// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <spine/Vector.h>
#include <spine/SpineString.h>  // 确保包含String头文件
#include <spine/Atlas.h>  // 确保包含AtlasPage头文件确保包含AtlasRegion头文件
#include <spine/BoneData.h>  // 确保包含BoneData头文件
#include <spine/SlotData.h>
#include <spine/Skin.h>
#include <spine/Animation.h>

#include <spine/EventData.h>
#include <spine/Animation.h>
#include <spine/ConstraintData.h>
#include <spine/IkConstraintData.h>
#include <spine/TransformConstraintData.h>
#include <spine/PathConstraintData.h>
#include <spine/PhysicsConstraintData.h>

#include <spine/SkeletonBounds.h>//Polygon
#include <spine/BoundingBoxAttachment.h>
#include <spine/TextureRegion.h>
#include <spine/Event.h>
#include <spine/AnimationState.h>//TrackEntry
#include <spine/Timeline.h>
#include <spine/Bone.h>
#include <spine/Updatable.h>
#include <spine/Slot.h>
#include <spine/IkConstraint.h>
#include <spine/PathConstraint.h>
#include <spine/TransformConstraint.h>
#include <spine/PhysicsConstraint.h>

namespace py = pybind11;
using namespace spine;

template<typename T>
void bind_vector(py::module& m, const std::string& type_name) {
    py::class_<Vector<T>>(m, ("Vector" + type_name).c_str())
        .def(py::init<>(), "默认构造函数")
        .def(py::init<const Vector<T>&>(), py::arg("other"), "拷贝构造函数")
        
        // 基础属性
        .def("size", &Vector<T>::size, "返回元素数量")
        .def("capacity", &Vector<T>::getCapacity, "返回容量")
        .def("empty", [](const Vector<T>& v) { return v.size() == 0; }, "判断是否为空")
        
        // 元素操作
        .def("clear", &Vector<T>::clear, "清空元素")
        .def("add", &Vector<T>::add, py::arg("value"), "添加元素")
        .def("add_all", &Vector<T>::addAll, py::arg("other"), "添加另一个Vector的所有元素")
        .def("clear_and_add_all", &Vector<T>::clearAndAddAll, py::arg("other"), "清空后添加另一个Vector的所有元素")
        .def("remove_at", &Vector<T>::removeAt, py::arg("index"), "移除指定索引元素")
        .def("contains", &Vector<T>::contains, py::arg("value"), "判断是否包含元素")
        .def("index_of", &Vector<T>::indexOf, py::arg("value"), "返回元素索引")
        
        // 容量管理
        .def("ensure_capacity", &Vector<T>::ensureCapacity, py::arg("new_capacity") = 0, "确保容量")
        .def("set_size", &Vector<T>::setSize, py::arg("new_size"), py::arg("default_value"), "设置大小并填充默认值")
        
        // 索引访问
        .def("__getitem__", [](const Vector<T>& v, size_t idx) {
            if (idx >= v.size()) throw py::index_error("索引超出范围");
            return const_cast<Vector<T>&>(v)[idx];  // 临时移除const以调用非const operator[]
        })
        .def("__setitem__", [](Vector<T>& v, size_t idx, const T& val) {
            if (idx >= v.size()) throw py::index_error("索引超出范围");
            v[idx] = val;
        })
        
        // 迭代器支持（核心修改：用const_cast规避const检查）
        .def("__iter__", [](const Vector<T>& v) {
            // 临时将const Vector转为非const以调用buffer()，但确保不修改数据
            Vector<T>& non_const_v = const_cast<Vector<T>&>(v);
            return py::make_iterator(non_const_v.buffer(), non_const_v.buffer() + v.size());
        }, py::keep_alive<0, 1>())  // 保持容器存活
        
        // 长度支持
        .def("__len__", &Vector<T>::size)
        
        // 比较操作（修正const不匹配）
        .def("__eq__", [](Vector<T>& a, Vector<T>& b) { return a == b; })  // 非const参数
        .def("__ne__", [](Vector<T>& a, Vector<T>& b) { return a != b; })  // 非const参数
        
        // 赋值操作
        .def("__assign__", &Vector<T>::operator=, py::arg("other"), "赋值运算符")
        
        // 转换为Python列表（核心修改：用const_cast）
        .def("to_list", [](const Vector<T>& v) {
            Vector<T>& non_const_v = const_cast<Vector<T>&>(v);
            return py::list(py::make_iterator(non_const_v.buffer(), non_const_v.buffer() + v.size()));
        }, "转换为Python列表")
        
        // 从Python列表初始化
        .def_static("from_list", [](const py::list& l) {
            Vector<T> v;
            for (auto& item : l) {
                v.add(item.cast<T>());
            }
            return v;
        }, py::arg("list"), "从列表创建Vector");
}
// 绑定常用类型（包含注释中所有Vector类型）
void bind_spine_vector(py::module& m) {
    // 1. 基础数据类型（含注释中的 long long、unsigned short）
    bind_vector<int>(m, "Int");
    bind_vector<float>(m, "Float");
    bind_vector<double>(m, "Double");
    bind_vector<bool>(m, "Bool");
    bind_vector<long long>(m, "LongLong");          // 对应注释：Vector<long long>
    bind_vector<unsigned short>(m, "UnsignedShort");// 对应注释：Vector<unsigned short>

    // 2. 字符串类型
    bind_vector<String>(m, "String");  // 绑定String类型的Vector

    // 3. Atlas相关指针类型
    bind_vector<AtlasPage *>(m, "AtlasPagePtr");    // 原绑定：AtlasPage*
    bind_vector<AtlasRegion *>(m, "AtlasRegionPtr");// 对应注释：Vector<AtlasRegion *>

    // 4. 骨骼数据相关指针类型（含原绑定+注释补充）
    bind_vector<BoneData *>(m, "BoneDataPtr");      // 修正原绑定的类型名（原误写为AtlasRegion）
    bind_vector<SlotData *>(m, "SlotDataPtr");      // 原绑定：SlotData*
    bind_vector<EventData *>(m, "EventDataPtr");    // 原绑定：EventData*
    bind_vector<Skin *>(m, "SkinPtr");              // 原绑定：Skin*
    bind_vector<Animation *>(m, "AnimationPtr");    // 原绑定：Animation*

    // 5. 约束数据相关指针类型（原绑定+注释补充）
    bind_vector<IkConstraintData *>(m, "IkConstraintDataPtr");          // 原绑定：IkConstraintData*
    bind_vector<TransformConstraintData *>(m, "TransformConstraintDataPtr");// 原绑定：TransformConstraintData*
    bind_vector<PathConstraintData *>(m, "PathConstraintDataPtr");      // 原绑定：PathConstraintData*
    bind_vector<PhysicsConstraintData *>(m, "PhysicsConstraintDataPtr");// 原绑定：PhysicsConstraintData*

    // 6. 附件/纹理相关指针类型（对应注释）
    bind_vector<Polygon *>(m, "PolygonPtr");                // 对应注释：Vector<Polygon *>
    bind_vector<BoundingBoxAttachment *>(m, "BoundingBoxAttachmentPtr");// 对应注释：Vector<BoundingBoxAttachment *>
    bind_vector<TextureRegion *>(m, "TextureRegionPtr");    // 对应注释：Vector<TextureRegion *>

    // 7. 运行时实例相关指针类型（对应注释）
    bind_vector<Event *>(m, "EventPtr");                    // 对应注释：Vector<Event *>
    bind_vector<TrackEntry *>(m, "TrackEntryPtr");          // 对应注释：Vector<TrackEntry *>
    bind_vector<Timeline *>(m, "TimelinePtr");              // 对应注释：Vector<Timeline *>
    bind_vector<Bone *>(m, "BonePtr");                      // 对应注释：Vector<Bone *>
    bind_vector<Updatable *>(m, "UpdatablePtr");            // 对应注释：Vector<Updatable *>
    bind_vector<Slot *>(m, "SlotPtr");                      // 对应注释：Vector<Slot *>
    bind_vector<IkConstraint *>(m, "IkConstraintPtr");      // 对应注释：Vector<IkConstraint *>
    bind_vector<PathConstraint *>(m, "PathConstraintPtr");  // 对应注释：Vector<PathConstraint *>
    bind_vector<TransformConstraint *>(m, "TransformConstraintPtr");// 对应注释：Vector<TransformConstraint *>
    bind_vector<PhysicsConstraint *>(m, "PhysicsConstraintPtr");// 对应注释：Vector<PhysicsConstraint *>
    bind_vector<ConstraintData  *>(m, "ConstraintDataPtr");// 对应注释：Vector<ConstraintData *>
    // 8. 嵌套容器类型（对应注释：Vector<Vector<float>*>）
    // 先绑定内层 Vector<float>（已在基础类型中绑定，类型名为"Float"）
    // 再绑定外层 Vector<Vector<float>*>，类型名设为"VectorFloatPtr"
    bind_vector<Vector<float> *>(m, "VectorFloatPtr");
}