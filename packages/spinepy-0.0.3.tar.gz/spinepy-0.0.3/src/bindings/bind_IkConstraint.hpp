// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/IkConstraint.h>

namespace py = pybind11;
using namespace spine;

void bind_ik_constraint(py::module_& m) {
    py::class_<IkConstraint, Updatable>(m, "IkConstraint")
        // 构造函数（不变）
        .def(py::init<IkConstraintData&, Skeleton&>(),
             py::arg("data"), py::arg("skeleton"),
             "构造函数：传入IK约束数据（IkConstraintData）和骨骼容器（Skeleton）")

        // -------------------------- 修正：显式指定重载函数类型 --------------------------
        // 1. 绑定 "单骨骼" 版本的 apply 静态方法
        .def_static(
            "apply_single_bone",
            // 显式声明函数指针类型，匹配第一个重载（参数：Bone&, float, float, bool, bool, bool, float）
            static_cast<void (*)(Bone&, float, float, bool, bool, bool, float)>(&IkConstraint::apply),
            py::arg("bone"), py::arg("target_x"), py::arg("target_y"),
            py::arg("compress"), py::arg("stretch"), py::arg("uniform"), py::arg("alpha"),
            "单骨骼IK计算：调整单个骨骼旋转，使骨骼尖端接近目标世界坐标"
        )

        // 2. 绑定 "父子骨骼" 版本的 apply 静态方法
        .def_static(
            "apply_parent_child",
            // 显式声明函数指针类型，匹配第二个重载（参数：Bone&, Bone&, float, float, int, bool, bool, float, float）
            static_cast<void (*)(Bone&, Bone&, float, float, int, bool, bool, float, float)>(&IkConstraint::apply),
            py::arg("parent_bone"), py::arg("child_bone"), py::arg("target_x"), py::arg("target_y"),
            py::arg("bend_dir"), py::arg("stretch"), py::arg("uniform"), py::arg("softness"), py::arg("alpha"),
            "父子骨骼IK计算：调整父子骨骼旋转，使子骨骼尖端接近目标世界坐标（child必须是parent的直接子骨骼）"
        )

        // -------------------------- 其他成员函数（不变） --------------------------
        .def("update", &IkConstraint::update,
             py::arg("physics"), "更新IK约束状态（参数为Physics枚举，控制物理更新逻辑）")
        .def("get_order", &IkConstraint::getOrder,
             "获取约束更新顺序（用于Skeleton按顺序执行约束，返回int）")
        .def("get_data", &IkConstraint::getData,
             "获取关联的IK约束数据（IkConstraintData）",
             py::return_value_policy::reference)
        .def("get_bones", &IkConstraint::getBones,
             "获取受该IK约束控制的骨骼列表（Vector<Bone*>）",
             py::return_value_policy::reference_internal)
        .def("get_target", &IkConstraint::getTarget,
             "获取IK约束的目标骨骼（Bone）",
             py::return_value_policy::reference)
        .def("set_target", &IkConstraint::setTarget,
             py::arg("target_bone"), "设置IK约束的目标骨骼（Bone）")
        .def("get_bend_direction", &IkConstraint::getBendDirection,
             "获取IK骨骼的弯曲方向（1 或 -1，控制骨骼弯曲朝向）")
        .def("set_bend_direction", &IkConstraint::setBendDirection,
             py::arg("direction"), "设置IK骨骼的弯曲方向（仅支持1或-1）")
        .def("get_compress", &IkConstraint::getCompress,
             "判断是否允许IK骨骼压缩（true=允许，false=禁止）")
        .def("set_compress", &IkConstraint::setCompress,
             py::arg("enable"), "设置是否允许IK骨骼压缩")
        .def("get_stretch", &IkConstraint::getStretch,
             "判断是否允许IK骨骼拉伸（true=允许，false=禁止）")
        .def("set_stretch", &IkConstraint::setStretch,
             py::arg("enable"), "设置是否允许IK骨骼拉伸")
        .def("get_mix", &IkConstraint::getMix,
             "获取IK约束的混合系数（0-1，值越大约束影响越强）")
        .def("set_mix", &IkConstraint::setMix,
             py::arg("mix"), "设置IK约束的混合系数（0-1范围）")
        .def("get_softness", &IkConstraint::getSoftness,
             "获取IK约束的柔和度（值越大，IK效果越柔和，避免骨骼突变）")
        .def("set_softness", &IkConstraint::setSoftness,
             py::arg("softness"), "设置IK约束的柔和度")
        .def("is_active", &IkConstraint::isActive,
             "判断IK约束是否处于激活状态（true=生效，false=失效）")
        .def("set_active", &IkConstraint::setActive,
             py::arg("enable"), "设置IK约束是否激活")
        .def("set_to_setup_pose", &IkConstraint::setToSetupPose,
             "将IK约束参数重置为初始姿态（恢复到SkeletonData定义的默认值）")
        .def("__repr__", [](const IkConstraint& self) {
            IkConstraint& non_const_self = const_cast<IkConstraint&>(self);
            return py::str("IkConstraint(data='{}', bones_count={}, active={})")
                .format(
                    non_const_self.getData().getName().buffer(),
                    non_const_self.getBones().size(),
                    non_const_self.isActive()
                );
        });
}