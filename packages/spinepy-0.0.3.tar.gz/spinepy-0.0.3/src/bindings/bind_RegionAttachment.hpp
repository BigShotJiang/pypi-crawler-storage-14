// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/RegionAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_region_attachment(py::module_& m) {
    py::class_<RegionAttachment, Attachment>(m, "RegionAttachment")
        // 1. 构造函数与析构函数
        .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为RegionAttachment的名称")
        .def("__del__", [](RegionAttachment& self) { /* 自动调用C++析构函数，无需额外逻辑 */ }, 
             "默认析构函数，释放内部资源")

        // 2. 核心功能函数
        .def("updateRegion", &RegionAttachment::updateRegion, 
             "更新纹理区域（TextureRegion）相关的顶点和UV数据，需在修改Region后调用")
        
        // 重载1：computeWorldVertices（输出到float数组）
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, float*, size_t, size_t>(&RegionAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("worldVertices"), py::arg("offset"), py::arg("stride") = 2,
             "计算4个顶点的世界坐标并输出到float数组\n"
             "- slot：父插槽（Slot）实例\n"
             "- worldVertices：输出数组（需预分配至少 offset + 8 长度）\n"
             "- offset：数组起始写入索引\n"
             "- stride：顶点数据步长（默认2，即[x,y]连续存储）")
        
        // 重载2：computeWorldVertices（输出到Vector<float>）
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, Vector<float>&, size_t, size_t>(&RegionAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("worldVertices"), py::arg("offset"), py::arg("stride") = 2,
             "计算4个顶点的世界坐标并输出到Vector<float>\n"
             "- 参数含义同数组版本，Vector会自动扩容以适配数据")

        // 3. 基础属性的get/set方法（位置、旋转、缩放、尺寸）
        .def("getX", &RegionAttachment::getX, "获取X轴位置")
        .def("setX", &RegionAttachment::setX, py::arg("inValue"), "设置X轴位置")
        .def("getY", &RegionAttachment::getY, "获取Y轴位置")
        .def("setY", &RegionAttachment::setY, py::arg("inValue"), "设置Y轴位置")
        .def("getRotation", &RegionAttachment::getRotation, "获取旋转角度（度）")
        .def("setRotation", &RegionAttachment::setRotation, py::arg("inValue"), "设置旋转角度（度）")
        .def("getScaleX", &RegionAttachment::getScaleX, "获取X轴缩放系数")
        .def("setScaleX", &RegionAttachment::setScaleX, py::arg("inValue"), "设置X轴缩放系数")
        .def("getScaleY", &RegionAttachment::getScaleY, "获取Y轴缩放系数")
        .def("setScaleY", &RegionAttachment::setScaleY, py::arg("inValue"), "设置Y轴缩放系数")
        .def("getWidth", &RegionAttachment::getWidth, "获取宽度")
        .def("setWidth", &RegionAttachment::setWidth, py::arg("inValue"), "设置宽度")
        .def("getHeight", &RegionAttachment::getHeight, "获取高度")
        .def("setHeight", &RegionAttachment::setHeight, py::arg("inValue"), "设置高度")

        // 4. 颜色、路径、纹理区域、序列相关属性
        .def("getColor", &RegionAttachment::getColor, py::return_value_policy::reference_internal, 
             "获取颜色引用（可直接修改RGB值）")
        .def("getPath", &RegionAttachment::getPath, py::return_value_policy::reference_internal, 
             "获取纹理路径字符串（只读，内部存储）")
        .def("setPath", &RegionAttachment::setPath, py::arg("inValue"), "设置纹理路径字符串")
        .def("getRegion", &RegionAttachment::getRegion, py::return_value_policy::reference, 
             "获取关联的TextureRegion（可能为None）")
        .def("setRegion", &RegionAttachment::setRegion, py::arg("region"), "设置关联的TextureRegion（可传None）")
        .def("getSequence", &RegionAttachment::getSequence, py::return_value_policy::reference, 
             "获取关联的Sequence（序列帧，可能为None）")
        .def("setSequence", &RegionAttachment::setSequence, py::arg("sequence"), "设置关联的Sequence（可传None）")

        // 5. 内部数据向量（顶点偏移、UV坐标）
        .def("getOffset", &RegionAttachment::getOffset, py::return_value_policy::reference_internal, 
             "获取顶点偏移向量（Vector<float>，存储4个顶点的偏移数据）")
        .def("getUVs", &RegionAttachment::getUVs, py::return_value_policy::reference_internal, 
             "获取UV坐标向量（Vector<float>，共8个值，对应4个顶点的UV）")

        // 6. 复制方法
        .def("copy", &RegionAttachment::copy, 
             "复制当前RegionAttachment并返回新实例（需手动管理新实例的生命周期）");
}