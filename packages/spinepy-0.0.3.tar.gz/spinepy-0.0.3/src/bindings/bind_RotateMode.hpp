// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/RotateMode.h>  // 替换为实际包含 RotateMode 的头文件

namespace py = pybind11;
using namespace spine;

void bind_rotate_mode(py::module_& m) {
    py::enum_<RotateMode>(m, "RotateMode")
        .value("TANGENT", RotateMode_Tangent, "切线旋转模式")
        .value("CHAIN", RotateMode_Chain, "链旋转模式")
        .value("CHAIN_SCALE", RotateMode_ChainScale, "链缩放旋转模式");
}