// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Vertices.h>

namespace py = pybind11;
using namespace spine;

void bind_vertices(py::module_ &m){
    // 绑定Vertices类
    py::class_<Vertices, SpineObject>(m, "Vertices")
        .def(py::init<>(), "创建Vertices实例")
        // 暴露_bones成员（Vector<int>类型）
        .def_readwrite("_bones", &Vertices::_bones, 
                      "骨骼索引列表（VectorInt类型）",
                      py::return_value_policy::reference_internal)  // 引用内部成员，不复制
        // 暴露_vertices成员（Vector<float>类型）
        .def_readwrite("_vertices", &Vertices::_vertices, 
                      "顶点坐标列表（VectorFloat类型）",
                      py::return_value_policy::reference_internal);
}
