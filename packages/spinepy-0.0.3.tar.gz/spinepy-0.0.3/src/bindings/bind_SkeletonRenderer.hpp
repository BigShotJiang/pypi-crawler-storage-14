// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>  // 用于处理 STL 容器（如 spine::Vector）
#include <spine/SkeletonRenderer.h>  // 假设 RenderCommand 和 SkeletonRenderer 实现在此头文件

// 定义 pybind11 命名空间别名（简化代码）
namespace py = pybind11;
// 绑定 spine 命名空间（让 Python 端能通过 spine.RenderCommand 访问）
using namespace spine;

// 第一步：绑定 RenderCommand 结构体
void bind_skeleton_renderer(py::module_& m) {
    py::class_<RenderCommand>(m, "RenderCommand")
        // 暴露结构体成员（注意指针类型的绑定方式）
        .def_readwrite("positions", &RenderCommand::positions, 
            py::return_value_policy::reference)  // 不转移所有权，仅返回引用
        .def_readwrite("uvs", &RenderCommand::uvs, 
            py::return_value_policy::reference)
        .def_readwrite("colors", &RenderCommand::colors, 
            py::return_value_policy::reference)
        .def_readwrite("darkColors", &RenderCommand::darkColors, 
            py::return_value_policy::reference)
        .def_readwrite("numVertices", &RenderCommand::numVertices)  // 普通 int32_t，直接暴露
        .def_readwrite("indices", &RenderCommand::indices, 
            py::return_value_policy::reference)
        .def_readwrite("numIndices", &RenderCommand::numIndices)    // 普通 int32_t
        .def_readwrite("blendMode", &RenderCommand::blendMode)      // 枚举类型，自动匹配
        .def_readwrite("texture", &RenderCommand::texture, 
            py::return_value_policy::reference)  // void* 类型，Python 端会视为通用指针
        .def_readwrite("next", &RenderCommand::next, 
            py::return_value_policy::reference) // 指向自身的指针（链表结构）

        //? 这是我自定义的返回数据方法，在c++进行处理和封装，最后以列表形式返回
        // 新增：返回当前command的所有原始数据（单个命令）
        .def("get_raw_data", [](RenderCommand& self) -> py::dict {
            py::dict data;  // 存储单个命令的所有数据

            // 1. positions: float* -> Python列表（原始float值）
            py::list positions;
            if (self.positions && self.numVertices > 0) {
                for (int i = 0; i < self.numVertices * 2; ++i) {  // 每个顶点2个坐标
                    positions.append(self.positions[i]);
                }
            }
            data["positions"] = positions;

            // 2. uvs: float* -> Python列表
            py::list uvs;
            if (self.uvs && self.numVertices > 0) {
                for (int i = 0; i < self.numVertices * 2; ++i) {  // 每个顶点2个纹理坐标
                    uvs.append(self.uvs[i]);
                }
            }
            data["uvs"] = uvs;

            // 3. colors: uint32_t* -> Python列表
            py::list colors;
            if (self.colors && self.numVertices > 0) {
                for (int i = 0; i < self.numVertices; ++i) {  // 每个顶点1个颜色
                    colors.append(static_cast<uint64_t>(self.colors[i]));
                }
            }
            data["colors"] = colors;

            // 4. darkColors: uint32_t* -> Python列表
            py::list dark_colors;
            if (self.darkColors && self.numVertices > 0) {
                for (int i = 0; i < self.numVertices; ++i) {
                    dark_colors.append(static_cast<uint64_t>(self.darkColors[i]));
                }
            }
            data["darkColors"] = dark_colors;

            // 5. indices: uint16_t* -> Python列表
            py::list indices;
            if (self.indices && self.numIndices > 0) {
                for (int i = 0; i < self.numIndices; ++i) {
                    indices.append(static_cast<uint64_t>(self.indices[i]));
                }
            }
            data["indices"] = indices;

            // 6. 附加基本信息（顶点数、索引数等）
            data["numVertices"] = self.numVertices;
            data["numIndices"] = self.numIndices;
            data["blendMode"] = self.blendMode;
            data["texture"] = reinterpret_cast<uint64_t>(self.texture);  // 纹理ID

            return data;
        }, "返回当前RenderCommand的所有原始数据（单个命令）");



    py::class_<SkeletonRenderer>(m, "SkeletonRenderer")
        // 绑定构造函数（C++ 中是 explicit 单参构造，无默认构造）
        .def(py::init<>())  // 假设 C++ 构造函数无参数（需与实际实现匹配）
        
        // 绑定析构函数（pybind11 自动处理，但可显式声明以明确所有权）
        .def("__del__", [](SkeletonRenderer& self) { 
            // 若 C++ 析构函数需特殊处理，可在此添加逻辑（默认无需）
        })
        
        // 绑定核心方法 render()（关键：处理引用参数和返回值）
        .def("render", &SkeletonRenderer::render,
            py::arg("skeleton"),  // 明确参数名（Python 端调用时更清晰）
            py::return_value_policy::reference)  // 返回 RenderCommand*，不转移所有权
        ;

}