// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/BoneData.h>
#include <spine/Inherit.h>  // 依赖Inherit枚举
#include <spine/Color.h>    // 依赖Color类

namespace py = pybind11;
using namespace spine;

// 前置声明BoneData绑定函数（供其他绑定文件调用）
void bind_bonedata(py::module_ &m) {
    // 绑定BoneData类（继承自SpineObject，无需需完整绑定SpineObject，只需声明编译器知道其存在）
    py::class_<BoneData, SpineObject>(m, "BoneData")
        // 构造函数（参数：index, name, parent）
        .def(py::init<int, const String &, BoneData *>(),
             py::arg("index"), py::arg("name"), py::arg("parent") = nullptr,
             "创建BoneData实例（索引、名称、父骨骼数据）")

        // 基础属性（getter）
        .def("get_index", &BoneData::getIndex, "获取骨骼在骨架中的索引")
        .def("get_name", &BoneData::getName, py::return_value_policy::reference_internal,
             "获取骨骼名称（字符串引用，不复制）")
        .def("get_parent", &BoneData::getParent, py::return_value_policy::reference,
             "获取父骨骼数据（可能为None）")

        // 长度属性
        .def("get_length", &BoneData::getLength, "获取骨骼长度")
        .def("set_length", &BoneData::setLength, "设置骨骼长度", py::arg("value"))
        .def_property("length", &BoneData::getLength, &BoneData::setLength, "骨骼长度")

        // 本地变换属性（X/Y位移、旋转、缩放、剪切）
        .def_property("x", &BoneData::getX, &BoneData::setX, "本地X坐标")
        .def_property("y", &BoneData::getY, &BoneData::setY, "本地Y坐标")
        .def_property("rotation", &BoneData::getRotation, &BoneData::setRotation, "本地旋转角度（度）")
        .def_property("scale_x", &BoneData::getScaleX, &BoneData::setScaleX, "X轴缩放系数")
        .def_property("scale_y", &BoneData::getScaleY, &BoneData::setScaleY, "Y轴缩放系数")
        .def_property("shear_x", &BoneData::getShearX, &BoneData::setShearX, "X轴剪切系数")
        .def_property("shear_y", &BoneData::getShearY, &BoneData::setShearY, "Y轴剪切系数")

        // 继承模式（依赖已绑定的Inherit枚举）
        .def_property("inherit", &BoneData::getInherit, &BoneData::setInherit, 
                     "骨骼继承模式（参考Inherit枚举）")

        // 皮肤与可见性
        .def_property("skin_required", &BoneData::isSkinRequired, &BoneData::setSkinRequired,
                     "是否需要特定皮肤才能显示")
        .def_property("visible", &BoneData::isVisible, &BoneData::setVisible, "骨骼是否可见")

        // 颜色属性（返回Color对象引用，需确保Color已绑定）
        .def("get_color", &BoneData::getColor, py::return_value_policy::reference,
             "获取骨骼颜色（Color对象）")
        .def("set_color", [](BoneData &self, const Color &color) {
            self.getColor() = color;
        }, "设置骨骼颜色", py::arg("color"))
        .def_property("color", 
                     [](BoneData &self) { return &self.getColor(); },
                     [](BoneData &self, const Color &color) { self.getColor() = color; },
                     py::return_value_policy::reference,
                     "骨骼颜色（Color对象）")

        // 图标属性
        .def_property("icon", 
                     &BoneData::getIcon, 
                     &BoneData::setIcon, 
                     py::return_value_policy::reference_internal,
                     "骨骼图标名称");
}