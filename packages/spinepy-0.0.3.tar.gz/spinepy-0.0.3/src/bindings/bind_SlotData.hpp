// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/SlotData.h>
#include <spine/BoneData.h>  // 依赖 BoneData 类
#include <spine/BlendMode.h> // 依赖 BlendMode 枚举
#include <spine/Color.h>     // 依赖 Color 类

namespace py = pybind11;
using namespace spine;

void bind_slot_data(py::module_& m) {
    py::class_<SlotData, SpineObject>(m, "SlotData")
        // 构造函数（注意：参数包含 BoneData&，需传入已绑定的 BoneData 实例）
        .def(py::init<int, const String&, BoneData&>(),
             py::arg("index"), py::arg("name"), py::arg("bone_data"),
             "构造函数：索引、名称、所属骨骼数据")

        // 公共方法绑定
        .def("get_index", &SlotData::getIndex, 
             "获取插槽索引")
        .def("get_name", &SlotData::getName, 
             "获取插槽名称",
             py::return_value_policy::reference_internal)  // 返回内部字符串引用
        .def("get_bone_data", &SlotData::getBoneData, 
             "获取所属骨骼数据（BoneData）",
             py::return_value_policy::reference)  // 返回对 BoneData 的引用（不转移所有权）
        .def("get_color", &SlotData::getColor, 
             "获取颜色（Color）",
             py::return_value_policy::reference_internal)  // 返回内部 Color 对象引用
        .def("get_dark_color", &SlotData::getDarkColor, 
             "获取暗色（Color）",
             py::return_value_policy::reference_internal)
        .def("has_dark_color", &SlotData::hasDarkColor, 
             "判断是否有暗色")
        .def("set_has_dark_color", &SlotData::setHasDarkColor, 
             py::arg("value"), "设置是否有暗色")
        .def("get_attachment_name", &SlotData::getAttachmentName, 
             "获取附件名称",
             py::return_value_policy::reference_internal)
        .def("set_attachment_name", &SlotData::setAttachmentName, 
             py::arg("name"), "设置附件名称")
        .def("get_blend_mode", &SlotData::getBlendMode, 
             "获取混合模式（BlendMode）")
        .def("set_blend_mode", &SlotData::setBlendMode, 
             py::arg("mode"), "设置混合模式（BlendMode）")
        .def("is_visible", &SlotData::isVisible, 
             "判断是否可见")
        .def("set_visible", &SlotData::setVisible, 
             py::arg("visible"), "设置是否可见")

        .def("__repr__", [](const SlotData& self) {
            // 临时解除 const 限制，以调用非 const 成员函数
            SlotData& non_const_self = const_cast<SlotData&>(self);
            return py::str("SlotData(index={}, name='{}', bone='{}')")
                .format(
                    non_const_self.getIndex(), 
                    non_const_self.getName().buffer(), 
                    non_const_self.getBoneData().getName().buffer()
                );
        });
}