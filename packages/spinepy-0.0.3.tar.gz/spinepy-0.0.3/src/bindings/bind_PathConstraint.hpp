// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/PathConstraint.h>

namespace py = pybind11;
using namespace spine;

void bind_path_constraint(py::module_& m) {
    // 绑定路径约束类（继承自Updatable）
    py::class_<PathConstraint, Updatable>(m, "PathConstraint")
        // 1. 构造函数（通常由Skeleton内部创建，Python侧一般不直接实例化）
        .def(py::init<PathConstraintData&, Skeleton&>(),
             py::arg("data"), py::arg("skeleton"),
             "构造函数：传入路径约束数据（PathConstraintData）和骨骼容器（Skeleton）")

        // 2. 基类Updatable接口
        .def("update", &PathConstraint::update,
             py::arg("physics"), "更新路径约束状态（参数为Physics枚举，控制物理更新逻辑）")
        .def("get_order", &PathConstraint::getOrder,
             "获取约束更新顺序（用于Skeleton按顺序执行约束，返回int）")

        // 3. 关联数据与受约束骨骼列表
        .def("get_data", &PathConstraint::getData,
             "获取关联的路径约束数据（PathConstraintData）",
             py::return_value_policy::reference)  // 数据由外部管理，返回引用
        .def("get_bones", &PathConstraint::getBones,
             "获取受该路径约束控制的骨骼列表（Vector<Bone*>）",
             py::return_value_policy::reference_internal)  // 内部容器，不转移所有权

        // 4. 目标插槽操作（路径约束的目标是Slot，其包含PathAttachment）
        .def("get_target", &PathConstraint::getTarget,
             "获取路径约束的目标插槽（Slot，需包含PathAttachment才能生效）",
             py::return_value_policy::reference)  // 目标插槽由Skeleton管理，返回引用
        .def("set_target", &PathConstraint::setTarget,
             py::arg("target_slot"), "设置路径约束的目标插槽（Slot，需包含PathAttachment）")

        // 5. 路径位置与间距参数
        .def("get_position", &PathConstraint::getPosition,
             "获取骨骼在路径上的位置参数（具体含义由PositionMode决定：固定值/百分比）")
        .def("set_position", &PathConstraint::setPosition,
             py::arg("position"), "设置骨骼在路径上的位置参数")
        .def("get_spacing", &PathConstraint::getSpacing,
             "获取骨骼间的间距参数（具体含义由SpacingMode决定：长度/固定值/百分比/比例）")
        .def("set_spacing", &PathConstraint::setSpacing,
             py::arg("spacing"), "设置骨骼间的间距参数")

        // 6. 混合系数（控制约束对旋转/X/Y轴位置的影响强度）
        .def("get_mix_rotate", &PathConstraint::getMixRotate,
             "获取旋转属性的混合系数（0-1，值越大约束影响越强）")
        .def("set_mix_rotate", &PathConstraint::setMixRotate,
             py::arg("mix"), "设置旋转属性的混合系数（0-1）")
        .def("get_mix_x", &PathConstraint::getMixX,
             "获取X轴位置的混合系数（0-1）")
        .def("set_mix_x", &PathConstraint::setMixX,
             py::arg("mix"), "设置X轴位置的混合系数（0-1）")
        .def("get_mix_y", &PathConstraint::getMixY,
             "获取Y轴位置的混合系数（0-1）")
        .def("set_mix_y", &PathConstraint::setMixY,
             py::arg("mix"), "设置Y轴位置的混合系数（0-1）")

        // 7. 激活状态与初始姿态
        .def("is_active", &PathConstraint::isActive,
             "判断路径约束是否处于激活状态（true=生效，false=失效）")
        .def("set_active", &PathConstraint::setActive,
             py::arg("enable"), "设置路径约束是否激活")
        .def("set_to_setup_pose", &PathConstraint::setToSetupPose,
             "将路径约束参数重置为初始姿态（恢复到PathConstraintData定义的默认值）")

        // 8. 调试字符串（便于Python侧查看实例信息）
        .def("__repr__", [](const PathConstraint& self) {
            // 临时解除const限制（处理非const成员函数）
            PathConstraint& non_const_self = const_cast<PathConstraint&>(self);
            return py::str("PathConstraint(data='{}', bones_count={}, active={})")
                .format(
                    non_const_self.getData().getName().buffer(),  // 约束数据名称
                    non_const_self.getBones().size(),             // 受约束骨骼数量
                    non_const_self.isActive()                     // 激活状态
                );
        });
}