// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/VertexAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_vertex_attachment(py::module_& m) {
    py::class_<VertexAttachment, Attachment>(m, "VertexAttachment")
        // .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为附件名称")
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, float*>(&VertexAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("worldVertices"), 
             "计算世界坐标顶点，输出到float数组")
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, Vector<float>&>(&VertexAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("worldVertices"), 
             "计算世界坐标顶点，输出到Vector<float>")
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, size_t, size_t, float*, size_t, size_t>(&VertexAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("start"), py::arg("count"), 
             py::arg("worldVertices"), py::arg("offset"), py::arg("stride") = 2,
             "计算世界坐标顶点（带范围和步长参数），输出到float数组")
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, size_t, size_t, Vector<float>&, size_t, size_t>(&VertexAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("start"), py::arg("count"), 
             py::arg("worldVertices"), py::arg("offset"), py::arg("stride") = 2,
             "计算世界坐标顶点（带范围和步长参数），输出到Vector<float>")
        .def("getId", &VertexAttachment::getId, "获取附件的唯一ID")
        .def("getBones", &VertexAttachment::getBones, py::return_value_policy::reference_internal,
             "返回影响该附件的骨骼索引向量")
        .def("getVertices", &VertexAttachment::getVertices, py::return_value_policy::reference_internal,
             "返回本地顶点坐标向量")
        .def("getWorldVerticesLength", &VertexAttachment::getWorldVerticesLength,
             "获取世界坐标顶点的长度")
        .def("setWorldVerticesLength", &VertexAttachment::setWorldVerticesLength, py::arg("inValue"),
             "设置世界坐标顶点的长度")
        .def("getTimelineAttachment", &VertexAttachment::getTimelineAttachment, py::return_value_policy::reference,
             "获取时间线关联的附件")
        .def("setTimelineAttachment", &VertexAttachment::setTimelineAttachment, py::arg("attachment"),
             "设置时间线关联的附件")
        .def("copyTo", &VertexAttachment::copyTo, py::arg("other"),
             "将当前附件的数据复制到另一个VertexAttachment实例");
}