// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>  // 用于处理Python列表转换
#include <spine/Skin.h>
#include <spine/SpineObject.h>
#include <spine/Attachment.h>
#include <spine/BoneData.h>
#include <spine/ConstraintData.h>
#include <spine/Color.h>
#include <spine/Vector.h>

namespace py = pybind11;
using namespace spine;

// 先绑定 Skin::AttachmentMap 内部类（含 Entry 和 Entries 子内部类）
void bind_skin_attachment_map(py::module_& m) {
    // 1. 绑定 Skin::AttachmentMap::Entry（附件映射的条目）
    py::class_<Skin::AttachmentMap::Entry>(m, "SkinAttachmentEntry")
        .def_readonly("_slot_index", &Skin::AttachmentMap::Entry::_slotIndex, "插槽索引")
        .def_readonly("_name", &Skin::AttachmentMap::Entry::_name, "附件名称", py::return_value_policy::reference_internal)
        .def_readonly("_attachment", &Skin::AttachmentMap::Entry::_attachment, "关联的附件", py::return_value_policy::reference)
        .def("__repr__", [](const Skin::AttachmentMap::Entry& self) {
            const char* att_name = self._attachment ? self._attachment->getName().buffer() : "null";
            return py::str("SkinAttachmentEntry(slot_index={}, name='{}', attachment='{}')")
                .format(self._slotIndex, self._name.buffer(), att_name);
        });

    // 2. 绑定 Skin::AttachmentMap::Entries（条目迭代器，手动实现Python迭代器协议）
    py::class_<Skin::AttachmentMap::Entries>(m, "SkinAttachmentEntries")
        .def("has_next", &Skin::AttachmentMap::Entries::hasNext, "判断是否有下一个条目")
        .def("next", &Skin::AttachmentMap::Entries::next, "获取下一个条目（C++风格）", py::return_value_policy::reference_internal)
        // 实现Python迭代器协议：__iter__ 返回自身，__next__ 调用 hasNext()/next()
        .def("__iter__", [](py::object self) { return self; })  // 迭代器的 __iter__ 返回自身
        .def("__next__", [](Skin::AttachmentMap::Entries& self) {
            if (self.hasNext()) {
                // 有下一个条目时返回
                return &self.next();  // 返回Entry的引用，配合reference_internal策略
            } else {
                // 没有下一个条目时，抛出StopIteration（Python迭代结束的标准方式）
                throw py::stop_iteration();
            }
        }, py::return_value_policy::reference_internal);  // 保持Entry的生命周期与Entries绑定

    // 3. 绑定 Skin::AttachmentMap（附件映射表）
    py::class_<Skin::AttachmentMap, SpineObject>(m, "SkinAttachmentMap")
        .def("put", &Skin::AttachmentMap::put, 
             py::arg("slot_index"), py::arg("attachment_name"), py::arg("attachment"), 
             "添加附件到映射表（覆盖同名条目）")
        .def("get", &Skin::AttachmentMap::get, 
             py::arg("slot_index"), py::arg("attachment_name"), 
             "根据插槽索引和名称获取附件（不存在返回None）", 
             py::return_value_policy::reference)
        .def("remove", &Skin::AttachmentMap::remove, 
             py::arg("slot_index"), py::arg("attachment_name"), 
             "从映射表移除附件")
        .def("get_entries", &Skin::AttachmentMap::getEntries, 
             "获取所有条目的迭代器", 
             py::return_value_policy::reference_internal);
}

// 绑定 Skin 主类
void bind_skin(py::module_& m) {
    // 先绑定内部类 AttachmentMap
    bind_skin_attachment_map(m);

    py::class_<Skin, SpineObject>(m, "Skin")
        // 构造函数
        .def(py::init<const String&>(), 
             py::arg("name"), 
             "构造函数：传入皮肤名称")

        // 附件操作（核心接口）
        .def("set_attachment", &Skin::setAttachment, 
             py::arg("slot_index"), py::arg("name"), py::arg("attachment"), 
             "添加附件到皮肤（覆盖同名附件）")
        .def("get_attachment", &Skin::getAttachment, 
             py::arg("slot_index"), py::arg("name"), 
             "根据插槽索引和名称获取附件（不存在返回None）", 
             py::return_value_policy::reference)
        .def("remove_attachment", &Skin::removeAttachment, 
             py::arg("slot_index"), py::arg("name"), 
             "从皮肤移除附件")

        // 插槽相关附件查询（转换为Python列表返回，更易用）
        .def("find_names_for_slot", [](Skin& self, size_t slot_index) {
            Vector<String> names_vec;
            self.findNamesForSlot(slot_index, names_vec);
            // 转换为Python列表
            py::list names_list;
            for (size_t i = 0; i < names_vec.size(); ++i) {
                names_list.append(names_vec[i].buffer());
            }
            return names_list;
        }, py::arg("slot_index"), "获取指定插槽下的所有附件名称（返回Python列表）")
        .def("find_attachments_for_slot", [](Skin& self, size_t slot_index) {
            Vector<Attachment*> atts_vec;
            self.findAttachmentsForSlot(slot_index, atts_vec);
            // 转换为Python列表
            py::list atts_list;
            for (size_t i = 0; i < atts_vec.size(); ++i) {
                atts_list.append(atts_vec[i]);
            }
            return atts_list;
        }, py::arg("slot_index"), "获取指定插槽下的所有附件（返回Python列表）")

        // 名称与附件映射表
        .def("get_name", &Skin::getName, 
             "获取皮肤名称", 
             py::return_value_policy::reference_internal)
        .def("get_attachments", &Skin::getAttachments, 
             "获取所有附件的映射迭代器", 
             py::return_value_policy::reference_internal)

        // 骨骼与约束数据（内部容器）
        .def("get_bones", &Skin::getBones, 
             "获取皮肤关联的骨骼数据列表（Vector<BoneData*>）", 
             py::return_value_policy::reference_internal)
        .def("get_constraints", &Skin::getConstraints, 
             "获取皮肤关联的约束数据列表（Vector<ConstraintData*>）", 
             py::return_value_policy::reference_internal)

        // 颜色属性
        .def("get_color", &Skin::getColor, 
             "获取皮肤颜色（可直接修改Color对象）", 
             py::return_value_policy::reference_internal)

        // 皮肤合并与复制
        .def("add_skin", &Skin::addSkin, 
             py::arg("other"), 
             "将另一个皮肤的所有资源（附件/骨骼/约束）添加到当前皮肤")
        .def("copy_skin", &Skin::copySkin, 
             py::arg("other"), 
             "复制另一个皮肤的所有资源（附件深拷贝）到当前皮肤")

        // 调试字符串
        .def("__repr__", [](const Skin& self) {
            Skin& non_const_self = const_cast<Skin&>(self);
            return py::str("Skin(name='{}', bones_count={}, constraints_count={})")
                .format(
                    non_const_self.getName().buffer(),
                    non_const_self.getBones().size(),
                    non_const_self.getConstraints().size()
                );
        });
}