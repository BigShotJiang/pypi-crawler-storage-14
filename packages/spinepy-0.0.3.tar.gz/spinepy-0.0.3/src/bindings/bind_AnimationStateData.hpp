// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/AnimationStateData.h"

namespace py = pybind11;
using namespace spine;

void bind_animation_state_data(py::module_& m) {
    py::class_<AnimationStateData, SpineObject>(m, "AnimationStateData")
        // 1. 构造函数
        .def(py::init<SkeletonData*>(), py::arg("skeleton_data"),
             "构造函数\n"
             "- skeleton_data：骨骼数据（SkeletonData*），用于查找动画")

        // 2. 骨骼数据访问
        .def("getSkeletonData", &AnimationStateData::getSkeletonData, 
             py::return_value_policy::reference,
             "获取关联的骨骼数据（SkeletonData*）")

        // 3. 默认混合时长（crossfade）设置
        .def("getDefaultMix", &AnimationStateData::getDefaultMix,
             "获取默认动画混合时长（秒）\n"
             "当两个动画之间没有特定混合时长时使用此值")
        .def("setDefaultMix", &AnimationStateData::setDefaultMix, py::arg("in_value"),
             "设置默认动画混合时长（秒）")

        // 4. 动画混合时长设置（两种重载：按名称/按Animation对象）
        .def("setMix", 
             py::overload_cast<const String&, const String&, float>(&AnimationStateData::setMix),
             py::arg("from_name"), py::arg("to_name"), py::arg("duration"),
             "按动画名称设置混合时长\n"
             "- from_name：源动画名称\n"
             "- to_name：目标动画名称\n"
             "- duration：混合时长（秒）")
        .def("setMix", 
             py::overload_cast<Animation*, Animation*, float>(&AnimationStateData::setMix),
             py::arg("from"), py::arg("to"), py::arg("duration"),
             "按Animation对象设置混合时长\n"
             "- from：源动画实例\n"
             "- to：目标动画实例\n"
             "- duration：混合时长（秒）")

        // 5. 获取动画混合时长
        .def("getMix", &AnimationStateData::getMix, 
             py::arg("from"), py::arg("to"),
             "获取两个动画之间的混合时长（秒）\n"
             "- from：源动画实例\n"
             "- to：目标动画实例\n"
             "- 返回：设置的混合时长，若未设置则返回默认混合时长")

        // 6. 清空所有混合设置
        .def("clear", &AnimationStateData::clear,
             "清除所有已设置的混合时长，并将默认混合时长设为0");
}