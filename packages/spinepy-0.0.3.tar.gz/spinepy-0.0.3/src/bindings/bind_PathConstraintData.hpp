// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/PathConstraintData.h>

namespace py = pybind11;
using namespace spine;

void bind_path_constraint_data(py::module_& m) {
    // 绑定路径约束数据类（继承自 ConstraintData）
    py::class_<PathConstraintData, ConstraintData>(m, "PathConstraintData")
        // 构造函数（接收约束名称）
        .def(py::init<const String&>(),
             py::arg("name"),
             "构造函数：传入路径约束名称（骨骼中唯一）")

        // 关联骨骼列表（返回 Vector<BoneData*>，需确保该容器已绑定）
        .def("get_bones", &PathConstraintData::getBones,
             "获取受约束的骨骼数据列表（Vector<BoneData*>）",
             py::return_value_policy::reference_internal)  // 内部容器引用，不转移所有权

        // 目标插槽操作（SlotData*）
        .def("get_target", &PathConstraintData::getTarget,
             "获取路径约束的目标插槽数据（SlotData）",
             py::return_value_policy::reference)  // 返回插槽引用（不转移所有权）
        .def("set_target", &PathConstraintData::setTarget,
             py::arg("slot_data"), "设置路径约束的目标插槽数据（SlotData）")

        // 模式参数（PositionMode/SpacingMode/RotateMode 枚举）
        .def("get_position_mode", &PathConstraintData::getPositionMode,
             "获取位置模式（PositionMode 枚举）")
        .def("set_position_mode", &PathConstraintData::setPositionMode,
             py::arg("mode"), "设置位置模式（PositionMode 枚举）")
        .def("get_spacing_mode", &PathConstraintData::getSpacingMode,
             "获取间距模式（SpacingMode 枚举）")
        .def("set_spacing_mode", &PathConstraintData::setSpacingMode,
             py::arg("mode"), "设置间距模式（SpacingMode 枚举）")
        .def("get_rotate_mode", &PathConstraintData::getRotateMode,
             "获取旋转模式（RotateMode 枚举）")
        .def("set_rotate_mode", &PathConstraintData::setRotateMode,
             py::arg("mode"), "设置旋转模式（RotateMode 枚举）")

        // 偏移与位置参数
        .def("get_offset_rotation", &PathConstraintData::getOffsetRotation,
             "获取旋转偏移量（角度）")
        .def("set_offset_rotation", &PathConstraintData::setOffsetRotation,
             py::arg("offset"), "设置旋转偏移量（角度）")
        .def("get_position", &PathConstraintData::getPosition,
             "获取路径位置参数")
        .def("set_position", &PathConstraintData::setPosition,
             py::arg("position"), "设置路径位置参数")
        .def("get_spacing", &PathConstraintData::getSpacing,
             "获取间距参数")
        .def("set_spacing", &PathConstraintData::setSpacing,
             py::arg("spacing"), "设置间距参数")

        // 混合系数（旋转/X/Y轴）
        .def("get_mix_rotate", &PathConstraintData::getMixRotate,
             "获取旋转混合系数（0-1，值越大约束影响越强）")
        .def("set_mix_rotate", &PathConstraintData::setMixRotate,
             py::arg("mix"), "设置旋转混合系数（0-1）")
        .def("get_mix_x", &PathConstraintData::getMixX,
             "获取X轴混合系数（0-1）")
        .def("set_mix_x", &PathConstraintData::setMixX,
             py::arg("mix"), "设置X轴混合系数（0-1）")
        .def("get_mix_y", &PathConstraintData::getMixY,
             "获取Y轴混合系数（0-1）")
        .def("set_mix_y", &PathConstraintData::setMixY,
             py::arg("mix"), "设置Y轴混合系数（0-1）")

        // 调试字符串表示
        .def("__repr__", [](const PathConstraintData& self) {
            // 临时解除const限制以调用非const成员函数
            PathConstraintData& non_const_self = const_cast<PathConstraintData&>(self);
            // 获取目标插槽名称（若存在）
            const char* target_name = non_const_self.getTarget() 
                ? non_const_self.getTarget()->getName().buffer() 
                : "null";
            return py::str("PathConstraintData(name='{}', target='{}', bones_count={})")
                .format(
                    non_const_self.getName().buffer(),  // 从基类 ConstraintData 继承的名称
                    target_name,
                    non_const_self.getBones().size()     // 受约束骨骼数量
                );
        });
}