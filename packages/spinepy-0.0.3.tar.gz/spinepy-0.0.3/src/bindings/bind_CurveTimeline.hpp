// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/CurveTimeline.h>
#include <spine/MixBlend.h>
#include <spine/MixDirection.h>

namespace py = pybind11;
using namespace spine;

void bind_curve_timelines(py::module& m) {
    // 1. 基础曲线时间线（CurveTimeline）
    py::class_<CurveTimeline, Timeline>(m, "CurveTimeline")

        .def("set_linear", &CurveTimeline::setLinear, 
             py::arg("frame"), "将指定帧设置为线性插值")
        .def("set_stepped", &CurveTimeline::setStepped, 
             py::arg("frame"), "将指定帧设置为阶梯插值（无过渡）")
        .def("set_bezier", &CurveTimeline::setBezier,
             py::arg("bezier"), py::arg("frame"), py::arg("value"),
             py::arg("time1"), py::arg("value1"), py::arg("cx1"), py::arg("cy1"),
             py::arg("cx2"), py::arg("cy2"), py::arg("time2"), py::arg("value2"),
             "设置贝塞尔曲线插值参数")
        .def("get_bezier_value", &CurveTimeline::getBezierValue,
             py::arg("time"), py::arg("frame"), py::arg("value_offset"), py::arg("i"),
             "获取贝塞尔曲线在指定时间的插值结果")
        .def_property_readonly("curves", &CurveTimeline::getCurves,
                              "获取曲线数据向量（内部插值参数）");

    // 2. 单值曲线时间线（CurveTimeline1）
    py::class_<CurveTimeline1, CurveTimeline>(m, "CurveTimeline1")

        .def("set_frame", &CurveTimeline1::setFrame,
             py::arg("frame"), py::arg("time"), py::arg("value"),
             "设置指定帧的时间和值")
        .def("get_curve_value", &CurveTimeline1::getCurveValue,
             py::arg("time"), "获取指定时间的曲线值")
        .def("get_relative_value", &CurveTimeline1::getRelativeValue,
             py::arg("time"), py::arg("alpha"), py::arg("blend"), py::arg("current"), py::arg("setup"),
             "获取相对混合模式下的插值结果")
        .def("get_absolute_value", py::overload_cast<float, float, MixBlend, float, float>(&CurveTimeline1::getAbsoluteValue),
             py::arg("time"), py::arg("alpha"), py::arg("blend"), py::arg("current"), py::arg("setup"),
             "获取绝对混合模式下的插值结果")
        .def("get_absolute_value", py::overload_cast<float, float, MixBlend, float, float, float>(&CurveTimeline1::getAbsoluteValue),
             py::arg("time"), py::arg("alpha"), py::arg("blend"), py::arg("current"), py::arg("setup"), py::arg("value"),
             "获取带额外值的绝对混合模式插值结果")
        .def("get_scale_value", &CurveTimeline1::getScaleValue,
             py::arg("time"), py::arg("alpha"), py::arg("blend"), py::arg("direction"), py::arg("current"), py::arg("setup"),
             "获取缩放混合模式下的插值结果");

    // 3. 双值曲线时间线（CurveTimeline2）
    py::class_<CurveTimeline2, CurveTimeline>(m, "CurveTimeline2")

        .def("set_frame", &CurveTimeline2::setFrame,
             py::arg("frame"), py::arg("time"), py::arg("value1"), py::arg("value2"),
             "设置指定帧的时间和两个值");
     //!CurveTimeline2的getCurveValue根本没有实现！！！
     //    .def("get_curve_value", &CurveTimeline2::getCurveValue,
     //         py::arg("time"), "获取指定时间的曲线值（返回第一个值）");
}