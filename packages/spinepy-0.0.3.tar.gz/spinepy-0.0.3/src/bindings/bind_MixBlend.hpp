// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/MixBlend.h>  // 假设包含该枚举的头文件

namespace py = pybind11;
using namespace spine;

void bind_mix_blend(py::module_& m) {
    // 绑定 BlendMode 枚举，不导出到模块顶层（避免命名污染）
    py::enum_<MixBlend>(m, "MixBlend")
        .value("MixBlend_Setup", MixBlend_Setup)
        .value("MixBlend_First", MixBlend_First)
        .value("MixBlend_Replace", MixBlend_Replace)
        .value("MixBlend_Add", MixBlend_Add);
}