// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/IkConstraintData.h>

namespace py = pybind11;
using namespace spine;

void bind_ik_constraint_data(py::module_& m) {
    // 绑定 IK 约束数据类（继承自 ConstraintData）
    py::class_<IkConstraintData, ConstraintData>(m, "IkConstraintData")
        // 构造函数（接收约束名称，骨骼中唯一）
        .def(py::init<const String&>(),
             py::arg("name"),
             "构造函数：传入IK约束名称（骨骼中唯一标识）")

        // 核心属性：受约束的骨骼列表
        .def("get_bones", &IkConstraintData::getBones,
             "获取受该IK约束控制的骨骼数据列表（Vector<BoneData*>）",
             py::return_value_policy::reference_internal)  // 内部容器，不转移所有权

        // 目标骨骼操作（IK约束的目标）
        .def("get_target", &IkConstraintData::getTarget,
             "获取IK约束的目标骨骼数据（BoneData）",
             py::return_value_policy::reference)  // 目标骨骼由外部管理，仅返回引用
        .def("set_target", &IkConstraintData::setTarget,
             py::arg("target_bone_data"),
             "设置IK约束的目标骨骼数据（BoneData）")

        // 弯曲方向（1 或 -1，控制IK骨骼的弯曲朝向）
        .def("get_bend_direction", &IkConstraintData::getBendDirection,
             "获取IK骨骼的弯曲方向（1 或 -1）")
        .def("set_bend_direction", &IkConstraintData::setBendDirection,
             py::arg("direction"),
             "设置IK骨骼的弯曲方向（仅支持 1 或 -1）")

        // 压缩/拉伸/均匀缩放开关
        .def("get_compress", &IkConstraintData::getCompress,
             "判断是否允许IK骨骼压缩（true=允许，false=禁止）")
        .def("set_compress", &IkConstraintData::setCompress,
             py::arg("enable"),
             "设置是否允许IK骨骼压缩（true=允许，false=禁止）")
        .def("get_stretch", &IkConstraintData::getStretch,
             "判断是否允许IK骨骼拉伸（true=允许，false=禁止）")
        .def("set_stretch", &IkConstraintData::setStretch,
             py::arg("enable"),
             "设置是否允许IK骨骼拉伸（true=允许，false=禁止）")
        .def("get_uniform", &IkConstraintData::getUniform,
             "判断IK骨骼拉伸/压缩时是否保持均匀缩放（true=均匀，false=非均匀）")
        .def("set_uniform", &IkConstraintData::setUniform,
             py::arg("enable"),
             "设置IK骨骼拉伸/压缩时是否保持均匀缩放（true=均匀，false=非均匀）")

        // 混合系数与柔和度
        .def("get_mix", &IkConstraintData::getMix,
             "获取IK约束的混合系数（0-1，值越大约束影响越强）")
        .def("set_mix", &IkConstraintData::setMix,
             py::arg("mix"),
             "设置IK约束的混合系数（0-1，建议范围）")
        .def("get_softness", &IkConstraintData::getSoftness,
             "获取IK约束的柔和度（值越大，IK效果越柔和）")
        .def("set_softness", &IkConstraintData::setSoftness,
             py::arg("softness"),
             "设置IK约束的柔和度（值越大效果越柔和）")

        // 调试字符串（便于Python中查看实例信息）
        .def("__repr__", [](const IkConstraintData& self) {
            // 临时解除const限制（处理非const成员函数）
            IkConstraintData& non_const_self = const_cast<IkConstraintData&>(self);
            // 获取目标骨骼名称（若存在）
            const char* target_name = non_const_self.getTarget()
                ? non_const_self.getTarget()->getName().buffer()
                : "null";
            return py::str("IkConstraintData(name='{}', target='{}', bones_count={}, bend_dir={})")
                .format(
                    non_const_self.getName().buffer(),  // 从基类ConstraintData继承的名称
                    target_name,
                    non_const_self.getBones().size(),    // 受约束骨骼数量
                    non_const_self.getBendDirection()    // 弯曲方向
                );
        });
}