// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/BlendMode.h>  // 假设包含该枚举的头文件

namespace py = pybind11;
using namespace spine;

void bind_blend_mode(py::module_& m) {
    // 绑定 BlendMode 枚举，不导出到模块顶层（避免命名污染）
    py::enum_<BlendMode>(m, "BlendMode")
        .value("NORMAL", BlendMode_Normal)       // 正常混合模式
        .value("ADDITIVE", BlendMode_Additive)   // 叠加混合模式
        .value("MULTIPLY", BlendMode_Multiply)   // 正片叠底混合模式
        .value("SCREEN", BlendMode_Screen);      // 滤色混合模式
        // 不调用 export_values()，避免枚举值泄漏到模块顶层
}