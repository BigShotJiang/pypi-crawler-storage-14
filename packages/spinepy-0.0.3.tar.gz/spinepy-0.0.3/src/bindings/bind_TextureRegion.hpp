// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include "spine/TextureRegion.h"

namespace py = pybind11;
using namespace spine;

void bind_texture_region(py::module_& m) {
    py::class_<TextureRegion, SpineObject>(m, "TextureRegion")
        .def(py::init<>(), "Default constructor for TextureRegion")
        // .def_readwrite("rendererObject", &TextureRegion::rendererObject, 
        //               "Renderer-specific object (e.g., texture handle)")
        .def_property(
            "rendererObject",
            // getter：将 void* 转换为 uint64_t 整数（返回给 Python）
            [](const TextureRegion& self) -> uint64_t {
                // 转换 void* 指针为 64 位整数（适配 64 位系统，确保地址不被截断）
                return reinterpret_cast<uint64_t>(self.rendererObject);
            },
            // setter：将 Python 传入的整数转换为 void*
            [](TextureRegion& self, uint64_t obj_id) {
                // 将整数转换回 void* 指针
                self.rendererObject = reinterpret_cast<void*>(obj_id);
            },
            "Renderer-specific object (e.g., texture handle) as integer ID"
        )
        .def_readwrite("u", &TextureRegion::u, "Texture coordinate U (left)")
        .def_readwrite("v", &TextureRegion::v, "Texture coordinate V (bottom)")
        .def_readwrite("u2", &TextureRegion::u2, "Texture coordinate U2 (right)")
        .def_readwrite("v2", &TextureRegion::v2, "Texture coordinate V2 (top)")
        .def_readwrite("degrees", &TextureRegion::degrees, "Rotation in degrees (0, 90, 180, 270)")
        .def_readwrite("offsetX", &TextureRegion::offsetX, "X offset of the region in the original image")
        .def_readwrite("offsetY", &TextureRegion::offsetY, "Y offset of the region in the original image")
        .def_readwrite("width", &TextureRegion::width, "Width of the region")
        .def_readwrite("height", &TextureRegion::height, "Height of the region")
        .def_readwrite("originalWidth", &TextureRegion::originalWidth, "Original width of the image containing the region")
        .def_readwrite("originalHeight", &TextureRegion::originalHeight, "Original height of the image containing the region");
}