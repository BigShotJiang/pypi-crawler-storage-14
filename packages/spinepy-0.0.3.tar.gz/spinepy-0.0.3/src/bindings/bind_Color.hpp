// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Color.h>

namespace py = pybind11;
using namespace spine;

void bind_color(py::module_& m) {
    py::class_<Color, SpineObject>(m, "Color")
        // 构造函数
        .def(py::init<>(), "默认构造函数（黑色透明）")
        .def(py::init<float, float, float, float>(),
             py::arg("r") = 0.0f, py::arg("g") = 0.0f, py::arg("b") = 0.0f, py::arg("a") = 1.0f,
             "通过 RGBA 分量构造（值范围 0-1）")

        // 成员变量（直接暴露，方便读写）
        .def_readwrite("r", &Color::r, "红色分量（0-1）")
        .def_readwrite("g", &Color::g, "绿色分量（0-1）")
        .def_readwrite("b", &Color::b, "蓝色分量（0-1）")
        .def_readwrite("a", &Color::a, "Alpha 分量（0-1）")

        // 方法绑定（处理重载）
        .def("set", py::overload_cast<float, float, float, float>(&Color::set),
             py::arg("r"), py::arg("g"), py::arg("b"), py::arg("a"),
             "设置 RGBA 分量并归一化")
        .def("set", py::overload_cast<float, float, float>(&Color::set),
             py::arg("r"), py::arg("g"), py::arg("b"),
             "设置 RGB 分量（Alpha 不变）并归一化")
        .def("set", py::overload_cast<const Color&>(&Color::set),
             py::arg("other"), "从另一个 Color 复制分量并归一化")

        .def("add", py::overload_cast<float, float, float, float>(&Color::add),
             py::arg("r"), py::arg("g"), py::arg("b"), py::arg("a"),
             "叠加 RGBA 分量并归一化")
        .def("add", py::overload_cast<float, float, float>(&Color::add),
             py::arg("r"), py::arg("g"), py::arg("b"),
             "叠加 RGB 分量（Alpha 不变）并归一化")
        .def("add", py::overload_cast<const Color&>(&Color::add),
             py::arg("other"), "与另一个 Color 叠加分量并归一化")

        .def("clamp", &Color::clamp, "将所有分量限制在 0-1 范围内")

        // Python 特殊方法
        .def("__repr__", [](const Color& c) {
            return py::str("Color(r={:.2f}, g={:.2f}, b={:.2f}, a={:.2f})")
                .format(c.r, c.g, c.b, c.a);
        }, "对象的调试字符串表示")

        // 支持通过 tuple 解包（如 r, g, b, a = color）
        .def("__iter__", [](const Color& c) {
            return py::make_iterator(&c.r, &c.a + 1);  // 迭代 r, g, b, a
        }, py::keep_alive<0, 1>())

        // 支持加法运算（color1 + color2）
        .def("__add__", [](const Color& a, const Color& b) {
            Color res(a);
            res.add(b);
            return res;
        }, py::arg("other"), "两个颜色叠加")

        // 支持赋值加法（color1 += color2）
        .def("__iadd__", [](Color& a, const Color& b) {
            a.add(b);
            return a;
        }, py::arg("other"), "当前颜色叠加另一个颜色");
}