// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/Animation.h"

namespace py = pybind11;
using namespace spine;

void bind_animation(py::module_& m) {
    py::class_<Animation, SpineObject>(m, "Animation")
        // 1. 构造函数
        .def(py::init<const String&, Vector<Timeline*>&, float>(), 
             py::arg("name"), py::arg("timelines"), py::arg("duration"),
             "构造函数\n"
             "- name：动画名称\n"
             "- timelines：时间线列表（Vector<Timeline*>）\n"
             "- duration：动画总时长（秒）")

        // 2. 核心应用方法（apply）
        .def("apply", &Animation::apply, 
             py::arg("skeleton"), py::arg("last_time"), py::arg("time"), 
             py::arg("loop"), 
             py::arg("events"), 
             py::arg("alpha"),
             py::arg("blend"),
             py::arg("direction"),
             "将动画应用到骨骼上\n"
             "- skeleton：目标Skeleton实例\n"
             "- last_time：上一帧时间（用于计算帧间差值）\n"
             "- time：当前动画时间（秒）\n"
             "- loop：是否循环播放（bool）\n"
             "- events：输出事件列表（可选，Vector<Event*>*，默认None）\n"
             "- alpha：动画混合权重（0~1，默认1.0）\n"
             "- blend：混合模式（MixBlend枚举，默认normal）\n"
             "- direction：混合方向（MixDirection枚举，默认mix）")

        // 3. 公共属性get/set
        .def("getName", &Animation::getName, py::return_value_policy::reference_internal,
             "获取动画名称（返回String引用，只读）")
        .def("getTimelines", &Animation::getTimelines, py::return_value_policy::reference_internal,
             "获取动画的时间线列表（返回Vector<Timeline*>&，可遍历访问各时间线）")
        .def("hasTimeline", &Animation::hasTimeline, py::arg("ids"),
             "检查是否包含指定属性ID的时间线\n"
             "- ids：属性ID列表（Vector<PropertyId>）\n"
             "- 返回：存在则为True，否则为False")
        .def("getDuration", &Animation::getDuration,
             "获取动画总时长（秒）")
        .def("setDuration", &Animation::setDuration, py::arg("inValue"),
             "设置动画总时长（秒）")

        // 4. 静态方法（search）
        .def_static("search", py::overload_cast<Vector<float>&, float>(&Animation::search),
                    py::arg("values"), py::arg("target"),
                    "静态方法：在值列表中搜索目标值的插入位置（步长为1）\n"
                    "- values：排序后的float列表\n"
                    "- target：待搜索的目标值\n"
                    "- 返回：目标值应插入的索引（保持列表有序）")
        .def_static("search", py::overload_cast<Vector<float>&, float, int>(&Animation::search),
                    py::arg("values"), py::arg("target"), py::arg("step"),
                    "静态方法：在值列表中搜索目标值的插入位置（指定步长）\n"
                    "- values：排序后的float列表\n"
                    "- target：待搜索的目标值\n"
                    "- step：搜索步长（如时间线关键帧的步长）\n"
                    "- 返回：目标值应插入的索引（保持列表有序）");
}