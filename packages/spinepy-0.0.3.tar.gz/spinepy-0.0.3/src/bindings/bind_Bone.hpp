// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/Bone.h"
#include "spine/BoneData.h"
#include "spine/Skeleton.h" 

namespace py = pybind11;
using namespace spine;

void bind_bone(py::module_ &m) {
    py::class_<Bone, Updatable>(m, "Bone")
        // 静态方法
        .def_static("set_y_down", &Bone::setYDown, "设置Y轴向下")
        .def_static("is_y_down", &Bone::isYDown, "判断Y轴是否向下")

        // 构造函数
        .def(py::init<BoneData &, Skeleton &, Bone *>(),
             py::arg("data"), py::arg("skeleton"), py::arg("parent") = nullptr)

        // 核心更新方法（修正：显式指定重载函数类型）
        .def("update", &Bone::update, "更新骨骼状态", py::arg("physics"))
        .def("update_world_transform", (void (Bone::*)())&Bone::updateWorldTransform, "更新世界变换（无参数版本）")  // 无参版本
        .def("update_world_transform_ex", 
             (void (Bone::*)(float, float, float, float, float, float, float))&Bone::updateWorldTransform,  // 显式指定带参数版本
             "使用指定的本地变换更新世界变换",
             py::arg("x"), py::arg("y"), py::arg("rotation"),
             py::arg("scale_x"), py::arg("scale_y"),
             py::arg("shear_x"), py::arg("shear_y"))
        .def("update_applied_transform", &Bone::updateAppliedTransform, 
             "从世界变换更新应用的变换")

        // 姿态相关
        .def("set_to_setup_pose", &Bone::setToSetupPose, "重置到初始姿态")

        // 坐标转换
        .def("world_to_local", [](Bone &self, float world_x, float world_y) {
            float local_x, local_y;
            self.worldToLocal(world_x, world_y, local_x, local_y);
            return py::make_tuple(local_x, local_y);
        }, "世界坐标转本地坐标", py::arg("world_x"), py::arg("world_y"))

        .def("local_to_world", [](Bone &self, float local_x, float local_y) {
            float world_x, world_y;
            self.localToWorld(local_x, local_y, world_x, world_y);
            return py::make_tuple(world_x, world_y);
        }, "本地坐标转世界坐标", py::arg("local_x"), py::arg("local_y"))

        // 旋转相关
        .def("rotate_world", &Bone::rotateWorld, "旋转世界变换", py::arg("degrees"))
        .def("world_to_local_rotation", &Bone::worldToLocalRotation, 
             "世界旋转转本地旋转", py::arg("world_rotation"))
        .def("local_to_world_rotation", &Bone::localToWorldRotation, 
             "本地旋转转世界旋转", py::arg("local_rotation"))

        // 属性访问器（本地变换）
        .def_property("x", &Bone::getX, &Bone::setX, "本地X坐标")
        .def_property("y", &Bone::getY, &Bone::setY, "本地Y坐标")
        .def_property("rotation", &Bone::getRotation, &Bone::setRotation, "本地旋转角度")
        .def_property("scale_x", &Bone::getScaleX, &Bone::setScaleX, "X轴缩放")
        .def_property("scale_y", &Bone::getScaleY, &Bone::setScaleY, "Y轴缩放")
        .def_property("shear_x", &Bone::getShearX, &Bone::setShearX, "X轴剪切")
        .def_property("shear_y", &Bone::getShearY, &Bone::setShearY, "Y轴剪切")

        // 属性访问器（应用的变换）
        .def_property("applied_rotation", &Bone::getAppliedRotation, &Bone::setAppliedRotation, "应用的旋转")
        .def_property("a_x", &Bone::getAX, &Bone::setAX, "应用的本地X坐标")
        .def_property("a_y", &Bone::getAY, &Bone::setAY, "应用的本地Y坐标")
        .def_property("a_scale_x", &Bone::getAScaleX, &Bone::setAScaleX, "应用的X轴缩放")
        .def_property("a_scale_y", &Bone::getAScaleY, &Bone::setAScaleY, "应用的Y轴缩放")

        // 属性访问器（世界变换矩阵）
        .def_property("a", &Bone::getA, &Bone::setA, "变换矩阵A分量")
        .def_property("b", &Bone::getB, &Bone::setB, "变换矩阵B分量")
        .def_property("c", &Bone::getC, &Bone::setC, "变换矩阵C分量")
        .def_property("d", &Bone::getD, &Bone::setD, "变换矩阵D分量")

        // 世界坐标和状态
        .def_property("world_x", &Bone::getWorldX, &Bone::setWorldX, "世界X坐标")
        .def_property("world_y", &Bone::getWorldY, &Bone::setWorldY, "世界Y坐标")
        .def_property("active", &Bone::isActive, &Bone::setActive, "是否激活")
        .def_property("inherit", &Bone::getInherit, &Bone::setInherit, "继承模式")

        // 其他常用属性
        .def("get_data", &Bone::getData, py::return_value_policy::reference, "获取骨骼数据")
        .def("get_skeleton", &Bone::getSkeleton, py::return_value_policy::reference, "获取所属骨骼动画")
        .def("get_parent", &Bone::getParent, py::return_value_policy::reference, "获取父骨骼")
        .def("get_children", &Bone::getChildren, py::return_value_policy::reference, "获取子骨骼列表")
        .def("get_world_rotation_x", &Bone::getWorldRotationX, "获取世界X轴旋转")
        .def("get_world_rotation_y", &Bone::getWorldRotationY, "获取世界Y轴旋转")
        .def("get_world_scale_x", &Bone::getWorldScaleX, "获取世界X轴缩放")
        .def("get_world_scale_y", &Bone::getWorldScaleY, "获取世界Y轴缩放");
}