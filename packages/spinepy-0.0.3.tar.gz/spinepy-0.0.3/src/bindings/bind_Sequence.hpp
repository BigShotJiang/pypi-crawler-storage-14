// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/Sequence.h"  // 假设包含原始类定义的头文件

namespace py = pybind11;
using namespace spine;

void bind_sequence(py::module_& m) {
    // 绑定SequenceMode枚举
    py::enum_<SequenceMode>(m, "SequenceMode")
        .value("hold", SequenceMode::hold)
        .value("once", SequenceMode::once)
        .value("loop", SequenceMode::loop)
        .value("pingpong", SequenceMode::pingpong)
        .value("onceReverse", SequenceMode::onceReverse)
        .value("loopReverse", SequenceMode::loopReverse)
        .value("pingpongReverse", SequenceMode::pingpongReverse);

    // 绑定Sequence类
    py::class_<Sequence, SpineObject>(m, "Sequence")
        .def(py::init<int>(), py::arg("count"), "构造函数，参数为序列数量")
        .def("__copy__", &Sequence::copy, "创建序列的副本")
        .def("apply", &Sequence::apply, py::arg("slot"), py::arg("attachment"), 
             "将序列应用到指定插槽和附件")
        .def("getPath", &Sequence::getPath, py::arg("basePath"), py::arg("index"), 
             "获取指定索引的路径，基于基础路径")
        .def("getId", &Sequence::getId, "返回序列ID")
        .def("setId", &Sequence::setId, py::arg("id"), "设置序列ID")
        .def("getStart", &Sequence::getStart, "返回起始索引")
        .def("setStart", &Sequence::setStart, py::arg("start"), "设置起始索引")
        .def("getDigits", &Sequence::getDigits, "返回数字位数")
        .def("setDigits", &Sequence::setDigits, py::arg("digits"), "设置数字位数")
        .def("getSetupIndex", &Sequence::getSetupIndex, "返回初始索引")
        .def("setSetupIndex", &Sequence::setSetupIndex, py::arg("setupIndex"), "设置初始索引")
        .def("getRegions", &Sequence::getRegions, py::return_value_policy::reference_internal, 
             "返回纹理区域的向量引用");
}