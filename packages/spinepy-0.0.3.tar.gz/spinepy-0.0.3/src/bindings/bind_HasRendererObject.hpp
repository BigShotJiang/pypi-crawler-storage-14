// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/HasRendererObject.h>  // 包含目标类声明

namespace py = pybind11;
using namespace spine;


void bind_has_renderer_object(py::module_& m) {
    // 如果只是为了让类型系统工作，可以这样简化
    py::class_<HasRendererObject> hasRendererObject(m, "HasRendererObject");
    // 只绑定必要的函数
    hasRendererObject
        .def("getRendererObject", &HasRendererObject::getRendererObject)
        .def("setRendererObject", &HasRendererObject::setRendererObject,
            py::arg("renderer_object"),
            py::arg("dispose"));
    // 在实际使用中，Python 代码不会直接创建这个类的实例
    // 它只是作为其他类的基类存在
}
