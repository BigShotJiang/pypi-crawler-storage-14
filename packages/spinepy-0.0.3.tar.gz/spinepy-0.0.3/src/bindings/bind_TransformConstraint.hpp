// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/TransformConstraint.h>

namespace py = pybind11;
using namespace spine;

void bind_transform_constraint(py::module_& m) {
    // 绑定变换约束类（继承自Updatable）
    py::class_<TransformConstraint, Updatable>(m, "TransformConstraint")
        // 1. 构造函数（通常由Skeleton内部创建，Python侧一般不直接实例化）
        .def(py::init<TransformConstraintData&, Skeleton&>(),
             py::arg("data"), py::arg("skeleton"),
             "构造函数：传入变换约束数据（TransformConstraintData）和骨骼容器（Skeleton）")

        // 2. 基类Updatable接口
        .def("update", &TransformConstraint::update,
             py::arg("physics"), "更新变换约束状态（参数为Physics枚举，控制物理更新逻辑）")
        .def("get_order", &TransformConstraint::getOrder,
             "获取约束更新顺序（用于Skeleton按顺序执行约束，返回int）")

        // 3. 关联数据与骨骼列表
        .def("get_data", &TransformConstraint::getData,
             "获取关联的变换约束数据（TransformConstraintData）",
             py::return_value_policy::reference)  // 数据由外部管理，返回引用
        .def("get_bones", &TransformConstraint::getBones,
             "获取受该变换约束控制的骨骼列表（Vector<Bone*>）",
             py::return_value_policy::reference_internal)  // 内部容器，不转移所有权

        // 4. 目标骨骼操作
        .def("get_target", &TransformConstraint::getTarget,
             "获取变换约束的目标骨骼（Bone）",
             py::return_value_policy::reference)  // 目标骨骼由外部管理
        .def("set_target", &TransformConstraint::setTarget,
             py::arg("target_bone"), "设置变换约束的目标骨骼（Bone）")

        // 5. 混合系数（控制约束对各变换属性的影响强度）
        .def("get_mix_rotate", &TransformConstraint::getMixRotate,
             "获取旋转属性的混合系数（0-1，值越大约束影响越强）")
        .def("set_mix_rotate", &TransformConstraint::setMixRotate,
             py::arg("mix"), "设置旋转属性的混合系数（0-1）")
        .def("get_mix_x", &TransformConstraint::getMixX,
             "获取X轴位置的混合系数（0-1）")
        .def("set_mix_x", &TransformConstraint::setMixX,
             py::arg("mix"), "设置X轴位置的混合系数（0-1）")
        .def("get_mix_y", &TransformConstraint::getMixY,
             "获取Y轴位置的混合系数（0-1）")
        .def("set_mix_y", &TransformConstraint::setMixY,
             py::arg("mix"), "设置Y轴位置的混合系数（0-1）")
        .def("get_mix_scale_x", &TransformConstraint::getMixScaleX,
             "获取X轴缩放的混合系数（0-1）")
        .def("set_mix_scale_x", &TransformConstraint::setMixScaleX,
             py::arg("mix"), "设置X轴缩放的混合系数（0-1）")
        .def("get_mix_scale_y", &TransformConstraint::getMixScaleY,
             "获取Y轴缩放的混合系数（0-1）")
        .def("set_mix_scale_y", &TransformConstraint::setMixScaleY,
             py::arg("mix"), "设置Y轴缩放的混合系数（0-1）")
        .def("get_mix_shear_y", &TransformConstraint::getMixShearY,
             "获取Y轴剪切的混合系数（0-1）")
        .def("set_mix_shear_y", &TransformConstraint::setMixShearY,
             py::arg("mix"), "设置Y轴剪切的混合系数（0-1）")

        // 6. 激活状态与初始姿态
        .def("is_active", &TransformConstraint::isActive,
             "判断变换约束是否处于激活状态（true=生效，false=失效）")
        .def("set_active", &TransformConstraint::setActive,
             py::arg("enable"), "设置变换约束是否激活")
        .def("set_to_setup_pose", &TransformConstraint::setToSetupPose,
             "将变换约束参数重置为初始姿态（恢复到SkeletonData定义的默认值）")

        // 7. 调试字符串（便于Python侧查看实例信息）
        .def("__repr__", [](const TransformConstraint& self) {
            // 临时解除const限制（处理非const成员函数）
            TransformConstraint& non_const_self = const_cast<TransformConstraint&>(self);
            // 获取目标骨骼名称（若存在）

            return py::str("TransformConstraint(data='{}', bones_count={}, active={})")
                .format(
                    non_const_self.getData().getName().buffer(),  // 约束数据名称
                    non_const_self.getBones().size(),             // 受约束骨骼数量
                    non_const_self.isActive()                     // 激活状态
                );
        });
}