// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/EventData.h>

namespace py = pybind11;
using namespace spine;

void bind_event_data(py::module_& m) {
    py::class_<EventData, SpineObject>(m, "EventData")
        // 构造函数（接收事件名称）
        .def(py::init<const String&>(),
             py::arg("name"),
             "构造函数：传入事件名称（骨骼中唯一）")

        // 名称（只读，由构造函数初始化）
        .def("get_name", &EventData::getName,
             "获取事件名称（骨骼中唯一）",
             py::return_value_policy::reference_internal)  // 返回内部字符串引用

        // 整数类型值
        .def("get_int_value", &EventData::getIntValue,
             "获取整数类型值")
        .def("set_int_value", &EventData::setIntValue,
             py::arg("value"), "设置整数类型值")

        // 浮点类型值
        .def("get_float_value", &EventData::getFloatValue,
             "获取浮点类型值")
        .def("set_float_value", &EventData::setFloatValue,
             py::arg("value"), "设置浮点类型值")

        // 字符串类型值
        .def("get_string_value", &EventData::getStringValue,
             "获取字符串类型值",
             py::return_value_policy::reference_internal)
        .def("set_string_value", &EventData::setStringValue,
             py::arg("value"), "设置字符串类型值")

        // 音频路径
        .def("get_audio_path", &EventData::getAudioPath,
             "获取音频文件路径",
             py::return_value_policy::reference_internal)
        .def("set_audio_path", &EventData::setAudioPath,
             py::arg("path"), "设置音频文件路径")

        // 音量
        .def("get_volume", &EventData::getVolume,
             "获取音量（0-1范围）")
        .def("set_volume", &EventData::setVolume,
             py::arg("volume"), "设置音量（0-1范围）")

        // 平衡（左右声道）
        .def("get_balance", &EventData::getBalance,
             "获取声道平衡（-1左到1右）")
        .def("set_balance", &EventData::setBalance,
             py::arg("balance"), "设置声道平衡（-1左到1右）")

        // 调试字符串表示
        .def("__repr__", [](const EventData& self) {
            return py::str("EventData(name='{}', int={}, float={:.2f})")
                .format(self.getName().buffer(), self.getIntValue(), self.getFloatValue());
        });
}