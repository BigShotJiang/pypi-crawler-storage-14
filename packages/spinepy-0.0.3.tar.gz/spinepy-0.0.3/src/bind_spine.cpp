// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>

#include "bind_SpineObject.hpp"
#include "bind_Color.hpp"
#include "bind_Vector.hpp"

#include "bind_Property.hpp"
#include "bind_MixBlend.hpp"
#include "bind_MixDirection.hpp"

#include "bind_Bone.hpp"
#include "bind_Updatable.hpp"
#include "bind_SpineString.hpp"
#include "bind_Vertices.hpp"
#include "bind_BoneData.hpp"

#include "bind_Atlas.hpp"
#include "bind_TextureLoader.hpp"
#include "bind_HasRendererObject.hpp"


#include "bind_SlotData.hpp"

#include "bind_EventData.hpp"
#include "bind_Event.hpp"

#include "bind_Physics.hpp"

#include "bind_ConstraintData.hpp"
#include "bind_PhysicsConstraintData.hpp"
#include "bind_PhysicsConstraint.hpp"
#include "bind_PathConstraintData.hpp"
#include "bind_Attachment.hpp"

#include "bind_BlendMode.hpp"
#include "bind_RotateMode.hpp"
#include "bind_PositionMode.hpp"
#include "bind_SpacingMode.hpp"

#include "bind_Skin.hpp"

#include "bind_IkConstraintData.hpp"
#include "bind_TransformConstraintData.hpp"

#include "bind_IkConstraint.hpp"
#include "bind_TransformConstraint.hpp"
#include "bind_PathConstraint.hpp"

#include "bind_Timeline.hpp"

#include "bind_SkeletonData.hpp"

#include "bind_SkeletonClipping.hpp"

#include "bind_Skeleton.hpp"

#include "bind_Slot.hpp"
#include "bind_TextureRegion.hpp"
#include "bind_Sequence.hpp"

#include "bind_VertexAttachment.hpp"
#include "bind_BoundingBoxAttachment.hpp"
#include "bind_PointAttachment.hpp"
#include "bind_ClippingAttachment.hpp"
#include "bind_PathAttachment.hpp"
#include "bind_RegionAttachment.hpp"
#include "bind_MeshAttachment.hpp"
#include "bind_AttachmentLoader.hpp"

#include "bind_Animation.hpp"
#include "bind_AnimationStateData.hpp"
#include "bind_AnimationState.hpp"

#include "bind_CurveTimeline.hpp"

#include "bind_SkeletonBinary.hpp"

#include "bind_SkeletonRenderer.hpp"

SpineExtension *spine::getDefaultExtension() {
	return new spine::DefaultSpineExtension();
}

namespace py = pybind11;

// int add(int i, int j) {
//     return i + j;
// }

PYBIND11_MODULE(spine, m) {
    // 可选：如果需要禁用 GIL（全局解释器锁），添加以下一行
    // m.attr("__gil_scoped_release") = py::bool_(true);
    // 或使用标记（二选一，根据 pybind11 版本）：
    // PYBIND11_MODULE(spine_module, m, py::mod_gil_not_used())  // 注意这里是宏的一部分，无逗号分隔

    m.doc() = "no doc!!!"; // 模块文档字符串
    // m.def("add", &add, "A function that adds two numbers");
    bind_mix_blend(m);
    bind_mix_direction(m);
    bind_property_enum(m);
    bind_physics_enum(m); // 绑定 Physics 枚举
    bind_blend_mode(m);
    bind_rotate_mode(m);
    bind_position_mode(m);
    bind_spacing_mode(m);
    bind_spine_string(m);
    
    bind_spine_vector(m);



    bind_has_renderer_object(m);//depends on SpineObject
    bind_spine_object(m);//! base Object
    bind_animation_state_all(m);
    bind_sequence(m);
    bind_slot(m);//depends on SpineObject
    bind_timeline(m);//depends on SpineObject
    bind_curve_timelines(m);//depends on Timeline

    bind_attachment(m);//!Attachment is abstract class, cannot be instantiated
    bind_vertex_attachment(m);//depends on Attachment
    bind_region_attachment(m);//depends on VertexAttachment
    bind_mesh_attachment(m);//depends on VertexAttachment
    bind_bounding_box_attachment(m);//depends on VertexAttachment
    bind_point_attachment(m);//depends on VertexAttachment
    bind_clipping_attachment(m);//depends on VertexAttachment
    bind_path_attachment(m);//depends on VertexAttachment
    bind_attachment_loader(m);

    bind_color(m);//!必须要放在spine_object后面
    bind_constraint_data(m);
    bind_ik_constraint_data(m);//depends on ConstraintData
    bind_transform_constraint_data(m);//depends on ConstraintData
    bind_physics_constraint_data(m);
    bind_event_data(m);
    bind_event(m);
    bind_texture_loader(m);
    bind_texture_region(m);
    bind_atlas(m);
    bind_animation(m);
    bind_animation_state_data(m);
    
    bind_slot_data(m);
    
    bind_bonedata(m);//depends on SpineObject
    bind_vertices(m);//depends on SpineObject

    bind_skeleton_data(m);//depends on SpineObject


    bind_updatable(m);//todo depends on SpineObject
    bind_path_constraint(m);//depends on Updatable
    bind_transform_constraint(m);//depends on Updatable
    bind_physics_constraint(m);//depends on Updatable
    bind_ik_constraint(m);//depends on Updatable
    bind_bone(m);//depends on Updatable
    
    bind_skin(m);
    bind_path_constraint_data(m);
    bind_skeleton_clipping(m);
    bind_skeleton(m);
    bind_skeleton_binary(m);

    bind_skeleton_renderer(m);


}