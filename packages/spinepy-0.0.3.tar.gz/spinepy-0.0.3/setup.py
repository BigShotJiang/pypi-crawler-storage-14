import os
import shutil
import platform
import subprocess
from pathlib import Path
from setuptools.command.install import install
from setuptools import setup  # 移除了 Extension 和 build_ext 的导入

# ========== 核心配置项（修复路径相关配置） ==========
TARGET_MODULE_NAME = "spinepy"  # 匹配编译产物的前缀
SRC_DIR = "src"  # 源码根目录（包含CMakeLists.txt）
BUILD_DIR = "build"
# 修正：CMake源码目录为 src 目录（因为CMakeLists.txt在src下）
CMAKE_SRC_DIR = Path(__file__).parent.absolute() / SRC_DIR
# 编译产物最终复制的目标目录（build/lib/spinepy）
COMPILED_CORE_DIR = Path(BUILD_DIR) / "lib" / TARGET_MODULE_NAME
# 目标系统全局变量，默认空，可手动指定：Windows/Linux/Darwin
TARGET_SYSTEM = ""  # 手动指定示例：TARGET_SYSTEM = "Linux"
# 产物匹配关键词（根据你的输出是spine开头）
PRODUCT_MATCH_KEY = "spine"
# ==================================================

def get_system_info() -> tuple:
    """获取系统类型、CMake生成器、产物后缀（保留平台参数核心）"""
    system = platform.system()
    if system == "Windows":
        # Windows自动适配CMake默认生成器（MinGW Makefiles/MSVC均可）
        return "Windows", None, ".pyd"
    elif system == "Linux":
        return "Linux", "Unix Makefiles", ".so"
    elif system == "Darwin":
        raise NotImplementedError("macOS暂未适配")
    else:
        raise OSError(f"不支持的系统：{system}")

def check_cmake() -> None:
    """检查CMake是否安装"""
    try:
        subprocess.run(
            ["cmake", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True
        )
        print("✅ CMake已安装")
    except (subprocess.CalledProcessError, FileNotFoundError):
        raise RuntimeError("❌ 未找到CMake，请先安装并添加到系统PATH")

def check_cmakelists() -> None:
    """检查 src 目录是否存在CMakeLists.txt（修复路径）"""
    cmake_file = CMAKE_SRC_DIR / "CMakeLists.txt"  # 现在指向src目录下的文件
    if not cmake_file.exists():
        raise RuntimeError(f"❌ 未找到CMakeLists.txt，路径：{cmake_file}\n请确认CMakeLists.txt在src目录下")
    print(f"✅ 找到CMakeLists.txt：{cmake_file}")

def get_pybind11_dir() -> str:
    """自动获取pybind11的CMake配置目录"""
    try:
        import pybind11
        cmake_dir = pybind11.get_cmake_dir()
        if not os.path.exists(cmake_dir):
            raise FileNotFoundError(f"pybind11 CMake目录不存在：{cmake_dir}")
        print(f"✅ 找到pybind11 CMake目录：{cmake_dir}")
        return cmake_dir
    except ImportError:
        raise ImportError("❌ 未安装pybind11，请执行：pip install pybind11")

def find_compiled_file(ext: str) -> Path:
    """
    优先搜索build根目录，兜底搜索整个build目录
    :param ext: 目标后缀（.pyd/.so）
    :return: 产物文件路径
    """
    build_root = Path(BUILD_DIR)
    print(f"📌 优先搜索产物目录：{build_root}")
    # 优先遍历build根目录下的文件
    if build_root.exists():
        for file in os.listdir(build_root):
            file_path = build_root / file
            # 匹配条件：后缀正确 + 包含产物关键词
            if file_path.is_file() and file.endswith(ext) and PRODUCT_MATCH_KEY in file.lower():
                print(f"✅ 找到编译产物：{file_path}")
                return file_path

    # 兜底搜索整个build目录（防止产物在子目录的情况）
    print(f"📌 根目录未找到产物，兜底搜索整个{BUILD_DIR}目录")
    for root, _, files in os.walk(BUILD_DIR):
        for file in files:
            if file.endswith(ext) and PRODUCT_MATCH_KEY in file.lower():
                file_path = Path(root) / file
                print(f"✅ 找到编译产物：{file_path}")
                return file_path

    raise FileNotFoundError(
        f"❌ 未找到符合规则的{ext}文件\n"
        f"优先搜索目录：{build_root}\n"
        f"兜底搜索目录：{BUILD_DIR}\n"
        f"匹配关键词：{PRODUCT_MATCH_KEY}\n"
        f"请检查CMake编译是否成功"
    )

def copy_compiled_file(ext: str) -> None:
    """将编译产物从build根目录复制到build/lib/spinepy"""
    compiled_file = find_compiled_file(ext)
    target_dir = COMPILED_CORE_DIR
    target_dir.mkdir(exist_ok=True, parents=True)
    target_file = target_dir / compiled_file.name
    # 执行复制（覆盖已存在的文件）
    shutil.copy2(compiled_file, target_file, follow_symlinks=True)
    print(f"✅ 产物已复制到打包目录：{target_file}")

def run_cmake(system: str, generator: str, pybind11_dir: str) -> None:
    """执行CMake配置和编译（使用修正后的src目录作为源码目录）"""
    build_path = Path(BUILD_DIR)
    build_path.mkdir(exist_ok=True)

    # CMake基础配置参数
    cmake_args = [
        "cmake",
        f"-Dpybind11_DIR={pybind11_dir}",
        f"-DCMAKE_BUILD_TYPE=Release",
        f"-DTARGET_SYSTEM={TARGET_SYSTEM}",
    ]

    # 非Windows系统指定生成器，Windows由CMake自动检测
    if generator:
        cmake_args.extend(["-G", generator])

    # 指定源码目录（修正为src目录）和构建目录
    cmake_args.extend([str(CMAKE_SRC_DIR), "-B", str(build_path)])

    # 执行CMake配置
    print(f"📌 执行CMake配置：{' '.join(cmake_args)}")
    try:
        result = subprocess.run(cmake_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        if result.stdout: print(f"CMake配置输出：{result.stdout.strip()}")
        if result.stderr: print(f"CMake配置警告：{result.stderr.strip()}")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"❌ CMake配置失败！\n错误：{e.stderr.strip()}\n输出：{e.stdout.strip()}") from e

    # 执行编译（-j4启用多线程编译）
    build_args = ["cmake", "--build", str(build_path), "--config", "Release", "-j4"]
    print(f"📌 执行编译：{' '.join(build_args)}")
    try:
        result = subprocess.run(build_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        if result.stdout: print(f"编译输出：{result.stdout.strip()}")
        if result.stderr: print(f"编译警告：{result.stderr.strip()}")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"❌ 编译失败！\n错误：{e.stderr.strip()}\n输出：{e.stdout.strip()}") from e

class CustomInstall(install):
    """自定义安装命令：若TARGET_SYSTEM为空则自动获取"""
    def run(self):
        global TARGET_SYSTEM  # 声明使用全局变量
        check_cmake()
        check_cmakelists()  # 现在会正确查找src目录下的CMakeLists.txt
        # 若TARGET_SYSTEM为空，调用get_system_info自动获取并赋值
        system, generator, ext = get_system_info()
        if not TARGET_SYSTEM:
            TARGET_SYSTEM = system
            print(f"📌 TARGET_SYSTEM未手动指定，自动获取为：{TARGET_SYSTEM}")
        else:
            print(f"📌 使用手动指定的TARGET_SYSTEM：{TARGET_SYSTEM}")
        pybind11_dir = get_pybind11_dir()
        run_cmake(system, generator, pybind11_dir)
        copy_compiled_file(ext)
        super().run()

# Setup打包配置（移除了 ext_modules 和 build_ext 相关配置）
setup(
    cmdclass={"install": CustomInstall},  # 只保留自定义的 install 命令
    zip_safe=False,  # 二进制产物必须设为False
)