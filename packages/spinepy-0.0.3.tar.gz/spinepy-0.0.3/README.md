# Spine Runtimes C++ Bindings for Python(Alpha)

## 重要协议声明
1. 本项目包含两部分代码：
   - **原始代码**：由 [GuYeying] 开发的 pybind11 绑定逻辑、Python 层渲染实现等，采用 MIT 协议（详见 LICENSE 文件）。
   - **第三方代码**：基于 spine-runtimes 的 C++ 代码，其版权和协议归属原作者（Esoteric Software），必须严格遵循 [spine-runtimes 官方协议](https://github.com/EsotericSoftware/spine-runtimes/blob/4.2/LICENSE 或 详见 LICENSE-SPINE 文件）)。

2. 使用本项目时，需同时遵守上述两部分协议。若违反任何协议，一切后果由使用者自行承担。

3. 再次强调：spine-runtimes 相关代码的使用权受其原始协议约束，本项目的 MIT 协议仅适用于开发者原创部分，不改变第三方代码的版权和许可条款。


## 项目说明
- **版本**：Alpha v0.01  
- **功能范围**：本版本功能对标 spine-runtimes 中的 `spine-glfw` 案例，仅保证该案例覆盖的核心功能可用，不确保其他模块的稳定性（可能存在未测试的兼容性问题）。  
- **核心特性**：OpenGL 渲染逻辑已完全迁移至 Python 层实现，开发者无需关心图形库选型、渲染流程适配或版本依赖问题，可直接在 Python 中灵活修改渲染逻辑。  


## 参与贡献
欢迎提交 Issues 反馈问题或 Star 支持项目！


---

# Spine Runtimes C++ Bindings for Python(Alpha)


## Important License Notice
1. This project consists of two parts of code:
   - **Original Code**: The pybind11 binding logic and Python-layer rendering implementation developed by [Your Name], which is licensed under the MIT License (see the LICENSE file for details).
   - **Third-Party Code**: The C++ code based on spine-runtimes, whose copyright and license belong to the original author (Esoteric Software). Users must strictly comply with the [official spine-runtimes license](https://github.com/EsotericSoftware/spine-runtimes/blob/4.2/LICENSE or see the LICENSE-SPINE file for details).

2. When using this project, users must comply with both of the above licenses. Any consequences arising from non-compliance with any license shall be borne by the user.

3. It is emphasized again that the right to use code related to spine-runtimes is governed by its original license. The MIT License of this project applies solely to the original code written by the developer and does not alter the copyright or licensing terms of third-party code.



## Project Description
- **Version**: Alpha v0.01  
- **Scope**: This version is functionally aligned with the `spine-glfw` example in spine-runtimes. It only guarantees the stability of core features covered by this example, and does not ensure compatibility with other modules (untested issues may exist).  
- **Core Feature**: OpenGL rendering logic is fully implemented in the Python layer. Developers do not need to worry about graphics library selection, rendering process adaptation, or version dependencies. Rendering logic can be flexibly modified directly in Python.  


## Contribution
Issues and Stars are welcome!
