#!/usr/bin/env python
# coding: utf-8

version_info = (0, 7, 17)
__version__ = ".".join(map(str, version_info))


if __name__ == "__main__":
    print(__version__)
