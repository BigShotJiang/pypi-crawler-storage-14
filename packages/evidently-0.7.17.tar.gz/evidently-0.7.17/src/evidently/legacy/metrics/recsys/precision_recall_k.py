import warnings
from typing import Dict
from typing import List
from typing import Optional

import numpy as np
import pandas as pd

from evidently.legacy.base_metric import InputData
from evidently.legacy.base_metric import Metric
from evidently.legacy.base_metric import MetricResult
from evidently.legacy.calculations.recommender_systems import get_curr_and_ref_df
from evidently.legacy.core import IncludeTags
from evidently.legacy.model.widget import BaseWidgetInfo
from evidently.legacy.options.base import AnyOptions
from evidently.legacy.renderers.base_renderer import MetricRenderer
from evidently.legacy.renderers.base_renderer import default_renderer


def safe_pd_column_expanding(df: pd.DataFrame):
    try:
        # Try the old way (works on older pandas)
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=".*axis=1.*", category=FutureWarning)
            return df.expanding(axis=1)  # type: ignore[arg-type]
    except TypeError:
        # pandas removed axis=1 -> use transpose trick
        return df.T.expanding()


class PrecisionRecallCalculationResult(MetricResult):
    class Config:
        type_alias = "evidently:metric_result:PrecisionRecallCalculationResult"
        pd_include = False
        field_tags = {"current": {IncludeTags.Current}, "reference": {IncludeTags.Reference}}

    current: Dict[str, list]
    reference: Optional[Dict[str, list]] = None


class PrecisionRecallCalculation(Metric[PrecisionRecallCalculationResult]):
    class Config:
        type_alias = "evidently:metric:PrecisionRecallCalculation"

    max_k: int
    min_rel_score: Optional[int]

    def __init__(self, max_k: int, min_rel_score: Optional[int] = None, options: AnyOptions = None) -> None:
        self.max_k = max_k
        self.min_rel_score = min_rel_score
        super().__init__(options=options)

    def get_precision_and_recall_dict(self, df, max_k):
        user_df = df.groupby("users").target.agg(["size", "sum"])
        user_df.columns = ["size", "all"]
        max_k = min(user_df["size"].max(), max_k)
        res = {}
        for k in range(1, max_k + 1):
            tp = df[df.preds <= k].groupby("users").target.agg(["sum", "last"])
            tp.columns = [f"tp_{k}", f"rel_{k}"]
            user_df = pd.concat([user_df, tp], axis=1).fillna(0)
            user_df[f"precision_{k}"] = user_df[f"tp_{k}"] / np.minimum(user_df["size"], k)
            user_df[f"recall_{k}"] = user_df[f"tp_{k}"] / user_df["all"]
        user_df.replace([np.inf, -np.inf, np.nan], 0, inplace=True)
        res["k"] = [k for k in range(1, max_k + 1)]
        res["precision_include_no_feedback"] = list(user_df[[f"precision_{k}" for k in range(1, k + 1)]].mean())
        res["precision"] = list(user_df.loc[user_df["all"] != 0, [f"precision_{k}" for k in range(1, k + 1)]].mean())
        res["map_include_no_feedback"] = list(
            safe_pd_column_expanding(
                user_df[[f"precision_{k}" for k in range(1, k + 1)]].multiply(
                    user_df[[f"rel_{k}" for k in range(1, k + 1)]].values
                )
            )
            .sum()
            .divide(user_df["all"], axis=0)
            .fillna(0)
            .mean()
        )
        res["map"] = list(
            safe_pd_column_expanding(
                user_df.loc[user_df["all"] != 0, [f"precision_{k}" for k in range(1, k + 1)]].multiply(
                    user_df.loc[user_df["all"] != 0, [f"rel_{k}" for k in range(1, k + 1)]].values
                )
            )
            .sum()
            .divide(user_df.loc[user_df["all"] != 0, "all"], axis=0)
            .fillna(0)
            .mean()
        )
        res["recall_include_no_feedback"] = list(user_df[[f"recall_{k}" for k in range(1, k + 1)]].mean())
        res["recall"] = list(user_df.loc[user_df["all"] != 0, [f"recall_{k}" for k in range(1, k + 1)]].mean())
        res["mar_include_no_feedback"] = list(
            safe_pd_column_expanding(
                user_df[[f"recall_{k}" for k in range(1, k + 1)]].multiply(
                    user_df[[f"rel_{k}" for k in range(1, k + 1)]].values
                )
            )
            .sum()
            .divide(user_df["all"], axis=0)
            .fillna(0)
            .mean()
        )
        res["mar"] = list(
            safe_pd_column_expanding(
                user_df.loc[user_df["all"] != 0, [f"recall_{k}" for k in range(1, k + 1)]].multiply(
                    user_df.loc[user_df["all"] != 0, [f"rel_{k}" for k in range(1, k + 1)]].values
                )
            )
            .sum()
            .divide(user_df.loc[user_df["all"] != 0, "all"], axis=0)
            .fillna(0)
            .mean()
        )
        return res

    def calculate(self, data: InputData) -> PrecisionRecallCalculationResult:
        curr, ref = get_curr_and_ref_df(data, self.min_rel_score, True, True)
        current = self.get_precision_and_recall_dict(curr, self.max_k)
        reference: Optional[dict] = None
        if ref is not None:
            reference = self.get_precision_and_recall_dict(ref, self.max_k)

        return PrecisionRecallCalculationResult(
            current=current,
            reference=reference,
        )


@default_renderer(wrap_type=PrecisionRecallCalculation)
class PrecisionTopKMetricRenderer(MetricRenderer):
    def render_html(self, obj: PrecisionRecallCalculation) -> List[BaseWidgetInfo]:
        return []
