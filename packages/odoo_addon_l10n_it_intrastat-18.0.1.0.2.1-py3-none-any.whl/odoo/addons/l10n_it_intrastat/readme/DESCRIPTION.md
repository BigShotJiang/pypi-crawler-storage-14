**Italiano**

Questo modulo si occupa della riclassificazione delle merci e dei
servizi che sono oggetto di transazioni comunitarie.

Il modulo precarica anche le tabelle necessarie alla compilazione della
dichiarazione: nomenclature combinate, sezioni doganali, natura delle
transazioni, modalità di trasporto.

Per la creazione delle dichiarazioni, degli elenchi riepilogativi e le
estrazioni da presentare all'Agenzia delle Dogane è necessario
installare il modulo l10n_it_intrastat_statement.
