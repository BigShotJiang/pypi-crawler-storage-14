#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""COmparing Continuous Optimisers (COCO) post-processing tool for comparing
two algorithms:

Contains routines for the comparison of two algorithms.

"""
