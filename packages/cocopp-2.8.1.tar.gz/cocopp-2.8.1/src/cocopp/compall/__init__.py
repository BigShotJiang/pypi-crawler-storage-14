#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""COmparing Continuous Optimisers (COCO) post-processing tool for comparing
multiple algorithms:

Contains routines for the comparison of multiple algorithms.

"""
