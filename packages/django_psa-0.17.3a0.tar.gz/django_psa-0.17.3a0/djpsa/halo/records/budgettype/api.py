from djpsa.halo.api import HaloAPIClient


class BudgetTypeAPI(HaloAPIClient):
    endpoint = 'BudgetType'
