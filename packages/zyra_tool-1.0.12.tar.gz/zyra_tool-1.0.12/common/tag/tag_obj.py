from common.commit.commit_obj import GITCommit

class GITTag(GITCommit):
    obj_type = b'tag'
