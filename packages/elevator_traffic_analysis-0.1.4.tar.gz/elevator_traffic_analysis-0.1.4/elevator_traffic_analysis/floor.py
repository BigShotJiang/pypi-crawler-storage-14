from __future__ import annotations

from functools import total_ordering
from typing import List, Dict, Any

from .passenger import Passenger

@total_ordering
class Floor:
    def __init__(self, floor_id: str) -> None:
        self.floor_id: str = floor_id
        self.waiting_passengers: List[Passenger] = []
        self.dismbarked_passengers: List[Passenger] = []

    def __lt__(self, other: Floor) -> bool:
        return int(self) < int(other)

    def __eq__(self, other: Floor) -> bool:
        return int(self) == int(other)

    def __int__(self) -> int:
        return int(self.floor_id.split('__')[1])

    def __repr__(self) -> str:
        return f"Floor(id={self.floor_id}, waiting_passengers={len(self.waiting_passengers)})"

    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': 'Floor',
            'id': self.floor_id,
            'waiting_passengers_count': len(self.waiting_passengers),
            'waiting_passengers': [p.to_dict() for p in self.waiting_passengers],
            'dismbarked_passengers_count': len(self.dismbarked_passengers),
            'dismbarked_passengers': [p.to_dict() for p in self.dismbarked_passengers]
        }

    def add_waiting_passenger(self, passenger: Passenger) -> None:
        self.waiting_passengers.append(passenger)

    def remove_waiting_passenger(self, passenger: Passenger) -> None:
        self.waiting_passengers.remove(passenger)

    def add_dismbarked_passenger(self, passenger: Passenger) -> None:
        self.dismbarked_passengers.append(passenger)

    def create_passenger(self, passenger_id: str, destination_floor: Floor, tick_appeared: int) -> Passenger:
        passenger = Passenger(
            passenger_id=passenger_id,
            origin_floor=self,
            destination_floor=destination_floor,
            tick_appeared=tick_appeared
        )
        self.add_waiting_passenger(passenger)
        return passenger
