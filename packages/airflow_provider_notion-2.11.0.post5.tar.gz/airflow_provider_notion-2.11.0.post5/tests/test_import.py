#!/usr/bin/env python
"""
Simple test script to verify Notion provider can be imported.
Run this from a different directory to avoid import conflicts.
"""

import sys

# Remove current directory from path to avoid local airflow/ conflict
if "" in sys.path:
    sys.path.remove("")
if "." in sys.path:
    sys.path.remove(".")

try:
    from airflow.providers.notion.hooks.notion import NotionHook

    print("✅ NotionHook imported successfully")

    from airflow.providers.notion.operators.notion import (
        NotionQueryDatabaseOperator,
        NotionCreatePageOperator,
        NotionUpdatePageOperator,
    )

    print("✅ All Notion operators imported successfully")

    from airflow.providers.notion.get_provider_info import get_provider_info

    provider_info = get_provider_info()
    print(
        f"✅ Provider info: {provider_info['package-name']} v{provider_info['versions'][0]}"
    )

    print("\n🎉 All imports successful! Provider is correctly installed.")

except ImportError as e:
    print(f"❌ Import failed: {e}")
    import traceback

    traceback.print_exc()
    sys.exit(1)
