"""
xml.dom unsafe functions
"""
from . import minidom, pulldom  # noqa: F401
