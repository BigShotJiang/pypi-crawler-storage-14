"""
xml unsafe functions
"""
from . import dom, etree, sax  # noqa: F401
