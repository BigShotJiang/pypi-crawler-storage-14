class EmptyNamespace(Exception):
    pass


class IllegalAsteriskNamespace(Exception):
    pass
