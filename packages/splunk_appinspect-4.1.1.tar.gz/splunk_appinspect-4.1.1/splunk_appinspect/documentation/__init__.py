"""
Splunk AppInspect documentation metadata generator module
"""

from . import criteria_generator, tag_reference_generator  # noqa: F401
from .splunk_docs import DocumentationLinks  # noqa: F401
