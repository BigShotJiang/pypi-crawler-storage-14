import typing

import json5

from prefer.formatters import formatter


class JSONFormatter(formatter.Formatter):
    @staticmethod
    def extensions() -> set[str]:
        return {".json", ".json5"}

    async def serialize(self, source: dict[str, typing.Any]) -> str:
        result: str = json5.dumps(source, quote_keys=True)
        return result

    async def deserialize(self, source: str) -> dict[str, typing.Any]:
        result: dict[str, typing.Any] = json5.loads(source)
        return result
