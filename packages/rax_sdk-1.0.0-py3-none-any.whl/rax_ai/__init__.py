"""
Rax AI Python SDK

Official Python client for the Rax AI Platform.
"""

from .client import RaxAI, RaxAIError
from .types import ChatMessage, ChatRequest, ChatResponse, Model, UsageStats

# Optional async client
try:
    from .async_client import AsyncRaxAI
    __all__ = [
        "RaxAI",
        "AsyncRaxAI",
        "RaxAIError", 
        "ChatMessage",
        "ChatRequest",
        "ChatResponse",
        "Model",
        "UsageStats",
    ]
except ImportError:
    # aiohttp not available
    __all__ = [
        "RaxAI",
        "RaxAIError", 
        "ChatMessage",
        "ChatRequest",
        "ChatResponse",
        "Model",
        "UsageStats",
    ]

__version__ = "1.0.0"
