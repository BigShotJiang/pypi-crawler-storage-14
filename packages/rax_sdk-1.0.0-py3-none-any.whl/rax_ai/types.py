"""Type definitions for Rax AI SDK."""

from typing import Dict, List, Optional, Union, Any
try:
    from typing import TypedDict
except ImportError:
    # Python < 3.8 compatibility
    from typing_extensions import TypedDict


class ChatMessage(TypedDict):
    """A chat message."""
    role: str  # 'system', 'user', or 'assistant'
    content: str


class ChatRequest(TypedDict, total=False):
    """Request for chat completion."""
    model: str
    messages: List[ChatMessage]
    max_tokens: Optional[int]
    temperature: Optional[float]
    top_p: Optional[float]
    stream: Optional[bool]
    user: Optional[str]


class Usage(TypedDict):
    """Token usage information."""
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class Choice(TypedDict):
    """A chat completion choice."""
    index: int
    message: ChatMessage
    finish_reason: str


class ChatResponse(TypedDict):
    """Response from chat completion."""
    id: str
    object: str
    created: int
    model: str
    choices: List[Choice]
    usage: Usage


class Model(TypedDict, total=False):
    """AI model information."""
    id: str
    name: str
    description: Optional[str]
    context_length: Optional[int]


class DailyUsage(TypedDict):
    """Daily usage breakdown."""
    date: str
    requests: int
    tokens: int
    cost: float


class UsageStats(TypedDict, total=False):
    """Usage statistics."""
    total_requests: int
    total_tokens: int
    total_cost: float
    period: Dict[str, str]
    daily_breakdown: Optional[List[DailyUsage]]


class ErrorDetail(TypedDict):
    """Error detail structure."""
    message: str
    type: str
    code: Optional[str]


class APIError(TypedDict):
    """API error response."""
    error: ErrorDetail
