# `light-curve-python`

`light-curve-python` had been a previous name of the [`light-curve`](https://github.com/light-curve/light-curve-python) package.
Now this is an empty package which depends on `light-curve` only.
