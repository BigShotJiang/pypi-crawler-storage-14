class MudraDevice:
    def __init__(self, a: int, b: int):
        self.a = a
        self.b = b

    def sum_parameters(self) -> int:
        return self.a + self.b

