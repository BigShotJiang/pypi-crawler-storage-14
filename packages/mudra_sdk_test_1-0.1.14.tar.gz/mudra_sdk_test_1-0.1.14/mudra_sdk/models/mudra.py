from ..libs.library_loader import load_library
from ctypes import CDLL
from typing import Optional


class Mudra:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        # Initialize your singleton state here if needed
        self._native_lib: Optional[CDLL] = None
        self._load_native_library()

    def _load_native_library(self):
        """
        Load the native library for the current platform.
        This will automatically detect the platform and load the correct .dll/.so/.dylib
        """
        try:
            self._native_lib = load_library('MudraSDK', 'MudraSDK')
            print(f"Native library loaded: {self._native_lib}")
        except (FileNotFoundError, OSError) as e:
            # Handle the case where the library is not found or cannot be loaded
            print(f"Warning: Could not load native library: {e}")
            self._native_lib = None

    @property
    def native_lib(self) -> Optional[CDLL]:
        """Get the loaded native library, or None if not loaded."""
        return self._native_lib

