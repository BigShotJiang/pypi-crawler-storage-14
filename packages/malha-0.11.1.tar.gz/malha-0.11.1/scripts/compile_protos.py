#!/usr/bin/env python3
"""
Compile Protocol Buffer Definitions
====================================

This script compiles the .proto files into Python code using grpc_tools.

Usage:
    python scripts/compile_protos.py
    
Requirements:
    pip install grpcio-tools
"""

import subprocess
import sys
from pathlib import Path


def compile_protos():
    """Compile all .proto files in the malha/protos directory."""
    
    # Get project root
    project_root = Path(__file__).parent.parent
    proto_dir = project_root / "malha" / "protos"
    
    if not proto_dir.exists():
        print(f"Error: Proto directory not found: {proto_dir}")
        sys.exit(1)
    
    # Find all .proto files
    proto_files = list(proto_dir.glob("*.proto"))
    
    if not proto_files:
        print(f"No .proto files found in {proto_dir}")
        sys.exit(1)
    
    print(f"Found {len(proto_files)} proto file(s):")
    for proto_file in proto_files:
        print(f"  - {proto_file.name}")
    
    # Compile each proto file
    for proto_file in proto_files:
        print(f"\nCompiling {proto_file.name}...")
        
        cmd = [
            sys.executable,
            "-m", "grpc_tools.protoc",
            f"-I{project_root}",
            f"--python_out={project_root}",
            f"--grpc_python_out={project_root}",
            str(proto_file.relative_to(project_root))
        ]
        
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            print(f"✓ Successfully compiled {proto_file.name}")
            
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(result.stderr)
        
        except subprocess.CalledProcessError as e:
            print(f"✗ Error compiling {proto_file.name}:")
            print(e.stderr)
            sys.exit(1)
        except FileNotFoundError:
            print("Error: grpc_tools not found. Install with: pip install grpcio-tools")
            sys.exit(1)
    
    print("\n✓ All proto files compiled successfully!")
    print("\nGenerated files:")
    for proto_file in proto_files:
        base_name = proto_file.stem
        print(f"  - malha/protos/{base_name}_pb2.py")
        print(f"  - malha/protos/{base_name}_pb2_grpc.py")


if __name__ == "__main__":
    compile_protos()
