"""
Test Suite: Synapse P2P Replication - Comprehensive gRPC Mocking
================================================================

State-of-the-art testing for the Synapse distributed replication driver.
"""

import asyncio
import json
import shutil
import tempfile
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from registro import DomainResource, register

from malha import connect

# ============================================================================
# Test Domain Resource
# ============================================================================

class SynapseTestUser(DomainResource):
    name: str
    email: str = "test@example.com"

register("SynapseTestUser", SynapseTestUser)


# ============================================================================
# Mock Classes
# ============================================================================

class MockServicerContext:
    def __init__(self, peer_name="ipv4:127.0.0.1:50052"):
        self._peer = peer_name
    def peer(self): return self._peer


class MockReplicationEvent:
    DATA, ERROR_REPORT, COMPENSATION = 0, 1, 2
    def __init__(self, transaction_id="tx-123", origin_node_id="node-1",
                 resource_rid="ri.test.prod.user.123", operation="UPSERT",
                 payload=b'{"name": "Test"}', event_type=0, reply_to_node="", **kwargs):
        self.transaction_id = transaction_id
        self.origin_node_id = origin_node_id
        self.resource_rid = resource_rid
        self.operation = operation
        self.payload = payload
        self.timestamp = kwargs.get("timestamp", int(datetime.now(UTC).timestamp() * 1e6))
        self.schema_version = kwargs.get("schema_version", 1)
        self.event_type = event_type
        self.reply_to_node = reply_to_node


class MockAck:
    def __init__(self, transaction_id="tx-123", success=True, node_id="node-1", error_message="", **kwargs):
        self.transaction_id, self.success = transaction_id, success
        self.node_id, self.error_message = node_id, error_message


class MockHealthResponse:
    def __init__(self, node_id="node-1", status="HEALTHY", **kwargs):
        self.node_id, self.status = node_id, status
        self.timestamp = kwargs.get("timestamp", int(datetime.now(UTC).timestamp() * 1e6))
        self.active_connections = kwargs.get("active_connections", 0)


class MockGrpcServer:
    def __init__(self): self._started = False
    def add_insecure_port(self, addr): return 50051
    async def start(self): self._started = True
    async def stop(self, grace=0): pass


class MockGrpcStub:
    def __init__(self, channel=None):
        self._should_fail = False
        self._fail_error = None
    def set_failure(self, error):
        self._should_fail, self._fail_error = True, error
    async def ReplicateStream(self, request_iterator):
        if self._should_fail: raise self._fail_error
        async for event in request_iterator:
            yield MockAck(transaction_id=event.transaction_id, success=True)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def temp_dir():
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
def mock_pb2():
    mock = MagicMock()
    mock.ReplicationEvent = MockReplicationEvent
    mock.ReplicationEvent.DATA, mock.ReplicationEvent.ERROR_REPORT = 0, 1
    mock.ReplicationEvent.COMPENSATION = 2
    mock.Ack, mock.HealthResponse = MockAck, MockHealthResponse
    return mock


@pytest.fixture
def mock_pb2_grpc():
    mock = MagicMock()
    mock.SynapseMeshServicer = object
    mock.SynapseMeshStub = MockGrpcStub
    mock.add_SynapseMeshServicer_to_server = MagicMock()
    return mock


# ============================================================================
# Tests: SynapseServicer
# ============================================================================

class TestSynapseServicer:
    @pytest.mark.asyncio
    async def test_servicer_init(self):
        from malha.drivers.synapse import SynapseServicer
        servicer = SynapseServicer(MagicMock(), "test-node")
        assert servicer.node_id == "test-node"

    @pytest.mark.asyncio
    async def test_servicer_deduplication_cache(self):
        from malha.drivers.synapse import SynapseServicer
        servicer = SynapseServicer(MagicMock(), "test-node")
        for i in range(15000):
            servicer._processed_transactions.add(f"tx-{i}")
        assert len(servicer._processed_transactions) <= servicer._cache_max_size + 5000

    @pytest.mark.asyncio
    async def test_servicer_health_check(self, mock_pb2):
        from malha.drivers.synapse import SynapseServicer
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            servicer = SynapseServicer(MagicMock(), "test-node")
            resp = await servicer.HealthCheck(MagicMock(), MagicMock())
            assert resp.status == "HEALTHY"

    @pytest.mark.asyncio
    async def test_servicer_upsert_event(self, temp_dir, mock_pb2):
        from malha.drivers.synapse import SynapseServicer
        kernel = await connect(
            url=f"sqlite+aiosqlite:///{temp_dir}/test.db",
            kuzu_path=f"{temp_dir}/graph", enable_monitoring=False,
        )
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            servicer = SynapseServicer(kernel, "test-node")
            event = MockReplicationEvent(
                payload=json.dumps({"name": "Test", "type": "SynapseTestUser"}).encode(),
            )
            async def stream(): yield event
            acks = [a async for a in servicer.ReplicateStream(stream(), MockServicerContext())]
            assert acks[0].success
        await kernel.close()

    @pytest.mark.asyncio
    async def test_servicer_backpressure(self, temp_dir, mock_pb2):
        from malha.drivers.synapse import SynapseServicer
        kernel = await connect(
            url=f"sqlite+aiosqlite:///{temp_dir}/test.db",
            kuzu_path=f"{temp_dir}/graph", enable_monitoring=False,
        )
        kernel.graph_driver.qsize = MagicMock(return_value=2000)
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            servicer = SynapseServicer(kernel, "test-node")
            async def stream(): yield MockReplicationEvent()
            acks = [a async for a in servicer.ReplicateStream(stream(), MockServicerContext())]
            assert not acks[0].success
            assert "BACKPRESSURE" in acks[0].error_message
        await kernel.close()

    @pytest.mark.asyncio
    async def test_servicer_error_report(self, temp_dir, mock_pb2):
        from malha.drivers.synapse import SynapseServicer
        kernel = await connect(
            url=f"sqlite+aiosqlite:///{temp_dir}/test.db",
            kuzu_path=f"{temp_dir}/graph", enable_monitoring=False,
        )
        kernel._saga_error_handlers = [AsyncMock()]
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            servicer = SynapseServicer(kernel, "test-node")
            event = MockReplicationEvent(event_type=1, payload=b'{"reason": "error"}')
            await servicer._apply_remote_event(event)
            kernel._saga_error_handlers[0].assert_called_once()
        await kernel.close()

    @pytest.mark.asyncio
    async def test_servicer_compensation(self, temp_dir, mock_pb2):
        from malha.drivers.synapse import SynapseServicer
        kernel = await connect(
            url=f"sqlite+aiosqlite:///{temp_dir}/test.db",
            kuzu_path=f"{temp_dir}/graph", enable_monitoring=False,
        )
        kernel._saga_compensation_handlers = [AsyncMock()]
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            servicer = SynapseServicer(kernel, "test-node")
            event = MockReplicationEvent(event_type=2, payload=b'{"rollback": true}')
            await servicer._apply_remote_event(event)
            kernel._saga_compensation_handlers[0].assert_called_once()
        await kernel.close()


# ============================================================================
# Tests: SynapseDriver
# ============================================================================

class TestSynapseDriverComprehensive:
    @pytest.mark.asyncio
    async def test_driver_init(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50099, ["p1:50051", "p2:50051"])
        assert driver.node_id == "node-1"
        assert len(driver.all_peers) == 2

    @pytest.mark.asyncio
    async def test_driver_start_stop(self, mock_pb2, mock_pb2_grpc):
        from malha.drivers.synapse import SynapseDriver
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            with patch("malha.drivers.synapse.synapse_pb2_grpc", mock_pb2_grpc):
                with patch("malha.drivers.synapse.grpc.aio.server", return_value=MockGrpcServer()):
                    driver = SynapseDriver(MagicMock(), "node-1", 50100, [])
                    await driver.start()
                    assert driver._running
                    await driver.stop()
                    assert not driver._running

    @pytest.mark.asyncio
    async def test_driver_no_protos(self):
        from malha.drivers.synapse import SynapseDriver
        with patch("malha.drivers.synapse.synapse_pb2", None):
            driver = SynapseDriver(MagicMock(), "node-1", 50101)
            await driver.start()
            assert driver.server is None

    @pytest.mark.asyncio
    async def test_gossip_small_set(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50102, ["p1:50051", "p2:50051"], gossip_fanout=5)
        await driver._rotate_active_peers()
        assert len(driver.active_peers) == 2

    @pytest.mark.asyncio
    async def test_gossip_large_set(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50103, [f"p{i}:50051" for i in range(10)], gossip_fanout=3)
        await driver._rotate_active_peers()
        assert len(driver.active_peers) == 3

    @pytest.mark.asyncio
    async def test_broadcast_success(self, mock_pb2, mock_pb2_grpc):
        from malha.drivers.synapse import SynapseDriver
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            with patch("malha.drivers.synapse.synapse_pb2_grpc", mock_pb2_grpc):
                driver = SynapseDriver(MagicMock(), "node-1", 50104, ["peer:50051"])
                driver._running = True
                driver.active_peers = {"peer:50051"}
                driver._peer_stubs["peer:50051"] = MockGrpcStub()
                event = MagicMock(id=1, rid="ri.test.user.1", operation="UPSERT", payload="{}")
                await driver.broadcast(event)
                assert driver._peer_failures.get("peer:50051", 0) == 0

    @pytest.mark.asyncio
    async def test_broadcast_failure(self, mock_pb2, mock_pb2_grpc):
        from malha.drivers.synapse import SynapseDriver
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            with patch("malha.drivers.synapse.synapse_pb2_grpc", mock_pb2_grpc):
                driver = SynapseDriver(MagicMock(), "node-1", 50105, ["peer:50051"])
                driver._running = True
                driver.active_peers = {"peer:50051"}
                stub = MockGrpcStub()
                stub.set_failure(Exception("Network error"))
                driver._peer_stubs["peer:50051"] = stub
                event = MagicMock(id=1, rid="ri.test.user.1", operation="UPSERT", payload="{}")
                await driver.broadcast(event)
                assert driver._peer_failures.get("peer:50051", 0) >= 1


# ============================================================================
# Tests: Circuit Breaker
# ============================================================================

class TestCircuitBreakerComprehensive:
    @pytest.mark.asyncio
    async def test_circuit_closed_initially(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50106, ["peer:50051"])
        assert not driver._is_circuit_open("peer:50051")

    @pytest.mark.asyncio
    async def test_circuit_opens_on_failures(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50107, ["peer:50051"])
        for _ in range(driver._circuit_breaker_threshold):
            driver._record_failure("peer:50051")
        assert driver._is_circuit_open("peer:50051")

    @pytest.mark.asyncio
    async def test_circuit_closes_after_timeout(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50108, ["peer:50051"])
        for _ in range(driver._circuit_breaker_threshold):
            driver._record_failure("peer:50051")
        driver._peer_circuit_open["peer:50051"] = datetime.now(UTC) - timedelta(seconds=1)
        assert not driver._is_circuit_open("peer:50051")

    @pytest.mark.asyncio
    async def test_success_resets_failures(self):
        from malha.drivers.synapse import SynapseDriver
        driver = SynapseDriver(MagicMock(), "node-1", 50109, ["peer:50051"])
        driver._record_failure("peer:50051")
        driver._record_failure("peer:50051")
        driver._record_success("peer:50051")
        assert driver._peer_failures["peer:50051"] == 0


# ============================================================================
# Tests: Peer Rotation Loop
# ============================================================================

class TestPeerRotation:
    @pytest.mark.asyncio
    async def test_rotation_loop(self, mock_pb2, mock_pb2_grpc):
        from malha.drivers.synapse import SynapseDriver
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            with patch("malha.drivers.synapse.synapse_pb2_grpc", mock_pb2_grpc):
                driver = SynapseDriver(MagicMock(), "node-1", 50110,
                    [f"p{i}:50051" for i in range(5)], gossip_fanout=2, peer_rotation_interval=0.1)
                driver._running = True
                task = asyncio.create_task(driver._peer_rotation_loop())
                await asyncio.sleep(0.25)
                driver._running = False
                task.cancel()
                try: await task
                except asyncio.CancelledError: pass

    @pytest.mark.asyncio
    async def test_connect_to_peers(self, mock_pb2, mock_pb2_grpc):
        from malha.drivers.synapse import SynapseDriver
        with patch("malha.drivers.synapse.synapse_pb2", mock_pb2):
            with patch("malha.drivers.synapse.synapse_pb2_grpc", mock_pb2_grpc):
                with patch("malha.drivers.synapse.grpc.aio.insecure_channel"):
                    driver = SynapseDriver(MagicMock(), "node-1", 50111, ["peer:50051"])
                    driver.active_peers = {"peer:50051"}
                    await driver._connect_to_peers()
                    assert "peer:50051" in driver._peer_stubs
