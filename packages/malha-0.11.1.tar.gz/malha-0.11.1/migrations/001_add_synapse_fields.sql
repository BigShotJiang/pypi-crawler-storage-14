-- Migration: Add Synapse replication fields to sys_outbox
-- Version: 001
-- Date: 2024-11-24
-- Description: Adds origin_node, retries, and next_retry_at columns for distributed replication

-- SQLite syntax
ALTER TABLE sys_outbox ADD COLUMN origin_node TEXT DEFAULT 'local';
ALTER TABLE sys_outbox ADD COLUMN retries INTEGER DEFAULT 0;
ALTER TABLE sys_outbox ADD COLUMN next_retry_at TIMESTAMP NULL;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_outbox_origin_node ON sys_outbox(origin_node);
CREATE INDEX IF NOT EXISTS idx_outbox_retry_schedule ON sys_outbox(status, next_retry_at) 
    WHERE status = 'RETRY';

-- Update existing rows to have default values
UPDATE sys_outbox SET origin_node = 'local' WHERE origin_node IS NULL;
UPDATE sys_outbox SET retries = 0 WHERE retries IS NULL;

-- PostgreSQL syntax (alternative)
-- ALTER TABLE sys_outbox ADD COLUMN IF NOT EXISTS origin_node TEXT DEFAULT 'local';
-- ALTER TABLE sys_outbox ADD COLUMN IF NOT EXISTS retries INTEGER DEFAULT 0;
-- ALTER TABLE sys_outbox ADD COLUMN IF NOT EXISTS next_retry_at TIMESTAMP WITH TIME ZONE NULL;
-- CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_outbox_origin_node ON sys_outbox(origin_node);
-- CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_outbox_retry_schedule ON sys_outbox(status, next_retry_at) 
--     WHERE status = 'RETRY';
