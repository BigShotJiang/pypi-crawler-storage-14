"""
Malha Protocol Buffers Package
===============================

This package contains compiled protobuf definitions for Malha's network protocols.

To compile the proto files, run:
    python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. malha/protos/synapse.proto

Or use the provided script:
    python scripts/compile_protos.py
"""

__all__ = ["synapse_pb2", "synapse_pb2_grpc"]

try:
    from . import synapse_pb2, synapse_pb2_grpc
except ImportError:
    # Proto files not yet compiled
    synapse_pb2 = None
    synapse_pb2_grpc = None
