# refundengine

A small refund calculation library for ticketing systems.

## Example

```python
from refundengine import RefundCalculator

rc = RefundCalculator()
print(rc.calculate_refund(
    fare=25,
    hours_before_departure=5,
    is_student=True
))



