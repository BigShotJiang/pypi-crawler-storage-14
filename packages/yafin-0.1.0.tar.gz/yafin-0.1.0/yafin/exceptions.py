class TrailingBalanceSheetError(Exception):
    """Exception for using trailing frequency for balance sheet types."""

    pass
