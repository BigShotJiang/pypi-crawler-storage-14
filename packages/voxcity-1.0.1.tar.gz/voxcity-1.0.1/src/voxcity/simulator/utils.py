import numpy as np
import pandas as pd
from datetime import datetime

def dummy_function(test_string):
    return test_string