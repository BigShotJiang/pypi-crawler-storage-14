# StockAPIS Go Client

Simple, unified Go client for StockAPIS Trading Bot API.

## Installation

No installation needed - the client is part of the tradebot-py package structure.

## Quick Start

```go
package main

import (
    "context"
    "fmt"
    "log"

    stockapis "path/to/tradebot-py/packages/api/clients/go"
)

func main() {
    // Create client (reads from env vars by default)
    client, err := stockapis.NewClient(nil)
    if err != nil {
        log.Fatal(err)
    }
    defer client.Close()

    ctx := context.Background()

    // List running bot instances
    instances, err := client.Trading.TradingAPIBotInstances.List(ctx, map[string]string{
        "status": "running",
    })
    if err != nil {
        log.Fatal(err)
    }

    fmt.Printf("Running bots: %d\n", len(instances))
}
```

## Configuration

### Environment Variables

```bash
# API URL (optional, defaults to http://localhost:8000)
export STOCKAPIS_API_URL=http://api.stockapis.com

# API Key for authentication (optional)
export STOCKAPIS_API_KEY=your-api-key-here
```

### Programmatic Configuration

```go
client, err := stockapis.NewClient(&stockapis.Config{
    BaseURL: "http://localhost:8000",
    APIKey:  "your-api-key",
    Timeout: 30 * time.Second,
})
```

## API Reference

### Trading API

#### Bot Instances

```go
ctx := context.Background()

// List instances
instances, err := client.Trading.TradingAPIBotInstances.List(ctx, nil)

// Filter by status
running, err := client.Trading.TradingAPIBotInstances.List(ctx, map[string]string{
    "status": "running",
})

// Get specific instance
instance, err := client.Trading.TradingAPIBotInstances.Retrieve(ctx, "instance-id")

// Update instance heartbeat
err = client.Trading.TradingAPIBotInstances.Heartbeat(ctx, "instance-id")

// Start instance
err = client.Trading.TradingAPIBotInstances.Start(ctx, "instance-id")

// Stop instance
err = client.Trading.TradingAPIBotInstances.Stop(ctx, "instance-id")
```

#### Bot Configs

```go
// List configs
configs, err := client.Trading.TradingAPIBotConfigs.List(ctx, nil)

// Filter enabled configs
enabled, err := client.Trading.TradingAPIBotConfigs.List(ctx, map[string]string{
    "enabled": "true",
})

// Get specific config
config, err := client.Trading.TradingAPIBotConfigs.Retrieve(ctx, "config-id")

// Update config
err = client.Trading.TradingAPIBotConfigs.PartialUpdate(ctx, "config-id", map[string]interface{}{
    "amount_usdt": "200.0",
})
```

#### Stock Deals

```go
// List deals
deals, err := client.Trading.TradingAPIStockDeals.List(ctx, nil)

// Filter open deals
openDeals, err := client.Trading.TradingAPIStockDeals.List(ctx, map[string]string{
    "status": "open",
})

// Get specific deal
deal, err := client.Trading.TradingAPIStockDeals.Retrieve(ctx, "deal-id")
```

### Signals API

```go
// List signals
signals, err := client.Signals.SignalsAPISignals.List(ctx, nil)

// Filter by source
telegramSignals, err := client.Signals.SignalsAPISignals.List(ctx, map[string]string{
    "source": "telegram",
})

// Get specific signal
signal, err := client.Signals.SignalsAPISignals.Retrieve(ctx, "signal-id")
```

## Advanced Usage

### Custom HTTP Client

```go
import "net/http"

httpClient := &http.Client{
    Timeout: 60 * time.Second,
    // Add custom transport, etc.
}

client, err := stockapis.NewClient(&stockapis.Config{
    HTTPClient: httpClient,
})
```

### Error Handling

```go
instances, err := client.Trading.TradingAPIBotInstances.List(ctx, nil)
if err != nil {
    // Check if it's an HTTP error
    if httpErr, ok := err.(*stockapis.HTTPError); ok {
        fmt.Printf("HTTP %d: %s\n", httpErr.StatusCode, httpErr.Message)
    } else {
        fmt.Printf("Error: %v\n", err)
    }
}
```

### Context with Timeout

```go
import "time"

// Create context with timeout
ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
defer cancel()

// Request will timeout after 5 seconds
instances, err := client.Trading.TradingAPIBotInstances.List(ctx, nil)
```

## Examples

### Monitor Bot Health

```go
func monitorBots(client *stockapis.Client) {
    ctx := context.Background()
    ticker := time.NewTicker(1 * time.Minute)
    defer ticker.Stop()

    for range ticker.C {
        instances, err := client.Trading.TradingAPIBotInstances.List(ctx, nil)
        if err != nil {
            log.Printf("Error fetching instances: %v", err)
            continue
        }

        for _, instance := range instances {
            if instance.LastHeartbeatAt != nil {
                age := time.Since(*instance.LastHeartbeatAt)
                if age > 2*time.Minute {
                    fmt.Printf("⚠️  Bot %s is stale!\n", instance.ID)
                }
            } else {
                fmt.Printf("❌ Bot %s never sent heartbeat\n", instance.ID)
            }
        }
    }
}
```

### Auto-Restart Failed Bots

```go
func restartFailedBots(client *stockapis.Client) error {
    ctx := context.Background()

    errored, err := client.Trading.TradingAPIBotInstances.List(ctx, map[string]string{
        "status": "error",
    })
    if err != nil {
        return err
    }

    for _, instance := range errored {
        fmt.Printf("Restarting %s...\n", instance.ID)
        err := client.Trading.TradingAPIBotInstances.Start(ctx, instance.ID)
        if err != nil {
            log.Printf("Failed to restart %s: %v", instance.ID, err)
        }
    }

    return nil
}
```

### List Open Positions

```go
func listOpenPositions(client *stockapis.Client) error {
    ctx := context.Background()

    deals, err := client.Trading.TradingAPIStockDeals.List(ctx, map[string]string{
        "status": "open",
    })
    if err != nil {
        return err
    }

    fmt.Printf("Open positions: %d\n", len(deals))
    for _, deal := range deals {
        fmt.Printf("- %s: Entry %.2f, Current P&L: %.2f\n",
            deal.Instrument.Symbol,
            deal.EntryPrice,
            deal.UnrealizedPnl,
        )
    }

    return nil
}
```

## Development

### Testing

```bash
go test ./...
```

### Building

```bash
go build
```

## License

MIT
