# Configuration Directory

This directory contains example configuration files for the listing monitor.

## Files

- `config.example.json` - Example main configuration file
- `proxies.example.json` - Example proxy configuration
- `.env.example` - Example environment variables

## Usage

1. Copy the example files and remove the `.example` suffix:
   ```bash
   cp config.example.json config.json
   cp proxies.example.json proxies.json
   cp .env.example .env
   ```

2. Edit the files with your actual credentials and settings

3. Never commit the actual config files to version control (they're in .gitignore)

## Configuration Files

### config.json

Main configuration file containing:
- Bot configurations (exchange credentials, trading parameters)
- API monitoring settings
- Warming configuration
- Telegram notification settings

### proxies.json

Proxy configuration for API requests:
```json
[
  "http:proxy1.example.com:8010:user:pass:enabled",
  "http:proxy2.example.com:8010:user:pass:disabled"
]
```

Format: `protocol:host:port:username:password:status`

### .env

Environment variables for sensitive data:
```
TELEGRAM_BOT_TOKEN=your_token_here
TELEGRAM_CHAT_ID=your_chat_id
COINGECKO_API_KEY=your_api_key
```
