# Trading Bot Server

Stateless Python bot that connects to Django via gRPC for configuration and control.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run bot (interactive selection)
python run_bot.py

# Or specify environment directly
ENV=dev python run_bot.py   # Development
ENV=prod python run_bot.py  # Production
```

Interactive prompt (with questionary):
```
? Select environment: (Use arrow keys)
  » Development (localhost:50051)
    Production (grpc.stockapis.com:443)
```

## Configuration

Two environment files:
- `.env.dev` - Development (localhost:50051)
- `.env.prod` - Production (grpc.stockapis.com:443)

Edit `.env.prod` and set your `DJANGO_SECRET_KEY`.

## How It Works

1. Bot connects to Django gRPC server
2. Receives configuration (exchange, strategy, amount)
3. Processes trading signals
4. Sends heartbeat with metrics
5. All state stored in Django PostgreSQL (bot is stateless)

## Commands

```bash
# Development
python run_bot.py

# Production
ENV=prod python run_bot.py

# Test connection
python scripts/test_grpc_connection.py
```

## Architecture

```
Django PostgreSQL  ←→  gRPC (TLS)  ←→  Bot Client
   (Config/State)                      (Trading Logic)
```

- ✅ No database on bot side
- ✅ Hot reload on config updates
- ✅ TLS for production
- ✅ Protobuf models (no code duplication)

## Requirements

- Python 3.10+
- grpcio, protobuf, pydantic-settings
- psutil (optional, for system metrics)

## Environment Variables

Required in `.env.dev` / `.env.prod`:

```env
BOT_ID=<uuid>                           # From Django admin
DJANGO_GRPC_HOST=<host:port>            # gRPC server
DJANGO_SECRET_KEY=<django-secret-key>   # Authentication
USE_TLS=true/false                      # Enable TLS
LOG_LEVEL=DEBUG/INFO                    # Logging level
```

## Docs

- `DEPLOYMENT.md` - Full deployment guide
- `QUICKSTART.md` - Quick start guide
- `CHANGELOG.md` - Version history
