# 🤖 BotServer v2 - Stateless Trading Bot

**Version**: 2.0.0
**Status**: ✅ Foundation Complete
**Architecture**: Stateless, gRPC-based, NO database

---

## ⚡ Quick Start

```bash
# 1. Generate protobuf stubs
./scripts/generate_protos.sh

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment
cp .env.example .env
# Edit .env - set BOT_ID from Django

# 4. Run bot (example)
python example_run.py --bot-id=<uuid-from-django>
```

---

## 🎯 What is BotServer v2?

**BotServer v2** is a **stateless trading bot** that connects to Django via gRPC.

### Key Features

- ✅ **NO Database** - All data via gRPC from Django
- ✅ **Stateless** - All state in memory, can restart anytime
- ✅ **Hot Reload** - Config updates without restart
- ✅ **Bidirectional gRPC** - Bot ↔ Django communication
- ✅ **Type Safe** - Pydantic v2, 100% typed
- ✅ **Async** - Full asyncio support
- ✅ **Metrics** - System + trading metrics

### ⚠️ CRITICAL: Bot Has NO Database!

```
❌ NO PostgreSQL connection
❌ NO local database
❌ NO Django ORM
❌ NO direct DB access

✅ ALL data via gRPC from Django
✅ Django → PostgreSQL (single source of truth)
```

---

## 📦 Project Structure

```
botserver/
├── proto/                          # Protobuf definitions
│   ├── bot_service.proto           # Django gRPC service (Bot → Django)
│   └── bot_command_service.proto   # Bot gRPC service (Bot ← Django)
│
├── generated/                      # Auto-generated protobuf stubs
│   ├── bot_service_pb2.py
│   ├── bot_service_pb2_grpc.py
│   └── ... (6 files total)
│
├── scripts/
│   └── generate_protos.sh          # Generate protobuf stubs
│
├── src/botserver/                  # Bot application source
│   ├── config/
│   │   └── settings.py             # Pydantic v2 settings (NO DB!)
│   ├── core/
│   │   └── bot_core.py             # Stateless trading logic
│   ├── grpc_client/
│   │   └── client.py               # Bot → Django gRPC client
│   ├── grpc_server/
│   │   └── server.py               # Bot ← Django gRPC server
│   ├── utils/
│   │   └── metrics.py              # System + trading metrics
│   └── main.py                     # Application entry point
│
├── @docs/                          # Complete documentation (18 files)
│   ├── 00-START-HERE.md
│   ├── 01-ARCHITECTURE-DIAGRAMS.md
│   ├── 02-WORKFLOW-PLAN.md
│   ├── 06-BOT-IMPLEMENTATION.md
│   └── ... (14 more files)
│
├── requirements.txt                # Dependencies (NO psycopg2!)
├── .env.example                    # Environment template
├── example_run.py                  # Example bot usage
└── README.md                       # This file
```

---

## 🔌 Architecture

### Bidirectional gRPC Communication

```
Bot Instance (Stateless)
├── gRPC Client → Django :50051    (Register, Heartbeat, Report)
├── gRPC Server :5005X ← Django    (Start, Stop, Pause commands)
├── Bot Core (in memory)
├── Exchange Connection
└── NO DATABASE ❌

Django (Single Source of Truth)
├── PostgreSQL Database
├── gRPC Server :50051
└── Manages all bot instances
```

### Data Flow

```
1. Bot Startup:
   Bot → RegisterBot() → Django → PostgreSQL → Returns config

2. Heartbeat:
   Bot → SendHeartbeat() → Django → PostgreSQL → Updates status

3. Config Update:
   Django updates config → StreamConfig() → Bot → Apply (hot reload)

4. Trade Execution:
   Bot executes trade → ReportExecution() → Django → PostgreSQL → Logs

5. Bot Control:
   Django → StartBot/StopBot → Bot → Execute command
```

---

## 🚀 Installation

### 1. Prerequisites

- Python 3.11+
- Django gRPC server running on localhost:50051
- Bot instance created in Django database

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

**Dependencies**:
- `grpcio` - gRPC client/server
- `grpcio-tools` - Protobuf compiler
- `pydantic` - Settings & validation
- `pydantic-settings` - Environment config
- `psutil` - System metrics (optional)

**NOT included** (intentionally):
- ❌ `psycopg2` - Bot has NO database!
- ❌ `sqlalchemy` - Bot has NO ORM!
- ❌ `django` - Bot is separate from Django!

### 3. Generate Protobuf Stubs

```bash
./scripts/generate_protos.sh
```

This generates Python stubs from `.proto` files.

### 4. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:
```ini
BOT_ID=<uuid-from-django>
DJANGO_GRPC_HOST=localhost
DJANGO_GRPC_PORT=50051
BOT_GRPC_PORT=50052
```

---

## 💻 Usage

### Basic Usage

```bash
python example_run.py --bot-id=550e8400-e29b-41d4-a716-446655440000
```

### Programmatic Usage

```python
from botserver.config.settings import BotSettings
from botserver.grpc_client.client import BotGrpcClient
from botserver.core.bot_core import BotCore

# Load settings
settings = BotSettings()

# Connect to Django
client = BotGrpcClient(
    host=settings.DJANGO_GRPC_HOST,
    port=settings.DJANGO_GRPC_PORT,
    bot_id=settings.BOT_ID
)

await client.connect()

# Register and get config
config = await client.register(
    api_key="...",
    hostname="bot-1",
    grpc_port=50052
)

# Initialize bot core (in-memory, NO DB!)
bot = BotCore(config)
bot.start()

# Send heartbeat
metrics = bot.get_metrics()
await client.send_heartbeat(status="RUNNING", metrics=metrics)
```

---

## 🧪 Testing

### Test Protobuf Generation

```bash
./scripts/generate_protos.sh
python -c "from generated import bot_service_pb2; print('✅ OK')"
```

### Test Bot Core

```python
from botserver.core.bot_core import BotCore

config = {
    "id": "test-uuid",
    "name": "Test Bot",
    "exchange": "bybit",
    "market_type": "swap",
    "direction": "BOTH",
    "amount_usdt": 100.0,
    "signal_type": "SIGNAL_LISTING",
    "allowed_quotes": ["USDT"],
    "allowed_sources": ["telegram"],
    "settings": {}
}

bot = BotCore(config)
bot.start()
print(bot.get_status_summary())
# Output: 🟢 RUNNING | Test Bot | Uptime: 0m | ...
```

### Test Metrics

```python
from botserver.utils.metrics import MetricsCollector

collector = MetricsCollector()
print(collector.get_summary())
# Output: ⏱️ Uptime: < 1m | 💻 CPU: 15.2% | 🧠 Mem: 45.3% | ...
```

---

## 📚 Documentation

Complete documentation is in the `@docs/` directory:

- **[00-START-HERE.md](@docs/00-START-HERE.md)** - Entry point
- **[01-ARCHITECTURE-DIAGRAMS.md](@docs/01-ARCHITECTURE-DIAGRAMS.md)** - System architecture
- **[02-WORKFLOW-PLAN.md](@docs/02-WORKFLOW-PLAN.md)** - Implementation plan
- **[06-BOT-IMPLEMENTATION.md](@docs/06-BOT-IMPLEMENTATION.md)** - Bot implementation guide
- **[COMPLETION-STATUS.md](@docs/COMPLETION-STATUS.md)** - Progress tracking
- **[IMPLEMENTATION-PROGRESS.md](@docs/IMPLEMENTATION-PROGRESS.md)** - Latest updates

**Total**: 18 markdown files, ~7,500 lines

---

## 🔧 Configuration

### Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `BOT_ID` | ✅ Yes | - | UUID from Django BotInstance |
| `DJANGO_GRPC_HOST` | ✅ Yes | localhost | Django gRPC server host |
| `DJANGO_GRPC_PORT` | ✅ Yes | 50051 | Django gRPC server port |
| `BOT_GRPC_PORT` | ✅ Yes | 50052 | Bot's gRPC server port (unique per bot) |
| `HOSTNAME` | No | auto | Bot's hostname |
| `EXCHANGE_API_KEY` | No | - | Exchange API key (or from Django) |
| `EXCHANGE_API_SECRET` | No | - | Exchange API secret (or from Django) |
| `HEARTBEAT_INTERVAL` | No | 60 | Heartbeat interval (seconds) |
| `HEARTBEAT_TIMEOUT` | No | 120 | Heartbeat timeout (seconds) |
| `LOG_LEVEL` | No | INFO | Log level (DEBUG, INFO, WARNING, ERROR) |
| `ENABLE_DRY_RUN` | No | false | Dry run mode (no real trades) |

### What's NOT Needed

❌ **NO Database Variables**:
- `DATABASE_URL`
- `DB_HOST`, `DB_PORT`, `DB_NAME`
- `DB_USER`, `DB_PASSWORD`
- `POSTGRESQL_*`

Bot is **stateless** - all data via gRPC!

---

## 🏗️ Development

### Project Structure

- **`proto/`** - Protobuf definitions (shared with Django)
- **`src/botserver/`** - Bot application code
- **`scripts/`** - Utility scripts
- **`@docs/`** - Complete documentation

### Code Style

- **Type hints**: 100% coverage
- **Docstrings**: Google style
- **Formatting**: Black (line length 100)
- **Linting**: Ruff
- **Type checking**: mypy

### Testing Strategy

1. **Unit tests** - Test individual components
2. **Integration tests** - Test gRPC communication
3. **End-to-end tests** - Test full bot lifecycle

---

## 🐛 Troubleshooting

### Proto Import Error

```
ModuleNotFoundError: No module named 'bot_service_pb2'
```

**Solution**: Regenerate proto stubs
```bash
./scripts/generate_protos.sh
```

### gRPC Connection Failed

```
Failed to connect to Django gRPC
```

**Check**:
1. Django gRPC server is running
2. Correct host/port in `.env`
3. Network connectivity

### Bot Not Found

```
Bot instance <uuid> not found
```

**Solution**: Create bot instance in Django database first

### Heartbeat Timeout

```
Heartbeat not acknowledged
```

**Check**:
1. Bot ID is correct
2. Django gRPC server is responsive
3. Network not congested

---

## 📊 Metrics

### System Metrics

- CPU usage (%)
- Memory usage (%)
- Uptime (seconds)

### Trading Metrics

- Open positions
- Daily P&L (USDT)
- Total trades
- Win rate (%)
- Total volume

All metrics are **ephemeral** (in-memory only).
Django receives them via heartbeat and stores in PostgreSQL.

---

## 🚀 Deployment

### Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Generate proto stubs
RUN ./scripts/generate_protos.sh

# Run bot
CMD ["python", "-m", "botserver.main", "--bot-id=${BOT_ID}"]
```

### Kubernetes

Each bot instance = separate pod with unique `BOT_GRPC_PORT`.

---

## 🔒 Security

### Best Practices

✅ **Use JWT tokens** for gRPC authentication (when enabled)
✅ **Store API keys in Django** (encrypted), not in bot .env
✅ **Use TLS for gRPC** in production
✅ **No database credentials** on bot side
✅ **Rotate API keys regularly**

---

## 📝 License

Proprietary - StockAPIs Internal Project

---

## 🤝 Contributing

1. Read documentation in `@docs/`
2. Follow code style guidelines
3. Add tests for new features
4. Update documentation

---

## 📞 Support

**Documentation**: `@docs/` directory
**Issues**: Internal issue tracker
**Contact**: Development team

---

**Built with ❤️ by StockAPIs Team**
