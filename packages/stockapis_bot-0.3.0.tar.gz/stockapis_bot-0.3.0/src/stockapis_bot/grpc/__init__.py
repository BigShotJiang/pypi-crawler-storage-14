"""gRPC module for Django communication."""

from .client import GRPCStreamingClient
from .connection import ConnectionManager

__all__ = [
    "GRPCStreamingClient",
    "ConnectionManager",
]
