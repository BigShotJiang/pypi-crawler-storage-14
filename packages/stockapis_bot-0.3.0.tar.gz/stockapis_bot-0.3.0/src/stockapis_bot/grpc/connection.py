"""gRPC connection manager."""

import asyncio
from typing import Optional

import grpc

from shared import get_logger

from ..exceptions import GRPCConnectionError

logger = get_logger(__name__)


class ConnectionManager:
    """Manages gRPC channel connection with reconnection support.

    Handles connection lifecycle, reconnection on failure,
    and channel state monitoring.
    """

    def __init__(
        self,
        host: str,
        port: int,
        use_tls: bool = False,
        reconnect_interval: int = 5,
    ) -> None:
        """Initialize connection manager.

        Args:
            host: gRPC server host
            port: gRPC server port
            use_tls: Enable TLS/SSL
            reconnect_interval: Seconds between reconnection attempts
        """
        self._host = host
        self._port = port
        self._use_tls = use_tls
        self._reconnect_interval = reconnect_interval
        self._channel: Optional[grpc.aio.Channel] = None
        self._connected = False

    @property
    def address(self) -> str:
        """Get server address."""
        return f"{self._host}:{self._port}"

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected and self._channel is not None

    @property
    def channel(self) -> grpc.aio.Channel:
        """Get the gRPC channel.

        Raises:
            GRPCConnectionError: If not connected.
        """
        if self._channel is None:
            raise GRPCConnectionError(
                message="Not connected to gRPC server",
                host=self._host,
                port=self._port,
            )
        return self._channel

    async def connect(self) -> bool:
        """Connect to gRPC server.

        Returns:
            True if connection successful.
        """
        try:
            self._channel = self._create_channel()
            await self._wait_for_ready()
            self._connected = True
            logger.info(f"Connected to gRPC server at {self.address}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to gRPC server: {e}")
            self._connected = False
            raise GRPCConnectionError(
                message=str(e),
                host=self._host,
                port=self._port,
            ) from e

    def _create_channel(self) -> grpc.aio.Channel:
        """Create gRPC channel."""
        if self._use_tls:
            credentials = grpc.ssl_channel_credentials()
            return grpc.aio.secure_channel(self.address, credentials)
        return grpc.aio.insecure_channel(self.address)

    async def _wait_for_ready(self, timeout: float = 10.0) -> None:
        """Wait for channel to be ready.

        Args:
            timeout: Timeout in seconds

        Raises:
            GRPCConnectionError: If connection times out.
        """
        if self._channel is None:
            raise GRPCConnectionError(
                message="Channel not created",
                host=self._host,
                port=self._port,
            )

        try:
            await asyncio.wait_for(
                self._channel.channel_ready(),
                timeout=timeout,
            )
        except asyncio.TimeoutError as e:
            raise GRPCConnectionError(
                message=f"Connection timeout after {timeout}s",
                host=self._host,
                port=self._port,
            ) from e

    async def disconnect(self) -> None:
        """Disconnect from gRPC server."""
        if self._channel:
            await self._channel.close()
            self._channel = None
        self._connected = False
        logger.info("Disconnected from gRPC server")

    async def reconnect(self) -> bool:
        """Attempt to reconnect to server.

        Returns:
            True if reconnection successful.
        """
        await self.disconnect()
        await asyncio.sleep(self._reconnect_interval)
        return await self.connect()
