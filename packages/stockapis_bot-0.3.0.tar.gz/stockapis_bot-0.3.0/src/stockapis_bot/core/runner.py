"""Async runner utilities for running bots."""

import asyncio
import signal
from typing import Optional

from shared import get_logger

from .bot import TradingBot
from .client import BotClient
from ..models.config import ClientConfig

logger = get_logger(__name__)


async def run_bot(
    bot: TradingBot,
    config: ClientConfig,
    client: Optional[BotClient] = None,
) -> None:
    """Run a trading bot with graceful shutdown handling.

    This is the main entry point for running bots.
    Handles SIGINT and SIGTERM for graceful shutdown.

    Args:
        bot: TradingBot instance
        config: Client configuration
        client: Optional pre-configured BotClient

    Example:
        from stockapis_bot import run_bot, TradingBot, ClientConfig

        class MyBot(TradingBot):
            async def on_signal(self, signal):
                return SignalDecision.skip("Not implemented")

        bot = MyBot(bot_id="my-bot", name="My Bot")
        config = ClientConfig(...)

        asyncio.run(run_bot(bot, config))
    """
    if client is None:
        client = BotClient.create(bot, config)

    # Setup signal handlers
    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def signal_handler() -> None:
        logger.info("Shutdown signal received")
        shutdown_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, signal_handler)

    # Run client with shutdown handling
    run_task = asyncio.create_task(client.run())

    # Wait for shutdown signal
    shutdown_task = asyncio.create_task(shutdown_event.wait())

    done, pending = await asyncio.wait(
        [run_task, shutdown_task],
        return_when=asyncio.FIRST_COMPLETED,
    )

    # Stop client if shutdown triggered
    if shutdown_task in done:
        await client.stop()

    # Cancel remaining tasks
    for task in pending:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    # Re-raise any exceptions from run_task
    if run_task in done:
        run_task.result()


def run_bot_sync(
    bot: TradingBot,
    config: ClientConfig,
    client: Optional[BotClient] = None,
) -> None:
    """Synchronous wrapper for run_bot.

    Convenience function for running from main().

    Args:
        bot: TradingBot instance
        config: Client configuration
        client: Optional pre-configured BotClient

    Example:
        if __name__ == "__main__":
            bot = MyBot(bot_id="my-bot", name="My Bot")
            config = ClientConfig(...)
            run_bot_sync(bot, config)
    """
    asyncio.run(run_bot(bot, config, client))
