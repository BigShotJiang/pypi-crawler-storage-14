"""Trading data models - Pydantic v2, NO raw dicts."""

from datetime import datetime, timezone
from decimal import Decimal
from typing import Annotated, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .enums import OrderSide, OrderStatus, OrderType, SignalType


def utc_now() -> datetime:
    """Get current UTC time with timezone info."""
    return datetime.now(timezone.utc)


class TradingSignal(BaseModel):
    """Trading signal from Telegram or other sources."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    signal_id: UUID = Field(default_factory=uuid4)
    symbol: Annotated[str, Field(min_length=1, max_length=20)]
    signal_type: SignalType
    source: str = Field(description="Signal source (e.g., 'listing', 'technical')")
    confidence: Annotated[float, Field(ge=0, le=1)] = Field(default=0.5)
    price: Optional[Decimal] = Field(default=None, description="Suggested price if any")
    timestamp: datetime = Field(default_factory=utc_now)
    metadata: dict[str, str] = Field(default_factory=dict)

    @field_validator("symbol")
    @classmethod
    def normalize_symbol(cls, v: str) -> str:
        """Normalize symbol format."""
        return v.upper().replace("/", "").replace("-", "").replace("_", "")

    @property
    def is_buy_signal(self) -> bool:
        """Check if this is a buy signal."""
        return self.signal_type in {SignalType.BUY, SignalType.BUY_LONG}

    @property
    def is_sell_signal(self) -> bool:
        """Check if this is a sell signal."""
        return self.signal_type in {SignalType.SELL, SignalType.SELL_SHORT}

    @property
    def is_close_signal(self) -> bool:
        """Check if this is a close position signal."""
        return self.signal_type in {SignalType.CLOSE_LONG, SignalType.CLOSE_SHORT}


class TickerInfo(BaseModel):
    """Current price information from exchange."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    symbol: str
    price: Decimal
    bid: Optional[Decimal] = Field(default=None)
    ask: Optional[Decimal] = Field(default=None)
    volume_24h: Optional[Decimal] = Field(default=None)
    timestamp: datetime = Field(default_factory=utc_now)

    @property
    def spread(self) -> Optional[Decimal]:
        """Calculate bid-ask spread."""
        if self.bid is not None and self.ask is not None:
            return self.ask - self.bid
        return None


class AccountBalance(BaseModel):
    """Account balance information."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    total_balance: Decimal
    available_balance: Decimal
    currency: str = Field(default="USDT")
    unrealized_pnl: Decimal = Field(default=Decimal("0"))
    margin_balance: Optional[Decimal] = Field(default=None)

    @property
    def used_balance(self) -> Decimal:
        """Calculate used balance."""
        return self.total_balance - self.available_balance


class Order(BaseModel):
    """Order data structure."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    order_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: Decimal
    price: Optional[Decimal] = Field(default=None)
    status: OrderStatus = Field(default=OrderStatus.PENDING)
    filled_quantity: Decimal = Field(default=Decimal("0"))
    average_price: Optional[Decimal] = Field(default=None)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: Optional[datetime] = Field(default=None)
    client_order_id: Optional[str] = Field(default=None)

    @property
    def is_filled(self) -> bool:
        """Check if order is fully filled."""
        return self.status == OrderStatus.FILLED

    @property
    def is_active(self) -> bool:
        """Check if order is still active."""
        return self.status in {OrderStatus.PENDING, OrderStatus.NEW, OrderStatus.PARTIALLY_FILLED}

    @property
    def fill_percentage(self) -> Decimal:
        """Calculate fill percentage."""
        if self.quantity > 0:
            return (self.filled_quantity / self.quantity) * 100
        return Decimal("0")


class Position(BaseModel):
    """Open position data structure."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    position_id: str
    symbol: str
    side: OrderSide
    size: Decimal
    entry_price: Decimal
    current_price: Optional[Decimal] = Field(default=None)
    unrealized_pnl: Decimal = Field(default=Decimal("0"))
    realized_pnl: Decimal = Field(default=Decimal("0"))
    leverage: int = Field(default=1)
    liquidation_price: Optional[Decimal] = Field(default=None)
    margin: Optional[Decimal] = Field(default=None)
    created_at: datetime = Field(default_factory=utc_now)

    @property
    def notional_value(self) -> Decimal:
        """Calculate notional value of position."""
        price = self.current_price or self.entry_price
        return self.size * price

    @property
    def pnl_percentage(self) -> Optional[Decimal]:
        """Calculate PnL percentage."""
        if self.current_price is None or self.entry_price == 0:
            return None
        if self.side == OrderSide.BUY:
            return ((self.current_price - self.entry_price) / self.entry_price) * 100
        else:
            return ((self.entry_price - self.current_price) / self.entry_price) * 100
