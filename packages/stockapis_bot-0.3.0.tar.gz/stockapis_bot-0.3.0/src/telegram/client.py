"""
Telegram client wrapper around Telethon.

Handles connection, authorization, and message listening.
Supports both interactive auth (phone) and session string auth (containers).
"""

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Optional

from shared import get_logger

from .config import ChannelConfig, TelegramConfig

if TYPE_CHECKING:
    from telethon import TelegramClient as TelethonClient
    from telethon.tl.types import Channel

logger = get_logger(__name__)


def _check_telethon() -> None:
    """Check if telethon is installed."""
    try:
        import telethon  # noqa: F401
    except ImportError:
        raise ImportError(
            "Telethon is required for Telegram functionality. "
            "Install with: pip install botclient[telegram]"
        )


class TelegramClient:
    """
    Async Telegram client wrapper around Telethon.

    Supports two authentication methods:
    1. Interactive auth with phone number (for initial setup)
    2. Session string auth (for containerized deployment)

    Usage:
        # Interactive auth
        config = TelegramConfig(api_id=123, api_hash="abc", phone="+1234567890")
        client = TelegramClient(config)
        await client.connect()

        # Session string auth (recommended for production)
        config = TelegramConfig(api_id=123, api_hash="abc", session_string="...")
        client = TelegramClient(config)
        await client.connect()  # No interaction needed
    """

    def __init__(self, config: TelegramConfig) -> None:
        """
        Initialize Telethon client.

        Args:
            config: TelegramConfig with api_id, api_hash, and auth method.
        """
        _check_telethon()

        self.config = config
        self._client: Optional["TelethonClient"] = None
        self._connected = False
        self._handlers: list[tuple[ChannelConfig, Callable[..., Any]]] = []

        logger.info(
            f"TelegramClient initialized "
            f"(auth: {'session_string' if config.session_string else 'phone'})"
        )

    @property
    def is_connected(self) -> bool:
        """Check if connected to Telegram."""
        return self._connected

    async def connect(self) -> None:
        """
        Connect to Telegram with retry logic.

        Raises:
            ConnectionError: If all retries fail.
            ImportError: If telethon is not installed.
        """
        from telethon import TelegramClient as TelethonClient
        from telethon.errors import FloodWaitError, SessionPasswordNeededError
        from telethon.sessions import StringSession

        # Determine session type
        if self.config.session_string:
            # Use session string (no interaction needed)
            session = StringSession(self.config.session_string)
            logger.info("Using session string authentication")
        else:
            # Use session file (may require interaction)
            session_path = self.config.session_file
            if session_path.parent != Path("."):
                session_path.parent.mkdir(parents=True, exist_ok=True)
            session = str(session_path)
            logger.info(f"Using session file: {session_path}")

        # Create Telethon client
        self._client = TelethonClient(
            session,
            self.config.api_id,
            self.config.api_hash,
        )

        for attempt in range(1, 6):  # 5 retries
            try:
                logger.info(f"Connecting to Telegram (attempt {attempt}/5)...")

                await self._client.connect()

                # Check if authorized
                if not await self._client.is_user_authorized():
                    if self.config.session_string:
                        raise ConnectionError(
                            "Session string is invalid or expired. "
                            "Generate a new one with TelegramClient.generate_session_string()"
                        )
                    logger.info("Authorization required")
                    await self._authorize()

                self._connected = True
                me = await self._client.get_me()
                logger.info(f"Connected to Telegram as: {me.username or me.phone}")
                return

            except SessionPasswordNeededError:
                logger.error("2FA password required")
                raise ConnectionError(
                    "2FA password required. Use interactive auth first to create session."
                )

            except FloodWaitError as e:
                wait_seconds = e.seconds
                logger.warning(f"Flood wait: {wait_seconds}s")
                await asyncio.sleep(wait_seconds)

            except Exception as e:
                logger.error(f"Connection failed (attempt {attempt}): {e}")
                if attempt < 5:
                    await asyncio.sleep(5)
                else:
                    raise ConnectionError(f"Failed after {attempt} attempts: {e}")

    async def _authorize(self) -> None:
        """
        Request verification code and sign in.

        Note: Interactive authorization for first-time setup.
        """
        import getpass

        from telethon.errors import SessionPasswordNeededError

        if not self._client:
            raise RuntimeError("Client not initialized")

        if not self.config.phone:
            raise ValueError(
                "Phone number required for interactive authorization. "
                "Set config.phone or use session_string for non-interactive auth."
            )

        await self._client.send_code_request(self.config.phone)

        logger.info(f"Code sent to {self.config.phone}")
        print(f"\n[TelegramClient] Code sent to {self.config.phone}")
        code = input("Enter verification code: ").strip()

        try:
            await self._client.sign_in(self.config.phone, code)
            logger.info("Authorization successful")
        except SessionPasswordNeededError:
            logger.info("2FA enabled - password required")
            print("\n[TelegramClient] 2FA is enabled on this account")
            password = getpass.getpass("Enter 2FA password: ")
            await self._client.sign_in(password=password)
            logger.info("Authorization successful with 2FA")

    async def disconnect(self) -> None:
        """Disconnect from Telegram."""
        if self._client and self._connected:
            await self._client.disconnect()
            self._connected = False
            logger.info("Disconnected from Telegram")

    async def get_channel_entity(self, username: str) -> Optional["Channel"]:
        """
        Resolve channel by username.

        Args:
            username: Channel username (e.g., 'cryptosignals').

        Returns:
            Channel entity or None.
        """
        from telethon.errors import ChannelPrivateError

        if not self._client:
            return None

        try:
            entity = await self._client.get_entity(username)
            logger.debug(f"Channel resolved: {username}")
            return entity

        except ChannelPrivateError:
            logger.error(f"Channel is private: {username}")
            return None

        except Exception as e:
            logger.error(f"Failed to resolve channel {username}: {e}")
            return None

    def register_message_handler(
        self,
        channel: ChannelConfig,
        callback: Callable[[Any], Any],
    ) -> None:
        """
        Register handler for new messages in channel.

        Args:
            channel: ChannelConfig with username.
            callback: Async callback(event) function.
        """
        from telethon import events

        if not self._client:
            raise RuntimeError("Client not initialized")

        @self._client.on(events.NewMessage(chats=[channel.username]))
        async def handler(event: events.NewMessage.Event) -> None:
            """Handle new message event."""
            try:
                if event.message.text:
                    logger.debug(
                        f"Message received: {channel.username}#{event.message.id}"
                    )
                    await callback(event)

            except Exception as e:
                logger.error(f"Handler error for {channel.username}: {e}")

        self._handlers.append((channel, callback))
        logger.info(f"Handler registered: {channel.username}")

    async def start_listening(self) -> None:
        """
        Start listening for events (blocking).

        Runs until disconnected or interrupted.
        """
        if not self._client:
            raise RuntimeError("Client not initialized")

        logger.info("Starting event listener...")

        try:
            await self._client.run_until_disconnected()
        except KeyboardInterrupt:
            logger.info("Listener interrupted")
        except Exception as e:
            logger.error(f"Listener error: {e}")
            raise

    async def get_me(self) -> Any:
        """Get current user info."""
        if not self._client:
            raise RuntimeError("Client not initialized")
        return await self._client.get_me()

    async def get_dialogs(self) -> list:
        """Get list of dialogs (chats, channels, groups)."""
        if not self._client:
            raise RuntimeError("Client not initialized")
        return await self._client.get_dialogs()

    async def __aenter__(self) -> "TelegramClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(
        self, exc_type: Any, exc_val: Any, exc_tb: Any
    ) -> None:
        """Async context manager exit."""
        await self.disconnect()

    # ═══════════════════════════════════════════════════════════════
    # SESSION STRING GENERATION
    # ═══════════════════════════════════════════════════════════════

    @classmethod
    async def generate_session_string(
        cls,
        api_id: int,
        api_hash: str,
        phone: str,
    ) -> str:
        """
        Generate a session string for containerized deployment.

        This is an interactive process that requires phone verification.
        Run this once locally, save the session string, and use it in containers.

        Args:
            api_id: Telegram API ID from my.telegram.org
            api_hash: Telegram API hash
            phone: Phone number with country code (e.g., "+1234567890")

        Returns:
            Session string that can be used for non-interactive auth.

        Usage:
            session_string = await TelegramClient.generate_session_string(
                api_id=12345,
                api_hash="abc123...",
                phone="+1234567890"
            )
            print(f"Save this session string: {session_string}")

            # Later, use in container:
            config = TelegramConfig(
                api_id=12345,
                api_hash="abc123...",
                session_string=session_string
            )
        """
        _check_telethon()

        import getpass

        from telethon import TelegramClient as TelethonClient
        from telethon.errors import SessionPasswordNeededError
        from telethon.sessions import StringSession

        print("\n=== Telegram Session String Generator ===\n")

        client = TelethonClient(StringSession(), api_id, api_hash)

        try:
            await client.connect()

            if not await client.is_user_authorized():
                await client.send_code_request(phone)
                print(f"Verification code sent to {phone}")
                code = input("Enter verification code: ").strip()

                try:
                    await client.sign_in(phone, code)
                except SessionPasswordNeededError:
                    print("2FA is enabled on this account")
                    password = getpass.getpass("Enter 2FA password: ")
                    await client.sign_in(password=password)

            # Get session string
            session_string = client.session.save()

            me = await client.get_me()
            print(f"\nAuthorized as: {me.username or me.phone}")
            print(f"\nSession string (keep this secret!):\n{session_string}\n")

            return session_string

        finally:
            await client.disconnect()
