"""
Telegram spy module for monitoring trading signal channels.

REQUIRES: pip install botclient[telegram]

Usage:
    from stockapis_bot.telegram import TelegramSpy, TelegramConfig

    spy = TelegramSpy(
        api_id=12345,
        api_hash="your_api_hash",
        session_string="YOUR_SESSION_STRING",
        channels=["crypto_signals", "whale_alerts"],
    )

    @spy.on_signal
    async def handle_signal(signal):
        print(f"Signal: {signal.action} {signal.symbol}")

    await spy.start()

Generate session string:
    from stockapis_bot.telegram import TelegramSpy

    session = await TelegramSpy.generate_session_string(
        api_id=12345,
        api_hash="your_api_hash",
        phone="+1234567890"
    )
    print(f"Save this: {session}")
"""

from .client import TelegramClient
from .config import ChannelConfig, TelegramConfig, TelegramSpyConfig
from .extractors import SignalExtractor
from .extractors.signal_extractor import ExtractedSignal, ExtractionResult
from .grpc import SignalPublisher
from .redis_publisher import RedisSignalPublisher
from .spy import TelegramSpy
from .test_bot import TEST_SIGNALS, send_all_signals, send_test_signal

__all__ = [
    # Main service
    "TelegramSpy",
    # Client
    "TelegramClient",
    # Config
    "TelegramConfig",
    "TelegramSpyConfig",
    "ChannelConfig",
    # Extractor
    "SignalExtractor",
    "ExtractedSignal",
    "ExtractionResult",
    # Publishers
    "SignalPublisher",       # → Django (gRPC)
    "RedisSignalPublisher",  # → Redis → BotClient
    # Test utilities
    "send_test_signal",
    "send_all_signals",
    "TEST_SIGNALS",
]
