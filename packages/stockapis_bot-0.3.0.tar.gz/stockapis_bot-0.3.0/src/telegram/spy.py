"""
TelegramSpy - Main service for monitoring Telegram channels.

REQUIRES: pip install botclient[telegram]

Usage:
    from stockapis_bot.telegram import TelegramSpy, TelegramConfig, ChannelConfig

    # Create spy with session string (recommended for production)
    spy = TelegramSpy(
        api_id=12345,
        api_hash="your_api_hash",
        session_string="your_session_string",
        channels=["crypto_signals", "whale_alerts"],
    )

    # Register signal handler
    @spy.on_signal
    async def handle_signal(signal):
        print(f"Signal: {signal.action} {signal.symbol}")
        # Forward to your bot...

    # Start monitoring
    await spy.start()
"""

import asyncio
import json
from functools import partial
from typing import Any, Callable, Optional, Protocol

from shared import get_logger

from .client import TelegramClient
from .config import ChannelConfig, TelegramConfig, TelegramSpyConfig
from .extractors import SignalExtractor
from .extractors.signal_extractor import ExtractedSignal

logger = get_logger(__name__)


class SignalPublisherProtocol(Protocol):
    """Protocol for signal publishers (Redis, gRPC, etc.)."""

    async def connect(self) -> bool:
        ...

    async def disconnect(self) -> None:
        ...

    async def publish_signal(self, signal: ExtractedSignal) -> bool:
        ...


class TelegramSpy:
    """
    Telegram channel monitoring service.

    Monitors configured channels, extracts trading signals from messages,
    and forwards them via callbacks or Redis PubSub.

    Features:
    - Session string auth for containerized deployment
    - Multi-channel monitoring
    - Configurable signal filters (type, confidence)
    - Redis PubSub publishing
    - Custom signal callbacks
    """

    def __init__(
        self,
        api_id: int,
        api_hash: str,
        session_string: Optional[str] = None,
        phone: Optional[str] = None,
        channels: Optional[list[str | ChannelConfig]] = None,
        min_confidence: float = 0.3,
        redis_url: Optional[str] = None,
        redis_channel: str = "trading_signals",
    ) -> None:
        """
        Initialize TelegramSpy.

        Args:
            api_id: Telegram API ID from my.telegram.org
            api_hash: Telegram API hash
            session_string: Pre-authorized session string (recommended)
            phone: Phone number for interactive auth (alternative to session_string)
            channels: List of channel usernames or ChannelConfig objects
            min_confidence: Minimum confidence to publish signals (0.0-1.0)
            redis_url: Redis URL for signal publishing (optional)
            redis_channel: Redis PubSub channel name

        Example:
            spy = TelegramSpy(
                api_id=12345,
                api_hash="abc123...",
                session_string="...",
                channels=["crypto_signals", "whale_alerts"],
            )
        """
        # Build config
        self._telegram_config = TelegramConfig(
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string,
            phone=phone,
        )

        # Parse channels
        self._channels: list[ChannelConfig] = []
        if channels:
            for ch in channels:
                if isinstance(ch, str):
                    self._channels.append(ChannelConfig(username=ch))
                else:
                    self._channels.append(ch)

        self._min_confidence = min_confidence
        self._redis_url = redis_url
        self._redis_channel = redis_channel

        # Components (initialized in start)
        self._client: Optional[TelegramClient] = None
        self._extractor: Optional[SignalExtractor] = None
        self._redis: Optional[Any] = None  # aioredis.Redis

        # Callbacks
        self._signal_callbacks: list[Callable[[ExtractedSignal], Any]] = []

        # State
        self._running = False

        # Statistics
        self._stats = {
            "messages_received": 0,
            "signals_extracted": 0,
            "signals_published": 0,
            "signals_filtered": 0,
        }

        logger.info(
            f"TelegramSpy initialized with {len(self._channels)} channels"
        )

    # ═══════════════════════════════════════════════════════════════
    # CONFIGURATION
    # ═══════════════════════════════════════════════════════════════

    def add_channel(self, channel: str | ChannelConfig) -> None:
        """Add a channel to monitor."""
        if isinstance(channel, str):
            channel = ChannelConfig(username=channel)
        self._channels.append(channel)
        logger.info(f"Channel added: {channel.username}")

    def on_signal(
        self, callback: Callable[[ExtractedSignal], Any]
    ) -> Callable[[ExtractedSignal], Any]:
        """
        Register a callback for extracted signals.

        Can be used as a decorator:
            @spy.on_signal
            async def handle_signal(signal):
                print(signal)

        Or directly:
            spy.on_signal(my_handler)
        """
        self._signal_callbacks.append(callback)
        logger.info(f"Signal callback registered: {callback.__name__}")
        return callback

    # ═══════════════════════════════════════════════════════════════
    # LIFECYCLE
    # ═══════════════════════════════════════════════════════════════

    async def start(self) -> None:
        """
        Start monitoring channels.

        Connects to Telegram, registers handlers, and starts listening.
        This is a blocking call - use asyncio.create_task() for concurrent execution.
        """
        if self._running:
            logger.warning("TelegramSpy is already running")
            return

        logger.info("Starting TelegramSpy...")
        self._running = True

        try:
            # Initialize extractor
            self._extractor = SignalExtractor()

            # Initialize Redis if configured
            if self._redis_url:
                await self._init_redis()

            # Initialize Telegram client
            self._client = TelegramClient(self._telegram_config)
            await self._client.connect()

            # Register handlers for each channel
            for channel in self._channels:
                if channel.enabled:
                    handler = partial(self._handle_message, channel_config=channel)
                    self._client.register_message_handler(channel, handler)

            logger.info(
                f"TelegramSpy started. Monitoring {len(self._channels)} channels."
            )

            # Start listening (blocking)
            await self._client.start_listening()

        except Exception as e:
            logger.error(f"TelegramSpy error: {e}", exc_info=True)
            raise
        finally:
            await self.stop()

    async def stop(self) -> None:
        """Stop monitoring gracefully."""
        if not self._running:
            return

        logger.info("Stopping TelegramSpy...")
        self._running = False

        try:
            if self._client:
                await self._client.disconnect()

            if self._redis:
                await self._redis.close()

        except Exception as e:
            logger.error(f"Error during shutdown: {e}")

        logger.info("TelegramSpy stopped")

    # ═══════════════════════════════════════════════════════════════
    # MESSAGE HANDLING
    # ═══════════════════════════════════════════════════════════════

    async def _handle_message(
        self, event: Any, channel_config: ChannelConfig
    ) -> None:
        """Handle incoming Telegram message."""
        self._stats["messages_received"] += 1

        try:
            message = event.message
            if not message.text:
                return

            # Get channel info
            chat = await event.get_chat()
            channel_name = getattr(chat, "title", channel_config.username)
            channel_username = getattr(chat, "username", channel_config.username)

            logger.debug(f"Processing message from {channel_username}#{message.id}")

            # Check keyword filters
            if not self._passes_filters(message.text, channel_config):
                logger.debug(f"Message filtered by keywords: {message.id}")
                return

            # Extract signal
            if not self._extractor:
                return

            result = self._extractor.extract(
                text=message.text,
                channel_name=channel_name,
                channel_username=channel_username,
                message_id=message.id,
                message_date=message.date,
            )

            if not result.success or not result.signal:
                return

            self._stats["signals_extracted"] += 1
            signal = result.signal

            # Check confidence threshold
            effective_min = max(self._min_confidence, channel_config.min_confidence)
            if float(signal.confidence) < effective_min:
                logger.debug(
                    f"Signal filtered by confidence: {signal.confidence} < {effective_min}"
                )
                self._stats["signals_filtered"] += 1
                return

            # Check signal type filter
            if channel_config.signal_types:
                signal_type_value = signal.action.value.upper()
                allowed_types = [t.value for t in channel_config.signal_types]
                if signal_type_value not in allowed_types:
                    logger.debug(
                        f"Signal filtered by type: {signal_type_value} not in {allowed_types}"
                    )
                    self._stats["signals_filtered"] += 1
                    return

            # Log signal
            logger.info(
                f"Signal: {signal.action.value} {signal.symbol} "
                f"(confidence={signal.confidence}, completeness={signal.completeness})"
            )

            # Publish to Redis
            if self._redis:
                await self._publish_to_redis(signal)

            # Call registered callbacks
            for callback in self._signal_callbacks:
                try:
                    result = callback(signal)
                    if asyncio.iscoroutine(result):
                        await result
                except Exception as e:
                    logger.error(f"Callback error: {e}", exc_info=True)

            self._stats["signals_published"] += 1

        except Exception as e:
            logger.error(f"Error handling message: {e}", exc_info=True)

    def _passes_filters(self, text: str, config: ChannelConfig) -> bool:
        """Check if message passes keyword filters."""
        text_lower = text.lower()

        # Check exclude keywords
        for keyword in config.exclude_keywords:
            if keyword.lower() in text_lower:
                return False

        # Check include keywords (if any specified)
        if config.keywords:
            return any(kw.lower() in text_lower for kw in config.keywords)

        return True

    # ═══════════════════════════════════════════════════════════════
    # REDIS
    # ═══════════════════════════════════════════════════════════════

    async def _init_redis(self) -> None:
        """Initialize Redis connection."""
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                self._redis_url,
                decode_responses=True,
                socket_timeout=5.0,
            )
            await self._redis.ping()
            logger.info(f"Connected to Redis: {self._redis_url}")
        except ImportError:
            logger.warning("redis package not installed, Redis publishing disabled")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self._redis = None

    async def _publish_to_redis(self, signal: ExtractedSignal) -> bool:
        """Publish signal to Redis PubSub."""
        if not self._redis:
            return False

        try:
            message = json.dumps(signal.to_redis_dict(), default=str)
            subscribers = await self._redis.publish(self._redis_channel, message)
            logger.debug(f"Signal published to Redis (subscribers={subscribers})")
            return True
        except Exception as e:
            logger.error(f"Failed to publish to Redis: {e}")
            return False

    # ═══════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════

    def get_stats(self) -> dict[str, Any]:
        """Get monitoring statistics."""
        return {
            **self._stats,
            "running": self._running,
            "channels": len(self._channels),
            "extraction_rate": (
                self._stats["signals_extracted"] / self._stats["messages_received"]
                if self._stats["messages_received"] > 0
                else 0
            ),
        }

    @classmethod
    async def generate_session_string(
        cls,
        api_id: int,
        api_hash: str,
        phone: str,
    ) -> str:
        """
        Generate a session string for containerized deployment.

        Shortcut to TelegramClient.generate_session_string().
        """
        return await TelegramClient.generate_session_string(api_id, api_hash, phone)

    # ═══════════════════════════════════════════════════════════════
    # CONTEXT MANAGER
    # ═══════════════════════════════════════════════════════════════

    async def __aenter__(self) -> "TelegramSpy":
        """Async context manager entry."""
        # Don't start automatically - let user call start()
        return self

    async def __aexit__(
        self, exc_type: Any, exc_val: Any, exc_tb: Any
    ) -> None:
        """Async context manager exit."""
        await self.stop()
