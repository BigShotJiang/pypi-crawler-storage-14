from .synthetic2 import SyntheticDataset2, SyntheticDataset2Discrete

__all__ = ["SyntheticDataset2", "SyntheticDataset2Discrete"]
