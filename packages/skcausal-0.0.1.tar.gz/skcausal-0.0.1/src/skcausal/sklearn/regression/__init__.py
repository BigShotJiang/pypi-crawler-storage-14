from .local_linear_regression import LocalLinearRegression

__all__ = ["LocalLinearRegression"]
