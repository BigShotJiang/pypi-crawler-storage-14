from typing import Optional
class Credential:
    """认证信息"""
    def __init__(self, ak: str, sk : str):
        self.ak = ak
        self.sk = sk