"""File System Skill - Provides file system access capabilities."""
from .skill import FileSystemSkill

__all__ = ["FileSystemSkill"]
