"""
KRN Harmony Adapter - 鸿蒙适配自动化工具
"""

__version__ = "1.0.93"
__author__ = "continue919"
__email__ = "526086554@qq.com"