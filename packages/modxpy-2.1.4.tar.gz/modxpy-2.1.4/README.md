### **🌟 ModXPy — The Python Module Universe at Your Fingertips**



Welcome to ModXPy, the ultimate playground for Python’s modules.  
With ModXPy you can instantly import, explore, and experiment with the entire Python standard library — plus any installed third-party modules — all from one simple interface.



#### UPDATE 2.1.4



###### importrandom() upgrade 2:



Improved new argument to control dependency

leaking (strict\_mode).

Removed allow\_duplicates as it is not very

useful.



Explanation of why importrandom() used to 

leak some modules:



Let's say that when someone runs importrandom()

the modules get chosen from a random list, modules.

Let's say that this list includes 2 modules called

a and b. b is a dependency to a. Let's say that

importrandom() imported a. Since b is a dependency, 

b also gets imported, but if importrandom() picked

module b after a got imported, since b is already

imported by a, Python goes "Oh, well b is already

imported, so I get we'll skip it." Thus, this

results in less modules imported than you expected.



New argument for importrandom(), strict\_mode can 

control this behavior.



strict\_mode = False(default): Allow above behavior

to pass, may import less than you expect.



strict\_mode = True: Force import modules until exactly

n amount of NEW modules are imported, no more no less

(unless all modules were imported)



###### Examples:



importrandom(n, strict\_mode, print\_imported)



modx.importrandom(50, False, True)

Output: "Successfully imported 48 random modules (normal mode)"

(Leaked 2 due to some dependencies)



modx.importrandom(50, True, True)

 Output: "Successfully imported 50 new modules (strict mode)"

 (Force imported 50 new modules.)



#### 🚀 Installation and Importing



Install directly from terminal.

Type: "pip install modxpy"



In Python, import as import modx (not modxpy)



#### Functions:



🔹 importall(show\_imported=False)

Imports about every standard library module at once.



🔹 importrandom(n, strict\_mode = False, show\_imported = False)

Import n random stndlib modules.

strict\_mode=False: import n modules, some may leak due to dependencies.

strict\_mode=True : Force import until EXACTLY n NEW modules.



🔹 importletter(letter, show\_imported=False)

Imports all standard library modules whose names start with the given letter.



🔹 importexternal(show\_imported=False)

Attempts to import every third-party module you currently have installed.



🔹 importscreen(show\_imported=False)

Imports every module that uses a screen/GUI (like pygame or turtle).



🔹 listimportall()

Returns a list of modules that would be imported by import\_all().



🔹 modsloaded()

Shows how many modules you currently have downloaded on your device.



🔹 imported()

Lists the modules imported since ModX loaded (user + ModX), including dependencies.



🔹 modximported()

Lists the modules that were ONLY imported by ModX, NOT including user imports

and dependencies.



🔹 importletter(letter)

Import every standard library module from the ModX 'modules' list
whose name starts with the given letter (case-insensitive).



🔹 searchmodules(keyword)

Search for modules whose names contain the keyword.



🔹 info(module\_name)

Shows basic info about typed module: file path, built-in status, docstring.



🔹 isimported(module)

Checks if module is currently imported into Python Shell (Not Pythonlib)



🔹 dependencies()

Shows what other modules a specific module depends on without importing it.



🔹 vcompat(module\_name, python\_version)

Checks if a module is compatible with a python version, if a version was given.



🔹 modfunctions(module)

Show how many and what functions a module has without importing it.



🔹 modxhelp()

Shows ModX's built in help dialogue.



🔹 modclasses(module)

Show how many and what classes a module has without importing it.



🔹 modorigin(module)

Shows where a module came from (e.g. built-in, stndlib or pip-installed).



🔹 modbench(n)

Shows how much time and memory a module takes to import
(typed modules DOES get imported)



🔹 revdeps(module)

Shows what modules import typed module without importing it.



🔹 modglobals(module)

Show a module's global names (not functions/classes/modules);

optional private names and Markdown export (may import typed module).



🔹 nonimported():

    Returns a list of STANDARD LIBRARY

modules that have NOT been imported yet."""



#### 💡 Why Use ModX?



1.) Explore the Python standard library in seconds
2.) Stress-test your environment by bulk importing modules
3.) See hidden dependencies that load behind the scenes
4.) Experiment with random imports for fun or testing
5.) Discover new modules you didn’t know existed



ModXPy turns Python’s module system into a playground —
perfect for learning, testing, or just satisfying your curiosity.
Install it today with pip install modxpy, import it with import modx,
and start discovering how many modules Python already has waiting for you!

