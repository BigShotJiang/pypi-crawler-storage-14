"""Vulture whitelist for false positives in dead code detection."""

# LanguageConfig dataclass fields - used via instance attribute access
_.fallback_command
_.fallback_env
_.fallback_via_file
_.fallback_file_arg
_.fallback_file_suffix
