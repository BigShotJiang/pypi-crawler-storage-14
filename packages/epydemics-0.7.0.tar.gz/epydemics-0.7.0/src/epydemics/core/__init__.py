"""Core module for epydemics package."""

from . import config

__all__ = ["config"]