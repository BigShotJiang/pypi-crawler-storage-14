import json
import random
import re
import string
from datetime import datetime

import boto3
import requests
from botocore.exceptions import ClientError


def extract(s, partten, value):
    match = re.search(partten, s, re.IGNORECASE)
    return match.group(1) if match else value


def generate_random_str(length=10):
    chars = string.ascii_letters + string.digits
    random_str = "".join(random.choice(chars) for _ in range(length))
    return random_str


def get_api_key(secretId):
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name="us-east-1")

    try:
        api_response = client.get_secret_value(SecretId=secretId)
        print("getting secrets", api_response["SecretString"])
        return api_response["SecretString"]
    except ClientError as e:
        raise e


def geocode_address(address, key):
    if not key:
        print("Error: GOOGLE_MAPS_API_KEY is not set in environment variables.")
        return None, None

    if not address:
        return None, None

    base_url = "https://maps.googleapis.com/maps/api/geocode/json"
    params = {"address": address, "key": key}

    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        data = response.json()

        if data["status"] == "OK" and len(data["results"]) > 0:
            location = data["results"][0]["geometry"]["location"]
            return round(location["lat"], 6), round(location["lng"], 6)
        else:
            print(
                f"Geocoding API error for address '{address}': Status: {data.get('status')}, Message: {data.get('error_message')}"
            )
            return None, None

    except requests.exceptions.RequestException as e:
        print(f"Error calling Geocoding API for address '{address}': {e}")
        return None, None


def send_sqs_message(charger_id, status, queue_url):
    sqs = boto3.client("sqs")
    message_body = json.dumps(
        {
            "order_id": charger_id,
            "status": status,
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }
    )
    sqs.send_message(
        QueueUrl=queue_url,
        MessageBody=message_body,
        MessageAttributes={
            "OrderId": {"DataType": "String", "StringValue": charger_id},
            "Status": {"DataType": "String", "StringValue": status},
        },
    )


def update_order_status(record_id, url, status):
    headers = {"Content-Type": "application/json"}
    response = requests.post(
        url + record_id + "/update_status/", headers=headers, json={
            "status": status
        }
    )
    response.raise_for_status()
    return response.json()


def update_charger_status(charger_id, url, status):
    headers = {"Content-Type": "application/json"}
    response = requests.post(
        url + charger_id + "/update_status/", headers=headers,
        json={
            "status": status
        }
    )
    response.raise_for_status()
    return response.json()
