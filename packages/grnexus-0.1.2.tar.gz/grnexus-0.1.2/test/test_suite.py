#!/usr/bin/env python3
"""
Test Suite Master - GRNexus
Ejecuta todos los tests disponibles desde una interfaz unificada

Copyright (C) 2024 GR Code Digital Solutions
Licenciado bajo GPL v3
"""

import sys
import os
import subprocess

try:
    import flet as ft
    FLET_DISPONIBLE = True
except ImportError:
    FLET_DISPONIBLE = False
    print("❌ Flet no está instalado")
    print("   Instala con: pip install flet")


# Tests disponibles
TESTS = [
    {
        "nombre": "Reconocimiento de Dígitos",
        "descripcion": "Dibuja dígitos y entrena la red en tiempo real",
        "archivo": "test_digitos.py",
        "icon": "✏️",
        "color": ft.Colors.BLUE_700
    },
    {
        "nombre": "Análisis de Sentimientos",
        "descripcion": "Clasifica reseñas de películas como positivas o negativas",
        "archivo": "test_sentiment.py",
        "icon": "🎬",
        "color": ft.Colors.PURPLE_700
    },
    {
        "nombre": "Clasificación de Flores Iris",
        "descripcion": "Clasifica flores en 3 especies usando medidas reales",
        "archivo": "test_iris.py",
        "icon": "🌸",
        "color": ft.Colors.PINK_700
    },
    {
        "nombre": "Predicción de Precios de Casas",
        "descripcion": "Predice precios basándose en características de la propiedad",
        "archivo": "test_housing.py",
        "icon": "🏠",
        "color": ft.Colors.GREEN_700
    },
]


def main(page: ft.Page):
    """Aplicación principal del test suite"""
    
    if not FLET_DISPONIBLE:
        return
    
    page.title = "GRNexus Test Suite"
    page.window_width = 900
    page.window_height = 700
    page.padding = 30
    page.theme_mode = ft.ThemeMode.DARK
    page.scroll = ft.ScrollMode.AUTO
    
    # Header
    header = ft.Container(
        content=ft.Column([
            ft.Text(
                "🧠 GRNexus Test Suite",
                size=40,
                weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER
            ),
            ft.Text(
                "Suite completa de pruebas para el framework GRNexus",
                size=16,
                color=ft.Colors.GREY_400,
                text_align=ft.TextAlign.CENTER
            ),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        padding=20,
        bgcolor=ft.Colors.with_opacity(0.1, ft.Colors.BLUE),
        border_radius=10,
        margin=ft.margin.only(bottom=20)
    )
    
    # Info del framework
    info_card = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Icon(ft.Icons.INFO_OUTLINE, color=ft.Colors.BLUE_400, size=30),
                ft.Text("Información del Framework", size=20, weight=ft.FontWeight.BOLD)
            ], spacing=10),
            ft.Divider(height=1, color=ft.Colors.GREY_700),
            ft.Text("✅ Nueva API con compile() y fit()", size=14),
            ft.Text("✅ Formato .nexus para modelos", size=14),
            ft.Text("✅ Optimizadores: SGD, Adam, RMSprop", size=14),
            ft.Text("✅ Múltiples capas y activaciones", size=14),
            ft.Text("✅ Dropout y Batch Normalization", size=14),
        ], spacing=8),
        padding=20,
        bgcolor=ft.Colors.with_opacity(0.05, ft.Colors.BLUE),
        border_radius=10,
        margin=ft.margin.only(bottom=20)
    )
    
    def ejecutar_test(archivo):
        """Ejecuta un test específico"""
        test_path = os.path.join(os.path.dirname(__file__), archivo)
        
        if not os.path.exists(test_path):
            page.snack_bar = ft.SnackBar(
                content=ft.Text(f"❌ Archivo no encontrado: {archivo}"),
                bgcolor=ft.Colors.RED_700
            )
            page.snack_bar.open = True
            page.update()
            return
        
        try:
            # Ejecutar el test en un proceso separado
            subprocess.Popen([sys.executable, test_path])
            
            page.snack_bar = ft.SnackBar(
                content=ft.Text(f"✅ Ejecutando: {archivo}"),
                bgcolor=ft.Colors.GREEN_700
            )
            page.snack_bar.open = True
            page.update()
        except Exception as ex:
            page.snack_bar = ft.SnackBar(
                content=ft.Text(f"❌ Error: {str(ex)}"),
                bgcolor=ft.Colors.RED_700
            )
            page.snack_bar.open = True
            page.update()
    
    # Crear tarjetas para cada test
    test_cards = []
    for test in TESTS:
        card = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text(test["icon"], size=40),
                    ft.Column([
                        ft.Text(
                            test["nombre"],
                            size=20,
                            weight=ft.FontWeight.BOLD
                        ),
                        ft.Text(
                            test["descripcion"],
                            size=12,
                            color=ft.Colors.GREY_400
                        ),
                    ], spacing=2, expand=True),
                ], spacing=15),
                ft.Divider(height=1, color=ft.Colors.GREY_700),
                ft.Row([
                    ft.Text(f"📄 {test['archivo']}", size=11, color=ft.Colors.GREY_500),
                    ft.ElevatedButton(
                        "▶️ Ejecutar",
                        on_click=lambda e, archivo=test["archivo"]: ejecutar_test(archivo),
                        style=ft.ButtonStyle(
                            bgcolor=test["color"],
                            color=ft.Colors.WHITE
                        )
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], spacing=10),
            padding=20,
            bgcolor=ft.Colors.with_opacity(0.05, test["color"]),
            border=ft.border.all(2, test["color"]),
            border_radius=10,
            margin=ft.margin.only(bottom=15),
            on_hover=lambda e, card=None: hover_effect(e, card) if card else None
        )
        
        # Guardar referencia para el hover
        original_card = card
        card.on_hover = lambda e, c=card: hover_effect(e, c)
        
        test_cards.append(card)
    
    def hover_effect(e, card):
        """Efecto hover para las tarjetas"""
        if e.data == "true":
            card.elevation = 8
            card.scale = 1.02
        else:
            card.elevation = 0
            card.scale = 1.0
        page.update()
    
    # Botón para ejecutar todos
    def ejecutar_todos(e):
        """Ejecuta todos los tests"""
        for test in TESTS:
            ejecutar_test(test["archivo"])
    
    btn_ejecutar_todos = ft.ElevatedButton(
        "▶️ Ejecutar Todos los Tests",
        on_click=ejecutar_todos,
        style=ft.ButtonStyle(
            bgcolor=ft.Colors.ORANGE_700,
            color=ft.Colors.WHITE,
            padding=20
        ),
        icon=ft.Icons.PLAY_CIRCLE_FILLED,
        height=50,
        expand=True
    )
    
    # Footer
    footer = ft.Container(
        content=ft.Column([
            ft.Divider(height=1, color=ft.Colors.GREY_700),
            ft.Text(
                "GRNexus Neural Network Framework v2.0",
                size=12,
                color=ft.Colors.GREY_500,
                text_align=ft.TextAlign.CENTER
            ),
            ft.Text(
                "Copyright © 2024 GR Code Digital Solutions",
                size=10,
                color=ft.Colors.GREY_600,
                text_align=ft.TextAlign.CENTER
            ),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5),
        margin=ft.margin.only(top=20)
    )
    
    # Layout principal
    page.add(
        header,
        info_card,
        ft.Text("📋 Tests Disponibles:", size=24, weight=ft.FontWeight.BOLD),
        *test_cards,
        btn_ejecutar_todos,
        footer
    )


if __name__ == "__main__":
    if FLET_DISPONIBLE:
        print("\n🧠 GRNexus Test Suite")
        print(f"   {len(TESTS)} tests disponibles\n")
        ft.app(target=main)
    else:
        print("\n❌ Error: Flet no instalado")
        print("   Instala con: pip install flet")
