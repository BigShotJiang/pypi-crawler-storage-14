
from quadrilateral_interpolation import QuadInterpolationResampler


def test_interpolation():
    interpolator = QuadInterpolationResampler(None, None)
    