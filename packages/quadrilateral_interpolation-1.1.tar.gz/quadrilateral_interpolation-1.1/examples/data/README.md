

To run the notebook, download and unzip here the content of the archive S3A_OL_1_EFR____20170813T130925_20170813T131225_20180706T214618_0180_021_081_1980_LR2_R_NT_002.SEN3.zip or any other OLCI archive from Greenland.

It can be downloaded from: https://finder.creodias.eu/#

In the "path" input enter: "S3A_OL_1_EFR____20170813T130925_20170813T131225_20180706T214618_0180_021_081_1980_LR2_R_NT_002.SEN3"

