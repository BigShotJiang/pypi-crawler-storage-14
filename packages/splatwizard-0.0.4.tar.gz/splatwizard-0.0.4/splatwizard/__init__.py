"""
CompressGS - Gaussian Splatting Compression Implementation
"""

__version__ = "0.1.0" 