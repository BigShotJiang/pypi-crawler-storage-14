# Differential Gaussian Rasterization used for compression

Used as the rasterization engine for the paper "LightGaussian: Unbounded 3D Gaussian Compression with 15x Reduction and 200+ FPS". 
Based on the excellent Rasterization engine in the 3D Gaussian Splatting. [diff-gaussian-rasterization](https://github.com/graphdeco-inria/diff-gaussian-rasterization) 


