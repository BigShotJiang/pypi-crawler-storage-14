Rasterizer from Trim 3D Gaussian Splatting for Accurate Geometry Representation

https://github.com/Abyssaledge/diff-gaussian-rasterization/tree/587901969dfdec6fdefd71b3f3a091f7ef84ade7