from .middleware import UrlVarsMiddleware #noqa
