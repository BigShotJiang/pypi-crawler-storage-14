default_app_config = "django_project_base.celery.apps.DjangoProjectBaseCeleryConfig"
