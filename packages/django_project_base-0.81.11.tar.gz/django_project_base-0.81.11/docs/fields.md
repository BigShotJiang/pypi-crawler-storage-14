# Fields

## HEXColorField

Field with validator for color in hex format, currently used for setting background color for Tags.



