from pybinwalk.main import basic_scan
