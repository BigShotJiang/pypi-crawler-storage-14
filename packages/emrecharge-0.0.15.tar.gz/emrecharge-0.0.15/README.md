# EM Recharge

Install the package using pip

```
    pip install emrecharge
```

## Development Install

```
    pip install -r requirements_dev.txt
```
