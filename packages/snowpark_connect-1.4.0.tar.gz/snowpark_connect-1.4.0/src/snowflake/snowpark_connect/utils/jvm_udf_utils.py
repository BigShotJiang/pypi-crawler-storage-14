#
# Copyright (c) 2012-2025 Snowflake Computing Inc. All rights reserved.
#

from dataclasses import dataclass
from enum import Enum
from typing import List

from snowflake import snowpark
from snowflake.snowpark_connect.resources_initializer import RESOURCE_PATH


@dataclass(frozen=True)
class Param:
    """
    Represents a function parameter with name and data type.

    Attributes:
        name: Parameter name
        data_type: Parameter data type as a string
    """

    name: str
    data_type: str


@dataclass(frozen=True)
class NullHandling(str, Enum):
    """
    Enumeration for UDF null handling behavior.

    Determines how the UDF behaves when input parameters contain null values.
    """

    RETURNS_NULL_ON_NULL_INPUT = "RETURNS NULL ON NULL INPUT"
    CALLED_ON_NULL_INPUT = "CALLED ON NULL INPUT"


@dataclass(frozen=True)
class ReturnType:
    """
    Represents the return type of a function.

    Attributes:
        data_type: Return data type as a string
    """

    data_type: str


@dataclass(frozen=True)
class Signature:
    """
    Represents a function signature with parameters and return type.

    Attributes:
        params: List of function parameters
        returns: Function return type
    """

    params: List[Param]
    returns: ReturnType


def build_jvm_udxf_imports(
    session: snowpark.Session, payload: bytes, udf_name: str, is_map_return: bool
) -> List[str]:
    """
    Build the list of imports needed for the JVM UDxF.

    This function:
    1. Saves the UDF payload to a binary file in the session stage
    2. Collects user-uploaded JAR files from the stage
    3. Returns a list of all required JAR files for the UDxF

    Args:
        session: Snowpark session
        payload: Binary payload containing the serialized Scala UDF
        udf_name: Name of the Scala UDF (used for the binary file name)
        is_map_return: Indicates if the UDxF returns a Map (affects imports)

    Returns:
        List of JAR file paths to be imported by the UDxF
    """
    # Save pciudf._payload to a bin file:
    import io

    payload_as_stream = io.BytesIO(payload)
    stage = session.get_session_stage()
    stage_resource_path = stage + RESOURCE_PATH
    closure_binary_file = stage_resource_path + "/scala/bin/" + udf_name + ".bin"
    session.file.put_stream(
        payload_as_stream,
        closure_binary_file,
        overwrite=True,
    )

    # Format the user jars to be used in the IMPORTS clause of the stored procedure.
    return [
        closure_binary_file,
        f"{stage_resource_path}/spark-connect-client-jvm_2.12-3.5.6.jar",
        f"{stage_resource_path}/spark-common-utils_2.12-3.5.6.jar",
        f"{stage_resource_path}/spark-sql_2.12-3.5.6.jar",
        f"{stage_resource_path}/json4s-ast_2.12-3.7.0-M11.jar",
        f"{stage_resource_path}/sas-scala-udf_2.12-0.2.0.jar",
        f"{stage_resource_path}/scala-reflect-2.12.18.jar",  # Required for deserializing Scala lambdas
    ] + list(session._artifact_jars)
