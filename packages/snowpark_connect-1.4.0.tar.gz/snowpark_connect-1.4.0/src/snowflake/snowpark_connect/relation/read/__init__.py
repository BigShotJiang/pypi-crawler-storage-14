#
# Copyright (c) 2012-2025 Snowflake Computing Inc. All rights reserved.
#

from .map_read import map_read

__all__ = ["map_read"]
