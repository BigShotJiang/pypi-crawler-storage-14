#
# Copyright (c) 2012-2025 Snowflake Computing Inc. All rights reserved.
#

"""
Remote Spark Connect Server for Snowpark Connect.

Lightweight servicer that forwards Spark Connect requests to Snowflake backend
via REST API using SparkConnectResource SDK.
"""

import logging
import uuid
from typing import Iterator

import grpc
import pyarrow as pa
from google.rpc import code_pb2
from grpc_status import rpc_status
from pyspark.sql.connect.proto import base_pb2, base_pb2_grpc, types_pb2
from snowflake.core.spark_connect._spark_connect import SparkConnectResource

from snowflake.snowpark import Session
from snowflake.snowpark_connect.client.exceptions import (
    GrpcErrorStatusException,
    UnexpectedResponseException,
)
from snowflake.snowpark_connect.client.query_results import (
    fetch_query_result_as_arrow_batches,
    fetch_query_result_as_protobuf,
)
from spark.connect import envelope_pb2

logger = logging.getLogger(__name__)


def _log_and_return_error(
    err_mesg: str,
    error: Exception,
    status_code: grpc.StatusCode,
    context: grpc.ServicerContext,
) -> None:
    """Log error and set gRPC context."""
    context.set_details(str(error))
    context.set_code(status_code)
    logger.error(f"{err_mesg} status code: {status_code}", exc_info=True)
    return None


def _validate_response_type(
    resp_envelope: envelope_pb2.ResponseEnvelope, expected_field: str
) -> None:
    """Validate that response envelope has expected type."""
    field_name = resp_envelope.WhichOneof("response_type")
    if field_name != expected_field:
        raise UnexpectedResponseException(
            f"Expected response type {expected_field}, got {field_name}"
        )


def _build_result_complete_response(
    request: base_pb2.ExecutePlanRequest,
) -> base_pb2.ExecutePlanResponse:
    return base_pb2.ExecutePlanResponse(
        session_id=request.session_id,
        operation_id=request.operation_id or "0",
        result_complete=base_pb2.ExecutePlanResponse.ResultComplete(),
    )


def _build_exec_plan_resp_stream_from_df_query_result(
    request: base_pb2.ExecutePlanRequest,
    session: Session,
    query_result: envelope_pb2.DataframeQueryResult,
) -> Iterator[base_pb2.ExecutePlanResponse]:
    query_id = query_result.result_job_uuid
    arrow_schema = pa.ipc.read_schema(pa.BufferReader(query_result.arrow_schema))
    spark_schema = types_pb2.DataType()
    spark_schema.ParseFromString(query_result.spark_schema)

    for row_count, arrow_batch_bytes in fetch_query_result_as_arrow_batches(
        session, query_id, arrow_schema
    ):
        yield base_pb2.ExecutePlanResponse(
            session_id=request.session_id,
            operation_id=request.operation_id or "0",
            arrow_batch=base_pb2.ExecutePlanResponse.ArrowBatch(
                row_count=row_count,
                data=arrow_batch_bytes,
            ),
            schema=spark_schema,
        )

    yield _build_result_complete_response(request)


def _build_exec_plan_resp_stream_from_resp_envelope(
    request: base_pb2.ExecutePlanRequest,
    session: Session,
    resp_envelope: envelope_pb2.ResponseEnvelope,
) -> Iterator[base_pb2.ExecutePlanResponse]:
    """Build execution plan response stream from response envelope."""
    resp_type = resp_envelope.WhichOneof("response_type")

    if resp_type == "dataframe_query_result":
        query_result = resp_envelope.dataframe_query_result
        yield from _build_exec_plan_resp_stream_from_df_query_result(
            request, session, query_result
        )
    elif resp_type == "execute_plan_response":
        yield resp_envelope.execute_plan_response
        yield _build_result_complete_response(request)
    elif resp_type == "status":
        raise GrpcErrorStatusException(resp_envelope.status)
    else:
        logger.warning(f"Unexpected response type: {resp_type}")


class SnowflakeConnectClientServicer(base_pb2_grpc.SparkConnectServiceServicer):
    def __init__(self, snowpark_session: Session) -> None:
        self.snowpark_session = snowpark_session

    def _get_spark_resource(self) -> SparkConnectResource:
        return SparkConnectResource(self.snowpark_session)

    def _parse_response_envelope(
        self, response_bytes: bytes | bytearray, expected_resp_type: str = None
    ) -> envelope_pb2.ResponseEnvelope:
        """Parse and validate response envelope from GS backend."""

        resp_envelope = envelope_pb2.ResponseEnvelope()
        if isinstance(response_bytes, bytearray):
            response_bytes = bytes(response_bytes)
        resp_envelope.ParseFromString(response_bytes)

        resp_type = resp_envelope.WhichOneof("response_type")
        if resp_type == "status":
            raise GrpcErrorStatusException(resp_envelope.status)

        if not resp_envelope.query_id and not resp_type == "dataframe_query_result":
            _validate_response_type(resp_envelope, expected_resp_type)

        return resp_envelope

    def ExecutePlan(
        self, request: base_pb2.ExecutePlanRequest, context: grpc.ServicerContext
    ) -> Iterator[base_pb2.ExecutePlanResponse]:
        """Execute a Spark plan by forwarding to GS backend."""
        logger.debug("Received Execute Plan request")
        query_id = None

        try:
            spark_resource = self._get_spark_resource()
            response_bytes = spark_resource.execute_plan(request.SerializeToString())
            resp_envelope = self._parse_response_envelope(
                response_bytes, "execute_plan_response"
            )
            query_id = resp_envelope.query_id

            if query_id:
                job_res_envelope = fetch_query_result_as_protobuf(
                    self.snowpark_session, resp_envelope.query_id
                )
                yield from _build_exec_plan_resp_stream_from_resp_envelope(
                    request, self.snowpark_session, job_res_envelope
                )
            else:
                yield from _build_exec_plan_resp_stream_from_resp_envelope(
                    request, self.snowpark_session, resp_envelope
                )

        except GrpcErrorStatusException as e:
            context.abort_with_status(rpc_status.to_status(e.status))
        except Exception as e:
            logger.error(f"Error in ExecutePlan, query id {query_id}", exc_info=True)
            return _log_and_return_error(
                "Error in ExecutePlan call", e, grpc.StatusCode.INTERNAL, context
            )

    def Config(
        self, request: base_pb2.ConfigRequest, context: grpc.ServicerContext
    ) -> base_pb2.ConfigResponse:
        logger.debug("Received Config request")
        query_id = None

        try:
            spark_resource = self._get_spark_resource()
            response_bytes = spark_resource.config(request.SerializeToString())
            resp_envelope = self._parse_response_envelope(
                response_bytes, "config_response"
            )

            query_id = resp_envelope.query_id

            if query_id:
                resp_envelope = fetch_query_result_as_protobuf(
                    self.snowpark_session, resp_envelope.query_id
                )
                assert resp_envelope.WhichOneof("response_type") == "config_response"

            return resp_envelope.config_response

        except GrpcErrorStatusException as e:
            context.abort_with_status(rpc_status.to_status(e.status))
        except Exception as e:
            logger.error(f"Error in Config, query id {query_id}", exc_info=True)
            return _log_and_return_error(
                "Error in Config call", e, grpc.StatusCode.INTERNAL, context
            )

    def AnalyzePlan(
        self, request: base_pb2.AnalyzePlanRequest, context: grpc.ServicerContext
    ) -> base_pb2.AnalyzePlanResponse:
        logger.debug("Received Analyze Plan request")
        query_id = None

        try:
            spark_resource = self._get_spark_resource()
            response_bytes = spark_resource.analyze_plan(request.SerializeToString())
            resp_envelope = self._parse_response_envelope(
                response_bytes, "analyze_plan_response"
            )

            query_id = resp_envelope.query_id

            if query_id:
                resp_envelope = fetch_query_result_as_protobuf(
                    self.snowpark_session, query_id
                )
                assert (
                    resp_envelope.WhichOneof("response_type") == "analyze_plan_response"
                )

            return resp_envelope.analyze_plan_response

        except GrpcErrorStatusException as e:
            context.abort_with_status(rpc_status.to_status(e.status))
        except Exception as e:
            logger.error(f"Error in AnalyzePlan, query id {query_id}", exc_info=True)
            return _log_and_return_error(
                "Error in AnalyzePlan call", e, grpc.StatusCode.INTERNAL, context
            )

    def AddArtifacts(
        self,
        request_iterator: Iterator[base_pb2.AddArtifactsRequest],
        context: grpc.ServicerContext,
    ) -> base_pb2.AddArtifactsResponse:
        logger.debug("Received AddArtifacts request")
        add_artifacts_response = None

        spark_resource = self._get_spark_resource()

        for request in request_iterator:
            query_id = None
            try:
                response_bytes = spark_resource.add_artifacts(
                    request.SerializeToString()
                )
                resp_envelope = self._parse_response_envelope(
                    response_bytes, "add_artifacts_response"
                )

                query_id = resp_envelope.query_id

                if query_id:
                    resp_envelope = fetch_query_result_as_protobuf(
                        self.snowpark_session, query_id
                    )
                    assert (
                        resp_envelope.WhichOneof("response_type")
                        == "add_artifacts_response"
                    )

                add_artifacts_response = resp_envelope.add_artifacts_response

            except GrpcErrorStatusException as e:
                context.abort_with_status(rpc_status.to_status(e.status))
            except Exception as e:
                logger.error(
                    f"Error in AddArtifacts, query id {query_id}", exc_info=True
                )
                return _log_and_return_error(
                    "Error in AddArtifacts call", e, grpc.StatusCode.INTERNAL, context
                )

        if add_artifacts_response is None:
            raise ValueError("AddArtifacts received empty request_iterator")

        return add_artifacts_response

    def ArtifactStatus(
        self, request: base_pb2.ArtifactStatusesRequest, context: grpc.ServicerContext
    ) -> base_pb2.ArtifactStatusesResponse:
        """Check statuses of artifacts in the session and returns them in a [[ArtifactStatusesResponse]]"""
        logger.debug("Received ArtifactStatus request")
        query_id = None

        try:
            spark_resource = self._get_spark_resource()
            response_bytes = spark_resource.artifact_status(request.SerializeToString())
            resp_envelope = self._parse_response_envelope(
                response_bytes, "artifact_status_response"
            )

            query_id = resp_envelope.query_id

            if query_id:
                resp_envelope = fetch_query_result_as_protobuf(
                    self.snowpark_session, query_id
                )
                assert (
                    resp_envelope.WhichOneof("response_type")
                    == "artifact_status_response"
                )

            return resp_envelope.artifact_status_response
        except GrpcErrorStatusException as e:
            context.abort_with_status(rpc_status.to_status(e.status))
        except Exception as e:
            logger.error(f"Error in ArtifactStatus, query id {query_id}", exc_info=True)
            return _log_and_return_error(
                "Error in ArtifactStatus call", e, grpc.StatusCode.INTERNAL, context
            )

    def Interrupt(
        self, request: base_pb2.InterruptRequest, context: grpc.ServicerContext
    ) -> base_pb2.InterruptResponse:
        """Interrupt running executions."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method Interrupt not implemented!")
        raise NotImplementedError("Method Interrupt not implemented!")

    def ReleaseExecute(
        self, request: base_pb2.ReleaseExecuteRequest, context: grpc.ServicerContext
    ) -> base_pb2.ReleaseExecuteResponse:
        """Release an execution."""
        logger.debug("Received Release Execute request")
        try:
            return base_pb2.ReleaseExecuteResponse(
                session_id=request.session_id,
                operation_id=request.operation_id or str(uuid.uuid4()),
            )
        except Exception as e:
            logger.error("Error in ReleaseExecute", exc_info=True)
            return _log_and_return_error(
                "Error in ReleaseExecute call", e, grpc.StatusCode.INTERNAL, context
            )

    def ReattachExecute(
        self, request: base_pb2.ReattachExecuteRequest, context: grpc.ServicerContext
    ) -> Iterator[base_pb2.ExecutePlanResponse]:
        """Reattach to an existing reattachable execution.
        The ExecutePlan must have been started with ReattachOptions.reattachable=true.
        If the ExecutePlanResponse stream ends without a ResultComplete message, there is more to
        continue. If there is a ResultComplete, the client should use ReleaseExecute with
        """
        from google.rpc import status_pb2

        status = status_pb2.Status(
            code=code_pb2.UNIMPLEMENTED,
            message="Method ReattachExecute not implemented! INVALID_HANDLE.OPERATION_NOT_FOUND",
        )
        context.abort_with_status(rpc_status.to_status(status))
