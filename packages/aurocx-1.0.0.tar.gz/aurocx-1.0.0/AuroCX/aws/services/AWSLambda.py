import os
import boto3
from botocore.exceptions import ClientError

class Lambda:
    def __init__(self, region_name: str = None):
        region = region_name or os.getenv("AWS_DEFAULT_REGION", "us-east-1")
        self.client = boto3.client("lambda", region_name=region)

    def list_functions(self):
        """
        Get list of Lambda functions (same as JS listFunctions)
        """
        try:
            resp = self.client.list_functions()
            return resp.get("Functions", [])
        except ClientError as e:
            print("AWS Error:", e)
            raise
        except Exception as e:
            print("General Error:", e)
            raise
