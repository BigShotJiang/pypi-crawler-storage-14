# Vasudev CLI 🚀

Vasudev CLI is your personal AI assistant in the terminal. It helps you write code, build applications, automate tasks, and control your browser using natural language.

## Features ✨

-   **AI Chat**: Powered by Google Gemini (Flash 1.5).
-   **Natural Language Actions**:
    -   "Open Google" -> Opens browser.
    -   "Play Believer" -> Plays song on YouTube.
-   **Shell Execution**: Run commands directly via `/run <command>`.
-   **Code Writer**: Automatically detects and saves code blocks.
-   **Auto-Browser**: Toggle automatic URL opening with `/autobrowser on`.

## Installation 🛠️

1.  **Prerequisites**: Ensure you have Python installed.
2.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

## Usage 🚀

Run the CLI using the batch file:

```bash
.\vc.bat
```

### First Run
On the first run, the CLI will ask for your **Gemini API Key**.
-   It will securely save it to `~/.vasudev/config.json`.
-   You can get a key from [Google AI Studio](https://aistudio.google.com/).

### Commands
-   **Chat**: Just type your message!
-   `/help`: Show available tools.
-   `/run <cmd>`: Execute a shell command (e.g., `/run dir`).
-   `/exit`: Quit the CLI.

## Project Structure 📂

-   `src/main.py`: Main source code.
-   `vc.bat`: Launcher script.
-   `requirements.txt`: Python dependencies.

---
*Built with ❤️ by Vasudev AI*
