import os
import sys
import json
import re
import typer
import google.generativeai as genai
import questionary
import webbrowser
import subprocess
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from pyfiglet import Figlet
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables
load_dotenv()

app = typer.Typer(name="vasudev-cli", help="Vasudev CLI - Your personal assistant")
console = Console()

CONFIG_DIR = Path.home() / ".vasudev"
CONFIG_FILE = CONFIG_DIR / "config.json"

def get_config():
    config = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        except:
            pass
    
    # Env var takes precedence
    if os.getenv("GEMINI_API_KEY"):
        config["GEMINI_API_KEY"] = os.getenv("GEMINI_API_KEY")
        
    return config

def set_config(key, value):
    if not CONFIG_DIR.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    
    config = get_config()
    config[key] = value
    
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

@app.command()
def hello():
    """Say hello"""
    f = Figlet(font='slant')
    console.print(Text(f.renderText('VASUDEV CLI'), style="cyan"))
    console.print(Panel("[green]Hello from Vasudev CLI! 🚀[/green]", style="green"))

@app.command()
def ai(prompt: str = typer.Argument(None, help="Initial prompt")):
    """Interact with Gemini AI (Continuous Chat)"""
    
    # Banner
    f = Figlet(font='slant')
    console.print(Text(f.renderText('VASUDEV CLI'), style="cyan"))
    
    # API Key Handling
    config = get_config()
    api_key = config.get("GEMINI_API_KEY")
    
    if not api_key:
        console.print("[yellow]Gemini API Key is missing.[/yellow]")
        api_key = questionary.password("Please enter your Gemini API Key:").ask()
        
        if api_key:
            save = questionary.confirm("Do you want to save this key for future use?", default=True).ask()
            if save:
                set_config("GEMINI_API_KEY", api_key)
                console.print("[green]API Key saved![/green]")
            else:
                console.print("[yellow]Using key for this session only.[/yellow]")
        else:
            console.print("[red]API Key is required.[/red]")
            return

    genai.configure(api_key=api_key)
    
    # System Instruction for better persona and capabilities
    system_instruction = """
    You are Vasudev, an advanced AI CLI assistant.
    Your goal is to help the user build applications, write code, debug issues, and automate tasks.
    - When asked to write code, provide complete, runnable files.
    - If the user wants to run commands, guide them to use the /run tool.
    - If the user asks to open a website, output: [OPEN: url]
    - If the user asks to play a song or video, output: [OPEN: https://www.youtube.com/results?search_query=query]
    - Be concise, professional, and helpful.
    """
    
    # Use gemini-flash-latest
    try:
        model = genai.GenerativeModel('gemini-flash-latest', system_instruction=system_instruction)
    except:
         console.print("[red]Error initializing Gemini model.[/red]")
         return

    chat = model.start_chat(history=[])
    
    console.print(Panel(
        "[cyan]Vasudev AI Chat Started![/cyan]\n"
        "Type [bold]/help[/bold] for options.\n"
        "Type [bold]/exit[/bold] to quit.",
        title="Welcome", border_style="cyan"
    ))
    
    current_prompt = prompt
    
    while True:
        try:
            if not current_prompt:
                current_prompt = questionary.text("You:", style=questionary.Style([('qmark', 'fg:blue bold'), ('question', 'fg:blue bold')])).ask()
                    
            if current_prompt is None: # Handle Ctrl+C / Cancel in questionary
                 console.print("\n[yellow]Goodbye! 👋[/yellow]")
                 break

            if not current_prompt.strip():
                current_prompt = None
                continue

            input_text = current_prompt.strip()
            
            # Slash Commands
            if input_text.startswith('/'):
                cmd_parts = input_text.split(' ')
                cmd = cmd_parts[0].lower()
                args = cmd_parts[1:]
                
                if cmd in ['/exit', '/quit']:
                    console.print("[yellow]Goodbye! 👋[/yellow]")
                    break
                
                elif cmd in ['/help', '/tools']:
                    console.print(Panel("""
[bold]Available Tools:[/bold]
/help, /tools         - Show this menu
/exit, /quit          - Exit the chat
/clear                - Clear the screen
/browser <url>        - Open a URL in browser
/autobrowser <on|off> - Toggle auto-opening URLs
/run <command>        - Execute a shell command
                    """, title="Chat Tools", border_style="yellow"))
                    current_prompt = None
                    continue
                    
                elif cmd == '/clear':
                    console.clear()
                    current_prompt = None
                    continue
                    
                elif cmd == '/browser':
                    url = ' '.join(args)
                    if url:
                        target = url if url.startswith('http') else f'https://{url}'
                        console.print(f"[blue]Opening {target}...[/blue]")
                        webbrowser.open(target)
                    else:
                        console.print("[red]Usage: /browser <url>[/red]")
                    current_prompt = None
                    continue
                    
                elif cmd == '/autobrowser':
                    state = args[0].lower() if args else None
                    if state == 'on':
                        set_config('AUTO_OPEN_BROWSER', True)
                        console.print("[green]Auto-Browser enabled! 🌐[/green]")
                    elif state == 'off':
                        set_config('AUTO_OPEN_BROWSER', False)
                        console.print("[yellow]Auto-Browser disabled.[/yellow]")
                    else:
                        current = "ON" if get_config().get("AUTO_OPEN_BROWSER") else "OFF"
                        console.print(f"[blue]Auto-Browser is currently: {current}[/blue]")
                        console.print("[gray]Usage: /autobrowser <on|off>[/gray]")
                    current_prompt = None
                    continue

                elif cmd == '/run':
                    command_to_run = ' '.join(args)
                    if command_to_run:
                        console.print(f"[magenta]Running: {command_to_run}[/magenta]")
                        try:
                            subprocess.run(command_to_run, shell=True, check=True)
                        except subprocess.CalledProcessError as e:
                            console.print(f"[red]Command failed with error code {e.returncode}[/red]")
                        except Exception as e:
                            console.print(f"[red]Error running command: {e}[/red]")
                    else:
                        console.print("[red]Usage: /run <command>[/red]")
                    current_prompt = None
                    continue
                
                else:
                    console.print(f"[red]Unknown command: {cmd}. Type /help for options.[/red]")
                    current_prompt = None
                    continue

            # AI Processing
            console.print("") # Spacing
            
            response = chat.send_message(current_prompt, stream=True)
            full_text = ""
            
            with Live(Panel("Thinking...", title="[bold cyan]Vasudev AI 🤖[/bold cyan]", border_style="cyan"), refresh_per_second=10) as live:
                for chunk in response:
                    try:
                        text = chunk.text
                        full_text += text
                        live.update(Panel(Markdown(full_text), title="[bold cyan]Vasudev AI 🤖[/bold cyan]", border_style="cyan"))
                    except Exception:
                        pass # Skip chunks with no text (e.g. safety block)
            
            console.print("") # Spacing
            console.rule(style="dim") # Separator
            console.print("") # Spacing
            
            # Action Parsing [OPEN: url]
            actions = re.findall(r'\[OPEN: (.*?)\]', full_text)
            if actions:
                for url in actions:
                    console.print(f"[magenta]\nExecuting Action: Opening {url} 🚀[/magenta]")
                    webbrowser.open(url)

            # Auto-Browser Logic (Legacy / Fallback)
            config = get_config()
            if config.get("AUTO_OPEN_BROWSER") and not actions:
                urls = re.findall(r'(https?://[^\s]+)', full_text)
                if urls:
                    first_url = urls[0].rstrip(').,;')
                    console.print(f"[magenta]\nAuto-opening: {first_url} 🚀[/magenta]")
                    webbrowser.open(first_url)
            
            # Code Extraction Logic
            code_blocks = re.findall(r'```(\w+)?\n([\s\S]*?)```', full_text)
            if code_blocks:
                save = questionary.confirm(f"Found {len(code_blocks)} code block(s). Do you want to save them to files?", default=False).ask()
                
                if save:
                    for i, (lang, code) in enumerate(code_blocks):
                        lang = lang or 'txt'
                        ext = 'py' if lang == 'python' else 'js' if lang == 'javascript' else lang
                        default_filename = f"generated_code_{i+1}.{ext}"
                        
                        filename = questionary.text(f"Enter filename for code block {i+1} ({lang}):", default=default_filename).ask()
                        
                        if filename:
                            with open(filename, "w", encoding="utf-8") as f:
                                f.write(code)
                            console.print(f"[green]Saved to {filename}[/green]")

            current_prompt = None

        except KeyboardInterrupt:
            console.print("\n[yellow]Goodbye! 👋[/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error: {str(e)}[/red]")
            current_prompt = None

@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """
    Vasudev CLI Entry Point
    """
    if ctx.invoked_subcommand is None:
        ai(None)

if __name__ == "__main__":
    app()
