eumetsat module
===============

.. automodule:: visusat.eumetsat
   :members:
   :undoc-members:
   :show-inheritance:
