""".. include:: ./doc.md"""  # noqa: D415

from .api import detect_human_voice_activity_in_audios  # noqa: F401
