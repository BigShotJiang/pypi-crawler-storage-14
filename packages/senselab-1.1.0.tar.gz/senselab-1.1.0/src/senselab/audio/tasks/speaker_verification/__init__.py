"""Verifies whether two audio segments belong to the same speaker."""

from .speaker_verification import verify_speaker  # noqa: F401
