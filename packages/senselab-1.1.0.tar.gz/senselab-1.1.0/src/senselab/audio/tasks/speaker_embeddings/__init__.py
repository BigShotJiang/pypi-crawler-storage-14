""".. include:: ./doc.md"""  # noqa: D415

from .api import extract_speaker_embeddings_from_audios  # noqa: F401
