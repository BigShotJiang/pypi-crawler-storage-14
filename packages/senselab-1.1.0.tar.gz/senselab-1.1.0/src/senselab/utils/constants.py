"""Constants used by Senselab."""

import uuid

SENSELAB_NAMESPACE = uuid.uuid3(uuid.NAMESPACE_URL, "https://github.com/sensein/senselab")
