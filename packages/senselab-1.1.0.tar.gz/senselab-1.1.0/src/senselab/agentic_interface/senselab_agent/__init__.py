"""This is the senselab AI agentic interface."""

from .extension import AIAgentExtension
