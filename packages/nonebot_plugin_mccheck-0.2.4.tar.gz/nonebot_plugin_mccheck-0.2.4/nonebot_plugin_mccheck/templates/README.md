﻿# Minecraft CSS Framework

- Welcome to the package!

- There is a whole docs by me. Visit [https://legend077.github.io/framework-docs](https://legend077.github.io/framework-docs).

## Changes in V1.2.0

- Bug Fixes!
