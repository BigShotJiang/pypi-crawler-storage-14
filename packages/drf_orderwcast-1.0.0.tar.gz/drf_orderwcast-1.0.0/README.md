# drf-orderwcast

OrderingFilter subclass that applies functions before sorting the declared
fields.

## Using

Use inplace of OrderingFilter in views. Needs to tell the functions in a
dictionary of field name and database functions.

## views.py

```python

from django.db.models.functions import Lower

from filters import OrderingWCastFilter


class FooListView(generics.ListAPIView):
    queryset = Foo.objects.all()
    serializer_class = FooSerializer
    filter_backends = (OrderingWCastFilter,)
    ordering_fields = ['username', 'email']
    ordering_cast = {'username': Lower('username')}

```
