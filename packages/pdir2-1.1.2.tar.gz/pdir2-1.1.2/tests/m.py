a = 1
b = 2


class OOO:
    """OOO today."""

    pass


def func():
    """This is a function"""
    pass
