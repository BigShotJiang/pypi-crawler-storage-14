"""gRPC module for Telegram signal publishing."""

from .publisher import SignalPublisher

__all__ = [
    "SignalPublisher",
]
