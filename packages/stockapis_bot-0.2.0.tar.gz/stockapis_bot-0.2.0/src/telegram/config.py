"""
Telegram spy configuration models.
"""

from enum import Enum
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class SignalTypeFilter(str, Enum):
    """Signal types for filtering."""

    BUY = "BUY"
    SELL = "SELL"
    PUMP = "PUMP"
    LISTING = "LISTING"
    INFO = "INFO"


class TelegramConfig(BaseModel):
    """Telegram API configuration."""

    api_id: int = Field(..., description="Telegram API ID from my.telegram.org")
    api_hash: str = Field(
        ..., min_length=32, max_length=32, description="Telegram API hash"
    )
    phone: Optional[str] = Field(
        default=None,
        pattern=r"^\+\d{10,15}$",
        description="Phone number with country code (for interactive auth)",
    )
    session_string: Optional[str] = Field(
        default=None,
        description="Pre-authorized session string (for containerized deployment)",
    )
    session_file: Path = Field(
        default=Path("botclient.session"), description="Session file path"
    )

    @field_validator("api_hash")
    @classmethod
    def validate_api_hash(cls, v: str) -> str:
        """Ensure api_hash is lowercase hex."""
        if not all(c in "0123456789abcdef" for c in v.lower()):
            raise ValueError("api_hash must be hexadecimal")
        return v.lower()

    def has_auth_method(self) -> bool:
        """Check if authentication method is configured."""
        return bool(self.session_string or self.phone)


class ChannelConfig(BaseModel):
    """Channel monitoring configuration."""

    username: str = Field(
        ...,
        pattern=r"^@?[a-zA-Z][a-zA-Z0-9_]{4,31}$",
        description="Channel username (with or without @)",
    )
    enabled: bool = Field(default=True, description="Whether channel is active")
    signal_types: list[SignalTypeFilter] = Field(
        default=[SignalTypeFilter.BUY, SignalTypeFilter.SELL],
        description="Signal types to extract from this channel",
    )
    keywords: list[str] = Field(
        default_factory=list, description="Keywords to filter messages (include)"
    )
    exclude_keywords: list[str] = Field(
        default_factory=list, description="Keywords to exclude messages"
    )
    min_confidence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Minimum signal confidence"
    )

    @field_validator("username")
    @classmethod
    def normalize_username(cls, v: str) -> str:
        """Remove @ prefix if present."""
        return v.lstrip("@")


class TelegramSpyConfig(BaseModel):
    """Complete configuration for TelegramSpy."""

    telegram: TelegramConfig
    channels: list[ChannelConfig] = Field(default_factory=list)
    min_confidence: float = Field(
        default=0.3, ge=0.0, le=1.0, description="Global minimum confidence threshold"
    )
    publish_to_redis: bool = Field(
        default=True, description="Publish signals to Redis PubSub"
    )
    redis_channel: str = Field(
        default="trading_signals", description="Redis PubSub channel name"
    )

    @property
    def enabled_channels(self) -> list[ChannelConfig]:
        """Get only enabled channels."""
        return [c for c in self.channels if c.enabled]
