"""
Universal Logger with Rich

Shared logging system for botclient:
- Rich library for beautiful console output
- Logs saved to single logs/ folder
- Log rotation by size and time
- Colored output with timestamps
- Multiple logging levels support

Usage:
    from shared.logger import get_logger, setup_logger

    logger = get_logger(__name__)
    logger.info("Service started")
    logger.error("Something went wrong", exc_info=True)
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.logging import RichHandler
from rich.theme import Theme


# Rich console with custom theme
custom_theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "bold red",
    "critical": "bold white on red",
    "debug": "dim cyan",
    "success": "bold green",
})

console = Console(theme=custom_theme)

# Default log directory (botclient/logs/)
DEFAULT_LOG_DIR = Path(__file__).parent.parent.parent / "logs"


def setup_logger(
    name: str,
    level: int = logging.INFO,
    log_dir: Optional[Path] = None,
    log_to_file: bool = True,
    log_to_console: bool = True,
) -> logging.Logger:
    """
    Setup universal logger with Rich and file output.

    Args:
        name: Logger name (usually __name__)
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_dir: Directory for log files (default: botclient/logs/)
        log_to_file: Enable file logging
        log_to_console: Enable console logging with Rich

    Returns:
        Configured logger instance

    Example:
        ```python
        from shared.logger import setup_logger

        logger = setup_logger(__name__)
        logger.info("Service started")
        logger.error("Something went wrong", exc_info=True)
        ```
    """
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()

    # Format for file logs (detailed)
    file_formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(funcName)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 1. Console handler with Rich (beautiful output)
    if log_to_console:
        console_handler = RichHandler(
            console=console,
            show_time=True,
            show_level=True,
            show_path=True,
            rich_tracebacks=True,
            tracebacks_show_locals=True,
            markup=True,
        )
        console_handler.setLevel(level)
        logger.addHandler(console_handler)

    # 2. File handler (detailed logs saved to disk)
    if log_to_file:
        # Use provided or default log directory
        if log_dir is None:
            log_dir = DEFAULT_LOG_DIR

        log_dir.mkdir(parents=True, exist_ok=True)

        # Log file name with date
        log_file = log_dir / f"{datetime.now().strftime('%Y-%m-%d')}.log"

        # Rotating file handler (max 10 MB, keep 5 backups)
        from logging.handlers import RotatingFileHandler

        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)  # Always log DEBUG to file
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)

    # Prevent propagation to root logger
    logger.propagate = False

    return logger


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    Get or create logger with default settings.

    Args:
        name: Logger name (usually __name__)
        level: Logging level

    Returns:
        Logger instance

    Example:
        ```python
        from shared.logger import get_logger

        logger = get_logger(__name__)
        logger.info("Service started")
        ```
    """
    # Check if logger already exists and has handlers
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    # Setup new logger
    return setup_logger(name, level=level)


# Global logger instance for quick access
default_logger = setup_logger("shared", level=logging.INFO)


# Convenience functions
def info(msg: str, **kwargs) -> None:
    """Log info message."""
    default_logger.info(msg, **kwargs)


def warning(msg: str, **kwargs) -> None:
    """Log warning message."""
    default_logger.warning(msg, **kwargs)


def error(msg: str, **kwargs) -> None:
    """Log error message."""
    default_logger.error(msg, **kwargs)


def debug(msg: str, **kwargs) -> None:
    """Log debug message."""
    default_logger.debug(msg, **kwargs)


def critical(msg: str, **kwargs) -> None:
    """Log critical message."""
    default_logger.critical(msg, **kwargs)


def success(msg: str) -> None:
    """Log success message (INFO level with green color)."""
    console.print(f"[success]{msg}[/success]")
    default_logger.info(msg)
