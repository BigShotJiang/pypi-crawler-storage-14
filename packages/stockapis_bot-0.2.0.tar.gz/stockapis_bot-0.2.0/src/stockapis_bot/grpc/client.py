"""gRPC bidirectional streaming client for Django communication.

Based on botserver's BotStreamingClient but following CRITICAL_REQUIREMENTS:
- Functions < 20 lines
- Complete type annotations (no Any)
- Custom exception hierarchy
- Pydantic v2 models
"""

import asyncio
import os
import uuid
from datetime import datetime, timezone
from typing import AsyncIterator, Awaitable, Callable, Optional

import grpc
from google.protobuf.json_format import MessageToDict
from google.protobuf.timestamp_pb2 import Timestamp

from shared import get_logger

from ..exceptions import GRPCConnectionError, GRPCStreamError
from ..models.config import BotConfig, TradingParams
from ..models.enums import Direction, SignalType
from ..models.execution import ExecutionReport
from ..models.trading import TradingSignal
from .connection import ConnectionManager
from .generated import bot_streaming_service_pb2 as pb2
from .generated import bot_streaming_service_pb2_grpc as pb2_grpc

logger = get_logger(__name__)


class GRPCStreamingClient:
    """Bidirectional streaming client for bot-Django communication.

    Usage:
        client = GRPCStreamingClient(
            bot_id="uuid",
            host="grpc.stockapis.com",
            port=443,
            api_key="your-api-key",
        )
        await client.connect_and_run()
    """

    def __init__(
        self,
        bot_id: str,
        host: str = "localhost",
        port: int = 50051,
        api_key: str = "",
        use_tls: bool = False,
        heartbeat_interval: int = 30,
    ) -> None:
        """Initialize streaming client."""
        self._bot_id = bot_id
        self._host = host
        self._port = port
        self._api_key = api_key
        self._use_tls = use_tls
        self._heartbeat_interval = heartbeat_interval

        self._version = os.getenv("BOT_VERSION", "1.0.0")
        self._hostname = os.getenv("HOSTNAME", "botclient")

        self._stream: Optional[grpc.aio.StreamStreamCall[pb2.BotMessage, pb2.DjangoCommand]] = None
        self._running = False
        self._config_received = asyncio.Event()
        self._connected = False

        # Command handlers
        self.on_start: Optional[Callable[[], None]] = None
        self.on_stop: Optional[Callable[[str], None]] = None
        self.on_pause: Optional[Callable[[str], None]] = None
        self.on_resume: Optional[Callable[[], None]] = None
        self.on_config: Optional[Callable[[BotConfig], None]] = None
        self.on_signal: Optional[Callable[[TradingSignal], Awaitable[None]]] = None

        logger.info(f"Initialized GRPCStreamingClient: {host}:{port}")

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected and self._running

    @property
    def address(self) -> str:
        """Get server address."""
        return f"{self._host}:{self._port}"

    async def connect(self) -> bool:
        """Connect to server (alias for connect_and_run)."""
        try:
            await self.connect_and_run(max_retries=1)
            return True
        except GRPCConnectionError:
            return False

    async def disconnect(self) -> None:
        """Disconnect from server."""
        self._running = False
        self._connected = False
        self._stream = None
        logger.info("Disconnected from gRPC server")

    async def connect_and_run(
        self,
        max_retries: Optional[int] = None,
        initial_backoff: float = 1.0,
        max_backoff: float = 60.0,
    ) -> None:
        """Connect and run with auto-reconnect."""
        retry_count = 0
        backoff = initial_backoff

        while max_retries is None or retry_count < max_retries:
            try:
                if retry_count > 0:
                    await self._log_and_wait_retry(retry_count, backoff)

                await self._connect_once()
                break

            except GRPCConnectionError as e:
                retry_count, backoff = self._handle_connection_error(
                    e, retry_count, backoff, max_backoff, max_retries
                )
            except asyncio.CancelledError:
                logger.info("Connection cancelled")
                raise

    async def _log_and_wait_retry(self, retry_count: int, backoff: float) -> None:
        """Log retry attempt and wait."""
        logger.info(f"Reconnect attempt {retry_count} after {backoff:.1f}s...")
        await asyncio.sleep(backoff)

    def _handle_connection_error(
        self,
        error: GRPCConnectionError,
        retry_count: int,
        backoff: float,
        max_backoff: float,
        max_retries: Optional[int],
    ) -> tuple[int, float]:
        """Handle connection error and update retry state."""
        retry_count += 1
        logger.warning(f"Connection failed (attempt {retry_count}): {error}")

        if max_retries is not None and retry_count >= max_retries:
            raise error

        self._reset_connection_state()
        return retry_count, min(backoff * 2, max_backoff)

    def _reset_connection_state(self) -> None:
        """Reset connection state."""
        self._running = False
        self._connected = False
        self._stream = None
        self._config_received.clear()

    async def _connect_once(self) -> None:
        """Single connection attempt."""
        logger.info(f"Connecting to {self.address}...")
        channel = self._create_channel()

        async with channel:
            stub = pb2_grpc.BotStreamingServiceStub(channel)
            metadata = [("x-api-key", self._api_key)]

            self._stream = stub.ConnectBot(metadata=metadata)
            self._running = True
            self._connected = True

            logger.info("Connected to Django gRPC server")
            await self._send_registration()
            await self._run_tasks()

    def _create_channel(self) -> grpc.aio.Channel:
        """Create gRPC channel."""
        options = self._get_channel_options()

        if self._use_tls:
            credentials = grpc.ssl_channel_credentials()
            return grpc.aio.secure_channel(self.address, credentials, options=options)
        return grpc.aio.insecure_channel(self.address, options=options)

    def _get_channel_options(self) -> list[tuple[str, int]]:
        """Get gRPC channel options."""
        return [
            ("grpc.dns_min_time_between_resolutions_ms", 10000),
            ("grpc.keepalive_time_ms", 30000),
            ("grpc.keepalive_timeout_ms", 10000),
            ("grpc.keepalive_permit_without_calls", 1),
        ]

    async def _run_tasks(self) -> None:
        """Run heartbeat and receive tasks."""
        try:
            await asyncio.gather(
                self._send_heartbeats(),
                self._receive_commands(),
            )
        except asyncio.CancelledError:
            logger.info("Tasks cancelled")
            raise
        except GRPCConnectionError:
            raise
        finally:
            self._running = False

    async def _send_registration(self) -> None:
        """Send bot registration."""
        if self._stream is None:
            return

        msg = self._create_bot_message()
        msg.register.CopyFrom(
            pb2.RegisterRequest(
                version=self._version,
                hostname=self._hostname,
                grpc_port=0,
                supported_exchanges=["binance"],
                supported_strategies=["default"],
                metadata={},
            )
        )
        await self._stream.write(msg)
        logger.info("Registration sent")

    async def _send_heartbeats(self) -> None:
        """Send periodic heartbeats."""
        await self._config_received.wait()

        while self._running:
            await asyncio.sleep(self._heartbeat_interval)
            if not self._running:
                break
            await self._send_single_heartbeat()

    async def _send_single_heartbeat(self) -> None:
        """Send single heartbeat."""
        if self._stream is None:
            return

        try:
            msg = self._create_bot_message()
            msg.heartbeat.CopyFrom(pb2.HeartbeatUpdate())
            await self._stream.write(msg)
            logger.debug("Heartbeat sent")
        except Exception as e:
            logger.error(f"Failed to send heartbeat: {e}")

    async def _receive_commands(self) -> None:
        """Receive and handle commands."""
        if self._stream is None:
            return

        try:
            async for command in self._stream:
                if command == grpc.aio.EOF:
                    raise GRPCStreamError(
                        message="Stream closed by server",
                        code="STREAM_CLOSED",
                    )
                await self._handle_command(command)
        except grpc.aio.AioRpcError as e:
            raise GRPCConnectionError(
                message=f"gRPC error: {e.details()}",
                code="GRPC_ERROR",
            ) from e

    async def _handle_command(self, command: pb2.DjangoCommand) -> None:
        """Handle incoming command."""
        command_type = command.WhichOneof("payload")
        if command_type is None:
            return

        logger.info(f"Received {command_type.upper()} command")

        handlers = {
            "config_update": self._handle_config_update,
            "start": self._handle_start,
            "stop": self._handle_stop,
            "pause": self._handle_pause,
            "resume": self._handle_resume,
            "ping": self._handle_ping,
        }

        handler = handlers.get(command_type)
        if handler:
            await handler(command)

    async def _handle_config_update(self, command: pb2.DjangoCommand) -> None:
        """Handle config update command."""
        self._config_received.set()
        config = self._parse_config(command.config_update.config)

        if self.on_config:
            self.on_config(config)
            logger.info("Config updated")

        await self._send_command_ack(command.command_id, True, "Config updated")

    def _parse_config(self, proto_config: pb2.BotConfig) -> BotConfig:
        """Parse protobuf config to Pydantic model."""
        settings = MessageToDict(proto_config.settings) if proto_config.HasField("settings") else {}

        trading = TradingParams(
            symbol=settings.get("symbol", "BTCUSDT"),
            direction=Direction(settings.get("direction", "LONG")),
        )

        return BotConfig(
            bot_id=proto_config.id,
            name=proto_config.name,
            enabled=proto_config.enabled,
            active=proto_config.active,
            description=proto_config.description,
            trading=trading,
            custom_settings={str(k): str(v) for k, v in settings.items()},
        )

    async def _handle_start(self, command: pb2.DjangoCommand) -> None:
        """Handle start command."""
        success = False
        if self.on_start:
            self.on_start()
            success = True
        await self._send_command_ack(command.command_id, success, "Bot started")

    async def _handle_stop(self, command: pb2.DjangoCommand) -> None:
        """Handle stop command."""
        success = False
        reason = command.stop.reason if command.stop.reason else "No reason"
        if self.on_stop:
            self.on_stop(reason)
            success = True
        await self._send_command_ack(command.command_id, success, "Bot stopped")

    async def _handle_pause(self, command: pb2.DjangoCommand) -> None:
        """Handle pause command."""
        success = False
        reason = command.pause.reason if command.pause.reason else "No reason"
        if self.on_pause:
            self.on_pause(reason)
            success = True
        await self._send_command_ack(command.command_id, success, "Bot paused")

    async def _handle_resume(self, command: pb2.DjangoCommand) -> None:
        """Handle resume command."""
        success = False
        if self.on_resume:
            self.on_resume()
            success = True
        await self._send_command_ack(command.command_id, success, "Bot resumed")

    async def _handle_ping(self, command: pb2.DjangoCommand) -> None:
        """Handle ping command."""
        await self._send_single_heartbeat()

    async def _send_command_ack(
        self,
        command_id: str,
        success: bool,
        message: str,
    ) -> None:
        """Send command acknowledgment."""
        if self._stream is None or not self._running:
            return

        try:
            msg = self._create_bot_message()
            msg.command_ack.CopyFrom(
                pb2.CommandAck(
                    command_id=command_id,
                    success=success,
                    message=message,
                )
            )
            await self._stream.write(msg)
            logger.debug(f"CommandAck sent: {command_id}")
        except Exception as e:
            logger.error(f"Failed to send CommandAck: {e}")

    async def send_execution_report(self, report: ExecutionReport) -> bool:
        """Send execution report to Django."""
        if self._stream is None or not self._running:
            logger.warning("Cannot send report - stream not active")
            return False

        try:
            msg = self._create_bot_message()
            msg.execution.CopyFrom(self._create_proto_execution(report))
            await self._stream.write(msg)
            logger.info(f"ExecutionReport sent: {report.execution_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to send ExecutionReport: {e}")
            return False

    def _create_proto_execution(self, report: ExecutionReport) -> pb2.ExecutionReport:
        """Create protobuf execution report."""
        return pb2.ExecutionReport(
            execution_id=report.execution_id,
            symbol=report.symbol,
            side=report.side.value,
            order_type=report.order_type,
            quantity=report.quantity,
            price=report.price,
            filled_quantity=report.filled_quantity,
            average_price=report.average_price,
            fee=report.fee,
            fee_currency=report.fee_currency,
            status=report.status,
            exchange=report.exchange,
            exchange_order_id=report.exchange_order_id or "",
        )

    def _create_bot_message(self) -> pb2.BotMessage:
        """Create base bot message."""
        return pb2.BotMessage(
            bot_id=self._bot_id,
            message_id=str(uuid.uuid4()),
            timestamp=self._current_timestamp(),
        )

    def _current_timestamp(self) -> Timestamp:
        """Get current UTC timestamp."""
        ts = Timestamp()
        ts.FromDatetime(datetime.now(timezone.utc))
        return ts

    async def send_heartbeat(self) -> None:
        """Public method to send heartbeat."""
        await self._send_single_heartbeat()

    async def send_registration(self) -> bool:
        """Public method to send registration."""
        await self._send_registration()
        return True

    async def receive_commands(self) -> AsyncIterator[BotConfig]:
        """Receive config commands from server."""
        if self._stream is None:
            return

        async for command in self._stream:
            if command.HasField("config_update"):
                config = self._parse_config(command.config_update.config)
                yield config
