"""
BotClient SDK - Trading Bot Framework for StockAPIs.

A Python SDK for building custom trading bots that integrate with
the StockAPIs Django backend. Provides ready-made infrastructure
for exchange connections, gRPC communication, and signal handling.

Usage:
    from stockapis_bot import BotClient, TradingBot, ClientConfig
    from stockapis_bot.models import TradingSignal, SignalDecision, SignalAction

    class MyBot(TradingBot):
        async def on_signal(self, signal: TradingSignal) -> SignalDecision:
            if signal.confidence > 0.8:
                qty = await self.calculate_quantity(signal.symbol, 100, 10)
                return SignalDecision.buy(qty, "High confidence")
            return SignalDecision.skip("Low confidence")

    bot = MyBot(bot_id="my-bot", name="My Bot")
    config = ClientConfig(
        bot_id="my-bot",
        bot_name="My Bot",
        grpc=GRPCConfig(host="localhost", port=50051, api_key="..."),
        exchange=ExchangeConfig(
            api_key="...",
            api_secret="...",
            testnet=True,
        ),
    )
    client = BotClient.create(bot, config)
    await client.run()

For more examples, see: https://docs.stockapis.com/botclient
"""

__version__ = "0.2.0"

# Core classes
from .core.bot import TradingBot
from .core.client import BotClient
from .core.runner import run_bot, run_bot_sync

# Configuration models
from .models.config import (
    BotConfig,
    ClientConfig,
    ExchangeConfig,
    GRPCConfig,
    RedisConfig,
    TradingParams,
)

# Trading models
from .models.trading import (
    AccountBalance,
    Order,
    Position,
    TickerInfo,
    TradingSignal,
)

# Execution models
from .models.execution import (
    ExecutionReport,
    OrderResult,
    SignalDecision,
)

# Enums
from .models.enums import (
    BotState,
    Direction,
    MarketType,
    OrderSide,
    OrderStatus,
    OrderType,
    SignalAction,
    SignalType,
)

# Exceptions
from .exceptions import (
    BotClientError,
    BotNotRunningError,
    BusinessError,
    ConfigValidationError,
    ConnectionError,
    ExchangeAuthenticationError,
    ExchangeConnectionError,
    ExchangeError,
    GRPCConnectionError,
    GRPCStreamError,
    InsufficientBalanceError,
    InvalidSymbolError,
    OrderExecutionError,
    PositionLimitError,
    RedisConnectionError,
    SignalRejectedError,
    SignalValidationError,
    ValidationError,
)

# Exchange adapters
from .exchanges import (
    BaseExchange,
    BinanceExchange,
    ExchangeFactory,
)

# gRPC client
from .grpc import (
    GRPCStreamingClient,
    ConnectionManager,
)

# Signal handling
from .signals import (
    RedisSignalListener,
    SignalBus,
)

__all__ = [
    # Version
    "__version__",
    # Core
    "TradingBot",
    "BotClient",
    "run_bot",
    "run_bot_sync",
    # Config
    "ClientConfig",
    "GRPCConfig",
    "ExchangeConfig",
    "RedisConfig",
    "TradingParams",
    "BotConfig",
    # Trading
    "TradingSignal",
    "TickerInfo",
    "AccountBalance",
    "Order",
    "Position",
    # Execution
    "OrderResult",
    "ExecutionReport",
    "SignalDecision",
    # Enums
    "SignalType",
    "OrderSide",
    "OrderType",
    "OrderStatus",
    "BotState",
    "SignalAction",
    "MarketType",
    "Direction",
    # Exceptions
    "BotClientError",
    "ConnectionError",
    "GRPCConnectionError",
    "GRPCStreamError",
    "RedisConnectionError",
    "ExchangeError",
    "ExchangeConnectionError",
    "ExchangeAuthenticationError",
    "OrderExecutionError",
    "InsufficientBalanceError",
    "InvalidSymbolError",
    "ValidationError",
    "ConfigValidationError",
    "SignalValidationError",
    "BusinessError",
    "BotNotRunningError",
    "SignalRejectedError",
    "PositionLimitError",
    # Exchanges
    "BaseExchange",
    "BinanceExchange",
    "ExchangeFactory",
    # gRPC
    "GRPCStreamingClient",
    "ConnectionManager",
    # Signals
    "SignalBus",
    "RedisSignalListener",
]
