# -*- coding: utf-8 -*-


"""
lesscode python version file.
"""

__version__ = "0.4.23"
