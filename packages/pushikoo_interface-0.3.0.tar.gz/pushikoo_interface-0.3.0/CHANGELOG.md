# Changelog

## [0.3.0](https://github.com/Pushikoo/pushikoo-interface/compare/v0.2.0...v0.3.0) (2025-11-25)


### Features

* **adapter:** add processer adapter type with testing utilities ([232bfc7](https://github.com/Pushikoo/pushikoo-interface/commit/232bfc73c4084b6dd13e4d85dfa3e96fbca62fab))

## [0.2.0](https://github.com/Pushikoo/pushikoo-interface/compare/v0.1.1...v0.2.0) (2025-11-17)


### Features

* **test:** add adapter testing utilities with basic flow validation ([a12e4ff](https://github.com/Pushikoo/pushikoo-interface/commit/a12e4ff5dacc4df2217fee37bd7429824f4792c1))

## [0.1.1](https://github.com/Pushikoo/pushikoo-interface/compare/v0.1.0...v0.1.1) (2025-11-17)


### Miscellaneous Chores

* Trigger release-please ([4ac8d97](https://github.com/Pushikoo/pushikoo-interface/commit/4ac8d973a095f74fc7ffc5efa517f19c51723f47))

## [0.1.0](https://github.com/Pushikoo/pushikoo-interface/compare/v0.0.11...v0.1.0) (2025-11-17)


### Features

* **pushikoo_interface:** enhance image handling with StructImage support ([c9372b0](https://github.com/Pushikoo/pushikoo-interface/commit/c9372b0698e123976312739701e428eb340b6710))


### Bug Fixes

* **pushikoo_interface:** add missing comma to __all__ list ([7685da3](https://github.com/Pushikoo/pushikoo-interface/commit/7685da3434b89f9765ca850ac6c5ec44d0d98e2d))
