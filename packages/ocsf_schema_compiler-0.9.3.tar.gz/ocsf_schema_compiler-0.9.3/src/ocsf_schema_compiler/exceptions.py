class SchemaException(Exception):
    pass
