import {helperFunction} from "./index";


export function useHelper() {
    helperFunction();
}

useHelper();
