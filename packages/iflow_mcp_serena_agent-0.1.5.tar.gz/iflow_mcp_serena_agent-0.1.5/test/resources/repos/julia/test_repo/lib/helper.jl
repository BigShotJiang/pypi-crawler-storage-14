module Helper
    function say_hello()
        println("Hello from the helper module!")
    end
end
