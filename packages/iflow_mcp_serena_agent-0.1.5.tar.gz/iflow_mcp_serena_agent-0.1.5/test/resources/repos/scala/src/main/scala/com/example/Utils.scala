package com.example

object Utils {
  def printHello(): Unit = {
    println("Hello from Utils!")
  }
  
  def multiply(x: Int, y: Int): Int = {
    x * y
  }
}
