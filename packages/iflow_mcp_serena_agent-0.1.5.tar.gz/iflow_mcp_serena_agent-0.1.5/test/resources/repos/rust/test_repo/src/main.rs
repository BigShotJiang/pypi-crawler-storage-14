use rsandbox::add;

fn main() {
    println!("Hello, World!");
    println!("Good morning!");
    println!("add result: {}", add());
    println!("inserted line");
}
