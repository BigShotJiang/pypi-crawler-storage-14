<?php
$localVar = "test";
echo $localVar;
?> 