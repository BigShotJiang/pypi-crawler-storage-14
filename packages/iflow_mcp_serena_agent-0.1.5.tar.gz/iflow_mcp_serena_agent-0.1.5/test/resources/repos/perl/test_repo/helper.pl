#!/usr/bin/env perl
use strict;
use warnings;

sub helper_function {
    print "Helper function was called.\n";
}

1;
