package test_repo

object Utils {
    fun printHello() {
        println("Hello from Utils!")
    }
}