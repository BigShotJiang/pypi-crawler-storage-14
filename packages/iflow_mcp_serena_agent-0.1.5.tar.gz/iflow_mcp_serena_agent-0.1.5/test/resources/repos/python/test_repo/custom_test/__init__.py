"""
Custom test package for testing code parsing capabilities.
"""
