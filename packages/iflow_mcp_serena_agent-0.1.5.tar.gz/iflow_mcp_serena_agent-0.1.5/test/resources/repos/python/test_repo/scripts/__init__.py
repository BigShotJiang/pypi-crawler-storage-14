"""
Scripts package containing entry point scripts for the application.
"""
