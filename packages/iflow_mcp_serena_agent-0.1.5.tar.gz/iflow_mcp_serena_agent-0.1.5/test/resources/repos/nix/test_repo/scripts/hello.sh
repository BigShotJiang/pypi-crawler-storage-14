#!/usr/bin/env bash
# Simple hello script for testing
echo "Hello from Nix!"