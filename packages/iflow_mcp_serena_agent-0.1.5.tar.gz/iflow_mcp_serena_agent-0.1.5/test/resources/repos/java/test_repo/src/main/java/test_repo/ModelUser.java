package test_repo;

public class ModelUser {
    public static void main(String[] args) {
        Model model = new Model("Cascade");
        System.out.println(model.getName());
    }
}
