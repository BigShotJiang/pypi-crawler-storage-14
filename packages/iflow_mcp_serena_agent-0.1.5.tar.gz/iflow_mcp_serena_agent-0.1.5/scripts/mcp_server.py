from serena.cli import start_mcp_server

if __name__ == "__main__":
    start_mcp_server()
