"""
Test suite for asymcaus package.
"""
