"""
asymcaus - Asymmetric Causality Testing Package
===============================================

A Python implementation of the asymmetric causality test developed by 
Hatemi-J (2012). This package allows testing for causal relationships
between positive and negative components of time series variables.

Main Features
-------------
- Asymmetric causality testing (positive/negative components)
- Bootstrap critical values with leverage adjustment
- Multiple information criteria for lag selection (AIC, BIC, HQC, HJC)
- Toda-Yamamoto procedure for integrated variables
- Diagnostic tests (normality, ARCH effects)
- Unit root tests (ADF, KPSS, PP)

Quick Start
-----------
>>> import numpy as np
>>> from asymcaus import asymmetric_causality_test
>>> 
>>> # Generate sample data
>>> np.random.seed(42)
>>> z = np.cumsum(np.random.randn(500))  # Cause variable
>>> y = np.cumsum(np.random.randn(500))  # Effect variable
>>> 
>>> # Test positive component causality (Z+ -> Y+)
>>> result = asymmetric_causality_test(y, z, component='positive')
>>> print(result.summary())

Reference
---------
Hatemi-J, A. (2012). Asymmetric Causality Tests with an Application.
Empirical Economics, 43(1), 447-456.

Original GAUSS code by Abdulnasser Hatemi-J and Scott Hacker.
Python implementation by Dr. Merwan Roudane.

License: MIT

GitHub: https://github.com/merwanroudane/asymcaus
Email: merwanroudane920@gmail.com
"""

__version__ = "2.0.0"
__author__ = "Dr. Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"
__license__ = "MIT"

# Core functionality
from .core import (
    # Main test functions
    asymmetric_causality_test,
    full_asymmetric_causality_analysis,
    print_full_analysis,
    
    # Data transformation
    cumulative_components,
    
    # VAR model functions
    var_lags,
    estimate_var,
    select_lag_order,
    information_criterion,
    
    # Test functions
    wald_test,
    bootstrap_critical_values,
    create_restriction_matrix,
    
    # Result class
    AsymmetricCausalityResult,
)

# Diagnostic tests
from .diagnostics import (
    doornik_hansen_test,
    multivariate_jarque_bera,
    multivariate_arch_test,
    ljung_box_test,
    run_all_diagnostics,
    print_diagnostics_summary,
    DiagnosticResult,
)

# Unit root tests
from .unit_root import (
    adf_test,
    kpss_test,
    pp_test,
    determine_integration_order,
    print_unit_root_summary,
    UnitRootResult,
)

# Define public API
__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__email__",
    
    # Core functions
    "asymmetric_causality_test",
    "full_asymmetric_causality_analysis",
    "print_full_analysis",
    "cumulative_components",
    "var_lags",
    "estimate_var",
    "select_lag_order",
    "information_criterion",
    "wald_test",
    "bootstrap_critical_values",
    "create_restriction_matrix",
    "AsymmetricCausalityResult",
    
    # Diagnostics
    "doornik_hansen_test",
    "multivariate_jarque_bera",
    "multivariate_arch_test",
    "ljung_box_test",
    "run_all_diagnostics",
    "print_diagnostics_summary",
    "DiagnosticResult",
    
    # Unit root tests
    "adf_test",
    "kpss_test",
    "pp_test",
    "determine_integration_order",
    "print_unit_root_summary",
    "UnitRootResult",
]
