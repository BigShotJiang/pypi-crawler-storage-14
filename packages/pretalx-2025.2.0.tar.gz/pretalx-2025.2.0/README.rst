.. SPDX-FileCopyrightText: 2017-present Tobias Kunze
.. SPDX-License-Identifier: Apache-2.0

|logo|

.. image:: https://img.shields.io/github/actions/workflow/status/pretalx/pretalx/tests.yml?branch=main
   :target: https://github.com/pretalx/pretalx/actions/workflows/tests.yml?query=workflow%3ATests
   :alt: Continuous integration

.. image:: https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/rixx/0ac3e4314d780e809c0164c8c329f36f/raw/covbadge.json
   :target: https://github.com/pretalx/pretalx/actions/workflows/tests.yml?query=workflow%3ATests
   :alt: Coverage

.. image:: https://img.shields.io/pypi/v/pretalx.svg?colorB=3aa57c
   :target: https://pypi.python.org/pypi/pretalx
   :alt: PyPI

.. image:: https://img.shields.io/badge/docs-passing-3aa57c
   :target: https://docs.pretalx.org/
   :alt: Documentation

.. image:: https://img.shields.io/badge/news-blog-3aa57c
   :target: https://pretalx.com/p/news/
   :alt: Website

**pretalx** is a conference planning tool focused on providing the best
experience for organisers, speakers, reviewers, and attendees alike.  It
handles the submission process with a configurable Call for Participation, the
reviewing and selection of submissions, and the scheduling and release
handling. After the event, pretalx allows speakers to receive feedback, upload
their slides, and organisers to embed recordings.

Read our `feature list`_ on our main site to get a better idea of what pretalx
can do for you, but it typically involves everything you'll need to curate
submissions and contents for a conference with several tracks and conference
days.

You can host pretalx yourself, as detailed in our `administrator
documentation`_, or use our public instance at `pretalx.com`_. If you want to
use pretalx, we recommend you follow `our blog`_, where we announce new
versions and upcoming features.

📺 Look and feel
----------------

|screenshots|

Check out our `feature list`_ for more screenshots – or check the `list of
events`_ to see how pretalx looks in the wild.

pretalx is highly configurable, so you can change its appearance and behaviour
in many ways if the defaults don't fit your event. If the settings are not
enough for you, you can even write plugins of your own.

🚦 Project status
-----------------

pretalx is under `active development`_ and used by `many events`_. It supports
everything required for talk submission, speaker communication, and scheduling.
You can see our supported features in the `feature list`_, and our planned
features in our open issues_. pretalx has regular releases – you can look at
the `changelog`_ to see upcoming and past changes, and install pretalx via
PyPI_.

🔨 Contributing
---------------

Contributions to pretalx are very welcome! You can contribute observations,
bugs or feature requests via the issues. If you want to contribute changes to
pretalx, please check our `developer documentation`_ on how to set up pretalx
and get started on development. Please bear in mind that our Code of Conduct
applies to the complete contribution process.

If you are interested in plugin development, check both our documentation and
our `list of plugin ideas`_ in the project wiki.

💡 Project information
----------------------

The pretalx source code is available on `GitHub`_, where you can also find the
issue tracker. The documentation is available at `docs.pretalx.org`_, and you
can find up to date information on `our blog`_ and `Twitter`_. The pretalx
package is available via `PyPI`_.

We publish pretalx under the terms of the Apache License. See the LICENSE file
for further information and the complete license text.

The primary maintainer of this project is Tobias Kunze <r@rixx.de> (who also
runs `pretalx.com`_).  See the CONTRIBUTORS file for a list of all the awesome
folks who contributed to this project.

🧭 Users
--------

If you want to look at conferences using pretalx, head over to the wiki for a
`list of events`_. And if you use pretalx for your event, please add it to the
list (or tell us about it, and we'll add it)!

.. |logo| image:: https://raw.githubusercontent.com/pretalx/pretalx/main/src/pretalx/static/common/img/logo.png
   :alt: pretalx logo
   :target: https://pretalx.com
.. |screenshots| image:: https://img.pretalx.com/docs/screenshots.png
   :target: https://pretalx.com/p/features
   :alt: Screenshots of pretalx pages
.. _issues: https://github.com/pretalx/pretalx/issues/
.. _feature list: https://pretalx.com/p/features
.. _developer documentation: https://docs.pretalx.org/developer/index.html
.. _administrator documentation: https://docs.pretalx.org/administrator/index.html
.. _pretalx.com: https://pretalx.com/
.. _active development: https://github.com/pretalx/pretalx/pulse
.. _changelog: https://docs.pretalx.org/en/latest/changelog.html
.. _PyPI: https://pypi.python.org/pypi/pretalx
.. _list of plugin ideas: https://github.com/pretalx/pretalx/wiki/Plugin-ideas
.. _list of events: https://github.com/pretalx/pretalx/wiki/Events
.. _many events: https://github.com/pretalx/pretalx/wiki/Events
.. _our blog: https://pretalx.com/p/news/
.. _GitHub: https://github.com/pretalx/pretalx
.. _docs.pretalx.org: https://docs.pretalx.org
.. _Twitter: https://twitter.com/pretalx
