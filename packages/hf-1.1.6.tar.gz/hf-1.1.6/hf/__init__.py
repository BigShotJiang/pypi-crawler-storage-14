raise ImportError(
    "The 'hf' package only provides a CLI entry point. "
    "It cannot be imported. Please install 'huggingface_hub' instead:\n\n"
    "    pip install huggingface_hub\n"
)
