"""Git worktree coordination for multi-agent execution."""
from __future__ import annotations

import subprocess
from pathlib import Path


class GitWorktreeManager:
    """Manages git worktrees for parallel agent execution."""

    def __init__(self, repo_root: Path, integration_branch: str = "main"):
        self.repo_root = repo_root
        self.integration_branch = integration_branch
        self.worktrees_root = repo_root / ".agent_worktrees"

    def _run(self, args: list[str], cwd: Path | None = None) -> str:
        """Run a git command and return stdout."""
        result = subprocess.run(
            ["git", *args],
            cwd=cwd or self.repo_root,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"git {' '.join(args)}: {result.stderr.strip()}")
        return result.stdout.strip()

    def _run_safe(self, args: list[str], cwd: Path | None = None) -> tuple[bool, str]:
        """Run a git command, return (success, output)."""
        result = subprocess.run(
            ["git", *args],
            cwd=cwd or self.repo_root,
            capture_output=True,
            text=True,
        )
        return result.returncode == 0, result.stdout.strip() or result.stderr.strip()

    def init_repo_if_needed(self) -> None:
        """Initialize git repo if not already initialized."""
        git_dir = self.repo_root / ".git"
        if not git_dir.exists():
            self._run(["init"])
            self._run(["add", "-A"])
            self._run(["commit", "-m", "Initial commit"])

    def ensure_agent_worktree(self, agent_id: int) -> Path:
        """Create worktree for agent if it doesn't exist."""
        branch = f"agent/{agent_id}"
        wt_dir = self.worktrees_root / f"agent-{agent_id}"

        # Create worktrees directory
        self.worktrees_root.mkdir(exist_ok=True)

        # Get existing branches
        branches = self._run(["branch", "--format", "%(refname:short)"]).splitlines()

        # Create branch if missing
        if branch not in branches:
            self._run(["branch", branch, self.integration_branch])

        # Create worktree if missing
        if not wt_dir.exists():
            self._run(["worktree", "add", str(wt_dir), branch])

        return wt_dir

    def sync_from_main(self, agent_id: int) -> bool:
        """Merge main into agent's branch. Returns True if successful."""
        wt_dir = self.worktrees_root / f"agent-{agent_id}"
        
        success, output = self._run_safe(
            ["merge", "--no-edit", self.integration_branch],
            cwd=wt_dir,
        )
        
        if not success:
            # Abort failed merge
            self._run_safe(["merge", "--abort"], cwd=wt_dir)
            print(f"[git] Merge conflict syncing main → agent/{agent_id}")
            return False
        return True

    def commit_agent_work(self, agent_id: int, task_id: str, message: str) -> str | None:
        """Commit agent's work and return commit SHA."""
        wt_dir = self.worktrees_root / f"agent-{agent_id}"
        
        # Stage all changes
        self._run_safe(["add", "-A"], cwd=wt_dir)
        
        # Check if there's anything to commit
        success, _ = self._run_safe(["diff", "--cached", "--quiet"], cwd=wt_dir)
        if success:
            return None  # Nothing to commit
        
        # Commit
        commit_msg = f"[agent-{agent_id}][{task_id}] {message}"
        self._run(["commit", "-m", commit_msg], cwd=wt_dir)
        
        return self._run(["rev-parse", "HEAD"], cwd=wt_dir)

    def merge_to_main(self, agent_id: int) -> bool:
        """Merge agent's branch into main. Returns True if successful."""
        branch = f"agent/{agent_id}"
        
        success, output = self._run_safe(
            ["merge", "--no-edit", branch],
            cwd=self.repo_root,
        )
        
        if not success:
            self._run_safe(["merge", "--abort"], cwd=self.repo_root)
            print(f"[git] Merge conflict merging agent/{agent_id} → main")
            return False
        return True

    def get_recent_log(self, count: int = 15) -> str:
        """Get recent commit log from main branch."""
        success, output = self._run_safe(
            ["log", "--oneline", "-n", str(count), self.integration_branch]
        )
        return output if success else ""

    def get_agent_worktree_path(self, agent_id: int) -> Path:
        """Get the worktree path for an agent."""
        return self.worktrees_root / f"agent-{agent_id}"

    def cleanup_worktrees(self) -> None:
        """Remove all agent worktrees."""
        if not self.worktrees_root.exists():
            return
        
        for wt_dir in self.worktrees_root.iterdir():
            if wt_dir.is_dir():
                self._run_safe(["worktree", "remove", "--force", str(wt_dir)])
        
        self.worktrees_root.rmdir()
