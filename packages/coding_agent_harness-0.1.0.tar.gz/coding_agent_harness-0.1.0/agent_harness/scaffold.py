"""Scaffolding templates for agent-harness init."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path


DEFAULT_INIT_SH = """\
#!/usr/bin/env bash
set -e
echo "[init.sh] Environment ready."
"""


def default_progress() -> str:
    date = datetime.now().strftime("%Y-%m-%d")
    return f"# Agent Progress Log\n\n- [{date}] Initialized harness.\n"


def scaffold_files(base: Path | None = None) -> list[str]:
    """Create minimal harness files (no config or tasks - those come from init)."""
    base = base or Path.cwd()
    created = []

    files = {
        "agent-progress.md": default_progress(),
        "init.sh": DEFAULT_INIT_SH,
    }

    for name, content in files.items():
        path = base / name
        if path.exists():
            continue
        path.write_text(content)
        if name == "init.sh":
            path.chmod(0o755)
        created.append(name)

    return created
