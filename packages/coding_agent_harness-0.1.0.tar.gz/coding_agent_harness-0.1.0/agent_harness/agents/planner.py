"""Planner agent that analyzes repo and generates tasks."""
from __future__ import annotations

import json
import subprocess
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agent_harness.config import AgentConfig


PLANNER_PROMPT = """\
You are a senior software architect planning work for a team of coding agents.

## Goal
{goal}

## Available Agents
{agents_desc}

## Your Job
1. Analyze this codebase (read key files, understand structure)
2. Break down the goal into atomic tasks
3. Assign each task to the appropriate agent based on their scope
4. Ensure NO CONFLICTS between agents (no two agents edit the same files)
5. Order tasks by dependencies

## Response Format
Respond with ONLY valid JSON:
{{
  "tasks": [
    {{
      "id": "task_001",
      "title": "Short title",
      "description": "Detailed description including specific files to create/modify",
      "status": "todo",
      "assigned_agent": 1,
      "dependencies": [],
      "verification": "How to verify this task is complete",
      "files_touched": ["list", "of", "files"],
      "notes": ""
    }}
  ]
}}

## Critical Rules
- Each task must specify which files it touches in "files_touched"
- NO TWO AGENTS should have tasks that touch the same files
- Tasks with dependencies must wait for those to complete first
- Create atomic tasks (1-2 hours of work each)
- Include verification steps so agents know when they're done
- Be specific: name files, functions, APIs to create/modify

## Conflict Prevention
Before finalizing, verify:
1. List all files each agent will touch
2. Confirm no overlap between agents
3. If overlap exists, assign conflicting tasks to the same agent
"""


def run_planner(goal: str, agents: list[AgentConfig], provider: str = "codex") -> list[dict]:
    """Run the planner agent to generate tasks."""
    agents_desc = "\n".join(
        f"- Agent {a.id}: {a.scope}" for a in agents
    )
    
    prompt = PLANNER_PROMPT.format(goal=goal, agents_desc=agents_desc)
    
    if provider == "claude":
        cmd = ["claude", "--dangerously-skip-permissions", "--model", "claude-opus-4-5", "-p", prompt]
    elif provider == "codex":
        cmd = [
            "codex", "exec", prompt,
            "--model", "gpt-5",
            "-c", "model_reasoning_effort=high",
            "-c", "approval_policy=never",
            "-c", "sandbox_mode=danger-full-access",
        ]
    elif provider == "gemini":
        cmd = ["gemini", "--yolo", "-m", "gemini-3-pro-preview", "-p", prompt]
    else:
        print(f"[planner] Unknown provider: {provider}")
        return []

    print("[planner] Analyzing codebase and generating tasks...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"[planner] Error: {result.stderr[:200]}")
        return []

    return parse_tasks(result.stdout)


def parse_tasks(output: str) -> list[dict]:
    """Parse JSON tasks from planner output."""
    text = output.strip()
    
    # Extract JSON from markdown code blocks
    if "```json" in text:
        start = text.find("```json") + 7
        end = text.find("```", start)
        if end > start:
            text = text[start:end].strip()
    elif "```" in text:
        start = text.find("```") + 3
        end = text.find("```", start)
        if end > start:
            text = text[start:end].strip()

    try:
        parsed = json.loads(text)
        return parsed.get("tasks", [])
    except json.JSONDecodeError:
        print(f"[planner] Failed to parse response:\n{output[:500]}")
        return []
