"""Anthropic coding agent implementation."""
from __future__ import annotations

import json
import os
from typing import Any

import httpx

from .base import BaseAgent, CodingResult


SYSTEM_PROMPT = """\
You are a coding agent working within agent-harness.

You will receive:
- current_task: The task you should work on
- all_tasks: Full list of tasks for context
- recent_progress: Recent entries from the progress log

You must respond with ONLY valid JSON matching this schema:
{
  "task_update": {"id": "<task_id>", "status": "todo|in-progress|done", "notes": "<optional>"},
  "file_edits": [{"path": "<relative_path>", "content": "<full_file_content>"}],
  "progress_entry": "<one-line summary of what you did>"
}

Guidelines:
- Set status to "in-progress" if partially done, "done" if complete
- file_edits should contain the complete file content, not patches
- Keep progress_entry concise (one sentence)
- If you cannot complete the task, explain in notes and keep status as "todo"
"""


class AnthropicAgent(BaseAgent):
    """Anthropic Claude agent for coding tasks."""

    def __init__(self, model: str = "claude-sonnet-4-20250514") -> None:
        self.model = model
        self.api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        self.base_url = "https://api.anthropic.com/v1/messages"

    def run_step(
        self,
        task: dict[str, Any],
        tasks: list[dict[str, Any]],
        progress_tail: str,
    ) -> CodingResult:
        if not self.api_key:
            return self._error_result(task, "ANTHROPIC_API_KEY not set")

        user_message = json.dumps({
            "current_task": task,
            "all_tasks": tasks,
            "recent_progress": progress_tail,
        }, indent=2)

        response = self._call_api(user_message)
        if response is None:
            return self._error_result(task, "API call failed")

        return self._parse_response(task, response)

    def _call_api(self, user_message: str) -> dict[str, Any] | None:
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": self.model,
            "max_tokens": 4096,
            "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": user_message}],
        }

        with httpx.Client(timeout=120) as client:
            resp = client.post(self.base_url, headers=headers, json=payload)
            if resp.status_code != 200:
                print(f"[agent] API error: {resp.status_code} {resp.text[:200]}")
                return None
            return resp.json()

    def _parse_response(self, task: dict[str, Any], response: dict[str, Any]) -> CodingResult:
        content = response.get("content", [])
        text = content[0].get("text", "") if content else ""

        text = text.strip()
        if text.startswith("```json"):
            text = text[7:]
        if text.startswith("```"):
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        parsed = json.loads(text)
        return CodingResult(
            task_update=parsed.get("task_update", {"id": task.get("id"), "status": "todo"}),
            file_edits=parsed.get("file_edits", []),
            progress_entry=parsed.get("progress_entry", ""),
        )

    def _error_result(self, task: dict[str, Any], message: str) -> CodingResult:
        print(f"[agent] {message}")
        return CodingResult(
            task_update={"id": task.get("id"), "status": "todo", "notes": message},
            file_edits=[],
            progress_entry=f"Error: {message}",
        )
