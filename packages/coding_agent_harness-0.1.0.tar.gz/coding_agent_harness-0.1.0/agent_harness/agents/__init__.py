"""Agent implementations for agent-harness."""

from .base import BaseAgent, CodingResult
from .anthropic_agent import AnthropicAgent

__all__ = ["BaseAgent", "CodingResult", "AnthropicAgent"]
