"""Base agent definitions."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, TypedDict


class CodingResult(TypedDict):
    """Structured response expected from a coding agent."""

    task_update: Dict[str, Any]
    file_edits: List[Dict[str, Any]]
    progress_entry: str


class BaseAgent(ABC):
    """Abstract base class for coding agents."""

    @abstractmethod
    def run_step(
        self, task: Dict[str, Any], tasks: List[Dict[str, Any]], progress_tail: str
    ) -> CodingResult:
        """Run a single agent step and return a structured result."""

