"""CLI-based agent using claude or codex commands."""
from __future__ import annotations

import json
import subprocess
from typing import Any

from .base import BaseAgent, CodingResult


PROMPT_TEMPLATE = """\
You are Agent {agent_id} working in a multi-agent coding team.

## Your Scope
You are responsible for: {agent_scope}

## Getting Bearings
1. Check the git log below to see what other agents have done
2. Review your assigned task and its dependencies
3. Verify the environment works before making changes

## Your Current Task
{task}

## All Tasks (for context on what others are doing)
{tasks}

## Recent Activity
{progress}

## Your Workflow
1. Understand what other agents have built (from git log above)
2. Implement your task incrementally
3. Test your changes work correctly
4. The orchestrator will commit your work automatically
5. Only mark as "done" after verifying it works

## Response Format
Respond with ONLY valid JSON:
{{
  "task_update": {{"id": "<task_id>", "status": "todo|in-progress|done", "notes": "<optional>"}},
  "file_edits": [{{"path": "<relative_path>", "content": "<full_file_content>"}}],
  "progress_entry": "<one-line summary of what you did>"
}}

## Critical Rules
- Do NOT edit files outside your scope (other agents own those)
- Do NOT edit feature_list.json or agent-progress.md (orchestrator manages those)
- Test before marking done
- Leave codebase in a clean, working state
- Coordinate with other agents through your progress_entry
"""


class CLIAgent(BaseAgent):
    """Agent that uses claude or codex CLI tools."""

    def __init__(self, provider: str = "codex", agent_id: int = 1, scope: str = "All tasks") -> None:
        self.provider = provider
        self.agent_id = agent_id
        self.scope = scope

    def run_step(
        self,
        task: dict[str, Any],
        tasks: list[dict[str, Any]],
        progress_tail: str,
    ) -> CodingResult:
        prompt = PROMPT_TEMPLATE.format(
            agent_id=self.agent_id,
            agent_scope=self.scope,
            task=json.dumps(task, indent=2),
            tasks=json.dumps(tasks, indent=2),
            progress=progress_tail,
        )

        output = self._call_cli(prompt)
        if output is None:
            return self._error_result(task, f"{self.provider} CLI call failed")

        return self._parse_response(task, output)

    def _call_cli(self, prompt: str) -> str | None:
        if self.provider == "claude":
            cmd = ["claude", "--dangerously-skip-permissions", "--model", "claude-opus-4-5", "-p", prompt]
        elif self.provider == "codex":
            cmd = [
                "codex", "exec", prompt,
                "--model", "gpt-5-codex-max",
                "-c", "model_reasoning_effort=xhigh",
                "-c", "approval_policy=never",
                "-c", "sandbox_mode=danger-full-access",
            ]
        elif self.provider == "gemini":
            cmd = ["gemini", "--yolo", "-m", "gemini-3-pro-preview", "-p", prompt]
        else:
            print(f"[agent] Unknown provider: {self.provider}")
            return None

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"[agent] CLI error: {result.stderr[:200]}")
            return None
        return result.stdout

    def _parse_response(self, task: dict[str, Any], output: str) -> CodingResult:
        text = output.strip()
        
        # Try to extract JSON from markdown code blocks
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            if end > start:
                text = text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            if end > start:
                text = text[start:end].strip()

        try:
            parsed = json.loads(text)
            return CodingResult(
                task_update=parsed.get("task_update", {"id": task.get("id"), "status": "todo"}),
                file_edits=parsed.get("file_edits", []),
                progress_entry=parsed.get("progress_entry", ""),
            )
        except json.JSONDecodeError:
            print(f"[agent] Failed to parse response:\n{output[:500]}")
            return self._error_result(task, "Invalid JSON response from model")

    def _error_result(self, task: dict[str, Any], message: str) -> CodingResult:
        print(f"[agent] {message}")
        return CodingResult(
            task_update={"id": task.get("id"), "status": "todo", "notes": message},
            file_edits=[],
            progress_entry=f"Error: {message}",
        )
