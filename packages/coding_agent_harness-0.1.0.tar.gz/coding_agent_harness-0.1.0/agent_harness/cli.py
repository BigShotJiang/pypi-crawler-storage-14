"""Command line interface for agent-harness."""
from __future__ import annotations

import argparse
import subprocess
from typing import Callable

from agent_harness import __version__
from agent_harness.config import HarnessConfig, load_config, save_config
from agent_harness.scaffold import scaffold_files
from agent_harness.state import save_tasks


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agent-harness",
        description="Lightweight long-running harness for coding agents.",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"agent-harness {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # init command
    init_parser = subparsers.add_parser("init", help="Initialize harness with AI-generated plan.")
    init_parser.add_argument("--provider", default="codex", help="Agent provider (codex/claude)")
    init_parser.set_defaults(func=handle_init)

    # run command
    run_parser = subparsers.add_parser("run", help="Run agents to execute tasks.")
    run_parser.add_argument("--max-steps", type=int, help="Max steps per agent")
    run_parser.set_defaults(func=handle_run)

    # status command
    status_parser = subparsers.add_parser("status", help="Show task status.")
    status_parser.set_defaults(func=handle_status)

    return parser


def handle_init(args: argparse.Namespace) -> int:
    """Interactive init: get goal, agent scopes, generate plan with AI."""
    from agent_harness.agents.planner import run_planner
    from agent_harness.config import AgentConfig

    print("=== Agent Harness Setup ===\n")
    
    # Get goal
    goal = input("What do you want to accomplish?\n> ").strip()
    if not goal:
        print("No goal provided. Aborting.")
        return 1

    # Get number of agents
    num_agents_str = input("\nHow many parallel agents? [1]\n> ").strip()
    num_agents = int(num_agents_str) if num_agents_str.isdigit() else 1

    # Get scope for each agent if more than 1
    agents: list[AgentConfig] = []
    if num_agents > 1:
        print(f"\nDefine scope for each agent (to prevent conflicts):\n")
        for i in range(1, num_agents + 1):
            scope = input(f"Agent {i} scope (e.g., 'backend API', 'frontend UI'):\n> ").strip()
            if not scope:
                scope = f"General tasks {i}"
            agents.append(AgentConfig(id=i, scope=scope))
    else:
        agents.append(AgentConfig(id=1, scope="All tasks"))

    provider = args.provider
    print(f"\nUsing provider: {provider}")

    # Scaffold basic files
    created = scaffold_files()
    if created:
        print(f"Created: {', '.join(created)}")

    # Run planner to generate tasks with agent scopes
    tasks = run_planner(goal, agents, provider)
    
    if not tasks:
        print("[init] Planner failed to generate tasks.")
        return 1

    # Save tasks
    save_tasks("feature_list.json", tasks)
    print(f"\n[init] Generated {len(tasks)} tasks in feature_list.json")

    # Save config
    cfg = HarnessConfig(
        provider=provider,
        num_agents=num_agents,
        goal=goal,
        agents=agents,
    )
    save_config(cfg)
    print(f"[init] Saved config to agent_harness.yaml")

    # Show summary
    print("\n--- Agent Assignments ---")
    for a in agents:
        count = sum(1 for t in tasks if t.get("assigned_agent") == a.id)
        print(f"Agent {a.id} ({a.scope}): {count} tasks")

    print("\nRun 'agent-harness run' to start execution.")
    return 0


def handle_run(args: argparse.Namespace) -> int:
    """Run agents to execute tasks."""
    from agent_harness.agents.cli_agent import CLIAgent
    from agent_harness.orchestrator import MultiAgentOrchestrator

    cfg = load_config()
    
    print(f"[run] Running init command: {cfg.init_cmd}")
    result = subprocess.run(cfg.init_cmd, shell=True)
    if result.returncode != 0:
        print(f"[run] Init command failed with code {result.returncode}")
        return result.returncode

    # Factory to create agents for each worker with their scope
    def agent_factory(agent_id: int, provider: str) -> CLIAgent:
        scope = "All tasks"
        for a in cfg.agents:
            if a.id == agent_id:
                scope = a.scope
                break
        return CLIAgent(provider=provider, agent_id=agent_id, scope=scope)

    max_steps = args.max_steps
    orchestrator = MultiAgentOrchestrator(
        cfg=cfg,
        agent_factory=agent_factory,
        max_steps=max_steps,
    )
    orchestrator.run()
    return 0


def handle_status(args: argparse.Namespace) -> int:
    """Show current task status."""
    from agent_harness.state import load_tasks

    cfg = load_config()
    tasks = load_tasks(cfg.features_file)

    if not tasks:
        print("No tasks found.")
        return 0

    todo = sum(1 for t in tasks if t.get("status") == "todo")
    in_progress = sum(1 for t in tasks if t.get("status") == "in-progress")
    done = sum(1 for t in tasks if t.get("status") == "done")

    print(f"Tasks: {len(tasks)} total | {done} done | {in_progress} in-progress | {todo} todo")
    print(f"Agents: {cfg.num_agents} | Provider: {cfg.provider}\n")
    
    # Group by agent
    by_agent: dict[int, list] = {}
    for t in tasks:
        agent = t.get("assigned_agent", 1)
        by_agent.setdefault(agent, []).append(t)
    
    for agent_id in sorted(by_agent.keys()):
        print(f"Agent {agent_id}:")
        for t in by_agent[agent_id]:
            status = t.get("status", "?")
            icon = {"done": "✓", "in-progress": "→", "todo": "○"}.get(status, "?")
            deps = t.get("dependencies", [])
            dep_str = f" (deps: {', '.join(deps)})" if deps else ""
            print(f"  {icon} [{t.get('id')}] {t.get('title')}{dep_str}")
        print()

    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    handler: Callable[[argparse.Namespace], int] = args.func
    return handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
