"""Configuration helpers for agent-harness."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG_PATH = Path("agent_harness.yaml")

# Default models per provider (planner = powerful, executor = fast)
DEFAULT_MODELS = {
    "claude": {"planner": "claude-opus-4-5", "executor": "claude-opus-4-5"},
    "codex": {"planner": "gpt-5", "executor": "gpt-5-codex-max"},
    "gemini": {"planner": "gemini-3-pro-preview", "executor": "gemini-3-pro-preview"},
}


@dataclass
class AgentConfig:
    id: int
    scope: str


@dataclass
class HarnessConfig:
    features_file: str = "feature_list.json"
    progress_file: str = "agent-progress.md"
    init_cmd: str = "bash init.sh"
    provider: str = "codex"
    planner_model: str = ""
    executor_model: str = ""
    num_agents: int = 1
    goal: str = ""
    agents: list[AgentConfig] = None  # type: ignore

    def __post_init__(self) -> None:
        defaults = DEFAULT_MODELS.get(self.provider, DEFAULT_MODELS["claude"])
        if not self.planner_model:
            self.planner_model = defaults["planner"]
        if not self.executor_model:
            self.executor_model = defaults["executor"]
        if self.agents is None:
            self.agents = []


def load_config(path: str | Path = DEFAULT_CONFIG_PATH) -> HarnessConfig:
    """Load configuration from YAML."""
    config_path = Path(path)
    if not config_path.exists():
        return HarnessConfig()
    
    with config_path.open() as fh:
        raw: dict[str, Any] = yaml.safe_load(fh) or {}
    
    agents_raw = raw.get("agents", [])
    agents = [AgentConfig(id=a["id"], scope=a["scope"]) for a in agents_raw]
    
    return HarnessConfig(
        features_file=raw.get("features_file", "feature_list.json"),
        progress_file=raw.get("progress_file", "agent-progress.md"),
        init_cmd=raw.get("init_cmd", "bash init.sh"),
        provider=raw.get("provider", "codex"),
        planner_model=raw.get("planner_model", ""),
        executor_model=raw.get("executor_model", ""),
        num_agents=int(raw.get("num_agents", 1)),
        goal=raw.get("goal", ""),
        agents=agents,
    )


def save_config(cfg: HarnessConfig, path: str | Path = DEFAULT_CONFIG_PATH) -> None:
    """Save configuration to YAML."""
    data = {
        "features_file": cfg.features_file,
        "progress_file": cfg.progress_file,
        "init_cmd": cfg.init_cmd,
        "provider": cfg.provider,
        "planner_model": cfg.planner_model,
        "executor_model": cfg.executor_model,
        "num_agents": cfg.num_agents,
        "goal": cfg.goal,
        "agents": [{"id": a.id, "scope": a.scope} for a in cfg.agents],
    }
    Path(path).write_text(yaml.dump(data, default_flow_style=False))
