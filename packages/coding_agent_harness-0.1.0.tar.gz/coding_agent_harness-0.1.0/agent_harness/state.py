"""State I/O for tasks, progress, and file edits."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, TypedDict


class Task(TypedDict):
    id: str
    title: str
    description: str
    status: str  # "todo" | "in-progress" | "done"
    notes: str


class FileEdit(TypedDict):
    path: str
    content: str


def load_tasks(path: str | Path) -> list[dict[str, Any]]:
    """Load tasks from JSON file."""
    p = Path(path)
    if not p.exists():
        return []
    data = json.loads(p.read_text())
    return data.get("tasks", [])


def save_tasks(path: str | Path, tasks: list[dict[str, Any]]) -> None:
    """Save tasks to JSON file."""
    Path(path).write_text(json.dumps({"tasks": tasks}, indent=2) + "\n")


def read_progress_tail(path: str | Path, max_lines: int = 50) -> str:
    """Read the last N lines of the progress file."""
    p = Path(path)
    if not p.exists():
        return ""
    text = p.read_text()
    lines = text.splitlines()
    return "\n".join(lines[-max_lines:])


def append_progress(path: str | Path, entry: str) -> None:
    """Append a timestamped entry to the progress file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    line = f"\n- [{timestamp}] {entry}\n"
    with Path(path).open("a") as f:
        f.write(line)


def apply_file_edits(edits: list[FileEdit]) -> list[str]:
    """Apply file edits and return list of paths written."""
    written = []
    for edit in edits:
        p = Path(edit["path"])
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(edit["content"])
        written.append(str(p))
    return written
