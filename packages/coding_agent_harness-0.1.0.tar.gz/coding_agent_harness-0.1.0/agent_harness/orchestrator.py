"""Orchestrator for coordinating multi-agent execution."""
from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from agent_harness.git_coord import GitWorktreeManager
from agent_harness.state import (
    append_progress,
    load_tasks,
    read_progress_tail,
    save_tasks,
)

if TYPE_CHECKING:
    from agent_harness.agents.base import BaseAgent
    from agent_harness.config import HarnessConfig


@dataclass
class AgentStepResult:
    agent_id: int
    task: dict
    task_update: dict
    file_edits: list[dict]
    progress_entry: str | None
    commit_sha: str | None
    success: bool


class MultiAgentOrchestrator:
    """Coordinates parallel agent execution with git worktrees."""

    def __init__(
        self,
        *,
        cfg: HarnessConfig,
        agent_factory: callable,  # (agent_id, provider) -> BaseAgent
        max_steps: int | None = None,
    ) -> None:
        self.cfg = cfg
        self.agent_factory = agent_factory
        self.max_steps = max_steps
        self.git = GitWorktreeManager(Path.cwd())

    def run(self) -> None:
        """Run the multi-agent orchestrator loop."""
        # Initialize git if needed
        self.git.init_repo_if_needed()

        # Setup worktrees for all agents
        print(f"[orchestrator] Setting up {self.cfg.num_agents} agent worktrees...")
        for agent_id in range(1, self.cfg.num_agents + 1):
            wt_path = self.git.ensure_agent_worktree(agent_id)
            print(f"  Agent {agent_id}: {wt_path}")

        steps = 0
        max_workers = min(self.cfg.num_agents, 4)  # Limit parallelism

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            while self.max_steps is None or steps < self.max_steps:
                tasks = load_tasks(self.cfg.features_file)
                runnable = self._pick_runnable_tasks(tasks)

                if not runnable:
                    remaining = sum(1 for t in tasks if t.get("status") != "done")
                    if remaining > 0:
                        print(f"[orchestrator] {remaining} tasks blocked by dependencies.")
                    else:
                        print("[orchestrator] All tasks complete!")
                    break

                # Submit parallel agent steps
                futures = {}
                for agent_id, task in runnable:
                    future = pool.submit(
                        self._run_agent_step, agent_id, task, tasks
                    )
                    futures[future] = (agent_id, task)

                # Collect results and integrate (serialized)
                for future in as_completed(futures):
                    agent_id, task = futures[future]
                    result = future.result()
                    self._integrate_result(result)
                    steps += 1

                    if self.max_steps and steps >= self.max_steps:
                        break

        # Summary
        tasks = load_tasks(self.cfg.features_file)
        done = sum(1 for t in tasks if t.get("status") == "done")
        print(f"\n[orchestrator] Completed {steps} steps. {done}/{len(tasks)} tasks done.")

    def _pick_runnable_tasks(self, tasks: list[dict]) -> list[tuple[int, dict]]:
        """Pick tasks that are ready to run (dependencies met)."""
        done_ids = {t.get("id") for t in tasks if t.get("status") == "done"}
        in_progress_ids = {t.get("id") for t in tasks if t.get("status") == "in-progress"}

        runnable: list[tuple[int, dict]] = []
        agents_busy: set[int] = set()

        for t in tasks:
            if t.get("status") != "todo":
                continue

            # Check dependencies
            deps = t.get("dependencies", [])
            if not all(d in done_ids for d in deps):
                continue

            agent_id = t.get("assigned_agent", 1)
            
            # One task per agent at a time
            if agent_id in agents_busy:
                continue

            # Mark as in-progress
            t["status"] = "in-progress"
            runnable.append((agent_id, t))
            agents_busy.add(agent_id)

        if runnable:
            save_tasks(self.cfg.features_file, tasks)

        return runnable

    def _run_agent_step(
        self, agent_id: int, task: dict, tasks_snapshot: list[dict]
    ) -> AgentStepResult:
        """Execute a single agent step in its worktree."""
        wt_dir = self.git.get_agent_worktree_path(agent_id)
        task_id = task.get("id", "unknown")
        task_title = task.get("title", "")

        print(f"[agent-{agent_id}] Starting: {task_title}")

        # Sync agent's worktree with main
        if not self.git.sync_from_main(agent_id):
            return AgentStepResult(
                agent_id=agent_id,
                task=task,
                task_update={"id": task_id, "status": "blocked", "notes": "Merge conflict from main"},
                file_edits=[],
                progress_entry=f"Agent {agent_id} blocked by merge conflict",
                commit_sha=None,
                success=False,
            )

        # Build context with git log from other agents
        progress_tail = read_progress_tail(self.cfg.progress_file)
        recent_log = self.git.get_recent_log(15)
        
        augmented_progress = progress_tail
        if recent_log:
            augmented_progress += f"\n\n### Recent commits from all agents:\n{recent_log}"

        # Create agent and run step in worktree context
        agent = self.agent_factory(agent_id, self.cfg.provider)
        
        original_cwd = os.getcwd()
        os.chdir(wt_dir)
        try:
            result = agent.run_step(task, tasks_snapshot, augmented_progress)
        finally:
            os.chdir(original_cwd)

        # Commit agent's work
        commit_sha = self.git.commit_agent_work(
            agent_id, task_id, task_title
        )

        if commit_sha:
            print(f"[agent-{agent_id}] Committed: {commit_sha[:8]}")

        return AgentStepResult(
            agent_id=agent_id,
            task=task,
            task_update=result["task_update"],
            file_edits=result.get("file_edits", []),
            progress_entry=result.get("progress_entry"),
            commit_sha=commit_sha,
            success=True,
        )

    def _integrate_result(self, result: AgentStepResult) -> None:
        """Integrate agent's result back into main."""
        task_id = result.task.get("id", "unknown")

        # Update task status on main
        tasks = load_tasks(self.cfg.features_file)
        self._apply_task_update(tasks, result.task_update)
        save_tasks(self.cfg.features_file, tasks)

        # Append progress
        if result.progress_entry:
            entry = f"[Agent {result.agent_id}] {result.progress_entry}"
            append_progress(self.cfg.progress_file, entry)

        # Merge agent's code changes into main
        if result.commit_sha:
            if self.git.merge_to_main(result.agent_id):
                status = result.task_update.get("status", "?")
                print(f"[agent-{result.agent_id}] Merged to main ({task_id}: {status})")
            else:
                # Mark task as needing manual merge
                tasks = load_tasks(self.cfg.features_file)
                for t in tasks:
                    if t.get("id") == task_id:
                        t["status"] = "blocked"
                        t["notes"] = "Merge conflict - needs manual resolution"
                        break
                save_tasks(self.cfg.features_file, tasks)

    def _apply_task_update(
        self, tasks: list[dict[str, Any]], update: dict[str, Any]
    ) -> None:
        """Update matching task in place."""
        task_id = update.get("id")
        for t in tasks:
            if t.get("id") == task_id:
                t.update(update)
                return


# Simple single-agent orchestrator for backwards compatibility
class Orchestrator(MultiAgentOrchestrator):
    """Single-agent orchestrator (backwards compatible)."""

    def __init__(
        self,
        *,
        cfg: HarnessConfig,
        agent: BaseAgent,
        max_steps: int | None = None,
    ) -> None:
        self.cfg = cfg
        self.single_agent = agent
        self.max_steps = max_steps
        self.git = GitWorktreeManager(Path.cwd())
        
        # Factory that always returns the same agent
        self.agent_factory = lambda aid, provider: self.single_agent
        
        # Force single agent
        self.cfg.num_agents = 1
