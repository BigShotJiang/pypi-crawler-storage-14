class TopologyEngine:
    pass
