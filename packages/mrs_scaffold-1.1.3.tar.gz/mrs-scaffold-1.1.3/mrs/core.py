class MRSCore:
    pass
