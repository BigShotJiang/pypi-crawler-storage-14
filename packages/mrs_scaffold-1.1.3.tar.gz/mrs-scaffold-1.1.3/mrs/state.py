class StateTracker:
    pass
