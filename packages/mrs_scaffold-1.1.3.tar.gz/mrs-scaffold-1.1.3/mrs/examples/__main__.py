"""CLI entrypoint for mrs.examples module."""

from mrs.examples.basic_reasoning import main

if __name__ == "__main__":
    main()
