class RecursionNode:
    pass
