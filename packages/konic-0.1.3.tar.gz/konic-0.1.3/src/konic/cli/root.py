import os
from pathlib import Path

from cookiecutter.main import cookiecutter
from typer import Typer

from konic.cli.decorators import error_handler, pretty_output
from konic.cli.enums import BoilerplateOptions
from konic.cli.env_keys import KonicCLIEnvVars
from konic.cli.src import agents, data, health, training
from konic.cli.utils import compile_artifact

app = Typer(
    name="konic",
    help="Official Konic Agent Development Toolkit",
    no_args_is_help=True,
)

app.add_typer(health.app, name="health")
app.add_typer(agents.app, name="agent")
app.add_typer(training.app, name="train")
app.add_typer(data.app, name="data")


@app.command(name="get-host")
@error_handler(exit_on_error=True)
@pretty_output(title="Konic Host Configuration", border_style="cyan")
def get_host() -> str:
    """
    Get the Konic host URL from environment variables
    """
    host = os.environ.get(KonicCLIEnvVars.KONIC_HOST.value, "")
    return host if host else "Not configured"


@app.command(name="init")
@error_handler(exit_on_error=True)
def create_boilerplate(template: BoilerplateOptions = BoilerplateOptions.basic):
    path = Path(__file__).parent / "boilerplates" / template.value
    cookiecutter(str(path))


@app.command(name="compile")
@error_handler(exit_on_error=True)
def compile(filepath: str):
    compile_artifact(filepath)
