#!/usr/bin/env python3
"""CLI script to create tar.gz archives of collected data."""

import argparse
import sys
from pathlib import Path

from softverse.config import get_config
from softverse.utils.file_utils import create_tar_gz, ensure_directory
from softverse.utils.logging_utils import get_logger, setup_logging


def create_archive_if_needed(
    source_dir: Path, output_file: Path, force_refresh: bool = False
) -> bool:
    """Create archive if source directory exists and needs updating.

    Args:
        source_dir: Directory to archive
        output_file: Output archive path
        force_refresh: Force recreation even if archive exists

    Returns:
        True if archive was created or already up to date
    """
    logger = get_logger("create_archives")

    if not source_dir.exists():
        logger.warning(f"Source directory does not exist: {source_dir}")
        return False

    if not any(source_dir.iterdir()):
        logger.warning(f"Source directory is empty: {source_dir}")
        return False

    if output_file.exists() and not force_refresh:
        # Check if archive is newer than source directory
        archive_mtime = output_file.stat().st_mtime
        source_mtime = max(
            (f.stat().st_mtime for f in source_dir.rglob("*") if f.is_file()),
            default=0,
        )

        if archive_mtime > source_mtime:
            logger.info(f"Archive is up to date: {output_file}")
            return True

    logger.info(f"Creating archive: {source_dir} -> {output_file}")
    return create_tar_gz(source_dir, output_file)


def main():
    """Main entry point for archive creation CLI."""
    parser = argparse.ArgumentParser(
        description="Create tar.gz archives of collected data and results",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument(
        "--output-dir",
        type=str,
        help="Output directory for archives (default from config)",
    )
    parser.add_argument(
        "--datasets-dir",
        type=str,
        help="Directory with dataset files to archive",
    )
    parser.add_argument(
        "--scripts-dir",
        type=str,
        help="Directory with script files to archive",
    )
    parser.add_argument(
        "--files-dir", type=str, help="Directory with file metadata to archive"
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force recreation of all archives",
    )
    parser.add_argument(
        "--archives",
        nargs="+",
        choices=["datasets", "files", "scripts", "all"],
        default=["all"],
        help="Which archives to create",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set logging level",
    )
    parser.add_argument(
        "--log-file", type=str, help="Log file path (default from config)"
    )

    args = parser.parse_args()

    # Setup logging
    logger = setup_logging(level=args.log_level, log_file=args.log_file)

    try:
        logger.info("Starting archive creation")

        # Get configuration
        config = get_config(args.config)
        output_config = config.output_config

        # Determine directories
        output_dir = Path(args.output_dir or output_config.get("base_dir", "data/"))
        datasets_dir = Path(args.datasets_dir or "data/datasets/")
        scripts_dir = Path(args.scripts_dir or "scripts/")
        files_dir = Path(args.files_dir or "files_dfs/")

        ensure_directory(output_dir)

        # Determine which archives to create
        if "all" in args.archives:
            archives_to_create = ["datasets", "files", "scripts"]
        else:
            archives_to_create = args.archives

        # Archive configurations
        archive_configs = {
            "datasets": {
                "source": datasets_dir,
                "output": output_dir
                / output_config.get(
                    "files.datasets_archive", "datasets_by_dataverse.tar.gz"
                ),
                "description": "Dataset metadata by dataverse",
            },
            "files": {
                "source": files_dir,
                "output": output_dir
                / output_config.get("files.files_archive", "files_in_dataverse.tar.gz"),
                "description": "File metadata from dataverse",
            },
            "scripts": {
                "source": scripts_dir,
                "output": output_dir
                / output_config.get("files.scripts_archive", "script_files.tar.gz"),
                "description": "Downloaded script files",
            },
        }

        # Create archives
        results = {}
        for archive_name in archives_to_create:
            if archive_name in archive_configs:
                config_info = archive_configs[archive_name]

                logger.info("=" * 50)
                logger.info(f"CREATING {archive_name.upper()} ARCHIVE")
                logger.info(f"Description: {config_info['description']}")
                logger.info("=" * 50)

                success = create_archive_if_needed(
                    config_info["source"],
                    config_info["output"],
                    args.force_refresh,
                )
                results[archive_name] = success

                if success:
                    # Get archive size for reporting
                    if config_info["output"].exists():
                        size_mb = config_info["output"].stat().st_size / (1024 * 1024)
                        logger.info(f"Archive size: {size_mb:.1f} MB")
            else:
                logger.error(f"Unknown archive type: {archive_name}")
                results[archive_name] = False

        # Report results
        logger.info("=" * 50)
        logger.info("ARCHIVE CREATION SUMMARY")
        logger.info("=" * 50)

        total_success = 0
        total_attempted = 0

        for archive_name, success in results.items():
            status = "✓ SUCCESS" if success else "✗ FAILED"
            logger.info(f"{archive_name.upper()}: {status}")
            if success:
                total_success += 1
            total_attempted += 1

        if total_attempted == 0:
            logger.error("No archives were processed")
            return 1

        logger.info(f"Overall: {total_success}/{total_attempted} archives successful")

        if total_success == total_attempted:
            logger.info("All archives created successfully")
            return 0
        elif total_success > 0:
            logger.warning("Archive creation partially successful")
            return 2  # Partial success exit code
        else:
            logger.error("All archive creation failed")
            return 1

    except KeyboardInterrupt:
        logger.info("Archive creation interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error during archive creation: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
