#!/usr/bin/env python3
"""CLI script to run the complete Softverse pipeline."""

import argparse
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

from softverse.analyzers.import_analyzer import ImportAnalyzer
from softverse.collectors.dataverse_collector import DataverseDatasetCollector
from softverse.collectors.dataverse_scripts import DataverseScriptCollector
from softverse.collectors.icpsr_collector import ICPSRScriptCollector
from softverse.collectors.zenodo_collector import ZenodoScriptCollector
from softverse.config import get_config
from softverse.utils.file_utils import create_tar_gz
from softverse.utils.logging_utils import get_logger, setup_logging


class PipelineRunner:
    """Orchestrates the complete Softverse pipeline."""

    def __init__(self, config_path: Optional[str] = None):
        """Initialize pipeline runner.

        Args:
            config_path: Path to configuration file
        """
        self.config = get_config(config_path)
        self.logger = get_logger("pipeline")
        self.results: Dict[str, Dict[str, Any]] = {}

    def run_phase(self, phase_name: str, phase_func, **kwargs) -> bool:
        """Run a pipeline phase with timing and error handling.

        Args:
            phase_name: Name of the phase
            phase_func: Function to execute
            **kwargs: Arguments to pass to the function

        Returns:
            True if phase succeeded
        """
        self.logger.info("=" * 60)
        self.logger.info(f"STARTING PHASE: {phase_name.upper()}")
        self.logger.info("=" * 60)

        start_time = time.time()

        try:
            success = phase_func(**kwargs)
            end_time = time.time()
            duration = end_time - start_time

            self.results[phase_name] = {
                "success": success,
                "duration": duration,
                "error": None,
            }

            status = "✓ SUCCESS" if success else "✗ FAILED"
            self.logger.info(f"Phase {phase_name}: {status} ({duration:.1f}s)")

            return success

        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time

            self.results[phase_name] = {
                "success": False,
                "duration": duration,
                "error": str(e),
            }

            self.logger.error(f"Phase {phase_name} failed: {e}")
            return False

    def run_dataset_collection(self, force_refresh: bool = False, **kwargs) -> bool:
        """Run Phase 1: Dataset collection."""
        collector = DataverseDatasetCollector(None)
        return collector.collect_all_datasets(force_refresh=force_refresh)

    def run_script_collection(
        self,
        sources: list = None,
        force_refresh: bool = False,
        max_zenodo: Optional[int] = None,
        max_icpsr: Optional[int] = None,
        **kwargs,
    ) -> bool:
        """Run Phase 2: Script collection."""
        if sources is None:
            sources = ["dataverse", "zenodo", "icpsr"]

        overall_success = True

        # Dataverse scripts
        if "dataverse" in sources:
            self.logger.info("Collecting Dataverse scripts")
            try:
                collector = DataverseScriptCollector(None)
                success = collector.collect_all_scripts(force_refresh=force_refresh)
                if not success:
                    overall_success = False
                    self.logger.error("Dataverse script collection failed")
            except Exception as e:
                overall_success = False
                self.logger.error(f"Dataverse script collection error: {e}")

        # Zenodo scripts
        if "zenodo" in sources:
            self.logger.info("Collecting Zenodo scripts")
            try:
                collector = ZenodoScriptCollector(None)
                success = collector.collect_all_scripts(
                    max_records=max_zenodo, force_refresh=force_refresh
                )
                if not success:
                    overall_success = False
                    self.logger.error("Zenodo script collection failed")
            except Exception as e:
                overall_success = False
                self.logger.error(f"Zenodo script collection error: {e}")

        # ICPSR scripts
        if "icpsr" in sources:
            self.logger.info("Collecting ICPSR scripts")
            try:
                collector = ICPSRScriptCollector(None)
                success = collector.collect_all_scripts(
                    max_studies=max_icpsr, force_refresh=force_refresh
                )
                if not success:
                    overall_success = False
                    self.logger.error("ICPSR script collection failed")
            except Exception as e:
                overall_success = False
                self.logger.error(f"ICPSR script collection error: {e}")

        return overall_success

    def run_import_analysis(
        self, languages: list = None, force_refresh: bool = False, **kwargs
    ) -> bool:
        """Run Phase 3: Import analysis."""
        if languages is None:
            languages = ["R", "Python", "Stata"]

        analyzer = ImportAnalyzer(None)
        return analyzer.analyze_all_scripts(
            languages=languages, force_refresh=force_refresh
        )

    def run_archive_creation(self, force_refresh: bool = False, **kwargs) -> bool:
        """Run Phase 4: Archive creation."""
        output_config = self.config.output_config
        base_dir = Path(output_config.get("base_dir", "data/"))

        archives = [
            ("datasets", Path("data/datasets/"), "datasets_by_dataverse.tar.gz"),
            ("files", Path("files_dfs/"), "files_in_dataverse.tar.gz"),
            ("scripts", Path("scripts/"), "script_files.tar.gz"),
        ]

        overall_success = True

        for name, source_dir, filename in archives:
            if source_dir.exists() and any(source_dir.iterdir()):
                output_file = base_dir / filename
                self.logger.info(f"Creating {name} archive: {output_file}")

                success = create_tar_gz(source_dir, output_file)
                if not success:
                    overall_success = False
                    self.logger.error(f"Failed to create {name} archive")
                else:
                    size_mb = output_file.stat().st_size / (1024 * 1024)
                    self.logger.info(f"{name} archive: {size_mb:.1f} MB")
            else:
                self.logger.warning(f"Skipping {name} archive - no data found")

        return overall_success

    def run_complete_pipeline(
        self,
        phases: list = None,
        sources: list = None,
        languages: list = None,
        force_refresh: bool = False,
        max_zenodo: Optional[int] = None,
        max_icpsr: Optional[int] = None,
        **kwargs,
    ) -> bool:
        """Run the complete pipeline.

        Args:
            phases: List of phases to run
            sources: List of script sources
            languages: List of languages to analyze
            force_refresh: Force refresh all data
            max_zenodo: Maximum Zenodo records
            max_icpsr: Maximum ICPSR studies

        Returns:
            True if all phases succeeded
        """
        if phases is None:
            phases = ["datasets", "scripts", "analysis", "archives"]

        self.logger.info("🚀 STARTING COMPLETE SOFTVERSE PIPELINE")
        self.logger.info(f"Phases: {', '.join(phases)}")
        if sources:
            self.logger.info(f"Script sources: {', '.join(sources)}")
        if languages:
            self.logger.info(f"Languages: {', '.join(languages)}")

        pipeline_start = time.time()
        overall_success = True

        # Phase 1: Dataset Collection
        if "datasets" in phases:
            success = self.run_phase(
                "Dataset Collection",
                self.run_dataset_collection,
                force_refresh=force_refresh,
            )
            if not success:
                overall_success = False

        # Phase 2: Script Collection
        if "scripts" in phases:
            success = self.run_phase(
                "Script Collection",
                self.run_script_collection,
                sources=sources,
                force_refresh=force_refresh,
                max_zenodo=max_zenodo,
                max_icpsr=max_icpsr,
            )
            if not success:
                overall_success = False

        # Phase 3: Import Analysis
        if "analysis" in phases:
            success = self.run_phase(
                "Import Analysis",
                self.run_import_analysis,
                languages=languages,
                force_refresh=force_refresh,
            )
            if not success:
                overall_success = False

        # Phase 4: Archive Creation
        if "archives" in phases:
            success = self.run_phase(
                "Archive Creation",
                self.run_archive_creation,
                force_refresh=force_refresh,
            )
            if not success:
                overall_success = False

        # Final summary
        pipeline_end = time.time()
        total_duration = pipeline_end - pipeline_start

        self.logger.info("=" * 60)
        self.logger.info("🏁 PIPELINE EXECUTION SUMMARY")
        self.logger.info("=" * 60)

        for phase_name, result in self.results.items():
            success = result["success"]
            duration = result["duration"]
            status = "✓" if success else "✗"
            self.logger.info(f"{status} {phase_name}: {duration:.1f}s")

            if result["error"]:
                self.logger.error(f"  Error: {result['error']}")

        self.logger.info(f"Total pipeline duration: {total_duration:.1f}s")

        if overall_success:
            self.logger.info("🎉 PIPELINE COMPLETED SUCCESSFULLY")
        else:
            self.logger.error("❌ PIPELINE FAILED")

        return overall_success


def main():
    """Main entry point for pipeline execution."""
    parser = argparse.ArgumentParser(
        description="Run the complete Softverse pipeline",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument(
        "--phases",
        nargs="+",
        choices=["datasets", "scripts", "analysis", "archives", "all"],
        default=["all"],
        help="Pipeline phases to run",
    )
    parser.add_argument(
        "--sources",
        nargs="+",
        choices=["dataverse", "zenodo", "icpsr", "all"],
        default=["all"],
        help="Script sources to collect from",
    )
    parser.add_argument(
        "--languages",
        nargs="+",
        choices=["R", "Python", "Stata", "all"],
        default=["all"],
        help="Languages to analyze",
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force refresh all data, ignore existing files",
    )
    parser.add_argument(
        "--max-zenodo-records",
        type=int,
        help="Maximum number of Zenodo records to process",
    )
    parser.add_argument(
        "--max-icpsr-studies",
        type=int,
        help="Maximum number of ICPSR studies to process",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set logging level",
    )
    parser.add_argument(
        "--log-file", type=str, help="Log file path (default from config)"
    )

    args = parser.parse_args()

    # Setup logging
    logger = setup_logging(level=args.log_level, log_file=args.log_file)

    try:
        # Process arguments
        if "all" in args.phases:
            phases = ["datasets", "scripts", "analysis", "archives"]
        else:
            phases = args.phases

        if "all" in args.sources:
            sources = ["dataverse", "zenodo", "icpsr"]
        else:
            sources = args.sources

        if "all" in args.languages:
            languages = ["R", "Python", "Stata"]
        else:
            languages = args.languages

        # Create and run pipeline
        runner = PipelineRunner(args.config)
        success = runner.run_complete_pipeline(
            phases=phases,
            sources=sources,
            languages=languages,
            force_refresh=args.force_refresh,
            max_zenodo=args.max_zenodo_records,
            max_icpsr=args.max_icpsr_studies,
        )

        return 0 if success else 1

    except KeyboardInterrupt:
        logger.info("Pipeline execution interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error during pipeline execution: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
