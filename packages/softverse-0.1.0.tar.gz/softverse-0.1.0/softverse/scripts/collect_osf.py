"""Script to collect data from OSF (Open Science Framework)."""

import sys
from pathlib import Path

import click

from softverse.analyzers.journal_analyzer import JournalAnalyzer
from softverse.collectors.osf_collector import OSFCollector
from softverse.config import get_config
from softverse.utils.logging_utils import get_logger

logger = get_logger(__name__)


@click.group()
def cli():
    """OSF (Open Science Framework) data collection and analysis tools."""
    pass


@cli.command()
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory for collected data",
)
@click.option(
    "--node-ids",
    "-n",
    multiple=True,
    help="Specific OSF node IDs to collect (can be specified multiple times)",
)
@click.option(
    "--node-ids-file",
    "-f",
    type=click.Path(exists=True, path_type=Path),
    help="File containing OSF node IDs (one per line)",
)
@click.option(
    "--institution",
    "-i",
    help="OSF institution ID to collect all nodes from",
)
@click.option(
    "--search",
    "-s",
    help="Search query to find nodes",
)
@click.option(
    "--filter-title",
    help="Filter nodes by title keyword",
)
@click.option(
    "--filter-public",
    is_flag=True,
    default=None,
    help="Only collect public nodes",
)
@click.option(
    "--recursive/--no-recursive",
    default=True,
    help="Recursively collect child components",
)
@click.option(
    "--download-files/--no-download-files",
    default=True,
    help="Download actual files (vs. metadata only)",
)
@click.option(
    "--max-nodes",
    type=int,
    default=None,
    help="Maximum number of nodes to collect",
)
@click.option(
    "--api-token",
    envvar="OSF_API_TOKEN",
    help="OSF API token (can also be set via OSF_API_TOKEN env var)",
)
@click.option(
    "--rate-limit",
    type=float,
    default=0.5,
    help="Delay between API requests in seconds",
)
def collect(
    output_dir: Path | None,
    node_ids: tuple,
    node_ids_file: Path | None,
    institution: str | None,
    search: str | None,
    filter_title: str | None,
    filter_public: bool | None,
    recursive: bool,
    download_files: bool,
    max_nodes: int | None,
    api_token: str | None,
    rate_limit: float,
) -> None:
    """Collect data from OSF (Open Science Framework).

    Examples:
        # Collect specific nodes
        collect-osf --node-ids abc123 --node-ids xyz789

        # Collect from a file of node IDs
        collect-osf --node-ids-file osf_nodes.txt

        # Collect all nodes from an institution
        collect-osf --institution cos

        # Search and collect
        collect-osf --search "replication data" --filter-public

        # Collect with custom settings
        collect-osf --node-ids abc123 --no-recursive --no-download-files
    """
    # Load configuration
    config = get_config()

    # Set output directory
    if output_dir is None:
        output_dir = Path(config.get("data_sources.osf.output_dir", "outputs/osf"))

    # Initialize collector
    collector = OSFCollector(api_token=api_token, rate_limit_delay=rate_limit)

    # Collect node IDs from various sources
    all_node_ids: list[str] = []

    # From command line
    if node_ids:
        all_node_ids.extend(node_ids)
        logger.info(f"Added {len(node_ids)} node IDs from command line")

    # From file
    if node_ids_file:
        with open(node_ids_file) as f:
            file_ids = [line.strip() for line in f if line.strip()]
            all_node_ids.extend(file_ids)
            logger.info(f"Added {len(file_ids)} node IDs from file")

    # From institution
    if institution:
        logger.info(f"Collecting nodes from institution: {institution}")
        stats = collector.collect_from_institution(
            institution,
            output_dir,
            max_nodes=max_nodes,
            download_files=download_files,
            recursive=recursive,
        )
        _print_stats(stats)
        return

    # From search
    if search or filter_title or filter_public is not None:
        filters = {}
        if filter_title:
            filters["title"] = filter_title
        if filter_public is not None:
            filters["public"] = str(filter_public).lower()

        if search:
            # Use search API
            logger.info(f"Searching for nodes with query: {search}")
            search_results = collector.search_nodes(search)
            search_node_ids = [
                node["id"] for node in search_results if "id" in node
            ][:max_nodes]
            all_node_ids.extend(search_node_ids)
            logger.info(f"Found {len(search_node_ids)} nodes from search")
        else:
            # Use filters
            logger.info(f"Filtering nodes with: {filters}")
            filtered_nodes = collector.get_nodes(filters=filters)
            filtered_ids = [
                node["id"] for node in filtered_nodes if "id" in node
            ][:max_nodes]
            all_node_ids.extend(filtered_ids)
            logger.info(f"Found {len(filtered_ids)} nodes from filters")

    # If no node IDs collected, try to get all public nodes (with limit)
    if not all_node_ids:
        logger.warning("No specific nodes requested. Fetching recent public nodes...")
        default_filters = config.get("data_sources.osf.default_filters", {})
        nodes = collector.get_nodes(filters=default_filters)

        # Apply max_nodes limit
        if max_nodes:
            nodes = nodes[:max_nodes]
        elif config.get("data_sources.osf.max_nodes_per_run"):
            nodes = nodes[: config.get("data_sources.osf.max_nodes_per_run")]

        all_node_ids = [node["id"] for node in nodes if "id" in node]
        logger.info(f"Found {len(all_node_ids)} public nodes to collect")

    # Remove duplicates while preserving order
    unique_node_ids = list(dict.fromkeys(all_node_ids))

    if not unique_node_ids:
        logger.error("No nodes to collect!")
        sys.exit(1)

    logger.info(f"Collecting {len(unique_node_ids)} unique nodes...")

    # Collect the nodes
    stats = collector.collect_from_nodes(
        unique_node_ids,
        output_dir,
        download_files=download_files,
        recursive=recursive,
    )

    # Print statistics
    _print_stats(stats)


def _print_stats(stats: dict) -> None:
    """Print collection statistics.

    Args:
        stats: Statistics dictionary
    """
    logger.info("=" * 50)
    logger.info("Collection Statistics:")
    logger.info(f"  Total nodes processed: {stats.get('total_nodes', 0)}")
    logger.info(f"  Total files downloaded: {stats.get('total_files', 0)}")

    errors = stats.get("errors", [])
    if errors:
        logger.warning(f"  Errors encountered: {len(errors)}")
        for error in errors[:5]:  # Show first 5 errors
            logger.warning(f"    - Node {error['node_id']}: {error['error']}")
        if len(errors) > 5:
            logger.warning(f"    ... and {len(errors) - 5} more errors")
    else:
        logger.info("  No errors encountered")

    logger.info("=" * 50)


@cli.command()
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory for journal analysis results",
)
@click.option(
    "--doi-sample-size",
    type=int,
    default=100,
    help="Sample size for DOI-based analysis",
)
@click.option(
    "--include-collections/--no-collections",
    default=True,
    help="Include collection-based analysis",
)
@click.option(
    "--include-dois/--no-dois",
    default=True,
    help="Include DOI-based analysis",
)
@click.option(
    "--include-text/--no-text",
    default=True,
    help="Include text-based analysis",
)
@click.option(
    "--api-token",
    envvar="OSF_API_TOKEN",
    help="OSF API token (can also be set via OSF_API_TOKEN env var)",
)
@click.option(
    "--rate-limit",
    type=float,
    default=1.0,
    help="Delay between API requests in seconds",
)
def discover_journals(
    output_dir: Path | None,
    doi_sample_size: int,
    include_collections: bool,
    include_dois: bool,
    include_text: bool,
    api_token: str | None,
    rate_limit: float,
) -> None:
    """Discover journals hosting data on OSF.

    This command analyzes OSF projects to identify which journals have
    their data hosted on the platform using multiple approaches:

    - Collections analysis: Find journal collections
    - DOI analysis: Resolve DOIs to journal metadata
    - Text analysis: Search for journal mentions in project metadata

    Examples:
        # Full analysis with default settings
        collect-osf discover-journals

        # Quick analysis with smaller sample
        collect-osf discover-journals --doi-sample-size 50

        # Only DOI-based analysis
        collect-osf discover-journals --no-collections --no-text
    """
    # Load configuration
    config = get_config()

    # Set output directory
    if output_dir is None:
        output_dir = Path(config.get("data_sources.osf.output_dir", "outputs/osf")) / "journal_analysis"

    logger.info("Starting journal discovery analysis")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"DOI sample size: {doi_sample_size}")
    logger.info(f"Include collections: {include_collections}")
    logger.info(f"Include DOIs: {include_dois}")
    logger.info(f"Include text: {include_text}")

    # Initialize collector and analyzer
    collector = OSFCollector(api_token=api_token, rate_limit_delay=rate_limit)
    analyzer = JournalAnalyzer(osf_collector=collector, crossref_rate_limit=rate_limit)

    # Run comprehensive analysis
    try:
        report = analyzer.generate_comprehensive_report(
            output_dir=output_dir,
            include_collections=include_collections,
            include_dois=include_dois,
            include_text=include_text,
            doi_sample_size=doi_sample_size,
        )

        # Print summary
        _print_journal_summary(report)

        logger.info(f"Journal analysis complete! Results saved to {output_dir}")
        logger.info(f"Summary report: {output_dir}/journal_summary.txt")
        logger.info(f"Detailed report: {output_dir}/comprehensive_journal_report.json")

    except Exception as e:
        logger.error(f"Journal analysis failed: {e}")
        sys.exit(1)


@cli.command()
@click.option(
    "--output-file",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output file for collection analysis results",
)
@click.option(
    "--api-token",
    envvar="OSF_API_TOKEN",
    help="OSF API token (can also be set via OSF_API_TOKEN env var)",
)
@click.option(
    "--rate-limit",
    type=float,
    default=0.5,
    help="Delay between API requests in seconds",
)
def analyze_collections(
    output_file: Path | None,
    api_token: str | None,
    rate_limit: float,
) -> None:
    """Analyze OSF collections to find journal partnerships.

    This command analyzes all OSF collections to identify those that
    appear to be related to journals or publications.

    Examples:
        # Analyze collections with default output
        collect-osf analyze-collections

        # Save to specific file
        collect-osf analyze-collections -o journal_collections.json
    """
    # Load configuration
    config = get_config()

    # Set output file
    if output_file is None:
        output_dir = Path(config.get("data_sources.osf.output_dir", "outputs/osf"))
        output_file = output_dir / "journal_collections.json"

    logger.info("Analyzing OSF collections for journal partnerships")
    logger.info(f"Output file: {output_file}")

    # Initialize collector
    collector = OSFCollector(api_token=api_token, rate_limit_delay=rate_limit)

    try:
        # Run collection analysis
        analysis = collector.analyze_journal_collections(output_path=output_file)

        # Print summary
        logger.info("=" * 50)
        logger.info("Collection Analysis Summary:")
        logger.info(f"  Total collections: {analysis['total_collections']}")
        logger.info(f"  Journal collections: {analysis['journal_count']}")
        logger.info(f"  Total journal projects: {analysis['total_journal_projects']}")
        logger.info("=" * 50)

        # Show top collections
        journal_collections = analysis['journal_collections']
        if journal_collections:
            logger.info("Top journal collections:")
            sorted_collections = sorted(
                journal_collections,
                key=lambda x: x['project_count'],
                reverse=True
            )
            for i, collection in enumerate(sorted_collections[:10]):
                logger.info(f"  {i+1:2d}. {collection['title']} ({collection['project_count']} projects)")

        logger.info(f"Complete analysis saved to: {output_file}")

    except Exception as e:
        logger.error(f"Collection analysis failed: {e}")
        sys.exit(1)


def _print_journal_summary(report: dict) -> None:
    """Print journal discovery summary.

    Args:
        report: Analysis report data
    """
    logger.info("=" * 60)
    logger.info("JOURNAL DISCOVERY SUMMARY")
    logger.info("=" * 60)

    summary = report.get("summary", {})
    logger.info(f"Total unique journals identified: {summary.get('total_unique_journals', 0)}")
    logger.info(f"Total projects mapped: {summary.get('total_projects_mapped', 0)}")
    logger.info(f"Analysis methods used: {', '.join(summary.get('analysis_methods', []))}")
    logger.info("")

    # Collections summary
    if "collections" in summary:
        collections = summary["collections"]
        logger.info("COLLECTIONS ANALYSIS:")
        logger.info(f"  Journal collections found: {collections.get('journal_collections', 0)}")
        logger.info(f"  Projects in collections: {collections.get('projects_in_collections', 0)}")
        logger.info("")

    # DOI summary
    if "doi_analysis" in summary:
        doi_summary = summary["doi_analysis"]
        logger.info("DOI-BASED ANALYSIS:")
        logger.info(f"  Journals from DOIs: {doi_summary.get('journals_from_dois', 0)}")
        logger.info(f"  Projects with DOIs: {doi_summary.get('projects_with_dois', 0)}")
        logger.info(f"  DOI resolution success rate: {doi_summary.get('success_rate', 0):.1f}%")
        logger.info("")

    # Text summary
    if "text_analysis" in summary:
        text_summary = summary["text_analysis"]
        logger.info("TEXT-BASED ANALYSIS:")
        logger.info(f"  Journals mentioned: {text_summary.get('journals_mentioned', 0)}")
        logger.info(f"  Projects analyzed: {text_summary.get('projects_analyzed', 0)}")
        logger.info("")

    # Top journals from DOI analysis
    if "doi_analysis" in report:
        logger.info("TOP JOURNALS BY PROJECT COUNT:")
        journals = report["doi_analysis"].get("journals", {})
        top_journals = sorted(journals.items(), key=lambda x: x[1].get("project_count", 0), reverse=True)
        for i, (journal_name, data) in enumerate(top_journals[:10]):
            logger.info(f"  {i+1:2d}. {journal_name} ({data.get('project_count', 0)} projects)")

    logger.info("=" * 60)


if __name__ == "__main__":
    cli()
