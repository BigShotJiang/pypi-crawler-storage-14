#!/usr/bin/env python3
"""CLI script to collect datasets from Dataverse."""

import argparse
import sys

from softverse.collectors.dataverse_collector import DataverseDatasetCollector
from softverse.utils.logging_utils import setup_logging


def main():
    """Main entry point for dataset collection CLI."""
    parser = argparse.ArgumentParser(
        description="Collect dataset information from Dataverse instances",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument(
        "--input-csv",
        type=str,
        help="Path to CSV file with dataverse information (default from config)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        help="Output directory for dataset files (default from config)",
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force refresh all datasets, ignore existing files",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set logging level",
    )
    parser.add_argument(
        "--log-file", type=str, help="Log file path (default from config)"
    )

    args = parser.parse_args()

    # Setup logging
    logger = setup_logging(level=args.log_level, log_file=args.log_file)

    try:
        logger.info("Starting dataset collection")

        # Create collector
        collector = DataverseDatasetCollector(args.config)

        # Run collection
        success = collector.collect_all_datasets(
            input_csv=args.input_csv,
            output_dir=args.output_dir,
            force_refresh=args.force_refresh,
        )

        if success:
            logger.info("Dataset collection completed successfully")
            return 0
        else:
            logger.error("Dataset collection failed")
            return 1

    except KeyboardInterrupt:
        logger.info("Dataset collection interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error during dataset collection: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
