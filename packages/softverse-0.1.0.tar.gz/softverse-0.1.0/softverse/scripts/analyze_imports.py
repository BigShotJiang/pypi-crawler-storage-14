#!/usr/bin/env python3
"""CLI script to analyze imports from collected script files."""

import argparse
import sys

from softverse.analyzers.import_analyzer import ImportAnalyzer
from softverse.utils.logging_utils import setup_logging


def main():
    """Main entry point for import analysis CLI."""
    parser = argparse.ArgumentParser(
        description="Analyze package imports from collected script files",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument(
        "--scripts-dir",
        type=str,
        help="Directory containing collected script files (default from config)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        help="Output directory for analysis results (default from config)",
    )
    parser.add_argument(
        "--languages",
        nargs="+",
        choices=["R", "Python", "Stata", "all"],
        default=["all"],
        help="Languages to analyze",
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force refresh analysis, ignore existing results",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set logging level",
    )
    parser.add_argument(
        "--log-file", type=str, help="Log file path (default from config)"
    )

    args = parser.parse_args()

    # Setup logging
    logger = setup_logging(level=args.log_level, log_file=args.log_file)

    try:
        logger.info("Starting import analysis")

        # Process language selection
        if "all" in args.languages:
            languages = ["R", "Python", "Stata"]
        else:
            languages = args.languages

        logger.info(f"Analyzing languages: {', '.join(languages)}")

        # Create analyzer
        analyzer = ImportAnalyzer(args.config)

        # Run analysis
        success = analyzer.analyze_all_scripts(
            scripts_dir=args.scripts_dir,
            output_dir=args.output_dir,
            languages=languages,
            force_refresh=args.force_refresh,
        )

        if success:
            logger.info("Import analysis completed successfully")
            return 0
        else:
            logger.error("Import analysis failed")
            return 1

    except KeyboardInterrupt:
        logger.info("Import analysis interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error during import analysis: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
