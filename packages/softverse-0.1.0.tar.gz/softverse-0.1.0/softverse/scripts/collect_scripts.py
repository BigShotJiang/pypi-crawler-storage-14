#!/usr/bin/env python3
"""CLI script to collect script files from multiple sources."""

import argparse
import sys
from typing import List, Optional

from softverse.collectors.dataverse_scripts import DataverseScriptCollector
from softverse.collectors.icpsr_collector import ICPSRScriptCollector
from softverse.collectors.zenodo_collector import ZenodoScriptCollector
from softverse.utils.logging_utils import get_logger, setup_logging


def collect_dataverse_scripts(
    config: Optional[str] = None,
    datasets_dir: Optional[str] = None,
    output_dir: Optional[str] = None,
    force_refresh: bool = False,
    num_workers: Optional[int] = None,
) -> bool:
    """Collect scripts from Dataverse."""
    logger = get_logger("collect_scripts")
    logger.info("Starting Dataverse script collection")

    try:
        collector = DataverseScriptCollector(config)
        success = collector.collect_all_scripts(
            datasets_dir=datasets_dir,
            output_dir=output_dir,
            force_refresh=force_refresh,
            num_workers=num_workers,
        )
        if success:
            logger.info("Dataverse script collection completed successfully")
        else:
            logger.error("Dataverse script collection failed")
        return success
    except Exception as e:
        logger.error(f"Dataverse script collection error: {e}")
        return False


def collect_zenodo_scripts(
    config: Optional[str] = None,
    output_dir: Optional[str] = None,
    communities: Optional[List[str]] = None,
    max_records: Optional[int] = None,
    force_refresh: bool = False,
) -> bool:
    """Collect scripts from Zenodo."""
    logger = get_logger("collect_scripts")
    logger.info("Starting Zenodo script collection")

    try:
        collector = ZenodoScriptCollector(config)
        success = collector.collect_all_scripts(
            output_dir=output_dir,
            communities=communities,
            max_records=max_records,
            force_refresh=force_refresh,
        )
        if success:
            logger.info("Zenodo script collection completed successfully")
        else:
            logger.error("Zenodo script collection failed")
        return success
    except Exception as e:
        logger.error(f"Zenodo script collection error: {e}")
        return False


def collect_icpsr_scripts(
    config: Optional[str] = None,
    output_dir: Optional[str] = None,
    search_query: str = "",
    max_studies: Optional[int] = None,
    force_refresh: bool = False,
) -> bool:
    """Collect scripts from ICPSR."""
    logger = get_logger("collect_scripts")
    logger.info("Starting ICPSR script collection")

    try:
        collector = ICPSRScriptCollector(config)
        success = collector.collect_all_scripts(
            output_dir=output_dir,
            search_query=search_query,
            max_studies=max_studies,
            force_refresh=force_refresh,
        )
        if success:
            logger.info("ICPSR script collection completed successfully")
        else:
            logger.error("ICPSR script collection failed")
        return success
    except Exception as e:
        logger.error(f"ICPSR script collection error: {e}")
        return False


def main():
    """Main entry point for script collection CLI."""
    parser = argparse.ArgumentParser(
        description="Collect script files from multiple sources",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Source selection
    parser.add_argument(
        "--source",
        choices=["dataverse", "zenodo", "icpsr", "all"],
        default="all",
        help="Source to collect scripts from",
    )

    # General options
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument(
        "--base-output-dir",
        type=str,
        help="Base output directory for all script files",
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force refresh all scripts, ignore existing files",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set logging level",
    )
    parser.add_argument(
        "--log-file", type=str, help="Log file path (default from config)"
    )

    # Dataverse-specific options
    dataverse_group = parser.add_argument_group("Dataverse options")
    dataverse_group.add_argument(
        "--datasets-dir",
        type=str,
        help="Directory with Dataverse dataset CSV files",
    )
    dataverse_group.add_argument(
        "--workers", type=int, help="Number of parallel workers for downloads"
    )

    # Zenodo-specific options
    zenodo_group = parser.add_argument_group("Zenodo options")
    zenodo_group.add_argument(
        "--zenodo-communities",
        nargs="+",
        help="Zenodo communities to search",
    )
    zenodo_group.add_argument(
        "--max-zenodo-records",
        type=int,
        help="Maximum number of Zenodo records to process",
    )

    # ICPSR-specific options
    icpsr_group = parser.add_argument_group("ICPSR options")
    icpsr_group.add_argument(
        "--icpsr-query", type=str, default="", help="ICPSR search query"
    )
    icpsr_group.add_argument(
        "--max-icpsr-studies",
        type=int,
        help="Maximum number of ICPSR studies to process",
    )

    args = parser.parse_args()

    # Setup logging
    logger = setup_logging(level=args.log_level, log_file=args.log_file)

    # Determine output directories
    base_output = args.base_output_dir or "scripts"
    dataverse_output = f"{base_output}/dataverse"
    zenodo_output = f"{base_output}/zenodo"
    icpsr_output = f"{base_output}/icpsr"

    # Track overall success
    results = {}

    try:
        logger.info(f"Starting script collection from source: {args.source}")

        # Collect from specified sources
        if args.source in ["dataverse", "all"]:
            logger.info("=" * 50)
            logger.info("COLLECTING FROM DATAVERSE")
            logger.info("=" * 50)
            results["dataverse"] = collect_dataverse_scripts(
                config=args.config,
                datasets_dir=args.datasets_dir,
                output_dir=dataverse_output,
                force_refresh=args.force_refresh,
                num_workers=args.workers,
            )

        if args.source in ["zenodo", "all"]:
            logger.info("=" * 50)
            logger.info("COLLECTING FROM ZENODO")
            logger.info("=" * 50)
            results["zenodo"] = collect_zenodo_scripts(
                config=args.config,
                output_dir=zenodo_output,
                communities=args.zenodo_communities,
                max_records=args.max_zenodo_records,
                force_refresh=args.force_refresh,
            )

        if args.source in ["icpsr", "all"]:
            logger.info("=" * 50)
            logger.info("COLLECTING FROM ICPSR")
            logger.info("=" * 50)
            results["icpsr"] = collect_icpsr_scripts(
                config=args.config,
                output_dir=icpsr_output,
                search_query=args.icpsr_query,
                max_studies=args.max_icpsr_studies,
                force_refresh=args.force_refresh,
            )

        # Report results
        logger.info("=" * 50)
        logger.info("COLLECTION SUMMARY")
        logger.info("=" * 50)

        total_success = 0
        total_attempted = 0

        for source, success in results.items():
            status = "✓ SUCCESS" if success else "✗ FAILED"
            logger.info(f"{source.upper()}: {status}")
            if success:
                total_success += 1
            total_attempted += 1

        if total_attempted == 0:
            logger.error("No sources were processed")
            return 1

        logger.info(f"Overall: {total_success}/{total_attempted} sources successful")

        if total_success == total_attempted:
            logger.info("All script collection completed successfully")
            return 0
        elif total_success > 0:
            logger.warning("Script collection partially successful")
            return 2  # Partial success exit code
        else:
            logger.error("All script collection failed")
            return 1

    except KeyboardInterrupt:
        logger.info("Script collection interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error during script collection: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
