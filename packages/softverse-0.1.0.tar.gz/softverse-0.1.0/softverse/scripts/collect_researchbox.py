"""Script to collect data from ResearchBox."""

import sys
from pathlib import Path

import click

from softverse.collectors.researchbox_collector import ResearchBoxCollector
from softverse.config import get_config
from softverse.utils.logging_utils import get_logger

logger = get_logger(__name__)


@click.command()
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory for collected data",
)
@click.option(
    "--box-ids",
    "-b",
    multiple=True,
    type=int,
    help="Specific ResearchBox IDs to collect (can be specified multiple times)",
)
@click.option(
    "--box-ids-file",
    "-f",
    type=click.Path(exists=True, path_type=Path),
    help="File containing ResearchBox IDs (one per line)",
)
@click.option(
    "--start-id",
    "-s",
    type=int,
    default=None,
    help="Starting ResearchBox ID for range collection",
)
@click.option(
    "--end-id",
    "-e",
    type=int,
    default=None,
    help="Ending ResearchBox ID for range collection",
)
@click.option(
    "--discover/--no-discover",
    default=True,
    help="Discover available IDs in range before downloading",
)
@click.option(
    "--extract/--no-extract",
    default=True,
    help="Extract ZIP files after downloading",
)
@click.option(
    "--keep-zip/--no-keep-zip",
    default=False,
    help="Keep ZIP files after extraction",
)
@click.option(
    "--rate-limit",
    type=float,
    default=1.0,
    help="Delay between requests in seconds",
)
@click.option(
    "--max-retries",
    type=int,
    default=3,
    help="Maximum retries for failed requests",
)
@click.option(
    "--max-boxes",
    type=int,
    default=None,
    help="Maximum number of boxes to collect",
)
def main(
    output_dir: Path | None,
    box_ids: tuple,
    box_ids_file: Path | None,
    start_id: int | None,
    end_id: int | None,
    discover: bool,
    extract: bool,
    keep_zip: bool,
    rate_limit: float,
    max_retries: int,
    max_boxes: int | None,
) -> None:
    """Collect data from ResearchBox repositories.

    Examples:
        # Collect specific ResearchBox IDs
        collect-researchbox --box-ids 1 --box-ids 15 --box-ids 17

        # Collect from a file of IDs
        collect-researchbox --box-ids-file researchbox_ids.txt

        # Collect a range of IDs with discovery
        collect-researchbox --start-id 1 --end-id 100

        # Collect range without discovery (faster but may have many 404s)
        collect-researchbox --start-id 1 --end-id 100 --no-discover

        # Collect with custom settings
        collect-researchbox --box-ids 15 --no-extract --keep-zip
    """
    # Load configuration
    config = get_config()

    # Set output directory
    if output_dir is None:
        output_dir = Path(config.get("data_sources.researchbox.output_dir", "outputs/researchbox"))

    # Initialize collector
    collector = ResearchBoxCollector(
        rate_limit_delay=rate_limit,
        max_retries=max_retries
    )

    # Collect box IDs from various sources
    all_box_ids: list[int] = []

    # From command line
    if box_ids:
        all_box_ids.extend(box_ids)
        logger.info(f"Added {len(box_ids)} box IDs from command line")

    # From file
    if box_ids_file:
        with open(box_ids_file) as f:
            file_ids = [int(line.strip()) for line in f if line.strip().isdigit()]
            all_box_ids.extend(file_ids)
            logger.info(f"Added {len(file_ids)} box IDs from file")

    # From range
    if start_id is not None and end_id is not None:
        if start_id > end_id:
            logger.error("Start ID must be less than or equal to end ID")
            sys.exit(1)

        logger.info(f"Collecting ResearchBox range: {start_id} to {end_id}")

        # Apply max_boxes limit to range
        actual_end_id = end_id
        if max_boxes:
            actual_end_id = min(end_id, start_id + max_boxes - 1)
            if actual_end_id < end_id:
                logger.info(f"Limited range to {start_id}-{actual_end_id} due to max_boxes limit")

        stats = collector.collect_range(
            start_id,
            actual_end_id,
            output_dir,
            discover_first=discover,
            extract=extract,
            keep_zip=keep_zip
        )
        _print_stats(stats)
        return

    # If no specific collection method, use default range
    if not all_box_ids:
        default_start = config.get("data_sources.researchbox.default_start_id", 1)
        default_end = config.get("data_sources.researchbox.default_end_id", 100)

        # Apply max_boxes limit
        if max_boxes:
            default_end = min(default_end, default_start + max_boxes - 1)

        logger.warning(f"No specific boxes requested. Using default range: {default_start}-{default_end}")

        stats = collector.collect_range(
            default_start,
            default_end,
            output_dir,
            discover_first=discover,
            extract=extract,
            keep_zip=keep_zip
        )
        _print_stats(stats)
        return

    # Remove duplicates while preserving order
    unique_box_ids = list(dict.fromkeys(all_box_ids))

    # Apply max_boxes limit
    if max_boxes and len(unique_box_ids) > max_boxes:
        unique_box_ids = unique_box_ids[:max_boxes]
        logger.info(f"Limited to first {max_boxes} boxes due to max_boxes limit")

    if not unique_box_ids:
        logger.error("No ResearchBox IDs to collect!")
        sys.exit(1)

    logger.info(f"Collecting {len(unique_box_ids)} unique ResearchBoxes...")

    # Collect the boxes
    stats = collector.collect_researchboxes(
        unique_box_ids,
        output_dir,
        extract=extract,
        keep_zip=keep_zip
    )

    # Print statistics
    _print_stats(stats)


def _print_stats(stats: dict) -> None:
    """Print collection statistics.

    Args:
        stats: Statistics dictionary
    """
    logger.info("=" * 50)
    logger.info("ResearchBox Collection Statistics:")
    logger.info(f"  Total requested: {stats.get('total_requested', 0)}")
    logger.info(f"  Successful downloads: {stats.get('successful_downloads', 0)}")
    logger.info(f"  Successful extractions: {stats.get('successful_extractions', 0)}")
    logger.info(f"  Total files: {stats.get('total_files', 0)}")
    logger.info(f"  Total script files: {stats.get('total_scripts', 0)}")

    errors = stats.get("errors", [])
    if errors:
        logger.warning(f"  Errors encountered: {len(errors)}")
        for error in errors[:5]:  # Show first 5 errors
            logger.warning(f"    - Box {error['box_id']}: {error['error']}")
        if len(errors) > 5:
            logger.warning(f"    ... and {len(errors) - 5} more errors")
    else:
        logger.info("  No errors encountered")

    # Success rate
    total_requested = stats.get('total_requested', 0)
    if total_requested > 0:
        success_rate = (stats.get('successful_downloads', 0) / total_requested) * 100
        logger.info(f"  Success rate: {success_rate:.1f}%")

    logger.info("=" * 50)


if __name__ == "__main__":
    main()
