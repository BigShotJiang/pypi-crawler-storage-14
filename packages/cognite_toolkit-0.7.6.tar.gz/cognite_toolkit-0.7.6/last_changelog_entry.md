## Changelog 

### Fixed

- Transformations with destination `instances` and `instanceSpace` not
explicitly set to `null` are no longer redeployed when they are
unchanged. The same is if `query` or `conflictMode` are not set.