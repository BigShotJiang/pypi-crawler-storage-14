# _*_ coding: utf-8 _*_
#
# hspylib-firebase v0.9.156
#
# Package: main.firebase.exception
"""Package initialization."""

__all__ = [
    'exceptions'
]
__version__ = '0.9.156'
