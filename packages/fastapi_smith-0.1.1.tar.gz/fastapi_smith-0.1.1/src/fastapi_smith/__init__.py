"""FastAPI Smith - Interactive FastAPI Project Scaffolder"""

__version__ = "0.1.1"
