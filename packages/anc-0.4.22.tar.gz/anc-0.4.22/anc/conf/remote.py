remote_server = "http://dataloader-service.infra.svc.cluster.local:5000"
remote_storage_prefix = "/mnt/"
repo_url = "https://github.com/a7n-global/dataset-registry.git"