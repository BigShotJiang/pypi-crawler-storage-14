# 超簡単な並列処理 [forkx]
# 【動作確認 / 使用例】

import sys
import time
import ezpip
forkx = ezpip.load_develop("forkx", "../", develop_flag = True)

# 簡単な使い方

def proc_a():
	time.sleep(1)
	return 2**2

def proc_b():
	time.sleep(1)
	return 3**3

# proc_a, proc_b が並列で実行される
results = forkx(proc_a, proc_b)
print(results)	# -> [4, 27]

# より複雑な使い方

# 並列でアクセスされる対象
common = {"cnt": 0}
lock = forkx.Lock()	# アクセスロックオブジェクトの作成

def cnt_up():
	time.sleep(1)
	# ロックによって競合編集を避ける
	with lock:
		common["cnt"] += 1

# 当然同一の関数も並列で実行できる
forkx(*[cnt_up for _ in range(10)])
print(common)

# 引数ありの場合
def gen_func(i): return lambda : i**2
funcs = [gen_func(i) for i in range(5)]
print(forkx(*funcs))	# -> [0,1,4,9,16]
