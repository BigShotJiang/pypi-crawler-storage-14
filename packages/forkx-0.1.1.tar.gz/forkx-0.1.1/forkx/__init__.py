# 超簡単な並列処理 [forkx]

import sys
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

# forkxのクラス
class ForkX:
	# 初期化処理
	def __init__(self): pass
	# 並行処理実行
	def __call__(self, *func_list):
		with ThreadPoolExecutor() as ex:
			# 結果遅延取得objのリストを作成
			res_promises = [
				ex.submit(func)
				for func in func_list
			]
		# 結果を待って返す
		return [e.result() for e in res_promises]
	# ロックオブジェクトの生成
	def Lock(self): return Lock()

# ForkX型のオブジェクトをモジュールオブジェクトと同一視
sys.modules[__name__] = ForkX()
