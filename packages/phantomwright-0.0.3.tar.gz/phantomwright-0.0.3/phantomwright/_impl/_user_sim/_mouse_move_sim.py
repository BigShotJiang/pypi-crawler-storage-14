import random
import logging
import asyncio

logger = logging.getLogger(__name__)

async def async_mouse_move(page):
    try:
        await asyncio.sleep(random.uniform(0.5, 1.5))
        viewport = page.viewport_size
        if not viewport:
            return
        width, height = viewport['width'], viewport['height']
        for _ in range(random.randint(3, 7)):
            x = random.randint(100, width - 100)
            y = random.randint(100, height - 100)
            await page.mouse.move(x, y)
            await asyncio.sleep(random.uniform(0.1, 0.3))
    except Exception as e:
        logger.error(f"Error simulating user activity: {e}")

def sync_mouse_move(page):
    try:
        import time
        time.sleep(random.uniform(0.5, 1.5))
        viewport = page.viewport_size
        if not viewport:
            return
        width, height = viewport['width'], viewport['height']
        for _ in range(random.randint(3, 7)):
            x = random.randint(100, width - 100)
            y = random.randint(100, height - 100)
            page.mouse.move(x, y)
            time.sleep(random.uniform(0.1, 0.3))
    except Exception as e:
        logger.error(f"Error simulating user activity: {e}")
