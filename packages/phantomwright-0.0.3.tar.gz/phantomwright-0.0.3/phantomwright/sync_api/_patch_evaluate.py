from functools import wraps
from patchright.sync_api import Page

_original_evaluate = Page.evaluate


@wraps(_original_evaluate)
def _hooked_evaluate(self, *args, **kwargs):
    # Ensure isolated_context defaults to False if not provided
    kwargs.setdefault("isolated_context", False)
    return _original_evaluate(self, *args, **kwargs)


Page.evaluate = _hooked_evaluate

_original_evaluate_handle = Page.evaluate_handle


@wraps(_original_evaluate_handle)
def _hooked_evaluate_handle(self, *args, **kwargs):
    # Ensure isolated_context defaults to False if not provided
    kwargs.setdefault("isolated_context", False)
    return _original_evaluate_handle(self, *args, **kwargs)


Page.evaluate_handle = _hooked_evaluate_handle
