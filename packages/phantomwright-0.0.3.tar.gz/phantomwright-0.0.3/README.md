## Introduction

Phantomwright is a library combining [patchright](https://pypi.org/project/patchright/) and [playwright-stealth](https://pypi.org/project/playwright-stealth/), we aim to:
 + Wrap & Re-export API from patchright, provide basic stealth ability
 + Provide the ability to extend playwright, thus you can use API to:
    + Enable stealth injection script
    + Do user simulation
+ (TODO) Setup the ability to add breakpoint into playwright-core and playwright-python
+ (TODO) More extending API support for recaptcha resolver, proxy management etc.

### Initialization & Unit Test

```shell
    uv venv
    .venv\Scripts\activate
    uv sync --extra dev
    uv run patchright install-deps
    uv run patchright install
    uv run pytest
```

### Clear VENV Installation

```shell
    uv venv --clear
```

### Thanks

+ [patchright](https://pypi.org/project/patchright/) 
+ [playwright-stealth](https://pypi.org/project/playwright-stealth/)