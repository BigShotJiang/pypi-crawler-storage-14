import argparse
import requests
import json
import os

DEFAULT_SERVER = "http://api.adgit.online"

def cargar_historial():
    if not os.path.exists("adgit_historial.json"):
        return []
    with open("adgit_historial.json", "r") as f:
        return json.load(f)

def subir(server_arg=None, main=False):
    if server_arg:
        server = server_arg
    elif main:
        server = DEFAULT_SERVER
    else:
        print("¿A qué servidor querés subir?")
        print("1) Servidor principal (main)")
        print("2) Escribir URL/IP manual")
        opcion = input("> ")

        if opcion == "1":
            server = DEFAULT_SERVER
        elif opcion == "2":
            server = input("Ingresá la URL o IP del servidor: ")
        else:
            print("Opción inválida")
            return

    commits = cargar_historial()

    try:
        resp = requests.post(f"{server}/subir", json={"commits": commits})
        resp.raise_for_status()
        print("✔ Subida exitosa al servidor:", server)
    except Exception as e:
        print("❌ Error al subir:", e)

def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command")

    subir_cmd = subparsers.add_parser("subir")
    subir_cmd.add_argument("--server")
    subir_cmd.add_argument("--main", action="store_true")

    args = parser.parse_args()

    if args.command == "subir":
        subir(server_arg=args.server, main=args.main)
