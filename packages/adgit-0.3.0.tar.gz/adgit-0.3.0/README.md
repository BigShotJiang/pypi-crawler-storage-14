# ADgit CLI
Cliente oficial para ADgit.