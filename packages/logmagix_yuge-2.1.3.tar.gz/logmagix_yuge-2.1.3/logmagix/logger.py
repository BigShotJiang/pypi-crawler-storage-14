import datetime
import time
from threading import Thread, Event
from itertools import cycle
from colorama import Fore, Style
import os
import sys
import getpass
from .font import *
from pystyle import Write, System, Colors
from enum import Enum
import re
import threading

# Repository info tracking at module level
_repository_info_displayed = False

# Windows ANSI 支持初始化
if os.name == 'nt':
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass  # 如果失败则忽略，依赖 colorama

class LogLevel(Enum):
    DEBUG = 1
    INFO = 2
    WARNING = 3
    SUCCESS = 4
    FAILURE = 5
    CRITICAL = 6

class Logger:
    def __new__(cls, style: int = 1, *args, **kwargs):
        if cls is Logger:
            if style == 2:
                return SimpleLogger(*args, **kwargs)
            return ColorLogger(*args, **kwargs)
        return super().__new__(cls)

    def __init__(self, style: int = 1, prefix: str | None = "yuge666", github_repository: str = None, level: LogLevel = LogLevel.DEBUG, log_file: str | None = None):
        global _repository_info_displayed

        self.level = level
        self.repo_url = github_repository
        self.log_file = log_file
        self.prefix = prefix

        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            self._write_to_log(f"=== Logging started at {datetime.datetime.now()} ===\n")

        from .updater import AutoUpdater
        updater = AutoUpdater("logmagix-yuge", self)
        updater.check_for_updates()

    def _extract_github_username(self, url: str) -> str | None:
        url = url.replace('https://', '').replace('http://', '').replace('www.', '')
        patterns = [
            r'^github\.com/([^/]+)(?:/.*)?$',  # github.com/username or username/repo
            r'^([^/]+)(?:/.*)?$',              # username or username/repo
            r'^@(.+)$'                         # @username
        ]
        for pattern in patterns:
            if match := re.search(pattern, url):
                return match.group(1).rstrip('/ \t\n\r')

        return None

    def _write_to_log(self, message: str) -> None:
        if self.log_file:
            try:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    clean_message = self._strip_ansi(message)
                    f.write(clean_message + '\n')
            except Exception as e:
                print(f"Error writing to log file: {e}")

    def _strip_ansi(self, text: str) -> str:
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    def get_time(self) -> str:
        return datetime.datetime.now().strftime("%H:%M:%S")

    def _should_log(self, message_level: LogLevel) -> bool:
        return message_level.value >= self.level.value

    def display_repo_info(self):
        global _repository_info_displayed

        if self.repo_url and not _repository_info_displayed:
            username = self._extract_github_username(self.repo_url)
            if username:
                self.info(f"Developed by {username} - {self.repo_url}")
            else:
                self.info(f"GitHub Repository: {self.repo_url}")
            _repository_info_displayed = True

class ColorLogger(Logger):
    def __init__(self, *args, **kwargs):
        self.WHITE = "\u001b[37m"
        self.MAGENTA = "\033[38;5;97m"
        self.BRIGHT_MAGENTA = "\033[38;2;157;38;255m"
        self.LIGHT_CORAL = "\033[38;5;210m"
        self.RED = "\033[38;5;196m"
        self.GREEN = "\033[38;5;40m"
        self.YELLOW = "\033[38;5;220m"
        self.BLUE = "\033[38;5;21m"
        self.PINK = "\033[38;5;176m"
        self.CYAN = "\033[96m"
        super().__init__(*args, **kwargs)
        self.prefix = f"{self.PINK}[{self.MAGENTA}{self.prefix}{self.PINK}] " if self.prefix else f"{self.PINK}"

        # Display repo info after initializing colors
        self.display_repo_info()

    def message3(self, level: str, message: str, start: int = None, end: int = None) -> str:
        current_time = self.get_time()
        return f"{self.prefix}[{self.BRIGHT_MAGENTA}{current_time}{self.PINK}] {self.PINK}[{self.CYAN}{level}{self.PINK}] -> {self.CYAN}{message}{Fore.RESET}"

    def success(self, message: str, start: int = None, end: int = None, level: str = "Success") -> None:
        if self._should_log(LogLevel.SUCCESS):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.GREEN}{level}", f"{self.GREEN}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)

    def failure(self, message: str, start: int = None, end: int = None, level: str = "Failure") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.RED}{level}", f"{self.RED}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)

    def error(self, message: str, start: int = None, end: int = None, level: str = "Error") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.RED}{level}", f"{self.RED}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)

    def warning(self, message: str, start: int = None, end: int = None, level: str = "Warning") -> None:
        if self._should_log(LogLevel.WARNING):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.YELLOW}{level}", f"{self.YELLOW}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)

    def message(self, level: str, message: str, start: int = None, end: int = None) -> None:
        timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
        log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}] [{self.CYAN}{level}{self.PINK}] -> [{self.CYAN}{message}{self.PINK}]{timer}"
        print(log_message)
        self._write_to_log(log_message)

    def message2(self, level: str, message: str, start: int = None, end: int = None) -> None:
        if start and end:
            print(f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}] {self.PINK}[{self.CYAN}{level}{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET} [{Fore.CYAN}{end - start}s{Style.RESET_ALL}]", end="\r")
        else:
            print(f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}] {self.PINK}[{Fore.BLUE}{level}{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET}", end="\r")

    def question(self, message: str, start: int = None, end: int = None) -> None:
        question_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{Fore.BLUE}?{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET}"
        print(question_message, end='')
        i = input()
        self._write_to_log(f"{question_message}")
        self._write_to_log(f"User Answer: {i}")

        return i

    def critical(self, message: str, start: int = None, end: int = None, level: str = "CRITICAL", exit_code: int = 1) -> None:
        if self._should_log(LogLevel.CRITICAL):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{self.RED}{level}{self.PINK}] -> {self.LIGHT_CORAL}{message}{Fore.RESET}" + timer
            print(log_message)
            input()
            self._write_to_log(log_message)
            self._write_to_log(f"=== Program terminated with exit code {exit_code} at {datetime.datetime.now()} ===")
            exit(exit_code)

    def info(self, message: str, start: int = None, end: int = None) -> None:
        if self._should_log(LogLevel.INFO):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{Fore.BLUE}!{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET}" + timer
            print(log_message)
            self._write_to_log(log_message)

    def debug(self, message: str, start: int = None, end: int = None) -> None:
        if self._should_log(LogLevel.DEBUG):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{Fore.YELLOW}DEBUG{self.PINK}] -> {Fore.RESET} {self.GREEN}{message}{Fore.RESET}" + timer
            print(log_message)
            self._write_to_log(log_message)

class SimpleLogger(Logger):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = f"{Fore.BLACK}{self.get_time()} » {Fore.RESET}"

        # Display repo info after initializing prefix
        self.display_repo_info()

    def success(self, message: str, start: int = None, end: int = None, level: str = "SUCCESS") -> None:
        if self._should_log(LogLevel.SUCCESS):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTGREEN_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def failure(self, message: str, start: int = None, end: int = None, level: str = "FAILURE") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTRED_EX}{level} {Fore.BLACK}  ➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def error(self, message: str, start: int = None, end: int = None, level: str = "ERROR") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTRED_EX}{level} {Fore.BLACK}  ➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def warning(self, message: str, start: int = None, end: int = None, level: str = "WARNING") -> None:
        if self._should_log(LogLevel.WARNING):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTYELLOW_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def message(self, message: str, start: int = None, end: int = None, level: str = "MESSAGE") -> None:
        if self._should_log(LogLevel.WARNING):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTMAGENTA_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def info(self, message: str, start: int = None, end: int = None, level: str = "INFO") -> None:
        if self._should_log(LogLevel.INFO):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTBLUE_EX}{level} {Fore.BLACK}   ➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def debug(self, message: str, start: int = None, end: int = None) -> None:
        if self._should_log(LogLevel.DEBUG):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.GREEN}[{Fore.YELLOW}DEBUG{Fore.GREEN}] {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def question(self, message: str, level: str = "QUESTION") -> None:
        question_message = f"{self.prefix}{Fore.LIGHTCYAN_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}"
        print(question_message, end='')
        i = input()
        self._write_to_log(f"{question_message}")
        self._write_to_log(f"User Answer: {i}")
        return i

log = Logger()


# ============================================================
# 多行模式支持 - Multi-line Loader Support (已优化)
# ============================================================

class CursorControl:
    """ANSI 转义序列光标控制工具"""

    @staticmethod
    def move_to(line, column=0):
        """移动光标到指定位置"""
        return f"\033[{line};{column}H"

    @staticmethod
    def move_up(n=1):
        """光标上移 n 行"""
        return f"\033[{n}A"

    @staticmethod
    def move_down(n=1):
        """光标下移 n 行"""
        return f"\033[{n}B"

    @staticmethod
    def save_position():
        """保存光标位置"""
        return "\033[s"

    @staticmethod
    def restore_position():
        """恢复光标位置"""
        return "\033[u"

    @staticmethod
    def clear_line():
        """清除当前行"""
        return "\033[2K"

    @staticmethod
    def hide_cursor():
        """隐藏光标"""
        return "\033[?25l"

    @staticmethod
    def show_cursor():
        """显示光标"""
        return "\033[?25h"

    @staticmethod
    def clear_from_cursor():
        """清除从光标到行尾的内容"""
        return "\033[K"


class LoaderManager:
    """
    多 Loader 管理器 - 负责统一渲染所有 Loader

    优化版本 - 修复了多线程并发问题:
    1. 修复渲染线程过早退出导致后续 Loader 不显示
    2. 添加自动清理机制，清除已停止的 Loader
    3. 添加渲染线程重启机制
    4. 改进线程安全性
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        """单例模式"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """初始化管理器"""
        if hasattr(self, '_initialized'):
            return

        self._initialized = True
        self.loaders = []
        self.print_lock = threading.Lock()
        self.running = False
        self.render_thread = None
        self.stop_event = Event()

        # 清理相关
        self.cleanup_delay = 2.0  # 停止后延迟清理时间(秒)
        self.last_cleanup = time.time()

    def register(self, loader):
        """
        注册一个 Loader

        优化: 如果渲染线程已停止，会自动重启
        """
        with self.print_lock:
            if loader not in self.loaders:
                self.loaders.append(loader)
                loader.line_index = len(self.loaders) - 1
                loader.stop_time = None

                # 优化: 如果是第一个 Loader 或渲染线程已停止，则启动/重启
                if len(self.loaders) == 1 or not self.running:
                    self.start()
                else:
                    self._reserve_line()

    def unregister(self, loader):
        """
        注销一个 Loader

        优化: 重新分配所有 Loader 的 line_index
        """
        with self.print_lock:
            if loader in self.loaders:
                self.loaders.remove(loader)
                # 重新分配索引
                for idx, ldr in enumerate(self.loaders):
                    ldr.line_index = idx

    def _reserve_line(self):
        """预留一行空白（使用 sys.stdout 统一输出）"""
        sys.stdout.write('\n')
        sys.stdout.flush()

    def start(self):
        """
        启动渲染线程

        优化: 重置 stop_event，确保可以重复启动
        """
        if not self.running:
            self.running = True
            self.stop_event.clear()

            # 隐藏光标
            sys.stdout.write(CursorControl.hide_cursor())
            sys.stdout.flush()

            # 为第一个 Loader 预留行
            self._reserve_line()

            # 启动渲染线程
            self.render_thread = threading.Thread(target=self._render_loop, daemon=True)
            self.render_thread.start()

    def stop(self):
        """
        停止渲染线程

        优化: 使用 Event 来优雅地停止线程
        """
        if self.running:
            self.running = False
            self.stop_event.set()

            if self.render_thread and self.render_thread.is_alive():
                self.render_thread.join(timeout=2)

            # 显示光标
            sys.stdout.write(CursorControl.show_cursor())
            sys.stdout.write('\n')
            sys.stdout.flush()

    def _cleanup_stopped_loaders(self):
        """
        清理已停止超过指定时间的 Loader

        优化: 自动清理机制，避免 Loader 累积
        """
        current_time = time.time()

        # 每隔一段时间执行一次清理
        if current_time - self.last_cleanup < 0.5:
            return

        self.last_cleanup = current_time

        with self.print_lock:
            to_remove = []
            for loader in self.loaders:
                if loader.stopped and loader.stop_time:
                    if current_time - loader.stop_time > self.cleanup_delay:
                        to_remove.append(loader)

            for loader in to_remove:
                self.loaders.remove(loader)

            # 重新分配索引
            if to_remove:
                for idx, ldr in enumerate(self.loaders):
                    ldr.line_index = idx

    def _render_loop(self):
        """
        主渲染循环

        优化:
        1. 改为只有当 loaders 为空时才退出，而不是所有都停止时退出
        2. 添加自动清理机制
        3. 使用 Event 来优雅停止
        """
        while self.running and not self.stop_event.is_set():
            # 清理已停止的 Loader
            self._cleanup_stopped_loaders()

            # 渲染所有 Loader
            self._render_all()

            # 检查是否应该退出
            with self.print_lock:
                has_loaders = len(self.loaders) > 0

            # 优化: 只有当没有任何 Loader 时才退出
            if not has_loaders:
                # 给一点时间让新 Loader 注册
                for _ in range(10):
                    time.sleep(0.1)
                    with self.print_lock:
                        if len(self.loaders) > 0:
                            break
                else:
                    # 确实没有 Loader 了，退出
                    self.running = False
                    break

            # 渲染间隔
            time.sleep(0.05)

        # 清理
        with self.print_lock:
            sys.stdout.write(CursorControl.show_cursor())
            sys.stdout.write('\n')
            sys.stdout.flush()

    def _render_all(self):
        """
        渲染所有 Loader

        优化: 使用更可靠的光标控制
        """
        with self.print_lock:
            if not self.loaders:
                return

            num_loaders = len(self.loaders)

            # 上移到第一个 Loader 的位置
            sys.stdout.write(CursorControl.move_up(num_loaders))

            # 渲染每个 Loader
            for idx, loader in enumerate(self.loaders):
                # 清除当前行
                sys.stdout.write(CursorControl.clear_line())
                # 输出 Loader 内容
                sys.stdout.write("\r" + loader.get_display_text())

                # 如果不是最后一个，下移一行
                if idx < num_loaders - 1:
                    sys.stdout.write(CursorControl.move_down(1))

            # 最后下移一行，保持光标在最下方
            sys.stdout.write(CursorControl.move_down(1))
            sys.stdout.flush()


# 全局管理器实例
_global_manager = LoaderManager()

# ============================================================
# 优化后的 Loader 类
# ============================================================

class Loader:
    def __init__(self, prefix: str = "yuge666", desc="Loading...", end="\r", timeout=0.1, multiline: bool = False):
        """
        初始化 Loader

        Args:
            prefix: 前缀（任务名称）
            desc: 描述文本
            end: 结束时的提示文本
            timeout: 动画间隔（仅单行模式使用）
            multiline: 是否使用多行模式（True=多行，False=单行，默认False保持向下兼容）
        """
        self._desc = desc
        self.end = end
        self.prefix = prefix
        self.timeout = timeout
        self.multiline = multiline
        self.time = None
        self.start_time = datetime.datetime.now()

        # 动画相关
        self.steps = ["⢿", "⣻", "⣽", "⣾", "⣷", "⣯", "⣟", "⡿"]
        self.spinner_index = 0

        # 多行模式相关
        self.line_index = None
        self.manager = None
        self.stopped = False
        self.stop_time = None  # 优化: 记录停止时间

        # 单行模式相关
        self._thread = Thread(target=self._animate, daemon=True)
        self.done = False

    @property
    def desc(self):
        """获取描述"""
        return self._desc

    @desc.setter
    def desc(self, value):
        """设置描述（支持动态更新）"""
        self._desc = value

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()

    def start(self):
        """启动 Loader"""
        if self.multiline:
            # 多行模式：注册到 Manager
            self.manager = _global_manager
            self.manager.register(self)
        else:
            # 单行模式：启动独立线程（原版逻辑）
            self._thread.start()
        return self

    def _animate(self):
        """单行模式动画（原版逻辑）"""
        for c in cycle(self.steps):
            if self.done:
                break
            current_time = datetime.datetime.now().strftime("%H:%M:%S")
            loader_message = f"\r{log.PINK}[{log.MAGENTA}{self.prefix}{log.PINK}] [{log.BRIGHT_MAGENTA}{current_time}{log.PINK}] [{log.GREEN}{self._desc}{log.PINK}]{Fore.RESET} {c}"
            print(loader_message, flush=True, end="")
            time.sleep(self.timeout)

    def stop(self):
        """
        停止 Loader

        优化: 记录停止时间，用于自动清理
        """
        if self.multiline:
            # 多行模式：标记为已停止
            self.stopped = True
            self.stop_time = time.time()  # 优化: 记录停止时间
            if self.end:
                self._desc = self.end
        else:
            # 单行模式：停止线程（原版逻辑）
            self.done = True
            if (self.end != "\r"):
                current_time = datetime.datetime.now().strftime("%H:%M:%S")
                end_message = f"\n{log.PINK}[{log.MAGENTA}{self.prefix}{log.PINK}] [{log.BRIGHT_MAGENTA}{current_time}{log.PINK}] {log.GREEN} {self.end} {Fore.RESET}"
                print(end_message, flush=True)
            else:
                print(self.end, flush=True)

    def get_display_text(self):
        """获取要显示的文本（供 Manager 调用，仅多行模式使用）"""
        current_time = datetime.datetime.now().strftime("%H:%M:%S")

        # 如果已停止，显示固定的完成标记，不再旋转
        if self.stopped:
            return f"{log.PINK}[{log.MAGENTA}{self.prefix}{log.PINK}] [{log.BRIGHT_MAGENTA}{current_time}{log.PINK}] [{log.GREEN}{self._desc}{log.PINK}]{Fore.RESET} ✓"

        # 正常显示旋转的 spinner
        spinner = self.steps[self.spinner_index % len(self.steps)]
        self.spinner_index += 1

        return f"{log.PINK}[{log.MAGENTA}{self.prefix}{log.PINK}] [{log.BRIGHT_MAGENTA}{current_time}{log.PINK}] [{log.GREEN}{self._desc}{log.PINK}]{Fore.RESET} {spinner}"

class Home:
    def __init__(self, text, align="left", adinfo1=None, adinfo2=None, credits=None, clear=True):
        self.text = text
        self.align = align
        self.adinfo1 = adinfo1
        self.adinfo2 = adinfo2
        self.credits = credits
        self.clear = clear
        self.username = getpass.getuser()

    def _get_char_art(self):
        char_arts = []
        max_height = 8

        for char in self.text:
            char_art = ascii_art.get(char, [" " * 8] * 8)

            if char.islower() and len(char_art) == 6:
                char_art = [" " * 8] * 1 + char_art

            char_arts.append(char_art)

        return char_arts, max_height

    def _align_text(self, lines, terminal_width, alignment, block_width):
        aligned_result = []
        for line in lines:
            stripped_line = line.rstrip()
            if alignment == "center":
                padding = max(0, (terminal_width - block_width) // 2)
                aligned_line = " " * padding + stripped_line
            elif alignment == "right":
                padding = max(0, terminal_width - block_width)
                aligned_line = " " * padding + stripped_line
            else:
                aligned_line = stripped_line
            aligned_result.append(aligned_line)
        return aligned_result

    def _clear(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def display(self):
        char_arts, max_height = self._get_char_art()
        result = [""] * max_height

        for i in range(max_height):
            line = "".join([char_art[i] if i < len(char_art) else " " * 8 for char_art in char_arts])
            result[i] = line

        max_line_width = max(len(line) for line in result)

        try:
            terminal_width = os.get_terminal_size().columns
        except OSError:
            terminal_width = 80

        aligned_result = self._align_text(result, terminal_width, self.align, max_line_width)
        if self.clear:
            self._clear()

        for line in aligned_result:
            Write.Print(line + "\n", Colors.red_to_blue, interval=0.000)

        self._display_adinfo(aligned_result, terminal_width)
        self._display_welcome(terminal_width, max_line_width)

    def _display_adinfo(self, aligned_result, terminal_width):
        if not (self.adinfo1 or self.adinfo2):
            return

        ascii_art_width = max(len(line.rstrip()) for line in aligned_result)
        adinfo_text = self._construct_adinfo_text(ascii_art_width)
        adinfo_block_width = len(adinfo_text)
        aligned_adinfo = self._align_text([adinfo_text], terminal_width, self.align, adinfo_block_width)

        for line in aligned_adinfo:
            Write.Print(line + "\n", Colors.red_to_blue, interval=0.000)

    def _construct_adinfo_text(self, ascii_art_width):
        if self.adinfo1 and self.adinfo2:
            total_adinfo_length = len(self.adinfo1) + len(self.adinfo2)
            remaining_space = ascii_art_width - total_adinfo_length
            if (remaining_space > 0):
                padding_between = '  ' * (remaining_space // 3)
                return self.adinfo1 + padding_between + self.adinfo2
            else:
                return self.adinfo1 + '   ' + self.adinfo2
        return self.adinfo1 or self.adinfo2 or ''

    def _display_welcome(self, terminal_width, block_width):
        welcome_message = f"Welcome {self.username}"
        if self.credits:
            welcome_message += f" | {self.credits}"

        welcome_message_with_tildes = f"    {welcome_message}    "
        tilde_line = "~" * len(welcome_message_with_tildes)

        welcome_padding = max(0, (terminal_width - len(welcome_message_with_tildes)) // 2)
        tilde_padding = max(0, (terminal_width - len(tilde_line)) // 2)

        welcome_line = " " * welcome_padding + welcome_message_with_tildes
        tilde_line_aligned = " " * tilde_padding + tilde_line

        Write.Print(f"{welcome_line}\n", Colors.red_to_blue, interval=0.000)
        Write.Print(f"{tilde_line_aligned}\n", Colors.red_to_blue, interval=0.000)

        equals_line = "═" * terminal_width
        Write.Print(f"{equals_line}\n", Colors.red_to_blue, interval=0.000)
