"""Tests for georaffer package."""
