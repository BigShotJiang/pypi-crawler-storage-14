﻿import torch
import torch.nn as nn
from typing import Dict

class Reversible(nn.Module):
    """AUREON: Universal Reversible Learning Framework
    
    Physics-based unlearning with k-drift constant (0.60)
    Charge → Discharge → Recharge protocol
    """
    
    K_CHARGE = 0.56
    K_DISCHARGE = 0.337
    K_RECHARGE = 0.57
    
    def __init__(self, model, optimizer=None, device='cuda', use_holonomy=True):
        super().__init__()
        self.model = model.to(device)
        self.device = device
        self.optimizer = optimizer or torch.optim.AdamW(model.parameters(), lr=1e-4)
        self.criterion = nn.CrossEntropyLoss()
        self.k_current = self.K_CHARGE
        self.phase = 'IDLE'
        self.metrics = {'before': {}, 'after': {}, 'recovery_ratio': 0.0}
        print(f'✓ Reversible initialized\n  k_charge={self.K_CHARGE}\n  k_discharge={self.K_DISCHARGE}\n  k_recharge={self.K_RECHARGE}')
    
    def charge(self, dataloader, num_epochs=1, verbose=True):
        """CHARGE PHASE: Standard training (minimize loss)"""
        print(f'\n🔋 CHARGE PHASE')
        self.phase = 'CHARGE'
        self.model.train()
        total_loss = total_correct = total_samples = 0
        
        for epoch in range(num_epochs):
            for inputs, labels in dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                logits = outputs.logits if hasattr(outputs, 'logits') else outputs
                loss = self.criterion(logits, labels)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                
                total_loss += loss.item()
                pred = logits.argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        
        acc = 100 * total_correct / total_samples
        if verbose: print(f'  Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%')
        self.metrics['before']['acc'] = acc
        return acc
    
    def discharge(self, dataloader, num_epochs=1, verbose=True):
        """DISCHARGE PHASE: Unlearning with k-based gradient reversal
        
        AUREON Physics:
        1. Compute loss normally
        2. Reverse gradients based on k_current
        3. Update weights in loss-MAXIMIZING direction
        """
        print(f'\n⚡ DISCHARGE PHASE (k={self.K_DISCHARGE})')
        self.phase = 'DISCHARGE'
        self.model.train()
        total_loss = total_correct = total_samples = 0
        
        for epoch in range(num_epochs):
            for inputs, labels in dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                logits = outputs.logits if hasattr(outputs, 'logits') else outputs
                loss = self.criterion(logits, labels)
                
                # AUREON: Normal backward
                loss.backward()
                
                # CRITICAL: Gradient reversal using k-physics
                k_current = torch.clamp(torch.tensor(self.K_DISCHARGE, device=self.device), 0.01, 0.99)
                with torch.no_grad():
                    for name, param in self.model.named_parameters():
                        if param.grad is not None and 'k' not in name:
                            # k < 0.5 → reverse gradients (unlearn)
                            reversal_strength = torch.sign(k_current - 0.5).item()
                            param.grad *= reversal_strength
                
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                
                total_loss += loss.item()
                pred = logits.argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        
        acc = 100 * total_correct / total_samples
        if verbose: print(f'  Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%\n  ✓ Unlearning complete')
        self.metrics['after']['acc'] = acc
        return acc
    
    def recharge(self, dataloader, num_epochs=1, verbose=True):
        """RECHARGE PHASE: Recovery training (restore performance)"""
        print(f'\n🔌 RECHARGE PHASE (k={self.K_RECHARGE})')
        self.phase = 'RECHARGE'
        self.model.train()
        total_loss = total_correct = total_samples = 0
        
        for epoch in range(num_epochs):
            for inputs, labels in dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                logits = outputs.logits if hasattr(outputs, 'logits') else outputs
                loss = self.criterion(logits, labels)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                
                total_loss += loss.item()
                pred = logits.argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        
        acc = 100 * total_correct / total_samples
        if verbose: print(f'  Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%\n  ✓ Recharging complete')
        return acc
    
    def verify(self, test_dataloader, verbose=True):
        """VERIFY PHASE: Measure recovery ratio"""
        print(f'\n✅ VERIFICATION PHASE')
        self.model.eval()
        total_correct = total_samples = 0
        
        with torch.no_grad():
            for inputs, labels in test_dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                outputs = self.model(inputs)
                logits = outputs.logits if hasattr(outputs, 'logits') else outputs
                pred = logits.argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        
        test_acc = 100 * total_correct / total_samples
        before_acc = self.metrics['before'].get('acc', 0)
        after_acc = self.metrics['after'].get('acc', 0)
        
        if before_acc > after_acc and before_acc > 0:
            recovery_ratio = (test_acc - after_acc) / (before_acc - after_acc)
        else:
            recovery_ratio = 0.0
        
        if verbose:
            print(f'  Before: {before_acc:.2f}%, After: {after_acc:.2f}%, Test: {test_acc:.2f}%')
            print(f'  Recovery Ratio: {recovery_ratio:.4f}')
        
        self.metrics['recovery_ratio'] = recovery_ratio
        return {
            'before_acc': before_acc,
            'after_acc': after_acc,
            'test_acc': test_acc,
            'recovery_ratio': recovery_ratio
        }
