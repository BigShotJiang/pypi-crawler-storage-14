
from setuptools import setup

setup(
    name="ary-acx",
    version="0.0.1.post1",
    description="Alias package for ACX framework.",
    packages=["ary_acx"],
    install_requires=["acx"],
)
