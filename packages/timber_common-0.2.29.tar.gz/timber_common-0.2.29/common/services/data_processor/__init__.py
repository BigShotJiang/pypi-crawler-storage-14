"""
Data Processor Package

Provides data processing and transformation functions for financial data.

This package is organized into modules:
- standardization: Data cleaning and formatting
- returns: Returns calculations
- risk_metrics: Volatility, drawdown, Sharpe ratio, etc.
- technical_indicators: Moving averages, RSI, Bollinger Bands, etc.
- portfolio_metrics: Beta, correlation, wealth index, etc.

Usage:
    # Option 1: Import specific functions
    from common.services.data_processor import calculate_returns, calculate_sharpe_ratio
    
    # Option 2: Import whole modules
    from common.services.data_processor import risk_metrics, technical_indicators
    
    # Option 3: Use the aggregated data_processor object (backward compatible)
    from common.services.data_processor import data_processor
    df = data_processor.calculate_returns(df)
    
    # Option 4: Use umbrella functions that run multiple calculations
    from common.services.data_processor import calculate_technical_indicators
    df, results = calculate_technical_indicators(df)
    # results contains: {'success': bool, 'columns_added': [...], 'errors': {...}, 'indicators': {...}}
"""

# Import all functions from sub-modules
from .standardization import (
    standardize_dataframe,
    clean_data,
    resample_data
)

from .returns import (
    calculate_returns,
    calculate_cumulative_returns,
    calculate_rolling_returns
)

from .risk_metrics import (
    calculate_volatility,
    calculate_drawdown,
    calculate_sharpe_ratio,
    calculate_sortino_ratio,
    calculate_max_drawdown,
    calculate_var
)

from .technical_indicators import (
    calculate_moving_averages,
    calculate_ema,
    calculate_rsi,
    calculate_macd,
    calculate_bollinger_bands,
    calculate_atr,
    calculate_stochastic
)

from .portfolio_metrics import (
    calculate_wealth_index,
    calculate_correlation,
    calculate_beta,
    calculate_alpha,
    calculate_information_ratio,
    calculate_treynor_ratio
)


# ============================================================================
# Umbrella Functions
# ============================================================================

def calculate_technical_indicators(
    df,
    ma_windows=[20, 50, 200],
    ema_windows=[12, 26],
    rsi_window=14,
    macd_fast=12,
    macd_slow=26,
    macd_signal=9,
    bb_window=20,
    bb_std=2.0,
    atr_window=14,
    stoch_k_window=14,
    stoch_d_window=3,
    price_column='Close'
):
    """
    Umbrella function that calculates all technical indicators at once.
    
    This function runs all technical indicator calculations and returns
    an aggregate structure with all the results and any errors encountered.
    
    Args:
        df: DataFrame with OHLC price data
        ma_windows: List of windows for moving averages (default: [20, 50, 200])
        ema_windows: List of windows for EMAs (default: [12, 26])
        rsi_window: Window for RSI (default: 14)
        macd_fast: Fast window for MACD (default: 12)
        macd_slow: Slow window for MACD (default: 26)
        macd_signal: Signal window for MACD (default: 9)
        bb_window: Window for Bollinger Bands (default: 20)
        bb_std: Number of standard deviations for BB (default: 2.0)
        atr_window: Window for ATR (default: 14)
        stoch_k_window: K window for Stochastic (default: 14)
        stoch_d_window: D window for Stochastic (default: 3)
        price_column: Column to use for price-based calculations (default: 'Close')
    
    Returns:
        Tuple of (DataFrame with all indicators, dict with results and errors)
        
    Example:
        df, results = calculate_technical_indicators(df)
        if results['success']:
            print(f"Added columns: {results['columns_added']}")
        if results['errors']:
            print(f"Errors: {results['errors']}")
    """
    from typing import Optional, Tuple
    import pandas as pd
    
    results = {
        'success': True,
        'columns_added': [],
        'errors': {},
        'indicators': {}
    }
    
    original_columns = set(df.columns)
    
    # Moving Averages
    df, error = calculate_moving_averages(df, windows=ma_windows, price_column=price_column)
    if error:
        results['errors']['moving_averages'] = error
        results['success'] = False
    else:
        results['indicators']['moving_averages'] = {
            'windows': ma_windows,
            'columns': [f'MA_{w}' for w in ma_windows]
        }
    
    # Exponential Moving Averages
    df, error = calculate_ema(df, windows=ema_windows, price_column=price_column)
    if error:
        results['errors']['ema'] = error
        results['success'] = False
    else:
        results['indicators']['ema'] = {
            'windows': ema_windows,
            'columns': [f'EMA_{w}' for w in ema_windows]
        }
    
    # RSI
    df, error = calculate_rsi(df, window=rsi_window, price_column=price_column)
    if error:
        results['errors']['rsi'] = error
        results['success'] = False
    else:
        results['indicators']['rsi'] = {
            'window': rsi_window,
            'column': 'RSI'
        }
    
    # MACD
    df, error = calculate_macd(
        df, 
        fast=macd_fast, 
        slow=macd_slow, 
        signal=macd_signal, 
        price_column=price_column
    )
    if error:
        results['errors']['macd'] = error
        results['success'] = False
    else:
        results['indicators']['macd'] = {
            'fast': macd_fast,
            'slow': macd_slow,
            'signal': macd_signal,
            'columns': ['MACD', 'MACD_Signal', 'MACD_Histogram']
        }
    
    # Bollinger Bands
    df, error = calculate_bollinger_bands(
        df, 
        window=bb_window, 
        num_std=bb_std, 
        price_column=price_column
    )
    if error:
        results['errors']['bollinger_bands'] = error
        results['success'] = False
    else:
        results['indicators']['bollinger_bands'] = {
            'window': bb_window,
            'std': bb_std,
            'columns': ['BB_Middle', 'BB_Upper', 'BB_Lower', 'BB_Width']
        }
    
    # ATR (requires OHLC data)
    df, error = calculate_atr(df, window=atr_window)
    if error:
        results['errors']['atr'] = error
        # ATR failure is not critical if OHLC data is missing
    else:
        results['indicators']['atr'] = {
            'window': atr_window,
            'column': 'ATR'
        }
    
    # Stochastic (requires OHLC data)
    df, error = calculate_stochastic(df, k_window=stoch_k_window, d_window=stoch_d_window)
    if error:
        results['errors']['stochastic'] = error
        # Stochastic failure is not critical if OHLC data is missing
    else:
        results['indicators']['stochastic'] = {
            'k_window': stoch_k_window,
            'd_window': stoch_d_window,
            'columns': ['Stochastic_K', 'Stochastic_D']
        }
    
    # Determine which columns were added
    new_columns = set(df.columns) - original_columns
    results['columns_added'] = sorted(list(new_columns))
    
    return df, results


# ============================================================================
# Aggregated Data Processor Class (for backward compatibility)
# ============================================================================

class DataProcessor:
    """
    Aggregated data processor that provides access to all functions.
    
    This class serves as a convenience wrapper around all the modular functions,
    allowing for object-oriented usage: data_processor.calculate_returns(df)
    """
    
    # Standardization
    @staticmethod
    def standardize_dataframe(df):
        return standardize_dataframe(df)
    
    @staticmethod
    def clean_data(df, method='forward'):
        return clean_data(df, method)
    
    @staticmethod
    def resample_data(df, freq='D', price_column='Close'):
        return resample_data(df, freq, price_column)
    
    # Returns
    @staticmethod
    def calculate_returns(df, price_column='Close', method='simple'):
        return calculate_returns(df, price_column, method)
    
    @staticmethod
    def calculate_cumulative_returns(df, returns_column='Returns'):
        return calculate_cumulative_returns(df, returns_column)
    
    @staticmethod
    def calculate_rolling_returns(df, window=20, returns_column='Returns', annualize=False, trading_days=252):
        return calculate_rolling_returns(df, window, returns_column, annualize, trading_days)
    
    # Risk Metrics
    @staticmethod
    def calculate_volatility(df, window=20, returns_column='Returns', annualize=True, trading_days=252):
        return calculate_volatility(df, window, returns_column, annualize, trading_days)
    
    @staticmethod
    def calculate_drawdown(df, price_column='Close'):
        return calculate_drawdown(df, price_column)
    
    @staticmethod
    def calculate_sharpe_ratio(df, risk_free_rate=0.02, window=252, returns_column='Returns', trading_days=252):
        return calculate_sharpe_ratio(df, risk_free_rate, window, returns_column, trading_days)
    
    @staticmethod
    def calculate_sortino_ratio(df, risk_free_rate=0.02, window=252, returns_column='Returns', trading_days=252):
        return calculate_sortino_ratio(df, risk_free_rate, window, returns_column, trading_days)
    
    @staticmethod
    def calculate_max_drawdown(df, price_column='Close'):
        return calculate_max_drawdown(df, price_column)
    
    @staticmethod
    def calculate_var(df, confidence_level=0.95, returns_column='Returns'):
        return calculate_var(df, confidence_level, returns_column)
    
    # Technical Indicators
    @staticmethod
    def calculate_moving_averages(df, windows=[20, 50, 200], price_column='Close'):
        return calculate_moving_averages(df, windows, price_column)
    
    @staticmethod
    def calculate_ema(df, windows=[12, 26], price_column='Close'):
        return calculate_ema(df, windows, price_column)
    
    @staticmethod
    def calculate_rsi(df, window=14, price_column='Close'):
        return calculate_rsi(df, window, price_column)
    
    @staticmethod
    def calculate_macd(df, fast=12, slow=26, signal=9, price_column='Close'):
        return calculate_macd(df, fast, slow, signal, price_column)
    
    @staticmethod
    def calculate_bollinger_bands(df, window=20, num_std=2.0, price_column='Close'):
        return calculate_bollinger_bands(df, window, num_std, price_column)
    
    @staticmethod
    def calculate_atr(df, window=14):
        return calculate_atr(df, window)
    
    @staticmethod
    def calculate_stochastic(df, k_window=14, d_window=3):
        return calculate_stochastic(df, k_window, d_window)
    
    @staticmethod
    def calculate_technical_indicators(
        df,
        ma_windows=[20, 50, 200],
        ema_windows=[12, 26],
        rsi_window=14,
        macd_fast=12,
        macd_slow=26,
        macd_signal=9,
        bb_window=20,
        bb_std=2.0,
        atr_window=14,
        stoch_k_window=14,
        stoch_d_window=3,
        price_column='Close'
    ):
        """Umbrella function that calculates all technical indicators."""
        return calculate_technical_indicators(
            df,
            ma_windows=ma_windows,
            ema_windows=ema_windows,
            rsi_window=rsi_window,
            macd_fast=macd_fast,
            macd_slow=macd_slow,
            macd_signal=macd_signal,
            bb_window=bb_window,
            bb_std=bb_std,
            atr_window=atr_window,
            stoch_k_window=stoch_k_window,
            stoch_d_window=stoch_d_window,
            price_column=price_column
        )
    
    # Portfolio Metrics
    @staticmethod
    def calculate_wealth_index(df, initial_investment=1000.0, returns_column='Returns'):
        return calculate_wealth_index(df, initial_investment, returns_column)
    
    @staticmethod
    def calculate_correlation(df1, df2, window=30, column='Returns'):
        return calculate_correlation(df1, df2, window, column)
    
    @staticmethod
    def calculate_beta(stock_df, market_df, window=252, returns_column='Returns'):
        return calculate_beta(stock_df, market_df, window, returns_column)
    
    @staticmethod
    def calculate_alpha(stock_df, market_df, risk_free_rate=0.02, window=252, returns_column='Returns', trading_days=252):
        return calculate_alpha(stock_df, market_df, risk_free_rate, window, returns_column, trading_days)
    
    @staticmethod
    def calculate_information_ratio(portfolio_df, benchmark_df, window=252, returns_column='Returns'):
        return calculate_information_ratio(portfolio_df, benchmark_df, window, returns_column)
    
    @staticmethod
    def calculate_treynor_ratio(df, risk_free_rate=0.02, window=252, returns_column='Returns', trading_days=252):
        return calculate_treynor_ratio(df, risk_free_rate, window, returns_column, trading_days)


# Create singleton instance for convenience
data_processor = DataProcessor()


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Main object
    'data_processor',
    'DataProcessor',
    
    # Standardization
    'standardize_dataframe',
    'clean_data',
    'resample_data',
    
    # Returns
    'calculate_returns',
    'calculate_cumulative_returns',
    'calculate_rolling_returns',
    
    # Risk Metrics
    'calculate_volatility',
    'calculate_drawdown',
    'calculate_sharpe_ratio',
    'calculate_sortino_ratio',
    'calculate_max_drawdown',
    'calculate_var',
    
    # Technical Indicators
    'calculate_moving_averages',
    'calculate_ema',
    'calculate_rsi',
    'calculate_macd',
    'calculate_bollinger_bands',
    'calculate_atr',
    'calculate_stochastic',
    'calculate_technical_indicators',  # Umbrella function
    
    # Portfolio Metrics
    'calculate_wealth_index',
    'calculate_correlation',
    'calculate_beta',
    'calculate_alpha',
    'calculate_information_ratio',
    'calculate_treynor_ratio',
]