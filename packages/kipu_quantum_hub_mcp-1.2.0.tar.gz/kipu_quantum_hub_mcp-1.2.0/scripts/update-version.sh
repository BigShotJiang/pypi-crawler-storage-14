#!/usr/bin/env sh

version=${1:-0.0.0}

# Update version in pyproject.toml
sed -i "s/^version = .*$/version = \"${version}\"/g" pyproject.toml
