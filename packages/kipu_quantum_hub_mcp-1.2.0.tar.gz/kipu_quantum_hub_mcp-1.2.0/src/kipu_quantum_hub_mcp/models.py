from typing import Optional, TypeVar, Generic

from pydantic import BaseModel, Field
from planqk.quantum.client.sdk import (
    BackendHardwareProvider,
    BackendProvider,
    BackendStatus,
    BackendTechnology,
    BackendType, BackendAccessType,
)


class BackendSummary(BaseModel):
    id: Optional[str]
    display_name: Optional[str]
    provider: Optional[BackendProvider]
    hardware_provider: Optional[BackendHardwareProvider]
    type: Optional[BackendType]
    status: Optional[BackendStatus]
    free_of_charge: Optional[bool]
    access_type: Optional[BackendAccessType]

class UseCaseServiceSummary(BaseModel):
    id: Optional[str] = None
    created_at: Optional[str] = Field(default=None, alias="createdAt")
    modified_at: Optional[str] = Field(default=None, alias="modifiedAt")
    name: Optional[str] = None
    display_name: Optional[str] = Field(default=None, alias="displayName")
    provider: Optional[str] = None
    type: Optional[str] = None
    lifecycle: Optional[str] = None
    service_definition_id: Optional[str] = Field(default=None, alias="serviceDefinitionId")

    model_config = {"populate_by_name": True}


class UseCaseAlgorithmSummary(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    intent: Optional[str] = None


class Author(BaseModel):
    """Author information for use cases."""
    id: str
    name: Optional[str] = None
    model_config = {"populate_by_name": True}


class UseCaseSummary(BaseModel):
    """Summary information for a use case."""
    id: str
    title: str
    short_description: Optional[str] = Field(default=None, alias="shortDescription")
    status: str
    authors: list[Author]

    model_config = {"populate_by_name": True}


T = TypeVar('T')

class PageableResponse(BaseModel, Generic[T]):
    """Generic pageable response wrapper for API endpoints that return paginated data."""
    content: list[T]
    first: bool
    last: bool
    total_pages: int = Field(alias="totalPages")

    model_config = {"populate_by_name": True}
