"""
Kipu Quantum Hub MCP Server

A Model Context Protocol server for interacting with the Kipu Quantum Hub platform.
"""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("kipu-quantum-hub-mcp")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

from .server import mcp

__all__ = ["mcp", "__version__"]