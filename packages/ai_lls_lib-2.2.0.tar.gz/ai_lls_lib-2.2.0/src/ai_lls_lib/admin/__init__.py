"""Admin module for user management and administrative operations."""
from .service import AdminService

__all__ = ["AdminService"]
