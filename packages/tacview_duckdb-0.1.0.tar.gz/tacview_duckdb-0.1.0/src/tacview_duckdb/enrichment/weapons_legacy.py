"""Weapon enrichment logic."""

import json
from typing import Optional
import duckdb

from .pipeline import Enricher


class WeaponEnricher(Enricher):
    """
    Enriches weapon objects with launcher/target information.
    
    Matches weapons to:
    - Launchers (parent_id): Platform that fired the weapon (first position)
    - Targets (properties.TargetIDs): Objects the weapon hit/approached (last position, array)
    """
    
    def __init__(
        self,
        time_window: float = 0.5,
        proximity_radius: float = 100.0,
        static_radius: float = 500.0,
        find_launchers: bool = True,
        find_targets: bool = True,
        batch_size: int = 1000
    ):
        """
        Initialize weapon enricher.
        
        Args:
            time_window: Time window around weapon event (default: 0.5s)
            proximity_radius: Distance for moving platforms (default: 100m)
            static_radius: Distance for static platforms (default: 500m)
            find_launchers: Enrich with launcher data (default: True)
            find_targets: Enrich with target data (default: True)
            batch_size: Objects per batch for chunked processing (default: 1000). Fixed count ensures consistent performance regardless of mission action density.
        """
        self.time_window = time_window
        self.proximity_radius = proximity_radius
        self.static_radius = static_radius
        self.find_launchers = find_launchers
        self.find_targets = find_targets
        self.batch_size = batch_size
    
    def enrich(self, objects: list, conn: duckdb.DuckDBPyConnection) -> int:
        """
        Run weapon enrichment with object count-based batching.
        
        Uses LIMIT without OFFSET - the filter automatically excludes already-enriched weapons,
        so each iteration naturally processes the next batch.
        
        Args:
            objects: Not used (queries DB directly)
            conn: DuckDB connection
            
        Returns:
            Number of weapons enriched
        """
        total_enriched = 0
        
        # Process launchers in batches (filter does the "offset" for us)
        if self.find_launchers:
            while True:
                count = self._enrich_batched(
                    conn,
                    limit=self.batch_size,
                    time_window=self.time_window,
                    proximity_radius=self.proximity_radius,
                    static_radius=self.static_radius,
                    use_last_position=False
                )
                if count == 0:
                    break
                total_enriched += count
        
        # Process targets in batches (filter does the "offset" for us)
        if self.find_targets:
            while True:
                count = self._enrich_batched(
                    conn,
                    limit=self.batch_size,
                    time_window=self.time_window,
                    proximity_radius=self.proximity_radius,
                    static_radius=self.proximity_radius * 1.5,  # Smaller radius for targets
                    use_last_position=True
                )
                if count == 0:
                    break
                total_enriched += count
        
        return total_enriched
    
    def _enrich_batched(
        self,
        conn: duckdb.DuckDBPyConnection,
        limit: int,
        time_window: float,
        proximity_radius: float,
        static_radius: float,
        use_last_position: bool = False
    ) -> int:
        """
        Batched enrichment using two-stage matching (moving + static platforms).
        Split into separate queries to reduce memory usage.
        
        Args:
            conn: DuckDB connection
            limit: Batch size (LIMIT clause)
            time_window: Time window around weapon event (narrowed to ±0.2s for dynamic)
            proximity_radius: Distance for moving platforms
            static_radius: Distance for static platforms
            use_last_position: If True, match at impact (target). If False, match at launch (launcher)
            
        Returns:
            Number of weapons enriched in this batch
        """
        # STEP 1: Try dynamic matching (±0.2s window)
        stage1_matches = self._match_weapons_dynamic(
            conn, limit, use_last_position, proximity_radius
        )
        
        # STEP 2: For unmatched weapons, try static matching
        stage2_matches = self._match_weapons_static(
            conn, limit, use_last_position, static_radius
        )
        
        # Combine both stages
        all_matches = stage1_matches + stage2_matches
        
        if not all_matches:
            return 0
        
        # Bulk update parent_id for launchers only
        if not use_last_position:
            weapon_launcher_pairs = [(platform_id, weapon_id) 
                                     for weapon_id, _, _, _, platform_id, *_ in all_matches]
            
            if weapon_launcher_pairs:
                conn.executemany(
                    "UPDATE objects SET parent_id = ? WHERE id = ?",
                    weapon_launcher_pairs
                )
                
                # Insert WEAPON_LAUNCH events into tactical_events
                self._insert_weapon_launch_events(conn, all_matches)
        
        # Insert WEAPON_HIT/WEAPON_MISS events into tactical_events
        if use_last_position:
            self._insert_weapon_impact_events(conn, all_matches)
        
        return len(all_matches)
    
    def _match_weapons_dynamic(
        self,
        conn: duckdb.DuckDBPyConnection,
        limit: int,
        use_last_position: bool,
        proximity_radius: float
    ) -> list:
        """
        Stage 1: Match weapons to platforms with recent states (±0.2s window).
        Uses LATERAL join to get only one state per platform candidate.
        """
        order_direction = "DESC" if use_last_position else "ASC"
        event_name = "impact_time" if use_last_position else "launch_time"
        already_enriched_filter = "AND w.id NOT IN (SELECT initiator_id FROM tactical_events WHERE event_type IN ('WEAPON_HIT', 'WEAPON_MISS', 'WEAPON_DESTROYED'))" if use_last_position else "AND w.parent_id IS NULL"
        
        if use_last_position:
            platform_exclusion_filter = ""
            target_type_filter = "(weapon_type_basic = 'Missile') OR (platform_type_class IN ('Air', 'Sea', 'Ground'))"
        else:
            platform_exclusion_filter = "AND p.type_class IN ('Air', 'Sea', 'Ground')"
            target_type_filter = "TRUE"
        
        proximity_radius_sq = proximity_radius * proximity_radius
        
        query = f"""
        WITH weapon_batch AS (
            SELECT id
            FROM objects w
            WHERE (w.type_class = 'Weapon' 
                   OR w.type_basic IN ('Missile', 'Rocket', 'Bomb', 'Torpedo', 'Beam'))
              AND w.coalition IS NOT NULL
              {already_enriched_filter}
            ORDER BY w.first_seen
            LIMIT ?
        ),
        weapon_all_states AS (
            SELECT 
                w.id as weapon_id,
                w.name as weapon_name,
                w.coalition as weapon_coalition,
                w.type_basic as weapon_type_basic,
                s.timestamp as {event_name},
                s.u as weapon_u,
                s.v as weapon_v,
                s.altitude as weapon_alt,
                s.id as weapon_state_id,
                ROW_NUMBER() OVER (PARTITION BY w.id ORDER BY s.timestamp {order_direction}) as rn
            FROM weapon_batch wb
            JOIN objects w ON w.id = wb.id
            JOIN states s ON w.id = s.object_id
            WHERE s.u IS NOT NULL AND s.v IS NOT NULL
        ),
        weapon_selected_states AS (
            SELECT weapon_id, weapon_name, weapon_coalition, weapon_type_basic, {event_name},
                   weapon_u, weapon_v, weapon_alt, weapon_state_id
            FROM weapon_all_states
            WHERE rn = 1
        ),
        
        -- STAGE 1: Moving platforms with pair-based pre-filtering
        stage1_weapon_platform_pairs AS (
            SELECT
                w.weapon_id,
                w.{event_name} as event_time,
                w.weapon_u,
                w.weapon_v,
                w.weapon_alt,
                w.weapon_state_id,
                w.weapon_type_basic,
                p.id as platform_id,
                p.name as platform_name,
                p.type_class as platform_type_class,
                p.type_class || '+' || COALESCE(p.type_basic, '') as platform_type,
                p.type_basic as platform_type_basic,
                p.pilot as platform_pilot,
                p.coalition as platform_coalition
            FROM weapon_selected_states w
            JOIN objects p ON p.id != w.weapon_id
                AND p.coalition IS NOT NULL
                {platform_exclusion_filter}
        ),
        stage1_all_platform_states AS (
            SELECT
                s.object_id as platform_id,
                s.timestamp,
                s.u,
                s.v,
                s.altitude,
                s.id as platform_state_id
            FROM states s
            WHERE s.object_id IN (SELECT DISTINCT platform_id FROM stage1_weapon_platform_pairs)
        ),
        stage1_closest_states AS (
            SELECT
                wpp.weapon_id,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type,
                wpp.platform_type_class,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                aps.u,
                aps.v,
                aps.altitude,
                aps.platform_state_id,
                ROW_NUMBER() OVER (
                    PARTITION BY wpp.weapon_id, wpp.platform_id
                    ORDER BY ABS(aps.timestamp - wpp.event_time)
                ) as rn
            FROM stage1_weapon_platform_pairs wpp
            JOIN stage1_all_platform_states aps ON aps.platform_id = wpp.platform_id
                AND aps.timestamp BETWEEN wpp.event_time - ? AND wpp.event_time + ?
                AND ABS(aps.altitude - wpp.weapon_alt) <= 100  -- CRITICAL: Altitude pre-filter
        ),
        stage1_matches AS (
            SELECT 
                weapon_id,
                weapon_state_id,
                weapon_type_basic,
                event_time as {event_name},
                platform_id,
                platform_name,
                platform_type,
                platform_type_basic,
                platform_pilot,
                platform_coalition,
                platform_state_id,
                SQRT(
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS distance_meters,
                ROW_NUMBER() OVER (PARTITION BY weapon_id ORDER BY 
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS rank
            FROM stage1_closest_states
            WHERE rn = 1  -- Only closest state per platform per weapon
              AND (POWER(weapon_u - u, 2) + 
                   POWER(weapon_v - v, 2) + 
                   POWER(weapon_alt - altitude, 2)) <= ?
              AND ({target_type_filter})
        ),
        
        -- STAGE 2: Static platforms with pair-based pre-filtering
        unmatched_weapons AS (
            SELECT w.* 
            FROM weapon_selected_states w
            WHERE NOT EXISTS (
                SELECT 1 FROM stage1_matches s1 WHERE s1.weapon_id = w.weapon_id AND s1.rank = 1
            )
        ),
        stage2_weapon_platform_pairs_pre AS (
            SELECT
                w.weapon_id,
                w.{event_name} as event_time,
                w.weapon_u,
                w.weapon_v,
                w.weapon_alt,
                w.weapon_state_id,
                w.weapon_type_basic,
                p.id as platform_id,
                p.name as platform_name,
                p.type_class as platform_type_class,
                p.type_class || '+' || COALESCE(p.type_basic, '') as platform_type,
                p.type_basic as platform_type_basic,
                p.pilot as platform_pilot,
                p.coalition as platform_coalition
            FROM unmatched_weapons w
            JOIN objects p ON p.id != w.weapon_id
                AND p.coalition IS NOT NULL
                AND p.first_seen <= w.{event_name}
                AND (p.removed_at IS NULL OR p.removed_at >= w.{event_name})
                {platform_exclusion_filter}
        ),
        platform_last_state_per_weapon AS (
            SELECT 
                wpp.weapon_id,
                wpp.platform_id,
                s.u,
                s.v,
                s.altitude,
                ROW_NUMBER() OVER (
                    PARTITION BY wpp.weapon_id, wpp.platform_id
                    ORDER BY s.timestamp DESC
                ) as state_rank
            FROM stage2_weapon_platform_pairs_pre wpp
            JOIN states s ON s.object_id = wpp.platform_id
                AND s.timestamp <= wpp.event_time + 0.1
            WHERE s.u IS NOT NULL
              AND s.v IS NOT NULL
        ),
        stage2_weapon_platform_pairs AS (
            SELECT
                wpp.weapon_id,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type_class,
                wpp.platform_type,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                pls.u as platform_u,
                pls.v as platform_v,
                pls.altitude as platform_alt
            FROM stage2_weapon_platform_pairs_pre wpp
            LEFT JOIN platform_last_state_per_weapon pls ON pls.weapon_id = wpp.weapon_id
                AND pls.platform_id = wpp.platform_id
                AND pls.state_rank = 1
            WHERE pls.platform_id IS NOT NULL
              AND (POWER(wpp.weapon_u - pls.u, 2) + POWER(wpp.weapon_v - pls.v, 2)) <= POWER(5000, 2)
        ),
        stage2_all_platform_states AS (
            SELECT
                s.object_id as platform_id,
                s.timestamp,
                s.u,
                s.v,
                s.altitude,
                s.id as platform_state_id
            FROM states s
            WHERE s.object_id IN (SELECT DISTINCT platform_id FROM stage2_weapon_platform_pairs)
        ),
        stage2_closest_states AS (
            SELECT
                wpp.weapon_id,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type,
                wpp.platform_type_class,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                aps.u,
                aps.v,
                aps.altitude,
                aps.platform_state_id,
                ROW_NUMBER() OVER (
                    PARTITION BY wpp.weapon_id, wpp.platform_id
                    ORDER BY aps.timestamp DESC
                ) as rn
            FROM stage2_weapon_platform_pairs wpp
            JOIN stage2_all_platform_states aps ON aps.platform_id = wpp.platform_id
                AND aps.timestamp <= wpp.event_time + 0.1
                AND ABS(aps.altitude - wpp.weapon_alt) <= 100
        ),
        stage2_matches AS (
            SELECT 
                weapon_id,
                weapon_state_id,
                weapon_type_basic,
                event_time as {event_name},
                platform_id,
                platform_name,
                platform_type,
                platform_type_basic,
                platform_pilot,
                platform_coalition,
                platform_state_id,
                SQRT(
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS distance_meters,
                ROW_NUMBER() OVER (PARTITION BY weapon_id ORDER BY 
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS rank
            FROM stage2_closest_states
            WHERE rn = 1
              AND (POWER(weapon_u - u, 2) + 
                   POWER(weapon_v - v, 2) + 
                   POWER(weapon_alt - altitude, 2)) <= ?
              AND ({target_type_filter})
        ),
        
        -- Combine both stages
        all_matches AS (
            SELECT * FROM stage1_matches WHERE rank = 1
            UNION ALL
            SELECT * FROM stage2_matches WHERE rank = 1
        )
        SELECT 
            weapon_id,
            weapon_state_id,
            weapon_type_basic,
            {event_name},
            platform_id,
            platform_name,
            platform_type,
            platform_type_basic,
            platform_pilot,
            platform_coalition,
            platform_state_id,
            distance_meters
        FROM all_matches
        """
        
        # Execute two-stage bulk match query with LIMIT (no OFFSET - filter handles it)
        matches = conn.execute(
            bulk_match_query,
            [limit, time_window, time_window, proximity_radius_sq, static_radius_sq]
        ).fetchall()
        
        if not matches:
            return 0
        
        # Bulk update parent_id for launchers only
        if not use_last_position:
            weapon_launcher_pairs = [(platform_id, weapon_id) 
                                     for weapon_id, _, _, _, platform_id, *_ in matches]
            
            if weapon_launcher_pairs:
                conn.executemany(
                    "UPDATE objects SET parent_id = ? WHERE id = ?",
                    weapon_launcher_pairs
                )
                
                # Insert WEAPON_LAUNCH events into tactical_events
                self._insert_weapon_launch_events(conn, matches)
        
        # Insert WEAPON_HIT/WEAPON_DECOYED/WEAPON_MISS events into tactical_events
        if use_last_position:
            self._insert_weapon_impact_events(conn, matches)
        
        return len(matches)
    
    def _enrich_bulk(
        self,
        conn: duckdb.DuckDBPyConnection,
        time_window: float,
        proximity_radius: float,
        static_radius: float,
        use_last_position: bool = False
    ) -> int:
        """
        Bulk enrichment using two-stage matching (moving + static platforms).
        
        Args:
            conn: DuckDB connection
            time_window: Time window around weapon event
            proximity_radius: Distance for moving platforms
            static_radius: Distance for static platforms
            use_last_position: If True, match at impact (target). If False, match at launch (launcher)
            
        Returns:
            Number of weapons enriched
        """
        proximity_radius_sq = proximity_radius * proximity_radius
        static_radius_sq = static_radius * static_radius
        
        # Order direction: ASC for first state (launch), DESC for last state (impact)
        order_direction = "DESC" if use_last_position else "ASC"
        event_name = "impact_time" if use_last_position else "launch_time"
        # Conditional filter for already enriched weapons
        # The filter automatically excludes weapons enriched in previous iterations
        # For targets: exclude weapons with outcome events (HIT/MISS/DESTROYED)
        #   Note: WEAPON_DECOYED doesn't exist yet - it's created later by MissedWeaponAnalyzer
        # For launchers: exclude weapons with parent_id already set
        already_enriched_filter = "AND w.id NOT IN (SELECT initiator_id FROM tactical_events WHERE event_type IN ('WEAPON_HIT', 'WEAPON_MISS', 'WEAPON_DESTROYED'))" if use_last_position else "AND w.parent_id IS NULL"
        
        # Platform filtering based on mode
        if use_last_position:
            # Target detection: only missiles can target other weapons
            platform_exclusion_filter = ""
            target_type_filter = """
                      (weapon_type_basic = 'Missile')  -- Missiles can target anything
                      OR 
                      (platform_type_class IN ('Air', 'Sea', 'Ground'))  -- Non-missiles can only target Air/Sea/Ground
            """
        else:
            # Launcher detection: only Air/Sea/Ground can be launchers
            platform_exclusion_filter = "AND p.type_class IN ('Air', 'Sea', 'Ground')"
            target_type_filter = "TRUE"
        
        # Two-stage bulk query
        bulk_match_query = f"""
        WITH weapon_all_states AS (
            SELECT 
                w.id as weapon_id,
                w.name as weapon_name,
                w.coalition as weapon_coalition,
                w.type_basic as weapon_type_basic,
                s.timestamp as {event_name},
                s.u as weapon_u,
                s.v as weapon_v,
                s.altitude as weapon_alt,
                s.id as weapon_state_id,
                ROW_NUMBER() OVER (PARTITION BY w.id ORDER BY s.timestamp {order_direction}) as rn
            FROM objects w
            JOIN states s ON w.id = s.object_id
            WHERE (w.type_class = 'Weapon' 
                   OR w.type_basic IN ('Missile', 'Rocket', 'Bomb', 'Torpedo', 'Beam'))
              AND w.coalition IS NOT NULL
              {already_enriched_filter}
        ),
        weapon_selected_states AS (
            SELECT weapon_id, weapon_name, weapon_coalition, weapon_type_basic, {event_name},
                   weapon_u, weapon_v, weapon_alt, weapon_state_id
            FROM weapon_all_states
            WHERE rn = 1
        ),
        
        -- STAGE 1: Moving platforms with pair-based pre-filtering
        stage1_weapon_platform_pairs AS (
            SELECT
                w.weapon_id,
                w.{event_name} as event_time,
                w.weapon_u,
                w.weapon_v,
                w.weapon_alt,
                w.weapon_state_id,
                w.weapon_type_basic,
                p.id as platform_id,
                p.name as platform_name,
                p.type_class as platform_type_class,
                p.type_class || '+' || COALESCE(p.type_basic, '') as platform_type,
                p.type_basic as platform_type_basic,
                p.pilot as platform_pilot,
                p.coalition as platform_coalition
            FROM weapon_selected_states w
            JOIN objects p ON p.id != w.weapon_id
                AND p.coalition IS NOT NULL
                {platform_exclusion_filter}
        ),
        stage1_all_platform_states AS (
            SELECT
                s.object_id as platform_id,
                s.timestamp,
                s.u,
                s.v,
                s.altitude,
                s.id as platform_state_id
            FROM states s
            WHERE s.object_id IN (SELECT DISTINCT platform_id FROM stage1_weapon_platform_pairs)
        ),
        stage1_closest_states AS (
            SELECT
                wpp.weapon_id,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type,
                wpp.platform_type_class,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                aps.u,
                aps.v,
                aps.altitude,
                aps.platform_state_id,
                ROW_NUMBER() OVER (
                    PARTITION BY wpp.weapon_id, wpp.platform_id
                    ORDER BY ABS(aps.timestamp - wpp.event_time)
                ) as rn
            FROM stage1_weapon_platform_pairs wpp
            JOIN stage1_all_platform_states aps ON aps.platform_id = wpp.platform_id
                AND aps.timestamp BETWEEN wpp.event_time - ? AND wpp.event_time + ?
                AND ABS(aps.altitude - wpp.weapon_alt) <= 100  -- CRITICAL: Altitude pre-filter
        ),
        stage1_matches AS (
            SELECT 
                weapon_id,
                weapon_state_id,
                weapon_type_basic,
                event_time as {event_name},
                platform_id,
                platform_name,
                platform_type,
                platform_type_basic,
                platform_pilot,
                platform_coalition,
                platform_state_id,
                SQRT(
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS distance_meters,
                ROW_NUMBER() OVER (PARTITION BY weapon_id ORDER BY 
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS rank
            FROM stage1_closest_states
            WHERE rn = 1  -- Only closest state per platform per weapon
              AND (POWER(weapon_u - u, 2) + 
                   POWER(weapon_v - v, 2) + 
                   POWER(weapon_alt - altitude, 2)) <= ?
              AND ({target_type_filter})
        ),
        
        -- STAGE 2: Static platforms with pair-based pre-filtering
        unmatched_weapons AS (
            SELECT w.* 
            FROM weapon_selected_states w
            WHERE NOT EXISTS (
                SELECT 1 FROM stage1_matches s1 WHERE s1.weapon_id = w.weapon_id AND s1.rank = 1
            )
        ),
        -- OPTIMIZATION: Get last state for each platform-weapon pair BEFORE weapon spawn
        -- (Reduces state table scan from millions to thousands)
        stage2_weapon_platform_pairs_pre AS (
            SELECT
                w.weapon_id,
                w.{event_name} as event_time,
                w.weapon_u,
                w.weapon_v,
                w.weapon_alt,
                w.weapon_state_id,
                w.weapon_type_basic,
                p.id as platform_id,
                p.name as platform_name,
                p.type_class as platform_type_class,
                p.type_class || '+' || COALESCE(p.type_basic, '') as platform_type,
                p.type_basic as platform_type_basic,
                p.pilot as platform_pilot,
                p.coalition as platform_coalition
            FROM unmatched_weapons w
            JOIN objects p ON p.id != w.weapon_id
                AND p.coalition IS NOT NULL
                AND p.first_seen <= w.{event_name}
                AND (p.removed_at IS NULL OR p.removed_at >= w.{event_name})
                {platform_exclusion_filter}
        ),
        platform_last_state_per_weapon AS (
            SELECT 
                wpp.weapon_id,
                wpp.platform_id,
                s.u,
                s.v,
                s.altitude,
                ROW_NUMBER() OVER (
                    PARTITION BY wpp.weapon_id, wpp.platform_id
                    ORDER BY s.timestamp DESC
                ) as state_rank
            FROM stage2_weapon_platform_pairs_pre wpp
            JOIN states s ON s.object_id = wpp.platform_id
                AND s.timestamp <= wpp.event_time + 0.1  -- CRITICAL: Last state BEFORE weapon spawn (with 0.1s buffer for timing edge cases)
            WHERE s.u IS NOT NULL
              AND s.v IS NOT NULL
        ),
        stage2_weapon_platform_pairs AS (
            SELECT
                wpp.weapon_id,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type_class,
                wpp.platform_type,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                pls.u as platform_u,
                pls.v as platform_v,
                pls.altitude as platform_alt
            FROM stage2_weapon_platform_pairs_pre wpp
            -- CRITICAL OPTIMIZATION: Spatial pre-filter using platform's last known position BEFORE weapon spawn
            LEFT JOIN platform_last_state_per_weapon pls ON pls.weapon_id = wpp.weapon_id
                AND pls.platform_id = wpp.platform_id
                AND pls.state_rank = 1
            -- Reject platforms >5km away (static_radius is typically 500m, 5km gives 10x margin)
            WHERE pls.platform_id IS NOT NULL  -- Must have at least one state before weapon spawn
              AND (POWER(wpp.weapon_u - pls.u, 2) + POWER(wpp.weapon_v - pls.v, 2)) <= POWER(5000, 2)
        ),
        stage2_all_platform_states AS (
            SELECT
                s.object_id as platform_id,
                s.timestamp,
                s.u,
                s.v,
                s.altitude,
                s.id as platform_state_id
            FROM states s
            WHERE s.object_id IN (SELECT DISTINCT platform_id FROM stage2_weapon_platform_pairs)
        ),
        stage2_closest_states AS (
            SELECT
                wpp.weapon_id,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type,
                wpp.platform_type_class,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                aps.u,
                aps.v,
                aps.altitude,
                aps.platform_state_id,
                ROW_NUMBER() OVER (
                    PARTITION BY wpp.weapon_id, wpp.platform_id
                    ORDER BY aps.timestamp DESC  -- Last state before (or at) spawn
                ) as rn
            FROM stage2_weapon_platform_pairs wpp
            JOIN stage2_all_platform_states aps ON aps.platform_id = wpp.platform_id
                AND aps.timestamp <= wpp.event_time + 0.1  -- Small buffer forward for timing edge cases
                AND ABS(aps.altitude - wpp.weapon_alt) <= 100  -- CRITICAL: Altitude pre-filter
        ),
        stage2_matches AS (
            SELECT 
                weapon_id,
                weapon_state_id,
                weapon_type_basic,
                event_time as {event_name},
                platform_id,
                platform_name,
                platform_type,
                platform_type_basic,
                platform_pilot,
                platform_coalition,
                platform_state_id,
                SQRT(
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS distance_meters,
                ROW_NUMBER() OVER (PARTITION BY weapon_id ORDER BY 
                    POWER(weapon_u - u, 2) + 
                    POWER(weapon_v - v, 2) + 
                    POWER(weapon_alt - altitude, 2)
                ) AS rank
            FROM stage2_closest_states
            WHERE rn = 1  -- Only last state per platform per weapon
              AND (POWER(weapon_u - u, 2) + 
                   POWER(weapon_v - v, 2) + 
                   POWER(weapon_alt - altitude, 2)) <= ?
              AND ({target_type_filter})
        ),
        
        -- Combine both stages
        all_matches AS (
            SELECT * FROM stage1_matches WHERE rank = 1
            UNION ALL
            SELECT * FROM stage2_matches WHERE rank = 1
        )
        SELECT 
            weapon_id,
            weapon_state_id,
            weapon_type_basic,
            {event_name},
            platform_id,
            platform_name,
            platform_type,
            platform_type_basic,
            platform_pilot,
            platform_coalition,
            platform_state_id,
            distance_meters
        FROM all_matches
        """
        
        # Execute two-stage bulk match query
        matches = conn.execute(
            bulk_match_query,
            [time_window, time_window, proximity_radius_sq, static_radius_sq]
        ).fetchall()
        
        if not matches:
            return 0
        
        # Bulk update parent_id for launchers only
        if not use_last_position:
            weapon_launcher_pairs = [(platform_id, weapon_id) 
                                     for weapon_id, _, _, _, platform_id, *_ in matches]
            
            if weapon_launcher_pairs:
                conn.executemany(
                    "UPDATE objects SET parent_id = ? WHERE id = ?",
                    weapon_launcher_pairs
                )
                
                # Insert WEAPON_LAUNCH events into tactical_events
                self._insert_weapon_launch_events(conn, matches)
        
        # Insert WEAPON_HIT/WEAPON_DECOYED/WEAPON_MISS events into tactical_events
        if use_last_position:
            self._insert_weapon_outcome_events(conn, matches)
        
        return len(matches)
    
    def _enrich_bulk_unified(
        self,
        conn: duckdb.DuckDBPyConnection,
        proximity_radius: float,
        static_radius: float,
        use_last_position: bool = False
    ) -> int:
        """
        EXPERIMENTAL: Unified bulk enrichment using single-stage "last state before spawn" matching.
        
        Combines moving and static platform detection into one query by always using
        the last known state before weapon spawn. Applies adaptive distance thresholds
        based on platform characteristics.
        
        Args:
            conn: DuckDB connection
            proximity_radius: Distance for moving platforms (100m)
            static_radius: Distance for static platforms (500m)
            use_last_position: If True, match at impact (target). If False, match at launch (launcher)
            
        Returns:
            Number of weapons enriched
        """
        # Determine event name and filters
        event_name = "last_seen" if use_last_position else "first_seen"
        
        # Platform type filtering
        if use_last_position:
            # For targets: include Air, Ground, Sea (exclude weapons for non-missiles)
            platform_filter = """
                AND (
                    p.type_class IN ('Air', 'Ground', 'Sea')
                    OR (w.weapon_type_basic = 'Missile' AND p.type_class = 'Weapon')
                    OR p.type_basic = 'Decoy'
                )
            """
        else:
            # For launchers: exclude projectiles and missiles (they can't launch weapons)
            platform_filter = """
                AND p.type_class IN ('Air', 'Ground', 'Sea')
                AND p.type_basic NOT IN ('Projectile', 'Missile', 'Rocket', 'Bomb', 'Torpedo')
            """
        
        # Squared distance thresholds for performance
        proximity_radius_sq = proximity_radius ** 2
        static_radius_sq = static_radius ** 2
        
        # Build unified bulk match query
        bulk_match_query = f"""
        WITH weapon_selected_states AS (
            SELECT 
                w.id as weapon_id,
                w.type_basic as weapon_type_basic,
                w.coalition as weapon_coalition,
                w.{event_name},
                s.u as weapon_u,
                s.v as weapon_v,
                s.altitude as weapon_alt,
                s.id as weapon_state_id
            FROM objects w
            JOIN states s ON w.id = s.object_id
                AND s.timestamp = w.{event_name}
            WHERE w.type_class = 'Weapon'
              AND w.{event_name} IS NOT NULL
              AND s.u IS NOT NULL
              AND s.v IS NOT NULL
        ),
        -- Create weapon-platform pairs with temporal filtering only
        weapon_platform_pairs_pre AS (
            SELECT
                w.weapon_id,
                w.{event_name} as event_time,
                w.weapon_u,
                w.weapon_v,
                w.weapon_alt,
                w.weapon_state_id,
                w.weapon_type_basic,
                w.weapon_coalition,
                p.id as platform_id,
                p.name as platform_name,
                p.type_class as platform_type_class,
                p.type_class || '+' || COALESCE(p.type_basic, '') as platform_type,
                p.type_basic as platform_type_basic,
                p.pilot as platform_pilot,
                p.coalition as platform_coalition
            FROM weapon_selected_states w
            JOIN objects p ON p.id != w.weapon_id
                AND p.coalition IS NOT NULL
                AND (w.weapon_coalition = p.coalition OR {use_last_position})  -- Coalition filter for launchers only
                AND p.first_seen <= w.{event_name}
                AND (p.removed_at IS NULL OR p.removed_at >= w.{event_name})
                {platform_filter}
        ),
        -- Get ONLY the last state BEFORE weapon spawn for each weapon-platform pair
        -- Uses correlated subquery to avoid loading all states (OOM prevention)
        weapon_platform_pairs AS (
            SELECT
                wpp.weapon_id,
                wpp.event_time,
                wpp.weapon_u,
                wpp.weapon_v,
                wpp.weapon_alt,
                wpp.weapon_state_id,
                wpp.weapon_type_basic,
                wpp.platform_id,
                wpp.platform_name,
                wpp.platform_type_class,
                wpp.platform_type,
                wpp.platform_type_basic,
                wpp.platform_pilot,
                wpp.platform_coalition,
                -- Correlated subquery: Get ONLY last state before spawn (no window function!)
                (SELECT s.u FROM states s 
                 WHERE s.object_id = wpp.platform_id 
                   AND s.timestamp <= wpp.event_time + 0.1
                   AND s.u IS NOT NULL
                 ORDER BY s.timestamp DESC LIMIT 1) as platform_u,
                (SELECT s.v FROM states s 
                 WHERE s.object_id = wpp.platform_id 
                   AND s.timestamp <= wpp.event_time + 0.1
                   AND s.v IS NOT NULL
                 ORDER BY s.timestamp DESC LIMIT 1) as platform_v,
                (SELECT s.altitude FROM states s 
                 WHERE s.object_id = wpp.platform_id 
                   AND s.timestamp <= wpp.event_time + 0.1
                   AND s.u IS NOT NULL
                 ORDER BY s.timestamp DESC LIMIT 1) as platform_alt,
                (SELECT s.id FROM states s 
                 WHERE s.object_id = wpp.platform_id 
                   AND s.timestamp <= wpp.event_time + 0.1
                   AND s.u IS NOT NULL
                 ORDER BY s.timestamp DESC LIMIT 1) as platform_state_id,
                (SELECT s.timestamp FROM states s 
                 WHERE s.object_id = wpp.platform_id 
                   AND s.timestamp <= wpp.event_time + 0.1
                   AND s.u IS NOT NULL
                 ORDER BY s.timestamp DESC LIMIT 1) as platform_timestamp
            FROM weapon_platform_pairs_pre wpp
        ),
        -- Now filter by distance using the retrieved last state
        weapon_platform_pairs_filtered AS (
            SELECT * FROM weapon_platform_pairs
            WHERE platform_u IS NOT NULL
              AND platform_v IS NOT NULL
              -- Spatial filter: Reject platforms >5km away
              AND (POWER(weapon_u - platform_u, 2) + POWER(weapon_v - platform_v, 2)) <= POWER(5000, 2)
        ),
        -- Calculate distances and apply adaptive thresholds
        platform_matches AS (
            SELECT 
                weapon_id,
                weapon_state_id,
                weapon_type_basic,
                event_time as {event_name},
                platform_id,
                platform_name,
                platform_type,
                platform_type_basic,
                platform_pilot,
                platform_coalition,
                platform_state_id,
                SQRT(
                    POWER(weapon_u - platform_u, 2) + 
                    POWER(weapon_v - platform_v, 2) + 
                    POWER(weapon_alt - platform_alt, 2)
                ) AS distance_meters,
                -- Adaptive threshold: tight for recent states (moving), wide for old states (static)
                CASE 
                    WHEN ABS(event_time - platform_timestamp) <= 1.0 THEN {proximity_radius_sq}  -- Recent state = moving platform
                    ELSE {static_radius_sq}  -- Old state = static platform
                END as distance_threshold_sq,
                ROW_NUMBER() OVER (PARTITION BY weapon_id ORDER BY 
                    POWER(weapon_u - platform_u, 2) + 
                    POWER(weapon_v - platform_v, 2) + 
                    POWER(weapon_alt - platform_alt, 2)
                ) AS rank
            FROM weapon_platform_pairs_filtered
            WHERE (POWER(weapon_u - platform_u, 2) + 
                   POWER(weapon_v - platform_v, 2) + 
                   POWER(weapon_alt - platform_alt, 2)) <= {static_radius_sq}  -- Use wider threshold as upper bound
        )
        SELECT 
            weapon_id,
            weapon_state_id,
            weapon_type_basic,
            {event_name},
            platform_id,
            platform_name,
            platform_type,
            platform_type_basic,
            platform_pilot,
            platform_coalition,
            platform_state_id,
            distance_meters
        FROM platform_matches
        WHERE rank = 1
          AND (POWER(distance_meters, 2)) <= distance_threshold_sq  -- Apply adaptive threshold
        """
        
        # Execute unified query
        matches = conn.execute(bulk_match_query).fetchall()
        
        if not matches:
            return 0
        
        # Bulk update parent_id for launchers only
        if not use_last_position:
            weapon_launcher_pairs = [(platform_id, weapon_id) 
                                     for weapon_id, _, _, _, platform_id, *_ in matches]
            
            if weapon_launcher_pairs:
                conn.executemany(
                    "UPDATE objects SET parent_id = ? WHERE id = ?",
                    weapon_launcher_pairs
                )
                
                # Insert WEAPON_LAUNCH events into tactical_events
                self._insert_weapon_launch_events(conn, matches)
        
        # Insert WEAPON_HIT/WEAPON_DECOYED/WEAPON_MISS events into tactical_events
        if use_last_position:
            self._insert_weapon_outcome_events(conn, matches)
        
        return len(matches)
    
    def _insert_weapon_launch_events(self, conn: duckdb.DuckDBPyConnection, matches: list):
        """
        Insert WEAPON_LAUNCH events into tactical_events table.
        
        Args:
            conn: DuckDB connection
            matches: List of launcher matches from bulk query
                Format: (weapon_id, wpn_state_id, weapon_type_basic, event_time,
                        platform_id, platform_name, platform_type, platform_type_basic,
                        platform_pilot, platform_coalition, platform_state_id, distance_meters)
        """
        if not matches:
            return
        
        # Use SQL INSERT...SELECT for efficiency
        # Build a query that joins matches with weapon/launcher data
        insert_query = """
        INSERT INTO tactical_events 
        (event_type, timestamp, initiator_id, target_id,
         initiator_type, target_type, initiator_coalition, target_coalition,
         longitude, latitude, altitude,
         initiator_state_id, target_state_id, initiator_parent_state_id, metadata)
        SELECT 
            'WEAPON_LAUNCH',
            w.first_seen,
            l.id,                    -- initiator = launcher
            w.id,                    -- target = weapon
            l.type_class,            -- initiator_type
            w.type_basic,            -- target_type
            l.coalition,
            w.coalition,
            ws.longitude, ws.latitude, ws.altitude,
            ls.id,                   -- initiator_state_id = launcher state
            ws.id,                   -- target_state_id = weapon state
            NULL,                    -- initiator_parent_state_id
            '{}'::JSON
        FROM objects w
        JOIN objects l ON w.parent_id = l.id
        JOIN states ws ON ws.object_id = w.id AND ws.timestamp = w.first_seen
        JOIN LATERAL (
            SELECT id, longitude, latitude, altitude
            FROM states
            WHERE object_id = l.id AND timestamp <= w.first_seen
            ORDER BY timestamp DESC LIMIT 1
        ) ls ON true
        WHERE w.id IN (SELECT UNNEST(?))
          AND w.first_seen IS NOT NULL
        """
        
        # Extract weapon IDs from matches
        weapon_ids = [match[0] for match in matches]
        
        conn.execute(insert_query, [weapon_ids])
    
    def _insert_weapon_outcome_events(self, conn: duckdb.DuckDBPyConnection, matches: list):
        """
        Insert WEAPON_HIT/WEAPON_MISS events into tactical_events table.
        
        NOTE: WEAPON_DECOYED events are handled by the missed_weapons enricher,
        which does sophisticated trajectory analysis to identify decoys and intended targets.
        
        Args:
            conn: DuckDB connection
            matches: List of target matches from bulk query
                Format: (weapon_id, wpn_state_id, weapon_type_basic, event_time,
                        platform_id, platform_name, platform_type, platform_type_basic,
                        platform_pilot, platform_coalition, platform_state_id, distance_meters)
        """
        # Filter out decoy hits - they'll be handled by missed_weapons enricher
        hit_events = []
        
        if matches:
            for match in matches:
                (weapon_id, wpn_state_id, weapon_type_basic, event_time,
                 platform_id, platform_name, platform_type, platform_type_basic,
                 platform_pilot, platform_coalition, platform_state_id, distance_meters) = match
                
                is_decoy = platform_type_basic == 'Decoy'
                
                if not is_decoy:
                    # WEAPON_HIT event (skip decoys)
                    hit_events.append((weapon_id, platform_id, wpn_state_id, platform_state_id, distance_meters))
        
        # Insert WEAPON_HIT events
        if hit_events:
            self._insert_hit_events(conn, hit_events)
        
        # Insert WEAPON_MISS events
        # The MISS query filters out weapons that already have HIT events
        # DECOYED weapons will be handled later by missed_weapons enricher
        self._insert_weapon_miss_events(conn)
    
    def _insert_hit_events(self, conn: duckdb.DuckDBPyConnection, hit_events: list):
        """Insert WEAPON_HIT events using SQL INSERT...SELECT."""
        # hit_events format: (weapon_id, target_id, weapon_state_id, target_state_id, distance)
        
        insert_query = """
        WITH hit_data AS (
            SELECT 
                UNNEST(?) as weapon_id,
                UNNEST(?) as target_id,
                UNNEST(?) as weapon_state_id,
                UNNEST(?) as target_state_id,
                UNNEST(?) as distance
        )
        INSERT INTO tactical_events 
        (event_type, timestamp, initiator_id, target_id,
         initiator_type, target_type, initiator_coalition, target_coalition,
         longitude, latitude, altitude,
         initiator_state_id, target_state_id, initiator_parent_state_id, metadata)
        SELECT 
            CASE 
                WHEN t.type_class = 'Weapon' AND w.coalition != t.coalition THEN 'WEAPON_DESTROYED'
                ELSE 'WEAPON_HIT'
            END,
            w.last_seen,
            w.id,                    -- initiator = weapon
            h.target_id,            -- target = hit object
            w.type_basic,
            t.type_class,
            w.coalition,
            t.coalition,
            ws.longitude, ws.latitude, ws.altitude,
            h.weapon_state_id,       -- weapon state at impact
            h.target_state_id,       -- target state at impact
            ls.id,                   -- launcher state at impact
            ('{"hit_distance": ' || h.distance || ', "hit_type": "' || 
             CASE 
                WHEN w.coalition = t.coalition THEN 'FRIENDLY_FIRE'
                WHEN w.coalition != t.coalition THEN 'ENEMY'
                ELSE 'NEUTRAL'
             END || '"}')::JSON
        FROM hit_data h
        JOIN objects w ON w.id = h.weapon_id
        JOIN objects t ON t.id = h.target_id
        JOIN states ws ON ws.id = h.weapon_state_id
        JOIN LATERAL (
            SELECT id
            FROM states
            WHERE object_id = w.parent_id AND timestamp <= w.last_seen
            ORDER BY timestamp DESC LIMIT 1
        ) ls ON w.parent_id IS NOT NULL
        """
        
        # Unpack hit_events into separate lists
        weapon_ids = [h[0] for h in hit_events]
        target_ids = [h[1] for h in hit_events]
        weapon_state_ids = [h[2] for h in hit_events]
        target_state_ids = [h[3] for h in hit_events]
        distances = [h[4] for h in hit_events]
        
        conn.execute(insert_query, [weapon_ids, target_ids, weapon_state_ids, target_state_ids, distances])
    
    def _insert_weapon_miss_events(self, conn: duckdb.DuckDBPyConnection):
        """Insert WEAPON_MISS events for weapons that didn't hit anything."""
        insert_query = """
        INSERT INTO tactical_events 
        (event_type, timestamp, initiator_id, target_id,
         initiator_type, target_type, initiator_coalition, target_coalition,
         longitude, latitude, altitude,
         initiator_state_id, target_state_id, initiator_parent_state_id, metadata)
        SELECT 
            'WEAPON_MISS',
            w.last_seen,
            w.id,                    -- initiator = weapon
            NULL,                    -- target = none (for now, intended target analysis is separate)
            w.type_basic,
            NULL,
            w.coalition,
            NULL,
            ws.longitude, ws.latitude, ws.altitude,
            ws.id,                   -- weapon state at end of flight
            NULL,                    -- no target state
            (SELECT id FROM states 
             WHERE object_id = w.parent_id AND timestamp <= w.last_seen
             ORDER BY timestamp DESC LIMIT 1),  -- launcher state at end of flight
            '{}'::JSON
        FROM objects w
        JOIN LATERAL (
            SELECT id, longitude, latitude, altitude
            FROM states
            WHERE object_id = w.id
            ORDER BY timestamp DESC LIMIT 1
        ) ws ON true
        WHERE (w.type_class = 'Weapon' 
               OR w.type_basic IN ('Missile', 'Rocket', 'Bomb', 'Torpedo', 'Beam'))
          AND w.coalition IS NOT NULL
          AND w.last_seen IS NOT NULL
          AND w.id NOT IN (
              SELECT initiator_id FROM tactical_events 
              WHERE event_type IN ('WEAPON_HIT')
          )
        """
        
        conn.execute(insert_query)