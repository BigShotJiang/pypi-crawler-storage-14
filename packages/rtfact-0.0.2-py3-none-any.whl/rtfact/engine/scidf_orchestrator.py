import asyncio
import math
from typing import List, Dict, Optional, cast

from pydantic import BaseModel
import logging
from tqdm import tqdm

from ..core import LLMProvider, ContextProvider, EvaluationResult
from ..evaluation.judges import CorrectnessJudge, RefusalJudge
from ..data import QAPair
from ..cache import CacheConfig
from ..llm import CachedLLMProvider

_logger = logging.getLogger(__name__)

class ExperimentDataPoint(BaseModel):
    qa_id: int
    model_id: str
    k: int
    rho: float
    context: str
    response_text: str
    evaluation: EvaluationResult
    knowledge_depth: Optional[int] = None
    base_hallucination: Optional[float] = None


class QAResultSummary(BaseModel):
    qa_id: int
    model_id: str
    knowledge_depth: int
    base_hallucination: float
    # Additional fields for analysis / export
    question: Optional[str] = None
    ground_truth_answer: Optional[str] = None
    context_signal: Optional[str] = None
    response_signal: Optional[str] = None
    context_noise: Optional[str] = None
    response_noise: Optional[str] = None
    # Human-readable explanation when A/B contextual test fails
    reason: Optional[str] = None
    error: Optional[str] = None

    def pprint(self, *, show_context: bool = False, width: int = 80) -> None:
        """
        Pretty-print a compact, human-readable summary of this result.

        Args:
            show_context: When True, also print signal/noise contexts and responses.
            width: Separator width for visual grouping.
        """
        sep = "-" * width
        lines = [
            sep,
            f"QA ID:             {self.qa_id}",
            f"Model ID:          {self.model_id}",
            f"Knowledge depth:   {self.knowledge_depth}",
            f"Base hallucination:{self.base_hallucination}",
        ]
        if self.question:
            lines.append(f"Question:          {self.question}")
        if self.ground_truth_answer:
            lines.append(f"Ground truth:      {self.ground_truth_answer}")
        if self.reason:
            lines.append(f"Reason:            {self.reason}")
        if self.error:
            lines.append(f"Error:             {self.error}")

        if show_context:
            if self.context_signal:
                lines.append(sep)
                lines.append("Context (signal):")
                lines.append(self.context_signal)
            if self.response_signal:
                lines.append(sep)
                lines.append("Response (signal):")
                lines.append(self.response_signal)
            if self.context_noise:
                lines.append(sep)
                lines.append("Context (noise):")
                lines.append(self.context_noise)
            if self.response_noise:
                lines.append(sep)
                lines.append("Response (noise):")
                lines.append(self.response_noise)

        print("\n".join(lines))


class QAResultSummaryList(list):
    """
    Convenience container for a list of QAResultSummary objects.

    Behaves like a regular list but adds a ``pprint`` helper to quickly inspect
    a subset of results in the console.
    """

    def pprint(
        self,
        *,
        max_items: Optional[int] = None,
        show_context: bool = False,
        width: int = 80,
    ) -> None:
        """
        Pretty-print one or more QAResultSummary entries.

        Args:
            max_items: If given, only print the first ``max_items`` results.
            show_context: When True, also print contexts and responses.
            width: Separator width for visual grouping.
        """
        items = self if max_items is None else self[:max_items]
        for item in items:
            if isinstance(item, QAResultSummary):
                item.pprint(show_context=show_context, width=width)
            else:
                print("-" * width)
                print(repr(item))


class ScidfOrchestrator:
    """Orchestrator for SCID-F experiments."""

    def __init__(
        self,
        models: Dict[str, LLMProvider],
        context: ContextProvider,
        judge_provider: LLMProvider,
        k_max: int = 20,
        k_min: int = 2,
        batch_size: int = 3,
        scan_grid: Optional[List[int]] = None,
        replicas_per_k: int = 1,
        cache_config: Optional[CacheConfig] = None,
    ):
        self.models = models
        # Wrap models with caching if enabled
        if cache_config and cache_config.enabled:
            self.models = {
                mid: CachedLLMProvider(p, cache_config, mid)
                for mid, p in self.models.items()
            }

        self.context = context
        self.judge = CorrectnessJudge(judge_provider)
        self.refusal_judge = RefusalJudge(judge_provider)
        self.k_max = k_max
        self.k_min = max(1, int(k_min))
        self.batch_size = batch_size
        self.scan_grid = scan_grid or [1, 3, 5, 10, 20]
        self.replicas_per_k = replicas_per_k

        self._knowledge_depth_cache: Dict[tuple, int] = {}
        self._base_hallucination_cache: Dict[tuple, float] = {}
        self._ab_failure_reason_cache: Dict[tuple, Optional[str]] = {}

    async def measure_knowledge_depth(self, qa_pair: QAPair, model_id: str) -> int:
        """Measure knowledge depth (D) using Noise Titration (rho=0)."""
        model = self.models[model_id]

        for k in range(0, self.k_max + 1):
            context = await self.context.get_context(
                qa_pair.question,
                k,
                qa_id=qa_pair.id,
                rho=0.0,
                answer=qa_pair.ground_truth_answer,
            )
            response = await model.generate(
                f"Context:\n{context}\n\nQuestion: {qa_pair.question}"
            )

            evaluation = await self.judge.evaluate(
                qa_pair.question, qa_pair.ground_truth_answer, response, context
            )

            if not evaluation.is_correct:
                return k

        return self.k_max

    async def measure_contextual_fidelity_ab(
        self, qa_pair: QAPair, model_id: str
    ) -> tuple[float, str, str, str, str, Optional[str]]:
        """Measure A/B contextual fidelity and return H plus raw A/B traces.

        Returns:
            A tuple of:
                - H_contextual (0.0 or 1.0)
                - context_a (signal + noise)
                - resp_a
                - context_b (pure noise)
                - resp_b
                - failure_reason (optional, only when H_contextual == 1.0)
        """
        model = self.models[model_id]
        k_star = max(self.k_min, math.ceil(0.8 * self.k_max))

        # Test A: Signal + Noise
        context_a = await self.context.get_context(
            qa_pair.question,
            k_star,
            qa_id=qa_pair.id,
            rho=1.0,
            answer=qa_pair.ground_truth_answer,
        )
        resp_a = await model.generate(
            f"Context:\n{context_a}\n\nQuestion: {qa_pair.question}"
        )
        eval_a = await self.judge.evaluate(
            qa_pair.question, qa_pair.ground_truth_answer, resp_a, context_a
        )

        # Test B: Pure Noise
        context_b = await self.context.get_context(
            qa_pair.question,
            k_star,
            qa_id=qa_pair.id,
            rho=0.0,
            answer=qa_pair.ground_truth_answer,
        )
        resp_b = await model.generate(
            f"Context:\n{context_b}\n\nQuestion: {qa_pair.question}"
        )

        b_refusal = await self.refusal_judge.is_refusal(qa_pair.question, resp_b)

        f_contextual = bool(eval_a.is_correct and b_refusal)
        h_contextual = 0.0 if f_contextual else 1.0

        failure_reason: Optional[str] = None
        if h_contextual == 1.0:
            # Derive a compact human-readable reason for A/B failure.
            if not eval_a.is_correct and not b_refusal:
                failure_reason = (
                    "A incorrect under signal+noise context; "
                    "B answered instead of refusing under pure noise"
                )
            elif not eval_a.is_correct:
                failure_reason = "A incorrect under signal+noise context"
            elif not b_refusal:
                failure_reason = "B answered instead of refusing under pure noise"
            else:
                failure_reason = "A/B contextual test failed for unspecified reasons"

        return h_contextual, context_a, resp_a, context_b, resp_b, failure_reason

    async def process_qa_pair(self, qa_pair: QAPair, model_id: str) -> QAResultSummary:
        try:
            kd_key = (qa_pair.id, model_id)
            if kd_key in self._knowledge_depth_cache:
                knowledge_depth = self._knowledge_depth_cache[kd_key]
            else:
                knowledge_depth = await self.measure_knowledge_depth(qa_pair, model_id)
                self._knowledge_depth_cache[kd_key] = knowledge_depth

            if kd_key in self._base_hallucination_cache:
                h_contextual = self._base_hallucination_cache[kd_key]
                context_signal = None
                response_signal = None
                context_noise = None
                response_noise = None
                failure_reason = self._ab_failure_reason_cache.get(kd_key)
            else:
                (
                    h_contextual,
                    context_signal,
                    response_signal,
                    context_noise,
                    response_noise,
                    failure_reason,
                ) = await self.measure_contextual_fidelity_ab(qa_pair, model_id)
                self._base_hallucination_cache[kd_key] = h_contextual
                self._ab_failure_reason_cache[kd_key] = failure_reason

            return QAResultSummary(
                qa_id=qa_pair.id,
                model_id=model_id,
                knowledge_depth=knowledge_depth,
                base_hallucination=h_contextual,
                question=qa_pair.question,
                ground_truth_answer=qa_pair.ground_truth_answer,
                context_signal=context_signal,
                response_signal=response_signal,
                context_noise=context_noise,
                response_noise=response_noise,
                reason=failure_reason,
            )
        except Exception as e:
            _logger.warning(f"Error processing QA pair {qa_pair.id} for model {model_id}: {str(e)}")
            return QAResultSummary(
                qa_id=qa_pair.id,
                model_id=model_id,
                knowledge_depth=0,
                base_hallucination=1.0,
                question=qa_pair.question,
                ground_truth_answer=qa_pair.ground_truth_answer,
                error=str(e),
            )

    async def run_experiment(self, qa_pairs: List[QAPair]) -> List[QAResultSummary]:
        sem = asyncio.Semaphore(self.batch_size)

        async def _bounded_process(qa: QAPair, mid: str):
            async with sem:
                return await self.process_qa_pair(qa, mid)

        tasks: List[asyncio.Task] = []
        for qa in qa_pairs:
            for mid in self.models:
                tasks.append(asyncio.create_task(_bounded_process(qa, mid)))

        if not tasks:
            return []

        results: List[QAResultSummary] = []

        with tqdm(total=len(tasks), desc="Running SCID-F experiment") as bar:
            for task in asyncio.as_completed(tasks):
                try:
                    r = await task
                    if not isinstance(r, BaseException):
                        results.append(cast(QAResultSummary, r))
                except Exception:
                    # Errors are already captured in process_qa_pair as QAResultSummary.error
                    # This except is just for safety; we don't re-raise here.
                    pass
                finally:
                    bar.update(1)

        return results
