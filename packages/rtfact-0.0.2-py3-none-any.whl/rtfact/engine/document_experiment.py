"""
High-level experiment pipeline for running SCID-F from raw documents.

This module wraps the typical end-to-end flow:

    documents  →  LLM-based QA generation  →  PgVector ingestion
               →  SCID-F (ScidfOrchestrator)  →  CSV + per-sample folders

It is intentionally generic: a "document" can be any long-form text.
"""

from __future__ import annotations

import random
from pathlib import Path
from typing import Dict, Iterable, Optional

from pydantic import BaseModel, Field

from ..core import LLMProvider, ContextProvider
from ..cache import CacheConfig
from ..data.unstructured import RawDocument, generate_qa_for_documents
from .result_exporter import ResultExporter
from .scidf_orchestrator import QAResultSummaryList


class DocumentScidfConfig(BaseModel):
    """
    Configuration for DocumentScidfExperiment.

    This groups together the many tunable parameters of the
    document → QA → SCID-F pipeline so that callers can pass a single
    config object instead of a long list of keyword arguments.
    """

    run_name: str = "documents"
    chunk_size: int = 1200
    qa_per_chunk: int = 3
    temperature: float = 0.0
    concurrency: int = 8
    k_max: int = 10
    k_min: int = 2
    batch_size: int = 4
    sample_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    output_root: Path | str | None = None
    cache_config: CacheConfig | None = None
    judge_model_id: str | None = None


class DocumentScidfExperiment:
    """
    High-level wrapper that runs SCID-F starting from raw documents.

    Steps:
      1) Generate QA pairs from the documents using an LLM.
      2) Persist documents and QA pairs into PgVector.
      3) Run ScidfOrchestrator over the generated QA pairs.
      4) Optionally subsample QA pairs via sample_rate.
      5) Export results (CSV + folders) under the configured output_root.
    """

    def __init__(
        self,
        context: ContextProvider,
        llm: LLMProvider,
        *,
        config: DocumentScidfConfig,
    ):
        self._context = context
        self.llm = llm

        self.config = config
        self.run_name = config.run_name
        self.chunk_size = config.chunk_size
        self.qa_per_chunk = config.qa_per_chunk
        self.temperature = config.temperature
        self.concurrency = config.concurrency
        self.k_max = config.k_max
        self.k_min = config.k_min
        self.batch_size = config.batch_size
        self.sample_rate = config.sample_rate

        # Normalise output_root to a Path with a sensible default.
        if config.output_root is None:
            self.output_root = Path("result")
        else:
            self.output_root = Path(config.output_root)

        # Cache and judge configuration
        self.cache_config = config.cache_config or CacheConfig(enabled=True)
        self.judge_model_id = config.judge_model_id
        self._exporter = ResultExporter(
            output_root=self.output_root,
            run_name=self.run_name,
            csv_name="scidf_ab_documents.csv",
        )

    async def run(
        self,
        documents: Iterable[RawDocument],
        models: Optional[Dict[str, LLMProvider]] = None,
    ) -> QAResultSummaryList:
        docs_list = list(documents)
        if not docs_list:
            return QAResultSummaryList([])

        # 1) Generate QA pairs from documents
        qa_pairs = await generate_qa_for_documents(
            docs_list,
            llm=self.llm,
            chunk_size=self.chunk_size,
            qa_per_chunk=self.qa_per_chunk,
            temperature=self.temperature,
            concurrency=self.concurrency,
        )
        if not qa_pairs:
            return QAResultSummaryList([])

        # Optionally subsample QA pairs before persistence / evaluation.
        if 0.0 < self.sample_rate < 1.0 and qa_pairs:
            sample_size = int(len(qa_pairs) * self.sample_rate)
            if sample_size <= 0 and len(qa_pairs) > 0:
                sample_size = 1
            if 0 < sample_size < len(qa_pairs):
                qa_pairs = random.sample(qa_pairs, sample_size)

        # 2) Persist docs and QA pairs to backing store via context; align QA ids.
        if not hasattr(self._context, "persist_documents_and_qa"):
            raise TypeError(
                "DocumentScidfExperiment requires a context object that "
                "implements `persist_documents_and_qa(documents, qa_pairs, "
                "document_source=...)` in addition to `get_context`."
            )
        qa_pairs = await self._context.persist_documents_and_qa(  # type: ignore[attr-defined]
            documents,
            qa_pairs,
            document_source="documents",
        )

        # 3) Run SCID-F via the high-level evaluation runner
        if models is None:
            models = {"subject": self.llm}

        # Lazy import to avoid circular imports at module initialization time.
        from ..evaluation.runner import ScidfEvaluationConfig, HallucinationEvaluator

        eval_config = ScidfEvaluationConfig(
            k_max=self.k_max,
            k_min=self.k_min,
            batch_size=self.batch_size,
            judge_model_id=self.judge_model_id,
            # We rely on DocumentScidfExperiment.sample_rate for QA subsampling,
            # so sample_size remains None here.
        )
        evaluator = HallucinationEvaluator(
            context=self._context,
            config=eval_config,
            cache_config=self.cache_config,
        )

        results, _metrics = await evaluator.run_on_qa_pairs(qa_pairs, models=models)

        # 4) Export results
        self._exporter.export(results)
        return QAResultSummaryList(results)
