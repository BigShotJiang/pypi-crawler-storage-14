import instructor
import openai
from pydantic import BaseModel
from typing import Optional
from ..core import LLMProvider


class OpenAIProvider(LLMProvider):
    """OpenAI implementation of LLMProvider.

    Notes:
        - Plain text generation uses the raw AsyncOpenAI client.
        - Structured generation uses an instructor-wrapped client that
          requires a ``response_model``.
    """

    def __init__(
        self, api_key: str, base_url: Optional[str] = None, model: str = "gpt-4o"
    ):
        # Raw OpenAI-compatible async client
        self.client = openai.AsyncOpenAI(api_key=api_key, base_url=base_url)
        # Instructor-wrapped client for structured outputs
        self.structured_client = instructor.from_openai(self.client)
        self.model = model

    async def generate(self, prompt: str, **kwargs) -> str:
        """Generate free-form text from a prompt."""
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        return response.choices[0].message.content  # type: ignore[return-value]

    async def generate_structured(
        self, prompt: str, response_model: type[BaseModel], **kwargs
    ) -> BaseModel:
        """Generate structured output parsed into a Pydantic model."""
        return await self.structured_client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            response_model=response_model,
            **kwargs,
        )
