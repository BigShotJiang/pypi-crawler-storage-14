import itertools as t

def new_list():
    """Boş bir liste oluşturur ve döndürür."""
    return []

def start_list(lst):
    """Kullanıcı girdisine göre kombinasyonlar oluşturur ve dosyaya yazar."""
    chars = input("ListC Hakkında Bilgi: ") 
    try:
        min_len = int(input("ListC Hakkında Sayı Gir En Az: ")) 
        max_len = int(input("ListC Hakkında Sayı Gir En Fazla: ")) 
    except ValueError:
        print("Lütfen geçerli bir sayı girin!")
        return None

    output = input("Output File: ")

    if output == "" or output is None:
        file_name = chars + ".txt"
    else:
        file_name = output

    if min_len > max_len:
        print("Maksimum tekrar, minimum tekrardan büyük olmalıdır!")
        return None

    with open(file_name, 'w') as file:
        for i in range(min_len, max_len + 1):
            for a in t.product(chars, repeat=i):
                s = "".join(a)
                file.write(s + "\n")

    print(f"Dosyanız kaydedildi: {file_name}")
    return file_name
