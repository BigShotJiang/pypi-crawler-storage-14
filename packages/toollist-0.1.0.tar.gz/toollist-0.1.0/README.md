# toollist
Python package to create lists and generate character combinations.

## Kullanım
```python
import toollist as tl

my_list = tl.new_list()
result_file = tl.start_list(my_list)
```
