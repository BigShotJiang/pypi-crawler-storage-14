"""CLI module main entry point."""

from .main import main

if __name__ == '__main__':
    main()