"""
Greb pipeline module.

Provides tools and utilities for intelligent code search.
Client-side only: grep, read, AST analysis.
GPU reranking is done server-side.
"""

from .base import (
    FileSpan,
    CandidateMatch,
)

from .grep import GrepTool
from .read import ReadTool
from .code_analyzer import FastCodeAnalyzer, CodeReference
from .search_context import SearchContext

__all__ = [
    # Base classes
    'FileSpan',
    'CandidateMatch',
    # Tools
    'GrepTool',
    'ReadTool',
    'FastCodeAnalyzer',
    'CodeReference',
    'SearchContext',
]
