class UnsupportedOperation(Exception):
    pass
