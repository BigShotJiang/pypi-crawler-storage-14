# sage_setup: distribution = sagemath-tdlib

from sage.all__sagemath_tdlib import *
