"""Tests for gocam.indexing module."""
from pathlib import Path

INPUT_DIR = Path(__file__).parent / "input"
