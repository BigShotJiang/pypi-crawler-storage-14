from gocam._version import __version__ as __version__
