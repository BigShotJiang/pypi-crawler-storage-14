from dataclasses import dataclass


@dataclass
class GraphTranslator:
    pass