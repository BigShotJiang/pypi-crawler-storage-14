# Examples of use of gocam

This folder contains example data conforming to gocam

The source for these is in [src/data](../src/data/examples)
