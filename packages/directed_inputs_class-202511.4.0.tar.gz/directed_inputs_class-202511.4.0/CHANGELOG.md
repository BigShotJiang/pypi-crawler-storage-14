# CHANGELOG

<!-- version list -->

## v202511.4.0 (2025-11-29)

### Features

- Add FSC fleet coordination support
  ([`7a046b6`](https://github.com/jbcom/jbcom-control-center/commit/7a046b6578cd2216542e893d61ecd501d8305a8c))


## v202511.3.0 (2025-11-28)

- Initial Release
