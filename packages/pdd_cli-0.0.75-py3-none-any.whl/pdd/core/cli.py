"""
Main CLI class and entry point logic.
"""
import os
import click
from typing import Any, List, Optional, Tuple

from .. import DEFAULT_STRENGTH, __version__, DEFAULT_TIME
from ..auto_update import auto_update
from ..construct_paths import list_available_contexts
from ..install_completion import get_local_pdd_path
from .errors import console, handle_error, clear_core_dump_errors
from .utils import _first_pending_command, _should_show_onboarding_reminder
from .dump import _write_core_dump

class PDDCLI(click.Group):
    """Custom Click Group that adds a Generate Suite section to root help."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        self.format_usage(ctx, formatter)
        with formatter.section("Generate Suite (related commands)"):
            formatter.write_dl([
                ("generate", "Create runnable code from a prompt file."),
                ("test",     "Generate or enhance unit tests for a code file."),
                ("example",  "Generate example code from a prompt and implementation."),
            ])
        formatter.write(
            "Use `pdd generate --help` for details on this suite and common global flags.\n"
        )

        self.format_options(ctx, formatter)

    def invoke(self, ctx):
        exception_to_handle = None
        try:
            result = super().invoke(ctx)
        except SystemExit as e:
            # Let successful exits (code 0) pass through, but handle error exits
            if e.code == 0 or e.code is None:
                raise
            # Convert error exit to exception for proper error handling
            error_msg = f"Process exited with code {e.code}"
            exception_to_handle = RuntimeError(error_msg)
        except click.exceptions.Exit as e:
            # Let successful Click exits pass through, but handle error exits
            if e.exit_code == 0:
                raise
            # Convert error exit to exception
            error_msg = f"Command exited with code {e.exit_code}"
            exception_to_handle = RuntimeError(error_msg)
        except Exception as e:
            # Handle all other exceptions
            exception_to_handle = e
        else:
            # No exception, return normally
            return result

        # Exception handling for all non-success cases
        # Figure out quiet mode if possible
        quiet = False
        try:
            if isinstance(ctx.obj, dict):
                quiet = ctx.obj.get("quiet", False)
        except Exception:
            pass

        # Centralized error reporting
        handle_error(exception_to_handle, _first_pending_command(ctx) or "unknown", quiet)

        # Make sure ctx.obj exists so _write_core_dump can read flags
        if ctx.obj is None:
            ctx.obj = {}

        # Force a core dump even though result_callback won't run
        try:
            normalized_results: List[Any] = []
            # Try to get invoked_subcommands from multiple sources
            invoked_subcommands = getattr(ctx, "invoked_subcommands", []) or []
            if not invoked_subcommands and isinstance(ctx.obj, dict):
                invoked_subcommands = ctx.obj.get("invoked_subcommands", []) or []
            total_cost = 0.0
            _write_core_dump(ctx, normalized_results, invoked_subcommands, total_cost)
        except Exception:
            # Never let core-dump logic itself crash the CLI
            pass

        # Exit with appropriate code: 2 for usage errors, 1 for other errors
        exit_code = 2 if isinstance(exception_to_handle, click.UsageError) else 1
        ctx.exit(exit_code)


# --- Main CLI Group ---
@click.group(
    cls=PDDCLI,
    invoke_without_command=True,
    help="PDD (Prompt-Driven Development) Command Line Interface.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite existing files without asking for confirmation (commonly used with 'sync' to update generated outputs).",
)
@click.option(
    "--strength",
    type=click.FloatRange(0.0, 1.0),
    default=DEFAULT_STRENGTH,
    show_default=True,
    help="Set the strength of the AI model (0.0 to 1.0).",
)
@click.option(
    "--temperature",
    type=click.FloatRange(0.0, 2.0), # Allow higher temperatures if needed
    default=0.0,
    show_default=True,
    help="Set the temperature of the AI model.",
)
@click.option(
    "--time",
    type=click.FloatRange(0.0, 1.0),
    default=None,
    show_default=True,
    help="Controls reasoning allocation for LLMs (0.0-1.0). Uses DEFAULT_TIME if None.",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Increase output verbosity for more detailed information.",
)
@click.option(
    "--quiet",
    is_flag=True,
    default=False,
    help="Decrease output verbosity for minimal information.",
)
@click.option(
    "--output-cost",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Enable cost tracking and output a CSV file with usage details.",
)
@click.option(
    "--review-examples",
    is_flag=True,
    default=False,
    help="Review and optionally exclude few-shot examples before command execution.",
)
@click.option(
    "--local",
    is_flag=True,
    default=False,
    help="Run commands locally instead of in the cloud.",
)
@click.option(
    "--context",
    "context_override",
    type=str,
    default=None,
    help="Override automatic context detection and use the specified .pddrc context.",
)
@click.option(
    "--list-contexts",
    "list_contexts",
    is_flag=True,
    default=False,
    help="List available contexts from .pddrc and exit.",
)
@click.option(
    "--core-dump",
    "core_dump",
    is_flag=True,
    default=False,
    help="Write a JSON core dump for this run into .pdd/core_dumps (for bug reports).",
)
@click.version_option(version=__version__, package_name="pdd-cli")
@click.pass_context
def cli(
    ctx: click.Context,
    force: bool,
    strength: float,
    temperature: float,
    verbose: bool,
    quiet: bool,
    output_cost: Optional[str],
    review_examples: bool,
    local: bool,
    time: Optional[float], # Type hint is Optional[float]
    context_override: Optional[str],
    list_contexts: bool,
    core_dump: bool,
):
    """
    Main entry point for the PDD CLI. Handles global options and initializes context.
    """
    # Ensure PDD_PATH is set before any commands run
    get_local_pdd_path()

    # Reset per-run error buffer and store core_dump flag
    clear_core_dump_errors()

    ctx.ensure_object(dict)
    ctx.obj["force"] = force
    ctx.obj["strength"] = strength
    ctx.obj["temperature"] = temperature
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet
    ctx.obj["output_cost"] = output_cost
    ctx.obj["review_examples"] = review_examples
    ctx.obj["local"] = local
    # Use DEFAULT_TIME if time is not provided
    ctx.obj["time"] = time if time is not None else DEFAULT_TIME
    # Persist context override for downstream calls
    ctx.obj["context"] = context_override
    ctx.obj["core_dump"] = core_dump

    # Suppress verbose if quiet is enabled
    if quiet:
        ctx.obj["verbose"] = False

    # Warn users who have not completed interactive setup unless they are running it now
    if _should_show_onboarding_reminder(ctx):
        console.print(
            "[warning]Complete onboarding with `pdd setup` to install tab completion and configure API keys.[/warning]"
        )
        ctx.obj["reminder_shown"] = True

    # If --list-contexts is provided, print and exit before any other actions
    if list_contexts:
        try:
            names = list_available_contexts()
        except Exception as exc:
            # Surface config errors as usage errors
            raise click.UsageError(f"Failed to load .pddrc: {exc}")
        # Print one per line; avoid Rich formatting for portability
        for name in names:
            click.echo(name)
        ctx.exit(0)

    # Optional early validation for --context
    if context_override:
        try:
            names = list_available_contexts()
        except Exception as exc:
            # If .pddrc is malformed, propagate as usage error
            raise click.UsageError(f"Failed to load .pddrc: {exc}")
        if context_override not in names:
            raise click.UsageError(
                f"Unknown context '{context_override}'. Available contexts: {', '.join(names)}"
            )

    # Perform auto-update check unless disabled
    if os.getenv("PDD_AUTO_UPDATE", "true").lower() != "false":
        try:
            if not quiet:
                console.print("[info]Checking for updates...[/info]")
            # Removed quiet=quiet argument as it caused TypeError
            auto_update()
        except Exception as exception:  # Using more descriptive name
            if not quiet:
                console.print(
                    f"[warning]Auto-update check failed:[/warning] {exception}", 
                    style="warning"
                )

    # If no subcommands were provided, show help and exit gracefully
    if ctx.invoked_subcommand is None and not ctx.protected_args:
        if not quiet:
            console.print("[info]Run `pdd --help` for usage or `pdd setup` to finish onboarding.[/info]")
        click.echo(ctx.get_help())
        ctx.exit(0)

# --- Result Callback for Command Execution Summary ---
@cli.result_callback()
@click.pass_context
def process_commands(ctx: click.Context, results: List[Optional[Tuple[Any, float, str]]], **kwargs):
    """
    Processes results returned by executed commands and prints a summary.
    Receives a list of tuples, typically (result, cost, model_name),
    or None from each command function.
    """
    total_cost = 0.0
    # Get Click's invoked subcommands attribute first
    invoked_subcommands = getattr(ctx, 'invoked_subcommands', [])
    # If Click didn't provide it (common in real runs), fall back to the list
    # tracked on ctx.obj by @track_cost — but avoid doing this during pytest
    # so unit tests continue to assert the "Unknown Command" output.
    if not invoked_subcommands:
        import os as _os
        if not _os.environ.get('PYTEST_CURRENT_TEST'):
            try:
                if ctx.obj and isinstance(ctx.obj, dict):
                    invoked_subcommands = ctx.obj.get('invoked_subcommands', []) or []
            except Exception:
                invoked_subcommands = []
    # Normalize results: Click may pass a single return value (e.g., a 3-tuple)
    # rather than a list of results. Wrap single 3-tuples so we treat them as
    # one step in the summary instead of three separate items.
    if results is None:
        normalized_results: List[Any] = []
    elif isinstance(results, list):
        normalized_results = results
    elif isinstance(results, tuple) and len(results) == 3:
        normalized_results = [results]
    else:
        # Fallback: wrap any other scalar/iterable as a single result
        normalized_results = [results]

    num_commands = len(invoked_subcommands)
    num_results = len(normalized_results)  # Number of results actually received

    if not ctx.obj.get("quiet"):
        console.print("\n[info]--- Command Execution Summary ---[/info]")

    for i, result_tuple in enumerate(normalized_results):
        # Use the retrieved subcommand name (might be "Unknown Command X" in tests)
        command_name = invoked_subcommands[i] if i < num_commands else f"Unknown Command {i+1}"

        # Check if the command failed (returned None)
        if result_tuple is None:
            if not ctx.obj.get("quiet"):
                # Check if it was install_completion (which normally returns None)
                if command_name == "install_completion":
                    console.print(f"  [info]Step {i+1} ({command_name}):[/info] Command completed.")
                # If command name is unknown, and it might be install_completion which prints its own status
                elif command_name.startswith("Unknown Command"):
                    console.print(f"  [info]Step {i+1} ({command_name}):[/info] Command executed (see output above for status details).")
                # Check if it was preprocess (which returns a dummy tuple on success)
                # This case handles actual failure for preprocess
                elif command_name == "preprocess":
                    console.print(f"  [error]Step {i+1} ({command_name}):[/error] Command failed.")
                else:
                    console.print(f"  [error]Step {i+1} ({command_name}):[/error] Command failed.")
        # Check if the result is the expected tuple structure from @track_cost or preprocess success
        elif isinstance(result_tuple, tuple) and len(result_tuple) == 3:
            _result_data, cost, model_name = result_tuple
            total_cost += cost
            if not ctx.obj.get("quiet"):
                # Special handling for preprocess success message (check actual command name)
                actual_command_name = invoked_subcommands[i] if i < num_commands else None # Get actual name if possible
                if actual_command_name == "preprocess" and cost == 0.0 and model_name == "local":
                    console.print(f"  [info]Step {i+1} ({command_name}):[/info] Command completed (local).")
                else:
                    # Generic output using potentially "Unknown Command" name
                    console.print(f"  [info]Step {i+1} ({command_name}):[/info] Cost: ${cost:.6f}, Model: {model_name}")
        else:
            # Handle unexpected return types if necessary
            if not ctx.obj.get("quiet"):
                # Provide more detail on the unexpected type
                console.print(f"  [warning]Step {i+1} ({command_name}):[/warning] Unexpected result format: {type(result_tuple).__name__} - {str(result_tuple)[:50]}...")


    if not ctx.obj.get("quiet"):
        # Only print total cost if at least one command potentially contributed cost
        if any(res is not None and isinstance(res, tuple) and len(res) == 3 for res in normalized_results):
            console.print(f"[info]Total Estimated Cost:[/info] ${total_cost:.6f}")
        # Indicate if the chain might have been incomplete due to errors
        if num_results < num_commands and not all(res is None for res in results): # Avoid printing if all failed
            console.print("[warning]Note: Chain may have terminated early due to errors.[/warning]")
        console.print("[info]-------------------------------------[/info]")

    # Finally, write a core dump if requested
    _write_core_dump(ctx, normalized_results, invoked_subcommands, total_cost)
    fatal = ctx.obj.get("_fatal_exception") if isinstance(ctx.obj, dict) else None
    if fatal:
        ctx.exit(1)
