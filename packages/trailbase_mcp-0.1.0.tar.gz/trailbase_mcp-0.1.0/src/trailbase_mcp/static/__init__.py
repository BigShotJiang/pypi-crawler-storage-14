"""Static files for TrailBase MCP Server"""

