"""Pydantic models for TrailBase MCP"""

