"""配置管理工具"""

import json
from typing import Any

from mcp.types import Tool, TextContent

from trailbase_mcp.client.client import TrailBaseClient


def get_config_tools() -> list[Tool]:
    """获取配置相关工具"""
    return [
        Tool(
            name="config.get",
            description="获取配置",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="config.update",
            description="更新配置",
            inputSchema={
                "type": "object",
                "properties": {
                    "patch": {
                        "type": "object",
                        "description": "配置补丁（server, auth, email, storage, system_jobs, record_apis）",
                    },
                },
                "required": ["patch"],
            },
        ),
    ]


async def handle_config_get(
    client: TrailBaseClient,
) -> list[TextContent]:
    """处理 config.get 工具调用"""
    try:
        result = client.http.get("/api/_admin/config")
        return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}, ensure_ascii=False))]


async def handle_config_update(
    client: TrailBaseClient,
    patch: dict[str, Any],
) -> list[TextContent]:
    """处理 config.update 工具调用"""
    try:
        # 只允许更新特定字段
        allowed_keys = {"server", "auth", "email", "storage", "system_jobs", "record_apis"}
        filtered_patch = {k: v for k, v in patch.items() if k in allowed_keys}

        result = client.http.post("/api/_admin/config", json=filtered_patch)
        return [TextContent(type="text", text=json.dumps({"ok": True}, ensure_ascii=False))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}, ensure_ascii=False))]

