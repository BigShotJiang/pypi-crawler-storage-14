"""工具注册表 - 统一管理所有工具的处理器"""

from collections.abc import Awaitable, Callable
from typing import Any

from mcp.types import TextContent

from trailbase_mcp.client.client import TrailBaseClient


# 工具处理器类型定义（异步函数）
ToolHandler = Callable[[TrailBaseClient, dict[str, Any]], Awaitable[list[TextContent]]]


class ToolRegistry:
    """工具注册表 - 管理所有工具的处理器"""

    def __init__(self):
        self._handlers: dict[str, ToolHandler] = {}

    def register(self, name: str, handler: ToolHandler) -> None:
        """注册工具处理器"""
        self._handlers[name] = handler

    def get_handler(self, name: str) -> ToolHandler | None:
        """获取工具处理器"""
        return self._handlers.get(name)

    def has_handler(self, name: str) -> bool:
        """检查是否有对应的处理器"""
        return name in self._handlers

    def list_tool_names(self) -> list[str]:
        """列出所有已注册的工具名称"""
        return list(self._handlers.keys())


# 全局工具注册表实例
_registry = ToolRegistry()


def get_registry() -> ToolRegistry:
    """获取全局工具注册表"""
    return _registry


def register_tool(name: str, handler: ToolHandler) -> None:
    """注册工具处理器（便捷函数）"""
    _registry.register(name, handler)

