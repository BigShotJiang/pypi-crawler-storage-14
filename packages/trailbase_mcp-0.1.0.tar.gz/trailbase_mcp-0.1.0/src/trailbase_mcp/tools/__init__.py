"""MCP tools for TrailBase"""

from typing import Any

from trailbase_mcp.tools import auth, config, db, files, info, jobs, logs, records, schema, tx
from trailbase_mcp.tools.registry import register_tool

# 延迟导入以避免循环依赖
__all__ = [
    "auth",
    "config",
    "db",
    "files",
    "info",
    "jobs",
    "logs",
    "records",
    "schema",
    "tx",
    "register_all_tools",
]


def register_all_tools():
    """注册所有工具到注册表"""
    # DB 工具
    async def handle_db_query(client, args: dict[str, Any]):
        return await db.handle_db_query(
            client,
            args.get("sql", ""),
            args.get("params"),
            args.get("timeout_ms"),
            args.get("tx"),
        )

    async def handle_db_explain(client, args: dict[str, Any]):
        return await db.handle_db_explain(client, args.get("sql", ""))

    async def handle_db_tables(client, args: dict[str, Any]):
        return await db.handle_db_tables(client, args.get("like"))

    async def handle_db_table_info(client, args: dict[str, Any]):
        return await db.handle_db_table_info(client, args.get("table", ""))

    register_tool("db.query", handle_db_query)
    register_tool("db.explain", handle_db_explain)
    register_tool("db.tables", handle_db_tables)
    register_tool("db.table_info", handle_db_table_info)

    # Records 工具
    async def handle_records_list(client, args: dict[str, Any]):
        return await records.handle_records_list(
            client,
            args.get("api", ""),
            args.get("filter"),
            args.get("order_by"),
            args.get("limit"),
            args.get("page_token"),
            args.get("expand"),
        )

    async def handle_records_get(client, args: dict[str, Any]):
        return await records.handle_records_get(client, args.get("api", ""), args.get("id", ""))

    async def handle_records_create(client, args: dict[str, Any]):
        return await records.handle_records_create(client, args.get("api", ""), args.get("data", {}))

    async def handle_records_update(client, args: dict[str, Any]):
        return await records.handle_records_update(
            client,
            args.get("api", ""),
            args.get("id", ""),
            args.get("data", {}),
        )

    async def handle_records_delete(client, args: dict[str, Any]):
        return await records.handle_records_delete(client, args.get("api", ""), args.get("id", ""))

    async def handle_records_schema(client, args: dict[str, Any]):
        return await records.handle_records_schema(client, args.get("api", ""))

    async def handle_records_apis(client, args: dict[str, Any]):
        return await records.handle_records_apis(client)

    register_tool("records.list", handle_records_list)
    register_tool("records.get", handle_records_get)
    register_tool("records.create", handle_records_create)
    register_tool("records.update", handle_records_update)
    register_tool("records.delete", handle_records_delete)
    register_tool("records.schema", handle_records_schema)
    register_tool("records.apis", handle_records_apis)

    # Auth 工具
    async def handle_auth_users_list(client, args: dict[str, Any]):
        return await auth.handle_auth_users_list(
            client,
            args.get("query"),
            args.get("page_size"),
            args.get("page_token"),
        )

    async def handle_auth_users_create(client, args: dict[str, Any]):
        return await auth.handle_auth_users_create(
            client,
            args.get("email", ""),
            args.get("password"),
            args.get("verified"),
        )

    async def handle_auth_users_update(client, args: dict[str, Any]):
        return await auth.handle_auth_users_update(
            client, args.get("id_or_email", ""), args.get("patch", {})
        )

    async def handle_auth_users_delete(client, args: dict[str, Any]):
        return await auth.handle_auth_users_delete(client, args.get("id_or_email", ""))

    async def handle_auth_sessions_invalidate(client, args: dict[str, Any]):
        return await auth.handle_auth_sessions_invalidate(client, args.get("id_or_email", ""))

    async def handle_auth_token_mint(client, args: dict[str, Any]):
        return await auth.handle_auth_token_mint(client, args.get("id_or_email", ""), args.get("ttl_sec"))

    register_tool("auth.users.list", handle_auth_users_list)
    register_tool("auth.users.create", handle_auth_users_create)
    register_tool("auth.users.update", handle_auth_users_update)
    register_tool("auth.users.delete", handle_auth_users_delete)
    register_tool("auth.sessions.invalidate", handle_auth_sessions_invalidate)
    register_tool("auth.token.mint", handle_auth_token_mint)

    # Schema 工具
    async def handle_schema_tables(client, args: dict[str, Any]):
        return await schema.handle_schema_tables(client)

    async def handle_schema_create_table(client, args: dict[str, Any]):
        return await schema.handle_schema_create_table(
            client,
            args.get("table", ""),
            args.get("columns", []),
            args.get("if_not_exists"),
        )

    async def handle_schema_alter_table(client, args: dict[str, Any]):
        return await schema.handle_schema_alter_table(
            client,
            args.get("table", ""),
            args.get("add_columns"),
            args.get("drop_columns"),
            args.get("rename"),
        )

    async def handle_schema_drop_table(client, args: dict[str, Any]):
        return await schema.handle_schema_drop_table(client, args.get("table", ""), args.get("if_exists"))

    async def handle_schema_indexes(client, args: dict[str, Any]):
        return await schema.handle_schema_indexes(client, args.get("table", ""))

    register_tool("schema.tables", handle_schema_tables)
    register_tool("schema.create_table", handle_schema_create_table)
    register_tool("schema.alter_table", handle_schema_alter_table)
    register_tool("schema.drop_table", handle_schema_drop_table)
    register_tool("schema.indexes", handle_schema_indexes)

    # Jobs 工具
    async def handle_jobs_list(client, args: dict[str, Any]):
        return await jobs.handle_jobs_list(client)

    async def handle_jobs_update_schedule(client, args: dict[str, Any]):
        return await jobs.handle_jobs_update_schedule(client, args.get("id", ""), args.get("schedule", ""))

    async def handle_jobs_enable(client, args: dict[str, Any]):
        return await jobs.handle_jobs_enable(client, args.get("id", ""))

    async def handle_jobs_disable(client, args: dict[str, Any]):
        return await jobs.handle_jobs_disable(client, args.get("id", ""))

    async def handle_jobs_run_now(client, args: dict[str, Any]):
        return await jobs.handle_jobs_run_now(client, args.get("id", ""))

    async def handle_jobs_history(client, args: dict[str, Any]):
        return await jobs.handle_jobs_history(
            client, args.get("id", ""), args.get("limit"), args.get("before")
        )

    register_tool("jobs.list", handle_jobs_list)
    register_tool("jobs.update_schedule", handle_jobs_update_schedule)
    register_tool("jobs.enable", handle_jobs_enable)
    register_tool("jobs.disable", handle_jobs_disable)
    register_tool("jobs.run_now", handle_jobs_run_now)
    register_tool("jobs.history", handle_jobs_history)

    # Logs 工具
    async def handle_logs_query(client, args: dict[str, Any]):
        return await logs.handle_logs_query(
            client,
            args.get("level"),
            args.get("route"),
            args.get("user"),
            args.get("since"),
            args.get("until"),
            args.get("limit"),
        )

    async def handle_logs_tail(client, args: dict[str, Any]):
        return await logs.handle_logs_tail(client, args.get("level_min"), args.get("follow"))

    async def handle_metrics_overview(client, args: dict[str, Any]):
        return await logs.handle_metrics_overview(client)

    register_tool("logs.query", handle_logs_query)
    register_tool("logs.tail", handle_logs_tail)
    register_tool("metrics.overview", handle_metrics_overview)

    # Config 工具
    async def handle_config_get(client, args: dict[str, Any]):
        return await config.handle_config_get(client)

    async def handle_config_update(client, args: dict[str, Any]):
        return await config.handle_config_update(client, args.get("patch", {}))

    register_tool("config.get", handle_config_get)
    register_tool("config.update", handle_config_update)

    # Files 工具
    async def handle_files_list(client, args: dict[str, Any]):
        return await files.handle_files_list(
            client, args.get("prefix"), args.get("limit"), args.get("page_token")
        )

    async def handle_files_delete(client, args: dict[str, Any]):
        return await files.handle_files_delete(client, args.get("path", ""))

    async def handle_files_meta(client, args: dict[str, Any]):
        return await files.handle_files_meta(client, args.get("path", ""))

    register_tool("files.list", handle_files_list)
    register_tool("files.delete", handle_files_delete)
    register_tool("files.meta", handle_files_meta)

    # Transaction 工具
    async def handle_tx_execute(client, args: dict[str, Any]):
        return await tx.handle_tx_execute(client, args.get("steps", []), args.get("stop_on_error"))

    register_tool("tx.execute", handle_tx_execute)

    # Info 工具
    async def handle_info_version(client, args: dict[str, Any]):
        return await info.handle_info_version(client)

    register_tool("info.version", handle_info_version)
