"""统一异常处理"""


class TrailBaseError(Exception):
    """TrailBase 基础异常"""

    def __init__(self, code: str, message: str, details: dict | None = None):
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class TrailBaseHTTPError(TrailBaseError):
    """HTTP 请求错误"""

    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        details: dict | None = None,
    ):
        self.status_code = status_code
        super().__init__(code, message, details)

