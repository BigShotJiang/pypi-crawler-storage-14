"""TrailBase HTTP client"""

from trailbase_mcp.client.client import TrailBaseClient

__all__ = ["TrailBaseClient"]

