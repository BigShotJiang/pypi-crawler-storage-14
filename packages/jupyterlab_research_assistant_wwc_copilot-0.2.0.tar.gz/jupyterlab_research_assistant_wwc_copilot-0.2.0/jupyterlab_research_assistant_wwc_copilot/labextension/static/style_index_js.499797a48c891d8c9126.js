"use strict";
(self["webpackChunkjupyterlab_research_assistant_wwc_copilot"] = self["webpackChunkjupyterlab_research_assistant_wwc_copilot"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

/* Research Library Panel Styles */
.jp-WWCExtension-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 8px;
}

.jp-WWCExtension-tabs {
  display: flex;
  border-bottom: 1px solid var(--jp-border-color1);
  margin-bottom: 8px;
}

.jp-WWCExtension-tab {
  background: none;
  border: none;
  padding: 8px 16px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  transition:
    color 0.15s ease-in-out,
    background-color 0.15s ease-in-out,
    border-bottom-color 0.15s ease-in-out;
  font-weight: 500;
  min-width: fit-content;
}

.jp-WWCExtension-tab:hover {
  color: var(--jp-content-font-color1);
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-tab.active {
  color: var(--jp-content-font-color1);
  border-bottom-color: var(--jp-brand-color1);
  font-weight: 600;

  /* Prevent layout shift by maintaining consistent spacing */
  letter-spacing: -0.01em;
}

.jp-WWCExtension-content {
  flex: 1;
  overflow-y: auto;
}

/* Search Bar Styles */
.jp-WWCExtension-search-bar {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.jp-WWCExtension-input {
  flex: 1;
  min-width: 150px;
  padding: 12px 16px;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size2);
  background-color: var(--jp-layout-color0);
  color: var(--jp-content-font-color1);
  transition:
    border-color 0.2s ease-in-out,
    outline 0.2s ease-in-out;
}

.jp-WWCExtension-input:focus {
  outline: 1px solid var(--jp-brand-color1);
  outline-offset: -1px;
}

.jp-WWCExtension-select {
  padding: 6px 8px;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size1);
  background-color: var(--jp-layout-color0);
  color: var(--jp-content-font-color1);
  cursor: pointer;
  transition:
    border-color 0.2s ease-in-out,
    outline 0.2s ease-in-out;
}

.jp-WWCExtension-select:focus {
  outline: 1px solid var(--jp-brand-color1);
  outline-offset: -1px;
}

.jp-WWCExtension-button {
  padding: 12px 24px;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  font-size: var(--jp-ui-font-size2);
  cursor: pointer;
  font-weight: 500;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.jp-WWCExtension-button.jp-mod-muted:not(:disabled) {
  background-color: var(--jp-brand-color3);
  opacity: 0.7;
}

.jp-WWCExtension-button.jp-mod-muted-secondary:not(:disabled) {
  background-color: var(--jp-accent-color1);
  opacity: 0.7;
}

.jp-WWCExtension-button.jp-mod-muted-gray:not(:disabled) {
  background-color: var(--jp-layout-color3);
  color: var(--jp-ui-inverse-font-color1);
  border-color: var(--jp-border-color2);
}

.jp-WWCExtension-button:hover:not(:disabled) {
  background-color: var(--jp-brand-color0);
}

/* Paper Card Styles */
.jp-WWCExtension-papers {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.jp-WWCExtension-paper-card {
  padding: 12px;
  margin-bottom: 8px;
  background-color: var(--jp-layout-color0);
  border-left: 4px solid var(--jp-brand-color2);
  border-radius: var(--jp-border-radius);
  box-shadow: var(--jp-elevation-z1);
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-paper-card:hover {
  cursor: pointer;
  background-color: var(--jp-layout-color2);
  box-shadow: var(--jp-elevation-z4);
  transform: translateY(-2px);
}

.jp-WWCExtension-paper-card.jp-mod-selected {
  border-left-color: var(--jp-brand-color1);
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-paper-title {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
  line-height: 1.4;
}

.jp-WWCExtension-paper-title.jp-mod-clickable {
  cursor: pointer;
}

.jp-WWCExtension-paper-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 8px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  line-height: 1.5;
}

.jp-WWCExtension-paper-authors,
.jp-WWCExtension-paper-year,
.jp-WWCExtension-paper-citations {
  margin: 0;
}

.jp-WWCExtension-paper-abstract {
  margin: 8px 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  line-height: 1.5;
}

.jp-WWCExtension-paper-status {
  margin: 8px 0;
}

.jp-WWCExtension-pdf-badge {
  display: inline-block;
  padding: 4px 8px;
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  line-height: 1.4;
}

.jp-WWCExtension-pdf-badge.jp-mod-has-pdf {
  background-color: var(--jp-success-color3);
  color: var(--jp-success-color0);
  border: 1px solid var(--jp-success-color1);
  text-decoration: underline;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-pdf-badge.jp-mod-has-pdf:hover {
  background-color: var(--jp-success-color2);
  color: var(--jp-success-color0);
  border-color: var(--jp-success-color0);
  text-decoration: underline;
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgb(0 0 0 / 10%);
}

.jp-WWCExtension-pdf-badge.jp-mod-metadata-only {
  background-color: var(--jp-warn-color3);
  color: var(--jp-warn-color0);
  border: 1px solid var(--jp-warn-color1);
}

.jp-WWCExtension-pdf-badge.jp-mod-open-access {
  background-color: var(--jp-info-color3);
  color: var(--jp-info-color0);
  border: 1px solid var(--jp-info-color1);
  text-decoration: underline;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-pdf-badge.jp-mod-open-access:hover {
  background-color: var(--jp-info-color2);
  color: var(--jp-info-color0);
  border-color: var(--jp-info-color0);
  text-decoration: underline;
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgb(0 0 0 / 10%);
}

.jp-WWCExtension-paper-actions {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}

.jp-WWCExtension-import-button {
  margin-top: 8px;
  width: 100%;
}

/* Error and Loading Styles */
.jp-WWCExtension-error {
  padding: 8px;
  margin-bottom: 16px;
  background-color: var(--jp-error-color3);
  color: var(--jp-ui-inverse-font-color1);
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

.jp-WWCExtension-loading {
  padding: 16px;
  text-align: center;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

.jp-WWCExtension-empty {
  padding: 32px;
  text-align: center;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

/* Discovery and Library Tab Specific Styles */
.jp-WWCExtension-discovery,
.jp-WWCExtension-library {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.jp-WWCExtension-results {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

/* Skeleton Loaders */
.jp-WWCExtension-skeleton {
  padding: 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  background-color: var(--jp-layout-color1);
  animation: pulse 1.5s ease-in-out infinite;
}

.jp-WWCExtension-skeleton-title {
  height: 20px;
  width: 80%;
  background-color: var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  margin-bottom: 8px;
}

.jp-WWCExtension-skeleton-line {
  height: 14px;
  width: 100%;
  background-color: var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  margin-bottom: 4px;
}

.jp-WWCExtension-skeleton-line.short {
  width: 60%;
}

@keyframes pulse {
  0%,
  100% {
    opacity: 1;
  }

  50% {
    opacity: 0.6;
  }
}

/* PDF Upload Section */
.jp-WWCExtension-upload-section {
  margin-bottom: 16px;
  padding: 8px;
  border: 1px dashed var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  text-align: center;
}

.jp-WWCExtension-upload-section label {
  margin: 0;
}

/* Detail View Styles */

.jp-WWCExtension-detail-view {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 8px;
}

.jp-WWCExtension-detail-header {
  margin-bottom: 16px;
}

.jp-WWCExtension-close-button {
  float: right;
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: var(--jp-content-font-color2);
  padding: 0;
  width: 32px;
  height: 32px;
  line-height: 32px;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-close-button:hover {
  color: var(--jp-content-font-color1);
  background-color: var(--jp-layout-color2);
  border-radius: var(--jp-border-radius);
}

.jp-WWCExtension-detail-header h2 {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-detail-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
  line-height: 1.5;
}

/* Tab containers */
.jp-WWCExtension-detail-tabs {
  display: flex;
  border-bottom: 1px solid var(--jp-border-color1);
  margin-bottom: 16px;
  gap: 8px;
}

.jp-WWCExtension-synthesis-tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  border-bottom: 1px solid var(--jp-border-color1);
}

/* Tab buttons - specificity (0,2,0) - all grouped together */
.jp-WWCExtension-detail-tabs button {
  background: none;
  border: none;
  padding: 8px 16px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-synthesis-tabs button {
  background: none;
  border: none;
  padding: 8px 16px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  transition:
    color 0.15s ease-in-out,
    background-color 0.15s ease-in-out,
    border-bottom-color 0.15s ease-in-out;
  font-weight: 500;
  min-width: fit-content;
}

/* Tab button hover states - specificity (0,2,1) - all grouped together */
.jp-WWCExtension-detail-tabs button:hover {
  color: var(--jp-content-font-color1);
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-synthesis-tabs button:hover {
  color: var(--jp-content-font-color1);
  background-color: var(--jp-layout-color2);
}

/* Tab button active/selected states - higher specificity - all grouped together */
.jp-WWCExtension-detail-tabs button.active {
  color: var(--jp-content-font-color1);
  border-bottom-color: var(--jp-brand-color1);
  font-weight: 600;
}

.jp-WWCExtension-synthesis-tabs button.jp-WWCExtension-tab-active {
  color: var(--jp-brand-color1) !important;
  border-bottom: 3px solid var(--jp-brand-color1) !important;
  font-weight: 700 !important;
  background-color: var(--jp-brand-color3) !important;
  border-radius: var(--jp-border-radius) var(--jp-border-radius) 0 0;

  /* Prevent layout shift by maintaining consistent spacing */
  letter-spacing: -0.01em;
}

.jp-WWCExtension-detail-content {
  flex: 0 1 auto;
  overflow-y: auto;
  min-height: 0;
}

.jp-WWCExtension-detail-section {
  margin-bottom: 24px;
}

.jp-WWCExtension-detail-section h3 {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-detail-section p {
  margin: 0 0 8px;
  color: var(--jp-content-font-color2);
  line-height: 1.6;
}

.jp-WWCExtension-detail-section table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 8px;
}

.jp-WWCExtension-detail-section th,
.jp-WWCExtension-detail-section td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid var(--jp-border-color1);
}

.jp-WWCExtension-detail-section th {
  font-weight: 600;
  color: var(--jp-content-font-color1);
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-detail-actions {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid var(--jp-border-color1);
}

/* Multi-Select Styles */
.jp-WWCExtension-paper-card-selected {
  border-left-color: var(--jp-brand-color1);
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-paper-card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}

.jp-WWCExtension-paper-card-checkbox {
  flex-shrink: 0;
}

.jp-WWCExtension-checkbox {
  cursor: pointer;
}

.jp-WWCExtension-view-details-button {
  font-size: 1.1em;
  padding: 8px 16px;
  margin-left: auto;
}

.jp-WWCExtension-synthesis-button-container {
  margin-bottom: 16px;
  padding: 8px;
  text-align: center;
}

.jp-WWCExtension-synthesis-button {
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  font-weight: 600;
  padding: 10px 20px;
}

/* WWC Co-Pilot Styles */
.jp-WWCExtension-wwc {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 16px;
  padding-bottom: 32px;
  overflow-y: auto;
}

.jp-WWCExtension-wwc-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--jp-border-color1);
}

.jp-WWCExtension-wwc-header h2 {
  margin: 0;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-close {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: var(--jp-content-font-color2);
  padding: 0;
  width: 32px;
  height: 32px;
  line-height: 32px;
  border-radius: var(--jp-border-radius);
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-close:hover {
  color: var(--jp-content-font-color1);
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-wwc-judgments {
  margin-bottom: 24px;
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z1);
}

.jp-WWCExtension-wwc-judgments h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-wwc-field {
  margin-bottom: 16px;
}

.jp-WWCExtension-wwc-field label {
  display: block;
  margin-bottom: 6px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 500;
  color: var(--jp-content-font-color1);
  line-height: 1.5;
}

.jp-WWCExtension-wwc-field select {
  width: 100%;
  padding: 6px 8px;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size1);
  background-color: var(--jp-layout-color0);
  color: var(--jp-content-font-color1);
  cursor: pointer;
  transition:
    border-color 0.2s ease-in-out,
    outline 0.2s ease-in-out;
}

.jp-WWCExtension-wwc-field select:focus {
  outline: 1px solid var(--jp-brand-color1);
  outline-offset: -1px;
}

.jp-WWCExtension-wwc-help {
  margin: 4px 0 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
  font-style: italic;
  line-height: 1.5;
}

.jp-WWCExtension-wwc-results {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z1);
}

.jp-WWCExtension-wwc-results h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-wwc-rating {
  padding: 12px;
  border-radius: var(--jp-border-radius);
  margin-bottom: 16px;
  text-align: center;
  color: white;
}

.jp-WWCExtension-wwc-rating.jp-type-meets-standards {
  background-color: var(--jp-success-color1);
}

.jp-WWCExtension-wwc-rating.jp-type-meets-with-reservations {
  background-color: var(--jp-warn-color1);
}

.jp-WWCExtension-wwc-rating.jp-type-does-not-meet {
  background-color: var(--jp-error-color1);
}

.jp-WWCExtension-wwc-section {
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jp-WWCExtension-wwc-section:last-child {
  border-bottom: none;
}

.jp-WWCExtension-wwc-section h4 {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-wwc-section p {
  margin: 4px 0;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

.jp-WWCExtension-wwc-justification {
  margin-top: 16px;
}

.jp-WWCExtension-wwc-justification h4 {
  margin: 0 0 8px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-wwc-justification ul {
  margin: 0;
  padding-left: 20px;
  color: var(--jp-content-font-color2);
  line-height: 1.5;
}

.jp-WWCExtension-wwc-justification li {
  margin-bottom: 4px;
}

/* Synthesis Workbench Styles */
.jp-WWCExtension-synthesis {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 16px;
  overflow-y: auto;
}

.jp-WWCExtension-synthesis-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--jp-border-color1);
}

.jp-WWCExtension-synthesis-header h2 {
  margin: 0;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-synthesis-actions {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 24px;
}

.jp-WWCExtension-synthesis-actions-row {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.jp-WWCExtension-synthesis-content {
  flex: 1;
  overflow-y: auto;
}

.jp-WWCExtension-synthesis-empty {
  padding: 32px 32px 48px;
  text-align: center;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

.jp-WWCExtension-synthesis-empty h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
}

.jp-WWCExtension-synthesis-empty p {
  margin: 12px 0;
  text-align: left;
}

.jp-WWCExtension-synthesis-empty ul {
  margin: 12px 0;
  padding-left: 24px;
  text-align: left;
}

.jp-WWCExtension-synthesis-empty li {
  margin: 8px 0;
}

.jp-WWCExtension-synthesis-empty-note {
  margin-top: 24px;
  padding-bottom: 24px;
}

/* Meta-Analysis View Styles */
.jp-WWCExtension-meta-analysis {
  display: flex;
  flex-direction: column;
  gap: 24px;
  padding-bottom: 16px;
}

.jp-WWCExtension-meta-analysis h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

/* Stat Cards Grid Layout */
.jp-WWCExtension-meta-analysis-summary {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-meta-analysis-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background-color: var(--jp-layout-color0);
  border-radius: var(--jp-border-radius);
  box-shadow: var(--jp-elevation-z1);
  text-align: center;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-meta-analysis-stat:hover {
  box-shadow: var(--jp-elevation-z2);
  transform: translateY(-2px);
}

.jp-WWCExtension-meta-analysis-stat strong {
  color: var(--jp-content-font-color1);
  font-weight: 600;
  font-size: var(--jp-ui-font-size0);
  text-transform: uppercase;
  margin-bottom: 8px;
  line-height: 1.4;
}

.jp-WWCExtension-meta-analysis-stat span {
  color: var(--jp-brand-color1);
  font-family: var(--jp-code-font-family);
  font-size: 28px;
  font-weight: 700;
  line-height: 1.2;
}

.jp-WWCExtension-meta-analysis-plot {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-plot-image {
  max-width: 100%;
  height: auto;
}

.jp-WWCExtension-meta-analysis-plot h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-meta-analysis-studies {
  padding: 16px;
  padding-bottom: 32px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-meta-analysis-studies h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--jp-ui-font-size1);
}

.jp-WWCExtension-table thead {
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-table th {
  padding: 8px 12px;
  text-align: left;
  font-weight: 600;
  color: var(--jp-content-font-color1);
  border-bottom: 2px solid var(--jp-border-color1);
  line-height: 1.4;
  white-space: nowrap;
}

.jp-WWCExtension-table td {
  padding: 8px 12px;
  color: var(--jp-content-font-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  word-wrap: break-word;
  overflow-wrap: break-word;
  line-height: 1.5;
  transition: background-color 0.2s ease-in-out;
}

.jp-WWCExtension-table td:first-child {
  max-width: 250px;
  min-width: 150px;
  word-break: break-word;
}

.jp-WWCExtension-table tbody tr:hover {
  background-color: var(--jp-layout-color2);
}

/* Conflict View Styles */
.jp-WWCExtension-conflicts {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.jp-WWCExtension-conflicts h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-conflicts-summary {
  padding: 12px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z1);
}

.jp-WWCExtension-conflicts-summary p {
  margin: 0;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

.jp-WWCExtension-conflicts-empty {
  padding: 32px;
  text-align: center;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size1);
  line-height: 1.5;
}

.jp-WWCExtension-conflicts-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.jp-WWCExtension-conflict-item {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  border-left: 4px solid var(--jp-error-color1);
  box-shadow: var(--jp-elevation-z1);
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-conflict-item:hover {
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-conflict-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jp-WWCExtension-conflict-header strong {
  color: var(--jp-content-font-color1);
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  line-height: 1.3;
}

.jp-WWCExtension-conflict-header span {
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size0);
  font-family: var(--jp-code-font-family);
  line-height: 1.4;
}

.jp-WWCExtension-conflict-papers {
  margin-bottom: 12px;
  padding: 8px;
  background-color: var(--jp-layout-color2);
  border-radius: var(--jp-border-radius);
}

.jp-WWCExtension-conflict-papers div {
  margin: 4px 0;
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size0);
  line-height: 1.5;
}

.jp-WWCExtension-conflict-papers strong {
  color: var(--jp-content-font-color1);
  font-weight: 600;
}

.jp-WWCExtension-conflict-findings {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.jp-WWCExtension-conflict-findings div {
  padding: 8px;
  background-color: var(--jp-layout-color2);
  border-radius: var(--jp-border-radius);
  color: var(--jp-content-font-color2);
  font-size: var(--jp-ui-font-size0);
  line-height: 1.5;
}

.jp-WWCExtension-conflict-findings strong {
  color: var(--jp-content-font-color1);
  font-weight: 600;
  display: block;
  margin-bottom: 4px;
}

.jp-WWCExtension-conflict-explanation {
  margin-top: 16px;
  padding: 12px;
  background-color: var(--jp-layout-color2);
  border-radius: var(--jp-border-radius);
  border-left: 3px solid var(--jp-brand-color1);
}

.jp-WWCExtension-conflict-explanation strong {
  color: var(--jp-content-font-color1);
  font-weight: 600;
  display: block;
  margin-bottom: 8px;
  font-size: var(--jp-ui-font-size1);
}

.jp-WWCExtension-conflict-explanation p {
  margin: 8px 0;
  line-height: 1.6;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
}

.jp-WWCExtension-conflict-explanation ul {
  margin: 8px 0 8px 20px;
  padding-left: 0;
}

.jp-WWCExtension-conflict-explanation li {
  margin: 6px 0;
  line-height: 1.5;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
}

/* WWC Info Boxes Container */
.jp-WWCExtension-wwc-info-container {
  margin: 16px 0 24px;
  display: flex;
  flex-direction: column;
  gap: 0; /* No gap between boxes when stacked */
}

/* Always-visible informational box */
.jp-WWCExtension-wwc-info-box {
  padding: 16px;
  background-color: var(--jp-info-color3);
  border: 2px solid var(--jp-info-color1);
  border-radius: var(--jp-border-radius);
  border-left-width: 4px;
  width: 100%;
}

/* Warning box - only shows when data is missing */
.jp-WWCExtension-wwc-warning-box {
  padding: 16px;
  background-color: var(--jp-warn-color3);
  border: 2px solid var(--jp-warn-color1);
  border-radius: var(--jp-border-radius);
  border-left-width: 4px;
  width: 100%;
}

/* When info box is followed by warning box, connect them seamlessly */
.jp-WWCExtension-wwc-info-box + .jp-WWCExtension-wwc-warning-box {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  margin-top: 0;
}

/* When warning follows info, remove bottom radius from info box */
.jp-WWCExtension-wwc-info-box:has(+ .jp-WWCExtension-wwc-warning-box) {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  margin-bottom: 0;
}

/* Shared content styling */
.jp-WWCExtension-wwc-info-content,
.jp-WWCExtension-wwc-warning-content {
  color: var(--jp-content-font-color1);
}

.jp-WWCExtension-wwc-info-content strong {
  color: var(--jp-info-color0);
  font-weight: 600;
  display: block;
  margin-bottom: 8px;
  font-size: var(--jp-ui-font-size1);
}

.jp-WWCExtension-wwc-warning-content strong {
  color: var(--jp-warn-color0);
  font-weight: 600;
  display: block;
  margin-bottom: 8px;
  font-size: var(--jp-ui-font-size1);
}

.jp-WWCExtension-wwc-info-content p,
.jp-WWCExtension-wwc-warning-content p {
  margin: 8px 0;
  line-height: 1.6;
  font-size: var(--jp-ui-font-size1);
}

.jp-WWCExtension-wwc-warning-content ul {
  margin: 8px 0 8px 20px;
  padding-left: 0;
}

.jp-WWCExtension-wwc-warning-content li {
  margin: 6px 0;
  line-height: 1.5;
}

.jp-WWCExtension-wwc-info-content code,
.jp-WWCExtension-wwc-warning-content code {
  background-color: var(--jp-layout-color2);
  padding: 2px 6px;
  border-radius: 3px;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-ui-font-size0);
}

/* WWC Wizard Progress Indicator */
.jp-WWCExtension-wwc-progress {
  margin-bottom: 24px;
}

.jp-WWCExtension-wwc-progress-bar {
  height: 4px;
  background-color: var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  margin-bottom: 16px;
  overflow: hidden;
}

.jp-WWCExtension-wwc-progress-fill {
  height: 100%;
  background-color: var(--jp-brand-color1);
  transition: width 0.3s ease;
}

.jp-WWCExtension-wwc-steps {
  display: flex;
  justify-content: space-between;
  gap: 8px;
}

.jp-WWCExtension-step {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 8px;
  background: none;
  border: 2px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-step:hover {
  background-color: var(--jp-layout-color2);
}

.jp-WWCExtension-step.active {
  border-color: var(--jp-brand-color1);
  background-color: var(--jp-brand-color3);
}

.jp-WWCExtension-step.completed {
  border-color: var(--jp-success-color1);
  background-color: var(--jp-success-color3);
}

.jp-WWCExtension-step .step-number {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background-color: var(--jp-border-color2);
  color: var(--jp-content-font-color2);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  margin-bottom: 4px;
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-step.active .step-number {
  background-color: var(--jp-brand-color1);
  color: white;
}

.jp-WWCExtension-step.completed .step-number {
  background-color: var(--jp-success-color1);
  color: white;
}

.jp-WWCExtension-step .step-label {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
  text-align: center;
  line-height: 1.4;
}

.jp-WWCExtension-wwc-navigation {
  display: flex;
  justify-content: space-between;
  margin-top: 24px;
  margin-bottom: 32px;
  padding-top: 16px;
  border-top: 1px solid var(--jp-border-color1);
}

.jp-WWCExtension-wwc-step-content {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z1);
}

.jp-WWCExtension-wwc-step-content h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

/* Subgroup Analysis Styles */
.jp-WWCExtension-subgroup-analysis {
  display: flex;
  flex-direction: column;
  gap: 24px;
  padding-bottom: 32px;
}

.jp-WWCExtension-subgroup-analysis h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-subgroup-overall {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-subgroup-overall h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-subgroup-results {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.jp-WWCExtension-subgroup-results h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-subgroup-item {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z1);
  transition: all 0.2s ease-in-out;
}

.jp-WWCExtension-subgroup-item:hover {
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-subgroup-item h5 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-subgroup-controls {
  display: flex;
  gap: 8px;
  align-items: center;
}

/* Bias Assessment Styles */
.jp-WWCExtension-bias-assessment {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.jp-WWCExtension-bias-assessment h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-eggers-test {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  align-items: start;
}

.jp-WWCExtension-eggers-test h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
  grid-column: 1 / -1;
}

.jp-WWCExtension-eggers-interpretation {
  grid-column: 1 / -1;
  margin-top: 8px;
  padding-top: 16px;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-WWCExtension-funnel-plot {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-funnel-plot h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

/* Sensitivity Analysis Styles */
.jp-WWCExtension-sensitivity-analysis {
  padding-bottom: 32px;
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.jp-WWCExtension-sensitivity-analysis h3 {
  margin: 0 0 16px;
  font-size: var(--jp-ui-font-size2);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-sensitivity-overall,
.jp-WWCExtension-sensitivity-loo,
.jp-WWCExtension-sensitivity-influence {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  box-shadow: var(--jp-elevation-z2);
}

.jp-WWCExtension-sensitivity-overall h4,
.jp-WWCExtension-sensitivity-loo h4,
.jp-WWCExtension-sensitivity-influence h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

/* Findings Preview Styles */
.jp-WWCExtension-findings-preview {
  padding: 16px;
  background-color: var(--jp-layout-color1);
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  margin-bottom: 16px;
  box-shadow: var(--jp-elevation-z1);
}

.jp-WWCExtension-findings-preview h4 {
  margin: 0 0 12px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-content-font-color1);
  line-height: 1.3;
}

.jp-WWCExtension-finding-item {
  margin-bottom: 16px;
  padding: 12px;
  background-color: var(--jp-layout-color2);
  border-radius: var(--jp-border-radius);
}

.jp-WWCExtension-finding-item strong {
  color: var(--jp-content-font-color1);
  font-weight: 600;
  display: block;
  margin-bottom: 8px;
  line-height: 1.3;
}

.jp-WWCExtension-finding-item ul {
  margin: 0;
  padding-left: 20px;
  color: var(--jp-content-font-color2);
}

.jp-WWCExtension-finding-item li {
  margin-bottom: 4px;
  line-height: 1.5;
}

/* WWC Badge Styles */
.jp-WWCExtension-wwcBadge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 8px;
  text-transform: uppercase;
  line-height: 1.4;
}

.jp-WWCExtension-wwcBadge.jp-type-meets-standards {
  background-color: var(--jp-success-color2);
  color: var(--jp-success-color0);
}

.jp-WWCExtension-wwcBadge.jp-type-meets-with-reservations {
  background-color: var(--jp-warn-color2);
  color: var(--jp-warn-color0);
}

.jp-WWCExtension-wwcBadge.jp-type-does-not-meet {
  background-color: var(--jp-error-color2);
  color: var(--jp-error-color0);
}

.jp-WWCExtension-wwcBadge.jp-type-not-assessed {
  background-color: var(--jp-layout-color3);
  color: var(--jp-ui-font-color2);
}

/* Utility Classes */
.jp-WWCExtension-file-input {
  display: none;
}

.jp-mod-file-upload-label {
  display: inline-block;
  cursor: pointer;
}

.jp-mod-high-difference {
  color: var(--jp-error-color1);
}
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;;AAED,kCAAkC;AAClC;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,YAAY;AACd;;AAEA;EACE,aAAa;EACb,gDAAgD;EAChD,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,iBAAiB;EACjB,eAAe;EACf,oCAAoC;EACpC,oCAAoC;EACpC,kCAAkC;EAClC;;;yCAGuC;EACvC,gBAAgB;EAChB,sBAAsB;AACxB;;AAEA;EACE,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,2CAA2C;EAC3C,gBAAgB;;EAEhB,2DAA2D;EAC3D,uBAAuB;AACzB;;AAEA;EACE,OAAO;EACP,gBAAgB;AAClB;;AAEA,sBAAsB;AACtB;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;EACnB,eAAe;AACjB;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,kBAAkB;EAClB,yCAAyC;EACzC,sCAAsC;EACtC,kCAAkC;EAClC,yCAAyC;EACzC,oCAAoC;EACpC;;4BAE0B;AAC5B;;AAEA;EACE,yCAAyC;EACzC,oBAAoB;AACtB;;AAEA;EACE,gBAAgB;EAChB,yCAAyC;EACzC,sCAAsC;EACtC,kCAAkC;EAClC,yCAAyC;EACzC,oCAAoC;EACpC,eAAe;EACf;;4BAE0B;AAC5B;;AAEA;EACE,yCAAyC;EACzC,oBAAoB;AACtB;;AAEA;EACE,kBAAkB;EAClB,yCAAyC;EACzC,sCAAsC;EACtC,wCAAwC;EACxC,uCAAuC;EACvC,kCAAkC;EAClC,eAAe;EACf,gBAAgB;EAChB,gCAAgC;AAClC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,yCAAyC;EACzC,YAAY;AACd;;AAEA;EACE,yCAAyC;EACzC,uCAAuC;EACvC,qCAAqC;AACvC;;AAEA;EACE,wCAAwC;AAC1C;;AAEA,sBAAsB;AACtB;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,yCAAyC;EACzC,6CAA6C;EAC7C,sCAAsC;EACtC,kCAAkC;EAClC,gCAAgC;AAClC;;AAEA;EACE,eAAe;EACf,yCAAyC;EACzC,kCAAkC;EAClC,2BAA2B;AAC7B;;AAEA;EACE,yCAAyC;EACzC,yCAAyC;AAC3C;;AAEA;EACE,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,kBAAkB;EAClB,kCAAkC;EAClC,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;;;EAGE,SAAS;AACX;;AAEA;EACE,aAAa;EACb,kCAAkC;EAClC,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,sCAAsC;EACtC,kCAAkC;EAClC,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA;EACE,0CAA0C;EAC1C,+BAA+B;EAC/B,0CAA0C;EAC1C,0BAA0B;EAC1B,eAAe;EACf,gCAAgC;AAClC;;AAEA;EACE,0CAA0C;EAC1C,+BAA+B;EAC/B,sCAAsC;EACtC,0BAA0B;EAC1B,2BAA2B;EAC3B,sCAAsC;AACxC;;AAEA;EACE,uCAAuC;EACvC,4BAA4B;EAC5B,uCAAuC;AACzC;;AAEA;EACE,uCAAuC;EACvC,4BAA4B;EAC5B,uCAAuC;EACvC,0BAA0B;EAC1B,eAAe;EACf,gCAAgC;AAClC;;AAEA;EACE,uCAAuC;EACvC,4BAA4B;EAC5B,mCAAmC;EACnC,0BAA0B;EAC1B,2BAA2B;EAC3B,sCAAsC;AACxC;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,eAAe;EACf,WAAW;AACb;;AAEA,6BAA6B;AAC7B;EACE,YAAY;EACZ,mBAAmB;EACnB,wCAAwC;EACxC,uCAAuC;EACvC,sCAAsC;EACtC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA,8CAA8C;AAC9C;;EAEE,aAAa;EACb,sBAAsB;EACtB,YAAY;AACd;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA,qBAAqB;AACrB;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,0CAA0C;AAC5C;;AAEA;EACE,YAAY;EACZ,UAAU;EACV,yCAAyC;EACzC,sCAAsC;EACtC,kBAAkB;AACpB;;AAEA;EACE,YAAY;EACZ,WAAW;EACX,yCAAyC;EACzC,sCAAsC;EACtC,kBAAkB;AACpB;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE;;IAEE,UAAU;EACZ;;EAEA;IACE,YAAY;EACd;AACF;;AAEA,uBAAuB;AACvB;EACE,mBAAmB;EACnB,YAAY;EACZ,0CAA0C;EAC1C,sCAAsC;EACtC,kBAAkB;AACpB;;AAEA;EACE,SAAS;AACX;;AAEA,uBAAuB;;AAEvB;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,YAAY;AACd;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,YAAY;EACZ,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,oCAAoC;EACpC,UAAU;EACV,WAAW;EACX,YAAY;EACZ,iBAAiB;EACjB,gCAAgC;AAClC;;AAEA;EACE,oCAAoC;EACpC,yCAAyC;EACzC,sCAAsC;AACxC;;AAEA;EACE,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,kCAAkC;EAClC,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA,mBAAmB;AACnB;EACE,aAAa;EACb,gDAAgD;EAChD,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;EACnB,gDAAgD;AAClD;;AAEA,6DAA6D;AAC7D;EACE,gBAAgB;EAChB,YAAY;EACZ,iBAAiB;EACjB,eAAe;EACf,oCAAoC;EACpC,oCAAoC;EACpC,kCAAkC;EAClC,gCAAgC;AAClC;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,iBAAiB;EACjB,eAAe;EACf,oCAAoC;EACpC,oCAAoC;EACpC,kCAAkC;EAClC;;;yCAGuC;EACvC,gBAAgB;EAChB,sBAAsB;AACxB;;AAEA,yEAAyE;AACzE;EACE,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA,kFAAkF;AAClF;EACE,oCAAoC;EACpC,2CAA2C;EAC3C,gBAAgB;AAClB;;AAEA;EACE,wCAAwC;EACxC,0DAA0D;EAC1D,2BAA2B;EAC3B,mDAAmD;EACnD,kEAAkE;;EAElE,2DAA2D;EAC3D,uBAAuB;AACzB;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,aAAa;AACf;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,eAAe;EACf,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,yBAAyB;EACzB,eAAe;AACjB;;AAEA;;EAEE,YAAY;EACZ,gBAAgB;EAChB,gDAAgD;AAClD;;AAEA;EACE,gBAAgB;EAChB,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,6CAA6C;AAC/C;;AAEA,wBAAwB;AACxB;EACE,yCAAyC;EACzC,yCAAyC;AAC3C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,kBAAkB;AACpB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,iBAAiB;AACnB;;AAEA;EACE,mBAAmB;EACnB,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,wCAAwC;EACxC,uCAAuC;EACvC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA,wBAAwB;AACxB;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,aAAa;EACb,oBAAoB;EACpB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,mBAAmB;EACnB,oBAAoB;EACpB,gDAAgD;AAClD;;AAEA;EACE,SAAS;EACT,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,oCAAoC;EACpC,UAAU;EACV,WAAW;EACX,YAAY;EACZ,iBAAiB;EACjB,sCAAsC;EACtC,gCAAgC;AAClC;;AAEA;EACE,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA;EACE,mBAAmB;EACnB,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,gBAAgB;EAChB,yCAAyC;EACzC,sCAAsC;EACtC,kCAAkC;EAClC,yCAAyC;EACzC,oCAAoC;EACpC,eAAe;EACf;;4BAE0B;AAC5B;;AAEA;EACE,yCAAyC;EACzC,oBAAoB;AACtB;;AAEA;EACE,eAAe;EACf,kCAAkC;EAClC,oCAAoC;EACpC,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sCAAsC;EACtC,mBAAmB;EACnB,kBAAkB;EAClB,YAAY;AACd;;AAEA;EACE,0CAA0C;AAC5C;;AAEA;EACE,uCAAuC;AACzC;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,mBAAmB;EACnB,oBAAoB;EACpB,gDAAgD;AAClD;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,SAAS;EACT,kBAAkB;EAClB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;AACpB;;AAEA,+BAA+B;AAC/B;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,aAAa;EACb,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,mBAAmB;EACnB,oBAAoB;EACpB,gDAAgD;AAClD;;AAEA;EACE,SAAS;EACT,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;EACT,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,SAAS;EACT,eAAe;AACjB;;AAEA;EACE,OAAO;EACP,gBAAgB;AAClB;;AAEA;EACE,uBAAuB;EACvB,kBAAkB;EAClB,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;AACtC;;AAEA;EACE,cAAc;EACd,gBAAgB;AAClB;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,gBAAgB;EAChB,oBAAoB;AACtB;;AAEA,8BAA8B;AAC9B;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;EACT,oBAAoB;AACtB;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA,2BAA2B;AAC3B;EACE,aAAa;EACb,2DAA2D;EAC3D,SAAS;EACT,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,kCAAkC;EAClC,kBAAkB;EAClB,gCAAgC;AAClC;;AAEA;EACE,kCAAkC;EAClC,2BAA2B;AAC7B;;AAEA;EACE,oCAAoC;EACpC,gBAAgB;EAChB,kCAAkC;EAClC,yBAAyB;EACzB,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,6BAA6B;EAC7B,uCAAuC;EACvC,eAAe;EACf,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,eAAe;EACf,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,oBAAoB;EACpB,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,yBAAyB;EACzB,kCAAkC;AACpC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,iBAAiB;EACjB,gBAAgB;EAChB,gBAAgB;EAChB,oCAAoC;EACpC,gDAAgD;EAChD,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,iBAAiB;EACjB,oCAAoC;EACpC,gDAAgD;EAChD,qBAAqB;EACrB,yBAAyB;EACzB,gBAAgB;EAChB,6CAA6C;AAC/C;;AAEA;EACE,gBAAgB;EAChB,gBAAgB;EAChB,sBAAsB;AACxB;;AAEA;EACE,yCAAyC;AAC3C;;AAEA,yBAAyB;AACzB;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,SAAS;EACT,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,6CAA6C;EAC7C,kCAAkC;EAClC,gCAAgC;AAClC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,mBAAmB;EACnB,mBAAmB;EACnB,gDAAgD;AAClD;;AAEA;EACE,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA;EACE,oCAAoC;EACpC,kCAAkC;EAClC,uCAAuC;EACvC,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;EACnB,YAAY;EACZ,yCAAyC;EACzC,sCAAsC;AACxC;;AAEA;EACE,aAAa;EACb,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,YAAY;EACZ,yCAAyC;EACzC,sCAAsC;EACtC,oCAAoC;EACpC,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,oCAAoC;EACpC,gBAAgB;EAChB,cAAc;EACd,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,6CAA6C;AAC/C;;AAEA;EACE,oCAAoC;EACpC,gBAAgB;EAChB,cAAc;EACd,kBAAkB;EAClB,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,gBAAgB;EAChB,kCAAkC;EAClC,oCAAoC;AACtC;;AAEA;EACE,sBAAsB;EACtB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,gBAAgB;EAChB,kCAAkC;EAClC,oCAAoC;AACtC;;AAEA,6BAA6B;AAC7B;EACE,mBAAmB;EACnB,aAAa;EACb,sBAAsB;EACtB,MAAM,EAAE,sCAAsC;AAChD;;AAEA,qCAAqC;AACrC;EACE,aAAa;EACb,uCAAuC;EACvC,uCAAuC;EACvC,sCAAsC;EACtC,sBAAsB;EACtB,WAAW;AACb;;AAEA,kDAAkD;AAClD;EACE,aAAa;EACb,uCAAuC;EACvC,uCAAuC;EACvC,sCAAsC;EACtC,sBAAsB;EACtB,WAAW;AACb;;AAEA,sEAAsE;AACtE;EACE,yBAAyB;EACzB,0BAA0B;EAC1B,aAAa;AACf;;AAEA,kEAAkE;AAClE;EACE,4BAA4B;EAC5B,6BAA6B;EAC7B,gBAAgB;AAClB;;AAEA,2BAA2B;AAC3B;;EAEE,oCAAoC;AACtC;;AAEA;EACE,4BAA4B;EAC5B,gBAAgB;EAChB,cAAc;EACd,kBAAkB;EAClB,kCAAkC;AACpC;;AAEA;EACE,4BAA4B;EAC5B,gBAAgB;EAChB,cAAc;EACd,kBAAkB;EAClB,kCAAkC;AACpC;;AAEA;;EAEE,aAAa;EACb,gBAAgB;EAChB,kCAAkC;AACpC;;AAEA;EACE,sBAAsB;EACtB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,gBAAgB;AAClB;;AAEA;;EAEE,yCAAyC;EACzC,gBAAgB;EAChB,kBAAkB;EAClB,uCAAuC;EACvC,kCAAkC;AACpC;;AAEA,kCAAkC;AAClC;EACE,mBAAmB;AACrB;;AAEA;EACE,WAAW;EACX,yCAAyC;EACzC,sCAAsC;EACtC,mBAAmB;EACnB,gBAAgB;AAClB;;AAEA;EACE,YAAY;EACZ,wCAAwC;EACxC,2BAA2B;AAC7B;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,QAAQ;AACV;;AAEA;EACE,OAAO;EACP,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,YAAY;EACZ,gBAAgB;EAChB,yCAAyC;EACzC,sCAAsC;EACtC,eAAe;EACf,gCAAgC;AAClC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,wCAAwC;AAC1C;;AAEA;EACE,sCAAsC;EACtC,0CAA0C;AAC5C;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,yCAAyC;EACzC,oCAAoC;EACpC,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,gBAAgB;EAChB,kBAAkB;EAClB,gCAAgC;AAClC;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,0CAA0C;EAC1C,YAAY;AACd;;AAEA;EACE,kCAAkC;EAClC,oCAAoC;EACpC,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,gBAAgB;EAChB,mBAAmB;EACnB,iBAAiB;EACjB,6CAA6C;AAC/C;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA,6BAA6B;AAC7B;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;EACT,oBAAoB;AACtB;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;EAClC,gCAAgC;AAClC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;AACrB;;AAEA,2BAA2B;AAC3B;EACE,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;EAClC,aAAa;EACb,2DAA2D;EAC3D,SAAS;EACT,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;EACnB,eAAe;EACf,iBAAiB;EACjB,6CAA6C;AAC/C;;AAEA;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA,gCAAgC;AAChC;EACE,oBAAoB;EACpB,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;;;EAGE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,kCAAkC;AACpC;;AAEA;;;EAGE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA,4BAA4B;AAC5B;EACE,aAAa;EACb,yCAAyC;EACzC,sCAAsC;EACtC,yCAAyC;EACzC,mBAAmB;EACnB,kCAAkC;AACpC;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;EACnB,aAAa;EACb,yCAAyC;EACzC,sCAAsC;AACxC;;AAEA;EACE,oCAAoC;EACpC,gBAAgB;EAChB,cAAc;EACd,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA;EACE,SAAS;EACT,kBAAkB;EAClB,oCAAoC;AACtC;;AAEA;EACE,kBAAkB;EAClB,gBAAgB;AAClB;;AAEA,qBAAqB;AACrB;EACE,qBAAqB;EACrB,gBAAgB;EAChB,mBAAmB;EACnB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,yBAAyB;EACzB,gBAAgB;AAClB;;AAEA;EACE,0CAA0C;EAC1C,+BAA+B;AACjC;;AAEA;EACE,uCAAuC;EACvC,4BAA4B;AAC9B;;AAEA;EACE,wCAAwC;EACxC,6BAA6B;AAC/B;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA,oBAAoB;AACpB;EACE,aAAa;AACf;;AAEA;EACE,qBAAqB;EACrB,eAAe;AACjB;;AAEA;EACE,6BAA6B;AAC/B","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n/* Research Library Panel Styles */\n.jp-WWCExtension-panel {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  padding: 8px;\n}\n\n.jp-WWCExtension-tabs {\n  display: flex;\n  border-bottom: 1px solid var(--jp-border-color1);\n  margin-bottom: 8px;\n}\n\n.jp-WWCExtension-tab {\n  background: none;\n  border: none;\n  padding: 8px 16px;\n  cursor: pointer;\n  border-bottom: 2px solid transparent;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  transition:\n    color 0.15s ease-in-out,\n    background-color 0.15s ease-in-out,\n    border-bottom-color 0.15s ease-in-out;\n  font-weight: 500;\n  min-width: fit-content;\n}\n\n.jp-WWCExtension-tab:hover {\n  color: var(--jp-content-font-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-tab.active {\n  color: var(--jp-content-font-color1);\n  border-bottom-color: var(--jp-brand-color1);\n  font-weight: 600;\n\n  /* Prevent layout shift by maintaining consistent spacing */\n  letter-spacing: -0.01em;\n}\n\n.jp-WWCExtension-content {\n  flex: 1;\n  overflow-y: auto;\n}\n\n/* Search Bar Styles */\n.jp-WWCExtension-search-bar {\n  display: flex;\n  gap: 8px;\n  margin-bottom: 16px;\n  flex-wrap: wrap;\n}\n\n.jp-WWCExtension-input {\n  flex: 1;\n  min-width: 150px;\n  padding: 12px 16px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size2);\n  background-color: var(--jp-layout-color0);\n  color: var(--jp-content-font-color1);\n  transition:\n    border-color 0.2s ease-in-out,\n    outline 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-input:focus {\n  outline: 1px solid var(--jp-brand-color1);\n  outline-offset: -1px;\n}\n\n.jp-WWCExtension-select {\n  padding: 6px 8px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size1);\n  background-color: var(--jp-layout-color0);\n  color: var(--jp-content-font-color1);\n  cursor: pointer;\n  transition:\n    border-color 0.2s ease-in-out,\n    outline 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-select:focus {\n  outline: 1px solid var(--jp-brand-color1);\n  outline-offset: -1px;\n}\n\n.jp-WWCExtension-button {\n  padding: 12px 24px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  background-color: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n  font-size: var(--jp-ui-font-size2);\n  cursor: pointer;\n  font-weight: 500;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-button:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.jp-WWCExtension-button.jp-mod-muted:not(:disabled) {\n  background-color: var(--jp-brand-color3);\n  opacity: 0.7;\n}\n\n.jp-WWCExtension-button.jp-mod-muted-secondary:not(:disabled) {\n  background-color: var(--jp-accent-color1);\n  opacity: 0.7;\n}\n\n.jp-WWCExtension-button.jp-mod-muted-gray:not(:disabled) {\n  background-color: var(--jp-layout-color3);\n  color: var(--jp-ui-inverse-font-color1);\n  border-color: var(--jp-border-color2);\n}\n\n.jp-WWCExtension-button:hover:not(:disabled) {\n  background-color: var(--jp-brand-color0);\n}\n\n/* Paper Card Styles */\n.jp-WWCExtension-papers {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n\n.jp-WWCExtension-paper-card {\n  padding: 12px;\n  margin-bottom: 8px;\n  background-color: var(--jp-layout-color0);\n  border-left: 4px solid var(--jp-brand-color2);\n  border-radius: var(--jp-border-radius);\n  box-shadow: var(--jp-elevation-z1);\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-paper-card:hover {\n  cursor: pointer;\n  background-color: var(--jp-layout-color2);\n  box-shadow: var(--jp-elevation-z4);\n  transform: translateY(-2px);\n}\n\n.jp-WWCExtension-paper-card.jp-mod-selected {\n  border-left-color: var(--jp-brand-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-paper-title {\n  margin: 0 0 8px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-ui-font-color1);\n  line-height: 1.4;\n}\n\n.jp-WWCExtension-paper-title.jp-mod-clickable {\n  cursor: pointer;\n}\n\n.jp-WWCExtension-paper-meta {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  margin-bottom: 8px;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-ui-font-color2);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-paper-authors,\n.jp-WWCExtension-paper-year,\n.jp-WWCExtension-paper-citations {\n  margin: 0;\n}\n\n.jp-WWCExtension-paper-abstract {\n  margin: 8px 0;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-ui-font-color2);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-paper-status {\n  margin: 8px 0;\n}\n\n.jp-WWCExtension-pdf-badge {\n  display: inline-block;\n  padding: 4px 8px;\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 500;\n  line-height: 1.4;\n}\n\n.jp-WWCExtension-pdf-badge.jp-mod-has-pdf {\n  background-color: var(--jp-success-color3);\n  color: var(--jp-success-color0);\n  border: 1px solid var(--jp-success-color1);\n  text-decoration: underline;\n  cursor: pointer;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-pdf-badge.jp-mod-has-pdf:hover {\n  background-color: var(--jp-success-color2);\n  color: var(--jp-success-color0);\n  border-color: var(--jp-success-color0);\n  text-decoration: underline;\n  transform: translateY(-1px);\n  box-shadow: 0 2px 4px rgb(0 0 0 / 10%);\n}\n\n.jp-WWCExtension-pdf-badge.jp-mod-metadata-only {\n  background-color: var(--jp-warn-color3);\n  color: var(--jp-warn-color0);\n  border: 1px solid var(--jp-warn-color1);\n}\n\n.jp-WWCExtension-pdf-badge.jp-mod-open-access {\n  background-color: var(--jp-info-color3);\n  color: var(--jp-info-color0);\n  border: 1px solid var(--jp-info-color1);\n  text-decoration: underline;\n  cursor: pointer;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-pdf-badge.jp-mod-open-access:hover {\n  background-color: var(--jp-info-color2);\n  color: var(--jp-info-color0);\n  border-color: var(--jp-info-color0);\n  text-decoration: underline;\n  transform: translateY(-1px);\n  box-shadow: 0 2px 4px rgb(0 0 0 / 10%);\n}\n\n.jp-WWCExtension-paper-actions {\n  display: flex;\n  gap: 8px;\n  margin-top: 8px;\n}\n\n.jp-WWCExtension-import-button {\n  margin-top: 8px;\n  width: 100%;\n}\n\n/* Error and Loading Styles */\n.jp-WWCExtension-error {\n  padding: 8px;\n  margin-bottom: 16px;\n  background-color: var(--jp-error-color3);\n  color: var(--jp-ui-inverse-font-color1);\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-loading {\n  padding: 16px;\n  text-align: center;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-empty {\n  padding: 32px;\n  text-align: center;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n/* Discovery and Library Tab Specific Styles */\n.jp-WWCExtension-discovery,\n.jp-WWCExtension-library {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n\n.jp-WWCExtension-results {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n\n/* Skeleton Loaders */\n.jp-WWCExtension-skeleton {\n  padding: 12px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  background-color: var(--jp-layout-color1);\n  animation: pulse 1.5s ease-in-out infinite;\n}\n\n.jp-WWCExtension-skeleton-title {\n  height: 20px;\n  width: 80%;\n  background-color: var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  margin-bottom: 8px;\n}\n\n.jp-WWCExtension-skeleton-line {\n  height: 14px;\n  width: 100%;\n  background-color: var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  margin-bottom: 4px;\n}\n\n.jp-WWCExtension-skeleton-line.short {\n  width: 60%;\n}\n\n@keyframes pulse {\n  0%,\n  100% {\n    opacity: 1;\n  }\n\n  50% {\n    opacity: 0.6;\n  }\n}\n\n/* PDF Upload Section */\n.jp-WWCExtension-upload-section {\n  margin-bottom: 16px;\n  padding: 8px;\n  border: 1px dashed var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  text-align: center;\n}\n\n.jp-WWCExtension-upload-section label {\n  margin: 0;\n}\n\n/* Detail View Styles */\n\n.jp-WWCExtension-detail-view {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  padding: 8px;\n}\n\n.jp-WWCExtension-detail-header {\n  margin-bottom: 16px;\n}\n\n.jp-WWCExtension-close-button {\n  float: right;\n  background: none;\n  border: none;\n  font-size: 24px;\n  cursor: pointer;\n  color: var(--jp-content-font-color2);\n  padding: 0;\n  width: 32px;\n  height: 32px;\n  line-height: 32px;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-close-button:hover {\n  color: var(--jp-content-font-color1);\n  background-color: var(--jp-layout-color2);\n  border-radius: var(--jp-border-radius);\n}\n\n.jp-WWCExtension-detail-header h2 {\n  margin: 0 0 8px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-detail-meta {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n  line-height: 1.5;\n}\n\n/* Tab containers */\n.jp-WWCExtension-detail-tabs {\n  display: flex;\n  border-bottom: 1px solid var(--jp-border-color1);\n  margin-bottom: 16px;\n  gap: 8px;\n}\n\n.jp-WWCExtension-synthesis-tabs {\n  display: flex;\n  gap: 8px;\n  margin-bottom: 16px;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n/* Tab buttons - specificity (0,2,0) - all grouped together */\n.jp-WWCExtension-detail-tabs button {\n  background: none;\n  border: none;\n  padding: 8px 16px;\n  cursor: pointer;\n  border-bottom: 2px solid transparent;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-synthesis-tabs button {\n  background: none;\n  border: none;\n  padding: 8px 16px;\n  cursor: pointer;\n  border-bottom: 2px solid transparent;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  transition:\n    color 0.15s ease-in-out,\n    background-color 0.15s ease-in-out,\n    border-bottom-color 0.15s ease-in-out;\n  font-weight: 500;\n  min-width: fit-content;\n}\n\n/* Tab button hover states - specificity (0,2,1) - all grouped together */\n.jp-WWCExtension-detail-tabs button:hover {\n  color: var(--jp-content-font-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-synthesis-tabs button:hover {\n  color: var(--jp-content-font-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n/* Tab button active/selected states - higher specificity - all grouped together */\n.jp-WWCExtension-detail-tabs button.active {\n  color: var(--jp-content-font-color1);\n  border-bottom-color: var(--jp-brand-color1);\n  font-weight: 600;\n}\n\n.jp-WWCExtension-synthesis-tabs button.jp-WWCExtension-tab-active {\n  color: var(--jp-brand-color1) !important;\n  border-bottom: 3px solid var(--jp-brand-color1) !important;\n  font-weight: 700 !important;\n  background-color: var(--jp-brand-color3) !important;\n  border-radius: var(--jp-border-radius) var(--jp-border-radius) 0 0;\n\n  /* Prevent layout shift by maintaining consistent spacing */\n  letter-spacing: -0.01em;\n}\n\n.jp-WWCExtension-detail-content {\n  flex: 0 1 auto;\n  overflow-y: auto;\n  min-height: 0;\n}\n\n.jp-WWCExtension-detail-section {\n  margin-bottom: 24px;\n}\n\n.jp-WWCExtension-detail-section h3 {\n  margin: 0 0 8px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-detail-section p {\n  margin: 0 0 8px;\n  color: var(--jp-content-font-color2);\n  line-height: 1.6;\n}\n\n.jp-WWCExtension-detail-section table {\n  width: 100%;\n  border-collapse: collapse;\n  margin-top: 8px;\n}\n\n.jp-WWCExtension-detail-section th,\n.jp-WWCExtension-detail-section td {\n  padding: 8px;\n  text-align: left;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n.jp-WWCExtension-detail-section th {\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-detail-actions {\n  margin-top: 16px;\n  padding-top: 16px;\n  border-top: 1px solid var(--jp-border-color1);\n}\n\n/* Multi-Select Styles */\n.jp-WWCExtension-paper-card-selected {\n  border-left-color: var(--jp-brand-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-paper-card-header {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 8px;\n}\n\n.jp-WWCExtension-paper-card-checkbox {\n  flex-shrink: 0;\n}\n\n.jp-WWCExtension-checkbox {\n  cursor: pointer;\n}\n\n.jp-WWCExtension-view-details-button {\n  font-size: 1.1em;\n  padding: 8px 16px;\n  margin-left: auto;\n}\n\n.jp-WWCExtension-synthesis-button-container {\n  margin-bottom: 16px;\n  padding: 8px;\n  text-align: center;\n}\n\n.jp-WWCExtension-synthesis-button {\n  background-color: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n  font-weight: 600;\n  padding: 10px 20px;\n}\n\n/* WWC Co-Pilot Styles */\n.jp-WWCExtension-wwc {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  padding: 16px;\n  padding-bottom: 32px;\n  overflow-y: auto;\n}\n\n.jp-WWCExtension-wwc-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 24px;\n  padding-bottom: 16px;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n.jp-WWCExtension-wwc-header h2 {\n  margin: 0;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-close {\n  background: none;\n  border: none;\n  font-size: 24px;\n  cursor: pointer;\n  color: var(--jp-content-font-color2);\n  padding: 0;\n  width: 32px;\n  height: 32px;\n  line-height: 32px;\n  border-radius: var(--jp-border-radius);\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-close:hover {\n  color: var(--jp-content-font-color1);\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-wwc-judgments {\n  margin-bottom: 24px;\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z1);\n}\n\n.jp-WWCExtension-wwc-judgments h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-wwc-field {\n  margin-bottom: 16px;\n}\n\n.jp-WWCExtension-wwc-field label {\n  display: block;\n  margin-bottom: 6px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 500;\n  color: var(--jp-content-font-color1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-wwc-field select {\n  width: 100%;\n  padding: 6px 8px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size1);\n  background-color: var(--jp-layout-color0);\n  color: var(--jp-content-font-color1);\n  cursor: pointer;\n  transition:\n    border-color 0.2s ease-in-out,\n    outline 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-wwc-field select:focus {\n  outline: 1px solid var(--jp-brand-color1);\n  outline-offset: -1px;\n}\n\n.jp-WWCExtension-wwc-help {\n  margin: 4px 0 0;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n  font-style: italic;\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-wwc-results {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z1);\n}\n\n.jp-WWCExtension-wwc-results h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-wwc-rating {\n  padding: 12px;\n  border-radius: var(--jp-border-radius);\n  margin-bottom: 16px;\n  text-align: center;\n  color: white;\n}\n\n.jp-WWCExtension-wwc-rating.jp-type-meets-standards {\n  background-color: var(--jp-success-color1);\n}\n\n.jp-WWCExtension-wwc-rating.jp-type-meets-with-reservations {\n  background-color: var(--jp-warn-color1);\n}\n\n.jp-WWCExtension-wwc-rating.jp-type-does-not-meet {\n  background-color: var(--jp-error-color1);\n}\n\n.jp-WWCExtension-wwc-section {\n  margin-bottom: 16px;\n  padding-bottom: 16px;\n  border-bottom: 1px solid var(--jp-border-color2);\n}\n\n.jp-WWCExtension-wwc-section:last-child {\n  border-bottom: none;\n}\n\n.jp-WWCExtension-wwc-section h4 {\n  margin: 0 0 8px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-wwc-section p {\n  margin: 4px 0;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-wwc-justification {\n  margin-top: 16px;\n}\n\n.jp-WWCExtension-wwc-justification h4 {\n  margin: 0 0 8px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-wwc-justification ul {\n  margin: 0;\n  padding-left: 20px;\n  color: var(--jp-content-font-color2);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-wwc-justification li {\n  margin-bottom: 4px;\n}\n\n/* Synthesis Workbench Styles */\n.jp-WWCExtension-synthesis {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  padding: 16px;\n  overflow-y: auto;\n}\n\n.jp-WWCExtension-synthesis-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 24px;\n  padding-bottom: 16px;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n.jp-WWCExtension-synthesis-header h2 {\n  margin: 0;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-synthesis-actions {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  margin-bottom: 24px;\n}\n\n.jp-WWCExtension-synthesis-actions-row {\n  display: flex;\n  gap: 12px;\n  flex-wrap: wrap;\n}\n\n.jp-WWCExtension-synthesis-content {\n  flex: 1;\n  overflow-y: auto;\n}\n\n.jp-WWCExtension-synthesis-empty {\n  padding: 32px 32px 48px;\n  text-align: center;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-synthesis-empty h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n}\n\n.jp-WWCExtension-synthesis-empty p {\n  margin: 12px 0;\n  text-align: left;\n}\n\n.jp-WWCExtension-synthesis-empty ul {\n  margin: 12px 0;\n  padding-left: 24px;\n  text-align: left;\n}\n\n.jp-WWCExtension-synthesis-empty li {\n  margin: 8px 0;\n}\n\n.jp-WWCExtension-synthesis-empty-note {\n  margin-top: 24px;\n  padding-bottom: 24px;\n}\n\n/* Meta-Analysis View Styles */\n.jp-WWCExtension-meta-analysis {\n  display: flex;\n  flex-direction: column;\n  gap: 24px;\n  padding-bottom: 16px;\n}\n\n.jp-WWCExtension-meta-analysis h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n/* Stat Cards Grid Layout */\n.jp-WWCExtension-meta-analysis-summary {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\n  gap: 16px;\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-meta-analysis-stat {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 16px;\n  background-color: var(--jp-layout-color0);\n  border-radius: var(--jp-border-radius);\n  box-shadow: var(--jp-elevation-z1);\n  text-align: center;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-meta-analysis-stat:hover {\n  box-shadow: var(--jp-elevation-z2);\n  transform: translateY(-2px);\n}\n\n.jp-WWCExtension-meta-analysis-stat strong {\n  color: var(--jp-content-font-color1);\n  font-weight: 600;\n  font-size: var(--jp-ui-font-size0);\n  text-transform: uppercase;\n  margin-bottom: 8px;\n  line-height: 1.4;\n}\n\n.jp-WWCExtension-meta-analysis-stat span {\n  color: var(--jp-brand-color1);\n  font-family: var(--jp-code-font-family);\n  font-size: 28px;\n  font-weight: 700;\n  line-height: 1.2;\n}\n\n.jp-WWCExtension-meta-analysis-plot {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-plot-image {\n  max-width: 100%;\n  height: auto;\n}\n\n.jp-WWCExtension-meta-analysis-plot h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-meta-analysis-studies {\n  padding: 16px;\n  padding-bottom: 32px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-meta-analysis-studies h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-table {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-WWCExtension-table thead {\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-table th {\n  padding: 8px 12px;\n  text-align: left;\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  border-bottom: 2px solid var(--jp-border-color1);\n  line-height: 1.4;\n  white-space: nowrap;\n}\n\n.jp-WWCExtension-table td {\n  padding: 8px 12px;\n  color: var(--jp-content-font-color2);\n  border-bottom: 1px solid var(--jp-border-color2);\n  word-wrap: break-word;\n  overflow-wrap: break-word;\n  line-height: 1.5;\n  transition: background-color 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-table td:first-child {\n  max-width: 250px;\n  min-width: 150px;\n  word-break: break-word;\n}\n\n.jp-WWCExtension-table tbody tr:hover {\n  background-color: var(--jp-layout-color2);\n}\n\n/* Conflict View Styles */\n.jp-WWCExtension-conflicts {\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n\n.jp-WWCExtension-conflicts h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-conflicts-summary {\n  padding: 12px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z1);\n}\n\n.jp-WWCExtension-conflicts-summary p {\n  margin: 0;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-conflicts-empty {\n  padding: 32px;\n  text-align: center;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size1);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-conflicts-list {\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n\n.jp-WWCExtension-conflict-item {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  border-left: 4px solid var(--jp-error-color1);\n  box-shadow: var(--jp-elevation-z1);\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-conflict-item:hover {\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-conflict-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n  padding-bottom: 8px;\n  border-bottom: 1px solid var(--jp-border-color2);\n}\n\n.jp-WWCExtension-conflict-header strong {\n  color: var(--jp-content-font-color1);\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-conflict-header span {\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size0);\n  font-family: var(--jp-code-font-family);\n  line-height: 1.4;\n}\n\n.jp-WWCExtension-conflict-papers {\n  margin-bottom: 12px;\n  padding: 8px;\n  background-color: var(--jp-layout-color2);\n  border-radius: var(--jp-border-radius);\n}\n\n.jp-WWCExtension-conflict-papers div {\n  margin: 4px 0;\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size0);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-conflict-papers strong {\n  color: var(--jp-content-font-color1);\n  font-weight: 600;\n}\n\n.jp-WWCExtension-conflict-findings {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.jp-WWCExtension-conflict-findings div {\n  padding: 8px;\n  background-color: var(--jp-layout-color2);\n  border-radius: var(--jp-border-radius);\n  color: var(--jp-content-font-color2);\n  font-size: var(--jp-ui-font-size0);\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-conflict-findings strong {\n  color: var(--jp-content-font-color1);\n  font-weight: 600;\n  display: block;\n  margin-bottom: 4px;\n}\n\n.jp-WWCExtension-conflict-explanation {\n  margin-top: 16px;\n  padding: 12px;\n  background-color: var(--jp-layout-color2);\n  border-radius: var(--jp-border-radius);\n  border-left: 3px solid var(--jp-brand-color1);\n}\n\n.jp-WWCExtension-conflict-explanation strong {\n  color: var(--jp-content-font-color1);\n  font-weight: 600;\n  display: block;\n  margin-bottom: 8px;\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-WWCExtension-conflict-explanation p {\n  margin: 8px 0;\n  line-height: 1.6;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n}\n\n.jp-WWCExtension-conflict-explanation ul {\n  margin: 8px 0 8px 20px;\n  padding-left: 0;\n}\n\n.jp-WWCExtension-conflict-explanation li {\n  margin: 6px 0;\n  line-height: 1.5;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n}\n\n/* WWC Info Boxes Container */\n.jp-WWCExtension-wwc-info-container {\n  margin: 16px 0 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 0; /* No gap between boxes when stacked */\n}\n\n/* Always-visible informational box */\n.jp-WWCExtension-wwc-info-box {\n  padding: 16px;\n  background-color: var(--jp-info-color3);\n  border: 2px solid var(--jp-info-color1);\n  border-radius: var(--jp-border-radius);\n  border-left-width: 4px;\n  width: 100%;\n}\n\n/* Warning box - only shows when data is missing */\n.jp-WWCExtension-wwc-warning-box {\n  padding: 16px;\n  background-color: var(--jp-warn-color3);\n  border: 2px solid var(--jp-warn-color1);\n  border-radius: var(--jp-border-radius);\n  border-left-width: 4px;\n  width: 100%;\n}\n\n/* When info box is followed by warning box, connect them seamlessly */\n.jp-WWCExtension-wwc-info-box + .jp-WWCExtension-wwc-warning-box {\n  border-top-left-radius: 0;\n  border-top-right-radius: 0;\n  margin-top: 0;\n}\n\n/* When warning follows info, remove bottom radius from info box */\n.jp-WWCExtension-wwc-info-box:has(+ .jp-WWCExtension-wwc-warning-box) {\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n  margin-bottom: 0;\n}\n\n/* Shared content styling */\n.jp-WWCExtension-wwc-info-content,\n.jp-WWCExtension-wwc-warning-content {\n  color: var(--jp-content-font-color1);\n}\n\n.jp-WWCExtension-wwc-info-content strong {\n  color: var(--jp-info-color0);\n  font-weight: 600;\n  display: block;\n  margin-bottom: 8px;\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-WWCExtension-wwc-warning-content strong {\n  color: var(--jp-warn-color0);\n  font-weight: 600;\n  display: block;\n  margin-bottom: 8px;\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-WWCExtension-wwc-info-content p,\n.jp-WWCExtension-wwc-warning-content p {\n  margin: 8px 0;\n  line-height: 1.6;\n  font-size: var(--jp-ui-font-size1);\n}\n\n.jp-WWCExtension-wwc-warning-content ul {\n  margin: 8px 0 8px 20px;\n  padding-left: 0;\n}\n\n.jp-WWCExtension-wwc-warning-content li {\n  margin: 6px 0;\n  line-height: 1.5;\n}\n\n.jp-WWCExtension-wwc-info-content code,\n.jp-WWCExtension-wwc-warning-content code {\n  background-color: var(--jp-layout-color2);\n  padding: 2px 6px;\n  border-radius: 3px;\n  font-family: var(--jp-code-font-family);\n  font-size: var(--jp-ui-font-size0);\n}\n\n/* WWC Wizard Progress Indicator */\n.jp-WWCExtension-wwc-progress {\n  margin-bottom: 24px;\n}\n\n.jp-WWCExtension-wwc-progress-bar {\n  height: 4px;\n  background-color: var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  margin-bottom: 16px;\n  overflow: hidden;\n}\n\n.jp-WWCExtension-wwc-progress-fill {\n  height: 100%;\n  background-color: var(--jp-brand-color1);\n  transition: width 0.3s ease;\n}\n\n.jp-WWCExtension-wwc-steps {\n  display: flex;\n  justify-content: space-between;\n  gap: 8px;\n}\n\n.jp-WWCExtension-step {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding: 8px;\n  background: none;\n  border: 2px solid var(--jp-border-color1);\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-step:hover {\n  background-color: var(--jp-layout-color2);\n}\n\n.jp-WWCExtension-step.active {\n  border-color: var(--jp-brand-color1);\n  background-color: var(--jp-brand-color3);\n}\n\n.jp-WWCExtension-step.completed {\n  border-color: var(--jp-success-color1);\n  background-color: var(--jp-success-color3);\n}\n\n.jp-WWCExtension-step .step-number {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background-color: var(--jp-border-color2);\n  color: var(--jp-content-font-color2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 600;\n  margin-bottom: 4px;\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-step.active .step-number {\n  background-color: var(--jp-brand-color1);\n  color: white;\n}\n\n.jp-WWCExtension-step.completed .step-number {\n  background-color: var(--jp-success-color1);\n  color: white;\n}\n\n.jp-WWCExtension-step .step-label {\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n  text-align: center;\n  line-height: 1.4;\n}\n\n.jp-WWCExtension-wwc-navigation {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 24px;\n  margin-bottom: 32px;\n  padding-top: 16px;\n  border-top: 1px solid var(--jp-border-color1);\n}\n\n.jp-WWCExtension-wwc-step-content {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z1);\n}\n\n.jp-WWCExtension-wwc-step-content h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n/* Subgroup Analysis Styles */\n.jp-WWCExtension-subgroup-analysis {\n  display: flex;\n  flex-direction: column;\n  gap: 24px;\n  padding-bottom: 32px;\n}\n\n.jp-WWCExtension-subgroup-analysis h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-subgroup-overall {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-subgroup-overall h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-subgroup-results {\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n\n.jp-WWCExtension-subgroup-results h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-subgroup-item {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z1);\n  transition: all 0.2s ease-in-out;\n}\n\n.jp-WWCExtension-subgroup-item:hover {\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-subgroup-item h5 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-subgroup-controls {\n  display: flex;\n  gap: 8px;\n  align-items: center;\n}\n\n/* Bias Assessment Styles */\n.jp-WWCExtension-bias-assessment {\n  display: flex;\n  flex-direction: column;\n  gap: 24px;\n}\n\n.jp-WWCExtension-bias-assessment h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-eggers-test {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\n  gap: 16px;\n  align-items: start;\n}\n\n.jp-WWCExtension-eggers-test h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n  grid-column: 1 / -1;\n}\n\n.jp-WWCExtension-eggers-interpretation {\n  grid-column: 1 / -1;\n  margin-top: 8px;\n  padding-top: 16px;\n  border-top: 1px solid var(--jp-border-color2);\n}\n\n.jp-WWCExtension-funnel-plot {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-funnel-plot h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n/* Sensitivity Analysis Styles */\n.jp-WWCExtension-sensitivity-analysis {\n  padding-bottom: 32px;\n  display: flex;\n  flex-direction: column;\n  gap: 24px;\n}\n\n.jp-WWCExtension-sensitivity-analysis h3 {\n  margin: 0 0 16px;\n  font-size: var(--jp-ui-font-size2);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-sensitivity-overall,\n.jp-WWCExtension-sensitivity-loo,\n.jp-WWCExtension-sensitivity-influence {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  box-shadow: var(--jp-elevation-z2);\n}\n\n.jp-WWCExtension-sensitivity-overall h4,\n.jp-WWCExtension-sensitivity-loo h4,\n.jp-WWCExtension-sensitivity-influence h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n/* Findings Preview Styles */\n.jp-WWCExtension-findings-preview {\n  padding: 16px;\n  background-color: var(--jp-layout-color1);\n  border-radius: var(--jp-border-radius);\n  border: 1px solid var(--jp-border-color1);\n  margin-bottom: 16px;\n  box-shadow: var(--jp-elevation-z1);\n}\n\n.jp-WWCExtension-findings-preview h4 {\n  margin: 0 0 12px;\n  font-size: var(--jp-ui-font-size1);\n  font-weight: 600;\n  color: var(--jp-content-font-color1);\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-finding-item {\n  margin-bottom: 16px;\n  padding: 12px;\n  background-color: var(--jp-layout-color2);\n  border-radius: var(--jp-border-radius);\n}\n\n.jp-WWCExtension-finding-item strong {\n  color: var(--jp-content-font-color1);\n  font-weight: 600;\n  display: block;\n  margin-bottom: 8px;\n  line-height: 1.3;\n}\n\n.jp-WWCExtension-finding-item ul {\n  margin: 0;\n  padding-left: 20px;\n  color: var(--jp-content-font-color2);\n}\n\n.jp-WWCExtension-finding-item li {\n  margin-bottom: 4px;\n  line-height: 1.5;\n}\n\n/* WWC Badge Styles */\n.jp-WWCExtension-wwcBadge {\n  display: inline-block;\n  padding: 2px 8px;\n  border-radius: 12px;\n  font-size: 11px;\n  font-weight: 600;\n  margin-top: 8px;\n  text-transform: uppercase;\n  line-height: 1.4;\n}\n\n.jp-WWCExtension-wwcBadge.jp-type-meets-standards {\n  background-color: var(--jp-success-color2);\n  color: var(--jp-success-color0);\n}\n\n.jp-WWCExtension-wwcBadge.jp-type-meets-with-reservations {\n  background-color: var(--jp-warn-color2);\n  color: var(--jp-warn-color0);\n}\n\n.jp-WWCExtension-wwcBadge.jp-type-does-not-meet {\n  background-color: var(--jp-error-color2);\n  color: var(--jp-error-color0);\n}\n\n.jp-WWCExtension-wwcBadge.jp-type-not-assessed {\n  background-color: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color2);\n}\n\n/* Utility Classes */\n.jp-WWCExtension-file-input {\n  display: none;\n}\n\n.jp-mod-file-upload-label {\n  display: inline-block;\n  cursor: pointer;\n}\n\n.jp-mod-high-difference {\n  color: var(--jp-error-color1);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js":
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ })

}]);
//# sourceMappingURL=style_index_js.499797a48c891d8c9126.js.map