"""Python unit tests for jupyterlab_research_assistant_wwc_copilot."""
