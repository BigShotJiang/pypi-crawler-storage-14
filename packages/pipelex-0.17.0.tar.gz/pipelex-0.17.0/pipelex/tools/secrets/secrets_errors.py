from pipelex.system.exceptions import ToolError


class SecretNotFoundError(ToolError):
    pass
