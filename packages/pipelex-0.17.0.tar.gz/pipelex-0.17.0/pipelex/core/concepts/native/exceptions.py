from pipelex.base_exceptions import PipelexError


class NativeConceptDefinitionError(PipelexError):
    pass
