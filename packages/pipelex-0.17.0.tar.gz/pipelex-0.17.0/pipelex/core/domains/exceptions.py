from pipelex.base_exceptions import PipelexError


class DomainCodeError(PipelexError):
    pass


class DomainFactoryError(PipelexError):
    pass
