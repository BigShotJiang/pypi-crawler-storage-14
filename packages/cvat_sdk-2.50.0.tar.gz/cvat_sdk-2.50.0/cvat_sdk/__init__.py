# Copyright (C) CVAT.ai Corporation
#
# SPDX-License-Identifier: MIT

from cvat_sdk.core.client import Client, Config, make_client
from cvat_sdk.version import VERSION as __version__
