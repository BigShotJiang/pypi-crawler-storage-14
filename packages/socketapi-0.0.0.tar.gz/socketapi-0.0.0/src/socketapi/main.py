class SocketAPI:
    pass
