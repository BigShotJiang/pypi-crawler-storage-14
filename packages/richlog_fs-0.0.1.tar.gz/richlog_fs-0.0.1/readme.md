# richlog for fs accessing.

## Installation

You can install from [pypi](https://pypi.org/project/richlog_fs/)

```console
pip install -U richlog_fs
```

## Usage

```python
import richlog_fs
```
