# yarobot/__init__.py
from . import *

__all__ = ["generate"]
