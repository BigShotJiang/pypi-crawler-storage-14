.. Zino documentation master file, created by
   sphinx-quickstart on Fri Sep 13 14:02:10 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Zino documentation
==================

Zino is a robust network management system for large backbone networks.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   configuration
   development
   howtos
