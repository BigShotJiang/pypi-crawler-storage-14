SNMPTRAP_MISSING = "Cannot find snmptrap command line program"
