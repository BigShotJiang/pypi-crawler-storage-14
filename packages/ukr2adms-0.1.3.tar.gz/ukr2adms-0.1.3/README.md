# `ukr2adms` utility

The `ukr2adms` utility is designed to help UK amateur radio enthusiasts upload
UK repeater and gateway frequencies/callsigns into the the memories in their C4FM radios.
It automatically downloads
repeater and gateway information from the [RSGB ukrepeaters](https://ukrepeater.net)
website, and formats the required CSV file for uploading into the Yaesu ADMS programming
software.

Options for the user are to download gateways as well as repeaters, select analog- as well
as C4FM-capable stations, and select only "OPERATIONAL" status stations.  The user may
instruct `ukr2adms` to set the operating mode of each station to AMS (Automatic Mode
Select), otherwise "DN" is assumed for YSF-capable stations, and "FM" otherwise.

> [!note]
> There are a couple of caveats you should consider when using this software:
> 
> 1. The software has been tested on the ADMS-16 software when programming a Yaesu FTM-500D. With
>    other radios, YMMV!
> 1. The data from the [UK Repeaters API](https://ukrepeater.net/csvfiles.html) is not 100% accurate. 
>    In particular, certain CTCSS frequencies are erroneous, and don't match the set of CTCSS frequencies
>    allowed by ADMS.  `ukr2adms` makes a best guess, converting `0` (i.e. no CTCSS) to `100.0 Hz` with 
>    Tone Squelch set of `OFF`), and setting any other CTCSS frequencies to their nearest frequency in the
>    ADMS valid set.


## Installation
Installation is best carried out using either `pip` or `pipx`, i.e.

```bash
$ pip install ukr2adms
```
or
```bash
$ pipx install ukr2adms
```

## Basic usage
To download all the repeater and gateway frequencies on both 2m and 70cm, and output to a CSV file `foo.csv` invoke `ukr2adms` by

```bash
$ ukr2adms -g foo.csv
```

`foo.csv` can now be imported into ADMS(-16) for writing to the radio.

For more information, consult the user help:

```bash
$ ukr2adms -h
```

