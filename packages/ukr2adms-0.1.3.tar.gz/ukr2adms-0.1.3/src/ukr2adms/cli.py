"""ukr2adms command line utility"""

import argparse
import logging

from .constants import BANDS
from .main import ukr2adms


def parse_cli_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-b",
        "--band",
        choices=BANDS,
        default=["2m", "70cm"],
        action="append",
        help="One or more required frequency bands (default -b 2m -b 70cm)).",
    )
    parser.add_argument(
        "-g",
        "--gateway",
        action="store_true",
        help="Include gateways",
    )
    parser.add_argument(
        "-m",
        "--mode",
        type=str,
        default="both",
        choices=["analog", "c4fm", "both"],
        help="Which transmission mode capabilities to include.  Default: 'both'.",
    )
    parser.add_argument(
        "-a",
        "--ams-mode",
        action="store_true",
        help="If specified, transmission modes are set to AMS. Otherwise, DN is used for C4FM stations, and FM for non-C4FM stations.",
    )
    parser.add_argument(
        "-p",
        "--operational-only",
        action="store_true",
        help="Include only 'OPERATIONAL' status stations",
    )
    parser.add_argument(
        "-d",
        "--debug",
        type=str,
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Set debug level.",
    )
    parser.add_argument("output", type=str, help="Output CSV filename.")

    return parser.parse_args()


def cli():
    args = parse_cli_args()
    print("args:", args)

    logging.basicConfig(level=args.debug)

    kwargs = {
        "band": args.band,
        "analog": args.mode in ["analog", "both"],
        "c4fm": args.mode in ["c4fm", "both"],
        "gateway": args.gateway,
        "operational_only": args.operational_only,
        "ams_mode": args.ams_mode,
    }

    print(kwargs)

    ukr2adms(**kwargs).to_csv(args.output, header=False)


if __name__ == "__main__":
    cli()
