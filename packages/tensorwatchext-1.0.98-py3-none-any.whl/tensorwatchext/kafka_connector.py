import time
import threading
import multiprocessing as mp
from queue import Empty
import random
import json
import pickle
from typing import Dict
from confluent_kafka import Consumer, KafkaError
from .watcher import Watcher
from probables import CountMinSketch
import logging

# Optional Parsers
try:
    import xmltodict
except ImportError:
    xmltodict = None

try:
    # import avro.schema
    # from avro.io import DatumReader, BinaryDecoder
    # import io
    from fastavro import schemaless_reader
    import io
except ImportError:
    print("⚠️ avro is not installed. Please run 'pip install fastavro'.")
    avro = None

try:
    from google.protobuf.json_format import MessageToDict
    protobuf_to_dict = lambda msg: MessageToDict(msg, preserving_proto_field_name=True)
except ImportError:
    print("⚠️ protobuf is not installed. Please run 'pip install protobuf'.")
    protobuf_to_dict = None


class kafka_connector:
    """
    A Kafka consumer that runs in a separate thread to consume messages from a Kafka topic.
    It supports various message formats and integrates with TensorWatch for real-time data visualization.
    """


    # Note: This class is no longer a thread. It manages child processes.
    def __init__(self, hosts="localhost:9092", topic=None, parsetype=None, queue_length=50000,
                 cluster_size=1, consumer_config=None, poll=1.0, auto_offset="earliest", group_id="mygroup", parser_extra=None,
                 decode="utf-8", schema_path=None, protobuf_message=None, random_sampling=None, countmin_width=None,
                 countmin_depth=None, twapi_instance=None, ordering_field=None, zmq_port=None):
        """
        Initializes the kafka_connector.

        Args:
            hosts (str): Comma-separated list of Kafka brokers.
            topic (str): The Kafka topic to consume from.
            parsetype (str): The format of the messages (e.g., "json", "pickle", "xml", "avro", "protobuf").
            queue_length (int): The maximum number of messages to store in the internal queue.
            cluster_size (int): The number of consumer threads to run.
            consumer_config (dict): A dictionary of Kafka consumer configuration settings.
            poll (float): The timeout for polling for new messages from Kafka.
            auto_offset (str): The offset reset policy.
            group_id (str): The consumer group ID.
            parser_extra (str): Extra information for the parser (e.g.avro_schema, Protobuf module).
            decode (str): The encoding to use for decoding messages.
            schema_path (str): The path to the Avro schema file.
            protobuf_message (str): The name of the Protobuf message class.
            random_sampling (int): The percentage of messages to sample (0-100).
            countmin_width (int): The width of the Count-Min Sketch.
            countmin_depth (int): The depth of the Count-Min Sketch.
            twapi_instance: An instance of the TensorWatch API for updating metrics.
            ordering_field (str): Optional message field to maintain global ordering.
            zmq_port (int): The port offset for the ZMQ watcher. If None, an automatic offset is assigned.
        """
        self.hosts = hosts or "localhost:9092"
        self.topic = topic
        self.cluster_size = cluster_size
        self.decode = decode
        self.parsetype = parsetype
        self.parser_extra = parser_extra
        self.protobuf_message = protobuf_message
        self.queue_length = queue_length
        # Queues for inter-process communication. Add a signal queue for startup.
        self.signal_queue = mp.Queue(maxsize=1)
        self.raw_message_queue = mp.Queue(maxsize=queue_length)
        self.data = self.raw_message_queue # Maintain 'data' attribute for compatibility
        self.cms = {}
        self.countmin_width = countmin_width
        self.countmin_depth = countmin_depth
        self.random_sampling = random_sampling
        self.poll = poll
        self.consumer_config = consumer_config or {
            "bootstrap.servers": self.hosts,
            "group.id": group_id,
            "auto.offset.reset": auto_offset,
        }
        self._quit = mp.Event()
        self.size = 0
        self.zmq_port = zmq_port # Store port, but don't create watcher yet
        self.schema = None
        self.reader = None

        self.twapi_instance = None
        self.latencies = []
        self.received_count = 0
        self.last_report_time = time.time()
        self.first_message_sent = False

        # --- NEW: Optional ordering field ---
        self.ordering_field = ordering_field
        self.reordering_buffer = []

        # Parser resources will be initialized lazily inside each worker process
        # to avoid pickling errors.
        self.protobuf_class = None
        self.avro_schema = None

        self.processes = []
        # The Watcher should be created and managed by the twapi instance.
        if twapi_instance:
            self.watcher = twapi_instance.get_watcher(port=self.zmq_port)
        else:
            self.watcher = None

        # Start the background polling processes
        for i in range(self.cluster_size):
            p = mp.Process(target=kafka_connector._poll_loop, args=(self.topic, self.consumer_config, self.poll, self.raw_message_queue, self._quit), daemon=True)
            self.processes.append(p)
            p.start()
        
        # Start a single, dedicated observer process
        if self.watcher:
            observer_args = (
                self.raw_message_queue, self.signal_queue, self._quit,
                self.watcher.port, self.parsetype, self.decode # BUGFIX: Pass the port, not the watcher object
            )
            observer_process = mp.Process(target=kafka_connector._observer_worker, args=observer_args, daemon=True)
            self.processes.append(observer_process)
            observer_process.start()
            logging.info("Started observer worker process.")

    @staticmethod
    def _poll_loop(topic, consumer_config, poll_timeout, raw_message_queue, quit_event):
        """
        A simple, efficient loop that runs in a background process to poll raw bytes.
        """
        logging.info(f"Starting Kafka polling process for topic '{topic}'")
        try:
            consumer = Consumer(consumer_config)
            consumer.subscribe([topic])

            while not quit_event.is_set():
                try:
                    # PERFORMANCE: Use consume() for high-throughput batch polling
                    msgs = consumer.consume(num_messages=10000, timeout=poll_timeout)
                    if not msgs:
                        continue
                    
                    for msg in msgs:
                        if not msg.error():
                            raw_message_queue.put(msg.value())
                except Exception as e:
                    logging.error(f"Exception during consumer.consume(): {e}")
        except Exception as e:
            logging.error(f"Exception in poll loop: {e}")
        finally:
            if 'consumer' in locals():
                consumer.close()
        logging.info("Polling process stopped")

    @staticmethod
    def _observer_worker(raw_message_queue, signal_queue, quit_event, zmq_port, parsetype, decode):
        """
        A single background process that gets raw messages, parses them,
        and sends them to the tensorwatch server.
        """
        watcher = Watcher(port=zmq_port)
        size = 0
        first_batch_sent = False
        while not quit_event.is_set():
            try:
                # Drain the queue to process in a batch
                raw_messages = []
                # Get at least one message, then try to get more without blocking
                raw_messages.append(raw_message_queue.get(timeout=1))
                while not raw_message_queue.empty():
                    raw_messages.append(raw_message_queue.get_nowait())
                
                if not raw_messages:
                    continue

                # Fast, batch parsing
                if parsetype == 'json':
                    items_to_observe = [json.loads(m) for m in raw_messages]
                else: # Add other parsers here if needed
                    items_to_observe = [m.decode(decode) for m in raw_messages]

                size += len(items_to_observe)
                watcher.observe(data=items_to_observe, size=size)

                # Send a one-time signal after the first successful batch
                if not first_batch_sent and items_to_observe:
                    try:
                        signal_queue.put('first_message_sent', block=False)
                        first_batch_sent = True
                    except: # Queue might be full, which is fine
                        pass
            except Empty:
                continue
            except Exception as e:
                logging.error(f"Error in observer worker: {e}")

    def quit(self):
        """Stops the consumer processes."""
        logging.info("Shutting down kafka_connector...")
        self._quit.set()

        for p in self.processes:
            p.join(timeout=5)
            if p.is_alive():
                p.terminate()
        logging.info("All processes stopped.")
