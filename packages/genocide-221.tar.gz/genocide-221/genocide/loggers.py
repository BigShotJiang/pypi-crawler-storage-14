# This file is placed in the Public Domain.


import logging


from .statics import LEVELS


class Logging:

    datefmt = "%H:%M:%S"
    format = "%(module).3s %(message)s"


class Format(logging.Formatter):

    def format(self, record):
        record.module = record.module.upper()
        return logging.Formatter.format(self, record)


def level(loglevel):
    lvl = LEVELS.get(loglevel)
    if not lvl:
        return
    logger = logging.getLogger()
    for handler in logger.handlers:
        logger.removeHandler(handler)
    logger.setLevel(lvl)
    formatter = Format(Logging.format, datefmt=Logging.datefmt)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)


def __dir__():
    return (
        'Logging',
        'level'
    )
