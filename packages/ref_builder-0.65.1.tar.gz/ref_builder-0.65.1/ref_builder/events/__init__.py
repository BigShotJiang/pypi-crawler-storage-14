"""Events that are emitted to the repository event log."""
