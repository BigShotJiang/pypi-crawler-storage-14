"""Virtool CLI for managing references.

TODO: Switch back to Rich.
TODO: Allow exclusion checks at the Repo level.
"""
