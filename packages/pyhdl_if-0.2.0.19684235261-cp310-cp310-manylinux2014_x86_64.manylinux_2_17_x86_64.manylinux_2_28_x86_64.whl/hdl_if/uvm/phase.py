
from .object import uvm_object

class uvm_phase(uvm_object):
    pass