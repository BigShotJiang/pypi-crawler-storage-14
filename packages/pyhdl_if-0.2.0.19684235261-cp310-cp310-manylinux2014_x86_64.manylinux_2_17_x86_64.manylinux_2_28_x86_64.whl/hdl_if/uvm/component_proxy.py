import dataclasses as dc
from .component import uvm_component

class uvm_component_proxy(uvm_component):
    pass



