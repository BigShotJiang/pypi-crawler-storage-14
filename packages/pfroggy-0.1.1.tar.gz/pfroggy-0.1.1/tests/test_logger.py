"""Tests for the logger."""

import pytest
from io import StringIO

from pfroggy import Logger, Level, ConsoleHandler, TextFormatter, Color
from pfroggy.core.context import LogContext
from pfroggy.handlers.console import COLOR_SCHEMES, DEFAULT_COLORS, RESET


class TestLogger:
    def setup_method(self) -> None:
        Logger.reset()

    def test_get_logger_returns_root(self) -> None:
        logger = Logger.get_logger()
        assert logger.name == "root"

    def test_get_logger_creates_hierarchy(self) -> None:
        logger = Logger.get_logger("app.module.submodule")
        assert logger.name == "app.module.submodule"
        assert logger.parent is not None
        assert logger.parent.name == "app.module"

    def test_log_levels(self) -> None:
        output = StringIO()
        logger = Logger.get_logger()
        logger.level = Level.INFO
        handler = ConsoleHandler(stream=output, colorize=False)
        handler.formatter = TextFormatter()
        logger.add_handler(handler)

        logger.debug("debug message")  # Should not appear
        logger.info("info message")

        result = output.getvalue()
        assert "debug message" not in result
        assert "info message" in result

    def test_extra_fields(self) -> None:
        output = StringIO()
        logger = Logger.get_logger()
        handler = ConsoleHandler(stream=output, colorize=False)
        handler.formatter = TextFormatter(include_extra=True)
        logger.add_handler(handler)

        logger.info("test", user_id=123, action="login")

        result = output.getvalue()
        assert "user_id=123" in result
        assert "action='login'" in result

    def test_bound_logger(self) -> None:
        output = StringIO()
        logger = Logger.get_logger()
        handler = ConsoleHandler(stream=output, colorize=False)
        handler.formatter = TextFormatter(include_extra=True)
        logger.add_handler(handler)

        bound = logger.bind(request_id="abc123")
        bound.info("processing")

        result = output.getvalue()
        assert "request_id='abc123'" in result

    def test_context_manager(self) -> None:
        output = StringIO()
        logger = Logger.get_logger()
        handler = ConsoleHandler(stream=output, colorize=False)
        handler.formatter = TextFormatter(
            include_context=True, include_correlation_id=True)
        logger.add_handler(handler)

        with LogContext(user="alice"):
            logger.info("inside context")

        # Context should be cleared after exiting
        logger.info("outside context")

        result = output.getvalue()
        lines = result.strip().split("\n")
        assert "user='alice'" in lines[0]
        assert "user=" not in lines[1]


class TestLevels:
    def test_level_ordering(self) -> None:
        assert Level.TRACE < Level.DEBUG < Level.INFO < Level.WARNING < Level.ERROR < Level.CRITICAL

    def test_is_enabled_for(self) -> None:
        logger = Logger(level=Level.WARNING)
        assert not logger.is_enabled_for(Level.DEBUG)
        assert not logger.is_enabled_for(Level.INFO)
        assert logger.is_enabled_for(Level.WARNING)
        assert logger.is_enabled_for(Level.ERROR)


class TestConsoleHandlerColors:
    def setup_method(self) -> None:
        Logger.reset()

    def test_colorize_disabled(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output, colorize=False)
        handler.formatter = TextFormatter()
        logger = Logger.get_logger()
        logger.add_handler(handler)

        logger.info("test message")

        result = output.getvalue()
        assert "\033[" not in result  # No ANSI codes
        assert "test message" in result

    def test_colorize_enabled_default_scheme(self) -> None:
        output = StringIO()
        # Force colorize even though StringIO isn't a tty
        handler = ConsoleHandler(stream=output, colorize=False)
        handler._colorize = True  # Force enable for test
        handler._colors = DEFAULT_COLORS.copy()
        handler.formatter = TextFormatter()
        logger = Logger.get_logger()
        logger.add_handler(handler)

        logger.info("test message")

        result = output.getvalue()
        assert Color.GREEN in result  # INFO is green by default
        assert RESET in result

    def test_colorize_different_levels(self) -> None:
        output = StringIO()
        err_output = StringIO()
        handler = ConsoleHandler(
            stream=output, error_stream=err_output, colorize=False, level=Level.TRACE
        )
        handler._colorize = True
        handler._colors = DEFAULT_COLORS.copy()
        handler.formatter = TextFormatter()
        logger = Logger.get_logger()
        logger.level = Level.TRACE
        logger.add_handler(handler)

        logger.trace("trace")
        logger.debug("debug")
        logger.warning("warning")
        logger.error("error")

        result = output.getvalue()
        err_result = err_output.getvalue()
        assert Color.DIM in result  # TRACE
        assert Color.CYAN in result  # DEBUG
        assert Color.YELLOW in result  # WARNING
        assert Color.RED in err_result  # ERROR goes to stderr

    def test_preset_color_scheme(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output, colors="bold")
        assert handler._colors == COLOR_SCHEMES["bold"]

    def test_preset_color_scheme_minimal(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output, colors="minimal")
        assert handler._colors == COLOR_SCHEMES["minimal"]

    def test_preset_color_scheme_pastel(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output, colors="pastel")
        assert handler._colors == COLOR_SCHEMES["pastel"]

    def test_invalid_preset_raises(self) -> None:
        output = StringIO()
        with pytest.raises(ValueError, match="Unknown color scheme"):
            ConsoleHandler(stream=output, colors="nonexistent")

    def test_custom_color_dict(self) -> None:
        output = StringIO()
        custom_colors = {
            Level.INFO: Color.BLUE,
            Level.ERROR: Color.BOLD + Color.RED,
        }
        handler = ConsoleHandler(stream=output, colors=custom_colors)
        assert handler._colors[Level.INFO] == Color.BLUE
        assert handler._colors[Level.ERROR] == Color.BOLD + Color.RED

    def test_set_color_single_level(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output)
        handler.set_color(Level.INFO, Color.MAGENTA)
        assert handler._colors[Level.INFO] == Color.MAGENTA

    def test_set_colors_replaces_scheme(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output, colors="default")
        handler.set_colors("bold")
        assert handler._colors == COLOR_SCHEMES["bold"]

    def test_set_colors_with_dict(self) -> None:
        output = StringIO()
        handler = ConsoleHandler(stream=output)
        new_colors = {Level.DEBUG: Color.BRIGHT_BLUE}
        handler.set_colors(new_colors)
        assert handler._colors == new_colors

    def test_color_constants_exist(self) -> None:
        # Verify Color class has expected constants
        assert Color.RED == "\033[31m"
        assert Color.GREEN == "\033[32m"
        assert Color.BOLD == "\033[1m"
        assert Color.BRIGHT_RED == "\033[91m"
        assert Color.BG_RED == "\033[41m"
        assert Color.RESET == "\033[0m"

    def test_combined_colors(self) -> None:
        output = StringIO()
        err_output = StringIO()
        handler = ConsoleHandler(
            stream=output, error_stream=err_output, colorize=False)
        handler._colorize = True
        handler._colors = {Level.CRITICAL: Color.BOLD +
                           Color.BG_RED + Color.WHITE}
        handler.formatter = TextFormatter()
        logger = Logger.get_logger()
        logger.add_handler(handler)

        logger.critical("critical message")

        result = err_output.getvalue()  # CRITICAL goes to stderr
        assert Color.BOLD in result
        assert Color.BG_RED in result
        assert Color.WHITE in result
