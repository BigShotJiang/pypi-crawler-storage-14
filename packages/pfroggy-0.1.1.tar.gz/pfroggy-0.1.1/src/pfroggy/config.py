"""Configuration utilities."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pfroggy.core.logger import Logger
from pfroggy.core.levels import Level, parse_level
from pfroggy.handlers.console import ConsoleHandler
from pfroggy.handlers.file import FileHandler, RotatingFileHandler
from pfroggy.handlers.json_handler import JsonFileHandler
from pfroggy.formatters.text import TextFormatter
from pfroggy.formatters.json_fmt import JsonFormatter


def configure(
    level: str | int = Level.INFO,
    handlers: list[str] | None = None,
    format: str | None = None,
    colorize: bool = True,
    filename: str | None = None,
) -> Logger:
    """Quick configuration for common use cases.

    Args:
        level: Minimum log level
        handlers: List of handler types ("console", "file", "json")
        format: Log format string
        colorize: Enable console colors
        filename: File path for file handlers

    Returns:
        Configured root logger
    """
    Logger.reset()
    logger = Logger.get_logger()
    logger.level = parse_level(level) if isinstance(level, str) else level

    if handlers is None:
        handlers = ["console"]

    formatter = TextFormatter(fmt=format) if format else TextFormatter()

    for handler_type in handlers:
        if handler_type == "console":
            logger.add_handler(ConsoleHandler(
                formatter=formatter, colorize=colorize))
        elif handler_type == "file":
            if not filename:
                raise ValueError("filename required for file handler")
            logger.add_handler(FileHandler(filename, formatter=formatter))
        elif handler_type == "json":
            if not filename:
                raise ValueError("filename required for json handler")
            logger.add_handler(JsonFileHandler(filename))

    return logger


def configure_from_dict(config: dict[str, Any]) -> Logger:
    """Configure logging from a dictionary.

    Example config:
    {
        "level": "INFO",
        "handlers": [
            {
                "type": "console",
                "level": "DEBUG",
                "colorize": true,
                "formatter": {
                    "type": "text",
                    "format": "{timestamp} [{level}] {message}"
                }
            },
            {
                "type": "rotating_file",
                "filename": "app.log",
                "max_bytes": 10485760,
                "backup_count": 5
            }
        ]
    }
    """
    Logger.reset()
    logger = Logger.get_logger()

    if "level" in config:
        logger.level = parse_level(config["level"])

    for handler_config in config.get("handlers", []):
        handler = _create_handler(handler_config)
        logger.add_handler(handler)

    return logger


def _create_formatter(config: dict[str, Any]) -> TextFormatter | JsonFormatter:
    """Create a formatter from config."""
    fmt_type = config.get("type", "text")

    if fmt_type == "json":
        return JsonFormatter(
            include_extra=config.get("include_extra", True),
            include_context=config.get("include_context", True),
            include_thread=config.get("include_thread", False),
            indent=config.get("indent"),
        )
    else:
        return TextFormatter(
            fmt=config.get("format"),
            timestamp_format=config.get("timestamp_format"),
            include_extra=config.get("include_extra", True),
            include_context=config.get("include_context", False),
        )


def _create_handler(config: dict[str, Any]) -> Any:
    """Create a handler from config."""
    handler_type = config.get("type", "console")
    level = parse_level(config.get("level", "DEBUG"))

    formatter = None
    if "formatter" in config:
        formatter = _create_formatter(config["formatter"])

    if handler_type == "console":
        return ConsoleHandler(
            level=level,
            formatter=formatter,
            colorize=config.get("colorize", True),
        )
    elif handler_type == "file":
        return FileHandler(
            filename=config["filename"],
            level=level,
            formatter=formatter,
            mode=config.get("mode", "a"),
        )
    elif handler_type == "rotating_file":
        return RotatingFileHandler(
            filename=config["filename"],
            level=level,
            formatter=formatter,
            max_bytes=config.get("max_bytes", 10 * 1024 * 1024),
            backup_count=config.get("backup_count", 5),
        )
    elif handler_type == "json_file":
        return JsonFileHandler(
            filename=config["filename"],
            level=level,
        )
    else:
        raise ValueError(f"Unknown handler type: {handler_type}")


def configure_from_file(path: str | Path) -> Logger:
    """Configure from YAML or TOML file."""
    path = Path(path)

    if path.suffix in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "pyyaml required. Install with: pip install pfroggy[yaml]")
        with open(path) as f:
            config = yaml.safe_load(f)
    elif path.suffix == ".toml":
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore
            except ImportError:
                raise ImportError(
                    "tomli required for Python < 3.11. Install with: pip install pfroggy[toml]")
        with open(path, "rb") as f:
            config = tomllib.load(f)
    else:
        raise ValueError(f"Unsupported config file format: {path.suffix}")

    return configure_from_dict(config)
