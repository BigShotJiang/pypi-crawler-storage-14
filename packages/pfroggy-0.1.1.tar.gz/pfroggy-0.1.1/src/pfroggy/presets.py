"""Pre-configured handler and formatter presets for common use cases."""

from __future__ import annotations

from pfroggy.core.levels import Level
from pfroggy.handlers.console import ConsoleHandler
from pfroggy.handlers.file import FileHandler, RotatingFileHandler
from pfroggy.handlers.json_handler import JsonFileHandler
from pfroggy.formatters.text import TextFormatter
from pfroggy.formatters.json_fmt import JsonFormatter
from pfroggy.formatters.base import Formatter


# =============================================================================
# Formatter Presets
# =============================================================================

def formatter_simple() -> TextFormatter:
    """Simple formatter: [LEVEL] message"""
    return TextFormatter(fmt="[{level}] {message}", include_extra=False)


def formatter_default() -> TextFormatter:
    """Default formatter: timestamp [LEVEL] logger: message | extras"""
    return TextFormatter(
        fmt="{timestamp} [{level}] {name}: {message}",
        timestamp_format="%Y-%m-%d %H:%M:%S",
        include_extra=True,
    )


def formatter_detailed() -> TextFormatter:
    """Detailed formatter with thread info and context."""
    return TextFormatter(
        fmt="{timestamp} [{level}] {name} ({thread_name}): {message}",
        timestamp_format="%Y-%m-%d %H:%M:%S.%f",
        include_extra=True,
        include_context=True,
        include_correlation_id=True,
    )


def formatter_compact() -> TextFormatter:
    """Compact formatter: HH:MM:SS [LEVEL] message"""
    return TextFormatter(
        fmt="{timestamp} [{level}] {message}",
        timestamp_format="%H:%M:%S",
        include_extra=False,
    )


def formatter_dev() -> TextFormatter:
    """Development formatter with short timestamp and all details."""
    return TextFormatter(
        fmt="{timestamp} [{level}] {name}: {message}",
        timestamp_format="%H:%M:%S.%f",
        include_extra=True,
        include_context=True,
    )


def formatter_prod() -> TextFormatter:
    """Production formatter with full timestamp."""
    return TextFormatter(
        fmt="{timestamp} [{level}] {name}: {message}",
        timestamp_format="%Y-%m-%d %H:%M:%S",
        include_extra=True,
    )


def formatter_json() -> JsonFormatter:
    """JSON formatter for structured logging."""
    return JsonFormatter(
        include_extra=True,
        include_context=True,
        include_thread=False,
    )


def formatter_json_detailed() -> JsonFormatter:
    """JSON formatter with thread info."""
    return JsonFormatter(
        include_extra=True,
        include_context=True,
        include_thread=True,
    )


FORMATTER_PRESETS = {
    "simple": formatter_simple,
    "default": formatter_default,
    "detailed": formatter_detailed,
    "compact": formatter_compact,
    "dev": formatter_dev,
    "prod": formatter_prod,
    "json": formatter_json,
    "json_detailed": formatter_json_detailed,
}


def get_formatter_preset(name: str = "default") -> Formatter:
    """Get a pre-configured formatter by name.

    Available presets:
        - simple: [LEVEL] message
        - default: timestamp [LEVEL] logger: message | extras
        - detailed: full timestamp, thread, context, correlation_id
        - compact: HH:MM:SS [LEVEL] message
        - dev: short timestamp with extras and context
        - prod: full timestamp with extras
        - json: JSON structured output
        - json_detailed: JSON with thread info

    Args:
        name: Preset name (default: "default")

    Returns:
        Configured Formatter
    """
    if name not in FORMATTER_PRESETS:
        available = ", ".join(FORMATTER_PRESETS.keys())
        raise ValueError(
            f"Unknown formatter preset: {name}. Available: {available}")
    return FORMATTER_PRESETS[name]()


# =============================================================================
# Console Handler Presets
# =============================================================================

def console_simple() -> ConsoleHandler:
    """Simple console output with minimal formatting.

    Format: [LEVEL] message
    """
    handler = ConsoleHandler(colorize=True)
    handler.formatter = formatter_simple()
    return handler


def console_default() -> ConsoleHandler:
    """Default console output with timestamp and extras.

    Format: 2024-01-15 10:30:00 [INFO] logger: message | key=value
    """
    handler = ConsoleHandler(colorize=True)
    handler.formatter = formatter_default()
    return handler


def console_detailed() -> ConsoleHandler:
    """Detailed console output with thread info and context.

    Format: 2024-01-15 10:30:00.123456 [INFO] logger (thread): message | extras | ctx
    """
    handler = ConsoleHandler(colorize=True)
    handler.formatter = formatter_detailed()
    return handler


def console_compact() -> ConsoleHandler:
    """Compact console output with short timestamp.

    Format: 10:30:00 [INFO] message
    """
    handler = ConsoleHandler(colorize=True)
    handler.formatter = formatter_compact()
    return handler


def console_json() -> ConsoleHandler:
    """Console output in JSON format for structured logging."""
    handler = ConsoleHandler(colorize=False)  # No colors for JSON
    handler.formatter = formatter_json()
    return handler


def console_dev() -> ConsoleHandler:
    """Development-friendly console with bold colors and all details.

    Uses the 'bold' color scheme for high visibility.
    """
    handler = ConsoleHandler(colorize=True, colors="bold", level=Level.DEBUG)
    handler.formatter = formatter_dev()
    return handler


def console_prod() -> ConsoleHandler:
    """Production console - INFO+ level, minimal colors.

    Uses the 'minimal' color scheme, only WARNING+ get colors.
    """
    handler = ConsoleHandler(colorize=True, colors="minimal", level=Level.INFO)
    handler.formatter = formatter_prod()
    return handler


# =============================================================================
# File Handler Presets
# =============================================================================

def file_simple(filename: str) -> FileHandler:
    """Simple file logging with timestamp."""
    handler = FileHandler(filename)
    handler.formatter = formatter_default()
    return handler


def file_rotating(
    filename: str,
    max_mb: int = 10,
    backup_count: int = 5,
) -> RotatingFileHandler:
    """Rotating file handler with size limit.

    Args:
        filename: Log file path
        max_mb: Max file size in MB before rotation
        backup_count: Number of backup files to keep
    """
    handler = RotatingFileHandler(
        filename,
        max_bytes=max_mb * 1024 * 1024,
        backup_count=backup_count,
    )
    handler.formatter = formatter_default()
    return handler


def file_json(filename: str) -> JsonFileHandler:
    """JSON file logging for log aggregation systems."""
    return JsonFileHandler(
        filename,
        include_extra=True,
        include_context=True,
    )


def file_detailed(filename: str) -> FileHandler:
    """Detailed file logging with thread info and context."""
    handler = FileHandler(filename)
    handler.formatter = formatter_detailed()
    return handler


# =============================================================================
# Preset Registry
# =============================================================================

CONSOLE_PRESETS = {
    "simple": console_simple,
    "default": console_default,
    "detailed": console_detailed,
    "compact": console_compact,
    "json": console_json,
    "dev": console_dev,
    "prod": console_prod,
}

FILE_PRESETS = {
    "simple": file_simple,
    "rotating": file_rotating,
    "json": file_json,
    "detailed": file_detailed,
}


def get_console_preset(name: str = "default") -> ConsoleHandler:
    """Get a pre-configured console handler by name.

    Available presets:
        - simple: [LEVEL] message
        - default: timestamp [LEVEL] logger: message | extras
        - detailed: full timestamp, thread, context, correlation_id
        - compact: short timestamp, no extras
        - json: JSON formatted output
        - dev: bold colors, DEBUG level, all details
        - prod: minimal colors, INFO level

    Args:
        name: Preset name (default: "default")

    Returns:
        Configured ConsoleHandler
    """
    if name not in CONSOLE_PRESETS:
        available = ", ".join(CONSOLE_PRESETS.keys())
        raise ValueError(
            f"Unknown console preset: {name}. Available: {available}")
    return CONSOLE_PRESETS[name]()


def get_file_preset(name: str, filename: str, **kwargs) -> FileHandler:
    """Get a pre-configured file handler by name.

    Available presets:
        - simple: basic file logging
        - rotating: rotating file with size limit (kwargs: max_mb, backup_count)
        - json: JSON formatted file
        - detailed: full details with thread info

    Args:
        name: Preset name
        filename: Log file path
        **kwargs: Additional arguments for specific presets

    Returns:
        Configured FileHandler
    """
    if name not in FILE_PRESETS:
        available = ", ".join(FILE_PRESETS.keys())
        raise ValueError(
            f"Unknown file preset: {name}. Available: {available}")

    preset_fn = FILE_PRESETS[name]
    if name == "rotating":
        return preset_fn(filename, **kwargs)
    return preset_fn(filename)
