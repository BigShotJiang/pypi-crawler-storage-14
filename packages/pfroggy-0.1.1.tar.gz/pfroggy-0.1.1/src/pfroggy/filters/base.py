"""Base filter class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class Filter(ABC):
    """Base class for filters."""

    @abstractmethod
    def filter(self, record: LogRecord) -> bool:
        """Return True if the record should be logged."""
        ...
