"""Regex-based filters."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from pfroggy.filters.base import Filter

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class RegexFilter(Filter):
    """Filter messages by regex pattern."""

    def __init__(self, pattern: str, exclude: bool = False) -> None:
        """
        Args:
            pattern: Regex pattern to match against message
            exclude: If True, exclude matching messages; if False, include only matching
        """
        self._pattern = re.compile(pattern)
        self._exclude = exclude

    def filter(self, record: LogRecord) -> bool:
        matches = bool(self._pattern.search(record.message))
        return not matches if self._exclude else matches


class LoggerNameFilter(Filter):
    """Filter by logger name pattern."""

    def __init__(self, pattern: str, exclude: bool = False) -> None:
        self._pattern = re.compile(pattern)
        self._exclude = exclude

    def filter(self, record: LogRecord) -> bool:
        matches = bool(self._pattern.search(record.logger_name))
        return not matches if self._exclude else matches
