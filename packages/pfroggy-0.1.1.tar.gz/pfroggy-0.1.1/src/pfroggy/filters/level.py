"""Level-based filters."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pfroggy.core.levels import LogLevel
from pfroggy.filters.base import Filter

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class LevelFilter(Filter):
    """Filter by log level range."""

    def __init__(
        self,
        min_level: LogLevel | None = None,
        max_level: LogLevel | None = None,
    ) -> None:
        self._min_level = min_level
        self._max_level = max_level

    def filter(self, record: LogRecord) -> bool:
        if self._min_level is not None and record.level < self._min_level:
            return False
        if self._max_level is not None and record.level > self._max_level:
            return False
        return True


class ExactLevelFilter(Filter):
    """Filter for exact level match."""

    def __init__(self, level: LogLevel) -> None:
        self._level = level

    def filter(self, record: LogRecord) -> bool:
        return record.level == self._level
