"""Callable-based filter."""

from __future__ import annotations

from typing import Callable, TYPE_CHECKING

from pfroggy.filters.base import Filter

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class CallableFilter(Filter):
    """Filter using a custom callable."""

    def __init__(self, func: Callable[[LogRecord], bool]) -> None:
        self._func = func

    def filter(self, record: LogRecord) -> bool:
        return self._func(record)
