"""pfroggy - A super configurable logging library for Python."""

from pfroggy.core.logger import Logger
from pfroggy.core.levels import Level, LogLevel
from pfroggy.core.record import LogRecord
from pfroggy.handlers.base import Handler
from pfroggy.handlers.console import ConsoleHandler, Color
from pfroggy.handlers.file import FileHandler, RotatingFileHandler
from pfroggy.handlers.json_handler import JsonFileHandler
from pfroggy.formatters.base import Formatter
from pfroggy.formatters.text import TextFormatter
from pfroggy.formatters.json_fmt import JsonFormatter
from pfroggy.filters.base import Filter
from pfroggy.filters.level import LevelFilter
from pfroggy.config import configure, configure_from_dict
from pfroggy.presets import (
    # Formatter presets
    get_formatter_preset,
    formatter_simple,
    formatter_default,
    formatter_detailed,
    formatter_compact,
    formatter_dev,
    formatter_prod,
    formatter_json,
    formatter_json_detailed,
    # Console handler presets
    get_console_preset,
    console_simple,
    console_default,
    console_detailed,
    console_compact,
    console_json,
    console_dev,
    console_prod,
    # File handler presets
    get_file_preset,
    file_simple,
    file_rotating,
    file_json,
    file_detailed,
)

__version__ = "0.1.0"
__all__ = [
    # Core
    "Logger",
    "Level",
    "LogLevel",
    "LogRecord",
    # Handlers
    "Handler",
    "ConsoleHandler",
    "Color",
    "FileHandler",
    "RotatingFileHandler",
    "JsonFileHandler",
    # Formatters
    "Formatter",
    "TextFormatter",
    "JsonFormatter",
    # Filters
    "Filter",
    "LevelFilter",
    # Config
    "configure",
    "configure_from_dict",
    # Formatter Presets
    "get_formatter_preset",
    "formatter_simple",
    "formatter_default",
    "formatter_detailed",
    "formatter_compact",
    "formatter_dev",
    "formatter_prod",
    "formatter_json",
    "formatter_json_detailed",
    # Console Handler Presets
    "get_console_preset",
    "console_simple",
    "console_default",
    "console_detailed",
    "console_compact",
    "console_json",
    "console_dev",
    "console_prod",
    # File Handler Presets
    "get_file_preset",
    "file_simple",
    "file_rotating",
    "file_json",
    "file_detailed",
]


def get_logger(name: str | None = None) -> Logger:
    """Get or create a logger with the given name."""
    return Logger.get_logger(name)
