"""Text formatter."""

from __future__ import annotations

import traceback
from datetime import datetime
from typing import TYPE_CHECKING

from pfroggy.core.levels import get_level_name
from pfroggy.formatters.base import Formatter

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class TextFormatter(Formatter):
    """Configurable text formatter."""

    DEFAULT_FORMAT = "{timestamp} [{level}] {name}: {message}"
    DEFAULT_TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S.%f"

    def __init__(
        self,
        fmt: str | None = None,
        timestamp_format: str | None = None,
        include_extra: bool = True,
        include_context: bool = False,
        include_correlation_id: bool = False,
    ) -> None:
        self._fmt = fmt or self.DEFAULT_FORMAT
        self._timestamp_format = timestamp_format or self.DEFAULT_TIMESTAMP_FORMAT
        self._include_extra = include_extra
        self._include_context = include_context
        self._include_correlation_id = include_correlation_id

    def format(self, record: LogRecord) -> str:
        timestamp = datetime.fromtimestamp(
            record.timestamp).strftime(self._timestamp_format)

        parts = {
            "timestamp": timestamp,
            "level": get_level_name(record.level).ljust(8),
            "name": record.logger_name,
            "message": record.message,
            "thread_id": record.thread_id,
            "thread_name": record.thread_name,
        }

        if self._include_correlation_id and record.correlation_id:
            parts["correlation_id"] = record.correlation_id

        result = self._fmt.format(**parts)

        # Append extra fields
        if self._include_extra and record.extra:
            extra_str = " ".join(f"{k}={v!r}" for k, v in record.extra.items())
            result = f"{result} | {extra_str}"

        # Append context
        if self._include_context and record.context:
            ctx_str = " ".join(f"{k}={v!r}" for k, v in record.context.items())
            result = f"{result} | ctx: {ctx_str}"

        # Append exception info
        if record.exc_info:
            tb = "".join(traceback.format_exception(
                type(record.exc_info), record.exc_info, record.exc_info.__traceback__))
            result = f"{result}\n{tb}"

        return result
