"""JSON formatter."""

from __future__ import annotations

import json
import traceback
from datetime import datetime
from typing import Any, TYPE_CHECKING

from pfroggy.core.levels import get_level_name
from pfroggy.formatters.base import Formatter

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class JsonFormatter(Formatter):
    """JSON formatter for structured logging."""

    def __init__(
        self,
        include_extra: bool = True,
        include_context: bool = True,
        include_thread: bool = False,
        timestamp_format: str | None = None,
        indent: int | None = None,
    ) -> None:
        self._include_extra = include_extra
        self._include_context = include_context
        self._include_thread = include_thread
        self._timestamp_format = timestamp_format
        self._indent = indent

    def format(self, record: LogRecord) -> str:
        if self._timestamp_format:
            timestamp = datetime.fromtimestamp(
                record.timestamp).strftime(self._timestamp_format)
        else:
            timestamp = datetime.fromtimestamp(record.timestamp).isoformat()

        data: dict[str, Any] = {
            "timestamp": timestamp,
            "level": get_level_name(record.level),
            "logger": record.logger_name,
            "message": record.message,
        }

        if record.correlation_id:
            data["correlation_id"] = record.correlation_id

        if self._include_context and record.context:
            data["context"] = record.context

        if self._include_extra and record.extra:
            data["extra"] = record.extra

        if self._include_thread:
            data["thread_id"] = record.thread_id
            data["thread_name"] = record.thread_name

        if record.exc_info:
            data["exception"] = {
                "type": type(record.exc_info).__name__,
                "message": str(record.exc_info),
                "traceback": traceback.format_exception(
                    type(record.exc_info),
                    record.exc_info,
                    record.exc_info.__traceback__,
                ),
            }

        return json.dumps(data, indent=self._indent, default=str)
