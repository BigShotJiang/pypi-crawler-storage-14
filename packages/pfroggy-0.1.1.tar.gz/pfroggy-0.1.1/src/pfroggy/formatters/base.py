"""Base formatter class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord


class Formatter(ABC):
    """Base class for formatters."""

    @abstractmethod
    def format(self, record: LogRecord) -> str:
        """Format a log record into a string."""
        ...
