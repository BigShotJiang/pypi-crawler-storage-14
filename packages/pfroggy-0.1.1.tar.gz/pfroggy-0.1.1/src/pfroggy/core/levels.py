"""Log levels definition."""

from enum import IntEnum
from typing import TypeAlias


class Level(IntEnum):
    """Standard log levels."""

    TRACE = 5
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50
    OFF = 100


LogLevel: TypeAlias = Level | int


# Level name mapping
LEVEL_NAMES: dict[int, str] = {
    Level.TRACE: "TRACE",
    Level.DEBUG: "DEBUG",
    Level.INFO: "INFO",
    Level.WARNING: "WARNING",
    Level.ERROR: "ERROR",
    Level.CRITICAL: "CRITICAL",
}


def get_level_name(level: LogLevel) -> str:
    """Get the name for a log level."""
    if level in LEVEL_NAMES:
        return LEVEL_NAMES[level]
    return f"LEVEL_{level}"


def parse_level(level: str | int) -> LogLevel:
    """Parse a level from string or int."""
    if isinstance(level, int):
        return level
    level_upper = level.upper()
    for lvl, name in LEVEL_NAMES.items():
        if name == level_upper:
            return lvl
    raise ValueError(f"Unknown log level: {level}")
