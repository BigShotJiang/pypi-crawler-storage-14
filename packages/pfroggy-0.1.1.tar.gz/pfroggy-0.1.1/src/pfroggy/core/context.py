"""Context management for logging."""

from __future__ import annotations

import contextvars
import uuid
from typing import Any

# Context variables for async-safe context
_correlation_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "correlation_id", default=None
)
_log_context: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "log_context", default={}
)


def get_correlation_id() -> str | None:
    """Get the current correlation ID."""
    return _correlation_id.get()


def set_correlation_id(cid: str | None = None) -> str:
    """Set the correlation ID, generating one if not provided."""
    if cid is None:
        cid = str(uuid.uuid4())
    _correlation_id.set(cid)
    return cid


def clear_correlation_id() -> None:
    """Clear the correlation ID."""
    _correlation_id.set(None)


def get_context() -> dict[str, Any]:
    """Get the current logging context."""
    return _log_context.get().copy()


def set_context(**kwargs: Any) -> None:
    """Set context values."""
    current = _log_context.get()
    _log_context.set({**current, **kwargs})


def clear_context() -> None:
    """Clear all context."""
    _log_context.set({})


class LogContext:
    """Context manager for scoped logging context."""

    def __init__(self, correlation_id: str | None = None, **kwargs: Any) -> None:
        self._correlation_id = correlation_id
        self._kwargs = kwargs
        self._token_cid: contextvars.Token[str | None] | None = None
        self._token_ctx: contextvars.Token[dict[str, Any]] | None = None
        self._prev_ctx: dict[str, Any] = {}

    def __enter__(self) -> LogContext:
        if self._correlation_id is not None:
            self._token_cid = _correlation_id.set(self._correlation_id)
        elif get_correlation_id() is None:
            self._token_cid = _correlation_id.set(str(uuid.uuid4()))

        self._prev_ctx = get_context()
        new_ctx = {**self._prev_ctx, **self._kwargs}
        self._token_ctx = _log_context.set(new_ctx)
        return self

    def __exit__(self, *args: Any) -> None:
        if self._token_cid is not None:
            _correlation_id.reset(self._token_cid)
        if self._token_ctx is not None:
            _log_context.reset(self._token_ctx)
