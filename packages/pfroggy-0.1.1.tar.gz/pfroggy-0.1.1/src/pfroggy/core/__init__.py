"""Core logging components."""
