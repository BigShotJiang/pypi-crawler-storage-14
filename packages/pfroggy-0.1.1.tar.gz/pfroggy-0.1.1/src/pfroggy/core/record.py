"""Log record definition."""

from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from typing import Any

from pfroggy.core.levels import LogLevel


@dataclass
class LogRecord:
    """Represents a single log event."""

    level: LogLevel
    message: str
    logger_name: str
    timestamp: float = field(default_factory=time.time)
    extra: dict[str, Any] = field(default_factory=dict)
    exc_info: BaseException | None = None
    thread_id: int = field(default_factory=threading.get_ident)
    thread_name: str = field(
        default_factory=lambda: threading.current_thread().name)

    # Context fields
    correlation_id: str | None = None
    context: dict[str, Any] = field(default_factory=dict)

    def with_context(self, **kwargs: Any) -> LogRecord:
        """Return a new record with additional context."""
        new_context = {**self.context, **kwargs}
        return LogRecord(
            level=self.level,
            message=self.message,
            logger_name=self.logger_name,
            timestamp=self.timestamp,
            extra=self.extra,
            exc_info=self.exc_info,
            thread_id=self.thread_id,
            thread_name=self.thread_name,
            correlation_id=self.correlation_id,
            context=new_context,
        )
