"""Main logger implementation."""

from __future__ import annotations

import sys
import threading
import traceback
from typing import Any

from pfroggy.core.levels import Level, LogLevel, parse_level
from pfroggy.core.record import LogRecord
from pfroggy.core.context import get_correlation_id, get_context
from pfroggy.handlers.base import Handler
from pfroggy.filters.base import Filter


class Logger:
    """Main logger class."""

    _loggers: dict[str, Logger] = {}
    _lock = threading.Lock()
    _root: Logger | None = None

    def __init__(
        self,
        name: str | None = None,
        level: LogLevel = Level.DEBUG,
        handlers: list[Handler] | None = None,
        filters: list[Filter] | None = None,
        parent: Logger | None = None,
        propagate: bool = True,
    ) -> None:
        self.name = name or "root"
        self._level = level
        self._handlers: list[Handler] = handlers or []
        self._filters: list[Filter] = filters or []
        self.parent = parent
        self.propagate = propagate
        self._enabled = True

    @classmethod
    def get_logger(cls, name: str | None = None) -> Logger:
        """Get or create a logger by name."""
        if name is None:
            if cls._root is None:
                cls._root = Logger(name="root")
            return cls._root

        with cls._lock:
            if name in cls._loggers:
                return cls._loggers[name]

            # Create logger with parent hierarchy
            parent = cls.get_logger()  # root
            parts = name.split(".")
            for i in range(len(parts) - 1):
                parent_name = ".".join(parts[: i + 1])
                if parent_name not in cls._loggers:
                    cls._loggers[parent_name] = Logger(
                        name=parent_name, parent=parent)
                parent = cls._loggers[parent_name]

            logger = Logger(name=name, parent=parent)
            cls._loggers[name] = logger
            return logger

    @classmethod
    def reset(cls) -> None:
        """Reset all loggers (useful for testing)."""
        with cls._lock:
            cls._loggers.clear()
            cls._root = None

    @property
    def level(self) -> LogLevel:
        """Get effective log level."""
        return self._level

    @level.setter
    def level(self, value: LogLevel | str) -> None:
        """Set log level."""
        self._level = parse_level(value) if isinstance(value, str) else value

    def add_handler(self, handler: Handler) -> Logger:
        """Add a handler. Returns self for chaining."""
        self._handlers.append(handler)
        return self

    def remove_handler(self, handler: Handler) -> None:
        """Remove a handler."""
        self._handlers.remove(handler)

    def add_filter(self, flt: Filter) -> Logger:
        """Add a filter. Returns self for chaining."""
        self._filters.append(flt)
        return self

    def remove_filter(self, flt: Filter) -> None:
        """Remove a filter."""
        self._filters.remove(flt)

    def is_enabled_for(self, level: LogLevel) -> bool:
        """Check if logging is enabled for the given level."""
        return self._enabled and level >= self._level

    def _should_log(self, record: LogRecord) -> bool:
        """Check if record passes all filters."""
        return all(f.filter(record) for f in self._filters)

    def _log(
        self,
        level: LogLevel,
        message: str,
        exc_info: BaseException | None = None,
        **extra: Any,
    ) -> None:
        """Internal log method."""
        if not self.is_enabled_for(level):
            return

        record = LogRecord(
            level=level,
            message=message,
            logger_name=self.name,
            extra=extra,
            exc_info=exc_info,
            correlation_id=get_correlation_id(),
            context=get_context(),
        )

        if not self._should_log(record):
            return

        self._handle(record)

    def _handle(self, record: LogRecord) -> None:
        """Handle a log record."""
        for handler in self._handlers:
            if handler.is_enabled_for(record.level):
                try:
                    handler.emit(record)
                except Exception:
                    # Don't let handler errors break logging
                    sys.stderr.write(
                        f"Error in handler {handler}: {traceback.format_exc()}\n")

        if self.propagate and self.parent:
            self.parent._handle(record)

    # Convenience methods
    def trace(self, message: str, **extra: Any) -> None:
        """Log at TRACE level."""
        self._log(Level.TRACE, message, **extra)

    def debug(self, message: str, **extra: Any) -> None:
        """Log at DEBUG level."""
        self._log(Level.DEBUG, message, **extra)

    def info(self, message: str, **extra: Any) -> None:
        """Log at INFO level."""
        self._log(Level.INFO, message, **extra)

    def warning(self, message: str, **extra: Any) -> None:
        """Log at WARNING level."""
        self._log(Level.WARNING, message, **extra)

    def warn(self, message: str, **extra: Any) -> None:
        """Alias for warning."""
        self.warning(message, **extra)

    def error(self, message: str, exc_info: BaseException | None = None, **extra: Any) -> None:
        """Log at ERROR level."""
        self._log(Level.ERROR, message, exc_info=exc_info, **extra)

    def critical(self, message: str, exc_info: BaseException | None = None, **extra: Any) -> None:
        """Log at CRITICAL level."""
        self._log(Level.CRITICAL, message, exc_info=exc_info, **extra)

    def exception(self, message: str, exc: BaseException | None = None, **extra: Any) -> None:
        """Log an exception at ERROR level."""
        if exc is None:
            exc = sys.exc_info()[1]
        self.error(message, exc_info=exc, **extra)

    def log(self, level: LogLevel | str, message: str, **extra: Any) -> None:
        """Log at arbitrary level."""
        lvl = parse_level(level) if isinstance(level, str) else level
        self._log(lvl, message, **extra)

    def bind(self, **kwargs: Any) -> BoundLogger:
        """Create a bound logger with preset extra fields."""
        return BoundLogger(self, kwargs)


class BoundLogger:
    """A logger with preset extra fields."""

    def __init__(self, logger: Logger, bindings: dict[str, Any]) -> None:
        self._logger = logger
        self._bindings = bindings

    def bind(self, **kwargs: Any) -> BoundLogger:
        """Create a new bound logger with additional bindings."""
        return BoundLogger(self._logger, {**self._bindings, **kwargs})

    def trace(self, message: str, **extra: Any) -> None:
        self._logger.trace(message, **{**self._bindings, **extra})

    def debug(self, message: str, **extra: Any) -> None:
        self._logger.debug(message, **{**self._bindings, **extra})

    def info(self, message: str, **extra: Any) -> None:
        self._logger.info(message, **{**self._bindings, **extra})

    def warning(self, message: str, **extra: Any) -> None:
        self._logger.warning(message, **{**self._bindings, **extra})

    def error(self, message: str, exc_info: BaseException | None = None, **extra: Any) -> None:
        self._logger.error(message, exc_info=exc_info, **
                           {**self._bindings, **extra})

    def critical(self, message: str, exc_info: BaseException | None = None, **extra: Any) -> None:
        self._logger.critical(message, exc_info=exc_info,
                              **{**self._bindings, **extra})
