"""Console handler with optional color support."""

from __future__ import annotations

import sys
from typing import TextIO

from pfroggy.core.levels import Level, LogLevel
from pfroggy.core.record import LogRecord
from pfroggy.handlers.base import Handler
from pfroggy.formatters.base import Formatter

# Try to import colorama for Windows support
try:
    import colorama

    colorama.init()
    HAS_COLORAMA = True
except ImportError:
    HAS_COLORAMA = False


# ANSI escape codes
RESET = "\033[0m"


class Color:
    """ANSI color codes for terminal output."""

    # Standard colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright colors
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

    # Styles
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    # Backgrounds
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"

    RESET = RESET


# Default color scheme - smart defaults based on severity
DEFAULT_COLORS: dict[int, str] = {
    Level.TRACE: Color.DIM + Color.WHITE,
    Level.DEBUG: Color.CYAN,
    Level.INFO: Color.GREEN,
    Level.WARNING: Color.YELLOW,
    Level.ERROR: Color.RED,
    Level.CRITICAL: Color.BOLD + Color.MAGENTA,
}

# Alternative schemes users can choose from
COLOR_SCHEMES: dict[str, dict[int, str]] = {
    "default": DEFAULT_COLORS,
    "minimal": {
        Level.TRACE: Color.DIM,
        Level.DEBUG: "",
        Level.INFO: "",
        Level.WARNING: Color.YELLOW,
        Level.ERROR: Color.RED,
        Level.CRITICAL: Color.BOLD + Color.RED,
    },
    "bold": {
        Level.TRACE: Color.DIM,
        Level.DEBUG: Color.BOLD + Color.CYAN,
        Level.INFO: Color.BOLD + Color.GREEN,
        Level.WARNING: Color.BOLD + Color.YELLOW,
        Level.ERROR: Color.BOLD + Color.RED,
        Level.CRITICAL: Color.BOLD + Color.BG_RED + Color.WHITE,
    },
    "pastel": {
        Level.TRACE: Color.BRIGHT_BLACK,
        Level.DEBUG: Color.BRIGHT_CYAN,
        Level.INFO: Color.BRIGHT_GREEN,
        Level.WARNING: Color.BRIGHT_YELLOW,
        Level.ERROR: Color.BRIGHT_RED,
        Level.CRITICAL: Color.BRIGHT_MAGENTA,
    },
}


class ConsoleHandler(Handler):
    """Handler that writes to console (stdout/stderr) with configurable colors."""

    def __init__(
        self,
        level: LogLevel = Level.DEBUG,
        formatter: Formatter | None = None,
        stream: TextIO | None = None,
        colorize: bool = True,
        colors: dict[int, str] | str | None = None,
        error_stream: TextIO | None = None,
        error_level: LogLevel = Level.ERROR,
    ) -> None:
        """
        Args:
            level: Minimum log level to handle
            formatter: Formatter for log messages
            stream: Output stream (default: stdout)
            colorize: Enable/disable colors
            colors: Color configuration - can be:
                - None: use default color scheme
                - str: name of a preset scheme ("default", "minimal", "bold", "pastel")
                - dict: custom mapping of level -> ANSI color code
            error_stream: Stream for error+ level logs (default: stderr)
            error_level: Minimum level to write to error_stream
        """
        super().__init__(level=level, formatter=formatter)
        self._stream = stream or sys.stdout
        self._error_stream = error_stream or sys.stderr
        self._error_level = error_level
        self._colorize = colorize and self._supports_color()
        self._colors = self._resolve_colors(colors)

    def _resolve_colors(self, colors: dict[int, str] | str | None) -> dict[int, str]:
        """Resolve color configuration to a color mapping."""
        if colors is None:
            return DEFAULT_COLORS.copy()
        if isinstance(colors, str):
            if colors not in COLOR_SCHEMES:
                raise ValueError(
                    f"Unknown color scheme: {colors}. "
                    f"Available: {', '.join(COLOR_SCHEMES.keys())}"
                )
            return COLOR_SCHEMES[colors].copy()
        return colors

    def _supports_color(self) -> bool:
        """Check if terminal supports color."""
        if not hasattr(self._stream, "isatty"):
            return False
        if not self._stream.isatty():
            return HAS_COLORAMA  # colorama can work without tty on Windows
        return True

    def set_color(self, level: LogLevel, color: str) -> None:
        """Set color for a specific level.

        Args:
            level: Log level to configure
            color: ANSI color code (use Color class constants)

        Example:
            handler.set_color(Level.ERROR, Color.BOLD + Color.BG_RED + Color.WHITE)
        """
        self._colors[level] = color

    def set_colors(self, colors: dict[int, str] | str) -> None:
        """Set multiple colors at once.

        Args:
            colors: Either a scheme name or a dict mapping levels to colors
        """
        self._colors = self._resolve_colors(colors)

    def _get_stream(self, record: LogRecord) -> TextIO:
        """Get appropriate stream for record level."""
        if record.level >= self._error_level:
            return self._error_stream
        return self._stream

    def _get_default_formatter(self) -> Formatter:
        """Return cached default formatter."""
        if not hasattr(self, "_default_formatter_cache"):
            from pfroggy.presets import formatter_default
            self._default_formatter_cache = formatter_default()
        return self._default_formatter_cache

    def format(self, record: LogRecord) -> str:
        """Format the record, using default formatter if none set."""
        if self._formatter:
            return self._formatter.format(record)
        return self._get_default_formatter().format(record)

    def emit(self, record: LogRecord) -> None:
        if not self.should_handle(record):
            return

        message = self.format(record)

        if self._colorize:
            color = self._colors.get(record.level, "")
            if color:
                message = f"{color}{message}{RESET}"

        stream = self._get_stream(record)
        stream.write(message + "\n")
        stream.flush()
