"""JSON file handler."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pfroggy.core.levels import Level, LogLevel
from pfroggy.handlers.file import FileHandler
from pfroggy.formatters.json_fmt import JsonFormatter
from pfroggy.formatters.base import Formatter


class JsonFileHandler(FileHandler):
    """Handler that writes JSON-formatted logs to a file."""

    def __init__(
        self,
        filename: str | Path,
        level: LogLevel = Level.DEBUG,
        formatter: Formatter | None = None,
        mode: Literal["a", "w"] = "a",
        encoding: str = "utf-8",
        include_extra: bool = True,
        include_context: bool = True,
    ) -> None:
        # Use provided formatter or create a JsonFormatter
        if formatter is None:
            formatter = JsonFormatter(
                include_extra=include_extra,
                include_context=include_context,
            )
        super().__init__(
            filename=filename,
            level=level,
            formatter=formatter,
            mode=mode,
            encoding=encoding,
        )
