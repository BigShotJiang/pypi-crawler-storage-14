"""Base handler class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from pfroggy.core.levels import Level, LogLevel
from pfroggy.filters.base import Filter

if TYPE_CHECKING:
    from pfroggy.core.record import LogRecord
    from pfroggy.formatters.base import Formatter


class Handler(ABC):
    """Base class for all handlers."""

    def __init__(
        self,
        level: LogLevel = Level.DEBUG,
        formatter: Formatter | None = None,
        filters: list[Filter] | None = None,
    ) -> None:
        self._level = level
        self._formatter = formatter
        self._filters: list[Filter] = filters or []

    @property
    def level(self) -> LogLevel:
        return self._level

    @level.setter
    def level(self, value: LogLevel) -> None:
        self._level = value

    @property
    def formatter(self) -> Formatter | None:
        return self._formatter

    @formatter.setter
    def formatter(self, value: Formatter) -> None:
        self._formatter = value

    def is_enabled_for(self, level: LogLevel) -> bool:
        """Check if handler accepts this level."""
        return level >= self._level

    def add_filter(self, flt: Filter) -> Handler:
        """Add a filter."""
        self._filters.append(flt)
        return self

    def should_handle(self, record: LogRecord) -> bool:
        """Check if record should be handled."""
        return all(f.filter(record) for f in self._filters)

    def format(self, record: LogRecord) -> str:
        """Format the record."""
        if self._formatter:
            return self._formatter.format(record)
        return record.message

    @abstractmethod
    def emit(self, record: LogRecord) -> None:
        """Emit the log record. Must be implemented by subclasses."""
        ...

    def close(self) -> None:
        """Close the handler. Override if cleanup is needed."""
        pass
