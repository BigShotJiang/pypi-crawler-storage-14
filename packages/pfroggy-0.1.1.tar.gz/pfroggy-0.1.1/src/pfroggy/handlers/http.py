"""HTTP handler for remote logging."""

from __future__ import annotations

import json
import queue
import threading
from typing import Any

from pfroggy.core.levels import Level, LogLevel
from pfroggy.core.record import LogRecord
from pfroggy.handlers.base import Handler
from pfroggy.formatters.base import Formatter

try:
    import httpx

    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False


class HttpHandler(Handler):
    """Handler that sends logs to an HTTP endpoint."""

    def __init__(
        self,
        url: str,
        level: LogLevel = Level.DEBUG,
        formatter: Formatter | None = None,
        method: str = "POST",
        headers: dict[str, str] | None = None,
        timeout: float = 5.0,
        batch_size: int = 10,
        flush_interval: float = 5.0,
        async_mode: bool = True,
    ) -> None:
        if not HAS_HTTPX:
            raise ImportError(
                "httpx is required for HttpHandler. Install with: pip install pfroggy[http]")

        super().__init__(level=level, formatter=formatter)
        self._url = url
        self._method = method
        self._headers = headers or {"Content-Type": "application/json"}
        self._timeout = timeout
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._async_mode = async_mode

        self._queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self._client = httpx.Client(timeout=timeout)
        self._shutdown = threading.Event()

        if async_mode:
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    def _record_to_dict(self, record: LogRecord) -> dict[str, Any]:
        """Convert record to dictionary for JSON serialization."""
        from pfroggy.core.levels import get_level_name

        return {
            "timestamp": record.timestamp,
            "level": get_level_name(record.level),
            "logger": record.logger_name,
            "message": record.message,
            "correlation_id": record.correlation_id,
            "context": record.context,
            "extra": record.extra,
            "thread_id": record.thread_id,
            "thread_name": record.thread_name,
        }

    def _send_batch(self, records: list[dict[str, Any]]) -> None:
        """Send a batch of records."""
        try:
            payload = json.dumps(records)
            self._client.request(
                self._method,
                self._url,
                content=payload,
                headers=self._headers,
            )
        except Exception:
            # Silently fail - don't break the application
            pass

    def _worker(self) -> None:
        """Background worker for async sending."""
        batch: list[dict[str, Any]] = []

        while not self._shutdown.is_set():
            try:
                record = self._queue.get(timeout=self._flush_interval)
                batch.append(record)

                if len(batch) >= self._batch_size:
                    self._send_batch(batch)
                    batch = []
            except queue.Empty:
                if batch:
                    self._send_batch(batch)
                    batch = []

        # Flush remaining
        while not self._queue.empty():
            try:
                batch.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if batch:
            self._send_batch(batch)

    def emit(self, record: LogRecord) -> None:
        if not self.should_handle(record):
            return

        data = self._record_to_dict(record)

        if self._async_mode:
            self._queue.put(data)
        else:
            self._send_batch([data])

    def close(self) -> None:
        self._shutdown.set()
        if self._async_mode and self._thread.is_alive():
            self._thread.join(timeout=10)
        self._client.close()
