"""File-based handlers."""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Literal

from pfroggy.core.levels import Level, LogLevel
from pfroggy.core.record import LogRecord
from pfroggy.handlers.base import Handler
from pfroggy.formatters.base import Formatter


class FileHandler(Handler):
    """Handler that writes to a file."""

    def __init__(
        self,
        filename: str | Path,
        level: LogLevel = Level.DEBUG,
        formatter: Formatter | None = None,
        mode: Literal["a", "w"] = "a",
        encoding: str = "utf-8",
    ) -> None:
        super().__init__(level=level, formatter=formatter)
        self._filename = Path(filename)
        self._mode = mode
        self._encoding = encoding
        self._lock = threading.Lock()
        self._file = self._open()

    def _open(self) -> object:
        """Open the file."""
        self._filename.parent.mkdir(parents=True, exist_ok=True)
        return open(self._filename, self._mode, encoding=self._encoding)

    def emit(self, record: LogRecord) -> None:
        if not self.should_handle(record):
            return

        message = self.format(record)
        with self._lock:
            self._file.write(message + "\n")  # type: ignore
            self._file.flush()  # type: ignore

    def close(self) -> None:
        with self._lock:
            if self._file:
                self._file.close()  # type: ignore


class RotatingFileHandler(Handler):
    """Handler that rotates files based on size."""

    def __init__(
        self,
        filename: str | Path,
        level: LogLevel = Level.DEBUG,
        formatter: Formatter | None = None,
        max_bytes: int = 10 * 1024 * 1024,  # 10MB
        backup_count: int = 5,
        encoding: str = "utf-8",
    ) -> None:
        super().__init__(level=level, formatter=formatter)
        self._filename = Path(filename)
        self._max_bytes = max_bytes
        self._backup_count = backup_count
        self._encoding = encoding
        self._lock = threading.Lock()
        self._file: object = None
        self._open()

    def _open(self) -> None:
        self._filename.parent.mkdir(parents=True, exist_ok=True)
        self._file = open(self._filename, "a", encoding=self._encoding)

    def _should_rotate(self) -> bool:
        if self._max_bytes <= 0:
            return False
        try:
            return self._filename.stat().st_size >= self._max_bytes
        except OSError:
            return False

    def _rotate(self) -> None:
        if self._file:
            self._file.close()  # type: ignore

        # Rotate existing backups
        for i in range(self._backup_count - 1, 0, -1):
            src = self._filename.with_suffix(f"{self._filename.suffix}.{i}")
            dst = self._filename.with_suffix(
                f"{self._filename.suffix}.{i + 1}")
            if src.exists():
                if dst.exists():
                    dst.unlink()
                src.rename(dst)

        # Rename current to .1
        dst = self._filename.with_suffix(f"{self._filename.suffix}.1")
        if self._filename.exists():
            if dst.exists():
                dst.unlink()
            self._filename.rename(dst)

        self._open()

    def emit(self, record: LogRecord) -> None:
        if not self.should_handle(record):
            return

        message = self.format(record)
        with self._lock:
            if self._should_rotate():
                self._rotate()
            self._file.write(message + "\n")  # type: ignore
            self._file.flush()  # type: ignore

    def close(self) -> None:
        with self._lock:
            if self._file:
                self._file.close()  # type: ignore
