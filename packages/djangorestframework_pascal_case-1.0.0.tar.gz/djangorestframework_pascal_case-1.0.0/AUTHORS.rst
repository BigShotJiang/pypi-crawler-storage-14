=======
Credits
=======

Development Lead
----------------

* Chris

Original Library
----------------

This is a fork of `djangorestframework-camel-case <https://github.com/vbabiy/djangorestframework-camel-case>`_
by Vitaly Babiy <vbabiy86@gmail.com>.