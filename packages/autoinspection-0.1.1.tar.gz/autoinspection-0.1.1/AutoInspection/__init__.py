# from .auto_inspection2 import AutoInspection
from .auto_inspection import AutoInspection
from .training import training

__version__ = '0.1.1'
