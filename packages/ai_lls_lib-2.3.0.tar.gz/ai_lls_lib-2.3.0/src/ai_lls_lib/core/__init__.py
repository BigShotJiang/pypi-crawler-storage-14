"""
Core business logic modules
"""
