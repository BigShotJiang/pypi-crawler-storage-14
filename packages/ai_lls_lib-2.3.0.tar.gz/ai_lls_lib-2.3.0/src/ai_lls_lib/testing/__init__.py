"""
Testing utilities and fixtures
"""
