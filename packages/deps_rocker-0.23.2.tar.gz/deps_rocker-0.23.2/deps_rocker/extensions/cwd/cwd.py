import os
import pwd
import logging
from pathlib import Path
import re
from deps_rocker.simple_rocker_extension import SimpleRockerExtension


class CWD(SimpleRockerExtension):
    """Mount the current working directory inside the container's home directory at ~/project_name"""

    name = "cwd"
    depends_on_extension = ("user",)

    def get_docker_args(self, cliargs) -> str:
        """
        Mount the current working directory inside the container's home directory
        at ~/project_name and set the working directory to that location.
        """
        # Get the container home directory from user extension
        container_home = cliargs.get("user_home_dir") or pwd.getpwuid(os.getuid()).pw_dir
        if not container_home:
            logging.warning(
                "Could not determine container home directory. Cannot mount CWD to home."
            )
            return ""

        # Get the current working directory and its name
        host_cwd = Path.cwd()
        project_name = host_cwd.name

        # Mount CWD inside container home (e.g., ~/projectA) and set working directory to it
        container_project_path = f"{container_home}/{project_name}"
        return f' -v "{host_cwd}:{container_project_path}" -w "{container_project_path}"'

    def invoke_after(self, cliargs) -> set:
        return {"user"}

    def get_snippet(self, cliargs) -> str:
        """
        Add a Dockerfile snippet to create mount point with proper permissions.
        The mounted volume will be made accessible to all users.
        """
        container_home = cliargs.get("user_home_dir") or pwd.getpwuid(os.getuid()).pw_dir
        host_cwd = Path.cwd()
        project_name = host_cwd.name
        container_project_path = f"{container_home}/{project_name}"

        return f"""
# Set up mount point for CWD with proper permissions
# Create the directory structure with world-writable permissions
# This ensures the mounted volume is accessible regardless of which user runs the container
RUN mkdir -p "{container_project_path}" && \\
    chmod 777 "{container_project_path}"
"""


class CWDName(SimpleRockerExtension):
    """Set the name of the container to the name of the folder of the current working directory"""

    name = "cwd_name"

    def get_docker_args(self, cliargs) -> str:
        return f" --name {Path.cwd().stem}"

    @staticmethod
    def sanitize_container_name(name: str) -> str:
        """
        Sanitizes the container name to conform to Docker's requirements.

        Args:
            name (str): The original name, typically from the current working directory.

        Returns:
            str: A sanitized name that only includes alphanumeric characters, dots, and dashes.

        Raises:
            ValueError: If the sanitized name is empty after sanitization.
        """
        # Replace invalid characters with dashes
        sanitized = re.sub(r"[^a-zA-Z0-9.-]", "-", name)

        # Ensure the name is not empty after sanitization
        if not sanitized.strip("-"):
            raise ValueError(
                f"The sanitized container name '{name}' is invalid. Ensure the working directory name contains valid characters."
            )

        return sanitized
