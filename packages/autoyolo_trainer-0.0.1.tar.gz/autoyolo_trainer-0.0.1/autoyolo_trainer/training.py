from ultralytics import YOLO
from .model_downloader import download_model
from .augmentation import get_augmentations
import yaml


def train_yolo(dataset_yaml, epochs=50, imgsz=640):
    """
    Train a custom YOLO model using dataset YAML and augmentations.

    Args:
        dataset_yaml (str): Path to dataset yaml
        epochs (int): Epoch count
        imgsz (int): Image size
    """
    # Validate dataset YAML
    try:
        with open(dataset_yaml) as f:
            yaml.safe_load(f)
    except Exception as e:
        raise ValueError(f"Invalid dataset YAML: { e }")

    print("[AUTOYOLO] Downloading base model…")
    model = download_model()

    print("[AUTOYOLO] Applying custom augmentations…")
    aug = get_augmentations()

    results = model.train(
        data=dataset_yaml,
        epochs=epochs,
        imgsz=imgsz,
        project="autoyolo_output",
        name="custom_training",
        pretrained=True,
        augmentations=aug
    )

    print("[AUTOYOLO] Training Completed!")
    return results
