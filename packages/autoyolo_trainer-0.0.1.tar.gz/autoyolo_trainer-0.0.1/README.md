# AutoYOLO Trainer
A simple Python package to train YOLO models automatically with custom augmentations.

## Usage
```python
from autoyolo_trainer import train_yolo

train_yolo("path/to/dataset.yaml", epochs=50)
pgsql
Copy code

---