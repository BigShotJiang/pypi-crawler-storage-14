from setuptools import setup, find_packages

setup(
    name="autoyolo-trainer",
    version="0.0.1",
    author="Jagadeeshwaran",
    description="Auto YOLO Trainer with custom augmentations and model downloader",
    packages=find_packages(),
    install_requires=[
        "ultralytics",
        "opencv-python",
        "numpy",
        "pillow"
    ],
    python_requires=">=3.8",
)