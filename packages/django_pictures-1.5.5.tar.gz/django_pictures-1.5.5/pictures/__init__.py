"""Responsive cross-browser image library using modern codes like AVIF & WebP."""

from . import _version

__version__ = _version.version
VERSION = _version.version_tuple
