# Permanent Variable Tool
### 中文文档请往下查看
---
## `var.new(variable:str, value:Any=None) -> None`
Functionality

Creates/updates variable files in `./data/` directory 
### Usage Example 
```python
var.new("user_profile", {"name": "John", "age": 28})  # Serializes to string 
var.new("system_flag")   # Creates empty file 
```
---
## `var.read(variable:str) -> str`
### Critical Notes
- Always wrap in try-except:
```python 
try:
    config = var.read("app_config")
except FileNotFoundError:
    initialize_defaults()
```
---
## `var.delete(variable:str) -> None`
### Security Notice 
- Deletion is permanent. Recommended safety check:
```python 
if os.path.exists(var.data_dir + "/" + variable + ".var"):
    var.delete("temp_data") 
```
---
---

# 永久变量工具 (Permanent Variable Tool)
### Please check the English documents up.
---
## `var.new(变量名:str, 值:Any=None) -> None`
功能 
在`./data/`目录中创建/更新变量文件
### 使用示例 
```python
var.new("user_profile", {"name": "张三", "age": 28})  # 序列化为字符串 
var.new("system_flag")   # 创建空文件
```
--- 
## `var.read(变量名:str) -> str`
### 重要说明 
- 必须使用try-except包裹:
```python 
try:
    config = var.read("app_config")
except FileNotFoundError:
    initialize_defaults()
```
---
## `var.delete(变量名:str) -> None`
### 安全提示 
- 删除操作不可逆。建议进行安全检查:
```python 
if os.path.exists(var.data_dir + "/" + variable + ".var"):
    var.delete("temp_data")
```