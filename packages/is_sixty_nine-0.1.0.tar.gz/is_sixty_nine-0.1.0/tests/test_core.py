from is_sixty_nine import is_sixty_nine


def test_exact_69():
    assert is_sixty_nine(69)
    assert is_sixty_nine("69")


def test_not_69():
    assert not is_sixty_nine(70)
    assert not is_sixty_nine("68")
    assert not is_sixty_nine(None)
    assert not is_sixty_nine("not a number")
