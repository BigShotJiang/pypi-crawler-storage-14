# is-sixty-nine

Tiny Python utility to answer one important question: is it 69?

## Installation

```bash
pip install is-sixty-nine
```
