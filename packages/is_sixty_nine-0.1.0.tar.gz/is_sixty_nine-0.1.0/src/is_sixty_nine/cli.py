import argparse
from .core import is_sixty_nine


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="is-sixty-nine",
        description="Check if a given value is 69.",
    )
    parser.add_argument("value", help="Value to check")
    args = parser.parse_args()

    if is_sixty_nine(args.value):
        print("YES: the value you entered is 69.")
    else:
        print("NO: the value you entered is not 69.")
