def is_sixty_nine(value) -> bool:
    """
    Return True if the number is 69, False otherwise.
    """
    try:
        number = int(value)
    except (TypeError, ValueError):
        return False

    return number == 69
