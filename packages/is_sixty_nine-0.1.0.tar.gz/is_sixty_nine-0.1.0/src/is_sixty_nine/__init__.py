from .core import is_sixty_nine

__all__ = ["is_sixty_nine"]
