# datacrunch is now verda

This package has been renamed to `verda`. Use `pip install verda` or `uv add verda` instead.

To migrate from `datacrunch`, follow [the migration guide](https://github.com/verda-cloud/sdk-python/blob/master/MIGRATION.md).

New package: https://pypi.org/project/verda/
