class UserNotFoundException(Exception):
    """Raised when user UUID is not found in the cookie service."""

    pass
