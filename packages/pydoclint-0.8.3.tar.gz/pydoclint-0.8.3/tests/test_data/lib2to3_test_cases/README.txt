The test cases in this folder comes from Python's officiel lib2to3 test cases:
https://github.com/python/cpython/tree/11b89094129e4f16705805956e00868e8c924336/Lib/test/test_lib2to3/data
