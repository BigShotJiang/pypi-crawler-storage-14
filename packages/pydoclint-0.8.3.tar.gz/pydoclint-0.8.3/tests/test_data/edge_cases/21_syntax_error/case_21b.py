# Python 2 syntax
print 'haha'
