a =  # this is a comment
b =
c +
e = '
f
