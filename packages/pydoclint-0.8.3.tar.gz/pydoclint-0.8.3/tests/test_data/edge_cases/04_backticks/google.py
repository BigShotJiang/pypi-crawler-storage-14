def someFunc(arg1: int, arg2: bool) -> str:
    """
    Do something.

    Args:
        arg1 (`int`): Arg 1
        arg2 (``bool``): Arg 2

    Returns:
        `str`: Return value
    """
    pass
