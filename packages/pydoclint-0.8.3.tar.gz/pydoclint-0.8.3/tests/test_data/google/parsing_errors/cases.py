class A:
    """
    Some class

    Args:
        arg1
        arg2
    """

    def __init__(self):
        pass

    def method1(self, arg3: int) -> int:
        """
        Do something

        Args:
            arg3 (int): arg3

        Returns:
            int: The return value
        """
        return 2
