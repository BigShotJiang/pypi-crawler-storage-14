def myFunc(arg1: str):
    """
    This is a docstring.

    This function does something very fancy. Yes, it does! But I don't think
    :class:`something` so I can remember what it does.
    """
    pass
