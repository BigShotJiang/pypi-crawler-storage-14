from typing import Dict, Tuple


class A:
    def __init__(self, *args: Tuple, **kwargs: Dict) -> None:
        """
        Do something.

        Parameters
        ----------
        *args :
            Args
        **kwargs :
            Keyword args
        """
        pass
