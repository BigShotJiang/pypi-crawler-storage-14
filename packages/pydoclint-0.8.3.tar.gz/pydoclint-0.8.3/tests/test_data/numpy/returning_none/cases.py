def func(arg1: int) -> None:
    """
    Do something

    Parameters
    ----------
    arg1 : int
        Arg 1
    """
    print(1)
