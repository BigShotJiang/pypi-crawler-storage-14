def func(arg1: int) -> None:
    """
    Do something

    :param arg1: Arg 1
    :type arg1: int
    """
    print(1)
