class A:
    """
    Some class

    param: arg1
    param: arg2
    """

    def __init__(self):
        pass

    def method1(self, arg3: int) -> int:
        """
        Do something

        :param arg3: arg3
        :type arg3: int
        :return: The return value
        :rtype: int
        """
        return 2
