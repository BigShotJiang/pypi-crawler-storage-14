class EdgeCaseError(Exception):
    """Errors from edge cases"""
