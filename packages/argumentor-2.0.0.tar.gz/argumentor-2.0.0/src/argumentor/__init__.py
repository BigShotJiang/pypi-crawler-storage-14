# argumentor - a lightweight & copylefted library to work with command-line arguments
# Copyright (C) 2021-2025 Camelia Lavender <camelia@tblock.me>

"""Main argumentor package."""

from gettext import textdomain
from typing import Tuple, Dict, Iterable
from .builder import Builder
from .const import Flags
from .helper import Helper
from .parser import Parser

textdomain("argumentor")

__all__ = ("__version__", "Argumentor", "Flags")
__version__ = "2.0.0"


class Argumentor(Builder):  # pragma: no cover
    """Argumentor object."""

    def get_help(self, *args, **kwargs) -> str:
        """Generate help page for the command-line interface.

        Args:
            single_command: print only given command (use '' to print all commands)
            print_global_options: print global options (default: True)
            print_all_options: print ALL options (default: False)
            print_options_for_command: print options available with given command
            show_hidden: show hidden commands/options as well (default: hide them)

        Returns:
            a formatted help page
        """
        helper = Helper(self)
        return helper.format_help(*args, **kwargs)

    def parse(self, args: Iterable[str] | None = None) -> Tuple[Dict, Dict]:
        """Parse command-line arguments.

        Args:
            args: the command-line arguments to parse

        Raises:
            ParsingError: when user input contains error (i.e. unexpected argument,
                mandatory options omitted, etc.)

        Returns:
            two dicts, one containing the command and its value(s), the other one containing
            options and their value(s)
        """
        parser = Parser(self, args)
        return parser.parse()
