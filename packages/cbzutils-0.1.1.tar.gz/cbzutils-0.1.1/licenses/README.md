# Licenses for files vendored

opensans.ttf is vendored into the package and hence the sublicense for the same is provided in (LICENSE-opensans.ttf-.txt)
