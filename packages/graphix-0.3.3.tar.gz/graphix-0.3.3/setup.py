"""Blank setup.py for backward compatibility."""

from __future__ import annotations

from setuptools import setup

setup()
