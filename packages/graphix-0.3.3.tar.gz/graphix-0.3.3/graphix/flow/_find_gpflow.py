"""Pauli flow finding algorithm.

This module implements the algorithm presented in [1]. For a given labelled open graph (G, I, O, meas_plane), this algorithm finds a maximally delayed Pauli flow [2] in polynomial time with the number of nodes, :math:`O(N^3)`.
If the input graph does not have Pauli measurements, the algorithm returns a generalised flow (gflow) if it exists by definition.

References
----------
[1] Mitosek and Backens, 2024 (arXiv:2410.23439).
[2] Browne et al., 2007 New J. Phys. 9 250 (arXiv:quant-ph/0702212)
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from functools import cached_property
from typing import TYPE_CHECKING, Generic, TypeVar

import numpy as np
from typing_extensions import override

from graphix._linalg import MatGF2, solve_f2_linear_system
from graphix.fundamentals import AbstractMeasurement, AbstractPlanarMeasurement, Axis, Plane
from graphix.sim.base_backend import NodeIndex

if TYPE_CHECKING:
    from collections.abc import Set as AbstractSet

    from graphix.opengraph import OpenGraph


_M_co = TypeVar("_M_co", bound=AbstractMeasurement, covariant=True)
_PM_co = TypeVar("_PM_co", bound=AbstractPlanarMeasurement, covariant=True)


class AlgebraicOpenGraph(Generic[_M_co]):
    """A class for providing an algebraic representation of open graphs as introduced in [1]. In particular, it allows managing the mapping between node labels of the graph and the relevant matrix indices. The flow-demand and order-demand matrices are cached properties.

    It reuses the class `:class: graphix.sim.base_backend.NodeIndex` introduced for managing the mapping between node numbers and qubit indices in the internal state of the backend.

    Attributes
    ----------
        og (OpenGraph)
        non_inputs (NodeIndex) : Mapping between matrix indices and non-input nodes (labelled with integers).
        non_outputs (NodeIndex) : Mapping between matrix indices and non-output nodes (labelled with integers).
        non_outputs_optim (NodeIndex) : Mapping between matrix indices and a subset of non-output nodes (labelled with integers).

    Notes
    -----
    At initialization, `non_outputs_optim` is a copy of `non_outputs`. The nodes corresponding to zero-rows of the order-demand matrix are removed for calculating the :math:`P` matrix more efficiently in the `:func: _compute_correction_matrix_general` routine.

    References
    ----------
    [1] Mitosek and Backens, 2024 (arXiv:2410.23439).
    """

    def __init__(self, og: OpenGraph[_M_co]) -> None:
        """Initialize AlgebraicOpenGraph objects.

        Parameters
        ----------
        og : OpenGraph[_M_co]
            The open graph in its standard representation.
        """
        self.og = og
        nodes = set(og.graph.nodes)

        # Nodes don't need to be sorted. We do it for debugging purposes, so we can check the matrices in intermediate steps of the algorithm.

        nodes_non_input = sorted(nodes - set(og.input_nodes))
        nodes_non_output = sorted(nodes - set(og.output_nodes))

        self.non_inputs = NodeIndex()
        self.non_inputs.extend(nodes_non_input)

        self.non_outputs = NodeIndex()
        self.non_outputs.extend(nodes_non_output)

        # Needs to be a deep copy because it may be modified during runtime.
        self.non_outputs_optim = deepcopy(self.non_outputs)

    @property
    def flow_demand_matrix(self) -> MatGF2:
        """Return the flow-demand matrix.

        Returns
        -------
        MatGF2
            Flow-demand matrix

        Notes
        -----
        See Definition 3.4 and Algorithm 1 in Mitosek and Backens, 2024 (arXiv:2410.23439).
        """
        return self._og_matrices[0]

    @property
    def order_demand_matrix(self) -> MatGF2:
        """Return the flow-demand matrix.

        Returns
        -------
        MatGF2
            Order-demand matrix

        Notes
        -----
        See Definition 3.5 and Algorithm 1 in Mitosek and Backens, 2024 (arXiv:2410.23439).
        """
        return self._og_matrices[1]

    def _compute_reduced_adj(self) -> MatGF2:
        r"""Return the reduced adjacency matrix (RAdj) of the open graph.

        Returns
        -------
        adj_red : MatGF2
            Reduced adjacency matrix.

        Notes
        -----
        The adjacency matrix of a graph :math:`Adj_G` is an :math:`n \times n` matrix.

        The RAdj matrix of an open graph OG is an :math:`(n - n_O) \times (n - n_I)` submatrix of :math:`Adj_G` constructed by removing the output rows and input columns of :math:`Adj_G`.

        See Definition 3.3 in Mitosek and Backens, 2024 (arXiv:2410.23439).
        """
        graph = self.og.graph
        row_tags = self.non_outputs
        col_tags = self.non_inputs

        adj_red = np.zeros((len(row_tags), len(col_tags)), dtype=np.uint8).view(MatGF2)

        for n1, n2 in graph.edges:
            for u, v in ((n1, n2), (n2, n1)):
                if u in row_tags and v in col_tags:
                    i, j = row_tags.index(u), col_tags.index(v)
                    adj_red[i, j] = 1

        return adj_red

    @cached_property
    def _og_matrices(self) -> tuple[MatGF2, MatGF2]:
        r"""Construct the flow-demand and order-demand matrices.

        Returns
        -------
        flow_demand_matrix : MatGF2
        order_demand_matrix : MatGF2

        Notes
        -----
        - See Definitions 3.4 and 3.5, and Algorithm 1 in Mitosek and Backens, 2024 (arXiv:2410.23439).
        """
        flow_demand_matrix = self._compute_reduced_adj()
        order_demand_matrix = flow_demand_matrix.copy()

        inputs_set = set(self.og.input_nodes)

        row_tags = self.non_outputs
        col_tags = self.non_inputs

        for v in row_tags:  # v is a node tag
            i = row_tags.index(v)
            plane_axis_v = self._get_measurement_label(v)

            if plane_axis_v in {Plane.YZ, Plane.XZ, Axis.Z}:
                flow_demand_matrix[i, :] = 0  # Set row corresponding to node v to 0
            if plane_axis_v in {Plane.YZ, Plane.XZ, Axis.Y, Axis.Z} and v not in inputs_set:
                j = col_tags.index(v)
                flow_demand_matrix[i, j] = 1  # Set element (v, v) = 0
            if plane_axis_v in {Plane.XY, Axis.X, Axis.Y, Axis.Z}:
                order_demand_matrix[i, :] = 0  # Set row corresponding to node v to 0
            if plane_axis_v in {Plane.XY, Plane.XZ} and v not in inputs_set:
                j = col_tags.index(v)
                order_demand_matrix[i, j] = 1  # Set element (v, v) = 1

        return flow_demand_matrix, order_demand_matrix

    def _get_measurement_label(self, node: int) -> Plane | Axis:
        """Return the measurement label (plane or axis) of a node in the open graph.

        Parameters
        ----------
        node : int
            Measured node.

        Returns
        -------
        Plane | Axis
            Measurement label.

        Notes
        -----
        Measurements with a Pauli angle are intepreted as `Axis` instances.
        """
        return self.og.measurements[node].to_plane_or_axis()


class PlanarAlgebraicOpenGraph(AlgebraicOpenGraph[_PM_co]):
    """A subclass of `AlgebraicOpenGraph`.

    This class differs from its parent class only in that Pauli measurements are interpreted as `Plane` instances (instead of `Axis`) when constructing the flow-demand and order-demand matrices. This allows to verify if open graphs with measurements along Pauli angles interpreted as planes have generalised flow.

    """

    @override
    def _get_measurement_label(self, node: int) -> Plane:
        """Return the measurement label (plane) of a node in the open graph.

        Parameters
        ----------
        node : int
            Measured node.

        Returns
        -------
        Plane
            Measurement label.

        Notes
        -----
        Measurements with a Pauli angle are intepreted as `Plane` instances.
        """
        return self.og.measurements[node].to_plane()


@dataclass(frozen=True)  # `NamedTuple` does not support multiple inheritance in Python 3.9 and 3.10
class CorrectionMatrix(Generic[_M_co]):
    r"""A dataclass to bundle the correction matrix and its associated open graph.

    Attributes
    ----------
        aog (AgebraicOpenGraph) : Open graph in an algebraic representation.
        c_matrix (MatGF2) : Matrix encoding the correction function of a Pauli (or generalised) flow, :math:`C`.

    Notes
    -----
    The correction matrix :math:`C` is an :math:`(n - n_I) \times (n - n_O)` matrix related to the correction function :math:`c(v) = \{u \in I^c|C_{u,v} = 1\}`, where :math:`I^c` are the non-input nodes of `aog`. In other words, the column :math:`v` of :math:`C` encodes the correction set of :math:`v`, :math:`c(v)`.

    See Definition 3.6 in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """

    aog: AlgebraicOpenGraph[_M_co]
    c_matrix: MatGF2

    def to_correction_function(self) -> dict[int, frozenset[int]]:
        r"""Transform the correction matrix into a correction function.

        Returns
        -------
        correction_function : dict[int, frozenset[int]]
            Pauli (or generalised) flow correction function. `correction_function[i]` is the set of qubits correcting the measurement of qubit `i`.
        """
        row_tags = self.aog.non_inputs
        col_tags = self.aog.non_outputs
        correction_function: dict[int, frozenset[int]] = {}
        for node in col_tags:
            i = col_tags.index(node)
            correction_set = {row_tags[j] for j in np.flatnonzero(self.c_matrix[:, i])}
            correction_function[node] = frozenset(correction_set)
        return correction_function


def _compute_p_matrix(aog: AlgebraicOpenGraph[_M_co], nb_matrix: MatGF2) -> MatGF2 | None:
    r"""Perform the steps 8 - 12 of the general case (larger number of outputs than inputs) algorithm.

    Parameters
    ----------
    aog : AlgebraicOpenGraph
        Open graph for which the matrix :math:`P` is computed.
    nb_matrix : MatGF2
        Matrix :math:`N_B`

    Returns
    -------
    p_matrix : MatGF2
        Matrix encoding the correction function.

    or `None`
        if the input open graph does not have Pauli flow.

    Notes
    -----
    See Theorem 4.4, steps 8 - 12 in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    n_no = len(aog.non_outputs)  # number of columns of P matrix.
    n_oi_diff = len(aog.og.output_nodes) - len(aog.og.input_nodes)  # number of rows of P matrix.
    n_no_optim = len(aog.non_outputs_optim)  # number of rows and columns of the third block of the K_{LS} matrix.

    # Steps 8, 9 and 10
    kils_matrix = np.concatenate(
        (nb_matrix[:, n_no:], nb_matrix[:, :n_no], np.eye(n_no_optim, dtype=np.uint8)), axis=1
    ).view(MatGF2)  # N_R | N_L | 1 matrix.
    kls_matrix = kils_matrix.gauss_elimination(ncols=n_oi_diff, copy=True)  # RREF form is not needed, only REF.

    # Step 11
    p_matrix = np.zeros((n_oi_diff, n_no), dtype=np.uint8).view(MatGF2)
    solved_nodes: set[int] = set()
    non_outputs_set = set(aog.non_outputs)

    # Step 12
    while solved_nodes != non_outputs_set:
        solvable_nodes = _find_solvable_nodes(aog, kls_matrix, non_outputs_set, solved_nodes, n_oi_diff)  # Step 12.a
        if not solvable_nodes:
            return None

        _update_p_matrix(aog, kls_matrix, p_matrix, solvable_nodes, n_oi_diff)  # Steps 12.b, 12.c
        _update_kls_matrix(aog, kls_matrix, kils_matrix, solvable_nodes, n_oi_diff, n_no, n_no_optim)  # Step 12.d
        solved_nodes.update(solvable_nodes)

    return p_matrix


def _find_solvable_nodes(
    aog: AlgebraicOpenGraph[_M_co],
    kls_matrix: MatGF2,
    non_outputs_set: AbstractSet[int],
    solved_nodes: AbstractSet[int],
    n_oi_diff: int,
) -> set[int]:
    """Return the set nodes whose associated linear system is solvable.

    A node is solvable if:
        - It has not been solved yet.
        - Its column in the second block of :math:`K_{LS}` (which determines the constants in each equation) has only zeros where it intersects rows for which all the coefficients in the first block are 0s.

    See Theorem 4.4, step 12.a in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    solvable_nodes: set[int] = set()

    row_idxs = np.flatnonzero(
        ~kls_matrix[:, :n_oi_diff].any(axis=1)
    )  # Row indices of the 0-rows in the first block of K_{LS}.
    if row_idxs.size:
        for v in non_outputs_set - solved_nodes:
            j = n_oi_diff + aog.non_outputs.index(v)  # `n_oi_diff` is the column offset from the first block of K_{LS}.
            if not kls_matrix[row_idxs, j].any():
                solvable_nodes.add(v)
    else:
        # If the first block of K_{LS} does not have 0-rows, all non-solved nodes are solvable.
        solvable_nodes = set(non_outputs_set - solved_nodes)

    return solvable_nodes


def _update_p_matrix(
    aog: AlgebraicOpenGraph[_M_co],
    kls_matrix: MatGF2,
    p_matrix: MatGF2,
    solvable_nodes: AbstractSet[int],
    n_oi_diff: int,
) -> None:
    """Update `p_matrix`.

    The solution of the linear system associated with node :math:`v` in `solvable_nodes` corresponds to the column of `p_matrix` associated with node :math:`v`.

    See Theorem 4.4, steps 12.b and 12.c in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    for v in solvable_nodes:
        j = aog.non_outputs.index(v)
        j_shift = n_oi_diff + j  # `n_oi_diff` is the column offset from the first block of K_{LS}.
        mat = MatGF2(kls_matrix[:, :n_oi_diff])  # First block of K_{LS}, in row echelon form.
        b = MatGF2(kls_matrix[:, j_shift])
        x = solve_f2_linear_system(mat, b)
        p_matrix[:, j] = x


def _update_kls_matrix(
    aog: AlgebraicOpenGraph[_M_co],
    kls_matrix: MatGF2,
    kils_matrix: MatGF2,
    solvable_nodes: AbstractSet[int],
    n_oi_diff: int,
    n_no: int,
    n_no_optim: int,
) -> None:
    """Update `kls_matrix`.

    Bring the linear system encoded in :math:`K_{LS}` to the row-echelon form (REF) that would be achieved by Gaussian elimination if the row and column vectors corresponding to vertices in `solvable_nodes` where not included in the starting matrix.

    See Theorem 4.4, step 12.d in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    shift = n_oi_diff + n_no  # `n_oi_diff` + `n_no` is the column offset from the first two blocks of K_{LS}.
    row_permutation: list[int]

    def reorder(old_pos: int, new_pos: int) -> None:  # Used in step 12.d.vi
        """Reorder the elements of `row_permutation`.

        The element at `old_pos` is placed on the right of the element at `new_pos`.
        Example:
        ```
        row_permutation = [0, 1, 2, 3, 4]
        reorder(1, 3) -> [0, 2, 3, 1, 4]
        reorder(2, -1) -> [2, 0, 1, 3, 4]
        ```
        """
        val = row_permutation.pop(old_pos)
        row_permutation.insert(new_pos + (new_pos < old_pos), val)

    for v in solvable_nodes:
        if (
            v in aog.non_outputs_optim
        ):  # if `v` corresponded to a zero row in N_B, it was not present in `kls_matrix` because we removed it in the optimization process, so there's no need to do Gaussian elimination for that vertex.
            # Step 12.d.ii
            j = aog.non_outputs_optim.index(v)
            j_shift = shift + j
            row_idxs = np.flatnonzero(
                kls_matrix[:, j_shift]
            ).tolist()  # Row indices with 1s in column of node `v` in third block.

            # `row_idxs` can't be empty:
            # The third block of K_{LS} is initially the identity matrix, so all columns have initially a 1. Row permutations and row additions in the Gaussian elimination routine can't remove all 1s from a given column.
            k = row_idxs.pop()

            # Step 12.d.iii
            kls_matrix[row_idxs] ^= kls_matrix[k]  # Adding a row to previous rows preserves REF.

            # Step 12.d.iv
            kls_matrix[k] ^= kils_matrix[j]  # Row `k` may now break REF.

            # Step 12.d.v
            pivots: list[np.int_] = []  # Store pivots for next step.
            for i, row in enumerate(kls_matrix):
                if i != k:
                    col_idxs = np.flatnonzero(row[:n_oi_diff])  # Column indices with 1s in first block.
                    if col_idxs.size == 0:
                        # Row `i` has all zeros in the first block. Only row `k` can break REF, so rows below have all zeros in the first block too.
                        break
                    pivots.append(p := col_idxs[0])
                    if kls_matrix[k, p]:  # Row `k` has a 1 in the column corresponding to the leading 1 of row `i`.
                        kls_matrix[k] ^= row

            row_permutation = list(range(n_no_optim))  # Row indices of `kls_matrix`.
            n_pivots = len(pivots)

            col_idxs = np.flatnonzero(kls_matrix[k, :n_oi_diff])
            pk = col_idxs[0] if col_idxs.size else None  # Pivot of row `k`.

            if pk and k >= n_pivots:  # Row `k` is non-zero in the FB (first block) and it's among zero rows.
                # Find row `new_pos` s.t. `pivots[new_pos] <= pk < pivots[new_pos+1]`.
                new_pos = (
                    int(np.argmax(np.array(pivots) > pk) - 1) if pivots else -1
                )  # `pivots` can be empty. If so, we bring row `k` to the top since it's non-zero.
            elif pk:  # Row `k` is non-zero in the FB and it's among non-zero rows.
                # Find row `new_pos` s.t. `pivots[new_pos] <= pk < pivots[new_pos+1]`
                new_pos = int(np.argmax(np.array(pivots) > pk) - 1)
                # We skipped row `k` in loop of step 12.d.v, so `pivots[j]` can be the pivot of row `j` or `j+1`.
                if new_pos >= k:
                    new_pos += 1
            elif k < n_pivots:  # Row `k` is zero in the first block and it's among non-zero rows.
                new_pos = (
                    n_pivots  # Move row `k` to the top of the zeros block (i.e., below the row of the last pivot).
                )
            else:  # Row `k` is zero in the first block and it's among zero rows.
                new_pos = k  # Do nothing.

            if new_pos != k:
                reorder(k, new_pos)  # Modify `row_permutation` in-place.
                kls_matrix[:] = kls_matrix[
                    row_permutation
                ]  # `[:]` is crucial to modify the data pointed by `kls_matrix`.


def _compute_correction_matrix_general_case(
    aog: AlgebraicOpenGraph[_M_co], flow_demand_matrix: MatGF2, order_demand_matrix: MatGF2
) -> MatGF2 | None:
    r"""Construct the generalized correction matrix :math:`C'C^B` for an open graph with larger number of outputs than inputs.

    Parameters
    ----------
    aog : AlgebraicOpenGraph
        Open graph for which :math:`C'C^B` and :math:`NC'C^B` are computed.
    flow_demand_matrix: MatGF2
        Flow demand matrix :math:`M` (a property of the open graph).
    order_demand_matrix: MatGF2
        Order demand matrix :math:`N` (a property of the open graph).

    Returns
    -------
    correction_matrix : MatGF2
        Matrix encoding the correction function.

    or `None`
        if the input open graph does not have Pauli flow.

    Notes
    -----
    - The function returns `None` if
        a) The flow-demand matrix is not invertible, or
        b) Not all linear systems of equations associated to the non-output nodes are solvable,
    meaning that `aog` does not have Pauli flow.
    Condition (b) is satisfied when the flow-demand matrix :math:`M` does not have a right inverse :math:`C` such that :math:`NC` represents a directed acyclical graph (DAG).

    See Theorem 4.4 and Algorithm 3 in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    n_no = len(aog.non_outputs)
    n_oi_diff = len(aog.og.output_nodes) - len(aog.og.input_nodes)

    # Steps 3 and 4
    correction_matrix_0 = flow_demand_matrix.right_inverse()  # C0 matrix.
    if correction_matrix_0 is None:
        return None  # The flow-demand matrix is not invertible, therefore there's no flow.

    # Steps 5, 6 and 7
    ker_flow_demand_matrix = flow_demand_matrix.null_space().transpose()  # F matrix.
    c_prime_matrix = np.concatenate((correction_matrix_0, ker_flow_demand_matrix), axis=1).view(MatGF2)

    row_idxs = np.flatnonzero(order_demand_matrix.any(axis=1))  # Row indices of the non-zero rows.

    if row_idxs.size:
        # The p-matrix finding algorithm runs on the `order_demand_matrix` without the zero rows.
        # This optimization is allowed because:
        #   - The zero rows remain zero after the change of basis (multiplication by `c_prime_matrix`).
        #   - The zero rows remain zero after gaussian elimination.
        #   - Removing the zero rows does not change the solvability condition of the open graph nodes.
        nb_matrix_optim = (
            order_demand_matrix[row_idxs].view(MatGF2).mat_mul(c_prime_matrix)
        )  # `view` is used to keep mypy happy without copying data.
        for i in set(range(order_demand_matrix.shape[0])).difference(row_idxs):
            aog.non_outputs_optim.remove(aog.non_outputs[i])  # Update the node-index mapping.

        # Steps 8 - 12
        if (p_matrix := _compute_p_matrix(aog, nb_matrix_optim)) is None:
            return None
    else:
        # If all rows of `order_demand_matrix` are zero, any matrix will solve the associated linear system of equations.
        p_matrix = np.zeros((n_oi_diff, n_no), dtype=np.uint8).view(MatGF2)

    # Step 13
    cb_matrix = np.concatenate((np.eye(n_no, dtype=np.uint8), p_matrix), axis=0).view(MatGF2)

    return c_prime_matrix.mat_mul(cb_matrix)


def _compute_topological_generations(ordering_matrix: MatGF2) -> list[list[int]] | None:
    """Stratify the directed acyclic graph (DAG) represented by the ordering matrix into generations.

    Parameters
    ----------
    ordering_matrix : MatGF2
        Matrix encoding the partial ordering between nodes interpreted as the adjacency matrix of a directed graph.

    Returns
    -------
    list[list[int]]
        topological generations. Integers represent the indices of the matrix `ordering_matrix`, not the labelling of the nodes.

    or `None`
        if `ordering_matrix` is not a DAG.

    Notes
    -----
    This function is adapted from `:func: networkx.algorithms.dag.topological_generations` so that it works directly on the adjacency matrix (which is the output of the Pauli-flow finding algorithm) instead of a `:class: nx.DiGraph` object. This avoids calling the function `nx.from_numpy_array` which can be expensive for certain graph instances.

    Here we use the convention that the element `ordering_matrix[i,j]` represents a link `j -> i`. NetworkX uses the opposite convention.
    """
    adj_mat = ordering_matrix

    indegree_map: dict[int, int] = {}
    zero_indegree: list[int] = []
    neighbors = {node: set(np.flatnonzero(row).astype(int)) for node, row in enumerate(adj_mat.T)}
    for node, col in enumerate(adj_mat):
        parents = np.flatnonzero(col)
        if parents.size:
            indegree_map[node] = parents.size
        else:
            zero_indegree.append(node)

    generations: list[list[int]] = []

    while zero_indegree:
        this_generation = zero_indegree
        zero_indegree = []
        for node in this_generation:
            for child in neighbors[node]:
                indegree_map[child] -= 1
                if indegree_map[child] == 0:
                    zero_indegree.append(child)
                    del indegree_map[child]
        generations.append(this_generation)

    if indegree_map:
        return None
    return generations


def compute_partial_order_layers(correction_matrix: CorrectionMatrix[_M_co]) -> tuple[frozenset[int], ...] | None:
    r"""Compute the partial order compatible with the correction matrix if it exists.

    Parameters
    ----------
    correction_matrix : CorrectionMatrix[_M_co]
        Algebraic representation of the correction function.

    Returns
    -------
    layers : tuple[frozenset[int], ...]
        Partial order between corrected qubits in a layer form. The frozenset `layers[i]` comprises the nodes in layer `i`. Nodes in layer `i` are "larger" in the partial order than nodes in layer `i+1`. Output nodes are always in layer 0.

    or `None`
        If the correction matrix is not compatible with a partial order on the the open graph, in which case the associated ordering matrix is not a DAG. In the context of the flow-finding algorithm, this means that the input open graph does not have Pauli (or generalised) flow.

    Notes
    -----
    - The partial order of the Pauli (or generalised) flow :math:`<_c` is the transitive closure of :math:`\lhd_c`, where the latter is related to the ordering matrix :math:`NC` as :math:`v \lhd_c w \Leftrightarrow (NC)_{w,v} = 1`, for :math:`v, w, \in O^c` two non-output nodes of `aog`. The ordering matrix is the product of the order-demand and the correction matrices and it is the adjacency matrix of the directed acyclical graph encoding the partial order.

    - If the open graph has flow, it must have outputs, so `layers[0]` always contains a finite set of nodes.

    See Lemma 3.12, and Theorem 3.1 in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    aog, c_matrix = correction_matrix.aog, correction_matrix.c_matrix
    ordering_matrix = aog.order_demand_matrix.mat_mul(c_matrix)

    if (topo_gen := _compute_topological_generations(ordering_matrix)) is None:
        return None  # The NC matrix is not a DAG, therefore there's no flow.

    layers = [
        frozenset(aog.og.output_nodes)
    ]  # Output nodes are always in layer 0. If the open graph has flow, it must have outputs, so we never end up with an empty set at `layers[0]`.

    # If m >_c n, with >_c the flow partial order for two nodes m, n, then layer(n) > layer(m).
    # Therefore, we iterate the topological sort of the graph in _reverse_ order to obtain the order of measurements.
    col_tags = aog.non_outputs
    layers.extend(frozenset({col_tags[i] for i in idx_layer}) for idx_layer in reversed(topo_gen))

    return tuple(layers)


def compute_correction_matrix(aog: AlgebraicOpenGraph[_M_co]) -> CorrectionMatrix[_M_co] | None:
    """Return the correction matrix of the input open graph if it exists.

    Parameters
    ----------
    aog : AlgebraicOpenGraph[_M_co]
        Algberaic representation of the open graph whose correction matrix is calculated.

    Returns
    -------
    correction_matrix : CorrectionMatrix[_M_co]
        Algebraic representation of the correction function.

    or `None`
        if the input open graph does not have Pauli (or generalised) flow.

    Notes
    -----
    - In the case of open graphs with equal number of inputs and outputs, the function only returns `None` when the flow-demand matrix is not invertible (meaning that `aog` does not have Pauli flow). The additional condition for the existence of Pauli flow that the ordering matrix :math:`NC` must encode a directed acyclic graph (DAG) is verified by :func:`compute_partial_order`, which is called from the `graphix.flow.core.PauliFlow` constructor.

    - See Definitions 3.4, 3.5 and 3.6, Theorems 3.1, 4.2 and 4.4, and Algorithms 2 and 3 in Mitosek and Backens, 2024 (arXiv:2410.23439).
    """
    ni = len(aog.og.input_nodes)
    no = len(aog.og.output_nodes)

    if ni > no:
        return None

    # Steps 1 and 2
    # Flow-demand and order-demand matrices are cached properties of `aog`.
    flow_demand_matrix, order_demand_matrix = aog._og_matrices

    if ni == no:
        correction_matrix = flow_demand_matrix.right_inverse()
    else:
        correction_matrix = _compute_correction_matrix_general_case(aog, flow_demand_matrix, order_demand_matrix)

    if correction_matrix is None:
        return None

    return CorrectionMatrix(aog, correction_matrix)
