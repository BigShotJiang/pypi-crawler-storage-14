# Static version file
__version__ = "1.0.10"
version = "1.0.10"
__version_tuple__ = (1, 0, 10)
version_tuple = (1, 0, 10)
