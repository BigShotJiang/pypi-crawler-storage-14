def main():
    print("Hello from python-starter!")


if __name__ == "__main__":
    main()
