# MITgcmutils

Python utilities for the MIT General Circulation Model,
[MITgcm](http://mitgcm.org).

This package is developed as a part of MITgcm on
[github](https://github.com/MITgcm/MITgcm/tree/master/utils/python/MITgcmutils).

It is documented in the MITgcm
[manual](http://mitgcm.rtfd.io/en/latest/utilities/utilities.html#mitgcmutils).
