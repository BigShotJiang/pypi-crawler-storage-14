"""
Reversi42 Web GUI - FastAPI WebSocket Server
Web-based interface for playing Reversi/Othello against AI opponents.
"""

__all__ = ["cli"]
