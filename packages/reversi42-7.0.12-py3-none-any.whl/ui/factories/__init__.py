"""
UI Factories

Factory classes for creating UI components with proper dependency injection.
"""

from .view_factory import ViewFactory

__all__ = ["ViewFactory"]
