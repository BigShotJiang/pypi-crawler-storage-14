"""
Infrastructure Package - External Dependencies and Technical Concerns

This package contains infrastructure layer components:
- Persistence (file I/O, database)
- UI implementations (pygame, terminal, etc.)
- External services

Part of Clean Architecture - Infrastructure Layer.
"""
