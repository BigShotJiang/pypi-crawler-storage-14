"""
Persistence Package - Data Storage and Retrieval

Handles game save/load operations and other persistence concerns.
"""

from .game_io import GameIO

__all__ = ["GameIO"]
