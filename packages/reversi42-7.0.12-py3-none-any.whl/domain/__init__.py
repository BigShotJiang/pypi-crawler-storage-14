"""
Domain Package - Business Logic Layer

This package contains all domain logic for Reversi42.
Part of Clean Architecture - Domain Layer.

The domain layer should have NO dependencies on:
- UI frameworks (pygame, etc.)
- Infrastructure (file I/O, database)
- External libraries

Other layers depend on domain, but domain depends on nothing!
"""
