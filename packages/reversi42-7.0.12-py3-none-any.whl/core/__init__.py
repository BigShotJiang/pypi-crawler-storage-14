"""
Core Package - Application Configuration and Constants

This package contains core application settings and constants.
Part of Clean Architecture - Core Layer.
"""

from .config import GameConfig, UIConfig

__all__ = ["GameConfig", "UIConfig"]
