## Changelog 

### Improved

- The `cdf data plugin dir` now have a progress bar for the upload.