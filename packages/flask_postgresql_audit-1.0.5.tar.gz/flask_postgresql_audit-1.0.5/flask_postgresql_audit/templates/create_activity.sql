CREATE OR REPLACE FUNCTION ${schema_prefix}create_activity() RETURNS TRIGGER AS $$
DECLARE
    audit_row ${schema_prefix}pga_activity;
    excluded_cols text[] = ARRAY[]::text[];
    _transaction_id BIGINT;
BEGIN
    _transaction_id := (
        SELECT id
        FROM ${schema_prefix}pga_transaction
        WHERE native_transaction_id = txid_current()
            AND issued_at >= (NOW() - INTERVAL '1 day')
        ORDER BY issued_at DESC
        LIMIT 1
    );

    IF TG_ARGV[0] IS NOT NULL THEN
        excluded_cols = TG_ARGV[0]::text[];
    END IF;

    IF (TG_OP = 'UPDATE') THEN
        INSERT INTO ${schema_prefix}pga_activity(
            id, schema_name, table_name, relid, issued_at, native_transaction_id,
            verb, row_key, old_data, changed_data, transaction_id)
        SELECT
            nextval('${schema_prefix}pga_activity_id_seq') as id,
            TG_TABLE_SCHEMA::text AS schema_name,
            TG_TABLE_NAME::text AS table_name,
            TG_RELID AS relid,
            statement_timestamp() AT TIME ZONE 'UTC' AS issued_at,
            txid_current() AS native_transaction_id,
            LOWER(TG_OP) AS verb,
            ${schema_prefix}get_pk_values(TG_RELID, new_data) AS row_key,
            old_data - excluded_cols AS old_data,
            ${schema_prefix}jsonb_subtract(new_data, old_data) - excluded_cols AS changed_data,
            _transaction_id AS transaction_id
        FROM (
                SELECT *
                FROM (
                        SELECT row_to_json(old_table.*)::jsonb AS old_data, row_number() OVER ()
                        FROM old_table
                    ) AS old_table
                    JOIN (
                        SELECT row_to_json(new_table.*)::jsonb AS new_data, row_number() OVER ()
                        FROM new_table
                    ) AS new_table
                    USING(row_number)
            ) as sub
        WHERE ${schema_prefix}jsonb_subtract(new_data, old_data) - excluded_cols != '{}'::jsonb;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO ${schema_prefix}pga_activity(
            id, schema_name, table_name, relid, issued_at, native_transaction_id,
            verb, row_key, old_data, changed_data, transaction_id)
        SELECT
            nextval('${schema_prefix}pga_activity_id_seq') as id,
            TG_TABLE_SCHEMA::text AS schema_name,
            TG_TABLE_NAME::text AS table_name,
            TG_RELID AS relid,
            statement_timestamp() AT TIME ZONE 'UTC' AS issued_at,
            txid_current() AS native_transaction_id,
            LOWER(TG_OP) AS verb,
            ${schema_prefix}get_pk_values(TG_RELID, to_jsonb(new_table)) AS row_key,
            '{}'::jsonb AS old_data,
            row_to_json(new_table.*)::jsonb - excluded_cols AS changed_data,
            _transaction_id AS transaction_id
        FROM new_table;
    ELSEIF TG_OP = 'DELETE' THEN
        INSERT INTO ${schema_prefix}pga_activity(
            id, schema_name, table_name, relid, issued_at, native_transaction_id,
            verb, row_key, old_data, changed_data, transaction_id)
        SELECT
            nextval('${schema_prefix}pga_activity_id_seq') as id,
            TG_TABLE_SCHEMA::text AS schema_name,
            TG_TABLE_NAME::text AS table_name,
            TG_RELID AS relid,
            statement_timestamp() AT TIME ZONE 'UTC' AS issued_at,
            txid_current() AS native_transaction_id,
            LOWER(TG_OP) AS verb,
            ${schema_prefix}get_pk_values(TG_RELID, to_jsonb(old_table)) AS row_key,
            row_to_json(old_table.*)::jsonb - excluded_cols AS old_data,
            '{}'::jsonb AS changed_data,
            _transaction_id AS transaction_id
        FROM old_table;
    END IF;
    RETURN NULL;
END;
$$
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public;