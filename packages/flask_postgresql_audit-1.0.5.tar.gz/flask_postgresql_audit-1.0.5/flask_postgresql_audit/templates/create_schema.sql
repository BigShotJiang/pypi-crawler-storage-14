CREATE SCHEMA ${schema_name};
REVOKE ALL ON SCHEMA ${schema_name} FROM public;
