import json
from typing import List, Optional, Dict, Any
from uuid import UUID
from ..db import DBManager
from ..models import Project, CreateProjectDTO, UpdateProjectDTO
from ..utils import get_sql

class ProjectsRepository:
    @classmethod
    async def list(cls) -> List[Project]:
        sql = get_sql('projects', 'list')
        rows = await DBManager.fetch_all(sql)
        return [cls._map_row_to_model(row) for row in rows]

    @classmethod
    async def get_by_id(cls, id: str) -> Optional[Project]:
        sql = get_sql('projects', 'get_by_id')
        row = await DBManager.fetch_one(sql, id)
        if not row:
            return None
        return cls._map_row_to_model(row)

    @classmethod
    async def get_raw_by_id(cls, id: str) -> Optional[Dict[str, Any]]:
        """Get raw project data without model mapping."""
        row = await DBManager.fetch_one(
            "SELECT * FROM projects WHERE id = $1",
            id
        )
        if not row:
            return None
        return dict(row)

    @classmethod
    async def get_by_key(cls, key: str) -> Optional[Project]:
        sql = get_sql('projects', 'get_by_key')
        row = await DBManager.fetch_one(sql, key)
        if not row:
            return None
        return cls._map_row_to_model(row)
    
    @classmethod
    async def create(cls, dto: CreateProjectDTO, actor: str = None) -> Project:
        sql = get_sql('projects', 'create')
        row = await DBManager.fetch_one(sql, dto.key, dto.name)
        if not row:
            raise Exception("Failed to create project")
            
        return cls._map_row_to_model(row)

    @classmethod
    async def update(cls, id: str, updates: UpdateProjectDTO) -> Project:
        """Update a project."""
        updates_list = []
        values = []
        param_count = 1

        if updates.name is not None:
            updates_list.append(f"name = ${param_count}")
            values.append(updates.name)
            param_count += 1

        if updates.key is not None:
            updates_list.append(f"key = ${param_count}")
            values.append(updates.key)
            param_count += 1

        if len(updates_list) == 0:
            existing = await cls.get_by_id(id)
            if not existing:
                raise Exception("Project not found")
            return existing

        values.append(id)
        sql = f"""
            UPDATE projects
            SET {', '.join(updates_list)}
            WHERE id = ${param_count}
            RETURNING 
                id,
                ref,
                key,
                name,
                ARRAY[]::text[] as tags,
                '{{}}'::jsonb as tprops,
                NULL as connector_ref,
                created_at,
                updated_at
        """
        row = await DBManager.fetch_one(sql, *values)

        if not row:
            raise Exception("Project not found")

        return cls._map_row_to_model(row)

    @classmethod
    async def delete(cls, id: str) -> None:
        """Delete a project."""
        existing = await cls.get_by_id(id)
        if not existing:
            raise Exception("Project not found")

        await DBManager.execute(
            "DELETE FROM projects WHERE id = $1",
            id
        )

    @staticmethod
    def _map_row_to_model(row: dict) -> Project:
        data = dict(row)
        
        # Convert UUID to string if needed
        if isinstance(data.get('id'), UUID):
            data['id'] = str(data['id'])
        
        # Handle tprops JSON parsing
        if isinstance(data.get('tprops'), str):
            data['tprops'] = json.loads(data['tprops'])
        elif data.get('tprops') is None:
            data['tprops'] = {}
        
        return Project(**data)
