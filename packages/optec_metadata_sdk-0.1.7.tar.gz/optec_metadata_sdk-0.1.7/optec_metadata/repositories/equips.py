import json
from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import UUID

from ..db import DBManager
from ..models import Equip, CreateEquipDTO, UpdateEquipDTO, ListEquipsQuery
from ..utils import normalize_tags, normalize_tprops, ref_to_id, get_sql

class EquipsRepository:
    @classmethod
    async def list(cls, query_params: ListEquipsQuery) -> List[Equip]:
        sql = get_sql('equips', 'list_base')
        
        params = []
        param_count = 1
        
        if query_params.systemRef:
            system_id = ref_to_id(query_params.systemRef)
            if not system_id:
                raise ValueError("Invalid systemRef")
            sql += f" AND e.system_id = ${param_count}"
            params.append(system_id)
            param_count += 1
            
        if query_params.equipRef:
            equip_id = ref_to_id(query_params.equipRef)
            if not equip_id:
                raise ValueError("Invalid equipRef")
            sql += f" AND e.id = ${param_count}"
            params.append(equip_id)
            param_count += 1
            
        if query_params.equipTags:
            normalized_tags = normalize_tags(query_params.equipTags)
            # Use @> operator for array containment
            sql += f" AND e.tags @> ${param_count}::text[]"
            params.append(normalized_tags)
            param_count += 1
            
        sql += " ORDER BY e.name"
        
        rows = await DBManager.fetch_all(sql, *params)
        results = [cls._map_row_to_model(row) for row in rows]
        
        if query_params.includeChildren and results:
            all_results = list(results)
            for result in results:
                children = await cls._get_children_recursive(result.id)
                all_results.extend(children)
            results = all_results
            
        return results

    @classmethod
    async def _get_children_recursive(cls, parent_id: str) -> List[Equip]:
        sql = get_sql('equips', 'get_children')
        rows = await DBManager.fetch_all(sql, parent_id)
        children = [cls._map_row_to_model(row) for row in rows]
        
        all_children = list(children)
        for child in children:
            grandchildren = await cls._get_children_recursive(child.id)
            all_children.extend(grandchildren)
            
        return all_children

    @classmethod
    async def get_by_id(cls, id: str) -> Optional[Equip]:
        sql = get_sql('equips', 'get_by_id')
        row = await DBManager.fetch_one(sql, id)
        if not row:
            return None
        return cls._map_row_to_model(row)

    @classmethod
    async def create(cls, dto: CreateEquipDTO, actor: str) -> Equip:
        site_id = ref_to_id(dto.siteRef)
        system_id = ref_to_id(dto.systemRef)
        parent_equip_id = ref_to_id(dto.parentEquipRef) if dto.parentEquipRef else None
        
        if not site_id or not system_id:
            raise ValueError("Invalid siteRef or systemRef")
            
        tags_with_entity_type = (dto.tags or []) + ['equip']
        normalized_tags = normalize_tags(tags_with_entity_type)
        normalized_tprops = normalize_tprops(dto.tprops)
        
        sql = get_sql('equips', 'create')
        
        row = await DBManager.fetch_one(
            sql, 
            site_id, 
            system_id, 
            parent_equip_id, 
            dto.name, 
            normalized_tags, 
            json.dumps(normalized_tprops), 
            dto.connector_ref
        )
        
        if not row:
            raise Exception("Failed to create equip")
            
        equip = await cls.get_by_id(row['id'])
        if not equip:
            raise Exception("Failed to fetch created equip")
            
        return equip

    @classmethod
    async def update(cls, id: str, updates: UpdateEquipDTO, actor: str) -> Equip:
        # Note: Implementation skips optimistic locking (ETag) for simplicity unless requested
        
        updates_list = []
        values = []
        param_count = 1
        
        if updates.name is not None:
            updates_list.append(f"name = ${param_count}")
            values.append(updates.name)
            param_count += 1
            
        if updates.siteRef is not None:
            site_id = ref_to_id(updates.siteRef) if updates.siteRef else None
            if updates.siteRef and not site_id:
                raise ValueError("Invalid siteRef")
            updates_list.append(f"site_id = ${param_count}")
            values.append(site_id)
            param_count += 1
            
        if updates.systemRef is not None:
            system_id = ref_to_id(updates.systemRef) if updates.systemRef else None
            if updates.systemRef and not system_id:
                raise ValueError("Invalid systemRef")
            updates_list.append(f"system_id = ${param_count}")
            values.append(system_id)
            param_count += 1
            
        if updates.parentEquipRef is not None:
            parent_id = ref_to_id(updates.parentEquipRef) if updates.parentEquipRef else None
            updates_list.append(f"parent_equip_id = ${param_count}")
            values.append(parent_id)
            param_count += 1
            
        if updates.tags is not None:
            normalized_tags = normalize_tags(updates.tags)
            updates_list.append(f"tags = ${param_count}::text[]")
            values.append(normalized_tags)
            param_count += 1
            
        if updates.tprops is not None:
            normalized_tprops = normalize_tprops(updates.tprops)
            updates_list.append(f"tprops = ${param_count}::jsonb")
            values.append(json.dumps(normalized_tprops))
            param_count += 1
            
        if updates.connector_ref is not None:
            updates_list.append(f"connector_ref = ${param_count}")
            values.append(updates.connector_ref)
            param_count += 1
            
        if not updates_list:
            existing = await cls.get_by_id(id)
            if not existing:
                raise ValueError("Equip not found")
            return existing
            
        values.append(id)
        sql = f"""
            UPDATE equips
            SET {', '.join(updates_list)}
            WHERE id = ${param_count} AND deleted_at IS NULL
            RETURNING id
        """
        
        row = await DBManager.fetch_one(sql, *values)
        if not row:
            raise ValueError("Equip not found")
            
        equip = await cls.get_by_id(row['id'])
        if not equip:
            raise Exception("Failed to update equip")
            
        return equip

    @classmethod
    async def soft_delete(cls, id: str, reason: str, actor: str, retention_days: int = 30):
        # Transactional soft delete
        pool = await DBManager.get_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await cls._soft_delete_recursive(conn, id, reason, actor, retention_days)

    @classmethod
    async def _soft_delete_recursive(cls, conn, id: str, reason: str, actor: str, retention_days: int):
        # Soft delete the equip
        await conn.execute(
            "UPDATE equips SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL",
            id
        )
        
        row = await conn.fetchrow("SELECT id, ref FROM equips WHERE id = $1", id)
        if not row:
            # Might have been already deleted or not found
            # The recursive logic might attempt to delete already deleted children, which is fine
            # But top-level call should probably error if not found?
            # Matching TS logic strictness might be complex here.
            # TS SDK errors if not found.
            # For recursion, we query `deleted_at IS NULL` so we won't recurse on already deleted items ideally.
            return

        # Add to trash
        await conn.execute(
            """
            INSERT INTO trash (entity, entity_id, ref, reason, deleted_by, purge_after)
            VALUES ($1, $2, $3, $4, $5, now() + interval '1 day' * $6)
            """,
            'equip', row['id'], row['ref'], reason, actor, retention_days
        )
        
        # Soft delete points
        points = await conn.fetch(
            "SELECT id, ref FROM points WHERE equip_id = $1 AND deleted_at IS NULL",
            id
        )
        for point in points:
            await conn.execute("UPDATE points SET deleted_at = now() WHERE id = $1", point['id'])
            await conn.execute(
                """
                INSERT INTO trash (entity, entity_id, ref, reason, deleted_by, purge_after)
                VALUES ($1, $2, $3, $4, $5, now() + interval '1 day' * $6)
                """,
                'point', point['id'], point['ref'], f"Cascaded from equip deletion: {reason}", actor, retention_days
            )
            
        # Recurse for child equips
        child_equips = await conn.fetch(
            "SELECT id FROM equips WHERE parent_equip_id = $1 AND deleted_at IS NULL",
            id
        )
        for child in child_equips:
            await cls._soft_delete_recursive(conn, child['id'], f"Cascaded from parent equip deletion: {reason}", actor, retention_days)

    @staticmethod
    def _map_row_to_model(row: dict) -> Equip:
        # Convert row (Record) to dict
        data = dict(row)
        
        # Convert UUID to string if needed
        if isinstance(data.get('id'), UUID):
            data['id'] = str(data['id'])
        
        # Handle tprops if it's a string (though asyncpg usually decodes JSONB automatically)
        if isinstance(data.get('tprops'), str):
             data['tprops'] = json.loads(data['tprops'])
        elif data.get('tprops') is None:
            data['tprops'] = {}
            
        return Equip(**data)
