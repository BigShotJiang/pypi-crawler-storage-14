import json
from typing import List, Optional
from uuid import UUID
from ..db import DBManager
from ..models import System, CreateSystemDTO, UpdateSystemDTO, ListSystemsQuery
from ..utils import normalize_tags, normalize_tprops, ref_to_id, get_sql

class SystemsRepository:
    @classmethod
    async def list(cls, query_params: ListSystemsQuery) -> List[System]:
        site_id = ref_to_id(query_params.siteRef)
        if not site_id:
            raise ValueError("Invalid siteRef")
            
        sql = get_sql('systems', 'list_base')
        
        params = [site_id]
        param_count = 2
        
        if query_params.tags:
            normalized_tags = normalize_tags(query_params.tags)
            sql += f" AND s.tags @> ${param_count}::text[]"
            params.append(normalized_tags)
            param_count += 1
            
        sql += " ORDER BY s.name"
        
        rows = await DBManager.fetch_all(sql, *params)
        return [cls._map_row_to_model(row) for row in rows]

    @classmethod
    async def get_by_id(cls, id: str) -> Optional[System]:
        sql = get_sql('systems', 'get_by_id')
        row = await DBManager.fetch_one(sql, id)
        if not row:
            return None
        return cls._map_row_to_model(row)

    @classmethod
    async def create(cls, dto: CreateSystemDTO, actor: str) -> System:
        site_id = ref_to_id(dto.siteRef)
        if not site_id:
            raise ValueError("Invalid siteRef")
            
        tags_with_entity_type = (dto.tags or []) + ['system']
        normalized_tags = normalize_tags(tags_with_entity_type)
        normalized_tprops = normalize_tprops(dto.tprops)
        
        sql = get_sql('systems', 'create')
        
        row = await DBManager.fetch_one(
            sql,
            site_id,
            dto.name,
            normalized_tags,
            json.dumps(normalized_tprops),
            dto.connector_ref
        )
        
        if not row:
            raise Exception("Failed to create system")
            
        system = await cls.get_by_id(row['id'])
        if not system:
            raise Exception("Failed to fetch created system")
            
        return system

    @classmethod
    async def update(cls, id: str, updates: UpdateSystemDTO, actor: str) -> System:
        updates_list = []
        values = []
        param_count = 1
        
        if updates.name is not None:
            updates_list.append(f"name = ${param_count}")
            values.append(updates.name)
            param_count += 1
            
        if updates.tags is not None:
            normalized_tags = normalize_tags(updates.tags)
            updates_list.append(f"tags = ${param_count}::text[]")
            values.append(normalized_tags)
            param_count += 1
            
        if updates.tprops is not None:
            normalized_tprops = normalize_tprops(updates.tprops)
            updates_list.append(f"tprops = ${param_count}::jsonb")
            values.append(json.dumps(normalized_tprops))
            param_count += 1
            
        if updates.siteRef is not None:
            site_id = ref_to_id(updates.siteRef)
            if not site_id:
                raise ValueError("Invalid siteRef")
            updates_list.append(f"site_id = ${param_count}")
            values.append(site_id)
            param_count += 1
            
        if updates.connector_ref is not None:
            updates_list.append(f"connector_ref = ${param_count}")
            values.append(updates.connector_ref)
            param_count += 1
            
        if not updates_list:
            existing = await cls.get_by_id(id)
            if not existing:
                raise ValueError("System not found")
            return existing
            
        values.append(id)
        sql = f"""
            UPDATE systems
            SET {', '.join(updates_list)}
            WHERE id = ${param_count} AND deleted_at IS NULL
            RETURNING id
        """
        
        row = await DBManager.fetch_one(sql, *values)
        if not row:
            raise ValueError("System not found")
            
        system = await cls.get_by_id(row['id'])
        if not system:
            raise Exception("Failed to update system")
            
        return system

    @classmethod
    async def soft_delete(cls, id: str, reason: str, actor: str, retention_days: int = 30):
        pool = await DBManager.get_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # Reusing recursive delete logic from SitesRepository (or duplicated here)
                await cls._soft_delete_system_recursive(conn, id, reason, actor, retention_days)

    @classmethod
    async def _soft_delete_system_recursive(cls, conn, system_id: str, reason: str, actor: str, retention_days: int):
        # Delete system
        await conn.execute("UPDATE systems SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL", system_id)
        
        row = await conn.fetchrow("SELECT id, ref FROM systems WHERE id = $1", system_id)
        if not row: return
        
        await conn.execute(
            """
            INSERT INTO trash (entity, entity_id, ref, reason, deleted_by, purge_after)
            VALUES ($1, $2, $3, $4, $5, now() + interval '1 day' * $6)
            """,
            'system', row['id'], row['ref'], reason, actor, retention_days
        )
        
        # Delete equips
        equips = await conn.fetch("SELECT id FROM equips WHERE system_id = $1 AND deleted_at IS NULL", system_id)
        for equip in equips:
            # Need to use Equip recursive logic
            # Duplicating here to be self-contained
            await cls._soft_delete_equip_recursive(conn, equip['id'], f"Cascaded from system deletion: {reason}", actor, retention_days)

    @classmethod
    async def _soft_delete_equip_recursive(cls, conn, equip_id: str, reason: str, actor: str, retention_days: int):
        # Duplicated logic
        await conn.execute("UPDATE equips SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL", equip_id)
        row = await conn.fetchrow("SELECT id, ref FROM equips WHERE id = $1", equip_id)
        if not row: return
        
        await conn.execute(
            """
            INSERT INTO trash (entity, entity_id, ref, reason, deleted_by, purge_after)
            VALUES ($1, $2, $3, $4, $5, now() + interval '1 day' * $6)
            """,
            'equip', row['id'], row['ref'], reason, actor, retention_days
        )
        points = await conn.fetch("SELECT id, ref FROM points WHERE equip_id = $1 AND deleted_at IS NULL", equip_id)
        for point in points:
            await conn.execute("UPDATE points SET deleted_at = now() WHERE id = $1", point['id'])
            await conn.execute(
                """
                INSERT INTO trash (entity, entity_id, ref, reason, deleted_by, purge_after)
                VALUES ($1, $2, $3, $4, $5, now() + interval '1 day' * $6)
                """,
                'point', point['id'], point['ref'], f"Cascaded from equip deletion: {reason}", actor, retention_days
            )
        child_equips = await conn.fetch("SELECT id FROM equips WHERE parent_equip_id = $1 AND deleted_at IS NULL", equip_id)
        for child in child_equips:
            await cls._soft_delete_equip_recursive(conn, child['id'], f"Cascaded from parent equip deletion: {reason}", actor, retention_days)

    @staticmethod
    def _map_row_to_model(row: dict) -> System:
        data = dict(row)
        
        # Convert UUID to string if needed
        if isinstance(data.get('id'), UUID):
            data['id'] = str(data['id'])
        
        if isinstance(data.get('tprops'), str):
             data['tprops'] = json.loads(data['tprops'])
        elif data.get('tprops') is None:
            data['tprops'] = {}
        return System(**data)
