import json
import logging
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from uuid import UUID

from ..db import DBManager
from ..models import (
    Point, CreatePointDTO, UpdatePointDTO, ListPointsQuery, 
    PointState, PointHistory, Quality
)
from ..utils import normalize_tags, normalize_tprops, ref_to_id, get_sql
from .equips import EquipsRepository

logger = logging.getLogger(__name__)

class PointsRepository:
    @classmethod
    async def list(cls, query_params: ListPointsQuery) -> List[Point]:
        sql = get_sql('points', 'list_base')
        
        params = []
        param_count = 1
        
        if query_params.equipRef:
            equip_id = ref_to_id(query_params.equipRef)
            if not equip_id:
                raise ValueError("Invalid equipRef")
            sql += f" AND p.equip_id = ${param_count}"
            params.append(equip_id)
            param_count += 1
            
        if query_params.siteRef:
            site_id = ref_to_id(query_params.siteRef)
            if not site_id:
                raise ValueError("Invalid siteRef")
            sql += f" AND p.site_id = ${param_count}"
            params.append(site_id)
            param_count += 1
            
        if query_params.systemRef:
            system_id = ref_to_id(query_params.systemRef)
            if not system_id:
                raise ValueError("Invalid systemRef")
            sql += f" AND p.system_id = ${param_count}"
            params.append(system_id)
            param_count += 1
            
        if query_params.pointTags:
            normalized_tags = normalize_tags(query_params.pointTags)
            sql += f" AND p.tags @> ${param_count}::text[]"
            params.append(normalized_tags)
            param_count += 1
            
        sql += " ORDER BY p.name"
        
        rows = await DBManager.fetch_all(sql, *params)
        results = [cls._map_row_to_model(row) for row in rows]
        
        if query_params.includeChildren and query_params.equipRef:
            # Get points from nested equips
            # Use EquipsRepository to list children with includeChildren=True
            # Better to import ListEquipsQuery
            from ..models import ListEquipsQuery as LEQ
            nested_equips = await EquipsRepository.list(
                LEQ(equipRef=query_params.equipRef, includeChildren=True)
            )
            
            nested_equip_ids = [e.id for e in nested_equips]
            
            if nested_equip_ids:
                nested_sql = get_sql('points', 'list_by_equip_ids')
                nested_rows = await DBManager.fetch_all(nested_sql, nested_equip_ids)
                nested_points = [cls._map_row_to_model(row) for row in nested_rows]
                results.extend(nested_points)
                
        return results

    @classmethod
    async def get_by_id(cls, id: str) -> Optional[Point]:
        sql = get_sql('points', 'get_by_id')
        row = await DBManager.fetch_one(sql, id)
        if not row:
            return None
        return cls._map_row_to_model(row)

    @classmethod
    async def create(cls, dto: CreatePointDTO, actor: str) -> Point:
        site_id = ref_to_id(dto.siteRef)
        system_id = ref_to_id(dto.systemRef)
        equip_id = ref_to_id(dto.equipRef)
        
        if not site_id or not system_id or not equip_id:
            raise ValueError("Invalid siteRef, systemRef, or equipRef")
            
        tags_with_entity_type = (dto.tags or []) + ['point']
        normalized_tags = normalize_tags(tags_with_entity_type)
        normalized_tprops = normalize_tprops(dto.tprops)
        
        sql = get_sql('points', 'create')
        
        his = dto.his or PointHistory()
        
        row = await DBManager.fetch_one(
            sql,
            site_id,
            system_id,
            equip_id,
            dto.name,
            dto.kind,
            dto.unit,
            normalized_tags,
            json.dumps(normalized_tprops),
            json.dumps(dto.scaling or {}),
            his.enabled,
            his.start,
            his.end,
            his.size,
            dto.qos or 'good',
            dto.enabled,
            dto.connector_ref,
            dto.monnitSensorId
        )
        
        if not row:
            raise Exception("Failed to create point")
            
        point = await cls.get_by_id(row['id'])
        if not point:
            raise Exception("Failed to fetch created point")
            
        return point

    @classmethod
    async def update(cls, id: str, updates: UpdatePointDTO, actor: str) -> Point:
        # Note: ETag logic omitted for brevity in this migration, can be re-added
        # This focuses on file structure migration first
        
        updates_list = []
        values = []
        param_count = 1
        
        if updates.name is not None:
            updates_list.append(f"name = ${param_count}")
            values.append(updates.name)
            param_count += 1
            
        if updates.kind is not None:
            updates_list.append(f"kind = ${param_count}")
            values.append(updates.kind)
            param_count += 1
            
        if updates.unit is not None:
            updates_list.append(f"unit = ${param_count}")
            values.append(updates.unit)
            param_count += 1
            
        if updates.siteRef is not None:
            site_id = ref_to_id(updates.siteRef)
            if not site_id:
                raise ValueError("Invalid siteRef")
            updates_list.append(f"site_id = ${param_count}")
            values.append(site_id)
            param_count += 1
            
        if updates.systemRef is not None:
            system_id = ref_to_id(updates.systemRef)
            if not system_id:
                raise ValueError("Invalid systemRef")
            updates_list.append(f"system_id = ${param_count}")
            values.append(system_id)
            param_count += 1
            
        if updates.equipRef is not None:
            equip_id = ref_to_id(updates.equipRef)
            if not equip_id:
                raise ValueError("Invalid equipRef")
            updates_list.append(f"equip_id = ${param_count}")
            values.append(equip_id)
            param_count += 1
            
        if updates.tags is not None:
            normalized_tags = normalize_tags(updates.tags)
            updates_list.append(f"tags = ${param_count}::text[]")
            values.append(normalized_tags)
            param_count += 1
            
        if updates.tprops is not None:
            normalized_tprops = normalize_tprops(updates.tprops)
            updates_list.append(f"tprops = ${param_count}::jsonb")
            values.append(json.dumps(normalized_tprops))
            param_count += 1
            
        if updates.scaling is not None:
            updates_list.append(f"scaling = ${param_count}::jsonb")
            values.append(json.dumps(updates.scaling))
            param_count += 1
            
        if updates.his is not None:
            if updates.his.enabled is not None:
                updates_list.append(f"his_enabled = ${param_count}")
                values.append(updates.his.enabled)
                param_count += 1
            if updates.his.start is not None:
                updates_list.append(f"his_start = ${param_count}")
                values.append(updates.his.start)
                param_count += 1
            if updates.his.end is not None:
                updates_list.append(f"his_end = ${param_count}")
                values.append(updates.his.end)
                param_count += 1
            if updates.his.size is not None:
                updates_list.append(f"his_size = ${param_count}")
                values.append(updates.his.size)
                param_count += 1
                
        if updates.qos is not None:
            updates_list.append(f"qos = ${param_count}")
            values.append(updates.qos)
            param_count += 1
            
        if updates.enabled is not None:
            updates_list.append(f"enabled = ${param_count}")
            values.append(updates.enabled)
            param_count += 1
            
        if updates.connector_ref is not None:
            updates_list.append(f"connector_ref = ${param_count}")
            values.append(updates.connector_ref)
            param_count += 1
            
        if updates.monnitSensorId is not None:
            updates_list.append(f"monnit_sensor_id = ${param_count}")
            values.append(updates.monnitSensorId)
            param_count += 1
            
        if not updates_list:
            existing = await cls.get_by_id(id)
            if not existing:
                raise ValueError("Point not found")
            return existing
            
        values.append(id)
        sql = f"""
            UPDATE points
            SET {', '.join(updates_list)}
            WHERE id = ${param_count} AND deleted_at IS NULL
            RETURNING id
        """
        
        row = await DBManager.fetch_one(sql, *values)
        if not row:
            raise ValueError("Point not found")
            
        point = await cls.get_by_id(row['id'])
        if not point:
            raise Exception("Failed to update point")
            
        return point

    @classmethod
    async def soft_delete(cls, id: str, reason: str, actor: str, retention_days: int = 30):
        pool = await DBManager.get_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "UPDATE points SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL",
                    id
                )
                
                row = await conn.fetchrow("SELECT id, ref FROM points WHERE id = $1", id)
                if not row:
                     raise ValueError("Point not found")
                     
                await conn.execute(
                    """
                    INSERT INTO trash (entity, entity_id, ref, reason, deleted_by, purge_after)
                    VALUES ($1, $2, $3, $4, $5, now() + interval '1 day' * $6)
                    """,
                    'point', row['id'], row['ref'], reason, actor, retention_days
                )

    @classmethod
    async def get_detailed(cls, id: str, include_history_stats: bool = True) -> Optional[Point]:
        sql = get_sql('points', 'get_detailed')
        
        row = await DBManager.fetch_one(sql, id)
        if not row:
            return None
        
        point_data = dict(row)
        
        # Parse standard fields
        his_end = point_data.get('his_end')
        his_size = point_data.get('his_size') or 0
        his_enabled = point_data.get('his_enabled', False)
        
        # Convert datetime to ISO string if needed
        if isinstance(his_end, datetime):
            his_end = his_end.isoformat()
        elif his_end is not None:
            his_end = str(his_end)
        
        # Remove extra fields before mapping
        del point_data['his_end']
        del point_data['his_size']
        
        point = cls._map_row_to_model(point_data)
        
        if not include_history_stats:
            return point
            
        # If history enabled but stats missing/zero, query raw_1m
        if his_enabled and (not his_end or his_size == 0):
            try:
                # Query TimescaleDB raw_1m table
                # We reuse the same pool assuming same DB
                stats_row = await DBManager.fetch_one(
                    """
                    SELECT 
                        MAX(time) as max_time,
                        COUNT(*)::bigint as count
                    FROM raw_1m
                    WHERE point_id = $1
                    """,
                    id
                )
                
                if stats_row:
                    if stats_row['max_time']:
                        his_end = stats_row['max_time'].isoformat() if isinstance(stats_row['max_time'], datetime) else str(stats_row['max_time'])
                    
                    if stats_row['count']:
                        his_size = int(stats_row['count'])
                        
            except Exception as e:
                logger.warning(f"Failed to query raw_1m for point {id}: {e}")
                
        # Update point.his
        if not point.his:
            point.his = PointHistory(enabled=his_enabled)
            
        point.his.end = his_end
        point.his.size = his_size
        point.his.enabled = his_enabled
        
        return point

    @classmethod
    async def record_sample(
        cls, 
        point_id: str, 
        ts: Union[datetime, str], 
        value: Union[float, bool, str, None],
        quality: Quality = 'good',
        source: Optional[str] = None
    ) -> None:
        # Determine value columns based on type
        value_double = None
        value_bool = None
        value_text = None
        
        if value is not None:
            if isinstance(value, bool):
                value_bool = value
            elif isinstance(value, (int, float)):
                value_double = float(value)
            else:
                value_text = str(value)
                
        # Convert timestamp if needed
        timestamp = ts
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
        sql = """
            SELECT record_point_sample(
                $1::uuid, 
                $2::timestamptz, 
                $3::double precision, 
                $4::boolean, 
                $5::text, 
                $6::text, 
                $7::text
            )
        """
        
        await DBManager.fetch_one(
            sql,
            point_id,
            timestamp,
            value_double,
            value_bool,
            value_text,
            quality,
            source
        )

    @classmethod
    async def read_raw(
        cls, 
        point_id: str, 
        start: Union[datetime, str], 
        end: Union[datetime, str],
        limit: int = 10000
    ) -> List[Dict[str, Any]]:
        # Convert timestamps if needed
        start_ts = start if isinstance(start, datetime) else datetime.fromisoformat(start.replace('Z', '+00:00'))
        end_ts = end if isinstance(end, datetime) else datetime.fromisoformat(end.replace('Z', '+00:00'))
        
        sql = """
            SELECT 
                time,
                value_double,
                value_bool,
                value_text,
                quality
            FROM raw_1m
            WHERE point_id = $1 AND time >= $2 AND time <= $3
            ORDER BY time ASC
            LIMIT $4
        """
        
        rows = await DBManager.fetch_all(sql, point_id, start_ts, end_ts, limit)
        
        results = []
        for row in rows:
            val = None
            if row['value_double'] is not None:
                val = row['value_double']
            elif row['value_bool'] is not None:
                val = row['value_bool']
            elif row['value_text'] is not None:
                val = row['value_text']
                
            results.append({
                'ts': row['time'],
                'val': val,
                'quality': row['quality']
            })
            
        return results

    @classmethod
    async def read_rollup(
        cls, 
        point_id: str, 
        start: Union[datetime, str], 
        end: Union[datetime, str],
        interval: str = '1h'
    ) -> List[Dict[str, Any]]:
        view_map = {
            '30m': 'rollup_30m',
            '1h': 'rollup_60m',
            '60m': 'rollup_60m',
            '6h': 'rollup_6hr',
            '12h': 'rollup_12hr',
            '24h': 'rollup_24hr',
            '1d': 'rollup_24hr'
        }
        
        view_name = view_map.get(interval)
        if not view_name:
            raise ValueError(f"Unsupported rollup interval: {interval}. Supported: {list(view_map.keys())}")
            
        start_ts = start if isinstance(start, datetime) else datetime.fromisoformat(start.replace('Z', '+00:00'))
        end_ts = end if isinstance(end, datetime) else datetime.fromisoformat(end.replace('Z', '+00:00'))
        
        sql = f"""
            SELECT 
                time,
                avg_v,
                min_v,
                max_v,
                sum_v,
                n
            FROM {view_name}
            WHERE point_id = $1 AND time >= $2 AND time <= $3
            ORDER BY time ASC
        """
        
        rows = await DBManager.fetch_all(sql, point_id, start_ts, end_ts)
        
        return [dict(row) for row in rows]

    @staticmethod
    def _map_row_to_model(data: Dict[str, Any]) -> Point:
        data = dict(data)
        
        # Convert UUID to string if needed
        if isinstance(data.get('id'), UUID):
            data['id'] = str(data['id'])
        
        if isinstance(data.get('tprops'), str):
             data['tprops'] = json.loads(data['tprops'])
        elif data.get('tprops') is None:
            data['tprops'] = {}
            
        if isinstance(data.get('scaling'), str):
             data['scaling'] = json.loads(data['scaling'])
        
        # Normalize qos values (handle legacy values)
        qos = data.get('qos', 'good')
        if qos == 'ok':
            qos = 'good'
        elif qos not in ('good', 'uncertain', 'bad'):
            # Default to 'good' for any unknown values
            qos = 'good'
        data['qos'] = qos
        
        his_enabled = data.get('his_enabled', False)
        his_start = data.get('his_start')
        his_end = data.get('his_end')
        his_size = data.get('his_size')
        
        # Convert datetime objects to ISO strings
        if isinstance(his_start, datetime):
            his_start = his_start.isoformat()
        elif his_start is not None:
            his_start = str(his_start)
            
        if isinstance(his_end, datetime):
            his_end = his_end.isoformat()
        elif his_end is not None:
            his_end = str(his_end)
        
        his = PointHistory(
            enabled=his_enabled,
            start=his_start,
            end=his_end,
            size=his_size
        )
        
        data['his'] = his
        
        keys_to_remove = ['his_enabled', 'his_start', 'his_end', 'his_size']
        for k in keys_to_remove:
            if k in data:
                del data[k]
                
        return Point(**data)
