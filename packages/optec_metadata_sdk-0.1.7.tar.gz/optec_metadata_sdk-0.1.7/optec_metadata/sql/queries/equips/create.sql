      INSERT INTO equips (site_id, system_id, parent_equip_id, name, tags, tprops, connector_ref)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7)
       RETURNING id

