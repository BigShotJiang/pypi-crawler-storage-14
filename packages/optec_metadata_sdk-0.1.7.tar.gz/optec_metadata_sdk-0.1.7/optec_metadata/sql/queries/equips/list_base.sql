      SELECT 
        e.id,
        e.ref,
        e.site_id,
        s.ref as "siteRef",
        e.system_id,
        sys.ref as "systemRef",
        e.parent_equip_id,
        pe.ref as "parentEquipRef",
        e.name,
        e.tags,
        e.tprops,
        e.connector_ref,
        e.created_at,
        e.updated_at,
        e.deleted_at
      FROM equips e
      LEFT JOIN sites s ON s.id = e.site_id
      LEFT JOIN systems sys ON sys.id = e.system_id
      LEFT JOIN equips pe ON pe.id = e.parent_equip_id
      WHERE e.deleted_at IS NULL

