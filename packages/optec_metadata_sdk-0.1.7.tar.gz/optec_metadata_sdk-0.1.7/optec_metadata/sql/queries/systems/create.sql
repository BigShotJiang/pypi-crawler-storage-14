      INSERT INTO systems (site_id, name, tags, tprops, connector_ref)
       VALUES ($1, $2, $3, $4::jsonb, $5)
       RETURNING id

