      SELECT 
        s.id,
        s.ref,
        s.site_id,
        site.ref as "siteRef",
        s.name,
        s.tags,
        s.tprops,
        s.connector_ref,
        s.created_at,
        s.updated_at,
        s.deleted_at
      FROM systems s
      LEFT JOIN sites site ON site.id = s.site_id
      WHERE s.id = $1 AND s.deleted_at IS NULL

