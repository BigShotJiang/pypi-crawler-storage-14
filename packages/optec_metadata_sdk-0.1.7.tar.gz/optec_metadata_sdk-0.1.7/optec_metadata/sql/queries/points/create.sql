      INSERT INTO points (
        site_id, system_id, equip_id, name, kind, unit, tags, tprops, scaling,
        his_enabled, his_start, his_end, his_size, qos, enabled, connector_ref, monnit_sensor_id
      )
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9::jsonb, $10, $11, $12, $13, $14, $15, $16, $17)
       RETURNING id

