      SELECT 
        p.id,
        p.ref,
        p.site_id,
        s.ref as "siteRef",
        p.system_id,
        sys.ref as "systemRef",
        p.equip_id,
        e.ref as "equipRef",
        p.name,
        p.kind,
        p.unit,
        p.tags,
        p.tprops,
        p.scaling,
        p.his_enabled,
        p.his_start,
        p.his_end,
        p.his_size,
        p.qos,
        p.enabled,
        p.connector_ref,
        p.monnit_sensor_id as "monnitSensorId",
        p.created_at,
        p.updated_at,
        p.deleted_at
      FROM points p
      LEFT JOIN sites s ON s.id = p.site_id
      LEFT JOIN systems sys ON sys.id = p.system_id
      LEFT JOIN equips e ON e.id = p.equip_id
      WHERE p.deleted_at IS NULL

