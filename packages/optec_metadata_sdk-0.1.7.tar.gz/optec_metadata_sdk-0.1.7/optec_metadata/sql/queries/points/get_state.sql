      SELECT 
        point_id,
        last_value_double,
        last_value_bool,
        last_value_text,
        last_quality,
        last_ts,
        updated_at
      FROM point_state
      WHERE point_id = $1

