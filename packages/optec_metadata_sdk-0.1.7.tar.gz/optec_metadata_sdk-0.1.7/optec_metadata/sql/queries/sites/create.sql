      INSERT INTO sites (project_id, name, tz, tags, tprops, connector_ref, address, city, state, country, postal_code, crm_id, coordinates)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
       RETURNING id

