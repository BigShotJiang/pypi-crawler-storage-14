      SELECT 
        s.id,
        s.ref,
        s.project_id,
        p.ref as "projectRef",
        s.name,
        s.tz,
        s.tags,
        s.tprops,
        s.connector_ref,
        s.address,
        s.city,
        s.state,
        s.country,
        s.postal_code as "postalCode",
        s.crm_id as "crmId",
        s.coordinates,
        s.created_at,
        s.updated_at,
        s.deleted_at
      FROM sites s
      LEFT JOIN projects p ON p.id = s.project_id
      WHERE s.project_id = $1 AND s.deleted_at IS NULL

