      INSERT INTO projects (key, name)
       VALUES ($1, $2)
       RETURNING 
         id,
         ref,
         key,
         name,
         ARRAY[]::text[] as tags,
         '{}'::jsonb as tprops,
         NULL as connector_ref,
         created_at,
         updated_at

