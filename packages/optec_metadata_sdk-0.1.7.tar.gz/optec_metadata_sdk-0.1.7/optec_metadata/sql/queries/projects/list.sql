      SELECT 
        id,
        ref,
        key,
        name,
        ARRAY[]::text[] as tags,
        '{}'::jsonb as tprops,
        NULL as connector_ref,
        created_at,
        updated_at
      FROM projects
      ORDER BY name

