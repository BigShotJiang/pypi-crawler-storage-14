import os
import urllib.parse
import asyncpg
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

class DBManager:
    _pool: Optional[asyncpg.Pool] = None

    @classmethod
    async def get_pool(cls) -> asyncpg.Pool:
        """
        Get or create the PostgreSQL/TimescaleDB connection pool.
        Mirroring the logic from optec-metadata-sdk/src/db/postgres-client.ts
        """
        if cls._pool is None:
            config = cls._parse_connection_config()
            logger.info(f"Initializing Metadata DB pool with host={config.get('host')} port={config.get('port')} db={config.get('database')}")
            
            try:
                cls._pool = await asyncpg.create_pool(
                    **config,
                    min_size=1,
                    max_size=20,
                    max_inactive_connection_lifetime=30.0,
                    timeout=30.0
                )
            except Exception as e:
                logger.error(f"Failed to create Metadata DB pool: {e}")
                raise

        return cls._pool

    @classmethod
    async def close_pool(cls):
        """Close the connection pool."""
        if cls._pool:
            await cls._pool.close()
            cls._pool = None
            logger.info("Metadata DB pool closed")

    @classmethod
    def _parse_connection_config(cls) -> Dict[str, Any]:
        """
        Parse connection URI and return connection config dictionary for asyncpg.
        """
        # Prefer TIMESCALE_DB_URI
        connection_string = os.getenv('TIMESCALE_DB_URI') or os.getenv('POSTGRES_URL')

        if not connection_string:
             raise ValueError("TIMESCALE_DB_URI or POSTGRES_URL environment variable must be set")

        # Handle password injection if needed
        # asyncpg handles dsn parsing, but we might need to inject password
        # if the URI doesn't have it but we have TIMESCALE_DB_PASSWORD
        
        try:
            url = urllib.parse.urlparse(connection_string)
            password = url.password
            
            if not password:
                separate_password = os.getenv('TIMESCALE_DB_PASSWORD')
                if separate_password:
                    # Reconstruct URL with password
                    netloc = f"{url.username}:{urllib.parse.quote(separate_password)}@{url.hostname}"
                    if url.port:
                        netloc += f":{url.port}"
                    
                    # asyncpg prefers 'postgresql' scheme
                    scheme = 'postgresql' if url.scheme in ('postgres', 'postgresql') else url.scheme
                    
                    # Rebuild
                    connection_string = urllib.parse.urlunparse((
                        scheme,
                        netloc,
                        url.path,
                        url.params,
                        url.query,
                        url.fragment
                    ))
            
            # Prepare config dict for asyncpg
            # We can pass dsn directly, but might need ssl options
            config = {'dsn': connection_string}
            
            # SSL handling
            # TimescaleDB (TigerCloud) requires SSL
            # optec-metadata-sdk uses ssl: { rejectUnauthorized: false } which is equivalent to ssl='require' 
            # but without verifying CA in some contexts, or creating a context that doesn't verify.
            # asyncpg needs an SSLContext for complex configs, or just 'require'/'prefer'.
            
            # Default to ssl=require for Timescale Cloud, but allow override
            ssl_mode = 'require'
            
            # Check query params for sslmode
            if url.query:
                qs = urllib.parse.parse_qs(url.query)
                if 'sslmode' in qs:
                    ssl_mode = qs['sslmode'][0]

            # In asyncpg, ssl='require' validates certificates. 
            # If we want { rejectUnauthorized: false } behavior (node), we need a custom context
            # that disables verification.
            import ssl
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            config['ssl'] = ssl_context
            
            return config

        except Exception as e:
            logger.error(f"Error parsing connection string: {e}")
            raise

    @classmethod
    async def fetch_all(cls, query: str, *args) -> list[asyncpg.Record]:
        pool = await cls.get_pool()
        async with pool.acquire() as conn:
            return await conn.fetch(query, *args)

    @classmethod
    async def fetch_one(cls, query: str, *args) -> Optional[asyncpg.Record]:
        pool = await cls.get_pool()
        async with pool.acquire() as conn:
            return await conn.fetchrow(query, *args)

    @classmethod
    async def execute(cls, query: str, *args) -> str:
        pool = await cls.get_pool()
        async with pool.acquire() as conn:
            return await conn.execute(query, *args)

    @classmethod
    async def transaction(cls):
        """
        Return a connection that can be used for a transaction.
        Usage:
            pool = await DBManager.get_pool()
            async with pool.acquire() as conn:
                async with conn.transaction():
                    await conn.execute(...)
        Helper wrapper is tricky with asyncpg transaction context manager.
        """
        pool = await cls.get_pool()
        return pool.acquire()

