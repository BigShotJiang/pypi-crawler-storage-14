import os
import re
from pathlib import Path
from typing import List, Optional, Dict, Any

# Base directory for SQL queries
# In development (monorepo): ../../../../sql/queries (from optec_metadata/utils.py)
# When installed: SQL files should be packaged with the distribution
# For now, we'll try to find it relative to the package location
def _get_sql_dir() -> Path:
    """Get the SQL queries directory path."""
    # First, try relative to this file (development mode in monorepo)
    # From optec_metadata/utils.py -> ../../../../sql/queries
    dev_path = Path(__file__).parent.parent.parent.parent / 'sql' / 'queries'
    if dev_path.exists():
        return dev_path
    
    # Try in package directory (installed mode - SQL files packaged with distribution)
    # From optec_metadata/utils.py -> optec_metadata/sql/queries
    package_sql_path = Path(__file__).parent / 'sql' / 'queries'
    if package_sql_path.exists():
        return package_sql_path
    
    # Fallback: try to find it via environment variable
    env_sql_path = os.getenv('OPTEC_METADATA_SQL_PATH')
    if env_sql_path:
        return Path(env_sql_path)
    
    # Last resort: assume it's in the package directory
    return package_sql_path

def get_sql(entity: str, query_name: str) -> str:
    """Load SQL query from file."""
    sql_dir = _get_sql_dir()
    file_path = sql_dir / entity / f"{query_name}.sql"
    if not file_path.exists():
        raise FileNotFoundError(f"SQL query file not found: {file_path}. Searched in: {sql_dir}")
    return file_path.read_text()


def normalize_tag(tag: str) -> Optional[str]:
    """
    Normalize a single tag according to the rules:
    1. Lowercase
    2. Replace whitespace with hyphens
    3. Remove empty strings
    """
    if not tag or not isinstance(tag, str):
        return None
    
    # Convert to lowercase
    normalized = tag.lower().strip()
    
    # Replace whitespace (spaces, tabs, newlines) with hyphens
    normalized = re.sub(r'\s+', '-', normalized)
    
    # Remove leading/trailing hyphens
    normalized = re.sub(r'^-+|-+$', '', normalized)
    
    # Return None for empty strings
    if normalized == '':
        return None
    
    return normalized


def normalize_tags(tags: List[str]) -> List[str]:
    """
    Normalize an array of tags:
    1. Normalize each tag
    2. Remove nulls and empty strings
    3. Deduplicate (case-insensitive)
    4. Sort alphabetically
    """
    if not isinstance(tags, list):
        return []
    
    # Normalize and filter
    normalized = [tag for tag in [normalize_tag(t) for t in tags] if tag is not None]
    
    # Deduplicate using a set (case-insensitive)
    unique = list(set(tag.lower() for tag in normalized))
    
    # Sort alphabetically
    return sorted(unique)


def normalize_tprops(value: Any) -> Dict[str, Any]:
    """
    Normalize tprops: convert null/undefined to empty object.
    
    Args:
        value: The tprops value to normalize
        
    Returns:
        A dictionary (empty dict if value is None, not an object, or an array)
    """
    if value is None:
        return {}
    
    if isinstance(value, list) or not isinstance(value, dict):
        return {}
    
    return value


def ref_to_id(ref: str) -> Optional[str]:
    """
    Extract UUID from Ref string.
    
    Ref format: "type:uuid"
    Example: "site:123e4567-e89b-12d3-a456-426614174000"
    
    Args:
        ref: The Ref string to parse
        
    Returns:
        The UUID string, or None if invalid
    """
    if not ref or not isinstance(ref, str):
        return None
    
    parts = ref.split(':')
    if len(parts) != 2:
        return None
    
    type_part, id_part = parts
    
    valid_types = ['project', 'site', 'system', 'equip', 'point']
    if type_part not in valid_types:
        return None
    
    # Basic UUID validation (36 characters with dashes)
    if not re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', id_part, re.IGNORECASE):
        return None
    
    return id_part
