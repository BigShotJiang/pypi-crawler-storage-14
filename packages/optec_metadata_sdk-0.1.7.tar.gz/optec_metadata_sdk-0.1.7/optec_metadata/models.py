from datetime import datetime
from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field, ConfigDict

# Types
Ref = str
EntityType = Literal['project', 'site', 'system', 'equip', 'point']
PointKind = Literal['Number', 'Bool', 'Str']
Quality = Literal['good', 'uncertain', 'bad']

class BaseEntity(BaseModel):
    model_config = ConfigDict(extra='ignore')
    id: str
    ref: Ref
    tags: List[str] = Field(default_factory=list)
    tprops: Dict[str, Any] = Field(default_factory=dict)
    connector_ref: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None

class Project(BaseEntity):
    key: str
    name: str

class Site(BaseEntity):
    projectRef: Ref
    name: str
    tz: str
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    postalCode: Optional[str] = None
    crmId: Optional[str] = None
    coordinates: Optional[Dict[str, Any]] = None

class System(BaseEntity):
    siteRef: Ref
    name: str

class Equip(BaseEntity):
    siteRef: Ref
    systemRef: Ref
    parentEquipRef: Optional[Ref] = None
    name: str

class PointHistory(BaseModel):
    enabled: bool = False
    start: Optional[str] = None  # ISO timestamp string
    end: Optional[str] = None
    size: Optional[int] = None

class PointState(BaseModel):
    point_id: str
    curVal: Optional[Any] = None
    quality: Optional[Quality] = None
    ts: Optional[str] = None  # ISO timestamp string
    updated_at: datetime

class Point(BaseEntity):
    siteRef: Ref
    systemRef: Ref
    equipRef: Ref
    name: str
    kind: PointKind
    unit: Optional[str] = None
    scaling: Optional[Dict[str, Any]] = None
    his: Optional[PointHistory] = None
    qos: Quality
    enabled: bool
    monnitSensorId: Optional[str] = None
    state: Optional[PointState] = None

# DTOs
class CreateProjectDTO(BaseModel):
    key: str
    name: str

class UpdateProjectDTO(BaseModel):
    key: Optional[str] = None
    name: Optional[str] = None

class CreateSiteDTO(BaseModel):
    projectRef: Ref
    name: str
    tz: str
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    connector_ref: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    postalCode: Optional[str] = None
    crmId: Optional[str] = None
    coordinates: Optional[Dict[str, Any]] = None

class CreateSystemDTO(BaseModel):
    siteRef: Ref
    name: str
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    connector_ref: Optional[str] = None

class CreateEquipDTO(BaseModel):
    siteRef: Ref
    systemRef: Ref
    parentEquipRef: Optional[Ref] = None
    name: str
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    connector_ref: Optional[str] = None

class CreatePointDTO(BaseModel):
    siteRef: Ref
    systemRef: Ref
    equipRef: Ref
    name: str
    kind: PointKind
    unit: Optional[str] = None
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    scaling: Optional[Dict[str, Any]] = None
    his: Optional[PointHistory] = None
    qos: Optional[Quality] = 'good'
    enabled: Optional[bool] = True
    connector_ref: Optional[str] = None
    monnitSensorId: Optional[str] = None

class UpdateSiteDTO(BaseModel):
    name: Optional[str] = None
    tz: Optional[str] = None
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    projectRef: Optional[Ref] = None
    connector_ref: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    postalCode: Optional[str] = None
    crmId: Optional[str] = None
    coordinates: Optional[Dict[str, Any]] = None

class UpdateSystemDTO(BaseModel):
    name: Optional[str] = None
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    siteRef: Optional[Ref] = None
    connector_ref: Optional[str] = None

class UpdateEquipDTO(BaseModel):
    name: Optional[str] = None
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    siteRef: Optional[Ref] = None
    systemRef: Optional[Ref] = None
    parentEquipRef: Optional[Ref] = None
    connector_ref: Optional[str] = None

class UpdatePointDTO(BaseModel):
    name: Optional[str] = None
    kind: Optional[PointKind] = None
    unit: Optional[str] = None
    tags: Optional[List[str]] = None
    tprops: Optional[Dict[str, Any]] = None
    siteRef: Optional[Ref] = None
    systemRef: Optional[Ref] = None
    equipRef: Optional[Ref] = None
    scaling: Optional[Dict[str, Any]] = None
    his: Optional[PointHistory] = None
    qos: Optional[Quality] = None
    enabled: Optional[bool] = None
    connector_ref: Optional[str] = None
    monnitSensorId: Optional[str] = None

# Query Params
class ListSitesQuery(BaseModel):
    projectRef: Ref
    q: Optional[str] = None
    tags: Optional[List[str]] = None

class ListSystemsQuery(BaseModel):
    siteRef: Ref
    tags: Optional[List[str]] = None

class ListEquipsQuery(BaseModel):
    systemRef: Optional[Ref] = None
    equipRef: Optional[Ref] = None
    equipTags: Optional[List[str]] = None
    includeChildren: Optional[bool] = False

class ListPointsQuery(BaseModel):
    equipRef: Optional[Ref] = None
    pointTags: Optional[List[str]] = None
    includeChildren: Optional[bool] = False
    siteRef: Optional[Ref] = None
    systemRef: Optional[Ref] = None

