import os
from PIL import Image
from typing import Dict, Any


def validate_image(image_path: str) -> Dict[str, Any]:
    if not os.path.exists(image_path):
        return {"valid": False, "error": f"Image not found: {image_path}"}

    try:
        with Image.open(image_path) as img:
            img.verify()
        return {"valid": True, "error": None}
    except Exception as e:
        return {"valid": False, "error": f"Invalid image: {str(e)}"}


def prepare_image_data(image_path: str) -> Dict[str, Any]:
    try:
        with Image.open(image_path) as img:
            return {
                "width": img.width,
                "height": img.height,
                "format": img.format,
                "mode": img.mode,
                "size_mb": os.path.getsize(image_path) / (1024 * 1024)
            }
    except Exception as e:
        return {"error": f"Error getting metadata: {str(e)}"}