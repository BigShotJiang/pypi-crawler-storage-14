from .agent import HairEditorAgent

__all__ = ["HairEditorAgent"]

try:
    from importlib.metadata import version
    __version__ = version("hair-editor-agent")
except ImportError:
    __version__ = "0.1.0-dev"