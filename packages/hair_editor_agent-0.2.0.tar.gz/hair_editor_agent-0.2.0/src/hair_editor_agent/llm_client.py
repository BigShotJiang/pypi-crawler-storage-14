import requests
import base64
import re
from typing import Dict, Any, Optional
from PIL import Image
import io
import time


class LLMClient:
    def __init__(self, api_key: str, max_image_size: Optional[int] = 1024, jpeg_quality: int = 85, output_format: str = "JPEG"):
        self.api_key = api_key
        self.base_url = "https://openrouter.ai/api/v1/chat/completions"
        # Compression / resize defaults
        self.max_image_size = max_image_size
        self.jpeg_quality = jpeg_quality
        self.output_format = output_format

    @staticmethod
    def _sanitize_filename_component(s: str) -> str:
        # Keep only safe filename chars and limit length
        import re
        if not s:
            return ""
        cleaned = re.sub(r"[^A-Za-z0-9_.-]", "_", s)
        return cleaned[:64]

    def image_to_base64(self, image_path: str, max_size: Optional[int] = None, quality: Optional[int] = None, output_format: Optional[str] = None) -> str:
        """
        Read an image from disk, optionally resize and recompress it, and return a base64 string.

        - max_size: maximum width/height in pixels; preserves aspect ratio. If None, uses client default.
        - quality: JPEG quality (1-95) when output_format is JPEG. If None, uses client default.
        - output_format: "JPEG" or "PNG". If None, uses client default.
        """
        try:
            max_size = self.max_image_size if max_size is None else max_size
            quality = self.jpeg_quality if quality is None else quality
            output_format = self.output_format if output_format is None else output_format

            with Image.open(image_path) as im:
                # Convert transparencies to solid background if needed
                if im.mode in ("RGBA", "LA"):
                    bg = Image.new("RGB", im.size, (255, 255, 255))
                    bg.paste(im, mask=im.split()[-1])
                    im = bg
                else:
                    im = im.convert("RGB")

                # Resize if larger than max_size
                if max_size is not None:
                    w, h = im.size
                    if max(w, h) > max_size:
                        ratio = max_size / float(max(w, h))
                        new_size = (int(w * ratio), int(h * ratio))
                        im = im.resize(new_size, Image.LANCZOS)

                buf = io.BytesIO()
                save_kwargs = {}
                fmt = output_format.upper() if isinstance(output_format, str) else "JPEG"
                if fmt == "JPEG":
                    save_kwargs["quality"] = int(max(10, min(95, quality)))
                    save_kwargs["optimize"] = True
                elif fmt == "PNG":
                    save_kwargs["optimize"] = True

                im.save(buf, format=fmt, **save_kwargs)
                buf.seek(0)
                return base64.b64encode(buf.read()).decode('utf-8')

        except FileNotFoundError:
            raise Exception(f"Image not found: {image_path}")
        except Exception as e:
            raise Exception(f"Error reading or processing image: {str(e)}")

    def edit_hair(self, image_path: str, hair_style: str, hair_color: str) -> Dict[str, Any]:
        image_base64 = self.image_to_base64(image_path)

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/msalsas/hair-editor-agent",
            "X-Title": "Hair Editor Agent"
        }

        prompt = f"EDIT THIS IMAGE: Change the hair to {hair_color} color and {hair_style} style. Keep the same face, features, and background. Return the edited image."

        payload = {
            "model": "google/gemini-3-pro-image-preview",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_base64}",
                                "detail": "high"
                            }
                        }
                    ]
                }
            ],
            "max_tokens": 1000
        }

        try:
            response = requests.post(self.base_url, headers=headers, json=payload, timeout=120)

            if response.status_code == 200:
                return self._process_api_response(response.json(), hair_style, hair_color)
            else:
                return {
                    "success": False,
                    "error": f"API Error: {response.status_code}",
                    "edited_image_path": None
                }

        except requests.exceptions.Timeout:
            return {
                "success": False,
                "error": "Timeout: API took too long to respond",
                "edited_image_path": None
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Connection error: {str(e)}",
                "edited_image_path": None
            }

    def _process_api_response(self, response_json: Dict, hair_style: str, hair_color: str) -> Dict[str, Any]:
        try:
            if 'choices' in response_json and len(response_json['choices']) > 0:
                message = response_json['choices'][0].get('message', {})

                if 'images' in message and isinstance(message['images'], list):
                    for image_obj in message['images']:
                        if 'image_url' in image_obj and 'url' in image_obj['image_url']:
                            url = image_obj['image_url']['url']
                            if url.startswith('data:image'):
                                image_path = self._save_image_from_url(url, hair_style, hair_color)
                                if image_path:
                                    return {
                                        "success": True,
                                        "edited_image_path": image_path,
                                        "hair_style": hair_style,
                                        "hair_color": hair_color
                                    }

                content = message.get('content', '')
                if content and isinstance(content, str):
                    base64_match = re.search(r'data:image/(?:jpeg|png|jpg);base64,([A-Za-z0-9+/=]+)', content)
                    if base64_match:
                        image_path = self._save_image_base64(base64_match.group(1), hair_style, hair_color)
                        return {
                            "success": True,
                            "edited_image_path": image_path,
                            "hair_style": hair_style,
                            "hair_color": hair_color
                        }

            return {
                "success": False,
                "error": "Could not extract edited image from response",
                "edited_image_path": None
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Error processing response: {str(e)}",
                "edited_image_path": None
            }

    @staticmethod
    def _save_image_from_url(url: str, hair_style: str, hair_color: str) -> Optional[str]:
        base64_match = re.search(r'data:image/(?:jpeg|png|jpg);base64,([A-Za-z0-9+/=]+)', url)
        if base64_match:
            return LLMClient._save_image_base64(base64_match.group(1), hair_style, hair_color)
        return None

    @staticmethod
    def _save_image_base64(base64_string: str, hair_style: str, hair_color: str) -> str:
        try:
            padding = 4 - (len(base64_string) % 4)
            if padding != 4:
                base64_string += '=' * padding

            image_data = base64.b64decode(base64_string)
            image = Image.open(io.BytesIO(image_data))

            timestamp = int(time.time())
            safe_style = LLMClient._sanitize_filename_component(hair_style)
            safe_color = LLMClient._sanitize_filename_component(hair_color)
            filename = f"edited_hair_{safe_style}_{safe_color}_{timestamp}.jpg"

            image.save(filename, "JPEG", quality=95)
            return filename

        except Exception as e:
            raise Exception(f"Error saving image: {e}")
