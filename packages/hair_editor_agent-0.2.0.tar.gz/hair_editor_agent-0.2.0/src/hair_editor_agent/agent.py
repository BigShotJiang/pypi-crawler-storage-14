from agent_core_framework import BaseAgent, AgentTask, AgentResponse
from typing import Dict, Any
from .llm_client import LLMClient
from .image_utils import validate_image


class HairEditorAgent(BaseAgent):
    """
    Specialized agent for editing hairstyles and colors.
    Uses an LLM-backed image editing client for realistic transformations.

    This agent accepts free-form, descriptive styles and colors so an
    orchestrator can pass detailed instructions (for example:
    "Shoulder-length wavy hair with subtle balayage highlights,")
    without being constrained to a pre-defined set.

    You can configure image compression via constructor options which are
    forwarded to the underlying LLMClient (max_image_size, jpeg_quality, output_format).
    """

    def __init__(self, openrouter_api_key: str, max_image_size: int = 1024, jpeg_quality: int = 85, output_format: str = "JPEG"):
        super().__init__("HairEditor", "1.0.0")
        self.supported_tasks = [
            "edit_hair_style",
            "edit_hair_color",
            "change_appearance"
        ]
        self.client = LLMClient(openrouter_api_key, max_image_size=max_image_size, jpeg_quality=jpeg_quality, output_format=output_format)

    def process(self, task: AgentTask) -> AgentResponse:
        try:
            task_type = task.type
            payload = task.payload

            if task_type == "edit_hair_style":
                return self._edit_hair_style(payload)
            elif task_type == "edit_hair_color":
                return self._edit_hair_color(payload)
            elif task_type == "change_appearance":
                return self._change_appearance(payload)
            else:
                return AgentResponse(
                    success=False,
                    error=f"Unsupported task type: {task_type}",
                    agent_name=self.name
                )

        except Exception as e:
            return AgentResponse(
                success=False,
                error=f"Error processing task: {str(e)}",
                agent_name=self.name
            )

    def _edit_hair_style(self, payload: Dict[str, Any]) -> AgentResponse:
        required_fields = ['image_path', 'hair_style']
        if not all(field in payload for field in required_fields):
            return AgentResponse(
                success=False,
                error=f"Missing required fields: {required_fields}",
                agent_name=self.name
            )

        image_path = payload['image_path']
        hair_style = payload['hair_style']
        hair_color = payload.get('hair_color', 'same')

        validation = validate_image(image_path)
        if not validation["valid"]:
            return AgentResponse(
                success=False,
                error=validation["error"],
                agent_name=self.name
            )

        result = self.client.edit_hair(
            image_path=image_path,
            hair_style=hair_style,
            hair_color=hair_color
        )

        return AgentResponse(
            success=result["success"],
            data=result,
            error=result.get("error", ""),
            agent_name=self.name
        )

    def _edit_hair_color(self, payload: Dict[str, Any]) -> AgentResponse:
        required_fields = ['image_path', 'hair_color']
        if not all(field in payload for field in required_fields):
            return AgentResponse(
                success=False,
                error=f"Missing required fields: {required_fields}",
                agent_name=self.name
            )

        image_path = payload['image_path']
        hair_color = payload['hair_color']
        hair_style = payload.get('hair_style', 'same')

        validation = validate_image(image_path)
        if not validation["valid"]:
            return AgentResponse(
                success=False,
                error=validation["error"],
                agent_name=self.name
            )

        result = self.client.edit_hair(
            image_path=image_path,
            hair_style=hair_style,
            hair_color=hair_color
        )

        return AgentResponse(
            success=result["success"],
            data=result,
            error=result.get("error", ""),
            agent_name=self.name
        )

    def _change_appearance(self, payload: Dict[str, Any]) -> AgentResponse:
        required_fields = ['image_path', 'hair_style', 'hair_color']
        if not all(field in payload for field in required_fields):
            return AgentResponse(
                success=False,
                error=f"Missing required fields: {required_fields}",
                agent_name=self.name
            )

        validation = validate_image(payload['image_path'])
        if not validation["valid"]:
            return AgentResponse(
                success=False,
                error=validation["error"],
                agent_name=self.name
            )

        hair_style = payload['hair_style']
        hair_color = payload['hair_color']

        result = self.client.edit_hair(
            image_path=payload['image_path'],
            hair_style=hair_style,
            hair_color=hair_color
        )

        return AgentResponse(
            success=result["success"],
            data=result,
            error=result.get("error", ""),
            agent_name=self.name
        )

    def get_info(self) -> Dict[str, Any]:
        base_info = super().get_info()
        base_info.update({
            "api_client": self.client.__class__.__name__,
            "api_client_base_url": getattr(self.client, "base_url", None),
            "note": "Accepts free-form descriptive hair_style and hair_color strings"
        })
        return base_info
