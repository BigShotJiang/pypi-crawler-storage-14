from hair_editor_agent import HairEditorAgent
from agent_core_framework import AgentTask
import os
from PIL import Image


def _create_temp_image(path):
    img = Image.new("RGB", (8, 8), (0, 128, 255))
    img.save(path, format="JPEG")


def test_agent_creation():
    agent = HairEditorAgent(openrouter_api_key="test_key")

    assert agent.name == "HairEditor"
    assert agent.version == "1.0.0"
    assert "edit_hair_style" in agent.supported_tasks
    print("✅ Agent creation test passed")


def test_agent_info():
    agent = HairEditorAgent(openrouter_api_key="test_key")
    info = agent.get_info()

    assert info["name"] == "HairEditor"
    assert "api_client" in info
    assert info["api_client"] == agent.client.__class__.__name__
    print("✅ Agent info test passed")


def test_validation():
    agent = HairEditorAgent(openrouter_api_key="test_key")

    task = AgentTask(
        type="edit_hair_style",
        payload={"hair_style": "short"}  # Missing image_path
    )

    result = agent.process(task)
    assert result.success is False
    assert "Missing required fields" in result.error
    print("✅ Validation test passed")


def test_edit_hair_success_monkeypatched(tmp_path):
    img_path = tmp_path / "person_temp.jpg"
    _create_temp_image(img_path)

    agent = HairEditorAgent(openrouter_api_key="test_key")

    class DummyClient:
        def edit_hair(self, image_path: str, hair_style: str, hair_color: str):
            # ensure the agent passes the same path we created
            assert os.path.exists(image_path)
            return {
                "success": True,
                "edited_image_path": "edited_person.jpg",
                "hair_style": hair_style,
                "hair_color": hair_color,
            }

    agent.client = DummyClient()

    task = AgentTask(
        type="edit_hair_style",
        payload={"image_path": str(img_path), "hair_style": "short", "hair_color": "brown"},
    )

    res = agent.process(task)
    assert res.success is True
    assert res.data["edited_image_path"] == "edited_person.jpg"


def test_descriptive_style_is_accepted(tmp_path):
    img_path = tmp_path / "person_freeform.jpg"
    _create_temp_image(img_path)

    agent = HairEditorAgent(openrouter_api_key="test_key")

    description = "Shoulder-length wavy hair with subtle balayage highlights, loose beachy waves"

    class DummyClientForDesc:
        def edit_hair(self, image_path: str, hair_style: str, hair_color: str):
            # Assert the description is passed through unchanged (or starts with expected words)
            assert "Shoulder-length" in hair_style or "beachy" in hair_style
            return {"success": True, "edited_image_path": "desc_ok.jpg", "hair_style": hair_style, "hair_color": hair_color}

    agent.client = DummyClientForDesc()

    task = AgentTask(
        type="edit_hair_style",
        payload={"image_path": str(img_path), "hair_style": description, "hair_color": "brown"},
    )

    res = agent.process(task)
    assert res.success is True
    assert res.data["edited_image_path"] == "desc_ok.jpg"


def test_unsupported_color_returns_error(tmp_path):
    img_path = tmp_path / "person_bad_color.jpg"
    _create_temp_image(img_path)

    agent = HairEditorAgent(openrouter_api_key="test_key")

    task = AgentTask(
        type="edit_hair_color",
        payload={"image_path": str(img_path), "hair_color": "chartreuse"},
    )

    res = agent.process(task)
    assert res.success is False


def test_freeform_color_forwarded(tmp_path):
    img_path = tmp_path / "person_color_freeform.jpg"
    _create_temp_image(img_path)

    agent = HairEditorAgent(openrouter_api_key="test_key")

    class DummyClientColor:
        def edit_hair(self, image_path: str, hair_style: str, hair_color: str):
            assert hair_color == "chartreuse with gold highlights"
            return {"success": True, "edited_image_path": "color_ok.jpg", "hair_style": hair_style, "hair_color": hair_color}

    agent.client = DummyClientColor()

    task = AgentTask(
        type="edit_hair_color",
        payload={"image_path": str(img_path), "hair_color": "chartreuse with gold highlights"},
    )

    res = agent.process(task)
    assert res.success is True
    assert res.data["edited_image_path"] == "color_ok.jpg"


def test_change_appearance_accepts_freeform(tmp_path):
    img_path = tmp_path / "person_change.jpg"
    _create_temp_image(img_path)

    agent = HairEditorAgent(openrouter_api_key="test_key")

    class DummyClientBoth:
        def edit_hair(self, image_path: str, hair_style: str, hair_color: str):
            assert "asymmetrical" in hair_style
            assert "rose gold" in hair_color
            return {"success": True, "edited_image_path": "change_ok.jpg", "hair_style": hair_style, "hair_color": hair_color}

    agent.client = DummyClientBoth()

    task = AgentTask(
        type="change_appearance",
        payload={"image_path": str(img_path), "hair_style": "asymmetrical layered cut with long fringe", "hair_color": "rose gold with warm undertones"},
    )

    res = agent.process(task)
    assert res.success is True
    assert res.data["edited_image_path"] == "change_ok.jpg"


def test_image_compression_reduces_size(tmp_path):
    # create a large image
    img_path = tmp_path / "large.jpg"
    from PIL import Image
    img = Image.new("RGB", (2000, 1500), (10, 200, 120))
    img.save(img_path, format="JPEG", quality=95)

    from hair_editor_agent.llm_client import LLMClient

    # client without resizing (max_image_size=None)
    client_no_compress = LLMClient(api_key="test", max_image_size=None, jpeg_quality=95)
    b64_no = client_no_compress.image_to_base64(str(img_path))

    # client with compression
    client_compress = LLMClient(api_key="test", max_image_size=512, jpeg_quality=50)
    b64_yes = client_compress.image_to_base64(str(img_path))

    # compressed base64 should be smaller
    assert len(b64_yes) < len(b64_no)


if __name__ == "__main__":
    test_agent_creation()
    test_agent_info()
    test_validation()
    print("🎉 All basic tests passed!")