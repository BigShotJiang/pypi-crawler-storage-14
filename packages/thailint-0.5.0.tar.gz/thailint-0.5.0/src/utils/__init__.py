"""Utils package for shared utilities.

This package provides common utility functions used across the linter framework.
"""
