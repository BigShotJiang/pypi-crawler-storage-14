def boolean(arg: str) -> bool:
    return arg.lower() in {'true', 't', 'yes', 'y', '1', 'on'}
