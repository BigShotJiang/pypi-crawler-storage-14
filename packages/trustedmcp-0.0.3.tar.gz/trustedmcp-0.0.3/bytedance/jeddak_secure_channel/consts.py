# Copyright (c) 2025 Beijing Volcano Engine Technology Co., Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

class ClientConst:
    MIN_ATTEST_INTERVAL = 3600  # 内置最小的attest间隔，单位秒
