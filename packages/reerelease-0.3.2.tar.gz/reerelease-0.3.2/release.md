# REErelease releases

## 0.3.2

API fixes and issue printing
**Release date:** 2025-11-27
**Release artifact:** [pypi 0.3.2](https://pypi.org/project/reerelease/0.3.2/)

### 0.3.2 Improvements

- `context check` prints the all the contexts & milestones issues
- Added command signature tests to ensure API is known and controlled

### 0.3.2 Fixes

- Corrected annotation to ignore capitalization and generalized a bit the name detection of *roadmap* and *release* files
- Corrected default `context` & `milestone` commands relaying object
- Corrected *milestone* status validation to use the string value
- Added `-p` alias to **all** `--path` argument
- Added `--verbose` alias to `--verbosity` argument

---

## 0.3.1

Restructure, milestone and DSL pipeline
**Release date:** 2025-11-17
**Release artifact:** [pypi 0.3.1](https://pypi.org/project/reerelease/0.3.1/)
**Note:** Should have been 0.3.0 but release scripts failed and pypi.org doesn't allow re-using version

### 0.3.1 Improvements

- Massive refactoring for long-term scalability (still needs work on the DSL part)
- Added user guide and overall documentation
- Added a DSL system to read annotation in the jinja templates making them bidirectionnal
- Added an inplace edit mecanism to make chirugical modification in files (fallback to full render)
- Extended the service layer (context_manager, milestone_manager, template_manager) to improve separation of concern and re-usability
- Improved validation methods
- Added a global config object giving r/w access to global configuration to almost all code context
- CLI code is now a thin layer calling services and reporting on it, arguably a real MVC now
- API now has `milestone` command operationnal (see [commands.md](/docs/commands.md)) for details
- API now has `context` command refactored and functionnal with more information and overall usefulness

### 0.3.1 Known Problems

- `context` default command to list but fails because OptionInfo object is passed as max_depth instead of integer
- `milestone` default command to list but fails because OptionInfo object is passed to pathlib.Path() instead of string
- *roadmap* and *release* annotation does not capture capitalized title or slightly different yet common phrasing like "release note"
- `milestone check` print the MilestoneStatus object itself and  always fail on status check

---

## 0.2.0

Scalable command structure  
**Release date:** 2025-09-16  
**Release artifact:** [pypi 0.2.0](https://pypi.org/project/reerelease/0.2.0/)

### 0.2.0 Improvements

- Improved command structure: added `context` command with subcommands (`list`, `add`, `remove`, `check`) and forwarded aliases `contexts` → `context list`, `new` → `context add`.
- Added skeleton commands for `task`, `problem`, and `milestone` to prepare for future task/problem management features.
- Integrated automatic hooks for linting, formatting, and type checking to run as part of the development workflow.
- Modular templating groundwork laid for later expansion into domain-specific templates and composition (no breaking changes to existing templates).
- Documentation and roadmap updated to reflect planned features and next milestones.

---

## 0.1.1

Minor metadata correction  
**Release date:** 2025-09-08  
**Release artifact:** [pypi 0.1.1](https://pypi.org/project/reerelease/0.1.1/)

### 0.1.1 Fixes

- Removed untested python version
- Added classifier for pypi publishing

---

## 0.1.0

Initial CLI & template creation  
**Release date:** 2025-09-08  
**Release artifact:** [pypi 0.1.0](https://pypi.org/project/reerelease/0.1.0/)

### 0.1.0 New Commands

- `reerelease new <context-name> [path]` - Create new context with templates
- `reerelease contexts [path]` - Discover and display existing contexts

### 0.1.0 Features

- Full Python TDD setup with automated testing and coverage
- Logging system with configurable verbosity levels
- Jinja2 templating engine for document generation
- Safe context creation (no overwriting existing contexts)
- Automatic context detection with name and path extraction
- Basic templates: release.md, roadmap.md, readme.md

### 0.1.0 Foundation

Establishes the core architecture for template-based project documentation management with CLI interface and context discovery system.

### 0.1.0 Known problems

- Very basic templating system
- Command structure not scalable
