# SPDX-FileCopyrightText: 2025-present Realee inc. <admin@realee.tech>
#
# SPDX-License-Identifier: MIT
__version__ = "0.3.2"
__author__ = "Laurence DV"
