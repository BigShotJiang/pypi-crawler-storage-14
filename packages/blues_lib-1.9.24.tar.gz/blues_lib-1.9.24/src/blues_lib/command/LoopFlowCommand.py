from blues_lib.command.FlowCommand import FlowCommand
from blues_lib.type.output.STDOut import STDOut

class LoopFlowCommand(FlowCommand):

  NAME = None

  def _run(self)->STDOut:

    loop:dict = self._config.get('loop') or {}
    entities:list[dict] = loop.get('entities') or []
    count:int = int(loop.get('count') or -1)
    
    if not entities:
      raise Exception(f'{self.NAME} must have loop entities')

    # one by one
    items:list[dict] = []
    for entity in entities:
      # must pass a list
      stdout:STDOut = self._run_one([entity])
      sub_items:list[dict] = stdout.data or []
      items.extend(sub_items)
      if count > 0 and len(items) >= count:
        break
    items = items[:count] if count > 0 else items
    return STDOut(200,'flow loop success',items)

  def _run_one(self,start_data:list[dict]=None)->STDOut:
    start_bizdata = {"data":start_data} if start_data else None
    dag_def:dict = self._get_dag_with_start(start_bizdata)
    return self._run_flow(dag_def)
  