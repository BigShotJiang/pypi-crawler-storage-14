from abc import ABC,abstractmethod
from typing import final

from blues_lib.type.executor.Command import Command
from blues_lib.namespace.CrawlerName import CrawlerName
from blues_lib.type.output.STDOut import STDOut
from blues_lib.type.model.Model import Model
from blues_lib.command.io.InputHandler import InputHandler
from blues_lib.command.io.OutputHandler import OutputHandler
from blues_lib.command.io.IOExcept import IOExcept
from blues_lib.hook.command.CommandHook import CommandHook
from blues_lib.deco.CommandSTDOutLog import CommandSTDOutLog

class NodeCommand(Command,ABC):

  NAME = None
  
  def __init__(self,task_def:dict,ti:any) -> None:
    f'''
    Args:
      task_def {dict}: the task's definition
        - id {str} : the task id
        - command {str} : the command name
        - meta {dict} : the task meta data
        - bizdata {dict|None} : the task bizdata
        - input {list|dict|None} : the task input definition
        - output {list|dict|None} : the task output definition
        - setup {list|dict|None} : the task setup hook
        - teardown {list|dict|None} : the task teardown hook
      ti {any} : the task instance
    '''
    super().__init__({})
    self._task_def:dict = task_def
    self._ti:any = ti

    # init model, it will be recalculated by the InputHandler

  @property
  def task_id(self)->str:
    return self._task_def.get('task_id')

  @final
  @CommandSTDOutLog()
  def execute(self)->STDOut:
    
    # validate input: only validate the outer struct of the input
    IOExcept.validate_task(self._task_def)

    # input mappding 
    InputHandler(self._task_def,self._ti).handle()

    # set fields after recalculate the model
    self._setup()

    # Airflow不能识别自定义异常，使用xcom标识状态
    hook_defs:list[dict] = self._task_def.get('before_invoked')
    options:dict = {'ti':self._ti}
    CommandHook(hook_defs,options).execute()

    # 因为有多个hook，所以不能基于某个实例判断是否block或skip
    CommandHook.block(self._ti)
    stdout:STDOut|None = CommandHook.skip(self._ti)
    if stdout:
      return stdout

    stdout = self._invoke()

    hook_defs:list[dict] = self._task_def.get('after_invoked')
    options:dict = {'ti':self._ti,'stdout':stdout}
    CommandHook(hook_defs,options).execute()

    # 因为有多个hook，所以不能基于某个实例判断是否block或skip
    CommandHook.block(self._ti)
    # output after hook deal
    OutputHandler.handle(self._ti,stdout)

    # raise except if the stdout is not matched
    IOExcept.validate_except(self._task_def,stdout)
    
    return stdout
    
  def _setup(self): 
    
    self._dag_def:dict = self._task_def.get('dag') or {}
    # must crate the model after handle the input
    meta = self._task_def.get('meta') or {}
    bizdata = self._task_def.get('bizdata') or {}
    self._model:Model = Model(meta,bizdata)
    self._config:dict = self._model.config
    
    # recalculate the hooks' defs
    self._task_def['before_invoked'] = self._get_hook_defs('before_invoked',bizdata)
    self._task_def['after_invoked'] = self._get_hook_defs('after_invoked',bizdata)

    self._summary:dict = self._config.get(CrawlerName.Field.SUMMARY.value) or {}
    
  def _get_hook_defs(self,hook_name:str,bizdata:dict)->list[dict]:
    if hook_defs:=self._task_def.get(hook_name):
      return Model(hook_defs,bizdata).config
    return []

  @abstractmethod
  def _invoke(self)->STDOut:
    pass
