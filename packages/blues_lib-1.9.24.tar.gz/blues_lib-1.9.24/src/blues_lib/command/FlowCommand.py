from copy import deepcopy
from abc import ABC,abstractmethod
from blues_lib.command.NodeCommand import NodeCommand
from blues_lib.type.output.STDOut import STDOut
from blues_lib.flow.Flow import Flow
from blues_lib.deco.CommandSTDOutLog import CommandSTDOutLog

class FlowCommand(NodeCommand,ABC):

  NAME = None

  def _invoke(self)->STDOut:
    return self._run()

  @abstractmethod
  def _run(self)->STDOut: 
    pass
    
  @CommandSTDOutLog('flow',max_chars=100)
  def _run_flow(self,dag_def:dict)->STDOut:
    flow = self._get_flow(dag_def)
    stdout:STDOut = flow.execute() 
    if stdout.code == 200:
      return flow.last_task_stdout
    else:
      return stdout

  def _get_flow(self,dag_def:dict)->Flow:
    # avoid circular import
    from blues_lib.flow.Flow import Flow
    flow = Flow(dag_def)
    if not flow:
      raise Exception(f'{self.NAME} Failed to create flow')
    return flow

  def _get_dag_with_start(self,bizdata:dict|None=None)->list[dict]:
    dag_def_copy:dict = deepcopy(self._dag_def)
    if not bizdata:
      return dag_def_copy

    start_task_def:dict = self._get_start_task(bizdata)
    tasks:list[dict] = dag_def_copy.get('tasks') or []
    dag_def_copy['tasks'] = [start_task_def] + tasks
    return dag_def_copy
    
  def _get_start_task(self,bizdata:dict)->dict:
    task_def:dict = {
      "task_id":"start",
      "command":"command.standard.dummy",
      "meta":{
        "summary":{
          "code":"${code}",
          "message":"${message}",
          "data":"${data}",
          "detail":"${detail}"
        }
      },
      "bizdata":bizdata,
    }

    return task_def
