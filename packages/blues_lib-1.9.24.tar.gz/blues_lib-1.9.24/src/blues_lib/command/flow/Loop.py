from blues_lib.command.LoopFlowCommand import LoopFlowCommand
from blues_lib.namespace.CommandName import CommandName

class Loop(LoopFlowCommand):

  NAME = CommandName.Flow.LOOP
