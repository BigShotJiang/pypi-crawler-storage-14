## Python types vs JS types
The execute_script return value type -> Ptyhon type

- `null/undefined` -> `None`
- `HTMLDocumentElement` -> `WebElement`
- `string` -> `str`
- `boolean` -> `bool`
- `number` -> `double`
- `number` -> `long`
- `Array` -> `list`
- others -> `str`

## as params
可以对应的这些python类型，同样可以作为`execute_script`的入参直接传给js