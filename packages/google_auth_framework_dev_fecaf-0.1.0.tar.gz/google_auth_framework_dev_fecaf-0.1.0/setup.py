import setuptools

# Lê o conteúdo do README.md para a descrição longa do pacote
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="google-auth-framework-dev-fecaf",  # IMPORTANTE: Escolha um nome único para o PyPI
    version="0.1.0",
    author="dev-fecaf", # Coloque seu nome de usuário ou nome real
    author_email="arthur.souza@fecaf.com.br", # Coloque seu email
    description="Um framework para simplificar a autenticação com APIs do Google via console.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/dev-fecaf/google-auth-framework", # URL do seu repositório
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        'google-api-python-client',
        'google-auth-oauthlib',
    ],
)
