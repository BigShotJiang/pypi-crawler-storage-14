# Google Auth Framework

Este é um framework simples em Python para gerenciar a autenticação com APIs do Google usando o fluxo OAuth 2.0. Ele foi projetado para ser reutilizável e especialmente útil em ambientes de servidor ou contêineres Docker, onde a autenticação precisa ser feita através do console.

## Funcionalidades

- **Gerenciamento de Token**: Cuida do carregamento, validação e atualização automática de tokens de acesso.
- **Fluxo de Autenticação para Servidor**: Implementa um fluxo de autorização que exibe uma URL no console, permitindo que o usuário autorize o acesso em um navegador local e cole a resposta de volta no terminal.
- **Armazenamento Seguro**: Salva as credenciais de token em um arquivo para evitar a necessidade de login a cada execução.
- **Fácil Integração**: Fornece uma classe `GoogleAuthManager` simples para construir e interagir com os serviços das APIs do Google (YouTube, Calendar, Drive, etc.).

## Pré-requisitos

- Python 3.6+
- Um projeto no [Google Cloud Console](https://console.cloud.google.com/).
- Credenciais de OAuth 2.0 (ID do cliente para aplicativos de desktop) baixadas como um arquivo `client_secret.json`.

## Como Configurar

1.  **Instale as dependências:**
    ```bash
    pip install google-api-python-client google-auth-oauthlib
    ```

2.  **Obtenha suas credenciais:**
    - Acesse o [Google Cloud Console](https://console.cloud.google.com/) e crie ou selecione seu projeto.
    - Vá para "APIs e Serviços" > "Credenciais".
    - Crie uma credencial do tipo "ID do cliente OAuth".
    - Selecione "Aplicativo para computador".
    - Após a criação, baixe o arquivo JSON e renomeie-o para `client_secret.json`. Coloque este arquivo na raiz do seu projeto.

3.  **Configure a URI de Redirecionamento:**
    - Dentro das configurações da sua credencial no Google Cloud Console, adicione uma "URI de redirecionamento autorizada".
    - Para uso local e no fluxo deste framework, `http://localhost:8080/` ou `http://localhost:2000/` são boas opções. Certifique-se de que a URI no seu código seja a mesma que está autorizada no console.

## Como Usar

Para utilizar o framework, importe a classe `GoogleAuthManager` e crie uma instância dela, passando as configurações necessárias.

```python
# Exemplo em um arquivo meu_app.py

from google_auth_framework.auth import GoogleAuthManager

# 1. Crie uma instância do gerenciador de autenticação
auth_manager = GoogleAuthManager(
    credentials_file="client_secret.json",
    token_dir="credentials",
    token_filename="meu_token_especifico.json",
    redirect_uri='http://localhost:8080/',  # Deve ser a mesma do Google Console
    scopes=[
        "https://www.googleapis.com/auth/youtube.readonly",
        "https://www.googleapis.com/auth/calendar.readonly"
    ]
)

# 2. Construa os serviços que você precisa
# A autenticação será acionada automaticamente na primeira vez
youtube_service = auth_manager.build_service('youtube', 'v3')
calendar_service = auth_manager.build_service('calendar', 'v3')

# 3. Use os serviços para interagir com as APIs
if youtube_service:
    try:
        print("Buscando vídeos sobre 'Python' no YouTube...")
        response = youtube_service.search().list(
            q="Python",
            part="snippet",
            maxResults=5
        ).execute()

        for item in response.get("items", []):
            print(f"- {item['snippet']['title']}")

    except Exception as e:
        print(f"Ocorreu um erro ao acessar a API do YouTube: {e}")

if calendar_service:
    print("\nServiço do Google Calendar pronto para uso.")

```

### Fluxo de Autenticação (Primeira Execução)

Na primeira vez que o código for executado, ou se o token expirar e não puder ser atualizado, você verá as seguintes instruções no console:

```
Iniciando fluxo de autenticação no console...

--- AÇÃO NECESSÁRIA PARA AUTENTICAÇÃO ---
Para autorizar o acesso, siga estes passos:
1. Abra a seguinte URL no seu navegador:

   https://accounts.google.com/o/oauth2/v2/auth?....

2. Faça login na sua Conta Google e autorize o acesso.
3. Você será redirecionado para uma página (provavelmente exibindo um erro), o que é esperado.
4. Copie a URL completa da barra de endereço do seu navegador.

5. Cole a URL de redirecionamento completa aqui e pressione Enter:
```

Após colar a URL e pressionar Enter, o token será salvo no diretório `credentials/`, e as próximas execuções usarão esse token sem precisar de intervenção manual.
