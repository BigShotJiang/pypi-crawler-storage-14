"""
robotchronograf.cli

Command-line interface for the RobotChronograf Python SDK.

This CLI is intentionally thin:
- it does NOT reimplement the spec
- it delegates to library functions where possible
- it is safe to evolve as the SDK grows

Subcommands:
  - version        → show installed package version
  - barcode now    → emit a simple Temporal Barcode for "now"
  - sync           → sync Chronograf manifest hashes from a spec directory
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

try:
    # Python 3.8+
    from importlib.metadata import version as pkg_version, PackageNotFoundError
except ImportError:  # pragma: no cover
    # For older Python, but we require >=3.10 anyway
    from importlib_metadata import version as pkg_version, PackageNotFoundError  # type: ignore

from .sync import sync_chronograf


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class TemporalBarcode:
    """
    Minimal, implementation-agnostic Temporal Barcode representation.

    This is a pragmatic, non-normative structure to make the CLI usable.
    The full, normative schema is defined in the Chronograf Specification.
    """

    time_atom_version_str: str
    captured_at_iso8601_str: str
    captured_at_epoch_ns_int: int
    uncertainty_exp10_int: int
    source_clock_str: str

    def to_dict(self) -> dict:
        return {
            "time_atom_version_str": self.time_atom_version_str,
            "captured_at_iso8601_str": self.captured_at_iso8601_str,
            "captured_at_epoch_ns_int": self.captured_at_epoch_ns_int,
            "uncertainty_exp10_int": self.uncertainty_exp10_int,
            "source_clock_str": self.source_clock_str,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_version() -> str:
    try:
        return pkg_version("robotchronograf")
    except PackageNotFoundError:
        return "0.0.0-dev"


def _emit_barcode_now() -> TemporalBarcode:
    """
    Generate a simple Temporal Barcode for "now".

    This is a practical default:
    - uses system wall-clock + epoch_ns
    - assumes an uncertainty order of magnitude (~microseconds → 10^-6)
      but we stay conservative and default to 10^-9 for now.
    """
    now = datetime.now(timezone.utc)
    epoch_ns = time.time_ns()

    return TemporalBarcode(
        time_atom_version_str="time_atom_v1",
        captured_at_iso8601_str=now.isoformat(),
        captured_at_epoch_ns_int=epoch_ns,
        uncertainty_exp10_int=-9,
        source_clock_str="SYSTEM_UTC_MONOTONIC_APPROX",
    )


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def cmd_version(_args: argparse.Namespace) -> int:
    ver = _resolve_version()
    print(f"robotchronograf {ver}")
    return 0


def cmd_barcode_now(_args: argparse.Namespace) -> int:
    barcode = _emit_barcode_now()
    print(json.dumps(barcode.to_dict(), indent=2))
    return 0


def cmd_sync(args: argparse.Namespace) -> int:
    spec_dir = Path(args.spec_dir).expanduser().resolve()

    if not spec_dir.exists() or not spec_dir.is_dir():
        print(f"[ERROR] Spec directory not found or not a directory: {spec_dir}", file=sys.stderr)
        return 1

    # Expecting files like time_kernel.rcg, time_channels.rcg, time_topology.rcg, chronograf_manifest.rcg
    sync_chronograf(str(spec_dir))
    return 0


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="robotchronograf",
        description="RobotChronograf CLI — tools for the Chronograf temporal standard.",
    )

    subparsers = parser.add_subparsers(
        title="subcommands",
        dest="command",
        metavar="<command>",
    )

    # version
    p_version = subparsers.add_parser(
        "version",
        help="Show installed robotchronograf version.",
    )
    p_version.set_defaults(func=cmd_version)

    # barcode now
    p_barcode = subparsers.add_parser(
        "barcode",
        help="Generate Temporal Barcodes.",
    )
    barcode_sub = p_barcode.add_subparsers(
        title="barcode commands",
        dest="barcode_cmd",
        metavar="<barcode_cmd>",
    )

    p_barcode_now = barcode_sub.add_parser(
        "now",
        help="Generate a Temporal Barcode for the current instant.",
    )
    p_barcode_now.set_defaults(func=cmd_barcode_now)

    # sync
    p_sync = subparsers.add_parser(
        "sync",
        help="Sync Chronograf manifest hashes from a spec directory.",
        description=(
            "Update the Chronograf manifest with the SHA-256 digests of "
            "time_kernel.rcg, time_channels.rcg, and time_topology.rcg."
        ),
    )
    p_sync.add_argument(
        "spec_dir",
        type=str,
        help="Path to the directory containing Chronograf .rcg files and manifest.",
    )
    p_sync.set_defaults(func=cmd_sync)

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "func"):
        parser.print_help()
        return 1

    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
