# Chronograf Python SDK  
**Official Python Toolkit for the Chronograf Temporal Standard**

This repository provides the reference Python implementation for interacting with **Chronograf**, the temporal substrate defined in the `chronograf-spec` repository.

---

## Purpose

The SDK bridges the Chronograf Specification with real systems, enabling:

- loading and validating `.rcg` layers  
- consuming manifests  
- generating Time Atoms & Temporal Barcodes  
- interacting with deterministic or simulated time  

---

## Polymorf Licensing Strategy

Chronograf uses a layered licensing approach:

- **The Specification** → open license (CC-based)  
- **The SDK** → Apache-2.0 (permissive, enterprise-friendly)  
- **Implementations** → free to adopt diverse licensing models  
  (proprietary, hardware-coupled, commercial)

This ensures **distributed wealth**: shared standard, free SDK, diverse engines.

---

## Structure

```
src/
  robotchronograf/
    api.py
    cli.py
    sync.py
    utils.py
    loaders/
    codecs/
spec/
  chronograf/        # submodule
```

---

## Installation

```bash
pip install robotchronograf
```

or

```bash
pip install -e .
```

---

## CLI Usage

```bash
robotchronograf --help
robotchronograf barcode now
```

---

## API Example

```python
from robotchronograf.api import load_manifest, generate_temporal_barcode

manifest = load_manifest("spec/chronograf/manifest/chronograf_manifest.rcg")
barcode = generate_temporal_barcode()
print(barcode)
```

---

## License

Apache-2.0
