"""App Settings"""

# Django
from django.conf import settings

# put your app settings here


Market_Tracker_SETTING_ONE = getattr(settings, "Market_Tracker_SETTING_ONE", None)
