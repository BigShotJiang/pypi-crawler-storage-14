"""Testing utilities including integration test runner and performance benchmarks."""
