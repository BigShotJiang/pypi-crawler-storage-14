# pyfilemetre: Python Codebase Analyzer

**pyfilemetre** is a **Python CLI tool** that calculates lines of code (**LOC**), counts classes and functions, checks for **docstrings**, and generates **Markdown reports** for Python projects. It is designed to give you a clear, file-by-file summary of your codebase quickly.

---

## Features

* Counts **lines of code (LOC)** per file.
* Counts **classes and functions**.
* Checks for **missing docstrings**.
* Generates **Markdown reports** summarizing the project.
* Interactive CLI with **spinner animation**.
* Optional flag to **skip saving the report**.

---

## Installation

You can install pyfilemetre from PyPI:

```bash
pip install pyfilemetre
````

> **Note:** Currently not available for local development\!

-----

## Usage

Run pyfilemetre on a Python file or directory:

```bash
pyfilemetre <path_to_project>
```

**Example:**

```bash
pyfilemetre "C:\Users\You\Desktop\demo_project"
```

### Execution Flow

1.  You'll see a **spinner animation** showing progress.
2.  The terminal will display a summary of classes, functions, and docstrings.
3.  You’ll be prompted to save a Markdown report. Enter `y` to save and provide a path, or `n` to skip.

### Optional Flags

  * `--no-md` = Skip saving the Markdown report.

**Example with flag:**

```bash
pyfilemetre "C:\Users\You\Desktop\demo_project" --no-md
```

-----

## Example Output

**Terminal summary:**

```
File: utils.py
  LOC: 120
  Functions: 5
  Classes: 2
  Missing docstrings: 1

File: main.py
  LOC: 200
  Functions: 8
  Classes: 1
  Missing docstrings: 0
```

  * **Markdown report:** `report.md` generated with the same details per file.


-----

## License

This project is licensed under the **MIT License**. See the `LICENSE` file for details.

-----

## Notes

  * **Python 3.8+** required.
  * Works on Windows, macOS, and Linux.
  * **Tabulate** library is used for nice terminal output.

----
### Created by **[Aditi Gupta](https://aditi-gupta-portfolio.vercel.app/)**.