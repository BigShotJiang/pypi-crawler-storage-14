# ginom/config.py
import json
import os
from .core import meta_paths

def read_config(root: str):
    p = meta_paths(root)
    try:
        with open(p["config"], "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def write_config(root: str, cfg: dict):
    p = meta_paths(root)
    with open(p["config"], "w") as f:
        json.dump(cfg, f, indent=2)

def set_config(root: str, key: str, value):
    cfg = read_config(root)
    cfg[key] = value
    write_config(root, cfg)

def get_config(root: str, key: str, default=None):
    return read_config(root).get(key, default)
