import json
import time
from .core import sha256

def make_blob(data: bytes):
    oid = sha256(b"blob\n" + data)
    return oid, data

def make_tree(entries: list[dict]):
    # entries = [{"path": str, "blob": str}]
    content = json.dumps(entries, sort_keys=True).encode()
    oid = sha256(b"tree\n" + content)
    return oid, content

def make_commit(message: str, parent_oid: str | None, tree_oid: str, author: str):
    payload = {
        "message": message,
        "parent": parent_oid,
        "tree": tree_oid,
        "author": author,
        "timestamp": int(time.time()),
    }
    data = json.dumps(payload, sort_keys=True).encode()
    oid = sha256(b"commit\n" + data)
    return oid, data, payload
