# ginom/cli.py
import argparse
import os
import base64

from .core import init_repo, save, log, meta_paths
from .index import track as idx_track, untrack as idx_untrack, status as idx_status
from .refs import create_branch, switch_branch, head_branch, read_ref
from .config import set_config
from .transport import push, pull

def main():
    parser = argparse.ArgumentParser(prog="ginom", description="Ginom CLI")
    sub = parser.add_subparsers(dest="cmd")

    # --- Repo commands
    sub.add_parser("init", help="Initialize a Ginom repo in the current folder")

    p_track = sub.add_parser("track", help="Track a file path")
    p_track.add_argument("path")

    p_untrack = sub.add_parser("untrack", help="Stop tracking a file path")
    p_untrack.add_argument("path")

    sub.add_parser("status", help="Show tracked files")

    p_save = sub.add_parser("save", help="Save a snapshot (commit)")
    p_save.add_argument("message")
    p_save.add_argument("--author", default="unknown")

    sub.add_parser("log", help="Show commit log")

    p_branch = sub.add_parser("branch", help="Create a new branch")
    p_branch.add_argument("name")

    p_switch = sub.add_parser("switch", help="Switch to a branch")
    p_switch.add_argument("name")

    # --- Config + remote
    p_set = sub.add_parser("set", help="Set config key/value")
    p_set.add_argument("key")
    p_set.add_argument("value")

    sub.add_parser("push", help="Push to GitHub")
    sub.add_parser("pull", help="Pull from GitHub")

    args = parser.parse_args()
    root = os.getcwd()
    paths = meta_paths(root)

    if args.cmd == "init":
        init_repo(root)

    elif args.cmd == "track":
        idx_track(paths["index"], args.path)
        print(f"Tracking: {args.path}")

    elif args.cmd == "untrack":
        idx_untrack(paths["index"], args.path)
        print(f"Untracked: {args.path}")

    elif args.cmd == "status":
        tracked = idx_status(paths["index"])
        if not tracked:
            print("No tracked files.")
        else:
            for p in tracked:
                print(f"tracked: {p}")

    elif args.cmd == "save":
        save(root, args.message, author=args.author)

    elif args.cmd == "log":
        for item in log(root):
            print(f"{item['oid'][:8]}  {item['message']}")

    elif args.cmd == "branch":
        create_branch(root, args.name)
        print(f"Branch created: {args.name}")

    elif args.cmd == "switch":
        switch_branch(root, args.name)
        print(f"Switched to: {args.name}")

    elif args.cmd == "set":
        set_config(root, args.key, args.value)
        print(f"Set {args.key} = {args.value}")

    elif args.cmd == "push":
        tracked = idx_status(paths["index"])
        files = {}
        for p in tracked:
            with open(os.path.join(root, p), "rb") as f:
                files[p] = base64.b64encode(f.read()).decode()
        repo = {
            "branch": head_branch(root),
            "commit": read_ref(root, head_branch(root)),
            "files": files,
        }
        push(root, repo)

    elif args.cmd == "pull":
        repo = {
            "branch": head_branch(root),
            "commit": read_ref(root, head_branch(root)),
        }
        pull(root, repo)

    else:
        parser.print_help()
