import json
import os

def _read_json(path: str, default):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return default

def _write_json(path: str, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def read_index(index_path: str):
    return _read_json(index_path, {"tracked": []})

def write_index(index_path: str, data):
    _write_json(index_path, data)

def track(index_path: str, relpath: str):
    idx = read_index(index_path)
    if relpath not in idx["tracked"]:
        idx["tracked"].append(relpath)
        write_index(index_path, idx)

def untrack(index_path: str, relpath: str):
    idx = read_index(index_path)
    idx["tracked"] = [p for p in idx["tracked"] if p != relpath]
    write_index(index_path, idx)

def status(index_path: str):
    idx = read_index(index_path)
    return idx["tracked"]
    