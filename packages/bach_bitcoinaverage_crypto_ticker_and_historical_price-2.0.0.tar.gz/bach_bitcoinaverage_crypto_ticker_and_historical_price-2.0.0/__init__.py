"""MCP Server for Bitcoinaverage Crypto Ticker And Historical Price"""
