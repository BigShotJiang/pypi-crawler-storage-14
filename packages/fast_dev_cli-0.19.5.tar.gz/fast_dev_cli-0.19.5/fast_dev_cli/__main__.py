from fast_dev_cli.cli import main

main()
