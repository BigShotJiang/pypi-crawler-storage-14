"""
Init file for the aa_dependency_overrides package.
"""

__version__ = "0.6.0"
__title__ = "AA Dependency Overrides"
