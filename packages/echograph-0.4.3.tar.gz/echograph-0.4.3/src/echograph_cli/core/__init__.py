"""Core functionality package."""
