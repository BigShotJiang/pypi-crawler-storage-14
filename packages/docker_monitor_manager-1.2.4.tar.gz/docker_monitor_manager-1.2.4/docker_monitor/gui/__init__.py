"""GUI components for Docker Monitor Manager."""
