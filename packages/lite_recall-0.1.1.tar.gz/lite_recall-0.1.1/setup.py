from setuptools import setup, find_packages

setup(
    name="lite-recall",
    version="0.1.1",
    description="ReCALL Lite — A lightweight, AGI-inspired memory layer for LLMs.",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Project Genesis",
    url="https://github.com/projectGenesisEngine/ReCALL_Lite",
    
    packages=find_packages(exclude=["tests*", "examples*"]),
    package_dir={"": "."},

    install_requires=[
        "numpy",
        "pandas",
        "pyarrow",
        "networkx",
        "requests",
        "sentence-transformers==2.7.0",
        "torch",
        "transformers",
        "openai",
    ],

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
)
