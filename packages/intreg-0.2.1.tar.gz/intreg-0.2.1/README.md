[![codecov](https://codecov.io/gh/fowler-lab/intreg/branch/main/graph/badge.svg?token=EECMnKifvc)](https://codecov.io/gh/fowler-lab/intreg)
[![DOI](https://zenodo.org/badge/856350662.svg)](https://doi.org/10.5281/zenodo.14889276)


# intreg

A Python implementation of interval regression
