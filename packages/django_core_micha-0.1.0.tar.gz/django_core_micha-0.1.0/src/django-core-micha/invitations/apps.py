from django.apps import AppConfig


class InvitationsCoreConfig(AppConfig):
    name = "django_core.invitations"
    label = "django_core_invitations"
    verbose_name = "Core Invitations"
