from django.apps import AppConfig

class CoreAuthConfig(AppConfig):
    name = 'django_core.auth'
    label = 'core_auth'

    def ready(self):
        import django_core.auth.signals