"""
Kubiya Control Plane SDK Version

This version must match between worker and control plane for compatibility.
Workers will check this version during registration and exit if mismatched.
"""

__version__ = "0.5.1"


def get_sdk_version() -> str:
    """Get the SDK version string.

    Returns:
        str: Package version (e.g., "0.3.9")
    """
    return __version__
