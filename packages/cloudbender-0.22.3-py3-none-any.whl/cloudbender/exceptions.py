class ParameterNotFound(Exception):
    """My documentation"""


class ParameterIllegalValue(Exception):
    """My documentation"""


class InvalidProjectDir(Exception):
    """My documentation"""


class InvalidHook(Exception):
    """My documentation"""


class ChecksumError(Exception):
    """My documentation"""
