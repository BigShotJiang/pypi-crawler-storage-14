from django.apps import AppConfig


class BrowsingConfig(AppConfig):
    name = "browsing"
