# FBChecker

Python library to check Facebook accounts.

## Example

```python
from fbchecker import FBChecker

checker = FBChecker(accounts_file="accounts.txt", passwords="Password123")
results = checker.run()
print(results)