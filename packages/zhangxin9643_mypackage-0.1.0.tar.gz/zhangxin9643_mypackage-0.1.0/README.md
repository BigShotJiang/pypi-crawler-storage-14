# mypackage

A student project package with examples of:
- generators
- iterators
- decorators
- descriptors

This package was created for a university assignment.