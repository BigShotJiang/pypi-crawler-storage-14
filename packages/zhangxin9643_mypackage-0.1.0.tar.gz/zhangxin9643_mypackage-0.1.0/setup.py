from setuptools import setup, find_packages

setup(
    name="zhangxin9643-mypackage",
    version="0.1.0",
    packages=find_packages(),
    description="A student project package with generators, iterators, decorators and descriptors",
    author="Zhang Xin",
    author_email="cs08@tpu.ru",
    url="https://example.com",
    python_requires=">=3.8",
)
