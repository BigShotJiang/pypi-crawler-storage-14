# mypackage/tests/test_iterators.py

import unittest
from mypackage.iterators import (
    CounterIterator,
    InfiniteIterator,
    repeat_string,
    repeat_value,
    permutations_iterator,
    combinations_iterator,
    singularize,
    transform_phrases,
)


class TestIterators(unittest.TestCase):

    def test_counter_iterator(self):
        result = list(CounterIterator(3, 6))
        self.assertEqual(result, [3, 4, 5, 6])

    def test_infinite_iterator(self):
        it = InfiniteIterator(10)
        nums = [next(it) for _ in range(5)]
        for n in nums:
            self.assertTrue(n % 7 == 0 or n % 9 == 0)

    def test_repeat_string(self):
        it = repeat_string("Hi", 3)
        result = [next(it) for _ in range(3)]
        self.assertEqual(result, ["Hi", "Hi", "Hi"])

    def test_repeat_value(self):
        it = repeat_value(5, 4)
        result = [next(it) for _ in range(4)]
        self.assertEqual(result, [5, 5, 5, 5])

    def test_permutations_iterator(self):
        lst = [1, 2]
        perms = list(permutations_iterator(lst))
        self.assertEqual(perms, [(1, 2), (2, 1)])

    def test_combinations_iterator(self):
        input_list = [2, 1]
        combos = list(combinations_iterator(input_list))
        self.assertEqual(combos, [(1,), (2,), (1, 2)])

    def test_singularize(self):
        self.assertEqual(singularize("lights"), "light")
        self.assertEqual(singularize("opportunities"), "opportunity")
        self.assertEqual(singularize("boxes"), "box")

    def test_transform_phrases(self):
        phrases = [
            "turn on the lights",
            "make sense of the words",
            "make use of the opportunities"
        ]
        result = transform_phrases(phrases)
        self.assertEqual(result, ["light", "word", "opportunity"])


if __name__ == "__main__":
    unittest.main()
