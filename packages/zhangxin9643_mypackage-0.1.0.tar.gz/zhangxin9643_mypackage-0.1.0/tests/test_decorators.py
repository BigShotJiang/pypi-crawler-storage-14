import unittest
import time
from mypackage.decorators import timeit


class TestTimeitDecorator(unittest.TestCase):

    def test_decorator_returns_correct_value(self):
        @timeit(min_seconds=0, debug=False)
        def add(a, b):
            return a + b

        self.assertEqual(add(2, 3), 5)

    def test_timeit_does_not_print_when_debug_false(self):
        @timeit(min_seconds=0, debug=False)
        def add(a, b):
            return a + b

        # 捕获输出
        import io
        import sys
        captured = io.StringIO()
        sys.stdout = captured

        add(4, 5)

        sys.stdout = sys.__stdout__
        self.assertEqual(captured.getvalue(), "")  # 不应该有输出

    def test_timeit_prints_when_debug_true_and_time_exceeds(self):
        @timeit(min_seconds=0, debug=True)
        def add(a, b):
            time.sleep(0.01)
            return a + b

        import io
        import sys
        captured = io.StringIO()
        sys.stdout = captured

        add(1, 2)

        sys.stdout = sys.__stdout__
        self.assertIn("seconds", captured.getvalue())  # 应该打印
