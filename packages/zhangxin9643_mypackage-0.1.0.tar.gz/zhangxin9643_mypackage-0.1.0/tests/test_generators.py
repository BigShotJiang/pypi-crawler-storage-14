# mypackage/tests/test_generators.py

import unittest
from mypackage.generators import fibonacci, geometric_sequence, countdown


class TestGenerators(unittest.TestCase):

    # 测试 fibonacci 函数
    def test_fibonacci(self):
        self.assertEqual(list(fibonacci(5)), [0, 1, 1, 2, 3])   # 前 5 个 Fibonacci 数
        self.assertEqual(list(fibonacci(3)), [0, 1, 1])         # 前 3 个 Fibonacci 数

    # 测试 geometric_sequence 函数
    def test_geometric_sequence(self):
        self.assertEqual(
            list(geometric_sequence(1, 2, 5)),
            [1, 2, 4, 8, 16]
        )  # 首项=1，比例=2

        self.assertEqual(
            list(geometric_sequence(3, 3, 4)),
            [3, 9, 27, 81]
        )  # 首项=3，比例=3

    # 测试 countdown 函数
    def test_countdown(self):
        self.assertEqual(list(countdown(5)), [5, 4, 3, 2, 1, 0])  # 从 5 到 0
        self.assertEqual(list(countdown(3)), [3, 2, 1, 0])        # 从 3 到 0
