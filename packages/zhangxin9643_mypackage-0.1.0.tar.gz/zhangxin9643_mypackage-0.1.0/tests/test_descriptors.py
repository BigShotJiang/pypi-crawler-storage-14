import unittest
import math
from mypackage.descriptors import Circle, Rectangle, Square


class TestDescriptors(unittest.TestCase):

    def test_circle_area(self):
        c = Circle(10)
        self.assertAlmostEqual(c.area, math.pi * 100, places=5)

    def test_circle_get_set(self):
        c = Circle(5)
        self.assertEqual(c.radius, 5)
        c.radius = 8
        self.assertEqual(c.radius, 8)

    def test_circle_delete_radius(self):
        c = Circle(6)
        del c.radius
        with self.assertRaises(AttributeError):
            _ = c.radius

    def test_rectangle_area(self):
        r = Rectangle(3, 4)
        self.assertEqual(r.area, 12)

    def test_rectangle_perimeter(self):
        r = Rectangle(3, 4)
        self.assertEqual(r.perimeter, 14)

    def test_rectangle_delete(self):
        r = Rectangle(5, 6)
        del r.a
        with self.assertRaises(AttributeError):
            _ = r.a

    def test_square_inheritance(self):
        s = Square(10)
        self.assertEqual(s.area, 100)
        self.assertEqual(s.perimeter, 40)

    def test_square_descriptor(self):
        s = Square(7)
        self.assertEqual(s.a, 7)
        s.a = 9
        self.assertEqual(s.a, 9)
