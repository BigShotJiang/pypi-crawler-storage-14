def count_in_list(lst: list, value) -> int:
    """Return the number of occurrences of value in lst."""
    return lst.count(value)
