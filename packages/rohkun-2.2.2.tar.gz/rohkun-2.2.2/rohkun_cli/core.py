"""
Core analysis logic - shared between CLI and MCP
Returns structured data instead of printing
"""
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass

from .config import Config
from .auth import authorize_scan, report_usage
from .analyzer import scan_project
from .report import format_report, save_report
from .snapshot import SnapshotTracker
from .visualization import generate_visualization, start_visualization_server
from .utils.file_utils import estimate_project_size


@dataclass
class AnalysisResult:
    """Structured result from analysis"""
    success: bool
    results: Optional[Dict[str, Any]] = None
    report_path: Optional[Path] = None
    snapshot: Optional[Dict[str, Any]] = None
    project_hash: Optional[str] = None
    visualization_url: Optional[str] = None
    credits_remaining: Optional[int] = None
    error: Optional[str] = None
    error_reason: Optional[str] = None
    error_message: Optional[str] = None


def run_analysis(
    project_path: Path,
    api_key: Optional[str] = None,
    skip_auth: bool = False
) -> AnalysisResult:
    """
    Core analysis function - shared by CLI and MCP
    
    Args:
        project_path: Path to project directory
        api_key: Optional API key (if None, will try to load from config)
        skip_auth: Skip authorization check (for testing)
    
    Returns:
        AnalysisResult with structured data
    """
    project_path = project_path.resolve()
    
    # Validate path
    if not project_path.exists():
        return AnalysisResult(
            success=False,
            error="Path does not exist",
            error_message=f"Path does not exist: {project_path}"
        )
    
    if not project_path.is_dir():
        return AnalysisResult(
            success=False,
            error="Not a directory",
            error_message=f"Path is not a directory: {project_path}"
        )
    
    # Get API key
    if api_key is None:
        config = Config(project_path)
        api_key = config.get_api_key()
    
    # Authorization
    auth_result = None
    if not skip_auth:
        if not api_key:
            return AnalysisResult(
                success=False,
                error="No API key found",
                error_message="Set your API key with: rohkun config --api-key YOUR_KEY"
            )
        
        # Estimate size and authorize
        size_info = estimate_project_size(project_path)
        auth_result = authorize_scan(
            api_key=api_key,
            project_name=project_path.name,
            estimated_files=size_info['file_count']
        )
        
        if not auth_result.authorized:
            return AnalysisResult(
                success=False,
                error="Authorization failed",
                error_reason=auth_result.reason,
                error_message=auth_result.message,
                credits_remaining=auth_result.credits_remaining
            )
    
    # Run analysis
    try:
        # Initialize snapshot tracker
        tracker = SnapshotTracker(project_path)
        project_info = tracker.get_or_create_project()
        
        # Run scan
        results = scan_project(project_path)
        
        # Generate report
        report = format_report(results, project_path)
        report_file = save_report(report, project_path)
        
        # Save snapshot
        snapshot = tracker.save_snapshot(results, report_file.name)
        
        # Generate visualization
        viz_file = generate_visualization(report, project_path)
        viz_dir = viz_file.parent
        server_thread, port = start_visualization_server(viz_dir, port=8000, open_browser=False)
        
        # Report usage (fire-and-forget)
        if not skip_auth and api_key and auth_result:
            report_usage(api_key, auth_result.user_id, success=True)
        
        return AnalysisResult(
            success=True,
            results=results,
            report_path=report_file,
            snapshot=snapshot,
            project_hash=project_info['project_hash'],
            visualization_url=f"http://localhost:{port}",
            credits_remaining=auth_result.credits_remaining if auth_result else None
        )
        
    except Exception as e:
        # Report failure
        if not skip_auth and api_key and auth_result:
            report_usage(api_key, auth_result.user_id, success=False)
        
        return AnalysisResult(
            success=False,
            error="Analysis failed",
            error_message=str(e)
        )

