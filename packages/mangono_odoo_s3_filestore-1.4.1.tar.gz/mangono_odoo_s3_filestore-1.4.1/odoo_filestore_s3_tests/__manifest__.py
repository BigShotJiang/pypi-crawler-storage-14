{
    "name": "Odoo S3 Tests",
    "summary": """
        Test de odoo_filestore_s3 addons, who is not installable.
""",
    "description": """

    """,
    "author": "NDP Systemes",
    "website": "http://ndp-systemes.fr/",
    "category": "Uncategorized",
    "version": "0.1",
    "license": "AGPL-3",
    "depends": ["base"],
    "auto_install": False,
    "external_dependencies": {},
    "data": [],
    "installable": True,
}
