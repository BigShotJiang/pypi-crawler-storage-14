# odoo_filestore_s3

## build

```shell
uv build
```

## Install

```shell
pip install mangono-odoo-s3-filestore
```
