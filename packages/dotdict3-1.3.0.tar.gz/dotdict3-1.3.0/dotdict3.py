class DotDict(dict):
    def __init__(self, d):
        for k, v in d.items():
            self[k] = v

    def __setitem__(self, k, v):
        if isinstance(v, dict) and not isinstance(v, DotDict):
            return super().__setitem__(k, DotDict(v))
        elif isinstance(v, (tuple, list, set, range)):
            return super().__setitem__(k, DotList(v))
        return super().__setitem__(k, v)

    __delattr__ = dict.__delitem__
    __getattr__ = dict.__getitem__
    __setattr__ = __setitem__


class DotList(list):
    def __init__(self, l):
        for i in l:
            self.append(i)

    def append(self, i):
        if isinstance(i, dict) and not isinstance(i, DotDict):
            super().append(DotDict(i))
        elif isinstance(i, (tuple, list, set, range)) and not isinstance(i, DotList):
            super().append(DotList(i))
        else:
            super().append(i)

    def insert(self, index, object):
        if isinstance(object, dict) and not isinstance(object, DotDict):
            return super().insert(index, DotDict(object))
        return super().insert(index, object)
