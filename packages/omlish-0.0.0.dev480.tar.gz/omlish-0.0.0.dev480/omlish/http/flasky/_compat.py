def compat(obj):
    return obj
