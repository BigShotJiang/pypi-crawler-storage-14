from weconnect_cli.weconnect_cli_base import main

if __name__ == '__main__':
    main()
