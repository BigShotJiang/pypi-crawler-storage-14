# Parser placeholder for missing imports
def parse_prowler_report_html(content, preview_length=500):
    """Parse HTML prowler report"""
    return {
        "file_type": "Prowler HTML Report",
        "keyword_counts": {
            "PASS": 0,
            "FAIL": 0,
            "CRITICAL": 0,
            "HIGH": 0,
            "MEDIUM": 0,
            "LOW": 0
        },
        "text_preview": content[:preview_length]
    }

def parse_prowler_report_asff_json(content):
    """Parse JSON ASFF prowler report"""
    return {
        "file_type": "JSON ASFF Data",
        "data_type": "dict",
        "keyword_counts": {}
    }