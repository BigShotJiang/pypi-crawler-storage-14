from pathlib import Path
from typing import List

import anywidget
import traitlets


class TangleSlider(anywidget.AnyWidget):
    """Slider inspired by Bret Victor's Tangle UI."""

    _esm = Path(__file__).parent / "static" / "tangle-slider.js"
    amount = traitlets.Float(0.0).tag(sync=True)
    min_value = traitlets.Float(-100.0).tag(sync=True)
    max_value = traitlets.Float(100.0).tag(sync=True)
    step = traitlets.Float(1.0).tag(sync=True)
    pixels_per_step = traitlets.Int(2).tag(sync=True)
    prefix = traitlets.Unicode("").tag(sync=True)
    suffix = traitlets.Unicode("").tag(sync=True)
    digits = traitlets.Int(1).tag(sync=True)

    def __init__(
        self,
        amount: float | None = None,
        min_value: float = -100,
        max_value: float = 100,
        step: float = 1.0,
        pixels_per_step: int = 2,
        prefix: str = "",
        suffix: str = "",
        digits: int = 1,
        **kwargs,
    ) -> None:
        if amount is None:
            amount = (max_value + min_value) / 2
        super().__init__(
            amount=amount,
            min_value=min_value,
            max_value=max_value,
            step=step,
            pixels_per_step=pixels_per_step,
            prefix=prefix,
            suffix=suffix,
            digits=digits,
            **kwargs,
        )


class TangleChoice(anywidget.AnyWidget):
    """Choice widget inspired by Tangle."""

    _esm = Path(__file__).parent / "static" / "tangle-choice.js"
    choice = traitlets.Unicode("").tag(sync=True)
    choices = traitlets.List([]).tag(sync=True)

    def __init__(self, choices: List[str], **kwargs) -> None:
        if len(choices) < 2:
            raise ValueError("Must pass at least two choices.")
        super().__init__(value=choices[1], choices=choices, **kwargs)


class TangleSelect(anywidget.AnyWidget):
    """Dropdown select widget inspired by Tangle."""

    _esm = Path(__file__).parent / "static" / "tangle-select.js"
    choice = traitlets.Unicode("").tag(sync=True)
    choices = traitlets.List([]).tag(sync=True)

    def __init__(self, choices: List[str], **kwargs) -> None:
        if len(choices) < 2:
            raise ValueError("Must pass at least two choices.")
        super().__init__(choice=choices[0], choices=choices, **kwargs)
