from typing import List, Literal, TypedDict

class TapPoint(TypedDict):
    """点击点"""

    x: int  # 坐标 X
    y: int  # 坐标 Y

# 设置动作抖动值（像素，随屏幕 scale 适配）
def setJitterValue(value: int) -> None:
    """设置动作抖动值（像素，随屏幕 scale 适配）

    参数:
      value: 抖动像素值
    返回:
      bool: 是否设置成功
    """
    ...

# 点击
# 参数：x/y 坐标；duration 持续时间（ms）；jitter 是否启用抖动
def click(x: int, y: int, duration: int = ..., jitter: bool = ...) -> bool:
    """点击指定坐标

    参数:
      x: 坐标 X
      y: 坐标 Y
      duration: 按下持续时间（毫秒，默认 20ms）
      jitter: 是否启用抖动（默认 False）
    返回:
      bool: 是否点击成功
    """
    ...

# 随机点击指定矩形区域
def clickRandom(x1: int, y1: int, x2: int, y2: int, duration: int = ...) -> bool:
    """随机点击矩形区域

    参数:
      x1: 左上角 X
      y1: 左上角 Y
      x2: 右下角 X
      y2: 右下角 Y
      duration: 按下持续时间（毫秒，默认 20ms）
    返回:
      bool: 是否点击成功
    """
    ...

# 双击
# 参数：duration 持续时间；interval 间隔时间（ms）；jitter 是否抖动
def doubleClick(
    x: int, y: int, duration: int = ..., interval: int = ..., jitter: bool = ...
) -> bool:
    """双击

    参数:
      x: 坐标 X
      y: 坐标 Y
      duration: 每次按下持续时间（毫秒，默认 20ms）
      interval: 两次点击间隔（毫秒，默认 20ms）
      jitter: 是否启用抖动（默认 False）
    返回:
      bool: 是否双击成功
    """
    ...

# 随机双击指定区域
def doubleClickRandom(
    x1: int, y1: int, x2: int, y2: int, duration: int = ..., interval: int = ...
) -> bool:
    """随机双击矩形区域

    参数:
      x1: 左上角 X
      y1: 左上角 Y
      x2: 右下角 X
      y2: 右下角 Y
      duration: 每次按下持续时间（毫秒，默认 20ms）
      interval: 两次点击间隔（毫秒，默认 20ms）
    返回:
      bool: 是否双击成功
    """
    ...

# 直线滑动
# 参数：起点 x/y；终点 ex/ey；duration 总时长；jitter 抖动；steps 轨迹点数
def swipe(
    startX: int,
    startY: int,
    endX: int,
    endY: int,
    duration: int = ...,
    jitter: bool = ...,
    steps: int = ...,
) -> bool:
    """直线滑动

    参数:
      startX: 起始 X
      startY: 起始 Y
      endX: 结束 X
      endY: 结束 Y
      duration: 总时长（毫秒，默认 100ms）
      jitter: 是否启用抖动（默认 False）
      steps: 轨迹点数量（默认 6）
    返回:
      bool: 是否滑动成功
    """
    ...

# 长按并滑动
# 参数：touch_* 三段时长（ms）；steps 步数
def pressAndSwipe(
    startX: int,
    startY: int,
    endX: int,
    endY: int,
    touch_down_duration: int = ...,
    touch_move_duration: int = ...,
    touch_up_duration: int = ...,
    jitter: bool = ...,
    steps: int = ...,
) -> bool:
    """长按并滑动

    参数:
      touch_down_duration: 按下时长（毫秒，默认 500ms）
      touch_move_duration: 移动时长（毫秒，默认 1000ms）
      touch_up_duration: 抬起时长（毫秒，默认 500ms）
      jitter: 是否启用抖动（默认 False）
      steps: 轨迹点数量（默认 6）
      其他坐标与滑动参数同 swipe
    返回:
      bool: 是否执行成功
    """
    ...

# 3点曲线滑动（先快后慢）
def swipeCurve(
    startX: int,
    startY: int,
    midX: int,
    midY: int,
    endX: int,
    endY: int,
    duration: int = ...,
) -> bool:
    """3点曲线滑动（先快后慢）

    参数:
      startX/startY: 起点坐标
      midX/midY: 中间控制点坐标
      endX/endY: 终点坐标
      duration: 总时长（毫秒，默认 1000ms）
    返回:
      bool: 是否执行成功
    """
    ...

# 输入英文文本（不支持中文）
def input(text: str) -> bool:
    """输入英文文本（不支持中文）

    参数:
      text: 文本内容
    返回:
      bool: 是否输入成功
    """
    ...

# 删除文本（count 默认 1）
def backspace(count: int = ...) -> bool:
    """删除文本

    参数:
      count: 删除数量（默认 1）
    返回:
      bool: 是否删除成功
    """
    ...

# 回车
def enter() -> bool:
    """回车

    返回:
      bool: 是否成功
    """
    ...

# 回到主屏幕
def homeScreen() -> bool:
    """回到主屏幕

    返回:
      bool: 是否成功
    """
    ...

# 按按钮（home/volumeup/volumedown 等）
def pressButton(button: Literal["home", "volumeup", "volumedown"]) -> bool:
    """按按钮（home/volumeup/volumedown 等）

    参数:
      button: 按钮名称
    返回:
      bool: 是否成功
    """
    ...

# 按 HID 按钮（power/snapshot 等），可指定时长
def pressHidButton(
    button: Literal["home", "volumeup", "volumedown", "power", "snapshot"],
    duration: int = ...,
) -> bool:
    """按 HID 按钮（power/snapshot 等），可指定时长

    参数:
      button: HID 按钮名称
      duration: 持续时间（毫秒，默认 20ms）
    返回:
      bool: 是否成功
    """
    ...

# 链式 ActionBuilder
class Pointer:
    def moveTo(self, x: int, y: int, duration: int = ...) -> "Pointer": ...
    def down(self) -> "Pointer": ...
    def up(self) -> "Pointer": ...
    def stay(self, duration: int = ...) -> "Pointer": ...
    def tap(self, x: int, y: int, duration: int = ...) -> "Pointer": ...
    def done(self) -> "ActionBuilder": ...

class ActionBuilder:
    def addPointer(self, id: int) -> Pointer: ...
    def singleTap(self, x: int, y: int, duration: int = ...) -> "ActionBuilder": ...
    def multiTap(
        self, points: List[TapPoint], duration: int = ...
    ) -> "ActionBuilder": ...
    def execute(self) -> bool: ...

def createBuilder() -> ActionBuilder:
    """创建 ActionBuilder 构建器

    返回:
      ActionBuilder: 链式构建器实例
    """
    ...
