from typing import Any, List, Dict, Optional, Protocol, TypedDict

# 连接配置：host/port/username/password/database/charset
class MySQLConfig(TypedDict):
    """MySQL 连接配置"""

    host: str  # 主机名或 IP 地址
    port: Optional[int]  # 端口号（默认 3306）
    username: str  # 用户名
    password: str  # 密码
    database: str  # 数据库名
    charset: Optional[str]  # 字符集（默认 utf8mb4）

# 查询/执行，返回对象：rows/affectedRows/insertId/success/error
class MySQLResult(Protocol):
    """MySQL 查询/执行结果"""

    rows: List[Dict[str, Any]]  # 查询结果行（如果有）
    affectedRows: int  # 受影响的行数（INSERT/UPDATE/DELETE）
    success: bool  # 是否成功执行
    insertId: Optional[int]  # 插入行的 ID（如果有）
    error: Optional[str]  # 错误信息（如果有）

def connect(config: MySQLConfig) -> bool:
    """连接到数据库"""
    ...

def disconnect() -> None:
    """断开数据库连接"""
    ...

def isConnected() -> bool:
    """检查连接状态"""
    ...

def query(sql: str, params: List[Any] = ...) -> MySQLResult:
    """执行查询（SELECT）"""
    ...

def execute(sql: str, params: List[Any] = ...) -> MySQLResult:
    """执行更新（INSERT/UPDATE/DELETE）"""
    ...

# 事务控制
def beginTransaction() -> bool:
    """开始事务"""
    ...

def commit() -> bool:
    """提交事务"""
    ...

def rollback() -> bool:
    """回滚事务"""
    ...
