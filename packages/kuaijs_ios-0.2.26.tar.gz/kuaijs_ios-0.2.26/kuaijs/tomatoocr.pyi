from typing import Optional, Protocol

class TomatoInitResult(Protocol):
    """TomatoOCR 初始化结果"""

    deviceId: str  # 设备 ID
    expiryTime: str  # 有效期时间
    message: str  # 初始化消息
    status: str  # 状态
    versionName: str  # 版本名称

def initializeWithConfig(
    mode: str, licenseData: str, remark: str = ...
) -> Optional[TomatoInitResult]:
    """初始化 TomatoOCR 并设置基本配置

    参数默认值:
      remark: 空字符串
    """
    ...

# 配置项：HTTP间隔/识别类型/检测框类型/展开比例/分数阈值/返回类型/二值阈值/运行模式/过滤颜色
def setHttpIntervalTime(second: float) -> None:
    """设置 HTTP 请求间隔时间（秒）"""
    ...

def setRecType(recType: str) -> None:
    """设置识别类型（如 ch-3.0/cht/japan 等）"""
    ...

def setDetBoxType(detBoxType: str) -> None:
    """设置检测框类型（rect/quad）"""
    ...

def setDetUnclipRatio(detUnclipRatio: float) -> None:
    """设置检测框展开比例（建议 1.6-2.5）"""
    ...

def setRecScoreThreshold(recScoreThreshold: float) -> None:
    """设置识别分数阈值（默认 0.1）"""
    ...

def setReturnType(returnType: str) -> None:
    """设置返回类型（json/text/num/自定义字符集）"""
    ...

def setBinaryThresh(binaryThresh: float) -> None:
    """设置二值化阈值（0-255）"""
    ...

def setRunMode(runMode: str) -> None:
    """设置运行模式（如 fast）"""
    ...

def setFilterColor(filterColor: str, backgroundColor: str) -> None:
    """设置图像滤色参数（多色用 | 连接）"""
    ...

# 图片OCR与点击点查找
def ocrImage(
    input: str,
    type: int = ...,
    x: int = ...,
    y: int = ...,
    ex: int = ...,
    ey: int = ...,
) -> str:
    """对图像执行 OCR 识别，返回 JSON 字符串

    参数默认值:
      type: 3（检测+识别）
      x/y/ex/ey: 0
    """
    ...

def findTapPoint(data: str) -> str:
    """查找点击点（返回中心点 JSON 字符串）"""
    ...

def findTapPoints(data: str) -> str:
    """查找多个点击点（返回中心点数组 JSON 字符串）"""
    ...
