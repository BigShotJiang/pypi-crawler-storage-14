from typing import List, Protocol

# 语音列表与设置音色
class VoiceInfo(Protocol):
    """语音信息"""

    identifier: str  # 语音标识符
    name: str  # 语音名称
    language: str  # 语音语言（例如 "zh-CN"）
    quality: int  # 语音质量（0=低，1=中，2=高）

# 播放语音（rate:0.0-1.0；pitch:0.5-2.0；volume:0.0-1.0；language:zh-CN 等）
def speak(
    text: str,
    rate: float = ...,
    pitch: float = ...,
    volume: float = ...,
    language: str = ...,
) -> bool:
    """播放文本转语音（5 参数版本）

    参数默认值:
      rate: 0.5
      pitch: 1.0
      volume: 1.0
      language: "zh-CN"
    """
    ...

def waitEnd() -> None:
    """等待当前语音播放结束"""
    ...

def stop() -> None:
    """停止当前播放"""
    ...

def isSpeaking() -> bool:
    """是否正在播放"""
    ...

def getAvailableVoices() -> List[VoiceInfo]:
    """获取可用的语音列表"""
    ...

def setVoice(voiceIdentifier: str) -> bool:
    """设置语音（identifier）"""
    ...

# 释放资源
def free() -> None:
    """释放 TTS 资源"""
    ...
