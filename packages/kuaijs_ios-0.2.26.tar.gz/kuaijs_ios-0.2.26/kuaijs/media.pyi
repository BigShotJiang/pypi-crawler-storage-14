"""媒体管理：相册与音频"""

# 保存图片/视频到相册
def saveImageToAlbum(imageId: str) -> bool:
    """保存图像到相册"""
    ...

def saveVideoToAlbumPath(path: str) -> bool:
    """保存视频路径到相册"""
    ...

# 清空相册图片/视频
def deleteAllPhotos() -> bool:
    """清空相册中的图片"""
    ...

def deleteAllVideos() -> bool:
    """清空相册中的视频"""
    ...

# 播放/停止MP3；同步播放（等待结束）
def playMp3(path: str, loop: bool) -> bool:
    """播放 MP3（异步）"""
    ...

def stopMp3() -> bool:
    """停止播放 MP3"""
    ...

def playMp3WaitEnd(path: str, loop: bool) -> bool:
    """同步播放 MP3（等待结束）"""
    ...
