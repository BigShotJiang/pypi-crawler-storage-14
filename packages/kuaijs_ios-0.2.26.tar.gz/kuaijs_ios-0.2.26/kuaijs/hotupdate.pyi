from typing import Optional, Protocol, TypedDict

class HotUpdateOptions(TypedDict):
    """热更新检查参数"""

    url: Optional[str]  # 热更新检查 URL
    version: Optional[int]  # 当前版本号
    timeout: Optional[int]  # 超时时间（毫秒）

class HotUpdateResult(Protocol):
    """热更新检查结果"""

    needUpdate: bool  # 是否需要更新
    error: Optional[str]  # 错误信息（如果有）
    data: Optional[HotUpdateResponse]  # 热更新响应数据（如果有）

class HotUpdateResponse(Protocol):
    """热更新响应数据"""

    download_url: str  # 下载 URL
    version: int  # 最新版本号
    download_timeout: int  # 下载超时时间（毫秒）
    dialog: bool  # 是否显示弹窗
    msg: str  # 弹窗消息
    force: bool  # 是否强制更新
    md5: Optional[str]  # 最新版本文件的 MD5（如果有）

# 下载并安装（返回 {updated,error?}）
class InstallResult(Protocol):
    """安装结果"""

    updated: bool  # 是否成功更新
    error: Optional[str]  # 错误信息（如果有）

def checkUpdate(options: Optional[HotUpdateOptions] = ...) -> HotUpdateResult:
    """检查更新

    参数:
      options: 检查参数（url/version/timeout）
    返回:
      HotUpdateResult: needUpdate/data/error
    """
    ...

def downloadAndInstall() -> InstallResult:
    """下载并安装更新（执行成功会自动重启脚本）"""
    ...

# 获取当前应用版本号（整数）
def getCurrentVersion() -> int:
    """获取当前应用版本号（数字）"""
    ...
