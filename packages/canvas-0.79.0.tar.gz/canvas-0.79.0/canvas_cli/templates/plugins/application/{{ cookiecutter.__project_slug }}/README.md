{{ cookiecutter.__project_slug }}
{% for _ in cookiecutter.__project_slug %}={% endfor %}

## Description

A description of this plugin

### Important Note!

The CANVAS_MANIFEST.json is used when installing your plugin. Please ensure it
gets updated if you add, remove, or rename protocols.
