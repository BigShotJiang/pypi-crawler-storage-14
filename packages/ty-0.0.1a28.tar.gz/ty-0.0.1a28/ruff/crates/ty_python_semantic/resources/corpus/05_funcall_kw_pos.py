fun(var, 10, a=a, kw=2)
