if a:
    b
elif c:
    d
else:
    e
