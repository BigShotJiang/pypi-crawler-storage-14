a.b = 1
a.b.c.d = 2
