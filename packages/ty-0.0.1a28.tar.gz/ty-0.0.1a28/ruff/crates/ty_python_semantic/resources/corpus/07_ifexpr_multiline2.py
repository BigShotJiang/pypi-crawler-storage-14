a = (
    (
        b()
    )
    if c
    else d
)
