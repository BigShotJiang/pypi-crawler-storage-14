def foo(z, *y, x=1, **c):
    a
