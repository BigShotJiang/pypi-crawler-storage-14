lambda x=a: y
