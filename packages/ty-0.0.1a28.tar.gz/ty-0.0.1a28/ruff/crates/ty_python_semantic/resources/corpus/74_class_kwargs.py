class Foo(x=42):
    pass
