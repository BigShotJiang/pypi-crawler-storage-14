if __debug__:
    print('hello')
