match some_int:
    case x:=2:
        pass
