for a in b:
    break
