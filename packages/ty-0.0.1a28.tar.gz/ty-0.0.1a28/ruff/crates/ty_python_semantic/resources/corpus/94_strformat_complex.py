query = f"""
    {a} {b} {c} {d}
    {b} {c} {a} {d}
    {b} {d} {c} {d}
    {a} {e} {b} {e}
"""
