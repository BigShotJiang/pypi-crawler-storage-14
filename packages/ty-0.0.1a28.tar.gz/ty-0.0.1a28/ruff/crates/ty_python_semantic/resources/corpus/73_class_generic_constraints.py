class Foo[T: (str, bytes)]:
    x: T
