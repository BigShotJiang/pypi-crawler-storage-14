def foo():
    # This is runtime, not compile-time error
    a
    a = 2
