(
    (a and aa) or
    (b and bb) or
    (c and cc)
)
