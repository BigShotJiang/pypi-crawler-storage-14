def foo():
    a = 2
    a
