if a:
    b
else:
    c
