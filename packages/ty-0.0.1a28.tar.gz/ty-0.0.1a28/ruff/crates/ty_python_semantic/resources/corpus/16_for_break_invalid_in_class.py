for _ in range(1):

    class A:
        x: int

        break
