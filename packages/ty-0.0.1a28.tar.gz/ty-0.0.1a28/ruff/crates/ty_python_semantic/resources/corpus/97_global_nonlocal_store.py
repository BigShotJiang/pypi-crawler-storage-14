def dispatch():
    row_id: int = 0

    def update_task_runs() -> None:
        global row_id
        a = row_id
