def foo():
    a = 1

    def inner():
        a

