fun(*b, c)
fun(a, *b, c)
fun(a, *b, c, *d)
