from unresolved_module import SomethingUnknown

class Foo(SomethingUnknown): ...

tuple(Foo)
