for x in [a, b]:
    pass
