a = [
    x for x in y
]
