def get_names(syms):
    return [s for s in syms]
