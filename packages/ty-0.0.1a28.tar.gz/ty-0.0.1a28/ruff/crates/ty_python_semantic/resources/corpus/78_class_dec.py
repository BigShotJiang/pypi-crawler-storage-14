@foo
class C:
   pass

