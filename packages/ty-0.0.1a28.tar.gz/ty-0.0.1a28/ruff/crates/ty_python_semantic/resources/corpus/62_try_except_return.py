def foo():
    try:
        pass
    except Exception as e:
        if a:
            return
