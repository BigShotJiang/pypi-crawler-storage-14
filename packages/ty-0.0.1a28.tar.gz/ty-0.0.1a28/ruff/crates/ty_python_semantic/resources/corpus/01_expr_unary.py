-a
~a
+a
not a
