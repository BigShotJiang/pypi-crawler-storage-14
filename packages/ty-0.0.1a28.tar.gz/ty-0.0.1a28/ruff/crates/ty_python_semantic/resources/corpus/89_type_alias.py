type foo = int
type ListOrSet[T] = list[T] | set[T]
