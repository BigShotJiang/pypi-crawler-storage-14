def tracing_scope():
    try:
        pass
    finally:
        while a:
            pass
