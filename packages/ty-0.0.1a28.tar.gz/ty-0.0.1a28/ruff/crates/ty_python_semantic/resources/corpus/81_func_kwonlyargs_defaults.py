def foo():
    class Foo:
        def bar(a=b.c, *, b=c.d):
            pass
