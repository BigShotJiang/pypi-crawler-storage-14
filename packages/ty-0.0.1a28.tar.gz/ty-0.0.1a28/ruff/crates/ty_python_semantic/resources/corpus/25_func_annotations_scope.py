def foo():
    ann = None
    def bar(a: ann) -> ann:
        pass
