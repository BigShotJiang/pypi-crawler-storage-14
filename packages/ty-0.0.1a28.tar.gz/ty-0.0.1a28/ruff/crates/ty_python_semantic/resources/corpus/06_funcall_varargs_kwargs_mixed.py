fun(a, kw=1, *c, **d)
fun(a, *c, kw=1, **d)

fun(a, kw=1, *c)
fun(a, *c, kw=1)

fun(a, *c)

# Introduced in Python3.5, not supported yet
#fun(*c, a)
