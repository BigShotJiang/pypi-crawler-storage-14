("foo"
.format())
