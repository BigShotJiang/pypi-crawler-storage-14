while a:
    try:
        continue
    finally:
        break
