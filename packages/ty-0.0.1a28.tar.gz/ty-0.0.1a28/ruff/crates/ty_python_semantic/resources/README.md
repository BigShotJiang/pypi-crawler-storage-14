Markdown files within the `mdtest/` subdirectory are tests of type inference and type checking;
executed by the `tests/mdtest.rs` integration test.

See `crates/ty_test/README.md` for documentation of this test format.
