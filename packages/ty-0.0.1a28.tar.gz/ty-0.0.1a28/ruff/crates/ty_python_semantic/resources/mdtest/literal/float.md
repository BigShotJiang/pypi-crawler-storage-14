# Float literals

## Basic

```py
reveal_type(1.0)  # revealed: float
```
