# Multi-target assignment

## Basic

```py
x = y = 1
reveal_type(x)  # revealed: Literal[1]
reveal_type(y)  # revealed: Literal[1]
```
