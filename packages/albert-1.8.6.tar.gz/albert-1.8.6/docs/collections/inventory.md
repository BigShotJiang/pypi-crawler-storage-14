::: albert.collections.inventory.InventoryCollection
