::: albert.resources.locations
