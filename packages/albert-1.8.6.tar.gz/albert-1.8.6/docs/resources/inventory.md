::: albert.resources.inventory
