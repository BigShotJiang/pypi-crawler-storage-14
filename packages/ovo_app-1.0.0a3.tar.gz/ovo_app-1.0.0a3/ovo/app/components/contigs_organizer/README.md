# Development Guide

Install and build using:

```bash
bun install
npm run build
```