from ovo.app.components.molstar_custom_component import *
