# SEC07-BP02: Define data protection controls

## Description

Controls theo classification.

## Implementation Guidance

- Control matrix by classification
- Encryption requirements
- Access control requirements
- Handling procedures
- Monitoring requirements

## Risk Level

Medium - Inconsistent controls lead to gaps.
