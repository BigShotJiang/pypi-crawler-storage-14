# SEC10-BP01: Identify key personnel and external resources

## Description

IR team identified.

## Implementation Guidance

- Security incident team defined
- External IR support contracts
- Legal counsel identified
- Communication team ready
- Escalation contacts current

## Risk Level

High - Unknown responders delay incident response.
