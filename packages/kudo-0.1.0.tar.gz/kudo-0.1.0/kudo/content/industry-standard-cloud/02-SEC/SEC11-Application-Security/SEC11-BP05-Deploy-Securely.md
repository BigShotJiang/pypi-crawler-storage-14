# SEC11-BP05: Implement a program that embeds security in your development organization

## Description

Secure deployment.

## Implementation Guidance

- Security champions program
- Embedded security in teams
- Security gates in SDLC
- Security metrics tracking
- Continuous security improvement

## Risk Level

Medium - Bolt-on security is less effective.
