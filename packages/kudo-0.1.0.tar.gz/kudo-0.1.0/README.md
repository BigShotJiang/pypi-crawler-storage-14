# Kudo

Agentic Coding

> Kudo: What if I known Industry Standard Practices, can I code better than human?