PINTEREST_SERVER_URL = 'https://api.pinterest.com'
