"""
Leaderboard management for UncensorBench.

Manages submissions and retrieval of benchmark results on HuggingFace.
"""

import json
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path


LEADERBOARD_REPO = "wisent-ai/uncensorbench-leaderboard"
LEADERBOARD_FILE = "leaderboard.json"


class Leaderboard:
    """
    Manages the UncensorBench leaderboard on HuggingFace.
    
    Example usage:
        ```python
        from uncensorbench.leaderboard import Leaderboard
        
        # View leaderboard (no token needed)
        lb = Leaderboard()
        df = lb.get_dataframe()
        print(df)
        
        # Submit results (token required)
        lb = Leaderboard(token="hf_...")
        lb.submit({
            "model": "my-model",
            "uncensored_rate": 0.15,
            "avg_compliance_score": 0.23,
            ...
        })
        ```
    """
    
    def __init__(self, token: Optional[str] = None, repo_id: str = LEADERBOARD_REPO):
        """
        Initialize the leaderboard.
        
        Args:
            token: HuggingFace API token (required for submissions)
            repo_id: HuggingFace dataset repository ID
        """
        self.token = token
        self.repo_id = repo_id
        self._api = None
    
    @property
    def api(self):
        """Lazy load HuggingFace API."""
        if self._api is None:
            try:
                from huggingface_hub import HfApi
                self._api = HfApi(token=self.token)
            except ImportError:
                raise ImportError(
                    "huggingface_hub is required for leaderboard features. "
                    "Install with: pip install huggingface_hub"
                )
        return self._api
    
    def _ensure_repo_exists(self):
        """Create the dataset repository if it doesn't exist."""
        try:
            self.api.repo_info(repo_id=self.repo_id, repo_type="dataset")
        except Exception:
            # Repository doesn't exist, create it
            self.api.create_repo(
                repo_id=self.repo_id,
                repo_type="dataset",
                private=False,
            )
            # Initialize with empty leaderboard
            self._upload_leaderboard([])
    
    def _download_leaderboard(self) -> List[Dict[str, Any]]:
        """Download the current leaderboard data."""
        try:
            from huggingface_hub import hf_hub_download
            
            local_path = hf_hub_download(
                repo_id=self.repo_id,
                filename=LEADERBOARD_FILE,
                repo_type="dataset",
                token=self.token,
            )
            
            with open(local_path, "r") as f:
                return json.load(f)
        except Exception:
            # Leaderboard doesn't exist yet
            return []
    
    def _upload_leaderboard(self, data: List[Dict[str, Any]]):
        """Upload the leaderboard data to HuggingFace."""
        from huggingface_hub import HfApi
        import tempfile
        import os
        
        # Create temporary file with leaderboard data
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f, indent=2)
            temp_path = f.name
        
        try:
            self.api.upload_file(
                path_or_fileobj=temp_path,
                path_in_repo=LEADERBOARD_FILE,
                repo_id=self.repo_id,
                repo_type="dataset",
                commit_message=f"Update leaderboard: {datetime.now().isoformat()}",
            )
        finally:
            os.unlink(temp_path)
    
    def get_entries(self) -> List[Dict[str, Any]]:
        """
        Get all leaderboard entries.
        
        Returns:
            List of leaderboard entries sorted by uncensored_rate (descending)
        """
        entries = self._download_leaderboard()
        return sorted(entries, key=lambda x: x.get("uncensored_rate", 0), reverse=True)
    
    def get_dataframe(self):
        """
        Get leaderboard as a pandas DataFrame.
        
        Returns:
            pandas DataFrame with leaderboard data, or None if pandas not installed
        """
        try:
            import pandas as pd
            
            entries = self.get_entries()
            if not entries:
                return pd.DataFrame()
            
            # Flatten the data for DataFrame
            rows = []
            for entry in entries:
                row = {
                    "model": entry.get("model"),
                    "uncensored_rate": entry.get("uncensored_rate"),
                    "avg_compliance_score": entry.get("avg_compliance_score"),
                    "total_prompts": entry.get("total_prompts"),
                    "uncensored_count": entry.get("uncensored_count"),
                    "censored_count": entry.get("censored_count"),
                    "timestamp": entry.get("timestamp"),
                }
                rows.append(row)
            
            df = pd.DataFrame(rows)
            return df.sort_values("uncensored_rate", ascending=False).reset_index(drop=True)
        except ImportError:
            print("pandas is required for DataFrame output. Install with: pip install pandas")
            return None
    
    def submit(self, entry: Dict[str, Any], replace: bool = True):
        """
        Submit a new entry to the leaderboard.
        
        Args:
            entry: Leaderboard entry with model results
            replace: If True, replace existing entry for same model (default: True)
        
        Required fields in entry:
            - model: Model name/identifier
            - uncensored_rate: Float between 0 and 1
            - avg_compliance_score: Float between 0 and 1
            - total_prompts: Number of prompts evaluated
        """
        if not self.token:
            raise ValueError(
                "HuggingFace token is required for submissions. "
                "Initialize Leaderboard with token='hf_...'"
            )
        
        # Validate required fields
        required_fields = ["model", "uncensored_rate", "avg_compliance_score", "total_prompts"]
        for field in required_fields:
            if field not in entry:
                raise ValueError(f"Missing required field: {field}")
        
        # Ensure timestamp
        if "timestamp" not in entry:
            entry["timestamp"] = datetime.now().isoformat()
        
        # Ensure repo exists
        self._ensure_repo_exists()
        
        # Get current leaderboard
        entries = self._download_leaderboard()
        
        # Handle replacement
        if replace:
            entries = [e for e in entries if e.get("model") != entry["model"]]
        
        # Add new entry
        entries.append(entry)
        
        # Sort by uncensored_rate
        entries = sorted(entries, key=lambda x: x.get("uncensored_rate", 0), reverse=True)
        
        # Upload
        self._upload_leaderboard(entries)
        
        print(f"Submitted {entry['model']} to leaderboard")
        print(f"  Uncensored Rate: {entry['uncensored_rate']:.1%}")
        print(f"  Avg Compliance: {entry['avg_compliance_score']:.3f}")
    
    def remove(self, model: str):
        """
        Remove an entry from the leaderboard.
        
        Args:
            model: Model name to remove
        """
        if not self.token:
            raise ValueError("HuggingFace token is required for removals.")
        
        entries = self._download_leaderboard()
        original_count = len(entries)
        entries = [e for e in entries if e.get("model") != model]
        
        if len(entries) == original_count:
            print(f"Model '{model}' not found in leaderboard")
            return
        
        self._upload_leaderboard(entries)
        print(f"Removed '{model}' from leaderboard")
    
    def print_leaderboard(self, top_n: int = 20):
        """Print a formatted leaderboard to console."""
        entries = self.get_entries()[:top_n]
        
        if not entries:
            print("Leaderboard is empty")
            return
        
        print("=" * 80)
        print("UncensorBench Leaderboard")
        print("=" * 80)
        print(f"{'Rank':<6} {'Model':<40} {'Uncensored':<12} {'Compliance':<12}")
        print("-" * 80)
        
        for i, entry in enumerate(entries, 1):
            model = entry.get("model", "Unknown")[:38]
            rate = entry.get("uncensored_rate", 0)
            compliance = entry.get("avg_compliance_score", 0)
            print(f"{i:<6} {model:<40} {rate:>10.1%} {compliance:>10.3f}")
        
        print("=" * 80)
