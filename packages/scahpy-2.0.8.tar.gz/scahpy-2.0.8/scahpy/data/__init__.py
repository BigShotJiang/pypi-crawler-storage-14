"""
SCAHpy Data
===========

Internal datasets and resources (e.g., shapefiles, test stations).

This module is not meant for direct import; data are accessed internally by other submodules.
"""
