import re
from collections import Counter
from .exception import InvalidTextError, InvalidArgumentError
from .cleaning import remove_punctuation

def _validate_text(text):
    if not isinstance(text, str):
        raise InvalidTextError("Входной аргумент 'text' должен быть строкой.")

def word_count(text: str) -> int:
    _validate_text(text)
    cleaned_text = remove_punctuation(text).lower()
    words = cleaned_text.split()
    return len(words)

def char_count(text: str, ignore_spaces: bool = False) -> int:
    _validate_text(text)
    if not isinstance(ignore_spaces, bool):
        raise InvalidArgumentError("Аргумент 'ignore_spaces' должен быть булевым.")

    if ignore_spaces:
        return len(text.replace(' ', ''))
    return len(text)

def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    _validate_text(text)
    if not isinstance(n, int) or n < 1:
        raise InvalidArgumentError("Аргумент 'n' должен быть целым числом и больше или равен 1.")

    cleaned_text = remove_punctuation(text).lower()
    words = [word for word in cleaned_text.split() if word]

    if not words:
        return []

    word_counts = Counter(words)
    return word_counts.most_common(n)