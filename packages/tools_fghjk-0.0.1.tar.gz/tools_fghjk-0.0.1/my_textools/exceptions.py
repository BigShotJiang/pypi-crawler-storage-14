class TexttoolsError(Exception):
    pass

class InvalidTextError(TexttoolsError):
    pass

class InvalidArgumentError(TexttoolsError):
    pass