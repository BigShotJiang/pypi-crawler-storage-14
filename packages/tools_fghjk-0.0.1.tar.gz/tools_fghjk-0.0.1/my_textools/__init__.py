from .exception import TexttoolsError, InvalidTextError, InvalidArgumentError
from .cleaning import remove_whitespace, remove_punctuation, replace_symbols
from .formatting import to_snake_case, to_kebab_case, capitalize_sentences
from .analysis import word_count, char_count, top_words

__all__ = [
    "TexttoolsError",
    "InvalidTextError",
    "InvalidArgumentError",
    "remove_whitespace",
    "remove_punctuation",
    "replace_symbols",
    "to_snake_case",
    "to_kebab_case",
    "capitalize_sentences",
    "word_count",
    "char_count",
    "top_words",
]
from .exception import TextToolsError, InvalidTextError
from .cleaning import remove_whitespace, remove_punctuation, normalize_spaces

__version__ = "0.1.0"
    
