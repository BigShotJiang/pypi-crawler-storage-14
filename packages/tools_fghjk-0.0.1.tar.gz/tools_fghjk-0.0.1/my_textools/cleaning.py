import re
import string
from .exceptions import InvalidTextError

def _validate_text(text):
    if not isinstance(text, str):
        raise InvalidTextError("Входной аргумент 'text' должен быть строкой.")

def remove_whitespace(text: str) -> str:
    _validate_text(text)
    return re.sub(r'\s+', ' ', text).strip()

def remove_punctuation(text: str, keep: str = "") -> str:
    _validate_text(text)
    if not isinstance(keep, str):
        raise InvalidTextError("Аргумент 'keep' должен быть строкой.")

    punctuations_to_remove = "".join(
        [char for char in string.punctuation if char not in keep]
    )
    translator = str.maketrans("", "", punctuations_to_remove)
    return text.translate(translator)

def replace_symbols(text: str) -> str:
    _validate_text(text)
    return remove_whitespace(re.sub(r'[\t\n\r\f\v]', ' ', text))