"""
Main entry point for running ApiLinker as a module.
"""

from apilinker.cli import app

if __name__ == "__main__":
    app()
