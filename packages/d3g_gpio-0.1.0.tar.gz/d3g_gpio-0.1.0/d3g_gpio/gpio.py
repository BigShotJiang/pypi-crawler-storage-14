import os
import time

GPIO_IN = "in"
GPIO_OUT = "out"

GPIO_LOW = 0
GPIO_HIGH = 1

class D3GGPIO:
    def __init__(self):
        self.export_path = "/sys/class/gpio/export"
        self.unexport_path = "/sys/class/gpio/unexport"

    def export(self, pin):
        if not os.path.exists(f"/sys/class/gpio/gpio{pin}"):
            with open(self.export_path, "w") as f:
                f.write(str(pin))
            time.sleep(0.05)

    def unexport(self, pin):
        with open(self.unexport_path, "w") as f:
            f.write(str(pin))

    def setup(self, pin, direction):
        self.export(pin)
        with open(f"/sys/class/gpio/gpio{pin}/direction", "w") as f:
            f.write(direction)

    def output(self, pin, value:int):
        path = f"/sys/class/gpio/gpio{pin}/value"
        with open(path, "w") as f:
            f.write("1" if value else "0")

    def input(self, pin):
        path = f"/sys/class/gpio/gpio{pin}/value"
        with open(path, "r") as f:
            return int(f.read().strip())

# �̱��� �ν��Ͻ�ó�� ���� ����
GPIO = D3GGPIO()
