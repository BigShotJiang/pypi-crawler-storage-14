function t(t,n){const e=n||{};return(""===t[t.length-1]?[...t,""]:t).join((e.padRight?" ":"")+","+(!1===e.padLeft?"":" ")).trim()}export{t as s};
