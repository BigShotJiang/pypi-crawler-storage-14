const a=function(a){for(var e=a.length/6|0,f=new Array(e),r=0;r<e;)f[r]="#"+a.slice(6*r,6*++r);return f}("4e79a7f28e2ce1575976b7b259a14fedc949af7aa1ff9da79c755fbab0ab");export{a as d};
