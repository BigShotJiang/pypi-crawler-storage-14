from __future__ import annotations

import typing as t

from audex.helper.settings import BaseModel
from audex.helper.settings.fields import Field


class RecorderConfig(BaseModel):
    format: t.Literal["float32", "int32", "int16", "int8", "uint8"] = Field(
        default="int16",
        description="Audio sample format.",
    )

    channels: int = Field(
        default=1,
        ge=1,
        le=8,
        description="Number of audio channels.",
    )

    chunk: int = Field(
        default=1024,
        ge=256,
        le=8192,
        description="Number of frames per buffer.",
    )

    input_device_index: int | None = Field(
        default=None,
        description="Index of the input audio device. If None, the default device is used.",
    )
