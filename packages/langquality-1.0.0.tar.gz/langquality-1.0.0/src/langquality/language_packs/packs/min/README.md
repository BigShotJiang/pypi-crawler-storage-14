# Minimal Example Language Pack

This is a minimal example showing the absolute minimum required for a Language Pack.

It contains:
- `config.yaml` with only required language fields
- `metadata.json` with only required metadata fields
- No resources directory
- No custom analyzers

This pack will use all default settings and will have limited functionality, but demonstrates that Language Packs can be very simple.
