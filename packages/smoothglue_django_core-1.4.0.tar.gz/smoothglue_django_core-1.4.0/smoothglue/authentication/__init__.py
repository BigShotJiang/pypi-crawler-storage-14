default_app_config = "smoothglue.authentication.apps.AuthenticationConfig"
