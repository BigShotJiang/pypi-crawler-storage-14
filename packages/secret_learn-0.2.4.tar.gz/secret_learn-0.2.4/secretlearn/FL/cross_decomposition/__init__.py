"""SecretFlow cross_decomposition adapters"""
