"""SecretFlow anomaly_detection adapters"""
