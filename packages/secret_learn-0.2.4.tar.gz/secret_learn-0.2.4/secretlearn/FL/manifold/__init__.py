"""SecretFlow manifold adapters"""
