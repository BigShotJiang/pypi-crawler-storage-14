"""SecretFlow dummy adapters"""
