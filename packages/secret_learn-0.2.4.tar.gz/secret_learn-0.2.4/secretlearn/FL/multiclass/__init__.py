"""SecretFlow multiclass adapters"""
