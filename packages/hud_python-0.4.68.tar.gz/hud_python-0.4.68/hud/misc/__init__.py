"""Miscellaneous utilities for HUD SDK."""
