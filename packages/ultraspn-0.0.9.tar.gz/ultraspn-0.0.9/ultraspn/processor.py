from __future__ import annotations

import multiprocessing
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional, Sequence, Tuple

import chanfig
import cv2 as cv
import numpy as np
import pandas as pd
from PIL import Image
from scipy.optimize import curve_fit
from scipy.signal import find_peaks
from scipy.special import expit
from tqdm import tqdm


class Config(chanfig.Config):
    input: str = "images"
    output: str = "outputs"
    table: str = "zx.csv"
    plateau_width: float = 63.0
    threshold: float = 0.8
    bbox_color: Tuple[int, int, int] = (0, 255, 0)
    bbox_thickness: int = 5
    workers: int | None = None

    def post(self) -> None:
        if not (0 < self.threshold <= 1.0):
            raise ValueError("threshold must be within (0, 1]")
        if self.workers is not None and self.workers < 0:
            raise ValueError("workers must be None, 0, or positive integer")


@dataclass
class BoundingBox:
    top: int
    bottom: int
    left: int
    right: int

    @property
    def height(self) -> int:
        return max(0, self.bottom - self.top)

    @property
    def width(self) -> int:
        return max(0, self.right - self.left)


@dataclass
class ColorCues:
    band: np.ndarray
    glare_mask: np.ndarray
    specular_map: np.ndarray


class Axis(Enum):
    VERTICAL = 0
    HORIZONTAL = 1


def _ensure_odd(value: int) -> int:
    """Ensures the integer value is odd, useful for kernel sizes."""
    return value if value % 2 == 1 else value + 1


def _smooth_sequence(sequence: np.ndarray, window: int) -> np.ndarray:
    """Smooths a 1D sequence using a moving average box filter."""
    if window <= 1:
        return sequence
    window = _ensure_odd(int(window))
    kernel = np.ones(window, dtype=np.float64) / window
    return np.convolve(sequence, kernel, mode="same")


def _clahe_parameters(gray: np.ndarray) -> Tuple[float, Tuple[int, int]]:
    """Calculates dynamic CLAHE parameters based on image variance."""
    h, w = gray.shape
    grid = max(2, int(round(np.sqrt(h * w) / 150)))
    clip = float(np.clip(np.var(gray) / 1024 + 1.5, 1.0, 8.0))
    return clip, (grid, grid)


def _calculate_column_weights(width: int) -> np.ndarray:
    """Generates a Gaussian weight distribution centered on the image width."""
    positions = (np.arange(width) - (width - 1) / 2) / max(width / 6.0, 1.0)
    weights = np.exp(-(positions**2) / 2.0)
    return weights / weights.max()


def _calculate_row_weights(height: int) -> np.ndarray:
    """Generates a Gaussian weight distribution centered on the image height."""
    positions = (np.arange(height) - (height - 1) / 2) / max(height / 6.0, 1.0)
    weights = np.exp(-(positions**2) / 2.0)
    return weights / weights.max()


def _preprocess(gray: np.ndarray) -> np.ndarray:
    """Applies CLAHE and Gaussian Blur to enhance local contrast."""
    clip_limit, tile_grid = _clahe_parameters(gray)
    clahe = cv.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid)
    enhanced = clahe.apply(gray)
    kernel = _ensure_odd(max(3, int(round(min(gray.shape) / 150))))
    return cv.GaussianBlur(enhanced, (kernel, kernel), 0)


def _sobel_profiles(image: np.ndarray, axis: int) -> Tuple[np.ndarray, np.ndarray]:
    """Computes positive and negative gradient profiles using Sobel operator."""
    if axis == 0:
        grad = cv.Sobel(image, cv.CV_32F, 0, 1, ksize=3)
        col_weights = _calculate_column_weights(image.shape[1])
        row_weights = _calculate_row_weights(image.shape[0])
        positive = (np.maximum(grad, 0.0) * col_weights).sum(axis=1) * row_weights
        negative = (np.maximum(-grad, 0.0) * col_weights).sum(axis=1) * row_weights
    elif axis == 1:
        grad = cv.Sobel(image, cv.CV_32F, 1, 0, ksize=3)
        row_weights = _calculate_row_weights(image.shape[0])
        weighted = np.maximum(grad, 0.0) * row_weights[:, None]
        col_weights = _calculate_column_weights(image.shape[1]) ** 0.5
        positive = weighted.sum(axis=0) * col_weights
        weighted_neg = np.maximum(-grad, 0.0) * row_weights[:, None]
        negative = weighted_neg.sum(axis=0) * col_weights
    else:
        raise ValueError("axis must be 0 (vertical) or 1 (horizontal)")
    return positive.astype(np.float64), negative.astype(np.float64)


def _local_maxima(values: np.ndarray) -> np.ndarray:
    """Finds indices of local maxima in a 1D array."""
    if values.size < 3:
        return np.array([], dtype=np.int32)
    gradient = np.diff(values)
    signs = np.sign(gradient)
    turning = (np.hstack([signs, 0.0]) < 0.0) & (np.hstack([0.0, signs]) > 0.0)
    return np.where(turning)[0].astype(np.int32)


def _detect_plateau_bounds(
    darkness_smooth: np.ndarray,
    width: int,
    plateau_threshold: float = 0.5,
) -> Tuple[int, int]:
    """Detects the broad specimen region ('plateau') based on darkness."""
    high_darkness_mask = darkness_smooth > plateau_threshold

    transitions = np.diff(np.concatenate(([False], high_darkness_mask, [False])).astype(int))
    starts = np.where(transitions == 1)[0]
    ends = np.where(transitions == -1)[0]

    if len(starts) == 0 or len(ends) == 0:
        raise RuntimeError("no plateau found")

    widths = ends - starts
    widest_idx = np.argmax(widths)
    plateau_start = starts[widest_idx]
    plateau_end = ends[widest_idx]
    plateau_width = widths[widest_idx]

    if plateau_width < width * 0.20:
        raise RuntimeError("plateau is not wide enough to be considered a plateau")

    return int(plateau_start), int(plateau_end)


def _enhance_by_plateau(
    color: np.ndarray,
    enhanced_gray: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, Tuple[int, int]]:
    """Performs initial perspective correction based on the detected plateau."""
    height, width = enhanced_gray.shape
    if height == 0 or width == 0:
        raise RuntimeError("image is empty")

    col_profile = enhanced_gray.mean(axis=0).astype(np.float64)
    max_intensity = float(col_profile.max())
    min_intensity = float(col_profile.min())
    darkness = (max_intensity - col_profile) / (max_intensity - min_intensity + 1e-9)
    sigma = max(1.0, width / 1800.0)
    darkness_smooth = cv.GaussianBlur(darkness.reshape(1, -1), (0, 0), sigma * 1.5).reshape(-1)

    left, right = _detect_plateau_bounds(darkness_smooth, width, plateau_threshold=0.5)

    src = np.float32([[left, 0], [right, 0], [right, height - 1], [left, height - 1]])
    dst_w = int(max(1, right - left))
    dst = np.float32([[0, 0], [dst_w - 1, 0], [dst_w - 1, height - 1], [0, height - 1]])
    M = cv.getPerspectiveTransform(src, dst)

    rect_color = cv.warpPerspective(color, M, (dst_w, height), flags=cv.INTER_LINEAR)
    rect_gray = cv.warpPerspective(enhanced_gray, M, (dst_w, height), flags=cv.INTER_LINEAR)

    return rect_color, rect_gray, (int(left), int(right))


def _detect_vertical_edges(
    rect_gray: np.ndarray,
) -> Tuple[int, int, int, int]:
    """Finds the Top/Bottom boundaries using vertical Sobel profiles."""
    h, w = rect_gray.shape
    if h == 0:
        return 0, 0, 0, 0

    blur_sigma = max(1.0, min(h, w) / 1500.0)
    blurred = cv.GaussianBlur(rect_gray, (0, 0), blur_sigma)

    strip_w = max(10, w // 12)
    left_strip = blurred[:, :strip_w]
    right_strip = blurred[:, w - strip_w :]

    up_l, down_l = _sobel_profiles(left_strip, axis=0)
    up_r, down_r = _sobel_profiles(right_strip, axis=0)

    smoothing = max(5, h // 200)
    up_l = _smooth_sequence(up_l, smoothing)
    down_l = _smooth_sequence(down_l, smoothing)
    up_r = _smooth_sequence(up_r, smoothing)
    down_r = _smooth_sequence(down_r, smoothing)

    bottom_l = int(np.argmax(down_l))
    bottom_r = int(np.argmax(down_r))

    peaks_l = _local_maxima(up_l)
    peaks_r = _local_maxima(up_r)

    def pick_top(peaks, up_s, bottom_idx):
        cand = [p for p in peaks if 0 < bottom_idx - p <= max(h // 4, 400)]
        if not cand and bottom_idx > 0:
            cand = [int(np.argmax(up_s[:bottom_idx]))]
        return int(max(cand, key=lambda i: up_s[i])) if cand else max(0, bottom_idx - h // 10)

    top_l = pick_top(peaks_l, up_l, bottom_l)
    top_r = pick_top(peaks_r, up_r, bottom_r)

    return top_l, top_r, bottom_l, bottom_r


def _fit_box_model(profile: np.ndarray, width: int, threshold: float = 0.95) -> Tuple[int, int, int, int]:
    """
    Method 1: Global Model Fitting.
    Fits a Double-Sigmoid (Box) model to the intensity profile.
    Robust against noise and invisible centers by using the entire signal shape.
    Returns (adjusted_left, adjusted_right, raw_inflection_left, raw_inflection_right).
    """
    # Safety: Normalize threshold if passed as percentage > 1.0 (e.g. 80 -> 0.8)
    if threshold > 1.0:
        threshold /= 100.0

    x = np.arange(width)

    def model(x, x1, x2, k1, k2, b, h):
        # k1: steepness of rising edge (left), k2: steepness of falling edge (right)
        s1 = expit(k1 * (x - x1))
        s2 = expit(k2 * (x - x2))
        return b + h * (s1 - s2)

    p0_x1 = width * 0.25
    p0_x2 = width * 0.75
    p0_k1 = 0.5
    p0_k2 = 0.5
    p0_b = float(np.min(profile))
    p0_h = float(np.max(profile) - p0_b)

    bounds = ([0, 0, 0.01, 0.01, 0, 0], [width, width, 10.0, 10.0, 1.0, 1.5])

    try:
        popt, _ = curve_fit(model, x, profile, p0=[p0_x1, p0_x2, p0_k1, p0_k2, p0_b, p0_h], bounds=bounds, maxfev=5000)
        x1, x2, k1, k2, b, h = popt

        if x1 > x2:
            x1, x2 = x2, x1
            k1, k2 = k2, k1  # Swap steepness too

        shift_l = -(1.0 / k1) * np.log(1.0 / threshold - 1.0)
        shift_r = -(1.0 / k2) * np.log(1.0 / threshold - 1.0)

        adj_x1 = int(x1 + shift_l)
        adj_x2 = int(x2 - shift_r)

        return adj_x1, adj_x2, int(x1), int(x2)

    except Exception:
        return -1, -1, -1, -1


def _detect_gradient_edges(ni_smooth: np.ndarray, width: int) -> Tuple[int, int]:
    """
    Method 2: Adaptive Gradient Analysis.
    1. Estimates noise floor from the signal statistics.
    2. Finds peaks above adaptive threshold.
    3. Selects best symmetric pair maximizing (Strength - Asymmetry).
    """
    g1 = np.gradient(ni_smooth)

    grad_std = np.std(g1)
    grad_abs_mean = np.mean(np.abs(g1))

    if g1.size < 3:
        return -1, -1

    pos_peaks, _ = find_peaks(g1, height=grad_abs_mean + grad_std)
    neg_peaks, _ = find_peaks(-g1, height=grad_abs_mean + grad_std)

    if pos_peaks.size == 0 or neg_peaks.size == 0:
        pos_peaks, _ = find_peaks(g1, height=grad_abs_mean)
        neg_peaks, _ = find_peaks(-g1, height=grad_abs_mean)
        if pos_peaks.size == 0 or neg_peaks.size == 0:
            return -1, -1

    center = width // 2
    best_score = -float("inf")
    best_l, best_r = -1, -1

    max_g = np.max(np.abs(g1)) + 1e-9

    for l in pos_peaks:
        if l >= center + width * 0.1:
            continue

        for r in neg_peaks:
            if r <= center - width * 0.1:
                continue
            if r <= l + 10:
                continue

            h_l = g1[l] / max_g
            h_r = -g1[r] / max_g

            dist_l = center - l
            dist_r = r - center
            asymmetry = abs(dist_l - dist_r) / (width + 1e-9)

            score = (h_l + h_r) - 2.0 * asymmetry

            if score > best_score:
                best_score = score
                best_l = l
                best_r = r

    return int(best_l), int(best_r)


def _detect_legacy_fallback(
    ni_smooth: np.ndarray, ni_mask: np.ndarray, width: int, threshold: float = 0.4
) -> Tuple[int, int]:
    """
    Method 3: Legacy Center-Out Scan.
    Scans for the first significant peak starting from the center outwards.
    Used as a last resort if smarter methods fail.
    """
    g1 = np.gradient(ni_smooth)
    center_idx = int(width // 2)
    n = width

    if g1.size >= 3:
        pos_peaks = np.where((g1[1:-1] > g1[:-2]) & (g1[1:-1] > g1[2:]))[0] + 1
        neg_peaks = np.where((g1[1:-1] < g1[:-2]) & (g1[1:-1] < g1[2:]))[0] + 1
    else:
        pos_peaks = np.array([], dtype=np.int32)
        neg_peaks = np.array([], dtype=np.int32)

    def thresholded_from_center(deriv: np.ndarray, center: int, threshold: float) -> tuple[int, int]:
        an_l, an_r = -1, -1
        left_idx = pos_peaks[pos_peaks < center]
        if left_idx.size:
            left_max = float(deriv[left_idx].max())
            thr_l = threshold * left_max
            left_set = set(int(i) for i in left_idx.tolist())
            for i in range(center - 1, 1, -1):
                if i in left_set and deriv[i] >= thr_l:
                    an_l = i
                    break

        right_idx = neg_peaks[neg_peaks > center]
        if right_idx.size:
            right_max = float((-deriv[right_idx]).max())
            thr_r = threshold * right_max
            right_set = set(int(i) for i in right_idx.tolist())
            for i in range(center + 1, n - 1):
                if i in right_set and (-deriv[i]) >= thr_r:
                    an_r = i
                    break
        return an_l, an_r

    an_left, an_right = thresholded_from_center(g1, center_idx, threshold=threshold)

    if an_left == -1 or an_right == -1:
        m = ni_mask.astype(np.int32)
        trans = np.diff(np.concatenate(([0], m, [0])))
        starts = np.where(trans == 1)[0]
        ends = np.where(trans == -1)[0] - 1
        run_lengths = ends - starts + 1
        min_run = max(30, int(0.04 * n))
        valid = run_lengths >= min_run
        starts = starts[valid]
        ends = ends[valid]

        if an_left == -1:
            left_runs = ends < center_idx
            if np.any(left_runs):
                le = ends[left_runs]
                ls = starts[left_runs]
                li = int(np.argmin(center_idx - le))
                rs_l = int(ls[li])
                re_l = int(le[li])
                rel = int(np.argmax(g1[rs_l : re_l + 1]))
                an_left = rs_l + rel
            else:
                lo = 1
                hi = max(2, center_idx)
                rel = int(np.argmax(g1[lo:hi])) if hi > lo else 1
                an_left = lo + rel

        if an_right == -1:
            right_runs = starts > center_idx
            if np.any(right_runs):
                rs = starts[right_runs]
                re = ends[right_runs]
                ri = int(np.argmin(rs - center_idx))
                rs_r = int(rs[ri])
                re_r = int(re[ri])
                rel = int(np.argmin(g1[rs_r : re_r + 1]))
                an_right = rs_r + rel
            else:
                lo = min(center_idx, n - 2)
                hi = n - 1
                rel = int(np.argmin(g1[lo:hi])) if hi > lo else n - 2
                an_right = lo + rel

    return int(an_left), int(an_right)


def _detect_horizontal_edges(
    enhanced_gray: np.ndarray,
    top: int,
    bottom: int,
    threshold: float = 0.95,
) -> Tuple[int, int]:
    """
    Main function to determine the Left/Right boundaries of the specimen.
    Uses a hierarchy of 3 methods:
    1. Global Model Fit (Best for faint/transparent samples)
    2. Adaptive Gradient Analysis (Smart heuristic fallback)
    3. Legacy Center-Out Scan (Robust last resort)
    """
    height, width = enhanced_gray.shape
    center_idx = int(width // 2)
    top = max(0, min(top, height - 1))
    bottom = max(top + 1, min(bottom, height))
    strip_proc = enhanced_gray[top:bottom]
    if strip_proc.size == 0:
        return 0, width

    profile = strip_proc.mean(axis=0).astype(np.float64)
    sigma = max(1.0, width / 1800.0)
    smoothed = cv.GaussianBlur(profile.reshape(1, -1), (0, 0), sigma).reshape(-1)

    max_intensity = float(smoothed.max())
    min_intensity = float(smoothed.min())
    neg_intensity_raw = max_intensity - smoothed
    neg_intensity = neg_intensity_raw / (max_intensity - min_intensity + 1e-9)

    win_pre = max(21, int(width / 300))
    if win_pre % 2 == 0:
        win_pre += 1
    kernel_pre = np.ones(win_pre, dtype=np.float64) / win_pre
    ni_smooth = np.convolve(neg_intensity, kernel_pre, mode="same")

    win_bg = max(win_pre * 3, int(width / 40))
    if win_bg % 2 == 0:
        win_bg += 1
    kernel_bg = np.ones(win_bg, dtype=np.float64) / win_bg
    ni_mean = np.convolve(ni_smooth, kernel_bg, mode="same")
    ni_sq_mean = np.convolve(ni_smooth * ni_smooth, kernel_bg, mode="same")
    ni_var = np.maximum(0.0, ni_sq_mean - ni_mean * ni_mean)
    ni_std = np.sqrt(ni_var + 1e-9)
    k_std = 0.9
    ni_mask = ni_smooth > (ni_mean + k_std * ni_std)

    fit_left, fit_right, raw_left, raw_right = _fit_box_model(ni_smooth, width, threshold=threshold)
    if fit_left != -1 and fit_right != -1:
        g1 = np.gradient(ni_smooth)
        x = np.arange(width)
        sigma = max(5.0, width * 0.02)

        def find_tightest_peak(signal: np.ndarray, is_left: bool) -> int:
            abs_signal = np.abs(signal)
            max_val = np.max(abs_signal)
            peaks, properties = find_peaks(abs_signal, height=max_val * 0.1, distance=max(3, width * 0.01))

            if len(peaks) == 0:
                return int(np.argmax(abs_signal))

            peak_heights = properties["peak_heights"]
            if len(peak_heights) == 0:
                return int(np.argmax(abs_signal))

            max_peak_height = np.max(peak_heights)
            valid_indices = np.where(peak_heights >= max_peak_height * 0.5)[0]

            if len(valid_indices) == 0:
                return int(peaks[np.argmax(peak_heights)])

            valid_peaks = peaks[valid_indices]
            valid_heights = peak_heights[valid_indices]

            sorted_valid_idx = np.argsort(valid_heights)[::-1]
            top_peaks = valid_peaks[sorted_valid_idx[:3]]

            if is_left:
                best_peak = np.max(top_peaks)
            else:
                best_peak = np.min(top_peaks)

            return int(best_peak)

        w_left = np.exp(-0.5 * ((x - raw_left) / sigma) ** 2)
        best_l = find_tightest_peak(np.maximum(g1 * w_left, 0), is_left=True)

        w_right = np.exp(-0.5 * ((x - raw_right) / sigma) ** 2)
        best_r = find_tightest_peak(np.maximum(-g1 * w_right, 0), is_left=False)

        if best_r > best_l + 10:
            return max(0, best_l), min(width - 1, best_r)

    grad_left, grad_right = _detect_gradient_edges(ni_smooth, width)
    if grad_left != -1 and grad_right != -1:
        return max(0, grad_left), min(width - 1, grad_right)

    an_left, an_right = _detect_legacy_fallback(ni_smooth, ni_mask, width, threshold=0.4)

    left = int(max(0, min(an_left, width - 2)))
    right = int(max(left + 1, min(an_right, width - 1)))
    if right <= left:
        right = min(width - 1, max(left + 1, center_idx + max(20, width // 100)))

    return left, right


def _rectify_distortion(
    image: np.ndarray, enhanced_gray: np.ndarray, v_bounds: Tuple[int, int, int, int]
) -> Tuple[np.ndarray, np.ndarray, Tuple[int, int]]:
    """Performs perspective transform to straighten the specimen region."""
    top_l, top_r, bottom_l, bottom_r = v_bounds
    h, w = image.shape[:2]

    src = np.float32([[0, top_l], [w - 1, top_r], [w - 1, bottom_r], [0, bottom_l]])

    avg_top = int((top_l + top_r) / 2)
    avg_bottom = int((bottom_l + bottom_r) / 2)

    dst = np.float32([[0, avg_top], [w - 1, avg_top], [w - 1, avg_bottom], [0, avg_bottom]])

    M = cv.getPerspectiveTransform(src, dst)
    rect_color = cv.warpPerspective(image, M, (w, h), flags=cv.INTER_LINEAR)
    rect_gray = cv.warpPerspective(enhanced_gray, M, (w, h), flags=cv.INTER_LINEAR)
    return rect_color, rect_gray, (avg_top, avg_bottom)


def detect_bbox(work_color: np.ndarray, work_gray: np.ndarray, threshold: float) -> Tuple[BoundingBox, np.ndarray]:
    """Detects the specimen bounding box using the full pipeline."""
    tl, tr, bl, br = _detect_vertical_edges(work_gray)
    rect_color, rect_gray, (new_top, new_bottom) = _rectify_distortion(work_color, work_gray, (tl, tr, bl, br))

    height, width = rect_gray.shape
    left, right = _detect_horizontal_edges(rect_gray, new_top, new_bottom, threshold)

    left = max(0, min(left, width - 2))
    right = max(left + 1, min(right, width))

    return (
        BoundingBox(top=new_top, bottom=new_bottom, left=left, right=right),
        rect_color,
    )


def draw_bbox(image: np.ndarray, box: BoundingBox, bbox_color: Tuple[int, int, int], bbox_thickness: int) -> np.ndarray:
    """Draws the bounding box on the image."""
    annotated = image.copy()
    cv.rectangle(
        annotated,
        (int(box.left), int(box.top)),
        (int(box.right), int(box.bottom)),
        tuple(int(v) for v in bbox_color),
        int(bbox_thickness),
    )
    return annotated


def process_image(
    input: str, output: str, threshold: float, bbox_color: Tuple[int, int, int], bbox_thickness: int
) -> Tuple[BoundingBox, str, int]:
    """Main entry point for processing a single image."""
    input_path = Path(input)
    color = cv.imread(str(input_path), cv.IMREAD_COLOR)
    if color is None:
        raise FileNotFoundError(f"unable to read image: {input_path}")

    gray = cv.cvtColor(color, cv.COLOR_BGR2GRAY)
    enhanced_gray = _preprocess(gray)
    rect_color, rect_gray, plateau_bounds = _enhance_by_plateau(color, enhanced_gray)

    bbox, final_img = detect_bbox(rect_color, rect_gray, threshold)

    plateau_left = int(plateau_bounds[0])
    global_bbox = BoundingBox(
        top=bbox.top,
        bottom=bbox.bottom,
        left=int(plateau_left + bbox.left),
        right=int(plateau_left + bbox.right),
    )

    annotated = draw_bbox(final_img, bbox, bbox_color, bbox_thickness)

    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.open(input_path)
    try:
        exif = img.getexif()
        time = exif[306]
    except Exception:
        time = ""
    if not cv.imwrite(str(output_path), annotated):
        raise RuntimeError(f"failed to save {output_path}")
    plateau_width = int(plateau_bounds[1] - plateau_bounds[0])
    return global_bbox, time, plateau_width


def _process_wrapper(args):
    input_path, output_path, threshold, bbox_color, bbox_thickness, f = args
    box, time, pwidth = process_image(input_path, output_path, threshold, bbox_color, bbox_thickness)
    return (box, time, pwidth), f


if __name__ == "__main__":
    cfg = Config().parse()
    ret = []
    files = sorted(os.listdir(cfg.input))
    if cfg.workers == 0:
        for f in tqdm(files, total=len(files), desc="Processing images"):
            box, time, pwidth = process_image(
                os.path.join(cfg.input, f),
                os.path.join(cfg.output, f),
                cfg.threshold,
                cfg.bbox_color,
                cfg.bbox_thickness,
            )
            ret.append(
                {
                    "id": f,
                    "time": time,
                    "height": box.height,
                    "width": box.width,
                    "top": box.top,
                    "left": box.left,
                    "bottom": box.bottom,
                    "right": box.right,
                    "plateau_width": box.width / pwidth * cfg.plateau_width,
                }
            )
    else:
        num_workers = cfg.workers if cfg.workers is not None else multiprocessing.cpu_count()
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            results = list(
                tqdm(
                    executor.map(
                        _process_wrapper,
                        [
                            (
                                os.path.join(cfg.input, f),
                                os.path.join(cfg.output, f),
                                cfg.threshold,
                                cfg.bbox_color,
                                cfg.bbox_thickness,
                                f,
                            )
                            for f in files
                        ],
                    ),
                    total=len(files),
                    desc="Processing images",
                )
            )
            ret = []
            for (box, time, pwidth), f in results:
                ret.append(
                    {
                        "id": f,
                        "time": time,
                        "height": box.height,
                        "width": box.width,
                        "top": box.top,
                        "left": box.left,
                        "bottom": box.bottom,
                        "right": box.right,
                        "plateau_width": box.width / pwidth * cfg.plateau_width,
                    }
                )
    df = pd.DataFrame(ret)
    df.to_csv(cfg.table, index=False)
    print(f"saved table -> {cfg.table}")
