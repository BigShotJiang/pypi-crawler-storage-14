"""Environment management for switching between local, staging, and production."""

import os
from pathlib import Path
from typing import Literal

from aitronos_cli.config import config
from aitronos_cli.utils.colors import log_ok, log_error, log_info, log_warn, FG_CYAN, FG_YELLOW, RESET

EnvironmentType = Literal["local", "staging", "production"]


class EnvironmentManager:
    """Manage environment configuration."""

    ENVIRONMENTS = {
        "local": {
            "name": "Local Development",
            "api_url": "http://localhost:8000",
            "description": "Local development server",
        },
        "staging": {
            "name": "Staging",
            "api_url": "https://staging-api.aitronos.com",
            "description": "Staging environment for testing",
        },
        "production": {
            "name": "Production",
            "api_url": "https://api.aitronos.com",
            "description": "Production environment",
        },
    }

    @staticmethod
    def get_current_environment() -> str:
        """Get the current environment."""
        api_url = config.get_api_url()
        
        # Match API URL to environment
        for env_key, env_config in EnvironmentManager.ENVIRONMENTS.items():
            if api_url == env_config["api_url"]:
                return env_key
        
        return "custom"

    @staticmethod
    def set_environment(environment: EnvironmentType) -> bool:
        """
        Set the environment.

        Args:
            environment: Environment to switch to (local, staging, production)

        Returns:
            True if successful, False otherwise
        """
        if environment not in EnvironmentManager.ENVIRONMENTS:
            log_error(f"Invalid environment: {environment}")
            return False

        env_config = EnvironmentManager.ENVIRONMENTS[environment]
        api_url = env_config["api_url"]

        # Update config
        config.set("api_url", api_url)
        config.save()

        log_ok(f"Switched to {env_config['name']} environment")
        log_info(f"API URL: {FG_CYAN}{api_url}{RESET}")

        return True

    @staticmethod
    def show_current_environment():
        """Display current environment information."""
        current_env = EnvironmentManager.get_current_environment()
        api_url = config.get_api_url()

        print()
        print(f"{FG_CYAN}Current Environment{RESET}")
        print("=" * 50)

        if current_env == "custom":
            print(f"Environment: {FG_YELLOW}Custom{RESET}")
            print(f"API URL: {api_url}")
        else:
            env_config = EnvironmentManager.ENVIRONMENTS[current_env]
            print(f"Environment: {FG_CYAN}{env_config['name']}{RESET}")
            print(f"API URL: {api_url}")
            print(f"Description: {env_config['description']}")

        print()

    @staticmethod
    def list_environments():
        """List all available environments."""
        current_env = EnvironmentManager.get_current_environment()

        print()
        print(f"{FG_CYAN}Available Environments{RESET}")
        print("=" * 50)

        for env_key, env_config in EnvironmentManager.ENVIRONMENTS.items():
            is_current = "✓ " if env_key == current_env else "  "
            print(f"{is_current}{FG_CYAN}{env_key}{RESET}: {env_config['name']}")
            print(f"   URL: {env_config['api_url']}")
            print(f"   {env_config['description']}")
            print()

    @staticmethod
    def switch_environment_interactive():
        """Interactive environment switching."""
        print()
        print(f"{FG_CYAN}Switch Environment{RESET}")
        print("=" * 50)

        current_env = EnvironmentManager.get_current_environment()
        print(f"Current: {FG_CYAN}{current_env}{RESET}")
        print()

        print("Available environments:")
        print(f"  1. {FG_CYAN}local{RESET} - Local development (http://localhost:8000)")
        print(f"  2. {FG_YELLOW}staging{RESET} - Staging environment")
        print(f"  3. {FG_YELLOW}production{RESET} - Production environment")
        print()

        choice = input("Select environment (1-3) or 'q' to cancel: ").strip()

        if choice == "q":
            log_info("Cancelled")
            return

        env_map = {
            "1": "local",
            "2": "staging",
            "3": "production",
        }

        if choice not in env_map:
            log_error("Invalid choice")
            return

        selected_env = env_map[choice]

        # Warn if switching to production
        if selected_env == "production":
            print()
            log_warn("You are about to switch to PRODUCTION environment")
            confirm = input("Are you sure? (yes/no): ").strip().lower()
            if confirm != "yes":
                log_info("Cancelled")
                return

        # Switch environment
        if EnvironmentManager.set_environment(selected_env):
            print()
            log_ok("Environment switched successfully!")
            
            # Show warning if not authenticated
            if not config.get("access_token"):
                print()
                log_warn("You are not authenticated in this environment")
                print("Run: aitronos auth login")


def show_environment():
    """Show current environment."""
    EnvironmentManager.show_current_environment()


def list_environments():
    """List available environments."""
    EnvironmentManager.list_environments()


def switch_environment(environment: str = None):
    """
    Switch environment.

    Args:
        environment: Environment to switch to (local, staging, production)
    """
    if environment:
        # Direct switch
        if environment not in EnvironmentManager.ENVIRONMENTS:
            log_error(f"Invalid environment: {environment}")
            print()
            print("Available environments: local, staging, production")
            return

        EnvironmentManager.set_environment(environment)
    else:
        # Interactive switch
        EnvironmentManager.switch_environment_interactive()
