"""Streamline project initialization."""

import io
import sys
import zipfile
import tempfile
import yaml
from pathlib import Path
from typing import Optional

from aitronos_cli.config import config
from aitronos_cli.auth import auth_manager
from aitronos_cli.api_client import (
    AitronosAPIClient,
    AuthenticationError,
    AuthorizationError,
)
from aitronos_cli.utils.colors import log_ok, log_error, log_info, log_step


def init_repository(directory: Optional[str] = None):
    """
    Initialize multi-automation repository.

    Creates a repository structure with automations/ directory for multiple automations.

    Args:
        directory: Target directory (defaults to current directory)
    """
    return _init_project(directory=directory, is_repo=True)


def init_automation(directory: Optional[str] = None):
    """
    Initialize single automation.

    Creates a standalone automation with streamline.yaml, main.py, etc.

    Args:
        directory: Target directory (defaults to current directory)
    """
    return _init_project(directory=directory, is_repo=False)


def _init_project(directory: Optional[str] = None, is_repo: bool = False):
    """
    Internal function to initialize Streamline project or repository.

    Fetches templates from Freddy Backend (which proxies to Streamline).

    Args:
        directory: Target directory (defaults to current directory)
        is_repo: If True, initialize multi-automation repository; if False, single automation
    """
    # Check authentication
    if not auth_manager.is_authenticated():
        log_error("Authentication required")
        log_info("Run 'aitronos auth login' to authenticate")
        return False

    # Prompt for directory if not provided
    if directory is None:
        print()
        log_info("Target directory (press Enter for current directory):")
        print("  Examples: ./my-project, ~/projects/test, ../automation")
        directory_input = input("  Path: ").strip()

        if directory_input:
            directory = directory_input
        else:
            directory = "."

    # Determine target directory
    target_dir = Path(directory).resolve()

    # Create directory if it doesn't exist
    if not target_dir.exists():
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
            log_ok(f"Created directory: {target_dir}")
        except Exception as e:
            log_error(f"Failed to create directory: {e}")
            return False

    # Check if directory is empty or confirm overwrite
    if list(target_dir.iterdir()):
        response = (
            input(f"Directory {target_dir} is not empty. Continue? (Y/n): ")
            .strip()
            .lower()
        )
        if response in ["n", "no"]:
            log_info("Cancelled")
            return False

    template_type = "repository" if is_repo else "project"
    log_step(f"Initializing Streamline {template_type}...")

    # Get API client
    api_url = config.get_api_url()
    access_token = auth_manager.get_access_token()
    client = AitronosAPIClient(api_url, access_token)

    try:
        # Fetch template ZIP from Freddy Backend
        log_info(f"Fetching {template_type} template...")

        if is_repo:
            zip_bytes = client.get_repository_template()
        else:
            zip_bytes = client.get_project_templates()

        if not zip_bytes:
            log_error("No template received from server")
            return False

        log_ok("Template downloaded successfully")

        # Extract ZIP to temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Extract ZIP
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                zf.extractall(temp_path)

            # Determine template root based on type
            if is_repo:
                # Repository template: root is the extracted directory
                # Should contain automations/ directory
                template_root = temp_path
                automations_dir = template_root / "automations"

                if not automations_dir.exists():
                    log_error(
                        "Invalid repository template: automations/ directory not found"
                    )
                    return False

                log_ok(
                    f"Extracted repository template with {len(list(automations_dir.iterdir()))} automations"
                )
            else:
                # Single automation template: find streamline.yaml
                template_files = list(temp_path.rglob("streamline.yaml"))
                if not template_files:
                    log_error("Invalid template: streamline.yaml not found")
                    return False

                template_root = template_files[0].parent
                log_ok(
                    f"Extracted {len(list(template_root.rglob('*')))} template files"
                )

            if is_repo:
                # Repository template: extract as-is without modification
                print()
                log_step("Generating repository files...")

                files_created = 0
                for file_path in template_root.rglob("*"):
                    if file_path.is_file():
                        relative_path = file_path.relative_to(template_root)
                        target_file = target_dir / relative_path
                        target_file.parent.mkdir(parents=True, exist_ok=True)

                        # Copy file as-is
                        target_file.write_bytes(file_path.read_bytes())
                        files_created += 1
                        log_ok(f"Created: {relative_path}")

                print()
                log_ok("Repository initialized successfully!")
                log_info(f"Created {files_created} files in {target_dir}")

                # Ask if user wants to create GitHub repository
                print()
                create_github = (
                    input("Create GitHub repository? (Y/n): ").strip().lower()
                )

                # Default to yes if empty or 'y'
                if create_github in ["", "y", "yes"]:
                    github_repo_url = _setup_github_repository(target_dir, client)
                    if github_repo_url:
                        print()
                        log_ok("GitHub repository created and initialized!")
                        print(f"  Repository: {github_repo_url}")
                        print()

                print()
                print("Repository structure:")
                print(
                    "  - Multiple automation directories (automation-1/, automation-2/, etc.)"
                )
                print("  - Each automation has its own streamline.yaml")
                print("  - Shared resources in common/ directory")
                print()
                print("Next steps:")
                print("  1. Edit each automation's main.py with your logic")
                print("  2. Update each streamline.yaml with configuration")
                print("  3. Add shared dependencies to common/requirements.txt")
                if create_github in ["", "y", "yes"]:
                    print(
                        "  4. Push changes: git add . && git commit -m 'Update' && git push"
                    )
                else:
                    print("  4. Upload each automation individually or link to GitHub")
                print()
            else:
                # Single project template: interactive wizard
                print()
                log_step("Project Configuration")
                print()

                # Get automation ID
                automation_id = input(
                    "Automation ID (e.g., com.company.my-automation): "
                ).strip()
                if not automation_id:
                    log_error("Automation ID is required")
                    return False

                # Get automation name
                automation_name = input("Automation name: ").strip()
                if not automation_name:
                    automation_name = (
                        automation_id.split(".")[-1].replace("-", " ").title()
                    )
                    log_info(f"Using default name: {automation_name}")

                # Get description
                description = input("Description (optional): ").strip()
                if not description:
                    description = f"Streamline automation: {automation_name}"

                # Get entry point
                entry_point = input("Entry point [default: main.py]: ").strip()
                if not entry_point:
                    entry_point = "main.py"

                # Get return mode
                print("\nReturn mode:")
                print("  1. stream (real-time output)")
                print("  2. sync (wait for completion)")
                return_mode_choice = input("Select (1/2) [default: 1]: ").strip()
                return_mode = "sync" if return_mode_choice == "2" else "stream"

                print()
                log_step("Generating project files...")

                # Process and copy files
                files_created = 0
                for file_path in template_root.rglob("*"):
                    if file_path.is_file():
                        relative_path = file_path.relative_to(template_root)
                        target_file = target_dir / relative_path
                        target_file.parent.mkdir(parents=True, exist_ok=True)

                        # Read file content
                        content = file_path.read_text()

                        # Replace placeholders in streamline.yaml
                        if file_path.name == "streamline.yaml":
                            # Parse YAML
                            yaml_data = yaml.safe_load(content)

                            # Update fields
                            yaml_data["automation_id"] = automation_id
                            yaml_data["name"] = automation_name
                            yaml_data["description"] = description
                            yaml_data["entry_point"] = entry_point
                            yaml_data["return_mode"] = return_mode

                            # Write updated YAML
                            content = yaml.dump(
                                yaml_data, default_flow_style=False, sort_keys=False
                            )

                        # Write file
                        target_file.write_text(content)
                        files_created += 1
                        log_ok(f"Created: {relative_path}")

                print()
                log_ok("Project initialized successfully!")
                log_info(f"Created {files_created} files in {target_dir}")
                print()
                print("Next steps:")
                print("  1. Edit main.py with your automation logic")
                print("  2. Add dependencies to requirements.txt")
                print("  3. Update streamline.yaml with parameters")
                print("  4. Run 'aitronos streamline upload' to deploy")
                print()

            return True

    except AuthenticationError as e:
        log_error(f"Authentication failed: {str(e)}")
        print()
        print("Your session has expired or is invalid.")
        print("Please log in again:")
        print("  aitronos auth login")
        print()
        return False

    except AuthorizationError as e:
        log_error(f"Access denied: {str(e)}")
        print()
        print("You don't have permission to access this resource.")
        print("Please contact your administrator.")
        print()
        return False

    except Exception as e:
        log_error(f"Failed to initialize project: {str(e)}")
        import traceback

        traceback.print_exc()
        return False


def show_project_structure():
    """Display expected project structure."""
    structure = """
Streamline Project Structure:
├── config.freddy.json      # Automation configuration
├── requirements.txt        # Python dependencies
├── documentation.txt       # Usage documentation
├── resources/
│   └── parameters.json     # Parameter schema
└── src/
    └── main.py             # Entry point
"""
    print(structure)


def add_automation_to_repo(automation_name: Optional[str] = None):
    """
    Add a new automation to an existing repository.

    Must be run inside a repository directory (contains automations/ folder).

    Args:
        automation_name: Name of the automation (e.g., my-automation)
    """
    # Check if we're in a repository
    current_dir = Path.cwd()
    automations_dir = current_dir / "automations"

    if not automations_dir.exists() or not automations_dir.is_dir():
        log_error("Not in a Streamline repository")
        print()
        print("This command must be run inside a repository directory.")
        print("A repository contains an 'automations/' folder.")
        print()
        print("To create a repository:")
        print("  aitronos streamline repo init")
        print()
        return False

    # Prompt for automation name if not provided
    if automation_name is None:
        print()
        log_info("New automation name (lowercase with hyphens):")
        print("  Examples: my-automation, daily-report, data-processor")
        automation_name = input("  Name: ").strip()

    if not automation_name:
        log_error("Automation name is required")
        return False

    # Validate automation name
    if not automation_name.replace("-", "").replace("_", "").isalnum():
        log_error(
            "Invalid automation name. Use only letters, numbers, hyphens, and underscores."
        )
        return False

    # Check if automation already exists
    automation_dir = automations_dir / automation_name
    if automation_dir.exists():
        log_error(f"Automation '{automation_name}' already exists")
        return False

    # Create automation directory
    try:
        automation_dir.mkdir(parents=True, exist_ok=True)
        log_ok(f"Created directory: automations/{automation_name}")
    except Exception as e:
        log_error(f"Failed to create directory: {e}")
        return False

    # Interactive configuration
    print()
    log_step("Automation Configuration")
    print()

    # Get automation display name
    display_name = input(
        f"Display name [{automation_name.replace('-', ' ').title()}]: "
    ).strip()
    if not display_name:
        display_name = automation_name.replace("-", " ").title()

    # Get description
    description = input("Description: ").strip()
    if not description:
        description = f"Streamline automation: {display_name}"

    # Get entry point
    entry_point = input("Entry point [default: main.py]: ").strip()
    if not entry_point:
        entry_point = "main.py"

    # Get return mode
    print("\nReturn mode:")
    print("  1. stream (real-time output)")
    print("  2. complete (wait for completion)")
    return_mode_choice = input("Select (1/2) [default: 1]: ").strip()
    return_mode = "complete" if return_mode_choice == "2" else "stream"

    print()
    log_step("Generating automation files...")

    # Create streamline.yaml
    streamline_config = {
        "name": display_name,
        "description": description,
        "execution_file": entry_point,
        "execution_return_mode": return_mode,
        "parameters": {},
    }

    streamline_yaml_path = automation_dir / "streamline.yaml"
    with open(streamline_yaml_path, "w") as f:
        yaml.dump(streamline_config, f, default_flow_style=False, sort_keys=False)
    log_ok(f"Created: automations/{automation_name}/streamline.yaml")

    # Create main.py
    main_py_content = '''"""Main automation entry point."""

from typing import Any, Dict


def main(parameters: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Main automation function.
    
    Args:
        parameters: Dictionary of parameters passed to the automation
        
    Returns:
        Dictionary with status and results
    """
    if parameters is None:
        parameters = {}
    
    # Extract parameters with defaults
    # example_param = parameters.get("example_param", "default_value")
    
    # Your automation logic here
    print("Automation started...")
    
    # Example processing
    result = {
        "status": "success",
        "message": "Automation completed successfully",
        "data": {}
    }
    
    print("Automation completed!")
    
    return result


if __name__ == "__main__":
    # Test locally with sample parameters
    test_params = {}
    result = main(test_params)
    print(result)
'''

    main_py_path = automation_dir / entry_point
    main_py_path.write_text(main_py_content)
    log_ok(f"Created: automations/{automation_name}/{entry_point}")

    # Create requirements.txt
    requirements_content = """# Python dependencies for this automation
# Add your dependencies here, one per line
# Example:
# requests==2.31.0
# pandas==2.0.0
"""

    requirements_path = automation_dir / "requirements.txt"
    requirements_path.write_text(requirements_content)
    log_ok(f"Created: automations/{automation_name}/requirements.txt")

    print()
    log_ok(f"Automation '{automation_name}' created successfully!")
    print()
    print("Next steps:")
    print(f"  1. cd automations/{automation_name}")
    print(f"  2. Edit {entry_point} with your automation logic")
    print("  3. Add dependencies to requirements.txt")
    print("  4. Update streamline.yaml with parameters")
    print("  5. Test locally: python main.py")
    print("  6. Deploy: aitronos streamline upload")
    print()

    return True


def is_in_repository() -> bool:
    """Check if current directory is inside a Streamline repository."""
    current_dir = Path.cwd()
    automations_dir = current_dir / "automations"
    return automations_dir.exists() and automations_dir.is_dir()


def _setup_github_repository(target_dir: Path, client) -> Optional[str]:
    """
    Set up GitHub repository for the project.

    Args:
        target_dir: Project directory
        client: API client instance

    Returns:
        Repository URL if successful, None otherwise
    """
    import subprocess
    import webbrowser
    import time

    print()
    log_step("GitHub Repository Setup")
    print()

    # Get organization ID
    user_info = auth_manager.get_user_info()
    organization_id = user_info.get("organization_id")

    if not organization_id:
        log_error("Organization ID not found")
        return None

    # Check if GitHub is connected
    try:
        log_info("Checking GitHub connection...")
        status = client.check_github_connection(organization_id)

        if not status.get("connected"):
            log_info("GitHub account not connected")
            print()
            print(
                "To create a GitHub repository, you need to connect your GitHub account."
            )
            print(
                "This is a one-time setup that will open your browser for authorization."
            )
            print()

            connect = input("Connect GitHub now? (Y/n): ").strip().lower()
            if connect in ["n", "no"]:
                log_info("Skipping GitHub setup")
                return None

            # Initiate OAuth flow
            log_info("Initiating GitHub OAuth...")
            oauth_response = client.initiate_github_oauth(organization_id)
            auth_url = oauth_response["authorization_url"]

            print()
            log_info("Opening browser for GitHub authorization...")
            print(f"  URL: {auth_url}")
            print()
            print("If the browser doesn't open, copy and paste the URL above.")
            print()

            # Open browser
            webbrowser.open(auth_url)

            # Wait for user to complete OAuth
            print("Waiting for authorization...")
            print("(Press Ctrl+C to cancel)")
            print()

            # Poll for connection (simple approach - wait for user confirmation)
            input("Press Enter after you've authorized in the browser...")

            # Verify connection
            time.sleep(2)  # Give backend time to process callback
            status = client.check_github_connection(organization_id)

            if not status.get("connected"):
                log_error("GitHub connection failed")
                print()
                print("Please try again or connect GitHub via the web dashboard.")
                return None

            log_ok("GitHub connected successfully!")
            print()

    except Exception as e:
        log_error(f"Failed to check GitHub connection: {str(e)}")
        return None

    # Fetch GitHub user info and organizations
    try:
        from aitronos_cli.utils.colors import FG_CYAN, FG_GRAY, BOLD, RESET

        log_info("Fetching GitHub account information...")
        github_info = client.get_github_organizations(organization_id)
        user_info = github_info["user"]
        organizations = github_info["organizations"]

        print()
        log_ok(f"Connected as: {BOLD}{FG_CYAN}{user_info['login']}{RESET}")
        print()
    except Exception as e:
        log_error(f"Failed to fetch GitHub information: {str(e)}")
        return None

    # Choose repository owner (personal or organization)
    from aitronos_cli.utils.colors import FG_GREEN, FG_BLUE, FG_GRAY, RESET

    print("Repository owner:")
    print(
        f"  {FG_GREEN}1.{RESET} Personal account ({FG_CYAN}{user_info['login']}{RESET})"
    )

    if organizations:
        for idx, org in enumerate(organizations, start=2):
            org_desc = (
                f" {FG_GRAY}- {org['description']}{RESET}" if org["description"] else ""
            )
            print(
                f"  {FG_BLUE}{idx}.{RESET} Organization: {FG_CYAN}{org['login']}{RESET}{org_desc}"
            )

        max_choice = len(organizations) + 1
        owner_choice = input(f"Select (1-{max_choice}) [default: 1]: ").strip()
    else:
        print(f"  {FG_GRAY}(No organizations available){RESET}")
        owner_choice = input("Select (1) [default: 1]: ").strip()

    org_name = None
    if owner_choice and owner_choice != "1":
        try:
            choice_idx = int(owner_choice)
            if 2 <= choice_idx <= len(organizations) + 1:
                org_name = organizations[choice_idx - 2]["login"]
                print()
                log_info(f"Creating in organization: {FG_CYAN}{org_name}{RESET}")
            else:
                log_error(f"Invalid choice. Please select 1-{len(organizations) + 1}")
                return None
        except ValueError:
            log_error("Invalid input. Please enter a number.")
            return None

    print()

    # Get repository name (default to directory name)
    default_repo_name = target_dir.name
    repo_name = input(f"Repository name [{default_repo_name}]: ").strip()
    if not repo_name:
        repo_name = default_repo_name

    # Get description
    description = input("Repository description (optional): ").strip()
    if not description:
        description = f"Streamline automation repository: {repo_name}"

    # Get visibility
    print("\nRepository visibility:")
    print("  1. Private (recommended)")
    print("  2. Public")
    visibility_choice = input("Select (1/2) [default: 1]: ").strip()
    private = visibility_choice != "2"

    try:
        # Create repository via backend (uses stored OAuth token)
        log_info("Creating GitHub repository...")

        response = client.create_github_repository(
            repo_name=repo_name,
            organization_id=organization_id,
            description=description,
            private=private,
            org_name=org_name,
        )

        repo_url = response["repository_url"]
        html_url = response["html_url"]

        print()
        log_ok(f"Repository created: {html_url}")

        # Initialize git locally
        log_info("Initializing git repository...")

        subprocess.run(["git", "init"], cwd=target_dir, check=True, capture_output=True)
        subprocess.run(
            ["git", "add", "."], cwd=target_dir, check=True, capture_output=True
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit: Streamline repository template"],
            cwd=target_dir,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "branch", "-M", "main"],
            cwd=target_dir,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "remote", "add", "origin", repo_url],
            cwd=target_dir,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "push", "-u", "origin", "main"],
            cwd=target_dir,
            check=True,
            capture_output=True,
        )

        log_ok("Code pushed to GitHub")
        print()

        # Connect automations to Streamline with subdirectory support
        from aitronos_cli.utils.colors import log_warn

        log_info("Connecting automations to Streamline...")

        # Find all automation directories
        automations_dir = target_dir / "automations"
        if automations_dir.exists():
            automation_dirs = [
                d
                for d in automations_dir.iterdir()
                if d.is_dir() and (d / "streamline.yaml").exists()
            ]

            connected_count = 0
            for auto_dir in automation_dirs:
                automation_name = auto_dir.name
                try:
                    log_info(f"Uploading {automation_name}...")

                    # Upload with subdirectory path
                    upload_response = client.upload_automation_from_git(
                        git_url=repo_url,
                        branch="main",
                        automation_name=automation_name,
                        organization_id=organization_id,
                        subdirectory=f"automations/{automation_name}",
                    )

                    log_ok(
                        f"{automation_name} connected (ID: {upload_response.get('automation_id', 'N/A')})"
                    )
                    connected_count += 1

                except Exception as upload_err:
                    log_warn(f"Failed to connect {automation_name}: {str(upload_err)}")
                    # Continue with other automations

            if connected_count > 0:
                print()
                log_ok(f"Connected {connected_count} automation(s) to Streamline")
                print()
                print("Your automations are now synced with GitHub!")
                print("Future pushes will automatically update Streamline.")
            else:
                print()
                log_warn(
                    "No automations were connected. You can connect them manually later."
                )

        print()
        return html_url

    except Exception as e:
        import traceback
        import os
        from aitronos_cli.utils.colors import log_warn, FG_YELLOW, RESET
        from datetime import datetime

        error_details = str(e)
        is_duplicate = False

        # Try to extract more specific error message
        if hasattr(e, "response") and e.response is not None:
            try:
                error_json = e.response.json()
                if "error" in error_json:
                    error_details = error_json["error"].get("message", str(e))
                    system_message = error_json["error"].get("system_message")
                    if system_message:
                        error_details = f"{error_details} ({system_message})"

                    # Check for duplicate repository error
                    github_errors = (
                        error_json["error"].get("details", {}).get("github_errors", [])
                    )
                    for gh_error in github_errors:
                        if "already exists" in gh_error.get("message", "").lower():
                            is_duplicate = True
                            break
            except (ValueError, KeyError, AttributeError):
                # If JSON parsing fails, try to get text
                try:
                    error_details = e.response.text[:500]
                except (AttributeError, TypeError):
                    pass

        print()
        log_error(f"Failed to set up GitHub repository: {error_details}")

        # Show helpful message for duplicate repository
        if is_duplicate:
            print()
            log_warn(f"Repository '{repo_name}' already exists on GitHub")
            print()
            print(f"{FG_YELLOW}Suggestions:{RESET}")
            timestamp = datetime.now().strftime("%Y%m%d")
            print(f"  • Try a different name: {repo_name}-{timestamp}")
            print(f"  • Or use: {repo_name}-v2")
            print("  • Delete the existing repository on GitHub first")
            print()

            retry = (
                input("Would you like to try again with a different name? (Y/n): ")
                .strip()
                .lower()
            )
            if retry not in ["n", "no"]:
                # Recursive retry with new name
                return _setup_github_repository(target_dir, organization_id, client)

            return None

        # Show traceback in debug mode or dev environment
        show_debug = (
            "--debug" in sys.argv
            or os.getenv("DEBUG") == "1"
            or os.getenv("ENVIRONMENT") in ["development", "dev", "local"]
        )

        if show_debug:
            print()
            print("=" * 60)
            print("DEBUG TRACEBACK:")
            print("=" * 60)
            traceback.print_exc()
            print("=" * 60)

            # Also show response details if available
            if hasattr(e, "response") and e.response is not None:
                print()
                print("Response Status:", e.response.status_code)
                print("Response Headers:", dict(e.response.headers))
                try:
                    print("Response Body:", e.response.text[:1000])
                except (AttributeError, TypeError):
                    pass
                print("=" * 60)

        print()
        print("You can manually set up GitHub later:")
        print("  1. Create repository on GitHub")
        print(f"  2. cd {target_dir}")
        print("  3. git init")
        print("  4. git add .")
        print("  5. git commit -m 'Initial commit'")
        print("  6. git remote add origin <your-repo-url>")
        print("  7. git push -u origin main")
        print()
        return None
