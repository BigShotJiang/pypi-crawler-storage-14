"""Streamline automation management commands."""
