"""Aitronos CLI - Unified command line interface for Aitronos services."""

__version__ = "0.1.0"
