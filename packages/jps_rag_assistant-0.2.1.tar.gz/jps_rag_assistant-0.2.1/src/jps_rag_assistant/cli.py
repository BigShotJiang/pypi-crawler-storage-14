from __future__ import annotations

import logging
import os
from datetime import datetime
from pathlib import Path

import typer

from .config import Config
from .ingest import ingest_all
from .logging_helper import setup_logging

app = typer.Typer(name="jps-rag-ingest", help="JPS RAG Assistant – Ingest data into vector store")

DEFAULT_CONFIG_PATH = Path("~/.config/jps-rag-assistant/config.yaml").expanduser()


@app.command()
def main(
    config_file: Path = typer.Option(
        DEFAULT_CONFIG_PATH,
        "--config-file",
        help="Path to YAML configuration file",
    ),
    outdir: Path = typer.Option(
        None,
        "--outdir",
        help="Output directory (auto-generated if not provided)",
    ),
    logfile: Path = typer.Option(
        None,
        "--logfile",
        help="Log file path",
    ),
) -> None:
    if outdir is None:
        timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
        outdir = Path("/tmp") / os.getenv("USER", "user") / "ingest_all.py" / timestamp
    outdir.mkdir(parents=True, exist_ok=True)

    if logfile is None:
        logfile = outdir / "ingest_all.log"

    setup_logging(logfile)

    logging.info("Starting ingestion run")
    try:
        config = Config.load(config_file)
        ingest_all(config)
        logging.info("Ingestion completed successfully")
    except Exception:

        logging.exception("Ingestion failed")
        raise
    finally:
        abs_log = logfile.resolve()
        print(f"Wrote the log file to '{abs_log}'")


if __name__ == "__main__":
    app()
