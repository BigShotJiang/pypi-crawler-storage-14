from __future__ import annotations

from pathlib import Path
from typing import List

import yaml
from pydantic import BaseModel, Field


class OllamaConfig(BaseModel):
    # model: str = "llama3.1:70b"
    model: str = "llama3.1:8b"
    # embedding: str = "nomic-embed-text-v1.5"
    embedding: str = "nomic-embed-text"
    request_timeout: int = 300


class OutlookConfig(BaseModel):
    folder_names: List[str] = Field(default_factory=lambda: ["Inbox", "Sent Items"])
    days: int = 180


class JiraConfig(BaseModel):
    base_url: str
    email: str
    days: int = 90


class ConfluenceConfig(BaseModel):
    base_url: str
    space_keys: List[str] = Field(default_factory=list)


class VectorStoreConfig(BaseModel):
    show_progress: bool = True
    persist_dir: str = "~/.jps-rag-assistant"


class ChunkingConfig(BaseModel):
    chunk_size: int = 512
    chunk_overlap: int = 50


class Config(BaseModel):
    ollama: OllamaConfig = OllamaConfig()
    outlook: OutlookConfig = OutlookConfig()
    jira: JiraConfig
    confluence: ConfluenceConfig
    vector_store: VectorStoreConfig = VectorStoreConfig()
    chunking: ChunkingConfig = ChunkingConfig()

    @classmethod
    def load(cls, path: Path) -> "Config":
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with path.open() as f:
            data = yaml.safe_load(f) or {}

        return cls(**data)
