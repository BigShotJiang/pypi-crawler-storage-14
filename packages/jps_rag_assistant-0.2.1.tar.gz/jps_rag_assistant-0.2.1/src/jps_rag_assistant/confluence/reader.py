from __future__ import annotations

from typing import List

import keyring
from llama_index.core import Document
from llama_index.readers.confluence import ConfluenceReader


def retrieve_data(base_url: str, space_keys: List[str], email: str) -> List[Document]:
    """Load Confluence pages from specified spaces.

    Uses OAuth2 bearer token stored in keyring (service: "confluence", user: email).

    Args:
        base_url: Confluence base URL (e.g. https://your-co.atlassian.net/wiki)
        space_keys: List of space keys or ~username for personal space
        email: User email (used as keyring username)

    Returns:
        List of Document objects

    Raises:
        ValueError: If no OAuth2 token found in keyring
    """
    oauth2_token = keyring.get_password("confluence", email)
    if not oauth2_token:
        raise ValueError(f"No Confluence OAuth2 token found in keyring for {email}")

    reader = ConfluenceReader(
        confluence_base_url=base_url,
        oauth2_token=oauth2_token,
    )
    return reader.load_data(space_keys=space_keys)
