from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from jps_rag_assistant.cli import app

runner = CliRunner()


@pytest.mark.skip(reason="Skipping this test")
def test_cli_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "jps-rag-ingest" in result.stdout
    assert "--config-file" in result.stdout


def test_cli_default_config_path(sample_config: Path, monkeypatch):
    monkeypatch.setenv("HOME", str(sample_config.parent.parent))  # fake home
    monkeypatch.setattr("pathlib.Path.expanduser", lambda p: sample_config)

    result = runner.invoke(app)
    assert result.exit_code == 0
    # Should not crash — proves config loading works
    assert "Ingestion complete" in result.stdout or "No documents loaded" in result.stdout
