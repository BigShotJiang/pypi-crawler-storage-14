from __future__ import annotations

from pathlib import Path

from jps_rag_assistant.config import Config


def test_config_loads_successfully(sample_config: Path):
    config = Config.load(sample_config)
    assert config.ollama.model == "llama3.1:8b"
    assert config.jira.email == "test@example.com"
    assert config.vector_store.persist_dir == "/tmp/jps-rag-test-store"
    assert config.chunking.chunk_size == 512


def test_config_missing_file_raises(tmp_config_dir: Path):
    fake_path = tmp_config_dir / "nonexistent.yaml"
    from pytest import raises

    from jps_rag_assistant.config import Config

    with raises(FileNotFoundError):
        Config.load(fake_path)
