# supplychainlib/aws_sns.py

import boto3
from django.conf import settings

class SNSManager:
    def __init__(self):
        self.sns_client = boto3.client('sns', region_name=settings.AWS_REGION) # Create SNS client using boto3 and configuring to aws region

    def ensure_topic_and_subscription(self, customer_email):
        topic_name = f"customer-order-{customer_email.replace('@','-').replace('.','-')}" # Create SNS topic name from customer email
        topic_response = self.sns_client.create_topic(Name=topic_name) # crates topic if not there or return the existing topic
        topic_arn = topic_response["TopicArn"] # Stores the Topic ARN 

        # Subscribe the customer only if not subscribed
        subscribe = self.sns_client.list_subscriptions_by_topic(TopicArn=topic_arn) # list the subsciption for the topic 
        subscribed = any(subscribe["Endpoint"] == customer_email for sub in subscribe.get("Subscriptions", [])) # Check if the customer is already subscribed

        if not subscribed:
            self.sns_client.subscribe(
                TopicArn=topic_arn,
                Protocol="email",
                Endpoint=customer_email
            )
        return topic_arn

    def send_order_notification(self, customer_email, order_id, product_name, quantity, total_price):
        # Ensure topic & email subscription, then send order status notification to the customer
        
        topic_arn = self.ensure_topic_and_subscription(customer_email)
        subject = f"Order Update - {order_id}"
        message = f"""Dear Customer,
Your order status has changed!
Order Details:
Order ID: {order_id}
Product: {product_name}
Quantity: {quantity}
Total Price: ${total_price:.2f}
Customer Email: {customer_email}

Thank you for shopping with us,
Gourmet Coffee Supply Chain
"""
        # send SNS notification
        try:
            response = self.sns_client.publish(
                TopicArn=topic_arn,
                Subject=subject,
                Message=message
            ) 
            print(f"SNS notification sent successfully. MessageId: {response['MessageId']}")
            return True
        except Exception as e:
            print(f"Error sending SNS notification: {e}")
            return False
