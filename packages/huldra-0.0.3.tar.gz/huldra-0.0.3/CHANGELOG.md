# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

<!-- insertion marker -->
## [0.0.3](https://github.com/Okwizi/Huldra/releases/tag/0.0.3) - 2025-11-28

<small>[Compare with 0.0.2](https://github.com/Okwizi/Huldra/compare/0.0.2...0.0.3)</small>

### Features

- add release script ([96edcae](https://github.com/Okwizi/Huldra/commit/96edcae639604cafe8a8d645a35e43d7696a5c55) by Okwizi).
- add formatting, linting, and type checking ([f77478e](https://github.com/Okwizi/Huldra/commit/f77478ea8e1c77945d0653a89f0a5db19bd20c17) by Okwizi).

### Bug Fixes

- fix the release script and include changelog package ([06b4602](https://github.com/Okwizi/Huldra/commit/06b460254e71a387e1eaa0abd01aff10a0b61fda) by Okwizi).

### Chore

- Release 0.0.3 🚀 ([dce231e](https://github.com/Okwizi/Huldra/commit/dce231e88e21edd8fb3eeb1a29a803a654dbff6c) by Okwizi).
- setup github workflows for code quality and tests ([ea228c3](https://github.com/Okwizi/Huldra/commit/ea228c3cb9acf31dbc2e6d6ab053524c1e908cb6) by Okwizi).
- setup tests for huldra ([7da3804](https://github.com/Okwizi/Huldra/commit/7da3804915310c36d32f1ab7e86b9f6d300bbb56) by Okwizi).

### Tests

- add tests and cover the project to 100% ([4436604](https://github.com/Okwizi/Huldra/commit/4436604b2f72c8fa1cfe56d4336de67e22b90363) by Okwizi).

## [0.0.2](https://github.com/Okwizi/Huldra/releases/tag/0.0.2) - 2025-11-25

<small>[Compare with first commit](https://github.com/Okwizi/Huldra/compare/85b4bfa3647e92756ab1f86269f8acd52f017f6e...0.0.2)</small>

### Chore

- package huldra ([8ba2531](https://github.com/Okwizi/Huldra/commit/8ba2531ce79f693c39b83d68b38e3f6ab854c5c0) by Okwizi).
- layout and scaffold the project ([7f3ebc7](https://github.com/Okwizi/Huldra/commit/7f3ebc7c2c6be8b0d118df31559d85cdbe642ec6) by Okwizi).

