"""Huldra core.

This is the core module where the healing and LLM magic happens."""
