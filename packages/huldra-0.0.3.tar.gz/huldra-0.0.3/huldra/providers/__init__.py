"""Huldra providers.

These are the different languages providers."""
