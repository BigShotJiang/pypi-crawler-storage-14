"""Test the core module."""
