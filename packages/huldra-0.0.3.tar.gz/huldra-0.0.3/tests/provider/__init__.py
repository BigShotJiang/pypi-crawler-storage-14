"""Test the provider module."""
