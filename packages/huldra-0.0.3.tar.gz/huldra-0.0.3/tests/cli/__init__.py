"""Test CLI file."""
