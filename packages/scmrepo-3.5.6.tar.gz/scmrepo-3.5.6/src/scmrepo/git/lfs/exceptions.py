from scmrepo.exceptions import SCMError


class LFSError(SCMError):
    pass
