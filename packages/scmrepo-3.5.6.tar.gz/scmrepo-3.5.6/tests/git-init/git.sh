#!/bin/sh
apk add --no-cache git
