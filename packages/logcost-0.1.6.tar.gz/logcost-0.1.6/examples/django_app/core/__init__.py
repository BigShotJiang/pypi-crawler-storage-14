# Core app for Django example
