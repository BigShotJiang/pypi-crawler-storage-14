import pandas as pd
import sqlite3
import random
import os
from contextlib import contextmanager

# --- Configuration ---
DB_NAME = 'weather_hive.db'
TABLE_NAME = 'weather_data'
CSV_PATH = '/tmp/weather_data.csv'  # Using /tmp for Linux execution

# --- Setup Utilities ---

def generate_sample_data(num_records=1000):
    """
    Generates a DataFrame with random weather data and saves it to a CSV file,
    simulating data residing in HDFS.
    """
    years = list(range(1900, 2021))
    data = {
        'record_id': range(1, num_records + 1),
        'year': [random.choice(years) for _ in range(num_records)],
        'temperature_c': [random.uniform(-50, 50) for _ in range(num_records)]
    }
    df = pd.DataFrame(data)

    # Save to a local file, simulating HDFS storage
    df.to_csv(CSV_PATH, index=False)
    print(f"Sample data generated and saved to {CSV_PATH} (simulating HDFS file).")
    return CSV_PATH

@contextmanager
def sqlite_connection(db_name):
    """Context manager for managing SQLite connections."""
    conn = sqlite3.connect(db_name)
    try:
        yield conn
    finally:
        conn.close()

# --- Sqoop Simulation ---

def sqoop_like_import(csv_path, db_name, table_name):
    """
    Simulates a Sqoop import job: reads data from the file (HDFS) and loads it 
    into the SQLite table (Hive).
    """
    try:
        df = pd.read_csv(csv_path)
    except FileNotFoundError:
        print(f"Error: CSV file not found at {csv_path}. Cannot simulate import.")
        return

    print(f"Sqoop-like export: Read {len(df)} records from {csv_path} (HDFS).")

    with sqlite_connection(db_name) as conn:
        # Load the DataFrame into SQLite, simulating Hive table creation/insertion
        df.to_sql(table_name, conn, if_exists='replace', index=False)
        print(f"Sqoop-like import: Loaded data into {db_name}.{table_name} (Hive table).")

        # Create Index (Optional, but simulates a common post-import step in a data warehouse)
        conn.execute(f'CREATE INDEX IF NOT EXISTS idx_year ON {table_name}(year)')
        print(f"Index 'idx_year' created on {table_name}.year.")

# --- HiveQL Simulation (Reporting) ---

def generate_weather_report(db_name, table_name):
    """
    Simulates a HiveQL query running on the loaded data to compute yearly aggregates.
    """
    with sqlite_connection(db_name) as conn:
        query = f'''
            SELECT year,
                   MIN(temperature_c) AS min_temp_c,
                   MAX(temperature_c) AS max_temp_c
            FROM {table_name}
            GROUP BY year
            ORDER BY year
        '''
        report_df = pd.read_sql_query(query, conn)
        
        # Round the temperature columns for clean output
        report_df['min_temp_c'] = report_df['min_temp_c'].round(1)
        report_df['max_temp_c'] = report_df['max_temp_c'].round(1)
        
    return report_df

# --- Main Execution ---

if __name__ == "__main__":
    
    print("=== Simulating Sqoop Export/Import to Hive ===")
    
    # 1. Generate data (Source: Relational DB/HDFS)
    generate_sample_data(1000)
    
    # 2. Simulate Sqoop Import (Data transfer to Hive)
    sqoop_like_import(CSV_PATH, DB_NAME, TABLE_NAME)

    print("\nGenerating Weather Temperature Statistics Report...")
    
    # 3. Generate Report (Querying Hive)
    report = generate_weather_report(DB_NAME, TABLE_NAME)

    # 4. Print results
    print("\n=== Weather Report ===")
    print("Year\tMin Temp (°C)\tMax Temp (°C)")
    print("-" * 35)
    
    for _, row in report.iterrows():
        print(f"{int(row['year'])}\t{row['min_temp_c']}\t\t{row['max_temp_c']}")

    # 5. Print Sample Data
    print(f"\nSample data from {TABLE_NAME} (first 5 rows):")
    with sqlite_connection(DB_NAME) as conn:
        sample_data = pd.read_sql_query(f'SELECT * FROM {TABLE_NAME} LIMIT 5', conn)
        print(sample_data.to_string(index=False))

    # Optional cleanup of the generated CSV file
    if os.path.exists(CSV_PATH):
        os.remove(CSV_PATH)

# pip install pandas sqlalchemy
# (SqLite3 is included by default with standard Python installations.)

# Step 3: Execute the Python File
# Run the script using the Python interpreter:

# Bash

# python3 sqoop_simulation.py