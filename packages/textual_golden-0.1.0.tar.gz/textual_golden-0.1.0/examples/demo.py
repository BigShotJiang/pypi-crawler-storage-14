"""Demo showcasing the Golden widget."""
from textual.app import App, ComposeResult
from textual.containers import Center, Horizontal, Middle, Vertical
from textual.widgets import Static

from textual_golden import Golden, FIRE, GREEN


class DemoApp(App):
    CSS = """
    Screen {
        background: $surface;
    }

    #container {
        width: 60;
        height: auto;
        border: round $primary;
        padding: 2 4;
        background: $panel;
    }

    #title {
        text-align: center;
        text-style: bold;
        color: $text;
        margin-bottom: 1;
    }

    #status {
        text-align: center;
        margin-bottom: 2;
    }

    #delete-btn {
        width: auto;
        margin-top: 1;
        padding: 0 2;
        background: $error;
        border: tall $error-darken-2;
    }

    #delete-btn:hover {
        background: $error-darken-1;
    }

    #btn-container {
        width: 100%;
        align: center middle;
        height: auto;
    }
    """

    def compose(self) -> ComposeResult:
        with Middle():
            with Center():
                with Vertical(id="container"):
                    yield Static("Demo", id="title")
                    yield Golden("Cogitating furiously...", id="status")
                    # with Horizontal(id="btn-container"):
                    #     yield Golden("Delete", colors=FIRE, id="delete-btn")


if __name__ == "__main__":
    DemoApp().run()
