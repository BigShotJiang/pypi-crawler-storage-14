"""Quick test to see if animation works."""
from textual.app import App, ComposeResult
from textual_golden import Golden

class TestApp(App):
    def compose(self) -> ComposeResult:
        yield Golden("Testing animation...")

if __name__ == "__main__":
    TestApp().run()
