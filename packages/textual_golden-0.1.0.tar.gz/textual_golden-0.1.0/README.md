<img src="demo.gif" width="400">

# textual-golden

Animated golden text widget for [Textual](https://textual.textualize.io/).

## Installation

```bash
pip install textual-golden
```

## Usage

```python
from textual.app import App, ComposeResult
from textual_golden import Golden

class MyApp(App):
    def compose(self) -> ComposeResult:
        yield Golden("Loading...")

MyApp().run()
```

## Custom Colors

```python
from textual_golden import Golden, BLUE, FIRE

# Use preset color schemes
yield Golden("Processing...", colors=BLUE)
yield Golden("Warning!", colors=FIRE)

# Or define your own
from textual.color import Color
MY_COLORS = [Color(255, 0, 0), Color(255, 255, 255), Color(255, 0, 0)]
yield Golden("Custom!", colors=MY_COLORS)
```

## Presets

- `BLUE` - Cool blue shimmer
- `GREEN` - Nature green
- `PURPLE` - Royal purple
- `FIRE` - Red/orange fire effect
