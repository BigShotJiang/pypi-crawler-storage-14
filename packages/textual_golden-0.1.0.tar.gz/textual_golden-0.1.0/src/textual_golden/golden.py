"""Golden gradient animation widget."""

from textual.widgets import Static
from textual.color import Color


class Golden(Static):
    """A golden gradient widget with controllable speed."""

    COLORS = [
        Color(139, 90, 0),
        Color(184, 134, 11),
        Color(218, 165, 32),
        Color(255, 215, 0),
        Color(255, 235, 120),
        Color(255, 255, 200),
        Color(255, 255, 255),
        Color(255, 255, 200),
        Color(255, 235, 120),
        Color(255, 215, 0),
        Color(218, 165, 32),
        Color(184, 134, 11),
        Color(139, 90, 0),
    ]

    def __init__(
        self,
        text: str = "Thinking...",
        speed: float = 1.75,
        colors: list[Color] | None = None,
        **kwargs,
    ) -> None:
        self.wave_text = text
        self.base_speed = speed
        self.wave_position = 0.0
        self._colors = colors or self.COLORS
        initial_content = self._generate_colored_text()
        super().__init__(initial_content, **kwargs)

    def _generate_colored_text(self) -> str:
        """Generate the colored text for current wave position."""
        colored_text = ""

        for i, char in enumerate(self.wave_text):
            if char == " ":
                colored_text += " "
            else:
                # Interpolate between colors for smoother gradient
                color_pos = (i - self.wave_position / 2) % len(self._colors)
                color_index = int(color_pos)
                next_index = (color_index + 1) % len(self._colors)

                # Blend between two colors
                blend = color_pos - color_index
                color1 = self._colors[color_index]
                color2 = self._colors[next_index]

                r = int(color1.r + (color2.r - color1.r) * blend)
                g = int(color1.g + (color2.g - color1.g) * blend)
                b = int(color1.b + (color2.b - color1.b) * blend)

                # Calculate brightness
                brightness = (r + g + b) / 3

                # Make character bold when it's bright
                if brightness > 220:
                    colored_text += f"[bold rgb({r},{g},{b})]{char}[/]"
                else:
                    colored_text += f"[rgb({r},{g},{b})]{char}[/]"

        return colored_text.strip()

    def on_mount(self) -> None:
        """Start the animation."""
        self.set_interval(0.05, self._update_wave)

    def _update_wave(self) -> None:
        """Update the wave animation."""
        colored_text = self._generate_colored_text()
        self.update(colored_text)
        self.wave_position += self.base_speed


BLUE = [
    Color(70, 130, 180),
    Color(100, 149, 237),
    Color(135, 206, 250),
    Color(176, 224, 230),
    Color(200, 240, 255),
    Color(255, 255, 255),
    Color(200, 240, 255),
    Color(176, 224, 230),
    Color(135, 206, 250),
    Color(100, 149, 237),
    Color(70, 130, 180),
]

GREEN = [
    Color(34, 139, 34),
    Color(50, 205, 50),
    Color(144, 238, 144),
    Color(152, 251, 152),
    Color(200, 255, 200),
    Color(255, 255, 255),
    Color(200, 255, 200),
    Color(152, 251, 152),
    Color(144, 238, 144),
    Color(50, 205, 50),
    Color(34, 139, 34),
]

PURPLE = [
    Color(75, 0, 130),
    Color(138, 43, 226),
    Color(148, 103, 189),
    Color(186, 85, 211),
    Color(221, 160, 221),
    Color(255, 255, 255),
    Color(221, 160, 221),
    Color(186, 85, 211),
    Color(148, 103, 189),
    Color(138, 43, 226),
    Color(75, 0, 130),
]

FIRE = [
    Color(139, 0, 0),
    Color(178, 34, 34),
    Color(255, 69, 0),
    Color(255, 140, 0),
    Color(255, 215, 0),
    Color(255, 255, 100),
    Color(255, 215, 0),
    Color(255, 140, 0),
    Color(255, 69, 0),
    Color(178, 34, 34),
    Color(139, 0, 0),
]
