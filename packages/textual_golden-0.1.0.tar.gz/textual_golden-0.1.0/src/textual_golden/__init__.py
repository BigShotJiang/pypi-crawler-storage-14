"""Animated golden text widget for Textual."""

from .golden import Golden, BLUE, GREEN, PURPLE, FIRE

__version__ = "0.1.0"
__all__ = ["Golden", "BLUE", "GREEN", "PURPLE", "FIRE"]
