"""Marks this directory as a Python package for test discovery and imports."""
