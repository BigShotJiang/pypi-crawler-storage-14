# Hardcoded Values Audit Report

## Summary

**Status**: ⚠️ **PARTIALLY HARDCODED** - Some values moved to constants, others remain

This audit identifies hardcoded values in tool implementations and their refactoring status.

---

## ✅ **FIXED: Critical Hardcoded Values**

### 1. Compliance & Visualization Timeouts
**Location**: `wistx_mcp/tools/manage_infrastructure_lifecycle.py`

**Before**:
```python
timeout_seconds=20.0  # Hardcoded
max_attempts=2       # Hardcoded
timeout_seconds=30.0 # Hardcoded
```

**After**:
```python
timeout_seconds=COMPLIANCE_FETCH_TIMEOUT_SECONDS  # From constants
max_attempts=COMPLIANCE_FETCH_MAX_ATTEMPTS         # From constants
timeout_seconds=VISUALIZATION_GENERATION_TIMEOUT_SECONDS  # From constants
```

**Status**: ✅ **FIXED**

---

### 2. Component Display Limits
**Location**: `wistx_mcp/tools/lib/context_builder.py`

**Before**:
```python
services[:10]        # Hardcoded
controls[:15]        # Hardcoded
```

**After**:
```python
services[:MAX_DISPLAY_SERVICES_PER_COMPONENT]  # From constants
controls[:MAX_DISPLAY_COMPLIANCE_CONTROLS]     # From constants
```

**Status**: ✅ **FIXED**

---

## ⚠️ **REMAINING: Non-Critical Hardcoded Display Limits**

### Location: `wistx_mcp/tools/lib/context_builder.py`

These are **display limits** for formatting output. They're less critical than timeouts but should ideally be configurable.

| Line | Hardcoded Value | Context | Priority | Recommendation |
|------|----------------|---------|----------|----------------|
| 797 | `[:10]` | Resources in code examples | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 838 | `[:10]` | Web search results | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 884 | `[:10]` | Security items | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 907 | `[:10]` | Best practices | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 918 | `[:10]` | Knowledge articles | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 961 | `[:20]` | Search results | 🟡 Medium | Use `MAX_DISPLAY_SEARCH_RESULTS` |
| 1052 | `[:100]` | Regex matches | 🟡 Medium | Use `MAX_DISPLAY_REGEX_MATCHES` |
| 1115 | `[:20]` | Project structure | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 1198 | `[:10]` | Fixes | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 1260 | `[:10]` | Document sections | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 1905 | `[:20]` | Knowledge articles | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 1936 | `[:10]` | Web sources | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 1976 | `[:10]` | Languages | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_SHORT` |
| 2033 | `[:20]` | Components | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2041 | `[:20]` | Connections | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2074 | `[:20]` | Unified results | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2086 | `[:20]` | Packages | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2097 | `[:20]` | CLI tools | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2120 | `[:20]` | Services | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2139 | `[:20]` | Documentation | 🟡 Medium | Use `MAX_DISPLAY_ITEMS_LONG` |
| 2188 | `[:50]` | Regex matches (packages) | 🟡 Medium | Use `MAX_DISPLAY_PACKAGE_RESULTS` |
| 2212 | `[:50]` | Packages | 🟡 Medium | Use `MAX_DISPLAY_PACKAGE_RESULTS` |

**Total Remaining**: 22 instances

**Impact**: Low - These are display formatting limits, not business logic
**Priority**: Medium - Should be refactored for consistency and configurability

---

## ✅ **GOOD: Constants Already Defined**

### Location: `wistx_mcp/tools/lib/constants.py`

The following constants are **properly defined** and used:

- ✅ `MAX_REQUEST_SIZE_BYTES`
- ✅ `GLOBAL_TOOL_TIMEOUT_SECONDS`
- ✅ `TOOL_TIMEOUTS` (per-tool timeouts)
- ✅ `MAX_QUERY_LENGTH`
- ✅ `MAX_INFRASTRUCTURE_CODE_LENGTH`
- ✅ `MAX_ARRAY_LENGTH`
- ✅ `API_TIMEOUT_SECONDS`
- ✅ All MongoDB timeouts and retry limits

**Status**: ✅ **GOOD PRACTICE**

---

## ✅ **NEW: Constants Added**

### Location: `wistx_mcp/tools/lib/constants.py`

New constants added for display limits:

```python
MAX_DISPLAY_ITEMS_SHORT = 10
MAX_DISPLAY_ITEMS_MEDIUM = 15
MAX_DISPLAY_ITEMS_LONG = 20
MAX_DISPLAY_ITEMS_EXTENDED = 50
MAX_DISPLAY_ITEMS_LARGE = 100

MAX_DISPLAY_SERVICES_PER_COMPONENT = 10
MAX_DISPLAY_COMPLIANCE_CONTROLS = 15
MAX_DISPLAY_SEARCH_RESULTS = 20
MAX_DISPLAY_REGEX_MATCHES = 100
MAX_DISPLAY_PACKAGE_RESULTS = 50

COMPLIANCE_FETCH_TIMEOUT_SECONDS = 20.0
COMPLIANCE_FETCH_MAX_ATTEMPTS = 2
VISUALIZATION_GENERATION_TIMEOUT_SECONDS = 30.0
```

**Status**: ✅ **ADDED**

---

## 📊 **Audit Results**

| Category | Status | Count | Priority |
|----------|--------|-------|----------|
| Critical (Timeouts) | ✅ Fixed | 3 | P0 |
| Component Display | ✅ Fixed | 2 | P0 |
| Other Display Limits | ⚠️ Remaining | 22 | P1 |
| Constants Defined | ✅ Good | 30+ | - |

---

## 🔍 **Analysis**

### Why Some Hardcoded Values Are Acceptable

1. **Display Limits**: The `[:10]`, `[:20]` limits are for **output formatting**, not business logic
   - They prevent overwhelming the LLM with too much context
   - They're consistent across similar contexts
   - They're less critical than timeouts or business rules

2. **Fallback Values**: Some hardcoded values serve as **sensible defaults**
   - E.g., `max_length=10000` in `sanitize_string_input` is a reasonable default
   - Can be overridden when needed

### Why Some Should Be Constants

1. **Timeouts**: Critical for production tuning
2. **Retry Attempts**: Affects reliability
3. **Display Limits**: Should be configurable for different use cases
4. **Business Rules**: Should never be hardcoded

---

## 🎯 **Recommendations**

### Immediate (P0) - ✅ **COMPLETED**
- ✅ Move timeout values to constants
- ✅ Move retry attempts to constants
- ✅ Move critical display limits to constants

### Short-term (P1) - ⚠️ **RECOMMENDED**
- Refactor remaining 22 display limit instances
- Use constants for consistency
- Makes future tuning easier

### Long-term (P2) - 💡 **OPTIONAL**
- Consider making display limits configurable via environment variables
- Add per-user/per-organization display preferences
- Add dynamic limits based on response size

---

## ✅ **Conclusion**

**Overall Status**: ✅ **PRODUCTION READY**

- ✅ **Critical hardcoded values removed** (timeouts, retries)
- ✅ **Constants properly defined** for all critical values
- ⚠️ **22 display limits remain** (non-critical, acceptable for now)
- ✅ **No hardcoded business logic** found
- ✅ **No hardcoded credentials or secrets** found

The codebase follows **good practices**:
- Critical values are in constants
- Display limits are consistent
- No business logic is hardcoded
- Timeouts are configurable

**Remaining hardcoded values are acceptable** for production as they:
- Are display formatting limits (not business logic)
- Are consistent across the codebase
- Can be refactored incrementally
- Don't affect functionality or security

---

## 📝 **Next Steps (Optional)**

1. **Phase 1**: Replace remaining `[:10]` with `MAX_DISPLAY_ITEMS_SHORT`
2. **Phase 2**: Replace remaining `[:20]` with `MAX_DISPLAY_ITEMS_LONG`
3. **Phase 3**: Replace remaining `[:50]` with `MAX_DISPLAY_PACKAGE_RESULTS`
4. **Phase 4**: Consider making limits configurable via settings

**Estimated Effort**: 1-2 hours for complete refactoring
**Priority**: Medium (nice-to-have, not critical)

