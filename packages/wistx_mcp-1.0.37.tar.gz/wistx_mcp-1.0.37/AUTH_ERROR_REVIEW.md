# Authentication Error Review

## Summary

This document reviews all authentication errors found in `auth-error.json` and confirms API key expiration behavior.

## Error Analysis

### 1. Primary Authentication Errors

**Error Type**: `401 Unauthorized` - Invalid or Expired API Key

**Location**: Lines 25300-25343 in `auth-error.json`

**Error Details**:
```
httpx.HTTPStatusError: Client error '401 Unauthorized' for url 'http://localhost:8000/v1/users/me'
ValueError: Invalid or expired API key
```

**Root Cause**: The API key validation is failing when calling `/v1/users/me` endpoint. This indicates:
- The API key is either invalid (wrong key)
- The API key has been revoked
- The API key has expired (if expiration was set)
- The API key doesn't exist in the database

**Frequency**: Multiple occurrences throughout the log file, particularly around:
- 2025-11-30 21:17:07 - Multiple authentication failures
- Various timestamps showing repeated validation failures

### 2. Error Pattern Analysis

**Successful Authentications**:
- Many successful authentications logged for user `691b23b32069bb318a2ef7bb`
- Authentication method: `api_key`
- These occur throughout the log, indicating the system was working for some users

**Failed Authentications**:
- Error: "Invalid or expired API key"
- Error: "Invalid API key or authentication failed"
- Security events logged with severity: `HIGH`
- Event type: `auth_failure`
- Reason: `validation_failed`

### 3. Specific Error Messages

1. **"Invalid or expired API key"** (Line 25314, 25333)
   - Source: `wistx_mcp/tools/lib/api_client.py:884`
   - Triggered when HTTP 401 is returned from `/v1/users/me`

2. **"Invalid API key or authentication failed"** (Line 25336, 25339)
   - Source: `wistx_mcp/tools/lib/auth_context.py:118`
   - Wrapped error from API client validation

3. **"Failed to validate auth context"** (Line 25336, 25339)
   - Source: `wistx_mcp/server.py`
   - Occurs when AuthContext validation fails during tool execution

### 4. Error Flow

```
Tool Call Request
  ↓
get_auth_context() → Returns None or invalid context
  ↓
Attempt to validate API key
  ↓
WISTXAPIClient.get_current_user() → HTTP 401
  ↓
ValueError: "Invalid or expired API key"
  ↓
Security event logged (HIGH severity)
  ↓
MCPError raised to client
```

## API Key Expiration

### Default Behavior

**API Keys DO NOT expire by default.**

**Evidence from Code** (`api/auth/api_keys.py`):

1. **Creation** (Line 69):
   ```python
   expires_at: Optional[datetime] = None,
   ```
   - `expires_at` is optional
   - Default is `None` (no expiration)

2. **Storage** (Line 120):
   ```python
   "expires_at": expires_at,
   ```
   - Stored as provided (can be `None`)

3. **Verification** (Lines 208-210):
   ```python
   expires_at = api_key_doc.get("expires_at")
   if expires_at and expires_at < datetime.utcnow():
       return None
   ```
   - Only checks expiration if `expires_at` is set
   - If `expires_at` is `None`, key never expires

### When API Keys Expire

API keys only expire if:
1. **Explicit expiration set during creation**: When creating an API key via `/v1/auth/api-keys`, you can optionally provide an `expires_at` datetime
2. **Key is revoked**: Keys can be manually revoked, setting `revoked_at` timestamp
3. **Key is rotated**: Old keys enter a grace period, then expire after `grace_period_end`

### Expiration Check Logic

From `api/auth/api_keys.py` (Lines 205-214):

```python
if api_key_doc.get("revoked_at"):
    return None  # Revoked keys are invalid

expires_at = api_key_doc.get("expires_at")
if expires_at and expires_at < datetime.utcnow():
    return None  # Expired keys are invalid

grace_period_end = api_key_doc.get("grace_period_end")
if grace_period_end and datetime.utcnow() > grace_period_end:
    return None  # Grace period expired
```

**Key Points**:
- Expiration is checked in this order: revoked → expired → grace period
- If `expires_at` is `None`, the key never expires (unless revoked)
- Grace period applies to rotated keys (default: 24 hours)

## Confirmed Errors

### Error 1: 401 Unauthorized - Invalid API Key
- **Status**: Confirmed
- **Location**: Multiple occurrences in log
- **Cause**: API key validation failing at `/v1/users/me` endpoint
- **Impact**: Tools cannot execute, authentication fails

### Error 2: Authentication Context Missing
- **Status**: Confirmed (should be fixed by recent changes)
- **Location**: Tool execution flow
- **Cause**: No auth context found, API key not loaded from environment
- **Impact**: Tools fail with "Authentication required" error

### Error 3: API Key Validation Failure
- **Status**: Confirmed
- **Location**: `auth_context.py:109` and `api_client.py:884`
- **Cause**: HTTP 401 response from API
- **Impact**: User cannot authenticate

## Recommendations

### 1. For Users Experiencing "Invalid or Expired API Key" Errors

**Check**:
- Verify the API key is correct (no typos, complete key)
- Check if the key was revoked in the dashboard
- Verify the key wasn't rotated (check for grace period)
- Confirm the API key exists in the database

**Solution**:
- Generate a new API key if the current one is invalid
- Update Claude Desktop configuration with the new key
- Restart Claude Desktop to reload the configuration

### 2. For Developers

**Improvements Needed**:
1. **Better error messages**: Distinguish between:
   - Invalid key (wrong key)
   - Expired key (expiration date passed)
   - Revoked key (manually revoked)
   - Missing key (not found in database)

2. **Error logging**: Include more context in error messages:
   - Key prefix (first 16 chars) for identification
   - Expiration date (if set)
   - Revocation status

3. **API key validation endpoint**: Add a `/v1/auth/verify-key` endpoint to check key status without full authentication

## API Key Expiration Summary

| Aspect | Details |
|--------|---------|
| **Default Expiration** | None (keys don't expire by default) |
| **Optional Expiration** | Can be set during creation via `expires_at` parameter |
| **Expiration Check** | Only checked if `expires_at` is set |
| **Revocation** | Keys can be manually revoked (immediate expiration) |
| **Rotation** | Rotated keys have grace period (default: 24 hours) |
| **Expiration Behavior** | If `expires_at` is `None`, key never expires |

## Conclusion

1. **All errors confirmed**: The log shows consistent 401 Unauthorized errors indicating invalid/expired API keys
2. **API keys don't expire by default**: Only expire if explicitly set during creation
3. **Most likely cause**: The API key in Claude Desktop configuration is either:
   - Incorrect/typo
   - Revoked
   - Not found in database
   - Expired (if expiration was set)

**Next Steps**:
1. Verify the API key in Claude Desktop configuration matches a valid key in the database
2. Check if the key was revoked or expired
3. Generate a new API key if needed
4. Update Claude Desktop configuration and restart

