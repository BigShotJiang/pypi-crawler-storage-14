# Claude Desktop MCP Server Troubleshooting Guide

## Your Current Configuration

```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

## Common Issues and Solutions

### Issue 1: Package Not Installed via pipx

**Problem**: `pipx run wistx-mcp` requires the package to be installed in pipx.

**Solution**: Install the package first:

```bash
# Install wistx-mcp via pipx
pipx install /Users/clever/Desktop/wistx-model

# Or if you've built a wheel:
pipx install dist/wistx_mcp-*.whl
```

**Alternative**: Use `uv` instead of `pipx` (works without installation):

```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

### Issue 2: Config File Location

**Problem**: Claude Desktop might not be reading the config file from the expected location.

**Solution**: Verify the config file location:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

**Windows**: `%APPDATA%/Claude/claude_desktop_config.json`

**Check if file exists**:
```bash
# macOS
ls -la ~/Library/Application\ Support/Claude/claude_desktop_config.json

# Or check if Claude directory exists
ls -la ~/Library/Application\ Support/Claude/
```

### Issue 3: Claude Desktop Not Restarted

**Problem**: Claude Desktop needs a full restart to load MCP server configurations.

**Solution**:
1. **Quit Claude Desktop completely** (not just close the window)
   - macOS: `Cmd + Q` or right-click dock icon → Quit
   - Windows: Close all windows and check Task Manager
2. **Wait 5-10 seconds**
3. **Restart Claude Desktop**
4. **Check Settings → Connectors** for the MCP server

### Issue 4: JSON Syntax Errors

**Problem**: Invalid JSON syntax prevents Claude Desktop from loading the config.

**Solution**: Validate JSON syntax:

```bash
# macOS/Linux
python3 -m json.tool ~/Library/Application\ Support/Claude/claude_desktop_config.json

# Or use online JSON validator
```

**Common JSON errors**:
- Trailing commas
- Missing quotes
- Unclosed brackets

### Issue 5: pipx Not in PATH

**Problem**: Claude Desktop can't find `pipx` command.

**Solution**: Use full path to pipx:

```bash
# Find pipx location
which pipx
# Usually: ~/.local/bin/pipx or /usr/local/bin/pipx

# Update config with full path
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "/Users/clever/.local/bin/pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

### Issue 6: Package Name Mismatch

**Problem**: The package might not be installed with the exact name `wistx-mcp`.

**Solution**: Check installed packages:

```bash
pipx list
# Look for wistx-mcp in the list
```

If not installed, install it:
```bash
cd /Users/clever/Desktop/wistx-model
pipx install .
```

## Recommended Configuration (Using uv - Most Reliable)

Since you're already using `uv` in the project, this is the most reliable approach:

```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

**Advantages**:
- No need to install package separately
- Works directly from project directory
- Handles dependencies automatically
- More reliable than pipx for local development

## Step-by-Step Fix

1. **Verify config file location**:
   ```bash
   # macOS
   cat ~/Library/Application\ Support/Claude/claude_desktop_config.json
   ```

2. **Update config with uv (recommended)**:
   ```json
   {
     "mcpServers": {
       "wistx-mcp-server": {
         "command": "uv",
         "args": [
           "run",
           "--directory",
           "/Users/clever/Desktop/wistx-model",
           "python",
           "-m",
           "wistx_mcp.server"
         ],
         "env": {
           "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
           "WISTX_API_URL": "https://api.wistx.ai"
         }
       }
     }
   }
   ```

3. **Validate JSON**:
   ```bash
   python3 -m json.tool ~/Library/Application\ Support/Claude/claude_desktop_config.json
   ```

4. **Fully quit Claude Desktop**:
   - macOS: `Cmd + Q` or Activity Monitor → Force Quit
   - Wait 10 seconds

5. **Restart Claude Desktop**

6. **Check Settings → Connectors**:
   - Should see "wistx-mcp-server" or "mcp-server-wistx"
   - Status should show "Connected" or "Configured"

7. **Check Claude Desktop logs**:
   - macOS: `~/Library/Logs/Claude/`
   - Look for MCP server startup messages
   - Look for any error messages

## Alternative: Install via pipx First

If you prefer using pipx:

```bash
# Navigate to project directory
cd /Users/clever/Desktop/wistx-model

# Build the package
uv build

# Install via pipx
pipx install dist/wistx_mcp-*.whl

# Verify installation
pipx list | grep wistx
```

Then use your original config:
```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

## Debugging Steps

1. **Test the command manually**:
   ```bash
   # Test pipx command
   pipx run --no-cache wistx-mcp
   
   # Or test uv command
   cd /Users/clever/Desktop/wistx-model
   uv run python -m wistx_mcp.server
   ```

2. **Check Claude Desktop logs**:
   ```bash
   # macOS
   tail -f ~/Library/Logs/Claude/*.log
   ```

3. **Verify environment variables**:
   ```bash
   # Test if environment variables are accessible
   WISTX_API_KEY="wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af" \
   WISTX_API_URL="https://api.wistx.ai" \
   pipx run --no-cache wistx-mcp
   ```

## Expected Behavior

After successful configuration:

1. **In Claude Desktop Settings → Connectors**:
   - You should see "wistx-mcp-server" or similar
   - Status: "Connected" or "Configured"
   - May show "LOCAL DEV" tag

2. **In Claude Desktop Chat**:
   - Tools should be available when you ask questions
   - You can test with: "What are the PCI-DSS compliance requirements for RDS?"

3. **In Logs**:
   - MCP server should start successfully
   - No authentication errors
   - Tools should be registered

## Quick Fix Command

Run this to update your config with the recommended uv-based setup:

```bash
cat > ~/Library/Application\ Support/Claude/claude_desktop_config.json << 'EOF'
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
EOF
```

Then restart Claude Desktop completely.

