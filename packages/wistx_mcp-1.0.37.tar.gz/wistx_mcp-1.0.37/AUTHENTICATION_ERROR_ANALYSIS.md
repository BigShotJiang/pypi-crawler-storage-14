# Authentication Error Analysis

## Problem Summary

The MCP server is configured with `WISTX_API_KEY` in Claude Desktop's `claude_desktop_config.json`, but tools are failing with authentication errors when called. The error message indicates: "Authentication required. Provide API key via WISTX_API_KEY environment variable or MCP initialization."

## Root Cause Analysis

### 1. **Environment Variable Loading Issue**

**Location**: `wistx_mcp/config.py` and `wistx_mcp/server.py`

The MCP server configuration loads settings from environment variables using Pydantic Settings:

```62:66:wistx_mcp/config.py
    api_key: str = Field(
        default="",
        validation_alias="WISTX_API_KEY",
        description="WISTX API key for REST API calls (optional, required for API-dependent tools)",
    )
```

**Problem**: When Claude Desktop runs the MCP server via `pipx run --no-cache wistx-mcp`, the environment variables from `claude_desktop_config.json` are set in the `env` section, but:

1. The settings object is created during module import (line 136 in `config.py`)
2. The `reload_from_env()` method is called in `server.py` (line 86), but this happens AFTER the initial settings object is created
3. If the environment variable isn't available at import time, it defaults to an empty string

### 2. **AuthContext Initialization Failure**

**Location**: `wistx_mcp/server.py` lines 391-398

```391:398:wistx_mcp/server.py
    if AuthContext is not None:
        try:
            # Create auth context but don't validate yet - validation happens on first tool call
            auth_ctx = AuthContext(api_key=settings.api_key)
            set_auth_context(auth_ctx)
            logger.info("Authentication context initialized (validation deferred to first tool call)")
        except Exception as e:
            logger.warning("Failed to initialize auth context: %s", e)
```

**Problem**: 
- If `settings.api_key` is empty at this point, `AuthContext` is created with an empty API key
- The validation is deferred, so no error is raised during initialization
- When tools are called, they check for `auth_ctx` but it has no valid API key

### 3. **Initialization Options Not Properly Handled**

**Location**: `wistx_mcp/server.py` lines 437-486

```437:486:wistx_mcp/server.py
            init_options = params.get("initializationOptions", {}) or {}
            api_key = init_options.get("api_key") or settings.api_key
            
            api_url = init_options.get("api_url") or init_options.get("WISTX_API_URL")
            if api_url:
                object.__setattr__(settings, "api_url", api_url.rstrip("/"))
                logger.info("API URL set from initialization options: %s [request_id=%s]", api_url, request_id)
            elif not settings.api_url or settings.api_url == "https://api.wistx.ai":
                import os
                env_api_url = os.getenv("WISTX_API_URL")
                if env_api_url:
                    object.__setattr__(settings, "api_url", env_api_url.rstrip("/"))
                    logger.info("API URL set from environment variable: %s [request_id=%s]", env_api_url, request_id)
            
            openai_api_key = init_options.get("openai_api_key") or init_options.get("OPENAI_API_KEY")
            if openai_api_key:
                object.__setattr__(settings, "openai_api_key", openai_api_key)
                logger.info("OpenAI API key set from initialization options [request_id=%s]", request_id)
            elif not settings.openai_api_key:
                import os
                env_openai_key = os.getenv("OPENAI_API_KEY")
                if env_openai_key:
                    object.__setattr__(settings, "openai_api_key", env_openai_key)
                    logger.info("OpenAI API key set from environment variable [request_id=%s]", request_id)

            if api_key:
                if AuthContext is None:
                    logger.debug("API key provided but AuthContext not available (api.config dependency issue), skipping authentication")
                else:
                    try:
                        auth_ctx = AuthContext(api_key=api_key)
                        await auth_ctx.validate()
                        set_auth_context(auth_ctx)
                        logger.info(
                            "Authentication successful via initialization for user: %s [request_id=%s]",
                            auth_ctx.get_user_id(),
                            request_id,
                        )
                    except ValueError as e:
                        # Don't raise error during initialization - let tools validate API key when called
                        logger.warning("Failed to validate API key from initialization: %s [request_id=%s]", e, request_id)
                        logger.info("API key validation will be deferred to tool execution [request_id=%s]", request_id)
                    except (RuntimeError, ConnectionError) as e:
                        # Don't raise error during initialization - authentication service may be temporarily unavailable
                        logger.warning("Authentication service unavailable during initialization: %s [request_id=%s]", e, request_id)
                        logger.info("API key validation will be deferred to tool execution [request_id=%s]", request_id)
                    except Exception as e:
                        logger.warning("Unexpected error during authentication: %s [request_id=%s]", e, request_id)
                        logger.debug("Authentication error details: %s", e, exc_info=True)
                        logger.info("API key validation will be deferred to tool execution [request_id=%s]", request_id)
```

**Problem**:
- The code checks `init_options.get("api_key")` but Claude Desktop passes environment variables in the `env` section, not in `initializationOptions`
- The code doesn't check `os.getenv("WISTX_API_KEY")` during initialization like it does for `WISTX_API_URL` and `OPENAI_API_KEY`
- If the API key isn't in `init_options`, it falls back to `settings.api_key`, which may still be empty

### 4. **Tool Execution Authentication Check**

**Location**: `wistx_mcp/server.py` lines 2601-2614

```2601:2614:wistx_mcp/server.py
            existing_auth_ctx = get_auth_context()
            if not existing_auth_ctx:
                await security_logger.log_security_event(
                    event_type=SecurityEventType.AUTHENTICATION_FAILURE,
                    tool_name=name,
                    severity="HIGH",
                    details={"reason": "no_auth_context"},
                    alert=True,
                )
                raise MCPError(
                    code=MCPErrorCode.INVALID_REQUEST,
                    message="Authentication required. Provide API key via WISTX_API_KEY environment variable or MCP initialization.",
                    data={"request_id": request_id, "tool": name},
                )
```

**Problem**: 
- If `get_auth_context()` returns `None` (no auth context was set), the tool immediately fails
- The error message suggests using `WISTX_API_KEY` environment variable, but the variable might not be accessible to the MCP server process

## Specific Issues Identified

### Issue 1: Environment Variable Not Available at Import Time

**Root Cause**: When `pipx run` executes the MCP server, environment variables from Claude Desktop's config are set, but:
- The `settings` object is created during module import (before environment variables might be fully available)
- `reload_from_env()` is called, but if the variable isn't set yet, it remains empty

**Evidence**: The config defaults to empty string (`default=""`), and there's no validation that ensures the API key is actually loaded.

### Issue 2: Missing Environment Variable Check During Initialization

**Root Cause**: In the `on_initialize` handler, the code checks `init_options` and `settings.api_key`, but doesn't explicitly check `os.getenv("WISTX_API_KEY")` like it does for other variables.

**Evidence**: Compare lines 446-449 (checks `os.getenv("WISTX_API_URL")`) and lines 457-459 (checks `os.getenv("OPENAI_API_KEY")`) with the API key handling (lines 437-438), which only checks `init_options` and `settings.api_key`.

### Issue 3: AuthContext Created with Empty API Key

**Root Cause**: If `settings.api_key` is empty when `AuthContext` is created during server startup (line 394), it's created with an empty key. Validation is deferred, so no error is raised until a tool is called.

**Evidence**: The code at line 394 creates `AuthContext(api_key=settings.api_key)` without checking if the key is empty.

### Issue 4: No Fallback to Environment Variable in Tool Execution

**Root Cause**: When tools execute and find no auth context, they immediately fail. There's no attempt to check environment variables at that point.

**Evidence**: The tool execution code (lines 2601-2614) only checks for existing auth context and doesn't attempt to create one from environment variables.

## Recommended Fixes

### Fix 1: Check Environment Variable During Initialization

Add explicit check for `WISTX_API_KEY` environment variable in the `on_initialize` handler, similar to how `WISTX_API_URL` and `OPENAI_API_KEY` are handled:

```python
api_key = init_options.get("api_key") or settings.api_key
if not api_key:
    import os
    env_api_key = os.getenv("WISTX_API_KEY")
    if env_api_key:
        api_key = env_api_key
        object.__setattr__(settings, "api_key", env_api_key)
        logger.info("API key set from environment variable [request_id=%s]", request_id)
```

### Fix 2: Update Settings Object When API Key is Found

When the API key is found (from any source), update the settings object so it's available for subsequent operations:

```python
if api_key:
    object.__setattr__(settings, "api_key", api_key)
    # ... rest of authentication logic
```

### Fix 3: Add Fallback in Tool Execution

If no auth context exists when a tool is called, attempt to create one from environment variables or settings:

```python
existing_auth_ctx = get_auth_context()
if not existing_auth_ctx:
    # Try to create from environment or settings
    api_key = os.getenv("WISTX_API_KEY") or settings.api_key
    if api_key and AuthContext is not None:
        try:
            auth_ctx = AuthContext(api_key=api_key)
            await auth_ctx.validate()
            set_auth_context(auth_ctx)
            existing_auth_ctx = auth_ctx
        except Exception as e:
            logger.warning("Failed to create auth context from environment: %s", e)
    
    if not existing_auth_ctx:
        # ... existing error handling
```

### Fix 4: Improve Error Messages

Make error messages more specific about where to set the API key:

```python
message="Authentication required. Set WISTX_API_KEY in Claude Desktop MCP server configuration (env section) or provide via MCP initialization options."
```

## Testing Recommendations

1. **Test with environment variable in Claude Desktop config**: Verify that `WISTX_API_KEY` in the `env` section is properly loaded
2. **Test with initialization options**: Verify that API key passed via `initializationOptions` works
3. **Test error handling**: Verify that clear error messages are shown when API key is missing
4. **Test API key validation**: Verify that invalid API keys are properly rejected with clear error messages

## Additional Observations

1. **Claude Desktop Configuration**: The config shows `WISTX_API_KEY` is set in the `env` section, which should be available to the MCP server process
2. **API URL Handling**: The code successfully handles `WISTX_API_URL` from environment variables, suggesting the pattern should work for API keys too
3. **Deferred Validation**: The design defers API key validation to tool execution time, which is good for resilience but requires proper fallback handling

## Conclusion

The primary issue is that the API key from Claude Desktop's environment configuration is not being properly loaded and used during MCP server initialization. The fix requires:
1. Explicitly checking `os.getenv("WISTX_API_KEY")` during initialization
2. Updating the settings object when the API key is found
3. Adding fallback logic in tool execution to create auth context from environment variables if needed

