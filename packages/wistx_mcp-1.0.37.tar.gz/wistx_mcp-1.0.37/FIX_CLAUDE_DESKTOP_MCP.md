# Fix Claude Desktop MCP Server Not Showing

## Current Status

✅ **Config file exists and is valid JSON**
✅ **Package installed via pipx** (version 1.0.28)
✅ **pipx and uv are available**
✅ **Configuration syntax is correct**

## Most Likely Issues

### Issue 1: Claude Desktop Not Fully Restarted

**Solution**: 
1. **Completely quit Claude Desktop**:
   - Press `Cmd + Q` (not just close window)
   - Or: Right-click Claude Desktop in dock → Quit
   - Or: Activity Monitor → Force Quit Claude Desktop
2. **Wait 10 seconds**
3. **Restart Claude Desktop**
4. **Check Settings → Connectors**

### Issue 2: Server Name Mismatch

Claude Desktop might be looking for a different server name. Try these variations:

**Option A: Keep current name**
```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

**Option B: Use shorter name**
```json
{
  "mcpServers": {
    "wistx": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

**Option C: Use full pipx path**
```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "/opt/homebrew/bin/pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

### Issue 3: Use uv Instead (More Reliable)

Since you're in the project directory, using `uv` is more reliable:

```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

## Step-by-Step Fix

### Step 1: Update Config File

I'll create a script to update your config with the most reliable setup:

```bash
cat > ~/Library/Application\ Support/Claude/claude_desktop_config.json << 'EOF'
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
EOF
```

### Step 2: Validate JSON

```bash
python3 -m json.tool ~/Library/Application\ Support/Claude/claude_desktop_config.json
```

### Step 3: Fully Quit Claude Desktop

**IMPORTANT**: You must completely quit, not just close the window:

```bash
# Check if Claude Desktop is running
ps aux | grep -i claude | grep -v grep

# If running, quit it:
# Option 1: Use Activity Monitor
# Option 2: Use killall (be careful!)
killall "Claude" 2>/dev/null || echo "Claude Desktop not running"
```

### Step 4: Wait and Restart

1. Wait 10 seconds
2. Open Claude Desktop
3. Go to Settings → Connectors
4. Look for "wistx-mcp-server"

### Step 5: Check Logs

If it still doesn't appear, check Claude Desktop logs:

```bash
# View recent logs
tail -50 ~/Library/Logs/Claude/*.log | grep -i mcp

# Or view all logs
ls -la ~/Library/Logs/Claude/
```

## Alternative: Check Claude Desktop Version

Some versions of Claude Desktop have MCP support issues. Check your version:

1. Open Claude Desktop
2. Go to Settings → About
3. Note the version number

**Known Issues**:
- Some beta versions don't show MCP servers in UI
- MCP servers might work even if not visible in Settings

## Test if MCP Server is Actually Working

Even if it doesn't show in Settings, it might be working. Test it:

1. Open a new chat in Claude Desktop
2. Ask: "What are the PCI-DSS compliance requirements for RDS?"
3. If Claude uses WISTX tools, it's working (even if not visible in Settings)

## Quick Fix Script

Run this to update your config and test:

```bash
#!/bin/bash

# Backup current config
cp ~/Library/Application\ Support/Claude/claude_desktop_config.json \
   ~/Library/Application\ Support/Claude/claude_desktop_config.json.backup

# Update config with uv-based setup
cat > ~/Library/Application\ Support/Claude/claude_desktop_config.json << 'EOF'
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
EOF

# Validate JSON
echo "Validating JSON..."
python3 -m json.tool ~/Library/Application\ Support/Claude/claude_desktop_config.json > /dev/null && echo "✅ JSON is valid" || echo "❌ JSON is invalid"

# Test command
echo "Testing MCP server command..."
cd /Users/clever/Desktop/wistx-model
timeout 3 uv run python -m wistx_mcp.server 2>&1 | head -5 && echo "✅ Command works" || echo "⚠️  Command test (timeout expected)"

echo ""
echo "✅ Config updated!"
echo "📋 Next steps:"
echo "   1. Completely quit Claude Desktop (Cmd+Q)"
echo "   2. Wait 10 seconds"
echo "   3. Restart Claude Desktop"
echo "   4. Check Settings → Connectors"
```

