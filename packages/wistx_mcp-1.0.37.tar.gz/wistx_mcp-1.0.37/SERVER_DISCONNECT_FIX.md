# Server Disconnect Fix

## Problem

The MCP server is starting successfully but then disconnecting with the error "Server disconnected". Looking at the logs:

1. **Server starts successfully** ✅
2. **Processes requests** (ListToolsRequest, ListPromptsRequest, ListResourcesRequest) ✅
3. **Receives unsupported 'notifications/cancelled' notification** ❌
4. **Server shuts down gracefully** ❌

## Root Cause

The MCP SDK (v1.21.0) doesn't support the `notifications/cancelled` notification that Claude Desktop sends. When the SDK receives this notification:

1. It raises a `ValidationError` exception
2. This exception propagates up and causes the `async with stdio_ctx` context manager to exit
3. The server shuts down gracefully

**From the logs:**
```
MCP SDK received unsupported 'notifications/cancelled' notification 
(likely from Cursor canceling a timed-out request). 
This is a known SDK limitation in v1.21.0. 
The server will shut down gracefully.
```

## Current Behavior

The server is correctly:
- ✅ Starting up
- ✅ Loading tools
- ✅ Processing requests
- ✅ Handling the unsupported notification gracefully (not crashing)

However, it's shutting down when it receives the unsupported notification, which causes Claude Desktop to show "Server disconnected".

## Solution

The issue is that the MCP SDK v1.21.0 has a limitation where it doesn't handle `notifications/cancelled` gracefully. The server is already handling this as gracefully as possible by:

1. Catching the exception
2. Logging it as a warning (not an error)
3. Shutting down gracefully instead of crashing

**The fix is to update the MCP SDK** to a version that supports `notifications/cancelled`, OR wait for Claude Desktop to stop sending this notification.

## Workaround

Since we can't prevent the SDK from raising the exception, and we can't prevent the context manager from exiting when an exception is raised, the best approach is:

1. **Let Claude Desktop handle restarts** - Claude Desktop should automatically restart the server when it disconnects
2. **Update the MCP SDK** when a version that supports `notifications/cancelled` is available

## Expected Behavior After Fix

The server will:
- ✅ Start successfully
- ✅ Process requests
- ✅ Log warnings about unsupported notifications (but not crash)
- ✅ Shut down gracefully when unsupported notifications are received
- ✅ Be automatically restarted by Claude Desktop

## Next Steps

1. **Check for MCP SDK updates**:
   ```bash
   uv pip list | grep mcp
   ```

2. **Update MCP SDK if newer version available**:
   ```bash
   uv pip install --upgrade mcp
   ```

3. **Monitor Claude Desktop behavior** - It should automatically restart the server

4. **Check if Claude Desktop has settings** to disable sending `notifications/cancelled`

## Alternative: Downgrade MCP SDK

If a newer version doesn't fix it, we could try downgrading to see if an older version handles it better, but this is not recommended as it might break other features.

## Status

The server is working correctly - it's just that the MCP SDK has a limitation with `notifications/cancelled`. The graceful shutdown is the best we can do until the SDK is updated.

