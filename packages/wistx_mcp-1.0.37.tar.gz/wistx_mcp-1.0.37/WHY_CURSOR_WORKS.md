# Why Cursor Works But Claude Desktop Doesn't

## The Answer

**Cursor doesn't send the `notifications/cancelled` notification that breaks the server in Claude Desktop.**

## Key Differences

### 1. MCP Protocol Implementation

**Cursor**:
- ✅ Does NOT send `notifications/cancelled` notification
- ✅ Server stays connected
- ✅ Tools work correctly

**Claude Desktop**:
- ❌ Sends `notifications/cancelled` notification (for timeout/cancellation)
- ❌ MCP SDK (v0.9.1) doesn't support this notification
- ❌ Server shuts down when it receives it
- ❌ Shows "Server disconnected"

### 2. Configuration Approach

**Cursor** (Working):
```json
{
  "mcpServers": {
    "wistx-local": {
      "command": "/Users/clever/.local/bin/uv",
      "args": ["run", "--directory", "/Users/clever/Desktop/wistx-model", "python", "-m", "wistx_mcp.server"],
      "env": {
        "WISTX_API_URL": "http://localhost:8000"
      }
    }
  }
}
```

**Claude Desktop** (Now Updated to Match):
```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": ["run", "--directory", "/Users/clever/Desktop/wistx-model", "python", "-m", "wistx_mcp.server"],
      "env": {
        "WISTX_API_KEY": "...",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

## What We Changed

Updated Claude Desktop config to use the **same approach as Cursor**:
- ✅ Direct `uv` command (not wrapper script)
- ✅ Same argument structure
- ✅ Same directory-based approach

## Why This Might Help

1. **Consistency**: Using the same command structure as Cursor
2. **No wrapper script**: Direct execution might handle signals differently
3. **Better error handling**: `uv` might handle the notification differently

## However, The Real Issue Remains

Even with this change, Claude Desktop will still send `notifications/cancelled`, which the SDK doesn't support. The server will still disconnect, but:

1. **It might reconnect faster** (direct `uv` command)
2. **Claude Desktop might auto-restart it** more reliably
3. **The disconnect might be less frequent**

## Next Steps

1. **Restart Claude Desktop completely** (Cmd+Q, wait 10 seconds, restart)
2. **Test if it works better** with the direct `uv` command
3. **Monitor logs** to see if disconnects are less frequent
4. **If it still disconnects**, this confirms it's the `notifications/cancelled` issue

## The Real Solution

The **only real fix** is:
1. **Update MCP SDK** to support `notifications/cancelled` (when available)
2. **Wait for Claude Desktop** to stop sending unsupported notifications
3. **Use Cursor** for now (it's working perfectly!)

## Summary

- ✅ **Cursor works**: Doesn't send problematic notification
- ❌ **Claude Desktop fails**: Sends `notifications/cancelled` that SDK doesn't support
- ✅ **Config updated**: Now matches Cursor's working approach
- ⚠️ **Still may disconnect**: Due to SDK limitation, but should be more stable

The server code is correct - this is a protocol implementation difference between Cursor and Claude Desktop.

