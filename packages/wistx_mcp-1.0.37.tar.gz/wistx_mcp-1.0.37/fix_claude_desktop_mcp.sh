#!/bin/bash

set -e

echo "🔧 Fixing Claude Desktop MCP Configuration"
echo ""

CONFIG_FILE="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
BACKUP_FILE="$HOME/Library/Application Support/Claude/claude_desktop_config.json.backup"

echo "📋 Step 1: Backing up current config..."
if [ -f "$CONFIG_FILE" ]; then
    cp "$CONFIG_FILE" "$BACKUP_FILE"
    echo "✅ Backup created: $BACKUP_FILE"
else
    echo "⚠️  Config file not found, will create new one"
fi

echo ""
echo "📋 Step 2: Updating config with uv-based setup (most reliable)..."
cat > "$CONFIG_FILE" << 'EOF'
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
EOF

echo "✅ Config file updated"

echo ""
echo "📋 Step 3: Validating JSON syntax..."
if python3 -m json.tool "$CONFIG_FILE" > /dev/null 2>&1; then
    echo "✅ JSON is valid"
else
    echo "❌ JSON is invalid! Restoring backup..."
    cp "$BACKUP_FILE" "$CONFIG_FILE"
    exit 1
fi

echo ""
echo "📋 Step 4: Testing MCP server command..."
cd /Users/clever/Desktop/wistx-model
export WISTX_API_KEY="wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af"
export WISTX_API_URL="https://api.wistx.ai"

if uv run python -m wistx_mcp.server --help > /dev/null 2>&1 || \
   (uv run python -m wistx_mcp.server 2>&1 | head -3 | grep -q "Starting\|Server\|MCP" 2>/dev/null); then
    echo "✅ Command works (server started)"
else
    echo "⚠️  Command test inconclusive (this is OK - server might need stdin)"
fi

echo ""
echo "✅ Configuration updated successfully!"
echo ""
echo "📋 Next steps:"
echo "   1. Completely quit Claude Desktop:"
echo "      - Press Cmd+Q (not just close window)"
echo "      - Or: Right-click dock icon → Quit"
echo "      - Or: Activity Monitor → Force Quit"
echo ""
echo "   2. Wait 10 seconds"
echo ""
echo "   3. Restart Claude Desktop"
echo ""
echo "   4. Check Settings → Connectors for 'wistx-mcp-server'"
echo ""
echo "   5. If not visible, test in chat:"
echo "      Ask: 'What are the PCI-DSS compliance requirements for RDS?'"
echo "      (MCP might work even if not shown in Settings)"
echo ""
echo "📁 Config file location: $CONFIG_FILE"
echo "💾 Backup saved to: $BACKUP_FILE"

