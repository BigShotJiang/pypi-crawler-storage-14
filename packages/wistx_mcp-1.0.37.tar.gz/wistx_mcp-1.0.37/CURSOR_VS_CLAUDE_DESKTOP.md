# Why MCP Works in Cursor But Fails in Claude Desktop

## Key Observation

✅ **Cursor**: Server "wistx-local" is **active** with "20 tools, 3 resources enabled"  
❌ **Claude Desktop**: Server "wistx-mcp-server" shows as **"failed"** with "Server disconnected"

## Root Cause Analysis

### The Problem: `notifications/cancelled` Notification

From the logs, Claude Desktop is sending an unsupported `notifications/cancelled` notification that causes the server to shut down:

```
MCP SDK received unsupported 'notifications/cancelled' notification 
(likely from Claude Desktop canceling a timed-out request). 
This is a known SDK limitation in v1.21.0. 
The exception was caught during context manager exit. 
Claude Desktop should automatically restart the server.
```

### Why Cursor Works But Claude Desktop Doesn't

**Cursor**:
- ✅ Does NOT send `notifications/cancelled` notification (or handles it differently)
- ✅ Server stays connected
- ✅ Tools work correctly

**Claude Desktop**:
- ❌ Sends `notifications/cancelled` notification
- ❌ MCP SDK (v0.9.1) doesn't support this notification
- ❌ Server shuts down gracefully when it receives it
- ❌ Claude Desktop shows "Server disconnected"

## Configuration Differences

### Cursor Configuration (`.cursor-mcp.json`)
```json
{
  "mcpServers": {
    "wistx-local": {
      "command": "/Users/clever/.local/bin/uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_URL": "http://localhost:8000"
      }
    }
  }
}
```

### Claude Desktop Configuration (`claude_desktop_config.json`)
```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "/Users/clever/Desktop/wistx-model/run_mcp_server.sh",
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai",
        "PYTHONUNBUFFERED": "1"
      }
    }
  }
}
```

## Why This Happens

1. **Different MCP Protocol Implementations**:
   - Cursor and Claude Desktop implement MCP protocol differently
   - Claude Desktop sends `notifications/cancelled` for timeout/cancellation
   - Cursor might not send this notification or handles it at a different level

2. **MCP SDK Limitation**:
   - The MCP SDK (v0.9.1) doesn't support `notifications/cancelled`
   - When it receives this notification, it raises a `ValidationError`
   - This causes the server to shut down gracefully

3. **Auto-Restart Behavior**:
   - Cursor might auto-restart the server more reliably
   - Claude Desktop might not be auto-restarting, or it's restarting but immediately disconnecting again

## Solutions

### Option 1: Update MCP SDK (If Available)

Check if a newer SDK version supports `notifications/cancelled`:

```bash
cd /Users/clever/Desktop/wistx-model
uv pip install --upgrade mcp
```

**Current constraint**: `mcp>=0.9.1,<1.0.0` in `pyproject.toml`

### Option 2: Use Cursor's Configuration Approach

Try using the same configuration approach that works in Cursor:

```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

**Difference**: Direct `uv` command instead of wrapper script

### Option 3: Wait for Claude Desktop Update

Claude Desktop might update to:
- Stop sending `notifications/cancelled` for unsupported servers
- Handle the notification more gracefully
- Auto-restart servers more reliably

### Option 4: Report to MCP SDK Maintainers

This is a known SDK limitation. Report the issue to the MCP SDK maintainers so they can add support for `notifications/cancelled`.

## Current Status

- ✅ **Server code**: Working correctly
- ✅ **JSON parsing**: Fixed
- ✅ **Warning suppression**: Fixed
- ✅ **Cursor integration**: Working perfectly
- ❌ **Claude Desktop integration**: Failing due to SDK limitation with `notifications/cancelled`

## Recommendation

Since Cursor is working perfectly, you can:
1. **Use Cursor for development** (it's working!)
2. **Wait for MCP SDK update** that supports `notifications/cancelled`
3. **Try Option 2** above (use direct `uv` command like Cursor does)

The server code is correct - this is an external dependency limitation specific to how Claude Desktop implements the MCP protocol.

