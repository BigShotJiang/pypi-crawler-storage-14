# Auto-Restart Fix for Claude Desktop Disconnects

## Problem

Claude Desktop sends `notifications/cancelled` which causes the MCP server to shut down gracefully. Claude Desktop doesn't automatically restart the server, so it shows "Server disconnected".

## Solution: Auto-Restart Loop

I've implemented an **auto-restart loop** in the CLI that will automatically restart the server when it disconnects due to unsupported notifications.

### How It Works

1. **Server starts** normally
2. **If it disconnects** due to unsupported notification:
   - Wait 2 seconds
   - Automatically restart
   - Repeat up to 10 times
3. **If it exits normally** (not due to disconnect), it stops

### Features

- ✅ **Automatic restart** on disconnect (up to 10 attempts)
- ✅ **2-second delay** between restarts (prevents rapid restart loops)
- ✅ **Smart detection** - only restarts on disconnect errors, not other errors
- ✅ **Max retry limit** - stops after 10 attempts to prevent infinite loops
- ✅ **Graceful handling** - respects KeyboardInterrupt and normal exits

## What Changed

**File**: `wistx_mcp/server.py` - `cli()` function

The CLI now:
- Detects disconnect errors (BrokenResourceError, notifications/cancelled, etc.)
- Automatically restarts the server
- Logs restart attempts
- Stops after max retries

## Expected Behavior

1. **Server starts** ✅
2. **Claude Desktop sends unsupported notification** ⚠️
3. **Server disconnects gracefully** ✅
4. **Auto-restart kicks in** ✅
5. **Server restarts automatically** ✅
6. **Process repeats** until Claude Desktop stops sending the notification or max retries reached

## Testing

1. **Restart Claude Desktop completely** (Cmd+Q, wait 10 seconds, restart)
2. **Check Settings → Connectors** - server should show as connected
3. **Monitor logs** - you should see restart messages if disconnects occur:
   ```
   Server disconnected. Restarting in 2.0 seconds (attempt 1/10)...
   ```

## Limitations

- **Max 10 restarts** - if it keeps disconnecting, it will stop after 10 attempts
- **2-second delay** - there's a brief delay between restarts
- **Still depends on Claude Desktop** - if Claude Desktop keeps sending unsupported notifications, the server will keep restarting

## Alternative Solutions

If auto-restart doesn't work well:

1. **Update MCP SDK** when a version supporting `notifications/cancelled` is available
2. **Use Cursor** (it's working perfectly!)
3. **Wait for Claude Desktop update** that stops sending unsupported notifications

## Status

✅ **Auto-restart implemented** - server will automatically restart on disconnect
⚠️ **May still show "disconnected"** briefly during restart
✅ **Should be more stable** - server will keep trying to reconnect

The server will now automatically recover from disconnects caused by unsupported notifications!

