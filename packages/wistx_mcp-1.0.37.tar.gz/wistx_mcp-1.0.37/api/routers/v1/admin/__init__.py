"""Admin routers."""

