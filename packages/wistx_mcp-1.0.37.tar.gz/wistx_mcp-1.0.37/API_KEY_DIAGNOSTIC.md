# API Key Diagnostic Analysis

## Database Record Analysis

The API key record in the database shows:

```json
{
  "_id": "6924774efec47ee0fdeedf5c",
  "key_hash": "bd758e3b34475ae04dcc1f15620ca39373cdbd4ebcd45e458b14f8c0c5f50699",
  "key_prefix": "wistx_f1141b2c15",
  "user_id": "691b23b32069bb318a2ef7bb",
  "is_active": true,
  "expires_at": null,
  "revoked_at": null,
  "created_at": "2025-11-24T15:18:38.184Z"
}
```

**Status**: ✅ The key record is valid:
- `is_active: true` - Key is active
- `expires_at: null` - Key never expires
- `revoked_at: null` - Key is not revoked
- `usage_count: 0` - Key has never been used (interesting!)

## Root Cause Analysis

Since the database record is valid, the 401 error must be caused by one of these issues:

### Issue 1: API Key Hash Mismatch (Most Likely)

**Problem**: The API key being sent doesn't hash to the stored hash.

**Possible Causes**:
1. **API_KEY_PEPPER changed**: The pepper used to hash the key during creation is different from the pepper used during verification
2. **Key truncation**: The API key in Claude Desktop config might be truncated or incomplete
3. **Whitespace/encoding**: Extra spaces or encoding issues in the key

**Verification Steps**:
1. Check if `API_KEY_PEPPER` environment variable is the same as when the key was created
2. Verify the full API key matches (should start with `wistx_f1141b2c15...`)
3. Check for any whitespace or special characters

### Issue 2: User Document Missing

**Problem**: The user document for `user_id: "691b23b32069bb318a2ef7bb"` might not exist.

**Code Location**: `api/auth/api_keys.py:219-222`
```python
user_doc = db.users.find_one({"_id": api_key_doc["user_id"]})
if not user_doc:
    logger.warning("User not found for API key: %s", user_id)
    return None
```

**Verification**: Check if user document exists in database:
```javascript
db.users.findOne({_id: ObjectId("691b23b32069bb318a2ef7bb")})
```

### Issue 3: Database Connection Issue

**Problem**: MongoDB connection might be failing during verification.

**Verification**: Check MongoDB connection and logs.

## Diagnostic Steps

### Step 1: Verify API Key Hash

Create a test script to verify the hash matches:

```python
import hmac
import hashlib
import os

# Get the pepper from environment
pepper = os.getenv("API_KEY_PEPPER", "")

# The API key from Claude Desktop config (full key)
api_key = "wistx_f1141b2c152da1b1413cd365b760870c7728b65e21cc6db4f6424540057d46ea"

# Hash the key
key_hash = hmac.new(
    key=pepper.encode(),
    msg=api_key.encode(),
    digestmod=hashlib.sha256
).hexdigest()

print(f"Computed hash: {key_hash}")
print(f"Stored hash:   bd758e3b34475ae04dcc1f15620ca39373cdbd4ebcd45e458b14f8c0c5f50699")
print(f"Match: {key_hash == 'bd758e3b34475ae04dcc1f15620ca39373cdbd4ebcd45e458b14f8c0c5f50699'}")
```

### Step 2: Verify User Document Exists

Check MongoDB:
```javascript
// Connect to MongoDB
use wistx-production

// Check if user exists
db.users.findOne({_id: ObjectId("691b23b32069bb318a2ef7bb")})

// Check if user is active
db.users.findOne({
  _id: ObjectId("691b23b32069bb318a2ef7bb"),
  is_active: true
})
```

### Step 3: Check API Logs

Look for these log messages:
- `"User not found for API key: 691b23b32069bb318a2ef7bb"` - User document missing
- `"Failed to verify API key"` - Hash mismatch or other issue
- `"API key validation failed"` - General validation failure

### Step 4: Test API Key Directly

Test the API key with curl:
```bash
curl -X GET "http://localhost:8000/v1/users/me" \
  -H "Authorization: Bearer wistx_f1141b2c152da1b1413cd365b760870c7728b65e21cc6db4f6424540057d46ea"
```

## Most Likely Issue: API_KEY_PEPPER Mismatch

**Hypothesis**: The `API_KEY_PEPPER` environment variable used when creating the key is different from the one used during verification.

**Why this happens**:
- Key was created with one pepper value
- Server is running with a different pepper value
- Hash comparison fails even though the key is correct

**Solution**:
1. **Option A**: Use the same `API_KEY_PEPPER` that was used when creating the key
2. **Option B**: Create a new API key with the current pepper
3. **Option C**: Update the stored hash if you know the original key (not recommended for security)

## Recommended Fix

1. **Verify the pepper**: Check `API_KEY_PEPPER` in your `.env` file matches the one used when creating the key
2. **Check user document**: Verify user `691b23b32069bb318a2ef7bb` exists and is active
3. **Test hash**: Run the diagnostic script above to verify hash matches
4. **Create new key**: If pepper mismatch, create a new API key with current pepper

## Quick Fix: Create New API Key

If the pepper mismatch is confirmed, the quickest solution is to create a new API key:

1. Log in to the API dashboard
2. Go to API Keys section
3. Create a new API key
4. Update Claude Desktop configuration with the new key
5. Restart Claude Desktop

The new key will be hashed with the current pepper and should work correctly.

