# Authentication Error Analysis V2

## Summary

The new `auth-error.json` shows **significant progress** - API key authentication is now **working successfully**! However, there's a new issue with CSRF protection blocking API key-based requests.

## ✅ Good News: API Key Authentication Working

**Evidence**:
- Line 110: `"Authenticated user: 691b23b32069bb318a2ef7bb"` ✅
- Line 112: API key `wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af` is working
- Multiple successful 200 OK responses:
  - Line 129: `GET /v1/users/me HTTP/1.1" 200 OK`
  - Line 145: `GET /v1/indexing/resources HTTP/1.1" 200 OK`
  - Line 167: `GET /v1/users/me HTTP/1.1" 200 OK`

**Conclusion**: The authentication fixes we implemented are working! The API key is being properly loaded and validated.

## ❌ New Issue: CSRF Protection Blocking API Key Requests

### Error Details

**Location**: Line 184-496

**Error**:
```
CSRF validation failed: method=POST, path=/v1/knowledge/research, has_header=False, has_cookie=False
HTTPException: 403: CSRF token missing or invalid
```

**Root Cause**: The CSRF middleware is blocking POST requests that use API key authentication. The MCP server is making POST requests with `Authorization: Bearer <api_key>` headers, but CSRF middleware requires CSRF tokens (which are cookie-based and not applicable to API key requests).

### Why This Happens

1. **CSRF Protection Purpose**: CSRF protection is designed to prevent cross-site request forgery attacks in browser-based applications where cookies are automatically sent.

2. **API Key Authentication**: API key authentication uses `Authorization: Bearer <token>` headers, which are:
   - Not automatically sent by browsers
   - Not vulnerable to CSRF attacks
   - Used by programmatic clients (like MCP servers)

3. **Current Behavior**: The CSRF middleware (`api/middleware/csrf.py`) checks for CSRF tokens on all POST/PUT/PATCH/DELETE requests, regardless of authentication method.

### The Problem

**Code Location**: `api/middleware/csrf.py:64-145`

The CSRF middleware:
- Checks if request is a state-changing method (POST, PUT, PATCH, DELETE)
- Validates CSRF token from header and cookie
- **Does NOT check if request uses API key authentication**
- Blocks the request if CSRF token is missing

**Impact**:
- MCP server POST requests fail with 403 CSRF error
- API key-based clients cannot make POST requests
- Only cookie-based (browser) requests can make POST requests

## Recommended Fix

### Solution: Exempt API Key Requests from CSRF Protection

The CSRF middleware should skip validation for requests authenticated via API keys (Bearer tokens), since API keys are not vulnerable to CSRF attacks.

**Implementation**:

Add a check in `api/middleware/csrf.py` to detect API key authentication and skip CSRF validation:

```python
async def dispatch(self, request: Request, call_next: Callable) -> Response:
    # ... existing code ...
    
    # Skip CSRF validation for API key authenticated requests
    # API keys are not vulnerable to CSRF attacks (they use Authorization headers, not cookies)
    authorization = request.headers.get("authorization", "")
    if authorization and authorization.startswith("Bearer "):
        api_key_value = authorization.replace("Bearer ", "").strip()
        if api_key_value:
            # Check if it's a valid API key format (starts with wistx_)
            if api_key_value.startswith("wistx_") or len(api_key_value) > 20:
                logger.debug(
                    "Skipping CSRF validation for API key authenticated request: path=%s",
                    request.url.path,
                )
                return await call_next(request)
    
    # ... rest of CSRF validation ...
```

### Alternative: More Robust Check

A more robust approach would be to check if the request has valid API key authentication by checking `request.state.user_info` (set by AuthenticationMiddleware):

```python
# Skip CSRF validation if request is authenticated via API key
# (API keys are not vulnerable to CSRF since they use Authorization headers)
if hasattr(request.state, "user_info") and request.state.user_info:
    authorization = request.headers.get("authorization", "")
    if authorization and authorization.startswith("Bearer "):
        logger.debug(
            "Skipping CSRF validation for API key authenticated request: path=%s, user_id=%s",
            request.url.path,
            request.state.user_info.get("user_id"),
        )
        return await call_next(request)
```

## Secondary Issues

### 1. Invalid Webhook URL

**Location**: Line 190-191

**Error**:
```
Failed to connect to webhook URL https://your-webhook-url.com/alerts: [Errno 8] nodename nor servname provided, or not known
```

**Issue**: The webhook URL is a placeholder (`https://your-webhook-url.com/alerts`) that doesn't exist.

**Impact**: Non-critical - alerts are still stored in database, just webhook notifications fail.

**Fix**: Update webhook URL in configuration or disable webhook alerts if not needed.

## Summary of All Errors

### ✅ Resolved
1. **API Key Authentication** - Now working! ✅
   - API key `wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af` authenticates successfully
   - User `691b23b32069bb318a2ef7bb` is authenticated
   - GET requests work fine

### ❌ Current Issues
1. **CSRF Protection Blocking POST Requests** - **CRITICAL**
   - POST requests with API keys fail with 403 CSRF error
   - Affects: `/v1/knowledge/research` and other POST endpoints
   - **Fix Required**: Exempt API key requests from CSRF validation

2. **Invalid Webhook URL** - **LOW PRIORITY**
   - Placeholder webhook URL causes connection errors
   - Non-critical (alerts still stored in database)

## Action Items

1. **URGENT**: Update CSRF middleware to exempt API key authenticated requests
2. **OPTIONAL**: Update webhook URL configuration or disable webhook alerts
3. **VERIFY**: Test POST requests from MCP server after CSRF fix

## API Key Status

**Working API Key**: `wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af`
- **Status**: ✅ Valid and working
- **User**: `691b23b32069bb318a2ef7bb`
- **Authentication**: Successful
- **GET Requests**: ✅ Working
- **POST Requests**: ❌ Blocked by CSRF protection

**Previous API Key**: `wistx_f1141b2c15...` (from Claude Desktop config)
- **Status**: Unknown (not in this log)
- **Note**: The working key is different, suggesting either:
  - A new key was generated
  - The key in Claude Desktop config was updated

