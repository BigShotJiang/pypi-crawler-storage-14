# Complete JSON Parsing Error Fix

## Problem Analysis

From the MCP log (`~/Library/Logs/Claude/mcp.log`), the errors are:
- Lines 786-794, 863-871, 934-942: JSON parsing errors
- "Unexpected token 'W', "WeasyPrint"... is not valid JSON"
- "Unexpected token 'h', "https://do"... is not valid JSON"

**Root Cause**: Dependency warnings and import-time messages (like WeasyPrint warnings) are being printed to **stdout** during module imports, breaking the MCP JSON protocol which requires ONLY JSON on stdout.

## Complete Fix Applied

### 1. Global Warning Suppression (Lines 21-35)

Suppressed ALL warnings at module level:
```python
warnings.filterwarnings("ignore")
warnings.simplefilter("ignore")

# Suppress all warning categories
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=PendingDeprecationWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=ImportWarning)
warnings.filterwarnings("ignore", category=UnicodeWarning)
warnings.filterwarnings("ignore", category=BytesWarning)
warnings.filterwarnings("ignore", category=ResourceWarning)

os.environ["PYTHONWARNINGS"] = "ignore"
```

### 2. Early Logging Configuration (Lines 37-44)

Configure logging to stderr BEFORE any imports that might print:
```python
if not logging.getLogger().handlers:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(...))
    logging.getLogger().addHandler(handler)
    logging.getLogger().setLevel(logging.WARNING)
```

### 3. Stdout Suppression During Imports (Lines 88-120)

Created `_SuppressStdout` class and suppress stdout during critical imports:
```python
class _SuppressStdout:
    def write(self, s):
        pass
    def flush(self):
        pass

_suppress_stdout = _SuppressStdout()

# Suppress stdout during config import
sys.stdout = _suppress_stdout
try:
    from wistx_mcp.config import settings
finally:
    sys.stdout = _original_stdout

# Suppress stdout during auth_context import
sys.stdout = _suppress_stdout
try:
    from wistx_mcp.tools.lib.auth_context import ...
finally:
    sys.stdout = _original_stdout
```

### 4. Stdout Suppression During Tool Imports (Lines 300-330)

Suppress stdout during tool module imports in `main()`:
```python
sys.stdout = _suppress_stdout
try:
    from wistx_mcp.tools import mcp_tools
    mcp_tools_module = mcp_tools
finally:
    sys.stdout = _original_stdout
```

### 5. Removed traceback.print_exc() Calls

All `traceback.print_exc()` calls removed (already done in previous fix).

### 6. Wrapper Script with stderr Redirection

The `run_mcp_server.sh` wrapper redirects stderr to log files:
```bash
exec 2>> "$LOG_FILE"
uv run python -m wistx_mcp.server "$@"
```

## Expected Behavior After Fix

1. ✅ **No warnings printed to stdout** - All warnings suppressed globally
2. ✅ **No import-time messages to stdout** - Stdout suppressed during imports
3. ✅ **Only valid JSON on stdout** - MCP protocol requirements met
4. ✅ **All errors go to stderr/logs** - Proper error handling

## Testing

After restarting Claude Desktop, the JSON parsing errors should be gone. The server will:
- Start without printing warnings to stdout
- Only output valid JSON for MCP protocol
- Send all errors/warnings to stderr (captured in logs)

## Files Modified

1. `wistx_mcp/server.py`:
   - Added global warning suppression
   - Added stdout suppression during imports
   - Early logging configuration
   - Removed duplicate warnings import

2. `run_mcp_server.sh`:
   - Already configured to redirect stderr to logs

3. `~/Library/Application Support/Claude/claude_desktop_config.json`:
   - Already configured to use wrapper script

## Next Steps

1. **Restart Claude Desktop completely** (Cmd+Q, wait 10 seconds, restart)
2. **Check for JSON errors** - Should be gone
3. **Test MCP tools** - Should work without errors
4. **Check logs** if issues persist: `tail -f ~/Library/Logs/Claude/wistx-mcp/server-*.log`

