# MCP JSON Parsing Error Fix

## Problem

Claude Desktop was showing JSON parsing errors:
- "Unexpected end of JSON input"
- "No number after minus sign in JSON at position 1"
- "Unexpected token 'W', "WeasyPrint"... is not valid JSON"
- "Unexpected token 'h', "https://do"... is not valid JSON"

## Root Cause

The MCP server was outputting non-JSON content to stdout/stderr:
1. `traceback.print_exc()` was printing stack traces
2. Python warnings were being printed
3. Dependency import warnings (like WeasyPrint) were appearing
4. Error messages were leaking to stdout

**MCP Protocol Requirement**: Only valid JSON can be sent to stdout. Any other output breaks JSON parsing.

## Fixes Applied

### 1. Removed `traceback.print_exc()` Calls

**File**: `wistx_mcp/server.py`

Replaced all `traceback.print_exc()` calls with logger calls that use `exc_info=True`:
- Logger already captures exceptions via `exc_info=True`
- No need to print tracebacks that interfere with JSON protocol

**Changed**:
```python
# Before
except Exception as e:
    logger.error("Error: %s", e, exc_info=True)
    traceback.print_exc()  # ❌ Prints to stderr, breaks JSON

# After
except Exception as e:
    logger.error("Error: %s", e, exc_info=True)
    # ✅ Logger captures exception, no traceback.print_exc()
```

### 2. Suppressed Python Version Warnings

**File**: `wistx_mcp/server.py`

Suppressed warning output that was interfering with JSON:
- Warnings are now only logged via logger, not printed
- Prevents "WeasyPrint" and other dependency warnings from appearing

### 3. Created Wrapper Script with stderr Redirection

**File**: `run_mcp_server.sh`

Created a wrapper script that:
- Redirects stderr to a log file: `~/Library/Logs/Claude/wistx-mcp/server-*.log`
- Keeps stdout clean for MCP JSON protocol
- Ensures all error output goes to logs, not stdout

### 4. Updated Claude Desktop Config

**File**: `~/Library/Application Support/Claude/claude_desktop_config.json`

Updated to use the wrapper script:
```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "/Users/clever/Desktop/wistx-model/run_mcp_server.sh",
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai",
        "PYTHONUNBUFFERED": "1"
      }
    }
  }
}
```

## Verification

1. **Check logs** (if errors occur):
   ```bash
   tail -f ~/Library/Logs/Claude/wistx-mcp/server-*.log
   ```

2. **Test MCP server manually**:
   ```bash
   cd /Users/clever/Desktop/wistx-model
   ./run_mcp_server.sh
   ```

3. **Restart Claude Desktop**:
   - Completely quit (Cmd+Q)
   - Wait 10 seconds
   - Restart
   - Check Settings → Connectors

## Expected Behavior

After fixes:
- ✅ No JSON parsing errors in Claude Desktop
- ✅ MCP server appears in Settings → Connectors
- ✅ All error output goes to log files
- ✅ Only valid JSON on stdout (for MCP protocol)

## Files Modified

1. `wistx_mcp/server.py` - Removed traceback.print_exc(), suppressed warnings
2. `run_mcp_server.sh` - New wrapper script for stderr redirection
3. `~/Library/Application Support/Claude/claude_desktop_config.json` - Updated to use wrapper script

## Alternative: Direct uv Command (If Wrapper Doesn't Work)

If the wrapper script doesn't work, you can use the direct uv command (stderr will still go to Claude Desktop logs):

```json
{
  "mcpServers": {
    "wistx-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/Users/clever/Desktop/wistx-model",
        "python",
        "-m",
        "wistx_mcp.server"
      ],
      "env": {
        "WISTX_API_KEY": "wistx_4dbf9441e975d83d9538b2c529a14b7d0aa08eea97702d71030e13397e2395af",
        "WISTX_API_URL": "https://api.wistx.ai",
        "PYTHONUNBUFFERED": "1"
      }
    }
  }
}
```

The code fixes (removing traceback.print_exc() and suppressing warnings) should prevent most JSON parsing errors even with the direct command.

