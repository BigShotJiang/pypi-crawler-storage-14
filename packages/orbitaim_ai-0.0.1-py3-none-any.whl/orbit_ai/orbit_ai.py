import numpy as np


def hello_avneesh_function():
    return ("hello from avneesh!")
