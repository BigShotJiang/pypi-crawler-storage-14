from setuptools import setup, find_packages

setup(
    name="orbitaim_data",
    version="0.0.4",
    description="Google Discovery Engine search wrapper",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        "google-cloud-discoveryengine",
        "google-api-core",
        "protobuf",
        "grpcio",
    ],
    python_requires=">=3.9",
)
