# ssort/__init__.py

# Bubble Sort
def bubble(l):
    arr = l[:]  # copy list
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr

# Insertion Sort
def insertion(l):
    arr = l[:]
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j+1] = arr[j]
            j -= 1
        arr[j+1] = key
    return arr

# Selection Sort
def selection(l):
    arr = l[:]
    for i in range(len(arr)):
        min_idx = i
        for j in range(i+1, len(arr)):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr

# Merge Sort
def merge(l):
    if len(l) <= 1:
        return l
    mid = len(l) // 2
    left = merge(l[:mid])
    right = merge(l[mid:])
    return _merge_two(left, right)

def _merge_two(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

# Quick Sort
def quick(l):
    if len(l) <= 1:
        return l
    pivot = l[0]
    less = [x for x in l[1:] if x <= pivot]
    greater = [x for x in l[1:] if x > pivot]
    return quick(less) + [pivot] + quick(greater)

# Heap Sort
def heap(l):
    import heapq
    arr = l[:]
    heapq.heapify(arr)
    return [heapq.heappop(arr) for _ in range(len(arr))]
