## [2.0.1] - 2025-11-27

### Added
- Add classes

### Changed
- Merge pull request #1 from clearskies-py/di-fix by @tnijboer in [#1](https://github.com/clearskies-py/cortex/pull/1)
- Initial project setup

### Fixed
- Pass dependencies and build the tree by @cmancone

## New Contributors
* @tnijboer made their first contribution in [#1](https://github.com/clearskies-py/cortex/pull/1)
* @cmancone made their first contribution
* @ made their first contribution
