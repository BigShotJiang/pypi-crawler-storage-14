"""Django REST Framework MCP - Expose DRF APIs as MCP tools."""

__version__ = "0.1.0a4"
