This module allows printing the Picking Operations report in the
partner's or warehouse's language, configurable at the warehouse level.
