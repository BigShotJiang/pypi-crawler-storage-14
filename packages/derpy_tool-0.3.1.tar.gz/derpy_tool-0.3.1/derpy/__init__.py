"""
Derpy - A simple container tool, made with AI

A Python CLI application that provides essential container functionality
without relying on existing container runtimes like Docker, Podman, or containerd.
"""

__version__ = "0.3.1"
__author__ = "Adonis Cesar Legón Campo"
__email__ = "alegon@gmail.com"