"""Initialize the app"""

__version__ = "1.1.5"
__title__ = "Markettracker"
