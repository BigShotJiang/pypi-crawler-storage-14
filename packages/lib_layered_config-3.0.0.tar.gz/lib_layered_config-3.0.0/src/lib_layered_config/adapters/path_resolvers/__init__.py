"""Path resolver adapters for platform-specific search order."""
