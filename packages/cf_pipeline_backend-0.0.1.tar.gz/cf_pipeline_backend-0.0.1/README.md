# cf-pipeline-backend (stub)

Stub Python implementation of the mixed C++/Python pipeline backend described in `pipeline_backend/spec/PIPELINE_SPEC.md`.

This package exposes:

- `__backend_metadata__`
- `register_py_op`, `register_cpp_op` (bookkeeping only for C++ ops)
- `list_ops`, `describe_ops`
- `Pipeline` (executes Python ops; C++ ops raise `NotImplementedError`)
- `_register_op_capsule` (PyCapsule for future C++ plugin registration)

Resources bundled for validation/reference:
- Spec: `pipeline_backend/spec/PIPELINE_SPEC.md`
- Schemas: `pipeline_backend/spec/schemas/{pipeline_backend.schema.json,pipeline_plugin.schema.json}`
- Validator helper: `pipeline_backend.validator`

Example (uses cf_basic_signal, OPC UA virtual pH server):
```
pip install -e sand_toys/cf_basic_steps/cf_basic_signal
pip install -e sand_toys/cf-pipeline/cf-pipeline-backend
python sand_toys/cf-pipeline/cf-pipeline-backend/examples/run_opcua_fifo_avg_csv.py
```

Code lives in `src/pipeline_backend/`. This packaging layer enables tag-driven wheel builds and publishing to PyPI/TestPyPI.
