from pathlib import Path
from jsonargparse.typing import register_type

register_type(Path)
