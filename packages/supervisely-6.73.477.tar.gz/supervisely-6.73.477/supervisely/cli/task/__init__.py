from supervisely.cli.task.task_set import set_output_directory_run
