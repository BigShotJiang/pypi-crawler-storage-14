.. role:: hidden
    :class: hidden-section

gpytorch.settings
===================================

.. currentmodule:: gpytorch.settings

.. automodule:: gpytorch.settings
   :members:
