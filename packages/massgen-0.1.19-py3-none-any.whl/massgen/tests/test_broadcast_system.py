#!/usr/bin/env python
"""Unit tests for broadcast communication system."""

import asyncio
import pytest
from datetime import datetime
from unittest.mock import MagicMock, AsyncMock, patch

from massgen.broadcast.broadcast_dataclasses import (
    BroadcastRequest,
    BroadcastResponse,
    BroadcastStatus,
)
from massgen._broadcast_channel import BroadcastChannel
from massgen.agent_config import AgentConfig, CoordinationConfig
from massgen.backend.chat_completions import ChatCompletionsBackend
from massgen.chat_agent import SingleAgent
from massgen.orchestrator import Orchestrator


class TestBroadcastDataclasses:
    """Test broadcast data structures."""

    def test_broadcast_request_creation(self):
        """Test creating a broadcast request."""
        request = BroadcastRequest(
            id="test-123",
            sender_agent_id="agent_a",
            question="What is 2+2?",
            timestamp=datetime.now(),
            response_mode="inline",
        )

        assert request.id == "test-123"
        assert request.sender_agent_id == "agent_a"
        assert request.question == "What is 2+2?"
        assert request.response_mode == "inline"
        assert request.status == BroadcastStatus.PENDING

    def test_broadcast_request_to_dict(self):
        """Test serialization of broadcast request."""
        request = BroadcastRequest(
            id="test-123",
            sender_agent_id="agent_a",
            question="Test question",
            timestamp=datetime.now(),
            response_mode="inline",
        )

        data = request.to_dict()
        assert data["id"] == "test-123"
        assert data["sender_agent_id"] == "agent_a"
        assert data["question"] == "Test question"
        assert data["status"] == "pending"

    def test_broadcast_response_creation(self):
        """Test creating a broadcast response."""
        response = BroadcastResponse(
            request_id="test-123",
            responder_id="agent_b",
            content="The answer is 4",
            timestamp=datetime.now(),
            is_human=False,
        )

        assert response.request_id == "test-123"
        assert response.responder_id == "agent_b"
        assert response.content == "The answer is 4"
        assert response.is_human is False

    def test_human_broadcast_response(self):
        """Test creating a human broadcast response."""
        response = BroadcastResponse(
            request_id="test-123",
            responder_id="human",
            content="I think it's 4",
            timestamp=datetime.now(),
            is_human=True,
        )

        assert response.is_human is True
        assert response.responder_id == "human"


@pytest.mark.asyncio
class TestBroadcastChannel:
    """Test BroadcastChannel functionality."""

    async def test_create_broadcast(self):
        """Test creating a broadcast request."""
        # Create mock orchestrator
        orchestrator = MagicMock()
        orchestrator.agents = {"agent_a": MagicMock(), "agent_b": MagicMock()}
        orchestrator.config = AgentConfig.create_openai_config()
        orchestrator.config.coordination_config = CoordinationConfig(
            broadcast="agents",
            broadcast_timeout=300,
            max_broadcasts_per_agent=10,
        )

        channel = BroadcastChannel(orchestrator)

        request_id = await channel.create_broadcast(
            sender_agent_id="agent_a",
            question="What is 2+2?",
        )

        assert request_id in channel.active_broadcasts
        assert channel.active_broadcasts[request_id].question == "What is 2+2?"
        assert channel.active_broadcasts[request_id].sender_agent_id == "agent_a"

    async def test_rate_limiting(self):
        """Test broadcast rate limiting."""
        orchestrator = MagicMock()
        orchestrator.agents = {"agent_a": MagicMock(), "agent_b": MagicMock()}
        orchestrator.config = AgentConfig.create_openai_config()
        orchestrator.config.coordination_config = CoordinationConfig(
            broadcast="agents",
            max_broadcasts_per_agent=2,
        )

        channel = BroadcastChannel(orchestrator)

        # Create 2 broadcasts (at limit)
        await channel.create_broadcast("agent_a", "Question 1")
        await channel.create_broadcast("agent_a", "Question 2")

        # Third should fail
        with pytest.raises(ValueError, match="maximum number"):
            await channel.create_broadcast("agent_a", "Question 3")

    async def test_collect_response(self):
        """Test collecting broadcast responses."""
        orchestrator = MagicMock()
        orchestrator.agents = {"agent_a": MagicMock(), "agent_b": MagicMock()}
        orchestrator.config = AgentConfig.create_openai_config()
        orchestrator.config.coordination_config = CoordinationConfig(broadcast="agents")

        channel = BroadcastChannel(orchestrator)

        request_id = await channel.create_broadcast("agent_a", "Question")

        await channel.collect_response(
            request_id=request_id,
            responder_id="agent_b",
            content="Answer from agent_b",
        )

        responses = channel.broadcast_responses[request_id]
        assert len(responses) == 1
        assert responses[0].responder_id == "agent_b"
        assert responses[0].content == "Answer from agent_b"

    async def test_broadcast_status(self):
        """Test getting broadcast status."""
        orchestrator = MagicMock()
        orchestrator.agents = {"agent_a": MagicMock(), "agent_b": MagicMock(), "agent_c": MagicMock()}
        orchestrator.config = AgentConfig.create_openai_config()
        orchestrator.config.coordination_config = CoordinationConfig(broadcast="agents")

        channel = BroadcastChannel(orchestrator)

        request_id = await channel.create_broadcast("agent_a", "Question")

        # Initial status
        status = channel.get_broadcast_status(request_id)
        assert status["status"] == "pending"
        assert status["response_count"] == 0
        assert status["expected_count"] == 2  # agent_b and agent_c

        # After one response
        await channel.collect_response(request_id, "agent_b", "Answer")
        status = channel.get_broadcast_status(request_id)
        assert status["response_count"] == 1
        assert "agent_c" in status["waiting_for"]
        assert "agent_b" not in status["waiting_for"]

    async def test_broadcast_completion(self):
        """Test broadcast completion when all responses collected."""
        orchestrator = MagicMock()
        orchestrator.agents = {"agent_a": MagicMock(), "agent_b": MagicMock()}
        orchestrator.config = AgentConfig.create_openai_config()
        orchestrator.config.coordination_config = CoordinationConfig(broadcast="agents")

        channel = BroadcastChannel(orchestrator)

        request_id = await channel.create_broadcast("agent_a", "Question")

        # Collect response from agent_b (the only other agent)
        await channel.collect_response(request_id, "agent_b", "Answer")

        # Check completion
        broadcast = channel.active_broadcasts[request_id]
        assert broadcast.status == BroadcastStatus.COMPLETE
        assert channel.response_events[request_id].is_set()


@pytest.mark.asyncio
class TestAgentBroadcastHandling:
    """Test agent broadcast injection and handling."""

    async def test_inject_broadcast(self):
        """Test injecting broadcast into agent queue."""
        config = AgentConfig.create_openai_config()
        backend = ChatCompletionsBackend(config=config.backend_params)
        agent = SingleAgent(
            backend=backend,
            agent_id="agent_b",
            system_message="Test agent",
        )

        broadcast = BroadcastRequest(
            id="test-123",
            sender_agent_id="agent_a",
            question="What is 2+2?",
            timestamp=datetime.now(),
            response_mode="inline",
        )

        await agent.inject_broadcast(broadcast)

        # Check queue
        pending = await agent._check_broadcast_queue()
        assert pending is not None
        assert pending.id == "test-123"
        assert pending.question == "What is 2+2?"

    async def test_check_empty_broadcast_queue(self):
        """Test checking empty broadcast queue."""
        config = AgentConfig.create_openai_config()
        backend = ChatCompletionsBackend(config=config.backend_params)
        agent = SingleAgent(
            backend=backend,
            agent_id="agent_b",
            system_message="Test agent",
        )

        pending = await agent._check_broadcast_queue()
        assert pending is None


@pytest.mark.asyncio
class TestOrchestratorIntegration:
    """Test orchestrator integration with broadcast system."""

    async def test_orchestrator_initializes_broadcast_channel(self):
        """Test that orchestrator creates broadcast channel."""
        config = AgentConfig.create_openai_config()
        config.coordination_config = CoordinationConfig(broadcast="agents")

        agent_a = SingleAgent(
            backend=ChatCompletionsBackend(config=config.backend_params),
            agent_id="agent_a",
        )
        agent_b = SingleAgent(
            backend=ChatCompletionsBackend(config=config.backend_params),
            agent_id="agent_b",
        )

        orchestrator = Orchestrator(
            agents={"agent_a": agent_a, "agent_b": agent_b},
            config=config,
        )

        assert hasattr(orchestrator, "broadcast_channel")
        assert orchestrator.broadcast_channel is not None

    async def test_agents_have_orchestrator_reference(self):
        """Test that agents get orchestrator reference."""
        config = AgentConfig.create_openai_config()
        config.coordination_config = CoordinationConfig(broadcast="agents")

        agent_a = SingleAgent(
            backend=ChatCompletionsBackend(config=config.backend_params),
            agent_id="agent_a",
        )
        agent_b = SingleAgent(
            backend=ChatCompletionsBackend(config=config.backend_params),
            agent_id="agent_b",
        )

        orchestrator = Orchestrator(
            agents={"agent_a": agent_a, "agent_b": agent_b},
            config=config,
        )

        assert agent_a._orchestrator == orchestrator
        assert agent_b._orchestrator == orchestrator

    async def test_broadcast_tools_included_when_enabled(self):
        """Test that broadcast tools are included in workflow tools when enabled."""
        config = AgentConfig.create_openai_config()
        config.coordination_config = CoordinationConfig(broadcast="agents")

        agent_a = SingleAgent(
            backend=ChatCompletionsBackend(config=config.backend_params),
            agent_id="agent_a",
        )

        orchestrator = Orchestrator(
            agents={"agent_a": agent_a},
            config=config,
        )

        # Check workflow tools include broadcast tools
        tool_names = []
        for tool in orchestrator.workflow_tools:
            if "function" in tool:
                tool_names.append(tool["function"]["name"])
            elif "name" in tool:
                tool_names.append(tool["name"])

        assert "ask_others" in tool_names

    async def test_broadcast_tools_not_included_when_disabled(self):
        """Test that broadcast tools are NOT included when disabled."""
        config = AgentConfig.create_openai_config()
        config.coordination_config = CoordinationConfig(broadcast=False)

        agent_a = SingleAgent(
            backend=ChatCompletionsBackend(config=config.backend_params),
            agent_id="agent_a",
        )

        orchestrator = Orchestrator(
            agents={"agent_a": agent_a},
            config=config,
        )

        # Check workflow tools don't include broadcast tools
        tool_names = []
        for tool in orchestrator.workflow_tools:
            if "function" in tool:
                tool_names.append(tool["function"]["name"])
            elif "name" in tool:
                tool_names.append(tool["name"])

        assert "ask_others" not in tool_names


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
