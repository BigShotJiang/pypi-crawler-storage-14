# Security Policy

## Reporting a vulnerability

To report a security vulnerability, go to [the security tab](https://github.com/topgrade-rs/topgrade/security) and click "Report a vulnerability".

## Supported Versions

We only support the latest version of Topgrade. Fixes are not backported.
