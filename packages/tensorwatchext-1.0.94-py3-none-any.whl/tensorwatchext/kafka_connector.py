import time
import threading
import multiprocessing as mp
from queue import Empty
import random
import json
import pickle
from typing import Dict
from confluent_kafka import Consumer, KafkaError
from .watcher import Watcher
from probables import CountMinSketch
import logging

# Optional Parsers
try:
    import xmltodict
except ImportError:
    xmltodict = None

try:
    # import avro.schema
    # from avro.io import DatumReader, BinaryDecoder
    # import io
    from fastavro import schemaless_reader
    import io
except ImportError:
    print("⚠️ avro is not installed. Please run 'pip install fastavro'.")
    avro = None

try:
    from google.protobuf.json_format import MessageToDict
    protobuf_to_dict = lambda msg: MessageToDict(msg, preserving_proto_field_name=True)
except ImportError:
    print("⚠️ protobuf is not installed. Please run 'pip install protobuf'.")
    protobuf_to_dict = None


class kafka_connector:
    """
    A Kafka consumer that runs in a separate thread to consume messages from a Kafka topic.
    It supports various message formats and integrates with TensorWatch for real-time data visualization.
    """


    # Note: This class is no longer a thread. It manages child processes.
    def __init__(self, hosts="localhost:9092", topic=None, parsetype=None, queue_length=50000,
                 cluster_size=1, consumer_config=None, poll=1.0, auto_offset="earliest", group_id="mygroup", parser_extra=None,
                 decode="utf-8", schema_path=None, protobuf_message=None, random_sampling=None, countmin_width=None,
                 countmin_depth=None, twapi_instance=None, ordering_field=None, zmq_port=None):
        """
        Initializes the kafka_connector.

        Args:
            hosts (str): Comma-separated list of Kafka brokers.
            topic (str): The Kafka topic to consume from.
            parsetype (str): The format of the messages (e.g., "json", "pickle", "xml", "avro", "protobuf").
            queue_length (int): The maximum number of messages to store in the internal queue.
            cluster_size (int): The number of consumer threads to run.
            consumer_config (dict): A dictionary of Kafka consumer configuration settings.
            poll (float): The timeout for polling for new messages from Kafka.
            auto_offset (str): The offset reset policy.
            group_id (str): The consumer group ID.
            parser_extra (str): Extra information for the parser (e.g.avro_schema, Protobuf module).
            decode (str): The encoding to use for decoding messages.
            schema_path (str): The path to the Avro schema file.
            protobuf_message (str): The name of the Protobuf message class.
            random_sampling (int): The percentage of messages to sample (0-100).
            countmin_width (int): The width of the Count-Min Sketch.
            countmin_depth (int): The depth of the Count-Min Sketch.
            twapi_instance: An instance of the TensorWatch API for updating metrics.
            ordering_field (str): Optional message field to maintain global ordering.
            zmq_port (int): The port offset for the ZMQ watcher. If None, an automatic offset is assigned.
        """
        self.hosts = hosts or "localhost:9092"
        self.topic = topic
        self.cluster_size = cluster_size
        self.decode = decode
        self.parsetype = parsetype
        self.parser_extra = parser_extra
        self.protobuf_message = protobuf_message
        self.queue_length = queue_length
        # Queues for inter-process communication
        self.raw_message_queue = mp.Queue()
        self.parsed_message_queue = mp.Queue(maxsize=queue_length)
        self.data = self.parsed_message_queue # Maintain 'data' attribute for compatibility
        self.cms = {}
        self.countmin_width = countmin_width
        self.countmin_depth = countmin_depth
        self.random_sampling = random_sampling
        self.poll = poll
        self.consumer_config = consumer_config or {
            "bootstrap.servers": self.hosts,
            "group.id": group_id,
            "auto.offset.reset": auto_offset,
        }
        self._quit = mp.Event()
        self.size = 0
        self.zmq_port = zmq_port # Store port, but don't create watcher yet
        self.schema = None
        self.reader = None

        self.twapi_instance = None
        self.latencies = []
        self.received_count = 0
        self.last_report_time = time.time()
        self.first_message_sent = False

        # --- NEW: Optional ordering field ---
        self.ordering_field = ordering_field
        self.reordering_buffer = []

        # Parser resources will be initialized lazily inside each worker process
        # to avoid pickling errors.
        self.protobuf_class = None
        self.avro_schema = None

        self.processes = []
        self.main_thread = threading.Thread(target=self.run, args=(twapi_instance,), daemon=True)
        self.main_thread.start()


    def myparser(self, message):
        """
        Parses a message based on the specified format.

        Args:
            message: The message to parse.

        Returns:
            The parsed message, or None if parsing fails.
        """
        try:
            if self.parsetype is None or self.parsetype.lower() == "json":
                return json.loads(message.decode(self.decode))
            elif self.parsetype.lower() == "pickle":
                return pickle.loads(message)
            elif self.parsetype.lower() == "xml" and xmltodict:
                return xmltodict.parse(message.decode(self.decode))["root"]
            elif self.parsetype.lower() == "protobuf" and protobuf_to_dict:
                if self.protobuf_class:
                    try:
                        dynamic_message = self.protobuf_class() # message is already bytes
                        dynamic_message.ParseFromString(message)
                        return protobuf_to_dict(dynamic_message)
                    except Exception as e:
                        print(f"❌ Protobuf parsing error: {e}")
            elif self.parsetype.lower() == "avro" and avro:
                # decoder = BinaryDecoder(io.BytesIO(message))
                self._bytes_io.seek(0)
                self._bytes_io.truncate()
                self._bytes_io.write(message)
                self._bytes_io.seek(0)
                return schemaless_reader(self._bytes_io, self.avro_schema)
                # return self.reader.read(decoder)
        except Exception as e:
            logging.error(f"Parsing Error ({self.parsetype}): {e}")
            print(f"Parsing Error ({self.parsetype}): {e}")
        return None

    @staticmethod
    def _poll_loop(topic, consumer_config, poll_timeout, raw_message_queue, quit_event):
        """
        Static method to run in a separate process. It polls messages from Kafka.
        It only accepts pickle-able arguments.
        """
        logging.info(f"Starting Kafka polling process for topic '{topic}'")
        consumer = Consumer(consumer_config)
        consumer.subscribe([topic])

        while not quit_event.is_set():
            msg = consumer.poll(poll_timeout)
            if msg is None:
                continue
            if msg.error():
                if msg.error().code() != KafkaError._PARTITION_EOF:
                    logging.error(f"Kafka Error: {msg.error()}")
                continue

            raw_message_queue.put(msg.value())

        consumer.close()
        logging.info("Polling process stopped")

    @staticmethod
    def _worker_loop(raw_message_queue, parsed_message_queue, quit_event, worker_config):
        """
        Static method to run in a separate process. It parses raw messages.
        It only accepts pickle-able arguments.
        """
        logging.info("Starting worker process")

        # Create a temporary 'self' like object for the parser methods to use
        class ParserContext:
            pass
        
        parser_context = ParserContext()
        parser_context.parsetype = worker_config.get('parsetype')
        parser_context.decode = worker_config.get('decode')
        parser_context.parser_extra = worker_config.get('parser_extra')
        parser_context.protobuf_message = worker_config.get('protobuf_message')
        parser_context.myparser = kafka_connector.myparser.__get__(parser_context, ParserContext)

        # Lazy-initialize parsers inside the worker process to avoid pickling issues.
        if parser_context.parsetype:
            if parser_context.parsetype.lower() == "avro" and avro:
                try:
                    import fastavro
                    if isinstance(parser_context.parser_extra, str):
                        parser_context.avro_schema = json.loads(parser_context.parser_extra)
                    elif isinstance(parser_context.parser_extra, dict):
                        parser_context.avro_schema = parser_context.parser_extra
                    parser_context._bytes_io = io.BytesIO()
                except Exception as e:
                    logging.error(f"Worker Avro Schema Error: {e}, Avro may not work")
            elif parser_context.parsetype.lower() == "protobuf" and protobuf_to_dict:
                try:
                    import importlib
                    module = importlib.import_module(parser_context.parser_extra)
                    parser_context.protobuf_class = getattr(module, parser_context.protobuf_message)
                except Exception as e:
                    logging.error(f"Worker Protobuf Import Error: {e}")

        # This is a simplified version of process_message, focusing only on parsing
        # and queueing. Latency, CMS, etc., are handled by the consumer of the queue.
        def _process_and_queue(raw_message):
            parsed_message = parser_context.myparser(raw_message)
            if parsed_message:
                # Add receive_time here to measure latency from parsing to consumption
                if isinstance(parsed_message, dict):
                    parsed_message['receive_time'] = time.time()

                if not parsed_message_queue.full():
                    parsed_message_queue.put(parsed_message, block=False)
                else:
                    _ = parsed_message_queue.get_nowait() # Drop oldest
                    parsed_message_queue.put(parsed_message, block=False)

        while not quit_event.is_set():
            try:
                raw_message = raw_message_queue.get(timeout=1)
                if raw_message is None: # Sentinel value to exit
                    break
                
                _process_and_queue(raw_message)
            except Empty:
                continue
        logging.info("Worker process stopped")

    def run(self, twapi_instance):
        """
        Starts the polling and worker processes, and then enters the main loop
        to observe the parsed data queue for visualization.
        """
        logging.info(f"Starting {self.cluster_size} worker processes and 1 polling process.")
        
        poll_args = (self.topic, self.consumer_config, self.poll, self.raw_message_queue, self._quit)
        poll_process = mp.Process(target=kafka_connector._poll_loop, args=poll_args, daemon=True)
        self.processes.append(poll_process)
        poll_process.start()

        # Start the worker processes
        for _ in range(self.cluster_size):
            worker_config = {
                'parsetype': self.parsetype,
                'decode': self.decode,
                'parser_extra': self.parser_extra,
                'protobuf_message': self.protobuf_message,
            }
            worker_args = (self.raw_message_queue, self.parsed_message_queue, self._quit, worker_config)
            worker_process = mp.Process(target=kafka_connector._worker_loop, args=worker_args, daemon=True)
            self.processes.append(worker_process)
            worker_process.start()

        # Lazy-initialize the watcher in the main thread, AFTER forking child processes.
        self.watcher = Watcher(port=self.zmq_port)
        self.twapi_instance = twapi_instance

        # The main thread no longer needs a loop. It just starts the background processes.
        # The twapi class is now responsible for consuming the parsed_message_queue.
        pass

    def quit(self):
        """Stops the consumer processes."""
        logging.info("Shutting down kafka_connector...")
        self._quit.set()
        # Send sentinel values to workers to ensure they exit the queue.get()
        for _ in range(self.cluster_size):
            self.raw_message_queue.put(None)

        for p in self.processes:
            p.join(timeout=5)
        logging.info("All processes stopped.")
