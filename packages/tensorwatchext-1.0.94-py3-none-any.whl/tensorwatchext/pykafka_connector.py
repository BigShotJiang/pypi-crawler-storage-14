from pykafka import KafkaClient
from pykafka.common import OffsetType
from .watcher import Watcher
import multiprocessing as mp
from queue import Empty
import json
import pickle
import time
import random
import logging
import io

# Optional Parsers
try:
    import xmltodict
except ImportError:
    xmltodict = None

try:
    # import avro.schema
    # from avro.io import DatumReader, BinaryDecoder
    from fastavro import schemaless_reader
    import io
except ImportError:
    avro = None

try:
    from protobuf_to_dict import protobuf_to_dict
except ImportError:
    protobuf_to_dict = None

from probables import CountMinSketch

class pykafka_connector:
    """
    A Kafka consumer that uses the pykafka library to consume messages from a Kafka topic.
    It runs in a separate thread and supports various message formats.
    """


    # Note: This class is no longer a thread. It manages child processes.
    def __init__(self, hosts: str = "localhost:9092", topic: str = None, parsetype: str = None, queue_length: int = 50000, cluster_size: int = 1,
                 consumer_group: bytes = b'default', auto_offset_reset: OffsetType = OffsetType.EARLIEST,
                 fetch_message_max_bytes: int = 1024 * 1024, num_consumer_fetchers: int = 1,
                 auto_commit_enable: bool = False, auto_commit_interval_ms: int = 1000,
                 queued_max_messages: int = 2000, fetch_min_bytes: int = 1,
                 consumer_timeout_ms: int = -1, decode: str = "utf-8",
                 consumer_start_timeout_ms: int = 5000, schema_path: str = None,
                 random_sampling: int = None, countmin_width: int = None,
                 countmin_depth: int = None, twapi_instance=None, parser_extra=None, protobuf_message=None, zookeeper_hosts: str = '127.0.0.1:2181',
                 ordering_field: str = None, zmq_port: int = None):
        """
        Initializes the pykafka_connector.

        Args:
                    hosts (str): Comma-separated list of Kafka brokers.
            topic (str): The Kafka topic to consume from.
            parsetype (str): The format of the messages (e.g., "json", "pickle", "xml", "avro", "protobuf").
            queue_length (int): The maximum number of messages to store in the internal queue.
            cluster_size (int): The number of consumer threads to run.
            consumer_group (bytes): The consumer group ID.
            auto_offset_reset (OffsetType): The offset reset policy.
            fetch_message_max_bytes (int): The maximum size of a message to fetch.
            num_consumer_fetchers (int): The number of fetcher threads.
            auto_commit_enable (bool): Whether to enable auto-commit.
            auto_commit_interval_ms (int): The auto-commit interval in milliseconds.
            queued_max_messages (int): The maximum number of messages to queue.
            fetch_min_bytes (int): The minimum number of bytes to fetch.
            consumer_timeout_ms (int): The consumer timeout in milliseconds.
            consumer_start_timeout_ms (int): How long to wait for the consumer to get a partition assignment.
            anim_interval (float): The animation interval for plots in seconds.
            decode (str): The encoding to use for decoding messages.
            schema_path (str): The path to the Avro or Protobuf schema.
            random_sampling (int): The percentage of messages to sample (0-100).
            countmin_width (int): The width of the Count-Min Sketch.
            countmin_depth (int): The depth of the Count-Min Sketch.
            twapi_instance: An instance of the TensorWatch API for updating metrics.
            parser_extra (str): Extra information for the parser (e.g., Avro schema, Protobuf module).
            protobuf_message (str): The name of the Protobuf message class.
            zookeeper_hosts (str): Comma-separated list of Zookeeper hosts.
            ordering_field (str): Optional message field for global ordering.
            zmq_port (int): The port offset for the ZMQ watcher. If None, an automatic offset is assigned.
        """
        self.hosts = hosts
        self.topic = topic
        self.cluster_size = cluster_size
        self.decode = decode
        self.parsetype = parsetype
        self.schema_path = schema_path
        self.random_sampling = random_sampling
        self.parser_extra = parser_extra
        self.protobuf_message = protobuf_message
        self.queue_length = queue_length
        # Queues for inter-process communication
        self.raw_message_queue = mp.Queue()
        self.parsed_message_queue = mp.Queue(maxsize=queue_length)
        self.data = self.parsed_message_queue # Maintain 'data' attribute for compatibility
        self._quit = mp.Event()
        self.size = 0
        self.zmq_port = zmq_port # Store port, but don't create watcher yet
        self.cms = {}
        self.countmin_depth = countmin_depth
        self.countmin_width = countmin_width

        # Optional ordering
        self.ordering_field = ordering_field
        self.reordering_buffer = []

        # pykafka specific settings
        self.consumer_group = consumer_group
        self.auto_offset_reset = auto_offset_reset
        self.fetch_message_max_bytes = fetch_message_max_bytes
        self.num_consumer_fetchers = num_consumer_fetchers
        self.auto_commit_enable = auto_commit_enable
        self.auto_commit_interval_ms = auto_commit_interval_ms
        self.queued_max_messages = queued_max_messages
        self.fetch_min_bytes = fetch_min_bytes
        self.consumer_timeout_ms = consumer_timeout_ms
        self.consumer_start_timeout_ms = consumer_start_timeout_ms
        self.zookeeper_hosts = zookeeper_hosts

        # twapi integration
        self.twapi_instance = None
        self.latencies = []
        self.received_count = 0
        self.last_report_time = time.time()
        self.first_message_sent = False

        # Parsers initialization
        self.protobuf_class = None # Will be initialized in worker
        self.avro_schema = None # Will be initialized in worker

        self.processes = []
        self.main_thread = threading.Thread(target=self.run, args=(twapi_instance,), daemon=True)
        self.main_thread.start()


    def myparser(self, message):
        """
        Parses a message based on the specified format.
        """
        try:
            if self.parsetype is None or self.parsetype.lower() == 'json':
                return json.loads(message)
            elif self.parsetype.lower() == 'pickle':
                return pickle.loads(message)
            elif self.parsetype.lower() == 'xml' and xmltodict:
                return xmltodict.parse(message).get("root")
            elif self.parsetype.lower() == 'protobuf' and self.protobuf_class:
                dynamic_message = self.protobuf_class()
                dynamic_message.ParseFromString(message)
                return protobuf_to_dict(dynamic_message)
            elif self.parsetype.lower() == 'avro' and self.reader:
                # message_bytes = io.BytesIO(message)
                # decoder = BinaryDecoder(message_bytes)
                self._bytes_io.seek(0)
                self._bytes_io.truncate()
                self._bytes_io.write(message)
                self._bytes_io.seek(0)
                return schemaless_reader(self._bytes_io, self.avro_schema)
                # return self.reader.read(decoder)
        except Exception as e:
            logging.error(f"Parsing Error ({self.parsetype}): {e}")
        return None

    def _poll_loop(self):
        """
        Dedicated process to poll messages from Kafka and put them onto the raw_message_queue.
        This is an I/O-bound task.
        """

        logging.info(f"Starting pykafka consumer loop for topic '{self.topic}'")
        client = KafkaClient(hosts=self.hosts)
        topic = client.topics[self.topic]

        if self.cluster_size > 1:
            consumer = topic.get_balanced_consumer(
                consumer_group=self.consumer_group,
                auto_commit_enable=self.auto_commit_enable,
                auto_offset_reset=self.auto_offset_reset,
                num_consumer_fetchers=self.num_consumer_fetchers,
                auto_commit_interval_ms=self.auto_commit_interval_ms,
                queued_max_messages=self.queued_max_messages,
                fetch_min_bytes=self.fetch_min_bytes,
                zookeeper_connect=self.zookeeper_hosts
            )
            if self.consumer_start_timeout_ms > 0:
                time.sleep(self.consumer_start_timeout_ms / 1000.0)
        else:
            consumer = topic.get_simple_consumer(
                auto_offset_reset=self.auto_offset_reset,
                consumer_timeout_ms=self.consumer_timeout_ms,
                fetch_message_max_bytes=self.fetch_message_max_bytes,
                auto_commit_enable=self.auto_commit_enable,
                auto_commit_interval_ms=self.auto_commit_interval_ms,
                queued_max_messages=self.queued_max_messages,
                fetch_min_bytes=self.fetch_min_bytes
            )

        for message in consumer:
            if self._quit.is_set():
                break
            if message is None:
                continue
            self.raw_message_queue.put(message.value)

        consumer.stop()
        logging.info("Consumer loop stopped")

    def _worker_loop(self):
        """
        Dedicated worker process to fetch raw messages, parse them, and put them
        onto the parsed_message_queue. This is a CPU-bound task.
        """
        logging.info("Starting worker process")

        # Lazy-initialize parsers inside the worker process to avoid pickling issues.
        if self.parsetype:
            if self.parsetype.lower() == 'avro' and avro:
                try:
                    import fastavro
                    if isinstance(self.parser_extra, str):
                        self.avro_schema = json.loads(self.parser_extra)
                    elif isinstance(self.parser_extra, dict):
                        self.avro_schema = self.parser_extra
                    self._bytes_io = io.BytesIO()
                except Exception as e:
                    logging.error(f"Worker Avro schema error: {e}")
            elif self.parsetype.lower() == 'protobuf' and protobuf_to_dict:
                try:
                    import sys
                    import importlib
                    if self.schema_path:
                        sys.path.append(self.schema_path)
                    mymodule = importlib.import_module(self.parser_extra)
                    self.protobuf_class = getattr(mymodule, self.protobuf_message)
                except Exception as e:
                    logging.error(f"Worker Error importing protobuf: {e}")

        def _process_and_queue(raw_message):
            parsed_message = self.myparser(raw_message)
            if parsed_message:
                if isinstance(parsed_message, dict):
                    parsed_message['receive_time'] = time.time()

                if not self.parsed_message_queue.full():
                    self.parsed_message_queue.put(parsed_message, block=False)
                else:
                    _ = self.parsed_message_queue.get_nowait() # Drop oldest
                    self.parsed_message_queue.put(parsed_message, block=False)

        while not self._quit.is_set():
            try:
                raw_message = self.raw_message_queue.get(timeout=1)
                if raw_message is None: # Sentinel value to exit
                    break
                _process_and_queue(raw_message)
            except Empty:
                continue
        logging.info("Worker process stopped")

    def run(self, twapi_instance):
        """
        Starts the polling and worker processes, and then enters the main loop
        to observe the parsed data queue for visualization.
        """
        logging.info(f"Starting {self.cluster_size} worker processes and 1 polling process.")


        # Start the single polling process
        poll_process = mp.Process(target=self._poll_loop, daemon=True)
        self.processes.append(poll_process)
        poll_process.start()

        # Start the worker processes
        for _ in range(self.cluster_size):
            worker_process = mp.Process(target=self._worker_loop, daemon=True)
            self.processes.append(worker_process)
            worker_process.start()

        # Lazy-initialize the watcher in the main process, AFTER forking.
        self.watcher = Watcher(port=self.zmq_port)
        self.twapi_instance = twapi_instance

        # The main thread no longer needs a loop. It just starts the background processes.
        # The twapi class is now responsible for consuming the parsed_message_queue.
        pass

    def quit(self):
        """Stops the consumer thread."""
        logging.info("Shutting down pykafka_connector...")
        self._quit.set()
        # Send sentinel values to workers to ensure they exit the queue.get()
        for _ in range(self.cluster_size):
            self.raw_message_queue.put(None)

        for p in self.processes:
            p.join(timeout=5)
        logging.info("All processes stopped.")
