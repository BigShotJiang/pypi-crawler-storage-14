from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rentclc",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[],
    author="Aatmaja Karbhari",
    author_email="youremail@example.com",
    description="A generic rent calculation library for Python projects.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/rentcalc",
    project_urls={
        "Bug Tracker": "https://github.com/yourusername/rentcalc/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
    ],
    python_requires=">=3.7",
)
