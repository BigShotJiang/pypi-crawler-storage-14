from datetime import date


class RentCalculator:
    """
    Generic rent calculator for any project.
    """

    @staticmethod
    def days_between(start_date: date, end_date: date) -> int:
        if end_date < start_date:
            raise ValueError("End date cannot be earlier than start date.")
        return (end_date - start_date).days

    @staticmethod
    def calculate_daily_rent(rate, start_date, end_date):
        days = RentCalculator.days_between(start_date, end_date)
        return round(days * rate, 2)

    @staticmethod
    def calculate_weekly_rent(rate, start_date, end_date):
        days = RentCalculator.days_between(start_date, end_date)
        return round((days / 7) * rate, 2)

    @staticmethod
    def calculate_monthly_rent(rate, start_date, end_date):
        days = RentCalculator.days_between(start_date, end_date)
        return round((days / 30) * rate, 2)

    @staticmethod
    def auto_calculate(rate, rate_type, start_date, end_date):
        rate_type = rate_type.lower()

        if rate_type == "daily":
            return RentCalculator.calculate_daily_rent(rate, start_date, end_date)
        elif rate_type == "weekly":
            return RentCalculator.calculate_weekly_rent(rate, start_date, end_date)
        elif rate_type == "monthly":
            return RentCalculator.calculate_monthly_rent(rate, start_date, end_date)
        else:
            raise ValueError("rate_type must be daily, weekly, or monthly")
