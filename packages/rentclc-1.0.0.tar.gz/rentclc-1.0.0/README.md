# rentcalc
A generic rent calculation library for Python.

## Install:
pip install rentcalc

## Example:
from rentcalc import RentCalculator
from datetime import date

RentCalculator.auto_calculate(1200, "monthly", date(2025,1,1), date(2025,6,1))
