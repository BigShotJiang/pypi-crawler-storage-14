#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time: 2025/11/27 10:57
# @Author: zhanjiyuan
# @File: dataprocessing.py
# ----------------------------------------------------------------------------------------------------------------------
import os

def judge_interval_index(value, top_bins,start_value=None, return_interval=False):
    """
    给定数值，判断属于是哪个区间，并返回区间的范围和索引位置。
    value: 需要判断的数值
    top_bins: 区间范围值，必须从小到大排序
    return_interval: 是否返回区间值，默认只返回区间的索引。
    比如:
    value = 12
    top_bins = [10,20,30]
    res = judge_interval_index(value, top_bins, return_interval=True)
    print(res)
    # (1, '(10,20)')
    res = judge_interval_index(value, top_bins)
    print(res)
    # (1, )
    """
    if value >= top_bins[-1]:
        results = (len(top_bins),)
        if return_interval:
            results += (f"[{top_bins[-1]},)", )

        return results

    if start_value is None:
        start_value = 0
    else:
        assert start_value < top_bins[0], f"start_value {start_value} must be less than {top_bins[0]}"

    for i, tb in enumerate(top_bins):
        if value < tb:
            results = (i, )
            if return_interval:
                results +=  (f"[{top_bins[i-1] if i else start_value},{top_bins[i]})",)
            return results

def generate_interval_categories(top_bins,start_value = 0):
    """
    根据top_bins返回所有的区间值，
    例如：
    top_bins = [10,20,30]
    start_value = -1
    res = generate_interval_categories(top_bins,start_value)
    print(res)
    # ['[-1,10)', '[10,20)', '[20,30)', '[30,)']
    """
    intervals = []
    for e in [start_value] + top_bins:
        intervals.append(judge_interval_index(e,top_bins,start_value=start_value,return_interval=True)[1])
    return intervals

def map_op_interval(value,op_top_bins,start_value=0):
    """直接将value，映射到区间
    例如：
    value = 12
    op_top_bins = [10,20,30]
    res = map_op_interval(value,op_top_bins)
    print(res)
    # [10, 20)
    """
    return judge_interval_index(value,op_top_bins,start_value=start_value, return_interval=True)[1]

if __name__ == "__main__":
    print(os.path.basename(__file__))

    value = 12
    top_bins = [10,20,30]
    res = judge_interval_index(value,top_bins)
    print(res)

    res = generate_interval_categories(top_bins)
    print(res)

    res = map_op_interval(12, [10, 20, 30])
    print(f"res:{res}")
