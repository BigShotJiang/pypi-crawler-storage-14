from bsym import SymmetryGroup

class PointGroup(SymmetryGroup):

    class_str = 'PointGroup'
