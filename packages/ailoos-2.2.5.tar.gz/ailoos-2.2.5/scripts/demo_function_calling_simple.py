#!/usr/bin/env python3
"""
Demo Simple de Function Calling
Versión simplificada que evita importaciones circulares del sistema AILOOS completo.
"""

import asyncio
import sys
from pathlib import Path

# Añadir rutas específicas para evitar importaciones circulares
current_dir = Path(__file__).parent
project_root = current_dir.parent
models_dir = project_root / "models"
src_dir = project_root / "src"

sys.path.insert(0, str(models_dir))
sys.path.insert(0, str(src_dir))

print(f"Python path: {sys.path[:3]}...")  # Debug

# Importaciones directas de tools
try:
    from ailoos.tools.registry import ToolRegistry, Tool, ToolParameter
    from ailoos.tools.executor import ToolExecutor, ExecutionLimits
    from ailoos.tools.function_calling import FunctionCallingProcessor
    from ailoos.tools.builtin_tools import (
        calculator_tool, datetime_tool, web_search_tool, filesystem_tool
    )
    print("✅ Tools imports successful")
except ImportError as e:
    print(f"❌ Tools import failed: {e}")
    sys.exit(1)


async def setup_simple_system():
    """Configura un sistema simplificado de function calling."""
    print("🚀 Configurando sistema simplificado de Function Calling...")

    # 1. Configurar registry manualmente
    print("🔧 Configurando Tool Registry...")
    registry = ToolRegistry()

    # Registrar herramientas built-in
    tools = [calculator_tool, datetime_tool, web_search_tool, filesystem_tool]
    for tool in tools:
        await registry.register_tool(tool)
        print(f"  ✅ Registrada herramienta: {tool.name}")

    # 2. Configurar executor
    print("⚙️ Configurando Tool Executor...")
    limits = ExecutionLimits(max_execution_time=10.0)  # Timeout más corto para demo
    executor = ToolExecutor(registry, limits)

    # 3. Configurar processor
    print("🎯 Configurando Function Calling Processor...")
    processor = FunctionCallingProcessor(registry, executor)
    processor.set_tool_tokens("<tool_call>", "</tool_call>")  # Tokens por defecto

    print("✅ Sistema simplificado configurado!")
    return processor


async def demo_calculator(processor):
    """Demo simple de calculadora."""
    print("\n" + "="*60)
    print("🧮 DEMO: Calculadora")
    print("="*60)

    # Simular respuesta del modelo con tool call
    simulated_response = '''Para calcular 2349 × 1293, usaré la calculadora.

<tool_call>{"name": "calculator", "parameters": {"operation": "*", "x": 2349, "y": 1293}}</tool_call>'''

    print("Usuario: Calcula cuánto es 2349 multiplicado por 1293")
    print(f"EmpoorioLM: {simulated_response}")

    # Procesar con tools
    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")
    print(f"Tiempo de procesamiento: {result.processing_time:.2f}s")
    print(f"Tool calls detectados: {len(result.tool_calls)}")


async def demo_datetime(processor):
    """Demo simple de fecha y hora."""
    print("\n" + "="*60)
    print("📅 DEMO: Fecha y Hora")
    print("="*60)

    simulated_response = '''Necesito consultar la fecha y hora actual.

<tool_call>{"name": "datetime", "parameters": {"operation": "now"}}</tool_call>
<tool_call>{"name": "datetime", "parameters": {"operation": "weekday"}}</tool_call>'''

    print("Usuario: ¿Qué día es hoy y qué hora es?")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")
    print(f"Tiempo de procesamiento: {result.processing_time:.2f}s")
    print(f"Tool calls detectados: {len(result.tool_calls)}")


async def demo_multiple_tools(processor):
    """Demo de múltiples herramientas."""
    print("\n" + "="*60)
    print("🔧 DEMO: Múltiples Herramientas")
    print("="*60)

    simulated_response = '''El usuario pide dos operaciones diferentes.

<tool_call>{"name": "calculator", "parameters": {"operation": "sqrt", "x": 144}}</tool_call>

<tool_call>{"name": "datetime", "parameters": {"operation": "today"}}</tool_call>'''

    print("Usuario: Calcula la raíz cuadrada de 144 y dime qué día es hoy")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")
    print(f"Tiempo de procesamiento: {result.processing_time:.2f}s")
    print(f"Tool calls detectados: {len(result.tool_calls)}")


async def demo_error_handling(processor):
    """Demo de manejo de errores."""
    print("\n" + "="*60)
    print("❌ DEMO: Manejo de Errores")
    print("="*60)

    simulated_response = '''Intentaré calcular la raíz cuadrada de un número negativo.

<tool_call>{"name": "calculator", "parameters": {"operation": "sqrt", "x": -1}}</tool_call>'''

    print("Usuario: Calcula la raíz cuadrada de -1")
    print(f"EmpoorioLM: {simulated_response}")

    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")
    print(f"Tiempo de procesamiento: {result.processing_time:.2f}s")
    print(f"Tool calls detectados: {len(result.tool_calls)}")


async def show_system_status(processor):
    """Muestra estado del sistema."""
    print("\n" + "="*60)
    print("ℹ️ ESTADO DEL SISTEMA")
    print("="*60)

    tools = processor.registry.list_tools()
    print(f"🔧 Herramientas registradas: {len(tools)}")

    for tool in tools:
        print(f"  • {tool.name}: {tool.description}")

    print("\n📊 Herramientas por categoría:")
    categories = processor.registry.get_categories()
    for category, tool_names in categories.items():
        print(f"  • {category}: {len(tool_names)} tools")


async def main():
    """Función principal simplificada."""
    print("🎯 DEMO SIMPLIFICADO: Function Calling con EmpoorioLM")
    print("Versión que evita importaciones circulares del sistema completo.")

    try:
        # Configurar sistema simplificado
        processor = await setup_simple_system()

        # Mostrar estado del sistema
        await show_system_status(processor)

        # Ejecutar demos
        await demo_calculator(processor)
        await demo_datetime(processor)
        await demo_multiple_tools(processor)
        await demo_error_handling(processor)

        print("\n" + "="*60)
        print("🎉 ¡Demo simplificada completada exitosamente!")
        print("="*60)
        print("\nResumen de capacidades demostradas:")
        print("✅ Detección automática de tool calls")
        print("✅ Parsing JSON de llamadas a herramientas")
        print("✅ Ejecución segura en sandbox")
        print("✅ Manejo de errores robusto")
        print("✅ Procesamiento paralelo de múltiples tools")
        print("✅ Formateo de resultados para el modelo")
        print("\n🚀 ¡Function Calling operativo!")

    except Exception as e:
        print(f"❌ Error en demo: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)