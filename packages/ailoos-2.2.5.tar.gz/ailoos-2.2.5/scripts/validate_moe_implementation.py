#!/usr/bin/env python3
"""
MoE Implementation Validation Script
Script completo para validar toda la funcionalidad MoE implementada en Fase 1.
"""

import torch
import torch.nn as nn
import sys
import os
import time
import json
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging

# Add models directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.empoorio_lm.config import EmpoorioLMConfig, get_config_for_model_size
from models.empoorio_lm.model import EmpoorioLM
from models.empoorio_lm.moe import (
    NoisyTopKRouter,
    MoEExpert,
    MoELayer,
    compute_moe_loss,
    get_moe_statistics
)

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class MoEValidator:
    """
    Comprehensive validator for MoE implementation.
    Tests all components and functionality.
    """

    def __init__(self):
        self.results = {
            "component_tests": {},
            "integration_tests": {},
            "performance_tests": {},
            "conversion_tests": {},
            "overall_status": "pending"
        }

    def run_all_validations(self) -> Dict[str, Any]:
        """Run all validation tests."""
        logger.info("🚀 Starting comprehensive MoE validation...")

        try:
            # Component tests
            self.results["component_tests"] = self._test_components()

            # Integration tests
            self.results["integration_tests"] = self._test_integration()

            # Performance tests
            self.results["performance_tests"] = self._test_performance()

            # Conversion tests
            self.results["conversion_tests"] = self._test_conversion()

            # Overall status
            all_passed = all(
                all(test["status"] == "passed" for test in category.values())
                for category in [self.results["component_tests"],
                               self.results["integration_tests"],
                               self.results["performance_tests"],
                               self.results["conversion_tests"]]
            )

            self.results["overall_status"] = "passed" if all_passed else "failed"

            logger.info(f"✅ Validation completed. Overall status: {self.results['overall_status']}")

        except Exception as e:
            logger.error(f"❌ Validation failed with error: {str(e)}")
            self.results["overall_status"] = "error"
            self.results["error"] = str(e)

        return self.results

    def _test_components(self) -> Dict[str, Any]:
        """Test individual MoE components."""
        logger.info("🔧 Testing MoE components...")

        results = {}

        # Test NoisyTopKRouter
        results["router"] = self._test_router()

        # Test MoEExpert
        results["expert"] = self._test_expert()

        # Test MoELayer
        results["moe_layer"] = self._test_moe_layer()

        return results

    def _test_router(self) -> Dict[str, Any]:
        """Test NoisyTopKRouter component."""
        try:
            from models.empoorio_lm.moe import NoisyTopKRouter

            router = NoisyTopKRouter(
                input_dim=64,
                num_experts=8,
                top_k=2
            )

            # Test forward pass
            hidden_states = torch.randn(32, 64)  # batch_size * seq_len, hidden_dim
            routing_weights, expert_mask, aux_info = router(hidden_states)

            # Validate outputs
            assert routing_weights.shape == (32, 8)
            assert expert_mask.shape == (32, 8)
            assert torch.all(expert_mask.sum(dim=-1) == 2)  # top_k = 2
            assert "load_balance_loss" in aux_info

            return {"status": "passed", "message": "Router test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"Router test failed: {str(e)}"}

    def _test_expert(self) -> Dict[str, Any]:
        """Test MoEExpert component."""
        try:
            from models.empoorio_lm.moe import MoEExpert

            expert = MoEExpert(
                input_dim=64,
                hidden_dim=128,
                output_dim=64
            )

            # Test forward pass
            hidden_states = torch.randn(4, 64)
            output = expert(hidden_states)

            # Validate output
            assert output.shape == (4, 64)
            assert not torch.isnan(output).any()
            assert not torch.isinf(output).any()

            return {"status": "passed", "message": "Expert test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"Expert test failed: {str(e)}"}

    def _test_moe_layer(self) -> Dict[str, Any]:
        """Test MoELayer component."""
        try:
            from models.empoorio_lm.moe import MoELayer

            config = EmpoorioLMConfig(
                hidden_size=128,
                num_heads=8,
                num_experts=4,
                top_k=2,
                moe_layers=[0],
                device="cpu"
            )

            moe_layer = MoELayer(config, layer_idx=0)

            # Test forward pass
            hidden_states = torch.randn(2, 8, 128)  # batch_size, seq_len, hidden_dim
            output, aux_info = moe_layer(hidden_states)

            # Validate outputs
            assert output.shape == (2, 8, 128)
            assert "router_info" in aux_info
            assert "total_experts" in aux_info
            assert aux_info["total_experts"] == 5  # 4 experts + 1 shared

            return {"status": "passed", "message": "MoE layer test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"MoE layer test failed: {str(e)}"}

    def _test_integration(self) -> Dict[str, Any]:
        """Test MoE integration with full model."""
        logger.info("🔗 Testing MoE integration...")

        results = {}

        # Test MoE model creation
        results["model_creation"] = self._test_moe_model_creation()

        # Test forward pass
        results["forward_pass"] = self._test_moe_forward_pass()

        # Test generation
        results["generation"] = self._test_moe_generation()

        # Test loss calculation
        results["loss_calculation"] = self._test_moe_loss_calculation()

        return results

    def _test_moe_model_creation(self) -> Dict[str, Any]:
        """Test creating a complete MoE model."""
        try:
            config = EmpoorioLMConfig(
                vocab_size=1000,
                hidden_size=128,
                num_layers=4,
                num_heads=8,
                use_moe=True,
                num_experts=4,
                moe_layers=[1, 2],
                device="cpu"
            )

            model = EmpoorioLM(config)

            # Validate model structure
            assert len(model.blocks) == 4
            moe_blocks = [i for i, block in enumerate(model.blocks) if hasattr(block.ffn, 'router')]
            assert moe_blocks == [1, 2]

            info = model.get_model_info()
            assert info["use_moe"] == True
            assert info["num_experts"] == 4

            return {"status": "passed", "message": "MoE model creation test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"MoE model creation test failed: {str(e)}"}

    def _test_moe_forward_pass(self) -> Dict[str, Any]:
        """Test forward pass with MoE."""
        try:
            config = EmpoorioLMConfig(
                vocab_size=1000,
                hidden_size=128,
                num_layers=4,
                num_heads=8,
                use_moe=True,
                num_experts=4,
                moe_layers=[1, 2],
                device="cpu"
            )

            model = EmpoorioLM(config)
            model.eval()

            # Test forward pass
            batch_size, seq_len = 2, 16
            input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))

            with torch.no_grad():
                outputs = model(input_ids)

            # Validate outputs
            assert "logits" in outputs
            assert outputs["logits"].shape == (batch_size, seq_len, config.vocab_size)
            assert "moe_aux_info" in outputs
            assert len(outputs["moe_aux_info"]) == 2  # 2 MoE layers

            return {"status": "passed", "message": "MoE forward pass test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"MoE forward pass test failed: {str(e)}"}

    def _test_moe_generation(self) -> Dict[str, Any]:
        """Test text generation with MoE."""
        try:
            config = EmpoorioLMConfig(
                vocab_size=1000,
                hidden_size=128,
                num_layers=4,
                num_heads=8,
                use_moe=True,
                num_experts=4,
                moe_layers=[1, 2],
                device="cpu"
            )

            model = EmpoorioLM(config)
            model.eval()

            # Test generation
            input_ids = torch.randint(0, config.vocab_size, (1, 8))

            with torch.no_grad():
                generated = model.generate(
                    input_ids=input_ids,
                    max_length=16,
                    do_sample=False
                )

            # Validate generation
            assert generated.shape[0] == 1
            assert generated.shape[1] >= 8  # Should be extended

            return {"status": "passed", "message": "MoE generation test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"MoE generation test failed: {str(e)}"}

    def _test_moe_loss_calculation(self) -> Dict[str, Any]:
        """Test MoE loss calculation."""
        try:
            config = EmpoorioLMConfig(
                vocab_size=1000,
                hidden_size=128,
                num_layers=4,
                num_heads=8,
                use_moe=True,
                num_experts=4,
                moe_layers=[1, 2],
                device="cpu"
            )

            model = EmpoorioLM(config)
            model.train()

            # Test with labels
            batch_size, seq_len = 2, 12
            input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))
            labels = input_ids.clone()

            outputs = model(input_ids, labels=labels)

            # Validate losses
            assert "loss" in outputs
            assert "moe_aux_loss" in outputs
            assert outputs["loss"] >= outputs["moe_aux_loss"]  # Total loss includes MoE loss

            return {"status": "passed", "message": "MoE loss calculation test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"MoE loss calculation test failed: {str(e)}"}

    def _test_performance(self) -> Dict[str, Any]:
        """Test MoE performance characteristics."""
        logger.info("⚡ Testing MoE performance...")

        results = {}

        # Test inference speed
        results["inference_speed"] = self._test_inference_speed()

        # Test memory usage
        results["memory_usage"] = self._test_memory_usage()

        return results

    def _test_inference_speed(self) -> Dict[str, Any]:
        """Test inference speed."""
        try:
            config = EmpoorioLMConfig(
                vocab_size=1000,
                hidden_size=128,
                num_layers=4,
                num_heads=8,
                use_moe=True,
                num_experts=4,
                moe_layers=[1, 2],
                device="cpu"
            )

            model = EmpoorioLM(config)
            model.eval()

            batch_size, seq_len = 4, 16
            input_ids = torch.randint(0, config.vocab_size, (batch_size, seq_len))

            # Warm up
            with torch.no_grad():
                for _ in range(3):
                    _ = model(input_ids)

            # Measure inference time
            num_runs = 10
            start_time = time.time()

            with torch.no_grad():
                for _ in range(num_runs):
                    _ = model(input_ids)

            end_time = time.time()
            avg_time = (end_time - start_time) / num_runs

            # Should be reasonable (less than 1 second)
            if avg_time < 1.0:
                return {"status": "passed", "message": f"Inference speed test passed: {avg_time:.3f}s per batch"}
            else:
                return {"status": "warning", "message": f"Inference speed test: {avg_time:.3f}s per batch (slower than expected)"}

        except Exception as e:
            return {"status": "failed", "message": f"Inference speed test failed: {str(e)}"}

    def _test_memory_usage(self) -> Dict[str, Any]:
        """Test memory usage."""
        try:
            import psutil
            process = psutil.Process()
            initial_memory = process.memory_info().rss / 1024 / 1024  # MB

            config = EmpoorioLMConfig(
                vocab_size=1000,
                hidden_size=128,
                num_layers=4,
                num_heads=8,
                use_moe=True,
                num_experts=4,
                moe_layers=[1, 2],
                device="cpu"
            )

            model = EmpoorioLM(config)
            final_memory = process.memory_info().rss / 1024 / 1024  # MB

            memory_usage = final_memory - initial_memory

            # Should be reasonable (less than 500MB for this small model)
            if memory_usage < 500:
                return {"status": "passed", "message": f"Memory usage test passed: {memory_usage:.1f} MB"}
            else:
                return {"status": "warning", "message": f"Memory usage test: {memory_usage:.1f} MB (higher than expected)"}

        except Exception as e:
            return {"status": "failed", "message": f"Memory usage test failed: {str(e)}"}

    def _test_conversion(self) -> Dict[str, Any]:
        """Test dense to MoE conversion."""
        logger.info("🔄 Testing dense to MoE conversion...")

        results = {}

        # Test conversion pipeline
        results["conversion_pipeline"] = self._test_conversion_pipeline()

        # Test weight preservation
        results["weight_preservation"] = self._test_weight_preservation()

        return results

    def _test_conversion_pipeline(self) -> Dict[str, Any]:
        """Test the complete conversion pipeline."""
        try:
            from scripts.upcycle_dense_to_moe import DenseToMoEConverter

            # Load dense config
            dense_config_path = Path("models/dense_model/config.json")
            if not dense_config_path.exists():
                return {"status": "skipped", "message": "Dense model not found, skipping conversion test"}

            dense_config = EmpoorioLMConfig.load_config(str(dense_config_path))
            dense_model = EmpoorioLM.from_pretrained("models/dense_model", dense_config)

            # Create MoE config
            moe_config = EmpoorioLMConfig(
                vocab_size=dense_config.vocab_size,
                hidden_size=dense_config.hidden_size,
                num_layers=dense_config.num_layers,
                num_heads=dense_config.num_heads,
                max_position_embeddings=dense_config.max_position_embeddings,
                use_moe=True,
                num_experts=4,
                top_k=2,
                moe_layers=[4, 7, 10],  # Default MoE layers
                device="cpu"
            )

            # Convert
            converter = DenseToMoEConverter(dense_config, moe_config)
            moe_model = converter.convert_model(dense_model)

            # Validate conversion
            assert isinstance(moe_model, EmpoorioLM)
            assert moe_model.config.use_moe == True

            return {"status": "passed", "message": "Conversion pipeline test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"Conversion pipeline test failed: {str(e)}"}

    def _test_weight_preservation(self) -> Dict[str, Any]:
        """Test that weights are properly preserved during conversion."""
        try:
            from scripts.upcycle_dense_to_moe import DenseToMoEConverter

            # Load dense model
            dense_config_path = Path("models/dense_model/config.json")
            if not dense_config_path.exists():
                return {"status": "skipped", "message": "Dense model not found, skipping weight preservation test"}

            dense_config = EmpoorioLMConfig.load_config(str(dense_config_path))
            dense_model = EmpoorioLM.from_pretrained("models/dense_model", dense_config)

            # Create MoE config
            moe_config = EmpoorioLMConfig(
                vocab_size=dense_config.vocab_size,
                hidden_size=dense_config.hidden_size,
                num_layers=dense_config.num_layers,
                num_heads=dense_config.num_heads,
                max_position_embeddings=dense_config.max_position_embeddings,
                use_moe=True,
                num_experts=4,
                top_k=2,
                moe_layers=[4, 7, 10],
                device="cpu"
            )

            # Convert
            converter = DenseToMoEConverter(dense_config, moe_config)
            moe_model = converter.convert_model(dense_model)

            # Check that embeddings are preserved
            assert torch.allclose(
                dense_model.embed_tokens.weight,
                moe_model.embed_tokens.weight
            )

            # Check that attention weights are preserved for non-MoE layers
            dense_attn = dense_model.blocks[0].attn.q_proj.weight
            moe_attn = moe_model.blocks[0].attn.q_proj.weight
            assert torch.allclose(dense_attn, moe_attn)

            return {"status": "passed", "message": "Weight preservation test passed"}

        except Exception as e:
            return {"status": "failed", "message": f"Weight preservation test failed: {str(e)}"}

    def save_results(self, output_file: str = "moe_validation_results.json"):
        """Save validation results to file."""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        logger.info(f"✅ Validation results saved to {output_file}")

    def print_summary(self):
        """Print validation summary."""
        print("\n" + "="*80)
        print("MoE IMPLEMENTATION VALIDATION SUMMARY")
        print("="*80)

        print(f"\nOverall Status: {self.results['overall_status'].upper()}")

        for category_name, category_results in self.results.items():
            if category_name == "overall_status":
                continue
            if isinstance(category_results, dict):
                print(f"\n{category_name.upper()}:")
                for test_name, test_result in category_results.items():
                    status = test_result.get("status", "unknown")
                    message = test_result.get("message", "")
                    status_icon = "✅" if status == "passed" else "❌" if status == "failed" else "⚠️"
                    print(f"  {status_icon} {test_name}: {message}")

        print("\n" + "="*80)


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Validate MoE implementation")
    parser.add_argument("--output", default="moe_validation_results.json", help="Output file")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Run validation
    validator = MoEValidator()
    results = validator.run_all_validations()

    # Save and print results
    validator.save_results(args.output)
    validator.print_summary()

    # Exit with appropriate code
    if results["overall_status"] == "passed":
        print("\n🎉 All validations passed!")
        sys.exit(0)
    else:
        print("\n❌ Some validations failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()