#!/usr/bin/env python3
"""
Upcycle Dense to MoE Converter
Script para convertir modelos EmpoorioLM densos a arquitectura MoE.
"""

import torch
import torch.nn as nn
from pathlib import Path
from typing import Optional, Dict, Any
import argparse
import logging
import sys
import os

# Add models directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.empoorio_lm.config import EmpoorioLMConfig
from models.empoorio_lm.model import EmpoorioLM
from models.empoorio_lm.moe import MoELayer

logger = logging.getLogger(__name__)


class DenseToMoEConverter:
    """
    Conversor de modelos densos a MoE.
    Copia pesos del modelo denso y inicializa componentes MoE correctamente.
    """

    def __init__(self, dense_config: EmpoorioLMConfig, moe_config: EmpoorioLMConfig):
        self.dense_config = dense_config
        self.moe_config = moe_config

        # Validate compatibility
        self._validate_configs()

    def _validate_configs(self):
        """Validate that configs are compatible for conversion."""
        assert self.dense_config.hidden_size == self.moe_config.hidden_size, "hidden_size must match"
        assert self.dense_config.num_layers == self.moe_config.num_layers, "num_layers must match"
        assert self.dense_config.vocab_size == self.moe_config.vocab_size, "vocab_size must match"
        assert self.moe_config.use_moe, "MoE config must have use_moe=True"

        logger.info("✅ Config validation passed")

    def convert_model(self, dense_model: EmpoorioLM) -> EmpoorioLM:
        """
        Convert dense model to MoE model.

        Args:
            dense_model: Trained dense EmpoorioLM model

        Returns:
            MoE version of the model with copied weights
        """
        logger.info("🚀 Starting dense to MoE conversion...")

        # Create new MoE model
        moe_model = EmpoorioLM(self.moe_config)

        # Copy shared weights
        self._copy_shared_weights(dense_model, moe_model)

        # Convert dense layers to MoE layers
        self._convert_dense_to_moe_layers(dense_model, moe_model)

        # Initialize MoE components
        self._initialize_moe_components(moe_model)

        logger.info("✅ Dense to MoE conversion completed")
        return moe_model

    def _copy_shared_weights(self, dense_model: EmpoorioLM, moe_model: EmpoorioLM):
        """Copy weights that are shared between dense and MoE models."""
        logger.info("📋 Copying shared weights...")

        # Copy token embeddings
        moe_model.embed_tokens.load_state_dict(dense_model.embed_tokens.state_dict())

        # Handle position embeddings - copy if both models have them
        if hasattr(dense_model, 'embed_positions') and dense_model.embed_positions is not None:
            if hasattr(moe_model, 'embed_positions') and moe_model.embed_positions is not None:
                moe_model.embed_positions.load_state_dict(dense_model.embed_positions.state_dict())
                logger.info("   Position embeddings copied")
            else:
                logger.info("   Skipping position embeddings (MoE model uses RoPE)")
        else:
            logger.info("   No position embeddings in dense model")

        # Copy final layer norm
        moe_model.ln_f.load_state_dict(dense_model.ln_f.state_dict())

        # Copy attention layers for all blocks
        for i, (dense_block, moe_block) in enumerate(zip(dense_model.blocks, moe_model.blocks)):
            moe_block.attn.load_state_dict(dense_block.attn.state_dict())
            moe_block.ln1.load_state_dict(dense_block.ln1.state_dict())

        logger.info("✅ Shared weights copied")

    def _convert_dense_to_moe_layers(self, dense_model: EmpoorioLM, moe_model: EmpoorioLM):
        """Convert dense FFN layers to MoE layers where specified."""
        logger.info("🔄 Converting dense layers to MoE layers...")

        moe_layers = set(self.moe_config.moe_layers)

        for i, (dense_block, moe_block) in enumerate(zip(dense_model.blocks, moe_model.blocks)):
            if i in moe_layers:
                # This is a MoE layer - copy dense weights to shared expert
                self._copy_dense_to_shared_expert(dense_block, moe_block)
                logger.info(f"   Layer {i}: Converted to MoE")
            else:
                # This is a dense layer - copy directly
                moe_block.ffn.load_state_dict(dense_block.ffn.state_dict())
                moe_block.ln2.load_state_dict(dense_block.ln2.state_dict())
                logger.info(f"   Layer {i}: Kept as dense")

    def _copy_dense_to_shared_expert(self, dense_block: nn.Module, moe_block: nn.Module):
        """Copy dense FFN weights to the shared expert in MoE layer."""
        dense_ffn = dense_block.ffn
        dense_ln2 = dense_block.ln2
        moe_layer = moe_block.ffn

        # Copy layer norms
        moe_layer.pre_norm.load_state_dict(dense_ln2.state_dict())
        moe_layer.post_norm.load_state_dict(dense_ln2.state_dict())

        # Copy dense FFN weights to shared expert
        # Dense FFN: fc1 -> act -> dropout -> fc2 -> dropout
        # Shared expert: w1 -> w3 -> act -> dropout -> w2
        # We map fc1 -> w1, fc2 -> w2, and initialize w3 as copy of fc1

        shared_expert = moe_layer.shared_expert

        # Copy fc1 weights to both w1 and w3 (standard initialization)
        # Note: MoE experts use bias=False, so we don't copy biases
        if hasattr(dense_ffn, 'fc1'):
            shared_expert.w1.weight.data.copy_(dense_ffn.fc1.weight.data)
            shared_expert.w3.weight.data.copy_(dense_ffn.fc1.weight.data)

        # Copy fc2 weights
        if hasattr(dense_ffn, 'fc2'):
            shared_expert.w2.weight.data.copy_(dense_ffn.fc2.weight.data)

    def _initialize_moe_components(self, moe_model: EmpoorioLM):
        """Initialize MoE-specific components (experts and routers)."""
        logger.info("🎯 Initializing MoE components...")

        moe_layers = set(self.moe_config.moe_layers)

        for i, block in enumerate(moe_model.blocks):
            if i in moe_layers and hasattr(block.ffn, 'experts'):
                moe_layer = block.ffn

                # Initialize experts with small random weights
                for expert in moe_layer.experts:
                    self._initialize_expert_weights(expert)

                # Initialize router
                self._initialize_router_weights(moe_layer.router)

                logger.info(f"   Layer {i}: MoE components initialized")

    def _initialize_expert_weights(self, expert: nn.Module):
        """Initialize expert weights with small random values."""
        for name, param in expert.named_parameters():
            if 'weight' in name:
                # Small initialization for experts
                nn.init.normal_(param, mean=0.0, std=0.01)
            elif 'bias' in name:
                nn.init.zeros_(param)

    def _initialize_router_weights(self, router: nn.Module):
        """Initialize router weights."""
        # Router weights are already initialized in __init__
        # We could add custom initialization here if needed
        pass

    @classmethod
    def upcycle_dense_to_moe(
        cls,
        dense_model_path: str,
        moe_config: EmpoorioLMConfig,
        output_path: str,
        device: str = "auto"
    ) -> str:
        """
        Complete upcycling pipeline from dense model to MoE.

        Args:
            dense_model_path: Path to dense model directory
            moe_config: MoE configuration
            output_path: Where to save the MoE model
            device: Device to use for conversion

        Returns:
            Path to the converted MoE model
        """
        logger.info(f"🔄 Upcycling dense model from {dense_model_path} to MoE...")

        # Load dense model
        dense_model_path = Path(dense_model_path)
        dense_config_path = dense_model_path / "config.json"

        if not dense_config_path.exists():
            raise FileNotFoundError(f"Dense config not found: {dense_config_path}")

        dense_config = EmpoorioLMConfig.load_config(str(dense_config_path))

        # Ensure dense config is actually dense
        dense_config.use_moe = False
        dense_config.use_rope = False  # Use position embeddings for compatibility

        dense_model = EmpoorioLM.from_pretrained(dense_model_path, dense_config)

        # Create converter
        converter = cls(dense_config, moe_config)

        # Convert model
        moe_model = converter.convert_model(dense_model)

        # Save MoE model
        output_path = Path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)
        moe_model.save_pretrained(output_path)

        logger.info(f"✅ MoE model saved to {output_path}")

        # Print conversion summary
        cls._print_conversion_summary(dense_config, moe_config, dense_model, moe_model)

        return str(output_path)

    @staticmethod
    def _print_conversion_summary(
        dense_config: EmpoorioLMConfig,
        moe_config: EmpoorioLMConfig,
        dense_model: EmpoorioLM,
        moe_model: EmpoorioLM
    ):
        """Print summary of the conversion."""
        print("\n" + "="*60)
        print("🔄 DENSE TO MoE CONVERSION SUMMARY")
        print("="*60)

        dense_info = dense_model.get_model_info()
        moe_info = moe_model.get_model_info()

        print(f"Dense Model:")
        print(f"  Parameters: {dense_info['total_parameters']:,}")
        print(f"  Architecture: {dense_info['architecture']}")

        print(f"\nMoE Model:")
        print(f"  Parameters: {moe_info['total_parameters']:,}")
        print(f"  Architecture: {moe_info['architecture']}")
        print(f"  Experts per layer: {moe_config.num_experts}")
        print(f"  Top-K routing: {moe_config.top_k}")
        print(f"  MoE layers: {moe_config.moe_layers}")

        param_increase = moe_info['total_parameters'] / dense_info['total_parameters']
        print(".2f")

        print("\n✅ Conversion completed successfully!")
        print("="*60)


def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description="Upcycle dense EmpoorioLM to MoE")
    parser.add_argument("--dense_model_path", required=True, help="Path to dense model directory")
    parser.add_argument("--output_path", required=True, help="Output path for MoE model")
    parser.add_argument("--num_experts", type=int, default=8, help="Number of experts")
    parser.add_argument("--moe_layers", type=str, default="4,7,10", help="Comma-separated list of MoE layer indices")
    parser.add_argument("--top_k", type=int, default=2, help="Top-K routing")
    parser.add_argument("--load_balance_weight", type=float, default=0.01, help="Load balancing weight")
    parser.add_argument("--expert_quantization", choices=["none", "int8", "int4"], default="int8", help="Expert quantization")

    args = parser.parse_args()

    # Setup logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    try:
        # Load dense model config to get base parameters
        dense_config_path = Path(args.dense_model_path) / "config.json"
        if not dense_config_path.exists():
            raise FileNotFoundError(f"Dense config not found: {dense_config_path}")

        dense_config = EmpoorioLMConfig.load_config(str(dense_config_path))

        # Create MoE config
        moe_config = EmpoorioLMConfig(
            vocab_size=dense_config.vocab_size,
            hidden_size=dense_config.hidden_size,
            num_layers=dense_config.num_layers,
            num_heads=dense_config.num_heads,
            max_position_embeddings=dense_config.max_position_embeddings,
            use_moe=True,
            num_experts=args.num_experts,
            moe_layers=[int(x.strip()) for x in args.moe_layers.split(",")],
            top_k=args.top_k,
            load_balance_weight=args.load_balance_weight,
            expert_quantization=args.expert_quantization,
        )

        # Run conversion
        output_path = DenseToMoEConverter.upcycle_dense_to_moe(
            dense_model_path=args.dense_model_path,
            moe_config=moe_config,
            output_path=args.output_path
        )

        print(f"\n🎉 Conversion completed! MoE model saved to: {output_path}")

    except Exception as e:
        logger.error(f"❌ Conversion failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()