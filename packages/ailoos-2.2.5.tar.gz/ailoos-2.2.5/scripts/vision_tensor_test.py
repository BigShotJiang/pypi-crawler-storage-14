#!/usr/bin/env python3
"""
Vision Tensor Test Script
Prueba el flujo completo de tensores para Empoorio-Vision.

Verifica que:
1. VisionEncoder carga y procesa imágenes correctamente
2. MultiModalProjector proyecta embeddings correctamente
3. LVLMWrapper combina todo sin errores
"""

import sys
import os
import torch
import numpy as np
from PIL import Image

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

def create_test_image():
    """Create a simple test image."""
    # Create a 224x224 RGB image with some patterns
    img_array = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
    # Add some structure
    img_array[50:150, 50:150, 0] = 255  # Red square
    img_array[100:200, 100:200, 1] = 255  # Green square
    return Image.fromarray(img_array)

def test_vision_encoder():
    """Test VisionEncoder independently."""
    print("🧪 Testing VisionEncoder...")

    try:
        from ailoos.models.vision.encoder import VisionEncoder

        # Create encoder
        encoder = VisionEncoder(freeze_weights=True)
        print("✅ VisionEncoder created")

        # Test with dummy image
        test_image = create_test_image()
        features = encoder.get_image_features(test_image)

        print(f"✅ Features shape: {features.shape}")
        print(f"✅ Hidden size: {encoder.hidden_size}")
        print(f"✅ Num patches: {encoder.num_patches}")

        # Verify dimensions - CLIP ViT-Base: 224x224 image, 32x32 patches = 7x7 = 49 patches
        expected_patches = (224 // 32) ** 2  # CLIP patch size is 32
        assert features.shape[0] == expected_patches, f"Expected {expected_patches} patches, got {features.shape[0]}"
        assert features.shape[1] == encoder.hidden_size, f"Expected hidden size {encoder.hidden_size}, got {features.shape[1]}"

        print("✅ VisionEncoder test passed!")
        return True

    except Exception as e:
        print(f"❌ VisionEncoder test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_multimodal_projector():
    """Test MultiModalProjector independently."""
    print("🧪 Testing MultiModalProjector...")

    try:
        from ailoos.models.vision.projector import MultiModalProjector

        # Create projector
        vision_dim = 1152  # SigLIP
        llm_hidden_size = 768  # EmpoorioLM
        projector = MultiModalProjector(vision_dim, llm_hidden_size)
        print("✅ MultiModalProjector created")

        # Test with dummy vision features
        batch_size, num_patches = 1, 256
        vision_features = torch.randn(batch_size, num_patches, vision_dim)

        projected = projector(vision_features)

        print(f"✅ Input shape: {vision_features.shape}")
        print(f"✅ Output shape: {projected.shape}")

        # Verify dimensions
        assert projected.shape == (batch_size, num_patches, llm_hidden_size), \
            f"Expected {(batch_size, num_patches, llm_hidden_size)}, got {projected.shape}"

        # Check projector info
        info = projector.get_projector_info()
        print(f"✅ Projector parameters: {info['total_parameters']:,}")

        print("✅ MultiModalProjector test passed!")
        return True

    except Exception as e:
        print(f"❌ MultiModalProjector test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_lvlm_wrapper():
    """Test LVLMWrapper integration."""
    print("🧪 Testing LVLMWrapper...")

    try:
        from ailoos.models.vision.lvlm_wrapper import LVLMWrapper, VisionConfig

        # Create mock base model
        class MockBaseModel(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.wte = torch.nn.Embedding(1000, 768)
                self.config = type('Config', (), {'n_embd': 768})()

            def forward(self, input_ids=None, inputs_embeds=None, **kwargs):
                seq_len = inputs_embeds.shape[1] if inputs_embeds is not None else input_ids.shape[1]
                return {
                    'logits': torch.randn(1, seq_len, 1000),
                    'loss': None
                }

        base_model = MockBaseModel()
        vision_config = VisionConfig()

        # Create LVLM wrapper
        lvlm = LVLMWrapper(base_model, vision_config)
        print("✅ LVLMWrapper created")

        # Test preprocess inputs (without image)
        inputs = lvlm.preprocess_inputs("Hello world", image=None)
        assert 'input_ids' in inputs
        assert inputs['has_image'] == False
        print("✅ Text preprocessing works")

        # Test forward pass without image
        outputs = lvlm(inputs['input_ids'])
        assert 'logits' in outputs
        assert outputs['has_image'] == False
        print("✅ Forward pass without image works")

        # Test with mock image
        test_image = create_test_image()
        inputs_with_image = lvlm.preprocess_inputs("Describe this image", image=test_image)
        assert inputs_with_image['has_image'] == True
        print("✅ Image preprocessing works")

        # Test forward pass with image
        outputs_with_image = lvlm(
            inputs_with_image['input_ids'],
            pixel_values=inputs_with_image.get('pixel_values')
        )
        assert outputs_with_image['has_image'] == True
        assert 'vision_features' in outputs_with_image
        print("✅ Forward pass with image works")

        # Test generation
        response = lvlm.generate("What do you see?", test_image)
        assert isinstance(response, str)
        assert "image" in response.lower()
        print("✅ Generation with image works")

        # Test model info
        info = lvlm.get_model_info()
        assert info['vision_capabilities'] == True
        print("✅ Model info works")

        print("✅ LVLMWrapper test passed!")
        return True

    except Exception as e:
        print(f"❌ LVLMWrapper test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_complete_pipeline():
    """Test complete vision pipeline."""
    print("🧪 Testing Complete Vision Pipeline...")

    try:
        from ailoos.models.vision import create_empoorio_vision

        # Create model (will use mock if real not available)
        model = create_empoorio_vision()
        print("✅ EmpoorioVision model created")

        # Test with text only
        response_text = model.generate("Hello world")
        assert isinstance(response_text, str)
        print("✅ Text-only generation works")

        # Test with image
        test_image = create_test_image()
        response_vision = model.generate("What is in this image?", test_image)
        assert isinstance(response_vision, str)
        assert "image" in response_vision.lower()
        print("✅ Vision generation works")

        print("✅ Complete pipeline test passed!")
        return True

    except Exception as e:
        print(f"❌ Complete pipeline test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all vision tests."""
    print("🚀 Empoorio-Vision Tensor Flow Tests")
    print("=" * 50)

    tests = [
        test_vision_encoder,
        test_multimodal_projector,
        test_lvlm_wrapper,
        test_complete_pipeline
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} crashed: {e}")
            results.append(False)
        print()

    print("=" * 50)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 50)

    passed = sum(results)
    total = len(results)

    for i, (test, result) in enumerate(zip(tests, results)):
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{i+1}. {test.__name__}: {status}")

    print(f"\n🎯 Overall: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 ALL VISION TESTS PASSED! Empoorio-Vision is ready!")
        return 0
    else:
        print("⚠️ Some tests failed. Check the output above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())