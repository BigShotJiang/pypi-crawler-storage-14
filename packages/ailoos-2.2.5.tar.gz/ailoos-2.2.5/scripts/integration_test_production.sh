#!/bin/bash

# AILOOS Production Integration Tests
# Ejecuta tests end-to-end contra el sistema desplegado

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

info() {
    echo -e "${PURPLE}ℹ️  $1${NC}"
}

# Función de ayuda
usage() {
    echo "Uso: $0 [OPTIONS]"
    echo ""
    echo "Ejecuta tests de integración E2E en producción"
    echo ""
    echo "OPTIONS:"
    echo "  -e, --environment ENV    Ambiente (staging|production) [default: staging]"
    echo "  -u, --base-url URL        URL base del sistema [auto-detect]"
    echo "  -t, --test-timeout SEC    Timeout por test en segundos [default: 60]"
    echo "  -v, --verbose             Output detallado"
    echo "  -j, --json                Output en formato JSON"
    echo "  --skip-frontend           Saltar tests del frontend"
    echo "  --skip-backend            Saltar tests del backend"
    echo "  --skip-api                Saltar tests de API"
    echo "  -h, --help                Mostrar esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 --environment production"
    echo "  $0 -e staging --verbose"
    echo "  $0 --json > integration_results.json"
}

# Valores por defecto
ENVIRONMENT="staging"
BASE_URL=""
TEST_TIMEOUT=60
VERBOSE=false
JSON_OUTPUT=false
SKIP_FRONTEND=false
SKIP_BACKEND=false
SKIP_API=false

# Parsear argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -u|--base-url)
            BASE_URL="$2"
            shift 2
            ;;
        -t|--test-timeout)
            TEST_TIMEOUT="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -j|--json)
            JSON_OUTPUT=true
            shift
            ;;
        --skip-frontend)
            SKIP_FRONTEND=true
            shift
            ;;
        --skip-backend)
            SKIP_BACKEND=true
            shift
            ;;
        --skip-api)
            SKIP_API=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Opción desconocida: $1"
            usage
            exit 1
            ;;
    esac
done

# Variables globales para resultados
declare -A TEST_RESULTS
OVERALL_STATUS="passed"
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# Función para actualizar estadísticas
update_stats() {
    local result=$1
    ((TOTAL_TESTS++))
    if [[ "$result" == "passed" ]]; then
        ((PASSED_TESTS++))
    else
        ((FAILED_TESTS++))
        OVERALL_STATUS="failed"
    fi
}

# Función para ejecutar test con timeout
run_test() {
    local test_name=$1
    local test_command=$2

    if [[ "$VERBOSE" == true ]]; then
        log "Ejecutando test: $test_name"
    fi

    # Ejecutar con timeout
    if timeout "$TEST_TIMEOUT" bash -c "$test_command" 2>/dev/null; then
        TEST_RESULTS["$test_name"]="passed"
        update_stats "passed"
        if [[ "$VERBOSE" == true ]]; then
            success "$test_name: PASSED"
        fi
        return 0
    else
        TEST_RESULTS["$test_name"]="failed"
        update_stats "failed"
        if [[ "$VERBOSE" == true ]]; then
            error "$test_name: FAILED"
        fi
        return 1
    fi
}

# Función para determinar URLs base
determine_urls() {
    if [[ -z "$BASE_URL" ]]; then
        if [[ "$ENVIRONMENT" == "production" ]]; then
            BASE_URL="https://ailoos.dev"
            API_BASE_URL="https://ailoos-gateway-production-[hash].uc.gateway.dev"
        else
            BASE_URL="https://staging.ailoos.dev"
            API_BASE_URL="https://ailoos-gateway-staging-[hash].uc.gateway.dev"
        fi

        # Intentar cargar desde configuración
        if [[ -f "backend_config_$ENVIRONMENT.json" ]] && command -v jq &> /dev/null; then
            API_BASE_URL=$(jq -r '.gateway_url' "backend_config_$ENVIRONMENT.json")
        fi
    else
        API_BASE_URL="$BASE_URL/api"
    fi

    if [[ "$VERBOSE" == true ]]; then
        log "URLs detectadas:"
        log "  Frontend: $BASE_URL"
        log "  API: $API_BASE_URL"
    fi
}

# Tests del backend
run_backend_tests() {
    if [[ "$SKIP_BACKEND" == true ]]; then
        warning "Saltando tests del backend"
        return 0
    fi

    info "🔧 Ejecutando tests del backend..."

    # Test 1: Health check de servicios
    run_test "Backend Health Check" "
        services=('coordinator' 'compliance' 'dashboard' 'monitoring' 'integration')
        for service in \"\${services[@]}\"; do
            if ! curl -f -s \"$API_BASE_URL/\$service/health\" > /dev/null; then
                exit 1
            fi
        done
        exit 0
    "

    # Test 2: Conexión a base de datos
    run_test "Database Connection" "
        # Intentar una query simple a través de la API
        response=\$(curl -s \"$API_BASE_URL/coordinator/health\")
        if echo \"\$response\" | grep -q 'database.*ok'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 3: Redis connectivity
    run_test "Redis Connectivity" "
        # Verificar que Redis esté respondiendo
        response=\$(curl -s \"$API_BASE_URL/monitoring/metrics\")
        if echo \"\$response\" | grep -q 'redis'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 4: API endpoints básicos
    run_test "API Endpoints" "
        endpoints=('federated/stats' 'compliance/status' 'dashboard/summary' 'monitoring/health')
        for endpoint in \"\${endpoints[@]}\"; do
            if ! curl -f -s \"$API_BASE_URL/\$endpoint\" > /dev/null 2>&1; then
                # Algunos endpoints pueden requerir auth, verificar al menos que respondan
                if ! curl -s \"$API_BASE_URL/\$endpoint\" | grep -q 'unauthorized\|forbidden'; then
                    exit 1
                fi
            fi
        done
        exit 0
    "

    success "Tests del backend completados"
}

# Tests del frontend
run_frontend_tests() {
    if [[ "$SKIP_FRONTEND" == true ]]; then
        warning "Saltando tests del frontend"
        return 0
    fi

    info "🌐 Ejecutando tests del frontend..."

    # Test 1: Página principal carga
    run_test "Frontend Home Page" "
        response=\$(curl -s -w 'HTTPSTATUS:%{http_code}' '$BASE_URL')
        http_code=\$(echo \"\$response\" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
        if [[ \"\$http_code\" == '200' ]]; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 2: Assets estáticos cargan
    run_test "Static Assets" "
        # Verificar que CSS y JS carguen
        html=\$(curl -s '$BASE_URL')
        if echo \"\$html\" | grep -q '\.css' && echo \"\$html\" | grep -q '\.js'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 3: Páginas principales accesibles
    run_test "Main Pages" "
        pages=('' 'dashboard' 'federated' 'compliance' 'monitoring')
        for page in \"\${pages[@]}\"; do
            url=\"$BASE_URL\${page:+/\$page}\"
            http_code=\$(curl -s -o /dev/null -w '%{http_code}' \"\$url\")
            if [[ \"\$http_code\" != '200' && \"\$http_code\" != '302' ]]; then
                exit 1
            fi
        done
        exit 0
    "

    # Test 4: API calls desde frontend
    run_test "Frontend API Calls" "
        # Verificar que el frontend pueda hacer llamadas a la API
        # Esto requiere JavaScript execution, por ahora verificamos configuración
        html=\$(curl -s '$BASE_URL')
        if echo \"\$html\" | grep -q 'API_BASE_URL\|NEXT_PUBLIC_API_URL'; then
            exit 0
        else
            exit 1
        fi
    "

    success "Tests del frontend completados"
}

# Tests de integración API
run_api_tests() {
    if [[ "$SKIP_API" == true ]]; then
        warning "Saltando tests de API"
        return 0
    fi

    info "🔗 Ejecutando tests de integración API..."

    # Test 1: Federated learning workflow
    run_test "Federated Learning API" "
        # Crear una sesión federated
        response=\$(curl -s -X POST '$API_BASE_URL/federated/session' \\
            -H 'Content-Type: application/json' \\
            -d '{\"model_type\":\"test\",\"participants\":2}')
        if echo \"\$response\" | grep -q 'session_id'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 2: Compliance API
    run_test "Compliance API" "
        response=\$(curl -s '$API_BASE_URL/compliance/status')
        if echo \"\$response\" | grep -q 'status\|compliant'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 3: Dashboard data
    run_test "Dashboard API" "
        response=\$(curl -s '$API_BASE_URL/dashboard/summary')
        if echo \"\$response\" | grep -q 'metrics\|data'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 4: Monitoring endpoints
    run_test "Monitoring API" "
        response=\$(curl -s '$API_BASE_URL/monitoring/metrics')
        if echo \"\$response\" | grep -q 'metrics\|uptime'; then
            exit 0
        else
            exit 1
        fi
    "

    # Test 5: Cross-service communication
    run_test "Cross-Service Communication" "
        # Verificar que servicios puedan comunicarse entre sí
        coord_health=\$(curl -s '$API_BASE_URL/coordinator/health')
        monitor_health=\$(curl -s '$API_BASE_URL/monitoring/health')
        if echo \"\$coord_health\" | grep -q 'ok' && echo \"\$monitor_health\" | grep -q 'ok'; then
            exit 0
        else
            exit 1
        fi
    "

    success "Tests de integración API completados"
}

# Tests de carga básicos
run_load_tests() {
    info "⚡ Ejecutando tests de carga básicos..."

    # Test 1: Múltiples requests concurrentes
    run_test "Concurrent Requests" "
        # Hacer 10 requests concurrentes
        for i in {1..10}; do
            curl -s '$API_BASE_URL/coordinator/health' > /dev/null &
        done
        wait
        exit 0
    "

    # Test 2: Sustained load
    run_test "Sustained Load" "
        # Hacer requests por 10 segundos
        end_time=\$((SECONDS + 10))
        while [ \$SECONDS -lt \$end_time ]; do
            curl -s '$API_BASE_URL/monitoring/health' > /dev/null
            sleep 0.1
        done
        exit 0
    "

    success "Tests de carga completados"
}

# Función para mostrar resultados
display_results() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                  🧪 INTEGRATION TEST RESULTS                 ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""

    echo "Ambiente: $ENVIRONMENT"
    echo "Base URL: $BASE_URL"
    echo "API URL: $API_BASE_URL"
    echo "Timestamp: $(date)"
    echo ""

    for test_name in "${!TEST_RESULTS[@]}"; do
        status="${TEST_RESULTS[$test_name]}"
        if [[ "$status" == "passed" ]]; then
            echo -e "  $test_name: ${GREEN}✅ PASSED${NC}"
        else
            echo -e "  $test_name: ${RED}❌ FAILED${NC}"
        fi
    done

    echo ""
    echo "Resumen:"
    echo "  Total tests: $TOTAL_TESTS"
    echo "  ✅ Passed: $PASSED_TESTS"
    echo "  ❌ Failed: $FAILED_TESTS"
    echo ""

    if [[ "$OVERALL_STATUS" == "passed" ]]; then
        success "Estado general: ALL TESTS PASSED"
    else
        error "Estado general: SOME TESTS FAILED"
    fi
}

# Función para output JSON
output_json() {
    local json_output="{
  \"environment\": \"$ENVIRONMENT\",
  \"base_url\": \"$BASE_URL\",
  \"api_url\": \"$API_BASE_URL\",
  \"timestamp\": \"$(date -Iseconds)\",
  \"overall_status\": \"$OVERALL_STATUS\",
  \"summary\": {
    \"total\": $TOTAL_TESTS,
    \"passed\": $PASSED_TESTS,
    \"failed\": $FAILED_TESTS
  },
  \"tests\": {"

    local first=true
    for test_name in "${!TEST_RESULTS[@]}"; do
        if [[ "$first" == true ]]; then
            first=false
        else
            json_output+=","
        fi
        json_output+="
    \"$test_name\": \"${TEST_RESULTS[$test_name]}\""
    done

    json_output+="
  }
}"

    echo "$json_output"
}

# Main execution
log "🧪 Iniciando tests de integración para ambiente: $ENVIRONMENT"

# Determinar URLs
determine_urls

# Ejecutar suites de tests
run_backend_tests
run_frontend_tests
run_api_tests
run_load_tests

# Mostrar resultados
display_results

if [[ "$JSON_OUTPUT" == true ]]; then
    output_json
fi

# Exit code basado en resultados
if [[ "$OVERALL_STATUS" == "passed" ]]; then
    success "🎉 Todos los tests de integración pasaron exitosamente"
    exit 0
else
    error "💥 Algunos tests de integración fallaron"
    exit 1
fi