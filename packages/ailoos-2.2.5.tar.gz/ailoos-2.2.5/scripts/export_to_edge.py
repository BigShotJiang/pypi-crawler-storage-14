#!/usr/bin/env python3
"""
Export to Edge - Pipeline completo para exportar EmpoorioLM a formatos edge

Este script toma un modelo EmpoorioLM (denso o MoE) y lo exporta a formatos
compatibles con dispositivos edge: ONNX, CoreML, TFLite.

Uso:
    python scripts/export_to_edge.py --model_path models/empoorio_lm/ --output_dir exports/edge/

Características:
- Exportación ONNX con optimizaciones
- Compatibilidad MoE (static routing para ONNX)
- Cuantización dinámica opcional
- Empaquetado con metadatos completos
- Validación de modelos exportados
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

import torch
import torch.nn as nn
import numpy as np

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Añadir el directorio raíz al path
script_dir = Path(__file__).parent
root_dir = script_dir.parent
sys.path.insert(0, str(root_dir))

try:
    from src.ailoos.models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
    from src.ailoos.models.empoorio_lm.tokenizer import EmpoorioLMTokenizer
except ImportError:
    logger.warning("No se pudo importar EmpoorioLM real, usando fallback")
    # Fallback imports para desarrollo
    pass


class EdgeExporter:
    """Exportador completo para modelos edge."""

    def __init__(self, model_path: str, output_dir: str, device: str = "auto"):
        """
        Inicializar exportador edge.

        Args:
            model_path: Ruta al modelo EmpoorioLM
            output_dir: Directorio de salida para exports
            device: Dispositivo para carga del modelo
        """
        self.model_path = Path(model_path)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Determinar dispositivo
        if device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        self.model = None
        self.tokenizer = None
        self.config = None

        logger.info(f"🚀 Inicializando EdgeExporter - Device: {self.device}")

    def load_model(self) -> bool:
        """Cargar modelo EmpoorioLM."""
        try:
            logger.info(f"📥 Cargando modelo desde {self.model_path}")

            # Cargar configuración
            config_path = self.model_path / "config.json"
            if config_path.exists():
                with open(config_path, 'r') as f:
                    config_dict = json.load(f)
                self.config = EmpoorioLMConfig.from_dict(config_dict)
            else:
                logger.warning("Config no encontrada, usando configuración por defecto")
                self.config = EmpoorioLMConfig()

            # Cargar modelo
            self.model = EmpoorioLM(self.config)
            self.model.to(self.device)
            self.model.eval()

            # Cargar tokenizer si existe
            tokenizer_path = self.model_path / "tokenizer.json"
            if tokenizer_path.exists():
                self.tokenizer = EmpoorioLMTokenizer.from_pretrained(str(tokenizer_path))
            else:
                self.tokenizer = EmpoorioLMTokenizer()

            logger.info("✅ Modelo cargado exitosamente")
            model_info = self.model.get_model_info()
            logger.info(f"   Parámetros: {model_info.get('total_parameters', 0):,}")
            logger.info(f"   Arquitectura: {model_info.get('architecture', 'Unknown')}")
            logger.info(f"   Contexto máximo: {self.config.max_position_embeddings}")

            return True

        except Exception as e:
            logger.error(f"❌ Error cargando modelo: {e}")
            return False

    def prepare_for_onnx_export(self, model: nn.Module) -> nn.Module:
        """
        Preparar modelo para exportación ONNX.
        Maneja casos especiales como MoE.
        """
        logger.info("🔧 Preparando modelo para ONNX...")

        # Para MoE, necesitamos manejar el routing dinámico
        if hasattr(model, 'config') and getattr(model.config, 'use_moe', False):
            logger.info("   Detectado modelo MoE - Aplicando static routing para ONNX")
            model = self._convert_moe_for_onnx(model)

        return model

    def _convert_moe_for_onnx(self, model: nn.Module) -> nn.Module:
        """Convertir MoE para compatibilidad ONNX usando static routing."""
        # Para ONNX, necesitamos routing determinístico
        # Una aproximación es usar routing basado en posición del token

        class StaticMoERouter(nn.Module):
            def __init__(self, original_router):
                super().__init__()
                self.num_experts = original_router.num_experts
                self.top_k = original_router.top_k

            def forward(self, x):
                batch_size, seq_len, hidden_size = x.shape
                # Routing simple basado en posición: alternar expertos
                expert_indices = torch.arange(seq_len) % self.num_experts
                expert_indices = expert_indices.unsqueeze(0).expand(batch_size, -1)
                expert_indices = expert_indices.to(x.device)

                # Weights uniformes para simplificar
                weights = torch.ones_like(expert_indices, dtype=x.dtype) / self.top_k

                return weights, expert_indices, torch.tensor(0.0)  # aux_loss dummy

        # Reemplazar routers dinámicos con estáticos
        for block in model.blocks:
            if hasattr(block, 'moe_layer') and block.moe_layer is not None:
                original_router = block.moe_layer.router
                block.moe_layer.router = StaticMoERouter(original_router)

        logger.info("   ✅ MoE convertido para ONNX (static routing)")
        return model

    def export_to_onnx(self, quantize: bool = False) -> bool:
        """Exportar modelo a formato ONNX."""
        try:
            logger.info("📤 Exportando a ONNX...")

            # Preparar modelo
            model_onnx = self.prepare_for_onnx_export(self.model)

            # Cuantización opcional
            if quantize:
                logger.info("   Aplicando cuantización dinámica...")
                model_onnx = self._apply_dynamic_quantization(model_onnx)

            # Crear input dummy
            dummy_input = torch.randint(0, self.config.vocab_size,
                                      (1, self.config.max_position_embeddings // 4),
                                      dtype=torch.long).to(self.device)

            # Ruta de salida
            onnx_path = self.output_dir / "model.onnx"

            # Exportar
            torch.onnx.export(
                model_onnx,
                dummy_input,
                str(onnx_path),
                export_params=True,
                opset_version=14,  # Compatible con móviles
                do_constant_folding=True,
                input_names=['input_ids'],
                output_names=['logits'],
                dynamic_axes={'input_ids': {0: 'batch_size', 1: 'seq_length'},
                             'logits': {0: 'batch_size', 1: 'seq_length'}}
            )

            # Verificar tamaño
            size_mb = onnx_path.stat().st_size / (1024 * 1024)
            logger.info(f"   📊 Tamaño ONNX: {size_mb:.2f} MB")
            return True

        except Exception as e:
            logger.error(f"❌ Error en exportación ONNX: {e}")
            return False

    def _apply_dynamic_quantization(self, model: nn.Module) -> nn.Module:
        """Aplicar cuantización dinámica al modelo."""
        try:
            from torch.quantization import quantize_dynamic
            quantized_model = quantize_dynamic(
                model, {nn.Linear}, dtype=torch.qint8
            )
            logger.info("   ✅ Cuantización aplicada")
            return quantized_model
        except Exception as e:
            logger.warning(f"   ⚠️ Cuantización falló, usando modelo original: {e}")
            return model

    def create_metadata_package(self) -> bool:
        """Crear paquete de metadatos para el modelo edge."""
        try:
            logger.info("📦 Creando paquete de metadatos...")

            metadata = {
                "model_info": {
                    "name": "EmpoorioLM-Edge",
                    "version": "1.0.0",
                    "architecture": self.model.get_model_info().get('architecture', 'GPT-2') if self.model else "GPT-2",
                    "parameters": self.model.get_model_info().get('total_parameters', 0) if self.model else 0,
                    "max_context": self.config.max_position_embeddings if self.config else 1024,
                    "vocab_size": self.config.vocab_size if self.config else 30000
                },
                "export_info": {
                    "format": "ONNX",
                    "opset_version": 14,
                    "quantized": False,  # TODO: detectar si fue cuantizado
                    "device_target": "mobile",
                    "supported_platforms": ["android", "ios", "linux"]
                },
                "tokenizer_config": {
                    "type": "BPE",
                    "vocab_size": self.tokenizer.vocab_size if self.tokenizer else 30000,
                    "max_length": self.config.max_position_embeddings if self.config else 1024,
                    "special_tokens": {
                        "bos_token": "<|endoftext|>",
                        "eos_token": "<|endoftext|>",
                        "unk_token": "<|endoftext|>"
                    }
                },
                "inference_config": {
                    "max_batch_size": 1,
                    "max_sequence_length": self.config.max_position_embeddings if self.config else 1024,
                    "temperature": 1.0,
                    "top_k": 50,
                    "top_p": 0.9,
                    "repetition_penalty": 1.1
                }
            }

            # Guardar metadatos
            metadata_path = self.output_dir / "metadata.json"
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)

            logger.info(f"   ✅ Metadatos guardados en {metadata_path}")
            return True

        except Exception as e:
            logger.error(f"❌ Error creando metadatos: {e}")
            return False

    def validate_export(self) -> bool:
        """Validar que el modelo exportado funciona correctamente."""
        try:
            logger.info("🔍 Validando exportación...")

            # Verificar archivos
            onnx_path = self.output_dir / "model.onnx"
            metadata_path = self.output_dir / "metadata.json"

            if not onnx_path.exists():
                raise FileNotFoundError(f"ONNX file not found: {onnx_path}")

            if not metadata_path.exists():
                raise FileNotFoundError(f"Metadata file not found: {metadata_path}")

            # Verificar tamaño razonable
            size_mb = onnx_path.stat().st_size / (1024 * 1024)
            if size_mb > 5000:  # 5GB límite razonable
                logger.warning(f"   ⚠️ Tamaño ONNX muy grande: {size_mb:.2f} MB")
            # Intentar cargar metadatos
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)

            required_keys = ["model_info", "export_info", "tokenizer_config", "inference_config"]
            for key in required_keys:
                if key not in metadata:
                    raise ValueError(f"Missing required metadata key: {key}")

            logger.info("   ✅ Validación exitosa")
            logger.info(f"   📊 Tamaño ONNX: {size_mb:.2f} MB")
            logger.info(f"   📋 Metadatos: {len(metadata)} campos")

            return True

        except Exception as e:
            logger.error(f"❌ Error en validación: {e}")
            return False

    def run_full_pipeline(self, quantize: bool = False) -> bool:
        """Ejecutar pipeline completo de exportación edge."""
        logger.info("🚀 Iniciando pipeline completo de exportación edge")
        logger.info("=" * 60)

        # Paso 1: Cargar modelo
        if not self.load_model():
            return False

        # Paso 2: Exportar a ONNX
        if not self.export_to_onnx(quantize=quantize):
            return False

        # Paso 3: Crear metadatos
        if not self.create_metadata_package():
            return False

        # Paso 4: Validar
        if not self.validate_export():
            return False

        logger.info("=" * 60)
        logger.info("🎉 Pipeline de exportación completado exitosamente!")
        logger.info(f"📁 Archivos generados en: {self.output_dir}")
        logger.info("   - model.onnx: Modelo ONNX optimizado")
        logger.info("   - metadata.json: Configuración y metadatos")

        return True


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description="Exportar EmpoorioLM a formatos edge")
    parser.add_argument("--model_path", required=True, help="Ruta al modelo EmpoorioLM")
    parser.add_argument("--output_dir", required=True, help="Directorio de salida")
    parser.add_argument("--quantize", action="store_true", help="Aplicar cuantización dinámica")
    parser.add_argument("--device", default="auto", help="Dispositivo (auto/cuda/cpu)")

    args = parser.parse_args()

    # Crear exportador
    exporter = EdgeExporter(
        model_path=args.model_path,
        output_dir=args.output_dir,
        device=args.device
    )

    # Ejecutar pipeline
    success = exporter.run_full_pipeline(quantize=args.quantize)

    if success:
        logger.info("\n🎯 Próximos pasos:")
        logger.info("1. Probar inferencia con ONNX Runtime")
        logger.info("2. Convertir a CoreML: python scripts/convert_to_coreml.py")
        logger.info("3. Convertir a TFLite: python scripts/convert_to_tflite.py")
        logger.info("4. Crear app móvil de demo")
        sys.exit(0)
    else:
        logger.error("\n❌ Pipeline falló - revisar logs para detalles")
        sys.exit(1)


if __name__ == "__main__":
    main()