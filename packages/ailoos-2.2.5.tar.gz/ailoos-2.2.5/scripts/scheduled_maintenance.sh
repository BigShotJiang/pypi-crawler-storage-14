#!/bin/bash
# Scheduled maintenance script for automated pruning of Docker images
# This script can be scheduled with cron for regular maintenance
# Example cron job (weekly on Sunday at 2 AM):
# 0 2 * * 0 /path/to/scheduled_maintenance.sh >> /var/log/ailoos_maintenance.log 2>&1

set -e

# Configuration - modify these variables as needed
PROJECT_ID="${PROJECT_ID:-your-project-id}"
LOCATION="${LOCATION:-europe-west1}"
REPOSITORY="${REPOSITORY:-ailoos-repo}"
DAYS_OLD="${DAYS_OLD:-30}"
LOG_DIR="${LOG_DIR:-/var/log/ailoos}"

# Ensure log directory exists
mkdir -p "$LOG_DIR"

# Generate log file name with timestamp
LOG_FILE="$LOG_DIR/maintenance_$(date +%Y%m%d_%H%M%S).log"

echo "Starting scheduled maintenance at $(date)" | tee "$LOG_FILE"

# Check if required environment variables are set
if [ "$PROJECT_ID" = "your-project-id" ]; then
    echo "ERROR: PROJECT_ID not configured. Please set PROJECT_ID environment variable or modify the script." | tee -a "$LOG_FILE"
    exit 1
fi

if [ -z "$COSIGN_PUBLIC_KEY" ]; then
    echo "WARNING: COSIGN_PUBLIC_KEY not set. Unsigned image pruning will fail." | tee -a "$LOG_FILE"
fi

# Run the maintenance pruning
echo "Running maintenance pruning..." | tee -a "$LOG_FILE"
./maintenance_prune.sh "$PROJECT_ID" "$LOCATION" "$REPOSITORY" "$DAYS_OLD" "$LOG_FILE"

echo "Scheduled maintenance completed at $(date)" | tee -a "$LOG_FILE"

# Optional: Send notification (uncomment and configure as needed)
# curl -X POST -H 'Content-type: application/json' --data '{"text":"Artifact Registry maintenance completed. Check logs at '"$LOG_FILE"'"}' YOUR_SLACK_WEBHOOK_URL

# Optional: Clean up old log files (keep last 10)
echo "Cleaning up old log files..." | tee -a "$LOG_FILE"
ls -t "$LOG_DIR"/maintenance_*.log | tail -n +11 | xargs -r rm
echo "Cleanup completed." | tee -a "$LOG_FILE"