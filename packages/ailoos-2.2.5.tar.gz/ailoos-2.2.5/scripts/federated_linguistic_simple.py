#!/usr/bin/env python3
"""
FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO SIMPLIFICADO
Demuestra aprendizaje colaborativo de lenguaje entre múltiples nodos.
"""

import asyncio
import logging
import torch
import torch.nn as nn
from typing import Dict, List, Any, Optional
from pathlib import Path
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Importar componentes básicos
from ailoos.federated.real_federated_training_loop import (
    RealFederatedTrainingLoop,
    FederatedTrainingConfig,
    create_real_federated_training_loop
)

logger = logging.getLogger(__name__)


class SimpleLinguisticNode:
    """Nodo simple especializado en aprendizaje lingüístico."""

    def __init__(self, node_id: str):
        self.node_id = node_id
        self.model = self._create_simple_model()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)
        self.local_texts = self._generate_texts()
        self.local_data = self._prepare_data()

    def _create_simple_model(self):
        """Crear modelo lingüístico simple."""
        return nn.Sequential(
            nn.Embedding(1000, 64),
            nn.LSTM(64, 32, batch_first=True),
            nn.Linear(32, 1000)
        )

    def _generate_texts(self) -> List[str]:
        """Generar textos locales."""
        base = ["hello world", "machine learning", "ai systems", "neural nets"]
        return [f"{self.node_id} {text}" for text in base] * 5

    def _prepare_data(self) -> List[Dict[str, torch.Tensor]]:
        """Preparar datos de entrenamiento."""
        data = []
        for text in self.local_texts:
            tokens = [ord(c) % 1000 for c in text.lower()][:10]  # Simple encoding
            if len(tokens) > 1:
                input_ids = torch.tensor(tokens[:-1], dtype=torch.long)
                labels = torch.tensor(tokens[1:], dtype=torch.long)
                data.append({'input': input_ids, 'target': labels})
        return data

    async def train_local_round(self, global_weights: Dict[str, torch.Tensor], epochs: int = 3) -> Dict[str, Any]:
        """Entrenar localmente."""
        # Cargar pesos globales
        self.model.load_state_dict(global_weights)

        criterion = nn.CrossEntropyLoss()
        total_loss = 0
        total_acc = 0

        for epoch in range(epochs):
            for batch in self.local_data:
                self.optimizer.zero_grad()
                output = self.model(batch['input'].unsqueeze(0))
                loss = criterion(output.view(-1, 1000), batch['target'])
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item()
                pred = output.argmax(dim=-1)
                acc = (pred == batch['target']).float().mean().item()
                total_acc += acc

        avg_loss = total_loss / (epochs * len(self.local_data))
        avg_acc = total_acc / (epochs * len(self.local_data))

        return {
            "node_id": self.node_id,
            "weights": self.model.state_dict(),
            "samples_processed": len(self.local_data),
            "accuracy": avg_acc,
            "loss": avg_loss,
            "training_time": epochs * 0.1,
            "gradient_norm": 1.0,
            "public_key": f"key_{self.node_id}"
        }


async def demo_federated_linguistic_training():
    """Demo de entrenamiento federado lingüístico."""
    print("🔥 FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO")
    print("=" * 60)
    print("Múltiples nodos colaborando en aprendizaje de lenguaje")
    print()

    # Crear nodos
    nodes = [SimpleLinguisticNode(f"node_{i+1}") for i in range(3)]
    node_ids = [node.node_id for node in nodes]

    print(f"✅ Creados {len(nodes)} nodos lingüísticos:")
    for node in nodes:
        print(f"   - {node.node_id}: {len(node.local_texts)} textos")

    # Configurar sistema federado
    config = FederatedTrainingConfig(
        num_rounds=3,
        min_participants_per_round=len(nodes),
        use_tenseal=False,
        enable_blockchain_rewards=True
    )

    training_loop = create_real_federated_training_loop("linguistic_federated_demo", config)

    # Inicializar
    print("\n🔧 Inicializando sistema federado...")
    await training_loop.initialize_training()

    # Registrar nodos
    print("📝 Registrando nodos...")
    for node in nodes:
        wallet = await training_loop.register_participant(node.node_id, {"type": "linguistic"})
        print(f"   ✅ {node.node_id} -> {wallet[:20]}...")

    # Entrenamiento federado
    print("\n🎯 INICIANDO ENTRENAMIENTO FEDERADO")
    print("=" * 40)

    global_weights = training_loop.model.state_dict()

    for round_num in range(1, config.num_rounds + 1):
        print(f"\n🎯 RONDA {round_num}")
        print("-" * 20)

        # Iniciar ronda
        await training_loop.start_round(round_num, node_ids)

        # Entrenamiento local en cada nodo
        print("🔄 Entrenamiento local...")
        node_updates = {}
        for node in nodes:
            update = await node.train_local_round(global_weights, epochs=2)
            node_updates[node.node_id] = update
            print(".4f")

        # Agregación federada
        print("📦 Agregando actualizaciones...")
        if await training_loop.collect_node_updates(node_updates):
            round_result = await training_loop.aggregate_and_update_global_model()

            print("✅ Resultado de ronda:")
            print(".4f")
            print(".2f")
            print(".2f")

            global_weights = training_loop.model.state_dict()
        else:
            print("❌ Error en agregación")
            break

    # Resultados finales
    print("\n" + "=" * 60)
    print("🎊 RESULTADOS FINALES - APRENDIZAJE FEDERADO LINGÜÍSTICO")
    print("=" * 60)

    stats = training_loop.get_training_stats()
    print(f"✅ Rondas completadas: {len(training_loop.round_results)}")
    print(".2f")
    print(f"🔗 Transacciones: {sum(len(r.blockchain_transactions) for r in training_loop.round_results)}")

    if training_loop.round_results:
        final_loss = training_loop.round_results[-1].global_loss
        initial_loss = training_loop.round_results[0].global_loss
        improvement = (initial_loss - final_loss) / initial_loss * 100

        print("\n📊 MÉTRICAS FINALES:")
        print(f"Loss inicial: {initial_loss:.4f}")
        print(f"Loss final: {final_loss:.4f}")
        print(f"Mejora: {improvement:.1f}%")
        if final_loss < 3.0 and improvement > 30:
            print("\n🎉 ¡APRENDIZAJE FEDERADO LINGÜÍSTICO CONFIRMADO!")
            print("✅ Múltiples nodos colaboraron exitosamente")
            print("✅ Loss lingüística reducida significativamente")
            print("✅ Conocimiento distribuido fusionado")
            print("\n🏆 FASE REAL-7: ÉXITO TOTAL")
            print("💡 El sistema federado APRENDE LENGUAJE COLECTIVAMENTE")
        else:
            print("\n⚠️ Aprendizaje limitado")
    else:
        print("❌ No se completaron rondas")


async def main():
    """Función principal."""
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

    try:
        await demo_federated_linguistic_training()
        return 0
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return 1


if __name__ == "__main__":
    exit(asyncio.run(main()))