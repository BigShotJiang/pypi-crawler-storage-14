#!/usr/bin/env python3
"""
AILOOS Security Penetration Test Script
Tests container security features: Seccomp, cap-drop, read-only filesystem, and privilege escalation attempts.
"""

import os
import sys
import subprocess
import json
import time
from datetime import datetime

class SecurityTester:
    def __init__(self):
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "container": os.environ.get("HOSTNAME", "unknown"),
            "tests": {}
        }

    def run_command(self, cmd, description):
        """Run a command and capture result"""
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            return {
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Timeout"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def test_seccomp(self):
        """Test Seccomp restrictions by attempting blocked syscalls"""
        print("Testing Seccomp restrictions...")

        tests = [
            # Try to use a syscall that might be blocked (using strace as proxy)
            {"cmd": "strace -e trace=all echo 'test'", "desc": "strace system call tracing"},
            # Try to mount something (mount syscall)
            {"cmd": "mount -t tmpfs tmpfs /tmp/test_mount 2>/dev/null || echo 'mount failed'", "desc": "mount syscall"},
            # Try to reboot (should be blocked in containers)
            {"cmd": "reboot 2>/dev/null || echo 'reboot blocked'", "desc": "reboot syscall"},
            # Try to change hostname
            {"cmd": "hostname test-host 2>/dev/null || echo 'hostname change blocked'", "desc": "sethostname syscall"},
        ]

        results = {}
        for test in tests:
            result = self.run_command(test["cmd"], test["desc"])
            results[test["desc"]] = result
            print(f"  {test['desc']}: {'PASS' if not result.get('success', False) else 'FAIL'}")

        self.results["tests"]["seccomp"] = results

    def test_cap_drop(self):
        """Test dropped capabilities"""
        print("Testing dropped capabilities...")

        tests = [
            # Try to use NET_RAW (dropped)
            {"cmd": "ping -c 1 127.0.0.1 2>/dev/null || echo 'ping failed - NET_RAW dropped'", "desc": "NET_RAW capability"},
            # Try to use SYS_ADMIN (dropped) - create namespace
            {"cmd": "unshare -n bash -c 'echo unshared' 2>/dev/null || echo 'unshare blocked - SYS_ADMIN dropped'", "desc": "SYS_ADMIN capability (unshare)"},
            # Try to use SYS_PTRACE (dropped)
            {"cmd": "strace -p 1 2>/dev/null || echo 'ptrace blocked - SYS_PTRACE dropped'", "desc": "SYS_PTRACE capability"},
            # Try to use DAC_OVERRIDE (dropped) - access restricted files
            {"cmd": "cat /etc/shadow 2>/dev/null || echo 'access denied - DAC_OVERRIDE dropped'", "desc": "DAC_OVERRIDE capability"},
        ]

        results = {}
        for test in tests:
            result = self.run_command(test["cmd"], test["desc"])
            results[test["desc"]] = result
            print(f"  {test['desc']}: {'PASS' if not result.get('success', False) else 'FAIL'}")

        self.results["tests"]["cap_drop"] = results

    def test_readonly_filesystem(self):
        """Test read-only filesystem restrictions"""
        print("Testing read-only filesystem...")

        tests = [
            # Try to write to /etc
            {"cmd": "echo 'test' > /etc/test_file 2>/dev/null || echo 'write to /etc blocked'", "desc": "write to /etc"},
            # Try to create directory in root
            {"cmd": "mkdir /test_dir 2>/dev/null || echo 'mkdir in root blocked'", "desc": "create directory in /"},
            # Try to write to /var
            {"cmd": "echo 'test' > /var/test_file 2>/dev/null || echo 'write to /var blocked'", "desc": "write to /var"},
            # Try to modify /etc/passwd
            {"cmd": "echo 'test:x:1001:1001::/home/test:/bin/bash' >> /etc/passwd 2>/dev/null || echo 'modify /etc/passwd blocked'", "desc": "modify /etc/passwd"},
        ]

        results = {}
        for test in tests:
            result = self.run_command(test["cmd"], test["desc"])
            results[test["desc"]] = result
            print(f"  {test['desc']}: {'PASS' if not result.get('success', False) else 'FAIL'}")

        self.results["tests"]["readonly_fs"] = results

    def test_privilege_escalation(self):
        """Test privilege escalation attempts"""
        print("Testing privilege escalation...")

        tests = [
            # Try to exec /bin/bash as root
            {"cmd": "exec /bin/bash -c 'whoami' 2>/dev/null || echo 'exec bash blocked'", "desc": "exec /bin/bash"},
            # Try to use su
            {"cmd": "su - 2>/dev/null || echo 'su blocked'", "desc": "switch user with su"},
            # Try to use sudo
            {"cmd": "sudo id 2>/dev/null || echo 'sudo blocked'", "desc": "sudo command"},
            # Try to change to root user
            {"cmd": "su root 2>/dev/null || echo 'su root blocked'", "desc": "su to root"},
        ]

        results = {}
        for test in tests:
            result = self.run_command(test["cmd"], test["desc"])
            results[test["desc"]] = result
            print(f"  {test['desc']}: {'PASS' if not result.get('success', False) else 'FAIL'}")

        self.results["tests"]["privilege_escalation"] = results

    def test_empoorio_functionality(self):
        """Test that EmpoorioLM functionality still works"""
        print("Testing EmpoorioLM functionality...")

        # Try to make a request to the health endpoint
        result = self.run_command("curl -f http://localhost:8000/health 2>/dev/null || echo 'health check failed'", "health check")
        self.results["tests"]["empoorio_health"] = result
        print(f"  EmpoorioLM health: {'PASS' if result.get('success', False) else 'FAIL'}")

    def run_all_tests(self):
        """Run all security tests"""
        print("Starting AILOOS Security Penetration Tests")
        print("=" * 50)

        self.test_seccomp()
        print()
        self.test_cap_drop()
        print()
        self.test_readonly_filesystem()
        print()
        self.test_privilege_escalation()
        print()
        self.test_empoorio_functionality()

        print("\n" + "=" * 50)
        print("Tests completed. Generating report...")

    def generate_report(self):
        """Generate JSON report"""
        return json.dumps(self.results, indent=2)

    def save_report(self, filename="security_test_report.json"):
        """Save results to file"""
        with open(filename, 'w') as f:
            f.write(self.generate_report())
        print(f"Report saved to {filename}")

if __name__ == "__main__":
    tester = SecurityTester()
    tester.run_all_tests()
    print("\nReport:")
    print(tester.generate_report())
    tester.save_report()