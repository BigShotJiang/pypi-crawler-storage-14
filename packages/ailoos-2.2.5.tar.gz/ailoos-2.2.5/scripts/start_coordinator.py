#!/usr/bin/env python3
"""
Script to start the AILOOS Coordinator with EmpoorioLM service.
This script initializes and starts the complete AILOOS system.
"""

import sys
import os
import logging
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Import hardware detector
from hardware_detector import HardwareDetector, save_config

def main():
    """Main entry point."""
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(name)s | %(levelname)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    logger = logging.getLogger(__name__)
    logger.info("🚀 Starting AILOOS Coordinator with EmpoorioLM...")

    # Hardware detection and role assignment
    try:
        logger.info("🔍 Running hardware detection and role assignment...")
        detector = HardwareDetector()
        config = detector.run()

        # Save configuration
        save_config(config)

        # Set environment variables based on detected config
        os.environ["AILOOS_NODE_ROLE"] = config["node_role"]
        os.environ["AILOOS_DEVICE"] = config["inference_config"]["device"]
        os.environ["AILOOS_MAX_BATCH_SIZE"] = str(config["inference_config"]["max_batch_size"])
        os.environ["AILOOS_PRECISION"] = config["inference_config"]["precision"]

        logger.info(f"✅ Hardware detection completed. Assigned role: {config['node_role']}, Device: {config['inference_config']['device']}")

    except Exception as e:
        logger.error(f"❌ Hardware detection failed: {e}")
        logger.warning("Continuing with default configuration...")
        # Continue without exiting to allow startup even if detection fails

    try:
        # Import and create application
        from ailoos.coordinator.main import create_application

        # Create FastAPI app
        app = create_application()
        logger.info("✅ FastAPI application created successfully")

        # Import uvicorn for serving
        import uvicorn

        # Get configuration from environment or defaults
        host = os.getenv("AILOOS_HOST", "0.0.0.0")
        port = int(os.getenv("AILOOS_PORT", "8000"))
        reload = os.getenv("AILOOS_RELOAD", "false").lower() == "true"
        log_level = os.getenv("AILOOS_LOG_LEVEL", "info")

        logger.info(f"🌐 Starting server on {host}:{port}")
        logger.info(f"📚 API Documentation: http://{host}:{port}/docs")
        logger.info(f"🔄 Realtime Dashboard: http://{host}:{port}/redoc")

        # Start server
        uvicorn.run(
            app,
            host=host,
            port=port,
            reload=reload,
            log_level=log_level,
            access_log=True,
            server_header=False,  # Hide server info for security
            date_header=False     # Hide date for security
        )

    except KeyboardInterrupt:
        logger.info("⏹️ Server stopped by user")
    except Exception as e:
        logger.error(f"❌ Failed to start coordinator: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()