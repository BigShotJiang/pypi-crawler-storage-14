#!/bin/bash

# AILOOS Health Check Script
# Verifica la salud de todos los servicios del sistema

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

info() {
    echo -e "${PURPLE}ℹ️  $1${NC}"
}

# Función de ayuda
usage() {
    echo "Uso: $0 [OPTIONS]"
    echo ""
    echo "Verifica la salud de todos los servicios de AILOOS"
    echo ""
    echo "OPTIONS:"
    echo "  -e, --environment ENV    Ambiente (staging|production) [default: staging]"
    echo "  -t, --timeout SEC         Timeout por check en segundos [default: 30]"
    echo "  -v, --verbose             Output detallado"
    echo "  -j, --json                Output en formato JSON"
    echo "  -h, --help                Mostrar esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 --environment production"
    echo "  $0 -e staging --verbose"
    echo "  $0 --json > health_report.json"
}

# Valores por defecto
ENVIRONMENT="staging"
TIMEOUT=30
VERBOSE=false
JSON_OUTPUT=false

# Parsear argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -t|--timeout)
            TIMEOUT="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -j|--json)
            JSON_OUTPUT=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Opción desconocida: $1"
            usage
            exit 1
            ;;
    esac
done

# Variables globales para resultados
OVERALL_STATUS="healthy"

# Función para actualizar estado general
update_overall_status() {
    local status=$1
    if [[ "$status" == "unhealthy" && "$OVERALL_STATUS" == "healthy" ]]; then
        OVERALL_STATUS="unhealthy"
    elif [[ "$status" == "warning" && "$OVERALL_STATUS" == "healthy" ]]; then
        OVERALL_STATUS="warning"
    fi
}

# Función para hacer HTTP requests con timeout
http_check() {
    local url=$1
    local expected_code=${2:-200}
    local name=$3

    if [[ "$VERBOSE" == true ]]; then
        log "Verificando $name: $url"
    fi

    local response
    local http_code

    # Usar curl con timeout
    if response=$(curl -s -w "HTTPSTATUS:%{http_code};TIME:%{time_total}" \
                  --max-time "$TIMEOUT" \
                  --connect-timeout 10 \
                  "$url" 2>/dev/null); then

        http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://' | sed -e 's/;TIME.*//')
        local time=$(echo "$response" | tr -d '\n' | sed -e 's/.*TIME://')

        if [[ "$http_code" == "$expected_code" ]]; then
            eval "RESULT_${name// /_}=\"healthy\""
            if [[ "$VERBOSE" == true ]]; then
                success "$name: HTTP $http_code (${time}s)"
            fi
            return 0
        else
            eval "RESULT_${name// /_}=\"unhealthy\""
            update_overall_status "unhealthy"
            if [[ "$VERBOSE" == true ]]; then
                error "$name: HTTP $http_code (esperado $expected_code) (${time}s)"
            fi
            return 1
        fi
    else
        eval "RESULT_${name// /_}=\"unhealthy\""
        update_overall_status "unhealthy"
        if [[ "$VERBOSE" == true ]]; then
            error "$name: Conexión fallida (timeout ${TIMEOUT}s)"
        fi
        return 1
    fi
}

# Función para verificar base de datos
db_check() {
    local db_url=$1
    local name=$2

    if [[ "$VERBOSE" == true ]]; then
        log "Verificando $name"
    fi

    # Extraer componentes de la URL de PostgreSQL
    # postgresql://user:pass@host:port/db?params
    local db_host db_port db_name db_user

    if [[ $db_url =~ postgresql://([^:]+):([^@]+)@([^:]+):([^/]+)/([^?]+) ]]; then
        db_user="${BASH_REMATCH[1]}"
        # password = BASH_REMATCH[2] (no la usamos por seguridad)
        db_host="${BASH_REMATCH[3]}"
        db_port="${BASH_REMATCH[4]}"
        db_name="${BASH_REMATCH[5]}"
    else
        eval "RESULT_${name// /_}=\"unhealthy\""
        update_overall_status "unhealthy"
        if [[ "$VERBOSE" == true ]]; then
            error "$name: URL de base de datos inválida"
        fi
        return 1
    fi

    # Intentar conexión simple (esto requiere psql instalado)
    if command -v psql &> /dev/null; then
        if PGPASSWORD="${DB_PASSWORD:-default}" psql -h "$db_host" -p "$db_port" -U "$db_user" -d "$db_name" -c "SELECT 1;" --quiet --no-align --tuples-only &>/dev/null; then
            eval "RESULT_${name// /_}=\"healthy\""
            if [[ "$VERBOSE" == true ]]; then
                success "$name: Conexión exitosa"
            fi
            return 0
        else
            eval "RESULT_${name// /_}=\"unhealthy\""
            update_overall_status "unhealthy"
            if [[ "$VERBOSE" == true ]]; then
                error "$name: Falló conexión a BD"
            fi
            return 1
        fi
    else
        # Fallback: intentar TCP connection
        if timeout 5 bash -c "echo > /dev/tcp/$db_host/$db_port" 2>/dev/null; then
            eval "RESULT_${name// /_}=\"healthy\""
            if [[ "$VERBOSE" == true ]]; then
                success "$name: Puerto accesible"
            fi
            return 0
        else
            eval "RESULT_${name// /_}=\"unhealthy\""
            update_overall_status "unhealthy"
            if [[ "$VERBOSE" == true ]]; then
                error "$name: Puerto no accesible"
            fi
            return 1
        fi
    fi
}

# Función para verificar Redis
redis_check() {
    local redis_url=$1
    local name=$2

    if [[ "$VERBOSE" == true ]]; then
        log "Verificando $name"
    fi

    # Extraer host y puerto de Redis URL
    # redis://host:port
    local redis_host redis_port

    if [[ $redis_url =~ redis://([^:]+):([0-9]+) ]]; then
        redis_host="${BASH_REMATCH[1]}"
        redis_port="${BASH_REMATCH[2]}"
    else
        eval "RESULT_${name// /_}=\"unhealthy\""
        update_overall_status "unhealthy"
        if [[ "$VERBOSE" == true ]]; then
            error "$name: URL de Redis inválida"
        fi
        return 1
    fi

    # Verificar conectividad TCP
    if timeout 5 bash -c "echo > /dev/tcp/$redis_host/$redis_port" 2>/dev/null; then
        eval "RESULT_${name// /_}=\"healthy\""
        if [[ "$VERBOSE" == true ]]; then
            success "$name: Puerto accesible"
        fi
        return 0
    else
        eval "RESULT_${name// /_}=\"unhealthy\""
        update_overall_status "unhealthy"
        if [[ "$VERBOSE" == true ]]; then
            error "$name: Puerto no accesible"
        fi
        return 1
    fi
}

# Cargar configuración del backend
load_backend_config() {
    local config_file="backend_config_$ENVIRONMENT.json"

    if [[ ! -f "$config_file" ]]; then
        warning "Archivo de configuración $config_file no encontrado"
        return 1
    fi

    if command -v jq &> /dev/null; then
        GATEWAY_URL=$(jq -r '.gateway_url' "$config_file")
        PROJECT_ID=$(jq -r '.project_id' "$config_file")
        REGION=$(jq -r '.region' "$config_file")

        # Leer servicios
        while IFS='=' read -r service_name service_url; do
            eval "SERVICE_$service_name=\"$service_url\""
        done < <(jq -r '.services | to_entries[] | "\(.key)=\(.value)"' "$config_file")
    else
        # Fallback sin jq
        GATEWAY_URL=$(grep '"gateway_url"' "$config_file" | sed 's/.*"gateway_url": "\([^"]*\)".*/\1/')
        PROJECT_ID=$(grep '"project_id"' "$config_file" | sed 's/.*"project_id": "\([^"]*\)".*/\1/')
        REGION=$(grep '"region"' "$config_file" | sed 's/.*"region": "\([^"]*\)".*/\1/')
    fi

    return 0
}

# Función principal de health check
perform_health_checks() {
    log "🏥 Iniciando verificación de salud para ambiente: $ENVIRONMENT"

    # Cargar configuración
    if ! load_backend_config; then
        warning "Usando configuración por defecto"
        # Configuración por defecto
        if [[ "$ENVIRONMENT" == "production" ]]; then
            GATEWAY_URL="https://ailoos-gateway-production-[hash].uc.gateway.dev"
            COORDINATOR_URL="https://ailoos-coordinator-api-production-[hash]-uc.a.run.app"
            COMPLIANCE_URL="https://ailoos-compliance-api-production-[hash]-uc.a.run.app"
            DASHBOARD_URL="https://ailoos-dashboard-api-production-[hash]-uc.a.run.app"
            MONITORING_URL="https://ailoos-monitoring-api-production-[hash]-uc.a.run.app"
            INTEGRATION_URL="https://ailoos-integration-api-production-[hash]-uc.a.run.app"
            FRONTEND_URL="https://ailoos.dev"
        else
            GATEWAY_URL="https://ailoos-gateway-staging-[hash].uc.gateway.dev"
            COORDINATOR_URL="https://ailoos-coordinator-api-staging-[hash]-uc.a.run.app"
            COMPLIANCE_URL="https://ailoos-compliance-api-staging-[hash]-uc.a.run.app"
            DASHBOARD_URL="https://ailoos-dashboard-api-staging-[hash]-uc.a.run.app"
            MONITORING_URL="https://ailoos-monitoring-api-staging-[hash]-uc.a.run.app"
            INTEGRATION_URL="https://ailoos-integration-api-staging-[hash]-uc.a.run.app"
            FRONTEND_URL="https://staging.ailoos.dev"
        fi
    else
        COORDINATOR_URL=$(eval "echo \$SERVICE_coordinator")
        COMPLIANCE_URL=$(eval "echo \$SERVICE_compliance")
        DASHBOARD_URL=$(eval "echo \$SERVICE_dashboard")
        MONITORING_URL=$(eval "echo \$SERVICE_monitoring")
        INTEGRATION_URL=$(eval "echo \$SERVICE_integration")
        FRONTEND_URL="https://$ENVIRONMENT.ailoos.dev"
    fi

    # 1. Verificar API Gateway
    http_check "$GATEWAY_URL/health" 200 "API Gateway"

    # 2. Verificar servicios backend individuales
    http_check "$COORDINATOR_URL/health" 200 "Coordinator API"
    http_check "$COMPLIANCE_URL/health" 200 "Compliance API"
    http_check "$DASHBOARD_URL/health" 200 "Dashboard API"
    http_check "$MONITORING_URL/health" 200 "Monitoring API"
    http_check "$INTEGRATION_URL/health" 200 "Integration API"

    # 3. Verificar frontend
    http_check "$FRONTEND_URL" 200 "Frontend"

    # 4. Verificar base de datos (si tenemos credenciales)
    if [[ -n "${DATABASE_URL:-}" ]]; then
        db_check "$DATABASE_URL" "Database"
    else
        eval "RESULT_Database=\"unknown\""
        if [[ "$VERBOSE" == true ]]; then
            warning "Database: Sin credenciales para verificar"
        fi
    fi

    # 5. Verificar Redis (si tenemos URL)
    if [[ -n "${REDIS_URL:-}" ]]; then
        redis_check "$REDIS_URL" "Redis Cache"
    else
        eval "RESULT_Redis_Cache=\"unknown\""
        if [[ "$VERBOSE" == true ]]; then
            warning "Redis Cache: Sin URL para verificar"
        fi
    fi

    # 6. Verificar servicios externos críticos
    # OpenAI API (simulación)
    if [[ -n "${OPENAI_API_KEY:-}" ]]; then
        # Aquí podríamos hacer un ping simple a la API
        eval "RESULT_OpenAI_API=\"healthy\""  # Asumir healthy si tenemos la key
    else
        eval "RESULT_OpenAI_API=\"unknown\""
    fi

    success "Verificación de salud completada"
}

# Función para mostrar resultados
display_results() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                     🏥 HEALTH CHECK RESULTS                  ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""

    echo "Ambiente: $ENVIRONMENT"
    echo "Timestamp: $(date)"
    echo ""

    local healthy_count=0
    local unhealthy_count=0
    local warning_count=0
    local unknown_count=0

    local services_list=("API Gateway" "Coordinator API" "Compliance API" "Dashboard API" "Monitoring API" "Integration API" "Frontend" "Database" "Redis Cache" "OpenAI API")

    for service in "${services_list[@]}"; do
        status=$(eval "echo \$RESULT_${service// /_}")
        case $status in
            healthy)
                echo -e "  $service: ${GREEN}✅ Healthy${NC}"
                ((healthy_count++))
                ;;
            unhealthy)
                echo -e "  $service: ${RED}❌ Unhealthy${NC}"
                ((unhealthy_count++))
                ;;
            warning)
                echo -e "  $service: ${YELLOW}⚠️  Warning${NC}"
                ((warning_count++))
                ;;
            unknown)
                echo -e "  $service: ${BLUE}❓ Unknown${NC}"
                ((unknown_count++))
                ;;
        esac
    done

    echo ""
    echo "Resumen:"
    echo "  ✅ Healthy: $healthy_count"
    echo "  ❌ Unhealthy: $unhealthy_count"
    echo "  ⚠️  Warning: $warning_count"
    echo "  ❓ Unknown: $unknown_count"
    echo ""

    case $OVERALL_STATUS in
        healthy)
            success "Estado general: HEALTHY"
            return 0
            ;;
        warning)
            warning "Estado general: WARNING"
            return 0
            ;;
        unhealthy)
            error "Estado general: UNHEALTHY"
            return 1
            ;;
    esac
}

# Función para output JSON
output_json() {
    local json_output="{
  \"environment\": \"$ENVIRONMENT\",
  \"timestamp\": \"$(date -Iseconds)\",
  \"overall_status\": \"$OVERALL_STATUS\",
  \"services\": {"

    local first=true
    local services_list=("API Gateway" "Coordinator API" "Compliance API" "Dashboard API" "Monitoring API" "Integration API" "Frontend" "Database" "Redis Cache" "OpenAI API")

    for service in "${services_list[@]}"; do
        local status=$(eval "echo \$RESULT_${service// /_}")
        if [[ "$first" == true ]]; then
            first=false
        else
            json_output+=","
        fi
        json_output+="
    \"$service\": \"$status\""
    done

    json_output+="
  }
}"

    echo "$json_output"
}

# Main execution
perform_health_checks
display_results

if [[ "$JSON_OUTPUT" == true ]]; then
    output_json
fi

# Exit code basado en estado general
case $OVERALL_STATUS in
    healthy|warning)
        exit 0
        ;;
    unhealthy)
        exit 1
        ;;
esac
