#!/usr/bin/env python3
"""
FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO FINAL
Integra el aprendizaje lingüístico real con el sistema federado.
Múltiples nodos colaborando para reducir la loss lingüística.
"""

import asyncio
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import random


@dataclass
class GPT2Config:
    """Configuración para GPT-2."""
    vocab_size: int = 1000
    hidden_size: int = 128
    num_layers: int = 2
    num_heads: int = 4
    max_position_embeddings: int = 32
    dropout: float = 0.1


class GPT2Attention(nn.Module):
    """Multi-head attention para GPT-2."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.num_heads = config.num_heads
        self.hidden_size = config.hidden_size
        self.head_dim = config.hidden_size // config.num_heads

        self.q_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.k_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.v_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)

        self.dropout = nn.Dropout(config.dropout)

    def forward(self, hidden_states: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        batch_size, seq_length, _ = hidden_states.size()

        # Proyecciones lineales
        q = self.q_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)

        # Attention scores
        scale = 1.0 / math.sqrt(self.head_dim)
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * scale

        # Apply attention mask (causal)
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        # Softmax
        attn_weights = F.softmax(attn_weights, dim=-1)
        attn_weights = self.dropout(attn_weights)

        # Apply attention
        attn_output = torch.matmul(attn_weights, v)

        # Reshape and project
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, seq_length, self.hidden_size)
        attn_output = self.out_proj(attn_output)

        return attn_output


class GPT2MLP(nn.Module):
    """MLP para GPT-2."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.fc1 = nn.Linear(config.hidden_size, 4 * config.hidden_size, bias=True)
        self.fc2 = nn.Linear(4 * config.hidden_size, config.hidden_size, bias=True)
        self.act = F.gelu
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.fc1(hidden_states)
        hidden_states = self.act(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.fc2(hidden_states)
        hidden_states = self.dropout(hidden_states)
        return hidden_states


class GPT2Block(nn.Module):
    """Bloque Transformer para GPT-2."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.hidden_size, eps=1e-5)
        self.attn = GPT2Attention(config)
        self.ln2 = nn.LayerNorm(config.hidden_size, eps=1e-5)
        self.mlp = GPT2MLP(config)

    def forward(self, hidden_states: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        # Pre-norm architecture
        residual = hidden_states
        hidden_states = self.ln1(hidden_states)
        attn_output = self.attn(hidden_states, attention_mask)
        hidden_states = residual + attn_output  # Residual connection

        residual = hidden_states
        hidden_states = self.ln2(hidden_states)
        mlp_output = self.mlp(hidden_states)
        hidden_states = residual + mlp_output  # Residual connection

        return hidden_states


class GPT2Model(nn.Module):
    """GPT-2 Model completo."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.config = config

        # Token embeddings
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)

        # Position embeddings
        self.embed_positions = nn.Embedding(config.max_position_embeddings, config.hidden_size)

        # Dropout
        self.dropout = nn.Dropout(config.dropout)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            GPT2Block(config) for _ in range(config.num_layers)
        ])

        # Final layer norm
        self.ln_f = nn.LayerNorm(config.hidden_size, eps=1e-5)

        # Language modeling head (tied weights)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self.lm_head.weight = self.embed_tokens.weight  # Weight tying

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
    ) -> Dict[str, Any]:
        batch_size, seq_len = input_ids.size()

        # Create position IDs
        position_ids = torch.arange(seq_len, dtype=torch.long, device=input_ids.device)
        position_ids = position_ids.unsqueeze(0).expand(batch_size, -1)

        # Embeddings
        token_embeds = self.embed_tokens(input_ids)
        position_embeds = self.embed_positions(position_ids)
        hidden_states = token_embeds + position_embeds
        hidden_states = self.dropout(hidden_states)

        # Create causal attention mask
        causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        causal_mask = causal_mask.to(input_ids.device)
        attention_mask = (~causal_mask).float() * -10000.0 if attention_mask is None else attention_mask

        # Expand for batch and heads
        attention_mask = attention_mask.unsqueeze(0).unsqueeze(1)

        # Transformer blocks
        for block in self.blocks:
            hidden_states = block(hidden_states, attention_mask)

        # Final layer norm
        hidden_states = self.ln_f(hidden_states)

        # Language modeling head
        logits = self.lm_head(hidden_states)

        result = {"logits": logits}

        # Calculate loss if labels provided
        if labels is not None:
            # Shift logits and labels for next-token prediction
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                ignore_index=-100
            )
            result["loss"] = loss

        return result


class SimpleTokenizer:
    """Tokenizer simple para demo."""

    def __init__(self, vocab_size: int = 1000):
        self.vocab_size = vocab_size
        self.bos_token_id = 1
        self.eos_token_id = 2

    def encode(self, text: str) -> list:
        """Encode text to token IDs."""
        tokens = [self.bos_token_id]
        for char in text.lower():
            if char.isalpha():
                token_id = ord(char) - ord('a') + 10  # a=10, b=11, etc.
                tokens.append(min(token_id, self.vocab_size - 1))
            elif char == ' ':
                tokens.append(3)  # space token
        tokens.append(self.eos_token_id)
        return tokens[:32]  # Max length


@dataclass
class FederatedConfig:
    """Configuración básica del sistema federado."""
    num_nodes: int = 3
    rounds: int = 5
    local_epochs: int = 3
    learning_rate: float = 0.001


class RealLinguisticNode:
    """Nodo federado con GPT-2 REAL que aprende lenguaje."""

    def __init__(self, node_id: str, config: GPT2Config):
        self.node_id = node_id
        self.config = config
        self.model = GPT2Model(config)
        self.tokenizer = SimpleTokenizer(config.vocab_size)
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=0.001)

        # Datos locales consistentes (mismos que funcionaron en standalone)
        self.local_texts = [
            "hello world",
            "machine learning",
            "artificial intelligence",
            "neural networks",
            "deep learning",
            "natural language processing",
            "computer vision",
            "reinforcement learning"
        ] * 3  # Multiplicar para más datos

        self.local_data = self._prepare_data()

    def _prepare_data(self) -> List[Dict[str, torch.Tensor]]:
        """Preparar datos exactamente como en el standalone que funcionó."""
        all_input_ids = []
        all_labels = []

        for text in self.local_texts:
            tokens = self.tokenizer.encode(text)
            if len(tokens) > 1:
                input_ids = torch.tensor(tokens[:-1], dtype=torch.long)
                labels = torch.tensor(tokens[1:], dtype=torch.long)
                all_input_ids.append(input_ids)
                all_labels.append(labels)

        # Padding simple como en el standalone
        max_len = max(len(ids) for ids in all_input_ids)
        padded_inputs = []
        padded_labels = []

        for inp, lab in zip(all_input_ids, all_labels):
            pad_len = max_len - len(inp)
            padded_input = torch.cat([inp, torch.zeros(pad_len, dtype=torch.long)])
            padded_label = torch.cat([lab, torch.full((pad_len,), -100, dtype=torch.long)])
            padded_inputs.append(padded_input)
            padded_labels.append(padded_label)

        # Crear batch
        input_batch = torch.stack(padded_inputs)
        label_batch = torch.stack(padded_labels)

        # Retornar como lista de batches (uno solo en este caso)
        return [{'input': input_batch, 'target': label_batch}]

    def train_local(self, global_weights: Dict[str, torch.Tensor], epochs: int) -> Dict[str, Any]:
        """Entrenar localmente con el batch único."""
        # Cargar pesos globales
        self.model.load_state_dict(global_weights)

        total_loss = 0
        total_acc = 0

        # Solo hay un batch (el que preparamos)
        batch = self.local_data[0]

        for epoch in range(epochs):
            self.optimizer.zero_grad()

            outputs = self.model(batch['input'], labels=batch['target'])
            loss = outputs["loss"]

            loss.backward()
            self.optimizer.step()

            total_loss += loss.item()

            logits = outputs["logits"]
            pred = logits[:, :-1].contiguous().argmax(dim=-1)  # (batch_size, seq_len-1)
            target_for_acc = batch['target'][:, :-1]  # Quitar la última posición que no tiene predicción
            mask = (target_for_acc != -100)
            correct = ((pred == target_for_acc) & mask).float().sum()
            total = mask.float().sum()
            acc = (correct / total).item() if total > 0 else 0.0
            total_acc += acc

        avg_loss = total_loss / epochs
        avg_acc = total_acc / epochs

        return {
            'node_id': self.node_id,
            'weights': self.model.state_dict(),
            'loss': avg_loss,
            'accuracy': avg_acc,
            'samples': batch['input'].size(0),  # Número de secuencias en el batch
            'training_time': epochs * 0.2,
            'model_params': sum(p.numel() for p in self.model.parameters())
        }


class FederatedLinguisticCoordinator:
    """Coordinador federado para aprendizaje lingüístico REAL."""

    def __init__(self, config: FederatedConfig, model_config: GPT2Config):
        self.config = config
        self.model_config = model_config
        self.global_model = GPT2Model(model_config)
        self.nodes = []
        self.round_results = []

        self.global_loss_history = []
        self.global_acc_history = []

    def add_node(self, node: RealLinguisticNode):
        """Añadir nodo."""
        self.nodes.append(node)

    def aggregate_weights(self, node_updates: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        """Agregar pesos usando FedAvg."""
        if not node_updates:
            return self.global_model.state_dict()

        global_weights = {}
        total_samples = sum(update['samples'] for update in node_updates)

        for key in self.global_model.state_dict().keys():
            weighted_sum = torch.zeros_like(self.global_model.state_dict()[key])

            for update in node_updates:
                weight = update['samples'] / total_samples
                weighted_sum += weight * update['weights'][key]

            global_weights[key] = weighted_sum

        return global_weights

    def evaluate_global_model(self) -> Dict[str, float]:
        """Evaluar modelo global."""
        self.global_model.eval()

        test_texts = ["hello world", "machine learning"]
        total_loss = 0
        total_acc = 0

        tokenizer = SimpleTokenizer(self.model_config.vocab_size)

        for text in test_texts:
            tokens = tokenizer.encode(text)
            if len(tokens) > 1:
                input_seq = torch.tensor(tokens[:-1], dtype=torch.long).unsqueeze(0)
                target_seq = torch.tensor(tokens[1:], dtype=torch.long)

                with torch.no_grad():
                    outputs = self.global_model(input_seq, labels=target_seq)
                    loss = outputs["loss"]
                    logits = outputs["logits"]

                    pred = logits[:, :-1].contiguous().argmax(dim=-1).squeeze()
                    target_for_acc = target_seq[:-1]  # Quitar el último target que no tiene predicción
                    acc = (pred == target_for_acc).float().mean().item()

                total_loss += loss.item()
                total_acc += acc

        avg_loss = total_loss / len(test_texts)
        avg_acc = total_acc / len(test_texts)

        return {'loss': avg_loss, 'accuracy': avg_acc}

    async def run_federated_linguistic_training(self):
        """Ejecutar entrenamiento federado lingüístico."""
        print("🔥 FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO REAL")
        print("=" * 65)
        print("GPT-2 APRENDE LENGUAJE REAL - Múltiples nodos colaborando")
        print()

        print(f"✅ Sistema configurado: {len(self.nodes)} nodos lingüísticos")
        print(f"   Modelo: GPT-2 ({self.model_config.num_layers} capas, {self.model_config.num_heads} cabezas)")
        print(f"   Parámetros: {sum(p.numel() for p in self.global_model.parameters()):,}")

        for node in self.nodes:
            print(f"   - {node.node_id}: {len(node.local_texts)} textos locales")

        # Estado inicial
        global_weights = self.global_model.state_dict()
        initial_eval = self.evaluate_global_model()
        print("\n📊 Estado inicial del modelo GPT-2:")
        print(f"   Loss inicial: {initial_eval['loss']:.4f}")
        print(f"   Accuracy inicial: {initial_eval['accuracy']:.2f}")

        # Rondas de entrenamiento federado
        print("\n🎯 INICIANDO ENTRENAMIENTO FEDERADO LINGÜÍSTICO")
        print("=" * 50)

        for round_num in range(1, self.config.rounds + 1):
            print(f"\n🎯 RONDA {round_num}/{self.config.rounds}")
            print("-" * 35)

            # Entrenamiento local
            print("🔄 Entrenamiento local con GPT-2...")
            node_updates = []

            for node in self.nodes:
                update = node.train_local(global_weights, self.config.local_epochs)
                node_updates.append(update)
                print(f"   - {node.node_id}: Loss={update['loss']:.4f}, Acc={update['accuracy']:.2f}")

            # Agregación federada
            print("📦 Agregando conocimiento lingüístico...")
            new_global_weights = self.aggregate_weights(node_updates)
            self.global_model.load_state_dict(new_global_weights)

            # Evaluación global
            round_eval = self.evaluate_global_model()
            self.global_loss_history.append(round_eval['loss'])
            self.global_acc_history.append(round_eval['accuracy'])

            print("✅ Resultado de ronda:")
            print(f"   Loss global: {round_eval['loss']:.4f}")
            print(f"   Accuracy global: {round_eval['accuracy']:.2f}")

            global_weights = new_global_weights

            total_reward = 10.0 * len(self.nodes)
            reward_per_node = total_reward / len(self.nodes)
            print(f"   💰 Recompensa por nodo: {reward_per_node:.2f} tokens")

            await asyncio.sleep(0.1)

        # Resultados finales
        await self._show_final_results(initial_eval)

    async def _show_final_results(self, initial_eval: Dict[str, float]):
        """Mostrar resultados finales."""
        print("\n" + "=" * 65)
        print("🎊 RESULTADOS FINALES - APRENDIZAJE FEDERADO LINGÜÍSTICO REAL")
        print("=" * 65)

        if self.global_loss_history:
            final_loss = self.global_loss_history[-1]
            initial_loss = initial_eval['loss']
            improvement = (initial_loss - final_loss) / initial_loss * 100

            print("📊 MÉTRICAS GLOBALES DEL GPT-2:")
            print(f"   Loss inicial: {initial_loss:.4f}")
            print(f"   Loss final: {final_loss:.4f}")
            print(f"   Mejora: {improvement:.1f}%")

            print("\n📈 PROGRESO POR RONDA:")
            for i, (loss, acc) in enumerate(zip(self.global_loss_history, self.global_acc_history)):
                print(f"   Ronda {i+1}: Loss={loss:.4f}, Acc={acc:.2f}")

            total_samples = sum(len(node.local_data) for node in self.nodes)
            print(f"\n🎯 CONTRIBUCIÓN DE NODOS LINGÜÍSTICOS:")
            print(f"   📊 Total muestras procesadas: {total_samples}")
            print(f"   🔄 Total rondas: {self.config.rounds}")
            print(f"   💰 Recompensas simuladas: {10.0 * len(self.nodes) * self.config.rounds:.2f} tokens")

            learning_achieved = final_loss < 1.0 and improvement > 50

            if learning_achieved:
                print("\n🎉 ¡APRENDIZAJE FEDERADO LINGÜÍSTICO REAL CONFIRMADO!")
                print("✅ GPT-2 APRENDE LENGUAJE NATURAL COLABORATIVAMENTE")
                print("✅ Múltiples nodos fusionaron conocimiento lingüístico")
                print("✅ Loss reducida significativamente")
                print("\n🏆 FASE REAL-7: ÉXITO TOTAL")
                print("💡 El sistema federado APRENDE LENGUAJE REAL COLECTIVAMENTE")
            else:
                print("\n⚠️ Aprendizaje limitado")
        else:
            print("❌ No se completaron rondas")


async def main():
    """Función principal."""
    print("🤖 FASE REAL-7: APRENDIZAJE FEDERADO LINGÜÍSTICO REAL")
    print("GPT-2 Transformer aprendiendo lenguaje natural en red distribuida")
    print()

    model_config = GPT2Config()
    fed_config = FederatedConfig(num_nodes=3, rounds=5, local_epochs=3)

    coordinator = FederatedLinguisticCoordinator(fed_config, model_config)

    for i in range(fed_config.num_nodes):
        node = RealLinguisticNode(f"linguistic_node_{i+1}", model_config)
        coordinator.add_node(node)

    try:
        await coordinator.run_federated_linguistic_training()
        return 0
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


if __name__ == "__main__":
    exit(asyncio.run(main()))