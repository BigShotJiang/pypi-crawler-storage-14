#!/usr/bin/env python3
"""
FASE REAL-8 DIAGNÓSTICO: Debugging del Sistema Federado Lingüístico
Identifica exactamente por qué diverge el modelo y accuracy = 0.0
"""

import asyncio
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import random
import time


@dataclass
class DiagnosticConfig:
    """Configuración para diagnóstico detallado"""
    num_nodes: int = 3          # Solo 3 nodos para debugging rápido
    rounds: int = 5             # Pocas rondas para análisis
    local_epochs: int = 10      # Más epochs para aprendizaje real
    learning_rate: float = 0.001  # LR más bajo como el modelo real
    debug_level: str = "full"   # full, basic, minimal


class DiagnosticLogger:
    """Logger avanzado para debugging"""

    def __init__(self, config: DiagnosticConfig):
        self.config = config
        self.logs = {
            'model_gradients': [],
            'loss_history': [],
            'accuracy_history': [],
            'weight_updates': [],
            'fedprox_penalty': [],
            'learning_rates': []
        }

    def log_model_diagnostics(self, model, step_name: str):
        """Log detallado del estado del modelo"""
        print(f"\n🔍 DIAGNÓSTICO - {step_name}")

        # Gradientes
        total_grad_norm = 0
        param_count = 0
        for name, param in model.named_parameters():
            if param.grad is not None:
                grad_norm = param.grad.norm().item()
                total_grad_norm += grad_norm ** 2
                param_count += 1

        total_grad_norm = math.sqrt(total_grad_norm) if param_count > 0 else 0

        # Pesos
        total_weight_norm = 0
        for param in model.parameters():
            total_weight_norm += param.norm().item() ** 2
        total_weight_norm = math.sqrt(total_weight_norm)

        print(f"   📊 Parámetros totales: {sum(p.numel() for p in model.parameters()):,}")
        print(f"   🎯 Norma gradientes: {total_grad_norm:.6f}")
        print(f"   ⚖️  Norma pesos: {total_weight_norm:.6f}")
        print(f"   📈 Gradientes/Parámetros: {total_grad_norm/param_count:.8f}" if param_count > 0 else "   📈 Sin gradientes")

        # Verificar NaN/inf
        has_nan = any(torch.isnan(p).any() for p in model.parameters())
        has_inf = any(torch.isinf(p).any() for p in model.parameters())

        if has_nan:
            print("   🚨 ALERTA: NaN detectado en parámetros!")
        if has_inf:
            print("   🚨 ALERTA: Inf detectado en parámetros!")

        self.logs['model_gradients'].append({
            'step': step_name,
            'grad_norm': total_grad_norm,
            'weight_norm': total_weight_norm,
            'has_nan': has_nan,
            'has_inf': has_inf
        })

    def log_training_step(self, node_id: str, loss: float, accuracy: float,
                         fedprox_penalty: float, lr: float):
        """Log detallado de cada paso de entrenamiento"""
        print(f"   🤖 {node_id}: Loss={loss:.6f}, Acc={accuracy:.4f}, FedProx={fedprox_penalty:.6f}, LR={lr:.6f}")

        self.logs['loss_history'].append(loss)
        self.logs['accuracy_history'].append(accuracy)
        self.logs['fedprox_penalty'].append(fedprox_penalty)
        self.logs['learning_rates'].append(lr)

    def log_aggregation_diagnostics(self, node_updates: List[Dict], global_weights):
        """Log del proceso de agregación"""
        print("\n🔄 DIAGNÓSTICO DE AGREGACIÓN:")
        print(f"   📦 Nodos agregados: {len(node_updates)}")

        # Analizar variabilidad entre nodos
        losses = [u['loss'] for u in node_updates]
        accuracies = [u['accuracy'] for u in node_updates]

        loss_std = torch.std(torch.tensor(losses)).item() if len(losses) > 1 else 0
        acc_std = torch.std(torch.tensor(accuracies)).item() if len(accuracies) > 1 else 0

        print(f"   📊 Loss - Media: {sum(losses)/len(losses):.4f}, Std: {loss_std:.4f}")
        print(f"   🎯 Accuracy - Media: {sum(accuracies)/len(accuracies):.4f}, Std: {acc_std:.4f}")

        # Verificar estabilidad de pesos globales
        global_weight_norm = 0
        for param in global_weights.values():
            global_weight_norm += param.norm().item() ** 2
        global_weight_norm = math.sqrt(global_weight_norm)

        print(f"   ⚖️  Norma pesos globales: {global_weight_norm:.4f}")

    def generate_diagnostic_report(self):
        """Generar reporte de diagnóstico completo"""
        print("\n" + "="*80)
        print("📋 REPORTE DIAGNÓSTICO COMPLETO")
        print("="*80)

        # Análisis de gradientes
        grad_norms = [log['grad_norm'] for log in self.logs['model_gradients']]
        if grad_norms:
            print("\n🎯 ANÁLISIS DE GRADIENTES:")
            print(f"   Norma gradiente inicial: {grad_norms[0]:.6f}")
            print(f"   Norma gradiente final: {grad_norms[-1]:.6f}")
            print(f"   Gradientes estables: {all(g > 1e-8 for g in grad_norms[-3:])}")

        # Análisis de loss
        losses = self.logs['loss_history']
        if len(losses) > 5:
            recent_losses = losses[-5:]
            loss_trend = "mejorando" if recent_losses[-1] < recent_losses[0] else "empeorando"
            print("\n📉 ANÁLISIS DE LOSS:")
            print(f"   Tendencia reciente: {loss_trend}")
            print(f"   Loss inicial: {losses[0]:.4f}")
            print(f"   Loss final: {losses[-1]:.4f}")
            print(f"   Mejora total: {((losses[0] - losses[-1]) / losses[0] * 100):.1f}%")

        # Análisis de accuracy
        accuracies = self.logs['accuracy_history']
        if accuracies:
            print("\n🎯 ANÁLISIS DE ACCURACY:")
            print(f"   Accuracy inicial: {accuracies[0]:.4f}")
            print(f"   Accuracy final: {accuracies[-1]:.4f}")
            print(f"   Accuracy siempre 0: {all(acc == 0.0 for acc in accuracies)}")

        # Diagnóstico final
        print("\n🔍 DIAGNÓSTICO FINAL:")
        issues = []

        if all(acc == 0.0 for acc in accuracies):
            issues.append("🚨 Accuracy siempre 0.0 - modelo no aprende")
        if len(losses) > 5 and losses[-1] > losses[0]:
            issues.append("🚨 Loss aumenta - modelo diverge")
        if any(log['has_nan'] for log in self.logs['model_gradients']):
            issues.append("🚨 NaN detectado - inestabilidad numérica")
        if any(log['has_inf'] for log in self.logs['model_gradients']):
            issues.append("🚨 Inf detectado - gradientes explosivos")

        if not issues:
            print("   ✅ No se detectaron problemas críticos")
        else:
            for issue in issues:
                print(f"   {issue}")

        return issues


# Modelo REAL GPT-2 que APRENDE LENGUAJE (del linguistic_fire_standalone.py)
@dataclass
class GPT2Config:
    """Configuración para GPT-2 REAL."""
    vocab_size: int = 1000
    hidden_size: int = 128
    num_layers: int = 2
    num_heads: int = 4
    max_position_embeddings: int = 32
    dropout: float = 0.1


class GPT2Attention(nn.Module):
    """Multi-head attention para GPT-2 REAL."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.num_heads = config.num_heads
        self.hidden_size = config.hidden_size
        self.head_dim = config.hidden_size // config.num_heads

        self.q_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.k_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.v_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)
        self.out_proj = nn.Linear(config.hidden_size, config.hidden_size, bias=True)

        self.dropout = nn.Dropout(config.dropout)

    def forward(self, hidden_states: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        batch_size, seq_length, _ = hidden_states.size()

        # Proyecciones lineales
        q = self.q_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(hidden_states).view(batch_size, seq_length, self.num_heads, self.head_dim).transpose(1, 2)

        # Attention scores
        scale = 1.0 / math.sqrt(self.head_dim)
        attn_weights = torch.matmul(q, k.transpose(-2, -1)) * scale

        # Apply attention mask (causal)
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        # Softmax
        attn_weights = F.softmax(attn_weights, dim=-1)
        attn_weights = self.dropout(attn_weights)

        # Apply attention
        attn_output = torch.matmul(attn_weights, v)

        # Reshape and project
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, seq_length, self.hidden_size)
        attn_output = self.out_proj(attn_output)

        return attn_output


class GPT2MLP(nn.Module):
    """MLP para GPT-2 REAL."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.fc1 = nn.Linear(config.hidden_size, 4 * config.hidden_size, bias=True)
        self.fc2 = nn.Linear(4 * config.hidden_size, config.hidden_size, bias=True)
        self.act = F.gelu
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.fc1(hidden_states)
        hidden_states = self.act(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.fc2(hidden_states)
        hidden_states = self.dropout(hidden_states)
        return hidden_states


class GPT2Block(nn.Module):
    """Bloque Transformer para GPT-2 REAL."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.ln1 = nn.LayerNorm(config.hidden_size, eps=1e-5)
        self.attn = GPT2Attention(config)
        self.ln2 = nn.LayerNorm(config.hidden_size, eps=1e-5)
        self.mlp = GPT2MLP(config)

    def forward(self, hidden_states: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        # Pre-norm architecture
        residual = hidden_states
        hidden_states = self.ln1(hidden_states)
        attn_output = self.attn(hidden_states, attention_mask)
        hidden_states = residual + attn_output  # Residual connection

        residual = hidden_states
        hidden_states = self.ln2(hidden_states)
        mlp_output = self.mlp(hidden_states)
        hidden_states = residual + mlp_output  # Residual connection

        return hidden_states


class GPT2Model(nn.Module):
    """GPT-2 Model completo que APRENDE LENGUAJE REAL."""

    def __init__(self, config: GPT2Config):
        super().__init__()
        self.config = config

        # Token embeddings
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)

        # Position embeddings
        self.embed_positions = nn.Embedding(config.max_position_embeddings, config.hidden_size)

        # Dropout
        self.dropout = nn.Dropout(config.dropout)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            GPT2Block(config) for _ in range(config.num_layers)
        ])

        # Final layer norm
        self.ln_f = nn.LayerNorm(config.hidden_size, eps=1e-5)

        # Language modeling head (tied weights)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self.lm_head.weight = self.embed_tokens.weight  # Weight tying

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
    ) -> Dict[str, Any]:
        batch_size, seq_len = input_ids.size()

        # Create position IDs
        position_ids = torch.arange(seq_len, dtype=torch.long, device=input_ids.device)
        position_ids = position_ids.unsqueeze(0).expand(batch_size, -1)

        # Embeddings
        token_embeds = self.embed_tokens(input_ids)
        position_embeds = self.embed_positions(position_ids)
        hidden_states = token_embeds + position_embeds
        hidden_states = self.dropout(hidden_states)

        # Create causal attention mask
        causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        causal_mask = causal_mask.to(input_ids.device)
        attention_mask = (~causal_mask).float() * -10000.0 if attention_mask is None else attention_mask

        # Expand for batch and heads
        attention_mask = attention_mask.unsqueeze(0).unsqueeze(1)

        # Transformer blocks
        for block in self.blocks:
            hidden_states = block(hidden_states, attention_mask)

        # Final layer norm
        hidden_states = self.ln_f(hidden_states)

        # Language modeling head
        logits = self.lm_head(hidden_states)

        result = {"logits": logits}

        # Calculate loss if labels provided
        if labels is not None:
            # Shift logits and labels for next-token prediction
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                ignore_index=-100
            )
            result["loss"] = loss

        return result


class SimpleTokenizer:
    """Tokenizer REAL del modelo que funcionó"""
    def __init__(self, vocab_size: int = 1000):
        self.vocab_size = vocab_size
        self.bos_token_id = 1
        self.eos_token_id = 2
        self.pad_token_id = 0  # Añadido para compatibilidad

    def encode(self, text: str) -> list:
        """Encode text to token IDs - MISMO QUE EL MODELO REAL"""
        tokens = [self.bos_token_id]
        for char in text.lower():
            if char.isalpha():
                token_id = ord(char) - ord('a') + 10  # a=10, b=11, etc.
                tokens.append(min(token_id, self.vocab_size - 1))
            elif char == ' ':
                tokens.append(3)  # space token
        tokens.append(self.eos_token_id)
        return tokens[:32]  # Max length


class DiagnosticNode:
    """Nodo con logging detallado para diagnóstico"""

    def __init__(self, node_id: str, config: GPT2Config, fed_config: DiagnosticConfig, logger: DiagnosticLogger):
        self.node_id = node_id
        self.config = config
        self.fed_config = fed_config
        self.logger = logger
        self.model = GPT2Model(config)
        self.tokenizer = SimpleTokenizer(config.vocab_size)
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=fed_config.learning_rate, weight_decay=0.01)
        self.local_texts = self._generate_simple_texts()
        self.local_data = self._prepare_data()

    def _generate_simple_texts(self) -> List[str]:
        """Textos REALES como el modelo que funcionó"""
        base_texts = [
            "hello world",
            "machine learning",
            "artificial intelligence",
            "neural networks",
            "deep learning",
            "natural language processing",
            "computer vision",
            "reinforcement learning"
        ]
        extended_texts = base_texts * 20  # 160 textos como el modelo real
        random.seed(hash(self.node_id) % 100000)
        random.shuffle(extended_texts)
        return extended_texts

    def _prepare_data(self) -> List[Dict[str, torch.Tensor]]:
        all_input_ids = []
        all_labels = []

        for text in self.local_texts[:50]:  # Solo 50 para diagnóstico rápido
            tokens = self.tokenizer.encode(text)
            if len(tokens) > 3:
                input_ids = torch.tensor(tokens[:-1], dtype=torch.long)
                labels = torch.tensor(tokens[1:], dtype=torch.long)
                all_input_ids.append(input_ids)
                all_labels.append(labels)

        if not all_input_ids:
            # Fallback mínimo
            dummy_input = torch.tensor([1, 10, 11, 2], dtype=torch.long)
            dummy_label = torch.tensor([10, 11, 2, 0], dtype=torch.long)
            all_input_ids = [dummy_input]
            all_labels = [dummy_label]

        max_len = min(max(len(ids) for ids in all_input_ids), self.config.max_position_embeddings)
        padded_inputs = []
        padded_labels = []

        for inp, lab in zip(all_input_ids, all_labels):
            if len(inp) > max_len:
                inp, lab = inp[:max_len], lab[:max_len]
            pad_len = max_len - len(inp)
            padded_input = torch.cat([inp, torch.full((pad_len,), self.tokenizer.pad_token_id, dtype=torch.long)])
            padded_label = torch.cat([lab, torch.full((pad_len,), -100, dtype=torch.long)])
            padded_inputs.append(padded_input)
            padded_labels.append(padded_label)

        input_batch = torch.stack(padded_inputs)
        label_batch = torch.stack(padded_labels)
        return [{'input': input_batch, 'target': label_batch}]

    def train_local(self, global_weights: Dict[str, torch.Tensor], round_num: int) -> Dict[str, Any]:
        """Entrenamiento con logging detallado"""
        self.global_weights = {k: v.clone() for k, v in global_weights.items()}
        current_lr = self.fed_config.learning_rate * (0.995 ** (round_num - 1))
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = current_lr

        self.model.load_state_dict(global_weights)
        self.logger.log_model_diagnostics(self.model, f"{self.node_id}_before_training_r{round_num}")

        batch = self.local_data[0]
        total_loss = 0

        for epoch in range(self.fed_config.local_epochs):
            self.optimizer.zero_grad()
            outputs = self.model(batch['input'], labels=batch['target'])
            loss = outputs["loss"]

            # FedProx muy suave para diagnóstico
            prox_term = 0.0
            for name, param in self.model.named_parameters():
                if name in self.global_weights:
                    prox_term += (param - self.global_weights[name]).norm(2)
            loss += (0.0001 / 2) * prox_term  # FedProx casi neutro

            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / self.fed_config.local_epochs

        # Evaluación detallada
        with torch.no_grad():
            outputs = self.model(batch['input'], labels=batch['target'])
            logits = outputs["logits"]
            pred = logits[:, :-1].contiguous().argmax(dim=-1)
            target_for_acc = batch['target'][:, :-1]

            mask = (target_for_acc != -100) & (target_for_acc != self.tokenizer.pad_token_id) & (target_for_acc > 0)
            correct = ((pred == target_for_acc) & mask).float().sum()
            total = mask.float().sum()
            acc = (correct / total).item() if total > 0 else 0.0

            # Debug detallado
            if self.fed_config.debug_level == "full":
                print(f"   🔍 {self.node_id} Debug:")
                print(f"      Pred shape: {pred.shape}, Target shape: {target_for_acc.shape}")
                print(f"      Mask sum: {mask.sum().item()}, Total valid: {total}")
                print(f"      Correct: {correct.item()}, Accuracy: {acc:.4f}")
                print(f"      Sample preds: {pred[0, :5].tolist()}")
                print(f"      Sample targets: {target_for_acc[0, :5].tolist()}")

        self.logger.log_model_diagnostics(self.model, f"{self.node_id}_after_training_r{round_num}")
        self.logger.log_training_step(self.node_id, avg_loss, acc, prox_term.item(), current_lr)

        return {
            'node_id': self.node_id,
            'weights': self.model.state_dict(),
            'loss': avg_loss,
            'accuracy': acc,
            'samples': len(self.local_texts),
            'learning_rate': current_lr
        }


class DiagnosticCoordinator:
    """Coordinador con diagnóstico completo"""

    def __init__(self, config: DiagnosticConfig, model_config: GPT2Config):
        self.config = config
        self.model_config = model_config
        self.global_model = GPT2Model(model_config)
        self.nodes = []
        self.logger = DiagnosticLogger(config)

    def add_node(self, node: DiagnosticNode):
        self.nodes.append(node)

    def aggregate_weights(self, node_updates: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        """Agregación con diagnóstico"""
        if not node_updates:
            return self.global_model.state_dict()

        global_weights = {}
        total_weighted_samples = 0

        for update in node_updates:
            accuracy_weight = update['accuracy'] + 0.1  # Bonus mínimo
            sample_weight = update['samples']
            update['combined_weight'] = accuracy_weight * sample_weight
            total_weighted_samples += update['combined_weight']

        if total_weighted_samples == 0:
            total_weighted_samples = len(node_updates)
            for update in node_updates:
                update['combined_weight'] = 1.0

        for key in self.global_model.state_dict().keys():
            weighted_sum = torch.zeros_like(self.global_model.state_dict()[key])
            for update in node_updates:
                weight = update['combined_weight'] / total_weighted_samples
                weighted_sum += weight * update['weights'][key]
            global_weights[key] = weighted_sum

        self.logger.log_aggregation_diagnostics(node_updates, global_weights)
        return global_weights

    def evaluate_global_model(self) -> Dict[str, float]:
        """Evaluación con diagnóstico"""
        self.global_model.eval()

        test_texts = ["machine learning", "data science", "neural network"]
        total_loss = 0
        total_acc = 0
        tokenizer = SimpleTokenizer(self.model_config.vocab_size)

        print("\n🔍 DIAGNÓSTICO DE EVALUACIÓN:")
        for i, text in enumerate(test_texts):
            tokens = tokenizer.encode(text)
            if len(tokens) > 3:
                max_eval_len = min(16, self.model_config.max_position_embeddings)
                tokens = tokens[:max_eval_len+1] if len(tokens) > max_eval_len+1 else tokens
                if len(tokens) < max_eval_len + 1:
                    tokens.extend([tokenizer.pad_token_id] * (max_eval_len + 1 - len(tokens)))

                input_seq = torch.tensor(tokens[:-1], dtype=torch.long).unsqueeze(0)
                target_seq = torch.tensor(tokens[1:], dtype=torch.long)

                with torch.no_grad():
                    outputs = self.global_model(input_seq, labels=target_seq)
                    loss = outputs["loss"]
                    logits = outputs["logits"]
                    pred = logits[:, :-1].contiguous().argmax(dim=-1).squeeze()
                    target_for_acc = target_seq[:-1]

                    mask = (target_for_acc != tokenizer.pad_token_id) & (target_for_acc != -100) & (target_for_acc > 0)
                    correct = ((pred == target_for_acc) & mask).float().sum()
                    total_eval = mask.float().sum()
                    acc = (correct / total_eval).item() if total_eval > 0 else 0.0

                print(f"   Texto {i+1}: Loss={loss.item():.4f}, Acc={acc:.4f}")
                total_loss += loss.item()
                total_acc += acc

        avg_loss = total_loss / len(test_texts) if test_texts else 10.0
        avg_acc = total_acc / len(test_texts) if test_texts else 0.0

        print(f"   📊 Global: Loss={avg_loss:.4f}, Accuracy={avg_acc:.4f}")

        return {'loss': avg_loss, 'accuracy': avg_acc}

    async def run_diagnostic_training(self):
        """Entrenamiento con diagnóstico completo"""
        print("🔬 FASE REAL-8: DIAGNÓSTICO COMPLETO DEL SISTEMA FEDERADO")
        print("=" * 80)
        print("Identificando exactamente por qué diverge el modelo")
        print()

        print("✅ Sistema de Diagnóstico Configurado:")
        print("   Modelo: GPT-2 REAL ({:,} parámetros)".format(sum(p.numel() for p in self.global_model.parameters())))
        print("   Nodos: {} (diagnóstico)".format(len(self.nodes)))
        print("   Rondas: {} (análisis completo)".format(self.config.rounds))
        print("   Nivel debug: {}".format(self.config.debug_level))
        print()

        global_weights = self.global_model.state_dict()
        initial_eval = self.evaluate_global_model()

        print("📊 Estado Inicial: Loss={:.4f}, Acc={:.4f}".format(initial_eval['loss'], initial_eval['accuracy']))
        print("   Total datos: {:,}".format(sum(len(node.local_texts) for node in self.nodes)))

        print("\n🎯 INICIANDO DIAGNÓSTICO DETALLADO")

        for round_num in range(1, self.config.rounds + 1):
            print("\n🎯 RONDA {} - DIAGNÓSTICO".format(round_num))

            node_updates = []
            for node in self.nodes:
                update = node.train_local(global_weights, round_num)
                node_updates.append(update)

            new_global_weights = self.aggregate_weights(node_updates)
            self.global_model.load_state_dict(new_global_weights)

            round_eval = self.evaluate_global_model()

            print("✅ Resultado de ronda:")
            print("   Loss global: {:.4f}".format(round_eval['loss']))
            print("   Accuracy global: {:.4f}".format(round_eval['accuracy']))

            if len(self.logger.logs['loss_history']) > 1:
                loss_hist = self.logger.logs['loss_history']
                acc_hist = self.logger.logs['accuracy_history']
                loss_imp = (loss_hist[-2] - round_eval['loss']) / max(loss_hist[-2], 0.001) * 100
                acc_imp = (round_eval['accuracy'] - acc_hist[-2]) / max(acc_hist[-2], 0.001) * 100
                print("   Mejora: Loss {:.1f}%, Acc {:.1f}%".format(loss_imp, acc_imp))

            global_weights = new_global_weights

        # Resultados finales y diagnóstico
        final_loss = self.logger.logs['loss_history'][-1] if self.logger.logs['loss_history'] else 0
        final_acc = self.logger.logs['accuracy_history'][-1] if self.logger.logs['accuracy_history'] else 0

        loss_improvement = (initial_eval['loss'] - final_loss) / max(initial_eval['loss'], 0.001) * 100
        acc_improvement = (final_acc - initial_eval['accuracy']) / max(initial_eval['accuracy'], 0.001) * 100

        print("\n🎊 RESULTADOS FINALES DE DIAGNÓSTICO:")
        print("   Loss: {:.4f} → {:.4f} ({:.1f}% mejora)".format(initial_eval['loss'], final_loss, loss_improvement))
        print("   Accuracy: {:.4f} → {:.4f} ({:.1f}% mejora)".format(initial_eval['accuracy'], final_acc, acc_improvement))

        # Generar reporte de diagnóstico
        issues = self.logger.generate_diagnostic_report()

        print("\n🔧 RECOMENDACIONES PARA ARREGLAR:")
        if "Accuracy siempre 0.0" in str(issues):
            print("   1. ✅ AÑADIR MÁS DATOS - El modelo necesita más ejemplos")
            print("   2. ✅ MODELO MÁS SIMPLE - Reducir complejidad inicial")
            print("   3. ✅ MEJOR TOKENIZER - Vocabulario más rico")
        if "Loss aumenta" in str(issues):
            print("   1. ✅ REDUCIR LEARNING RATE - LR demasiado alto")
            print("   2. ✅ AUMENTAR FEDPROX - Regularización insuficiente")
            print("   3. ✅ GRADIENT CLIPPING - Prevenir explosión de gradientes")
        if "NaN detectado" in str(issues) or "Inf detectado" in str(issues):
            print("   1. ✅ GRADIENT CLIPPING - Implementar inmediatamente")
            print("   2. ✅ REDUCIR LR - Learning rate demasiado alto")
            print("   3. ✅ CHECK WEIGHTS - Verificar inicialización")

        return issues


async def main():
    print("🔬 DIAGNÓSTICO COMPLETO DEL SISTEMA FEDERADO LINGÜÍSTICO")
    print("Identificando problemas de divergencia y accuracy = 0.0")

    model_config = GPT2Config()
    fed_config = DiagnosticConfig()

    coordinator = DiagnosticCoordinator(fed_config, model_config)

    print("🚀 Inicializando {} nodos de diagnóstico...".format(fed_config.num_nodes))

    for i in range(fed_config.num_nodes):
        node = DiagnosticNode("diag_node_{:02d}".format(i+1), model_config, fed_config, coordinator.logger)
        coordinator.add_node(node)

    try:
        issues = await coordinator.run_diagnostic_training()

        print("\n" + "="*80)
        if not issues:
            print("🎉 ¡DIAGNÓSTICO EXITOSO! El sistema funciona correctamente")
        else:
            print("⚠️  DIAGNÓSTICO COMPLETADO - Se encontraron {} problemas".format(len(issues)))
            print("💡 Próximo paso: Implementar correcciones basadas en el reporte")
        print("="*80)

        return 0 if not issues else len(issues)
    except Exception as e:
        print("❌ Error en diagnóstico: {}".format(e))
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(asyncio.run(main()))