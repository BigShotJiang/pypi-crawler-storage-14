#!/bin/bash

# AILOOS Deployment Readiness Verification Script
# Verifica que todo esté preparado para despliegue one-click

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

info() {
    echo -e "${PURPLE}ℹ️  $1${NC}"
}

# Variables de estado
CHECKS_PASSED=0
CHECKS_FAILED=0
ISSUES_FOUND=()

# Función para registrar problemas
add_issue() {
    local issue=$1
    ISSUES_FOUND+=("$issue")
    ((CHECKS_FAILED++))
}

# Función para verificar existencia de archivo
check_file() {
    local file=$1
    local description=$2

    if [[ -f "$file" ]]; then
        success "$description encontrado: $file"
        ((CHECKS_PASSED++))
        return 0
    else
        error "$description no encontrado: $file"
        add_issue "Archivo faltante: $file"
        return 1
    fi
}

# Función para verificar ejecutabilidad
check_executable() {
    local file=$1
    local description=$2

    if [[ -x "$file" ]]; then
        success "$description es ejecutable: $file"
        ((CHECKS_PASSED++))
        return 0
    else
        warning "$description no es ejecutable: $file"
        add_issue "Archivo no ejecutable: $file"
        return 1
    fi
}

# Función para verificar comando disponible
check_command() {
    local cmd=$1
    local description=$2

    if command -v "$cmd" &> /dev/null; then
        success "$description disponible: $cmd"
        ((CHECKS_PASSED++))
        return 0
    else
        error "$description no disponible: $cmd"
        add_issue "Comando faltante: $cmd"
        return 1
    fi
}

# Función para verificar configuración JSON
check_json_config() {
    local file=$1
    local description=$2

    if [[ -f "$file" ]]; then
        if command -v jq &> /dev/null; then
            if jq empty "$file" 2>/dev/null; then
                success "$description válido: $file"
                ((CHECKS_PASSED++))
                return 0
            else
                error "$description inválido (JSON malformed): $file"
                add_issue "JSON inválido: $file"
                return 1
            fi
        else
            warning "jq no disponible, saltando validación JSON de $file"
            ((CHECKS_PASSED++))
            return 0
        fi
    else
        error "$description no encontrado: $file"
        add_issue "Archivo faltante: $file"
        return 1
    fi
}

# Función para verificar variables de entorno
check_env_vars() {
    local env_file=$1
    local description=$2
    local required_vars=("${@:3}")

    if [[ -f "$env_file" ]]; then
        local missing_vars=()

        for var in "${required_vars[@]}"; do
            if ! grep -q "^${var}=" "$env_file" || grep -q "^${var}=\s*$" "$env_file"; then
                missing_vars+=("$var")
            fi
        done

        if [[ ${#missing_vars[@]} -eq 0 ]]; then
            success "$description completo: $env_file"
            ((CHECKS_PASSED++))
            return 0
        else
            warning "$description incompleto: $env_file (faltan: ${missing_vars[*]})"
            add_issue "Variables faltantes en $env_file: ${missing_vars[*]}"
            return 1
        fi
    else
        error "$description no encontrado: $env_file"
        add_issue "Archivo faltante: $env_file"
        return 1
    fi
}

log "🔍 Verificando preparación para despliegue one-click de AILOOS"

# 1. Verificar herramientas del sistema
echo ""
info "🔧 Verificando herramientas del sistema..."
check_command "gcloud" "Google Cloud SDK"
check_command "vercel" "Vercel CLI"
check_command "docker" "Docker"
check_command "node" "Node.js"
check_command "npm" "NPM"
check_command "python3" "Python 3"
check_command "pip" "Pip"
check_command "jq" "JQ (opcional)"

# 2. Verificar scripts de despliegue
echo ""
info "📜 Verificando scripts de despliegue..."
check_file "scripts/deploy_backend.sh" "Script de despliegue backend"
check_file "scripts/deploy_frontend.sh" "Script de despliegue frontend"
check_file "scripts/deploy_full.sh" "Script de despliegue completo"
check_file "scripts/health_check.sh" "Script de health check"
check_file "scripts/integration_test_production.sh" "Script de tests integración"

# Verificar ejecutabilidad
check_executable "scripts/deploy_backend.sh" "Script backend"
check_executable "scripts/deploy_frontend.sh" "Script frontend"
check_executable "scripts/deploy_full.sh" "Script completo"
check_executable "scripts/health_check.sh" "Script health check"
check_executable "scripts/integration_test_production.sh" "Script tests"

# 3. Verificar configuración de infraestructura
echo ""
info "🏗️  Verificando configuración de infraestructura..."
check_file "infrastructure/gcp/terraform/main.tf" "Terraform GCP"
check_file "infrastructure/gcp/terraform/variables.tf" "Variables Terraform"
check_file "infrastructure/gcp/terraform/terraform.tfvars" "Valores Terraform"

# 4. Verificar configuración de frontend
echo ""
info "🌐 Verificando configuración de frontend..."
check_file "frontend/package.json" "Package.json frontend"
check_file "frontend/vercel.json" "Configuración Vercel"
check_file "frontend/.env.example" "Ejemplo variables entorno frontend"

# 5. Verificar archivos de entorno
echo ""
info "🔐 Verificando archivos de configuración..."
check_file ".env.production" "Variables producción"
check_file ".env.staging" "Variables staging"

# Verificar variables críticas en archivos de entorno
check_env_vars ".env.production" "Variables producción" \
    "DATABASE_URL" "AUTH_SECRET" "OPENAI_API_KEY" "GCP_PROJECT_ID"

check_env_vars ".env.staging" "Variables staging" \
    "DATABASE_URL" "AUTH_SECRET" "OPENAI_API_KEY" "GCP_PROJECT_ID"

# 6. Verificar documentación
echo ""
info "📚 Verificando documentación..."
check_file "docs/deployment_guide.md" "Guía de despliegue"
check_file "docs/production_setup.md" "Configuración producción"
check_file "docs/monitoring_setup.md" "Configuración monitoreo"
check_file "README.md" "README principal"

# 7. Verificar configuración CI/CD
echo ""
info "🔄 Verificando configuración CI/CD..."
check_file ".github/workflows/deploy.yml" "Workflow despliegue"

# 8. Verificar autenticaciones (si están disponibles)
echo ""
info "🔑 Verificando autenticaciones..."

# Verificar autenticación GCP (opcional)
if command -v gcloud &> /dev/null; then
    if gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
        success "Autenticación GCP configurada"
        ((CHECKS_PASSED++))
    else
        warning "Autenticación GCP no configurada (requerida para despliegue)"
        add_issue "Configurar: gcloud auth login"
    fi
else
    warning "gcloud no disponible para verificar autenticación"
fi

# Verificar autenticación Vercel (opcional)
if command -v vercel &> /dev/null; then
    if vercel whoami &> /dev/null; then
        success "Autenticación Vercel configurada"
        ((CHECKS_PASSED++))
    else
        warning "Autenticación Vercel no configurada (requerida para despliegue)"
        add_issue "Configurar: vercel login"
    fi
else
    warning "vercel no disponible para verificar autenticación"
fi

# 9. Verificar dependencias
echo ""
info "📦 Verificando dependencias..."

# Verificar dependencias Python
if [[ -f "requirements.txt" ]]; then
    if pip install --dry-run -r requirements.txt &> /dev/null; then
        success "Dependencias Python verificadas"
        ((CHECKS_PASSED++))
    else
        warning "Problemas con dependencias Python"
        add_issue "Verificar requirements.txt"
    fi
else
    warning "requirements.txt no encontrado"
fi

# Verificar dependencias Node.js frontend
if [[ -f "frontend/package.json" ]]; then
    cd frontend
    if npm ls --depth=0 &> /dev/null; then
        success "Dependencias frontend verificadas"
        ((CHECKS_PASSED++))
    else
        warning "Problemas con dependencias frontend"
        add_issue "Verificar dependencias en frontend/"
    fi
    cd ..
else
    warning "package.json frontend no encontrado"
fi

# 10. Verificar configuración de red y conectividad
echo ""
info "🌐 Verificando configuración de red..."

# Verificar conectividad básica
if curl -s --connect-timeout 5 https://www.google.com > /dev/null; then
    success "Conectividad a internet disponible"
    ((CHECKS_PASSED++))
else
    warning "Sin conectividad a internet"
    add_issue "Verificar conexión de red"
fi

# 11. Verificar permisos de archivos
echo ""
info "🔒 Verificando permisos de archivos..."

# Verificar que los scripts sean ejecutables
for script in scripts/deploy_*.sh scripts/health_check.sh scripts/integration_test_production.sh; do
    if [[ -f "$script" ]]; then
        if [[ -x "$script" ]]; then
            success "Permisos correctos: $script"
            ((CHECKS_PASSED++))
        else
            warning "Permisos incorrectos: $script"
            add_issue "Ejecutar: chmod +x $script"
        fi
    fi
done

# Resultados finales
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                  📊 RESULTADOS DE VERIFICACIÓN               ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

TOTAL_CHECKS=$((CHECKS_PASSED + CHECKS_FAILED))
SUCCESS_RATE=$((CHECKS_PASSED * 100 / TOTAL_CHECKS))

echo "Checks totales: $TOTAL_CHECKS"
echo "✅ Exitosos: $CHECKS_PASSED"
echo "❌ Fallidos: $CHECKS_FAILED"
echo "📊 Tasa de éxito: ${SUCCESS_RATE}%"
echo ""

if [[ ${#ISSUES_FOUND[@]} -eq 0 ]]; then
    success "🎉 ¡Todo está preparado para despliegue one-click!"
    echo ""
    info "Puedes ejecutar:"
    echo "  ./scripts/deploy_full.sh --environment production"
    echo ""
    exit 0
else
    warning "Se encontraron ${#ISSUES_FOUND[@]} problemas que resolver:"
    echo ""
    for issue in "${ISSUES_FOUND[@]}"; do
        echo "  - $issue"
    done
    echo ""

    if [[ $SUCCESS_RATE -ge 80 ]]; then
        warning "Puedes proceder con precaución, pero resuelve los problemas críticos primero"
        exit 1
    else
        error "Demasiados problemas críticos. Resuelve antes de proceder"
        exit 1
    fi
fi