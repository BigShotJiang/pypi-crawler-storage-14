#!/usr/bin/env python3
"""
Script para medir la tasa de aciertos del cache (Cache Hit Rate) en RAG + CAG con EmpoorioLM.

Este script evalúa la eficiencia del sistema de cache semántico midiendo:
- Tasa de aciertos del cache
- Latencia promedio de búsqueda en cache
- Número de consultas procesadas
- Distribución de hits vs misses

Uso:
    python scripts/measure_cache_hit_rate.py --num_queries 100 --similarity_threshold 0.8
"""

import argparse
import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Any
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.rag.cache_augmented.cache_augmented_rag import CacheAugmentedRAG
from ailoos.rag.techniques.naive_rag import NaiveRAG
from ailoos.rag.core.generators import EmpoorioLMGenerator
from ailoos.rag.core.retrievers import VectorRetriever
from ailoos.rag.core.evaluators import BasicRAGEvaluator

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class CacheHitRateMeasurer:
    """Medidor de tasa de aciertos del cache para RAG + CAG."""

    def __init__(self, config: Dict[str, Any]):
        """
        Inicializar el medidor.

        Args:
            config: Configuración del experimento
        """
        self.config = config
        self.results = {
            'experiment_config': config,
            'metrics': {},
            'queries': [],
            'timestamp': time.time()
        }

    def setup_rag_system(self) -> CacheAugmentedRAG:
        """Configurar el sistema RAG con cache aumentado."""
        logger.info("Configurando sistema RAG con Cache Augmented Generation...")

        # Configuración del retriever
        retriever_config = {
            'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
            'vector_store': {
                'type': 'chroma',
                'collection_name': 'test_cache_hit_rate',
                'persist_directory': './data/cache_hit_rate_test'
            }
        }

        # Configuración del generador EmpoorioLM
        generator_config = {
            'empoorio_api_config': {
                'model_path': self.config.get('model_path', './models/empoorio_lm/v1.0.0'),
                'device': 'cpu',  # Usar CPU para pruebas
                'max_tokens': 512,
                'temperature': 0.7
            },
            'generation_config': {
                'max_new_tokens': 256,
                'temperature': 0.7,
                'do_sample': True
            },
            'caching': {
                'max_size': 100,  # Pequeño para pruebas
                'ttl_seconds': 3600
            }
        }

        # Configuración del evaluador
        evaluator_config = {}

        # Configuración del RAG base (NaiveRAG)
        base_rag_config = {
            'retriever_class': VectorRetriever,
            'retriever_config': retriever_config,
            'generator_class': EmpoorioLMGenerator,
            'generator_config': generator_config,
            'evaluator_class': BasicRAGEvaluator,
            'evaluator_config': evaluator_config
        }

        # Configuración del cache aumentado
        cache_config = {
            'model_name': 'all-MiniLM-L6-v2',
            'similarity_threshold': self.config.get('similarity_threshold', 0.8),
            'max_size': self.config.get('cache_max_size', 1000),
            'eviction_policy': self.config.get('eviction_policy', 'LRU'),
            'cache_file': self.config.get('cache_file')
        }

        # Configuración completa del CAG
        cag_config = {
            'base_rag_class': NaiveRAG,
            'base_rag_config': base_rag_config,
            'cache_config': cache_config,
            'cache_enabled': True,
            'quality_config': {}
        }

        try:
            rag_system = CacheAugmentedRAG(cag_config)
            logger.info("Sistema RAG configurado exitosamente")
            return rag_system
        except Exception as e:
            logger.error(f"Error configurando sistema RAG: {e}")
            raise

    def generate_test_queries(self) -> List[Dict[str, Any]]:
        """Generar consultas de prueba con algunas repetidas para medir cache hits."""
        base_queries = [
            "¿Qué es la inteligencia artificial?",
            "¿Cómo funciona el aprendizaje automático?",
            "¿Cuáles son las aplicaciones de la IA en medicina?",
            "¿Qué es el procesamiento de lenguaje natural?",
            "¿Cómo se entrena un modelo de IA?",
            "¿Qué es el aprendizaje profundo?",
            "¿Cuáles son los desafíos éticos de la IA?",
            "¿Qué es la visión por computadora?",
            "¿Cómo funciona el reconocimiento de voz?",
            "¿Qué es el aprendizaje por refuerzo?"
        ]

        # Crear queries con repeticiones para medir cache hits
        test_queries = []
        num_repetitions = self.config.get('num_repetitions', 3)

        for i, query in enumerate(base_queries):
            # Agregar query original
            test_queries.append({
                'id': f'query_{i}_original',
                'query': query,
                'expected_cache_hit': False
            })

            # Agregar repeticiones (deberían ser cache hits)
            for rep in range(num_repetitions):
                test_queries.append({
                    'id': f'query_{i}_rep_{rep}',
                    'query': query,
                    'expected_cache_hit': True
                })

        # Agregar algunas queries similares (deberían ser cache hits si similarity_threshold es adecuado)
        similar_queries = [
            ("¿Qué significa IA?", "¿Qué es la inteligencia artificial?"),
            ("¿Cómo opera el machine learning?", "¿Cómo funciona el aprendizaje automático?"),
            ("¿Para qué se usa la IA en salud?", "¿Cuáles son las aplicaciones de la IA en medicina?"),
            ("¿Qué es el PLN?", "¿Qué es el procesamiento de lenguaje natural?")
        ]

        for similar_query, original_query in similar_queries:
            test_queries.append({
                'id': f'similar_{hash(similar_query) % 1000}',
                'query': similar_query,
                'expected_cache_hit': True,  # Similar queries should hit cache
                'similar_to': original_query
            })

        logger.info(f"Generadas {len(test_queries)} consultas de prueba")
        return test_queries

    async def run_experiment(self) -> Dict[str, Any]:
        """Ejecutar el experimento de medición de cache hit rate."""
        logger.info("Iniciando experimento de medición de cache hit rate...")

        # Configurar sistema RAG
        rag_system = self.setup_rag_system()

        # Generar consultas de prueba
        test_queries = self.generate_test_queries()

        # Ejecutar consultas
        results = []
        start_time = time.time()

        for i, query_data in enumerate(test_queries):
            query_id = query_data['id']
            query = query_data['query']

            logger.info(f"Ejecutando consulta {i+1}/{len(test_queries)}: {query[:50]}...")

            try:
                # Ejecutar consulta
                query_start = time.time()
                result = rag_system.run(query)
                query_time = time.time() - query_start

                # Extraer métricas del cache
                cache_hit = result['metadata'].get('cache_hit', False)
                cache_metrics = result['metadata'].get('cache_metrics', {})

                # Registrar resultado
                query_result = {
                    'query_id': query_id,
                    'query': query,
                    'cache_hit': cache_hit,
                    'expected_cache_hit': query_data.get('expected_cache_hit', False),
                    'query_time': query_time,
                    'response_length': len(result.get('response', '')),
                    'cache_similarity': cache_metrics.get('avg_similarity_search_time', 0),
                    'similar_to': query_data.get('similar_to'),
                    'timestamp': time.time()
                }

                results.append(query_result)
                self.results['queries'].append(query_result)

                logger.info(f"  Cache hit: {cache_hit}, Tiempo: {query_time:.3f}s")

            except Exception as e:
                logger.error(f"Error ejecutando consulta {query_id}: {e}")
                error_result = {
                    'query_id': query_id,
                    'query': query,
                    'error': str(e),
                    'timestamp': time.time()
                }
                results.append(error_result)
                self.results['queries'].append(error_result)

        total_time = time.time() - start_time

        # Calcular métricas finales
        self.calculate_metrics(results, total_time)

        logger.info("Experimento completado")
        return self.results

    def calculate_metrics(self, results: List[Dict[str, Any]], total_time: float):
        """Calcular métricas del experimento."""
        successful_queries = [r for r in results if 'error' not in r]
        cache_hits = [r for r in successful_queries if r.get('cache_hit', False)]
        cache_misses = [r for r in successful_queries if not r.get('cache_hit', False)]

        self.results['metrics'] = {
            'total_queries': len(results),
            'successful_queries': len(successful_queries),
            'cache_hits': len(cache_hits),
            'cache_misses': len(cache_misses),
            'cache_hit_rate': len(cache_hits) / len(successful_queries) if successful_queries else 0.0,
            'total_experiment_time': total_time,
            'avg_query_time': sum(r.get('query_time', 0) for r in successful_queries) / len(successful_queries) if successful_queries else 0.0,
            'avg_cache_hit_time': sum(r.get('query_time', 0) for r in cache_hits) / len(cache_hits) if cache_hits else 0.0,
            'avg_cache_miss_time': sum(r.get('query_time', 0) for r in cache_misses) / len(cache_misses) if cache_misses else 0.0,
            'error_rate': (len(results) - len(successful_queries)) / len(results) if results else 0.0
        }

        logger.info("Métricas calculadas:")
        logger.info(f"  Total consultas: {self.results['metrics']['total_queries']}")
        logger.info(f"  Cache hit rate: {self.results['metrics']['cache_hit_rate']:.3f}")
        logger.info(f"  Tiempo promedio por consulta: {self.results['metrics']['avg_query_time']:.3f}s")
        logger.info(f"  Tiempo total experimento: {total_time:.2f}s")

    def save_results(self, output_file: str):
        """Guardar resultados en archivo JSON."""
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        logger.info(f"Resultados guardados en {output_path}")

    def print_summary(self):
        """Imprimir resumen de resultados."""
        metrics = self.results['metrics']

        print("\n" + "="*60)
        print("RESUMEN DEL EXPERIMENTO - CACHE HIT RATE")
        print("="*60)
        print(f"Total de consultas: {metrics['total_queries']}")
        print(f"Consultas exitosas: {metrics['successful_queries']}")
        print(f"Cache hits: {metrics['cache_hits']}")
        print(f"Cache misses: {metrics['cache_misses']}")
        print(".3f")
        print(".3f")
        print(".3f")
        print(".3f")
        print(".3f")
        print(".3f")
        print("="*60)


async def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Medir cache hit rate en RAG + CAG')
    parser.add_argument('--num_queries', type=int, default=50,
                       help='Número de consultas a ejecutar')
    parser.add_argument('--similarity_threshold', type=float, default=0.8,
                       help='Umbral de similitud para cache hits')
    parser.add_argument('--cache_max_size', type=int, default=1000,
                       help='Tamaño máximo del cache')
    parser.add_argument('--num_repetitions', type=int, default=3,
                       help='Número de repeticiones por query base')
    parser.add_argument('--model_path', type=str, default='./models/empoorio_lm/v1.0.0',
                       help='Ruta al modelo EmpoorioLM')
    parser.add_argument('--output_file', type=str, default='benchmark_results/cache_hit_rate_results.json',
                       help='Archivo de salida para resultados')
    parser.add_argument('--eviction_policy', type=str, default='LRU', choices=['LRU', 'LFU'],
                       help='Política de eviction del cache')

    args = parser.parse_args()

    # Configuración del experimento
    config = {
        'num_queries': args.num_queries,
        'similarity_threshold': args.similarity_threshold,
        'cache_max_size': args.cache_max_size,
        'num_repetitions': args.num_repetitions,
        'model_path': args.model_path,
        'eviction_policy': args.eviction_policy,
        'cache_file': f'./cache/cache_hit_rate_test_{int(time.time())}.pkl'
    }

    # Crear medidor
    measurer = CacheHitRateMeasurer(config)

    try:
        # Ejecutar experimento
        results = await measurer.run_experiment()

        # Guardar resultados
        measurer.save_results(args.output_file)

        # Imprimir resumen
        measurer.print_summary()

        logger.info(f"Experimento completado. Resultados guardados en {args.output_file}")

    except Exception as e:
        logger.error(f"Error en el experimento: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())