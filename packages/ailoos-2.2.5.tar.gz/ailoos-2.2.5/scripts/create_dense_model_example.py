#!/usr/bin/env python3
"""
Create Dense Model Example
Script para crear un modelo EmpoorioLM denso de ejemplo para testing.
"""

import sys
from pathlib import Path

# Add models directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.empoorio_lm.config import EmpoorioLMConfig
from models.empoorio_lm.model import EmpoorioLM

def create_dense_model_example():
    """Create and save a dense EmpoorioLM model for testing."""

    # Create dense configuration
    config = EmpoorioLMConfig(
        vocab_size=30000,
        hidden_size=768,
        num_layers=12,
        num_heads=12,
        max_position_embeddings=1024,
        use_moe=False,  # Dense model
        dropout=0.1,
        layer_norm_eps=1e-5
    )

    print("🚀 Creating dense EmpoorioLM model...")

    # Create model
    model = EmpoorioLM(config)

    # Print model info
    info = model.get_model_info()
    print(f"✅ Dense model created:")
    print(f"   Parameters: {info['total_parameters']:,}")
    print(f"   Architecture: {info['architecture']}")

    # Save model
    output_path = Path("models/dense_model")
    output_path.mkdir(parents=True, exist_ok=True)

    model.save_pretrained(output_path)
    print(f"✅ Model saved to {output_path}")

    return str(output_path)

if __name__ == "__main__":
    create_dense_model_example()