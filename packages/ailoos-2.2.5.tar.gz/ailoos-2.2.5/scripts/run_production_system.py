#!/usr/bin/env python3
"""
FASE REAL-5: Script de ejecución del sistema de producción completo
Ejecuta el pipeline de producción federado end-to-end con monitoreo completo.
"""

import asyncio
import logging
import argparse
import json
import time
from pathlib import Path
import sys

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.production import (
    ProductionPipelineOrchestrator,
    create_production_orchestrator
)

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('./production_system.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


def load_config(config_path: str = None) -> dict:
    """Cargar configuración desde archivo o usar defaults."""
    if config_path and Path(config_path).exists():
        with open(config_path, 'r') as f:
            return json.load(f)

    # Configuración por defecto para demo
    return {
        "training_config": {
            "data_config": {
                "datasets": ["wikitext", "openwebtext"],
                "num_shards": 5,
                "batch_size": 8,
                "max_length": 512
            },
            "federated_config": {
                "num_rounds": 3,
                "min_participants": 3,
                "max_participants": 5,
                "use_tenseal": False,
                "enable_rewards": True
            }
        },
        "monitoring_config": {
            "update_interval": 10,
            "enable_api": True,
            "api_port": 8080,
            "alert_thresholds": {
                "cpu_usage": 80.0,
                "memory_usage": 85.0,
                "training_loss": 5.0
            }
        },
        "scaling_config": {
            "min_nodes": 3,
            "max_nodes": 10,
            "scale_up_threshold": 0.8,
            "scale_down_threshold": 0.3,
            "enable_auto_scaling": True,
            "predictive_scaling": True
        },
        "deployment_config": {
            "deployment_strategy": "blue_green",
            "rollback_on_failure": True,
            "health_check_timeout": 300
        }
    }


async def run_production_system(config: dict, session_id: str = None):
    """Ejecutar el sistema de producción completo."""
    if not session_id:
        session_id = f"production_{int(time.time())}"

    print("🤖 AILOOS - FASE REAL-5: SISTEMA DE PRODUCCIÓN COMPLETO")
    print("=" * 70)
    print(f"Session ID: {session_id}")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()

    try:
        # Crear orquestador
        print("🚀 Inicializando Production Pipeline Orchestrator...")
        orchestrator = create_production_orchestrator(session_id, config)

        # Añadir callbacks para logging
        def log_stage_change(status):
            stage = status.get('stage', 'unknown')
            progress = status.get('progress', 0)
            print(f"📍 Stage: {stage} - Progress: {progress:.1f}%")

        orchestrator.add_stage_callback("data_preparation", log_stage_change)
        orchestrator.add_stage_callback("training", log_stage_change)
        orchestrator.add_stage_callback("monitoring", log_stage_change)
        orchestrator.add_stage_callback("scaling", log_stage_change)
        orchestrator.add_stage_callback("deployment", log_stage_change)

        # Iniciar pipeline
        print("🎯 Iniciando pipeline de producción...")
        start_time = time.time()

        success = await orchestrator.start_production_pipeline()

        end_time = time.time()
        duration = end_time - start_time

        print()
        print("=" * 70)
        if success:
            print("🎉 SISTEMA DE PRODUCCIÓN COMPLETADO EXITOSAMENTE")
            print(f"   Duración: {duration:.2f}s")
        else:
            print("❌ SISTEMA DE PRODUCCIÓN FALLÓ")
            print(f"   Duración: {duration:.2f}s")

        # Mostrar estadísticas finales
        status = orchestrator.get_pipeline_status()
        print()
        print("📊 ESTADÍSTICAS FINALES:")
        print(f"   Estado final: {status['stage']}")
        print(f"   Progreso: {status['progress']:.1f}%")
        print(f"   Componentes activos: {sum(status['components'].values())}")
        print(f"   Errores: {len(status['errors'])}")

        if status['errors']:
            print("   Errores encontrados:")
            for error in status['errors'][-3:]:  # Mostrar últimos 3
                print(f"     - {error}")

        # Guardar reporte
        report_path = f"./production_report_{session_id}.json"
        with open(report_path, 'w') as f:
            json.dump({
                "session_id": session_id,
                "success": success,
                "duration": duration,
                "final_status": status,
                "timestamp": time.time()
            }, f, indent=2, default=str)

        print(f"📋 Reporte guardado en: {report_path}")

        return success

    except Exception as e:
        logger.error(f"❌ Error crítico en sistema de producción: {e}")
        print(f"❌ ERROR CRÍTICO: {e}")
        return False


async def demo_production_system():
    """Demo del sistema de producción con configuración simplificada."""
    print("🎭 DEMO: Sistema de Producción AILOOS FASE REAL-5")
    print("=" * 50)

    # Configuración simplificada para demo
    demo_config = {
        "training_config": {
            "data_config": {
                "datasets": ["wikitext"],
                "num_shards": 3,
                "batch_size": 4,
                "max_length": 256
            },
            "federated_config": {
                "num_rounds": 2,
                "min_participants": 2,
                "max_participants": 3,
                "use_tenseal": False,
                "enable_rewards": False
            }
        },
        "monitoring_config": {
            "update_interval": 5,
            "enable_api": False,  # Deshabilitar API para demo
            "alert_thresholds": {
                "cpu_usage": 90.0,
                "memory_usage": 90.0
            }
        },
        "scaling_config": {
            "min_nodes": 2,
            "max_nodes": 5,
            "enable_auto_scaling": True,
            "predictive_scaling": False
        },
        "deployment_config": {
            "deployment_strategy": "blue_green",
            "rollback_on_failure": True
        }
    }

    await run_production_system(demo_config, "demo_session")


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description="AILOOS Production System - FASE REAL-5")
    parser.add_argument("--config", type=str, help="Path to configuration JSON file")
    parser.add_argument("--session-id", type=str, help="Custom session ID")
    parser.add_argument("--demo", action="store_true", help="Run demo mode")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       default="INFO", help="Logging level")

    args = parser.parse_args()

    # Configurar logging level
    logging.getLogger().setLevel(getattr(logging, args.log_level))

    # Cargar configuración
    config = load_config(args.config)

    # Ejecutar
    if args.demo:
        asyncio.run(demo_production_system())
    else:
        asyncio.run(run_production_system(config, args.session_id))


if __name__ == "__main__":
    main()