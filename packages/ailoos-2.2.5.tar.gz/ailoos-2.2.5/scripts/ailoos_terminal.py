#!/usr/bin/env python3
"""
AILOOS Terminal - Centro de Mando Interactivo
Interfaz de línea de comandos completa para todas las funcionalidades de AILOOS.
"""

import asyncio
import sys
import os
import time
import psutil
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

# Asegurar que podemos importar módulos de AILOOS
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.live import Live
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    import questionary

    RICH_AVAILABLE = True
except ImportError:
    print("⚠️ Rich library not available. Install with: pip install rich questionary")
    RICH_AVAILABLE = False
    # Fallback básico
    class Console:
        def print(self, *args, **kwargs): print(*args)
        def clear(self): os.system('clear' if os.name == 'posix' else 'cls')
    console = Console()

if RICH_AVAILABLE:
    console = Console()

from src.ailoos.sdk.advanced_client import AILOOSNode, create_ailoos_node
from src.ailoos.core.logging import get_logger

logger = get_logger(__name__)


class AILOOSTerminal:
    """
    Terminal interactiva completa para AILOOS.
    Proporciona una interfaz de usuario rica para todas las funcionalidades.
    """

    def __init__(self):
        self.node: Optional[AILOOSNode] = None
        self.node_id = f"terminal_node_{int(time.time())}"
        self.start_time = datetime.now()

        # Configuración de colores y estilos
        if RICH_AVAILABLE:
            self.styles = {
                'header': 'bold cyan',
                'success': 'bold green',
                'error': 'bold red',
                'warning': 'bold yellow',
                'info': 'blue',
                'token': 'bold gold1',
                'ai': 'deep_sky_blue1'
            }
        else:
            self.styles = {}

    async def initialize_node(self) -> bool:
        """Inicializa el nodo AILOOS."""
        try:
            with console.status("[bold green]🚀 Inicializando nodo AILOOS...[/bold green]"):
                self.node = await create_ailoos_node(
                    node_id=self.node_id,
                    workspace_path="./ailoos_terminal_workspace"
                )

            console.print(f"\n[green]✅ Nodo inicializado:[/green] {self.node_id}")
            return True

        except Exception as e:
            console.print(f"[red]❌ Error inicializando nodo:[/red] {e}")
            return False

    def show_logo(self):
        """Muestra el logo de AILOOS."""
        logo = """
        [ai]   __   __  __    ___    ___   ___   ___   ___   ___ [/ai]
        [ai]  /  \ |  ||  |  / _ \  / _ \ / __| / __| / __| / __|[/ai]
        [ai] / /\ \|  ||  |__|| || || || |\__ \ \__ \ \__ \ \__ \\[/ai]
        [ai]/_/  \_\__||____|\___/  \___/ |___/ |___/ |___/ |___/[/ai]
        [dim]NEURAL LINK TERMINAL v2.0 - COMMAND CENTER[/dim]
        """
        console.print(logo, justify="center")

    def get_system_status(self) -> Dict[str, Any]:
        """Obtiene el estado del sistema."""
        try:
            cpu_percent = psutil.cpu_percent(interval=0.1)
            ram = psutil.virtual_memory()
            disk = psutil.disk_usage('/')

            return {
                'cpu_percent': cpu_percent,
                'ram_used_gb': round(ram.used / (1024**3), 1),
                'ram_total_gb': round(ram.total / (1024**3), 1),
                'disk_used_gb': round(disk.used / (1024**3), 1),
                'disk_total_gb': round(disk.total / (1024**3), 1),
                'uptime': str(datetime.now() - self.start_time).split('.')[0]
            }
        except:
            return {'error': 'System monitoring not available'}

    async def show_dashboard(self):
        """Muestra el dashboard principal."""
        console.clear()
        self.show_logo()

        # Estado del sistema
        sys_status = self.get_system_status()

        # Crear panel de estado
        status_table = Table(title="📊 System Status")
        status_table.add_column("Metric", style="cyan")
        status_table.add_column("Value", style="magenta")

        status_table.add_row("CPU Usage", f"{sys_status.get('cpu_percent', 0)}%")
        status_table.add_row("RAM", f"{sys_status.get('ram_used_gb', 0)}/{sys_status.get('ram_total_gb', 0)} GB")
        status_table.add_row("Disk", f"{sys_status.get('disk_used_gb', 0)}/{sys_status.get('disk_total_gb', 0)} GB")
        status_table.add_row("Uptime", sys_status.get('uptime', 'N/A'))

        console.print(status_table)
        console.print()

        # Estado del nodo
        if self.node:
            try:
                node_status = await self.node.get_full_status()

                # Wallet status
                wallet_panel = Panel(
                    f"Balance: [token]{node_status.get('wallet_balance', 0):.2f} DRACMA[/token]\n"
                    f"Staked: [bold blue]{node_status.get('staking_info', {}).get('staked_amount', 0):.2f} DRACMA[/bold blue]",
                    title="💰 Wallet Status",
                    border_style="gold1"
                )
                console.print(wallet_panel)

                # Node stats
                stats = node_status.get('stats', {})
                stats_panel = Panel(
                    f"Datasets: {stats.get('datasets_processed', 0)}\n"
                    f"Training: {stats.get('training_sessions', 0)}\n"
                    f"Earned: [token]{stats.get('tokens_earned', 0):.2f} DRACMA[/token]",
                    title="📈 Node Statistics"
                )
                console.print(stats_panel)

            except Exception as e:
                console.print(f"[warning]⚠️ Could not load node status: {e}[/warning]")
        else:
            console.print("[warning]⚠️ Node not initialized[/warning]")

        console.print()

    async def menu_wallet_staking(self):
        """Menú de wallet y staking."""
        if not self.node:
            console.print("[error]❌ Node not initialized[/error]")
            return

        while True:
            console.clear()
            await self.show_dashboard()

            # Menú simple sin questionary
            console.print("\n[bold cyan]💰 WALLET & STAKING MENU[/bold cyan]")
            console.print("1. 📊 View Balance & Portfolio")
            console.print("2. 🔒 Stake Tokens")
            console.print("3. 🔓 Unstake Tokens")
            console.print("4. 💸 Transfer Tokens")
            console.print("5. 📈 View Staking Rewards")
            console.print("6. ⬅️  Back to Main Menu")

            try:
                choice_input = input("\nSelecciona una opción (1-6): ").strip()
                choice_map = {
                    "1": "📊 View Balance & Portfolio",
                    "2": "🔒 Stake Tokens",
                    "3": "🔓 Unstake Tokens",
                    "4": "💸 Transfer Tokens",
                    "5": "📈 View Staking Rewards",
                    "6": "⬅️  Back to Main Menu"
                }
                choice = choice_map.get(choice_input)
            except EOFError:
                choice = "⬅️  Back to Main Menu"

            if choice == "⬅️  Back to Main Menu":
                break
            elif choice == "📊 View Balance & Portfolio":
                await self.view_wallet_balance()
            elif choice == "🔒 Stake Tokens":
                await self.stake_tokens()
            elif choice == "🔓 Unstake Tokens":
                await self.unstake_tokens()
            elif choice == "💸 Transfer Tokens":
                await self.transfer_tokens()
            elif choice == "📈 View Staking Rewards":
                await self.view_staking_rewards()

            input("\nPress Enter to continue...")

    async def view_wallet_balance(self):
        """Muestra el balance de la wallet."""
        try:
            balance = await self.node.get_wallet_balance()
            staking_info = await self.node.get_staking_info()

            table = Table(title="💰 Wallet Balance")
            table.add_column("Asset", style="cyan")
            table.add_column("Amount", style="green")
            table.add_column("Status", style="yellow")

            table.add_row("DRACMA", f"{balance:.2f}", "Available")
            table.add_row("Staked DRACMA", f"{staking_info.get('staked_amount', 0):.2f}", "Locked")
            table.add_row("Rewards", f"{staking_info.get('rewards_amount', 0):.2f}", "Claimable")

            console.print(table)

        except Exception as e:
            console.print(f"[error]❌ Error getting balance: {e}[/error]")

    async def stake_tokens(self):
        """Interfaz para staking de tokens."""
        try:
            balance = await self.node.get_wallet_balance()
            console.print(f"Available balance: [token]{balance:.2f} DRACMA[/token]")

            amount_str = input("Amount to stake (DRACMA): ").strip()
            if amount_str and amount_str.replace('.', '').isdigit():
                amount = float(amount_str)
                if not (0 < amount <= balance):
                    console.print("[error]❌ Invalid amount[/error]")
                    return
            else:
                console.print("[error]❌ Invalid number[/error]")
                return

            with console.status(f"[bold yellow]🔒 Staking {amount} DRACMA...[/bold yellow]"):
                result = await self.node.stake_tokens(amount)

            if result.get('success'):
                console.print(f"[success]✅ Successfully staked {amount} DRACMA![/success]")
            else:
                console.print(f"[error]❌ Staking failed: {result.get('error', 'Unknown error')}[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error during staking: {e}[/error]")

    async def unstake_tokens(self):
        """Interfaz para unstaking de tokens."""
        try:
            staking_info = await self.node.get_staking_info()
            staked = staking_info.get('staked_amount', 0)

            if staked == 0:
                console.print("[warning]⚠️ No tokens staked[/warning]")
                return

            console.print(f"Currently staked: [token]{staked:.2f} DRACMA[/token]")

            amount_str = input("Amount to unstake (DRACMA): ").strip()
            if amount_str and amount_str.replace('.', '').isdigit():
                amount = float(amount_str)
                if not (0 < amount <= staked):
                    console.print("[error]❌ Invalid amount[/error]")
                    return
            else:
                console.print("[error]❌ Invalid number[/error]")
                return

            with console.status(f"[bold yellow]🔓 Unstaking {amount} DRACMA...[/bold yellow]"):
                result = await self.node.unstake_tokens(amount)

            if result.get('success'):
                console.print(f"[success]✅ Successfully unstaked {amount} DRACMA![/success]")
            else:
                console.print(f"[error]❌ Unstaking failed: {result.get('error', 'Unknown error')}[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error during unstaking: {e}[/error]")

    async def transfer_tokens(self):
        """Interfaz para transferir tokens."""
        try:
            balance = await self.node.get_wallet_balance()
            console.print(f"Available balance: [token]{balance:.2f} DRACMA[/token]")

            recipient = input("Recipient address: ").strip()
            if not recipient:
                return

            amount_str = input("Amount to transfer (DRACMA): ").strip()
            if amount_str and amount_str.replace('.', '').isdigit():
                amount = float(amount_str)
                if not (0 < amount <= balance):
                    console.print("[error]❌ Invalid amount[/error]")
                    return
            else:
                console.print("[error]❌ Invalid number[/error]")
                return

            confirm_input = input(f"Transfer {amount} DRACMA to {recipient}? (y/N): ").strip().lower()
            if confirm_input not in ['y', 'yes']:
                console.print("[info]ℹ️ Transfer cancelled[/info]")
                return

            with console.status(f"[bold yellow]💸 Transferring {amount} DRACMA...[/bold yellow]"):
                result = await self.node.transfer_tokens(recipient, amount)

            if result.get('success'):
                console.print(f"[success]✅ Transfer successful![/success]")
            else:
                console.print(f"[error]❌ Transfer failed: {result.get('error', 'Unknown error')}[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error during transfer: {e}[/error]")

    async def view_staking_rewards(self):
        """Muestra información de staking y rewards."""
        try:
            staking_info = await self.node.get_staking_info()

            table = Table(title="📈 Staking Information")
            table.add_column("Metric", style="cyan")
            table.add_column("Value", style="green")

            table.add_row("Staked Amount", f"{staking_info.get('staked_amount', 0):.2f} DRACMA")
            table.add_row("Rewards Earned", f"{staking_info.get('rewards_amount', 0):.2f} DRACMA")
            table.add_row("Reputation Level", staking_info.get('reputation_level', 'N/A'))
            table.add_row("APR", f"{staking_info.get('apr', 0):.1f}%")
            table.add_row("Lock Period", f"{staking_info.get('lock_period_days', 0)} days")

            console.print(table)

        except Exception as e:
            console.print(f"[error]❌ Error getting staking info: {e}[/error]")

    async def menu_datasets(self):
        """Menú de gestión de datasets."""
        if not self.node:
            console.print("[error]❌ Node not initialized[/error]")
            return

        while True:
            console.clear()
            await self.show_dashboard()

            # Menú simple sin questionary
            console.print("\n[bold cyan]📦 DATASETS MENU[/bold cyan]")
            console.print("1. 📤 Process & Upload Dataset")
            console.print("2. 🔍 Search Available Datasets")
            console.print("3. ⬇️  Download Dataset Shard")
            console.print("4. 📋 View My Datasets")
            console.print("5. 🛒 List Dataset for Sale")
            console.print("6. 🛍️  Purchase Dataset")
            console.print("7. ⬅️  Back to Main Menu")

            try:
                choice_input = input("\nSelecciona una opción (1-7): ").strip()
                choice_map = {
                    "1": "📤 Process & Upload Dataset",
                    "2": "🔍 Search Available Datasets",
                    "3": "⬇️  Download Dataset Shard",
                    "4": "📋 View My Datasets",
                    "5": "🛒 List Dataset for Sale",
                    "6": "🛍️  Purchase Dataset",
                    "7": "⬅️  Back to Main Menu"
                }
                choice = choice_map.get(choice_input)
            except EOFError:
                choice = "⬅️  Back to Main Menu"

            if choice == "⬅️  Back to Main Menu":
                break
            elif choice == "📤 Process & Upload Dataset":
                await self.process_dataset()
            elif choice == "🔍 Search Available Datasets":
                await self.search_datasets()
            elif choice == "⬇️  Download Dataset Shard":
                await self.download_shard()
            elif choice == "📋 View My Datasets":
                await self.view_my_datasets()
            elif choice == "🛒 List Dataset for Sale":
                await self.list_dataset_for_sale()
            elif choice == "🛍️  Purchase Dataset":
                await self.purchase_dataset()

            input("\nPress Enter to continue...")

    async def process_dataset(self):
        """Procesa y sube un dataset."""
        try:
            file_path = input("Select file to process (path): ").strip()
            if not file_path or not os.path.exists(file_path):
                console.print("[error]❌ Invalid file path[/error]")
                return

            dataset_name = input("Dataset name: ").strip()
            if not dataset_name:
                return

            shard_size_str = input("Shard size (MB, default 50): ").strip() or "50"
            shard_size = int(shard_size_str) if shard_size_str.isdigit() else 50

            with console.status(f"[bold yellow]📦 Processing dataset {dataset_name}...[/bold yellow]"):
                result = await self.node.process_dataset(file_path, dataset_name, shard_size)

            if result:
                console.print(f"[success]✅ Dataset processed successfully![/success]")
                console.print(f"   Name: {result['dataset_name']}")
                console.print(f"   Shards: {result['num_shards']}")
                console.print(f"   Size: {result['total_size_mb']:.1f} MB")
            else:
                console.print("[error]❌ Dataset processing failed[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error processing dataset: {e}[/error]")

    async def search_datasets(self):
        """Busca datasets disponibles."""
        try:
            query = input("Search query (optional): ").strip()
            console.print("Categories: legal, medical, financial, technical, general")
            category = input("Category (optional): ").strip()

            with console.status("[bold yellow]🔍 Searching datasets...[/bold yellow]"):
                datasets = await self.node.search_datasets(query=query, category=category)

            if not datasets:
                console.print("[warning]⚠️ No datasets found[/warning]")
                return

            table = Table(title=f"🔍 Found {len(datasets)} datasets")
            table.add_column("Name", style="cyan")
            table.add_column("Category", style="green")
            table.add_column("Quality", style="yellow")
            table.add_column("Shards", style="magenta")

            for ds in datasets[:10]:  # Mostrar máximo 10
                table.add_row(
                    ds.get('dataset_name', 'N/A'),
                    ds.get('metadata', {}).get('category', 'N/A'),
                    f"{ds.get('quality_score', 0):.2f}",
                    str(ds.get('num_shards', 0))
                )

            console.print(table)

        except Exception as e:
            console.print(f"[error]❌ Error searching datasets: {e}[/error]")

    async def download_shard(self):
        """Descarga un shard específico."""
        try:
            cid = input("Shard CID: ").strip()
            if not cid:
                return

            local_path = input("Local save path (optional): ").strip()
            local_path = local_path if local_path else None

            with console.status(f"[bold yellow]⬇️ Downloading shard {cid[:16]}...[/bold yellow]"):
                shard = await self.node.download_shard(cid, local_path)

            console.print(f"[success]✅ Shard downloaded![/success]")
            console.print(f"   Dataset: {shard.source_dataset}")
            console.print(f"   Index: {shard.index + 1}/{shard.total_shards}")
            if local_path:
                console.print(f"   Saved to: {local_path}")

        except Exception as e:
            console.print(f"[error]❌ Error downloading shard: {e}[/error]")

    async def view_my_datasets(self):
        """Muestra datasets del usuario."""
        try:
            # Esta funcionalidad necesitaría ser implementada en el registry
            console.print("[info]ℹ️ Feature coming soon - View My Datasets[/info]")
        except Exception as e:
            console.print(f"[error]❌ Error viewing datasets: {e}[/error]")

    async def list_dataset_for_sale(self):
        """Lista un dataset para venta."""
        try:
            dataset_name = input("Dataset name to list: ").strip()
            if not dataset_name:
                return

            price_str = input("Price in DRACMA: ").strip()
            if not price_str or not price_str.replace('.', '').isdigit():
                console.print("[error]❌ Invalid price[/error]")
                return

            price = float(price_str)
            description = input("Description (optional): ").strip()

            with console.status(f"[bold yellow]🛒 Listing dataset for sale...[/bold yellow]"):
                result = await self.node.list_dataset_for_sale(dataset_name, price, description)

            if result.get('success'):
                console.print(f"[success]✅ Dataset listed for sale![/success]")
                console.print(f"   Listing ID: {result.get('listing_id')}")
                console.print(f"   Price: {price} DRACMA")
            else:
                console.print("[error]❌ Failed to list dataset[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error listing dataset: {e}[/error]")

    async def purchase_dataset(self):
        """Compra un dataset."""
        try:
            listing_id = input("Listing ID to purchase: ").strip()
            if not listing_id:
                return

            with console.status(f"[bold yellow]🛍️ Purchasing dataset...[/bold yellow]"):
                result = await self.node.purchase_dataset(listing_id)

            if result.get('success'):
                console.print(f"[success]✅ Dataset purchased successfully![/success]")
            else:
                console.print(f"[error]❌ Purchase failed: {result.get('error', 'Unknown error')}[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error purchasing dataset: {e}[/error]")

    async def menu_training(self):
        """Menú de entrenamiento federado."""
        if not self.node:
            console.print("[error]❌ Node not initialized[/error]")
            return

        while True:
            console.clear()
            await self.show_dashboard()

            # Menú simple sin questionary
            console.print("\n[bold cyan]🧠 TRAINING MENU[/bold cyan]")
            console.print("1. 🎯 Join Training Session")
            console.print("2. 📤 Submit Training Results")
            console.print("3. 📊 View Training History")
            console.print("4. ⬅️  Back to Main Menu")

            try:
                choice_input = input("\nSelecciona una opción (1-4): ").strip()
                choice_map = {
                    "1": "🎯 Join Training Session",
                    "2": "📤 Submit Training Results",
                    "3": "📊 View Training History",
                    "4": "⬅️  Back to Main Menu"
                }
                choice = choice_map.get(choice_input)
            except EOFError:
                choice = "⬅️  Back to Main Menu"

            if choice == "⬅️  Back to Main Menu":
                break
            elif choice == "🎯 Join Training Session":
                await self.join_training_session()
            elif choice == "📤 Submit Training Results":
                await self.submit_training_results()
            elif choice == "📊 View Training History":
                await self.view_training_history()

            input("\nPress Enter to continue...")

    async def join_training_session(self):
        """Únete a una sesión de entrenamiento."""
        try:
            session_id = input("Training session ID: ").strip()
            if not session_id:
                return

            with console.status(f"[bold yellow]🎯 Joining session {session_id}...[/bold yellow]"):
                result = await self.node.join_training_session(session_id)

            if result.get('success'):
                console.print(f"[success]✅ Joined training session {session_id}![/success]")
            else:
                console.print(f"[error]❌ Failed to join session: {result.get('error', 'Unknown error')}[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error joining training session: {e}[/error]")

    async def submit_training_results(self):
        """Envía resultados de entrenamiento."""
        try:
            session_id = input("Session ID: ").strip()
            if not session_id:
                return

            # En una implementación real, aquí cargaríamos los gradientes del entrenamiento
            gradients_file = input("Gradients file path: ").strip()
            if not gradients_file:
                return

            # Simulación de carga de gradientes
            gradients = {"mock": "gradients_data"}

            with console.status(f"[bold yellow]📤 Submitting results to {session_id}...[/bold yellow]"):
                result = await self.node.submit_training_result(session_id, gradients)

            if result.get('success'):
                console.print(f"[success]✅ Training results submitted![/success]")
            else:
                console.print(f"[error]❌ Failed to submit results: {result.get('error', 'Unknown error')}[/error]")

        except Exception as e:
            console.print(f"[error]❌ Error submitting training results: {e}[/error]")

    async def view_training_history(self):
        """Muestra historial de entrenamiento."""
        console.print("[info]ℹ️ Training history feature coming soon[/info]")

    async def menu_governance(self):
        """Menú de gobernanza."""
        if not self.node:
            console.print("[error]❌ Node not initialized[/error]")
            return

        while True:
            console.clear()
            await self.show_dashboard()

            # Menú simple sin questionary
            console.print("\n[bold cyan]🗳️ GOVERNANCE MENU[/bold cyan]")
            console.print("1. 📋 View Active Proposals")
            console.print("2. 🆕 Create New Proposal")
            console.print("3. 🗳️  Vote on Proposal")
            console.print("4. 📊 View Voting Results")
            console.print("5. ⬅️  Back to Main Menu")

            try:
                choice_input = input("\nSelecciona una opción (1-5): ").strip()
                choice_map = {
                    "1": "📋 View Active Proposals",
                    "2": "🆕 Create New Proposal",
                    "3": "🗳️  Vote on Proposal",
                    "4": "📊 View Voting Results",
                    "5": "⬅️  Back to Main Menu"
                }
                choice = choice_map.get(choice_input)
            except EOFError:
                choice = "⬅️  Back to Main Menu"

            if choice == "⬅️  Back to Main Menu":
                break
            elif choice == "📋 View Active Proposals":
                await self.view_proposals()
            elif choice == "🆕 Create New Proposal":
                await self.create_proposal()
            elif choice == "🗳️  Vote on Proposal":
                await self.vote_on_proposal()
            elif choice == "📊 View Voting Results":
                await self.view_voting_results()

            input("\nPress Enter to continue...")

    async def view_proposals(self):
        """Muestra propuestas activas."""
        console.print("[info]ℹ️ Governance features coming soon[/info]")

    async def create_proposal(self):
        """Crea una nueva propuesta."""
        console.print("[info]ℹ️ Proposal creation coming soon[/info]")

    async def vote_on_proposal(self):
        """Vota en una propuesta."""
        console.print("[info]ℹ️ Voting interface coming soon[/info]")

    async def view_voting_results(self):
        """Muestra resultados de votación."""
        console.print("[info]ℹ️ Voting results coming soon[/info]")

    def run_sync(self):
        """Ejecuta el terminal principal de forma síncrona."""
        # Crear nuevo event loop para evitar conflictos
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            loop.run_until_complete(self.run())
        finally:
            loop.close()

    async def run(self):
        """Ejecuta el terminal principal."""
        # Inicializar nodo
        if not await self.initialize_node():
            console.print("[error]❌ Failed to initialize AILOOS node. Exiting.[/error]")
            return

        # Menú principal
        while True:
            console.clear()
            await self.show_dashboard()

            # Menú principal simple (sin questionary para evitar conflictos de asyncio)
            console.print("\n[bold cyan]🌟 AILOOS COMMAND CENTER[/bold cyan]")
            console.print("1. 💰 Wallet & Staking")
            console.print("2. 📦 Datasets & IPFS")
            console.print("3. 🧠 Federated Training")
            console.print("4. 🗳️  Governance & Voting")
            console.print("5. 📊 System Statistics")
            console.print("6. ❌ Exit")

            try:
                choice_input = input("\nSelecciona una opción (1-6): ").strip()
                choice_map = {
                    "1": "💰 Wallet & Staking",
                    "2": "📦 Datasets & IPFS",
                    "3": "🧠 Federated Training",
                    "4": "🗳️  Governance & Voting",
                    "5": "📊 System Statistics",
                    "6": "❌ Exit"
                }
                choice = choice_map.get(choice_input)
            except EOFError:
                choice = "❌ Exit"

            if choice == "❌ Exit":
                console.print("[bold]👋 Thank you for using AILOOS![/bold]")
                if self.node:
                    self.node.cleanup()
                break
            elif choice == "💰 Wallet & Staking":
                await self.menu_wallet_staking()
            elif choice == "📦 Datasets & IPFS":
                await self.menu_datasets()
            elif choice == "🧠 Federated Training":
                await self.menu_training()
            elif choice == "🗳️  Governance & Voting":
                await self.menu_governance()
            elif choice == "📊 System Statistics":
                await self.show_detailed_stats()

    async def show_detailed_stats(self):
        """Muestra estadísticas detalladas del sistema."""
        console.clear()
        self.show_logo()

        if self.node:
            try:
                status = await self.node.get_full_status()

                # Node info
                console.print(Panel(
                    f"Node ID: {status['node_id']}\n"
                    f"Capabilities: {status['capabilities']}\n"
                    f"Initialized: {status['initialized']}",
                    title="🤖 Node Information"
                ))

                # Network stats
                network = status.get('network_stats', {})
                console.print(Panel(
                    f"Total Nodes: {network.get('total_nodes', 0)}\n"
                    f"Active Nodes: {network.get('active_nodes', 0)}\n"
                    f"Datasets: {network.get('total_datasets', 0)}\n"
                    f"Shards: {network.get('total_shards', 0)}",
                    title="🌐 Network Statistics"
                ))

                # IPFS status
                ipfs = status.get('ipfs_status', {})
                console.print(Panel(
                    f"Connected: {ipfs.get('connected', False)}\n"
                    f"Can Upload: {ipfs.get('can_upload', False)}\n"
                    f"Can Download: {ipfs.get('can_download', False)}",
                    title="📡 IPFS Status"
                ))

            except Exception as e:
                console.print(f"[error]❌ Error getting detailed stats: {e}[/error]")
        else:
            console.print("[error]❌ Node not available[/error]")

        input("\nPress Enter to return to main menu...")


def main():
    """Función principal."""
    try:
        # Crear nuevo event loop para evitar conflictos
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        terminal = AILOOSTerminal()
        loop.run_until_complete(terminal.run())

    except KeyboardInterrupt:
        console.print("\n[bold]👋 AILOOS Terminal closed.[/bold]")
    except Exception as e:
        console.print(f"[error]❌ Fatal error: {e}[/error]")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        try:
            loop.close()
        except:
            pass


if __name__ == "__main__":
    main()