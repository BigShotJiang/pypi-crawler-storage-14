#!/usr/bin/env python3
"""
Script para generar claves VAPID para notificaciones push web
=============================================================

Este script genera un par de claves VAPID (Voluntary Application Server Identification)
necesarias para enviar notificaciones push web de forma segura.

Las claves VAPID se utilizan para:
1. Identificar el servidor de aplicaciones que envía las notificaciones
2. Encriptar el payload de las notificaciones push
3. Verificar la autenticidad del remitente

Uso:
    python generate_vapid_keys.py

Salida:
    - Clave privada (VAPID_PRIVATE_KEY)
    - Clave pública (VAPID_PUBLIC_KEY)
    - Subject (VAPID_SUBJECT) - URL del sitio web

Guardar estas claves de forma segura en las variables de entorno.
"""

import os
import base64
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend


def generate_vapid_keys():
    """Genera un par de claves VAPID usando ECDSA P-256."""
    try:
        # Generar clave privada ECDSA P-256
        private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

        # Obtener clave privada en formato PEM
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ).decode('utf-8').strip()

        # Obtener clave pública en formato raw (65 bytes: 0x04 + x + y)
        public_key_raw = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint
        )

        # Convertir a base64url (sin padding)
        public_key_b64 = base64.urlsafe_b64encode(public_key_raw).decode('utf-8').rstrip('=')

        return private_pem, public_key_b64

    except Exception as e:
        print(f"Error generando claves VAPID: {e}")
        return None, None


def main():
    """Función principal."""
    print("Generando claves VAPID para notificaciones push web...")
    print("=" * 60)

    private_key, public_key = generate_vapid_keys()

    if private_key and public_key:
        print("\n✅ Claves VAPID generadas exitosamente!")
        print("\n📋 Configuración para variables de entorno:")
        print("-" * 40)
        print("VAPID_PRIVATE_KEY=" + private_key)
        print("VAPID_PUBLIC_KEY=" + public_key)
        print("VAPID_SUBJECT=https://tu-dominio.com")  # Cambiar por el dominio real
        print("-" * 40)

        print("\n🔐 Clave privada (guardar de forma segura):")
        print(private_key)

        print("\n🌐 Clave pública (compartir con el frontend):")
        print(public_key)

        print("\n📝 Instrucciones:")
        print("1. Copia las variables de entorno a tu archivo .env")
        print("2. Cambia VAPID_SUBJECT por tu dominio real")
        print("3. Reinicia el servidor para cargar las nuevas variables")
        print("4. La clave pública se usará en el frontend para suscribirse")

        # Crear archivo .env.example si no existe
        env_example_path = os.path.join(os.path.dirname(__file__), '..', '.env.example')
        if os.path.exists(env_example_path):
            print(f"\n📄 Actualizando {env_example_path}...")
            with open(env_example_path, 'a') as f:
                f.write("\n# VAPID Keys para notificaciones push web\n")
                f.write("# Generadas con scripts/generate_vapid_keys.py\n")
                f.write("VAPID_PRIVATE_KEY=\n")
                f.write("VAPID_PUBLIC_KEY=\n")
                f.write("VAPID_SUBJECT=https://tu-dominio.com\n")
        else:
            print(f"\n⚠️  No se encontró {env_example_path}, crea manualmente las variables")

    else:
        print("\n❌ Error generando claves VAPID")
        exit(1)


if __name__ == "__main__":
    main()