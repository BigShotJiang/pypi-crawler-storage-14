#!/usr/bin/env python3
"""
Instalador de dependencias para AILOOS CLI
Instala todas las dependencias necesarias para ejecutar la CLI interactiva.
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Ejecutar comando y mostrar resultado."""
    print(f"📦 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completado")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error en {description}: {e}")
        print(f"Salida de error: {e.stderr}")
        return False

def check_python_version():
    """Verificar versión de Python."""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 o superior es requerido")
        return False
    print(f"✅ Python {sys.version.split()[0]} detectado")
    return True

def install_cli_dependencies():
    """Instalar dependencias de la CLI."""
    dependencies = [
        "questionary>=1.10.0",
        "rich>=12.0.0",
        "click>=8.0.0",
        "pyfiglet>=0.8.0",
        "colorama>=0.4.0"
    ]

    print("🚀 Instalando dependencias de AILOOS CLI...")
    print("=" * 50)

    # Verificar Python
    if not check_python_version():
        return False

    # Instalar dependencias
    success_count = 0
    for dep in dependencies:
        if run_command(f"pip install '{dep}'", f"Instalando {dep}"):
            success_count += 1

    print(f"\n📊 Resultado: {success_count}/{len(dependencies)} dependencias instaladas")

    if success_count == len(dependencies):
        print("\n🎉 ¡Todas las dependencias instaladas exitosamente!")
        print("\nPara ejecutar la CLI:")
        print("  python scripts/ailoos_cli.py")
        print("  # o con opciones:")
        print("  python scripts/ailoos_cli.py --expert --coordinator-url http://localhost:8001")
        return True
    else:
        print(f"\n❌ {len(dependencies) - success_count} dependencias fallaron")
        return False

def verify_installation():
    """Verificar que las dependencias se instalaron correctamente."""
    print("\n🔍 Verificando instalación...")

    try:
        import questionary
        import rich
        import click
        import pyfiglet
        import colorama

        print("✅ Todas las dependencias verificadas")
        return True
    except ImportError as e:
        print(f"❌ Dependencia faltante: {e}")
        return False

def main():
    """Función principal."""
    print("AILOOS CLI - Instalador de Dependencias")
    print("=" * 50)

    # Cambiar al directorio del proyecto
    project_root = Path(__file__).parent.parent
    os.chdir(project_root)

    # Instalar dependencias
    if install_cli_dependencies():
        # Verificar instalación
        if verify_installation():
            print("\n🎯 ¡CLI lista para usar!")
            print("Ejecuta: python scripts/ailoos_cli.py")
            return 0
        else:
            print("\n❌ Verificación fallida")
            return 1
    else:
        print("\n❌ Instalación fallida")
        return 1

if __name__ == "__main__":
    sys.exit(main())