#!/bin/bash

# AILOOS Complete Deployment Script
# Despliega backend y frontend de forma automatizada

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

info() {
    echo -e "${PURPLE}ℹ️  $1${NC}"
}

# Función de ayuda
usage() {
    echo "Uso: $0 [OPTIONS]"
    echo ""
    echo "Despliega completamente AILOOS (backend + frontend)"
    echo ""
    echo "OPTIONS:"
    echo "  -e, --environment ENV        Ambiente (staging|production) [default: staging]"
    echo "  -p, --project-id ID           GCP Project ID [default: ailoos-ia]"
    echo "  -r, --region REGION           GCP Region [default: us-central1]"
    echo "  -t, --tag TAG                 Docker tag [default: latest]"
    echo "  -v, --vercel-project NAME     Nombre del proyecto en Vercel [default: ailoos]"
    echo "  --skip-backend                Saltar despliegue del backend"
    echo "  --skip-frontend               Saltar despliegue del frontend"
    echo "  --skip-health-check           Saltar verificación de salud"
    echo "  --skip-integration-test       Saltar tests de integración"
    echo "  -h, --help                    Mostrar esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 --environment production"
    echo "  $0 -e staging --skip-integration-test"
    echo "  $0 --skip-backend --skip-health-check  # Solo frontend"
}

# Valores por defecto
ENVIRONMENT="staging"
PROJECT_ID="ailoos-oauth-473213"
REGION="us-central1"
DOCKER_TAG="latest"
VERCEL_PROJECT="frontend"
SKIP_BACKEND=false
SKIP_FRONTEND=false
SKIP_HEALTH_CHECK=false
SKIP_INTEGRATION_TEST=false

# Parsear argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -p|--project-id)
            PROJECT_ID="$2"
            shift 2
            ;;
        -r|--region)
            REGION="$2"
            shift 2
            ;;
        -t|--tag)
            DOCKER_TAG="$2"
            shift 2
            ;;
        -v|--vercel-project)
            VERCEL_PROJECT="$2"
            shift 2
            ;;
        --skip-backend)
            SKIP_BACKEND=true
            shift
            ;;
        --skip-frontend)
            SKIP_FRONTEND=true
            shift
            ;;
        --skip-health-check)
            SKIP_HEALTH_CHECK=true
            shift
            ;;
        --skip-integration-test)
            SKIP_INTEGRATION_TEST=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Opción desconocida: $1"
            usage
            exit 1
            ;;
    esac
done

# Validar ambiente
if [[ "$ENVIRONMENT" != "staging" && "$ENVIRONMENT" != "production" ]]; then
    error "Ambiente inválido: $ENVIRONMENT. Debe ser 'staging' o 'production'"
    exit 1
fi

# Banner
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    🚀 AILOOS DEPLOYMENT                     ║"
echo "║                     Complete System                         ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

log "🚀 Iniciando despliegue completo de AILOOS"
log "Ambiente: $ENVIRONMENT"
log "Proyecto GCP: $PROJECT_ID"
log "Región: $REGION"
log "Proyecto Vercel: $VERCEL_PROJECT"
log "Tag Docker: $DOCKER_TAG"

# Verificar prerrequisitos
log "Verificando prerrequisitos..."

# Verificar gcloud
if ! command -v gcloud &> /dev/null; then
    error "gcloud CLI no está instalado. Instálalo desde: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

# Verificar vercel
if ! command -v vercel &> /dev/null; then
    error "Vercel CLI no está instalado. Instálalo con: npm i -g vercel"
    exit 1
fi

# Verificar autenticaciones
log "Verificando autenticaciones..."

if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    error "No hay cuenta GCP activa. Ejecuta: gcloud auth login"
    exit 1
fi

if ! vercel whoami &> /dev/null; then
    warning "No estás autenticado en Vercel. El script intentará autenticarte automáticamente"
fi

success "Prerrequisitos verificados"

# Función para manejar errores y cleanup
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        error "El despliegue falló con código de salida $exit_code"
        warning "Revisa los logs anteriores para más detalles"
        warning "Puedes reintentar con: $0 $@"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Paso 1: Desplegar backend
if [[ "$SKIP_BACKEND" == false ]]; then
    echo ""
    info "📦 PASO 1: Desplegando Backend (GCP)"
    echo "══════════════════════════════════════"

    ./scripts/deploy_backend.sh \
        --environment "$ENVIRONMENT" \
        --project-id "$PROJECT_ID" \
        --region "$REGION" \
        --tag "$DOCKER_TAG"

    success "Backend desplegado exitosamente"
else
    warning "Saltando despliegue del backend (--skip-backend)"
fi

# Paso 2: Desplegar frontend
if [[ "$SKIP_FRONTEND" == false ]]; then
    echo ""
    info "🌐 PASO 2: Desplegando Frontend (Vercel)"
    echo "═════════════════════════════════════════"

    ./scripts/deploy_frontend.sh \
        --environment "$ENVIRONMENT" \
        --project-name "$VERCEL_PROJECT"

    success "Frontend desplegado exitosamente"
else
    warning "Saltando despliegue del frontend (--skip-frontend)"
fi

# Paso 3: Verificación de salud
if [[ "$SKIP_HEALTH_CHECK" == false ]]; then
    echo ""
    info "🏥 PASO 3: Verificación de Salud"
    echo "══════════════════════════════════"

    if [[ -f "scripts/health_check.sh" ]]; then
        ./scripts/health_check.sh --environment "$ENVIRONMENT"
        success "Verificación de salud completada"
    else
        warning "Script de health check no encontrado, saltando verificación"
    fi
else
    warning "Saltando verificación de salud (--skip-health-check)"
fi

# Paso 4: Tests de integración
if [[ "$SKIP_INTEGRATION_TEST" == false ]]; then
    echo ""
    info "🧪 PASO 4: Tests de Integración"
    echo "════════════════════════════════"

    if [[ -f "scripts/integration_test_production.sh" ]]; then
        ./scripts/integration_test_production.sh --environment "$ENVIRONMENT"
        success "Tests de integración completados"
    else
        warning "Script de tests de integración no encontrado, saltando tests"
    fi
else
    warning "Saltando tests de integración (--skip-integration-test)"
fi

# Paso 5: Configuración de monitoreo
echo ""
info "📊 PASO 5: Configuración de Monitoreo"
echo "═══════════════════════════════════════"

# Aquí podríamos agregar configuración adicional de monitoreo
# Por ahora, solo mostrar información

if [[ "$ENVIRONMENT" == "production" ]]; then
    info "Monitoreo configurado para producción:"
    echo "  - GCP Monitoring: Alertas automáticas activas"
    echo "  - Vercel Analytics: Métricas de rendimiento"
    echo "  - Uptime checks: Verificación cada 5 minutos"
    echo "  - Error tracking: Sentry integrado"
fi

success "Configuración de monitoreo completada"

# Resumen final
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                     🎉 DEPLOYMENT COMPLETE                  ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

log "📋 Resumen del despliegue completo:"
echo ""
echo "🌍 Ambiente: $ENVIRONMENT"
echo "🏗️  Backend: $( [[ "$SKIP_BACKEND" == true ]] && echo "Saltado" || echo "Desplegado en GCP" )"
echo "🌐 Frontend: $( [[ "$SKIP_FRONTEND" == true ]] && echo "Saltado" || echo "Desplegado en Vercel" )"
echo "🏥 Health Check: $( [[ "$SKIP_HEALTH_CHECK" == true ]] && echo "Saltado" || echo "Completado" )"
echo "🧪 Integration Tests: $( [[ "$SKIP_INTEGRATION_TEST" == true ]] && echo "Saltado" || echo "Completados" )"
echo ""

# Mostrar URLs si están disponibles
if [[ -f "backend_config_$ENVIRONMENT.json" ]]; then
    if command -v jq &> /dev/null; then
        GATEWAY_URL=$(jq -r '.gateway_url' "backend_config_$ENVIRONMENT.json")
        echo "🔗 API Gateway: $GATEWAY_URL"
    fi
fi

# URLs de Vercel (si se puede obtener)
if [[ "$SKIP_FRONTEND" == false ]]; then
    echo "🔗 Frontend: $( [[ "$ENVIRONMENT" == "production" ]] && echo "https://ailoos.dev" || echo "Verifica en Vercel Dashboard" )"
fi

echo ""
success "🎊 ¡Despliegue completo de AILOOS finalizado exitosamente!"

# Próximos pasos
echo ""
info "Próximos pasos recomendados:"
echo "1. Verifica que todas las funcionalidades funcionen en $ENVIRONMENT"
echo "2. Monitorea los logs y métricas en GCP/Vercel dashboards"
echo "3. Configura alertas adicionales si es necesario"
echo "4. Actualiza documentación si hay cambios"
echo "5. Notifica al equipo sobre el nuevo despliegue"
echo ""

# Notificación opcional
if [[ "$ENVIRONMENT" == "production" ]]; then
    warning "🎯 ¡ATENCIÓN! Despliegue a PRODUCCIÓN completado"
    warning "Asegúrate de que todos los tests pasaron y el sistema está estable"
fi

log "Deployment script completed at $(date)"