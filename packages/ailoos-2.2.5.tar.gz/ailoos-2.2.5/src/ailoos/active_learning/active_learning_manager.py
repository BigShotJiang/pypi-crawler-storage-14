import numpy as np
from typing import Dict, List, Any, Optional, Type
from sklearn.base import BaseEstimator
from .uncertainty_sampling import UncertaintySampling
from .query_by_committee import QueryByCommittee
from .expected_model_change import ExpectedModelChange
from .density_weighted_sampling import DensityWeightedSampling
from .active_learning_pipeline import ActiveLearningPipeline
import logging

logger = logging.getLogger(__name__)

class ActiveLearningManager:
    """
    Gestor que coordina todas las estrategias de aprendizaje activo.
    Permite cambiar dinámicamente entre estrategias y gestionar múltiples pipelines.
    """

    def __init__(self):
        self.strategies = {}
        self.pipelines = {}
        self.models = {}
        self._register_strategies()

    def _register_strategies(self):
        """Registra todas las estrategias disponibles"""
        self.strategies = {
            'uncertainty_least_confident': lambda **kwargs: UncertaintySampling(method='least_confident'),
            'uncertainty_margin': lambda **kwargs: UncertaintySampling(method='margin'),
            'uncertainty_entropy': lambda **kwargs: UncertaintySampling(method='entropy'),
            'query_by_committee_vote': lambda **kwargs: QueryByCommittee(
                committee=kwargs.get('committee', []),
                disagreement_measure='vote_entropy'
            ),
            'query_by_committee_kl': lambda **kwargs: QueryByCommittee(
                committee=kwargs.get('committee', []),
                disagreement_measure='kl_divergence'
            ),
            'expected_model_change': lambda **kwargs: ExpectedModelChange(
                model_type=kwargs.get('model_type', 'logistic')
            ),
            'density_weighted': lambda **kwargs: DensityWeightedSampling(
                uncertainty_strategy=kwargs.get('uncertainty_strategy'),
                density_weight=kwargs.get('density_weight', 0.5)
            )
        }

    def create_pipeline(self, pipeline_id: str, strategy_name: str, model: BaseEstimator,
                       batch_size: int = 10, max_iterations: int = 50, **strategy_kwargs) -> str:
        """
        Crea un nuevo pipeline de aprendizaje activo.

        Args:
            pipeline_id: Identificador único del pipeline
            strategy_name: Nombre de la estrategia a usar
            model: Modelo base
            batch_size: Tamaño del batch por iteración
            max_iterations: Máximo número de iteraciones
            strategy_kwargs: Parámetros adicionales para la estrategia

        Returns:
            ID del pipeline creado
        """
        try:
            if strategy_name not in self.strategies:
                raise ValueError(f"Estrategia {strategy_name} no registrada")

            strategy = self.strategies[strategy_name](**strategy_kwargs)
            pipeline = ActiveLearningPipeline(strategy, model, batch_size, max_iterations)

            self.pipelines[pipeline_id] = pipeline
            self.models[pipeline_id] = model

            logger.info(f"Pipeline {pipeline_id} creado con estrategia {strategy_name}")
            return pipeline_id

        except Exception as e:
            logger.error(f"Error creando pipeline {pipeline_id}: {e}")
            raise

    def run_pipeline(self, pipeline_id: str, initial_labeled_data: np.ndarray,
                    initial_labels: np.ndarray, unlabeled_data: np.ndarray,
                    oracle: callable, test_data: Optional[np.ndarray] = None,
                    test_labels: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Ejecuta un pipeline específico.

        Args:
            pipeline_id: ID del pipeline a ejecutar
            initial_labeled_data: Datos iniciales etiquetados
            initial_labels: Etiquetas iniciales
            unlabeled_data: Pool de datos no etiquetados
            oracle: Función oráculo para etiquetado
            test_data: Datos de prueba (opcional)
            test_labels: Etiquetas de prueba (opcional)

        Returns:
            Historial del proceso
        """
        if pipeline_id not in self.pipelines:
            raise ValueError(f"Pipeline {pipeline_id} no existe")

        pipeline = self.pipelines[pipeline_id]
        history = pipeline.run(initial_labeled_data, initial_labels, unlabeled_data,
                              oracle, test_data, test_labels)

        logger.info(f"Pipeline {pipeline_id} ejecutado exitosamente")
        return history

    def compare_strategies(self, strategies: List[str], initial_labeled_data: np.ndarray,
                          initial_labels: np.ndarray, unlabeled_data: np.ndarray,
                          oracle: callable, test_data: Optional[np.ndarray] = None,
                          test_labels: Optional[np.ndarray] = None, **kwargs) -> Dict[str, Dict]:
        """
        Compara múltiples estrategias en el mismo conjunto de datos.

        Args:
            strategies: Lista de nombres de estrategias a comparar
            initial_labeled_data: Datos iniciales etiquetados
            initial_labels: Etiquetas iniciales
            unlabeled_data: Pool de datos no etiquetados
            oracle: Función oráculo
            test_data: Datos de prueba (opcional)
            test_labels: Etiquetas de prueba (opcional)
            kwargs: Parámetros adicionales (model, batch_size, etc.)

        Returns:
            Diccionario con resultados de cada estrategia
        """
        results = {}
        model = kwargs.get('model', None)
        batch_size = kwargs.get('batch_size', 10)
        max_iterations = kwargs.get('max_iterations', 20)

        if model is None:
            raise ValueError("Se requiere un modelo para comparación")

        for strategy_name in strategies:
            pipeline_id = f"comparison_{strategy_name}"
            try:
                self.create_pipeline(pipeline_id, strategy_name, model.__class__(),
                                   batch_size, max_iterations, **kwargs)

                history = self.run_pipeline(pipeline_id, initial_labeled_data.copy(),
                                          initial_labels.copy(), unlabeled_data.copy(),
                                          oracle, test_data, test_labels)

                results[strategy_name] = history

            except Exception as e:
                logger.error(f"Error en estrategia {strategy_name}: {e}")
                results[strategy_name] = {'error': str(e)}

        return results

    def get_pipeline(self, pipeline_id: str) -> Optional[ActiveLearningPipeline]:
        """Obtiene un pipeline por ID"""
        return self.pipelines.get(pipeline_id)

    def get_model(self, pipeline_id: str) -> Optional[BaseEstimator]:
        """Obtiene el modelo de un pipeline"""
        return self.models.get(pipeline_id)

    def list_strategies(self) -> List[str]:
        """Lista todas las estrategias disponibles"""
        return list(self.strategies.keys())

    def list_pipelines(self) -> List[str]:
        """Lista todos los pipelines creados"""
        return list(self.pipelines.keys())

    def delete_pipeline(self, pipeline_id: str) -> bool:
        """Elimina un pipeline"""
        if pipeline_id in self.pipelines:
            del self.pipelines[pipeline_id]
            if pipeline_id in self.models:
                del self.models[pipeline_id]
            logger.info(f"Pipeline {pipeline_id} eliminado")
            return True
        return False