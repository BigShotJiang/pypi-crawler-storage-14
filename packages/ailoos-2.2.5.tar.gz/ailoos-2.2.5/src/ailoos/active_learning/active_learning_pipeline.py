import numpy as np
from typing import List, Dict, Any, Optional, Callable
from sklearn.base import BaseEstimator
from sklearn.metrics import accuracy_score
import logging
import time

logger = logging.getLogger(__name__)

class ActiveLearningPipeline:
    """
    Pipeline completo de aprendizaje activo.
    Coordina el proceso de selección de muestras, etiquetado y re-entrenamiento.
    """

    def __init__(self, strategy: Any, model: BaseEstimator, batch_size: int = 10,
                 max_iterations: int = 50, stopping_criterion: Optional[Callable] = None):
        """
        Inicializa ActiveLearningPipeline.

        Args:
            strategy: Estrategia de selección de muestras
            model: Modelo base para entrenamiento
            batch_size: Número de muestras a seleccionar por iteración
            max_iterations: Máximo número de iteraciones
            stopping_criterion: Función que determina cuándo detener (opcional)
        """
        self.strategy = strategy
        self.model = model
        self.batch_size = batch_size
        self.max_iterations = max_iterations
        self.stopping_criterion = stopping_criterion or self._default_stopping_criterion

        self.history = {
            'iterations': [],
            'accuracy': [],
            'labeled_samples': [],
            'selected_indices': [],
            'time_elapsed': []
        }

    def run(self, initial_labeled_data: np.ndarray, initial_labels: np.ndarray,
            unlabeled_data: np.ndarray, oracle: Callable[[np.ndarray], np.ndarray],
            test_data: Optional[np.ndarray] = None, test_labels: Optional[np.ndarray] = None) -> Dict[str, Any]:
        """
        Ejecuta el pipeline de aprendizaje activo.

        Args:
            initial_labeled_data: Datos iniciales etiquetados
            initial_labels: Etiquetas iniciales
            unlabeled_data: Pool de datos no etiquetados
            oracle: Función que proporciona etiquetas para muestras seleccionadas
            test_data: Datos de prueba para evaluación (opcional)
            test_labels: Etiquetas de prueba (opcional)

        Returns:
            Diccionario con historial del proceso
        """
        try:
            # Inicializar
            labeled_data = initial_labeled_data.copy()
            labeled_labels = initial_labels.copy()
            unlabeled_pool = unlabeled_data.copy()
            pool_indices = list(range(len(unlabeled_pool)))

            start_time = time.time()

            for iteration in range(self.max_iterations):
                logger.info(f"Iteración {iteration + 1}/{self.max_iterations}")

                # Entrenar modelo con datos actuales
                self.model.fit(labeled_data, labeled_labels)

                # Evaluar rendimiento si hay datos de prueba
                accuracy = None
                if test_data is not None and test_labels is not None:
                    predictions = self.model.predict(test_data)
                    accuracy = accuracy_score(test_labels, predictions)

                # Registrar progreso
                self._record_iteration(iteration, accuracy, len(labeled_data), time.time() - start_time)

                # Verificar criterio de parada
                if self.stopping_criterion(iteration, accuracy, len(labeled_data)):
                    logger.info("Criterio de parada alcanzado")
                    break

                # Seleccionar nuevas muestras
                if len(unlabeled_pool) < self.batch_size:
                    logger.info("No hay suficientes muestras no etiquetadas")
                    break

                selected_indices = self._select_samples(unlabeled_pool)

                # Obtener etiquetas del oráculo
                selected_samples = unlabeled_pool[selected_indices]
                new_labels = oracle(selected_samples)

                # Agregar a conjunto etiquetado
                labeled_data = np.vstack([labeled_data, selected_samples])
                labeled_labels = np.append(labeled_labels, new_labels)

                # Remover del pool no etiquetado
                unlabeled_pool = np.delete(unlabeled_pool, selected_indices, axis=0)
                selected_original_indices = [pool_indices[i] for i in selected_indices]
                pool_indices = [pool_indices[i] for i in range(len(pool_indices)) if i not in selected_indices]

                # Registrar índices seleccionados
                self.history['selected_indices'].append(selected_original_indices)

            # Entrenamiento final
            self.model.fit(labeled_data, labeled_labels)

            logger.info("Pipeline completado")
            return self.history

        except Exception as e:
            logger.error(f"Error en run: {e}")
            raise

    def _select_samples(self, unlabeled_pool: np.ndarray) -> List[int]:
        """Selecciona muestras usando la estrategia configurada"""
        if hasattr(self.strategy, 'select_samples'):
            # Estrategias que necesitan el modelo
            return self.strategy.select_samples(self.model, unlabeled_pool, self.batch_size)
        else:
            # Estrategias que solo necesitan datos
            return self.strategy(unlabeled_pool, self.batch_size)

    def _record_iteration(self, iteration: int, accuracy: Optional[float],
                         n_labeled: int, time_elapsed: float):
        """Registra el progreso de una iteración"""
        self.history['iterations'].append(iteration)
        self.history['accuracy'].append(accuracy)
        self.history['labeled_samples'].append(n_labeled)
        self.history['time_elapsed'].append(time_elapsed)

    def _default_stopping_criterion(self, iteration: int, accuracy: Optional[float], n_labeled: int) -> bool:
        """Criterio de parada por defecto: máximo de iteraciones"""
        return iteration >= self.max_iterations - 1

    def get_model(self) -> BaseEstimator:
        """Retorna el modelo entrenado"""
        return self.model

    def get_history(self) -> Dict[str, List]:
        """Retorna el historial del proceso"""
        return self.history