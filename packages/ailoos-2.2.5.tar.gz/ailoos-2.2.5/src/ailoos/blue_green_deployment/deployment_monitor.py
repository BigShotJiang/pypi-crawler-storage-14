"""
Deployment Monitor for Blue-Green Deployments.

Provides real-time monitoring of deployments, collects metrics,
analyzes performance, and triggers alerts based on configurable thresholds.
"""

import logging
import time
import threading
import statistics
from typing import Dict, Any, List, Optional, Callable
from collections import deque
from dataclasses import dataclass
from enum import Enum


class MetricType(Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class MetricData:
    """
    Represents a metric data point.
    """
    name: str
    value: float
    timestamp: float
    tags: Dict[str, str]


@dataclass
class Alert:
    """
    Represents an alert.
    """
    id: str
    severity: AlertSeverity
    message: str
    timestamp: float
    environment: str
    metric_name: Optional[str] = None
    threshold: Optional[float] = None
    current_value: Optional[float] = None


class DeploymentMonitor:
    """
    Monitors blue-green deployments in real-time.

    Collects metrics, analyzes performance, and provides monitoring insights.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the Deployment Monitor.

        Args:
            config: Configuration dictionary containing:
                - metrics_retention_period: How long to keep metrics (seconds)
                - alert_rules: List of alert rule configurations
                - monitoring_interval: Interval between monitoring checks (seconds)
                - enable_real_time: Whether to enable real-time monitoring
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

        self.metrics_retention_period = config.get('metrics_retention_period', 3600)  # 1 hour
        self.monitoring_interval = config.get('monitoring_interval', 30)
        self.enable_real_time = config.get('enable_real_time', True)

        # Metrics storage
        self.metrics: Dict[str, deque] = {}

        # Alert rules
        self.alert_rules: List[Dict[str, Any]] = config.get('alert_rules', [])

        # Active alerts
        self.active_alerts: Dict[str, Alert] = {}

        # Callbacks for alerts
        self.alert_callbacks: List[Callable] = []

        # Monitoring thread
        self.monitoring_thread: Optional[threading.Thread] = None
        self.stop_monitoring = False

        # Start monitoring if enabled
        if self.enable_real_time:
            self.start_monitoring()

    def start_monitoring(self):
        """
        Start the real-time monitoring thread.
        """
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.logger.warning("Monitoring already running")
            return

        self.stop_monitoring = False
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        self.logger.info("Started real-time deployment monitoring")

    def stop_monitoring(self):
        """
        Stop the real-time monitoring thread.
        """
        self.stop_monitoring = True
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        self.logger.info("Stopped real-time deployment monitoring")

    def record_metric(self, name: str, value: float, tags: Optional[Dict[str, str]] = None):
        """
        Record a metric data point.

        Args:
            name: Metric name
            value: Metric value
            tags: Optional tags for the metric
        """
        if tags is None:
            tags = {}

        metric_data = MetricData(
            name=name,
            value=value,
            timestamp=time.time(),
            tags=tags
        )

        if name not in self.metrics:
            self.metrics[name] = deque()

        self.metrics[name].append(metric_data)

        # Clean old metrics
        self._cleanup_old_metrics(name)

        # Check alert rules
        self._check_alert_rules(metric_data)

    def get_metric_stats(self, name: str, time_range: Optional[float] = None) -> Dict[str, Any]:
        """
        Get statistics for a metric.

        Args:
            name: Metric name
            time_range: Time range in seconds (None for all data)

        Returns:
            dict: Metric statistics
        """
        if name not in self.metrics:
            return {'error': 'Metric not found'}

        metrics = list(self.metrics[name])

        if time_range:
            cutoff = time.time() - time_range
            metrics = [m for m in metrics if m.timestamp >= cutoff]

        if not metrics:
            return {'error': 'No data in time range'}

        values = [m.value for m in metrics]

        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'avg': statistics.mean(values),
            'median': statistics.median(values),
            'stddev': statistics.stdev(values) if len(values) > 1 else 0,
            'latest': values[-1],
            'time_range': time_range
        }

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """
        Get statistics for all metrics.

        Returns:
            dict: All metric statistics
        """
        return {name: self.get_metric_stats(name) for name in self.metrics.keys()}

    def add_alert_rule(self, rule_config: Dict[str, Any]):
        """
        Add an alert rule.

        Args:
            rule_config: Alert rule configuration containing:
                - name: Rule name
                - metric: Metric name
                - condition: Condition (gt, lt, eq, etc.)
                - threshold: Threshold value
                - severity: Alert severity
                - message: Alert message template
        """
        self.alert_rules.append(rule_config)
        self.logger.info(f"Added alert rule: {rule_config['name']}")

    def remove_alert_rule(self, rule_name: str):
        """
        Remove an alert rule.

        Args:
            rule_name: Name of rule to remove
        """
        self.alert_rules = [rule for rule in self.alert_rules if rule['name'] != rule_name]
        self.logger.info(f"Removed alert rule: {rule_name}")

    def add_alert_callback(self, callback: Callable[[Alert], None]):
        """
        Add a callback for alert notifications.

        Args:
            callback: Function to call when alert is triggered
        """
        self.alert_callbacks.append(callback)

    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """
        Get list of active alerts.

        Returns:
            list: Active alerts
        """
        return [
            {
                'id': alert.id,
                'severity': alert.severity.value,
                'message': alert.message,
                'timestamp': alert.timestamp,
                'environment': alert.environment,
                'metric_name': alert.metric_name,
                'threshold': alert.threshold,
                'current_value': alert.current_value
            }
            for alert in self.active_alerts.values()
        ]

    def acknowledge_alert(self, alert_id: str):
        """
        Acknowledge an alert.

        Args:
            alert_id: ID of alert to acknowledge
        """
        if alert_id in self.active_alerts:
            del self.active_alerts[alert_id]
            self.logger.info(f"Acknowledged alert: {alert_id}")

    def _monitoring_loop(self):
        """
        Main monitoring loop.
        """
        while not self.stop_monitoring:
            try:
                self._collect_system_metrics()
                self._analyze_performance()
                time.sleep(self.monitoring_interval)
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(self.monitoring_interval)

    def _collect_system_metrics(self):
        """
        Collect system-level metrics.
        """
        # In a real implementation, this would collect:
        # - CPU usage
        # - Memory usage
        # - Network I/O
        # - Disk I/O
        # - Response times
        # - Error rates

        # Simulate metric collection
        import random

        self.record_metric('cpu_usage', random.uniform(10, 90), {'environment': 'blue'})
        self.record_metric('cpu_usage', random.uniform(10, 90), {'environment': 'green'})
        self.record_metric('memory_usage', random.uniform(20, 80), {'environment': 'blue'})
        self.record_metric('memory_usage', random.uniform(20, 80), {'environment': 'green'})
        self.record_metric('response_time', random.uniform(50, 500), {'environment': 'blue'})
        self.record_metric('response_time', random.uniform(50, 500), {'environment': 'green'})
        self.record_metric('error_rate', random.uniform(0, 5), {'environment': 'blue'})
        self.record_metric('error_rate', random.uniform(0, 5), {'environment': 'green'})

    def _analyze_performance(self):
        """
        Analyze performance metrics and detect anomalies.
        """
        # Analyze response times for performance degradation
        blue_response_times = self.get_metric_stats('response_time', 300)  # Last 5 minutes
        green_response_times = self.get_metric_stats('response_time', 300)

        if 'avg' in blue_response_times and 'avg' in green_response_times:
            blue_avg = blue_response_times['avg']
            green_avg = green_response_times['avg']

            # Check for significant performance difference
            if abs(blue_avg - green_avg) > 100:  # 100ms difference threshold
                self._trigger_performance_alert(blue_avg, green_avg)

    def _trigger_performance_alert(self, blue_avg: float, green_avg: float):
        """
        Trigger a performance alert.

        Args:
            blue_avg: Blue environment average response time
            green_avg: Green environment average response time
        """
        alert = Alert(
            id=f"perf_diff_{int(time.time())}",
            severity=AlertSeverity.WARNING,
            message=f"Performance difference detected: Blue={blue_avg:.1f}ms, Green={green_avg:.1f}ms",
            timestamp=time.time(),
            environment='both',
            metric_name='response_time'
        )

        self.active_alerts[alert.id] = alert
        self._notify_alert_callbacks(alert)

    def _check_alert_rules(self, metric_data: MetricData):
        """
        Check alert rules against metric data.

        Args:
            metric_data: Metric data point
        """
        for rule in self.alert_rules:
            if rule['metric'] != metric_data.name:
                continue

            condition = rule['condition']
            threshold = rule['threshold']
            value = metric_data.value

            triggered = False

            if condition == 'gt' and value > threshold:
                triggered = True
            elif condition == 'lt' and value < threshold:
                triggered = True
            elif condition == 'eq' and value == threshold:
                triggered = True
            elif condition == 'gte' and value >= threshold:
                triggered = True
            elif condition == 'lte' and value <= threshold:
                triggered = True

            if triggered:
                self._trigger_alert(rule, metric_data)

    def _trigger_alert(self, rule: Dict[str, Any], metric_data: MetricData):
        """
        Trigger an alert based on a rule.

        Args:
            rule: Alert rule configuration
            metric_data: Metric data that triggered the alert
        """
        alert_id = f"{rule['name']}_{metric_data.name}_{int(time.time())}"

        alert = Alert(
            id=alert_id,
            severity=AlertSeverity(rule['severity']),
            message=rule['message'].format(
                metric=metric_data.name,
                value=metric_data.value,
                threshold=rule['threshold']
            ),
            timestamp=time.time(),
            environment=metric_data.tags.get('environment', 'unknown'),
            metric_name=metric_data.name,
            threshold=rule['threshold'],
            current_value=metric_data.value
        )

        self.active_alerts[alert.id] = alert
        self._notify_alert_callbacks(alert)

    def _notify_alert_callbacks(self, alert: Alert):
        """
        Notify all alert callbacks.

        Args:
            alert: Alert to notify about
        """
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Error in alert callback: {e}")

    def _cleanup_old_metrics(self, metric_name: str):
        """
        Clean up old metric data points.

        Args:
            metric_name: Name of metric to clean up
        """
        if metric_name not in self.metrics:
            return

        cutoff = time.time() - self.metrics_retention_period
        metrics_queue = self.metrics[metric_name]

        while metrics_queue and metrics_queue[0].timestamp < cutoff:
            metrics_queue.popleft()

    def get_monitoring_status(self) -> Dict[str, Any]:
        """
        Get monitoring system status.

        Returns:
            dict: Monitoring status information
        """
        return {
            'monitoring_active': self.monitoring_thread and self.monitoring_thread.is_alive(),
            'metrics_count': len(self.metrics),
            'total_data_points': sum(len(queue) for queue in self.metrics.values()),
            'active_alerts_count': len(self.active_alerts),
            'alert_rules_count': len(self.alert_rules),
            'retention_period': self.metrics_retention_period,
            'monitoring_interval': self.monitoring_interval
        }