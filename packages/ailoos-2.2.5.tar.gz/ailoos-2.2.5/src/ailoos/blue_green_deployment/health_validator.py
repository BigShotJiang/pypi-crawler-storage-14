"""
Health Validator for Blue-Green Deployments.

Validates the health of deployed applications through various checks
including HTTP endpoints, metrics, and custom health indicators.
"""

import logging
import time
import requests
from typing import Dict, Any, List, Optional, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
import statistics


class HealthCheck:
    """
    Represents a single health check configuration.
    """

    def __init__(self, name: str, check_type: str, config: Dict[str, Any]):
        self.name = name
        self.check_type = check_type
        self.config = config
        self.last_result = None
        self.last_check_time = None


class HealthValidator:
    """
    Validates health of blue-green deployment environments.

    Supports multiple types of health checks and provides comprehensive
    health assessment for deployment validation.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the Health Validator.

        Args:
            config: Configuration dictionary containing:
                - health_checks: List of health check configurations
                - validation_timeout: Timeout for validation (seconds)
                - success_threshold: Percentage of successful checks required
                - retry_attempts: Number of retry attempts for failed checks
                - check_interval: Interval between health checks (seconds)
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

        self.validation_timeout = config.get('validation_timeout', 300)
        self.success_threshold = config.get('success_threshold', 95.0)
        self.retry_attempts = config.get('retry_attempts', 3)
        self.check_interval = config.get('check_interval', 10)

        # Health checks by environment
        self.health_checks: Dict[str, List[HealthCheck]] = {'blue': [], 'green': []}

        # Health status cache
        self.health_status = {'blue': {}, 'green': {}}

        # Load health checks from config
        self._load_health_checks()

    def _load_health_checks(self):
        """Load health check configurations."""
        checks_config = self.config.get('health_checks', [])

        for check_config in checks_config:
            check = HealthCheck(
                name=check_config['name'],
                check_type=check_config['type'],
                config=check_config
            )

            # Add to both environments (they can be environment-specific later)
            for env in ['blue', 'green']:
                self.health_checks[env].append(check)

    def validate(self, environment: str) -> bool:
        """
        Validate health of the specified environment.

        Args:
            environment: Environment to validate ('blue' or 'green')

        Returns:
            bool: True if environment is healthy, False otherwise
        """
        if environment not in ['blue', 'green']:
            self.logger.error(f"Invalid environment: {environment}")
            return False

        self.logger.info(f"Starting health validation for {environment}")

        start_time = time.time()
        successful_checks = 0
        total_checks = len(self.health_checks[environment])

        if total_checks == 0:
            self.logger.warning(f"No health checks configured for {environment}")
            return True

        # Perform health checks with retries
        for attempt in range(self.retry_attempts):
            self.logger.info(f"Health check attempt {attempt + 1}/{self.retry_attempts} for {environment}")

            results = self._perform_health_checks(environment)

            successful_checks = sum(1 for result in results.values() if result['status'] == 'healthy')
            success_rate = (successful_checks / total_checks) * 100

            self.logger.info(f"Attempt {attempt + 1}: {successful_checks}/{total_checks} checks passed ({success_rate:.1f}%)")

            if success_rate >= self.success_threshold:
                self.logger.info(f"Health validation successful for {environment}")
                return True

            if attempt < self.retry_attempts - 1:
                self.logger.warning(f"Health validation failed, retrying in {self.check_interval}s")
                time.sleep(self.check_interval)

        self.logger.error(f"Health validation failed for {environment} after {self.retry_attempts} attempts")
        return False

    def _perform_health_checks(self, environment: str) -> Dict[str, Dict[str, Any]]:
        """
        Perform all health checks for an environment.

        Args:
            environment: Target environment

        Returns:
            dict: Health check results
        """
        results = {}

        # Use thread pool for parallel checks
        with ThreadPoolExecutor(max_workers=min(len(self.health_checks[environment]), 10)) as executor:
            future_to_check = {
                executor.submit(self._execute_health_check, check, environment): check
                for check in self.health_checks[environment]
            }

            for future in as_completed(future_to_check):
                check = future_to_check[future]
                try:
                    result = future.result()
                    results[check.name] = result
                    check.last_result = result
                    check.last_check_time = time.time()
                except Exception as e:
                    self.logger.error(f"Health check {check.name} failed with exception: {e}")
                    results[check.name] = {
                        'status': 'error',
                        'error': str(e),
                        'timestamp': time.time()
                    }

        # Update health status cache
        self.health_status[environment] = results
        return results

    def _execute_health_check(self, check: HealthCheck, environment: str) -> Dict[str, Any]:
        """
        Execute a single health check.

        Args:
            check: Health check to execute
            environment: Target environment

        Returns:
            dict: Health check result
        """
        try:
            if check.check_type == 'http':
                return self._http_health_check(check, environment)
            elif check.check_type == 'tcp':
                return self._tcp_health_check(check, environment)
            elif check.check_type == 'metric':
                return self._metric_health_check(check, environment)
            elif check.check_type == 'custom':
                return self._custom_health_check(check, environment)
            else:
                return {
                    'status': 'error',
                    'error': f"Unknown check type: {check.check_type}",
                    'timestamp': time.time()
                }
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'timestamp': time.time()
            }

    def _http_health_check(self, check: HealthCheck, environment: str) -> Dict[str, Any]:
        """
        Perform HTTP health check.

        Args:
            check: Health check configuration
            environment: Target environment

        Returns:
            dict: Check result
        """
        url = check.config.get('url', '').format(environment=environment)
        method = check.config.get('method', 'GET')
        expected_status = check.config.get('expected_status', 200)
        timeout = check.config.get('timeout', 10)

        try:
            response = requests.request(method, url, timeout=timeout)

            if response.status_code == expected_status:
                return {
                    'status': 'healthy',
                    'response_time': response.elapsed.total_seconds(),
                    'status_code': response.status_code,
                    'timestamp': time.time()
                }
            else:
                return {
                    'status': 'unhealthy',
                    'error': f"Unexpected status code: {response.status_code}",
                    'status_code': response.status_code,
                    'timestamp': time.time()
                }
        except requests.RequestException as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': time.time()
            }

    def _tcp_health_check(self, check: HealthCheck, environment: str) -> Dict[str, Any]:
        """
        Perform TCP health check.

        Args:
            check: Health check configuration
            environment: Target environment

        Returns:
            dict: Check result
        """
        import socket

        host = check.config.get('host', '').format(environment=environment)
        port = check.config.get('port', 80)
        timeout = check.config.get('timeout', 5)

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()

            if result == 0:
                return {
                    'status': 'healthy',
                    'timestamp': time.time()
                }
            else:
                return {
                    'status': 'unhealthy',
                    'error': f"Connection failed to {host}:{port}",
                    'timestamp': time.time()
                }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': time.time()
            }

    def _metric_health_check(self, check: HealthCheck, environment: str) -> Dict[str, Any]:
        """
        Perform metric-based health check.

        Args:
            check: Health check configuration
            environment: Target environment

        Returns:
            dict: Check result
        """
        # In a real implementation, this would query monitoring systems
        # like Prometheus, CloudWatch, etc.
        # For now, simulate a metric check

        metric_name = check.config.get('metric', 'cpu_usage')
        threshold = check.config.get('threshold', 80)

        # Simulate metric value
        metric_value = 45.0  # Assume healthy

        if metric_value <= threshold:
            return {
                'status': 'healthy',
                'metric_value': metric_value,
                'threshold': threshold,
                'timestamp': time.time()
            }
        else:
            return {
                'status': 'unhealthy',
                'error': f"Metric {metric_name} exceeded threshold: {metric_value} > {threshold}",
                'metric_value': metric_value,
                'threshold': threshold,
                'timestamp': time.time()
            }

    def _custom_health_check(self, check: HealthCheck, environment: str) -> Dict[str, Any]:
        """
        Perform custom health check.

        Args:
            check: Health check configuration
            environment: Target environment

        Returns:
            dict: Check result
        """
        # Custom checks would be implemented via plugins or callbacks
        # For now, assume healthy
        return {
            'status': 'healthy',
            'message': 'Custom check passed',
            'timestamp': time.time()
        }

    def get_health_status(self, environment: Optional[str] = None) -> Dict[str, Any]:
        """
        Get current health status.

        Args:
            environment: Specific environment or None for all

        Returns:
            dict: Health status information
        """
        if environment:
            return {
                'environment': environment,
                'checks': self.health_status.get(environment, {}),
                'overall_healthy': self._is_environment_healthy(environment)
            }
        else:
            return {
                'blue': self.get_health_status('blue'),
                'green': self.get_health_status('green')
            }

    def _is_environment_healthy(self, environment: str) -> bool:
        """
        Check if an environment is currently healthy.

        Args:
            environment: Environment to check

        Returns:
            bool: True if healthy
        """
        results = self.health_status.get(environment, {})
        if not results:
            return False

        successful = sum(1 for result in results.values() if result.get('status') == 'healthy')
        total = len(results)
        success_rate = (successful / total) * 100 if total > 0 else 0

        return success_rate >= self.success_threshold

    def add_health_check(self, environment: str, check_config: Dict[str, Any]):
        """
        Add a health check for an environment.

        Args:
            environment: Target environment
            check_config: Health check configuration
        """
        check = HealthCheck(
            name=check_config['name'],
            check_type=check_config['type'],
            config=check_config
        )

        self.health_checks[environment].append(check)
        self.logger.info(f"Added health check {check.name} for {environment}")

    def remove_health_check(self, environment: str, check_name: str):
        """
        Remove a health check from an environment.

        Args:
            environment: Target environment
            check_name: Name of check to remove
        """
        self.health_checks[environment] = [
            check for check in self.health_checks[environment]
            if check.name != check_name
        ]
        self.logger.info(f"Removed health check {check_name} from {environment}")