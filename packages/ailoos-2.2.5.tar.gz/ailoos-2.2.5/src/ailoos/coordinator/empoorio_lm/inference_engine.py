"""
EmpoorioLM Inference Engine
Motor de inferencia optimizado para modelos EmpoorioLM con streaming y batch processing.
"""

import asyncio
import time
import torch
import threading
from typing import Dict, List, Any, Optional, Tuple, AsyncGenerator
from dataclasses import dataclass, field
import logging
from concurrent.futures import ThreadPoolExecutor
import queue
import numpy as np

from ...models.empoorio_lm import EmpoorioLM
from .model_manager import ModelManager

logger = logging.getLogger(__name__)


@dataclass
class InferenceRequest:
    """Solicitud de inferencia."""

    request_id: str
    model_version: str
    input_text: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    priority: int = 1  # 1=normal, 2=high, 3=critical


@dataclass
class InferenceResult:
    """Resultado de inferencia."""

    request_id: str
    output_text: str
    tokens_generated: int
    processing_time: float
    model_version: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchInferenceRequest:
    """Solicitud de inferencia por lotes."""

    batch_id: str
    requests: List[InferenceRequest]
    created_at: float = field(default_factory=time.time)


@dataclass
class InferenceEngineConfig:
    """Configuración del Inference Engine."""

    # Configuración de procesamiento
    max_concurrent_requests: int = 10
    max_batch_size: int = 8
    request_timeout_seconds: int = 300

    # Configuración de streaming
    enable_streaming: bool = True
    stream_chunk_size: int = 10  # Tokens por chunk

    # Configuración de optimización
    enable_dynamic_batching: bool = True
    batch_timeout_ms: int = 50  # Tiempo máximo esperando batch completo

    # Configuración de calidad
    enable_quality_filtering: bool = True
    min_confidence_threshold: float = 0.1

    # Configuración de recursos
    max_workers: int = 4
    enable_gpu_optimization: bool = True


class InferenceEngine:
    """
    Motor de inferencia para EmpoorioLM.

    Funcionalidades:
    - Inferencia síncrona y asíncrona
    - Streaming de tokens en tiempo real
    - Batch processing para eficiencia
    - Queue management con prioridades
    - Optimizaciones GPU/CPU
    - Monitoreo de rendimiento
    """

    def __init__(self, config: InferenceEngineConfig, model_manager: ModelManager):
        self.config = config
        self.model_manager = model_manager

        # Colas de procesamiento
        self.request_queue = asyncio.Queue()
        self.batch_queue = asyncio.Queue()

        # Estado del engine
        self.is_running = False
        self.active_requests: Dict[str, InferenceRequest] = {}
        self.processing_tasks: Dict[str, asyncio.Task] = {}

        # Thread pool para operaciones CPU-bound
        self.executor = ThreadPoolExecutor(max_workers=config.max_workers)

        # Estadísticas
        self.stats = {
            "total_requests_processed": 0,
            "total_tokens_generated": 0,
            "avg_processing_time": 0.0,
            "queue_wait_time_avg": 0.0,
            "batch_efficiency": 0.0,
            "cache_hit_rate": 0.0
        }

        # Locks para thread safety
        self.stats_lock = threading.Lock()

        logger.info(f"🚀 Inference Engine inicializado - Workers: {config.max_workers}")

    async def start(self):
        """Iniciar el engine de inferencia."""
        if self.is_running:
            return

        self.is_running = True

        # Iniciar workers
        for i in range(self.config.max_workers):
            asyncio.create_task(self._worker_loop(i))

        # Iniciar batch processor si está habilitado
        if self.config.enable_dynamic_batching:
            asyncio.create_task(self._batch_processor())

        logger.info("✅ Inference Engine iniciado")

    async def stop(self):
        """Detener el engine de inferencia."""
        self.is_running = False

        # Cancelar todas las tareas activas
        for task in self.processing_tasks.values():
            task.cancel()

        # Cerrar executor
        self.executor.shutdown(wait=True)

        logger.info("🛑 Inference Engine detenido")

    async def submit_request(
        self,
        model_version: str,
        input_text: str,
        parameters: Optional[Dict[str, Any]] = None,
        priority: int = 1
    ) -> str:
        """
        Enviar solicitud de inferencia.

        Args:
            model_version: Versión del modelo a usar
            input_text: Texto de entrada
            parameters: Parámetros de generación
            priority: Prioridad de la solicitud (1-3)

        Returns:
            ID de la solicitud
        """
        request_id = f"req_{int(time.time() * 1000)}_{hash(input_text) % 10000}"

        request = InferenceRequest(
            request_id=request_id,
            model_version=model_version,
            input_text=input_text,
            parameters=parameters or {},
            priority=priority
        )

        # Añadir a cola
        await self.request_queue.put(request)
        self.active_requests[request_id] = request

        logger.debug(f"📨 Solicitud enviada: {request_id}")
        return request_id

    async def submit_batch_request(
        self,
        requests: List[Tuple[str, str, Optional[Dict[str, Any]]]]
    ) -> str:
        """
        Enviar solicitud de inferencia por lotes.

        Args:
            requests: Lista de (model_version, input_text, parameters)

        Returns:
            ID del batch
        """
        batch_id = f"batch_{int(time.time() * 1000)}_{len(requests)}"

        inference_requests = []
        for model_version, input_text, parameters in requests:
            request_id = f"{batch_id}_{len(inference_requests)}"
            request = InferenceRequest(
                request_id=request_id,
                model_version=model_version,
                input_text=input_text,
                parameters=parameters or {}
            )
            inference_requests.append(request)
            self.active_requests[request_id] = request

        batch_request = BatchInferenceRequest(
            batch_id=batch_id,
            requests=inference_requests
        )

        await self.batch_queue.put(batch_request)

        logger.debug(f"📦 Batch enviado: {batch_id} ({len(requests)} requests)")
        return batch_id

    async def get_result(self, request_id: str, timeout: float = 30.0) -> Optional[InferenceResult]:
        """
        Obtener resultado de una solicitud.

        Args:
            request_id: ID de la solicitud
            timeout: Tiempo máximo de espera

        Returns:
            Resultado o None si timeout
        """
        if request_id not in self.active_requests:
            return None

        # Esperar a que se complete (simplificado - en producción usar eventos)
        start_time = time.time()
        while time.time() - start_time < timeout:
            if request_id not in self.processing_tasks:
                # Buscar resultado en algún lugar (simplificado)
                # En implementación real, mantener un dict de resultados
                await asyncio.sleep(0.1)
            else:
                await asyncio.sleep(0.1)

        return None  # Placeholder

    async def stream_inference(
        self,
        model_version: str,
        input_text: str,
        parameters: Optional[Dict[str, Any]] = None
    ) -> AsyncGenerator[str, None]:
        """
        Realizar inferencia con streaming de tokens.

        Args:
            model_version: Versión del modelo
            input_text: Texto de entrada
            parameters: Parámetros de generación

        Yields:
            Chunks de texto generado
        """
        if not self.config.enable_streaming:
            # Fallback a inferencia normal
            result = await self._perform_inference(model_version, input_text, parameters)
            if result:
                yield result.output_text
            return

        # Obtener modelo y tokenizer
        model_data = await self.model_manager.get_model(model_version)
        if model_data is None:
            logger.error(f"❌ Modelo y tokenizer no disponibles: {model_version}")
            return
        model, tokenizer = model_data

        # Preparar input
        input_ids = tokenizer.encode(input_text)
        input_tensor = torch.tensor([input_ids]).to(model.device)

        # Parámetros de generación
        gen_params = self._prepare_generation_params(parameters)

        try:
            generated_tokens = input_ids.copy()
            current_length = len(generated_tokens)

            while current_length < gen_params.get("max_length", 100):
                # Forward pass
                with torch.no_grad():
                    outputs = model(input_tensor)
                    next_token_logits = outputs["logits"][:, -1, :]

                # Aplicar temperatura y sampling
                next_token = self._sample_next_token(next_token_logits, gen_params)

                # Añadir token
                generated_tokens.append(next_token.item())
                current_length += 1

                # Convertir a texto y yield
                new_text = tokenizer.decode([next_token.item()], skip_special_tokens=True)
                yield new_text

                # Actualizar input para siguiente iteración
                input_tensor = torch.tensor([generated_tokens]).to(model.device)

                # Verificar condiciones de parada
                if next_token.item() in gen_params.get("eos_token_ids", [tokenizer.eos_token_id]):
                    break

        except Exception as e:
            logger.error(f"Error en streaming: {e}")

    async def _worker_loop(self, worker_id: int):
        """Loop principal de worker."""
        logger.debug(f"👷 Worker {worker_id} iniciado")

        while self.is_running:
            try:
                # Obtener solicitud de la cola
                request = await self.request_queue.get()

                # Procesar solicitud
                task = asyncio.create_task(self._process_request(request))
                self.processing_tasks[request.request_id] = task

                # Esperar a que termine
                await task

                # Limpiar
                del self.processing_tasks[request.request_id]
                del self.active_requests[request.request_id]

                self.request_queue.task_done()

            except Exception as e:
                logger.error(f"Error en worker {worker_id}: {e}")

    async def _batch_processor(self):
        """Procesador de batches para eficiencia."""
        logger.debug("📦 Batch processor iniciado")

        while self.is_running:
            try:
                # Esperar batch o timeout
                batch_request = await asyncio.wait_for(
                    self.batch_queue.get(),
                    timeout=self.config.batch_timeout_ms / 1000
                )

                # Procesar batch
                await self._process_batch(batch_request)
                self.batch_queue.task_done()

            except asyncio.TimeoutError:
                # Procesar requests individuales si hay suficientes
                await self._process_pending_requests_as_batch()

            except Exception as e:
                logger.error(f"Error en batch processor: {e}")

    async def _process_request(self, request: InferenceRequest) -> Optional[InferenceResult]:
        """Procesar una solicitud individual."""
        start_time = time.time()

        try:
            # Realizar inferencia
            result = await self._perform_inference(
                request.model_version,
                request.input_text,
                request.parameters
            )

            if result:
                processing_time = time.time() - start_time
                result.processing_time = processing_time

                # Actualizar estadísticas
                with self.stats_lock:
                    self.stats["total_requests_processed"] += 1
                    self.stats["total_tokens_generated"] += result.tokens_generated
                    # Actualizar promedio
                    current_avg = self.stats["avg_processing_time"]
                    count = self.stats["total_requests_processed"]
                    self.stats["avg_processing_time"] = (current_avg * (count - 1) + processing_time) / count

                logger.debug(f"✅ Solicitud procesada: {request.request_id} ({processing_time:.2f}s)")
                return result

        except Exception as e:
            logger.error(f"❌ Error procesando solicitud {request.request_id}: {e}")

        return None

    async def _process_batch(self, batch_request: BatchInferenceRequest):
        """Procesar un batch de solicitudes."""
        if not batch_request.requests:
            return

        start_time = time.time()

        try:
            # Agrupar por modelo para eficiencia
            model_groups = {}
            for request in batch_request.requests:
                model_version = request.model_version
                if model_version not in model_groups:
                    model_groups[model_version] = []
                model_groups[model_version].append(request)

            # Procesar cada grupo
            all_results = []
            for model_version, requests in model_groups.items():
                batch_results = await self._perform_batch_inference(model_version, requests)
                all_results.extend(batch_results)

            processing_time = time.time() - start_time

            # Actualizar estadísticas de batch
            with self.stats_lock:
                batch_size = len(batch_request.requests)
                self.stats["batch_efficiency"] = (
                    (self.stats["batch_efficiency"] * 0.9) +
                    (batch_size / max(1, processing_time)) * 0.1
                )

            logger.debug(f"✅ Batch procesado: {batch_request.batch_id} "
                        f"({len(batch_request.requests)} requests en {processing_time:.2f}s)")

        except Exception as e:
            logger.error(f"❌ Error procesando batch {batch_request.batch_id}: {e}")

    async def _process_pending_requests_as_batch(self):
        """Procesar requests pendientes como batch si hay suficientes."""
        # Implementación simplificada
        pass

    async def _perform_inference(
        self,
        model_version: str,
        input_text: str,
        parameters: Dict[str, Any]
    ) -> Optional[InferenceResult]:
        """Realizar inferencia individual."""
        try:
            # Obtener modelo y tokenizer
            model_data = await self.model_manager.get_model(model_version)
            if model_data is None:
                logger.error(f"❌ Modelo y tokenizer no disponibles para la versión: {model_version}")
                return None
            model, tokenizer = model_data

            # Preparar input
            input_ids = tokenizer.encode(input_text)
            input_tensor = torch.tensor([input_ids]).to(model.device)

            # Preparar parámetros
            gen_params = self._prepare_generation_params(parameters)

            # Generar
            start_time = time.time()
            with torch.no_grad():
                generated_ids = model.generate(
                    input_tensor,
                    max_new_tokens=gen_params.get("max_new_tokens", 50),
                    temperature=gen_params.get("temperature", 1.0),
                    top_p=gen_params.get("top_p", 1.0),
                    do_sample=gen_params.get("do_sample", True)
                )

            processing_time = time.time() - start_time

            # Decodificar output
            generated_text = tokenizer.decode(generated_ids[0][len(input_ids):], skip_special_tokens=True)

            result = InferenceResult(
                request_id=f"temp_{int(time.time())}",  # Placeholder
                output_text=generated_text,
                tokens_generated=len(generated_ids[0]) - len(input_ids),
                processing_time=processing_time,
                model_version=model_version,
                metadata={
                    "input_tokens": len(input_ids),
                    "total_tokens": len(generated_ids[0])
                }
            )

            return result

        except Exception as e:
            logger.error(f"Error en inferencia: {e}")
            return None

    async def _perform_batch_inference(
        self,
        model_version: str,
        requests: List[InferenceRequest]
    ) -> List[InferenceResult]:
        """Realizar inferencia por lotes."""
        # Implementación simplificada - procesar individualmente
        # En producción, usar batch processing real
        results = []
        for request in requests:
            result = await self._perform_inference(
                request.model_version,
                request.input_text,
                request.parameters
            )
            if result:
                result.request_id = request.request_id
                results.append(result)

        return results



    def _prepare_generation_params(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Preparar parámetros de generación con valores por defecto."""
        defaults = {
            "max_new_tokens": 50,
            "temperature": 1.0,
            "top_p": 1.0,
            "top_k": 50,
            "do_sample": True,
            "repetition_penalty": 1.0,
            "eos_token_ids": [2]
        }

        # Combinar con parámetros proporcionados
        params = defaults.copy()
        params.update(parameters)

        return params

    def _sample_next_token(self, logits: torch.Tensor, params: Dict[str, Any]) -> torch.Tensor:
        """Samplear siguiente token basado en parámetros."""
        # Aplicar temperatura
        if params.get("temperature", 1.0) != 1.0:
            logits = logits / params["temperature"]

        # Aplicar top-k
        if params.get("top_k", 50) > 0:
            top_k_logits, top_k_indices = torch.topk(logits, params["top_k"], dim=-1)
            logits = torch.where(
                logits < top_k_logits[:, -1:].expand_as(logits),
                torch.full_like(logits, float('-inf')),
                logits
            )

        # Aplicar top-p
        if params.get("top_p", 1.0) < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)

            # Remove tokens with cumulative probability above the threshold
            sorted_logits = torch.where(
                cumulative_probs > params["top_p"],
                torch.full_like(sorted_logits, float('-inf')),
                sorted_logits
            )

            # Reorder back to original positions
            logits = torch.gather(
                sorted_logits,
                dim=-1,
                index=torch.argsort(sorted_indices, dim=-1)
            )

        # Sample
        if params.get("do_sample", True):
            return torch.multinomial(torch.softmax(logits, dim=-1), num_samples=1)
        else:
            return torch.argmax(logits, dim=-1, keepdim=True)

    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del engine."""
        with self.stats_lock:
            stats = self.stats.copy()

        # Añadir información en tiempo real
        stats.update({
            "active_requests": len(self.active_requests),
            "queued_requests": self.request_queue.qsize(),
            "queued_batches": self.batch_queue.qsize(),
            "is_running": self.is_running
        })

        return stats

    def get_queue_status(self) -> Dict[str, Any]:
        """Obtener estado de las colas."""
        return {
            "request_queue_size": self.request_queue.qsize(),
            "batch_queue_size": self.batch_queue.qsize(),
            "active_requests": len(self.active_requests),
            "processing_tasks": len(self.processing_tasks)
        }

    def get_batch_status(self, batch_id: str) -> Dict[str, Any]:
        """Obtener estado de un batch."""
        batch_requests = [req for req in self.active_requests.values() if req.request_id.startswith(f"{batch_id}_")]
        
        if not batch_requests:
            return {"batch_id": batch_id, "status": "not_found", "message": "Batch not found"}

        total_requests = len(batch_requests)
        completed_requests = sum(1 for req in batch_requests if req.request_id not in self.processing_tasks)
        
        status = "processing"
        if completed_requests == total_requests:
            status = "completed"
        elif completed_requests > 0:
            status = "partially_completed"

        return {
            "batch_id": batch_id,
            "status": status,
            "total_requests": total_requests,
            "completed_requests": completed_requests,
            "pending_requests": total_requests - completed_requests,
            "message": f"Batch {status}"
        }


# Funciones de conveniencia
def create_inference_engine(
    model_manager: ModelManager,
    config: Optional[InferenceEngineConfig] = None
) -> InferenceEngine:
    """Crear instancia del Inference Engine."""
    if config is None:
        config = InferenceEngineConfig()

    return InferenceEngine(config, model_manager)