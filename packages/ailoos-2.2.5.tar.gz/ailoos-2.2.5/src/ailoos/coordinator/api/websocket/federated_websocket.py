"""
WebSocket endpoints for real-time federated learning events.
Provides live updates about federated learning rounds, model updates, and coordination events.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any, List
import json
import asyncio
from datetime import datetime

from ...database.connection import get_db
from ...auth.dependencies import get_current_user, require_admin
from ...websocket.room_manager import room_manager
from ...websocket.message_types import WebSocketMessageFactory
from ...coordinator import FederatedCoordinator
from ...core.config import get_config


# Create router
router = APIRouter()


@router.websocket("/ws/federated/global")
async def global_federated_websocket(
    websocket: WebSocket,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for global federated learning events.
    Streams system-wide federated learning updates and coordination events.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["admin", "coordinator"]:
            await websocket.close(code=1008, reason="Admin/coordinator access required for global federated events")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join global federated room
        room_id = "federated_global"
        await room_manager.join_room(room_id, websocket, user_id, room_type="federated_global")

        # Send initial federated status
        await _send_initial_federated_status(websocket, db)

        # Start global federated event streaming
        await _start_global_federated_streaming(websocket, user_id, db)

    except Exception as e:
        print(f"Global federated WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/federated/session/{session_id}")
async def session_federated_websocket(
    websocket: WebSocket,
    session_id: str,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for session-specific federated learning events.
    Streams events related to a specific federated learning session.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        user_id = token_data.sub
        await websocket.accept()

        # Join session-specific federated room
        room_id = f"federated_session_{session_id}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="federated_session")

        # Send initial session federated status
        await _send_initial_session_federated_status(websocket, session_id, db)

        # Start session federated event streaming
        await _start_session_federated_streaming(websocket, user_id, session_id, db)

    except Exception as e:
        print(f"Session federated WebSocket error for session {session_id}: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/federated/node/{node_id}")
async def node_federated_websocket(
    websocket: WebSocket,
    node_id: str,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for node-specific federated learning events.
    Streams events related to a specific node's participation in federated learning.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["admin", "coordinator"] and token_data.sub != node_id:
            await websocket.close(code=1008, reason="Access denied for node federated events")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join node-specific federated room
        room_id = f"federated_node_{node_id}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="federated_node")

        # Send initial node federated status
        await _send_initial_node_federated_status(websocket, node_id, db)

        # Start node federated event streaming
        await _start_node_federated_streaming(websocket, user_id, node_id, db)

    except Exception as e:
        print(f"Node federated WebSocket error for node {node_id}: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/federated/rounds/{round_id}")
async def round_federated_websocket(
    websocket: WebSocket,
    round_id: str,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for round-specific federated learning events.
    Streams detailed events for a specific training round.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["admin", "coordinator"]:
            await websocket.close(code=1008, reason="Admin/coordinator access required for round events")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join round-specific federated room
        room_id = f"federated_round_{round_id}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="federated_round")

        # Send initial round status
        await _send_initial_round_status(websocket, round_id, db)

        # Start round event streaming
        await _start_round_streaming(websocket, user_id, round_id, db)

    except Exception as e:
        print(f"Round federated WebSocket error for round {round_id}: {e}")
        await websocket.close(code=1011, reason="Internal server error")


async def _send_initial_federated_status(websocket: WebSocket, db: Session):
    """Send initial global federated learning status."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        global_status = coordinator.get_global_status()

        message = WebSocketMessageFactory.create_federated_event(
            event_type="global_status_initial",
            message="Initial global federated learning status",
            data={
                "timestamp": datetime.utcnow().isoformat(),
                "status": global_status
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial federated status: {e}")


async def _start_global_federated_streaming(websocket: WebSocket, user_id: str, db: Session):
    """Start streaming global federated learning events."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        while True:
            await asyncio.sleep(10)  # Global status updates every 10 seconds

            global_status = coordinator.get_global_status()

            message = WebSocketMessageFactory.create_federated_event(
                event_type="global_status_update",
                message="Global federated learning status update",
                data={
                    "timestamp": datetime.utcnow().isoformat(),
                    "status": global_status
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from global federated events")
    except Exception as e:
        print(f"Error in global federated streaming: {e}")


async def _send_initial_session_federated_status(websocket: WebSocket, session_id: str, db: Session):
    """Send initial federated status for a specific session."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        session_status = coordinator.get_session_status(session_id)

        message = WebSocketMessageFactory.create_federated_event(
            event_type="session_status_initial",
            message=f"Initial status for session {session_id}",
            data={
                "session_id": session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "status": session_status
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial session federated status: {e}")


async def _start_session_federated_streaming(websocket: WebSocket, user_id: str, session_id: str, db: Session):
    """Start streaming federated events for a specific session."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        while True:
            await asyncio.sleep(5)  # Session updates every 5 seconds

            session_status = coordinator.get_session_status(session_id)

            message = WebSocketMessageFactory.create_federated_event(
                event_type="session_status_update",
                message=f"Session {session_id} status update",
                data={
                    "session_id": session_id,
                    "timestamp": datetime.utcnow().isoformat(),
                    "status": session_status
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from session {session_id} federated events")
    except Exception as e:
        print(f"Error in session federated streaming: {e}")


async def _send_initial_node_federated_status(websocket: WebSocket, node_id: str, db: Session):
    """Send initial federated status for a specific node."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        node_status = coordinator.get_node_status(node_id)

        message = WebSocketMessageFactory.create_federated_event(
            event_type="node_status_initial",
            message=f"Initial federated status for node {node_id}",
            data={
                "node_id": node_id,
                "timestamp": datetime.utcnow().isoformat(),
                "status": node_status
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial node federated status: {e}")


async def _start_node_federated_streaming(websocket: WebSocket, user_id: str, node_id: str, db: Session):
    """Start streaming federated events for a specific node."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        while True:
            await asyncio.sleep(15)  # Node updates every 15 seconds

            node_status = coordinator.get_node_status(node_id)

            message = WebSocketMessageFactory.create_federated_event(
                event_type="node_status_update",
                message=f"Node {node_id} federated status update",
                data={
                    "node_id": node_id,
                    "timestamp": datetime.utcnow().isoformat(),
                    "status": node_status
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from node {node_id} federated events")
    except Exception as e:
        print(f"Error in node federated streaming: {e}")


async def _send_initial_round_status(websocket: WebSocket, round_id: str, db: Session):
    """Send initial status for a specific round."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        round_status = coordinator.get_round_status(round_id)

        message = WebSocketMessageFactory.create_federated_event(
            event_type="round_status_initial",
            message=f"Initial status for round {round_id}",
            data={
                "round_id": round_id,
                "timestamp": datetime.utcnow().isoformat(),
                "status": round_status
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial round status: {e}")


async def _start_round_streaming(websocket: WebSocket, user_id: str, round_id: str, db: Session):
    """Start streaming events for a specific round."""
    try:
        config = get_config()
        coordinator = FederatedCoordinator(config)
        while True:
            await asyncio.sleep(2)  # Round updates every 2 seconds for detailed monitoring

            round_status = coordinator.get_round_status(round_id)

            message = WebSocketMessageFactory.create_federated_event(
                event_type="round_status_update",
                message=f"Round {round_id} status update",
                data={
                    "round_id": round_id,
                    "timestamp": datetime.utcnow().isoformat(),
                    "status": round_status
                }
            )

            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from round {round_id} events")
    except Exception as e:
        print(f"Error in round streaming: {e}")


# Broadcast functions for external use
async def broadcast_federated_event(event_type: str, message: str, data: Dict[str, Any]):
    """Broadcast federated learning event to global room."""
    room_id = "federated_global"

    ws_message = WebSocketMessageFactory.create_federated_event(
        event_type=event_type,
        message=message,
        data=data
    )

    try:
        await room_manager.broadcast_to_room(room_id, ws_message)
    except Exception as e:
        print(f"Error broadcasting federated event: {e}")


async def broadcast_session_federated_event(session_id: str, event_type: str, message: str, data: Dict[str, Any]):
    """Broadcast federated event for a specific session."""
    room_id = f"federated_session_{session_id}"

    ws_message = WebSocketMessageFactory.create_federated_event(
        event_type=event_type,
        message=message,
        data={
            "session_id": session_id,
            **data
        }
    )

    try:
        await room_manager.broadcast_to_room(room_id, ws_message)
    except Exception as e:
        print(f"Error broadcasting session federated event: {e}")


async def broadcast_node_federated_event(node_id: str, event_type: str, message: str, data: Dict[str, Any]):
    """Broadcast federated event for a specific node."""
    room_id = f"federated_node_{node_id}"

    ws_message = WebSocketMessageFactory.create_federated_event(
        event_type=event_type,
        message=message,
        data={
            "node_id": node_id,
            **data
        }
    )

    try:
        await room_manager.broadcast_to_room(room_id, ws_message)
    except Exception as e:
        print(f"Error broadcasting node federated event: {e}")


async def broadcast_round_event(round_id: str, event_type: str, message: str, data: Dict[str, Any]):
    """Broadcast event for a specific round."""
    room_id = f"federated_round_{round_id}"

    ws_message = WebSocketMessageFactory.create_federated_event(
        event_type=event_type,
        message=message,
        data={
            "round_id": round_id,
            **data
        }
    )

    try:
        await room_manager.broadcast_to_room(room_id, ws_message)
    except Exception as e:
        print(f"Error broadcasting round event: {e}")


async def broadcast_new_round_notification(session_id: str, round_id: str, round_data: Dict[str, Any]):
    """Broadcast notification when a new round starts."""
    message = f"New training round {round_id} started for session {session_id}"

    # Broadcast to session room
    await broadcast_session_federated_event(
        session_id=session_id,
        event_type="round_started",
        message=message,
        data={"round_id": round_id, "round_data": round_data}
    )

    # Broadcast to global room
    await broadcast_federated_event(
        event_type="round_started",
        message=message,
        data={"session_id": session_id, "round_id": round_id, "round_data": round_data}
    )


async def broadcast_round_completion(session_id: str, round_id: str, results: Dict[str, Any]):
    """Broadcast notification when a round completes."""
    message = f"Training round {round_id} completed for session {session_id}"

    # Broadcast to session room
    await broadcast_session_federated_event(
        session_id=session_id,
        event_type="round_completed",
        message=message,
        data={"round_id": round_id, "results": results}
    )

    # Broadcast to global room
    await broadcast_federated_event(
        event_type="round_completed",
        message=message,
        data={"session_id": session_id, "round_id": round_id, "results": results}
    )


async def broadcast_model_aggregated(session_id: str, round_id: str, metrics: Dict[str, Any]):
    """Broadcast notification when model aggregation is complete."""
    message = f"Model aggregation completed for round {round_id} in session {session_id}"

    # Broadcast to session room
    await broadcast_session_federated_event(
        session_id=session_id,
        event_type="model_aggregated",
        message=message,
        data={"round_id": round_id, "metrics": metrics}
    )

    # Broadcast to global room
    await broadcast_federated_event(
        event_type="model_aggregated",
        message=message,
        data={"session_id": session_id, "round_id": round_id, "metrics": metrics}
    )