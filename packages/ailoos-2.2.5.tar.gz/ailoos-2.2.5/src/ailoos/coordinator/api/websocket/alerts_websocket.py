"""
WebSocket endpoints for real-time system alerts and notifications.
Provides live streaming of system alerts, warnings, and critical notifications.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any, List
import json
import asyncio
from datetime import datetime

from ...database.connection import get_db
from ...auth.dependencies import get_current_user, require_admin
from ...websocket.room_manager import room_manager
from ...websocket.message_types import WebSocketMessageFactory
from ailoos.monitoring.realtime_monitor import AlertManager


# Create router
router = APIRouter()


@router.websocket("/ws/alerts/live")
async def live_alerts_websocket(
    websocket: WebSocket,
    token: str = Query(..., description="JWT access token"),
    alert_levels: Optional[str] = Query("info,warning,error,critical", description="Comma-separated alert levels to receive"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for live system alerts.
    Streams real-time alerts, warnings, and notifications based on user permissions.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        user_id = token_data.sub
        user_role = token_data.type

        # Parse alert levels
        requested_levels = set(alert_levels.split(",")) if alert_levels else {"info", "warning", "error", "critical"}

        # Filter levels based on user role
        if user_role not in ["admin", "coordinator"]:
            # Regular users only get info and warning levels
            requested_levels = requested_levels.intersection({"info", "warning"})

        await websocket.accept()

        # Join alerts room
        room_id = f"alerts_{user_role}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="alerts")

        # Send recent alerts
        await _send_recent_alerts(websocket, requested_levels, db)

        # Start alert streaming
        await _start_alert_streaming(websocket, user_id, requested_levels, db)

    except Exception as e:
        print(f"Live alerts WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/alerts/system")
async def system_alerts_websocket(
    websocket: WebSocket,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for system-wide alerts (admin/coordinator only).
    Provides all system alerts and critical notifications.
    """
    try:
        # Authenticate admin/coordinator
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["admin", "coordinator"]:
            await websocket.close(code=1008, reason="Admin/coordinator access required")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join system alerts room
        room_id = "alerts_system"
        await room_manager.join_room(room_id, websocket, user_id, room_type="system_alerts")

        # Send system status
        await _send_system_status(websocket, db)

        # Start system alert streaming
        await _start_system_alert_streaming(websocket, user_id, db)

    except Exception as e:
        print(f"System alerts WebSocket error: {e}")
        await websocket.close(code=1011, reason="Internal server error")


@router.websocket("/ws/alerts/node/{node_id}")
async def node_alerts_websocket(
    websocket: WebSocket,
    node_id: str,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for node-specific alerts.
    Streams alerts related to a specific node.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["admin", "coordinator"] and token_data.sub != node_id:
            await websocket.close(code=1008, reason="Access denied for node alerts")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join node alerts room
        room_id = f"alerts_node_{node_id}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="node_alerts")

        # Send node alerts
        await _send_node_alerts(websocket, node_id, db)

        # Start node alert streaming
        await _start_node_alert_streaming(websocket, user_id, node_id, db)

    except Exception as e:
        print(f"Node alerts WebSocket error for node {node_id}: {e}")
        await websocket.close(code=1011, reason="Internal server error")


async def _send_recent_alerts(websocket: WebSocket, alert_levels: set, db: Session):
    """Send recent alerts to client."""
    try:
        from ...monitoring.realtime_monitor import get_realtime_monitor
        monitor = get_realtime_monitor()

        # Get active alerts and filter by levels
        active_alerts = monitor.alert_manager.get_active_alerts()
        recent_alerts = [
            {
                "alert_id": alert.alert_id,
                "severity": alert.severity.value,
                "message": alert.message,
                "value": alert.value,
                "timestamp": alert.timestamp.isoformat(),
                "resolved": alert.resolved
            }
            for alert in active_alerts
            if alert.severity.value in alert_levels
        ][:10]  # Limit to 10

        message = WebSocketMessageFactory.create_system_alert(
            alert_type="recent_alerts",
            message="Recent system alerts",
            data={
                "timestamp": datetime.utcnow().isoformat(),
                "alerts": recent_alerts
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending recent alerts: {e}")


async def _start_alert_streaming(websocket: WebSocket, user_id: str, alert_levels: set, db: Session):
    """Start live alert streaming."""
    try:
        from ...monitoring.realtime_monitor import get_realtime_monitor
        monitor = get_realtime_monitor()
        last_check = datetime.utcnow()

        while True:
            await asyncio.sleep(1)  # Check for new alerts every second

            # Get recent alerts from alert history
            alert_history = monitor.alert_manager.get_alert_history(limit=50)
            new_alerts = [
                alert for alert in alert_history
                if alert.timestamp > last_check and alert.severity.value in alert_levels
            ]

            if new_alerts:
                for alert in new_alerts:
                    message = WebSocketMessageFactory.create_system_alert(
                        alert_type=alert.severity.value,
                        message=alert.message,
                        data={
                            "alert_id": alert.alert_id,
                            "severity": alert.severity.value,
                            "value": alert.value,
                            "threshold": alert.threshold,
                            "timestamp": alert.timestamp.isoformat(),
                            "resolved": alert.resolved
                        }
                    )
                    await websocket.send_text(message.json())

            last_check = datetime.utcnow()

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from live alerts")
    except Exception as e:
        print(f"Error in alert streaming: {e}")


async def _send_system_status(websocket: WebSocket, db: Session):
    """Send current system status and active alerts."""
    try:
        from ...monitoring.realtime_monitor import get_realtime_monitor
        monitor = get_realtime_monitor()
        system_status = monitor.get_system_status()

        message = WebSocketMessageFactory.create_system_alert(
            alert_type="system_status",
            message="Current system status",
            data={
                "timestamp": datetime.utcnow().isoformat(),
                "status": system_status
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending system status: {e}")


async def _start_system_alert_streaming(websocket: WebSocket, user_id: str, db: Session):
    """Start system-wide alert streaming."""
    try:
        from ...monitoring.realtime_monitor import get_realtime_monitor
        monitor = get_realtime_monitor()
        last_check = datetime.utcnow()

        while True:
            await asyncio.sleep(5)  # System status updates every 5 seconds

            system_status = monitor.get_system_status()

            # Check for critical alerts
            critical_alerts = [
                alert for alert in system_status.get("active_alerts", [])
                if alert.get("severity") == "critical"
            ]

            if critical_alerts:
                for alert in critical_alerts:
                    message = WebSocketMessageFactory.create_system_alert(
                        alert_type="critical_alert",
                        message=alert.get("message", "Critical system alert"),
                        data=alert
                    )
                    await websocket.send_text(message.json())

            # Send system status update
            message = WebSocketMessageFactory.create_system_alert(
                alert_type="system_status_update",
                message="System status update",
                data={
                    "timestamp": datetime.utcnow().isoformat(),
                    "status": system_status
                }
            )
            await websocket.send_text(message.json())

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from system alerts")
    except Exception as e:
        print(f"Error in system alert streaming: {e}")


async def _send_node_alerts(websocket: WebSocket, node_id: str, db: Session):
    """Send alerts for a specific node."""
    try:
        from ...monitoring.realtime_monitor import get_realtime_monitor
        monitor = get_realtime_monitor()

        # Get all alerts and filter by node_id in message or data
        all_alerts = monitor.alert_manager.get_alert_history(limit=50)
        node_alerts = [
            {
                "alert_id": alert.alert_id,
                "severity": alert.severity.value,
                "message": alert.message,
                "value": alert.value,
                "timestamp": alert.timestamp.isoformat(),
                "resolved": alert.resolved
            }
            for alert in all_alerts
            if node_id in alert.message or (hasattr(alert, 'data') and alert.data and node_id in str(alert.data))
        ][:10]  # Limit to 10

        message = WebSocketMessageFactory.create_system_alert(
            alert_type="node_alerts",
            message=f"Alerts for node {node_id}",
            data={
                "node_id": node_id,
                "timestamp": datetime.utcnow().isoformat(),
                "alerts": node_alerts
            }
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending node alerts: {e}")


async def _start_node_alert_streaming(websocket: WebSocket, user_id: str, node_id: str, db: Session):
    """Start streaming alerts for a specific node."""
    try:
        from ...monitoring.realtime_monitor import get_realtime_monitor
        monitor = get_realtime_monitor()
        last_check = datetime.utcnow()

        while True:
            await asyncio.sleep(10)  # Node alerts updates every 10 seconds

            # Get recent alerts and filter by node
            alert_history = monitor.alert_manager.get_alert_history(limit=20)
            new_node_alerts = [
                alert for alert in alert_history
                if alert.timestamp > last_check and
                (node_id in alert.message or (hasattr(alert, 'data') and alert.data and node_id in str(alert.data)))
            ]

            # Send any new alerts
            for alert in new_node_alerts:
                message = WebSocketMessageFactory.create_system_alert(
                    alert_type=f"node_{alert.severity.value}",
                    message=alert.message,
                    data={
                        "node_id": node_id,
                        "alert_id": alert.alert_id,
                        "severity": alert.severity.value,
                        "value": alert.value,
                        "timestamp": alert.timestamp.isoformat(),
                        "resolved": alert.resolved
                    }
                )
                await websocket.send_text(message.json())

            last_check = datetime.utcnow()

    except WebSocketDisconnect:
        print(f"Client {user_id} disconnected from node {node_id} alerts")
    except Exception as e:
        print(f"Error in node alert streaming: {e}")


# Broadcast functions for external use
async def broadcast_system_alert(alert_type: str, message: str, data: Dict[str, Any]):
    """Broadcast system alert to all connected clients."""
    # Broadcast to all alert rooms
    alert_rooms = ["alerts_user", "alerts_admin", "alerts_coordinator", "alerts_system"]

    ws_message = WebSocketMessageFactory.create_system_alert(
        alert_type=alert_type,
        message=message,
        data=data
    )

    for room_id in alert_rooms:
        try:
            await room_manager.broadcast_to_room(room_id, ws_message)
        except Exception as e:
            print(f"Error broadcasting to room {room_id}: {e}")


async def broadcast_node_alert(node_id: str, alert_type: str, message: str, data: Dict[str, Any]):
    """Broadcast alert for a specific node."""
    room_id = f"alerts_node_{node_id}"

    ws_message = WebSocketMessageFactory.create_system_alert(
        alert_type=alert_type,
        message=message,
        data={
            "node_id": node_id,
            **data
        }
    )

    try:
        await room_manager.broadcast_to_room(room_id, ws_message)
    except Exception as e:
        print(f"Error broadcasting node alert to {node_id}: {e}")


async def broadcast_critical_alert(message: str, data: Dict[str, Any]):
    """Broadcast critical alert to admin/coordinator rooms only."""
    admin_rooms = ["alerts_admin", "alerts_coordinator", "alerts_system"]

    ws_message = WebSocketMessageFactory.create_system_alert(
        alert_type="critical",
        message=message,
        data=data
    )

    for room_id in admin_rooms:
        try:
            await room_manager.broadcast_to_room(room_id, ws_message)
        except Exception as e:
            print(f"Error broadcasting critical alert to {room_id}: {e}")