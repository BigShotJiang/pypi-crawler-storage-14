"""
API endpoints for federated learning rounds management.
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...models.schemas import (
    RoundResponse, RoundCreate, RoundUpdate, RoundParticipantResponse,
    APIResponse, PaginatedResponse
)
from ...services.round_service import RoundService
from ...auth.dependencies import get_current_node, get_current_admin, get_current_user
from ...core.exceptions import CoordinatorException


router = APIRouter()


@router.get("/active", response_model=APIResponse)
async def get_active_rounds(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get all active federated learning rounds."""
    try:
        rounds = await RoundService.get_active_rounds(db=db)

        return APIResponse(
            success=True,
            message="Active rounds retrieved successfully",
            data={"rounds": rounds}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving active rounds: {str(e)}")


@router.get("/", response_model=PaginatedResponse)
async def list_rounds(
    skip: int = Query(0, ge=0, description="Number of rounds to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of rounds to return"),
    session_id: Optional[str] = Query(None, description="Filter by session ID"),
    status: Optional[str] = Query(None, description="Filter by round status"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """List federated learning rounds with optional filtering and pagination."""
    try:
        rounds, total = await RoundService.list_rounds(
            db=db,
            skip=skip,
            limit=limit,
            session_id=session_id,
            status=status
        )

        return PaginatedResponse(
            success=True,
            message="Rounds retrieved successfully",
            data=rounds,
            total=total,
            page=(skip // limit) + 1,
            page_size=limit,
            total_pages=(total + limit - 1) // limit
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving rounds: {str(e)}")


@router.get("/{round_id}", response_model=APIResponse)
async def get_round(
    round_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get a specific federated learning round by ID."""
    try:
        round_data = await RoundService.get_round_by_id(db=db, round_id=round_id)

        return APIResponse(
            success=True,
            message="Round retrieved successfully",
            data=round_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving round: {str(e)}")


@router.post("/", response_model=APIResponse)
async def create_round(
    round_data: RoundCreate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Create a new federated learning round."""
    try:
        round_obj = await RoundService.create_round(
            db=db,
            round_data=round_data
        )

        return APIResponse(
            success=True,
            message="Round created successfully",
            data=round_obj
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating round: {str(e)}")


@router.put("/{round_id}", response_model=APIResponse)
async def update_round(
    round_id: str,
    round_update: RoundUpdate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Update a federated learning round."""
    try:
        round_obj = await RoundService.update_round(
            db=db,
            round_id=round_id,
            round_update=round_update
        )

        return APIResponse(
            success=True,
            message="Round updated successfully",
            data=round_obj
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating round: {str(e)}")


@router.post("/{round_id}/start", response_model=APIResponse)
async def start_round(
    round_id: str,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Start a federated learning round."""
    try:
        round_obj = await RoundService.start_round(db=db, round_id=round_id)

        return APIResponse(
            success=True,
            message="Round started successfully",
            data=round_obj
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error starting round: {str(e)}")


@router.post("/{round_id}/complete", response_model=APIResponse)
async def complete_round(
    round_id: str,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Complete a federated learning round."""
    try:
        round_obj = await RoundService.complete_round(db=db, round_id=round_id)

        return APIResponse(
            success=True,
            message="Round completed successfully",
            data=round_obj
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error completing round: {str(e)}")


@router.get("/{round_id}/participants", response_model=APIResponse)
async def get_round_participants(
    round_id: str,
    status: Optional[str] = Query(None, description="Filter by participant status"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get participants for a specific round."""
    try:
        participants = await RoundService.get_round_participants(
            db=db,
            round_id=round_id,
            status=status
        )

        return APIResponse(
            success=True,
            message="Round participants retrieved successfully",
            data=participants
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving round participants: {str(e)}")


@router.post("/{round_id}/submit-update", response_model=APIResponse)
async def submit_model_update(
    round_id: str,
    node_id: str = Query(..., description="Node ID submitting the update"),
    model_update: Dict[str, Any] = None,  # In body
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Submit a model update for a round."""
    try:
        # Verify the node_id matches the authenticated node
        if current_node.get("node_id") != node_id:
            raise HTTPException(status_code=403, detail="Node ID mismatch")

        result = await RoundService.submit_model_update(
            db=db,
            round_id=round_id,
            node_id=node_id,
            model_update=model_update
        )

        return APIResponse(
            success=True,
            message="Model update submitted successfully",
            data=result
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error submitting model update: {str(e)}")


@router.get("/stats/active", response_model=APIResponse)
async def get_active_rounds_count(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get count of active rounds."""
    try:
        count = await RoundService.get_active_rounds_count(db=db)

        return APIResponse(
            success=True,
            message="Active rounds count retrieved successfully",
            data={"active_rounds_count": count}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving active rounds count: {str(e)}")