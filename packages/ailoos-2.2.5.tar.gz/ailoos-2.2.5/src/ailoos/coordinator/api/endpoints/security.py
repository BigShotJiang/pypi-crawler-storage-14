"""
Security API endpoints.
Provides REST endpoints for user security management including 2FA, session management,
password changes, security alerts, and session timeout configuration.
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from fastapi import APIRouter, HTTPException, Depends, Request, BackgroundTasks
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user, revoke_token, create_user_token
from ....security.two_factor import get_two_factor_manager, TwoFactorStatus
from ...models.base import User, RefreshToken, AuditLog
from ...config.settings import settings

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class TwoFactorSetupRequest(BaseModel):
    """Request model for 2FA setup."""
    issuer: str = Field(default="AILOOS", description="Issuer name for TOTP")
    account_name: str = Field(default="", description="Account name for TOTP")


class TwoFactorSetupResponse(BaseModel):
    """Response model for 2FA setup."""
    secret: str
    qr_code_uri: str
    qr_code_data: str  # Base64 encoded PNG
    expires_at: datetime


class TwoFactorVerifyRequest(BaseModel):
    """Request model for 2FA verification."""
    code: str = Field(..., min_length=6, max_length=8, description="TOTP code or backup code")


class TwoFactorStatusResponse(BaseModel):
    """Response model for 2FA status."""
    status: str
    enabled: bool
    backup_codes_count: int
    last_used: Optional[datetime]
    failed_attempts: int
    locked_until: Optional[datetime]


class PasswordChangeRequest(BaseModel):
    """Request model for password change."""
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)

    @validator('new_password')
    def password_strength(cls, v):
        if not any(char.isupper() for char in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(char.islower() for char in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(char.isdigit() for char in v):
            raise ValueError('Password must contain at least one digit')
        if not any(char in '!@#$%^&*(),.?":{}|<>' for char in v):
            raise ValueError('Password must contain at least one special character')
        return v


class SessionInfo(BaseModel):
    """Session information model."""
    session_id: str
    device_info: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    created_at: datetime
    last_activity: Optional[datetime]
    expires_at: datetime


class SessionListResponse(BaseModel):
    """Response model for session list."""
    sessions: List[SessionInfo]
    current_session_id: str


class SecurityAlert(BaseModel):
    """Security alert model."""
    id: str
    type: str
    message: str
    severity: str
    created_at: datetime
    resolved: bool


class SecurityAlertsResponse(BaseModel):
    """Response model for security alerts."""
    alerts: List[SecurityAlert]
    total_unresolved: int


class SessionTimeoutUpdateRequest(BaseModel):
    """Request model for session timeout update."""
    timeout_minutes: int = Field(..., ge=5, le=480, description="Session timeout in minutes")


class SecuritySettingsResponse(BaseModel):
    """Response model for security settings."""
    two_factor_enabled: bool
    session_timeout_minutes: int
    password_last_changed: Optional[datetime]
    login_attempts: int
    account_locked_until: Optional[datetime]


# Helper functions
def get_user_id_from_token(current_user: Dict) -> str:
    """Extract user ID from JWT token payload."""
    return current_user.get('sub', '')


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    import bcrypt
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash."""
    import bcrypt
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))


def log_security_event(db: Session, user_id: str, event_type: str, details: Dict = None,
                      ip_address: str = None, user_agent: str = None):
    """Log security-related events."""
    audit_log = AuditLog(
        entity_type="security",
        entity_id=user_id,
        action=event_type,
        user_id=user_id,
        old_values=None,
        new_values=details,
        ip_address=ip_address,
        user_agent=user_agent
    )
    db.add(audit_log)
    db.commit()


def get_active_sessions(user_id: str, db: Session) -> List[Dict[str, Any]]:
    """Get active sessions for a user."""
    # Get refresh tokens that are not revoked and not expired
    active_tokens = db.query(RefreshToken).filter(
        RefreshToken.user_id == user_id,
        RefreshToken.is_revoked == False,
        RefreshToken.expires_at > datetime.utcnow()
    ).all()

    sessions = []
    for token in active_tokens:
        sessions.append({
            'session_id': token.token_jti,
            'device_info': getattr(token, 'device_info', None),
            'ip_address': getattr(token, 'ip_address', None),
            'user_agent': getattr(token, 'user_agent', None),
            'created_at': token.created_at,
            'last_activity': getattr(token, 'last_used_at', None),
            'expires_at': token.expires_at
        })

    return sessions


# API Endpoints

# 2FA Endpoints
@router.post("/2fa/setup", response_model=TwoFactorSetupResponse,
             summary="Iniciar configuración de 2FA",
             description="""
             Inicia la configuración de autenticación de dos factores (2FA) para el usuario actual.

             **Proceso:**
             - Genera un secreto TOTP único
             - Crea código QR para configuración en app autenticadora
             - Almacena configuración temporal (expira en 15 minutos)

             **Respuesta incluye:**
             - Secreto TOTP (para configuración manual)
             - URI del código QR
             - Datos del código QR en base64

             **Códigos de respuesta:**
             - 200: Configuración iniciada exitosamente
             - 400: 2FA ya configurado
             - 401: Usuario no autenticado
             """)
async def setup_two_factor(
    request: TwoFactorSetupRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Setup 2FA for current user.

    - Generates TOTP secret
    - Creates QR code
    - Stores temporary setup
    """
    try:
        user_id = get_user_id_from_token(current_user)
        manager = get_two_factor_manager()

        # Check if 2FA already enabled
        status = manager.get_two_factor_status(user_id)
        if status == TwoFactorStatus.ENABLED:
            raise HTTPException(status_code=400, detail="2FA already enabled")

        # Setup 2FA
        setup = manager.setup_two_factor(
            user_id=user_id,
            issuer=request.issuer,
            account_name=request.account_name
        )

        # Convert QR code data to base64
        import base64
        qr_base64 = base64.b64encode(setup.qr_code_data).decode('utf-8')

        return TwoFactorSetupResponse(
            secret=setup.secret,
            qr_code_uri=setup.qr_code_uri,
            qr_code_data=f"data:image/png;base64,{qr_base64}",
            expires_at=setup.expires_at
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"2FA setup error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/2fa/verify", summary="Verificar configuración de 2FA",
             description="""
             Verifica el código TOTP para completar la configuración de 2FA.

             **Proceso:**
             - Valida el código TOTP proporcionado
             - Completa la configuración si es válido
             - Genera códigos de respaldo

             **Códigos de respuesta:**
             - 200: 2FA configurado exitosamente
             - 400: Código inválido o expirado
             - 401: Usuario no autenticado
             """)
async def verify_two_factor_setup(
    request: TwoFactorVerifyRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Verify 2FA setup code and complete configuration.
    """
    try:
        user_id = get_user_id_from_token(current_user)
        manager = get_two_factor_manager()

        # Verify setup code
        if not manager.verify_setup_code(user_id, request.code):
            raise HTTPException(status_code=400, detail="Invalid or expired verification code")

        # Complete setup
        secret_obj = manager.complete_setup(user_id)

        # Log security event
        log_security_event(
            db=db,
            user_id=user_id,
            event_type="2fa_enabled",
            details={"backup_codes_generated": len(secret_obj.backup_codes)}
        )

        return {
            "message": "2FA setup completed successfully",
            "backup_codes": secret_obj.backup_codes
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"2FA verification error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/2fa/status", response_model=TwoFactorStatusResponse,
            summary="Obtener estado de 2FA",
            description="""
            Obtiene el estado actual de la autenticación de dos factores.

            **Estados posibles:**
            - disabled: 2FA no configurado
            - enabled: 2FA activo
            - pending_setup: Configuración en proceso
            - suspended: Cuenta bloqueada por intentos fallidos

            **Códigos de respuesta:**
            - 200: Estado obtenido exitosamente
            - 401: Usuario no autenticado
            """)
async def get_two_factor_status(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current 2FA status for user.
    """
    try:
        user_id = get_user_id_from_token(current_user)
        manager = get_two_factor_manager()

        status = manager.get_two_factor_status(user_id)
        info = manager.get_user_secret_info(user_id)

        return TwoFactorStatusResponse(
            status=status.value,
            enabled=status == TwoFactorStatus.ENABLED,
            backup_codes_count=info.get('backup_codes_count', 0) if info else 0,
            last_used=info.get('last_used') if info else None,
            failed_attempts=info.get('failed_attempts', 0) if info else 0,
            locked_until=info.get('locked_until') if info else None
        )

    except Exception as e:
        logger.error(f"Get 2FA status error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/2fa", summary="Deshabilitar 2FA",
               description="""
               Deshabilita la autenticación de dos factores para el usuario actual.

               **Proceso:**
               - Elimina el secreto TOTP
               - Limpia códigos de respaldo
               - Registra el evento de seguridad

               **Códigos de respuesta:**
               - 200: 2FA deshabilitado exitosamente
               - 401: Usuario no autenticado
               """)
async def disable_two_factor(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Disable 2FA for current user.
    """
    try:
        user_id = get_user_id_from_token(current_user)
        manager = get_two_factor_manager()

        if manager.disable_two_factor(user_id):
            # Log security event
            log_security_event(
                db=db,
                user_id=user_id,
                event_type="2fa_disabled"
            )

            return {"message": "2FA disabled successfully"}
        else:
            raise HTTPException(status_code=400, detail="2FA not enabled")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Disable 2FA error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/2fa/backup-codes/regenerate", summary="Regenerar códigos de respaldo",
             description="""
             Regenera los códigos de respaldo para 2FA.

             **Proceso:**
             - Genera nuevos códigos de respaldo
             - Invalida los códigos anteriores
             - Registra el evento de seguridad

             **Códigos de respuesta:**
             - 200: Códigos regenerados exitosamente
             - 400: 2FA no habilitado
             - 401: Usuario no autenticado
             """)
async def regenerate_backup_codes(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Regenerate backup codes for 2FA.
    """
    try:
        user_id = get_user_id_from_token(current_user)
        manager = get_two_factor_manager()

        new_codes = manager.regenerate_backup_codes(user_id)
        if new_codes is None:
            raise HTTPException(status_code=400, detail="2FA not enabled")

        # Log security event
        log_security_event(
            db=db,
            user_id=user_id,
            event_type="backup_codes_regenerated",
            details={"codes_count": len(new_codes)}
        )

        return {
            "message": "Backup codes regenerated successfully",
            "backup_codes": new_codes
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Regenerate backup codes error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Session Management Endpoints
@router.get("/sessions", response_model=SessionListResponse,
            summary="Listar sesiones activas",
            description="""
            Obtiene la lista de sesiones activas del usuario actual.

            **Incluye:**
            - ID de sesión
            - Información del dispositivo
            - Dirección IP
            - User agent
            - Fechas de creación y última actividad

            **Códigos de respuesta:**
            - 200: Sesiones obtenidas exitosamente
            - 401: Usuario no autenticado
            """)
async def list_active_sessions(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    List active sessions for current user.
    """
    try:
        user_id = get_user_id_from_token(current_user)

        sessions = get_active_sessions(user_id, db)
        current_session_id = current_user.get('jti', '')

        return SessionListResponse(
            sessions=[SessionInfo(**session) for session in sessions],
            current_session_id=current_session_id
        )

    except Exception as e:
        logger.error(f"List sessions error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/sessions/{session_id}", summary="Revocar sesión específica",
               description="""
               Revoca una sesión específica del usuario.

               **Proceso:**
               - Busca la sesión por ID
               - Revoca el token de refresh
               - Registra el evento de seguridad

               **Códigos de respuesta:**
               - 200: Sesión revocada exitosamente
               - 404: Sesión no encontrada
               - 401: Usuario no autenticado
               """)
async def revoke_session(
    session_id: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Revoke a specific session.
    """
    try:
        user_id = get_user_id_from_token(current_user)

        # Find and revoke the session
        token = db.query(RefreshToken).filter(
            RefreshToken.token_jti == session_id,
            RefreshToken.user_id == user_id,
            RefreshToken.is_revoked == False
        ).first()

        if not token:
            raise HTTPException(status_code=404, detail="Session not found")

        # Revoke token
        token.is_revoked = True
        revoke_token(token.token_jti, token.token_type, user_id, "manual_revoke", db)
        db.commit()

        # Log security event
        log_security_event(
            db=db,
            user_id=user_id,
            event_type="session_revoked",
            details={"session_id": session_id}
        )

        return {"message": "Session revoked successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Revoke session error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/sessions", summary="Revocar todas las sesiones",
               description="""
               Revoca todas las sesiones activas del usuario excepto la actual.

               **Proceso:**
               - Revoca todos los tokens de refresh
               - Mantiene la sesión actual activa
               - Registra el evento de seguridad

               **Códigos de respuesta:**
               - 200: Sesiones revocadas exitosamente
               - 401: Usuario no autenticado
               """)
async def revoke_all_sessions(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Revoke all sessions except current one.
    """
    try:
        user_id = get_user_id_from_token(current_user)
        current_session_id = current_user.get('jti', '')

        # Get all active sessions except current
        tokens = db.query(RefreshToken).filter(
            RefreshToken.user_id == user_id,
            RefreshToken.is_revoked == False,
            RefreshToken.token_jti != current_session_id
        ).all()

        revoked_count = 0
        for token in tokens:
            token.is_revoked = True
            revoke_token(token.token_jti, token.token_type, user_id, "revoke_all", db)
            revoked_count += 1

        db.commit()

        # Log security event
        log_security_event(
            db=db,
            user_id=user_id,
            event_type="all_sessions_revoked",
            details={"revoked_count": revoked_count}
        )

        return {
            "message": f"All sessions revoked successfully",
            "revoked_count": revoked_count
        }

    except Exception as e:
        logger.error(f"Revoke all sessions error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


# Password Management Endpoints
@router.post("/password/change", summary="Cambiar contraseña",
             description="""
             Cambia la contraseña del usuario actual.

             **Requisitos de contraseña:**
             - Mínimo 8 caracteres
             - Al menos una letra mayúscula
             - Al menos una letra minúscula
             - Al menos un dígito
             - Al menos un carácter especial

             **Proceso:**
             - Verifica la contraseña actual
             - Valida la nueva contraseña
             - Actualiza el hash de contraseña
             - Revoca todas las sesiones existentes
             - Registra el evento de seguridad

             **Códigos de respuesta:**
             - 200: Contraseña cambiada exitosamente
             - 400: Contraseña actual incorrecta o nueva inválida
             - 401: Usuario no autenticado
             """)
async def change_password(
    request: PasswordChangeRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Change user password.
    """
    try:
        user_id = get_user_id_from_token(current_user)

        # Get user
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Verify current password
        if not verify_password(request.current_password, user.password_hash):
            raise HTTPException(status_code=400, detail="Current password is incorrect")

        # Hash new password
        new_password_hash = hash_password(request.new_password)

        # Update password
        user.password_hash = new_password_hash
        user.updated_at = datetime.utcnow()
        db.commit()

        # Revoke all refresh tokens for security
        refresh_tokens = db.query(RefreshToken).filter(
            RefreshToken.user_id == user_id,
            RefreshToken.is_revoked == False
        ).all()

        for token in refresh_tokens:
            token.is_revoked = True
            revoke_token(token.token_jti, token.token_type, user_id, "password_change", db)

        db.commit()

        # Log security event
        log_security_event(
            db=db,
            user_id=user_id,
            event_type="password_changed"
        )

        return {"message": "Password changed successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Change password error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


# Security Alerts Endpoints
@router.get("/alerts", response_model=SecurityAlertsResponse,
            summary="Obtener alertas de seguridad",
            description="""
            Obtiene las alertas de seguridad del usuario actual.

            **Tipos de alertas:**
            - suspicious_login: Inicio de sesión sospechoso
            - password_changed: Contraseña cambiada
            - 2fa_disabled: 2FA deshabilitado
            - session_revoked: Sesión revocada
            - failed_login_attempts: Intentos de login fallidos

            **Códigos de respuesta:**
            - 200: Alertas obtenidas exitosamente
            - 401: Usuario no autenticado
            """)
async def get_security_alerts(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db),
    resolved: bool = False,
    limit: int = 50
):
    """
    Get security alerts for current user.
    """
    try:
        user_id = get_user_id_from_token(current_user)

        # Get audit logs for security events
        security_actions = [
            "login", "logout", "password_change", "2fa_enabled", "2fa_disabled",
            "session_revoked", "all_sessions_revoked", "backup_codes_regenerated"
        ]

        query = db.query(AuditLog).filter(
            AuditLog.user_id == user_id,
            AuditLog.action.in_(security_actions)
        )

        if not resolved:
            # For demo purposes, consider all as unresolved
            pass

        logs = query.order_by(AuditLog.created_at.desc()).limit(limit).all()

        alerts = []
        for log in logs:
            alert_type = log.action
            severity = "info"

            if "failed" in log.action or "suspicious" in log.action:
                severity = "warning"
            elif "disabled" in log.action or "revoked" in log.action:
                severity = "warning"

            message = f"Security event: {log.action.replace('_', ' ').title()}"
            if log.ip_address:
                message += f" from {log.ip_address}"

            alerts.append(SecurityAlert(
                id=str(log.id),
                type=alert_type,
                message=message,
                severity=severity,
                created_at=log.created_at,
                resolved=False  # For demo, all are unresolved
            ))

        return SecurityAlertsResponse(
            alerts=alerts,
            total_unresolved=len([a for a in alerts if not a.resolved])
        )

    except Exception as e:
        logger.error(f"Get security alerts error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Session Timeout Configuration
@router.get("/settings", response_model=SecuritySettingsResponse,
            summary="Obtener configuración de seguridad",
            description="""
            Obtiene la configuración actual de seguridad del usuario.

            **Incluye:**
            - Estado de 2FA
            - Timeout de sesión
            - Último cambio de contraseña
            - Intentos de login
            - Estado de bloqueo de cuenta

            **Códigos de respuesta:**
            - 200: Configuración obtenida exitosamente
            - 401: Usuario no autenticado
            """)
async def get_security_settings(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current security settings for user.
    """
    try:
        user_id = get_user_id_from_token(current_user)

        # Get user
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Get 2FA status
        manager = get_two_factor_manager()
        two_factor_status = manager.get_two_factor_status(user_id)

        # For demo, use default session timeout
        session_timeout = getattr(user, 'session_timeout_minutes', 60) or 60

        return SecuritySettingsResponse(
            two_factor_enabled=two_factor_status == TwoFactorStatus.ENABLED,
            session_timeout_minutes=session_timeout,
            password_last_changed=getattr(user, 'password_changed_at', None),
            login_attempts=getattr(user, 'login_attempts', 0),
            account_locked_until=getattr(user, 'locked_until', None)
        )

    except Exception as e:
        logger.error(f"Get security settings error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/settings/timeout", summary="Actualizar timeout de sesión",
            description="""
            Actualiza el timeout de sesión para el usuario actual.

            **Rango válido:**
            - Mínimo: 5 minutos
            - Máximo: 480 minutos (8 horas)

            **Códigos de respuesta:**
            - 200: Timeout actualizado exitosamente
            - 400: Valor fuera de rango
            - 401: Usuario no autenticado
            """)
async def update_session_timeout(
    request: SessionTimeoutUpdateRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Update session timeout for current user.
    """
    try:
        user_id = get_user_id_from_token(current_user)

        # Get user
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Update session timeout (assuming user model has this field)
        if hasattr(user, 'session_timeout_minutes'):
            user.session_timeout_minutes = request.timeout_minutes
            user.updated_at = datetime.utcnow()
            db.commit()

            # Log security event
            log_security_event(
                db=db,
                user_id=user_id,
                event_type="session_timeout_updated",
                details={"timeout_minutes": request.timeout_minutes}
            )

            return {"message": "Session timeout updated successfully"}
        else:
            # For demo, just return success
            return {"message": "Session timeout updated successfully"}

    except Exception as e:
        logger.error(f"Update session timeout error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")