"""
Wallet API endpoints.
Provides complete wallet functionality with DRACMA token management, staking, and blockchain integration.
"""

import logging
from typing import Dict, List, Any, Optional

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ....marketplace.marketplace import marketplace
from ...database.connection import get_db
from ...auth.jwt import get_current_user
# from ..auth.permissions import require_permissions  # Commented out - function not defined

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class CreateWalletRequest(BaseModel):
    """Request model for creating a wallet."""
    label: str = Field(default="default", min_length=1, max_length=50)


class TransferRequest(BaseModel):
    """Request model for transferring tokens."""
    receiver_address: str = Field(..., min_length=42, max_length=42, pattern=r"^0x[a-fA-F0-9]{40}$")
    amount: float = Field(..., gt=0)
    description: str = Field(default="", max_length=255)


class StakeRequest(BaseModel):
    """Request model for staking tokens."""
    amount: float = Field(..., gt=0)


class WalletInfoResponse(BaseModel):
    """Response model for wallet information."""
    address: str
    balance_dracma: float
    staked_dracma: float
    total_value_dracma: float
    staking_multiplier: float
    estimated_daily_reward: float
    estimated_monthly_reward: float
    recent_transactions: int
    portfolio_health: str


class TransactionHistoryResponse(BaseModel):
    """Response model for transaction history."""
    tx_hash: str
    type: str
    amount: float
    timestamp: float
    status: str
    sender: str
    receiver: str
    data: Optional[Dict[str, Any]]


class StakingInfoResponse(BaseModel):
    """Response model for staking information."""
    staked_amount: float
    multiplier: float
    estimated_daily_reward: float
    estimated_monthly_reward: float
    staking_tier: str


class ExportWalletRequest(BaseModel):
    """Request model for exporting wallet."""
    password: str = Field(..., min_length=8, max_length=128)


class ImportWalletRequest(BaseModel):
    """Request model for importing wallet."""
    encrypted_data: str = Field(..., min_length=1)
    password: str = Field(..., min_length=8, max_length=128)


# API Endpoints
@router.post("/create", response_model=Dict[str, Any],
             summary="Crear nueva wallet DRACMA",
             description="""
             Crea una nueva wallet DRACMA para el usuario autenticado.

             **Proceso:**
             - Verifica que el usuario no tenga ya una wallet
             - Crea una nueva wallet con dirección única
             - Asigna balance inicial si está configurado
             - Configura capacidades de staking

             **Características de la wallet:**
             - Dirección Ethereum-compatible (0x...)
             - Soporte para tokens DRACMA
             - Funcionalidad de staking integrada
             - Historial de transacciones completo

             **Códigos de respuesta:**
             - 200: Wallet creada exitosamente
             - 400: El usuario ya tiene una wallet
             - 500: Error interno del servidor
             """,
             responses={
                 200: {
                     "description": "Wallet creada exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "wallet_address": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
                                 "initial_balance": 100.0,
                                 "message": "Wallet created successfully",
                                 "portfolio": {
                                     "balance_dracma": 100.0,
                                     "staked_dracma": 0.0,
                                     "total_value_dracma": 100.0,
                                     "staking_multiplier": 1.0,
                                     "estimated_daily_reward": 0.0,
                                     "estimated_monthly_reward": 0.0,
                                     "recent_transactions": 0,
                                     "portfolio_health": "healthy"
                                 }
                             }
                         }
                     }
                 },
                 400: {
                     "description": "Usuario ya tiene wallet",
                     "content": {
                         "application/json": {
                             "example": {"detail": "User already has a wallet"}
                         }
                     }
                 }
             })
async def create_wallet(
    request: CreateWalletRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create a new DRACMA wallet for the user.

    - Creates wallet with initial balance
    - Sets up staking capabilities
    - Returns wallet information
    """
    try:
        user_id = current_user.sub

        # Check if user already has a wallet
        existing_wallet = marketplace.get_wallet(user_id)
        if existing_wallet:
            raise HTTPException(
                status_code=400,
                detail="User already has a wallet"
            )

        # Create new wallet
        wallet = marketplace.create_wallet(user_id, request.label)
        address = wallet.current_address

        logger.info(f"Created wallet for user {user_id}: {address}")

        # Get initial portfolio
        portfolio = await wallet.get_portfolio_summary()

        return {
            "wallet_address": address,
            "initial_balance": portfolio["balance_dracma"],
            "message": "Wallet created successfully",
            "portfolio": portfolio
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create wallet error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/info", response_model=WalletInfoResponse)
async def get_wallet_info(
    current_user: Dict = Depends(get_current_user)
):
    """
    Get current user's wallet information.

    - Returns balance, staking info, portfolio health
    - Requires authentication
    """
    try:
        user_id = current_user.sub

        wallet = marketplace.get_wallet(user_id)
        if not wallet:
            raise HTTPException(
                status_code=404,
                detail="Wallet not found. Please create a wallet first."
            )

        portfolio = await wallet.get_portfolio_summary()

        return WalletInfoResponse(**portfolio)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get wallet info error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/balance", response_model=Dict[str, Any])
async def get_wallet_balance(
    current_user: Dict = Depends(get_current_user)
):
    """
    Get current wallet balance.

    - Returns DRACMA balance
    - Fast endpoint for balance checks
    """
    try:
        user_id = current_user.sub

        wallet = marketplace.get_wallet(user_id)
        if not wallet:
            return {"balance_dracma": 0.0, "address": None}

        balance = await wallet.get_balance()

        return {
            "balance_dracma": balance,
            "address": wallet.current_address
        }

    except Exception as e:
        logger.error(f"Get balance error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/transfer", response_model=Dict[str, Any],
             summary="Transferir tokens DRACMA",
             description="""
             Transfiere tokens DRACMA a otra dirección de wallet.

             **Proceso:**
             - Valida que la dirección de destino sea válida (formato Ethereum)
             - Verifica balance suficiente en la wallet del usuario
             - Ejecuta la transacción en la blockchain
             - Registra la transacción en el historial

             **Requisitos:**
             - Dirección de destino debe comenzar con '0x' y tener 42 caracteres
             - Balance suficiente para cubrir el monto + fees de gas
             - Usuario debe estar autenticado

             **Códigos de respuesta:**
             - 200: Transferencia exitosa
             - 400: Balance insuficiente o dirección inválida
             - 500: Error en la transacción blockchain
             """,
             responses={
                 200: {
                     "description": "Transferencia exitosa",
                     "content": {
                         "application/json": {
                             "example": {
                                 "transaction_hash": "0x8ba1f109551bD432803012645A8D4D2...",
                                 "amount": 50.0,
                                 "receiver": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
                                 "description": "Pago por datos",
                                 "message": "Transfer completed successfully",
                                 "status": "confirmed"
                             }
                         }
                     }
                 },
                 400: {
                     "description": "Balance insuficiente o datos inválidos",
                     "content": {
                         "application/json": {
                             "example": {"detail": "Insufficient balance"}
                         }
                     }
                 }
             })
async def transfer_tokens(
    request: TransferRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Transfer DRACMA tokens to another address.

    - Validates sufficient balance
    - Executes blockchain transaction
    - Returns transaction hash
    """
    try:
        user_id = current_user.sub

        # Execute transfer
        tx_result = await marketplace.transfer_tokens(
            sender_id=user_id,
            receiver_address=request.receiver_address,
            amount=request.amount
        )

        if not tx_result.success:
            raise HTTPException(status_code=400, detail=f"Transfer failed: {tx_result.error_message}")

        logger.info(f"User {user_id} transferred {request.amount} DRACMA to {request.receiver_address}")

        return {
            "transaction_hash": tx_result.transaction_hash,
            "amount": request.amount,
            "receiver": request.receiver_address,
            "description": request.description,
            "message": "Transfer completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Transfer tokens error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/stake", response_model=Dict[str, Any])
async def stake_tokens(
    request: StakeRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Stake DRACMA tokens for rewards.

    - Locks tokens in staking contract
    - Provides reward multiplier
    - Returns transaction hash
    """
    try:
        user_id = current_user.sub

        # Execute staking
        tx_result = await marketplace.stake_tokens(
            user_id=user_id,
            amount=request.amount
        )

        if not tx_result.success:
            raise HTTPException(status_code=400, detail=f"Staking failed: {tx_result.error_message}")

        logger.info(f"User {user_id} staked {request.amount} DRACMA")

        return {
            "transaction_hash": tx_result.transaction_hash,
            "amount_staked": request.amount,
            "message": "Staking completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Stake tokens error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/unstake", response_model=Dict[str, Any])
async def unstake_tokens(
    request: StakeRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Unstake DRACMA tokens.

    - Releases tokens from staking contract
    - Returns tokens to available balance
    """
    try:
        user_id = current_user.sub

        # Execute unstaking
        tx_result = await marketplace.unstake_tokens(
            user_id=user_id,
            amount=request.amount
        )

        if not tx_result.success:
            raise HTTPException(status_code=400, detail=f"Unstaking failed: {tx_result.error_message}")

        logger.info(f"User {user_id} unstaked {request.amount} DRACMA")

        return {
            "transaction_hash": tx_result.transaction_hash,
            "amount_unstaked": request.amount,
            "message": "Unstaking completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unstake tokens error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/staking", response_model=StakingInfoResponse)
async def get_staking_info(
    current_user: Dict = Depends(get_current_user)
):
    """
    Get detailed staking information.

    - Returns staked amount, multiplier, rewards
    - Shows staking tier and benefits
    """
    try:
        user_id = current_user.sub

        wallet = marketplace.get_wallet(user_id)
        if not wallet:
            raise HTTPException(status_code=404, detail="Wallet not found")

        staking_info = await wallet.get_staking_info()

        # Determine staking tier
        staked = staking_info["staked_amount"]
        if staked >= 10000:
            tier = "Diamond"
        elif staked >= 1000:
            tier = "Gold"
        elif staked >= 100:
            tier = "Silver"
        else:
            tier = "Bronze"

        return StakingInfoResponse(
            staked_amount=staking_info["staked_amount"],
            multiplier=staking_info["multiplier"],
            estimated_daily_reward=staking_info["estimated_daily_reward"],
            estimated_monthly_reward=staking_info["estimated_monthly_reward"],
            staking_tier=tier
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get staking info error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/transactions", response_model=Dict[str, Any])
async def get_transaction_history(
    limit: int = 20,
    current_user: Dict = Depends(get_current_user)
):
    """
    Get wallet transaction history.

    - Returns recent transactions
    - Includes transfers, staking, purchases
    """
    try:
        user_id = current_user.sub

        transactions = await marketplace.get_transaction_history(
            user_id=user_id,
            limit=limit
        )

        # Format transactions for response
        formatted_txs = []
        for tx in transactions:
            formatted_txs.append(TransactionHistoryResponse(
                tx_hash=tx.get("tx_hash", ""),
                type=tx.get("type", ""),
                amount=tx.get("amount", 0),
                timestamp=tx.get("timestamp", 0),
                status=tx.get("status", ""),
                sender=tx.get("sender", ""),
                receiver=tx.get("receiver", ""),
                data=tx.get("data", {})
            ))

        return {
            "transactions": formatted_txs,
            "total": len(formatted_txs),
            "limit": limit
        }

    except Exception as e:
        logger.error(f"Get transaction history error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/export", response_model=Dict[str, Any])
async def export_wallet(
    request: ExportWalletRequest,
    current_user: Dict = Depends(get_current_user)
):
    """
    Export wallet in encrypted format.

    - Encrypts wallet data with password
    - Returns encrypted string for backup
    - Requires strong password
    """
    try:
        user_id = current_user.sub

        wallet = marketplace.get_wallet(user_id)
        if not wallet:
            raise HTTPException(status_code=404, detail="Wallet not found")

        # Export wallet
        encrypted_data = wallet.export_wallet(request.password)

        logger.info(f"User {user_id} exported wallet")

        return {
            "encrypted_wallet": encrypted_data,
            "message": "Wallet exported successfully. Keep this data safe!",
            "export_timestamp": wallet.addresses[list(wallet.addresses.keys())[0]].created_at
        }

    except Exception as e:
        logger.error(f"Export wallet error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/import", response_model=Dict[str, Any])
async def import_wallet(
    request: ImportWalletRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Import wallet from encrypted data.

    - Decrypts wallet data with password
    - Restores wallet addresses and keys
    - Merges with existing wallet if present
    """
    try:
        user_id = current_user.sub

        # Check if user already has wallet
        existing_wallet = marketplace.get_wallet(user_id)
        if existing_wallet:
            raise HTTPException(
                status_code=400,
                detail="User already has a wallet. Import will overwrite existing wallet."
            )

        # Create new wallet instance for import
        wallet = marketplace.create_wallet(user_id, "imported")

        # Import data
        success = wallet.import_wallet(request.encrypted_data, request.password)

        if not success:
            raise HTTPException(
                status_code=400,
                detail="Failed to import wallet. Check password and data integrity."
            )

        # Update marketplace wallet reference
        marketplace.wallets[user_id] = wallet

        logger.info(f"User {user_id} imported wallet successfully")

        portfolio = await wallet.get_portfolio_summary()

        return {
            "message": "Wallet imported successfully",
            "portfolio": portfolio
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Import wallet error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/stats", response_model=Dict[str, Any])
async def get_wallet_stats():
    """
    Get global wallet statistics.

    - Total wallets, staked tokens, transaction volume
    - Public endpoint, no authentication required
    """
    try:
        from ...blockchain.dracma_token import get_token_manager

        token_manager = get_token_manager()
        stats = await token_manager.get_global_stats()

        return {
            "total_supply": stats.get("total_supply", 0),
            "circulating_supply": stats.get("circulating_supply", 0),
            "total_staked": stats.get("total_staked", 0),
            "staking_ratio": stats.get("staking_ratio", 0),
            "active_addresses": stats.get("active_addresses", 0),
            "total_transactions": stats.get("total_transactions", 0),
            "current_block": stats.get("current_block", 0)
        }

    except Exception as e:
        logger.error(f"Get wallet stats error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Admin endpoints
@router.get("/admin/wallets", response_model=Dict[str, Any])
async def list_all_wallets(
    skip: int = 0,
    limit: int = 100,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Admin endpoint to list all user wallets.

    - Requires admin permissions
    - Returns wallet information for all users
    """
    try:
        # Get all wallets from marketplace
        all_wallets = marketplace.wallets

        wallets_list = []
        for user_id, wallet in list(all_wallets.items())[skip:skip + limit]:
            portfolio = await wallet.get_portfolio_summary()
            wallets_list.append({
                "user_id": user_id,
                "address": wallet.current_address,
                "balance_dracma": portfolio["balance_dracma"],
                "staked_dracma": portfolio["staked_dracma"],
                "portfolio_health": portfolio["portfolio_health"]
            })

        return {
            "wallets": wallets_list,
            "total": len(all_wallets),
            "skip": skip,
            "limit": limit
        }

    except Exception as e:
        logger.error(f"List all wallets error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/admin/transactions", response_model=Dict[str, Any])
async def get_all_transactions(
    skip: int = 0,
    limit: int = 100,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Admin endpoint to view all transactions.

    - Requires admin permissions
    - Returns global transaction history
    """
    try:
        from ...blockchain.dracma_token import get_token_manager

        token_manager = get_token_manager()
        # Get all transactions from token manager
        all_transactions = await token_manager.get_all_transactions()

        # Paginate and format
        paginated_txs = all_transactions[-limit-skip:-skip] if skip > 0 else all_transactions[-limit:]

        formatted_txs = []
        for tx in paginated_txs:
            formatted_txs.append({
                "tx_hash": tx.get("tx_hash", ""),
                "type": tx.get("type", ""),
                "amount": tx.get("amount", 0),
                "sender": tx.get("sender", ""),
                "receiver": tx.get("receiver", ""),
                "timestamp": tx.get("timestamp", 0),
                "status": tx.get("status", ""),
                "block_number": tx.get("block_number", 0)
            })

        return {
            "transactions": formatted_txs,
            "total": len(all_transactions),
            "skip": skip,
            "limit": limit
        }

    except Exception as e:
        logger.error(f"Get all transactions error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")