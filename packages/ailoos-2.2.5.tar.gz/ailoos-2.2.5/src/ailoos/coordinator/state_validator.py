"""
Validador de integridad de estado para el coordinador de Ailoos.
Valida la integridad y consistencia del estado global del coordinador,
incluyendo checksums de modelos, validación de sesiones activas,
verificación de contribuciones, detección de inconsistencias,
validaciones criptográficas, reglas de negocio y métricas de confianza.
"""

import asyncio
import hashlib
import hmac
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Set
from enum import Enum

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from .models.base import (
    FederatedSession, SessionParticipant, Contribution,
    Model, Node, RewardTransaction
)
from ..core.config import Config
from ..utils.logging import setup_logging
import logging

logger = logging.getLogger(__name__)


class ValidationSeverity(Enum):
    """Severidad de las validaciones."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class ValidationResult(Enum):
    """Resultado de una validación."""
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"


@dataclass
class ValidationIssue:
    """Representa un problema de validación detectado."""
    component: str
    issue_type: str
    severity: ValidationSeverity
    description: str
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    resolved: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convierte el issue a diccionario."""
        return {
            'component': self.component,
            'issue_type': self.issue_type,
            'severity': self.severity.value,
            'description': self.description,
            'details': self.details,
            'timestamp': self.timestamp,
            'resolved': self.resolved
        }


@dataclass
class StateIntegrityMetrics:
    """Métricas de integridad del estado."""
    total_validations: int = 0
    passed_validations: int = 0
    failed_validations: int = 0
    critical_issues: int = 0
    warning_issues: int = 0
    last_validation_time: Optional[float] = None
    average_validation_time: float = 0.0
    trust_score: float = 1.0  # 0.0 a 1.0
    components_validated: Set[str] = field(default_factory=set)


class StateValidator:
    """
    Validador de integridad de estado para el coordinador.

    Valida múltiples aspectos del estado global:
    - Checksums de modelos
    - Sesiones activas y participantes
    - Contribuciones y recompensas
    - Consistencia de datos
    - Validaciones criptográficas
    - Reglas de negocio
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.metrics = StateIntegrityMetrics()
        self.validation_issues: List[ValidationIssue] = []
        self.validation_history: List[Dict[str, Any]] = []
        self.cryptographic_key = self._generate_crypto_key()

        # Configuración de validación
        self.validation_interval = 300.0  # 5 minutos
        self.max_issues_history = 1000
        self.critical_issue_threshold = 10
        self.trust_score_decay_rate = 0.05

        # Componentes de validación
        self.validators = {
            'models': self._validate_models_integrity,
            'sessions': self._validate_sessions_integrity,
            'contributions': self._validate_contributions_integrity,
            'nodes': self._validate_nodes_integrity,
            'rewards': self._validate_rewards_integrity,
            'business_rules': self._validate_business_rules,
            'cryptographic': self._validate_cryptographic_integrity
        }

        logger.info("✅ StateValidator inicializado")

    def _generate_crypto_key(self) -> bytes:
        """Genera una clave criptográfica para validaciones HMAC."""
        # En producción, usar una clave segura de configuración
        key_seed = f"ailoos_state_validator_{int(time.time())}_{id(self)}"
        return hashlib.sha256(key_seed.encode()).digest()

    async def validate_global_state(self, db: Session) -> Tuple[bool, List[ValidationIssue]]:
        """
        Valida la integridad completa del estado global.

        Args:
            db: Sesión de base de datos

        Returns:
            (estado_válido, lista_de_issues)
        """
        start_time = time.time()
        issues = []

        try:
            logger.info("🔍 Iniciando validación completa del estado global")

            # Ejecutar todas las validaciones
            for component_name, validator_func in self.validators.items():
                try:
                    component_issues = await validator_func(db)
                    issues.extend(component_issues)
                    self.metrics.components_validated.add(component_name)
                except Exception as e:
                    logger.error(f"❌ Error validando componente {component_name}: {e}")
                    issues.append(ValidationIssue(
                        component=component_name,
                        issue_type="validation_error",
                        severity=ValidationSeverity.CRITICAL,
                        description=f"Error ejecutando validación: {str(e)}",
                        details={'error': str(e)}
                    ))

            # Calcular métricas
            validation_time = time.time() - start_time
            self._update_validation_metrics(issues, validation_time)

            # Registrar en historial
            self._record_validation_history(issues, validation_time)

            # Limpiar issues antiguos
            self._cleanup_old_issues()

            # Determinar si el estado es válido
            critical_issues = [i for i in issues if i.severity == ValidationSeverity.CRITICAL]
            is_valid = len(critical_issues) == 0

            logger.info(f"✅ Validación completada en {validation_time:.2f}s. "
                       f"Estado válido: {is_valid}, Issues: {len(issues)}")

            return is_valid, issues

        except Exception as e:
            logger.error(f"❌ Error crítico en validación de estado: {e}")
            critical_issue = ValidationIssue(
                component="state_validator",
                issue_type="critical_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error crítico en validación: {str(e)}",
                details={'error': str(e)}
            )
            return False, [critical_issue]

    async def _validate_models_integrity(self, db: Session) -> List[ValidationIssue]:
        """Valida la integridad de los modelos."""
        issues = []

        try:
            models = db.query(Model).all()

            for model in models:
                # Validar checksum si existe
                if model.global_parameters_hash:
                    if not self._validate_model_checksum(model):
                        issues.append(ValidationIssue(
                            component="models",
                            issue_type="checksum_mismatch",
                            severity=ValidationSeverity.ERROR,
                            description=f"Checksum inválido para modelo {model.id}",
                            details={
                                'model_id': model.id,
                                'expected_hash': model.global_parameters_hash
                            }
                        ))

                # Validar estado del modelo
                if model.status not in ['created', 'training', 'trained', 'published', 'archived', 'failed']:
                    issues.append(ValidationIssue(
                        component="models",
                        issue_type="invalid_status",
                        severity=ValidationSeverity.WARNING,
                        description=f"Estado inválido para modelo {model.id}: {model.status}",
                        details={'model_id': model.id, 'status': model.status}
                    ))

                # Validar consistencia de sesión
                if model.session_id:
                    session = db.query(FederatedSession).filter(FederatedSession.id == model.session_id).first()
                    if not session:
                        issues.append(ValidationIssue(
                            component="models",
                            issue_type="orphaned_model",
                            severity=ValidationSeverity.ERROR,
                            description=f"Modelo {model.id} referencia sesión inexistente {model.session_id}",
                            details={'model_id': model.id, 'session_id': model.session_id}
                        ))

        except Exception as e:
            logger.error(f"Error validando integridad de modelos: {e}")
            issues.append(ValidationIssue(
                component="models",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando modelos: {str(e)}"
            ))

        return issues

    async def _validate_sessions_integrity(self, db: Session) -> List[ValidationIssue]:
        """Valida la integridad de las sesiones."""
        issues = []

        try:
            sessions = db.query(FederatedSession).all()

            for session in sessions:
                # Validar estado de la sesión
                valid_states = ['created', 'active', 'running', 'completed', 'failed', 'cancelled']
                if session.status not in valid_states:
                    issues.append(ValidationIssue(
                        component="sessions",
                        issue_type="invalid_status",
                        severity=ValidationSeverity.WARNING,
                        description=f"Estado inválido para sesión {session.id}: {session.status}",
                        details={'session_id': session.id, 'status': session.status}
                    ))

                # Validar participantes
                participants = db.query(SessionParticipant).filter(
                    SessionParticipant.session_id == session.id
                ).all()

                # Verificar que no exceda límites
                if len(participants) > session.max_nodes:
                    issues.append(ValidationIssue(
                        component="sessions",
                        issue_type="participant_limit_exceeded",
                        severity=ValidationSeverity.ERROR,
                        description=f"Sesión {session.id} excede límite máximo de participantes",
                        details={
                            'session_id': session.id,
                            'current_participants': len(participants),
                            'max_nodes': session.max_nodes
                        }
                    ))

                # Validar sesiones activas con tiempo de vida excesivo
                if session.status in ['active', 'running'] and session.started_at:
                    age_days = (datetime.utcnow() - session.started_at).days
                    max_age_days = 30  # Configurable

                    if age_days > max_age_days:
                        issues.append(ValidationIssue(
                            component="sessions",
                            issue_type="session_too_old",
                            severity=ValidationSeverity.WARNING,
                            description=f"Sesión {session.id} activa por {age_days} días",
                            details={
                                'session_id': session.id,
                                'started_at': session.started_at.isoformat(),
                                'age_days': age_days
                            }
                        ))

        except Exception as e:
            logger.error(f"Error validando integridad de sesiones: {e}")
            issues.append(ValidationIssue(
                component="sessions",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando sesiones: {str(e)}"
            ))

        return issues

    async def _validate_contributions_integrity(self, db: Session) -> List[ValidationIssue]:
        """Valida la integridad de las contribuciones."""
        issues = []

        try:
            contributions = db.query(Contribution).all()

            for contribution in contributions:
                # Validar que la sesión existe
                session = db.query(FederatedSession).filter(
                    FederatedSession.id == contribution.session_id
                ).first()

                if not session:
                    issues.append(ValidationIssue(
                        component="contributions",
                        issue_type="orphaned_contribution",
                        severity=ValidationSeverity.ERROR,
                        description=f"Contribución {contribution.id} referencia sesión inexistente",
                        details={
                            'contribution_id': contribution.id,
                            'session_id': contribution.session_id
                        }
                    ))
                    continue

                # Validar que el nodo existe
                node = db.query(Node).filter(Node.id == contribution.node_id).first()
                if not node:
                    issues.append(ValidationIssue(
                        component="contributions",
                        issue_type="invalid_node",
                        severity=ValidationSeverity.ERROR,
                        description=f"Contribución {contribution.id} referencia nodo inexistente",
                        details={
                            'contribution_id': contribution.id,
                            'node_id': contribution.node_id
                        }
                    ))
                    continue

                # Validar que el nodo es participante de la sesión
                participant = db.query(SessionParticipant).filter(
                    and_(
                        SessionParticipant.session_id == contribution.session_id,
                        SessionParticipant.node_id == contribution.node_id
                    )
                ).first()

                if not participant:
                    issues.append(ValidationIssue(
                        component="contributions",
                        issue_type="unauthorized_contribution",
                        severity=ValidationSeverity.ERROR,
                        description=f"Nodo {contribution.node_id} no autorizado para contribuir en sesión {contribution.session_id}",
                        details={
                            'contribution_id': contribution.id,
                            'session_id': contribution.session_id,
                            'node_id': contribution.node_id
                        }
                    ))

                # Validar round number
                if contribution.round_number > session.total_rounds:
                    issues.append(ValidationIssue(
                        component="contributions",
                        issue_type="invalid_round",
                        severity=ValidationSeverity.WARNING,
                        description=f"Round inválido en contribución {contribution.id}",
                        details={
                            'contribution_id': contribution.id,
                            'round_number': contribution.round_number,
                            'total_rounds': session.total_rounds
                        }
                    ))

                # Validar datos de contribución
                if contribution.parameters_trained <= 0:
                    issues.append(ValidationIssue(
                        component="contributions",
                        issue_type="invalid_parameters",
                        severity=ValidationSeverity.WARNING,
                        description=f"Parámetros inválidos en contribución {contribution.id}",
                        details={
                            'contribution_id': contribution.id,
                            'parameters_trained': contribution.parameters_trained
                        }
                    ))

        except Exception as e:
            logger.error(f"Error validando integridad de contribuciones: {e}")
            issues.append(ValidationIssue(
                component="contributions",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando contribuciones: {str(e)}"
            ))

        return issues

    async def _validate_nodes_integrity(self, db: Session) -> List[ValidationIssue]:
        """Valida la integridad de los nodos."""
        issues = []

        try:
            nodes = db.query(Node).all()

            for node in nodes:
                # Validar estado del nodo
                valid_states = ['registered', 'active', 'inactive', 'suspended', 'banned']
                if node.status not in valid_states:
                    issues.append(ValidationIssue(
                        component="nodes",
                        issue_type="invalid_status",
                        severity=ValidationSeverity.WARNING,
                        description=f"Estado inválido para nodo {node.id}: {node.status}",
                        details={'node_id': node.id, 'status': node.status}
                    ))

                # Validar reputación
                if not (0.0 <= node.reputation_score <= 1.0):
                    issues.append(ValidationIssue(
                        component="nodes",
                        issue_type="invalid_reputation",
                        severity=ValidationSeverity.WARNING,
                        description=f"Reputación inválida para nodo {node.id}: {node.reputation_score}",
                        details={'node_id': node.id, 'reputation': node.reputation_score}
                    ))

                # Validar nodos inactivos por mucho tiempo
                if node.last_heartbeat:
                    days_since_heartbeat = (datetime.utcnow() - node.last_heartbeat).days
                    max_inactive_days = 7  # Configurable

                    if days_since_heartbeat > max_inactive_days and node.status == 'active':
                        issues.append(ValidationIssue(
                            component="nodes",
                            issue_type="inactive_node",
                            severity=ValidationSeverity.INFO,
                            description=f"Nodo {node.id} activo pero sin heartbeat por {days_since_heartbeat} días",
                            details={
                                'node_id': node.id,
                                'last_heartbeat': node.last_heartbeat.isoformat(),
                                'days_inactive': days_since_heartbeat
                            }
                        ))

        except Exception as e:
            logger.error(f"Error validando integridad de nodos: {e}")
            issues.append(ValidationIssue(
                component="nodes",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando nodos: {str(e)}"
            ))

        return issues

    async def _validate_rewards_integrity(self, db: Session) -> List[ValidationIssue]:
        """Valida la integridad de las recompensas."""
        issues = []

        try:
            rewards = db.query(RewardTransaction).all()

            for reward in rewards:
                # Validar que la contribución existe si está referenciada
                if reward.contribution_id:
                    contribution = db.query(Contribution).filter(
                        Contribution.id == reward.contribution_id
                    ).first()

                    if not contribution:
                        issues.append(ValidationIssue(
                            component="rewards",
                            issue_type="orphaned_reward",
                            severity=ValidationSeverity.ERROR,
                            description=f"Recompensa {reward.id} referencia contribución inexistente",
                            details={
                                'reward_id': reward.id,
                                'contribution_id': reward.contribution_id
                            }
                        ))

                # Validar montos positivos
                if reward.drachma_amount <= 0:
                    issues.append(ValidationIssue(
                        component="rewards",
                        issue_type="invalid_amount",
                        severity=ValidationSeverity.WARNING,
                        description=f"Monto inválido en recompensa {reward.id}: {reward.drachma_amount}",
                        details={
                            'reward_id': reward.id,
                            'amount': reward.drachma_amount
                        }
                    ))

                # Validar estado
                valid_states = ['pending', 'processing', 'completed', 'failed', 'cancelled']
                if reward.status not in valid_states:
                    issues.append(ValidationIssue(
                        component="rewards",
                        issue_type="invalid_status",
                        severity=ValidationSeverity.WARNING,
                        description=f"Estado inválido en recompensa {reward.id}: {reward.status}",
                        details={'reward_id': reward.id, 'status': reward.status}
                    ))

        except Exception as e:
            logger.error(f"Error validando integridad de recompensas: {e}")
            issues.append(ValidationIssue(
                component="rewards",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando recompensas: {str(e)}"
            ))

        return issues

    async def _validate_business_rules(self, db: Session) -> List[ValidationIssue]:
        """Valida reglas de negocio."""
        issues = []

        try:
            # Regla: Sesiones completadas deben tener contribuciones
            completed_sessions = db.query(FederatedSession).filter(
                FederatedSession.status == 'completed'
            ).all()

            for session in completed_sessions:
                contribution_count = db.query(Contribution).filter(
                    and_(
                        Contribution.session_id == session.id,
                        Contribution.status == 'validated'
                    )
                ).count()

                if contribution_count == 0:
                    issues.append(ValidationIssue(
                        component="business_rules",
                        issue_type="completed_session_no_contributions",
                        severity=ValidationSeverity.WARNING,
                        description=f"Sesión completada {session.id} sin contribuciones validadas",
                        details={'session_id': session.id}
                    ))

            # Regla: Contribuciones validadas deben tener recompensas
            validated_contributions = db.query(Contribution).filter(
                Contribution.status == 'validated'
            ).all()

            for contribution in validated_contributions:
                reward = db.query(RewardTransaction).filter(
                    and_(
                        RewardTransaction.contribution_id == contribution.id,
                        RewardTransaction.status == 'completed'
                    )
                ).first()

                if not reward:
                    issues.append(ValidationIssue(
                        component="business_rules",
                        issue_type="validated_contribution_no_reward",
                        severity=ValidationSeverity.INFO,
                        description=f"Contribución validada {contribution.id} sin recompensa completada",
                        details={'contribution_id': contribution.id}
                    ))

            # Regla: Sesiones activas no deben exceder tiempo límite
            active_sessions = db.query(FederatedSession).filter(
                FederatedSession.status.in_(['active', 'running'])
            ).all()

            for session in active_sessions:
                if session.estimated_completion and datetime.utcnow() > session.estimated_completion:
                    days_overdue = (datetime.utcnow() - session.estimated_completion).days
                    issues.append(ValidationIssue(
                        component="business_rules",
                        issue_type="session_overdue",
                        severity=ValidationSeverity.WARNING,
                        description=f"Sesión {session.id} retrasada {days_overdue} días",
                        details={
                            'session_id': session.id,
                            'estimated_completion': session.estimated_completion.isoformat(),
                            'days_overdue': days_overdue
                        }
                    ))

        except Exception as e:
            logger.error(f"Error validando reglas de negocio: {e}")
            issues.append(ValidationIssue(
                component="business_rules",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando reglas de negocio: {str(e)}"
            ))

        return issues

    async def _validate_cryptographic_integrity(self, db: Session) -> List[ValidationIssue]:
        """Valida integridad criptográfica."""
        issues = []

        try:
            # Validar firmas de modelos (si existen)
            models_with_hash = db.query(Model).filter(
                Model.global_parameters_hash.isnot(None)
            ).all()

            for model in models_with_hash:
                if not self._validate_model_cryptographic_signature(model):
                    issues.append(ValidationIssue(
                        component="cryptographic",
                        issue_type="invalid_signature",
                        severity=ValidationSeverity.ERROR,
                        description=f"Firma criptográfica inválida para modelo {model.id}",
                        details={'model_id': model.id}
                    ))

            # Validar integridad de contribuciones validadas
            validated_contributions = db.query(Contribution).filter(
                and_(
                    Contribution.status == 'validated',
                    Contribution.validation_hash.isnot(None)
                )
            ).all()

            for contribution in validated_contributions:
                if not self._validate_contribution_hash(contribution):
                    issues.append(ValidationIssue(
                        component="cryptographic",
                        issue_type="invalid_contribution_hash",
                        severity=ValidationSeverity.ERROR,
                        description=f"Hash de validación inválido para contribución {contribution.id}",
                        details={'contribution_id': contribution.id}
                    ))

        except Exception as e:
            logger.error(f"Error validando integridad criptográfica: {e}")
            issues.append(ValidationIssue(
                component="cryptographic",
                issue_type="validation_error",
                severity=ValidationSeverity.CRITICAL,
                description=f"Error validando integridad criptográfica: {str(e)}"
            ))

        return issues

    def _validate_model_checksum(self, model: Model) -> bool:
        """Valida el checksum de un modelo."""
        try:
            # Crear hash de los parámetros del modelo
            model_data = {
                'id': model.id,
                'name': model.name,
                'version': model.version,
                'architecture': model.architecture,
                'hyperparameters': model.hyperparameters,
                'metrics': model.metrics
            }

            content_str = json.dumps(model_data, sort_keys=True, default=str)
            calculated_hash = hashlib.sha256(content_str.encode()).hexdigest()

            return calculated_hash == model.global_parameters_hash
        except Exception:
            return False

    def _validate_model_cryptographic_signature(self, model: Model) -> bool:
        """Valida la firma criptográfica de un modelo."""
        try:
            # Implementar validación HMAC usando la clave del validador
            model_data = f"{model.id}:{model.global_parameters_hash}:{model.updated_at.isoformat()}"
            expected_signature = hmac.new(
                self.cryptographic_key,
                model_data.encode(),
                hashlib.sha256
            ).hexdigest()

            # En un sistema real, comparar con firma almacenada
            # Por ahora, solo validamos que el hash sea consistente
            return self._validate_model_checksum(model)
        except Exception:
            return False

    def _validate_contribution_hash(self, contribution: Contribution) -> bool:
        """Valida el hash de validación de una contribución."""
        try:
            # Crear hash de los datos de contribución
            contribution_data = {
                'id': contribution.id,
                'session_id': contribution.session_id,
                'node_id': contribution.node_id,
                'round_number': contribution.round_number,
                'parameters_trained': contribution.parameters_trained,
                'data_samples_used': contribution.data_samples_used,
                'model_accuracy': contribution.model_accuracy,
                'loss_value': contribution.loss_value,
                'validated_at': contribution.validated_at.isoformat() if contribution.validated_at else None
            }

            content_str = json.dumps(contribution_data, sort_keys=True, default=str)
            calculated_hash = hashlib.sha256(content_str.encode()).hexdigest()

            return calculated_hash == contribution.validation_hash
        except Exception:
            return False

    def _update_validation_metrics(self, issues: List[ValidationIssue], validation_time: float):
        """Actualiza las métricas de validación."""
        self.metrics.total_validations += 1
        self.metrics.last_validation_time = time.time()

        # Contar resultados
        critical_count = sum(1 for i in issues if i.severity == ValidationSeverity.CRITICAL)
        warning_count = sum(1 for i in issues if i.severity == ValidationSeverity.WARNING)

        self.metrics.critical_issues = critical_count
        self.metrics.warning_issues = warning_count

        # Calcular promedio de tiempo
        if self.metrics.total_validations == 1:
            self.metrics.average_validation_time = validation_time
        else:
            self.metrics.average_validation_time = (
                (self.metrics.average_validation_time * (self.metrics.total_validations - 1)) +
                validation_time
            ) / self.metrics.total_validations

        # Calcular trust score
        base_trust = 1.0
        critical_penalty = min(critical_count * 0.2, 0.8)  # Máximo 80% penalty por critical
        warning_penalty = min(warning_count * 0.05, 0.2)  # Máximo 20% penalty por warning

        new_trust = base_trust - critical_penalty - warning_penalty

        # Aplicar decay rate para trust score anterior
        if hasattr(self.metrics, 'trust_score'):
            decayed_trust = self.metrics.trust_score * (1 - self.trust_score_decay_rate)
            self.metrics.trust_score = max(new_trust, decayed_trust)
        else:
            self.metrics.trust_score = new_trust

        # Asegurar límites
        self.metrics.trust_score = max(0.0, min(1.0, self.metrics.trust_score))

    def _record_validation_history(self, issues: List[ValidationIssue], validation_time: float):
        """Registra la validación en el historial."""
        record = {
            'timestamp': time.time(),
            'validation_time': validation_time,
            'issues_count': len(issues),
            'critical_issues': sum(1 for i in issues if i.severity == ValidationSeverity.CRITICAL),
            'warning_issues': sum(1 for i in issues if i.severity == ValidationSeverity.WARNING),
            'trust_score': self.metrics.trust_score,
            'components_validated': list(self.metrics.components_validated)
        }

        self.validation_history.append(record)

        # Mantener solo las últimas N validaciones
        if len(self.validation_history) > 100:
            self.validation_history = self.validation_history[-100:]

    def _cleanup_old_issues(self):
        """Limpia issues antiguos resueltos."""
        # Mantener solo issues no resueltos más recientes
        unresolved_issues = [i for i in self.validation_issues if not i.resolved]
        resolved_issues = [i for i in self.validation_issues if i.resolved]

        # Mantener máximo de issues resueltos
        max_resolved = self.max_issues_history // 2
        if len(resolved_issues) > max_resolved:
            resolved_issues = sorted(resolved_issues, key=lambda x: x.timestamp, reverse=True)[:max_resolved]

        self.validation_issues = unresolved_issues + resolved_issues

        # Limitar total
        if len(self.validation_issues) > self.max_issues_history:
            self.validation_issues = sorted(
                self.validation_issues,
                key=lambda x: x.timestamp,
                reverse=True
            )[:self.max_issues_history]

    def get_integrity_report(self) -> Dict[str, Any]:
        """Obtiene un reporte completo de integridad."""
        return {
            'metrics': {
                'total_validations': self.metrics.total_validations,
                'passed_validations': self.metrics.passed_validations,
                'failed_validations': self.metrics.failed_validations,
                'critical_issues': self.metrics.critical_issues,
                'warning_issues': self.metrics.warning_issues,
                'last_validation_time': self.metrics.last_validation_time,
                'average_validation_time': self.metrics.average_validation_time,
                'trust_score': self.metrics.trust_score,
                'components_validated': list(self.metrics.components_validated)
            },
            'current_issues': [i.to_dict() for i in self.validation_issues if not i.resolved],
            'recent_history': self.validation_history[-10:] if self.validation_history else [],
            'health_status': self._calculate_health_status()
        }

    def _calculate_health_status(self) -> str:
        """Calcula el estado de salud del sistema."""
        trust_score = self.metrics.trust_score
        critical_issues = self.metrics.critical_issues

        if critical_issues > 0:
            return "critical"
        elif trust_score < 0.5:
            return "unhealthy"
        elif trust_score < 0.8:
            return "warning"
        else:
            return "healthy"

    async def start_periodic_validation(self, db_factory):
        """
        Inicia validación periódica del estado.

        Args:
            db_factory: Factory para obtener sesiones de DB
        """
        while True:
            try:
                await asyncio.sleep(self.validation_interval)

                # Obtener sesión de DB
                db = db_factory()
                try:
                    is_valid, issues = await self.validate_global_state(db)

                    if not is_valid:
                        logger.warning(f"⚠️ Estado global inválido detectado: {len(issues)} issues")

                    # Log issues críticos
                    critical_issues = [i for i in issues if i.severity == ValidationSeverity.CRITICAL]
                    if critical_issues:
                        logger.error(f"🚨 Issues críticos detectados: {len(critical_issues)}")

                finally:
                    db.close()

            except Exception as e:
                logger.error(f"❌ Error en validación periódica: {e}")

    def resolve_issue(self, component: str, issue_type: str, details: Dict[str, Any] = None) -> bool:
        """
        Marca un issue como resuelto.

        Args:
            component: Componente del issue
            issue_type: Tipo del issue
            details: Detalles adicionales para matching

        Returns:
            True si se encontró y resolvió el issue
        """
        for issue in self.validation_issues:
            if (issue.component == component and
                issue.issue_type == issue_type and
                not issue.resolved):

                # Verificar detalles si proporcionados
                if details:
                    match = True
                    for key, value in details.items():
                        if issue.details.get(key) != value:
                            match = False
                            break
                    if not match:
                        continue

                issue.resolved = True
                logger.info(f"✅ Issue resuelto: {component}:{issue_type}")
                return True

        return False


# Instancia global del validador
state_validator = StateValidator()