"""
Service layer for federated learning rounds management.
"""

from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
from sqlalchemy.orm import Session

from ..database.connection import get_db
from ..models.schemas import RoundCreate, RoundUpdate
from ..core.exceptions import CoordinatorException


class RoundService:
    """Service for managing federated learning rounds."""

    @staticmethod
    async def get_active_rounds(db: Session) -> List[Dict[str, Any]]:
        """Get all active federated learning rounds."""
        try:
            # In a real implementation, this would query the database
            # For now, return mock data that matches the frontend expectations
            return [
                {
                    "id": "round-1",
                    "session_id": "session-001",
                    "round_number": 5,
                    "status": "active",
                    "progress_percentage": 67,
                    "active_participants": 12,
                    "total_participants": 15,
                    "estimated_completion": (datetime.now().replace(hour=datetime.now().hour + 2)).isoformat(),
                    "started_at": (datetime.now().replace(hour=datetime.now().hour - 0.5)).isoformat(),
                    "metrics": {
                        "loss": 0.034,
                        "accuracy": 0.89,
                        "f1_score": 0.85,
                        "throughput": 18.2,
                    },
                    "participants": [
                        {
                            "id": "1",
                            "node_id": "node-001",
                            "status": "active",
                            "contributions_count": 45,
                            "rewards_earned": 1250,
                            "last_activity": (datetime.now().replace(minute=datetime.now().minute - 5)).isoformat(),
                            "performance_metrics": {
                                "local_loss": 0.032,
                                "local_accuracy": 0.91,
                                "computation_time": 45.2,
                            },
                        },
                        {
                            "id": "2",
                            "node_id": "node-002",
                            "status": "active",
                            "contributions_count": 42,
                            "rewards_earned": 1180,
                            "last_activity": (datetime.now().replace(minute=datetime.now().minute - 8)).isoformat(),
                            "performance_metrics": {
                                "local_loss": 0.038,
                                "local_accuracy": 0.87,
                                "computation_time": 52.1,
                            },
                        },
                    ],
                },
                {
                    "id": "round-2",
                    "session_id": "session-002",
                    "round_number": 3,
                    "status": "running",
                    "progress_percentage": 45,
                    "active_participants": 8,
                    "total_participants": 10,
                    "estimated_completion": (datetime.now().replace(hour=datetime.now().hour + 1.5)).isoformat(),
                    "started_at": (datetime.now().replace(minute=datetime.now().minute - 45)).isoformat(),
                    "metrics": {
                        "loss": 0.028,
                        "accuracy": 0.91,
                        "f1_score": 0.88,
                        "throughput": 22.1,
                    },
                    "participants": [
                        {
                            "id": "3",
                            "node_id": "node-003",
                            "status": "active",
                            "contributions_count": 28,
                            "rewards_earned": 890,
                            "last_activity": (datetime.now().replace(minute=datetime.now().minute - 3)).isoformat(),
                            "performance_metrics": {
                                "local_loss": 0.025,
                                "local_accuracy": 0.93,
                                "computation_time": 38.7,
                            },
                        },
                    ],
                },
                {
                    "id": "round-3",
                    "session_id": "session-003",
                    "round_number": 7,
                    "status": "active",
                    "progress_percentage": 89,
                    "active_participants": 15,
                    "total_participants": 16,
                    "estimated_completion": (datetime.now().replace(minute=datetime.now().minute + 30)).isoformat(),
                    "started_at": (datetime.now().replace(minute=datetime.now().minute - 20)).isoformat(),
                    "metrics": {
                        "loss": 0.019,
                        "accuracy": 0.94,
                        "f1_score": 0.91,
                        "throughput": 16.8,
                    },
                    "participants": [
                        {
                            "id": "4",
                            "node_id": "node-004",
                            "status": "active",
                            "contributions_count": 67,
                            "rewards_earned": 2100,
                            "last_activity": (datetime.now().replace(minute=datetime.now().minute - 2)).isoformat(),
                            "performance_metrics": {
                                "local_loss": 0.017,
                                "local_accuracy": 0.96,
                                "computation_time": 41.3,
                            },
                        },
                    ],
                },
            ]
        except Exception as e:
            raise CoordinatorException(f"Error retrieving active rounds: {str(e)}", status_code=500)

    @staticmethod
    async def list_rounds(
        db: Session,
        skip: int = 0,
        limit: int = 100,
        session_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> Tuple[List[Dict[str, Any]], int]:
        """List rounds with optional filtering and pagination."""
        try:
            # In a real implementation, this would query the database with filters
            all_rounds = await RoundService.get_active_rounds(db)

            # Apply filters
            filtered_rounds = all_rounds
            if session_id:
                filtered_rounds = [r for r in filtered_rounds if r["session_id"] == session_id]
            if status:
                filtered_rounds = [r for r in filtered_rounds if r["status"] == status]

            # Apply pagination
            total = len(filtered_rounds)
            paginated_rounds = filtered_rounds[skip:skip + limit]

            return paginated_rounds, total
        except Exception as e:
            raise CoordinatorException(f"Error listing rounds: {str(e)}", status_code=500)

    @staticmethod
    async def get_round_by_id(db: Session, round_id: str) -> Dict[str, Any]:
        """Get a specific round by ID."""
        try:
            all_rounds = await RoundService.get_active_rounds(db)
            round_data = next((r for r in all_rounds if r["id"] == round_id), None)

            if not round_data:
                raise CoordinatorException(f"Round {round_id} not found", status_code=404)

            return round_data
        except CoordinatorException:
            raise
        except Exception as e:
            raise CoordinatorException(f"Error retrieving round {round_id}: {str(e)}", status_code=500)

    @staticmethod
    async def create_round(db: Session, round_data: RoundCreate) -> Dict[str, Any]:
        """Create a new round."""
        try:
            # In a real implementation, this would create a database record
            new_round = {
                "id": f"round-{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "session_id": round_data.session_id,
                "round_number": round_data.round_number,
                "status": "created",
                "progress_percentage": 0,
                "active_participants": 0,
                "total_participants": round_data.total_participants,
                "created_at": datetime.now().isoformat(),
                "configuration": round_data.configuration,
            }

            return new_round
        except Exception as e:
            raise CoordinatorException(f"Error creating round: {str(e)}", status_code=500)

    @staticmethod
    async def update_round(db: Session, round_id: str, round_update: RoundUpdate) -> Dict[str, Any]:
        """Update a round."""
        try:
            # Get existing round
            round_data = await RoundService.get_round_by_id(db, round_id)

            # Apply updates
            for field, value in round_update.dict(exclude_unset=True).items():
                round_data[field] = value

            round_data["updated_at"] = datetime.now().isoformat()

            return round_data
        except CoordinatorException:
            raise
        except Exception as e:
            raise CoordinatorException(f"Error updating round {round_id}: {str(e)}", status_code=500)

    @staticmethod
    async def start_round(db: Session, round_id: str) -> Dict[str, Any]:
        """Start a round."""
        try:
            round_data = await RoundService.get_round_by_id(db, round_id)

            if round_data["status"] != "created":
                raise CoordinatorException(f"Round {round_id} cannot be started (status: {round_data['status']})", status_code=400)

            round_data["status"] = "active"
            round_data["started_at"] = datetime.now().isoformat()

            return round_data
        except CoordinatorException:
            raise
        except Exception as e:
            raise CoordinatorException(f"Error starting round {round_id}: {str(e)}", status_code=500)

    @staticmethod
    async def complete_round(db: Session, round_id: str) -> Dict[str, Any]:
        """Complete a round."""
        try:
            round_data = await RoundService.get_round_by_id(db, round_id)

            if round_data["status"] not in ["active", "running"]:
                raise CoordinatorException(f"Round {round_id} cannot be completed (status: {round_data['status']})", status_code=400)

            round_data["status"] = "completed"
            round_data["completed_at"] = datetime.now().isoformat()
            round_data["progress_percentage"] = 100

            return round_data
        except CoordinatorException:
            raise
        except Exception as e:
            raise CoordinatorException(f"Error completing round {round_id}: {str(e)}", status_code=500)

    @staticmethod
    async def get_round_participants(
        db: Session,
        round_id: str,
        status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get participants for a round."""
        try:
            round_data = await RoundService.get_round_by_id(db, round_id)
            participants = round_data.get("participants", [])

            if status:
                participants = [p for p in participants if p.get("status") == status]

            return participants
        except CoordinatorException:
            raise
        except Exception as e:
            raise CoordinatorException(f"Error retrieving participants for round {round_id}: {str(e)}", status_code=500)

    @staticmethod
    async def submit_model_update(
        db: Session,
        round_id: str,
        node_id: str,
        model_update: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Submit a model update for a round."""
        try:
            round_data = await RoundService.get_round_by_id(db, round_id)

            if round_data["status"] not in ["active", "running"]:
                raise CoordinatorException(f"Round {round_id} is not active", status_code=400)

            # In a real implementation, this would validate and store the model update
            result = {
                "round_id": round_id,
                "node_id": node_id,
                "submitted_at": datetime.now().isoformat(),
                "status": "accepted",
                "update_size": len(str(model_update))  # Simplified
            }

            return result
        except CoordinatorException:
            raise
        except Exception as e:
            raise CoordinatorException(f"Error submitting model update for round {round_id}: {str(e)}", status_code=500)

    @staticmethod
    async def get_active_rounds_count(db: Session) -> int:
        """Get count of active rounds."""
        try:
            active_rounds = await RoundService.get_active_rounds(db)
            return len(active_rounds)
        except Exception as e:
            raise CoordinatorException(f"Error counting active rounds: {str(e)}", status_code=500)