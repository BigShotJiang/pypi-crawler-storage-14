"""
Pydantic schemas for API request/response models.
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, validator
from fastapi import UploadFile


class InferenceRequest(BaseModel):
    """Schema for inference request."""
    prompt: str = Field(..., description="Input text prompt")
    max_tokens: Optional[int] = Field(512, ge=1, le=2048, description="Maximum tokens to generate")
    temperature: Optional[float] = Field(0.7, ge=0.0, le=2.0, description="Sampling temperature")
    top_p: Optional[float] = Field(0.9, ge=0.0, le=1.0, description="Top-p sampling parameter")
    top_k: Optional[int] = Field(50, ge=1, le=100, description="Top-k sampling parameter")
    stream: bool = Field(False, description="Enable streaming response")
    stop_sequences: Optional[List[str]] = Field(None, description="Stop sequences")


class InferenceResponse(BaseModel):
    """Schema for inference response."""
    text: str = Field(..., description="Generated text")
    usage: Dict[str, Any] = Field(..., description="Token usage statistics")
    model_version: str = Field(..., description="Model version used")
    generated_at: datetime = Field(default_factory=datetime.utcnow, description="Generation timestamp")


class ModelInfo(BaseModel):
    """Schema for model information."""
    id: str = Field(..., description="Model identifier")
    object: str = Field("model", description="Object type")
    created: int = Field(..., description="Creation timestamp")
    owned_by: str = Field("ailoos", description="Owner organization")


class ModelCreate(BaseModel):
    """Schema for model creation request."""
    name: str = Field(..., min_length=1, max_length=255, description="Model name")
    model_type: str = Field(..., min_length=1, max_length=100, description="Model type")
    description: Optional[str] = Field(None, max_length=1000, description="Model description")
    version: Optional[str] = Field("1.0.0", description="Model version")
    config: Optional[Dict[str, Any]] = Field(None, description="Model configuration")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Initial metrics")
    tags: Optional[List[str]] = Field(None, description="Model tags")


class ModelUpdate(BaseModel):
    """Schema for model update request."""
    name: Optional[str] = Field(None, min_length=1, max_length=255, description="Model name")
    description: Optional[str] = Field(None, max_length=1000, description="Model description")
    version: Optional[str] = Field(None, description="Model version")
    config: Optional[Dict[str, Any]] = Field(None, description="Model configuration")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Model metrics")
    tags: Optional[List[str]] = Field(None, description="Model tags")


# Federated Learning Schemas
class FederatedSessionResponse(BaseModel):
    """Response schema for federated session."""
    id: str
    name: str
    description: Optional[str]
    model_type: str
    status: str
    current_round: int
    total_rounds: int
    min_nodes: int
    max_nodes: int
    active_participants: int
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]


class FederatedSessionCreate(BaseModel):
    """Schema for creating federated session."""
    name: str
    description: Optional[str]
    model_type: str
    total_rounds: int = Field(10, ge=1, le=100)
    min_nodes: int = Field(2, ge=1)
    max_nodes: int = Field(100, ge=1, le=1000)


class FederatedSessionUpdate(BaseModel):
    """Schema for updating federated session."""
    name: Optional[str]
    description: Optional[str]
    status: Optional[str]
    total_rounds: Optional[int]


class SessionParticipantResponse(BaseModel):
    """Response schema for session participant."""
    id: int
    session_id: str
    node_id: str
    status: str
    joined_at: Optional[datetime]
    contributions_count: int
    rewards_earned: float


# Node Schemas
class NodeResponse(BaseModel):
    """Response schema for node."""
    id: str
    public_key: str
    status: str
    reputation_score: float
    trust_level: str
    hardware_specs: Optional[Dict[str, Any]]
    last_heartbeat: Optional[datetime]
    total_contributions: int
    total_rewards_earned: float
    is_verified: bool
    created_at: datetime


class NodeUpdate(BaseModel):
    """Schema for updating node."""
    status: Optional[str]
    reputation_score: Optional[float]
    trust_level: Optional[str]
    hardware_specs: Optional[Dict[str, Any]]


# Contribution Schemas
class ContributionResponse(BaseModel):
    """Response schema for contribution."""
    id: int
    session_id: str
    node_id: str
    round_number: int
    parameters_trained: int
    data_samples: int
    training_time_seconds: float
    model_accuracy: Optional[float]
    loss_value: Optional[float]
    status: str
    rewards_calculated: Optional[float]
    submitted_at: datetime
    validated_at: Optional[datetime]


class ContributionCreate(BaseModel):
    """Schema for creating contribution."""
    session_id: str
    round_number: int
    parameters_trained: int
    data_samples: int
    training_time_seconds: float
    model_accuracy: Optional[float]
    loss_value: Optional[float]
    hardware_specs: Dict[str, Any]
    proof_of_work: str


# Model Schemas
class ModelResponse(BaseModel):
    """Response schema for model."""
    id: str
    name: str
    version: str
    model_type: str
    description: Optional[str]
    architecture: Optional[Dict[str, Any]]
    hyperparameters: Optional[Dict[str, Any]]
    metrics: Optional[Dict[str, Any]]
    tags: Optional[List[str]]
    is_public: bool
    session_id: Optional[str]
    status: str
    ipfs_cid: Optional[str]
    file_hash: Optional[str]
    file_size: Optional[int]
    storage_location: Optional[str]
    owner_node_id: Optional[str]
    published_at: Optional[datetime]
    published_by: Optional[str]
    created_at: datetime
    updated_at: datetime


class ModelCreate(BaseModel):
    """Schema for creating model."""
    name: str
    model_type: str
    description: Optional[str]
    version: Optional[str]
    config: Optional[Dict[str, Any]]
    metrics: Optional[Dict[str, Any]]
    tags: Optional[List[str]]


class ModelUpdate(BaseModel):
    """Schema for updating model."""
    name: Optional[str]
    description: Optional[str]
    status: Optional[str]
    metrics: Optional[Dict[str, Any]]
    is_public: Optional[bool]


class ModelUpload(BaseModel):
    """Schema for model file upload."""
    name: str = Field(..., min_length=1, max_length=255, description="Model name")
    model_type: str = Field(..., min_length=1, max_length=100, description="Model type (e.g., 'tensorflow', 'pytorch')")
    description: Optional[str] = Field(None, max_length=1000, description="Model description")
    version: Optional[str] = Field("1.0.0", description="Model version")
    tags: Optional[List[str]] = Field(None, description="Model tags")
    file: UploadFile = Field(..., description="Model file to upload")


# Common Response Schemas
class APIResponse(BaseModel):
    """Generic API response schema."""
    success: bool = Field(True, description="Operation success status")
    message: str = Field(..., description="Response message")
    data: Optional[Any] = Field(None, description="Response data")
    errors: Optional[List[str]] = Field(None, description="Error messages if any")


class PaginatedResponse(BaseModel):
    """Paginated response schema."""
    success: bool = Field(True, description="Operation success status")
    message: str = Field(..., description="Response message")
    data: List[Any] = Field(..., description="Response data list")
    total: int = Field(..., description="Total number of items")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Items per page")
    total_pages: int = Field(..., description="Total number of pages")


class StatusResponse(BaseModel):
    """Schema for service status response."""
    status: str = Field(..., description="Service status")
    model_loaded: bool = Field(..., description="Model loaded status")
    device: str = Field(..., description="Device being used")
    model_info: Optional[Dict[str, Any]] = Field(None, description="Model information")
    metrics: Dict[str, Any] = Field(..., description="Service metrics")
    config: Dict[str, Any] = Field(..., description="Service configuration")


# WebSocket Schemas
class WebSocketMessage(BaseModel):
    """Base schema for WebSocket messages."""
    type: str = Field(..., description="Message type")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Message timestamp")
    session_id: Optional[str] = Field(None, description="Session ID if applicable")
    node_id: Optional[str] = Field(None, description="Node ID if applicable")
    data: Dict[str, Any] = Field(..., description="Message data payload")


class WebSocketSessionUpdate(WebSocketMessage):
    """Schema for session update WebSocket messages."""
    type: str = Field("session_update", description="Message type")
    update_type: str = Field(..., description="Type of session update")
    session_data: Dict[str, Any] = Field(..., description="Session data")


class WebSocketMetricsUpdate(WebSocketMessage):
    """Schema for metrics update WebSocket messages."""
    type: str = Field("metrics_update", description="Message type")
    metrics_type: str = Field(..., description="Type of metrics update")
    metrics_data: Dict[str, Any] = Field(..., description="Metrics data")


class WebSocketAlert(WebSocketMessage):
    """Schema for alert WebSocket messages."""
    type: str = Field("alert", description="Message type")
    alert_type: str = Field(..., description="Type of alert")
    severity: str = Field(..., description="Alert severity: info, warning, error, critical")
    message: str = Field(..., description="Alert message")


class WebSocketFederatedEvent(WebSocketMessage):
    """Schema for federated learning event WebSocket messages."""
    type: str = Field("federated_event", description="Message type")
    event_type: str = Field(..., description="Type of federated event")
    event_data: Dict[str, Any] = Field(..., description="Event data")


# Metrics Schemas
class NodeMetricsResponse(BaseModel):
    """Schema for node metrics response."""
    node_id: str = Field(..., description="Node identifier")
    status: str = Field(..., description="Node status")
    reputation_score: float = Field(..., description="Node reputation score")
    total_contributions: int = Field(..., description="Total contributions made")
    total_rewards_earned: float = Field(..., description="Total rewards earned")
    avg_training_time: Optional[float] = Field(None, description="Average training time in seconds")
    avg_accuracy: Optional[float] = Field(None, description="Average model accuracy")
    last_heartbeat: Optional[datetime] = Field(None, description="Last heartbeat timestamp")
    uptime_percentage: float = Field(..., description="Node uptime percentage")
    hardware_specs: Optional[Dict[str, Any]] = Field(None, description="Hardware specifications")


class SessionMetricsResponse(BaseModel):
    """Schema for session metrics response."""
    session_id: str = Field(..., description="Session identifier")
    status: str = Field(..., description="Session status")
    current_round: int = Field(..., description="Current training round")
    total_rounds: int = Field(..., description="Total training rounds")
    active_participants: int = Field(..., description="Number of active participants")
    total_participants: int = Field(..., description="Total participants")
    avg_accuracy: Optional[float] = Field(None, description="Average model accuracy")
    avg_training_time: Optional[float] = Field(None, description="Average training time per round")
    total_rewards_distributed: float = Field(..., description="Total rewards distributed")
    created_at: datetime = Field(..., description="Session creation timestamp")
    completed_at: Optional[datetime] = Field(None, description="Session completion timestamp")


class P2PMetricsResponse(BaseModel):
    """Schema for P2P network metrics response."""
    total_connections: int = Field(..., description="Total active P2P connections")
    avg_latency_ms: float = Field(..., description="Average network latency in milliseconds")
    messages_per_second: float = Field(..., description="Messages processed per second")
    data_transferred_mb: float = Field(..., description="Data transferred in MB")
    active_peers: int = Field(..., description="Number of active peers")
    network_health_score: float = Field(..., description="Network health score (0-100)")
    connection_failures: int = Field(..., description="Number of connection failures in last hour")
    bandwidth_usage_mbps: float = Field(..., description="Current bandwidth usage in Mbps")


class SystemHealthResponse(BaseModel):
    """Schema for system health metrics response."""
    overall_status: str = Field(..., description="Overall system status")
    database_status: str = Field(..., description="Database health status")
    coordinator_status: str = Field(..., description="Coordinator service status")
    p2p_network_status: str = Field(..., description="P2P network status")
    active_nodes: int = Field(..., description="Number of active nodes")
    active_sessions: int = Field(..., description="Number of active sessions")
    total_memory_usage_mb: float = Field(..., description="Total memory usage in MB")
    total_cpu_usage_percent: float = Field(..., description="Total CPU usage percentage")
    disk_usage_percent: float = Field(..., description="Disk usage percentage")
    uptime_seconds: int = Field(..., description="System uptime in seconds")
    last_health_check: datetime = Field(..., description="Last health check timestamp")


class HistoricalMetricsResponse(BaseModel):
    """Schema for historical metrics response."""
    metric_type: str = Field(..., description="Type of metric")
    time_range: str = Field(..., description="Time range (e.g., '1h', '24h', '7d')")
    data_points: List[Dict[str, Any]] = Field(..., description="Historical data points")
    aggregation_type: str = Field(..., description="Aggregation type (avg, sum, max, min)")
    total_data_points: int = Field(..., description="Total number of data points")


class AggregatedMetricsResponse(BaseModel):
    """Schema for aggregated metrics response."""
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Metrics timestamp")
    node_metrics: Dict[str, Any] = Field(..., description="Aggregated node metrics")
    session_metrics: Dict[str, Any] = Field(..., description="Aggregated session metrics")
    p2p_metrics: Dict[str, Any] = Field(..., description="P2P network metrics")
    system_health: Dict[str, Any] = Field(..., description="System health metrics")
    performance_indicators: Dict[str, Any] = Field(..., description="Key performance indicators")


class MetricsQuery(BaseModel):
    """Schema for metrics query parameters."""
    start_time: Optional[datetime] = Field(None, description="Start time for historical data")
    end_time: Optional[datetime] = Field(None, description="End time for historical data")
    time_range: Optional[str] = Field(None, description="Time range (e.g., '1h', '24h', '7d')")
    aggregation: Optional[str] = Field("avg", description="Aggregation type")
    granularity: Optional[str] = Field("5m", description="Data granularity")
    filters: Optional[Dict[str, Any]] = Field(None, description="Additional filters")


# Reward Schemas
class RewardTransactionResponse(BaseModel):
    """Schema for reward transaction response."""
    id: str = Field(..., description="Transaction identifier")
    session_id: str = Field(..., description="Session identifier")
    node_id: str = Field(..., description="Node identifier")
    amount: float = Field(..., description="Reward amount in DRACMA")
    transaction_type: str = Field(..., description="Type of reward transaction")
    status: str = Field(..., description="Transaction status")
    blockchain_tx_hash: Optional[str] = Field(None, description="Blockchain transaction hash")
    created_at: datetime = Field(..., description="Transaction creation timestamp")
    processed_at: Optional[datetime] = Field(None, description="Transaction processing timestamp")


class RewardCalculationRequest(BaseModel):
    """Schema for reward calculation request."""
    session_id: str = Field(..., description="Session identifier")
    contribution_ids: List[int] = Field(..., description="List of contribution IDs to calculate rewards for")
    reward_pool_amount: float = Field(..., description="Total reward pool amount")
    calculation_method: str = Field("contribution_based", description="Reward calculation method")


class RewardDistributionResponse(BaseModel):
    """Schema for reward distribution response."""
    session_id: str = Field(..., description="Session identifier")
    total_distributed: float = Field(..., description="Total rewards distributed")
    transactions_count: int = Field(..., description="Number of reward transactions")
    distribution_method: str = Field(..., description="Distribution method used")
    distributed_at: datetime = Field(default_factory=datetime.utcnow, description="Distribution timestamp")


# Round Schemas
class RoundCreate(BaseModel):
    """Schema for creating a federated learning round."""
    session_id: str = Field(..., description="Session ID for the round")
    round_number: int = Field(..., description="Round number")
    total_participants: int = Field(..., description="Total expected participants")
    configuration: Optional[Dict[str, Any]] = Field(None, description="Round configuration")


class RoundUpdate(BaseModel):
    """Schema for updating a federated learning round."""
    status: Optional[str] = Field(None, description="Round status")
    progress_percentage: Optional[int] = Field(None, description="Progress percentage")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Round metrics")
    configuration: Optional[Dict[str, Any]] = Field(None, description="Round configuration")


class RoundResponse(BaseModel):
    """Schema for round response."""
    id: str = Field(..., description="Round identifier")
    session_id: str = Field(..., description="Session identifier")
    round_number: int = Field(..., description="Round number")
    status: str = Field(..., description="Round status")
    progress_percentage: int = Field(..., description="Progress percentage")
    active_participants: int = Field(..., description="Number of active participants")
    total_participants: int = Field(..., description="Total participants")
    estimated_completion: Optional[str] = Field(None, description="Estimated completion time")
    started_at: Optional[str] = Field(None, description="Round start time")
    completed_at: Optional[str] = Field(None, description="Round completion time")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Round metrics")
    created_at: str = Field(..., description="Round creation time")
    updated_at: str = Field(..., description="Round last update time")


class RoundParticipantResponse(BaseModel):
    """Schema for round participant response."""
    id: int = Field(..., description="Participant identifier")
    round_id: str = Field(..., description="Round identifier")
    node_id: str = Field(..., description="Node identifier")
    status: str = Field(..., description="Participant status")
    joined_at: Optional[datetime] = Field(None, description="Join timestamp")
    contributions_count: int = Field(..., description="Number of contributions")
    rewards_earned: float = Field(..., description="Rewards earned")
    performance_metrics: Optional[Dict[str, Any]] = Field(None, description="Performance metrics")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")