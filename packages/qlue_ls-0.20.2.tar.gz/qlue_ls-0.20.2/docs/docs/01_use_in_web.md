# 🌐 Use in web

If you want to connect from a web-based-editor, you can use this package as well.
For this purpose this can be compiled to wasm and is available on [npm](https://www.npmjs.com/package/@ioannisnezis/sparql-language-server):

```shell
npm i qlue-ls
```

You will have to wrap this in a Web Worker and provide a language server client.
There will be more documentation on this in the future...

Until then you can check out the demo in ./editor/
