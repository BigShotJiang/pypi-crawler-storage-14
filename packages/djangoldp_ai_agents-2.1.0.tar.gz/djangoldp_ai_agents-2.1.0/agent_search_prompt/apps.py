from django.apps import AppConfig


class AgentSearchPromptConfig(AppConfig):
    name = "agent_search_prompt"
    verbose_name = "AI Agent - Search Prompt"
