from django.apps import AppConfig


class Agent3DSummarizeConfig(AppConfig):
    name = "agent_3d_summarize"
    verbose_name = "AI Agent - 3D summarize"
