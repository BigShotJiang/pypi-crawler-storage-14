__version__ = "2.1.0"
name = "djangoldp_ai_agents"
