//! Contains serializable models of different data structures.

pub mod v5;
pub mod v6;
