//! Functionality to stream and extract packages in an [`tokio`] async context.

pub mod async_read;
pub mod fs;
