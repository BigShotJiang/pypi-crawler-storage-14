//! Functionality to stream and extract packages directly from a [`reqwest::Url`].
pub mod tokio;
