use rattler_macros::sorted;

#[sorted]
pub enum Alphabet {
    A,
    BBB,
    C,
    XYZ,
    Z
}

fn main() {}
