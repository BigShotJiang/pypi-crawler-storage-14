// Main integration test entry point
mod integration;
