//! This module contains CLI common components used in various sub-projects
//! (like pixi, rattler-build).
pub mod auth;
