# LinkError

::: rattler.exceptions.LinkError
