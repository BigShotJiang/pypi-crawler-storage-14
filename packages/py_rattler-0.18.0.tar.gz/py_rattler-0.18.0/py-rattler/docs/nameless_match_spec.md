# NamelessMatchSpec

::: rattler.match_spec.nameless_match_spec
