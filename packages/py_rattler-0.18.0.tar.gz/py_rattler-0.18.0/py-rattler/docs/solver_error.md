# solver_error

::: rattler.exceptions.SolverError
