# PathType

::: rattler.package.paths_json.PathType
