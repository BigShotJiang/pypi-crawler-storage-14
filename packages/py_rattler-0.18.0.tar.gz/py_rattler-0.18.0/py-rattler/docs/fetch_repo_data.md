# fetch_repo_data

::: rattler.networking.fetch_repo_data
