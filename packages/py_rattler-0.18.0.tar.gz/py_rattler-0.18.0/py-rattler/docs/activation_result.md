# ActivationResult

::: rattler.shell.shell.ActivationResult
