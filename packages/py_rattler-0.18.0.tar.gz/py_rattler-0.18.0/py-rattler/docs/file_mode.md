# FileMode

::: rattler.package.paths_json.FileMode
