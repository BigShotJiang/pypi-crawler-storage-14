# FetchRepoDataError

::: rattler.exceptions.FetchRepoDataError
