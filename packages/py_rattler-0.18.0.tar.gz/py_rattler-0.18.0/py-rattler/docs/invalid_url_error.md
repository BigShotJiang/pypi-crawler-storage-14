# InvalidUrlError

::: rattler.exceptions.InvalidUrlError
