# PathsEntry

::: rattler.package.paths_json.PathsEntry
