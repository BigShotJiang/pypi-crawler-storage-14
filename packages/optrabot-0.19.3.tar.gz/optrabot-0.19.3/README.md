# OptraBot
OptraBot is a Options Trading Bot which can be used to run fully automated options trading strategies using your Interactive Brokers trading account.

Have a look on the **[Roadmap](https://app.loopedin.io/optrabot/roadmap)** and discover what we're currently working on and whats coming next.

Run through the **[Changelog](https://app.loopedin.io/optrabot/#/updates)** and find out about the most recent updates of the software.

## System requirements
Microsoft Windows, MacOS or Linux operating system

Python 3.10 or newer

Interactive Brokers Trader Workstation or IB Gateway

## Installation

### UV Package Manager
OptraBot uses the Python Package Manager UV from Astral (https://docs.astral.sh/uv/).

1. Install UV using the following command depending on your operating system:

Windows: `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"`

MacOS/Linux: `curl -LsSf https://astral.sh/uv/install.sh | sh`

This will download and automatically install UV.

2. Check the version with command: `uv version`

### OptraBot

Now install and run the OptraBot by using the following command: `uv tool run optrabot`

The same command is used to run the OptraBot later on.

## Updating

The OptraBot got a auto-update functionality integrated. There is no need to update it manually.

The UV Package Manager can be updated with the command `uv self update`

## Disclaimer
Be aware that you're using this software at your own risk. The author is not liable for any losses occuring with using this software.
