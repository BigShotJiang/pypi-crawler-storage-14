"use strict";sap.ui.define(["./HelloJourney"],function(e){"use strict"});
//# sourceMappingURL=opaTests.qunit.js.map