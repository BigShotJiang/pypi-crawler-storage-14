"use strict";

sap.ui.define(["./HelloJourney"], function (___HelloJourney) {
  "use strict";
});
//# sourceMappingURL=opaTests.qunit-dbg.js.map
