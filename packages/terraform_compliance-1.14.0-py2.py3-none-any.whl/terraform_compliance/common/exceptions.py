

class TerraformComplianceInvalidConfig(Exception):
    pass


class TerraformComplianceInvalidConfigurationType(Exception):
    pass


class Failure(Exception):
    pass


class TerraformComplianceNotImplemented(Exception):
    pass


class TerraformComplianceInternalFailure(Exception):
    pass


class TerraformComplianceInvalidData(Exception):
    pass
