import sys

from .main import cli

sys.exit(cli())
