__app_name__ = 'terraform-compliance'
__version__ = '1.14.0' if not '1.14.0'.startswith('{') else '0.0.0'
