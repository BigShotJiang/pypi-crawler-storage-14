"""Meld CLI - Main entry point."""

import asyncio
import json
import webbrowser
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .api import MeldAPI, MeldAPIError
from .config import (
    clear_credentials,
    get_api_url,
    load_credentials,
    save_credentials,
)

console = Console()


@click.group()
@click.version_option()
def cli():
    """Meld - Personal memory system for Claude Code."""
    pass


@cli.command()
def login():
    """Log in to Meld via browser."""
    console.print(Panel.fit("[bold]Meld Login[/bold]"))

    # Check if already logged in
    creds = load_credentials()
    if creds:
        console.print(f"[yellow]Already logged in as {creds.get('email', 'unknown')}[/yellow]")
        if not click.confirm("Log in again?", default=False):
            return

    # Open the sign-in page served by the API
    signin_url = f"{get_api_url()}/signin"

    console.print(f"\n[bold]Opening browser for sign-in...[/bold]")
    webbrowser.open(signin_url)

    console.print(f"Opened: {signin_url}\n")
    console.print("Sign in and copy the token shown on the page.")
    console.print("")

    token = click.prompt("Paste your Clerk session token")

    if not token:
        console.print("[red]No token provided[/red]")
        return

    # Exchange the short-lived Clerk token for a long-lived Meld token
    api = MeldAPI(token=token)

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Exchanging token...", total=None)
            result = asyncio.run(api.exchange_token())
            progress.remove_task(task)

        if "error" in result:
            console.print(f"[red]Error: {result.get('error')}[/red]")
            return

        # Save the long-lived Meld token
        save_credentials(
            token=result.get("access_token", ""),
            user_id=result.get("user_id", ""),
            email=result.get("email", ""),
        )

        expires_days = result.get("expires_in", 0) // 86400
        console.print(f"\n[green]✓[/green] Logged in as {result.get('email', 'user')}")
        console.print(f"[dim]Token valid for {expires_days} days[/dim]")

    except MeldAPIError as e:
        console.print(f"[red]Login failed: {e.message}[/red]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


@cli.command()
def logout():
    """Log out and clear credentials."""
    clear_credentials()
    console.print("[green]✓[/green] Logged out successfully")


@cli.command()
def status():
    """Check Meld status and connection."""
    creds = load_credentials()

    console.print(Panel.fit("[bold]Meld Status[/bold]"))

    # Check credentials
    if creds:
        console.print(f"[green]✓[/green] Logged in as: {creds.get('email', 'unknown')}")
    else:
        console.print("[yellow]⚠[/yellow] Not logged in. Run [bold]meld login[/bold]")
        return

    # Check API connection
    api = MeldAPI()

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Checking API connection...", total=None)
            health = asyncio.run(api.health_check())
            progress.remove_task(task)

        if health.get("status") == "healthy":
            console.print(f"[green]✓[/green] API: Connected ({get_api_url()})")
        else:
            console.print(f"[yellow]⚠[/yellow] API: {health}")
    except Exception as e:
        console.print(f"[red]✗[/red] API: Connection failed - {e}")
        return

    # Get user state
    try:
        state = asyncio.run(api.get_user_state())
        console.print(f"\n[bold]User State:[/bold] {state.get('state')}")
        console.print(f"  Projects: {state.get('content_counts', {}).get('projects', 0)}")
        console.print(f"  Memories: {state.get('content_counts', {}).get('memories', 0)}")

        if state.get("checkin_info", {}).get("suggested"):
            console.print(
                f"\n[yellow]ℹ[/yellow] Check-in suggested: {state.get('greeting')}"
            )
    except MeldAPIError as e:
        console.print(f"[red]✗[/red] Failed to get user state: {e.message}")


@cli.command()
def setup():
    """Configure Claude Code to use Meld."""
    console.print(Panel.fit("[bold]Meld Setup for Claude Code[/bold]"))

    # Check if logged in
    creds = load_credentials()
    if not creds:
        console.print("[yellow]⚠[/yellow] Not logged in. Run [bold]meld login[/bold] first.")
        return

    # Find Claude settings
    claude_settings_dir = Path.home() / ".claude"
    claude_settings_file = claude_settings_dir / "settings.json"

    if not claude_settings_dir.exists():
        console.print("[yellow]⚠[/yellow] Claude Code not detected (~/.claude not found)")
        console.print("Make sure Claude Code is installed and has been run at least once.")
        return

    console.print(f"[green]✓[/green] Found Claude Code at {claude_settings_dir}")

    # Load existing settings
    settings = {}
    if claude_settings_file.exists():
        try:
            settings = json.loads(claude_settings_file.read_text())
            console.print("[green]✓[/green] Loaded existing Claude settings")
        except Exception:
            console.print("[yellow]⚠[/yellow] Could not parse existing settings, creating new")

    # Add MCP server config
    if "mcpServers" not in settings:
        settings["mcpServers"] = {}

    # Check if meld is already configured
    if "meld" in settings.get("mcpServers", {}):
        console.print("[green]✓[/green] Meld MCP server already configured")
        if not click.confirm("Update configuration?", default=False):
            return

    # Configure Meld MCP server
    meld_config = {
        "command": "python",
        "args": ["-m", "meld_mcp"],
        "env": {
            "MELD_API_URL": get_api_url(),
        },
    }

    settings["mcpServers"]["meld"] = meld_config

    # Write settings
    claude_settings_file.write_text(json.dumps(settings, indent=2))
    console.print("[green]✓[/green] Updated Claude Code settings")

    # Add session hook for meld_hello
    console.print("\n[bold]Adding session hook...[/bold]")

    hooks = settings.get("hooks", {})
    if "UserPromptSubmit" not in hooks:
        hooks["UserPromptSubmit"] = []

    # Check if meld hook already exists
    meld_hook_exists = any(
        "meld" in str(hook.get("hooks", [])).lower()
        for hook in hooks.get("UserPromptSubmit", [])
    )

    if not meld_hook_exists:
        # Add meld session hook
        hooks["UserPromptSubmit"].append({
            "hooks": [
                {
                    "type": "command",
                    "command": "python -m meld_mcp.hooks",
                    "timeout": 5,
                }
            ]
        })
        settings["hooks"] = hooks
        claude_settings_file.write_text(json.dumps(settings, indent=2))
        console.print("[green]✓[/green] Added session hook")
    else:
        console.print("[green]✓[/green] Session hook already configured")

    console.print("\n[bold green]Setup complete![/bold green]")
    console.print("\nRestart Claude Code to activate Meld.")
    console.print("On first prompt, Meld will greet you and offer onboarding.")


@cli.command()
def whoami():
    """Show current user info."""
    creds = load_credentials()
    if not creds:
        console.print("Not logged in. Run [bold]meld login[/bold]")
        return

    console.print(f"Email: {creds.get('email')}")
    console.print(f"User ID: {creds.get('user_id')}")


if __name__ == "__main__":
    cli()
