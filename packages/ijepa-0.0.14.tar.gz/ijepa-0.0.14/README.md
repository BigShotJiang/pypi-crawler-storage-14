# ijepa
An easy implementation of Image Joint Embedding Predictive Architecture. 
