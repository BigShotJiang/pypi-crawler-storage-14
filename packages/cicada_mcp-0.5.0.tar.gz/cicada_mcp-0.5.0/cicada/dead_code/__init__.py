"""Dead code analysis module - finds and analyzes unused code in Elixir projects."""
