"""Tests for supernote package."""


def test_placeholder() -> None:
    """A placeholder test to ensure the test suite runs."""
    assert True
