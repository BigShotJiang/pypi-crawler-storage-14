"""Semantico - Ontologia Core - Camada Semântica."""

from .core import (
    CONSTRAINT_REGISTRY,
    Archetype,
    Cardinality,
    Constraint,
    Interface,
    Length,
    Link,
    LinkDescriptor,
    LinkManager,
    Logic,
    Object,
    Property,
    Range,
    Regex,
    VirtualObject,
    clear_kernel,
    get_constraint_registry,
    get_kernel,
    reconstruct_constraint,
    set_kernel,
)

__all__ = [
    # Dependency Injection
    "clear_kernel",
    "get_kernel",
    "set_kernel",
    # Constraints
    "CONSTRAINT_REGISTRY",
    "Constraint",
    "Length",
    "Range",
    "Regex",
    "get_constraint_registry",
    "reconstruct_constraint",
    # Core Classes
    "Archetype",
    "Cardinality",
    "Interface",
    "Link",
    "LinkDescriptor",
    "LinkManager",
    "Logic",
    "Object",
    "Property",
    "VirtualObject",
]

__version__ = "0.4.2"
