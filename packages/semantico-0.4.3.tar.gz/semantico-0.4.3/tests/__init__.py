"""Testes para o módulo semantico."""
