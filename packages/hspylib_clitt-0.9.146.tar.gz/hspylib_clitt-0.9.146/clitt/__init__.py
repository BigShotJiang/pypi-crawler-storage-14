# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt
"""Package initialization."""

__all__ = [
    'addons', 
    'core', 
    'utils'
]
__version__ = '0.9.146'
