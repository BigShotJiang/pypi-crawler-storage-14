# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.addons
"""Package initialization."""

__all__ = [
    'appman', 
    'widman'
]
__version__ = '0.9.146'
