# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.addons.widman.widgets
"""Package initialization."""

__all__ = [
    'widget_free', 
    'widget_punch', 
    'widget_send_msg', 
    'widget_time_calc'
]
__version__ = '0.9.146'
