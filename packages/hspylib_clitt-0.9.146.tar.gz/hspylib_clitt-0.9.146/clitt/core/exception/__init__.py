# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.core.exception
"""Package initialization."""

__all__ = [
    'exceptions'
]
__version__ = '0.9.146'
