# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.core.icons.emojis
"""Package initialization."""

__all__ = [
    'emojis', 
    'face_smiling'
]
__version__ = '0.9.146'
