# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.core.icons.font_awesome
"""Package initialization."""

__all__ = [
    'app_icons', 
    'awesome', 
    'dashboard_icons', 
    'form_icons', 
    'game_icons', 
    'nav_icons', 
    'trickplay_icons', 
    'widget_icons'
]
__version__ = '0.9.146'
