# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.core.tui.mchoose
"""Package initialization."""

__all__ = [
    'mchoose', 
    'menu_choose'
]
__version__ = '0.9.146'
