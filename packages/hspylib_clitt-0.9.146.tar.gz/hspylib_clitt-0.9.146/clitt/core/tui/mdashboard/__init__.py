# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.core.tui.mdashboard
"""Package initialization."""

__all__ = [
    'dashboard_builder', 
    'dashboard_item', 
    'mdashboard', 
    'menu_dashboard'
]
__version__ = '0.9.146'
