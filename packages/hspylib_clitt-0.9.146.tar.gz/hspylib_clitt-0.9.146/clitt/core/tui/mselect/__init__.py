# _*_ coding: utf-8 _*_
#
# hspylib-clitt v0.9.146
#
# Package: main.clitt.core.tui.mselect
"""Package initialization."""

__all__ = [
    'menu_select', 
    'mselect'
]
__version__ = '0.9.146'
