import asyncio
import logging
import os
import sys
from email.policy import default
from typing import Annotated

import click
from mcp.server.fastmcp import Context, FastMCP
from mcp.server.session import ServerSession
from pydantic import BaseModel, Field, model_validator
from pydantic.fields import FieldInfo

from huayi_mcp_server.sdk.huajitong import Huajitong
from huayi_mcp_server.sdk.models import UserNumDetailOutput

logger = logging.getLogger(__name__)



class ToolSet:

    def __init__(self, name: str, log_level: str, base_url: str, token: str):
        self.mcp = FastMCP(name=name)
        self.mcp.settings.log_level = log_level.upper()
        self.base_url = base_url
        self.token = token
        self.huajitong_client = Huajitong(base_url=self.base_url, token=self.token)

        @self.mcp.tool(
            name="查询给定用户自配送次数",
            title="查询给定用户自配送次数",
            description="查询给定用户自配送次数",
            structured_output=True,
        )
        async def get_user_num_detail(ctx: Context[ServerSession, None], user_identifier: Annotated[str, Field(title="用户标识", description="用户标识, 可能是 userId 或 userPhone", default=None)]) -> UserNumDetailOutput | str:
            """查询给定用户自配送次数"""

            await ctx.info(f"get_user_num_detail's input: {user_identifier}")

            # todo: handle error
            return self.huajitong_client.get_user_num_detail(user_identifier=user_identifier)

    def run_on_stdio(self):
        self.mcp.run(transport="stdio")

    def run_on_streamable_http(self):
        self.mcp.run(transport="streamable-http")

    def run_on_sse(self):
        self.mcp.run(transport="sse")


@click.command()
@click.option(
    "--transport",
    default="stdio",
    help="MCP transport: stdio, streamable-http, sse",
)
@click.option(
    "--log-level",
    default="INFO",
    help="Log level: DEBUG, INFO, WARNING, ERROR",
)
def main(transport: str | None, log_level: str | None) -> int:
    """Run the MCP Server."""
    transport = transport if transport else "stdio"
    log_level = log_level if log_level else "INFO"

    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    base_url = os.getenv("BASE_URL", "https://e-api.huaji.com")
    token = os.getenv("HUAJITONG_TOKEN", None)
    if not token:
        raise Exception("Token is not provided")
        sys.exit(1)

    logger.info(f"Starting MCP Server")

    toolset = ToolSet(name="Huayi MCP", log_level=log_level, base_url=base_url, token=token)
    host = toolset.mcp.settings.host
    port = toolset.mcp.settings.port
    streamable_http_path = toolset.mcp.settings.streamable_http_path
    sse_path = toolset.mcp.settings.sse_path

    try:
        if transport.lower() == "streamable-http":
            logger.info(f"StreamableHTTP endpoint will be: http://{host}:{port}{streamable_http_path}")
            toolset.run_on_streamable_http()

        if transport.lower() == "sse":
            logger.info(f"SSE endpoint will be: http://{host}:{port}{sse_path}")
            toolset.run_on_sse()

        if transport.lower() == "stdio":
            logger.info(f"MCP Server will run on Stdio")
            toolset.run_on_stdio()

    except KeyboardInterrupt:
        logger.info("received Ctrl-C, shutting down...")

    return 0


if __name__ == "__main__":
    main()
