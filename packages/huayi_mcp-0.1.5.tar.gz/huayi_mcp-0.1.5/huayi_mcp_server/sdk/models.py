from pydantic import BaseModel, Field


class UserNumDetailOutput(BaseModel):
    user_id: str = Field(title="用户Id", alias="userId", description="用户标识 用户ID userId")
    user_phone: str = Field(title="用户手机号码", alias="userPhone",
                            description="用户手机号码 可作为用户标识 userPhone")

    """会员自配送次数"""
    member_expire_num: int = Field(
        title="会员自配送次数",
        alias="memberExpireNum",
        description="会员自配送次数",
        json_schema_extra={"x-display-name": "自配送次数"},
    )

    """其他自配送次数"""
    other_num: int = Field(title="其他自配送次数", alias="otherNum", description="其他自配送次数")

    class Config:
        populate_by_name = True
