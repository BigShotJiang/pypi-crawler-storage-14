class SDK(object):
    def __init__(self,base_url: str, token: str, **kwargs):
        self.base_url = base_url
        self.token = token
        self.headers = {
            'Content-Type': 'application/json',
            'Access-Control-Request-Headers': 'Content-Type,Token',
            'Token': self.token,
        }
