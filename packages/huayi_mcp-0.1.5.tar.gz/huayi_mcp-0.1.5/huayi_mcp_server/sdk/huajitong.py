import httpx
from functools import wraps
from pydantic import BaseModel, Field

from huayi_mcp_server.sdk import SDK
from huayi_mcp_server.sdk.models import UserNumDetailOutput


class Huajitong(SDK):

    @staticmethod
    def check_credentials(func):
        """检查 base_url 和 token 是否有效的装饰器"""
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            if not self.base_url or not self.token:
                return None
            return func(self, *args, **kwargs)
        return wrapper

    @check_credentials
    def get_user_num_detail(self, user_identifier: str) -> UserNumDetailOutput | str:
        url = self.base_url + "/performanceBond/admin/get-user-num-detail"
        response = httpx.post(url, headers=self.headers, json={"value": user_identifier})
        if response.status_code != 200:
            return f"response {response.status_code}"

        json_data = response.json()
        print("get_user_num_detail response content:\n")
        print(json_data)

        if json_data.get("code") != 200:
            code = json_data.get("code")
            msg = json_data.get("msg")
            return f"response {code}: {msg}"

        json_data = json_data.get("data")
        return UserNumDetailOutput.model_validate(json_data)
