from __future__ import annotations

from videodataset.dataset.base_dataset import BaseVideoDataset

__all__ = ["BaseVideoDataset"]
