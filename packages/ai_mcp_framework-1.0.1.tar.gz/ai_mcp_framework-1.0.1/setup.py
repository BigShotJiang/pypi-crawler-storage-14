from setuptools import setup, find_packages

setup(
    name="ai-mcp-framework",
    version="1.0.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "fastmcp>=0.1.0",
        "google-genai>=0.1.0",
        "asyncpg>=0.29.0",
        "PyJWT>=2.8.0",
        "cachetools>=5.3.0",
        "httpx>=0.25.0",
    ],
    python_requires=">=3.9",
)