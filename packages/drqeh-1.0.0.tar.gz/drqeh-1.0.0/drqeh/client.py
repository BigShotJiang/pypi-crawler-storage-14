import requests

API_URL = "https://digirakshaquantumencription.onrender.com/encrypt"

def encrypt(password: str) -> str:
    """
    DigiRaksha Quantum Encryption Hasher (DQEH) – Python SDK
    This function sends the password to your API and returns encrypted output.
    """
    try:
        response = requests.post(API_URL, json={"password": password})
        response.raise_for_status()

        data = response.json()
        return data.get("encrypted")

    except Exception as e:
        raise Exception(f"DQEH API Error: {str(e)}")
