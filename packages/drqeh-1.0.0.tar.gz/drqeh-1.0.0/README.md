# DQEH – DigiRaksha Quantum Encryption Hasher (Python SDK)

This SDK allows developers to use DigiRaksha Quantum Encryption Hasher
directly in Python by calling the official DigiRaksha API.

### Install

pip install drqeh

### Usage

from drqeh import encrypt

result = encrypt("Pass@123")
print(result)
Output:

arduino
Copy code
4a9f0c3e24ac... (256-bit hash)
What is DQEH?
DQEH is a quantum–inspired, chaos–driven, irreversible one-way hasher algorithm
developed under DigiRaksha.
