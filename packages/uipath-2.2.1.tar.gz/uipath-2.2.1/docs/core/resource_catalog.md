::: uipath._services.resource_catalog_service
