# Authors

The following individuals have contributed to **vba_edit**.

## Project Maintainer
- **Markus Killer** – creator and maintainer

## Major Contributors
- **onderhold** – support for RubberduckVBA & much more

## Other Contributors
(Automatically tracked in the [GitHub contributors graph](https://github.com/markuskiller/vba-edit/graphs/contributors))

---

💡 *If you contribute to this project and would like to be listed here, please open a pull request adding your name.*
