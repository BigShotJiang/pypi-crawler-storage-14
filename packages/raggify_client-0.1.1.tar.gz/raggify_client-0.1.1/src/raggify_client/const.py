from __future__ import annotations

PROJECT_BASE_NAME: str = "raggify"
PROJECT_NAME: str = f"{PROJECT_BASE_NAME}-client"
VERSION: str = "0.1.1"
USER_CONFIG_PATH: str = f"/etc/{PROJECT_NAME}/config.yaml"
