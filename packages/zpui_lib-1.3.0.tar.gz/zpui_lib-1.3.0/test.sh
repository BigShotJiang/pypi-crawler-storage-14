#!/usr/bin/env sh
cd src/zpui_lib
./test.sh
