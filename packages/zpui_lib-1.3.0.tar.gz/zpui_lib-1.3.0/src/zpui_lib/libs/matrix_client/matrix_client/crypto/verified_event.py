class VerifiedEvent(dict):
    pass
