#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
from setuptools import setup, find_packages

from mecho import help

setup(
    name="mecho",
    version=help.get_version(),
    author="qicongsheng",
    author_email="qicongsheng@outlook.com",
    description="mecho",
    url="https://github.com/qicongsheng/mecho",
    packages=find_packages(),
    package_data={
        "mecho": ["templates/*", "static/*", "static/*/*"]
    },
    install_requires=[
        "flask==2.3.3",
        "flask-socketio==5.3.6",
        "python-socketio[client]==5.10.0",
        "requests==2.31.0"
    ],
    entry_points={
        "console_scripts": [
            "mecho-server=mecho.server:start",
            "mecho-client=mecho.client:start",
        ]
    }
)
