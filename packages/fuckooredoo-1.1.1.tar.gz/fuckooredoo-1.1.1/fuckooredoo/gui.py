#gui.py

import customtkinter as ctk
from tkinter import filedialog, messagebox
import threading
import os
import subprocess
import time
import math
from typing import Optional, Dict, List
from .torrent_client import TorrentClient
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============== THEME & COLORS ==============
class AppTheme:
    """Professional color theme for the application - Blue Theme"""
    # Primary colors - Blue
    PRIMARY = "#2196F3"          # Blue
    PRIMARY_HOVER = "#1976D2"
    PRIMARY_DARK = "#0D47A1"
    
    # Accent colors
    ACCENT = "#10B981"           # Emerald green
    ACCENT_HOVER = "#059669"
    WARNING = "#F59E0B"          # Amber
    DANGER = "#EF4444"           # Red
    DANGER_HOVER = "#DC2626"
    
    # Background colors
    BG_DARK = "#0A0A0F"
    BG_CARD = "#0F1724"
    BG_CARD_HOVER = "#1A2332"
    BG_SURFACE = "#0D1520"
    BG_INPUT = "#080D14"
    
    # Text colors
    TEXT_PRIMARY = "#FFFFFF"
    TEXT_SECONDARY = "#94A3B8"
    TEXT_MUTED = "#64748B"
    
    # Status colors
    STATUS_SUCCESS = "#22C55E"
    STATUS_WARNING = "#FBBF24"
    STATUS_ERROR = "#F87171"
    STATUS_INFO = "#38BDF8"
    
    # Gradient-like colors for progress
    PROGRESS_START = "#2196F3"
    PROGRESS_END = "#03A9F4"
    
    # Border colors
    BORDER_DEFAULT = "#1E3A5F"
    BORDER_ACTIVE = "#2196F3"


# ============== ANIMATED COMPONENTS ==============
class AnimatedProgressBar(ctk.CTkFrame):
    """Custom animated progress bar with gradient effect and glow"""
    
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        
        self.progress = 0.0
        self.target_progress = 0.0
        self.animation_speed = 0.05
        self.is_animating = False
        self.pulse_phase = 0
        self.is_active = False
        
        # Background track
        self.track = ctk.CTkFrame(
            self,
            height=12,
            corner_radius=6,
            fg_color=AppTheme.BG_INPUT,
            border_width=1,
            border_color=AppTheme.BORDER_DEFAULT
        )
        self.track.pack(fill="x", expand=True)
        
        # Progress fill
        self.fill = ctk.CTkFrame(
            self.track,
            height=10,
            corner_radius=5,
            fg_color=AppTheme.PRIMARY
        )
        self.fill.place(x=1, y=1, relwidth=0, relheight=1)
        
        # Percentage label overlay
        self.percentage_label = ctk.CTkLabel(
            self.track,
            text="0%",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        self.percentage_label.place(relx=0.5, rely=0.5, anchor="center")
        
    def set(self, value: float, animate: bool = True):
        """Set progress value (0.0 to 1.0)"""
        self.target_progress = max(0.0, min(1.0, value))
        self.is_active = value > 0 and value < 1.0
        
        if animate and not self.is_animating:
            self._animate_progress()
        elif not animate:
            self.progress = self.target_progress
            self._update_display()
    
    def _animate_progress(self):
        """Smooth animation for progress changes"""
        self.is_animating = True
        
        diff = self.target_progress - self.progress
        if abs(diff) < 0.001:
            self.progress = self.target_progress
            self.is_animating = False
            self._update_display()
            return
        
        # Easing function for smooth animation
        self.progress += diff * 0.15
        self._update_display()
        
        self.after(16, self._animate_progress)  # ~60 FPS
    
    def _update_display(self):
        """Update visual display"""
        # Update fill width
        self.fill.place(x=1, y=1, relwidth=max(0.01, self.progress), relheight=1)
        
        # Update percentage text
        percentage = int(self.progress * 100)
        self.percentage_label.configure(text=f"{percentage}%")
        
        # Change color based on progress
        if self.progress >= 1.0:
            self.fill.configure(fg_color=AppTheme.STATUS_SUCCESS)
        elif self.progress > 0.7:
            self.fill.configure(fg_color="#03A9F4")  # Light Blue
        elif self.progress > 0.3:
            self.fill.configure(fg_color=AppTheme.PRIMARY)
        else:
            self.fill.configure(fg_color="#0288D1")  # Dark Blue


class PulsingIndicator(ctk.CTkFrame):
    """Animated pulsing status indicator"""
    
    def __init__(self, master, size=12, color=AppTheme.STATUS_SUCCESS, **kwargs):
        super().__init__(master, fg_color="transparent", width=size+10, height=size+10, **kwargs)
        
        self.size = size
        self.base_color = color
        self.pulse_phase = 0
        self.is_pulsing = False
        
        # Glow effect (outer circle)
        self.glow = ctk.CTkFrame(
            self,
            width=size + 6,
            height=size + 6,
            corner_radius=(size + 6) // 2,
            fg_color=self._adjust_alpha(color, 0.3)
        )
        self.glow.place(relx=0.5, rely=0.5, anchor="center")
        
        # Main indicator (inner circle)
        self.indicator = ctk.CTkFrame(
            self,
            width=size,
            height=size,
            corner_radius=size // 2,
            fg_color=color
        )
        self.indicator.place(relx=0.5, rely=0.5, anchor="center")
    
    def _adjust_alpha(self, hex_color, alpha):
        """Create a color with adjusted brightness to simulate alpha"""
        # Convert hex to RGB
        hex_color = hex_color.lstrip('#')
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        # Darken to simulate alpha on dark background
        r = int(r * alpha)
        g = int(g * alpha)
        b = int(b * alpha)
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def set_color(self, color):
        """Update indicator color"""
        self.base_color = color
        self.indicator.configure(fg_color=color)
        self.glow.configure(fg_color=self._adjust_alpha(color, 0.3))
    
    def start_pulse(self):
        """Start pulsing animation"""
        if not self.is_pulsing:
            self.is_pulsing = True
            self._pulse()
    
    def stop_pulse(self):
        """Stop pulsing animation"""
        self.is_pulsing = False
    
    def _pulse(self):
        """Pulsing animation loop"""
        if not self.is_pulsing:
            return
        
        self.pulse_phase = (self.pulse_phase + 0.1) % (2 * math.pi)
        scale = 1.0 + 0.2 * math.sin(self.pulse_phase)
        
        new_size = int(self.size * scale)
        glow_size = new_size + 6
        
        self.indicator.configure(width=new_size, height=new_size, corner_radius=new_size // 2)
        self.glow.configure(width=glow_size, height=glow_size, corner_radius=glow_size // 2)
        
        self.after(50, self._pulse)


class ToastNotification(ctk.CTkFrame):
    """Modern toast notification that slides in and out"""
    
    def __init__(self, master, message: str, toast_type: str = "info", duration: int = 3000, **kwargs):
        super().__init__(master, corner_radius=12, **kwargs)
        
        self.duration = duration
        self.master_widget = master
        
        # Set colors based on type
        colors = {
            "success": (AppTheme.STATUS_SUCCESS, "✓"),
            "error": (AppTheme.STATUS_ERROR, "✕"),
            "warning": (AppTheme.STATUS_WARNING, "⚠"),
            "info": (AppTheme.STATUS_INFO, "ℹ"),
        }
        color, icon = colors.get(toast_type, colors["info"])
        
        self.configure(fg_color=AppTheme.BG_CARD, border_width=2, border_color=color)
        
        # Icon
        icon_label = ctk.CTkLabel(
            self,
            text=icon,
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=color,
            width=30
        )
        icon_label.pack(side="left", padx=(15, 5), pady=12)
        
        # Message
        msg_label = ctk.CTkLabel(
            self,
            text=message,
            font=ctk.CTkFont(size=13),
            text_color=AppTheme.TEXT_PRIMARY
        )
        msg_label.pack(side="left", padx=(5, 15), pady=12)
        
        # Close button
        close_btn = ctk.CTkButton(
            self,
            text="×",
            width=25,
            height=25,
            corner_radius=12,
            fg_color="transparent",
            hover_color=AppTheme.BG_CARD_HOVER,
            text_color=AppTheme.TEXT_MUTED,
            font=ctk.CTkFont(size=16),
            command=self._dismiss
        )
        close_btn.pack(side="right", padx=(5, 10), pady=8)
        
        # Position off-screen initially
        self.place(relx=0.5, y=-100, anchor="n")
        
        # Animate in
        self.after(10, self._slide_in)
    
    def _slide_in(self, y=None):
        """Slide in animation"""
        if y is None:
            y = -100
        
        if y < 20:
            y += 10
            self.place(relx=0.5, y=y, anchor="n")
            self.after(10, lambda: self._slide_in(y))
        else:
            # Schedule auto-dismiss
            self.after(self.duration, self._dismiss)
    
    def _dismiss(self, y=None):
        """Slide out and destroy"""
        if y is None:
            y = 20
        
        if y > -100:
            y -= 15
            self.place(relx=0.5, y=y, anchor="n")
            self.after(10, lambda: self._dismiss(y))
        else:
            self.destroy()


class SpeedGraph(ctk.CTkFrame):
    """Mini speed graph showing download history"""
    
    def __init__(self, master, width=100, height=30, **kwargs):
        super().__init__(master, fg_color=AppTheme.BG_INPUT, corner_radius=4, 
                        width=width, height=height, **kwargs)
        
        self.width_val = width
        self.height_val = height
        self.history: List[float] = [0] * 20
        self.max_speed = 1.0
        
        # Create canvas for drawing
        from tkinter import Canvas
        self.canvas = Canvas(
            self,
            width=width - 4,
            height=height - 4,
            bg="#0D1B2A",
            highlightthickness=0
        )
        self.canvas.place(x=2, y=2)
    
    def add_point(self, speed: float):
        """Add a new speed point to the graph"""
        self.history.append(speed)
        if len(self.history) > 20:
            self.history.pop(0)
        
        self.max_speed = max(max(self.history), 0.1)
        self._redraw()
    
    def _redraw(self):
        """Redraw the speed graph"""
        self.canvas.delete("all")
        
        w = self.width_val - 4
        h = self.height_val - 6
        
        if len(self.history) < 2:
            return
        
        # Calculate points
        points = []
        for i, speed in enumerate(self.history):
            x = int(i * w / (len(self.history) - 1))
            y = int(h - (speed / self.max_speed) * h) + 2
            points.append((x, y))
        
        # Draw filled area
        area_points = [(0, h + 2)] + points + [(w, h + 2)]
        self.canvas.create_polygon(
            area_points,
            fill="#1E3A5F",
            outline=""
        )
        
        # Draw line
        if len(points) >= 2:
            flat_points = [coord for point in points for coord in point]
            self.canvas.create_line(
                flat_points,
                fill=AppTheme.PRIMARY,
                width=2,
                smooth=True
            )


# Native file chooser helpers: prefer GTK (PyGObject) on Zorin/Ubuntu, fall back to zenity, then tkinter
def _choose_directory_native(title: str, mustexist: bool = False):
    """Return a directory path selected using the native OS dialog.
    Tries GTK via PyGObject first, then zenity, then tkinter.filedialog.
    """
    # 1) Try PyGObject (GTK)
    try:
        from gi.repository import Gtk  # type: ignore

        dialog = Gtk.FileChooserDialog(title=title, parent=None, action=Gtk.FileChooserAction.SELECT_FOLDER,
                                       buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        dialog.set_select_multiple(False)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            path = dialog.get_filename()
        else:
            path = None
        dialog.destroy()
        return path
    except Exception:
        pass

    # 2) Try zenity (good fallback on many Linux desktops)
    try:
        zenity_cmd = ["zenity", "--file-selection", "--directory", "--title", title]
        p = subprocess.run(zenity_cmd, capture_output=True, text=True)
        if p.returncode == 0:
            return p.stdout.strip()
    except Exception:
        pass

    # 3) Last resort: tkinter native chooser
    try:
        return filedialog.askdirectory(title=title, mustexist=mustexist)
    except Exception:
        return None


def _choose_file_native(title: str, filetypes=None):
    """Return a file path selected using the native OS dialog.
    Tries GTK via PyGObject first, then zenity, then tkinter.filedialog.
    """
    # 1) PyGObject (GTK)
    try:
        from gi.repository import Gtk  # type: ignore

        dialog = Gtk.FileChooserDialog(title=title, parent=None, action=Gtk.FileChooserAction.OPEN,
                                       buttons=(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        dialog.set_select_multiple(False)
        if filetypes:
            filt = Gtk.FileFilter()
            for desc, pattern in filetypes:
                filt.add_pattern(pattern)
            dialog.add_filter(filt)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            path = dialog.get_filename()
        else:
            path = None
        dialog.destroy()
        return path
    except Exception:
        pass

    # 2) zenity
    try:
        zenity_cmd = ["zenity", "--file-selection", "--title", title]
        if filetypes:
            for desc, pattern in filetypes:
                zenity_cmd.extend(["--file-filter", f"{desc} | {pattern}"])

        p = subprocess.run(zenity_cmd, capture_output=True, text=True)
        if p.returncode == 0:
            return p.stdout.strip()
    except Exception:
        pass

    # 3) tkinter fallback
    try:
        return filedialog.askopenfilename(title=title, filetypes=filetypes)
    except Exception:
        return None


class TorrentGUI:
    """Modern GUI application for torrent downloading with animations"""
    
    def __init__(self, client: TorrentClient):
        logger.info("Initializing TorrentGUI...")
        self.client = client
        self.client.status_callback = self._update_torrent_list
        
        # Create main window
        self.root = ctk.CTk()
        self.root.title("⚡ SecureTorrent - Anti-Throttling Downloader")
        self.root.geometry("1400x900")
        self.root.configure(fg_color=AppTheme.BG_DARK)
        
        # Set minimum window size
        self.root.minsize(1100, 750)
        
        # Store torrent frames for updates
        self.torrent_frames: Dict[str, dict] = {}
        
        # Animation states
        self.animation_running = True
        self.status_pulse_phase = 0
        self.speed_history: List[float] = []
        
        # Toast notification queue
        self.toast_queue: List[ToastNotification] = []
        
        logger.info("Prompting user to select download path...")
        # Force user to select download path on startup
        self._force_select_download_path()
        
        # Build the UI
        self._build_ui()
        
        # Start animations
        self._start_animations()
        
        # Setup keyboard shortcuts
        self._setup_keyboard_shortcuts()
        
        logger.info("GUI initialized successfully")
        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)
    
    def _setup_keyboard_shortcuts(self):
        """Setup keyboard shortcuts for better UX"""
        # Ctrl+V to paste and auto-detect magnet link
        self.root.bind("<Control-v>", self._handle_paste)
        self.root.bind("<Control-V>", self._handle_paste)
        
        # Enter to start download when entry is focused
        self.magnet_entry.bind("<Return>", lambda e: self._add_torrent())
        
        # Ctrl+O to open file browser
        self.root.bind("<Control-o>", lambda e: self._browse_torrent())
        self.root.bind("<Control-O>", lambda e: self._browse_torrent())
        
        # Escape to clear input
        self.magnet_entry.bind("<Escape>", lambda e: self.magnet_entry.delete(0, 'end'))
        
        logger.info("Keyboard shortcuts configured")
    
    def _handle_paste(self, event=None):
        """Handle paste event - auto-detect magnet links"""
        try:
            clipboard = self.root.clipboard_get()
            if clipboard.startswith("magnet:"):
                # Clear and paste magnet link
                self.magnet_entry.delete(0, 'end')
                self.magnet_entry.insert(0, clipboard)
                self.magnet_entry.focus_set()
                self._show_toast("Magnet link detected! Press Enter to download.", "info")
        except Exception:
            pass  # No clipboard content or error
    
    def _build_ui(self):
        """Build the complete user interface"""
        logger.info("Building user interface...")
        # Configure grid layout
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)
        
        # Top control panel
        self._build_control_panel()
        
        # Main content area
        self._build_content_area()
        
        # Bottom status bar
        self._build_status_bar()
        logger.info("User interface built successfully")
    
    def _start_animations(self):
        """Start background animations"""
        self._animate_status_indicators()
    
    def _animate_status_indicators(self):
        """Animate status indicators periodically"""
        if not self.animation_running:
            return
        
        self.status_pulse_phase = (self.status_pulse_phase + 0.1) % (2 * math.pi)
        
        # Schedule next frame
        self.root.after(100, self._animate_status_indicators)
    
    def _force_select_download_path(self):
        """Force user to select download path on startup"""
        logger.info("Forcing user to select download directory...")
        # If the client already has a valid download path, don't force the dialog.
        try:
            current_path = self.client.download_path
        except Exception:
            current_path = None

        if current_path and os.path.isdir(current_path) and os.access(current_path, os.W_OK):
            logger.info(f"Existing download path is valid: {current_path} - skipping prompt")
            return
        while True:
            # Use the system/native directory chooser. Allow user to type a new path.
            path = _choose_directory_native(title="🗂️ Select Download Directory", mustexist=False)
            
            if not path:
                logger.warning("User cancelled directory selection, asking again...")
                response = messagebox.askyesno(
                    "Download Path Required",
                    "You must select a download directory to continue.\n\nClick 'Yes' to select again or 'No' to exit."
                )
                if not response:
                    logger.info("User chose to exit without selecting download path")
                    self.root.quit()
                    exit(0)
                continue
            
            logger.info(f"User selected download path: {path}")
            # If the path doesn't exist, ask the user if they'd like to create it.
            if not os.path.exists(path):
                create = messagebox.askyesno(
                    "Create Directory?",
                    f"The directory '{path}' does not exist. Create it?"
                )
                if not create:
                    logger.info("User declined to create the selected directory; asking again...")
                    continue
            # set_download_path will ensure the directory exists (it calls makedirs)
            self.client.set_download_path(path)
            logger.info(f"Download path set to: {path}")
            break
    
    def _build_control_panel(self):
        """Build top control panel with input and buttons"""
        control_frame = ctk.CTkFrame(
            self.root, 
            corner_radius=16, 
            fg_color=AppTheme.BG_CARD,
            border_width=1,
            border_color=AppTheme.BORDER_DEFAULT
        )
        control_frame.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="ew")
        control_frame.grid_columnconfigure(0, weight=1)
        
        # Header section with gradient-like effect
        header_frame = ctk.CTkFrame(control_frame, fg_color="transparent")
        header_frame.grid(row=0, column=0, columnspan=3, sticky="ew", padx=25, pady=(20, 15))
        header_frame.grid_columnconfigure(1, weight=1)
        
        # App icon/logo area
        logo_frame = ctk.CTkFrame(
            header_frame, 
            fg_color=AppTheme.PRIMARY,
            corner_radius=12,
            width=50,
            height=50
        )
        logo_frame.grid(row=0, column=0, rowspan=2, padx=(0, 15))
        logo_frame.grid_propagate(False)
        
        logo_icon = ctk.CTkLabel(
            logo_frame,
            text="⚡",
            font=ctk.CTkFont(size=24),
            text_color=AppTheme.TEXT_PRIMARY
        )
        logo_icon.place(relx=0.5, rely=0.5, anchor="center")
        
        # Title
        title_label = ctk.CTkLabel(
            header_frame,
            text="SecureTorrent",
            font=ctk.CTkFont(size=26, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        title_label.grid(row=0, column=1, sticky="w")
        
        # Subtitle with status badges
        status_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        status_frame.grid(row=1, column=1, sticky="w", pady=(2, 0))
        
        # Encryption badge
        enc_badge = ctk.CTkFrame(status_frame, fg_color=AppTheme.STATUS_SUCCESS, corner_radius=10, height=22)
        enc_badge.pack(side="left", padx=(0, 8))
        enc_label = ctk.CTkLabel(
            enc_badge,
            text=" 🔒 RC4/MSE ",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color="#000000"
        )
        enc_label.pack(padx=6, pady=2)
        
        # DPI Bypass badge
        dpi_badge = ctk.CTkFrame(status_frame, fg_color=AppTheme.PRIMARY, corner_radius=10, height=22)
        dpi_badge.pack(side="left", padx=(0, 8))
        dpi_label = ctk.CTkLabel(
            dpi_badge,
            text=" 🛡️ DPI Bypass ",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        dpi_label.pack(padx=6, pady=2)
        
        # Anti-throttle badge
        throttle_badge = ctk.CTkFrame(status_frame, fg_color=AppTheme.WARNING, corner_radius=10, height=22)
        throttle_badge.pack(side="left", padx=(0, 8))
        throttle_label = ctk.CTkLabel(
            throttle_badge,
            text=" ⚡ Anti-Throttle ",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color="#000000"
        )
        throttle_label.pack(padx=6, pady=2)
        
        # Connection status indicator (right side)
        self.connection_indicator = PulsingIndicator(
            header_frame,
            size=14,
            color=AppTheme.STATUS_SUCCESS
        )
        self.connection_indicator.grid(row=0, column=2, rowspan=2, padx=(10, 0))
        self.connection_indicator.start_pulse()
        
        # Separator line
        separator = ctk.CTkFrame(control_frame, height=1, fg_color=AppTheme.BORDER_DEFAULT)
        separator.grid(row=1, column=0, columnspan=3, sticky="ew", padx=25, pady=(0, 15))
        
        # Input section
        input_frame = ctk.CTkFrame(control_frame, fg_color="transparent")
        input_frame.grid(row=2, column=0, columnspan=3, sticky="ew", padx=25, pady=(0, 20))
        input_frame.grid_columnconfigure(0, weight=1)
        
        # Input label with icon
        input_label_frame = ctk.CTkFrame(input_frame, fg_color="transparent")
        input_label_frame.grid(row=0, column=0, sticky="w", pady=(0, 8))
        
        magnet_label = ctk.CTkLabel(
            input_label_frame,
            text="📎 Add Torrent",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        magnet_label.pack(side="left")
        
        hint_label = ctk.CTkLabel(
            input_label_frame,
            text="  •  Paste magnet link or browse for .torrent file",
            font=ctk.CTkFont(size=12),
            text_color=AppTheme.TEXT_MUTED
        )
        hint_label.pack(side="left")
        
        # Input and buttons row
        input_row = ctk.CTkFrame(input_frame, fg_color="transparent")
        input_row.grid(row=1, column=0, sticky="ew")
        input_row.grid_columnconfigure(0, weight=1)
        
        # Modern styled entry
        self.magnet_entry = ctk.CTkEntry(
            input_row,
            placeholder_text="magnet:?xt=urn:btih:... or drag & drop .torrent file",
            height=50,
            font=ctk.CTkFont(size=13),
            fg_color=AppTheme.BG_INPUT,
            border_color=AppTheme.BORDER_DEFAULT,
            border_width=2,
            corner_radius=12,
            text_color=AppTheme.TEXT_PRIMARY,
            placeholder_text_color=AppTheme.TEXT_MUTED
        )
        self.magnet_entry.grid(row=0, column=0, padx=(0, 12), sticky="ew")
        
        # Bind focus events for border color change
        self.magnet_entry.bind("<FocusIn>", lambda e: self.magnet_entry.configure(border_color=AppTheme.PRIMARY))
        self.magnet_entry.bind("<FocusOut>", lambda e: self.magnet_entry.configure(border_color=AppTheme.BORDER_DEFAULT))
        
        # Buttons container
        btn_container = ctk.CTkFrame(input_row, fg_color="transparent")
        btn_container.grid(row=0, column=1, sticky="e")
        
        # Browse button (secondary style)
        browse_btn = ctk.CTkButton(
            btn_container,
            text="📁 Browse",
            command=self._browse_torrent,
            width=120,
            height=50,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=AppTheme.BG_SURFACE,
            hover_color=AppTheme.BG_CARD_HOVER,
            border_width=2,
            border_color=AppTheme.BORDER_DEFAULT,
            corner_radius=12,
            text_color=AppTheme.TEXT_PRIMARY
        )
        browse_btn.grid(row=0, column=0, padx=(0, 10))
        
        # Download button (primary style with gradient-like effect)
        self.download_btn = ctk.CTkButton(
            btn_container,
            text="⬇ Download",
            command=self._add_torrent,
            width=140,
            height=50,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=AppTheme.PRIMARY,
            hover_color=AppTheme.PRIMARY_HOVER,
            corner_radius=12,
            text_color=AppTheme.TEXT_PRIMARY
        )
        self.download_btn.grid(row=0, column=1)
    
    def _build_content_area(self):
        """Build main content area with torrent list"""
        content_frame = ctk.CTkFrame(
            self.root, 
            corner_radius=16,
            fg_color=AppTheme.BG_CARD,
            border_width=1,
            border_color=AppTheme.BORDER_DEFAULT
        )
        content_frame.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_rowconfigure(1, weight=1)
        
        # Header with controls
        header_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", padx=25, pady=(20, 15))
        header_frame.grid_columnconfigure(1, weight=1)
        
        # Downloads icon and title
        downloads_icon = ctk.CTkFrame(
            header_frame,
            width=40,
            height=40,
            corner_radius=10,
            fg_color=AppTheme.BG_SURFACE
        )
        downloads_icon.grid(row=0, column=0, padx=(0, 12))
        downloads_icon.grid_propagate(False)
        
        icon_label = ctk.CTkLabel(
            downloads_icon,
            text="📥",
            font=ctk.CTkFont(size=18)
        )
        icon_label.place(relx=0.5, rely=0.5, anchor="center")
        
        # Title and count
        title_container = ctk.CTkFrame(header_frame, fg_color="transparent")
        title_container.grid(row=0, column=1, sticky="w")
        
        header_label = ctk.CTkLabel(
            title_container,
            text="Active Downloads",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        header_label.pack(side="left")
        
        self.download_count_badge = ctk.CTkFrame(
            title_container,
            fg_color=AppTheme.PRIMARY,
            corner_radius=10,
            width=24,
            height=24
        )
        self.download_count_badge.pack(side="left", padx=(10, 0))
        self.download_count_badge.pack_propagate(False)
        
        self.download_count_label = ctk.CTkLabel(
            self.download_count_badge,
            text="0",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        self.download_count_label.place(relx=0.5, rely=0.5, anchor="center")
        
        # Action buttons (right side)
        actions_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        actions_frame.grid(row=0, column=2, sticky="e")
        
        # Settings button
        settings_btn = ctk.CTkButton(
            actions_frame,
            text="⚙️ Settings",
            command=self._open_settings,
            width=110,
            height=38,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=AppTheme.BG_SURFACE,
            hover_color=AppTheme.BG_CARD_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_SECONDARY
        )
        settings_btn.pack(side="left", padx=(0, 10))
        
        # Clear all button
        clear_btn = ctk.CTkButton(
            actions_frame,
            text="🗑️ Clear All",
            command=self._clear_all,
            width=110,
            height=38,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=AppTheme.DANGER,
            hover_color=AppTheme.DANGER_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_PRIMARY
        )
        clear_btn.pack(side="left")
        
        # Separator
        separator = ctk.CTkFrame(content_frame, height=1, fg_color=AppTheme.BORDER_DEFAULT)
        separator.grid(row=0, column=0, sticky="ew", padx=25, pady=(70, 0))
        
        # Scrollable frame for torrents
        self.scroll_frame = ctk.CTkScrollableFrame(
            content_frame,
            corner_radius=12,
            fg_color=AppTheme.BG_DARK,
            scrollbar_button_color=AppTheme.BG_SURFACE,
            scrollbar_button_hover_color=AppTheme.PRIMARY
        )
        self.scroll_frame.grid(row=1, column=0, padx=20, pady=(15, 20), sticky="nsew")
        self.scroll_frame.grid_columnconfigure(0, weight=1)
        
        # Empty state message with better styling
        self.empty_frame = ctk.CTkFrame(self.scroll_frame, fg_color="transparent")
        self.empty_frame.grid(row=0, column=0, pady=80, sticky="nsew")
        
        # Empty state icon
        empty_icon = ctk.CTkLabel(
            self.empty_frame,
            text="📭",
            font=ctk.CTkFont(size=64)
        )
        empty_icon.pack(pady=(0, 15))
        
        empty_title = ctk.CTkLabel(
            self.empty_frame,
            text="No Active Downloads",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=AppTheme.TEXT_SECONDARY
        )
        empty_title.pack(pady=(0, 8))
        
        self.empty_label = ctk.CTkLabel(
            self.empty_frame,
            text="Paste a magnet link above or browse for a .torrent file\nto start downloading with anti-throttling protection",
            font=ctk.CTkFont(size=14),
            text_color=AppTheme.TEXT_MUTED,
            justify="center"
        )
        self.empty_label.pack()
    
    def _build_status_bar(self):
        """Build bottom status bar with modern styling"""
        status_frame = ctk.CTkFrame(
            self.root, 
            height=70, 
            corner_radius=16,
            fg_color=AppTheme.BG_CARD,
            border_width=1,
            border_color=AppTheme.BORDER_DEFAULT
        )
        status_frame.grid(row=2, column=0, padx=20, pady=(10, 20), sticky="ew")
        status_frame.grid_columnconfigure(2, weight=1)
        
        # === Left Section: Speed Stats ===
        speed_container = ctk.CTkFrame(status_frame, fg_color="transparent")
        speed_container.grid(row=0, column=0, padx=20, pady=12, sticky="w")
        
        # Global download speed with animated indicator
        dl_frame = ctk.CTkFrame(
            speed_container, 
            fg_color=AppTheme.BG_SURFACE, 
            corner_radius=10
        )
        dl_frame.pack(side="left", padx=(0, 10))
        
        dl_icon_frame = ctk.CTkFrame(dl_frame, fg_color=AppTheme.STATUS_SUCCESS, corner_radius=6, width=28, height=28)
        dl_icon_frame.pack(side="left", padx=(8, 6), pady=8)
        dl_icon_frame.pack_propagate(False)
        
        dl_icon = ctk.CTkLabel(dl_icon_frame, text="↓", font=ctk.CTkFont(size=14, weight="bold"), text_color="#000")
        dl_icon.place(relx=0.5, rely=0.5, anchor="center")
        
        self.global_download_label = ctk.CTkLabel(
            dl_frame,
            text="0.00 MB/s",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AppTheme.STATUS_SUCCESS
        )
        self.global_download_label.pack(side="left", padx=(0, 12), pady=8)
        
        # Global upload speed
        ul_frame = ctk.CTkFrame(
            speed_container, 
            fg_color=AppTheme.BG_SURFACE, 
            corner_radius=10
        )
        ul_frame.pack(side="left", padx=(0, 10))
        
        ul_icon_frame = ctk.CTkFrame(ul_frame, fg_color=AppTheme.WARNING, corner_radius=6, width=28, height=28)
        ul_icon_frame.pack(side="left", padx=(8, 6), pady=8)
        ul_icon_frame.pack_propagate(False)
        
        ul_icon = ctk.CTkLabel(ul_icon_frame, text="↑", font=ctk.CTkFont(size=14, weight="bold"), text_color="#000")
        ul_icon.place(relx=0.5, rely=0.5, anchor="center")
        
        self.global_upload_label = ctk.CTkLabel(
            ul_frame,
            text="0.00 MB/s",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AppTheme.WARNING
        )
        self.global_upload_label.pack(side="left", padx=(0, 12), pady=8)
        
        # === Center Section: Tor Status ===
        tor_container = ctk.CTkFrame(status_frame, fg_color="transparent")
        tor_container.grid(row=0, column=1, padx=15, pady=12, sticky="w")
        
        tor_frame = ctk.CTkFrame(
            tor_container, 
            fg_color=AppTheme.BG_SURFACE, 
            corner_radius=10
        )
        tor_frame.pack(side="left")
        
        # Tor icon with pulsing indicator
        self.tor_indicator = PulsingIndicator(tor_frame, size=10, color=AppTheme.STATUS_SUCCESS)
        self.tor_indicator.pack(side="left", padx=(12, 6), pady=10)
        self.tor_indicator.start_pulse()
        
        tor_label = ctk.CTkLabel(
            tor_frame,
            text="🧅 Tor Active",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=AppTheme.STATUS_SUCCESS
        )
        tor_label.pack(side="left", padx=(0, 12), pady=10)
        
        # === Center-Right Section: Download Path ===
        path_container = ctk.CTkFrame(status_frame, fg_color="transparent")
        path_container.grid(row=0, column=2, padx=10, pady=12, sticky="ew")
        
        path_frame = ctk.CTkFrame(
            path_container, 
            fg_color=AppTheme.BG_SURFACE, 
            corner_radius=10
        )
        path_frame.pack(fill="x", expand=True)
        
        path_icon = ctk.CTkLabel(
            path_frame,
            text="📁",
            font=ctk.CTkFont(size=14)
        )
        path_icon.pack(side="left", padx=(12, 6), pady=10)
        
        self.path_value = ctk.CTkLabel(
            path_frame,
            text=self.client.download_path,
            font=ctk.CTkFont(size=11),
            text_color=AppTheme.TEXT_SECONDARY,
            anchor="w"
        )
        self.path_value.pack(side="left", padx=(0, 10), pady=10, fill="x", expand=True)
        
        # === Right Section: Change Path Button ===
        change_path_btn = ctk.CTkButton(
            status_frame,
            text="📂 Change",
            command=self._change_download_path,
            width=100,
            height=40,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=AppTheme.BG_SURFACE,
            hover_color=AppTheme.BG_CARD_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_SECONDARY,
            border_width=1,
            border_color=AppTheme.BORDER_DEFAULT
        )
        change_path_btn.grid(row=0, column=3, padx=(10, 20), pady=12)
    
    def _browse_torrent(self):
        """Browse for .torrent file"""
        logger.info("User opening file browser for .torrent selection...")
        filename = _choose_file_native(
            title="Select Torrent File",
            filetypes=[("Torrent Files", "*.torrent"), ("All Files", "*.*")]
        )
        if filename:
            logger.info(f"User selected torrent file: {filename}")
            self.magnet_entry.delete(0, 'end')
            self.magnet_entry.insert(0, filename)
        else:
            logger.info("User cancelled file browser")
    
    def _add_torrent(self):
        """Add a new torrent with visual feedback"""
        magnet_uri = self.magnet_entry.get().strip()
        
        logger.info(f"User attempting to add torrent: {magnet_uri[:80]}...")
        
        if not magnet_uri:
            logger.warning("User tried to add torrent without providing magnet link or file")
            self._show_toast("Please enter a magnet link or select a torrent file", "warning")
            # Highlight the entry field
            self.magnet_entry.configure(border_color=AppTheme.DANGER)
            self.root.after(2000, lambda: self.magnet_entry.configure(border_color=AppTheme.BORDER_DEFAULT))
            return
        
        # Show loading state on button
        original_text = self.download_btn.cget("text")
        self.download_btn.configure(text="⏳ Adding...", state="disabled")
        
        # Add torrent in background thread
        def add_thread():
            logger.info(f"Starting thread to add torrent...")
            success = self.client.add_torrent(magnet_uri)
            
            def update_ui():
                self.download_btn.configure(text=original_text, state="normal")
                if success:
                    logger.info("Torrent added successfully")
                    self.magnet_entry.delete(0, 'end')
                    self._show_toast("Download started with encryption enabled!", "success")
                else:
                    logger.error(f"Failed to add torrent: {magnet_uri}")
                    self._show_toast("Failed to add torrent. Check the link/file.", "error")
            
            self.root.after(0, update_ui)
        
        threading.Thread(target=add_thread, daemon=True).start()
    
    def _update_torrent_list(self, torrents):
        """Update the torrent list display"""
        # Run in main thread
        self.root.after(0, lambda: self._update_torrent_list_ui(torrents))
    
    def _update_torrent_list_ui(self, torrents):
        """Update torrent list UI (must be called from main thread)"""
        # Update download count badge
        count = len(torrents)
        self.download_count_label.configure(text=str(count))
        
        # Hide/show empty state
        if torrents:
            self.empty_frame.grid_forget()
        else:
            self.empty_frame.grid(row=0, column=0, pady=80, sticky="nsew")
            # Reset global speeds when no torrents
            self.global_download_label.configure(text="0.00 MB/s", text_color=AppTheme.TEXT_MUTED)
            self.global_upload_label.configure(text="0.00 MB/s", text_color=AppTheme.TEXT_MUTED)
            return
        
        # Calculate total speeds
        total_download = sum(t['download_speed'] for t in torrents)
        total_upload = sum(t['upload_speed'] for t in torrents)
        
        # Update speed history for mini graph
        self.speed_history.append(total_download)
        if len(self.speed_history) > 60:
            self.speed_history.pop(0)
        
        # Update global speed display with color based on activity
        dl_color = AppTheme.STATUS_SUCCESS if total_download > 0 else AppTheme.TEXT_MUTED
        ul_color = AppTheme.WARNING if total_upload > 0 else AppTheme.TEXT_MUTED
        
        self.global_download_label.configure(
            text=f"{total_download:.2f} MB/s",
            text_color=dl_color
        )
        self.global_upload_label.configure(
            text=f"{total_upload:.2f} MB/s",
            text_color=ul_color
        )
        
        # Update or create torrent cards
        current_names = set()
        
        for i, status in enumerate(torrents):
            name = status['name']
            current_names.add(name)
            
            if name not in self.torrent_frames:
                # Create new torrent card
                self._create_torrent_card(name, i)
            
            # Update torrent card
            self._update_torrent_card(name, status)
        
        # Remove torrents that no longer exist
        for name in list(self.torrent_frames.keys()):
            if name not in current_names:
                self.torrent_frames[name]['frame'].destroy()
                del self.torrent_frames[name]
    
    def _create_torrent_card(self, name: str, row: int):
        """Create a new torrent display card with modern styling"""
        # Main card frame with subtle gradient effect
        card_frame = ctk.CTkFrame(
            self.scroll_frame, 
            corner_radius=16, 
            fg_color=AppTheme.BG_CARD,
            border_width=2, 
            border_color=AppTheme.BORDER_DEFAULT
        )
        card_frame.grid(row=row, column=0, padx=8, pady=8, sticky="ew")
        card_frame.grid_columnconfigure(0, weight=1)
        
        # Bind hover effects
        card_frame.bind("<Enter>", lambda e: card_frame.configure(border_color=AppTheme.PRIMARY))
        card_frame.bind("<Leave>", lambda e: card_frame.configure(border_color=AppTheme.BORDER_DEFAULT))
        
        # ============ Header Row ============
        header_frame = ctk.CTkFrame(card_frame, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=(18, 10))
        header_frame.grid_columnconfigure(1, weight=1)
        
        # File type icon
        file_icon_frame = ctk.CTkFrame(
            header_frame,
            width=42,
            height=42,
            corner_radius=10,
            fg_color=AppTheme.PRIMARY
        )
        file_icon_frame.grid(row=0, column=0, rowspan=2, padx=(0, 14))
        file_icon_frame.grid_propagate(False)
        
        file_icon = ctk.CTkLabel(
            file_icon_frame,
            text="📦",
            font=ctk.CTkFont(size=18)
        )
        file_icon.place(relx=0.5, rely=0.5, anchor="center")
        
        # Torrent name (truncated if too long)
        display_name = name if len(name) <= 60 else name[:57] + "..."
        name_label = ctk.CTkLabel(
            header_frame,
            text=display_name,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY,
            anchor="w"
        )
        name_label.grid(row=0, column=1, sticky="w")
        
        # Status badge row
        badge_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        badge_frame.grid(row=1, column=1, sticky="w", pady=(4, 0))
        
        state_badge = ctk.CTkFrame(
            badge_frame,
            fg_color=AppTheme.STATUS_INFO,
            corner_radius=8,
            height=20
        )
        state_badge.pack(side="left", padx=(0, 8))
        
        state_label = ctk.CTkLabel(
            state_badge,
            text=" ● Initializing ",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color="#000000"
        )
        state_label.pack(padx=6, pady=2)
        
        # Action buttons (right side)
        btn_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        btn_frame.grid(row=0, column=2, rowspan=2, sticky="e", padx=(10, 0))
        
        pause_btn = ctk.CTkButton(
            btn_frame,
            text="⏸",
            command=lambda: self._pause_torrent(name),
            width=42,
            height=42,
            font=ctk.CTkFont(size=16),
            fg_color=AppTheme.BG_SURFACE,
            hover_color=AppTheme.BG_CARD_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_PRIMARY
        )
        pause_btn.grid(row=0, column=0, padx=3)
        
        resume_btn = ctk.CTkButton(
            btn_frame,
            text="▶",
            command=lambda: self._resume_torrent(name),
            width=42,
            height=42,
            font=ctk.CTkFont(size=16),
            fg_color=AppTheme.ACCENT,
            hover_color=AppTheme.ACCENT_HOVER,
            corner_radius=10,
            text_color="#000000"
        )
        resume_btn.grid(row=0, column=1, padx=3)
        
        remove_btn = ctk.CTkButton(
            btn_frame,
            text="🗑",
            command=lambda: self._remove_torrent(name),
            width=42,
            height=42,
            font=ctk.CTkFont(size=16),
            fg_color=AppTheme.DANGER,
            hover_color=AppTheme.DANGER_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_PRIMARY
        )
        remove_btn.grid(row=0, column=2, padx=3)
        
        # ============ Progress Section ============
        progress_section = ctk.CTkFrame(card_frame, fg_color="transparent")
        progress_section.grid(row=1, column=0, sticky="ew", padx=20, pady=(5, 5))
        progress_section.grid_columnconfigure(0, weight=1)
        
        # Progress info row (percentage + ETA)
        progress_info = ctk.CTkFrame(progress_section, fg_color="transparent")
        progress_info.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        progress_info.grid_columnconfigure(1, weight=1)
        
        progress_label = ctk.CTkLabel(
            progress_info,
            text="0.0%",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color=AppTheme.PRIMARY
        )
        progress_label.grid(row=0, column=0, sticky="w")
        
        eta_label = ctk.CTkLabel(
            progress_info,
            text="⏱ Calculating...",
            font=ctk.CTkFont(size=12),
            text_color=AppTheme.TEXT_MUTED
        )
        eta_label.grid(row=0, column=2, sticky="e")
        
        # Custom animated progress bar
        progress_bar = AnimatedProgressBar(progress_section)
        progress_bar.grid(row=1, column=0, sticky="ew")
        
        # ============ Stats Grid ============
        stats_frame = ctk.CTkFrame(
            card_frame, 
            fg_color=AppTheme.BG_SURFACE, 
            corner_radius=12
        )
        stats_frame.grid(row=2, column=0, sticky="ew", padx=20, pady=(12, 18))
        stats_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        
        # Download Speed
        dl_stat = self._create_stat_item(stats_frame, "⬇ Download", "0.00 MB/s", AppTheme.STATUS_SUCCESS)
        dl_stat['frame'].grid(row=0, column=0, padx=10, pady=12, sticky="w")
        
        # Upload Speed
        ul_stat = self._create_stat_item(stats_frame, "⬆ Upload", "0.00 MB/s", AppTheme.WARNING)
        ul_stat['frame'].grid(row=0, column=1, padx=10, pady=12, sticky="w")
        
        # Peers
        peers_stat = self._create_stat_item(stats_frame, "👥 Peers", "0 (0 seeds)", AppTheme.TEXT_SECONDARY)
        peers_stat['frame'].grid(row=0, column=2, padx=10, pady=12, sticky="w")
        
        # Size
        size_stat = self._create_stat_item(stats_frame, "📦 Size", "0 MB / 0 MB", AppTheme.TEXT_SECONDARY)
        size_stat['frame'].grid(row=0, column=3, padx=10, pady=12, sticky="e")
        
        # Encryption indicator
        encryption_frame = ctk.CTkFrame(stats_frame, fg_color="transparent")
        encryption_frame.grid(row=1, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 10))
        
        encryption_indicator = PulsingIndicator(encryption_frame, size=8, color=AppTheme.STATUS_SUCCESS)
        encryption_indicator.pack(side="left", padx=(0, 6))
        
        encryption_label = ctk.CTkLabel(
            encryption_frame,
            text="🔒 Encrypted Connection",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=AppTheme.STATUS_SUCCESS
        )
        encryption_label.pack(side="left")
        
        # Store references
        self.torrent_frames[name] = {
            'frame': card_frame,
            'progress_bar': progress_bar,
            'progress_label': progress_label,
            'state_label': state_label,
            'state_badge': state_badge,
            'download_label': dl_stat['value'],
            'upload_label': ul_stat['value'],
            'peers_label': peers_stat['value'],
            'size_label': size_stat['value'],
            'eta_label': eta_label,
            'encryption_label': encryption_label,
            'encryption_indicator': encryption_indicator,
        }
    
    def _create_stat_item(self, parent, label: str, value: str, color: str) -> dict:
        """Create a stat display item"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        
        label_widget = ctk.CTkLabel(
            frame,
            text=label,
            font=ctk.CTkFont(size=10),
            text_color=AppTheme.TEXT_MUTED
        )
        label_widget.pack(anchor="w")
        
        value_widget = ctk.CTkLabel(
            frame,
            text=value,
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=color
        )
        value_widget.pack(anchor="w")
        
        return {'frame': frame, 'label': label_widget, 'value': value_widget}
    
    def _update_torrent_card(self, name: str, status: dict):
        """Update a torrent card with current status"""
        if name not in self.torrent_frames:
            return
        
        frame_data = self.torrent_frames[name]
        
        # Update animated progress bar
        progress = status['progress'] / 100.0
        frame_data['progress_bar'].set(progress)
        
        # Update progress percentage with formatting
        pct = status['progress']
        frame_data['progress_label'].configure(text=f"{pct:.1f}%")
        
        # Update progress label color based on completion
        if pct >= 100:
            frame_data['progress_label'].configure(text_color=AppTheme.STATUS_SUCCESS)
        elif pct > 50:
            frame_data['progress_label'].configure(text_color="#00BCD4")  # Cyan
        else:
            frame_data['progress_label'].configure(text_color=AppTheme.PRIMARY)
        
        # Update state badge with appropriate color
        state = status['state'].title()
        state_colors = {
            'Downloading': (AppTheme.STATUS_INFO, "#000"),
            'Seeding': (AppTheme.STATUS_SUCCESS, "#000"),
            'Finished': (AppTheme.STATUS_SUCCESS, "#000"),
            'Paused': (AppTheme.TEXT_MUTED, "#fff"),
            'Checking': (AppTheme.WARNING, "#000"),
            'Queued': (AppTheme.TEXT_MUTED, "#fff"),
            'Downloading Metadata': (AppTheme.WARNING, "#000"),
            'Allocating': (AppTheme.WARNING, "#000"),
        }
        badge_color, text_color = state_colors.get(state, (AppTheme.TEXT_MUTED, "#fff"))
        frame_data['state_badge'].configure(fg_color=badge_color)
        frame_data['state_label'].configure(text=f" ● {state} ", text_color=text_color)
        
        # Update download speed with color animation
        dl_speed = status['download_speed']
        dl_color = AppTheme.STATUS_SUCCESS if dl_speed > 0 else AppTheme.TEXT_MUTED
        frame_data['download_label'].configure(
            text=f"{dl_speed:.2f} MB/s",
            text_color=dl_color
        )
        
        # Update upload speed with color animation
        ul_speed = status['upload_speed']
        ul_color = AppTheme.WARNING if ul_speed > 0 else AppTheme.TEXT_MUTED
        frame_data['upload_label'].configure(
            text=f"{ul_speed:.2f} MB/s",
            text_color=ul_color
        )
        
        # Update peers with health indicator
        num_peers = status['num_peers']
        num_seeds = status['num_seeds']
        
        # Determine peer health color
        if num_seeds > 10:
            peers_color = AppTheme.STATUS_SUCCESS
        elif num_seeds > 3:
            peers_color = AppTheme.WARNING
        else:
            peers_color = AppTheme.TEXT_MUTED
        
        frame_data['peers_label'].configure(
            text=f"{num_peers} ({num_seeds} seeds)",
            text_color=peers_color
        )
        
        # Update size (downloaded / total) with smart units
        downloaded_bytes = status['downloaded']
        total_bytes = status['total_size']
        
        size_text = self._format_size_progress(downloaded_bytes, total_bytes)
        frame_data['size_label'].configure(text=size_text)
        
        # Update ETA with better formatting
        eta = status.get('eta', '∞')
        if eta != "∞":
            eta_color = AppTheme.STATUS_INFO
            eta_text = f"⏱ {eta} remaining"
        else:
            eta_color = AppTheme.TEXT_MUTED
            eta_text = "⏱ Calculating..."
        
        frame_data['eta_label'].configure(text=eta_text, text_color=eta_color)
        
        # Update encryption status with indicator
        encryption = status['encryption']
        if "Encrypted" in encryption:
            frame_data['encryption_label'].configure(
                text="🔒 Encrypted Connection",
                text_color=AppTheme.STATUS_SUCCESS
            )
            if hasattr(frame_data.get('encryption_indicator'), 'set_color'):
                frame_data['encryption_indicator'].set_color(AppTheme.STATUS_SUCCESS)
                frame_data['encryption_indicator'].start_pulse()
        elif "Connecting" in encryption:
            frame_data['encryption_label'].configure(
                text="⏳ Establishing Secure Connection...",
                text_color=AppTheme.WARNING
            )
            if hasattr(frame_data.get('encryption_indicator'), 'set_color'):
                frame_data['encryption_indicator'].set_color(AppTheme.WARNING)
        else:
            frame_data['encryption_label'].configure(
                text=encryption,
                text_color=AppTheme.TEXT_MUTED
            )
    
    def _format_size_progress(self, downloaded: int, total: int) -> str:
        """Format size progress with appropriate units"""
        def format_bytes(b):
            if b >= 1024 ** 3:
                return f"{b / (1024 ** 3):.2f} GB"
            elif b >= 1024 ** 2:
                return f"{b / (1024 ** 2):.1f} MB"
            elif b >= 1024:
                return f"{b / 1024:.1f} KB"
            return f"{b} B"
        
        return f"{format_bytes(downloaded)} / {format_bytes(total)}"
        
        # Update peers
        num_peers = status['num_peers']
        num_seeds = status['num_seeds']
        peers_color = "#4CAF50" if num_peers > 0 else "#757575"
        frame_data['peers_label'].configure(
            text=f"👥 {num_peers} peers ({num_seeds} seeds)",
            text_color=peers_color
        )
        
        # Update size (downloaded / total)
        downloaded_mb = status['downloaded'] / (1024 * 1024)
        total_mb = status['total_size'] / (1024 * 1024)
        
        if total_mb >= 1024:  # Show in GB if > 1GB
            downloaded_gb = downloaded_mb / 1024
            total_gb = total_mb / 1024
            size_text = f"📦 {downloaded_gb:.2f} GB / {total_gb:.2f} GB"
        else:
            size_text = f"📦 {downloaded_mb:.1f} MB / {total_mb:.1f} MB"
        
        frame_data['size_label'].configure(text=size_text)
        
        # Update ETA
        eta = status.get('eta', '∞')
        eta_color = "#FFC107" if eta != "∞" else "#757575"
        frame_data['eta_label'].configure(
            text=f"⏱ {eta}",
            text_color=eta_color
        )
        
        # Update encryption status with animation-like effect
        encryption = status['encryption']
        if "Encrypted" in encryption:
            frame_data['encryption_label'].configure(
                text="🔒 Encrypted",
                text_color="#00E676"
            )
        elif "Connecting" in encryption:
            frame_data['encryption_label'].configure(
                text="⏳ Connecting...",
                text_color="#FFC107"
            )
        else:
            frame_data['encryption_label'].configure(
                text=encryption,
                text_color="#90A4AE"
            )
    
    def _pause_torrent(self, name: str):
        """Pause a torrent with feedback"""
        logger.info(f"User pausing torrent: {name}")
        self.client.pause_torrent(name)
        self._show_toast(f"Paused: {name[:30]}...", "info")
        logger.info(f"Torrent paused: {name}")
    
    def _resume_torrent(self, name: str):
        """Resume a torrent with feedback"""
        logger.info(f"User resuming torrent: {name}")
        self.client.resume_torrent(name)
        self._show_toast(f"Resumed: {name[:30]}...", "success")
        logger.info(f"Torrent resumed: {name}")
    
    def _remove_torrent(self, name: str):
        """Remove a torrent after confirmation"""
        logger.info(f"User attempting to remove torrent: {name}")
        response = messagebox.askyesnocancel(
            "Remove Torrent",
            f"Remove '{name}'?\n\nYes = Keep files\nNo = Delete files\nCancel = Don't remove"
        )
        
        if response is None:  # Cancel
            logger.info(f"User cancelled torrent removal: {name}")
            return
        
        delete_files = not response  # No = delete files
        logger.info(f"Removing torrent: {name} (delete_files={delete_files})")
        self.client.remove_torrent(name, delete_files)
    
    def _clear_all(self):
        """Clear all torrents"""
        logger.info("User attempting to clear all torrents...")
        if not self.torrent_frames:
            logger.info("No torrents to clear")
            return
        
        response = messagebox.askyesno(
            "Clear All",
            "Remove all torrents?\n\nFiles will be kept."
        )
        
        if response:
            logger.info("User confirmed clearing all torrents")
            for name in list(self.torrent_frames.keys()):
                logger.info(f"Removing torrent: {name}")
                self.client.remove_torrent(name, delete_files=False)
        else:
            logger.info("User cancelled clear all operation")
    
    def _change_download_path(self):
        """Change download directory"""
        logger.info("User requesting to change download path...")
        # Allow creation of a new directory from the native dialog
        path = _choose_directory_native(title="Select Download Directory", mustexist=False)
        if not path:
            logger.info("User cancelled path selection")
            return

        logger.info(f"User selected new download path: {path}")
        if not os.path.exists(path):
            create = messagebox.askyesno(
                "Create Directory?",
                f"The directory '{path}' does not exist. Create it?"
            )
            if not create:
                logger.info("User declined to create the selected directory; aborting change")
                return

        # set_download_path will create the directory if needed
        self.client.set_download_path(path)
        self.path_value.configure(text=path)
        logger.info(f"Download path changed to: {path}")
    
    def _open_settings(self):
        """Open settings window with modern design"""
        settings_window = ctk.CTkToplevel(self.root)
        settings_window.title("⚙️ Settings & Information")
        settings_window.geometry("700x600")
        settings_window.transient(self.root)
        settings_window.configure(fg_color=AppTheme.BG_DARK)
        
        # Wait for window to be visible before grabbing
        settings_window.after(100, lambda: settings_window.grab_set())
        
        # Header section
        header_frame = ctk.CTkFrame(settings_window, fg_color=AppTheme.BG_CARD, corner_radius=0, height=80)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)
        
        title = ctk.CTkLabel(
            header_frame,
            text="⚙️ Settings & Security Info",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        title.pack(pady=25)
        
        # Scrollable content
        content = ctk.CTkScrollableFrame(
            settings_window, 
            fg_color=AppTheme.BG_DARK,
            scrollbar_button_color=AppTheme.BG_SURFACE
        )
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # === Security Section ===
        self._create_settings_section(
            content, 
            "🔒 Security & Encryption",
            [
                ("Protocol Encryption", "RC4/MSE (Message Stream Encryption)", AppTheme.STATUS_SUCCESS),
                ("Encryption Mode", "Forced on all connections", AppTheme.STATUS_SUCCESS),
                ("Proxy Protocol", "SOCKS5 via Tor (127.0.0.1:9050)", AppTheme.STATUS_SUCCESS),
            ]
        )
        
        # === Anti-Throttling Section ===
        self._create_settings_section(
            content,
            "⚡ Anti-Throttling Features",
            [
                ("Deep Packet Inspection Bypass", "Active - Traffic obfuscated", AppTheme.STATUS_SUCCESS),
                ("Traffic Randomization", "Enabled - Pattern masking", AppTheme.STATUS_SUCCESS),
                ("Port Randomization", "Enabled - Dynamic ports 6881-6999", AppTheme.STATUS_SUCCESS),
                ("uTP Protocol", "Enabled - Additional DPI evasion", AppTheme.STATUS_SUCCESS),
            ]
        )
        
        # === Performance Section ===
        self._create_settings_section(
            content,
            "🚀 Performance Settings",
            [
                ("Max Connections", "2000 peers", AppTheme.STATUS_INFO),
                ("Download Limit", "Unlimited", AppTheme.STATUS_INFO),
                ("Upload Limit", "10 MB/s (optimized for ratio)", AppTheme.STATUS_INFO),
                ("Disk Cache", "2GB buffer for fast I/O", AppTheme.STATUS_INFO),
            ]
        )
        
        # === Tips Section ===
        tips_frame = ctk.CTkFrame(content, fg_color=AppTheme.BG_CARD, corner_radius=12)
        tips_frame.pack(fill="x", pady=(10, 5))
        
        tips_title = ctk.CTkLabel(
            tips_frame,
            text="💡 Tips for Best Performance",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        tips_title.pack(anchor="w", padx=15, pady=(15, 10))
        
        tips = [
            "• Keep Tor service running for maximum ISP bypass",
            "• Popular torrents work best (more encrypted peers)",
            "• Encryption adds minimal CPU overhead",
            "• Allow some upload for better download speeds",
        ]
        
        for tip in tips:
            tip_label = ctk.CTkLabel(
                tips_frame,
                text=tip,
                font=ctk.CTkFont(size=12),
                text_color=AppTheme.TEXT_SECONDARY,
                anchor="w"
            )
            tip_label.pack(anchor="w", padx=15, pady=2)
        
        # Spacing at bottom of tips
        ctk.CTkFrame(tips_frame, height=10, fg_color="transparent").pack()
        
        # Close button
        close_btn = ctk.CTkButton(
            settings_window,
            text="Close",
            command=settings_window.destroy,
            width=140,
            height=42,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=AppTheme.PRIMARY,
            hover_color=AppTheme.PRIMARY_HOVER,
            corner_radius=10
        )
        close_btn.pack(pady=20)
    
    def _create_settings_section(self, parent, title: str, items: list):
        """Create a settings section with items"""
        section_frame = ctk.CTkFrame(parent, fg_color=AppTheme.BG_CARD, corner_radius=12)
        section_frame.pack(fill="x", pady=(0, 15))
        
        # Section title
        title_label = ctk.CTkLabel(
            section_frame,
            text=title,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        title_label.pack(anchor="w", padx=15, pady=(15, 10))
        
        # Items
        for label, value, color in items:
            item_frame = ctk.CTkFrame(section_frame, fg_color="transparent")
            item_frame.pack(fill="x", padx=15, pady=4)
            
            label_widget = ctk.CTkLabel(
                item_frame,
                text=label,
                font=ctk.CTkFont(size=12),
                text_color=AppTheme.TEXT_MUTED
            )
            label_widget.pack(side="left")
            
            value_widget = ctk.CTkLabel(
                item_frame,
                text=value,
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=color
            )
            value_widget.pack(side="right")
        
        # Bottom padding
        ctk.CTkFrame(section_frame, height=10, fg_color="transparent").pack()
    
    def _show_notification(self, title: str, message: str, error: bool = False):
        """Show a notification message (legacy method)"""
        toast_type = "error" if error else "success"
        self._show_toast(message, toast_type)
    
    def _show_toast(self, message: str, toast_type: str = "info", duration: int = 3000):
        """Show a modern toast notification"""
        try:
            toast = ToastNotification(self.root, message, toast_type, duration)
            self.toast_queue.append(toast)
        except Exception as e:
            logger.error(f"Failed to show toast: {e}")
            # Fallback to messagebox
            if toast_type == "error":
                messagebox.showerror("Error", message)
            else:
                messagebox.showinfo("Info", message)
    
    def _on_closing(self):
        """Handle window close event with confirmation dialog"""
        logger.info("User attempting to close application...")
        
        # Create custom confirmation dialog
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("Confirm Exit")
        dialog.geometry("400x220")
        dialog.transient(self.root)
        dialog.configure(fg_color=AppTheme.BG_DARK)
        dialog.resizable(False, False)
        
        # Center the dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 200
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 110
        dialog.geometry(f"+{x}+{y}")
        
        dialog.after(100, lambda: dialog.grab_set())
        
        # Content frame
        content = ctk.CTkFrame(dialog, fg_color=AppTheme.BG_CARD, corner_radius=16)
        content.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Warning icon
        icon_label = ctk.CTkLabel(
            content,
            text="⚠️",
            font=ctk.CTkFont(size=40)
        )
        icon_label.pack(pady=(20, 10))
        
        # Message
        msg_label = ctk.CTkLabel(
            content,
            text="Are you sure you want to exit?",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=AppTheme.TEXT_PRIMARY
        )
        msg_label.pack(pady=(0, 5))
        
        sub_msg = ctk.CTkLabel(
            content,
            text="All downloads will be paused",
            font=ctk.CTkFont(size=12),
            text_color=AppTheme.TEXT_MUTED
        )
        sub_msg.pack(pady=(0, 20))
        
        # Buttons frame
        btn_frame = ctk.CTkFrame(content, fg_color="transparent")
        btn_frame.pack(pady=(0, 15))
        
        def confirm_exit():
            dialog.destroy()
            logger.info("User confirmed application exit")
            self.animation_running = False
            logger.info("Shutting down torrent client...")
            self.client.shutdown()
            logger.info("Destroying GUI...")
            self.root.quit()
            self.root.destroy()
            logger.info("Application closed successfully")
        
        def cancel_exit():
            dialog.destroy()
            logger.info("User cancelled application exit")
        
        cancel_btn = ctk.CTkButton(
            btn_frame,
            text="Cancel",
            command=cancel_exit,
            width=120,
            height=40,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=AppTheme.BG_SURFACE,
            hover_color=AppTheme.BG_CARD_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_PRIMARY
        )
        cancel_btn.pack(side="left", padx=(0, 10))
        
        exit_btn = ctk.CTkButton(
            btn_frame,
            text="Exit",
            command=confirm_exit,
            width=120,
            height=40,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=AppTheme.DANGER,
            hover_color=AppTheme.DANGER_HOVER,
            corner_radius=10,
            text_color=AppTheme.TEXT_PRIMARY
        )
        exit_btn.pack(side="left")
    
    def run(self):
        """Start the GUI main loop"""
        # Start torrent client updates
        self.client.start_updates()
        
        # Start the GUI main loop
        self.root.mainloop()
