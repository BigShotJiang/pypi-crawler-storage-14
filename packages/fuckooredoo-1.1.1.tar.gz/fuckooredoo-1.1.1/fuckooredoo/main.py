#fuckooredoo/main.py
"""
SecureTorrent - Anti-Throttling Torrent Downloader
Bypasses ISP throttling through Tor network routing and traffic encryption
Features:
- Modern animated UI with smooth transitions
- RC4/MSE encryption for all connections
- Deep Packet Inspection (DPI) bypass
- Traffic pattern randomization
- Real-time progress with animated indicators
"""

import customtkinter as ctk
from .torrent_client import TorrentClient
from .gui import TorrentGUI
import sys


def main():
    """Main application entry point"""
    # Set modern dark appearance
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    
    # Configure high DPI scaling
    ctk.deactivate_automatic_dpi_awareness()
    
    # Create the torrent client with encryption enabled
    client = TorrentClient()
    
    # Create and run the GUI
    app = TorrentGUI(client)
    app.run()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n✋ Application stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
