Python C++ interface
####################

pybind11 exposes Python types and functions using thin C++ wrappers, which
makes it possible to conveniently call Python code from C++ without resorting
to Python's C API.

.. toctree::
   :maxdepth: 2

   object
   numpy
   utilities
