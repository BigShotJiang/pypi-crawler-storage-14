"""Spatial Intelligence - Foundational 3D AI models"""

__version__ = "0.0.1"
