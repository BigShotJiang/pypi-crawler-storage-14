"""
ParserNaam is a package for parsing names.
"""

from parsernaam.parse import ParseNames

__all__ = ["ParseNames"]
