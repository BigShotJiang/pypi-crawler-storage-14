import json

DATA_FILE = "todo_data.json"

def load_task_from_file():
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            loaded_list = json.load(f)
            print(f"💾{len(loaded_list)}件のタスクをファイルから読み込みました。")
            return loaded_list
        
    except FileNotFoundError:
        print("💡 todo_data.jsonが見つかりませんでした。新しいリストを開始します。")
        return []
    except json.JSONDecodeError:
        print("❌ ファイルの内容が不正です。新しいリストを開始します。")
        return []
    except Exception as e:
        print(f"❌ ファイル読み込み中に予期せぬエラーが発生しました: {e}")
        return []
    
def save_tasks_to_file(data_list):
    try:
        # 'w' は書き込みモード (ファイルがなければ作成、あれば上書き)
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            # data_list を JSON形式に変換してファイルに書き込む
            json.dump(data_list, f, indent=4, ensure_ascii=False)
        print(f"✅ タスクをファイル '{DATA_FILE}' に保存しました。")
    except Exception as e:
        print(f"❌ ファイル保存中にエラーが発生しました: {e}")