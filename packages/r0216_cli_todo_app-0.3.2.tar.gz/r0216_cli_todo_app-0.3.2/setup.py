from setuptools import setup, find_packages

setup(
    name='R0216-cli-todo-app',
    version='0.3.2',
    author='R0216',
    description='A simple command-line ToDo list application written in Python.',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/R0216/todo_list',
    py_modules=['main', 'data_handler'],
    entry_points={
        'console_scripts': [
            'todo=main:main',
        ],
    },

    python_requires='>=3.6',
    install_requires=[

    ],

    license='MIT',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
        'Topic :: Utilities',
    ],
)