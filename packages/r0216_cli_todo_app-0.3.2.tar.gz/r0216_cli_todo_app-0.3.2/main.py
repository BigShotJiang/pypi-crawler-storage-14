from data_handler import load_task_from_file, save_tasks_to_file

todo_list = []

class ToDoList:
    def __init__(self):
        global todo_list
        loaded_data = load_task_from_file()
        if loaded_data:
            todo_list = loaded_data

    def display_task(self):
        print("\n--- ToDo リスト ---")
        if not todo_list:
            print("タスクはありません。")
            return 
        for index, task in enumerate(todo_list):
            if task["completed"]:
                status = "[✓]"
            else:
                status = "[ ]"
            print(f"{index + 1}. {status} {task['deadline']} {task['task']}")
        print("--------------\n")

    def add_task(self, task_name, deadline):
        new_task = {"task": task_name, "deadline": deadline, "completed": False}
        todo_list.append(new_task)
        print(f"タスク: '{task_name}'を追加しました。")

    def remove_task(self):
        self.display_task()
        if not todo_list:
            return
        
        try:
            task_number = int(input("削除するタスクの番号を入力してください: "))
            task_index = task_number - 1
            if 0 <= task_index < len(todo_list):
                removed_task = todo_list.pop(task_index)
                print(f"✅ タスク: '{removed_task['task']}' を削除しました。")
            else:
                print("エラー: その番号のタスクは存在しません。")

        except ValueError:
            print("エラー: 無効な入力です。番号を数字で入力してください。")
        except Exception as e:
            print(f"予期せぬエラーが発生しました: {e}")
        
    def initialize_data(self):
        global todo_list
        loaded_data = load_task_from_file()
        if loaded_data:
            todo_list.extend(loaded_data)

    def save_and_exit(self):
        save_tasks_to_file(todo_list)
        
        

    def complete_task(self):
        self.display_task()
        if not todo_list:
            return 
        try:
            task_number = int(input("完了するタスクの番号を入力してください： "))
            task_index = task_number - 1
            if 0 <= task_index < len(todo_list):
                todo_list[task_index]["completed"] = True
                complete_task_name = todo_list[task_index]["task"]
                print(f"タスク: '{complete_task_name}'を完了にしました。[✓]")
            else:
                print("エラー: その番号のタスクは存在しません。")
        except ValueError:
            print("エラー: 無効な入力です。番号を数字で入力してください。")
        except Exception as e:
            print(f"予期せぬエラーが発生しました: {e}")

    def edit_task(self):
        self.display_task()
        if not todo_list:
            return
        
        try:
            task_number = int(input('編集するタスクの番号を入力してください： '))
            task_index = task_number - 1

            if 0 <= task_index < len(todo_list):
                current_task_name = todo_list[task_index]["task"]
                print(f"現在のタスク: '{current_task_name}'")

                new_task_name = input("新しいタスク名を入力してください: ")
                todo_list[task_index]["task"] = new_task_name
                print(f"タスク{task_number} を '{new_task_name}' に更新しました。")

            else:
                print("エラー: その番号のタスクは存在しません。")
        except ValueError:
            print("エラー: 無効な入力です。番号を数字で入力してください。")
        except Exception as e:
            print(f"予期せぬエラーが発生しました: {e}")




def main():

    app = ToDoList()
    while True:
        print("\n--- メニュー---")
        print("1: タスクを表示")
        print("2: タスクを追加")
        print("3: タスクの編集")
        print("4: タスクの削除")
        print("5: タスクを完了")
        print("6: タスクを保存")

        choice = input("選択してください（1-5）: ")

        if choice == '1':
            app.display_task()
        elif choice == '2':
            task_name = input('タスクを入力: ')
            deadline = input('提出期限を入力: ')
            app.add_task(task_name, deadline)

        elif choice == '3':
            app.edit_task()
        elif choice == '4':
            app.remove_task()
        elif choice == '5':
            app.complete_task()
        elif choice == '6':
            app.save_and_exit()
            break
        else:
            print("無効な選択肢です")

if __name__ == "__main__":
    main()


