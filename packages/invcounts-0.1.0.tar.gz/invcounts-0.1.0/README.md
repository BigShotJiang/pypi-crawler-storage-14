# invcounts

A tiny helper providing:

- `summarize_counts(items)`: returns a dict with totals for expired, out, low.

Usage:
```python
from invcounts import summarize_counts
counts = summarize_counts(items)
```