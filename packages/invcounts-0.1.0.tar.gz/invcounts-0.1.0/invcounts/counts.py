def summarize_counts(items):
    """
    Return a dict with counts for total, expired, out, and low.
    Assumes each item has a 'status' attribute that is one of:
    'expired', 'out', 'low', 'ok' (or similar).
    """
    total = len(items)
    expired = sum(1 for it in items if getattr(it, "status", "") == "expired")
    out = sum(1 for it in items if getattr(it, "status", "") == "out")
    low = sum(1 for it in items if getattr(it, "status", "") == "low")
    return {"total": total, "expired": expired, "out": out, "low": low}