* Go to "Inventory -> Configuration -> Settings" and scroll to the "Operation" section.
* In the "Portal Visible Operations" select operation types that would be visible in the customer portal.