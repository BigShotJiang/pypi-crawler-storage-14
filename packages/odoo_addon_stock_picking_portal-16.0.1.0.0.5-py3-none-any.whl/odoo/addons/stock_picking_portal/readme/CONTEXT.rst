Sometimes you would like your customers to be able to see their stock operations in the customer portal.
For example if they would like to check statuses of their delivery orders.