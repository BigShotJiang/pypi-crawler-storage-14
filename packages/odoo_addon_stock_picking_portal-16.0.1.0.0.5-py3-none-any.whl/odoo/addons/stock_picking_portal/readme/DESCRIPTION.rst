This module implements the following features:

* Show stock operations (pickings) in the customer portal
* Sign pickings directly in portal. Built-in Odoo signatures wizard is used
* Sharing pickings using shareable links with tokens
 
Users have access to the following stock operations:

* Operation type is available in portal
* User (partner) is set as "Customer"