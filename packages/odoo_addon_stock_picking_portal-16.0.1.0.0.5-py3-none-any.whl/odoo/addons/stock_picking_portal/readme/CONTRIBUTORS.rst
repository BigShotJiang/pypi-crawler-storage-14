* `Cetmix <https://cetmix.com>`__:

   * Ivan Sokolov
   * George Smirnov
   * Dessan Hemrayev
