from . import test_stock_picking_portal
from . import test_res_config_settings
from . import test_wizard
