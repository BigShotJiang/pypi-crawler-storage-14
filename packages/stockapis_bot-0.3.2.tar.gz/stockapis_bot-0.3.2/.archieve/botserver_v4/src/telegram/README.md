# Telegram Signal Monitor

Monitors Telegram channels for trading signals and publishes them to Django via gRPC (or Redis fallback).

## Quick Start

```bash
...stockapis/solution/projects/botserver/src/telegram

# First time - authorize Telegram account
make auth

# Run monitor
make run

# Debug mode (verbose logs)
make debug
```

## Architecture

```
Telegram Channels → Telegram Monitor → gRPC (port 50053) → Django ORM
                                     ↘ Redis (fallback)
```

**Components:**
- `service.py` - Main service orchestration
- `client/` - Telethon client wrapper (handles 2FA)
- `extractors/` - Signal parsing from messages
- `grpc/` - gRPC publisher to Django signals service
- `redis/` - Redis publisher (fallback if gRPC unavailable)

## Configuration

### `.env` file
```env
# Telegram API (from https://my.telegram.org/)
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=abcdef1234567890
TELEGRAM_PHONE=+1234567890

# gRPC (primary)
GRPC_HOST=localhost
GRPC_PORT=50053
GRPC_ENABLED=true

# Redis (fallback)
REDIS_HOST=localhost
REDIS_PORT=6379
```

### `channels.yaml` - channels to monitor
```yaml
channels:
  - username: upbit_news
    enabled: true
    signal_types: [BUY, SELL]
    min_confidence: 0.5

  - username: stockapisdemo2
    enabled: true
    signal_types: [BUY, SELL]
    min_confidence: 0.5
```

## Make Commands

| Command | Description |
|---------|-------------|
| `make run` | Run signal monitor |
| `make auth` | First-time Telegram authorization |
| `make debug` | Run with DEBUG logging |
| `make send` | Send test signal to channel |
| `make send-all` | Send all sample signals |

## Testing End-to-End

### 1. Start Django services (in `projects/django/`)

```bash
...stockapis/solution/projects/django

# Run all services (ASGI + gRPC + RQ)
make run-all

# Or individual services:
make asgi   # Port 8000
make grpc   # Port 50051 (trading_bots gRPC)
```

### 2. Start Telegram monitor

```bash
stockapis/solution/projects/botserver/src/telegram
make debug
```

### 3. Send test messages

In another terminal:
```bash
stockapis/solution/projects/botserver/src/telegram

# Send single test signal
make send

# Send all sample signals
make send-all

# Send custom message
python test_send.py -m "BUY BTC/USDT at 95000"
```

### 4. Verify

Watch telegram monitor logs for:
```
Signal: buy BTC/USDT (confidence=0.6, completeness=0.9)
Signal published: BTC/USDT buy (subscribers=0)
```

## Test Messages

Sample signals in `test_send.py`:
```
BUY Signal: BTC/USDT Entry: 95000 Target 1: 96500 Stop Loss: 93500
SELL Signal: ETH/USDT Entry: 3500 Target: 3300 Stop Loss: 3600
PUMP Alert: DOGE on Binance
```

### Custom test message
```bash
python test_send.py -m "🚀 BUY Signal
Coin: DOGE/USDT
Entry: 0.38
Target 1: 0.42
Stop Loss: 0.35"
```

### Expected log output
```
Message received: stockapisdemo2#263
Processing message from stockapisdemo2#263
Signal: buy DOGE/USDT (confidence=0.6, completeness=0.9)
Signal published: DOGE/USDT buy (subscribers=0)
```

## Troubleshooting

### "No enabled channels configured"
Edit `channels.yaml` and add channels with `enabled: true`

### 2FA password required
The auth flow will prompt for 2FA password if enabled on your Telegram account.

### Session in wrong location
Sessions are stored in `telegram/sessions/session.session`. Delete and re-auth if needed.

### gRPC connection failed
Falls back to Redis automatically. Check:
- Is Django signals gRPC running on port 50053?
- Verify GRPC_HOST and GRPC_PORT in `.env`

### Signal not extracted
- Check `min_confidence` in `channels.yaml`
- Debug log shows extraction details
- Pattern expects format: `BTC/USDT` or `BTC USDT`

## Files

```
telegram/
├── .env                 # Config (API keys, gRPC, Redis)
├── channels.yaml        # Channels to monitor
├── Makefile            # Dev commands
├── test_send.py        # Send test signals via bot
├── sessions/           # Telethon session files
├── run.py              # Entrypoint
├── service.py          # Main service
├── config/             # Settings (pydantic)
├── client/             # Telethon wrapper
├── extractors/         # Signal parsing
├── handlers/           # Message processing
├── models/             # Data models
├── grpc/               # gRPC publisher
│   ├── publisher.py    # Signal publisher client
│   └── signal_service_pb2*.py  # Generated proto
└── redis/              # Redis publisher (fallback)
```

## gRPC Proto Sync

Proto files are managed in Django and synced here:
```bash
# In Django directory
stockapis/solution/projects/django/apps/signals/grpc/services/proto
./generate_proto.sh
```

This generates and copies proto files to:
- `django/apps/signals/grpc/generated/` (Django server)
- `telegram/grpc/` (this project, client)

## Current Status

| Feature | Status |
|---------|--------|
| Telegram client | ✅ Working |
| 2FA support | ✅ Working |
| Signal extraction | ✅ Working |
| Redis publisher | ✅ Working (fallback) |
| gRPC publisher | ⚠️ Client ready, server TODO |
| Django ORM integration | 🔜 Pending gRPC server |

### Next steps
1. Create Django signals gRPC server on port 50053
2. Add `rungrpc_signals` management command
3. Test end-to-end with Django ORM
