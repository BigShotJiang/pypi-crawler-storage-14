# StockAPIS Trading Bot Server

FastAPI middleware with gRPC for orchestrating trading bot instances.

## 🚀 Quick Start

### Option 1: Docker (Recommended)

```bash
# Start services (server + redis)
make docker-up

# View logs
make docker-logs

# Stop services
make docker-down
```

Server will be available at:
- HTTP: http://localhost:8010
- gRPC: localhost:50051

### Option 2: Local Development

```bash
# Install dependencies
make install

# Run development server with hot reload
make dev

# Or run production mode
make run
```

### Test Health Endpoint

```bash
curl http://localhost:8010/health
```

Expected response:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "redis": "ok",
  "django": "ok"
}
```

## 📂 Project Structure

```
packages/server/
├── src/server/              # Main application code
│   ├── api/                 # FastAPI routes
│   ├── infrastructure/      # Redis, Django clients
│   ├── models/              # Pydantic models
│   ├── grpc/                # gRPC services
│   ├── services/            # Business logic
│   ├── config.py            # Settings
│   └── main.py              # Application entry point
├── proto/                   # Protocol Buffers definitions
├── tests/                   # Tests
├── pyproject.toml           # Poetry dependencies
└── README.md
```

## 🧪 Run Tests

```bash
# Run all tests
make test

# Run tests with coverage
make test-cov
```

## 🔧 Development

```bash
# Format code
make format

# Lint code
make lint

# Clean build artifacts
make clean
```

## 🐳 Docker

```bash
# Build image
make docker-build

# Start services
make docker-up

# View logs
make docker-logs

# Restart services
make docker-restart

# Stop services
make docker-down

# Remove all containers and volumes
make docker-clean

# Access Redis CLI
make redis-cli
```

## 📖 Documentation

See `@docs/` directory for complete documentation.

- **[Implementation Plan](../@workflow/SKYSCRAPER_IMPLEMENTATION.md)** - Step-by-step guide
- **[Architecture](../@docs/architecture/index.md)** - System design
- **[API Reference](../@docs/server/index.md)** - FastAPI + gRPC spec

## 🏗️ Implementation Status

### Floor 0: Foundation ✅ COMPLETE (16h)
- ✅ Floor 0.1: Project Structure Setup (2h)
- ✅ Floor 0.2: Redis Client (3h)
- ✅ Floor 0.3: Django REST Client (5h)
- ✅ Floor 0.4: Pydantic Models (4h)
- ✅ Floor 0.5: Docker Setup (2h)

### Next: Floor 1 - Bot Manager (16h)
See [SKYSCRAPER_IMPLEMENTATION.md](../@workflow/SKYSCRAPER_IMPLEMENTATION.md) for details.
