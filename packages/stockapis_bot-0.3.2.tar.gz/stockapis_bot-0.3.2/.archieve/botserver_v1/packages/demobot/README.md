# DemoBot - Simulated Trading Bot

> 🎮 Demo trading bot for StockAPIS that simulates trading without real funds

**Version:** 1.0.0
**Status:** 📋 Documentation Complete - Ready for Implementation
**License:** Same as StockAPIS

---

## Overview

DemoBot is a fully functional trading bot that **simulates all trading operations** without requiring real exchange credentials or funds. Perfect for:

- 🧪 Testing bot lifecycle and infrastructure
- 📊 Demonstrating trading capabilities
- 🎓 Training and onboarding
- 🚀 CI/CD integration testing
- 🔬 Performance benchmarking

---

## Key Features

✅ **Simulated Exchange** - No real API calls, instant order fills
✅ **gRPC Integration** - Full bidirectional communication with server
✅ **Config Hot-Reload** - Update settings without restart
✅ **Heartbeat Monitoring** - Health metrics every 30 seconds
✅ **Multiple Strategies** - Random, signal-based, trend-following
✅ **Realistic Simulation** - Slippage, fees, price movements
✅ **Zero Risk** - No real funds, no real trades

---

## Quick Start

### Installation

```bash
cd /path/to/botserver/packages/demobot

# Install dependencies
poetry install

# Run bot
poetry run demobot --config config.json
```

### Basic Usage

```python
from demobot import DemoBot, BotConfig

# Create config
config = BotConfig(
    bot_id="demo-001",
    exchange="simulated",
    symbol="BTC/USDT",
    amount_usdt=10000.0,
    trading_mode="random"
)

# Create and start bot
bot = DemoBot(config)
await bot.start()
```

### With gRPC Server

```bash
# Start FastAPI server first
cd ../server
poetry run python -m uvicorn server.main:app --port 50051

# Start DemoBot
cd ../demobot
poetry run demobot \
  --config config.json \
  --grpc-url localhost:50051 \
  --log-level INFO
```

---

## Configuration

### config.json Example

```json
{
  "bot_id": "demo-btc-001",
  "adapter": "demobot-python",
  "exchange": "simulated",
  "symbol": "BTC/USDT",
  "amount_usdt": 10000.0,
  "direction": "long",
  "market_type": "spot",
  "trading_mode": "random",

  "simulation_settings": {
    "enable_pnl_simulation": true,
    "pnl_variance": 0.02,
    "trade_frequency_seconds": 10,
    "max_position_size": 5,
    "enable_slippage": true,
    "slippage_percent": 0.001
  },

  "grpc_server": {
    "enabled": true,
    "server_url": "localhost:50051",
    "tls_enabled": false,
    "reconnect_interval_seconds": 5
  },

  "log_level": "INFO",
  "log_file": "/var/log/demobot/demobot.log"
}
```

### Environment Variables

```bash
export DEMOBOT_BOT_ID=demo-001
export DEMOBOT_GRPC_URL=localhost:50051
export DEMOBOT_LOG_LEVEL=DEBUG
```

---

## Architecture

```
┌─────────────────────────────────────────┐
│          Django Control Plane            │
│  (BotAdapter, BotConfig, BotInstance)   │
└──────────────┬──────────────────────────┘
               │ REST API
               ▼
┌─────────────────────────────────────────┐
│       FastAPI Orchestration Server       │
│  • BotRegistry (in-memory cache)        │
│  • gRPC Server (bidirectional stream)   │
│  • ConfigManager (hot-reload)           │
└──────────────┬──────────────────────────┘
               │ gRPC
               ▼
┌─────────────────────────────────────────┐
│           DemoBot Process                │
│  ┌────────────────────────────────────┐ │
│  │ Main Controller                    │ │
│  │  • Trading Loop                    │ │
│  │  • Heartbeat Loop (every 30s)      │ │
│  │  • Config Listener                 │ │
│  │  • Command Handler                 │ │
│  └────────────────────────────────────┘ │
│  ┌────────────────────────────────────┐ │
│  │ SimulatedExchange                  │ │
│  │  • Instant order fills             │ │
│  │  • Mock price generator            │ │
│  │  • Position tracking               │ │
│  │  • PnL calculation                 │ │
│  └────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

---

## Trading Modes

### 1. Random Trading
```json
{
  "trading_mode": "random",
  "simulation_settings": {
    "trade_frequency_seconds": 10
  }
}
```
- Executes random buy/sell at intervals
- Good for stress testing

### 2. Signal-Based (Simulated)
```json
{
  "trading_mode": "signal_based"
}
```
- Pretends to receive external signals
- More realistic patterns

### 3. Trend-Following (Simulated)
```json
{
  "trading_mode": "trend_following"
}
```
- Simulates trend detection
- Buys on uptrends, sells on downtrends

---

## API Reference

### DemoBot Class

```python
class DemoBot:
    def __init__(self, config: BotConfig)
    async def start() -> None
    async def stop() -> None
    async def get_status() -> BotStatus
    async def get_positions() -> List[Position]
    async def get_pnl() -> float
```

### SimulatedExchange Class

```python
class SimulatedExchange(BaseExchangeTrader):
    async def connect() -> None
    async def disconnect() -> None
    async def place_order(
        symbol: str,
        side: OrderSide,
        quantity: float,
        order_type: OrderType = OrderType.MARKET,
        price: Optional[float] = None
    ) -> Order
    async def get_account_info() -> AccountInfo
    async def cancel_order(symbol: str, order_id: str) -> bool
```

### GRPCClient Class

```python
class GRPCClient:
    async def connect() -> None
    async def register(bot_id: str, adapter: str) -> str
    async def send_heartbeat(heartbeat: Heartbeat) -> None
    async def stream_config_updates() -> AsyncIterator[ConfigUpdate]
    async def stream_commands() -> AsyncIterator[BotCommand]
```

---

## Examples

### Example 1: Basic Standalone Bot

```python
import asyncio
from demobot import DemoBot, BotConfig

async def main():
    config = BotConfig(
        bot_id="standalone-demo",
        exchange="simulated",
        symbol="BTC/USDT",
        amount_usdt=5000.0,
        trading_mode="random",
        grpc_server={"enabled": False}
    )

    bot = DemoBot(config)
    await bot.start()

asyncio.run(main())
```

### Example 2: With gRPC Integration

```python
import asyncio
from demobot import DemoBot, BotConfig, GRPCServerConfig

async def main():
    config = BotConfig(
        bot_id="grpc-demo",
        exchange="simulated",
        symbol="ETH/USDT",
        amount_usdt=10000.0,
        trading_mode="trend_following",
        grpc_server=GRPCServerConfig(
            enabled=True,
            server_url="localhost:50051",
            tls_enabled=False
        )
    )

    bot = DemoBot(config)

    try:
        await bot.start()
    except KeyboardInterrupt:
        await bot.stop()

asyncio.run(main())
```

### Example 3: Custom Strategy

```python
from demobot import DemoBot, BotConfig
from demobot.trading import BaseTradingStrategy, TradeSignal

class MyCustomStrategy(BaseTradingStrategy):
    async def get_signal(self) -> Optional[TradeSignal]:
        # Your custom logic here
        return TradeSignal(
            symbol="BTC/USDT",
            side=OrderSide.BUY,
            confidence=0.8
        )

# Use custom strategy
config = BotConfig(...)
bot = DemoBot(config)
bot.trading_engine.strategy = MyCustomStrategy(config)
await bot.start()
```

---

## Testing

### Run Tests

```bash
# All tests
poetry run pytest

# Unit tests only
poetry run pytest tests/unit/ -v

# Integration tests (requires gRPC server)
poetry run pytest tests/integration/ -v

# With coverage
poetry run pytest --cov=demobot --cov-report=html
```

### Test Coverage Goals

- Unit tests: > 80%
- Integration tests: > 60%
- Overall: > 75%

---

## Monitoring

### Logs

```
2025-10-26 12:00:00 [INFO] 🚀 Starting DemoBot...
2025-10-26 12:00:01 [INFO] ✅ Connected to simulated exchange
2025-10-26 12:00:01 [INFO] ✅ gRPC connected to localhost:50051
2025-10-26 12:00:01 [INFO] ✅ Registered with token: abc123...
2025-10-26 12:00:02 [INFO] 📊 Trading loop started
2025-10-26 12:00:02 [INFO] 💓 Heartbeat loop started
2025-10-26 12:00:10 [INFO] 📊 Order filled: BUY 0.2 BTC @ $50,123.45
2025-10-26 12:00:30 [DEBUG] 💓 Heartbeat sent: PnL=$150.00
2025-10-26 12:01:00 [INFO] 📥 Config update received (v2)
2025-10-26 12:01:00 [INFO] ✅ Config hot-reloaded successfully
```

### Metrics

Access via FastAPI:

```bash
curl http://localhost:8080/api/v1/bots/demo-001/metrics

{
  "bot_id": "demo-001",
  "uptime_seconds": 3600,
  "total_trades": 24,
  "total_pnl": 325.50,
  "win_rate": 0.625,
  "avg_trade_duration": "5m",
  "cpu_usage_percent": 2.5,
  "memory_usage_mb": 45.2,
  "last_heartbeat": "2025-10-26T12:30:00Z"
}
```

---

## Deployment

### Docker

```dockerfile
FROM python:3.12-slim

WORKDIR /app

COPY pyproject.toml poetry.lock ./
RUN pip install poetry && poetry install --no-dev

COPY src/ ./src/
COPY config.json ./

CMD ["poetry", "run", "demobot", "--config", "config.json"]
```

```bash
docker build -t demobot:1.0.0 .
docker run -d --name demobot \
  -v $(pwd)/config.json:/app/config.json \
  demobot:1.0.0
```

### Supervisor

```ini
[program:demobot]
command=/app/.venv/bin/python -m demobot --config /etc/demobot/config.json
directory=/app/packages/demobot
user=botuser
autostart=true
autorestart=true
stderr_logfile=/var/log/demobot/error.log
stdout_logfile=/var/log/demobot/output.log
```

---

## Documentation

| Document | Description |
|----------|-------------|
| [00-DEMOBOT-OVERVIEW.md](@docs/00-DEMOBOT-OVERVIEW.md) | Complete overview and features |
| [01-ARCHITECTURE.md](@docs/01-ARCHITECTURE.md) | Detailed architecture documentation |
| [02-IMPLEMENTATION-PLAN.md](@docs/02-IMPLEMENTATION-PLAN.md) | Step-by-step implementation guide |

---

## Development

### Project Structure

```
demobot/
├── @docs/               # Documentation
├── src/demobot/         # Source code
│   ├── core/            # Core bot logic
│   ├── exchange/        # Simulated exchange
│   ├── trading/         # Trading strategies
│   ├── grpc_integration/# gRPC client
│   └── utils/           # Utilities
├── tests/               # Tests
│   ├── unit/            # Unit tests
│   └── integration/     # Integration tests
├── examples/            # Example scripts
├── pyproject.toml       # Dependencies
└── README.md            # This file
```

### Contributing

1. Follow code style (Black, Ruff)
2. Write tests for new features
3. Update documentation
4. Submit PR with clear description

---

## Roadmap

### v1.0.0 (Current) - Documentation
- [x] Complete architecture documentation
- [x] Implementation plan
- [x] API reference

### v1.1.0 - Core Implementation
- [ ] Simulated exchange
- [ ] Basic trading strategies
- [ ] gRPC integration
- [ ] Config hot-reload

### v1.2.0 - Advanced Features
- [ ] Multiple trading strategies
- [ ] Advanced PnL simulation
- [ ] Mock order book
- [ ] Market event simulation

### v1.3.0 - Analytics
- [ ] Performance dashboard
- [ ] Trade history export
- [ ] Backtesting mode
- [ ] Strategy comparison

---

## FAQ

**Q: Does DemoBot make real trades?**
A: No, all trading is simulated. No real funds are used.

**Q: Can I test gRPC integration?**
A: Yes, DemoBot fully implements gRPC protocol.

**Q: Does config hot-reload work?**
A: Yes, you can update config without restarting the bot.

**Q: Can I use custom trading strategies?**
A: Yes, implement `BaseTradingStrategy` interface.

**Q: Does it work with FastAPI server?**
A: Yes, fully integrated with bot management server.

---

## Support

- **Documentation:** See `@docs/` directory
- **Issues:** File in main StockAPIS repository
- **Questions:** Contact development team

---

## License

Same license as parent StockAPIS project

---

## Credits

- **Architecture:** Based on listing-monitor reference implementation
- **gRPC Protocol:** Defined in server package
- **Team:** StockAPIS Development Team

---

**Status:** 📋 Ready for implementation
**Last Updated:** 2025-10-26
**Maintainer:** StockAPIS Team
