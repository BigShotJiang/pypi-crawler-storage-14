# StockAPIS TypeScript Client

Simple, unified TypeScript client for StockAPIS Trading Bot API.

## Installation

```bash
# Using npm
npm install @stockapis/client

# Using yarn
yarn add @stockapis/client

# Using pnpm
pnpm add @stockapis/client
```

## Quick Start

```typescript
import { StockAPISClient } from '@stockapis/client';

// Create client
const client = new StockAPISClient({
  baseUrl: 'http://localhost:8000',
  apiKey: 'your-api-key'  // Optional
});

// List running bot instances
const instances = await client.trading.trading_bot_instances.list({
  query: { status: 'running' }
});

console.log(`Running bots: ${instances.length}`);
```

## Configuration

### Environment Variables

```bash
# API URL (optional, defaults to http://localhost:8000)
STOCKAPIS_API_URL=http://api.stockapis.com

# API Key for authentication (optional)
STOCKAPIS_API_KEY=your-api-key-here
```

### Programmatic Configuration

```typescript
const client = new StockAPISClient({
  baseUrl: 'http://localhost:8000',
  apiKey: 'your-api-key',
  timeout: 30000,  // Request timeout in ms
});
```

## API Reference

### Trading API

#### Bot Instances

```typescript
// List instances
const instances = await client.trading.trading_bot_instances.list();

// Filter by status
const running = await client.trading.trading_bot_instances.list({
  query: { status: 'running' }
});

// Get specific instance
const instance = await client.trading.trading_bot_instances.retrieve({
  path: { id: 'instance-id' }
});

// Create instance
const newInstance = await client.trading.trading_bot_instances.create({
  body: {
    config: 'bot-config-id',
    status: 'running',
    host: 'localhost',
    process_id: '12345'
  }
});

// Update instance
const updated = await client.trading.trading_bot_instances.partialUpdate({
  path: { id: 'instance-id' },
  body: { status: 'paused' }
});

// Lifecycle actions
await client.trading.trading_bot_instances.start({
  path: { id: 'instance-id' }
});

await client.trading.trading_bot_instances.stop({
  path: { id: 'instance-id' }
});

await client.trading.trading_bot_instances.heartbeat({
  path: { id: 'instance-id' }
});
```

#### Bot Configs

```typescript
// List configs
const configs = await client.trading.trading_bot_configs.list();

// Filter enabled configs
const enabled = await client.trading.trading_bot_configs.list({
  query: { enabled: true }
});

// Get specific config
const config = await client.trading.trading_bot_configs.retrieve({
  path: { id: 'config-id' }
});

// Update config
const updated = await client.trading.trading_bot_configs.partialUpdate({
  path: { id: 'config-id' },
  body: { amount_usdt: '200.0' }
});
```

#### Stock Deals

```typescript
// List deals
const deals = await client.trading.trading_stock_deals.list();

// Filter open deals
const openDeals = await client.trading.trading_stock_deals.list({
  query: { status: 'open' }
});

// Create deal
const deal = await client.trading.trading_stock_deals.create({
  body: {
    bot_instance: 'instance-id',
    instrument: 'instrument-id',
    direction: 'long',
    entry_price: '50000.0',
    quantity: '0.001'
  }
});
```

### Signals API

```typescript
// List signals
const signals = await client.signals.signals_signals.list();

// Filter by source
const telegramSignals = await client.signals.signals_signals.list({
  query: { source: 'telegram' }
});

// Get specific signal
const signal = await client.signals.signals_signals.retrieve({
  path: { id: 'signal-id' }
});
```

## Advanced Usage

### Error Handling

```typescript
import { APIError } from '@stockapis/client';

try {
  const instance = await client.trading.trading_bot_instances.retrieve({
    path: { id: 'non-existent-id' }
  });
} catch (error) {
  if (error instanceof APIError) {
    console.error(`API Error: ${error.message}`);
    console.error(`Status: ${error.status}`);
  } else {
    throw error;
  }
}
```

### TypeScript Types

```typescript
import type {
  BotInstance,
  BotConfig,
  StockDeal
} from '@stockapis/client/trading/types';

// Fully typed responses
const instance: BotInstance = await client.trading.trading_bot_instances.retrieve({
  path: { id: 'instance-id' }
});

// Type-safe parameters
const config: BotConfig = {
  name: 'My Bot',
  exchange: 'bybit',
  enabled: true,
  amount_usdt: '100.0'
};
```

## Examples

### Monitor Bot Health

```typescript
async function monitorBots() {
  const client = new StockAPISClient();

  while (true) {
    const instances = await client.trading.trading_bot_instances.list();

    for (const instance of instances) {
      if (instance.last_heartbeat_at) {
        const age = Date.now() - new Date(instance.last_heartbeat_at).getTime();
        if (age > 120000) {  // 2 minutes
          console.log(`⚠️  Bot ${instance.id} is stale!`);
        }
      } else {
        console.log(`❌ Bot ${instance.id} never sent heartbeat`);
      }
    }

    await new Promise(resolve => setTimeout(resolve, 60000));  // Check every minute
  }
}
```

### Auto-Restart Failed Bots

```typescript
async function restartFailedBots() {
  const client = new StockAPISClient();

  const errored = await client.trading.trading_bot_instances.list({
    query: { status: 'error' }
  });

  for (const instance of errored) {
    console.log(`Restarting ${instance.id}...`);
    await client.trading.trading_bot_instances.start({
      path: { id: instance.id }
    });
  }
}
```

## Development

### Project Structure

```
clients/typescript/
├── StockAPISClient.ts   # Main client
├── index.ts             # Package exports
├── README.md            # This file
├── package.json         # Package config
└── tsconfig.json        # TypeScript config
```

### Building

```bash
# Install dependencies
npm install

# Build
npm run build

# Test
npm test
```

## License

MIT
