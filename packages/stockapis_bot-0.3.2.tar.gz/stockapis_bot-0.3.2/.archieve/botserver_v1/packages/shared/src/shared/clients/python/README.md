# StockAPIS Python Client

Simple, unified Python client for StockAPIS Trading Bot API.

## Installation

```bash
# From this directory
pip install -e .

# Or add to your requirements.txt
-e /path/to/tradebot-py/packages/api/clients/python
```

## Quick Start

```python
from stockapis_client import StockAPISClient

# Simple usage
async with StockAPISClient() as client:
    # List running bot instances
    instances = await client.trading.trading_bot_instances.list(
        params={"status": "running"}
    )

    for instance in instances:
        print(f"Bot: {instance.config.name}, Status: {instance.status}")
```

## Configuration

### Environment Variables

```bash
# API URL (optional, defaults to http://localhost:8000)
export STOCKAPIS_API_URL=http://api.stockapis.com

# API Key for authentication (optional)
export STOCKAPIS_API_KEY=your-api-key-here
```

### Programmatic Configuration

```python
client = StockAPISClient(
    base_url="http://localhost:8000",
    api_key="your-api-key",
    enable_retry=True,        # Auto-retry failed requests
    enable_logging=False,     # Log requests/responses
    timeout=30.0              # Request timeout
)
```

## API Reference

### Trading API

#### Bot Instances

```python
async with StockAPISClient() as client:
    # List instances
    instances = await client.trading.trading_bot_instances.list()

    # Filter by status
    running = await client.trading.trading_bot_instances.list(
        params={"status": "running"}
    )

    # Get specific instance
    instance = await client.trading.trading_bot_instances.retrieve(
        id="instance-id"
    )

    # Create instance
    new_instance = await client.trading.trading_bot_instances.create(
        data={
            "config": "bot-config-id",
            "status": "running",
            "host": "localhost",
            "process_id": "12345"
        }
    )

    # Update instance
    updated = await client.trading.trading_bot_instances.partial_update(
        id="instance-id",
        data={"status": "paused"}
    )

    # Lifecycle actions
    await client.trading.trading_bot_instances.start(id="instance-id")
    await client.trading.trading_bot_instances.stop(id="instance-id")
    await client.trading.trading_bot_instances.pause(id="instance-id")
    await client.trading.trading_bot_instances.resume(id="instance-id")

    # Heartbeat
    await client.trading.trading_bot_instances.heartbeat(id="instance-id")
```

#### Bot Configs

```python
async with StockAPISClient() as client:
    # List configs
    configs = await client.trading.trading_bot_configs.list()

    # Filter enabled configs
    enabled = await client.trading.trading_bot_configs.list(
        params={"enabled": True}
    )

    # Get specific config
    config = await client.trading.trading_bot_configs.retrieve(
        id="config-id"
    )

    # Update config
    updated = await client.trading.trading_bot_configs.partial_update(
        id="config-id",
        data={"amount_usdt": "200.0"}
    )
```

#### Stock Deals

```python
async with StockAPISClient() as client:
    # List deals
    deals = await client.trading.trading_stock_deals.list()

    # Filter open deals
    open_deals = await client.trading.trading_stock_deals.list(
        params={"status": "open"}
    )

    # Create deal
    deal = await client.trading.trading_stock_deals.create(
        data={
            "bot_instance": "instance-id",
            "instrument": "instrument-id",
            "direction": "long",
            "entry_price": "50000.0",
            "quantity": "0.001"
        }
    )

    # Close deal
    await client.trading.trading_stock_deals.partial_update(
        id="deal-id",
        data={"status": "closed", "exit_price": "51000.0"}
    )
```

### Signals API

```python
async with StockAPISClient() as client:
    # List signals
    signals = await client.signals.signals_signals.list()

    # Filter by source
    telegram_signals = await client.signals.signals_signals.list(
        params={"source": "telegram"}
    )

    # Get specific signal
    signal = await client.signals.signals_signals.retrieve(
        id="signal-id"
    )
```

## Advanced Usage

### Custom Retry Configuration

```python
from stockapis_client import StockAPISClient

async with StockAPISClient(
    enable_retry=True,
    # Retry config is built-in, just enable it
) as client:
    # Automatically retries on network errors or 5xx responses
    instances = await client.trading.trading_bot_instances.list()
```

### Logging Requests

```python
async with StockAPISClient(
    enable_logging=True  # Logs all requests/responses
) as client:
    instances = await client.trading.trading_bot_instances.list()
```

### Error Handling

```python
from httpx import HTTPStatusError

async with StockAPISClient() as client:
    try:
        instance = await client.trading.trading_bot_instances.retrieve(
            id="non-existent-id"
        )
    except HTTPStatusError as e:
        if e.response.status_code == 404:
            print("Instance not found")
        else:
            print(f"Error: {e}")
```

## Examples

### Monitor Bot Health

```python
import asyncio
from stockapis_client import StockAPISClient

async def monitor_bots():
    async with StockAPISClient() as client:
        while True:
            # Get all instances
            instances = await client.trading.trading_bot_instances.list()

            for instance in instances:
                # Check if instance is alive (heartbeat < 2 min ago)
                if instance.last_heartbeat_at:
                    age = datetime.now() - instance.last_heartbeat_at
                    if age.total_seconds() > 120:
                        print(f"⚠️  Bot {instance.id} is stale!")
                else:
                    print(f"❌ Bot {instance.id} never sent heartbeat")

            await asyncio.sleep(60)  # Check every minute

asyncio.run(monitor_bots())
```

### Auto-Restart Failed Bots

```python
async def restart_failed_bots():
    async with StockAPISClient() as client:
        # Get all errored instances
        errored = await client.trading.trading_bot_instances.list(
            params={"status": "error"}
        )

        for instance in errored:
            print(f"Restarting {instance.id}...")
            await client.trading.trading_bot_instances.start(id=instance.id)
```

## Development

### Project Structure

```
clients/python/
├── stockapis_client.py    # Main client
├── __init__.py            # Package exports
├── README.md              # This file
└── setup.py               # Package setup
```

### Testing

```python
# Run tests
pytest tests/

# With coverage
pytest --cov=stockapis_client tests/
```

## License

MIT
