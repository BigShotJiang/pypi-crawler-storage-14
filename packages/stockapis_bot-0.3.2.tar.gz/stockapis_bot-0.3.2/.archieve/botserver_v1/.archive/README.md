# Listing Monitor v3.0

Cryptocurrency listing monitoring and automated trading system.

## Features

- **Multi-Exchange Support**: Trade on 10+ exchanges (Bybit, Binance, OKX, Gate, MEXC, XT, BingX, Hyperliquid, Bitget)
- **Multiple Signal Sources**: Announcements API, Pairs Diff, Telegram channels  
- **Low Latency**: Connection warming reduces execution latency by 170-500ms
- **Fast Price Lookups**: gRPC-based price caching (50x faster than API calls)
- **Risk Management**: Configurable leverage, take profit, stop loss, trailing stop
- **Real-time Notifications**: Telegram notifications with detailed timing metrics
- **Proxy Support**: Rotate proxies to avoid rate limits
- **Testnet Support**: Test strategies on testnet before going live

## Quick Start

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for detailed documentation.

## Installation

```bash
pip install -e .
```

## Developed By

Reforms AI
