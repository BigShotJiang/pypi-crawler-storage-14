"""
Shared settings for botclient using pydantic-settings.

Uses double underscore prefix for environment variable grouping:
    TELEGRAM__API_ID -> settings.telegram.api_id
    REDIS__HOST -> settings.redis.host
    etc.

.env file search order:
    1. Current working directory (.env) - PyPI users
    2. examples/.env - our credentials
    3. debug/.env - debug override

Usage:
    from shared.settings import get_settings
    settings = get_settings()

    # Access nested settings
    settings.telegram.api_id
    settings.bot.token
    settings.redis.host
"""

from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_env_file() -> str | None:
    """Find .env file in search paths."""
    # Get package root (botclient/)
    package_root = Path(__file__).parent.parent.parent

    search_paths = [
        Path.cwd() / ".env",                    # Current directory (PyPI users)
        package_root / "examples" / ".env",     # Our credentials
        package_root / "debug" / ".env",        # Debug override (if any)
    ]

    for path in search_paths:
        if path.exists():
            return str(path)

    return None


class TelegramSettings(BaseModel):
    """Telegram user account settings (for monitoring channels)."""
    api_id: Optional[int] = None  # Empty string in .env becomes None
    api_hash: str = ""
    session: str = ""
    channels: str = ""  # Comma-separated

    @property
    def channels_list(self) -> list[str]:
        """Get channels as list."""
        if not self.channels:
            return []
        return [ch.strip() for ch in self.channels.split(",") if ch.strip()]


class BotSettings(BaseModel):
    """Telegram bot settings (for sending signals)."""
    token: str = ""
    channel: str = "@stockapisdemo2"


class RedisSettings(BaseModel):
    """Redis settings."""
    host: str = "localhost"
    port: int = 6379
    password: Optional[str] = None
    channel: str = "trading_signals"

    @property
    def url(self) -> str:
        """Get Redis URL."""
        if self.password:
            return f"redis://:{self.password}@{self.host}:{self.port}"
        return f"redis://{self.host}:{self.port}"


class BinanceSettings(BaseModel):
    """Binance settings."""
    api_key: str = ""
    api_secret: str = ""
    testnet: bool = True


class GrpcSettings(BaseModel):
    """gRPC settings."""
    host: str = "localhost"
    port: int = 50051
    api_key: str = ""  # Set via GRPC__API_KEY in .env
    use_tls: bool = False  # Set via GRPC__USE_TLS in .env

    @property
    def address(self) -> str:
        """Get gRPC address."""
        return f"{self.host}:{self.port}"


class Settings(BaseSettings):
    """Main settings container with nested groups."""

    model_config = SettingsConfigDict(
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    telegram: TelegramSettings = TelegramSettings()
    bot: BotSettings = BotSettings()
    redis: RedisSettings = RedisSettings()
    binance: BinanceSettings = BinanceSettings()
    grpc: GrpcSettings = GrpcSettings()


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    env_file = _find_env_file()
    return Settings(_env_file=env_file)


def clear_settings_cache() -> None:
    """Clear settings cache (useful for testing)."""
    get_settings.cache_clear()
