"""
Compiled regex patterns for signal extraction.

Supports English and Russian signal formats.
"""

import re
from typing import Pattern

# ═══════════════════════════════════════════════════════════════
# EXCHANGE ENUM (local to telegram module)
# ═══════════════════════════════════════════════════════════════


class Exchange:
    """Supported exchanges for pattern matching."""

    BINANCE = "binance"
    BYBIT = "bybit"
    OKX = "okx"
    MEXC = "mexc"
    BITGET = "bitget"
    KUCOIN = "kucoin"
    GATEIO = "gateio"
    HTX = "htx"
    UNKNOWN = "unknown"


# ═══════════════════════════════════════════════════════════════
# ACTION PATTERNS
# ═══════════════════════════════════════════════════════════════

BUY_PATTERNS: list[str] = [
    r"\b(buy|long|entry|enter)\b",
    r"\b(покупка|лонг|вход)\b",
    r"📈",
    r"🟢",
    r"✅",
]

SELL_PATTERNS: list[str] = [
    r"\b(sell|short|exit)\b",
    r"\b(продажа|шорт|выход)\b",
    r"📉",
    r"🔴",
    r"❌",
]

PUMP_PATTERNS: list[str] = [
    r"\b(pump|moon|rocket|gem)\b",
    r"\b(памп|луна|ракета)\b",
    r"🚀",
    r"🌕",
    r"💎",
    r"🔥",
]

LISTING_PATTERNS: list[str] = [
    r"\b(listing|list|новая монета|new listing)\b",
    r"\b(will list|добавлен|листинг)\b",
]

# ═══════════════════════════════════════════════════════════════
# SYMBOL PATTERNS
# ═══════════════════════════════════════════════════════════════

# Standard format: BTC/USDT, ETH USDT, BTCUSDT
_QUOTE_CURRENCIES = r"(USDT|USD|BUSD|BTC|ETH)"
_KNOWN_COINS = (
    # Top coins - common bases
    r"BTC|ETH|BNB|XRP|ADA|SOL|DOGE|DOT|AVAX|MATIC|"
    r"LINK|UNI|ATOM|LTC|ETC|XLM|TRX|NEAR|ALGO|FTM|"
    r"APE|SAND|MANA|AXS|GALA|GMT|OP|ARB|SUI|SEI|"
    # Memecoins
    r"SHIB|PEPE|FLOKI|WIF|BONK|BOME|"
    # Others
    r"[A-Z]{2,10}"
)
_ACTION_WORDS = (
    r"BUY|SELL|LONG|SHORT|EXIT|ENTRY|PUMP|LIST|MOON|STOP|"
    r"LISTING|TARGET|TAKE|PROFIT|LOSS|SIGNAL|COIN"
)
SYMBOL_PATTERN = rf"\b(?!(?:{_ACTION_WORDS})\b)({_KNOWN_COINS})[/\s]+{_QUOTE_CURRENCIES}\b"

# Dollar sign format: $BTC, $ETH
SYMBOL_DOLLAR = r"\$([A-Z]{2,10})\b"

# Hashtag format: #BTC, #ETH
SYMBOL_HASHTAG = r"#([A-Z]{2,10})\b"

# ═══════════════════════════════════════════════════════════════
# PRICE PATTERNS
# ═══════════════════════════════════════════════════════════════

# Entry price: "Entry: 45000", "Entry @ 45000", "@ 45000", "Buy @ 45000"
ENTRY_PATTERN = (
    r"(?:entry|вход|buy|покупка|enter|@)"
    r"(?:\s+at|\s+@|\s+по|:|\s+zone)?[:\s]*"
    r"(\d+(?:[\.,]\d+)?)"
)

# Target prices: "Target 1: 46000", "TP1 50000"
TARGET_PATTERN = (
    r"(?:target|tp|цель|🎯|take\s*profit)"
    r"\s*(\d+)?[:\s]*"
    r"(\d+(?:[\.,]\d+)?)"
)

# Stop loss: "Stop: 44000", "SL 44000", "Stop Loss: 44000"
STOP_LOSS_PATTERN = (
    r"(?:stop\s*loss|stop|sl|стоп|стоп.?лосс)"
    r"[:\s]*(\d+(?:[\.,]\d+)?)"
)

# Price range: "3000-3050", "3000 - 3050"
PRICE_RANGE_PATTERN = r"(\d+(?:[\.,]\d+)?)\s*[-–—]\s*(\d+(?:[\.,]\d+)?)"

# ═══════════════════════════════════════════════════════════════
# EXCHANGE PATTERNS
# ═══════════════════════════════════════════════════════════════

EXCHANGE_PATTERNS: dict[str, str] = {
    Exchange.BINANCE: r"\b(binance|бинанс)\b",
    Exchange.BYBIT: r"\b(bybit|байбит)\b",
    Exchange.OKX: r"\b(okx|okex|окекс)\b",
    Exchange.MEXC: r"\b(mexc|мекс)\b",
    Exchange.BITGET: r"\b(bitget|битгет)\b",
    Exchange.KUCOIN: r"\b(kucoin|кукоин)\b",
    Exchange.GATEIO: r"\b(gate\.?io|гейт)\b",
    Exchange.HTX: r"\b(htx|huobi|хуоби)\b",
}

# ═══════════════════════════════════════════════════════════════
# LEVERAGE PATTERN
# ═══════════════════════════════════════════════════════════════

LEVERAGE_PATTERN = r"(\d+)\s*[xх]\s*(?:leverage|плечо|левередж)?"

# ═══════════════════════════════════════════════════════════════
# MARKET TYPE PATTERNS
# ═══════════════════════════════════════════════════════════════

FUTURES_PATTERN = r"\b(futures|фьючерс|perp|perpetual|бессрочн)\b"
SPOT_PATTERN = r"\b(spot|спот)\b"


# ═══════════════════════════════════════════════════════════════
# COMPILED PATTERNS
# ═══════════════════════════════════════════════════════════════


def compile_patterns(patterns: list[str]) -> list[Pattern[str]]:
    """Compile list of patterns with IGNORECASE flag."""
    return [re.compile(p, re.IGNORECASE) for p in patterns]


class CompiledPatterns:
    """Pre-compiled regex patterns for performance."""

    def __init__(self) -> None:
        # Action patterns
        self.buy = compile_patterns(BUY_PATTERNS)
        self.sell = compile_patterns(SELL_PATTERNS)
        self.pump = compile_patterns(PUMP_PATTERNS)
        self.listing = compile_patterns(LISTING_PATTERNS)

        # Symbol patterns
        self.symbol = re.compile(SYMBOL_PATTERN, re.IGNORECASE)
        self.symbol_dollar = re.compile(SYMBOL_DOLLAR)
        self.symbol_hashtag = re.compile(SYMBOL_HASHTAG)

        # Price patterns
        self.entry = re.compile(ENTRY_PATTERN, re.IGNORECASE)
        self.target = re.compile(TARGET_PATTERN, re.IGNORECASE)
        self.stop_loss = re.compile(STOP_LOSS_PATTERN, re.IGNORECASE)
        self.price_range = re.compile(PRICE_RANGE_PATTERN)

        # Exchange patterns
        self.exchanges: dict[str, Pattern[str]] = {
            exchange: re.compile(pattern, re.IGNORECASE)
            for exchange, pattern in EXCHANGE_PATTERNS.items()
        }

        # Other patterns
        self.leverage = re.compile(LEVERAGE_PATTERN, re.IGNORECASE)
        self.futures = re.compile(FUTURES_PATTERN, re.IGNORECASE)
        self.spot = re.compile(SPOT_PATTERN, re.IGNORECASE)


# Global compiled patterns instance
PATTERNS = CompiledPatterns()
