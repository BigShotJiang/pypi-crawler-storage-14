"""
Send test signals via Telegram Bot API.

Simple HTTP-based sending - uses shared settings.

Usage:
    from telegram.test_bot import send_test_signal, send_all_signals

    # Send single signal
    send_test_signal()

    # Send all test signals
    send_all_signals()

Environment (via shared/settings.py):
    BOT__TOKEN        - Bot token from @BotFather
    BOT__TEST_CHANNEL - Channel username (default: @stockapisdemo2)
"""

import json
import time
from typing import Optional
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from shared.settings import get_settings

# Test signals for E2E testing
TEST_SIGNALS = [
    """🚀 BUY Signal
Coin: BTC/USDT
Entry: 95000
TP1: 97000
TP2: 99000
SL: 93000
Leverage: 10x""",
    """📉 SELL Signal
Coin: ETH/USDT
Entry: 3500
Target: 3300
Stop: 3600""",
    """🔥 PUMP Alert
$DOGE listing on Binance
Expected pump 50%+""",
    """📊 Signal Update
BTC reached TP1 ✅
Moving SL to entry""",
]


def _get_config() -> tuple[str, str]:
    """Get bot token and channel from settings."""
    settings = get_settings()

    if not settings.bot.token:
        raise ValueError("BOT__TOKEN not set in environment")

    return settings.bot.token, settings.bot.channel


def _send_message(bot_token: str, chat_id: str, text: str) -> bool:
    """Send message via Telegram Bot API."""
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = urlencode({"chat_id": chat_id, "text": text}).encode()

    try:
        req = Request(url, data=data, method="POST")
        with urlopen(req, timeout=10) as response:
            result = json.loads(response.read())
            return result.get("ok", False)
    except Exception as e:
        print(f"Error: {e}")
        return False


def send_test_signal(message: Optional[str] = None) -> bool:
    """Send a single test signal.

    Args:
        message: Custom message or None for default BUY signal

    Returns:
        True if sent successfully
    """
    bot_token, channel = _get_config()
    text = message or TEST_SIGNALS[0]
    return _send_message(bot_token, channel, text)


def send_all_signals(delay: float = 2.0) -> int:
    """Send all test signals.

    Args:
        delay: Delay between signals in seconds

    Returns:
        Number of signals sent successfully
    """
    bot_token, channel = _get_config()
    sent = 0

    for i, signal in enumerate(TEST_SIGNALS):
        if _send_message(bot_token, channel, signal):
            sent += 1
        if i < len(TEST_SIGNALS) - 1:
            time.sleep(delay)

    return sent
