"""Bot ID generation utilities.

Generates deterministic UUIDs from bot names using UUID5.
Same name = same UUID always, across any machine.
"""

import uuid

# Namespace for stockapis bots
STOCKAPIS_NAMESPACE = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # UUID namespace DNS


def generate_bot_id(name: str) -> str:
    """Generate deterministic bot ID from name.

    Uses UUID5 (SHA-1 hash) to generate consistent UUID from name.
    Same name will always produce the same UUID on any machine.

    Args:
        name: Human-readable bot name (e.g., "redis-scalper", "grid-trader")

    Returns:
        UUID string (e.g., "b87b79f7-ad23-5113-84fc-451fbed8e209")

    Example:
        >>> generate_bot_id("redis-scalper")
        'a1b2c3d4-...'
        >>> generate_bot_id("redis-scalper")  # Same input = same output
        'a1b2c3d4-...'
    """
    # Add domain suffix for namespacing
    full_name = f"{name}.stockapis.com"
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, full_name))
