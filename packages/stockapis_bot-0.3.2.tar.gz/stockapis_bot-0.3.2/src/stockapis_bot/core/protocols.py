"""Protocol definitions for dependency injection.

Using Protocol instead of ABC for structural subtyping.
This allows duck typing while maintaining type safety.
"""

from typing import AsyncIterator, Protocol

from ..models.config import BotConfig
from ..models.execution import ExecutionReport, OrderResult
from ..models.trading import AccountBalance, TickerInfo, TradingSignal


class ExchangeProtocol(Protocol):
    """Exchange adapter interface.

    Implement this protocol for custom exchange adapters.
    All methods are async for non-blocking I/O.
    """

    @property
    def name(self) -> str:
        """Exchange name (e.g., 'binance', 'bybit')."""
        ...

    @property
    def is_connected(self) -> bool:
        """Check if connected to exchange."""
        ...

    async def connect(self) -> bool:
        """Connect to exchange API.

        Returns:
            True if connection successful.
        """
        ...

    async def disconnect(self) -> None:
        """Disconnect from exchange API."""
        ...

    async def get_ticker(self, symbol: str) -> TickerInfo:
        """Get current price for symbol.

        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')

        Returns:
            Current ticker info.
        """
        ...

    async def place_market_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        reduce_only: bool = False,
    ) -> OrderResult:
        """Place market order.

        Args:
            symbol: Trading pair
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            reduce_only: If True, only reduce position (futures)

        Returns:
            Order result with execution details.
        """
        ...

    async def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        price: str,
        time_in_force: str = "GTC",
    ) -> OrderResult:
        """Place limit order.

        Args:
            symbol: Trading pair
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            price: Limit price
            time_in_force: Order time in force (GTC, IOC, FOK)

        Returns:
            Order result with execution details.
        """
        ...

    async def cancel_order(self, symbol: str, order_id: str) -> bool:
        """Cancel an order.

        Args:
            symbol: Trading pair
            order_id: Order ID to cancel

        Returns:
            True if cancellation successful.
        """
        ...

    async def get_account_balance(self) -> AccountBalance:
        """Get account balance.

        Returns:
            Current account balance.
        """
        ...

    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for futures trading.

        Args:
            symbol: Trading pair
            leverage: Leverage value (1-125)

        Returns:
            True if successful.
        """
        ...

    async def calculate_quantity(
        self,
        symbol: str,
        usdt_amount: float,
        leverage: int = 1,
    ) -> str:
        """Calculate order quantity from USDT amount.

        Args:
            symbol: Trading pair
            usdt_amount: Amount in USDT
            leverage: Leverage to apply

        Returns:
            Formatted quantity string.
        """
        ...


class GRPCClientProtocol(Protocol):
    """gRPC client interface for Django communication."""

    @property
    def is_connected(self) -> bool:
        """Check if connected to gRPC server."""
        ...

    async def connect(self) -> bool:
        """Connect to gRPC server.

        Returns:
            True if connection successful.
        """
        ...

    async def disconnect(self) -> None:
        """Disconnect from gRPC server."""
        ...

    async def send_registration(self) -> bool:
        """Send bot registration to server.

        Returns:
            True if registration successful.
        """
        ...

    async def send_heartbeat(self) -> None:
        """Send heartbeat to server."""
        ...

    async def send_execution_report(self, report: ExecutionReport) -> bool:
        """Send execution report to server.

        Args:
            report: Execution report to send

        Returns:
            True if sent successfully.
        """
        ...

    async def receive_commands(self) -> AsyncIterator[BotConfig]:
        """Receive config commands from server.

        Yields:
            BotConfig updates from server.
        """
        ...


class SignalListenerProtocol(Protocol):
    """Signal listener interface for Redis pub/sub."""

    async def connect(self) -> bool:
        """Connect to signal source.

        Returns:
            True if connection successful.
        """
        ...

    async def disconnect(self) -> None:
        """Disconnect from signal source."""
        ...

    async def listen(self) -> AsyncIterator[TradingSignal]:
        """Listen for trading signals.

        Yields:
            Trading signals from source.
        """
        ...
