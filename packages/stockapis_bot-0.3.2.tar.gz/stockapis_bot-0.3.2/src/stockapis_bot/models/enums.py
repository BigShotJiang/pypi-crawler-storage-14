"""All enums for type safety - NO string literals in business logic."""

from enum import Enum


class SignalType(str, Enum):
    """Trading signal types from Telegram or other sources."""

    BUY = "BUY"
    SELL = "SELL"
    BUY_LONG = "BUY_LONG"
    SELL_SHORT = "SELL_SHORT"
    CLOSE_LONG = "CLOSE_LONG"
    CLOSE_SHORT = "CLOSE_SHORT"
    INFO = "INFO"


class OrderSide(str, Enum):
    """Order side - BUY or SELL."""

    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    """Order type for exchange."""

    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP_MARKET = "STOP_MARKET"
    STOP_LIMIT = "STOP_LIMIT"
    TAKE_PROFIT_MARKET = "TAKE_PROFIT_MARKET"


class OrderStatus(str, Enum):
    """Order execution status."""

    PENDING = "PENDING"
    NEW = "NEW"
    FILLED = "FILLED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class BotState(str, Enum):
    """Bot lifecycle state."""

    INITIALIZING = "INITIALIZING"
    CONNECTING = "CONNECTING"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    ERROR = "ERROR"


class SignalAction(str, Enum):
    """Trading signal actions (extracted from Telegram or other sources)."""

    BUY = "BUY"
    SELL = "SELL"
    SKIP = "SKIP"
    # Extended actions for Telegram signals
    PUMP = "PUMP"
    LISTING = "LISTING"
    BINANCE_LISTING = "BINANCE_LISTING"
    UNKNOWN = "UNKNOWN"


class MarketType(str, Enum):
    """Exchange market type."""

    SPOT = "spot"
    FUTURES = "futures"
    PERPETUAL = "perpetual"
    SWAP = "swap"


class Direction(str, Enum):
    """Trading direction preference."""

    LONG = "LONG"
    SHORT = "SHORT"
    BOTH = "BOTH"


class EventType(str, Enum):
    """Event types for internal bus."""

    SIGNAL = "SIGNAL"
    CONFIG_UPDATE = "CONFIG_UPDATE"
    HEARTBEAT = "HEARTBEAT"
    EXECUTION = "EXECUTION"
    ERROR = "ERROR"


class Environment(str, Enum):
    """Deployment environment.

    Built-in infrastructure configs are defined in models/config.py.
    Users only need to provide credentials (API keys) in .env.
    """

    DEV = "dev"      # localhost:50051, no TLS
    PROD = "prod"    # grpc.stockapis.com:443, TLS
