"""Event definitions for internal event bus."""

from datetime import datetime, timezone
from typing import Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from .config import BotConfig
from .enums import EventType
from .trading import TradingSignal


def utc_now() -> datetime:
    """Get current UTC time with timezone info."""
    return datetime.now(timezone.utc)


class BotEvent(BaseModel):
    """Base event class."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    event_id: UUID = Field(default_factory=uuid4)
    event_type: EventType
    timestamp: datetime = Field(default_factory=utc_now)


class SignalEvent(BotEvent):
    """Event carrying a trading signal."""

    event_type: EventType = Field(default=EventType.SIGNAL)
    signal: TradingSignal


class ConfigUpdateEvent(BotEvent):
    """Event carrying a config update."""

    event_type: EventType = Field(default=EventType.CONFIG_UPDATE)
    config: BotConfig
    previous_config: Optional[BotConfig] = Field(default=None)


class HeartbeatEvent(BotEvent):
    """Heartbeat event for connection monitoring."""

    event_type: EventType = Field(default=EventType.HEARTBEAT)
    sequence: int = Field(default=0)
    latency_ms: Optional[float] = Field(default=None)
