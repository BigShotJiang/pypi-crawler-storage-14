"""Pydantic v2 models for BotClient SDK."""

from .config import (
    BotConfig,
    ClientConfig,
    ExchangeConfig,
    GRPCConfig,
    RedisConfig,
    TradingParams,
)
from .enums import (
    BotState,
    Direction,
    MarketType,
    OrderSide,
    OrderStatus,
    OrderType,
    SignalAction,
    SignalType,
)
from .events import (
    BotEvent,
    ConfigUpdateEvent,
    EventType,
    HeartbeatEvent,
    SignalEvent,
)
from .execution import (
    ExecutionReport,
    OrderResult,
    SignalDecision,
)
from .trading import (
    AccountBalance,
    Order,
    Position,
    TickerInfo,
    TradingSignal,
)

__all__ = [
    # Enums
    "SignalType",
    "OrderSide",
    "OrderType",
    "OrderStatus",
    "BotState",
    "SignalAction",
    "MarketType",
    "Direction",
    # Config
    "ExchangeConfig",
    "GRPCConfig",
    "RedisConfig",
    "TradingParams",
    "BotConfig",
    "ClientConfig",
    # Trading
    "TradingSignal",
    "TickerInfo",
    "AccountBalance",
    "Order",
    "Position",
    # Execution
    "OrderResult",
    "ExecutionReport",
    "SignalDecision",
    # Events
    "EventType",
    "BotEvent",
    "SignalEvent",
    "ConfigUpdateEvent",
    "HeartbeatEvent",
]
