.. GraTools documentation master file, created by
   sphinx-quickstart on Fri Aug  2 13:48:06 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GraTools: a powerful tool for analyzing pangenome graphs
========================================================

.. image:: ./_static/GraTools_logo.png
   :alt: GraTools Logo

What's GraTools ?
-----------------

GraTools offered  **a set of commands for analyzing and handling pangenome graphs quickly, whatever the model and therefore the size
and the complexity of the GFA file.**

For example, GraTools allows to extract sequences or subgraphs, convert graphs into FASTA sequences, and identify shared and specific nodes across samples.
Additionally, it provides essential statistics for chromosomes and samples data.
With multi-threading support and flexible logging capabilities, GraTools is an efficient solution for pangenome graph analysis.

GraTools has been developed by IRD and CIRAD, as part of a collaboration between the `PANEEC <https://paneec.fr/>`_/DIADE and PHIM research teams.

.. image:: ./_static/paneec_small.png
   :target: https://paneec.fr/

.. image:: ./_static/ird_small.png
   :target: https://www.ird.fr/

.. image:: ./_static/cirad_small.jpg
   :target: https://www.cirad.fr/

.. toctree::
   :caption: Quick Start Guide
   :name: Quick Start Guide
   :maxdepth: 2

   quick_start.rst

This quick start guide for GraTools will help you get up and running with GraTools in no time.


How to use GraTools commands ?
------------------------------

GraTools is composed of multiple commands that can be invoked according the following syntax:

.. code-block:: bash

   GraTools [command] [options]

For example, to list the chromosomes per sample in a GFA file

.. code-block:: bash

   GraTools show_chr --gfa graph.gfa --full


.. toctree::
   :caption: Advanced Usage
   :name: Advanced Usage
   :maxdepth: 3

   commands/gratools_all
   commands/index
   commands/stats
   commands/list_samples
   commands/list_chr
   commands/extract_subgraph
   commands/get_fasta
   commands/core_dispensable_ratio
   commands/get_segment_by_depth
   commands/depth_nodes_stat
   commands/specific_groups_sample
   commands/shell_completion


.. toctree::
   :caption: GraTools for developers
   :name: GraTools for developers
   :maxdepth: 4

   module

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`



License
=======

GraTools is freely available under the [GNU General Public License, version 3 (GPLv3)](https://www.gnu.org/licenses/gpl-3.0.en.html).

Intellectual property belongs to `IRD <https://www.ird.fr>`_ , `CIRAD <https://www.cirad.fr/>`_ and previously cited authors.

Authors
=======

* Sébastien RAVEL (PHIM, CIRAD)
* Camille CARRETTE (DIADE, IRD/SYNGENTA)
* Nina MARTHE (DIADE, IRD)
* Mohamed MOURDAS (DIADE, IRD)
* François SABOT (DIADE, IRD)
* Christine TRANCHANT (DIADE, IRD)

Acknowledgments
===============

Thanks to Cécile Triay for the logo. Thanks to the  `i-trop plateform <https://bioinfo.ird.fr>`_, especially Ndomassi Tando, for the support.


Contact
============

If you have questions, requests, or bug reports, please contact to the GraTools mailing list : [gratools@ird.fr](mailto:gratools@ird.fr)