.. automodapi::  gratools
    :inherited-members:
    :no-inheritance-diagram:


.. autopydantic_model:: Graph
   :model-erdantic-figure:
   :model-erdantic-figure-collapsed: False