.. _gratools_doc:

GraTools: A Pangenome GFA Toolkit
==================================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry


Available Subcommands
---------------------

The `gratools` command provides an overview of all available subcommands, organized into logical sections.

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, color='forced')

Command Reference
-----------------

For detailed information on each command, including all options and examples, please see the individual documentation pages:

**Core Commands**
*   :ref:`index_doc`: Pre-processes a GFA file for all other operations.
*   :ref:`stats_doc`: Calculates and displays a wide range of statistics about the graph.

**GFA Content Information**
*   :ref:`list_samples_doc` (You'll need to create this page): Lists all sample names in the GFA.
*   :ref:`list_chr_doc` (You'll need to create this page): Lists all chromosomes/contigs per sample.

**GFA Data Extraction**
*   :ref:`extract_subgraph_doc`: Extracts a subgraph in GFA format based on a genomic region.
*   :ref:`get_fasta_doc`: Extracts sequences in FASTA format for a specific region.

**GFA Analysis**
*   :ref:`core_dispensable_ratio_doc`: Calculates the ratio of core and dispensable segments.
*   :ref:`depth_nodes_stat_doc`: Displays statistics about segment sharing across samples.
*   :ref:`specific_groups_sample_doc`: Identifies segments shared by or specific to defined sample groups.
*   :ref:`get_segments_by_depth_doc`: Lists segments based on how many samples share them.