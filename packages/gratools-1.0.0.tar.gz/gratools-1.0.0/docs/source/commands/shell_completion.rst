.. _shell_completion_doc:

gratools shell_completion
=========================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

Introduction
------------

Shell completion is a powerful feature that makes using command-line tools faster and easier. It allows you to auto-complete command names, options, and file paths by pressing the `Tab` key. The `shell_completion` command generates the necessary script to enable this for GraTools in your preferred shell (like Bash or Zsh).

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["shell_completion"], color='forced')

Setup Instructions
------------------

Follow these three steps to enable shell completion.

**Step 1: Generate the Completion Script**

Run the command, specifying your shell and a location to save the script. Saving it in your home directory is a simple option.

.. code-block:: bash

    $ gratools shell_completion --shell bash --output ~

    Completion script for bash generated: /home/your_user/gratools-completion.bash
    To enable completion, add the following line to your shell configuration file:

    # Add completion for gratools
    if [ -f "/home/your_user/gratools-completion.bash" ]; then
        . "/home/your_user/gratools-completion.bash"
    fi

**Step 2: Configure Your Shell**

Copy the lines provided in the output and paste them at the end of the appropriate configuration file for your shell. Common files are:

*   **Bash:** `~/.bashrc`
*   **Zsh:** `~/.zshrc`
*   **macOS (Bash):** You might need to use `~/.bash_profile`

.. admonition:: Important
    :class: warning

    You must adapt the path `/home/your_user/` to match your own username and the location where you saved the file.

**Step 3: Reload Your Shell Configuration**

For the changes to take effect, either close and reopen your terminal, or "source" your configuration file directly:

.. code-block:: bash

    # For Bash
    source ~/.bashrc

    # For Zsh
    source ~/.zshrc

How to Use Shell Completion
---------------------------

Once enabled, you can use the `Tab` key to complete different parts of a GraTools command.

**1. Complete Command Names**

Start typing a command and press `Tab` to see possible completions.

.. code-block:: bash

    $ gratools list_
    list_chr      list_samples

**2. Complete Option Names**

Type a command followed by `--` and press `Tab` to see all available options for that command.

.. code-block:: bash

    $ gratools get_fasta --

    --all-samples             --merge-dist              --output-file-suffix
    --chrom-query             --num-threads             --sample-query
    --gfa-file-path           --output-directory        --samples-list
    --log-path                --start-query             --stop-query
    --help                    ...

**3. Complete Option Values (e.g., File Paths)**

Completion also works for values, like file paths. This is extremely useful for avoiding typos.

.. code-block:: bash

    # Type this and press Tab
    $ gratools stats --gfa-file-path ./data-g

    # It will complete to:
    $ gratools stats --gfa-file-path ./data-gratools/