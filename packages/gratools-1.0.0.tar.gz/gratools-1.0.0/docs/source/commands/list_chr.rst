.. _list_chr_doc:

gratools list_chr
=================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["list_chr"], color='forced')


Usage Examples
--------------

* in a short format

.. code-block:: bash

    $ gratools list_chr --gfa Og_cactus.gfa.gz

    ────────────────────────────────── Summary ─────────────────────────────────────────
    Total samples: 5
    Min chromosomes per sample: 2
    Max chromosomes per sample: 2
                  5 Samples, 2-2 Unique Chromosomes/Sample (GFA: Og_cactus)
    ╭─────────────┬──────────────────────────────────────┬──────────────────────────────╮
    │ Sample Name │ Unique Chromosomes (Comma-separated) │ Number of Unique Chromosomes │
    ├─────────────┼──────────────────────────────────────┼──────────────────────────────┤
    │ CG14        │ CG14_Chr07, CG14_Chr08               │ 2                            │
    ├─────────────┼──────────────────────────────────────┼──────────────────────────────┤
    │ Og103       │ Og103_Chr07, Og103_Chr08             │ 2                            │
    ├─────────────┼──────────────────────────────────────┼──────────────────────────────┤
    │ Og182       │ Og182_Chr07, Og182_Chr08             │ 2                            │
    ├─────────────┼──────────────────────────────────────┼──────────────────────────────┤
    │ Og20        │ Og20_Chr07, Og20_Chr08               │ 2                            │
    ├─────────────┼──────────────────────────────────────┼──────────────────────────────┤
    │ Tog5681     │ Tog5681_Chr07, Tog5681_Chr08         │ 2                            │
    ╰─────────────┴──────────────────────────────────────┴──────────────────────────────╯

* with detailed information, including chromosome start and end positions

.. code-block:: bash

    $ gratools list_chr --gfa Og_cactus.gfa.gz --full

    ───────────────────────────────── Summary ────────────────────────────────
    Total samples: 5
    Total unique chromosomes: 10
    Total fragments: 23
    Min fragment length: 1,772,164 bp
    Max fragment length: 2,075,321 bp
    Average fragment length: 11,330,633.22 bp
     5 Samples, 2-2 Chromosomes/Sample (GFA: Og_cactus) - Full Fragment List
    ╭─────────────┬──────────────────────────┬────────────────┬──────────────╮
    │ Sample Name │ Chromosome Fragment Name │ Fragment Start │ Fragment End │
    ├─────────────┼──────────────────────────┼────────────────┼──────────────┤
    │ CG14        │ CG14_Chr07               │              0 │   26,599,614 │
    │             │ CG14_Chr08               │              0 │   25,472,747 │
    ├─────────────┼──────────────────────────┼────────────────┼──────────────┤
    │ Og103       │ Og103_Chr07              │         23,875 │   12,687,580 │
    │             │ Og103_Chr07              │     12,866,628 │   13,747,795 │
    │             │ Og103_Chr07              │     13,903,795 │   27,060,440 │
    │             │ Og103_Chr08              │         30,268 │   25,689,516 │
    ├─────────────┼──────────────────────────┼────────────────┼──────────────┤
    │ Og182       │ Og182_Chr07              │         16,376 │   26,829,393 │
    │             │ Og182_Chr08              │         11,495 │   25,639,462 │
    ├─────────────┼──────────────────────────┼────────────────┼──────────────┤
    │ Og20        │ Og20_Chr07               │         13,644 │    1,772,164 │
    │             │ Og20_Chr07               │      1,890,766 │   13,326,301 │
    │             │ Og20_Chr07               │     13,432,358 │   26,556,933 │
    │             │ Og20_Chr08               │         33,688 │   25,577,180 │
    ├─────────────┼──────────────────────────┼────────────────┼──────────────┤
    │ Tog5681     │ Tog5681_Chr07            │         22,457 │    9,322,325 │
    │             │ Tog5681_Chr07            │      9,748,285 │    9,764,302 │
    │             │ Tog5681_Chr07            │      9,907,780 │    9,939,241 │
    │             │ Tog5681_Chr07            │     10,023,782 │   13,034,997 │
    │             │ Tog5681_Chr07            │     13,211,081 │   14,101,598 │
    │             │ Tog5681_Chr07            │     14,241,787 │   25,016,640 │
    │             │ Tog5681_Chr07            │     25,052,306 │   25,203,063 │
    │             │ Tog5681_Chr07            │     25,411,687 │   25,413,700 │
    │             │ Tog5681_Chr07            │     25,481,734 │   27,557,055 │
    │             │ Tog5681_Chr08            │          9,084 │   16,374,127 │
    │             │ Tog5681_Chr08            │     16,391,988 │   25,643,255 │
    ╰─────────────┴──────────────────────────┴────────────────┴──────────────╯


* save in a tabular file

.. code-block:: bash

    $ gratools list_chr --gfa Og_cactus.gfa.gz --full --save


