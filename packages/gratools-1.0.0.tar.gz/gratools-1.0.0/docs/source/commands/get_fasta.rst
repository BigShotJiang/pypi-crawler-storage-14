.. _get_fasta_doc:

gratools get_fasta
==================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

The `get_fasta` command extracts sequences from a GFA graph for a specific genomic region and saves them in FASTA format. The region is defined using the coordinates of a single *query sample*, but the command can extract the corresponding sequences for that sample, a list of other samples, or all samples in the graph.

This command is essentially a convenient wrapper around `extract_subgraph` that is optimized for generating FASTA output directly.

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["get_fasta"], color='forced')


Usage Examples
--------------

Extracting a sequence for a specific sample and region
......................................................

This example extracts the sequence for the sample `CG14` in the region from 10,000 to 15,000 on its chromosome `CG14_Chr07`.

.. code-block:: bash

    $ gratools get_fasta -g Og_cactus.gfa.gz \
        --sample-query CG14 --chrom-query CG14_Chr07 --start-query 10000 --stop-query 15000
    GLOBAL: Samples progression: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 1/1
    CG14: End processing         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
    Saving in Og_cactus_subgraph_CG14-CG14_Chr07-10000-15000.fasta

Extracting sequences for all samples included in the graph
..........................................................

This command uses the same region defined by `CG14`'s coordinates but extracts the corresponding sequences for **all** samples in the graph using the `--all-samples` flag.

.. code-block:: bash

    $ gratools get_fasta -g Og_cactus.gfa.gz \
        --sample-query CG14 --chrom-query CG14_Chr07 --start-query 10000 --stop-query 15000 \
        --all-samples --threads 8
    GLOBAL: Samples progression: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 4/4
    Og20: End processing         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
    Og103: End processing        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
    Og182: End processing        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
    Tog5681: End processing      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
    Saving in Og_cactus_subgraph_CG14-CG14_Chr07-10000-15000.fasta

Extracting sequences for a list of samples provided in a file
.............................................................

Here, we provide a file containing a list of sample names to extract using the `--samples-list` option.

.. code-block:: bash

        $ cat list_samples2extract.txt
        Og20
        Og103

        $ gratools get_fasta -g Og_cactus.gfa.gz \
            --sample-query CG14 --chrom-query CG14_Chr07 --start-query 10000 --stop-query 15000 \
            --samples-list list_samples2extract.txt
        GLOBAL: Samples progression: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 2/2
        Og20: End processing         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
        Og103: End processing        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5
        Saving in Og_cactus_subgraph_CG14-CG14_Chr07-10000-15000.fasta


Illustrated Example
-------------------

.. admonition::  Understanding the Process

   1. **Linear Reference Coordinate:** The ``--sample-query`` and ``--chrom-query`` options specify the coordinate system. The ``--start-query`` and ``--stop-query`` options define the region of interest *within that coordinate*.

      .. graphviz:: ../dot_files/sequences.dot

   2. **Pangenome Graph:** The graph contains nodes (sequences) and edges (connections).  The linear reference guides the traversal of the graph. Different samples might have variations in this region. The blue path in the graph represents the linear reference path used for extraction.

      .. graphviz:: ../dot_files/pan_graph.dot

   3. **Extracted Sequence:** ``get_fasta`` follows the paths in the graph corresponding to the specified region, generating a FASTA sequence for each selected sample.  The example below shows the extraction for  `sample=reference`, `chromosome=region`, `start=4`, and `end=18`.

      .. graphviz:: ../dot_files/pan_graph_sub.dot


   The following diagram illustrates how the linear reference guides sequence extraction from the pangenome graph:

      .. graphviz:: ../dot_files/sub_sequences.dot