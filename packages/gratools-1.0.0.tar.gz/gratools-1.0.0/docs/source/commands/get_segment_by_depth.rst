.. _get_segments_by_depth_doc:

gratools get_segments_by_depth
==============================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

This command lists or saves segments (nodes) that are shared by a number of samples falling within a specific range (e.g., core segments shared by >95% of samples, or private segments found in only one sample). The range can be defined either by absolute numbers of samples or by percentages.

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["get_segments_by_depth"], color='forced')

Usage Examples
--------------

List segments shared by a number of individuals and save to a file
...................................................................

This example finds all segments shared by 2 or fewer individuals and saves the list to a CSV file (which is the default behavior).

.. code-block:: bash

    $ gratools get_segments_by_depth -g Og_cactus.gfa.gz \
        --input-as-number --lower-bound 0 --upper-bound 2

    |  INFO     | Parameters: lower=0; upper=2; filter_len=0
    |  INFO     | Generate CSV file Og_cactus_segment_by_depth_between_0-2_individuals.csv
    |  INFO     | Number of segments found: 891345 between 0 and 2 individuals

List core segments (by percentage) and display them in the terminal
....................................................................

This example identifies core segments, defined as those present in 95% to 100% of the samples, and prints the list directly to the terminal instead of saving it to a file.

.. code-block:: bash

    $ gratools get_segments_by_depth -g Og_cactus.gfa.gz \
        --input-as-percentage --lower-bound 95% --upper-bound 100% --display-to-terminal

    |  INFO     | Parameters: lower=95.0%; upper=100.0%; filter_len=0
    |  INFO     | Segments found: 660741
    Segment
    5
    6
    7
    ...

Illustrated Example
-------------------

.. admonition:: Understanding the Process

   1.  **Input Mode:** The user must specify whether the bounds are numbers or percentages.
       -   With ``--input-as-percentage``, you can specify ``--lower-bound 0% --upper-bound 20%`` to get a list of segments found in 20% or fewer of the samples.
       -   With ``--input-as-number``, you specify the exact lower and upper bounds for the number of individuals sharing the segments.

   2.  **Get Core Genome Segments:** The command ``get_segments_by_depth --input-as-number --lower-bound 4 --upper-bound 5`` will extract a list of segments shared by exactly 4 or 5 individuals.

       .. image:: ../png_files/get_segment_diagram_2.png
         :width: 500
         :alt: get_segment command example 1

   3.  **Get Dispensable Genome Segments:** The command ``get_segments_by_depth --input-as-number --lower-bound 0 --upper-bound 2`` will extract segments shared by 0, 1, or 2 individuals.

       .. image:: ../png_files/get_segment_diagram_1.png
         :width: 500
         :alt: get_segment command example 2

   4.  **Length Filter:** The ``--filter-len`` (``-fl``) option applies a filter to only include segments that are longer than the specified integer value.