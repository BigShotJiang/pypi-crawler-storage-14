.. _index_doc:

gratools index
===============

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

The `index` command is a critical first step for using GraTools efficiently.
It pre-processes a GFA file to create several auxiliary files that allow other commands to access graph data much faster.
It is highly recommended to run `index` on your GFA file before using other analysis or extraction commands, especially with large graphs.

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["index"], color='forced')


Usage Examples
--------------

**1. Basic Indexing**

This is the simplest way to create an index. GraTools will create an index directory named after the GFA file (e.g., `Og_cactus.gfa.gz.Gratools_index/`).

.. code-block:: bash

    $ gratools index --gfa Og_cactus.gfa.gz

**2. Indexing with Link Information and Multiple Threads**

For some analyses, indexing the links between segments can be useful. You can also specify the number of threads to speed up the process.

.. code-block:: bash

    $ gratools index --gfa Og_cactus.gfa.gz --index-links --threads 8


What `index` Does
-------------------

The indexing process parses the GFA file once and stores the information in optimized formats.
This avoids re-parsing the entire GFA for every subsequent command, leading to significant performance gains.

When you run `index`, GraTools performs the following actions:

1.  **Parses Segments (S-lines):** Creates a BAM file representing all segments, which is efficient for random access.
2.  **Parses Walks (W-lines):** Creates BED files for each sample, mapping their paths to the segments.
3.  **Calculates Basic Statistics:** Generates a summary of the graph's properties.
4.  **(Optional) Indexes Links (L-lines):** If `--index-links` is used, it stores link information in a database for faster connectivity queries.

All these generated files are stored together in the GraTools index directory. If an index already exists, other GraTools commands will automatically detect and use it.



