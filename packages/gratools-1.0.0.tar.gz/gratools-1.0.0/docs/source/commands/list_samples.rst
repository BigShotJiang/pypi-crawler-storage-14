.. _list_samples_doc:

gratools list_samples
=====================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["list_samples"], color='forced')


Usage Examples
--------------

.. code-block:: bash

    $ gratools list_samples --gfa Og_cactus.gfa.gz
    ─────────────────────────────── Summary ────────────────────────────────
    Total samples in GFA: 5
       Available
    Samples in GFA:
       Og_cactus
    ╭─────────────╮
    │ Sample Name │
    ├─────────────┤
    │ CG14        │
    │ Og20        │
    │ Og103       │
    │ Og182       │
    │ Tog5681     │
    ╰─────────────╯

