.. _depth_nodes_stat_doc:

gratools depth_nodes_stat
=============================

.. contents:: Table of Contents
   :depth: 2
   :backlinks: entry

Options
-------

.. click:run::
    from gratools.main import main_command as gratools_cmd
    invoke(gratools_cmd, args=["depth_nodes_stat"], color='forced')

Usage Examples
--------------

Display statistics about the node depth
.......................................

This command analyzes how many samples share each segment (node) in the graph and presents a summary table.

.. code-block:: bash

    $ gratools depth_nodes_stat --gfa Og_cactus.gfa.gz --filter-len 50 --threads 4

    ────────────────  Summary ────────────────────────────────────────
    Total segments analyzed: 2,354,995
    Total segments passing length filter: 210,046 (8.92%)

              Node Depth Statistics — Og_cactus (Len ≥ 50bp)
    ╭───────┬──────────┬────────────┬───────────────────┬────────────╮
    │ Depth │ Segments │ Percentage │ Filtered Segments │ Filtered % │
    ├───────┼──────────┼────────────┼───────────────────┼────────────┤
    │   1   │ 575,292  │   24.43%   │       1,257       │   0.60%    │
    │   2   │ 316,053  │   13.42%   │       7,345       │   3.50%    │
    │   3   │ 301,588  │   12.81%   │       5,604       │   2.67%    │
    │   4   │ 501,321  │   21.29%   │      11,500       │   5.47%    │
    │   5   │ 660,741  │   28.06%   │      184,340      │   87.76%   │
    ╰───────┴──────────┴────────────┴───────────────────┴────────────╯

.. admonition:: Columns Explanation

    1.  **Depth**: The number of unique samples that a segment is found in. For example, a depth of `1` means the segment is private to a single sample.
    2.  **Segments**: The total count of segments at that specific depth.
    3.  **Percentage**: The proportion of segments at this depth relative to the **total number of segments** in the GFA.
    4.  **Filtered Segments**: The count of segments at this depth that are longer than the size specified by the ``--filter-len`` option.
    5.  **Filtered %**: The proportion of filtered segments at this depth relative to the **total number of filtered segments** (shown in the summary header).

.. admonition:: Filter Option

    The ``--filter-len`` (or ``-fl``) option takes an integer value. This value is used to populate the **Filtered Segments** and **Filtered %** columns. In the example above, a filter of `50` was used, meaning these columns only account for segments that are 50 base pairs or longer.