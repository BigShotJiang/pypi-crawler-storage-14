from os import listdir
from os.path import isfile, join

# This script reads the output files of gratools, and gives the values for the venn diagram that compares the populations indica and japonica.
# The values outputed are used in the R script print_venn_gratools.R

def prep_files(directory_path,group):
    onlyfiles = [f for f in listdir(directory_path) if isfile(join(directory_path, f))] # files in the directory with gratools output (specific and shared segments/nodes from the two populations)
    only_specific=[f for f in onlyfiles if "specific" in f] # files with segments specific to an individual from the population (indica or japonica)
    specific_paths=[directory_path+'/'+f for f in only_specific]
    print(f"For group {group} :")
    print(f"Found {len(specific_paths)} files with specific segments")

    # sort specific files according to the three filter values
    filter_0=[f for f in specific_paths if "_0.csv" in f]
    filter_2=[f for f in specific_paths if "_2.csv" in f]
    filter_50=[f for f in specific_paths if "_50.csv" in f]

    print(f"{len(filter_0)} files correspond to filter 0, {len(filter_2)} to filter 2 and {len(filter_50)} to filter 50")

    # compute count and cumulated length for segments specific to the population, for the three filter values
    seg_count_0,seg_len_0=unique_seg(filter_0)
    seg_count_2,seg_len_2=unique_seg(filter_2)
    seg_count_50,seg_len_50=unique_seg(filter_50)

    print(f"For filter 0, {seg_count_0:,} unique segments found, with a total length of {seg_len_0:,} bp")
    print(f"For filter 2, {seg_count_2:,} unique segments found, with a total length of {seg_len_2:,} bp")
    print(f"For filter 50, {seg_count_50:,} unique segments found, with a total length of {seg_len_50:,} bp\n")

def unique_seg(paths):
    all_seg=set()
    cumul_length=0
    # for each file, go through all its segments and add it to the count/cumul length of the segment is new (hasn't been encountered in a previous file) -> only count unique segments.
    for file_path in paths:
        with open(file_path) as file:
            for line in file:
                if line[0]!='#' and line[0]!="N":
                    seg_id=line.split(',')[0]
                    if seg_id not in all_seg:
                        all_seg.add(seg_id)
                        seg_pos=line.split(';')[0].split(':')[1]
                        seg_start,seg_stop=seg_pos.split('-')
                        seg_len=int(seg_stop)-int(seg_start)
                        cumul_length+=seg_len

    return len(all_seg),cumul_length

print(f"Counting the segments that are present in one group but completely absent from the other (indica vs japonica)\n")

dir_path_ind="output_ind/GraTools-output_NewRiceGraph_MGC"
dir_path_jap="output_jap/GraTools-output_NewRiceGraph_MGC"
prep_files(dir_path_ind,"indica")
prep_files(dir_path_jap,"japonica")
