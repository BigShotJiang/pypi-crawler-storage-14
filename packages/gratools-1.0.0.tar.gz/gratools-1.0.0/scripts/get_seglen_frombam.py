from pysam import AlignedSegment, AlignmentFile, index, qualitystring_to_array, view
from tqdm import tqdm

# This script retrieves the segments that are covered by 11, 12 or 13 genomes in the graph, that correspond to 80%, 90% and 100% of genomes.
# It gives the count and cumulated length of these segments, with no filter on segment length, or filter at 2 or 50 bp.
# The values outputed are used in the R script print_core_gratools.R
# The script also gives the total length of segments for two filter values, used in R script print_venn_gratools.R

bam_path="NewRiceGraph_MGC_GraTools_INDEX/bam_files/NewRiceGraph_MGC.bam"

total_filter2_len=0
total_filter50_len=0
total_cov11_count=[0,0,0] # filter 0, 2, 50
total_cov12_count=[0,0,0] # filter 0, 2, 50
total_cov13_count=[0,0,0] # filter 0, 2, 50
total_cov11_len=[0,0,0] # filter 0, 2, 50
total_cov12_len=[0,0,0] # filter 0, 2, 50
total_cov13_len=[0,0,0] # filter 0, 2, 50

with AlignmentFile(bam_path, "rb", check_sq=False) as bam_file:
    for segment in tqdm(bam_file.fetch(until_eof=True), total=26461214): # total = number of segments in the graph
        segments_missing_sw_tag=0
        if not segment.has_tag("SW"):
            segments_missing_sw_tag += 1
            continue  # Skip segments without SW tag for depth calculation

	# get all the genomes that cover this segment
        sw_tag_value = segment.get_tag("SW")
        unique_samples_for_segment = set(s.split(";")[0] for s in sw_tag_value.split(',') if s)
        current_segment_depth = len(unique_samples_for_segment)
	
	# get the length of the segment, and store it according to its size (filter) and its coverage (number of genomes that cover it)
        seg_length = segment.query_length

        if seg_length>=2:
            total_filter2_len+=seg_length
            if seg_length>=50:
                total_filter50_len+=seg_length

        if current_segment_depth>=11:
            total_cov11_len[0]+=seg_length
            total_cov11_count[0]+=1
            if seg_length>=2:
                total_cov11_len[1]+=seg_length
                total_cov11_count[1]+=1
                if seg_length>=50:
                    total_cov11_len[2]+=seg_length
                    total_cov11_count[2]+=1
            if current_segment_depth>=12:
                total_cov12_len[0]+=seg_length
                total_cov12_count[0]+=1
                if seg_length>=2:
                    total_cov12_len[1]+=seg_length
                    total_cov12_count[1]+=1
                    if seg_length>=50:
                        total_cov12_len[2]+=seg_length
                        total_cov12_count[2]+=1
                if current_segment_depth>=13:
                    total_cov13_len[0]+=seg_length
                    total_cov13_count[0]+=1
                    if seg_length>=2:
                        total_cov13_len[1]+=seg_length
                        total_cov13_count[1]+=1
                        if seg_length>=50:
                            total_cov13_len[2]+=seg_length
                            total_cov13_count[2]+=1


print(segments_missing_sw_tag)
# total length filter 0 is the total size of the graph
print(total_filter2_len)
print(total_filter50_len)
print(total_cov11_count, total_cov11_len)
print(total_cov12_count, total_cov12_len)
print(total_cov13_count, total_cov13_len)
