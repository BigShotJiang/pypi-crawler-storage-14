library("VennDiagram")

compute_venn <- function(list_values){
  shared=list_values[3]
  indica=list_values[1]+shared
  japonica=list_values[2]+shared
  total=sum(list_values)
  draw.pairwise.venn(area1=indica, area2=japonica, cross.area=shared, category=c("Indica", "Japonica"),fill = c("darkorchid","chocolate2"),lty = "solid",scaled=T, ext.text = FALSE, alpha=c(0.6,0.6))
}


# indica, japonica, shared
filter0_count=c(6568775, 3377329, 16515110)
filter0_len=c(327950177, 151658662, 378808206)
filter2_count=c(1294085, 482308, 8371302)
filter2_len=c(322675487, 148763641, 370664398)
filter50_count=c(287519, 99845, 1846427)
filter50_len=c(312319101, 145807641, 273608982)

# count
grid.newpage();compute_venn(filter0_count)
grid.newpage();compute_venn(filter2_count)
grid.newpage();compute_venn(filter50_count)
# length
grid.newpage();compute_venn(filter0_len)
grid.newpage();compute_venn(filter2_len)
grid.newpage();compute_venn(filter50_len)
