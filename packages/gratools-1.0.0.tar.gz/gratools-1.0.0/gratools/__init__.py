"""
Main package module for gratools.

:no-index:

Contains core classes and functions for GraTools.
"""

from importlib.metadata import version
from gratools.Graph import AsyncGfaDatabase, SubGraph, GFA, GratoolsBam
from gratools.logger_config import ThreadedRichHandler, configure_logger, update_logger_file_suffix
from gratools.useful_function import CustomCommand, CustomGroup, validate_percentage_or_int


def get_version() -> str:
    """
    Retrieve the version of the gratools package.

    Returns:
        str: The version of the gratools package.
    """
    return version("gratools")


__version__ = get_version()

header_tool = rf"""[bright_blue]
Welcome to GraTools version: '{__version__}'
@author: GraTools team's[bright_cyan]
        ____                 __________               ____          
      6MMMMMb/               MMMMMMMMMM               `MM          
     8P    YM               /   MM     \               MM          
    6M      Y ___  __    ___    MM   _____     _____   MM   ____   
    MM        `MM 6MM  6MMMMb   MM  6MMMMMb   6MMMMMb  MM  6MMMMb\ 
    MM         MM69 " 8M'  `Mb  MM 6M'   `Mb 6M'   `Mb MM MM'    ` 
    MM     ___ MM'        ,oMM  MM MM     MM MM     MM MM YM.      
    MM     `M' MM     ,6MM9'MM  MM MM     MM MM     MM MM  YMMMMb  
    YM      M  MM     MM'   MM  MM MM     MM MM     MM MM      `Mb 
     8b    d9  MM     MM.  ,MM  MM YM.   ,M9 YM.   ,M9 MM L    ,MM 
      YMMMMM9  _MM_   `YMMM9'Yb_MM_ YMMMMM9   YMMMMM9 _MM_MYMMMM9 
        \                                    /                /
        /''[bright_red]A[/bright_red]''\          /''''''\           /     /''''[bright_red]A[/bright_red]'''''\
  ...[bright_yellow]G[/bright_yellow][bright_green]C[/bright_green]|       |..[bright_red]A[/bright_red][bright_blue]T[/bright_blue][bright_yellow]G[/bright_yellow]...[bright_green]C[/bright_green]...[bright_green]C[/bright_green][bright_yellow]G[/bright_yellow]...[bright_blue]T[/bright_blue]....[bright_blue]T[/bright_blue][bright_red]A[/bright_red][bright_yellow]G[/bright_yellow]..'..[bright_yellow]G[/bright_yellow][bright_green]C[/bright_green].|            |...
        \..[bright_green]C[/bright_green]../      \.............../            \...[bright_blue]T[/bright_blue][bright_red]A[/bright_red][bright_blue]T[/bright_blue][bright_red]A[/bright_red].../[/bright_cyan]
 
Please cite our gitlab: https://forge.ird.fr/diade/gratools.git[/bright_blue]\
"""

__all__ = [
    "AsyncGfaDatabase",
    "SubGraph",
    "GFA",
    "GratoolsBam",
    "Gratools",
    "ThreadedRichHandler",
    "configure_logger",
    "update_logger_file_suffix",
    "CustomCommand",
    "CustomGroup",
    "validate_percentage_or_int",
    # …any other modules or functions you want documented…
]
