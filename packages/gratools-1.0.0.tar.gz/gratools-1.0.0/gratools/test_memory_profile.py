from memory_profiler import profile
from gratools.main import main_command
import cProfile
import pstats
import sys
import yappi

@profile
def run_gratools():
    # Simule la ligne de commande
    # sys.argv = [
    #     "gratools",
    #     "extract_subgraph",
    #     "--sample-query", "CG14",
    #     "--chrom-query", "CG14_Chr07",
    #     "--start-query", "10000",
    #     "--stop-query", "15000",
    #     "--all-samples",
    #     "--threads", "6",
    #     "-g", "/media/work/GIT/data-gratools/Rice/Og_cactus.gfa",  # adapte ce chemin si besoin
    #     "--build-fasta"
    # ]
    # sys.argv = [
    #     "gratools",
    #     "index",
    #     "--threads", "12",
    #     "-g", "/shared/home/sravel/GIT/data-gratools/Rice/NewRiceGraph_MGC.gfa.gz",  # adapte ce chemin si besoin
    #
    # ]
    sys.argv = [
        "gratools",
        "index",
        "--threads", "24",
        "-g", "/shared/home/sravel/GIT/data-gratools/Rice/Og_cactus.gfa.gz",  # adapte ce chemin si besoin

    ]

    # sys.argv = [
    #     "gratools",
    #     "extract_subgraph",
    #     "--sample-query", "OsIR64RS1",
    #     "--chrom-query", "CM020884.1_OsIR64RS1_chromosome9",
    #     "--all-samples",
    #     "--threads", "12",
    #     "-g", "/media/work/GIT/data-gratools/Rice/NewRiceGraph_MGC.gfa.gz",  # adapte ce chemin si besoin
    #
    # ]

    # Enregistre le profil CPU dans un fichier
    profiler = cProfile.Profile()
    profiler.enable()
    # yappi.set_clock_type("wall")  # ou "wall" selon ce qu'on veut mesurer
    yappi.set_clock_type("cpu")  # ou "wall" selon ce qu'on veut mesurer
    yappi.start()

    try:
        print(">> Appel de main_command()...")
        main_command()
        print(">> Fin de main_command()")
    finally:
        profiler.disable()
        profiler.dump_stats("gratools_profile.prof")
        print("\n✅ Profil sauvegardé dans gratools_profile.prof")

        yappi.stop()
        # Affiche un résumé
        stats = yappi.get_func_stats()
        stats.sort("ttot")

        # Écrire les résultats dans un fichier
        with open("gratools_yappi_stats.txt", "w") as f:
            for stat in stats:
                if stat.ttot > 0.1:  # Seuil de 0.1 secondes
                    f.write(f"{stat}\n")
        print("Profil CPU multithread sauvé dans gratools_yappi_stats.txt")

        # Analyser les résultats de cProfile avec pstats
        p = pstats.Stats("gratools_profile.prof")
        p.sort_stats(pstats.SortKey.CUMULATIVE).print_stats(50)  # Afficher les 20 fonctions les plus longues

if __name__ == "__main__":
    run_gratools()
