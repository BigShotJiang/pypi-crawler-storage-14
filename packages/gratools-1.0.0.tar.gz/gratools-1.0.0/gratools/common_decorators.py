# Standard library imports
from functools import wraps # For creating decorators
from pathlib import Path # For type hinting Path objects
from typing import Callable # For type hinting callables (functions, methods)

# Third-party imports
import click # For click.Path and click.Choice
from cloup import option, option_group # For defining CLI options and groups

# Define available logging levels for user choice
# This constant can be set up through the --verbosity option.
LOG_LEVELS = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] # Added WARNING and CRITICAL

# ===============================================
# COMMON OPTIONS FOR GFA FILE AND OUTPUT HANDLING
# ===============================================
# This list defines the frequently used options across the different GraTools commands
# related to the GFA file input and the general output parameters.
# These can be spread onto commands using `*option_GFA`.

LOG_LEVELS = ['DEBUG', 'INFO', 'ERROR']

options_for_gfa_handling = [ # Renamed from option_GFA for clarity
    option(
        "--gfa",
        "-g",
        "gfa_file_path", # Explicit destination variable name
        type=click.Path(
            exists=True,      # File must exist
            readable=True,    # File must be readable
            resolve_path=True,# Resolve to an absolute path
            path_type=Path    # Convert value to a Path object
        ),
        required=True, # This option is mandatory for commands using it
        help="Path to the input GFA file (e.g., myGraph.gfa or myGraph.gfa.gz).",
    ),
    option(
        "--outdir",
        "-o",
        "output_directory", # Explicit destination variable name
        type=click.Path(
            file_okay=False,  # Must be a directory
            writable=True,    # Directory must be writable
            resolve_path=True,
            path_type=Path
        ),
        default=None, # If set at None, Gratools class might default to GFA file's parent directory
        required=False,
        help="Output directory for GraTools results. If not specified, results are typically "
             "placed in a subdirectory within the GFA file's parent directory "
             "(e.g., 'GraTools-output_<gfa_name>').",
    ),
    option(
        "--suffix",
        "-su", # Consider a more descriptive short option if possible, e.g., -sfx
        "output_file_suffix", # Explicit destination variable name
        default=None, # Defaulting to None might be cleaner; Gratools can then generate one if needed.
                      # An empty string default "" is also fine.
        type=str,
        required=False,
        help="Custom suffix to append to output filenames. If not provided, a default "
             "suffix will be generated based on the command line parameters.",
    )
]


# ===============================================
# DECORATOR FOR COMMON LOGGING AND PERFORMANCE OPTIONS
# ===============================================
# This decorator function is designed to be applied to Click/Cloup command functions.
# It adds standard option groups for performance (threads) and logging (verbosity, log path)
# to the decorated command.

def common_options_decorator(func: Callable) -> Callable:
    """
    A decorator that applies common option groups (Performance, Logging)
    to a Click/Cloup command function.

    Args:
        func (Callable): The command function to be decorated.

    Returns:
        Callable: The decorated command function, now equipped with
                  the common performance and logging options.
    """

    # Apply Performance Options Group
    func = option_group( # This will be the innermost option group applied
        "Performance Options", # Title of the option group in help output
        option(
            "--threads",
            "-t",
            "num_threads", # Explicit destination variable name
            type=int,
            default=1,
            show_default=True, # Show the default value in help
            required=False,
            help="Number of threads to be used for parallelizable operations.",
        )
        # Add other performance-related options here if needed
    )(func)

    # Apply Logging Options Group
    func = option_group( # This will be applied after Performance Options
        "Logging Options", # Title of the option group
        option(
            "--verbosity",
            "-vv", # Common short option for verbosity
            "log_verbosity_level", # Explicit destination variable name
            default="INFO",
            show_default=True,
            type=click.Choice(LOG_LEVELS, case_sensitive=False), # Use the defined LOG_LEVELS
            required=False,
            help="Set the logging verbosity level.",
        ),
        option(
            "--log-path",
            "-l", # Consider if -l is used by other options; could be --log-dir
            "log_file_directory", # Explicit destination variable name
            default=None, # If None, Gratools might default to a subdir in outdir or works_path
            type=click.Path(
                file_okay=False, # Must be a directory
                writable=True,
                resolve_path=True,
                path_type=Path
            ),
            required=False,
            help="Directory where the log files will be saved. If not specified, logs will be "
                 "placed in the main output directory (or in a default GraTools log location).",
        )
    )(func)



    return func