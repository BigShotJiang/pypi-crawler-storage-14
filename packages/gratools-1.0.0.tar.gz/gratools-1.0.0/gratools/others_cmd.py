# Standard library imports
from pathlib import Path
from random import choice  # For secret_command
from subprocess import check_output  # For shell_completion
from time import sleep  # For secret_command
from typing import Optional  # For type hinting output parameter

# Third-party imports
import click
from cloup import command, option  # Using cloup.command for shell_completion
from rich.live import Live  # For secret_command animation
from rich.panel import Panel  # For secret_command animation

# Local application/library specific imports
from .useful_function import CustomCommand  # Your custom command class
from .logger_config import shared_console  # For final print in secret_command


@command(
    "shell_completion",
    cls=CustomCommand,
    short_help="Generates shell completion scripts (Bash, Zsh, Fish).",
    help="""
    Generates shell completion scripts for GraTools. This enables
    autocompletion for commands, options, and arguments in your terminal,
    making it easier and faster to use the GraTools CLI.

    Supported shells: Bash, Zsh, Fish.

    After generating the script, you'll need to source it or place it
    in the appropriate directory for your shell to activate autocompletion.
    Instructions will be provided upon script generation.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/shell_completion.html
    """,
    no_args_is_help=True,
)
@option(
    "--shell",
    type=click.Choice(["bash", "zsh", "fish"], case_sensitive=False),
    required=True,
    help="Specify your shell type (bash, zsh, or fish) to generate the appropriate completion script.",
)
@option(
    "--output-file",
    "output_filepath_str",
    type=click.Path(writable=True, resolve_path=True, path_type=Path),
    required=False,  # Making it optional, will default to current directory
    help="Specify the full path (including filename) to save the generated completion script. "
         "If not provided, defaults to 'gratools-completion.<shell>' in the current directory.",
)
def shell_completion_command(shell: str, output_filepath_str: Optional[Path]) -> None:
    """
    Generates and saves a shell completion script for GraTools.

    This command leverages Click's built-in completion generation mechanism.
    It outputs the script and provides instructions on how to enable it for
    the specified shell.

    Args:
        shell (str): The target shell (bash, zsh, or fish).
        output_filepath_str (Optional[Path]): The desired output file path for the script.
                                               If None, a default name in the current directory is used.
    """
    shell = shell.lower()  # Ensure consistent casing

    # Determine the output filename
    if output_filepath_str:
        output_file_path = output_filepath_str
        # Ensure parent directory exists if a full path is given
        try:
            output_file_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            click.echo(f"Error: Could not create parent directory for '{output_file_path}': {e}", err=True)
            raise click.Abort()
    else:
        default_filename = f"gratools-completion.{shell}"
        output_file_path = Path.cwd() / default_filename

    click.echo(f"Generating completion script for {shell} shell...")

    # Environment variable `_GRATOOLS_COMPLETE` is how Click's completion system is triggered.
    # The value `{shell}_source` tells Click to output the full source script for that shell.
    # `gratools` is the name of your main Click command/group.
    env_var_name = "_GRATOOLS_COMPLETE"  # Click convention for program name in uppercase
    command_to_run = f"{env_var_name}={shell}_source gratools"

    try:
        completion_script_content = check_output(
            command_to_run,
            shell=True,  # Necessary for environment variable setting like this
            #executable="/bin/bash",
            text=True,  # Decodes output as text
        )
    except Exception as e:
        click.echo(f"Error generating completion script: {e}", err=True)
        click.echo("Ensure 'gratools' is callable in your current environment (e.g., installed or in PATH).", err=True)
        raise click.Abort()

    try:
        with output_file_path.open("w", encoding="utf-8") as f:
            f.write(completion_script_content)
        click.echo(f"Successfully generated completion script for {shell} at: {output_file_path.resolve()}")
    except IOError as e:
        click.echo(f"Error: Could not write completion script to '{output_file_path}': {e}", err=True)
        raise click.Abort()

    # Provide instructions for enabling completion
    click.echo("\nTo enable shell completion:")
    resolved_script_path = output_file_path.resolve()

    if shell == "bash":
        click.echo(f"  1. Add the following line to your ~/.bashrc or ~/.bash_profile file:")
        click.echo(f"     [ -f \"{resolved_script_path}\" ] && . \"{resolved_script_path}\"")
        click.echo(f"  2. Reload your shell configuration: source ~/.bashrc (or source ~/.bash_profile)")
    elif shell == "zsh":
        click.echo(f"  1. Ensure your Zsh completion system is initialized. You might need this in your ~/.zshrc:")
        click.echo(f"     autoload -Uz compinit && compinit")
        click.echo(f"  2. Add the following line to your ~/.zshrc file (before 'compinit' if applicable):")
        click.echo(f"     [ -f \"{resolved_script_path}\" ] && . \"{resolved_script_path}\"")
        click.echo(f"  3. Reload your shell configuration: source ~/.zshrc")
        click.echo(f"  Alternatively, for Zsh, you can place the script in a directory within your $fpath,")
        click.echo(f"  named '_gratools' (e.g., ~/.zsh/completion/_gratools).")
    elif shell == "fish":
        # Fish shell typically looks for completions in ~/.config/fish/completions/
        fish_completions_dir = Path.home() / ".config/fish/completions"
        fish_target_script_path = fish_completions_dir / f"gratools.fish"
        try:
            fish_completions_dir.mkdir(parents=True, exist_ok=True)
            # For Fish, it's often better to just save it directly to the conventional location
            # or instruct the user to move/copy it there.
            # Here, we'll save it directly if output_filepath_str was not specified,
            # otherwise, we'll inform the user based on where they saved it.
            if output_filepath_str is None:  # Default save location was used
                output_file_path.rename(fish_target_script_path)  # Move default to fish dir
                click.echo(f"  - Completion script moved to: {fish_target_script_path}")
                click.echo(
                    f"  - Fish shell should automatically pick it up. Restart your Fish shell or run 'source {fish_target_script_path}'.")
            else:  # User specified a custom output location
                click.echo(
                    f"  1. Copy or link the generated script '{resolved_script_path}' to your Fish completions directory:")
                click.echo(f"     cp \"{resolved_script_path}\" \"{fish_target_script_path}\"")
                click.echo(f"  2. Restart your Fish shell, or source the script in the completions directory.")
        except Exception as e:
            click.echo(f"Could not automatically place Fish completion script: {e}", err=True)
            click.echo(f"Please manually place or source '{resolved_script_path}' for Fish shell.")
    click.echo("\nNote: You might need to restart your terminal session for changes to take full effect.")


@click.command(
    name="secret",
    hidden=True,  # Hides this command from the main help output
    help="Displays a fun, colorful ASCII animation. It's a secret!"  # Help for `gratools secret --help`
)
def secret_command() -> None:
    """
    A hidden easter egg command that displays a colorful ASCII animation.
    This command is not typically listed in help messages but can be invoked directly.
    """
    # ASCII art for GraTools (or similar)
    # Ensure backslashes are escaped or use raw strings if they are part of the art.
    display_text = r"""
        ____                 __________               ____
      6MMMMMb/               MMMMMMMMMM               `MM
     8P    YM               /   MM     \               MM
    6M      Y ___  __    ___    MM   _____     _____   MM   ____
    MM        `MM 6MM  6MMMMb   MM  6MMMMMb   6MMMMMb  MM  6MMMMb\
    MM         MM69 " 8M'  `Mb  MM 6M'   `Mb 6M'   `Mb MM MM'    `
    MM     ___ MM'        ,oMM  MM MM     MM MM     MM MM YM.
    MM     `M' MM     ,6MM9'MM  MM MM     MM MM     MM MM  YMMMMb
    YM      M  MM     MM'   MM  MM MM     MM MM     MM MM      `Mb
     8b    d9  MM     MM.  ,MM  MM YM.   ,M9 YM.   ,M9 MM L    ,MM
      YMMMMM9  _MM_    `YMMM9'Yb_MM_ YMMMMM9   YMMMMM9 _MM_MYMMMM9
        \                                    /                /
        /''A''\          /''''''\           /     /''''A'''''\
   ..GC|       |..ATG...C...CG...T....TAG..'..GC|            |..
        \..C../      \.............../            \...TATA.../
        """

    # List of bright colors available in Rich
    available_colors = [
        "bright_red", "bright_green", "bright_blue", "bright_yellow",
        "bright_magenta", "bright_cyan", "bright_white", "red", "green",
        "blue", "yellow", "magenta", "cyan"
    ]

    def get_random_color() -> str:
        """Returns a random color string from the available list."""
        return choice(available_colors)

    # Using Rich Live for dynamic screen updates
    # `screen=True` creates an alternate screen buffer, good for full-screen animations.
    with Live(Panel(""), refresh_per_second=10, screen=True, console=shared_console) as live:
        animated_frame_content = ""
        text_lines = display_text.split("\n")

        # Animate line by line appearance
        for line in text_lines:
            line_color = get_random_color()
            # Add new line with color, stripping trailing whitespace from original line
            animated_frame_content += f"[{line_color}]{line.rstrip()}[/{line_color}]\n"
            # Update the Live display with a Panel containing the current animation state
            live.update(Panel(animated_frame_content, title="GraTools Secret", border_style="dim blue",
                              height=len(text_lines) + 2))
            sleep(0.15)  # Pause slightly between lines

        # Final message after animation
        final_message_english = "\n🎉 🎊 You found the GraTools easter egg! 🎈 🎁\n"
        final_display_content = animated_frame_content + f"[bold bright_yellow]{final_message_english}[/]"

        # Blinking effect for the final message
        for _ in range(3):  # Blink 3 times
            live.update(Panel(final_display_content, title="GraTools Secret!", border_style="yellow",
                              height=len(text_lines) + 4))
            sleep(0.5)
            # "Hide" the final message part by redrawing just the art (or making text dim)
            live.update(Panel(animated_frame_content + "\n" * 3, title="GraTools Secret", border_style="dim yellow",
                              height=len(text_lines) + 4))
            sleep(0.3)

        # Show final message steadily
        live.update(Panel(final_display_content, title="GraTools Secret!", border_style="bold green",
                          height=len(text_lines) + 4))
        sleep(2.0)  # Keep final message visible for a couple of seconds

    # After Live context exits, print the final message to the normal console output
    # This ensures it's visible even if the alternate screen is cleared.
    shared_console.print(Panel(final_display_content, title="GraTools Secret!", border_style="green", expand=False))