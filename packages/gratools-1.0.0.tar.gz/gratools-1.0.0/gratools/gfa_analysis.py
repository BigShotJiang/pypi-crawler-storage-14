# Standard library imports
from pathlib import Path
from typing import Any  # For type hinting kwargs

# Third-party imports
import click
from cloup import command, option, option_group
# from cloup.constraints import ErrorFmt, RequireAtLeast # Not used in this file directly

# Local application/library specific imports
from .Gratools import Gratools
from .common_decorators import common_options_decorator, options_for_gfa_handling
# Assuming CustomCommand and validate_percentage_or_int are correctly defined
from .useful_function import CustomCommand, validate_percentage_or_int


@command(
    "core_dispensable_ratio",
    cls=CustomCommand,
    short_help="Compute and display the ratio of core and dispensable segments.",
    help="""
    This command analyzes segments in the GFA to determine the ratio of core segments
    (shared by almost all samples) versus the dispensable ones
    (present in a smaller subset of samples). The thresholds for defining 'core'
    and 'dispensable' can be specified as an absolute number of samples or as a percentage
    of the total number of samples embedded in the GFA. A filter on segment length can also be applied.
    Results are displayed in the terminal and saved to a CSV file.
    This command relies on a pre-existing GraTools index of the input GFA.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/core_dispensable_ratio.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Core/Dispensable Ratio Options",  # Group name for clarity
    *options_for_gfa_handling,  # Common GFA options (path, threads, output_directory, suffix, index_links)
    option(
        "--input-as-number/--input-as-percentage",
        "input_as_number_flag",  # Explicit dest name to avoid conflict with Gratools param
        is_flag=True,
        required=True,  # User must specify the input mode
        help="Specify whether --shared-min and --specific-max are absolute numbers or percentages.",
    ),
    option(
        "--shared-min",
        "-sm",  # Short option
        callback=validate_percentage_or_int,  # Your custom validator
        required=True,  # This threshold is essential for the analysis
        help="Minimal number/percentage of samples embedded in for a segment to be 'core'.",
    ),
    option(
        "--specific-max",
        "-spm",  # Short option (changed from -sp to avoid conflict if other commands use it)
        callback=validate_percentage_or_int,
        required=True,  # This threshold is essential for the analysis
        help="Maximal number/percentage of samples embedded in for a segment to be 'dispensable'.",
    ),
    option(
        "--filter-len",
        "-fl",
        type=int,
        default=0,  # Default to 0 (no length filtering)
        show_default=True,
        help="Minimal segment length (bp) to be included in the analysis. A value of 0 means no length filter.",
    ),
)
@common_options_decorator  # Global options like verbosity, log_path
@click.pass_context
def core_dispensable_ratio_command(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to compute and display the ratio of core and dispensable segments.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),
        suffix=kwargs.get("output_file_suffix"),  # From options_for_gfa_handling or common_options
        meta=kwargs,  # Pass all kwargs for verbosity, log_path, etc.
        index_links=kwargs.get("index_links", False)  # From options_for_gfa_handling
    )

    # Call the updated method name in Gratools
    gratools_instance.run_core_dispensable_ratio_analysis(
        input_as_number=kwargs.get("input_as_number_flag"),  # Use dest name
        shared_min=kwargs.get("shared_min"),
        specific_max=kwargs.get("specific_max"),
        filter_len=kwargs.get("filter_len")
    )


@command(
    "depth_nodes_stat",
    cls=CustomCommand,
    short_help="Display various statistics about segment depth (number of embedded samples).",
    help="""
    This command computes how segments are shared across different samples by
    calculating the 'depth' of each segment (i.e., the number of unique samples
    encompassing it). It outputs a table showing the count of segments for each
    depth level. An optional length filter can be applied to consider only segments
    above a certain size for a 'filtered' count.
    Results are displayed in the terminal and saved to a CSV file.
    This command relies on a pre-existing GraTools index.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/depth_nodes_stat.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Node Depth Statistics Options",  # Group name
    *options_for_gfa_handling,
    option(
        "--filter-len",
        "-fl",
        type=int,
        default=0,
        show_default=True,
        help="Minimal segment length (bp) to be considered in the depth count. A value of 0 means no length filter.",
    ),
)
@common_options_decorator
@click.pass_context
def depth_nodes_stat_command(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to display statistics about segment depth.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),
        suffix=kwargs.get("output_file_suffix"),
        meta=kwargs,
        index_links=kwargs.get("index_links", False)
    )

    # Call the updated method name in Gratools
    gratools_instance.run_depth_nodes_statistics(
        filter_len=kwargs.get("filter_len")
    )


@command(
    "specific_groups_sample",
    cls=CustomCommand,
    short_help="Identify segments shared by or specific to defined sample groups.",
    help="""
    This command compares segments between two (optional) groups of samples (A and B),
    both defined by providing files listing sample. It identifies:
    1. Segments shared by ALL samples in group A.
    2. Segments specific to group A (i.e., present in ALL of A and ABSENT from ALL of B).
    An optional length filter can be applied to consider only segment for a minimal length. 
    Results are logged to the terminal and saved in a CSV file.
    This command relies on a pre-existing GraTools index.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/specific_and_shared_segments.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Specific groups sample Options",
    *options_for_gfa_handling[:-1],
    option(
        "--samples-list-A",
        "-sla",
        "samples_list_A",
        type=click.Path(
            exists=True, file_okay=True, dir_okay=False, readable=True,
            resolve_path=True, path_type=Path
        ),
        required=True,  # List A is fundamental to this analysis
        help="Path to a file listing sample names for group A (one sample per line).",
    ),
    option(
        "--samples-list-B",
        "-slb",
        "samples_list_B",
        type=click.Path(
            exists=True, file_okay=True, dir_okay=False, readable=True,
            resolve_path=True, path_type=Path
        ),
        required=False,  # List B is optional (for specificity check)
        help="Path to a file listing sample names for group B (one sample per line). Required for specificity analysis.",
    ),
    option(
        "--filter-len",
        "-fl",
        "filter_len",
        type=int,
        default=0,
        show_default=True,
        help="Minimum segment length (bp) to consider. 0 means no length filter.",
    ),
    option('--output_csv', '-csv', is_flag=True, default=False,
           help='Save the specific and shared segments in a csv file.'),
    option('--suffix', '-su', "output_file_suffix", default='', type=str,
           required=True, help='Suffix added to output filename.'),
)
@common_options_decorator
@click.pass_context
def specific_groups_sample_command(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to identify segments shared by and specific to given sample groups.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),
        suffix=kwargs.get("output_file_suffix"),
        meta=kwargs,
        index_links=kwargs.get("index_links", False)
    )

    # Call the updated method name in Gratools
    gratools_instance.run_get_specific_groups_sample_analysis(
        sample_list_a_path=kwargs.get("samples_list_A"),
        sample_list_b_path=kwargs.get("samples_list_B"),  # Can be None
        filter_len=kwargs.get("filter_len"),
        output_csv=kwargs.get('output_csv')
    )


@command(
    "get_segments_by_depth",
    cls=CustomCommand,
    short_help="List segments within a specified depth range (number of encompassing samples).",
    help="""
    This command generates a list of segments (also called nodes) that are shared by a given range of 
    samples (number). This range can be defined as an
    absolute number of individuals or through a percentage of the total embedded GFA samples.
    For instance, when providing as a percentage: --input-as-percentage --lower-bound 90 --upper-bound 100
    will list core segments. 
    When providing absolute numbers e.g.: --input-as-number --lower-bound 0 --upper-bound 2
    will list segments found in none, 1, or 2 individuals.
    An optional length filter can be applied to remove segment of a size lower than the filter. 
    Output will be sent to the terminal or a CSV file if specified.
    This function relies on a pre-existing GraTools index.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/get_segments_by_depth.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Segment Recovery by Depth Options",
    *options_for_gfa_handling,
    option(
        "--input-as-number/--input-as-percentage",
        "input_as_number_flag",
        is_flag=True,
        required=True,
        help="Define if --lower-bound and --upper-bound are absolute numbers or percentages.",
    ),
    option(
        "--lower-bound",
        "-lb",
        callback=validate_percentage_or_int,
        required=True,
        help="Lower bound of the depth interval (inclusive).",
    ),
    option(
        "--upper-bound",
        "-ub",  # Short option
        callback=validate_percentage_or_int,
        required=True,
        help="Upper bound of the depth interval (inclusive).",
    ),
    option(
        "--filter-len",
        "-fl",
        type=int,
        default=0,
        show_default=True,
        help="Minimum segment length (bp) to be considered. A value of 0 means no length filter.",
    ),
    option(
        "--save-to-file/--display-to-terminal",
        "output_to_file_flag",
        is_flag=True,
        default=True,  # Default to saving to a file
        show_default=True,
        help="Save results to a CSV file instead of displaying to the terminal.",
    ),
)
@common_options_decorator
@click.pass_context
def get_segments_by_depth_command(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to list segments shared by a number of individuals within specified bounds.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),
        suffix=kwargs.get("output_file_suffix"),
        meta=kwargs,
        index_links=kwargs.get("index_links", False)
    )

    # Call the updated method name in Gratools
    gratools_instance.display_or_save_segments_by_depth(
        input_as_number=kwargs.get("input_as_number_flag"),
        lower_bound=kwargs.get("lower_bound"),
        upper_bound=kwargs.get("upper_bound"),
        filter_len=kwargs.get("filter_len"),
        output_to_file=kwargs.get("output_to_file_flag")  # Use dest name
    )