# Third-party imports
from pathlib import Path
from typing import Any

import click
from cloup import command, option, option_group

# Local application/library specific imports
from .Gratools import Gratools  # Assuming Gratools is in the same directory or a submodule
from .common_decorators import common_options_decorator, options_for_gfa_handling  # Your custom decorators
from .useful_function import CustomCommand  # Your custom command class


@command(
    "list_samples",
    cls=CustomCommand,
    short_help="List the samples embedded in the indexed GFA file.",
    help="""
    Lists all unique sample names found in the walks (W lines) of the
    GFA file after its indexation by GraTools. This command thus relies on
    the pre-existing GraTools index for the specified GFA file.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/list_samples.html
    """,
    no_args_is_help=True,
)
@option_group(
    "List Samples Options",
    *options_for_gfa_handling[:-1],  # Assumes options_for_gfa_handling provides common GFA path, threads, etc.
    # The [:-1] slice might be specific to your decorator setup.
    option(
        "--save/--no-save",
        "save_to_file",  # Explicit dest name to avoid conflict if 'save' is a kwarg elsewhere
        is_flag=True,
        default=False,
        show_default=True,
        help="Save the list of the embedded sample names to a text file in the GraTools output directory.",
    ),
)
@common_options_decorator  # Your common options like verbosity, log_path
@click.pass_context
def list_samples(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to list sample names available in an indexed GFA file.
    The list is displayed to the console and can optionally be saved to a file.

    Args:
        ctx (click.Context): The Click context object, automatically passed.
        **kwargs (Any): Keyword arguments from Click options. Expected keys include
                        'gfa' (Path to GFA), 'threads' (int), 'outdir' (Optional[Path]),
                        'save_to_file' (bool), and others from common_options_decorator
                        and options_for_gfa_handling.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),
        meta=kwargs,  # Pass all kwargs for meta-parameter handling (verbosity, etc.)
        index_links=kwargs.get("index_links", False),
    )

    gratools_instance.display_available_sample_names()

    if kwargs.get("save_to_file"):  # Use the explicit dest name
        gratools_instance.save_available_sample_names()


@command(
    "list_chr",
    cls=CustomCommand,
    short_help="List the embedded chromosomes and their fragments if relevant from the indexed GFA file.",
    help="""
    Lists the chromosome information derived from the walks (W lines) of the
    indexed GFA file. By default, it shows a summary of unique chromosomes per sample 
    (meaning multiple fragments in the same chromosome are combined as a single one).
    The --full option displays the detailed start/end positions for each chromosome fragment.
    The results is displayed in the command line or in a CSV file.
    This command relies on the pre-existing GraTools index.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/list_chr.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Chromosome Listing Options",
    *options_for_gfa_handling[:-1],
    option(
        "--full/--no-full",
        "display_full_details",  # Explicit dest name
        is_flag=True,
        default=False,
        show_default=True,
        help="Display the detailed chromosome fragment information (original start/end positions from walks).",
    ),
    option(
        "--save/--no-save",
        "save_to_file",  # Explicit dest name
        is_flag=True,
        default=False,
        show_default=True,
        help="Save the chromosome list (summary or full, based on --full) to a CSV file.",
    ),
)
@common_options_decorator
@click.pass_context
def list_chr(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to list chromosome information from an indexed GFA file.
    Displays either a summary per sample or full fragment details.
    Output can optionally be saved to a file.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options. Expected keys include
                        'gfa', 'threads', 'outdir', 'display_full_details' (bool),
                        'save_to_file' (bool), and others from decorators.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),
        meta=kwargs,
        index_links=kwargs.get("index_links", False),
    )

    if kwargs.get("display_full_details"):
        gratools_instance.display_full_chromosome_fragment_data()
        if kwargs.get("save_to_file"):
            gratools_instance.save_full_chromosome_fragment_data()
    else:
        gratools_instance.display_chromosomes_summary()
        if kwargs.get("save_to_file"):
            gratools_instance.save_chromosomes_summary_by_sample()


@command(
    "stats",
    cls=CustomCommand,
    short_help="Compute and display various statistics for a GFA file.",
    help="""
    Parses a GFA file (or uses an existing GraTools index) to compute
    various statistics about its structure, including segment counts, link properties,
    walk characteristics, and connectivity. Results are displayed in the terminal
    and saved to a file within the GraTools index directory.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/stats.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Statistics Options",
    *options_for_gfa_handling[:-1],  # Assuming this slice correctly excludes an irrelevant option for stats
    option(
        "--by-category/--single-table",
        "display_by_category",  # Explicit dest name
        is_flag=True,
        default=False,  # Default is to show a single table
        show_default=True,
        help="Display statistics in separate tables per category instead of one consolidated table.",
    ),
    option(
        "--save/--no-save",
        "save_to_file",  # Explicit dest name
        is_flag=True,
        default=False,
        show_default=True,
        help="Save the statistique to a CSV file.",
    ),
)
@common_options_decorator
@click.pass_context
def stats(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to calculate and display statistics for a GFA file.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options. Expected keys include
                        'gfa', 'threads', 'outdir', 'display_by_category' (bool),
                        'index_links' (bool, passed via meta to GFA), and others.
    """
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("num_threads"),
        outdir=kwargs.get("output_directory"),  # outdir for Gratools if it creates files
        meta=kwargs,
        index_links=kwargs.get("index_links", False),
    )

    if kwargs.get("display_by_category"):
        gratools_instance.display_gfa_statistics(by_category=True)
    else:
        gratools_instance.display_gfa_statistics(by_category=False)
    if kwargs.get("save_to_file"):
        gratools_instance.save_gfa_statistics()