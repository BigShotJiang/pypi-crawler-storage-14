import os
import hashlib
import mmap
import os
import shutil
import subprocess
import textwrap
from pathlib import Path
from shutil import rmtree  # Explicit import for rmtree
from typing import Any, Dict, List, Tuple  # Added Tuple and List for type hints

import aiosqlite  # For compute_links_checksum_async
import pytest
from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

# Assuming gratools module is in the PYTHONPATH or installable
from gratools.Graph import AsyncGfaDatabase  # Adjust if path is different

# ———————————————————————————————
# CONFIGURATION
# ———————————————————————————————


# Environment variable configurations
GFA_FILE_PATH = Path(
    os.environ.get(
        "GFA_FILE_PATH",
        "/shared/ifbstor1/projects/glp701/sandbox/gratools/data-gratools/Rice/Og_cactus.gfa.gz",
    )
)
NUM_THREADS = int(os.environ.get("NUM_THREADS", 6))
MD5_REFERENCE_DIR = Path(os.environ.get("MD5_REFERENCE_DIR", "./md5sum_tests"))
FORCE_ALL_TESTS = os.environ.get("FORCE_ALL_TESTS", "0") == "0"
CAPTURE_SUBPROCESS_OUTPUT = os.environ.get("CAPTURE_SUBPROCESS_OUTPUT", "1") == "1"
CI_PROJECT_DIR_PATH = Path(os.environ.get("CI_PROJECT_DIR")) if os.environ.get("CI_PROJECT_DIR") else None

# Ensure MD5 reference directory exists if provided, or skip MD5 checks
if not MD5_REFERENCE_DIR.exists():
    print(
        f"WARNING: MD5 reference directory '{MD5_REFERENCE_DIR}' not found. MD5 checks will be skipped or fail if files are expected.")
    # Optionally, disable MD5 checks here or handle missing files gracefully

console = Console()

# Flag to track if the GFA index creation test passed
# This helps in skipping subsequent tests that depend on a valid index.
INDEX_CREATION_PASSED = True

# Test configurations: (command_template, md5_reference_filename_for_outputs)
# The command template uses {num_threads} for thread count.
# Output directory handling is now more explicit in execute_gratools.
TEST_CONFIGURATIONS: List[Tuple[str, str]] = [
    # Indexing (foundational) - output is the index directory itself.
    # MD5 for index checks specific files within the index (e.g., BAM, DB, txt files).
    ("index --index-links --threads {num_threads}", "md5sum_index.txt"),

    # Listing commands (rely on index)
    ("list_samples --save --threads {num_threads}", "md5sum_list_samples.txt"),
    ("list_chr --save --threads {num_threads}", "md5sum_list_chr.txt"),
    ("list_chr --save --full --threads {num_threads}", "md5sum_list_chr_full.txt"),

    # Statistics command (relies on index)
    ("stats --save --threads {num_threads}", "md5sum_stats.txt"),  # Assuming stats saves a summary file

    # Extraction commands (rely on index)
    ("extract_subgraph --sample-query CG14 --chrom-query CG14_Chr07 --start-query 10000 --stop-query 15000 --all-samples --threads {num_threads}",
     "md5sum_extract_subgraph_cg14_chr7_all.txt"),
    ("extract_subgraph --sample-query CG14 --chrom-query CG14_Chr07 --start-query 10000 --stop-query 15000 --all-samples --build-fasta --threads {num_threads}",
     "md5sum_extract_subgraph_cg14_chr7_all_fasta.txt"),  # If --build-fasta creates different/additional files
    ("get_fasta --sample-query CG14 --chrom-query CG14_Chr07 --start-query 10000 --stop-query 15000 --all-samples --threads {num_threads}",
     "md5sum_get_fasta_cg14_chr7_all.txt"),

    # Analysis command
    ("core_dispensable_ratio --input-as-number -sm 4 -spm 2 -fl 50 -t {num_threads}",
     "md5sum_core_dispensable_ratio.txt"),
    (f"specific_groups_sample -sla {MD5_REFERENCE_DIR}/list_A.txt -slb {MD5_REFERENCE_DIR}/list_B.txt --suffix test -csv -t {{num_threads}}",
     "md5sum_specific_groups_sample.txt"),
    ("depth_nodes_stat -t {num_threads}",
     "md5sum_depth_nodes_stat.txt"),
    ("get_segments_by_depth --save-to-file --input-as-number -lb 0 -ub 2 -fl 0 -t {num_threads}",
     "md5sum_get_segment_by_depth.txt")

]

# Dictionary to track failures and totals per command category (base command)
command_test_results: Dict[str, Dict[str, int]] = {
    tpl_parts[0]: {"failed": 0, "total": 0, "skipped": 0}
    for tpl_parts in (cmd_tpl.split() for cmd_tpl, _ in TEST_CONFIGURATIONS)
}


# ———————————————————————————————
# UTILITY FUNCTIONS
# ———————————————————————————————

def calculate_md5_memory_mapped(file_path: Path) -> str:  # Renamed for clarity
    """Calculates the MD5 hash of a file using memory mapping for efficiency with large files."""
    md5_hasher = hashlib.md5()
    try:
        with open(file_path, "rb") as f_in:
            # Memory map the file for efficient reading
            with mmap.mmap(f_in.fileno(), 0, access=mmap.ACCESS_READ) as mm_obj:
                md5_hasher.update(mm_obj)
        return md5_hasher.hexdigest()
    except ValueError:  # mmap raises ValueError for empty files
        # For empty files, MD5 should be d41d8cd98f00b204e9800998ecf8427e
        if file_path.stat().st_size == 0:
            return "d41d8cd98f00b204e9800998ecf8427e"
        raise  # Re-raise if not an empty file issue
    except Exception as e:
        console.print(f"[red]Error calculating MD5 for {file_path}: {e}[/red]")
        return f"ERROR_CALCULATING_MD5_{e!s:.20}"


async def compute_sqlite_links_table_checksum_async(db_instance: AsyncGfaDatabase) -> str:  # Renamed
    """
    Exports sorted link data from the 'links' table of the given AsyncGfaDatabase
    instance and computes its MD5 hash asynchronously.
    Ensures database connection is managed correctly.
    """
    if not db_instance.db_file.exists():
        return "DB_FILE_MISSING_FOR_CHECKSUM"
    # Re-opening a direct connection for checksumming ensures no interference with the instance's state.
    try:
        async with aiosqlite.connect(db_instance.db_file.as_posix()) as conn:
            async with conn.execute(
                    "SELECT * FROM links ORDER BY seg_id_1, orient_seg_1, seg_id_2, orient_seg_2, orient_key_seg_1, orient_key_seg_2") as cursor:  # More comprehensive sort
                rows = await cursor.fetchall()

        # Serialize rows to a consistent string format for hashing
        # Converting rows to strings and joining with newlines.
        content_str = "\n".join(map(str, rows))
        return hashlib.md5(content_str.encode("utf-8")).hexdigest()
    except Exception as e:
        console.print(f"[red]Error computing links checksum for {db_instance.db_file}: {e}[/red]")
        return f"ERROR_COMPUTING_DB_CHECKSUM_{e!s:.20}"


def load_md5_reference_file(md5_file_path: Path) -> Dict[str, str]:  # Renamed
    """Loads reference MD5 hashes from a specified file."""
    reference_hashes: Dict[str, str] = {}
    if not md5_file_path.is_file():
        console.print(f"[yellow]MD5 reference file not found: {md5_file_path}. Cannot verify checksums.[/yellow]")
        return reference_hashes

    with open(md5_file_path, "r", encoding="utf-8") as f_ref:
        for line_num, line_content in enumerate(f_ref, 1):
            line_content = line_content.strip()
            if not line_content or line_content.startswith("#"):  # Skip empty/comment lines
                continue
            parts = line_content.split(maxsplit=1)  # Split only on first whitespace
            if len(parts) == 2:
                md5_hash, file_name_key = parts
                reference_hashes[file_name_key.strip()] = md5_hash.strip()
            else:
                console.print(
                    f"[yellow]Warning: Malformed line #{line_num} in MD5 reference file '{md5_file_path.name}': {line_content}[/yellow]")
    return reference_hashes


def get_expected_output_files(md5_reference_file_path: Path, base_output_directory: Path) -> List[Path]:  # Renamed
    """
    Determines the list of expected output file paths based on an MD5 reference file.
    File names in the MD5 reference are treated as relative to `base_output_directory`
    unless they are already absolute paths.
    """
    reference_hashes = load_md5_reference_file(md5_reference_file_path)
    expected_file_paths: List[Path] = []
    for file_name_key in reference_hashes.keys():
        path_from_key = Path(file_name_key)
        if path_from_key.is_absolute():
            expected_file_paths.append(path_from_key)
        else:
            # Resolve relative to the base output directory for the specific command run
            expected_file_paths.append((base_output_directory / file_name_key).resolve())
    return expected_file_paths


def execute_gratools_command(
        command_template: str,
        md5_reference_filename: str,
        test_run_output_dir: Path,
        gfa_file_to_test: Path,
        num_threads_for_command: int
) -> Tuple[List[Path], str, Path, int]:  # Ajout de int pour le code de retour
    """
    Executes a GraTools command, manages output directories, and returns information
    for test validation including the command's return code.
    ...
    Returns:
        A tuple: (list_of_expected_output_file_paths, base_command_name, effective_output_dir_for_command_outputs, return_code).
    """
    if test_run_output_dir.exists():
        rmtree(test_run_output_dir)
    test_run_output_dir.mkdir(parents=True, exist_ok=True)

    formatted_command_args = command_template.format(num_threads=num_threads_for_command).split()
    base_command_name = formatted_command_args[0]

    cli_args = ["gratools"] + formatted_command_args

    effective_output_dir: Path
    if base_command_name == "index":
        gfa_name_stem = gfa_file_to_test.name.removesuffix(".gfa.gz").removesuffix(".gfa")
        effective_output_dir = (gfa_file_to_test.parent / f"{gfa_name_stem}_GraTools_INDEX").resolve()

        if effective_output_dir.exists():
            rmtree(effective_output_dir)
    else:
        cli_args.extend(["--outdir", str(test_run_output_dir)])
        gfa_name_stem = gfa_file_to_test.name.removesuffix(".gfa.gz").removesuffix(".gfa")
        effective_output_dir = (test_run_output_dir / f"GraTools-output_{gfa_name_stem}").resolve()

    cli_args.extend(["-g", str(gfa_file_to_test)])

    command_to_display = " ".join(cli_args)
    terminal_width = shutil.get_terminal_size(fallback=(80, 24)).columns
    wrapped_command_display = "\n".join(textwrap.wrap(command_to_display, width=terminal_width))

    title_text = Text(f"\n# EXECUTING: {base_command_name.upper()} #", style="bold cyan", justify="left")
    console.print(Align.left(title_text))
    console.print(Syntax(wrapped_command_display, "bash", theme="monokai", line_numbers=False, word_wrap=True))

    process = subprocess.Popen(
        cli_args,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8"
    )

    stdout_lines_list: List[str] = []
    stderr_lines_list: List[str] = []

    if CAPTURE_SUBPROCESS_OUTPUT:
        console.print(Align.left(Text("\n# Subprocess Output:", style="bold cyan")))

    # Stream stdout
    if process.stdout:
        for line in iter(process.stdout.readline, ''):
            stdout_lines_list.append(line)
            if CAPTURE_SUBPROCESS_OUTPUT:
                console.print(line.rstrip())
        process.stdout.close()

    # Stream stderr
    if process.stderr:
        for line in iter(process.stderr.readline, ''):
            stderr_lines_list.append(line)
            # Afficher stderr s'il y a quelque chose, surtout pour les erreurs
            if line.strip():  # Ne pas afficher des Panel pour des lignes vides de stderr
                if CAPTURE_SUBPROCESS_OUTPUT:
                    console.print(Panel(line.rstrip(), title="stderr", border_style="red", expand=False))
        process.stderr.close()

    return_code = process.wait()
    stdout_full = "".join(stdout_lines_list)
    stderr_full = "".join(stderr_lines_list)

    if return_code != 0:
        console.print(f"[bold red]Command '{command_to_display}' FAILED with exit code {return_code}[/bold red]")
        if not CAPTURE_SUBPROCESS_OUTPUT:  # Si on n'a pas déjà affiché au fur et à mesure
            if stdout_full.strip():
                console.print("[bold gold]Captured STDOUT on failure:[/bold gold]")
                console.print(Panel(stdout_full.strip(), title="stdout", border_style="gold", expand=False))
            if stderr_full.strip():
                console.print("[bold red]Captured STDERR on failure:[/bold red]")
                console.print(Panel(stderr_full.strip(), title="stderr", border_style="red", expand=False))

    md5_ref_path = MD5_REFERENCE_DIR / md5_reference_filename
    list_of_expected_files = get_expected_output_files(md5_ref_path, effective_output_dir)

    return list_of_expected_files, base_command_name, effective_output_dir, return_code


@pytest.mark.parametrize(
    "command_template_str, md5_reference_filename_str",
    TEST_CONFIGURATIONS,
    ids=[cmd_tpl.split()[0] for cmd_tpl, _ in TEST_CONFIGURATIONS],
)
@pytest.mark.asyncio
async def test_gratools_command_outputs(
    command_template_str: str,
    md5_reference_filename_str: str,
    tmp_path: Path
):
    global INDEX_CREATION_PASSED
    base_command_name_from_template = command_template_str.split()[0]

    if base_command_name_from_template != "index" and not INDEX_CREATION_PASSED and not FORCE_ALL_TESTS:
        command_test_results[base_command_name_from_template]["skipped"] += 1
        pytest.skip(f"Skipping test for '{base_command_name_from_template}' because index creation test did not pass.")

    expected_files_list, actual_base_command, effective_output_dir_for_command, command_return_code = execute_gratools_command(
        command_template_str,
        md5_reference_filename_str,
        tmp_path,
        GFA_FILE_PATH,
        NUM_THREADS
    )

    # Échec immédiat si la commande elle-même a échoué, avant même de vérifier les MD5
    if command_return_code != 0:
        # Mettre à jour les stats pour la commande comme ayant échoué globalement
        command_test_results[actual_base_command]["failed"] += len(
            expected_files_list) if expected_files_list else 1  # Compter tous les fichiers attendus comme échec ou au moins 1 échec global
        command_test_results[actual_base_command]["total"] += len(expected_files_list) if expected_files_list else 1
        pytest.fail(
            f"Command '{actual_base_command}' execution failed with exit code {command_return_code}. "
            "No MD5 checks performed for this command.",
            pytrace=False
        )

    md5_ref_file_full_path = MD5_REFERENCE_DIR / md5_reference_filename_str
    reference_md5_map = load_md5_reference_file(md5_ref_file_full_path)

    if not reference_md5_map and expected_files_list:
        console.print(
            f"[bold red]No reference MD5s loaded for {actual_base_command}. All file checks will be marked as 'NO_REF'.[/bold red]")

    num_failed_files = 0
    num_total_expected_files = len(expected_files_list)

    console.print(Align.left(Text(f"\n# Verifying Outputs for: {actual_base_command.upper()}", style="bold cyan")))
    results_table = Table(title=f"Output File Verification: {actual_base_command.upper()}")
    # Modification ici pour la colonne "Expected File"
    results_table.add_column("File Name", style="cyan", overflow="fold")  # Changé de "Expected File" à "File Name"
    results_table.add_column("Status", style="magenta", justify="center")
    results_table.add_column("Details (MD5 / Error)", style="yellow", overflow="fold")

    for expected_file_path in expected_files_list:
        # Clé pour la map de référence MD5 : utiliser le nom de fichier relatif au répertoire de sortie effectif
        relative_file_name_key_for_lookup: str
        try:
            relative_file_name_key_for_lookup = str(expected_file_path.relative_to(effective_output_dir_for_command))
        except ValueError:
            relative_file_name_key_for_lookup = expected_file_path.name
            # Ce warning est toujours utile s'il se produit
            console.print(
                f"[yellow]Warning: Could not make '{expected_file_path}' relative to '{effective_output_dir_for_command}'. Using filename '{relative_file_name_key_for_lookup}' as MD5 key.[/yellow]")

        # Nom de fichier à afficher dans la table
        file_name_for_display = expected_file_path.name

        if not expected_file_path.exists():
            # Modification ici : utiliser file_name_for_display
            results_table.add_row(file_name_for_display, "[red]❌ MISSING[/red]", f"File not found at expected location.{expected_file_path}")
            num_failed_files += 1
        else:
            calculated_md5_hash = ""
            if expected_file_path.suffix == ".db":
                db_for_checksum = AsyncGfaDatabase(expected_file_path)
                calculated_md5_hash = await compute_sqlite_links_table_checksum_async(db_for_checksum)
            else:
                calculated_md5_hash = calculate_md5_memory_mapped(expected_file_path)

            expected_md5_hash = reference_md5_map.get(relative_file_name_key_for_lookup)

            if not expected_md5_hash:
                # Modification ici : utiliser file_name_for_display
                results_table.add_row(file_name_for_display, "[yellow]⚠️ NO_REF[/yellow]",
                                      f"No ref MD5 for key '{relative_file_name_key_for_lookup}'. Calc: {calculated_md5_hash}")
            elif calculated_md5_hash == expected_md5_hash:
                # Modification ici : utiliser file_name_for_display
                results_table.add_row(file_name_for_display, "[green]✅ PASSED[/green]",
                                      f"MD5 match: {calculated_md5_hash}")
            else:
                # Modification ici : utiliser file_name_for_display
                results_table.add_row(file_name_for_display, "[red]❌ FAILED[/red]",
                                      f"MD5 mismatch. Key: '{relative_file_name_key_for_lookup}'. Exp: {expected_md5_hash}, Got: {calculated_md5_hash}")
                num_failed_files += 1

    console.print(results_table)
    command_test_results[actual_base_command]["failed"] += num_failed_files
    command_test_results[actual_base_command]["total"] += num_total_expected_files

    if actual_base_command == "index":
        INDEX_CREATION_PASSED = (num_failed_files == 0)
        if not INDEX_CREATION_PASSED:
            console.print("[bold red]Index creation test failed. Subsequent tests might be skipped.[/bold red]")

    if num_failed_files > 0:
        if CI_PROJECT_DIR_PATH:
            artifacts_dir = CI_PROJECT_DIR_PATH / "test_artifacts" / actual_base_command
            artifacts_dir.mkdir(exist_ok=True, parents=True)
            source_dir_for_artifact = effective_output_dir_for_command  # Utiliser le répertoire de sortie effectif
            if source_dir_for_artifact.exists():
                try:
                    shutil.copytree(source_dir_for_artifact, artifacts_dir, dirs_exist_ok=True)
                    console.print(
                        f"[yellow]Copied outputs from '{source_dir_for_artifact}' to artifacts: '{artifacts_dir}'.[/yellow]")
                except Exception as copy_err:
                    console.print(f"[red]Error copying artifacts for {actual_base_command}: {copy_err}[/red]")
            else:
                console.print(
                    f"[yellow]Source dir for artifacts '{source_dir_for_artifact}' not found. Skipping copy.[/yellow]")

        pytest.fail(
            f"Command '{actual_base_command}': {num_failed_files}/{num_total_expected_files} output file checks failed.",
            pytrace=False)

    elif num_failed_files == 0 and not (
            num_total_expected_files == 0 and not reference_md5_map):  # Si tout a passé et qu'il y avait des fichiers à vérifier
        console.print(f"[green]All checks passed for command '{actual_base_command}'.[/green]")
        # Nettoyage du répertoire de sortie effectif si ce n'est pas le tmp_path principal de pytest (cas de 'index')
        # et si on n'est pas dans un contexte CI où on veut garder les artefacts.
        # tmp_path est automatiquement nettoyé par pytest.
        if actual_base_command == "index" and effective_output_dir_for_command.exists() and not CI_PROJECT_DIR_PATH:
            console.print(
                f"[green]Index command passed. Index directory '{effective_output_dir_for_command}' may be kept for subsequent tests or manually cleaned.[/green]")
            # rmtree(effective_output_dir_for_command) # Décommentez pour nettoyer l'index après un test 'index' réussi
# ———————————————————————————————
# SUMMARY FIXTURE (RUNS AT END OF SESSION)
# ———————————————————————————————

@pytest.fixture(scope="session", autouse=True)
def print_overall_test_summary(request):  # Renamed and using request fixture
    """
    Pytest fixture to print a summary of command test failures at the end of the test session.
    `autouse=True` ensures it runs automatically for the session.
    """
    # This part runs before tests in the session (setup, if any)
    yield
    # This part runs after all tests in the session have completed (teardown/summary)

    console.print(Align.center(Text("\n╔══════════════════════════════════════╗", style="bold blue")))
    console.print(Align.center(Text("║      GraTools Test Run Summary       ║", style="bold blue")))
    console.print(Align.center(Text("╚══════════════════════════════════════╝\n", style="bold blue")))

    summary_table = Table(title="[bold]Overall Command Test Results[/bold]", show_header=True,
                          header_style="bold magenta")
    summary_table.add_column("Command Tested", style="cyan", min_width=30)
    summary_table.add_column("Files Checked", style="yellow", justify="center")
    summary_table.add_column("Files Failed", style="red", justify="center")
    summary_table.add_column("Files Skipped (due to Index)", style="blue", justify="center")  # If tracking skips
    summary_table.add_column("Status", justify="center")

    grand_total_checked = 0
    grand_total_failed = 0
    grand_total_skipped = 0

    for command_name, stats_dict in command_test_results.items():
        total_for_cmd = stats_dict.get("total", 0)
        failed_for_cmd = stats_dict.get("failed", 0)
        skipped_for_cmd = stats_dict.get("skipped", 0)

        status_text = "[green]✅ ALL PASSED[/green]"
        if failed_for_cmd > 0:
            status_text = f"[red]❌ {failed_for_cmd} FAILED[/red]"
        elif total_for_cmd == 0 and skipped_for_cmd == 0:  # No files checked for this command (e.g. bad MD5 ref file)
            status_text = "[yellow]⚠️ NO CHECKS[/yellow]"
        elif skipped_for_cmd > 0 and total_for_cmd == 0:  # All were skipped
            status_text = "[blue]➡️ SKIPPED[/blue]"

        summary_table.add_row(
            command_name,
            str(total_for_cmd),
            str(failed_for_cmd),
            str(skipped_for_cmd),
            str(status_text).strip()
        )
        grand_total_checked += total_for_cmd
        grand_total_failed += failed_for_cmd
        grand_total_skipped += skipped_for_cmd

    console.print(summary_table)

    if grand_total_failed == 0 and grand_total_checked > 0:
        console.print("\n[bold green]🎉 All configured GraTools command tests passed successfully! 🎉[/bold green]")
    elif grand_total_checked == 0 and grand_total_skipped == 0:
        console.print(
            "\n[bold yellow]🤔 No files were checked across all commands. Verify MD5 reference files and test configurations.[/bold yellow]")
    else:
        console.print(
            f"\n[bold red]☠️ {grand_total_failed} file check(s) failed across all commands. Review logs for details. ☠️[/bold red]")

    if grand_total_skipped > 0:
        console.print(
            f"[blue]ℹ️ {grand_total_skipped} check(s) were skipped, likely due to index creation failure (if not forced).[/blue]")