# Standard library imports
# (None directly used at this top level, but good practice if any were)
from typing import Any
from pathlib import Path

# Third-party imports
import click
from cloup import group, command, option_group, option # For CLI structure

# Local application/library specific imports
# Assuming these modules contain the actual command function definitions
from .gfa_content_info import list_samples, list_chr, stats
from .gfa_extract import extract_subgraph_command, get_fasta_command
from .gfa_analysis import (
    core_dispensable_ratio_command,
    depth_nodes_stat_command,
    specific_groups_sample_command,
    get_segments_by_depth_command,
)
from .others_cmd import shell_completion_command, secret_command # For utility/hidden commands
from .__init__ import __version__ # For application version
from .useful_function import CustomGroup, CustomCommand # Custom Click classes
from .common_decorators import options_for_gfa_handling, common_options_decorator # Shared CLI options
from .Gratools import Gratools # The core Gratools class


# ==========================
# MAIN COMMAND GROUP
# ==========================
@group(
    name="gratools",
    cls=CustomGroup,
    help="A toolkit for analyzing, manipulating, and extracting information from pangenome graphs in GFA format.",
    invoke_without_command=True, # Allows `gratools` to be run alone (e.g., to show help or version)
    no_args_is_help=True,      # Shows help if `gratools` is run with no subcommand and no options
)
@click.version_option(
    __version__, # Automatically sourced from .__init__
    "-v", "--version",
    message="%(prog)s, version %(version)s" # Standard version message format
)
@click.pass_context # Allows the main command to access the context if needed
def main_command(ctx: click.Context) -> None:
    """
    Main entry point for the GraTools Command Line Interface.

    This command group organizes all available GraTools functionalities into logical sections.
    Running `gratools` without any subcommands or with `--help` will display
    the list of available commands and their descriptions.
    """
    # This function is often empty if `invoke_without_command=True` is used mainly
    # to show help or version. If `gratools` itself should perform a default action
    # when no subcommand is given (and it's not just for help/version),
    # that logic would go here.
    if ctx.invoked_subcommand is None:
        # Example: Could print a welcome message or brief overview if desired,
        # but `no_args_is_help=True` usually handles this by showing help.

        pass


# ==========================
# INDEX COMMAND
# ==========================
@command(
    "index",
    cls=CustomCommand,
    short_help="Pre-processes a GFA file for faster GraTools operations.",
    help="""
    The 'index' command parses a GFA file and creates several auxiliary files
    (e.g., a BAM representation of segments, BED files for walks per sample,
    and a statistics summary). These indexed files allow subsequent GraTools
    commands to operate much more quickly on the GFA data.

    It is highly recommended to run 'index' on your GFA file before using
    other analysis or extraction commands for optimal performance, especially
    with large GFA files. If an index already exists, GraTools will typically
    use it; this command can be used to explicitly (re)generate the index.

    For more details, see the full documentation:
    https://gratools.readthedocs.io/en/latest/commands/index.html
    """,
    no_args_is_help=True,
)
@option_group(
    "Index Generation Options",
    *options_for_gfa_handling[:-2],
    option(
        "--index-links/--no-index-links",
        "index_links",  # Explicit dest name
        is_flag=True,
        default=False,
        show_default=True,
        help="index links on DB",
    ),
    option(
        "--disable-progress",
        "disable_progress_flag",  # Explicit dest name to avoid conflict with Gratools param
        is_flag=True,
        default=False,
        show_default=True,
        help="Disable progress bars, which may improve performance for large GFA files.", )

)
@common_options_decorator
@click.pass_context
def index_gfa_file(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to generate or update the GraTools index for a GFA file.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options. Expected to include
                        'gfa' (Path), 'threads' (int), and others defined by
                        decorators (like 'verbosity', 'log_path', 'index_links', 'outdir'
                        which are passed via `meta`).
    """
    _ = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("threads"),
        outdir=kwargs.get("output_directory"), # Pass outdir if provided by common_options_decorator or options_for_gfa_handling
        meta=kwargs, # Pass all kwargs; Gratools constructor picks what it needs (e.g., index_links, verbosity)
        index_links=kwargs.get("index_links")
    )


# ==========================
# TO_BANDAGE COMMAND
# ==========================
@command(
    "to_bandage",
    cls=CustomCommand,
    short_help="Generates a CSV file for the Bandage graph visualizer.",
    help="""
    The 'to_bandage' command processes the indexed BAM file of GFA segments
    to generate a CSV file. This CSV contains node information (e.g., length,
    depth/coverage) that can be imported directly into Bandage for coloring
    and analyzing the graph visually.

    This command requires a GraTools index to exist for the GFA file.
    If the index is not present, auto run 'index' command.
    """,
    no_args_is_help=True,
)
@option_group(
    "Input/Output Options",
    *options_for_gfa_handling[:-2],  # Re-uses GFA path and output directory options
    option(
        "--output-csv",
        "output_csv_path",
        type=click.Path(file_okay=True, dir_okay=False, writable=True, path_type=Path),
        default=None,
        help="Path for the output CSV file. [Default: <gfa_path>/<gfa_name>_bandage.csv]",
    ),
)
@common_options_decorator
@click.pass_context
def to_bandage(ctx: click.Context, **kwargs: Any) -> None:
    """
    CLI command to generate a Bandage-compatible CSV from the GraTools index.

    Args:
        ctx (click.Context): The Click context object.
        **kwargs (Any): Keyword arguments from Click options.
    """
    # Instantiate Gratools, which handles finding/creating the index and setting up paths
    gratools_instance = Gratools(
        gfa_path=kwargs.get("gfa_file_path"),
        threads=kwargs.get("threads"),
        outdir=kwargs.get("output_directory"),
        meta=kwargs,
    )

    # Delegate the core logic to the new method in the Gratools class
    gratools_instance.export_to_bandage_csv(
        output_csv_path=kwargs.get("output_csv_path")
    )


# ==========================
# REGISTERING COMMANDS WITH SECTIONS
# ==========================
# This uses Cloup's ability to group commands into sections for better help output.

# Section 1: Commands for querying GFA content information
main_command.section(
    "GFA Content Information", # Section title in help output
    list_samples,              # from .gfa_content_info
    list_chr,                  # from .gfa_content_info
    stats                      # from .gfa_content_info
)

# Section 2: Commands for extracting data from GFA (subgraphs, sequences)
main_command.section(
    "GFA Data Extraction",        # Section title
    extract_subgraph_command,   # from .gfa_extract
    get_fasta_command,           # from .gfa_extract
    to_bandage
)

# Section 3: Commands for performing analyses on GFA data
main_command.section(
    "GFA Analysis",                               # Section title
    core_dispensable_ratio_command,             # from .gfa_analysis
    depth_nodes_stat_command,                   # from .gfa_analysis
    specific_groups_sample_command,       # from .gfa_analysis
    get_segments_by_depth_command               # from .gfa_analysis
)

# Adding commands that don't fit neatly into the above sections,
# or are top-level utilities.
main_command.add_command(index_gfa_file) # Add the 'index' command (renamed function)
main_command.add_command(shell_completion_command) # Utility for shell completion
main_command.add_command(secret_command)   # Example of a hidden or special command

# ==========================
# SCRIPT EXECUTION ENTRY POINT
# ==========================
if __name__ == "__main__":
    # This allows the script to be run directly, e.g., `python -m your_package.cli`
    # or `python your_cli_script.py`
    main_command()