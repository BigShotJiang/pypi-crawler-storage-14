# Commands

## Intallation de gratools

```bash
module load python/3.12 bedtools/2.31.1
virtualenv --python="/shared/ifbstor1/software/miniconda/envs/python-3.12/bin/python" env_gratools
source ./env_gratools/bin/activate
python3 -m pip install GraTools@git+https://forge.ird.fr/diade/gratools.git@main
gratools 
gratools index  -h
```

## Téléchargement des données de test

```bash
wget http://itrop.ird.fr/GraTools/data-gratools.tar.gz
tar -zxvf data-gratools.tar.gz
```


## Indexation 

```bash
gratools index --gfa data-gratools/Rice/NewRiceGraph_MGC.gfa.gz --threads 6
```

## Stats

```bash
gratools stats --gfa data.-gratools/Rice/NewRiceGraph_MGC.gfa.gz
```

╭─────────────────────────┬─────────────────────────────────────────────────────────────┬─────────────────────────────────────────────────────────────────────────╮                           
│ Category                │ Metric                                                      │ Value                                                                   │                           
├─────────────────────────┼─────────────────────────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────┤
│ Graph Overview          │ GFA File Name                                               │ NewRiceGraph_MGC                                                        │
│ Graph Overview          │ GFA Version                                                 │ 1.1                                                                     │
│ Graph Overview          │ Total Segments (S lines)                                    │ 26,461,214                                                              │
│ Graph Overview          │ Total Links (L lines)                                       │ 36,276,920                                                              │
│ Graph Overview          │ Total Walks (W lines)                                       │ 743                                                                     │
│ Graph Overview          │ Unique Samples in Walks                                     │ 13                                                                      │
│ Segment Statistics      │ Total Segment Length (bp)                                   │ 858,417,045                                                             │
│ Segment Statistics      │ Average Segment Length (bp)                                 │ 32.44                                                                   │
│ Segment Statistics      │ Median Segment Length (bp)                                  │ 1.00                                                                    │
│ Segment Statistics      │ Avg Length of Top 5% Longest Segments (bp)                  │ 508.68                                                                  │
│ Segment Statistics      │ Median Length of Top 5% Longest Segments (bp)               │ 155.00                                                                  │
│ Segment Statistics      │ Segment Length Distribution                                 │ 0-499bp: 26325942, 500-999bp: 77342, 1000-1999bp: 28835, 2000+bp: 29095 │
│ Link Statistics         │ Max Segment Degree                                          │ 0                                                                       │
│ Link Statistics         │ Average Segment Degree                                      │ 2.74                                                                    │
│ Link Statistics         │ Self-Links (S1 -> S1)                                       │ 0                                                                       │
│ Link Statistics         │ Inverted Links (S1+ -> S2-)                                 │ 0                                                                       │
│ Link Statistics         │ Both Negative Links (S1- -> S2-)                            │ 0                                                                       │
│ Path (Walk) Statistics  │ Total Length of All Paths (bp, input_genome_size)           │ 5,110,760,744                                                           │
│ Path (Walk) Statistics  │ Graph Compression Ratio (input_genome_size / graph_size_bp) │ 5.95                                                                    │
│ Path (Walk) Statistics  │ Max Segments in a Single Walk                               │ 1,658,219                                                               │
│ Path (Walk) Statistics  │ Sum of First Segment Lengths in Walks                       │ 5,442,916                                                               │
│ Segment Sharing & Depth │ Avg Unique Samples per Segment (Similarity Mean)            │ 7.36                                                                    │
│ Segment Sharing & Depth │ Median Unique Samples per Segment (Similarity Median)       │ 7.00                                                                    │
│ Segment Sharing & Depth │ StdDev Unique Samples per Segment (Similarity Std)          │ 4.47                                                                    │
│ Segment Sharing & Depth │ Avg Occurrences per Segment (Depth Mean)                    │ 7.49                                                                    │
│ Segment Sharing & Depth │ Median Occurrences per Segment (Depth Median)               │ 7.00                                                                    │
│ Segment Sharing & Depth │ StdDev Occurrences per Segment (Depth Std)                  │ 4.59                                                                    │
│ Graph Structure         │ Graph Density                                               │ 1.04e-07                                                                │
│ Graph Structure         │ Segments/Links Ratio                                        │ 0.73                                                                    │
│ Graph Structure         │ Dead-End Segments (degree 1)                                │ 0                                                                       │
│ Graph Structure         │ Isolated Segments (degree 0)                                │ 26,461,214                                                              │
│ Graph Structure         │ Number of Connected Components (CCs)                        │ 0                                                                       │
│ Graph Structure         │ Largest CC Size (bp)                                        │ 0                                                                       │
│ Graph Structure         │ Number of Disconnected CCs (excluding largest)              │ 0                                                                       │
│ Graph Structure         │ Total Length of Disconnected CCs (bp)                       │ 0                                                                       │
╰─────────────────────────┴─────────────────────────────────────────────────────────────┴─────────────────────────────────────────────────────────────────────────╯

## Extraction d'un sous-graphe

```bash
gratools extract_subgraph --gfa data-gratools/Rice/NewRiceGraph_MGC.gfa.gz --sample-query OsIR64RS1 --chrom-query CM020884.1_OsIR64RS1_chromosome9 --all-samples --suffix chr9 --threads 24
```

```bash
gratools extract_subgraph -g data-gratools/Rice/NewRiceGraph_MGC.gfa.gz -sq OsIR64RS1 -chr CM020884.1_OsIR64RS1_chromosome9 --all-samples  -t 12  --start-query 7400000 --stop-query 7800000
```