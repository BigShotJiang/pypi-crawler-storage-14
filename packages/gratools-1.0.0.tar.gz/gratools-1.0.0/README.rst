.. image:: ./docs/source/_static/GraTools_logo.png
   :target: https://gratools.readthedocs.io/en/latest/
   :align: center
   :alt: GraTools Logo

|PyPI version fury.io| |PyPI license|

|PyPI pyversions| |Downloads|

**GraTools is a powerful tool for analyzing and handling pangenome graphs quickly, whatever the model and therefore the size
and the complexity of the GFA file.**

It allows users to extract sequences or subgraphs, convert graphs into FASTA sequences, and identify shared and specific nodes across samples.
Additionally, it provides essential statistics for chromosomes and samples data.
With multi-threading support and flexible logging capabilities, Gratools is an efficient solution for pangenome graph analysis.

GraTools has been developed by IRD and CIRAD, as part of a collaboration between the PANEEC/DIADE and PHIM research teams.

.. image:: ./docs/source/_static/paneec_small.png
   :target: https://paneec.fr/

.. image:: ./docs/source/_static/ird_small.png
   :target: https://www.ird.fr/

.. image:: ./docs/source/_static/cirad_small.jpg
   :target: https://www.cirad.fr/

Documentation
=============

https://gratools.readthedocs.io/en/latest/


Install GraTools
================

GraTools can be installed like any standard Python package.
For a quick start, please refer to the `quick start guide <https://gratools.readthedocs.io/en/latest/quick_start.html#>`_ in the official documentation.

Using GraTools
==============


Gratools is composed of multiple commands that can be used with the following syntax:

.. code-block:: bash

    gratools [command] [options]

To view the list of available commands and their descriptions, simply run:

.. code-block:: bash

    gratools

This will display all the commands supported by Gratools.

For example, to list the chromosomes per sample in a GFA file

.. code-block:: bash

    gratools show_chr --gfa graph.gfa --full


For more details, refer to the For more details, refer to the `Quick Start section <https://gratools.readthedocs.io/en/latest/quick_start.html#getting-commands-list-and-help>`_ or the `full command manual <https://gratools.readthedocs.io/en/latest/commands/gratools_all.html>`_ in the official documentation. or the `full command manual <https://gratools.readthedocs.io/en/latest/commands/gratools_all.html>`_ in the official documentation.


Test GraTools with a GFA file
-----------------------------

.. code-block:: bash

    wget http://itrop.ird.fr/GraTools/data-gratools.tar.gz
    tar -zxvf data-gratools.tar.gz


Discovering GraSuite
====================

.. image:: ./docs/source/_static/grasuite.png
   :target: https://forge.ird.fr/diade/GraSuite
   :align: left
   :alt: GraTools Logo

GraTools is one of the tools in `GraSuite <https://forge.ird.fr/diade/GraSuite>`_, a comprehensive ecosystem of tools for working with GFA pangenome graphs — from creation to analysis and visualization.

Citation
========

https://forge.ird.fr/diade/gratools

Maintainer
==========

* Sébastien RAVEL (PHIM, CIRAD), sebastien.ravel@cirad.fr
* Christine TRANCHANT (DIADE, IRD), christine.tranchant@ird.fr

Authors
=======

* Sébastien RAVEL (PHIM, CIRAD)
* Camille CARRETTE (PANEEC/DIADE, IRD/SYNGENTA)
* Nina MARTHE (PANEEC/DIADE, IRD)
* Mohamed MOURDAS (PANEEC/DIADE, IRD)
* François SABOT (PANEEC/DIADE, IRD)
* Christine TRANCHANT (PANEEC/DIADE, IRD)

Thanks
======

* Cécile Triay for the logo.
* the  `i-trop plateform <https://bioinfo.ird.fr>`_, especially Ndomassi Tando, for the support.

License
=======

Licensed under GLPLv3.

Intellectual property belongs to `IRD <https://www.ird.fr>`_ , `CIRAD <https://www.cirad.fr/>`_ and previously cited authors.


.. |PyPI pyversions| image:: https://img.shields.io/pypi/pyversions/gratools.svg
   :target: https://pypi.python.org/pypi/gratools/

.. |Downloads| image:: https://img.shields.io/pypi/dm/gratools?color=orange&logo=gratools-pypi
   :target: https://pypi.org/project/gratools
   :alt: PyPi downloads

.. |PyPI version fury.io| image:: https://badge.fury.io/py/gratools.svg
   :target: https://pypi.python.org/pypi/gratools/

.. |PyPI license| image:: https://img.shields.io/pypi/l/gratools.svg
   :target: https://pypi.python.org/pypi/gratools/