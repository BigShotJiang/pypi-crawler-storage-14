# GraTools Contribution guide

Welcome to GraTools contribution guide and thank you for helping us making GraTools the best open source tool for pangenome manipulations.

## Reporting new issue 

[Opening an issue](https://forge.ird.fr/diade/GraTools/issues/new?issue%5Bassignee_id%5D=&issue%5Bmilestone_id%5D=) does not imply to fill the  contribution agreement.

Please follow as much as possible this template :

> ⚠️ *One issue, One bug*
>
>(Describe your issue in detail. Provide as much as possible steps to reproduce.)
>
>### Environment
>
>(describe your python and OS versions, the GraTools version, etc.)
>
>### Expected Behavior
>
>(Write what you thought would happen.)
>
>### Actual Behavior
>
>(Write what happened. Include screenshots if needed.)

## What to contribute

You can contribute to GraTools in the following domains:

* Code
* Tests
* Documentation
* Packaging and distributing

## Before contributing

Before submitting your first contribution, please take the time to fill GraTools contribution agreement. We will not accept any contribution without it !

You can find the individual agreement [here](https://forge.ird.fr/diade/GraTools/-/blob/main/Contributors/contributorAgreementIndividual.md?ref_type=heads) and the entity agreement 
[here](https://forge.ird.fr/diade/GraTools/-/blob/main/Contributors/contributorAgreementEntity.md?ref_type=heads). Please send us your agreement at [gratools@ird.fr](mailto:gratools@ird.fr).

### Why a contribution agreement ?

We need your agreement as one of GraTools contributor to take any decisions relative to the future of GraTools, in particular for the licensing aspects. There is thus some legal consideration about how your contribution can be used and distributed in GraTools. So please take your time and read the agreement before sending it to us. And if you have any question, feel free to ask us at [gratools@ird.fr](mailto:gratools@ird.fr).

### Contributing to GraTools Code

Before contributing to GraTools code you should ask us before hand at [gratools@ird.fr](mailto:gratools@ird.fr). This will prevent you from submitting code that we won't integrate: GraTools is still under heavy development and some featured modules are refactored quite often.

Outside of GraTools core code, you can help us [solve bugs](https://forge.ird.fr/diade/GraTools/issues), or write [new tests](https://forge.ird.fr/diade/GraTools/-/blob/main/src/testunits/README.md?ref_type=heads).

### Contributing to GraTools Documentation

Helping us to write GraTools documentation is one of the best way to help us making GraTools a more usable tool. 

You can also write GraTools example or tutorials, both are direly needed.

### Contributing to GraTools Packaging and Distribution

Packaging and distributing GraTools helps a lot by letting GraTools users easily access updates. We currently have [pip](https://pypi.python.org/pypi/GraTools) packaging for GraTools. Please contact us if you plan to package GraTools. We will be happy to help X)

## How to contribute

For your first contribution, you should fork GraTools, make your contribution and send us a merge request. Before contributing, please take the time to warn us at [gratools@ird.fr](mailto:gratools@ird.fr) so we can help you out with your contribution.

## Notes
The current manual is based on [aGrum manual for contributing](https://gitlab.com/agrumery/aGrUM/-/blob/master/CONTRIBUTING.md?ref_type=heads)

