# (C) 2025 GoodData Corporation

from .logger import LoggerLike, LogObserver

__all__ = [
    "LoggerLike",
    "LogObserver",
]
