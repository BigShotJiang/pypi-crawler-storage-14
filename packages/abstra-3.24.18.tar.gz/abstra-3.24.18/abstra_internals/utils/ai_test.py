from unittest import TestCase


class TestAiWs(TestCase): ...
