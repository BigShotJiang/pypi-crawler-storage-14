## API Documentation
::: zizou.data
::: zizou.rsam
::: zizou.ssam
::: zizou.dsar
::: zizou.spectral_features
::: zizou.pca
::: zizou.autoencoder
::: zizou.visualise
::: zizou.feature_base
::: zizou.anomaly_base
::: zizou.util