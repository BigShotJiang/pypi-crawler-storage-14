# Manifest

::: geneva.manifest.mgr.GenevaManifest

::: geneva.manifest.builder.GenevaManifestBuilder
