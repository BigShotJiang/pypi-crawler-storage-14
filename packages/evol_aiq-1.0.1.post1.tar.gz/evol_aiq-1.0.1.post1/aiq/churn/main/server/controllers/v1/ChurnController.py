import logging
from sys import api_version
from flask import Blueprint, request, jsonify

from aiq.churn.main.server.services.ChurnService import ChurnService

api_version = "1"

logger = logging.getLogger(__name__)

def create_churn_bp_v1(churn_service: ChurnService):
    churn_bp = Blueprint('churn_bp', __name__, url_prefix='/churn/v1/')

    # POST /churn/v1/startTrain - JSON: {username, password}
    @churn_bp.route('/startTrain', methods=['POST'])
    def start_train():
        data = request.get_json()
        start_train_result = churn_service.start_train(data)
        return jsonify(start_train_result.to_dict(api_version)), 200

    # POST /churn/v1/publishModel - JSON: {model_name, service_name, model_version, username, password}
    @churn_bp.route('/publishModel', methods=['POST'])
    def publish_model():
        data = request.get_json()
        publish_model_result = churn_service.publish_model(data)
        return jsonify(publish_model_result.to_dict(api_version)), 200

    # POST /churn/v1/predict - JSON: {model_name, service_name, model_version, username, password}
    @churn_bp.route('/predict', methods=['POST'])
    def predict():
        data = request.get_json()
        # logger.info(data.__class__.__name__)
        prediction_result = churn_service.predict(data)
        return jsonify(prediction_result.to_dict(api_version)), 200

    return churn_bp