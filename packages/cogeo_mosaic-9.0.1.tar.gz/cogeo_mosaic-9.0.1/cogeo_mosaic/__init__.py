"""Cogeo_mosaic."""

__version__ = "9.0.1"
