"""cogeo-mosaic logger."""

import logging

logger = logging.getLogger("cogeo-mosaic")
