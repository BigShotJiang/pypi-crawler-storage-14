__version__ = "0.0.1"

def ping():
    """Simple placeholder function."""
    return "gitspaces placeholder"
