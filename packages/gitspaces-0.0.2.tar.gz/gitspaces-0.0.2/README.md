# gitspaces

Dummy package to reserve the name `gitspaces` on PyPI.

This package is intentionally minimal and contains a placeholder function.

gitspaces coming soon