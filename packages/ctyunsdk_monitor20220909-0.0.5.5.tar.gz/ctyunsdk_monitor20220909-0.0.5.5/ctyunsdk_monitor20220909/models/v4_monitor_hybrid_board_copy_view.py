from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardCopyViewRequest:
    viewID: str  # 要复制的监控视图ID
    destBoardID: str  # 目标监控大盘ID
    viewName: Optional[str] = None  # 监控视图副本名称，默认为原监控视图名称加"_copy"



@dataclass_json
@dataclass
class V4MonitorHybridBoardCopyViewResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardCopyViewReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardCopyViewReturnObj:
    viewID: Optional[str] = None  # 复制的新视图ID



