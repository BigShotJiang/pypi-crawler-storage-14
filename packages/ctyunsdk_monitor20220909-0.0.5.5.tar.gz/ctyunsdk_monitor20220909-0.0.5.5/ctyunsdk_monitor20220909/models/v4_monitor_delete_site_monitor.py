from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorDeleteSiteMonitorRequest:
    taskIDList: List[str]  # 站点监控任务ID列表



@dataclass_json
@dataclass
class V4MonitorDeleteSiteMonitorResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorDeleteSiteMonitorReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorDeleteSiteMonitorReturnObj:
    success: Optional[bool] = None  # 删除成功标识



