from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskAnomalyRequest:
    regionID: str  # 资源池ID
    inspectionType: int  # 本参数表示巡检类型，见巡检项查询接口返回。
    taskID: str  # 巡检任务ID



@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskAnomalyResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorIntelligentInspectionQueryTaskAnomalyReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskAnomalyReturnObj:
    inspectionAnomalyList: Optional[List['V4MonitorIntelligentInspectionQueryTaskAnomalyReturnObjInspectionAnomalyList']] = None  # 巡检异常列表


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionQueryTaskAnomalyReturnObjInspectionAnomalyList:
    inspectionItem: Optional[int] = None  # 本参数表示巡检项。
    inspectionName: Optional[str] = None  # 本参数表示巡检项名称
    anomalyCount: Optional[int] = None  # 巡检项的异常数量
    solveTime: Optional[int] = None  # 治理时间，秒级。



