from enum import Enum


class ReportType(Enum):
    TABULAR = "tabular"
    TIMESERIES = "timeseries"
