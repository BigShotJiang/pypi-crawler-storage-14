from typing import List

from ydata.report.metrics import MetricGroup


class Document:
    groups: List[MetricGroup]
