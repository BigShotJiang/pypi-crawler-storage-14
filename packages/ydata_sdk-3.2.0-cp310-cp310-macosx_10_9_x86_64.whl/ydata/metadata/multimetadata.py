from __future__ import annotations

from os import getenv
from pickle import HIGHEST_PROTOCOL, dump, load

from dask import compute
from pandas import DataFrame
from pandas.api.types import is_numeric_dtype

from ydata.characteristics import ColumnCharacteristic
from ydata.dataset import Dataset, DatasetType, MultiDataset
from ydata.dataset.schemas.datasets_schema import ForeignReference, MultiTableSchema, RelationType, TableSchema
from ydata.metadata import Metadata
from ydata.metadata.schema_validator import SchemaValidator
from ydata.metadata.utils import dropna, value_counts
from ydata.utils.configuration import TextStyle
from ydata.utils.data_types import DataType
from ydata.utils.exceptions import InvalidDatasetTypeError
from ydata.utils.logger import utilslogger_config

logger = utilslogger_config(verbose=getenv(
    "VERBOSE", "false").lower() == "true")


def _format_count(count, total):
    ratio = count / total if total > 0 else 0
    return f"{count} ({round(100. * ratio, 2):.2f}%)"


class MultiMetadata:
    def __init__(
        self,
        multiset: MultiDataset,
        tables_metadata: dict[str, Metadata] | None = None,
        dataset_attrs: dict[str, dict] | None = None,
        dataset_type: dict[str, DatasetType | str] | None = None,
        schema: MultiTableSchema | None = None
    ) -> None:
        self._dataset_attrs = dataset_attrs
        self.dataset_type = {}
        # Metadata are computed only if not provided by the user
        tables_metadata = tables_metadata if tables_metadata is not None else {}
        self._metas = {
            k: tables_metadata[k] for k, _ in multiset.items() if k in tables_metadata
        }
        if len(multiset.keys()) > len(self._metas):
            uncomputed_metadata = set(
                multiset.keys()) - set(self._metas.keys())
            logger.info(
                f"[MULTIMETADATA] - Calculating metadata for tables: {uncomputed_metadata}.")
        self._metas.update({k: Metadata(v) if v is not None else Metadata(multiset[k])
                           for k, v in multiset.items() if k not in self._metas})

        logger.info("[MULTIMETADATA] - Initializing characteristics.")
        self.schema = schema if schema is not None else multiset.schema
        for k, m in self._metas.items():
            if m is not None:
                self._metas[k] = self._add_id_characteristics(
                    k, m, multiset[k])

        logger.info("[MULTIMETADATA] - Validating schema.")
        validator = SchemaValidator()
        self.__warnings = validator.get_warnings(self.schema)

        logger.info("[MULTIMETADATA] - Update relationship types.")
        self._update_foreign_key_relations()
        ''' Deactivate for now as it is computationally expensive
        no_elements = self._compute_zero_cardinality_fks(dataset=multiset)
        self.zero_children_relations = no_elements[0]
        self.zero_parents_relations = no_elements[1]
        '''

        dataset_type = dataset_type if dataset_type is not None else {}
        try:
            for k in self._metas.keys():
                if k in dataset_type.keys():
                    self.dataset_type[k] = DatasetType(dataset_type[k])
        except ValueError:
            raise InvalidDatasetTypeError(
                f"Provided dataset_type {dataset_type} is not valid."
            )

        self.__valid_inputs(self._dataset_attrs)
        multiset.add_observer_for_new_tables(self._new_table_callback)
        self._deferred_request_endpoint = multiset._deferred_request_endpoint()

    @property
    def warnings(self) -> dict:
        return self.__warnings

    def _new_table_callback(self, table_name: str, dataset: Dataset):
        self._metas[table_name] = Metadata(dataset)
        self._metas[table_name] = self._add_id_characteristics(
            table_name, self._metas[table_name], dataset)
        self._update_foreign_key_relations()

    def _add_id_characteristics(self, table_name: str, meta: Metadata, dataset: Dataset) -> Metadata:
        """Adds the ID characteristic to primary keys and foreign keys.

        If the metadata is lazy-computed, only the tables already
        fetched are considered.
        """
        table = self.schema.get(table_name)
        if table is not None:
            keys = []
            if table.primary_keys:
                meta.add_characteristics(
                    {pk: ColumnCharacteristic.ID for pk in table.primary_keys})
                keys.extend(table.primary_keys)

            if table.foreign_keys:
                meta.add_characteristics(
                    {fk.column: ColumnCharacteristic.ID for fk in table.foreign_keys})
                keys.extend([fk.column for fk in table.foreign_keys])

            key_types = {key: DataType.CATEGORICAL for key in keys}
            meta.update_datatypes(key_types, dataset)
        return meta

    def _update_foreign_key_relations(self):
        """Updates the type of relationships between tables based on the
        cardinality of the foreign keys.

        If the metadata is lazy-computed, only the tables already
        fetched are considered.
        """
        # TODO: Detect the relation type automatically based on the cardinality for each columns
        for k, v in self._metas.items():
            if v is not None:
                table = self.schema.get(k)
                if table is not None and table.foreign_keys:
                    for fk in table.foreign_keys:
                        if self._metas[fk.parent_table] is not None and self._metas[fk.table] is not None:
                            # Foreign key is unique in the parent table
                            if self._metas[fk.parent_table].summary['cardinality'][fk.parent_column] == self._metas[fk.parent_table].summary['nrows']:
                                if self._metas[fk.table].summary['nrows'] == self._metas[fk.parent_table].summary['cardinality'][fk.parent_column]:
                                    fk.relation_type = RelationType.ONE_TO_ONE
                                else:
                                    fk.relation_type = RelationType.ONE_TO_MANY

    def _compute_zero_cardinality_fks(self, dataset: MultiDataset):
        """ For foreign keys with 1-N cardinality, this method compute the number of rows
        in the parent table without any children, i.e. when N = 0.
        """
        tasks_children = {
            t: {}
            for t, m in self._metas.items()
            if m is not None
        }
        tasks_parents = {
            t: {}
            for t, m in self._metas.items()
            if m is not None
        }
        for table_name, m in self._metas.items():
            if m is not None:
                table = self.schema.get(table_name)
                if table is not None and table.foreign_keys:
                    child_table = dataset[table_name].to_dask()
                    if child_table is not None:
                        for fk in table.foreign_keys:
                            if fk.relation_type == RelationType.ONE_TO_MANY:
                                parent_table = dataset[fk.parent_table].to_dask(
                                )
                                if parent_table is not None:
                                    # 1-N with N = 0 (no children)
                                    count_without_children = self._metas[fk.parent_table].summary['nrows'] - parent_table[fk.parent_column].astype(
                                        'category').cat.set_categories(child_table[fk.column].unique().dropna().values).dropna().shape[0]
                                    tasks_parents[table_name][fk] = count_without_children
                                    count_without_parents = self._metas[fk.table].summary['missings'].get(fk.column, 0) + self._metas[fk.table].summary['nrows'] - child_table[fk.column].astype(
                                        'category').cat.set_categories(parent_table[fk.parent_column].unique().dropna().values).dropna().shape[0]
                                    tasks_children[table_name][fk] = count_without_parents
        return compute([tasks_parents, tasks_children])[0]

    def compute(self):
        """Request all the tables that are not available yet."""
        for key in self._metas.keys():
            if self._metas[key] is None:
                self.__getitem__(key)
        return self

    def __valid_inputs(self, dataset_attrs):
        for k in self._metas.keys():
            if k in self.dataset_type.keys():
                if self.dataset_type[k] == DatasetType.TIMESERIES:
                    assert dataset_attrs, "Timeseries dataset requires dataset_attrs."
                    assert (
                        "sortbykey" in dataset_attrs[k]
                    ), "Timeseries dataset requires sortbykey attribute."

    def __getitem__(self, key: str) -> Metadata:
        if self._metas[key] is None and self._deferred_request_endpoint is not None:
            # If the Metadata is not available, the table is requested from the MultiDataset,
            #   which will then trigger the Metadata computation through the callback function.
            self._deferred_request_endpoint.request_table(key)
        return self._metas[key]

    def items(self):
        self.compute()
        return self._metas.items()

    def keys(self):
        return self._metas.keys()

    def values(self):
        self.compute()
        return self._metas.values()

    def __iter__(self):
        self.compute()
        return self._metas.__iter__()

    def __delitem__(self, table: str):
        del self._metas[table]

    def __str__(self):
        def _get_pk_summary(pks: list[str], table: str):
            summary = []
            for pk in pks:
                for c in self[table].columns[pk].characteristics:
                    summary.append(c.value)
            return summary

        def _get_fk_summary(fk: list, table: str):
            summary = {}
            for a in fk:
                characteristics = []
                for c in self[table].columns[a].characteristics:
                    characteristics.append(c.value)
                summary[a] = characteristics
            return summary

        n_tables = len(self.schema)

        str_repr = TextStyle.BOLD + "MultiMetadata Summary \n \n" + TextStyle.END

        str_repr += (
            TextStyle.BOLD
            + "Tables Summary "
            + TextStyle.END
            + "\n"
        )
        str_repr += (
            TextStyle.BOLD
            + "Number of tables: "
            + TextStyle.END
            + f"{n_tables} \n \n"
        )

        summary = []
        rel_summary = []
        for table, table_details in self.schema.items():
            if self._metas[table] is not None:
                pk = table_details.primary_keys
                pk_characteristics = _get_pk_summary(
                    table_details.primary_keys, table) if len(pk) else ''

                fk = [key.column for key in table_details.foreign_keys]
                fk_characteristics = _get_fk_summary(fk, table)

                for fks in table_details.foreign_keys:
                    rel_item = {
                        'Table': fks.table,
                        'Column': fks.column,
                        'Parent Table': fks.parent_table,
                        'Parent Column': fks.parent_column,
                        'Relation Type': fks.relation_type.value,
                        # 'Rows with no children': _format_count(self.zero_children_relations[fks.table].get(fks, 0), self[fks.parent_table].summary['nrows']),
                        # 'Rows with no parents': _format_count(self.zero_parents_relations[fks.table].get(fks, 0), self[fks.table].summary['nrows']),
                    }
                    rel_summary.append(rel_item)

                table_summary = {"Table name": table,
                                 "# cols": self[table].ncols,
                                 "# nrows": self[table].summary['nrows'],
                                 "Primary keys": pk,
                                 "Foreign keys": fk if len(fk) else '',
                                 "PK characteristics": pk_characteristics if len(pk_characteristics) else '',
                                 "FK characteristics": fk_characteristics if len(fk_characteristics) else '',
                                 "Notes": ""}
            else:
                table_summary = {"Table name": table,
                                 "# cols": "",
                                 "# nrows": "",
                                 "Primary keys": "",
                                 "Foreign keys": "",
                                 "PK characteristics": "",
                                 "FK characteristics": "",
                                 "Notes": "The Metadata for this table has not been requested yet."}
            summary.append(table_summary)

        str_repr += DataFrame(summary).to_string()

        str_repr += ("\n \n"
                     + TextStyle.BOLD
                     + "Relations Summary "
                     + TextStyle.END
                     + "\n"
                     )
        str_repr += (
            TextStyle.BOLD
            + "Number of relations: "
            + TextStyle.END
            + f"{len(rel_summary)} \n \n"
        )
        str_repr += DataFrame(rel_summary).to_string()

        if self.warnings:
            str_repr += f"\n \n{TextStyle.BOLD}Warnings Summary{TextStyle.END}\n"
            for k, warning in self.warnings.items():
                str_repr += f"{TextStyle.BOLD}{k}: {TextStyle.END}"
                str_repr += f"{warning.description}\n"
        else:
            str_repr += f"\n \n{TextStyle.BOLD} No warnings Found {TextStyle.END}\n"

        return str_repr

    def save(self, path: str):
        "Creates a pickle of the metadata object stored in the provided path."
        try:
            # The deferred request endpoint must be forgotten before saving because it can't be pickled.
            #   Consequently, after the load no new tables can be fetched.
            #   As such, all needed tables must be fetched before saving the object.
            self.compute()
            self._deferred_request_endpoint = None
            # Saving NameTuple as a dict to pickle the object
            with open(path, "wb") as handle:
                dump(self, handle, HIGHEST_PROTOCOL)
        except FileNotFoundError:
            raise Exception(
                f"The directory implied in the provided path: '{path}', could not be found. Please save \
                in an existing folder."
            )

    @staticmethod
    def load(path: str) -> Metadata:
        "Loads a metadata object from a path to a pickle."
        try:
            with open(path, "rb") as handle:
                metadata = load(handle)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"The path: '{path}', could not be found. Please provide an existing load path."
            )
        assert isinstance(
            metadata, MultiMetadata
        ), "The provided path does not refer to a MultiMetadata object. Please \
            verify your input path."
        return metadata

    def set_table_dataset_type(
        self,
        table_name: str,
        dataset_type: str | DatasetType,
        dataset_attrs: dict | None = None
    ):
        """Update table's metadata dataset type.

        Args:
            table_name (str): Table that will have the dataset type updated
            dataset_type (str | DatasetType): new dataset type
            dataset_attrs (dict | None, optional): Dataset attrs for TIMESERIES dataset. Defaults to None.

        Raises:
            KeyError: when MultiMetadata does not contain the any table named as {table_name}
        """
        if table_name not in self._metas:
            raise KeyError(f"MultiMetadata does not have table [{table_name}]")
        self[table_name].set_dataset_type(
            dataset_type=dataset_type, dataset_attrs=dataset_attrs)

    def set_table_dataset_attrs(
        self,
        table_name: str,
        sortby: str | list,
        entities: str | list | None = None
    ):
        """Update table's metadata dataset attributes.

        Args:
            table_name (str): Table that will have the dataset attributes updated
            sortby (str | List[str]): Column(s) that express the temporal component
            entities (str | List[str] | None, optional): Column(s) that identify the entities. Defaults to None

        Raises:
            KeyError: when MultiMetadata does not contain the any table named as {table_name}
        """
        if table_name not in self._metas:
            raise KeyError(f"MultiMetadata does not have table [{table_name}]")
        self[table_name].set_dataset_attrs(sortby=sortby, entities=entities)

