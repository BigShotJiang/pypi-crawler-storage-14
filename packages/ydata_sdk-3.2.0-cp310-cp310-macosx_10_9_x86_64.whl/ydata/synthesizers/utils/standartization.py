"""Methods for data standartization."""
