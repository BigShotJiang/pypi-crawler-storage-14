"""
Matrix subpackage containing rref function.
"""
from .elementary import rref, rowswap, rowscale, rowreplacement
__all__=['rref, rowswap, rowscale,rowreplacement']