from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequest:
    name: str  # 监控大盘名称
    viewsQueryParams: Optional['V4MonitorHybridBoardCreateRequestViewsQueryParams'] = None  # 视图查询参数
    defaultDatasource: Optional['V4MonitorHybridBoardCreateRequestDefaultDatasource'] = None  # 默认数据源，如果views中datasource下的namespace配置了$namespace，则会自动替换为本配置值
    views: Optional[List['V4MonitorHybridBoardCreateRequestViews']] = None  # 视图内容


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestViewsQueryParams:
    job: Optional[List[str]] = None  # 任务，默认查询所有


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestDefaultDatasource:
    type: str  # 数据类型。取值范围:<br>prometheus<br>根据以上范围取值。
    namespace: str  # 指标仓库名称，支持使用$namespace来自动替换为defaultDatasource的仓库名称


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestViews:
    name: str  # 监控大盘视图名称
    type: str  # 视图类型。取值范围:<br>timeSeries：折线图。<br>barChart：柱状图。<br>table：表格。<br>根据以上范围取值。
    datasource: 'V4MonitorHybridBoardCreateRequestViewsDatasource'  # 数据源
    fieldConfig: 'V4MonitorHybridBoardCreateRequestViewsFieldConfig'  # 字段配置
    targets: List['V4MonitorHybridBoardCreateRequestViewsTargets']
    description: Optional[str] = None  # 视图描述


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestViewsDatasource:
    type: str  # 数据类型。取值范围:<br>prometheus<br>根据以上范围取值。
    namespace: str  # 指标仓库名称，支持使用$namespace来自动替换为defaultDatasource的仓库名称


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestViewsFieldConfig:
    defaults: 'V4MonitorHybridBoardCreateRequestViewsFieldConfigDefaults'  # 默认配置


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestViewsFieldConfigDefaults:
    unit: str  # 单位


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateRequestViewsTargets:
    expr: str  # prometheus表达式
    legendFormat: Optional[str] = None  # 图例格式化
    period: Optional[int] = None  # 周期



@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardCreateReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateReturnObj:
    boardID: Optional[str] = None  # 监控大盘ID
    viewIDs: Optional[List[str]] = None  # 视图ID



