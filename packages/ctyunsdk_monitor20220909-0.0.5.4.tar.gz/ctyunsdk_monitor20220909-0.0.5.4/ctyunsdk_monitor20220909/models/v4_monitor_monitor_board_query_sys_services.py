from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQuerySysServicesRequest:
    regionID: str  # 资源池ID



@dataclass_json
@dataclass
class V4MonitorMonitorBoardQuerySysServicesResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorMonitorBoardQuerySysServicesReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQuerySysServicesReturnObj:
    data: Optional[List['V4MonitorMonitorBoardQuerySysServicesReturnObjData']] = None  # 服务维度信息


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQuerySysServicesReturnObjData:
    service: Optional[str] = None  # 云监控服务
    serviceName: Optional[str] = None  # 云监控服务的名称
    dimensions: Optional[List['V4MonitorMonitorBoardQuerySysServicesReturnObjDataDimensions']] = None  # 云监控维度


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQuerySysServicesReturnObjDataDimensions:
    dimension: Optional[str] = None  # 云监控维度
    dimensionName: Optional[str] = None  # 云监控维度的名称



