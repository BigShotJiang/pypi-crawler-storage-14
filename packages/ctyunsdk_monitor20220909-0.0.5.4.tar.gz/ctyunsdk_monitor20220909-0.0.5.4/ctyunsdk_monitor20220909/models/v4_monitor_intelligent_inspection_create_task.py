from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionCreateTaskRequest:
    regionID: str  # 资源池ID



@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionCreateTaskResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorIntelligentInspectionCreateTaskReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionCreateTaskReturnObj:
    taskID: Optional[str] = None  # 巡检任务ID



