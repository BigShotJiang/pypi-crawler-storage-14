from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardDeleteViewRequest:
    viewIDs: List[str]  # 要删除的监控视图ID



@dataclass_json
@dataclass
class V4MonitorHybridBoardDeleteViewResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardDeleteViewReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardDeleteViewReturnObj:
    success: Optional[bool] = None  # 是否删除成功



