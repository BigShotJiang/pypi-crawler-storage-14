from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorAlarmRuleQueryBindingNoticeStrategyRequest:
    regionID: str  # ctyun资源池ID
    noticeStrategyID: str  # 通知策略ID
    service: str  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    dimension: str  # 云监控维度。取值范围： <br />ecs：云主机。 <br />disk：云硬盘。 <br />pms：物理机。 <br />... <br />具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 页大小，默认为20
    alarmRuleName: Optional[str] = None  # 告警规则名称，支持模糊查询



@dataclass_json
@dataclass
class V4MonitorAlarmRuleQueryBindingNoticeStrategyResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorAlarmRuleQueryBindingNoticeStrategyReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorAlarmRuleQueryBindingNoticeStrategyReturnObj:
    alarmRules: Optional[List['V4MonitorAlarmRuleQueryBindingNoticeStrategyReturnObjAlarmRules']] = None  # 告警规则
    totalCount: Optional[int] = None  # 总记录数
    currentCount: Optional[int] = None  # 当前页记录数
    totalPage: Optional[int] = None  # 总页数


@dataclass_json
@dataclass
class V4MonitorAlarmRuleQueryBindingNoticeStrategyReturnObjAlarmRules:
    alarmRuleID: Optional[str] = None  # 告警规则ID
    alarmRuleName: Optional[str] = None  # 规则名
    service: Optional[str] = None  # 服务
    status: Optional[int] = None  # 本参数表示告警规则启用状态。取值范围：<br>0：启用。<br>1：停用。<br>根据以上范围取值。



