import typing
import sys
from enum import Enum
from dataclasses import dataclass, field
from typing import NamedTuple, List, Optional, Sequence, Tuple, Union, TypeVar
import pytest

from data_helpers.cls_parsing import (
    dict_to_cls,
    _replace_recursive,
    get_parser,
    get_val_from_tuple,
    parse_base_val,
    parse_dataclass_val,
    parse_enum_val,
    parse_list_val,
    rsetattr,
    rgetattr,
    check_types,
)

if sys.version_info <= (3, 9):
    list = List
    tuple = Tuple
    sequence = Sequence


class DemoEnum(Enum):
    DEFAULT = "default"

@dataclass
class DemoDataclass:
    foo: int
    bar: str = "hello"
    number: int = 1
    # number: FieldType("Number Field", int, 1) = 1


@dataclass
class DemoDataclassSimple:
    foo: int = 0


@pytest.mark.parametrize(['f', 't', 'v', 'result'], [
    ('field', type(1), 1, 1),
    ('field', type("a"), "a", "a"),
    ('field', type(True), True, True),
])
def test_parse_base_val(f, t, v, result):
    assert parse_base_val(f, t, v) == result


UX = TypeVar('UX')
UY = TypeVar('UY')
PiecewiseFunction = Tuple[List[UX], List[UY]]


@pytest.mark.parametrize(['f', 't', 'v', 'result', 'error'], [
    ('field', type([]), [1, 2, 3], None, TypeError),
    ('field', List[int], [1, 2, 3], [1, 2, 3], None),
    ('field', PiecewiseFunction, None, [], None),
    # ('field', List[int], ['1','2','3'], [1,2,3], None), # TODO: fix this test
])
def test_parse_list_val(f, t, v, result, error):
    if error:
        with pytest.raises(error):
            parse_list_val(f, t, v) == result # type: ignore
    else:
        assert parse_list_val(f, t, v) == result


@pytest.mark.parametrize(['f', 't', 'v', 'result', 'error'], [
    ('field', DemoDataclass, {"foo": 1, "bar": "world", "number": 3}, DemoDataclass(1, "world", 3), None),
    ('field', DemoDataclass, {}, None, None),
    ('field', DemoDataclassSimple, {}, DemoDataclassSimple(), None),
])
def test_parse_dataclass_val(f, t, v, result, error):
    if error:
        with pytest.raises(error):
            parse_dataclass_val(f, t, v) == result # type: ignore
    else:
        assert parse_dataclass_val(f, t, v) == result


def test_dict_to_cls():
    class B(NamedTuple):
        foo: typing.Optional[str] = None

    class A(NamedTuple):
        b: B = B()
        c: typing.Optional[int] = None
        e: typing.Optional[int] = None

    d = {
        "b": {
            "foo": "bar"
        },
        "c": 1,
    }

    new_object = dict_to_cls(d, A)
    assert new_object == A(B('bar'), 1)


def test_dict_to_dataclass():
    @dataclass
    class B:
        foo: typing.Optional[str] = None

    @dataclass
    class A:
        b: B = field(default_factory=lambda: B())
        c: typing.Optional[int] = None
        e: typing.Optional[int] = None

    d = {
        "b": {
            "foo": "bar"
        },
        "c": 1,
    }

    new_object = dict_to_cls(d, A)
    assert new_object == A(B('bar'), 1)


def test_dict_to_cls_b():
    class B(NamedTuple):
        foo: typing.Optional[str] = None

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()

    d = {
        "a": {
            "lat": 52.2,
            "lon": -1.12,
        },
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(a=A(lat=52.2, lon=-1.12))


def test_dict_to_cls_nested_named_tuple():
    class B(NamedTuple):
        parameters: List[str] = []

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()

    d = {
        "a": {
            "lat": 52.2,
            "lon": -1.12,
        },
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(a=A(lat=52.2, lon=-1.12))


def test_dict_to_cls_empty():
    class B(NamedTuple):
        parameters: List[str] = []

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    @dataclass
    class Wrap():
        a: typing.Optional[A] = None
        b: typing.Optional[B] = None

    d = {
        "a": {},
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(a=A(lat=None, lon=None))


def test_dict_to_cls_nested_list_of_lists_b():

    class Wrap(NamedTuple):
        a: List[List[int]] = [[0]]

    d = {
        "a": [
            [
                1, 2, 3
            ],
            [
                4, 5, 6,
            ]
        ],
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(a=[[1, 2, 3], [4, 5, 6]])


class FooEnum(Enum):
    A = 0
    B = 1


class BarEnum(Enum):
    A = "a"
    B = "b"


def test_dict_to_cls_with_enum():
    class Obj(NamedTuple):
        a: FooEnum
        b: FooEnum = FooEnum.B
        c: BarEnum = BarEnum.A

    d = {
        "a": 0,
        "c": "a"
    }

    new_object = dict_to_cls(d, Obj)
    assert new_object == Obj(a=FooEnum.A, b=FooEnum.B, c=BarEnum.A)


def test_dict_to_cls_list():
    class B(NamedTuple):
        parameters: List[str] = []
        parameters_alt: list[str] = []

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()
        c: List[str] = []

    d = {
        "c": ["a", "b"]
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(c=["a", "b"])


def test_dict_to_cls_nested_list():
    class B(NamedTuple):
        parameters: List[str] = []

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()
        c: List[str] = []

    d = {
        "b": {
            "parameters": [
                "a", "b"
            ]
        }
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(b=B(parameters=["a", "b"]))


def test_dict_to_cls_nested_list_of_lists():

    class Foo(NamedTuple):
        bar: List[List[float]] = []

    class Parameters(NamedTuple):
        foo: Foo = Foo()

    class B(NamedTuple):
        parameters: List[Parameters] = []

    class Wrap(NamedTuple):
        b: B = B()

    d = {
        "b": {
            "parameters": [
                {
                    "foo": {
                        "bar": [[1, 2], [3, 4]]
                    }
                }
            ]
        }
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(b=B(parameters=[Parameters(foo=Foo(bar=[[1, 2], [3, 4]]))]))

def test_dict_to_cls_typevar_class():

    class Car(NamedTuple):
        rar: typing.Optional[PiecewiseFunction] = None

    class Bar(NamedTuple):
        car: Car = Car()

    class Foo(NamedTuple):
        bar: List[Bar] = []

    class Wrap(NamedTuple):
        foo: Foo = Foo()
        see: typing.Optional[PiecewiseFunction] = None

    data = {
        "see": [[0, -1.0], [73.55, 0.0], [632.53, 1.0], [1471.0, 2.0]],
        "foo": {
            "bar": [
                {
                    "car": {
                        "rar": [[0, -1.0], [73.55, 0.0], [632.53, 1.0], [1471.0, 2.0]]
                    }
                }
            ]
        }
    }

    new_object: Wrap = dict_to_cls(data, Wrap) # type: ignore
    assert new_object.see is not None
    assert new_object.foo is not None
    assert new_object.see[0] == [0, -1.0]
    assert new_object.foo.bar is not None
    assert new_object.foo.bar[0] is not None
    assert new_object.foo.bar[0].car is not None
    assert new_object.foo.bar[0].car.rar is not None
    assert new_object.foo.bar[0].car.rar[0] == [0, -1.0]


def test_dict_to_cls_nested_list_of_tuple():
    class B(NamedTuple):
        parameters: List[str] = []

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()
        c: Sequence[A] = []

    d = {
        "c": [
            {
                "lat": 52.2,
                "lon": -1.12,
            },
            {
                "lat": 20.2,
                "lon": -10.12,
            },
        ]
    }

    new_object = dict_to_cls(d, Wrap)
    assert new_object == Wrap(c=[A(lat=52.2, lon=-1.12), A(lat=20.2, lon=-10.12)])


def test_dict_to_cls_invalid():
    class B(NamedTuple):
        foo: typing.Optional[str] = None

    class A(NamedTuple):
        lat: typing.Optional[float] = None
        lon: typing.Optional[float] = None

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()

    d = {
        "a": {
            "lat": False,
            "lon": -1.12,
        },
        "b": 4,
    }

    with pytest.raises(Exception):
        dict_to_cls(d, Wrap, strict=True)

    d2 = {
        "b": 4,
    }

    with pytest.raises(Exception):
        dict_to_cls(d2, Wrap, strict=True)

    d3 = {
        "z": 4,
    }

    with pytest.raises(Exception):
        dict_to_cls(d3, Wrap, strict=True)


class TestGetParser():

    def test_get_parser_Union(self):
        t = Union[int, float]
        parser = get_parser(t)
        assert parser == parse_base_val

    def test_get_parser_Union_enum(self):

        t = Union[DemoEnum, DemoEnum]
        parser = get_parser(t)
        assert parser == parse_enum_val

    def test_get_parser_Union_incompatible(self):
        # Should throw error if union types are not similar

        class A(NamedTuple):
            foo: typing.Optional[float] = None

        class B(NamedTuple):
            foo: List[str] = []

        t = Union[A, B]

        with pytest.raises(Exception) as e:
            get_parser(t)

        assert "Invalid Union Type" in str(e)

    def test_get_parser_typing_tuple(self):
        t = typing.Tuple
        parser = get_parser(t)
        assert parser == parse_list_val


class TestParsers:

    class TestEnum:

        def test_parse_enum_val(self):
            result = parse_enum_val('field', DemoEnum, 'default')
            assert result == DemoEnum.DEFAULT

        def test_parse_enum_val_invalid(self):
            with pytest.raises(TypeError):
                parse_enum_val('field', DemoEnum, 'invalid_value')

        def test_parse_enum_val_invalid_type(self):
            with pytest.raises(TypeError):
                parse_enum_val('field', DemoEnum, 123)

        def test_parse_enum_val_invalid_type_2(self):
            with pytest.raises(TypeError):
                parse_enum_val('field', DemoEnum, None, True)

    class TestUnionEnum:

        def test_parse_union_enum_val(self):
            result = parse_enum_val('field', Union[DemoEnum, DemoEnum], 'default')
            assert result == DemoEnum.DEFAULT

        def test_parse_union_enum_val_invalid(self):
            with pytest.raises(TypeError):
                parse_enum_val('field', Union[DemoEnum, DemoEnum], 'invalid_value')

    class TestOptional:

        def test_optional_with_value(self):
            parser = get_parser(Optional[int])
            result = parser('field', Optional[int], 1, False)
            assert result == 1

        def test_optional_without_value(self):
            parser = get_parser(Optional[int])
            result = parser('field', Optional[int], None, False)
            assert result is None

def test_replace_recursive():

    class B(NamedTuple):
        foo: str = 'hello'

    class A(NamedTuple):
        lat: float = 2
        lon: float = 3

    class Wrap(NamedTuple):
        a: A = A()
        b: B = B()
        c: int = 4

    updated_wrap_b = _replace_recursive(Wrap(), 'a.lat', 5)
    assert updated_wrap_b.a.lat == 5 # type: ignore


def test_replace_recursive_with_list():
    class B(NamedTuple):
        foo: str = 'hello'

    class A(NamedTuple):
        lat: float = 2
        lon: float = 3

    class Wrap(NamedTuple):
        a: A = A()
        b: List[B] = [B(), B()]
        c: int = 4

    updated_wrap_b = _replace_recursive(Wrap(), 'b.0.foo', 'world')
    assert updated_wrap_b.b[0].foo == 'world' # type: ignore


def test_get_nested_args_from_tuple():
    class A(NamedTuple):
        val: int = 1

    class Tup(NamedTuple):
        foo: int = 1
        a: A = A()
        arr: List[int] = [1, 2, 3]
    tup = Tup()

    result = get_val_from_tuple(tup, 'foo')
    assert result == 1
    result = get_val_from_tuple(tup, 'arr.1')
    assert result == 2
    result = get_val_from_tuple(tup, 'a.val')
    assert result == 1


class TestRGetAttr:

    def test_can_get_nested_value(self):
        obj = {
            "foo": {
                "bar": {
                    "zoo": "hello"
                }
            }
        }
        result = rgetattr(obj, 'foo.bar.zoo')
        assert result == 'hello'

class TestRsetattr:

    def test_can_set_base_attribute(self):
        base = {}
        out = rsetattr(base, 'foo', 'bar')
        assert out['foo'] == 'bar'

    def test_can_set_nested_attribute(self):
        base = {"foo": {}}
        out = rsetattr(base, 'foo.bar', 'bar')
        assert out['foo']['bar'] == 'bar'
        base = {"foo": {"bar": {}}}
        out = rsetattr(base, 'foo.bar.zoo', 'bar')
        assert out['foo']['bar']['zoo'] == 'bar'

    def test_can_create_missing_dicts(self):
        base = {}
        out = rsetattr(base, 'foo.bar', 'bar', create_missing_dicts=True)
        assert out['foo']['bar'] == 'bar'

    def test_can_create_missing_lists(self):
        base = {}
        out = rsetattr(base, 'foo.0', 'bar', create_missing_dicts=True)
        print(out)
        assert out['foo'][0] == 'bar'

    def test_can_create_missing_lists_padded(self):
        base = {}
        out = rsetattr(base, 'foo.3', 'bar', create_missing_dicts=True)
        print(out)
        assert out['foo'][3] == 'bar'
        assert out['foo'][0] == None
        assert len(out['foo']) == 4


class TestCheckTypes:

    def test_can_check_some_data(self):
        config_data = {
            "foo": 1,
            "bar": "world",
            "number": 3,
        }

        config: Union[DemoDataclass, None] = dict_to_cls(config_data, DemoDataclass)
        check_types(config)