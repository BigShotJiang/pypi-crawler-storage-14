class InferenceDeprecationWarning(Warning):
    pass


class InferenceExperimentalFeatureWarning(Warning):
    pass


class ModelDependencyMissing(Warning):
    pass
