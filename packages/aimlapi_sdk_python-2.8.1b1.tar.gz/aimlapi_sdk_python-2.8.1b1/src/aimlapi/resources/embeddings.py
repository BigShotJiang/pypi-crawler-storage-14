from __future__ import annotations

from openai.resources.embeddings import *  # noqa: F401, F403
