from __future__ import annotations

from openai.types.video_seconds import *  # noqa: F401, F403
