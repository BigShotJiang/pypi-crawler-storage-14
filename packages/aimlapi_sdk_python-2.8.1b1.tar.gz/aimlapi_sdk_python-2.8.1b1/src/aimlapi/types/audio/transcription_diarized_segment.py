from __future__ import annotations

from openai.types.audio.transcription_diarized_segment import *  # noqa: F401, F403
