from __future__ import annotations

from openai.types.audio.translation_verbose import *  # noqa: F401, F403
