from __future__ import annotations

from openai.types.file_deleted import *  # noqa: F401, F403
