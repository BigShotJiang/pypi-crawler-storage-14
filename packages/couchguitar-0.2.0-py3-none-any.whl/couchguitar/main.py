"""
CouchGuitar - Cross-platform PyQt6 application for displaying song lyrics with auto-scroll
and audio playback/recording capabilities.

Supports: Windows, Linux, macOS
"""

import sys
import platform
import importlib.resources as pkg_resources
from typing import Optional

import numpy as np
from scipy.io.wavfile import write as wav_write

from pydub import AudioSegment
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap, QPalette, QColor
from PyQt6.QtWidgets import (
    QApplication, QVBoxLayout, QFileDialog, QSplitter, QWidget,
    QTextEdit, QLabel, QHBoxLayout, QFrame, QSpacerItem,
    QSizePolicy, QMainWindow, QDialog, QPushButton
)
from qfluentwidgets import (
    PushButton, Slider, ComboBox,
    FluentIcon as FIF, setTheme, Theme, setThemeColor
)
import sounddevice as sd

# Import resource module - adjust this import based on your package structure
try:
    from couchguitar import resource
except ImportError:
    resource = None


# -----------------------------------------------------------------------------
# Dark Theme Stylesheet for Cross-Platform Consistency
# -----------------------------------------------------------------------------

DARK_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #202020;
    color: #ffffff;
}

QLabel {
    color: #ffffff;
}

QPushButton, PushButton {
    background-color: #3d3d3d;
    color: #ffffff;
    border: 1px solid #555555;
    border-radius: 5px;
    padding: 8px 16px;
    text-align: left;
}

QPushButton:hover, PushButton:hover {
    background-color: #4a4a4a;
    border: 1px solid #666666;
}

QPushButton:pressed, PushButton:pressed {
    background-color: #2d2d2d;
}

QPushButton:disabled, PushButton:disabled {
    background-color: #2a2a2a;
    color: #666666;
    border: 1px solid #3a3a3a;
}

QTextEdit {
    background-color: #2b2b2b;
    color: #ffffff;
    border: none;
    selection-background-color: #3daee9;
}

QComboBox {
    background-color: #3d3d3d;
    color: #ffffff;
    border: 1px solid #555555;
    border-radius: 5px;
    padding: 5px 10px;
}

QComboBox:hover {
    border: 1px solid #666666;
}

QComboBox::drop-down {
    border: none;
}

QComboBox QAbstractItemView {
    background-color: #3d3d3d;
    color: #ffffff;
    selection-background-color: #3daee9;
}

QSlider::groove:horizontal {
    border: 1px solid #555555;
    height: 8px;
    background: #3d3d3d;
    border-radius: 4px;
}

QSlider::handle:horizontal {
    background: #3daee9;
    border: 1px solid #3daee9;
    width: 18px;
    margin: -5px 0;
    border-radius: 9px;
}

QSlider::handle:horizontal:hover {
    background: #4fc3f7;
}

QScrollBar:vertical {
    background-color: #2b2b2b;
    width: 12px;
    border-radius: 6px;
}

QScrollBar::handle:vertical {
    background-color: #555555;
    border-radius: 6px;
    min-height: 20px;
}

QScrollBar::handle:vertical:hover {
    background-color: #666666;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QDialog {
    background-color: #202020;
    color: #ffffff;
}
"""


# -----------------------------------------------------------------------------
# Cross-Platform Audio Player
# -----------------------------------------------------------------------------

class AudioPlayer:
    """
    Cross-platform audio player using sounddevice.
    Replaces simpleaudio for better Linux compatibility.
    """

    def __init__(self):
        self.audio_data: Optional[np.ndarray] = None
        self.sample_rate: int = 44100
        self.channels: int = 2
        self.current_frame: int = 0
        self.is_playing: bool = False
        self.is_paused: bool = False
        self._playback_start_frame: int = 0
        self._stream_start_time: float = 0

    def load(self, file_path: str) -> bool:
        """
        Load audio file using pydub (handles format conversion via ffmpeg).

        Args:
            file_path: Path to audio file (WAV, MP3, etc.)

        Returns:
            True if loaded successfully, False otherwise
        """
        try:
            audio = AudioSegment.from_file(file_path)

            # Convert to numpy array
            samples = np.array(audio.get_array_of_samples())

            # Reshape for stereo
            if audio.channels == 2:
                samples = samples.reshape((-1, 2))
            elif audio.channels == 1:
                # Convert mono to stereo for consistent handling
                samples = np.column_stack([samples, samples])

            # Normalize to float32 range [-1.0, 1.0] for sounddevice
            max_val = 2 ** (audio.sample_width * 8 - 1)
            self.audio_data = samples.astype(np.float32) / max_val
            self.sample_rate = audio.frame_rate
            self.channels = 2  # Always stereo after conversion
            self.current_frame = 0
            self.is_playing = False
            self.is_paused = False

            return True

        except Exception as e:
            print(f"Error loading audio: {e}")
            return False

    def play(self):
        """Start or resume audio playback."""
        if self.audio_data is None:
            return

        if self.is_paused:
            # Resume from saved position
            data_to_play = self.audio_data[self.current_frame:]
        else:
            # Start from beginning
            data_to_play = self.audio_data
            self.current_frame = 0

        if len(data_to_play) == 0:
            return

        self._playback_start_frame = self.current_frame
        self.is_playing = True
        self.is_paused = False

        # Use sounddevice for cross-platform playback
        sd.play(data_to_play, self.sample_rate)

    def pause(self):
        """Pause audio playback, saving current position."""
        if self.is_playing and not self.is_paused:
            sd.stop()

            # Estimate current position based on elapsed time
            # This is approximate but works well enough for this use case
            try:
                stream = sd.get_stream()
                if stream is not None:
                    elapsed_frames = int(stream.time * self.sample_rate)
                    self.current_frame = self._playback_start_frame + elapsed_frames
                    # Clamp to valid range
                    if self.audio_data is not None:
                        self.current_frame = min(self.current_frame, len(self.audio_data))
            except Exception:
                pass  # If we can't get stream time, just stop at current position

            self.is_playing = False
            self.is_paused = True

    def stop(self):
        """Stop audio playback and reset position."""
        sd.stop()
        self.is_playing = False
        self.is_paused = False
        self.current_frame = 0

    @property
    def is_loaded(self) -> bool:
        """Check if audio is loaded."""
        return self.audio_data is not None


# -----------------------------------------------------------------------------
# Audio Recorder (Non-blocking, callback-based)
# -----------------------------------------------------------------------------

class AudioRecorder:
    """
    Non-blocking audio recorder using sounddevice InputStream.
    Avoids threading deadlocks by using callback-based recording.
    """

    def __init__(self, fs: int = 44100, channels: int = 2):
        self.fs = fs
        self.channels = channels
        self.max_duration = 900  # 15 minutes max
        self.recorded_frames: list = []
        self.stream: Optional[sd.InputStream] = None
        self.is_recording = False

    def _audio_callback(self, indata, frames, time_info, status):
        """Callback function called for each audio block."""
        if status:
            print(f"Recording status: {status}")
        # Append a copy of the incoming data
        self.recorded_frames.append(indata.copy())

    def start(self):
        """Start recording audio."""
        self.recorded_frames = []
        self.is_recording = True

        try:
            # Use float32 for better cross-platform compatibility
            # Some Linux audio backends don't support float64
            self.stream = sd.InputStream(
                samplerate=self.fs,
                channels=self.channels,
                dtype='float32',
                callback=self._audio_callback
            )
            self.stream.start()
            return True
        except Exception as e:
            print(f"Failed to start recording: {e}")
            self.is_recording = False
            return False

    def stop(self) -> Optional[np.ndarray]:
        """Stop recording and return the recorded audio data."""
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None

        self.is_recording = False

        if self.recorded_frames:
            # Concatenate all recorded frames
            recording = np.concatenate(self.recorded_frames, axis=0)
            self.recorded_frames = []
            return recording

        return None

    def get_duration(self) -> float:
        """Get current recording duration in seconds."""
        if not self.recorded_frames:
            return 0.0
        total_frames = sum(len(frame) for frame in self.recorded_frames)
        return total_frames / self.fs


# -----------------------------------------------------------------------------
# Recording Dialog
# -----------------------------------------------------------------------------

class RecordingDialog(QDialog):
    """Dialog for recording audio with start/stop/save controls."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Record Audio")
        self.setGeometry(200, 200, 350, 280)
        self.setup_ui()
        self.setup_recording()

    def setup_ui(self):
        """Initialize UI components."""
        self.layout = QVBoxLayout(self)

        # Info label
        self.time_label = QLabel(
            "Maximum recording time: 15 minutes.\n"
            "You will be warned at 14 minutes."
        )
        self.time_label.setWordWrap(True)
        self.layout.addWidget(self.time_label)

        # Duration label
        self.duration_label = QLabel("Duration: 00:00")
        self.duration_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.layout.addWidget(self.duration_label)

        # Status label
        self.status_label = QLabel("Status: Ready")
        self.status_label.setStyleSheet("color: #888888;")
        self.layout.addWidget(self.status_label)

        # Buttons - using standard QPushButton for consistent styling
        self.start_button = QPushButton("▶ Start Recording")
        self.stop_button = QPushButton("⏹ Stop Recording")
        self.stop_button.setEnabled(False)
        self.save_button = QPushButton("💾 Save Recording")
        self.save_button.setEnabled(False)

        self.layout.addWidget(self.start_button)
        self.layout.addWidget(self.stop_button)
        self.layout.addWidget(self.save_button)

        # Connect buttons
        self.start_button.clicked.connect(self.start_recording)
        self.stop_button.clicked.connect(self.stop_recording)
        self.save_button.clicked.connect(self.save_recording)

    def setup_recording(self):
        """Initialize recorder and timers."""
        self.recorder = AudioRecorder()
        self.recording_data: Optional[np.ndarray] = None

        # Timer to update duration display
        self.duration_timer = QTimer()
        self.duration_timer.timeout.connect(self.update_duration)

        # Timer for 14-minute warning
        self.warning_timer = QTimer()
        self.warning_timer.setSingleShot(True)
        self.warning_timer.timeout.connect(self.show_warning)

        # Timer for 15-minute auto-stop
        self.max_time_timer = QTimer()
        self.max_time_timer.setSingleShot(True)
        self.max_time_timer.timeout.connect(self.auto_stop_recording)

    def start_recording(self):
        """Start audio recording."""
        if self.recorder.start():
            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(True)
            self.save_button.setEnabled(False)
            self.status_label.setText("Status: Recording...")
            self.status_label.setStyleSheet("color: #e74c3c;")

            # Start timers
            self.duration_timer.start(100)  # Update every 100ms
            self.warning_timer.start(840 * 1000)  # 14 minutes
            self.max_time_timer.start(900 * 1000)  # 15 minutes
        else:
            self.status_label.setText("Status: Failed to start recording")
            self.status_label.setStyleSheet("color: #e74c3c;")

    def stop_recording(self):
        """Stop audio recording."""
        # Stop all timers
        self.duration_timer.stop()
        self.warning_timer.stop()
        self.max_time_timer.stop()

        # Stop recording and get data
        self.recording_data = self.recorder.stop()

        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)

        if self.recording_data is not None and len(self.recording_data) > 0:
            self.save_button.setEnabled(True)
            self.status_label.setText("Status: Recording complete")
            self.status_label.setStyleSheet("color: #27ae60;")
        else:
            self.status_label.setText("Status: No audio recorded")
            self.status_label.setStyleSheet("color: #f39c12;")

    def auto_stop_recording(self):
        """Auto-stop when max time reached."""
        self.status_label.setText("Status: Maximum time reached!")
        self.stop_recording()

    def update_duration(self):
        """Update the duration display."""
        duration = self.recorder.get_duration()
        minutes = int(duration // 60)
        seconds = int(duration % 60)
        self.duration_label.setText(f"Duration: {minutes:02d}:{seconds:02d}")

    def show_warning(self):
        """Show warning when approaching time limit."""
        if self.recorder.is_recording:
            self.status_label.setText("Status: Recording... (1 minute remaining!)")
            self.status_label.setStyleSheet("color: #e67e22;")

    def save_recording(self):
        """Save recorded audio to WAV file."""
        if self.recording_data is None:
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Recording", "", "WAV Files (*.wav)"
        )

        if file_path:
            # Ensure .wav extension
            if not file_path.lower().endswith('.wav'):
                file_path += '.wav'

            # Normalize and convert to int16
            max_val = np.max(np.abs(self.recording_data))
            if max_val > 0:
                scaled = np.int16(self.recording_data / max_val * 32767)
            else:
                scaled = np.int16(self.recording_data)

            wav_write(file_path, self.recorder.fs, scaled)
            self.status_label.setText(f"Status: Saved!")
            self.status_label.setStyleSheet("color: #27ae60;")


# -----------------------------------------------------------------------------
# Song Display Interface
# -----------------------------------------------------------------------------

class SongInterface(QWidget):
    """Interface for displaying song text with auto-scrolling."""

    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.setup_scroll_timer()

    def setup_ui(self):
        """Initialize UI components."""
        # Frame for styling
        frame = QFrame(self)
        frame_layout = QVBoxLayout(frame)
        frame_layout.setContentsMargins(10, 10, 10, 10)
        frame.setFrameShape(QFrame.Shape.StyledPanel)
        frame.setStyleSheet("background-color: #2b2b2b; border-radius: 8px;")

        # Text display
        self.text_edit = QTextEdit(frame)
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(QFont("Courier", 14))
        self.text_edit.setStyleSheet("""
            QTextEdit {
                color: #ffffff;
                background-color: #2b2b2b;
                border: none;
            }
        """)
        frame_layout.addWidget(self.text_edit)

        # Main layout
        layout = QVBoxLayout(self)
        layout.addWidget(frame)
        self.setLayout(layout)

    def setup_scroll_timer(self):
        """Initialize auto-scroll timer."""
        self.scroll_timer = QTimer()
        self.scroll_timer.timeout.connect(self.auto_scroll)
        self.scroll_speed = 5

    def load_text(self, text: str):
        """Load text content into display."""
        self.text_edit.setPlainText(text)

    def auto_scroll(self):
        """Perform one scroll step."""
        scrollbar = self.text_edit.verticalScrollBar()
        scrollbar.setValue(scrollbar.value() + 1)

    def toggle_scroll(self, enable: bool):
        """Enable or disable auto-scrolling."""
        if enable:
            interval = max(10, 200 // self.scroll_speed)
            self.scroll_timer.start(interval)
        else:
            self.scroll_timer.stop()

    def set_scroll_speed(self, speed: int):
        """Update scroll speed."""
        self.scroll_speed = max(1, speed)
        if self.scroll_timer.isActive():
            interval = max(10, 200 // self.scroll_speed)
            self.scroll_timer.start(interval)


# -----------------------------------------------------------------------------
# Control Interface
# -----------------------------------------------------------------------------

class ControlInterface(QWidget):
    """Interface for file controls, playback, and settings."""

    def __init__(self, song_interface: SongInterface):
        super().__init__()
        self.song_interface = song_interface
        self.audio_player = AudioPlayer()
        self.playback_timer = QTimer()
        self.playback_timer.timeout.connect(self.update_playback_status)

        self.setup_ui()

    def create_button(self, icon_text: str, label: str) -> QPushButton:
        """Create a styled button with icon and label."""
        btn = QPushButton(f"{icon_text}  {label}")
        btn.setMinimumHeight(36)
        return btn

    def setup_ui(self):
        """Initialize UI components."""
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # Logo/image
        self.image_label = QLabel(self)
        self.load_logo()
        layout.addWidget(self.image_label)

        # Recording button
        self.record_audio_button = self.create_button("🎤", "Record Audio")
        self.record_audio_button.clicked.connect(self.open_recording_dialog)
        layout.addWidget(self.record_audio_button)

        # File controls
        self.open_file_button = self.create_button("📄", "Open Text File")
        self.open_file_button.clicked.connect(self.open_file)
        layout.addWidget(self.open_file_button)

        self.load_audio_button = self.create_button("🎵", "Load Audio")
        self.load_audio_button.clicked.connect(self.load_audio)
        layout.addWidget(self.load_audio_button)

        # Playback controls
        self.play_button = self.create_button("▶", "Play")
        self.play_button.setEnabled(False)
        self.play_button.clicked.connect(self.play_audio)
        layout.addWidget(self.play_button)

        self.pause_button = self.create_button("⏸", "Pause")
        self.pause_button.setEnabled(False)
        self.pause_button.clicked.connect(self.pause_audio)
        layout.addWidget(self.pause_button)

        self.stop_button = self.create_button("⏹", "Stop")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_audio)
        layout.addWidget(self.stop_button)

        # Spacers
        layout.addSpacerItem(QSpacerItem(
            20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed
        ))
        layout.addSpacerItem(QSpacerItem(
            20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding
        ))

        # Bottom controls frame
        control_frame = QFrame()
        control_layout = QVBoxLayout(control_frame)
        control_layout.setContentsMargins(0, 0, 0, 0)

        # Font size selector
        font_label = QLabel("Font Size:")
        control_layout.addWidget(font_label)

        self.font_size_selector = ComboBox()
        self.font_size_selector.addItems([str(i) for i in range(8, 25)])
        self.font_size_selector.setCurrentText("14")
        self.font_size_selector.currentTextChanged.connect(self.set_font_size)
        control_layout.addWidget(self.font_size_selector)

        # Scroll speed slider
        speed_label = QLabel("Scroll Speed:")
        control_layout.addWidget(speed_label)

        self.scroll_speed_slider = Slider(Qt.Orientation.Horizontal)
        self.scroll_speed_slider.setRange(1, 20)
        self.scroll_speed_slider.setValue(5)
        self.scroll_speed_slider.valueChanged.connect(
            self.song_interface.set_scroll_speed
        )
        control_layout.addWidget(self.scroll_speed_slider)

        # Scroll toggle button
        self.play_pause_scroll_button = self.create_button("▶", "Play Scroll")
        self.play_pause_scroll_button.clicked.connect(self.toggle_scroll)
        control_layout.addWidget(self.play_pause_scroll_button)

        layout.addWidget(control_frame)

    def load_logo(self):
        """Load application logo image."""
        try:
            if resource is not None:
                # Get the path without using deprecated context manager
                image_path = pkg_resources.files(resource).joinpath("guitar.png")
                pixmap = QPixmap(str(image_path))
                self.image_label.setPixmap(
                    pixmap.scaled(
                        50, 50,
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation
                    )
                )
        except Exception as e:
            print(f"Could not load logo: {e}")
            self.image_label.setText("🎸")
            self.image_label.setFont(QFont("Arial", 32))

    def set_font_size(self, size: str):
        """Update font size in song interface."""
        font = QFont("Courier", int(size))
        self.song_interface.text_edit.setFont(font)

    def open_recording_dialog(self):
        """Open the recording dialog."""
        dialog = RecordingDialog(self)
        dialog.exec()

    def open_file(self):
        """Open and load a text file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Song File", "", "Text Files (*.txt);;All Files (*)"
        )
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    self.song_interface.load_text(f.read())
            except UnicodeDecodeError:
                # Fallback for files with different encoding
                with open(file_path, "r", encoding="latin-1") as f:
                    self.song_interface.load_text(f.read())

    def load_audio(self):
        """Load an audio file for playback."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Audio File", "",
            "Audio Files (*.wav *.mp3 *.ogg *.flac);;WAV Files (*.wav);;All Files (*)"
        )
        if file_path:
            if self.audio_player.load(file_path):
                self.play_button.setEnabled(True)
                self.pause_button.setEnabled(True)
                self.stop_button.setEnabled(True)

    def play_audio(self):
        """Start or resume audio playback."""
        self.audio_player.play()
        self.playback_timer.start(100)

    def pause_audio(self):
        """Pause audio playback."""
        self.audio_player.pause()
        self.playback_timer.stop()

    def stop_audio(self):
        """Stop audio playback."""
        self.audio_player.stop()
        self.playback_timer.stop()

    def update_playback_status(self):
        """Update playback status (for future use with progress display)."""
        pass

    def toggle_scroll(self):
        """Toggle auto-scrolling."""
        is_scrolling = not self.song_interface.scroll_timer.isActive()
        self.song_interface.toggle_scroll(is_scrolling)
        icon = "⏸" if is_scrolling else "▶"
        text = "Pause Scroll" if is_scrolling else "Play Scroll"
        self.play_pause_scroll_button.setText(f"{icon}  {text}")


# -----------------------------------------------------------------------------
# Main Window
# -----------------------------------------------------------------------------

class MainFluentWindow(QMainWindow):
    """Main application window with Fluent design."""

    def __init__(self):
        super().__init__()
        setTheme(Theme.DARK)
        self.setup_ui()

    def setup_ui(self):
        """Initialize main window UI."""
        self.setWindowTitle("Couch Guitar")

        # Create interfaces
        self.song_interface = SongInterface()
        self.control_interface = ControlInterface(self.song_interface)

        # Central widget with layout
        central_widget = QWidget()
        main_layout = QVBoxLayout(central_widget)
        self.setCentralWidget(central_widget)

        # Splitter for resizable panels
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self.control_interface)
        splitter.addWidget(self.song_interface)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)

        main_layout.addWidget(splitter)

    def resizeEvent(self, event):
        """Handle window resize - hide/show elements based on size."""
        super().resizeEvent(event)

        threshold_height = 400
        if self.height() < threshold_height:
            self.control_interface.image_label.hide()
        else:
            self.control_interface.image_label.show()


# -----------------------------------------------------------------------------
# Entry Point
# -----------------------------------------------------------------------------

def check_dependencies():
    """Check and report on platform-specific dependencies."""
    system = platform.system()
    print(f"Running on: {system}")

    # Check sounddevice
    try:
        devices = sd.query_devices()
        print(f"Audio devices available: {len(devices)}")
    except Exception as e:
        print(f"Warning: Audio device query failed: {e}")
        if system == "Linux":
            print("Hint: Install PortAudio with: sudo apt-get install portaudio19-dev")


def main():
    """Application entry point."""
    check_dependencies()

    app = QApplication(sys.argv)

    # Apply dark stylesheet for cross-platform consistency
    app.setStyleSheet(DARK_STYLESHEET)

    window = MainFluentWindow()

    # Get screen dimensions and size window appropriately
    screen = QApplication.primaryScreen()
    if screen:
        geometry = screen.geometry()
        width = int(geometry.width() * 0.9)
        height = int(geometry.height() * 0.8)
        window.resize(width, height)

        # Center window
        x = (geometry.width() - width) // 2
        y = (geometry.height() - height) // 2
        window.move(x, max(0, y - 20))

    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()