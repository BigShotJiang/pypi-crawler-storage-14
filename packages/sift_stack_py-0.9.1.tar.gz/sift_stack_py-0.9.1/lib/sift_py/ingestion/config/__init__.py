"""
Contains the in memory representation of a telemetry config used to configure ingestion.
"""
