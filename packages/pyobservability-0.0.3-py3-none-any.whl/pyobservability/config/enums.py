from enum import StrEnum


class APIEndpoints(StrEnum):
    root = "/"
    ws = "/ws"
