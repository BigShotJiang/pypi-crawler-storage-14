"""
Placeholder for future kk0 event models.
"""

__all__ = []
