from conan.internal.model.conan_file import ConanFile
from conan.internal.model.workspace import Workspace
from conan.internal.model.version import Version

__version__ = '2.23.0'
conan_version = Version(__version__)
