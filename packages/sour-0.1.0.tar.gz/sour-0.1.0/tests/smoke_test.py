import sour
import sys

print(f"Successfully imported sour version: {sour.__version__}")
sys.exit(0)
