Authors
=======

Xiaohao Yang

Billinge Group members

Contributors
------------

For a list of contributors, visit
https://github.com/diffpy/diffpy.srxplanargui/graphs/contributors
