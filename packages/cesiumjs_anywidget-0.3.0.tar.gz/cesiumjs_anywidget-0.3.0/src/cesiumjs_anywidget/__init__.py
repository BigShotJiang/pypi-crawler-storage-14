"""CesiumJS Anywidget - A Jupyter widget for CesiumJS 3D globe visualization."""

from .widget import CesiumWidget

__version__ = "0.1.0"
__all__ = ["CesiumWidget"]
