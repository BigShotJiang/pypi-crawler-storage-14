# Changelog

## [0.1.0] - YYYY-MM-DD
- Initial package release.
- User registration/login, JWT, MFA, password security.
