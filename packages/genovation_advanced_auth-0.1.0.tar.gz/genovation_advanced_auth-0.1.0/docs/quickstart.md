# Quick Start Guide

## Installation

pip install genovation-advanced-auth


## Basic Setup

1. Create FastAPI app
2. Include auth routers
3. Configure settings
4. Run and test

See [examples/basic_usage.py](../examples/basic_usage.py) for complete example.

## Next Steps

- [Configuration](./configuration.md)
- [API Reference](./api-reference.md)

