# Configuration

## Environment Variables

SECRET_KEY=your-secret-key
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
MFA_ISSUER_NAME=YourApp


## AuthConfig Class

from genovation_advanced_auth import AuthConfig

config = AuthConfig(
secret_key="...",
algorithm="HS256",
access_token_expire_minutes=30
)

undefined