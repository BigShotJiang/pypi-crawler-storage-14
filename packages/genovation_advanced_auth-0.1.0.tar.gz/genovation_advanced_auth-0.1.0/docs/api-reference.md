# API Reference

## Authentication Endpoints

### POST /auth/register
Register a new user.

**Request Body:**

{
"username": "string",
"email": "string",
"password": "string"
}


### POST /auth/login
Login and receive JWT token.

**Request Body:**

{
"username": "string",
"password": "string"
}


**Response:**

{
"access_token": "string",
"token_type": "bearer"
}


## MFA Endpoints

### POST /auth/mfa/setup
Setup MFA for current user. Returns QR code and secret.

### POST /auth/mfa/verify
Verify MFA code and enable MFA.

## User Endpoints

### GET /users/me
Get current user profile (requires authentication).

### POST /users/change-password
Change user password (requires authentication).
