from fastapi import FastAPI, Depends
from genovation_advanced_auth import AuthRouter, UsersRouter, get_current_user

app = FastAPI(title="Auth Example")

# Include auth routes
app.include_router(AuthRouter, prefix="/api/v1/auth", tags=["auth"])
app.include_router(UsersRouter, prefix="/api/v1/users", tags=["users"])

@app.get("/")
def root():
    return {"message": "Welcome to Genovation Auth Example"}

@app.get("/protected")
def protected_endpoint(current_user = Depends(get_current_user)):
    return {
        "message": f"Hello {current_user['username']}!",
        "user": current_user
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
