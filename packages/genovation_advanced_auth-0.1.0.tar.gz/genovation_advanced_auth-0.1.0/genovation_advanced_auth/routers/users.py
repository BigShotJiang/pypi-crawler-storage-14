from fastapi import APIRouter, Depends, HTTPException, status

from genovation_advanced_auth.dependencies.auth import get_current_user
from genovation_advanced_auth.schemas.user import UserResponse
from genovation_advanced_auth.schemas.common import SuccessResponse

router = APIRouter()


@router.get("/me", response_model=UserResponse)
def get_current_user_profile(
    current_user: dict = Depends(get_current_user)
):
    """
    Get current user profile from token.
    
    Returns basic user information decoded from JWT token.
    For full profile with database lookup, integrate with your app's get_db.
    """
    # Return user data from token (no database needed)
    from datetime import datetime
    
    return UserResponse(
        id=current_user["id"],
        username=current_user.get("username", "user"),
        email=f"user{current_user['id']}@example.com",  # Placeholder
        is_active=True,
        is_superuser=current_user.get("is_superuser", False),
        mfa_enabled=False,
        created_at=datetime.utcnow(),
        last_login=None
    )


@router.get("/health")
def health_check():
    """Health check endpoint."""
    return SuccessResponse(
        success=True,
        message="Users router is healthy"
    )
