from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class AuthConfig(BaseSettings):
    """Authentication configuration for the library."""
    
    # Security
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    
    # MFA
    mfa_issuer_name: str = "MyApp"
    mfa_backup_codes_count: int = 10
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        env_prefix="AUTH_",  # All env vars start with AUTH_
        extra="ignore"
    )

# Global config instance
_config: Optional[AuthConfig] = None

def get_config() -> AuthConfig:
    """
    Get global config instance (lazy initialization from .env).
    Falls back to environment variables if .env doesn't exist.
    """
    global _config
    if _config is None:
        _config = AuthConfig()
    return _config

def set_config(config: AuthConfig) -> None:
    """
    Set global config instance (for explicit configuration).
    Use this to override .env settings programmatically.
    """
    global _config
    _config = config
