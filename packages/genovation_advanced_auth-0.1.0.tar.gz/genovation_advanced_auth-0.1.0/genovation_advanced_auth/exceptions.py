from fastapi import HTTPException, status


class BaseAppException(Exception):
    """Base exception for application errors."""
    
    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


# Authentication Exceptions
class AuthenticationError(BaseAppException):
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, status.HTTP_401_UNAUTHORIZED)


class InvalidCredentialsError(AuthenticationError):
    def __init__(self):
        super().__init__("Invalid username or password")


class InvalidMFACodeError(AuthenticationError):
    def __init__(self):
        super().__init__("Invalid MFA code")


class MFANotSetupError(BaseAppException):
    def __init__(self):
        super().__init__("MFA is not setup for this user", status.HTTP_400_BAD_REQUEST)


class TokenExpiredError(AuthenticationError):
    def __init__(self):
        super().__init__("Token has expired")


class InvalidTokenError(AuthenticationError):
    def __init__(self):
        super().__init__("Invalid token")


# User Exceptions
class UserNotFoundError(BaseAppException):
    def __init__(self):
        super().__init__("User not found", status.HTTP_404_NOT_FOUND)


class UserAlreadyExistsError(BaseAppException):
    def __init__(self):
        super().__init__("User already exists", status.HTTP_409_CONFLICT)


# Model Exceptions
class ModelNotFoundError(BaseAppException):
    def __init__(self, model_id: str):
        super().__init__(f"Model {model_id} not found", status.HTTP_404_NOT_FOUND)


class ModelAlreadyExistsError(BaseAppException):
    def __init__(self, model_name: str):
        super().__init__(f"Model {model_name} already exists", status.HTTP_409_CONFLICT)


class ModelLoadError(BaseAppException):
    def __init__(self, model_id: str, reason: str):
        super().__init__(
            f"Failed to load model {model_id}: {reason}",
            status.HTTP_500_INTERNAL_SERVER_ERROR
        )


class ModelHandlerNotFoundError(BaseAppException):
    def __init__(self, handler_type: str):
        super().__init__(
            f"No handler found for type: {handler_type}",
            status.HTTP_400_BAD_REQUEST
        )


# Storage Exceptions
class StorageError(BaseAppException):
    def __init__(self, message: str):
        super().__init__(f"Storage error: {message}", status.HTTP_500_INTERNAL_SERVER_ERROR)


class FileTooLargeError(BaseAppException):
    def __init__(self, max_size: int):
        super().__init__(
            f"File size exceeds maximum allowed size of {max_size} bytes",
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE
        )


# Deployment Exceptions
class DeploymentError(BaseAppException):
    def __init__(self, message: str):
        super().__init__(f"Deployment error: {message}", status.HTTP_500_INTERNAL_SERVER_ERROR)


# Validation Exceptions
class ValidationError(BaseAppException):
    def __init__(self, message: str):
        super().__init__(f"Validation error: {message}", status.HTTP_422_UNPROCESSABLE_ENTITY)
