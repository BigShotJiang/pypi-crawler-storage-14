"""
Genovation Advanced Auth Library
"""

__version__ = "0.1.0"

# Expose routers for easy app integration
from .routers.auth import router as AuthRouter
from .routers.users import router as UsersRouter

# Export core APIs for user convenience
from .dependencies.auth import get_current_user
from .schemas.user import UserCreate, UserResponse, PasswordChange
from .schemas.common import SuccessResponse, ErrorResponse

__all__ = [
    "AuthRouter",
    "UsersRouter",
    "get_current_user",
    "UserCreate",
    "UserResponse",
    "PasswordChange",
    "SuccessResponse",
    "ErrorResponse",
]
