---
name: SpecPulse: Feature Init
description: Initialize new feature without SpecPulse CLI
category: SpecPulse
tags: [specpulse, feature, init]
---

# SpecPulse Feature Initialization

Initialize new features and create complete project structure without requiring SpecPulse CLI installation.

<!-- SPECPULSE:START -->
**Guardrails**
- CLI-first approach: Always try SpecPulse CLI commands before file operations
- Keep changes tightly scoped to feature initialization
- Only edit .specpulse/ directory structure
- Favor straightforward, minimal implementations first

**Steps**
Track these steps as TODOs and complete them one by one.
1. Parse arguments and extract feature name
2. Validate feature name format (alphanumeric with hyphens)
3. Generate feature ID using Universal ID System
4. Create feature directory structure: .specpulse/specs/[feature-id]-[feature-name]/
5. Initialize subdirectories: plans/, tasks/, memory/
6. Create feature context in memory/context.md
7. Copy feature templates from templates/ if available
8. Set up git branch: feature/[feature-id]-[feature-name]
9. Update feature summary and provide next steps

**Reference**
- Use Universal ID System for conflict-free numbering
- Follow template structure for consistency
- Check .specpulse/memory/context.md for active feature management

**Usage**
Arguments should be provided as: `<feature-name> [--force]`

**CLI-Independent Benefits:**
- Works completely without SpecPulse CLI installation
- Uses LLM-safe file operations for reliable initialization
- Complete project structure setup with templates
- Git integration for version control

**Output Structure:**
```
.specpulse/specs/[feature-id]-[feature-name]/
├── spec-001.md                 # Initial specification template
├── plans/
│   └── plan-001.md            # Implementation plan template
├── tasks/
│   └── tasks-001.md           # Task breakdown template
└── memory/
    ├── context.md             # Feature working context
    └── decisions.md           # Decision tracking
```
<!-- SPECPULSE:END -->