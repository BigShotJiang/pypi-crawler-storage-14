##Upload stdio MCP to PyPI##

- uv init . --package -p 3.13
- uv add "mcp[cli]"
- uv build
- uv publish --token {APIKey}



## MCP Configuration for Cherry Studio ##
```json
{
  "mcpServers": {
    "fYp3yK95P0s2MAcpRuXEI": {
      "name": "MCP Server Stdio PyPi",
      "description": "",
      "baseUrl": "",
      "command": "uvx",
      "args": [
        "askandyz-mcp-server-demo"
      ],
      "env": {},
      "isActive": true,
      "type": "stdio",
      "registryUrl": ""
    },
    "9jzTuaGxtb9d6CuPBL_lj": {
      "name": "MCP Server SSE",
      "description": "",
      "baseUrl": "http://127.0.0.1:8000/sse",
      "command": "",
      "args": [],
      "env": {},
      "isActive": false,
      "type": "sse"
    },
    "-a4zp-fOr5Juj3lYoa-fP": {
      "isActive": false,
      "name": "MCP Server StreamableHttp",
      "type": "streamableHttp",
      "description": "",
      "baseUrl": "http://127.0.0.1:8000/mcp",
      "command": "",
      "args": [],
      "env": {},
      "installSource": "unknown"
    },
    "oG9xnqZyTYsTNtPcCzH_3": {
      "isActive": false,
      "name": "MCP Server Stdio",
      "type": "stdio",
      "description": "",
      "baseUrl": "",
      "command": "uv",
      "registryUrl": "",
      "args": [
        "--directory",
        "E:\\Workspaces\\AI\\MCP\\mcp-server-demo",
        "run",
        "stdio.py"
      ],
      "env": {},
      "installSource": "unknown"
    }
  }
}
```