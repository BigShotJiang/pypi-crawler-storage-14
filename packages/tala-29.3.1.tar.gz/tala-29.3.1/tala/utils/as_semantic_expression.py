class AsSemanticExpressionMixin(object):
    def as_semantic_expression(self):
        return str(self)
