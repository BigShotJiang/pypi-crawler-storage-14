
# HybridOpt
`HybridOpt` は Python で多様な最適化アルゴリズムを組み合わせて、連続・離散変数の混合、制約付き最適化、スケジュール探索の自動比較を行えるハイブリッド最適化ライブラリです。


## 特徴
- LHS（Latin Hypercube Sampling）、Bayesian Optimization、局所探索、Differential Evolution、GA、PSO に対応
- 連続・整数変数の混合に対応
- 制約付き目的関数の探索が可能
- 複数スケジュールの再現性評価、時間制限評価が可能
- CSV に履歴を追記しながら探索可能


## インストール
```bash
pip install hybridopt pyDOE scikit-optimize scipy
```

※ PSO を利用する場合は pyswarms を別途インストールしてください。
```bash
pip install pyswarms
```


## 使用例
### 目的関数例（多峰性）
```python
import numpy as np
from hybridopt.optimizer import HybridOptimizer

def my_func(x, y):
    """多峰性関数: 最大値は (0.1, 4.0)"""
    return np.sin(5*x) * (1-np.tanh(y**2)) + 2*np.exp(-((x-0.1)**2 + (y-4.0)**2))
```

### 変数定義

```python
variables = [
    {"label": "x", "bounds": (0, 1), "type": float},
    {"label": "y", "bounds": (0, 5), "type": float}
]
```

### 1. 通常の最適化
```python
optimizer = HybridOptimizer(variables, target_label="obj", maximize=True)

X_all, Y_all, best_x, best_y = optimizer.run_schedule(
    func=my_func,
    csv_filename="history_normal.csv",
    schedule=[("lhs", 10), ("bo", 15), ("local", 20)]
)
print("Best x:", best_x)
print("Best y:", best_y)
```
#### 出力例
```yaml
Best x: [0.092, 4.0]
Best y: 2.625
```
![探索アニメーション](docs/imgs/opt.gif)

### 2. 制約付き最適化
```python
constraint_func = lambda y: y > 0
optimizer_constrained = HybridOptimizer(
    variables,
    target_label="obj",
    maximize=True,
    constraint=constraint_func
)

X_all, Y_all, best_x, best_y = optimizer_constrained.run_schedule(
    func=my_func,
    csv_filename="history_constrained.csv",
    schedule=[("lhs", 10), ("bo", 10), ("local", 20)]
)
print("Best x:", best_x)
print("Best y:", best_y)
```
#### 出力例
```yaml
Best x: [0.092, 4.0]
Best y: 2.625
```

### 3. 複数スケジュールの検証
```python
schedules = [
    [("lhs", 10), ("de", 20), ("local", 20)],
    [("lhs", 15), ("ga", 25), ("local", 15)],
    [("lhs", 20), ("bo", 10), ("local", 20)]
]

best_result = optimizer.run_multiple_schedules(
    func=my_func,
    csv_prefix="history_schedule",
    schedules=schedules,
    n_runs=3
)
print("Overall best schedule:", best_result["schedule"])
print("Best y:", best_result["best_y"])
print("Best x:", best_result["best_x"])
```
#### 出力例
```yaml
Overall best schedule: [('lhs', 20), ('bo', 10), ('local', 20)]
Best y: 2.625
Best x: [0.092, 4.0]
```

### 4. 時間制限ベースで検証
```python
best_result_time = optimizer.run_multiple_schedules_time_based(
    func=my_func,
    csv_prefix="history_time_schedule",
    schedules=schedules,
    time_limit_per_schedule=5.0,
    n_runs=3
)
print("Overall best schedule:", best_result_time["schedule"])
print("Best y:", best_result_time["best_y"])
print("Best x:", best_result_time["best_x"])
```
#### 出力例
```yaml
Overall best schedule: [('lhs', 20), ('bo', 10), ('local', 20)]
Best y: 2.625
Best x: [0.092, 4.0]
```


## 探索アルゴリズム
| モード   | 説明                                        |
| ----- | ----------------------------------------- |
| lhs   | Latin Hypercube Sampling                  |
| bo    | Bayesian Optimization                     |
| local | 局所探索（L-BFGS-B）                            |
| de    | Differential Evolution                    |
| ga    | Genetic Algorithm                         |
| pso   | Particle Swarm Optimization（pyswarms が必要） |


## 制約の指定
```python
constraint_func = lambda y: y > 0  # 目的関数 y が正の値のみ許可
optimizer = HybridOptimizer(variables, target_label="obj", constraint=constraint_func)
```
制約を満たさない点は探索対象外として扱われます。


## スケジュール探索
複数のアルゴリズムを組み合わせた探索スケジュールを検証可能。
- `run_multiple_schedules` は最良結果を繰り返し評価し、平均値で比較。
- `run_multiple_schedules_time_based` は各スケジュールの実行時間で公平に比較。


## ライセンス
`HybridOpt` は MIT ライセンスの下で提供されています。詳細は LICENSE ファイルを参照してください。

