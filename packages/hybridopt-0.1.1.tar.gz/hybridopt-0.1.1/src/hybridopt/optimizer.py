
import numpy as np
import pandas as pd
import time
from pyDOE import lhs
from skopt import Optimizer
from skopt.space import Real, Integer
from scipy.optimize import minimize, differential_evolution
import os
import traceback

# PSO 用（pyswarms がある場合）
try:
    import pyswarms as ps
    PSO_AVAILABLE = True
except ImportError:
    PSO_AVAILABLE = False
    print("pyswarms not installed: PSO mode will be disabled")


# ==========================
# HybridOptimizer 完全版
# ==========================
class HybridOptimizer:
    def __init__(self, variables, target_label, maximize=True, constraint=None, random_seed=None):
        self.variables = variables
        self.target_label = target_label
        self.maximize = maximize
        self.constraint = constraint
        self.random_seed = random_seed

        self.var_labels = [v["label"] for v in variables]
        self.var_bounds = [v["bounds"] for v in variables]
        self.var_types = [v.get("type", float) for v in variables]
        self.dim = len(variables)

        if self.random_seed is not None:
            np.random.seed(self.random_seed)

    # -------------------
    # ユーティリティ
    # -------------------
    def _get_skopt_dimensions(self):
        dims = []
        for b, t in zip(self.var_bounds, self.var_types):
            dims.append(Integer(b[0], b[1]) if t==int else Real(b[0], b[1]))
        return dims

    def _append_csv(self, filename, x, y):
        if filename is None:
            return  # ファイル指定なしならスキップ
        df = pd.DataFrame([list(x)], columns=self.var_labels)
        df[self.target_label] = float(y)
        write_header = not os.path.exists(filename)
        df.to_csv(filename, mode="a", header=write_header, index=False)

    def _safe_eval(self, func, x):
        try:
            y = func(*x)
            if not self.maximize:
                y = -y
            if self.constraint is not None and not self.constraint(y):
                y = -1e12
        except Exception as e:
            print("Evaluation error:", e)
            traceback.print_exc()
            y = -1e12
        return float(y)

    # -------------------
    # 各モードの探索メソッド
    # -------------------
    def _run_lhs(self, func, steps, csv_filename, X_all, Y_all, best_x, best_y):
        samples = lhs(self.dim, samples=steps)
        for row in samples:
            x = np.array([lo + r*(hi-lo) for r, (lo,hi) in zip(row, self.var_bounds)])
            x = np.array([int(v) if t==int else v for v,t in zip(x,self.var_types)])
            y = self._safe_eval(func, x)
            X_all = np.vstack([X_all, x])
            Y_all = np.append(Y_all, y)
            self._append_csv(csv_filename, x, y)
            if y > best_y:
                best_x, best_y = x, y
        return X_all, Y_all, best_x, best_y

    def _run_bo(self, func, steps, csv_filename, X_all, Y_all, best_x, best_y):
        dims = self._get_skopt_dimensions()
        opt = Optimizer(dimensions=dims, n_initial_points=0, random_state=self.random_seed)
        if len(X_all) > 0:
            opt.tell(X_all.tolist(), Y_all.tolist())
        for _ in range(steps):
            x = np.array(opt.ask())
            x = np.array([int(v) if t==int else v for v,t in zip(x,self.var_types)])
            y = self._safe_eval(func, x)
            if x.tolist() not in opt.Xi:
                opt.tell(x.tolist(), y)
            X_all = np.vstack([X_all, x])
            Y_all = np.append(Y_all, y)
            self._append_csv(csv_filename, x, y)
            if y > best_y:
                best_x, best_y = x, y
        return X_all, Y_all, best_x, best_y

    def _run_local(self, func, steps, csv_filename, X_all, Y_all, best_x, best_y):
        if best_x is None:
            best_x = np.array([(lo+hi)/2 for lo,hi in self.var_bounds])
        def wrapper(x):
            x_proc = np.array([int(v) if t==int else v for v,t in zip(x,self.var_types)])
            y = self._safe_eval(func, x_proc)
            self._append_csv(csv_filename, x_proc, y)
            nonlocal best_x, best_y
            if y > best_y:
                best_x, best_y = x_proc.copy(), y
            return -y
        try:
            minimize(wrapper, best_x, method="L-BFGS-B", bounds=self.var_bounds, options={"maxfun": steps})
        except Exception as e:
            print("Local optimization error:", e)
            traceback.print_exc()
        return X_all, Y_all, best_x, best_y

    def _run_de(self, func, steps, csv_filename, X_all, Y_all, best_x, best_y):
        def wrapper(x):
            x_proc = np.array([int(v) if t==int else v for v,t in zip(x,self.var_types)])
            y = self._safe_eval(func, x_proc)
            self._append_csv(csv_filename, x_proc, y)
            nonlocal best_x, best_y
            if y > best_y:
                best_x, best_y = x_proc.copy(), y
            return -y
        result = differential_evolution(wrapper, self.var_bounds, maxiter=steps)
        best_x = np.array([int(v) if t==int else v for v,t in zip(result.x,self.var_types)])
        best_y = -result.fun
        return X_all, Y_all, best_x, best_y

    def _run_ga(self, func, steps, csv_filename, X_all, Y_all, best_x, best_y):
        pop_size = max(10, steps)
        population = np.array([
            [np.random.uniform(lo,hi) if t==float else np.random.randint(lo,hi+1)
             for (lo,hi), t in zip(self.var_bounds, self.var_types)]
            for _ in range(pop_size)
        ])
        n_generations = steps
        mutation_rate = 0.2
        crossover_rate = 0.7
        for gen in range(n_generations):
            fitness = np.array([self._safe_eval(func, ind) for ind in population])
            for ind, y in zip(population, fitness):
                self._append_csv(csv_filename, ind, y)
                if y > best_y:
                    best_x, best_y = ind.copy(), y
            idx_sorted = np.argsort(-fitness)
            population = population[idx_sorted[:pop_size]]
            # crossover
            for i in range(0, pop_size-1, 2):
                if np.random.rand() < crossover_rate:
                    alpha = np.random.rand()
                    x1, x2 = population[i].copy(), population[i+1].copy()
                    population[i] = alpha*x1 + (1-alpha)*x2
                    population[i+1] = alpha*x2 + (1-alpha)*x1
            # mutation
            for i in range(pop_size):
                if np.random.rand() < mutation_rate:
                    j = np.random.randint(self.dim)
                    lo, hi = self.var_bounds[j]
                    t = self.var_types[j]
                    population[i,j] = np.random.uniform(lo,hi) if t==float else np.random.randint(lo,hi+1)
        return X_all, Y_all, best_x, best_y

    def _run_pso(self, func, steps, csv_filename, X_all, Y_all, best_x, best_y):
        if not PSO_AVAILABLE:
            raise ImportError("pyswarms not installed")
        options = {'c1':0.5,'c2':0.3,'w':0.9}
        bounds = (np.array([b[0] for b in self.var_bounds]), np.array([b[1] for b in self.var_bounds]))
        def pso_obj(x):
            y_arr = np.array([self._safe_eval(func, xi) for xi in x])
            for xi, yi in zip(x, y_arr):
                self._append_csv(csv_filename, xi, yi)
                nonlocal best_x, best_y
                if yi > best_y:
                    best_x, best_y = xi.copy(), yi
            return -y_arr
        optimizer = ps.single.GlobalBestPSO(n_particles=max(10, steps), dimensions=self.dim, options=options, bounds=bounds)
        optimizer.optimize(pso_obj, iters=steps)
        return X_all, Y_all, best_x, best_y

    # -------------------
    # 単一モード呼び出し
    # -------------------
    def run(self, func, mode, steps, csv_filename=None, history_df=None):
        """
        単一アルゴリズムモードを実行する

        Parameters
        ----------
        func : callable
            目的関数。複数変数の場合は func(x1, x2, ...) の形式
        mode : str
            実行モード。"lhs", "bo", "local", "de", "ga", "pso"
        steps : int
            実行ステップ数
        csv_filename : str or None, optional
            結果を追記する CSV ファイル名。None の場合は保存しない
        history_df : pd.DataFrame or None, optional
            過去の探索履歴を含む DataFrame

        Returns
        -------
        X_all : np.ndarray
            評価した全ての入力
        Y_all : np.ndarray
            評価結果
        best_x : np.ndarray
            最良の入力
        best_y : float
            最良の評価値
        """
        X_all = history_df[self.var_labels].values.astype(float) if history_df is not None else np.empty((0,self.dim))
        Y_all = history_df[self.target_label].values.astype(float) if history_df is not None else np.array([])
        best_x = None
        best_y = -1e12
        mode_map = {
            "lhs": self._run_lhs,
            "bo": self._run_bo,
            "local": self._run_local,
            "de": self._run_de,
            "ga": self._run_ga,
            "pso": self._run_pso
        }
        if mode not in mode_map:
            raise ValueError(f"Unknown mode: {mode}")
        return mode_map[mode](func, steps, csv_filename, X_all, Y_all, best_x, best_y)

    # -------------------
    # スケジュール実行
    # -------------------
    def run_schedule(self, func, csv_filename=None, schedule=None, history_df=None):
        """
        複数モードを順番に実行するスケジュール探索

        Parameters
        ----------
        func : callable
            目的関数
        csv_filename : str or None, optional
            結果を追記する CSV ファイル名。None の場合は保存しない
        schedule : list of tuple
            実行スケジュール [(mode1, steps1), (mode2, steps2), ...]
        history_df : pd.DataFrame or None, optional
            過去の探索履歴を含む DataFrame

        Returns
        -------
        X_all : np.ndarray
            評価した全ての入力
        Y_all : np.ndarray
            評価結果
        best_x : np.ndarray
            最良の入力
        best_y : float
            最良の評価値
        """
        X_all, Y_all, best_x, best_y = None, None, None, -1e12
        for mode, steps in schedule:
            print(f"Running mode '{mode}' for {steps} steps...")
            X_all, Y_all, best_x, best_y = self.run(func, mode, steps, csv_filename, history_df)
            history_df = pd.DataFrame(np.column_stack([X_all, Y_all]), columns=self.var_labels + [self.target_label])
        return X_all, Y_all, best_x, best_y

    # -------------------
    # 複数スケジュールの検証（再現性 + 時間基準）
    # -------------------
    def run_multiple_schedules(self, func, csv_prefix=None, schedules=None, n_runs=3, history_df=None):
        """
        複数スケジュールを繰り返し評価して最良スケジュールを決定する

        Parameters
        ----------
        func : callable
            目的関数
        csv_prefix : str or None, optional
            CSV 保存用接頭辞。None の場合は保存しない
        schedules : list of list of tuple
            スケジュールのリスト [[(mode, steps), ...], ...]
        n_runs : int
            各スケジュールの繰り返し回数
        history_df : pd.DataFrame or None, optional
            過去の探索履歴を含む DataFrame

        Returns
        -------
        best_result : dict
            {
                "schedule_idx": int,
                "schedule": list of tuple,
                "X_all": np.ndarray,
                "Y_all": np.ndarray,
                "best_x": np.ndarray,
                "best_y": float,
                "mean_y": float,
                "mean_time": float
            }
        """
        best_y_overall = -1e12
        best_result = None

        for idx, schedule in enumerate(schedules):
            best_y_runs = []
            times = []
            print(f"\n=== Testing schedule {idx}: {schedule} ===")

            for run_id in range(n_runs):
                start = time.time()
                csv_file = f"{csv_prefix}_schedule{idx}_run{run_id}.csv" if csv_prefix else None
                X_all, Y_all, best_x, best_y = self.run_schedule(func, csv_file, schedule, history_df)
                elapsed = time.time() - start

                best_y_runs.append(best_y)
                times.append(elapsed)

            mean_y = np.mean(best_y_runs)
            mean_time = np.mean(times)

            print(f"Schedule {idx} mean best y = {mean_y:.6f}, mean time = {mean_time:.2f}s")

            if mean_y > best_y_overall or (mean_y == best_y_overall and (best_result is None or mean_time < best_result.get("mean_time", 1e12))):
                best_y_overall = mean_y
                best_result = {
                    "schedule_idx": idx,
                    "schedule": schedule,
                    "X_all": X_all,
                    "Y_all": Y_all,
                    "best_x": best_x,
                    "best_y": best_y,
                    "mean_y": mean_y,
                    "mean_time": mean_time
                }

        print(f"\n=== Overall best schedule: {best_result['schedule']} ===")
        print(f"Best y = {best_result['best_y']:.6f} at x = {best_result['best_x']}")
        return best_result
    
    def run_multiple_schedules_time_based(self, func, csv_prefix=None, schedules=None, time_limit_per_schedule=5.0, n_runs=3, history_df=None):
        """
        各スケジュールを指定時間だけ実行して最良スケジュールを決定する

        Parameters
        ----------
        func : callable
            目的関数
        csv_prefix : str or None, optional
            CSV 保存用接頭辞。None の場合は保存しない
        schedules : list of list of tuple
            スケジュールのリスト [[(mode, steps), ...], ...]
        time_limit_per_schedule : float
            各スケジュールの実行上限時間（秒）
        n_runs : int
            各スケジュールの繰り返し回数
        history_df : pd.DataFrame or None, optional
            過去の探索履歴を含む DataFrame

        Returns
        -------
        best_result : dict
            {
                "schedule_idx": int,
                "schedule": list of tuple,
                "X_all": np.ndarray,
                "Y_all": np.ndarray,
                "best_x": np.ndarray,
                "best_y": float,
                "mean_y": float,
                "mean_time": float
            }
        """
        best_y_overall = -1e12
        best_result = None

        for idx, schedule in enumerate(schedules):
            best_y_runs = []
            times = []
            print(f"\n=== Testing schedule {idx}: {schedule} ===")

            for run_id in range(n_runs):
                start_time = time.time()
                elapsed = 0
                csv_file = f"{csv_prefix}_schedule{idx}_run{run_id}.csv" if csv_prefix else None
                X_all, Y_all = None, None
                best_x, best_y = None, -1e12
                hist_df = history_df.copy() if history_df is not None else None

                while elapsed < time_limit_per_schedule:
                    for mode, _ in schedule:
                        X_all, Y_all, best_x, best_y = self.run(func, mode, steps=1, csv_filename=csv_file, history_df=hist_df)
                        hist_df = pd.DataFrame(np.column_stack([X_all, Y_all]), columns=self.var_labels + [self.target_label])
                        elapsed = time.time() - start_time
                        if elapsed >= time_limit_per_schedule:
                            break

                times.append(elapsed)
                best_y_runs.append(best_y)

            mean_y = np.mean(best_y_runs)
            mean_time = np.mean(times)
            print(f"Schedule {idx} mean best y = {mean_y:.6f}, mean time = {mean_time:.2f}s")

            if mean_y > best_y_overall or (mean_y == best_y_overall and (best_result is None or mean_time < best_result.get("mean_time", 1e12))):
                best_y_overall = mean_y
                best_result = {
                    "schedule_idx": idx,
                    "schedule": schedule,
                    "X_all": X_all,
                    "Y_all": Y_all,
                    "best_x": best_x,
                    "best_y": best_y,
                    "mean_y": mean_y,
                    "mean_time": mean_time
                }

        print(f"\n=== Overall best schedule: {best_result['schedule']} ===")
        print(f"Best y = {best_result['best_y']:.6f} at x = {best_result['best_x']}")
        return best_result