import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation, PillowWriter

# --------------------
# 2Dアニメーション
# --------------------
def animate_2d_optimization(func, var_bounds, X_all, Y_all,
                            filename=None, interval=300, resolution=50):
    x1 = np.linspace(var_bounds[0][0], var_bounds[0][1], resolution)
    x2 = np.linspace(var_bounds[1][0], var_bounds[1][1], resolution)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.array([[func(xi, xj) for xi in x1] for xj in x2])

    fig, ax = plt.subplots(figsize=(6,5))
    cs = ax.contourf(X1, X2, Z, levels=50, cmap='viridis')
    scat = ax.scatter([], [], color='red', s=50)
    ax.set_xlim(var_bounds[0])
    ax.set_ylim(var_bounds[1])
    ax.set_xlabel('x1')
    ax.set_ylabel('x2')
    ax.set_title('2D View')

    def update(frame):
        if frame == 0:
            scat.set_offsets([])
        else:
            scat.set_offsets(X_all[:frame])
        return scat,

    ani = FuncAnimation(fig, update, frames=len(Y_all)+1, interval=interval, blit=False)
    if filename:
        if filename.endswith('.gif'):
            ani.save(filename, writer=PillowWriter(fps=1000/interval))
        else:
            ani.save(filename, writer='ffmpeg', fps=1000/interval)
    plt.show()

# --------------------
# 3Dアニメーション
# --------------------
def animate_3d_optimization(func, var_bounds, X_all, Y_all,
                            filename=None, interval=300, resolution=50):
    x1 = np.linspace(var_bounds[0][0], var_bounds[0][1], resolution)
    x2 = np.linspace(var_bounds[1][0], var_bounds[1][1], resolution)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.array([[func(xi, xj) for xi in x1] for xj in x2])

    fig = plt.figure(figsize=(8,6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.6)
    scat = ax.scatter([], [], [], color='red', s=50)

    ax.set_xlim(var_bounds[0])
    ax.set_ylim(var_bounds[1])
    ax.set_zlim(np.min(Z), np.max(Z))
    ax.set_xlabel('x1')
    ax.set_ylabel('x2')
    ax.set_zlabel('y')
    ax.set_title('3D View')

    def update(frame):
        if frame == 0:
            scat._offsets3d = ([], [], [])
        else:
            x = X_all[:frame,0]
            y = X_all[:frame,1]
            z = Y_all[:frame]
            scat._offsets3d = (x, y, z)
        return scat,

    ani = FuncAnimation(fig, update, frames=len(Y_all)+1, interval=interval, blit=False)
    if filename:
        if filename.endswith('.gif'):
            ani.save(filename, writer=PillowWriter(fps=1000/interval))
        else:
            ani.save(filename, writer='ffmpeg', fps=1000/interval)
    plt.show()

# --------------------
# 2D/3D左右統合アニメーション
# --------------------
def animate_2d_3d_optimization(func, var_bounds, X_all, Y_all,
                               filename=None, interval=300, resolution=50):
    x1 = np.linspace(var_bounds[0][0], var_bounds[0][1], resolution)
    x2 = np.linspace(var_bounds[1][0], var_bounds[1][1], resolution)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.array([[func(xi, xj) for xi in x1] for xj in x2])

    fig = plt.figure(figsize=(12,6))
    ax2d = fig.add_subplot(121)
    cs = ax2d.contourf(X1, X2, Z, levels=50, cmap='viridis')
    scat2d = ax2d.scatter([], [], color='red', s=50)
    scat2d.set_offsets(np.empty((0,2)))  # ←ここ
    ax2d.set_xlim(var_bounds[0])
    ax2d.set_ylim(var_bounds[1])
    ax2d.set_xlabel('x1')
    ax2d.set_ylabel('x2')
    ax2d.set_title('2D View')

    ax3d = fig.add_subplot(122, projection='3d')
    ax3d.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.6)
    scat3d = ax3d.scatter([], [], [], color='red', s=50)
    scat3d._offsets3d = ([], [], [])  # ←ここも初期化
    ax3d.set_xlim(var_bounds[0])
    ax3d.set_ylim(var_bounds[1])
    ax3d.set_zlim(np.min(Z), np.max(Z))
    ax3d.set_xlabel('x1')
    ax3d.set_ylabel('x2')
    ax3d.set_zlabel('y')
    ax3d.set_title('3D View')

    def update(frame):
        if frame == 0:
            scat2d.set_offsets(np.empty((0,2)))
            scat3d._offsets3d = ([], [], [])
        else:
            scat2d.set_offsets(X_all[:frame])
            x = X_all[:frame,0]
            y = X_all[:frame,1]
            z = Y_all[:frame]
            scat3d._offsets3d = (x, y, z)
        return scat2d, scat3d

    ani = FuncAnimation(fig, update, frames=len(Y_all)+1, interval=interval, blit=False)
    if filename:
        if filename.endswith('.gif'):
            ani.save(filename, writer=PillowWriter(fps=1000/interval))
        else:
            ani.save(filename, writer='ffmpeg', fps=1000/interval)
    plt.show()