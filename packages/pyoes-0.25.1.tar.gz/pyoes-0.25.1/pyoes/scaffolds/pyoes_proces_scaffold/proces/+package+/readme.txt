

// When upgrading scaffold do not forget to update following settings:

./src/config.rb => path to foundation/font-awesome
./src/resources/scss/_oe-settings.scss => set "$fa-font-path" to font path in font-awesome folder