import csv, io, tempfile, subprocess, sys
from pathlib import Path
from typing import Optional

import pandas as pd

from ._constants import EDATAAID_PATH, EDATAAID_CONTROL_FILE


def _determine_delimiter(
    textlines: list[str], initial_column_headers: tuple[str]
) -> str:
    """
    Identify the delimiter used for the data based on the
    delimiter used for the initial column header.

    Parameters
    ----------
    textlines: :obj:`list[str]`
        The lines of text from the presentation log file.

    initial_column_headers: :obj:`tuple[str]`
        The initial column headers for data.

    Returns
    -------
    str
        The delimiter
    """
    sniffer = csv.Sniffer()
    for indx, line in enumerate(textlines):
        if line.startswith(tuple(initial_column_headers)):
            header_string = textlines[indx]

    return sniffer.sniff(header_string, delimiters=None).delimiter


def _convert_time(
    df: pd.DataFrame, convert_to_seconds: list[str], divisor: int
) -> pd.DataFrame:
    """
    Change time resolution of specific columns.

    Parameters
    ----------
    presentation_df: :obj:`DataFrame`
        Pandas Dataframe of the Presentation log

    convert_to_seconds: :obj:`list[str]` or :obj:`None`, default=None
        Columns to convert to time.

    divisor: :obj:`int` or :obj:`None`, default=None
        Value to divide columns listed in ``convert_to_columns`` by.

    Returns
    -------
    pandas.Dataframe
        Dataframe with timing of the columns listed in
        ``convert_to_seconds`` converted to the units
        of the ``divisor``floats and time resolution
    """
    convert_to_seconds = (
        [convert_to_seconds]
        if isinstance(convert_to_seconds, str)
        else convert_to_seconds
    )
    df[convert_to_seconds] = df[convert_to_seconds].apply(
        lambda x: x.astype(str).str.lower()
    )
    df[convert_to_seconds] = df[convert_to_seconds].replace("null", "nan")
    df[convert_to_seconds] = df[convert_to_seconds].replace("", "nan")
    df[convert_to_seconds] = df[convert_to_seconds].astype(float)
    df[convert_to_seconds] = df[convert_to_seconds].apply(lambda x: x / divisor)

    return df


def convert_edat3_to_tsv(
    edat_path: str | Path,
    dst_path: Optional[str | Path] = None,
    return_dst_path: bool = False,
) -> str | None:
    """
    Converts a file with an "edat3" extension to a TSV file.

    .. warning::
       - Program is opened and closed rapidly, which results in white flashes.

    .. important::
       - Only works with Windows platforms with Eprime 3 installed.

    edat_path: :obj:`str` or :obj:`Path`
        Absolute path to the Eprime file with an "edat3" extension.

    dst_path: :obj:`str` or :obj:`Path`, default=None
        Absolute path to the output TSV file that the edat3 file will be converted to.
        If None, the TSV file will be saved in the same folder as the edat3 file.

    return_dst_path: :obj:`bool`, default=False
        Returns the destination path if True.

    Returns
    -------
    str or None
        Returns the destination path if ``return_dst_path`` is True.
    """
    assert (
        Path(edat_path).suffix == ".edat3"
    ), "`edat_path` must be a file with the '.edat3' extension."

    if sys.platform != "win32":
        raise OSError("Function only works for Windows platforms.")

    if not Path(EDATAAID_PATH).exists:
        raise FileNotFoundError(
            f"EPrime 3 must be installed to use the following program {EDATAAID_PATH}."
        )

    dst_path = dst_path if dst_path else str(edat_path).replace(".edat3", ".tsv")
    control_file = EDATAAID_CONTROL_FILE.format(edat_path=edat_path, dst_path=dst_path)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmpfile:
        tmpfile.write(control_file)

    subprocess.run([EDATAAID_PATH, "/e", "/f", tmpfile.name])

    Path(tmpfile.name).unlink()

    return dst_path if return_dst_path else None


def load_eprime_log(
    log_filepath: str | Path,
    convert_to_seconds: list[str] = None,
    initial_column_headers: str = ("ExperimentName", "Subject"),
) -> pd.DataFrame:
    """
    Loads EPrime 3 log file as a Pandas Dataframe.

    .. important::
       If the log file extension is "edat3", use :func:`nifti2bids.parsers.convert_edat3_to_tsv`
       to convert it to text form. If exporting manually, remove the checkmark from
       the "Unicode" field. The type of text file the edat file is exported as is irrelevent.

    Parameters
    ----------
    log_filepath: :obj:`str` or :obj:`Path`
        Absolute path to the Presentation log file (i.e text, log, excel files).

    convert_to_seconds: :obj:`list[str]` or :obj:`None`, default=None
        Convert the time resolution of the specified columns from milliseconds to seconds.

    initial_column_headers: :obj:`tuple[str]`, default=("ExperimentName", "Subject")
        The initial column headers for data.

    drop_columns: :obj:`list[str]` or :obj:`None`, default=None
        Remove specified columns from dataframe.

    Returns
    -------
    pandas.Dataframe
        A Pandas dataframe of the data.
    """
    assert (
        not Path(log_filepath).suffix == ".edat3"
    ), "`log_filepath` cannot be a file with the '.edat3' extension."
    with open(log_filepath, "r") as f:
        initial_column_headers = tuple(initial_column_headers)
        textlines = f.readlines()
        delimiter = _determine_delimiter(textlines, initial_column_headers)
        cleaned_textlines = [line for line in textlines if line != "\n"]
        for indx, line in enumerate(cleaned_textlines):
            if line.startswith(f"{delimiter}".join(initial_column_headers)):
                start_indx = indx
                break

        text = "".join(cleaned_textlines[start_indx:])
        df = pd.read_csv(io.StringIO(text, newline=None), sep=delimiter)

    return (
        df
        if not convert_to_seconds
        else _convert_time(df, convert_to_seconds, divisor=1000)
    )


def load_presentation_log(
    log_filepath: str | Path,
    convert_to_seconds: list[str] = None,
    initial_column_headers: tuple[str] = ("Trial", "Event Type"),
) -> pd.DataFrame:
    """
    Loads Presentation log file as a Pandas Dataframe.

    Parameters
    ----------
    log_filepath: :obj:`str` or :obj:`Path`
        Absolute path to the Presentation log file (i.e text, log, Excel files).

    convert_to_seconds: :obj:`list[str]` or :obj:`None`, default=None
        Convert the time resolution of the specified columns from 0.1ms to seconds.

    initial_column_headers: :obj:`str`, default=("Trial", "Event Tupe")
        The initial column headers for data.

    Returns
    -------
    pandas.Dataframe
        A Pandas dataframe of the data.
    """
    with open(log_filepath, "r") as f:
        initial_column_headers = tuple(initial_column_headers)
        textlines = f.readlines()
        delimiter = _determine_delimiter(textlines, initial_column_headers)
        content_indices = []
        cleaned_textlines = [line for line in textlines if line != "\n"]
        for indx, line in enumerate(cleaned_textlines):
            # Get the starting index of the data columns
            if line.startswith(f"{delimiter}".join(initial_column_headers)):
                content_indices.append(indx)
            # Get one more than the final index of the data colums
            # Note: the lines for the data contain a trial number
            elif content_indices and not line.split(f"{delimiter}")[0].isdigit():
                content_indices.append(indx)
                break

        start_indx = content_indices[0]
        stop_indx = (
            content_indices[1] if len(content_indices) > 1 else len(cleaned_textlines)
        )

        text = "".join(cleaned_textlines[start_indx:stop_indx])
        df = pd.read_csv(io.StringIO(text, newline=None), sep=delimiter)

    return (
        df
        if not convert_to_seconds
        else _convert_time(df, convert_to_seconds, divisor=10000)
    )
