----
title: Verification
description: Tutorial on using verification
order: 2
----
Describe verification goals.

Directing Code Logician to add verification goals by adding comments to a function.
