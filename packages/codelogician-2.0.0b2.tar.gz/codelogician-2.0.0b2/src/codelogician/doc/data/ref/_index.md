----
title: ImandraX Reference
description: Built-in functions and modules
order: 5
----