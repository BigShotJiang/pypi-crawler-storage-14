

import one

def hello2():
    print(one.hello())