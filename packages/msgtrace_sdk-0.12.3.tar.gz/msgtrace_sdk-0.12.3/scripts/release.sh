#!/bin/bash
# Automated release script for msgtrace-sdk
# Usage: ./scripts/release.sh <version>
# Example: ./scripts/release.sh 0.12.3

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if version was provided
if [ $# -eq 0 ]; then
    echo -e "${RED}❌ Error: Version number required${NC}"
    echo ""
    echo "Usage: $0 <version>"
    echo ""
    echo "Examples:"
    echo "  $0 0.12.3      # Release version 0.12.3"
    echo "  $0 1.0.0       # Release version 1.0.0"
    exit 1
fi

NEW_VERSION="$1"

# Validate version format (X.Y.Z)
if [[ ! "$NEW_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "${RED}❌ Error: Invalid version format${NC}"
    echo "Version must be in format X.Y.Z (e.g., 0.12.3)"
    exit 1
fi

echo -e "${BLUE}🚀 msgtrace-sdk Release Automation${NC}"
echo ""

# Ensure we're on main branch
CURRENT_BRANCH=$(git branch --show-current)
if [ "$CURRENT_BRANCH" != "main" ]; then
    echo -e "${RED}❌ Error: Must be on main branch${NC}"
    echo "   Current branch: $CURRENT_BRANCH"
    echo "   Run: git checkout main"
    exit 1
fi

# Ensure working directory is clean
if [ -n "$(git status --porcelain)" ]; then
    echo -e "${RED}❌ Error: Working directory is not clean${NC}"
    echo "   Commit or stash your changes first"
    git status --short
    exit 1
fi

# Pull latest changes
echo -e "${BLUE}📥 Pulling latest changes...${NC}"
git pull origin main

# Get current version
CURRENT_VERSION=$(uv run python -c "import sys; sys.path.insert(0, 'src'); from msgtrace.version import __version__; print(__version__)")
echo -e "${GREEN}📦 Current version: $CURRENT_VERSION${NC}"

# Validate version bump (must be greater than current)
uv run python << EOF
from packaging.version import parse as parse_version
import sys

current = "$CURRENT_VERSION"
new = "$NEW_VERSION"

if parse_version(new) <= parse_version(current):
    print(f"❌ Error: New version ({new}) must be greater than current version ({current})")
    sys.exit(1)

print(f"✅ Version bump validated: {current} → {new}")
EOF

if [ $? -ne 0 ]; then
    exit 1
fi

echo -e "${YELLOW}🎯 Releasing version: $CURRENT_VERSION → $NEW_VERSION${NC}"
echo ""

echo ""
echo -e "${BLUE}📝 Updating files...${NC}"

# Update version.py
echo "   → src/msgtrace/version.py"
sed -i "s/__version__ = \".*\"/__version__ = \"$NEW_VERSION\"/" src/msgtrace/version.py

# Update CHANGELOG.md (move Unreleased to new version)
echo "   → CHANGELOG.md"
TODAY=$(date +%Y-%m-%d)
sed -i "/## \[Unreleased\]/a \\
\\
## [$NEW_VERSION] - $TODAY" CHANGELOG.md

# Commit changes
echo ""
echo -e "${BLUE}💾 Committing changes...${NC}"
git add src/msgtrace/version.py CHANGELOG.md
git commit -m "RELEASE: v$NEW_VERSION

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>"

# Push to main (triggers publish workflow)
echo -e "${BLUE}📤 Pushing to main...${NC}"
git push origin main

echo ""
echo -e "${GREEN}✅ Release v$NEW_VERSION initiated!${NC}"
echo ""
echo -e "${BLUE}📋 What happens next:${NC}"
echo "   1. Push triggers publish.yml workflow"
echo "   2. Workflow validates version bump"
echo "   3. Builds package and creates tag v$NEW_VERSION"
echo "   4. Publishes to PyPI (trusted publishing)"
echo "   5. Creates GitHub Release"
echo ""
echo -e "${BLUE}🔗 Monitor progress:${NC}"
echo "   GitHub Actions: https://github.com/msgflux/msgtrace-sdk/actions"
echo "   PyPI (in ~2 min): https://pypi.org/project/msgtrace-sdk/$NEW_VERSION/"
echo ""
