# Scripts

Automation scripts for msgtrace-sdk repository management.

## Release Automation

Automated script to bump version, update changelog, and trigger PyPI release.

### Prerequisites

1. **Be on main branch** with clean working directory
2. **Be a repository owner** (to push directly to main)
3. **Have PyPI trusted publishing configured** (already done)

### Usage

```bash
# Patch release (0.12.1 → 0.12.2)
./scripts/release.sh patch

# Minor release (0.12.1 → 0.13.0)
./scripts/release.sh minor

# Major release (0.12.1 → 1.0.0)
./scripts/release.sh major

# Explicit version
./scripts/release.sh 1.2.3
```

### What It Does

1. **Validates environment:**
   - Checks you're on main branch
   - Ensures working directory is clean
   - Pulls latest changes

2. **Calculates new version:**
   - `patch`: Bumps last number (0.12.1 → 0.12.2)
   - `minor`: Bumps middle number (0.12.1 → 0.13.0)
   - `major`: Bumps first number (0.12.1 → 1.0.0)
   - Or uses explicit version if provided

3. **Updates files:**
   - `src/msgtrace/version.py` - Sets `__version__`
   - `CHANGELOG.md` - Moves `[Unreleased]` to new version with date

4. **Shows diff and asks for confirmation**

5. **Commits and pushes to main:**
   ```
   RELEASE: v0.12.2

   🤖 Generated with [Claude Code](https://claude.com/claude-code)

   Co-Authored-By: Claude <noreply@anthropic.com>
   ```

6. **Triggers publish workflow:**
   - `publish.yml` detects change to `version.py`
   - Validates version bump
   - Builds package
   - Creates git tag `v0.12.2`
   - Publishes to PyPI
   - Creates GitHub Release

### Example Session

```bash
$ ./scripts/release.sh patch
🚀 msgtrace-sdk Release Automation

📥 Pulling latest changes...
Already up to date.
📦 Current version: 0.12.1
🎯 Bumping version: 0.12.1 → 0.12.2

Continue with release v0.12.2? (y/N) y

📝 Updating files...
   → src/msgtrace/version.py
   → CHANGELOG.md

📋 Changes:
diff --git a/src/msgtrace/version.py b/src/msgtrace/version.py
-__version__ = "0.12.1"
+__version__ = "0.12.2"
...

Commit and push these changes? (y/N) y

💾 Committing changes...
📤 Pushing to main...

✅ Release v0.12.2 initiated!

📋 What happens next:
   1. Push triggers publish.yml workflow
   2. Workflow validates version bump
   3. Builds package and creates tag v0.12.2
   4. Publishes to PyPI (trusted publishing)
   5. Creates GitHub Release

🔗 Monitor progress:
   GitHub Actions: https://github.com/msgflux/msgtrace-sdk/actions
   PyPI (in ~2 min): https://pypi.org/project/msgtrace-sdk/0.12.2/
```

### Notes

- ✅ **Only repository owners can use this** (requires direct push to main)
- ✅ **Maintainers use normal PR workflow** (see below)
- ✅ **Automatic rollback** if you cancel at any confirmation prompt
- ✅ **Safe to run** - multiple confirmations before pushing
- ⚠️  **PyPI releases are permanent** - can't delete/overwrite versions

### Troubleshooting

**"Error: Must be on main branch"**
```bash
git checkout main
```

**"Error: Working directory is not clean"**
```bash
git status
git stash  # or commit changes
```

**"Error: remote rejected (protected branch)"**
- You need to be a repository owner
- Or branch protection needs `enforce_admins=false`

**"Workflow failed: version downgrade detected"**
- Check CHANGELOG.md wasn't manually edited
- Ensure version.py has correct current version

---

## Setup Branch Protection

Automatically configure branch protection rules for the `main` branch using GitHub best practices.

### Prerequisites

1. **Install GitHub CLI:**
   ```bash
   # Ubuntu/Debian
   sudo apt install gh

   # macOS
   brew install gh

   # Or download from: https://cli.github.com/
   ```

2. **Authenticate:**
   ```bash
   gh auth login
   # Follow prompts to authenticate with GitHub
   ```

### Usage

```bash
cd /home/vilson-neto/Documents/msg-projects/msgtrace-sdk
./scripts/setup-branch-protection.sh
```

### What It Configures

The script applies these **best practices** from major OSS projects (PyTorch, TensorFlow, etc.):

#### ✅ Pull Request Requirements
- **Require PR before merging** - No direct pushes to main (except for owners)
- **Require approvals: 0** - You can self-merge, but must create PR first
- **Dismiss stale reviews** - New commits invalidate old approvals

#### ✅ Status Checks (CI/CD)
- **Require checks to pass** - All tests must pass before merge
- **Required checks** (using correct workflow names):
  - `CI / Ruff Lint & Format` - Code linting and formatting
  - `CI / Test Python 3.10` - Test suite on Python 3.10
  - `CI / Test Python 3.11` - Test suite on Python 3.11
  - `CI / Test Python 3.12` - Test suite on Python 3.12
  - `CI / Test Python 3.13` - Test suite on Python 3.13
  - `CI / Build distribution` - Package build
- **Require branches up-to-date** - Must rebase on latest main

#### ✅ History & Safety
- **Require linear history** - No merge commits, cleaner git log
- **Require conversation resolution** - All PR comments must be resolved
- **⚠️ Don't enforce for admins** - Owners can push directly (for releases)
- **No force pushes** - Prevents accidental history rewrite
- **No deletions** - Prevents accidental branch deletion

#### 👤 Permissions
- **Repository Owners:** Can bypass rules and push directly to main (for releases)
- **Maintainers:** Must create PRs and follow all rules
- **Contributors:** Must create PRs and follow all rules

### After Running

You'll see output like:
```
✅ Branch protection configured successfully!

📋 Applied rules:
   ✅ Require pull request before merging
   ✅ Require status checks to pass (test, lint, build)
   ✅ Require branches to be up to date
   ✅ Require linear history (no merge commits)
   ...
```

### Verify Configuration

Visit: https://github.com/msgflux/msgtrace-sdk/settings/branches

You should see:
- Branch name pattern: `main`
- Branch protection rules: ✅ Active
- Status checks: `test`, `lint`, `build`

### Testing It Works

Try to push directly to main (should fail):
```bash
git checkout main
echo "test" >> README.md
git commit -am "test direct push"
git push origin main
# ❌ Should fail with: "protected branch hook declined"
```

Good! Now use PRs instead:
```bash
git checkout -b test/branch-protection
git push origin test/branch-protection
gh pr create --title "test: verify branch protection"
# ✅ This works!
```

### Customizing Rules

Edit `setup-branch-protection.sh` to customize:

```bash
# Require code owner reviews
-f required_pull_request_reviews[require_code_owner_reviews]=true

# Require 1 approval (instead of 0)
-f required_pull_request_reviews[required_approving_review_count]=1

# Allow force pushes (not recommended)
-f allow_force_pushes=true
```

### Troubleshooting

#### "gh: command not found"
Install GitHub CLI: https://cli.github.com/manual/installation

#### "HTTP 403: Resource not accessible by integration"
You need admin access to the repository.

#### "Required status checks not found"
The status checks (`test`, `lint`, `build`) need to run at least once before they can be required. They'll run automatically when CI runs on a PR.

#### Want to temporarily disable protection?
```bash
# Disable (use with caution!)
gh api -X DELETE "/repos/msgflux/msgtrace-sdk/branches/main/protection"

# Re-enable
./scripts/setup-branch-protection.sh
```

### Best Practices

After enabling branch protection:

1. **Always use feature branches:**
   ```bash
   git checkout -b feat/my-feature
   ```

2. **Create PRs for all changes:**
   ```bash
   git push origin feat/my-feature
   gh pr create
   ```

3. **Wait for CI to pass** before merging

4. **Use "Squash and merge"** to keep history clean

5. **Delete branches** after merging

### Resources

- [GitHub Branch Protection Docs](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches)
- [GitHub CLI Manual](https://cli.github.com/manual/)
- [Contributing Guide](../CONTRIBUTING.md)
