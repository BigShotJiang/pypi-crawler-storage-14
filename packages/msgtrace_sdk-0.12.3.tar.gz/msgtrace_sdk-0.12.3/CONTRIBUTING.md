# Contributing Guide

Guide for contributing to msgtrace-sdk with automated CI/CD workflow.

## 🚀 Development Workflow

### 1. Setup Local Environment

```bash
# Clone repository
git clone https://github.com/msgflux/msgtrace-sdk.git
cd msgtrace-sdk

# Install dependencies with dev tools
uv sync --group dev

# Run tests to ensure everything works
uv run pytest -v
```

### 2. Create Feature Branch

```bash
# Always start from latest main
git checkout main
git pull origin main

# Create feature branch (use conventional naming)
git checkout -b feat/add-retry-logic
# or
git checkout -b fix/tracer-initialization
# or
git checkout -b docs/improve-readme
```

**Branch naming convention:**
- `feat/` - New features
- `fix/` - Bug fixes
- `docs/` - Documentation only
- `refactor/` - Code refactoring
- `test/` - Adding tests
- `chore/` - Maintenance tasks
- `perf/` - Performance improvements

### 3. Make Changes

```bash
# Edit files
vim src/msgtrace/sdk/tracer.py

# Format code
uv run ruff format

# Lint code
uv run ruff check --fix

# Run tests frequently
uv run pytest -v

# Run specific test
uv run pytest tests/test_tracer.py::TestTracerManager::test_lazy_initialization -v
```

### 4. Commit Changes

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```bash
# Stage files individually (avoid git add -A)
git add src/msgtrace/sdk/tracer.py tests/test_tracer.py

# Good commit messages:
git commit -m "feat: add retry logic to tracer initialization"
git commit -m "fix: handle connection timeout in OTLP exporter"
git commit -m "docs: add examples for async usage"
git commit -m "test: add tests for edge cases in spans"

# Bad commit messages:
git commit -m "update code"  # ❌ Too vague
git commit -m "wip"          # ❌ Work in progress
```

**Commit message format:**
```
<type>: <description>

[optional body]

[optional footer]
```

Types: `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, `perf`

### 5. Push to GitHub

**Important**: Do NOT change version in PRs. Version bumps are done separately by maintainers after merge.

```bash
git push origin feat/add-retry-logic
```

### 6. Open Pull Request

#### Via GitHub CLI (recommended):

```bash
gh pr create \
  --title "feat: Add retry logic to tracer initialization" \
  --body "## Summary
- Adds exponential backoff retry for OTLP connection
- Configurable via MSGTRACE_MAX_RETRIES env var
- Defaults to 3 retries with 1s, 2s, 4s delays

## Testing
- Added unit tests for retry logic
- Tested with flaky network conditions

## Checklist
- [x] Tests pass locally
- [x] Code formatted with ruff
- [x] Documentation updated
- [x] CHANGELOG.md updated (if needed)"
```

#### Via GitHub Web:

1. Go to https://github.com/msgflux/msgtrace-sdk
2. Click **"Compare & pull request"** (appears after push)
3. Fill in title and description
4. Click **"Create pull request"**

### 7. Automated Checks

GitHub Actions will automatically:
- ✅ **Run ruff format check**
- ✅ **Run ruff lint**
- ✅ **Run tests** on Python 3.10, 3.11, 3.12, 3.13
- ✅ **Build package**

Fix any failures:
```bash
# See CI logs on GitHub
# Fix issues locally
git add file1.py file2.py  # Stage individually, not 'git add -A'
git commit -m "fix: address CI feedback"
git push origin feat/add-retry-logic
# CI runs again automatically
```

### 8. Merge PR

Once CI is green ✅:

1. Click **"Squash and merge"** (recommended)
   - Combines all commits into one clean commit
   - Keeps main history linear

2. Edit commit message if needed

3. Click **"Confirm squash and merge"**

4. Delete branch (GitHub will prompt)

### 9. Update Local Repository

```bash
git checkout main
git pull origin main
git branch -d feat/add-retry-logic  # Delete local branch
```

---

## 🔐 For Maintainers: Creating Releases

**Important**: Version bumps and releases are done by maintainers AFTER merging PRs to main.

### Release Process

1. **Merge all PRs** for the release to `main`

2. **Update version** in `src/msgtrace/version.py`:
   ```python
   __version__ = "0.2.0"  # Bump from current version
   ```

3. **Update CHANGELOG.md** with release notes

4. **Commit and push directly to main**:
   ```bash
   git checkout main
   git pull origin main
   git add src/msgtrace/version.py CHANGELOG.md
   git commit -m "chore: release v0.2.0"
   git push origin main
   ```

5. **Automated release workflow triggers**:
   - `publish.yml` workflow detects version change
   - Validates version was bumped correctly
   - Builds distribution packages
   - Creates git tag (e.g., `v0.2.0`)
   - Publishes to TestPyPI then PyPI
   - Creates GitHub Release with notes

6. **Verify release** (takes ~1-2 minutes):
   - Check workflow: https://github.com/msgflux/msgtrace-sdk/actions/workflows/publish.yml
   - Verify tag: https://github.com/msgflux/msgtrace-sdk/tags
   - Verify PyPI: https://pypi.org/project/msgtrace-sdk/
   - Check GitHub Release: https://github.com/msgflux/msgtrace-sdk/releases

### Version Bump Guidelines

- **Patch** (0.1.0 → 0.1.1): Bug fixes only
- **Minor** (0.1.0 → 0.2.0): New features, backward compatible
- **Major** (0.1.0 → 1.0.0): Breaking changes

### Why This Approach?

**Security**: Only maintainers with write access to `main` can create releases. PRs cannot trigger releases by bumping versions, preventing unauthorized package publishes.

---

## 🧪 Running Tests

```bash
# All tests
uv run pytest -v

# Specific test file
uv run pytest tests/test_tracer.py -v

# Specific test
uv run pytest tests/test_tracer.py::TestTracerManager::test_lazy_initialization -v

# With coverage
uv run pytest -v --cov=src/msgtrace --cov-report=html

# Fast (no coverage)
uv run pytest
```

## 🎨 Code Quality

```bash
# Format code
uv run ruff format

# Check formatting
uv run ruff format --check

# Lint
uv run ruff check

# Auto-fix lint issues
uv run ruff check --fix

# Full pre-push check
uv run ruff format --check && uv run ruff check && uv run pytest -v
```

## 🔄 Hotfix Workflow

For critical bugs in production:

```bash
# 1. Create hotfix branch from main
git checkout main
git pull origin main
git checkout -b hotfix/critical-bug

# 2. Fix the bug
# ... make changes ...

# 3. Commit and push (do NOT bump version)
git add fixed_file.py
git commit -m "fix: resolve critical bug"
git push origin hotfix/critical-bug

# 4. Create PR (mark as urgent)
gh pr create --title "🚨 HOTFIX: Critical bug" --label "urgent"

# 5. Fast-track review and merge

# 6. Maintainer bumps version and releases
# After merge, maintainer will:
# - Bump patch version (0.1.0 → 0.1.1)
# - Push to main → triggers auto-release
```

## 🎯 Best Practices

### Do's ✅
- Write descriptive commit messages
- Keep PRs small and focused (one feature/fix per PR)
- Add tests for new features
- Update documentation in README
- Run `ruff format` and `ruff check --fix` before committing
- Run tests locally before pushing
- Review your own PR before merging
- Update CHANGELOG.md for notable changes
- Stage files individually (avoid `git add -A`)

### Don'ts ❌
- Don't push directly to main (branch protection enabled)
- Don't merge without CI passing
- Don't use `git push --force` on shared branches
- Don't mix multiple features in one PR
- Don't skip tests
- Don't commit work-in-progress code
- Don't use `git add -A` (stage files explicitly)

## 📦 Local Development Install

```bash
# Install SDK in editable mode
uv pip install -e .

# Test import
python -c "from msgtrace.sdk import Spans, MsgTraceAttributes; print('✓ OK')"
```

## 🐛 Debugging CI Failures

If CI fails:

1. **Check logs on GitHub**
   - Click on the failed check
   - Read error messages

2. **Reproduce locally**
   ```bash
   # Use same Python version as CI
   uv python install 3.10
   uv run pytest -v
   ```

3. **Common issues**
   - **Ruff format**: Run `uv run ruff format`
   - **Ruff lint**: Run `uv run ruff check --fix`
   - **Test failures**: Run specific test locally
   - **Import errors**: Check `__init__.py` exports

## 🔬 Testing with act (Local GitHub Actions)

Test workflows locally before pushing:

```bash
# Install act (if not installed)
# See: https://github.com/nektos/act

# Test CI workflow
~/bin/act pull_request -W .github/workflows/ci.yml

# Test specific job
~/bin/act pull_request -W .github/workflows/ci.yml -j lint-format

# Dry run (see what would execute)
~/bin/act pull_request -W .github/workflows/ci.yml --dryrun
```

## 📋 Pull Request Checklist

Before creating a PR, ensure:

- [ ] Tests pass locally (`uv run pytest -v`)
- [ ] Code formatted (`uv run ruff format`)
- [ ] Lint checks pass (`uv run ruff check`)
- [ ] Added tests for new features
- [ ] Updated README if API changed
- [ ] Updated CHANGELOG.md for notable changes
- [ ] **Version NOT changed** (maintainers will bump version after merge)
- [ ] Commit messages follow conventional commits format
- [ ] No breaking changes (or documented in PR description)

## 🔐 GitHub Configuration

### Branch Protection (already configured)

Main branch is protected with:
- ✅ Require PR before merging
- ✅ Require status checks to pass
- ✅ Require linear history (squash merges)
- ❌ No force pushes
- ❌ No direct commits

### Required Secrets (for maintainers)

For PyPI publishing, configure these secrets at:
https://github.com/msgflux/msgtrace-sdk/settings/secrets/actions

- `PYPI_API_TOKEN` - From https://pypi.org/manage/account/token/
- `TEST_PYPI_API_TOKEN` - From https://test.pypi.org/manage/account/token/

## 📚 Resources

- [Conventional Commits](https://www.conventionalcommits.org/)
- [Semantic Versioning](https://semver.org/)
- [Keep a Changelog](https://keepachangelog.com/)
- [Ruff Documentation](https://docs.astral.sh/ruff/)
- [pytest Documentation](https://docs.pytest.org/)
- [GitHub Actions](https://docs.github.com/en/actions)
