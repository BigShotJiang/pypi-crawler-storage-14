# EZAI - 简单易用的AI机器人控制库

[![PyPI version](https://badge.fury.io/py/ezai-go2.svg)](https://badge.fury.io/py/ezai-go2)
[![Python versions](https://img.shields.io/pypi/pyversions/ezai-go2.svg)](https://pypi.org/project/ezai-go2/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

EZAI是一个专为Go2机器狗和AI应用设计的简化Python接口库，让机器人控制和计算机视觉变得简单易用。

## 🚀 特性

- **简单易用**: 专为初学者设计的API接口
- **模块化设计**: 支持按需导入，减少依赖
- **Go2机器狗控制**: 完整的运动控制和视频流支持
- **计算机视觉**: 集成OpenCV，支持图像处理和显示
- **AI工作流**: 支持ONNX和RKNN模型推理
- **教育友好**: 适合STEM教育和编程学习

## 📦 安装

### 基础安装
```bash
pip install ezai-go2
```

### 完整安装（包含所有可选依赖）
```bash
pip install ezai-go2[all]
```

### 仅安装ONNX支持
```bash
pip install ezai-go2[onnx]
```

### 仅安装RKNN支持
```bash
pip install ezai-go2[rknn]
```

## 🔧 Go2 SDK安装

要使用Go2机器狗控制功能，需要额外安装unitree-sdk2py：

```bash
# 从官方源码安装
git clone https://github.com/unitreerobotics/unitree_sdk2_python.git
cd unitree_sdk2_python
pip install -e .
```

## 📖 快速开始

### Go2机器狗控制

```python
from ezai import Go2

# 创建Go2控制器
dog = Go2()

# 连接机器狗
if dog.connect():
    # 前进
    dog.move(0.5, 0, 0)  # vx=0.5, vy=0, vyaw=0
    time.sleep(2)
    
    # 停止
    dog.move(0, 0, 0)
    
    # 断开连接
    dog.disconnect()
```

### 计算机视觉

```python
from ezai import Camera, OpenCVUI

# 创建摄像头
camera = Camera()
ui = OpenCVUI()

# 捕获图像
image = camera.capture()
if image is not None:
    # 显示图像
    ui.show_image("Camera", image)
    ui.waitKey(0)
```

### AI推理（ONNX）

```python
from ezai import ONNXWorkflow

# 创建ONNX工作流
workflow = ONNXWorkflow("model.onnx")

# 加载图像
image = cv2.imread("test.jpg")

# 运行推理
result = workflow.run(image)
print(f"推理结果: {result}")
```

## 📚 模块说明

### Go2模块
- `Go2`: Go2机器狗主控制类
- 支持运动控制、状态查询、视频流等
- 自动网络接口检测和IP配置

### Camera模块
- `Camera`: 摄像头控制类
- 支持USB摄像头和网络摄像头
- 简化的图像捕获接口

### UI模块
- `OpenCVUI`: OpenCV显示界面类
- 简化的图像显示和交互接口
- 支持窗口管理和事件处理

### AI工作流模块
- `ONNXWorkflow`: ONNX模型推理
- `RKNNWorkflow`: RKNN模型推理
- 统一的推理接口设计

## 🛠️ 开发

### 安装开发依赖
```bash
pip install ezai-go2[dev]
```

### 运行测试
```bash
pytest tests/
```

### 代码格式化
```bash
black ezai/
```

## 📋 依赖要求

- Python >= 3.7
- OpenCV >= 4.5.0
- NumPy <= 1.24.3
- Pillow >= 8.0.0
- netifaces >= 0.10.0

可选依赖：
- unitree-sdk2py (Go2控制)
- onnx + onnxruntime (ONNX推理)
- rknn-toolkit2 (RKNN推理)

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📄 许可证

本项目采用MIT许可证 - 详见 [LICENSE](LICENSE) 文件

## 📞 联系方式

- 邮箱: macnote@qq.com
- GitHub: https://github.com/nmww/go2dog
- 文档: https://github.com/nmww/go2dog/blob/main/DEVELOPMENT.md

## 🙏 致谢

感谢Unitree机器人提供的Go2 SDK支持！