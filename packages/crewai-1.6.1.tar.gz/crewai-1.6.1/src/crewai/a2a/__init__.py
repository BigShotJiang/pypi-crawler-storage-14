"""Agent-to-Agent (A2A) protocol communication module for CrewAI."""

from crewai.a2a.config import A2AConfig


__all__ = ["A2AConfig"]
