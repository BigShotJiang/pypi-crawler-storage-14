"""Exceptions for crewAI."""
