def sumar(a, b):
    """Devuelve la suma de a y b."""
    return a + b

def restar(a, b):
    """Devuelve la resta a - b."""
    return a - b

def multiplicar(a, b):
    """Devuelve la multiplicación de a por b."""
    return a * b

def dividir(a, b):
    """Devuelve la división a / b. Lanza ZeroDivisionError si b == 0."""
    if b == 0:
        raise ZeroDivisionError("No se puede dividir por cero.")
    return a / b
