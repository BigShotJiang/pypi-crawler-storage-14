from .operaciones import sumar, restar, multiplicar, dividir

__all__ = ["sumar", "restar", "multiplicar", "dividir"]
__version__ = "0.1.0"
