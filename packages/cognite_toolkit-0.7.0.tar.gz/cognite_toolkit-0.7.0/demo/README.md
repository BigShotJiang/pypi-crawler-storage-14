# demo directory

This directory contains configuration files and a preproc.py script used
as part of deploying the default demo to a Cognite-internal demo project.

You can delete this directory if you are not using the demo functionality for your own purposes.
