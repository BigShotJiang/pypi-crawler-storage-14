## Changelog 

### Added

- In `cdf build/deploy` resource types `Agents` and `SearchConfig` are
now supported.
- Added new plugin `cdf data download/upload/purge`.
- The `cdf build` command now has a new flag `--exit-on-warning`. This
is for CI when you want warnings to make `cdf build` fail.
- The `cdf dump` has been extended with support for `location-filter`,
`extraction-pipeline`, `functions`, `dataset`, `streamlit`.
- The `cdf.toml` now supports to fetch templates from external
litraries.

## Changed

- On `DataModelingOnly` projects, `cdf deploy` now uses `CogniteFile` to
store Funcion code.

## Removed

- The command `cdf dump asset/timeseries` have been removed. You should
use `cdf data download assets/timeseries` instead.
- The command `cdf purge` has been moved to `cdf data purge`.