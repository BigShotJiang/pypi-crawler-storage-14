"""QciConnect package"""
from .mageia import Client

Mageia = Client
