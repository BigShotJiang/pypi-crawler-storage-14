# QCI Connect API Client

This is a python package to interact with the [QCi Connect](https://connect.qci.dlr.de/) platform of the [German Aerospace Center (DLR)](https://www.dlr.de/). 
It also allows local testing, deployment, and interaction with the platform's compiler stack. 

## Quick start

The four following steps provide a quick start on how to programmatically interact with the QCi Connect platform:

- Download the [python package](https://gitlab.dlr.de/qc/compilation/hequate/-/jobs/5946985/artifacts/raw/build/hequate-0.2.0.tar.gz)
- Run `pip install qciconnect`
- Run `pip install -r requirements.txt`
- Run `jupyter notebook` and navigate to _./examples/example_remote.ipynb_

## Developer Workflow

If you're looking to integrate new compiler passes or features to the platform, feel free to reach out to [qc-software@dlr.de](mailto:qc-software@dlr.de). 
We will guide you through the steps outline below:
- set up of a local test environment similar to the production platform,
- set up an additional compiler pass template for your local platform.

### The Local Test Environment

The platform operates on [containerized compiler passes](qc-platform/FAQ.md). 
To set it up locally, choose either _Docker_ or _Podman_ below. 
(Within DLR the Linux user will likely go with _Docker_ and the Windows user with _Podman_.)  

#### Docker
- Install docker: [Docker Engine installation overview](https://docs.docker.com/engine/install/)  
- Log into [helmholtz.cloud](https://codebase.helmholtz.cloud/) and create an [access token](https://codebase.helmholtz.cloud/-/user_settings/personal_access_tokens).
- Build all docker images and run the stack:
  ```
  cd deployment/docker-user
  docker login registry.hzdr.de -u [username] -p [access token]
  docker compose up
  ```
- Run `jupyter notebook` and navigate to `examples/example_local.ipynb`

#### Podman
- Install podman and podman desktop from [Podman](https://podman.io) (Apache License 2.0)
- Log into [helmholtz.cloud](https://codebase.helmholtz.cloud/) and create an [access token](https://codebase.helmholtz.cloud/-/user_settings/personal_access_tokens).
- Install `podman compose` (if you don't intend to use docker-compose under the hood)
  ```
  pip3 install https://github.com/containers/podman-compose/archive/main.tar.gz
  ```
- Build all podman images:
  ```
  cd deployment/docker-user
  podman login registry.hzdr.de -u [username] -p [access token]
  podman compose up
  ```
- Run `jupyter notebook` and navigate to_examples/example_local.ipynb_

### Adding New Compiler Passes

Please see  [`compilers/README.md`](./compilers/README.md) for instructions to do so.
