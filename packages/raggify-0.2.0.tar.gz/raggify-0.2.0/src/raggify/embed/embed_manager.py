from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from llama_index.core.settings import Settings

from ..core.utils import sanitize_str
from ..llama.core.schema import Modality
from ..logger import logger

if TYPE_CHECKING:
    from llama_index.core.base.embeddings.base import BaseEmbedding, Embedding
    from llama_index.core.schema import ImageType

    from ..llama.embeddings.multi_modal_base import AudioType, VideoType


@dataclass(kw_only=True)
class EmbedContainer:
    """Container for embedding-related parameters per modality."""

    provider_name: str
    embed: BaseEmbedding
    dim: int
    alias: str
    space_key: str = ""


class EmbedManager:
    """Manager class for embeddings."""

    def __init__(self, conts: dict[Modality, EmbedContainer]) -> None:
        """Constructor.

        Args:
            conts (dict[Modality, EmbedContainer]):
                Mapping of modality to embedding container.
        """
        self._conts = conts

        for modality, cont in conts.items():
            cont.space_key = self._generate_space_key(
                provider=cont.provider_name,
                model=cont.alias,
                modality=modality,
            )
            logger.debug(f"space_key: {cont.space_key} generated")

        Settings.embed_model = None  # disable llama_index default embed model

    @property
    def name(self) -> str:
        """Provider names.

        Returns:
            str: Provider names.
        """
        return ", ".join([cont.provider_name for cont in self._conts.values()])

    @property
    def modality(self) -> set[Modality]:
        """Modalities supported by this embedding manager.

        Returns:
            set[Modality]: Modalities.
        """
        return set(self._conts.keys())

    @property
    def space_key_text(self) -> str:
        """Space key for text embeddings.

        Raises:
            RuntimeError: If uninitialized.

        Returns:
            str: Space key.
        """
        return self.get_container(Modality.TEXT).space_key

    @property
    def space_key_image(self) -> str:
        """Space key for image embeddings.

        Raises:
            RuntimeError: If uninitialized.

        Returns:
            str: Space key.
        """
        return self.get_container(Modality.IMAGE).space_key

    @property
    def space_key_audio(self) -> str:
        """Space key for audio embeddings.

        Raises:
            RuntimeError: If uninitialized.

        Returns:
            str: Space key.
        """
        return self.get_container(Modality.AUDIO).space_key

    @property
    def space_key_video(self) -> str:
        """Space key for video embeddings.

        Raises:
            RuntimeError: If uninitialized.

        Returns:
            str: Space key.
        """
        return self.get_container(Modality.VIDEO).space_key

    def get_container(self, modality: Modality) -> EmbedContainer:
        """Get the embedding container for a modality.

        Args:
            modality (Modality): Modality.

        Raises:
            RuntimeError: If uninitialized.

        Returns:
            EmbedContainer: Embedding container.
        """
        cont = self._conts.get(modality)
        if cont is None:
            raise RuntimeError(f"embed {modality} is not initialized")

        return cont

    async def aembed_text(self, texts: list[str]) -> list[Embedding]:
        """Get embedding vectors for text asynchronously.

        Args:
            texts (list[str]): Texts to embed.

        Raises:
            RuntimeError: If failed to embed.

        Returns:
            list[Embedding]: Embedding vectors.
        """
        if Modality.TEXT not in self.modality:
            logger.warning("no text embedding is specified")
            return []

        embed = self.get_container(Modality.TEXT).embed

        logger.debug(f"now batch embedding {len(texts)} texts...")
        dims = await embed.aget_text_embedding_batch(texts=texts, show_progress=True)

        if dims:
            logger.debug(f"dim = {len(dims[0])}, embed {len(dims)} texts")

        return dims

    async def aembed_image(self, paths: list[ImageType]) -> list[Embedding]:
        """Get embedding vectors for images asynchronously.

        Args:
            paths (list[ImageType]): Image paths or base64 payloads.

        Raises:
            RuntimeError: If not an image embedder or failed to embed.

        Returns:
            list[Embedding]: Embedding vectors.
        """
        from llama_index.core.embeddings.multi_modal_base import MultiModalEmbedding

        if Modality.IMAGE not in self.modality:
            logger.warning("no image embedding is specified")
            return []

        embed = self.get_container(Modality.IMAGE).embed
        if not isinstance(embed, MultiModalEmbedding):
            raise RuntimeError("multimodal embed model is required")

        logger.debug(f"now batch embedding {len(paths)} images...")
        dims = await embed.aget_image_embedding_batch(
            img_file_paths=paths, show_progress=True
        )

        if dims:
            logger.debug(f"dim = {len(dims[0])}, embed {len(dims)} images")

        return dims

    async def aembed_audio(self, paths: list[AudioType]) -> list[Embedding]:
        """Get embedding vectors for audio asynchronously.

        Args:
            paths (list[AudioType]): Audio paths.

        Raises:
            RuntimeError: If not an audio embedder or failed to embed.

        Returns:
            list[Embedding]: Embedding vectors.
        """
        from ..llama.embeddings.multi_modal_base import AudioEmbedding

        if Modality.AUDIO not in self.modality:
            logger.warning("no audio embedding is specified")
            return []

        embed = self.get_container(Modality.AUDIO).embed
        if not isinstance(embed, AudioEmbedding):
            raise RuntimeError("audio embed model is required")

        logger.debug(f"now batch embedding {len(paths)} audios...")
        dims = await embed.aget_audio_embedding_batch(
            audio_file_paths=paths, show_progress=True
        )

        if dims:
            logger.debug(f"dim = {len(dims[0])}, embed {len(dims)} audios")

        return dims

    async def aembed_video(self, paths: list[VideoType]) -> list[Embedding]:
        """Get embedding vectors for video asynchronously.

        Args:
            paths (list[VideoType]): Video paths.

        Raises:
            RuntimeError: If not a video embedder or failed to embed.

        Returns:
            list[Embedding]: Embedding vectors.
        """
        from ..llama.embeddings.multi_modal_base import VideoEmbedding

        if Modality.VIDEO not in self.modality:
            logger.warning("no video embedding is specified")
            return []

        embed = self.get_container(Modality.VIDEO).embed
        if not isinstance(embed, VideoEmbedding):
            raise RuntimeError("video embed model is required")

        logger.debug(f"now batch embedding {len(paths)} videos...")
        dims = await embed.aget_video_embedding_batch(
            video_file_paths=paths, show_progress=True
        )

        if dims:
            logger.debug(f"dim = {len(dims[0])}, embed {len(dims)} videos")

        return dims

    def _generate_space_key(self, provider: str, model: str, modality: Modality) -> str:
        """Generate a space key string.

        Args:
            provider (str): Provider name.
            model (str): Model name.
            modality (Modality): Modality.

        Raises:
            ValueError: If the space key is too long.

        Returns:
            str: Space key string.
        """
        # Shorten labels
        mod = {
            Modality.TEXT: "te",
            Modality.IMAGE: "im",
            Modality.AUDIO: "au",
            Modality.VIDEO: "vi",
        }
        if mod.get(modality) is None:
            raise ValueError(f"unexpected modality: {modality}")

        return sanitize_str(f"{provider}_{model}_{mod[modality]}")
