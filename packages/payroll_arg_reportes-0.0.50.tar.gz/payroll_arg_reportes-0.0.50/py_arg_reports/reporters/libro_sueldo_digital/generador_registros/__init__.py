from .registro1 import *  # noqa F401
from .registro2 import *  # noqa F401
from .registro3 import *  # noqa F401
from .registro4 import *  # noqa F401
from .registro5 import *  # noqa F401
