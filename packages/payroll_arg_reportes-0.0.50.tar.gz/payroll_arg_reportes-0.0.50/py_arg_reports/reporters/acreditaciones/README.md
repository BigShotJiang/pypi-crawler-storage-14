# Generación de archivos de acreaditaciones para banco


