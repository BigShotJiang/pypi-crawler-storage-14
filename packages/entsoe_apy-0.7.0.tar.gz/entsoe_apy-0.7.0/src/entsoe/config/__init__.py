from .config import (
    get_config,
    set_config,
)

__all__ = ["set_config", "get_config"]
