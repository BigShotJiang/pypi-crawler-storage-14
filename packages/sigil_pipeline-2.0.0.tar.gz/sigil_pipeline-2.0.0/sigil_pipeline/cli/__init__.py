"""
CLI modules for SigilDERG Pipeline.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
Version: 2.0.0
"""
