"""
Common utilities for CCCC runtime.
"""

