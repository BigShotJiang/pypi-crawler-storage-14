"""
MOA Triple-Metric Outlier Scorer
Patent Pending U.S. Provisional Serial No. 63/926,578 (filed Nov 27, 2025)
Copyright © 2025 Michael Ordon. All Rights Reserved.
BUSL 1.1 (change date: 2029-11-27).

This is the canonical reference implementation of the patented triple-metric
outlier detection algorithm for embedding vectors in RAG systems.
"""

import numpy as np
from scipy.spatial.distance import cdist
from scipy.stats import zscore
from sklearn.neighbors import NearestNeighbors


def triple_metric_scorer(embeddings, k=15, lambda_thresh=1.5):
    """
    Magnetic Outlier Agent core scorer.

    Combines three geometric metrics to identify outliers in embedding space:
    1. Centroid distance (d_i): How far each point is from the global center
    2. Local density (δ_i): Inverse of average k-NN distance (sparse = outlier)
    3. Triangle density/curvature (κ_i): How tightly neighbors connect to each other

    The final score is: z(d) - z(δ) - z(κ)
    High scores indicate outliers: far from center, sparse neighborhood, weak neighbor connections.

    Args:
        embeddings: numpy array of shape (N, D) where N=num samples, D=dimensions
        k: number of nearest neighbors to use (default 15)
        lambda_thresh: outlier threshold in standard deviations (default 1.5)

    Returns:
        scores: array of length N with outlier scores per sample
        outlier_indices: indices where score > mean + lambda_thresh * std

    Example:
        >>> embeddings = np.random.normal(0, 1, (100, 64))  # 100 normal points
        >>> outliers = np.random.normal(10, 1, (5, 64))     # 5 far outliers
        >>> X = np.vstack([embeddings, outliers])
        >>> scores, out_idx = triple_metric_scorer(X, k=10, lambda_thresh=1.5)
        >>> print(f"Detected {len(out_idx)} outliers")
        >>> print(f"Last 5 indices flagged: {set(out_idx) == set(range(100, 105))}")
    """
    embeddings = np.asarray(embeddings, dtype=float)
    N, D = embeddings.shape

    if N <= k:
        raise ValueError(f"Need more samples than k. Got N={N}, k={k}")

    # Metric 1: distance to global centroid
    centroid = np.mean(embeddings, axis=0)
    d_i = np.linalg.norm(embeddings - centroid, axis=1)

    # Metric 2: local density (inverse of avg distance to k nearest neighbors)
    nbrs = NearestNeighbors(n_neighbors=k+1, metric="euclidean").fit(embeddings)
    distances, indices = nbrs.kneighbors(embeddings)

    # distances[:, 0] are zero (self). Use 1: to skip self.
    avg_knn_dist = np.mean(distances[:, 1:], axis=1)
    delta_i = 1.0 / (avg_knn_dist + 1e-8)  # add epsilon to avoid div-by-zero

    # Metric 3: curvature proxy (triangle density among neighbors)
    # For each point, count how many of its k neighbors are also neighbors of each other
    kappa_i = np.zeros(N, dtype=float)
    for i in range(N):
        neighbor_idx = indices[i, 1:]  # exclude self
        sub = embeddings[neighbor_idx]
        sub_dists = cdist(sub, sub)  # pairwise distances among neighbors
        radius = np.max(distances[i, 1:])  # k-th neighbor distance

        triangles = 0
        possible = 0
        for a in range(k):
            for b in range(a + 1, k):
                possible += 1
                # If two neighbors are close to each other (within 1.2x radius), count as triangle
                if sub_dists[a, b] < 1.2 * radius:
                    triangles += 1
        kappa_i[i] = triangles / possible if possible > 0 else 0.0

    # Normalize each metric to z-scores and combine
    z_d = zscore(d_i)
    z_delta = zscore(delta_i)
    z_kappa = zscore(kappa_i)

    # Final score: high d (far), low delta (sparse), low kappa (weak connections) → high score
    scores = z_d - z_delta - z_kappa

    # Flag outliers above threshold
    mean_s = np.mean(scores)
    std_s = np.std(scores) if np.std(scores) > 0 else 1.0
    cutoff = mean_s + lambda_thresh * std_s
    outlier_indices = np.where(scores > cutoff)[0]

    return scores, outlier_indices


if __name__ == "__main__":
    # Synthetic demo: 105 normal points around 0, 10 clear outliers around 10
    np.random.seed(42)
    normals = np.random.normal(0.0, 1.0, size=(105, 64))
    outliers = np.random.normal(10.0, 1.5, size=(10, 64))
    X = np.vstack([normals, outliers])

    print("=" * 60)
    print("MOA Triple-Metric Scorer - Synthetic Test")
    print("=" * 60)
    print(f"Data: {len(normals)} normals (mean=0, std=1) + {len(outliers)} outliers (mean=10, std=1.5)")
    print(f"Total samples: {X.shape[0]}, Dimensions: {X.shape[1]}")
    print()

    scores, out_idx = triple_metric_scorer(X, k=10, lambda_thresh=1.5)

    print(f"Score stats → mean: {scores.mean():.3f}, std: {scores.std():.3f}")
    print(f"Cutoff threshold: {scores.mean() + 1.5 * scores.std():.3f}")
    print()
    print(f"Detected {len(out_idx)} outliers:")
    print(f"  Indices: {sorted(out_idx.tolist())}")
    print()

    # Check if we perfectly caught the 10 synthetic outliers (indices 105-114)
    expected = set(range(105, 115))
    detected = set(out_idx)
    perfect = expected == detected

    if perfect:
        print("✅ Perfect detection: all 10 outliers flagged, no false positives!")
    else:
        false_pos = detected - expected
        false_neg = expected - detected
        print(f"⚠️  Detection results:")
        if false_pos:
            print(f"   False positives: {sorted(false_pos)}")
        if false_neg:
            print(f"   False negatives (missed outliers): {sorted(false_neg)}")

    print("=" * 60)
    print("Patent Pending: U.S. Provisional 63/926,578")
    print("License: BUSL 1.1 (change date: 2029-11-27)")
    print("=" * 60)
