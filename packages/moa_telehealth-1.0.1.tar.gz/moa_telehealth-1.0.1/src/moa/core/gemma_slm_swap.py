import ollama
from typing import Dict, List

class SLMRuleChecker:
    def __init__(self):
        self.model = "gemma2:2b"  # Local, PHI-safe

    def check_implied_consent(self, text: str) -> Dict[str, float]:
        prompt = f"Analyze this RN/telehealth note for implied informed consent (risks/benefits explained, revocation option). Score 0-1 (1=full consent). Output ONLY the score as a number (e.g., 0.95). Text: {text[:500]}..."
        resp = ollama.generate(model=self.model, prompt=prompt)
        # Robust parse: Find first numeric (0.0-1.0)
        score_str = [s for s in resp['response'].split() if s.replace('.', '').replace('-', '').isdigit() and 0 <= float(s) <= 1]
        score = float(score_str[0]) if score_str else 0.5  # Fallback 0.5
        return {"passed": score > 0.8, "score": score, "details": resp['response'][:100]}

def evaluate_with_slm(text: str, rules: List[str]) -> List[Dict]:
    checker = SLMRuleChecker()
    results = []
    for rule in rules:
        if rule == "consent":
            results.append(checker.check_implied_consent(text))
    return results

if __name__ == "__main__":
    sample = "Patient consented to telehealth risks; in-person option discussed."
    print(evaluate_with_slm(sample, ["consent"]))  # {'passed': True, 'score': 0.95, ...}