"""
MCP Layer 3 — Free Gov/Insurance APIs for Telehealth Compliance
Patent Pending U.S. Provisional 63/926,578 (filed Nov 27, 2025)
Copyright © 2025 Michael Ordon. All Rights Reserved.
BUSL 1.1 (change date: 2029-11-27).
"""

import os
import re
import time
from typing import Dict, Any

import requests
# Optional; keep only if you really need full FHIR parsing
# from fhir.resources.patient import Patient  # For CMS Blue Button FHIR


# -------- PHI GUARD --------

PHI_PATTERNS = [
    r"\b\d{3}-\d{2}-\d{4}\b",          # SSN pattern
    r"\b\d{3}-\d{3}-\d{4}\b",          # US phone
    r"\b[A-Z][a-z]+ [A-Z][a-z]+\b",    # Very rough "Firstname Lastname"
    r"\b\d{1,2}/\d{1,2}/\d{4}\b",      # Date mm/dd/yyyy
]

def _contains_phi(text: str) -> bool:
    if not text:
        return False
    for pattern in PHI_PATTERNS:
        if re.search(pattern, text):
            return True
    return False


# -------- SIMPLE TTL CACHE --------

class _TTLCache:
    def __init__(self, ttl_seconds: int = 86400):
        self.ttl = ttl_seconds
        self._store: Dict[str, Any] = {}

    def get(self, key: str):
        item = self._store.get(key)
        if not item:
            return None
        value, ts = item
        if time.time() - ts > self.ttl:
            self._store.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any):
        self._store[key] = (value, time.time())


# -------- MAIN GATEWAY --------

class MCPGateway:
    """
    Thin wrapper around free gov/insurance APIs.

    WARNING: Do NOT pass raw clinical notes or patient names here from an LLM.
    Only use sanitized codes (ICD-10, CPT), state abbreviations, and generic bill queries.
    """

    def __init__(self, ttl_seconds: int = 86400):
        self.cache = _TTLCache(ttl_seconds=ttl_seconds)

    # ---------- ICD / CPT LOOKUP (NLM + eCFR) ----------

    def lookup_billing_code(self, code_type: str, code: str) -> dict:
        """
        code_type: "icd10" or "cpt"
        code: e.g., "F33.1" or "99213"
        """
        if _contains_phi(code):
            raise ValueError("PHI DETECTED - refusing to call external API with this input")

        cache_key = f"billing:{code_type}:{code}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached

        if code_type.lower() == "icd10":
            # NLM Clinical Tables API
            url = "https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search"
            try:
                resp = requests.get(url, params={"terms": code}, timeout=8)
                resp.raise_for_status()
                data = resp.json()

                # Typical structure:
                # [version, field_names, list_of_rows, ...]
                rows = data[3] if len(data) > 3 else []
                if rows:
                    first = rows[0]
                    # Usually [code, name, ...]
                    desc = first[1] if len(first) > 1 else "Description unavailable"
                else:
                    desc = "Not found"

                result = {
                    "code_type": "icd10",
                    "code": code,
                    "description": desc,
                    "source": "NLM Clinical Tables",
                }
            except Exception as e:
                result = {
                    "code_type": "icd10",
                    "code": code,
                    "error": f"NLM lookup failed: {e}",
                    "source": "NLM Clinical Tables",
                }

        elif code_type.lower() == "cpt":
            # eCFR – section lookup; many endpoints return HTML not JSON.
            # Here we just return a static compliance statement + raw text snippet.
            url = (
                "https://www.ecfr.gov/api/versioner/v1/full/2024-01-01/"
                "title-42/chapter-IV/subchapter-B/part-410/subpart-B/section-410.78"
            )
            try:
                resp = requests.get(url, timeout=8)
                resp.raise_for_status()
                text = resp.text[:2000]  # avoid giant payloads
                result = {
                    "code_type": "cpt",
                    "code": code,
                    "description": "Telehealth billing (42 CFR §410.78). Manual human interpretation required.",
                    "raw_excerpt": text,
                    "source": "eCFR",
                }
            except Exception as e:
                result = {
                    "code_type": "cpt",
                    "code": code,
                    "error": f"eCFR fetch failed: {e}",
                    "source": "eCFR",
                }
        else:
            result = {"error": "Invalid code_type (use 'icd10' or 'cpt')"}

        self.cache.set(cache_key, result)
        return result

    # ---------- STATE BILL STATUS (OpenStates) ----------

    def check_state_bill_status(self, state: str, bill_query: str) -> dict:
        """
        state: two-letter code, e.g. "ca"
        bill_query: short query like "telehealth consent"
        """
        if _contains_phi(bill_query):
            raise ValueError("PHI DETECTED - refusing to call OpenStates with this input")

        cache_key = f"openstates:{state}:{bill_query}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached

        api_key = os.getenv("OPENSTATES_API_KEY")
        if not api_key:
            return {"error": "OPENSTATES_API_KEY not set in environment"}

        url = "https://openstates.org/api/v3/bills"
        params = {
            "jurisdiction": state.lower(),  # or full name, depending on config
            "q": bill_query,
        }
        headers = {"X-API-KEY": api_key}

        try:
            resp = requests.get(url, params=params, headers=headers, timeout=8)
            resp.raise_for_status()
            data = resp.json()
            # User's latest snippet uses .get("data", []) but previous one used .get("results", [])
            # I will use .get("results", []) as it is more standard for OpenStates v3, 
            # but I will add a fallback to .get("data", []) just in case.
            bills = data.get("results") or data.get("data") or []
            
            result = {
                "bills": bills,
                "status": "Current" if bills else "No active bills",
                "source": "OpenStates",
            }
        except Exception as e:
            result = {
                "error": f"OpenStates query failed: {e}",
                "source": "OpenStates",
            }

        self.cache.set(cache_key, result)
        return result

    # ---------- MEDICAID ELIGIBILITY (Blue Button stub) ----------

    def verify_medicaid_eligibility(self, patient_id: str) -> dict:
        """
        STUB – do NOT call with real IDs from an LLM.
        This is an offline pattern only; real integration must live in a
        locked backend where you control patient identity and OAuth.
        """
        if _contains_phi(patient_id):
            raise ValueError("PHI DETECTED - do not pass real patient IDs from LLM layer")

        token = os.getenv("CMS_OAUTH_TOKEN")
        if not token:
            return {"error": "CMS_OAUTH_TOKEN not set; Blue Button disabled"}

        url = f"https://bluebutton.cms.gov/v2/fhir/Patient/{patient_id}"
        headers = {"Authorization": f"Bearer {token}"}

        try:
            resp = requests.get(url, headers=headers, timeout=8)
            resp.raise_for_status()
            data = resp.json()
            # For now just return raw FHIR bundle; human or downstream service interprets.
            result = {
                "source": "CMS Blue Button",
                "raw": data,
            }
        except Exception as e:
            result = {
                "error": f"Blue Button call failed: {e}",
                "source": "CMS Blue Button",
            }

        return result


if __name__ == "__main__":
    mcp = MCPGateway()
    print(mcp.lookup_billing_code("icd10", "F33.1"))
    # print(mcp.check_state_bill_status("ca", "telehealth consent"))
    # DO NOT call verify_medicaid_eligibility with real IDs from the LLM layer.
