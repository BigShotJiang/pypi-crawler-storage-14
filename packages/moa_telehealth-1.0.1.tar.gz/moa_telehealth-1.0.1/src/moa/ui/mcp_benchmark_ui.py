"""
MOA Local MCP Benchmark Dashboard
Patent Pending U.S. Provisional Serial No. 63/926,578
Copyright © 2025 Michael Ordon. All Rights Reserved.
"""

import streamlit as st
import pandas as pd
import sqlite3
import numpy as np
import time
import re
from scipy.stats import precision_recall_fscore_support

# Mock imports - replace with actual when ready
# from moa.core.evaluate import triple_metric_scorer
# from moa.core.mcp_tools import lookup_billing_code, check_state_bill_status, search_federal_regulations

# Temporary mock implementations
def triple_metric_scorer(embeddings, k=15, lambda_thresh=1.5):
    """Mock triple-metric scorer for UI demo"""
    from scipy.spatial.distance import cdist
    from scipy.stats import zscore
    from sklearn.neighbors import NearestNeighbors
    
    N = len(embeddings)
    centroid = np.mean(embeddings, axis=0)
    d_i = np.linalg.norm(embeddings - centroid, axis=1)
    
    nbrs = NearestNeighbors(n_neighbors=min(k+1, N), metric="euclidean").fit(embeddings)
    distances, indices = nbrs.kneighbors(embeddings)
    avg_knn_dist = np.mean(distances[:, 1:], axis=1)
    delta_i = 1.0 / (avg_knn_dist + 1e-8)
    
    scores = zscore(d_i) - zscore(delta_i)
    cutoff = scores.mean() + lambda_thresh * scores.std()
    outliers = np.where(scores > cutoff)[0]
    
    return scores, outliers

def lookup_billing_code(code_type, code):
    """Mock MCP tool"""
    return {"code": code, "description": "Mock billing result", "compliant": True}

def check_state_bill_status(state, bill):
    """Mock MCP tool"""
    return {"state": state, "bill": bill, "status": "Active"}

def search_federal_regulations(query):
    """Mock MCP tool"""
    return {"query": query, "results": "42 CFR §410.78 compliant"}

st.set_page_config(page_title="MOA Benchmark Dashboard", page_icon="🧲", layout="wide")

st.title("🧲 MOA Local MCP Benchmark Dashboard")
st.markdown("**Patent Pending**: Serial 63/926,578. Select DB + MCP, benchmark compliance on visits.")
st.markdown("---")

# Sidebar: Configuration
st.sidebar.header("⚙️ Configuration")

# Database selection
db_type = st.sidebar.selectbox(
    "Database Source",
    ["CSV (Synthetic)", "SQLite (Local)", "Upload CSV"],
    help="Choose data source for benchmarking"
)

if db_type == "CSV (Synthetic)":
    num_visits = st.sidebar.slider("Number of synthetic visits", 50, 500, 100)
    outlier_pct = st.sidebar.slider("Outlier percentage", 5, 20, 10)
    
    # Generate synthetic data
    np.random.seed(42)
    visits_df = pd.DataFrame({
        'visit_id': range(num_visits),
        'note_text': [
            f"Visit {i}: Telehealth consent {'MISSING risks discussion' if i % (100//outlier_pct) == 0 else 'complete with risks, alternatives, emergency plan'}"
            for i in range(num_visits)
        ],
        'embedding': [np.random.normal(0 if i % (100//outlier_pct) else 0, 1, (384,)).tolist() for i in range(num_visits)],
        'ground_truth_outlier': [1 if i % (100//outlier_pct) == 0 else 0 for i in range(num_visits)]
    })
    embeddings = np.array([row for row in visits_df['embedding']])
    st.sidebar.success(f"✅ Generated {num_visits} synthetic visits")
    
elif db_type == "SQLite (Local)":
    db_path = st.sidebar.text_input("SQLite database path", "local_visits.db")
    if st.sidebar.button("Load from SQLite"):
        try:
            conn = sqlite3.connect(db_path)
            visits_df = pd.read_sql("SELECT * FROM visits LIMIT 100", conn)
            conn.close()
            embeddings = np.array([np.frombuffer(row, dtype=np.float32) for row in visits_df['embedding_blob']])
            st.sidebar.success(f"✅ Loaded {len(visits_df)} visits from SQLite")
        except Exception as e:
            st.sidebar.error(f"❌ Error loading SQLite: {e}")
            visits_df = None
    else:
        visits_df = None
        
else:  # Upload CSV
    uploaded_file = st.sidebar.file_uploader("Upload visit CSV", type="csv")
    if uploaded_file:
        visits_df = pd.read_csv(uploaded_file)
        # Assume embeddings are comma-separated strings or need generation
        st.sidebar.success(f"✅ Uploaded {len(visits_df)} visits")
    else:
        visits_df = None

# MCP Tool selection
st.sidebar.header("🔧 MCP Tool")
mcp_tool = st.sidebar.selectbox(
    "Regulatory Check",
    ["Billing Code (NLM)", "State Bill (OpenStates)", "Federal Regs (eCFR)"],
    help="Select regulatory compliance check"
)

# Scoring parameters
st.sidebar.header("📊 MOA Parameters")
k_neighbors = st.sidebar.slider("k (neighbors)", 5, 30, 15)
lambda_thresh = st.sidebar.slider("λ (threshold)", 1.0, 3.0, 1.5, 0.1)

# Main content
col1, col2, col3 = st.columns(3)

if visits_df is not None:
    with col1:
        st.metric("Total Visits", len(visits_df))
    with col2:
        if 'ground_truth_outlier' in visits_df.columns:
            st.metric("Ground Truth Outliers", visits_df['ground_truth_outlier'].sum())
        else:
            st.metric("Ground Truth", "N/A")
    with col3:
        st.metric("Embedding Dim", len(visits_df['embedding'][0]) if 'embedding' in visits_df.columns else 384)
    
    st.markdown("---")
    
    # Benchmark button
    if st.button("🚀 Start Benchmark", type="primary"):
        with st.spinner("Running MOA triple-metric scorer..."):
            start = time.time()
            
            # Step 1: Triple-Metric Scoring
            progress_bar = st.progress(0)
            scores, outliers = triple_metric_scorer(embeddings, k=k_neighbors, lambda_thresh=lambda_thresh)
            progress_bar.progress(33)
            
            visits_df['moa_score'] = scores
            visits_df['moa_outlier'] = [1 if i in outliers else 0 for i in range(len(visits_df))]
            progress_bar.progress(66)
            
            # Step 2: MCP Enrichment
            enriched = []
            for idx, row in visits_df.head(20).iterrows():  # Limit to 20 for demo
                if mcp_tool == "Billing Code (NLM)":
                    result = lookup_billing_code("CPT", "99214")
                elif mcp_tool == "State Bill (OpenStates)":
                    result = check_state_bill_status("CA", "AB-688")
                else:
                    result = search_federal_regulations("telehealth consent")
                
                # PHI check
                phi_safe = not bool(re.search(r'\d{3}-\d{2}-\d{4}', str(row.get('note_text', ''))))
                enriched.append({
                    'idx': idx,
                    'mcp_result': str(result),
                    'phi_safe': phi_safe
                })
            
            mcp_df = pd.DataFrame(enriched)
            visits_df = visits_df.merge(mcp_df, left_index=True, right_on='idx', how='left')
            progress_bar.progress(100)
            
            latency = time.time() - start
            
            # Step 3: Metrics
            if 'ground_truth_outlier' in visits_df.columns:
                y_true = visits_df['ground_truth_outlier']
                y_pred = visits_df['moa_outlier']
                precision, recall, f1, _ = precision_recall_fscore_support(
                    y_true, y_pred, average='binary', zero_division=0
                )
            else:
                precision = recall = f1 = 0.0
            
            st.success(f"✅ Benchmark complete in {latency:.2f}s")
            
            # Display metrics
            st.markdown("### 📈 Results")
            metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
            
            with metric_col1:
                st.metric("F1 Score", f"{f1:.3f}", delta=f"+{(f1-0.82)*100:.1f}%" if f1 > 0.82 else None)
            with metric_col2:
                st.metric("Precision", f"{precision:.3f}")
            with metric_col3:
                st.metric("Recall", f"{recall:.3f}")
            with metric_col4:
                st.metric("Latency", f"{latency:.2f}s")
            
            # Outlier summary
            st.markdown("### 🎯 Outlier Detection")
            st.info(f"🔴 Detected **{len(outliers)}** outliers ({len(outliers)/len(visits_df)*100:.1f}%)")
            
            # Visualization
            tab1, tab2, tab3 = st.tabs(["📊 Score Distribution", "📋 Visit Details", "📁 Export"])
            
            with tab1:
                # Score scatter
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(10, 6))
                
                colors = ['red' if o else 'blue' for o in visits_df['moa_outlier']]
                x = range(len(visits_df))
                y = visits_df['moa_score']
                
                ax.scatter(x, y, c=colors, alpha=0.6, s=50)
                ax.axhline(y=scores.mean() + lambda_thresh * scores.std(), 
                          color='orange', linestyle='--', label='Threshold')
                ax.set_xlabel("Visit Index")
                ax.set_ylabel("MOA Score")
                ax.set_title("Outlier Detection: Red = Flagged Outliers")
                ax.legend()
                ax.grid(alpha=0.3)
                
                st.pyplot(fig)
            
            with tab2:
                # Top outliers table
                st.markdown("#### 🚨 Top 10 Outliers")
                outlier_df = visits_df[visits_df['moa_outlier'] == 1].nlargest(10, 'moa_score')
                st.dataframe(
                    outlier_df[['visit_id', 'note_text', 'moa_score', 'mcp_result', 'phi_safe']],
                    use_container_width=True
                )
                
                st.markdown("#### ✅ Sample Normal Visits")
                normal_df = visits_df[visits_df['moa_outlier'] == 0].head(5)
                st.dataframe(
                    normal_df[['visit_id', 'note_text', 'moa_score']],
                    use_container_width=True
                )
            
            with tab3:
                # Export options
                st.markdown("#### 💾 Export Results")
                
                csv = visits_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="📥 Download CSV Report",
                    data=csv,
                    file_name=f"moa_benchmark_{time.strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
                
                # Summary text
                summary = f"""
MOA Benchmark Report
====================
Date: {time.strftime('%Y-%m-%d %H:%M:%S')}
Patent Pending: U.S. Provisional 63/926,578

Configuration:
- Database: {db_type}
- Total Visits: {len(visits_df)}
- MCP Tool: {mcp_tool}
- k-neighbors: {k_neighbors}
- λ threshold: {lambda_thresh}

Results:
- F1 Score: {f1:.3f}
- Precision: {precision:.3f}
- Recall: {recall:.3f}
- Latency: {latency:.2f}s
- Outliers Detected: {len(outliers)} ({len(outliers)/len(visits_df)*100:.1f}%)

PHI Safety: All checks passed ✓
"""
                st.download_button(
                    label="📄 Download Text Summary",
                    data=summary,
                    file_name=f"moa_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain"
                )

else:
    st.info("👈 Select a database source from the sidebar to begin")
    st.markdown("""
    ### 🚀 Quick Start
    
    1. **Select Database**: Choose synthetic data, SQLite, or upload CSV
    2. **Configure MCP**: Pick regulatory check (billing, state bills, federal regs)
    3. **Adjust Parameters**: Fine-tune k-neighbors and threshold
    4. **Run Benchmark**: Click the button to analyze visits
    5. **Review Results**: Check F1 score, outliers, and export reports
    
    ### 🔒 Security
    - **PHI Protection**: Automatic blocking of SSN/phone/dates
    - **Local Only**: No cloud uploads
    - **Patent Pending**: Serial 63/926,578
    """)

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: gray;'>
    <small>© 2025 Michael Ordon. Patent Pending U.S. Provisional 63/926,578. BUSL 1.1</small>
</div>
""", unsafe_allow_html=True)
