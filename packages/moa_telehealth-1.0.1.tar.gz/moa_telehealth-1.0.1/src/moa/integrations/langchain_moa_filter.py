from typing import List, Optional, Dict, Any
from langchain_core.documents import Document
from langchain_core.runnables import RunnableLambda

try:
    from moa import detect_outliers
except ImportError:
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../src'))
    from moa import detect_outliers

class MOAOutlierFilter:
    """
    LangChain-compatible filter that removes outliers from a list of Documents
    based on their embeddings.
    """
    def __init__(self, threshold: float = 2.0, embeddings_key: str = "embedding"):
        self.threshold = threshold
        self.embeddings_key = embeddings_key

    def filter_documents(self, documents: List[Document]) -> List[Document]:
        if not documents:
            return []
        
        # Extract embeddings
        # Assumes embeddings are stored in document metadata or passed separately
        # For this implementation, we'll assume they are in metadata for simplicity
        # In a real chain, you might pass a list of (doc, emb) tuples
        
        embeddings = []
        valid_docs = []
        
        for doc in documents:
            if self.embeddings_key in doc.metadata:
                embeddings.append(doc.metadata[self.embeddings_key])
                valid_docs.append(doc)
        
        if not embeddings:
            # If no embeddings found, return original docs (fail open) or empty (fail closed)
            # Let's return original to be safe, but log warning
            return documents

        # Run MOA
        scores, mask = detect_outliers(embeddings, threshold=self.threshold)
        
        # Filter
        filtered_docs = []
        for i, is_outlier in enumerate(mask):
            if not is_outlier:
                # Add score to metadata for transparency
                valid_docs[i].metadata['moa_score'] = float(scores[i])
                filtered_docs.append(valid_docs[i])
                
        return filtered_docs

def MOAFilterRunnable(threshold: float = 2.0) -> RunnableLambda:
    """
    Returns a Runnable that filters a list of Documents.
    """
    filter_instance = MOAOutlierFilter(threshold=threshold)
    return RunnableLambda(filter_instance.filter_documents)
