"""
MOA vs LOF Benchmark & PDF Report Generator
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import precision_score, recall_score, f1_score
from fpdf import FPDF
import sys
import os
from pathlib import Path

# Add src to path to import MOA
sys.path.insert(0, str(Path(__file__).parent))
from moa.core.geometric import GeometricDetector

# Setup directories
REPORT_DIR = Path("docs/reports")
REPORT_DIR.mkdir(parents=True, exist_ok=True)

def generate_data(n_samples=300, n_outliers=30, n_features=2):
    """Generate synthetic data for visualization (2D)."""
    np.random.seed(42)
    # Normal data: 2 clusters
    c1 = np.random.randn(n_samples // 2, n_features) + np.array([2, 2])
    c2 = np.random.randn(n_samples // 2, n_features) + np.array([-2, -2])
    X_normal = np.vstack([c1, c2])
    
    # Outliers: Uniform noise
    X_outliers = np.random.uniform(low=-6, high=6, size=(n_outliers, n_features))
    
    X = np.vstack([X_normal, X_outliers])
    y = np.array([0] * n_samples + [1] * n_outliers)
    
    return X, y

def run_benchmark():
    print("Generating synthetic data...")
    X, y_true = generate_data()
    
    # --- MOA Detection ---
    print("Running MOA (GeometricDetector)...")
    moa = GeometricDetector(lambda_threshold=1.5)
    moa_scores, moa_mask, _ = moa.detect(X)
    y_pred_moa = moa_mask.astype(int)
    
    # --- LOF Detection ---
    print("Running LOF (LocalOutlierFactor)...")
    lof = LocalOutlierFactor(n_neighbors=20, contamination=0.1)
    y_pred_lof = lof.fit_predict(X)
    # LOF returns -1 for outliers, 1 for inliers. Convert to 0/1.
    y_pred_lof = np.where(y_pred_lof == -1, 1, 0)
    
    # --- Metrics ---
    metrics = {
        "MOA": {
            "Precision": precision_score(y_true, y_pred_moa),
            "Recall": recall_score(y_true, y_pred_moa),
            "F1": f1_score(y_true, y_pred_moa)
        },
        "LOF": {
            "Precision": precision_score(y_true, y_pred_lof),
            "Recall": recall_score(y_true, y_pred_lof),
            "F1": f1_score(y_true, y_pred_lof)
        }
    }
    
    return X, y_true, y_pred_moa, y_pred_lof, metrics

def create_visuals(X, y_true, y_pred_moa, y_pred_lof):
    print("Generating visualization...")
    plt.figure(figsize=(15, 5))
    
    # Ground Truth
    plt.subplot(1, 3, 1)
    sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=y_true, palette={0: 'blue', 1: 'red'}, legend='full')
    plt.title("Ground Truth")
    
    # MOA
    plt.subplot(1, 3, 2)
    sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=y_pred_moa, palette={0: 'blue', 1: 'red'}, legend=False)
    plt.title("MOA Detection")
    
    # LOF
    plt.subplot(1, 3, 3)
    sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=y_pred_lof, palette={0: 'blue', 1: 'red'}, legend=False)
    plt.title("LOF Detection")
    
    plt.tight_layout()
    plot_path = REPORT_DIR / "benchmark_plot.png"
    plt.savefig(plot_path)
    print(f"Plot saved to {plot_path}")
    return plot_path

def create_pdf(metrics, plot_path):
    print("Generating PDF report...")
    pdf = FPDF()
    pdf.add_page()
    
    # Title
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "MOA vs LOF Benchmark Report", ln=True, align="C")
    pdf.ln(10)
    
    # Executive Summary
    pdf.set_font("Arial", "", 12)
    pdf.multi_cell(0, 10, "This report benchmarks the Magnetic Outlier Agent (MOA) against the standard Local Outlier Factor (LOF) algorithm. MOA utilizes a multi-metric geometric approach designed for high-dimensional RAG embeddings.")
    pdf.ln(5)
    
    # Metrics Table
    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, "Performance Metrics", ln=True)
    pdf.set_font("Arial", "", 12)
    
    # Header
    pdf.cell(40, 10, "Algorithm", 1)
    pdf.cell(40, 10, "Precision", 1)
    pdf.cell(40, 10, "Recall", 1)
    pdf.cell(40, 10, "F1 Score", 1)
    pdf.ln()
    
    # Rows
    for algo, scores in metrics.items():
        pdf.cell(40, 10, algo, 1)
        pdf.cell(40, 10, f"{scores['Precision']:.3f}", 1)
        pdf.cell(40, 10, f"{scores['Recall']:.3f}", 1)
        pdf.cell(40, 10, f"{scores['F1']:.3f}", 1)
        pdf.ln()
        
    pdf.ln(10)
    
    # Visualization
    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, "Visual Analysis (2D Projection)", ln=True)
    pdf.image(str(plot_path), x=10, w=190)
    
    # Conclusion
    pdf.ln(10)
    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, "Conclusion", ln=True)
    pdf.set_font("Arial", "", 12)
    
    winner = "MOA" if metrics["MOA"]["F1"] > metrics["LOF"]["F1"] else "LOF"
    pdf.multi_cell(0, 10, f"Based on the F1 score, {winner} performs better on this synthetic dataset. MOA's geometric approach is specifically tuned to detect outliers that deviate from the cluster centroid while maintaining local density awareness.")
    
    report_path = REPORT_DIR / "MOA_Benchmark_Report.pdf"
    pdf.output(str(report_path))
    print(f"PDF Report saved to {report_path}")
    return report_path

if __name__ == "__main__":
    X, y_true, y_pred_moa, y_pred_lof, metrics = run_benchmark()
    plot_path = create_visuals(X, y_true, y_pred_moa, y_pred_lof)
    create_pdf(metrics, plot_path)
