"""
测试 MCP Server 是否能正确响应 STDIO 输入
"""
import subprocess
import json
import time
import sys

print("启动 MCP Server 测试...\n")

# 启动 MCP Server
python_exe = r"H:\project\questions_mcp_server\.venv\Scripts\python.exe"
cwd = r"H:\project\questions_mcp_server"

print(f"Python: {python_exe}")
print(f"工作目录: {cwd}\n")

proc = subprocess.Popen(
    [python_exe, "-m", "src.main"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    cwd=cwd,
    text=True,
    encoding='utf-8',
    bufsize=0  # 无缓冲
)

print("MCP Server 已启动，PID:", proc.pid)
print("等待服务器初始化...\n")

# 等待服务器启动
time.sleep(3)

# 检查 stderr 输出
import threading

stderr_lines = []

def read_stderr():
    while True:
        line = proc.stderr.readline()
        if line:
            stderr_lines.append(line)
            print(f"[STDERR] {line.rstrip()}")
        else:
            break

stderr_thread = threading.Thread(target=read_stderr, daemon=True)
stderr_thread.start()

# 发送初始化请求
print("\n发送初始化请求...")
init_request = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "initialize",
    "params": {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {
            "name": "test-client",
            "version": "1.0.0"
        }
    }
}

request_str = json.dumps(init_request) + "\n"
print(f"请求: {request_str.rstrip()}\n")

try:
    proc.stdin.write(request_str)
    proc.stdin.flush()
    
    print("等待响应...")
    
    # 设置超时读取
    import select
    
    # Windows 不支持 select，使用另一种方式
    response_line = None
    start_time = time.time()
    timeout = 5
    
    while time.time() - start_time < timeout:
        try:
            response_line = proc.stdout.readline()
            if response_line:
                print(f"\n收到响应:\n{response_line}")
                
                # 尝试解析 JSON
                try:
                    response = json.loads(response_line)
                    print(f"\n解析后的响应:")
                    print(json.dumps(response, indent=2, ensure_ascii=False))
                except json.JSONDecodeError as e:
                    print(f"JSON 解析失败: {e}")
                
                break
        except Exception as e:
            print(f"读取错误: {e}")
            break
    
    if not response_line:
        print("\n超时：未收到响应")
        print(f"\n进程状态: {'运行中' if proc.poll() is None else '已退出'}")
        if proc.poll() is not None:
            print(f"退出代码: {proc.poll()}")
    
except Exception as e:
    print(f"\n错误: {e}")
    import traceback
    traceback.print_exc()

finally:
    print("\n\n终止服务器...")
    proc.terminate()
    
    # 等待进程结束
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        print("强制终止...")
        proc.kill()
    
    print("测试完成")
