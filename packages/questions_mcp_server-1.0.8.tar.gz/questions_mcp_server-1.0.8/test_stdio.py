"""
测试 MCP Server STDIO 通信
"""
import sys
import json

# 确保使用 UTF-8 编码
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', line_buffering=True)
    sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')

print("Testing STDIO communication...", file=sys.stderr)
print(f"Python version: {sys.version}", file=sys.stderr)
print(f"Encoding - stdin: {sys.stdin.encoding}, stdout: {sys.stdout.encoding}", file=sys.stderr)

# 测试读取 JSON-RPC 消息
try:
    print("Waiting for input...", file=sys.stderr)
    for line in sys.stdin:
        print(f"Received: {line.strip()}", file=sys.stderr)
        
        try:
            msg = json.loads(line)
            print(f"Parsed message: {msg}", file=sys.stderr)
            
            # 简单的 echo 响应
            response = {
                "jsonrpc": "2.0",
                "id": msg.get("id"),
                "result": {
                    "status": "ok",
                    "received": msg
                }
            }
            
            print(json.dumps(response), flush=True)
            
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}", file=sys.stderr)
            
except KeyboardInterrupt:
    print("Interrupted", file=sys.stderr)
except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    import traceback
    traceback.print_exc(file=sys.stderr)
