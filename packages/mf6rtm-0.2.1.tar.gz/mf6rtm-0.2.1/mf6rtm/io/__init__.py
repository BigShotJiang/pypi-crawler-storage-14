"""
Main io module to write and read model files
"""

from .externalio import *
