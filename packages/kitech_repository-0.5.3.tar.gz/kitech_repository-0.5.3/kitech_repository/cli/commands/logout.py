"""Logout command."""

import typer
from rich.console import Console

from kitech_repository.core.auth import AuthManager

console = Console(highlight=False)
app = typer.Typer()


@app.callback(invoke_without_command=True)
def logout(ctx: typer.Context):
    """KITECH 서버 로그아웃"""
    try:
        auth_manager = AuthManager()
        if auth_manager.logout():
            console.print("[green]✅ 로그아웃 성공![/green]")
        else:
            console.print("⚠️  로그인되어 있지 않습니다")
    except Exception as e:
        console.print(f"[red]❌ 로그아웃 실패: {e}[/red]")
        raise typer.Exit(1)
