"""Configuration commands for CLI."""

import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from kitech_repository.core.config import Config

console = Console(highlight=False)
app = typer.Typer()


@app.callback(invoke_without_command=True)
def config(ctx: typer.Context):
    """현재 설정 표시"""
    # If a subcommand is being invoked, skip the default behavior
    if ctx.invoked_subcommand is not None:
        return

    try:
        config_obj = Config.load()
        config_file = config_obj.config_dir / "config.json"

        table = Table(title="KITECH 설정", show_header=True, header_style="bold cyan")
        table.add_column("설정", style="dim", width=20)
        table.add_column("값")

        table.add_row("서버 URL", config_obj.server_url)
        table.add_row("청크 크기", f"{config_obj.chunk_size} bytes")
        table.add_row("설정 디렉토리", str(config_obj.config_dir))
        table.add_row("다운로드 디렉토리", str(config_obj.download_dir))
        table.add_row("설정 파일", str(config_file))
        table.add_row("설정 파일 존재", "✅ 있음" if config_file.exists() else "❌ 없음 (기본값 사용)")
        table.add_row("", "")  # Empty row for visual separation
        table.add_row("참고", "API 버전은 런타임에 설정됨 (기본값: v1)")

        console.print(table)
    except Exception as e:
        console.print(f"[red]❌ 설정 불러오기 실패: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def reset():
    """설정을 기본값으로 초기화"""
    try:
        config_obj = Config.load()
        config_file = config_obj.config_dir / "config.json"

        if config_file.exists():
            # Confirm with user
            confirm = Prompt.ask(f"정말 {config_file}을(를) 삭제하시겠습니까?", choices=["y", "n"], default="n")

            if confirm.lower() == "y":
                config_file.unlink()
                console.print("[green]✅ 설정이 기본값으로 초기화되었습니다[/green]")

                # Show default config
                default_config = Config()
                console.print(f"\n기본 서버 URL: {default_config.server_url}")
            else:
                console.print("초기화가 취소되었습니다")
        else:
            console.print("⚠️ 설정 파일이 없습니다 - 이미 기본값을 사용 중입니다")
    except Exception as e:
        console.print(f"[red]❌ 설정 초기화 실패: {e}[/red]")
        raise typer.Exit(1)
