"""Server management command."""

import typer
from rich.console import Console

from kitech_repository.core.config import Config

console = Console(highlight=False)
app = typer.Typer()


@app.callback(invoke_without_command=True)
def server(
    ctx: typer.Context,
    url: str = typer.Argument(None, help="설정할 서버 URL (입력하지 않으면 현재 서버 표시)"),
):
    """KITECH 서버 설정 관리"""
    if not url:
        # Show current server
        try:
            config = Config.load()
            console.print(f"\n[bold]현재 서버:[/bold] {config.server_url}\n")
        except Exception as e:
            console.print(f"[red]❌ 설정 불러오기 실패: {e}[/red]")
            raise typer.Exit(1)
    else:
        # Set new server
        url = url.strip()
        if not url:
            console.print("[red]❌ URL은 비어있을 수 없습니다[/red]")
            raise typer.Exit(1)

        try:
            config = Config.load()
            config.server_url = url.rstrip("/")
            config.save()

            console.print(f"[green]✅ 서버 설정 완료: {config.server_url}[/green]")
            console.print("\n[yellow]⚠️  다시 로그인해주세요: kitech login[/yellow]")
        except Exception as e:
            console.print(f"[red]❌ 설정 저장 실패: {e}[/red]")
            raise typer.Exit(1)
