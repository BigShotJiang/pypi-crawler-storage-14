# CHANGELOG

<!-- version list -->

## v3.0.2 (2025-11-27)

### Bug Fixes

- **core**: Add missing pydantic dependency to lifx-emulator-core
  ([`7cd2309`](https://github.com/Djelibeybi/lifx-emulator/commit/7cd230948285706c3d31ed5478e2e271ed134033))


## v3.0.1 (2025-11-26)

### Bug Fixes

- Adjust uv build for new monorepo layout
  ([`a0d5b7c`](https://github.com/Djelibeybi/lifx-emulator/commit/a0d5b7c1c1ab5659acc8554931f6c441654add05))


## v3.0.0 (2025-11-26)

### Refactoring

- Split into monorepo with separate library and CLI packages
  ([`402fe6e`](https://github.com/Djelibeybi/lifx-emulator/commit/402fe6e6c42e4fb730d076cd4dd0bfe7743b2c57))

### Breaking Changes

- The project is now split into two packages:


## v2.4.0 (2025-11-26)

- Initial Release
