# Cache System Quick Start Guide

## Installation

The caching system is built into Zephyr. Just ensure dependencies are installed:

```bash
uv sync
```

## Configuration

Add to your `.env` file:

```env
# Cache Configuration
CACHE_BACKEND=multi-level          # memory, redis, or multi-level
CACHE_REDIS_URL=redis://localhost:6379/0
CACHE_MEMORY_MAX_SIZE=10000
CACHE_DEFAULT_TTL=300              # 5 minutes
CACHE_ENABLE_COMPRESSION=true
CACHE_ENABLE_METRICS=true
CACHE_KEY_PREFIX=myapp:cache:
```

## Quick Examples

### 1. Initialize Cache in Your App

```python
from zephyr.core.cache import CacheManager

# In your app startup
cache_manager = CacheManager.configure(
    backend_type="multi-level",  # Use both memory (L1) and Redis (L2)
    redis_url="redis://localhost:6379/0",
    default_ttl=300
)
```

### 2. Basic Cache Operations

```python
from zephyr.core.cache import CacheManager

manager = CacheManager()

# Set a value
await manager.set("user:123", {"name": "John", "email": "john@example.com"})

# Get a value
user = await manager.get("user:123")

# Check existence
exists = await manager.exists("user:123")

# Delete a value
await manager.delete("user:123")

# Delete multiple
await manager.delete_many(["user:1", "user:2", "user:3"])

# Clear all cache
await manager.clear()
```

### 3. Batch Operations

```python
manager = CacheManager()

# Set multiple values
await manager.set_many({
    "user:1": {"name": "Alice"},
    "user:2": {"name": "Bob"},
    "user:3": {"name": "Charlie"}
})

# Get multiple values
users = await manager.get_many(["user:1", "user:2", "user:3"])
# Returns: {"user:1": {...}, "user:2": {...}, "user:3": {...}}
```

### 4. Numeric Operations

```python
manager = CacheManager()

# Counter increment
await manager.set("page_views", 0)
new_count = await manager.increment("page_views")      # Returns: 1
new_count = await manager.increment("page_views", 10)  # Returns: 11

# Counter decrement
new_count = await manager.decrement("page_views", 5)   # Returns: 6
```

### 5. Decorator: Simple Caching

```python
from zephyr.core.cache import cache, CacheManager

# Initialize first
CacheManager.configure(backend_type="memory")

@cache(ttl=3600)
async def get_expensive_data(data_id: int) -> dict:
    # This function result is cached for 1 hour
    # Subsequent calls with same data_id return cached value
    return await fetch_from_database(data_id)

# Usage
result1 = await get_expensive_data(1)  # Calls function
result2 = await get_expensive_data(1)  # Returns cached value
result3 = await get_expensive_data(2)  # Different arg, calls function
```

### 6. Decorator: With Invalidation

```python
from zephyr.core.cache import cache, invalidate_cache, CacheManager

CacheManager.configure(backend_type="memory")

@cache(ttl=3600)
async def get_user(user_id: int) -> dict:
    return await db.get_user(user_id)

@invalidate_cache(tags=['user:profile'])
async def update_user(user_id: int, data: dict) -> dict:
    result = await db.update_user(user_id, data)
    return result

# Usage
user = await get_user(1)        # Cached
updated = await update_user(1, new_data)  # Invalidates cache
user = await get_user(1)        # Fetches fresh data from DB
```

### 7. Health Checks

```python
manager = CacheManager()

is_healthy = await manager.health_check()
if is_healthy:
    print("Cache is ready")
else:
    print("Cache backend is down")
```

## Backend Comparison

| Feature | Memory | Redis | Multi-Level |
|---------|--------|-------|-------------|
| Speed | Fast | Fast | Fastest |
| Persistence | No | Optional | No (L1) |
| Distributed | No | Yes | Yes (L2) |
| Max Size | Configurable | Unlimited | Unlimited |
| Cost | Free | Free | Free |
| Best For | Dev/Testing | Production | Production |

## Memory Backend

Perfect for development and single-instance deployments.

```python
CacheManager.configure(
    backend_type="memory",
    memory_max_size=10000,  # Max items
    default_ttl=300
)
```

- LRU eviction when max_size reached
- TTL-based expiration
- Thread-safe with asyncio locks
- Good for testing

## Redis Backend

For distributed, production environments.

```python
CacheManager.configure(
    backend_type="redis",
    redis_url="redis://localhost:6379/0",
    enable_compression=True,
    default_ttl=3600
)
```

- Requires Redis server running
- Distributed across instances
- Compression support (gzip)
- Connection pooling
- Auto-reconnection

## Multi-Level Backend (Recommended)

Combines memory (L1) + Redis (L2) for best performance.

```python
CacheManager.configure(
    backend_type="multi-level",
    redis_url="redis://localhost:6379/1",
    memory_max_size=1000,    # L1 limit
    enable_compression=True,
    default_ttl=300
)
```

- L1: Fast in-process memory cache
- L2: Distributed Redis cache
- Write-through strategy
- Graceful degradation if Redis down

**Strategy:**
1. Get: Try L1 → Try L2 → Return None
2. Set: Write to L1 → Write to L2
3. Delete: Delete from L1 → Delete from L2

## Common Patterns

### Pattern 1: Cache User Data

```python
@cache(ttl=3600, prefix='user')
async def get_user_profile(user_id: int) -> dict:
    return await db.query_user(user_id)

@invalidate_cache(tags=['user:profile'])
async def update_user_profile(user_id: int, changes: dict) -> dict:
    return await db.update_user(user_id, changes)
```

### Pattern 2: Cache DB Query Results

```python
@cache(ttl=300, prefix='products')
async def list_products(category: str, limit: int = 50) -> list[dict]:
    return await db.query_products(category, limit)
```

### Pattern 3: Session Caching

```python
manager = CacheManager()

async def save_session(session_id: str, data: dict) -> None:
    await manager.set(f"session:{session_id}", data, ttl=86400)  # 24 hours

async def get_session(session_id: str) -> dict | None:
    return await manager.get(f"session:{session_id}")
```

### Pattern 4: Counter/Rate Limiting

```python
manager = CacheManager()

async def check_rate_limit(user_id: str, limit: int = 100) -> bool:
    key = f"rate_limit:{user_id}"
    count = await manager.increment(key)
    
    if count == 1:
        await manager.set(key, 1, ttl=3600)  # Reset every hour
    
    return count <= limit
```

## Performance Tips

1. **Use multi-level caching** for production apps
2. **Set appropriate TTLs** - balance freshness vs performance
3. **Use prefixes** to avoid key collisions
4. **Monitor cache** with health checks
5. **Clear cache thoughtfully** - only invalidate what changed
6. **Use decorators** for automatic caching on expensive operations

## Troubleshooting

### Cache not working?
- Check CACHE_BACKEND env variable
- Ensure Redis is running (if using Redis backend)
- Call `CacheManager.configure()` on app startup

### Redis connection errors?
- Verify CACHE_REDIS_URL is correct
- Check Redis server is running
- Check network connectivity

### Memory cache filling up?
- Increase CACHE_MEMORY_MAX_SIZE
- Reduce CACHE_DEFAULT_TTL
- Use Redis backend instead

### Stale data?
- Reduce TTL value
- Use @invalidate_cache decorator after updates
- Manually call manager.delete() when needed

## API Reference

```python
# Manager interface
await manager.get(key: str) -> Any | None
await manager.set(key: str, value: Any, ttl: int | None = None) -> None
await manager.delete(key: str) -> None
await manager.exists(key: str) -> bool
await manager.clear() -> None

# Batch operations
await manager.get_many(keys: list[str]) -> dict[str, Any]
await manager.set_many(data: dict[str, Any], ttl: int | None = None) -> None
await manager.delete_many(keys: list[str]) -> None

# Numeric
await manager.increment(key: str, delta: int = 1) -> int
await manager.decrement(key: str, delta: int = 1) -> int

# Admin
await manager.health_check() -> bool
await manager.close() -> None
```

## See Also

- [Full Implementation Guide](PHASE2_CACHE_IMPLEMENTATION.md)
- [Architecture Documentation](docs/caching.md)
- [Test Examples](tests/cache/)





