"""Scripts package for Zephyr framework utilities."""
