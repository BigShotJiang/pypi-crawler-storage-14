#!/bin/bash
#
# Setup git hooks for Zephyr Framework
#

set -e

HOOK_DIR=".git/hooks"

echo "📦 Setting up git hooks..."

# Create pre-commit hook
cat > "$HOOK_DIR/pre-commit" << 'EOF'
#!/bin/sh
#
# Pre-commit hook for Zephyr Framework
# Formats and checks only staged/new files with ruff
#

set -e

STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

if [ -z "$STAGED_FILES" ]; then
    exit 0
fi

PYTHON_FILES=$(echo "$STAGED_FILES" | grep '\.py$' || true)

if [ -z "$PYTHON_FILES" ]; then
    exit 0
fi

echo "🔍 Running ruff format on staged Python files..."
echo "$PYTHON_FILES" | xargs ruff format --quiet

echo "🔍 Running ruff check on staged Python files..."

if echo "$PYTHON_FILES" | xargs ruff check --quiet; then
    echo "✅ Ruff check passed"
else
    echo "❌ Ruff check failed"
    exit 1
fi

echo "📝 Re-staging formatted files..."
echo "$PYTHON_FILES" | xargs git add

exit 0
EOF

chmod +x "$HOOK_DIR/pre-commit"

echo "✅ Pre-commit hook installed"
echo "🎉 Git hooks setup complete!"

