# 🏗️ ZEPHYR PHASE 3 - MICROSERVICES ARCHITECTURE

**Version:** 1.0  
**Updated:** November 21, 2025  
**Package Manager:** UV (Python Unified Package Manager) - NO requirements.txt

---

## 🎯 TWO DEPLOYMENT MODES

Zephyr supports **BOTH monolith and microservices** deployment models from the same codebase.

```
MODE 1: MONOLITH (Single Container)
  └─ All routes in one app
  └─ Standard web framework usage
  └─ NO orchestrator needed
  └─ Perfect for small-to-medium apps

MODE 2: MICROSERVICES (Multiple Containers)
  └─ Orchestrator + Independent services
  └─ Each service in separate container
  └─ Automatic service discovery
  └─ Perfect for scaling
```

---

## 📦 PROJECT STRUCTURE - UV MONOREPO

```
zephyr-project/                          ← UV Workspace Root
│
├── pyproject.toml                       (Root workspace config - UV only)
├── uv.lock                              (Dependency lock file - auto-managed by UV)
│
├── core/                                ← Shared Code (Optional)
│   ├── pyproject.toml                   (Shared package - UV workspace member)
│   ├── src/
│   │   ├── __init__.py
│   │   ├── models.py                    (Shared data models)
│   │   ├── exceptions.py                (Shared exceptions)
│   │   ├── base_service.py              (BaseService with context managers)
│   │   └── utils.py                     (Shared utilities)
│   └── README.md
│
├── MODE-1-MONOLITH/                     ← Option 1: Run as Single App
│   └── app/
│       ├── pyproject.toml               (Monolith package - UV workspace member)
│       ├── src/
│       │   ├── __init__.py
│       │   ├── app.py                   (Main Zephyr app - MONOLITH MODE)
│       │   ├── main.py                  (Entry point)
│       │   ├── handlers/
│       │   │   ├── __init__.py
│       │   │   ├── users.py
│       │   │   ├── orders.py
│       │   │   └── payments.py
│       │   ├── middleware/
│       │   │   ├── __init__.py
│       │   │   └── custom.py
│       │   ├── models/
│       │   │   ├── __init__.py
│       │   │   └── schemas.py
│       │   └── config/
│       │       ├── __init__.py
│       │       └── settings.py
│       ├── Dockerfile                   (Single container)
│       ├── docker-compose.yml
│       └── README.md
│
├── MODE-2-MICROSERVICES/                ← Option 2: Run as Multiple Services
│   ├── orchestrator/
│   │   ├── pyproject.toml               (Orchestrator - UV workspace member)
│   │   ├── src/
│   │   │   ├── __init__.py
│   │   │   ├── app.py                   (Orchestrator Zephyr app - ORCHESTRATOR MODE)
│   │   │   ├── main.py                  (Entry point)
│   │   │   ├── manager.py               (Service manager)
│   │   │   └── config/
│   │   │       └── settings.py
│   │   ├── Dockerfile
│   │   └── README.md
│   │
│   ├── services/
│   │   ├── user-service/
│   │   │   ├── pyproject.toml           (Service - UV workspace member)
│   │   │   ├── src/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── app.py               (Service Zephyr app - SERVICE MODE)
│   │   │   │   ├── main.py              (Entry point)
│   │   │   │   ├── handlers/
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   └── users.py
│   │   │   │   ├── models/
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   └── user.py
│   │   │   │   └── config/
│   │   │   │       └── settings.py
│   │   │   ├── Dockerfile
│   │   │   └── README.md
│   │   │
│   │   ├── order-service/
│   │   │   ├── pyproject.toml           (Service - UV workspace member)
│   │   │   ├── src/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── app.py
│   │   │   │   ├── main.py
│   │   │   │   ├── handlers/
│   │   │   │   ├── models/
│   │   │   │   └── config/
│   │   │   ├── Dockerfile
│   │   │   └── README.md
│   │   │
│   │   └── payment-service/
│   │       ├── pyproject.toml           (Service - UV workspace member)
│   │       ├── src/
│   │       │   ├── __init__.py
│   │       │   ├── app.py
│   │       │   ├── main.py
│   │       │   ├── handlers/
│   │       │   ├── models/
│   │       │   └── config/
│   │       ├── Dockerfile
│   │       └── README.md
│   │
│   ├── config/
│   │   ├── zephyr-services.yml          (Microservices configuration)
│   │   ├── zephyr-mesh.yml              (Service mesh config)
│   │   └── zephyr-monitoring.yml        (Monitoring config)
│   │
│   └── docker-compose.yml               (Multi-service dev environment)
│
├── docker/
│   ├── Dockerfile.base                  (Base image for all services)
│   ├── docker-compose.monolith.yml      (Monolith mode - single container)
│   └── docker-compose.services.yml      (Microservices mode - multiple containers)
│
└── tools/
    ├── scripts/
    │   ├── setup.sh
    │   └── build-all.sh
    └── README.md
```

---

## 📋 UV WORKSPACE CONFIGURATION

### **Root pyproject.toml** (UV Workspace Config - NO requirements.txt)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "zephyr-project"
version = "1.0.0"
description = "Zephyr Microservices Platform"
requires-python = ">=3.11"

[tool.uv]
# UV workspace members
workspace = [
    { path = "core" },
    { path = "app" },                               # Monolith mode
    { path = "orchestrator" },                      # Microservices mode
    { path = "services/user-service" },             # Microservices mode
    { path = "services/order-service" },            # Microservices mode
    { path = "services/payment-service" },          # Microservices mode
]

[tool.uv.sources]
zephyr = { workspace = true }
core = { workspace = true }
```

---

### **Shared Core - core/pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "core"
version = "1.0.0"
description = "Zephyr Shared Core Libraries"
requires-python = ">=3.11"
dependencies = [
    "pydantic>=2.11.2",
    "structlog>=24.1.0",
    "sqlalchemy>=2.0.0",
    "cryptography>=41.0.0",
]

[tool.uv]
workspace-dependencies = true
```

---

### **Monolith Mode - app/pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "zephyr-monolith"
version = "1.0.0"
description = "Zephyr Monolith Application"
requires-python = ">=3.11"
dependencies = [
    "zephyr-py>=0.1.0",
    "core",                                         # Include shared core
    "pydantic>=2.11.2",
    "structlog>=24.1.0",
    "redis>=5.0.0",
    "sqlalchemy>=2.0.0",
]

[tool.uv]
workspace-dependencies = true

[tool.uv.sources]
zephyr-py = { index = "pypi" }
```

---

### **Orchestrator - orchestrator/pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "zephyr-orchestrator"
version = "1.0.0"
description = "Zephyr Orchestrator Control Plane"
requires-python = ">=3.11"
dependencies = [
    "zephyr-py>=0.1.0",
    "core",                                         # Include shared core
    "pydantic>=2.11.2",
    "structlog>=24.1.0",
    "docker>=6.0.0",                                # Docker API
    "redis>=5.0.0",
    "sqlalchemy>=2.0.0",
]

[tool.uv]
workspace-dependencies = true

[tool.uv.sources]
zephyr-py = { index = "pypi" }
```

---

### **Service - services/user-service/pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "user-service"
version = "1.0.0"
description = "Zephyr User Microservice"
requires-python = ">=3.11"
dependencies = [
    "zephyr-py>=0.1.0",
    "core",                                         # Include shared core
    "pydantic>=2.11.2",
    "structlog>=24.1.0",
    "sqlalchemy>=2.0.0",
    "redis>=5.0.0",
]

[tool.uv]
workspace-dependencies = true

[tool.uv.sources]
zephyr-py = { index = "pypi" }
```

---

### **Service - services/order-service/pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "order-service"
version = "1.0.0"
description = "Zephyr Order Microservice"
requires-python = ">=3.11"
dependencies = [
    "zephyr-py>=0.1.0",
    "core",                                         # Include shared core
    "pydantic>=2.11.2",
    "structlog>=24.1.0",
    "sqlalchemy>=2.0.0",
    "redis>=5.0.0",
]

[tool.uv]
workspace-dependencies = true

[tool.uv.sources]
zephyr-py = { index = "pypi" }
```

---

### **Service - services/payment-service/pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "payment-service"
version = "1.0.0"
description = "Zephyr Payment Microservice"
requires-python = ">=3.11"
dependencies = [
    "zephyr-py>=0.1.0",
    "core",                                         # Include shared core
    "pydantic>=2.11.2",
    "structlog>=24.1.0",
    "sqlalchemy>=2.0.0",
    "redis>=5.0.0",
]

[tool.uv]
workspace-dependencies = true

[tool.uv.sources]
zephyr-py = { index = "pypi" }
```

---

## 🚀 UV COMMANDS (No requirements.txt!)

```bash
# Install all workspace dependencies
uv sync

# Install specific workspace member
uv sync --package core
uv sync --package app
uv sync --package orchestrator
uv sync --package user-service

# Add dependency to specific package
uv add -p core pydantic@latest
uv add -p app redis@latest
uv add -p orchestrator docker@latest

# Update all dependencies
uv lock --upgrade

# Run command in workspace
uv run -p app python -m app.main
uv run -p orchestrator python -m orchestrator.main
uv run -p user-service python -m user_service.main

# Remove dependency
uv remove -p app redis
```

---

## 🔍 MODE DIFFERENTIATION

### **MODE 1: MONOLITH**

**File: app/src/app.py**
```python
from zephyr import Zephyr

# MONOLITH MODE - All routes in one app
app = Zephyr(
    title="My Application",
    version="1.0.0",
    mode="monolith"  # ← IDENTIFIER
)

# All routes here
@app.get("/users")
async def list_users():
    return []

@app.get("/orders")
async def list_orders():
    return []

@app.get("/payments")
async def list_payments():
    return []

@app.get("/health")
async def health():
    return {"status": "ok", "mode": "monolith"}
```

---

### **MODE 2A: ORCHESTRATOR**

**File: orchestrator/src/app.py**
```python
from zephyr import Zephyr
from zephyr.orchestrator import ServiceManager

# ORCHESTRATOR MODE - Control plane
app = Zephyr(
    title="Zephyr Orchestrator",
    version="1.0.0",
    mode="orchestrator"  # ← IDENTIFIER
)

# Service manager
service_manager = ServiceManager(app)

# Orchestrator-only endpoints
@app.get("/services")
async def list_services():
    return await service_manager.list_services()

@app.post("/services/{name}/start")
async def start_service(name: str):
    return await service_manager.start_service(name)

@app.post("/services/{name}/stop")
async def stop_service(name: str):
    return await service_manager.stop_service(name)

@app.get("/orchestrator/status")
async def status():
    return {"status": "running", "mode": "orchestrator"}
```

---

### **MODE 2B: INDIVIDUAL SERVICE**

**File: services/user-service/src/app.py**
```python
from zephyr import Zephyr
from core.base_service import BaseService

# SERVICE MODE - Individual microservice
app = Zephyr(
    title="User Service",
    version="1.0.0",
    mode="service"  # ← IDENTIFIER
)

# Service-specific routes ONLY
@app.get("/users")
async def list_users():
    return []

@app.post("/users")
async def create_user(user: dict):
    return user

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "mode": "service",
        "service": "user-service"
    }
```

---

## 📊 DEPLOYMENT COMPARISON

| Aspect | Monolith | Orchestrator | Service |
|--------|----------|--------------|---------|
| **Mode** | `mode="monolith"` | `mode="orchestrator"` | `mode="service"` |
| **Containers** | 1 | 1 (+ services) | Multiple |
| **Port** | 8000 | 9090 | 8001, 8002, 8003 |
| **Entry** | `app/src/main.py` | `orchestrator/src/main.py` | `services/*/src/main.py` |
| **Package** | `uv sync -p app` | `uv sync -p orchestrator` | `uv sync -p user-service` |
| **Routes** | All endpoints | Service management | One service only |

---

## 🐳 DOCKERFILE (Using UV)

### **Dockerfile for All Services**

```dockerfile
FROM python:3.11-slim

# Install uv
COPY --from=ghcr.io/astral-sh/uv:latest /uv /uvx /bin/

WORKDIR /app

# Copy workspace files
COPY pyproject.toml uv.lock ./

# Copy shared core (if exists)
COPY core/ ./core/

# Copy app/service files (build arg determines which)
ARG SERVICE_PATH=app
COPY ${SERVICE_PATH}/ ./${SERVICE_PATH}/

# Install dependencies with uv
RUN uv sync --frozen --no-dev

# Run the service
ARG SERVICE_MODULE=app.main
ENTRYPOINT ["uv", "run", "-p", "${SERVICE_PATH}", "python", "-m", "${SERVICE_MODULE}"]
```

---

## 🐳 DOCKER COMPOSE - MONOLITH MODE

**File: docker-compose.monolith.yml**

```yaml
version: '3.9'

services:
  app:
    build:
      context: .
      dockerfile: docker/Dockerfile
      args:
        SERVICE_PATH: app
        SERVICE_MODULE: app.main
    ports:
      - "8000:8000"
    environment:
      - ZEPHYR_MODE=monolith
      - LOG_LEVEL=info
    volumes:
      - ./app:/app/app
```

---

## 🐳 DOCKER COMPOSE - MICROSERVICES MODE

**File: docker-compose.services.yml**

```yaml
version: '3.9'

services:
  orchestrator:
    build:
      context: .
      dockerfile: docker/Dockerfile
      args:
        SERVICE_PATH: orchestrator
        SERVICE_MODULE: orchestrator.main
    ports:
      - "9090:9090"
    environment:
      - ZEPHYR_MODE=orchestrator
      - LOG_LEVEL=info

  user-service:
    build:
      context: .
      dockerfile: docker/Dockerfile
      args:
        SERVICE_PATH: services/user-service
        SERVICE_MODULE: user_service.main
    ports:
      - "8001:8001"
    environment:
      - ZEPHYR_MODE=service
      - SERVICE_NAME=user-service
      - LOG_LEVEL=info
    depends_on:
      - orchestrator

  order-service:
    build:
      context: .
      dockerfile: docker/Dockerfile
      args:
        SERVICE_PATH: services/order-service
        SERVICE_MODULE: order_service.main
    ports:
      - "8002:8002"
    environment:
      - ZEPHYR_MODE=service
      - SERVICE_NAME=order-service
      - LOG_LEVEL=info
    depends_on:
      - orchestrator

  payment-service:
    build:
      context: .
      dockerfile: docker/Dockerfile
      args:
        SERVICE_PATH: services/payment-service
        SERVICE_MODULE: payment_service.main
    ports:
      - "8003:8003"
    environment:
      - ZEPHYR_MODE=service
      - SERVICE_NAME=payment-service
      - LOG_LEVEL=info
    depends_on:
      - orchestrator
```

---

## 🚀 RUNNING APPLICATIONS

### **Run as Monolith**

```bash
# Install dependencies
uv sync

# Run monolith app
uv run -p app python -m app.main

# Via Docker
docker-compose -f docker-compose.monolith.yml up

# Endpoints:
# - http://localhost:8000/users
# - http://localhost:8000/orders
# - http://localhost:8000/payments
# - http://localhost:8000/health
```

---

### **Run as Microservices**

```bash
# Install all workspace dependencies
uv sync

# Run orchestrator
uv run -p orchestrator python -m orchestrator.main

# Run services (in separate terminals)
uv run -p user-service python -m user_service.main
uv run -p order-service python -m order_service.main
uv run -p payment-service python -m payment_service.main

# OR via Docker Compose
docker-compose -f docker-compose.services.yml up

# Endpoints:
# Orchestrator:   http://localhost:9090/services
# User Service:   http://localhost:8001/users
# Order Service:  http://localhost:8002/orders
# Payment Service: http://localhost:8003/payments
```

---

## ✅ KEY POINTS

- ✅ **UV only** - No requirements.txt files
- ✅ **Workspace** - All packages in one repo
- ✅ **Shared core** - Common code in `core/` package
- ✅ **Monolith mode** - Single container deployment
- ✅ **Microservices mode** - Multiple independent containers
- ✅ **Mode differentiation** - Via `mode="..."` parameter
- ✅ **UV sync** - Auto-manages all dependencies
- ✅ **Same pyproject.toml format** - For all packages
- ✅ **Docker-native** - Builds work with UV
- ✅ **Development-friendly** - `uv sync` gets everything

---

## 📝 NEXT STEPS

1. ✅ Create monorepo structure with UV
2. ✅ Define shared core package
3. ✅ Build monolith version (simple)
4. ✅ Build microservices version (orchestrator + services)
5. ✅ Test both modes
6. ✅ Add service discovery and messaging
7. ✅ Add observability (metrics, logging, tracing)

**Total estimate for Phase 3: 4-6 weeks** 🚀


