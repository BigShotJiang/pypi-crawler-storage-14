#!/usr/bin/env python3
"""Test server to verify OpenAPI documentation endpoints."""

from zephyr import Zephyr

app = Zephyr(
    title="EDUORAA Backend API",
    version="1.0.0",
    description="Learning Management System Backend",
    debug=True,
)


@app.get("/")
async def root() -> dict:
    """Welcome endpoint."""
    return {
        "message": "Welcome to EDUORAA Backend",
        "version": "1.0.0",
    }


@app.get("/health")
async def health_check() -> dict:
    """Health check endpoint."""
    return {"status": "healthy"}


@app.get("/api/users/me")
async def get_current_user() -> dict:
    """Get current user info."""
    return {
        "id": "user-123",
        "username": "john_doe",
        "email": "john@example.com",
    }


@app.get("/api/courses")
async def list_courses() -> dict:
    """List all courses."""
    return {
        "courses": [
            {"id": 1, "name": "Python Basics", "instructor": "Alice"},
            {"id": 2, "name": "Web Development", "instructor": "Bob"},
        ],
    }


@app.post("/api/courses")
async def create_course() -> dict:
    """Create a new course."""
    return {
        "id": 3,
        "name": "New Course",
        "instructor": "Charlie",
        "created": True,
    }


if __name__ == "__main__":
    print("🚀 Starting EDUORAA Backend Test Server...")
    print("\n📚 Documentation URLs:")
    print("  - Swagger UI: http://localhost:8000/docs")
    print("  - ReDoc: http://localhost:8000/redoc")
    print("  - OpenAPI JSON: http://localhost:8000/openapi.json")
    print("\n")
    app.run(host="127.0.0.1", port=8000)
