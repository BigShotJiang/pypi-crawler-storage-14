# Zephyr Framework Documentation

**Version:** 0.1.0.dev2  
**Author:** A M (am@bbdevs.com)  
**Created:** October 2, 2025

---

## Overview

Zephyr is a modern, high-performance Python ASGI web framework with enterprise-grade capabilities. It provides a comprehensive suite of features including JWT authentication, Role-Based Access Control (RBAC), rate limiting, advanced caching, WebSocket support, and a production-ready ORM layer.

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Core Features](#core-features)
3. [Security Module](#security-module)
4. [Caching System](#caching-system)
5. [Database ORM](#database-orm)
6. [Task System](#task-system)
7. [Middleware](#middleware)
8. [Configuration](#configuration)
9. [Logging](#logging)
10. [Changelog](#changelog)

---

## Quick Start

### Installation

```bash
pip install zephyr-py
```

### Basic Application

```python
from zephyr import Zephyr

app = Zephyr(title="My API", version="1.0.0")

@app.get("/")
async def hello():
    return {"message": "Hello from Zephyr!"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
```

### Using ZServer (Built-in Server)

```python
from zephyr import Zephyr
from zephyr.core.zserver.config import ServerConfig
from zephyr.core.zserver.server import Server

app = Zephyr()

@app.get("/")
async def hello():
    return {"message": "Hello World"}

server_config = ServerConfig(app, host="0.0.0.0", port=8000)
server = Server(server_config)
server.run()
```

---

## Core Features

### Route Decorators

Zephyr supports all standard HTTP methods:

```python
from zephyr import Zephyr

app = Zephyr()

@app.get("/users")
async def list_users():
    return {"users": []}

@app.post("/users")
async def create_user():
    return {"id": 1, "created": True}

@app.put("/users/{user_id}")
async def update_user(user_id: int):
    return {"id": user_id, "updated": True}

@app.delete("/users/{user_id}")
async def delete_user(user_id: int):
    return {"deleted": True}
```

### WebSocket Support

```python
from zephyr import Zephyr
from zephyr.app.websockets import WebSocketDisconnect

app = Zephyr()

connected_clients = set()

@app.websocket("/ws")
async def websocket_endpoint(websocket):
    await websocket.accept()
    connected_clients.add(websocket)
    
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_text(f"Echo: {data}")
            
            # Broadcast to all clients
            for client in connected_clients:
                if client != websocket:
                    await client.send_text(f"Broadcast: {data}")
    except WebSocketDisconnect:
        connected_clients.discard(websocket)

@app.websocket("/chat")
async def chat_endpoint(websocket):
    await websocket.accept()
    
    await websocket.send_json({
        "type": "connection",
        "message": "Connected successfully"
    })
    
    while True:
        message = await websocket.receive_json()
        await websocket.send_json({"echo": message})
```

### Lifecycle Hooks

```python
from zephyr import Zephyr

app = Zephyr()

@app.register_hook("after_startup")
async def startup():
    app.logger.info("Application starting up...")

@app.register_hook("before_shutdown")
async def shutdown():
    app.logger.info("Application shutting down...")

# Legacy event-style (backward compatible)
@app.on_event("startup")
async def on_startup():
    pass
```

### Router Composition

```python
from zephyr import Zephyr
from zephyr.app.routing import Router

app = Zephyr()
api_router = Router()

@api_router.get("/users")
async def list_users():
    return {"users": []}

@api_router.get("/products")
async def list_products():
    return {"products": []}

# Include router with prefix
app.include_router(api_router, prefix="/api/v1")
# Routes available at /api/v1/users and /api/v1/products
```

### Exception Handlers

```python
from zephyr import Zephyr
from zephyr.app.responses import JSONResponse

app = Zephyr()

@app.exception_handler(ValueError)
async def handle_value_error(request, exc):
    return JSONResponse(
        {"error": str(exc)},
        status_code=400
    )

# Or programmatically
app.add_exception_handler(404, custom_404_handler)
```

### OpenAPI Documentation

Zephyr auto-generates OpenAPI 3.1.0 documentation:

- `/openapi.json` - OpenAPI schema
- `/docs` - Swagger UI
- `/redoc` - ReDoc interface

---

## Security Module

### JWT Authentication

```python
from zephyr.security import JWTManager, JWTConfig

config = JWTConfig(
    secret_key="your-secret-key",
    algorithm="HS256",
    access_token_expire_minutes=15,
    refresh_token_expire_days=7,
    issuer="my-app",
    audience="my-users"
)

jwt_manager = JWTManager(config)

# Create tokens
access_token = await jwt_manager.create_access_token(
    user_id="user-123",
    scope=["read", "write"],
    extra_claims={"role": "admin"}
)

refresh_token = await jwt_manager.create_refresh_token(user_id="user-123")

# Verify token
payload = await jwt_manager.verify_token(access_token, token_type="access")
print(payload.sub)  # user-123
print(payload.scope)  # ["read", "write"]

# Refresh tokens
new_access, new_refresh = await jwt_manager.refresh_access_token(refresh_token)
```

### Password Hashing

```python
from zephyr.security import PasswordHasher

hasher = PasswordHasher()

# Hash password (bcrypt with 12 rounds)
hashed = await hasher.hash_password("my-secure-password")

# Verify password (constant-time comparison)
is_valid = await hasher.verify_password("my-secure-password", hashed)

# Check if rehash needed (algorithm upgrade)
needs_update = await hasher.needs_rehash(hashed)
```

### Role-Based Access Control (RBAC)

```python
from zephyr.security.rbac import (
    RBACManager, RBACConfig, Role, Permission, 
    Policy, PolicyRule, Effect, Action, Resource
)

# Configure RBAC
config = RBACConfig()
rbac = RBACManager(config)

# Define roles
admin_role = Role(
    id="admin",
    name="Administrator",
    permissions=["users:read", "users:write", "users:delete"]
)

user_role = Role(
    id="user",
    name="User",
    permissions=["users:read"]
)

await rbac.add_role(admin_role)
await rbac.add_role(user_role)

# Check permissions
has_access = await rbac.check_permission(
    user_id="user-123",
    permission="users:write"
)
```

### OAuth2 Server

```python
from zephyr.security.oauth2 import (
    OAuth2Server, OAuth2Config, OAuth2Client,
    AuthorizationCodeFlow, ClientCredentialsFlow, PKCEFlow
)

config = OAuth2Config(
    authorization_endpoint="/oauth/authorize",
    token_endpoint="/oauth/token",
    access_token_expire_seconds=3600
)

oauth2_server = OAuth2Server(config)

# Register client
client = OAuth2Client(
    client_id="my-client",
    client_secret="client-secret",
    redirect_uris=["https://app.example.com/callback"],
    grant_types=["authorization_code", "refresh_token"],
    scopes=["openid", "profile", "email"]
)

await oauth2_server.register_client(client)
```

### Single Sign-On (SSO)

```python
from zephyr.security.sso import (
    SSOManager, SSOConfig,
    GoogleSSOProvider, GitHubSSOProvider, 
    MicrosoftSSOProvider, AppleSSOProvider
)

config = SSOConfig()
sso = SSOManager(config)

# Register providers
google = GoogleSSOProvider(
    client_id="google-client-id",
    client_secret="google-secret",
    redirect_uri="https://app.example.com/auth/google/callback"
)

github = GitHubSSOProvider(
    client_id="github-client-id",
    client_secret="github-secret",
    redirect_uri="https://app.example.com/auth/github/callback"
)

await sso.register_provider("google", google)
await sso.register_provider("github", github)

# Get authorization URL
auth_url = await sso.get_authorization_url("google", state="random-state")

# Handle callback
user_info = await sso.handle_callback("google", code="auth-code")
```

### Keycloak Integration

```python
from zephyr.security.keycloak import (
    KeycloakClient, KeycloakConfig, KeycloakAdmin
)

config = KeycloakConfig(
    server_url="https://keycloak.example.com",
    realm="my-realm",
    client_id="my-client",
    client_secret="client-secret"
)

client = KeycloakClient(config)

# Authenticate user
token = await client.authenticate("username", "password")

# Validate token
user_info = await client.get_user_info(token.access_token)

# Admin operations
admin = KeycloakAdmin(config)
users = await admin.list_users()
```

---

## Caching System

### Multi-Backend Caching

```python
from zephyr.core.cache import (
    CacheManager, MemoryCacheBackend, 
    MultiLevelCacheBackend
)

# Memory backend (default)
cache = CacheManager()

# Set/Get values
await cache.set("user:123", {"name": "John"}, ttl=3600)
user = await cache.get("user:123")

# Delete
await cache.delete("user:123")

# Multi-level cache (Memory + Redis)
l1 = MemoryCacheBackend(max_size=1000)
l2 = RedisCacheBackend(redis_url="redis://localhost:6379")
multi_cache = MultiLevelCacheBackend(backends=[l1, l2])
```

### Cache Decorators

```python
from zephyr.core.cache import cache, cache_with_tags, invalidate_cache

@cache(ttl=3600)
async def get_user(user_id: int) -> dict:
    # Expensive database query
    return await db.fetch_user(user_id)

@cache_with_tags(ttl=3600, tags=["users", "profiles"])
async def get_user_profile(user_id: int) -> dict:
    return await db.fetch_profile(user_id)

# Invalidate by tags
await invalidate_cache(tags=["users"])
```

---

## Database ORM

### Backend-Agnostic ORM Layer

```python
from zephyr.db import (
    Base, BaseModel, ConnectionManager, 
    Session, QueryBuilder, TransactionManager
)
from sqlalchemy import Column, String, Integer

# Define models
class User(BaseModel):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True)

# Connection management
connection_manager = ConnectionManager()
await connection_manager.connect("postgresql://user:pass@localhost/db")

# Session management
async with Session() as session:
    user = User(name="John", email="john@example.com")
    session.add(user)
    await session.commit()

# Query builder
query = QueryBuilder(User)
users = await query.filter(User.name == "John").all()
```

### Transactions

```python
from zephyr.db import TransactionManager, Session

async with TransactionManager() as tx:
    async with Session() as session:
        user = User(name="Jane")
        session.add(user)
        
        # Nested transaction (savepoint)
        async with tx.savepoint():
            profile = Profile(user_id=user.id)
            session.add(profile)
```

### Health Checks

```python
from zephyr.db import HealthChecker, HealthStatus

checker = HealthChecker(connection_manager)
status: HealthStatus = await checker.check()

print(status.is_healthy)
print(status.latency_ms)
print(status.details)
```

---

## Task System

### Task Registration and Execution

```python
from zephyr.core.tasks import TaskManager, task, periodic_task

# Register task with decorator
@task(name="process_data", retry=3, timeout=30)
async def process_data(user_id: int) -> dict:
    return {"user_id": user_id, "status": "done"}

# Periodic task
@periodic_task(interval=60)  # Run every 60 seconds
async def cleanup_expired_sessions():
    await session_store.cleanup()

# Initialize manager
manager = TaskManager.configure()
await manager.initialize()

# Submit task
task_id = await manager.submit("process_data", user_id=123)

# Get result
result = await manager.get_result(task_id, wait=True)
```

### Backend Support

- **In-process**: Async and sync task execution
- **Celery**: Distributed task queue
- **RQ (Redis Queue)**: Simple Redis-based queue

---

## Middleware

### Built-in Middleware

Zephyr includes several middleware components that are auto-configured:

```python
from zephyr import Zephyr

app = Zephyr()

# Middleware is auto-enabled based on settings:
# - RequestIDMiddleware (ENABLE_REQUEST_ID=True)
# - RateLimitMiddleware (ENABLE_RATE_LIMITING=True)
# - CompressionMiddleware (ENABLE_COMPRESSION=True)
# - CacheMiddleware (ENABLE_CACHING=True)
# - MetricsMiddleware (ENABLE_METRICS=True)
# - TracingMiddleware (ENABLE_TRACING=True)
```

### Rate Limiting

```python
from zephyr.app.middleware.rate_limit import RateLimitMiddleware
from zephyr.app.middleware.redis_rate_limit import RedisRateLimitMiddleware

# In-memory rate limiting
app.add_middleware(RateLimitMiddleware, requests=1000, window=60)

# Redis-backed distributed rate limiting
app.add_middleware(
    RedisRateLimitMiddleware,
    redis_url="redis://localhost:6379",
    requests=1000,
    window=60
)
```

### CORS

```python
from zephyr import Zephyr

app = Zephyr()

app.use_cors(
    allow_origins=["https://example.com"],
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
    allow_credentials=True
)
```

### Custom Middleware

```python
from zephyr.app.middleware.base import BaseMiddleware

class CustomMiddleware(BaseMiddleware):
    async def __call__(self, scope, receive, send):
        # Pre-processing
        print("Before request")
        
        await self.app(scope, receive, send)
        
        # Post-processing
        print("After request")

app.add_middleware(CustomMiddleware)
```

---

## Configuration

### Settings Management

```python
# settings.py
from zephyr.conf import BaseSettings

class Settings(BaseSettings):
    DEBUG = True
    ENABLE_CORS = True
    ENABLE_RATE_LIMITING = True
    RATE_LIMIT_REQUESTS = 1000
    RATE_LIMIT_WINDOW = 60
    
    # Database
    DATABASE_URL = "postgresql://user:pass@localhost/db"
    
    # Security
    JWT_SECRET_KEY = "your-secret-key"
    JWT_ALGORITHM = "HS256"
```

```python
# app.py
from zephyr import Zephyr
from zephyr.conf import settings

settings.configure(settings_module="myproject.settings")
app = Zephyr()
```

### Environment Variables

Settings can be loaded from `.env` files:

```env
DEBUG=true
DATABASE_URL=postgresql://user:pass@localhost/db
JWT_SECRET_KEY=your-secret-key
```

---

## Logging

### Structured Logging

```python
from zephyr.core.logging import get_logger, Logger

# Get logger instance
logger = get_logger("my-app")

# Structured logging
logger.info("User logged in", user_id="123", ip="192.168.1.1")
logger.error("Database error", error=str(exc), query=sql)
logger.warning("Rate limit exceeded", client_ip=ip, requests=count)
```

### Configuration

```python
from zephyr.core.logging import (
    LoggingConfig, LogLevel, LogFormat,
    ConsoleHandlerConfig, FileHandlerConfig
)

config = LoggingConfig(
    level=LogLevel.INFO,
    format=LogFormat.JSON,
    handlers=[
        ConsoleHandlerConfig(enabled=True),
        FileHandlerConfig(
            enabled=True,
            path="/var/log/app.log",
            max_bytes=10_000_000,
            backup_count=5
        )
    ]
)
```

---

## Changelog

### v0.1.0.dev2 (2025-11-22)

#### Features
- **Database ORM** (`feat(db)`): Complete production ORM layer with backend-agnostic abstraction
  - Session management
  - Query builder
  - Transaction support
  - Relationship management
  - Health checks
  
- **Caching System** (`feat(cache)`): Multi-backend caching implementation
  - Memory backend
  - Redis backend
  - Multi-level cache
  - Cache decorators (`@cache`, `@cache_with_tags`)
  
- **Rate Limiting** (`feat(rate-limit)`): Redis-backed distributed rate limiting
  - In-memory rate limiting
  - Redis-backed distributed limiting
  - Configurable windows and limits

#### Security
- **OAuth2 Server**: Complete OAuth2 authorization server
  - Authorization Code flow
  - Client Credentials flow
  - PKCE support
  - Device flow
  
- **SSO Integration**: Single Sign-On with major providers
  - Google, GitHub, Microsoft, Apple
  - SAML support
  - Generic OAuth2 provider
  
- **Keycloak Integration**: Full Keycloak support
  - Authentication
  - Admin API
  - SSO provider

#### Fixes
- `fix(oauth2,keycloak)`: Fixed all linting errors
- `fix(sso)`: Replaced generic types with KWARGS/ALL
- `fix`: Replaced `datetime.utcnow()` with timezone-aware `datetime.now(timezone.utc)`
- `fix`: Resolved circular import in routing.py
- `fix`: Resolved F821 undefined name errors

---

### v0.1.0.dev1 (2025-11-18)

#### Features
- **OpenAPI Documentation**: Auto-generated OpenAPI 3.1.0 schemas
  - Swagger UI at `/docs`
  - ReDoc at `/redoc`
  
- **Logging Module**: Comprehensive structured logging
  - Multiple handlers (Console, File, Loki, Syslog)
  - JSON and text formats
  - Context management
  
- **WebSocket Support**: Full WebSocket implementation
  - Text and JSON messaging
  - Connection management
  - Broadcasting

- **Middleware System**: Extensible middleware
  - CORS, Rate Limiting, Compression
  - Request ID, Metrics, Tracing
  - Security Headers

- **Configuration Management**: Environment-based settings
  - BaseSettings class
  - .env file support
  - Lazy loading

#### Infrastructure
- `chore`: Added examples and development tools
- `chore`: Bumped version to 0.1.0.dev2
- `test`: Added test infrastructure and initial tests

---

### v0.1.0.dev0 (2025-10-25)

#### Initial Release
- **Core Framework**: ASGI web framework foundation
  - Route decorators (GET, POST, PUT, DELETE)
  - Request/Response handling
  - Router composition
  
- **CORS Middleware**: Cross-Origin Resource Sharing support

- **ZServer**: Built-in ASGI server
  - HTTP/1.1 support
  - WebSocket protocol
  - Lifespan management

---

## Commit History

| Date | Commit | Description |
|------|--------|-------------|
| 2025-11-22 | `5b5222f` | fix(oauth2,keycloak): fix all linting errors |
| 2025-11-22 | `eb18103` | Fix ALL ruff linting issues: Replace Any/Union with modern type hints |
| 2025-11-21 | `9c59b89` | feat(db): Complete production ORM layer with all tasks |
| 2025-11-21 | `584523a` | feat(db): Backend-agnostic ORM abstraction |
| 2025-11-20 | `aa9fb08` | feat(rate-limit): implement redis-backed distributed rate limiting |
| 2025-11-20 | `fc94f60` | test(cache): add comprehensive test suite for caching system |
| 2025-11-20 | `8d340e5` | feat(cache): implement multi-backend caching system |
| 2025-11-18 | `38d0e88` | fix: add missing timezone imports to security modules |
| 2025-11-18 | `1a33017` | test: add test infrastructure and initial tests |
| 2025-11-18 | `5208827` | feat: add advanced security and caching modules |
| 2025-11-18 | `3c70f66` | feat: update zserver and core components |
| 2025-11-18 | `3a6c3fb` | feat: add new middleware and enhance existing ones |
| 2025-11-18 | `dd0fae9` | feat: enhance OpenAPI schema generation |
| 2025-11-14 | `b26ed98` | New: OPENAPI DOCS addition |
| 2025-11-14 | `180ceac` | New: Logging Module impl |
| 2025-11-13 | `97089ea` | New: WS Support for ZEPHYR |
| 2025-10-25 | `5a1ccc7` | New: Middlewares support |
| 2025-10-08 | `b0ee789` | New: Zephyr Cors Middleware |
| 2025-10-08 | `16e2b82` | New: LDAP Backend Support |
| 2025-08-26 | `af20516` | Zephyr Framework (Initial commit) |

---

## Architecture

```mermaid
graph TB
    subgraph "Zephyr Framework"
        App[Zephyr Application]
        
        subgraph "Core"
            Router[Router]
            Middleware[Middleware Stack]
            Server[ZServer]
        end
        
        subgraph "Security"
            JWT[JWT Manager]
            RBAC[RBAC Engine]
            OAuth2[OAuth2 Server]
            SSO[SSO Manager]
            Password[Password Hasher]
        end
        
        subgraph "Data Layer"
            Cache[Cache Manager]
            DB[Database ORM]
            Tasks[Task Manager]
        end
        
        subgraph "Observability"
            Logging[Structured Logging]
            Metrics[Metrics]
            Tracing[Distributed Tracing]
        end
    end
    
    App --> Router
    App --> Middleware
    Router --> Server
    
    Middleware --> JWT
    Middleware --> RBAC
    
    App --> Cache
    App --> DB
    App --> Tasks
    
    App --> Logging
    Middleware --> Metrics
    Middleware --> Tracing
```

---

## License

MIT License - See [LICENSE](LICENSE) for details.



