# Task/Queue Core System - Development Plan

**Version:** 1.0.0  
**Author:** A M (am@bbdevs.com)  
**Created:** November 2025  
**Status:** Planning Phase

---

## Overview

A unified, progressive task execution system for Zephyr framework that scales from simple in-process async tasks to distributed worker architectures. This system provides a foundation for storage transfers, background jobs, and other async operations.

## Design Principles

1. **Zero-config default** - Works immediately without setup
2. **Progressive complexity** - Add features only when needed
3. **Unified API** - Same interface regardless of backend
4. **App-attached** - Access via `app.tasks`
5. **Cancellable** - Graceful stop/kill support
6. **100% test coverage** - All edge cases covered

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         app.tasks                               │
├─────────────────────────────────────────────────────────────────┤
│                      TaskManager (Facade)                        │
│  - submit(), run(), background()                                │
│  - get(), list(), stop(), kill()                                │
├─────────────────────────────────────────────────────────────────┤
│                    Execution Backends                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌───────────────────┐  │
│  │  Async   │ │  Thread  │ │ Process  │ │    Distributed    │  │
│  │  Runner  │ │   Pool   │ │   Pool   │ │  (Celery/ARQ/RQ)  │  │
│  └──────────┘ └──────────┘ └──────────┘ └───────────────────┘  │
├─────────────────────────────────────────────────────────────────┤
│  Result Store (Memory/Redis)  │  State Store (Memory/Redis)    │
└─────────────────────────────────────────────────────────────────┘
```

---

## Development Phases

### Phase 1: Core Refactoring & App Integration (Week 1)
**Goal:** Simplify API, attach to app, zero-config default

| Task ID | Description | Hours | Test Coverage |
|---------|-------------|-------|---------------|
| 1.1 | Add `tasks` property to Zephyr app (lazy init) | 2 | Property access, lazy init, multiple calls |
| 1.2 | Add `@app.task` decorator with options | 3 | Decorator with/without args, async/sync, metadata |
| 1.3 | Implement `app.tasks.background()` fire-and-forget | 2 | Background execution, no tracking, error handling |
| 1.4 | Simplify `submit()` / `run()` / `get()` API | 4 | All combinations, error cases, timeout |
| 1.5 | Auto-initialize with memory backend | 2 | Auto-init, no config needed, fallback |
| 1.6 | Update existing tests for new API | 3 | All existing tests pass, new patterns |
| 1.7 | Add integration tests for app.tasks | 3 | Full workflow, edge cases, error paths |
| **Total** | | **19 hours** | **100% coverage** |

**Deliverables:**
- `app.tasks` property on Zephyr class
- Zero-config default (memory backend)
- Simplified API matching design spec
- All tests passing with 100% coverage

**API After Phase 1:**
```python
app = Zephyr()

@app.task
async def my_task(x: int) -> int:
    return x * 2

# Fire and forget
app.tasks.background(my_task, 5)

# With tracking
task_id = await app.tasks.submit(my_task, 5)
result = await app.tasks.get(task_id)
```

**Commit Points:**
- After 1.1-1.2: `feat(tasks): add app.tasks property and decorator`
- After 1.3-1.5: `feat(tasks): add background() and auto-init`
- After 1.6-1.7: `test(tasks): update tests for new API`

**Edge Cases to Test:**
- Multiple simultaneous task submissions
- Task submission before app initialization
- Decorator on sync/async functions
- Invalid task names/IDs
- Memory backend failures
- Concurrent access to task manager

---

### Phase 2: Cancellation Support (Week 1-2)
**Goal:** Add stop/kill with graceful cleanup

| Task ID | Description | Hours | Test Coverage |
|---------|-------------|-------|---------------|
| 2.1 | Implement `CancellationToken` class | 3 | Token creation, cancel, check, async wait |
| 2.2 | Add `cancellable=True` decorator option | 2 | Decorator option, token injection, default |
| 2.3 | Implement `stop()` with timeout | 4 | Graceful stop, timeout handling, cleanup |
| 2.4 | Implement `kill()` force terminate | 3 | Force kill, immediate termination, cleanup |
| 2.5 | Add STOPPING/CANCELLED states | 2 | State transitions, state persistence |
| 2.6 | Implement `stop_all()` / `kill_all()` | 3 | Bulk operations, partial success, errors |
| 2.7 | Add `shutdown()` for graceful app shutdown | 2 | Shutdown sequence, wait timeout, cleanup |
| 2.8 | Tests for cancellation (all backends) | 5 | All backends, edge cases, race conditions |
| **Total** | | **24 hours** | **100% coverage** |

**Deliverables:**
- CancellationToken for cooperative cancellation
- stop() with cleanup timeout
- kill() for force termination
- Bulk stop/kill operations
- Graceful shutdown support

**API After Phase 2:**
```python
@app.task(cancellable=True)
async def long_task(cancel_token: CancellationToken):
    for item in items:
        if cancel_token.is_cancelled:
            return {"status": "cancelled"}
        await process(item)

# Stop gracefully
await app.tasks.stop(task_id, timeout=30)

# Force kill
await app.tasks.kill(task_id)
```

**Commit Points:**
- After 2.1-2.2: `feat(tasks): add cancellation token support`
- After 2.3-2.5: `feat(tasks): implement stop/kill operations`
- After 2.6-2.8: `feat(tasks): add bulk ops and tests`

**Edge Cases to Test:**
- Stop task that's already completing
- Kill task during cleanup
- Multiple stop/kill calls on same task
- Stop all with partial failures
- Cancellation token race conditions
- Stop during retry
- Shutdown with running tasks

---

### Phase 3: Thread & Process Pool Runners (Week 2)
**Goal:** Add Level 2 & 3 execution backends

| Task ID | Description | Hours | Test Coverage |
|---------|-------------|-------|---------------|
| 3.1 | Implement `ThreadPoolRunner` | 4 | Thread execution, blocking I/O, error handling |
| 3.2 | Implement `ProcessPoolRunner` | 5 | Process execution, CPU-bound, serialization |
| 3.3 | Add auto-detection (blocking/cpu_bound hints) | 3 | Auto-selection, manual override, hints |
| 3.4 | Add `@app.task(blocking=True)` decorator option | 2 | Decorator option, thread pool routing |
| 3.5 | Add `@app.task(cpu_bound=True)` decorator option | 2 | Decorator option, process pool routing |
| 3.6 | Implement cancellation for thread/process pools | 4 | Stop/kill in pools, cleanup, resource release |
| 3.7 | Tests for thread/process pools | 6 | All scenarios, edge cases, resource cleanup |
| **Total** | | **26 hours** | **100% coverage** |

**Deliverables:**
- ThreadPoolRunner for blocking I/O
- ProcessPoolRunner for CPU-bound tasks
- Auto-detection based on hints
- Cancellation support for both

**API After Phase 3:**
```python
@app.task(blocking=True)
def read_file(path: str) -> bytes:
    with open(path, 'rb') as f:
        return f.read()

@app.task(cpu_bound=True)
def process_image(data: bytes) -> bytes:
    return heavy_processing(data)
```

**Commit Points:**
- After 3.1-3.2: `feat(tasks): add thread and process pool runners`
- After 3.3-3.5: `feat(tasks): add auto-detection and hints`
- After 3.6-3.7: `feat(tasks): add pool cancellation and tests`

**Edge Cases to Test:**
- Thread pool exhaustion
- Process pool serialization errors
- Cancellation during thread execution
- Process termination cleanup
- Pool shutdown with running tasks
- Resource leaks (threads/processes)
- Large data serialization

---

### Phase 4: Distributed Workers (Week 3)
**Goal:** Add Level 4 external worker support

| Task ID | Description | Hours | Test Coverage |
|---------|-------------|-------|---------------|
| 4.1 | Refactor CeleryBackend for new API | 3 | Integration, message format, routing |
| 4.2 | Refactor RQBackend for new API | 3 | Integration, job format, queue management |
| 4.3 | Add ARQ backend support | 4 | ARQ integration, async-native, Redis |
| 4.4 | Implement worker CLI (`zephyr worker`) | 5 | CLI commands, queue selection, concurrency |
| 4.5 | Add broker configuration (Redis/RabbitMQ) | 3 | Config parsing, connection, health checks |
| 4.6 | Implement distributed cancellation | 4 | Cancel via broker, worker acknowledgment |
| 4.7 | Add result backend configuration | 2 | Redis/DB result storage, persistence |
| 4.8 | Tests for distributed backends | 6 | All backends, worker scenarios, failures |
| **Total** | | **30 hours** | **100% coverage** |

**Deliverables:**
- Celery, RQ, ARQ backend support
- Worker CLI tool
- Broker configuration
- Distributed cancellation

**API After Phase 4:**
```python
app = Zephyr(
    task_broker="redis://localhost:6379/1",
    task_result_backend="redis://localhost:6379/0",
)

@app.task(distributed=True, queue="heavy")
async def train_model(data: dict):
    pass
```

**Commit Points:**
- After 4.1-4.3: `feat(tasks): refactor distributed backends`
- After 4.4-4.5: `feat(tasks): add worker CLI and broker config`
- After 4.6-4.8: `feat(tasks): add distributed cancellation and tests`

**Edge Cases to Test:**
- Broker connection failures
- Worker crashes during execution
- Message serialization errors
- Queue routing failures
- Result backend failures
- Network partitions
- Worker scaling up/down

---

### Phase 5: Advanced Features (Week 3-4)
**Goal:** Scheduling, routing, monitoring

| Task ID | Description | Hours | Test Coverage |
|---------|-------------|-------|---------------|
| 5.1 | Add periodic task scheduling (cron/interval) | 5 | Cron parsing, interval scheduling, execution |
| 5.2 | Add task priority and queue routing | 3 | Priority queues, routing rules, fairness |
| 5.3 | Add task dependencies (chain/group) | 4 | Task chains, groups, error propagation |
| 5.4 | Add task retry policies (exponential backoff) | 3 | Retry logic, backoff calculation, max retries |
| 5.5 | Add task monitoring/metrics | 4 | Metrics collection, health checks, stats |
| 5.6 | Add task result expiration | 2 | TTL handling, cleanup, storage management |
| 5.7 | Tests for advanced features | 6 | All features, edge cases, integration |
| **Total** | | **27 hours** | **100% coverage** |

**Deliverables:**
- Periodic task scheduling
- Priority queues and routing
- Task dependencies
- Advanced retry policies
- Monitoring and metrics

**API After Phase 5:**
```python
@app.periodic_task(cron="0 * * * *")
async def hourly_cleanup():
    pass

@app.task(priority=10, queue="critical")
async def urgent_task():
    pass
```

**Commit Points:**
- After 5.1-5.2: `feat(tasks): add scheduling and routing`
- After 5.3-5.4: `feat(tasks): add dependencies and retry policies`
- After 5.5-5.7: `feat(tasks): add monitoring and complete tests`

**Edge Cases to Test:**
- Cron parsing edge cases
- Priority queue starvation
- Dependency chain failures
- Retry exhaustion
- Metrics collection under load
- Result expiration cleanup

---

## Test Requirements

### Coverage Targets
- **Unit Tests:** 100% code coverage
- **Integration Tests:** All backends, all scenarios
- **Edge Cases:** All error paths, race conditions, failures

### Test Categories

1. **Unit Tests**
   - Task registration
   - Execution backends
   - Result storage
   - Cancellation
   - State management

2. **Integration Tests**
   - Full workflow (submit → execute → result)
   - Multiple backends
   - App lifecycle
   - Worker communication

3. **Edge Case Tests**
   - Concurrent submissions
   - Resource exhaustion
   - Network failures
   - Serialization errors
   - Race conditions
   - Cleanup failures

### Test Files Structure

```
tests/tasks/
├── conftest.py
├── test_registry.py (18 tests)
├── test_decorators.py (12 tests)
├── test_result.py (15 tests)
├── test_runner.py (18 tests)
├── test_manager.py (20 tests)
├── test_backends.py (23 tests)
├── test_cancellation.py (25 tests)  # NEW
├── test_thread_pool.py (15 tests)   # NEW
├── test_process_pool.py (15 tests)  # NEW
├── test_distributed.py (20 tests)   # NEW
├── test_scheduling.py (12 tests)    # NEW
├── test_routing.py (10 tests)      # NEW
└── test_integration.py (15 tests)   # NEW
```

**Total Tests:** ~218 tests (target)

---

## Timeline Summary

| Phase | Duration | Hours | Commits |
|-------|----------|-------|---------|
| Phase 1 | Week 1 | 19h | 3 |
| Phase 2 | Week 1-2 | 24h | 3 |
| Phase 3 | Week 2 | 26h | 3 |
| Phase 4 | Week 3 | 30h | 3 |
| Phase 5 | Week 3-4 | 27h | 3 |
| **Total** | **3-4 weeks** | **126h** | **15** |

---

## Success Criteria

- ✅ Zero-config default works out of the box
- ✅ All execution levels (1-4) functional
- ✅ 100% test coverage with all edge cases
- ✅ Cancellation works for all backends
- ✅ API is simple and intuitive
- ✅ Documentation complete
- ✅ Performance benchmarks meet targets
- ✅ No resource leaks (threads, processes, connections)

---

## Dependencies

- Existing task system (refactor, not rebuild)
- Redis (for distributed backends)
- Optional: Celery, RQ, ARQ (for distributed workers)

---

## Notes

- Build incrementally, test thoroughly at each phase
- Each commit should be self-contained and working
- Focus on simplicity first, add complexity only when needed
- All edge cases must be tested before moving to next phase



