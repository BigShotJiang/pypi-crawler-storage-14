#!/usr/bin/env python3
"""Quick test script for OpenAPI schema generation."""

import asyncio

from zephyr import Zephyr


async def test_openapi():
    """Test OpenAPI schema generation."""
    app = Zephyr(title="Test API", version="1.0.0", description="A test API")

    @app.get("/")
    async def root() -> dict:
        """Root endpoint."""
        return {"message": "Welcome"}

    @app.get("/users/{user_id:int}")
    async def get_user(user_id: int) -> dict:
        """Get a user by ID.

        Args:
            user_id: The user ID

        Returns:
            User information
        """
        return {"id": user_id, "name": "John Doe"}

    @app.post("/users")
    async def create_user() -> dict:
        """Create a new user."""
        return {"id": 1, "name": "Jane Doe"}

    @app.get("/health")
    async def health() -> dict:
        """Health check endpoint."""
        return {"status": "healthy"}

    # Get the schema
    from zephyr.app.openapi import get_openapi_schema

    schema = get_openapi_schema(
        app.router,
        title=app.title,
        version=app.version,
        description=app.description,
    )

    print("✓ OpenAPI Schema Generated Successfully!")
    print(f"\nAPI Title: {schema['info']['title']}")
    print(f"API Version: {schema['info']['version']}")
    print(f"Total Paths: {len(schema['paths'])}")
    print("\nPaths:")
    for path, methods in schema["paths"].items():
        for method in methods.keys():
            print(f"  {method.upper()} {path}")

    # Verify schema structure
    assert schema["openapi"] == "3.1.0"
    assert schema["info"]["title"] == "Test API"
    assert schema["info"]["version"] == "1.0.0"
    assert len(schema["paths"]) > 0
    assert "/" in schema["paths"]

    # Check path parameters extraction
    user_path = "/users/{user_id:int}"
    if user_path in schema["paths"]:
        get_op = schema["paths"][user_path].get("get", {})
        if "parameters" in get_op:
            params = get_op["parameters"]
            print(f"\n✓ Parameters for {user_path}: {params}")
            assert any(p["name"] == "user_id" for p in params)

    print("\n✅ All tests passed!")


if __name__ == "__main__":
    asyncio.run(test_openapi())
