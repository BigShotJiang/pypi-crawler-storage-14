# 📋 ZEPHYR CLI - IMPLEMENTATION PLAN

**Detailed step-by-step plan to build Zephyr CLI**

---

## 📊 EXECUTION SUMMARY

| Tier | Component | Duration | Status |
|------|-----------|----------|--------|
| 1 | CLI Core + EnvManager | 2-3h | ⏳ START FIRST |
| 2 | Service + Dev Commands | 3-4h | ⏳ AFTER TIER 1 |
| 3 | Database Commands | 2-3h | ⏳ AFTER TIER 2 |
| 4 | Deploy + Monitor | 3-4h | ⏳ AFTER TIER 3 |
| 5 | Shell + Profiling | 2-3h | ⏳ AFTER TIER 4 |
| **TOTAL** | **Complete CLI** | **12-17h** | **~1-2 days** |

---

## TIER 1: CLI CORE FRAMEWORK (2-3 hours) - START HERE

### What Gets Done

1. ✅ CLI package structure
2. ✅ Entry point with Click
3. ✅ Environment manager (load .env files)
4. ✅ Basic commands (config init/show/set/get)
5. ✅ Error handling
6. ✅ Rich formatting
7. ✅ Basic tests

### Files to Create

```
zephyr/cli/
├── pyproject.toml                    [NEW]
├── README.md                         [NEW]
├── tests/
│   ├── conftest.py                   [NEW]
│   ├── test_commands/
│   │   └── test_config.py            [NEW]
│   └── test_core/
│       ├── test_env_manager.py       [NEW]
│       └── test_config_loader.py     [NEW]
└── zephyr_cli/
    ├── __init__.py                   [NEW]
    ├── main.py                       [NEW]
    ├── commands/
    │   ├── __init__.py               [NEW]
    │   └── config.py                 [NEW]
    └── core/
        ├── __init__.py               [NEW]
        ├── env_manager.py            [NEW]
        ├── config_loader.py          [NEW]
        ├── exceptions.py             [NEW]
        └── types.py                  [NEW]
```

### Step 1.1: Create Package Structure (15 min)

```bash
mkdir -p zephyr/cli/zephyr_cli/{commands,core}
mkdir -p zephyr/cli/tests/{test_commands,test_core}
touch zephyr/cli/zephyr_cli/__init__.py
touch zephyr/cli/zephyr_cli/main.py
touch zephyr/cli/zephyr_cli/commands/__init__.py
touch zephyr/cli/zephyr_cli/core/__init__.py
```

### Step 1.2: Create pyproject.toml (15 min)

**zephyr/cli/pyproject.toml:**
```toml
[project]
name = "zephyr-cli"
version = "0.1.0"
description = "Zephyr Framework - All-in-one CLI"
requires-python = ">=3.11"
dependencies = [
    "zephyr-py>=0.1.0",              # Main framework
    "dockpy-cli>=0.1.0",             # Use zhcli as base
    "click>=8.0.0",
    "pydantic>=2.0.0",
    "pyyaml>=6.0",
]

[project.scripts]
zephyr = "zephyr_cli.main:cli"

[tool.uv]
workspace-dependencies = true
```

### Step 1.3: Create EnvManager (30 min)

**zephyr/cli/zephyr_cli/core/env_manager.py:**

```python
"""
Environment file management for Zephyr CLI

Author: AM
Created At: 22 Nov 2025
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger()


class EnvManager:
    """Manage .env files with hierarchy support"""
    
    def __init__(self, root_dir: str | Path = ".") -> None:
        """Initialize EnvManager
        
        Args:
            root_dir: Root directory to search for .env files
        """
        self.root_dir = Path(root_dir)
    
    def load_config(self, env: str | None = None) -> dict[str, str]:
        """Load environment configuration with hierarchy
        
        Load order:
        1. .env (default)
        2. .env.{env} (environment-specific)
        3. .env.local (local overrides)
        4. OS environment variables (highest priority)
        
        Args:
            env: Environment name (dev, staging, prod)
            
        Returns:
            Merged configuration dictionary
        """
        config: dict[str, str] = {}
        
        # 1. Load default .env
        config.update(self._load_file(".env"))
        logger.debug("loaded_env_file", file=".env", keys=len(config))
        
        # 2. Load environment-specific .env.{env}
        if env:
            env_config = self._load_file(f".env.{env}")
            config.update(env_config)
            logger.debug("loaded_env_file", file=f".env.{env}", keys=len(env_config))
        
        # 3. Load local overrides .env.local (if exists)
        local_config = self._load_file(".env.local")
        config.update(local_config)
        if local_config:
            logger.debug("loaded_env_file", file=".env.local", keys=len(local_config))
        
        # 4. OS environment variables override everything
        for key, value in os.environ.items():
            if key.startswith(("ZEPHYR_", "APP_", "DATABASE_", "REDIS_")):
                config[key] = value
        
        return config
    
    def create_env_files(self, env: str | None = None) -> None:
        """Create .env files from defaults
        
        Args:
            env: Specific environment to create (dev, staging, prod)
        """
        if env:
            self._create_specific_env(env)
        else:
            self._create_all_env_files()
    
    def save_config(self, key: str, value: str, env: str | None = None) -> None:
        """Save configuration value to .env file
        
        Args:
            key: Configuration key
            value: Configuration value
            env: Environment name (None = .env)
        """
        filename = f".env.{env}" if env else ".env"
        filepath = self.root_dir / filename
        
        # Load existing
        config = self._load_file(filename)
        
        # Update
        config[key] = value
        
        # Save
        with open(filepath, "w") as f:
            for k, v in config.items():
                f.write(f"{k}={v}\n")
        
        logger.info("saved_config", file=filename, key=key)
    
    def _load_file(self, filename: str) -> dict[str, str]:
        """Load a single .env file
        
        Args:
            filename: Filename to load
            
        Returns:
            Configuration dictionary
        """
        filepath = self.root_dir / filename
        
        if not filepath.exists():
            return {}
        
        config: dict[str, str] = {}
        
        try:
            with open(filepath) as f:
                for line in f:
                    line = line.strip()
                    
                    # Skip comments and empty lines
                    if not line or line.startswith("#"):
                        continue
                    
                    # Parse KEY=VALUE
                    if "=" not in line:
                        continue
                    
                    key, value = line.split("=", 1)
                    config[key.strip()] = value.strip()
        
        except Exception as e:
            logger.error("failed_to_load_env_file", file=filename, error=str(e))
        
        return config
    
    def _create_all_env_files(self) -> None:
        """Create default .env files"""
        self._create_default_env()
        self._create_specific_env("dev")
        self._create_specific_env("staging")
        self._create_specific_env("prod")
    
    def _create_default_env(self) -> None:
        """Create default .env file"""
        filepath = self.root_dir / ".env"
        
        if filepath.exists():
            logger.warning("env_file_exists", file=".env")
            return
        
        content = """# Zephyr Configuration - Default Values
# Copy .env.example to .env and customize

# Application
APP_NAME=MyApp
APP_PORT=8000
ENVIRONMENT=development
DEBUG=false

# Database
DATABASE_URL=postgresql://localhost:5432/myapp
DATABASE_ECHO=false
DATABASE_POOL_SIZE=20

# Redis
REDIS_URL=redis://localhost:6379/0
CACHE_REDIS_URL=redis://localhost:6379/1

# Logging
LOG_LEVEL=INFO

# Security
SECRET_KEY=change-me-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRATION=3600
"""
        
        with open(filepath, "w") as f:
            f.write(content)
        
        logger.info("created_env_file", file=".env")
    
    def _create_specific_env(self, env: str) -> None:
        """Create environment-specific .env file
        
        Args:
            env: Environment name (dev, staging, prod)
        """
        filepath = self.root_dir / f".env.{env}"
        
        if filepath.exists():
            logger.warning("env_file_exists", file=f".env.{env}")
            return
        
        content = f"""# Zephyr Configuration - {env.upper()} Environment

# Application
ENVIRONMENT={env}
DEBUG={'true' if env == 'dev' else 'false'}
LOG_LEVEL={'DEBUG' if env == 'dev' else 'INFO'}

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/myapp_{env}
DATABASE_ECHO={'true' if env == 'dev' else 'false'}

# Redis
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=change-me-in-production-{env}
"""
        
        with open(filepath, "w") as f:
            f.write(content)
        
        logger.info("created_env_file", file=f".env.{env}")
```

### Step 1.4: Create ConfigLoader (20 min)

**zephyr/cli/zephyr_cli/core/config_loader.py:**

```python
"""Configuration loader and validator"""

from __future__ import annotations

from typing import Any

import structlog
from pydantic import BaseModel, ValidationError

logger = structlog.get_logger()


class AppConfig(BaseModel):
    """Application configuration schema"""
    
    app_name: str = "MyApp"
    app_port: int = 8000
    environment: str = "development"
    debug: bool = False
    log_level: str = "INFO"
    database_url: str | None = None
    redis_url: str | None = None
    secret_key: str | None = None


class ConfigLoader:
    """Load and validate configuration"""
    
    @staticmethod
    def validate(config: dict[str, Any]) -> AppConfig:
        """Validate configuration against schema
        
        Args:
            config: Configuration dictionary
            
        Returns:
            Validated AppConfig
            
        Raises:
            ValidationError: If configuration is invalid
        """
        try:
            return AppConfig(**config)
        except ValidationError as e:
            logger.error("config_validation_failed", errors=e.errors())
            raise
    
    @staticmethod
    def check_required(config: dict[str, Any], required: list[str]) -> bool:
        """Check if required keys are present
        
        Args:
            config: Configuration dictionary
            required: List of required keys
            
        Returns:
            True if all required keys present
        """
        missing = [key for key in required if key not in config]
        
        if missing:
            logger.warning("missing_required_config", keys=missing)
            return False
        
        return True
```

### Step 1.5: Create CLI Entry Point (20 min)

**zephyr/cli/zephyr_cli/main.py:**

```python
"""Zephyr CLI - Main entry point

Author: AM
Created At: 22 Nov 2025
"""

from __future__ import annotations

import click
import structlog
from rich.console import Console

from zephyr_cli.commands import config as config_cmd

logger = structlog.get_logger()
console = Console()


@click.group()
@click.version_option(version="0.1.0", message="Zephyr CLI v%(version)s")
def cli() -> None:
    """Zephyr Framework - All-in-one CLI
    
    Pure async, no subprocess calls, built on zhcli
    """
    pass


# Register command groups
cli.add_command(config_cmd.config)


if __name__ == "__main__":
    cli()
```

### Step 1.6: Create Config Commands (30 min)

**zephyr/cli/zephyr_cli/commands/config.py:**

```python
"""Configuration management commands

Author: AM
Created At: 22 Nov 2025
"""

from __future__ import annotations

import click
import structlog
from rich.console import Console
from rich.table import Table

from zephyr_cli.core.env_manager import EnvManager

logger = structlog.get_logger()
console = Console()


@click.group()
def config() -> None:
    """Configuration management"""
    pass


@config.command()
@click.option("--env", default=None, help="Environment name")
def init(env: str | None) -> None:
    """Initialize .env files"""
    manager = EnvManager()
    
    try:
        manager.create_env_files(env)
        
        if env:
            console.print(f"[green]✅[/green] Config files created for {env}")
        else:
            console.print("[green]✅[/green] Config files initialized")
    
    except Exception as e:
        console.print(f"[red]❌[/red] Error: {e}")
        raise click.Exit(1)


@config.command()
@click.option("--env", default=None, help="Environment name")
@click.option("--format", default="table", type=click.Choice(["table", "json"]))
def show(env: str | None, format: str) -> None:
    """Show configuration"""
    manager = EnvManager()
    
    try:
        config_dict = manager.load_config(env)
        
        if format == "json":
            import json
            console.print_json(data=config_dict)
        else:
            table = Table(title="Configuration")
            table.add_column("Key", style="cyan")
            table.add_column("Value", style="green")
            
            for key, value in config_dict.items():
                table.add_row(key, value)
            
            console.print(table)
    
    except Exception as e:
        console.print(f"[red]❌[/red] Error: {e}")
        raise click.Exit(1)


@config.command()
@click.argument("key")
def get(key: str) -> None:
    """Get configuration value"""
    manager = EnvManager()
    
    try:
        config_dict = manager.load_config()
        
        if key in config_dict:
            console.print(f"{key}={config_dict[key]}")
        else:
            console.print(f"[yellow]⚠️[/yellow] Key not found: {key}")
            raise click.Exit(1)
    
    except Exception as e:
        console.print(f"[red]❌[/red] Error: {e}")
        raise click.Exit(1)


@config.command()
@click.argument("key")
@click.argument("value")
@click.option("--env", default=None, help="Environment name")
@click.option("--local", is_flag=True, help="Set in .env.local")
def set(key: str, value: str, env: str | None, local: bool) -> None:
    """Set configuration value"""
    manager = EnvManager()
    
    try:
        target_env = "local" if local else env
        manager.save_config(key, value, target_env)
        
        file_name = ".env.local" if local else (f".env.{env}" if env else ".env")
        console.print(f"[green]✅[/green] {key} set in {file_name}")
    
    except Exception as e:
        console.print(f"[red]❌[/red] Error: {e}")
        raise click.Exit(1)


@config.command()
@click.option("--env", default=None, help="Environment name")
def validate(env: str | None) -> None:
    """Validate configuration"""
    manager = EnvManager()
    
    try:
        config_dict = manager.load_config(env)
        
        # Check required keys
        required = [
            "DATABASE_URL",
            "REDIS_URL",
            "SECRET_KEY",
        ]
        
        missing = [key for key in required if key not in config_dict]
        
        if missing:
            console.print("[yellow]⚠️  Missing required config:[/yellow]")
            for key in missing:
                console.print(f"  - {key}")
            raise click.Exit(1)
        
        console.print("[green]✅[/green] Configuration is valid")
    
    except Exception as e:
        console.print(f"[red]❌[/red] Error: {e}")
        raise click.Exit(1)
```

### Step 1.7: Create Tests (15 min)

**zephyr/cli/tests/test_commands/test_config.py:**

```python
"""Tests for config commands"""

import pytest
from click.testing import CliRunner

from zephyr_cli.main import cli


@pytest.fixture
def runner():
    """Create CLI runner"""
    return CliRunner()


def test_config_init(runner, tmp_path):
    """Test config init"""
    with runner.isolated_filesystem():
        result = runner.invoke(cli, ["config", "init"])
        
        assert result.exit_code == 0
        assert "Config files initialized" in result.output


def test_config_show(runner, tmp_path):
    """Test config show"""
    with runner.isolated_filesystem():
        # First initialize
        runner.invoke(cli, ["config", "init"])
        
        # Then show
        result = runner.invoke(cli, ["config", "show"])
        
        assert result.exit_code == 0
        assert "Configuration" in result.output
```

### Step 1.8: Test Locally (15 min)

```bash
cd zephyr/cli

# Install dependencies
uv sync

# Test basic command
uv run zephyr --version
uv run zephyr --help

# Test config command
uv run zephyr config init
uv run zephyr config show
uv run zephyr config get APP_NAME

# Run tests
uv run pytest tests/ -v
```

---

## TIER 2: SERVICE & DEV COMMANDS (3-4 hours)

### Files to Create

```
zephyr/cli/zephyr_cli/
├── commands/
│   ├── service.py       [NEW]
│   ├── dev.py          [NEW]
│   └── base.py         [NEW]  (BaseCommand class)
├── core/
│   ├── compose_generator.py  [NEW]
│   └── service_registry.py   [NEW]
└── utils/
    └── docker_helpers.py     [NEW]
```

### Implementation

1. Create BaseCommand for async support
2. Implement ComposeGenerator
3. Create service.py with list/start/stop/logs
4. Create dev.py with start/stop/logs
5. Write tests

---

## TIER 3: DATABASE COMMANDS (2-3 hours)

### Files to Create

```
zephyr/cli/zephyr_cli/
└── commands/
    └── db.py  [NEW]
```

### Implementation

1. Create db.py with migrate/seed commands
2. Integrate with Alembic
3. Write tests

---

## TIER 4: DEPLOYMENT & MONITORING (3-4 hours)

### Files to Create

```
zephyr/cli/zephyr_cli/
└── commands/
    ├── deploy.py   [NEW]
    └── monitor.py  [NEW]
```

### Implementation

1. Create deploy.py with start/stop/rollback
2. Create monitor.py with logs/health/metrics
3. Integrate with zhcli
4. Write tests

---

## TIER 5: ADVANCED TOOLS (2-3 hours)

### Files to Create

```
zephyr/cli/zephyr_cli/
└── commands/
    ├── shell.py      [NEW]
    └── profiling.py  [NEW]
```

### Implementation

1. Create shell.py for interactive REPL
2. Create profiling.py for CPU/memory profiling
3. Write tests

---

## CHECKLIST

### TIER 1 (CLI Core)
- [ ] Create package structure
- [ ] Create pyproject.toml
- [ ] Implement EnvManager
- [ ] Implement ConfigLoader
- [ ] Create main.py entry point
- [ ] Create config.py commands
- [ ] Write tests
- [ ] Test locally
- [ ] Commit to git

### TIER 2 (Service & Dev)
- [ ] Create service.py
- [ ] Create dev.py
- [ ] Implement ComposeGenerator
- [ ] Write tests
- [ ] Test locally
- [ ] Commit to git

### TIER 3 (Database)
- [ ] Create db.py
- [ ] Integrate with Alembic
- [ ] Write tests
- [ ] Commit to git

### TIER 4 (Deploy & Monitor)
- [ ] Create deploy.py
- [ ] Create monitor.py
- [ ] Write tests
- [ ] Commit to git

### TIER 5 (Advanced)
- [ ] Create shell.py
- [ ] Create profiling.py
- [ ] Write tests
- [ ] Commit to git

---

## GIT COMMITS

```bash
# After TIER 1
git add zephyr/cli/
git commit -m "feat: Zephyr CLI core framework with config management"

# After TIER 2
git commit -m "feat: Service and development environment commands"

# After TIER 3
git commit -m "feat: Database migration commands"

# After TIER 4
git commit -m "feat: Deployment and monitoring commands"

# After TIER 5
git commit -m "feat: Shell and profiling tools"
```

---

## TESTING STRATEGY

### Unit Tests
- EnvManager functionality
- ConfigLoader validation
- Command logic

### Integration Tests
- CLI command execution
- File I/O operations
- Error handling

### End-to-End Tests
- Full workflows
- Docker integration (optional)

---

## DEPENDENCIES TO INSTALL

```bash
cd zephyr/cli
uv add click pydantic pyyaml structlog rich
uv add -p cli dockpy-cli zephyr-py
```

---

**Ready to start? Begin with TIER 1!** 🚀



