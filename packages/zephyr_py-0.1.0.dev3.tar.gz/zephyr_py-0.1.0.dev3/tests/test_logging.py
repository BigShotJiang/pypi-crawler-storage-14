"""Test suite for the Zephyr logging system.

Tests the wrapper pattern logger with contextvars support.
"""

import asyncio
import logging

import pytest

from zephyr.core.logging import get_logger


class TestLoggerBasics:
    """Test basic logging functionality."""

    def test_simple_message(self, caplog):
        """Test simple log message."""
        logger = get_logger("test.basic")
        with caplog.at_level(logging.INFO):
            logger.info("Simple message")
        assert "Simple message" in caplog.text

    def test_message_with_kwargs(self, caplog):
        """Test log message with keyword arguments."""
        logger = get_logger("test.kwargs")
        with caplog.at_level(logging.INFO):
            logger.info("Message with kwargs", user_id=123, action="login")
        assert "Message with kwargs" in caplog.text

    def test_percent_formatting(self, caplog):
        """Test % formatting support."""
        logger = get_logger("test.percent")
        with caplog.at_level(logging.INFO):
            logger.info("User %s logged in", "john_doe")
        assert "User john_doe logged in" in caplog.text

    def test_percent_formatting_with_kwargs(self, caplog):
        """Test % formatting with additional kwargs."""
        logger = get_logger("test.percent_kwargs")
        with caplog.at_level(logging.INFO):
            logger.info("Processing %d items for user %s", 42, "jane_doe", status="active")
        assert "Processing 42 items for user jane_doe" in caplog.text


class TestContextBinding:
    """Test context binding with contextvars."""

    def test_bind_context(self, caplog):
        """Test binding context variables."""
        logger = get_logger("test.bind")
        logger.bind(request_id="req-123", user_id=456)
        with caplog.at_level(logging.INFO):
            logger.info("Message with bound context")
        # Context should be in the log record
        assert any(record.request_id == "req-123" for record in caplog.records)
        assert any(record.user_id == 456 for record in caplog.records)

    def test_unbind_context(self, caplog):
        """Test unbinding context variables."""
        logger = get_logger("test.unbind")
        logger.bind(request_id="req-123", user_id=456)
        logger.unbind("user_id")
        with caplog.at_level(logging.INFO):
            logger.info("After unbind")
        # Only request_id should remain
        assert any(record.request_id == "req-123" for record in caplog.records)
        assert not any(hasattr(record, "user_id") for record in caplog.records)

    def test_context_manager(self, caplog):
        """Test context manager for temporary context."""
        logger = get_logger("test.context_mgr")
        with caplog.at_level(logging.INFO):
            with logger.context(transaction_id="txn-789"):
                logger.info("Inside context manager")
            logger.info("Outside context")

        # First message should have transaction_id
        assert caplog.records[0].transaction_id == "txn-789"
        # Second message should not have transaction_id
        assert not hasattr(caplog.records[1], "transaction_id")

    def test_correlation_id_context(self, caplog):
        """Test correlation_id context manager."""
        logger = get_logger("test.correlation")
        with caplog.at_level(logging.INFO):
            with logger.correlation_id("corr-123"):
                logger.info("With correlation ID")
            logger.info("Without correlation ID")

        assert caplog.records[0].correlation_id == "corr-123"
        assert not hasattr(caplog.records[1], "correlation_id")

    def test_request_id_context(self, caplog):
        """Test request_id context manager."""
        from zephyr.core.logging.logger import _log_context

        # Clear any existing context
        _log_context.set({})

        logger = get_logger("test.request")
        with caplog.at_level(logging.INFO):
            with logger.request_id("req-456"):
                logger.info("With request ID")
            logger.info("Without request ID")

        assert caplog.records[0].request_id == "req-456"
        assert not hasattr(caplog.records[1], "request_id")


class TestAsyncContextPropagation:
    """Test context propagation across async/await boundaries."""

    @pytest.mark.asyncio
    async def test_async_context_persistence(self, caplog):
        """Test that context persists across await boundaries."""
        logger = get_logger("test.async")
        logger.bind(async_task_id="task-001")

        with caplog.at_level(logging.INFO):
            logger.info("Before await")
            await asyncio.sleep(0.01)
            logger.info("After await")

        # Both messages should have the context
        assert all(record.async_task_id == "task-001" for record in caplog.records)

    @pytest.mark.asyncio
    async def test_async_context_manager(self, caplog):
        """Test context manager in async context."""
        logger = get_logger("test.async_ctx")

        with caplog.at_level(logging.INFO):
            # Use regular 'with', not 'async with' - contextvars work across async
            with logger.context(operation="async_op"):
                logger.info("Inside async context")
                await asyncio.sleep(0.01)
                logger.info("After await in context")
            logger.info("Outside context")

        # First two messages should have operation
        assert caplog.records[0].operation == "async_op"
        assert caplog.records[1].operation == "async_op"
        # Third message should not
        assert not hasattr(caplog.records[2], "operation")


class TestLogLevels:
    """Test different log levels."""

    def test_trace_level(self, caplog):
        """Test TRACE log level."""
        logger = get_logger("test.trace")
        with caplog.at_level(5):  # TRACE_LOG_LEVEL
            logger.trace("Trace message")
        assert "Trace message" in caplog.text

    def test_debug_level(self, caplog):
        """Test DEBUG log level."""
        logger = get_logger("test.debug")
        with caplog.at_level(logging.DEBUG):
            logger.debug("Debug message")
        assert "Debug message" in caplog.text

    def test_info_level(self, caplog):
        """Test INFO log level."""
        logger = get_logger("test.info")
        with caplog.at_level(logging.INFO):
            logger.info("Info message")
        assert "Info message" in caplog.text

    def test_warning_level(self, caplog):
        """Test WARNING log level."""
        logger = get_logger("test.warning")
        with caplog.at_level(logging.WARNING):
            logger.warning("Warning message")
        assert "Warning message" in caplog.text

    def test_error_level(self, caplog):
        """Test ERROR log level."""
        logger = get_logger("test.error")
        with caplog.at_level(logging.ERROR):
            logger.error("Error message")
        assert "Error message" in caplog.text

    def test_critical_level(self, caplog):
        """Test CRITICAL log level."""
        logger = get_logger("test.critical")
        with caplog.at_level(logging.CRITICAL):
            logger.critical("Critical message")
        assert "Critical message" in caplog.text


class TestLoggerDelegation:
    """Test that unknown attributes are delegated to wrapped logger."""

    def test_delegate_level(self):
        """Test that logger level is accessible."""
        logger = get_logger("test.delegate")
        assert hasattr(logger, "level")
        assert isinstance(logger.level, int)

    def test_delegate_handlers(self):
        """Test that handlers are accessible."""
        logger = get_logger("test.handlers")
        assert hasattr(logger, "handlers")
        assert isinstance(logger.handlers, list)

    def test_delegate_name(self):
        """Test that logger name is accessible."""
        logger = get_logger("test.name")
        assert logger.name == "test.name"


class TestTimeExecution:
    """Test time_execution decorator."""

    def test_time_execution_decorator(self, caplog):
        """Test timing decorator."""
        logger = get_logger("test.timing")

        @logger.time_execution
        def slow_function():
            import time

            time.sleep(0.01)
            return "done"

        with caplog.at_level(logging.INFO):
            result = slow_function()

        assert result == "done"
        assert any("took" in record.message for record in caplog.records)
        assert any(hasattr(record, "elapsed_seconds") for record in caplog.records)

    def test_time_execution_with_level(self, caplog):
        """Test timing decorator with custom level."""
        logger = get_logger("test.timing_level")

        @logger.time_execution(level=logging.DEBUG)
        def fast_function():
            return "quick"

        with caplog.at_level(logging.DEBUG):
            result = fast_function()

        assert result == "quick"
        assert any("took" in record.message for record in caplog.records)
