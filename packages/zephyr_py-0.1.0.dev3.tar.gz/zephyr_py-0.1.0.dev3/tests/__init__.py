"""Test suite for Zephyr framework.

Comprehensive tests for all Zephyr components including authentication,
middleware, configuration, and application functionality.
"""
