"""Tests for memory cache backend."""

from __future__ import annotations

import pytest

from zephyr.core.cache.memory import MemoryCacheBackend


@pytest.mark.asyncio
@pytest.mark.cache
class TestMemoryCacheBackend:
    """Test suite for MemoryCacheBackend."""

    async def test_set_and_get(self, memory_cache: MemoryCacheBackend) -> None:
        """Test setting and retrieving a value."""
        await memory_cache.set("key1", "value1")
        result = await memory_cache.get("key1")
        assert result == "value1"

    async def test_get_missing_key(self, memory_cache: MemoryCacheBackend) -> None:
        """Test getting a missing key returns None."""
        result = await memory_cache.get("missing_key")
        assert result is None

    async def test_delete(self, memory_cache: MemoryCacheBackend) -> None:
        """Test deleting a value."""
        await memory_cache.set("key1", "value1")
        assert await memory_cache.exists("key1")
        await memory_cache.delete("key1")
        assert not await memory_cache.exists("key1")

    async def test_exists(self, memory_cache: MemoryCacheBackend) -> None:
        """Test checking if key exists."""
        await memory_cache.set("key1", "value1")
        assert await memory_cache.exists("key1")
        assert not await memory_cache.exists("missing_key")

    async def test_clear(self, memory_cache: MemoryCacheBackend) -> None:
        """Test clearing all cache."""
        await memory_cache.set("key1", "value1")
        await memory_cache.set("key2", "value2")
        await memory_cache.clear()
        assert not await memory_cache.exists("key1")
        assert not await memory_cache.exists("key2")

    async def test_get_many(self, memory_cache: MemoryCacheBackend) -> None:
        """Test getting multiple values."""
        await memory_cache.set_many({"key1": "value1", "key2": "value2", "key3": "value3"})
        result = await memory_cache.get_many(["key1", "key2", "missing"])
        assert result == {"key1": "value1", "key2": "value2"}

    async def test_set_many(self, memory_cache: MemoryCacheBackend) -> None:
        """Test setting multiple values."""
        data = {"key1": "value1", "key2": "value2", "key3": "value3"}
        await memory_cache.set_many(data)
        result = await memory_cache.get("key1")
        assert result == "value1"
        result = await memory_cache.get("key2")
        assert result == "value2"

    async def test_delete_many(self, memory_cache: MemoryCacheBackend) -> None:
        """Test deleting multiple values."""
        await memory_cache.set_many({"key1": "value1", "key2": "value2", "key3": "value3"})
        await memory_cache.delete_many(["key1", "key2"])
        assert not await memory_cache.exists("key1")
        assert not await memory_cache.exists("key2")
        assert await memory_cache.exists("key3")

    async def test_increment(self, memory_cache: MemoryCacheBackend) -> None:
        """Test incrementing a value."""
        await memory_cache.set("counter", 10)
        result = await memory_cache.increment("counter", 5)
        assert result == 15
        stored = await memory_cache.get("counter")
        assert stored == 15

    async def test_increment_missing_key(self, memory_cache: MemoryCacheBackend) -> None:
        """Test incrementing a missing key."""
        result = await memory_cache.increment("counter", 5)
        assert result == 5

    async def test_decrement(self, memory_cache: MemoryCacheBackend) -> None:
        """Test decrementing a value."""
        await memory_cache.set("counter", 10)
        result = await memory_cache.decrement("counter", 3)
        assert result == 7

    async def test_ttl_expiration(self, memory_cache: MemoryCacheBackend) -> None:
        """Test that values expire based on TTL."""
        import time

        await memory_cache.set("key1", "value1", ttl=1)
        assert await memory_cache.exists("key1")
        time.sleep(1.5)
        assert not await memory_cache.exists("key1")

    async def test_lru_eviction(self) -> None:
        """Test LRU eviction when max_size is reached."""
        cache = MemoryCacheBackend(max_size=3, default_ttl=300)
        try:
            # Fill cache
            await cache.set("key1", "value1")
            await cache.set("key2", "value2")
            await cache.set("key3", "value3")

            # Add one more (should evict oldest)
            await cache.set("key4", "value4")

            # key1 should be evicted
            assert not await cache.exists("key1")
            assert await cache.exists("key2")
            assert await cache.exists("key3")
            assert await cache.exists("key4")
        finally:
            await cache.close()

    async def test_cache_different_types(self, memory_cache: MemoryCacheBackend, sample_data: dict) -> None:
        """Test caching different data types."""
        for key, value in sample_data.items():
            await memory_cache.set(key, value)

        for key, expected_value in sample_data.items():
            result = await memory_cache.get(key)
            assert result == expected_value

    async def test_health_check(self, memory_cache: MemoryCacheBackend) -> None:
        """Test health check."""
        is_healthy = await memory_cache.health_check()
        assert is_healthy is True

    async def test_get_stats(self, memory_cache: MemoryCacheBackend) -> None:
        """Test getting cache statistics."""
        await memory_cache.set("key1", "value1")
        await memory_cache.get("key1")  # Hit
        await memory_cache.get("missing")  # Miss

        stats = memory_cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["size"] == 1
        assert stats["max_size"] == 100

    async def test_close(self, memory_cache: MemoryCacheBackend) -> None:
        """Test closing cache."""
        await memory_cache.set("key1", "value1")
        await memory_cache.close()
        # After close, cache should be empty
        stats = memory_cache.get_stats()
        assert stats["size"] == 0

    async def test_concurrent_operations(self, memory_cache: MemoryCacheBackend) -> None:
        """Test concurrent cache operations."""
        import asyncio

        async def set_and_get(key: str, value: str) -> str | None:
            await memory_cache.set(key, value)
            return await memory_cache.get(key)

        tasks = [set_and_get(f"key{i}", f"value{i}") for i in range(10)]
        results = await asyncio.gather(*tasks)

        # All operations should succeed
        assert all(r is not None for r in results)
        assert len(results) == 10
