"""Tests for cache decorators."""

from __future__ import annotations

import pytest

from zephyr.core.cache.decorators import cache, cache_with_tags, invalidate_cache
from zephyr.core.cache.manager import CacheManager


@pytest.mark.asyncio
@pytest.mark.cache
class TestCacheDecorators:
    """Test suite for cache decorators."""

    async def test_cache_decorator_caches_result(self) -> None:
        """Test that @cache decorator caches function results."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        call_count = 0

        @cache(ttl=3600)
        async def expensive_function(value: int) -> int:
            nonlocal call_count
            call_count += 1
            return value * 2

        # First call
        result1 = await expensive_function(5)
        assert result1 == 10
        assert call_count == 1

        # Second call with same args (should use cache)
        result2 = await expensive_function(5)
        assert result2 == 10
        assert call_count == 1  # Not incremented

        # Third call with different args
        result3 = await expensive_function(10)
        assert result3 == 20
        assert call_count == 2  # Incremented

    async def test_cache_decorator_with_different_args(self) -> None:
        """Test that @cache decorator uses different cache keys for different args."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        @cache(ttl=3600)
        async def get_user(user_id: int) -> dict:
            return {"id": user_id, "name": f"User{user_id}"}

        result1 = await get_user(1)
        result2 = await get_user(2)

        assert result1 == {"id": 1, "name": "User1"}
        assert result2 == {"id": 2, "name": "User2"}

    async def test_cache_decorator_with_prefix(self) -> None:
        """Test @cache decorator with custom prefix."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        @cache(ttl=3600, prefix="users")
        async def get_user(user_id: int) -> dict:
            return {"id": user_id}

        result = await get_user(1)
        assert result == {"id": 1}

    async def test_cache_with_tags_decorator(self) -> None:
        """Test @cache_with_tags decorator."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        @cache_with_tags(tags=["user:profile"], ttl=3600)
        async def get_user_profile(user_id: int) -> dict:
            return {"id": user_id, "name": f"User{user_id}"}

        result1 = await get_user_profile(1)
        assert result1 == {"id": 1, "name": "User1"}

        # Second call should use cache
        result2 = await get_user_profile(1)
        assert result2 == {"id": 1, "name": "User1"}

    async def test_invalidate_cache_decorator(self) -> None:
        """Test @invalidate_cache decorator."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        call_count = 0

        @cache(ttl=3600)
        async def get_data(data_id: int) -> dict:
            nonlocal call_count
            call_count += 1
            return {"id": data_id, "value": data_id * 2}

        @invalidate_cache(tags=["data"])
        async def update_data(data_id: int, new_value: int) -> dict:
            return {"id": data_id, "value": new_value}

        # Get initial data (cached)
        result1 = await get_data(1)
        assert call_count == 1

        # Get again (should use cache)
        result2 = await get_data(1)
        assert call_count == 1

        # Update data (should invalidate cache)
        await update_data(1, 100)

        # Get again (should call function)
        result3 = await get_data(1)
        assert call_count == 2

    async def test_cache_decorator_with_kwargs(self) -> None:
        """Test @cache decorator with keyword arguments."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        @cache(ttl=3600)
        async def greet(first_name: str, last_name: str) -> str:
            return f"Hello, {first_name} {last_name}"

        result1 = await greet(first_name="John", last_name="Doe")
        result2 = await greet(first_name="John", last_name="Doe")

        assert result1 == result2 == "Hello, John Doe"

    async def test_cache_decorator_with_mixed_args(self) -> None:
        """Test @cache decorator with mixed positional and keyword args."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        @cache(ttl=3600)
        async def calculate(a: int, b: int, operation: str = "add") -> int:
            if operation == "add":
                return a + b
            if operation == "multiply":
                return a * b
            return 0

        result1 = await calculate(5, 3, operation="add")
        result2 = await calculate(5, 3, operation="add")

        assert result1 == result2 == 8

    async def test_cache_decorator_caches_none_values(self) -> None:
        """Test that @cache decorator caches None values."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        call_count = 0

        @cache(ttl=3600)
        async def might_return_none(value: int) -> int | None:
            nonlocal call_count
            call_count += 1
            if value < 0:
                return None
            return value * 2

        # First call returns None
        result1 = await might_return_none(-1)
        assert result1 is None
        assert call_count == 1

        # Second call should still call function (None not cached typically)
        result2 = await might_return_none(-1)
        assert result2 is None

    async def test_cache_decorator_with_complex_objects(self) -> None:
        """Test @cache decorator with complex objects."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory")

        @cache(ttl=3600)
        async def get_complex_data(data_id: int) -> dict:
            return {
                "id": data_id,
                "nested": {"level1": {"level2": "value"}},
                "list": [1, 2, 3, {"nested": "item"}],
            }

        result1 = await get_complex_data(1)
        result2 = await get_complex_data(1)

        assert result1 == result2
        assert result1["nested"]["level1"]["level2"] == "value"
        assert result1["list"][3]["nested"] == "item"

    async def test_cache_decorator_default_ttl(self) -> None:
        """Test @cache decorator with default TTL."""
        CacheManager.reset()
        CacheManager.configure(backend_type="memory", default_ttl=600)

        @cache()  # No TTL specified
        async def get_value() -> str:
            return "cached_value"

        result = await get_value()
        assert result == "cached_value"
