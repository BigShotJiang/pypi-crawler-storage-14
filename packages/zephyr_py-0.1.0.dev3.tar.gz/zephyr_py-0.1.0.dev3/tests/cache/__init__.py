"""Cache tests module."""
