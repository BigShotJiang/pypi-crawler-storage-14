"""Pytest fixtures for cache tests."""

from __future__ import annotations

import pytest

from zephyr.core.cache.memory import MemoryCacheBackend
from zephyr.core.cache.multi_level import MultiLevelCacheBackend


@pytest.fixture
def memory_cache():
    """Create a memory cache backend for testing."""
    cache = MemoryCacheBackend(max_size=100, default_ttl=300)
    yield cache
    # Cleanup
    import asyncio

    asyncio.run(cache.close())


@pytest.fixture
def multi_level_cache():
    """Create a multi-level cache backend for testing."""
    l1 = MemoryCacheBackend(max_size=50, default_ttl=300)
    l2 = MemoryCacheBackend(max_size=100, default_ttl=600)  # Use memory as L2 for tests
    cache = MultiLevelCacheBackend(l1_backend=l1, l2_backend=l2)
    yield cache
    # Cleanup
    import asyncio

    asyncio.run(cache.close())


@pytest.fixture
def sample_data():
    """Create sample data for caching tests."""
    return {
        "string": "hello world",
        "integer": 42,
        "float": 3.14,
        "boolean": True,
        "list": [1, 2, 3],
        "dict": {"nested": "value"},
        "none": None,
    }
