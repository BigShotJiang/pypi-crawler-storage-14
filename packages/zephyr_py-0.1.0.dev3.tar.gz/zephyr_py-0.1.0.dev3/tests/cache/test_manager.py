"""Tests for cache manager."""

from __future__ import annotations

import pytest

from zephyr.core.cache.exceptions import CacheError
from zephyr.core.cache.manager import CacheManager
from zephyr.core.cache.memory import MemoryCacheBackend


@pytest.mark.asyncio
@pytest.mark.cache
class TestCacheManager:
    """Test suite for CacheManager."""

    def test_singleton_pattern(self) -> None:
        """Test that CacheManager is a singleton."""
        manager1 = CacheManager()
        manager2 = CacheManager()
        assert manager1 is manager2

    def test_configure_memory_backend(self) -> None:
        """Test configuring memory backend."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory", default_ttl=300)

        assert manager is not None
        backend = manager.get_backend()
        assert isinstance(backend, MemoryCacheBackend)

    def test_configure_without_backend_raises_error(self) -> None:
        """Test that operations raise error without configured backend."""
        CacheManager.reset()
        manager = CacheManager()

        with pytest.raises(CacheError, match="Cache backend not configured"):
            manager.get_backend()

    def test_configure_redis_missing_url_raises_error(self) -> None:
        """Test that Redis backend requires URL."""
        CacheManager.reset()

        with pytest.raises(CacheError, match="redis_url required"):
            CacheManager.configure(backend_type="redis")

    def test_configure_multi_level_missing_url_raises_error(self) -> None:
        """Test that multi-level backend requires Redis URL."""
        CacheManager.reset()

        with pytest.raises(CacheError, match="redis_url required"):
            CacheManager.configure(backend_type="multi-level")

    def test_configure_unknown_backend_raises_error(self) -> None:
        """Test that unknown backend type raises error."""
        CacheManager.reset()

        with pytest.raises(CacheError, match="Unknown backend type"):
            CacheManager.configure(backend_type="unknown")

    async def test_get_set_delete(self) -> None:
        """Test get, set, and delete operations."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set("key1", "value1")
        result = await manager.get("key1")
        assert result == "value1"

        await manager.delete("key1")
        result = await manager.get("key1")
        assert result is None

    async def test_exists(self) -> None:
        """Test exists operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set("key1", "value1")
        assert await manager.exists("key1")
        assert not await manager.exists("missing")

    async def test_clear(self) -> None:
        """Test clear operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set_many({"key1": "value1", "key2": "value2"})
        await manager.clear()

        assert not await manager.exists("key1")
        assert not await manager.exists("key2")

    async def test_get_many(self) -> None:
        """Test get_many operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set_many({"key1": "value1", "key2": "value2"})
        result = await manager.get_many(["key1", "key2", "missing"])

        assert result == {"key1": "value1", "key2": "value2"}

    async def test_set_many(self) -> None:
        """Test set_many operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        data = {"key1": "value1", "key2": "value2"}
        await manager.set_many(data)

        for key, value in data.items():
            result = await manager.get(key)
            assert result == value

    async def test_delete_many(self) -> None:
        """Test delete_many operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set_many({"key1": "value1", "key2": "value2", "key3": "value3"})
        await manager.delete_many(["key1", "key2"])

        assert not await manager.exists("key1")
        assert not await manager.exists("key2")
        assert await manager.exists("key3")

    async def test_increment(self) -> None:
        """Test increment operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set("counter", 10)
        result = await manager.increment("counter", 5)

        assert result == 15

    async def test_decrement(self) -> None:
        """Test decrement operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set("counter", 10)
        result = await manager.decrement("counter", 3)

        assert result == 7

    async def test_health_check(self) -> None:
        """Test health_check operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        is_healthy = await manager.health_check()
        assert is_healthy is True

    async def test_health_check_without_backend(self) -> None:
        """Test health_check without configured backend."""
        CacheManager.reset()
        manager = CacheManager()

        is_healthy = await manager.health_check()
        assert is_healthy is False

    async def test_close(self) -> None:
        """Test close operation."""
        CacheManager.reset()
        manager = CacheManager.configure(backend_type="memory")

        await manager.set("key1", "value1")
        await manager.close()

        # After close, cache should be empty
        result = await manager.get("key1")
        assert result is None

    def test_reset(self) -> None:
        """Test reset operation."""
        manager1 = CacheManager.configure(backend_type="memory")
        CacheManager.reset()
        manager2 = CacheManager()

        # Should be able to create a new instance
        assert manager2 is not None
