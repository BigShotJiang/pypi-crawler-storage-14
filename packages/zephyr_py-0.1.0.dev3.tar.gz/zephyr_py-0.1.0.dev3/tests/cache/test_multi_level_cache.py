"""Tests for multi-level cache backend."""

from __future__ import annotations

import pytest

from zephyr.core.cache.memory import MemoryCacheBackend
from zephyr.core.cache.multi_level import MultiLevelCacheBackend


@pytest.mark.asyncio
@pytest.mark.cache
class TestMultiLevelCache:
    """Test suite for MultiLevelCacheBackend."""

    async def test_set_to_both_levels(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test that set writes to both L1 and L2."""
        await multi_level_cache.set("key1", "value1")

        # Check both levels have the value
        l1_result = await multi_level_cache._l1.get("key1")
        l2_result = await multi_level_cache._l2.get("key1")

        assert l1_result == "value1"
        assert l2_result == "value1"

    async def test_get_from_l1_first(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test that get tries L1 first."""
        await multi_level_cache.set("key1", "value1")
        result = await multi_level_cache.get("key1")
        assert result == "value1"

    async def test_get_from_l2_fallback(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test fallback to L2 when key not in L1."""
        # Set only in L2
        await multi_level_cache._l2.set("key1", "value1")

        # Get should find it in L2 and populate L1
        result = await multi_level_cache.get("key1")
        assert result == "value1"

        # Now it should be in L1 too
        l1_result = await multi_level_cache._l1.get("key1")
        assert l1_result == "value1"

    async def test_delete_from_both_levels(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test that delete removes from both L1 and L2."""
        await multi_level_cache.set("key1", "value1")
        await multi_level_cache.delete("key1")

        assert not await multi_level_cache._l1.exists("key1")
        assert not await multi_level_cache._l2.exists("key1")

    async def test_exists_checks_both_levels(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test that exists checks both L1 and L2."""
        # Only in L2
        await multi_level_cache._l2.set("key1", "value1")
        assert await multi_level_cache.exists("key1")

        # Both levels
        await multi_level_cache.set("key2", "value2")
        assert await multi_level_cache.exists("key2")

    async def test_clear_both_levels(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test that clear clears both L1 and L2."""
        await multi_level_cache.set_many({"key1": "value1", "key2": "value2"})
        await multi_level_cache.clear()

        assert not await multi_level_cache._l1.exists("key1")
        assert not await multi_level_cache._l2.exists("key1")
        assert not await multi_level_cache._l1.exists("key2")
        assert not await multi_level_cache._l2.exists("key2")

    async def test_get_many(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test getting multiple values from multi-level cache."""
        await multi_level_cache.set_many({"key1": "value1", "key2": "value2"})
        result = await multi_level_cache.get_many(["key1", "key2", "missing"])

        assert result == {"key1": "value1", "key2": "value2"}

    async def test_get_many_from_l2(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test getting multiple values from L2."""
        # Set only in L2
        await multi_level_cache._l2.set_many({"key1": "value1", "key2": "value2"})

        result = await multi_level_cache.get_many(["key1", "key2"])

        # Should be found and populated to L1
        assert result == {"key1": "value1", "key2": "value2"}
        assert await multi_level_cache._l1.exists("key1")
        assert await multi_level_cache._l1.exists("key2")

    async def test_set_many(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test setting multiple values."""
        data = {"key1": "value1", "key2": "value2", "key3": "value3"}
        await multi_level_cache.set_many(data)

        for key, value in data.items():
            l1_result = await multi_level_cache._l1.get(key)
            l2_result = await multi_level_cache._l2.get(key)
            assert l1_result == value
            assert l2_result == value

    async def test_delete_many(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test deleting multiple values."""
        await multi_level_cache.set_many({"key1": "value1", "key2": "value2", "key3": "value3"})
        await multi_level_cache.delete_many(["key1", "key2"])

        assert not await multi_level_cache.exists("key1")
        assert not await multi_level_cache.exists("key2")
        assert await multi_level_cache.exists("key3")

    async def test_increment(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test incrementing a value."""
        await multi_level_cache.set("counter", 10)
        result = await multi_level_cache.increment("counter", 5)

        assert result == 15
        l1_result = await multi_level_cache._l1.get("counter")
        l2_result = await multi_level_cache._l2.get("counter")
        assert l1_result == 15
        assert l2_result == 15

    async def test_decrement(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test decrementing a value."""
        await multi_level_cache.set("counter", 10)
        result = await multi_level_cache.decrement("counter", 3)

        assert result == 7

    async def test_health_check(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test health check."""
        is_healthy = await multi_level_cache.health_check()
        assert is_healthy is True

    async def test_close(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test closing cache."""
        await multi_level_cache.set("key1", "value1")
        await multi_level_cache.close()

        # After close, caches should be empty
        l1_exists = await multi_level_cache._l1.exists("key1")
        l2_exists = await multi_level_cache._l2.exists("key1")
        assert not l1_exists
        assert not l2_exists

    async def test_write_through_strategy(self, multi_level_cache: MultiLevelCacheBackend) -> None:
        """Test write-through strategy."""
        assert multi_level_cache._write_through is True

        await multi_level_cache.set("key1", "value1")

        # Both levels should have the value
        assert await multi_level_cache._l1.exists("key1")
        assert await multi_level_cache._l2.exists("key1")

    async def test_l2_failure_graceful_degradation(self) -> None:
        """Test graceful degradation when L2 fails."""
        l1 = MemoryCacheBackend(max_size=50, default_ttl=300)
        l2 = MemoryCacheBackend(max_size=100, default_ttl=600)
        cache = MultiLevelCacheBackend(l1_backend=l1, l2_backend=l2)

        try:
            # Close L2 to simulate failure
            await l2.close()

            # Set should still work with L1
            await cache.set("key1", "value1")

            # Get should still work with L1
            result = await cache.get("key1")
            assert result == "value1"
        finally:
            await cache.close()
