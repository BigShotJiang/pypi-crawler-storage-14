"""Database abstraction layer tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from abc import ABC


class TestDatabaseBackendInterface:
    """Test database backend abstraction interface."""

    @pytest.mark.asyncio
    async def test_import_database_backend_abc(self) -> None:
        """Test DatabaseBackend ABC can be imported."""
        from zephyr.db.backends.base import DatabaseBackend

        assert DatabaseBackend is not None
        assert issubclass(DatabaseBackend, ABC)

    @pytest.mark.asyncio
    async def test_database_backend_has_initialize(self) -> None:
        """Test DatabaseBackend has initialize method."""
        from zephyr.db.backends.base import DatabaseBackend

        assert hasattr(DatabaseBackend, "initialize")
        assert hasattr(DatabaseBackend.initialize, "__isabstractmethod__")

    @pytest.mark.asyncio
    async def test_database_backend_has_shutdown(self) -> None:
        """Test DatabaseBackend has shutdown method."""
        from zephyr.db.backends.base import DatabaseBackend

        assert hasattr(DatabaseBackend, "shutdown")
        assert hasattr(DatabaseBackend.shutdown, "__isabstractmethod__")

    @pytest.mark.asyncio
    async def test_database_backend_has_get_session(self) -> None:
        """Test DatabaseBackend has get_session method."""
        from zephyr.db.backends.base import DatabaseBackend

        assert hasattr(DatabaseBackend, "get_session")
        assert hasattr(DatabaseBackend.get_session, "__isabstractmethod__")

    @pytest.mark.asyncio
    async def test_database_backend_has_health_check(self) -> None:
        """Test DatabaseBackend has health_check method."""
        from zephyr.db.backends.base import DatabaseBackend

        assert hasattr(DatabaseBackend, "health_check")
        assert hasattr(DatabaseBackend.health_check, "__isabstractmethod__")

    @pytest.mark.asyncio
    async def test_import_sqlalchemy_backend(self) -> None:
        """Test SQLAlchemy backend implementation can be imported."""
        from zephyr.db.backends.sqlalchemy_backend import SQLAlchemyBackend

        assert SQLAlchemyBackend is not None

    @pytest.mark.asyncio
    async def test_sqlalchemy_backend_is_database_backend(self) -> None:
        """Test SQLAlchemy backend implements DatabaseBackend interface."""
        from zephyr.db.backends.base import DatabaseBackend
        from zephyr.db.backends.sqlalchemy_backend import SQLAlchemyBackend

        assert issubclass(SQLAlchemyBackend, DatabaseBackend)

    @pytest.mark.asyncio
    async def test_backend_factory_pattern(self) -> None:
        """Test BackendFactory can create backends."""
        from zephyr.db.backends.factory import BackendFactory

        assert BackendFactory is not None
        assert hasattr(BackendFactory, "create")

    @pytest.mark.asyncio
    async def test_backend_factory_creates_sqlalchemy(self) -> None:
        """Test BackendFactory creates SQLAlchemy backend."""
        from zephyr.db.backends.factory import BackendFactory
        from zephyr.db.backends.base import DatabaseBackend
        from tests.db.conftest import TEST_DATABASE_URL

        backend = BackendFactory.create("sqlalchemy", TEST_DATABASE_URL)
        assert isinstance(backend, DatabaseBackend)

    @pytest.mark.asyncio
    async def test_backend_factory_supported_backends(self) -> None:
        """Test BackendFactory knows supported backends."""
        from zephyr.db.backends.factory import BackendFactory

        backends = BackendFactory.get_supported_backends()
        assert "sqlalchemy" in backends

    @pytest.mark.asyncio
    async def test_session_interface(self) -> None:
        """Test Session interface abstraction."""
        from zephyr.db.session import Session

        assert Session is not None
        assert hasattr(Session, "execute")
        assert hasattr(Session, "commit")
        assert hasattr(Session, "rollback")

    @pytest.mark.asyncio
    async def test_import_connection_manager(self) -> None:
        """Test ConnectionManager can be imported."""
        from zephyr.db.connection import ConnectionManager

        assert ConnectionManager is not None

    @pytest.mark.asyncio
    async def test_connection_manager_backend_agnostic(self) -> None:
        """Test ConnectionManager is backend-agnostic."""
        from zephyr.db.connection import ConnectionManager
        from tests.db.conftest import TEST_DATABASE_URL

        # Should work with any backend
        manager = ConnectionManager(database_url=TEST_DATABASE_URL, backend_type="sqlalchemy")
        assert manager is not None

    @pytest.mark.asyncio
    async def test_connection_manager_accepts_backend_type(self) -> None:
        """Test ConnectionManager accepts backend_type parameter."""
        from zephyr.db.connection import ConnectionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = ConnectionManager(database_url=TEST_DATABASE_URL, backend_type="sqlalchemy")

        assert hasattr(manager, "backend_type")
        assert manager.backend_type == "sqlalchemy"

    @pytest.mark.asyncio
    async def test_connection_manager_can_switch_backends(self) -> None:
        """Test ConnectionManager can work with different backends."""
        from zephyr.db.connection import ConnectionManager
        from tests.db.conftest import TEST_DATABASE_URL

        # SQLAlchemy backend
        manager = ConnectionManager(database_url=TEST_DATABASE_URL, backend_type="sqlalchemy")
        assert manager.backend_type == "sqlalchemy"

        # Future backends should work the same way
        # manager2 = ConnectionManager(url, backend_type="future_backend")

    @pytest.mark.asyncio
    async def test_abstraction_in_public_api(self) -> None:
        """Test abstraction interfaces are in public API."""
        from zephyr import db

        # These should be available but implementation-agnostic
        assert hasattr(db, "ConnectionManager")
        assert hasattr(db, "Session")
        assert hasattr(db, "BaseModel")

    @pytest.mark.asyncio
    async def test_backend_specific_not_in_public_api(self) -> None:
        """Test backend-specific code is NOT in public API."""
        from zephyr import db

        # These should NOT be directly imported from main db module
        # (they're in zephyr.db.backends.sqlalchemy_backend)
        assert not hasattr(db, "SQLAlchemy")
        assert not hasattr(db, "AsyncSession")


class TestBackendSwappability:
    """Test backends are truly swappable."""

    @pytest.mark.asyncio
    async def test_backend_swap_at_runtime(self) -> None:
        """Test backend can be swapped at runtime."""
        from zephyr.db.backends.factory import BackendFactory
        from tests.db.conftest import TEST_DATABASE_URL

        # Create with SQLAlchemy
        backend1 = BackendFactory.create("sqlalchemy", TEST_DATABASE_URL)
        assert backend1 is not None

        # Create with different backend (when available)
        # This tests the interface is consistent
        backend2 = BackendFactory.create("sqlalchemy", TEST_DATABASE_URL)
        assert backend2 is not None

        # Both should have same interface
        assert hasattr(backend1, "initialize")
        assert hasattr(backend2, "initialize")

    @pytest.mark.asyncio
    async def test_backend_registration(self) -> None:
        """Test backends can be registered dynamically."""
        from zephyr.db.backends.factory import BackendFactory

        # Should be able to register new backends
        if hasattr(BackendFactory, "register"):
            assert callable(BackendFactory.register)

    @pytest.mark.asyncio
    async def test_no_sqlalchemy_imports_in_models(self) -> None:
        """Test models don't directly import SQLAlchemy."""
        # Models should use zephyr.db abstractions, not SQLAlchemy directly
        # This will be validated in model tests

        from zephyr.db import BaseModel

        assert BaseModel is not None
