"""Database test fixtures and configuration.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import asyncio
import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from collections.abc import AsyncGenerator

# Test database URL (in-memory SQLite)
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"


@pytest.fixture(scope="session")
def event_loop() -> asyncio.AbstractEventLoop:
    """Create event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def test_engine():
    """Create test database engine."""
    engine = create_async_engine(
        TEST_DATABASE_URL,
        echo=False,
        connect_args={"check_same_thread": False},
    )
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def test_session_factory(test_engine):
    """Create test session factory."""
    async_session = sessionmaker(test_engine, class_=AsyncSession, expire_on_commit=False)
    return async_session


@pytest_asyncio.fixture
async def test_session(test_session_factory) -> AsyncGenerator[AsyncSession, None]:
    """Get test database session."""
    async with test_session_factory() as session:
        yield session
        await session.rollback()
        await session.close()


@pytest.fixture
def sample_user_data() -> dict:
    """Sample user data for testing."""
    return {
        "email": "test@example.com",
        "username": "testuser",
        "password_hash": "hashed_password_123",
        "full_name": "Test User",
        "bio": "Test bio",
        "role": "student",
        "is_active": True,
    }


@pytest.fixture
def sample_course_data() -> dict:
    """Sample course data for testing."""
    return {
        "title": "Python 101",
        "description": "Learn Python basics",
        "slug": "python-101",
        "category": "programming",
        "is_published": False,
        "thumbnail_url": "https://example.com/thumb.jpg",
    }


@pytest.fixture
def sample_lesson_data() -> dict:
    """Sample lesson data for testing."""
    return {
        "title": "Variables and Types",
        "content": "Introduction to Python variables",
        "video_url": "https://example.com/video.mp4",
        "order": 1,
        "duration_minutes": 15,
    }
