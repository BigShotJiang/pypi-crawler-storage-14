"""Database connection and pooling tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession


class TestDatabaseConnection:
    """Test database connection functionality."""

    @pytest.mark.asyncio
    async def test_import_database_connection(self) -> None:
        """Test DatabaseConnection can be imported."""
        from zephyr.db.connection import DatabaseConnection

        assert DatabaseConnection is not None

    @pytest.mark.asyncio
    async def test_database_connection_init(self) -> None:
        """Test DatabaseConnection initialization."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        assert conn is not None
        assert conn.database_url == TEST_DATABASE_URL

    @pytest.mark.asyncio
    async def test_database_connection_initialize(self) -> None:
        """Test DatabaseConnection.initialize() method."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        await conn.initialize()

        # Backend should be initialized
        assert conn.backend is not None

        await conn.shutdown()

    @pytest.mark.asyncio
    async def test_database_connection_get_session(self) -> None:
        """Test DatabaseConnection.get_session() context manager."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        await conn.initialize()

        async with conn.get_session() as session:
            assert isinstance(session, AsyncSession)

        await conn.shutdown()

    @pytest.mark.asyncio
    async def test_database_connection_health_check(self) -> None:
        """Test DatabaseConnection.health_check() method."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        await conn.initialize()

        health = await conn.health_check()
        # Health check should return boolean
        assert isinstance(health, bool)

        await conn.shutdown()

    @pytest.mark.asyncio
    async def test_database_connection_shutdown(self) -> None:
        """Test DatabaseConnection.shutdown() method."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        await conn.initialize()

        # Shutdown should not raise
        await conn.shutdown()
        # Backend should be None after shutdown
        assert conn.backend is None

    @pytest.mark.asyncio
    async def test_database_connection_pool_size(self) -> None:
        """Test DatabaseConnection respects pool_size setting."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL, pool_size=10)
        await conn.initialize()

        # Check that connection is initialized with backend
        assert conn.backend is not None

        await conn.shutdown()

    @pytest.mark.asyncio
    async def test_database_connection_health_check_failure(self) -> None:
        """Test DatabaseConnection.health_check() with invalid DB."""
        from zephyr.db.connection import DatabaseConnection

        conn = DatabaseConnection("sqlite+aiosqlite:////invalid/path/db.db")
        await conn.initialize()

        # Health check may fail for invalid path
        health = await conn.health_check()
        # Don't assert, just ensure method doesn't crash

        await conn.shutdown()

    @pytest.mark.asyncio
    async def test_database_connection_multiple_get_session(self) -> None:
        """Test DatabaseConnection can provide multiple sessions."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        await conn.initialize()

        async with conn.get_session() as session1, conn.get_session() as session2:
            assert isinstance(session1, AsyncSession)
            assert isinstance(session2, AsyncSession)
            assert session1 is not session2

        await conn.shutdown()

    @pytest.mark.asyncio
    async def test_database_connection_in_zephyr_db_init(self) -> None:
        """Test DatabaseConnection is exported from zephyr.db.__init__."""
        from zephyr.db import DatabaseConnection

        assert DatabaseConnection is not None

    @pytest.mark.asyncio
    async def test_database_connection_properties(self) -> None:
        """Test DatabaseConnection has required properties."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)

        assert hasattr(conn, "database_url")
        assert hasattr(conn, "engine")
        assert hasattr(conn, "session_factory")
        assert hasattr(conn, "initialize")
        assert hasattr(conn, "shutdown")
        assert hasattr(conn, "get_session")
        assert hasattr(conn, "health_check")

    @pytest.mark.asyncio
    async def test_database_connection_echo_setting(self) -> None:
        """Test DatabaseConnection respects echo setting."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL, echo=True)
        await conn.initialize()

        assert conn.backend is not None

        await conn.shutdown()


class TestConnectionPool:
    """Test connection pooling functionality."""

    @pytest.mark.asyncio
    async def test_import_connection_pool_utilities(self) -> None:
        """Test connection pool utilities can be imported."""
        from zephyr.db.pool import PoolConfig

        assert PoolConfig is not None

    @pytest.mark.asyncio
    async def test_pool_config_defaults(self) -> None:
        """Test PoolConfig has sensible defaults."""
        from zephyr.db.pool import PoolConfig

        config = PoolConfig()
        assert config.pool_size >= 5
        assert config.max_overflow >= 5
        assert config.pool_timeout > 0
        assert config.pool_recycle > 0

    @pytest.mark.asyncio
    async def test_pool_config_custom_values(self) -> None:
        """Test PoolConfig accepts custom values."""
        from zephyr.db.pool import PoolConfig

        config = PoolConfig(pool_size=30, max_overflow=20)
        assert config.pool_size == 30
        assert config.max_overflow == 20

    @pytest.mark.asyncio
    async def test_pool_stats(self) -> None:
        """Test pool statistics tracking."""
        from zephyr.db.connection import DatabaseConnection
        from tests.db.conftest import TEST_DATABASE_URL

        conn = DatabaseConnection(TEST_DATABASE_URL)
        await conn.initialize()

        # Get multiple sessions to exercise pool
        async with conn.get_session(), conn.get_session():
            pass

        # Connection should still be valid
        assert conn.backend is not None

        await conn.shutdown()
