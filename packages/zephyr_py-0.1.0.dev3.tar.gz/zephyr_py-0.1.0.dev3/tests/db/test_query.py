"""Query builder tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.asyncio import AsyncSession


class TestQueryBuilder:
    """Test query builder functionality."""

    @pytest.mark.asyncio
    async def test_import_query_builder(self) -> None:
        """Test QueryBuilder can be imported."""
        from zephyr.db.query import QueryBuilder

        assert QueryBuilder is not None

    @pytest.mark.asyncio
    async def test_create_query_builder(self) -> None:
        """Test creating query builder instance."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_model_1"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)
        assert builder is not None
        assert builder.model == TestModel

    @pytest.mark.asyncio
    async def test_query_builder_has_methods(self) -> None:
        """Test QueryBuilder has all required methods."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_model_2"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)
        methods = [
            "filter",
            "filter_by",
            "order_by",
            "limit",
            "offset",
            "all",
            "first",
            "one",
            "count",
            "join",
            "distinct",
            "group_by",
        ]
        for method in methods:
            assert hasattr(builder, method), f"Missing method: {method}"
            assert callable(getattr(builder, method))

    @pytest.mark.asyncio
    async def test_query_builder_method_chaining(self) -> None:
        """Test method chaining."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class User(BaseModel):
            __tablename__ = "users_chaining"
            id = Column(Integer, primary_key=True)
            email = Column(String(255))

        builder = QueryBuilder(User)
        # Should support chaining
        result = builder.filter_by(email="test@example.com").limit(10).offset(5)
        assert result is not None
        assert result is builder  # Should return self

    @pytest.mark.asyncio
    async def test_query_builder_in_zephyr_db_init(self) -> None:
        """Test QueryBuilder is exported from zephyr.db.__init__."""
        from zephyr.db import QueryBuilder

        assert QueryBuilder is not None

    @pytest.mark.asyncio
    async def test_query_builder_limit_validation(self) -> None:
        """Test limit validates input."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_limit_validation"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)
        with pytest.raises(ValueError):
            builder.limit(-1)

    @pytest.mark.asyncio
    async def test_query_builder_offset_validation(self) -> None:
        """Test offset validates input."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_offset_validation"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)
        with pytest.raises(ValueError):
            builder.offset(-1)

    @pytest.mark.asyncio
    async def test_query_builder_with_session(self, test_session: AsyncSession) -> None:
        """Test QueryBuilder with actual session."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class SessionModel(BaseModel):
            __tablename__ = "session_model_test"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(SessionModel, session=test_session)
        assert builder.session == test_session

    @pytest.mark.asyncio
    async def test_query_builder_filter_by_invalid_column(self) -> None:
        """Test filter_by raises error for invalid column."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class User(BaseModel):
            __tablename__ = "users_invalid_col"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(User)
        with pytest.raises(AttributeError):
            builder.filter_by(nonexistent="value")

    @pytest.mark.asyncio
    async def test_query_builder_all_requires_session(self) -> None:
        """Test all() requires session."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_no_session"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)  # No session
        with pytest.raises(RuntimeError):
            await builder.all()

    @pytest.mark.asyncio
    async def test_query_builder_first_requires_session(self) -> None:
        """Test first() requires session."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_first_session"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)  # No session
        with pytest.raises(RuntimeError):
            await builder.first()

    @pytest.mark.asyncio
    async def test_query_builder_count_requires_session(self) -> None:
        """Test count() requires session."""
        from zephyr.db.query import QueryBuilder
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            __tablename__ = "test_count_session"
            id = Column(Integer, primary_key=True)

        builder = QueryBuilder(TestModel)  # No session
        with pytest.raises(RuntimeError):
            await builder.count()
