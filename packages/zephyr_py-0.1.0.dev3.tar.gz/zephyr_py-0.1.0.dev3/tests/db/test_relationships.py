"""Relationship management tests (lazy/eager loading, cascades).

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship


class TestRelationships:
    """Test relationship functionality."""

    @pytest.mark.asyncio
    async def test_import_relationship_manager(self) -> None:
        """Test RelationshipManager can be imported."""
        from zephyr.db.relationships import RelationshipManager

        assert RelationshipManager is not None

    @pytest.mark.asyncio
    async def test_lazy_loading_enum(self) -> None:
        """Test LazyLoadStrategy enum."""
        from zephyr.db.relationships import LazyLoadStrategy

        assert hasattr(LazyLoadStrategy, "LAZY")
        assert hasattr(LazyLoadStrategy, "EAGER")
        assert hasattr(LazyLoadStrategy, "SUBQUERY")

    @pytest.mark.asyncio
    async def test_cascade_strategy_enum(self) -> None:
        """Test CascadeStrategy enum."""
        from zephyr.db.relationships import CascadeStrategy

        assert hasattr(CascadeStrategy, "SAVE_UPDATE")
        assert hasattr(CascadeStrategy, "DELETE")
        assert hasattr(CascadeStrategy, "ALL")

    @pytest.mark.asyncio
    async def test_relationship_config(self) -> None:
        """Test RelationshipConfig dataclass."""
        from zephyr.db.relationships import RelationshipConfig, LazyLoadStrategy

        config = RelationshipConfig(
            lazy_strategy=LazyLoadStrategy.LAZY,
            cascade_delete=True,
        )
        assert config is not None
        assert config.lazy_strategy == LazyLoadStrategy.LAZY
        assert config.cascade_delete is True

    @pytest.mark.asyncio
    async def test_one_to_many_relationship(self) -> None:
        """Test 1-N relationship definition."""
        from zephyr.db.base import BaseModel

        class Author(BaseModel):
            __tablename__ = "authors_rel"
            id = Column(Integer, primary_key=True)
            name = Column(String(255))
            books = relationship("Book", back_populates="author")

        class Book(BaseModel):
            __tablename__ = "books_rel"
            id = Column(Integer, primary_key=True)
            title = Column(String(255))
            author_id = Column(Integer, ForeignKey("authors_rel.id"))
            author = relationship("Author", back_populates="books")

        assert hasattr(Author, "books")
        assert hasattr(Book, "author")

    @pytest.mark.asyncio
    async def test_many_to_many_relationship(self) -> None:
        """Test N-N relationship definition."""
        from zephyr.db.base import BaseModel
        from sqlalchemy import Table

        association_table = Table(
            "student_course",
            BaseModel.metadata,
            Column("student_id", Integer, ForeignKey("students_rel.id")),
            Column("course_id", Integer, ForeignKey("courses_rel.id")),
        )

        class Student(BaseModel):
            __tablename__ = "students_rel"
            id = Column(Integer, primary_key=True)
            name = Column(String(255))
            courses = relationship(
                "Course",
                secondary=association_table,
                back_populates="students",
            )

        class Course(BaseModel):
            __tablename__ = "courses_rel"
            id = Column(Integer, primary_key=True)
            title = Column(String(255))
            students = relationship(
                "Student",
                secondary=association_table,
                back_populates="courses",
            )

        assert hasattr(Student, "courses")
        assert hasattr(Course, "students")

    @pytest.mark.asyncio
    async def test_one_to_one_relationship(self) -> None:
        """Test 1-1 relationship definition."""
        from zephyr.db.base import BaseModel

        class User(BaseModel):
            __tablename__ = "users_1to1"
            id = Column(Integer, primary_key=True)
            email = Column(String(255))
            profile = relationship("Profile", back_populates="user", uselist=False)

        class Profile(BaseModel):
            __tablename__ = "profiles_1to1"
            id = Column(Integer, primary_key=True)
            bio = Column(String(500))
            user_id = Column(Integer, ForeignKey("users_1to1.id"))
            user = relationship("User", back_populates="profile")

        assert hasattr(User, "profile")
        assert hasattr(Profile, "user")

    @pytest.mark.asyncio
    async def test_relationship_manager_get_load_strategy(self) -> None:
        """Test getting load strategy from RelationshipManager."""
        from zephyr.db.relationships import RelationshipManager, LazyLoadStrategy

        manager = RelationshipManager()
        strategy = manager.get_load_strategy(LazyLoadStrategy.LAZY)
        assert strategy is not None

    @pytest.mark.asyncio
    async def test_relationship_manager_configure_cascade(self) -> None:
        """Test configuring cascade settings."""
        from zephyr.db.relationships import RelationshipManager, CascadeStrategy

        manager = RelationshipManager()
        cascade_str = manager.configure_cascade(CascadeStrategy.DELETE)
        assert "delete" in cascade_str.lower()

    @pytest.mark.asyncio
    async def test_relationship_in_zephyr_db_init(self) -> None:
        """Test relationship utilities exported from zephyr.db."""
        from zephyr.db import RelationshipManager

        assert RelationshipManager is not None

    @pytest.mark.asyncio
    async def test_cascade_all_strategy(self) -> None:
        """Test CASCADE ALL strategy includes all operations."""
        from zephyr.db.relationships import RelationshipManager, CascadeStrategy

        manager = RelationshipManager()
        cascade_str = manager.configure_cascade(CascadeStrategy.ALL)
        # Should include multiple cascade options
        assert cascade_str is not None
        assert len(cascade_str) > 0

    @pytest.mark.asyncio
    async def test_relationship_config_defaults(self) -> None:
        """Test RelationshipConfig has sensible defaults."""
        from zephyr.db.relationships import RelationshipConfig, LazyLoadStrategy

        config = RelationshipConfig()
        assert config.lazy_strategy == LazyLoadStrategy.LAZY
        assert config.cascade_delete is False
