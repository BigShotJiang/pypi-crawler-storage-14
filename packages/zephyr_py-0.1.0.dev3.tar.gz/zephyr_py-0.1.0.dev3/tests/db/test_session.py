"""Session management tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession


class TestSessionManager:
    """Test session management functionality."""

    @pytest.mark.asyncio
    async def test_import_session_manager(self) -> None:
        """Test SessionManager can be imported."""
        from zephyr.db.session import SessionManager

        assert SessionManager is not None

    @pytest.mark.asyncio
    async def test_session_manager_init(self) -> None:
        """Test SessionManager initialization."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        assert manager is not None
        assert manager.database_url == TEST_DATABASE_URL

    @pytest.mark.asyncio
    async def test_session_manager_initialize(self) -> None:
        """Test SessionManager.initialize() method."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        assert manager.backend is not None

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_manager_get_session(self) -> None:
        """Test SessionManager.get_session() context manager."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        async with manager.get_session() as session:
            assert isinstance(session, AsyncSession)

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_manager_multiple_sessions(self) -> None:
        """Test SessionManager can create multiple sessions."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        async with manager.get_session() as session1:
            assert isinstance(session1, AsyncSession)

            async with manager.get_session() as session2:
                assert isinstance(session2, AsyncSession)
                # Sessions should be different instances
                assert session1 is not session2

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_manager_shutdown(self) -> None:
        """Test SessionManager.shutdown() method."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        # Should shutdown cleanly
        await manager.shutdown()
        assert manager.backend is None

    @pytest.mark.asyncio
    async def test_session_manager_double_initialize(self) -> None:
        """Test SessionManager handles double initialization."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        backend1 = manager.backend

        await manager.initialize()

        backend2 = manager.backend

        # Should be different backends
        assert backend1 is not backend2

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_manager_session_cleanup(self) -> None:
        """Test sessions are properly closed after context."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        session_ref = None

        async with manager.get_session() as session:
            session_ref = session
            assert not session.is_active or session.sync_session_class is not None

        # Session should be closed after context
        # Note: AsyncSession may not have is_active in all versions

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_manager_error_handling(self) -> None:
        """Test SessionManager handles errors gracefully."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)
        await manager.initialize()

        try:
            async with manager.get_session() as session:
                # Simulate an error
                raise ValueError("Test error")
        except ValueError:
            pass  # Expected

        # Manager should still be functional
        async with manager.get_session() as session:
            assert isinstance(session, AsyncSession)

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_session_manager_in_zephyr_db_init(self) -> None:
        """Test SessionManager is exported from zephyr.db.__init__."""
        from zephyr.db import SessionManager

        assert SessionManager is not None

    @pytest.mark.asyncio
    async def test_session_manager_properties(self) -> None:
        """Test SessionManager has required properties."""
        from zephyr.db.session import SessionManager
        from tests.db.conftest import TEST_DATABASE_URL

        manager = SessionManager(TEST_DATABASE_URL)

        assert hasattr(manager, "database_url")
        assert hasattr(manager, "engine")
        assert hasattr(manager, "session_factory")
        assert hasattr(manager, "initialize")
        assert hasattr(manager, "shutdown")
        assert hasattr(manager, "get_session")
