"""Health check tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession


class TestHealthChecks:
    """Test health check functionality."""

    @pytest.mark.asyncio
    async def test_import_health_checker(self) -> None:
        """Test HealthChecker can be imported."""
        from zephyr.db.health import HealthChecker

        assert HealthChecker is not None

    @pytest.mark.asyncio
    async def test_health_checker_init(self, test_session: AsyncSession) -> None:
        """Test HealthChecker initialization."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        assert checker is not None
        assert checker.session == test_session

    @pytest.mark.asyncio
    async def test_check_connection_method(self, test_session: AsyncSession) -> None:
        """Test check_connection method."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        assert hasattr(checker, "check_connection")
        assert callable(checker.check_connection)

    @pytest.mark.asyncio
    async def test_check_transaction_method(self, test_session: AsyncSession) -> None:
        """Test check_transaction method."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        assert hasattr(checker, "check_transaction")
        assert callable(checker.check_transaction)

    @pytest.mark.asyncio
    async def test_full_health_check(self, test_session: AsyncSession) -> None:
        """Test full_check method."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        assert hasattr(checker, "full_check")
        assert callable(checker.full_check)

    @pytest.mark.asyncio
    async def test_connection_check_result(self, test_session: AsyncSession) -> None:
        """Test connection check returns dict."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        result = await checker.check_connection()
        assert isinstance(result, dict)
        assert "status" in result

    @pytest.mark.asyncio
    async def test_transaction_check_result(self, test_session: AsyncSession) -> None:
        """Test transaction check returns dict."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        result = await checker.check_transaction()
        assert isinstance(result, dict)
        assert "status" in result

    @pytest.mark.asyncio
    async def test_full_check_result(self, test_session: AsyncSession) -> None:
        """Test full check returns comprehensive result."""
        from zephyr.db.health import HealthChecker

        checker = HealthChecker(test_session)
        result = await checker.full_check()
        assert isinstance(result, dict)
        assert "status" in result
        assert "checks" in result

    @pytest.mark.asyncio
    async def test_health_checker_in_db_init(self) -> None:
        """Test HealthChecker exported from zephyr.db."""
        from zephyr.db import HealthChecker

        assert HealthChecker is not None

    @pytest.mark.asyncio
    async def test_health_status_enum(self) -> None:
        """Test HealthStatus enum."""
        from zephyr.db.health import HealthStatus

        assert hasattr(HealthStatus, "HEALTHY")
        assert hasattr(HealthStatus, "DEGRADED")
        assert hasattr(HealthStatus, "UNHEALTHY")
