"""Database ORM tests module.

Author: AM
Created At: 21 Nov 2025
"""
