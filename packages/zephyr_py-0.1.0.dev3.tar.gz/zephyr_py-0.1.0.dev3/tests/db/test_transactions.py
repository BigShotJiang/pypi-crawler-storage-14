"""Transaction management tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession


class TestTransaction:
    """Test transaction functionality."""

    @pytest.mark.asyncio
    async def test_import_transaction_manager(self) -> None:
        """Test TransactionManager can be imported."""
        from zephyr.db.transactions import TransactionManager

        assert TransactionManager is not None

    @pytest.mark.asyncio
    async def test_create_transaction_manager(self, test_session: AsyncSession) -> None:
        """Test creating transaction manager."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)
        assert manager is not None
        assert manager.session == test_session

    @pytest.mark.asyncio
    async def test_transaction_begin_method(self, test_session: AsyncSession) -> None:
        """Test begin() context manager."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)
        assert hasattr(manager, "begin")
        assert callable(manager.begin)

    @pytest.mark.asyncio
    async def test_transaction_commit_method(self, test_session: AsyncSession) -> None:
        """Test commit() method."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)
        assert hasattr(manager, "commit")
        assert callable(manager.commit)

    @pytest.mark.asyncio
    async def test_transaction_rollback_method(self, test_session: AsyncSession) -> None:
        """Test rollback() method."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)
        assert hasattr(manager, "rollback")
        assert callable(manager.rollback)

    @pytest.mark.asyncio
    async def test_transaction_savepoint_method(self, test_session: AsyncSession) -> None:
        """Test savepoint() method."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)
        assert hasattr(manager, "savepoint")
        assert callable(manager.savepoint)

    @pytest.mark.asyncio
    async def test_transaction_begin_context(self, test_session: AsyncSession) -> None:
        """Test begin() context manager returns session."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)

        # begin() should be an async context manager
        async with manager.begin() as session:
            assert session is not None

    @pytest.mark.asyncio
    async def test_transaction_in_zephyr_db_init(self) -> None:
        """Test TransactionManager is exported from zephyr.db."""
        from zephyr.db import TransactionManager

        assert TransactionManager is not None

    @pytest.mark.asyncio
    async def test_transaction_error_handling(self, test_session: AsyncSession) -> None:
        """Test transaction handles errors gracefully."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)

        # Should handle exceptions without crashing
        try:
            async with manager.begin() as session:
                raise ValueError("Test error")
        except ValueError:
            pass  # Expected

        # Manager should still be functional
        assert manager.session is not None

    @pytest.mark.asyncio
    async def test_transaction_nested(self, test_session: AsyncSession) -> None:
        """Test nested transactions with savepoints."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)

        # Nested transactions should work
        async with manager.begin() as session1, manager.savepoint() as session2:
            assert session2 is not None

    @pytest.mark.asyncio
    async def test_transaction_multiple_operations(self, test_session: AsyncSession) -> None:
        """Test transaction with multiple operations."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)

        async with manager.begin() as session:
            # Should be able to perform operations
            assert session is not None

    @pytest.mark.asyncio
    async def test_transaction_commit_called_on_success(self, test_session: AsyncSession) -> None:
        """Test commit is called on successful transaction."""
        from zephyr.db.transactions import TransactionManager

        manager = TransactionManager(test_session)

        # Successful transaction should not raise
        async with manager.begin() as session:
            assert session is not None
