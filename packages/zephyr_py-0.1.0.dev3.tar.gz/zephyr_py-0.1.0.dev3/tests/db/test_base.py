"""Base model tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

import pytest
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.asyncio import AsyncSession


class TestBaseModel:
    """Test BaseModel functionality."""

    @pytest.mark.asyncio
    async def test_import_base_model(self) -> None:
        """Test BaseModel can be imported."""
        from zephyr.db.base import BaseModel

        assert BaseModel is not None

    @pytest.mark.asyncio
    async def test_import_base_declarative(self) -> None:
        """Test declarative_base can be imported."""
        from zephyr.db.base import Base

        assert Base is not None

    @pytest.mark.asyncio
    async def test_base_model_is_abstract(self) -> None:
        """Test BaseModel is abstract."""
        from zephyr.db.base import BaseModel

        # BaseModel should not be directly instantiable
        assert hasattr(BaseModel, "__abstract__")

    @pytest.mark.asyncio
    async def test_base_model_has_created_at(self) -> None:
        """Test BaseModel has created_at column."""
        from zephyr.db.base import BaseModel

        # Check that created_at exists in the model
        assert hasattr(BaseModel, "created_at")

    @pytest.mark.asyncio
    async def test_base_model_has_updated_at(self) -> None:
        """Test BaseModel has updated_at column."""
        from zephyr.db.base import BaseModel

        # Check that updated_at exists in the model
        assert hasattr(BaseModel, "updated_at")

    @pytest.mark.asyncio
    async def test_create_concrete_model(self, test_session: AsyncSession) -> None:
        """Test creating a concrete model from BaseModel."""
        from zephyr.db.base import BaseModel

        class TestModel(BaseModel):
            """Test concrete model."""

            __tablename__ = "test_models"
            id = Column(Integer, primary_key=True)
            name = Column(String(255))

        # Should be creatable
        assert TestModel is not None
        assert hasattr(TestModel, "created_at")
        assert hasattr(TestModel, "updated_at")

    @pytest.mark.asyncio
    async def test_base_model_timestamps_type(self) -> None:
        """Test BaseModel timestamps are datetime."""
        from zephyr.db.base import BaseModel

        # created_at should exist
        assert hasattr(BaseModel, "created_at")
        assert hasattr(BaseModel, "updated_at")

    @pytest.mark.asyncio
    async def test_model_to_dict_method(self) -> None:
        """Test BaseModel has to_dict method."""
        from zephyr.db.base import BaseModel

        assert hasattr(BaseModel, "to_dict")
        assert callable(BaseModel.to_dict)

    @pytest.mark.asyncio
    async def test_model_from_dict_method(self) -> None:
        """Test BaseModel has from_dict classmethod."""
        from zephyr.db.base import BaseModel

        assert hasattr(BaseModel, "from_dict")
        assert callable(BaseModel.from_dict)

    @pytest.mark.asyncio
    async def test_concrete_model_timestamps_on_create(self, test_session: AsyncSession) -> None:
        """Test timestamps are set on model creation."""
        from zephyr.db.base import BaseModel

        class UserModel(BaseModel):
            """Test user model."""

            __tablename__ = "test_users"
            id = Column(Integer, primary_key=True)
            name = Column(String(255))

        # Create instance
        user = UserModel(name="Test User")
        assert user is not None
        assert hasattr(user, "created_at")
        assert hasattr(user, "updated_at")

    @pytest.mark.asyncio
    async def test_base_model_in_zephyr_db_init(self) -> None:
        """Test BaseModel is exported from zephyr.db.__init__."""
        from zephyr.db import BaseModel

        assert BaseModel is not None

    @pytest.mark.asyncio
    async def test_base_declarative_in_zephyr_db_init(self) -> None:
        """Test Base is exported from zephyr.db.__init__."""
        from zephyr.db import Base

        assert Base is not None
