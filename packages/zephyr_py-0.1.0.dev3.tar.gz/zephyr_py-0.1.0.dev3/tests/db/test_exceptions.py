"""Database exceptions tests.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations


class TestDatabaseExceptions:
    """Test database exception hierarchy."""

    def test_import_base_exception(self) -> None:
        """Test DatabaseError can be imported."""
        from zephyr.db.exceptions import DatabaseError

        assert issubclass(DatabaseError, Exception)

    def test_import_connection_error(self) -> None:
        """Test ConnectionError can be imported."""
        from zephyr.db.exceptions import ConnectionError, DatabaseError

        assert issubclass(ConnectionError, DatabaseError)

    def test_import_query_error(self) -> None:
        """Test QueryError can be imported."""
        from zephyr.db.exceptions import QueryError, DatabaseError

        assert issubclass(QueryError, DatabaseError)

    def test_import_integrity_error(self) -> None:
        """Test IntegrityError can be imported."""
        from zephyr.db.exceptions import IntegrityError, DatabaseError

        assert issubclass(IntegrityError, DatabaseError)

    def test_import_not_found_error(self) -> None:
        """Test NotFoundError can be imported."""
        from zephyr.db.exceptions import NotFoundError, DatabaseError

        assert issubclass(NotFoundError, DatabaseError)

    def test_database_error_instantiation(self) -> None:
        """Test DatabaseError can be instantiated."""
        from zephyr.db.exceptions import DatabaseError

        error = DatabaseError("Test error")
        assert str(error) == "Test error"

    def test_connection_error_instantiation(self) -> None:
        """Test ConnectionError can be instantiated."""
        from zephyr.db.exceptions import ConnectionError

        error = ConnectionError("Connection failed")
        assert str(error) == "Connection failed"

    def test_query_error_instantiation(self) -> None:
        """Test QueryError can be instantiated."""
        from zephyr.db.exceptions import QueryError

        error = QueryError("Query failed")
        assert str(error) == "Query failed"

    def test_integrity_error_instantiation(self) -> None:
        """Test IntegrityError can be instantiated."""
        from zephyr.db.exceptions import IntegrityError

        error = IntegrityError("Constraint violation")
        assert str(error) == "Constraint violation"

    def test_not_found_error_instantiation(self) -> None:
        """Test NotFoundError can be instantiated."""
        from zephyr.db.exceptions import NotFoundError

        error = NotFoundError("Record not found")
        assert str(error) == "Record not found"

    def test_exception_inheritance_chain(self) -> None:
        """Test exception inheritance is correct."""
        from zephyr.db.exceptions import (
            DatabaseError,
            ConnectionError,
            QueryError,
        )

        error = ConnectionError("Test")
        assert isinstance(error, DatabaseError)
        assert isinstance(error, Exception)

        query_error = QueryError("Test")
        assert isinstance(query_error, DatabaseError)
        assert isinstance(query_error, Exception)
