"""Tests for TaskRunner."""

from __future__ import annotations

import asyncio

import pytest

from zephyr.core.tasks import (
    MemoryResultStore,
    TaskNotFoundError,
    TaskRegistry,
    TaskRetryError,
    TaskRunner,
    TaskStatus,
    TaskTimeoutError,
    task,
)


class TestTaskRunner:
    """Tests for TaskRunner execution."""

    @pytest.mark.asyncio
    async def test_run_async_task(
        self,
        runner: TaskRunner,
        sample_async_task: None,
    ) -> None:
        """Should execute async task successfully."""
        result = await runner.run("sample_async", 5)

        assert result.status == TaskStatus.SUCCESS
        assert result.result == {"value": 10}

    @pytest.mark.asyncio
    async def test_run_sync_task(
        self,
        runner: TaskRunner,
        sample_sync_task: None,
    ) -> None:
        """Should execute sync task in thread pool."""
        result = await runner.run("sample_sync", 4)

        assert result.status == TaskStatus.SUCCESS
        assert result.result == {"value": 12}

    @pytest.mark.asyncio
    async def test_run_nonexistent_raises_error(self, runner: TaskRunner) -> None:
        """Should raise error for unknown task."""
        with pytest.raises(TaskNotFoundError):
            await runner.run("nonexistent_task")

    @pytest.mark.asyncio
    async def test_run_with_custom_task_id(
        self,
        runner: TaskRunner,
        sample_async_task: None,
    ) -> None:
        """Should use provided task ID."""
        result = await runner.run("sample_async", 1, task_id="custom-id-123")

        assert result.task_id == "custom-id-123"

    @pytest.mark.asyncio
    async def test_run_stores_result(
        self,
        runner: TaskRunner,
        sample_async_task: None,
    ) -> None:
        """Should store result in result store."""
        result = await runner.run("sample_async", 1, task_id="stored-id")

        stored = await runner.get_result("stored-id")
        assert stored is not None
        assert stored.task_id == "stored-id"
        assert stored.status == TaskStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_run_with_timeout(
        self,
        runner: TaskRunner,
        slow_task: None,
    ) -> None:
        """Should timeout on slow tasks."""
        with pytest.raises(TaskTimeoutError):
            await runner.run("slow_task")

    @pytest.mark.asyncio
    async def test_run_with_retries(
        self,
        runner: TaskRunner,
        failing_task: None,
    ) -> None:
        """Should retry failed tasks."""
        with pytest.raises(TaskRetryError) as exc_info:
            await runner.run("failing_task")

        assert exc_info.value.attempts == 2  # 1 initial + 1 retry
        assert exc_info.value.max_retries == 1

    @pytest.mark.asyncio
    async def test_submit_returns_task_id(
        self,
        runner: TaskRunner,
        sample_async_task: None,
    ) -> None:
        """Should return task ID for submitted task."""
        task_id = await runner.submit("sample_async", 1)

        assert task_id is not None
        assert len(task_id) > 0

    @pytest.mark.asyncio
    async def test_submit_runs_in_background(
        self,
        runner: TaskRunner,
        registry: TaskRegistry,
    ) -> None:
        """Submitted task should run in background."""
        execution_order: list[str] = []

        @task(name="background_task")
        async def bg_task() -> str:
            await asyncio.sleep(0.1)
            execution_order.append("task")
            return "done"

        task_id = await runner.submit("background_task")
        execution_order.append("submitted")

        # Should return immediately
        assert execution_order == ["submitted"]

        # Wait for task
        await asyncio.sleep(0.2)
        assert "task" in execution_order

    @pytest.mark.asyncio
    async def test_cancel_running_task(
        self,
        runner: TaskRunner,
        registry: TaskRegistry,
    ) -> None:
        """Should cancel running task."""

        @task(name="cancellable")
        async def long_task() -> str:
            await asyncio.sleep(10)
            return "done"

        task_id = await runner.submit("cancellable")
        await asyncio.sleep(0.1)  # Let it start

        cancelled = await runner.cancel(task_id)
        assert cancelled is True

    @pytest.mark.asyncio
    async def test_cancel_nonexistent(self, runner: TaskRunner) -> None:
        """Should return False for nonexistent task."""
        cancelled = await runner.cancel("nonexistent-id")
        assert cancelled is False

    @pytest.mark.asyncio
    async def test_wait_for_task(
        self,
        runner: TaskRunner,
        sample_async_task: None,
    ) -> None:
        """Should wait for task completion."""
        task_id = await runner.submit("sample_async", 5)

        result = await runner.wait(task_id, timeout=5.0)

        assert result.status == TaskStatus.SUCCESS
        assert result.result == {"value": 10}

    @pytest.mark.asyncio
    async def test_wait_timeout(
        self,
        runner: TaskRunner,
        registry: TaskRegistry,
    ) -> None:
        """Should timeout when waiting too long."""

        @task(name="very_slow", timeout=10)
        async def very_slow() -> str:
            await asyncio.sleep(5)
            return "done"

        task_id = await runner.submit("very_slow")

        with pytest.raises(asyncio.TimeoutError):
            await runner.wait(task_id, timeout=0.1)

    @pytest.mark.asyncio
    async def test_running_count(
        self,
        runner: TaskRunner,
        registry: TaskRegistry,
    ) -> None:
        """Should track running tasks."""

        @task(name="count_task")
        async def counting_task() -> str:
            await asyncio.sleep(0.5)
            return "done"

        assert runner.running_count == 0

        task_id1 = await runner.submit("count_task")
        await asyncio.sleep(0.05)
        assert runner.running_count >= 1

        task_id2 = await runner.submit("count_task")
        await asyncio.sleep(0.05)
        assert runner.running_count >= 1

    @pytest.mark.asyncio
    async def test_running_task_ids(
        self,
        runner: TaskRunner,
        registry: TaskRegistry,
    ) -> None:
        """Should list running task IDs."""

        @task(name="id_task")
        async def id_task() -> str:
            await asyncio.sleep(0.5)
            return "done"

        task_id = await runner.submit("id_task")
        await asyncio.sleep(0.05)

        ids = runner.running_task_ids
        assert task_id in ids

    @pytest.mark.asyncio
    async def test_shutdown_waits(
        self,
        registry: TaskRegistry,
        memory_store: MemoryResultStore,
    ) -> None:
        """Should wait for tasks on shutdown."""
        local_runner = TaskRunner(
            registry=registry,
            result_store=memory_store,
        )

        @task(name="shutdown_task")
        async def shutdown_task() -> str:
            await asyncio.sleep(0.2)
            return "completed"

        task_id = await local_runner.submit("shutdown_task")
        await asyncio.sleep(0.05)

        await local_runner.shutdown(wait=True)

        result = await memory_store.get(task_id)
        assert result is not None
        assert result.status == TaskStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_shutdown_cancels(
        self,
        registry: TaskRegistry,
        memory_store: MemoryResultStore,
    ) -> None:
        """Should cancel tasks when not waiting."""
        local_runner = TaskRunner(
            registry=registry,
            result_store=memory_store,
        )

        @task(name="cancel_shutdown")
        async def cancel_task() -> str:
            await asyncio.sleep(5)
            return "completed"

        task_id = await local_runner.submit("cancel_shutdown")
        await asyncio.sleep(0.05)

        await local_runner.shutdown(wait=False)

        assert local_runner.running_count == 0

