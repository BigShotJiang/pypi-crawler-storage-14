"""Pytest fixtures for task system tests."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import pytest

from zephyr.core.tasks import (
    MemoryResultStore,
    TaskManager,
    TaskManagerConfig,
    TaskRegistry,
    TaskRunner,
    task,
)

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Generator


@pytest.fixture
def registry() -> Generator[TaskRegistry, None, None]:
    """Provide a clean TaskRegistry instance."""
    from zephyr.core.tasks import get_registry

    reg = get_registry()
    reg.clear()
    yield reg
    reg.clear()


@pytest.fixture
def memory_store() -> MemoryResultStore:
    """Provide a MemoryResultStore instance."""
    return MemoryResultStore(default_ttl=60)


@pytest.fixture
def runner(registry: TaskRegistry, memory_store: MemoryResultStore) -> TaskRunner:
    """Provide a TaskRunner instance."""
    return TaskRunner(
        registry=registry,
        result_store=memory_store,
        max_workers=2,
    )


@pytest.fixture
async def task_manager(
    registry: TaskRegistry,
    memory_store: MemoryResultStore,
) -> AsyncGenerator[TaskManager, None]:
    """Provide an initialized TaskManager instance."""
    config = TaskManagerConfig()
    manager = TaskManager(
        config=config,
        registry=registry,
        result_store=memory_store,
    )
    await manager.initialize()
    yield manager
    await manager.shutdown()


@pytest.fixture
def sample_async_task(registry: TaskRegistry) -> None:
    """Register a sample async task."""

    @task(name="sample_async")
    async def sample_async_func(value: int) -> dict:
        await asyncio.sleep(0.01)
        return {"value": value * 2}


@pytest.fixture
def sample_sync_task(registry: TaskRegistry) -> None:
    """Register a sample sync task."""

    @task(name="sample_sync")
    def sample_sync_func(value: int) -> dict:
        return {"value": value * 3}


@pytest.fixture
def failing_task(registry: TaskRegistry) -> None:
    """Register a task that always fails."""

    @task(name="failing_task", retry=1)
    async def failing_func() -> None:
        msg = "Task failed intentionally"
        raise RuntimeError(msg)


@pytest.fixture
def slow_task(registry: TaskRegistry) -> None:
    """Register a slow task for timeout testing."""

    @task(name="slow_task", timeout=0.1)
    async def slow_func() -> dict:
        await asyncio.sleep(1.0)
        return {"status": "done"}
