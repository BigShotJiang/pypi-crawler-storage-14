"""Tests for task decorators."""

from __future__ import annotations

import asyncio

import pytest

from zephyr.core.tasks import (
    PeriodicTaskWrapper,
    TaskRegistry,
    TaskWrapper,
    periodic_task,
    task,
)


class TestTaskDecorator:
    """Tests for @task decorator."""

    def test_decorator_without_args(self, registry: TaskRegistry) -> None:
        """Should work without parentheses."""

        @task
        def simple_task() -> str:
            return "done"

        assert isinstance(simple_task, TaskWrapper)
        assert simple_task.name == "simple_task"
        assert registry.exists("simple_task")

    def test_decorator_with_args(self, registry: TaskRegistry) -> None:
        """Should work with arguments."""

        @task(name="custom_name", retry=5, timeout=60.0)
        def named_task() -> str:
            return "done"

        assert isinstance(named_task, TaskWrapper)
        assert named_task.name == "custom_name"
        assert named_task.retry == 5
        assert named_task.timeout == 60.0

    def test_decorator_on_async_function(self, registry: TaskRegistry) -> None:
        """Should work on async functions."""

        @task(name="async_decorated")
        async def async_task() -> str:
            await asyncio.sleep(0.01)
            return "async done"

        assert isinstance(async_task, TaskWrapper)
        metadata = registry.get("async_decorated")
        assert metadata.is_async is True

    def test_decorator_preserves_function_execution(self, registry: TaskRegistry) -> None:
        """Decorated function should still be callable."""

        @task(name="callable_task")
        def add_numbers(a: int, b: int) -> int:
            return a + b

        result = add_numbers(2, 3)
        assert result == 5

    @pytest.mark.asyncio
    async def test_decorator_preserves_async_execution(self, registry: TaskRegistry) -> None:
        """Decorated async function should still work."""

        @task(name="async_callable")
        async def multiply(a: int, b: int) -> int:
            return a * b

        result = await multiply(3, 4)
        assert result == 12

    def test_wrapper_properties(self, registry: TaskRegistry) -> None:
        """TaskWrapper should expose all properties."""

        @task(name="prop_test", queue="high", retry=10, timeout=120.0)
        def prop_task() -> None:
            pass

        assert prop_task.name == "prop_test"
        assert prop_task.queue == "high"
        assert prop_task.retry == 10
        assert prop_task.timeout == 120.0

    def test_wrapper_repr(self, registry: TaskRegistry) -> None:
        """TaskWrapper should have meaningful repr."""

        @task(name="repr_task", queue="test_queue")
        def repr_task_func() -> None:
            pass

        repr_str = repr(repr_task_func)
        assert "repr_task" in repr_str
        assert "test_queue" in repr_str


class TestPeriodicTaskDecorator:
    """Tests for @periodic_task decorator."""

    def test_periodic_with_cron(self, registry: TaskRegistry) -> None:
        """Should work with cron expression."""

        @periodic_task(name="cron_task", cron="0 * * * *")
        async def hourly_task() -> None:
            pass

        assert isinstance(hourly_task, PeriodicTaskWrapper)
        assert hourly_task.cron == "0 * * * *"
        assert hourly_task.interval is None

    def test_periodic_with_interval(self, registry: TaskRegistry) -> None:
        """Should work with interval."""

        @periodic_task(name="interval_task", interval=60.0)
        async def minute_task() -> None:
            pass

        assert isinstance(minute_task, PeriodicTaskWrapper)
        assert minute_task.interval == 60.0
        assert minute_task.cron is None

    def test_periodic_requires_schedule(self, registry: TaskRegistry) -> None:
        """Should raise error if neither cron nor interval specified."""
        with pytest.raises(ValueError) as exc_info:

            @periodic_task(name="no_schedule")
            async def bad_task() -> None:
                pass

        assert "cron" in str(exc_info.value) or "interval" in str(exc_info.value)

    def test_periodic_wrapper_repr(self, registry: TaskRegistry) -> None:
        """PeriodicTaskWrapper should have meaningful repr."""

        @periodic_task(name="repr_periodic", cron="*/5 * * * *")
        async def cron_repr_task() -> None:
            pass

        repr_str = repr(cron_repr_task)
        assert "repr_periodic" in repr_str
        assert "cron" in repr_str

    def test_periodic_with_all_options(self, registry: TaskRegistry) -> None:
        """Should work with all options."""

        @periodic_task(
            name="full_periodic",
            queue="scheduled",
            retry=5,
            timeout=30.0,
            interval=120.0,
        )
        async def full_task() -> None:
            pass

        assert full_task.name == "full_periodic"
        assert full_task.queue == "scheduled"
        assert full_task.retry == 5
        assert full_task.timeout == 30.0
        assert full_task.interval == 120.0
