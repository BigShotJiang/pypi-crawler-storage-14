"""Tests for result storage backends."""

from __future__ import annotations

import asyncio
from datetime import datetime, UTC

import pytest

from zephyr.core.tasks import (
    MemoryResultStore,
    TaskResult,
    TaskStatus,
)


class TestTaskResult:
    """Tests for TaskResult dataclass."""

    def test_create_result(self) -> None:
        """Should create result with defaults."""
        result = TaskResult(
            task_id="test-123",
            task_name="my_task",
        )

        assert result.task_id == "test-123"
        assert result.task_name == "my_task"
        assert result.status == TaskStatus.PENDING
        assert result.result is None
        assert result.error is None
        assert result.retries == 0

    def test_result_with_success(self) -> None:
        """Should store successful result."""
        result = TaskResult(
            task_id="success-456",
            task_name="success_task",
            status=TaskStatus.SUCCESS,
            result={"data": "value"},
            completed_at=datetime.now(UTC),
        )

        assert result.status == TaskStatus.SUCCESS
        assert result.result == {"data": "value"}

    def test_result_with_failure(self) -> None:
        """Should store failed result."""
        result = TaskResult(
            task_id="fail-789",
            task_name="fail_task",
            status=TaskStatus.FAILURE,
            error="Something went wrong",
            completed_at=datetime.now(UTC),
        )

        assert result.status == TaskStatus.FAILURE
        assert result.error == "Something went wrong"

    def test_to_dict(self) -> None:
        """Should convert to dictionary."""
        result = TaskResult(
            task_id="dict-123",
            task_name="dict_task",
            status=TaskStatus.SUCCESS,
            result={"key": "value"},
        )

        data = result.to_dict()

        assert data["task_id"] == "dict-123"
        assert data["task_name"] == "dict_task"
        assert data["status"] == "success"
        assert data["result"] == {"key": "value"}

    def test_from_dict(self) -> None:
        """Should create from dictionary."""
        data = {
            "task_id": "from-dict-456",
            "task_name": "from_dict_task",
            "status": "running",
            "result": None,
            "error": None,
            "created_at": datetime.now(UTC).isoformat(),
            "started_at": datetime.now(UTC).isoformat(),
            "completed_at": None,
            "retries": 2,
        }

        result = TaskResult.from_dict(data)

        assert result.task_id == "from-dict-456"
        assert result.status == TaskStatus.RUNNING
        assert result.retries == 2


class TestMemoryResultStore:
    """Tests for MemoryResultStore."""

    @pytest.mark.asyncio
    async def test_store_and_get(self, memory_store: MemoryResultStore) -> None:
        """Should store and retrieve result."""
        result = TaskResult(
            task_id="mem-123",
            task_name="mem_task",
            status=TaskStatus.SUCCESS,
            result={"data": 42},
        )

        await memory_store.store(result)
        retrieved = await memory_store.get("mem-123")

        assert retrieved is not None
        assert retrieved.task_id == "mem-123"
        assert retrieved.result == {"data": 42}

    @pytest.mark.asyncio
    async def test_get_nonexistent(self, memory_store: MemoryResultStore) -> None:
        """Should return None for nonexistent task."""
        result = await memory_store.get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_delete(self, memory_store: MemoryResultStore) -> None:
        """Should delete result."""
        result = TaskResult(
            task_id="del-123",
            task_name="del_task",
        )

        await memory_store.store(result)
        assert await memory_store.exists("del-123") is True

        await memory_store.delete("del-123")
        assert await memory_store.exists("del-123") is False

    @pytest.mark.asyncio
    async def test_exists(self, memory_store: MemoryResultStore) -> None:
        """Should check existence correctly."""
        result = TaskResult(
            task_id="exist-123",
            task_name="exist_task",
        )

        assert await memory_store.exists("exist-123") is False

        await memory_store.store(result)
        assert await memory_store.exists("exist-123") is True

    @pytest.mark.asyncio
    async def test_list_tasks_all(self, memory_store: MemoryResultStore) -> None:
        """Should list all tasks."""
        for i in range(5):
            result = TaskResult(
                task_id=f"list-{i}",
                task_name="list_task",
                status=TaskStatus.SUCCESS if i % 2 == 0 else TaskStatus.FAILURE,
            )
            await memory_store.store(result)

        tasks = await memory_store.list_tasks()
        assert len(tasks) == 5

    @pytest.mark.asyncio
    async def test_list_tasks_with_status_filter(self, memory_store: MemoryResultStore) -> None:
        """Should filter by status."""
        await memory_store.store(
            TaskResult(
                task_id="s1",
                task_name="t",
                status=TaskStatus.SUCCESS,
            )
        )
        await memory_store.store(
            TaskResult(
                task_id="s2",
                task_name="t",
                status=TaskStatus.SUCCESS,
            )
        )
        await memory_store.store(
            TaskResult(
                task_id="f1",
                task_name="t",
                status=TaskStatus.FAILURE,
            )
        )

        success_tasks = await memory_store.list_tasks(status=TaskStatus.SUCCESS)
        assert len(success_tasks) == 2

        failure_tasks = await memory_store.list_tasks(status=TaskStatus.FAILURE)
        assert len(failure_tasks) == 1

    @pytest.mark.asyncio
    async def test_list_tasks_with_limit(self, memory_store: MemoryResultStore) -> None:
        """Should respect limit."""
        for i in range(10):
            await memory_store.store(
                TaskResult(
                    task_id=f"limit-{i}",
                    task_name="limit_task",
                )
            )

        tasks = await memory_store.list_tasks(limit=3)
        assert len(tasks) == 3

    @pytest.mark.asyncio
    async def test_ttl_expiration(self) -> None:
        """Should expire results after TTL."""
        store = MemoryResultStore(default_ttl=1)  # 1 second TTL

        result = TaskResult(
            task_id="expire-123",
            task_name="expire_task",
        )
        await store.store(result)

        # Should exist immediately
        assert await store.get("expire-123") is not None

        # Wait for expiration
        await asyncio.sleep(1.1)

        # Should be expired
        assert await store.get("expire-123") is None

    @pytest.mark.asyncio
    async def test_cleanup_expired(self) -> None:
        """Should cleanup expired results."""
        store = MemoryResultStore(default_ttl=1)

        for i in range(3):
            await store.store(
                TaskResult(
                    task_id=f"cleanup-{i}",
                    task_name="cleanup_task",
                )
            )

        assert store.count == 3

        await asyncio.sleep(1.1)

        removed = await store.cleanup_expired()
        assert removed == 3
        assert store.count == 0

    @pytest.mark.asyncio
    async def test_count(self, memory_store: MemoryResultStore) -> None:
        """Should return correct count."""
        assert memory_store.count == 0

        await memory_store.store(
            TaskResult(
                task_id="count-1",
                task_name="count_task",
            )
        )
        assert memory_store.count == 1

        await memory_store.store(
            TaskResult(
                task_id="count-2",
                task_name="count_task",
            )
        )
        assert memory_store.count == 2

    @pytest.mark.asyncio
    async def test_update_existing(self, memory_store: MemoryResultStore) -> None:
        """Should update existing result."""
        result = TaskResult(
            task_id="update-123",
            task_name="update_task",
            status=TaskStatus.PENDING,
        )
        await memory_store.store(result)

        # Update status
        result.status = TaskStatus.SUCCESS
        result.result = {"updated": True}
        await memory_store.store(result)

        retrieved = await memory_store.get("update-123")
        assert retrieved is not None
        assert retrieved.status == TaskStatus.SUCCESS
        assert retrieved.result == {"updated": True}

    @pytest.mark.asyncio
    async def test_close(self, memory_store: MemoryResultStore) -> None:
        """Should handle close gracefully."""
        await memory_store.close()
        # Should not raise

