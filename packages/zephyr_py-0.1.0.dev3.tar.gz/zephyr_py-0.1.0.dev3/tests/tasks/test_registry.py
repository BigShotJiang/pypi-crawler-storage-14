"""Tests for TaskRegistry."""

from __future__ import annotations


import pytest

from zephyr.core.tasks import (
    TaskAlreadyRegisteredError,
    TaskNotFoundError,
    TaskRegistry,
)


class TestTaskRegistry:
    """Tests for TaskRegistry singleton and registration."""

    def test_singleton_pattern(self) -> None:
        """Registry should be a singleton."""
        reg1 = TaskRegistry()
        reg2 = TaskRegistry()
        assert reg1 is reg2

    def test_get_instance(self) -> None:
        """get_instance should return the singleton."""
        instance = TaskRegistry.get_instance()
        assert instance is TaskRegistry()

    def test_register_sync_task(self, registry: TaskRegistry) -> None:
        """Should register a sync function as a task."""

        def my_sync_task(x: int) -> int:
            return x * 2

        metadata = registry.register(my_sync_task, name="sync_task")

        assert metadata.name == "sync_task"
        assert metadata.func is my_sync_task
        assert metadata.is_async is False
        assert metadata.queue == "default"
        assert metadata.retry == 3

    def test_register_async_task(self, registry: TaskRegistry) -> None:
        """Should register an async function as a task."""

        async def my_async_task(x: int) -> int:
            return x * 2

        metadata = registry.register(my_async_task, name="async_task")

        assert metadata.name == "async_task"
        assert metadata.func is my_async_task
        assert metadata.is_async is True

    def test_register_with_custom_options(self, registry: TaskRegistry) -> None:
        """Should register with custom retry, timeout, queue."""

        def custom_task() -> None:
            pass

        metadata = registry.register(
            custom_task,
            name="custom",
            queue="high_priority",
            retry=5,
            timeout=120.0,
        )

        assert metadata.queue == "high_priority"
        assert metadata.retry == 5
        assert metadata.timeout == 120.0

    def test_register_uses_function_name_as_default(self, registry: TaskRegistry) -> None:
        """Should use function name if no name provided."""

        def auto_named_task() -> None:
            pass

        metadata = registry.register(auto_named_task)

        assert metadata.name == "auto_named_task"

    def test_register_duplicate_raises_error(self, registry: TaskRegistry) -> None:
        """Should raise error when registering duplicate name."""

        def task1() -> None:
            pass

        def task2() -> None:
            pass

        registry.register(task1, name="duplicate")

        with pytest.raises(TaskAlreadyRegisteredError) as exc_info:
            registry.register(task2, name="duplicate")

        assert "duplicate" in str(exc_info.value)

    def test_get_existing_task(self, registry: TaskRegistry) -> None:
        """Should retrieve task metadata by name."""

        def my_task() -> None:
            pass

        registry.register(my_task, name="get_test")

        metadata = registry.get("get_test")
        assert metadata.name == "get_test"

    def test_get_nonexistent_raises_error(self, registry: TaskRegistry) -> None:
        """Should raise error when task not found."""
        with pytest.raises(TaskNotFoundError) as exc_info:
            registry.get("nonexistent")

        assert "nonexistent" in str(exc_info.value)

    def test_get_by_func(self, registry: TaskRegistry) -> None:
        """Should retrieve task by function reference."""

        def func_lookup_task() -> None:
            pass

        registry.register(func_lookup_task, name="func_test")

        metadata = registry.get_by_func(func_lookup_task)
        assert metadata.name == "func_test"

    def test_exists(self, registry: TaskRegistry) -> None:
        """Should check if task exists."""

        def exist_task() -> None:
            pass

        registry.register(exist_task, name="exists_test")

        assert registry.exists("exists_test") is True
        assert registry.exists("nonexistent") is False

    def test_unregister(self, registry: TaskRegistry) -> None:
        """Should unregister a task."""

        def unreg_task() -> None:
            pass

        registry.register(unreg_task, name="to_unregister")
        assert registry.exists("to_unregister") is True

        registry.unregister("to_unregister")
        assert registry.exists("to_unregister") is False

    def test_unregister_nonexistent_raises_error(self, registry: TaskRegistry) -> None:
        """Should raise error when unregistering nonexistent task."""
        with pytest.raises(TaskNotFoundError):
            registry.unregister("nonexistent")

    def test_list_tasks(self, registry: TaskRegistry) -> None:
        """Should list all registered tasks."""

        def task1() -> None:
            pass

        def task2() -> None:
            pass

        registry.register(task1, name="list_task1")
        registry.register(task2, name="list_task2")

        tasks = registry.list_tasks()
        names = [t.name for t in tasks]

        assert "list_task1" in names
        assert "list_task2" in names

    def test_list_task_names(self, registry: TaskRegistry) -> None:
        """Should list all task names."""

        def task_a() -> None:
            pass

        def task_b() -> None:
            pass

        registry.register(task_a, name="name_a")
        registry.register(task_b, name="name_b")

        names = registry.list_task_names()
        assert "name_a" in names
        assert "name_b" in names

    def test_count(self, registry: TaskRegistry) -> None:
        """Should return correct count of tasks."""
        assert registry.count == 0

        def count_task() -> None:
            pass

        registry.register(count_task, name="count1")
        assert registry.count == 1

        def count_task2() -> None:
            pass

        registry.register(count_task2, name="count2")
        assert registry.count == 2

    def test_clear(self, registry: TaskRegistry) -> None:
        """Should clear all registered tasks."""

        def clear_task() -> None:
            pass

        registry.register(clear_task, name="to_clear")
        assert registry.count > 0

        registry.clear()
        assert registry.count == 0

    def test_reset(self, registry: TaskRegistry) -> None:
        """Should reset the singleton instance."""

        def reset_task() -> None:
            pass

        registry.register(reset_task, name="reset_test")
        assert registry.count > 0

        TaskRegistry.reset()
        reg2 = TaskRegistry()

        # New instance should be empty
        assert reg2.count == 0
        reg2.clear()
