"""Tests for TaskManager."""

from __future__ import annotations

import asyncio

import pytest

from zephyr.core.tasks import (
    MemoryResultStore,
    ResultBackendType,
    ResultNotFoundError,
    TaskBackendType,
    TaskManager,
    TaskManagerConfig,
    TaskNotFoundError,
    TaskRegistry,
    TaskStatus,
    get_task_manager,
    set_task_manager,
    task,
)


class TestTaskManagerConfig:
    """Tests for TaskManagerConfig."""

    def test_default_config(self) -> None:
        """Should have sensible defaults."""
        config = TaskManagerConfig()

        assert config.backend == TaskBackendType.IN_PROCESS
        assert config.result_backend == ResultBackendType.MEMORY
        assert config.default_queue == "default"
        assert config.default_timeout == 300.0
        assert config.default_retry == 3
        assert config.result_ttl == 3600
        assert config.max_workers == 4

    def test_custom_config(self) -> None:
        """Should accept custom values."""
        config = TaskManagerConfig(
            backend=TaskBackendType.CELERY,
            result_backend=ResultBackendType.REDIS,
            broker_url="redis://localhost:6379/0",
            default_queue="high_priority",
            default_timeout=60.0,
        )

        assert config.backend == TaskBackendType.CELERY
        assert config.broker_url == "redis://localhost:6379/0"
        assert config.default_queue == "high_priority"


class TestTaskManager:
    """Tests for TaskManager unified facade."""

    @pytest.mark.asyncio
    async def test_initialize(self, task_manager: TaskManager) -> None:
        """Should initialize successfully."""
        assert task_manager.is_initialized is True

    @pytest.mark.asyncio
    async def test_auto_initialize_on_submit(
        self,
        registry: TaskRegistry,
        memory_store: MemoryResultStore,
    ) -> None:
        """Should auto-initialize when submitting."""

        @task(name="auto_init_task")
        async def auto_task() -> str:
            return "done"

        manager = TaskManager(
            config=TaskManagerConfig(),
            registry=registry,
            result_store=memory_store,
        )

        assert manager.is_initialized is False

        task_id = await manager.submit("auto_init_task")

        assert manager.is_initialized is True
        assert task_id is not None

        await manager.shutdown()

    @pytest.mark.asyncio
    async def test_submit_task(
        self,
        task_manager: TaskManager,
        sample_async_task: None,
    ) -> None:
        """Should submit task and return ID."""
        task_id = await task_manager.submit("sample_async", 5)

        assert task_id is not None
        assert len(task_id) > 0

    @pytest.mark.asyncio
    async def test_submit_nonexistent_raises(
        self,
        task_manager: TaskManager,
    ) -> None:
        """Should raise error for unknown task."""
        with pytest.raises(TaskNotFoundError):
            await task_manager.submit("nonexistent")

    @pytest.mark.asyncio
    async def test_get_result(
        self,
        task_manager: TaskManager,
        sample_async_task: None,
    ) -> None:
        """Should get result after completion."""
        task_id = await task_manager.submit("sample_async", 5)

        # Wait for completion
        await asyncio.sleep(0.2)

        result = await task_manager.get_result(task_id)
        assert result.status == TaskStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_get_result_with_wait(
        self,
        task_manager: TaskManager,
        sample_async_task: None,
    ) -> None:
        """Should wait for result when requested."""
        task_id = await task_manager.submit("sample_async", 3)

        result = await task_manager.get_result(task_id, wait=True, timeout=5.0)

        assert result.status == TaskStatus.SUCCESS
        assert result.result == {"value": 6}

    @pytest.mark.asyncio
    async def test_get_result_not_found(
        self,
        task_manager: TaskManager,
    ) -> None:
        """Should raise error when result not found."""
        with pytest.raises(ResultNotFoundError):
            await task_manager.get_result("nonexistent-id")

    @pytest.mark.asyncio
    async def test_cancel_task(
        self,
        task_manager: TaskManager,
        registry: TaskRegistry,
    ) -> None:
        """Should cancel running task."""

        @task(name="cancel_test")
        async def long_task() -> str:
            await asyncio.sleep(10)
            return "done"

        task_id = await task_manager.submit("cancel_test")
        await asyncio.sleep(0.1)

        cancelled = await task_manager.cancel(task_id)
        assert cancelled is True

    @pytest.mark.asyncio
    async def test_list_results(
        self,
        task_manager: TaskManager,
        sample_async_task: None,
    ) -> None:
        """Should list task results."""
        # Submit multiple tasks
        for i in range(3):
            await task_manager.submit("sample_async", i)

        await asyncio.sleep(0.3)

        results = await task_manager.list_results()
        assert len(results) >= 3

    @pytest.mark.asyncio
    async def test_list_results_filtered(
        self,
        task_manager: TaskManager,
        sample_async_task: None,
    ) -> None:
        """Should filter by status."""
        await task_manager.submit("sample_async", 1)
        await asyncio.sleep(0.2)

        success_results = await task_manager.list_results(status=TaskStatus.SUCCESS)
        assert len(success_results) >= 1
        assert all(r.status == TaskStatus.SUCCESS for r in success_results)

    @pytest.mark.asyncio
    async def test_list_registered_tasks(
        self,
        task_manager: TaskManager,
        sample_async_task: None,
        sample_sync_task: None,
    ) -> None:
        """Should list registered tasks."""
        tasks = task_manager.list_registered_tasks()

        assert "sample_async" in tasks
        assert "sample_sync" in tasks

    @pytest.mark.asyncio
    async def test_health_check(
        self,
        task_manager: TaskManager,
    ) -> None:
        """Should return health status."""
        health = await task_manager.health_check()

        assert "in_process_runner" in health
        assert "result_store" in health
        assert health["in_process_runner"] is True
        assert health["result_store"] is True

    @pytest.mark.asyncio
    async def test_shutdown(
        self,
        registry: TaskRegistry,
        memory_store: MemoryResultStore,
    ) -> None:
        """Should shutdown cleanly."""

        @task(name="shutdown_test")
        async def simple_task() -> str:
            return "done"

        manager = TaskManager(
            config=TaskManagerConfig(),
            registry=registry,
            result_store=memory_store,
        )
        await manager.initialize()

        await manager.shutdown()

        assert manager.is_initialized is False

    @pytest.mark.asyncio
    async def test_configure_factory(self, registry: TaskRegistry) -> None:
        """Should create manager via factory."""
        manager = TaskManager.configure(
            backend=TaskBackendType.IN_PROCESS,
            result_backend=ResultBackendType.MEMORY,
            default_timeout=60.0,
        )

        assert manager.config.backend == TaskBackendType.IN_PROCESS
        assert manager.config.default_timeout == 60.0

    @pytest.mark.asyncio
    async def test_config_property(
        self,
        task_manager: TaskManager,
    ) -> None:
        """Should expose config."""
        config = task_manager.config
        assert isinstance(config, TaskManagerConfig)

    @pytest.mark.asyncio
    async def test_registry_property(
        self,
        task_manager: TaskManager,
    ) -> None:
        """Should expose registry."""
        registry = task_manager.registry
        assert isinstance(registry, TaskRegistry)


class TestGlobalTaskManager:
    """Tests for global TaskManager instance."""

    def test_get_task_manager(self) -> None:
        """Should return global instance."""
        manager = get_task_manager()
        assert isinstance(manager, TaskManager)

    def test_set_task_manager(self) -> None:
        """Should set global instance."""
        custom_manager = TaskManager()
        set_task_manager(custom_manager)

        retrieved = get_task_manager()
        assert retrieved is custom_manager

    def test_get_task_manager_singleton(self) -> None:
        """Should return same instance."""
        manager1 = get_task_manager()
        manager2 = get_task_manager()
        assert manager1 is manager2

