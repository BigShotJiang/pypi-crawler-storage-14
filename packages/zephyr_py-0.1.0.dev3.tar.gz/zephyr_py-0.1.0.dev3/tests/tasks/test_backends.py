"""Tests for job queue backends (Celery and RQ)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from zephyr.core.tasks import TaskRegistry, TaskStatus, task
from zephyr.core.tasks.backends.celery import CELERY_STATE_MAP, CeleryBackend
from zephyr.core.tasks.backends.rq import RQ_STATUS_MAP, RQBackend
from zephyr.core.tasks.exceptions import BackendConnectionError, BackendError


class TestCeleryBackend:
    """Tests for CeleryBackend."""

    def test_init(self) -> None:
        """Should initialize with broker URL."""
        backend = CeleryBackend(
            broker_url="redis://localhost:6379/0",
            task_default_queue="high",
        )

        assert backend._broker_url == "redis://localhost:6379/0"
        assert backend._default_queue == "high"
        assert backend.is_connected is False

    def test_state_mapping(self) -> None:
        """Should map Celery states to TaskStatus."""
        assert CELERY_STATE_MAP["PENDING"] == TaskStatus.PENDING
        assert CELERY_STATE_MAP["STARTED"] == TaskStatus.RUNNING
        assert CELERY_STATE_MAP["SUCCESS"] == TaskStatus.SUCCESS
        assert CELERY_STATE_MAP["FAILURE"] == TaskStatus.FAILURE
        assert CELERY_STATE_MAP["RETRY"] == TaskStatus.RETRY
        assert CELERY_STATE_MAP["REVOKED"] == TaskStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_connect_without_celery_installed(self) -> None:
        """Should raise error when Celery not installed."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        with patch.dict("sys.modules", {"celery": None}), pytest.raises(BackendConnectionError):
            await backend.connect()

    @pytest.mark.asyncio
    async def test_submit_when_not_connected(self) -> None:
        """Should raise error when not connected."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        with pytest.raises(BackendError) as exc_info:
            await backend.submit(
                task_name="test",
                task_id="123",
                args=(),
                kwargs={},
            )

        assert "Not connected" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_cancel_when_not_connected(self) -> None:
        """Should return False when not connected."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        result = await backend.cancel("task-123")
        assert result is False

    @pytest.mark.asyncio
    async def test_get_status_when_not_connected(self) -> None:
        """Should return None when not connected."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        status = await backend.get_status("task-123")
        assert status is None

    @pytest.mark.asyncio
    async def test_health_check_when_not_connected(self) -> None:
        """Should return False when not connected."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        healthy = await backend.health_check()
        assert healthy is False

    @pytest.mark.asyncio
    async def test_disconnect(self) -> None:
        """Should disconnect cleanly."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        # Mock connected state
        mock_celery = MagicMock()
        backend._celery = mock_celery
        backend._connected = True

        await backend.disconnect()

        assert backend.is_connected is False
        mock_celery.close.assert_called_once()

    def test_celery_app_property(self) -> None:
        """Should expose Celery app."""
        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        assert backend.celery_app is None

        mock_celery = MagicMock()
        backend._celery = mock_celery

        assert backend.celery_app is mock_celery


class TestRQBackend:
    """Tests for RQBackend."""

    def test_init(self) -> None:
        """Should initialize with Redis URL."""
        backend = RQBackend(
            redis_url="redis://localhost:6379/0",
            default_queue="default",
            job_timeout=300,
        )

        assert backend._redis_url == "redis://localhost:6379/0"
        assert backend._default_queue == "default"
        assert backend._job_timeout == 300
        assert backend.is_connected is False

    def test_status_mapping(self) -> None:
        """Should map RQ statuses to TaskStatus."""
        assert RQ_STATUS_MAP["queued"] == TaskStatus.PENDING
        assert RQ_STATUS_MAP["started"] == TaskStatus.RUNNING
        assert RQ_STATUS_MAP["finished"] == TaskStatus.SUCCESS
        assert RQ_STATUS_MAP["failed"] == TaskStatus.FAILURE
        assert RQ_STATUS_MAP["canceled"] == TaskStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_connect_without_rq_installed(self) -> None:
        """Should raise error when RQ not installed."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        with patch.dict("sys.modules", {"rq": None, "redis": None}), pytest.raises(BackendConnectionError):
            await backend.connect()

    @pytest.mark.asyncio
    async def test_submit_when_not_connected(self) -> None:
        """Should raise error when not connected."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        with pytest.raises(BackendError) as exc_info:
            await backend.submit(
                task_name="test",
                task_id="123",
                args=(),
                kwargs={},
            )

        assert "Not connected" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_cancel_when_not_connected(self) -> None:
        """Should return False when not connected."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        result = await backend.cancel("task-123")
        assert result is False

    @pytest.mark.asyncio
    async def test_get_status_when_not_connected(self) -> None:
        """Should return None when not connected."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        status = await backend.get_status("task-123")
        assert status is None

    @pytest.mark.asyncio
    async def test_health_check_when_not_connected(self) -> None:
        """Should return False when not connected."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        healthy = await backend.health_check()
        assert healthy is False

    @pytest.mark.asyncio
    async def test_disconnect(self) -> None:
        """Should disconnect cleanly."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        # Mock connected state
        mock_redis = MagicMock()
        backend._redis = mock_redis
        backend._connected = True
        backend._queues = {"default": MagicMock()}

        await backend.disconnect()

        assert backend.is_connected is False
        mock_redis.close.assert_called_once()
        assert len(backend._queues) == 0

    def test_redis_connection_property(self) -> None:
        """Should expose Redis connection."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        assert backend.redis_connection is None

        mock_redis = MagicMock()
        backend._redis = mock_redis

        assert backend.redis_connection is mock_redis

    def test_queue_length_not_connected(self) -> None:
        """Should return 0 when not connected."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        length = backend.get_queue_length()
        assert length == 0

    @pytest.mark.asyncio
    async def test_get_job_result_not_connected(self) -> None:
        """Should return None when not connected."""
        backend = RQBackend(redis_url="redis://localhost:6379/0")

        result = await backend.get_job_result("task-123")
        assert result is None


class TestBackendIntegration:
    """Integration tests for backends with mocked connections."""

    @pytest.mark.asyncio
    async def test_celery_submit_with_mock(
        self,
        registry: TaskRegistry,
    ) -> None:
        """Should submit to Celery when mocked."""

        @task(name="celery_task")
        async def celery_task(x: int) -> int:
            return x * 2

        backend = CeleryBackend(broker_url="redis://localhost:6379/0")

        # Mock Celery
        mock_celery = MagicMock()
        mock_result = MagicMock()
        mock_result.id = "celery-task-id"
        mock_celery.send_task.return_value = mock_result

        backend._celery = mock_celery
        backend._connected = True

        task_id = await backend.submit(
            task_name="celery_task",
            task_id="test-id",
            args=(5,),
            kwargs={},
        )

        assert task_id == "celery-task-id"
        mock_celery.send_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_rq_submit_with_mock(
        self,
        registry: TaskRegistry,
    ) -> None:
        """Should submit to RQ when mocked."""
        pytest.importorskip("rq", reason="rq not installed")

        @task(name="rq_task")
        def rq_task(x: int) -> int:
            return x * 3

        backend = RQBackend(redis_url="redis://localhost:6379/0")

        # Mock Redis and Queue
        mock_redis = MagicMock()
        mock_queue = MagicMock()
        mock_job = MagicMock()
        mock_job.id = "rq-job-id"
        mock_queue.enqueue.return_value = mock_job

        backend._redis = mock_redis
        backend._connected = True
        backend._queues = {"default": mock_queue}

        task_id = await backend.submit(
            task_name="rq_task",
            task_id="test-id",
            args=(10,),
            kwargs={},
            queue="default",
        )

        assert task_id == "rq-job-id"
        mock_queue.enqueue.assert_called_once()
