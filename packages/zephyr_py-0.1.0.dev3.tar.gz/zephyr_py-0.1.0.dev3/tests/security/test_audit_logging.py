"""Unit tests for Audit Logging System."""

from __future__ import annotations

import json
from datetime import datetime
from unittest.mock import MagicMock

import pytest

from zephyr.security.audit import (
    AuditContext,
    AuditEventType,
    AuditLogger,
    get_audit_logger,
)


class TestAuditContext:
    """Test suite for AuditContext dataclass."""

    def test_audit_context_creation(self) -> None:
        """Test creating an audit context."""
        context = AuditContext(
            event_type=AuditEventType.AUTH_LOGIN_SUCCESS,
            user_id="user123",
            username="testuser",
            ip_address="127.0.0.1",
        )

        assert context.event_type == AuditEventType.AUTH_LOGIN_SUCCESS
        assert context.user_id == "user123"
        assert context.username == "testuser"
        assert context.ip_address == "127.0.0.1"

    def test_audit_context_to_dict(self) -> None:
        """Test converting audit context to dictionary."""
        context = AuditContext(
            event_type=AuditEventType.AUTH_LOGIN_SUCCESS,
            user_id="user123",
            username="testuser",
        )

        context_dict = context.to_dict()

        assert "event_type" in context_dict
        assert context_dict["event_type"] == "auth.login.success"
        assert context_dict["user_id"] == "user123"
        assert context_dict["username"] == "testuser"
        assert "timestamp" in context_dict

    def test_audit_context_default_values(self) -> None:
        """Test audit context default values."""
        context = AuditContext(event_type=AuditEventType.AUTH_LOGIN_SUCCESS)

        assert context.result == "success"
        assert context.user_id is None
        assert context.additional_data == {}
        assert isinstance(context.timestamp, datetime)


class TestAuditLogger:
    """Test suite for AuditLogger."""

    @pytest.fixture
    def mock_logger(self) -> MagicMock:
        """Create a mock logger."""
        return MagicMock()

    @pytest.fixture
    def audit_logger(self, mock_logger: MagicMock) -> AuditLogger:
        """Create an audit logger instance."""
        return AuditLogger(logger_instance=mock_logger)

    def test_audit_logger_initialization(self) -> None:
        """Test audit logger initialization."""
        logger = AuditLogger()

        assert logger.enabled is True
        assert logger.log_level == "INFO"
        assert logger.retention_days == 90
        assert logger.include_request_body is False
        assert logger.include_response_body is False

    def test_audit_logger_with_settings(self) -> None:
        """Test audit logger initialization with settings."""
        settings = MagicMock()
        settings.AUDIT_LOG_ENABLED = False
        settings.AUDIT_LOG_LEVEL = "DEBUG"
        settings.AUDIT_LOG_RETENTION_DAYS = 30
        settings.AUDIT_LOG_INCLUDE_REQUEST_BODY = True
        settings.AUDIT_LOG_SENSITIVE_FIELDS = ["password", "secret"]

        logger = AuditLogger(settings=settings)

        assert logger.enabled is False
        assert logger.log_level == "DEBUG"
        assert logger.retention_days == 30
        assert logger.include_request_body is True
        assert "password" in logger.sensitive_fields
        assert "secret" in logger.sensitive_fields

    def test_log_auth_attempt_success(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging successful authentication."""
        audit_logger.log_auth_attempt(
            username="testuser",
            success=True,
            ip_address="127.0.0.1",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "auth.login.success"
        assert log_data["username"] == "testuser"
        assert log_data["result"] == "success"

    def test_log_auth_attempt_failure(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging failed authentication."""
        audit_logger.log_auth_attempt(
            username="testuser",
            success=False,
            ip_address="127.0.0.1",
            error="Invalid password",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "auth.login.failure"
        assert log_data["username"] == "testuser"
        assert log_data["result"] == "failure"
        assert log_data["error_message"] == "Invalid password"

    def test_log_auth_logout(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging user logout."""
        audit_logger.log_auth_logout(
            user_id="user123",
            username="testuser",
            ip_address="127.0.0.1",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "auth.logout"
        assert log_data["user_id"] == "user123"
        assert log_data["username"] == "testuser"

    def test_log_authz_check_denied(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging denied authorization."""
        audit_logger.log_authz_check(
            user_id="user123",
            username="testuser",
            resource_type="document",
            resource_id="doc456",
            action="delete",
            denied=True,
            reason="Insufficient permissions",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "authz.permission.denied"
        assert log_data["result"] == "failure"
        assert log_data["action"] == "delete"
        assert log_data["error_message"] == "Insufficient permissions"

    def test_log_authz_check_allowed(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging allowed authorization."""
        audit_logger.log_authz_check(
            user_id="user123",
            username="testuser",
            resource_type="document",
            resource_id="doc456",
            action="read",
            denied=False,
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["result"] == "success"

    def test_log_sensitive_operation_create(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging user creation."""
        audit_logger.log_sensitive_operation(
            user_id="admin1",
            operation="create",
            resource_type="user",
            resource_id="user123",
            username="admin",
            success=True,
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "user.created"
        assert log_data["action"] == "create"
        assert log_data["resource_type"] == "user"

    def test_log_sensitive_operation_delete(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging user deletion."""
        audit_logger.log_sensitive_operation(
            user_id="admin1",
            operation="delete",
            resource_type="user",
            resource_id="user123",
            username="admin",
            success=True,
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "user.deleted"

    def test_log_sensitive_operation_failed(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging failed sensitive operation."""
        audit_logger.log_sensitive_operation(
            user_id="admin1",
            operation="delete",
            resource_type="user",
            resource_id="user123",
            username="admin",
            success=False,
            error="User not found",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["result"] == "failure"
        assert log_data["error_message"] == "User not found"

    def test_log_privilege_escalation(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging privilege escalation attempt."""
        audit_logger.log_privilege_escalation(
            user_id="user123",
            old_role="user",
            new_role="admin",
            username="testuser",
            reason="Unauthorized escalation attempt",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "security.privilege.escalation"
        assert log_data["result"] == "failure"
        assert log_data["additional_data"]["old_role"] == "user"
        assert log_data["additional_data"]["new_role"] == "admin"

    def test_log_suspicious_activity(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging suspicious activity."""
        audit_logger.log_suspicious_activity(
            activity_type="brute_force",
            description="Multiple failed login attempts",
            user_id="user123",
            ip_address="192.168.1.1",
            severity="high",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "security.suspicious_activity"
        assert log_data["additional_data"]["activity_type"] == "brute_force"
        assert log_data["additional_data"]["severity"] == "high"

    def test_log_rate_limit_exceeded(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test logging rate limit exceeded."""
        audit_logger.log_rate_limit_exceeded(
            identifier="user123",
            limit=5,
            window=60,
            user_id="user123",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["event_type"] == "security.rate_limit.exceeded"
        assert log_data["additional_data"]["limit"] == 5
        assert log_data["additional_data"]["window"] == 60

    def test_disabled_logger_no_logging(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test that disabled logger doesn't log anything."""
        audit_logger.enabled = False

        audit_logger.log_auth_attempt(username="testuser", success=True)

        mock_logger.info.assert_not_called()

    def test_redact_sensitive_fields(self, audit_logger: AuditLogger) -> None:
        """Test redacting sensitive fields from logs."""
        data = {
            "username": "testuser",
            "password": "secret123",
            "email": "test@example.com",
            "token": "jwt_token_xyz",
        }

        redacted = audit_logger._redact_sensitive_fields(data)

        assert redacted["username"] == "testuser"
        assert redacted["password"] == "***REDACTED***"
        assert redacted["email"] == "test@example.com"
        assert redacted["token"] == "***REDACTED***"

    def test_redact_nested_fields(self, audit_logger: AuditLogger) -> None:
        """Test redacting nested sensitive fields."""
        data = {
            "user": {
                "name": "testuser",
                "password": "secret123",
                "credentials": {
                    "api_key": "key123",
                    "secret": "secret456",
                },
            },
        }

        redacted = audit_logger._redact_sensitive_fields(data)

        assert redacted["user"]["name"] == "testuser"
        assert redacted["user"]["password"] == "***REDACTED***"
        assert redacted["user"]["credentials"]["api_key"] == "***REDACTED***"
        assert redacted["user"]["credentials"]["secret"] == "***REDACTED***"

    def test_redact_list_fields(self, audit_logger: AuditLogger) -> None:
        """Test redacting sensitive fields in lists."""
        data = {
            "tokens": ["token1", "token2", "token3"],
            "credentials": [
                {"password": "pass1", "username": "user1"},
                {"password": "pass2", "username": "user2"},
            ],
        }

        redacted = audit_logger._redact_sensitive_fields(data)

        assert "token" in redacted["tokens"][0]  # Original structure preserved
        assert redacted["credentials"][0]["password"] == "***REDACTED***"

    def test_request_id_correlation(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test request ID correlation in logs."""
        audit_logger.log_auth_attempt(
            username="testuser",
            success=True,
            request_id="req-123-456",
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["request_id"] == "req-123-456"

    def test_additional_data_preserved(self, audit_logger: AuditLogger, mock_logger: MagicMock) -> None:
        """Test that additional data is preserved in logs."""
        additional = {
            "user_agent": "Mozilla/5.0",
            "request_method": "POST",
            "endpoint": "/api/users",
        }

        audit_logger.log_auth_attempt(
            username="testuser",
            success=True,
            additional_data=additional,
        )

        mock_logger.info.assert_called_once()
        call_args = mock_logger.info.call_args
        log_message = call_args[0][0]
        log_data = json.loads(log_message)

        assert log_data["additional_data"]["user_agent"] == "Mozilla/5.0"
        assert log_data["additional_data"]["request_method"] == "POST"


@pytest.mark.unit
@pytest.mark.security
class TestAuditEventTypes:
    """Test audit event type enum."""

    def test_all_event_types_defined(self) -> None:
        """Test that all event types are defined."""
        auth_events = [e for e in AuditEventType if "auth" in e.value]
        authz_events = [e for e in AuditEventType if "authz" in e.value]
        user_events = [e for e in AuditEventType if "user" in e.value]

        assert len(auth_events) > 0
        assert len(authz_events) > 0
        assert len(user_events) > 0

    def test_event_type_values_are_strings(self) -> None:
        """Test that event type values are strings."""
        for event in AuditEventType:
            assert isinstance(event.value, str)
            assert "." in event.value


@pytest.mark.unit
@pytest.mark.security
class TestGlobalAuditLogger:
    """Test global audit logger instance."""

    def test_get_audit_logger_creates_instance(self) -> None:
        """Test that get_audit_logger creates an instance."""
        logger = get_audit_logger()

        assert isinstance(logger, AuditLogger)
        assert logger.enabled is True

    def test_get_audit_logger_with_settings(self) -> None:
        """Test get_audit_logger with settings."""
        settings = MagicMock()
        settings.AUDIT_LOG_ENABLED = False

        logger = get_audit_logger(settings)

        assert isinstance(logger, AuditLogger)
        assert logger.enabled is False
