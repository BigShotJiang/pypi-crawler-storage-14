"""Security module tests.

Tests for authentication, authorization, and security components.
"""
