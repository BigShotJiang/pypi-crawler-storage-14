"""Unit tests for CSRF Protection Middleware."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from zephyr.app.middleware.csrf import CSRFMiddleware
from zephyr.exceptions import PermissionDenied


class TestCSRFMiddleware:
    """Test suite for CSRF middleware."""

    @pytest.fixture
    def mock_app(self) -> AsyncMock:
        """Create a mock ASGI app."""
        return AsyncMock()

    @pytest.fixture
    def middleware(self, mock_app: AsyncMock) -> CSRFMiddleware:
        """Create CSRF middleware instance."""
        return CSRFMiddleware(mock_app)

    @pytest.fixture
    def http_scope(self) -> dict:
        """Create a basic HTTP scope."""
        return {
            "type": "http",
            "method": "GET",
            "path": "/",
            "headers": [],
            "client": ("127.0.0.1", 8000),
        }

    @pytest.mark.asyncio
    async def test_middleware_initialization(self) -> None:
        """Test middleware initialization with default settings."""
        app = AsyncMock()
        middleware = CSRFMiddleware(app)

        assert middleware.enabled is True
        assert middleware.token_length == 32
        assert middleware.cookie_name == "csrf_token"
        assert middleware.cookie_secure is True
        assert middleware.cookie_httponly is True

    @pytest.mark.asyncio
    async def test_middleware_with_settings(self) -> None:
        """Test middleware initialization with custom settings."""
        app = AsyncMock()
        settings = MagicMock()
        settings.CSRF_ENABLED = False
        settings.CSRF_TOKEN_LENGTH = 64
        settings.CSRF_COOKIE_NAME = "custom_csrf"
        settings.CSRF_COOKIE_SECURE = False
        settings.CSRF_TRUSTED_ORIGINS = ["https://example.com"]

        middleware = CSRFMiddleware(app, settings=settings)

        assert middleware.enabled is False
        assert middleware.token_length == 64
        assert middleware.cookie_name == "custom_csrf"
        assert middleware.cookie_secure is False
        assert "https://example.com" in middleware.trusted_origins

    @pytest.mark.asyncio
    async def test_non_http_request_passthrough(self, middleware: CSRFMiddleware, mock_app: AsyncMock) -> None:
        """Test that non-HTTP requests pass through unchanged."""
        scope = {"type": "websocket", "path": "/ws"}
        receive = AsyncMock()
        send = AsyncMock()

        await middleware(scope, receive, send)

        mock_app.assert_called_once_with(scope, receive, send)

    @pytest.mark.asyncio
    async def test_disabled_middleware_passthrough(self, mock_app: AsyncMock, http_scope: dict) -> None:
        """Test that disabled middleware passes through unchanged."""
        middleware = CSRFMiddleware(mock_app)
        middleware.enabled = False

        receive = AsyncMock()
        send = AsyncMock()

        await middleware(http_scope, receive, send)

        mock_app.assert_called_once()

    @pytest.mark.asyncio
    async def test_safe_method_generates_token(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that safe methods (GET) generate CSRF token."""
        receive = AsyncMock()
        send = AsyncMock()

        async def send_mock(message: dict) -> None:
            if message["type"] == "http.response.start":
                headers = message.get("headers", [])
                csrf_cookie = [h for h in headers if b"csrf_token" in h[0]]
                assert len(csrf_cookie) > 0

        await middleware(http_scope, receive, send_mock)

        mock_app.assert_called_once()

    @pytest.mark.asyncio
    async def test_csrf_token_generation(self, middleware: CSRFMiddleware) -> None:
        """Test CSRF token generation creates unique tokens."""
        token1 = middleware._generate_csrf_token()
        token2 = middleware._generate_csrf_token()

        assert token1 != token2
        assert len(token1) == middleware.token_length
        assert len(token2) == middleware.token_length
        assert isinstance(token1, str)
        assert isinstance(token2, str)

    @pytest.mark.asyncio
    async def test_csrf_cookie_creation(self, middleware: CSRFMiddleware) -> None:
        """Test CSRF cookie creation with secure flags."""
        token = "test_token_123"
        cookie = middleware._create_csrf_cookie(token)

        assert "csrf_token=test_token_123" in cookie
        assert "Secure" in cookie
        assert "HttpOnly" in cookie
        assert "SameSite=Lax" in cookie
        assert "Path=/" in cookie
        assert "Max-Age=31536000" in cookie

    @pytest.mark.asyncio
    async def test_extract_token_from_cookie(self, middleware: CSRFMiddleware, http_scope: dict) -> None:
        """Test extracting CSRF token from cookies."""
        http_scope["headers"] = [(b"cookie", b"csrf_token=abc123; session=xyz")]

        token = middleware._extract_token_from_cookie(http_scope)

        assert token == "abc123"

    @pytest.mark.asyncio
    async def test_extract_token_from_cookie_missing(self, middleware: CSRFMiddleware, http_scope: dict) -> None:
        """Test extracting CSRF token when cookie is missing."""
        http_scope["headers"] = [(b"cookie", b"session=xyz")]

        token = middleware._extract_token_from_cookie(http_scope)

        assert token is None

    @pytest.mark.asyncio
    async def test_extract_token_from_header(self, middleware: CSRFMiddleware, http_scope: dict) -> None:
        """Test extracting CSRF token from headers."""
        http_scope["headers"] = [(b"x-csrf-token", b"header_token_123")]

        token = middleware._extract_token_from_header(http_scope)

        assert token == "header_token_123"

    @pytest.mark.asyncio
    async def test_extract_token_from_header_missing(self, middleware: CSRFMiddleware, http_scope: dict) -> None:
        """Test extracting CSRF token when header is missing."""
        http_scope["headers"] = []

        token = middleware._extract_token_from_header(http_scope)

        assert token is None

    @pytest.mark.asyncio
    async def test_is_safe_method(self, middleware: CSRFMiddleware) -> None:
        """Test safe method detection."""
        assert middleware._is_safe_method("GET") is True
        assert middleware._is_safe_method("HEAD") is True
        assert middleware._is_safe_method("OPTIONS") is True
        assert middleware._is_safe_method("POST") is False
        assert middleware._is_safe_method("PUT") is False
        assert middleware._is_safe_method("DELETE") is False
        assert middleware._is_safe_method("PATCH") is False

    @pytest.mark.asyncio
    async def test_is_trusted_origin(self, middleware: CSRFMiddleware, http_scope: dict) -> None:
        """Test trusted origin checking."""
        middleware.trusted_origins = ["https://example.com"]
        http_scope["headers"] = [(b"origin", b"https://example.com")]

        assert middleware._is_trusted_origin(http_scope) is True

    @pytest.mark.asyncio
    async def test_is_trusted_origin_not_trusted(self, middleware: CSRFMiddleware, http_scope: dict) -> None:
        """Test that untrusted origin is detected."""
        middleware.trusted_origins = ["https://example.com"]
        http_scope["headers"] = [(b"origin", b"https://evil.com")]

        assert middleware._is_trusted_origin(http_scope) is False

    @pytest.mark.asyncio
    async def test_post_request_without_token_raises_error(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that POST without CSRF token raises PermissionDenied."""
        http_scope["method"] = "POST"
        receive = AsyncMock()
        send = AsyncMock()

        with pytest.raises(PermissionDenied):
            await middleware(http_scope, receive, send)

    @pytest.mark.asyncio
    async def test_put_request_without_token_raises_error(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that PUT without CSRF token raises PermissionDenied."""
        http_scope["method"] = "PUT"
        receive = AsyncMock()
        send = AsyncMock()

        with pytest.raises(PermissionDenied):
            await middleware(http_scope, receive, send)

    @pytest.mark.asyncio
    async def test_delete_request_without_token_raises_error(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that DELETE without CSRF token raises PermissionDenied."""
        http_scope["method"] = "DELETE"
        receive = AsyncMock()
        send = AsyncMock()

        with pytest.raises(PermissionDenied):
            await middleware(http_scope, receive, send)

    @pytest.mark.asyncio
    async def test_options_request_safe(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that OPTIONS requests are safe and don't require token."""
        http_scope["method"] = "OPTIONS"
        receive = AsyncMock()
        send = AsyncMock()

        await middleware(http_scope, receive, send)

        mock_app.assert_called_once()

    @pytest.mark.asyncio
    async def test_head_request_safe(self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict) -> None:
        """Test that HEAD requests are safe and don't require token."""
        http_scope["method"] = "HEAD"
        receive = AsyncMock()
        send = AsyncMock()

        await middleware(http_scope, receive, send)

        mock_app.assert_called_once()

    @pytest.mark.asyncio
    async def test_token_mismatch_raises_error(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that mismatched tokens raise PermissionDenied."""
        http_scope["method"] = "POST"
        http_scope["headers"] = [
            (b"cookie", b"csrf_token=cookie_token"),
            (b"x-csrf-token", b"header_token"),
        ]
        receive = AsyncMock()
        send = AsyncMock()

        with pytest.raises(PermissionDenied):
            await middleware(http_scope, receive, send)

    @pytest.mark.asyncio
    async def test_trusted_origin_bypasses_csrf(
        self, middleware: CSRFMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that trusted origins bypass CSRF validation."""
        middleware.trusted_origins = ["https://example.com"]
        http_scope["method"] = "POST"
        http_scope["headers"] = [(b"origin", b"https://example.com")]
        receive = AsyncMock()
        send = AsyncMock()

        await middleware(http_scope, receive, send)

        mock_app.assert_called_once()


@pytest.mark.unit
@pytest.mark.security
class TestCSRFTokenGeneration:
    """Test CSRF token generation security."""

    def test_token_length_matches_config(self) -> None:
        """Test that generated token length matches configuration."""
        app = AsyncMock()
        settings = MagicMock()
        settings.CSRF_TOKEN_LENGTH = 64

        middleware = CSRFMiddleware(app, settings=settings)
        token = middleware._generate_csrf_token()

        assert len(token) == settings.CSRF_TOKEN_LENGTH

    def test_token_format_is_hex(self) -> None:
        """Test that generated token is valid hex string."""
        app = AsyncMock()
        middleware = CSRFMiddleware(app)
        token = middleware._generate_csrf_token()

        try:
            int(token, 16)
            assert True
        except ValueError:
            pytest.fail("Token is not a valid hex string")


@pytest.mark.unit
@pytest.mark.security
class TestCSRFCookieHandling:
    """Test CSRF cookie handling."""

    def test_cookie_insecure_flag(self) -> None:
        """Test that Secure flag can be disabled."""
        app = AsyncMock()
        middleware = CSRFMiddleware(app)
        middleware.cookie_secure = False

        cookie = middleware._create_csrf_cookie("token")

        assert "Secure" not in cookie

    def test_cookie_httponly_flag(self) -> None:
        """Test that HttpOnly flag can be disabled."""
        app = AsyncMock()
        middleware = CSRFMiddleware(app)
        middleware.cookie_httponly = False

        cookie = middleware._create_csrf_cookie("token")

        assert "HttpOnly" not in cookie

    def test_cookie_samesite_strict(self) -> None:
        """Test that SameSite can be set to Strict."""
        app = AsyncMock()
        middleware = CSRFMiddleware(app)
        middleware.cookie_samesite = "Strict"

        cookie = middleware._create_csrf_cookie("token")

        assert "SameSite=Strict" in cookie
