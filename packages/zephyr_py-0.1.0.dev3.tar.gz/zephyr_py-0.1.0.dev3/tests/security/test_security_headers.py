"""Unit tests for Security Headers Middleware."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from zephyr.app.middleware.security_headers import SecurityHeadersMiddleware


class TestSecurityHeadersMiddleware:
    """Test suite for security headers middleware."""

    @pytest.fixture
    def mock_app(self) -> AsyncMock:
        """Create a mock ASGI app."""
        return AsyncMock()

    @pytest.fixture
    def middleware(self, mock_app: AsyncMock) -> SecurityHeadersMiddleware:
        """Create security headers middleware instance."""
        return SecurityHeadersMiddleware(mock_app)

    @pytest.fixture
    def http_scope(self) -> dict:
        """Create a basic HTTP scope."""
        return {
            "type": "http",
            "method": "GET",
            "path": "/",
            "headers": [],
        }

    @pytest.mark.asyncio
    async def test_middleware_initialization(self) -> None:
        """Test middleware initialization with default settings."""
        app = AsyncMock()
        middleware = SecurityHeadersMiddleware(app)

        assert middleware.enabled is True
        assert middleware.frame_options == "DENY"
        assert middleware.content_type_options == "nosniff"
        assert isinstance(middleware.hsts_max_age, int)
        assert middleware.hsts_max_age == 31536000

    @pytest.mark.asyncio
    async def test_middleware_with_settings(self) -> None:
        """Test middleware initialization with custom settings."""
        app = AsyncMock()
        settings = MagicMock()
        settings.SECURITY_HEADERS_ENABLED = False
        settings.SECURITY_FRAME_OPTIONS = "SAMEORIGIN"
        settings.SECURITY_CSP_POLICY = "default-src 'none';"
        settings.SECURITY_HSTS_MAX_AGE = 60480000

        middleware = SecurityHeadersMiddleware(app, settings=settings)

        assert middleware.enabled is False
        assert middleware.frame_options == "SAMEORIGIN"
        assert middleware.csp_policy == "default-src 'none';"
        assert middleware.hsts_max_age == 60480000

    @pytest.mark.asyncio
    async def test_non_http_request_passthrough(
        self, middleware: SecurityHeadersMiddleware, mock_app: AsyncMock
    ) -> None:
        """Test that non-HTTP requests pass through unchanged."""
        scope = {"type": "websocket", "path": "/ws"}
        receive = AsyncMock()
        send = AsyncMock()

        await middleware(scope, receive, send)

        mock_app.assert_called_once()

    @pytest.mark.asyncio
    async def test_disabled_middleware_passthrough(self, mock_app: AsyncMock, http_scope: dict) -> None:
        """Test that disabled middleware passes through unchanged."""
        middleware = SecurityHeadersMiddleware(mock_app)
        middleware.enabled = False

        receive = AsyncMock()
        send = AsyncMock()

        await middleware(http_scope, receive, send)

        mock_app.assert_called_once()

    @pytest.mark.asyncio
    async def test_security_headers_added_to_response(
        self, middleware: SecurityHeadersMiddleware, mock_app: AsyncMock, http_scope: dict
    ) -> None:
        """Test that security headers are added to response."""
        receive = AsyncMock()
        headers_to_check = {}

        async def send_mock(message: dict) -> None:
            if message["type"] == "http.response.start":
                headers_list = message.get("headers", [])
                for key, value in headers_list:
                    headers_to_check[key.lower()] = value

        # Make mock app call send with a response
        async def mock_app_call(scope, recv, send):
            await send({"type": "http.response.start", "status": 200, "headers": []})
            await send({"type": "http.response.body", "body": b""})

        mock_app.side_effect = mock_app_call

        await middleware(http_scope, receive, send_mock)

        assert b"x-frame-options" in headers_to_check
        assert b"x-content-type-options" in headers_to_check
        assert b"strict-transport-security" in headers_to_check

    def test_frame_options_header(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test X-Frame-Options header."""
        headers = []
        headers = middleware._add_header(headers, "X-Frame-Options", "DENY")

        assert (b"x-frame-options", b"DENY") in headers

    def test_content_type_options_header(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test X-Content-Type-Options header."""
        headers = []
        headers = middleware._add_header(headers, "X-Content-Type-Options", "nosniff")

        assert (b"x-content-type-options", b"nosniff") in headers

    def test_xss_protection_header(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test X-XSS-Protection header."""
        headers = []
        headers = middleware._add_header(headers, "X-XSS-Protection", "1; mode=block")

        assert (b"x-xss-protection", b"1; mode=block") in headers

    def test_hsts_header_with_defaults(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test HSTS header with default settings."""
        headers = []
        headers = middleware._add_hsts_header(headers)

        hsts_value = next((v for k, v in headers if k.lower() == b"strict-transport-security"), None)
        assert hsts_value is not None
        assert b"max-age=31536000" in hsts_value
        assert b"includeSubDomains" in hsts_value

    def test_hsts_header_without_subdomains(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test HSTS header without subdomains."""
        middleware.hsts_include_subdomains = False
        headers = []
        headers = middleware._add_hsts_header(headers)

        hsts_value = next((v for k, v in headers if k.lower() == b"strict-transport-security"), None)
        assert hsts_value is not None
        assert b"includeSubDomains" not in hsts_value

    def test_hsts_header_with_preload(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test HSTS header with preload."""
        middleware.hsts_preload = True
        headers = []
        headers = middleware._add_hsts_header(headers)

        hsts_value = next((v for k, v in headers if k.lower() == b"strict-transport-security"), None)
        assert hsts_value is not None
        assert b"preload" in hsts_value

    def test_csp_header_with_nonce(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test CSP header includes nonce."""
        headers = []
        nonce = "test_nonce_123"
        headers = middleware._add_csp_header(headers, nonce)

        csp_value = next((v for k, v in headers if k.lower() == b"content-security-policy"), None)
        assert csp_value is not None
        assert f"nonce-{nonce}".encode() in csp_value

    def test_referrer_policy_header(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test Referrer-Policy header."""
        headers = []
        headers = middleware._add_header(headers, "Referrer-Policy", "strict-origin-when-cross-origin")

        assert (b"referrer-policy", b"strict-origin-when-cross-origin") in headers

    def test_permissions_policy_header(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test Permissions-Policy header."""
        headers = []
        policy = "geolocation=(), microphone=(), camera=()"
        headers = middleware._add_header(headers, "Permissions-Policy", policy)

        assert (b"permissions-policy", policy.encode()) in headers

    def test_add_header_replaces_existing(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test that adding a header replaces existing one."""
        headers = [(b"x-frame-options", b"SAMEORIGIN")]
        headers = middleware._add_header(headers, "X-Frame-Options", "DENY")

        x_frame_options = [v for k, v in headers if k.lower() == b"x-frame-options"]
        assert len(x_frame_options) == 1
        assert x_frame_options[0] == b"DENY"

    def test_add_header_case_insensitive(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test that header comparison is case-insensitive."""
        headers = [(b"X-Frame-Options", b"SAMEORIGIN")]
        headers = middleware._add_header(headers, "x-frame-options", "DENY")

        x_frame_options = [v for k, v in headers if k.lower() == b"x-frame-options"]
        assert len(x_frame_options) == 1
        assert x_frame_options[0] == b"DENY"

    def test_get_nonce_returns_string(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test that get_nonce returns a string."""
        nonce = middleware.get_nonce()

        assert isinstance(nonce, str)
        assert len(nonce) > 0

    def test_get_nonce_returns_unique_values(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test that get_nonce returns unique values."""
        nonce1 = middleware.get_nonce()
        nonce2 = middleware.get_nonce()

        assert nonce1 != nonce2

    def test_default_csp_policy(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test default CSP policy is set."""
        assert len(middleware.csp_policy) > 0
        assert "default-src" in middleware.csp_policy


@pytest.mark.unit
@pytest.mark.security
class TestSecurityHeadersCustomization:
    """Test security headers customization."""

    def test_custom_frame_options(self) -> None:
        """Test custom X-Frame-Options."""
        app = AsyncMock()
        middleware = SecurityHeadersMiddleware(app)
        middleware.frame_options = "SAMEORIGIN"

        headers = []
        headers = middleware._add_header(headers, "X-Frame-Options", middleware.frame_options)

        assert (b"x-frame-options", b"SAMEORIGIN") in headers

    def test_custom_csp_policy(self) -> None:
        """Test custom CSP policy."""
        app = AsyncMock()
        settings = MagicMock()
        settings.SECURITY_HEADERS_ENABLED = True
        settings.SECURITY_CSP_POLICY = "default-src 'none'; script-src 'none';"
        settings.SECURITY_FRAME_OPTIONS = "DENY"
        settings.SECURITY_CONTENT_TYPE_OPTIONS = "nosniff"
        settings.SECURITY_HSTS_MAX_AGE = 31536000
        settings.SECURITY_HSTS_INCLUDE_SUBDOMAINS = True
        settings.SECURITY_HSTS_PRELOAD = False
        settings.SECURITY_REFERRER_POLICY = "strict-origin-when-cross-origin"
        settings.SECURITY_PERMISSIONS_POLICY = "geolocation=(), microphone=(), camera=()"

        middleware = SecurityHeadersMiddleware(app, settings=settings)

        assert middleware.csp_policy == "default-src 'none'; script-src 'none';"

    def test_multiple_headers_not_duplicated(
        self,
    ) -> None:
        """Test that multiple headers are not duplicated."""
        app = AsyncMock()
        middleware = SecurityHeadersMiddleware(app)

        headers = []
        headers = middleware._add_header(headers, "X-Frame-Options", "DENY")
        headers = middleware._add_header(headers, "X-Content-Type-Options", "nosniff")
        headers = middleware._add_header(headers, "X-Frame-Options", "SAMEORIGIN")

        x_frame_options = [v for k, v in headers if k.lower() == b"x-frame-options"]
        assert len(x_frame_options) == 1


@pytest.mark.unit
@pytest.mark.security
class TestSecurityHeadersValidation:
    """Test security header values."""

    @pytest.fixture
    def mock_app(self) -> AsyncMock:
        """Create a mock ASGI app."""
        return AsyncMock()

    @pytest.fixture
    def middleware(self, mock_app: AsyncMock) -> SecurityHeadersMiddleware:
        """Create security headers middleware instance."""
        return SecurityHeadersMiddleware(mock_app)

    def test_hsts_max_age_is_number(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test HSTS max-age is valid number."""
        assert isinstance(middleware.hsts_max_age, int)
        assert middleware.hsts_max_age > 0

    def test_frame_options_valid_values(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test frame options have valid values."""
        valid_values = ["DENY", "SAMEORIGIN", "ALLOW-FROM"]
        middleware.frame_options = "DENY"

        assert middleware.frame_options in valid_values

    def test_referrer_policy_not_empty(self, middleware: SecurityHeadersMiddleware) -> None:
        """Test referrer policy is not empty."""
        assert middleware.referrer_policy
        assert len(middleware.referrer_policy) > 0
