"""Tests for Keycloak integration."""
