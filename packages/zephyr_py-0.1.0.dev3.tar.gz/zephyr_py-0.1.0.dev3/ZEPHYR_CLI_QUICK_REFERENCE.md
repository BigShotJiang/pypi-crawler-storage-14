# ⚡ ZEPHYR CLI - QUICK REFERENCE

**Quick lookup guide for Zephyr CLI commands**

---

## 🚀 QUICK START

```bash
# Initialize config
zephyr config init

# Start development
zephyr dev start --env dev

# View logs
zephyr monitor logs --follow

# Run migrations
zephyr db migrate upgrade

# Deploy to production
zephyr deploy start --env prod
```

---

## 📋 ALL COMMANDS (Grouped)

### CONFIG MANAGEMENT
```bash
zephyr config init                         # Create .env files
zephyr config init --env prod              # Create .env.prod
zephyr config show                         # Show all config
zephyr config show --env dev               # Show dev config
zephyr config get KEY                      # Get one value
zephyr config set KEY VALUE                # Set value
zephyr config set --env prod KEY VALUE     # Set in prod env
zephyr config validate                     # Check all required vars
zephyr config validate --env prod          # Check prod config
zephyr config diff dev prod                # Compare environments
```

### SERVICE MANAGEMENT
```bash
zephyr service list                        # List all services
zephyr service start <name>                # Start service
zephyr service stop <name>                 # Stop service
zephyr service restart <name>              # Restart service
zephyr service status <name>               # Check service status
zephyr service logs <name>                 # View service logs
zephyr service logs <name> --tail 50       # Last 50 lines
zephyr service logs <name> --follow        # Stream logs
```

### DEVELOPMENT ENVIRONMENT
```bash
zephyr dev start                           # Start all services
zephyr dev start --env dev                 # Start with dev config
zephyr dev start --group infrastructure    # Start specific group
zephyr dev stop                            # Stop all services
zephyr dev restart                         # Restart services
zephyr dev status                          # Check status
zephyr dev health                          # Health check
zephyr dev logs                            # View all logs
zephyr dev logs --service web --tail 100   # Service-specific
zephyr dev logs --follow                   # Real-time logs
zephyr dev shell                           # Interactive Python shell
zephyr dev shell --db                      # Shell with DB session
zephyr dev reset                           # Full cleanup
```

### DATABASE MANAGEMENT
```bash
zephyr db migrate create "description"     # Create migration
zephyr db migrate upgrade                  # Apply migrations
zephyr db migrate upgrade head              # To latest
zephyr db migrate downgrade -1              # Rollback 1 step
zephyr db migrate current                  # Show current version
zephyr db migrate history                  # Show all migrations
zephyr db seed --file seeds.sql            # Seed database
```

### DEPLOYMENT
```bash
zephyr deploy start                        # Deploy (default: dev)
zephyr deploy start --env staging          # Deploy to staging
zephyr deploy start --env prod             # Deploy to production
zephyr deploy stop                         # Stop deployment
zephyr deploy restart                      # Restart deployment
zephyr deploy status                       # Deployment status
zephyr deploy logs                         # View deployment logs
zephyr deploy logs --follow                # Real-time logs
zephyr deploy health-check                 # Check service health
zephyr deploy rollback                     # Rollback to previous
zephyr deploy rollback --steps 2           # Rollback 2 versions
```

### MONITORING
```bash
zephyr monitor logs                        # All logs
zephyr monitor logs --service user-svc    # Service-specific
zephyr monitor logs --tail 100 --follow    # Last 100, stream
zephyr monitor health                      # Health dashboard
zephyr monitor health --detailed           # Detailed status
zephyr monitor metrics                     # Performance metrics
zephyr monitor metrics --service api      # Service metrics
```

### INTERACTIVE SHELL
```bash
zephyr shell                               # Python REPL
zephyr shell --db                          # With DB session
zephyr shell --cache                       # With cache manager
zephyr shell --queue                       # With queue manager
```

### PROFILING & BENCHMARKS
```bash
zephyr profiling cpu [--duration 30]       # CPU profiling
zephyr profiling memory [--interval 100ms] # Memory profiling
zephyr profiling request-tracing <url>     # Trace request
zephyr profiling benchmark --file bench.py # Run benchmarks
```

---

## 🎯 COMMON WORKFLOWS

### First-Time Setup
```bash
1. zephyr config init
2. zephyr config set DATABASE_URL postgresql://...
3. zephyr dev start
4. zephyr db migrate upgrade
5. zephyr db seed
6. zephyr service list
```

### Daily Development
```bash
Morning:   zephyr dev start
          zephyr monitor logs --follow

During:   zephyr service logs <service>
         zephyr db migrate create "change"
         zephyr db migrate upgrade
         zephyr shell --db

Night:    zephyr dev stop
```

### Before Deployment
```bash
zephyr config validate --env prod
zephyr deploy start --env prod
zephyr monitor health
zephyr monitor logs --follow
```

### Debugging
```bash
zephyr service logs <name> --tail 100
zephyr monitor logs --follow
zephyr service status <name>
zephyr shell  # Interactive debugging
```

---

## 📁 ENVIRONMENT FILES

### File Hierarchy (Load order)

```
.env                    ← Default values
.env.dev                ← Dev overrides
.env.staging            ← Staging overrides
.env.prod               ← Production overrides
.env.local              ← Local machine overrides (gitignored)
CLI arguments           ← Command-line overrides
```

### Creating Env Files

```bash
# Create all default env files
zephyr config init

# Create specific env file
zephyr config init --env prod

# Validate all configs
zephyr config validate
```

---

## 🔍 VIEWING OUTPUT FORMATS

### Tables (default)
```bash
zephyr service list
zephyr monitor health
```

### JSON
```bash
zephyr config show --format json
zephyr service list --format json
```

### YAML
```bash
zephyr config show --format yaml
```

---

## ✅ TROUBLESHOOTING

### Service won't start
```bash
zephyr service logs <name>  # Check error
zephyr config validate      # Check config
zephyr monitor health       # Check status
```

### Database migration failed
```bash
zephyr db migrate current               # Check current state
zephyr db migrate downgrade -1          # Rollback
zephyr db migrate upgrade               # Try again
```

### Can't connect to Docker
```bash
# Check Docker is running
zephyr monitor health

# Check config
zephyr config show
```

### Lost in development
```bash
zephyr dev reset            # Full cleanup
zephyr config init          # Reinitialize
zephyr dev start            # Start fresh
```

---

## 🎨 OUTPUT EXAMPLES

### `zephyr service list`
```
NAME            STATUS      PORTS
─────────────────────────────────────
postgres        running     5432:5432
redis           running     6379:6379
user-service    running     8001:8000
order-service   running     8002:8000
payment-svc     running     8003:8000
```

### `zephyr monitor health`
```
SERVICE HEALTH STATUS
─────────────────────────────
✅ postgres:        Healthy
✅ redis:           Healthy
✅ user-service:    Healthy
✅ order-service:   Healthy
✅ payment-svc:     Healthy

Overall: ALL HEALTHY ✅
```

### `zephyr config show`
```
DATABASE_URL          postgresql://localhost:5432/myapp
REDIS_URL             redis://localhost:6379/0
APP_PORT              8000
LOG_LEVEL             INFO
ENVIRONMENT           development
DEBUG                 true
```

---

## ⌨️ CLI HELP

```bash
zephyr --help              # Show all commands
zephyr --version           # Show version
zephyr config --help       # Help for config command
zephyr service start --help # Help for service start
```

---

## 🔧 ADVANCED USAGE

### Combine commands
```bash
# View logs and follow specific service
zephyr dev logs --service user-svc --tail 100 --follow

# Deploy and monitor
zephyr deploy start --env prod && zephyr monitor logs --follow
```

### Use different environments
```bash
# Dev environment (default)
zephyr dev start

# Staging environment
zephyr dev start --env staging

# Production environment
zephyr deploy start --env prod
```

### Service groups
```bash
# Start only infrastructure
zephyr dev start --group infrastructure

# Start specific services
zephyr dev start --group user-services,payment-services
```

---

## 🚫 KEY PRINCIPLE: NO SUBPROCESS

**This is NOT how Zephyr CLI works:**
```python
import subprocess
subprocess.run(['docker', 'ps'])
```

**This IS how it works:**
```python
from dockpysdk import AsyncDockerClient

async with AsyncDockerClient() as client:
    containers = await client.containers.list()
```

---

## 📚 RELATED DOCUMENTATION

- **Full Architecture:** `ZEPHYR_CLI_ARCHITECTURE.md`
- **Roadmap:** `ZEPHYR_ROADMAP.md`
- **Phase 3 Details:** `ZEPHYR_PHASE3_ARCHITECTURE.md`
- **zhcli SDK:** https://github.com/bbdevs/dockpy-cli

---

**Last Updated:** November 22, 2025



