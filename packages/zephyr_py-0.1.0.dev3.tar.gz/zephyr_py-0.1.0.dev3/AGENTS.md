# Zephyr Framework - AI Agent Guidelines

> **Note:** This file replaces `.cursorrules` which is now deprecated. All AI agents should follow the guidelines in this document.

## Package Management with UV

### Dependency Management

**ALWAYS use `uv` for all Python package management operations:**

1. **Sync dependencies (MANDATORY):**
   ```bash
   uv sync --all-groups --all-extras
   ```
   - Always use `--all-groups` to include all dependency groups
   - Always use `--all-extras` to include all optional dependencies
   - This ensures all development, testing, and optional dependencies are installed

2. **Running Python executables:**
   ```bash
   # ✅ CORRECT - Use uv run for Python interpreter
   uv run python script.py
   uv run pytest
   uv run mypy zephyr/
   uv run ruff check zephyr/
   
   # ❌ WRONG - Don't use system Python directly
   python script.py  # DO NOT USE
   pytest  # DO NOT USE (unless in uv environment)
   ```

3. **Adding dependencies:**
   ```bash
   uv add package-name
   uv add --dev package-name  # For dev dependencies
   uv add --group test package-name  # For test group
   ```

4. **Removing dependencies:**
   ```bash
   uv remove package-name
   ```

5. **Updating dependencies:**
   ```bash
   uv sync --all-groups --all-extras  # Updates lock file
   uv lock --upgrade  # Upgrade all dependencies
   ```

### Why UV?

- **Fast:** UV is significantly faster than pip
- **Reliable:** Uses lock files (`uv.lock`) for reproducible builds
- **Modern:** Built-in support for dependency groups and extras
- **Integrated:** Works seamlessly with `pyproject.toml`

### Common Commands

```bash
# Install/sync all dependencies
uv sync --all-groups --all-extras

# Run tests
uv run pytest

# Run linting
uv run ruff check zephyr/
uv run ruff format zephyr/

# Run type checking
uv run mypy zephyr/

# Run any Python script
uv run python path/to/script.py

# Activate virtual environment (if needed)
source .venv/bin/activate  # After uv sync
```

## Code Standards

See `.cursorrules` for detailed code standards (still maintained for reference, but AGENTS.md takes precedence for operational guidelines).

## Linting Rules (MANDATORY)

### Type Hints

**NEVER use `Any` - Use unified types from `zephyr._types`:**

```python
# ❌ WRONG
from typing import Any
def process(**kwargs: Any) -> Any:
    pass

# ✅ CORRECT
from zephyr._types import ALL, KWARGS
def process(**kwargs: ALL) -> None:
    pass
def handle_metadata(metadata: KWARGS) -> None:
    pass
```

**Rules:**
- Import `ALL` and `KWARGS` from `zephyr._types`
- Use `ALL` for `**kwargs` and `*args` parameters
- Use `KWARGS` for dict parameters
- Remove unused imports (F401)

### Datetime Usage

**ALWAYS use timezone-aware datetime:**

```python
# ❌ WRONG
from datetime import datetime
created_at = Field(default_factory=datetime.utcnow)

# ✅ CORRECT
from datetime import datetime, UTC
created_at = Field(default_factory=lambda: datetime.now(UTC))
```

**Rules:**
- Import `UTC` from `datetime` module
- Use `datetime.now(UTC)` instead of `datetime.utcnow()`
- Use `lambda: datetime.now(UTC)` in `default_factory`

### Exception Handling

**Catch specific exceptions, not bare `Exception`:**

```python
# ❌ WRONG
try:
    result = evaluate(expr)
except Exception as e:
    raise Error(f"Failed: {e}")

# ✅ CORRECT
try:
    result = evaluate(expr)
except (ValueError, TypeError, KeyError, AttributeError) as e:
    raise Error(f"Failed: {e}") from e
```

**Rules:**
- Never catch bare `Exception` (BLE001)
- Always use exception chaining: `raise ... from e` (B904)
- Catch specific exception types: `ValueError`, `TypeError`, `KeyError`, `AttributeError`, etc.

### Logging

**Use `%` formatting, not f-strings:**

```python
# ❌ WRONG
logger.info(f"Added role: {role.name}")
logger.info(f"Assigned role '{role_name}' to user '{user_id}'")

# ✅ CORRECT
logger.info("Added role: %s", role.name)
logger.info("Assigned role '%s' to user '%s'", role_name, user_id)
```

**Rules:**
- Use lazy `%` formatting for logging (G004)
- Never use f-strings in logging statements
- Format: `logger.info("Message: %s", variable)`

### Pydantic Validators

**Use `@field_validator` with `@classmethod`:**

```python
# ❌ WRONG
from pydantic import validator

@validator("name")
def validate_name(cls, v: str) -> str:
    return v.strip()

# ✅ CORRECT
from pydantic import field_validator

@field_validator("name")
@classmethod
def validate_name(cls, v: str) -> str:
    return v.strip()
```

**Rules:**
- Use `@field_validator` (not `@validator`)
- Always add `@classmethod` decorator
- Use type hints for parameters and return types

### Class Attributes

**Annotate mutable class attributes with `ClassVar`:**

```python
# ❌ WRONG
class Config:
    json_encoders = {
        # ...
    }

# ✅ CORRECT
from typing import ClassVar

class Config:
    json_encoders: ClassVar[dict] = {
        # ...
    }
```

**Rules:**
- Import `ClassVar` from `typing` at module level
- Annotate mutable class attributes with `ClassVar[type]` (RUF012)

### Performance

**Use list comprehensions instead of loops:**

```python
# ❌ WRONG
matched_rules = []
for rule in policy.get_active_rules():
    if self._evaluate_rule(rule, context):
        matched_rules.append(rule)

# ✅ CORRECT
matched_rules = [
    rule for rule in policy.get_active_rules()
    if self._evaluate_rule(rule, context)
]
```

**Rules:**
- Prefer list comprehensions for creating transformed lists (PERF401)
- More readable and performant

### Docstrings

**Use imperative mood for docstring first line:**

```python
# ❌ WRONG
def __str__(self) -> str:
    """String representation."""
    return self.name

# ✅ CORRECT
def __str__(self) -> str:
    """Return string representation."""
    return self.name
```

**Rules:**
- First line of docstring must be in imperative mood (D401)
- Use "Return", "Check", "Get", "Create", etc. (not "Returns", "Checks", etc.)

### Line Length

**Maximum 120 characters per line:**

```python
# ❌ WRONG (>120 chars)
reason=f"{'Allowed' if highest_priority_rule.effect == Effect.ALLOW else 'Denied'} by rule {highest_priority_rule.id}",

# ✅ CORRECT
reason=(
    f"{'Allowed' if highest_priority_rule.effect == Effect.ALLOW else 'Denied'} "
    f"by rule {highest_priority_rule.id}"
),
```

**Rules:**
- Maximum line length: 120 characters (E501)
- Split long lines using parentheses for continuation
- Break at logical points (operators, commas)

### Import Organization

**Organize imports in this order:**

```python
# 1. Standard library
from typing import ClassVar
from datetime import datetime, UTC

# 2. Third-party
from pydantic import BaseModel, Field

# 3. Local imports
from zephyr._types import ALL, KWARGS
from .exceptions import RBACError
```

**Rules:**
- Standard library first
- Third-party second
- Local imports last
- Remove unused imports (F401)

### Security

**Handle eval() usage carefully:**

```python
# ⚠️ Use with caution and explanation
try:
    # This is a simplified evaluator - in production, use a proper expression parser
    # Note: eval is used here for expression evaluation in a controlled environment
    # The builtins are disabled and only safe operations are allowed
    return eval(expr, {"__builtins__": {}}, {})  # noqa: S307
except (ValueError, TypeError, NameError, SyntaxError):
    return False
```

**Rules:**
- Add `# noqa: S307` comment with explanation
- Document why eval is necessary
- Disable builtins: `{"__builtins__": {}}`
- Catch specific exceptions

### Unused Parameters

**Prefix unused parameters with `_`:**

```python
# ❌ WRONG
def __init__(self, message: str, condition: str | None = None, **kwargs: ALL) -> None:
    # condition not used
    super().__init__(message=message, **kwargs)

# ✅ CORRECT
def __init__(self, message: str, _condition: str | None = None, **kwargs: ALL) -> None:
    # _condition is part of interface but not used
    super().__init__(message=message, **kwargs)
```

**Rules:**
- Use unused parameters or prefix with `_` (ARG002)
- If parameter is required by interface, prefix with `_` and document why

### Exception Messages

**Assign exception messages to variables first:**

```python
# ❌ WRONG
raise NotImplementedError("Subclasses must implement authenticate method")
raise AuthenticationError(f"Authentication failed: {e}") from e

# ✅ CORRECT
msg = "Subclasses must implement authenticate method"
raise NotImplementedError(msg)

error_msg = f"Authentication failed: {e}"
raise AuthenticationError(error_msg) from e
```

**Rules:**
- Always assign exception messages to variables first (EM101/EM102)
- Use descriptive variable names: `msg`, `error_msg`, `message`
- Never use f-strings directly in exception constructors

### Return Statements

**Avoid unnecessary `else` after `return`:**

```python
# ❌ WRONG
if not user.is_active:
    return None
else:
    return user

# ✅ CORRECT
if not user.is_active:
    return None
return user  # noqa: TRY300
```

**Rules:**
- Remove `else` after `return` statement (RET505)
- If TRY300 conflicts, use `# noqa: TRY300` comment
- Only use `noqa` for contradictory linting rules

### Boolean Arguments

**Make boolean arguments keyword-only:**

```python
# ❌ WRONG
async def decode_token(self, token: str, verify: bool = True) -> JWTPayload:
    pass

# ✅ CORRECT
async def decode_token(self, token: str, *, verify: bool = True) -> JWTPayload:
    pass
```

**Rules:**
- Use `*,` before boolean arguments (FBT001/FBT002)
- Makes boolean arguments explicit and prevents mistakes
- Applies to all boolean default parameters

### Magic Numbers

**Define constants for magic numbers:**

```python
# ❌ WRONG
if len(password_bytes) > 72:
    password = password_bytes[:72].decode("utf-8", errors="ignore")

# ✅ CORRECT
# Bcrypt maximum password length in bytes
BCRYPT_MAX_PASSWORD_LENGTH = 72

if len(password_bytes) > BCRYPT_MAX_PASSWORD_LENGTH:
    password = password_bytes[:BCRYPT_MAX_PASSWORD_LENGTH].decode("utf-8", errors="ignore")
```

**Rules:**
- Define constants for all magic numbers (PLR2004)
- Use UPPER_SNAKE_CASE for constant names
- Add comment explaining the constant's purpose

### Type-Checking Imports

**Handle runtime imports correctly:**

```python
# ❌ WRONG (if used at runtime)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .jwt import JWTManager  # But used in __init__ at runtime!

# ✅ CORRECT (when used at runtime)
from .jwt import JWTManager  # noqa: TC001
from .tokens import TokenManager  # noqa: TC001

# ✅ CORRECT (when only used for type hints)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .jwt import JWTManager
```

**Rules:**
- Use `TYPE_CHECKING` only when imports are NOT used at runtime
- If used in `__init__` or method bodies, import normally with `# noqa: TC001`
- TC001 is a false positive when imports are needed at runtime

### Conditional Imports

**Handle fallback imports correctly:**

```python
# ❌ WRONG (linting error PLC0415)
try:
    return self.context.hash(password)
except ValueError:
    import bcrypt  # Import inside try block
    return bcrypt.hashpw(...)

# ✅ CORRECT (import at top, use conditionally)
try:
    import bcrypt
except ImportError:
    bcrypt = None

try:
    return self.context.hash(password)
except ValueError:
    if bcrypt:
        return bcrypt.hashpw(...)
```

**Rules:**
- Prefer top-level imports when possible (PLC0415)
- For fallback imports, import at top level and check for None
- Only use conditional imports when absolutely necessary

### Noqa Comments

**Use `noqa` comments sparingly and only when necessary:**

```python
# ✅ CORRECT - Contradictory linting rules
return user  # noqa: TRY300  # RET505 wants no else, TRY300 wants else

# ✅ CORRECT - False positive
from .jwt import JWTManager  # noqa: TC001  # Used at runtime, not just types

# ✅ CORRECT - Security false positive
token_type: str = "access"  # noqa: S107  # Not a password, just a token type

# ❌ WRONG - Using noqa to ignore real issues
def bad_code():  # noqa: ALL  # Don't do this!
    pass
```

**Rules:**
- Only use `noqa` for contradictory rules or false positives
- Always add comment explaining WHY the noqa is needed
- Never use `noqa: ALL` or ignore entire files
- Prefer fixing the code over using `noqa`

## Quick Reference

- **Package Manager:** `uv` (always)
- **Sync Command:** `uv sync --all-groups --all-extras` (mandatory)
- **Python Execution:** `uv run python` (always)
- **Test Execution:** `uv run pytest` (always)
- **Lock File:** `uv.lock` (auto-generated, commit to repo)
- **Type Hints:** Use `ALL`/`KWARGS` from `zephyr._types` (never `Any`)
- **Datetime:** Use `datetime.now(UTC)` (never `datetime.utcnow()`)
- **Exceptions:** Catch specific types, use `from e` chaining, assign messages to variables
- **Logging:** Use `%` formatting (never f-strings)
- **Validators:** Use `@field_validator` with `@classmethod`
- **Line Length:** Maximum 120 characters
- **Boolean Args:** Make keyword-only with `*,`
- **Magic Numbers:** Define constants (UPPER_SNAKE_CASE)
- **Unused Params:** Prefix with `_`
- **Noqa:** Only for contradictory rules or false positives


