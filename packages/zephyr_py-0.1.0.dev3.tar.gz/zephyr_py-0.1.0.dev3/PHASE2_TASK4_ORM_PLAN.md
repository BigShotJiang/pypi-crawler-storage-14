# 🗄️ PHASE 2 TASK 4: DATABASE ORM LAYER - IMPLEMENTATION PLAN

📋 **Status:** ⏳ NOT STARTED  
⏱️ **Estimated Effort:** 20-24 hours  
🎯 **Priority:** 🔴 **CRITICAL - FOR LMS/CMS**  
✅ **Tests Required:** 115+ comprehensive tests  
📊 **Coverage Target:** 85%+  

---

## 📋 TASK BREAKDOWN (10 Sub-Tasks)

```mermaid
graph TD
    A["ORM Implementation<br/>20-24 hours"] --> B["1. Setup Module<br/>2-3h"]
    A --> C["2. Create Models<br/>3-4h"]
    A --> D["3. Connection Pool<br/>2-3h"]
    A --> E["4. Query Builder<br/>4-5h"]
    A --> F["5. Relationships<br/>3-4h"]
    A --> G["6. Transactions<br/>2-3h"]
    A --> H["7. Tests<br/>8-10h"]
    A --> I["8. Health Checks<br/>1-2h"]
    A --> J["9. Configuration<br/>1h"]
    A --> K["10. Documentation<br/>2-3h"]
```

---

## 🎯 TASK 1: Setup ORM Module Structure (2-3 hours)

**Status:** ⏳ Pending  
**Deliverables:** 5 core files  
**Type Hints:** 100% required

### Files to Create:

```
zephyr/db/
├── __init__.py                    # Module exports
├── base.py                        # Base model, declarative base
├── exceptions.py                  # Database exceptions
├── session.py                     # Session management
└── _types.py                      # Type definitions
```

### Implementation Details:

#### `zephyr/db/base.py` (250 lines)
```python
from __future__ import annotations
from sqlalchemy import Column, DateTime
from sqlalchemy.orm import declarative_base
from datetime import datetime, timezone

# Create declarative base
Base = declarative_base()

class BaseModel(Base):
    """Base model for all database entities."""
    __abstract__ = True
    
    # Timestamps
    created_at: datetime = Column(DateTime, default=datetime.now(timezone.utc))
    updated_at: datetime = Column(DateTime, onupdate=datetime.now(timezone.utc))
    
    def to_dict(self) -> dict:
        """Convert model to dictionary."""
        pass
    
    @classmethod
    def from_dict(cls, data: dict) -> BaseModel:
        """Create model from dictionary."""
        pass
```

#### `zephyr/db/exceptions.py` (100 lines)
```python
class DatabaseError(Exception):
    """Base database error."""
    pass

class ConnectionError(DatabaseError):
    """Connection failed."""
    pass

class QueryError(DatabaseError):
    """Query execution failed."""
    pass

class IntegrityError(DatabaseError):
    """Data integrity violation."""
    pass

class NotFoundError(DatabaseError):
    """Record not found."""
    pass
```

#### `zephyr/db/session.py` (200 lines)
```python
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.pool import NullPool, QueuePool

class DatabaseConnection:
    """Manages database connections."""
    
    def __init__(self, database_url: str):
        self.engine = None
        self.session_factory = None
    
    async def connect(self) -> None:
        """Create connection pool."""
        pass
    
    async def disconnect(self) -> None:
        """Close all connections."""
        pass
    
    async def get_session(self) -> AsyncSession:
        """Get database session."""
        pass
```

### Configuration in `zephyr/conf/base.py`:

```python
# Database
DATABASE_URL: str = "sqlite+aiosqlite:///./test.db"
DATABASE_ECHO: bool = False
DATABASE_POOL_SIZE: int = 20
DATABASE_MAX_OVERFLOW: int = 10
DATABASE_POOL_TIMEOUT: int = 30
DATABASE_POOL_RECYCLE: int = 3600
DATABASE_READ_REPLICAS: list[str] = []
```

---

## 🎯 TASK 2: Create LMS/CMS Data Models (3-4 hours)

**Status:** ⏳ Pending  
**Deliverables:** 6-8 model files  
**Models Required:** User, Course, Lesson, Enrollment, Progress, Certificate, Resource

### Files to Create:

```
zephyr/db/models/
├── __init__.py
├── user.py                       # User model + enums
├── course.py                     # Course model
├── lesson.py                     # Lesson model
├── enrollment.py                 # Enrollment N-N model
├── progress.py                   # Student progress
├── certificate.py                # Certificates
└── resource.py                   # Course resources
```

### Model Definitions:

#### `zephyr/db/models/user.py` (150 lines)
```python
from __future__ import annotations
from enum import Enum
from sqlalchemy import String, Boolean, Column, Integer, Text
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel
from datetime import datetime, timezone

class UserRole(str, Enum):
    """User roles."""
    ADMIN = "admin"
    INSTRUCTOR = "instructor"
    STUDENT = "student"

class User(BaseModel):
    """User model - Students, Instructors, Admins."""
    __tablename__ = "users"
    
    id: int = Column(Integer, primary_key=True)
    email: str = Column(String(255), unique=True, nullable=False)
    username: str = Column(String(255), unique=True, nullable=False)
    password_hash: str = Column(String(255), nullable=False)
    full_name: str = Column(String(255))
    bio: str = Column(Text, nullable=True)
    role: UserRole = Column(String(50), default=UserRole.STUDENT)
    is_active: bool = Column(Boolean, default=True)
    
    # Relationships
    enrollments = relationship("Enrollment", back_populates="user")
    progress = relationship("Progress", back_populates="user")
    certificates = relationship("Certificate", back_populates="user")
    courses_created = relationship("Course", back_populates="instructor")
    
    def verify_password(self, password: str) -> bool:
        """Verify password."""
        pass
```

#### `zephyr/db/models/course.py` (180 lines)
```python
from __future__ import annotations
from sqlalchemy import String, Text, Integer, Column, ForeignKey
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel

class Course(BaseModel):
    """Course model."""
    __tablename__ = "courses"
    
    id: int = Column(Integer, primary_key=True)
    title: str = Column(String(255), nullable=False)
    description: str = Column(Text, nullable=False)
    slug: str = Column(String(255), unique=True, nullable=False)
    category: str = Column(String(100), nullable=False)
    instructor_id: int = Column(Integer, ForeignKey("users.id"))
    is_published: bool = Column(Boolean, default=False)
    thumbnail_url: str = Column(String(500), nullable=True)
    
    # Relationships
    instructor = relationship("User", back_populates="courses_created")
    lessons = relationship("Lesson", back_populates="course", cascade="all, delete")
    enrollments = relationship("Enrollment", back_populates="course", cascade="all, delete")
    certificates = relationship("Certificate", back_populates="course", cascade="all, delete")
```

#### `zephyr/db/models/lesson.py` (150 lines)
```python
from __future__ import annotations
from sqlalchemy import String, Text, Integer, Column, ForeignKey
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel

class Lesson(BaseModel):
    """Lesson model."""
    __tablename__ = "lessons"
    
    id: int = Column(Integer, primary_key=True)
    course_id: int = Column(Integer, ForeignKey("courses.id"), nullable=False)
    title: str = Column(String(255), nullable=False)
    content: str = Column(Text)
    video_url: str = Column(String(500), nullable=True)
    order: int = Column(Integer)
    duration_minutes: int = Column(Integer, default=0)
    
    # Relationships
    course = relationship("Course", back_populates="lessons")
    progress = relationship("Progress", back_populates="lesson", cascade="all, delete")
    resources = relationship("Resource", back_populates="lesson", cascade="all, delete")
```

#### `zephyr/db/models/enrollment.py` (120 lines)
```python
from __future__ import annotations
from sqlalchemy import Integer, Column, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel

class Enrollment(BaseModel):
    """Enrollment model - N-N relationship between User and Course."""
    __tablename__ = "enrollments"
    __table_args__ = (
        UniqueConstraint("user_id", "course_id", name="uq_user_course"),
    )
    
    id: int = Column(Integer, primary_key=True)
    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    course_id: int = Column(Integer, ForeignKey("courses.id"), nullable=False)
    progress_percentage: float = Column(Float, default=0.0)
    is_completed: bool = Column(Boolean, default=False)
    
    # Relationships
    user = relationship("User", back_populates="enrollments")
    course = relationship("Course", back_populates="enrollments")
```

#### `zephyr/db/models/progress.py` (140 lines)
```python
from __future__ import annotations
from sqlalchemy import Integer, Float, Column, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel

class Progress(BaseModel):
    """Student progress model."""
    __tablename__ = "progress"
    
    id: int = Column(Integer, primary_key=True)
    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    lesson_id: int = Column(Integer, ForeignKey("lessons.id"), nullable=False)
    is_completed: bool = Column(Boolean, default=False)
    score: float = Column(Float, nullable=True)
    time_spent_seconds: int = Column(Integer, default=0)
    
    # Relationships
    user = relationship("User", back_populates="progress")
    lesson = relationship("Lesson", back_populates="progress")
```

#### `zephyr/db/models/certificate.py` (130 lines)
```python
from __future__ import annotations
from sqlalchemy import String, Text, Integer, Column, ForeignKey
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel

class Certificate(BaseModel):
    """Certificate model."""
    __tablename__ = "certificates"
    
    id: int = Column(Integer, primary_key=True)
    user_id: int = Column(Integer, ForeignKey("users.id"), nullable=False)
    course_id: int = Column(Integer, ForeignKey("courses.id"), nullable=False)
    verification_code: str = Column(String(255), unique=True)
    certificate_url: str = Column(String(500), nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="certificates")
    course = relationship("Course", back_populates="certificates")
```

#### `zephyr/db/models/resource.py` (100 lines)
```python
from __future__ import annotations
from sqlalchemy import String, Integer, Column, ForeignKey
from sqlalchemy.orm import relationship
from zephyr.db.base import BaseModel

class Resource(BaseModel):
    """Course resource (files, links, etc)."""
    __tablename__ = "resources"
    
    id: int = Column(Integer, primary_key=True)
    lesson_id: int = Column(Integer, ForeignKey("lessons.id"), nullable=False)
    title: str = Column(String(255), nullable=False)
    resource_url: str = Column(String(500), nullable=False)
    resource_type: str = Column(String(50))  # pdf, video, link, etc
    
    # Relationships
    lesson = relationship("Lesson", back_populates="resources")
```

---

## 🎯 TASK 3: Connection Pool & Session Management (2-3 hours)

**Status:** ⏳ Pending  
**Deliverables:** 2 files  
**Features:** Connection pooling, health checks, cleanup

### Files:

```
zephyr/db/
├── connection.py                 # Connection pool manager
└── pool.py                       # Connection pool utilities
```

### Implementation:

#### `zephyr/db/connection.py` (250 lines)
```python
from __future__ import annotations
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine
from sqlalchemy.pool import QueuePool, NullPool
from contextlib import asynccontextmanager
from zephyr.conf import settings

class DatabaseConnection:
    """Database connection manager with pooling."""
    
    _instance: DatabaseConnection | None = None
    
    def __init__(self):
        self.engine: AsyncEngine | None = None
        self.session_factory = None
    
    @classmethod
    def get_instance(cls) -> DatabaseConnection:
        """Get singleton instance."""
        if cls._instance is None:
            cls._instance = DatabaseConnection()
        return cls._instance
    
    async def initialize(self) -> None:
        """Initialize database connection and pool."""
        self.engine = create_async_engine(
            settings.DATABASE_URL,
            echo=settings.DATABASE_ECHO,
            pool_size=settings.DATABASE_POOL_SIZE,
            max_overflow=settings.DATABASE_MAX_OVERFLOW,
            pool_timeout=settings.DATABASE_POOL_TIMEOUT,
            pool_recycle=settings.DATABASE_POOL_RECYCLE,
            connect_args={"check_same_thread": False}
        )
        
        from sqlalchemy.orm import sessionmaker
        self.session_factory = sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
    
    @asynccontextmanager
    async def get_session(self):
        """Get database session context manager."""
        if self.session_factory is None:
            raise RuntimeError("Database not initialized")
        
        async with self.session_factory() as session:
            try:
                yield session
            finally:
                await session.close()
    
    async def health_check(self) -> bool:
        """Check database connectivity."""
        try:
            async with self.get_session() as session:
                await session.execute("SELECT 1")
                return True
        except Exception:
            return False
    
    async def shutdown(self) -> None:
        """Close all connections."""
        if self.engine:
            await self.engine.dispose()
```

---

## 🎯 TASK 4: Type-Safe Query Builder (4-5 hours)

**Status:** ⏳ Pending  
**Deliverables:** 2 files  
**Features:** Filters, joins, ordering, pagination

### Files:

```
zephyr/db/
├── query.py                      # Query builder
└── filters.py                    # Filter helpers
```

### Implementation:

#### `zephyr/db/query.py` (350 lines)
```python
from __future__ import annotations
from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from typing import TypeVar, Generic, Type, Any

T = TypeVar('T')

class Query(Generic[T]):
    """Type-safe query builder."""
    
    def __init__(self, model: Type[T], session: AsyncSession):
        self.model = model
        self.session = session
        self._stmt = select(model)
        self._filters: list[Any] = []
        self._order_by_clause: list[Any] = []
        self._limit_val: int | None = None
        self._offset_val: int | None = None
    
    def filter(self, *conditions) -> Query[T]:
        """Add filter conditions."""
        self._filters.extend(conditions)
        return self
    
    def filter_by(self, **kwargs) -> Query[T]:
        """Filter by column values."""
        for key, value in kwargs.items():
            self._filters.append(getattr(self.model, key) == value)
        return self
    
    def order_by(self, *columns) -> Query[T]:
        """Order results."""
        self._order_by_clause.extend(columns)
        return self
    
    def limit(self, limit: int) -> Query[T]:
        """Limit results."""
        self._limit_val = limit
        return self
    
    def offset(self, offset: int) -> Query[T]:
        """Offset results."""
        self._offset_val = offset
        return self
    
    async def all(self) -> list[T]:
        """Get all results."""
        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        return result.scalars().all()
    
    async def first(self) -> T | None:
        """Get first result."""
        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        return result.scalars().first()
    
    async def one(self) -> T:
        """Get one result (raises if none)."""
        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        row = result.scalars().one()
        return row
    
    async def count(self) -> int:
        """Count results."""
        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        return len(result.scalars().all())
    
    def _build_stmt(self):
        """Build statement with filters."""
        stmt = select(self.model)
        
        if self._filters:
            stmt = stmt.where(and_(*self._filters))
        
        if self._order_by_clause:
            stmt = stmt.order_by(*self._order_by_clause)
        
        if self._limit_val:
            stmt = stmt.limit(self._limit_val)
        
        if self._offset_val:
            stmt = stmt.offset(self._offset_val)
        
        return stmt
```

---

## 🎯 TASK 5: Relationship Handling (3-4 hours)

**Status:** ⏳ Pending  
**Deliverables:** Advanced relationship features  
**Features:** Lazy loading, eager loading, N-N management

### Key Relationships to Implement:

1. **User ↔ Enrollment ↔ Course** (N-N via Enrollment)
2. **Course → Lessons** (1-N)
3. **User → Progress → Lessons** (Track completion)
4. **Course → Certificates** (1-N)
5. **User → Certificates** (1-N)

### Implementation in models (already done in Task 2)

---

## 🎯 TASK 6: Transaction Management (2-3 hours)

**Status:** ⏳ Pending  
**Deliverables:** 1 file  
**Features:** ACID transactions, rollback, context managers

### File:

```
zephyr/db/
└── transactions.py               # Transaction handling
```

### Implementation:

```python
from __future__ import annotations
from contextlib import asynccontextmanager
from sqlalchemy.ext.asyncio import AsyncSession

class Transaction:
    """ACID transaction manager."""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    @asynccontextmanager
    async def begin(self):
        """Begin transaction context."""
        try:
            yield self.session
            await self.session.commit()
        except Exception:
            await self.session.rollback()
            raise
    
    async def commit(self) -> None:
        """Commit transaction."""
        await self.session.commit()
    
    async def rollback(self) -> None:
        """Rollback transaction."""
        await self.session.rollback()
```

---

## 🎯 TASK 7: Comprehensive Tests (8-10 hours)

**Status:** ⏳ Pending  
**Deliverables:** 115+ tests  
**Coverage Target:** 85%+

### Test Files:

```
tests/db/
├── __init__.py
├── conftest.py                   # Fixtures
├── test_base.py                  # Base model tests
├── test_connection.py            # Connection tests
├── test_models.py                # All model tests
│   ├── test_user_model.py       # User CRUD
│   ├── test_course_model.py     # Course CRUD
│   ├── test_lesson_model.py     # Lesson CRUD
│   ├── test_enrollment_model.py # N-N relationships
│   ├── test_progress_model.py   # Progress tracking
│   └── test_certificate_model.py # Certificates
├── test_query.py                 # Query builder tests
├── test_relationships.py         # Relationship handling
└── test_transactions.py          # Transaction tests
```

### Test Coverage:

```
User Model (15 tests):
├─ Create user
├─ Read user by ID
├─ Update user
├─ Delete user
├─ Query by email
├─ Verify password
├─ Role management
└─ Uniqueness constraints

Course Model (15 tests):
├─ Create course
├─ Update course
├─ Publish/unpublish
├─ Query by instructor
├─ Cascade delete lessons
└─ Enrollment relationships

Enrollment Model (20 tests):
├─ Create enrollment
├─ N-N relationships
├─ Progress tracking
├─ Duplicate prevention
├─ Cascade delete
└─ Query by user/course

Query Builder (20 tests):
├─ Filter operations
├─ Order by
├─ Limit/offset
├─ Joins
├─ Aggregations
└─ Complex queries

Transactions (15 tests):
├─ Commit
├─ Rollback
├─ Nested transactions
├─ Error handling
└─ Concurrency

Connection Pool (15 tests):
├─ Pool creation
├─ Health checks
├─ Timeout handling
├─ Resource cleanup
└─ Error recovery
```

---

## 🎯 TASK 8: Health Checks & Validation (1-2 hours)

**Status:** ⏳ Pending  
**Deliverables:** Health check endpoints  

### File:

```
zephyr/db/
└── health.py                     # Health checks
```

### Features:

```python
class DatabaseHealth:
    """Database health checks."""
    
    async def check_connection(self) -> dict:
        """Check database connection."""
        pass
    
    async def check_pool(self) -> dict:
        """Check connection pool status."""
        pass
    
    async def check_replicas(self) -> dict:
        """Check read replicas."""
        pass
    
    async def full_check(self) -> dict:
        """Full health check."""
        pass
```

---

## 🎯 TASK 9: Configuration Updates (1 hour)

**Status:** ⏳ Pending  
**File:** `zephyr/conf/base.py`

### Add Settings:

```python
# Database Configuration
DATABASE_URL: str = Field(
    default="sqlite+aiosqlite:///./test.db",
    description="Database URL"
)
DATABASE_ECHO: bool = Field(default=False, description="Log SQL")
DATABASE_POOL_SIZE: int = Field(default=20, description="Connection pool size")
DATABASE_MAX_OVERFLOW: int = Field(default=10, description="Max overflow")
DATABASE_POOL_TIMEOUT: int = Field(default=30, description="Pool timeout")
DATABASE_POOL_RECYCLE: int = Field(default=3600, description="Recycle interval")
DATABASE_READ_REPLICAS: list[str] = Field(default=[], description="Read replicas")

# Supported databases
# - sqlite+aiosqlite:///./test.db
# - postgresql+asyncpg://user:pass@localhost/dbname
# - mysql+aiomysql://user:pass@localhost/dbname
```

---

## 🎯 TASK 10: Documentation (2-3 hours)

**Status:** ⏳ Pending  
**Deliverables:** Comprehensive ORM guide

### Documentation Files:

```
docs/
├── orm-guide.md                  # Complete ORM guide
├── models.md                     # Model reference
├── queries.md                    # Query examples
├── relationships.md              # Relationship patterns
├── transactions.md               # Transaction handling
└── migrations.md                 # Migration guide (for Task 5)
```

### Contents:

- Installation & setup
- Creating models
- CRUD operations
- Querying & filtering
- Relationships (1-1, 1-N, N-N)
- Transactions
- Health checks
- Performance tips
- Common patterns

---

## 📊 TASK SUMMARY

| Task | Hours | Status | Tests | Files |
|------|-------|--------|-------|-------|
| 1. Setup | 2-3h | ⏳ | 10 | 5 |
| 2. Models | 3-4h | ⏳ | 25 | 8 |
| 3. Connection | 2-3h | ⏳ | 15 | 2 |
| 4. Query | 4-5h | ⏳ | 20 | 2 |
| 5. Relationships | 3-4h | ⏳ | 15 | 0 |
| 6. Transactions | 2-3h | ⏳ | 15 | 1 |
| 7. Tests | 8-10h | ⏳ | 115 | 10 |
| 8. Health | 1-2h | ⏳ | 10 | 1 |
| 9. Config | 1h | ⏳ | 5 | 1 |
| 10. Docs | 2-3h | ⏳ | - | 5 |
| **TOTAL** | **20-24h** | **⏳** | **115+** | **35+** |

---

## 🎯 EXECUTION ORDER

1. ✅ Task 1: Setup (foundational)
2. ✅ Task 2: Models (data structure)
3. ✅ Task 3: Connection (infrastructure)
4. ✅ Task 4: Query (query interface)
5. ✅ Task 5: Relationships (model relationships)
6. ✅ Task 6: Transactions (data integrity)
7. ✅ Task 7: Tests (validation - write as you go!)
8. ✅ Task 8: Health (monitoring)
9. ✅ Task 9: Config (settings)
10. ✅ Task 10: Docs (documentation)

---

## 📈 SUCCESS METRICS

✅ **Requirements:**
- [ ] 20-24 hours estimated effort
- [ ] 115+ comprehensive tests
- [ ] 85%+ code coverage
- [ ] 100% type hints
- [ ] 0 linting errors
- [ ] 7-8 data models for LMS/CMS
- [ ] Full async/await
- [ ] Production-ready quality

✅ **Features:**
- [ ] Multi-backend support (SQLite, PostgreSQL, MySQL)
- [ ] Connection pooling
- [ ] Query builder with filters, joins, ordering
- [ ] N-N relationship handling
- [ ] ACID transactions
- [ ] Health checks
- [ ] Comprehensive error handling

---

## 🚀 READY TO START?

All tasks documented. Begin with **Task 1: Setup Module Structure**.

**Shall I start implementing Task 1 now?** ✅


