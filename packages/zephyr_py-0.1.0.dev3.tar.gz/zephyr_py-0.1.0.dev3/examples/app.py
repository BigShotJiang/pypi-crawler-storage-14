"""EDUORAA Backend - Very Basic Zephyr Example"""

from zephyr import Zephyr

app = Zephyr(debug=True)


# Root endpoint
@app.get("/")
async def root() -> dict:
    """Welcome endpoint."""
    return {
        "message": "Welcome to EDUORAA Backend",
        "version": "0.1.0",
    }


# Health check
@app.get("/health")
async def health() -> dict:
    """Health check endpoint."""
    return {"status": "healthy"}


# Get current user (demo)
@app.get("/api/users/me")
async def get_current_user() -> dict:
    """Get current user info."""
    return {
        "id": "user-123",
        "username": "john_doe",
        "email": "john@example.com",
    }


# List courses
@app.get("/api/courses")
async def list_courses() -> dict:
    """List all courses."""
    return {
        "courses": [
            {"id": 1, "name": "Python Basics", "instructor": "Alice"},
            {"id": 2, "name": "Web Development", "instructor": "Bob"},
        ],
    }


# Create a new course (POST)
@app.post("/api/courses")
async def create_course() -> dict:
    """Create a new course."""
    return {
        "id": 3,
        "name": "New Course",
        "instructor": "Charlie",
        "created": True,
    }


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
