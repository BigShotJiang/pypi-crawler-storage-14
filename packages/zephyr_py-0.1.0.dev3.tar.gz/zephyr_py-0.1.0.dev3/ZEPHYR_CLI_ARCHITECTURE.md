# 🎯 ZEPHYR CLI - ARCHITECTURE & USER INTERACTION

**Version:** 1.0  
**Date:** November 22, 2025  
**Status:** Design Document  
**Based On:** zhcli (dockpy-cli) - Pure Python async Docker SDK

---

## 📋 TABLE OF CONTENTS

1. [Architecture Overview](#architecture-overview)
2. [Core Principles](#core-principles)
3. [Zephyr CLI Structure](#zephyr-cli-structure)
4. [User Workflows](#user-workflows)
5. [Command Reference](#command-reference)
6. [Implementation Plan](#implementation-plan)
7. [No Subprocess Rule](#no-subprocess-rule)
8. [Integration with zhcli](#integration-with-zhcli)

---

## ARCHITECTURE OVERVIEW

### Design Philosophy

Zephyr CLI is built on top of **zhcli** (dockpy-cli), a production-ready Python Docker SDK with async-first architecture.

```
User Terminal
    ↓
Zephyr CLI (Click)
    ↓
Zephyr Commands (Async functions)
    ├─ EnvManager (Load .env files)
    ├─ ConfigLoader (Parse configuration)
    └─ zhcli SDK (AsyncDockerClient)
        ↓
    Docker Engine (Direct HTTP API)
        └─ No subprocess calls!
```

### Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **CLI Framework** | Click | Command parsing, routing |
| **Async Runtime** | asyncio | Non-blocking execution |
| **Docker API** | zhcli SDK (httpx) | Direct Docker Engine communication |
| **Terminal UI** | Rich | Formatted output (tables, colors, progress) |
| **Logging** | structlog | Structured logging with context |
| **Configuration** | EnvManager | .env file hierarchy |
| **Type Safety** | mypy (strict) | Full type annotations |

---

## CORE PRINCIPLES

### 1. NO SUBPROCESS CALLS

**❌ NEVER DO THIS:**
```python
import subprocess
subprocess.run(['docker', 'ps'])
subprocess.run(['docker-compose', 'up'])
os.system('docker ...')
```

**✅ ALWAYS DO THIS:**
```python
from dockpysdk import AsyncDockerClient

async with AsyncDockerClient() as client:
    containers = await client.containers.list()
```

### 2. PURE ASYNC EXECUTION

All user interactions are non-blocking:
- EnvManager operations → Async file I/O
- Docker operations → Async HTTP via zhcli
- Database operations → Async SQLAlchemy
- Logging → Non-blocking structlog

### 3. DEPENDENCY: ZHCLI

Zephyr CLI **depends on zhcli (dockpy-cli)** and reuses:
- AsyncDockerClient
- Click CLI infrastructure
- structlog logging
- Rich formatting utilities

### 4. CONFIGURATION HIERARCHY

Environment loading order (first match wins):
```
1. Default values (built-in)
   ↓
2. .env (global)
   ↓
3. .env.{env} (environment-specific: dev, staging, prod)
   ↓
4. .env.local (local overrides - .gitignored)
   ↓
5. CLI arguments (--env-var KEY=VALUE)
```

---

## ZEPHYR CLI STRUCTURE

### Package Organization

```
zephyr/
├── cli/                                    ← CLI Package
│   ├── pyproject.toml
│   │   dependencies:
│   │   - zephyr-py>=0.1.0
│   │   - dockpy-cli>=0.1.0              ← USES ZHCLI
│   │   - pydantic>=2.0.0
│   │   - pyyaml>=6.0
│   │
│   ├── zephyr_cli/
│   │   ├── __init__.py
│   │   ├── main.py                       (CLI entry point)
│   │   │
│   │   ├── commands/                     (Zephyr-specific commands)
│   │   │   ├── __init__.py
│   │   │   ├── config.py                 (config init/show/set/get/validate)
│   │   │   ├── service.py                (service list/start/stop/logs)
│   │   │   ├── dev.py                    (dev start/stop/logs/shell)
│   │   │   ├── db.py                     (db migrate/seed)
│   │   │   ├── deploy.py                 (deploy start/stop/logs)
│   │   │   ├── monitor.py                (monitor logs/health/metrics)
│   │   │   ├── shell.py                  (interactive shell)
│   │   │   └── profiling.py              (profiling/benchmark)
│   │   │
│   │   ├── core/                         (Zephyr-specific utilities)
│   │   │   ├── __init__.py
│   │   │   ├── env_manager.py            (Load/manage .env files)
│   │   │   ├── config_loader.py          (Parse configuration)
│   │   │   ├── service_registry.py       (Service discovery)
│   │   │   └── exceptions.py             (Zephyr CLI exceptions)
│   │   │
│   │   └── utils/
│   │       ├── __init__.py
│   │       ├── validators.py             (Validation helpers)
│   │       └── formatters.py             (Output formatting)
│   │
│   ├── tests/
│   │   ├── conftest.py
│   │   ├── test_commands/
│   │   ├── test_core/
│   │   └── test_utils/
│   │
│   └── README.md
│
└── [rest of zephyr framework...]
```

### Main Entry Point

**zephyr/cli/zephyr_cli/main.py:**
```python
import click
import asyncio
from zephyr_cli.commands import config, service, dev, db, deploy, monitor

@click.group()
@click.version_option(version="0.1.0")
def cli():
    """Zephyr Framework - All-in-one CLI
    
    Pure async, no subprocess calls, built on zhcli
    """
    pass

# Register command groups
cli.add_command(config.config)
cli.add_command(service.service)
cli.add_command(dev.dev)
cli.add_command(db.db)
cli.add_command(deploy.deploy)
cli.add_command(monitor.monitor)

if __name__ == '__main__':
    cli()
```

---

## USER WORKFLOWS

### Workflow 1: Initial Setup (Developer)

```
Step 1: Initialize project
$ zephyr init my-project --template monolith

Step 2: Initialize configuration
$ zephyr config init

Step 3: Review/modify config
$ zephyr config show
$ zephyr config set DATABASE_URL postgresql://localhost/myapp
$ zephyr config validate

Step 4: Start development environment
$ zephyr dev start --env dev

Step 5: Initialize database
$ zephyr db migrate upgrade
$ zephyr db seed --file seeds.sql

Step 6: Verify everything running
$ zephyr service list
$ zephyr monitor health
```

### Workflow 2: Daily Development

```
Morning:
$ zephyr dev start --env dev
$ zephyr monitor logs --follow

During Development:
$ zephyr service logs user-service --tail 100
$ zephyr db migrate create "Add new field"
$ zephyr db migrate upgrade
$ zephyr shell --db  (interactive with DB context)

Testing:
$ zephyr profiling cpu --duration 30
$ zephyr profiling memory

Cleanup:
$ zephyr dev stop
$ zephyr dev reset  (full cleanup)
```

### Workflow 3: Deployment (Production)

```
Prepare:
$ zephyr config show --env prod
$ zephyr config validate --env prod

Deploy:
$ zephyr deploy start --env prod

Monitor:
$ zephyr monitor logs --follow
$ zephyr monitor health
$ zephyr monitor metrics

Rollback (if needed):
$ zephyr deploy rollback
```

### Workflow 4: Debugging

```
View service logs:
$ zephyr service logs order-service --tail 50

Stream real-time logs:
$ zephyr monitor logs --follow

Check service status:
$ zephyr service status

Get health info:
$ zephyr monitor health

Interactive shell:
$ zephyr shell
>>> # Now you can run Python code with app context
```

---

## COMMAND REFERENCE

### CONFIG COMMANDS

```bash
# Initialize environment files
zephyr config init
zephyr config init --env prod

# View configuration
zephyr config show
zephyr config show --env dev
zephyr config show --format json

# Get specific value
zephyr config get DATABASE_URL
zephyr config get --env prod DATABASE_URL

# Set value
zephyr config set KEY VALUE
zephyr config set --env prod DATABASE_URL postgresql://...
zephyr config set --local DEBUG true    (Override locally)

# Validate configuration
zephyr config validate
zephyr config validate --env prod

# Compare environments
zephyr config diff dev prod
```

### SERVICE COMMANDS

```bash
# List services
zephyr service list
zephyr service list --format json

# Service lifecycle
zephyr service start <name>
zephyr service stop <name>
zephyr service restart <name>
zephyr service status <name>

# Service logs
zephyr service logs <name>
zephyr service logs <name> --tail 100
zephyr service logs <name> --follow
zephyr service logs <name> --timestamps
```

### DEV COMMANDS

```bash
# Development environment
zephyr dev start
zephyr dev start --env dev
zephyr dev start --group infrastructure    (Start specific group)

zephyr dev stop
zephyr dev restart
zephyr dev status
zephyr dev health

# Logs and monitoring
zephyr dev logs
zephyr dev logs --service user-service
zephyr dev logs --tail 100 --follow

# Utilities
zephyr dev shell
zephyr dev shell --db                      (With DB context)
zephyr dev shell --cache                   (With cache context)

# Cleanup
zephyr dev reset                           (Remove containers/volumes)
```

### DATABASE COMMANDS

```bash
# Migration management
zephyr db migrate create "description"
zephyr db migrate upgrade [revision]
zephyr db migrate downgrade [-n]
zephyr db migrate current
zephyr db migrate history

# Seeding
zephyr db seed --file seeds.sql
zephyr db seed --file seeds.py

# Database shell
zephyr db shell
```

### DEPLOYMENT COMMANDS

```bash
# Deployment lifecycle
zephyr deploy start [--env prod]
zephyr deploy stop
zephyr deploy restart
zephyr deploy status
zephyr deploy health-check

# Logs and monitoring
zephyr deploy logs
zephyr deploy logs --service user-service --follow

# Rollback
zephyr deploy rollback
zephyr deploy rollback --steps 2
```

### MONITORING COMMANDS

```bash
# Logs
zephyr monitor logs
zephyr monitor logs --service <name>
zephyr monitor logs --tail 100 --follow

# Health
zephyr monitor health
zephyr monitor health --detailed

# Metrics
zephyr monitor metrics
zephyr monitor metrics --service <name>
```

### SHELL COMMANDS

```bash
# Interactive Python shell
zephyr shell
zephyr shell --db                  (With SQLAlchemy session)
zephyr shell --cache               (With cache manager)
zephyr shell --queue               (With queue manager)
```

### PROFILING COMMANDS

```bash
# Performance profiling
zephyr profiling cpu [--duration 30]
zephyr profiling memory [--sample-rate 100ms]
zephyr profiling request-tracing <url>
zephyr profiling benchmark --file benchmarks.py
```

---

## IMPLEMENTATION PLAN

### TIER 1: CLI Core (2-3h - START FIRST)

**Files to create:**
1. `zephyr/cli/pyproject.toml` (depends on dockpy-cli)
2. `zephyr/cli/zephyr_cli/main.py` (Click CLI entry)
3. `zephyr/cli/zephyr_cli/core/env_manager.py` (EnvManager)
4. `zephyr/cli/zephyr_cli/core/config_loader.py` (ConfigLoader)
5. `zephyr/cli/zephyr_cli/commands/config.py` (config commands)

**Commands to implement:**
- `zephyr --version`
- `zephyr --help`
- `zephyr config init`
- `zephyr config show`
- `zephyr config set/get`

---

### TIER 2: Service & Dev Commands (3-4h)

**Files to create:**
1. `zephyr/cli/zephyr_cli/commands/service.py`
2. `zephyr/cli/zephyr_cli/commands/dev.py`
3. `zephyr/cli/zephyr_cli/core/compose_generator.py`

**Commands to implement:**
- `zephyr service list/start/stop/logs`
- `zephyr dev start/stop/logs`

---

### TIER 3: Database Commands (2-3h)

**Files to create:**
1. `zephyr/cli/zephyr_cli/commands/db.py`

**Commands to implement:**
- `zephyr db migrate create/upgrade/downgrade`
- `zephyr db seed`

---

### TIER 4: Deployment & Monitoring (3-4h)

**Files to create:**
1. `zephyr/cli/zephyr_cli/commands/deploy.py`
2. `zephyr/cli/zephyr_cli/commands/monitor.py`

**Commands to implement:**
- `zephyr deploy start/stop/status`
- `zephyr monitor logs/health`

---

### TIER 5: Advanced Tools (2-3h)

**Files to create:**
1. `zephyr/cli/zephyr_cli/commands/shell.py`
2. `zephyr/cli/zephyr_cli/commands/profiling.py`

**Commands to implement:**
- `zephyr shell`
- `zephyr profiling cpu/memory/benchmark`

---

## NO SUBPROCESS RULE

### Why?

1. **Performance** - No process spawning overhead
2. **Reliability** - No shell escaping issues
3. **Responsiveness** - Pure async execution
4. **Maintainability** - Easier to debug and test

### Implementation

**zhcli provides AsyncDockerClient** - use it directly:

```python
# ❌ WRONG
import subprocess
subprocess.run(['docker', 'ps'])

# ✅ RIGHT
from dockpysdk import AsyncDockerClient

async with AsyncDockerClient() as client:
    containers = await client.containers.list()
```

### All Operations via zhcli SDK

| Operation | Method |
|-----------|--------|
| **Container create/start/stop** | `client.containers.*()` |
| **List services** | `client.containers.list()` |
| **Get logs** | `client.containers.logs()` |
| **Docker Compose** | `client.compose.*()` |
| **Image operations** | `client.images.*()` |
| **Network operations** | `client.networks.*()` |

---

## INTEGRATION WITH ZHCLI

### Dependencies

**zephyr/cli/pyproject.toml:**
```toml
[project]
name = "zephyr-cli"
dependencies = [
    "zephyr-py>=0.1.0",           # Main framework
    "dockpy-cli>=0.1.0",          # Use zhcli as base ← KEY
    "pydantic>=2.0.0",
    "pyyaml>=6.0",
]

[project.scripts]
zephyr = "zephyr_cli.main:cli"
```

### What We Use from zhcli

1. **AsyncDockerClient** - Direct Docker API access
   ```python
   from dockpysdk import AsyncDockerClient
   ```

2. **Click CLI Framework** - Command structure
   ```python
   import click
   from dockpycli.base import AsyncCommand
   ```

3. **Rich Formatting** - Terminal UI
   ```python
   from rich.console import Console
   from rich.table import Table
   ```

4. **structlog Logging** - Structured logs
   ```python
   import structlog
   logger = structlog.get_logger()
   ```

### What We Add (Zephyr-specific)

1. **EnvManager** - .env file hierarchy
2. **ConfigLoader** - Configuration parsing
3. **Service Registry** - Service discovery
4. **Zephyr Commands** - All app-specific commands
5. **Database Integration** - Alembic + SQLAlchemy

---

## EXECUTION FLOW (Example)

### Command: `zephyr dev start --env dev`

```
1. User enters: $ zephyr dev start --env dev
                        ↓
2. Click parses: dev_group.start_command(env='dev')
                        ↓
3. Async function: async def start(env: str)
                        ↓
4. Load config: EnvManager.load_config('dev')
                        └─ Reads: .env, .env.dev, .env.local
                        ↓
5. Generate compose: ComposeGenerator.generate()
                        ↓
6. Use zhcli SDK: AsyncDockerClient.compose.up(compose_content)
                        ↓
7. Direct Docker API: POST /v1.40/containers/create (Unix socket)
                        ↓
8. Docker Engine: Creates & starts containers
                        └─ No subprocess!
                        ↓
9. Format output: Rich.Table + Console
                        ↓
10. Display: ✅ Dev environment started
```

---

## ERROR HANDLING

### Exception Hierarchy

```python
# zephyr/cli/zephyr_cli/core/exceptions.py

class ZephyrCLIError(Exception):
    """Base CLI exception"""
    pass

class ConfigError(ZephyrCLIError):
    """Configuration error"""
    pass

class ServiceError(ZephyrCLIError):
    """Service operation error"""
    pass

class DeploymentError(ZephyrCLIError):
    """Deployment error"""
    pass

class EnvironmentError(ZephyrCLIError):
    """Environment setup error"""
    pass
```

### Error Messages

All errors caught and formatted with Rich:

```python
try:
    await operation()
except ServiceError as e:
    console.print(f"[red]❌ Error:[/red] {e}")
    sys.exit(1)
```

---

## TESTING STRATEGY

### Test Categories

1. **Unit Tests** - EnvManager, ConfigLoader, helpers
2. **Integration Tests** - Commands with mock Docker
3. **End-to-End** - Full workflows with test Docker

### Example Test

```python
# tests/test_commands/test_config.py
import pytest
from click.testing import CliRunner
from zephyr_cli.main import cli

def test_config_init():
    runner = CliRunner()
    result = runner.invoke(cli, ['config', 'init'])
    
    assert result.exit_code == 0
    assert '.env' in result.output
    assert 'initialized' in result.output
```

---

## DEPLOYMENT

### Installation

```bash
# Install from source
cd zephyr/cli
uv sync

# Install entry point
pip install -e .

# Verify
zephyr --version
```

### Distribution

```bash
# Build package
hatch build

# Publish to PyPI
twine upload dist/*

# Users can install
pip install zephyr-cli
```

---

## FUTURE ENHANCEMENTS

1. **Shell Completion** - Tab completion for commands
2. **Config Validation** - Schema validation
3. **Hooks** - Pre/post command hooks
4. **Plugins** - Plugin system for extensions
5. **Remote Management** - SSH-based remote CLI
6. **Web UI** - Web-based dashboard (optional)

---

## REFERENCES

- **zhcli Documentation:** https://github.com/bbdevs/dockpy-cli
- **Click Documentation:** https://click.palletsprojects.com/
- **Rich Documentation:** https://rich.readthedocs.io/
- **asyncio Documentation:** https://docs.python.org/3/library/asyncio.html

---

**Last Updated:** November 22, 2025  
**Status:** Design Document (Ready for Implementation)  
**Next Step:** Implement TIER 1 (CLI Core)



