"""Database ORM module.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

# Public API - backend agnostic
from zephyr.db.base import Base, BaseModel
from zephyr.db.connection import ConnectionManager, DatabaseConnection
from zephyr.db.exceptions import (
    ConnectionError,
    DatabaseError,
    IntegrityError,
    NotFoundError,
    QueryError,
)
from zephyr.db.pool import PoolConfig
from zephyr.db.query import QueryBuilder
from zephyr.db.relationships import RelationshipManager, LazyLoadStrategy, CascadeStrategy
from zephyr.db.session import Session, SessionManager
from zephyr.db.transactions import TransactionManager

# Health and configuration
from zephyr.db.config import DatabaseSettings
from zephyr.db.health import HealthChecker, HealthStatus

# Backend access (if needed)
from zephyr.db.backends import BackendFactory

__all__ = [
    # Models
    "Base",
    "BaseModel",
    # Connection management (public API)
    "ConnectionManager",
    "DatabaseConnection",
    "SessionManager",
    "Session",
    # Query building
    "QueryBuilder",
    # Relationships
    "RelationshipManager",
    "LazyLoadStrategy",
    "CascadeStrategy",
    # Transactions
    "TransactionManager",
    # Health and configuration
    "HealthChecker",
    "HealthStatus",
    "DatabaseSettings",
    # Configuration
    "PoolConfig",
    # Exceptions
    "DatabaseError",
    "ConnectionError",
    "QueryError",
    "IntegrityError",
    "NotFoundError",
    # Backend access
    "BackendFactory",
]
