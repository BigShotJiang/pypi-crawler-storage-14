"""Database connection management.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any
from collections.abc import AsyncGenerator

from zephyr.db.backends.base import DatabaseBackend
from zephyr.db.backends.factory import BackendFactory
from zephyr.db.pool import PoolConfig


class DatabaseConnection:
    """Low-level database connection manager."""

    def __init__(
        self,
        database_url: str,
        pool_size: int = 20,
        max_overflow: int = 10,
        pool_timeout: int = 30,
        pool_recycle: int = 3600,
        echo: bool = False,
    ) -> None:
        """Initialize database connection.

        Args:
            database_url: Database connection URL
            pool_size: Connection pool size
            max_overflow: Max overflow connections
            pool_timeout: Pool timeout in seconds
            pool_recycle: Pool recycle interval in seconds
            echo: Enable SQL echo logging

        """
        self.database_url = database_url
        self.pool_config = PoolConfig(
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            echo=echo,
        )
        self.backend: DatabaseBackend | None = None
        self.engine: Any = None
        self.session_factory: Any = None

    async def initialize(self) -> None:
        """Initialize database backend."""
        self.backend = BackendFactory.create(
            "sqlalchemy",
            self.database_url,
            self.pool_config,
        )
        await self.backend.initialize()

    async def shutdown(self) -> None:
        """Shutdown database backend."""
        if self.backend:
            await self.backend.shutdown()
            self.backend = None

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[Any, None]:
        """Get database session.

        Yields:
            Session: Database session

        Raises:
            RuntimeError: If not initialized

        """
        if not self.backend:
            raise RuntimeError("DatabaseConnection not initialized.")

        async with self.backend.get_session() as session:
            yield session

    async def health_check(self) -> bool:
        """Check database health.

        Returns:
            bool: True if healthy

        """
        if not self.backend:
            return False
        return await self.backend.health_check()


class ConnectionManager:
    """High-level connection manager (backend-agnostic)."""

    def __init__(
        self,
        database_url: str,
        backend_type: str = "sqlalchemy",
        pool_size: int = 20,
        max_overflow: int = 10,
        pool_timeout: int = 30,
        pool_recycle: int = 3600,
        echo: bool = False,
    ) -> None:
        """Initialize connection manager.

        Args:
            database_url: Database connection URL
            backend_type: Backend type (e.g., 'sqlalchemy')
            pool_size: Connection pool size
            max_overflow: Max overflow connections
            pool_timeout: Pool timeout in seconds
            pool_recycle: Pool recycle interval in seconds
            echo: Enable SQL echo logging

        """
        self.database_url = database_url
        self.backend_type = backend_type
        self.pool_config = PoolConfig(
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            echo=echo,
        )
        self.backend: DatabaseBackend | None = None

    async def initialize(self) -> None:
        """Initialize database backend."""
        self.backend = BackendFactory.create(
            self.backend_type,
            self.database_url,
            self.pool_config,
        )
        await self.backend.initialize()

    async def shutdown(self) -> None:
        """Shutdown database backend."""
        if self.backend:
            await self.backend.shutdown()
            self.backend = None

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[Any, None]:
        """Get database session.

        Yields:
            Session: Database session

        """
        if not self.backend:
            raise RuntimeError("ConnectionManager not initialized.")

        async with self.backend.get_session() as session:
            yield session

    async def health_check(self) -> bool:
        """Check database health.

        Returns:
            bool: True if healthy

        """
        if not self.backend:
            return False
        return await self.backend.health_check()
