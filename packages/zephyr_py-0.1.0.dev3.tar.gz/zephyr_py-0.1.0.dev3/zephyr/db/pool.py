"""Connection pool configuration and utilities.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PoolConfig:
    """Connection pool configuration."""

    pool_size: int = 20
    """Number of connections to keep in pool"""

    max_overflow: int = 10
    """Maximum overflow connections beyond pool_size"""

    pool_timeout: int = 30
    """Timeout in seconds for getting connection from pool"""

    pool_recycle: int = 3600
    """Recycle connections after this many seconds"""

    echo: bool = False
    """Enable SQL echo logging"""

    def validate(self) -> None:
        """Validate configuration values.

        Raises:
            ValueError: If any configuration is invalid

        """
        if self.pool_size < 1:
            raise ValueError("pool_size must be >= 1")

        if self.max_overflow < 0:
            raise ValueError("max_overflow must be >= 0")

        if self.pool_timeout <= 0:
            raise ValueError("pool_timeout must be > 0")

        if self.pool_recycle <= 0:
            raise ValueError("pool_recycle must be > 0")
