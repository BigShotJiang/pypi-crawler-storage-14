"""Query builder for type-safe database queries.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from typing import Any, Generic, TypeVar

from sqlalchemy import and_, select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import Select

from zephyr.db.base import BaseModel

T = TypeVar("T", bound=BaseModel)


class QueryBuilder(Generic[T]):
    """Type-safe query builder for database queries."""

    def __init__(
        self,
        model: type[T],
        session: AsyncSession | None = None,
    ) -> None:
        """Initialize query builder.

        Args:
            model: SQLAlchemy model class
            session: Async database session (optional)

        """
        self.model = model
        self.session = session
        self._stmt: Select = select(model)
        self._filters: list[Any] = []
        self._order_by_clauses: list[Any] = []
        self._joins: list[Any] = []
        self._limit_val: int | None = None
        self._offset_val: int | None = None
        self._distinct_val: bool = False
        self._group_by_clauses: list[Any] = []

    def filter(self, *conditions: Any) -> QueryBuilder[T]:
        """Add filter conditions.

        Args:
            *conditions: SQLAlchemy filter conditions

        Returns:
            QueryBuilder: Self for chaining

        """
        self._filters.extend(conditions)
        return self

    def filter_by(self, **kwargs: Any) -> QueryBuilder[T]:
        """Filter by column values.

        Args:
            **kwargs: Column=value pairs

        Returns:
            QueryBuilder: Self for chaining

        """
        for key, value in kwargs.items():
            if not hasattr(self.model, key):
                raise AttributeError(f"Model {self.model.__name__} has no column {key}")
            self._filters.append(getattr(self.model, key) == value)
        return self

    def order_by(self, *columns: Any) -> QueryBuilder[T]:
        """Order results.

        Args:
            *columns: Column expressions to order by

        Returns:
            QueryBuilder: Self for chaining

        """
        self._order_by_clauses.extend(columns)
        return self

    def limit(self, limit: int) -> QueryBuilder[T]:
        """Limit number of results.

        Args:
            limit: Maximum number of results

        Returns:
            QueryBuilder: Self for chaining

        Raises:
            ValueError: If limit is negative

        """
        if limit < 0:
            raise ValueError("Limit cannot be negative")
        self._limit_val = limit
        return self

    def offset(self, offset: int) -> QueryBuilder[T]:
        """Offset results.

        Args:
            offset: Number of results to skip

        Returns:
            QueryBuilder: Self for chaining

        Raises:
            ValueError: If offset is negative

        """
        if offset < 0:
            raise ValueError("Offset cannot be negative")
        self._offset_val = offset
        return self

    def join(self, *targets: Any) -> QueryBuilder[T]:
        """Join related tables.

        Args:
            *targets: Tables or relationships to join

        Returns:
            QueryBuilder: Self for chaining

        """
        self._joins.extend(targets)
        return self

    def distinct(self) -> QueryBuilder[T]:
        """Make results distinct.

        Returns:
            QueryBuilder: Self for chaining

        """
        self._distinct_val = True
        return self

    def group_by(self, *columns: Any) -> QueryBuilder[T]:
        """Group results by columns.

        Args:
            *columns: Column expressions to group by

        Returns:
            QueryBuilder: Self for chaining

        """
        self._group_by_clauses.extend(columns)
        return self

    async def all(self) -> list[T]:
        """Get all results.

        Returns:
            list[T]: List of results

        Raises:
            RuntimeError: If no session available

        """
        if not self.session:
            raise RuntimeError("Session required for query execution")

        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def first(self) -> T | None:
        """Get first result.

        Returns:
            T | None: First result or None

        Raises:
            RuntimeError: If no session available

        """
        if not self.session:
            raise RuntimeError("Session required for query execution")

        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        return result.scalars().first()

    async def one(self) -> T:
        """Get exactly one result.

        Returns:
            T: Single result

        Raises:
            RuntimeError: If no session available
            sqlalchemy.exc.NoResultFound: If no results
            sqlalchemy.exc.MultipleResultsFound: If multiple results

        """
        if not self.session:
            raise RuntimeError("Session required for query execution")

        stmt = self._build_stmt()
        result = await self.session.execute(stmt)
        return result.scalars().one()

    async def count(self) -> int:
        """Count total results.

        Returns:
            int: Number of results

        Raises:
            RuntimeError: If no session available

        """
        if not self.session:
            raise RuntimeError("Session required for query execution")

        # Count query should not have limit/offset
        count_stmt = select(func.count()).select_from(self.model)

        if self._filters:
            count_stmt = count_stmt.where(and_(*self._filters))

        result = await self.session.execute(count_stmt)
        return result.scalar() or 0

    def _build_stmt(self) -> Select:
        """Build SQLAlchemy statement from builder.

        Returns:
            Select: SQLAlchemy select statement

        """
        stmt = select(self.model)

        # Apply joins
        for join_target in self._joins:
            stmt = stmt.join(join_target)

        # Apply filters
        if self._filters:
            stmt = stmt.where(and_(*self._filters))

        # Apply group by
        if self._group_by_clauses:
            stmt = stmt.group_by(*self._group_by_clauses)

        # Apply distinct
        if self._distinct_val:
            stmt = stmt.distinct()

        # Apply order by
        if self._order_by_clauses:
            stmt = stmt.order_by(*self._order_by_clauses)

        # Apply limit
        if self._limit_val is not None:
            stmt = stmt.limit(self._limit_val)

        # Apply offset
        if self._offset_val is not None:
            stmt = stmt.offset(self._offset_val)

        return stmt
