"""Database configuration.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """Database configuration settings."""

    # Connection
    database_url: str = Field(
        default="sqlite+aiosqlite:///./db.sqlite",
        description="Database connection URL",
    )

    # Pool configuration
    pool_size: int = Field(default=20, description="Connection pool size")
    max_overflow: int = Field(default=10, description="Max overflow connections")
    pool_timeout: int = Field(default=30, description="Pool timeout seconds")
    pool_recycle: int = Field(default=3600, description="Pool recycle seconds")

    # Echo and logging
    echo: bool = Field(default=False, description="Log SQL statements")

    # Backend
    backend_type: str = Field(default="sqlalchemy", description="ORM backend type")

    class Config:
        """Pydantic config."""

        env_prefix = "DB_"
        env_file = ".env"
        case_sensitive = False

    def validate_url(self) -> None:
        """Validate database URL format.

        Raises:
            ValueError: If URL is invalid

        """
        if not self.database_url or "://" not in self.database_url:
            raise ValueError("Invalid database_url format")

    def validate_pool_settings(self) -> None:
        """Validate pool settings.

        Raises:
            ValueError: If settings are invalid

        """
        if self.pool_size < 1:
            raise ValueError("pool_size must be >= 1")
        if self.max_overflow < 0:
            raise ValueError("max_overflow must be >= 0")
        if self.pool_timeout <= 0:
            raise ValueError("pool_timeout must be > 0")
        if self.pool_recycle <= 0:
            raise ValueError("pool_recycle must be > 0")
