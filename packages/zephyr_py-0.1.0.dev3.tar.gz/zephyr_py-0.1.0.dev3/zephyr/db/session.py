"""Session management.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from typing import Any
from collections.abc import AsyncGenerator

from zephyr.db.backends.base import DatabaseBackend
from zephyr.db.backends.factory import BackendFactory
from zephyr.db.pool import PoolConfig


class Session(ABC):
    """Abstract session interface."""

    @abstractmethod
    async def execute(self, query: Any) -> Any:
        """Execute query."""

    @abstractmethod
    async def commit(self) -> None:
        """Commit transaction."""

    @abstractmethod
    async def rollback(self) -> None:
        """Rollback transaction."""

    @abstractmethod
    async def close(self) -> None:
        """Close session."""


class SessionManager:
    """Manages database sessions."""

    def __init__(
        self,
        database_url: str,
        backend_type: str = "sqlalchemy",
        pool_config: PoolConfig | None = None,
        echo: bool = False,
    ) -> None:
        """Initialize session manager.

        Args:
            database_url: Database connection URL
            backend_type: Database backend type
            pool_config: Connection pool configuration
            echo: Enable SQL echo logging

        """
        self.database_url = database_url
        self.backend_type = backend_type
        self.pool_config = pool_config or PoolConfig()
        self.echo = echo
        self.backend: DatabaseBackend | None = None
        self.engine: Any = None
        self.session_factory: Any = None

    async def initialize(self) -> None:
        """Initialize database backend.

        Raises:
            RuntimeError: If initialization fails

        """
        self.backend = BackendFactory.create(
            self.backend_type,
            self.database_url,
            self.pool_config,
            self.echo,
        )
        await self.backend.initialize()

    async def shutdown(self) -> None:
        """Shutdown database backend."""
        if self.backend:
            await self.backend.shutdown()
            self.backend = None

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[Any, None]:
        """Get database session.

        Yields:
            Session: Database session

        Raises:
            RuntimeError: If manager not initialized

        """
        if not self.backend:
            raise RuntimeError("SessionManager not initialized. Call initialize() first.")

        async with self.backend.get_session() as session:
            yield session

    async def health_check(self) -> bool:
        """Check database health.

        Returns:
            bool: True if database is healthy

        """
        if not self.backend:
            return False
        return await self.backend.health_check()
