"""Base database model.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from datetime import datetime, UTC
from typing import ClassVar

from sqlalchemy import Column, DateTime
from sqlalchemy.orm import declarative_base

# Create declarative base for models
Base = declarative_base()


class BaseModel(Base):
    """Base model for all database entities.

    Provides common timestamps and utility methods.
    """

    __abstract__ = True
    __allow_unmapped__ = True

    created_at: ClassVar[datetime] = Column(
        DateTime,
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    """Timestamp when record was created"""

    updated_at: ClassVar[datetime] = Column(
        DateTime,
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )
    """Timestamp when record was last updated"""

    def to_dict(self) -> dict:
        """Convert model to dictionary.

        Returns:
            dict: Model data as dictionary

        Note:
            This is a basic implementation. Subclasses should override
            for custom serialization logic.

        """
        result = {}
        for key, value in self.__dict__.items():
            if not key.startswith("_"):
                if isinstance(value, datetime):
                    result[key] = value.isoformat()
                else:
                    result[key] = value
        return result

    @classmethod
    def from_dict(cls, data: dict) -> BaseModel:
        """Create model instance from dictionary.

        Args:
            data: Dictionary with model data

        Returns:
            BaseModel: New model instance

        Note:
            This is a basic implementation. Subclasses should override
            for custom deserialization logic.

        """
        return cls(**data)
