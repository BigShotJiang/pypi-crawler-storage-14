"""Database backends - abstraction layer.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from zephyr.db.backends.base import DatabaseBackend
from zephyr.db.backends.factory import BackendFactory

__all__ = [
    "BackendFactory",
    "DatabaseBackend",
]
