"""SQLAlchemy database backend implementation.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from zephyr.db.backends.base import DatabaseBackend
from zephyr.db.exceptions import ConnectionError as DBConnectionError
from zephyr.db.pool import PoolConfig


class SQLAlchemyBackend(DatabaseBackend):
    """SQLAlchemy database backend implementation."""

    def __init__(
        self,
        database_url: str,
        pool_config: PoolConfig | None = None,
        echo: bool = False,
    ) -> None:
        """Initialize SQLAlchemy backend.

        Args:
            database_url: Database connection URL
            pool_config: Connection pool configuration
            echo: Enable SQL echo logging

        Raises:
            ValueError: If database_url is invalid

        """
        if not database_url:
            raise ValueError("database_url cannot be empty")

        self.database_url = database_url
        self.pool_config = pool_config or PoolConfig()
        self.echo = echo
        self.engine: AsyncEngine | None = None
        self.session_factory: sessionmaker | None = None

    async def initialize(self) -> None:
        """Initialize database connection and session factory."""
        try:
            # Build engine kwargs - avoid pool settings for SQLite
            engine_kwargs = {
                "echo": self.echo,
                "connect_args": {"check_same_thread": False},
            }

            # Only add pool settings for non-SQLite databases
            if "sqlite" not in self.database_url.lower():
                engine_kwargs.update(
                    {
                        "pool_size": self.pool_config.pool_size,
                        "max_overflow": self.pool_config.max_overflow,
                        "pool_timeout": self.pool_config.pool_timeout,
                        "pool_recycle": self.pool_config.pool_recycle,
                    }
                )

            self.engine = create_async_engine(
                self.database_url,
                **engine_kwargs,
            )

            self.session_factory = sessionmaker(
                self.engine,
                class_=AsyncSession,
                expire_on_commit=False,
            )
        except Exception as e:
            raise DBConnectionError(f"Failed to initialize database: {e!s}")

    async def shutdown(self) -> None:
        """Shutdown database engine and dispose of connections."""
        if self.engine:
            await self.engine.dispose()
            self.engine = None
            self.session_factory = None

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get database session context manager.

        Yields:
            AsyncSession: Database session

        Raises:
            RuntimeError: If database not initialized

        """
        if not self.session_factory:
            raise RuntimeError("Database not initialized. Call initialize() first.")

        async with self.session_factory() as session:
            try:
                yield session
            finally:
                await session.close()

    async def health_check(self) -> bool:
        """Check database connectivity.

        Returns:
            True if database is healthy, False otherwise

        """
        if not self.engine:
            return False

        try:
            async with self.get_session() as session:
                await session.execute("SELECT 1")
                return True
        except Exception:
            return False
