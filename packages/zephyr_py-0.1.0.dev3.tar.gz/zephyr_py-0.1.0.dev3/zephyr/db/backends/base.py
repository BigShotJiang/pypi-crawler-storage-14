"""Database backend abstraction interface.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from typing import Any
from collections.abc import AsyncGenerator


class DatabaseBackend(ABC):
    """Abstract base class for database backends."""

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize database connection."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Shutdown database connection."""

    @abstractmethod
    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[Any, None]:
        """Get database session context manager."""

    @abstractmethod
    async def health_check(self) -> bool:
        """Check database health."""
