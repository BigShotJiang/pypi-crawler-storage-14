"""Database backend factory.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations


from zephyr.db.backends.base import DatabaseBackend
from zephyr.db.backends.sqlalchemy_backend import SQLAlchemyBackend
from zephyr.db.exceptions import DatabaseError
from zephyr.db.pool import PoolConfig


class BackendFactory:
    """Factory for creating database backends."""

    _backends: dict[str, type[DatabaseBackend]] = {
        "sqlalchemy": SQLAlchemyBackend,
    }

    @classmethod
    def create(
        cls,
        backend_type: str,
        database_url: str,
        pool_config: PoolConfig | None = None,
        echo: bool = False,
    ) -> DatabaseBackend:
        """Create database backend instance.

        Args:
            backend_type: Backend type name (e.g., 'sqlalchemy')
            database_url: Database connection URL
            pool_config: Connection pool configuration
            echo: Enable SQL echo logging

        Returns:
            DatabaseBackend: Backend instance

        Raises:
            DatabaseError: If backend type is not supported

        """
        if backend_type not in cls._backends:
            supported = ", ".join(cls._backends.keys())
            raise DatabaseError(f"Unknown backend: {backend_type}. Supported backends: {supported}")

        backend_class = cls._backends[backend_type]
        return backend_class(database_url, pool_config, echo)

    @classmethod
    def register(cls, backend_type: str, backend_class: type[DatabaseBackend]) -> None:
        """Register custom backend.

        Args:
            backend_type: Backend type name
            backend_class: Backend class

        Raises:
            ValueError: If backend_type already registered

        """
        if backend_type in cls._backends:
            raise ValueError(f"Backend '{backend_type}' already registered")

        if not issubclass(backend_class, DatabaseBackend):
            raise ValueError("Backend class must inherit from DatabaseBackend")

        cls._backends[backend_type] = backend_class

    @classmethod
    def get_supported_backends(cls) -> list[str]:
        """Get list of supported backends.

        Returns:
            list[str]: List of backend type names

        """
        return list(cls._backends.keys())

    @classmethod
    def unregister(cls, backend_type: str) -> None:
        """Unregister backend.

        Args:
            backend_type: Backend type name

        Raises:
            ValueError: If backend is built-in (cannot unregister)

        """
        if backend_type == "sqlalchemy":
            raise ValueError("Cannot unregister built-in backends")

        if backend_type in cls._backends:
            del cls._backends[backend_type]
