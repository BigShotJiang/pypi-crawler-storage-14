"""Relationship management with lazy/eager loading and cascades (ORM best practices).

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class LazyLoadStrategy(str, Enum):
    """Lazy loading strategies for relationships."""

    LAZY = "select"
    """Load on access (deferred loading)"""

    EAGER = "joined"
    """Load immediately with JOIN"""

    SUBQUERY = "subquery"
    """Load with subquery"""


class CascadeStrategy(str, Enum):
    """Cascade strategies for relationship operations."""

    SAVE_UPDATE = "save-update"
    """Cascade saves and updates"""

    DELETE = "delete"
    """Cascade deletes"""

    ALL = "all"
    """All cascade operations"""


@dataclass
class RelationshipConfig:
    """Configuration for relationship handling."""

    lazy_strategy: LazyLoadStrategy = LazyLoadStrategy.LAZY
    """How to load related objects"""

    cascade_delete: bool = False
    """Whether to cascade delete"""

    cascade_save: bool = True
    """Whether to cascade save"""

    back_populates: str | None = None
    """Back reference name for bidirectional relationships"""

    foreign_keys: list[str] | None = None
    """Explicit foreign key columns"""

    uselist: bool = True
    """Whether relationship returns list (False for 1-1)"""

    def validate(self) -> None:
        """Validate configuration.

        Raises:
            ValueError: If configuration is invalid

        """
        if not isinstance(self.lazy_strategy, LazyLoadStrategy):
            raise ValueError("Invalid lazy_strategy")

        if self.uselist is False and self.cascade_delete is True:
            raise ValueError("Cannot cascade delete on 1-1 relationships without care")


class RelationshipManager:
    """Manages relationship configurations and strategies."""

    def get_load_strategy(self, strategy: LazyLoadStrategy) -> str:
        """Get SQLAlchemy load strategy string.

        Args:
            strategy: LazyLoadStrategy enum value

        Returns:
            str: SQLAlchemy load strategy

        """
        return strategy.value

    def configure_cascade(self, strategy: CascadeStrategy) -> str:
        """Configure cascade options.

        Args:
            strategy: CascadeStrategy enum value

        Returns:
            str: Cascade configuration string

        Note:
            Returns proper SQLAlchemy cascade syntax

        """
        if strategy == CascadeStrategy.SAVE_UPDATE:
            return "save-update, merge"
        if strategy == CascadeStrategy.DELETE:
            return "delete"
        if strategy == CascadeStrategy.ALL:
            return "all, delete-orphan"
        return "save-update, merge"

    @staticmethod
    def create_config(
        lazy: LazyLoadStrategy = LazyLoadStrategy.LAZY,
        cascade_delete: bool = False,
        cascade_save: bool = True,
        one_to_one: bool = False,
    ) -> RelationshipConfig:
        """Create relationship configuration.

        Args:
            lazy: Lazy loading strategy
            cascade_delete: Enable cascade delete
            cascade_save: Enable cascade save
            one_to_one: Whether this is 1-1 relationship

        Returns:
            RelationshipConfig: Configuration object

        """
        config = RelationshipConfig(
            lazy_strategy=lazy,
            cascade_delete=cascade_delete,
            cascade_save=cascade_save,
            uselist=not one_to_one,
        )
        config.validate()
        return config

    @staticmethod
    def define_one_to_many(
        foreign_key_column: str,
        back_reference: str | None = None,
        lazy: LazyLoadStrategy = LazyLoadStrategy.LAZY,
    ) -> dict:
        """Helper to define 1-N relationship.

        Args:
            foreign_key_column: Column name with FK
            back_reference: Back reference name
            lazy: Loading strategy

        Returns:
            dict: Relationship kwargs for SQLAlchemy

        """
        return {
            "lazy": lazy.value,
            "back_populates": back_reference,
        }

    @staticmethod
    def define_many_to_many(
        association_table: Any,
        back_reference: str | None = None,
        lazy: LazyLoadStrategy = LazyLoadStrategy.LAZY,
    ) -> dict:
        """Helper to define N-N relationship.

        Args:
            association_table: Association table
            back_reference: Back reference name
            lazy: Loading strategy

        Returns:
            dict: Relationship kwargs for SQLAlchemy

        """
        return {
            "secondary": association_table,
            "lazy": lazy.value,
            "back_populates": back_reference,
        }

    @staticmethod
    def define_one_to_one(
        foreign_key_column: str,
        back_reference: str | None = None,
        lazy: LazyLoadStrategy = LazyLoadStrategy.LAZY,
    ) -> dict:
        """Helper to define 1-1 relationship.

        Args:
            foreign_key_column: Column name with FK
            back_reference: Back reference name
            lazy: Loading strategy

        Returns:
            dict: Relationship kwargs for SQLAlchemy

        """
        return {
            "uselist": False,
            "lazy": lazy.value,
            "back_populates": back_reference,
        }
