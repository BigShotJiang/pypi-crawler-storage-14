"""Database health checks.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from datetime import datetime, UTC
from enum import Enum
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession


class HealthStatus(str, Enum):
    """Health status enumeration."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class HealthChecker:
    """Database health checking."""

    def __init__(self, session: AsyncSession) -> None:
        """Initialize health checker.

        Args:
            session: Async database session

        """
        self.session = session

    async def check_connection(self) -> dict[str, Any]:
        """Check database connection.

        Returns:
            dict: Connection health status

        """
        try:
            await self.session.execute("SELECT 1")
            return {
                "status": HealthStatus.HEALTHY.value,
                "component": "connection",
                "timestamp": datetime.now(UTC).isoformat(),
            }
        except Exception as e:
            return {
                "status": HealthStatus.UNHEALTHY.value,
                "component": "connection",
                "error": str(e),
                "timestamp": datetime.now(UTC).isoformat(),
            }

    async def check_transaction(self) -> dict[str, Any]:
        """Check transaction capability.

        Returns:
            dict: Transaction health status

        """
        try:
            async with self.session.begin():
                await self.session.execute("SELECT 1")
            return {
                "status": HealthStatus.HEALTHY.value,
                "component": "transaction",
                "timestamp": datetime.now(UTC).isoformat(),
            }
        except Exception as e:
            return {
                "status": HealthStatus.UNHEALTHY.value,
                "component": "transaction",
                "error": str(e),
                "timestamp": datetime.now(UTC).isoformat(),
            }

    async def full_check(self) -> dict[str, Any]:
        """Perform full health check.

        Returns:
            dict: Comprehensive health status

        """
        checks = {
            "connection": await self.check_connection(),
            "transaction": await self.check_transaction(),
        }

        # Determine overall status
        statuses = [check["status"] for check in checks.values()]
        if HealthStatus.UNHEALTHY.value in statuses:
            overall_status = HealthStatus.UNHEALTHY.value
        elif HealthStatus.DEGRADED.value in statuses:
            overall_status = HealthStatus.DEGRADED.value
        else:
            overall_status = HealthStatus.HEALTHY.value

        return {
            "status": overall_status,
            "checks": checks,
            "timestamp": datetime.now(UTC).isoformat(),
        }
