"""Transaction management for ACID compliance.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession


class TransactionManager:
    """Manages database transactions with ACID compliance."""

    def __init__(self, session: AsyncSession) -> None:
        """Initialize transaction manager.

        Args:
            session: Async database session

        """
        self.session = session

    @asynccontextmanager
    async def begin(self) -> AsyncGenerator[AsyncSession, None]:
        """Begin a transaction context.

        Yields:
            AsyncSession: Database session

        Raises:
            Exception: Any database errors are raised

        """
        try:
            async with self.session.begin():
                yield self.session
        except Exception:
            # Rollback happens automatically with context manager
            raise

    async def commit(self) -> None:
        """Commit current transaction.

        Raises:
            RuntimeError: If no active transaction

        """
        await self.session.commit()

    async def rollback(self) -> None:
        """Rollback current transaction."""
        await self.session.rollback()

    @asynccontextmanager
    async def savepoint(self, name: str | None = None) -> AsyncGenerator[AsyncSession, None]:
        """Create a savepoint for nested transactions.

        Args:
            name: Optional savepoint name

        Yields:
            AsyncSession: Database session

        """
        savepoint_obj = None
        try:
            if name:
                savepoint_obj = await self.session.begin_nested()
            else:
                savepoint_obj = await self.session.begin_nested()

            yield self.session

            if savepoint_obj:
                await self.session.commit()
        except Exception:
            if savepoint_obj:
                await self.session.rollback()
            raise

    async def is_active(self) -> bool:
        """Check if transaction is active.

        Returns:
            bool: True if transaction is active

        """
        return self.session.in_transaction()
