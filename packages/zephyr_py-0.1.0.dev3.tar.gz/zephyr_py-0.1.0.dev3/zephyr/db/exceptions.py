"""Database exceptions.

Author: AM
Created At: 21 Nov 2025
"""

from __future__ import annotations


class DatabaseError(Exception):
    """Base exception for all database errors."""


class ConnectionError(DatabaseError):
    """Database connection failed."""


class QueryError(DatabaseError):
    """Query execution failed."""


class IntegrityError(DatabaseError):
    """Data integrity constraint violation."""


class NotFoundError(DatabaseError):
    """Record not found."""
