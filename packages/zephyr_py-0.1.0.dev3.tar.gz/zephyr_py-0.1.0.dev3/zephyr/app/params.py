"""Parameter utilities for Zephyr dependency injection.

This module provides parameter extraction utilities for form data, query parameters,
and other request components used in dependency injection.
"""

from __future__ import annotations

from typing import Any


class FormField:
    """Marker class for form field parameters in dependency injection."""

    def __init__(
        self,
        default: Any = ...,
        *,
        pattern: str | None = None,
        min_length: int | None = None,
        max_length: int | None = None,
    ) -> None:
        """Initialize form field marker.

        Args:
            default: Default value if field is not provided
            pattern: Regex pattern for validation
            min_length: Minimum string length
            max_length: Maximum string length

        """
        self.default = default
        self.pattern = pattern
        self.min_length = min_length
        self.max_length = max_length


def Form(
    default: Any = ...,
    *,
    pattern: str | None = None,
    min_length: int | None = None,
    max_length: int | None = None,
) -> Any:
    """Mark a parameter as a form field for dependency injection.

    This function is used to indicate that a parameter should be extracted
    from form data in the request body.

    Args:
        default: Default value if field is not provided
        pattern: Regex pattern for validation
        min_length: Minimum string length
        max_length: Maximum string length

    Returns:
        FormField marker instance

    Example:
        ```python
        from zephyr import Zephyr
        from zephyr.app.params import Form

        app = Zephyr()

        @app.post("/login")
        async def login(
            username: str = Form(...),
            password: str = Form(...),
        ):
            return {"username": username}
        ```

    """
    return FormField(default=default, pattern=pattern, min_length=min_length, max_length=max_length)


__all__ = ["Form", "FormField"]
