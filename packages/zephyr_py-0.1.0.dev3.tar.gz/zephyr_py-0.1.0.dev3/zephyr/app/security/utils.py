"""Security utilities for the Zephyr framework.

Author: A M (am@bbdevs.com)

Created At: 19 Nov 2025
"""


def get_authorization_scheme_param(
    authorization_header_value: str | None,
) -> tuple[str, str]:
    if not authorization_header_value:
        return "", ""
    scheme, _, param = authorization_header_value.partition(" ")
    return scheme, param
