"""Base security scheme class for Zephyr applications."""

from __future__ import annotations

from zephyr.app.openapi.models import SecurityBaseModel


class SecurityBase:
    """Base class for all security schemes in Zephyr.

    All security authentication schemes (HTTP, API Key, OAuth2, etc.)
    inherit from this base class.
    """

    model: SecurityBaseModel
    scheme_name: str
