"""OpenAPI 3.1.0 schema generation for Zephyr applications.

This module generates OpenAPI schemas from Zephyr route definitions,
extracting metadata like paths, methods, parameters, and documentation.
"""

from __future__ import annotations

import inspect
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from zephyr.app.convertors import Convertor
    from zephyr.app.routing import Route, Router, WebSocketRoute

# Type alias for model types
Model = type[Any] | Any


def get_openapi_schema(
    router: Router,
    title: str = "Zephyr API",
    version: str = "1.0.0",
    description: str | None = None,
) -> dict[str, str]:
    """Generate an OpenAPI 3.1.0 schema from a Zephyr router.

    Args:
        router: The Zephyr Router instance containing the routes
        title: API title for the schema
        version: API version
        description: Optional API description

    Returns:
        A dictionary representing the complete OpenAPI 3.1.0 schema

    """
    from zephyr.app.routing import Route, WebSocketRoute

    paths: dict[str, dict[str, str]] = {}

    for route in router.routes:
        if isinstance(route, Route):
            _process_http_route(route, paths)
        elif isinstance(route, WebSocketRoute):
            _process_websocket_route(route, paths)

    schema: dict[str, str] = {
        "openapi": "3.1.0",
        "info": {
            "title": title,
            "version": version,
        },
        "paths": paths,
    }

    if description:
        schema["info"]["description"] = description

    return schema


def _process_http_route(route: Route, paths: dict[str, dict[str, str]]) -> None:
    """Process an HTTP route and add it to the paths dictionary.

    Args:
        route: The HTTP Route to process
        paths: The paths dictionary to update

    """
    path = route.path_format
    if path not in paths:
        paths[path] = {}

    # Get endpoint docstring
    docstring = _get_endpoint_docstring(route.endpoint)
    operation_id = route.unique_id

    # Extract parameters from path
    parameters = _extract_path_parameters(route)

    # Build operation for each method
    for method in route.methods:
        operation: dict[str, str] = {
            "operationId": operation_id,
            "summary": _get_first_line_of_docstring(docstring),
        }

        if docstring:
            operation["description"] = docstring

        if parameters:
            operation["parameters"] = parameters

        # Add response schema
        operation["responses"] = _build_response_schema(route)

        # Add request body if applicable
        if method.upper() in ("POST", "PUT", "PATCH") and route.response_model:
            operation["requestBody"] = _build_request_body_schema(route)

        # Add tags if available
        tags = _extract_tags_from_path(path)
        if tags:
            operation["tags"] = tags

        paths[path][method.lower()] = operation


def _process_websocket_route(route: WebSocketRoute, paths: dict[str, dict[str, str]]) -> None:
    """Process a WebSocket route and add it to the paths dictionary.

    Args:
        route: The WebSocket Route to process
        paths: The paths dictionary to update

    """
    path = route.path_format
    if path not in paths:
        paths[path] = {}

    docstring = _get_endpoint_docstring(route.endpoint)
    parameters = _extract_path_parameters_from_convertors(route.param_convertors)

    operation: dict[str, str] = {
        "operationId": route.name,
        "summary": _get_first_line_of_docstring(docstring),
    }

    if docstring:
        operation["description"] = docstring

    if parameters:
        operation["parameters"] = parameters

    operation["responses"] = {"101": {"description": "WebSocket connection established"}}

    tags = _extract_tags_from_path(path)
    if tags:
        operation["tags"] = tags

    paths[path]["get"] = operation


def _get_endpoint_docstring(endpoint: Callable) -> str | None:
    """Extract and clean the docstring from an endpoint function.

    Args:
        endpoint: The endpoint function

    Returns:
        The cleaned docstring, or None if not available

    """
    doc = inspect.getdoc(endpoint)
    return doc if doc else None


def _get_first_line_of_docstring(docstring: str | None) -> str:
    """Get the first line of a docstring.

    Args:
        docstring: The docstring to extract from

    Returns:
        The first line, or an empty string if no docstring

    """
    if not docstring:
        return ""
    lines = docstring.split("\n")
    return lines[0].strip() if lines else ""


def _extract_path_parameters(route: Route) -> list[dict[str, str]]:
    """Extract path parameters from a route.

    Args:
        route: The Route to extract parameters from

    Returns:
        A list of OpenAPI parameter objects

    """
    return _extract_path_parameters_from_convertors(route.param_convertors)


def _extract_path_parameters_from_convertors(
    param_convertors: dict[str, Convertor],
) -> list[dict[str, str]]:
    """Extract path parameters from param convertors.

    Args:
        param_convertors: Dict of parameter convertor objects

    Returns:
        A list of OpenAPI parameter objects

    """
    parameters: list[dict[str, str]] = []

    for param_name, convertor in param_convertors.items():
        param_type = _convertor_to_openapi_type(convertor)
        parameter: dict[str, str] = {
            "name": param_name,
            "in": "path",
            "required": True,
            "schema": {"type": param_type},
        }
        parameters.append(parameter)

    return parameters


def _convertor_to_openapi_type(convertor: Convertor) -> str:
    """Convert a Zephyr convertor to an OpenAPI type.

    Args:
        convertor: The convertor object

    Returns:
        An OpenAPI type string

    """
    convertor_type = type(convertor).__name__
    type_mapping = {
        "StringConvertor": "string",
        "IntConvertor": "integer",
        "FloatConvertor": "number",
        "PathConvertor": "string",
        "UUIDConvertor": "string",
    }
    return type_mapping.get(convertor_type, "string")


def _extract_tags_from_path(path: str) -> list[str]:
    """Extract tags from a path for OpenAPI grouping.

    Args:
        path: The path string

    Returns:
        A list of tag strings

    """
    if not path or path == "/":
        return []

    # Get first segment after / as tag
    segments = path.strip("/").split("/")
    if segments and segments[0]:
        return [segments[0]]
    return []


def _build_request_body_schema(route: Route) -> dict[str, str]:
    """Build a request body schema for a route.

    Args:
        route: The Route to extract request body from

    Returns:
        An OpenAPI request body object

    """
    return {
        "required": True,
        "content": {"application/json": {"schema": _get_model_schema(route.response_model)}},
    }


def _build_response_schema(route: Route) -> dict[str, dict[str, str]]:
    """Build response schemas for a route.

    Args:
        route: The Route to extract responses from

    Returns:
        An OpenAPI responses object

    """
    responses: dict[str, dict[str, str]] = {}

    # Add main response
    status_code = route.status_code or 200
    response_schema: dict[str, str] = {"description": "Successful response"}

    if route.response_model:
        response_schema["content"] = {"application/json": {"schema": _get_model_schema(route.response_model)}}

    responses[str(status_code)] = response_schema

    # Add additional responses
    if route.responses:
        for status, response_info in route.responses.items():
            responses[str(status)] = {"description": response_info.get("description", "Additional response")}

    # Add default error responses
    if "400" not in responses:
        responses["400"] = {"description": "Bad request"}
    if "404" not in responses:
        responses["404"] = {"description": "Not found"}
    if "500" not in responses:
        responses["500"] = {"description": "Internal server error"}

    return responses


def _get_model_schema(model: Model) -> dict[str, str]:
    """Get OpenAPI schema for a response model.

    Args:
        model: The model class or type

    Returns:
        An OpenAPI schema object

    """
    # For now, return a basic schema. Can be enhanced with Pydantic integration
    if model is None:
        return {"type": "object"}

    model_name = getattr(model, "__name__", str(model))

    # Try to detect if it's a dict-like type
    if hasattr(model, "__origin__"):
        origin = getattr(model, "__origin__", None)
        if origin is dict:
            return {"type": "object"}
        if origin is list:
            return {"type": "array", "items": {"type": "object"}}

    # Default schema
    return {
        "type": "object",
        "title": model_name,
    }
