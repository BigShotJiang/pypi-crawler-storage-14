"""OpenAPI security scheme models for Zephyr applications.

This module provides Pydantic models for OpenAPI 3.1.0 security schemes,
enabling native security documentation without external framework dependencies.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class SecurityBaseModel(BaseModel):
    """Base model for all OpenAPI security schemes."""

    type: str = Field(..., description="Security scheme type")
    description: str | None = Field(None, description="Security scheme description")


class APIKeyIn(str, Enum):
    """Location of the API key in the request."""

    query = "query"
    header = "header"
    cookie = "cookie"


class APIKeyModel(SecurityBaseModel):
    """OpenAPI API Key security scheme model."""

    type: str = Field(default="apiKey", description="Security scheme type")
    name: str = Field(..., description="Name of the header, query parameter, or cookie")
    in_: APIKeyIn = Field(..., alias="in", description="Location of the API key")


class HTTPBaseModel(SecurityBaseModel):
    """OpenAPI HTTP authentication security scheme model."""

    type: str = Field(default="http", description="Security scheme type")
    scheme: str = Field(..., description="HTTP authorization scheme (e.g., basic, bearer, digest)")


class HTTPBearerModel(HTTPBaseModel):
    """OpenAPI HTTP Bearer token security scheme model."""

    scheme: str = Field(default="bearer", description="HTTP authorization scheme")
    bearerFormat: str | None = Field(None, description="Bearer token format hint (e.g., JWT)")


class OAuthFlowsModel(BaseModel):
    """OAuth 2.0 flows configuration for OpenAPI."""

    implicit: dict[str, object] | None = Field(None, description="OAuth2 implicit flow configuration")
    password: dict[str, object] | None = Field(None, description="OAuth2 password flow configuration")
    clientCredentials: dict[str, object] | None = Field(
        None, description="OAuth2 client credentials flow configuration"
    )
    authorizationCode: dict[str, object] | None = Field(
        None, description="OAuth2 authorization code flow configuration"
    )


class OAuth2Model(SecurityBaseModel):
    """OpenAPI OAuth 2.0 security scheme model."""

    type: str = Field(default="oauth2", description="Security scheme type")
    flows: OAuthFlowsModel = Field(..., description="OAuth2 flows configuration")


class OpenIdConnectModel(SecurityBaseModel):
    """OpenAPI OpenID Connect security scheme model."""

    type: str = Field(default="openIdConnect", description="Security scheme type")
    openIdConnectUrl: str = Field(..., description="OpenID Connect discovery URL")


__all__ = [
    "APIKeyIn",
    "APIKeyModel",
    "HTTPBaseModel",
    "HTTPBearerModel",
    "OAuth2Model",
    "OAuthFlowsModel",
    "OpenIdConnectModel",
    "SecurityBaseModel",
]
