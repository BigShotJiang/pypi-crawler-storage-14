"""CSRF Protection Middleware for Zephyr applications.

Implements Cross-Site Request Forgery (CSRF) protection using the double-submit
cookie pattern with secure token validation.
"""

from __future__ import annotations

import secrets
import urllib.parse
from typing import TYPE_CHECKING, Any

from zephyr.app.middleware.base import BaseMiddleware
from zephyr.core.logging import get_logger
from zephyr.exceptions import PermissionDenied

if TYPE_CHECKING:
    from zephyr._types import ASGIApp, Receive, Scope, Send

logger = get_logger(__name__)


class CSRFMiddleware(BaseMiddleware):
    """CSRF Protection middleware using double-submit cookie pattern.

    This middleware provides protection against Cross-Site Request Forgery attacks by:
    1. Generating secure CSRF tokens for each session
    2. Validating tokens on state-changing requests (POST, PUT, DELETE, PATCH)
    3. Enforcing secure cookie settings (Secure, HttpOnly, SameSite)
    4. Supporting both form data and header-based token submission

    Configuration (from settings):
        - CSRF_ENABLED: Enable/disable CSRF protection
        - CSRF_TRUSTED_ORIGINS: List of trusted origins to skip CSRF checks
        - CSRF_TOKEN_LENGTH: Length of generated tokens (default: 32)
        - CSRF_COOKIE_SECURE: Only send cookie over HTTPS
        - CSRF_COOKIE_HTTPONLY: Prevent JavaScript access to token
        - CSRF_COOKIE_SAMESITE: Cookie SameSite policy (Lax or Strict)
        - CSRF_COOKIE_NAME: Name of the CSRF token cookie
        - CSRF_HEADER_NAME: Name of the CSRF token header
        - CSRF_FORM_FIELD_NAME: Name of the CSRF form field
    """

    SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}

    def __init__(
        self,
        app: ASGIApp,
        *,
        settings: Any | None = None,
    ) -> None:
        """Initialize CSRF middleware.

        Args:
            app: The ASGI application to wrap
            settings: Optional settings object with CSRF configuration

        """
        super().__init__(app)
        self.settings = settings
        self.enabled = True
        self.token_length = 32
        self.trusted_origins: list[str] = []
        self.cookie_name = "csrf_token"
        self.header_name = "X-CSRF-Token"
        self.form_field_name = "_csrf_token"
        self.cookie_secure = True
        self.cookie_httponly = True
        self.cookie_samesite = "Lax"

        if settings:
            self.enabled = getattr(settings, "CSRF_ENABLED", True)
            self.token_length = getattr(settings, "CSRF_TOKEN_LENGTH", 32)
            self.trusted_origins = getattr(settings, "CSRF_TRUSTED_ORIGINS", [])
            self.cookie_name = getattr(settings, "CSRF_COOKIE_NAME", "csrf_token")
            self.header_name = getattr(settings, "CSRF_HEADER_NAME", "X-CSRF-Token")
            self.form_field_name = getattr(settings, "CSRF_FORM_FIELD_NAME", "_csrf_token")
            self.cookie_secure = getattr(settings, "CSRF_COOKIE_SECURE", True)
            self.cookie_httponly = getattr(settings, "CSRF_COOKIE_HTTPONLY", True)
            self.cookie_samesite = getattr(settings, "CSRF_COOKIE_SAMESITE", "Lax")

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """ASGI middleware entry point.

        Args:
            scope: ASGI connection scope
            receive: ASGI receive callable
            send: ASGI send callable

        """
        if not self._is_http_request(scope):
            await self.app(scope, receive, send)
            return

        if not self.enabled:
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "GET")

        # Generate token for safe methods
        if method in self.SAFE_METHODS:
            await self._process_safe_request(scope, receive, send)
        else:
            # Validate token for state-changing methods
            await self._process_unsafe_request(scope, receive, send)

    async def _process_safe_request(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process GET, HEAD, OPTIONS requests (generate and set token).

        Args:
            scope: ASGI connection scope
            receive: ASGI receive callable
            send: ASGI send callable

        """
        token = self._generate_csrf_token()
        scope["_csrf_token"] = token

        async def send_with_csrf(message: dict[str, Any]) -> None:
            """Wrap send to add CSRF token to response."""
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))

                # Add CSRF token as cookie
                csrf_cookie = self._create_csrf_cookie(token)
                headers.append((b"set-cookie", csrf_cookie.encode()))

                message["headers"] = headers

            await send(message)

        await self.app(scope, receive, send_with_csrf)

    async def _process_unsafe_request(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process POST, PUT, DELETE, PATCH requests (validate token).

        Args:
            scope: ASGI connection scope
            receive: ASGI receive callable
            send: ASGI send callable

        Raises:
            PermissionDenied: If CSRF token is invalid or missing

        """
        # Check if origin is trusted
        if self._is_trusted_origin(scope):
            await self.app(scope, receive, send)
            return

        # Extract CSRF token from request
        token_from_request = await self._extract_csrf_token(scope, receive)
        token_from_cookie = self._extract_token_from_cookie(scope)

        # Validate token
        if not token_from_request or not token_from_cookie:
            logger.warning(
                "CSRF validation failed",
                extra={
                    "reason": "missing_token",
                    "method": scope.get("method"),
                    "path": scope.get("path"),
                    "client": scope.get("client"),
                },
            )
            msg = "CSRF token missing or invalid"
            raise PermissionDenied(msg)

        if token_from_request != token_from_cookie:
            logger.warning(
                "CSRF validation failed",
                extra={
                    "reason": "token_mismatch",
                    "method": scope.get("method"),
                    "path": scope.get("path"),
                    "client": scope.get("client"),
                },
            )
            msg = "CSRF token invalid"
            raise PermissionDenied(msg)

        # Token valid, proceed
        scope["_csrf_token"] = token_from_cookie
        await self.app(scope, receive, send)

    def _generate_csrf_token(self) -> str:
        """Generate a secure CSRF token.

        Returns:
            A secure random token as a hex string

        """
        return secrets.token_hex(self.token_length // 2)

    def _create_csrf_cookie(self, token: str) -> str:
        """Create a secure CSRF token cookie.

        Args:
            token: The CSRF token value

        Returns:
            A Set-Cookie header value

        """
        cookie_parts = [f"{self.cookie_name}={token}"]

        if self.cookie_secure:
            cookie_parts.append("Secure")

        if self.cookie_httponly:
            cookie_parts.append("HttpOnly")

        cookie_parts.append(f"SameSite={self.cookie_samesite}")
        cookie_parts.append("Path=/")
        cookie_parts.append("Max-Age=31536000")  # 1 year

        return "; ".join(cookie_parts)

    def _extract_token_from_cookie(self, scope: Scope) -> str | None:
        """Extract CSRF token from cookies.

        Args:
            scope: ASGI connection scope

        Returns:
            The CSRF token from cookie, or None if not found

        """
        headers = self._get_headers(scope)
        cookie_header = headers.get(b"cookie", b"").decode()

        if not cookie_header:
            return None

        for cookie in cookie_header.split(";"):
            cookie = cookie.strip()
            if cookie.startswith(f"{self.cookie_name}="):
                return cookie.split("=", 1)[1]

        return None

    def _extract_token_from_header(self, scope: Scope) -> str | None:
        """Extract CSRF token from request headers.

        Args:
            scope: ASGI connection scope

        Returns:
            The CSRF token from header, or None if not found

        """
        headers = self._get_headers(scope)
        header_name = self.header_name.lower().encode()

        for header_key, header_value in headers.items():
            if header_key.lower() == header_name:
                return header_value.decode()

        return None

    async def _extract_token_from_form(self, receive: Receive) -> str | None:
        """Extract CSRF token from form data.

        Args:
            receive: ASGI receive callable

        Returns:
            The CSRF token from form field, or None if not found

        """
        try:
            message = await receive()

            if message["type"] != "http.request":
                return None

            body = message.get("body", b"")

            if not body:
                return None

            # Parse form data
            body_str = body.decode()
            parsed = urllib.parse.parse_qs(body_str)

            token_list = parsed.get(self.form_field_name, [])
            return token_list[0] if token_list else None
        except Exception as e:
            logger.warning(f"Error extracting CSRF token from form: {e}")
            return None

    async def _extract_csrf_token(self, scope: Scope, receive: Receive) -> str | None:
        """Extract CSRF token from request.

        Tries multiple sources in order:
        1. Request headers (X-CSRF-Token)
        2. Form data (_csrf_token field)

        Args:
            scope: ASGI connection scope
            receive: ASGI receive callable

        Returns:
            The CSRF token, or None if not found

        """
        # Try header first
        token = self._extract_token_from_header(scope)
        if token:
            return token

        # Try form data
        token = await self._extract_token_from_form(receive)
        if token:
            return token

        return None

    def _is_trusted_origin(self, scope: Scope) -> bool:
        """Check if request origin is in trusted origins list.

        Args:
            scope: ASGI connection scope

        Returns:
            True if origin is trusted, False otherwise

        """
        if not self.trusted_origins:
            return False

        headers = self._get_headers(scope)
        origin_header = headers.get(b"origin", b"").decode()

        return origin_header in self.trusted_origins

    def _is_safe_method(self, method: str) -> bool:
        """Check if HTTP method is safe (doesn't modify state).

        Args:
            method: HTTP method (GET, POST, etc.)

        Returns:
            True if method is safe, False otherwise

        """
        return method.upper() in self.SAFE_METHODS
