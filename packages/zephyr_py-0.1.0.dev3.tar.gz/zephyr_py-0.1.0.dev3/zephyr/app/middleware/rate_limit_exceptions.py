"""Rate limiting exceptions."""

from __future__ import annotations


class RateLimitError(Exception):
    """Base exception for rate limiting."""


class RateLimitExceeded(RateLimitError):
    """Raised when rate limit is exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: int | None = None,
        limit: int | None = None,
        remaining: int | None = None,
    ) -> None:
        """Initialize rate limit exceeded exception.

        Args:
            message: Error message.
            retry_after: Seconds to wait before retrying.
            limit: Total allowed requests.
            remaining: Remaining requests.

        """
        super().__init__(message)
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining


class RateLimitConfigError(RateLimitError):
    """Raised when rate limiting is misconfigured."""


class RateLimitBackendError(RateLimitError):
    """Raised when rate limiting backend fails."""
