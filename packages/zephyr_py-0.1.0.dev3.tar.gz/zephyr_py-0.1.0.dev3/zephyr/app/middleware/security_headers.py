"""Security Headers Middleware for Zephyr applications.

Implements comprehensive HTTP security headers to protect against common web
vulnerabilities including XSS, Clickjacking, MIME type sniffing, and more.
"""

from __future__ import annotations

import secrets
from typing import TYPE_CHECKING, Any

from zephyr.app.middleware.base import BaseMiddleware
from zephyr.core.logging import get_logger

if TYPE_CHECKING:
    from zephyr._types import ASGIApp, Receive, Scope, Send

logger = get_logger(__name__)


class SecurityHeadersMiddleware(BaseMiddleware):
    """Security headers middleware for comprehensive HTTP security.

    This middleware adds security-related HTTP headers to all responses to:
    1. Prevent clickjacking attacks (X-Frame-Options)
    2. Prevent MIME type sniffing (X-Content-Type-Options)
    3. Enable XSS protection (X-XSS-Protection, CSP)
    4. Enforce HTTPS (HSTS)
    5. Control referrer information (Referrer-Policy)
    6. Restrict browser features (Permissions-Policy)
    7. Enforce Content Security Policy (CSP)

    Configuration (from settings):
        - SECURITY_HEADERS_ENABLED: Enable/disable security headers
        - SECURITY_CSP_POLICY: Content-Security-Policy header value
        - SECURITY_FRAME_OPTIONS: X-Frame-Options header value
        - SECURITY_CONTENT_TYPE_OPTIONS: X-Content-Type-Options header value
        - SECURITY_HSTS_MAX_AGE: HSTS max-age in seconds
        - SECURITY_HSTS_INCLUDE_SUBDOMAINS: Include subdomains in HSTS
        - SECURITY_HSTS_PRELOAD: Include preload directive in HSTS
        - SECURITY_REFERRER_POLICY: Referrer-Policy header value
        - SECURITY_PERMISSIONS_POLICY: Permissions-Policy header value
    """

    # Default security header values
    DEFAULT_FRAME_OPTIONS = "DENY"
    DEFAULT_CONTENT_TYPE_OPTIONS = "nosniff"
    DEFAULT_XSS_PROTECTION = "1; mode=block"
    DEFAULT_REFERRER_POLICY = "strict-origin-when-cross-origin"
    DEFAULT_PERMISSIONS_POLICY = "geolocation=(), microphone=(), camera=(), payment=(), usb=()"

    def __init__(
        self,
        app: ASGIApp,
        *,
        settings: Any | None = None,
    ) -> None:
        """Initialize Security Headers middleware.

        Args:
            app: The ASGI application to wrap
            settings: Optional settings object with security configuration

        """
        super().__init__(app)
        self.settings = settings
        self.enabled = True
        self.csp_policy = (
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;"
        )
        self.frame_options = self.DEFAULT_FRAME_OPTIONS
        self.content_type_options = self.DEFAULT_CONTENT_TYPE_OPTIONS
        self.hsts_max_age = 31536000  # 1 year
        self.hsts_include_subdomains = True
        self.hsts_preload = False
        self.referrer_policy = self.DEFAULT_REFERRER_POLICY
        self.permissions_policy = self.DEFAULT_PERMISSIONS_POLICY

        if settings:
            self.enabled = getattr(settings, "SECURITY_HEADERS_ENABLED", True)
            self.csp_policy = getattr(settings, "SECURITY_CSP_POLICY", self.csp_policy)
            self.frame_options = getattr(settings, "SECURITY_FRAME_OPTIONS", self.frame_options)
            self.content_type_options = getattr(settings, "SECURITY_CONTENT_TYPE_OPTIONS", self.content_type_options)
            self.hsts_max_age = getattr(settings, "SECURITY_HSTS_MAX_AGE", self.hsts_max_age)
            self.hsts_include_subdomains = getattr(
                settings, "SECURITY_HSTS_INCLUDE_SUBDOMAINS", self.hsts_include_subdomains
            )
            self.hsts_preload = getattr(settings, "SECURITY_HSTS_PRELOAD", self.hsts_preload)
            self.referrer_policy = getattr(settings, "SECURITY_REFERRER_POLICY", self.referrer_policy)
            self.permissions_policy = getattr(settings, "SECURITY_PERMISSIONS_POLICY", self.permissions_policy)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """ASGI middleware entry point.

        Args:
            scope: ASGI connection scope
            receive: ASGI receive callable
            send: ASGI send callable

        """
        if not self._is_http_request(scope):
            await self.app(scope, receive, send)
            return

        if not self.enabled:
            await self.app(scope, receive, send)
            return

        async def send_with_security_headers(message: dict[str, Any]) -> None:
            """Wrap send to add security headers to response.

            Args:
                message: ASGI message

            """
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers = self._add_security_headers(headers, scope)
                message["headers"] = headers

            await send(message)

        await self.app(scope, receive, send_with_security_headers)

    def _add_security_headers(self, headers: list[tuple[bytes, bytes]], scope: Scope) -> list[tuple[bytes, bytes]]:
        """Add all security headers to response.

        Args:
            headers: Current response headers
            scope: ASGI connection scope

        Returns:
            Headers with security headers added

        """
        # Generate nonce for CSP if needed
        nonce = secrets.token_hex(16)

        # Add all security headers
        headers = self._add_header(headers, "X-Frame-Options", self.frame_options)
        headers = self._add_header(headers, "X-Content-Type-Options", self.content_type_options)
        headers = self._add_header(headers, "X-XSS-Protection", self.DEFAULT_XSS_PROTECTION)
        headers = self._add_header(headers, "Referrer-Policy", self.referrer_policy)
        headers = self._add_header(headers, "Permissions-Policy", self.permissions_policy)

        # Add HSTS header
        headers = self._add_hsts_header(headers)

        # Add CSP header with nonce
        return self._add_csp_header(headers, nonce)

    def _add_header(self, headers: list[tuple[bytes, bytes]], name: str, value: str) -> list[tuple[bytes, bytes]]:
        """Add or update a header.

        Args:
            headers: Current headers list
            name: Header name
            value: Header value

        Returns:
            Updated headers list

        """
        name_bytes = name.lower().encode()
        value_bytes = value.encode()

        # Remove existing header if present
        headers = [(n, v) for n, v in headers if n.lower() != name_bytes]

        # Add new header
        headers.append((name_bytes, value_bytes))
        return headers

    def _add_hsts_header(self, headers: list[tuple[bytes, bytes]]) -> list[tuple[bytes, bytes]]:
        """Add Strict-Transport-Security (HSTS) header.

        Args:
            headers: Current headers list

        Returns:
            Updated headers list

        """
        hsts_parts = [f"max-age={self.hsts_max_age}"]

        if self.hsts_include_subdomains:
            hsts_parts.append("includeSubDomains")

        if self.hsts_preload:
            hsts_parts.append("preload")

        hsts_value = "; ".join(hsts_parts)
        return self._add_header(headers, "Strict-Transport-Security", hsts_value)

    def _add_csp_header(self, headers: list[tuple[bytes, bytes]], nonce: str) -> list[tuple[bytes, bytes]]:
        """Add Content-Security-Policy (CSP) header with nonce.

        Args:
            headers: Current headers list
            nonce: Generated nonce for inline scripts

        Returns:
            Updated headers list

        """
        csp = self.csp_policy

        # Add nonce to script-src if CSP contains script-src
        if "script-src" in csp:
            csp = csp.replace("script-src", f"script-src 'nonce-{nonce}'")

        # Store nonce in scope for template rendering
        # csp += f"; script-src 'nonce-{nonce}'"

        return self._add_header(headers, "Content-Security-Policy", csp)

    def get_nonce(self) -> str:
        """Generate a CSP nonce for inline scripts.

        Can be used in templates for inline <script> tags.

        Returns:
            A random nonce string

        """
        return secrets.token_hex(16)
