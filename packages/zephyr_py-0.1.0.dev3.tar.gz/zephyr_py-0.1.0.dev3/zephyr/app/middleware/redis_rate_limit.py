"""Redis-backed distributed rate limiting middleware."""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import redis.asyncio as redis

from zephyr.app.middleware.rate_limit_exceptions import (
    RateLimitBackendError,
    RateLimitConfigError,
    RateLimitExceeded,
)

if TYPE_CHECKING:
    from zephyr.conf.base import BaseSettings


class RedisRateLimiter:
    """Redis-backed rate limiter using token bucket algorithm.

    This implements distributed rate limiting across multiple instances
    using Redis as the backend storage.
    """

    def __init__(
        self,
        redis_url: str,
        default_limit: int = 1000,
        default_window: int = 60,
        key_prefix: str = "zephyr:rate_limit:",
        enable_metrics: bool = True,
    ) -> None:
        """Initialize Redis rate limiter.

        Args:
            redis_url: Redis connection URL.
            default_limit: Default request limit per window.
            default_window: Default time window in seconds.
            key_prefix: Prefix for all rate limit keys.
            enable_metrics: Whether to track metrics.

        Raises:
            RateLimitConfigError: If configuration is invalid.

        """
        if not redis_url:
            raise RateLimitConfigError("redis_url is required for Redis rate limiter")

        self._redis_url = redis_url
        self._default_limit = default_limit
        self._default_window = default_window
        self._key_prefix = key_prefix
        self._enable_metrics = enable_metrics
        self._client: redis.Redis[bytes] | None = None
        self._metrics = {
            "requests_total": 0,
            "violations_total": 0,
            "checks_total": 0,
        }

    async def _connect(self) -> None:
        """Establish Redis connection."""
        if self._client is None:
            try:
                self._client = await redis.from_url(
                    self._redis_url,
                    decode_responses=False,
                    socket_connect_timeout=5,
                    socket_keepalive=True,
                )
                await self._client.ping()
            except Exception as e:
                self._client = None
                raise RateLimitBackendError(f"Failed to connect to Redis: {e}") from e

    async def _health_check(self) -> bool:
        """Check if Redis connection is healthy.

        Returns:
            True if healthy, False otherwise.

        """
        try:
            await self._connect()
            if self._client is None:
                return False
            await self._client.ping()
            return True
        except Exception:
            return False

    def _make_key(self, identifier: str) -> str:
        """Generate a rate limit key.

        Args:
            identifier: Unique identifier (user_id, IP, API key, etc).

        Returns:
            The prefixed rate limit key.

        """
        return f"{self._key_prefix}{identifier}"

    async def check_rate_limit(
        self,
        identifier: str,
        limit: int | None = None,
        window: int | None = None,
    ) -> dict[str, Any]:
        """Check if a request is within rate limits.

        Args:
            identifier: Unique identifier for rate limiting.
            limit: Request limit (uses default if None).
            window: Time window in seconds (uses default if None).

        Returns:
            Dictionary with rate limit status and metadata.

        Raises:
            RateLimitExceeded: If rate limit is exceeded.
            RateLimitBackendError: If backend operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                raise RateLimitBackendError("Redis connection not available")

            # Use defaults if not provided
            limit = limit or self._default_limit
            window = window or self._default_window

            key = self._make_key(identifier)
            current_time = time.time()
            window_start = current_time - window

            # Update metrics
            if self._enable_metrics:
                self._metrics["checks_total"] += 1

            # Use Lua script for atomic operation
            # This ensures the operation is atomic across multiple Redis nodes
            lua_script = """
            local key = KEYS[1]
            local now = tonumber(ARGV[1])
            local window_start = tonumber(ARGV[2])
            local limit = tonumber(ARGV[3])
            local window = tonumber(ARGV[4])

            -- Remove old entries outside the window
            redis.call('ZREMRANGEBYSCORE', key, '-inf', window_start)

            -- Count requests in current window
            local current = redis.call('ZCARD', key)

            -- Create the result
            local result = {
                current = current,
                limit = limit,
                remaining = limit - current
            }

            -- Check if limit exceeded
            if current < limit then
                -- Add current request
                redis.call('ZADD', key, now, now)
                redis.call('EXPIRE', key, window + 1)
                return {1, result["current"] + 1, result["limit"], result["remaining"] - 1}
            else
                -- Limit exceeded
                return {0, result["current"], result["limit"], 0}
            end
            """

            script = self._client.register_script(lua_script)
            # Call the script - it's callable with await
            result = await script(keys=[key], args=[current_time, window_start, limit, window])

            allowed, requests_in_window, rate_limit, remaining = result

            if self._enable_metrics:
                self._metrics["requests_total"] += 1

            if not allowed:
                if self._enable_metrics:
                    self._metrics["violations_total"] += 1

                raise RateLimitExceeded(
                    message=f"Rate limit exceeded: {requests_in_window}/{rate_limit}",
                    retry_after=window,
                    limit=rate_limit,
                    remaining=0,
                )

            return {
                "allowed": True,
                "limit": rate_limit,
                "remaining": remaining,
                "reset_at": current_time + window,
                "window": window,
            }

        except RateLimitExceeded:
            raise
        except Exception as e:
            raise RateLimitBackendError(f"Rate limit check failed: {e}") from e

    async def reset(self, identifier: str) -> None:
        """Reset rate limit for an identifier.

        Args:
            identifier: Unique identifier to reset.

        Raises:
            RateLimitBackendError: If operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            key = self._make_key(identifier)
            await self._client.delete(key)
        except Exception as e:
            raise RateLimitBackendError(f"Failed to reset rate limit: {e}") from e

    async def reset_all(self) -> None:
        """Reset all rate limits.

        Raises:
            RateLimitBackendError: If operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            pattern = f"{self._key_prefix}*"
            cursor = 0
            while True:
                cursor, keys = await self._client.scan(cursor, match=pattern, count=100)
                if keys:
                    await self._client.delete(*keys)
                if cursor == 0:
                    break
        except Exception as e:
            raise RateLimitBackendError(f"Failed to reset all rate limits: {e}") from e

    async def close(self) -> None:
        """Close Redis connection."""
        try:
            if self._client is not None:
                await self._client.close()
                self._client = None
        except Exception:
            pass

    def get_metrics(self) -> dict[str, int]:
        """Get rate limiting metrics.

        Returns:
            Dictionary with metric counters.

        """
        return self._metrics.copy()

    def reset_metrics(self) -> None:
        """Reset metrics counters."""
        self._metrics = {
            "requests_total": 0,
            "violations_total": 0,
            "checks_total": 0,
        }


class RedisRateLimitMiddleware:
    """Middleware for Redis-backed rate limiting.

    This middleware can be applied to individual routes or globally
    to enforce distributed rate limits.
    """

    def __init__(
        self,
        app: Callable[..., Any],
        settings: BaseSettings,
        fallback_limiter: Any | None = None,
    ) -> None:
        """Initialize rate limit middleware.

        Args:
            app: ASGI application.
            settings: Application settings.
            fallback_limiter: Optional memory-based rate limiter for fallback.

        """
        self.app = app
        self.settings = settings
        self.fallback_limiter = fallback_limiter

        # Initialize Redis rate limiter
        self.limiter: RedisRateLimiter | None = None
        if settings.RATE_LIMIT_REDIS_URL:
            try:
                self.limiter = RedisRateLimiter(
                    redis_url=settings.RATE_LIMIT_REDIS_URL,
                    default_limit=settings.RATE_LIMIT_REQUESTS,
                    default_window=settings.RATE_LIMIT_WINDOW,
                    key_prefix=settings.RATE_LIMIT_KEY_PREFIX,
                    enable_metrics=settings.RATE_LIMIT_ENABLE_METRICS,
                )
            except Exception as e:
                # Log warning but don't fail initialization
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(f"Failed to initialize Redis rate limiter: {e}")

    async def __call__(
        self,
        scope: dict[str, Any],
        receive: Any,
        send: Any,
    ) -> None:
        """Process ASGI request with rate limiting.

        Args:
            scope: ASGI scope dictionary.
            receive: ASGI receive callable.
            send: ASGI send callable.

        """
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # Get client IP
        client_ip = scope.get("client", ("unknown", 0))[0]

        # Get user ID from scope (set by auth middleware)
        user_id = scope.get("user", {}).get("id") if scope.get("user") else None

        # Determine rate limit identifier
        identifier = user_id or client_ip

        try:
            # Try Redis limiter first
            if self.limiter:
                try:
                    result = await self.limiter.check_rate_limit(identifier)
                    # Store in scope for response headers
                    scope["rate_limit"] = result
                except RateLimitExceeded:
                    # Send 429 Too Many Requests
                    await send(
                        {
                            "type": "http.response.start",
                            "status": 429,
                            "headers": [
                                [b"content-type", b"application/json"],
                                [b"retry-after", str(result.get("window", 60)).encode()],
                            ],
                        }
                    )
                    await send(
                        {
                            "type": "http.response.body",
                            "body": b'{"error": "Rate limit exceeded"}',
                        }
                    )
                    return
                except RateLimitBackendError:
                    # Fall back to memory limiter if available
                    if self.fallback_limiter:
                        try:
                            result = await self.fallback_limiter.check_rate_limit(identifier)
                            scope["rate_limit"] = result
                        except RateLimitExceeded:
                            await send(
                                {
                                    "type": "http.response.start",
                                    "status": 429,
                                    "headers": [[b"content-type", b"application/json"]],
                                }
                            )
                            await send(
                                {
                                    "type": "http.response.body",
                                    "body": b'{"error": "Rate limit exceeded"}',
                                }
                            )
                            return
            elif self.fallback_limiter:
                result = await self.fallback_limiter.check_rate_limit(identifier)
                scope["rate_limit"] = result

        except Exception:
            # Log error but don't block request
            pass

        # Call app and add rate limit headers to response
        async def send_with_headers(message: dict[str, Any]) -> None:
            """Wrapper to add rate limit headers."""
            if message["type"] == "http.response.start" and "rate_limit" in scope:
                rate_limit = scope["rate_limit"]
                headers = list(message.get("headers", []))
                headers.extend(
                    [
                        [b"x-ratelimit-limit", str(rate_limit["limit"]).encode()],
                        [b"x-ratelimit-remaining", str(rate_limit["remaining"]).encode()],
                        [b"x-ratelimit-reset", str(int(rate_limit["reset_at"])).encode()],
                    ]
                )
                message["headers"] = headers

            await send(message)

        await self.app(scope, receive, send_with_headers)

    async def close(self) -> None:
        """Close middleware and connections."""
        if self.limiter:
            await self.limiter.close()
