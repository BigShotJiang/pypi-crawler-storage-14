"""SSO data models.

Defines all SSO-related data models including users, providers, and authentication states.
"""

import secrets
from datetime import datetime, timedelta, timezone, UTC
from typing import Any
from urllib.parse import urlencode

from pydantic import BaseModel, Field, field_validator


class SSOUser(BaseModel):
    """SSO user model."""

    id: str = Field(..., description="Unique user identifier")
    provider: str = Field(..., description="SSO provider name")
    provider_user_id: str = Field(..., description="User ID from SSO provider")
    email: str = Field(..., description="User email address")
    username: str | None = Field(default=None, description="Username")
    first_name: str | None = Field(default=None, description="First name")
    last_name: str | None = Field(default=None, description="Last name")
    display_name: str | None = Field(default=None, description="Display name")
    avatar_url: str | None = Field(default=None, description="Avatar URL")
    locale: str | None = Field(default=None, description="User locale")
    timezone: str | None = Field(default=None, description="User timezone")
    is_verified: bool = Field(default=False, description="Whether email is verified")
    is_active: bool = Field(default=True, description="Whether user is active")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC), description="Creation timestamp")
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC), description="Last update timestamp")
    last_login_at: datetime | None = Field(default=None, description="Last login timestamp")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional user metadata")
    provider_data: dict[str, Any] = Field(default_factory=dict, description="Raw provider data")

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        """Validate email format."""
        if "@" not in v or "." not in v.split("@")[1]:
            msg = "Invalid email format"
            raise ValueError(msg)
        return v.lower()

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        """Validate provider name."""
        valid_providers = {"google", "github", "microsoft", "apple", "saml", "generic_oauth2", "keycloak"}
        if v.lower() not in valid_providers:
            msg = f"Invalid provider: {v}"
            raise ValueError(msg)
        return v.lower()

    def get_full_name(self) -> str:
        """Get user's full name."""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        if self.display_name:
            return self.display_name
        if self.first_name:
            return self.first_name
        if self.last_name:
            return self.last_name
        return self.username or self.email.split("@")[0]

    def get_avatar_url(self, size: int = 64) -> str | None:
        """Get avatar URL with specified size."""
        if not self.avatar_url:
            return None

        # Add size parameter for common providers
        if "google" in self.provider and "googleusercontent.com" in self.avatar_url:
            return f"{self.avatar_url}?sz={size}"
        if "github" in self.provider and "github.com" in self.avatar_url:
            return f"{self.avatar_url}?s={size}"
        if "microsoft" in self.provider and "graph.microsoft.com" in self.avatar_url:
            return f"{self.avatar_url}?size={size}"
        return self.avatar_url

    def to_dict(self) -> dict[str, Any]:
        """Convert user to dictionary."""
        return {
            "id": self.id,
            "provider": self.provider,
            "provider_user_id": self.provider_user_id,
            "email": self.email,
            "username": self.username,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "display_name": self.display_name,
            "avatar_url": self.avatar_url,
            "locale": self.locale,
            "timezone": self.timezone,
            "is_verified": self.is_verified,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "last_login_at": self.last_login_at.isoformat() if self.last_login_at else None,
            "metadata": self.metadata,
            "provider_data": self.provider_data,
        }

    class Config:
        """Pydantic configuration."""

        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class SSOProviderInfo(BaseModel):
    """SSO provider information model."""

    name: str = Field(..., description="Provider name")
    display_name: str = Field(..., description="Human-readable provider name")
    description: str = Field(..., description="Provider description")
    icon_url: str | None = Field(default=None, description="Provider icon URL")
    color: str | None = Field(default=None, description="Provider brand color")
    website_url: str | None = Field(default=None, description="Provider website URL")
    documentation_url: str | None = Field(default=None, description="Provider documentation URL")
    supported_scopes: list[str] = Field(default_factory=list, description="Supported OAuth scopes")
    supported_claims: list[str] = Field(default_factory=list, description="Supported user claims")
    is_enabled: bool = Field(default=True, description="Whether provider is enabled")
    is_configured: bool = Field(default=False, description="Whether provider is configured")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional provider metadata")

    class Config:
        """Pydantic configuration."""

        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class SSOProviderConfig(BaseModel):
    """SSO provider configuration model."""

    provider: str = Field(..., description="Provider name")
    client_id: str = Field(..., description="OAuth client ID")
    client_secret: str = Field(..., description="OAuth client secret")
    redirect_uri: str = Field(..., description="OAuth redirect URI")
    scopes: list[str] = Field(default_factory=list, description="OAuth scopes")
    authorization_url: str = Field(..., description="OAuth authorization URL")
    token_url: str = Field(..., description="OAuth token URL")
    user_info_url: str = Field(..., description="User info API URL")
    jwks_url: str | None = Field(default=None, description="JWKS URL for token verification")
    issuer: str | None = Field(default=None, description="OAuth issuer")
    audience: str | None = Field(default=None, description="OAuth audience")
    is_enabled: bool = Field(default=True, description="Whether provider is enabled")
    auto_register: bool = Field(default=True, description="Whether to auto-register new users")
    auto_activate: bool = Field(default=True, description="Whether to auto-activate new users")
    require_email_verification: bool = Field(default=False, description="Whether to require email verification")
    user_mapping: dict[str, str] = Field(default_factory=dict, description="User attribute mapping")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional configuration metadata")

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        """Validate provider name."""
        valid_providers = {"google", "github", "microsoft", "apple", "saml", "generic_oauth2", "keycloak"}
        if v.lower() not in valid_providers:
            msg = f"Invalid provider: {v}"
            raise ValueError(msg)
        return v.lower()

    @field_validator("redirect_uri")
    @classmethod
    def validate_redirect_uri(cls, v: str) -> str:
        """Validate redirect URI."""
        if not v.startswith(("http://", "https://")):
            msg = "Redirect URI must start with http:// or https://"
            raise ValueError(msg)
        return v

    def get_authorization_url(self, state: str, additional_params: dict[str, str] | None = None) -> str:
        """Get OAuth authorization URL."""
        params = {
            "response_type": "code",
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": " ".join(self.scopes),
            "state": state,
        }

        if additional_params:
            params.update(additional_params)

        return f"{self.authorization_url}?{urlencode(params)}"

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary (excluding secrets)."""
        return {
            "provider": self.provider,
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scopes": self.scopes,
            "authorization_url": self.authorization_url,
            "token_url": self.token_url,
            "user_info_url": self.user_info_url,
            "jwks_url": self.jwks_url,
            "issuer": self.issuer,
            "audience": self.audience,
            "is_enabled": self.is_enabled,
            "auto_register": self.auto_register,
            "auto_activate": self.auto_activate,
            "require_email_verification": self.require_email_verification,
            "user_mapping": self.user_mapping,
            "metadata": self.metadata,
        }

    class Config:
        """Pydantic configuration."""

        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class SSOAuthState(BaseModel):
    """SSO authentication state model."""

    state: str = Field(..., description="Unique state identifier")
    provider: str = Field(..., description="SSO provider name")
    redirect_url: str | None = Field(default=None, description="Redirect URL after authentication")
    user_id: str | None = Field(default=None, description="User ID if already authenticated")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC), description="Creation timestamp")
    expires_at: datetime = Field(..., description="Expiration timestamp")
    is_used: bool = Field(default=False, description="Whether state has been used")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional state metadata")

    def is_expired(self) -> bool:
        """Check if state has expired."""
        return datetime.now(timezone.utc) > self.expires_at  # noqa: UP017

    def is_valid(self) -> bool:
        """Check if state is valid (not used and not expired)."""
        return not self.is_used and not self.is_expired()

    def mark_as_used(self) -> None:
        """Mark state as used."""
        self.is_used = True

    class Config:
        """Pydantic configuration."""

        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class SSOAuthResult(BaseModel):
    """SSO authentication result model."""

    success: bool = Field(..., description="Whether authentication was successful")
    user: SSOUser | None = Field(default=None, description="Authenticated user")
    provider: str = Field(..., description="SSO provider name")
    state: str | None = Field(default=None, description="Authentication state")
    error: str | None = Field(default=None, description="Error message if failed")
    error_code: str | None = Field(default=None, description="Error code if failed")
    redirect_url: str | None = Field(default=None, description="Redirect URL after authentication")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional result metadata")

    @classmethod
    def success_result(
        cls,
        user: SSOUser,
        provider: str,
        state: str | None = None,
        redirect_url: str | None = None,
        **kwargs: Any,
    ) -> "SSOAuthResult":
        """Create successful authentication result."""
        return cls(success=True, user=user, provider=provider, state=state, redirect_url=redirect_url, metadata=kwargs)

    @classmethod
    def error_result(
        cls, provider: str, error: str, error_code: str | None = None, state: str | None = None, **kwargs: Any
    ) -> "SSOAuthResult":
        """Create failed authentication result."""
        return cls(success=False, provider=provider, state=state, error=error, error_code=error_code, metadata=kwargs)

    def to_dict(self) -> dict[str, Any]:
        """Convert result to dictionary."""
        result = {
            "success": self.success,
            "provider": self.provider,
            "state": self.state,
            "redirect_url": self.redirect_url,
            "metadata": self.metadata,
        }

        if self.user:
            result["user"] = self.user.to_dict()

        if self.error:
            result["error"] = self.error
            result["error_code"] = self.error_code

        return result

    class Config:
        """Pydantic configuration."""

        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class SSOToken(BaseModel):
    """SSO token model."""

    access_token: str = Field(..., description="OAuth access token")
    token_type: str = Field(default="Bearer", description="Token type")
    expires_in: int = Field(..., description="Token expiration time in seconds")
    refresh_token: str | None = Field(default=None, description="OAuth refresh token")
    scope: str | None = Field(default=None, description="Token scope")
    id_token: str | None = Field(default=None, description="OpenID Connect ID token")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC), description="Creation timestamp")
    expires_at: datetime = Field(..., description="Expiration timestamp")
    provider: str = Field(..., description="SSO provider name")
    user_id: str | None = Field(default=None, description="User ID")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional token metadata")

    def is_expired(self) -> bool:
        """Check if token has expired."""
        return datetime.now(timezone.utc) > self.expires_at  # noqa: UP017

    def is_valid(self) -> bool:
        """Check if token is valid (not expired)."""
        return not self.is_expired()

    def get_remaining_time(self) -> int:
        """Get remaining time until expiration in seconds."""
        if self.is_expired():
            return 0
        return int((self.expires_at - datetime.now(timezone.utc)).total_seconds())  # noqa: UP017

    class Config:
        """Pydantic configuration."""

        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


def generate_state() -> str:
    """Generate a random state parameter."""
    return secrets.token_urlsafe(32)


def generate_nonce() -> str:
    """Generate a random nonce parameter."""
    return secrets.token_urlsafe(16)


def create_auth_state(
    provider: str,
    expires_in: int = 600,
    redirect_url: str | None = None,
    user_id: str | None = None,
    **kwargs: Any,
) -> SSOAuthState:
    """Create authentication state."""
    state = generate_state()
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)  # noqa: UP017

    return SSOAuthState(
        state=state,
        provider=provider,
        redirect_url=redirect_url,
        user_id=user_id,
        expires_at=expires_at,
        metadata=kwargs,
    )
