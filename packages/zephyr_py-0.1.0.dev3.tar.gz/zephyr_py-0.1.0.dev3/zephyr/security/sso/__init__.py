"""Single Sign-On (SSO) providers for Zephyr.

Provides comprehensive SSO integration with major identity providers including
Google, GitHub, Microsoft, Apple, and SAML.
"""

from .config import SSOConfig
from .exceptions import (
    SSOAuthCancelledError,
    SSOAuthError,
    SSOAuthTimeoutError,
    SSOConfigError,
    SSOError,
    SSOInvalidStateError,
    SSOProviderError,
    SSOProviderNotFoundError,
    SSOUserNotFoundError,
)
from .manager import SSOManager
from .models import SSOAuthResult, SSOAuthState, SSOProviderConfig, SSOProviderInfo, SSOUser
from .providers import (
    AppleSSOProvider,
    GenericOAuth2SSOProvider,
    GitHubSSOProvider,
    GoogleSSOProvider,
    MicrosoftSSOProvider,
    SAMLSSOProvider,
    SSOProvider,
)

__all__ = [
    "AppleSSOProvider",
    "GenericOAuth2SSOProvider",
    "GitHubSSOProvider",
    "GoogleSSOProvider",
    "MicrosoftSSOProvider",
    "SAMLSSOProvider",
    "SSOAuthCancelledError",
    "SSOAuthError",
    "SSOAuthResult",
    "SSOAuthState",
    "SSOAuthTimeoutError",
    # Configuration
    "SSOConfig",
    "SSOConfigError",
    # Exceptions
    "SSOError",
    "SSOInvalidStateError",
    # Manager
    "SSOManager",
    # Providers
    "SSOProvider",
    "SSOProviderConfig",
    "SSOProviderError",
    "SSOProviderInfo",
    "SSOProviderNotFoundError",
    # Models
    "SSOUser",
    "SSOUserNotFoundError",
]
