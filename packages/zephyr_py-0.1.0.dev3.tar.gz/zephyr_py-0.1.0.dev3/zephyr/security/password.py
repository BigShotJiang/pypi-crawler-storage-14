"""Password hashing and verification for Zephyr.

Provides secure password hashing using bcrypt with constant-time comparison.
"""

from __future__ import annotations

import secrets
import warnings

from passlib.context import CryptContext

# Import InvalidHashError - in some passlib versions it's a function, not a class
# We'll check for hash errors by examining the exception message instead
try:
    from passlib.exc import InvalidHashError as _InvalidHashError

    # Try to use it, but if it's not a class, we'll handle errors differently
    if isinstance(_InvalidHashError, type) and issubclass(_InvalidHashError, Exception):
        InvalidHashError = _InvalidHashError
    else:
        InvalidHashError = None  # Will check error messages instead
except (ImportError, TypeError):
    InvalidHashError = None

# Fix bcrypt compatibility with passlib
try:
    import bcrypt

    # Passlib expects bcrypt to have __about__ attribute
    if not hasattr(bcrypt, "__about__"):
        # Create a mock __about__ module for compatibility
        class MockAbout:
            """Mock __about__ module for bcrypt compatibility."""

            __version__ = getattr(bcrypt, "__version__", "unknown")

        bcrypt.__about__ = MockAbout()
except ImportError:
    pass


class PasswordError(Exception):
    """Base password error."""


class PasswordHashError(PasswordError):
    """Password hashing error."""


class PasswordVerificationError(PasswordError):
    """Password verification error."""


# Bcrypt maximum password length in bytes
BCRYPT_MAX_PASSWORD_LENGTH = 72


class PasswordHasher:
    """Secure password hasher using bcrypt.

    Provides password hashing, verification, and rehashing capabilities
    with constant-time comparison to prevent timing attacks.
    """

    _initialization_attempted = False
    _initialization_lock = None

    def __init__(self, schemes: list[str] | None = None, deprecated: list[str] | None = None) -> None:
        """Initialize password hasher.

        Args:
            schemes: List of hashing schemes to use (in order of preference)
            deprecated: List of deprecated schemes to check for rehashing

        """
        # Suppress warnings from passlib's bcrypt backend initialization
        if deprecated is None:
            deprecated = []
        if schemes is None:
            schemes = ["bcrypt"]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self.context = CryptContext(
                schemes=schemes,
                deprecated=deprecated,
                bcrypt__rounds=12,  # Secure default
                bcrypt__min_rounds=10,  # Minimum acceptable rounds
                bcrypt__max_rounds=15,  # Maximum rounds for performance
            )

    async def hash_password(self, password: str) -> str:
        """Hash password using bcrypt with automatic salt generation.

        Args:
            password: Plain text password

        Returns:
            Hashed password string

        Raises:
            PasswordHashError: If hashing fails

        """
        if not password:
            msg = "Password cannot be empty"
            raise PasswordHashError(msg)

        # Truncate password if too long for bcrypt (72 bytes max)
        password_bytes = password.encode("utf-8")
        if len(password_bytes) > BCRYPT_MAX_PASSWORD_LENGTH:
            password = password_bytes[:BCRYPT_MAX_PASSWORD_LENGTH].decode("utf-8", errors="ignore")

        # Handle passlib's bcrypt backend initialization issue
        # Passlib may fail during bug detection - we use direct bcrypt as fallback
        try:
            return self.context.hash(password)
        except ValueError as e:
            error_msg = str(e).lower()
            if "72 bytes" in error_msg or "cannot be longer" in error_msg:
                # This might be passlib's bug detection failing or actual password too long
                # Use bcrypt directly as fallback
                try:
                    # Ensure password is exactly 72 bytes or less
                    final_password = password_bytes[:BCRYPT_MAX_PASSWORD_LENGTH].decode("utf-8", errors="ignore")
                    # Generate salt and hash directly with bcrypt
                    salt = bcrypt.gensalt(rounds=12)
                    hashed = bcrypt.hashpw(final_password.encode("utf-8"), salt)
                    # Return in passlib format for compatibility
                    return hashed.decode("utf-8")
                except ImportError:
                    msg = "bcrypt library not available"
                    raise PasswordHashError(msg) from e
                except Exception as bcrypt_error:
                    msg = f"Password hashing failed: {bcrypt_error}"
                    raise PasswordHashError(msg) from bcrypt_error
            msg = f"Password hashing failed: {e}"
            raise PasswordHashError(msg) from e
        except Exception as e:
            msg = f"Password hashing failed: {e}"
            raise PasswordHashError(msg) from e

    async def verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password using constant-time comparison.

        Args:
            password: Plain text password to verify
            password_hash: Stored password hash

        Returns:
            True if password matches, False otherwise

        Raises:
            PasswordVerificationError: If verification fails due to invalid hash

        """
        if not password:
            return False

        if not password_hash:
            return False

        # Truncate password if too long for bcrypt (72 bytes max)
        password_bytes = password.encode("utf-8")
        if len(password_bytes) > BCRYPT_MAX_PASSWORD_LENGTH:
            password = password_bytes[:BCRYPT_MAX_PASSWORD_LENGTH].decode("utf-8", errors="ignore")

        # Handle passlib's bcrypt backend initialization issue during verification
        try:
            return self.context.verify(password, password_hash)
        except ValueError as e:
            error_msg = str(e).lower()
            if "72 bytes" in error_msg or "cannot be longer" in error_msg:
                # This might be passlib's bug detection failing - use bcrypt directly as fallback
                try:
                    # Ensure password is exactly 72 bytes or less
                    final_password = password_bytes[:BCRYPT_MAX_PASSWORD_LENGTH].decode("utf-8", errors="ignore")
                    # Verify using bcrypt directly
                    # password_hash might already be bytes or a string
                    hash_bytes = password_hash.encode("utf-8") if isinstance(password_hash, str) else password_hash
                    return bcrypt.checkpw(final_password.encode("utf-8"), hash_bytes)
                except (ImportError, ValueError, TypeError, OSError):
                    # If bcrypt direct check fails, assume verification failed
                    return False
            # Re-raise other ValueErrors
            msg = f"Password verification failed: {e}"
            raise PasswordVerificationError(msg) from e
        except Exception as e:
            # Check if it's an InvalidHashError-like exception
            error_msg = str(e).lower()
            is_invalid_hash = (InvalidHashError and isinstance(e, InvalidHashError)) or (
                "invalid" in error_msg and "hash" in error_msg
            )
            if is_invalid_hash:
                msg = f"Invalid password hash: {e}"
                raise PasswordVerificationError(msg) from e
            msg = f"Password verification failed: {e}"
            raise PasswordVerificationError(msg) from e

    async def needs_rehash(self, password_hash: str) -> bool:
        """Check if hash needs upgrade (algorithm changed or rounds increased).

        Args:
            password_hash: Current password hash

        Returns:
            True if password needs rehashing, False otherwise

        Raises:
            PasswordVerificationError: If hash is invalid

        """
        try:
            return self.context.needs_update(password_hash)
        except Exception as e:
            # Check if it's an InvalidHashError-like exception or UnknownHashError
            error_msg = str(e).lower()
            error_type = str(type(e))
            if (
                (InvalidHashError and isinstance(e, InvalidHashError))
                or "UnknownHashError" in error_type
                or ("invalid" in error_msg and "hash" in error_msg)
                or ("could not be identified" in error_msg)
            ):
                msg = f"Invalid password hash: {e}"
                raise PasswordVerificationError(msg) from e
            msg = f"Rehash check failed: {e}"
            raise PasswordVerificationError(msg) from e

    async def generate_salt(self, length: int = 32) -> str:
        """Generate cryptographically secure random salt.

        Args:
            length: Salt length in bytes

        Returns:
            Base64-encoded salt string

        """
        return secrets.token_urlsafe(length)

    def get_scheme_info(self, password_hash: str) -> dict[str, object]:
        """Get information about the hashing scheme used.

        Args:
            password_hash: Password hash to analyze

        Returns:
            Dictionary with scheme information

        """
        if not password_hash:
            return {"scheme": "unknown", "error": "Empty hash"}
        try:
            info = self.context.identify(password_hash)
            if info is None:
                return {"scheme": "unknown", "error": "Unable to identify scheme"}
            # identify() may return a string or dict depending on passlib version
            if isinstance(info, str):
                return {"scheme": info}
            if isinstance(info, dict):
                return info
            # Fallback
            return {"scheme": str(info), "error": "Unexpected format"}
        except (ValueError, TypeError, AttributeError):
            return {"scheme": "unknown", "error": "Unable to identify scheme"}
