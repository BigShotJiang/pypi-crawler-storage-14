"""Role-Based Access Control (RBAC) system for Zephyr.

Provides comprehensive RBAC functionality including roles, permissions,
policy engine, and access control mechanisms.
"""

from .config import RBACConfig
from .engine import AccessControlEngine, PolicyEngine, RBACEngine
from .exceptions import (
    AccessControlError,
    AccessDeniedError,
    InvalidPermissionError,
    InvalidPolicyError,
    InvalidRoleError,
    PermissionNotFoundError,
    PolicyEvaluationError,
    PolicyNotFoundError,
    RBACError,
    RoleNotFoundError,
)
from .manager import RBACManager
from .models import AccessContext, AccessDecision, Action, Effect, Permission, Policy, PolicyRule, Resource, Role

__all__ = [
    "AccessContext",
    "AccessControlEngine",
    "AccessControlError",
    "AccessDecision",
    "AccessDeniedError",
    "Action",
    "Effect",
    "InvalidPermissionError",
    "InvalidPolicyError",
    "InvalidRoleError",
    "Permission",
    "PermissionNotFoundError",
    "Policy",
    # Engines
    "PolicyEngine",
    "PolicyEvaluationError",
    "PolicyNotFoundError",
    "PolicyRule",
    # Config
    "RBACConfig",
    "RBACEngine",
    # Exceptions
    "RBACError",
    # Manager
    "RBACManager",
    "Resource",
    # Models
    "Role",
    "RoleNotFoundError",
]
