"""Keycloak integration for Zephyr applications.

Provides Keycloak OAuth2/OIDC authentication, Admin API client, and SSO integration.
"""

from .admin import KeycloakAdmin
from .client import KeycloakClient
from .config import KeycloakConfig, KeycloakRealmConfig
from .exceptions import (
    KeycloakAdminError,
    KeycloakAuthenticationError,
    KeycloakConnectionError,
    KeycloakError,
    KeycloakExpiredTokenError,
    KeycloakInvalidTokenError,
    KeycloakRealmNotFoundError,
    KeycloakTokenError,
    KeycloakUserNotFoundError,
)
from .models import (
    KeycloakClient as KeycloakClientModel,
)
from .models import (
    KeycloakGroup,
    KeycloakRealm,
    KeycloakRole,
    KeycloakToken,
    KeycloakUser,
    KeycloakUserInfo,
)
from .provider import KeycloakSSOProvider

__all__ = [
    "KeycloakAdmin",
    "KeycloakAdminError",
    "KeycloakAuthenticationError",
    # Client
    "KeycloakClient",
    "KeycloakClientModel",
    # Configuration
    "KeycloakConfig",
    "KeycloakConnectionError",
    # Exceptions
    "KeycloakError",
    "KeycloakExpiredTokenError",
    "KeycloakGroup",
    "KeycloakInvalidTokenError",
    "KeycloakRealm",
    "KeycloakRealmConfig",
    "KeycloakRealmNotFoundError",
    "KeycloakRole",
    # Provider
    "KeycloakSSOProvider",
    # Models
    "KeycloakToken",
    "KeycloakTokenError",
    "KeycloakUser",
    "KeycloakUserInfo",
    "KeycloakUserNotFoundError",
]
