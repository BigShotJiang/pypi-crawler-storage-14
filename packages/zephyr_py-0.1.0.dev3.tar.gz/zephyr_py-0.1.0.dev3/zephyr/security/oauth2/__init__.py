"""OAuth2 Server Implementation for Zephyr.

Provides comprehensive OAuth2 authorization server functionality including
Authorization Code, Client Credentials, PKCE, and Device flows.
"""

from .endpoints import AuthorizationEndpoint, IntrospectionEndpoint, RevocationEndpoint, TokenEndpoint
from .exceptions import (
    AccessDeniedError,
    InvalidClientError,
    InvalidGrantError,
    InvalidRequestError,
    InvalidScopeError,
    OAuth2Error,
    ServerError,
    UnsupportedGrantTypeError,
    UnsupportedResponseTypeError,
)
from .flows import AuthorizationCodeFlow, ClientCredentialsFlow, DeviceFlow, PKCEFlow, RefreshTokenFlow
from .models import (
    OAuth2AccessToken,
    OAuth2AuthorizationCode,
    OAuth2Client,
    OAuth2DeviceCode,
    OAuth2Grant,
    OAuth2RefreshToken,
    OAuth2Scope,
)
from .config import OAuth2Config
from .server import OAuth2Server

__all__ = [
    "AccessDeniedError",
    # Flows
    "AuthorizationCodeFlow",
    # Endpoints
    "AuthorizationEndpoint",
    "ClientCredentialsFlow",
    "DeviceFlow",
    "IntrospectionEndpoint",
    "InvalidClientError",
    "InvalidGrantError",
    "InvalidRequestError",
    "InvalidScopeError",
    "OAuth2AccessToken",
    "OAuth2AuthorizationCode",
    # Models
    "OAuth2Client",
    "OAuth2Config",
    "OAuth2DeviceCode",
    # Exceptions
    "OAuth2Error",
    "OAuth2Grant",
    "OAuth2RefreshToken",
    "OAuth2Scope",
    # Server
    "OAuth2Server",
    "PKCEFlow",
    "RefreshTokenFlow",
    "RevocationEndpoint",
    "ServerError",
    "TokenEndpoint",
    "UnsupportedGrantTypeError",
    "UnsupportedResponseTypeError",
]
