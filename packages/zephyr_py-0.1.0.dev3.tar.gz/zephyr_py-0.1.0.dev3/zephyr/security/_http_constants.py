"""HTTP status code constants for security modules.

Centralized HTTP status codes to avoid magic values (PLR2004).
"""

from __future__ import annotations

# Success codes
HTTP_OK = 200
HTTP_CREATED = 201
HTTP_NO_CONTENT = 204

# Client error codes
HTTP_BAD_REQUEST = 400
HTTP_UNAUTHORIZED = 401
HTTP_FORBIDDEN = 403
HTTP_NOT_FOUND = 404

# Server error codes
HTTP_INTERNAL_SERVER_ERROR = 500
HTTP_SERVICE_UNAVAILABLE = 503

# Token-related constants (not passwords, just identifiers)
TOKEN_TYPE_ACCESS = "access_token"  # noqa: S105
TOKEN_TYPE_REFRESH = "refresh_token"  # noqa: S105
TOKEN_TYPE_AUTH_CODE = "authorization_code"  # noqa: S105
TOKEN_TYPE_DEVICE = "device_code"  # noqa: S105

# Cache duration
JWKS_CACHE_DURATION = 3600  # 1 hour in seconds
