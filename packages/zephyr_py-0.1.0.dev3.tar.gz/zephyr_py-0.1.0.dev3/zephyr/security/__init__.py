"""Zephyr Security Module

Comprehensive authentication and authorization system for Zephyr applications.
"""

from .backends import AuthenticationBackend, JWTAuthenticationBackend
from .jwt import JWTConfig, JWTManager, JWTPayload
from .middleware import BearerAuthMiddleware
from .oauth2 import OAuth2Config, OAuth2Server
from .password import PasswordHasher
from .rbac import RBACConfig, RBACManager
from .sso import SSOConfig, SSOManager
from .tokens import TokenBlacklist, TokenManager
from .user import AnonymousUser, User

__all__ = [
    # JWT
    "JWTManager",
    "JWTConfig",
    "JWTPayload",
    # Password
    "PasswordHasher",
    # Tokens
    "TokenManager",
    "TokenBlacklist",
    # User
    "User",
    "AnonymousUser",
    # Backends
    "AuthenticationBackend",
    "JWTAuthenticationBackend",
    # Middleware
    "BearerAuthMiddleware",
    # OAuth2
    "OAuth2Server",
    "OAuth2Config",
    # SSO
    "SSOManager",
    "SSOConfig",
    # RBAC
    "RBACManager",
    "RBACConfig",
]
