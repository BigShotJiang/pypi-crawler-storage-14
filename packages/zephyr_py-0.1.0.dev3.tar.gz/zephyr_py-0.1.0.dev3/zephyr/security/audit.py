"""Audit Logging System for Zephyr applications.

Provides comprehensive audit logging for security-critical events including
authentication attempts, authorization failures, and sensitive operations.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from zephyr.core.logging import get_logger

logger = get_logger(__name__)


class AuditEventType(str, Enum):
    """Types of audit events that can be logged."""

    # Authentication events
    AUTH_LOGIN_SUCCESS = "auth.login.success"
    AUTH_LOGIN_FAILURE = "auth.login.failure"
    AUTH_LOGOUT = "auth.logout"
    AUTH_TOKEN_GENERATED = "auth.token.generated"
    AUTH_TOKEN_REVOKED = "auth.token.revoked"
    AUTH_TOKEN_EXPIRED = "auth.token.expired"
    AUTH_REFRESH_TOKEN_USED = "auth.refresh_token.used"
    AUTH_MFA_ENABLED = "auth.mfa.enabled"
    AUTH_MFA_DISABLED = "auth.mfa.disabled"
    AUTH_MFA_VERIFIED = "auth.mfa.verified"
    AUTH_MFA_FAILED = "auth.mfa.failed"

    # Authorization events
    AUTHZ_PERMISSION_DENIED = "authz.permission.denied"
    AUTHZ_ROLE_DENIED = "authz.role.denied"
    AUTHZ_RBAC_CHECK_FAILED = "authz.rbac.check.failed"

    # User operations
    USER_CREATED = "user.created"
    USER_UPDATED = "user.updated"
    USER_DELETED = "user.deleted"
    USER_PASSWORD_CHANGED = "user.password.changed"
    USER_PASSWORD_RESET = "user.password.reset"
    USER_LOCKED = "user.locked"
    USER_UNLOCKED = "user.unlocked"
    USER_ROLE_ASSIGNED = "user.role.assigned"
    USER_ROLE_REMOVED = "user.role.removed"

    # Admin operations
    ADMIN_OPERATION = "admin.operation"
    ADMIN_CONFIG_CHANGED = "admin.config.changed"

    # Security events
    SECURITY_SUSPICIOUS_ACTIVITY = "security.suspicious_activity"
    SECURITY_RATE_LIMIT_EXCEEDED = "security.rate_limit.exceeded"
    SECURITY_ATTACK_DETECTED = "security.attack.detected"
    SECURITY_PRIVILEGE_ESCALATION = "security.privilege.escalation"

    # API operations
    API_KEY_GENERATED = "api_key.generated"
    API_KEY_REVOKED = "api_key.revoked"
    API_KEY_ROTATED = "api_key.rotated"


@dataclass
class AuditContext:
    """Context information for audit events."""

    event_type: AuditEventType
    timestamp: datetime = field(default_factory=datetime.utcnow)
    user_id: str | None = None
    username: str | None = None
    email: str | None = None
    ip_address: str | None = None
    request_id: str | None = None
    session_id: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    action: str | None = None
    result: str = "success"  # success or failure
    status_code: int | None = None
    error_message: str | None = None
    additional_data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert context to dictionary.

        Returns:
            Dictionary representation of audit context

        """
        return {
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "user_id": self.user_id,
            "username": self.username,
            "email": self.email,
            "ip_address": self.ip_address,
            "request_id": self.request_id,
            "session_id": self.session_id,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "action": self.action,
            "result": self.result,
            "status_code": self.status_code,
            "error_message": self.error_message,
            "additional_data": self.additional_data,
        }


class AuditLogger:
    """Comprehensive audit logging for security-critical events.

    This logger tracks all security-related events including authentication,
    authorization, user operations, and admin actions for compliance and
    security monitoring.

    Configuration (from settings):
        - AUDIT_LOG_ENABLED: Enable/disable audit logging
        - AUDIT_LOG_LEVEL: Logging level (DEBUG, INFO, WARNING, ERROR)
        - AUDIT_LOG_RETENTION_DAYS: How long to retain audit logs
        - AUDIT_LOG_INCLUDE_REQUEST_BODY: Include request body in logs
        - AUDIT_LOG_INCLUDE_RESPONSE_BODY: Include response body in logs
        - AUDIT_LOG_SENSITIVE_FIELDS: Fields to redact from logs
        - AUDIT_LOG_FILE_PATH: Path to audit log file
    """

    def __init__(
        self,
        settings: Any | None = None,
        logger_instance: Any | None = None,
    ) -> None:
        """Initialize the audit logger.

        Args:
            settings: Optional settings object with audit configuration
            logger_instance: Optional logger instance to use

        """
        self.logger = logger_instance or get_logger("zephyr.audit")
        self.settings = settings
        self.enabled = True
        self.log_level = "INFO"
        self.retention_days = 90
        self.include_request_body = False
        self.include_response_body = False
        self.sensitive_fields = ["password", "token", "api_key", "secret", "authorization"]

        if settings:
            self.enabled = getattr(settings, "AUDIT_LOG_ENABLED", True)
            self.log_level = getattr(settings, "AUDIT_LOG_LEVEL", "INFO")
            self.retention_days = getattr(settings, "AUDIT_LOG_RETENTION_DAYS", 90)
            self.include_request_body = getattr(settings, "AUDIT_LOG_INCLUDE_REQUEST_BODY", False)
            self.include_response_body = getattr(settings, "AUDIT_LOG_INCLUDE_RESPONSE_BODY", False)
            self.sensitive_fields = getattr(settings, "AUDIT_LOG_SENSITIVE_FIELDS", self.sensitive_fields)

    def log_auth_attempt(
        self,
        username: str,
        success: bool,
        ip_address: str | None = None,
        request_id: str | None = None,
        error: str | None = None,
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log authentication attempt.

        Args:
            username: Username attempting to authenticate
            success: Whether authentication succeeded
            ip_address: Client IP address
            request_id: Request ID for correlation
            error: Error message if authentication failed
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        event_type = AuditEventType.AUTH_LOGIN_SUCCESS if success else AuditEventType.AUTH_LOGIN_FAILURE

        context = AuditContext(
            event_type=event_type,
            username=username,
            ip_address=ip_address,
            request_id=request_id,
            result="success" if success else "failure",
            error_message=error,
            additional_data=additional_data or {},
        )

        self._log_event(context)

    def log_auth_logout(
        self,
        user_id: str,
        username: str | None = None,
        ip_address: str | None = None,
        request_id: str | None = None,
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log user logout.

        Args:
            user_id: User ID logging out
            username: Username logging out
            ip_address: Client IP address
            request_id: Request ID for correlation
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        context = AuditContext(
            event_type=AuditEventType.AUTH_LOGOUT,
            user_id=user_id,
            username=username,
            ip_address=ip_address,
            request_id=request_id,
            additional_data=additional_data or {},
        )

        self._log_event(context)

    def log_authz_check(
        self,
        user_id: str,
        username: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        action: str | None = None,
        denied: bool = False,
        reason: str | None = None,
        ip_address: str | None = None,
        request_id: str | None = None,
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log authorization check/denial.

        Args:
            user_id: User ID being checked
            username: Username being checked
            resource_type: Type of resource being accessed
            resource_id: ID of resource being accessed
            action: Action being attempted (read, write, delete, etc.)
            denied: Whether the action was denied
            reason: Reason for denial
            ip_address: Client IP address
            request_id: Request ID for correlation
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        event_type = AuditEventType.AUTHZ_PERMISSION_DENIED if denied else AuditEventType.AUTHZ_RBAC_CHECK_FAILED

        context = AuditContext(
            event_type=event_type,
            user_id=user_id,
            username=username,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            result="failure" if denied else "success",
            error_message=reason,
            ip_address=ip_address,
            request_id=request_id,
            additional_data=additional_data or {},
        )

        self._log_event(context)

    def log_sensitive_operation(
        self,
        user_id: str,
        operation: str,
        resource_type: str,
        resource_id: str | None = None,
        username: str | None = None,
        ip_address: str | None = None,
        request_id: str | None = None,
        success: bool = True,
        error: str | None = None,
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log sensitive operations (create, delete, modify, etc.).

        Args:
            user_id: User performing the operation
            operation: Type of operation (create, delete, update, etc.)
            resource_type: Type of resource being modified
            resource_id: ID of resource being modified
            username: Username performing the operation
            ip_address: Client IP address
            request_id: Request ID for correlation
            success: Whether the operation succeeded
            error: Error message if operation failed
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        event_type_map = {
            "create": AuditEventType.USER_CREATED,
            "update": AuditEventType.USER_UPDATED,
            "delete": AuditEventType.USER_DELETED,
            "modify": AuditEventType.USER_UPDATED,
            "reset_password": AuditEventType.USER_PASSWORD_RESET,
            "change_password": AuditEventType.USER_PASSWORD_CHANGED,
        }

        event_type = event_type_map.get(operation, AuditEventType.ADMIN_OPERATION)

        context = AuditContext(
            event_type=event_type,
            user_id=user_id,
            username=username,
            action=operation,
            resource_type=resource_type,
            resource_id=resource_id,
            result="success" if success else "failure",
            error_message=error,
            ip_address=ip_address,
            request_id=request_id,
            additional_data=additional_data or {},
        )

        self._log_event(context)

    def log_privilege_escalation(
        self,
        user_id: str,
        old_role: str | None = None,
        new_role: str | None = None,
        username: str | None = None,
        ip_address: str | None = None,
        request_id: str | None = None,
        reason: str | None = None,
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log suspicious privilege escalation attempts.

        Args:
            user_id: User attempting escalation
            old_role: Previous role
            new_role: New role being granted
            username: Username attempting escalation
            ip_address: Client IP address
            request_id: Request ID for correlation
            reason: Description of escalation attempt
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        data = additional_data or {}
        data["old_role"] = old_role
        data["new_role"] = new_role
        data["reason"] = reason

        context = AuditContext(
            event_type=AuditEventType.SECURITY_PRIVILEGE_ESCALATION,
            user_id=user_id,
            username=username,
            ip_address=ip_address,
            request_id=request_id,
            result="failure",
            error_message=reason,
            additional_data=data,
        )

        self._log_event(context)

    def log_suspicious_activity(
        self,
        activity_type: str,
        description: str,
        user_id: str | None = None,
        username: str | None = None,
        ip_address: str | None = None,
        request_id: str | None = None,
        severity: str = "medium",
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log suspicious security activity.

        Args:
            activity_type: Type of suspicious activity
            description: Description of suspicious activity
            user_id: User ID associated with activity
            username: Username associated with activity
            ip_address: Client IP address
            request_id: Request ID for correlation
            severity: Severity level (low, medium, high, critical)
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        data = additional_data or {}
        data["activity_type"] = activity_type
        data["severity"] = severity

        context = AuditContext(
            event_type=AuditEventType.SECURITY_SUSPICIOUS_ACTIVITY,
            user_id=user_id,
            username=username,
            ip_address=ip_address,
            request_id=request_id,
            result="warning",
            error_message=description,
            additional_data=data,
        )

        self._log_event(context)

    def log_rate_limit_exceeded(
        self,
        identifier: str,
        limit: int,
        window: int,
        ip_address: str | None = None,
        user_id: str | None = None,
        request_id: str | None = None,
        additional_data: dict[str, Any] | None = None,
    ) -> None:
        """Log rate limit exceeded event.

        Args:
            identifier: Identifier that exceeded rate limit (IP, user_id, etc.)
            limit: Rate limit threshold
            window: Time window in seconds
            ip_address: Client IP address
            user_id: User ID if applicable
            request_id: Request ID for correlation
            additional_data: Additional context data

        """
        if not self.enabled:
            return

        data = additional_data or {}
        data["identifier"] = identifier
        data["limit"] = limit
        data["window"] = window

        context = AuditContext(
            event_type=AuditEventType.SECURITY_RATE_LIMIT_EXCEEDED,
            user_id=user_id,
            ip_address=ip_address,
            request_id=request_id,
            result="failure",
            additional_data=data,
        )

        self._log_event(context)

    def _log_event(self, context: AuditContext) -> None:
        """Internal method to log an audit event.

        Args:
            context: Audit context with event details

        """
        try:
            event_data = context.to_dict()
            event_data = self._redact_sensitive_fields(event_data)

            log_message = json.dumps(event_data, default=str)
            self.logger.info(log_message, extra={"audit": True})
        except Exception as e:
            self.logger.error(f"Error logging audit event: {e}", exc_info=True)

    def _redact_sensitive_fields(self, data: dict[str, Any]) -> dict[str, Any]:
        """Redact sensitive fields from log data.

        Args:
            data: Data dictionary to redact

        Returns:
            Dictionary with sensitive fields redacted

        """
        sensitive_data = data.copy()

        def redact_dict(obj: Any) -> Any:
            """Recursively redact sensitive fields in a dictionary."""
            if isinstance(obj, dict):
                return {
                    k: "***REDACTED***" if k.lower() in self.sensitive_fields else redact_dict(v)
                    for k, v in obj.items()
                }
            if isinstance(obj, (list, tuple)):
                return [redact_dict(item) for item in obj]
            return obj

        return redact_dict(sensitive_data)


# Global audit logger instance
_audit_logger: AuditLogger | None = None


def get_audit_logger(settings: Any | None = None) -> AuditLogger:
    """Get or create the global audit logger instance.

    Args:
        settings: Optional settings object for configuration

    Returns:
        The audit logger instance

    """
    global _audit_logger

    if _audit_logger is None or settings is not None:
        _audit_logger = AuditLogger(settings)

    return _audit_logger
