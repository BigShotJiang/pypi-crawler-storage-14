"""Session Management for Zephyr.

Provides comprehensive session management with multiple backends including
Redis, Memory, Database, and File-based storage.
"""

from .backends import (
    DatabaseSessionBackend,
    FileSessionBackend,
    MemorySessionBackend,
    RedisSessionBackend,
    SessionBackend,
)
from .config import SessionConfig
from .exceptions import (
    SessionBackendError,
    SessionError,
    SessionExpiredError,
    SessionNotFoundError,
    SessionSerializationError,
    SessionStorageError,
    SessionValidationError,
)
from .manager import SessionManager
from .middleware import SessionMiddleware
from .models import Session, SessionData, SessionInfo, SessionStats

__all__ = [
    # Backends
    "SessionBackend",
    "MemorySessionBackend",
    "RedisSessionBackend",
    "DatabaseSessionBackend",
    "FileSessionBackend",
    # Configuration
    "SessionConfig",
    # Models
    "Session",
    "SessionData",
    "SessionInfo",
    "SessionStats",
    # Exceptions
    "SessionError",
    "SessionNotFoundError",
    "SessionExpiredError",
    "SessionBackendError",
    "SessionSerializationError",
    "SessionValidationError",
    "SessionStorageError",
    # Manager
    "SessionManager",
    # Middleware
    "SessionMiddleware",
]
