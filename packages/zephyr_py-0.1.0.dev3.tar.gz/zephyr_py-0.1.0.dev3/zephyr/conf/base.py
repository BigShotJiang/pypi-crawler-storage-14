"""Base settings class for Zephyr applications."""

from pydantic import Field
from pydantic_settings import BaseSettings as PydanticBaseSettings


class BaseSettings(PydanticBaseSettings):
    """Base settings for Zephyr applications.

    Users inherit from this in their settings.py file (Django-style).

    Example:
        # myproject/settings.py
        from zephyr.conf import BaseSettings

        class Settings(BaseSettings):
            DEBUG = True
            SECRET_KEY = "my-secret"
            ENABLE_CORS = True

    """

    # Core Application
    DEBUG: bool = False
    SECRET_KEY: str = Field(default="change-me-in-production")

    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 1

    # Application Metadata
    APP_NAME: str = "Zephyr"
    VERSION: str = "1.0.0"
    DESCRIPTION: str | None = None

    # Feature Flags
    ENABLE_HEALTH_CHECKS: bool = True
    ENABLE_METRICS: bool = True
    ENABLE_TRACING: bool = True
    ENABLE_COMPRESSION: bool = True
    ENABLE_CACHING: bool = True
    ENABLE_CORS: bool = True
    ENABLE_RATE_LIMITING: bool = True
    ENABLE_AUTO_DOCS: bool = True
    ENABLE_REQUEST_ID: bool = True
    ENABLE_ERROR_DETAILS: bool = True

    # CORS Configuration
    CORS_ORIGINS: list[str] = []
    CORS_ALLOW_CREDENTIALS: bool = False
    CORS_ALLOW_METHODS: list[str] = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    CORS_ALLOW_HEADERS: list[str] = ["*"]
    CORS_MAX_AGE: int = 600

    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = 1000
    RATE_LIMIT_WINDOW: int = 60
    RATE_LIMIT_STORAGE: str = "memory"  # memory or redis
    RATE_LIMIT_BACKEND: str = "token_bucket"  # token_bucket or sliding_window
    RATE_LIMIT_REDIS_URL: str | None = None
    RATE_LIMIT_KEY_PREFIX: str = "zephyr:rate_limit:"
    RATE_LIMIT_ENABLE_METRICS: bool = True
    RATE_LIMIT_ENABLE_PER_IP: bool = True
    RATE_LIMIT_ENABLE_PER_USER: bool = True

    # Database
    DATABASE_URL: str | None = None
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10

    # Redis
    REDIS_URL: str | None = None
    REDIS_POOL_SIZE: int = 10

    # Logging - Core
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"  # json, console, or colored

    # Logging - Console Handler
    LOG_CONSOLE_ENABLED: bool = True
    LOG_CONSOLE_COLORED: bool = True
    LOG_CONSOLE_LEVEL: str | None = None  # Defaults to LOG_LEVEL

    # Logging - File Handler
    LOG_FILE_ENABLED: bool = False
    LOG_FILE_PATH: str = "/var/log/zephyr/app.log"
    LOG_FILE_LEVEL: str | None = None
    LOG_FILE_MAX_BYTES: int = 10485760  # 10MB
    LOG_FILE_BACKUP_COUNT: int = 5
    LOG_FILE_ROTATION: str = "size"  # size, time, or both

    # Logging - Loki Handler
    LOG_LOKI_ENABLED: bool = False
    LOG_LOKI_URL: str | None = None
    LOG_LOKI_LABELS: dict[str, str] = Field(default_factory=dict)
    LOG_LOKI_LEVEL: str | None = None

    # Logging - HTTP Handler
    LOG_HTTP_ENABLED: bool = False
    LOG_HTTP_URL: str | None = None
    LOG_HTTP_METHOD: str = "POST"
    LOG_HTTP_HEADERS: dict[str, str] = Field(default_factory=dict)
    LOG_HTTP_LEVEL: str | None = None

    # Logging - Syslog Handler
    LOG_SYSLOG_ENABLED: bool = False
    LOG_SYSLOG_HOST: str = "localhost"
    LOG_SYSLOG_PORT: int = 514
    LOG_SYSLOG_FACILITY: str = "user"
    LOG_SYSLOG_LEVEL: str | None = None

    # Caching
    CACHE_BACKEND: str = "memory"  # memory, redis, memcached, or multi-level
    CACHE_DEFAULT_TTL: int = 300
    CACHE_REDIS_URL: str | None = None
    CACHE_MEMCACHED_URL: str | None = None
    CACHE_MEMORY_MAX_SIZE: int = 10000
    CACHE_ENABLE_COMPRESSION: bool = True
    CACHE_ENABLE_METRICS: bool = True
    CACHE_KEY_PREFIX: str = "zephyr:cache:"

    # Authentication
    AUTH_BACKEND: str = "zephyr.security.backends.JWTAuthenticationBackend"
    AUTH_USER_MODEL: str | None = None
    AUTH_LOGIN_URL: str = "/auth/login"
    AUTH_LOGOUT_URL: str = "/auth/logout"
    AUTH_RATE_LIMIT: int = 5  # attempts per minute

    # JWT
    JWT_SECRET_KEY: str = Field(default="change-me-in-production")
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    JWT_ISSUER: str | None = None
    JWT_AUDIENCE: str | None = None

    # OAuth2
    OAUTH2_ENABLED: bool = False
    OAUTH2_AUTHORIZATION_CODE_EXPIRE_MINUTES: int = 10
    OAUTH2_PKCE_REQUIRED: bool = True

    # Keycloak
    KEYCLOAK_ENABLED: bool = False
    KEYCLOAK_SERVER_URL: str | None = None
    KEYCLOAK_REALM: str | None = None
    KEYCLOAK_CLIENT_ID: str | None = None
    KEYCLOAK_CLIENT_SECRET: str | None = None

    # SSO
    SSO_GOOGLE_CLIENT_ID: str | None = None
    SSO_GOOGLE_CLIENT_SECRET: str | None = None
    SSO_GITHUB_CLIENT_ID: str | None = None
    SSO_GITHUB_CLIENT_SECRET: str | None = None

    # WebAuthn
    WEBAUTHN_ENABLED: bool = False
    WEBAUTHN_RP_ID: str | None = None
    WEBAUTHN_RP_NAME: str = "Zephyr App"
    WEBAUTHN_ORIGIN: str | None = None

    # MFA
    MFA_ENABLED: bool = False
    MFA_REQUIRED_FOR_ADMIN: bool = True
    MFA_TOTP_ISSUER: str = "Zephyr"
    MFA_BACKUP_CODES_COUNT: int = 10

    # LDAP
    LDAP_ENABLED: bool = False
    LDAP_SERVER_URI: str | None = None
    LDAP_BIND_DN: str | None = None
    LDAP_BIND_PASSWORD: str | None = None
    LDAP_USER_SEARCH_BASE: str | None = None

    # RBAC
    RBAC_ENABLED: bool = True
    RBAC_DEFAULT_ROLE: str = "user"

    # Sessions
    SESSION_BACKEND: str = "memory"
    SESSION_COOKIE_NAME: str = "sessionid"
    SESSION_COOKIE_SECURE: bool = True
    SESSION_COOKIE_HTTPONLY: bool = True
    SESSION_COOKIE_SAMESITE: str = "lax"
    SESSION_EXPIRE_SECONDS: int = 1209600  # 2 weeks

    # Password Hashing
    PASSWORD_BCRYPT_ROUNDS: int = 12

    # Token Management
    TOKEN_BLACKLIST_MAX_SIZE: int = 10000

    # OAuth2 - Additional endpoints
    OAUTH2_AUTHORIZATION_ENDPOINT: str = "/oauth2/authorize"
    OAUTH2_TOKEN_ENDPOINT: str = "/oauth2/token"
    OAUTH2_REVOKE_ENDPOINT: str = "/oauth2/revoke"

    # SSO Providers - Additional
    SSO_AZURE_TENANT_ID: str | None = None
    SSO_AZURE_CLIENT_ID: str | None = None
    SSO_AZURE_CLIENT_SECRET: str | None = None

    # Keycloak - Additional
    KEYCLOAK_ADMIN_USERNAME: str | None = None
    KEYCLOAK_ADMIN_PASSWORD: str | None = None

    # WebAuthn - Additional
    WEBAUTHN_RP_NAME: str = "Zephyr"

    # MFA - Additional
    MFA_TOTP_ISSUER: str = "Zephyr"
    MFA_SMS_PROVIDER: str | None = None
    MFA_EMAIL_PROVIDER: str | None = None

    # User Federation
    FEDERATION_ENABLED: bool = False
    LDAP_SERVER: str | None = None
    LDAP_PORT: int = 389
    LDAP_USE_SSL: bool = False
    LDAP_USER_SEARCH_FILTER: str = "(uid={username})"
    LDAP_GROUP_SEARCH_BASE: str | None = None
    LDAP_GROUP_SEARCH_FILTER: str = "(member={user_dn})"

    # UMA
    UMA_ENABLED: bool = False
    UMA_RESOURCE_SERVER: str | None = None
    UMA_AUTHORIZATION_SERVER: str | None = None

    # ============================================================================
    # PHASE 1: SECURITY HARDENING
    # ============================================================================

    # CSRF Protection
    CSRF_ENABLED: bool = True
    CSRF_TRUSTED_ORIGINS: list[str] = Field(default_factory=list)
    CSRF_TOKEN_LENGTH: int = 32
    CSRF_COOKIE_SECURE: bool = True
    CSRF_COOKIE_HTTPONLY: bool = True
    CSRF_COOKIE_SAMESITE: str = "Lax"
    CSRF_COOKIE_NAME: str = "csrf_token"
    CSRF_HEADER_NAME: str = "X-CSRF-Token"
    CSRF_FORM_FIELD_NAME: str = "_csrf_token"

    # Security Headers
    SECURITY_HEADERS_ENABLED: bool = True
    SECURITY_CSP_POLICY: str = (
        "default-src 'self'; script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;"
    )
    SECURITY_FRAME_OPTIONS: str = "DENY"
    SECURITY_CONTENT_TYPE_OPTIONS: str = "nosniff"
    SECURITY_HSTS_MAX_AGE: int = 31536000  # 1 year
    SECURITY_HSTS_INCLUDE_SUBDOMAINS: bool = True
    SECURITY_HSTS_PRELOAD: bool = False
    SECURITY_REFERRER_POLICY: str = "strict-origin-when-cross-origin"
    SECURITY_PERMISSIONS_POLICY: str = "geolocation=(), microphone=(), camera=(), payment=(), usb=()"

    # Audit Logging
    AUDIT_LOG_ENABLED: bool = True
    AUDIT_LOG_LEVEL: str = "INFO"
    AUDIT_LOG_RETENTION_DAYS: int = 90
    AUDIT_LOG_INCLUDE_REQUEST_BODY: bool = False
    AUDIT_LOG_INCLUDE_RESPONSE_BODY: bool = False
    AUDIT_LOG_SENSITIVE_FIELDS: list[str] = Field(
        default_factory=lambda: ["password", "token", "api_key", "secret", "authorization"]
    )
    AUDIT_LOG_FILE_PATH: str = "/var/log/zephyr/audit.log"
    AUDIT_LOG_FILE_ENABLED: bool = False

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
