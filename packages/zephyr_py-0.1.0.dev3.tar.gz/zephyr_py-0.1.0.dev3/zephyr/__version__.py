from importlib.metadata import version

zephyr_version = version("zephyr-py")
__version__ = zephyr_version

__all__ = ["__version__", "zephyr_version"]
