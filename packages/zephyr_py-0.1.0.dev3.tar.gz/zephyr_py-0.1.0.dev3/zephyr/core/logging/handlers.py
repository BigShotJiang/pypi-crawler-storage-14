"""Custom Handler Implementations

SOLID Principle: Single Responsibility
Each handler has ONE responsibility - emit logs to its destination.
Handler creation is delegated to factory.py
"""

from __future__ import annotations

import logging
import logging.handlers
from typing import Any

import orjson

from .types import HTTPHandlerConfig, SyslogHandlerConfig
from .utils import get_log_level


class HTTPHandler(logging.Handler):
    """Handler for sending logs to HTTP endpoint."""

    def __init__(self, config: HTTPHandlerConfig) -> None:
        """Initialize HTTP handler.

        Args:
            config: HTTP handler configuration

        """
        super().__init__()
        self.config = config

        if not config.url:
            raise ValueError("HTTP URL is required")

        if config.level:
            self.setLevel(get_log_level(config.level))

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record to HTTP endpoint.

        Args:
            record: Log record to emit

        """
        try:
            import urllib.request

            log_entry = self.format_log_entry(record)

            data = orjson.dumps(log_entry)

            req = urllib.request.Request(
                self.config.url,  # type: ignore[arg-type]
                data=data,
                headers={
                    "Content-Type": "application/json",
                    **self.config.headers,
                },
                method=self.config.method,
            )

            urllib.request.urlopen(req, timeout=self.config.timeout)

        except Exception:
            self.handleError(record)

    def format_log_entry(self, record: logging.LogRecord) -> dict[str, Any]:
        """Format log record as dictionary.

        Args:
            record: Log record

        Returns:
            Dictionary representation

        """
        return {
            "timestamp": record.created,
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "process": record.process,
            "thread": record.thread,
            "extra": getattr(record, "__dict__", {}),
        }


class EnhancedSyslogHandler(logging.handlers.SysLogHandler):
    """Enhanced syslog handler with facility mapping."""

    FACILITY_MAP = {
        "kern": logging.handlers.SysLogHandler.LOG_KERN,
        "user": logging.handlers.SysLogHandler.LOG_USER,
        "mail": logging.handlers.SysLogHandler.LOG_MAIL,
        "daemon": logging.handlers.SysLogHandler.LOG_DAEMON,
        "auth": logging.handlers.SysLogHandler.LOG_AUTH,
        "syslog": logging.handlers.SysLogHandler.LOG_SYSLOG,
        "lpr": logging.handlers.SysLogHandler.LOG_LPR,
        "news": logging.handlers.SysLogHandler.LOG_NEWS,
        "uucp": logging.handlers.SysLogHandler.LOG_UUCP,
        "cron": logging.handlers.SysLogHandler.LOG_CRON,
        "authpriv": logging.handlers.SysLogHandler.LOG_AUTHPRIV,
        "local0": logging.handlers.SysLogHandler.LOG_LOCAL0,
        "local1": logging.handlers.SysLogHandler.LOG_LOCAL1,
        "local2": logging.handlers.SysLogHandler.LOG_LOCAL2,
        "local3": logging.handlers.SysLogHandler.LOG_LOCAL3,
        "local4": logging.handlers.SysLogHandler.LOG_LOCAL4,
        "local5": logging.handlers.SysLogHandler.LOG_LOCAL5,
        "local6": logging.handlers.SysLogHandler.LOG_LOCAL6,
        "local7": logging.handlers.SysLogHandler.LOG_LOCAL7,
    }

    def __init__(self, config: SyslogHandlerConfig) -> None:
        """Initialize syslog handler.

        Args:
            config: Syslog handler configuration

        """
        facility = self.FACILITY_MAP.get(config.facility.value, logging.handlers.SysLogHandler.LOG_USER)

        super().__init__(
            address=(config.host, config.port),
            facility=facility,
        )

        formatter = logging.Formatter(
            fmt="%(name)s[%(process)d]: %(levelname)s - %(message)s",
        )
        self.setFormatter(formatter)

        if config.level:
            self.setLevel(get_log_level(config.level))
