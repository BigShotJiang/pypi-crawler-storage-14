"""Utility functions for the logging module."""

from __future__ import annotations

import logging
import random
import sys
from typing import Any

from .constants import LOG_LEVELS


def get_log_level(level: str | int | None) -> int:
    """Convert log level string or int to logging level constant.

    Args:
        level: Log level as string, int, or None

    Returns:
        Logging level constant

    """
    if level is None:
        return logging.INFO

    if isinstance(level, int):
        return level

    level_str = level.upper()
    return LOG_LEVELS.get(level_str.lower(), logging.INFO)


def should_sample_log(sample_rate: float) -> bool:
    """Determine if a log should be sampled based on rate.

    Args:
        sample_rate: Sampling rate between 0.0 and 1.0

    Returns:
        True if log should be emitted

    """
    if sample_rate >= 1.0:
        return True
    if sample_rate <= 0.0:
        return False
    return random.random() < sample_rate


def is_tty() -> bool:
    """Check if stdout is a TTY."""
    return sys.stdout.isatty()


def sanitize_log_data(data: dict[str, Any], sensitive_keys: set[str] | None = None) -> dict[str, Any]:
    """Sanitize sensitive data from log dictionary.

    Args:
        data: Dictionary to sanitize
        sensitive_keys: Set of keys to redact

    Returns:
        Sanitized dictionary

    """
    if sensitive_keys is None:
        sensitive_keys = {
            "password",
            "secret",
            "token",
            "api_key",
            "apikey",
            "auth",
            "authorization",
            "credential",
            "credentials",
            "private_key",
            "access_token",
            "refresh_token",
        }

    sanitized = {}
    for key, value in data.items():
        key_lower = key.lower()
        if any(sensitive in key_lower for sensitive in sensitive_keys):
            sanitized[key] = "***REDACTED***"
        elif isinstance(value, dict):
            sanitized[key] = sanitize_log_data(value, sensitive_keys)
        elif isinstance(value, list):
            sanitized[key] = [
                sanitize_log_data(item, sensitive_keys) if isinstance(item, dict) else item for item in value
            ]
        else:
            sanitized[key] = value

    return sanitized


def format_exception_info(exc_info: tuple[type, Exception, Any] | None = None) -> dict[str, Any]:
    """Format exception info for structured logging.

    Args:
        exc_info: Exception info tuple

    Returns:
        Dictionary with exception details

    """
    if exc_info is None:
        return {}

    exc_type, exc_value, exc_tb = exc_info

    return {
        "exception_type": exc_type.__name__ if exc_type else None,
        "exception_message": str(exc_value) if exc_value else None,
        "exception_module": exc_type.__module__ if exc_type else None,
    }


def truncate_string(value: str, max_length: int = 1000) -> str:
    """Truncate string to maximum length.

    Args:
        value: String to truncate
        max_length: Maximum length

    Returns:
        Truncated string

    """
    if len(value) <= max_length:
        return value
    return value[: max_length - 3] + "..."


def validate_log_level(level: str) -> bool:
    """Validate if a log level string is valid.

    Args:
        level: Log level string

    Returns:
        True if valid

    """
    return level.lower() in LOG_LEVELS
