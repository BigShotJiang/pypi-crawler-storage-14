"""Type definitions for the logging module."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class LogLevel(str, Enum):
    """Log level enumeration."""

    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class LogFormat(str, Enum):
    """Log format enumeration."""

    JSON = "json"
    CONSOLE = "console"
    COLORED = "colored"


class RotationType(str, Enum):
    """File rotation type enumeration."""

    SIZE = "size"
    TIME = "time"
    BOTH = "both"


class SyslogFacility(str, Enum):
    """Syslog facility enumeration."""

    KERN = "kern"
    USER = "user"
    MAIL = "mail"
    DAEMON = "daemon"
    AUTH = "auth"
    SYSLOG = "syslog"
    LPR = "lpr"
    NEWS = "news"
    UUCP = "uucp"
    CRON = "cron"
    AUTHPRIV = "authpriv"
    LOCAL0 = "local0"
    LOCAL1 = "local1"
    LOCAL2 = "local2"
    LOCAL3 = "local3"
    LOCAL4 = "local4"
    LOCAL5 = "local5"
    LOCAL6 = "local6"
    LOCAL7 = "local7"


class ConsoleHandlerConfig(BaseModel):
    """Console handler configuration."""

    enabled: bool = True
    colored: bool = True
    level: str | None = None


class FileHandlerConfig(BaseModel):
    """File handler configuration."""

    enabled: bool = False
    path: str = "/var/log/zephyr/app.log"
    level: str | None = None
    max_bytes: int = 10485760  # 10MB
    backup_count: int = 5
    rotation: RotationType = RotationType.SIZE


class LokiHandlerConfig(BaseModel):
    """Loki handler configuration."""

    enabled: bool = False
    url: str | None = None
    labels: dict[str, str] = Field(default_factory=dict)
    level: str | None = None
    auth: tuple[str, str] | None = None  # (username, password)
    timeout: int = 10


class HTTPHandlerConfig(BaseModel):
    """HTTP handler configuration."""

    enabled: bool = False
    url: str | None = None
    method: str = "POST"
    headers: dict[str, str] = Field(default_factory=dict)
    level: str | None = None
    timeout: int = 10


class SyslogHandlerConfig(BaseModel):
    """Syslog handler configuration."""

    enabled: bool = False
    host: str = "localhost"
    port: int = 514
    facility: SyslogFacility = SyslogFacility.USER
    level: str | None = None


class LoggingConfig(BaseModel):
    """Complete logging configuration."""

    level: LogLevel = LogLevel.INFO
    format: LogFormat = LogFormat.JSON
    console: ConsoleHandlerConfig = Field(default_factory=ConsoleHandlerConfig)
    file: FileHandlerConfig = Field(default_factory=FileHandlerConfig)
    loki: LokiHandlerConfig = Field(default_factory=LokiHandlerConfig)
    http: HTTPHandlerConfig = Field(default_factory=HTTPHandlerConfig)
    syslog: SyslogHandlerConfig = Field(default_factory=SyslogHandlerConfig)

    @classmethod
    def from_settings(cls, settings: Any) -> LoggingConfig:
        """Create logging config from BaseSettings instance."""
        return cls(
            level=LogLevel(settings.LOG_LEVEL.upper()),
            format=LogFormat(settings.LOG_FORMAT.lower()),
            console=ConsoleHandlerConfig(
                enabled=settings.LOG_CONSOLE_ENABLED,
                colored=settings.LOG_CONSOLE_COLORED,
                level=settings.LOG_CONSOLE_LEVEL,
            ),
            file=FileHandlerConfig(
                enabled=settings.LOG_FILE_ENABLED,
                path=settings.LOG_FILE_PATH,
                level=settings.LOG_FILE_LEVEL,
                max_bytes=settings.LOG_FILE_MAX_BYTES,
                backup_count=settings.LOG_FILE_BACKUP_COUNT,
                rotation=RotationType(settings.LOG_FILE_ROTATION.lower()),
            ),
            loki=LokiHandlerConfig(
                enabled=settings.LOG_LOKI_ENABLED,
                url=settings.LOG_LOKI_URL,
                labels=settings.LOG_LOKI_LABELS,
                level=settings.LOG_LOKI_LEVEL,
            ),
            http=HTTPHandlerConfig(
                enabled=settings.LOG_HTTP_ENABLED,
                url=settings.LOG_HTTP_URL,
                method=settings.LOG_HTTP_METHOD,
                headers=settings.LOG_HTTP_HEADERS,
                level=settings.LOG_HTTP_LEVEL,
            ),
            syslog=SyslogHandlerConfig(
                enabled=settings.LOG_SYSLOG_ENABLED,
                host=settings.LOG_SYSLOG_HOST,
                port=settings.LOG_SYSLOG_PORT,
                facility=SyslogFacility(settings.LOG_SYSLOG_FACILITY.lower()),
                level=settings.LOG_SYSLOG_LEVEL,
            ),
        )
