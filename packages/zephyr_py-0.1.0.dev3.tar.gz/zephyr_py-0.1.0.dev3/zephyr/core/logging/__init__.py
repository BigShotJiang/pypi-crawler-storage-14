"""Zephyr Logging Module

A comprehensive logging system with multiple handlers, structured logging,
and context management.

Architecture (SOLID Principles):
- config.py: SINGLE SOURCE OF TRUTH - reads BaseSettings, creates LoggingConfig
- factory.py: Creates handlers (Open/Closed - easy to add new handlers)
- manager.py: Manages handler lifecycle
- logger.py: Provides logging interface
- types.py: Type definitions
- formatter.py: Formatters
- handlers.py: Custom handler implementations
- utils.py: Helper utilities
"""

from .config import LoggingConfigBuilder, get_logging_config, reset_logging_config
from .constants import *
from .formatter import *
from .logger import Logger, get_logger, logger
from .manager import HandlerManager, get_handler_manager
from .types import (
    ConsoleHandlerConfig,
    FileHandlerConfig,
    HTTPHandlerConfig,
    LogFormat,
    LoggingConfig,
    LogLevel,
    LokiHandlerConfig,
    SyslogHandlerConfig,
)
from .utils import (
    format_exception_info,
    get_log_level,
    sanitize_log_data,
    should_sample_log,
)

__all__ = [
    # Core logger
    "Logger",
    "logger",
    "get_logger",
    # Configuration (SINGLE SOURCE OF TRUTH)
    "get_logging_config",
    "reset_logging_config",
    "LoggingConfigBuilder",
    # Types
    "LoggingConfig",
    "LogLevel",
    "LogFormat",
    "ConsoleHandlerConfig",
    "FileHandlerConfig",
    "LokiHandlerConfig",
    "HTTPHandlerConfig",
    "SyslogHandlerConfig",
    # Manager
    "HandlerManager",
    "get_handler_manager",
    # Utils
    "get_log_level",
    "should_sample_log",
    "sanitize_log_data",
    "format_exception_info",
]


def _initialize_logging() -> None:
    """Initialize logging system on module import."""
    from .config import get_logging_config
    from .manager import get_handler_manager

    # Get configuration from settings (SINGLE SOURCE OF TRUTH)
    config = get_logging_config()

    # Configure handlers via manager
    manager = get_handler_manager()
    manager.configure(config)


# Auto-initialize logging on module import
_initialize_logging()
