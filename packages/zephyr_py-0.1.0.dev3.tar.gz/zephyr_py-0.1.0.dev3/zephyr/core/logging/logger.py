"""Logger Implementation - Responsible ONLY for logging interface

SOLID Principle: Single Responsibility
Logger provides logging interface with context management.
Configuration is handled by config.py
Handler creation is handled by factory.py
Handler lifecycle is handled by manager.py
"""

from __future__ import annotations

import contextvars
import logging
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from functools import wraps
from typing import Any, TypeVar

from .constants import CONTEXT_CORRELATION_ID, CONTEXT_REQUEST_ID, TRACE_LOG_LEVEL

# Type variable for decorators
F = TypeVar("F", bound=Callable[..., Any])

# Global context storage using contextvars (works across async/await)
_log_context: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar("log_context", default={})


class Logger:
    """Enhanced logger wrapper with structured logging and context management using contextvars."""

    def __init__(self, name: str) -> None:
        """Initialize logger wrapper.

        Args:
            name: Logger name

        """
        self._logger = logging.getLogger(name)
        self.name = name

    def __str__(self) -> str:
        """String representation."""
        return f"<ZEPHYRLogger name={self.name}>"

    def __repr__(self) -> str:
        """String representation."""
        return f"<ZEPHYRLogger(name='{self.name}')>"

    def __getattr__(self, name: str) -> Any:
        """Delegate unknown attributes to wrapped logger."""
        return getattr(self._logger, name)

    def _log(self, level: int, msg: str, args: tuple[Any, ...], **kwargs: Any) -> None:
        """Internal log method that injects context and delegates to logger.log().

        Args:
            level: Log level
            msg: Log message (supports % formatting)
            args: Positional arguments for % formatting
            **kwargs: Additional keyword arguments (passed as extra)

        """
        # Get context from contextvars
        ctx = _log_context.get()

        # Extract standard logging kwargs
        exc_info = kwargs.pop("exc_info", None)
        stack_info = kwargs.pop("stack_info", False)
        stacklevel = kwargs.pop("stacklevel", 1)
        extra = kwargs.pop("extra", {})

        # Merge context and remaining kwargs into extra
        extra.update(ctx)
        extra.update(kwargs)  # All remaining kwargs go to extra

        # Delegate to wrapped logger.log() - it handles isEnabledFor() check
        self._logger.log(
            level, msg, *args, exc_info=exc_info, stack_info=stack_info, stacklevel=stacklevel + 1, extra=extra
        )

    def trace(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a trace message."""
        self._log(TRACE_LOG_LEVEL, msg, args, **kwargs)

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a debug message."""
        self._log(logging.DEBUG, msg, args, **kwargs)

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an info message."""
        self._log(logging.INFO, msg, args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a warning message."""
        self._log(logging.WARNING, msg, args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an error message."""
        self._log(logging.ERROR, msg, args, **kwargs)

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a critical message."""
        self._log(logging.CRITICAL, msg, args, **kwargs)

    def bind(self, **kwargs: Any) -> Logger:
        """Bind context variables using contextvars (works across async/await).

        Args:
            **kwargs: Context variables

        Returns:
            Logger instance

        """
        current = _log_context.get().copy()
        current.update(kwargs)
        _log_context.set(current)
        return self

    def unbind(self, *keys: str) -> Logger:
        """Unbind context variables from contextvars.

        Args:
            *keys: Context keys to unbind

        Returns:
            Logger instance

        """
        current = _log_context.get().copy()
        for key in keys:
            current.pop(key, None)
        _log_context.set(current)
        return self

    @contextmanager
    def correlation_id(self, correlation_id: str) -> Iterator[Logger]:
        """Context manager for correlation ID.

        Args:
            correlation_id: Correlation ID

        Yields:
            Logger with correlation ID

        """
        token = _log_context.set({**_log_context.get(), CONTEXT_CORRELATION_ID: correlation_id})
        try:
            yield self
        finally:
            _log_context.reset(token)

    @contextmanager
    def request_id(self, request_id: str) -> Iterator[Logger]:
        """Context manager for request ID.

        Args:
            request_id: Request ID

        Yields:
            Logger with request ID

        """
        token = _log_context.set({**_log_context.get(), CONTEXT_REQUEST_ID: request_id})
        try:
            yield self
        finally:
            _log_context.reset(token)

    @contextmanager
    def context(self, **kwargs: Any) -> Iterator[Logger]:
        """Context manager for arbitrary context.

        Args:
            **kwargs: Context variables

        Yields:
            Logger with context

        """
        token = _log_context.set({**_log_context.get(), **kwargs})
        try:
            yield self
        finally:
            _log_context.reset(token)

    def time_execution(self, func: F | None = None, level: int = logging.INFO) -> F | Callable[[F], F]:
        """Decorator to time function execution.

        Args:
            func: Function to decorate
            level: Log level for timing message

        Returns:
            Decorated function

        """

        def decorator(f: F) -> F:
            @wraps(f)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                start_time = time.time()
                try:
                    result = f(*args, **kwargs)
                    return result
                finally:
                    elapsed = time.time() - start_time
                    self._log(
                        level,
                        f"Function {f.__name__} took {elapsed:.4f}s",
                        (),
                        function=f.__name__,
                        elapsed_seconds=elapsed,
                    )

            return wrapper  # type: ignore[return-value]

        if func is None:
            return decorator  # type: ignore[return-value]
        return decorator(func)


# Cache for logger instances
_logger_cache: dict[str, Logger] = {}


def get_logger(name: str) -> Logger:
    """Get a logger instance (cached).

    Args:
        name: Logger name

    Returns:
        Logger instance

    """
    if name not in _logger_cache:
        _logger_cache[name] = Logger(name)
    return _logger_cache[name]


# Module logger
logger: Logger = get_logger(__name__)
