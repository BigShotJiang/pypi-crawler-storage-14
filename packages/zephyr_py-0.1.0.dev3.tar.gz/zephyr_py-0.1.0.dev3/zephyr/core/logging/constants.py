import logging

TRACE_LOG_LEVEL = 5

LOG_LEVELS: dict[str, int] = {
    "critical": logging.CRITICAL,
    "error": logging.ERROR,
    "warning": logging.WARNING,
    "info": logging.INFO,
    "debug": logging.DEBUG,
    "trace": TRACE_LOG_LEVEL,
}

# Handler types
HANDLER_CONSOLE = "console"
HANDLER_FILE = "file"
HANDLER_LOKI = "loki"
HANDLER_HTTP = "http"
HANDLER_SYSLOG = "syslog"

# Context keys for structured logging
CONTEXT_REQUEST_ID = "request_id"
CONTEXT_CORRELATION_ID = "correlation_id"
CONTEXT_USER_ID = "user_id"
CONTEXT_SESSION_ID = "session_id"
CONTEXT_TRACE_ID = "trace_id"
CONTEXT_SPAN_ID = "span_id"

# Default format strings
DEFAULT_CONSOLE_FORMAT = "%(levelprefix)s %(message)s"
DEFAULT_FILE_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
DEFAULT_JSON_FORMAT = "json"
