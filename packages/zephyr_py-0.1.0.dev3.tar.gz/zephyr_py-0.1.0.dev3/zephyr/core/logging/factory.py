"""Handler Factory - Responsible ONLY for creating handlers

SOLID Principle: Open/Closed Principle
- Factory handles handler creation
- Easy to add new handler types without modifying manager or logger
- Depends on handler abstractions, not manager
"""

from __future__ import annotations

import logging
import logging.handlers
import sys

from logging_loki import LokiHandler as BaseLokiHandler

from .formatter import ColourizedFormatter, JSONFormatter
from .types import (
    ConsoleHandlerConfig,
    FileHandlerConfig,
    HTTPHandlerConfig,
    LokiHandlerConfig,
    SyslogHandlerConfig,
)
from .utils import get_log_level


class HandlerFactory:
    """Factory for creating logging handlers."""

    @staticmethod
    def create_console_handler(config: ConsoleHandlerConfig) -> logging.Handler:
        """Create console handler.

        Args:
            config: Console handler configuration

        Returns:
            Configured console handler

        """
        handler = logging.StreamHandler(sys.stderr)

        if config.colored:
            formatter = ColourizedFormatter(
                fmt="%(levelprefix)s %(message)s",
                use_colors=True,
            )
        else:
            formatter = logging.Formatter(
                fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            )

        handler.setFormatter(formatter)

        if config.level:
            handler.setLevel(get_log_level(config.level))

        return handler

    @staticmethod
    def create_file_handler(config: FileHandlerConfig) -> logging.Handler:
        """Create file handler with rotation.

        Args:
            config: File handler configuration

        Returns:
            Configured file handler

        """
        handler = logging.handlers.RotatingFileHandler(
            filename=config.path,
            maxBytes=config.max_bytes,
            backupCount=config.backup_count,
            encoding="utf-8",
        )

        formatter = logging.Formatter(
            fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)

        if config.level:
            handler.setLevel(get_log_level(config.level))

        return handler

    @staticmethod
    def create_loki_handler(config: LokiHandlerConfig) -> logging.Handler:
        """Create Loki handler.

        Args:
            config: Loki handler configuration

        Returns:
            Configured Loki handler

        """
        if not config.url:
            raise ValueError("Loki URL is required")

        handler = BaseLokiHandler(
            url=config.url,
            tags=config.labels,
            version="1",
        )

        if config.level:
            handler.setLevel(get_log_level(config.level))

        return handler

    @staticmethod
    def create_http_handler(config: HTTPHandlerConfig) -> logging.Handler:
        """Create HTTP handler.

        Args:
            config: HTTP handler configuration

        Returns:
            Configured HTTP handler

        """
        from .handlers import HTTPHandler

        handler = HTTPHandler(config)
        return handler

    @staticmethod
    def create_syslog_handler(config: SyslogHandlerConfig) -> logging.Handler:
        """Create syslog handler.

        Args:
            config: Syslog handler configuration

        Returns:
            Configured syslog handler

        """
        from .handlers import EnhancedSyslogHandler

        handler = EnhancedSyslogHandler(config)
        return handler

    @staticmethod
    def create_json_handler(config: FileHandlerConfig | None = None) -> logging.Handler:
        """Create JSON file handler.

        Args:
            config: File handler configuration (optional)

        Returns:
            Configured JSON file handler

        """
        if config is None:
            config = FileHandlerConfig()

        handler = logging.handlers.RotatingFileHandler(
            filename=config.path,
            maxBytes=config.max_bytes,
            backupCount=config.backup_count,
            encoding="utf-8",
        )

        formatter = JSONFormatter()
        handler.setFormatter(formatter)

        if config.level:
            handler.setLevel(get_log_level(config.level))

        return handler
