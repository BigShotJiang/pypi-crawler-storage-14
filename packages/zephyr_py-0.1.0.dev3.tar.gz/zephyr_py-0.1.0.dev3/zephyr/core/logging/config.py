"""Logging Configuration - SINGLE SOURCE OF TRUTH

This module is the ONLY place that reads from BaseSettings and creates
the logging configuration. All other modules receive configuration as
dependency injection.

SOLID Principles:
- Single Responsibility: Only reads settings and creates LoggingConfig
- Open/Closed: Easy to add new config options without modifying other modules
- Dependency Inversion: Depends on types.LoggingConfig abstraction
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from zephyr.conf.base import BaseSettings

from .types import LoggingConfig


class LoggingConfigBuilder:
    """Builder for creating LoggingConfig from BaseSettings.

    This is the SINGLE place where settings are read and configuration is built.
    """

    @staticmethod
    def from_settings(settings: BaseSettings) -> LoggingConfig:
        """Build LoggingConfig from BaseSettings.

        Args:
            settings: BaseSettings instance

        Returns:
            LoggingConfig instance

        """
        try:
            config = LoggingConfig.from_settings(settings)
            return config
        except Exception as e:
            logging.warning(f"Failed to load logging config from settings: {e}. Using defaults.")
            return LoggingConfig()

    @staticmethod
    def validate_config(config: LoggingConfig) -> bool:
        """Validate logging configuration.

        Args:
            config: Configuration to validate

        Returns:
            True if valid

        """
        # Validate critical settings
        if config.console.enabled and not isinstance(config.console.colored, bool):
            return False

        if config.file.enabled and not config.file.path:
            return False

        if config.loki.enabled and not config.loki.url:
            return False

        if config.http.enabled and not config.http.url:
            return False

        return True


# Global configuration instance (lazy loaded)
_logging_config: LoggingConfig | None = None


def get_logging_config(settings: BaseSettings | None = None) -> LoggingConfig:
    """Get or create logging configuration.

    This function ensures configuration is built ONCE and reused.

    Args:
        settings: Settings instance (if None, uses default settings)

    Returns:
        LoggingConfig instance

    """
    global _logging_config

    if _logging_config is not None:
        return _logging_config

    if settings is None:
        from zephyr.conf import settings as default_settings

        settings = default_settings

    _logging_config = LoggingConfigBuilder.from_settings(settings)

    if not LoggingConfigBuilder.validate_config(_logging_config):
        logging.warning("Logging configuration validation failed. Using defaults.")
        _logging_config = LoggingConfig()

    return _logging_config


def reset_logging_config() -> None:
    """Reset logging configuration (for testing)."""
    global _logging_config
    _logging_config = None
