"""Handler Manager - Responsible ONLY for handler lifecycle

SOLID Principle: Single Responsibility
Manager only manages handler lifecycle.
Handler creation is delegated to factory.py
Configuration is provided by config.py
"""

from __future__ import annotations

import atexit
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .types import LoggingConfig

from .factory import HandlerFactory
from .utils import get_log_level


class HandlerManager:
    """Manages logging handlers lifecycle."""

    def __init__(self) -> None:
        """Initialize handler manager."""
        self._handlers: dict[str, logging.Handler] = {}
        self._root_logger = logging.getLogger()

        # Register cleanup on exit
        atexit.register(self.shutdown)

    def configure(self, config: LoggingConfig) -> None:
        """Configure handlers based on configuration.

        Args:
            config: Logging configuration

        """
        # Clear existing handlers
        self.clear_handlers()

        # Set root logger level
        self._root_logger.setLevel(get_log_level(config.level.value))

        # Configure console handler
        if config.console.enabled:
            self._add_console_handler(config)

        # Configure file handler
        if config.file.enabled:
            self._add_file_handler(config)

        # Configure Loki handler
        if config.loki.enabled:
            self._add_loki_handler(config)

        # Configure HTTP handler
        if config.http.enabled:
            self._add_http_handler(config)

        # Configure syslog handler
        if config.syslog.enabled:
            self._add_syslog_handler(config)

    def _add_console_handler(self, config: LoggingConfig) -> None:
        """Add console handler."""
        try:
            handler = HandlerFactory.create_console_handler(config.console)
            self.register_handler("console", handler)
        except Exception as e:
            logging.exception(f"Failed to add console handler: {e}")

    def _add_file_handler(self, config: LoggingConfig) -> None:
        """Add file handler."""
        try:
            handler = HandlerFactory.create_file_handler(config.file)
            self.register_handler("file", handler)
        except Exception as e:
            logging.exception(f"Failed to add file handler: {e}")

    def _add_loki_handler(self, config: LoggingConfig) -> None:
        """Add Loki handler."""
        try:
            handler = HandlerFactory.create_loki_handler(config.loki)
            self.register_handler("loki", handler)
        except Exception as e:
            logging.exception(f"Failed to add Loki handler: {e}")

    def _add_http_handler(self, config: LoggingConfig) -> None:
        """Add HTTP handler."""
        try:
            handler = HandlerFactory.create_http_handler(config.http)
            self.register_handler("http", handler)
        except Exception as e:
            logging.exception(f"Failed to add HTTP handler: {e}")

    def _add_syslog_handler(self, config: LoggingConfig) -> None:
        """Add syslog handler."""
        try:
            handler = HandlerFactory.create_syslog_handler(config.syslog)
            self.register_handler("syslog", handler)
        except Exception as e:
            logging.exception(f"Failed to add syslog handler: {e}")

    def register_handler(self, name: str, handler: logging.Handler) -> None:
        """Register a handler.

        Args:
            name: Handler name
            handler: Handler instance

        """
        self._handlers[name] = handler
        self._root_logger.addHandler(handler)

    def unregister_handler(self, name: str) -> None:
        """Unregister a handler.

        Args:
            name: Handler name

        """
        if name in self._handlers:
            handler = self._handlers.pop(name)
            self._root_logger.removeHandler(handler)
            handler.close()

    def clear_handlers(self) -> None:
        """Clear all registered handlers."""
        for name in list(self._handlers.keys()):
            self.unregister_handler(name)

    def get_handler(self, name: str) -> logging.Handler | None:
        """Get a handler by name.

        Args:
            name: Handler name

        Returns:
            Handler instance or None

        """
        return self._handlers.get(name)

    def list_handlers(self) -> list[str]:
        """List all registered handler names.

        Returns:
            List of handler names

        """
        return list(self._handlers.keys())

    def flush_all(self) -> None:
        """Flush all handlers."""
        for handler in self._handlers.values():
            try:
                handler.flush()
            except ValueError as e:
                # Ignore closed file errors during shutdown
                if "closed file" not in str(e).lower():
                    logging.exception(f"Failed to flush handler: {e}")
            except Exception as e:
                logging.exception(f"Failed to flush handler: {e}")

    def shutdown(self) -> None:
        """Shutdown all handlers gracefully."""
        self.flush_all()
        self.clear_handlers()


# Global handler manager instance
_handler_manager: HandlerManager | None = None


def get_handler_manager() -> HandlerManager:
    """Get the global handler manager instance.

    Returns:
        Handler manager instance

    """
    global _handler_manager
    if _handler_manager is None:
        _handler_manager = HandlerManager()
    return _handler_manager
