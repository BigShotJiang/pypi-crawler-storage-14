"""Result storage backends for the Zephyr task system.

This module provides implementations for storing task results in memory
and Redis, as well as a multi-level store that combines both.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
from datetime import datetime, UTC
from typing import TYPE_CHECKING

from zephyr.core.tasks.base import ResultStoreBackend, TaskResult, TaskStatus
from zephyr.core.tasks.exceptions import ResultStoreError

if TYPE_CHECKING:
    from redis.asyncio import Redis

    from zephyr._types import ALL

logger = logging.getLogger(__name__)

# Default TTL for results: 1 hour
DEFAULT_RESULT_TTL = 3600


class MemoryResultStore(ResultStoreBackend):
    """In-memory result storage backend.

    Provides fast, non-persistent storage for task results.
    Uses thread-safe data structures and automatic TTL cleanup.
    """

    def __init__(self, default_ttl: int = DEFAULT_RESULT_TTL) -> None:
        """Initialize the memory result store.

        Args:
            default_ttl: Default time-to-live in seconds for results.

        """
        self._results: dict[str, TaskResult] = {}
        self._expiry: dict[str, datetime] = {}
        self._lock = threading.Lock()
        self._default_ttl = default_ttl

    async def store(self, result: TaskResult, ttl: int | None = None) -> None:
        """Store a task result in memory.

        Args:
            result: The TaskResult to store.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        """
        effective_ttl = ttl if ttl is not None else self._default_ttl
        expiry_time = datetime.now(UTC)

        with self._lock:
            self._results[result.task_id] = result
            if effective_ttl > 0:
                from datetime import timedelta

                self._expiry[result.task_id] = expiry_time + timedelta(seconds=effective_ttl)

    async def get(self, task_id: str) -> TaskResult | None:
        """Retrieve a task result from memory.

        Args:
            task_id: The unique task identifier.

        Returns:
            The TaskResult or None if not found or expired.

        """
        with self._lock:
            if task_id not in self._results:
                return None

            # Check expiry
            if task_id in self._expiry:
                if datetime.now(UTC) > self._expiry[task_id]:
                    # Expired - remove and return None
                    del self._results[task_id]
                    del self._expiry[task_id]
                    return None

            return self._results[task_id]

    async def delete(self, task_id: str) -> None:
        """Delete a task result from memory.

        Args:
            task_id: The unique task identifier.

        """
        with self._lock:
            self._results.pop(task_id, None)
            self._expiry.pop(task_id, None)

    async def exists(self, task_id: str) -> bool:
        """Check if a task result exists in memory.

        Args:
            task_id: The unique task identifier.

        Returns:
            True if the result exists and is not expired.

        """
        result = await self.get(task_id)
        return result is not None

    async def list_tasks(
        self,
        status: TaskStatus | None = None,
        limit: int = 100,
    ) -> list[TaskResult]:
        """List task results from memory.

        Args:
            status: Filter by task status. If None, returns all.
            limit: Maximum number of results to return.

        Returns:
            List of TaskResult objects.

        """
        results: list[TaskResult] = []
        now = datetime.now(UTC)

        with self._lock:
            for task_id, result in self._results.items():
                # Skip expired
                if task_id in self._expiry and now > self._expiry[task_id]:
                    continue

                if status is None or result.status == status:
                    results.append(result)

                if len(results) >= limit:
                    break

        return results

    async def cleanup_expired(self) -> int:
        """Remove expired task results from memory.

        Returns:
            Number of results removed.

        """
        removed = 0
        now = datetime.now(UTC)

        with self._lock:
            expired_ids = [task_id for task_id, expiry in self._expiry.items() if now > expiry]

            for task_id in expired_ids:
                self._results.pop(task_id, None)
                self._expiry.pop(task_id, None)
                removed += 1

        return removed

    async def close(self) -> None:
        """Close the memory result store (no-op for memory)."""

    @property
    def count(self) -> int:
        """Get the number of stored results."""
        with self._lock:
            return len(self._results)


class RedisResultStore(ResultStoreBackend):
    """Redis-based result storage backend.

    Provides persistent, distributed storage for task results.
    Supports automatic TTL expiration via Redis.
    """

    KEY_PREFIX = "zephyr:task:result:"

    def __init__(
        self,
        redis_client: Redis,
        default_ttl: int = DEFAULT_RESULT_TTL,
        key_prefix: str | None = None,
    ) -> None:
        """Initialize the Redis result store.

        Args:
            redis_client: Async Redis client instance.
            default_ttl: Default time-to-live in seconds for results.
            key_prefix: Optional custom key prefix.

        """
        self._redis = redis_client
        self._default_ttl = default_ttl
        self._prefix = key_prefix or self.KEY_PREFIX

    def _key(self, task_id: str) -> str:
        """Generate Redis key for a task ID.

        Args:
            task_id: The task identifier.

        Returns:
            Full Redis key with prefix.

        """
        return f"{self._prefix}{task_id}"

    async def store(self, result: TaskResult, ttl: int | None = None) -> None:
        """Store a task result in Redis.

        Args:
            result: The TaskResult to store.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            ResultStoreError: If the Redis operation fails.

        """
        try:
            effective_ttl = ttl if ttl is not None else self._default_ttl
            key = self._key(result.task_id)
            data = json.dumps(result.to_dict())

            if effective_ttl > 0:
                await self._redis.setex(key, effective_ttl, data)
            else:
                await self._redis.set(key, data)

        except Exception as e:
            raise ResultStoreError("store", str(e)) from e

    async def get(self, task_id: str) -> TaskResult | None:
        """Retrieve a task result from Redis.

        Args:
            task_id: The unique task identifier.

        Returns:
            The TaskResult or None if not found.

        Raises:
            ResultStoreError: If the Redis operation fails.

        """
        try:
            key = self._key(task_id)
            data = await self._redis.get(key)

            if data is None:
                return None

            parsed: dict[str, ALL] = json.loads(data)
            return TaskResult.from_dict(parsed)

        except Exception as e:
            raise ResultStoreError("get", str(e)) from e

    async def delete(self, task_id: str) -> None:
        """Delete a task result from Redis.

        Args:
            task_id: The unique task identifier.

        Raises:
            ResultStoreError: If the Redis operation fails.

        """
        try:
            key = self._key(task_id)
            await self._redis.delete(key)
        except Exception as e:
            raise ResultStoreError("delete", str(e)) from e

    async def exists(self, task_id: str) -> bool:
        """Check if a task result exists in Redis.

        Args:
            task_id: The unique task identifier.

        Returns:
            True if the result exists.

        Raises:
            ResultStoreError: If the Redis operation fails.

        """
        try:
            key = self._key(task_id)
            return bool(await self._redis.exists(key))
        except Exception as e:
            raise ResultStoreError("exists", str(e)) from e

    async def list_tasks(
        self,
        status: TaskStatus | None = None,
        limit: int = 100,
    ) -> list[TaskResult]:
        """List task results from Redis.

        Args:
            status: Filter by task status. If None, returns all.
            limit: Maximum number of results to return.

        Returns:
            List of TaskResult objects.

        Raises:
            ResultStoreError: If the Redis operation fails.

        """
        try:
            results: list[TaskResult] = []
            pattern = f"{self._prefix}*"
            cursor = 0

            while len(results) < limit:
                cursor, keys = await self._redis.scan(cursor, match=pattern, count=100)

                for key in keys:
                    if len(results) >= limit:
                        break

                    data = await self._redis.get(key)
                    if data:
                        parsed: dict[str, ALL] = json.loads(data)
                        result = TaskResult.from_dict(parsed)

                        if status is None or result.status == status:
                            results.append(result)

                if cursor == 0:
                    break

            return results

        except Exception as e:
            raise ResultStoreError("list_tasks", str(e)) from e

    async def cleanup_expired(self) -> int:
        """Remove expired task results (handled by Redis TTL).

        Returns:
            Always returns 0 as Redis handles expiration automatically.

        """
        # Redis handles TTL expiration automatically
        return 0

    async def close(self) -> None:
        """Close the Redis connection."""
        await self._redis.close()


class MultiLevelResultStore(ResultStoreBackend):
    """Multi-level result storage combining memory (L1) and Redis (L2).

    Provides fast access via memory cache with persistent backup in Redis.
    Reads check memory first, writes go to both stores.
    """

    def __init__(
        self,
        memory_store: MemoryResultStore,
        redis_store: RedisResultStore,
        sync_on_read: bool = True,
    ) -> None:
        """Initialize the multi-level result store.

        Args:
            memory_store: Memory store for L1 caching.
            redis_store: Redis store for L2 persistence.
            sync_on_read: Whether to sync L1 from L2 on cache miss.

        """
        self._memory = memory_store
        self._redis = redis_store
        self._sync_on_read = sync_on_read

    async def store(self, result: TaskResult, ttl: int | None = None) -> None:
        """Store a task result in both levels.

        Args:
            result: The TaskResult to store.
            ttl: Time-to-live in seconds.

        """
        # Store in both levels concurrently
        await asyncio.gather(
            self._memory.store(result, ttl),
            self._redis.store(result, ttl),
            return_exceptions=True,
        )

    async def get(self, task_id: str) -> TaskResult | None:
        """Retrieve a task result, checking L1 first, then L2.

        Args:
            task_id: The unique task identifier.

        Returns:
            The TaskResult or None if not found.

        """
        # Check L1 (memory) first
        result = await self._memory.get(task_id)
        if result is not None:
            return result

        # Check L2 (Redis)
        result = await self._redis.get(task_id)
        if result is not None and self._sync_on_read:
            # Sync to L1 for faster subsequent access
            await self._memory.store(result)

        return result

    async def delete(self, task_id: str) -> None:
        """Delete a task result from both levels.

        Args:
            task_id: The unique task identifier.

        """
        await asyncio.gather(
            self._memory.delete(task_id),
            self._redis.delete(task_id),
            return_exceptions=True,
        )

    async def exists(self, task_id: str) -> bool:
        """Check if a task result exists in either level.

        Args:
            task_id: The unique task identifier.

        Returns:
            True if the result exists in either level.

        """
        if await self._memory.exists(task_id):
            return True
        return await self._redis.exists(task_id)

    async def list_tasks(
        self,
        status: TaskStatus | None = None,
        limit: int = 100,
    ) -> list[TaskResult]:
        """List task results from Redis (authoritative source).

        Args:
            status: Filter by task status. If None, returns all.
            limit: Maximum number of results to return.

        Returns:
            List of TaskResult objects.

        """
        # Redis is the authoritative source for listing
        return await self._redis.list_tasks(status, limit)

    async def cleanup_expired(self) -> int:
        """Remove expired task results from memory.

        Returns:
            Number of results removed from memory.

        """
        # Only cleanup memory; Redis handles its own TTL
        return await self._memory.cleanup_expired()

    async def close(self) -> None:
        """Close both result stores."""
        await asyncio.gather(
            self._memory.close(),
            self._redis.close(),
            return_exceptions=True,
        )

    @property
    def memory_store(self) -> MemoryResultStore:
        """Get the memory store instance."""
        return self._memory

    @property
    def redis_store(self) -> RedisResultStore:
        """Get the Redis store instance."""
        return self._redis

