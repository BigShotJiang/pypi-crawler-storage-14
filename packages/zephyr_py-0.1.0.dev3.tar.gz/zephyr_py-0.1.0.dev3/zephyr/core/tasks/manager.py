"""Unified task manager facade for the Zephyr task system.

This module provides the TaskManager class that serves as a unified interface
for task execution, supporting both in-process and distributed backends.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from zephyr.core.tasks.base import (
    JobQueueBackend,
    ResultStoreBackend,
    TaskResult,
    TaskStatus,
)
from zephyr.core.tasks.exceptions import (
    BackendError,
    ResultNotFoundError,
    TaskNotFoundError,
)
from zephyr.core.tasks.registry import TaskRegistry, get_registry
from zephyr.core.tasks.result import MemoryResultStore
from zephyr.core.tasks.runner import TaskRunner

if TYPE_CHECKING:
    from zephyr._types import ALL

logger = logging.getLogger(__name__)


class TaskBackendType(Enum):
    """Supported task backend types."""

    IN_PROCESS = "in_process"
    CELERY = "celery"
    RQ = "rq"


class ResultBackendType(Enum):
    """Supported result storage backend types."""

    MEMORY = "memory"
    REDIS = "redis"
    BOTH = "both"


@dataclass
class TaskManagerConfig:
    """Configuration for TaskManager.

    Attributes:
        backend: The task execution backend type.
        result_backend: The result storage backend type.
        broker_url: URL for message broker (Celery/RQ).
        result_redis_url: URL for Redis result backend.
        default_queue: Default queue name for tasks.
        default_timeout: Default task timeout in seconds.
        default_retry: Default retry count for tasks.
        result_ttl: TTL for stored results in seconds.
        max_workers: Max thread pool workers for sync tasks.

    """

    backend: TaskBackendType = TaskBackendType.IN_PROCESS
    result_backend: ResultBackendType = ResultBackendType.MEMORY
    broker_url: str | None = None
    result_redis_url: str | None = None
    default_queue: str = "default"
    default_timeout: float = 300.0
    default_retry: int = 3
    result_ttl: int = 3600
    max_workers: int = 4


class TaskManager:
    """Unified facade for task management.

    Provides a single interface for:
    - Submitting tasks (in-process or distributed)
    - Retrieving task results
    - Cancelling tasks
    - Listing registered tasks

    Automatically selects the appropriate backend based on configuration.
    """

    _instance: TaskManager | None = None

    def __init__(
        self,
        config: TaskManagerConfig | None = None,
        registry: TaskRegistry | None = None,
        result_store: ResultStoreBackend | None = None,
        job_backend: JobQueueBackend | None = None,
    ) -> None:
        """Initialize the TaskManager.

        Args:
            config: Task manager configuration.
            registry: Task registry instance.
            result_store: Result storage backend.
            job_backend: Job queue backend for distributed execution.

        """
        self._config = config or TaskManagerConfig()
        self._registry = registry or get_registry()
        self._result_store = result_store
        self._job_backend = job_backend
        self._runner: TaskRunner | None = None
        self._initialized = False

    async def initialize(self) -> None:
        """Initialize the task manager and backends.

        This should be called during application startup.
        """
        if self._initialized:
            return

        # Setup result store if not provided
        if self._result_store is None:
            self._result_store = await self._create_result_store()

        # Setup in-process runner
        self._runner = TaskRunner(
            registry=self._registry,
            result_store=self._result_store,
            max_workers=self._config.max_workers,
        )

        # Connect job backend if configured
        if self._job_backend is not None:
            try:
                await self._job_backend.connect()
                logger.info(
                    "Connected to job queue backend: %s",
                    self._config.backend.value,
                )
            except Exception as e:
                logger.warning(
                    "Failed to connect to job backend, falling back to in-process: %s",
                    str(e),
                )
                self._job_backend = None

        self._initialized = True
        logger.info(
            "TaskManager initialized (backend=%s, result_backend=%s)",
            self._config.backend.value,
            self._config.result_backend.value,
        )

    async def _create_result_store(self) -> ResultStoreBackend:
        """Create result store based on configuration.

        Returns:
            Configured result store backend.

        """
        from zephyr.core.tasks.result import (
            MultiLevelResultStore,
            RedisResultStore,
        )

        memory_store = MemoryResultStore(default_ttl=self._config.result_ttl)

        if self._config.result_backend == ResultBackendType.MEMORY:
            return memory_store

        if self._config.result_backend in (ResultBackendType.REDIS, ResultBackendType.BOTH):
            if self._config.result_redis_url:
                try:
                    from redis.asyncio import Redis

                    redis_client = Redis.from_url(self._config.result_redis_url)
                    redis_store = RedisResultStore(
                        redis_client=redis_client,
                        default_ttl=self._config.result_ttl,
                    )

                    if self._config.result_backend == ResultBackendType.BOTH:
                        return MultiLevelResultStore(
                            memory_store=memory_store,
                            redis_store=redis_store,
                        )
                    return redis_store

                except ImportError:
                    logger.warning("redis package not installed, using memory store")
                except Exception as e:
                    logger.warning("Failed to connect to Redis: %s, using memory store", e)

        return memory_store

    async def submit(
        self,
        task_name: str,
        *args: ALL,
        queue: str | None = None,
        **kwargs: ALL,
    ) -> str:
        """Submit a task for execution.

        Uses distributed backend if configured and connected,
        otherwise falls back to in-process execution.

        Args:
            task_name: Name of the registered task.
            *args: Positional arguments for the task.
            queue: Queue name (uses default if not specified).
            **kwargs: Keyword arguments for the task.

        Returns:
            The task ID for tracking.

        Raises:
            TaskNotFoundError: If the task is not registered.
            BackendError: If task submission fails.

        """
        if not self._initialized:
            await self.initialize()

        # Verify task exists
        if not self._registry.exists(task_name):
            raise TaskNotFoundError(task_name)

        metadata = self._registry.get(task_name)
        effective_queue = queue or metadata.queue or self._config.default_queue

        # Try distributed backend first
        if self._job_backend is not None and self._job_backend.is_connected:
            try:
                import uuid

                task_id = str(uuid.uuid4())
                await self._job_backend.submit(
                    task_name=task_name,
                    task_id=task_id,
                    args=args,
                    kwargs=kwargs,
                    queue=effective_queue,
                )
                logger.debug(
                    "Submitted task %s to backend (id=%s, queue=%s)",
                    task_name,
                    task_id,
                    effective_queue,
                )
                return task_id

            except Exception as e:
                logger.warning(
                    "Backend submission failed, falling back to in-process: %s",
                    str(e),
                )

        # Fall back to in-process runner
        if self._runner is None:
            msg = "TaskManager not initialized"
            raise BackendError("in_process", msg)

        return await self._runner.submit(task_name, *args, **kwargs)

    async def get_result(
        self,
        task_id: str,
        wait: bool = False,
        timeout: float | None = None,
    ) -> TaskResult:
        """Get the result of a task.

        Args:
            task_id: The task ID.
            wait: Whether to wait for completion if still running.
            timeout: Maximum time to wait in seconds.

        Returns:
            The TaskResult.

        Raises:
            ResultNotFoundError: If result not found.
            asyncio.TimeoutError: If wait timeout exceeded.

        """
        if not self._initialized:
            await self.initialize()

        # If waiting, use runner's wait method
        if wait and self._runner:
            try:
                return await self._runner.wait(task_id, timeout=timeout)
            except TaskNotFoundError:
                pass

        # Check result store
        if self._result_store:
            result = await self._result_store.get(task_id)
            if result:
                return result

        # Check job backend status
        if self._job_backend and self._job_backend.is_connected:
            status = await self._job_backend.get_status(task_id)
            if status:
                # Return minimal result with status
                return TaskResult(
                    task_id=task_id,
                    task_name="unknown",
                    status=status,
                )

        raise ResultNotFoundError(task_id)

    async def cancel(self, task_id: str) -> bool:
        """Cancel a pending or running task.

        Args:
            task_id: The task ID to cancel.

        Returns:
            True if cancelled, False if not found or already completed.

        """
        if not self._initialized:
            await self.initialize()

        # Try in-process runner first
        if self._runner:
            if await self._runner.cancel(task_id):
                return True

        # Try job backend
        if self._job_backend and self._job_backend.is_connected:
            return await self._job_backend.cancel(task_id)

        return False

    async def list_results(
        self,
        status: TaskStatus | None = None,
        limit: int = 100,
    ) -> list[TaskResult]:
        """List task results.

        Args:
            status: Filter by status. None returns all.
            limit: Maximum number of results.

        Returns:
            List of TaskResult objects.

        """
        if not self._initialized:
            await self.initialize()

        if self._result_store:
            return await self._result_store.list_tasks(status, limit)

        return []

    def list_registered_tasks(self) -> list[str]:
        """List all registered task names.

        Returns:
            List of task names.

        """
        return self._registry.list_task_names()

    async def health_check(self) -> dict[str, bool]:
        """Check health of all backends.

        Returns:
            Dictionary with backend health status.

        """
        health: dict[str, bool] = {
            "in_process_runner": self._runner is not None,
            "result_store": self._result_store is not None,
        }

        if self._job_backend:
            try:
                health["job_backend"] = await self._job_backend.health_check()
            except Exception:
                health["job_backend"] = False

        return health

    async def shutdown(self, wait: bool = True) -> None:
        """Shutdown the task manager.

        Args:
            wait: Whether to wait for running tasks.

        """
        if self._runner:
            await self._runner.shutdown(wait=wait)

        if self._job_backend:
            await self._job_backend.disconnect()

        if self._result_store:
            await self._result_store.close()

        self._initialized = False
        logger.info("TaskManager shutdown complete")

    @property
    def is_initialized(self) -> bool:
        """Check if the manager is initialized."""
        return self._initialized

    @property
    def config(self) -> TaskManagerConfig:
        """Get the configuration."""
        return self._config

    @property
    def registry(self) -> TaskRegistry:
        """Get the task registry."""
        return self._registry

    @classmethod
    def configure(
        cls,
        backend: TaskBackendType = TaskBackendType.IN_PROCESS,
        result_backend: ResultBackendType = ResultBackendType.MEMORY,
        broker_url: str | None = None,
        result_redis_url: str | None = None,
        **kwargs: ALL,
    ) -> TaskManager:
        """Create and configure a TaskManager instance.

        This is a convenience factory method for creating managers.

        Args:
            backend: Task execution backend type.
            result_backend: Result storage backend type.
            broker_url: URL for message broker.
            result_redis_url: URL for Redis result backend.
            **kwargs: Additional configuration options.

        Returns:
            Configured TaskManager instance.

        """
        config = TaskManagerConfig(
            backend=backend,
            result_backend=result_backend,
            broker_url=broker_url,
            result_redis_url=result_redis_url,
            default_queue=str(kwargs.get("default_queue", "default")),
            default_timeout=float(kwargs.get("default_timeout", 300.0)),
            default_retry=int(kwargs.get("default_retry", 3)),
            result_ttl=int(kwargs.get("result_ttl", 3600)),
            max_workers=int(kwargs.get("max_workers", 4)),
        )
        return cls(config=config)


# Default global manager instance
_manager: TaskManager | None = None


def get_task_manager() -> TaskManager:
    """Get the global TaskManager instance.

    Returns:
        The global TaskManager instance.

    """
    global _manager
    if _manager is None:
        _manager = TaskManager()
    return _manager


def set_task_manager(manager: TaskManager) -> None:
    """Set the global TaskManager instance.

    Args:
        manager: The TaskManager instance to use globally.

    """
    global _manager
    _manager = manager

