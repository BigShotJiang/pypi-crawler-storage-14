"""In-process task runner for the Zephyr task system.

This module provides the TaskRunner class for executing tasks in-process,
supporting both async and sync task functions with timeout and retry handling.
"""

from __future__ import annotations

import asyncio
import logging
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, UTC
from typing import TYPE_CHECKING

from zephyr.core.tasks.base import ResultStoreBackend, TaskResult, TaskStatus
from zephyr.core.tasks.exceptions import (
    TaskExecutionError,
    TaskNotFoundError,
    TaskRetryError,
    TaskTimeoutError,
)
from zephyr.core.tasks.registry import TaskRegistry, get_registry

if TYPE_CHECKING:
    from zephyr._types import ALL

logger = logging.getLogger(__name__)

# Default thread pool size for sync tasks
DEFAULT_EXECUTOR_WORKERS = 4


class TaskRunner:
    """In-process task runner for async and sync tasks.

    Executes registered tasks locally with support for:
    - Async task execution (native await)
    - Sync task execution (via thread pool)
    - Timeout enforcement
    - Retry with exponential backoff
    - Result storage
    """

    def __init__(
        self,
        registry: TaskRegistry | None = None,
        result_store: ResultStoreBackend | None = None,
        max_workers: int = DEFAULT_EXECUTOR_WORKERS,
    ) -> None:
        """Initialize the task runner.

        Args:
            registry: Task registry. Uses global registry if not provided.
            result_store: Result store backend for persisting results.
            max_workers: Maximum thread pool workers for sync tasks.

        """
        self._registry = registry or get_registry()
        self._result_store = result_store
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._running_tasks: dict[str, asyncio.Task[TaskResult]] = {}

    async def run(
        self,
        task_name: str,
        *args: ALL,
        task_id: str | None = None,
        **kwargs: ALL,
    ) -> TaskResult:
        """Execute a task by name.

        Args:
            task_name: Name of the registered task.
            *args: Positional arguments for the task.
            task_id: Optional custom task ID. Generated if not provided.
            **kwargs: Keyword arguments for the task.

        Returns:
            TaskResult with execution outcome.

        Raises:
            TaskNotFoundError: If the task is not registered.
            TaskExecutionError: If execution fails after all retries.
            TaskTimeoutError: If execution times out.

        """
        # Get task metadata
        metadata = self._registry.get(task_name)
        effective_task_id = task_id or str(uuid.uuid4())

        # Create initial result
        result = TaskResult(
            task_id=effective_task_id,
            task_name=task_name,
            status=TaskStatus.PENDING,
            created_at=datetime.now(UTC),
        )

        # Store initial pending state
        if self._result_store:
            await self._result_store.store(result)

        # Execute with retries
        last_error: str | None = None
        attempts = 0

        while attempts <= metadata.retry:
            attempts += 1
            result.retries = attempts - 1

            try:
                # Update status to running
                result.status = TaskStatus.RUNNING
                result.started_at = datetime.now(UTC)
                if self._result_store:
                    await self._result_store.store(result)

                # Execute the task with timeout
                if metadata.is_async:
                    task_result = await self._run_async(
                        metadata.func,
                        args,
                        kwargs,
                        timeout=metadata.timeout,
                    )
                else:
                    task_result = await self._run_sync(
                        metadata.func,
                        args,
                        kwargs,
                        timeout=metadata.timeout,
                    )

                # Success
                result.status = TaskStatus.SUCCESS
                result.result = task_result
                result.completed_at = datetime.now(UTC)

                if self._result_store:
                    await self._result_store.store(result)

                logger.info(
                    "Task %s completed successfully (id=%s)",
                    task_name,
                    effective_task_id,
                )
                return result

            except TimeoutError:
                last_error = f"Task timed out after {metadata.timeout} seconds"
                result.status = TaskStatus.TIMEOUT
                result.error = last_error
                result.completed_at = datetime.now(UTC)

                logger.warning(
                    "Task %s timed out (id=%s, attempt=%d/%d)",
                    task_name,
                    effective_task_id,
                    attempts,
                    metadata.retry + 1,
                )

                if attempts > metadata.retry:
                    if self._result_store:
                        await self._result_store.store(result)
                    raise TaskTimeoutError(task_name, metadata.timeout) from None

            except Exception as e:
                last_error = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"

                logger.warning(
                    "Task %s failed (id=%s, attempt=%d/%d): %s",
                    task_name,
                    effective_task_id,
                    attempts,
                    metadata.retry + 1,
                    str(e),
                )

                if attempts <= metadata.retry:
                    # Will retry
                    result.status = TaskStatus.RETRY
                    result.error = last_error
                    if self._result_store:
                        await self._result_store.store(result)

                    # Exponential backoff
                    backoff = min(2 ** (attempts - 1), 30)
                    await asyncio.sleep(backoff)
                else:
                    # Final failure
                    result.status = TaskStatus.FAILURE
                    result.error = last_error
                    result.completed_at = datetime.now(UTC)

                    if self._result_store:
                        await self._result_store.store(result)

                    raise TaskRetryError(
                        task_name,
                        attempts,
                        metadata.retry,
                    ) from e

        # Should not reach here, but just in case
        result.status = TaskStatus.FAILURE
        result.error = last_error or "Unknown error"
        result.completed_at = datetime.now(UTC)

        if self._result_store:
            await self._result_store.store(result)

        raise TaskExecutionError(task_name, result.error)

    async def _run_async(
        self,
        func: ALL,
        args: tuple[ALL, ...],
        kwargs: dict[str, ALL],
        timeout: float,
    ) -> ALL:
        """Execute an async task function with timeout.

        Args:
            func: The async function to execute.
            args: Positional arguments.
            kwargs: Keyword arguments.
            timeout: Timeout in seconds.

        Returns:
            The function result.

        Raises:
            asyncio.TimeoutError: If execution times out.

        """
        return await asyncio.wait_for(
            func(*args, **kwargs),
            timeout=timeout,
        )

    async def _run_sync(
        self,
        func: ALL,
        args: tuple[ALL, ...],
        kwargs: dict[str, ALL],
        timeout: float,
    ) -> ALL:
        """Execute a sync task function in thread pool with timeout.

        Args:
            func: The sync function to execute.
            args: Positional arguments.
            kwargs: Keyword arguments.
            timeout: Timeout in seconds.

        Returns:
            The function result.

        Raises:
            asyncio.TimeoutError: If execution times out.

        """
        loop = asyncio.get_running_loop()
        future = loop.run_in_executor(
            self._executor,
            lambda: func(*args, **kwargs),
        )
        return await asyncio.wait_for(future, timeout=timeout)

    async def submit(
        self,
        task_name: str,
        *args: ALL,
        **kwargs: ALL,
    ) -> str:
        """Submit a task for background execution.

        Args:
            task_name: Name of the registered task.
            *args: Positional arguments for the task.
            **kwargs: Keyword arguments for the task.

        Returns:
            The task ID for tracking.

        Raises:
            TaskNotFoundError: If the task is not registered.

        """
        # Verify task exists
        if not self._registry.exists(task_name):
            raise TaskNotFoundError(task_name)

        task_id = str(uuid.uuid4())

        # Create background task
        async_task = asyncio.create_task(self.run(task_name, *args, task_id=task_id, **kwargs))
        self._running_tasks[task_id] = async_task

        # Cleanup when done
        async_task.add_done_callback(lambda _: self._running_tasks.pop(task_id, None))

        logger.debug("Submitted task %s (id=%s)", task_name, task_id)
        return task_id

    async def get_result(self, task_id: str) -> TaskResult | None:
        """Get the result of a task.

        Args:
            task_id: The task ID.

        Returns:
            TaskResult or None if not found.

        """
        if self._result_store:
            return await self._result_store.get(task_id)
        return None

    async def cancel(self, task_id: str) -> bool:
        """Cancel a running task.

        Args:
            task_id: The task ID to cancel.

        Returns:
            True if cancelled, False if not found or already completed.

        """
        async_task = self._running_tasks.get(task_id)
        if async_task is None:
            return False

        if async_task.done():
            return False

        async_task.cancel()
        self._running_tasks.pop(task_id, None)

        # Update result store
        if self._result_store:
            result = await self._result_store.get(task_id)
            if result:
                result.status = TaskStatus.CANCELLED
                result.completed_at = datetime.now(UTC)
                await self._result_store.store(result)

        logger.info("Cancelled task id=%s", task_id)
        return True

    async def wait(self, task_id: str, timeout: float | None = None) -> TaskResult:
        """Wait for a task to complete.

        Args:
            task_id: The task ID to wait for.
            timeout: Maximum time to wait in seconds.

        Returns:
            The TaskResult when complete.

        Raises:
            asyncio.TimeoutError: If timeout exceeded.
            TaskNotFoundError: If task not found.

        """
        async_task = self._running_tasks.get(task_id)

        if async_task is not None:
            # Wait for running task
            try:
                result = await asyncio.wait_for(async_task, timeout=timeout)
                return result
            except asyncio.CancelledError:
                # Task was cancelled
                pass

        # Check result store
        if self._result_store:
            result = await self._result_store.get(task_id)
            if result:
                return result

        raise TaskNotFoundError(task_id)

    @property
    def running_count(self) -> int:
        """Get the number of currently running tasks."""
        return len(self._running_tasks)

    @property
    def running_task_ids(self) -> list[str]:
        """Get list of running task IDs."""
        return list(self._running_tasks.keys())

    async def shutdown(self, wait: bool = True) -> None:
        """Shutdown the task runner.

        Args:
            wait: Whether to wait for running tasks to complete.

        """
        if wait:
            # Wait for all running tasks
            if self._running_tasks:
                await asyncio.gather(
                    *self._running_tasks.values(),
                    return_exceptions=True,
                )

        else:
            # Cancel all running tasks
            for task in self._running_tasks.values():
                task.cancel()

        self._running_tasks.clear()
        self._executor.shutdown(wait=wait)

        logger.info("TaskRunner shutdown complete")

