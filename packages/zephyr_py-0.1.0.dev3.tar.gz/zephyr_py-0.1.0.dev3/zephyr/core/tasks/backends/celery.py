"""Celery backend for the Zephyr task system.

This module provides integration with Celery for distributed task execution.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from zephyr.core.tasks.base import JobQueueBackend, TaskStatus
from zephyr.core.tasks.exceptions import BackendConnectionError, BackendError
from zephyr.core.tasks.registry import get_registry

if TYPE_CHECKING:
    from celery import Celery
    from celery.result import AsyncResult

    from zephyr._types import ALL

logger = logging.getLogger(__name__)


# Celery state to TaskStatus mapping
CELERY_STATE_MAP: dict[str, TaskStatus] = {
    "PENDING": TaskStatus.PENDING,
    "RECEIVED": TaskStatus.PENDING,
    "STARTED": TaskStatus.RUNNING,
    "SUCCESS": TaskStatus.SUCCESS,
    "FAILURE": TaskStatus.FAILURE,
    "RETRY": TaskStatus.RETRY,
    "REVOKED": TaskStatus.CANCELLED,
}


class CeleryBackend(JobQueueBackend):
    """Celery-based job queue backend.

    Provides distributed task execution via Celery with support for
    multiple message brokers (Redis, RabbitMQ, etc.).
    """

    def __init__(
        self,
        broker_url: str,
        result_backend: str | None = None,
        task_default_queue: str = "default",
        task_serializer: str = "json",
        result_serializer: str = "json",
    ) -> None:
        """Initialize the Celery backend.

        Args:
            broker_url: URL for the message broker.
            result_backend: URL for result backend. Uses broker if not specified.
            task_default_queue: Default queue name.
            task_serializer: Serializer for task messages.
            result_serializer: Serializer for results.

        """
        self._broker_url = broker_url
        self._result_backend = result_backend or broker_url
        self._default_queue = task_default_queue
        self._task_serializer = task_serializer
        self._result_serializer = result_serializer
        self._celery: Celery | None = None
        self._connected = False
        self._executor_task: asyncio.Task[None] | None = None

    @property
    def is_connected(self) -> bool:
        """Check if connected to the broker."""
        return self._connected and self._celery is not None

    async def connect(self) -> None:
        """Connect to the Celery broker.

        Raises:
            BackendConnectionError: If connection fails.

        """
        try:
            from celery import Celery

            self._celery = Celery(
                "zephyr_tasks",
                broker=self._broker_url,
                backend=self._result_backend,
            )

            # Configure Celery
            self._celery.conf.update(
                task_serializer=self._task_serializer,
                result_serializer=self._result_serializer,
                accept_content=["json"],
                task_default_queue=self._default_queue,
                task_track_started=True,
                result_extended=True,
            )

            # Register tasks from registry
            self._register_tasks()

            # Test connection
            connection = self._celery.connection()
            connection.ensure_connection(max_retries=3)
            connection.release()

            self._connected = True
            logger.info("Connected to Celery broker: %s", self._broker_url)

        except ImportError as e:
            raise BackendConnectionError(
                "celery",
                self._broker_url,
            ) from e
        except Exception as e:
            raise BackendConnectionError(
                "celery",
                self._broker_url,
            ) from e

    def _register_tasks(self) -> None:
        """Register all tasks from the registry with Celery."""
        if self._celery is None:
            return

        registry = get_registry()
        for metadata in registry.list_tasks():
            # Create a Celery task wrapper
            task_name = f"zephyr.{metadata.name}"

            @self._celery.task(name=task_name, bind=True)
            def celery_task_wrapper(
                self_task: ALL,
                task_name: str = metadata.name,
                *args: ALL,
                **kwargs: ALL,
            ) -> ALL:
                """Wrapper to execute Zephyr task via Celery."""
                task_metadata = registry.get(task_name)
                func = task_metadata.func

                if task_metadata.is_async:
                    # Run async function in new event loop
                    loop = asyncio.new_event_loop()
                    try:
                        return loop.run_until_complete(func(*args, **kwargs))
                    finally:
                        loop.close()
                else:
                    return func(*args, **kwargs)

            logger.debug("Registered Celery task: %s", task_name)

    async def disconnect(self) -> None:
        """Disconnect from the Celery broker."""
        if self._celery:
            self._celery.close()
            self._celery = None

        self._connected = False
        logger.info("Disconnected from Celery broker")

    async def submit(
        self,
        task_name: str,
        task_id: str,
        args: tuple[ALL, ...],
        kwargs: dict[str, ALL],
        queue: str = "default",
    ) -> str:
        """Submit a task to Celery.

        Args:
            task_name: Name of the registered task.
            task_id: Unique identifier for this execution.
            args: Positional arguments for the task.
            kwargs: Keyword arguments for the task.
            queue: Queue name to submit to.

        Returns:
            The task ID.

        Raises:
            BackendError: If submission fails.

        """
        if not self.is_connected:
            raise BackendError("celery", "Not connected to broker")

        try:
            celery_task_name = f"zephyr.{task_name}"

            # Submit to Celery
            result: AsyncResult = self._celery.send_task(
                celery_task_name,
                args=(task_name, *args),
                kwargs=kwargs,
                task_id=task_id,
                queue=queue,
            )

            logger.debug(
                "Submitted task %s to Celery (id=%s, queue=%s)",
                task_name,
                task_id,
                queue,
            )
            return result.id

        except Exception as e:
            raise BackendError("celery", str(e)) from e

    async def cancel(self, task_id: str) -> bool:
        """Cancel a Celery task.

        Args:
            task_id: The task ID to cancel.

        Returns:
            True if revoke signal sent, False otherwise.

        """
        if not self.is_connected:
            return False

        try:
            self._celery.control.revoke(task_id, terminate=True)
            logger.info("Revoked Celery task: %s", task_id)
            return True
        except Exception as e:
            logger.warning("Failed to revoke task %s: %s", task_id, e)
            return False

    async def get_status(self, task_id: str) -> TaskStatus | None:
        """Get the status of a Celery task.

        Args:
            task_id: The task ID to check.

        Returns:
            The task status or None if not found.

        """
        if not self.is_connected:
            return None

        try:
            from celery.result import AsyncResult

            result = AsyncResult(task_id, app=self._celery)
            state = result.state

            return CELERY_STATE_MAP.get(state, TaskStatus.PENDING)

        except Exception as e:
            logger.warning("Failed to get status for task %s: %s", task_id, e)
            return None

    async def health_check(self) -> bool:
        """Check if Celery is healthy.

        Returns:
            True if healthy, False otherwise.

        """
        if not self.is_connected:
            return False

        try:
            # Ping workers
            inspector = self._celery.control.inspect()
            ping_result = inspector.ping()
            return ping_result is not None and len(ping_result) > 0
        except Exception:
            return False

    @property
    def celery_app(self) -> Celery | None:
        """Get the Celery application instance."""
        return self._celery

