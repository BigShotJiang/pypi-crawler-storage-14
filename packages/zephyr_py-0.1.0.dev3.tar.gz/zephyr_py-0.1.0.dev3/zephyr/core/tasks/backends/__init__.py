"""Job queue backends for the Zephyr task system.

This module provides distributed task execution backends including
Celery and RQ (Redis Queue) integrations.
"""

from __future__ import annotations

from zephyr.core.tasks.base import JobQueueBackend

__all__ = [
    "JobQueueBackend",
]

