"""RQ (Redis Queue) backend for the Zephyr task system.

This module provides integration with RQ for distributed task execution.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from zephyr.core.tasks.base import JobQueueBackend, TaskStatus
from zephyr.core.tasks.exceptions import BackendConnectionError, BackendError
from zephyr.core.tasks.registry import get_registry

if TYPE_CHECKING:
    from redis import Redis
    from rq import Queue
    from rq.job import Job

    from zephyr._types import ALL

logger = logging.getLogger(__name__)


# RQ status to TaskStatus mapping
RQ_STATUS_MAP: dict[str, TaskStatus] = {
    "queued": TaskStatus.PENDING,
    "started": TaskStatus.RUNNING,
    "deferred": TaskStatus.PENDING,
    "finished": TaskStatus.SUCCESS,
    "stopped": TaskStatus.CANCELLED,
    "scheduled": TaskStatus.PENDING,
    "failed": TaskStatus.FAILURE,
    "canceled": TaskStatus.CANCELLED,
}


class RQBackend(JobQueueBackend):
    """RQ-based job queue backend.

    Provides distributed task execution via Redis Queue (RQ).
    """

    def __init__(
        self,
        redis_url: str,
        default_queue: str = "default",
        job_timeout: int = 600,
        result_ttl: int = 3600,
        failure_ttl: int = 86400,
    ) -> None:
        """Initialize the RQ backend.

        Args:
            redis_url: Redis connection URL.
            default_queue: Default queue name.
            job_timeout: Job execution timeout in seconds.
            result_ttl: TTL for successful job results.
            failure_ttl: TTL for failed job results.

        """
        self._redis_url = redis_url
        self._default_queue = default_queue
        self._job_timeout = job_timeout
        self._result_ttl = result_ttl
        self._failure_ttl = failure_ttl
        self._redis: Redis | None = None
        self._queues: dict[str, Queue] = {}
        self._connected = False

    @property
    def is_connected(self) -> bool:
        """Check if connected to Redis."""
        return self._connected and self._redis is not None

    async def connect(self) -> None:
        """Connect to Redis for RQ.

        Raises:
            BackendConnectionError: If connection fails.

        """
        try:
            from redis import Redis
            from rq import Queue

            # Parse Redis URL and connect
            self._redis = Redis.from_url(self._redis_url)

            # Test connection
            self._redis.ping()

            # Create default queue
            self._queues[self._default_queue] = Queue(
                name=self._default_queue,
                connection=self._redis,
                default_timeout=self._job_timeout,
            )

            self._connected = True
            logger.info("Connected to RQ backend: %s", self._redis_url)

        except ImportError as e:
            raise BackendConnectionError(
                "rq",
                self._redis_url,
            ) from e
        except Exception as e:
            raise BackendConnectionError(
                "rq",
                self._redis_url,
            ) from e

    def _get_or_create_queue(self, queue_name: str) -> Queue:
        """Get or create a queue by name.

        Args:
            queue_name: The queue name.

        Returns:
            The RQ Queue instance.

        """
        from rq import Queue

        if queue_name not in self._queues:
            self._queues[queue_name] = Queue(
                name=queue_name,
                connection=self._redis,
                default_timeout=self._job_timeout,
            )

        return self._queues[queue_name]

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._redis:
            self._redis.close()
            self._redis = None

        self._queues.clear()
        self._connected = False
        logger.info("Disconnected from RQ backend")

    async def submit(
        self,
        task_name: str,
        task_id: str,
        args: tuple[ALL, ...],
        kwargs: dict[str, ALL],
        queue: str = "default",
    ) -> str:
        """Submit a task to RQ.

        Args:
            task_name: Name of the registered task.
            task_id: Unique identifier for this execution.
            args: Positional arguments for the task.
            kwargs: Keyword arguments for the task.
            queue: Queue name to submit to.

        Returns:
            The job ID.

        Raises:
            BackendError: If submission fails.

        """
        if not self.is_connected:
            raise BackendError("rq", "Not connected to Redis")

        try:
            registry = get_registry()
            metadata = registry.get(task_name)

            # Get the queue
            rq_queue = self._get_or_create_queue(queue)

            # Create wrapper function for execution
            def execute_task(
                task_name: str,
                *task_args: ALL,
                **task_kwargs: ALL,
            ) -> ALL:
                """Execute the registered task."""
                reg = get_registry()
                task_meta = reg.get(task_name)
                func = task_meta.func

                if task_meta.is_async:
                    loop = asyncio.new_event_loop()
                    try:
                        return loop.run_until_complete(func(*task_args, **task_kwargs))
                    finally:
                        loop.close()
                else:
                    return func(*task_args, **task_kwargs)

            # Enqueue the job
            job: Job = rq_queue.enqueue(
                execute_task,
                task_name,
                *args,
                job_id=task_id,
                job_timeout=metadata.timeout,
                result_ttl=self._result_ttl,
                failure_ttl=self._failure_ttl,
                **kwargs,
            )

            logger.debug(
                "Submitted task %s to RQ (id=%s, queue=%s)",
                task_name,
                task_id,
                queue,
            )
            return job.id

        except Exception as e:
            raise BackendError("rq", str(e)) from e

    async def cancel(self, task_id: str) -> bool:
        """Cancel an RQ job.

        Args:
            task_id: The job ID to cancel.

        Returns:
            True if cancelled, False otherwise.

        """
        if not self.is_connected:
            return False

        try:
            from rq.job import Job

            job = Job.fetch(task_id, connection=self._redis)
            job.cancel()
            logger.info("Cancelled RQ job: %s", task_id)
            return True
        except Exception as e:
            logger.warning("Failed to cancel job %s: %s", task_id, e)
            return False

    async def get_status(self, task_id: str) -> TaskStatus | None:
        """Get the status of an RQ job.

        Args:
            task_id: The job ID to check.

        Returns:
            The task status or None if not found.

        """
        if not self.is_connected:
            return None

        try:
            from rq.job import Job

            job = Job.fetch(task_id, connection=self._redis)
            status = job.get_status()

            return RQ_STATUS_MAP.get(status, TaskStatus.PENDING)

        except Exception as e:
            logger.debug("Failed to get status for job %s: %s", task_id, e)
            return None

    async def health_check(self) -> bool:
        """Check if RQ backend is healthy.

        Returns:
            True if healthy, False otherwise.

        """
        if not self.is_connected:
            return False

        try:
            self._redis.ping()
            return True
        except Exception:
            return False

    async def get_job_result(self, task_id: str) -> ALL:
        """Get the result of a completed job.

        Args:
            task_id: The job ID.

        Returns:
            The job result or None if not found/not complete.

        """
        if not self.is_connected:
            return None

        try:
            from rq.job import Job

            job = Job.fetch(task_id, connection=self._redis)
            return job.result
        except Exception:
            return None

    def get_queue_length(self, queue_name: str | None = None) -> int:
        """Get the number of jobs in a queue.

        Args:
            queue_name: Queue name. Uses default if not specified.

        Returns:
            Number of jobs in the queue.

        """
        if not self.is_connected:
            return 0

        queue_name = queue_name or self._default_queue
        rq_queue = self._get_or_create_queue(queue_name)
        return len(rq_queue)

    @property
    def redis_connection(self) -> Redis | None:
        """Get the Redis connection."""
        return self._redis

