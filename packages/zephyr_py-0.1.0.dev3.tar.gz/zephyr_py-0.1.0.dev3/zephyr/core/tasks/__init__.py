"""Unified Task System for the Zephyr framework.

This module provides a comprehensive task management system supporting:
- In-process async and sync task execution
- Distributed execution via Celery or RQ
- Dual-layer result storage (Memory + Redis)
- Task registration via decorators
- Retry and timeout handling

Example usage:

    from zephyr.core.tasks import TaskManager, task

    # Register a task
    @task(name="process_data", retry=3, timeout=30)
    async def process_data(user_id: int) -> dict:
        return {"user_id": user_id, "status": "done"}

    # Submit and get result
    manager = TaskManager.configure()
    await manager.initialize()

    task_id = await manager.submit("process_data", user_id=123)
    result = await manager.get_result(task_id, wait=True)
"""

from __future__ import annotations

from zephyr.core.tasks.base import (
    JobQueueBackend,
    ResultStoreBackend,
    TaskMetadata,
    TaskResult,
    TaskStatus,
)
from zephyr.core.tasks.decorators import (
    PeriodicTaskWrapper,
    TaskWrapper,
    periodic_task,
    task,
)
from zephyr.core.tasks.exceptions import (
    BackendConnectionError,
    BackendError,
    ResultNotFoundError,
    ResultStoreError,
    TaskAlreadyRegisteredError,
    TaskCancelledError,
    TaskError,
    TaskExecutionError,
    TaskNotFoundError,
    TaskRetryError,
    TaskTimeoutError,
)
from zephyr.core.tasks.manager import (
    ResultBackendType,
    TaskBackendType,
    TaskManager,
    TaskManagerConfig,
    get_task_manager,
    set_task_manager,
)
from zephyr.core.tasks.registry import TaskRegistry, get_registry
from zephyr.core.tasks.result import (
    MemoryResultStore,
    MultiLevelResultStore,
    RedisResultStore,
)
from zephyr.core.tasks.runner import TaskRunner

__all__ = [
    # Core types
    "TaskStatus",
    "TaskMetadata",
    "TaskResult",
    # Abstract bases
    "ResultStoreBackend",
    "JobQueueBackend",
    # Registry
    "TaskRegistry",
    "get_registry",
    # Decorators
    "task",
    "periodic_task",
    "TaskWrapper",
    "PeriodicTaskWrapper",
    # Result stores
    "MemoryResultStore",
    "RedisResultStore",
    "MultiLevelResultStore",
    # Runner
    "TaskRunner",
    # Manager
    "TaskManager",
    "TaskManagerConfig",
    "TaskBackendType",
    "ResultBackendType",
    "get_task_manager",
    "set_task_manager",
    # Exceptions
    "TaskError",
    "TaskNotFoundError",
    "TaskAlreadyRegisteredError",
    "TaskExecutionError",
    "TaskTimeoutError",
    "TaskCancelledError",
    "TaskRetryError",
    "ResultNotFoundError",
    "ResultStoreError",
    "BackendError",
    "BackendConnectionError",
]

