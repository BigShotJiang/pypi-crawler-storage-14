"""Task-specific exceptions for the Zephyr framework.

This module defines custom exception classes for task operations including
registration, execution, result storage, and backend communication.
"""

from __future__ import annotations


class TaskError(Exception):
    """Base exception for all task operations."""


class TaskNotFoundError(TaskError):
    """Raised when a task is not found in the registry."""

    def __init__(self, task_name: str) -> None:
        """Initialize TaskNotFoundError.

        Args:
            task_name: The name of the task that was not found.

        """
        self.task_name = task_name
        super().__init__(f"Task '{task_name}' not found in registry")


class TaskAlreadyRegisteredError(TaskError):
    """Raised when attempting to register a task that already exists."""

    def __init__(self, task_name: str) -> None:
        """Initialize TaskAlreadyRegisteredError.

        Args:
            task_name: The name of the task that is already registered.

        """
        self.task_name = task_name
        super().__init__(f"Task '{task_name}' is already registered")


class TaskExecutionError(TaskError):
    """Raised when a task execution fails."""

    def __init__(self, task_name: str, reason: str) -> None:
        """Initialize TaskExecutionError.

        Args:
            task_name: The name of the task that failed.
            reason: The reason for the failure.

        """
        self.task_name = task_name
        self.reason = reason
        super().__init__(f"Task '{task_name}' execution failed: {reason}")


class TaskTimeoutError(TaskError):
    """Raised when a task execution times out."""

    def __init__(self, task_name: str, timeout: float) -> None:
        """Initialize TaskTimeoutError.

        Args:
            task_name: The name of the task that timed out.
            timeout: The timeout value in seconds.

        """
        self.task_name = task_name
        self.timeout = timeout
        super().__init__(f"Task '{task_name}' timed out after {timeout} seconds")


class TaskCancelledError(TaskError):
    """Raised when a task is cancelled before completion."""

    def __init__(self, task_id: str) -> None:
        """Initialize TaskCancelledError.

        Args:
            task_id: The ID of the task that was cancelled.

        """
        self.task_id = task_id
        super().__init__(f"Task '{task_id}' was cancelled")


class TaskRetryError(TaskError):
    """Raised when a task exceeds maximum retry attempts."""

    def __init__(self, task_name: str, attempts: int, max_retries: int) -> None:
        """Initialize TaskRetryError.

        Args:
            task_name: The name of the task that exceeded retries.
            attempts: The number of attempts made.
            max_retries: The maximum number of retries allowed.

        """
        self.task_name = task_name
        self.attempts = attempts
        self.max_retries = max_retries
        super().__init__(f"Task '{task_name}' exceeded maximum retries ({attempts}/{max_retries})")


class ResultNotFoundError(TaskError):
    """Raised when a task result is not found."""

    def __init__(self, task_id: str) -> None:
        """Initialize ResultNotFoundError.

        Args:
            task_id: The ID of the task whose result was not found.

        """
        self.task_id = task_id
        super().__init__(f"Result for task '{task_id}' not found")


class ResultStoreError(TaskError):
    """Raised when a result store operation fails."""

    def __init__(self, operation: str, reason: str) -> None:
        """Initialize ResultStoreError.

        Args:
            operation: The operation that failed (e.g., 'get', 'set').
            reason: The reason for the failure.

        """
        self.operation = operation
        self.reason = reason
        super().__init__(f"Result store {operation} failed: {reason}")


class BackendError(TaskError):
    """Raised when a job queue backend operation fails."""

    def __init__(self, backend: str, reason: str) -> None:
        """Initialize BackendError.

        Args:
            backend: The name of the backend (e.g., 'celery', 'rq').
            reason: The reason for the failure.

        """
        self.backend = backend
        self.reason = reason
        super().__init__(f"Backend '{backend}' error: {reason}")


class BackendConnectionError(BackendError):
    """Raised when connection to a job queue backend fails."""

    def __init__(self, backend: str, broker_url: str) -> None:
        """Initialize BackendConnectionError.

        Args:
            backend: The name of the backend.
            broker_url: The broker URL that failed to connect.

        """
        self.broker_url = broker_url
        super().__init__(backend, f"Failed to connect to broker at '{broker_url}'")

