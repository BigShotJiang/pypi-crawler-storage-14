"""Task decorators for the Zephyr task system.

This module provides decorators for registering functions as tasks,
including support for periodic/scheduled tasks.
"""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING, TypeVar, overload
from collections.abc import Callable

from zephyr.core.tasks.registry import get_registry

if TYPE_CHECKING:
    from collections.abc import Awaitable

    from zephyr._types import ALL

F = TypeVar("F", bound=Callable[..., "ALL | Awaitable[ALL]"])


class TaskWrapper:
    """Wrapper for registered task functions.

    This class wraps task functions to provide additional metadata
    and convenient access to task properties.
    """

    def __init__(
        self,
        func: Callable[..., ALL | Awaitable[ALL]],
        name: str,
        queue: str,
        retry: int,
        timeout: float,
    ) -> None:
        """Initialize the task wrapper.

        Args:
            func: The wrapped task function.
            name: The task name.
            queue: The queue name.
            retry: Maximum retry attempts.
            timeout: Execution timeout in seconds.

        """
        self._func = func
        self._name = name
        self._queue = queue
        self._retry = retry
        self._timeout = timeout

        # Preserve function metadata
        functools.update_wrapper(self, func)

    @property
    def name(self) -> str:
        """Get the task name."""
        return self._name

    @property
    def queue(self) -> str:
        """Get the queue name."""
        return self._queue

    @property
    def retry(self) -> int:
        """Get the retry count."""
        return self._retry

    @property
    def timeout(self) -> float:
        """Get the timeout value."""
        return self._timeout

    def __call__(self, *args: ALL, **kwargs: ALL) -> ALL | Awaitable[ALL]:
        """Execute the task function directly.

        Args:
            *args: Positional arguments for the task.
            **kwargs: Keyword arguments for the task.

        Returns:
            The task function result.

        """
        return self._func(*args, **kwargs)

    def __repr__(self) -> str:
        """Return string representation."""
        return f"<Task name={self._name!r} queue={self._queue!r}>"


class PeriodicTaskWrapper(TaskWrapper):
    """Wrapper for periodic/scheduled task functions.

    Extends TaskWrapper with scheduling capabilities.
    """

    def __init__(
        self,
        func: Callable[..., ALL | Awaitable[ALL]],
        name: str,
        queue: str,
        retry: int,
        timeout: float,
        cron: str | None = None,
        interval: float | None = None,
    ) -> None:
        """Initialize the periodic task wrapper.

        Args:
            func: The wrapped task function.
            name: The task name.
            queue: The queue name.
            retry: Maximum retry attempts.
            timeout: Execution timeout in seconds.
            cron: Cron expression for scheduling (e.g., "0 * * * *").
            interval: Interval in seconds between executions.

        """
        super().__init__(func, name, queue, retry, timeout)
        self._cron = cron
        self._interval = interval

    @property
    def cron(self) -> str | None:
        """Get the cron expression."""
        return self._cron

    @property
    def interval(self) -> float | None:
        """Get the interval in seconds."""
        return self._interval

    def __repr__(self) -> str:
        """Return string representation."""
        schedule = f"cron={self._cron!r}" if self._cron else f"interval={self._interval}s"
        return f"<PeriodicTask name={self._name!r} {schedule}>"


@overload
def task(func: F) -> TaskWrapper: ...


@overload
def task(
    *,
    name: str | None = None,
    queue: str = "default",
    retry: int = 3,
    timeout: float = 300.0,
) -> Callable[[F], TaskWrapper]: ...


def task(
    func: F | None = None,
    *,
    name: str | None = None,
    queue: str = "default",
    retry: int = 3,
    timeout: float = 300.0,
) -> TaskWrapper | Callable[[F], TaskWrapper]:
    """Decorator to register a function as a task.

    Can be used with or without arguments:

        @task
        async def my_task():
            pass

        @task(name="custom_name", retry=5)
        async def my_task():
            pass

    Args:
        func: The function to wrap (when used without parentheses).
        name: Optional task name. Defaults to function name.
        queue: Queue name for the task.
        retry: Maximum number of retry attempts.
        timeout: Task execution timeout in seconds.

    Returns:
        TaskWrapper instance or decorator function.

    """

    def decorator(f: F) -> TaskWrapper:
        task_name = name or f.__name__
        registry = get_registry()
        registry.register(
            func=f,
            name=task_name,
            queue=queue,
            retry=retry,
            timeout=timeout,
        )
        return TaskWrapper(
            func=f,
            name=task_name,
            queue=queue,
            retry=retry,
            timeout=timeout,
        )

    if func is not None:
        return decorator(func)

    return decorator


def periodic_task(
    *,
    name: str | None = None,
    queue: str = "default",
    retry: int = 3,
    timeout: float = 300.0,
    cron: str | None = None,
    interval: float | None = None,
) -> Callable[[F], PeriodicTaskWrapper]:
    """Decorator to register a function as a periodic/scheduled task.

    Must specify either cron or interval for scheduling:

        @periodic_task(cron="0 * * * *")  # Every hour
        async def hourly_cleanup():
            pass

        @periodic_task(interval=60.0)  # Every 60 seconds
        async def check_health():
            pass

    Args:
        name: Optional task name. Defaults to function name.
        queue: Queue name for the task.
        retry: Maximum number of retry attempts.
        timeout: Task execution timeout in seconds.
        cron: Cron expression for scheduling.
        interval: Interval in seconds between executions.

    Returns:
        Decorator function that creates PeriodicTaskWrapper.

    Raises:
        ValueError: If neither cron nor interval is specified.

    """
    if cron is None and interval is None:
        msg = "Either 'cron' or 'interval' must be specified for periodic tasks"
        raise ValueError(msg)

    def decorator(f: F) -> PeriodicTaskWrapper:
        task_name = name or f.__name__
        registry = get_registry()
        registry.register(
            func=f,
            name=task_name,
            queue=queue,
            retry=retry,
            timeout=timeout,
        )
        return PeriodicTaskWrapper(
            func=f,
            name=task_name,
            queue=queue,
            retry=retry,
            timeout=timeout,
            cron=cron,
            interval=interval,
        )

    return decorator

