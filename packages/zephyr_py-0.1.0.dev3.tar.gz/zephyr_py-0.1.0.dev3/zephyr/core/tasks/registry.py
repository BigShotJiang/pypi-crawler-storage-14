"""Task registry for managing registered tasks.

This module provides a singleton TaskRegistry for storing and retrieving
task metadata. Tasks are registered via decorators and looked up by name.
"""

from __future__ import annotations

import asyncio
import threading
from typing import TYPE_CHECKING
from collections.abc import Callable

from zephyr.core.tasks.base import TaskMetadata
from zephyr.core.tasks.exceptions import (
    TaskAlreadyRegisteredError,
    TaskNotFoundError,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable

    from zephyr._types import ALL


class TaskRegistry:
    """Singleton registry for task registration and lookup.

    This class maintains a thread-safe registry of all registered tasks,
    allowing lookup by name or function reference.
    """

    _instance: TaskRegistry | None = None
    _lock: threading.Lock = threading.Lock()

    def __new__(cls) -> TaskRegistry:
        """Create or return the singleton instance.

        Returns:
            The singleton TaskRegistry instance.

        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        """Initialize the registry."""
        if getattr(self, "_initialized", False):
            return

        self._tasks: dict[str, TaskMetadata] = {}
        self._func_to_name: dict[int, str] = {}  # func id -> task name
        self._initialized = True

    def register(
        self,
        func: Callable[..., ALL | Awaitable[ALL]],
        name: str | None = None,
        queue: str = "default",
        retry: int = 3,
        timeout: float = 300.0,
    ) -> TaskMetadata:
        """Register a task function.

        Args:
            func: The task function to register.
            name: Optional task name. Defaults to function name.
            queue: Queue name for the task.
            retry: Maximum number of retry attempts.
            timeout: Task execution timeout in seconds.

        Returns:
            The TaskMetadata for the registered task.

        Raises:
            TaskAlreadyRegisteredError: If a task with the same name exists.

        """
        task_name = name or func.__name__

        if task_name in self._tasks:
            raise TaskAlreadyRegisteredError(task_name)

        is_async = asyncio.iscoroutinefunction(func)

        metadata = TaskMetadata(
            name=task_name,
            func=func,
            queue=queue,
            retry=retry,
            timeout=timeout,
            is_async=is_async,
        )

        self._tasks[task_name] = metadata
        self._func_to_name[id(func)] = task_name

        return metadata

    def unregister(self, name: str) -> None:
        """Unregister a task by name.

        Args:
            name: The task name to unregister.

        Raises:
            TaskNotFoundError: If the task is not found.

        """
        if name not in self._tasks:
            raise TaskNotFoundError(name)

        metadata = self._tasks.pop(name)
        func_id = id(metadata.func)
        self._func_to_name.pop(func_id, None)

    def get(self, name: str) -> TaskMetadata:
        """Get task metadata by name.

        Args:
            name: The task name to look up.

        Returns:
            The TaskMetadata for the task.

        Raises:
            TaskNotFoundError: If the task is not found.

        """
        if name not in self._tasks:
            raise TaskNotFoundError(name)

        return self._tasks[name]

    def get_by_func(self, func: Callable[..., ALL | Awaitable[ALL]]) -> TaskMetadata:
        """Get task metadata by function reference.

        Args:
            func: The function to look up.

        Returns:
            The TaskMetadata for the task.

        Raises:
            TaskNotFoundError: If the task is not found.

        """
        func_id = id(func)
        if func_id not in self._func_to_name:
            raise TaskNotFoundError(f"<function {func.__name__}>")

        task_name = self._func_to_name[func_id]
        return self._tasks[task_name]

    def exists(self, name: str) -> bool:
        """Check if a task is registered.

        Args:
            name: The task name to check.

        Returns:
            True if the task exists, False otherwise.

        """
        return name in self._tasks

    def list_tasks(self) -> list[TaskMetadata]:
        """List all registered tasks.

        Returns:
            List of TaskMetadata for all registered tasks.

        """
        return list(self._tasks.values())

    def list_task_names(self) -> list[str]:
        """List all registered task names.

        Returns:
            List of task names.

        """
        return list(self._tasks.keys())

    def clear(self) -> None:
        """Clear all registered tasks."""
        self._tasks.clear()
        self._func_to_name.clear()

    @property
    def count(self) -> int:
        """Get the number of registered tasks.

        Returns:
            Number of registered tasks.

        """
        return len(self._tasks)

    @classmethod
    def get_instance(cls) -> TaskRegistry:
        """Get the singleton instance.

        Returns:
            The singleton TaskRegistry instance.

        """
        return cls()

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton instance (for testing)."""
        with cls._lock:
            if cls._instance is not None:
                cls._instance._tasks.clear()
                cls._instance._func_to_name.clear()
                cls._instance = None


# Global registry instance
_registry = TaskRegistry()


def get_registry() -> TaskRegistry:
    """Get the global task registry.

    Returns:
        The global TaskRegistry instance.

    """
    return _registry

