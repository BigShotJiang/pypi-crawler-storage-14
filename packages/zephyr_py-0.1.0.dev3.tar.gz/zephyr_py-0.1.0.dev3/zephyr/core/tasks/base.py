"""Abstract base classes for the Zephyr task system.

This module defines the abstract interfaces for task backends and result stores,
ensuring consistent behavior across different implementations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, UTC
from enum import Enum
from typing import TYPE_CHECKING
from collections.abc import Callable

if TYPE_CHECKING:
    from collections.abc import Awaitable

    from zephyr._types import ALL


class TaskStatus(Enum):
    """Enumeration of possible task states."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILURE = "failure"
    RETRY = "retry"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


@dataclass
class TaskMetadata:
    """Metadata for a registered task.

    Attributes:
        name: Unique task name.
        func: The callable task function.
        queue: The queue name for the task.
        retry: Maximum number of retry attempts.
        timeout: Task execution timeout in seconds.
        is_async: Whether the task function is async.

    """

    name: str
    func: Callable[..., ALL | Awaitable[ALL]]
    queue: str = "default"
    retry: int = 3
    timeout: float = 300.0
    is_async: bool = False


@dataclass
class TaskResult:
    """Result of a task execution.

    Attributes:
        task_id: Unique identifier for the task execution.
        task_name: Name of the executed task.
        status: Current status of the task.
        result: The return value if successful.
        error: Error message if failed.
        created_at: When the task was created.
        started_at: When execution started.
        completed_at: When execution completed.
        retries: Number of retry attempts made.

    """

    task_id: str
    task_name: str
    status: TaskStatus = TaskStatus.PENDING
    result: ALL = None
    error: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    retries: int = 0

    def to_dict(self) -> dict[str, ALL]:
        """Convert TaskResult to dictionary for serialization.

        Returns:
            Dictionary representation of the task result.

        """
        return {
            "task_id": self.task_id,
            "task_name": self.task_name,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "retries": self.retries,
        }

    @classmethod
    def from_dict(cls, data: dict[str, ALL]) -> TaskResult:
        """Create TaskResult from dictionary.

        Args:
            data: Dictionary containing task result data.

        Returns:
            TaskResult instance.

        """
        status_value = data.get("status", "pending")
        status = TaskStatus(status_value) if isinstance(status_value, str) else TaskStatus.PENDING

        created_at = data.get("created_at")
        started_at = data.get("started_at")
        completed_at = data.get("completed_at")

        return cls(
            task_id=str(data.get("task_id", "")),
            task_name=str(data.get("task_name", "")),
            status=status,
            result=data.get("result"),
            error=str(data["error"]) if data.get("error") else None,
            created_at=datetime.fromisoformat(str(created_at)) if created_at else datetime.now(UTC),
            started_at=datetime.fromisoformat(str(started_at)) if started_at else None,
            completed_at=datetime.fromisoformat(str(completed_at)) if completed_at else None,
            retries=int(data.get("retries", 0)),
        )


class ResultStoreBackend(ABC):
    """Abstract base class for result storage backends.

    Result stores persist task execution results and provide
    retrieval capabilities.
    """

    @abstractmethod
    async def store(self, result: TaskResult, ttl: int | None = None) -> None:
        """Store a task result.

        Args:
            result: The TaskResult to store.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            ResultStoreError: If the store operation fails.

        """

    @abstractmethod
    async def get(self, task_id: str) -> TaskResult | None:
        """Retrieve a task result by ID.

        Args:
            task_id: The unique task identifier.

        Returns:
            The TaskResult or None if not found.

        Raises:
            ResultStoreError: If the get operation fails.

        """

    @abstractmethod
    async def delete(self, task_id: str) -> None:
        """Delete a task result.

        Args:
            task_id: The unique task identifier.

        Raises:
            ResultStoreError: If the delete operation fails.

        """

    @abstractmethod
    async def exists(self, task_id: str) -> bool:
        """Check if a task result exists.

        Args:
            task_id: The unique task identifier.

        Returns:
            True if the result exists, False otherwise.

        """

    @abstractmethod
    async def list_tasks(
        self,
        status: TaskStatus | None = None,
        limit: int = 100,
    ) -> list[TaskResult]:
        """List task results with optional filtering.

        Args:
            status: Filter by task status. If None, returns all.
            limit: Maximum number of results to return.

        Returns:
            List of TaskResult objects.

        """

    @abstractmethod
    async def cleanup_expired(self) -> int:
        """Remove expired task results.

        Returns:
            Number of results removed.

        """

    @abstractmethod
    async def close(self) -> None:
        """Close the result store connection."""


class JobQueueBackend(ABC):
    """Abstract base class for job queue backends.

    Job queue backends handle distributed task execution
    via message brokers like Redis, RabbitMQ, etc.
    """

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if the backend is connected to the broker.

        Returns:
            True if connected, False otherwise.

        """

    @abstractmethod
    async def connect(self) -> None:
        """Connect to the message broker.

        Raises:
            BackendConnectionError: If connection fails.

        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from the message broker."""

    @abstractmethod
    async def submit(
        self,
        task_name: str,
        task_id: str,
        args: tuple[ALL, ...],
        kwargs: dict[str, ALL],
        queue: str = "default",
    ) -> str:
        """Submit a task to the job queue.

        Args:
            task_name: Name of the registered task.
            task_id: Unique identifier for this execution.
            args: Positional arguments for the task.
            kwargs: Keyword arguments for the task.
            queue: Queue name to submit to.

        Returns:
            The task ID.

        Raises:
            BackendError: If submission fails.

        """

    @abstractmethod
    async def cancel(self, task_id: str) -> bool:
        """Cancel a pending or running task.

        Args:
            task_id: The task ID to cancel.

        Returns:
            True if cancelled successfully, False otherwise.

        """

    @abstractmethod
    async def get_status(self, task_id: str) -> TaskStatus | None:
        """Get the status of a task.

        Args:
            task_id: The task ID to check.

        Returns:
            The task status or None if not found.

        """

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the backend is healthy.

        Returns:
            True if healthy, False otherwise.

        """

