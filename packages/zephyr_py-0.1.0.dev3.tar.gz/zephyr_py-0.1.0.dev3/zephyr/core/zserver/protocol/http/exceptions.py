class HTTPError(Exception):
    """Base class for HTTP related errors."""


class HTTPParserError(HTTPError):
    """Base class for parser related errors."""


class HTTPParserUpgrade(HTTPParserError):
    """Raised when a HTTP parser upgrade is requested."""


class InvalidRequestLine(HTTPParserError):
    """Raised when the request line is malformed."""


class InvalidHeader(HTTPParserError):
    """Raised when a header is malformed."""


class InvalidChunkSize(HTTPParserError):
    """Raised when a chunk size is invalid in chunked encoding."""


class PayloadTooLarge(HTTPParserError):
    """Raised when the payload exceeds maximum allowed size."""


class BufferError(HTTPError):
    """Base class for buffer related errors."""


class BufferOverflowError(BufferError):
    """Raised when buffer size exceeds maximum allowed."""


class HTTPProtocolError(HTTPError):
    """HTTP Protocol Base error."""
