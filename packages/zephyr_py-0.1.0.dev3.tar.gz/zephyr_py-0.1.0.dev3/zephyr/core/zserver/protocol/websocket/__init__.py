"""WebSocket protocol implementation for Zephyr server."""

from zephyr.core.zserver.protocol.websocket.ws_protocol import WebSocketProtocol

__all__ = ["WebSocketProtocol"]
