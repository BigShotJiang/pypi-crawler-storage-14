"""Network-related constants for the Zephyr server."""

# Default buffer size (64KB) for network operations
DEFAULT_BUFFER_SIZE = 65536  # 64 * 1024
