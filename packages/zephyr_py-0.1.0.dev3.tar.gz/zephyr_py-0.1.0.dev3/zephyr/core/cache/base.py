"""Abstract base class for cache backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class CacheBackend(ABC):
    """Abstract base class for cache backends.

    All cache backends must inherit from this class and implement
    the required methods.
    """

    @abstractmethod
    async def get(self, key: str) -> Any | None:
        """Retrieve a value from cache by key.

        Args:
            key: The cache key to retrieve.

        Returns:
            The cached value or None if not found.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Store a value in cache with optional TTL.

        Args:
            key: The cache key.
            value: The value to cache.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete a value from cache.

        Args:
            key: The cache key to delete.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if a key exists in cache.

        Args:
            key: The cache key to check.

        Returns:
            True if the key exists, False otherwise.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def clear(self) -> None:
        """Clear all values from cache.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Retrieve multiple values from cache.

        Args:
            keys: List of cache keys to retrieve.

        Returns:
            Dictionary mapping keys to cached values (missing keys excluded).

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def set_many(self, data: dict[str, Any], ttl: int | None = None) -> None:
        """Store multiple values in cache.

        Args:
            data: Dictionary of key-value pairs to cache.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def delete_many(self, keys: list[str]) -> None:
        """Delete multiple values from cache.

        Args:
            keys: List of cache keys to delete.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def increment(self, key: str, delta: int = 1) -> int:
        """Increment a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to increment by (default: 1).

        Returns:
            The new value after incrementing.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def decrement(self, key: str, delta: int = 1) -> int:
        """Decrement a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to decrement by (default: 1).

        Returns:
            The new value after decrementing.

        Raises:
            CacheError: If the cache operation fails.

        """

    @abstractmethod
    async def close(self) -> None:
        """Close cache backend connections.

        Raises:
            CacheError: If the close operation fails.

        """

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the cache backend is healthy.

        Returns:
            True if healthy, False otherwise.

        """
