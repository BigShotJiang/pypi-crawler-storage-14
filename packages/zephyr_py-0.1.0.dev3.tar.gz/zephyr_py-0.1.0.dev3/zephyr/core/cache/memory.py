"""In-memory cache backend using LRU eviction."""

from __future__ import annotations

import asyncio
import time
from collections import OrderedDict
from typing import Any

from zephyr.core.cache.base import CacheBackend
from zephyr.core.cache.exceptions import CacheError


class MemoryCacheBackend(CacheBackend):
    """In-memory cache backend with LRU eviction and TTL support.

    This is the L1 cache layer suitable for single-instance deployments
    or as a local cache layer in multi-level caching.
    """

    def __init__(self, max_size: int = 10000, default_ttl: int = 300) -> None:
        """Initialize memory cache backend.

        Args:
            max_size: Maximum number of items to store (default: 10000).
            default_ttl: Default time-to-live in seconds (default: 300).

        """
        self._cache: OrderedDict[str, tuple[Any, float | None]] = OrderedDict()
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._lock = asyncio.Lock()
        self._hits = 0
        self._misses = 0

    async def get(self, key: str) -> Any | None:
        """Retrieve a value from cache by key.

        Args:
            key: The cache key to retrieve.

        Returns:
            The cached value or None if not found or expired.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                if key not in self._cache:
                    self._misses += 1
                    return None

                value, expiration = self._cache[key]

                # Check if expired
                if expiration is not None and time.time() > expiration:
                    del self._cache[key]
                    self._misses += 1
                    return None

                # Move to end (LRU)
                self._cache.move_to_end(key)
                self._hits += 1
                return value
        except Exception as e:
            raise CacheError(f"Failed to retrieve cache value for key '{key}': {e}") from e

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Store a value in cache with optional TTL.

        Args:
            key: The cache key.
            value: The value to cache.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                ttl_seconds = ttl if ttl is not None else self._default_ttl
                expiration = time.time() + ttl_seconds if ttl_seconds > 0 else None

                # Remove old entry if exists
                if key in self._cache:
                    del self._cache[key]

                # Check if we need to evict
                if len(self._cache) >= self._max_size:
                    # Remove oldest item (FIFO for the oldest)
                    oldest_key = next(iter(self._cache))
                    del self._cache[oldest_key]

                # Add new entry
                self._cache[key] = (value, expiration)
        except Exception as e:
            raise CacheError(f"Failed to set cache value for key '{key}': {e}") from e

    async def delete(self, key: str) -> None:
        """Delete a value from cache.

        Args:
            key: The cache key to delete.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                if key in self._cache:
                    del self._cache[key]
        except Exception as e:
            raise CacheError(f"Failed to delete cache value for key '{key}': {e}") from e

    async def exists(self, key: str) -> bool:
        """Check if a key exists in cache and is not expired.

        Args:
            key: The cache key to check.

        Returns:
            True if the key exists and is not expired, False otherwise.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                if key not in self._cache:
                    return False

                value, expiration = self._cache[key]

                # Check if expired
                if expiration is not None and time.time() > expiration:
                    del self._cache[key]
                    return False

                return True
        except Exception as e:
            raise CacheError(f"Failed to check cache key existence '{key}': {e}") from e

    async def clear(self) -> None:
        """Clear all values from cache.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                self._cache.clear()
                self._hits = 0
                self._misses = 0
        except Exception as e:
            raise CacheError(f"Failed to clear cache: {e}") from e

    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Retrieve multiple values from cache.

        Args:
            keys: List of cache keys to retrieve.

        Returns:
            Dictionary mapping keys to cached values (missing keys excluded).

        Raises:
            CacheError: If the operation fails.

        """
        try:
            result = {}
            async with self._lock:
                for key in keys:
                    if key in self._cache:
                        value, expiration = self._cache[key]
                        # Check if expired
                        if expiration is None or time.time() <= expiration:
                            result[key] = value
                            self._cache.move_to_end(key)
                            self._hits += 1
                        else:
                            del self._cache[key]
                            self._misses += 1
                    else:
                        self._misses += 1
            return result
        except Exception as e:
            raise CacheError(f"Failed to retrieve multiple cache values: {e}") from e

    async def set_many(self, data: dict[str, Any], ttl: int | None = None) -> None:
        """Store multiple values in cache.

        Args:
            data: Dictionary of key-value pairs to cache.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                ttl_seconds = ttl if ttl is not None else self._default_ttl
                expiration = time.time() + ttl_seconds if ttl_seconds > 0 else None

                for key, value in data.items():
                    # Remove old entry if exists
                    if key in self._cache:
                        del self._cache[key]

                    # Check if we need to evict
                    while len(self._cache) >= self._max_size:
                        oldest_key = next(iter(self._cache))
                        del self._cache[oldest_key]

                    # Add new entry
                    self._cache[key] = (value, expiration)
        except Exception as e:
            raise CacheError(f"Failed to set multiple cache values: {e}") from e

    async def delete_many(self, keys: list[str]) -> None:
        """Delete multiple values from cache.

        Args:
            keys: List of cache keys to delete.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                for key in keys:
                    if key in self._cache:
                        del self._cache[key]
        except Exception as e:
            raise CacheError(f"Failed to delete multiple cache values: {e}") from e

    async def increment(self, key: str, delta: int = 1) -> int:
        """Increment a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to increment by (default: 1).

        Returns:
            The new value after incrementing.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            async with self._lock:
                if key not in self._cache:
                    value = delta
                    expiration = time.time() + self._default_ttl
                    self._cache[key] = (value, expiration)
                    return value

                current_value, expiration = self._cache[key]

                # Check if expired
                if expiration is not None and time.time() > expiration:
                    del self._cache[key]
                    value = delta
                    expiration = time.time() + self._default_ttl
                    self._cache[key] = (value, expiration)
                    return value

                # Increment
                if not isinstance(current_value, int):
                    raise TypeError(f"Cannot increment non-integer value: {type(current_value)}")

                new_value = current_value + delta
                self._cache[key] = (new_value, expiration)
                self._cache.move_to_end(key)
                return new_value
        except Exception as e:
            raise CacheError(f"Failed to increment cache value for key '{key}': {e}") from e

    async def decrement(self, key: str, delta: int = 1) -> int:
        """Decrement a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to decrement by (default: 1).

        Returns:
            The new value after decrementing.

        Raises:
            CacheError: If the operation fails.

        """
        return await self.increment(key, -delta)

    async def close(self) -> None:
        """Close cache backend connections (no-op for memory cache)."""
        async with self._lock:
            self._cache.clear()

    async def health_check(self) -> bool:
        """Check if the cache backend is healthy.

        Returns:
            Always True for memory cache.

        """
        return True

    def get_stats(self) -> dict[str, int]:
        """Get cache statistics.

        Returns:
            Dictionary with cache stats (hits, misses, size).

        """
        return {
            "hits": self._hits,
            "misses": self._misses,
            "size": len(self._cache),
            "max_size": self._max_size,
        }
