"""Cache manager facade for convenient cache operations."""

from __future__ import annotations

from typing import Any

from zephyr.core.cache.base import CacheBackend
from zephyr.core.cache.exceptions import CacheError
from zephyr.core.cache.memory import MemoryCacheBackend
from zephyr.core.cache.multi_level import MultiLevelCacheBackend
from zephyr.core.cache.redis import RedisCacheBackend


class CacheManager:
    """Facade for cache operations with factory pattern for backend selection."""

    _instance: CacheManager | None = None
    _backend: CacheBackend | None = None

    def __new__(cls) -> CacheManager:
        """Implement singleton pattern."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        """Initialize cache manager."""

    @classmethod
    def configure(
        cls,
        backend_type: str = "memory",
        default_ttl: int = 300,
        memory_max_size: int = 10000,
        redis_url: str | None = None,
        enable_compression: bool = True,
        key_prefix: str = "zephyr:cache:",
    ) -> CacheManager:
        """Configure and initialize cache backend.

        Args:
            backend_type: Type of backend ('memory', 'redis', or 'multi-level').
            default_ttl: Default TTL in seconds.
            memory_max_size: Max size for memory backend.
            redis_url: Redis connection URL (required for redis/multi-level).
            enable_compression: Enable compression for Redis backend.
            key_prefix: Prefix for all cache keys.

        Returns:
            CacheManager instance.

        Raises:
            CacheError: If backend configuration fails.

        """
        instance = cls()

        try:
            if backend_type == "memory":
                instance._backend = MemoryCacheBackend(
                    max_size=memory_max_size,
                    default_ttl=default_ttl,
                )
            elif backend_type == "redis":
                if not redis_url:
                    raise CacheError("redis_url required for Redis backend")
                instance._backend = RedisCacheBackend(
                    url=redis_url,
                    default_ttl=default_ttl,
                    enable_compression=enable_compression,
                    key_prefix=key_prefix,
                )
            elif backend_type == "multi-level":
                if not redis_url:
                    raise CacheError("redis_url required for multi-level backend")
                l1 = MemoryCacheBackend(
                    max_size=memory_max_size,
                    default_ttl=default_ttl,
                )
                l2 = RedisCacheBackend(
                    url=redis_url,
                    default_ttl=default_ttl,
                    enable_compression=enable_compression,
                    key_prefix=key_prefix,
                )
                instance._backend = MultiLevelCacheBackend(l1_backend=l1, l2_backend=l2)
            else:
                raise CacheError(f"Unknown backend type: {backend_type}")

            return instance
        except CacheError:
            raise
        except Exception as e:
            raise CacheError(f"Failed to configure cache: {e}") from e

    def get_backend(self) -> CacheBackend:
        """Get the configured cache backend.

        Returns:
            The configured cache backend.

        Raises:
            CacheError: If no backend is configured.

        """
        if self._backend is None:
            raise CacheError("Cache backend not configured. Call configure() first.")
        return self._backend

    async def get(self, key: str) -> Any | None:
        """Retrieve a value from cache.

        Args:
            key: The cache key.

        Returns:
            The cached value or None.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        return await backend.get(key)

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Store a value in cache.

        Args:
            key: The cache key.
            value: The value to cache.
            ttl: Optional TTL in seconds.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        await backend.set(key, value, ttl)

    async def delete(self, key: str) -> None:
        """Delete a value from cache.

        Args:
            key: The cache key.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        await backend.delete(key)

    async def exists(self, key: str) -> bool:
        """Check if a key exists in cache.

        Args:
            key: The cache key.

        Returns:
            True if the key exists, False otherwise.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        return await backend.exists(key)

    async def clear(self) -> None:
        """Clear all cache values.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        await backend.clear()

    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Retrieve multiple values from cache.

        Args:
            keys: List of cache keys.

        Returns:
            Dictionary of key-value pairs.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        return await backend.get_many(keys)

    async def set_many(self, data: dict[str, Any], ttl: int | None = None) -> None:
        """Store multiple values in cache.

        Args:
            data: Dictionary of key-value pairs.
            ttl: Optional TTL in seconds.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        await backend.set_many(data, ttl)

    async def delete_many(self, keys: list[str]) -> None:
        """Delete multiple values from cache.

        Args:
            keys: List of cache keys.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        await backend.delete_many(keys)

    async def increment(self, key: str, delta: int = 1) -> int:
        """Increment a numeric value in cache.

        Args:
            key: The cache key.
            delta: Amount to increment.

        Returns:
            The new value.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        return await backend.increment(key, delta)

    async def decrement(self, key: str, delta: int = 1) -> int:
        """Decrement a numeric value in cache.

        Args:
            key: The cache key.
            delta: Amount to decrement.

        Returns:
            The new value.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        return await backend.decrement(key, delta)

    async def close(self) -> None:
        """Close cache backend connections.

        Raises:
            CacheError: If the operation fails.

        """
        backend = self.get_backend()
        await backend.close()

    async def health_check(self) -> bool:
        """Check if cache backend is healthy.

        Returns:
            True if healthy, False otherwise.

        """
        try:
            backend = self.get_backend()
            return await backend.health_check()
        except Exception:
            return False

    @classmethod
    def reset(cls) -> None:
        """Reset singleton instance (useful for testing)."""
        if cls._instance is not None and cls._instance._backend is not None:
            try:
                import asyncio

                asyncio.run(cls._instance._backend.close())
            except Exception:
                pass
        cls._instance = None
