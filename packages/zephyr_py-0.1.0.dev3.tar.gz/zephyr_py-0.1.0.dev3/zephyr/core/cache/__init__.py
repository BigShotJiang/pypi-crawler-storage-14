"""Caching module for Zephyr framework.

Provides multi-backend caching support with memory, Redis, and Memcached backends.
"""

from __future__ import annotations

from zephyr.core.cache.base import CacheBackend
from zephyr.core.cache.decorators import cache, cache_with_tags, invalidate_cache
from zephyr.core.cache.exceptions import CacheConnectionError, CacheError, CacheKeyError
from zephyr.core.cache.manager import CacheManager
from zephyr.core.cache.memory import MemoryCacheBackend
from zephyr.core.cache.multi_level import MultiLevelCacheBackend

__all__ = [
    "CacheBackend",
    "CacheConnectionError",
    "CacheError",
    "CacheKeyError",
    "CacheManager",
    "MemoryCacheBackend",
    "MultiLevelCacheBackend",
    "cache",
    "cache_with_tags",
    "invalidate_cache",
]
