"""Multi-level cache backend with L1 (memory) and L2 (Redis/Memcached) fallback."""

from __future__ import annotations

from typing import Any

from zephyr.core.cache.base import CacheBackend
from zephyr.core.cache.exceptions import CacheError


class MultiLevelCacheBackend(CacheBackend):
    """Multi-level cache with L1 (memory) and L2 (Redis/Memcached) backends.

    Implements write-through strategy by default:
    - GET: Try L1, fallback to L2, populate L1 if found in L2
    - SET: Write to both L1 and L2
    - DELETE: Delete from both L1 and L2

    L2 failures are gracefully handled with fallback to L1 only.
    """

    def __init__(
        self,
        l1_backend: CacheBackend,
        l2_backend: CacheBackend | None = None,
        write_through: bool = True,
    ) -> None:
        """Initialize multi-level cache backend.

        Args:
            l1_backend: L1 cache backend (typically memory).
            l2_backend: L2 cache backend (typically Redis). Optional.
            write_through: If True, write to both L1 and L2. If False, write to L1 only.

        """
        self._l1 = l1_backend
        self._l2 = l2_backend
        self._write_through = write_through

    async def get(self, key: str) -> Any | None:
        """Retrieve a value using multi-level strategy.

        Args:
            key: The cache key to retrieve.

        Returns:
            The cached value or None if not found.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Try L1 first
            value = await self._l1.get(key)
            if value is not None:
                return value

            # Try L2 if available
            if self._l2 is not None:
                try:
                    value = await self._l2.get(key)
                    if value is not None:
                        # Populate L1 from L2
                        await self._l1.set(key, value)
                        return value
                except CacheError:
                    # L2 failed, return None
                    pass

            return None
        except Exception as e:
            raise CacheError(f"Multi-level cache GET failed for key '{key}': {e}") from e

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Store a value using multi-level strategy.

        Args:
            key: The cache key.
            value: The value to cache.
            ttl: Time-to-live in seconds.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Always write to L1
            await self._l1.set(key, value, ttl)

            # Write to L2 if available and enabled
            if self._write_through and self._l2 is not None:
                try:
                    await self._l2.set(key, value, ttl)
                except CacheError:
                    # L2 failed, continue with L1 only
                    pass
        except Exception as e:
            raise CacheError(f"Multi-level cache SET failed for key '{key}': {e}") from e

    async def delete(self, key: str) -> None:
        """Delete a value from all cache levels.

        Args:
            key: The cache key to delete.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Always delete from L1
            await self._l1.delete(key)

            # Delete from L2 if available
            if self._l2 is not None:
                try:
                    await self._l2.delete(key)
                except CacheError:
                    # L2 failed, continue
                    pass
        except Exception as e:
            raise CacheError(f"Multi-level cache DELETE failed for key '{key}': {e}") from e

    async def exists(self, key: str) -> bool:
        """Check if a key exists in any cache level.

        Args:
            key: The cache key to check.

        Returns:
            True if the key exists in L1 or L2, False otherwise.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Check L1 first
            if await self._l1.exists(key):
                return True

            # Check L2 if available
            if self._l2 is not None:
                try:
                    return await self._l2.exists(key)
                except CacheError:
                    # L2 failed, return result from L1
                    pass

            return False
        except Exception as e:
            raise CacheError(f"Multi-level cache EXISTS failed for key '{key}': {e}") from e

    async def clear(self) -> None:
        """Clear all values from all cache levels.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Always clear L1
            await self._l1.clear()

            # Clear L2 if available
            if self._l2 is not None:
                try:
                    await self._l2.clear()
                except CacheError:
                    # L2 failed, continue
                    pass
        except Exception as e:
            raise CacheError(f"Multi-level cache CLEAR failed: {e}") from e

    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Retrieve multiple values using multi-level strategy.

        Args:
            keys: List of cache keys to retrieve.

        Returns:
            Dictionary mapping keys to cached values.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            result = {}

            # Get from L1
            l1_result = await self._l1.get_many(keys)
            result.update(l1_result)

            # Get missing keys from L2
            if self._l2 is not None:
                missing_keys = [k for k in keys if k not in result]
                if missing_keys:
                    try:
                        l2_result = await self._l2.get_many(missing_keys)
                        result.update(l2_result)

                        # Populate L1 with L2 results
                        await self._l1.set_many(l2_result)
                    except CacheError:
                        # L2 failed, continue with L1 results
                        pass

            return result
        except Exception as e:
            raise CacheError(f"Multi-level cache GET_MANY failed: {e}") from e

    async def set_many(self, data: dict[str, Any], ttl: int | None = None) -> None:
        """Store multiple values using multi-level strategy.

        Args:
            data: Dictionary of key-value pairs to cache.
            ttl: Time-to-live in seconds.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Always write to L1
            await self._l1.set_many(data, ttl)

            # Write to L2 if available and enabled
            if self._write_through and self._l2 is not None:
                try:
                    await self._l2.set_many(data, ttl)
                except CacheError:
                    # L2 failed, continue with L1 only
                    pass
        except Exception as e:
            raise CacheError(f"Multi-level cache SET_MANY failed: {e}") from e

    async def delete_many(self, keys: list[str]) -> None:
        """Delete multiple values from all cache levels.

        Args:
            keys: List of cache keys to delete.

        Raises:
            CacheError: If the L1 operation fails.

        """
        try:
            # Always delete from L1
            await self._l1.delete_many(keys)

            # Delete from L2 if available
            if self._l2 is not None:
                try:
                    await self._l2.delete_many(keys)
                except CacheError:
                    # L2 failed, continue
                    pass
        except Exception as e:
            raise CacheError(f"Multi-level cache DELETE_MANY failed: {e}") from e

    async def increment(self, key: str, delta: int = 1) -> int:
        """Increment a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to increment by (default: 1).

        Returns:
            The new value after incrementing.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            # Always increment in L1
            new_value = await self._l1.increment(key, delta)

            # Increment in L2 if available and enabled
            if self._write_through and self._l2 is not None:
                try:
                    await self._l2.increment(key, delta)
                except CacheError:
                    # L2 failed, continue with L1 result
                    pass

            return new_value
        except Exception as e:
            raise CacheError(f"Multi-level cache INCREMENT failed for key '{key}': {e}") from e

    async def decrement(self, key: str, delta: int = 1) -> int:
        """Decrement a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to decrement by (default: 1).

        Returns:
            The new value after decrementing.

        Raises:
            CacheError: If the operation fails.

        """
        return await self.increment(key, -delta)

    async def close(self) -> None:
        """Close all cache backends.

        Raises:
            CacheError: If close operation fails.

        """
        try:
            # Close L1
            await self._l1.close()

            # Close L2 if available
            if self._l2 is not None:
                try:
                    await self._l2.close()
                except CacheError:
                    # L2 close failed, continue
                    pass
        except Exception as e:
            raise CacheError(f"Multi-level cache CLOSE failed: {e}") from e

    async def health_check(self) -> bool:
        """Check if the cache backends are healthy.

        Returns:
            True if L1 is healthy (L2 is optional).

        """
        try:
            l1_healthy = await self._l1.health_check()

            # Check L2 if available
            l2_healthy = True
            if self._l2 is not None:
                try:
                    l2_healthy = await self._l2.health_check()
                except Exception:
                    l2_healthy = False

            return l1_healthy and (self._l2 is None or l2_healthy)
        except Exception:
            return False
