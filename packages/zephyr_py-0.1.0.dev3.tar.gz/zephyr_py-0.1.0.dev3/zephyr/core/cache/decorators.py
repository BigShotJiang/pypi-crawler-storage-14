"""Cache decorators for easy function result caching."""

from __future__ import annotations

import functools
import hashlib
from collections.abc import Callable
from typing import Any, TypeVar

from zephyr.core.cache.manager import CacheManager

F = TypeVar("F", bound=Callable[..., Any])


def _make_cache_key(
    func_name: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    prefix: str = "",
) -> str:
    """Generate a cache key from function and arguments.

    Args:
        func_name: Name of the function.
        args: Positional arguments.
        kwargs: Keyword arguments.
        prefix: Optional prefix for the key.

    Returns:
        A deterministic cache key.

    """
    # Create a string representation of arguments
    arg_parts = [str(arg) for arg in args]
    kwarg_parts = [f"{k}={v}" for k, v in sorted(kwargs.items())]
    arg_string = "|".join(arg_parts + kwarg_parts)

    # Hash the arguments for deterministic key
    arg_hash = hashlib.md5(arg_string.encode()).hexdigest()[:8]

    # Create the final key
    if prefix:
        return f"{prefix}:{func_name}:{arg_hash}"
    return f"{func_name}:{arg_hash}"


def cache(ttl: int | None = None, prefix: str = "") -> Callable[[F], F]:
    """Decorator to cache async function results.

    Args:
        ttl: Time-to-live in seconds. If None, uses cache default.
        prefix: Optional prefix for cache key.

    Returns:
        Decorated function that caches results.

    Example:
        @cache(ttl=3600)
        async def get_user(user_id: int) -> dict:
            # Expensive operation
            return await db.fetch_user(user_id)

    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Generate cache key
            cache_key = _make_cache_key(func.__name__, args, kwargs, prefix)

            # Try to get from cache
            manager = CacheManager()
            cached_value = await manager.get(cache_key)
            if cached_value is not None:
                return cached_value

            # Call original function
            result = await func(*args, **kwargs)

            # Store in cache
            await manager.set(cache_key, result, ttl)

            return result

        return wrapper  # type: ignore

    return decorator


def cache_with_tags(tags: list[str] | None = None, ttl: int | None = None) -> Callable[[F], F]:
    """Decorator to cache results with tags for selective invalidation.

    Args:
        tags: List of tags to associate with cached result.
        ttl: Time-to-live in seconds.

    Returns:
        Decorated function that caches results with tags.

    Example:
        @cache_with_tags(tags=['user:profile'], ttl=3600)
        async def get_user_profile(user_id: int) -> dict:
            return await db.fetch_user_profile(user_id)

    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Create tag-based key
            tags_str = "|".join(sorted(tags or []))
            cache_key = _make_cache_key(
                func.__name__,
                args,
                kwargs,
                prefix=tags_str,
            )

            # Try to get from cache
            manager = CacheManager()
            cached_value = await manager.get(cache_key)
            if cached_value is not None:
                return cached_value

            # Call original function
            result = await func(*args, **kwargs)

            # Store in cache (result is cached directly, tags are just for invalidation strategy)
            await manager.set(cache_key, result, ttl)

            return result

        return wrapper  # type: ignore

    return decorator


def invalidate_cache(tags: list[str] | None = None) -> Callable[[F], F]:
    """Decorator to invalidate cache entries matching tags after function execution.

    Args:
        tags: List of tags to match for invalidation (supports wildcards: 'user:*').

    Returns:
        Decorated function that invalidates cache after execution.

    Example:
        @invalidate_cache(tags=['user:profile'])
        async def update_user_profile(user_id: int, data: dict) -> dict:
            return await db.update_user_profile(user_id, data)

    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Execute the function first
            result = await func(*args, **kwargs)

            # Invalidate cache tags
            manager = CacheManager()
            if tags:
                for tag in tags:
                    if "*" in tag:
                        # Pattern-based invalidation (not fully implemented yet)
                        # For now, just clear the whole cache
                        await manager.clear()
                    else:
                        # Exact tag match - would need a tag registry
                        # For simplicity, we just clear cache for now
                        await manager.clear()

            return result

        return wrapper  # type: ignore

    return decorator
