"""Redis cache backend with compression and serialization support."""

from __future__ import annotations

import gzip
from typing import Any

import orjson
import redis.asyncio as redis

from zephyr.core.cache.base import CacheBackend
from zephyr.core.cache.exceptions import CacheConnectionError, CacheError


class RedisCacheBackend(CacheBackend):
    """Redis cache backend with compression and serialization.

    This is the L2 cache layer suitable for distributed deployments
    and multi-instance environments.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379/0",
        default_ttl: int = 300,
        enable_compression: bool = True,
        key_prefix: str = "zephyr:cache:",
    ) -> None:
        """Initialize Redis cache backend.

        Args:
            url: Redis connection URL (default: redis://localhost:6379/0).
            default_ttl: Default time-to-live in seconds (default: 300).
            enable_compression: Enable gzip compression for values (default: True).
            key_prefix: Prefix for all cache keys (default: "zephyr:cache:").

        Raises:
            CacheConnectionError: If Redis connection fails.

        """
        self._url = url
        self._default_ttl = default_ttl
        self._enable_compression = enable_compression
        self._key_prefix = key_prefix
        self._client: redis.Redis[bytes] | None = None

    async def _connect(self) -> None:
        """Establish Redis connection."""
        if self._client is None:
            try:
                self._client = await redis.from_url(
                    self._url,
                    decode_responses=False,
                    socket_connect_timeout=5,
                    socket_keepalive=True,
                    health_check_interval=30,
                )
                # Test connection
                await self._client.ping()
            except Exception as e:
                self._client = None
                raise CacheConnectionError(f"Failed to connect to Redis: {e}") from e

    def _make_key(self, key: str) -> str:
        """Generate prefixed cache key.

        Args:
            key: The original cache key.

        Returns:
            The prefixed cache key.

        """
        return f"{self._key_prefix}{key}"

    def _serialize(self, value: Any) -> bytes:
        """Serialize value to bytes.

        Args:
            value: The value to serialize.

        Returns:
            Serialized bytes.

        Raises:
            CacheError: If serialization fails.

        """
        try:
            serialized = orjson.dumps(value)
            if self._enable_compression:
                return gzip.compress(serialized)
            return serialized
        except Exception as e:
            raise CacheError(f"Serialization failed: {e}") from e

    def _deserialize(self, data: bytes) -> Any:
        """Deserialize bytes to value.

        Args:
            data: The serialized bytes.

        Returns:
            Deserialized value.

        Raises:
            CacheError: If deserialization fails.

        """
        try:
            if self._enable_compression:
                data = gzip.decompress(data)
            return orjson.loads(data)
        except Exception as e:
            raise CacheError(f"Deserialization failed: {e}") from e

    async def get(self, key: str) -> Any | None:
        """Retrieve a value from cache by key.

        Args:
            key: The cache key to retrieve.

        Returns:
            The cached value or None if not found.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return None

            prefixed_key = self._make_key(key)
            data = await self._client.get(prefixed_key)

            if data is None:
                return None

            return self._deserialize(data)
        except CacheError:
            raise
        except Exception as e:
            raise CacheError(f"Failed to retrieve cache value for key '{key}': {e}") from e

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Store a value in cache with optional TTL.

        Args:
            key: The cache key.
            value: The value to cache.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            prefixed_key = self._make_key(key)
            serialized = self._serialize(value)
            ttl_seconds = ttl if ttl is not None else self._default_ttl

            await self._client.setex(prefixed_key, ttl_seconds, serialized)
        except CacheError:
            raise
        except Exception as e:
            raise CacheError(f"Failed to set cache value for key '{key}': {e}") from e

    async def delete(self, key: str) -> None:
        """Delete a value from cache.

        Args:
            key: The cache key to delete.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            prefixed_key = self._make_key(key)
            await self._client.delete(prefixed_key)
        except Exception as e:
            raise CacheError(f"Failed to delete cache value for key '{key}': {e}") from e

    async def exists(self, key: str) -> bool:
        """Check if a key exists in cache.

        Args:
            key: The cache key to check.

        Returns:
            True if the key exists, False otherwise.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return False

            prefixed_key = self._make_key(key)
            result = await self._client.exists(prefixed_key)
            return result > 0
        except Exception as e:
            raise CacheError(f"Failed to check cache key existence '{key}': {e}") from e

    async def clear(self) -> None:
        """Clear all values from cache matching key prefix.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            pattern = f"{self._key_prefix}*"
            cursor = 0
            while True:
                cursor, keys = await self._client.scan(cursor, match=pattern, count=100)
                if keys:
                    await self._client.delete(*keys)
                if cursor == 0:
                    break
        except Exception as e:
            raise CacheError(f"Failed to clear cache: {e}") from e

    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Retrieve multiple values from cache.

        Args:
            keys: List of cache keys to retrieve.

        Returns:
            Dictionary mapping keys to cached values (missing keys excluded).

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return {}

            prefixed_keys = [self._make_key(key) for key in keys]
            values = await self._client.mget(prefixed_keys)

            result = {}
            for key, value in zip(keys, values, strict=False):
                if value is not None:
                    result[key] = self._deserialize(value)

            return result
        except CacheError:
            raise
        except Exception as e:
            raise CacheError(f"Failed to retrieve multiple cache values: {e}") from e

    async def set_many(self, data: dict[str, Any], ttl: int | None = None) -> None:
        """Store multiple values in cache.

        Args:
            data: Dictionary of key-value pairs to cache.
            ttl: Time-to-live in seconds. If None, uses default TTL.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            ttl_seconds = ttl if ttl is not None else self._default_ttl

            # Use pipeline for atomic operation
            async with self._client.pipeline(transaction=False) as pipe:
                for key, value in data.items():
                    prefixed_key = self._make_key(key)
                    serialized = self._serialize(value)
                    await pipe.setex(prefixed_key, ttl_seconds, serialized)
                await pipe.execute()
        except CacheError:
            raise
        except Exception as e:
            raise CacheError(f"Failed to set multiple cache values: {e}") from e

    async def delete_many(self, keys: list[str]) -> None:
        """Delete multiple values from cache.

        Args:
            keys: List of cache keys to delete.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return

            prefixed_keys = [self._make_key(key) for key in keys]
            await self._client.delete(*prefixed_keys)
        except Exception as e:
            raise CacheError(f"Failed to delete multiple cache values: {e}") from e

    async def increment(self, key: str, delta: int = 1) -> int:
        """Increment a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to increment by (default: 1).

        Returns:
            The new value after incrementing.

        Raises:
            CacheError: If the operation fails.

        """
        try:
            await self._connect()
            if self._client is None:
                return 0

            prefixed_key = self._make_key(key)
            new_value = await self._client.incrby(prefixed_key, delta)

            # Set expiration if it's a new key
            await self._client.expire(prefixed_key, self._default_ttl)

            return int(new_value)
        except Exception as e:
            raise CacheError(f"Failed to increment cache value for key '{key}': {e}") from e

    async def decrement(self, key: str, delta: int = 1) -> int:
        """Decrement a numeric value in cache.

        Args:
            key: The cache key.
            delta: The amount to decrement by (default: 1).

        Returns:
            The new value after decrementing.

        Raises:
            CacheError: If the operation fails.

        """
        return await self.increment(key, -delta)

    async def close(self) -> None:
        """Close Redis connection.

        Raises:
            CacheError: If the close operation fails.

        """
        try:
            if self._client is not None:
                await self._client.close()
                self._client = None
        except Exception as e:
            raise CacheError(f"Failed to close Redis connection: {e}") from e

    async def health_check(self) -> bool:
        """Check if the Redis backend is healthy.

        Returns:
            True if Redis is responding to PING, False otherwise.

        """
        try:
            await self._connect()
            if self._client is None:
                return False
            await self._client.ping()
            return True
        except Exception:
            return False
