"""Cache-specific exceptions for the Zephyr framework."""

from __future__ import annotations


class CacheError(Exception):
    """Base exception for cache operations."""


class CacheKeyError(CacheError):
    """Raised when a cache key is not found or invalid."""


class CacheConnectionError(CacheError):
    """Raised when a cache backend connection fails."""


class CacheBackendError(CacheError):
    """Raised when a cache backend operation fails."""


class CacheSerializationError(CacheError):
    """Raised when cache serialization/deserialization fails."""


class CacheEvictionError(CacheError):
    """Raised when cache eviction fails."""


class CacheTimeoutError(CacheError):
    """Raised when a cache operation times out."""
