"""Zephyr Framework Exceptions.

Author: A M (am@bbdevs.com)

Created At: Oct 02, 2025
"""

__all__ = ["BaseZephyrException", "PermissionDenied"]


class BaseZephyrException(Exception):
    """Base Zephyr exception class."""


class PermissionDenied(BaseZephyrException):
    """Exception raised when permission is denied (HTTP 403 Forbidden)."""

    def __init__(self, detail: str = "Permission denied") -> None:
        """Initialize PermissionDenied exception.

        Args:
            detail: Human-readable error message describing the permission denial.

        """
        self.detail = detail
        super().__init__(detail)
