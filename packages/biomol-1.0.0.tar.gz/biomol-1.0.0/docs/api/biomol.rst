BioMol
======

.. currentmodule:: biomol


Constructor
-----------

.. autosummary::
   :toctree: ./generated/BioMol
   :nosignatures:

   BioMol
   CIFMol


Utilities
---------

.. autosummary::
   :toctree: ./generated/BioMol
   :nosignatures:

   load_bytes
   to_bytes
