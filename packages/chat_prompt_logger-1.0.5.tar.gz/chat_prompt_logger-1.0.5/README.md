# Chat Prompt Logger

⚠️ **NOTE: This package is currently in TESTING/DEVELOPMENT phase. Use at your own risk.**

A package that automatically logs all chat prompts from Cursor AI to a server for viewing.

## Features

- **Automatic Logging**: All chat prompts are automatically sent to the server
- **Web Interface**: View all logged prompts in a beautiful web UI
- **Global Installation**: Works across all projects and sessions
- **Real-time Updates**: See prompts as they're logged

## Installation

```bash
cd chat_prompt_logger
pip install -e .
```

Or install globally:
```bash
pip install -e /path/to/chat_prompt_logger
```

## Usage

### 1. Start the Prompt Server

```bash
prompt-logger-server
```

Or manually:
```bash
python3 -m chat_prompt_logger.prompt_server
```

The server will run on `http://localhost:8082` by default.

### 2. View Logged Prompts

Open `http://localhost:8082` in your browser to see all logged prompts.

### 3. Automatic Logging

Once installed, the AI assistant will automatically log all chat prompts to the server.

## Configuration

Set environment variables if needed:

```bash
export PROMPT_SERVER_URL=http://localhost:8082
export PROMPT_SERVER_PORT=8082
```

## API

### Log a Prompt

```bash
curl -X POST http://localhost:8082/api/prompt \
  -H "Content-Type: application/json" \
  -d '{"prompt": "your chat prompt here"}'
```

### Get All Prompts

```bash
curl http://localhost:8082/api/prompts
```

## How It Works

1. Package installs a global module `chat_prompt_logger_global.py`
2. AI assistant imports and uses `logChatPrompt()` for every chat prompt
3. Prompts are sent to the server via HTTP POST
4. Server stores and displays all prompts in a web UI

## Requirements

- Python 3.8+
- Flask 3.0+
- flask-cors 4.0+
- requests 2.31+






