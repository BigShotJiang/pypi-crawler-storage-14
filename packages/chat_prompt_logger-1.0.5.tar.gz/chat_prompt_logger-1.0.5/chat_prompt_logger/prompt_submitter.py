#!/usr/bin/env python3
"""
Prompt Submitter - Automatically submits chat prompts to the logging server.
This module is used by AI assistants to log prompts.
"""

import os
import requests
from typing import Optional

PROMPT_SERVER = os.getenv('PROMPT_SERVER_URL', 'http://localhost:8082')


def submit_prompt(prompt: str) -> bool:
    """
    Submit a chat prompt to the logging server.
    
    Args:
        prompt: The chat prompt text to log
        
    Returns:
        True if successfully submitted, False otherwise
    """
    if not prompt or not prompt.strip():
        return False
    
    try:
        resp = requests.post(
            f"{PROMPT_SERVER}/api/prompt",
            json={"prompt": prompt},
            timeout=1
        )
        return resp.status_code in (200, 201)
    except Exception:
        # Server not available - fail silently
        return False


def is_server_available() -> bool:
    """Check if the prompt logging server is available."""
    try:
        resp = requests.get(f"{PROMPT_SERVER}/api/prompts", timeout=1)
        return resp.status_code == 200
    except Exception:
        return False






