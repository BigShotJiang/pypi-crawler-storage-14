#!/usr/bin/env python3
"""
Prompt Logging Server - Receives and displays all chat prompts.
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import os
from datetime import datetime
from typing import Dict
import threading

app = Flask(__name__)
CORS(app)

# In-memory storage for prompts
prompts_db: Dict[int, dict] = {}
next_prompt_id = 1
lock = threading.Lock()

# HTML template for viewing prompts
PROMPT_VIEWER_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Prompt Logger</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2.5em;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1em;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            flex: 1;
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            color: #666;
            margin-top: 5px;
        }
        .prompt-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }
        .prompt-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .prompt-id {
            font-weight: bold;
            color: #667eea;
            font-size: 1.1em;
        }
        .prompt-time {
            color: #999;
            font-size: 0.9em;
        }
        .prompt-text {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 1em;
            line-height: 1.6;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .no-prompts {
            text-align: center;
            color: #999;
            padding: 40px;
            font-size: 1.2em;
        }
        .filter-bar {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        input[type="text"] {
            flex: 1;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
    </style>
    <script>
        function filterPrompts() {
            const filter = document.getElementById('filter').value.toLowerCase();
            const cards = document.querySelectorAll('.prompt-card');
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                card.style.display = text.includes(filter) ? 'block' : 'none';
            });
        }
        // Auto-refresh every 3 seconds
        setInterval(() => {
            if (document.visibilityState === 'visible') {
                location.reload();
            }
        }, 3000);
    </script>
</head>
<body>
    <div class="container">
        <h1>Chat Prompt Logger</h1>
        <p class="subtitle">All chat prompts are automatically logged here</p>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{{ total_prompts }}</div>
                <div class="stat-label">Total Prompts</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{{ recent_prompts }}</div>
                <div class="stat-label">Last Hour</div>
            </div>
        </div>
        
        <div class="filter-bar">
            <input type="text" id="filter" placeholder="Search prompts..." onkeyup="filterPrompts()">
        </div>
        
        {% if prompts %}
            {% for prompt in prompts %}
            <div class="prompt-card">
                <div class="prompt-header">
                    <span class="prompt-id">Prompt #{{ prompt.id }}</span>
                    <span class="prompt-time">{{ prompt.created_at }}</span>
                </div>
                <div class="prompt-text">{{ prompt.text }}</div>
            </div>
            {% endfor %}
        {% else %}
            <div class="no-prompts">No prompts logged yet</div>
        {% endif %}
    </div>
</body>
</html>
"""


@app.route('/')
def index():
    """Serve the prompt viewer UI."""
    with lock:
        prompts = list(prompts_db.values())
        prompts.sort(key=lambda x: x['id'], reverse=True)
        
        # Calculate stats
        total = len(prompts)
        now = datetime.now()
        recent = sum(1 for p in prompts 
                    if (now - datetime.fromisoformat(p['created_at'])).seconds < 3600)
    
    return render_template_string(PROMPT_VIEWER_TEMPLATE, 
                                 prompts=prompts, 
                                 total_prompts=total,
                                 recent_prompts=recent)


@app.route('/api/prompt', methods=['POST'])
def log_prompt():
    """Log a chat prompt."""
    data = request.get_json()
    if not data or 'prompt' not in data:
        return jsonify({'error': 'Missing prompt'}), 400
    
    prompt_text = data['prompt'].strip()
    if not prompt_text:
        return jsonify({'error': 'Empty prompt'}), 400
    
    global next_prompt_id
    with lock:
        prompt_id = next_prompt_id
        next_prompt_id += 1
        
        prompts_db[prompt_id] = {
            'id': prompt_id,
            'text': prompt_text,
            'created_at': datetime.now().isoformat(),
        }
    
    return jsonify({
        'id': prompt_id,
        'message': 'Prompt logged successfully'
    }), 201


@app.route('/api/prompts', methods=['GET'])
def get_prompts():
    """Get all logged prompts."""
    with lock:
        prompts = list(prompts_db.values())
        prompts.sort(key=lambda x: x['id'], reverse=True)
    return jsonify({'prompts': prompts, 'count': len(prompts)})


@app.route('/api/prompts/<int:prompt_id>', methods=['GET'])
def get_prompt(prompt_id: int):
    """Get a specific prompt."""
    with lock:
        prompt = prompts_db.get(prompt_id)
    
    if not prompt:
        return jsonify({'error': 'Prompt not found'}), 404
    
    return jsonify(prompt)


def main():
    """Start the prompt logging server."""
    port = int(os.getenv('PROMPT_SERVER_PORT', 8082))
    host = os.getenv('PROMPT_SERVER_HOST', '0.0.0.0')
    print(f"🚀 Starting Chat Prompt Logger on http://{host}:{port}")
    print(f"📱 View prompts at http://localhost:{port}")
    print(f"📡 API endpoint: http://localhost:{port}/api/prompt")
    app.run(host=host, port=port, debug=True)


if __name__ == '__main__':
    main()

