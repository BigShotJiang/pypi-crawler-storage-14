from PIL import Image
import numpy as np
import os
from tqdm import tqdm
import cv2
import shutil

def binarizar_mascaras(directorio_entrada, directorio_salida, umbral=64):
    """
    Binariza todas las máscaras de un directorio y las guarda en otro directorio.

    Parámetros:
    - directorio_entrada: ruta donde están las máscaras originales.
    - directorio_salida: ruta donde se guardarán las máscaras binarizadas.
    - umbral: valor para convertir píxeles a 0 o 1.
    - tolerancia: para detectar si la máscara es casi binaria.
    - porcentaje_min: porcentaje mínimo de píxeles que deben estar cerca de 0 o 255.
    """
    if not os.path.exists(directorio_salida):
        os.makedirs(directorio_salida)

    for archivo in tqdm(os.listdir(directorio_entrada)):
        ruta_archivo = os.path.join(directorio_entrada, archivo)
        if not os.path.isfile(ruta_archivo):
            continue

        # Abrir y convertir a escala de grises
        imagen = Image.open(ruta_archivo).convert("L")
        pixeles = np.array(imagen)

        binario = (pixeles >= umbral).astype(np.uint8) * 255

        nombre_png = os.path.splitext(archivo)[0] + ".png"
        ruta_salida = os.path.join(directorio_salida, nombre_png)

        Image.fromarray(binario).save(ruta_salida, format="PNG")

def limpiar_nombre(directorio):

    for archivo in tqdm(os.listdir(directorio)):
        ruta_completa = os.path.join(directorio, archivo)
        
        nombre, extension = os.path.splitext(archivo)

        nuevo_nombre = nombre.replace("_mask", "") + extension
        nueva_ruta = os.path.join(directorio, nuevo_nombre)

        if ruta_completa != nueva_ruta:
            os.rename(ruta_completa, nueva_ruta)

def mover_imagenes_por_nombre(directorio_origen, directorio_destino, lista_nombres):
    # Asegurar que el destino exista
    os.makedirs(directorio_destino, exist_ok=True)
    len(lista_nombres)

    for archivo in tqdm(os.listdir(directorio_origen)):
        ruta_origen = os.path.join(directorio_origen, archivo)

        # Procesar solo archivos
        if not os.path.isfile(ruta_origen):
            continue

        nombre, extension = os.path.splitext(archivo)

        # Verificar si el nombre está en la lista/set
        if nombre in lista_nombres:
            ruta_destino = os.path.join(directorio_destino, archivo)
            shutil.move(ruta_origen, ruta_destino)

lista = {'CHNCXR_0037_0', 'CHNCXR_0342_1', 'CHNCXR_0484_1', 'CHNCXR_0491_1', 'CHNCXR_0486_1', 'CHNCXR_0199_0', 'CHNCXR_0485_1', 
         'CHNCXR_0025_0', 'CHNCXR_0502_1', 'CHNCXR_0360_1', 'CHNCXR_0505_1', 'CHNCXR_0188_0', 'CHNCXR_0182_0', 'CHNCXR_0208_0', 
         'CHNCXR_0218_0', 'CHNCXR_0481_1', 'CHNCXR_0215_0', 'CHNCXR_0343_1', 'CHNCXR_0195_0', 'CHNCXR_0341_1', 'CHNCXR_0219_0', 
         'CHNCXR_0488_1', 'CHNCXR_0560_1', 'CHNCXR_0200_0', 'CHNCXR_0065_0', 'CHNCXR_0190_0', 'CHNCXR_0352_1', 'CHNCXR_0494_1', 
         'CHNCXR_0186_0', 'CHNCXR_0355_1', 'CHNCXR_0499_1', 'CHNCXR_0500_1', 'CHNCXR_0209_0', 'CHNCXR_0211_0', 'CHNCXR_0192_0', 
         'CHNCXR_0206_0', 'CHNCXR_0489_1', 'CHNCXR_0213_0', 'CHNCXR_0356_1', 'CHNCXR_0354_1', 'CHNCXR_0189_0', 'CHNCXR_0036_0', 
         'CHNCXR_0358_1', 'CHNCXR_0196_0', 'CHNCXR_0351_1', 'CHNCXR_0210_0', 'CHNCXR_0204_0', 'CHNCXR_0562_1', 'CHNCXR_0496_1', 
         'CHNCXR_0198_0', 'CHNCXR_0498_1', 'CHNCXR_0493_1', 'CHNCXR_0497_1', 'CHNCXR_0561_1', 'CHNCXR_0194_0', 'CHNCXR_0350_1', 
         'CHNCXR_0492_1', 'CHNCXR_0357_1', 'CHNCXR_0205_0', 'CHNCXR_0187_0', 'CHNCXR_0038_0', 'CHNCXR_0345_1', 'CHNCXR_0207_0', 
         'CHNCXR_0214_0', 'CHNCXR_0359_1', 'CHNCXR_0185_0', 'CHNCXR_0347_1', 'CHNCXR_0217_0', 'CHNCXR_0487_1', 'CHNCXR_0495_1', 
         'CHNCXR_0039_0', 'CHNCXR_0353_1', 'CHNCXR_0348_1', 'CHNCXR_0336_1', 'CHNCXR_0201_0', 'CHNCXR_0346_1', 'CHNCXR_0349_1', 
         'CHNCXR_0482_1', 'CHNCXR_0564_1', 'CHNCXR_0197_0', 'CHNCXR_0490_1', 'CHNCXR_0212_0', 'CHNCXR_0202_0', 'CHNCXR_0483_1', 
         'CHNCXR_0344_1', 'CHNCXR_0040_0', 'CHNCXR_0565_1', 'CHNCXR_0563_1', 'CHNCXR_0216_0', 'CHNCXR_0203_0', 'CHNCXR_0184_0', 
         'CHNCXR_0181_0', 'CHNCXR_0193_0', 'CHNCXR_0220_0', 'CHNCXR_0191_0', 'CHNCXR_0183_0'}
mover_imagenes_por_nombre(r"C:\Users\joortif\Downloads\archive\Lung Segmentation\images", r"C:\Users\joortif\Downloads\archive\Lung Segmentation\discarded", lista)

