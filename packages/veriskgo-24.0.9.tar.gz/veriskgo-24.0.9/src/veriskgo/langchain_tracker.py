"""
Universal LangChain Tracker for VeriskGO.
Supports ALL LangChain versions and ALL Bedrock providers.
Extracts token metadata from every possible source.

Works with:
    - LCEL pipelines (invoke/ainvoke)
    - ChatBedrock.invoke()
    - ChatBedrock.ainvoke()
    - ChatBedrock.generate()
    - ChatBedrock.agenerate()
    - StrOutputParser() (plain string output)
"""

import time
import functools
import traceback
import inspect
import contextvars
from typing import Any, Dict, Optional, cast

from .trace_manager import TraceManager, serialize_value, calculate_cost


# =====================================================================
# Context variable to store usage across async pipeline calls
# =====================================================================


_last_lc_usage: contextvars.ContextVar[Optional[Dict[str, Any]]] = (
    contextvars.ContextVar("last_lc_usage", default=None)
)


# =====================================================================
# TOKEN EXTRACTOR (Universal)
# =====================================================================

def _extract_metadata_from_result(result: Any) -> Optional[Dict[str, Any]]:
    """
    Extract token metadata from ANY LangChain return value.

    Supports:
        - ChatGeneration
        - LLMResult
        - AIMessage
        - Any LangChain v1/v2 output wrappers
        - Any model: Anthropic, Llama, Titan, etc.
    """

    # Helper function to extract from dict-like objects
    def get_from_dict(data: Any, *keys):
        if isinstance(data, dict):
            for k in keys:
                if k in data:
                    return data[k]
        return None

    candidates = []

    # 1. Direct attributes
    for attr in ["generation_info", "response_metadata", "raw", "additional_kwargs"]:
        meta = getattr(result, attr, None)
        if isinstance(meta, dict):
            candidates.append(meta)

    # 2. Nested message metadata (common for Claude)
    msg = getattr(result, "message", None)
    if msg:
        for attr in ["response_metadata", "additional_kwargs"]:
            meta = getattr(msg, attr, None)
            if isinstance(meta, dict):
                candidates.append(meta)

    # 3. Partial Genset (LangChain >= v0.1.0)
    if hasattr(result, "generations"):
        gens = getattr(result, "generations", [])
        if isinstance(gens, list) and gens:
            g = gens[0]
            meta = getattr(g, "generation_info", None)
            if isinstance(meta, dict):
                candidates.append(meta)

    # Combine and normalize
    merged = {}
    for c in candidates:
        merged.update(c)

    if not merged:
        return None

    # Normalize token fields (ALL models)
    input_tokens = (
        merged.get("input_tokens") or
        merged.get("inputTokens") or
        merged.get("prompt_tokens") or
        merged.get("promptTokens") or
        merged.get("tokens_in") or
        0
    )

    output_tokens = (
        merged.get("output_tokens") or
        merged.get("outputTokens") or
        merged.get("completion_tokens") or
        merged.get("completionTokens") or
        merged.get("tokens_out") or
        0
    )

    return {
        "input_tokens": int(input_tokens),
        "output_tokens": int(output_tokens),
        "total_tokens": int(input_tokens) + int(output_tokens),
    }


# =====================================================================
# PATCH ChatBedrock invoke/ainvoke/generate/agenerate
# =====================================================================

def _patch_langchain_bedrock():
    """
    Universal patch across ALL versions of langchain_aws ChatBedrock.
    Works whether methods exist or not.
    """

    try:
        from langchain_aws import ChatBedrock
    except Exception:
        return

    def wrap_method(method_name: str):
        original = getattr(ChatBedrock, method_name, None)
        if not callable(original):
            return

        async def async_wrapper(self, *args, **kwargs):
            # Runtime: original may be coroutine → OK
            # Pylance: cast(Any, ...) removes awaitability error
            result = await cast(Any, original)(self, *args, **kwargs)

            meta = _extract_metadata_from_result(result)
            if meta:
                _last_lc_usage.set(meta)

            return result


        def sync_wrapper(self, *args, **kwargs):
            # Runtime: original may be sync → OK
            # Pylance: cast(Any, ...) removes "not callable" complaints
            result = cast(Any, original)(self, *args, **kwargs)

            meta = _extract_metadata_from_result(result)
            if meta:
                _last_lc_usage.set(meta)

            return result

        # Apply correct wrapper
        if inspect.iscoroutinefunction(original):
            setattr(ChatBedrock, method_name, async_wrapper)
        else:
            setattr(ChatBedrock, method_name, sync_wrapper)

    # Patch all possible entry points
    for method in ["invoke", "ainvoke", "generate", "agenerate"]:
        wrap_method(method)


_patch_langchain_bedrock()


# =====================================================================
# OUTPUT BUILDER
# =====================================================================

def _build_output(result: Any, model_id: str, latency: int):
    usage = _last_lc_usage.get() or {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0
    }

    cost = calculate_cost(usage)

    # Extract text from any return type
    if isinstance(result, tuple):
        text = result[0]
    elif isinstance(result, str):
        text = result
    else:
        text = serialize_value(result)

    return {
        "status": "success",
        "model": model_id,
        "latency_ms": latency,
        "output": {"text": text},
        "usage": usage,
        "usage_details": usage,
        "cost": cost,
        "cost_details": cost,
    }


# =====================================================================
# DECORATOR
# =====================================================================

def track_langchain(name: str = "langchain_call", *, model_id: str = "", tags=None):
    def decorator(func):
        is_async = inspect.iscoroutinefunction(func)

        async def async_wrapper(*args, **kwargs):
            if not TraceManager.has_active_trace():
                return await func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={"args": serialize_value(args), "kwargs": serialize_value(kwargs)},
                tags=tags,
            )

            start = time.time()
            try:
                result = await func(*args, **kwargs)
            except Exception as e:
                TraceManager.end_span(span_id, {
                    "status": "error",
                    "error": str(e),
                    "stacktrace": traceback.format_exc(),
                })
                raise

            latency = int((time.time() - start) * 1000)
            TraceManager.end_span(span_id, _build_output(result, model_id, latency))
            return result

        def sync_wrapper(*args, **kwargs):
            if not TraceManager.has_active_trace():
                return func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={"args": serialize_value(args), "kwargs": serialize_value(kwargs)},
                tags=tags,
            )

            start = time.time()
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                TraceManager.end_span(span_id, {
                    "status": "error",
                    "error": str(e),
                    "stacktrace": traceback.format_exc(),
                })
                raise

            latency = int((time.time() - start) * 1000)
            TraceManager.end_span(span_id, _build_output(result, model_id, latency))
            return result

        return functools.wraps(func)(async_wrapper if is_async else sync_wrapper)

    return decorator
