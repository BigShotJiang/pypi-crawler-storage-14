"""A module for "pure" processing: no IO, no use of custom Darfix classes."""
