# Audio Format MCP

进行音频格式转换的 MCP 服务，提供 `convert_audio_format` 工具。返回值为英文文本。

## 安装
```bash
pip install audio-format-mcp
```

## 运行
```bash
audio-format-mcp
```

## 工具
- `convert_audio_format(input_audio_path: str, output_audio_path: str, target_format: str) -> str`
  - 支持常见格式：mp3/aac/m4a/wma/wav/flac/ogg/opus
  - 自动选择合适编码器与容器（如 m4a->mp4, aac->adts）

## 示例
将 WAV 转 MP3：