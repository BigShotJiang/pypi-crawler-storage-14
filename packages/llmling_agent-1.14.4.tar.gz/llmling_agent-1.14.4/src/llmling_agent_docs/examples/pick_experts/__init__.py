"""Example: Using pick() and pick_multiple() for expert selection."""

TITLE = "Expert Selection"
ICON = "octicon:people-16"
