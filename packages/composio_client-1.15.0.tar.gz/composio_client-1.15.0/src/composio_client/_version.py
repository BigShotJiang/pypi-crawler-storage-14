# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "composio_client"
__version__ = "1.15.0"  # x-release-please-version
