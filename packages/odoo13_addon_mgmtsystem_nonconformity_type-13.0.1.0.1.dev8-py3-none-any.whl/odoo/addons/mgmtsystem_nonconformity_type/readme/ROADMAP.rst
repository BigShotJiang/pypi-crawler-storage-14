* manage Template Action on statistic analysis
