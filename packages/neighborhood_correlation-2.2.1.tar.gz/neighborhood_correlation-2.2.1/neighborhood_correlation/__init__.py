__version__ = "2.2.1"

from neighborhood_correlation.tool import main
