# Seven2one Corporate Design für MkDocs

Diese Stylesheets implementieren das Seven2one Corporate Design für die MkDocs-Dokumentation.

## Verwendete Farben

Basierend auf dem Corporate Design Manual (MV-Corporate Design-281025-131850.pdf):

### Primärfarben

| Farbe | HEX | RGB | Verwendung |
|-------|-----|-----|------------|
| Orange | `#EF8200` | 239, 130, 0 | Header (Light Mode), Buttons, Links Hover |
| Green | `#10A384` | 16, 163, 132 | Accent, Header (Dark Mode) |
| DarkGray | `#707070` | 112, 112, 112 | Überschriften, Footer |
| White | `#FFFFFF` | 255, 255, 255 | Text auf dunklem Grund |

### Sekundärfarben

| Farbe | HEX | RGB | Verwendung |
|-------|-----|-----|------------|
| Blue | `#016CA7` | 1, 108, 167 | Links, Hervorhebungen |
| MediumGray | `#A5A5A5` | 165, 165, 165 | Subtile Elemente |
| LightGray | `#DDDDDD` | 221, 221, 221 | Hintergründe |
| WhiteSmoke | `#F2F2F2` | 242, 242, 242 | Code-Hintergründe, Tabellen |

### 30% Deckkraft Farben

| Farbe | HEX | RGB | Verwendung |
|-------|-----|-----|------------|
| Orange_30% | `#FADAB4` | 250, 218, 180 | Warnings, Light Backgrounds |
| Green_30% | `#B7E3DA` | 183, 227, 218 | Tips, Success Messages |
| Blue_30% | `#B2D3E4` | 178, 211, 228 | Info Boxes |

### Textfarben

| Farbe | HEX | RGB | Verwendung |
|-------|-----|-----|------------|
| Black | `#000000` | 0, 0, 0 | Haupttext (Light Mode) |
| White | `#FFFFFF` | 255, 255, 255 | Haupttext (Dark Mode) |

## Fonts

Basierend auf dem Corporate Design:

- **Überschriften**: Ubuntu Regular (400)
- **Fließtext**: Ubuntu Regular (400)
- **Fett**: Ubuntu Medium (500)
- **Code**: Ubuntu Mono

## Implementierung

### Light Mode

- **Primary**: Orange (`#EF8200`)
- **Accent**: Green (`#10A384`)
- **Header**: Orange
- **Background**: White / WhiteSmoke

### Dark Mode

- **Primary**: Green (`#10A384`)
- **Accent**: Orange (`#EF8200`)
- **Header**: DarkGray (`#707070`)
- **Background**: Dark Grays

## Anpassung

Die Farben können in der Datei [extra.css](extra.css) angepasst werden:

```css
:root {
  --s2o-orange: #EF8200;
  --s2o-green: #10A384;
  /* ... weitere Farben */
}
```

## Verwendung

Die Stylesheets werden automatisch über die `mkdocs.yml` eingebunden:

```yaml
extra_css:
  - stylesheets/extra.css
```

## Lokale Vorschau

```bash
poetry run mkdocs serve
```

Die Dokumentation ist dann unter [http://127.0.0.1:8000](http://127.0.0.1:8000) verfügbar.

## Referenzen

- Corporate Design Manual: `MV-Corporate Design-281025-131850.pdf`
- [Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)
- [Material for MkDocs - Color Customization](https://squidfunk.github.io/mkdocs-material/setup/changing-the-colors/)
