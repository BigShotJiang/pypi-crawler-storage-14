# Exceptions

::: questra_authentication.exceptions.QuestraAuthenticationError
    options:
      show_source: false
      heading_level: 2

::: questra_authentication.exceptions.AuthenticationError
    options:
      show_source: false
      heading_level: 2

::: questra_authentication.exceptions.NotAuthenticatedError
    options:
      show_source: false
      heading_level: 2

::: questra_authentication.exceptions.SessionNotInitializedError
    options:
      show_source: false
      heading_level: 2

::: questra_authentication.exceptions.InvalidCredentialsError
    options:
      show_source: false
      heading_level: 2

::: questra_authentication.exceptions.OidcDiscoveryError
    options:
      show_source: false
      heading_level: 2

::: questra_authentication.exceptions.TokenExpiredError
    options:
      show_source: false
      heading_level: 2
