# Device Client

::: questra_authentication.device_client.DeviceClient
    options:
      show_source: false
      heading_level: 2
