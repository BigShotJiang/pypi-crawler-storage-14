# Python-Projekt

## Python-Spezifika

- Python 3.10+ (native type hints: X | None, list[X])
- PEP 8 (Style), PEP 484 (Type Hints), PEP 257 (Docstrings)
- Type Hints: vollständig, keine typing.Any ohne Begründung

## Paketmanager & Tooling

- **uv** für Dependencies
- example_*.py Dateien bei Schnittstellenänderungen aktualisieren
- Wichtige uv Commands:
  - `uv sync` - Dependencies installieren
  - `uv sync --all-groups` - Mit allen Dev-Dependencies
  - `uv add <package>` - Package hinzufügen
  - `uv run <command>` - Command in venv ausführen

## Dokumentation

- Docstrings: Google-Style (Args/Returns/Raises/Examples)
- Code-Blöcke mit ` ```python`
- Deutsch erlaubt
- **MkDocs:** Nur aus Docstrings generieren, kein Extra-Content (außer Getting Started)

## Error Handling

- Spezifische Exceptions (ValueError, TypeError, etc.)
- **Niemals** bare `except:` oder `except Exception:` ohne Begründung
- Bei externen Aufrufen: spezifische Fehler wrappen (z.B. `requests.RequestException → APIError`)
