"""Abstract base class for torrent search providers."""

import urllib.parse
from abc import ABC, abstractmethod
from ...common import SearchResultDTO, TorrentCategory
from ...util.print import print_size


class BaseSearchProvider(ABC):
    """Abstract base class for torrent search providers.

    Each provider implements search functionality for a specific
    public tracker or torrent search engine.
    """

    @abstractmethod
    def _search_impl(self, query: str) -> list[SearchResultDTO]:
        """Provider-specific search implementation.

        Args:
            query: Search term

        Returns:
            List of SearchResultDTO objects

        Raises:
            Exception: If search fails
        """
        pass

    def search(self, query: str) -> list[SearchResultDTO]:
        """Search for torrents and refine unknown categories.

        This method calls the provider-specific implementation and
        automatically refines UNKNOWN categories by analyzing torrent names.

        Args:
            query: Search term

        Returns:
            List of SearchResultDTO objects with refined categories

        Raises:
            Exception: If search fails
        """
        results = self._search_impl(query)
        return self._refine_results(results)

    @property
    @abstractmethod
    def short_name(self) -> str:
        """Return the provider short name for results list."""
        pass

    @property
    @abstractmethod
    def full_name(self) -> str:
        """Return the provider full name for details view."""
        pass

    def _build_magnet_link(self, info_hash: str, name: str,
                           trackers: list[str] = None) -> str:
        """Build a magnet link from info hash, name, and optional trackers.

        Args:
            info_hash: 40-character hex string torrent info hash
            name: Torrent name to encode in magnet link
            trackers: Optional list of tracker URLs to append

        Returns:
            Complete magnet link string
        """
        encoded_name = urllib.parse.quote(name)
        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={encoded_name}"

        if trackers:
            for tracker in trackers:
                encoded_tracker = urllib.parse.quote(tracker, safe='/:')
                magnet += f"&tr={encoded_tracker}"

        return magnet

    def _detect_category_from_name(self, name: str) -> TorrentCategory | None:
        """Detect category from torrent name using pattern matching.

        Args:
            name: Torrent name/title

        Returns:
            Detected TorrentCategory or None if no pattern matches
        """
        name_lower = name.lower()

        # AUDIO: Check for audio file extensions and keywords
        audio_patterns = [
            '.mp3', '.flac', '.wav', '.aac', '.ogg', '.m4a', '.wma', '.alac',
            'album', 'discography', 'soundtrack', 'ost', 'music',
        ]
        if any(pattern in name_lower for pattern in audio_patterns):
            return TorrentCategory.AUDIO

        # VIDEO: Check for video file extensions and keywords
        video_patterns = [
            '.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v',
            'movie', 'film', '1080p', '720p', '2160p', '4k', 'bluray',
            'webrip', 'hdtv', 'x264', 'x265', 'hevc', 'dvdrip',
        ]
        if any(pattern in name_lower for pattern in video_patterns):
            return TorrentCategory.VIDEO

        # OTHER: Check for documents, archives, and other content FIRST
        # (before SOFTWARE to avoid "ebook" matching "app" in application)
        other_patterns = [
            '.pdf', '.epub', '.mobi', '.azw', '.doc', '.txt',
            '.zip', '.rar', '.7z', '.tar',
            ' book', 'ebook', 'magazine', 'comic', 'tutorial',
        ]
        if any(pattern in name_lower for pattern in other_patterns):
            return TorrentCategory.OTHER

        # SOFTWARE: Check for software extensions and keywords
        software_patterns = [
            '.exe', '.msi', '.dmg', '.pkg', '.deb', '.rpm', '.app',
            'software', 'program', 'application', 'installer', 'setup',
            'patch', 'crack', 'keygen', 'portable',
        ]
        if any(pattern in name_lower for pattern in software_patterns):
            return TorrentCategory.SOFTWARE

        # GAMES: Check for game-related keywords
        games_patterns = [
            'game', 'repack', 'fitgirl', 'codex', 'skidrow', 'plaza',
            'gog', 'steam', 'gameplay', 'pc game', 'ps4', 'ps5',
            'xbox', 'switch', 'nintendo',
        ]
        if any(pattern in name_lower for pattern in games_patterns):
            return TorrentCategory.GAMES

        # XXX: Check for adult content keywords
        xxx_patterns = ['xxx', 'adult', '18+', 'nsfw', 'porn']
        if any(pattern in name_lower for pattern in xxx_patterns):
            return TorrentCategory.XXX

        # No pattern matched
        return None

    def _refine_results(
            self,
            results: list[SearchResultDTO]) -> list[SearchResultDTO]:
        """Refine UNKNOWN categories by detecting from torrent names.

        Creates new DTOs with refined categories where detection succeeds,
        preserving immutability of SearchResultDTO.

        Args:
            results: List of search results

        Returns:
            List with refined categories (new DTOs where category changed)
        """
        refined_results = []
        for result in results:
            if result.category == TorrentCategory.UNKNOWN:
                detected = self._detect_category_from_name(result.title)
                if detected:
                    # Create new DTO with refined category
                    result = SearchResultDTO(
                        title=result.title,
                        category=detected,
                        seeders=result.seeders,
                        leechers=result.leechers,
                        size=result.size,
                        files_count=result.files_count,
                        magnet_link=result.magnet_link,
                        info_hash=result.info_hash,
                        upload_date=result.upload_date,
                        provider=result.provider,
                        fields=result.fields
                    )
            refined_results.append(result)
        return refined_results

    def details_common(self, result: SearchResultDTO) -> str:
        """Generate common torrent details for left column.

        Args:
            result: Search result to format

        Returns:
            Markdown-formatted string with common details
        """
        md = "## General\n"
        md += f"- **Provider:** {self.full_name}\n"
        md += f"- **Category:** {result.category.value}\n"
        md += f"- **Info Hash:** `{result.info_hash}`\n"

        if result.page_url:
            md += f"- **Link:** {result.page_url}\n"

        md += "## Statistics\n"
        md += f"- **Size:** {print_size(result.size)}\n"
        md += f"- **Seeders:** {result.seeders}\n"
        md += f"- **Leechers:** {result.leechers}\n"

        if result.files_count is not None:
            md += f"- **Files:** {result.files_count}\n"

        if result.upload_date:
            date_str = result.upload_date.strftime('%Y-%m-%d %H:%M')
            md += f"- **Uploaded:** {date_str}\n"

        return md

    def details_extended(self, result: SearchResultDTO) -> str:
        """Generate provider-specific details for right column.

        Base implementation returns empty string.
        Subclasses should override to add provider-specific fields.

        Args:
            result: Search result to format

        Returns:
            Markdown-formatted string with provider-specific details
        """
        return ""
