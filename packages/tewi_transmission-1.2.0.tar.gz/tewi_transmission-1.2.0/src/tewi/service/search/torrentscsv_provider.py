"""TorrentsCSV.com torrent search provider implementation."""

import urllib.request
import urllib.parse
import json
from datetime import datetime
from typing import Any

from .base_provider import BaseSearchProvider
from ...common import SearchResultDTO, TorrentCategory
from ...util.decorator import log_time


class TorrentsCsvProvider(BaseSearchProvider):
    """Search provider for torrents-csv.com (general torrents).

    TorrentsCSV provides a public API for searching torrent metadata.
    Documentation: https://git.torrents-csv.com/heretic/torrents-csv-server
    """

    API_URL = "https://torrents-csv.com/service/search"

    @property
    def short_name(self) -> str:
        return "T-CSV"

    @property
    def full_name(self) -> str:
        return "Torrents-CSV"

    @log_time
    def _search_impl(self, query: str) -> list[SearchResultDTO]:
        """Search torrents-csv.com for torrents.

        Args:
            query: Search term

        Returns:
            List of SearchResultDTO objects

        Raises:
            Exception: If API request fails
        """
        if not query or not query.strip():
            return []

        params = {
            'q': query.strip(),
            'size': 50,  # Limit results
        }

        url = f"{self.API_URL}?{urllib.parse.urlencode(params)}"

        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))

            torrents = data.get('torrents', [])
            if not torrents:
                return []

            results = []
            for torrent in torrents:
                result = self._parse_torrent(torrent)
                if result:
                    results.append(result)

            return results

        except urllib.error.URLError as e:
            raise Exception(f"Network error: {e}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse API response: {e}")

    def _parse_torrent(self, torrent: dict[str, Any]) -> SearchResultDTO | None:
        """Parse a single torrent from TorrentsCSV API response."""
        try:
            info_hash = torrent.get('infohash', '')
            if not info_hash:
                return None

            name = torrent.get('name', 'Unknown')

            size = torrent.get('size_bytes', 0)

            magnet_link = self._build_magnet_link(
                info_hash=info_hash,
                name=name
            )

            # Parse upload date from unix timestamp
            upload_date = None
            created_unix = torrent.get('created_unix')
            if created_unix:
                upload_date = datetime.fromtimestamp(created_unix)

            # Build provider-specific fields
            fields = {}
            completed = torrent.get('completed')
            if completed is not None:
                fields['completed'] = str(completed)

            scraped_date = torrent.get('scraped_date')
            if scraped_date:
                scraped_dt = datetime.fromtimestamp(scraped_date)
                fields['scraped_date'] = scraped_dt.strftime('%Y-%m-%d %H:%M')

            return SearchResultDTO(
                title=name,
                category=TorrentCategory.UNKNOWN,
                seeders=torrent.get('seeders', 0),
                leechers=torrent.get('leechers', 0),
                size=size,
                files_count=None,
                magnet_link=magnet_link,
                info_hash=info_hash,
                upload_date=upload_date,
                provider=self.short_name,
                page_url=None,
                fields=fields
            )

        except (KeyError, ValueError, TypeError):
            return None

    def details_extended(self, result: SearchResultDTO) -> str:
        """Generate TorrentsCSV-specific details for right column.

        Args:
            result: Search result to format

        Returns:
            Markdown-formatted string with statistics
        """
        if not result.fields:
            return ""

        md = "## Information\n"

        if 'completed' in result.fields:
            completed = result.fields['completed']
            md += f"- **Completed Downloads:** {completed}\n"

        if 'scraped_date' in result.fields:
            md += f"- **Last Scraped:** {result.fields['scraped_date']}\n"

        return md
