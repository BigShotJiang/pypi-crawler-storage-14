"""Entry point for `python -m phage_annotator`."""

from phage_annotator.cli import main


if __name__ == "__main__":
    main()
