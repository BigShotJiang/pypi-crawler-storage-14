"""
source_handler.py

This module defines the SourceHandler class, which manages the acquisition of
image data for the object pattern recognition system. It provides a unified
interface for working with either a live camera feed or static image files.

Features:
- Supports two source types: "camera" (via OpenCV VideoCapture) and "image" (via cv2.imread).
- Handles initialization, validation, and frame retrieval.
- Ensures proper cleanup and release of camera resources.
- Raises clear exceptions for invalid configuration or failed frame capture.

Typical usage:
    handler = SourceHandler(config)
    handler.init_source()
    frame = handler.get_frame()
    handler.release()
"""

import os
import cv2
import cv2.typing


class SourceHandler:
    """
    Support two Modes:
    - "camera": Live-camera via OpenCV (cv2.VideoCapture)
    - "image": Image file (cv2.imread)
    """

    def __init__(self, config: dict) -> None:
        """
        Initialize the SourceHandler with configuration data.

        Args:
        config (dict): Configuration dictionary loaded from config.json.
            Expected keys:
            - 'source.type': 'camera' or 'image'
            - 'source.camera_index': index of camera
            - 'source.image_path': path to image file (required if type is 'image')
        """
        src = config.get("source", {})
        self.source_type = src.get(
            "type", "camera"
        ).lower()  # .lower() to not differentiate between small and tall letters
        self.camera_index = int(src.get("camera_index", 0))
        self.image_path = src.get("image_path")
        # Placeholder, while no camera opened
        self.capture = None
        self.init_source()

    def init_source(self, source_type: str = "", image_path: str = "") -> None:
        """
        Initialize chosen type:
        - If self.source_type is 'camera', open camera via cv2:VideoCapture(self._camera_index)
        - If self.source:type is 'image', check if file exists

        Args:
        source_type (str, optional): Source type to overwrite self.source_type.
        image_path (str, optional): Image path to overwrite self.image_path.

        Raises:
            RuntimeError: Could not open camera
            FileNotFoundError: Image does not exist on path
            ValueError: Image is not a .png, .jpeg or .jpg file
            ValueError: Source type is not supported
        """
        if source_type != "":
            self.source_type = source_type
        if self.source_type == "camera":
            self.capture = cv2.VideoCapture(self.camera_index)  # type: ignore
            if not self.capture.isOpened():  # type: ignore
                if self.capture is not None:
                    self.capture.release()
                raise RuntimeError(
                    f"Could not open camera at index {self.camera_index}"
                )
        elif self.source_type == "image":
            if image_path != "":
                if image_path == "default":
                    source_handler_dir = os.path.dirname(os.path.abspath(__file__))
                    package_dir =  os.path.dirname(source_handler_dir)
                    self.image_path = os.path.join(package_dir, "img", "test_image_00.png")
                else:
                    self.image_path = image_path
            if not os.path.exists(self.image_path):
                raise FileNotFoundError(f"Image not found: {self.image_path}")
            if not self.image_path.lower().endswith((".png", ".jpeg", ".jpg")):
                raise ValueError("Image must be one of [.png, .jpeg, .jpg].")
        else:
            raise ValueError(f"Source type is not supported: {self.source_type}")

    def get_frame(self) -> cv2.typing.MatLike:
        """
        Function to read out the image or camera frame

        Raises:
            RuntimeError: Failed to read image/camera picture, or camera was not initialized
            ValueError: invalid source type

        Returns:
            cv2.typing.Matlike: The image frame as a NumPy array suitable for OpenCV processing
        """
        if self.source_type == "camera":
            if self.capture is None:
                raise RuntimeError("Camera was not initialized")
            return_value, frame = self.capture.read()
            if not return_value or frame is None:
                raise RuntimeError("Could not read from camera")
            return frame

        elif self.source_type == "image":
            frame = cv2.imread(self.image_path)
            if frame is None:
                raise RuntimeError(f"Failed to read image from {self.image_path}")
            return frame
        else:
            raise ValueError("Source type not valid.")

    def release(self) -> None:
        """
        Releases the currently active video source (e.g., camera).

        This method should be called when the source is no longer needed
        or before switching to a different source. Releasing the capture
        object prevents the camera device from remaining locked by OpenCV.
        """
        if self.capture is not None:
            try:
                self.capture.release()
            except Exception:
                pass
            self.capture = None
