import os
import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".xmu_rollcall"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "username": "",
    "password": "",
    "latitude": "",
    "longitude": ""
}

def ensure_config_dir():
    """确保配置目录存在"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

def load_config():
    """加载配置文件"""
    ensure_config_dir()
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return DEFAULT_CONFIG.copy()
    return DEFAULT_CONFIG.copy()

def save_config(config):
    """保存配置文件"""
    ensure_config_dir()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

def is_config_complete(config):
    """检查配置是否完整"""
    required_fields = ["username", "password", "latitude", "longitude"]
    return all(config.get(field) for field in required_fields)

def get_cookies_path():
    """获取cookies文件路径"""
    ensure_config_dir()
    return str(CONFIG_DIR / "cookies.json")

