# -*- coding: utf-8 -*-
"""
常量定义
"""

# 控制方式
METHOD_AUTO = "auto"
METHOD_ACCESSIBILITY = "accessibility"
METHOD_HID = "hid"
METHOD_ADB = "adb"

# 按键映射
KEYS = {
    # 导航键
    "back": 4,
    "home": 3,
    "menu": 82,
    "recent": 187,
    
    # 音量键
    "volume_up": 24,
    "volume_down": 25,
    "volume_mute": 164,
    
    # 电源键
    "power": 26,
    
    # 方向键
    "up": 19,
    "down": 20,
    "left": 21,
    "right": 22,
    "center": 23,
    "enter": 66,
    
    # 功能键
    "delete": 67,
    "del": 67,
    "tab": 61,
    "space": 62,
    "escape": 111,
    "esc": 111,
    
    # 媒体键
    "play": 85,
    "pause": 85,
    "play_pause": 85,
    "stop": 86,
    "next": 87,
    "previous": 88,
    
    # 相机
    "camera": 27,
    
    # 搜索
    "search": 84,
}

# 设备状态
STATUS_ONLINE = "online"
STATUS_OFFLINE = "offline"
STATUS_BUSY = "busy"
STATUS_ERROR = "error"

# 默认配置
DEFAULT_PORT = 8888
DEFAULT_TIMEOUT = 30
DEFAULT_SWIPE_DURATION = 300
DEFAULT_LONG_PRESS_DURATION = 1000

# 命令类型
CMD_CLICK = "click"
CMD_SWIPE = "swipe"
CMD_LONG_PRESS = "long_press"
CMD_INPUT_TEXT = "input_text"
CMD_PRESS_KEY = "press_key"
CMD_FIND_ELEMENT = "find_element"
CMD_FIND_ELEMENTS = "find_elements"
CMD_CLICK_ELEMENT = "click_element"
CMD_GET_ELEMENT_INFO = "get_element_info"
CMD_SCREENSHOT = "screenshot"
CMD_START_APP = "start_app"
CMD_STOP_APP = "stop_app"
CMD_GET_CURRENT_APP = "get_current_app"
CMD_GET_DEVICE_INFO = "get_device_info"
CMD_INSTALL_APP = "install_app"
CMD_UNINSTALL_APP = "uninstall_app"
CMD_WAKE_UP = "wake_up"
CMD_LOCK_SCREEN = "lock_screen"
CMD_GET_SCREEN_SIZE = "get_screen_size"
