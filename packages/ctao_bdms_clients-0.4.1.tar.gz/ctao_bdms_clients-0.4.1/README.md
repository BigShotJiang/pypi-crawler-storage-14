# Bulk Data Management System

[![CI](https://gitlab.cta-observatory.org/cta-computing/dpps/bdms/bdms/badges/main/pipeline.svg?key_text=CI&key_width=25)](https://gitlab.cta-observatory.org/dpps/bdms/bdms/-/pipelines/main/latest)
[![Test Report](https://gitlab.cta-observatory.org/cta-computing/dpps/bdms/bdms/badges/main/pipeline.svg?key_text=Test%20Report)](https://gitlab.cta-observatory.org/cta-computing/dpps/bdms/bdms/-/jobs/artifacts/main/file/test_report.pdf?job=build-test-report)
[![Docs](https://gitlab.cta-observatory.org/cta-computing/dpps/bdms/bdms/badges/main/pipeline.svg?key_text=docs&key_width=30)](http://cta-computing.gitlab-pages.cta-observatory.org/dpps/bdms/bdms/)
