
# Security Policy

## Reporting a Vulnerability

The team and community take all security vulnerabilities seriously. Thank you for improving the security of our project. We appreciate your efforts and responsible disclosure and will make every effort to acknowledge your contributions.

If you discover a potential security issue in this project, or think you may have discovered a security issue, we ask that you notify ByteDance Security via our [security center](https://security.bytedance.com/src) or vulnerability reporting email at [sec@bytedance.com](mailto:sec@bytedance.com).

**Please do not create a public GitHub issue.**

Please include the requested information listed below (as much as you can provide) to help us better understand the nature and scope of the possible issue:

*   Type of issue (e.g. buffer overflow, SQL injection, cross-site scripting, etc.)
*   Full paths of source file(s) related to the manifestation of the issue
*   The location of the affected source code (tag/branch/commit or direct URL)
*   Any special configuration required to reproduce the issue
*   Step-by-step instructions to reproduce the issue
*   Proof-of-concept or exploit code (if possible)
*   Impact of the issue, including how an attacker might exploit the issue

This project follows a 90-day disclosure timeline.
