
# Contributing to LangChain-Volcengine-MySQL

First off, thank you for considering contributing to this project! Your help is essential for keeping it great.

## Code of Conduct

This project and everyone participating in it is governed by the [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code. Please report unacceptable behavior to the project maintainers.

## How Can I Contribute?

### Reporting Bugs

Bugs are tracked as [GitHub issues](https://github.com/bytedance/langchain-volcengine-mysql/issues). Before creating a bug report, please check the existing issues to see if the problem has already been reported. If it has, please add a comment to the existing issue instead of creating a new one.

When you are creating a bug report, please include as many details as possible. Fill out the required template, the information it asks for helps us resolve issues faster.

### Suggesting Enhancements

Enhancement suggestions are tracked as [GitHub issues](https://github.com/bytedance/langchain-volcengine-mysql/issues). Use the "Feature request" template to describe your idea. Provide a clear and detailed explanation of the feature you're proposing, including potential use cases and benefits.

### Your First Code Contribution

Unsure where to begin contributing? You can start by looking through `good-first-issue` and `help-wanted` issues:

- [Good first issues](https://github.com/bytedance/langchain-volcengine-mysql/labels/good%20first%20issue) - issues which should only require a few lines of code, and a test or two.
- [Help wanted issues](https://github.com/bytedance/langchain-volcengine-mysql/labels/help%20wanted) - issues which should be a bit more involved than `good-first-issue` issues.

### Pull Requests

The process described here has several goals:

- Maintain code quality
- Fix problems that are important to users
- Engage the community in working toward the best possible product
- Enable a sustainable system for maintainers to review contributions

#### 1. Fork and Branch

Fork the repository and create a new branch from `main` for your contribution.

```bash
git checkout -b your-branch-name
```

#### 2. Commit Messages

We use [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) for our commit messages. This allows for automated changelog generation and helps us keep the history clean. Please follow this specification for your commit messages.

A commit message consists of a **header**, a **body** and a **footer**.

```
<type>(<scope>): <subject>
<BLANK LINE>
<body>
<BLANK LINE>
<footer>
```

- **Type**: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`, etc.
- **Scope** (optional): The part of the codebase your commit is related to (e.g., `vedb`, `mysql`, `readme`).
- **Subject**: A short, imperative-tense description of the change.

Example: `feat(vedb): add support for cosine distance`

#### 3. Writing Tests

All contributions should include tests that prove the change is effective. We use `pytest` for our testing framework. Please add unit tests for any new or changed functionality.

#### 4. Submitting a Pull Request

- Push your branch to your fork and submit a pull request to the `main` branch of the upstream repository.
- In your PR description, provide a clear summary of the changes and link any related issues (e.g., "Closes #123").
- Ensure that your PR passes all CI checks.

#### 5. Contributor License Agreement (CLA)

Before we can merge your contribution, you will need to sign the ByteDance Contributor License Agreement (CLA). A CLA bot will automatically comment on your PR with a link to sign the agreement.

Thank you for your contribution!
