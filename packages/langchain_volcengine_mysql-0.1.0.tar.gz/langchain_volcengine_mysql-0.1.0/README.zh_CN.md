[English](README.md) | 中文

# LangChain – Volcengine MySQL Ecosystem

这是一个统一、轻量级的 LangChain 适配器包，专为在火山引擎环境中使用 MySQL 的 LangChain 用户设计。它为两个功能强大且均可对外服务的数据库后端提供了一个统一的入口：

- **veDB for MySQL**: 火山引擎提供的一款云原生、高性能的数据库服务。
- **RDS for MySQL**: 一款完全托管、稳定且可扩展的关系型数据库服务。

两个适配器都捆绑在此包中，为创建和使用向量存储和检索器提供了一致的、属性风格的 API。

## 概述

官方文档： [veDB for MySQL](https://www.volcengine.com/docs/6357) · [RDS for MySQL](https://www.volcengine.com/docs/6313)

这个包简化了在 LangChain 应用中使用 veDB for MySQL 和 RDS for MySQL 作为向量存储的过程。它抽象了后端特定的细节，并提供了一个清晰、统一的接口。

- **对于 veDB for MySQL**: 它利用 `vedbsearch` 客户端库进行高效的向量搜索。
- **对于 RDS for MySQL**: 它利用了新近版本中提供的原生向量索引和搜索功能。

## 特性

- **统一 API**: 单个包即可与 veDB for MySQL 和 RDS for MySQL 进行交互。
- **属性式访问**: 使用 `vedb.vector_store` 和 `mysql.vector_store` 获取已配置的向量存储实例。
- **简易配置**: 使用 `configure()` 和 `set_embedding()` 轻松配置数据库连接和嵌入函数。


- **标准 LangChain 集成**: 与 LangChain 生态系统完全兼容，包括链（chains）和其他组件。

## 安装

安装统一的 SDK：

```bash
pip install langchain-volcengine-mysql
```

这个单一的安装包包含了连接到 veDB for MySQL 和 RDS for MySQL 所需的所有组件。

## 申请火山引擎账号与开通 veDB/RDS for MySQL（快速指引）

- 登录或注册火山引擎控制台。
- 开通 veDB for MySQL 或 RDS for MySQL 服务。
- 创建 MySQL 兼容实例。
- 记录连接信息：host、port、database、user、password。
- 按需配置 IP 白名单与 TLS。
- 在 SDK 中通过 `vedb.configure(...)` / `mysql.configure(...)` 填入上述参数。

```python
# veDB for MySQL
from langchain_volcengine_mysql import vedb
vedb.configure(
    host="your-vedb-host.example.com",
    port=3306,
    user="admin",
    password="***",
    database="app_db",
    table_name="vectors",
    embedding_function=embeddings,
)

# RDS for MySQL
from langchain_volcengine_mysql import mysql
mysql.configure(
    host="your-rds-host.example.com",
    port=3306,
    user="admin",
    password="***",
    database="app_db",
    table_name="vectors",
    embedding_function=embeddings,
)
```

更多开通流程与计费请参考火山引擎官方文档。

## 快速开始

有关详细的用法和示例，请参阅 [英文 README](README.md)。

## 贡献

我们欢迎任何形式的贡献！请查看 [CONTRIBUTING.md](CONTRIBUTING.md) 文件了解详情。

## 许可证

本项目采用 [Apache-2.0 许可证](LICENSE)。
