# Copyright 2025 ByteDance Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Typed definitions and common types for langchain_volcengine_mysql.

This module defines:
- BackendType: Literal["vedb", "mysql"]
- ConnectionConfig: minimal MySQL connection config TypedDict
- VectorStoreLike: protocol representing the subset of methods we rely on
- BaseChatMessageHistory: imported from LangChain if available, otherwise a Protocol fallback
- MySQLVectorDistance: Enum for MySQL vector distance metrics
- Common exceptions used by the package
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Protocol, TypedDict, Literal

# Try to import BaseChatMessageHistory from LangChain (newer or older paths),
# and provide a graceful fallback Protocol if not available at import time.
try:  # LangChain >= 0.1.0 (split packages)
    from langchain_core.chat_history import BaseChatMessageHistory  # type: ignore
except Exception:  # pragma: no cover
    try:  # Older LangChain
        from langchain.memory.chat_message_histories.base import (  # type: ignore
            BaseChatMessageHistory,
        )
    except Exception:  # pragma: no cover
        class BaseChatMessageHistory(Protocol):
            def add_message(self, message: Any) -> None: ...
            def get_messages(self) -> List[Any]: ...
            def clear(self) -> None: ...


BackendType = Literal["vedb", "mysql"]


class ConnectionConfig(TypedDict, total=False):
    """Minimal MySQL connection configuration shared by backends.

    This is intentionally minimal and backend-agnostic. Each backend may accept
    more parameters; additional keys will be forwarded as-is.
    """
    host: str
    port: int
    user: str
    password: str
    database: str
    charset: str  # e.g. "utf8mb4"
    ssl: bool
    # table/index related optional params (forward-only to backend factories)
    table_name: str
    index_name: str
    embedding_dim: int
    # any other backend-specific config will be forwarded verbatim


class VectorStoreLike(Protocol):
    """A minimal protocol representing LangChain-compatible vector store methods.

    Backends should return instances implementing at least these methods.
    """

    def add_texts(
        self,
        texts: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        ...

    def similarity_search(self, query: str, k: int = 4, **kwargs: Any) -> List[Any]:
        ...

    def as_retriever(self, **kwargs: Any) -> Any:
        ...


# Import MySQL-specific types
try:
    from .mysql.vendor.rds_mysql_vectorstore.vectorstore import MySQLVectorDistance
except ImportError:
    # Provide a fallback if MySQL backend is not available
    class MySQLVectorDistance:
        L2 = "l2"
        EUCLIDEAN = "euclidean"
        COSINE = "cosine"


class UnknownBackendError(ValueError):
    pass


class BackendNotInstalledError(ImportError):
    pass


class ConfigError(ValueError):
    pass


class NotSupportedError(Exception):
    """Raised when a requested feature is not currently supported by this package."""
    pass
