# Copyright 2025 ByteDance Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
veDB submodule providing attribute-style access via module-level __getattr__ (PEP 562).

Usage (no function call required after configuration):

    from langchain_volcengine_mysql import vedb
    vedb.configure(host=..., user=..., password=..., database=..., table_name=..., embedding_function=embeddings)
    vector_store = vedb.vector_store
    retriever = vedb.retriever

"""
from __future__ import annotations

from typing import Any

from ..types import (
    VectorStoreLike,
    BaseChatMessageHistory,
    NotSupportedError,
    ConfigError,
    BackendNotInstalledError,
)

# Default configuration for attribute-based access
_DEFAULT_CONFIG: dict[str, Any] = {}


def configure(**config: Any) -> None:
    """Configure module-level defaults for veDB vector store construction.

    Supported keys include connection params and embedding function:
    - host, port, user, password, database, table_name, charset
    - embedding_function (or alias via set_embedding)
    - embedding_dim (optional; mapped to client_config["dimension"]) 
    """
    _DEFAULT_CONFIG.update(config or {})


def set_embedding(embedding_function: Any) -> None:
    """Set the default embedding function used by veDB vector store."""
    _DEFAULT_CONFIG["embedding_function"] = embedding_function


def _build_vectorstore_from_defaults() -> VectorStoreLike:
    """Validate defaults and construct a VeDB vector store using vendored class."""
    # Required keys for VeDB construction
    required = [
        "embedding_function",
        "host",
        "user",
        "password",
        "database",
        "table_name",
    ]
    missing = [k for k in required if _DEFAULT_CONFIG.get(k) in (None, "")]
    if missing:
        raise ConfigError(
            f"Missing required config for veDB: {', '.join(missing)}"
        )

    try:
        from .vendor.langchain_vedb.vectorstores import VeDB as _VeDB  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise BackendNotInstalledError(
            "veDB vendor implementation not available."
        ) from exc

    embedding = _DEFAULT_CONFIG.get("embedding_function") or _DEFAULT_CONFIG.get("embedding")

    # Build client_config from known keys
    client_keys = (
        "host",
        "port",
        "user",
        "password",
        "database",
        "table_name",
        "charset",
        "metadata_columns",  # Add metadata_columns to client_config
    )
    client_config: dict[str, Any] = {
        k: _DEFAULT_CONFIG[k]
        for k in client_keys
        if k in _DEFAULT_CONFIG and _DEFAULT_CONFIG[k] is not None
    }
    
    # Add default metadata columns if not specified - to preserve demo metadata
    if "metadata_columns" not in client_config or not client_config["metadata_columns"]:
        client_config["metadata_columns"] = {
            "source": "VARCHAR(255)",
            "category": "VARCHAR(100)", 
            "version": "VARCHAR(50)"
        }

    # Map embedding_dim -> dimension if present
    if "embedding_dim" in _DEFAULT_CONFIG and _DEFAULT_CONFIG.get("embedding_dim") is not None:
        client_config["dimension"] = _DEFAULT_CONFIG.get("embedding_dim")

    return _VeDB(embedding=embedding, client_config=client_config)  # type: ignore[arg-type]


# PEP 562: module-level attribute access
def __getattr__(name: str) -> Any:
    if name == "vector_store":
        return _build_vectorstore_from_defaults()
    if name == "retriever":
        return _build_vectorstore_from_defaults().as_retriever()
    raise AttributeError(f"module 'vedb' has no attribute '{name}'")


# Legacy helper functions (still available)

def get_vectorstore(**config: Any) -> VectorStoreLike:
    """Create a VeDB-backed VectorStore using explicit config.

    Preferred path: use vendored `VeDB` class directly.

    Expected config keys:
    - embedding_function or embedding: LangChain Embeddings instance
    - host, port, user, password, database, table_name, charset: client config
    - embedding_dim (optional): mapped to client_config["dimension"]
    """
    try:
        from .vendor.langchain_vedb.vectorstores import VeDB as _VeDB  # type: ignore
        embedding = config.get("embedding_function") or config.get("embedding")
        if embedding is None:
            raise ValueError(
                "VeDB requires `embedding_function` (or `embedding`) in config."
            )
        client_keys = (
            "host",
            "port",
            "user",
            "password",
            "database",
            "table_name",
            "charset",
            "metadata_columns",  # Add metadata_columns to client_config
        )
        client_config: dict[str, Any] = {
            k: config[k] for k in client_keys if k in config and config[k] is not None
        }
        
        # Add default metadata columns if not specified - to preserve demo metadata
        if "metadata_columns" not in client_config or not client_config["metadata_columns"]:
            client_config["metadata_columns"] = {
                "source": "VARCHAR(255)",
                "category": "VARCHAR(100)", 
                "version": "VARCHAR(50)"
            }
        if "embedding_dim" in config and config.get("embedding_dim") is not None:
            client_config["dimension"] = config.get("embedding_dim")
        return _VeDB(embedding=embedding, client_config=client_config)  # type: ignore[arg-type]
    except Exception as exc:
        raise BackendNotInstalledError(
            "veDB vendor implementation not available."
        ) from exc


def get_chat_history(**config: Any) -> BaseChatMessageHistory:
    """Chat history is currently not supported for VeDB backend."""
    raise NotSupportedError("Chat history is not supported in this package at the moment.")


def get_retriever(**config: Any) -> Any:
    """Create a retriever from the VeDB-backed VectorStore."""
    vs = get_vectorstore(**config)
    return vs.as_retriever()


__all__ = [
    # Attribute-style names (provided via __getattr__)
    "vector_store",
    "retriever",
    # Configuration helpers
    "configure",
    "set_embedding",
    # Legacy function helpers
    "get_vectorstore",
    "get_chat_history",
    "get_retriever",
]
