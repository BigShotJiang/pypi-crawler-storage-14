# Copyright 2025 ByteDance Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
MySQL submodule providing attribute-style access via module-level __getattr__ (PEP 562).

Usage (no function call required after configuration):

    from langchain_volcengine_mysql import mysql
    mysql.configure(host=..., user=..., password=..., database=..., table_name=..., embedding_function=embeddings)
    vector_store = mysql.vector_store
    retriever = mysql.retriever

"""
from __future__ import annotations

from typing import Any

from ..types import (
    VectorStoreLike,
    BaseChatMessageHistory,
    NotSupportedError,
    ConfigError,
    BackendNotInstalledError,
)

# Default configuration for attribute-based access
_DEFAULT_CONFIG: dict[str, Any] = {}


def configure(**config: Any) -> None:
    """Configure module-level defaults for MySQL vector store construction.

    Supported keys include connection params and optional embedding function:
    - host, port, user, password, database, table_name, vector_column, index_name
    - embedding_function (or alias via set_embedding)
    - embedding_dim (optional)
    """
    _DEFAULT_CONFIG.update(config or {})


def set_embedding(embedding_function: Any) -> None:
    """Set the default embedding function used by MySQL vector store."""
    _DEFAULT_CONFIG["embedding_function"] = embedding_function


def _build_vectorstore_from_defaults() -> VectorStoreLike:
    """Validate defaults and construct a MySQL vector store using vendored class."""
    # Required keys for MySQL construction (discrete params path)
    required = [
        "host",
        "user",
        "password",
        "database",
        "table_name",
    ]
    missing = [k for k in required if _DEFAULT_CONFIG.get(k) in (None, "")]
    if missing:
        raise ConfigError(
            f"Missing required config for MySQL: {', '.join(missing)}"
        )

    try:
        from .vendor.rds_mysql_vectorstore.vectorstore import (
            VolcMySQLVectorStore as _MySQLVS,
        )  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise BackendNotInstalledError(
            "MySQL vendor implementation not available."
        ) from exc

    # Pass through all known/default keys directly
    init_kwargs: dict[str, Any] = dict(_DEFAULT_CONFIG)
    # Ensure optional defaults for convenience
    init_kwargs.setdefault("vector_column", "embedding")

    # Create vector store instance
    vs = _MySQLVS(**init_kwargs)  # type: ignore[arg-type]
    
    # Check if this is a real VolcMySQLVectorStore instance with database connection
    # Skip table creation for dummy/mock implementations
    if hasattr(vs, '_cursor') and hasattr(vs, '_conn'):
        # Check if table exists and create schema if it doesn't
        try:
            with vs._cursor() as cur:
                cur.execute(
                    "SHOW TABLES LIKE %s",
                    (init_kwargs["table_name"],)
                )
                table_exists = cur.fetchone() is not None
                
            if not table_exists:
                # Get embedding dimension from embedding function if available
                embedding_dim = init_kwargs.get("embedding_dim")
                embedding_function = init_kwargs.get("embedding_function")
                
                if embedding_dim is None and embedding_function is not None:
                    # Try to infer embedding dimension by embedding a sample text
                    try:
                        sample_embedding = embedding_function.embed_query("test")
                        embedding_dim = len(sample_embedding)
                    except Exception as e:
                        raise ConfigError(
                            "Could not infer embedding dimension from embedding_function. "
                            "Please provide embedding_dim in config."
                        ) from e
                
                if embedding_dim is None:
                    raise ConfigError(
                        "embedding_dim is required when creating a new table and no embedding_function is provided."
                    )
                
                # Create schema with default HNSW index
                vs.create_schema(
                    table_name=init_kwargs["table_name"],
                    embedding_dim=embedding_dim,
                    algorithm_params={"algorithm": "hnsw", "distance": "euclidean"}
                )
                
        except Exception as e:
            # Clean up the connection if we failed to create the schema
            vs._conn.close()
            raise RuntimeError(f"Failed to initialize vector store: {str(e)}") from e

    return vs


# PEP 562: module-level attribute access
def __getattr__(name: str) -> Any:
    if name == "vector_store":
        return _build_vectorstore_from_defaults()
    if name == "retriever":
        return _build_vectorstore_from_defaults().as_retriever()
    raise AttributeError(f"module 'mysql' has no attribute '{name}'")


# Legacy helper functions (still available)

def get_vectorstore(**config: Any) -> VectorStoreLike:
    """Create a MySQL-backed VectorStore using explicit config.

    Preferred path: use vendored `VolcMySQLVectorStore` directly.
    """
    try:
        from .vendor.rds_mysql_vectorstore.vectorstore import (
            VolcMySQLVectorStore as _MySQLVS,
        )  # type: ignore
        return _MySQLVS(**config)  # type: ignore[arg-type]
    except Exception as exc:
        raise BackendNotInstalledError(
            "MySQL vendor implementation not available."
        ) from exc


def get_chat_history(**config: Any) -> BaseChatMessageHistory:
    """Chat history is currently not supported for MySQL backend."""
    raise NotSupportedError("Chat history is not supported in this package at the moment.")


def get_retriever(**config: Any) -> Any:
    """Create a retriever from the MySQL-backed VectorStore."""
    vs = get_vectorstore(**config)
    return vs.as_retriever()


__all__ = [
    # Attribute-style names (provided via __getattr__)
    "vector_store",
    "retriever",
    # Configuration helpers
    "configure",
    "set_embedding",
    # Legacy function helpers
    "get_vectorstore",
    "get_chat_history",
    "get_retriever",
]
