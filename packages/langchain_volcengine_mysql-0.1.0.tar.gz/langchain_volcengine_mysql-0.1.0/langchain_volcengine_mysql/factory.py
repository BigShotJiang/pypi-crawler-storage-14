# Copyright 2025 ByteDance Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Factory functions for unified veDB MySQL and RDS for MySQL adapters.

Top-level public API:
- get_vectorstore(backend: Literal["vedb", "mysql"], **config) -> VectorStoreLike
- get_retriever(backend: Literal["vedb", "mysql"], **config) -> Any


These functions perform backend dispatching and basic validation, while deferring
actual object construction to submodule adapters located under
`langchain_volcengine_mysql.{vedb|mysql}`.
"""
from __future__ import annotations

from typing import Any

from .types import (
    BackendType,
    VectorStoreLike,
    BaseChatMessageHistory,
    UnknownBackendError,
    ConfigError,
    NotSupportedError,
)


REQUIRED_KEYS = ("host", "user", "password", "database")


def _validate_common_config(config: dict) -> None:
    missing = [k for k in REQUIRED_KEYS if k not in config or not config.get(k)]
    if missing:
        raise ConfigError(
            f"Missing required connection parameters: {', '.join(missing)}. Required: {', '.join(REQUIRED_KEYS)}"
        )


def get_vectorstore(backend: BackendType, **config: Any) -> VectorStoreLike:
    """Return a LangChain-compatible VectorStore implementation for the backend.

    The function performs minimal validation and routes to the specific backend
    adapter's `create_vectorstore(**config)` implementation.
    """
    _validate_common_config(config)

    if backend == "vedb":
        from .vedb import get_vectorstore as _gv
        return _gv(**config)
    elif backend == "mysql":
        from .mysql import get_vectorstore as _gv
        return _gv(**config)
    else:
        raise UnknownBackendError(
            f"Unknown backend: {backend!r}. Supported backends: 'vedb' or 'mysql'"
        )


def get_chat_history(backend: BackendType, **config: Any) -> BaseChatMessageHistory:
    """Chat history is currently not supported for either backend.

    This function exists for future compatibility and will raise NotSupportedError.
    """
    raise NotSupportedError("Chat history is not supported in this package at the moment.")


def get_retriever(backend: BackendType, **config: Any) -> Any:
    """Delegate to submodule retriever creation.
    """
    if backend == "vedb":
        from .vedb import get_retriever as _gr
        return _gr(**config)
    elif backend == "mysql":
        from .mysql import get_retriever as _gr
        return _gr(**config)
    else:
        raise UnknownBackendError(
            f"Unknown backend: {backend!r}. Supported backends: 'vedb' or 'mysql'"
        )
