from pathlib import Path
import sys

# Ensure repo root on sys.path for direct package import
_REPO_ROOT = Path(__file__).resolve().parents[1]
if not (_REPO_ROOT / "langchain_volcengine_mysql").exists():
    # Fallback to parent of tests dir
    _REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from langchain_volcengine_mysql import vedb


class DummyVeDB:
    """Minimal stub to simulate ANN-like behavior via text length scoring.

    - Stores texts and metadatas in memory
    - similarity_search returns top-k longest texts
    - as_retriever returns an object exposing get_relevant_documents
    """

    def __init__(self, embedding, client_config):
        self.embedding = embedding
        self.client_config = client_config
        self._items = []  # list of dicts: {"text": str, "metadata": Any}

    def add_texts(self, texts, metadatas=None):
        metadatas = metadatas or [None] * len(texts)
        for t, m in zip(texts, metadatas):
            self._items.append({"text": t, "metadata": m})
        # Return simple IDs
        return list(range(len(self._items)))

    def similarity_search(self, query, k=2):
        # Score by text length (simulate ANN distance)
        ranked = sorted(self._items, key=lambda x: len(x["text"]), reverse=True)
        top = ranked[:k]
        # Return simple objects with attributes 'text' and 'metadata'
        return [type("Doc", (), item) for item in top]

    def as_retriever(self):
        parent = self

        class _Retriever:
            def __init__(self, vs):
                self._vs = vs

            def get_relevant_documents(self, query):
                return self._vs.similarity_search(query, k=2)

        return _Retriever(parent)


def test_attribute_style_ann_flow_for_vedb(monkeypatch):
    # Monkeypatch vendored VeDB class to DummyVeDB
    monkeypatch.setattr(
        "langchain_volcengine_mysql.vedb.vendor.langchain_vedb.vectorstores.VeDB",
        DummyVeDB,
        raising=False,
    )

    # Configure defaults for attribute-style API
    vedb.configure(
        host="example.com",
        user="u",
        password="p",
        database="db",
        table_name="tbl",
        embedding_function=object(),
        embedding_dim=128,
    )

    # Act: get vector store and use ANN-like operations
    vs = vedb.vector_store
    vs.add_texts(
        [
            "veDB is MySQL-compatible",
            "Short",
            "A longer explanation on approximate nearest neighbor search",
        ]
    )
    docs = vs.similarity_search("What is veDB?", k=2)

    # Assert length is k
    assert isinstance(docs, list)
    assert len(docs) == 2

    # Retriever path
    retriever = vedb.retriever
    rdocs = retriever.get_relevant_documents("veDB")
    assert isinstance(rdocs, list)
    assert len(rdocs) >= 1
