from pathlib import Path
import sys

# Ensure repo root on sys.path for direct package import
_REPO_ROOT = Path(__file__).resolve().parents[1]
if not (_REPO_ROOT / "langchain_volcengine_mysql").exists():
    # Fallback to parent of tests dir
    _REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from langchain_volcengine_mysql import mysql
from langchain_community.embeddings import FakeEmbeddings
from langchain_volcengine_mysql.types import MySQLVectorDistance


class DummyVolcMySQLVectorStore:
    """Minimal MySQL vector store stub for testing from_vectors and similarity_search_by_vector."""

    def __init__(self, **kwargs):
        self.kwargs = dict(kwargs)
        self.table_name = kwargs.get("table_name")
        self.distance = kwargs.get("distance")
        self._items = []

    @classmethod
    def from_vectors(cls, vectors, texts, connection_uri, table_name, distance, **kwargs):
        """Create from precomputed vectors."""
        instance = cls(
            connection_uri=connection_uri,
            table_name=table_name,
            distance=distance,
            **kwargs
        )
        # Store vectors and texts for later similarity search
        instance._vectors = vectors
        instance._texts = texts
        return instance

    def similarity_search_by_vector(self, query_vector, k=1):
        """Simulate vector similarity search by comparing vector lengths."""
        # For simplicity, use vector length as a proxy for similarity
        # In real implementation, this would use actual vector distance calculation
        vector_lengths = [sum(v**2 for v in vec) ** 0.5 for vec in self._vectors]
        query_length = sum(v**2 for v in query_vector) ** 0.5
        
        # Find the index of the vector with closest length
        closest_index = min(range(len(vector_lengths)), 
                          key=lambda i: abs(vector_lengths[i] - query_length))
        
        # Return the closest document
        return [type("Doc", (), {"page_content": self._texts[closest_index], "metadata": {}})]


def test_mysql_ann_from_vectors(monkeypatch):
    """Test MySQL ANN search using from_vectors and similarity_search_by_vector."""
    # Monkeypatch the real VolcMySQLVectorStore with our dummy implementation
    monkeypatch.setattr(
        "langchain_volcengine_mysql.mysql.vendor.rds_mysql_vectorstore.vectorstore.VolcMySQLVectorStore",
        DummyVolcMySQLVectorStore,
        raising=False,
    )

    # 1. 准备 embedding 模型和数据
    embedder = FakeEmbeddings(size=4)
    texts = ["苹果是水果", "香蕉是黄色的水果", "汽车是交通工具"]
    vectors = embedder.embed_documents(texts)
    uri = "mysql+pymysql://user:password@127.0.0.1:3306/test"

    # 2. 从预计算的向量创建 VectorStore
    vs = mysql.vendor.rds_mysql_vectorstore.vectorstore.VolcMySQLVectorStore.from_vectors(
        vectors=vectors,
        texts=texts,
        connection_uri=uri,
        table_name="docs_precomputed",
        distance=MySQLVectorDistance.L2,
    )

    # 3. 对查询文本进行向量化，并按向量搜索
    query_vector = embedder.embed_query("哪种水果是黄色的？")
    results = vs.similarity_search_by_vector(query_vector, k=1)
    
    # 验证结果
    assert isinstance(results, list)
    assert len(results) == 1
    assert hasattr(results[0], 'page_content')
    assert isinstance(results[0].page_content, str)
    
    # 验证配置参数是否正确传递
    assert vs.table_name == "docs_precomputed"
    assert vs.distance == MySQLVectorDistance.L2


def test_mysql_ann_integration_flow(monkeypatch):
    """Test end-to-end MySQL ANN search flow."""
    # Monkeypatch the real VolcMySQLVectorStore with our dummy implementation
    monkeypatch.setattr(
        "langchain_volcengine_mysql.mysql.vendor.rds_mysql_vectorstore.vectorstore.VolcMySQLVectorStore",
        DummyVolcMySQLVectorStore,
        raising=False,
    )

    # 配置 MySQL 连接
    mysql.configure(
        host="127.0.0.1",
        port=3306,
        user="user",
        password="password",
        database="test",
        table_name="docs_precomputed",
        distance=MySQLVectorDistance.L2,
    )

    # 准备数据
    embedder = FakeEmbeddings(size=4)
    texts = ["苹果是水果", "香蕉是黄色的水果", "汽车是交通工具"]
    vectors = embedder.embed_documents(texts)

    # 使用 configure 后的参数创建 VectorStore
    vs = mysql.vendor.rds_mysql_vectorstore.vectorstore.VolcMySQLVectorStore.from_vectors(
        vectors=vectors,
        texts=texts,
        connection_uri=mysql._config.get("connection_uri"),
        table_name=mysql._config.get("table_name"),
        distance=mysql._config.get("distance"),
    )

    # 执行搜索
    query = "哪种水果是黄色的？"
    query_vector = embedder.embed_query(query)
    results = vs.similarity_search_by_vector(query_vector, k=1)

    # 验证结果
    assert isinstance(results, list)
    assert len(results) == 1
    assert isinstance(results[0].page_content, str)
    print(f"查询: {query}")
    print(f"搜索结果: {results[0].page_content}")