from pathlib import Path
import sys

# Ensure repo root on sys.path for direct package import
_REPO_ROOT = Path(__file__).resolve().parents[1]
if not (_REPO_ROOT / "langchain_volcengine_mysql").exists():
    # Fallback to parent of tests dir
    _REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from langchain_volcengine_mysql import mysql


class DummyVolcMySQLVectorStore:
    """Minimal MySQL vector store stub capturing config and simulating ANN via text length."""

    def __init__(self, **kwargs):
        self.kwargs = dict(kwargs)
        self.index_name = kwargs.get("index_name")
        self.embedding_dim = kwargs.get("embedding_dim")
        self.distance = kwargs.get("distance")
        self._items = []

    def add_texts(self, texts, metadatas=None):
        metadatas = metadatas or [None] * len(texts)
        for t, m in zip(texts, metadatas):
            self._items.append({"text": t, "metadata": m})
        return list(range(len(self._items)))

    def similarity_search(self, query, k=2):
        ranked = sorted(self._items, key=lambda x: len(x["text"]), reverse=True)
        top = ranked[:k]
        return [type("Doc", (), item) for item in top]

    def as_retriever(self):
        parent = self

        class _Retriever:
            def __init__(self, vs):
                self._vs = vs

            def get_relevant_documents(self, query):
                return self._vs.similarity_search(query, k=2)

        return _Retriever(parent)


def test_attribute_style_ann_flow_for_mysql(monkeypatch):
    # Monkeypatch vendored MySQL vectorstore class to Dummy implementation
    monkeypatch.setattr(
        "langchain_volcengine_mysql.mysql.vendor.rds_mysql_vectorstore.vectorstore.VolcMySQLVectorStore",
        DummyVolcMySQLVectorStore,
        raising=False,
    )

    # Configure defaults for attribute-style API
    mysql.configure(
        host="example.com",
        user="u",
        password="p",
        database="db",
        table_name="tbl",
        index_name="idx_vectors",
        embedding_dim=256,
    )

    # Act: get vector store and use ANN-like operations
    vs = mysql.vector_store
    vs.add_texts(
        [
            "Example text one",
            "Short",
            "Another, much longer example text for ANN testing",
        ]
    )
    docs = vs.similarity_search("Example", k=2)

    # Assert length is k
    assert isinstance(docs, list)
    assert len(docs) == 2

    # Retriever path - use the same vector store instance
    retriever = vs.as_retriever()
    rdocs = retriever.get_relevant_documents("Example")
    assert isinstance(rdocs, list)
    assert len(rdocs) >= 1

    # Verify captured configuration made its way into the dummy
    assert getattr(vs, "index_name", None) == "idx_vectors"
    assert getattr(vs, "embedding_dim", None) == 256
