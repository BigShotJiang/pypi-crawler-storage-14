"""
BOE RAG Demo using veDB for MySQL as Vector Store
This demo shows a complete Retrieval-Augmented Generation system using:
- veDB for MySQL as vector store (via langchain-volcengine-mysql)
- Volcengine Ark for embeddings
- Volcengine Ark for LLM
- LangChain for RAG pipeline
"""

import os
import sys
import time
import logging

# Suppress INFO logging
logging.basicConfig(level=logging.WARNING, format="[%(levelname)s] %(message)s")
logging.getLogger("mysql.connector").setLevel(logging.WARNING)
logging.getLogger("vedbsearch").setLevel(logging.WARNING)

from typing import List, Dict, Any, Optional
from langchain_core.embeddings import Embeddings
from langchain_core.documents import Document
from langchain_volcengine_mysql import vedb
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from volcenginesdkarkruntime import Ark
from langchain_classic.chains import RetrievalQA
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, Runnable

# Add parent directory to path for module imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Initialize Volcengine Ark client
ARK_CLIENT = Ark(
    base_url="https://ark-cn-beijing.bytedance.net/api/v3",
    api_key="2d56d551-9a27-4b95-b37d-04ead97b62fe"
)

# veDB for MySQL Configuration
VEDB_CONFIG = {
    "host": "2605:340:cd50:2000:7cc2:2a2e:50ff:1904",
    "port": 3306,
    "user": "ndb",
    "password": "ndb",
    "database": "vedb_v_test",
    "table_name": "boe_rag_demo_documents",
    "embedding_dim": 2560  # Match Ark embedding dimension
}

# Volcengine Model Configuration (same as comprehensive_rag_demo.py)
EMBEDDING_MODEL = "ep-20251125150138-nhvhr"
LLM_MODEL = "ep-20251125191002-nqdw8"

class CustomArkEmbeddings(Embeddings):
    """Custom Volcengine Ark Embeddings class with rate limiting"""
    
    def __init__(self, client: Ark, model: str = EMBEDDING_MODEL):
        self.client = client
        self.model = model
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents using Ark embeddings with rate limiting."""
        max_retries = 3
        retry_delay = 2  # seconds
        
        for attempt in range(max_retries):
            try:
                resp = self.client.embeddings.create(
                    model=self.model,
                    input=texts
                )
                return [data.embedding for data in resp.data]
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                print(f"Rate limit exceeded. Retrying in {retry_delay} seconds... (Attempt {attempt + 1}/{max_retries})")
                time.sleep(retry_delay)
                retry_delay *= 2  # Exponential backoff
    
    def embed_query(self, text: str) -> List[float]:
        """Embed a single query using Ark embeddings."""
        return self.embed_documents([text])[0]

class VolcengineLLM(Runnable):
    """Custom Volcengine LLM wrapper that inherits from Runnable"""
    
    def __init__(self, client: Ark, model: str = LLM_MODEL):
        self.client = client
        self.model = model
    
    def invoke(self, input: dict | str | Any, config: Optional[dict] = None, **kwargs) -> str:
        """Generate text from prompt (Runnable interface)"""
        # Handle different input types
        if isinstance(input, dict):
            prompt = input.get("prompt", "") or input.get("input", "")
        elif hasattr(input, "to_string"):
            prompt = input.to_string()
        elif isinstance(input, str):
            prompt = input
        else:
            prompt = str(input)
            
        # Ignore stop parameter for now
        try:
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                        ],
                    }
                ],
                reasoning_effort="medium",
                extra_headers={'x-is-encrypted': 'true'},
            )
            return completion.choices[0].message.content
        except Exception as e:
            print(f"Error calling LLM: {e}")
            raise
    
    def __call__(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Generate text from prompt (compatibility interface)"""
        return self.invoke({"prompt": prompt})

class BOEvedbRAGDemo:
    """BOE RAG Demo Application using veDB for MySQL"""
    
    def __init__(self):
        self.embeddings = None
        self.vector_store = None
        self.retriever = None
        self.llm = None
        self.qa_chain = None
        
    def initialize_embeddings(self) -> None:
        """Initialize Volcengine embeddings"""
        print("Initializing Volcengine embeddings...")
        self.embeddings = CustomArkEmbeddings(client=ARK_CLIENT)
        print("✓ Volcengine embeddings initialized successfully")
        
    def configure_vector_store(self) -> None:
        """Configure and initialize veDB for MySQL vector store"""
        print("\nConfiguring veDB for MySQL vector store...")
        
        # Add embedding dimension verification
        print(f"Verifying embedding dimension...")
        test_text = "Test text to verify embedding dimension"
        test_embedding = self.embeddings.embed_query(test_text)
        actual_dim = len(test_embedding)
        configured_dim = VEDB_CONFIG["embedding_dim"]
        
        if actual_dim != configured_dim:
            print(f"⚠️  Warning: Embedding dimension mismatch!")
            print(f"   Configured: {configured_dim} | Actual: {actual_dim}")
            print(f"   Updating configuration to match actual embedding dimension...")
            VEDB_CONFIG["embedding_dim"] = actual_dim
        
        # Configure veDB
        vedb.configure(
            host=VEDB_CONFIG["host"],
            port=VEDB_CONFIG["port"],
            user=VEDB_CONFIG["user"],
            password=VEDB_CONFIG["password"],
            database=VEDB_CONFIG["database"],
            table_name=VEDB_CONFIG["table_name"],
            embedding_function=self.embeddings,
            embedding_dim=VEDB_CONFIG["embedding_dim"]
        )
        
        # Get vector store instance
        self.vector_store = vedb.vector_store
        print(f"✓ veDB for MySQL vector store configured (table: {VEDB_CONFIG['table_name']}, dimension: {VEDB_CONFIG['embedding_dim']})")
        
        # Clear existing documents in the table to ensure fresh state
        print(f"Clearing existing documents from table: {VEDB_CONFIG['table_name']}")
        self.vector_store.clear_all()
        print("✓ Table cleared successfully")
        
        # Initialize retriever
        self.retriever = vedb.retriever
        print("✓ Retriever initialized successfully")
        
    def setup_llm(self) -> None:
        """Initialize Volcengine LLM"""
        print("\nInitializing Volcengine LLM...")
        self.llm = VolcengineLLM(client=ARK_CLIENT)
        print("✓ Volcengine LLM initialized successfully")
        
    def setup_qa_chain(self) -> None:
        """Setup RAG QA chain"""
        print("\nSetting up RAG QA chain...")
        
        # Define prompt template
        prompt_template = """You are a helpful AI assistant. Use the following context to answer the question.
If you don't know the answer, just say you don't know. Do not make up answers.

Context:
{context}

Question: {question}

Answer:"""
        
        prompt = PromptTemplate(
            input_variables=["context", "question"],
            template=prompt_template
        )
        
        # Create QA chain
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.retriever,
            return_source_documents=True,
            chain_type_kwargs={"prompt": prompt}
        )
        
        print("✓ RAG QA chain setup completed")
        
    def prepare_test_data(self) -> List[Document]:
        """Prepare test documents for the BOE demo"""
        test_documents = [
            {
                "content": "BOE is bytedance offline environment, for safe test and rapid developement",
                "metadata": {"source": "tech_blog", "category": "devoop", "version": "2024", "industry": "bytedance"}
            },
            {
                "content": "veDB for MySQL is a cloud-native, high-performance database service from Volcengine. It provides automatic scaling, high availability, and excellent performance for modern applications.",
                "metadata": {"source": "product_docs", "category": "database", "version": "1.0", "service": "vedb"}
            },
            {
                "content": "LangChain is a framework for building applications with large language models. It provides tools for working with LLMs, vector stores, embeddings, and building complex chains.",
                "metadata": {"source": "tech_blog", "category": "framework", "version": "0.1", "technology": "llm"}
            },
            {
                "content": "Vector databases enable efficient similarity search for AI applications. They store high-dimensional vectors and allow fast retrieval of similar vectors using various algorithms like HNSW.",
                "metadata": {"source": "research_paper", "category": "ai", "version": "2.0", "topic": "vector-databases"}
            },
            {
                "content": "BOE's intelligent manufacturing solutions leverage AI and big data to optimize production processes, improve quality control, and reduce operational costs.",
                "metadata": {"source": "boe_tech", "category": "manufacturing", "version": "2024", "technology": "ai"}
            },
            {
                "content": "Volcengine Ark provides a comprehensive platform for building AI applications. It includes models for text generation, embeddings, image processing, and more.",
                "metadata": {"source": "volcengine_docs", "category": "ai-platform", "version": "latest", "platform": "ark"}
            },
            {
                "content": "Retrieval-Augmented Generation (RAG) combines information retrieval with text generation. It retrieves relevant documents from a knowledge base and uses them to generate more accurate and grounded responses.",
                "metadata": {"source": "ai_research", "category": "nlp", "version": "2024", "technique": "rag"}
            },
            {
                "content": "The langchain-volcengine-mysql package provides a unified interface for working with both veDB for MySQL and RDS for MySQL as vector stores in LangChain applications.",
                "metadata": {"source": "package_docs", "category": "software", "version": "1.0", "package": "langchain-volcengine-mysql"}
            },
            {
                "content": "BOE's display technology is used in a wide range of products including smartphones, tablets, laptops, TVs, and automotive displays. The company holds leading market share in multiple display segments.",
                "metadata": {"source": "boe_products", "category": "display", "version": "2024", "market": "global"}
            },
            {
                "content": "Cloud-native databases like veDB offer significant advantages over traditional databases including better scalability, higher availability, and lower operational costs through automation.",
                "metadata": {"source": "cloud_computing", "category": "database", "version": "2024", "architecture": "cloud-native"}
            }
        ]
        
        return [Document(page_content=doc["content"], metadata=doc["metadata"]) for doc in test_documents]
        
    def populate_vector_store(self, documents: List[Document]) -> List[str]:
        """Populate vector store with test documents"""
        print(f"\nAdding {len(documents)} documents to vector store...")
        
        # Add documents
        document_ids = self.vector_store.add_documents(documents)
        print(f"✓ Added {len(document_ids)} documents with IDs: {document_ids[:2]}...")
        
        # Verify documents were actually inserted by attempting to retrieve them
        print(f"\nVerifying insertion of {len(document_ids)} documents...")
        try:
            retrieved_docs = self.vector_store.get_by_ids(document_ids[:3])  # Test with first 3 documents
            print(f"✓ Successfully retrieved {len(retrieved_docs)} out of 3 documents by ID!")
            for doc in retrieved_docs:
                print(f"  - Document ID: {doc.id}, Content: {doc.page_content[:50]}...")
        except Exception as e:
            print(f"✗ Error verifying insertion: {e}")
        
        return document_ids
        
    def test_vector_store_search(self) -> None:
        """Test vector store search functionality"""
        print("\n=== Testing Vector Store Search ===")
        
        # Test similarity search
        test_queries = [
            "What is BOE?",
            "What is veDB?",
            "Tell me about vector databases",
            "Explain RAG technology",
            "What display products does BOE offer?"
        ]
        
        for query in test_queries:
            print(f"\nQuery: '{query}'")
            results = self.vector_store.similarity_search(query, k=2)
            print(f"Found {len(results)} results:")
            for i, doc in enumerate(results, 1):
                print(f"  {i}. {doc.page_content[:100]}... (source: {doc.metadata.get('source', 'unknown')})")
        
    def test_retriever(self) -> None:
        """Test retriever functionality"""
        print("\n=== Testing Retriever ===")
        
        query = "What is LangChain?"
        print(f"Querying retriever: '{query}'")
        
        # Use the correct method for the retriever interface
        docs = self.retriever.invoke(query)
        print(f"✓ Retriever returned {len(docs)} documents:")
        for i, doc in enumerate(docs, 1):
            print(f"  {i}. {doc.page_content[:100]}... (source: {doc.metadata.get('source', 'unknown')})")
        
    def test_rag_chain(self) -> None:
        """Test RAG QA chain with BOE-specific questions"""
        print("\n=== Testing RAG QA Chain ===")
        
        test_questions = [
            "What is BOE and what does the company specialize in?",
            "What are the key features of veDB for MySQL?",
            "Explain how RAG works and why it's important for AI applications?",
            "What display products does BOE manufacture?",
            "How can LangChain help with building LLM applications?",
            "What are the advantages of cloud-native databases like veDB?",
            "How does BOE use AI in its manufacturing processes?"
        ]
        
        for question in test_questions:
            print(f"\n{'='*60}")
            print(f"Question: {question}")
            print(f"{'-'*60}")
            
            try:
                # Get response from RAG chain
                result = self.qa_chain.invoke({"query": question})
                
                # Print answer
                print(f"Answer: {result['result']}")
                
                # Print source documents
                print(f"\nSource Documents ({len(result['source_documents'])}):")
                for i, doc in enumerate(result['source_documents'], 1):
                    print(f"  {i}. {doc.metadata.get('source', 'unknown')}: {doc.page_content[:100]}...")
                    
            except Exception as e:
                print(f"Error: {e}")
                import traceback
                traceback.print_exc()
                
    def cleanup(self, document_ids: List[str]) -> None:
        """Clean up test data"""
        print("\n=== Cleaning Up ===")
        
        # Delete test documents
        print(f"Deleting {len(document_ids)} test documents...")
        self.vector_store.delete(ids=document_ids)
        print("✓ Test documents deleted")
        
        # Clear all documents from the vector store
        print(f"Clearing all documents from table: {VEDB_CONFIG['table_name']}")
        self.vector_store.clear_all()
        print("✓ All documents cleared")
        
        # Close the vector store connection
        self.vector_store.close()
        print("✓ Vector store connection closed")
        
    def run_full_demo(self) -> None:
        """Run the complete BOE RAG demo with veDB"""
        print("=" * 80)
        print("BOE RAG Demo with veDB for MySQL Vector Store")
        print("=" * 80)
        
        try:
            # Initialize components
            self.initialize_embeddings()
            self.configure_vector_store()
            self.setup_llm()
            self.setup_qa_chain()
            
            # Prepare and populate data
            test_documents = self.prepare_test_data()
            document_ids = self.populate_vector_store(test_documents)
            
            # Add delay to avoid rate limiting and ensure index is fully built (veDB's async indexing needs extra time)
            print("\nWaiting 30 seconds to ensure index is fully built...")
            time.sleep(30)
            
            # Run tests
            self.test_vector_store_search()
            self.test_retriever()
            self.test_rag_chain()
            
            # Clean up
            self.cleanup(document_ids)
            
            print("\n" + "=" * 80)
            print("✅ BOE RAG DEMO COMPLETED SUCCESSFULLY!")
            print("=" * 80)
            
        except Exception as e:
            print(f"\n❌ BOE RAG DEMO FAILED: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

def main():
    """Main entry point"""
    demo = BOEvedbRAGDemo()
    demo.run_full_demo()

if __name__ == "__main__":
    main()
