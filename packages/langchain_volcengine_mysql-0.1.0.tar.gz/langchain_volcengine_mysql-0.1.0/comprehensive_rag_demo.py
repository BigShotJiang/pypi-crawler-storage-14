"""
Comprehensive RAG Demo using RDS MySQL as Vector Store
This demo shows a complete Retrieval-Augmented Generation system using:
- RDS MySQL as vector store (via langchain-volcengine-mysql)
- Volcengine Ark for embeddings
- Volcengine Ark for LLM
- LangChain for RAG pipeline
"""

import os
import sys
import time
from typing import List, Dict, Any, Optional
from langchain_core.embeddings import Embeddings
from langchain_core.documents import Document
from langchain_volcengine_mysql import mysql
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from volcenginesdkarkruntime import Ark
from langchain_classic.chains import RetrievalQA
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, Runnable

# Add parent directory to path for module imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Initialize Volcengine Ark client
ARK_CLIENT = Ark(
    base_url="https://ark-cn-beijing.bytedance.net/api/v3",
    api_key="2d56d551-9a27-4b95-b37d-04ead97b62fe"
)

# RDS MySQL Configuration
MYSQL_CONFIG = {
    "host": "33.249.124.133",
    "port": 3306,
    "user": "kernel_dev_admin",
    "password": "foxtos-Sivso3-byfcer",
    "database": "test",
    "table_name": "rag_demo_documents",
    "embedding_dim": 2560  # Match Ark embedding dimension
}

# Volcengine Model Configuration
EMBEDDING_MODEL = "ep-20251125150138-nhvhr"
LLM_MODEL = "ep-20251125191002-nqdw8"

class CustomArkEmbeddings(Embeddings):
    """Custom Volcengine Ark Embeddings class with rate limiting"""
    
    def __init__(self, client: Ark, model: str = EMBEDDING_MODEL):
        self.client = client
        self.model = model
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents using Ark embeddings with rate limiting."""
        max_retries = 3
        retry_delay = 2  # seconds
        
        for attempt in range(max_retries):
            try:
                resp = self.client.embeddings.create(
                    model=self.model,
                    input=texts
                )
                return [data.embedding for data in resp.data]
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                print(f"Rate limit exceeded. Retrying in {retry_delay} seconds... (Attempt {attempt + 1}/{max_retries})")
                time.sleep(retry_delay)
                retry_delay *= 2  # Exponential backoff
    
    def embed_query(self, text: str) -> List[float]:
        """Embed a single query using Ark embeddings."""
        return self.embed_documents([text])[0]

class VolcengineLLM(Runnable):
    """Custom Volcengine LLM wrapper that inherits from Runnable"""
    
    def __init__(self, client: Ark, model: str = LLM_MODEL):
        self.client = client
        self.model = model
    
    def invoke(self, input: dict | str | Any, config: Optional[dict] = None, **kwargs) -> str:
        """Generate text from prompt (Runnable interface)"""
        # Handle different input types
        if isinstance(input, dict):
            prompt = input.get("prompt", "") or input.get("input", "")
        elif hasattr(input, "to_string"):
            prompt = input.to_string()
        elif isinstance(input, str):
            prompt = input
        else:
            prompt = str(input)
            
        # Ignore stop parameter for now
        try:
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                        ],
                    }
                ],
                reasoning_effort="medium",
                extra_headers={'x-is-encrypted': 'true'},
            )
            return completion.choices[0].message.content
        except Exception as e:
            print(f"Error calling LLM: {e}")
            raise
    
    def __call__(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Generate text from prompt (compatibility interface)"""
        return self.invoke({"prompt": prompt})

class RAGDemo:
    """Comprehensive RAG Demo Application"""
    
    def __init__(self):
        self.embeddings = None
        self.vector_store = None
        self.retriever = None
        self.llm = None
        self.qa_chain = None
        
    def initialize_embeddings(self) -> None:
        """Initialize Volcengine embeddings"""
        print("Initializing Volcengine embeddings...")
        self.embeddings = CustomArkEmbeddings(client=ARK_CLIENT)
        print("✓ Volcengine embeddings initialized successfully")
        
    def configure_vector_store(self) -> None:
        """Configure and initialize RDS MySQL vector store"""
        print("\nConfiguring RDS MySQL vector store...")
        
        # Configure MySQL
        mysql.configure(
            host=MYSQL_CONFIG["host"],
            port=MYSQL_CONFIG["port"],
            user=MYSQL_CONFIG["user"],
            password=MYSQL_CONFIG["password"],
            database=MYSQL_CONFIG["database"],
            table_name=MYSQL_CONFIG["table_name"],
            embedding_function=self.embeddings,
            embedding_dim=MYSQL_CONFIG["embedding_dim"]
        )
        
        # Get vector store instance
        self.vector_store = mysql.vector_store
        print(f"✓ RDS MySQL vector store configured (table: {MYSQL_CONFIG['table_name']})")
        
        # Initialize retriever
        self.retriever = mysql.retriever
        print("✓ Retriever initialized successfully")
        
    def setup_llm(self) -> None:
        """Initialize Volcengine LLM"""
        print("\nInitializing Volcengine LLM...")
        self.llm = VolcengineLLM(client=ARK_CLIENT)
        print("✓ Volcengine LLM initialized successfully")
        
    def setup_qa_chain(self) -> None:
        """Setup RAG QA chain"""
        print("\nSetting up RAG QA chain...")
        
        # Define prompt template
        prompt_template = """You are a helpful AI assistant. Use the following context to answer the question.
If you don't know the answer, just say you don't know. Do not make up answers.

Context:
{context}

Question: {question}

Answer:"""
        
        prompt = PromptTemplate(
            input_variables=["context", "question"],
            template=prompt_template
        )
        
        # Create QA chain
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.retriever,
            return_source_documents=True,
            chain_type_kwargs={"prompt": prompt}
        )
        
        print("✓ RAG QA chain setup completed")
        
    def prepare_test_data(self) -> List[Document]:
        """Prepare test documents for the demo"""
        test_documents = [
            {
                "content": "veDB for MySQL is a cloud-native, high-performance database service from Volcengine. It provides automatic scaling, high availability, and excellent performance for modern applications.",
                "metadata": {"source": "product_docs", "category": "database", "version": "1.0", "service": "vedb"}
            },
            {
                "content": "LangChain is a framework for building applications with large language models. It provides tools for working with LLMs, vector stores, embeddings, and building complex chains.",
                "metadata": {"source": "tech_blog", "category": "framework", "version": "0.1", "technology": "llm"}
            },
            {
                "content": "Vector databases enable efficient similarity search for AI applications. They store high-dimensional vectors and allow fast retrieval of similar vectors using various algorithms like HNSW.",
                "metadata": {"source": "research_paper", "category": "ai", "version": "2.0", "topic": "vector-databases"}
            },
            {
                "content": "MySQL 8.0 introduced native vector indexing capabilities. This allows users to store vector embeddings directly in MySQL tables and perform similarity searches using SQL queries.",
                "metadata": {"source": "mysql_docs", "category": "database", "version": "8.0", "feature": "vector-indexing"}
            },
            {
                "content": "HNSW (Hierarchical Navigable Small World) is an efficient algorithm for approximate nearest neighbor search. It provides logarithmic time complexity for both insertion and search operations.",
                "metadata": {"source": "algorithm_guide", "category": "ai", "version": "1.5", "algorithm": "hnsw"}
            },
            {
                "content": "Volcengine Ark provides a comprehensive platform for building AI applications. It includes models for text generation, embeddings, image processing, and more.",
                "metadata": {"source": "volcengine_docs", "category": "ai-platform", "version": "latest", "platform": "ark"}
            },
            {
                "content": "Retrieval-Augmented Generation (RAG) combines information retrieval with text generation. It retrieves relevant documents from a knowledge base and uses them to generate more accurate and grounded responses.",
                "metadata": {"source": "ai_research", "category": "nlp", "version": "2024", "technique": "rag"}
            },
            {
                "content": "The langchain-volcengine-mysql package provides a unified interface for working with both veDB for MySQL and RDS for MySQL as vector stores in LangChain applications.",
                "metadata": {"source": "package_docs", "category": "software", "version": "1.0", "package": "langchain-volcengine-mysql"}
            }
        ]
        
        return [Document(page_content=doc["content"], metadata=doc["metadata"]) for doc in test_documents]
        
    def populate_vector_store(self, documents: List[Document]) -> List[str]:
        """Populate vector store with test documents"""
        print(f"\nAdding {len(documents)} documents to vector store...")
        
        # Add documents
        document_ids = self.vector_store.add_documents(documents)
        print(f"✓ Added {len(document_ids)} documents with IDs: {document_ids[:2]}...")
        
        return document_ids
        
    def test_vector_store_search(self) -> None:
        """Test vector store search functionality"""
        print("\n=== Testing Vector Store Search ===")
        
        # Test similarity search
        test_queries = [
            "What is veDB?",
            "Tell me about vector databases",
            "Explain RAG technology",
            "What is HNSW?"
        ]
        
        for query in test_queries:
            print(f"\nQuery: '{query}'")
            results = self.vector_store.similarity_search(query, k=2)
            print(f"Found {len(results)} results:")
            for i, doc in enumerate(results, 1):
                print(f"  {i}. {doc.page_content[:100]}... (source: {doc.metadata['source']})")
        
    def test_retriever(self) -> None:
        """Test retriever functionality"""
        print("\n=== Testing Retriever ===")
        
        query = "What is LangChain?"
        print(f"Querying retriever: '{query}'")
        
        # Use the correct method for the retriever interface
        docs = self.retriever.invoke(query)
        print(f"✓ Retriever returned {len(docs)} documents:")
        for i, doc in enumerate(docs, 1):
            print(f"  {i}. {doc.page_content[:100]}... (source: {doc.metadata['source']})")
        
    def test_rag_chain(self) -> None:
        """Test RAG QA chain with sample questions"""
        print("\n=== Testing RAG QA Chain ===")
        
        test_questions = [
            "What is veDB and what are its key features?",
            "Explain how RAG works and why it's important for AI applications?",
            "What is the difference between vector databases and traditional databases?",
            "How does HNSW algorithm work for similarity search?",
            "What is LangChain and how does it help with LLM applications?"
        ]
        
        for question in test_questions:
            print(f"\n{'='*60}")
            print(f"Question: {question}")
            print(f"{'-'*60}")
            
            try:
                # Get response from RAG chain
                result = self.qa_chain.invoke({"query": question})
                
                # Print answer
                print(f"Answer: {result['result']}")
                
                # Print source documents
                print(f"\nSource Documents ({len(result['source_documents'])}):")
                for i, doc in enumerate(result['source_documents'], 1):
                    print(f"  {i}. {doc.metadata['source']}: {doc.page_content[:100]}...")
                    
            except Exception as e:
                print(f"Error: {e}")
                import traceback
                traceback.print_exc()
                
    def cleanup(self, document_ids: List[str]) -> None:
        """Clean up test data"""
        print("\n=== Cleaning Up ===")
        
        # Delete test documents
        print(f"Deleting {len(document_ids)} test documents...")
        self.vector_store.delete(ids=document_ids)
        print("✓ Test documents deleted")
        
        # Drop test table
        print(f"Dropping test table: {MYSQL_CONFIG['table_name']}")
        self.vector_store.drop_table()
        print("✓ Test table dropped")
        
    def run_full_demo(self) -> None:
        """Run the complete RAG demo"""
        print("=" * 80)
        print("Comprehensive RAG Demo with RDS MySQL Vector Store")
        print("=" * 80)
        
        try:
            # Initialize components
            self.initialize_embeddings()
            self.configure_vector_store()
            self.setup_llm()
            self.setup_qa_chain()
            
            # Prepare and populate data
            test_documents = self.prepare_test_data()
            document_ids = self.populate_vector_store(test_documents)
            
            # Add delay to avoid rate limiting
            print("\nWaiting 3 seconds to avoid rate limiting...")
            time.sleep(3)
            
            # Run tests
            self.test_vector_store_search()
            self.test_retriever()
            self.test_rag_chain()
            
            # Clean up
            self.cleanup(document_ids)
            
            print("\n" + "=" * 80)
            print("✅ RAG DEMO COMPLETED SUCCESSFULLY!")
            print("=" * 80)
            
        except Exception as e:
            print(f"\n❌ RAG DEMO FAILED: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

def main():
    """Main entry point"""
    demo = RAGDemo()
    demo.run_full_demo()

if __name__ == "__main__":
    main()