"""
Proper veDB Vector Store Interface Test
This test uses the actual veDB interface implemented in the repo, following the 
official pattern shown in the __init__.py file and README.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from langchain_core.embeddings import FakeEmbeddings
from langchain_volcengine_mysql import vedb
from langchain_core.documents import Document

def test_vedb_official_interface():
    """Test the official veDB interface as implemented in the repo"""
    print("=" * 70)
    print("Proper veDB Vector Store Interface Test")
    print("Using the official interface from langchain_volcengine_mysql.vedb")
    print("=" * 70)
    
    try:
        # Test 1: Test configure() method and attribute-style access (RECOMMENDED)
        print("\n1. Testing configure() method and attribute-style access (RECOMMENDED)...")
        
        # Initialize fake embeddings
        embeddings = FakeEmbeddings(size=1024)
        
        # Configure veDB using the official interface
        vedb.configure(
            host="2605:340:cd50:2000:7cc2:2a2e:50ff:1904",
            port=3306,
            user="ndb",
            password="ndb",
            database="vedb_v_test",
            table_name="vedb_official_test",
            embedding_function=embeddings,
            embedding_dim=1024
        )
        
        # Get vector store using attribute-style access (PEP 562)
        vector_store = vedb.vector_store
        print("   ✓ vector_store attribute accessed successfully")
        
        # Get retriever using attribute-style access
        retriever = vedb.retriever
        print("   ✓ retriever attribute accessed successfully")
        
        # Test 2: Test document operations
        print("\n2. Testing document operations...")
        
        # Create test documents
        test_docs = [
            Document(page_content="veDB is a cloud-native database from Volcengine", 
                     metadata={"source": "doc1", "category": "database"}),
            Document(page_content="MySQL is a popular relational database management system", 
                     metadata={"source": "doc2", "category": "database"}),
            Document(page_content="Vector databases enable efficient similarity search", 
                     metadata={"source": "doc3", "category": "ai"}),
            Document(page_content="LangChain provides tools for building LLM applications", 
                     metadata={"source": "doc4", "category": "framework"})
        ]
        
        # Add documents
        print(f"   Adding {len(test_docs)} test documents...")
        doc_ids = vector_store.add_documents(test_docs)
        print(f"   ✓ Added documents with IDs: {doc_ids[:2]}...")
        
        # Test 3: Test similarity search
        print("\n3. Testing similarity search...")
        
        # Test multiple queries
        test_queries = [
            ("cloud database", "Looking for veDB documents"),
            ("relational database", "Looking for MySQL documents"),
            ("vector search", "Looking for vector database documents"),
            ("LLM applications", "Looking for LangChain documents")
        ]
        
        for query, description in test_queries:
            print(f"   - Query: '{query}' ({description})")
            results = vector_store.similarity_search(query, k=2)
            print(f"     Found {len(results)} results:")
            for i, doc in enumerate(results, 1):
                print(f"       {i}. {doc.page_content[:60]}...")
        
        # Test 4: Test retriever interface
        print("\n4. Testing retriever interface...")
        
        # Test retriever with different queries
        retriever_queries = [
            "What is veDB?",
            "Tell me about relational databases",
            "How do vector databases work?"
        ]
        
        for query in retriever_queries:
            print(f"   - Retriever query: '{query}'")
            retrieved_docs = retriever.invoke(query)
            print(f"     Retriever returned {len(retrieved_docs)} documents")
        
        # Test 5: Test legacy function interface
        print("\n5. Testing legacy function interface...")
        
        # Test get_vectorstore() function
        vector_store_func = vedb.get_vectorstore(
            host="2605:340:cd50:2000:7cc2:2a2e:50ff:1904",
            port=3306,
            user="ndb", 
            password="ndb",
            database="vedb_v_test",
            table_name="vedb_legacy_test",
            embedding_function=embeddings,
            embedding_dim=1024
        )
        print("   ✓ get_vectorstore() function works correctly")
        
        # Test get_retriever() function
        retriever_func = vedb.get_retriever(
            host="2605:340:cd50:2000:7cc2:2a2e:50ff:1904",
            port=3306,
            user="ndb",
            password="ndb",
            database="vedb_v_test",
            table_name="vedb_legacy_test",
            embedding_function=embeddings,
            embedding_dim=1024
        )
        print("   ✓ get_retriever() function works correctly")
        
        # Test 6: Test error handling for missing config
        print("\n6. Testing error handling for missing configuration...")
        
        try:
            # Clear configuration
            import langchain_volcengine_mysql.vedb as vedb_module
            vedb_module._DEFAULT_CONFIG.clear()
            
            # Try to access vector_store without configuration
            vector_store = vedb.vector_store
            print("   ✗ Should have raised ConfigError but didn't")
        except Exception as e:
            if "Missing required config for veDB" in str(e):
                print("   ✓ Correctly raised ConfigError for missing configuration")
            else:
                print(f"   ✗ Raised unexpected error: {e}")
        
        # Clean up
        print("\n7. Cleaning up test data...")
        try:
            # Delete documents from the main test
            vector_store.delete(ids=doc_ids)
            print("   ✓ Test documents deleted from main test table")
        except Exception as e:
            print(f"   ⚠️  Could not delete documents: {e}")
        
        print("\n" + "=" * 70)
        print("✅ ALL veDB INTERFACE TESTS PASSED!")
        print("=" * 70)
        print("\nSummary of working features:")
        print("✓ configure() method for setting defaults")
        print("✓ Attribute-style access: vedb.vector_store")
        print("✓ Attribute-style access: vedb.retriever")
        print("✓ Document insertion with embeddings")
        print("✓ Similarity search functionality")
        print("✓ Retriever interface")
        print("✓ Legacy get_vectorstore() function")
        print("✓ Legacy get_retriever() function")
        print("✓ Proper error handling for missing config")
        print("\nThe veDB interface is working exactly as designed!")
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == "__main__":
    success = test_vedb_official_interface()
    sys.exit(0 if success else 1)