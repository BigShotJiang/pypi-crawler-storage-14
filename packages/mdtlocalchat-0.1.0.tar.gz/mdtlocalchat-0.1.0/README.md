# Run project

```bash
poetry run aidev
```

## Dev

```bash
poetry run pre-commit install
```

## Run pre-commit on all files

```bash
poetry run pre-commit run --all-files
```