"""
Hopefully a single file server.
"""
import re
import datetime
from contextlib import asynccontextmanager
from pathlib import Path

from starlette.applications import Starlette
from starlette.exceptions import HTTPException
from starlette.endpoints import HTTPEndpoint
from starlette.responses import Response, JSONResponse
from starlette.routing import Route, Mount
from starlette.staticfiles import StaticFiles
from starlette.config import Config

import pygit2
from pygit2 import Repository
from pygit2.enums import SortMode, ObjectType


config = Config(env_prefix='XU60_')

REPO_HOME = Path(config("REPO_HOME", default="."))
SRV_HOME = Path(config("SRV_HOME", default=REPO_HOME))
OBJECT_ROUTE = config("OBJECT_ROUTE", default="object")
VERSIONS_ROUTE = config("VERSIONS_ROUTE", default="versions")
META_ROUTE = config("META_ROUTE", default="meta")

DIFFLINE = re.compile(r"\+(\d+),(\d+) ")

@asynccontextmanager
async def lifespan(app):
    """
    Lifespan management.
    """
    print('Startup')
    # double cache size and enable caching for objects under 512KB
    pygit2.settings.cache_max_size(512 * 1024**2)
    pygit2.settings.cache_object_limit(ObjectType.BLOB, 512 * 1024)

    yield

    used = pygit2.settings.cached_memory[0]
    total = pygit2.settings.cached_memory[1]
    print(
        'libgit2 cache use: ' \
        f'{used/1024**2:.1f}MB of {total/1024**2:.1f}MB ({used/total*100:.1f}%)'
    )
    print('Shutdown')

def cvd(repo, request):
    """
    Construct Version Directory (CVD)
    """
    if str(repo.head.target) in request.app.state.vd:
        # premature optimization type shi -- caching mechanism
        return request.app.state.vd[str(repo.head.target)]

    prev = {}
    vd = {}

    def construct(tree, commit, name=""):
        names = []
        for e in tree:
            p = f'{name}/{e.name}'[1:]
            if e.id in prev and p in prev[e.id]:
                pass
            else:
                if e.type == ObjectType.BLOB:
                    names += [
                        {"id": e.id,
                         "time": commit.commit_time,
                         "name": p,
                         "length": e.size}
                    ]
                    if e.id in prev:
                        prev[e.id] += [p]
                    else:
                        prev[e.id] = [p]
                if e.type == ObjectType.TREE:
                    names += construct(e, commit, name=f'{name}/{e.name}')

        return names

    for commit in repo.walk(
            repo.head.target,
            SortMode.TOPOLOGICAL | SortMode.TIME | SortMode.REVERSE
    ):
        vd[commit.id] = construct(commit.tree, commit)

    request.app.state.vd[str(repo.head.target)] = vd
    return vd

def cnd(repo, request):
    """
    Construct Name Directory (CND)
    """

    if str(repo.head.target) in request.app.state.nd:
        return request.app.state.nd[str(repo.head.target)]

    nd = {}
    vd = cvd(repo, request)

    for c in reversed(vd):
        for t in vd[c]:
            item = {
                "id": str(t["id"]),
                "commit_id": str(c),
                "time": t["time"]
            }
            if t["name"] in nd:
                nd[t["name"]] += [item]
            else:
                nd[t["name"]] = [item]

    request.app.state.nd[str(repo.head.target)] = nd
    return nd

def cod(repo, request):
    """
    Construct Object Directory (COD)
    """

    if str(repo.head.target) in request.app.state.od:
        return request.app.state.od[str(repo.head.target)]

    od = {}
    vd = cvd(repo, request)

    for c in reversed(vd):
        for t in vd[c]:
            item = {
                "name": t["name"],
                "commit_id": str(c),
                "time": t["time"]
            }
            if t["id"] in od:
                od[t["id"]] += [item]
            else:
                od[t["id"]] = [item]

    request.app.state.od[str(repo.head.target)] = od
    return od

class Metadata(HTTPEndpoint):
    """
    Metadata for the site
    """
    async def noop(self, scope, receive, send):
        """
        No op callable to satisfy the endpoint
        """

    async def get(self, request):
        """
        If a path is present, add flag to scope and re-route,
        otherwise return JSON metadata for the entire repo.
        """
        host = request.headers['host']
        repo = Repository(REPO_HOME)
        head = repo.revparse_single('HEAD')
        meta = request.path_params.get('meta_url')
        try:
            origin = repo.remotes["origin"].url
        except KeyError:
            origin = "None"

        if meta:
            scope = dict(self.scope)
            del scope["root_path"]
            del scope["path_params"]
            scope["path"] = "/" + meta
            scope["raw_path"] = str.encode(scope["path"])
            scope["xu60.meta"] = True
            await request.app(scope, self.receive, self.send)
            return self.noop

        return JSONResponse({
            "site": f'{request.url.scheme}://{host}{request.url.path}',
            "origin": origin,
            "head": str(head.id),
            "last_updated": str(datetime.datetime.fromtimestamp(head.commit_time)),
            "meta": f"/{META_ROUTE}",
            "object": f"/{OBJECT_ROUTE}",
            "versions": f"/{VERSIONS_ROUTE}"
        })


class Directory(HTTPEndpoint):
    """
    Site directory
    """
    async def get(self, request):
        """
        Send version directory, one entry per blob object in the tree.
        """
        repo = Repository(REPO_HOME)
        res = "object,time,name,length\n"

        vd = cvd(repo, request)
        json = []

        for c in reversed(vd):
            for t in vd[c]:
                if self.scope.get("xu60.meta"):
                    t["id"] = str(t["id"])
                    json += [t]
                else:
                    res += f'{t["id"]},{t["time"]},{t["name"]},{t["length"]}\n'
        if self.scope.get("xu60.meta"):
            return JSONResponse(json)
        return Response(res, media_type='text/plain')


class Object(HTTPEndpoint):
    """
    Get object contents from repo
    """
    async def get(self, request):
        """
        Send object contents, with allowable URL pattern for selecting bytes.
        """
        repo = Repository(REPO_HOME)
        oid = request.path_params['object']
        try:
            obj = repo.get(oid)
        except ValueError:
            raise HTTPException(status_code=404, detail="Not Found")

        start = request.path_params.get('start', 0)
        end = request.path_params.get('end', obj.size)

        body = obj.data[start:end]

        if self.scope.get("xu60.meta"):
            od = cod(repo, request)
            nd = cnd(repo, request)
            names = od[obj.id]

            versions = [v["id"] for n in names for v in nd[n["name"]]]
            i = versions.index(oid)
            changes = []
            if len(versions) > i + 1:
                patch = repo.get(versions[i+1]).diff(obj)
                for h in patch.hunks:
                    m = DIFFLINE.search(h.header)
                    startline = int(m[1]) - 1
                    numlines = int(m[2])

                    lines = obj.data.splitlines(keepends=True)
                    prevbytes = sum(len(l) for l in lines[:startline])
                    changebytes = sum(len(l) for l in lines[startline:startline+numlines])
                    changes += [f"{prevbytes}/-/{prevbytes + changebytes}"]

            return JSONResponse({
                "id": str(obj.id),
                "names": names,
                "body": body.decode('utf-8'),
                "length": obj.size,
                "window": {"start": start, "end": end},
                "changes": changes
            })
        return Response(body, media_type='text/plain')


class Versions(HTTPEndpoint):
    """
    Convert file properties to object form.
    """
    async def get(self, request):
        """
        Send version IDs in reverse order (newest first)
        """
        repo = Repository(REPO_HOME)
        p = request.path_params['path_to_file']
        pp = Path(p).parts
        versions = cnd(repo, request)
        start = ""
        end = ""

        if len(pp) > 2 and '-' in pp[-3:]:
            tail = pp[-3:]
            i = tail.index('-')
            if len(pp) == 3 or i == 2 or not tail[0].isdigit():
                p = str(Path(*pp[:-2]))
                if i == 2:
                    start = tail[1]
                else:
                    end = tail[2]
            else:
                start = tail[0]
                end = tail[2]
                p = str(Path(*pp[:-3]))

        try:
            versions = versions[p]
        except KeyError:
            raise HTTPException(status_code=404, detail="Not Found")

        try:
            if start:
                start = int(start)
                versions = [v for v in versions if v["time"] >= start]
            if end:
                end = int(end)
                versions = [v for v in versions if v["time"] <= end]
        except ValueError:
            raise HTTPException(status_code=400, detail="Non-Integer Time Index")

        if self.scope.get("xu60.meta"):
            return JSONResponse({
                "name": p,
                "versions": versions
            })

        res = "\n".join([x["id"] for x in versions]).rstrip()
        return Response(res, media_type='text/plain')


# RESERVED ROUTES: meta, object, versions
routes = [
    Route(f'/{META_ROUTE}', Metadata),
    Mount(f'/{META_ROUTE}',
          routes=[
              Route('/', Metadata),
              Route('/{meta_url:path}', Metadata),
          ]
    ),
    Route(f'/{OBJECT_ROUTE}', Directory),
    Mount(f'/{OBJECT_ROUTE}',
          routes=[
              Route('/', Directory),
              Route('/{object}', Object),
              Route('/{object}/{start:int}/-', Object),
              Route('/{object}/{start:int}/-/{end:int}', Object),
              Route('/{object}/-/{end:int}', Object)
        ]
    ),
    Route(f'/{VERSIONS_ROUTE}', Directory),
    Mount(f'/{VERSIONS_ROUTE}',
          routes=[
              Route('/', Directory),
              Route('/{path_to_file:path}', Versions)
          ]
    ),

    Mount('/', app=StaticFiles(directory=SRV_HOME, html=True)),
]

app = Starlette(debug=True, routes=routes, lifespan=lifespan)
app.state.vd = {} # VERSIONS DIRECTORY
app.state.od = {} # OBJECT DIRECTORY
app.state.nd = {} # NAME DIRECTORY
