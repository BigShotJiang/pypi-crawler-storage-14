from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorCanvasQueryResourceChildRequest:
    pass


@dataclass_json
@dataclass
class V4MonitorCanvasQueryResourceChildResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorCanvasQueryResourceChildReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorCanvasQueryResourceChildReturnObj:
    monitorDimensions: Optional[List['V4MonitorCanvasQueryResourceChildReturnObjMonitorDimensions']] = None  # 维度信息


@dataclass_json
@dataclass
class V4MonitorCanvasQueryResourceChildReturnObjMonitorDimensions:
    key: Optional[str] = None  # 维度字段
    data: Optional[List['V4MonitorCanvasQueryResourceChildReturnObjMonitorDimensionsData']] = None  # 维度信息


@dataclass_json
@dataclass
class V4MonitorCanvasQueryResourceChildReturnObjMonitorDimensionsData:
    value: Optional[str] = None  # 维度值
    desc: Optional[str] = None  # 维度描述



