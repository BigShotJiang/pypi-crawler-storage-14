from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorDescribeProbePointRequest:
    taskID: str  # 站点任务ID



@dataclass_json
@dataclass
class V4MonitorDescribeProbePointResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorDescribeProbePointReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorDescribeProbePointReturnObj:
    result: Optional[List['V4MonitorDescribeProbePointReturnObjResult']] = None  # 统计结果列表


@dataclass_json
@dataclass
class V4MonitorDescribeProbePointReturnObjResult:
    pointID: Optional[str] = None  # 探测节点ID
    data: Optional[List['V4MonitorDescribeProbePointReturnObjResultData']] = None  # 探测点异常统计信息


@dataclass_json
@dataclass
class V4MonitorDescribeProbePointReturnObjResultData:
    value: Optional[int] = None  # 事件统计数量
    samplingTime: Optional[int] = None  # 事件统计采样时间,秒级



