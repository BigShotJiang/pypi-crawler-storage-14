from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionDisableInspectionItemRequest:
    inspectionItem: Optional[int] = None  # 本参数表示巡检项，和巡检类型必传其一，见巡检项查询接口返回。
    inspectionType: Optional[int] = None  # 本参数表示巡检类型，和巡检项必传其一，见巡检项查询接口返回。



@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionDisableInspectionItemResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorIntelligentInspectionDisableInspectionItemReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorIntelligentInspectionDisableInspectionItemReturnObj:
    success: Optional[bool] = None  # 禁用成功标识



