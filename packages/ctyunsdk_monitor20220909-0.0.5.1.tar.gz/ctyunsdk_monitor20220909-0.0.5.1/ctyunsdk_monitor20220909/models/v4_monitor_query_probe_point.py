from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryProbePointRequest:
    pass


@dataclass_json
@dataclass
class V4MonitorQueryProbePointResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorQueryProbePointReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorQueryProbePointReturnObj:
    pointList: Optional[List['V4MonitorQueryProbePointReturnObjPointList']] = None  # 探测节点列表
    totalCount: Optional[int] = None  # 总记录数


@dataclass_json
@dataclass
class V4MonitorQueryProbePointReturnObjPointList:
    pointID: Optional[str] = None  # 探测节点唯一ID
    pointName: Optional[str] = None  # 探测节点名称
    position: Optional[str] = None  # 探测节点区域
    status: Optional[bool] = None  # 探测节点心跳状态
    longitude: Optional[str] = None  # 探测节点经度
    latitude: Optional[str] = None  # 探测节点纬度



