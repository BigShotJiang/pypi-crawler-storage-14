from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorDeleteAlarmRulesRequest:
    regionID: str  # 资源池ID
    alarmRuleIDList: List[str]  # 告警规则ID列表



@dataclass_json
@dataclass
class V4MonitorDeleteAlarmRulesResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorDeleteAlarmRulesReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorDeleteAlarmRulesReturnObj:
    success: Optional[List[str]] = None  # 删除成功的告警规则id列表
    failed: Optional[List[str]] = None  # 删除失败的告警规则id列表



