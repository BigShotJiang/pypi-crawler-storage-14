from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorDisableSiteMonitorRequest:
    taskIDList: List[str]  # 站点监控任务ID列表



@dataclass_json
@dataclass
class V4MonitorDisableSiteMonitorResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorDisableSiteMonitorReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorDisableSiteMonitorReturnObj:
    success: Optional[bool] = None  # 禁用成功标识



