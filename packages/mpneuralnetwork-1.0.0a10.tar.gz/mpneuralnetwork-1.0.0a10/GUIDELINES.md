# Analyse et Feuille de Route de mp-neural-network

Ce document détaille les critiques constructives, les axes d'amélioration et la liste des tâches à accomplir pour faire évoluer la bibliothèque.

---

## 1. Architecture et Design

### ⚠️ Gestion de l'État de l'Optimiseur via `id()`
- **Problème :** Utiliser `id(param)` pour stocker l'état (moments Adam, vélocités) est fragile. Lors du rechargement d'un modèle, les nouveaux tableaux NumPy ont de nouveaux IDs, ce qui déconnecte l'optimiseur de ses états passés.
- **Action :**
  - [ ] **Refactorisation Prioritaire** : Remplacer `id()` par un système de nommage stable (ex: `layer_0_weights`) ou envelopper les poids dans une classe `Parameter` avec un UUID persistant.

---

## 2. Performance et Optimisation (Nouveau)

### 🛑 Le Goulot d'Étranglement `Convolutional` (x1000 plus lent)
- **Problème :** L'implémentation actuelle utilise des boucles Python imbriquées (`for depth... for input_depth...`) et `scipy.signal`. Elle est extrêmement lente et ne supporte pas le batch processing.
- **Action :**
  - [ ] Implémenter **`im2col`** (image to column) pour vectoriser la convolution. Cela transforme les boucles en une seule multiplication matricielle (`dot`), débloquant l'accélération matérielle (BLAS/MKL).
  - [ ] **Bug `params`** : La propriété `params` retourne actuellement un dictionnaire vide. Les poids ne sont pas entraînés.

### 💾 Gestion de la Mémoire (Allocations Temporaires)
- **Problème :** Les opérations arithmétiques standard (`res = input @ weights + bias`) créent de multiples tableaux temporaires en RAM, sollicitant lourdement le Garbage Collector. C'est particulièrement critique dans les optimiseurs (Adam) qui dupliquent plusieurs fois les poids à chaque étape.
- **Action :**
  - [ ] Privilégier les opérations **"in-place"** (`+=`, `*=`, `np.add(..., out=...)`, `np.matmul(..., out=...)`) dans les méthodes `forward`, `backward` et `step`.
  - [ ] Remplacer `np.power(x, 2)` par `np.square(x)` ou `x*x` (plus rapide).

### 🔄 Boucle d'Entraînement Inefficace
- **Problème 1 (Copie RAM)** : À chaque époque, `X_shuffled = X_copy[permutation]` crée une copie complète du dataset en mémoire.
- **Problème 2 (Métriques)** : Calculer des métriques lourdes (`F1Score`, `TopK`) à *chaque batch* ralentit inutilement l'entraînement.
- **Action :**
  - [ ] Mélanger uniquement les **indices** (`idx = perm[...]`) et extraire les batchs à la volée (`X[idx_batch]`) pour éviter la duplication RAM.
  - [ ] Option pour calculer les métriques lourdes uniquement à la fin de l'époque, et garder seulement la `Loss` par batch.

---

## 3. Expérience Utilisateur (DX)

### 🐛 Messages d'Erreur (Formes/Dimensions)
- **Problème :** Les erreurs de dimension (mismatch) proviennent directement de NumPy et sont souvent cryptiques pour l'utilisateur (`ValueError: shapes (32,10) and (50,20) not aligned`).
- **Action :**
  - [ ] Ajouter des vérifications de forme explicites (au moins au `build` ou premier `forward`) avec des messages clairs : *"Layer Dense(10) cannot be connected to Layer Dense(50): expected input size 10, got 50"*.

### 📄 Documentation
- **Problème :** Les fonctionnalités avancées (He Init, Smart Weights, etc.) sont cachées dans le code source.
- **Action :**
  - [ ] Adopter le standard Google/NumPy pour les docstrings.
  - [ ] Documenter clairement les arguments (`Args`) et retours (`Returns`) de toutes les classes publiques.
  - [ ] **Clarté API Loss**: Documenter explicitement ou refactoriser le couplage implicite entre `CrossEntropy` et les logits.

---

## 4. Fonctionnalités Manquantes (Vers la Complétude)

- [ ] **Refactoring `BatchNormalization`** : Adapter la couche pour supporter les entrées 4D (Convolutional). Actuellement, elle ne gère que les entrées 2D (Dense). Il faut gérer les axes de réduction `(0, 2, 3)` pour le cas spatial.
- [ ] **Harmonisation `Layer`** : Refactoriser la classe mère pour utiliser `input_shape` (tuple) partout au lieu de `input_size` (int), afin de supporter proprement les tenseurs multidimensionnels.
- [ ] **`DataLoader` / Générateur** : Permettre l'entraînement sur des datasets plus grands que la RAM via des générateurs Python (`yield` batchs).
- [ ] **`predict` par Batch** : La méthode `predict` doit découper les grosses entrées en mini-batchs internes pour éviter les `MemoryError`.
- [ ] **MaxPooling2D / AveragePooling2D** : Essentiel pour les réseaux convolutionnels modernes.

---

## Terminé

- [x] **Couche `Flatten`** : Implémentée pour faire le pont entre Conv (4D) et Dense (2D).
- [x] **Régularisation L1/L2 (Weight Decay via Optimiseur)**: Implémentée globalement dans les optimiseurs (`SGD`, `Adam`, `RMSprop`) avec exclusion intelligente des biais et paramètres de BatchNormalization.
- [x] **Métriques Modulaires**: Module `metrics` implémenté avec support pour RMSE, Accuracy, Precision, Recall, F1, R2, TopK. (Macro-Average pour multiclasse).
- [x] **Robustesse Optimiseur**: Problème d'identité des objets (`id(param)`) résolu via mise à jour "in-place" lors du chargement des poids.
- [x] **Sauvegarde/Chargement Améliorée**: Refactoring complet pour découpler la sérialisation du Modèle, correction de la perte d'état du `BatchNormalization` et de l'optimiseur.
- [x] **Support `no_bias`**: Ajout de l'option pour désactiver les biais (utile avec BatchNormalization).
- [x] **Optimizers Avancés**: Implémentation de `Adam` et `RMSprop`.
- [x] **Couche `Dropout`**: Ajout de la régularisation par Dropout.
- [x] **Couche `Convolutional` (Basique)**: Implémentation initiale fonctionnelle (non vectorisée).
- [x] **Nouvelles Activations**: Ajout de `PReLU` et `Swish`.
- [x] **Validation Automatique**: Ajout du paramètre `auto_evaluation` pour diviser automatiquement le dataset.
- [x] **Inférence Automatique des Formes (Shape Inference)**: Permettre aux couches de déduire leur `input_shape` de la couche précédente. Le `input_shape` ne serait requis que pour la première couche du modèle.
- [x] **Fiabilisation des Tests**: Ajout de tests de forme et de gradient généralisés pour les couches, activations et fonctions de perte.
- [x] **Initialisation des Poids**: Une première version d'initialisation intelligente a été ajoutée.
- [x] **Linting**: Intégrer `ruff` dans le projet et en CI.
- [x] `ModelCheckpoint`: Pour sauvegarder le meilleur modèle.
- [x] `EarlyStopping` (Arrêt Précoce): Pour arrêter l'entraînement si une métrique stagne.
- [x] `BatchNormalization`: Normalisation des activations pour accélérer la convergence.