# Guide et Faits Intéressants sur le Réseau de Neurones

Ce fichier compile des explications et des faits intéressants rencontrés lors du développement et de l'utilisation de la bibliothèque `mpneuralnetwork`.

## Pourquoi l'Accuracy d'évaluation est-elle meilleure que l'Accuracy d'entraînement ?

Il est fréquent (et même bon signe) d'observer une accuracy plus élevée sur le jeu de validation/test que sur le jeu d'entraînement. Voici les trois raisons principales expliquant ce phénomène dans notre implémentation :

### 1. Dropout
La couche `Dropout` désactive aléatoirement un pourcentage de neurones pendant la phase d'entraînement (`training=True`) pour éviter le sur-apprentissage (overfitting) et forcer la redondance.
- **Entraînement :** Le réseau opère avec une "capacité réduite" et une information bruitée.
- **Évaluation :** Tous les neurones sont actifs (`training=False`). Le réseau utilise toute sa puissance, ce qui améliore naturellement les performances.

### 2. Batch Normalization
La couche `BatchNormalization` normalise les activations différemment selon la phase :
- **Entraînement :** Elle utilise la moyenne et la variance du *batch courant*. Ces statistiques fluctuent d'un batch à l'autre, introduisant du bruit (effet régularisateur).
- **Évaluation :** Elle utilise des moyennes glissantes (`cache_m`, `cache_v`) accumulées pendant l'entraînement. Ces statistiques sont stables et globales, offrant des prédictions plus précises.

### 3. Moyenne vs Instantané
- **Score d'entraînement :** C'est généralement la moyenne des scores obtenus sur chaque batch tout au long de l'époque. Le score inclut donc les performances du modèle au *début* de l'époque (moins bon) et à la *fin* (meilleur).
- **Score d'évaluation :** Il est calculé à la *fin* de l'époque, une fois que le modèle a appris sur toutes les données de cette époque. C'est donc une mesure de la performance du modèle à son meilleur état actuel.

## Architecture Intelligente et Automatisation

Le fichier `model.py` contient plusieurs mécanismes d'auto-configuration ("Smart Features") pour simplifier l'utilisation de la bibliothèque :

### 1. Propagation Automatique des Dimensions
Grâce à la méthode `_build_graph`, l'utilisateur n'a pas besoin de spécifier `input_size` pour chaque couche. Le modèle propage automatiquement la taille de sortie (`output_size`) d'une couche vers l'entrée de la suivante, imitant le comportement ergonomique de frameworks comme Keras.

### 2. Initialisation Contextuelle (`Smart Weights`)
La méthode `_init_smart_weights` analyse la structure du graphe pour choisir la meilleure stratégie d'initialisation :
- **Look-ahead :** Elle regarde quelle couche suit une couche `Dense`.
- **He Initialization :** Sélectionnée automatiquement si la couche suivante est une activation `ReLU`, `PReLU` ou `Swish`.
- **Xavier Initialization :** Sélectionnée pour `Sigmoid`, `Tanh` ou si aucune activation spécifique n'est détectée.
- **Suppression du Biais :** Si une couche `Dense` est suivie d'une `BatchNormalization`, le biais de la couche Dense est automatiquement désactivé (`no_bias=True`), car la normalisation rend ce biais mathématiquement redondant.

### 3. Gestion Automatique de la Sortie
La méthode `_init_output_activation` assure la cohérence entre la fonction de perte et la dernière couche :
- Si la perte est `BinaryCrossEntropy`, une activation `Sigmoid` est attachée ou configurée implicitement.
- Si la perte est `CategoricalCrossEntropy`, une activation `Softmax` est gérée.
Cela permet de bénéficier de la stabilité numérique (Logits Trick) de manière transparente pour l'utilisateur.

### 4. Checkpointing et Early Stopping
Le système de sauvegarde (`model_checkpoint`) conserve en mémoire les poids qui ont produit la **meilleure erreur d'évaluation**, et non simplement les derniers poids. À la fin de l'entraînement (ou après un arrêt précoce `early_stopping`), ces poids optimaux sont restaurés dans le modèle.

## Couches et Initialisation

### 1. Inverted Dropout
Dans `layers.py`, la couche `Dropout` applique une mise à l'échelle immédiate pendant l'entraînement :
```python
mask = ... / (1 - probability)
```
C'est la technique du **Inverted Dropout**.
- **Approche naïve :** On éteint les neurones en entraînement. En test, comme tous les neurones sont allumés, le signal est trop fort, il faut donc réduire les poids manuellement.
- **Approche Inverted :** On amplifie le signal des neurones restants *pendant l'entraînement* (en divisant par `1-p`). Ainsi, l'intensité moyenne du signal est conservée. Le modèle est prêt pour l'inférence sans aucune modification post-entraînement.

### 2. Initialisation : He vs Xavier
L'initialisation des poids n'est pas arbitraire (dans `Dense.init_weights`) :
- **Xavier (Glorot) :** `std = sqrt(1 / input_size)`. Optimisé pour les activations symétriques comme **Sigmoid** ou **Tanh**, pour garder la variance des activations stable.
- **He (Kaiming) :** `std = sqrt(2 / input_size)`. Indispensable pour **ReLU** et ses variantes. Comme ReLU "éteint" la moitié des neurones (ceux < 0), la variance du signal est divisée par 2 à chaque couche. L'initialisation "He" compense en doublant la variance initiale des poids.

### 3. Batch Normalization : Gradient Optimisé
L'implémentation du `backward` de la Batch Normalization utilise une formulation mathématique compacte. Au lieu de calculer séparément les dérivées partielles complexes par rapport à la moyenne et la variance, elle utilise une formule vectorisée qui prend en compte la dépendance de chaque échantillon envers les statistiques du batch entier. C'est beaucoup plus efficace informatiquement.

## Optimiseurs et Régularisation

### 1. Régularisation Sélective (Pas de Weight Decay sur les Biais)
Dans `optimizers.py`, la méthode `apply_regularization` est conçue pour ignorer certains paramètres :
- **Exclus :** Les biais (`bias`), ainsi que les paramètres de BatchNormalization (`gamma`, `beta`).
- **Pourquoi ?** La régularisation (L1/L2) cherche à maintenir les poids petits pour éviter l'overfitting. Cependant, contraindre les biais vers zéro restreint inutilement la capacité du réseau à "décaler" ses activations pour s'adapter aux données, sans pour autant améliorer la généralisation. C'est une bonne pratique standard.

### 2. Adam vs AdamW (Decoupled Weight Decay)
L'implémentation de notre classe `Adam` présente une subtilité importante dans la gestion de la régularisation L2 :
- **Approche Standard (L1) :** La pénalité est ajoutée au gradient *avant* le calcul des moments.
- **Approche Découplée (L2) :** La pénalité est appliquée directement sur les poids *à la fin*, indépendamment de la mise à jour adaptative du learning rate.
- **Intérêt :** Cette méthode s'apparente à **AdamW** (Adam with decoupled Weight Decay). Contrairement à l'implémentation naïve où le terme L2 est noyé dans l'adaptation du pas d'apprentissage, cette version découplée permet une régularisation plus efficace et stable, souvent recommandée pour obtenir de meilleurs résultats de généralisation.

## Stabilité Numérique et Astuces d'Implémentation

### 1. Le "Log-Sum-Exp Trick" (Softmax)
Dans `activations.py`, le calcul du Softmax utilise une astuce cruciale :
```python
m = np.max(input_batch, ...)
e = np.exp(input_batch - m)  # Soustraction du max
```
Calculer `exp(x)` avec de grandes valeurs de `x` provoque rapidement un dépassement de capacité (overflow -> `inf`). En soustrayant le maximum de chaque ligne (`x - max(x)`), toutes les valeurs deviennent négatives ou nulles. L'exponentielle est alors comprise entre 0 et 1, ce qui est numériquement stable, sans changer le résultat mathématique final du Softmax.

### 2. Stabilité des Pertes (Logits Trick)
Dans `losses.py`, les fonctions `BinaryCrossEntropy` et `CategoricalCrossEntropy` calculent la perte directement à partir des **logits** (sortie brute de la couche linéaire) plutôt que des probabilités activées.
- **Formule Stable (BCE) :** `max(x, 0) - x*y + log(1 + exp(-abs(x)))` au lieu de `y*log(p)`.
- **Pourquoi ?** Cela évite les problèmes de précision quand les probabilités sont très proches de 0 ou 1 (ce qui donnerait `log(0) -> -inf`). Cette fusion mathématique ("Loss with Logits") garantit que le modèle peut apprendre même quand il est très confiant mais a tort, sans planter.

### 3. Simplification Élégante du Gradient
Une propriété mathématique remarquable est exploitée dans `losses.py` pour la rétropropagation :
Quand on combine une couche linéaire (logits) + Softmax/Sigmoid + CrossEntropy, la dérivée de la perte par rapport aux logits se simplifie magnifiquement :
`Gradient = Prédictions - Cibles`
Cela évite de calculer des produits matriciels complexes avec la Jacobienne du Softmax, rendant l'entraînement beaucoup plus rapide et efficace. C'est pourquoi la méthode `prime` des pertes est si simple.

## Métriques : Macro-Average vs Weighted vs Micro

L'implémentation des métriques (`Precision`, `Recall`, `F1Score`) utilise par défaut une approche **"Macro-Average"** pour les problèmes multiclasses.

- **Macro-Average (Notre choix) :** Calcule le score indépendamment pour chaque classe, puis en fait la moyenne simple.
    - *Avantage :* Traite toutes les classes comme égales. Si le modèle échoue complètement sur une classe rare (ex: 1% des données), le score Macro va chuter drastiquement. C'est idéal pour s'assurer que le modèle n'ignore aucune classe.
- **Weighted-Average :** Pondère le score de chaque classe par le nombre d'exemples.
    - *Inconvénient :* Si une classe représente 90% des données, le score sera excellent même si le modèle est nul sur les 10% restants. Masque les problèmes sur les classes minoritaires.
- **Micro-Average :** Calcule les métriques globalement sur l'ensemble des prédictions.
    - *Note :* En classification multiclasse standard, `Micro-Precision = Micro-Recall = Micro-F1 = Accuracy`. Cette métrique n'apporte donc aucune information supplémentaire par rapport à l'Accuracy déjà calculée.