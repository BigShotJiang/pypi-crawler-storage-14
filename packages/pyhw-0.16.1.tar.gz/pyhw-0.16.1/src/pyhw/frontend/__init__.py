from .frontendBase import Printer


__all__ = ['Printer']
