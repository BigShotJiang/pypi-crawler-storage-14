class GPUNotFoundException(Exception):
    pass


class BackendException(Exception):
    pass


class OSUnsupportedException(Exception):
    pass


class LogoNotFoundException(Exception):
    pass
