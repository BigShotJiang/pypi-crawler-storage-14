from .uptimeBase import UptimeDetect


__all__ = ['UptimeDetect']
