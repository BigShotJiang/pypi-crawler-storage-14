"""MCP Server for Ai Doctor Api Ai Medical Chatbot Healthcare Ai Assistant"""
