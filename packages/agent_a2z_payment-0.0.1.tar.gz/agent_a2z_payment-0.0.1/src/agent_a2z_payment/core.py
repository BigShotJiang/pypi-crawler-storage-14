import logging
import uuid
from typing import List, Dict, Optional, Union
from enum import Enum
import tiktoken
import time
import math
import stripe
import requests


import sys, os
if sys.version_info <= (3, 9):
    from importlib_resources import files
else:
    from importlib.resources import files

from .constants import *


template_filepath_obj = files('agent_a2z_payment') / "web/checkout/checkout_template.html"
script_filepath_obj = files('agent_a2z_payment') / "web/checkout/checkout_scripts.js"
checkout_success_filepath_obj = files('agent_a2z_payment') / "web/checkout/checkout_success.html"
checkout_failure_filepath_obj = files('agent_a2z_payment') / "web/checkout/checkout_failure.html"

template_filepath = str(template_filepath_obj)
script_filepath = str(script_filepath_obj)
checkout_success_filepath = str(checkout_success_filepath_obj)
checkout_failure_filepath = str(checkout_failure_filepath_obj)

# --- Constants & Configuration ---
class Environment(Enum):
    SANDBOX = "sandbox"
    PRODUCTION = "production"

class PaymentProvider(Enum):
    STRIPE = "stripe"
    PAYPAL = "paypal"
    ALIPAY = "alipay"
    WECHAT = "wechat"
    AGENT_A2Z = "agenta2z"
    CREDIT_CARD = "credit_card"

class PaymentWaitingMode(Enum):
    SSE = "SSE"
    LONG_POOL = "LONG_POOL"

    def __eq__(self, other):
        if isinstance(other, str):
            return self.name == other or self.value == other
        return super().__eq__(other)

# Endpoint Constants
AGENT_A2Z_ENDPOINTS = {
    Environment.SANDBOX: "https://sandbox.aiagenta2z.com/api/pay",
    Environment.PRODUCTION: "https://live.aiagenta2z.com/api/pay"
}

class AgentPaymentConfig:
    """
    Configuration for the Payment SDK.
    Loads from environment variables or direct initialization.
    """
    def __init__(self,
                 environment: str = "sandbox",
                 # ---- Stripe Integration ----
                 stripe_secret_key: Optional[str] = None,
                 stripe_publishable_key: Optional[str] = None,
                 stripe_webhook_secret: Optional[str] = None,
                 agenta2z_api_key: Optional[str] = None,
                 # ---- Paypal Integration ----
                 paypal_client_id: Optional[str] = None,
                 paypal_secret: Optional[str] = None,
                 paypal_webhook_id: Optional[str] = None,
                 alipay_app_id: Optional[str] = None,
                 wechat_mch_id: Optional[str] = None,
                 price_per_thousand_token=0.10,
                 model_name="gpt-4"):

        self.environment = Environment(environment.lower())

        if self.environment == Environment.SANDBOX:
            ## Set different environment keys
            self.stripe_secret_key = stripe_secret_key or os.getenv(KEY_STRIPE_API_KEY_SK_TEST)
            self.stripe_publishable_key = stripe_publishable_key or os.getenv(KEY_STRIPE_API_KEY_PK_TEST)
            self.stripe_webhook_secret = stripe_webhook_secret or os.getenv(KEY_STRIPE_WEBHOOK_SECRET)
            self.agenta2z_api_key = agenta2z_api_key or os.getenv(KEY_AGENT_A2Z_API_KEY_TEST)
            self.agenta2z_base_url = AGENT_A2Z_ENDPOINTS[self.environment]
            self.paypal_client_id = paypal_client_id or os.getenv(KEY_PAYPAL_CLIENT_ID_TEST)
            self.paypal_secret = paypal_secret or os.getenv(KEY_PAYPAL_SECRET_TEST)
            self.paypal_webhook_id = paypal_webhook_id or os.getenv(KEY_PAYPAL_WEBHOOK_ID)
            self.alipay_app_id = alipay_app_id or os.getenv(KEY_ALIPAY_APP_ID_TEST)
            self.wechat_mch_id = wechat_mch_id or os.getenv(KEY_WECHAT_MCH_ID_TEST)

        elif self.environment == Environment.PRODUCTION:

            self.stripe_secret_key = stripe_secret_key or os.getenv(KEY_STRIPE_API_KEY_SK_LIVE)
            self.stripe_publishable_key = stripe_publishable_key or os.getenv(KEY_STRIPE_API_KEY_PK_LIVE)
            self.agenta2z_api_key = agenta2z_api_key or os.getenv(KEY_AGENT_A2Z_API_KEY_LIVE)
            self.agenta2z_base_url = AGENT_A2Z_ENDPOINTS[self.environment]

            self.paypal_client_id = paypal_client_id or os.getenv(KEY_PAYPAL_CLIENT_ID_LIVE)
            self.paypal_secret = paypal_secret or os.getenv(KEY_PAYPAL_SECRET_LIVE)
            self.alipay_app_id = alipay_app_id or os.getenv(KEY_ALIPAY_APP_ID_LIVE)
            self.wechat_mch_id = wechat_mch_id or os.getenv(KEY_WECHAT_MCH_ID_LIVE)

        else:
            raise ValueError("Environment must be either SANDBOX or PRODUCTION")

        self.model_name = model_name
        self.price_per_thousand_token = price_per_thousand_token

class TiktokenAgent:
    """
    A class that wraps token estimation functionality,
    mimicking the core usage of the tiktoken library for counting tokens.
    """

    # Placeholder mapping of model names to their encoding scheme for simulation
    _ENCODING_MAP = {
        "gpt-4": "cl100k_base",
        "gpt-3.5-turbo": "cl100k_base",
        "text-davinci-003": "p50k_base",
        "text-davinci-002": "p50k_base",
        "default": "cl100k_base",
    }

    def __init__(self, model_name: str = "default"):
        """
        Initializes the agent with a specific model encoding.

        :param model_name: The name of the model (e.g., 'gpt-4', 'gpt-3.5-turbo').
        """
        self.model_name = model_name
        self.encoding_name = self._ENCODING_MAP.get(model_name, self._ENCODING_MAP["default"])
        self.encoding = tiktoken.get_encoding(self.encoding_name)
        print(f"Initialized TiktokenAgent for model '{self.model_name}' using encoding '{self.encoding_name}'.")

    def count_tokens(self, text: str) -> int:
        """
        Uses the actual tiktoken encoding to get the precise count.
        """
        token_ids = self.encoding.encode(text)
        return len(token_ids)

    @classmethod
    def from_model_name(cls, model_name: str):
        """
        Class method to create an instance based on a model name.
        """
        return cls(model_name)

def render_template(filepath, **kwargs):
    """
    Loads an HTML template file and formats it using keyword arguments.
    """
    try:
        # Read the entire content of the template file
        with open(filepath, 'r') as f:
            template_content = f.read()
        rendered_html = template_content.format(**kwargs)
        return rendered_html
    except FileNotFoundError:
        return f"Error: Template file not found at {filepath}"
    except KeyError as e:
        return f"Error: Missing variable {e} in template arguments."

class PaymentAgent:
    def __init__(self, config: AgentPaymentConfig):
        self.config = config
        self.orders = {}
        self.tokenizer = TiktokenAgent.from_model_name(config.model_name)
        stripe.api_key = config.stripe_secret_key

    def calculate_payment(self, messages, **kwargs) -> dict:
        """
        Calculate the payment amount needed from the messages.

        :param messages: A list of message dictionaries (e.g., [{"role": "user", "content": "..."}]).
        :return: A dictionary containing the calculated amount, currency, and token count.
        """
        output = {}

        # 1. Estimate Total Tokens
        estimated_tokens = 0
        # Iterate through all messages (assuming message is a dict with a 'content' key)
        for message in messages:
            content = message.get("content", "")
            if content:
                estimated_tokens += self.tokenizer.count_tokens(content)
        price_per_thousand_token = self.config.price_per_thousand_token
        thousands_of_tokens = estimated_tokens / 1000.0
        amount = thousands_of_tokens * price_per_thousand_token

        # Final Output Structure
        output[AMOUNT] = round(amount, 4)
        output[CURRENCY] = CURRENCY_USD
        output[ESTIMATED_TOKENS] = estimated_tokens
        return output

    def create_order(self, amount: int, currency: str = CURRENCY_USD, description: str = "") -> Dict:
        """
            Creates a generic internal order record.
            amount: in smallest unit (e.g., cents)
        """
        order_id = f"order_{uuid.uuid4().hex[:16]}"
        cur_timestamp = int(time.time())
        self.orders[order_id] = {
            ORDER_ID: order_id,
            AMOUNT: amount,
            CURRENCY: currency,
            DESCRIPTION: description,
            STATUS: STATUS_PENDING,
            CREATED: cur_timestamp,
            EVENT: None
        }
        return self.orders[order_id]

    def create_payment(self, order_id: str, method: str):
        """

            Return:
                Payment Related URLs, such as return_url, web_hook
        """
        order = self.orders.get(order_id, {})
        if len(order) == 0:
            print (f"ERROR：create_payment order_id {order_id} status is not found...")
            return {}
        amount = order.get(AMOUNT, 0)
        currency = order.get(CURRENCY, CURRENCY_USD)

        if method == PAYMENT_METHOD_STRIPE:
            return self._stripe_create_payment(order_id, amount, currency)
        elif method == PAYMENT_METHOD_CREDIT_CARD:
            return self._stripe_credit_card_create_payment(order_id, amount, currency)
        elif method == PAYMENT_METHOD_PAYPAL:
            return self._paypal_create_payment(order_id, amount, currency)
        elif method == PAYMENT_METHOD_ALIPAY:
            return self._alipay_create_payment(order_id, amount, currency)
        elif method == PAYMENT_METHOD_WECHAT:
            return self._wechat_create_payment(order_id, amount, currency)
        elif method == PAYMENT_METHOD_AGENTA2Z:
            return self._agenta2z_create_payment(order_id, amount, currency)
        else:
            raise ValueError(f"Unknown payment method {method}")

    # -----------------------------
    # Stripe Checkout (Stripe)
    # -----------------------------
    def _stripe_create_payment(self, order_id, amount, currency):
        """
            stripe amount should be integer value of unit cents
        """
        try:
            amount_cents = math.ceil(amount * 100.0)
            logging.info(f"_stripe_create_payment input amount {amount} {currency} converting to cents {amount_cents} cents {currency} for {order_id}")
            session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                mode="payment",
                line_items=[{
                    "price_data": {
                        "currency": currency.lower(),
                        "unit_amount": amount_cents,
                        "product_data": {"name": f"Order {order_id}"}
                    },
                    "quantity": 1
                }],
                success_url=f"{SUCCESS_URL}{order_id}",
                cancel_url=f"{CANCEL_URL}{order_id}",
            )
            return {KEY_PAYMENT_URL: session.url}

        except Exception as e:
            logging.error(f"_stripe_create_payment failed with error {e}")
            return {KEY_PAYMENT_URL: "", "message": str(e)}

    # -----------------------------
    # Stripe Direct Credit Card
    # -----------------------------
    def _stripe_credit_card_create_payment(self, order_id, amount, currency):
        """
            Stripe use server side secrete key to create payment order
            sk + order -> client_secret
            client_secret, pk display in the web app

            Stripe Publishable Key (pk_live_xxx / pk_test_xxx)
            PaymentIntent Client Secret (pi_xxx_secret_xxx)
        """
        amount_cents = math.ceil(amount * 100.0)
        logging.info(
            f"_stripe_credit_card_create_payment input amount {amount} {currency} converting to cents {amount_cents} cents {currency} for {order_id}")
        intent = stripe.PaymentIntent.create(
            amount=amount_cents,
            currency=currency.lower(),
            metadata={ORDER_ID: order_id},
        )

        return {
            KEY_STRIPE_PUBLISHABLE_KEY: self.config.stripe_publishable_key,
            KEY_STRIPE_CLIENT_SECRET: intent.client_secret,
            KEY_PAYMENT_METHOD: PAYMENT_METHOD_CREDIT_CARD
        }

    # -----------------------------
    # PayPal Integration
    # -----------------------------
    def _paypal_create_payment(self, order_id, amount, currency):
        """

        """
        token = _get_paypal_access_token(
            self.config.paypal_client_id,
            self.config.paypal_secret,
            self.config.environment.value
        )
        if not token:
            raise Exception("_paypal_create_payment Could not retrieve PayPal access token.")
        try:
            ## Token Registered
            base_url = "https://api-m.sandbox.paypal.com" if self.config.environment == Environment.SANDBOX else "https://api-m.paypal.com"
            order_url = f"{base_url}/v2/checkout/orders"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
                "PayPal-Request-Id": order_id  # Ensure idempotency
            }
            order_payload = {
                "intent": "CAPTURE",
                "purchase_units": [{
                    "reference_id": order_id,
                    "amount": {
                        "currency_code": currency,
                        "value": f"{amount:.2f}"
                    },
                    "description": f"Payment for Order {order_id}"
                }],
                "application_context": {
                    "return_url": f"{RETURN_URL}{order_id}",
                    "cancel_url": f"{CANCEL_URL}{order_id}",
                    "brand_name": PAYPAL_BRAND_NAME,
                    "shipping_preference": "NO_SHIPPING"
                }
            }

            response = requests.post(order_url, headers=headers, json=order_payload)
            response.raise_for_status()
            order_data = response.json()

            # 5. Extract Approval Link
            approval_link = next(
                (link['href'] for link in order_data.get('links', []) if link['rel'] == 'approve'),
                None
            )

            if approval_link:
                return {KEY_PAYMENT_URL: approval_link, KEY_PAYPAL_ORDER_ID: order_data["id"]}
            else:
                raise Exception("PayPal order created but no approval link found.")

        except Exception as e:

            print(f"DEBUG: Paypal Checkout Failed with error {e}")
            return {KEY_PAYMENT_URL: f"https://paypal.com/checkout?token={order_id}"}

    # -----------------------------
    # Alipay Integration
    # -----------------------------
    def _alipay_create_payment(self, order_id, amount, currency):
        return {"payment_url": f"https://alipay.com/pay?token={order_id}"}

    def _agenta2z_create_payment(self, order_id, amount, currency):
        return {"payment_url": f"https://aiagenta2z.com/pay/live?token={order_id}"}

    # -----------------------------
    # WeChat Pay Integration
    # -----------------------------
    def _wechat_create_payment(self, order_id, amount, currency):
        return {"qr_code": f"weixin://wxpay/bizpayurl?pr={order_id}"}

    # -----------------------------
    # 3. Notify callback
    # -----------------------------
    def notify_payment(self, order_id: str, status: str):
        self.orders[order_id]["status"] = status

        if status == "success":
            return self.post_process_payment(order_id)

    def post_process_payment(self, order_id: str):
        # E.g. resume LLM run here
        return {
            "status": "complete",
            "order_id": order_id
        }

    def llm_after_payment(self, order_id: str):
        final_message = f"Order {order_id} is paid. The Agent Loop continue and results will be rendered"
        return final_message

    def checkout(self, payment_method: str, order_id: str, amount: float, currency: str):
        """
            The checkout is the main function to create payment by the method user chose, and return valid html, js snippet
            to render on chat/ai output, Create Order should be called before checkout

            Return:
                Dict, key: checkout_html, checkout_js
        """
        checkout_html = ""
        checkout_js = ""

        try:
            if payment_method == PAYMENT_METHOD_PAYPAL:
                ## 1. Paypal Payment
                payment = self.create_payment(order_id, method = payment_method)
                payment_url = payment.get(KEY_PAYMENT_URL, "")
                print(f"INFO: Paypal Checkout URL Successfully: {payment_url}")

                ## credit card on stripe
                if payment_url:
                    html_data_pass = {
                        KEY_TITLE: CHECKOUT_CARD_TITLE,
                        KEY_DESCRIPTION: CHECKOUT_CARD_DESCRIPTION,
                        KEY_AMOUNT: amount,
                        KEY_CURRENCY: currency,
                        KEY_PAYPAL_URL: payment_url,
                        KEY_A2Z_URL: AGENT_A2Z_PAY_URL
                    }
                    # Render a custom HTML template for PayPal (using the same render_checkout_html for simplicity)
                    checkout_html = self.render_checkout_html(**html_data_pass)  # Use a new render function
                    script_data_pass = {
                        KEY_STRIPE_PUBLISHABLE_KEY: "",
                        KEY_STRIPE_CLIENT_SECRET: ""
                    }
                    checkout_js = self.render_checkout_script(**script_data_pass)
                else:
                    checkout_html = PAYPAL_CHECKOUT_ERROR_HTML
                    checkout_js = ""

            elif payment_method == PAYMENT_METHOD_CREDIT_CARD:

                ## 1. Credit Card
                payment = self.create_payment(order_id, method=payment_method)
                payment_url = payment.get(KEY_PAYMENT_URL, "")
                print(f"INFO: Credit Card Stripe Checkout URL Successfully: {payment_url}")

                publishable_key = payment.get(KEY_STRIPE_PUBLISHABLE_KEY, "")
                client_secret = payment.get(KEY_STRIPE_CLIENT_SECRET, "")
                if LOG_ENABLE:
                    print(f"DEBUG: checkout PAYMENT_METHOD_CREDIT_CARD Stripe publishable_key {publishable_key} | client_secret {client_secret}")
                html_data_pass = {
                    KEY_TITLE: CHECKOUT_CARD_TITLE,
                    KEY_DESCRIPTION: CHECKOUT_CARD_DESCRIPTION,
                    KEY_AMOUNT: amount,
                    KEY_CURRENCY: currency,
                    KEY_A2Z_URL: AGENT_A2Z_PAY_URL
                }

                # Render the template
                checkout_html = self.render_checkout_html(**html_data_pass)
                if LOG_ENABLE:
                    print(f"Payment Method {payment_method} checkout_html {checkout_html}")

                script_data_pass = {
                    KEY_STRIPE_PUBLISHABLE_KEY: publishable_key,
                    KEY_STRIPE_CLIENT_SECRET: client_secret
                }
                checkout_js = self.render_checkout_script(**script_data_pass)
                if LOG_ENABLE:
                    print(f"Payment Method {payment_method} checkout_js {checkout_js}")

            elif payment_method == PAYMENT_METHOD_ALL:
                ## 1. add payment Paypal
                payment_card = self.create_payment(order_id, method=PAYMENT_METHOD_CREDIT_CARD)
                payment_url_card = payment_card.get(KEY_PAYMENT_URL, "")
                print(f"INFO: Payment By Credit Card Checkout URL Successfully: {payment_url_card}")
                stripe_publishable_key = payment_card.get(KEY_STRIPE_PUBLISHABLE_KEY, "")
                stripe_client_secret = payment_card.get(KEY_STRIPE_CLIENT_SECRET, "")

                ## add payment credit card
                payment_paypal = self.create_payment(order_id, method=PAYMENT_METHOD_PAYPAL)
                payment_url_paypal = payment_paypal.get(KEY_PAYMENT_URL, "")
                print(f"INFO: Payment By Paypal Checkout URL Successfully: {payment_url_paypal}")

                ## Merge Data in Html
                html_data_pass = {
                    KEY_TITLE: CHECKOUT_CARD_TITLE,
                    KEY_DESCRIPTION: CHECKOUT_CARD_DESCRIPTION,
                    KEY_AMOUNT: amount,
                    KEY_CURRENCY: currency,
                    KEY_PAYPAL_URL: payment_url_paypal,
                    KEY_A2Z_URL: AGENT_A2Z_PAY_URL
                }

                # Render the template
                checkout_html = self.render_checkout_html(**html_data_pass)
                print(f"Payment Method {payment_method} checkout_html {checkout_html}")

                script_data_pass = {
                    KEY_STRIPE_PUBLISHABLE_KEY: stripe_publishable_key,
                    KEY_STRIPE_CLIENT_SECRET: stripe_client_secret
                }
                checkout_js = self.render_checkout_script(**script_data_pass)
                print(f"Payment Method {payment_method} checkout_js {checkout_js}")

            else:
                print(f"DEBUG: PAYMENT_METHOD {payment_method} not supported.")

        except Exception as e:
            print (f"DEBUG: PayPal Checkout Failed with error {e}")

        result = {
            KEY_CHECKOUT_HTML: checkout_html,
            KEY_CHECKOUT_JS: checkout_js
        }
        return result

    def render_checkout_html(self, **html_data):
        """
            Fill the nececary fileds in the checkout html template
            Demo：
            data = {
                "title": "In Agent Purchase Payment",
                "description": "Checkout Card for Purchase Payment",
                "amount": amount,  # Pass the value 25.00
                "currency": currency,
                "a2z_url": "test_pay.aiagenta2z.com"
            }
        """
        return render_template(template_filepath, **html_data)

    def render_checkout_script(self, **script_data):
        """
            e.g. stripe credit checkout js required fields
                script_data = {
                    "publishable_key": publishable_key,
                    "client_secret": client_secret
                }
        """
        return render_template(script_filepath, **script_data)

    def render_checkout_success(self, **order_status):
        """
            e.g. stripe credit checkout js required fields
                order_status: {
                    "order_id": order_id
                }
        """
        return render_template(checkout_success_filepath, **order_status)

    def render_checkout_failure(self, **order_status):
        """
            e.g. stripe credit checkout js required fields
                order_status: {
                    "order_id": order_id
                }
        """
        return render_template(checkout_failure_filepath, **order_status)

# --------------------------------
# --- PayPal Helper Functions ---
# --------------------------------
def _get_paypal_access_token(client_id: str, client_secret: str, environment: str) -> Optional[str]:
    """Retrieves an access token from PayPal."""
    base_url = "https://api-m.sandbox.paypal.com" if environment == Environment.SANDBOX.value else "https://api-m.paypal.com"
    token_url = f"{base_url}/v1/oauth2/token"

    # PayPal uses Basic Auth for token request
    try:
        response = requests.post(
            token_url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data="grant_type=client_credentials",
            auth=(client_id, client_secret)
        )
        response.raise_for_status()
        token_data = response.json()
        return token_data.get(KEY_PAYPAL_ACCESS_TOKEN)
    except requests.exceptions.RequestException as e:
        logging.error(f"_get_paypal_access_token PayPal Token Request Failed: {e}")
        return None

# --- Usage Helper ---
def get_payment_sdk(env="sandbox"):
    cfg = AgentPaymentConfig(environment=env)
    return PaymentAgent(cfg)

