"""Tests for command kit."""
