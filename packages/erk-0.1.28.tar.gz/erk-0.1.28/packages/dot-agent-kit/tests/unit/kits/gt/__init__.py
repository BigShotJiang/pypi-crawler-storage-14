"""Tests for GT kit."""
