"""Integration tests for packaging."""
