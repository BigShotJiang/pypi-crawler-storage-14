"""Output utilities.

Import from submodules:
- output: format_duration, machine_output, user_output
"""
