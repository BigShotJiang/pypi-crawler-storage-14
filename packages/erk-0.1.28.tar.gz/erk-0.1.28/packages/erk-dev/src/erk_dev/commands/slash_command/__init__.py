"""Execute Claude Code slash commands from the command line."""
