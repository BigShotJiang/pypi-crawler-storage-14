# Display Enriched Plan for Review

After receiving the enriched plan from the agent, display it directly in the conversation:

```
## Enriched Plan

**Source:** [source description]

---

[Full enriched plan markdown from agent]

---
```

This allows the user to review the enriched plan before it is saved or used.
