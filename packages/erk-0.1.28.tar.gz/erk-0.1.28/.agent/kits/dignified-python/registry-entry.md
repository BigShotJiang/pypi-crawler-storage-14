### dignified-python (v0.2.0)

**Purpose**: Version-aware Python coding standards with automatic version detection

**Artifacts**:

- skill: skills/dignified-python-310/SKILL.md, skills/dignified-python-311/SKILL.md, skills/dignified-python-312/SKILL.md, skills/dignified-python-313/SKILL.md

**Usage**:

- Load `dignified-python-310` skill
