# Kit Documentation Registry

<!-- AUTO-GENERATED: This file is managed by dot-agent kit commands -->
<!-- DO NOT EDIT: Changes will be overwritten. Use 'dot-agent kit sync' -->

<!-- REGISTRY_VERSION: 1 -->

<!-- BEGIN_ENTRIES -->

<!-- ENTRY_START kit_id="devrun" version="0.1.0" source="bundled" -->

@.agent/kits/devrun/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="dignified-python" version="0.2.0" source="bundled" -->

@.agent/kits/dignified-python/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="erk" version="0.3.1" source="bundled" -->

@.agent/kits/erk/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="fake-driven-testing" version="0.1.0" source="bundled" -->

@.agent/kits/fake-driven-testing/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="gt" version="0.1.0" source="bundled" -->

@.agent/kits/gt/registry-entry.md

<!-- ENTRY_END -->

<!-- END_ENTRIES -->
