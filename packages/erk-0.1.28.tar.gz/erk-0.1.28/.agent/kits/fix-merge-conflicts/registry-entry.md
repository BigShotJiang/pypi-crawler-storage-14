### fix-merge-conflicts (v0.1.0)

**Purpose**: Fix merge conflicts during git rebase with intelligent conflict analysis

**Artifacts**:

- command: commands/fix-merge-conflicts/fix-merge-conflicts.md

**Usage**:

- Run `/fix-merge-conflicts` command
