"""Allow erk to be run as a module: python -m erk."""

from erk import main

if __name__ == "__main__":
    main()
