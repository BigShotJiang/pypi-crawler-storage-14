from mjxml.typeutils import ArrayLike, floatarr_to_str
from typing import Literal, SupportsFloat

__all__ = [
    "RotationType",
    "to_mjc",
]

RotationType = tuple[
    Literal["quat", "axisangle", "euler", "q", "aa", "e"],
    ArrayLike[SupportsFloat, Literal[3, 4, 6]],
]


def to_mjc(rot: RotationType):
    rot_type, values = rot
    if rot_type in ["quat", "q"]:
        mjc_type = "quat"
    elif rot_type in ["axisangle", "aa"]:
        mjc_type = "axisangle"
    elif rot_type in ["euler", "e"]:
        mjc_type = "euler"
    else:
        raise ValueError(f"Unsupported rotation type: {rot_type}")
    return (mjc_type, floatarr_to_str(values))
