import pytest

from ankipan import HtmlWrappers, OngoingTask, get_flashcard_field_registry

flashcard_field_registry = get_flashcard_field_registry({})

@pytest.mark.parametrize('field_name',[field_name for field_name in flashcard_field_registry.keys() if field_name.startswith('definitions_')])
def test_flashcard_fields_definitions(generate_test_environment, request, field_name, data_dir, requests_call_recorder):
    testenv = generate_test_environment(
        extract_kwargs={"lemma_counts": {"応援": 1}},
    )
    field_cls = get_flashcard_field_registry(testenv.collection.as_dict(serialize=False))[field_name]
    testenv.collection.set_flashcard_fields(field_cls.exposed_fields)

    testenv.collection.collect_field_data(testenv.deck_name, min_wait_time=10 if request.config.getoption("--update") else 0)

    for exposed_field_name in field_cls.exposed_fields:
        assert isinstance(testenv.get_flashcard_field(exposed_field_name), HtmlWrappers.CardSection)
    testenv.reload()

    for exposed_field_name in field_cls.exposed_fields:
        assert isinstance(testenv.get_flashcard_field(exposed_field_name), HtmlWrappers.CardSection)

    with open(data_dir / '.field.html', 'w', encoding='utf-8') as f:
        f.write(testenv.first_card.backside)
