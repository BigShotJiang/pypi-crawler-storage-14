# Ankipan

Ankipan is a project to democratize language learning in a decentralized way.

It allows you to choose which domains you want to be more fluent in, and create a custom learning curriculum that aims to get you to your goal as effectively and efficiently as possible.
At the moment we use a flashcard-based approach, where the user first specifies a source text or folder with textdocuments. Ankipan then uses a NLP library to parse all the words and bring them to their root form, and then generates anki flashcards sorted by occurrence frequency in the source.
The flashcards can contain any number of fields that the user is interested in, such as dictionary definitions, example sentences from a particular source, or explanations for how the words are used in the specified source:

<div style="display: flex; gap: 20px; justify-content: center; align-items: center; flex-wrap: wrap;">
  <div style="text-align: center;">
    <img src="/docs/anki_screenshot_1.png" alt="Ankipan flashcard example 1" width="400"/>
    <br><sub>Flashcard Backside</sub>
  </div>
  <div style="text-align: center;">
    <img src="/docs/anki_screenshot_2.png" alt="Ankipan flashcard example 2" width="400"/>
    <br><sub>Expanded example sentence field</sub>
  </div>
</div>

## Getting started

### 1. Prerequisites

- Download and install anki from https://apps.ankiweb.net/
- Create an account on their website
- Install the ankiconnect plugin (In anki, open Tools -> Add Ons -> Get Add-Ons -> paste code 2055492159, see https://ankiweb.net/shared/info/2055492159)
- Open the app and login, keep anki open when syncing databases

### 2. Installation

- Using pip:

```bash
pip install ankipan
```

- From source:

```bash
git clone git@gitlab.com:ankipan/ankipan.git
cd ankipan
pip install .
```

### 3. (Optional) Install lemmatizers to parse your own texts

- Download pytorch from https://pytorch.org/get-started/locally/ (for stanza lemma parsing)
- install dependencies:

```bash
pip install stanza
```

## Usage

See interactive source notebook in `/examples`

```python
# Create a new collection with your name, learning language and native language
from ankipan import Collection
collection = Collection('One Piece 1', learning_lang='jp', native_lang='en')

# Specify content to be downloaded for flashcards (see collection.get_available_sources() for example sentences and scraper.py module)

# the following e.g. prints ['jisho', 'wadoku', 'wikitionary_de', 'wikitionary_en', 'wikitionary_fr', 'wikitionary_jp', 'tatoeba', 'urban']:
print(collection.valid_definition_fields)
# now we select which definitions we want on our flashcard backside:
definitions = ['wadoku', 'jisho', 'wikitionary_en']

# the following e.g. prints ['lyrics', 'wikipedia', 'youtube']:
print(collection.get_available_sources())
# the following e.g. prints ['hajimesyacho', 'sushiramen', 'hikakin', 'fischers']:
print(c.get_available_sources('youtube'))
# the following can also be left empty if you have no preference, otherwise example sentences from the specified sources will be prioritized:
example_sentence_source_paths = ['wikipedia', 'syosetu.com', 'youtube/fischers', 'youtube/sushiramen']

# set the fields in the collection:
c.set_flashcard_fields(definitions = definitions, example_sentence_source_paths = example_sentence_source_paths)

# Specify a source the words of which you would like to add to your deck, either directly as string, as path to file or folder, or directly by source name
# see source names from collection.get_available_sources()

words = collection.collect(source_path='wikipedia/O/ONE_PIECE.html') # from DB, no lemmatizers required
# words = collection.collect(string='かつてこの世の全てを手に入れた男、〝海賊王〟ゴールド・ロジャー。') # from string
# words = collection.collect('./example_text_jp.txt') # textfile from path (original source: https://ja.wikipedia.org/wiki/ONE_PIECE)
# words = collection.collect('./example_subtitle_jp.srt') # subtitle from path

# Select the words you already know and the words you would like to learn from the table overview
words.select_new_words()

# Add words to collection
collection.add_deck(words, 'example_source')

# Optional: Persist collection state to harddrive (see /'.data' folder)
collection.save()

# Download content for new cards (also autosaves collection to drive)
collection.fetch('example_source')

# Sync current collection with anki to upload them to currently open anki instance
collection.sync_with_anki('testsource')

```

## Notes

- Current lemmatization is done via the `stanza` library in the reader.py module. While this works mostly fine, the library still just uses a statistical model to estimate the likely word roots (lemmas) of the different pieces of sentences. It sometimes makes mistakes, which requires the users to manually filter them in the `select_new_words` overview, or suspend the card later on in anki.

## Sentence-level color markers

Example sentence fields now expose a small marker button next to every sentence. Clicking the button opens a color picker and stores the selection in the note's tags so the highlighting persists across reviews and across devices.

- The color picker reads existing marker tags named sentcolor::<encoded_key>::<color> (with color in
ed|orange|yellow|green|blue) and displays matching dots next to the sentence as well as on the parent source collapsible.
- When selecting a new color the frontend removes all previous sentcolor tags for the sentence and adds the newly chosen one.
- To make this work Anki/AnkiDroid must expose a tiny "tag bridge" to the card webview:
  1. **Desktop** � provide a pycmd handler that accepts commands in the shape nkipanSentColor:<action>:<json> where <action> is get, dd, or
emove. The <json> payload is a JSON array of tags (URL encoded). Return the current tag list for get.
  2. **AnkiDroid or other clients** � inject a global window.ankipanTagBridge object with async methods getTags(), ddTags(tags), and
emoveTags(tags) that operate on the current note.

Without the bridge the UI still renders, but selecting a color only affects the local session. Provide the bridge described above (or adapt it to your existing scripting setup) to persist the markers through Anki's sync.
