"""Flash ORM - A powerful, database-agnostic ORM"""

__version__ = "2.2.0"
