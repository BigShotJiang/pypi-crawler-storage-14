"""Authentication schemas."""

from uuid import UUID

from pydantic import BaseModel, EmailStr, Field


class UserLogin(BaseModel):
    """Schema for user login."""

    email: EmailStr
    password: str = Field(..., min_length=8)


class UserRegister(BaseModel):
    """Schema for user registration."""

    email: EmailStr
    password: str = Field(..., min_length=8)
    first_name: str | None = None
    last_name: str | None = None
    phone: str | None = None
    country: str | None = None
    organization_name: str | None = None


class SignupResponse(BaseModel):
    """Schema for signup response."""

    success: bool
    message: str
    user_id: UUID
    email: EmailStr
    username: str | None = None


class LoginResponse(BaseModel):
    """Schema for login response."""

    success: bool
    message: str
    user_id: UUID | None = None


class LogoutRequest(BaseModel):
    """Schema for logout requests."""

    email: EmailStr


class LogoutResponse(BaseModel):
    """Schema for logout responses."""

    success: bool
    message: str

