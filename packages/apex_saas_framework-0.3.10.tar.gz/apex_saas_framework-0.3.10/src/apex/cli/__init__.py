"""CLI utilities module."""

from apex.cli.main import cli, main

__all__ = ["cli", "main"]

