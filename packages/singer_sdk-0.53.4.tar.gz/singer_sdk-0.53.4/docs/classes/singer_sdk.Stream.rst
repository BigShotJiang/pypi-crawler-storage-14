﻿singer_sdk.Stream
=================

.. currentmodule:: singer_sdk

.. autoclass:: Stream
    :members:
    :show-inheritance:
    :inherited-members: Stream
    :special-members: __init__