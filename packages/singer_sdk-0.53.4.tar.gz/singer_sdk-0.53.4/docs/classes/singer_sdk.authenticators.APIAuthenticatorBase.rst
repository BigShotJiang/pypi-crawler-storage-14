﻿singer_sdk.authenticators.APIAuthenticatorBase
==============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: APIAuthenticatorBase
    :members:
    :special-members: __init__, __call__