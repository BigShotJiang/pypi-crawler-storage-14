﻿singer_sdk.sql.connector.SQLToJSONSchema
========================================

.. currentmodule:: singer_sdk.sql.connector

.. autoclass:: SQLToJSONSchema
    :members:
    :special-members: __init__, __call__