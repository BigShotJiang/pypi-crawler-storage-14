﻿singer_sdk.sql.connector.JSONSchemaToSQL
========================================

.. currentmodule:: singer_sdk.sql.connector

.. autoclass:: JSONSchemaToSQL
    :members:
    :special-members: __init__, __call__