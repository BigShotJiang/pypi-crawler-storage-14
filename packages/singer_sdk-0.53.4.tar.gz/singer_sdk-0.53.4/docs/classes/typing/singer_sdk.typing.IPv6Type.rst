﻿singer_sdk.typing.IPv6Type
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: IPv6Type
    :members:
    :special-members: __init__, __call__