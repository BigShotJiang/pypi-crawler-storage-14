﻿singer_sdk.typing.PropertiesList
================================

.. currentmodule:: singer_sdk.typing

.. autoclass:: PropertiesList
    :members:
    :special-members: __init__, __call__