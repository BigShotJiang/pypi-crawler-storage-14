﻿singer_sdk.typing.DecimalType
=============================

.. currentmodule:: singer_sdk.typing

.. autoclass:: DecimalType
    :members:
    :special-members: __init__, __call__