﻿singer_sdk.authenticators.OAuthJWTAuthenticator
===============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: OAuthJWTAuthenticator
    :members:
    :special-members: __init__, __call__