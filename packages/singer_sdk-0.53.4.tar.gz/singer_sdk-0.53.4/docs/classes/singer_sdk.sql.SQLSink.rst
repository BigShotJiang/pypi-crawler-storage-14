﻿singer_sdk.sql.SQLSink
======================

.. currentmodule:: singer_sdk.sql

.. autoclass:: SQLSink
    :members:
    :special-members: __init__, __call__