﻿singer_sdk.pagination.BasePageNumberPaginator
=============================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: BasePageNumberPaginator
    :members:
    :special-members: __init__, __call__