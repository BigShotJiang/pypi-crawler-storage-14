﻿singer_sdk.pagination.SimpleHeaderPaginator
===========================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: SimpleHeaderPaginator
    :members:
    :special-members: __init__, __call__