﻿singer_sdk.authenticators.OAuthAuthenticator
============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: OAuthAuthenticator
    :members:
    :special-members: __init__, __call__