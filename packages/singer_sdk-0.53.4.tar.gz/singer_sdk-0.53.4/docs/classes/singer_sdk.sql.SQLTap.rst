﻿singer_sdk.sql.SQLTap
=====================

.. currentmodule:: singer_sdk.sql

.. autoclass:: SQLTap
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__