"""Configuration parsing and handling."""

from __future__ import annotations
