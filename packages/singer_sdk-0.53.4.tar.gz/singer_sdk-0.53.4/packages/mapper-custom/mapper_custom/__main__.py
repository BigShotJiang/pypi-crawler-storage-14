"""Entry point for the mapper."""

from __future__ import annotations

from mapper_custom.mapper import StreamTransform

StreamTransform.cli()
