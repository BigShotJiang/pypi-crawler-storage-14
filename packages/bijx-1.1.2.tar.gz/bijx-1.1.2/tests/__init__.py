"""
bijx tests.
"""
