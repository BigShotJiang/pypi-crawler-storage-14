# sage_setup: distribution = sagemath-environment
from sage.misc.temporary_file import tmp_dir, tmp_filename
