# src/thingspanel_mcp/prompts/__init__.py
from . import common_prompts

__all__ = ['common_prompts']