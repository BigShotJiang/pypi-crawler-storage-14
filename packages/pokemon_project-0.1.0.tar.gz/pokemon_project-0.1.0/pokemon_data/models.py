from sqlalchemy import Column, Integer, String, Float, Table, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

pokemon_grupo = Table(
    'pokemon_grupo', Base.metadata,
    Column('pokemon_id', ForeignKey('pokemons.id'), primary_key=True),
    Column('grupo_id', ForeignKey('grupos.id'), primary_key=True)
)

class Pokemon(Base):
    __tablename__ = 'pokemons'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    base_experience = Column(Integer)
    height = Column(Float)
    weight = Column(Float)
    grupos = relationship('Grupo', secondary=pokemon_grupo, back_populates='pokemons')

class Grupo(Base):
    __tablename__ = 'grupos'
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)
    pokemons = relationship('Pokemon', secondary=pokemon_grupo, back_populates='grupos')
