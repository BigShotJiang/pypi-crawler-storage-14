import pandas as pd
from database import Session
from models import Pokemon

def export_csv(filename="pokemon_stats.csv"):
    session = Session()
    data = []
    for p in session.query(Pokemon).all():
        grupos = ",".join([g.name for g in p.grupos])
        data.append({
            "id": p.id,
            "name": p.name,
            "base_experience": p.base_experience,
            "height": p.height,
            "weight": p.weight,
            "egg_groups": grupos
        })
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    session.close()
