from database import Session
from models import Pokemon, Grupo

def save_to_db(pokemons_data):
    session = Session()

    grupos_dict = {g.name: g for g in session.query(Grupo).all()}

    for p in pokemons_data:
        # Crear grupos si no existen
        for g_name in p.get('egg_groups', []):
            if g_name not in grupos_dict:
                grupo = Grupo(name=g_name)
                session.add(grupo)
                grupos_dict[g_name] = grupo

    session.commit()  # Guardar los grupos nuevos

    # Crear pokemons y relacionarlos con grupos
    for p in pokemons_data:
        if session.query(Pokemon).filter_by(id=p['id']).first():
            continue  # Evitar duplicados si se ejecuta varias veces
        pokemon = Pokemon(
            id=p['id'],
            name=p['name'],
            base_experience=p['base_experience'],
            height=p['height'],
            weight=p['weight']
        )
        for g_name in p.get('egg_groups', []):
            pokemon.grupos.append(grupos_dict[g_name])
        session.add(pokemon)

    session.commit()
    session.close()
