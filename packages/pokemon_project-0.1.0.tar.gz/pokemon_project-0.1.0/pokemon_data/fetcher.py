import aiohttp
import asyncio

POKEMON_URL = "https://pokeapi.co/api/v2/pokemon?limit=100"

async def fetch_json(session, url):
    async with session.get(url) as response:
        return await response.json()

async def fetch_pokemons():
    async with aiohttp.ClientSession() as session:
        data = await fetch_json(session, POKEMON_URL)
        tasks = [fetch_json(session, pokemon['url']) for pokemon in data['results']]
        pokemons = await asyncio.gather(*tasks)

        # Recuperar egg-groups de species
        async def fetch_species_egg_groups(p):
            species_data = await fetch_json(session, p['species']['url'])
            p['egg_groups'] = [g['name'] for g in species_data['egg_groups']]
            return p

        tasks2 = [fetch_species_egg_groups(p) for p in pokemons]
        pokemons = await asyncio.gather(*tasks2)
        return pokemons
