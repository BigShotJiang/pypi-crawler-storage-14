import asyncio
from database import create_tables
from fetcher import fetch_pokemons
from processor import save_to_db
from export_csv import export_csv

async def main():
    create_tables()
    pokemons = await fetch_pokemons()
    save_to_db(pokemons)
    export_csv()

if __name__ == "__main__":
    asyncio.run(main())
