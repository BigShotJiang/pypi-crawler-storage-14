# Pokémon Project

Proyecto que descarga los primeros 100 Pokémon usando la API de PokeAPI, almacena datos en SQLite y genera estadísticas con pandas.

## Paquetes

### pokemon_data
- Descarga Pokémon y grupos usando asincronía.
- Almacena datos en SQLite.
- Genera CSV `pokemon_stats.csv`.

### pokemon_stats
- Calcula estadísticas a partir del CSV.
- Funciones:
  - `get_grupos_pokemon()`
  - `get_altura_media_grupo(grupo)`
  - `get_peso_medio_grupo(grupo)`

## Licencia
MIT License
