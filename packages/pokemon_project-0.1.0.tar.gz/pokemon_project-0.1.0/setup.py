from setuptools import setup, find_packages

setup(
    name="pokemon_project",
    version="0.1.0",
    author="Laura Martinez",
    author_email="tuemail@example.com",
    description="Paquete de Pokémon: datos y estadísticas",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/lau1401200/pokemon_project",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "pandas",
        "aiohttp",
        "SQLAlchemy"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
