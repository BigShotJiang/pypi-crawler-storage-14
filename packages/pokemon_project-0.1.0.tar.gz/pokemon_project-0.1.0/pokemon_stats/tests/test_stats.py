from ..stats import get_grupos_pokemon, get_altura_media_grupo, get_peso_medio_grupo

def test_grupos():
    grupos = get_grupos_pokemon()
    assert isinstance(grupos, list)
    assert len(grupos) > 0

def test_altura_peso():
    grupos = get_grupos_pokemon()
    for grupo in grupos[:3]:
        altura = get_altura_media_grupo(grupo)
        peso = get_peso_medio_grupo(grupo)
        assert altura > 0
        assert peso > 0
