import pandas as pd

df = pd.read_csv("pokemon_stats.csv")

def get_grupos_pokemon():
    return df['egg_groups'].str.split(',').explode().unique().tolist()

def get_altura_media_grupo(grupo):
    subset = df[df['egg_groups'].str.contains(grupo)]
    return subset['height'].mean()

def get_peso_medio_grupo(grupo):
    subset = df[df['egg_groups'].str.contains(grupo)]
    return subset['weight'].mean()
