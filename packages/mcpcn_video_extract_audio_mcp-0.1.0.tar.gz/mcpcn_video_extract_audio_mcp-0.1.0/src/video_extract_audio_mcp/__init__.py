"""Video Extract Audio MCP - Extract audio from video files."""

__version__ = "0.1.0"
