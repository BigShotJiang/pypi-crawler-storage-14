import sys
import os
import argparse 

# Import all the necessary classes from your 'core.py' file
# ChotuSyntaxError is added for better error handling in REPL
from .core import Lexer, Parser, Interpreter, ChotuFunction, ChotuRuntimeError, ChotuSyntaxError

# --- Documentation String (UPDATED to Version 2.5.1) ---
# This is the full documentation, stored in a string to be printed by 'help'
CHOTULANG_DOCUMENTATION = """
=========================================
 Chotulang Documentation (Version 2.5.1)
=========================================

New in 2.5.1:
- Eliminated Syntax Warnings for chained expressions (e.g., m.pi).
- **Enhanced Error Diagnostics** (shows line and pointer for mistakes).
- Pipe Operator (|>) and Lambda Functions (=>) are now fully supported.

Chotulang is an enhanced, Python-compatible language that supports a blend
of imperative and functional programming concepts.

---------------------------------
 1. CLI Usage
---------------------------------
The interpreter can be run from your terminal.

* `chotulang`
  Starts the Interactive REPL (Read-Eval-Print Loop).

* `chotulang <filename>`
  Executes the specified Chotulang source file (e.g., `my_script.chotu`).

* `chotulang --debug <filename>`
  Executes the file in debug mode, printing Lexer tokens and Parser AST.

* `chotulang -h` or `--help`
  Displays the command-line help message.

---------------------------------
 2. REPL Meta-Commands
---------------------------------
Inside the REPL, the following commands are available:

* `help`
  Prints this full documentation.

* `clear` (or `cls`)
  Clears the terminal screen.

* `debug`
  Toggles debug mode (Tokens/AST) ON or OFF for the current session.

* `load <filename>`
  Loads and executes a .chotu file into the current REPL session.
  Variables and functions from the file will be available to use.
  Example: `load my_functions.chotu`

* `exit` (or `quit`)
  Exits the REPL.

* `-- ... --` (Multi-line Paste)
  Enter `--` on a line by itself to start multi-line input.
  Paste or type your code, then enter `--` on a new line to execute.

---------------------------------
 3. Language Keywords & Syntax
---------------------------------
| Category       | Keyword   | Description |
| :------------- | :-------- | :---------- |
| Declaration | `var`     | Declares a mutable variable (e.g., `var x = 10`). |
| Output | `out`     | Prints expressions (e.g., `out "hello", 1 + 2`). |
| Logic | `if`, `else` | Conditional execution (e.g., `if x > 5 { ... } else { ... }`). |
| Loops | `do`      | Defines a 'while' loop (e.g., `do x < 10 { ... }`). |
| Iteration | `for`, `in` | Iterates over an iterable (e.g., `for i in [1,2,3] { ... }`). |
| Flow Control | `break`, `next` | Exits a loop (`break`) or skips to the next iteration (`next`). |
| Functions | `fn`, `ret` | Defines a function (`fn f(a) { ... }`) and returns a value (`ret a * 2`). |
| Lambda | `=>`      | Defines an anonymous function (e.g., `fn(x) => x + 1`). |
| Error Handle | `try`, `catch` | Handles runtime errors (e.g., `try { ... } catch err_var { ... }`). |
| Module | `use`, `as` | Imports Python modules (e.g., `use math as m`). |
| Static Type | `strict`  | Toggles optional static type checking (e.g., `strict true`). |
| Literals | `true`, `false`, `null` | Boolean and null values. |

---------------------------------
 4. Operators
---------------------------------
* Arithmetic: `+`, `-`, `*`, `/`, `%`
* Compound: `+=`, `-=`, `*=`, `/=`, `%=` (e.g., `x += 1`)
* Comparison: `==`, `!=`, `<`, `>`, `<=`, `>=`
* Logical: `and`, `or`, `not`
* **Pipe: `|>`** (e.g., `10 |> add_five |> double`)
* Range: `..` (e.g., `1..10` creates a list from 1 to 9)
* Null Coalesce: `??` (e.g., `a ?? "default"`)

---------------------------------
 5. Data Types
---------------------------------
* Numbers: `123`, `45.6`
* Strings: `"hello"`, `'world'`
* Lists: `[1, "two", true]`
* Dicts: `{"a": 1, "b": 2}`
* Functions: First-class citizens. They can be assigned to variables and
               passed to other functions.

---------------------------------
 6. Built-in Functions
---------------------------------
* `len()`, `input()`, `type()`, `range()`
* `num()`, `str()`, `bool()`, `list()` (Type conversions)
* `map()`, `filter()`, `reduce()` (Supports Chotulang `fn` types)
* `keys()`, `values()`, `items()`, `sorted()`, `reversed()`
* `read_file()`, `write_file()`, `append_file()`
* `json_parse()`, `json_stringify()`
* `py_import()`, `py_call()`, `py_get()`, `py_set()` (Python Interop)
* ...and many more math/utility functions.

---------------------------------
 7. Method Calls
---------------------------------
* String: `my_str.upper()`, `my_str.lower()`, `my_str.split(',')`
* List: `my_list.append(x)`, `my_list.pop()`, `my_list.sort()`
* Dict: `my_dict.keys()`, `my_dict.values()`, `my_dict.get(key)`

Author: Vishnu Deviprasad Shetty (a.k.a idkshetty a.k.a chotu)
"""

def print_help():
    """Prints the formatted documentation."""
    print(CHOTULANG_DOCUMENTATION)

# --- REVISED 'run_code' ---
# Executes code and returns True on success, False on error.
def run_code(interpreter, code, debug=False):
    """
    Tokenizes, parses, and interprets a block of Chotulang code
    using a persistent interpreter.
    
    Returns True on success, False on error.
    """
    try:
        lexer = Lexer(code); tokens = lexer.tokenize()
        if debug: print("Tokens:", tokens)
            
        # IMPORTANT: Pass the source 'code' to the Parser for contextual error reporting
        parser = Parser(tokens, code); ast = parser.parse()
        if debug: print("AST:", ast)
        
        result = interpreter.interpret(ast)
        
        # Print the result of expressions (for REPL)
        if result is not None:
            if isinstance(result, ChotuFunction):
                print(repr(result))
            else:
                print(result)
        return True

    except ChotuSyntaxError as e:
        print(f"Syntax Error: {e}")
        return False
    except Exception as e:
        # ChotuRuntimeError already includes line number if available
        print(f"Error: {e}") 
        return False

# --- ENHANCED CLI: Using argparse and Multi-line Delimiters ---
def main():
    # Setup argument parsing
    parser = argparse.ArgumentParser(
        description="Chotulang Interpreter and REPL (Version 2.5.1).",
        epilog="If no file is provided, the interpreter starts in REPL mode."
    )
    
    parser.add_argument(
        'filename',
        nargs='?', 
        default=None,
        help="Path to the Chotulang source file (.chotu) to execute."
    )
    
    parser.add_argument(
        '-d', '--debug',
        action='store_true',
        help="Enable debug mode, showing Lexer tokens and Parser AST."
    )
    
    args = parser.parse_args()
    
    # Create one interpreter for the whole session
    interpreter = Interpreter()
    
    # --- File Execution Mode ---
    if args.filename:
        filename = args.filename
        if not os.path.exists(filename): 
            print(f"Error: File '{filename}' not found")
            sys.exit(1)
        with open(filename, 'r', encoding='utf-8') as f: 
            code = f.read()
        
        run_code(interpreter, code, debug=args.debug) 
    
    # --- REPL Mode (UPDATED for Multi-line Delimiter) ---
    else:
        print("Chotulang Enhanced REPL (Type 'help' for documentation, 'exit' to quit)")
        debug_mode = args.debug 
        
        code_block = [] 
        pasting_mode = False # State flag for multi-line input
        
        while True:
            try:
                # Set the prompt based on the mode
                prompt = "... " if pasting_mode else "> "
                line = input(prompt)
                
                # --- Handle Pasting Mode ---
                if pasting_mode:
                    if line.strip() == '--':
                        pasting_mode = False
                        full_code = "\n".join(code_block)
                        
                        # Execute the collected block if it's not empty
                        if full_code.strip():
                            run_code(interpreter, full_code, debug=debug_mode)
                        
                        code_block = [] # Reset block
                        continue
                    else:
                        code_block.append(line)
                        continue
                
                # --- Handle Single-Line / Command Mode ---
                
                # Check for multi-line start
                if line.strip() == '--':
                    pasting_mode = True
                    print("--- Pasting mode started (end with '--') ---")
                    continue
                
                # Check for empty line
                if not line.strip():
                    continue

                command = line.strip().lower()

                # --- Handle REPL Meta-Commands (only in single-line mode) ---
                if command in ['exit', 'quit']:
                    break
                
                elif command == 'help':
                    print_help()
                    continue

                elif command in ['clear', 'cls']:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    continue
                
                elif command == 'debug':
                    debug_mode = not debug_mode
                    print(f"Debug mode is now {'ON' if debug_mode else 'OFF'}")
                    continue

                elif command.startswith('load '):
                    filename = line.strip()[5:]
                    if not filename:
                        print("Error: Please specify a filename. Usage: load <filename>")
                        continue
                    if not os.path.exists(filename):
                        print(f"Error: File '{filename}' not found")
                        continue
                    
                    try:
                        with open(filename, 'r', encoding='utf-8') as f:
                            file_code = f.read()
                        print(f"Loading and executing '{filename}'...")
                        run_code(interpreter, file_code, debug=debug_mode)
                    except Exception as e:
                        print(f"Error loading file: {e}")
                    continue
                
                # --- Execute Single-Line Chotulang Code ---
                run_code(interpreter, line, debug=debug_mode) 

            except KeyboardInterrupt: 
                if pasting_mode:
                    print("\n--- Pasting mode cancelled ---")
                    pasting_mode = False
                    code_block = [] 
                else:
                    print("\nBye!"); 
                    break
            except EOFError:
                print("\nBye!")
                break
            except Exception as e: 
                print(f"Internal Error: {e}")
                pasting_mode = False
                code_block = []