"""Version information for linux_ssh_mcp package."""

__version__ = "1.0.0"
__author__ = "SSH MCP Development Team"
__email__ = "developer@sshmcp.local"
__license__ = "MIT"