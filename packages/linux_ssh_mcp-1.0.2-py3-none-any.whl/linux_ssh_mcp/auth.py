#!/usr/bin/env python3
"""
认证和授权模块
"""

import hashlib
import secrets
from typing import Dict, Optional, List, Any
from enum import Enum
from dataclasses import dataclass
import time


class UserRole(Enum):
    """用户角色枚举"""
    READONLY = "readonly"
    OPERATOR = "operator"
    ADMIN = "admin"
    SUPERUSER = "superuser"


class AuthMethod(Enum):
    """认证方法枚举"""
    PASSWORD = "password"
    API_KEY = "api_key"
    SSH_KEY = "ssh_key"
    TOKEN = "token"
    LDAP = "ldap"
    OAUTH = "oauth"


@dataclass
class User:
    """用户信息"""
    username: str
    password_hash: str
    role: UserRole
    auth_methods: List[AuthMethod]
    api_key: Optional[str] = None
    created_at: float = None
    last_login: Optional[float] = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = time.time()


@dataclass
class Session:
    """会话信息"""
    session_id: str
    username: str
    role: UserRole
    created_at: float
    expires_at: float
    last_activity: float


class AuthManager:
    """认证管理器"""

    def __init__(self):
        self.users: Dict[str, User] = {}
        self.sessions: Dict[str, Session] = {}
        self.api_keys: Dict[str, str] = {}  # api_key -> username
        self.session_timeout = 3600  # 1小时
        self.max_sessions_per_user = 10

    def create_user(self, username: str, password: str, role: UserRole = UserRole.READONLY) -> User:
        """创建用户"""
        if username in self.users:
            raise ValueError(f"用户 {username} 已存在")

        # 密码强度检查
        if len(password) < 8:
            raise ValueError("密码长度至少8位")

        password_hash = self._hash_password(password)
        user = User(
            username=username,
            password_hash=password_hash,
            role=role,
            auth_methods=[AuthMethod.PASSWORD]
        )

        # 生成API密钥
        user.api_key = self._generate_api_key()
        self.api_keys[user.api_key] = username

        self.users[username] = user
        return user

    def authenticate(self, username: str, password: str) -> Optional[str]:
        """用户认证，返回会话ID"""
        user = self.users.get(username)
        if not user:
            return None

        if not self._verify_password(password, user.password_hash):
            return None

        # 创建会话
        session_id = self._generate_session_id()
        now = time.time()

        # 检查会话数量限制
        user_sessions = [s for s in self.sessions.values() if s.username == username]
        if len(user_sessions) >= self.max_sessions_per_user:
            # 删除最旧的会话
            oldest_session = min(user_sessions, key=lambda s: s.last_activity)
            del self.sessions[oldest_session.session_id]

        session = Session(
            session_id=session_id,
            username=username,
            role=user.role,
            created_at=now,
            expires_at=now + self.session_timeout,
            last_activity=now
        )

        self.sessions[session_id] = session
        user.last_login = now

        return session_id

    def authenticate_api_key(self, api_key: str) -> Optional[str]:
        """API密钥认证"""
        username = self.api_keys.get(api_key)
        if not username:
            return None

        user = self.users.get(username)
        if not user:
            return None

        # 创建会话
        session_id = self._generate_session_id()
        now = time.time()

        session = Session(
            session_id=session_id,
            username=username,
            role=user.role,
            created_at=now,
            expires_at=now + self.session_timeout,
            last_activity=now
        )

        self.sessions[session_id] = session
        return session_id

    def validate_session(self, session_id: str) -> Optional[Session]:
        """验证会话"""
        session = self.sessions.get(session_id)
        if not session:
            return None

        now = time.time()
        if now > session.expires_at:
            del self.sessions[session_id]
            return None

        # 更新最后活动时间
        session.last_activity = now
        session.expires_at = now + self.session_timeout

        return session

    def logout(self, session_id: str) -> bool:
        """用户登出"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False

    def has_permission(self, session_id: str, required_role: UserRole) -> bool:
        """检查权限"""
        session = self.validate_session(session_id)
        if not session:
            return False

        # 角色权限等级
        role_hierarchy = {
            UserRole.READONLY: 1,
            UserRole.OPERATOR: 2,
            UserRole.ADMIN: 3,
            UserRole.SUPERUSER: 4
        }

        user_level = role_hierarchy.get(session.role, 0)
        required_level = role_hierarchy.get(required_role, 0)

        return user_level >= required_level

    def get_user(self, username: str) -> Optional[User]:
        """获取用户信息"""
        return self.users.get(username)

    def change_password(self, username: str, old_password: str, new_password: str) -> bool:
        """修改密码"""
        user = self.users.get(username)
        if not user:
            return False

        if not self._verify_password(old_password, user.password_hash):
            return False

        if len(new_password) < 8:
            raise ValueError("密码长度至少8位")

        user.password_hash = self._hash_password(new_password)
        return True

    def regenerate_api_key(self, username: str) -> str:
        """重新生成API密钥"""
        user = self.users.get(username)
        if not user:
            raise ValueError(f"用户 {username} 不存在")

        # 删除旧API密钥
        if user.api_key:
            del self.api_keys[user.api_key]

        # 生成新API密钥
        new_api_key = self._generate_api_key()
        user.api_key = new_api_key
        self.api_keys[new_api_key] = username

        return new_api_key

    def cleanup_expired_sessions(self) -> int:
        """清理过期会话"""
        now = time.time()
        expired_sessions = [
            session_id for session_id, session in self.sessions.items()
            if now > session.expires_at
        ]

        for session_id in expired_sessions:
            del self.sessions[session_id]

        return len(expired_sessions)

    def get_stats(self) -> Dict[str, Any]:
        """获取认证统计信息"""
        return {
            "total_users": len(self.users),
            "active_sessions": len(self.sessions),
            "api_keys": len(self.api_keys),
            "users_by_role": {
                role.value: sum(1 for user in self.users.values() if user.role == role)
                for role in UserRole
            }
        }

    def _hash_password(self, password: str) -> str:
        """密码哈希"""
        return hashlib.sha256(password.encode()).hexdigest()

    def _verify_password(self, password: str, password_hash: str) -> bool:
        """验证密码"""
        return self._hash_password(password) == password_hash

    def _generate_session_id(self) -> str:
        """生成会话ID"""
        return secrets.token_urlsafe(32)

    def _generate_api_key(self) -> str:
        """生成API密钥"""
        return f"sshmcp_{secrets.token_urlsafe(24)}"

    def _check_password_strength(self, password: str) -> bool:
        """检查密码强度"""
        if len(password) < 8:
            return False

        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)

        return has_upper and has_lower and has_digit and has_special