"""
Linux SSH MCP - Main Package
"""

from .ssh_manager import SSHManager, ServerConfig
from .auth import AuthManager

__version__ = "1.0.0"
__author__ = "SSH MCP Team"

__all__ = [
    "SSHManager",
    "ServerConfig",
    "AuthManager"
]