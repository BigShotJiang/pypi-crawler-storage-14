# Changelog

All notable changes to Malha will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.1] - 2024-11-25

### ⚡ High-Performance Append-Only Insertion

This release adds optimized insertion methods for log tables and append-only data.

#### Added

**Append-Only Insertion (No SCD2 Overhead)**
- `kernel.insert(obj)`: Single record insertion without version locking
- `kernel.insert_batch(objects)`: Batch insertion in single transaction
- Optional `replicate=True` flag for outbox/graph sync
- Ideal for: audit logs, telemetry, event streams, immutable records

#### Performance Characteristics
- **No SELECT FOR UPDATE**: Skips pessimistic locking
- **No version closing**: Skips SCD2 logic entirely
- **Single transaction**: Batch inserts all records atomically
- **Optional replication**: Only adds outbox entries when needed

#### Use Cases
```python
# High-performance log insertion
log = AuditLog(action="user_login", user_id="123")
await kernel.insert(log)

# Batch telemetry (500 events in one transaction)
events = [TelemetryEvent(metric="cpu", value=v) for v in values]
await kernel.insert_batch(events)

# Append-only with graph sync
await kernel.insert(transaction, replicate=True)
```

---

## [0.7.0] - 2024-11-24

### 🌀 Helix Pattern Complete - Topology Sync & Ghost Nodes

This release completes the **Helix Pattern** implementation, enabling Virtual Objects to participate in the graph without being persisted in the SQL layer.

#### Added

**TopologySyncService (Graph Topology Materializer)**
- New `malha.services.TopologySyncService` class for materializing graph topology from external sources
- `sync_relationship()`: Sync FK relationships from external tables to graph edges
- `sync_bidirectional()`: Sync many-to-many relationships (junction tables)
- `bulk_create_edges()`: Optimized bulk edge creation
- `generate_virtual_rid()`: Deterministic RID generation using UUIDv5 hashing
- Progress callbacks for long-running sync operations
- Statistics tracking (total_syncs, total_edges_created, total_errors)

**Ghost Nodes (Helix Pattern)**
- `KuzuActor.ensure_ghost_schema()`: Creates Object node table and LINK relationship table
- `KuzuActor.create_edge(create_ghost_nodes=True)`: Auto-creates stub nodes for missing RIDs
- Ghost nodes have `virtual=true` flag to distinguish from SQL-persisted entities
- Enables connecting Virtual Objects that live in external systems

**Column Selection for Lightweight Queries**
- `query_federated(columns=[...])`: Select specific columns instead of `SELECT *`
- Reduces data transfer for topology extraction (only keys needed)
- SQL injection protection for column names

#### Changed
- `DuckDBDriver.query_federated()` now accepts optional `columns` parameter
- `UnifiedDataManager.query_federated()` passes `columns` to driver
- All `_build_*_query()` methods updated to support column selection

#### Technical Details
- Ghost Node schema uses generic `LINK` relationship table with `label` property
- Separate MERGE operations for Kùzu compatibility (no multi-MERGE support)
- Idempotent schema creation with `_ghost_schema_initialized` flag

---

## [0.6.1] - 2024-11-24

### 🎨 State-of-the-Art Developer Experience

#### Added
- **Context Manager**: `async with kernel` for automatic cleanup
- **Federation Shortcuts**: `from_postgres()`, `from_parquet()`, `from_csv()`, `from_sqlite()`
- **Dynamic Version**: Uses `importlib.metadata` (single source of truth)
- **Better Exports**: Organized `__all__` with categories

#### Fixed
- Removed DEBUG logs and print statements from production code
- Improved error messages with examples for all federation errors
- Fixed SQLite attach duplicate error handling

#### Documentation
- Complete README rewrite with Federation docs
- Added badges (PyPI, coverage, Python version)
- Added API reference tables

---

## [0.6.0] - 2024-11-24

### 🌐 Federation Support (Helix) - Zero-ETL Analytics

This release introduces **federated query capabilities** enabling Zero-ETL analytics across external data sources.

#### Added

**DuckDB Federation (Helix)**
- `DuckDBDriver.query_federated()`: Execute queries on external sources without data movement
- Support for multiple source types:
  - **PostgreSQL**: Direct TCP connection via `postgres_scan` with predicate pushdown
  - **Parquet**: Local files or S3 paths
  - **CSV**: Auto-detection of delimiters and types
  - **SQLite**: Attach and query external databases
  - **S3**: Configurable credentials and region
- `DuckDBDriver.query_df()`: Return results as JSON-serializable list of dicts
- Dynamic extension loading with `_load_extension()`
- S3 credential configuration for remote file access

**UnifiedDataManager Integration**
- `kernel.query_federated()`: Proxy method for semantic layer integration
- Enables VirtualObject pattern where domain objects delegate queries to kernel

**Comprehensive Test Suite**
- 41 new federation tests covering all source types
- Tests for error handling, validation, and edge cases
- Integration tests with kernel proxy

#### Technical Details

```python
# Query PostgreSQL directly (Zero-ETL)
customers = await kernel.query_federated({
    "type": "postgres",
    "dsn": "dbname=legacy user=reader host=db.example.com",
    "table": "customers"
}, "status = 'active' AND created_at > '2024-01-01'")

# Query Parquet on S3
events = await kernel.query_federated({
    "type": "parquet",
    "path": "s3://bucket/data/events.parquet"
}, "event_type = 'purchase'")
```

#### Benefits
- **Zero-ETL**: No pipelines needed to copy data from legacy systems
- **Predicate Pushdown**: DuckDB pushes filters to source, minimizing data transfer
- **Security**: Credentials used at runtime only, not persisted
- **Performance**: Query external data as if it were local

---

## [0.5.1] - 2024-11-24

### 🧪 Test Coverage Improvements

- Comprehensive gRPC mocking for Synapse driver (40% → 75%)
- Overall coverage improved to 87%
- 215 tests passing

---

## [0.5.0] - 2024-11-24

### 🎯 Major Architectural Refactoring - Domain Envelope Pattern

This release represents a **fundamental architectural evolution** of Malha, adopting the Domain Envelope pattern from `registro` v0.7.0+ and introducing comprehensive Time Travel capabilities.

#### Added

**Domain Envelope Pattern**
- Full integration with `registro.DomainResource` as the official base class
- Removed duplicate `BaseResource` implementation (~65 lines eliminated)
- Transparent envelope conversion (`to_envelope()` / `from_envelope()`)
- Schema-on-Read support via `meta_tags` JSON field
- Rich domain objects with Pydantic validation

**Time Travel (SCD Type 2 Support)**
- `BaseRepository.get()` enhanced with temporal parameters:
  - `rid`: Logical resource identifier
  - `version`: Specific version number
  - `at_time`: Point-in-time queries
  - `active_only`: Filter for active versions only
- New `BaseRepository.get_history()` method for complete version history
- Bitemporal timestamp tracking (`valid_from`, `valid_to`, `tx_from`, `tx_to`)
- Audit trail and historical data analysis capabilities

**Enhanced Repository**
- Queries operate on physical table (`Resource`)
- Returns hydrated domain objects automatically
- Supports filtering by SQL columns
- Optimistic locking with version checking

**Interceptor Improvements**
- Interceptors now receive `DomainResource` objects
- Enables rich domain validation and transformation
- Access to full object graph, not just SQL columns

**Outbox & Replication**
- Outbox payload is now domain object JSON (not physical envelope)
- Uses `global_registry` from `registro` for class discovery
- Synapse driver instantiates `DomainResource` on remote events
- Fallback to generic `DomainResource` if class not found

**Documentation**
- `MIGRATION_DOMAIN_ENVELOPE.md`: Complete migration guide
- `REFACTORING_SUMMARY.md`: Technical implementation details
- `TEST_RESULTS.md`: Comprehensive test results
- `examples/domain_envelope_example.py`: Practical usage examples

**Testing**
- 23 tests for Domain Envelope pattern (100% passing)
- 11 tests for Time Travel functionality (100% passing)
- Total: 34 new tests validating core functionality

#### Changed

**Dependencies**
- Updated `registro` from 0.5.1 to **0.7.0** (required)
- Requires Python 3.13+

**BaseRepository**
- `get()` signature changed to support Time Travel
- Queries always on `RegistroResource` (physical table)
- Returns hydrated `DomainResource` objects
- Added `get_history()` for version history

**UnifiedDataManager**
- `save_versioned()` accepts `DomainResource` (not `RegistroResource`)
- Converts to envelope internally via `to_envelope()`
- Outbox payload is domain object JSON
- Improved pessimistic locking with envelope handling

**Interceptor Protocol**
- `on_write()` and `on_read()` now receive `DomainResource`
- Breaking change: update custom interceptors

**SynapseDriver**
- Uses `global_registry` for class discovery
- Instantiates `DomainResource` on replication
- Improved error handling with fallbacks

**Exports**
- Added `OptimisticLockError` to public API
- Added `ValidationError` to public API
- Added `SysOutbox` to public API
- Added `BaseRepository` to public API

#### Fixed

- Envelope conversion preserves all domain fields
- Dynamic fields correctly stored in `meta_tags`
- Roundtrip conversion (Domain → Envelope → Domain) lossless
- Pessimistic locking works with envelope pattern
- Outbox processor handles domain objects correctly

### 📦 Migration Guide

#### Breaking Changes

1. **`malha.BaseResource` removed**
   - **Before:** `from malha import BaseResource`
   - **After:** `from registro import DomainResource`

2. **`BaseRepository.get()` signature changed**
   - **Before:** `get(session, id=None, version=None, **filters)`
   - **After:** `get(session, id=None, rid=None, version=None, at_time=None, active_only=True, **filters)`

3. **Interceptors receive `DomainResource`**
   - **Before:** `async def on_write(self, obj: RegistroResource, agent=None)`
   - **After:** `async def on_write(self, obj: DomainResource, agent=None)`

#### Code Migration

**Step 1: Update imports**
```python
# Before
from malha import BaseResource

# After
from registro import DomainResource, register
```

**Step 2: Update resource classes**
```python
# Before
class User(BaseResource):
    name: str
    email: str

# After
class User(DomainResource):
    name: str
    email: str

# Register for global discovery
register("User", User)
```

**Step 3: Update interceptors**
```python
# Before
class MyInterceptor(Interceptor):
    async def on_write(self, obj: RegistroResource, agent=None):
        pass

# After
class MyInterceptor(Interceptor):
    async def on_write(self, obj: DomainResource, agent=None):
        # Now has access to rich domain object
        if isinstance(obj, User):
            # Domain-specific validation
            pass
```

**Step 4: Use Time Travel features**
```python
repo = kernel.get_repository(User)

# Get current version
user = await repo.get(session, rid="ri.app.prod.user.123")

# Get specific version
user_v1 = await repo.get(session, rid="ri.app.prod.user.123", version=1)

# Point-in-time query
user_past = await repo.get(
    session,
    rid="ri.app.prod.user.123",
    at_time=datetime(2024, 1, 1)
)

# Get complete history
history = await repo.get_history(session, rid="ri.app.prod.user.123")
for version in history:
    print(f"Version {version.version}: {version.name}")
```

### ⚠️ Known Limitations

1. **SCD Type 2 Constraint**: `registro.Resource` has `UNIQUE` constraint on `rid`, preventing true SCD Type 2 (multiple versions with same RID). Each "update" creates new resource with new RID. Full SCD Type 2 requires schema change in `registro`.

2. **Performance**: Bulk operations (100+ records) may be slow due to outbox processing. Consider disabling outbox for batch imports.

### 📊 Statistics

- **Lines Added**: ~3,000
- **Lines Removed**: ~200
- **New Files**: 7
- **Modified Files**: 5
- **New Tests**: 34
- **Test Coverage**: 100% (Domain Envelope + Time Travel)
- **Breaking Changes**: 3 (documented above)

### 🎓 Learning Resources

- [Migration Guide](MIGRATION_DOMAIN_ENVELOPE.md)
- [Technical Summary](REFACTORING_SUMMARY.md)
- [Test Results](TEST_RESULTS.md)
- [Practical Example](examples/domain_envelope_example.py)

---

## [0.3.0] - 2024-11-24

### 🚀 Major Features - State of the Art Upgrade

This release transforms Malha into a **distributed data kernel** with production-grade concurrency control and P2P mesh replication.

#### Added

**Distributed Replication (Synapse)**
- New `ReplicationDriver` protocol for pluggable P2P drivers
- `SynapseDriver` implementation using gRPC bidirectional streaming
- Protocol buffer schema (`malha/protos/synapse.proto`)
- Automatic peer connection management
- Transaction ID deduplication for idempotency
- Health check endpoint for monitoring
- Loop prevention via origin tracking

**Concurrency Hardening**
- Pessimistic locking with `SELECT FOR UPDATE` in `save_versioned()`
- Prevents race conditions in SCD Type 2 version rotation
- Guarantees atomic closure of active versions under high load

**Resilient Outbox Processing**
- Dead Letter Queue (DLQ) for events that fail after 5 retries
- Exponential backoff retry strategy (2^n seconds)
- Non-blocking error handling
- Status tracking: `PENDING`, `RETRY`, `DONE`, `DEAD_LETTER`

**New SysOutbox Fields**
- `origin_node` (str): Tracks event origin for loop prevention
- `retries` (int): Counts retry attempts
- `next_retry_at` (datetime): Schedules next retry

**Documentation**
- `SYNAPSE.md`: Complete architecture and usage guide
- `QUICKSTART.md`: Installation and setup instructions
- `IMPLEMENTATION_STATUS.md`: Detailed implementation status
- `examples/distributed_cluster.py`: 3-node cluster example
- `scripts/compile_protos.py`: Proto compilation utility
- `migrations/001_add_synapse_fields.sql`: Database migration

**Testing**
- Integration test suite for Synapse features
- Tests for pessimistic locking
- Tests for DLQ and retry logic
- Tests for loop prevention

#### Changed

**Dependencies**
- Updated `politipo` from 0.4.2 to 0.5.1
- Updated `registro` from 0.3.1 to 0.5.1
- Added `pyarrow>=10.0.0` as core dependency

**UnifiedDataManager**
- Added optional `replication_driver` parameter to constructor
- Modified `save_versioned()` to accept `origin` parameter
- Enhanced `_process_outbox()` with resilience features
- Improved `close()` to handle non-async driver cleanup

**AsyncSQLAlchemyDriver**
- Fixed pool configuration for SQLite vs PostgreSQL
- Disabled echo logging in tests
- Improved connection pooling logic

**BaseResource**
- Updated to use Pydantic v2 `ConfigDict` instead of `class Config`
- Removed deprecation warnings

#### Fixed

- SQLAlchemy pool configuration errors with SQLite `:memory:` databases
- Pydantic v2 compatibility warnings
- DuckDB `close()` method async handling
- Datetime serialization in JSON payloads

### 📦 Optional Dependencies

New `synapse` extra for distributed replication:

```bash
pip install malha[synapse]
```

Includes:
- `grpcio>=1.60.0`
- `grpcio-tools>=1.60.0`
- `protobuf>=4.25.0`

### 🔄 Migration Guide

#### Database Migration

For existing databases, run:

```sql
-- SQLite
ALTER TABLE sys_outbox ADD COLUMN origin_node TEXT DEFAULT 'local';
ALTER TABLE sys_outbox ADD COLUMN retries INTEGER DEFAULT 0;
ALTER TABLE sys_outbox ADD COLUMN next_retry_at TIMESTAMP NULL;
CREATE INDEX idx_outbox_origin_node ON sys_outbox(origin_node);
```

Or use the provided migration file:

```bash
sqlite3 your_database.db < migrations/001_add_synapse_fields.sql
```

#### Code Changes

**Before (v0.2.x):**
```python
manager = await connect(
    url="sqlite+aiosqlite:///data.db",
    kuzu_path="data/kuzu"
)
```

**After (v0.3.0 - with replication):**
```python
from malha.drivers.synapse import SynapseDriver

synapse = SynapseDriver(
    kernel_ref=None,
    node_id="node-1",
    port=50051,
    peers=["192.168.1.10:50051"]
)

manager = await connect(
    url="sqlite+aiosqlite:///data.db",
    kuzu_path="data/kuzu",
    replication_driver=synapse  # ← New parameter
)
```

**Note:** Replication is **optional**. Existing code works without changes.

### ⚠️ Breaking Changes

None. This release is **backward compatible** with v0.2.x.

### 🐛 Known Issues

1. **SQLite Limitations**: `FOR UPDATE` may not work as expected with `:memory:` databases. Use PostgreSQL for production.
2. **Proto Compilation Required**: Synapse features require running `python scripts/compile_protos.py` before use.
3. **Test Coverage**: Integration tests at 50% coverage. Some edge cases need refinement.

### 📊 Statistics

- **Lines Added**: ~2,500
- **New Files**: 8
- **Modified Files**: 3
- **New Dependencies**: 3 (optional)
- **Test Coverage**: 50% (integration tests)

---

## [0.2.4] - 2024-11-XX

### Changed
- Improved repository pattern implementation
- Enhanced async session management
- Better error handling in outbox processor

### Fixed
- Session lifecycle issues
- Transaction commit errors

---

## [0.2.0] - 2024-XX-XX

### Added
- UnifiedDataManager with SQL, Graph, and Analytics drivers
- Outbox pattern for dual-write consistency
- KuzuActor for thread-safe graph operations
- DuckDBDriver for zero-copy analytics
- Repository pattern with optimistic locking
- Signal system for event handling

### Changed
- Migrated from v4 architecture to v5
- Async-first design throughout
- Improved type safety with Protocols

---

## [0.1.0] - 2024-XX-XX

### Added
- Initial release
- Basic data management capabilities
- SQLModel integration
- Pydantic support

---

## Upgrade Path

### From 0.2.x to 0.3.0

1. **Update dependencies:**
   ```bash
   pip install --upgrade malha
   ```

2. **Run database migration:**
   ```bash
   sqlite3 your_db.db < migrations/001_add_synapse_fields.sql
   ```

3. **(Optional) Install Synapse dependencies:**
   ```bash
   pip install malha[synapse]
   python scripts/compile_protos.py
   ```

4. **Update code** (only if using replication):
   ```python
   # Add replication_driver parameter
   manager = await connect(..., replication_driver=synapse)
   ```

### From 0.1.x to 0.3.0

Not recommended. Migrate to 0.2.x first, then to 0.3.0.

---

## Deprecations

None in this release.

---

## Security

No security vulnerabilities fixed in this release.

**Note**: Synapse P2P communication is currently **unencrypted**. For production use:
- Deploy on private networks
- Use VPN or firewall rules
- TLS/mTLS support planned for v0.4.0

---

## Contributors

- Kevin Saltarelli (@kevinsaltarelli) - Lead Developer

---

## Links

- [Documentation](README.md)
- [Synapse Guide](SYNAPSE.md)
- [Quick Start](QUICKSTART.md)
- [Implementation Status](IMPLEMENTATION_STATUS.md)
- [GitHub Repository](https://github.com/yourusername/malha)

---

[0.3.0]: https://github.com/yourusername/malha/compare/v0.2.4...v0.3.0
[0.2.4]: https://github.com/yourusername/malha/compare/v0.2.0...v0.2.4
[0.2.0]: https://github.com/yourusername/malha/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/yourusername/malha/releases/tag/v0.1.0
