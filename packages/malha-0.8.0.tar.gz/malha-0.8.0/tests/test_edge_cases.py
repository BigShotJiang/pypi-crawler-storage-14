"""
Test Suite: Edge Cases and Error Handling
==========================================

Tests for edge cases, error handling, and resilience.
"""

import asyncio
import os
import shutil
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from registro import DomainResource, register

from malha import (
    Interceptor,
    Signal,
    SysOutbox,
    ValidationError,
    connect,
    get_kernel,
)

# ============================================================================
# Domain Resources
# ============================================================================

class EdgeUser(DomainResource):
    name: str
    email: str = "test@example.com"
    age: int | None = None

register("EdgeUser", EdgeUser)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def temp_dir():
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)

@pytest.fixture
async def kernel(temp_dir):
    db_path = os.path.join(temp_dir, "test.db")
    graph_path = os.path.join(temp_dir, "test_graph")
    manager = await connect(
        url=f"sqlite+aiosqlite:///{db_path}",
        kuzu_path=graph_path,
        enable_monitoring=False,
    )
    yield manager
    await manager.close()


# ============================================================================
# Tests: Connection Edge Cases
# ============================================================================

class TestConnectionEdgeCases:
    @pytest.mark.asyncio
    async def test_connect_with_reset(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        # Create files
        os.makedirs(graph_path, exist_ok=True)
        with open(db_path, "w") as f:
            f.write("test")

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            reset=True,
        )

        assert manager is not None
        await manager.close()

    @pytest.mark.asyncio
    async def test_connect_with_custom_drivers(self, temp_dir):
        sql_mock = AsyncMock()
        sql_mock.create_tables = AsyncMock()
        sql_mock.get_session = AsyncMock()

        graph_mock = AsyncMock()
        analytics_mock = MagicMock()

        manager = await connect(
            sql_driver=sql_mock,
            graph_driver=graph_mock,
            analytics_driver=analytics_mock,
        )

        assert manager.sql == sql_mock
        assert manager.graph == graph_mock
        assert manager.analytics == analytics_mock

        await manager.close()

    @pytest.mark.asyncio
    async def test_get_kernel_without_connection(self):
        # Clear context
        from malha.malha import _ctx
        _ctx.set(None)

        with pytest.raises(RuntimeError, match="Kernel not connected"):
            get_kernel()

    @pytest.mark.asyncio
    async def test_get_kernel_with_connection(self, kernel):
        k = get_kernel()
        assert k == kernel


# ============================================================================
# Tests: Save Edge Cases
# ============================================================================

class TestSaveEdgeCases:
    @pytest.mark.asyncio
    async def test_save_versioned_with_interceptor_exception(self, kernel):
        class FailingInterceptor(Interceptor):
            async def on_write(self, obj, agent=None):
                raise ValidationError("Interceptor failed")
            async def on_read(self, obj, agent=None):
                return obj

        kernel.add_interceptor(FailingInterceptor())

        user = EdgeUser(name="Test")
        with pytest.raises(ValidationError):
            await kernel.save_versioned(user)

    @pytest.mark.asyncio
    async def test_save_versioned_multiple_times(self, kernel):
        user = EdgeUser(name="Alice", age=25)

        # Save first version
        v1 = await kernel.save_versioned(user)
        rid = v1.rid

        # Update and save again
        v1.age = 26
        v2 = await kernel.save_versioned(v1)

        v2.age = 27
        v3 = await kernel.save_versioned(v2)

        # Verify history
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=rid)

        assert len(history) == 3


# ============================================================================
# Tests: Delete Edge Cases
# ============================================================================

class TestDeleteEdgeCases:
    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, kernel):
        user = EdgeUser(name="Ghost")
        # Don't save, just try to delete
        await kernel.delete_versioned(user)
        # Should not raise

    @pytest.mark.asyncio
    async def test_delete_already_deleted(self, kernel):
        user = EdgeUser(name="ToDelete")
        saved = await kernel.save_versioned(user)

        await kernel.delete_versioned(saved)
        await kernel.delete_versioned(saved)  # Delete again
        # Should not raise


# ============================================================================
# Tests: Repository Edge Cases
# ============================================================================

class TestRepositoryEdgeCases:
    @pytest.mark.asyncio
    async def test_get_nonexistent_id(self, kernel):
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            result = await repo.get(session, id=999999)
        assert result is None

    @pytest.mark.asyncio
    async def test_get_nonexistent_rid(self, kernel):
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            result = await repo.get(session, rid="ri.nonexistent.rid")
        assert result is None

    @pytest.mark.asyncio
    async def test_update_nonexistent(self, kernel):
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            result = await repo.update(session, id=999999, data={"name": "New"})
        assert result is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, kernel):
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            result = await repo.delete(session, id=999999)
        assert result is False

    @pytest.mark.asyncio
    async def test_list_empty(self, kernel):
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            results = await repo.list(session)
        # May or may not be empty depending on other tests
        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_list_with_large_skip(self, kernel):
        repo = kernel.get_repository(EdgeUser)
        async with await kernel.sql_driver.get_session() as session:
            results = await repo.list(session, skip=1000000, limit=10)
        assert results == []


# ============================================================================
# Tests: Signal Edge Cases
# ============================================================================

class TestSignalEdgeCases:
    @pytest.mark.asyncio
    async def test_emit_with_no_handlers(self):
        signal = Signal("empty")
        await signal.emit({"data": "test"})
        # Should not raise

    @pytest.mark.asyncio
    async def test_emit_with_failing_async_handler(self):
        signal = Signal("failing")

        async def failing_handler(data):
            raise Exception("Handler failed")

        signal.connect(failing_handler)
        await signal.emit({"data": "test"}, background=False)
        # Should not raise, error is logged


# ============================================================================
# Tests: Outbox Edge Cases
# ============================================================================

class TestOutboxEdgeCases:
    @pytest.mark.asyncio
    async def test_outbox_with_invalid_payload(self, kernel):
        # Manually insert invalid outbox entry
        async with await kernel.sql_driver.get_session() as session:
            async with session.begin():
                invalid_event = SysOutbox(
                    rid="test:invalid",
                    operation="UPSERT",
                    payload='{"invalid": "data"}',
                    status="PENDING",
                    origin_node="local",
                )
                session.add(invalid_event)

        # Wait for processor
        await asyncio.sleep(2)

        # Check status changed
        async with await kernel.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.rid == "test:invalid")
            result = await session.execute(stmt)
            event = result.scalars().first()

        # Should be in RETRY or DEAD_LETTER
        if event:
            assert event.status in ["RETRY", "DEAD_LETTER", "PENDING", "DONE"]


# ============================================================================
# Tests: Concurrency Edge Cases
# ============================================================================

class TestConcurrencyEdgeCases:
    @pytest.mark.asyncio
    async def test_concurrent_saves_same_rid(self, kernel):
        user = EdgeUser(name="Concurrent", age=1)
        v1 = await kernel.save_versioned(user)
        rid = v1.rid

        # Concurrent updates - each creates a new object with same RID
        async def update(i):
            obj = EdgeUser(name="Concurrent", age=i)
            obj.rid = rid
            return await kernel.save_versioned(obj)

        results = await asyncio.gather(
            update(2), update(3), update(4),
            return_exceptions=True,
        )

        # Count successes and failures
        successes = [r for r in results if not isinstance(r, Exception)]
        failures = [r for r in results if isinstance(r, Exception)]

        # At least some should succeed (pessimistic locking serializes them)
        # With SQLite, concurrent writes may fail, so we just verify no crash
        assert len(successes) + len(failures) == 3

    @pytest.mark.asyncio
    async def test_concurrent_creates(self, kernel):
        async def create(i):
            user = EdgeUser(name=f"User{i}", age=i)
            return await kernel.save_versioned(user)

        results = await asyncio.gather(
            *[create(i) for i in range(10)],
        )

        assert len(results) == 10
        assert all(r.rid is not None for r in results)


# ============================================================================
# Tests: Manager Lifecycle
# ============================================================================

class TestManagerLifecycle:
    @pytest.mark.asyncio
    async def test_close_without_replication(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
        )

        await manager.close()
        # Should not raise

    @pytest.mark.asyncio
    async def test_double_close(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
        )

        await manager.close()
        await manager.close()  # Double close
        # Should not raise

    @pytest.mark.asyncio
    async def test_boot_multiple_times(self, kernel):
        await kernel.boot()
        await kernel.boot()
        # Should not raise


# ============================================================================
# Tests: Link/Unlink Edge Cases
# ============================================================================

class TestLinkEdgeCases:
    @pytest.mark.asyncio
    async def test_link_objects(self, kernel):
        user1 = EdgeUser(name="User1")
        user2 = EdgeUser(name="User2")

        saved1 = await kernel.save_versioned(user1)
        saved2 = await kernel.save_versioned(user2)

        with patch.object(kernel.graph, "create_edge", new_callable=AsyncMock):
            await kernel.link(saved1, saved2, "KNOWS", {"since": 2024})
            kernel.graph.create_edge.assert_called_once()

    @pytest.mark.asyncio
    async def test_unlink_nonexistent(self, kernel):
        user1 = EdgeUser(name="User1")
        user2 = EdgeUser(name="User2")

        with patch.object(kernel.graph, "delete_edge", new_callable=AsyncMock):
            await kernel.unlink(user1, user2, "NONEXISTENT")
            # Should not raise


# ============================================================================
# Tests: Ingest Batch Edge Cases
# ============================================================================

class TestIngestBatchEdgeCases:
    @pytest.mark.asyncio
    async def test_ingest_empty_batch(self, kernel):
        await kernel.ingest_batch("test_table", [])
        # Should not raise

    @pytest.mark.asyncio
    async def test_ingest_batch_with_data(self, kernel):
        from pydantic import BaseModel

        class TestData(BaseModel):
            id: int
            name: str

        data = [TestData(id=1, name="A"), TestData(id=2, name="B")]

        with patch("malha.malha.PolyTransporter") as mock_transporter:
            mock_arrow = MagicMock()
            mock_transporter.return_value.to_arrow.return_value = mock_arrow

            with patch.object(kernel.analytics, "ingest_arrow", new_callable=AsyncMock):
                await kernel.ingest_batch("test_table", data)
                kernel.analytics.ingest_arrow.assert_called_once()
