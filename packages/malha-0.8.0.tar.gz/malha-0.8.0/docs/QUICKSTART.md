# Malha - Quick Start Guide

## Installation

### Option 1: Local Development (Recommended)

```bash
# Clone the repository
git clone https://github.com/yourusername/malha.git
cd malha

# Install with UV (recommended)
uv sync

# Or with pip
pip install -e .

# Install with Synapse support
pip install -e ".[synapse]"
```

### Option 2: From PyPI (when published)

```bash
# Basic installation
pip install malha

# With distributed replication
pip install malha[synapse]
```

## Compile Protocol Buffers (Required for Synapse)

```bash
# Install gRPC tools
pip install grpcio-tools

# Compile proto files
python scripts/compile_protos.py
```

Expected output:
```
Found 1 proto file(s):
  - synapse.proto

Compiling synapse.proto...
✓ Successfully compiled synapse.proto

✓ All proto files compiled successfully!

Generated files:
  - malha/protos/synapse_pb2.py
  - malha/protos/synapse_pb2_grpc.py
```

## Basic Usage (Single Node)

Create a file `example.py`:

```python
import asyncio
from malha import connect
from registro import Resource

async def main():
    # Connect to local kernel
    manager = await connect(
        url="sqlite+aiosqlite:///mydata.db",
        kuzu_path="data/kuzu"
    )
    
    # Register your models
    await manager.register_model(Resource)
    
    # Create a resource
    resource = Resource(data={
        "name": "Alice",
        "email": "alice@example.com",
        "age": 30
    })
    
    # Save with automatic versioning (SCD Type 2)
    saved = await manager.save_versioned(resource)
    print(f"✓ Saved resource: {saved.rid}")
    
    # Update the resource (creates new version)
    resource.data["age"] = 31
    updated = await manager.save_versioned(resource)
    print(f"✓ Updated resource: {updated.rid} (version {updated.id})")
    
    # Query all versions
    async with manager.sql.get_session() as session:
        from sqlmodel import select
        stmt = select(Resource).where(Resource.rid == saved.rid)
        result = await session.execute(stmt)
        versions = result.scalars().all()
        print(f"✓ Total versions: {len(versions)}")
    
    # Close
    await manager.close()

if __name__ == "__main__":
    asyncio.run(main())
```

Run it:
```bash
python example.py
```

## Distributed Setup (3-Node Cluster)

### Step 1: Start Node 1

Terminal 1:
```bash
python examples/distributed_cluster.py \
  --node-id node-1 \
  --port 50051 \
  --peers 127.0.0.1:50052,127.0.0.1:50053
```

### Step 2: Start Node 2

Terminal 2:
```bash
python examples/distributed_cluster.py \
  --node-id node-2 \
  --port 50052 \
  --peers 127.0.0.1:50051,127.0.0.1:50053
```

### Step 3: Start Node 3

Terminal 3:
```bash
python examples/distributed_cluster.py \
  --node-id node-3 \
  --port 50053 \
  --peers 127.0.0.1:50051,127.0.0.1:50052
```

### Expected Output

Node 1 will create test resources, and you should see them replicated to nodes 2 and 3:

```
[node-1] Creating test resources...
  ✓ Created: ri.malha.local.Resource.abc123
  ✓ Created: ri.malha.local.Resource.def456
  ✓ Created: ri.malha.local.Resource.ghi789

[node-2] Outbox Status: Pending=0, Done=3, DLQ=0
[node-3] Outbox Status: Pending=0, Done=3, DLQ=0
```

## Programmatic Distributed Setup

```python
import asyncio
from malha import connect
from malha.drivers.synapse import SynapseDriver
from registro import Resource

async def main():
    # Create Synapse driver
    synapse = SynapseDriver(
        kernel_ref=None,  # Will be set by connect()
        node_id="my-node",
        port=50051,
        peers=["192.168.1.10:50051", "192.168.1.11:50051"]
    )
    
    # Connect with replication
    manager = await connect(
        url="sqlite+aiosqlite:///mydata.db",
        kuzu_path="data/kuzu",
        replication_driver=synapse
    )
    
    await manager.register_model(Resource)
    
    # All writes are now automatically replicated!
    resource = Resource(data={"message": "Hello, distributed world!"})
    await manager.save_versioned(resource)
    
    print("✓ Resource saved and replicated to all peers")
    
    # Keep running
    await asyncio.sleep(3600)
    await manager.close()

asyncio.run(main())
```

## Testing

Run the test suite:

```bash
# All tests
pytest

# Synapse integration tests only
pytest tests/test_synapse_integration.py -v

# With coverage
pytest --cov=malha --cov-report=html
```

## Monitoring

### Check Outbox Status

```python
from sqlmodel import select
from malha.malha import SysOutbox

async with manager.sql.get_session() as session:
    # Pending events
    pending = await session.execute(
        select(SysOutbox).where(SysOutbox.status == "PENDING")
    )
    print(f"Pending: {len(pending.scalars().all())}")
    
    # Completed events
    done = await session.execute(
        select(SysOutbox).where(SysOutbox.status == "DONE")
    )
    print(f"Done: {len(done.scalars().all())}")
    
    # Dead letter queue
    dlq = await session.execute(
        select(SysOutbox).where(SysOutbox.status == "DEAD_LETTER")
    )
    print(f"DLQ: {len(dlq.scalars().all())}")
```

### View All Versions of a Resource

```python
from sqlmodel import select

async with manager.sql.get_session() as session:
    stmt = select(Resource).where(Resource.rid == "ri.malha.local.Resource.abc123")
    result = await session.execute(stmt)
    versions = result.scalars().all()
    
    for v in versions:
        status = "ACTIVE" if v.valid_to is None else "CLOSED"
        print(f"Version {v.id}: {status} (valid_from={v.valid_from})")
```

## Troubleshooting

### Proto compilation fails

```bash
# Ensure grpcio-tools is installed
pip install grpcio-tools

# Try manual compilation
python -m grpc_tools.protoc \
  -I. \
  --python_out=. \
  --grpc_python_out=. \
  malha/protos/synapse.proto
```

### Connection refused (Synapse)

- Check firewall: `sudo ufw allow 50051/tcp`
- Verify peer addresses: `ping 192.168.1.10`
- Check if port is in use: `lsof -i :50051`

### Database locked (SQLite)

SQLite has limited concurrency. For production, use PostgreSQL:

```python
manager = await connect(
    url="postgresql+asyncpg://user:pass@localhost/malha",
    kuzu_path="data/kuzu"
)
```

### Outbox growing (DLQ)

Inspect failed events:

```sql
SELECT * FROM sys_outbox WHERE status = 'DEAD_LETTER';
```

Common causes:
- Network partition
- Schema mismatch between nodes
- Corrupted payload

## Next Steps

- Read [SYNAPSE.md](SYNAPSE.md) for detailed architecture
- Explore [examples/](examples/) for more use cases
- Check [tests/](tests/) for API examples
- Join our community (Discord/Slack link)

## Performance Tips

1. **Use PostgreSQL for production** (better concurrency than SQLite)
2. **Tune outbox batch size** (default: 100 events)
3. **Monitor DLQ** (set up alerts for `status = 'DEAD_LETTER'`)
4. **Use connection pooling** (already configured in AsyncSQLAlchemyDriver)
5. **Enable compression** (TODO: add to Synapse protocol)

## Security Considerations

⚠️ **Current limitations**:
- No TLS/mTLS support (plaintext gRPC)
- No authentication between nodes
- No authorization/ACLs

For production:
- Use VPN or private network
- Implement mTLS (see Synapse roadmap)
- Add node authentication

## License

MIT License - See LICENSE file for details.
