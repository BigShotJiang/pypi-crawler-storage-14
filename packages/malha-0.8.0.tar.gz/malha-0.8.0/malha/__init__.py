"""Malha - Sistema Operacional Semântico.

Distributed Data Kernel with P2P Replication and Zero-ETL Federation.

Quick Start:
    ```python
    from malha import connect
    from registro import DomainResource, register

    class User(DomainResource):
        name: str
        email: str

    register("User", User)

    async def main():
        async with connect() as kernel:
            user = User(name="Alice", email="alice@example.com")
            saved = await kernel.save(user)
            print(f"Saved: {saved.rid}")
    ```
"""

# Dynamic version from pyproject.toml
try:
    from importlib.metadata import version
    __version__ = version("malha")
except Exception:
    __version__ = "0.6.0"

# Core API
from .instrumentation import KernelInstrumentation

# Drivers (advanced usage)
from .malha import (
    AnalyticsDriver,
    AsyncSQLAlchemyDriver,
    BaseRepository,
    DuckDBDriver,
    GraphDriver,
    Handler,
    Interceptor,
    KuzuActor,
    KuzuTask,
    OptimisticLockError,
    ReplicationDriver,
    Signal,
    SQLDriver,
    SysOutbox,
    SystemOverloadedError,
    UnifiedDataManager,
    ValidationError,
    connect,
    create_manager,
    get_kernel,
    post_delete,
    post_ingest,
    post_save,
)

# Observability
from .monitor import KernelMonitor, MetricTimer

# Services (Helix pattern)
from .services import TopologySyncService, generate_virtual_rid

# Backwards compatibility alias
KuzuDriver = KuzuActor

__all__ = [
    # Core API (most users need only these)
    "connect",
    "get_kernel",
    "UnifiedDataManager",
    "BaseRepository",

    # Signals
    "Signal",
    "post_save",
    "post_delete",
    "post_ingest",

    # Errors
    "OptimisticLockError",
    "ValidationError",
    "SystemOverloadedError",

    # Implicit Causal Scheduling
    "KuzuTask",

    # Observability
    "KernelMonitor",
    "KernelInstrumentation",
    "MetricTimer",

    # Services (Helix pattern)
    "TopologySyncService",
    "generate_virtual_rid",

    # Advanced: Drivers & Protocols
    "SQLDriver",
    "GraphDriver",
    "AnalyticsDriver",
    "ReplicationDriver",
    "AsyncSQLAlchemyDriver",
    "KuzuActor",
    "KuzuDriver",
    "DuckDBDriver",

    # Advanced: Extensibility
    "Interceptor",
    "Handler",
    "SysOutbox",

    # Metadata
    "__version__",
]
