class TextToolsError(Exception):
    """Базовое исключение библиотеки."""
    pass

class InvalidTextError(TextToolsError):
    """Исключение, выбрасываемое при передаче не строкового значения."""
    pass
