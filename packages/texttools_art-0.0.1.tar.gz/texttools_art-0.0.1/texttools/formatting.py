from .cleaning import remove_whitespace

def to_snake_case(text: str) -> str:
    """
    Переводит строку в snake_case.
    
    :param text: Исходная строка.
    :return: Строка в формате snake_case.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    text = remove_whitespace(text)
    return '_'.join(word.lower() for word in text.split())

def to_kebab_case(text: str) -> str:
    """
    Переводит строку в kebab-case.
    
    :param text: Исходная строка.
    :return: Строка в формате kebab-case.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    text = remove_whitespace(text)
    return '-'.join(word.lower() for word in text.split())

def capitalize_sentences(text: str) -> str:
    """
    Делает первую букву каждого предложения заглавной.
    
    :param text: Исходная строка.
    :return: Строка с заглавными буквами в начале предложений.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    sentences = text.split('. ')
    return '. '.join(sentence.capitalize() for sentence in sentences)
