from .exceptions import InvalidTextError

def remove_whitespace(text: str) -> str:
    """
    Убирает лишние пробелы: и в начале, и в конце, и повторяющиеся внутри.
    
    :param text: Исходная строка.
    :return: Очищенная строка.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    return ' '.join(text.strip().split())

def remove_punctuation(text: str, keep: str = "") -> str:
    """
    Убирает знаки пунктуации, кроме тех, что указаны в keep.
    
    :param text: Исходная строка.
    :param keep: Символы, которые нужно оставить.
    :return: Очищенная строка.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    import string
    translator = str.maketrans('', '', string.punctuation.replace(keep, ''))
    return text.translate(translator)

def normalize_spaces(text: str) -> str:
    """
    Превращает все виды пробелов/табов/переносов в обычный пробел.
    
    :param text: Исходная строка.
    :return: Очищенная строка.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    return ' '.join(text.split())
