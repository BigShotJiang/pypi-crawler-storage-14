from .cleaning import remove_whitespace

def word_count(text: str) -> int:
    """
    Возвращает количество слов в тексте.

    :param text: Исходная строка.
    :return: Количество слов.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    return len(remove_whitespace(text).split())
def char_count(text: str, ignore_spaces: bool = False) -> int:
    """
    Возвращает количество символов в тексте.

    :param text: Исходная строка.
    :param ignore_spaces: Если True, пробелы не учитываются.
    :return: Количество символов.
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")
    
    return len(text.replace(" ", "") if ignore_spaces else text)

def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """
    Возвращает список самых частых слов.

    :param text: Исходная строка.
    :param n: Количество возвращаемых слов.
    :return: Список кортежей (слово, количество).
    :raises InvalidTextError: Если text не строка.
    """
    if not isinstance(text, str):
        raise InvalidTextError("Input must be a string.")

    from collections import Counter
    
    words = remove_whitespace(text.lower()).split()
    most_common = Counter(words).most_common(n)
    
    return most_common
