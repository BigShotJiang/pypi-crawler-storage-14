"""Full Application Hooks.

Application and command hooks for the full application example.
"""

