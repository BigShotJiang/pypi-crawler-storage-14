"""
Placeholder diff viewer utilities.

The rich TypeScript diff viewer is not yet ported; these helpers provide
minimal formatting so imports resolve and future work has a home.
"""

from __future__ import annotations

from typing import Iterable


def render_diff(title: str, lines: Iterable[str]) -> str:
    """Return a simple unified diff block as text."""
    content = "\n".join(lines)
    return f"--- {title} ---\n{content}"
