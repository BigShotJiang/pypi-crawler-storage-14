"""
Unified Provider System

All LLM providers are managed through the unified schema.
This module provides the unified interface for all providers.

Supported Providers:
- OpenAI (GPT)
- Google (Gemini)
- DeepSeek (via OpenAI-compatible)
- xAI Grok (via OpenAI-compatible)
- Ollama (via OpenAI-compatible)
- Groq (via OpenAI-compatible)
- Together AI (via OpenAI-compatible)
- Fireworks AI (via OpenAI-compatible)
- Mistral AI (via OpenAI-compatible)
- Anthropic (Claude) - optional

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations
from typing import TYPE_CHECKING

# Core provider factory using unified schema
from .provider_factory import (
    create_provider,
    get_default_model,
    get_supported_providers,
    get_configured_providers,
    get_provider_info,
    get_models_for_provider,
    provider_supports_capability,
    auto_select_provider,
    get_first_available_provider,
    LLMProvider,
    ProviderOptions,
)

# OpenAI-compatible provider (handles DeepSeek, xAI, Ollama, Groq, etc.)
from .openai_compatible import (
    OpenAICompatibleProvider,
    OpenAICompatibleOptions,
)

# OpenAI provider (core - always available)
from .openai_provider import OpenAIProvider, OpenAIProviderOptions

# Google provider
from .google_provider import GoogleProvider, GoogleProviderOptions

# Lazy imports for optional providers (anthropic may not be installed)
if TYPE_CHECKING:
    from .anthropic_provider import AnthropicProvider, AnthropicProviderOptions


def __getattr__(name: str):
    """Lazy import for optional providers."""
    if name in ("AnthropicProvider", "AnthropicProviderOptions"):
        try:
            from .anthropic_provider import AnthropicProvider, AnthropicProviderOptions
            if name == "AnthropicProvider":
                return AnthropicProvider
            return AnthropicProviderOptions
        except ImportError:
            raise ImportError(
                f"{name} requires the 'anthropic' package. "
                "Install it with: pip install anthropic"
            )
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Unified factory
    "create_provider",
    "get_default_model",
    "get_supported_providers",
    "get_configured_providers",
    "get_provider_info",
    "get_models_for_provider",
    "provider_supports_capability",
    "auto_select_provider",
    "get_first_available_provider",
    "LLMProvider",
    "ProviderOptions",

    # Unified OpenAI-compatible provider
    "OpenAICompatibleProvider",
    "OpenAICompatibleOptions",

    # Native providers
    "OpenAIProvider",
    "OpenAIProviderOptions",
    "GoogleProvider",
    "GoogleProviderOptions",
    # Anthropic (optional - lazy loaded)
    "AnthropicProvider",
    "AnthropicProviderOptions",
]
