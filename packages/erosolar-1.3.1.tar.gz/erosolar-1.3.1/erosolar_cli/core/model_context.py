"""
Model Context Window Management

Maps models to their context window sizes and provides utilities
for dynamic context limit configuration.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Tuple

# Model context window definitions (in tokens)
# Format: (regex pattern, context_window, safe_target)
# safe_target is typically 70-75% of context_window to leave room for response
MODEL_CONTEXT_WINDOWS: list[Tuple[str, int, int]] = [
    # OpenAI GPT-5.x series (200K context)
    (r"^gpt-5\.1-?codex", 200_000, 140_000),
    (r"^gpt-5(?:\.1|-?pro|-?mini|-?nano|-?max)", 200_000, 140_000),
    (r"^gpt-5$", 200_000, 140_000),

    # OpenAI GPT-4o series (128K context)
    (r"^gpt-4o", 128_000, 90_000),
    (r"^gpt-4-turbo", 128_000, 90_000),
    (r"^gpt-4-(?:0125|1106)", 128_000, 90_000),

    # OpenAI GPT-4 (8K-32K context)
    (r"^gpt-4-32k", 32_000, 24_000),
    (r"^gpt-4(?!o|-)(?!-turbo)", 8_192, 6_000),

    # OpenAI o1/o3 reasoning models (200K context)
    (r"^o1(?:-pro|-mini)?", 200_000, 140_000),
    (r"^o3(?:-pro|-mini)?", 200_000, 140_000),

    # OpenAI GPT-3.5 (16K context)
    (r"^gpt-3\.5-turbo-16k", 16_000, 12_000),
    (r"^gpt-3\.5", 4_096, 3_000),

    # Anthropic Claude 4.x series (200K context)
    (r"^claude-(?:sonnet|opus|haiku)-4", 200_000, 140_000),
    (r"^(?:sonnet|opus|haiku)-4", 200_000, 140_000),

    # Anthropic Claude 3.x series (200K context)
    (r"^claude-3", 200_000, 140_000),

    # Anthropic Claude 2.x (100K context)
    (r"^claude-2", 100_000, 70_000),

    # Google Gemini Pro (1M+ context, but we cap at 200K for safety)
    (r"^gemini-(?:1\.5|2\.0)-pro", 1_000_000, 200_000),
    (r"^gemini-(?:1\.5|2\.0)-flash", 1_000_000, 200_000),
    (r"^gemini-pro", 32_000, 24_000),

    # DeepSeek (64K-128K context)
    (r"^deepseek-(?:chat|coder|reasoner)", 128_000, 90_000),
    (r"^deepseek", 64_000, 45_000),

    # xAI Grok (128K context)
    (r"^grok", 128_000, 90_000),

    # Ollama/Local models (typically smaller context)
    (r"^llama-?3\.?[12]?:?(?:70b|405b)", 128_000, 90_000),
    (r"^llama-?3", 8_192, 6_000),
    (r"^llama-?2", 4_096, 3_000),
    (r"^mistral", 32_000, 24_000),
    (r"^mixtral", 32_000, 24_000),
    (r"^codellama", 16_000, 12_000),
    (r"^qwen", 32_000, 24_000),
    (r"^phi", 4_096, 3_000),
]

# Compiled regex patterns for performance
_COMPILED_PATTERNS: list[Tuple[re.Pattern, int, int]] = [
    (re.compile(pattern, re.IGNORECASE), context, target)
    for pattern, context, target in MODEL_CONTEXT_WINDOWS
]

# Default fallback values
DEFAULT_CONTEXT_WINDOW = 128_000
DEFAULT_TARGET_TOKENS = 90_000


@dataclass
class ModelContextInfo:
    """Context window information for a model."""
    model: str
    context_window: int
    target_tokens: int
    is_default: bool = False


def get_model_context_info(model: str | None) -> ModelContextInfo:
    """
    Get context window information for a model.

    Args:
        model: Model identifier (e.g., "gpt-4o", "claude-3-opus")

    Returns:
        ModelContextInfo with context window and target tokens
    """
    if not model:
        return ModelContextInfo(
            model="unknown",
            context_window=DEFAULT_CONTEXT_WINDOW,
            target_tokens=DEFAULT_TARGET_TOKENS,
            is_default=True,
        )

    normalized = model.strip().lower()

    for pattern, context_window, target_tokens in _COMPILED_PATTERNS:
        if pattern.search(normalized):
            return ModelContextInfo(
                model=model,
                context_window=context_window,
                target_tokens=target_tokens,
                is_default=False,
            )

    # Return default values for unknown models
    return ModelContextInfo(
        model=model,
        context_window=DEFAULT_CONTEXT_WINDOW,
        target_tokens=DEFAULT_TARGET_TOKENS,
        is_default=True,
    )


def get_context_window_tokens(model: str | None) -> int | None:
    """
    Get context window size in tokens for a model.

    Args:
        model: Model identifier

    Returns:
        Context window size in tokens, or None if unknown
    """
    if not model:
        return None

    info = get_model_context_info(model)
    return info.context_window if not info.is_default else None


def get_safe_target_tokens(model: str | None, safety_margin: float = 0.70) -> int:
    """
    Get safe target token count for a model.

    This is the threshold at which context pruning should begin,
    leaving room for the model's response.

    Args:
        model: Model identifier
        safety_margin: Fraction of context window to use (default 0.70 = 70%)

    Returns:
        Safe target token count
    """
    info = get_model_context_info(model)

    # Use pre-calculated target if available, otherwise calculate
    if not info.is_default:
        return info.target_tokens

    return int(info.context_window * safety_margin)


def calculate_context_thresholds(model: str | None) -> dict[str, int]:
    """
    Calculate all context management thresholds for a model.

    Returns thresholds for:
    - max_tokens: Absolute maximum context size
    - target_tokens: Start pruning threshold (70% of max)
    - warning_tokens: Show warning threshold (60% of max)
    - critical_tokens: Critical warning threshold (85% of max)

    Args:
        model: Model identifier

    Returns:
        Dictionary of threshold values
    """
    info = get_model_context_info(model)
    context_window = info.context_window

    return {
        "max_tokens": context_window,
        "target_tokens": int(context_window * 0.70),  # Start pruning at 70%
        "warning_tokens": int(context_window * 0.60),  # Warn at 60%
        "critical_tokens": int(context_window * 0.85),  # Critical at 85%
    }
