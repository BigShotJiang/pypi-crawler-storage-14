"""
Attack Simulation Framework

Provides controlled attack simulations for red team exercises.
All simulations require explicit authorization.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import base64
import hashlib
import random
import string
import time
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from .core import AuthorizationRecord, AuthorizationScope


class AttackCategory(Enum):
    """Categories of attack simulations."""

    RECONNAISSANCE = "reconnaissance"
    WEB_APPLICATION = "web_application"
    AUTHENTICATION = "authentication"
    INJECTION = "injection"
    MISCONFIGURATION = "misconfiguration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DATA_EXFILTRATION = "data_exfiltration"


class AttackPhase(Enum):
    """MITRE ATT&CK inspired attack phases."""

    INITIAL_ACCESS = "initial_access"
    EXECUTION = "execution"
    PERSISTENCE = "persistence"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DEFENSE_EVASION = "defense_evasion"
    CREDENTIAL_ACCESS = "credential_access"
    DISCOVERY = "discovery"
    LATERAL_MOVEMENT = "lateral_movement"
    COLLECTION = "collection"
    EXFILTRATION = "exfiltration"
    IMPACT = "impact"


@dataclass
class AttackVector:
    """Definition of an attack vector."""

    name: str
    category: AttackCategory
    phase: AttackPhase
    description: str
    technique_id: str  # MITRE ATT&CK technique ID
    prerequisites: list[str] = field(default_factory=list)
    indicators_of_compromise: list[str] = field(default_factory=list)
    detection_methods: list[str] = field(default_factory=list)
    mitigations: list[str] = field(default_factory=list)


@dataclass
class AttackSimulationResult:
    """Result of an attack simulation."""

    vector: AttackVector
    target: str
    timestamp: float
    success: bool
    evidence: list[str] = field(default_factory=list)
    artifacts: dict[str, Any] = field(default_factory=dict)
    detection_triggered: bool = False
    duration_ms: float = 0.0
    notes: str = ""


# Common attack vectors based on OWASP Top 10 and MITRE ATT&CK
ATTACK_VECTORS = {
    "sql_injection": AttackVector(
        name="SQL Injection",
        category=AttackCategory.INJECTION,
        phase=AttackPhase.INITIAL_ACCESS,
        description="Inject malicious SQL queries",
        technique_id="T1190",
        prerequisites=["web_application_identified", "input_field_found"],
        detection_methods=["WAF rules", "Database monitoring"],
        mitigations=["Parameterized queries", "Input validation"],
    ),
    "xss_reflected": AttackVector(
        name="Reflected XSS",
        category=AttackCategory.WEB_APPLICATION,
        phase=AttackPhase.INITIAL_ACCESS,
        description="Inject scripts reflected to users",
        technique_id="T1189",
        detection_methods=["CSP reports", "WAF XSS rules"],
        mitigations=["CSP", "Output encoding", "Input validation"],
    ),
    "ssrf": AttackVector(
        name="Server-Side Request Forgery",
        category=AttackCategory.WEB_APPLICATION,
        phase=AttackPhase.DISCOVERY,
        description="Abuse server to make internal requests",
        technique_id="T1090",
        detection_methods=["Outbound request monitoring"],
        mitigations=["URL allowlisting", "Network segmentation"],
    ),
    "auth_bypass": AttackVector(
        name="Authentication Bypass",
        category=AttackCategory.AUTHENTICATION,
        phase=AttackPhase.INITIAL_ACCESS,
        description="Bypass authentication mechanisms",
        technique_id="T1078",
        detection_methods=["Failed login monitoring", "Session anomalies"],
        mitigations=["MFA", "Strong session management"],
    ),
    "path_traversal": AttackVector(
        name="Path Traversal",
        category=AttackCategory.WEB_APPLICATION,
        phase=AttackPhase.COLLECTION,
        description="Access files outside webroot",
        technique_id="T1083",
        detection_methods=["Path pattern monitoring", "WAF rules"],
        mitigations=["Input validation", "Chroot/sandbox"],
    ),
}


class PayloadGenerator:
    """Generates test payloads for security testing."""

    @staticmethod
    def sql_injection_payloads() -> list[str]:
        """Generate SQL injection test payloads."""
        return [
            "' OR '1'='1",
            "'; DROP TABLE users--",
            "1' AND '1'='1",
            "1 UNION SELECT NULL--",
            "admin'--",
        ]

    @staticmethod
    def xss_payloads() -> list[str]:
        """Generate XSS test payloads."""
        return [
            "<script>alert(1)</script>",
            "<img src=x onerror=alert(1)>",
            "javascript:alert(1)",
            "<svg onload=alert(1)>",
        ]

    @staticmethod
    def path_traversal_payloads() -> list[str]:
        """Generate path traversal test payloads."""
        return [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32\\config\\sam",
            "....//....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
        ]

    @staticmethod
    def encode_payload(payload: str, encoding: str) -> str:
        """Encode payload with specified encoding."""
        if encoding == "base64":
            return base64.b64encode(payload.encode()).decode()
        elif encoding == "url":
            return urllib.parse.quote(payload)
        elif encoding == "hex":
            return payload.encode().hex()
        return payload


class AttackSimulator:
    """
    Controlled attack simulation engine.

    All simulations require valid authorization and are designed
    for authorized security testing only.
    """

    def __init__(
        self,
        authorization: AuthorizationRecord,
        data_dir: Optional[Path] = None,
        verbose: bool = False,
    ):
        self.authorization = authorization
        self.data_dir = data_dir or Path(".attack_simulations")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.verbose = verbose
        self.results: list[AttackSimulationResult] = []

    def _check_authorization(self, target: str) -> None:
        """Verify authorization before simulation."""
        if not self.authorization:
            raise PermissionError("No authorization record.")
        if not self.authorization.is_valid():
            raise PermissionError("Authorization expired.")
        if not self.authorization.is_target_in_scope(target):
            raise PermissionError(f"Target {target} not in scope.")

        # Attack simulations require stronger authorization
        allowed = [
            AuthorizationScope.OWNED_SYSTEMS,
            AuthorizationScope.PENTEST_ENGAGEMENT,
            AuthorizationScope.RED_TEAM,
            AuthorizationScope.CTF_COMPETITION,
        ]
        if self.authorization.scope not in allowed:
            raise PermissionError("Simulations require pentest/red team authorization.")

    async def simulate_attack(
        self,
        target: str,
        vector_id: str,
        dry_run: bool = True,
    ) -> AttackSimulationResult:
        """
        Simulate an attack vector against a target.

        Args:
            target: Target to simulate against
            vector_id: ID of attack vector to simulate
            dry_run: If True, only generate payloads without sending

        Returns:
            Simulation result
        """
        self._check_authorization(target)

        if vector_id not in ATTACK_VECTORS:
            raise ValueError(f"Unknown attack vector: {vector_id}")

        vector = ATTACK_VECTORS[vector_id]
        start_time = time.time()

        if self.verbose:
            print(f"[Simulation] {vector.name} against {target}")
            print(f"  Technique: {vector.technique_id}")
            print(f"  Dry run: {dry_run}")

        result = AttackSimulationResult(
            vector=vector,
            target=target,
            timestamp=start_time,
            success=False,
            notes=f"Dry run: {dry_run}",
        )

        # Generate payloads based on vector type
        payloads = self._get_payloads_for_vector(vector_id)
        result.artifacts["payloads"] = payloads
        result.artifacts["payload_count"] = len(payloads)

        if not dry_run:
            # Actual simulation would go here
            # For safety, we only generate payloads
            result.notes = "Live simulation not implemented for safety"

        result.duration_ms = (time.time() - start_time) * 1000
        self.results.append(result)
        return result

    def _get_payloads_for_vector(self, vector_id: str) -> list[str]:
        """Get test payloads for a vector."""
        if "sql" in vector_id:
            return PayloadGenerator.sql_injection_payloads()
        elif "xss" in vector_id:
            return PayloadGenerator.xss_payloads()
        elif "path" in vector_id or "traversal" in vector_id:
            return PayloadGenerator.path_traversal_payloads()
        return []

    def get_vectors_by_category(self, category: AttackCategory) -> list[AttackVector]:
        """Get all vectors in a category."""
        return [v for v in ATTACK_VECTORS.values() if v.category == category]

    def get_vectors_by_phase(self, phase: AttackPhase) -> list[AttackVector]:
        """Get all vectors in an attack phase."""
        return [v for v in ATTACK_VECTORS.values() if v.phase == phase]

    def generate_report(self) -> str:
        """Generate simulation report."""
        lines = [
            "=" * 60,
            "ATTACK SIMULATION REPORT",
            "=" * 60,
            f"Generated: {datetime.now().isoformat()}",
            f"Target: {self.authorization.target_domain}",
            f"Scope: {self.authorization.scope.value}",
            f"Simulations: {len(self.results)}",
            "",
        ]

        for i, result in enumerate(self.results, 1):
            lines.extend([
                f"[{i}] {result.vector.name}",
                f"    Target: {result.target}",
                f"    Success: {result.success}",
                f"    Duration: {result.duration_ms:.1f}ms",
                f"    Payloads: {result.artifacts.get('payload_count', 0)}",
            ])

        return "\n".join(lines)


__all__ = [
    "AttackCategory",
    "AttackPhase",
    "AttackVector",
    "AttackSimulationResult",
    "AttackSimulator",
    "PayloadGenerator",
    "ATTACK_VECTORS",
]
