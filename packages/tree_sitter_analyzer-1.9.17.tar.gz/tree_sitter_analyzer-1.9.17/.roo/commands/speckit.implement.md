# implement

実装とコード生成 - 詳細は [.roo/docs/speckit.implement.md](.roo/docs/speckit.implement.md) を参照