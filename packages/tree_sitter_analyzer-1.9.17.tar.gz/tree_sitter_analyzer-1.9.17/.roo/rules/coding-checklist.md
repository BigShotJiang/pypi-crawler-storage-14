# Roo Code 実装チェックリスト

このファイルは、Roo Codeがソースコードを作成・修正する際の実践的なチェックリストです。

## 🚀 コード作成前チェック

### プロジェクト理解
- [ ] プロジェクトの目的と要件を理解している
- [ ] 既存のアーキテクチャパターンを把握している
- [ ] 関連する既存コードを確認している
- [ ] 影響範囲を特定している

### 設計確認
- [ ] 適切なモジュール・クラス構造を計画している
- [ ] 依存関係を最小限に抑えている
- [ ] 単一責任原則を遵守している
- [ ] 拡張性を考慮している

## 📝 コード実装チェック

### 基本品質
- [ ] **型ヒント**: 全ての関数・メソッドに型ヒントを追加
- [ ] **docstring**: パブリックAPIにGoogle形式のdocstringを記述
- [ ] **命名規則**: snake_case（関数・変数）、PascalCase（クラス）を使用
- [ ] **行長制限**: 88文字以内に収める

### エラーハンドリング
- [ ] 適切な例外クラスを使用している
- [ ] try-except文で具体的な例外をキャッチしている
- [ ] エラーメッセージが分かりやすい
- [ ] ログ出力が適切に設定されている

### 非同期処理（該当する場合）
- [ ] `async/await`を正しく使用している
- [ ] リソースの適切なクリーンアップを実装している
- [ ] デッドロックやレースコンディションを回避している
- [ ] セマフォやロックを適切に使用している

### セキュリティ
- [ ] ファイルパスの検証を実装している
- [ ] 入力値のサニタイゼーションを行っている
- [ ] 機密情報をログに出力していない
- [ ] SQLインジェクション等の脆弱性を回避している

## 🧪 テスト実装チェック

### テストカバレッジ
- [ ] 正常ケースのテストを作成している
- [ ] 異常ケース・エッジケースのテストを作成している
- [ ] モックを適切に使用している
- [ ] テストが独立して実行可能である

### テスト品質
- [ ] テスト名が分かりやすい
- [ ] Arrange-Act-Assertパターンを使用している
- [ ] テストデータが適切に管理されている
- [ ] 非同期テストで`@pytest.mark.asyncio`を使用している

## 🔧 コード品質チェック

### フォーマット・リンティング
- [ ] Blackフォーマッターを適用している
- [ ] Ruffリンターでエラーがない
- [ ] isortでインポートが整理されている
- [ ] MyPyで型チェックが通る

### セキュリティ・品質
- [ ] Banditでセキュリティチェックが通る
- [ ] pydocstyleでドキュメント品質が確保されている
- [ ] pyupgradeで最新のPython構文を使用している
- [ ] デバッグ文（print, pdb等）を削除している

## 📚 プロジェクト固有チェック

### Tree-sitter関連
- [ ] パーサーエラーの適切な処理を実装している
- [ ] 言語サポートの一貫性を維持している
- [ ] クエリの最適化を考慮している
- [ ] メモリ効率を考慮している

### MCP (Model Context Protocol)
- [ ] 非同期処理を正しく実装している
- [ ] エラーレスポンスを標準化している
- [ ] リソース管理を徹底している
- [ ] セキュリティ要件を満たしている

## 🚀 コード完成後チェック

### 最終確認
- [ ] 全てのテストが通る
- [ ] pre-commitフックが通る
- [ ] ドキュメントが更新されている
- [ ] 変更ログが記録されている

### パフォーマンス
- [ ] 大きなファイルでの動作を確認している
- [ ] メモリ使用量が適切である
- [ ] 処理時間が許容範囲内である
- [ ] キャッシュが適切に機能している

## 🔄 継続的改善

### コードレビュー観点
- [ ] 可読性が高い
- [ ] 保守性が高い
- [ ] 再利用性がある
- [ ] 拡張性がある

### 品質指標
- [ ] テストカバレッジ80%以上
- [ ] 複雑度が適切な範囲内
- [ ] 依存関係が最小限
- [ ] パフォーマンスが要件を満たす

## 📋 クイックリファレンス

### よく使用する型ヒント
```python
from typing import Dict, List, Optional, Union, Any, Callable, AsyncIterator
from pathlib import Path
import asyncio

# 基本的な関数
async def process_file(
    file_path: Path,
    options: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    pass

# ジェネレーター
async def stream_results() -> AsyncIterator[Dict[str, Any]]:
    pass

# コールバック
def callback_func(
    result: Dict[str, Any],
    callback: Optional[Callable[[str], None]] = None
) -> None:
    pass
```

### エラーハンドリングパターン
```python
try:
    result = await risky_operation()
except SpecificError as e:
    logger.error(f"Specific error occurred: {e}")
    raise CustomError(f"Operation failed: {e}") from e
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    raise
finally:
    await cleanup_resources()
```

### 非同期リソース管理
```python
async with managed_resource() as resource:
    result = await resource.process()
    return result
```

### テストパターン
```python
@pytest.mark.asyncio
async def test_function_success():
    # Arrange
    input_data = create_test_data()
    
    # Act
    result = await function_under_test(input_data)
    
    # Assert
    assert result is not None
    assert result["status"] == "success"
```

## 🎯 品質目標

- **コードカバレッジ**: 80%以上
- **型チェック**: MyPyエラーゼロ
- **リンティング**: Ruff/Flake8エラーゼロ
- **セキュリティ**: Bandit警告ゼロ
- **ドキュメント**: パブリックAPI 100%カバー
- **パフォーマンス**: 大きなファイル（1MB+）でも適切な応答時間