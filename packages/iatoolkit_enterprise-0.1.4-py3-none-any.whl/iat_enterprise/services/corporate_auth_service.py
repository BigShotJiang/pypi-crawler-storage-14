# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit Enterprise
#
# IAToolkit Enterprise is commercial, proprietary software.
# Unauthorized copying, modification, distribution, or use of this software,
# via any medium, is strictly prohibited unless explicitly permitted by the
# Enterprise License Agreement provided to the customer.
#
# This file is part of the IAToolkit Enterprise Edition and may not be
# redistributed as open-source. For licensing information, refer to:
# ENTERPRISE_LICENSE

from injector import inject
from iatoolkit.services.profile_service import ProfileService
from iatoolkit.services.dispatcher_service import Dispatcher
from iatoolkit.repositories.models import Company
from iatoolkit.common.session_manager import SessionManager

class CorporateAuthService:
    """
    Gestiona la lógica de perfiles y acceso para entornos corporativos (SSO, Portales, etc).
    """

    @inject
    def __init__(self,
                 dispatcher: Dispatcher,
                 profile_service: ProfileService):
        self.dispatcher = dispatcher
        self.profile_service = profile_service

    def login(self, company: Company, user_identifier: str):

        # 1. Fetch the external user profile via Dispatcher.
        # This brings the identification information from the SSO provider
        # or the company portal: email, name, company permissions, etc.
        external_user_profile = self.dispatcher.get_user_info(
            company_name=company.short_name,
            user_identifier=user_identifier
        )

        # 2. Create the session for this user
        self.profile_service.save_user_profile(
            company=company,
            user_identifier=user_identifier,
            user_profile=external_user_profile
        )

        # 3. Make sure the flask session is clean
        SessionManager.clear()