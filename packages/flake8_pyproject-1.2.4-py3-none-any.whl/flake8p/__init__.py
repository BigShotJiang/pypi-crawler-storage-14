# The imports here define the public interface of the package.

from .meta import version as __version__
from .meta import synopsis as __doc__
from .hook import main
from .hook import Plugin
