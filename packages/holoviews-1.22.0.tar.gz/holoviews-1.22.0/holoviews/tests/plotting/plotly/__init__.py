import pytest

pytest.importorskip("plotly")
