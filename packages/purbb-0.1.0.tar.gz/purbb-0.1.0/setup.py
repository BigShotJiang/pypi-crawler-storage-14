"""
Setup configuration for PURBB package.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="purbb",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Python Utility for Rapid Data Science - Print common ML/DS library imports",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/purbb",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.7",
    keywords="machine learning, data science, imports, utilities, scikit-learn",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/purbb/issues",
        "Source": "https://github.com/yourusername/purbb",
        "Documentation": "https://github.com/yourusername/purbb#readme",
    },
)

