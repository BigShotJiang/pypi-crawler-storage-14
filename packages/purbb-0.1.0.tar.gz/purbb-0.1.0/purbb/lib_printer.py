"""
Library printer module that prints all common ML/DS imports with descriptions.
"""


def print_all_lib():
    """
    Print all common machine learning and data science library imports
    with detailed comments explaining their purpose.
    """
    imports_text = """# -------- Core Python Utilities --------
import warnings              # To ignore warnings during execution
import random                # Used for random actions (e.g., Tic Tac Toe opponent)
from collections import defaultdict   # Stores Q-values for Q-Learning
from io import StringIO      # Handles in-memory text streams (GraphViz export)

# -------- Numerical & Data Handling --------
import numpy as np           # Numerical computations, arrays, matrices
import pandas as pd          # Data loading, DataFrame manipulation

# -------- Visualization Libraries --------
import matplotlib.pyplot as plt   # Plotting graphs and visualizations
import seaborn as sns             # Statistical plotting (heatmaps, distributions)

# -------- Machine Learning (Scikit-Learn) --------
from sklearn import datasets      # Access to built-in datasets (Iris, digits)
from sklearn import metrics       # Provides accuracy, precision, recall, etc.
from sklearn import preprocessing # Label Encoding, normalization utilities

# Dataset utilities
from sklearn.datasets import load_iris, make_circles, make_classification  
# load_iris: Iris dataset
# make_circles / make_classification: synthetic dataset generators

# Preprocessing tools
from sklearn.preprocessing import LabelEncoder, StandardScaler
# LabelEncoder: Convert labels to numbers
# StandardScaler: Standardize features (mean=0, std=1)

# Train-test split & cross-validation
from sklearn.model_selection import train_test_split, cross_val_score
# train_test_split: Split into training and testing
# cross_val_score: K-fold cross-validation scoring

# Model evaluation tools
from sklearn.metrics import (
    accuracy_score,         # Computes accuracy
    classification_report,   # Precision, recall, F1-score
    confusion_matrix,        # Confusion matrix for classification
    ConfusionMatrixDisplay,  # Plot utility for confusion matrix
    roc_curve,               # ROC curve values
    roc_auc_score            # AUC score for classification models
)

# -------- ML Models / Algorithms --------
from sklearn.tree import DecisionTreeClassifier, export_graphviz
# DecisionTreeClassifier: Decision tree model
# export_graphviz: Export tree structure for visualization

from sklearn.svm import SVC                     # Support Vector Machine classifier
from sklearn.neighbors import KNeighborsClassifier  # K-Nearest Neighbors classifier

from sklearn.cluster import KMeans              # K-Means clustering algorithm
from sklearn.mixture import GaussianMixture     # EM algorithm (Gaussian Mixture Model)

from sklearn.naive_bayes import GaussianNB      # Naive Bayes (Gaussian version)

from sklearn.ensemble import RandomForestClassifier, BaggingClassifier, AdaBoostClassifier
# RandomForestClassifier: Ensemble of decision trees
# BaggingClassifier: Bagging ensemble method
# AdaBoostClassifier: Adaptive boosting ensemble method

# -------- Dimensionality Reduction --------
from sklearn.decomposition import PCA           # Principal Component Analysis

# -------- Bayesian Networks (pgmpy) --------
from pgmpy.models import DiscreteBayesianNetwork   # Build Bayesian networks
from pgmpy.factors.discrete import TabularCPD      # Create CPDs (probability tables)
from pgmpy.inference import VariableElimination    # Inference algorithm for BBNs

# -------- Graph Visualization --------
import networkx as nx            # Graph drawing and network structures
import pydotplus                 # Render GraphViz trees/graphs
from IPython.display import Image  # Display images in notebooks
"""
    print(imports_text)
