# PURBB

**Python Utility for Rapid Data Science and Machine Learning**

A simple utility package that helps you quickly print all common machine learning and data science library imports with detailed comments.

## Installation

```bash
pip install purbb
```

## Usage

After installing, simply import and use the `print_all_lib` function:

```python
from purbb import print_all_lib

# Print all common ML/DS imports with descriptions
print_all_lib()
```

## What it does

The `print_all_lib()` function prints a comprehensive list of commonly used Python imports for machine learning and data science, including:

- Core Python utilities (warnings, random, collections, io)
- Numerical libraries (NumPy, Pandas)
- Visualization libraries (Matplotlib, Seaborn)
- Scikit-learn modules (datasets, preprocessing, metrics, models)
- Machine learning algorithms (SVM, KNN, Decision Trees, etc.)
- Clustering algorithms (K-Means, Gaussian Mixture)
- Ensemble methods (Random Forest, Bagging, AdaBoost)
- Dimensionality reduction (PCA)
- Bayesian networks (pgmpy)
- Graph visualization (NetworkX, pydotplus)

Each import includes helpful comments explaining its purpose.

## Example Output

```python
from purbb import print_all_lib
print_all_lib()

# Output:
# -------- Core Python Utilities --------
# import warnings              # To ignore warnings during execution
# import random                # Used for random actions (e.g., Tic Tac Toe opponent)
# ...
```

## Requirements

- Python 3.7 or higher

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Author

Your Name

## Version

0.1.0

