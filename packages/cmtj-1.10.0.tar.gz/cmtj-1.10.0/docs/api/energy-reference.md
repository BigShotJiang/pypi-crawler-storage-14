::: cmtj.utils.energy
