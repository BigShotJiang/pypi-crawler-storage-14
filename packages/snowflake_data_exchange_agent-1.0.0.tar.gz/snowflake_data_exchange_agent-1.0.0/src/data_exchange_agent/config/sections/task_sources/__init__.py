"""Task source configuration module."""

from data_exchange_agent.config.sections.task_sources.api import ApiConfig
from data_exchange_agent.config.sections.task_sources.task_source import TaskSourceConfig
from data_exchange_agent.config.sections.task_sources.task_source_registry import TaskSourceRegistry
from data_exchange_agent.constants.task_source_types import TaskSourceType


# Register task source types
TaskSourceRegistry.register(TaskSourceType.API, ApiConfig)

__all__ = ["ApiConfig", "TaskSourceConfig", "TaskSourceRegistry"]
