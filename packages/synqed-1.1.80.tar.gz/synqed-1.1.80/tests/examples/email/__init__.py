"""Tests for email examples."""

