"""
Test Suite: Time Travel (SCD Type 2)
====================================

Testes para validar funcionalidades de Time Travel:
- Busca por versão específica
- Point-in-time queries
- Histórico completo de versões
"""

import os
import shutil
import tempfile
from datetime import UTC, datetime, timedelta

import pytest
from registro import DomainResource, register

from malha import (
    AsyncSQLAlchemyDriver,
    DuckDBDriver,
    KuzuActor,
    UnifiedDataManager,
)

# ============================================================================
# Domain Resource para Testes
# ============================================================================


class TimeUser(DomainResource):
    """Recurso de domínio para testes de Time Travel."""

    name: str
    email: str
    age: int | None = None
    status: str = "active"


# Registrar no global registry
register("TimeUser", TimeUser)


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
async def temp_dir():
    """Cria diretório temporário para testes."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def sql_driver(temp_dir):
    """Driver SQL para testes."""
    db_path = os.path.join(temp_dir, "test.db")
    driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
    await driver.create_tables()
    return driver


@pytest.fixture
async def graph_driver(temp_dir):
    """Driver de grafo para testes."""
    graph_path = os.path.join(temp_dir, "test_graph")
    driver = KuzuActor(graph_path)
    yield driver
    await driver.close()


@pytest.fixture
async def analytics_driver(temp_dir):
    """Driver analytics para testes."""
    db_path = os.path.join(temp_dir, "test.db")
    driver = DuckDBDriver(db_path)
    yield driver
    driver.close()


@pytest.fixture
async def kernel(sql_driver, graph_driver, analytics_driver):
    """Kernel configurado para testes."""
    manager = UnifiedDataManager(
        sql_driver=sql_driver,
        graph_driver=graph_driver,
        analytics_driver=analytics_driver,
        enable_monitoring=False,
        node_id="test-node",
    )
    await manager.boot()
    return manager


# ============================================================================
# Testes: Time Travel Básico
# ============================================================================


class TestTimeTravelBasic:
    """Testa funcionalidades básicas de Time Travel."""

    @pytest.mark.asyncio
    async def test_get_by_rid_active_only(self, kernel):
        """Testa busca por RID retorna apenas versão ativa."""
        repo = kernel.get_repository(TimeUser)

        # Criar usuário
        user = TimeUser(name="Alice", email="alice@example.com", age=25)
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Buscar por RID (deve retornar versão ativa)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=rid)

        assert found is not None
        assert found.rid == rid
        assert found.name == "Alice"
        assert found.age == 25

    @pytest.mark.asyncio
    async def test_get_by_id_physical(self, kernel):
        """Testa busca por ID físico."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Bob", email="bob@example.com")
        saved = await kernel.save_versioned(obj=user)

        # Buscar por ID físico
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, id=saved.id)

        assert found is not None
        assert found.id == saved.id
        assert found.name == "Bob"

    @pytest.mark.asyncio
    async def test_get_with_filters(self, kernel):
        """Testa busca com filtros adicionais."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Charlie", email="charlie@example.com", status="premium")
        saved = await kernel.save_versioned(obj=user)

        # Buscar com filtro em coluna SQL (service)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=saved.rid, service="default")

        assert found is not None
        assert found.name == "Charlie"


# ============================================================================
# Testes: Version History
# ============================================================================


class TestVersionHistory:
    """Testa histórico de versões."""

    @pytest.mark.asyncio
    async def test_get_history_empty(self, kernel):
        """Testa get_history para RID inexistente."""
        repo = kernel.get_repository(TimeUser)

        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid="ri.test.prod.user.nonexistent")

        assert len(history) == 0

    @pytest.mark.asyncio
    async def test_get_history_single_version(self, kernel):
        """Testa get_history com uma única versão."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Diana", email="diana@example.com", age=28)
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=rid)

        assert len(history) == 1
        assert history[0].name == "Diana"
        assert history[0].age == 28

    @pytest.mark.asyncio
    async def test_get_history_ordering(self, kernel):
        """Testa ordenação do histórico."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Eve", email="eve@example.com", age=30)
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Buscar histórico em ordem crescente
        async with await kernel.sql_driver.get_session() as session:
            history_asc = await repo.get_history(session, rid=rid, ascending=True)

        assert len(history_asc) >= 1

        # Buscar histórico em ordem decrescente
        async with await kernel.sql_driver.get_session() as session:
            history_desc = await repo.get_history(session, rid=rid, ascending=False)

        assert len(history_desc) >= 1


# ============================================================================
# Testes: Active vs Inactive Versions
# ============================================================================


class TestActiveInactiveVersions:
    """Testa diferenciação entre versões ativas e inativas."""

    @pytest.mark.asyncio
    async def test_active_only_flag(self, kernel):
        """Testa flag active_only."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Frank", email="frank@example.com", age=35)
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Buscar com active_only=True (padrão)
        async with await kernel.sql_driver.get_session() as session:
            active = await repo.get(session, rid=rid, active_only=True)

        assert active is not None
        assert active.valid_to is None  # Versão ativa

        # Buscar com active_only=False (todas as versões)
        async with await kernel.sql_driver.get_session() as session:
            any_version = await repo.get(session, rid=rid, active_only=False)

        assert any_version is not None


# ============================================================================
# Testes: Point-in-Time Queries
# ============================================================================


class TestPointInTimeQueries:
    """Testa queries em pontos específicos do tempo."""

    @pytest.mark.asyncio
    async def test_at_time_current(self, kernel):
        """Testa at_time com timestamp atual."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Grace", email="grace@example.com", age=40)
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Buscar no momento atual
        now = datetime.now(UTC)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=rid, at_time=now)

        assert found is not None
        assert found.name == "Grace"

    @pytest.mark.asyncio
    async def test_at_time_future(self, kernel):
        """Testa at_time com timestamp futuro."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Henry", email="henry@example.com")
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Buscar no futuro (deve retornar a versão atual)
        future = datetime.now(UTC) + timedelta(days=365)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=rid, at_time=future)

        assert found is not None
        assert found.name == "Henry"

    @pytest.mark.asyncio
    async def test_at_time_past_no_version(self, kernel):
        """Testa at_time com timestamp anterior à criação."""
        repo = kernel.get_repository(TimeUser)

        user = TimeUser(name="Ivy", email="ivy@example.com")
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Buscar no passado (antes da criação)
        past = datetime.now(UTC) - timedelta(days=365)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=rid, at_time=past)

        # Não deve encontrar (recurso não existia)
        assert found is None


# ============================================================================
# Testes de Integração
# ============================================================================


class TestTimeTravelIntegration:
    """Testes de integração para Time Travel."""

    @pytest.mark.asyncio
    async def test_complete_time_travel_workflow(self, kernel):
        """Testa workflow completo de Time Travel."""
        repo = kernel.get_repository(TimeUser)

        # Criar usuário
        user = TimeUser(name="Jack", email="jack@example.com", age=45, status="active")
        v1 = await kernel.save_versioned(obj=user)
        rid = v1.rid

        # Verificar versão atual
        async with await kernel.sql_driver.get_session() as session:
            current = await repo.get(session, rid=rid)

        assert current.name == "Jack"
        assert current.age == 45
        assert current.status == "active"

        # Verificar histórico
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=rid)

        assert len(history) >= 1
        assert history[0].name == "Jack"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
