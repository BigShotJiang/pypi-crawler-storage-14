"""
Test Suite: Coverage Target 80-85%
==================================

Targeted tests for uncovered code paths to reach 80-85% coverage.
"""

import asyncio
import os
import shutil
import tempfile
from unittest.mock import AsyncMock, patch

import pytest
from pydantic import BaseModel
from registro import DomainResource, register

from malha import (
    DuckDBDriver,
    KuzuActor,
    SysOutbox,
    connect,
)
from malha.instrumentation import KernelInstrumentation
from malha.monitor import KernelMonitor

# ============================================================================
# Domain Resources
# ============================================================================

class TargetUser(DomainResource):
    name: str
    email: str = "test@example.com"
    age: int | None = None

register("TargetUser", TargetUser)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def temp_dir():
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def kernel(temp_dir):
    db_path = os.path.join(temp_dir, "test.db")
    graph_path = os.path.join(temp_dir, "test_graph")
    manager = await connect(
        url=f"sqlite+aiosqlite:///{db_path}",
        kuzu_path=graph_path,
        enable_monitoring=False,
    )
    yield manager
    await manager.close()


# ============================================================================
# Tests: Repository create with BaseModel (lines 301-303)
# ============================================================================

class TestRepositoryBaseModelCreate:
    @pytest.mark.asyncio
    async def test_create_with_non_domain_basemodel(self, kernel):
        """Test create with a non-DomainResource BaseModel."""
        class SimpleModel(BaseModel):
            name: str
            age: int = 25

        repo = kernel.get_repository(TargetUser)

        async with await kernel.sql_driver.get_session() as session:
            # Pass a BaseModel that's not a DomainResource
            simple = SimpleModel(name="Alice", age=30)
            created = await repo.create(session, simple)
            await session.commit()

        assert created.name == "Alice"


# ============================================================================
# Tests: save() method paths (lines 950-994)
# ============================================================================

class TestSaveMethod:
    @pytest.mark.asyncio
    async def test_save_with_dict(self, kernel):
        """Test save with dict data."""
        result = await kernel.save(TargetUser, {"name": "Bob", "age": 25})
        assert result.name == "Bob"

    @pytest.mark.asyncio
    async def test_save_with_basemodel(self, kernel):
        """Test save with BaseModel data."""
        user = TargetUser(name="Charlie", age=30)
        result = await kernel.save(TargetUser, user)
        assert result.name == "Charlie"

    @pytest.mark.asyncio
    async def test_save_update_existing(self, kernel):
        """Test save updates existing record."""
        # Create first
        created = await kernel.save(TargetUser, {"name": "Diana", "age": 25})

        # Update
        updated = await kernel.save(
            TargetUser,
            {"id": created.id, "name": "Diana Updated", "age": 26},
        )

        assert updated.name == "Diana Updated"
        assert updated.age == 26


# ============================================================================
# Tests: register_model (lines 923-927)
# ============================================================================

class TestRegisterModel:
    @pytest.mark.asyncio
    async def test_register_model_creates_view(self, kernel):
        """Test register_model creates analytics view."""
        class NewModel(DomainResource):
            title: str

        register("NewModel", NewModel)

        with patch.object(kernel.graph_driver, "register_schema", new_callable=AsyncMock):
            with patch.object(kernel.analytics_driver, "register_view", new_callable=AsyncMock) as mock_view:
                await kernel.register_model(NewModel)
                mock_view.assert_called_once()


# ============================================================================
# Tests: Outbox processing with replication (lines 1582-1646)
# ============================================================================

class TestOutboxProcessing:
    @pytest.mark.asyncio
    async def test_process_outbox_no_replication_driver(self, kernel):
        """Test process_outbox returns early without replication driver."""
        kernel.replication_driver = None
        await kernel.process_outbox()
        # Should return without error

    @pytest.mark.asyncio
    async def test_process_outbox_with_replication(self, temp_dir):
        """Test process_outbox with mock replication driver."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        # Create mock replication driver
        mock_replication = AsyncMock()
        mock_replication.start = AsyncMock()
        mock_replication.stop = AsyncMock()
        mock_replication.broadcast = AsyncMock()

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
            replication_driver=mock_replication,
        )

        # Create a user to generate outbox event
        user = TargetUser(name="Outbox Test")
        await manager.save_versioned(user, origin="local")

        # Process outbox
        await manager.process_outbox()

        # Verify broadcast was called
        assert mock_replication.broadcast.called

        await manager.close()

    @pytest.mark.asyncio
    async def test_process_outbox_broadcast_failure(self, temp_dir):
        """Test process_outbox handles broadcast failure with retry."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        # Create mock replication driver that fails
        mock_replication = AsyncMock()
        mock_replication.start = AsyncMock()
        mock_replication.stop = AsyncMock()
        mock_replication.broadcast = AsyncMock(side_effect=Exception("Network error"))

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
            replication_driver=mock_replication,
        )

        # Create a user to generate outbox event
        user = TargetUser(name="Retry Test")
        await manager.save_versioned(user, origin="local")

        # Process outbox (should handle error)
        await manager.process_outbox(max_retries=3)

        # Check event was marked for retry
        async with await manager.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.status == "RETRY")
            result = await session.execute(stmt)
            retry_events = result.scalars().all()

        assert len(retry_events) >= 1

        await manager.close()

    @pytest.mark.asyncio
    async def test_process_outbox_dead_letter_queue(self, temp_dir):
        """Test process_outbox moves to DLQ after max retries."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        # Create mock replication driver that always fails
        mock_replication = AsyncMock()
        mock_replication.start = AsyncMock()
        mock_replication.stop = AsyncMock()
        mock_replication.broadcast = AsyncMock(side_effect=Exception("Permanent failure"))

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
            replication_driver=mock_replication,
        )

        # Create a user to generate outbox event
        user = TargetUser(name="DLQ Test")
        await manager.save_versioned(user, origin="local")

        # Set event to have max retries already
        async with await manager.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.status == "PENDING")
            result = await session.execute(stmt)
            event = result.scalars().first()
            if event:
                event.retries = 4  # One less than max
                await session.commit()

        # Process outbox (should move to DLQ)
        await manager.process_outbox(max_retries=5)

        # Check event was moved to DLQ
        async with await manager.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.status == "DEAD_LETTER")
            result = await session.execute(stmt)
            dlq_events = result.scalars().all()

        assert len(dlq_events) >= 1

        await manager.close()


# ============================================================================
# Tests: start_outbox_processor (lines 1648-1671)
# ============================================================================

class TestOutboxProcessor:
    @pytest.mark.asyncio
    async def test_start_outbox_processor(self, temp_dir):
        """Test starting the background outbox processor."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        mock_replication = AsyncMock()
        mock_replication.start = AsyncMock()
        mock_replication.stop = AsyncMock()
        mock_replication.broadcast = AsyncMock()

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
            replication_driver=mock_replication,
        )

        # Start processor
        await manager.start_outbox_processor(interval=0.1)

        # Verify task was created
        assert hasattr(manager, "_outbox_processor")
        assert manager._outbox_processor is not None

        # Wait a bit for processor to run
        await asyncio.sleep(0.3)

        await manager.close()


# ============================================================================
# Tests: Monitor additional paths (lines 111-112, 160, 194-211)
# ============================================================================

class TestMonitorAdditional:
    @pytest.mark.asyncio
    async def test_monitor_auto_flush_loop(self, temp_dir):
        """Test monitor auto-flush loop."""
        driver = DuckDBDriver()
        monitor = KernelMonitor(driver, node_id="test", flush_interval=0.1)

        # Add some metrics
        await monitor.collect_metric(
            operation="test", duration_ms=10.0, status="success",
        )

        # Start auto-flush
        await monitor.start_auto_flush()

        # Wait for flush
        await asyncio.sleep(0.3)

        # Stop
        await monitor.stop()

        driver.close()

    @pytest.mark.asyncio
    async def test_monitor_get_summary_with_data(self, temp_dir):
        """Test get_summary with actual data."""
        driver = DuckDBDriver()
        monitor = KernelMonitor(driver, node_id="test")

        # Add and flush metrics
        for i in range(5):
            await monitor.collect_metric(
                operation=f"op{i}",
                duration_ms=float(i * 10),
                status="success",
                resource_type="TestModel",
            )

        async with monitor._buffer_lock:
            await monitor._flush_metrics()

        # Get summary
        summary = monitor.get_summary(hours=1)

        assert summary["total_operations"] >= 0

        driver.close()


# ============================================================================
# Tests: Instrumentation additional paths (lines 154-155, 168, 171-172, 199)
# ============================================================================

class TestInstrumentationAdditional:
    @pytest.mark.asyncio
    async def test_instrumentation_flush_with_arrow(self):
        """Test instrumentation flush with Arrow ingestion."""
        driver = DuckDBDriver()
        instr = KernelInstrumentation(driver, interval=60)

        # Add metrics
        from malha.instrumentation import metrics
        metrics.increment("test.counter", 10)
        metrics.set_gauge("test.gauge", 42.0)
        metrics.record_histogram("test.hist", 100.0)

        # Flush
        await instr._flush_metrics()

        driver.close()

    @pytest.mark.asyncio
    async def test_instrumentation_periodic_flush(self):
        """Test instrumentation periodic flush task."""
        driver = DuckDBDriver()
        instr = KernelInstrumentation(driver, interval=0.1)

        await instr.start()

        # Wait for a few flush cycles
        await asyncio.sleep(0.35)

        await instr.stop()

        driver.close()


# ============================================================================
# Tests: Graph driver edge cases (lines 636-643, 649, 673-675)
# ============================================================================

class TestGraphDriverEdgeCases:
    @pytest.mark.asyncio
    async def test_kuzu_execute_with_params(self, temp_dir):
        """Test KuzuActor execute with parameters."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        # Execute a simple query with params
        with patch.object(driver, "_execute_query", new_callable=AsyncMock) as mock_exec:
            mock_exec.return_value = []
            await driver.execute("CREATE NODE TABLE Test(id STRING PRIMARY KEY)", {})

        await driver.close()

    @pytest.mark.asyncio
    async def test_kuzu_query_with_params(self, temp_dir):
        """Test KuzuActor query with parameters."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)

        with patch.object(driver, "_execute_query", new_callable=AsyncMock) as mock_exec:
            mock_exec.return_value = [{"name": "Test"}]
            result = await driver.query("MATCH (n) WHERE n.name = $name RETURN n", {"name": "Test"})
            assert len(result) == 1

        await driver.close()


# ============================================================================
# Tests: Analytics driver edge cases (lines 751, 803)
# ============================================================================

class TestAnalyticsDriverEdgeCases:
    @pytest.mark.asyncio
    async def test_duckdb_query_simple(self):
        """Test DuckDB simple query."""
        driver = DuckDBDriver()

        # Create a test table
        driver.conn.execute("CREATE TABLE test_simple (id INT, name VARCHAR)")
        driver.conn.execute("INSERT INTO test_simple VALUES (1, 'Alice')")

        # Query without params
        result = await driver.query("SELECT * FROM test_simple WHERE id = 1")

        assert len(result) == 1
        assert result[0][1] == "Alice"

        driver.close()


# ============================================================================
# Tests: delete method (lines 1197-1214)
# ============================================================================

class TestDeleteMethod:
    @pytest.mark.asyncio
    async def test_delete_by_id(self, kernel):
        """Test delete by ID."""
        # Create
        user = TargetUser(name="ToDelete")
        saved = await kernel.save_versioned(user)

        # Delete
        await kernel.delete(TargetUser, saved.id)

        # Verify deleted
        found = await kernel.get(TargetUser, saved.id)
        assert found is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, kernel):
        """Test delete nonexistent record."""
        # Should not raise
        await kernel.delete(TargetUser, "nonexistent-id")


# ============================================================================
# Tests: connect with reset (lines 1707-1711)
# ============================================================================

class TestConnectReset:
    @pytest.mark.asyncio
    async def test_connect_with_reset_removes_files(self, temp_dir):
        """Test connect with reset=True removes existing files."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        # Create first connection
        manager1 = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
        )

        # Save some data
        user = TargetUser(name="BeforeReset")
        await manager1.save_versioned(user)
        await manager1.close()

        # Connect with reset
        manager2 = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            reset=True,
        )

        # Data should be gone
        results = await manager2.list(TargetUser)
        assert len(results) == 0

        await manager2.close()
