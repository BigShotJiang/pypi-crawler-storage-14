# invhelpers

Small helpers for a Django inventory app. Provides simple functions to parse dates, compute days until expiry, and get an item's status.

## Install (local)
```bash
pip install -e .
```

## Use in your project
```python
from invhelpers import parse_ymd, days_to_expiry, item_status

d = parse_ymd("2025-12-31")           # -> datetime.date or None
n = days_to_expiry("2025-12-31")      # -> integer days or None
s = item_status(5, 2, "2025-12-31")   # -> "ok" / "low" / "out" / "expired"
```

## Notes
- Expects dates like "YYYY-MM-DD".
- All functions are basic and safe for beginner use.