"""Quantitative analysis and pricing"""

__version__ = "0.4.3"
