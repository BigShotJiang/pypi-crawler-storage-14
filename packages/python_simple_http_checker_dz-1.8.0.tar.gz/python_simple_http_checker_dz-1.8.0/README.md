# python-devops-cicd-project
This repo contains the code for the CI/CD section of my Python for DevOps course
