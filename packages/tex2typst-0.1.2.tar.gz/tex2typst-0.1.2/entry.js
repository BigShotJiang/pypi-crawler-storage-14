import { tex2typst } from "tex2typst";

globalThis.convert = tex2typst;