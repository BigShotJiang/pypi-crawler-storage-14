import numpy as np
from scipy.stats import qmc
from typing import Dict, Iterable, List, Tuple
from class_e.core.parameters import Parameter


class LatinHyperCube:
    def __init__(
        self, param_ranges: Iterable[Parameter], seed: int | None = None
    ) -> None:
        self.param_ranges: List[Parameter] = list(param_ranges)
        # For maximum compatibility: seed NumPy global RNG if requested, then build sampler
        if seed is not None:
            np.random.seed(int(seed))
        self.sampler = qmc.LatinHypercube(d=len(self.param_ranges))

    def sample(self, n: int) -> Tuple[np.ndarray, List[str]]:
        """Draw n samples and map to parameter ranges.

        Returns
        -------
        samples : (n, d) array
        names : list[str]
        """
        unit = self.sampler.random(n)
        mins = np.array([p.min for p in self.param_ranges])
        maxs = np.array([p.max for p in self.param_ranges])
        samples = qmc.scale(unit, mins, maxs)
        names = [p.name for p in self.param_ranges]
        return samples, names

    @staticmethod
    def dict_to_ranges(bounds: Dict[str, Tuple[float, float]]) -> List[Parameter]:
        return [Parameter(k, min=v[0], max=v[1]) for k, v in bounds.items()]


class LatinHyperSphere:
    """
    Latin Hyper Sphere sampler that generates points uniformly distributed on the
    surface of a hypersphere, then maps them to parameter space while maintaining
    Latin Hypercube stratification properties.

    This is useful when parameters have natural correlations or when you want to
    avoid extreme parameter combinations that may be unphysical.
    """

    def __init__(
        self,
        param_ranges: Iterable[Parameter],
        seed: int | None = None,
        sampling_type: str = "surface",
    ) -> None:
        """
        Initialize the Latin Hyper Sphere sampler.

        Parameters
        ----------
        param_ranges : Iterable[Parameter]
            Parameter ranges to sample from
        seed : int, optional
            Random seed for reproducibility
        sampling_type : str, default 'surface'
            Type of sampling: 'surface' (on sphere surface) or 'volume' (within sphere)
        """
        self.param_ranges: List[Parameter] = list(param_ranges)
        self.sampling_type = sampling_type
        self._seed = seed
        if seed is not None:
            np.random.seed(int(seed))
        # We'll use LHS for angular coordinates stratification
        self.lhs_sampler = qmc.LatinHypercube(d=len(self.param_ranges))

    def sample(self, n: int) -> Tuple[np.ndarray, List[str]]:
        """
        Draw n samples from the hypersphere and map to parameter ranges.

        Returns
        -------
        samples : (n, d) array
            Parameter samples
        names : list[str]
            Parameter names
        """
        d = len(self.param_ranges)

        if self.sampling_type == "surface":
            sphere_points = self._sample_hypersphere_surface(n, d)
        elif self.sampling_type == "volume":
            sphere_points = self._sample_hypersphere_volume(n, d)
        else:
            raise ValueError(f"Unknown sampling_type: {self.sampling_type}")

        # Map from hypersphere to parameter space
        samples = self._map_to_parameter_space(sphere_points)
        names = [p.name for p in self.param_ranges]

        return samples, names

    def _sample_hypersphere_surface(self, n: int, d: int) -> np.ndarray:
        """
        Sample n points uniformly on the surface of a unit d-dimensional hypersphere.
        Uses the Marsaglia method: generate Gaussian random vectors and normalize.
        """
        # Generate Gaussian random vectors
        gaussian_vectors = np.random.normal(0, 1, (n, d))

        # Normalize to unit sphere surface
        norms = np.linalg.norm(gaussian_vectors, axis=1, keepdims=True)
        # Avoid division by zero (extremely rare)
        norms = np.maximum(norms, 1e-12)

        unit_sphere_points = gaussian_vectors / norms

        # Apply Latin stratification to improve space-filling properties
        return self._apply_latin_stratification(unit_sphere_points)

    def _sample_hypersphere_volume(self, n: int, d: int) -> np.ndarray:
        """
        Sample n points uniformly within a d-dimensional unit hypersphere.
        """
        # First get points on surface
        surface_points = self._sample_hypersphere_surface(n, d)

        # Generate radii with correct distribution for uniform density
        # For d dimensions, radius should be distributed as r^(d-1)
        uniform_r = np.random.random(n)
        radii = np.power(uniform_r, 1.0 / d)

        # Scale surface points by radii
        return surface_points * radii.reshape(-1, 1)

    def _apply_latin_stratification(self, sphere_points: np.ndarray) -> np.ndarray:
        """
        Apply Latin Hypercube stratification to improve space-filling properties.
        This is a heuristic approach that tries to maintain both spherical distribution
        and Latin Hypercube stratification.
        """
        n, d = sphere_points.shape

        # Get LHS samples in [0,1]^d
        lhs_unit = self.lhs_sampler.random(n)

        # Sort sphere points by each dimension and reassign using LHS order
        stratified_points = np.zeros_like(sphere_points)

        for dim in range(d):
            # Get sorting indices for this dimension
            sort_indices = np.argsort(sphere_points[:, dim])
            # Get LHS ordering for this dimension
            lhs_order = np.argsort(lhs_unit[:, dim])
            # Reassign using LHS stratification
            stratified_points[lhs_order, dim] = sphere_points[sort_indices, dim]

        return stratified_points

    def _map_to_parameter_space(self, sphere_points: np.ndarray) -> np.ndarray:
        """
        Map points from unit hypersphere to parameter space.
        Uses a simple linear scaling approach that maps the bounding box
        of the sphere to the parameter ranges.
        """
        n, d = sphere_points.shape

        # Get parameter bounds
        lows = np.array([p.min for p in self.param_ranges])
        highs = np.array([p.max for p in self.param_ranges])

        # Map from [-1, 1] (sphere bounds) to [low, high] (parameter bounds)
        # sphere_points are in [-1, 1] for each dimension
        samples = lows + (highs - lows) * (sphere_points + 1.0) / 2.0

        return samples

    @staticmethod
    def dict_to_ranges(bounds: Dict[str, Tuple[float, float]]) -> List[Parameter]:
        """Convert dictionary of bounds to list of Parameter objects."""
        return [Parameter(k, min=v[0], max=v[1]) for k, v in bounds.items()]


class CovarianceAwareLatinHyperCube:
    """
    Latin Hypercube sampler that uses a covariance matrix from previous MCMC runs
    to generate samples that respect parameter correlations and uncertainties.

    This is particularly useful for:
    - Training emulators focused on observationally relevant parameter regions
    - Respecting known parameter degeneracies (e.g., from Planck)
    - Efficient sampling in high-dimensional spaces
    - Avoiding unphysical parameter combinations
    """

    def __init__(
        self,
        param_ranges: Iterable[Parameter],
        covariance: np.ndarray,
        mean: np.ndarray | None = None,
        n_sigma: float = 3.0,
        seed: int | None = None,
        clip_to_bounds: bool = True,
    ) -> None:
        """
        Initialize covariance-aware sampler.

        Parameters
        ----------
        param_ranges : Iterable[Parameter]
            Parameter ranges (used for bounds and parameter names)
        covariance : np.ndarray, shape (d, d)
            Covariance matrix from MCMC runs
        mean : np.ndarray, shape (d,), optional
            Mean/best-fit parameter values. If None, uses center of param_ranges
        n_sigma : float, default 3.0
            Sample within n_sigma standard deviations
        seed : int, optional
            Random seed for reproducibility
        clip_to_bounds : bool, default True
            Whether to clip samples to stay within parameter bounds
        """
        self.param_ranges: List[Parameter] = list(param_ranges)
        self.covariance = np.asarray(covariance)
        self.n_sigma = n_sigma
        self.clip_to_bounds = clip_to_bounds
        self._seed = seed

        d = len(self.param_ranges)
        if self.covariance.shape != (d, d):
            raise ValueError(
                f"Covariance shape {self.covariance.shape} doesn't match {d} parameters"
            )

        # Set mean (center of distribution)
        if mean is not None:
            self.mean = np.asarray(mean)
            if self.mean.shape != (d,):
                raise ValueError(
                    f"Mean shape {self.mean.shape} doesn't match {d} parameters"
                )
        else:
            # Use center of parameter ranges if no mean provided
            self.mean = np.array([(p.min + p.max) / 2 for p in self.param_ranges])

        # Compute Cholesky decomposition for sampling
        # C = L @ L.T, where L is lower triangular
        try:
            self.L = np.linalg.cholesky(self.covariance)
        except np.linalg.LinAlgError:
            # If not positive definite, use eigendecomposition instead
            eigenvalues, eigenvectors = np.linalg.eigh(self.covariance)
            # Ensure positive eigenvalues
            eigenvalues = np.maximum(eigenvalues, 1e-10)
            self.L = eigenvectors @ np.diag(np.sqrt(eigenvalues))

        if seed is not None:
            np.random.seed(int(seed))

        # Create standard LHC sampler for the uncorrelated space
        self.lhc_sampler = qmc.LatinHypercube(d=d)

    def sample(self, n: int) -> Tuple[np.ndarray, List[str]]:
        """
        Draw n correlated samples using the covariance matrix.

        Returns
        -------
        samples : (n, d) array
            Parameter samples respecting covariance structure
        names : list[str]
            Parameter names
        """
        # Sample in standard normal space using LHC
        # Map [0,1]^d to [-n_sigma, n_sigma]^d with normal quantiles
        unit_samples = self.lhc_sampler.random(n)

        # Transform to standard normal using inverse CDF
        from scipy.stats import norm

        standard_normal_samples = norm.ppf(unit_samples)

        # Scale by n_sigma
        scaled_samples = self.n_sigma * standard_normal_samples

        # Transform using Cholesky factor: x = mean + L @ z
        correlated_samples = self.mean + (self.L @ scaled_samples.T).T

        # Optionally clip to parameter bounds
        if self.clip_to_bounds:
            for i, param in enumerate(self.param_ranges):
                correlated_samples[:, i] = np.clip(
                    correlated_samples[:, i], param.min, param.max
                )

        names = [p.name for p in self.param_ranges]
        return correlated_samples, names

    def get_principal_components(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get principal components (eigenvectors) and their uncertainties (sqrt of eigenvalues).

        Returns
        -------
        eigenvalues : np.ndarray, shape (d,)
            Eigenvalues of covariance matrix (variances along principal axes)
        eigenvectors : np.ndarray, shape (d, d)
            Eigenvectors (principal axes), each column is an eigenvector
        """
        eigenvalues, eigenvectors = np.linalg.eigh(self.covariance)
        # Sort by decreasing eigenvalue
        idx = eigenvalues.argsort()[::-1]
        return eigenvalues[idx], eigenvectors[:, idx]

    def get_correlation_matrix(self) -> np.ndarray:
        """
        Convert covariance to correlation matrix.

        Returns
        -------
        correlation : np.ndarray, shape (d, d)
            Correlation matrix with values in [-1, 1]
        """
        std_devs = np.sqrt(np.diag(self.covariance))
        correlation = self.covariance / np.outer(std_devs, std_devs)
        return correlation

    @staticmethod
    def dict_to_ranges(bounds: Dict[str, Tuple[float, float]]) -> List[Parameter]:
        """Convert dictionary of bounds to list of Parameter objects."""
        return [Parameter(k, min=v[0], max=v[1]) for k, v in bounds.items()]


def create_sampler(
    param_ranges: Iterable[Parameter],
    seed: int | None = None,
    method: str = "lhc",
    **kwargs,
) -> LatinHyperCube | LatinHyperSphere | CovarianceAwareLatinHyperCube:
    """
    Factory function to create LHC, LHS, or covariance-aware sampler.

    Parameters
    ----------
    param_ranges : Iterable[ParamRange]
        Parameter ranges to sample from
    seed : int, optional
        Random seed for reproducibility
    method : str, default 'lhc'
        Sampling method:
        - 'lhc': Latin Hypercube
        - 'lhs': Latin Hyper Sphere
        - 'cov': Covariance-aware Latin Hypercube
    **kwargs
        Additional arguments passed to the sampler:
        - For 'lhs': sampling_type ('surface' or 'volume')
        - For 'cov': covariance, mean, n_sigma, clip_to_bounds

    Returns
    -------
    sampler : LatinHypercubeSampler, LatinHyperSphereSampler, or CovarianceAwareLatinHypercubeSampler
    """
    if method.lower() == "lhc":
        return LatinHyperCube(param_ranges, seed)
    elif method.lower() == "lhs":
        return LatinHyperSphere(param_ranges, seed, **kwargs)
    elif method.lower() == "cov":
        if "covariance" not in kwargs:
            raise ValueError("Covariance-aware sampling requires 'covariance' argument")
        return CovarianceAwareLatinHyperCube(param_ranges, seed=seed, **kwargs)
    else:
        raise ValueError(
            f"Unknown sampling method: {method}. Use 'lhc', 'lhs', or 'cov'."
        )
