# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "marimo",
#     "nbformat==5.10.4",
#     "openai==2.2.0",
#     "pytest==8.4.2",
#     "ruff==0.14.0",
#     "typer==0.19.2",
# ]
# ///

import marimo

__generated_with = "0.17.2"
app = marimo.App(width="full")

with app.setup:
    # Initialization code that runs before all other cells
    from rich.console import Console
    from typing import Optional, List, Union, Any, Tuple
    from dataclasses import dataclass
    from pathlib import Path
    import numpy as np

    from class_e.generation.engine import (
        parse_config,
        compute_dataset,
        save_dataset,
        GenerationConfig,
    )

    def normalize_method(name: Optional[str]) -> str:
        key = str(name or "").strip().lower()
        aliases = {
            "lhc": "lhc",
            "latinhypercube": "lhc",
            "lhs": "lhs",
            "latinhypersphere": "lhs",
            "cov": "cov",
            "covarianceawarelatinhypercube": "cov",
        }
        return aliases.get(key, key)

    def normalize_out_path(
        out: Union[str, Path], default_filename: str = "data.npz"
    ) -> Path:
        p = Path(out)
        if p.suffix == ".npz":
            return p
        # If user clearly passed a directory (trailing slash), write default file inside it
        if isinstance(out, str) and out.rstrip().endswith("/"):
            return p / default_filename
        # Treat as file stem
        return p.with_suffix(".npz")

    def load_covariance(path: Path) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        if not path.exists():
            raise FileNotFoundError(str(path))

        covariance = None
        mean = None
        suf = path.suffix.lower()
        if suf == ".npz":
            arr = np.load(path, allow_pickle=True)
            if "covariance" in arr:
                covariance = arr["covariance"]
                if "mean" in arr:
                    mean = arr["mean"]
            elif len(arr.files) == 1:
                covariance = arr[arr.files[0]]
            else:
                raise ValueError(
                    "NPZ must contain 'covariance' (and optional 'mean') or a single array"
                )
        elif suf == ".npy":
            covariance = np.load(path)
        elif suf in (".txt", ".dat"):
            covariance = np.loadtxt(path)
        elif suf == ".csv":
            covariance = np.loadtxt(path, delimiter=",")
        else:
            # Fallback: try text load
            covariance = np.loadtxt(path)

        covariance = np.asarray(covariance, dtype=float)
        if covariance.ndim != 2 or covariance.shape[0] != covariance.shape[1]:
            raise ValueError(f"Invalid covariance shape: {covariance.shape}")

        if mean is not None:
            mean = np.asarray(mean, dtype=float)
            if mean.ndim != 1 or mean.shape[0] != covariance.shape[0]:
                # Ignore invalid mean
                mean = None
        return covariance, mean


@app.class_definition
@dataclass
class Options:
    info: Path
    out: Optional[Path] = None
    N: Optional[int] = None
    method: Optional[str] = None
    observables: Optional[List[str]] = None
    lmin: Optional[int] = None
    lmax: Optional[int] = None
    Nk: Optional[int] = 200
    kmin: Optional[float] = None
    kmax: Optional[float] = None
    cov: Optional[Path] = None
    interactive: bool = False
    dry_run: bool = False
    force: bool = False


@app.function
def load_info(
    info: str | None = None,
    out: str | None = None,
    n: int = 50,
    observables: list[str] = ["TT", "TE", "EE", "mPk"],
    lmin: int = 2,
    lmax: int = 2500,
    console=None,
):
    """Generate synthetic data based on a given cosmological model.

    Args:
        info (str | None, optional): Path to the cosmological model info file. Defaults to None.
        out (str | None, optional): Output path for the generated data. Defaults to None.
        n (int, optional): Number of synthetic datasets to generate. Defaults to 50.
        observables (list[str], optional): List of observables to include. Defaults to ['TT','TE','EE','mPk'].
        lmin (int, optional): Minimum multipole moment. Defaults to 2.
        lmax (int, optional): Maximum multipole moment. Defaults to 2500.
        console (_type_, optional): Console for logging. Defaults to None.
    """
    from class_e.utils import load_yaml

    info = load_yaml(info)
    return info


@app.function
def run(options: Options, console: Console) -> Optional[Path]:
    from class_e.core import io

    conf: GenerationConfig = parse_config(options.info)

    # Apply overrides
    if options.N is not None:
        conf.n_samples = int(options.N)
    if options.observables is not None:
        conf.observables = list(options.observables)
    if options.lmax is not None:
        conf.lmax = int(options.lmax)
    if options.method is not None:
        conf.method = normalize_method(options.method)

    # k grid
    if options.kmin is not None and options.kmax is not None:
        conf.k_values = np.logspace(
            np.log10(float(options.kmin)), np.log10(float(options.kmax)), options.Nk
        )

    # Covariance
    if options.cov is not None:
        cov, mean = load_covariance(Path(options.cov))
        conf.method = "cov"
        conf.sampling_kwargs["covariance"] = cov
        if mean is not None:
            conf.sampling_kwargs["mean"] = mean

    # Output path normalization: always use YAML output path unless --out is set
    if options.out:
        conf.output_path = normalize_out_path(options.out)
    else:
        out_path = Path(conf.output_path)
        if out_path.suffix != ".npz":
            out_path = out_path / "data.npz"
        conf.output_path = out_path

    # Build expected metadata
    expected_meta: dict[str, Any] = {
        "model_name": conf.model_name,
        "lmax": conf.lmax,
        "lensed": conf.lensed,
        "observables": conf.observables,
        "method": conf.method,
        "n_samples": conf.n_samples,
    }

    # Always check for existing file at output path
    check_target = Path(conf.output_path)
    existing = check_target if check_target.exists() else None
    if existing is not None and not options.dry_run:
        meta = io._load_metadata(existing)
        if meta:
            from class_e.core.io import _meta_matches

            if _meta_matches(meta, expected_meta):
                if options.force:
                    console.print(
                        "[bold yellow]Run settings match existing dataset. Overwriting as requested by --force.[/bold yellow]"
                    )
                    conf.output_path = existing
                else:
                    console.print(
                        "[bold yellow]Run settings match existing dataset. No need to rerun.[/bold yellow]"
                    )
                    return None
            else:
                console.print(
                    "[bold red]A dataset already exists at this path with different settings.[/bold red]"
                )
                console.print(
                    "You may abort and specify a new filename using the --out flag, or continue to overwrite."
                )
                if not options.force:
                    import typer

                    if not typer.confirm("Overwrite existing dataset?", default=False):
                        console.print(
                            "[bold]Aborted. Please rerun with a different --out filename if desired.[/bold]"
                        )
                        return None
        conf.output_path = existing

    # Early validation for COV method
    if conf.method == "cov" and "covariance" not in conf.sampling_kwargs:
        console.print(
            "[bold red]Covariance required for method COV.[/bold red]\n"
            "Provide a covariance via [cyan]--cov path/to/cov.npz[/cyan] or set [cyan]samples.covmat[/cyan] in the YAML.\n"
            "Supported formats: .npz (with 'covariance' and optional 'mean'), .npy, .txt/.dat, .csv."
        )
        return None

    io.print_generate_summary(conf, console, lmin=options.lmin)

    if options.dry_run:
        console.print(
            "[bold yellow]DRY-RUN[/bold yellow]: Configuration printed. No data was generated."
        )
        return None

    console.print("[bold cyan]Generating training data...[/bold cyan]")
    result = compute_dataset(conf, seed=None, console=console)
    saved_path = save_dataset(result, conf.output_path)

    io.print_result_summary(result, console, saved_path=saved_path)
    return saved_path


@app.cell
def _():
    return


@app.cell
def _():
    # run(options=Options('example.yaml',N=10,out='output_data/',dry_run=True),console=Console())
    return


@app.cell
def _():
    # mo.ui.dataframe(df=pd.Data)
    # load_info("example.yaml")
    return


@app.cell
def _(mo):
    def user_interface():
        info = """#Generate the training data for the emulators

        This module generates training data based on a given cosmological model.  The generated data can be used for training emulators or for other analyses.

        /// details | Details on how to use
        ##Usage

        To use this module, you can run it as a script or import it as a module in your Python code. The main function `run` takes several parameters to customize the data generation process. 

        ###Parameters 

        - `info`: Path to the cosmological model info file.
        - `out`: Output path for the generated data.
        - `n`: Number of training datasets to generate.
        - `observables`: List of observables to include (e.g., TT, TE, EE, mPk).
        - `lmin`: Minimum multipole moment.
        - `lmax`: Maximum multipole moment. 

        ###Example 

        ```python 
        from generate import run run(info='model_info.json', out='training_data/', n=100, observables=['TT', 'EE'], lmin=2, lmax=2000)
        ```

        """
        interface = mo.vstack(
            [
                mo.md(info),
                mo.ui.file_browser(
                    filetypes=[".json", ".yaml", ".yml"],
                    label="Cosmological Model Info File",
                ),
                mo.ui.text(label="Output Path", placeholder="training_data/"),
                mo.ui.slider(
                    label="Number of Datasets", start=1, stop=1000, step=1, value=50
                ),
                mo.ui.multiselect(
                    label="Observables",
                    options=["TT", "TE", "EE", "BB", "mPk"],
                    value=["TT", "TE", "EE", "mPk"],
                ),
                mo.ui.slider(
                    label=r"$\ell_{\rm min}$", start=2, stop=3000, step=1, value=2
                ),
                mo.ui.slider(
                    label="Maximum Multipole Moment (lmax)",
                    start=2,
                    stop=5000,
                    step=1,
                    value=2500,
                ),
                mo.ui.button(label="Run Data Generation"),
            ]
        )

        # if mo.app_meta().mode=='run':
        #     return interface
        # else:
        #     pass

        return interface

    return (user_interface,)


@app.cell
def _(user_interface):
    interface = user_interface()
    interface
    return


@app.cell
def _():
    # if mo.app_meta().mode=='run':
    #     user_interface()
    return


@app.cell
def _():
    import marimo as mo
    from typer import Typer

    tapp = Typer()
    return mo, tapp


@app.cell
def _(mo, tapp):
    if mo.app_meta().mode == "script":
        tapp()
    return


if __name__ == "__main__":
    app.run()
