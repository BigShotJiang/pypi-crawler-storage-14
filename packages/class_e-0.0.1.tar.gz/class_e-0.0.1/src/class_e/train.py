import marimo

__generated_with = "0.17.5"
app = marimo.App(width="full")

with app.setup:
    # Initialization code that runs before all other cells
    import numpy as np
    import marimo as mo
    from dataclasses import dataclass
    from rich.console import Console
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_absolute_percentage_error
    from typing import List

    from class_e.stats.gp import GaussianProcessPCA, Config
    from class_e.inspect import load_dataset
    from class_e.utils.mo import get_progress_bar as progress_bar
    from class_e.utils.mo import get_df

    _spectra = {"PP": "Cpp", "TT": "Ctt", "TE": "Cte", "EE": "Cee"}


@app.function
def load(path: str | None = None, console=None):
    # Load dataset
    ds = None
    try:
        if path:
            ds = load_dataset(path)
        else:
            # Try default filename in training_data
            ds = load_dataset("data.npz")
    except Exception as e:
        if console:
            console.print(f"[red]Failed to load dataset: {e}[/red]")
        return None, None

    if ds is None:
        if console:
            console.print("[yellow]No dataset found; aborting training.[/yellow]")
        return None, None

    return ds


@app.class_definition
@dataclass
class TrainingSet:
    path: str

    def __post_init__(self):
        self.data = self.load(self.path, console=Console())
        self._df = get_df(self.data)

    @classmethod
    def load(cls, path: str | None = None, console=None):
        # Load dataset
        ds = None
        try:
            if path:
                ds = load_dataset(path)
            else:
                # Try default filename in training_data
                ds = load_dataset("data.npz")
        except Exception as e:
            if console:
                console.print(f"[red]Failed to load dataset: {e}[/red]")
            return None, None

        if ds is None:
            if console:
                console.print("[yellow]No dataset found; aborting training.[/yellow]")
            return None, None

        return ds

    @property
    def df(self):
        return self._df

    @property
    def names(self):
        return self.data["names"]

    @property
    def theta(self):
        return self.data["theta"]

    @property
    def bounds(self):
        return {
            name: bound for name, bound in zip(self.data["names"], self.data["bounds"])
        }

    @property
    def observables(self):
        return list(self.data["observables"].tolist().keys())

    def summary(self):
        return mo.md(f"""
        **Dataset Summary** \n
        Emulated observables: {self.observables}
        """)


@app.class_definition
@dataclass
class Options:
    """Options for training runs.

    Fields mirror the TrainUI values so CLI or interactive UI can both populate
    the same configuration object.
    """

    dataset: str | None = None
    N_PCA: int = 12
    test_fraction: float = 0.2
    log_space: bool = True
    length_scale: float = 1.0
    standardize_X: bool = True
    out: str | None = None


@app.cell
def _(selected_file):
    data = TrainingSet(selected_file.path(0))
    data.summary()
    return (data,)


@app.function
def run(dataset: str | TrainingSet, settings: List[Options], console=None):
    """Train emulators using options from CLI or UI.

    Returns a tuple (emulators, rel_errors) on success, or None on failure.
    """
    ds = dataset if isinstance(dataset, TrainingSet) else TrainingSet(dataset)
    emulators = {}
    rel_errors = {}

    # Observables list from new dictionary structure
    observables = ds.observables

    for obs in progress_bar(observables, text="Training Emulators"):
        data = ds.data["observables"].item()
        training_data = data[obs]

        if training_data is None:
            if console:
                console.print(
                    f"[yellow]Skipping {obs}: no data found in dataset.[/yellow]"
                )
            continue

        options = settings[observables.index(obs)]
        # Split and train
        Xtr, Xte, Ytr, Yte = train_test_split(
            ds.theta, training_data, test_size=options.test_fraction, random_state=42
        )
        cfg = Config(
            n_components=min(options.N_PCA, Ytr.shape[1]),
            log_space=options.log_space,
            standardize_X=options.standardize_X,
        )
        emu = GaussianProcessPCA(cfg)
        _ = emu.fit(Xtr, Ytr)
        Yhat = emu.predict(Xte)
        emulators[obs] = emu
        rel = np.abs((Yhat - Yte) / np.clip(Yte, 1e-30, None))
        if console:
            mape = float(
                mean_absolute_percentage_error(Yte, np.clip(Yhat, 1e-30, None))
            )
            console.print(
                f"Mean Absolute Percentage Error (MAPE) for {obs}: {mape:.6g}"
            )
        rel_errors[obs] = rel

    # Optionally save trained emulators (not implemented: model serialization is dependent on GP impl)
    return emulators, rel_errors


@app.cell
def _():
    mo.md(r"""
    # Training the emulators
    """)
    return


@app.cell
def _():
    selected_file = mo.ui.file_browser(
        "training_data", label="Available Datasets", multiple=True
    )
    selected_file
    return (selected_file,)


@app.cell
def _(TrainUI, data):
    UIs = {obs: TrainUI() for obs in data.observables}
    tabs_content = {obs: UIs[obs].get(obs) for obs in data.observables}
    mo.ui.tabs(tabs_content)
    return (UIs,)


@app.cell
def _(run_button):
    run_button
    return


@app.cell
def _(UIs, data):
    list_options = [UIs[obs] for obs in data.observables]
    # list_options
    return (list_options,)


@app.cell
def _(list_options, run_button, selected_file):
    if run_button.value:
        emulators, rel_errors = run(
            selected_file.path(0), list_options, console=Console()
        )

    return


@app.cell
def _():
    from class_e.utils.mo import TrainUI

    ui = TrainUI()
    return (TrainUI,)


@app.cell
def _():
    run_button = mo.ui.button(label="Train Emulators", value=True, kind="success")
    return (run_button,)


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
