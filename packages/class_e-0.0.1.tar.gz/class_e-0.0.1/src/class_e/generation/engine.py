from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
from rich.progress import (
    Progress,
    BarColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
    MofNCompleteColumn,
    SpinnerColumn,
    TextColumn,
)


from class_e.core.boltzmann import get_observables
from class_e.utils.yml import load_yaml
from class_e.sampling import (
    LatinHyperCube,
    LatinHyperSphere,
    CovarianceAwareLatinHyperCube,
)
from class_e.core.cosmo_factory import load_cosmology_from_yaml


@dataclass
class GenerationConfig:
    yaml_path: Path
    bounds: Dict[str, Tuple[float, float]]
    observables: List[str]
    lmax: int
    lensed: bool
    k_values: Optional[np.ndarray]
    z_values: Optional[np.ndarray]
    n_samples: int
    method: str
    sampling_kwargs: Dict[str, Any]
    output_path: Path
    model_name: str


def parse_config(yaml_path: str | Path) -> GenerationConfig:
    cfg_path = Path(yaml_path)
    data = load_yaml(cfg_path)

    # Parameters/bounds
    params = data.get("parameters", {})
    bounds: Dict[str, Tuple[float, float]] = {}
    for name, spec in params.items():
        if isinstance(spec, (list, tuple)) and len(spec) == 2:
            bounds[name] = (float(spec[0]), float(spec[1]))
        elif isinstance(spec, dict) and "min" in spec and "max" in spec:
            bounds[name] = (float(spec["min"]), float(spec["max"]))
        else:
            # skip fixed/derived for sampling purposes
            continue

    # Observables from theory.classy.extra_args.output or default
    extra = (data.get("theory", {}) or {}).get("classy", {}).get("extra_args", {})
    output_flag = str(extra.get("output", "tCl,pCl,mPk"))
    # Map output flag to observables defaults; user can override later using UI/CLI
    observables = []
    if any(x in output_flag for x in ("tCl", "pCl")):
        observables.extend(["TT", "TE", "EE"])  # default set
    if "lCl" in output_flag:
        observables.append("PP")
    if "mPk" in output_flag:
        observables.append("mPk")
    if not observables:
        observables = ["TT", "TE", "EE", "mPk"]

    lmax = int(extra.get("l_max_scalars", 2500))
    lensed_flag = str(extra.get("lensing", "yes")).lower()
    lensed = lensed_flag in ("yes", "true", "1")

    # k and z grids from yaml if provided
    z_pk = extra.get("z_pk")
    if isinstance(z_pk, str):
        z_values = np.array([float(s) for s in z_pk.split(",") if s.strip()])
    elif isinstance(z_pk, (list, tuple, np.ndarray)):
        z_values = np.array(z_pk, dtype=float)
    else:
        z_values = None

    # k grid: not typically in YAML; leave None, engine will default when computing
    k_values = None

    # Sampling
    samples = data.get("samples", {})
    n_samples = int(samples.get("N", 50))
    method = str(samples.get("method", "LHC")).lower()
    sampling_kwargs: Dict[str, Any] = {}
    if method == "cov":
        cov_path = samples.get("covmat")
        if cov_path:
            arr = np.load(cov_path, allow_pickle=True)
            if "covariance" in arr:
                sampling_kwargs["covariance"] = arr["covariance"]
                if "mean" in arr:
                    sampling_kwargs["mean"] = arr["mean"]

    # Output
    out = data.get("output", {})
    model_name = str(out.get("model_name", "model"))
    default_out = Path("training_data") / f"{model_name}/data.npz"
    output_path = Path(out.get("path", default_out))

    return GenerationConfig(
        yaml_path=cfg_path,
        bounds=bounds,
        observables=observables,
        lmax=lmax,
        lensed=lensed,
        k_values=k_values,
        z_values=z_values,
        n_samples=n_samples,
        method=method,
        sampling_kwargs=sampling_kwargs,
        output_path=output_path,
        model_name=model_name,
    )


def _make_sampler(
    bounds: Dict[str, Tuple[float, float]],
    method: str,
    seed: Optional[int] = None,
    **kwargs,
):
    from class_e.core.parameters import Parameter

    ranges = [Parameter(k, min=v[0], max=v[1]) for k, v in bounds.items()]
    if method.lower() == "lhc":
        return LatinHyperCube(ranges, seed)
    if method.lower() == "lhs":
        sampling_type = kwargs.get("sampling_type", "surface")
        return LatinHyperSphere(ranges, seed, sampling_type=sampling_type)
    if method.lower() == "cov":
        if "covariance" not in kwargs:
            raise ValueError("Covariance matrix required for method='cov'")
        return CovarianceAwareLatinHyperCube(
            ranges, covariance=kwargs["covariance"], mean=kwargs.get("mean"), seed=seed
        )
    raise ValueError(f"Unknown sampling method: {method}")


@dataclass
class TrainingData:
    theta: np.ndarray  # (N, D)
    names: List[str]
    ell: Optional[np.ndarray]  # (L,)
    k: Optional[np.ndarray]  # (K,)
    z: Optional[np.ndarray]  # (Z,)
    cls: Dict[str, np.ndarray]  # keys among 'tt','te','ee','pp' -> (N,L)
    pk: Optional[np.ndarray]  # (N,Z,K) if requested
    meta: Dict[str, Any]


def _allocate_storage(
    N: int,
    observables: Sequence[str],
    ell_len: Optional[int],
    z_len: Optional[int],
    k_len: Optional[int],
) -> Dict[str, Any]:
    obs_set = {o.upper() for o in observables}
    out: Dict[str, Any] = {"cls": {}}
    if any(o in obs_set for o in ("TT", "TE", "EE", "PP")) and ell_len:
        if "TT" in obs_set:
            out["cls"]["tt"] = np.zeros((N, ell_len), dtype=float)
        if "TE" in obs_set:
            out["cls"]["te"] = np.zeros((N, ell_len), dtype=float)
        if "EE" in obs_set:
            out["cls"]["ee"] = np.zeros((N, ell_len), dtype=float)
        if "PP" in obs_set:
            out["cls"]["pp"] = np.zeros((N, ell_len), dtype=float)
    if "MPK" in obs_set and z_len and k_len:
        out["pk"] = np.zeros((N, z_len, k_len), dtype=float)
    else:
        out["pk"] = None
    return out


def compute_dataset(
    conf: GenerationConfig,
    seed: Optional[int] = None,
    console: Any = None,
) -> TrainingData:
    """Compute a training dataset (serial only)."""
    # Build model class from YAML for to_class() mapping
    Model = load_cosmology_from_yaml(conf.yaml_path)

    # Build sampler and generate all samples
    sampler = _make_sampler(conf.bounds, conf.method, seed=seed, **conf.sampling_kwargs)
    theta_all, names = sampler.sample(conf.n_samples)
    my_idx = np.arange(conf.n_samples)
    theta_chunk = theta_all

    # Probe first item to determine grids (ell/k/z sizes)
    probe_params = Model(**{n: float(theta_all[0, i]) for i, n in enumerate(names)})
    probe = get_observables(
        probe_params,
        observables=conf.observables,
        lmax=conf.lmax,
        lensed=conf.lensed,
        k_values=conf.k_values,
        z_values=conf.z_values,
    )
    ell = probe.get("ell")
    k = probe.get("k")
    z = probe.get("z")
    ell_len = int(ell.size) if ell is not None else None
    k_len = int(k.size) if k is not None else None
    z_len = int(z.size) if z is not None else None

    # Allocate storage
    local = _allocate_storage(len(my_idx), conf.observables, ell_len, z_len, k_len)

    # Compute loop with progress display
    t0 = time.time()
    show_progress = console is not None
    if show_progress:
        columns = (
            TextColumn("[bold cyan]Computing observables[/bold cyan]", justify="right"),
            SpinnerColumn(style="cyan"),
            BarColumn(bar_width=None),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
        )
        with Progress(*columns, transient=True, console=console) as progress:
            task = progress.add_task("generate", total=len(my_idx))
            for j, idx in enumerate(my_idx):
                pars = {names[i]: float(theta_chunk[j, i]) for i in range(len(names))}
                params = Model(**pars)
                obs = get_observables(
                    params,
                    observables=conf.observables,
                    lmax=conf.lmax,
                    lensed=conf.lensed,
                    k_values=conf.k_values,
                    z_values=conf.z_values,
                )
                # Fill cls
                for key in ("tt", "te", "ee", "pp"):
                    if key in local["cls"] and key in obs:
                        local["cls"][key][j, :] = obs[key]
                # Fill pk
                if local["pk"] is not None and "pk" in obs:
                    local["pk"][j, :, :] = obs["pk"]
                progress.advance(task, 1)
    else:
        for j, idx in enumerate(my_idx):
            pars = {names[i]: float(theta_chunk[j, i]) for i in range(len(names))}
            params = Model(**pars)
            obs = get_observables(
                params,
                observables=conf.observables,
                lmax=conf.lmax,
                lensed=conf.lensed,
                k_values=conf.k_values,
                z_values=conf.z_values,
            )
            # Fill cls
            for key in ("tt", "te", "ee", "pp"):
                if key in local["cls"] and key in obs:
                    local["cls"][key][j, :] = obs[key]
            # Fill pk
            if local["pk"] is not None and "pk" in obs:
                local["pk"][j, :, :] = obs["pk"]

    elapsed = time.time() - t0

    # Build result
    meta = {
        "model_name": conf.model_name,
        "observables": conf.observables,
        "n_samples": conf.n_samples,
        "method": conf.method,
        "bounds": conf.bounds,
        "elapsed_sec": elapsed,
        "yaml_path": str(conf.yaml_path),
        "lmax": conf.lmax,
        "lensed": conf.lensed,
    }

    return TrainingData(
        theta=theta_all,
        names=names,
        ell=ell,
        k=k,
        z=z,
        cls=local["cls"],
        pk=local["pk"],
        meta=meta,
    )


def save_dataset(result: TrainingData, out_path: str | Path) -> Path:
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    save_dict: Dict[str, Any] = {
        "theta": result.theta,
        "names": np.array(result.names, dtype=object),
        "ell": result.ell,
        "k": result.k,
        "z": result.z,
    }

    # Save bounds as a list of (min, max) tuples aligned to 'names' order
    bounds_dict = result.meta.get("bounds") if isinstance(result.meta, dict) else None
    if isinstance(bounds_dict, dict) and result.names:
        ordered_bounds = [tuple(bounds_dict[name]) for name in result.names]
        save_dict["bounds"] = np.array(ordered_bounds, dtype=object)

    # Store observables in a structured way (nested only)
    save_dict["observables"] = {}
    # C_ell observables
    for obs in ["TT", "TE", "EE", "PP"]:
        key = obs.lower()
        if key in result.cls:
            save_dict["observables"][obs] = result.cls[key]

    # Matter power spectrum (mPk)
    if result.pk is not None:
        if result.z is not None and len(result.z) > 1:
            for i, zval in enumerate(result.z):
                label = f"P(z={zval:.3g})"
                save_dict["observables"][label] = result.pk[:, i, :]
        else:
            save_dict["observables"]["mPk"] = result.pk.squeeze()

    # # Always store k and z at the top level of observables if present
    # if result.k is not None:
    #     save_dict["observables"]["k"] = result.k
    # if result.z is not None:
    #     save_dict["observables"]["z"] = result.z

    np.savez_compressed(out, **save_dict)
    # Save metadata sidecar for reproducibility and overwrite checks
    try:
        import json

        meta_path = out.with_suffix(out.suffix + ".meta.json")
        with open(meta_path, "w") as f:
            json.dump(
                result.meta,
                f,
                indent=2,
                sort_keys=True,
                default=lambda o: float(o) if hasattr(o, "__float__") else o,
            )
    except Exception:
        pass
    return out
