from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

import joblib
import numpy as np


@dataclass
class FitResult:
    ok: bool
    details: dict


class BaseEmulator(ABC):
    @abstractmethod
    def fit(
        self, X: np.ndarray, Y: np.ndarray
    ) -> FitResult:  # X: params, Y: outputs (e.g., PCs)
        ...

    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray: ...

    def save(self, path: str) -> None:
        joblib.dump(self, path)

    @staticmethod
    def load(path: str) -> "BaseEmulator":
        return joblib.load(path)
