from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, List
import numpy as np


@dataclass
class ObservablesRequest:
    observables: List[str]
    lmax: Optional[int]
    lensed: bool
    k_values: Optional[np.ndarray]
    z_values: Optional[List[float] | np.ndarray]

    def normalized(self) -> set[str]:
        return {o.upper() for o in (self.observables or [])}


@dataclass
class ObservablesResult:
    ell: Optional[np.ndarray]
    k: Optional[np.ndarray]
    z: Optional[np.ndarray]
    spectra: Dict[str, np.ndarray]  # keys: 'tt','te','ee','pp','pk'

    def has(self, key: str) -> bool:
        return key.lower() in self.spectra
