from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box
from pathlib import Path
from typing import Optional, Dict, Any, Iterable
import typer


# Find project root by walking upwards for common markers
def find_project_root(max_up: int = 5) -> Path:
    p = Path.cwd().resolve()
    for _ in range(max_up + 1):
        if (
            (p / "pyproject.toml").exists()
            or (p / ".git").exists()
            or (p / "README.md").exists()
        ):
            return p
        if p.parent == p:
            break
        p = p.parent
    return Path.cwd().resolve()


def _load_metadata(npz_path: Path) -> Optional[Dict[str, Any]]:
    """Load metadata sidecar JSON for a dataset (.npz.meta.json)."""
    try:
        import json

        meta_path = npz_path.with_suffix(npz_path.suffix + ".meta.json")
        if meta_path.exists():
            with open(meta_path, "r") as f:
                return json.load(f)
    except Exception:
        return None
    return None


def _norm_obs_list(observables: Iterable[str]) -> Iterable[str]:
    return sorted({str(o).upper() for o in observables})


def _meta_matches(meta: Dict[str, Any], expected: Dict[str, Any]) -> bool:
    """Compare dataset metadata against expected settings.

    Keys compared (if present): model_name, lmax, lensed, n_samples, method (case-insensitive),
    observables (as set, case-insensitive).
    Missing keys in metadata are treated as non-matching to avoid false positives.
    """
    try:
        if "model_name" in expected:
            if meta.get("model_name") != expected.get("model_name"):
                return False
        if "lmax" in expected:
            if int(meta.get("lmax")) != int(expected.get("lmax")):
                return False
        if "lensed" in expected:
            if bool(meta.get("lensed")) != bool(expected.get("lensed")):
                return False
        if "n_samples" in expected:
            # exact match on sample count
            if int(meta.get("n_samples")) != int(expected.get("n_samples")):
                return False
        if "observables" in expected:
            meta_obs = meta.get("observables")
            if not isinstance(meta_obs, (list, tuple)):
                return False
            if _norm_obs_list(meta_obs) != _norm_obs_list(
                expected.get("observables", [])
            ):
                return False
        if "method" in expected:
            # Compare case-insensitive
            exp_m = str(expected.get("method", "")).strip().lower()
            meta_m = str(meta.get("method", "")).strip().lower()
            if exp_m and meta_m and exp_m != meta_m:
                return False
        return True
    except Exception:
        return False


def _find_existing_dataset(
    target: Path, expected: Optional[Dict[str, Any]] = None
) -> Optional[Path]:
    """Return a matching existing dataset if found.

    Behavior:
    - If target is a file path (.npz): only return that path if it exists.
    - If target is a directory: return data.npz in it if it exists and matches expected.
      Otherwise, scan for any .npz in the directory that matches expected metadata.
      If expected is None, any existing .npz will be returned (first match).
    """
    # If target is a file path, check directly
    if target.suffix == ".npz":
        return target if target.exists() else None

    # Otherwise, treat as directory root
    root = target
    default_file = root / "data.npz"
    if default_file.exists():
        if expected is None:
            return default_file
        meta = _load_metadata(default_file)
        if meta and _meta_matches(meta, expected):
            return default_file

    # Fallback: look for any matching npz under the directory
    if root.exists() and root.is_dir():
        matches = sorted(root.glob("*.npz"))
        for cand in matches:
            if expected is None:
                return cand
            meta = _load_metadata(cand)
            if meta and _meta_matches(meta, expected):
                return cand

    return None


def _confirm_overwrite_or_skip(
    console: Console, output_path: Path, expected: Optional[Dict[str, Any]] = None
) -> bool:
    """Ask the user what to do when the output dataset already exists.

    Returns True to proceed (overwrite), False to skip generation.
    """
    console.print(
        f"[yellow]Output file already exists at[/yellow] [bold]{output_path}[/bold]"
    )
    # If expected metadata is provided, show differences to help decision
    if expected is not None:
        meta = _load_metadata(output_path)
        if meta:
            try:
                exp_m = str(expected.get("method", "")).strip().upper()
                old_m = str(meta.get("method", "")).strip().upper()
                if exp_m and old_m and exp_m != old_m:
                    console.print(
                        "[yellow]Note:[/yellow] existing dataset was generated with "
                        f"method [bold]{old_m}[/bold], current run is [bold]{exp_m}[/bold]."
                    )
                # Sample count differences
                exp_N = expected.get("n_samples")
                old_N = meta.get("n_samples")
                if exp_N is not None and old_N is not None:
                    try:
                        if int(exp_N) != int(old_N):
                            console.print(
                                "[yellow]Note:[/yellow] existing dataset has a different number of samples "
                                f"([bold]{old_N}[/bold] vs [bold]{exp_N}[/bold])."
                            )
                    except Exception:
                        pass
                exp_obs = ",".join(_norm_obs_list(expected.get("observables", [])))
                old_obs = ",".join(_norm_obs_list(meta.get("observables", [])))
                if exp_obs and old_obs and exp_obs != old_obs:
                    console.print(
                        "[yellow]Note:[/yellow] existing dataset observables differ "
                        f"([bold]{old_obs}[/bold] vs [bold]{exp_obs}[/bold])."
                    )
                if (
                    (exp_m and old_m and exp_m != old_m)
                    or (exp_obs and old_obs and exp_obs != old_obs)
                    or (
                        exp_N is not None
                        and old_N is not None
                        and str(exp_N) != str(old_N)
                    )
                ):
                    console.print(
                        "Consider using a different --out name (e.g., add a suffix) to keep datasets separate."
                    )
            except Exception:
                pass
    overwrite = typer.confirm("Overwrite existing dataset?", default=False)
    if overwrite:
        return True
    console.print("[bold]Skipping generation.[/bold]")
    return False


def welcome(version, console: Console) -> None:
    console.print(f"[bold cyan]{LOGO}[/bold cyan]")
    console.print(f"[dim]Version {version}[/dim]", justify="center")
    console.print()


def print_generate_summary(
    configuration, console: Console, lmin: Optional[int] = None
) -> None:
    # Pretty summary tables
    # 1) Parameters & bounds
    params_table = Table(title="Training Parameters", box=box.SIMPLE_HEAVY)
    params_table.add_column("Parameter", style="cyan", no_wrap=True)
    params_table.add_column("Min", justify="right")
    params_table.add_column("Max", justify="right")
    # Show in the same order the sampler will use (dict order from YAML)
    for name, (bmin, bmax) in configuration.bounds.items():
        params_table.add_row(name, f"{bmin:.6g}", f"{bmax:.6g}")

    # 2) Settings
    settings = Table.grid(expand=False)
    settings.add_column(justify="right", style="bold")
    settings.add_column()
    settings.add_row("Input YAML:", str(configuration.yaml_path))
    settings.add_row("Model Name:", configuration.model_name)
    settings.add_row("N Samples:", str(configuration.n_samples))
    settings.add_row("Sampling Method:", configuration.method.upper())
    settings.add_row("Requested Observables:", ", ".join(configuration.observables))

    # GenerationConfig currently does not carry lmin; display provided value or default 2
    display_lmin = int(lmin) if lmin is not None else 2
    settings.add_row("ℓ-range:", f"{display_lmin}–{configuration.lmax}")

    if configuration.k_values is not None:
        settings.add_row(
            "k-range:",
            f"{configuration.k_values.min():.2e} – {configuration.k_values.max():.2e} h/Mpc",
        )
    settings.add_row("Output:", str(configuration.output_path))

    console.print(
        Panel(params_table, title="[bold]Parameter Space[/bold]", border_style="cyan")
    )
    console.print(
        Panel(settings, title="[bold]Run Settings[/bold]", border_style="magenta")
    )


def print_result_summary(
    result, console: Console, saved_path: str | None = None
) -> None:
    # Result summary
    N, D = result.theta.shape if result.theta.size else (None, None)
    L = next((v.shape[1] for v in result.cls.values()), 0) if result.cls else 0
    ZK = result.pk.shape[1:] if result.pk is not None else (0, 0)

    res_table = Table(title="Dataset Summary", box=box.SIMPLE_HEAVY)
    res_table.add_column("Metric", style="bold")
    res_table.add_column("Value", justify="left")
    res_table.add_row("Samples (N)", str(N))
    res_table.add_row("Parameters (D)", str(D))
    res_table.add_row("ℓ points (L)", str(L))
    if result.pk is not None:
        res_table.add_row("z points", str(ZK[0]))
        res_table.add_row("k points", str(ZK[1]))
    res_table.add_row("File", str(saved_path))

    console.print(Panel(res_table, border_style="green"))
    console.print("[bold green]✓ Training data successfully generated.[/bold green]")


LOGO = """
    ╔═══════════════════════════════════════════════════════════════════════════════╗
    ║                                                                               ║
    ║             ██████╗██╗      █████╗ ███████╗███████╗      ███████╗             ║
    ║            ██╔════╝██║     ██╔══██╗██╔════╝██╔════╝      ██╔════╝             ║
    ║            ██║     ██║     ███████║███████╗███████╗█████╗█████╗               ║
    ║            ██║     ██║     ██╔══██║╚════██║╚════██║╚════╝██╔══╝               ║
    ║            ╚██████╗███████╗██║  ██║███████║███████║      ███████╗             ║
    ║             ╚═════╝╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝      ╚══════╝             ║
    ║                                                                               ║
    ║                       Cosmological Emulation Made Simple                      ║
    ║                                                                               ║
    ║    ════════════════════════════════════════════════════════════════════════   ║
    ║                                                                               ║
    ║    A lightweight, fast, and user-friendly emulator for the Boltzmann          ║
    ║    solver CLASS and its extensions. Train Gaussian Process emulators          ║
    ║    on CMB power spectra and matter power spectra for efficient parameter      ║
    ║    inference and forecasting.                                                 ║    
    ║                                                                               ║
    ╚═══════════════════════════════════════════════════════════════════════════════╝
"""

DESCRIPTION = """
Cosmological Emulation Made Simple \n\n

A lightweight Python package for emulating the Boltzmann solver CLASS. \n\n

Available Commands:\n\n
  • train    - Train a new emulator from scratch\n
  • generate  - Generate training data using CLASS\n
  • sample    - Sample posterior distributions with the trained emulator\n
  • info      - Get detailed information about a trained emulator\n

Use ```class-e COMMAND --help``` for more information on each command.
"""
