from __future__ import annotations
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field, field_validator


class Parameter(BaseModel):
    """Parameter definition with validation.

    Ensures that max > min and ref (if provided) is within bounds.

    Supports both keyword and positional arguments for backward compatibility:
        Parameter(name="H0", min=60.0, max=80.0)  # keyword
        Parameter("H0", min=60.0, max=80.0)       # positional name
    """

    name: str = Field(..., min_length=1, description="Parameter name")
    min: float = Field(..., description="Minimum value")
    max: float = Field(..., description="Maximum value")
    ref: float | None = Field(None, description="Optional reference value")
    latex: str = Field("", description="Optional LaTeX representation")

    def __init__(self, name=None, /, **kwargs):
        """Custom init to support positional 'name' argument for backward compatibility."""
        if name is not None:
            kwargs["name"] = name
        super().__init__(**kwargs)

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Ensure parameter name is not empty."""
        if not v or not v.strip():
            raise ValueError("Parameter name cannot be empty")
        return v.strip()

    @field_validator("max")
    @classmethod
    def validate_range(cls, v: float, info) -> float:
        """Ensure max > min."""
        if "min" in info.data and v <= info.data["min"]:
            raise ValueError(f"max ({v}) must be greater than min ({info.data['min']})")
        return v

    @field_validator("ref")
    @classmethod
    def validate_ref(cls, v: float | None, info) -> float | None:
        """Ensure ref is within [min, max] if provided."""
        if v is not None and "min" in info.data and "max" in info.data:
            min_val, max_val = info.data["min"], info.data["max"]
            if not (min_val <= v <= max_val):
                raise ValueError(
                    f"ref ({v}) must be within range [{min_val}, {max_val}]"
                )
        return v

    @property
    def low(self) -> float:
        """Alias for min (backward compatibility)."""
        return self.min

    @property
    def high(self) -> float:
        """Alias for max (backward compatibility)."""
        return self.max


def build_outputs_flag(
    lensed: bool, want_cls: bool, want_pp: bool, want_mpk: bool
) -> str:
    parts: list[str] = []
    if want_cls:
        parts.extend(["tCl", "pCl"])  # include both for simplicity
        if lensed or want_pp:
            parts.append("lCl")
    if want_mpk:
        parts.append("mPk")
    # stable order
    return ",".join(sorted(set(parts)))


def merge_class_args(
    model_args: Dict[str, Any],
    yaml_extra_args: Optional[Dict[str, Any]],
    request: Dict[str, Any],
) -> Dict[str, Any]:
    """Merge CLASS args with precedence: YAML extras > request > model.

    Ensures we don't set conflicting P_k_max variants and keeps outputs coherent.
    """
    args: Dict[str, Any] = dict(model_args or {})
    # request overlay
    args.update({k: v for k, v in request.items() if v is not None})
    # yaml extras have highest precedence
    if yaml_extra_args:
        args.update(yaml_extra_args)

    # P_k_max safety: if either variant exists, do not add/override the other
    if "P_k_max_1/Mpc" in args and "P_k_max_h/Mpc" in args:
        # Keep what user provided; prefer not to alter
        pass

    return args
