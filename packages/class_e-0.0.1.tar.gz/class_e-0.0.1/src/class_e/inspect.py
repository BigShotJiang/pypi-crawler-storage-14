import marimo

__generated_with = "0.17.2"
app = marimo.App(width="full")

with app.setup:
    # Initialization code that runs before all other cells
    import os
    import glob
    import polars as pl
    import numpy as np
    from pathlib import Path
    from dataclasses import dataclass


@app.function
def get_df(data):
    return pl.DataFrame(
        {name: data["theta"][:, i] for i, name in enumerate(data["names"])}
    )


@app.class_definition
@dataclass
class TrainingSet:
    data: dict

    def __post_init__(self):
        self._df = get_df(self.data)

    @property
    def df(self):
        return self._df

    @property
    def names(self):
        return self.data["names"]

    @property
    def bounds(self):
        return {
            name: bound for name, bound in zip(self.data["names"], self.data["bounds"])
        }


@app.cell
def _(data):
    data.data.files
    return


@app.function
# Load dataset
def load_dataset(filename: str, root_dir=None):
    from class_e.core.io import find_project_root

    root = find_project_root()
    proc_dir = root / "data" / "training" if root_dir is None else root_dir

    # Prefer the canonical filename if present; otherwise pick the newest matching file
    preferred = proc_dir / filename
    candidates = []
    if preferred.exists():
        candidates = [str(preferred)]
    else:
        candidates = glob.glob(str(proc_dir / "*.npz"))
        candidates.sort(key=lambda p: os.path.getmtime(p))  # newest last

    if not candidates:
        print(
            "Cls dataset not found yet; TE/EE/PP section will be skipped until the file exists."
        )
        ds = None
        Theta_ds = None
        ell_ds = None
    else:
        ds_path = candidates[-1]
        try:
            ds = np.load(ds_path, allow_pickle=True)
            print(f"Loaded dataset: {ds_path}")
        except Exception as e:
            print(f"Failed to load {ds_path}: {e}")
            ds = None

    if ds is not None:
        Theta_ds = ds["theta"]
        names_ds = [str(x) for x in ds["names"]]
        ell_ds = ds["ell"]
        # spectra = [s.decode() if isinstance(s, (bytes, bytearray)) else str(s) for s in ds["spectra"]]
        has = {k: (k in ds.files) for k in ["tt", "te", "ee", "pp"]}
        print(
            "theta:",
            Theta_ds.shape,
            "ell:",
            ell_ds.shape,
            # "spectra:", spectra,
            "present:",
            has,
        )

    return ds


@app.cell
def _(data, mo):
    def get_summary():
        bounds = data.bounds
        names = data.names
        n_samples = len(data.df)
        summary_md = "# Dataset Summary\n"
        summary_md += f"- Number of samples: **{n_samples}**\n"
        summary_md += "- Parameter bounds:\n"
        for name in names:
            bnd = bounds[name]
            summary_md += f"  - **{name}**: [{bnd[0]:.4f}, {bnd[1]:.4f}]\n"
        return mo.md(summary_md)

    return (get_summary,)


@app.cell
def _(selected_file):
    if selected_file.value and len(selected_file.value) > 0:
        data = load_dataset(
            selected_file.value[0].name, root_dir=Path("training_data/w0waCDM/")
        )
        data = TrainingSet(data)
    else:
        data = None  # or show a message, e.g. print("No file selected.")
    return (data,)


@app.cell
def _():
    # To see what's inside the .npz file do:
    # list(data.keys())
    return


@app.cell
def _(get_summary):
    summary = get_summary()  # data.bounds
    return (summary,)


@app.cell
def _(data, mo):
    df_table = mo.ui.table(data.df)
    return (df_table,)


@app.cell
def _(mo):
    selected_file = mo.ui.file_browser(
        Path("training_data/"), label="Available Datasets", multiple=False
    )
    selected_file
    return (selected_file,)


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell
def _():
    # if mo.app_meta().mode in ['edit','run']:
    #     run_button=mo.ui.run_button(label='Run training')
    #     test_fraction=mo.ui.number(value=0.2, label='Test fraction:', start=0.1, stop=0.8, step=0.1)
    #     N_PCA=mo.ui.number(value=10, label='N_PCA:', start=2, stop=128, step=1)
    #     standardize=mo.ui.checkbox(value=True, label='Standardize X')
    #     log_space=mo.ui.checkbox(value=True, label='Train in log space')
    return


@app.cell
def _():
    # def ui():
    #     _title=mo.md("#Emulator settings")
    #     _settings=mo.hstack([test_fraction,N_PCA,standardize,log_space,run_button])
    #     return mo.vstack([_title,_settings])
    return


@app.cell
def _():
    # ui()
    return


@app.cell
def _(data, mo):
    df_de = mo.ui.data_explorer(data.df)
    return (df_de,)


@app.cell
def _(df_de, df_table, mo, summary):
    # if mo.app_meta().mode in ['edit','run']:
    mo.ui.tabs(
        label="Dataset Explorer",
        tabs={"Plots": df_de, "Table": df_table, "Summary": summary},
    )
    return


@app.cell
def _(data):
    def plot_observable(observable="tt", **plt_kwargs):
        import matplotlib.pyplot as plt

        if observable in ["tt", "te", "ee"]:
            ell = data.data["ell"]
            ell_fac = ell * (ell + 1) / (2 * np.pi)
            X, Y = ell, ell_fac.reshape(-1, 1) * data.data[observable].T

        plt.plot(X, Y, alpha=0.1, **plt_kwargs)
        return plt.gca()

    return (plot_observable,)


@app.cell
def _(plot_observable):
    plot_observable("tt", color="C0")
    return


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
