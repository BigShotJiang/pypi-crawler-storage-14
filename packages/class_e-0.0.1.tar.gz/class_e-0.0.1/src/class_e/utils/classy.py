"""Utilities for dynamically loading CLASS from custom installation paths."""

from typing import Optional, Sequence, Union, List
from pathlib import Path
import os
import sys
import re


class ClassImportError(ImportError):
    """Raised when CLASS cannot be imported from the specified path."""


def load_class_from_path(
    class_path: Union[str, Path],
    python_version: Optional[Union[str, Sequence[int]]] = None,
    verbose: bool = True,
) -> type:
    """Load the CLASS Python wrapper (classy) from a specified source path.

    This function dynamically imports the CLASS Python wrapper from a custom
    installation path, handling the common build directory structure produced
    by CLASS's setup.py.

    Parameters
    ----------
    class_path : str or Path
        Path to the CLASS source directory (e.g., /path/to/AxiCLASS).
        Should contain a 'build/' subdirectory with compiled Python wrappers.
    python_version : str or tuple, optional
        Python version to match (e.g., "3.12" or (3, 12)).
        If None, uses the current interpreter version.
    verbose : bool, default True
        If True, print confirmation message with the loaded CLASS path.

    Returns
    -------
    type
        The Class class from the classy module.

    Raises
    ------
    ClassImportError
        If CLASS cannot be imported from the specified path.
    FileNotFoundError
        If the specified class_path does not exist.

    Examples
    --------
    >>> from class_e.utils.classy import load_class_from_path
    >>> Class = load_class_from_path("/Users/user/github/AxiCLASS")
    ✓ Loaded CLASS Python wrapper from: /Users/user/github/AxiCLASS/build/lib.macosx-14.0-arm64-cpython-312

    >>> cosmo = Class()
    >>> # Use CLASS as normal...

    Notes
    -----
    This function modifies sys.path to include the CLASS build directory,
    allowing the classy module to be imported. The path is prepended to
    sys.path to ensure it takes precedence over any system-installed CLASS.
    """
    from rich.console import Console

    console = Console()

    class_path = Path(class_path).expanduser().resolve()

    if not class_path.exists():
        raise FileNotFoundError(
            f"CLASS source path not found: {class_path}\n"
            "Please verify the path in your YAML configuration under theory.classy.path"
        )

    # Find the compiled import path using the helper function
    try:
        lib_path = find_compiled_import_path(
            source_path=str(class_path),
            python_version=python_version,
            build_dir_name="build",
            require_compiled_files=True,
            compiled_extensions=(".so", ".pyd", ".dylib"),
            allow_multiple=False,
            prefer_exact_version=True,
        )
    except (CompiledImportPathError, FileNotFoundError) as e:
        raise ClassImportError(
            f"Could not find compiled CLASS Python wrapper in {class_path}/build/\n"
            f"Error: {e}\n\n"
            "Please build CLASS with Python support:\n"
            "  cd /path/to/CLASS\n"
            "  make clean\n"
            "  make\n"
            "  python setup.py build"
        ) from e

    # Add to sys.path (prepend to take precedence)
    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)

    # Try to import classy
    try:
        import classy

        Class = classy.Class
    except ImportError as e:
        raise ClassImportError(
            f"Found build directory at {lib_path} but could not import classy module.\n"
            f"Error: {e}\n\n"
            "Please ensure CLASS was built with Python support:\n"
            "  cd /path/to/CLASS\n"
            "  make clean\n"
            "  make\n"
            "  python setup.py build"
        ) from e

    if verbose:
        console.print(
            f"[green]✓[/green] Loaded CLASS Python wrapper from: [cyan]{lib_path}[/cyan]"
        )

    return Class


def load_class_from_yaml(yaml_path: Union[str, Path], verbose: bool = True) -> type:
    """Load CLASS from the path specified in a YAML configuration file.

    Convenience wrapper around load_class_from_path that reads the CLASS
    path from a YAML configuration file.

    Parameters
    ----------
    yaml_path : str or Path
        Path to YAML configuration file containing theory.classy.path
    verbose : bool, default True
        If True, print confirmation message with the loaded CLASS path.

    Returns
    -------
    type
        The Class class from the classy module.

    Raises
    ------
    ClassImportError
        If CLASS cannot be imported.
    FileNotFoundError
        If the YAML file or CLASS path does not exist.
    ValueError
        If the YAML file does not contain theory.classy.path

    Examples
    --------
    >>> from class_e.utils.classy import load_class_from_yaml
    >>> Class = load_class_from_yaml("example.yaml")
    ✓ Loaded CLASS Python wrapper from: /Users/user/github/AxiCLASS/build/lib...

    >>> cosmo = Class()
    """
    from class_e.utils.yml import load_yaml, get_nested

    config = load_yaml(yaml_path)
    class_path = get_nested(config, "theory.classy.path")

    if class_path is None:
        raise ValueError(
            f"YAML configuration {yaml_path} does not contain 'theory.classy.path'.\n"
            "Please add the path to your CLASS installation:\n"
            "  theory:\n"
            "    classy:\n"
            "      path: /path/to/CLASS"
        )

    return load_class_from_path(class_path, verbose=verbose)


class CompiledImportPathError(FileNotFoundError):
    """Raised when a suitable compiled products folder cannot be found."""


def find_compiled_import_path(
    source_path: str,
    python_version: Optional[Union[str, Sequence[int]]] = None,
    build_dir_name: str = "build",
    require_compiled_files: bool = True,
    compiled_extensions: Optional[Sequence[str]] = None,
    allow_multiple: bool = False,
    prefer_exact_version: bool = True,
) -> Union[str, List[str]]:
    """
    Find the folder under `source_path/build` that contains compiled Python extension
    wrappers (e.g. the `lib.*` directory produced by `python setup.py build` or
    `pip wheel` build steps).

    Returns the absolute path of the best-matching subdirectory (or a list of paths if
    `allow_multiple=True`).

    Improvements over a minimal implementation:
    - Robustly matches directories starting with `lib.` but tolerates many tag forms
      (e.g. `lib.linux-x86_64-3.8`, `lib.macosx-11.1-arm64-3.11`, `lib.macosx-10.9-x86_64-3.11`).
    - Accepts an explicit `python_version` to prefer (string like "3.8" or sequence (3,8)).
    - Optionally verifies that compiled extension files (.so/.pyd/.dylib) exist in the candidate.
    - Returns helpful error messages listing what was inspected.
    - Optionally returns multiple candidates instead of raising when several match.

    Parameters
    ----------
    source_path:
        Path containing the package source directory (the directory that should have a
        `build/` subdirectory).
    python_version:
        Preferred Python version to match (e.g. "3.11" or (3, 11)). If None, uses current
        interpreter version.
    build_dir_name:
        Name of the build directory (default "build").
    require_compiled_files:
        If True (default), candidate lib.* dirs are only accepted if they contain at least
        one file with an extension in `compiled_extensions` (recursively).
    compiled_extensions:
        Sequence of file extensions to look for. If None, defaults to common platform
        extensions ['.so', '.pyd', '.dylib'].
    allow_multiple:
        If True, return a list of matching directories. If False, return the single best match
        (or raise if ambiguous).
    prefer_exact_version:
        If True (default), prefer directories that explicitly include the requested
        python version in an unambiguous form (e.g. "...-3.11" or "...3.11"). Fallback to
        looser matches if no exact-match found.

    Returns
    -------
    str or list[str]
        Path(s) to the matching compiled import directory.

    Raises
    ------
    CompiledImportPathError
        If no suitable `build/lib.*` directory can be found.
    FileNotFoundError
        If `source_path` or `source_path/build` do not exist.
    """
    # Normalise inputs
    source_path = os.path.abspath(source_path)
    if not os.path.isdir(source_path):
        raise FileNotFoundError(
            f"Source path '{source_path}' not found or not a directory."
        )

    build_root = os.path.join(source_path, build_dir_name)
    if not os.path.isdir(build_root):
        raise FileNotFoundError(
            f"`{build_dir_name}` folder not found under source path '{source_path}'. "
            "Maybe compilation hasn't run or used a different build folder."
        )

    if compiled_extensions is None:
        compiled_extensions = (".so", ".pyd", ".dylib")

    # Determine target python version strings to match
    if python_version is None:
        pv_major, pv_minor = sys.version_info.major, sys.version_info.minor
    else:
        if isinstance(python_version, str):
            parts = python_version.split(".")
            pv_major, pv_minor = int(parts[0]), int(parts[1]) if len(parts) > 1 else 0
        else:
            pv_major, pv_minor = int(python_version[0]), int(python_version[1])

    exact_tokens = {f"{pv_major}.{pv_minor}", f"{pv_major}{pv_minor}"}
    # also consider "cpXY" / many packaging tags; we'll match numbers anywhere
    version_re = re.compile(rf"({pv_major}\.?{pv_minor}|{pv_major}{pv_minor})")

    # Collect candidate lib.* directories
    dir_entries = []
    for entry in os.listdir(build_root):
        p = os.path.join(build_root, entry)
        if os.path.isdir(p) and entry.startswith("lib"):
            dir_entries.append((entry, p))

    if not dir_entries:
        raise CompiledImportPathError(
            f"No directories starting with 'lib' were found in '{build_root}'. "
            f"Contents: {sorted(os.listdir(build_root))}"
        )

    # Helper: checks for compiled files recursively
    def has_compiled_files(path: str) -> bool:
        for root, _, files in os.walk(path):
            for fn in files:
                if os.path.splitext(fn)[1] in compiled_extensions:
                    return True
        return False

    # Score candidates
    scored = []
    for name, path in dir_entries:
        score = 0
        # prefer exact textual token match
        if any(tok in name for tok in exact_tokens):
            score += 100
        # prefer presence of digits matching major/minor
        if version_re.search(name):
            score += 50
        # longer names frequently contain more specific tags (platform, abi)
        score += len(name) / 100.0
        # compiled content
        compiled_ok = has_compiled_files(path) if require_compiled_files else True
        scored.append(
            {"name": name, "path": path, "score": score, "compiled": compiled_ok}
        )

    # Filter out candidates without compiled files if required
    valid = [s for s in scored if s["compiled"]]
    if not valid and require_compiled_files:
        # Provide helpful diagnostics: list candidates and whether they contained compiled files
        diag = "\n".join(
            [
                f"  - {s['name']}: compiled={'yes' if s['compiled'] else 'no'}"
                for s in scored
            ]
        )
        raise CompiledImportPathError(
            "No `lib.*` build subdirectory containing compiled extension files was found.\n"
            f"Scanned directories in '{build_root}':\n{diag}"
        )

    # If no compiled-files requirement, any candidate counts
    if not valid:
        valid = scored

    # Sort by score descending
    valid.sort(key=lambda s: s["score"], reverse=True)

    # If prefer_exact_version, try to pick only directories that contain the exact token(s)
    if prefer_exact_version:
        exact_matches = [
            s for s in valid if any(tok in s["name"] for tok in exact_tokens)
        ]
        if exact_matches:
            valid = exact_matches
            valid.sort(key=lambda s: s["score"], reverse=True)

    paths = [s["path"] for s in valid]
    if allow_multiple:
        return paths
    # If multiple remain and none is strongly preferred, return the top one but warn via exception option?
    if not paths:
        raise CompiledImportPathError(
            f"No suitable compiled import path found under '{build_root}'."
        )
    # Return top-scoring candidate
    return paths[0]
