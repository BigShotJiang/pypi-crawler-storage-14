"""Utilities for running interactive apps with Marimo."""

import typer
import marimo as mo
from rich.console import Console
from typing import Iterable, Optional
from dataclasses import dataclass


def get_df(data):
    import polars as pl

    return pl.DataFrame(
        {name: data["theta"][:, i] for i, name in enumerate(data["names"])}
    )


def get_progress_bar(iterable: Iterable, text: str = "Training emulators") -> Iterable:
    from tqdm.auto import tqdm

    if mo.app_meta().mode != "script":
        return mo.status.progress_bar(
            iterable, title=text, subtitle="This may take a while..."
        )
    return tqdm(iterable, desc=text)


def run_marimo(script, console: Console, edit: bool = False) -> None:
    import subprocess
    import shutil

    mode = "edit" if edit else "run"
    # Try to run marimo directly first
    marimo_cmd = shutil.which("marimo")

    if marimo_cmd:
        # marimo is available in PATH
        try:
            console.print("[dim]Running: marimo run generate.py[/dim]")
            subprocess.run(["marimo", mode, str(script)], check=True)
            return
        except subprocess.CalledProcessError as e:
            console.print(f"[bold red]Error running marimo: {e}[/bold red]")
            raise typer.Exit(1)
    else:
        # marimo not in PATH, try with uv
        console.print("[yellow]marimo not found in PATH, trying with uv...[/yellow]")
        uv_cmd = shutil.which("uv")

        if uv_cmd:
            try:
                console.print(
                    "[dim]Running: uv run --with marimo marimo run generate.py[/dim]"
                )
                subprocess.run(
                    [
                        "uv",
                        "run",
                        "--with",
                        "marimo",
                        "marimo",
                        mode,
                        str(script),
                    ],
                    check=True,
                )
                return
            except subprocess.CalledProcessError as e:
                console.print(f"[bold red]Error running marimo with uv: {e}[/bold red]")
                raise typer.Exit(1)
        else:
            # Neither marimo nor uv available
            console.print(
                "[bold red]Error: Neither marimo nor uv found in PATH[/bold red]"
            )
            console.print(
                "\n[yellow]To use interactive mode, you need either:[/yellow]"
            )
            console.print("  1. Install marimo: [cyan]pip install marimo[/cyan]")
            console.print(
                "  2. Install uv (recommended): [cyan]https://docs.astral.sh/uv/getting-started/installation/[/cyan]"
            )
            console.print(
                "\n[bold]Would you like to install uv now?[/bold] (Recommended)"
            )
            console.print(
                "[dim]uv is a fast Python package installer and resolver[/dim]"
            )

            install_uv = typer.confirm("Install uv?", default=False)

            if install_uv:
                console.print(
                    "\n[cyan]Please run the following command to install uv:[/cyan]"
                )
                console.print(
                    "[bold]curl -LsSf https://astral.sh/uv/install.sh | sh[/bold]"
                )
                console.print(
                    "\n[dim]After installation, restart your terminal and try again.[/dim]"
                )
            else:
                console.print(
                    "\n[yellow]Alternatively, install marimo directly:[/yellow]"
                )
                console.print("[bold]pip install marimo[/bold]")

            raise typer.Exit(1)


@dataclass
class TrainUI:
    """UI elements for training configuration in Marimo."""

    def __init__(self):
        self._PCA_ui_elements = mo.ui.dictionary(
            {
                "N_PCA": mo.ui.number(
                    label="Number of PCA components", value=12, start=1, step=1
                ),
                "test_fraction": mo.ui.number(
                    label="Test Fraction", value=0.2, start=0.0, step=0.05, stop=1.0
                ),
                "log_space": mo.ui.switch(
                    label="Work in log space for the outputs", value=True
                ),
                "standardize_X": mo.ui.switch(
                    label="Standardize the X inputs", value=True
                ),
            }
        )

        self._GP_ui_elements = mo.ui.dictionary(
            {
                "n_restarts_optimizer": mo.ui.number(
                    label="Number of Restarts", value=3, start=0, step=1
                ),
                "length_scale": mo.ui.number(
                    label="Kernel Length Scale",
                    value=1.0,
                    start=0.1,
                    step=0.1,
                    stop=3.0,
                ),
                "kernel": mo.ui.dropdown(
                    label="Kernel Type",
                    value="rbf",
                    options=[
                        "rbf",
                        "matern32",
                        "matern52",
                        "rq",
                        "periodic",
                        "quasi_periodic",
                        "linear",
                        "rbf+white",
                    ],
                ),
            }
        )

    # PCA props
    @property
    def N_PCA(self):
        return int(self._PCA_ui_elements["N_PCA"].value)

    @property
    def test_fraction(self):
        return float(self._PCA_ui_elements["test_fraction"].value)

    @property
    def log_space(self):
        return bool(self._PCA_ui_elements["log_space"].value)

    @property
    def standardize_X(self):
        return bool(self._PCA_ui_elements["standardize_X"].value)

    # GP props
    @property
    def n_restarts_optimizer(self):
        return int(self._GP_ui_elements["n_restarts_optimizer"].value)

    @property
    def length_scale(self):
        return float(self._GP_ui_elements["length_scale"].value)

    @property
    def kernel(self):
        return str(self._GP_ui_elements["kernel"].value)

    @property
    def GP(self):
        """Return the raw GP ui dictionary for advanced usage."""
        return self._GP_ui_elements

    def get(self, observable: Optional[str] = None):
        title = mo.md(
            "**Training Configuration"
            + (f" for {observable}" if observable else "")
            + "**"
        )
        body = mo.hstack(
            [self._PCA_ui_elements.vstack(), self._GP_ui_elements.vstack()]
        )
        return mo.vstack(
            [
                title,
                body,
            ]
        )

    def values(self) -> dict:
        """Return a dictionary with the current values of all UI elements."""
        return {
            "N_PCA": self.N_PCA,
            "test_fraction": self.test_fraction,
            "log_space": self.log_space,
            "standardize_X": self.standardize_X,
            "n_restarts_optimizer": self.n_restarts_optimizer,
            "length_scale": self.length_scale,
            "kernel": self.kernel,
        }
