from __future__ import annotations

"""YAML file handling utilities for class-E.

This module provides utilities for loading and manipulating YAML configuration files,
particularly for Cobaya-like parameter files and CLASS input files.

"""
import yaml
import numpy as np
from pathlib import Path
from typing import Union, Dict, Any, Optional, Tuple


def load_yaml(filepath: Union[str, Path]) -> Dict[str, Any]:
    """Load a YAML file into a Python dictionary.

    This function reads a YAML file and parses it into a Python dictionary,
    handling common YAML structures used in cosmological analysis pipelines
    like Cobaya.

    Parameters
    ----------
    filepath : str or Path
        Path to the YAML file to load.

    Returns
    -------
    dict
        Dictionary containing the parsed YAML content.

    Raises
    ------
    FileNotFoundError
        If the specified file does not exist.
    yaml.YAMLError
        If there is an error parsing the YAML file.

    Examples
    --------
    >>> config = load_yaml("input/LCDM/planck.yaml")
    >>> print(config["theory"]["classy"]["path"])
    /home/calderon/projects/EFT-class/class-eft

    >>> params = config["params"]
    >>> print(params["logA"]["prior"])
    {'min': 2.6, 'max': 3.5}
    """
    filepath = Path(filepath)

    if not filepath.exists():
        raise FileNotFoundError(f"YAML file not found: {filepath}")

    with open(filepath, "r") as f:
        YAMLError = getattr(yaml, "YAMLError", Exception)
        try:
            data = yaml.safe_load(f)
        except YAMLError as e:
            raise RuntimeError(f"Error parsing YAML file {filepath}: {e}")

    return data


def save_yaml(
    data: Dict[str, Any], filepath: Union[str, Path], sort_keys: bool = False, **kwargs
) -> None:
    """Save a Python dictionary to a YAML file.

    Parameters
    ----------
    data : dict
        Dictionary to save as YAML.
    filepath : str or Path
        Path where the YAML file should be saved.
    sort_keys : bool, optional
        Whether to sort dictionary keys in the output. Default is False.
    **kwargs
        Additional keyword arguments passed to yaml.dump().

    Examples
    --------
    >>> config = {"theory": {"classy": {"path": "/path/to/class"}}}
    >>> save_yaml(config, "output/config.yaml")
    """
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with open(filepath, "w") as f:
        yaml.dump(data, f, sort_keys=sort_keys, default_flow_style=False, **kwargs)


def get_nested(
    data: Dict[str, Any], keys: Union[str, list], default: Optional[Any] = None
) -> Any:
    """Get a value from a nested dictionary using a key path.

    Parameters
    ----------
    data : dict
        The dictionary to search.
    keys : str or list
        Either a dot-separated string (e.g., "theory.classy.path") or
        a list of keys (e.g., ["theory", "classy", "path"]).
    default : Any, optional
        Default value to return if the key path is not found.

    Returns
    -------
    Any
        The value at the specified key path, or default if not found.

    Examples
    --------
    >>> config = load_yaml("input/ACT+Planck+SPT/full-anti-pl.yaml")
    >>> path = get_nested(config, "theory.classy.path")
    >>> print(path)
    /home/calderon/projects/EFT-class/class-eft

    >>> lmax = get_nested(config, ["theory", "classy", "extra_args", "l_max_scalars"])
    >>> print(lmax)
    5000
    """
    if isinstance(keys, str):
        keys = keys.split(".")

    current = data
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default

    return current


def set_nested(data: Dict[str, Any], keys: Union[str, list], value: Any) -> None:
    """Set a value in a nested dictionary using a key path.

    Parameters
    ----------
    data : dict
        The dictionary to modify (modified in place).
    keys : str or list
        Either a dot-separated string (e.g., "theory.classy.path") or
        a list of keys (e.g., ["theory", "classy", "path"]).
    value : Any
        The value to set at the specified key path.

    Examples
    --------
    >>> config = load_yaml("input/ACT+Planck+SPT/full-anti-pl.yaml")
    >>> set_nested(config, "theory.classy.extra_args.l_max_scalars", 6000)
    >>> print(get_nested(config, "theory.classy.extra_args.l_max_scalars"))
    6000
    """
    if isinstance(keys, str):
        keys = keys.split(".")

    current = data
    for key in keys[:-1]:
        if key not in current:
            current[key] = {}
        current = current[key]

    current[keys[-1]] = value


def extract_params(
    yaml_data: Dict[str, Any], param_type: Optional[str] = None
) -> Dict[str, Any]:
    """Extract parameter definitions from a Cobaya YAML configuration.

    Parameters
    ----------
    yaml_data : dict
        The loaded YAML configuration dictionary.
    param_type : str, optional
        Filter parameters by type. Options: 'sampled' (parameters with priors),
        'derived' (derived parameters), 'fixed' (fixed value parameters).
        If None, returns all parameters.

    Returns
    -------
    dict
        Dictionary of parameter definitions.

    Examples
    --------
    >>> config = load_yaml("input/ACT+Planck+SPT/full-anti-pl.yaml")
    >>> sampled = extract_params(config, "sampled")
    >>> print(list(sampled.keys()))
    ['a_cs', 'a_1', 'a_4', 'A_cs', 'A_1', 'A_4', 'logA', 'n_s', 'H0', ...]
    """
    if "params" not in yaml_data:
        return {}

    params = yaml_data["params"]

    if param_type is None:
        return params

    filtered = {}
    for name, param_def in params.items():
        if param_def is None:
            param_def = {}

        if param_type == "sampled":
            if isinstance(param_def, dict) and "prior" in param_def:
                filtered[name] = param_def
        elif param_type == "derived":
            if isinstance(param_def, dict) and (
                "derived" in param_def
                or (
                    "value" in param_def
                    and isinstance(param_def["value"], str)
                    and "lambda" in param_def["value"]
                )
            ):
                filtered[name] = param_def
        elif param_type == "fixed":
            if (
                isinstance(param_def, dict)
                and "value" in param_def
                and not isinstance(param_def["value"], str)
            ):
                filtered[name] = param_def
            elif isinstance(param_def, (int, float)):
                filtered[name] = {"value": param_def}

    return filtered


def update_yaml(
    filepath: Union[str, Path],
    updates: Dict[str, Any],
    output_path: Optional[Union[str, Path]] = None,
) -> Dict[str, Any]:
    """Load a YAML file, update it with new values, and optionally save it.

    Parameters
    ----------
    filepath : str or Path
        Path to the YAML file to load.
    updates : dict
        Dictionary of updates. Use dot-notation keys for nested updates
        (e.g., {"theory.classy.extra_args.l_max_scalars": 6000}).
    output_path : str or Path, optional
        If provided, save the updated configuration to this path.
        If None, the original file is not modified.

    Returns
    -------
    dict
        The updated configuration dictionary.

    Examples
    --------
    >>> updates = {
    ...     "theory.classy.extra_args.l_max_scalars": 6000,
    ...     "params.logA.ref.loc": 3.050
    ... }
    >>> config = update_yaml("input/config.yaml", updates, "output/config_new.yaml")
    """
    data = load_yaml(filepath)

    for key, value in updates.items():
        set_nested(data, key, value)

    if output_path is not None:
        save_yaml(data, output_path)

    return data


def load_dataset(npz_path: str | Path) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Load a dataset .npz plus its .meta.json sidecar.

    Returns (arrays, meta) where arrays contains keys:
    - theta, names, ell, k, z, bounds (optional), observables (nested dict)
    """
    p = Path(npz_path)
    arr = np.load(p, allow_pickle=True)
    arrays: Dict[str, Any] = {k: arr[k] for k in arr.files}
    # Observables may be stored as an object dict; ensure Python dict
    if "observables" in arrays and not isinstance(arrays["observables"], dict):
        arrays["observables"] = dict(arrays["observables"].item())

    # Load metadata if available
    meta: Dict[str, Any] = {}
    try:
        import json

        meta_path = p.with_suffix(p.suffix + ".meta.json")
        if meta_path.exists():
            meta = json.load(open(meta_path, "r"))
    except Exception:
        pass
    return arrays, meta


if __name__ == "__main__":
    # Example usage
    config = load_yaml("/Users/rodrigocalderon/github/class-e/example.yaml")
    print(config)
