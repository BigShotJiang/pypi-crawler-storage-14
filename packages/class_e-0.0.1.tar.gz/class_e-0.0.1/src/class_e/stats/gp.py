import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor, kernels
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from pydantic import BaseModel, Field, field_validator

from class_e.core import BaseEmulator, FitResult


class Config(BaseModel):
    """Configuration for PCA-based GaussianProcess emulators with validation.

    Ensures all parameters are physically valid and kernel names are recognized.
    """

    n_components: int = Field(
        default=12, gt=0, le=1000, description="Number of PCA components"
    )
    length_scale: float = Field(default=1.0, gt=0, description="Kernel length scale")
    log_space: bool = Field(default=False, description="Whether to work in log space")
    log_eps: float = Field(
        default=1e-30, gt=0, description="Small epsilon for log operations"
    )
    standardize_X: bool = Field(
        default=True, description="Whether to standardize input features"
    )
    residual_mode: str = Field(
        default="none",
        pattern="^(none|log_ratio)$",
        description="Residual mode: 'none' or 'log_ratio'",
    )
    kernel: str = Field(
        default="rbf",
        description="Kernel name: 'rbf', 'matern32', 'matern52', 'rq', 'periodic', 'quasi_periodic', 'linear', 'rbf+white'",
    )
    kernel_params: dict = Field(
        default_factory=dict, description="Additional kernel parameters"
    )
    optimize_hyperparams: bool = Field(
        default=True, description="Whether to optimize GP hyperparameters"
    )
    n_restarts_optimizer: int = Field(
        default=3, ge=0, description="Number of optimizer restarts (sklearn GP)"
    )

    @field_validator("kernel")
    @classmethod
    def validate_kernel(cls, v: str) -> str:
        """Ensure kernel name is recognized."""
        valid_kernels = {
            "rbf",
            "matern32",
            "matern52",
            "rq",
            "periodic",
            "quasi_periodic",
            "linear",
            "rbf+white",
        }
        if v not in valid_kernels:
            raise ValueError(
                f"Kernel '{v}' not recognized. Valid options: {valid_kernels}"
            )
        return v


class GaussianProcessPCA(BaseEmulator):
    """Gaussian Process emulator on PCA-compressed outputs."""

    def __init__(self, config: Config | None = None) -> None:
        self.info = config or Config()
        self.pca = PCA(n_components=self.info.n_components)

        # Kernel/GPR are built at fit() time when input dimensionality is known
        self.gp = None  # type: ignore[assignment]
        self._fitted = False
        self._xscaler = StandardScaler() if self.info.standardize_X else None
        self._baseline = None  # shape (nk,)

    def set_baseline(self, Y: np.ndarray) -> None:
        """Set baseline `Y_baseline` for residual training (log-ratio), log(Y/Y_baseline)."""
        self._baseline = np.asarray(Y).reshape(-1)

    def fit(self, X: np.ndarray, Y: np.ndarray) -> FitResult:
        # Lazily construct kernel/GPR now that input dimensionality is known
        if self.gp is None:
            optimizer = None if not self.info.optimize_hyperparams else "fmin_l_bfgs_b"
            self.gp = GaussianProcessRegressor(
                kernel=self._make_kernel(input_dim=X.shape[1]),
                normalize_y=True,
                optimizer=optimizer,
                n_restarts_optimizer=int(self.info.n_restarts_optimizer),
            )
        # Optionally standardize inputs
        if self._xscaler is not None:
            Xt = self._xscaler.fit_transform(X)
        else:
            Xt = X

        # Output transform: residual log-ratio has priority
        if self.info.residual_mode == "log_ratio":
            if self._baseline is None:
                raise RuntimeError(
                    "residual_mode=log_ratio requires a baseline set via set_baseline()."
                )
            Yt = np.log(np.clip(Y / self._baseline, self.info.log_eps, None))
        elif self.info.log_space:
            Yt = np.log(np.clip(Y, self.info.log_eps, None))
        else:
            Yt = Y
        # Fit PCA on outputs (rows are samples, columns are k-modes)
        Z = self.pca.fit_transform(Yt)
        self.gp.fit(Xt, Z)
        self._fitted = True
        return FitResult(
            ok=True, details={"explained_variance": self.pca.explained_variance_ratio_}
        )

    def predict(self, X: np.ndarray) -> np.ndarray:
        if not self._fitted:
            raise RuntimeError("Emulator not fitted")
        # Standardize inputs if used during training
        if self._xscaler is not None:
            Xt = self._xscaler.transform(X)
        else:
            Xt = X
        if self.gp is None:
            raise RuntimeError("Internal error: GP not initialized")
        Zout = self.gp.predict(Xt, return_std=False)
        Zpred = Zout[0] if isinstance(Zout, tuple) else Zout
        Yt_pred = self.pca.inverse_transform(Zpred)
        if self.info.residual_mode == "log_ratio":
            if self._baseline is None:
                raise RuntimeError(
                    "Baseline missing in predict() for residual_mode=log_ratio."
                )
            return self._baseline * np.exp(np.clip(Yt_pred, a_min=-100.0, a_max=100.0))
        if self.info.log_space:
            # Inverse transform from log-space; clip to avoid overflow
            return np.exp(np.clip(Yt_pred, a_min=-100.0, a_max=100.0))
        return Yt_pred

    # --- helpers ---
    def _make_kernel(self, input_dim: int):
        p = self.info.kernel_params or {}
        amp = float(p.get("amplitude", 1.0))
        noise = float(p.get("noise", 1e-6))
        ls = float(self.info.length_scale)
        ard = bool(p.get("ard", False))
        # If ARD requested, build a vector length_scale for RBF/Matern; others use scalar
        if ard:
            ls_vec = np.full(int(input_dim), ls, dtype=float)
        else:
            ls_vec = None

        _kernels = {
            "rbf": kernels.RBF(length_scale=(ls_vec if ls_vec is not None else ls)),
            "matern32": kernels.Matern(
                length_scale=(ls_vec if ls_vec is not None else ls), nu=1.5
            ),
            "matern52": kernels.Matern(
                length_scale=(ls_vec if ls_vec is not None else ls), nu=2.5
            ),
            "rbf+white": kernels.RBF(
                length_scale=(ls_vec if ls_vec is not None else ls)
            ),
            **{
                name: kernels.DotProduct(sigma_0=float(p.get("sigma0", 1.0)))
                for name in ("linear", "dot", "dotproduct")
            },
            **{
                name: kernels.RationalQuadratic(
                    length_scale=ls, alpha=float(p.get("alpha", 1.0))
                )
                for name in ("rq", "rationalquadratic", "rational_quadratic")
            },
            **{
                name: kernels.ExpSineSquared(
                    length_scale=ls, periodicity=float(p.get("periodicity", 1.0))
                )
                for name in ("periodic", "exp_sine_squared", "expsinesquared")
            },
            **{
                name: kernels.RBF(length_scale=(ls_vec if ls_vec is not None else ls))
                * kernels.ExpSineSquared(
                    length_scale=ls, periodicity=float(p.get("periodicity", 1.0))
                )
                for name in ("quasi_periodic", "quasiperiodic", "rbf*periodic")
            },
        }

        name = (self.info.kernel or "rbf").lower()
        base = _kernels.get(name)

        k = kernels.ConstantKernel(amp, (1e-3, 1e3)) * base + kernels.WhiteKernel(
            noise_level=noise
        )
        return k
