"""MsgSpec provider for JSON serialization and deserialization."""

from anyenv.json_tools.msgspec_provider.provider import MsgSpecProvider

__all__ = ["MsgSpecProvider"]
