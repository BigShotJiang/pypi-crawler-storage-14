from .cli import cli  # pragma: no cover


if "__main__" == __name__:  # pragma: no cover
    cli()
