from flay.bundle import DEFAULT_BUNDLE_METADATA
from flay.common.logging import enable_debug_logging

from flay.common.pydantic import FlayBaseSettings

import os
from pydantic import Field, AliasChoices
from pathlib import Path
import typing as t
from .bundle import cli_bundle_package
from .treeshake import cli_treeshake_package
from flay.common.rich import console, check
from .debug import debug_app
import click
from clonf.integrations.click import clonf_click
from clonf import CliArgument, CliOption
import click


class DebugSetting(FlayBaseSettings):
    debug: t.Annotated[
        bool, CliOption(is_flag=True), Field(description="Enable debug logging")
    ] = False


@click.group()
@clonf_click
def flay(debug_setting: DebugSetting) -> None:
    if debug_setting.debug:  # pragma: no cover
        enable_debug_logging()


class FlayMainSettings(FlayBaseSettings):
    module_spec: t.Annotated[
        str,
        CliArgument(),
        Field(description="Module that should be bundled"),
    ]
    output_path: t.Annotated[
        Path,
        CliOption(),
        Field(
            description="Target path for the generated bundle",
            alias="output-path",
            validation_alias=AliasChoices("output", "o"),
        ),
    ] = Path("flayed")
    bundle_metadata: t.Annotated[
        bool,
        CliOption(is_flag=True),
        Field(
            description="Whether package metadata should be collocated with the generated bundle",
            alias="bundle-metadata/--no-bundle-metadata",
            validation_alias=AliasChoices("bundle-metadata", "bundle_metadata"),
        ),
    ] = DEFAULT_BUNDLE_METADATA

    treeshake: t.Annotated[
        bool,
        CliOption(),
        Field(
            description="Should unused source code be stripped from the bundle?",
        ),
    ] = True
    resources: t.Annotated[
        dict[str, str],
        CliOption(),
        Field(
            description="Resources that should be bundled. Accepts a mapping with a module name as key and a glob pattern as value",
            default_factory=dict,
        ),
    ]
    import_aliases: t.Annotated[
        dict[str, str],
        CliOption(),
        Field(
            alias="import-aliases",
            description="Import aliases mapping. Useful for patching dynamic imports. Absolute paths for symbols are required.",
            default_factory=dict,
        ),
    ]
    preserve_symbols: t.Annotated[
        list[str],
        CliOption(),
        Field(
            alias="preserve-symbols",
            description="List of symbols that should be preserved at all cost. Absolute paths are required.",
            default_factory=list,
        ),
    ]
    safe_decorators: t.Annotated[
        list[str],
        CliOption(),
        Field(
            alias="safe-decorators",
            description="A list of decorators without side-effects that can be safely removed. Absolute paths are required.",
            default_factory=list,
        ),
    ]


@flay.command(name="bundle")
@clonf_click
def flay_main(settings: FlayMainSettings) -> None:
    console.print(f"Starting to bundle module {settings.module_spec}...")
    cli_bundle_package(
        module_spec=settings.module_spec,
        output_path=settings.output_path,
        bundle_metadata=settings.bundle_metadata,
        resources=settings.resources,
        import_aliases=settings.import_aliases,
    )
    console.print(check, f"Finished bundling {settings.module_spec}")
    if settings.treeshake:
        console.print("Start removing unused code...")

        removed_stmts_count = cli_treeshake_package(
            source_dir=str(settings.output_path.absolute()),
            import_aliases=settings.import_aliases,
            preserve_symbols=set(settings.preserve_symbols),
            safe_decorators=set(settings.safe_decorators),
        )
        console.print(
            check,
            f"Finished removing unused code. Removed {removed_stmts_count} statements in total",
        )


if os.getenv("FLAY_DEBUG_APP"):
    flay.add_command(debug_app)
