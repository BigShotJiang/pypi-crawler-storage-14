class FlayError(Exception):
    pass


class FlayFileNotFoundError(FlayError):
    pass
