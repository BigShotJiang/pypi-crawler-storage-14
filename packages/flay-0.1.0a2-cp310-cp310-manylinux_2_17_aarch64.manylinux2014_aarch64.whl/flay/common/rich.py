from __future__ import annotations
from rich.console import Console
from rich.style import Style
from rich.text import Text


console = Console()


check = Text("✔", style=Style(color="green"))
