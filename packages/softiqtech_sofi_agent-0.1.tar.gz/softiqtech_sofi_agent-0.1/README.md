# SoftiqTech Sofi Agent

**SoftiqTech Sofi Agent** is a Python package that provides a ready-to-use web assistant interface built with FastAPI for the backend and a static frontend, including interactive 3D assets. This package is designed to help developers quickly integrate a web-based assistant or demo application into their projects.

---

## Features

- ✅ FastAPI backend for serving APIs and static frontend.
- ✅ Pre-built frontend served from `frontend_build` folder.
- ✅ 3D interactive assets (like `kawaii_cute_flying_robot`) integrated with the frontend.
- ✅ Easy mounting of frontend and static assets using a single function.
- ✅ Works out-of-the-box after installation via PyPI.
- ✅ Lightweight and modular, ready to be extended for AI agents or assistant applications.

---

## Installation

You can install the package directly from PyPI:

```bash
pip install softiqTech-sofi-agent

When you install the package using pip, automatically the following packages are installed:
1) FastApi
2) uvicorn
3) openai-agents
