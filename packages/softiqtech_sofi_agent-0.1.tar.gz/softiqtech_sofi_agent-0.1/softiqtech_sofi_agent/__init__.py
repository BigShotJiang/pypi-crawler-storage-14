# Sofi/__init__.py
"""
Package initializer for Softiqtech_sofi_agent.

This file makes the package importable *without changing your existing api.py* which
uses bare imports like `from data import website_data`.
It maps package submodules to top-level names so those bare imports succeed.

Caveat: this is a compatibility shim. Long-term prefer using relative imports
inside api.py: `from .data import website_data`, etc.
"""

from importlib import import_module
import sys
from pathlib import Path
from .api import mount_frontend

# Package metadata
__name__ = "Softiqtecg_sofi_agent"
__version__ = "0.1"

# List of internal submodules that api.py expects as bare top-level names.
# Add any other module names that are imported bare inside your files.
_SUBMODULES_TO_ALIAS = [
    "data",
    "agent",
    "utils",
    "connection",
    "project_data",
    "python-dotenv",
    ".env"
    # add other module names as needed, e.g. "assistant" if imported directly
]

# Import the corresponding submodule from this package and alias it into sys.modules
for short_name in _SUBMODULES_TO_ALIAS:
    try:
        # import Sofi.<short_name> (relative to this package)
        full_mod_name = f"{__name__}.{short_name}"
        mod = import_module(full_mod_name)
        # alias it as a top-level module so "from data import ..." works
        if short_name not in sys.modules:
            sys.modules[short_name] = mod
    except Exception:
        # Do not fail import of package; if a submodule is missing, let it raise later
        # when api.py actually tries to import it.
        pass

# Re-export the FastAPI `app` so users can do `from Sofi import app`
try:
    # import the api module (this runs your api.py)
    from . import api as _api  # noqa: E402,F401
    # expose app directly on package
    app = getattr(_api, "app", None)
except Exception:
    # If importing api raises, don't crash package import; user will see error when they try to use it.
    app = None

# Convenience re-exports (optional)
# if you want to make assistant, website_data etc available as package attributes:
try:
    from .data import website_data as website_data  # type: ignore
except Exception:
    website_data = None

try:
    # If agent exports assistant
    from .agent import assistant as assistant  # type: ignore
except Exception:
    assistant = None

__all__ = ["app", "website_data", "assistant", "__version__"]
