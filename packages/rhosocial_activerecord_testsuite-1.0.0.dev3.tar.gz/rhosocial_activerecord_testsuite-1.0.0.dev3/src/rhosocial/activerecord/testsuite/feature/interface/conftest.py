# src/rhosocial/activerecord/testsuite/feature/interface/conftest.py
"""pytest configuration for interface tests.

This file provides pytest fixtures for the interface feature tests.
Even though it might seem empty, it's an important part of the test
discovery process.
"""
