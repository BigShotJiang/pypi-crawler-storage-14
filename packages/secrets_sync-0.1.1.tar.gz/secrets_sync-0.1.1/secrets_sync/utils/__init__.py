"""Utility helpers for secrets-sync."""
