"""Source implementations for secrets-sync."""

from .base import build_source

__all__ = ["build_source"]
