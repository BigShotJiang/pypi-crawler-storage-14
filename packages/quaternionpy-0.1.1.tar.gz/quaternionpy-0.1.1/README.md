# quad
A simple definition for quaternions.
Just a random dude's first time at implementing quaternions (from scratch). Expect errors, and please create an issue if there's a detrimental one.