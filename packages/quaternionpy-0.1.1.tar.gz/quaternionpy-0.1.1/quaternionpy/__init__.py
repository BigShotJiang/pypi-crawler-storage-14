"""# quad
A simple library for quaternions.
This library (if you can even call it that), contains only 1 file, which contains the only class definition, for `Quaternion`.
"""

from .quad import Quaternion
