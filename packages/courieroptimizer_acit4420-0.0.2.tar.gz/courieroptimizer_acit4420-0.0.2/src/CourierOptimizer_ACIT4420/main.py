from . import optimizer

print("\nCourier Optimizer module begun")
print("Input a depot, then create the route based on chosen mode and criterion")
print("Customer information is stored within input.csv")
while True:
    print("\nEnter the number of the option to continue")
    print("1. Input Depot")
    print("2. Start Route")
    print("3. Quit")
    answer = input()

    # default values in case user goes straight to start route
    inputted_depot = {'customer': 'near oslo', 'latitude': '60',
                             'longitude': '11', 'priority': 'medium', 'weight_kg': '0'}

    if answer == "1":
        print("Provide name of location of the Depot")
        print("Default name is: near oslo")
        inputted_depot['customer'] = input()

        print("Provide latitude of the Depot")
        print("Default latitude is: 60")
        inputted_depot['latitude'] = input()

        print("Provide longitude of the Depot")
        print("Default longitude is: 11")
        inputted_depot['longitude'] = input()

    elif answer == "2":
        modeValidity = False
        while not modeValidity:
            print("Provide chosen mode")
            print("options are: car, bicycle, walking")
            mode = input()
            if not re.match(r'^(car|bicycle|walking)$', mode):
                print("Must input a valid mode")
            else:
                modeValidity = True

        criterionValidity = False
        while not criterionValidity:
            print("Provide chosen criterion")
            print("options are:")
            print("1 for fastest total time")
            print("2 lowest total cost")
            print("3 for lowest total CO2 emission")
            criterion = input()
            if not re.match(r'^([123])$', criterion):
                print("Must input a valid criterion")
            else:
                criterionValidity = True

        optimizer.route_creator(mode, criterion, inputted_depot)
    elif answer == "3":
        exit(0)
    else:
        print("Invalid input, try again")