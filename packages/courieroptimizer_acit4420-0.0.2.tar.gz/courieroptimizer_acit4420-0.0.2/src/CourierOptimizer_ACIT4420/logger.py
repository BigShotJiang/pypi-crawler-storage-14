# logger.py
import datetime
import time

# https://www.geeksforgeeks.org/python/timing-functions-with-decorators-python/

def timing_decorator(function):
    def wrapper(*args, **kwargs):
        t1 = time.time()
        result = function(*args, **kwargs)
        t2 = time.time()
        print(f'Function {function.__name__!r} executed in {(t2-t1):.4f}s')
        with open("output\\run.log", "a") as log_file:
            log_file.write(f"{datetime.datetime.now()} - Function {function.__name__} ran with parameters: {wrapper}\n")
        return result
    return wrapper

def log_function_called(parameters):
    with open("output\\run.log", "a") as log_file:
        log_file.write(f"{datetime.datetime.now()} - Function called with parameters: {parameters}\n")

