import csv
import re
# latitude and longitude values are from https://www.geodatos.net/en

# https://www.geeksforgeeks.org/pandas/reading-csv-files-in-python/
# https://docs.python.org/3/library/csv.html


def input_validator(row):

    try:
        temp_customer = row["customer"]
        if len(temp_customer) == 0 or temp_customer.isprintable() == False:
            print("customer name not valid")
            return False

        try:
            temp_latitude = float(row["latitude"])
        except Exception as e:
            print("Latitude must be a number")
            print(e)
            return False

        if  temp_latitude < -90 or temp_latitude > 90:
            print("Latitude out of range, it must be between -90 and 90")
            return False

        try:
            temp_longitude = float(row["longitude"])
        except Exception as e:
            print("Longitude must be a number")
            print(e)
            return False
        if temp_longitude <-180 or temp_longitude > 180:
            print("Longitude out of range, it must be between -180 and 180")
            return False

        temp_priority = row["priority"].lower()
        if not re.match(r'^(low|medium|high)$', temp_priority):
            print("Priority must be low or medium or high")
            return False

        try:
            temp_weight = float(row["weight_kg"])
        except Exception as e:
            print("Weight must be a number")
            print(e)
            return False
        if temp_weight < 0:
            print("Weight must be positive")
            return False

    except Exception as e:
        print("Something is unexpectedly wrong, see following error")
        print(e)
        print()
        return False

    else:
        return True

def rejector(rejected_row):

    duplicate_checker = False

    with open('input\\rejected.csv', mode='r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            if rejected_row == row:
                print("Rejected row already in rejected list")
                print()
                duplicate_checker = True
                break

    if not duplicate_checker:
        fieldnames = ['customer', 'latitude', 'longitude', 'priority', 'weight_kg']
        with open('input\\rejected.csv', 'a', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writerow(rejected_row)
            print("Rejected row added in rejected list")
            print()


def input_processor():

    customer_dictionary = {}

    with open('input\\input.csv', mode='r') as file:
        reader = csv.DictReader(file)
        row_counter = 0

        for row in reader:
            row_counter += 1
            if input_validator(row):
                customer_dictionary["stop " + str(row_counter)] = row
            else:
                print("Row " + str(row_counter) + " is Invalid, adding row to rejected.csv")
                rejector(row)

    return customer_dictionary