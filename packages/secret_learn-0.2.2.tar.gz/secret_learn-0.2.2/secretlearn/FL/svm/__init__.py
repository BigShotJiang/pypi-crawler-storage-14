"""SecretFlow svm adapters"""
