"""Test fixtures organized by layer."""
