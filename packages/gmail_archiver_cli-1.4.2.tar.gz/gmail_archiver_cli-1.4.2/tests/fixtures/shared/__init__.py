"""Fixtures for shared layer tests.

The shared layer has minimal fixtures - primarily just temp_dir from conftest.
No layer-specific fixtures are needed since shared components are pure functions.
"""
