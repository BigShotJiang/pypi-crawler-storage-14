"""Archive compression for converting mbox files to compressed formats."""

import gzip
import logging
import lzma
import mailbox
import shutil
import tempfile
import time
from compression import zstd
from dataclasses import dataclass, field
from pathlib import Path

from gmailarchiver.data.db_manager import DBManager

logger = logging.getLogger(__name__)


@dataclass
class CompressionResult:
    """Result of compressing a single file."""

    source_file: str
    dest_file: str | None
    original_size: int
    compressed_size: int
    space_saved: int
    compression_ratio: float
    success: bool
    skipped: bool = False
    skip_reason: str | None = None


@dataclass
class CompressionSummary:
    """Summary of batch compression operation."""

    files_compressed: int
    files_skipped: int
    total_files: int
    original_size: int
    compressed_size: int = 0
    estimated_compressed_size: int = 0
    space_saved: int = 0
    estimated_space_saved: int = 0
    compression_ratio: float = 0.0
    estimated_compression_ratio: float = 0.0
    execution_time_ms: float = 0.0
    file_results: list[CompressionResult] = field(default_factory=list)
    verification_passed: bool = True


class ArchiveCompressor:
    """Compress mbox archives to save disk space."""

    def __init__(self, state_db_path: str) -> None:
        """Initialize compressor with database path.

        Args:
            state_db_path: Path to state database
        """
        self.state_db_path = state_db_path

    def compress(
        self,
        files: list[str],
        format: str = "zstd",
        in_place: bool = False,
        dry_run: bool = False,
        keep_original: bool = False,
    ) -> CompressionSummary:
        """
        Compress mbox archive files.

        Args:
            files: List of mbox file paths to compress
            format: Compression format ('gzip', 'lzma', 'zstd')
            in_place: Replace original file with compressed version
            dry_run: Preview compression without actually compressing

        Returns:
            CompressionSummary with compression statistics

        Raises:
            ValueError: If files is empty or format is invalid
            FileNotFoundError: If any file doesn't exist
        """
        start_time = time.perf_counter()

        # Validate inputs
        if not files:
            raise ValueError("files cannot be empty")

        valid_formats = ("gzip", "lzma", "zstd")
        if format not in valid_formats:
            raise ValueError(
                f"Unsupported compression format: {format}. Must be one of {valid_formats}"
            )

        # Convert to paths and verify existence
        file_paths = [Path(f) for f in files]
        for file_path in file_paths:
            if not file_path.exists():
                raise FileNotFoundError(f"Archive file not found: {file_path}")

        # Process each file
        file_results: list[CompressionResult] = []
        total_original_size = 0
        total_compressed_size = 0
        total_estimated_compressed_size = 0
        files_compressed = 0
        files_skipped = 0

        db_manager = DBManager(self.state_db_path, validate_schema=False)

        try:
            for file_path in file_paths:
                result = self._compress_file(
                    file_path,
                    format,
                    in_place,
                    dry_run,
                    keep_original,
                    db_manager,
                )
                file_results.append(result)

                total_original_size += result.original_size

                if result.skipped:
                    files_skipped += 1
                else:
                    files_compressed += 1
                    if dry_run:
                        total_estimated_compressed_size += result.compressed_size
                    else:
                        total_compressed_size += result.compressed_size

            # Commit database changes if not dry run
            if not dry_run:
                db_manager.commit()
            else:
                db_manager.rollback()

            end_time = time.perf_counter()
            execution_time_ms = (end_time - start_time) * 1000

            # Calculate summary statistics
            if dry_run:
                space_saved = total_original_size - total_estimated_compressed_size
                compression_ratio = (
                    total_original_size / total_estimated_compressed_size
                    if total_estimated_compressed_size > 0
                    else 0.0
                )
                return CompressionSummary(
                    files_compressed=0,
                    files_skipped=files_skipped,
                    total_files=len(files),
                    original_size=total_original_size,
                    estimated_compressed_size=total_estimated_compressed_size,
                    estimated_space_saved=space_saved,
                    estimated_compression_ratio=compression_ratio,
                    execution_time_ms=execution_time_ms,
                    file_results=file_results,
                )
            else:
                space_saved = total_original_size - total_compressed_size
                compression_ratio = (
                    total_original_size / total_compressed_size
                    if total_compressed_size > 0
                    else 0.0
                )
                return CompressionSummary(
                    files_compressed=files_compressed,
                    files_skipped=files_skipped,
                    total_files=len(files),
                    original_size=total_original_size,
                    compressed_size=total_compressed_size,
                    space_saved=space_saved,
                    compression_ratio=compression_ratio,
                    execution_time_ms=execution_time_ms,
                    file_results=file_results,
                )

        except Exception:
            db_manager.rollback()
            raise
        finally:
            db_manager.close()

    def _compress_file(
        self,
        file_path: Path,
        format: str,
        in_place: bool,
        dry_run: bool,
        keep_original: bool,
        db_manager: DBManager,
    ) -> CompressionResult:
        """
        Compress a single file.

        Args:
            file_path: Path to file to compress
            format: Compression format
            in_place: Replace original file
            dry_run: Preview only
            db_manager: Database manager for updating paths

        Returns:
            CompressionResult for this file
        """
        original_size = file_path.stat().st_size

        # Check if already compressed
        if self._is_compressed(file_path):
            logger.info(f"Skipping already-compressed file: {file_path}")
            return CompressionResult(
                source_file=str(file_path),
                dest_file=None,
                original_size=original_size,
                compressed_size=0,
                space_saved=0,
                compression_ratio=0.0,
                success=False,
                skipped=True,
                skip_reason="Already compressed",
            )

        # Determine output path
        extension = self._get_extension(format)
        dest_path = file_path.with_suffix(file_path.suffix + extension)

        if dry_run:
            # Estimate compression size by sampling
            estimated_size = self._estimate_compressed_size(file_path, format)
            space_saved = original_size - estimated_size
            compression_ratio = original_size / estimated_size if estimated_size > 0 else 0.0

            return CompressionResult(
                source_file=str(file_path),
                dest_file=str(dest_path),
                original_size=original_size,
                compressed_size=estimated_size,
                space_saved=space_saved,
                compression_ratio=compression_ratio,
                success=True,
            )

        # Actual compression
        try:
            self._compress_file_to_dest(file_path, dest_path, format)
            compressed_size = dest_path.stat().st_size

            # Verify compressed file can be read
            if not self._verify_compressed_file(dest_path, format):
                # Cleanup and raise error
                dest_path.unlink()
                raise ValueError(f"Verification failed for {dest_path}")

            # Update database if in_place
            if in_place:
                self._update_database_paths(db_manager, str(file_path), str(dest_path))
                # Remove original file unless the caller requested to keep it
                if not keep_original:
                    file_path.unlink()

            space_saved = original_size - compressed_size
            compression_ratio = original_size / compressed_size if compressed_size > 0 else 0.0

            return CompressionResult(
                source_file=str(file_path),
                dest_file=str(dest_path),
                original_size=original_size,
                compressed_size=compressed_size,
                space_saved=space_saved,
                compression_ratio=compression_ratio,
                success=True,
            )

        except Exception as e:
            logger.error(f"Failed to compress {file_path}: {e}")
            # Cleanup partial file
            if dest_path.exists():
                dest_path.unlink()
            raise

    def _is_compressed(self, file_path: Path) -> bool:
        """Check if file is already compressed or has a compressed sibling.

        This treats files with compressed extensions as compressed, and also
        considers an uncompressed mbox "effectively compressed" if a
        corresponding compressed variant (e.g., .mbox.zst) already exists.
        """
        # Directly compressed file
        if file_path.suffix in (".gz", ".xz", ".lzma", ".zst"):
            return True

        # If a compressed sibling already exists (same base name), skip
        for ext in (".gz", ".xz", ".lzma", ".zst"):
            sibling = file_path.with_suffix(file_path.suffix + ext)
            if sibling.exists():
                return True

        return False

    def _get_extension(self, format: str) -> str:
        """Get file extension for compression format."""
        if format == "gzip":
            return ".gz"
        elif format == "lzma":
            return ".xz"
        elif format == "zstd":
            return ".zst"
        else:
            raise ValueError(f"Unknown compression format: {format}")

    def _compress_file_to_dest(self, source: Path, dest: Path, format: str) -> None:
        """
        Compress file from source to destination.

        Args:
            source: Source file path
            dest: Destination compressed file path
            format: Compression format
        """
        if format == "gzip":
            with open(source, "rb") as f_in:
                with gzip.open(dest, "wb", compresslevel=6) as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif format == "lzma":
            with open(source, "rb") as f_in:
                with lzma.open(dest, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif format == "zstd":
            with open(source, "rb") as f_in:
                with zstd.open(dest, "wb", level=3) as f_out:
                    shutil.copyfileobj(f_in, f_out)
        else:
            raise ValueError(f"Unsupported compression format: {format}")

    def _verify_compressed_file(self, file_path: Path, format: str) -> bool:
        """
        Verify compressed file can be read.

        Args:
            file_path: Path to compressed file
            format: Compression format

        Returns:
            True if file can be decompressed successfully
        """
        try:
            # Try to open and read first few bytes
            if format == "gzip":
                with gzip.open(file_path, "rb") as f:
                    f.read(1024)  # Read a small chunk
            elif format == "lzma":
                with lzma.open(file_path, "rb") as f:
                    f.read(1024)
            elif format == "zstd":
                with zstd.open(file_path, "rb") as f:
                    f.read(1024)
            else:
                return False

            # Also verify it's a valid mbox by trying to open with mailbox
            # Use temporary file for mbox verification
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp_path = Path(tmp.name)

            try:
                # Decompress to temp file
                if format == "gzip":
                    with gzip.open(file_path, "rb") as f_in:
                        with open(tmp_path, "wb") as f_out:
                            shutil.copyfileobj(f_in, f_out)
                elif format == "lzma":
                    with lzma.open(file_path, "rb") as f_in:
                        with open(tmp_path, "wb") as f_out:
                            shutil.copyfileobj(f_in, f_out)
                elif format == "zstd":
                    with zstd.open(file_path, "rb") as f_in:
                        with open(tmp_path, "wb") as f_out:
                            shutil.copyfileobj(f_in, f_out)

                # Verify it's a valid mbox
                mbox = mailbox.mbox(str(tmp_path))
                # Just check it can be opened
                _ = len(mbox)
                mbox.close()

                return True
            finally:
                # Cleanup temp file
                if tmp_path.exists():
                    tmp_path.unlink()

        except Exception as e:
            logger.error(f"Verification failed for {file_path}: {e}")
            return False

    def _estimate_compressed_size(self, file_path: Path, format: str) -> int:
        """
        Estimate compressed size by compressing a sample.

        Args:
            file_path: Path to file
            format: Compression format

        Returns:
            Estimated compressed size in bytes
        """
        # Read first 10% of file (or 1MB, whichever is smaller)
        original_size = file_path.stat().st_size
        sample_size = min(original_size // 10, 1024 * 1024)

        if sample_size == 0:
            sample_size = original_size

        # Compress sample
        with open(file_path, "rb") as f:
            sample_data = f.read(sample_size)

        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp_path = Path(tmp.name)

        try:
            if format == "gzip":
                with gzip.open(tmp_path, "wb", compresslevel=6) as f:
                    f.write(sample_data)
            elif format == "lzma":
                with lzma.open(tmp_path, "wb") as f:
                    f.write(sample_data)
            elif format == "zstd":
                with zstd.open(tmp_path, "wb", level=3) as f:
                    f.write(sample_data)

            compressed_sample_size = tmp_path.stat().st_size

            # Extrapolate to full file size.
            # On highly compressible data, the raw ratio can be extremely small,
            # which would imply unrealistically high overall compression ratios.
            raw_ratio = compressed_sample_size / sample_size if sample_size > 0 else 1.0
            # Clamp to a minimum of 0.1 so that estimated_compression_ratio
            # (original_size / estimated_size) stays within a reasonable bound (≤ 10x).
            ratio = max(raw_ratio, 0.1)
            # Also ensure we never estimate a size smaller than 1/10th of the
            # original, so the implied compression ratio stays ≤ 10x.
            min_estimated_size = max(1, (original_size + 9) // 10)
            estimated_size = max(int(original_size * ratio), min_estimated_size)

            return estimated_size
        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    def _update_database_paths(self, db_manager: DBManager, old_path: str, new_path: str) -> None:
        """
        Update database to point to new compressed file.

        Args:
            db_manager: Database manager
            old_path: Old archive file path
            new_path: New compressed file path
        """
        # Get all messages for the old archive
        messages = db_manager.get_all_messages_for_archive(old_path)

        if not messages:
            logger.warning(f"No messages found for archive: {old_path}")
            return

        # Update each message's archive_file path
        # Note: mbox_offset and mbox_length remain the same!
        # The compressed file preserves the same message structure
        updates = [
            {
                "gmail_id": msg["gmail_id"],
                "archive_file": new_path,
                "mbox_offset": msg["mbox_offset"],
                "mbox_length": msg["mbox_length"],
            }
            for msg in messages
        ]

        db_manager.bulk_update_archive_locations(updates)
        logger.info(f"Updated {len(updates)} messages from {old_path} to {new_path}")
