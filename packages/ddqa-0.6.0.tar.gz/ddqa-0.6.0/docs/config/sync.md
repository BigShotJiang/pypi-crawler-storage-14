# Config synchronization

-----

Before performing any actions, you should synchronize the repository's [external configuration](repo.md#global-config-source) by running:

```
ddqa sync
```

!!! tip
    This automatically happens on the first run of a given repository.
