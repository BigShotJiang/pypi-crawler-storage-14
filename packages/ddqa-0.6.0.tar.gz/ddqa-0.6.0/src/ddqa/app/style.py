# SPDX-FileCopyrightText: 2023-present Datadog, Inc. <dev@datadoghq.com>
#
# SPDX-License-Identifier: MIT
CSS = """
$primary: #632CA6;
$secondary: #9574CD;
"""
