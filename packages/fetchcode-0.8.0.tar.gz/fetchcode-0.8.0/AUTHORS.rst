The following organizations or individuals have contributed to this repo:

- Mayank Chandra @ jimc404
- Michael Herzog @ mjherzog
- Philippe Ombredanne @ pombredanne
- Steven Esser @ majurg
- Tushar Goel @ TG1999
- Thomas Druez @ tdruez
