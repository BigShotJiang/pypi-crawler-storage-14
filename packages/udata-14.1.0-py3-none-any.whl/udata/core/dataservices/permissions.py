from udata.core.dataset.permissions import OwnablePermission


class DataserviceEditPermission(OwnablePermission):
    """Permissions to edit a Dataservice"""

    pass
