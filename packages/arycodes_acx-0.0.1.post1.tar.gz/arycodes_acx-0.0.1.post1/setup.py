
from setuptools import setup

setup(
    name="arycodes-acx",
    version="0.0.1.post1",
    description="Alias package for ACX framework.",
    packages=["arycodes_acx"],
    install_requires=["acx"],
)
