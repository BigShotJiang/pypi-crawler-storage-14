"""
Maquinaweb Shared Auth - Sistema de autenticação compartilhada
"""

__version__ = "0.2.25"

# Core models
from .models import (
    SharedOrganization,
    SharedMember,
    SharedToken,
    User,
)

# Permission system models
from .models import (
    System,
    Permission,
    GroupPermissions,
    Plan,
    Subscription,
    GroupOrganizationPermissions,
    MemberSystemGroup,
)

# Mixins
from .mixins import (
    OrganizationMixin,
    UserMixin,
    OrganizationUserMixin,
    LoggedOrganizationMixin,
    RequirePermissionMixin,
    TimestampedMixin,
)

# Permissions
from .permissions import (
    IsAuthenticated,
    HasActiveOrganization,
    IsSameOrganization,
    IsOwnerOrSameOrganization,
    HasSystemPermission,
    HasAnyPermission,
    HasAllPermissions,
)

# Permission helpers
from .permissions_helpers import (
    user_has_permission,
    get_user_permissions,
    get_user_permission_codenames,
    get_organization_permissions,
    get_organization_permission_codenames,
    user_has_any_permission,
    user_has_all_permissions,
)

__all__ = [
    # Core
    "SharedOrganization",
    "SharedMember",
    "SharedToken",
    "User",
    # Permission models
    "System",
    "Permission",
    "GroupPermissions",
    "Plan",
    "Subscription",
    "GroupOrganizationPermissions",
    "MemberSystemGroup",
    # Mixins
    "OrganizationMixin",
    "UserMixin",
    "OrganizationUserMixin",
    "LoggedOrganizationMixin",
    "RequirePermissionMixin",
    "TimestampedMixin",
    # Permissions
    "IsAuthenticated",
    "HasActiveOrganization",
    "IsSameOrganization",
    "IsOwnerOrSameOrganization",
    "HasSystemPermission",
    "HasAnyPermission",
    "HasAllPermissions",
    # Helpers
    "user_has_permission",
    "get_user_permissions",
    "get_user_permission_codenames",
    "get_organization_permissions",
    "get_organization_permission_codenames",
    "user_has_any_permission",
    "user_has_all_permissions",
]
default_app_config = "shared_auth.app.SharedAuthConfig"