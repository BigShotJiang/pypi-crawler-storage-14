from __future__ import annotations

from audex.lib.wifi import WiFiManager


def make_wifi_manager() -> WiFiManager:
    return WiFiManager()
