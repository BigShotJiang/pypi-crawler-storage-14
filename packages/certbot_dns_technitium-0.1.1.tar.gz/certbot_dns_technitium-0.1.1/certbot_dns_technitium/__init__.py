"""
The `~certbot_dns_technitium.dns_technitium` plugin automates the process of
completing a ``dns-01`` challenge (`~acme.challenges.DNS01`) by creating, and
subsequently removing, TXT records using the Technitium DNS Server API.

.. note::
   The plugin is not installed by default. It can be installed via pip:

   .. code-block:: bash

      pip install certbot-dns-technitium

Named Arguments
---------------

========================================  =====================================
``--dns-technitium-credentials``          Technitium DNS Server credentials_ INI file.
                                          (Optional if using command-line arguments)
``--dns-technitium-api-url``              Technitium DNS Server API URL.
                                          (Default: http://localhost:5380)
``--dns-technitium-api-token``            Technitium DNS Server API token.
                                          (Required)
``--dns-technitium-propagation-seconds``  The number of seconds to wait for DNS
                                          to propagate before asking the ACME
                                          server to verify the DNS record.
                                          (Default: 10)
========================================  =====================================


Credentials
-----------

Use of this plugin requires a configuration file containing Technitium DNS Server
API credentials, obtained from your Technitium DNS Server web interface.

The API token can be created in the Technitium DNS Server web interface under
Administration → Sessions → Create Token.

The credentials file should contain your API URL and token:

.. code-block:: ini
   :name: certbot_technitium.ini
   :caption: Example credentials file:

   # Technitium DNS Server API credentials used by Certbot
   dns_technitium_api_url = https://dns.example.com:53443
   dns_technitium_api_token = your-api-token-here

The path to this file can be provided interactively or using the
``--dns-technitium-credentials`` command-line argument. Certbot records the path
to this file for use during renewal, but does not store the file's contents.

Alternatively, you can provide the API URL and token directly via command-line
arguments:

.. code-block:: bash

   certbot certonly \\
     --authenticator dns-technitium \\
     --dns-technitium-api-url https://dns.example.com:53443 \\
     --dns-technitium-api-token your-api-token-here \\
     -d example.com

.. caution::
   You should protect these API credentials as you would the password to your
   Technitium DNS Server. Users who can read this file can use these credentials
   to issue arbitrary API calls on your behalf. Users who can cause Certbot to
   run using these credentials can complete a ``dns-01`` challenge to acquire
   new certificates or revoke existing certificates for associated domains,
   even if those domains aren't being managed by this server.

Certbot will emit a warning if it detects that the credentials file can be
accessed by other users on your system. The warning reads "Unsafe permissions
on credentials configuration file", followed by the path to the credentials
file. This warning will be emitted each time Certbot uses the credentials file,
including for renewal, and cannot be silenced except by addressing the issue
(e.g., by using a command like ``chmod 600`` to restrict access to the file).


Examples
--------

.. code-block:: bash
   :caption: To acquire a certificate for ``example.com``

   certbot certonly \\
     --authenticator dns-technitium \\
     --dns-technitium-credentials ~/.secrets/certbot/technitium.ini \\
     -d example.com

.. code-block:: bash
   :caption: To acquire a single certificate for both ``example.com`` and
             ``www.example.com``

   certbot certonly \\
     --authenticator dns-technitium \\
     --dns-technitium-credentials ~/.secrets/certbot/technitium.ini \\
     -d example.com \\
     -d www.example.com

.. code-block:: bash
   :caption: To acquire a wildcard certificate for ``*.example.com``

   certbot certonly \\
     --authenticator dns-technitium \\
     --dns-technitium-credentials ~/.secrets/certbot/technitium.ini \\
     -d example.com \\
     -d *.example.com

.. code-block:: bash
   :caption: To acquire a certificate for ``example.com``, waiting 60 seconds
             for DNS propagation

   certbot certonly \\
     --authenticator dns-technitium \\
     --dns-technitium-credentials ~/.secrets/certbot/technitium.ini \\
     --dns-technitium-propagation-seconds 60 \\
     -d example.com

.. code-block:: bash
   :caption: To acquire a certificate using command-line arguments instead of
             a credentials file

   certbot certonly \\
     --authenticator dns-technitium \\
     --dns-technitium-api-url https://dns.example.com:53443 \\
     --dns-technitium-api-token your-api-token-here \\
     -d example.com

"""

__version__ = "0.1.0"
