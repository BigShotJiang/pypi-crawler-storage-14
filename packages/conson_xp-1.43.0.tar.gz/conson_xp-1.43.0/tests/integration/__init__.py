"""Integration tests for the XP package."""
