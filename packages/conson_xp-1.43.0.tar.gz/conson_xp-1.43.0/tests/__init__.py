"""Test suite for the XP package."""
