"""Generic MsActionTable serializer base class for type hints."""


class MsActionTableSerializer:
    """Serializer for ActionTable telegram encoding/decoding."""

    pass
