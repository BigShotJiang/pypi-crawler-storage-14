"""XP CLI tool for remote console bus operations.

conson-xp package.
"""

__version__ = "1.43.0"
__manufacturer__ = "salchichon"
__model__ = "xp.cli"
__serial__ = "2025.09.23.000"
