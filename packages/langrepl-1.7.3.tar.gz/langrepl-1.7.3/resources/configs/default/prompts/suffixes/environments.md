Here is useful information about the environment you are running in:
<env>
Working directory: {working_dir}
Platform: {platform}
OS Version: {os_version}
Today's date: {current_date_time_zoned}
</env>
