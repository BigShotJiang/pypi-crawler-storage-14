"""Reusable test fixtures organized by category."""
