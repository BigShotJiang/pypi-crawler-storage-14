
import re
import csv
from .utils import default_browser , get_browser
from os import remove

class SHRBrowserHistoryProcessor:
    def __init__(self , error_class):
        self.pattern1 = re.compile(r'q=.*?&')
        self.pattern2 = re.compile(r'wd=.*?&')
        self.url_pattern = re.compile(r'^(?:http[s]?://)?([^/]+)')
        self.url_pattern2 = re.compile(r'[\u4e00-\u9fa5][\u4e00-\u9fa5\s,，。a-zA-Z0-9?!-]{2,10}')
        self.data = []
        self.error_class = error_class

    def fetch_history(self , browser=""):
        try:
            if browser:
                BrowserClass = get_browser(browser)
            else:
                BrowserClass = default_browser()
            if BrowserClass is None:
                return False
            else:
                b = BrowserClass()
                outputs = b.fetch_history(desc=True)
                outputs.save("history.csv")
                return True
        except Exception as e:
            raise self.error_class(f"SHRBrowserReader [ERROR.6001] unable to fetch browser history. Browser : {browser} | {str(e)}")

    def save_processed_history(self):
        with open("history.csv" , newline = '', encoding = 'UTF-8', errors = 'replace') as f:
            self.data = [row for row in csv.DictReader(f)]
            f.close()
        remove('history.csv')
        return self.data

