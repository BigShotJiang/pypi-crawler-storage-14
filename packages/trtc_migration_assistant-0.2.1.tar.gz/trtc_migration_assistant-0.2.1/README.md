# TRTC Migration Assistant

![mcpServer](https://developer.qcloudimg.com/http-save/900000/f9ab7acfbfdd1a1dc398fe0c15a09932.svg)

TRTC Migration Assistant 是 [TRTC云助手](https://cloud.tencent.com/product/trtccopilot?Is=sdk-topnav) 团队为 [腾讯云TRTC](https://cloud.tencent.com/product/trtc?Is=sdk-topnav) 打造的快速迁移MCP工具，可以在AI的帮助下快速将集成其他RTC厂商的业务代码迁移到腾讯云TRTC。

## 1. 功能

在支持MCP的AI工具中，选择或复制集成其他RTC厂商的业务代码，然后使用如下提示词提问

```
"xxxxxx" 这是xx友商的代码，帮我迁移到TRTC
```

该工具会解析源代码中对其他RTC厂商的接口调用，并提供迁移到TRTC对应的接口，文档和迁移指引，AI会根据这些信息进行准确的迁移，写出迁移后的代码。


## 2. 安装使用

### 2.1 获取腾讯云密钥

为了安全的使用该服务，建议您在[腾讯云控制台](https://console.cloud.tencent.com/cam/user/create?systemType=FastCreateV2)新建一个子用户，并只对该用户授予`QcloudTrtccopilotFullAccess`权限(该权限是用于访问`TRTC云助手`)，获取该子用户的`SecretID`和`SecretKey`。

### 2.2 获取MCP Server配置

在[腾讯云开发者-MCP广场](https://cloud.tencent.com/developer/mcp)找到`trtc-migration-assistant`,并在的右侧`连接服务`的部分输入前面获取到的`SecretID`和`SecretKey`，点击`连接Server`获取对应的MCP Server配置，例如

```json
{
  "mcpServers": {
    "trtc-migration-assistant": {
      "type": "streamableHttp",
      "url": "https://xxx"
    }
  }
}
```

### 2.3 配置MCP Server

复制上一步获取到的配置，在支持MCP的AI工具（例如`CodeBuddy`, `Cursor`, `VSCode`等）中配置该 MCP Server即可

