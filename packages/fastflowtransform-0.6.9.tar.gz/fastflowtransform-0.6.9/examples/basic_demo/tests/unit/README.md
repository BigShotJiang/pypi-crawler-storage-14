# Unit tests

Define YAML unit specs as described in docs/Config_and_Macros.md#73-model-unit-tests-fft-utest.
Invoke them with `fft utest <project> --env <profile>`.
