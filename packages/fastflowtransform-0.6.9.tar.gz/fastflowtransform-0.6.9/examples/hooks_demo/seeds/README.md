# Seeds directory (hooks_demo)

`seed_events.csv` ships with the demo and feeds the staging model. Extend or replace it when
experimenting with hook behavior; the audit hooks don't depend on any specific schema.
