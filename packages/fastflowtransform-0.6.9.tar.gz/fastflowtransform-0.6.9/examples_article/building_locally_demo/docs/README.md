# Project documentation

Write operator or contributor notes here and keep them in sync with generated docs.
See docs/Technical_Overview.md#auto-docs-and-lineage for `fft dag` / `fft docgen` guidance.
