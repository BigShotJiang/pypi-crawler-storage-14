"""MCP server for Gmail integration."""

from . import server

__version__ = "0.1.0"
__all__ = ["server"]