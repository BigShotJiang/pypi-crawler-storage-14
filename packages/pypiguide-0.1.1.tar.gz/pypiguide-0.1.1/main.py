from pypistarter import hello_world

print(hello_world())
