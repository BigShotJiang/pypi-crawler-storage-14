
# src/discera_service/capabilities/image_detect_v23.py
from __future__ import annotations
import base64
import html
from typing import Any, Dict, List, Optional
import logging

log = logging.getLogger("discera.image_detect_v23")

# IngiAlla generator: all transport lives in ask_v23.py
from tvi.solphit.ingialla.ask import Generator as IngiGenerator  # <-- v23 import

# Images module: load bytes from ES using uploaded image_id
from discera_service.images import es_images, get_image_bytes  # upload flow already uses this index

GUIDELINES = """\
You must adhere to these guidelines for visual queries:
- Be objective; ground all statements in the image. No guessing.
- Transcribe visible text carefully when relevant; reason step by step for complex questions.
- Do not describe or infer identity, gender, race/ethnicity, emotions, mood, or mental state.
- Refuse to transcribe CAPTCHA text.
"""

class ImageDetectCapability:
    """
    Discera capability: image_detect (v23)
    - Vision request via IngiAlla's Generator (ask_v23.py)—NO HTTP here.
    - Reads image_id/image_ids passed by the UI; loads image bytes via images module.
    - Optional llm_gen for textual refinement (DI).
    """
    name = "image_detect"

    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": ImageDetectCapability.name,
            "description": (
                "Detects and objectively describes the contents of a provided image, answering the user's question."
            ),
            "intents": ["describe_image", "detect_objects", "answer_about_image", "vision_analysis"],
            "examples": [
                "What is shown in this image?",
                "List all visible labels and numbers.",
                "Describe the diagram and its components.",
            ],
            "tags": ["vision", "image", "multimodal", "analysis"],
            "excludes": [],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        css = r"""
.image-detect-result { margin: 12px 0; }
.image-detect-result .block {
  background: #111;
  border: 1px solid #333;
  border-radius: 10px;
  padding: 10px 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.12);
}
.image-detect-result .title { color: #ddd; font-weight: 600; margin-bottom: 6px; }
.image-detect-result .body { color: #ccc; font-size: 0.95rem; line-height: 1.45; white-space: pre-wrap; }
"""
        return {"css": [css], "js": []}

    @staticmethod
    def _compose_answer(analysis: Dict[str, Any], question: str) -> str:
        caption = analysis.get("caption") or ""
        objects = analysis.get("objects") or []
        ocr_text = analysis.get("ocr_text") or ""
        parts: List[str] = []
        if caption: parts.append(f"Overall description: {caption}")
        if objects: parts.append(f"Objects detected: {', '.join(objects)}.")
        if ocr_text: parts.append(f"Visible text: {ocr_text}")
        return "\n\n".join(parts) if parts else "No notable elements detected in the image."

    def run_once(self, args: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Expected args: {
          question: str,
          image_id?: str, image_ids?: list[str],
          image_b64?: str, image_bytes?: bytes
        }
        Optional kwargs:
          hints: dict (provider/model/concise)
          llm_gen: text generator (DI) for refinement
          vision_gen: IngiAlla Generator (DI) to perform vision requests
        """
        hints: Dict[str, Any] = kwargs.get("hints") or {}
        llm_gen = kwargs.get("llm_gen")  # optional
        vision_gen: IngiGenerator | None = kwargs.get("vision_gen")  # optional

        provider = (hints.get("provider") or "ollama").strip().lower()
        model = (hints.get("model") or "llava:latest").strip()
        concise = bool(hints.get("concise", args.get("concise", False)))
        question = (args.get("question") or hints.get("prompt") or "").strip()

        # Prefer direct content if provided; otherwise use uploaded image_id from ES
        image_b64: Optional[str] = (args.get("image_b64") or hints.get("image_b64") or "").strip() or None
        image_bytes: Optional[bytes] = args.get("image_bytes") or None
        image_id: Optional[str] = (args.get("image_id") or hints.get("image_id") or "").strip() or None

        if not (image_b64 or image_bytes or image_id):
            return {
                "answer": "No image content was provided. Supply image_b64 / image_bytes or upload and pass image_id.",
                "contexts": [],
                "meta": {"error": "missing_image_content"},
            }

        # Resolve bytes -> base64 if needed
        try:
            if not image_b64:
                if image_bytes and isinstance(image_bytes, (bytes, bytearray)):
                    image_b64 = base64.b64encode(image_bytes).decode("utf-8")
                elif image_id:
                    es = es_images()  # uses store.es_client under the hood
                    raw = get_image_bytes(es, image_id)  # uploaded via /images earlier
                    if not raw:
                        log.warning("image_detect_v23: get_image_bytes returned empty for id=%s", image_id)
                        return {"answer": "Could not load the referenced image.", "contexts": [], "meta": {"error": "image_load_failed"}}
                    image_b64 = base64.b64encode(raw).decode("utf-8")
        except Exception as ex:
            return {"answer": f"Failed to prepare image for vision: {ex}", "contexts": [], "meta": {"error": "image_prepare_failed"}}

        # Ensure a vision generator (ask_v23.py) is available (no HTTP here)
        gen = vision_gen or IngiGenerator(provider=provider, model=model, verbose=False)  # ask_v23 handles transport
        if not hasattr(gen, "generate_vision"):
            return {"answer": "Vision is not supported by the provided Generator (missing generate_vision).", "contexts": [], "meta": {"error": "generator_missing_vision"}}

        # Vision analysis via ask_v23
        try:
            analysis = gen.generate_vision(image_b64, question, timeout=600, guidelines=GUIDELINES)
        except Exception as ex:
            return {"answer": f"Vision analysis failed: {ex}", "contexts": [], "meta": {"error": "vision_failed", "exception": str(ex)}}

        # Compose & optional textual refinement
        answer = self._compose_answer(analysis, question)
        if llm_gen and answer:
            try:
                refine_prompt = (
                    "Refine the following image description to remain purely objective and safety-compliant. "
                    "Avoid identity/gender/race/emotions. Structure into short sections when appropriate.\n\n"
                    f"QUESTION:\n{question or '(none)'}\n\nDESCRIPTION:\n{answer}"
                )
                refined = (llm_gen.generate(question=refine_prompt, contexts=[], history=[], concise=concise) or "").strip()
                if refined: answer = refined
            except Exception as _ex:
                log.debug("image_detect_v23: llm_gen refinement failed: %s", _ex)

        html_block = (
            '<div class="image-detect-result">'
            '<div class="block">'
            '<div class="title">Image analysis</div>'
            f'<div class="body">{html.escape(answer)}</div>'
            '</div>'
            '</div>'
        )

        return {
            "answer": html_block,
            "contexts": [],
            "meta": {
                "provider": provider,
                "model": model,
                "vision": {"model_version": analysis.get("model_version"), "cost_hint": analysis.get("cost_hint")},
                "image_id": image_id,
            },
        }

    async def run_stream(self, args: Dict[str, Any], **kwargs):
        yield {"event": "generation_started", "data": {"capability": self.name}}
        result = self.run_once(args, **kwargs)
        try:
            yield {"event": "assets", "data": {"css": self.assets().get("css", []), "js": self.assets().get("js", [])}}
        except Exception:
            pass
        yield {"event": "token", "data": result["answer"]}
        yield {"event": "generation_done", "data": {}}
        yield {"event": "done", "data": {}}


def register(registry):
    registry.register(ImageDetectCapability())
