from datetime import datetime, timedelta
from tqdm.asyncio import tqdm
import json
import os
import inspect
from pydantic import BaseModel, ValidationError, field_validator
from json.decoder import JSONDecodeError
from sqlalchemy import select, desc, delete
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from toolkitz.re import extract_
from toolkitz.content import create_async_session
from modusched.core import BianXieAdapter, ArkAdapter
from .database import Prompt, UseCase
import functools
from itertools import islice
from sqlalchemy import select
from tqdm import tqdm as tqdm_sync
from toon_format import encode, decode
import pytest

from pro_craft_infer.utils import IntellectRemoveError,IntellectRemoveFormatError,ModelNameError



class AsyncIntel():
    def __init__(self,
                 database_url = "",
                 model_name = "",
                 logger = None,
                ):
        
        database_url = database_url or os.getenv("database_url")
        database_url = "mysql+aiomysql://" + database_url

        self.logger = logger
        self.engine = create_async_engine(database_url, 
                                          echo=False,
                                           )

        if "gemini" in model_name:
            self.llm = BianXieAdapter(model_name = model_name)
        elif "doubao" in model_name:
            self.llm = ArkAdapter(model_name = model_name)
        else:
            raise ModelNameError("AsyncIntel init get error model_name from zxf")

    async def _get_prompt(self,prompt_id,version,session):
        """
        获取指定 prompt_id 的最新版本数据，通过创建时间判断。
        """
        if version:
            stmt_ = select(Prompt).filter(
                Prompt.prompt_id == prompt_id,
                Prompt.version == version
            )
        else:  
            stmt_ = select(Prompt).filter(
                Prompt.prompt_id == prompt_id,
            )
        stmt = stmt_.order_by(
                desc(Prompt.timestamp), # 使用 sqlalchemy.desc() 来指定降序
                desc(Prompt.version)    # 使用 sqlalchemy.desc() 来指定降序
            )

        result = await session.execute(stmt)
        result = result.scalars().first()

        return result
    
    async def get_prompt(self,
                             prompt_id: str,
                             version = None,
                             session = None) -> Prompt:
        """
        从sql获取提示词
        """
        prompt_obj = await self._get_prompt(prompt_id=prompt_id,version=version,session=session)
        if prompt_obj:
            return prompt_obj
        if version:
            prompt_obj = await self._get_prompt(prompt_id=prompt_id,version=None,session=session)

        if prompt_obj is None:
            raise IntellectRemoveError("不存在的prompt_id")
        return prompt_obj


    def check_json_valid(self,llm_output,OutputFormat):
        try:
            json_str = extract_(llm_output,r'json')
            llm_output = json.loads(json_str)
            output = OutputFormat(**llm_output)
            return output
        except JSONDecodeError as e:
            raise ValueError(f"LLM输出的JSON格式不正确: {e}")
        except ValidationError as e:
            raise ValueError(f"LLM输出不符合Schema要求: {e}")
        except Exception as e:
            raise
                      
    async def get_validated(self,user_theme: str,system_prompt = "",OutputFormat = None, max_retries = 3):
        for attempt in range(max_retries):
            try:
                llm_raw_output = await self.llm.aproduct(prompt=user_theme,
                                                        system_prompt=system_prompt)
                # print(llm_raw_output,'llm_raw_outputllm_raw_output')

                validated = self.check_json_valid(llm_raw_output,OutputFormat=OutputFormat)
                return validated
            except ValueError as e:
                print(f"尝试 {attempt + 1} 失败: {e}")
                if attempt < max_retries - 1:
                    print("正在重试...")
                    prompt_template = f"你上次的输出不符合JSON Schema或格式错误，具体错误是：{e}。请修正并重新生成。"
                    user_theme += prompt_template
                else:
                    print("所有重试均失败。")
                    raise # 最终抛出错误



    async def inference_format(self,
                    input_data: dict | str,
                    prompt_id: str,
                    version: str = None,
                    OutputFormat: object | None = None,
                    ):
        """
        这个format 是严格校验模式, 是interllect 的增强版, 会主动校验内容,并及时抛出异常(或者伺机修正)
        ConTent_Function
        AConTent_Function
        两种方式的传入方式, 内容未通过就抛出异常
        """                
        base_format_prompt = """
# !!! 必须包括MarkDown的json代码块语法
你需要严格遵循以下JSON Schema来输出内容。输出必须是只包含JSON的文本(包括 json代码块语法文本 )，不包含任何额外的解释或文本。

JSON Schema:
```json
{schema_str}
```
请确保生成的JSON是有效的，并且所有字段都符合Schema的要求。
"""
        assert isinstance(input_data,(dict,str))
        input_data =  encode(input_data) if isinstance(input_data,dict) else input_data

        # get Output_format
        _schema = OutputFormat.model_json_schema()
        schema_str = json.dumps(_schema, indent=2, ensure_ascii=False)
        output_format = base_format_prompt.format(schema_str = schema_str) if not isinstance(OutputFormat,str) else OutputFormat

        # get system_prompt
        async with create_async_session(self.engine) as session:
            result_obj = await self.get_prompt(prompt_id=prompt_id,version= version,
                                                    session=session)
            system_prompt = result_obj.prompt + output_format

        # recall & running
        result = await self.get_validated(input_data,system_prompt=system_prompt,OutputFormat = OutputFormat)

        return result.model_dump()

  
    async def inference_format_gather(self,
                    input_datas: list[dict | str],
                    prompt_id: str,
                    version: str = None,
                    OutputFormat: object | None = None,
                    **kwargs,
                    ):
                
        tasks = []
        for input_data in input_datas:
            tasks.append(
                self.inference_format(
                    input_data = input_data,
                    prompt_id = prompt_id,
                    version = version,
                    OutputFormat = OutputFormat,
                    **kwargs,
                )
            )
        results = await tqdm.gather(*tasks,total=len(tasks))
        return results


    async def save_use_case(self,log_file,session = None):
        source_results = await session.execute(
            select(UseCase)
            .order_by(UseCase.timestamp.desc())
            .limit(1)
        )
        records_to_sync = source_results.scalars().one_or_none()
        if records_to_sync:
            last_time = records_to_sync.timestamp
            one_second = timedelta(seconds=1)
            last_time += one_second
        else:
            last_time = datetime(2025, 1, 1, 14, 30, 0)

        with open(log_file,'r') as f:
            x = f.read()

    
        def deal_log(resu):
            if len(resu) <3:
                return 
            try:
                create_time = resu[1]
                level = resu[2]
                funcname = resu[3]
                line = resu[4]
                pathname = resu[5]
                message = resu[6]

                dt_object = datetime.fromtimestamp(float(create_time.strip()))
                message_list = message.split("&")
                if len(message_list) == 3:
                    func_name, input_, output_ = message_list
                elif len(message_list) == 2:
                    input_, output_ = message_list
                    func_name = "只有两个"
                elif len(message_list) == 1:
                    input_  = message_list[0]
                    output_ = " "
                    func_name = "只有一个"

                if dt_object > last_time:
                    use_case = UseCase(
                        time = create_time.strip(),
                        level = level.strip(),
                        timestamp =dt_object.strftime('%Y-%m-%d %H:%M:%S.%f'),
                        filepath=pathname.strip(),
                        function=func_name.strip(),
                        lines=line.strip(),
                        input_data=input_.strip(),
                        output_data=output_.strip(),
                    )
                    session.add(use_case)
            except Exception as e:
                raise


        for res in x.split("||"):
            resu = res.split("$")
            deal_log(resu)

        await session.commit() # 提交事务，将数据写入数据库


    async def sync_log(self,log_path, database_url:str = ""):
        if database_url:
            target_engine = create_async_engine(database_url, echo=False)
        else:
            target_engine = self.engine
        async with create_async_session(target_engine) as session:
            await self.save_use_case(log_file = log_path,session = session)




def calculate_pass_rate_and_assert(results, test_name, PASS_THRESHOLD_PERCENT = 90,bad_case = []):
    """
    辅助函数：计算通过率并根据阈值进行断言。
    results: 包含 True (通过) 或 False (失败) 的列表
    test_name: 测试名称，用于打印信息
    """
    result_text = ""
    if not results:
        pytest.fail(f"测试 '{test_name}' 没有执行任何子用例。")

    total_sub_cases = len(results)
    passed_sub_cases = results.count(True)
    pass_rate = (passed_sub_cases / total_sub_cases) * 100

    result_text +=f"\n--- 测试 '{test_name}' 内部结果 ---\n"
    result_text +=f"总子用例数: {total_sub_cases}\n"
    result_text +=f"通过子用例数: {passed_sub_cases}\n"
    result_text +=f"通过率: {pass_rate:.2f}%\n"

    if pass_rate >= PASS_THRESHOLD_PERCENT:
        result_text += f"通过率 ({pass_rate:.2f}%) 达到或超过 {PASS_THRESHOLD_PERCENT}%。测试通过。\n"
        assert True # 显式断言成功
        x = 0
    else:
        result_text += f"通过率 ({pass_rate:.2f}%) 低于 {PASS_THRESHOLD_PERCENT}%。测试失败。\n"
        result_text += "bad_case:" + '\n'.join(bad_case)
        x = 1
    return result_text,x

async def atest_by_use_case(func:object,
                            eval,
                            PASS_THRESHOLD_PERCENT=90,
                           database_url = "",
                           limit_number = 100):

    engine = create_async_engine(database_url, 
                                 echo=False,
                                pool_size=10,        # 连接池中保持的连接数
                                max_overflow=20,     # 当pool_size不够时，允许临时创建的额外连接数
                                pool_recycle=3600,   # 每小时回收一次连接
                                pool_pre_ping=True,  # 使用前检查连接活性
                                pool_timeout=30      # 等待连接池中连接的最长时间（秒）
                                        )

    async with create_async_session(engine) as session:
        result = await session.execute(
              select(UseCase)
              .filter(UseCase.function==func.__name__,UseCase.is_deleted==0)
              .order_by(UseCase.timestamp.desc())
              .limit(limit_number)
        )
        usecase = result.scalars().all()
        sub_case_results = []
        bad_case = []
        for usecase_i in tqdm_sync(usecase):
            try:
                usecase_dict = json.loads(usecase_i.input_data)
                result = await func(**usecase_dict)
                await eval(result,usecase_i)
                sub_case_results.append(True)
            except AssertionError as e:
                sub_case_results.append(False)
                bad_case.append(f"input: {usecase_dict} 未通过, putput: {result}, Error Info: {e}")
            except Exception as e:
                raise Exception(f"意料之外的错误 {e}")

        return calculate_pass_rate_and_assert(sub_case_results, f"test_{func.__name__}_pass_{PASS_THRESHOLD_PERCENT}",PASS_THRESHOLD_PERCENT,
                                              bad_case=bad_case)
    