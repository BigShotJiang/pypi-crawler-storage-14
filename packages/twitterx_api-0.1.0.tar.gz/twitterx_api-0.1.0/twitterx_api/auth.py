from typing import List, Type, Union
from twitterx_api.constants import X_AUTHORIZE_TOKEN, X_BASE_URL, X_MEDIA_UPLOAD_URL, XPFF_GENERATER
from twitterx_api.types.types import T
from twitterx_api.utils.http_client import HttpClient
from twitterx_api.utils.x_transaction_id import generate_x_transaction_id


class Auth:
    def __init__(self,cookies: Union[str, list, dict] = None) -> None:
        self.http_client = HttpClient(
            base_url=X_BASE_URL,
            accept_language="en-US,en;q=0.5",
            impersonate="firefox",
            max_retries=2,
            backoff_factor=0.5,
        )
        if cookies is not None:
            if '=' in cookies and 'Cookie:' in cookies or not cookies.strip().startswith('{') and not cookies.strip().startswith('['):
                self.http_client.import_cookies_header(cookies)
            elif isinstance(cookies, (list, dict)):
                self.http_client.import_cookies_json(cookies)
        
    
    def export_cookies_header(self) -> str:
        return self.http_client.export_cookies_header()

    def export_cookies_dict(self) -> List[dict]:
        return self.http_client.export_cookies_json()
    def get_http_client(self) -> HttpClient:
        return self.http_client
    
    def get(self, url: str,params: dict = None,model_class: Type[T] = None) -> Union[T, dict, list, str]:
        headers = self._gen_headers(url,"GET")
        response = self.http_client.get(url=url,params=params,headers=headers,origin=X_BASE_URL)
        print(f'text response: {response.text}  status code: {response.status_code}')
        return self.http_client.format_response_object(response,model_class)

    def post(self, url: str,data: dict = None,model_class: Type[T] = None) -> Union[T, dict, list, str]:
        headers = self._gen_headers(url,"POST")
        response = self.http_client.post_json(url=url,json=data,headers=headers,origin=X_BASE_URL)
        return self.http_client.format_response_object(response, model_class)
    
    
    def upload_media(self, media_data: bytes, media_type: str) -> str:

       is_video = media_type.startswith('video/')
      
       if is_video:
         # Handle video upload using chunked media upload
         return self._upload_video_in_chunks(media_data, media_type)
       else:
         # Handle image upload
         return self._upload_image(media_data, media_type)
    
    def _upload_image(self, media_data: bytes, media_type: str) -> str:
        """
        Upload an image to Twitter
        
        Args:
            media_data: Bytes of the image file
            media_type: MIME type of the image
            
        Returns:
            Media ID string
        """
        # Prepare headers
        headers = self._gen_headers(X_MEDIA_UPLOAD_URL, "POST")
        
        # Create files dictionary for multipart upload
        files = {
            'media': ('media', media_data, media_type)
        }
        
        # Add command parameter
        data = {
            'command': 'INIT'
        }
        
        # Make the request
        response = self.http_client.post_multipart(
            url=X_MEDIA_UPLOAD_URL,
            files=files,
            headers=headers
        )
        
        # Parse response
        response_data = response.json()
        return response_data.get('media_id_string')
    
    def _upload_video_in_chunks(self, media_data: bytes, media_type: str) -> str:
        """
        Upload a video to Twitter using the chunked upload endpoint
        
        Args:
            media_data: Bytes of the video file
            media_type: MIME type of the video
            
        Returns:
            Media ID string
        """
        # Prepare headers
        headers = self._gen_headers(X_MEDIA_UPLOAD_URL, "POST")
        
        # Step 1: INIT command
        init_data = {
            'command': 'INIT',
            'media_type': media_type,
            'total_bytes': str(len(media_data))
        }
        
        init_response = self.http_client.post_form(
            url=X_MEDIA_UPLOAD_URL,
            form=init_data,
            headers=headers
        )
        
        if not (200 <= init_response.status_code < 300):
            raise Exception(f"INIT command failed with status {init_response.status_code}: {init_response.text}")
        
        init_response_data = init_response.json()
        media_id = init_response_data.get('media_id_string')
        
        # Step 2: APPEND commands - upload chunks
        segment_size = 5 * 1024 * 1024  # 5 MB per chunk
        segment_index = 0
        
        for offset in range(0, len(media_data), segment_size):
            chunk = media_data[offset:offset + segment_size]
            
            # Create files dictionary for this chunk
            files = {
                'media': ('media', chunk, 'application/octet-stream')
            }
            
            # Form data for APPEND command
            append_data = {
                'command': 'APPEND',
                'media_id': media_id,
                'segment_index': str(segment_index)
            }
            
            append_response = self.http_client.post_multipart(
                url=X_MEDIA_UPLOAD_URL,
                form=append_data,
                files=files,
                headers=headers
            )
            
            if not (200 <= append_response.status_code < 300):
                raise Exception(f"APPEND command failed for segment {segment_index} with status {append_response.status_code}: {append_response.text}")
            
            segment_index += 1
        
        # Step 3: FINALIZE command
        finalize_data = {
            'command': 'FINALIZE',
            'media_id': media_id
        }
        
        finalize_response = self.http_client.post_form(
            url=X_MEDIA_UPLOAD_URL,
            form=finalize_data,
            headers=headers
        )
        
        if not (200 <= finalize_response.status_code < 300):
            raise Exception(f"FINALIZE command failed with status {finalize_response.status_code}: {finalize_response.text}")
        
        finalize_response_data = finalize_response.json()
        
        # Check if processing is needed
        processing_info = finalize_response_data.get('processing_info')
        if processing_info:
            # For simplicity, we're not implementing the status checking logic here
            # In a production environment, you would poll the status endpoint until completion
            pass
        
        return media_id

    def _gen_headers(self, url:str,method:str):
        guest_id = self.http_client.get_cookie_by_name("guest_id")
        gt = self.http_client.get_cookie_by_name("gt")
        ct0 =  self.http_client.get_cookie_by_name("ct0")
        xpff_header = XPFF_GENERATER(guest_id)
        transaction_id = generate_x_transaction_id(url=X_BASE_URL+"/"+url.lstrip("/"),method=method)
        headers = {
            "x-client-transaction-id": transaction_id,
            "x-xp-forwarded-for": xpff_header,
            #"x-guest-token": gt,
            "x-csrf-token":ct0,
            "Authorization": X_AUTHORIZE_TOKEN,
            "x-twitter-active-user":"yes",
            "x-twitter-auth-type": "OAuth2Session",
            "x-twitter-client-language":"en",
        }
        if gt is not None and gt != "":
            headers["x-guest-token"] = gt
        
        return headers