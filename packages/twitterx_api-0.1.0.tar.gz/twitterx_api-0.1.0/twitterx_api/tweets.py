import time
from typing import List, Optional, Union
from twitterx_api.auth import Auth
from twitterx_api.constants import X_CREATE_TWEET_URL, X_LIKE_TWEET_URL, X_MEDIA_UPLOAD_URL, X_RETWEET_URL, X_USER_TWEETS_URL
from twitterx_api.types.profile import TwitterUserResponse
from twitterx_api.types.response_base import ResponseData
from twitterx_api.types.tweet import TweetData
from twitterx_api.types.types import MediaFile
from twitterx_api.types.user_tweets import UserTweetsData


class Tweets:
    def __init__(self,auth:Auth) -> None:
        self.auth = auth
    def like(self,tweet_id:str) -> None:
       data = {"variables":{"tweet_id":tweet_id},"queryId":"lI07N6Otwv1PhnEgXILM7A"}
       self.auth.post(X_LIKE_TWEET_URL,data=data)
   
    def retweet(self,tweet_id:str) -> Union[dict, list, str]:
       data = {"variables":{"tweet_id":tweet_id,"dark_request":False},"queryId":"LFho5rIi4xcKO90p9jwG7A"}
       return self.auth.post(X_RETWEET_URL,data=data)
   
    def reply(self,tweet_id:str,text:str,media_files: Optional[List[MediaFile]] = None) -> Union[ResponseData[TweetData], dict, list, str]:
       media_ids = []
       if media_files:
         filtered_media_files: List[MediaFile] = self._validate_media_files(media_files)
        
            # Collect media IDs
         for media_file in filtered_media_files:
                # Upload media and get media ID
            media_id = self.auth.upload_media(media_file.data, media_file.media_type)
            media_ids.append(media_id)
       data = {
            "variables": {
                "tweet_text": text,
                "reply": {
                    "in_reply_to_tweet_id": tweet_id,
                    "exclude_reply_user_ids": []
                },
                "dark_request": False,
                "media": {
                    "media_entities": [{"media_id": media_id, "tagged_users": []} for media_id in media_ids],
                    "possibly_sensitive": False
                },
                "semantic_annotation_ids": [],
                "disallowed_reply_options": None
            },
            "features": {
                "premium_content_api_read_enabled": False,
                "communities_web_enable_tweet_community_results_fetch": True,
                "c9s_tweet_anatomy_moderator_badge_enabled": True,
                "responsive_web_grok_analyze_button_fetch_trends_enabled": False,
                "responsive_web_grok_analyze_post_followups_enabled": True,
                "responsive_web_jetfuel_frame": True,
                "responsive_web_grok_share_attachment_enabled": True,
                "responsive_web_edit_tweet_api_enabled": True,
                "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
                "view_counts_everywhere_api_enabled": True,
                "longform_notetweets_consumption_enabled": True,
                "responsive_web_twitter_article_tweet_consumption_enabled": True,
                "tweet_awards_web_tipping_enabled": False,
                "responsive_web_grok_show_grok_translated_post": True,
                "responsive_web_grok_analysis_button_from_backend": True,
                "creator_subscriptions_quote_tweet_preview_enabled": False,
                "longform_notetweets_rich_text_read_enabled": True,
                "longform_notetweets_inline_media_enabled": True,
                "payments_enabled": False,
                "profile_label_improvements_pcf_label_in_post_enabled": True,
                "responsive_web_profile_redirect_enabled": False,
                "rweb_tipjar_consumption_enabled": True,
                "verified_phone_label_enabled": False,
                "articles_preview_enabled": True,
                "responsive_web_grok_community_note_auto_translation_is_enabled": False,
                "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
                "freedom_of_speech_not_reach_fetch_enabled": True,
                "standardized_nudges_misinfo": True,
                "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
                "responsive_web_grok_image_annotation_enabled": True,
                "responsive_web_grok_imagine_annotation_enabled": True,
                "responsive_web_graphql_timeline_navigation_enabled": True,
                "responsive_web_enhance_cards_enabled": False
            },
            "queryId": "MtyT_TbO2PpwaFHNPK2qoQ"
        }
       return self.auth.post(X_CREATE_TWEET_URL,data=data,model_class=ResponseData[TweetData])
   
    def tweet(self,text:str,media_files: Optional[List[MediaFile]] = None) -> ResponseData[TweetData]:
      media_ids = []
      if media_files:
        filtered_media_files: List[MediaFile] = self._validate_media_files(media_files)
        
            # Collect media IDs
        for media_file in filtered_media_files:
                # Upload media and get media ID
            media_id = self.auth.upload_media(media_file.data, media_file.media_type)
            media_ids.append(media_id)
      payload = {
         "features": {
            "articles_preview_enabled": True,
            "c9s_tweet_anatomy_moderator_badge_enabled": True,
            "communities_web_enable_tweet_community_results_fetch": True,
            "creator_subscriptions_quote_tweet_preview_enabled": False,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "longform_notetweets_inline_media_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "payments_enabled": False,
            "premium_content_api_read_enabled": False,
            "profile_label_improvements_pcf_label_in_post_enabled": True,
            "responsive_web_edit_tweet_api_enabled": True,
            "responsive_web_enhance_cards_enabled": False,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "responsive_web_grok_analysis_button_from_backend": True,
            "responsive_web_grok_analyze_button_fetch_trends_enabled": False,
            "responsive_web_grok_analyze_post_followups_enabled": True,
            "responsive_web_grok_community_note_auto_translation_is_enabled": False,
            "responsive_web_grok_image_annotation_enabled": True,
            "responsive_web_grok_imagine_annotation_enabled": True,
            "responsive_web_grok_share_attachment_enabled": True,
            "responsive_web_grok_show_grok_translated_post": True,
            "responsive_web_jetfuel_frame": True,
            "responsive_web_profile_redirect_enabled": False,
            "responsive_web_twitter_article_tweet_consumption_enabled": True,
            "rweb_tipjar_consumption_enabled": True,
            "standardized_nudges_misinfo": True,
            "tweet_awards_web_tipping_enabled": False,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "verified_phone_label_enabled": False,
            "view_counts_everywhere_api_enabled": True
         },
         "queryId": "RwodRpJ0PbsPPZUtYjKS3w",
         "variables": {
            "dark_request": False,
            "disallowed_reply_options": None,
            "media": {
                  "media_entities": [{"media_id": media_id, "tagged_users": []} for media_id in media_ids],
                  "possibly_sensitive": False
            },
            "semantic_annotation_ids": [],
            "tweet_text": text,
         }
      }
      return self.auth.post(X_CREATE_TWEET_URL,data=payload,model_class=ResponseData[TweetData])
   
    def user_tweets(self,user_id:str, cursor:str, size:int = 20) -> ResponseData[UserTweetsData]:
       variables = f'{{"userId":{user_id},"count":{size},"includePromotedContent":true,"withQuickPromoteEligibilityTweetFields":true,"withVoice":true}}'
       if cursor and cursor != "null":
          variables = f'{{"userId":{user_id},"count":{size},"cursor":"{cursor}","includePromotedContent":true,"withQuickPromoteEligibilityTweetFields":true,"withVoice":true}}'
       features = '{"rweb_video_screen_enabled":false,"payments_enabled":false,"profile_label_improvements_pcf_label_in_post_enabled":true,"responsive_web_profile_redirect_enabled":false,"rweb_tipjar_consumption_enabled":true,"verified_phone_label_enabled":false,"creator_subscriptions_tweet_preview_api_enabled":true,"responsive_web_graphql_timeline_navigation_enabled":true,"responsive_web_graphql_skip_user_profile_image_extensions_enabled":false,"premium_content_api_read_enabled":false,"communities_web_enable_tweet_community_results_fetch":true,"c9s_tweet_anatomy_moderator_badge_enabled":true,"responsive_web_grok_analyze_button_fetch_trends_enabled":false,"responsive_web_grok_analyze_post_followups_enabled":false,"responsive_web_jetfuel_frame":true,"responsive_web_grok_share_attachment_enabled":true,"articles_preview_enabled":true,"responsive_web_edit_tweet_api_enabled":true,"graphql_is_translatable_rweb_tweet_is_translatable_enabled":true,"view_counts_everywhere_api_enabled":true,"longform_notetweets_consumption_enabled":true,"responsive_web_twitter_article_tweet_consumption_enabled":true,"tweet_awards_web_tipping_enabled":false,"responsive_web_grok_show_grok_translated_post":false,"responsive_web_grok_analysis_button_from_backend":true,"creator_subscriptions_quote_tweet_preview_enabled":false,"freedom_of_speech_not_reach_fetch_enabled":true,"standardized_nudges_misinfo":true,"tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled":true,"longform_notetweets_rich_text_read_enabled":true,"longform_notetweets_inline_media_enabled":true,"responsive_web_grok_image_annotation_enabled":true,"responsive_web_grok_imagine_annotation_enabled":true,"responsive_web_grok_community_note_auto_translation_is_enabled":false,"responsive_web_enhance_cards_enabled":false}'
       fieldToggles = '{"withArticlePlainText":false}'
       self.auth.get(X_USER_TWEETS_URL,params={"variables":variables,"features":features,"fieldToggles":fieldToggles},model_class=ResponseData[UserTweetsData])
    
   
    def _validate_media_files(self, media_files: list) -> list:
        """
        Validate and filter media files according to Twitter's limits:
        - Max 1 video and up to 3 images (total max 4 media files)
        - Or up to 4 images
        
        Args:
            media_files: List of media files, each with 'data' and 'type' keys
            
        Returns:
            Filtered list of media files
        """
        # If more than 4 media files, take only the first 4
        if len(media_files) > 4:
            media_files = media_files[:4]
        
        # Separate videos and images
        videos = [media for media in media_files if media['type'].startswith('video/')]
        images = [media for media in media_files if not media['type'].startswith('video/')]
        
        # If there are two or more videos, keep only the first one
        if len(videos) > 1:
            videos = videos[:1]
        
        # Combine videos and images, keeping the total to 4 or less
        filtered_media = videos + images
        if len(filtered_media) > 4:
            # Prioritize videos, then take up to 4 total
            if len(videos) > 0:
                # Keep the video and up to 3 images
                filtered_media = videos[:1] + images[:3]
            else:
                # Just images, take up to 4
                filtered_media = images[:4]
        
        return filtered_media
      