from typing import List, Optional, Union
from twitterx_api.auth import Auth
from twitterx_api.profile import Profile
from twitterx_api.search import Search
from twitterx_api.tweets import Tweets
from twitterx_api.types.profile import UserData
from twitterx_api.types.response_base import ResponseData
from twitterx_api.types.user_tweets import UserTweetsData
from twitterx_api.utils.parse_model import extract_tweets_info, parse_tweet_entries, parse_user_entries, parse_list_entries
from twitterx_api.types.types import SearchType, MediaFile
from twitterx_api.types.tweet import TweetData


class TwitterXClient:
    
    def __init__(self,cookies: Union[str, list, dict] = None) -> None:
        self.auth = Auth(cookies)
        self.tweets = Tweets(self.auth)
        self.profile = Profile(self.auth)
        self.search = Search(self.auth)

    def export_header_cookies(self) -> str:
        return self.auth.export_cookies_header()
    
    def export_dict_cookies(self) -> List[dict]:
        return self.auth.export_cookies_dict()
    
    def get_pfoile(self,screen_name:str) -> Union[ResponseData[UserData], dict, list, str]:
        repsponse :Union[ResponseData[UserData], dict, list, str] =  self.profile.profile(screen_name)
        if isinstance(repsponse,ResponseData):
            return repsponse.data.user.result
        else:
            return repsponse
    
    def get_tweets(self,user_id:str, cursor:str, size) -> dict:
        response:ResponseData[UserTweetsData] =  self.tweets.user_tweets(user_id, cursor, size)
        return extract_tweets_info(response)
    
    def search_latest_tweets(self, query: str, count: int = 20, cursor: str = None) -> dict:
        """
        Search for latest tweets based on a query.
        
        Args:
            query (str): Search query
            count (int): Number of tweets to retrieve (default: 20)
            cursor (str): Pagination cursor for fetching more results
            
        Returns:
            dict: Dictionary containing tweets, top and bottom cursors
        """
        response = self.search.search(query, count, cursor, SearchType.Latest)
        tweets, top_cursor, bottom_cursor = parse_tweet_entries(response)
        return {
            "tweets": tweets,
            "top_cursor": top_cursor,
            "bottom_cursor": bottom_cursor
        }
    
    def search_top_tweets(self, query: str, count: int = 20, cursor: str = None) -> dict:
        """
        Search for top tweets based on a query.
        
        Args:
            query (str): Search query
            count (int): Number of tweets to retrieve (default: 20)
            cursor (str): Pagination cursor for fetching more results
            
        Returns:
            dict: Dictionary containing tweets, top and bottom cursors
        """
        response = self.search.search(query, count, cursor, SearchType.Top)
        tweets, top_cursor, bottom_cursor = parse_tweet_entries(response)
        return {
            "tweets": tweets,
            "top_cursor": top_cursor,
            "bottom_cursor": bottom_cursor
        }
    
    def search_people(self, query: str, count: int = 20, cursor: str = None) -> dict:
        """
        Search for people (users) based on a query.
        
        Args:
            query (str): Search query
            count (int): Number of users to retrieve (default: 20)
            cursor (str): Pagination cursor for fetching more results
            
        Returns:
            dict: Dictionary containing users, top and bottom cursors
        """
        response = self.search.search(query, count, cursor, SearchType.People)
        users, top_cursor, bottom_cursor = parse_user_entries(response)
        return {
            "users": users,
            "top_cursor": top_cursor,
            "bottom_cursor": bottom_cursor
        }
    
    def search_lists(self, query: str, count: int = 20, cursor: str = None) -> dict:
        """
        Search for lists based on a query.
        
        Args:
            query (str): Search query
            count (int): Number of lists to retrieve (default: 20)
            cursor (str): Pagination cursor for fetching more results
            
        Returns:
            dict: Dictionary containing lists, top and bottom cursors
        """
        response = self.search.search(query, count, cursor, SearchType.List)
        lists, top_cursor, bottom_cursor = parse_list_entries(response)
        return {
            "lists": lists,
            "top_cursor": top_cursor,
            "bottom_cursor": bottom_cursor
        }
    
    def like_tweet(self, tweet_id: str) -> None:
        """
        Like a tweet by its ID.
        
        Args:
            tweet_id (str): The ID of the tweet to like
        """
        self.tweets.like(tweet_id)
    
    def retweet(self, tweet_id: str) -> Union[dict, list, str]:
        """
        Retweet a tweet by its ID.
        
        Args:
            tweet_id (str): The ID of the tweet to retweet
            
        Returns:
            Union[dict, list, str]: Response from the retweet operation
        """
        return self.tweets.retweet(tweet_id)
    
    def reply_to_tweet(self, tweet_id: str, text: str, media_files: Optional[List[MediaFile]] = None) -> Union[ResponseData[TweetData], dict, list, str]:
        """
        Reply to a tweet with text and optional media files.
        
        Args:
            tweet_id (str): The ID of the tweet to reply to
            text (str): The text content of the reply
            media_files (Optional[List[MediaFile]]): Optional list of media files to attach
            
        Returns:
            Union[ResponseData[TweetData], dict, list, str]: Response from the reply operation
        """
        return self.tweets.reply(tweet_id, text, media_files)
    
    def post_tweet(self, text: str, media_files: Optional[List[MediaFile]] = None) -> ResponseData[TweetData]:
        """
        Post a new tweet with text and optional media files.
        
        Args:
            text (str): The text content of the tweet
            media_files (Optional[List[MediaFile]]): Optional list of media files to attach
            
        Returns:
            ResponseData[TweetData]: Response from the tweet creation operation
        """
        return self.tweets.tweet(text, media_files)