from __future__ import annotations

import json
import re
from typing import Any, Dict, Mapping, Optional, Tuple, TypeVar, Union, Iterable, List
import time
from urllib.parse import urljoin
from http.cookies import SimpleCookie
from curl_cffi import requests as creq  # pip install curl-cffi
from typing import Type, Union, Any

from twitterx_api.types.types import T

JSONType = Union[dict, list, str, int, float, bool, None]
Headers = Mapping[str, str]
Params = Mapping[str, Union[str, int, float, bool]]



class HttpError(Exception):
    def __init__(self, status_code: int, text: str, url: str):
        super().__init__(f"HTTP {status_code} for {url}: {text[:300]}")
        self.status_code = status_code
        self.text = text
        self.url = url


class HttpClient:
    """
    基于 curl-cffi 的 Firefox 拟真客户端：
    - 使用 impersonate="firefox" 最大程度复制 Firefox 的 TLS+H2+UA+Accept-Encoding 行为
    - 支持：会话、Cookie 导入导出、重试、代理、自定义头、JSON/表单/文件
    - 提供 firefox_style_* 预设头（区分 HTML 导航 vs XHR/Fetch）
    """

    def __init__(
            self,
            base_url: str = "",
            headers: Optional[Headers] = None,
            timeout: float = 20.0,
            proxies: Optional[Dict[str, str]] = None,
            verify: bool = True,
            max_retries: int = 2,
            backoff_factor: float = 0.6,
            retry_for_statuses: Iterable[int] = (429, 500, 502, 503, 504),
            raise_for_status: bool = True,
            impersonate: str = "firefox",  # ★ 关键：Firefox 拟真
            accept_language: str = "zh-CN,zh;q=0.9,en-US;q=0.7,en;q=0.6",  # 可按需改
    ) -> None:
        self.base_url = base_url.rstrip("/") + "/" if base_url else ""
        self.timeout = timeout
        self.verify = verify
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.retry_for_statuses = set(retry_for_statuses)
        self.raise_for_status = raise_for_status
        self.accept_language = accept_language
        # 会话：使用 Firefox 指纹
        self.session = creq.Session(
            headers={
                # UA/Accept-Encoding/HTTP2 等由 impersonate 决定；这里放最小自定义
                "Accept-Language": self.accept_language,
                **(headers or {})
            },
            proxies=proxies,
            verify=verify,
            impersonate=impersonate,  # ★
        )

    # ---------- Header 预设：更像 Firefox ----------
    def firefox_style_html_headers(self, extra: Optional[Headers] = None) -> Dict[str, str]:
        """
        模拟用户“在地址栏打开网页”的请求头（text/html 导航场景）。
        注：不要加 Chromium 私有头（sec-ch-ua* / sec-fetch-*），Firefox 不发。
        """
        h = {
            # Firefox 导航常见 Accept（版本间略有差异，无需逐字一致）
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": self.accept_language,
            "Upgrade-Insecure-Requests": "1",
            # Accept-Encoding 由 curl-cffi 根据 TLS/H2/impersonate 决定；不手动覆盖
            # Connection/Keep-Alive/H2 伪首部顺序由 curl-impersonate 处理
        }
        if extra: h.update(extra)
        return h

    def firefox_style_xhr_headers(self, extra: Optional[Headers] = None) -> Dict[str, str]:
        """
        模拟 Firefox 发起的 XHR/Fetch（API）请求：
        - Accept: */*
        - 无 sec-fetch- 系列头（那是 Chromium 的）
        """
        h = {
            "Accept": "*/*",
            "Accept-Language": self.accept_language,
        }
        if extra: h.update(extra)
        return h

    # ---------- 基础会话操作 ----------
    def set_header(self, key: str, value: str) -> None:
        self.session.headers[key] = value

    def update_headers(self, headers: Headers) -> None:
        self.session.headers.update(headers)

    def get_header(self, key: str, default: Optional[str] = None) -> Optional[str]:
        return self.session.headers.get(key, default)

    def set_cookie(self, name: str, value: str, domain: Optional[str] = None, path: str = "/") -> None:
        self.session.cookies.set(name, value, domain=domain, path=path)

    def close(self) -> None:
        self.session.close()

    def __enter__(self) -> "HttpClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # ---------- 通用请求 ----------
    def request(
            self,
            method: str,
            url: str,
            *,
            params: Optional[Params] = None,
            headers: Optional[Headers] = None,
            data: Optional[Mapping[str, Any]] = None,
            json: Optional[JSONType] = None,
            files: Optional[Dict[str, Tuple[str, bytes, str]]] = None,
            timeout: Optional[float] = None,
            proxies: Optional[Dict[str, str]] = None,
            allow_redirects: bool = True,
            raise_for_status: Optional[bool] = None,
            referer: Optional[str] = None,  # ★ 有些站点要求携带
            origin: Optional[str] = None,  # ★ CORS/CSRF 场景
            use_html_preset: bool = False,  # ★ True=页面导航式头；False=XHR/Fetch 式头
    ) -> creq.Response:
        full_url = urljoin(self.base_url, url) if self.base_url else url
        timeout = timeout if timeout is not None else self.timeout
        raise_for_status = self.raise_for_status if raise_for_status is None else raise_for_status

        # 预设头（Firefox 风格）
        base_headers = (
            self.firefox_style_html_headers() if use_html_preset else self.firefox_style_xhr_headers()
        )
        req_headers = dict(self.session.headers)
        req_headers.update(base_headers)
        if headers:
            req_headers.update(headers)
        if referer:
            req_headers["Referer"] = referer
        if origin:
            req_headers["Origin"] = origin

        # JSON 与表单互斥；传 JSON 自动 Content-Type
        if json is not None and "Content-Type" not in {k.title(): v for k, v in req_headers.items()}:
            req_headers["Content-Type"] = "application/json"

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self._do_request_compat(
                    method=method.upper(),
                    url=full_url,
                    params=params,
                    data=None if json is not None else data,
                    json=json,
                    files=files,
                    headers=req_headers,
                    timeout=timeout,
                    proxies=proxies,
                    allow_redirects=allow_redirects,
                )

                if (resp.status_code in self.retry_for_statuses) and (attempt < self.max_retries):
                    self._sleep_backoff(attempt);
                    continue

                if raise_for_status and not (200 <= resp.status_code < 300):
                    # 读取部分文本以便调试
                    try:
                        text = resp.text
                    except Exception:
                        text = "<binary response>"
                    raise HttpError(resp.status_code, text, full_url)

                return resp

            except creq.RequestsError as e:
                last_exc = e
                if attempt < self.max_retries:
                    self._sleep_backoff(attempt);
                    continue
                raise
            except Exception as e:
                last_exc = e
                if attempt < self.max_retries:
                    self._sleep_backoff(attempt);
                    continue
                raise
        if last_exc: raise last_exc
        raise RuntimeError("Unknown request failure")

    def _sleep_backoff(self, attempt: int) -> None:
        time.sleep((2 ** attempt) * self.backoff_factor)

    def _do_request_compat(self, **kwargs):
        """
        兼容不同版本 curl-cffi：优先带 http2 调用，若不支持关键字则回退。
        """
        return self.session.request(**kwargs)

    # ---------- 便捷方法 ----------
    def get(self, url: str, **kw) -> creq.Response:
        return self.request("GET", url, **kw)

    def get_format(self, url: str, **kw) -> dict[str, Any]:
        return self.format_response(self.get(url, **kw))

    def post_json_format(self, url: str, **kw) -> dict[str, Any]:
        return self.format_response(self.post_json(url, **kw))

    def post_json(self, url: str, json: JSONType, **kw) -> creq.Response:
        # 对 XHR/Fetch 友好，默认走 XHR 预设；如需页面导航风格可在 kw 传 use_html_preset=True
        h = {"Accept": "application/json"}
        headers = kw.pop("headers", {})
        headers = {**h, **headers}
        return self.request("POST", url, json=json, headers=headers, **kw)

    def post_form(self, url: str, form: Mapping[str, Any], **kw) -> creq.Response:
        headers = kw.pop("headers", {})
        headers = {"Content-Type": "application/x-www-form-urlencoded", **headers}
        return self.request("POST", url, data=form, headers=headers, **kw)

    def post_multipart(self, url: str, form: Optional[Mapping[str, Any]] = None,
                       files: Optional[Dict[str, Tuple[str, bytes, str]]] = None, **kw) -> creq.Response:
        # multipart 的 boundary 让底层自动生成，不手动写 Content-Type
        return self.request("POST", url, data=form or {}, files=files, **kw)

    # ---------- Cookie 导入/导出（两种格式） ----------
    def add_cookie(self, name: str, value: str, domain: Optional[str] = None, path: str = "/",
                   secure: bool = False, http_only: bool = False,
                   same_site: Optional[str] = None, expires: Optional[float] = None) -> None:
        rest = {}
        if http_only: rest["HttpOnly"] = True
        if same_site: rest["SameSite"] = str(same_site).capitalize()
        exp = int(expires) if isinstance(expires, (int, float)) else None
        self._set_cookie_compat(
            name=name,
            value=value,
            domain=domain or "",
            path=path or "/",
            secure=bool(secure),
            httponly=bool(http_only),
            samesite=(str(same_site).capitalize() if same_site else None),
            expires=exp
        )

    def clear_cookies(self) -> None:
        self.session.cookies.clear()

    def export_cookies_json(self) -> List[dict]:
        out = []
        for c in self._iter_cookie_objects():
            rest = getattr(c, "_rest", {}) or {}
            http_only = bool(rest.get("HttpOnly") or rest.get("httponly"))
            same_site = (rest.get("SameSite") or rest.get("samesite") or "")
            same_site = str(same_site).lower() if same_site else ""
            session_flag = (getattr(c, "expires", None) is None)
            host_only = not bool(getattr(c, "domain", ""))

            out.append({
                "name": getattr(c, "name", "") or "",
                "value": getattr(c, "value", "") or "",
                "domain": getattr(c, "domain", "") or "",
                "hostOnly": host_only,
                "path": getattr(c, "path", "/") or "/",
                "secure": bool(getattr(c, "secure", False)),
                "httpOnly": http_only,
                "sameSite": same_site or "lax",
                "session": session_flag,
                "firstPartyDomain": "",
                "partitionKey": None,
                "expirationDate": float(c.expires) if getattr(c, "expires", None) is not None else None,
                "storeId": None,
            })
        return out



    def get_cookie_by_name(self, name: str) -> Optional[str]:
        cookie_json = self.export_cookies_json()
        for c in cookie_json:
            if c.get("name") == name:
                return c.get("value")
        return None

#resp: creq.Response,
    def format_response_object(self,response: creq.Response, model_class: Type[T] = None) -> Union[T, dict, list, str]:
        """
        根据 response 内容自动格式化返回值：
        - 若响应是 JSON 且提供了 model_class，则返回该类的实例；
        - 若响应是 JSON 但未提供 model_class，则返回 dict/list；
        - 否则返回原始文本（str）。
        
        支持 Pydantic v1 和 v2 模型。
        """
        try:
            json_data = response.json()  # curl_cffi 的 .json() 已处理编码
        except (ValueError, json.JSONDecodeError):
            return response.text

        if model_class is None:
            return json_data

        # 尝试 Pydantic v2
        if hasattr(model_class, "model_validate"):
            return model_class.model_validate(json_data)
        # 回退到 Pydantic v1
        elif hasattr(model_class, "parse_obj"):
            return model_class.parse_obj(json_data)
        else:
            raise TypeError(
                f"model_class must be a Pydantic model (v1 or v2), got {model_class}"
            )
    def _set_cookie_compat(
            self,
            *,
            name: str,
            value: str,
            domain: str,
            path: str,
            secure: bool,
            httponly: bool,
            samesite: Optional[str],
            expires: Optional[int],
    ) -> None:
        """
        逐步降级尝试不同签名，确保在老版本也不报错。
        """
        jar = self.session.cookies
        print(f'name={name}, value={value}, domain={domain}, path={path}, secure={secure}, httponly={httponly}, samesite={samesite}, expires={expires}')
        # 1) 全参数尝试
        try:
            return jar.set(
                name,
                value,
                domain=domain,
                path=path,
                secure=secure,
                httponly=httponly,  # 有的版本用 httponly
                samesite=samesite,
                expires=expires,
            )
        except TypeError:
            print("[WARNING] 1 Cookie samesite/expires is not supported by your version of requests.cookies.set().")

        # 2) 去掉 expires
        try:
            return jar.set(
                name,
                value,
                domain=domain,
                path=path,
                secure=secure,
                httponly=httponly,
                samesite=samesite,
            )
        except TypeError:
            print("[WARNING] 2 Cookie expires is not supported by your version of requests.cookies.set().")
        # 3) 只保留 secure
        try:
            print(f'3 Setting cookie: {name}={value}; domain={domain}; path={path}; secure={secure}; httponly={httponly}; samesite={samesite} ')
            return jar.set(
                name,
                value,
                domain=domain,
                path=path,
                secure=secure,
            )
        except TypeError:
            print("[WARNING] 3 Cookie samesite is not supported by your version of requests.cookies.set().")

        # 4) 最小签名（最广兼容）
        try:
            print(f'4 Setting cookie: {name}={value}; domain={domain}; path={path}; secure={secure}; httponly={httponly}; samesite={samesite} ')

            return jar.set(name, value, domain=domain, path=path)
        except TypeError:
            # 5) 某些极老版本只接受位置参数
            print(f'5 Setting cookie: {name}={value}; domain={domain}; path={path}; secure={secure}; httponly={httponly}; samesite={samesite} ')

            print("[WARNING] 4 Cookie domain/path is not supported by your version of requests.cookies.set().")
            return jar.set(name, value, domain, path)

    def import_cookies_json(self, cookies: Union[str, List[dict]]) -> None:
        """
        支持两种输入格式：
        1. Python对象（list[dict]）
        2. JSON字符串（自动解析）

        示例：
            cli.import_cookies_json('[{"name": "sid", "value": "abc"}]')
        """
        # ✅ 如果传入字符串，先自动解析
        if isinstance(cookies, str):
            try:
                cookies = json.loads(cookies)
            except Exception as e:
                raise ValueError(f"Invalid cookie JSON string: {e}")

        # ✅ 确保是 list
        if not isinstance(cookies, list):
            raise TypeError("cookies must be a list or a JSON string representing a list")

        for item in cookies:
            if not isinstance(item, dict):
                continue  # 忽略异常条目

            self.add_cookie(
                name=item.get("name", ""),
                value=item.get("value", ""),
                domain=item.get("domain") or None,
                path=item.get("path") or "/",
                secure=bool(item.get("secure", False)),
                http_only=bool(item.get("httpOnly", False)),
                same_site=item.get("sameSite"),
                expires=int(item["expirationDate"]) if isinstance(item.get("expirationDate"), (int, float)) else None
            )

    def format_response(
            self,
            resp: creq.Response,
            *,
            prefer_json: bool = True,  # 优先尝试按 JSON 解析
            max_text_chars: Optional[int] = None,  # 限制文本长度（None 不截断）
    ) -> dict:
        """
        将 curl-cffi Response 格式化为:
        {
          "status": "success"|"fail",
          "status_code": int,
          "url": str,
          "body_type": "json"|"text",
          "body": <json-obj or str>,
          "response_headers": { ... }
        }
        """
        headers = dict(getattr(resp, "headers", {}) or {})
        ctype = (headers.get("Content-Type") or "").lower()
        status_ok = 200 <= resp.status_code < 300
        status_str = "success" if status_ok else "fail"

        body: Any
        body_type = "text"

        def _as_text() -> str:
            # 优先用 resp.text；若失败，用 content 解码兜底
            try:
                text = resp.text
            except Exception:
                try:
                    text = resp.content.decode("utf-8", errors="replace")
                except Exception:
                    text = ""
            if isinstance(max_text_chars, int) and max_text_chars >= 0 and len(text) > max_text_chars:
                text = text[:max_text_chars] + "…"
            return text

        def _try_json_first() -> Tuple[bool, Any]:
            # 判断是否应按 JSON 解析
            looks_json = (
                    "application/json" in ctype
                    or ctype.endswith("+json")
                    or (prefer_json and (resp.content[:1] in (b"{", b"[") or str(
                resp.text[:1] if hasattr(resp, "text") else "").strip() in ("{", "[")))
            )
            if not looks_json:
                return False, None
            try:
                return True, resp.json()
            except Exception:
                # 再尝试从 text 解析
                try:
                    import json as _json
                    return True, _json.loads(_as_text())
                except Exception:
                    return False, None

        parsed, jval = _try_json_first()
        if parsed:
            body_type = "json"
            body = jval
        else:
            body_type = "text"
            body = _as_text()

        return {
            "status": status_str,
            "status_code": resp.status_code,
            "url": getattr(resp, "url", ""),
            "body_type": body_type,
            "body": body,
            "response_headers": headers,
        }

    def _iter_cookie_objects(self):
        """
        兼容不同实现：统一产出带 .name/.value/.domain/.path/.secure/.expires 的对象。
        优先：直接迭代 -> 若得到的不是对象则降级 -> 读 _cookies 映射 -> 最后 items() 拼临时对象
        """
        jar = self.session.cookies

        # 1) 直接尝试迭代，看是否得到 Cookie 对象
        try:
            got_any = False
            tmp_buf = []
            for c in jar:
                got_any = True
                if hasattr(c, "name") and hasattr(c, "value"):
                    tmp_buf.append(c)
                else:
                    # 不是 Cookie 对象，走降级路径
                    raise TypeError
            if got_any:
                for c in tmp_buf:
                    yield c
                return
        except Exception:
            pass

        # 2) 访问 requests 风格的内部结构 _cookies: {domain: {path: {name: Cookie}}}
        _cookies = getattr(jar, "_cookies", None)
        if isinstance(_cookies, dict):
            for domain_map in _cookies.values():
                for path_map in domain_map.values():
                    for c in path_map.values():
                        yield c
            return

        # 3) 再不行就用 (name, value) 项构造一个“最小”对象
        try:
            for name, value in jar.items():
                class _C:  # 轻量占位对象
                    __slots__ = ("name", "value", "domain", "path", "secure", "expires", "_rest")

                c = _C()
                c.name = name
                c.value = value
                c.domain = ""
                c.path = "/"
                c.secure = False
                c.expires = None
                c._rest = {}
                yield c
            return
        except Exception:
            return

    def export_cookies_header(self, include_prefix: bool = False) -> str:
        parts = [f"{c.name}={c.value}" for c in self._iter_cookie_objects() if getattr(c, "name", None)]
        s = "; ".join(parts)
        return f"Cookie: {s}" if include_prefix else s

    def import_cookies_header(self, cookie_header: str, *, domain: Optional[str] = None, path: str = "/") -> None:
        s = cookie_header.strip()
        if s.lower().startswith("cookie:"):
            s = s.split(":", 1)[1].strip()
        pairs = re.findall(r'\s*([^=;\s]+)\s*=\s*([^=;\s]*)\s*', s)
        for name, value in pairs:
            #print(f'''Importing cookie from header: {name}={value}''')
            self.add_cookie(name=name, value=value, domain=domain, path=path)

    def list_cookies(self) -> List[dict]:
        return [
            {
                "name": getattr(c, "name", ""),
                "value": getattr(c, "value", ""),
                "domain": getattr(c, "domain", ""),
                "path": getattr(c, "path", "/") or "/",
            }
            for c in self._iter_cookie_objects()
            if getattr(c, "name", None)
        ]


if __name__ == "__main__":
    with HttpClient(
            base_url="https://httpbin.org",
            # 可改成 en-US 等
            accept_language="zh-CN,zh;q=0.9,en-US;q=0.7,en;q=0.6",
            impersonate="firefox",  # ★ 关键
            http2=True,
            max_retries=2,
            backoff_factor=0.5,
    ) as cli:
        # HTML 导航式 GET（像在地址栏打开页面）
        r1 = cli.get("/headers", use_html_preset=True, headers={"DNT": "1"})
        print("HTML-like headers:", r1.json()["headers"])

        # XHR/Fetch 风格的 JSON POST（API 调用）
        r2 = cli.post_json(
            "/anything",
            json={"hello": "world"},
            origin="https://httpbin.org",  # 某些站点会校验
            referer="https://httpbin.org/",
            use_html_preset=False  # XHR 预设
        )
        print("XHR-like UA:", r2.json()["headers"].get("User-Agent"))

        # 导入/导出 Cookie（JSON 格式 & Header 字符串）
        cli.add_cookie("sid", "abc123", domain="httpbin.org", path="/", secure=True, http_only=True)
        print("Cookie header:", cli.export_cookies_header())

        dump = cli.export_cookies_json()
        cli.clear_cookies()
        cli.import_cookies_json(dump)
        r3 = cli.get("/cookies")
        print("Server sees cookies:", r3.json())
