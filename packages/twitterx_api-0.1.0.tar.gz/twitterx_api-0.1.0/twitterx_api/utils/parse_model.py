from typing import List, Tuple, Optional

from pydantic import RootModel

from twitterx_api.types.response_base import ResponseData
from twitterx_api.types.search_model import Instruction, SearchRootModel, TimelineCursorContent, TimelineItemEntryContent, TimelineModuleEntryContent, TimelineTweetContent, TimelineUserContent
from twitterx_api.types.user_tweets import UserTweetsData

def parse_tweet_entries(data: dict) -> Tuple[List[dict], Optional[str], Optional[str]]:
    """ Tweet """
    root = SearchRootModel(**data)
    tweets = []
    top_cursor = bottom_cursor = None

    for instr in root.data.search_by_raw_query.search_timeline.timeline.instructions:
        if instr.type == "TimelineAddEntries" and instr.entries:
            for entry in instr.entries:
                cont = entry.content
                if isinstance(cont, TimelineCursorContent):
                    if cont.cursorType == "Top":
                        top_cursor = cont.value
                    elif cont.cursorType == "Bottom":
                        bottom_cursor = cont.value
                elif isinstance(cont, TimelineItemEntryContent):
                    if isinstance(cont.itemContent, TimelineTweetContent):
                        tweets.append(cont.itemContent.tweet_results["result"].dict())

    return tweets, top_cursor, bottom_cursor


def parse_user_entries(data: dict) -> Tuple[List[dict], Optional[str], Optional[str]]:
    """ User """
    root = SearchRootModel(**data)
    users = []
    top_cursor = bottom_cursor = None

    for instr in root.data.search_by_raw_query.search_timeline.timeline.instructions:
        if instr.type == "TimelineAddEntries" and instr.entries:
            for entry in instr.entries:
                cont = entry.content
                if isinstance(cont, TimelineCursorContent):
                    if cont.cursorType == "Top":
                        top_cursor = cont.value
                    elif cont.cursorType == "Bottom":
                        bottom_cursor = cont.value
                elif isinstance(cont, TimelineItemEntryContent):
                    if isinstance(cont.itemContent, TimelineUserContent):
                        users.append(cont.itemContent.user_results["result"].dict())
                elif isinstance(cont, TimelineModuleEntryContent):
                    # 处理 module 中的 user（如第四个 JSON）
                    for item_wrap in cont.items:
                        item_data = item_wrap.item
                        icontent = item_data.get("itemContent", {})
                        if icontent.get("itemType") == "TimelineUser":
                            user_res = icontent.get("user_results", {}).get("result")
                            if user_res:
                                # 手动构造简化版（因嵌套未完全建模）
                                users.append({
                                    "rest_id": user_res.get("rest_id"),
                                    "name": user_res.get("core", {}).get("name"),
                                    "screen_name": user_res.get("core", {}).get("screen_name"),
                                    "description": user_res.get("legacy", {}).get("description"),
                                })

    return users, top_cursor, bottom_cursor


def parse_list_entries(data: dict) -> Tuple[List[dict], Optional[str], Optional[str]]:
    """ List  TimelineTimelineModule """
    root = SearchRootModel(**data)
    lists = []
    top_cursor = bottom_cursor = None
    instrs : List[Instruction] = root.data.search_by_raw_query.search_timeline.timeline.instructions
    for instr in instrs:
        if instr.type == "TimelineAddEntries" and instr.entries:
            for entry in instr.entries:
                cont = entry.content
                if isinstance(cont, TimelineCursorContent):
                    if cont.cursorType == "Top":
                        top_cursor = cont.value
                    elif cont.cursorType == "Bottom":
                        bottom_cursor = cont.value
                elif isinstance(cont, TimelineModuleEntryContent):
                    for item_wrap in cont.items:
                        item_data = item_wrap.item
                        icontent = item_data.get("itemContent", {})
                        if icontent.get("itemType") == "TimelineTwitterList":
                            tlist = icontent.get("list", {})
                            lists.append({
                                "id_str": tlist.get("id_str"),
                                "name": tlist.get("name"),
                                "description": tlist.get("description"),
                                "member_count": tlist.get("member_count"),
                                "owner": tlist.get("user_results", {}).get("result", {}).get("core", {})
                            })

    return lists, top_cursor, bottom_cursor


def parse_all_entries(data: dict) -> dict:
    tweets, top1, bot1 = parse_tweet_entries(data)
    users, top2, bot2 = parse_user_entries(data)
    lists, top3, bot3 = parse_list_entries(data)

    # 合并 cursor（优先非空）
    top_cursor = top1 or top2 or top3
    bottom_cursor = bot1 or bot2 or bot3
    dataLists = tweets or users or lists
    return {
        "lists": dataLists,
        "top_cursor": top_cursor,
        "bottom_cursor": bottom_cursor
    }

def extract_tweets_info(response_data:ResponseData[UserTweetsData]) -> dict:
    """
    Extract top cursor, bottom cursor, and list of tweets from ResponseData[UserTweetsData].
    
    Args:
        response_data: ResponseData[UserTweetsData] model
        
    Returns:
        tuple: (top_cursor, bottom_cursor, tweets_list)
    """
    top_cursor = None
    bottom_cursor = None
    tweets_list = []
    from twitterx_api.types.user_tweets import Instruction
    # Navigate to instructions
    instructions:List[Instruction] = response_data.data.user.result.timeline.instructions
    
    for instruction in instructions:
        if instruction.type == "TimelineAddEntries" and instruction.entries:
            for entry in instruction.entries:
                # Check if it's a cursor entry
                if hasattr(entry.content, 'cursorType'):
                    if entry.content.cursorType == "Top":
                        top_cursor = entry.content.value
                    elif entry.content.cursorType == "Bottom":
                        bottom_cursor = entry.content.value
                
                # Check if it's a tweet entry
                elif hasattr(entry.content, 'itemContent') and \
                     hasattr(entry.content.itemContent, 'tweet_results') and \
                     entry.content.itemContent.tweet_results.result.legacy:
                    tweets_list.append(entry.content.itemContent.tweet_results.result.legacy)
    
    return {
        "lists": tweets_list,
        "top_cursor": top_cursor,
        "bottom_cursor": bottom_cursor
    }