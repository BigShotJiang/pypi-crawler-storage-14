from urllib.parse import urlparse
import bs4
import requests
from x_client_transaction import ClientTransaction
from x_client_transaction.utils import generate_headers, handle_x_migration, get_ondemand_file_url

from twitterx_api.constants import USER_AGENT
def generate_x_transaction_id(url:str,method:str) -> str:
    session = requests.Session()
    session.headers = generate_headers()
    session.headers.update({
        "User-Agent": USER_AGENT,
    })
    home_page_response = handle_x_migration(session=session)
    home_page = session.get(url="https://x.com")
    home_page_response = bs4.BeautifulSoup(home_page.content, 'html.parser')
    ondemand_file_url = get_ondemand_file_url(response=home_page_response)
    ondemand_file = session.get(url=ondemand_file_url)
    ondemand_file_response = ondemand_file.text
    path = urlparse(url=url).path
    ct = ClientTransaction(home_page_response=home_page_response,
                       ondemand_file_response=ondemand_file_response)
    return  ct.generate_transaction_id(method=method, path=path)
    