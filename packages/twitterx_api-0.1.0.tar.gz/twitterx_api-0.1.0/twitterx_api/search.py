
from typing import Optional, Union
from twitterx_api.auth import Auth
from twitterx_api.constants import X_SEARCH_URL
from twitterx_api.types.types import SearchType
from twitterx_api.types.response_base import ResponseData
from twitterx_api.types.profile import UserData
import json

from twitterx_api.utils.parse_model import parse_all_entries

class Search:
    def __init__(self, auth: Auth):
        self.auth = auth
    
    def search(
        self,
        query: str,
        count: int = 20,
        cursor: Optional[str] = None,
        search_type: Optional[Union[SearchType,str]] = SearchType.Latest,
    ) -> dict:
        """Perform a search.

        `search_type` may be a `SearchType` enum member or a raw string.
        """
        # Accepts the enum but does not change behavior here; implementation
        # can convert `search_type` with `search_type.value` when used.
        # ---- Input validation ----
        if not isinstance(query, str) or not query.strip():
            raise ValueError("query must be a non-empty string")

        if not isinstance(count, int) or count <= 0:
            raise ValueError("count must be a positive integer")
        
        if cursor is not None and not isinstance(cursor, str):
            raise ValueError("cursor must be a string when provided")

        # ---- Normalize search_type ----
        if search_type is None:
            search_type_val = SearchType.Latest.value
        elif isinstance(search_type, SearchType):
            search_type_val = search_type.value
        elif isinstance(search_type, str):
            # accept case-insensitive names that match the enum
            normalized = search_type.strip()
            matches = [s for s in SearchType.__members__.keys() if s.lower() == normalized.lower()]
            if matches:
                search_type_val = SearchType[matches[0]].value
            elif normalized in [e.value for e in SearchType]:
                search_type_val = normalized
            else:
                raise ValueError(f"invalid search_type: {search_type}")
        else:
            raise TypeError("search_type must be a SearchType or a string")

        variables = {
            "rawQuery": query,
            "count": count,
            "querySource": "typed_query",
            "product": search_type_val,
            "withGrokTranslatedBio": False,
        }
        if cursor:
            variables["cursor"] = cursor
        features = {
            "rweb_video_screen_enabled": False,
            "payments_enabled": False,
            "profile_label_improvements_pcf_label_in_post_enabled": True,
            "responsive_web_profile_redirect_enabled": False,
            "rweb_tipjar_consumption_enabled": True,
            "verified_phone_label_enabled": False,
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "premium_content_api_read_enabled": False,
            "communities_web_enable_tweet_community_results_fetch": True,
            "c9s_tweet_anatomy_moderator_badge_enabled": True,
            "responsive_web_grok_analyze_button_fetch_trends_enabled": False,
            "responsive_web_grok_analyze_post_followups_enabled": True,
            "responsive_web_jetfuel_frame": True,
            "responsive_web_grok_share_attachment_enabled": True,
            "articles_preview_enabled": True,
            "responsive_web_edit_tweet_api_enabled": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
            "view_counts_everywhere_api_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "responsive_web_twitter_article_tweet_consumption_enabled": True,
            "tweet_awards_web_tipping_enabled": False,
            "responsive_web_grok_show_grok_translated_post": True,
            "responsive_web_grok_analysis_button_from_backend": True,
            "creator_subscriptions_quote_tweet_preview_enabled": False,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "standardized_nudges_misinfo": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "longform_notetweets_inline_media_enabled": True,
            "responsive_web_grok_image_annotation_enabled": True,
            "responsive_web_grok_imagine_annotation_enabled": True,
            "responsive_web_grok_community_note_auto_translation_is_enabled": False,
            "responsive_web_enhance_cards_enabled": False
        }
        params = {"variables": json.dumps(variables), "features": json.dumps(features)}

        try:
            return self.auth.get(X_SEARCH_URL, params=params)
        except Exception as e:
            # bubble up a clearer error for callers
            raise RuntimeError(f"search request failed: {e}") from e
