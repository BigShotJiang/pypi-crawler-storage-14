from typing import List, Optional, Union, Dict, Any
from pydantic import BaseModel

# === 公共结构 ===
class CoreUser(BaseModel):
    name: str
    screen_name: str
    created_at: str

class UserLegacy(BaseModel):
    description: str
    followers_count: int
    friends_count: int
    statuses_count: int
    url: Optional[str] = None

class Avatar(BaseModel):
    image_url: str

class UserResult(BaseModel):
    __typename: str
    rest_id: str
    core: CoreUser
    legacy: UserLegacy
    avatar: Avatar

# === Tweet 条目 ===
class TweetLegacy(BaseModel):
    id_str: str
    full_text: str
    created_at: str
    favorite_count: int
    retweet_count: int
    quote_count: int
    reply_count: int
    retweet_count: int
    bookmark_count: int
    lang: str
    created_at: str

class TweetResult(BaseModel):
    __typename: str
    rest_id: str
    core: Dict[str, UserResult]  # user_results.result
    legacy: TweetLegacy

class TimelineTweetContent(BaseModel):
    itemType: str  # "TimelineTweet"
    tweet_results: Dict[str, TweetResult]

# === User 条目 ===
class TimelineUserContent(BaseModel):
    itemType: str  # "TimelineUser"
    user_results: Dict[str, UserResult]

# === List 条目（嵌套）===
class ListOwner(BaseModel):
    rest_id: str
    name: str
    screen_name: str

class TwitterList(BaseModel):
    id_str: str
    name: str
    description: str
    member_count: int
    subscriber_count: int
    user_results: Dict[str, UserResult]

class TimelineTwitterListContent(BaseModel):
    itemType: str  # "TimelineTwitterList"
    list: TwitterList

# === 通用 Item 包装（用于 Module 内）===
class ModuleItem(BaseModel):
    entryId: str
    item: Dict[str, Any]  # 动态内容，需后续解析

# === Entry 内容分发 ===
class TimelineItemEntryContent(BaseModel):
    entryType: str  # "TimelineTimelineItem"
    itemContent: Union[TimelineTweetContent, TimelineUserContent]

class TimelineModuleEntryContent(BaseModel):
    entryType: str  # "TimelineTimelineModule"
    items: List[ModuleItem]

class TimelineCursorContent(BaseModel):
    entryType: str  # "TimelineTimelineCursor"
    cursorType: str  # "Top" or "Bottom"
    value: str

# === Entry 统一模型 ===
class Entry(BaseModel):
    entryId: str
    sortIndex: str
    content: Union[
        TimelineItemEntryContent,
        TimelineModuleEntryContent,
        TimelineCursorContent
    ]

# === 最外层结构 ===
class Instruction(BaseModel):
    type: str
    entries: Optional[List[Entry]] = None

class Timeline(BaseModel):
    instructions: List[Instruction]

class SearchTimeline(BaseModel):
    timeline: Timeline

class SearchByRawQuery(BaseModel):
    search_timeline: SearchTimeline

class Data(BaseModel):
    search_by_raw_query: SearchByRawQuery

class SearchRootModel(BaseModel):
    data: Data