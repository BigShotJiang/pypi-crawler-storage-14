from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from .common import Location, MediaPermissions, Privacy, RelationshipPerspectives, CoreUser

class UserProfileBio(BaseModel):
    description: str

class Verification(BaseModel):
    verified: bool

class EntitiesDescription(BaseModel):
    urls: List[Any]

class Entities(BaseModel):
    description: EntitiesDescription

class LegacyUser(BaseModel):
    default_profile: bool
    default_profile_image: bool
    description: str
    entities: Entities
    fast_followers_count: int
    favourites_count: int
    followers_count: int
    friends_count: int
    has_custom_timelines: bool
    is_translator: bool
    listed_count: int
    media_count: int
    needs_phone_verification: bool
    normal_followers_count: int
    pinned_tweet_ids_str: List[str]
    possibly_sensitive: bool
    profile_interstitial_type: str
    statuses_count: int
    translator_type: str
    want_retweets: bool
    withheld_in_countries: List[Any]

class UserResult(BaseModel):
    __typename: str = Field(..., alias='__typename')
    id: str
    rest_id: str
    affiliates_highlighted_label: Dict[Any, Any]
    avatar: Dict[str, str]
    core: CoreUser
    dm_permissions: Dict[str, bool]
    follow_request_sent: bool
    has_graduated_access: bool
    is_blue_verified: bool
    legacy: LegacyUser
    location: Location
    media_permissions: MediaPermissions
    parody_commentary_fan_label: str
    profile_image_shape: str
    profile_bio: UserProfileBio
    privacy: Privacy
    relationship_perspectives: RelationshipPerspectives
    tipjar_settings: Dict[Any, Any]
    verification: Verification
    profile_description_language: str

class UserResults(BaseModel):
    result: UserResult

class Core(BaseModel):
    user_results: UserResults

class EditControl(BaseModel):
    edit_tweet_ids: List[str]
    editable_until_msecs: str
    is_edit_eligible: bool
    edits_remaining: str

class Views(BaseModel):
    state: str

class GrokTranslatedPostWithAvailability(BaseModel):
    is_available: bool

class EntitiesTweet(BaseModel):
    hashtags: List[Any]
    symbols: List[Any]
    timestamps: List[Any]
    urls: List[Any]
    user_mentions: List[Dict[str, Any]]

class LegacyTweet(BaseModel):
    bookmark_count: int
    bookmarked: bool
    created_at: str
    conversation_id_str: str
    display_text_range: List[int]
    entities: EntitiesTweet
    favorite_count: int
    favorited: bool
    full_text: str
    in_reply_to_screen_name: str
    in_reply_to_status_id_str: str
    in_reply_to_user_id_str: str
    is_quote_status: bool
    lang: str
    quote_count: int
    reply_count: int
    retweet_count: int
    retweeted: bool
    user_id_str: str
    id_str: str

class Result(BaseModel):
    rest_id: str
    core: Core
    unmention_data: Dict[Any, Any]
    edit_control: EditControl
    is_translatable: bool
    views: Views
    source: str
    grok_translated_post_with_availability: GrokTranslatedPostWithAvailability
    grok_analysis_button: bool
    legacy: LegacyTweet
    unmention_info: Dict[Any, Any]

class TweetResults(BaseModel):
    result: Result

class CreateTweet(BaseModel):
    tweet_results: TweetResults

class TweetData(BaseModel):
    create_tweet: CreateTweet