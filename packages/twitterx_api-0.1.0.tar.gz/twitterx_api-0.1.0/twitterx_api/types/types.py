from typing import TypeVar
from pydantic import BaseModel
from enum import Enum

T = TypeVar("T", bound=BaseModel)


class SearchType(Enum):
	List = "List"
	Latest = "Latest"
	Top = "Top"
	People = "People"

class MediaFile(BaseModel):
    data: bytes
    media_type: str