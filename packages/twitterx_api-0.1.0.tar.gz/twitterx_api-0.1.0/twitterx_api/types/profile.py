from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from .common_types import Location, MediaPermissions, Privacy, RelationshipPerspectives, CoreUser, UrlEntity

class Entities(BaseModel):
    description: Optional[Dict[str, List]] = None
    url: Optional[Dict[str, List[UrlEntity]]] = None

class LegacyUser(BaseModel):
    default_profile: bool
    default_profile_image: bool
    description: str
    entities: Entities
    fast_followers_count: int
    favourites_count: int
    followers_count: int
    friends_count: int
    has_custom_timelines: bool
    is_translator: bool
    listed_count: int
    media_count: int
    normal_followers_count: int
    pinned_tweet_ids_str: List[str]
    possibly_sensitive: bool
    profile_banner_url: Optional[str] = None
    profile_interstitial_type: str
    statuses_count: int
    translator_type: str
    url: str
    want_retweets: bool
    withheld_in_countries: List[str]

class Avatar(BaseModel):
    image_url: str

class DmPermissions(BaseModel):
    can_dm: bool

class Professional(BaseModel):
    rest_id: str
    professional_type: str
    category: List[Any]

class ProfileBio(BaseModel):
    description: str

class TipjarSettings(BaseModel):
    is_enabled: bool
    bitcoin_handle: Optional[str] = None
    cash_app_handle: Optional[str] = None
    ethereum_handle: Optional[str] = None
    venmo_handle: Optional[str] = None

class Birthdate(BaseModel):
    day: int
    month: int
    visibility: str
    year_visibility: str

class LegacyExtendedProfile(BaseModel):
    birthdate: Birthdate

class VerificationReasonEntityRef(BaseModel):
    url: str
    url_type: str

class VerificationReasonEntity(BaseModel):
    from_index: int
    to_index: int
    ref: VerificationReasonEntityRef

class VerificationReasonDescription(BaseModel):
    text: str
    entities: List[VerificationReasonEntity]

class VerificationReason(BaseModel):
    description: VerificationReasonDescription
    verified_since_msec: str

class VerificationInfo(BaseModel):
    is_identity_verified: bool
    reason: VerificationReason

class UserResult(BaseModel):
    __typename: str = Field(alias="__typename")
    id: str
    rest_id: str
    affiliates_highlighted_label: Dict[str, Any]
    avatar: Avatar
    core: CoreUser
    dm_permissions: DmPermissions
    follow_request_sent: bool
    has_graduated_access: bool
    is_blue_verified: bool
    legacy: LegacyUser
    location: Location
    media_permissions: MediaPermissions
    parody_commentary_fan_label: str
    profile_image_shape: str
    professional: Professional
    profile_bio: ProfileBio
    privacy: Privacy
    relationship_perspectives: RelationshipPerspectives
    tipjar_settings: TipjarSettings
    super_follow_eligible: bool
    verification: Dict[str, bool]  # {"verified": false}
    profile_description_language: str
    grok_translated_bio_with_availability: Dict[str, bool]
    legacy_extended_profile: LegacyExtendedProfile
    is_profile_translatable: bool
    has_hidden_subscriptions_on_profile: bool
    verification_info: VerificationInfo
    highlights_info: Dict[str, Any]
    user_seed_tweet_count: int
    premium_gifting_eligible: bool
    business_account: Dict[str, Any]
    creator_subscriptions_count: int

class UserContainer(BaseModel):
    result: UserResult

class UserData(BaseModel):
    user: UserContainer