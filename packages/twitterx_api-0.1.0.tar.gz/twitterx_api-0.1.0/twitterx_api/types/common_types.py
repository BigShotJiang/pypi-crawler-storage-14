from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class Location(BaseModel):
    location: str

class MediaPermissions(BaseModel):
    can_media_tag: bool

class Privacy(BaseModel):
    protected: bool

class RelationshipPerspectives(BaseModel):
    following: bool

class CoreUser(BaseModel):
    created_at: str
    name: str
    screen_name: str

class UrlEntity(BaseModel):
    display_url: str
    expanded_url: str
    url: str
    indices: List[int]