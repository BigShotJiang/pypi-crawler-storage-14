from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel, Field

from twitterx_api.types.response_base import ResponseData

from .common_types import (
    Location, 
    Privacy, 
    CoreUser
)
from .tweet import (
    Core as TweetCore,
    EditControl,
    Views,
    LegacyTweet,
)

class SocialContext(BaseModel):
    """
    Represents contextual information about a tweet's social engagement
    """
    type: str
    contextType: str
    text: str

class MediaItem(BaseModel):
    """
    Simplified media information for tweets
    """
    display_url: str
    expanded_url: str
    media_url_https: str
    type: str
    url: str

class EntitiesTweetItem(BaseModel):
    """
    Text entity information in tweets
    """
    hashtags: List[Any]
    symbols: List[Any]
    timestamps: List[Any]
    urls: List[Any]
    user_mentions: List[Dict[str, Any]]

class ExtendedEntities(BaseModel):
    """
    Extended media entities in tweets
    """
    media: List[MediaItem]

class RetweetedStatusResultResult(BaseModel):
    """
    Information about retweeted content
    """
    typename: str = Field(alias="__typename")
    rest_id: str
    core: TweetCore
    edit_control: EditControl
    is_translatable: bool
    views: Views
    source: str
    legacy: LegacyTweet

class RetweetedStatusResult(BaseModel):
    result: RetweetedStatusResultResult

class TimelineTweetLegacy(BaseModel):
    """
    Essential legacy tweet information
    """
    bookmark_count: int
    bookmarked: bool
    created_at: str
    conversation_id_str: str
    entities: EntitiesTweetItem
    extended_entities: Optional[ExtendedEntities] = None
    favorite_count: int
    favorited: bool
    full_text: str
    is_quote_status: bool
    lang: str
    possibly_sensitive: bool
    quote_count: int
    reply_count: int
    retweet_count: int
    retweeted: bool
    user_id_str: str
    id_str: str
    retweeted_status_result: Optional[RetweetedStatusResult] = None

class ItemContentTweetResultsResult(BaseModel):
    """
    Main tweet result information
    """
    typename: str = Field(alias="__typename")
    rest_id: str
    core: TweetCore
    edit_control: EditControl
    is_translatable: bool
    views: Views
    source: str
    legacy: TimelineTweetLegacy

class TweetResultsItem(BaseModel):
    result: ItemContentTweetResultsResult

class ItemContent(BaseModel):
    """
    Content of a timeline item
    """
    itemType: str
    typename: str = Field(alias="__typename")
    tweet_results: TweetResultsItem
    tweetDisplayType: str
    socialContext: Optional[SocialContext] = None

class ContentItem(BaseModel):
    """
    Individual content item in timeline
    """
    entryType: str
    typename: str = Field(alias="__typename")
    itemContent: ItemContent

class Entry(BaseModel):
    """
    Timeline entry
    """
    entryId: str
    sortIndex: str
    content: ContentItem

class TimelineTimelineCursor(BaseModel):
    """
    Cursor for pagination
    """
    entryType: str
    typename: str = Field(alias="__typename")
    value: str
    cursorType: str

class EntryCursor(BaseModel):
    entryId: str
    sortIndex: str
    content: TimelineTimelineCursor

class TimelineAddEntriesInstruction(BaseModel):
    """
    Instruction to add entries to timeline
    """
    type: str
    entries: List[Union[Entry, EntryCursor]]

class Instruction(BaseModel):
    """
    General instruction for timeline operations
    """
    type: str
    entries: Optional[List[Union[Entry, EntryCursor]]] = None

class TimelineInnerTimeline(BaseModel):
    """
    Main timeline structure
    """
    instructions: List[Instruction]

class TimelineTimeline(BaseModel):
    timeline: TimelineInnerTimeline

class TimelineResult(BaseModel):
    typename: str = Field(alias="__typename")
    timeline: TimelineTimeline

class TimelineContainer(BaseModel):
    result: TimelineResult

class UserWithTimeline(BaseModel):
    user: TimelineContainer

class UserTweetsData(BaseModel):
    data: UserWithTimeline