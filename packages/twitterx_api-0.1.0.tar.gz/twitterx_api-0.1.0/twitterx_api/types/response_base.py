from typing import Generic
from pydantic import BaseModel
from twitterx_api.types.types import T

class ResponseData(BaseModel, Generic[T]):
    data: T