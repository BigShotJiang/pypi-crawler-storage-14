
from typing import Union
from urllib.parse import urlparse

from auth import Auth
from twitterx_api.constants import X_SCREEN_NAME_PROFILE_URL
from twitterx_api.types.profile import UserData
from twitterx_api.types.response_base import ResponseData

class Profile:
    def __init__(self,auth:Auth) -> None:
        self.auth = auth
    def profile(self,screen_name:str) -> Union[ResponseData[UserData], dict, list, str]:
        path = urlparse(url=X_SCREEN_NAME_PROFILE_URL).path
        params = {
            "variables":f'{{"screen_name":"{screen_name}","withGrokTranslatedBio":true}}',
            "features":'{"hidden_profile_subscriptions_enabled":true,"payments_enabled":false,"profile_label_improvements_pcf_label_in_post_enabled":true,"responsive_web_profile_redirect_enabled":false,"rweb_tipjar_consumption_enabled":true,"verified_phone_label_enabled":false,"subscriptions_verification_info_is_identity_verified_enabled":true,"subscriptions_verification_info_verified_since_enabled":true,"highlights_tweets_tab_ui_enabled":true,"responsive_web_twitter_article_notes_tab_enabled":true,"subscriptions_feature_can_gift_premium":true,"creator_subscriptions_tweet_preview_api_enabled":true,"responsive_web_graphql_skip_user_profile_image_extensions_enabled":false,"responsive_web_graphql_timeline_navigation_enabled":true}',
            "fieldToggles":'{"withAuxiliaryUserLabels":true}'
        }
        return self.auth.get(url=path,params=params,model_class=ResponseData[UserData])
