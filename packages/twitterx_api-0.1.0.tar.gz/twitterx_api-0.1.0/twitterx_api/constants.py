import time
from twitterx_api.utils.twitter_xpff import XPFFHeaderGenerator

X_AUTHORIZE_TOKEN = "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
XPFF_BASE_KEY = "0e6be1f1e21ffc33590b888fd4dc81b19713e570e805d4e5df80a493c9571a05"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:112.0) Gecko/20100101 Firefox/112.0"
X_BASE_URL = "https://x.com"

X_SCREEN_NAME_PROFILE_URL = 'https://x.com/i/api/graphql/ZHSN3WlvahPKVvUxVQbg1A/UserByScreenName'

# tweet endpoints
X_LIKE_TWEET_URL = 'https://x.com/i/api/graphql/lI07N6Otwv1PhnEgXILM7A/FavoriteTweet'
X_CREATE_TWEET_URL = 'https://x.com/i/api/graphql/MtyT_TbO2PpwaFHNPK2qoQ/CreateTweet'
X_USER_TWEETS_URL = 'https://api.x.com/graphql/oRJs8SLCRNRbQzuZG93_oA/UserTweets'
X_MEDIA_UPLOAD_URL = 'https://upload.twitter.com/1.1/media/upload.json'
X_RETWEET_URL = 'https://x.com/i/api/graphql/LFho5rIi4xcKO90p9jwG7A/CreateRetweet'

#search endpoints
X_SEARCH_URL = 'https://x.com/i/api/graphql/3v0J5l1kYpN0J9t1l1t4RQ/SearchTimeline'
def XPFF_GENERATER(guest_id) -> str:
    timestamp_ms = int(time.time() * 1000)
    ua = f'{{"navigator_properties":{{"hasBeenActive":"true","userAgent":{USER_AGENT},"webdriver":"false"}},"created_at":{timestamp_ms}}}'
    xPFFHeaderGenerator = XPFFHeaderGenerator(XPFF_BASE_KEY)
    return xPFFHeaderGenerator.generate_xpff(ua, guest_id)
