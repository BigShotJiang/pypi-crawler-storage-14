from curl_cffi.requests import Session

def get_impersonated_ua(browser: str = "firefox") -> str:
    with Session() as s:
        resp = s.get("https://httpbin.org/user-agent", impersonate=browser)
        return resp.json()["user-agent"]

ua = get_impersonated_ua("firefox")
print("Firefox UA:", ua)