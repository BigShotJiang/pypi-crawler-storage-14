# Copyright (c) 2025, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from nemo.collections.avlm.data import AVLMMockDataModule
from nemo.collections.avlm.model.avlm import AVLMConfig8B
from nemo.collections.avlm.model.base import AVLMConfig, AVLMModel
from nemo.collections.avlm.recipes import *


__all__ = [
    "AVLMConfig8B",
    "AVLMMockDataModule",
    "AVLMConfig",
    "AVLMModel",
    "avlm_8b",
]


import warnings

warnings.warn(
    "nemo.collections.avlm is deprecated and will be removed in a future major NeMo FW container release. "
    "Please refer to the new Megatron-Bridge repository: https://github.com/NVIDIA-NeMo/Megatron-Bridge",
    DeprecationWarning,
    stacklevel=2,
)
