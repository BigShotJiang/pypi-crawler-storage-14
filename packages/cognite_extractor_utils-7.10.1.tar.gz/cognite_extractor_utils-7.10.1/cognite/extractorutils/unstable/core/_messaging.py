from enum import Enum


class RuntimeMessage(Enum):
    RESTART = 1
