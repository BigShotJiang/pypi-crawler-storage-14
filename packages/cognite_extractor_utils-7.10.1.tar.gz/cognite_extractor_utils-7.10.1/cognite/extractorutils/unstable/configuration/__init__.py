"""
New version of ``configtools`` based on pydantic instead of dataclasses.
"""
