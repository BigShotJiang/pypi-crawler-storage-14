class SpiralError(Exception):
    """Simulation error."""

    pass
