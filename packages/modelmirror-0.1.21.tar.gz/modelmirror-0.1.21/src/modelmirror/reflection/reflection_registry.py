from pydantic import BaseModel


class ReflectionRegistry(BaseModel):
    id: str
