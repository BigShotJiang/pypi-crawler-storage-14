import cv2
import numpy as np
import time
from datetime import date


class UsbCamera:
    def __init__(self):
        self.DeviceName = "USB Webcam"
        self.cap = None
        self.index = 0  # Caméra détectée sur index 0 (confirmé)
        self.width = 1024
        self.height = 768

        print("[UsbCamera] Plugin initialisé.")

    # ---------------------------------------------------
    # ⭐ Initialisation de la webcam USB
    # ---------------------------------------------------
    def init_camera(self):
        print(f"[UsbCamera] Initialisation sur index {self.index}...")

        self.cap = cv2.VideoCapture(self.index, cv2.CAP_DSHOW)

        if not self.cap.isOpened():
            raise RuntimeError(
                f"❌ Impossible d’ouvrir la webcam USB sur index {self.index}.\n"
                "➡ Vérifie que la caméra n'est pas utilisée par Teams/Zoom/Chrome."
            )

        # résolution
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)

        print("[UsbCamera] ✔ Webcam initialisée avec succès.")

    # ---------------------------------------------------
    # ⭐ Capture d’une image
    # ---------------------------------------------------
    def image_capture(self, tag=None, save_path=None):
        if self.cap is None:
            raise RuntimeError("Camera non initialisée. Appelle init_camera() avant image_capture().")

        ret, frame = self.cap.read()

        if not ret:
            raise RuntimeError("❌ Échec de la capture d'image depuis la webcam USB.")

        # timestamps
        fdate = date.today().strftime("%d_%m_%Y")
        actual_time = time.strftime("%H-%M-%S")

        if tag == "init":
            save_path = f"./{tag}.png"
        elif save_path is None:
            save_path = f"./UsbCam_{tag}_{fdate}_{actual_time}.png"

        # OpenCV est en BGR → convertir pour plus tard
        cv2.imwrite(save_path, frame)

        print(f"[UsbCamera] ✔ Image capturée → {save_path}")

        # Optionnel : retourner version RGB
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # ---------------------------------------------------
    # ⭐ Pour compatibilité StubCamera
    # ---------------------------------------------------
    def get_image_var(self):
        time.sleep(1)

    # ---------------------------------------------------
    # ⭐ Fermeture de la webcam
    # ---------------------------------------------------
    def close(self):
        if self.cap is not None:
            self.cap.release()
        cv2.destroyAllWindows()
        print("[UsbCamera] ✔ Webcam fermée.")
