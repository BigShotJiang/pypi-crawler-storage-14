import pandas as pd
import streamlit as st
import plotly.express as px

class DashBoard:
    """
    Creador de Dashboards dinámicos con Streamlit.
    """

    def __init__(self, data: pd.DataFrame, title: str = "GraphIX Dashboard"):
        self.data = data
        self.title = title
        self.components = []  # Lista de funciones a ejecutar

    # ---------------------- ELEMENTOS ----------------------

    def add_title(self, text: str):
        self.components.append(lambda: st.title(text))
        return self

    def add_text(self, text: str):
        self.components.append(lambda: st.write(text))
        return self

    def add_table(self):
        self.components.append(lambda: st.dataframe(self.data))
        return self

    def add_metric(self, label, value):
        self.components.append(lambda: st.metric(label, value))
        return self

    # ---------------------- GRÁFICOS ----------------------

    def add_plot(self, x=None, y=None, kind="scatter"):
        def render():
            if kind == "scatter":
                fig = px.scatter(self.data, x=x, y=y)
            elif kind == "line":
                fig = px.line(self.data, x=x, y=y)
            elif kind == "hist":
                fig = px.histogram(self.data, x=x)
            else:
                st.error("Tipo no soportado")
                return
            st.plotly_chart(fig)

        self.components.append(render)
        return self

    # ---------------------- RENDER ----------------------

    def show(self):
        st.title(self.title)
        for c in self.components:
            c()
