import os
import pandas as pd
import plotly.express as px

class HTML:
    """
    Generador de páginas HTML dinámicas a partir de DataFrames y objetos.
    """

    def __init__(self, data: pd.DataFrame, title: str = "GraphIX Report"):
        self.data = data
        self.title = title
        self.elements = []  # Aquí se almacenan bloques HTML

    # ---------------------- ELEMENTOS BÁSICOS ----------------------

    def add_title(self, text: str):
        self.elements.append(f"<h1>{text}</h1>")
        return self

    def add_text(self, text: str):
        self.elements.append(f"<p>{text}</p>")
        return self

    def add_table(self):
        html_table = self.data.to_html(classes="table", border=0)
        self.elements.append(html_table)
        return self

    # ---------------------- GRÁFICOS ----------------------

    def add_plot(self, x=None, y=None, kind="scatter"):
        if kind == "scatter":
            fig = px.scatter(self.data, x=x, y=y)
        elif kind == "line":
            fig = px.line(self.data, x=x, y=y)
        elif kind == "hist":
            fig = px.histogram(self.data, x=x)
        else:
            raise ValueError("Tipo de gráfico no soportado")

        html_fig = fig.to_html(full_html=False)
        self.elements.append(html_fig)
        return self

    # ---------------------- EXPORTAR ----------------------

    def export(self, filename="report.html"):
        html = f"""
        <html>
        <head>
        <meta charset="UTF-8">
        <title>{self.title}</title>
        <style>
        body {{ font-family: Arial; padding: 20px; }}
        .table {{ border-collapse: collapse; }}
        </style>
        </head>
        <body>
        {''.join(self.elements)}
        </body>
        </html>
        """

        with open(filename, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"Archivo generado: {filename}")
        return filename
