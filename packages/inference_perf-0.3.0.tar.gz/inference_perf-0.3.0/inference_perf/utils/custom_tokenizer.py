# Copyright 2025 The Kubernetes Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from transformers import AutoTokenizer, PreTrainedTokenizerBase
from transformers.tokenization_utils_base import VERY_LARGE_INTEGER
from inference_perf.config import CustomTokenizerConfig


class CustomTokenizer:
    def __init__(self, config: CustomTokenizerConfig) -> None:
        self.tokenizer: PreTrainedTokenizerBase = AutoTokenizer.from_pretrained(  # type: ignore[no-untyped-call]
            config.pretrained_model_name_or_path, token=config.token, trust_remote_code=config.trust_remote_code
        )

    def count_tokens(self, text: str) -> int:
        if text == "":
            return 0

        # Some tokenizers don't set model_max_length which defaults to VERY_LARGE_INTEGER.
        # Prevent overflow and log spam by skipping truncation.
        if self.tokenizer.model_max_length == VERY_LARGE_INTEGER:
            return len(self.tokenizer(text).input_ids)
        return len(self.tokenizer(text, truncation=True, max_length=self.tokenizer.model_max_length).input_ids)

    def get_tokenizer(self) -> PreTrainedTokenizerBase:
        return self.tokenizer
