"""Tests for tuick, the Text User Interface for Compilers and checKers."""
