from tamar_model_client.schemas.inputs.freepik.image_upscaler import FreepikImageUpscalerInput

__all__ = [
    "FreepikImageUpscalerInput",
]
