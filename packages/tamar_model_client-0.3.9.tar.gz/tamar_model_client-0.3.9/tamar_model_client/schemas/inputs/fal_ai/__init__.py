from tamar_model_client.schemas.inputs.fal_ai.qwen_images import FalAIQwenImageEditInput
from tamar_model_client.schemas.inputs.fal_ai.wan_video_replace import FalAIWanVideoReplaceInput

__all__ = [
    "FalAIQwenImageEditInput",
    "FalAIWanVideoReplaceInput",
]
