# RBAC Frontend Management System - Examples

这个目录包含了如何使用RBAC前端管理系统的完整示例。

## 🚀 快速开始

### 1. 安装依赖

```bash
# 确保在项目根目录中
cd /root/Project/Siduri

# 安装依赖
uv sync
```

### 2. 运行示例

```bash
# 运行基础使用示例
uv run python examples/basic_usage.py
```

### 3. 访问系统

服务器启动后，可以访问以下页面：

- **📱 管理后台首页**: <http://localhost:8000/admin/>
- **👥 用户管理**: <http://localhost:8000/admin/users>
- **🏷️ 角色管理**: <http://localhost:8000/admin/roles>  
- **🔑 权限管理**: <http://localhost:8000/admin/permissions>
- **📚 API文档**: <http://localhost:8000/docs>

## 📊 示例数据

系统会自动创建以下示例数据：

### 👤 示例用户

| 用户名 | 姓名 | 邮箱 | 角色 | 状态 |
|--------|------|------|------|------|
| admin | System Administrator | <admin@example.com> | Administrator | 活跃 |
| john_doe | John Doe | <john.doe@example.com> | User Manager | 活跃 |
| jane_smith | Jane Smith | <jane.smith@example.com> | Editor | 活跃 |
| bob_wilson | Bob Wilson | <bob.wilson@example.com> | Viewer | 非活跃 |
| alice_brown | Alice Brown | <alice.brown@example.com> | Viewer | 锁定 |

### 🏷️ 示例角色

| 角色名 | 描述 | 类型 | 权限数量 |
|--------|------|------|----------|
| Administrator | 系统管理员 | 系统角色 | 全部权限 |
| User Manager | 用户管理员 | 自定义角色 | 用户/角色管理 |
| Editor | 编辑者 | 自定义角色 | 读写权限 |
| Viewer | 查看者 | 自定义角色 | 只读权限 |

### 🔑 示例权限

| 权限代码 | 权限名称 | 资源 | 动作 | 类型 |
|----------|----------|------|------|------|
| admin:full_access | 完全管理权限 | system | admin | 系统权限 |
| user:read | 查看用户 | user | read | 自定义权限 |
| user:write | 创建/编辑用户 | user | write | 自定义权限 |
| user:delete | 删除用户 | user | delete | 自定义权限 |
| role:read | 查看角色 | role | read | 自定义权限 |
| role:write | 创建/编辑角色 | role | write | 自定义权限 |
| role:delete | 删除角色 | role | delete | 自定义权限 |
| permission:read | 查看权限 | permission | read | 自定义权限 |
| permission:write | 创建/编辑权限 | permission | write | 自定义权限 |

## 🎯 功能演示

### 1. 仪表板功能

- ✅ 系统统计信息展示
- ✅ 快速操作入口
- ✅ 系统状态监控
- ✅ 最近活动记录

### 2. 用户管理功能

- ✅ 用户列表浏览（分页支持）
- ✅ 高级搜索（姓名、邮箱、用户名）
- ✅ 用户详情查看
- ✅ 用户角色管理
- ✅ 用户状态管理（活跃/非活跃/锁定）
- ✅ 批量操作支持

### 3. 角色管理功能

- ✅ 角色列表浏览（分页支持）
- ✅ 角色搜索和过滤
- ✅ 角色详情查看
- ✅ 用户分配管理
- ✅ 系统角色保护
- ✅ 角色权限查看

### 4. 权限管理功能

- ✅ 权限列表浏览（分页支持）
- ✅ 多条件搜索（名称、代码、描述）
- ✅ 权限类型过滤
- ✅ 权限详情查看
- ✅ 角色分配管理
- ✅ 系统权限保护

### 5. 交互功能

- ✅ 响应式设计（移动端适配）
- ✅ 实时搜索和过滤
- ✅ 模态框确认对话框
- ✅ 批量选择和操作
- ✅ 通知提示系统
- ✅ 加载状态显示

## 🔧 技术特性

### 前端技术栈

- **模板引擎**: Jinja2 (服务端渲染)
- **UI框架**: Bootstrap 5
- **图标**: Bootstrap Icons
- **JavaScript**: 原生ES6+ (增强交互)
- **CSS**: 定制样式 + Bootstrap

### 后端集成

- **路由器**: FastAPI Router
- **数据库**: SQLModel + AsyncIO
- **序列化器**: 直接集成现有API
- **静态文件**: FastAPI StaticFiles

### 性能优化

- **异步处理**: 全异步数据库操作
- **分页加载**: 避免大数据集性能问题
- **缓存策略**: 静态资源缓存
- **响应式**: 移动端性能优化

## 📝 使用场景

### 1. 系统管理员

```bash
# 场景：管理员需要查看系统整体状况
访问: http://localhost:8000/admin/

# 场景：管理员需要创建新用户并分配角色
访问: http://localhost:8000/admin/users
操作: 点击"Add User" -> 填写用户信息 -> 分配角色
```

### 2. 用户管理员

```bash
# 场景：查看特定用户的角色分配情况
访问: http://localhost:8000/admin/users
操作: 搜索用户 -> 点击用户详情 -> 查看角色分配

# 场景：批量修改用户状态
访问: http://localhost:8000/admin/users
操作: 选择多个用户 -> 点击批量操作 -> 选择状态
```

### 3. 权限审计员

```bash
# 场景：审计特定角色拥有的所有权限
访问: http://localhost:8000/admin/roles
操作: 搜索角色 -> 点击角色详情 -> 查看权限列表

# 场景：查看某个权限被哪些角色使用
访问: http://localhost:8000/admin/permissions
操作: 搜索权限 -> 点击权限详情 -> 查看角色分配
```

## 🐛 故障排除

### 常见问题

1. **服务器无法启动**

   ```bash
   # 检查端口是否被占用
   lsof -i :8000
   
   # 或者更换端口
   # 在 uvicorn.Config 中修改 port 参数
   ```

2. **前端页面无法访问**

   ```bash
   # 检查路由是否正确注册
   # 访问 http://localhost:8000/docs 查看所有端点
   ```

3. **数据库连接问题**

   ```bash
   # 检查数据库配置
   # 确保 database.py 中的连接配置正确
   ```

4. **静态文件加载失败**

   ```bash
   # 检查静态文件路径
   # 确保 frontend/static/ 目录存在且文件完整
   ```

### 调试模式

如需启用调试模式，修改 `basic_usage.py` 中的配置：

```python
config = uvicorn.Config(
    app=app,
    host="0.0.0.0",
    port=8000,
    reload=True,  # 启用热重载
    log_level="debug"  # 启用调试日志
)
```

## 📞 支持

如果您在使用过程中遇到问题，请：

1. 检查控制台输出的错误信息
2. 查看浏览器开发者工具的错误日志
3. 确认所有依赖都已正确安装
4. 验证数据库连接配置

系统运行成功后，您将看到类似输出：

```
🚀 Starting RBAC Management System...
==================================================
Creating sample data...
✓ Created permission: user:read
✓ Created permission: user:write
...
🎉 Sample data created successfully!

📊 Summary:
   • 9 permissions
   • 4 roles  
   • 5 users

🌐 Starting web server...
   📱 Frontend Dashboard: http://localhost:8000/admin/
   📚 API Documentation: http://localhost:8000/docs
   👥 User Management: http://localhost:8000/admin/users
   🏷️  Role Management: http://localhost:8000/admin/roles
   🔑 Permission Management: http://localhost:8000/admin/permissions
```
