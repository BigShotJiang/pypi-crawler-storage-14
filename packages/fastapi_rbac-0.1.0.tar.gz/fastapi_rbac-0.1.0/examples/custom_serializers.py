# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
# """
# RBAC Frontend Management System - Basic Usage Example

# This example demonstrates how to:
# 1. Setup FastAPI application with RBAC frontend management
# 2. Initialize database with sample data
# 3. Use the web interface for managing users, roles, and permissions
# 4. Integrate with existing API endpoints
# 5. **NEW**: Use custom User models with additional fields

# CUSTOM USER MODEL USAGE:
#     To use a custom User model with additional fields:

#     1. Create your extended User model:
#     ```python
#     from models import User
#     from sqlmodel import Field

#     class MyCustomUser(User, table=True):
#         __tablename__ = "t_users"  # Use same table

#         # Add your custom fields
#         department: Optional[str] = Field(default=None, max_length=100)
#         employee_id: Optional[str] = Field(default=None, max_length=50)
#     ```

#     2. Configure the Settings:
#     ```python
#     settings = Settings(custom_user_model=MyCustomUser)
#     ```

#     3. Use in your application:
#     ```python
#     app = create_app(settings)
#     await create_sample_data(settings)
#     ```

# Usage:
#     # Install dependencies first
#     uv sync

#     # Run the example
#     uv run python examples/basic_usage.py

#     # Then visit:
#     # - Frontend Dashboard: http://localhost:8000/admin/
#     # - API Documentation: http://localhost:8000/docs
#     # - User Management: http://localhost:8000/admin/users
#     # - Role Management: http://localhost:8000/admin/roles
#     # - Permission Management: http://localhost:8000/admin/permissions
# """
# import sys
# import os


# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# import asyncio
# import os
# import uvicorn
# from fastapi import FastAPI
# from fastapi.staticfiles import StaticFiles
# from sqlmodel import SQLModel
# from sqlmodel.ext.asyncio.session import AsyncSession

# # Import your existing RBAC components
# from sqlalchemy.ext.asyncio import create_async_engine
# from fastapi_rbac.models import (
#     User,
# )
# from fastapi_rbac.routers import (
#     user_router,
#     role_router,
#     permission_router,
#     frontend_router,
# )

# # Import necessary schemas for the fixes
# from fastapi_rbac.schemas.role_schemas import RoleCreate, UserRoleAssignment
# from fastapi_rbac.schemas.permission_schemas import (
#     PermissionCreate,
#     RolePermissionAssignment,
# )
# from fastapi_rbac.schemas.common_schemas import PaginationParams
# from fastapi_rbac.models import get_user_model

# from typing import List, Optional, Type
# from sqlmodel import Field, Relationship
# from datetime import datetime


# # Example: Extended User Model with additional fields
# class ExtendedUser(User, table=True):
#     """
#     Extended User Model Example

#     Demonstrates how to extend the base User model with additional fields
#     for specific application requirements.
#     """

#     __tablename__: str = "t_users"  # Use same table as base User

#     # Additional fields specific to your application
#     department: Optional[str] = Field(
#         default=None, max_length=100, description="User department"
#     )
#     employee_id: Optional[str] = Field(
#         default=None, max_length=50, description="Employee ID number"
#     )
#     hire_date: Optional[datetime] = Field(
#         default=None, description="Employee hire date"
#     )
#     salary_grade: Optional[int] = Field(default=None, description="Salary grade level")
#     manager_id: Optional[int] = Field(default=None, description="Manager user ID")

#     # Additional relationship
#     subordinates: List["ExtendedUser"] = Relationship(
#         back_populates="manager",
#         sa_relationship_kwargs={
#             "primaryjoin": "ExtendedUser.manager_id==ExtendedUser.id",
#             "foreign_keys": "[ExtendedUser.manager_id]",
#         },
#     )
#     manager: Optional["ExtendedUser"] = Relationship(
#         back_populates="subordinates",
#         sa_relationship_kwargs={
#             "primaryjoin": "ExtendedUser.id==ExtendedUser.manager_id",
#             "foreign_keys": "[ExtendedUser.manager_id]",
#         },
#     )


# class Settings:
#     """Application settings"""

#     def __init__(self, custom_user_model: Optional[Type] = None):
#         self.database_url = os.getenv(
#             "RBAC_DATABASE_URL",
#             "mysql+aiomysql://root:zxjzxj233@localhost:3306/siduri-example",
#         )
#         self.debug = os.getenv("DEBUG", "true").lower() == "true"
#         self.custom_user_model = custom_user_model


# settings = Settings()


# # Database configuration
# engine = create_async_engine(
#     settings.database_url,
#     echo=settings.debug,
#     pool_size=20,
#     max_overflow=20,
#     pool_pre_ping=True,
# )


# def get_async_session():
#     """Get async session"""
#     return AsyncSession(engine)


# def create_serializers(db_session_factory, models_dict):
#     """
#     Create serializer instances using dynamic models

#     Args:
#         db_session_factory: Database session factory function
#         models_dict: Dictionary containing model classes

#     Returns:
#         Dictionary containing serializer instances
#     """
#     from fastapi_rbac.serializers.user_serializer import UserSerializer
#     from fastapi_rbac.serializers.role_serializer import RoleSerializer
#     from fastapi_rbac.serializers.permission_serializer import PermissionSerializer

#     session = db_session_factory()

#     # Create serializers with dynamic models
#     user_serializer = UserSerializer(session)
#     role_serializer = RoleSerializer(session)
#     permission_serializer = PermissionSerializer(session)

#     # Override model references if needed
#     user_serializer.model_class = models_dict["User"]

#     return {
#         "user": user_serializer,
#         "role": role_serializer,
#         "permission": permission_serializer,
#         "session": session,
#     }


# async def create_sample_data(settings: Settings = None):
#     """Create sample data for demonstration purposes"""
#     print("Creating sample data...")

#     if settings is None:
#         settings = Settings()

#     # Initialize dynamic models
#     from fastapi_rbac.models import create_dynamic_models

#     models_dict = create_dynamic_models(settings.custom_user_model)

#     async with engine.begin() as conn:
#         # Create all tables
#         await conn.run_sync(SQLModel.metadata.create_all)

#     # Create serializers using factory
#     serializers = create_serializers(get_async_session, models_dict)

#     try:
#         # Initialize serializers
#         user_serializer = serializers["user"]
#         role_serializer = serializers["role"]
#         permission_serializer = serializers["permission"]
#         session = serializers["session"]

#         # Create sample permissions
#         permissions_data = [
#             {
#                 "code": "user:read",
#                 "name": "Read Users",
#                 "description": "View user information",
#                 "resource": "user",
#                 "action": "read",
#             },
#             {
#                 "code": "user:write",
#                 "name": "Write Users",
#                 "description": "Create and update users",
#                 "resource": "user",
#                 "action": "write",
#             },
#             {
#                 "code": "user:delete",
#                 "name": "Delete Users",
#                 "description": "Delete user accounts",
#                 "resource": "user",
#                 "action": "delete",
#             },
#             {
#                 "code": "role:read",
#                 "name": "Read Roles",
#                 "description": "View role information",
#                 "resource": "role",
#                 "action": "read",
#             },
#             {
#                 "code": "role:write",
#                 "name": "Write Roles",
#                 "description": "Create and update roles",
#                 "resource": "role",
#                 "action": "write",
#             },
#             {
#                 "code": "role:delete",
#                 "name": "Delete Roles",
#                 "description": "Delete roles",
#                 "resource": "role",
#                 "action": "delete",
#             },
#             {
#                 "code": "permission:read",
#                 "name": "Read Permissions",
#                 "description": "View permissions",
#                 "resource": "permission",
#                 "action": "read",
#             },
#             {
#                 "code": "permission:write",
#                 "name": "Write Permissions",
#                 "description": "Create and update permissions",
#                 "resource": "permission",
#                 "action": "write",
#             },
#             {
#                 "code": "admin:full_access",
#                 "name": "Full Admin Access",
#                 "description": "Complete system administration",
#                 "resource": "system",
#                 "action": "admin",
#                 "is_system": True,
#             },
#         ]

#         created_permissions = []
#         for perm_data in permissions_data:
#             perm_data_ins = PermissionCreate(**perm_data)
#             # Check if permission already exists
#             existing_perm = await permission_serializer._get_permission_by_code(
#                 perm_data["code"]
#             )
#             if not existing_perm:
#                 permission = await permission_serializer.create_permission(
#                     perm_data_ins
#                 )
#                 created_permissions.append(permission)
#                 print(f"✓ Created permission: {permission.code}")
#             else:
#                 created_permissions.append(existing_perm)
#                 print(f"- Permission already exists: {existing_perm.code}")

#         # Create lookup dictionary for permissions by code
#         permission_lookup = {}
#         for perm in created_permissions:
#             # Access attributes within session context and store them
#             perm_code = perm.code
#             perm_id = perm.id
#             permission_lookup[perm_code] = {"id": perm_id, "object": perm}

#         # Create sample roles
#         roles_data = [
#             {
#                 "name": "Administrator",
#                 "description": "System administrator with full access",
#                 "is_system": True,
#             },
#             {"name": "User Manager", "description": "Manages user accounts and roles"},
#             {"name": "Viewer", "description": "Read-only access to system information"},
#             {"name": "Editor", "description": "Can create and edit content"},
#         ]

#         created_roles = []
#         for role_data in roles_data:
#             role_data_ins = RoleCreate(**role_data)
#             # Check if role already exists
#             existing_role = await role_serializer._get_role_by_name(role_data["name"])
#             if not existing_role:
#                 role = await role_serializer.create_role(role_data_ins)
#                 created_roles.append(role)
#                 print(f"✓ Created role: {role.name}")
#             else:
#                 created_roles.append(existing_role)
#                 print(f"- Role already exists: {existing_role.name}")

#         # Create lookup dictionary for roles by name
#         role_lookup = {}
#         for role in created_roles:
#             # Access attributes within session context and store them
#             role_name = role.name
#             role_id = role.id
#             role_lookup[role_name] = {"id": role_id, "object": role}

#         # Assign permissions to roles
#         role_permission_mapping = {
#             "Administrator": ["admin:full_access"],  # Admin gets everything
#             "User Manager": [
#                 "user:read",
#                 "user:write",
#                 "user:delete",
#                 "role:read",
#                 "role:write",
#             ],
#             "Viewer": ["user:read", "role:read", "permission:read"],
#             "Editor": ["user:read", "user:write", "role:read"],
#         }

#         for role_name, permission_codes in role_permission_mapping.items():
#             role_info = role_lookup.get(role_name)
#             if role_info:
#                 role = role_info["object"]
#                 for perm_code in permission_codes:
#                     permission_info = permission_lookup.get(perm_code)
#                     if permission_info:
#                         permission = permission_info["object"]
#                         # Assign permission to role using existing method
#                         try:
#                             assignment_data = RolePermissionAssignment(
#                                 role_ids=[role_info["id"]],
#                                 assigned_by=1,  # System assignment
#                                 expires_at=None,
#                             )
#                             await permission_serializer.assign_roles(
#                                 permission_info["id"], assignment_data
#                             )
#                             print(f"✓ Assigned {perm_code} to {role_name}")
#                         except Exception as e:
#                             # Role might already be assigned, which is fine
#                             if "already" in str(e).lower():
#                                 print(
#                                     f"- Permission {perm_code} already assigned to {role_name}"
#                                 )
#                             else:
#                                 print(
#                                     f"⚠ Warning: Could not assign {perm_code} to {role_name}: {e}"
#                                 )

#         # Create sample users
#         users_data = [
#             {
#                 "name": "admin",
#                 "en_name": "Admin User",
#                 "email": "admin@example.com",
#                 "mobile": "+1234567890",
#                 "user_id": "admin001",
#                 "status": 1,
#                 "locked": 0,
#             },
#             {
#                 "name": "john_doe",
#                 "en_name": "John Doe",
#                 "email": "john.doe@example.com",
#                 "mobile": "+1234567891",
#                 "user_id": "user001",
#                 "status": 1,
#                 "locked": 0,
#             },
#             {
#                 "name": "jane_smith",
#                 "en_name": "Jane Smith",
#                 "email": "jane.smith@example.com",
#                 "mobile": "+1234567892",
#                 "user_id": "user002",
#                 "status": 1,
#                 "locked": 0,
#             },
#             {
#                 "name": "bob_wilson",
#                 "en_name": "Bob Wilson",
#                 "email": "bob.wilson@example.com",
#                 "mobile": "+1234567893",
#                 "user_id": "user003",
#                 "status": 0,  # Inactive user
#                 "locked": 0,
#             },
#             {
#                 "name": "alice_brown",
#                 "en_name": "Alice Brown",
#                 "email": "alice.brown@example.com",
#                 "mobile": "+1234567894",
#                 "user_id": "user004",
#                 "status": 1,
#                 "locked": 1,  # Locked user
#             },
#         ]

#         created_users = []
#         for user_data in users_data:
#             ModelUser = get_user_model()
#             user_data_ins = ModelUser(**user_data)
#             # Check if user already exists by querying with basic pagination
#             pagination = PaginationParams(
#                 page=1, size=100
#             )  # Get enough users to search through
#             all_users_result = await user_serializer.get_users(pagination=pagination)
#             existing_user = None
#             for user in all_users_result.items:
#                 if user.user_id == user_data["user_id"]:
#                     existing_user = user
#                     break

#             if not existing_user:
#                 user = await user_serializer.create_user(user_data_ins)
#                 created_users.append(user)
#                 print(f"✓ Created user: {user.name}")
#             else:
#                 created_users.append(existing_user)
#                 print(f"- User already exists: {existing_user.name}")

#         # Create lookup dictionary for users by name
#         user_lookup = {}
#         for user in created_users:
#             # Access attributes within session context and store them
#             user_name = user.name
#             user_id = user.id
#             user_lookup[user_name] = {"id": user_id, "object": user}

#         # Assign roles to users
#         user_role_mapping = {
#             "admin": ["Administrator"],
#             "john_doe": ["User Manager"],
#             "jane_smith": ["Editor"],
#             "bob_wilson": ["Viewer"],
#             "alice_brown": ["Viewer"],
#         }

#         for username, role_names in user_role_mapping.items():
#             user_info = user_lookup.get(username)
#             if user_info:
#                 user = user_info["object"]
#                 for role_name in role_names:
#                     role_info = role_lookup.get(role_name)
#                     if role_info:
#                         role = role_info["object"]
#                         # Assign user to role using existing method
#                         try:
#                             assignment_data = UserRoleAssignment(
#                                 user_ids=[user_info["id"]],
#                                 assigned_by=1,  # System assignment
#                                 expires_at=None,
#                             )
#                             await role_serializer.assign_users(
#                                 role_info["id"], assignment_data
#                             )
#                             print(f"✓ Assigned {role_name} to {username}")
#                         except Exception as e:
#                             # User might already be assigned, which is fine
#                             if (
#                                 "already" in str(e).lower()
#                                 or "exists" in str(e).lower()
#                             ):
#                                 print(
#                                     f"- Role {role_name} already assigned to {username}"
#                                 )
#                             else:
#                                 print(
#                                     f"⚠ Warning: Could not assign {role_name} to {username}: {e}"
#                                 )

#         # Print summary
#         print("\n📊 Summary:")
#         print(f"   • {len(created_permissions)} permissions")
#         print(f"   • {len(created_roles)} roles")
#         print(f"   • {len(created_users)} users")

#         await session.commit()
#         print("\n🎉 Sample data created successfully!")

#     except Exception as e:
#         await session.rollback()
#         print(f"\n❌ Error creating sample data: {e}")
#         raise
#     finally:
#         await session.close()


# def create_routers(db_session_factory, models_dict):
#     """
#     Create router instances using dynamic models

#     Args:
#         db_session_factory: Database session factory function
#         models_dict: Dictionary containing model classes

#     Returns:
#         Dictionary containing router instances
#     """

#     # Create routers with session factory
#     user_router_ins = user_router.create_user_router(db_session_factory)
#     role_router_ins = role_router.create_role_router(db_session_factory)
#     permission_router_ins = permission_router.create_permission_router(
#         db_session_factory
#     )
#     frontend_router_ins = frontend_router.create_frontend_router(db_session_factory)

#     return {
#         "user": user_router_ins,
#         "role": role_router_ins,
#         "permission": permission_router_ins,
#         "frontend": frontend_router_ins,
#     }


# def create_app(settings: Settings = None) -> FastAPI:
#     """Create and configure the FastAPI application"""

#     if settings is None:
#         settings = Settings()

#     # Initialize dynamic models with custom user model if provided
#     from fastapi_rbac.models import create_dynamic_models

#     models_dict = create_dynamic_models(settings.custom_user_model)

#     # Create FastAPI app
#     app = FastAPI(
#         title="RBAC Management System",
#         description="Role-Based Access Control system with web interface",
#         version="1.0.0",
#         docs_url="/docs",
#         redoc_url="/redoc",
#     )

#     # Create routers using factory
#     routers = create_routers(get_async_session, models_dict)

#     # Include API routers
#     app.include_router(routers["user"], prefix="/rbac", tags=["Users"])
#     app.include_router(routers["role"], prefix="/rbac", tags=["Roles"])
#     app.include_router(routers["permission"], prefix="/rbac", tags=["Permissions"])

#     # Include frontend router
#     app.include_router(routers["frontend"], tags=["Frontend"])

#     # Mount static files at application level for template url_for compatibility
#     from pathlib import Path

#     static_dir = Path(__file__).parent.parent / "fastapi_rbac" / "frontend" / "static"
#     app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

#     # Root redirect to admin dashboard
#     @app.get("/")
#     async def root():
#         """Redirect root URL to admin dashboard"""
#         from fastapi.responses import RedirectResponse

#         return RedirectResponse(url="/admin/")

#     # Health check endpoint
#     @app.get("/health")
#     async def health_check():
#         """Health check endpoint"""
#         return {"status": "healthy", "message": "RBAC Management System is running"}

#     return app


# async def main():
#     """Main function to setup and run the application"""

#     print("🚀 Starting RBAC Management System...")
#     print("=" * 50)

#     # Create settings with optional custom user model
#     # Example: Use ExtendedUser with additional fields
#     # settings = Settings(custom_user_model=ExtendedUser)

#     # For this demo, we'll use the default User model
#     settings = Settings()

#     # Create sample data
#     await create_sample_data(settings)

#     # Create app with settings
#     app = create_app(settings)

#     print("\n🌐 Starting web server...")
#     print("   📱 Frontend Dashboard: http://localhost:8000/admin/")
#     print("   📚 API Documentation: http://localhost:8000/docs")
#     print("   👥 User Management: http://localhost:8000/admin/users")
#     print("   🏷️  Role Management: http://localhost:8000/admin/roles")
#     print("   🔑 Permission Management: http://localhost:8000/admin/permissions")
#     print("\n💡 Frontend Features:")
#     print("   • Search and filter users, roles, permissions")
#     print("   • View detailed information for each entity")
#     print("   • Manage user-role and role-permission assignments")
#     print("   • Responsive design for mobile and desktop")
#     print("   • Real-time notifications and confirmations")
#     print("\n🔧 API Features:")
#     print("   • RESTful API endpoints for all operations")
#     print("   • Comprehensive search and pagination")
#     print("   • Async/await support for high performance")
#     print("   • Automatic API documentation")

#     print("\n" + "=" * 50)
#     print("Press Ctrl+C to stop the server")

#     # Run the server
#     config = uvicorn.Config(
#         app=app, host="0.0.0.0", port=8000, reload=False, log_level="info"
#     )
#     server = uvicorn.Server(config)
#     await server.serve()


# if __name__ == "__main__":
#     """
#     Frontend Management Usage Guide:

#     1. Dashboard (http://localhost:8000/admin/):
#        - View system statistics and overview
#        - Quick access to all management sections
#        - System status and information

#     2. User Management (http://localhost:8000/admin/users):
#        - Browse all users with pagination
#        - Search users by name, email, or username
#        - View user details and assigned roles
#        - Manage user status (active/inactive/locked)

#     3. Role Management (http://localhost:8000/admin/roles):
#        - Browse all roles with user counts
#        - Search roles by name or description
#        - View role details and assigned users
#        - Distinguish between system and custom roles

#     4. Permission Management (http://localhost:8000/admin/permissions):
#        - Browse all permissions with role assignments
#        - Filter by permission type and resource
#        - View permission details and assigned roles
#        - Manage permission-role relationships

#     5. Interactive Features:
#        - Bulk selection and operations
#        - Modal confirmations for destructive actions
#        - Real-time search and filtering
#        - Responsive mobile-friendly design
#        - Toast notifications for user feedback

#     Sample Accounts:
#     - admin: System administrator with full access
#     - john_doe: User manager with user/role management permissions
#     - jane_smith: Editor with basic read/write permissions
#     - bob_wilson: Viewer with read-only access (inactive)
#     - alice_brown: Viewer with read-only access (locked)
#     """
#     try:
#         asyncio.run(main())
#     except KeyboardInterrupt:
#         print("\n\n👋 Server stopped by user")
#     except Exception as e:
#         print(f"\n❌ Error starting server: {e}")
#         raise
