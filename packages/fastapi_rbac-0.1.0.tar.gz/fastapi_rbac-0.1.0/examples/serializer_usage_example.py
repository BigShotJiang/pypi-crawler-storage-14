#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:35:52
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Serializer Usage Example
    Demonstrates how to use the new serializer system with different user models.

All Rights Reserved.
"""

import asyncio
import sys
import os

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi_rbac.serializers import (
    UserSerializerFactory,
)
from fastapi_rbac.models import (
    get_user_model,
)


async def example_usage():
    """Example of using the new serializer system"""

    print("=== RBAC Serializer System Example ===\n")

    # Example 1: Using the factory to automatically select serializer
    print("1. Using UserSerializerFactory:")
    print(
        "   The factory automatically selects the appropriate serializer based on configuration.\n"
    )

    # Example 2: Direct serializer usage
    print("2. Direct Serializer Usage:")
    print(
        "   You can also use specific serializers directly when you know the model type.\n"
    )

    # Example 3: Checking serializer capabilities
    print("3. Checking Serializer Capabilities:")
    print("   You can check what features a serializer supports.\n")

    # Example 4: Custom user model support
    print("4. Custom User Model Support:")
    print("   The system supports custom user models that inherit from base models.\n")

    print("=== End of Example ===\n")


def demonstrate_serializer_factory():
    """Demonstrate the serializer factory functionality"""

    print("=== Serializer Factory Demonstration ===\n")

    # Get current user model
    try:
        user_model = get_user_model()
        print(f"Current user model: {user_model.__name__}")

        # Check serializer capabilities
        is_password_model = UserSerializerFactory.is_password_user_model(user_model)
        is_default_model = UserSerializerFactory.is_default_user_model(user_model)

        print(f"Supports passwords: {is_password_model}")
        print(f"Is default model: {is_default_model}")

        # Get appropriate serializer class
        serializer_class = UserSerializerFactory.get_serializer_class(user_model)
        print(f"Recommended serializer: {serializer_class.__name__}")

    except Exception as e:
        print(f"Error getting user model: {e}")

    print("\n=== End of Factory Demo ===\n")


def demonstrate_custom_models():
    """Demonstrate custom user model support"""

    print("=== Custom User Model Support ===\n")

    # Example of how to use with custom models
    print("To use a custom user model:")
    print("1. Create your model inheriting from BaseUser or existing models")
    print("2. Configure it in your RBAC config")
    print("3. The factory will automatically select the right serializer")

    print("\nExample custom model:")
    print(
        """
from fastapi_rbac.models.base_user_model import BaseUser
from sqlmodel import Field

class MyCustomUser(BaseUser, table=True):
    __tablename__ = "t_users"
    
    # Your custom fields
    department: str = Field(max_length=100)
    employee_id: str = Field(max_length=50)
    
    # Required relationship
    user_roles: List["UserRoleRelation"] = Relationship(...)
    """
    )

    print("\n=== End of Custom Model Demo ===\n")


if __name__ == "__main__":
    print("RBAC Serializer System Examples")
    print("=" * 40)

    # Run examples
    asyncio.run(example_usage())
    demonstrate_serializer_factory()
    demonstrate_custom_models()

    print("\nFor more information, see:")
    print("- fastapi_rbac/serializers/user_serializer_factory.py")
    print("- fastapi_rbac/serializers/base_user_serializer.py")
    print("- fastapi_rbac/serializers/default_user_serializer.py")
    print("- fastapi_rbac/serializers/password_user_serializer.py")
