#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Initialize/Update RBAC permissions (auto-discovered) and super_admin role

Usage:
    uv run python examples/init_rbac_data.py

This script will:
  - Analyze project routes to dynamically discover permissions used by `require_permissions`
  - Upsert (create missing) permissions into the database
  - Ensure a `super_admin` role exists and grant all discovered permissions to it
  - Ensure a default admin user exists and bind it to `super_admin`
"""

import os
import sys
from typing import Optional, Set, List, Type
import logging

from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from fastapi_rbac.schemas.permission_schemas import RolePermissionAssignment

# Ensure project root is on sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi_rbac.config import RBACConfig
from fastapi_rbac.models import create_dynamic_models, Role
from fastapi_rbac.serializers import (
    UserSerializer,
    RoleSerializer,
    PermissionSerializer,
)
from fastapi_rbac.schemas import (
    RoleCreate,
    PermissionCreate,
    PermissionRoleAssignment,
    UserRoleAssignment,
)
from fastapi_rbac.models import get_user_model
from fastapi import FastAPI
from fastapi.params import Depends
from fastapi.routing import APIRoute
import inspect

logger = logging.getLogger(__name__)

# DATABASE_URL = os.getenv(
#     "RBAC_DATABASE_URL", "mysql+aiomysql://root:root@localhost:3306/siduri"
# )


async def init_engine(database_url: Optional[str] = None):
    engine = create_async_engine(
        database_url,
        echo=False,
        pool_size=10,
        max_overflow=10,
        pool_pre_ping=True,
    )
    return engine


async def ensure_tables(engine, user_model: Type[SQLModel]) -> None:
    # Ensure dynamic models are registered
    create_dynamic_models(user_model)
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

        # Backward compatibility: ensure missing columns exist (e.g., password on t_users)
        def _get_columns(connection, table_name: str):
            from sqlalchemy import inspect

            inspector = inspect(connection)
            return [col["name"] for col in inspector.get_columns(table_name)]

        try:
            user_columns = await conn.run_sync(lambda c: _get_columns(c, "t_users"))
            if "password" not in user_columns:
                await conn.exec_driver_sql(
                    "ALTER TABLE t_users ADD COLUMN password VARCHAR(255) NULL"
                )
        except Exception:
            # Ignore if inspection fails; table may not exist yet on first run
            pass


def extract_permission_codes_from_app(app: FastAPI) -> Set[str]:
    """Extract permission codes from routes that depend on require_permissions."""
    permission_codes: Set[str] = set()
    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue
        endpoint = route.endpoint
        sig = inspect.signature(endpoint)
        for param in sig.parameters.values():
            default = param.default
            if isinstance(default, Depends):
                dep = default.dependency
                if hasattr(dep, "__name__") and dep.__name__ == "permission_dependency":  # type: ignore
                    closure = getattr(dep, "__closure__", None)  # type: ignore
                    if closure:
                        for cell in closure:
                            value = cell.cell_contents
                            if isinstance(value, tuple) and all(
                                isinstance(x, str) for x in value
                            ):
                                for code in value:
                                    permission_codes.add(code)
    return permission_codes


def build_permission_payload(code: str) -> PermissionCreate:
    """Build a PermissionCreate payload from a permission code."""
    if ":" in code:
        resource, action = code.split(":", 1)
    else:
        resource, action = code, "access"
    return PermissionCreate(
        code=code,
        name=code,
        description=f"Auto-discovered permission for {code}",
        resource=resource,
        action=action,
        permission_type="function",
        is_active=True,
        is_system=False,
    )


async def init_rbac(
    database_url: str,
    rbac_settings: RBACConfig,
    app: FastAPI = None,
    session: Optional[AsyncSession] = None,
) -> None:
    own_engine = None
    own_session = False

    User = rbac_settings.user_serializer.user_model
    try:
        if session is None:
            own_engine = await init_engine(database_url)
            await ensure_tables(own_engine, rbac_settings.user_serializer.user_model)
            SessionLocal = async_sessionmaker(
                own_engine, class_=AsyncSession, expire_on_commit=False
            )
            session = SessionLocal()  # type: ignore[assignment]
            own_session = True
        else:
            # Ensure tables when external session is passed requires engine
            engine = session.get_bind().engine  # type: ignore[attr-defined]
            if engine:
                await ensure_tables(engine, rbac_settings.user_serializer.user_model)

        user_s = UserSerializer(session)
        role_s = RoleSerializer(session)
        perm_s = PermissionSerializer(session)

        discovered_codes = extract_permission_codes_from_app(app)

        # 1) Upsert permissions (create missing only)
        created_permission_ids: List[int] = []
        for code in sorted(discovered_codes):
            existing = await perm_s._get_permission_by_code(code)
            if existing:
                created_permission_ids.append(existing.id)
                continue
            payload = build_permission_payload(code)
            created = await perm_s.create_permission(payload)
            created_permission_ids.append(created.id)

        # 2) Ensure super_admin role
        super_role: Optional[Role] = None
        from sqlmodel import select

        result = await session.exec(select(Role).where(Role.name == "super_admin"))
        super_role = result.first()
        if not super_role:
            super_role = await role_s.create_role(
                RoleCreate(
                    name="super_admin",
                    description="Super administrator",
                    is_system=True,
                    is_active=True,
                )
            )

        # 3) Grant all discovered permissions to super_admin
        if created_permission_ids:
            await role_s.assign_permissions(
                super_role.id,
                PermissionRoleAssignment(
                    permission_ids=created_permission_ids,
                    assigned_by=0,
                    expires_at=None,
                ),
            )

        # 4) Ensure an admin user and bind to super_admin
        # Find by email to avoid duplicates
        from sqlmodel import select

        result = await session.exec(
            select(User).where(User.email == "admin@example.com")
        )
        admin = result.first()
        if not admin:
            ModelUser = get_user_model()
            admin = await user_s.create_user(
                ModelUser(
                    name="admin",
                    en_name="Admin",
                    email="admin@example.com",
                    mobile="00000000000",
                    user_id="ADMIN",
                    status=1,
                    locked=0,
                    password="y6ZreZqlZeBeIl",
                )
            )

        await role_s.assign_users(
            super_role.id,
            UserRoleAssignment(
                user_ids=[admin.id],
                assigned_by=0,
                expires_at=None,
            ),
        )

        await session.commit()
        print("Initialized permissions, super_admin role, and admin user.")
    finally:
        if own_session and session is not None:
            await session.close()
        if own_engine is not None:
            await own_engine.dispose()


async def create_sample_data(database_url: str, rbac_settings: RBACConfig):
    """Create sample data for demonstration purposes"""
    print("Creating sample data...")

    engine = create_async_engine(
        database_url,
    )

    async with engine.begin() as conn:
        # drop all tables
        await conn.run_sync(SQLModel.metadata.drop_all)
        # Create all tables using RBAC metadata to avoid conflicts
        from fastapi_rbac.models import get_rbac_metadata

        rbac_metadata = get_rbac_metadata()
        await conn.run_sync(rbac_metadata.create_all)

    # Use a single session for all operations
    async with AsyncSession(engine, expire_on_commit=False) as session:
        try:
            # Initialize serializers with the same session
            user_serializer = UserSerializer(session)
            role_serializer = RoleSerializer(session)
            permission_serializer = PermissionSerializer(session)

            # Create sample permissions
            permissions_data = [
                {
                    "code": "user:read",
                    "name": "Read Users",
                    "description": "View user information",
                    "resource": "user",
                    "action": "read",
                },
                {
                    "code": "user:write",
                    "name": "Write Users",
                    "description": "Create and update users",
                    "resource": "user",
                    "action": "write",
                },
                {
                    "code": "user:delete",
                    "name": "Delete Users",
                    "description": "Delete user accounts",
                    "resource": "user",
                    "action": "delete",
                },
                {
                    "code": "role:read",
                    "name": "Read Roles",
                    "description": "View role information",
                    "resource": "role",
                    "action": "read",
                },
                {
                    "code": "role:write",
                    "name": "Write Roles",
                    "description": "Create and update roles",
                    "resource": "role",
                    "action": "write",
                },
                {
                    "code": "role:delete",
                    "name": "Delete Roles",
                    "description": "Delete roles",
                    "resource": "role",
                    "action": "delete",
                },
                {
                    "code": "permission:read",
                    "name": "Read Permissions",
                    "description": "View permissions",
                    "resource": "permission",
                    "action": "read",
                },
                {
                    "code": "permission:write",
                    "name": "Write Permissions",
                    "description": "Create and update permissions",
                    "resource": "permission",
                    "action": "write",
                },
                {
                    "code": "admin:full_access",
                    "name": "Full Admin Access",
                    "description": "Complete system administration",
                    "resource": "system",
                    "action": "admin",
                    "is_system": True,
                },
            ]

            created_permissions = []
            for perm_data in permissions_data:
                perm_data_ins = PermissionCreate(**perm_data)
                # Check if permission already exists
                existing_perm = await permission_serializer._get_permission_by_code(
                    perm_data["code"]
                )
                if not existing_perm:
                    permission = await permission_serializer.create_permission(
                        perm_data_ins
                    )
                    created_permissions.append(permission)
                    print(f"✓ Created permission: {permission.code}")
                else:
                    created_permissions.append(existing_perm)
                    print(f"- Permission already exists: {existing_perm.code}")

            # Create lookup dictionary for permissions by code
            permission_lookup = {}
            for perm in created_permissions:
                # Access attributes within session context and store plain ids/codes to avoid lazy loads later
                permission_lookup[perm.code] = {"id": perm.id}

            # Create sample roles
            roles_data = [
                {
                    "name": "Administrator",
                    "description": "System administrator with full access",
                    "is_system": True,
                },
                {
                    "name": "User Manager",
                    "description": "Manages user accounts and roles",
                },
                {
                    "name": "Viewer",
                    "description": "Read-only access to system information",
                },
                {"name": "Editor", "description": "Can create and edit content"},
            ]

            created_roles = []
            for role_data in roles_data:
                role_data_ins = RoleCreate(**role_data)
                # Check if role already exists
                existing_role = await role_serializer._get_role_by_name(
                    role_data["name"]
                )
                if not existing_role:
                    role = await role_serializer.create_role(role_data_ins)
                    created_roles.append(role)
                    print(f"✓ Created role: {role.name}")
                else:
                    created_roles.append(existing_role)
                    print(f"- Role already exists: {existing_role.name}")

            # Create lookup dictionary for roles by name
            role_lookup = {}
            for role in created_roles:
                role_lookup[role.name] = {"id": role.id}

            # Assign permissions to roles
            role_permission_mapping = {
                "Administrator": ["admin:full_access"],  # Admin gets everything
                "User Manager": [
                    "user:read",
                    "user:write",
                    "user:delete",
                    "role:read",
                    "role:write",
                ],
                "Viewer": ["user:read", "role:read", "permission:read"],
                "Editor": ["user:read", "user:write", "role:read"],
            }

            for role_name, permission_codes in role_permission_mapping.items():
                role_info = role_lookup.get(role_name)
                if role_info:
                    for perm_code in permission_codes:
                        permission_info = permission_lookup.get(perm_code)
                        if permission_info:
                            # Assign permission to role using existing method
                            try:
                                assignment_data = RolePermissionAssignment(
                                    role_ids=[role_info["id"]],
                                    assigned_by=1,  # System assignment
                                    expires_at=None,
                                )
                                await permission_serializer.assign_roles(
                                    permission_info["id"], assignment_data
                                )
                                print(f"✓ Assigned {perm_code} to {role_name}")
                            except Exception as e:
                                # Role might already be assigned, which is fine
                                if "already" in str(e).lower():
                                    print(
                                        f"- Permission {perm_code} already assigned to {role_name}"
                                    )
                                else:
                                    print(
                                        f"⚠ Warning: Could not assign {perm_code} to {role_name}: {e}"
                                    )

            # Create sample users
            users_data = [
                {
                    "name": "admin",
                    "en_name": "Admin User",
                    "email": "admin@example.com",
                    "password": "y6ZreZqlZeBeIl",
                    "mobile": "13800138000",
                    "user_id": "ADMIN001",
                    "status": 1,
                    "locked": 0,
                },
                {
                    "name": "john_doe",
                    "en_name": "John Doe",
                    "email": "john.doe@example.com",
                    "password": "y6ZreZqlZeBeIl",
                    "mobile": "13800138001",
                    "user_id": "USER001",
                    "status": 1,
                    "locked": 0,
                },
                {
                    "name": "jane_smith",
                    "en_name": "Jane Smith",
                    "email": "jane.smith@example.com",
                    "password": "y6ZreZqlZeBeIl",
                    "mobile": "13800138002",
                    "user_id": "USER002",
                    "status": 1,
                    "locked": 0,
                },
                {
                    "name": "bob_wilson",
                    "en_name": "Bob Wilson",
                    "email": "bob.wilson@example.com",
                    "password": "y6ZreZqlZeBeIl",
                    "mobile": "13800138003",
                    "user_id": "USER003",
                    "status": 0,  # Inactive
                    "locked": 0,
                },
                {
                    "name": "alice_brown",
                    "en_name": "Alice Brown",
                    "email": "alice.brown@example.com",
                    "password": "y6ZreZqlZeBeIl",
                    "mobile": "13800138004",
                    "user_id": "USER004",
                    "status": 1,
                    "locked": 1,  # Locked
                },
            ]

            created_users = []
            for user_data in users_data:
                ModelUser = get_user_model()
                user_data_ins = ModelUser(**user_data)
                # Check if user already exists
                existing_user = None
                try:
                    # Search for user by name
                    existing_users = await user_serializer.search_users(
                        user_data["name"], limit=1
                    )
                    if existing_users:
                        existing_user = existing_users[0]
                except Exception as e:
                    logger.error(f"Failed to search users: {e}")
                    pass

                if not existing_user:
                    user = await user_serializer.create_user(user_data_ins)
                    created_users.append(user)
                    print(f"✓ Created user: {user.name}")
                else:
                    created_users.append(existing_user)
                    print(f"- User already exists: {existing_user.name}")

            # Create lookup dictionary for users by name
            user_lookup = {}
            for user in created_users:
                user_lookup[user.name] = {"id": user.id}

            # Assign roles to users
            user_role_mapping = {
                "admin": ["Administrator"],
                "john_doe": ["User Manager"],
                "jane_smith": ["Editor"],
                "bob_wilson": ["Viewer"],
                "alice_brown": ["Viewer"],
            }

            for username, role_names in user_role_mapping.items():
                user_info = user_lookup.get(username)
                if user_info:
                    for role_name in role_names:
                        role_info = role_lookup.get(role_name)
                        if role_info:
                            # Assign user to role using existing method
                            try:
                                assignment_data = UserRoleAssignment(
                                    user_ids=[user_info["id"]],
                                    assigned_by=1,  # System assignment
                                    expires_at=None,
                                )
                                await role_serializer.assign_users(
                                    role_info["id"], assignment_data
                                )
                                print(f"✓ Assigned {role_name} to {username}")
                            except Exception as e:
                                # User might already be assigned, which is fine
                                if (
                                    "already" in str(e).lower()
                                    or "exists" in str(e).lower()
                                ):
                                    print(
                                        f"- Role {role_name} already assigned to {username}"
                                    )
                                else:
                                    print(
                                        f"⚠ Warning: Could not assign {role_name} to {username}: {e}"
                                    )

            # Print summary
            print("\n📊 Summary:")
            print(f"   • {len(created_permissions)} permissions")
            print(f"   • {len(created_roles)} roles")
            print(f"   • {len(created_users)} users")

            await session.commit()
            print("\n🎉 Sample data created successfully!")

        except Exception as e:
            await session.rollback()
            print(f"\n❌ Error creating sample data: {e}")
            raise
