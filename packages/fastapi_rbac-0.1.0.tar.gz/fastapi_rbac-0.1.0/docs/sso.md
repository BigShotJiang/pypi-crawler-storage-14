# FastAPI-RBAC SSO 集成指南

本文档详细说明如何在 FastAPI-RBAC 中集成自定义 SSO（单点登录）系统。

## 目录

1. [概述](#概述)
2. [架构设计](#架构设计)
3. [实现步骤](#实现步骤)
4. [代码示例](#代码示例)
5. [配置说明](#配置说明)
6. [使用方式](#使用方式)
7. [最佳实践](#最佳实践)
8. [故障排除](#故障排除)

## 概述

FastAPI-RBAC 支持通过外部认证客户端集成各种 SSO 系统。通过实现 `BaseExternalAuthClient` 接口，您可以轻松集成任何自定义的 SSO 认证系统。

### 核心特性

- ✅ 支持多种 SSO 协议
- ✅ 自动用户创建和同步
- ✅ 令牌验证和用户信息获取
- ✅ 与 RBAC 系统无缝集成
- ✅ 灵活的配置管理

## 架构设计

### 组件关系图

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   FastAPI App   │    │   RBAC Plugin    │    │  SSO Client     │
│                 │    │                  │    │                 │
│ ┌─────────────┐ │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ │   Routes    │ │◄──►│ │   Middleware │ │◄──►│ │   Token     │ │
│ └─────────────┘ │    │ └──────────────┘ │    │ │ Validation  │ │
│                 │    │                  │    │ └─────────────┘ │
│ ┌─────────────┐ │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ │ Dependencies│ │◄──►│ │ User Manager │ │◄──►│ │ User Info   │ │
│ └─────────────┘ │    │ └──────────────┘ │    │ │ Fetching    │ │
└─────────────────┘    └──────────────────┘    │ └─────────────┘ │
                                               └─────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │   SSO Server    │
                                               │                 │
                                               │ ┌─────────────┐ │
                                               │ │   Token     │ │
                                               │ │ Validation  │ │
                                               │ └─────────────┘ │
                                               │ ┌─────────────┐ │
                                               │ │   User      │ │
                                               │ │   Data      │ │
                                               │ └─────────────┘ │
                                               └─────────────────┘
```

### 核心组件

1. **SSOClient**: 继承 `BaseExternalAuthClient`，实现 SSO 特定逻辑
2. **SSOUserModel**: 扩展基础用户模型，添加 SSO 特定字段
3. **SSOUserSerializer**: 处理 SSO 用户的创建、更新和验证
4. **RBACConfig**: 配置外部认证客户端

## 实现步骤

### 步骤 1: 创建 SSO 用户模型

```python
# sso_extend/sso_user_model.py
from sqlmodel import Field, Relationship
from datetime import datetime
from typing import List, Optional
from fastapi_rbac.models.base_user_model import BaseUser
if TYPE_CHECKING:
    from fastapi_rbac.models.user_role_relation import UserRoleRelation

class SSOUserModel(BaseUser, table=True):
    __tablename__: str = "t_users"

    # 基础用户信息
    name: str = Field(index=True, max_length=50, min_length=5, description="用户名")
    en_name: str = Field(index=True, max_length=50, description="英文名")
    mobile: str = Field(index=True, max_length=100, description="手机号")

    # SSO 特定字段
    user_id: Optional[str] = Field(
        default=None,
        index=True,
        max_length=100,
        description="SSO系统用户ID"
    )

    # 状态管理
    status: int = Field(default=0, description="用户状态")
    locked: int = Field(default=0, description="用户锁定状态")

    # 时间戳
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="更新时间",
        sa_column_kwargs={"onupdate": datetime.now},
    )
    last_login: Optional[datetime] = Field(default=None, description="最后登录时间")

    # 关系定义
    user_roles: List["UserRoleRelation"] = Relationship(
        sa_relationship_kwargs={
            "primaryjoin": "SSOUserModel.id==UserRoleRelation.user_id",
            "foreign_keys": "[UserRoleRelation.user_id]",
            "cascade": "all, delete-orphan",
        },
    )
```

### 步骤 2: 实现 SSO 客户端

```python
# sso_extend/sso_client.py
import httpx
import time
import hashlib
from typing import Dict, Any
from fastapi import Request
from sqlmodel.ext.asyncio.session import AsyncSession
from fastapi_rbac.external_auth.base_client import BaseExternalAuthClient
from fastapi_rbac.config import RBACConfig
from loguru import logger

{from sso_extend.sso_user_model import SSOUserModel}  # add you UserModel

class SSOClient(BaseExternalAuthClient):
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        
        # SSO 系统配置 - 直接在客户端中配置
        self.SSO_DOMAIN = "https://your-sso-server.com"
        self.SECURITY = "your_security_key"
        self.PLATFORM_ID = "your_platform_id"
        
        # HTTP 客户端
        self.client = httpx.AsyncClient(base_url=self.SSO_DOMAIN)

    def _validate_config(self) -> None:
        """验证 SSO 配置"""
        # 可以在这里添加配置验证逻辑
        pass

    async def get_user_info(self, request: Request, db_session: AsyncSession) -> SSOUserModel:
        """从 SSO 系统获取用户信息"""
        auth_token = request.headers.get("X-Auth-Token")
        if not auth_token:
            raise ValueError("缺少 SSO 认证令牌")
        
        # 验证令牌并获取用户信息
        resp = await self.validate_token(auth_token)
        if resp.status_code == 200:
            user_data = resp.json()["data"]
            return SSOUserModel(**user_data)
        else:
            raise ValueError("SSO 令牌验证失败")

    async def validate_token(self, auth_token: str) -> httpx.Response:
        """验证 SSO 令牌"""
        url = "/auth/verify-access-token"
        post_data = {"platform_id": self.PLATFORM_ID}
        return await self.client.post(
            url=url, 
            json=post_data, 
            headers={"X-Token": auth_token}
        )

    def get_provider_name(self) -> str:
        """获取认证提供者名称"""
        return "sso"

    def _sign(self) -> tuple[int, str]:
        """生成签名（如果需要）"""
        timestamp = int(time.time())
        sign = hashlib.md5(f"{timestamp}_{self.SECURITY}".encode()).hexdigest()
        return timestamp, sign

    async def health_check(self) -> bool:
        """检查 SSO 服务可用性"""
        try:
            response = await self.client.get("/health")
            return response.status_code == 200
        except Exception:
            return False
```

### 步骤 3: 实现用户序列化器

```python
# sso_extend/sso_user_serializer.py
from typing import Any
from fastapi_rbac.models import get_user_model
from fastapi_rbac.serializers.base_user_serializer import BaseUserSerializer
from sqlmodel.ext.asyncio.session import AsyncSession
from loguru import logger

from sso_extend.sso_client import SSOClient
from sso_extend.sso_user_model import SSOUserModel

class SSOUserSerializer(BaseUserSerializer):
    """SSO 用户序列化器"""
    
    user_model = SSOUserModel

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)

    def _hash_password(self, password: str) -> str:
        """哈希密码"""
        import bcrypt
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    async def validate_user_from_sso(self, auth_token: str) -> Any:
        """从 SSO 验证用户"""
        from fastapi_rbac.config import RBACConfig
        
        config = RBACConfig(
            database_url="your_database_url",
            user_serializer=SSOUserSerializer,
        )
        sso_client = SSOClient(config)
        sso_user = await sso_client.validate_token(auth_token)
        return sso_user

    async def create_user(self, auth_token: str) -> Any:
        """创建 SSO 用户"""
        try:
            # 验证 SSO 用户
            sso_user_resp = await self.validate_user_from_sso(auth_token)
            
            # 创建用户
            User = get_user_model()
            user = await self.create(User(**sso_user_resp.model_dump()))
            
            logger.info(f"成功创建 SSO 用户: {user.email}")
            return user
            
        except Exception as e:
            logger.error(f"创建 SSO 用户失败: {str(e)}")
            raise

    async def update_user(self, user_id: int, user_data) -> Any:
        """更新 SSO 用户"""
        try:
            # 检查邮箱是否已存在
            if user_data.email:
                existing_user = await self._get_user_by_email(user_data.email)
                if existing_user and existing_user.id != user_id:
                    raise ValueError(f"邮箱 {user_data.email} 已被其他用户使用")

            # 创建更新数据字典
            update_dict = user_data.model_dump(exclude_unset=True)

            # 处理密码更新
            if hasattr(user_data, "password") and user_data.password:
                update_dict["password"] = self._hash_password(user_data.password)

            # 更新用户
            User = get_user_model()
            user = await self.update(user_id, User(**update_dict))
            
            logger.info(f"成功更新 SSO 用户: {user.email}")
            return user

        except Exception as e:
            logger.error(f"更新 SSO 用户失败: {str(e)}")
            raise
```

### 步骤 4: 配置主应用

```python
# main.py
from contextlib import asynccontextmanager
import os
from fastapi import Depends, FastAPI
from fastapi_rbac.config import RBACConfig
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import SQLModel
from sso_extend.sso_user_serializer import SSOUserSerializer
from sso_extend.sso_client import SSOClient
from fastapi_rbac.dependencies.login_dependencies import require_external_login
from fastapi_rbac.plugin import RBACPlugin

# 数据库配置
database_url = os.getenv(
    "RBAC_DATABASE_URL", 
    "mysql+aiomysql://root:password@localhost:3306/sso-example"
)

database_params = {
    "echo": False,
    "future": True,
    "pool_recycle": 60 * 5,
    "pool_pre_ping": True,
    "pool_size": 10,
    "max_overflow": 20,
}

# RBAC 配置
rbac_settings = RBACConfig(
    database_url=database_url,
    database_params=database_params,
    user_serializer=SSOUserSerializer,
    enable_external_auth=True,
    external_auth_clients={
        "sso": SSOClient,  # 注册 SSO 客户端
    },
)

# 创建数据库引擎
engine = create_async_engine(
    rbac_settings.database_url,
    **rbac_settings.database_params,
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.drop_all)
        await conn.run_sync(SQLModel.metadata.create_all)
    yield
    await engine.dispose()

# 创建 FastAPI 应用
app = FastAPI(lifespan=lifespan)

# 初始化 RBAC 插件
RBACPlugin(app, rbac_settings)

@app.get("/")
async def read_root(_: bool = Depends(require_external_login())):
    """受保护的端点，需要 SSO 认证"""
    return {"message": "Hello, SSO World!"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
```

## 配置说明

### 环境变量

```bash
# 数据库配置
RBAC_DATABASE_URL=mysql+aiomysql://user:password@host:port/database

# 日志配置
LOG_LEVEL=INFO
```

### SSO 客户端配置

在 `SSOClient` 类中直接配置 SSO 系统参数：

```python
class SSOClient(BaseExternalAuthClient):
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        
        # SSO 系统配置
        self.SSO_DOMAIN = "https://your-sso-server.com"
        self.SECURITY = "your_security_key"
        self.PLATFORM_ID = "your_platform_id"
        
        # 其他配置...
```

## 使用方式

### 1. 发起 SSO 认证

客户端需要提供以下请求头：

```http
GET /protected-endpoint
Headers:
  X-Auth-Type: sso
  X-Auth-Token: your_sso_token
```

### 2. 处理认证流程

```python
# 客户端示例
import httpx

async def access_protected_resource(sso_token: str):
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/",
            headers={
                "X-Auth-Type": "sso",
                "X-Auth-Token": sso_token
            }
        )
        return response.json()
```

### 3. 错误处理

```python
try:
    result = await access_protected_resource(token)
    print("认证成功:", result)
except httpx.HTTPStatusError as e:
    if e.response.status_code == 401:
        print("认证失败，请重新登录")
    else:
        print(f"请求失败: {e.response.status_code}")
```

## 最佳实践

### 1. 安全配置

- **令牌验证**: 始终验证 SSO 令牌的有效性
- **HTTPS**: 生产环境必须使用 HTTPS
- **令牌过期**: 实现令牌过期检查机制
- **错误处理**: 不要暴露敏感的错误信息

### 2. 性能优化

- **连接池**: 使用 HTTP 连接池减少连接开销
- **缓存**: 缓存用户信息减少 SSO 服务器请求
- **异步处理**: 使用异步 HTTP 客户端

### 3. 监控和日志

```python
import logging
from loguru import logger

# 配置日志
logger.add("sso.log", rotation="1 day", retention="30 days")

# 在关键操作中添加日志
async def validate_token(self, auth_token: str):
    logger.info(f"开始验证 SSO 令牌: {auth_token[:10]}...")
    try:
        result = await self._validate_with_sso_server(auth_token)
        logger.info("SSO 令牌验证成功")
        return result
    except Exception as e:
        logger.error(f"SSO 令牌验证失败: {str(e)}")
        raise
```

### 4. 配置管理

```python
import os
from typing import Optional

class SSOClient(BaseExternalAuthClient):
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        
        # 从环境变量读取配置
        self.SSO_DOMAIN = os.getenv("SSO_DOMAIN", "https://default-sso.com")
        self.SECURITY = os.getenv("SSO_SECURITY_KEY")
        self.PLATFORM_ID = os.getenv("SSO_PLATFORM_ID")
        
        if not self.SECURITY or not self.PLATFORM_ID:
            raise ValueError("SSO 配置不完整")
```

## 故障排除

### 常见问题

#### 1. "SSO 令牌验证失败" 错误

**可能原因**:
- SSO 服务器不可达
- 令牌格式错误
- 令牌已过期

**解决方案**:
```python
async def validate_token(self, auth_token: str):
    try:
        # 检查令牌格式
        if not auth_token or len(auth_token) < 10:
            raise ValueError("令牌格式无效")
        
        # 验证令牌
        response = await self.client.post(
            "/auth/verify-access-token",
            json={"platform_id": self.PLATFORM_ID},
            headers={"X-Token": auth_token},
            timeout=10.0  # 设置超时
        )
        
        if response.status_code == 200:
            return response
        else:
            raise ValueError(f"SSO 服务器返回错误: {response.status_code}")
            
    except httpx.TimeoutException:
        raise ValueError("SSO 服务器响应超时")
    except httpx.ConnectError:
        raise ValueError("无法连接到 SSO 服务器")
```

#### 2. 用户信息同步失败

**可能原因**:
- SSO 服务器返回的数据格式不匹配
- 数据库连接问题
- 用户模型字段映射错误

**解决方案**:
```python
async def get_user_info(self, request: Request, db_session: AsyncSession):
    try:
        auth_token = request.headers.get("X-Auth-Token")
        resp = await self.validate_token(auth_token)
        
        if resp.status_code == 200:
            data = resp.json()
            # 验证数据格式
            if "data" not in data:
                raise ValueError("SSO 响应数据格式错误")
            
            user_data = data["data"]
            # 验证必需字段
            required_fields = ["email", "name"]
            for field in required_fields:
                if field not in user_data:
                    raise ValueError(f"缺少必需字段: {field}")
            
            return SSOUserModel(**user_data)
        else:
            raise ValueError("SSO 令牌验证失败")
            
    except Exception as e:
        logger.error(f"获取用户信息失败: {str(e)}")
        raise
```

#### 3. 数据库连接问题

**解决方案**:
```python
# 检查数据库连接
async def check_database_connection():
    try:
        engine = create_async_engine(database_url)
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        print("数据库连接正常")
    except Exception as e:
        print(f"数据库连接失败: {str(e)}")
```

### 调试技巧

1. **启用详细日志**:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

2. **测试 SSO 连接**:
```python
async def test_sso_connection():
    client = SSOClient(config)
    health = await client.health_check()
    print(f"SSO 服务状态: {'正常' if health else '异常'}")
```

3. **验证令牌格式**:
```python
def validate_token_format(token: str) -> bool:
    # 根据您的 SSO 系统调整验证逻辑
    return len(token) > 10 and token.isalnum()
```

## 扩展功能

### 1. 多 SSO 系统支持

```python
# 支持多个 SSO 系统
rbac_settings = RBACConfig(
    # ... 其他配置
    external_auth_clients={
        "sso1": SSOClient1,
        "sso2": SSOClient2,
        "ldap": LDAPClient,
    },
)
```

### 2. 用户信息缓存

```python
from functools import lru_cache
import asyncio

class CachedSSOClient(SSOClient):
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        self._cache = {}
        self._cache_ttl = 300  # 5分钟缓存

    async def get_user_info(self, request: Request, db_session: AsyncSession):
        auth_token = request.headers.get("X-Auth-Token")
        
        # 检查缓存
        if auth_token in self._cache:
            cached_data, timestamp = self._cache[auth_token]
            if time.time() - timestamp < self._cache_ttl:
                return cached_data
        
        # 获取新数据
        user_info = await super().get_user_info(request, db_session)
        
        # 更新缓存
        self._cache[auth_token] = (user_info, time.time())
        
        return user_info
```

### 3. 自动用户同步

```python
async def sync_user_from_sso(self, user_id: int, auth_token: str):
    """定期同步用户信息"""
    try:
        # 获取最新用户信息
        latest_info = await self.validate_user_from_sso(auth_token)
        
        # 更新本地用户信息
        user = await self.get_by_id(user_id)
        if user:
            user.update_from_sso(latest_info)
            await self.update(user.id, user)
            
    except Exception as e:
        logger.error(f"用户信息同步失败: {str(e)}")
```

---

**注意**: 这是一个通用指南，具体实现需要根据您的 SSO 系统 API 进行调整。请确保在生产环境中进行充分的安全测试。
