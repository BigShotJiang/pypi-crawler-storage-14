# RBAC 序列化器系统

## 概述

RBAC 序列化器系统提供了一个灵活的架构，支持不同的用户模型和相应的业务逻辑。系统能够根据配置自动选择正确的序列化器，确保代码的可维护性和扩展性。

## 架构设计

### 核心组件

1. **BaseUserSerializer**: 抽象基础序列化器，包含所有用户模型通用的方法
2. **DefaultUserSerializer**: 默认用户序列化器，处理无密码功能的用户模型
3. **PasswordUserSerializer**: 密码用户序列化器，处理包含密码功能的用户模型
4. **UserSerializerFactory**: 序列化器工厂，根据配置自动选择正确的序列化器

### 继承关系

```
BaseUserSerializer (抽象基类)
├── DefaultUserSerializer (默认用户)
└── PasswordUserSerializer (密码用户)
```

## 配置选项

### 用户模型配置

系统支持两种配置方式：

#### 1. 自动序列化器选择（推荐）

```python
from fastapi_rbac.config import RBACConfig
from fastapi_rbac.models.pwd_user_model import UserWithPassword

# 使用预定义模型，系统自动选择序列化器
config = RBACConfig(
    database_url="mysql+aiomysql://...",
    user_model=UserWithPassword,  # 系统自动选择 PasswordUserSerializer
)
```

#### 2. 自定义序列化器配置

```python
from fastapi_rbac.config import RBACConfig
from fastapi_rbac.serializers.base_user_serializer import BaseUserSerializer

class CustomUserSerializer(BaseUserSerializer):
    def __init__(self, db_session, user_model):
        super().__init__(db_session, user_model)
    
    async def create_user(self, user_data):
        # 自定义用户创建逻辑
        return await super().create_user(user_data)

config = RBACConfig(
    database_url="mysql+aiomysql://...",
    user_model=CustomUser,
    user_serializer=CustomUserSerializer,  # 明确指定自定义序列化器
)
```

### 配置验证规则

系统会自动验证配置的完整性：

1. **预定义模型**: 不需要指定 `user_serializer`，系统自动选择
2. **继承模型**: 如果自定义模型继承自预定义模型，不需要指定 `user_serializer`
3. **完全自定义模型**: 必须明确指定 `user_serializer`，否则验证失败

### 配置验证示例

```python
# ✅ 预定义模型 - 自动选择序列化器
config1 = RBACConfig(
    user_model=UserWithPassword,  # 系统自动选择 PasswordUserSerializer
)

# ✅ 继承模型 - 自动选择序列化器
class ExtendedUser(UserWithPassword):
    department: str = Field(max_length=100)

config2 = RBACConfig(
    user_model=ExtendedUser,  # 系统自动选择 PasswordUserSerializer
)

# ✅ 自定义模型 + 自定义序列化器
config3 = RBACConfig(
    user_model=CustomUser,
    user_serializer=CustomUserSerializer,  # 明确指定
)

# ❌ 自定义模型 - 缺少序列化器配置
config4 = RBACConfig(
    user_model=CustomUser,  # 验证失败：需要指定 user_serializer
)
```

## 使用方法

### 1. 自动序列化器选择

```python
from fastapi_rbac.serializers import UserSerializerFactory

# 自动选择正确的序列化器
serializer = UserSerializerFactory.create_serializer(db_session)

# 使用序列化器
user = await serializer.get_user(user_id=1)
users = await serializer.get_users(pagination_params)
```

### 2. 直接使用特定序列化器

```python
from fastapi_rbac.serializers import DefaultUserSerializer, PasswordUserSerializer

# 明确使用默认序列化器
default_serializer = DefaultUserSerializer(db_session)

# 明确使用密码序列化器
password_serializer = PasswordUserSerializer(db_session)
```

### 3. 检查序列化器能力

```python
from fastapi_rbac.serializers import UserSerializerFactory

# 检查用户模型是否支持密码
is_password_model = UserSerializerFactory.is_password_user_model(user_model)

# 检查是否为默认用户模型
is_default_model = UserSerializerFactory.is_default_user_model(user_model)

# 获取推荐的序列化器类
serializer_class = UserSerializerFactory.get_serializer_class(user_model)
```

## 序列化器特性

### BaseUserSerializer

提供所有用户模型通用的功能：

- 用户查询（单个、列表、搜索）
- 角色管理（分配、移除、查询）
- 权限查询
- 基础的用户创建和更新

### DefaultUserSerializer

继承自 `BaseUserSerializer`，适用于无密码功能的用户模型：

- 无密码处理逻辑
- 适用于 SSO 集成场景
- 轻量级用户管理

### PasswordUserSerializer

继承自 `BaseUserSerializer`，适用于包含密码功能的用户模型：

- 密码哈希和验证
- 用户认证支持
- 密码更改和重置功能
- 使用 bcrypt 进行密码加密

## 自定义用户模型支持

### 1. 继承现有模型

```python
from fastapi_rbac.models.pwd_user_model import UserWithPassword
from sqlmodel import Field

class MyCustomUser(UserWithPassword, table=True):
    __tablename__ = "t_users"
    
    # 添加自定义字段
    department: str = Field(max_length=100)
    employee_id: str = Field(max_length=50)
    
    # 保持必要的用户角色关系
    user_roles: List["UserRoleRelation"] = Relationship(...)
```

### 2. 继承基础模型

```python
from fastapi_rbac.models.base_user_model import BaseUser
from sqlmodel import Field, Relationship

class MyCustomUser(BaseUser, table=True):
    __tablename__ = "t_users"
    
    # 添加自定义字段
    department: str = Field(max_length=100)
    employee_id: str = Field(max_length=50)
    
    # 必须定义用户角色关系
    user_roles: List["UserRoleRelation"] = Relationship(
        sa_relationship_kwargs={
            "primaryjoin": "MyCustomUser.id==UserRoleRelation.user_id",
            "foreign_keys": "[UserRoleRelation.user_id]",
            "cascade": "all, delete-orphan",
        },
    )
```

### 3. 配置自定义模型

```python
from fastapi_rbac.config import init_rbac_config
from my_models import MyCustomUser

# 初始化配置时指定自定义用户模型
config = init_rbac_config(
    database_url="mysql+aiomysql://...",
    user_model=MyCustomUser,
    # 其他配置...
)
```

## 迁移指南

### 从旧版本迁移

1. **更新导入语句**:
   ```python
   # 旧版本
   from fastapi_rbac.serializers import UserSerializer
   
   # 新版本
   from fastapi_rbac.serializers import UserSerializerFactory, create_user_serializer
   ```

2. **更新序列化器创建**:
   ```python
   # 旧版本
   serializer = UserSerializer(db_session)
   
   # 新版本
   serializer = create_user_serializer(db_session)
   # 或者
   serializer = UserSerializerFactory.create_serializer(db_session)
   ```

3. **保持向后兼容性**:
   - `UserSerializer` 类仍然可用，但标记为遗留类
   - 建议逐步迁移到新的工厂模式

## 最佳实践

### 1. 序列化器选择

- 使用 `UserSerializerFactory.create_serializer()` 进行自动选择
- 在明确知道模型类型时，可以直接使用特定序列化器
- 避免硬编码特定的序列化器类型

### 2. 错误处理

```python
try:
    serializer = UserSerializerFactory.create_serializer(db_session)
    user = await serializer.get_user(user_id=1)
except ValueError as e:
    # 处理序列化器创建失败
    logger.error(f"Failed to create serializer: {e}")
except Exception as e:
    # 处理其他错误
    logger.error(f"Unexpected error: {e}")
```

### 3. 性能优化

- 序列化器实例可以重复使用
- 避免在每次请求时创建新的序列化器实例
- 使用依赖注入来管理序列化器生命周期

### 4. 测试策略

```python
import pytest
from fastapi_rbac.serializers import UserSerializerFactory

def test_serializer_factory():
    # 测试默认用户模型
    serializer = UserSerializerFactory.create_serializer(db_session)
    assert isinstance(serializer, DefaultUserSerializer)
    
    # 测试密码用户模型
    config.user_model = UserWithPassword
    serializer = UserSerializerFactory.create_serializer(db_session)
    assert isinstance(serializer, PasswordUserSerializer)
```

## 故障排除

### 常见问题

1. **序列化器创建失败**:
   - 检查 RBAC 配置是否正确初始化
   - 确认用户模型类型是否被识别

2. **类型检查错误**:
   - 动态模型访问可能触发类型检查器警告
   - 使用 `# type: ignore` 注释来抑制相关警告

3. **密码功能不可用**:
   - 确认用户模型是否包含密码字段
   - 检查是否正确继承了 `PasswordMixin`

### 调试技巧

```python
# 启用详细日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 检查当前配置
from fastapi_rbac.config import get_rbac_config
config = get_rbac_config()
print(f"User model: {config.user_model}")

# 检查序列化器类型
serializer = UserSerializerFactory.create_serializer(db_session)
print(f"Serializer type: {type(serializer)}")
```

## 总结

新的序列化器系统提供了：

- **灵活性**: 支持不同的用户模型和业务需求
- **可维护性**: 清晰的继承结构和职责分离
- **可扩展性**: 易于添加新的用户模型和序列化器
- **向后兼容性**: 保持现有代码的兼容性

通过使用这个系统，您可以轻松地管理不同类型的用户模型，同时保持代码的清晰和可维护性。
