# FastAPI-RBAC OAuth 集成指南

本文档详细说明如何在 FastAPI-RBAC 中集成各种 OAuth 2.0 认证系统（如 GitHub、Google、Microsoft 等）。

## 目录

1. [概述](#概述)
2. [OAuth 2.0 流程](#oauth-20-流程)
3. [架构设计](#架构设计)
4. [实现步骤](#实现步骤)
5. [代码示例](#代码示例)
6. [配置说明](#配置说明)
7. [使用方式](#使用方式)
8. [最佳实践](#最佳实践)
9. [故障排除](#故障排除)

## 概述

FastAPI-RBAC 支持通过外部认证客户端集成各种 OAuth 2.0 认证系统。通过实现 `BaseExternalAuthClient` 接口，您可以轻松集成 GitHub、Google、Microsoft、Facebook 等主流 OAuth 提供者。

### 核心特性

- ✅ 支持 OAuth 2.0 授权码流程
- ✅ 自动令牌交换和刷新
- ✅ 用户信息自动同步
- ✅ 多 OAuth 提供者支持
- ✅ 安全的令牌验证
- ✅ 与 RBAC 系统无缝集成

## OAuth 2.0 流程

### 标准授权码流程

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌─────────────┐
│   用户      │    │   FastAPI    │    │  OAuth      │    │  数据库     │
│   浏览器    │    │   应用       │    │  提供者     │    │             │
└─────────────┘    └──────────────┘    └─────────────┘    └─────────────┘
       │                   │                   │                   │
       │ 1. 访问受保护资源  │                   │                   │
       ├──────────────────►│                   │                   │
       │                   │                   │                   │
       │ 2. 重定向到OAuth   │                   │                   │
       │◄──────────────────┤                   │                   │
       │                   │                   │                   │
       │ 3. 用户授权       │                   │                   │
       ├──────────────────────────────────────►│                   │
       │                   │                   │                   │
       │ 4. 授权码回调     │                   │                   │
       │◄──────────────────────────────────────┤                   │
       │                   │                   │                   │
       │ 5. 交换访问令牌   │                   │                   │
       ├──────────────────►│                   │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │                   │
       │ 6. 获取用户信息   │                   │                   │
       │                   ├──────────────────►│                   │
       │                   │                   │                   │
       │ 7. 创建/更新用户  │                   │                   │
       │                   ├──────────────────────────────────────►│
       │                   │                   │                   │
       │ 8. 返回访问令牌   │                   │                   │
       │◄──────────────────┤                   │                   │
       │                   │                   │                   │
       │ 9. 使用令牌访问   │                   │                   │
       ├──────────────────►│                   │                   │
```

## 架构设计

### 组件关系图

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   FastAPI App   │    │   RBAC Plugin    │    │  OAuth Client   │
│                 │    │                  │    │                 │
│ ┌─────────────┐ │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ │   Routes    │ │◄──►│ │   Middleware │ │◄──►│ │ Authorization│ │
│ └─────────────┘ │    │ └──────────────┘ │    │ │   Flow      │ │
│                 │    │                  │    │ └─────────────┘ │
│ ┌─────────────┐ │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ │ Dependencies│ │◄──►│ │ User Manager │ │◄──►│ │ Token       │ │
│ └─────────────┘ │    │ └──────────────┘ │    │ │ Exchange    │ │
└─────────────────┘    └──────────────────┘    │ └─────────────┘ │
                                               │ ┌─────────────┐ │
                                               │ │ User Info   │ │
                                               │ │ Fetching    │ │
                                               │ └─────────────┘ │
                                               └─────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │  OAuth Provider │
                                               │                 │
                                               │ ┌─────────────┐ │
                                               │ │ Authorization│ │
                                               │ │   Server    │ │
                                               │ └─────────────┘ │
                                               │ ┌─────────────┐ │
                                               │ │ Token       │ │
                                               │ │   Server    │ │
                                               │ └─────────────┘ │
                                               │ ┌─────────────┐ │
                                               │ │ Resource    │ │
                                               │ │   Server    │ │
                                               │ └─────────────┘ │
                                               └─────────────────┘
```

### 核心组件

1. **OAuthClient**: 继承 `BaseExternalAuthClient`，实现 OAuth 特定逻辑
2. **OAuthUserModel**: 扩展基础用户模型，添加 OAuth 特定字段
3. **OAuthUserSerializer**: 处理 OAuth 用户的创建、更新和验证
4. **RBACConfig**: 配置外部认证客户端

## 实现步骤

### 步骤 1: 创建 OAuth 用户模型

```python
# oauth_extend/oauth_user_model.py
from sqlmodel import Field, Relationship
from datetime import datetime
from typing import List, Optional
from fastapi_rbac.models.base_user_model import BaseUser

class OAuthUserModel(BaseUser, table=True):
    __tablename__: str = "t_oauth_users"

    # 基础用户信息
    name: str = Field(index=True, max_length=50, min_length=1, description="用户显示名称")
    en_name: str = Field(index=True, max_length=50, description="英文名称/用户名")
    mobile: str = Field(index=True, max_length=100, default="", description="手机号码")

    # OAuth 特定字段
    oauth_id: Optional[str] = Field(
        default=None, index=True, description="OAuth 提供者用户ID"
    )
    oauth_login: Optional[str] = Field(
        default=None, index=True, max_length=100, description="OAuth 用户名"
    )
    oauth_avatar_url: Optional[str] = Field(
        default=None, max_length=500, description="OAuth 头像URL"
    )
    oauth_html_url: Optional[str] = Field(
        default=None, max_length=500, description="OAuth 个人主页URL"
    )
    oauth_provider: Optional[str] = Field(
        default=None, index=True, max_length=50, description="OAuth 提供者名称"
    )
    
    # 统计信息（根据提供者调整）
    public_repos: int = Field(default=0, description="公开仓库数量")
    followers: int = Field(default=0, description="关注者数量")
    following: int = Field(default=0, description="关注数量")
    
    # 扩展信息
    bio: Optional[str] = Field(default=None, max_length=500, description="个人简介")
    company: Optional[str] = Field(default=None, max_length=200, description="公司信息")
    location: Optional[str] = Field(default=None, max_length=200, description="位置信息")
    blog: Optional[str] = Field(default=None, max_length=500, description="博客URL")

    # 外部系统集成字段
    user_id: Optional[str] = Field(
        default=None,
        index=True,
        max_length=100,
        description="外部系统用户ID，用于SSO集成",
    )

    # 状态管理
    status: int = Field(default=1, description="用户状态: 0-禁用, 1-启用")
    locked: int = Field(default=0, description="用户锁定状态: 0-未锁定, 1-锁定")

    # 时间戳字段
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="更新时间",
        sa_column_kwargs={"onupdate": datetime.now},
    )
    last_login: Optional[datetime] = Field(default=None, description="最后登录时间")
    oauth_updated_at: Optional[datetime] = Field(
        default=None, description="OAuth信息最后更新时间"
    )

    # 关系定义
    user_roles: List["UserRoleRelation"] = Relationship(
        sa_relationship_kwargs={
            "primaryjoin": "OAuthUserModel.id==UserRoleRelation.user_id",
            "foreign_keys": "[UserRoleRelation.user_id]",
            "cascade": "all, delete-orphan",
        },
    )

    @property
    def display_name(self) -> str:
        """获取用户显示名称"""
        return self.name or self.en_name or self.oauth_login or "未知用户"

    @property
    def profile_url(self) -> str:
        """获取个人主页URL"""
        return self.oauth_html_url or f"https://{self.oauth_provider}.com/{self.oauth_login}"

    def update_oauth_info(self, oauth_data: dict) -> None:
        """更新OAuth用户信息"""
        self.oauth_id = str(oauth_data.get("id", ""))
        self.oauth_login = oauth_data.get("login")
        self.oauth_avatar_url = oauth_data.get("avatar_url")
        self.oauth_html_url = oauth_data.get("html_url")
        self.oauth_provider = oauth_data.get("provider", "unknown")
        
        # 更新基础信息
        if oauth_data.get("name"):
            self.name = oauth_data["name"]
        if oauth_data.get("login"):
            self.en_name = oauth_data["login"]
        if oauth_data.get("email"):
            self.email = oauth_data["email"]
        
        # 更新统计信息
        self.public_repos = oauth_data.get("public_repos", 0)
        self.followers = oauth_data.get("followers", 0)
        self.following = oauth_data.get("following", 0)
        
        # 更新扩展信息
        self.bio = oauth_data.get("bio")
        self.company = oauth_data.get("company")
        self.location = oauth_data.get("location")
        self.blog = oauth_data.get("blog")
        
        self.oauth_updated_at = datetime.now()
```

### 步骤 2: 实现 OAuth 客户端

```python
# oauth_extend/oauth_client.py
import httpx
from typing import Dict, Any, Optional
from fastapi import Request
from sqlmodel.ext.asyncio.session import AsyncSession
from fastapi_rbac.external_auth.base_client import BaseExternalAuthClient
from fastapi_rbac.config import RBACConfig
from loguru import logger

from oauth_extend.oauth_user_model import OAuthUserModel

class OAuthClient(BaseExternalAuthClient):
    """
    OAuth 2.0 认证客户端基类
    
    实现 OAuth 2.0 授权码流程，包括：
    1. 获取用户授权码
    2. 交换访问令牌
    3. 获取用户信息
    4. 验证令牌有效性
    """
    
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        
        # OAuth 配置 - 直接在客户端中配置
        self.client_id = "your_oauth_client_id"
        self.client_secret = "your_oauth_client_secret"
        self.redirect_uri = "http://localhost:8000/auth/oauth/callback"
        self.scope = "user:email"
        
        # OAuth 端点
        self.authorize_url = "https://oauth-provider.com/oauth/authorize"
        self.token_url = "https://oauth-provider.com/oauth/access_token"
        self.user_info_url = "https://api.oauth-provider.com/user"
        
        # HTTP 客户端
        self.client = httpx.AsyncClient(
            headers={
                "Accept": "application/json",
                "User-Agent": "FastAPI-RBAC-OAuth"
            }
        )

    def _validate_config(self) -> None:
        """验证 OAuth 配置"""
        # 可以在这里添加配置验证逻辑
        pass

    async def get_user_info(self, request: Request, db_session: AsyncSession) -> OAuthUserModel:
        """从 OAuth 提供者获取用户信息"""
        auth_token = request.headers.get("X-Auth-Token")
        if not auth_token:
            raise ValueError("缺少 OAuth 访问令牌")
        
        # 获取用户信息
        user_data = await self._fetch_user_info(auth_token)
        
        # 转换为 OAuthUserModel
        oauth_user = OAuthUserModel(
            email=user_data.get("email", ""),
            name=user_data.get("name", user_data.get("login", "")),
            en_name=user_data.get("login", ""),
            mobile="",  # OAuth 通常不提供手机号
            user_id=str(user_data.get("id", "")),
            oauth_id=str(user_data.get("id", "")),
            oauth_login=user_data.get("login"),
            oauth_avatar_url=user_data.get("avatar_url"),
            oauth_html_url=user_data.get("html_url"),
            oauth_provider=self.get_provider_name(),
            public_repos=user_data.get("public_repos", 0),
            followers=user_data.get("followers", 0),
            following=user_data.get("following", 0),
            bio=user_data.get("bio"),
            company=user_data.get("company"),
            location=user_data.get("location"),
            blog=user_data.get("blog"),
            status=1,  # 激活状态
            locked=0   # 未锁定
        )
        
        return oauth_user

    async def validate_token(self, auth_token: str) -> bool:
        """验证 OAuth 访问令牌"""
        try:
            response = await self.client.get(
                self.user_info_url,
                headers={"Authorization": f"Bearer {auth_token}"}
            )
            
            if response.status_code == 200:
                logger.info("OAuth 令牌验证成功")
                return True
            else:
                logger.warning(f"OAuth 令牌验证失败: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"OAuth 令牌验证异常: {str(e)}")
            return False

    def get_provider_name(self) -> str:
        """获取认证提供者名称"""
        return "oauth"

    async def _fetch_user_info(self, access_token: str) -> Dict[str, Any]:
        """从 OAuth API 获取用户信息"""
        try:
            # 获取用户基本信息
            user_response = await self.client.get(
                self.user_info_url,
                headers={"Authorization": f"Bearer {access_token}"}
            )
            
            if user_response.status_code != 200:
                raise Exception(f"获取用户信息失败: {user_response.status_code}")
            
            user_data = user_response.json()
            
            # 如果用户没有公开邮箱，尝试获取私有邮箱
            if not user_data.get("email"):
                emails_response = await self.client.get(
                    f"{self.user_info_url}/emails",
                    headers={"Authorization": f"Bearer {access_token}"}
                )
                
                if emails_response.status_code == 200:
                    emails = emails_response.json()
                    # 查找主要邮箱或第一个邮箱
                    primary_email = next(
                        (email["email"] for email in emails if email.get("primary")),
                        emails[0]["email"] if emails else None,
                    )
                    if primary_email:
                        user_data["email"] = primary_email
            
            return user_data
            
        except Exception as e:
            logger.error(f"获取用户信息异常: {str(e)}")
            raise

    async def exchange_code_for_token(self, code: str) -> Dict[str, Any]:
        """使用授权码交换访问令牌"""
        try:
            response = await self.client.post(
                self.token_url,
                data={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "code": code,
                    "redirect_uri": self.redirect_uri,
                    "grant_type": "authorization_code"
                },
                headers={"Accept": "application/json"}
            )
            
            if response.status_code == 200:
                token_data = response.json()
                if "access_token" in token_data:
                    logger.info("成功获取 OAuth 访问令牌")
                    return token_data
                else:
                    error_msg = token_data.get("error_description", "未知错误")
                    raise Exception(f"获取访问令牌失败: {error_msg}")
            else:
                raise Exception(f"OAuth 请求失败: {response.status_code}")
                
        except Exception as e:
            logger.error(f"交换 OAuth 访问令牌异常: {str(e)}")
            raise

    def get_authorization_url(self, state: str = None) -> str:
        """生成 OAuth 授权URL"""
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": self.scope,
            "response_type": "code"
        }
        
        if state:
            params["state"] = state
        
        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        return f"{self.authorize_url}?{query_string}"

    async def health_check(self) -> bool:
        """检查 OAuth 服务可用性"""
        try:
            response = await self.client.get(f"{self.user_info_url}/health")
            return response.status_code == 200
        except Exception:
            return False
```

### 步骤 3: 实现用户序列化器

```python
# oauth_extend/oauth_user_serializer.py
from typing import Any, Optional
from fastapi_rbac.models import get_user_model
from fastapi_rbac.serializers.base_user_serializer import BaseUserSerializer
from sqlmodel.ext.asyncio.session import AsyncSession
from loguru import logger

from oauth_extend.oauth_client import OAuthClient
from oauth_extend.oauth_user_model import OAuthUserModel

class OAuthUserSerializer(BaseUserSerializer):
    """OAuth 用户序列化器"""
    
    user_model = OAuthUserModel

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)

    def _hash_password(self, password: str) -> str:
        """哈希密码（OAuth 用户通常不需要密码）"""
        import bcrypt
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    async def validate_user_from_oauth(self, auth_token: str) -> OAuthUserModel:
        """从 OAuth 验证用户"""
        from fastapi_rbac.config import RBACConfig
        
        config = RBACConfig(
            database_url="your_database_url",
            user_serializer=OAuthUserSerializer,
        )
        oauth_client = OAuthClient(config)
        
        # 验证令牌并获取用户信息
        if await oauth_client.validate_token(auth_token):
            from fastapi import Request
            from unittest.mock import Mock
            
            mock_request = Mock(spec=Request)
            mock_request.headers = {"X-Auth-Token": auth_token}
            
            oauth_user = await oauth_client.get_user_info(mock_request, self.db_session)
            return oauth_user
        else:
            raise ValueError("OAuth 令牌验证失败")

    async def create_user(self, auth_token: str) -> Any:
        """创建 OAuth 用户"""
        try:
            # 验证 OAuth 用户
            oauth_user_data = await self.validate_user_from_oauth(auth_token)
            
            # 检查用户是否已存在
            existing_user = await self._get_user_by_oauth_id(oauth_user_data.oauth_id)
            if existing_user:
                logger.info(f"OAuth 用户已存在: {existing_user.oauth_login}")
                return existing_user
            
            # 检查邮箱是否已存在
            if oauth_user_data.email:
                existing_user_by_email = await self._get_user_by_email(oauth_user_data.email)
                if existing_user_by_email:
                    logger.warning(f"邮箱 {oauth_user_data.email} 已被其他用户使用")
                    # 更新现有用户的 OAuth 信息
                    existing_user_by_email.update_oauth_info(oauth_user_data.model_dump())
                    await self.update(existing_user_by_email.id, existing_user_by_email)
                    return existing_user_by_email
            
            # 创建新用户
            User = get_user_model()
            user_data = User(
                email=oauth_user_data.email,
                name=oauth_user_data.name,
                en_name=oauth_user_data.en_name,
                mobile=oauth_user_data.mobile,
                user_id=oauth_user_data.user_id,
                status=oauth_user_data.status,
                locked=oauth_user_data.locked,
            )
            
            user = await self.create(user_data)
            
            # 更新 OAuth 特定信息
            user.update_oauth_info(oauth_user_data.model_dump())
            await self.update(user.id, user)
            
            logger.info(f"成功创建 OAuth 用户: {user.oauth_login}")
            return user
            
        except Exception as e:
            logger.error(f"创建 OAuth 用户失败: {str(e)}")
            raise

    async def update_user(self, user_id: int, user_data: Any) -> Any:
        """更新 OAuth 用户"""
        try:
            # 检查邮箱是否已存在
            if user_data.email:
                existing_user = await self._get_user_by_email(user_data.email)
                if existing_user and existing_user.id != user_id:
                    raise ValueError(f"邮箱 {user_data.email} 已被其他用户使用")

            # 创建更新数据字典
            update_dict = user_data.model_dump(exclude_unset=True)

            # 处理密码更新（OAuth 用户通常不需要）
            if hasattr(user_data, "password") and user_data.password:
                update_dict["password"] = self._hash_password(user_data.password)

            # 更新用户
            User = get_user_model()
            user = await self.update(user_id, User(**update_dict))
            
            logger.info(f"成功更新 OAuth 用户: {user.oauth_login}")
            return user

        except Exception as e:
            logger.error(f"更新 OAuth 用户失败: {str(e)}")
            raise

    async def _get_user_by_oauth_id(self, oauth_id: str) -> Optional[OAuthUserModel]:
        """根据 OAuth ID 获取用户"""
        try:
            from sqlmodel import select
            
            statement = select(OAuthUserModel).where(OAuthUserModel.oauth_id == oauth_id)
            result = await self.db_session.exec(statement)
            return result.first()
            
        except Exception as e:
            logger.error(f"根据 OAuth ID 获取用户失败: {str(e)}")
            return None

    async def sync_oauth_user_info(self, user_id: int, auth_token: str) -> OAuthUserModel:
        """同步 OAuth 用户信息"""
        try:
            # 获取用户
            user = await self.get_by_id(user_id)
            if not user:
                raise ValueError(f"用户不存在: {user_id}")

            # 获取最新的 OAuth 信息
            oauth_user_data = await self.validate_user_from_oauth(auth_token)
            
            # 更新 OAuth 信息
            user.update_oauth_info(oauth_user_data.model_dump())
            await self.update(user.id, user)
            
            logger.info(f"成功同步 OAuth 用户信息: {user.oauth_login}")
            return user
            
        except Exception as e:
            logger.error(f"同步 OAuth 用户信息失败: {str(e)}")
            raise
```

### 步骤 4: 配置主应用

```python
# oauth_main.py
from contextlib import asynccontextmanager
import os
from fastapi import Depends, FastAPI, HTTPException, Request, Query
from fastapi.responses import RedirectResponse
from fastapi_rbac.config import RBACConfig
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import SQLModel
from oauth_extend.oauth_user_serializer import OAuthUserSerializer
from oauth_extend.oauth_client import OAuthClient
from fastapi_rbac.dependencies.login_dependencies import require_external_login
from fastapi_rbac.plugin import RBACPlugin

# 数据库配置
database_url = os.getenv(
    "RBAC_DATABASE_URL",
    "mysql+aiomysql://root:password@localhost:3306/oauth-example",
)

database_params = {
    "echo": False,
    "future": True,
    "pool_recycle": 60 * 5,
    "pool_pre_ping": True,
    "pool_size": 10,
    "max_overflow": 20,
}

# RBAC 配置
rbac_settings = RBACConfig(
    database_url=database_url,
    database_params=database_params,
    user_serializer=OAuthUserSerializer,
    enable_external_auth=True,
    external_auth_clients={
        "oauth": OAuthClient,  # 注册 OAuth 客户端
    },
)

# 创建数据库引擎
engine = create_async_engine(
    rbac_settings.database_url,
    **rbac_settings.database_params,
)

# OAuth 客户端实例
oauth_client = OAuthClient(rbac_settings)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.drop_all)
        await conn.run_sync(SQLModel.metadata.create_all)
    yield
    await engine.dispose()

# 创建 FastAPI 应用
app = FastAPI(
    title="OAuth 集成示例",
    description="基于 FastAPI-RBAC 的 OAuth 登录示例",
    version="1.0.0",
    lifespan=lifespan,
)

# 初始化 RBAC 插件
RBACPlugin(app, rbac_settings)

@app.get("/")
async def read_root():
    """根路径，提供登录链接"""
    return {
        "message": "欢迎使用 OAuth 登录示例",
        "login_url": "/auth/oauth",
        "protected_url": "/protected"
    }

@app.get("/auth/oauth")
async def oauth_login(
    state: str = Query(None, description="状态参数，用于防止CSRF攻击")
):
    """发起 OAuth 登录"""
    try:
        # 生成授权URL
        auth_url = oauth_client.get_authorization_url(state)
        return RedirectResponse(url=auth_url)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OAuth 登录初始化失败: {str(e)}")

@app.get("/auth/oauth/callback")
async def oauth_callback(
    code: str = Query(..., description="OAuth 授权码"),
    state: str = Query(None, description="状态参数"),
    error: str = Query(None, description="错误信息"),
):
    """OAuth 回调处理"""
    try:
        if error:
            raise HTTPException(status_code=400, detail=f"OAuth 授权失败: {error}")

        if not code:
            raise HTTPException(status_code=400, detail="缺少授权码")

        # 交换访问令牌
        token_data = await oauth_client.exchange_code_for_token(code)
        access_token = token_data.get("access_token")

        if not access_token:
            raise HTTPException(status_code=400, detail="获取访问令牌失败")

        return {
            "message": "OAuth 登录成功",
            "access_token": access_token,
            "token_type": token_data.get("token_type", "bearer"),
            "scope": token_data.get("scope"),
            "usage": {
                "protected_endpoint": "/protected",
                "headers": {"X-Auth-Type": "oauth", "X-Auth-Token": access_token},
            },
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OAuth 登录处理失败: {str(e)}")

@app.get("/protected")
async def protected_endpoint(_: bool = Depends(require_external_login())):
    """受保护的端点，需要 OAuth 认证"""
    return {
        "message": "恭喜！您已成功通过 OAuth 认证",
        "status": "authenticated",
        "provider": "oauth"
    }

@app.get("/health")
async def health_check():
    """健康检查端点"""
    oauth_health = await oauth_client.health_check()
    
    return {
        "status": "healthy",
        "services": {"oauth_api": "healthy" if oauth_health else "unhealthy"},
    }

if __name__ == "__main__":
    import uvicorn
    
    print("启动 OAuth 示例应用...")
    print("请确保已配置以下环境变量:")
    print("- RBAC_DATABASE_URL: 数据库连接URL")
    
    uvicorn.run("oauth_main:app", host="0.0.0.0", port=8000, reload=True)
```

## 配置说明

### 环境变量

```bash
# 数据库配置
RBAC_DATABASE_URL=mysql+aiomysql://user:password@host:port/database

# 日志配置
LOG_LEVEL=INFO
```

### OAuth 客户端配置

在 `OAuthClient` 类中直接配置 OAuth 系统参数：

```python
class OAuthClient(BaseExternalAuthClient):
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        
        # OAuth 系统配置
        self.client_id = "your_oauth_client_id"
        self.client_secret = "your_oauth_client_secret"
        self.redirect_uri = "http://localhost:8000/auth/oauth/callback"
        self.scope = "user:email"
        
        # OAuth 端点
        self.authorize_url = "https://oauth-provider.com/oauth/authorize"
        self.token_url = "https://oauth-provider.com/oauth/access_token"
        self.user_info_url = "https://api.oauth-provider.com/user"
```

## 使用方式

### 1. 发起 OAuth 认证

```http
GET /auth/oauth?state=random_state_string
```

**响应**: 重定向到 OAuth 提供者授权页面

### 2. OAuth 回调处理

```http
GET /auth/oauth/callback?code=authorization_code&state=random_state_string
```

**响应**:
```json
{
  "message": "OAuth 登录成功",
  "access_token": "access_token_here",
  "token_type": "bearer",
  "scope": "user:email",
  "usage": {
    "protected_endpoint": "/protected",
    "headers": {
      "X-Auth-Type": "oauth",
      "X-Auth-Token": "access_token_here"
    }
  }
}
```

### 3. 访问受保护的端点

```http
GET /protected
Headers:
  X-Auth-Type: oauth
  X-Auth-Token: access_token_here
```

**响应**:
```json
{
  "message": "恭喜！您已成功通过 OAuth 认证",
  "status": "authenticated",
  "provider": "oauth"
}
```

## 最佳实践

### 1. 安全配置

- **客户端密钥保护**: 永远不要在客户端代码中暴露 `client_secret`
- **HTTPS**: 生产环境必须使用 HTTPS
- **状态参数**: 使用 state 参数防止 CSRF 攻击
- **令牌安全**: 安全存储和传输访问令牌
- **权限最小化**: 只请求必要的 OAuth 权限

### 2. 错误处理

```python
async def exchange_code_for_token(self, code: str) -> Dict[str, Any]:
    try:
        response = await self.client.post(
            self.token_url,
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "code": code,
                "redirect_uri": self.redirect_uri,
                "grant_type": "authorization_code"
            },
            headers={"Accept": "application/json"},
            timeout=30.0  # 设置超时
        )
        
        if response.status_code == 200:
            token_data = response.json()
            if "access_token" in token_data:
                return token_data
            else:
                error_msg = token_data.get("error_description", "未知错误")
                raise OAuthError(f"获取访问令牌失败: {error_msg}")
        else:
            raise OAuthError(f"OAuth 请求失败: {response.status_code}")
            
    except httpx.TimeoutException:
        raise OAuthError("OAuth 服务器响应超时")
    except httpx.ConnectError:
        raise OAuthError("无法连接到 OAuth 服务器")
    except Exception as e:
        raise OAuthError(f"OAuth 请求异常: {str(e)}")
```

### 3. 多 OAuth 提供者支持

```python
# 支持多个 OAuth 提供者
rbac_settings = RBACConfig(
    # ... 其他配置
    external_auth_clients={
        "github": GitHubOAuthClient,
        "google": GoogleOAuthClient,
        "microsoft": MicrosoftOAuthClient,
    },
)
```

### 4. 用户信息缓存

```python
import time
from functools import lru_cache

class CachedOAuthClient(OAuthClient):
    def __init__(self, config: RBACConfig):
        super().__init__(config)
        self._cache = {}
        self._cache_ttl = 300  # 5分钟缓存

    async def get_user_info(self, request: Request, db_session: AsyncSession):
        auth_token = request.headers.get("X-Auth-Token")
        
        # 检查缓存
        if auth_token in self._cache:
            cached_data, timestamp = self._cache[auth_token]
            if time.time() - timestamp < self._cache_ttl:
                return cached_data
        
        # 获取新数据
        user_info = await super().get_user_info(request, db_session)
        
        # 更新缓存
        self._cache[auth_token] = (user_info, time.time())
        
        return user_info
```

## 故障排除

### 常见问题

#### 1. "OAuth 授权失败" 错误

**可能原因**:
- 客户端ID或密钥错误
- 回调URL不匹配
- 权限范围不正确

**解决方案**:
```python
def _validate_config(self) -> None:
    """验证 OAuth 配置"""
    if not self.client_id:
        raise ValueError("OAuth 客户端ID未配置")
    if not self.client_secret:
        raise ValueError("OAuth 客户端密钥未配置")
    if not self.redirect_uri:
        raise ValueError("OAuth 回调URL未配置")
    
    # 验证URL格式
    if not self.redirect_uri.startswith(("http://", "https://")):
        raise ValueError("OAuth 回调URL格式错误")
```

#### 2. "获取访问令牌失败" 错误

**可能原因**:
- 授权码已过期
- 授权码已被使用
- 客户端密钥错误

**解决方案**:
```python
async def exchange_code_for_token(self, code: str) -> Dict[str, Any]:
    # 检查授权码格式
    if not code or len(code) < 10:
        raise ValueError("授权码格式无效")
    
    try:
        response = await self.client.post(
            self.token_url,
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "code": code,
                "redirect_uri": self.redirect_uri,
                "grant_type": "authorization_code"
            },
            headers={"Accept": "application/json"}
        )
        
        if response.status_code == 200:
            token_data = response.json()
            if "access_token" in token_data:
                return token_data
            elif "error" in token_data:
                error_msg = token_data.get("error_description", token_data["error"])
                raise ValueError(f"OAuth 错误: {error_msg}")
            else:
                raise ValueError("OAuth 响应格式错误")
        else:
            raise ValueError(f"OAuth 请求失败: {response.status_code}")
            
    except Exception as e:
        logger.error(f"交换访问令牌失败: {str(e)}")
        raise
```

#### 3. 用户信息获取失败

**可能原因**:
- 访问令牌无效
- API 端点错误
- 权限不足

**解决方案**:
```python
async def _fetch_user_info(self, access_token: str) -> Dict[str, Any]:
    try:
        # 验证令牌格式
        if not access_token or len(access_token) < 10:
            raise ValueError("访问令牌格式无效")
        
        # 获取用户信息
        response = await self.client.get(
            self.user_info_url,
            headers={"Authorization": f"Bearer {access_token}"}
        )
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            raise ValueError("访问令牌无效或已过期")
        elif response.status_code == 403:
            raise ValueError("权限不足，无法获取用户信息")
        else:
            raise ValueError(f"获取用户信息失败: {response.status_code}")
            
    except httpx.TimeoutException:
        raise ValueError("OAuth API 响应超时")
    except httpx.ConnectError:
        raise ValueError("无法连接到 OAuth API")
    except Exception as e:
        logger.error(f"获取用户信息异常: {str(e)}")
        raise
```

### 调试技巧

1. **启用详细日志**:
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# 在关键操作中添加日志
async def exchange_code_for_token(self, code: str):
    logger.info(f"开始交换授权码: {code[:10]}...")
    try:
        result = await self._exchange_with_oauth_server(code)
        logger.info("授权码交换成功")
        return result
    except Exception as e:
        logger.error(f"授权码交换失败: {str(e)}")
        raise
```

2. **测试 OAuth 连接**:
```python
async def test_oauth_connection():
    client = OAuthClient(config)
    health = await client.health_check()
    print(f"OAuth 服务状态: {'正常' if health else '异常'}")
```

3. **验证配置**:
```python
def validate_oauth_config():
    """验证 OAuth 配置"""
    required_fields = ["client_id", "client_secret", "redirect_uri"]
    for field in required_fields:
        if not hasattr(oauth_client, field) or not getattr(oauth_client, field):
            print(f"缺少配置: {field}")
            return False
    print("OAuth 配置验证通过")
    return True
```

## 扩展功能

### 1. 令牌刷新

```python
async def refresh_access_token(self, refresh_token: str) -> Dict[str, Any]:
    """刷新访问令牌"""
    try:
        response = await self.client.post(
            self.token_url,
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token"
            },
            headers={"Accept": "application/json"}
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise ValueError(f"令牌刷新失败: {response.status_code}")
            
    except Exception as e:
        logger.error(f"令牌刷新异常: {str(e)}")
        raise
```

### 2. 自动用户同步

```python
async def sync_user_from_oauth(self, user_id: int, auth_token: str):
    """定期同步用户信息"""
    try:
        # 获取最新用户信息
        latest_info = await self.validate_user_from_oauth(auth_token)
        
        # 更新本地用户信息
        user = await self.get_by_id(user_id)
        if user:
            user.update_oauth_info(latest_info.model_dump())
            await self.update(user.id, user)
            
    except Exception as e:
        logger.error(f"用户信息同步失败: {str(e)}")
```

### 3. 多租户支持

```python
class MultiTenantOAuthClient(OAuthClient):
    def __init__(self, config: RBACConfig, tenant_id: str):
        super().__init__(config)
        self.tenant_id = tenant_id
        # 根据租户ID调整配置
        self.redirect_uri = f"http://localhost:8000/auth/{tenant_id}/oauth/callback"
```

---

**注意**: 这是一个通用指南，具体实现需要根据您选择的 OAuth 提供者 API 进行调整。请确保在生产环境中进行充分的安全测试和性能优化。
