# 优化后的用户序列化器设计

## 概述

本文档描述了优化后的用户序列化器系统设计。主要优化目标是移除 `user_model` 配置项，简化配置逻辑，让序列化器自己知道对应的模型类型。

## 设计变更

### 1. 配置简化

**优化前：**
```python
class RBACConfig(BaseSettings):
    user_model: Type[SQLModel] = Field(description="User model class")
    user_serializer: Type[BaseUserSerializer] | None = Field(default=None)
```

**优化后：**
```python
class RBACConfig(BaseSettings):
    user_serializer: Type[BaseUserSerializer] = Field(description="User serializer class")
```

### 2. 序列化器基类重构

**优化前：**
```python
class BaseUserSerializer(BaseSerializer[Any, BaseModel, BaseModel]):
    def __init__(self, db_session: AsyncSession, user_model: Type[Any]):
        super().__init__(db_session, user_model)
        self.user_model = user_model
```

**优化后：**
```python
class BaseUserSerializer(BaseSerializer[Any, BaseModel, BaseModel]):
    # 子类必须定义此变量来指定对应的用户模型
    user_model: ClassVar[Type[Any]]

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session, self.user_model)
```

### 3. 具体序列化器实现

**DefaultUserSerializer:**
```python
class DefaultUserSerializer(BaseUserSerializer):
    user_model = User  # 明确指定用户模型

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)  # 不需要传递 user_model
```

**PasswordUserSerializer:**
```python
class PasswordUserSerializer(BaseUserSerializer):
    user_model = UserWithPassword  # 明确指定用户模型

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)  # 不需要传递 user_model
```

## 优势

### 1. 配置简化
- 只需要配置 `user_serializer`，不需要同时配置 `user_model`
- 减少了配置错误的可能性
- 配置更加直观和简单

### 2. 类型安全
- 序列化器在类级别就知道对应的用户模型
- 编译时就能发现类型错误
- 更好的 IDE 支持和代码提示

### 3. 架构清晰
- 序列化器和模型的关系更加明确
- 减少了配置和实现之间的耦合
- 更容易理解和维护

### 4. 扩展性
- 自定义序列化器只需要继承 `BaseUserSerializer` 并设置 `user_model`
- 不需要修改工厂类或配置验证逻辑
- 支持更复杂的用户模型定制

## 使用方式

### 1. 基本配置

```python
from fastapi_rbac.config import RBACConfig
from fastapi_rbac.serializers.default_user_serializer import DefaultUserSerializer

# 使用默认用户序列化器
config = RBACConfig(
    database_url="mysql+aiomysql://...",
    user_serializer=DefaultUserSerializer
)
```

### 2. 密码用户配置

```python
from fastapi_rbac.config import RBACConfig
from fastapi_rbac.serializers.password_user_serializer import PasswordUserSerializer

# 使用密码用户序列化器
config = RBACConfig(
    database_url="mysql+aiomysql://...",
    user_serializer=PasswordUserSerializer
)
```

### 3. 自定义序列化器

```python
from fastapi_rbac.serializers.base_user_serializer import BaseUserSerializer
from fastapi_rbac.config import RBACConfig

class CustomUserSerializer(BaseUserSerializer):
    user_model = CustomUser  # 指定自定义用户模型
    
    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)
    
    # 实现自定义逻辑...

# 配置自定义序列化器
config = RBACConfig(
    database_url="mysql+aiomysql://...",
    user_serializer=CustomUserSerializer
)
```

## 工厂类简化

### 1. UserSerializerFactory

**优化前：** 复杂的模型类型判断和序列化器选择逻辑
**优化后：** 直接从配置获取序列化器类并实例化

```python
@staticmethod
def create_serializer(db_session: AsyncSession) -> BaseUserSerializer:
    config = get_rbac_config()
    user_serializer_class = config.user_serializer
    return user_serializer_class(db_session)
```

### 2. ModelFactory

**优化前：** 从模型注册表获取用户模型
**优化后：** 从序列化器获取用户模型

```python
@staticmethod
def get_user_model() -> Type[SQLModel]:
    return UserSerializerFactory.get_user_model()
```

## 向后兼容性

### 1. 现有代码
- 现有的序列化器使用方式保持不变
- 工厂类的公共接口保持不变
- 配置验证更加严格但更清晰

### 2. 迁移指南
- 将 `user_model` 配置改为 `user_serializer`
- 确保序列化器继承自 `BaseUserSerializer`
- 在序列化器中设置 `user_model` 类变量

## 测试覆盖

新增了完整的测试覆盖：

1. **UserSerializerFactory 测试** - 验证工厂类的各种方法
2. **序列化器测试** - 验证具体序列化器的行为
3. **基类测试** - 验证抽象基类的约束
4. **配置集成测试** - 验证配置验证逻辑

## 总结

这次优化成功地：

1. ✅ 移除了 `user_model` 配置项
2. ✅ 简化了配置逻辑
3. ✅ 提高了类型安全性
4. ✅ 改善了架构清晰度
5. ✅ 保持了向后兼容性
6. ✅ 增强了扩展性

新的设计更加简洁、安全和易维护，同时保持了系统的灵活性和扩展性。
