# Siduri - 高级 RBAC FastAPI 扩展（中文说明）

## 1. 项目依赖安装方式（使用 uv）

本项目推荐使用 [uv](https://github.com/astral-sh/uv) 进行依赖管理和安装。

```bash
uv sync           # 安装所有依赖
uv run python ... # 运行 Python 脚本
```

如需安装本地开发依赖：

```bash
uv pip install -e .
```

## 2. 项目特性

- **自定义用户模型（Custom User Model）**：支持扩展用户表结构，添加自定义字段，满足企业级需求。
- **权限依赖注入（require_permissions）**：通过依赖注入方式进行权限校验，支持多权限（OR 逻辑）校验。
- **RBAC 完整模型**：用户-角色-权限多对多关系，支持角色继承、软删除、审计日志等。
- **插件化集成**：一行代码集成 RBAC 插件，自动生成 OpenAPI 文档。
- **高性能与可扩展性**：高效的权限校验查询，内置缓存、分页、连接池等。
- **多数据库支持**：兼容 MySQL、PostgreSQL、SQLite。
- **SSO 单点登录集成**：支持外部用户同步。
- **前后端一体化管理界面**：内置管理后台，支持用户、角色、权限的可视化管理。

## 3. /examples 目录案例说明

- **basic_usage.py**
  - 展示如何快速集成 RBAC 插件，初始化数据库，使用内置前端管理后台。
  - 演示自定义用户模型（Custom User Model）的用法，可扩展用户表字段。
  - 提供权限演示页面，展示 require_permissions 权限依赖注入的实际效果。
  - 运行方式：

    ```bash
    uv run python examples/basic_usage.py
    ```

  - 访问路径：
    - 权限演示页：<http://localhost:8000/index>
    - 管理后台：<http://localhost:8000/admin/>
    - API 文档：<http://localhost:8000/docs>

- **advanced_integration.py**
  - 展示如何在生产环境中集成 RBAC，包括自定义中间件、CORS、可信主机等配置。
  - 演示如何通过自定义 RBACMiddleware 实现 JWT/Session 用户认证。
  - 提供角色依赖注入、SSO 用户同步等高级用法。
  - 适合需要高度定制化的企业级项目。

- **auto_permission_generation.py**
  - 演示如何自动扫描 FastAPI 路由中的 require_permissions 并批量生成权限。
  - 适用于权限点较多、需自动化管理的场景。
  - 运行后会自动在数据库中插入所有路由声明的权限。
  - 运行方式：

    ```bash
    uv run python examples/auto_permission_generation.py
    ```

---

如需更多信息，请参考英文版 README.md 或访问 [官方文档](https://siduri-rbac.readthedocs.io)。
