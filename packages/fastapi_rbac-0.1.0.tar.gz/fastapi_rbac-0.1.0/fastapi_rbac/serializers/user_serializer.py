# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
# """
# @Author: harumonia
# @Email: zxjlm233@gmail.com
# @Create Time: 2025-05-26 18:35:52
# @Software: Visual Studio Code
# @Copyright: Copyright (c) 2025, harumonia
# @Description: User Serializer (Legacy)
#     This module is kept for backward compatibility.
#     For new code, use the UserSerializerFactory or specific serializer classes.

# All Rights Reserved.
# """

# from typing import List, Optional, Any
# from datetime import datetime
# from sqlmodel import select, and_
# from sqlmodel.ext.asyncio.session import AsyncSession
# from sqlalchemy.orm import selectinload

# from ..models import Role, Permission, RolePermissionRelation, get_user_model
# from ..models.user_role_relation import UserRoleRelation
# from ..schemas.user_schemas import UserSearchParams
# from ..schemas.common_schemas import PaginationParams, PaginatedResponse
# from .base_serializer import BaseSerializer
# from .exceptions import (
#     create_user_error,
#     create_user_not_found,
#     DatabaseError,
#     NotFoundError,
# )


# from pydantic import BaseModel


# class UserSerializer(BaseSerializer[Any, BaseModel, BaseModel]):
#     """
#     User serializer (Legacy - kept for backward compatibility)

#     This class is kept for backward compatibility. For new code, consider using:
#     - UserSerializerFactory.create_serializer() for automatic serializer selection
#     - DefaultUserSerializer for default user model
#     - PasswordUserSerializer for password-enabled user model
#     - BaseUserSerializer for custom user models

#     Handle user-related business logic, including query, internal creation/update, and role management.
#     """

#     def __init__(self, db_session: AsyncSession):
#         User = get_user_model()
#         super().__init__(db_session, User)

#     async def get_user(
#         self, user_id: int, include_roles: bool = False
#     ) -> Optional[Any]:
#         """
#         Get single user information

#         Args:
#             user_id: User ID
#             include_roles: Whether to include role information

#         Returns:
#             User instance or None
#         """
#         try:
#             User = get_user_model()
#             # type: ignore - Dynamic model access
#             statement = select(User).where(User.id == user_id)

#             if include_roles:
#                 statement = statement.options(
#                     # type: ignore - Dynamic model access
#                     selectinload(User.user_roles).selectinload(UserRoleRelation.role)
#                 )

#             result = await self.db_session.exec(statement)
#             return result.first()

#         except Exception as e:
#             self.logger.error(f"Failed to get user {user_id} information: {str(e)}")
#             raise create_user_error("GET_USER_INFO_FAILED", {"error": str(e)})

#     async def get_users(
#         self,
#         pagination: PaginationParams,
#         search_params: Optional[UserSearchParams] = None,
#         include_roles: bool = False,
#     ) -> PaginatedResponse[Any]:
#         """
#         Paginate query user list

#         Args:
#             pagination: Pagination parameters
#             search_params: Search parameters
#             include_roles: Whether to include role information

#         Returns:
#             Paginated user list
#         """
#         try:
#             User = get_user_model()
#             # Build base query
#             statement = select(User)

#             if include_roles:
#                 statement = statement.options(
#                     # type: ignore - Dynamic model access
#                     selectinload(User.user_roles).selectinload(UserRoleRelation.role)
#                 )

#             # Build filter conditions
#             filters = []

#             if search_params:
#                 if search_params.email:
#                     # type: ignore - Dynamic model access
#                     filters.append(User.email.like(f"%{search_params.email}%"))

#                 # if search_params.created_after:
#                 #     filters.append(User.created_at >= search_params.created_after)

#                 # if search_params.created_before:
#                 #     filters.append(User.created_at <= search_params.created_before)

#             # Apply filter conditions
#             if filters:
#                 statement = statement.where(and_(*filters))

#             # Sort
#             # type: ignore - Dynamic model access
#             statement = statement.order_by(User.id.desc())

#             # Calculate total
#             # type: ignore - Dynamic model access
#             count_statement = select(User.id)
#             if filters:
#                 count_statement = count_statement.where(and_(*filters))

#             count_result = await self.db_session.exec(count_statement)
#             total = len(count_result.all())

#             # Apply pagination
#             statement = statement.offset(pagination.offset).limit(pagination.size)

#             # Execute query
#             result = await self.db_session.exec(statement)
#             items = result.all()

#             return PaginatedResponse.create(
#                 items=items, total=total, page=pagination.page, size=pagination.size
#             )

#         except Exception as e:
#             self.logger.error(f"Failed to query user list: {str(e)}")
#             raise create_user_error("QUERY_USER_LIST_FAILED", {"error": str(e)})

#     async def search_users(self, query: str, limit: int = 10) -> List[Any]:
#         """
#         Search users (fuzzy matching)

#         Args:
#             query: Search keyword
#             limit: Result limit

#         Returns:
#             Matched user list
#         """
#         try:
#             User = get_user_model()
#             statement = select(User).where(User.email.like(f"%{query}%")).limit(limit)

#             result = await self.db_session.exec(statement)
#             return list(result.all())

#         except Exception as e:
#             self.logger.error(f"Failed to search users: {str(e)}")
#             raise create_user_error("SEARCH_USERS_FAILED", {"error": str(e)})

#     async def get_user_roles(self, user_id: int) -> List[Role]:
#         """
#         Get user role list

#         Args:
#             user_id: User ID

#         Returns:
#             User role list
#         """
#         try:
#             # Verify user exists
#             await self.get_by_id_or_404(user_id)

#             # Query user role
#             statement = (
#                 select(Role)
#                 .join(UserRoleRelation, Role.id == UserRoleRelation.role_id)
#                 .where(
#                     and_(
#                         UserRoleRelation.user_id == user_id,
#                         UserRoleRelation.is_active,
#                     )
#                 )
#                 .order_by(Role.name)
#             )

#             result = await self.db_session.exec(statement)
#             return list(result.all())

#         except NotFoundError:
#             raise
#         except Exception as e:
#             self.logger.error(f"Failed to get user {user_id} role list: {str(e)}")
#             raise DatabaseError("Failed to get user role list", {"error": str(e)})

#     async def assign_roles(
#         self, user_id: int, role_ids: List[int], assigned_by: Optional[int] = None
#     ) -> List["UserRoleRelation"]:
#         """
#         Assign roles to user

#         Args:
#             user_id: User ID
#             role_ids: Role ID list
#             assigned_by: Assigned by user ID

#         Returns:
#             Created user role relation list
#         """
#         try:
#             # Verify user exists
#             await self.get_by_id_or_404(user_id)

#             # Verify role exists
#             role_statement = select(Role).where(Role.id.in_(role_ids))
#             role_result = await self.db_session.exec(role_statement)
#             existing_roles = role_result.all()

#             if len(existing_roles) != len(role_ids):
#                 existing_role_ids = {role.id for role in existing_roles}
#                 missing_role_ids = set(role_ids) - existing_role_ids
#                 raise create_user_error(
#                     "ROLES_NOT_FOUND", missing_role_ids=missing_role_ids
#                 )

#             # Check existing relations
#             existing_relations_statement = select(UserRoleRelation).where(
#                 and_(
#                     UserRoleRelation.user_id == user_id,
#                     UserRoleRelation.role_id.in_(role_ids),
#                     UserRoleRelation.is_active,
#                 )
#             )
#             existing_relations_result = await self.db_session.exec(
#                 existing_relations_statement
#             )
#             existing_relations = existing_relations_result.all()
#             existing_role_ids = {rel.role_id for rel in existing_relations}

#             # Create new relations
#             new_relations = []
#             for role_id in role_ids:
#                 if role_id not in existing_role_ids:
#                     relation = UserRoleRelation(
#                         user_id=user_id,
#                         role_id=role_id,
#                         assigned_by=assigned_by,
#                         assigned_at=datetime.now(),
#                     )
#                     self.db_session.add(relation)
#                     new_relations.append(relation)

#             if new_relations:
#                 await self.db_session.commit()
#                 for relation in new_relations:
#                     await self.db_session.refresh(relation)

#                 self.logger.info(
#                     f"Successfully assigned {len(new_relations)} roles to user {user_id}"
#                 )

#             return new_relations

#         except (DatabaseError, NotFoundError):
#             raise
#         except Exception as e:
#             await self.db_session.rollback()
#             self.logger.error(f"Failed to assign roles to user {user_id}: {str(e)}")
#             raise DatabaseError("Failed to assign roles", {"error": str(e)})

#     async def remove_roles(self, user_id: int, role_ids: List[int]) -> int:
#         """
#         Remove user roles

#         Args:
#             user_id: User ID
#             role_ids: Role ID list

#         Returns:
#             Removed role count
#         """
#         try:
#             # Verify user exists
#             await self.get_by_id_or_404(user_id)

#             # Find relations to remove
#             statement = select(UserRoleRelation).where(
#                 and_(
#                     UserRoleRelation.user_id == user_id,
#                     UserRoleRelation.role_id.in_(role_ids),
#                     UserRoleRelation.is_active,
#                 )
#             )
#             result = await self.db_session.exec(statement)
#             relations_to_remove = result.all()

#             # Remove relations (soft delete)
#             removed_count = 0
#             for relation in relations_to_remove:
#                 relation.is_active = False
#                 removed_count += 1

#             if removed_count > 0:
#                 await self.db_session.commit()
#                 self.logger.info(
#                     f"Successfully removed {removed_count} roles from user {user_id}"
#                 )

#             return removed_count

#         except NotFoundError:
#             raise
#         except Exception as e:
#             await self.db_session.rollback()
#             self.logger.error(f"Failed to remove roles from user {user_id}: {str(e)}")
#             raise DatabaseError("Failed to remove roles", {"error": str(e)})

#     async def get_user_permissions(
#         self, user_id: int, use_cache: bool = True
#     ) -> List[str]:
#         """
#         Get all permission codes for a user through their roles (optimized version)

#         Args:
#             user_id: User ID
#             use_cache: Whether to use caching (for future implementation)

#         Returns:
#             List of permission codes that the user has access to
#         """
#         try:
#             # Optimized query: single JOIN query without user existence check for performance
#             # The query will return empty result if user doesn't exist or has no permissions
#             statement = (
#                 select(Permission.code)
#                 .select_from(Permission)
#                 .join(
#                     RolePermissionRelation,
#                     and_(
#                         Permission.id == RolePermissionRelation.permission_id,
#                         RolePermissionRelation.is_active,
#                     ),
#                 )
#                 .join(
#                     UserRoleRelation,
#                     and_(
#                         RolePermissionRelation.role_id == UserRoleRelation.role_id,
#                         UserRoleRelation.user_id == user_id,
#                         UserRoleRelation.is_active,
#                     ),
#                 )
#                 .where(Permission.is_active)
#                 .distinct()
#                 .order_by(Permission.code)  # Add ordering for consistency
#             )

#             result = await self.db_session.exec(statement)
#             permission_codes = list(result.all())

#             # Only check user existence if no permissions found (optimization)
#             if not permission_codes:
#                 # Verify if user exists or just has no permissions
#                 User = get_user_model()
#                 user_exists_statement = select(User.id).where(User.id == user_id)
#                 user_exists_result = await self.db_session.exec(user_exists_statement)
#                 if not user_exists_result.first():
#                     raise create_user_not_found("USER_NOT_FOUND", user_id=user_id)

#             self.logger.debug(f"User {user_id} has {len(permission_codes)} permissions")
#             return permission_codes

#         except NotFoundError:
#             raise
#         except Exception as e:
#             self.logger.error(f"Failed to get permissions for user {user_id}: {str(e)}")
#             raise DatabaseError("Failed to get user permissions", {"error": str(e)})

#     async def _get_user_by_email(self, email: str) -> Optional[Any]:
#         """
#         Get user by email (internal method)

#         Args:
#             email: Email address

#         Returns:
#             User instance or None
#         """
#         User = get_user_model()
#         statement = select(User).where(User.email == email)
#         result = await self.db_session.exec(statement)
#         return result.first()

#     async def create_user(self, user_data: BaseModel) -> Any:
#         """
#         Create user (internal use)

#         Args:
#             user_data: User creation data

#         Returns:
#             Created user instance

#         Note:
#             This method is for internal use, usually called when SSO syncs.
#         """
#         try:
#             # Check if email already exists
#             existing_user = await self._get_user_by_email(user_data.email)
#             if existing_user:
#                 raise create_user_error("EMAIL_ALREADY_EXISTS", email=user_data.email)

#             # Create user
#             user = await self.create(user_data)

#             self.logger.info(f"Successfully created user: {user.email}")
#             return user

#         except DatabaseError:
#             raise
#         except Exception as e:
#             self.logger.error(f"Failed to create user: {str(e)}")
#             raise e

#     async def update_user(self, user_id: int, user_data: BaseModel) -> Any:
#         """
#         Update user information (internal use)

#         Args:
#             user_id: User ID
#             user_data: User update data

#         Returns:
#             Updated user instance

#         Note:
#             This method is for internal use, usually called when SSO syncs.
#         """
#         try:
#             # If updating email, check if email already exists
#             if user_data.email:
#                 existing_user = await self._get_user_by_email(user_data.email)
#                 if existing_user and existing_user.id != user_id:
#                     raise create_user_error("EMAIL_ALREADY_USED", email=user_data.email)

#             # Update user
#             user = await self.update(user_id, user_data)

#             self.logger.info(f"Successfully updated user: {user.email}")
#             return user

#         except (DatabaseError, NotFoundError):
#             raise
#         except Exception as e:
#             self.logger.error(f"Failed to update user: {str(e)}")
#             raise DatabaseError("Failed to update user", {"error": str(e)})
