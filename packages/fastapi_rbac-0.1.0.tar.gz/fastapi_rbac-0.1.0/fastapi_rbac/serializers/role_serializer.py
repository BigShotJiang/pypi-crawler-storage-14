#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:39:49
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Role serializer
    Implement role-related business logic, including CRUD operations and user management.

All Rights Reserved.
"""

from typing import List, Optional, Any
from datetime import datetime
from sqlmodel import select, and_
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy import desc

from ..models import Role, Permission, RolePermissionRelation, get_user_model
from ..models.user_role_relation import UserRoleRelation
from ..schemas.role_schemas import (
    RoleCreate,
    RoleUpdate,
    RoleSearchParams,
    UserRoleAssignment,
    PermissionRoleAssignment,
)
from ..schemas.common_schemas import PaginationParams, PaginatedResponse
from .base_serializer import BaseSerializer
from .exceptions import (
    create_role_error,
    create_role_not_found,
    DatabaseError,
    NotFoundError,
)


class RoleSerializer(BaseSerializer[Role, RoleCreate, RoleUpdate]):
    """
    Role serializer

    Handle role-related business logic, including CRUD operations and user management.
    """

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session, Role)

    async def create_role(self, role_data: RoleCreate) -> Role:
        """
        Create role

        Args:
            role_data: Role creation data

        Returns:
            Created role instance
        """
        try:
            # Check if role name already exists
            existing_role = await self._get_role_by_name(role_data.name)
            if existing_role:
                raise create_role_error("ROLE_NAME_EXISTS", name=role_data.name)

            # Create role
            role = await self.create(role_data)

            self.logger.info(f"Successfully created role: {role.name}")
            return role

        except DatabaseError:
            raise
        except Exception as e:
            self.logger.error(f"Failed to create role: {str(e)}")
            raise create_role_error("ROLE_CREATE_FAILED", {"error": str(e)})

    async def get_role(
        self, role_id: int, include_users: bool = False
    ) -> Optional[Role]:
        """
        Get single role information

        Args:
            role_id: Role ID
            include_users: Whether to include user information

        Returns:
            Role instance or None
        """
        try:
            if include_users:
                # Get current User model dynamically
                User = get_user_model()
                # Use explicit join query instead of selectinload for dynamic user model
                statement = (
                    select(Role, UserRoleRelation, User)
                    .join(UserRoleRelation, Role.id == UserRoleRelation.role_id)
                    .join(User, UserRoleRelation.user_id == User.id)
                    .where(
                        and_(
                            Role.id == role_id,
                            UserRoleRelation.is_active,
                        )
                    )
                )

                result = await self.db_session.exec(statement)
                rows = result.all()

                if not rows:
                    return None

                # Group results by role and users
                role = rows[0][0]  # First element is Role
                # role_users = []
                # for row in rows:
                #     user_relation = row[1]  # UserRoleRelation
                #     user = row[2]  # User
                #     role_users.append(user_relation)

                # # Manually set the role_users relationship
                # role.role_users = role_users
                return role
            else:
                statement = select(Role).where(Role.id == role_id)
                result = await self.db_session.exec(statement)
                return result.first()

        except Exception as e:
            self.logger.error(f"Failed to get role {role_id} information: {str(e)}")
            raise create_role_error("GET_ROLE_INFO_FAILED", {"error": str(e)})

    async def get_roles(
        self,
        pagination: PaginationParams,
        search_params: Optional[RoleSearchParams] = None,
    ) -> PaginatedResponse[Role]:
        """
        Paginate query role list

        Args:
            pagination: Pagination parameters
            search_params: Search parameters

        Returns:
            Paginated role list
        """
        try:
            statement = select(Role)

            # Build filter conditions
            filters = []

            if search_params:
                if search_params.name:
                    filters.append(Role.name.ilike(f"%{search_params.name}%"))

                if search_params.description:
                    filters.append(
                        Role.description.ilike(f"%{search_params.description}%")
                    )

                if search_params.is_active is not None:
                    filters.append(Role.is_active == search_params.is_active)

                if search_params.is_system is not None:
                    filters.append(Role.is_system == search_params.is_system)

                if search_params.created_after:
                    filters.append(Role.created_at >= search_params.created_after)

                if search_params.created_before:
                    filters.append(Role.created_at <= search_params.created_before)

            # Apply filter conditions
            if filters:
                statement = statement.where(and_(*filters))

            # Sort
            statement = statement.order_by(desc(Role.created_at))

            # Calculate total
            count_statement = select(Role.id)
            if filters:
                count_statement = count_statement.where(and_(*filters))

            count_result = await self.db_session.exec(count_statement)
            total = len(count_result.all())

            # Apply pagination
            statement = statement.offset(pagination.offset).limit(pagination.size)
            result = await self.db_session.exec(statement)
            items = result.all()

            return PaginatedResponse.create(
                items=items, total=total, page=pagination.page, size=pagination.size
            )

        except Exception as e:
            self.logger.error(f"Failed to query role list: {str(e)}")
            raise e
            # raise create_role_error("QUERY_ROLE_LIST_FAILED", {"error": str(e)})

    async def update_role(self, role_id: int, role_data: RoleUpdate) -> Role:
        """
        Update role information

        Args:
            role_id: Role ID
            role_data: Role update data

        Returns:
            Updated role instance
        """
        try:
            # If updating role name, check if it's duplicated
            if role_data.name:
                existing_role = await self._get_role_by_name(role_data.name)
                if existing_role and existing_role.id != role_id:
                    raise create_role_error("ROLE_NAME_USED", name=role_data.name)

            # Update role
            role = await self.update(role_id, role_data)

            self.logger.info(f"Successfully updated role: {role.name}")
            return role

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            self.logger.error(f"Failed to update role: {str(e)}")
            raise create_role_error("ROLE_UPDATE_FAILED", {"error": str(e)})

    async def delete_role(self, role_id: int) -> bool:
        """
        Delete role

        Args:
            role_id: Role ID

        Returns:
            Whether the deletion is successful
        """
        try:
            # Get role information
            role = await self.get_by_id_or_404(role_id)

            # Check if it's a system role
            if role.is_system:
                raise create_role_error("SYSTEM_ROLE_CANNOT_DELETE")

            # Check if there are associated users
            user_count = await self._get_role_user_count(role_id)
            if user_count > 0:
                raise create_role_error("ROLE_HAS_USERS", user_count=user_count)

            # Delete role
            success = await self.delete(role_id)

            self.logger.info(f"Successfully deleted role: {role.name}")
            return success

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            self.logger.error(f"Failed to delete role: {str(e)}")
            raise create_role_error("ROLE_DELETE_FAILED", {"error": str(e)})

    async def get_role_users(self, role_id: int) -> List[Any]:
        """
        Get role users list

        Args:
            role_id: Role ID

        Returns:
            Role users list
        """
        try:
            # Verify role exists
            await self.get_by_id_or_404(role_id)

            # Query role users
            User = get_user_model()
            statement = (
                select(User)
                .join(UserRoleRelation, User.id == UserRoleRelation.user_id)
                .where(
                    and_(
                        UserRoleRelation.role_id == role_id,
                        UserRoleRelation.is_active,
                    )
                )
                .order_by(User.name)
            )

            result = await self.db_session.exec(statement)
            return list(result.all())

        except NotFoundError:
            raise
        except Exception as e:
            self.logger.error(f"Failed to get role {role_id} users list: {str(e)}")
            raise create_role_error("GET_ROLE_USERS_FAILED", {"error": str(e)})

    async def assign_users(
        self, role_id: int, assignment_data: UserRoleAssignment
    ) -> List[UserRoleRelation]:
        """
        Assign users to role

        Args:
            role_id: Role ID
            assignment_data: User assignment data

        Returns:
            Created user role relation list
        """
        try:
            # Verify role exists
            await self.get_by_id_or_404(role_id)

            # Verify users exist
            User = get_user_model()
            user_statement = select(User).where(User.id.in_(assignment_data.user_ids))
            user_result = await self.db_session.exec(user_statement)
            existing_users = user_result.all()

            if len(existing_users) != len(assignment_data.user_ids):
                existing_user_ids = {user.id for user in existing_users}
                missing_user_ids = set(assignment_data.user_ids) - existing_user_ids
                raise create_role_error(
                    "USERS_NOT_FOUND", missing_user_ids=missing_user_ids
                )

            # Check existing relations
            existing_relations_statement = select(UserRoleRelation).where(
                and_(
                    UserRoleRelation.role_id == role_id,
                    UserRoleRelation.user_id.in_(assignment_data.user_ids),
                    UserRoleRelation.is_active,
                )
            )
            existing_relations_result = await self.db_session.exec(
                existing_relations_statement
            )
            existing_relations = existing_relations_result.all()
            existing_user_ids = {rel.user_id for rel in existing_relations}

            # Create new relations
            new_relations = []
            for user_id in assignment_data.user_ids:
                if user_id not in existing_user_ids:
                    relation = UserRoleRelation(
                        user_id=user_id,
                        role_id=role_id,
                        assigned_by=assignment_data.assigned_by,
                        assigned_at=datetime.now(),
                        expires_at=assignment_data.expires_at,
                    )
                    self.db_session.add(relation)
                    new_relations.append(relation)

            if new_relations:
                await self.db_session.commit()
                for relation in new_relations:
                    await self.db_session.refresh(relation)

                self.logger.info(
                    f"Successfully assigned {len(new_relations)} users to role {role_id}"
                )

            return new_relations

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            await self.db_session.rollback()
            self.logger.error(f"Failed to assign users to role {role_id}: {str(e)}")
            raise e
            # raise create_role_error("ASSIGN_USERS_FAILED", {"error": str(e)})

    async def remove_user(self, role_id: int, user_id: int) -> bool:
        """
        Remove user from role

        Args:
            role_id: Role ID
            user_id: User ID

        Returns:
            Whether the removal is successful
        """
        try:
            # Verify role and user exist
            await self.get_by_id_or_404(role_id)

            User = get_user_model()
            user_statement = select(User).where(User.id == user_id)
            user_result = await self.db_session.exec(user_statement)
            if not user_result.first():
                raise NotFoundError(f"User {user_id} does not exist")

            # Find relations to remove
            statement = select(UserRoleRelation).where(
                and_(
                    UserRoleRelation.role_id == role_id,
                    UserRoleRelation.user_id == user_id,
                    UserRoleRelation.is_active,
                )
            )
            result = await self.db_session.exec(statement)
            relation = result.first()

            if not relation:
                raise create_role_error("USER_ROLE_RELATION_NOT_EXISTS")

            # Remove relation (soft delete)
            relation.is_active = False
            await self.db_session.commit()

            self.logger.info(f"Successfully removed user {user_id} from role {role_id}")
            return True

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to remove user {user_id} from role {role_id}: {str(e)}"
            )
            raise create_role_error("REMOVE_USER_FAILED", {"error": str(e)})

    async def _get_role_by_name(self, name: str) -> Optional[Role]:
        """
        Get role by name (internal method)

        Args:
            name: Role name

        Returns:
            Role instance or None
        """
        statement = select(Role).where(Role.name == name)
        result = await self.db_session.exec(statement)
        return result.first()

    async def _get_role_user_count(self, role_id: int) -> int:
        """
        Get role user count

        Args:
            role_id: Role ID

        Returns:
            User count under this role
        """
        try:
            statement = select(UserRoleRelation.id).where(
                and_(
                    UserRoleRelation.role_id == role_id,
                    UserRoleRelation.is_active,
                )
            )

            result = await self.db_session.exec(statement)
            return len(result.all())

        except Exception as e:
            self.logger.error(f"Failed to get role {role_id} user count: {str(e)}")
            return 0

    async def get_role_user_count(self, role_id: int) -> int:
        """
        Public wrapper to get number of active users under a role.

        Args:
            role_id: Role ID

        Returns:
            Active user count for the role
        """
        return await self._get_role_user_count(role_id)

    async def get_all_roles(self) -> List[Role]:
        """
        Get all active roles without pagination

        Returns:
            List of all active roles
        """
        try:
            statement = select(Role).where(Role.is_active).order_by(Role.name)
            result = await self.db_session.exec(statement)
            roles = list(result.all())

            self.logger.debug(f"Retrieved {len(roles)} active roles")
            return roles

        except Exception as e:
            self.logger.error(f"Failed to get all roles: {str(e)}")
            raise create_role_error("GET_ALL_ROLES_FAILED", {"error": str(e)})

    async def get_role_permissions(self, role_id: int) -> List[Permission]:
        """
        Get role permission list

        Args:
            role_id: Role ID

        Returns:
            Permission list for this role
        """
        try:
            # Check if role exists
            role = await self.get_role(role_id)
            if not role:
                raise create_role_not_found(role_id)

            # Query permissions for this role
            statement = (
                select(Permission)
                .join(
                    RolePermissionRelation,
                    Permission.id == RolePermissionRelation.permission_id,
                )
                .where(
                    and_(
                        RolePermissionRelation.role_id == role_id,
                        RolePermissionRelation.is_active,
                        Permission.is_active,
                    )
                )
                .order_by(Permission.name)
            )

            result = await self.db_session.exec(statement)
            permissions = list(result.all())

            self.logger.info(
                f"Successfully retrieved {len(permissions)} permissions for role {role_id}"
            )
            return permissions

        except NotFoundError:
            raise
        except Exception as e:
            self.logger.error(f"Failed to get role {role_id} permissions: {str(e)}")
            raise create_role_error("GET_ROLE_PERMISSIONS_FAILED", {"error": str(e)})

    async def assign_permissions(
        self, role_id: int, assignment_data: PermissionRoleAssignment
    ) -> List[RolePermissionRelation]:
        """
        Assign permissions to role

        Args:
            role_id: Role ID
            assignment_data: Permission assignment data

        Returns:
            List of created assignment relations
        """
        try:
            # Check if role exists
            role = await self.get_role(role_id)
            if not role:
                raise create_role_not_found(role_id)

            # Check if all permissions exist
            permission_statement = select(Permission.id).where(
                Permission.id.in_(assignment_data.permission_ids)
            )
            permission_result = await self.db_session.exec(permission_statement)
            existing_permission_ids = set(permission_result.all())

            missing_permission_ids = (
                set(assignment_data.permission_ids) - existing_permission_ids
            )
            if missing_permission_ids:
                raise create_role_error(
                    "PERMISSIONS_NOT_FOUND",
                    {"missing_permission_ids": missing_permission_ids},
                )

            # Check for existing active relations
            existing_statement = select(RolePermissionRelation).where(
                and_(
                    RolePermissionRelation.role_id == role_id,
                    RolePermissionRelation.permission_id.in_(
                        assignment_data.permission_ids
                    ),
                    RolePermissionRelation.is_active,
                )
            )

            existing_result = await self.db_session.exec(existing_statement)
            existing_relations = existing_result.all()
            existing_assigned_permission_ids = {
                rel.permission_id for rel in existing_relations
            }

            # Only create new relations for permissions that are not already assigned
            new_permission_ids = (
                set(assignment_data.permission_ids) - existing_assigned_permission_ids
            )
            new_relations = []

            for permission_id in new_permission_ids:
                relation = RolePermissionRelation(
                    role_id=role_id,
                    permission_id=permission_id,
                    assigned_by=assignment_data.assigned_by,
                    expires_at=assignment_data.expires_at,
                )
                self.db_session.add(relation)
                new_relations.append(relation)

            await self.db_session.commit()

            for relation in new_relations:
                await self.db_session.refresh(relation)

            self.logger.info(
                f"Successfully assigned {len(new_relations)} new permissions to role {role_id}, skipped {len(existing_assigned_permission_ids)} existing relations"
            )
            return new_relations

        except NotFoundError:
            raise
        except DatabaseError:
            raise
        except Exception as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to assign permissions to role {role_id}: {str(e)}"
            )
            raise create_role_error("ASSIGN_PERMISSIONS_FAILED", {"error": str(e)})

    async def remove_permission(self, role_id: int, permission_id: int) -> bool:
        """
        Remove permission from role

        Args:
            role_id: Role ID
            permission_id: Permission ID

        Returns:
            Success flag
        """
        try:
            # Check if role exists
            role = await self.get_role(role_id)
            if not role:
                raise create_role_not_found(role_id)

            # Find active relation
            statement = select(RolePermissionRelation).where(
                and_(
                    RolePermissionRelation.role_id == role_id,
                    RolePermissionRelation.permission_id == permission_id,
                    RolePermissionRelation.is_active,
                )
            )

            result = await self.db_session.exec(statement)
            relation = result.first()

            if not relation:
                raise create_role_error(
                    "ROLE_PERMISSION_RELATION_NOT_EXISTS",
                    {"role_id": role_id, "permission_id": permission_id},
                )

            # Soft delete: set is_active to False
            relation.is_active = False
            relation.updated_at = datetime.now()

            await self.db_session.commit()

            self.logger.info(
                f"Successfully removed permission {permission_id} from role {role_id}"
            )
            return True

        except NotFoundError:
            raise
        except DatabaseError:
            raise
        except Exception as e:
            await self.db_session.rollback()
            self.logger.error(
                f"Failed to remove permission {permission_id} from role {role_id}: {str(e)}"
            )
            raise create_role_error("REMOVE_PERMISSION_FAILED", {"error": str(e)})
