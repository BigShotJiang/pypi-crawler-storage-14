#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:35:52
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Default User Serializer
    Serializer for default user model without password functionality.
    Inherits from BaseUserSerializer and provides default user model specific logic.

All Rights Reserved.
"""

from sqlmodel.ext.asyncio.session import AsyncSession

from .base_user_serializer import BaseUserSerializer
from ..models.default_user_model import User


class DefaultUserSerializer(BaseUserSerializer):
    """
    Default user serializer for User model without password functionality

    This serializer handles the default user model that doesn't include
    password fields or authentication logic.
    """

    user_model = User

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session)

    async def create_user(self, user_data):
        """
        Create default user (no password handling)

        Args:
            user_data: User creation data

        Returns:
            Created user instance
        """
        # For default user model, we don't need special password handling
        return await super().create_user(user_data)

    async def update_user(self, user_id: int, user_data):
        """
        Update default user (no password handling)

        Args:
            user_id: User ID
            user_data: User update data

        Returns:
            Updated user instance
        """
        # For default user model, we don't need special password handling
        return await super().update_user(user_id, user_data)
