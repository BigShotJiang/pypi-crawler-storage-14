#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-01-16 12:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Centralized error message management
    Unified key-value management for all serializer error messages.

All Rights Reserved.
"""



class ErrorMessages:
    """Centralized error message management class"""

    # Base CRUD operation messages
    BASE_MESSAGES = {
        "CREATE_FAILED": "Failed to create {model_name}",
        "UPDATE_FAILED": "Failed to update {model_name} record by ID {obj_id}",
        "DELETE_FAILED": "Failed to delete {model_name} record by ID {obj_id}",
        "GET_FAILED": "Failed to get {model_name} record by ID {obj_id}",
        "PAGINATE_FAILED": "Failed to paginate query {model_name}",
        "NOT_FOUND": "{resource} with identifier {identifier} not found",
    }

    # User-specific messages
    USER_MESSAGES = {
        "GET_USER_INFO_FAILED": "Failed to get user information",
        "QUERY_USER_LIST_FAILED": "Failed to query user list",
        "SEARCH_USERS_FAILED": "Failed to search users",
        "EMAIL_ALREADY_EXISTS": "Email {email} already exists",
        "EMAIL_ALREADY_USED": "Email {email} already used by other user",
        "USER_CREATE_FAILED": "Failed to create user",
        "USER_UPDATE_FAILED": "Failed to update user",
        "GET_USER_ROLES_FAILED": "Failed to get user role list",
        "ROLES_NOT_FOUND": "Role not found: {missing_role_ids}",
        "ASSIGN_ROLES_FAILED": "Failed to assign roles",
        "REMOVE_ROLES_FAILED": "Failed to remove roles",
        "USER_NOT_FOUND": "User {user_id} not found",
        "GET_USER_PERMISSIONS_FAILED": "Failed to get user permissions",
    }

    # Role-specific messages
    ROLE_MESSAGES = {
        "ROLE_NAME_EXISTS": "Role name {name} already exists",
        "ROLE_CREATE_FAILED": "Failed to create role",
        "GET_ROLE_INFO_FAILED": "Failed to get role information",
        "QUERY_ROLE_LIST_FAILED": "Failed to query role list",
        "ROLE_NAME_USED": "Role name {name} already used by other role",
        "ROLE_UPDATE_FAILED": "Failed to update role",
        "SYSTEM_ROLE_CANNOT_DELETE": "System role cannot be deleted",
        "ROLE_HAS_USERS": "Role still has {user_count} associated users, cannot be deleted",
        "ROLE_DELETE_FAILED": "Failed to delete role",
        "GET_ROLE_USERS_FAILED": "Failed to get role users list",
        "USERS_NOT_FOUND": "Users not found: {missing_user_ids}",
        "ASSIGN_USERS_FAILED": "Failed to assign users",
        "USER_ROLE_RELATION_NOT_FOUND": "User role relation not found",
        "REMOVE_USER_FAILED": "Failed to remove user",
        "ASSIGN_SUCCESS": "Successfully assigned {count} users to role",
        "REMOVE_USER_SUCCESS": "Successfully removed user",
        "USER_ROLE_RELATION_NOT_EXISTS": "User role relation does not exist",
    }

    # Permission-specific messages
    PERMISSION_MESSAGES = {
        "PERMISSION_CODE_EXISTS": "Permission code {code} already exists",
        "PERMISSION_NAME_EXISTS": "Permission name {name} already exists",
        "PERMISSION_CREATE_FAILED": "Failed to create permission",
        "GET_PERMISSION_INFO_FAILED": "Failed to get permission information",
        "QUERY_PERMISSION_LIST_FAILED": "Failed to query permission list",
        "PERMISSION_CODE_USED": "Permission code {code} already used by other permission",
        "PERMISSION_NAME_USED": "Permission name {name} already used by other permission",
        "PERMISSION_UPDATE_FAILED": "Failed to update permission",
        "SYSTEM_PERMISSION_CANNOT_DELETE": "Cannot delete system built-in permission",
        "PERMISSION_HAS_ROLES": "Permission still has {role_count} associated roles, cannot be deleted",
        "PERMISSION_DELETE_FAILED": "Failed to delete permission",
        "ASSIGN_ROLES_TO_PERMISSION_FAILED": "Failed to assign roles to permission",
        "REMOVE_ROLES_FROM_PERMISSION_FAILED": "Failed to remove roles from permission",
        "ROLES_NOT_FOUND_FOR_PERMISSION": "Role not found: {missing_role_ids}",
        "ASSIGN_ROLES_SUCCESS": "Successfully assigned {count} roles to permission",
        "REMOVE_ROLE_FAILED": "Failed to remove role",
        "PERMISSION_ROLE_RELATION_NOT_EXISTS": "Permission role relation does not exist",
        "ALREADY_EXISTS": "Already exists",
    }

    # Router-level common messages
    ROUTER_MESSAGES = {
        "DATABASE_QUERY_FAILED": "Database query failed",
        "DATABASE_OPERATION_FAILED": "Database operation failed",
        "SERVER_INTERNAL_ERROR": "Server internal error",
        "INVALID_CREDENTIALS": "Invalid email or password",
        "DELETE_OPERATION_FAILED": "Delete operation failed",
        "REMOVE_OPERATION_FAILED": "Remove operation failed",
        "ASSIGN_SUCCESS": "Successfully assigned {count} {entity_type}",
        "REMOVE_SUCCESS": "Successfully removed {entity_type}",
        "USER_NOT_EXISTS": "User {user_id} does not exist",
        "ROLE_NOT_EXISTS": "Role {role_id} does not exist",
        "PERMISSION_NOT_EXISTS": "Permission {permission_id} does not exist",
        "RELATION_NOT_EXISTS": "Relation does not exist",
        "USERS_NOT_FOUND": "Users not found: {missing_user_ids}",
        "ROLES_NOT_FOUND": "Roles not found: {missing_role_ids}",
    }

    @classmethod
    def get_message(cls, category: str, key: str, **kwargs) -> str:
        """
        Get formatted error message

        Args:
            category: Message category (BASE, USER, ROLE, PERMISSION)
            key: Message key
            **kwargs: Parameters for message formatting

        Returns:
            Formatted error message

        Raises:
            KeyError: If category or key not found
        """
        category_dict = getattr(cls, f"{category}_MESSAGES", {})
        if key not in category_dict:
            raise KeyError(f"Message key '{key}' not found in category '{category}'")

        template = category_dict[key]
        try:
            return template.format(**kwargs)
        except KeyError as e:
            raise KeyError(
                f"Missing parameter {e} for message '{key}' in category '{category}'"
            )

    @classmethod
    def get_base_message(cls, key: str, **kwargs) -> str:
        """Get base category message"""
        return cls.get_message("BASE", key, **kwargs)

    @classmethod
    def get_user_message(cls, key: str, **kwargs) -> str:
        """Get user category message"""
        return cls.get_message("USER", key, **kwargs)

    @classmethod
    def get_role_message(cls, key: str, **kwargs) -> str:
        """Get role category message"""
        return cls.get_message("ROLE", key, **kwargs)

    @classmethod
    def get_permission_message(cls, key: str, **kwargs) -> str:
        """Get permission category message"""
        return cls.get_message("PERMISSION", key, **kwargs)

    @classmethod
    def get_router_message(cls, key: str, **kwargs) -> str:
        """Get router category message"""
        return cls.get_message("ROUTER", key, **kwargs)


# Convenience aliases for easier usage
def get_error_message(category: str, key: str, **kwargs) -> str:
    """Convenience function to get error message"""
    return ErrorMessages.get_message(category, key, **kwargs)


# Category-specific convenience functions
def get_base_error(key: str, **kwargs) -> str:
    """Get base error message"""
    return ErrorMessages.get_base_message(key, **kwargs)


def get_user_error(key: str, **kwargs) -> str:
    """Get user error message"""
    return ErrorMessages.get_user_message(key, **kwargs)


def get_role_error(key: str, **kwargs) -> str:
    """Get role error message"""
    return ErrorMessages.get_role_message(key, **kwargs)


def get_permission_error(key: str, **kwargs) -> str:
    """Get permission error message"""
    return ErrorMessages.get_permission_message(key, **kwargs)


def get_router_error(key: str, **kwargs) -> str:
    """Get router error message"""
    return ErrorMessages.get_router_message(key, **kwargs)


# DELETED KEYS AND THEIR REPLACEMENTS
# ===================================
#
# The following keys were removed due to duplication or similarity.
# Use this mapping for global replacement:
#
# DELETED_KEY -> REPLACEMENT_KEY
#
# From USER_MESSAGES:
# "DATABASE_QUERY_FAILED" -> "ROUTER.DATABASE_QUERY_FAILED"
# "SERVER_INTERNAL_ERROR" -> "ROUTER.SERVER_INTERNAL_ERROR"
# "USER_NOT_EXISTS" -> "ROUTER.USER_NOT_EXISTS"
#
# From ROLE_MESSAGES:
# "DATABASE_QUERY_FAILED" -> "ROUTER.DATABASE_QUERY_FAILED"
# "DATABASE_OPERATION_FAILED" -> "ROUTER.DATABASE_OPERATION_FAILED"
# "SERVER_INTERNAL_ERROR" -> "ROUTER.SERVER_INTERNAL_ERROR"
# "ROLE_NOT_EXISTS" -> "ROUTER.ROLE_NOT_EXISTS"
# "USER_NOT_EXISTS" -> "ROUTER.USER_NOT_EXISTS"
# "DELETE_ROLE_FAILED" -> "ROLE.ROLE_DELETE_FAILED"
# "SYSTEM_BUILTIN_ROLE_DELETE" -> "ROLE.SYSTEM_ROLE_CANNOT_DELETE"
# "ROLE_HAS_ASSOCIATED_USERS" -> "ROLE.ROLE_HAS_USERS"
# "USERS_NOT_EXISTS" -> "ROLE.USERS_NOT_FOUND"
# "NAME_ALREADY_USED" -> "ROLE.ROLE_NAME_USED"
#
# From PERMISSION_MESSAGES:
# "DATABASE_QUERY_FAILED" -> "ROUTER.DATABASE_QUERY_FAILED"
# "DATABASE_OPERATION_FAILED" -> "ROUTER.DATABASE_OPERATION_FAILED"
# "SERVER_INTERNAL_ERROR" -> "ROUTER.SERVER_INTERNAL_ERROR"
# "PERMISSION_NOT_EXISTS" -> "ROUTER.PERMISSION_NOT_EXISTS"
# "PERMISSION_NOT_EXISTS_CN" -> "ROUTER.PERMISSION_NOT_EXISTS"
# "DELETE_PERMISSION_FAILED" -> "PERMISSION.PERMISSION_DELETE_FAILED"
# "SYSTEM_BUILTIN_PERMISSION_DELETE" -> "PERMISSION.SYSTEM_PERMISSION_CANNOT_DELETE"
# "PERMISSION_HAS_ASSOCIATED_ROLES" -> "PERMISSION.PERMISSION_HAS_ROLES"
# "ROLES_NOT_EXISTS" -> "PERMISSION.ROLES_NOT_FOUND_FOR_PERMISSION"
# "CODE_ALREADY_USED" -> "PERMISSION.PERMISSION_CODE_USED"
# "NAME_ALREADY_USED" -> "PERMISSION.PERMISSION_NAME_USED"
#
# CORRECTED MESSAGES:
# "REMOVE_USER_SUCCESS" message content was corrected from "Failed to remove user" to "Successfully removed user"
