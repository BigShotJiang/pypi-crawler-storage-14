"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:25:26
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Permission Serializer
    Implement permission-related business logic, including CRUD operations and role management.

All Rights Reserved.
"""

from typing import List, Optional
from sqlmodel import select, and_
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.orm import selectinload

from ..models import Role, Permission, RolePermissionRelation
from ..schemas.permission_schemas import (
    PermissionCreate,
    PermissionUpdate,
    PermissionSearchParams,
    RolePermissionAssignment,
)
from ..schemas.common_schemas import PaginationParams, PaginatedResponse
from .base_serializer import BaseSerializer
from .exceptions import (
    create_permission_error,
    DatabaseError,
    NotFoundError,
)


class PermissionSerializer(
    BaseSerializer[Permission, PermissionCreate, PermissionUpdate]
):
    """
    Permission Serializer

    Implement permission-related business logic, including CRUD operations and role management.
    """

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session, Permission)

    async def create_permission(self, permission_data: PermissionCreate) -> Permission:
        """
        Create permission

        Args:
            permission_data: Permission creation data

        Returns:
            Created permission instance
        """
        try:
            # Check if permission code already exists
            existing_permission = await self._get_permission_by_code(
                permission_data.code
            )
            if existing_permission:
                raise create_permission_error(
                    "PERMISSION_CODE_EXISTS", code=permission_data.code
                )

            # Create permission
            permission = await self.create(permission_data)

            self.logger.info(f"Successfully created permission: {permission.code}")
            return permission

        except DatabaseError:
            raise
        except Exception as e:
            self.logger.exception(f"Failed to create permission: {str(e)}")
            raise e
            # raise create_permission_error("PERMISSION_CREATE_FAILED", {"error": str(e)})

    async def get_permission(
        self, permission_id: int, include_roles: bool = False
    ) -> Optional[Permission]:
        """
        Get single permission information

        Args:
            permission_id: Permission ID
            include_roles: Whether to include role information

        Returns:
            Permission instance or None
        """
        try:
            statement = select(Permission).where(Permission.id == permission_id)

            if include_roles:
                statement = statement.options(
                    selectinload(Permission.permission_roles).selectinload(
                        RolePermissionRelation.role
                    )
                )

            result = await self.db_session.exec(statement)
            return result.first()

        except Exception as e:
            self.logger.error(
                f"Failed to get permission {permission_id} information: {str(e)}"
            )
            raise create_permission_error(
                "GET_PERMISSION_INFO_FAILED", {"error": str(e)}
            )

    async def get_permissions(
        self,
        pagination: PaginationParams,
        search_params: Optional[PermissionSearchParams] = None,
    ) -> PaginatedResponse[Permission]:
        """
        Paginate query permission list

        Args:
            pagination: Pagination parameters
            search_params: Search parameters

        Returns:
            Paginated permission list
        """
        try:
            # Build base query
            statement = select(Permission)

            # Build filter conditions
            filters = []

            if search_params:
                if search_params.code:
                    filters.append(Permission.code.contains(search_params.code))

                if search_params.name:
                    filters.append(Permission.name.contains(search_params.name))

                if search_params.description:
                    filters.append(
                        Permission.description.contains(search_params.description)
                    )

                if search_params.resource:
                    filters.append(Permission.resource.contains(search_params.resource))

                if search_params.action:
                    filters.append(Permission.action.contains(search_params.action))

                if search_params.permission_type:
                    filters.append(
                        Permission.permission_type == search_params.permission_type
                    )

                if search_params.is_active is not None:
                    filters.append(Permission.is_active == search_params.is_active)

                if search_params.is_system is not None:
                    filters.append(Permission.is_system == search_params.is_system)

                if search_params.created_after:
                    filters.append(Permission.created_at >= search_params.created_after)

                if search_params.created_before:
                    filters.append(
                        Permission.created_at <= search_params.created_before
                    )

            # Apply filter conditions
            if filters:
                statement = statement.where(and_(*filters))

            # Sort
            statement = statement.order_by(Permission.created_at.desc())

            # Calculate total
            count_statement = select(Permission.id)
            if filters:
                count_statement = count_statement.where(and_(*filters))

            count_result = await self.db_session.exec(count_statement)
            total = len(count_result.all())

            # Apply pagination
            statement = statement.offset(pagination.offset).limit(pagination.size)

            # Execute query
            result = await self.db_session.exec(statement)
            items = result.all()

            return PaginatedResponse.create(
                items=items, total=total, page=pagination.page, size=pagination.size
            )

        except Exception as e:
            self.logger.error(f"Failed to query permission list: {str(e)}")
            raise DatabaseError("Failed to query permission list", {"error": str(e)})

    async def update_permission(
        self, permission_id: int, permission_data: PermissionUpdate
    ) -> Permission:
        """
        Update permission information

        Args:
            permission_id: Permission ID
            permission_data: Permission update data

        Returns:
            Updated permission instance
        """
        try:
            # If updating permission code, check if it is duplicated
            if permission_data.code:
                existing_permission = await self._get_permission_by_code(
                    permission_data.code
                )
                if existing_permission and existing_permission.id != permission_id:
                    raise create_permission_error(
                        "PERMISSION_CODE_USED", code=permission_data.code
                    )

            # Update permission
            permission = await self.update(permission_id, permission_data)

            self.logger.info(f"Successfully updated permission: {permission.code}")
            return permission

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            self.logger.error(f"Failed to update permission: {str(e)}")
            raise DatabaseError("Failed to update permission", {"error": str(e)})

    async def delete_permission(self, permission_id: int) -> bool:
        """
        Delete permission

        Args:
            permission_id: Permission ID

        Returns:
            Whether deletion is successful
        """
        try:
            # Get permission information
            permission = await self.get_by_id(permission_id)
            if not permission:
                raise NotFoundError(f"Permission {permission_id} does not exist")

            # Check if it is a system built-in permission
            if permission.is_system:
                raise create_permission_error("SYSTEM_PERMISSION_CANNOT_DELETE")

            # Check if there are related roles
            role_count = await self._get_permission_role_count(permission_id)
            if role_count > 0:
                raise create_permission_error(
                    "PERMISSION_HAS_ROLES", role_count=role_count
                )

            # Delete permission
            await self.delete(permission_id)

            self.logger.info(f"Successfully deleted permission: {permission.code}")
            return True

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            self.logger.error(f"Failed to delete permission: {str(e)}")
            raise DatabaseError("Failed to delete permission", {"error": str(e)})

    async def get_permission_roles(self, permission_id: int) -> List[Role]:
        """
        Get roles with specified permission

        Args:
            permission_id: Permission ID

        Returns:
            Role list
        """
        try:
            # Check if permission exists
            permission = await self.get_by_id(permission_id)
            if not permission:
                raise NotFoundError(f"Permission {permission_id} does not exist")

            # Query roles with this permission
            statement = (
                select(Role)
                .join(RolePermissionRelation, Role.id == RolePermissionRelation.role_id)
                .where(
                    and_(
                        RolePermissionRelation.permission_id == permission_id,
                        RolePermissionRelation.is_active,
                        Role.is_active,
                    )
                )
                .order_by(Role.name)
            )

            result = await self.db_session.exec(statement)
            roles = result.all()

            self.logger.debug(
                f"Permission {permission_id} has {len(roles)} related roles"
            )
            return roles

        except NotFoundError:
            raise
        except Exception as e:
            self.logger.error(
                f"Failed to get permission {permission_id} roles list: {str(e)}"
            )
            raise DatabaseError(
                "Failed to get permission roles list", {"error": str(e)}
            )

    async def assign_roles(
        self, permission_id: int, assignment_data: RolePermissionAssignment
    ) -> List[RolePermissionRelation]:
        """
        Assign roles to permission

        Args:
            permission_id: Permission ID
            assignment_data: Role assignment data

        Returns:
            Created permission role relation list
        """
        try:
            # Check if permission exists
            permission = await self.get_by_id(permission_id)
            if not permission:
                raise NotFoundError(f"Permission {permission_id} does not exist")

            # Check if roles exist
            role_statement = select(Role).where(Role.id.in_(assignment_data.role_ids))
            role_result = await self.db_session.exec(role_statement)
            existing_roles = role_result.all()
            existing_role_ids = {role.id for role in existing_roles}

            missing_role_ids = set(assignment_data.role_ids) - existing_role_ids
            if missing_role_ids:
                raise create_permission_error(
                    "ROLES_NOT_FOUND_FOR_PERMISSION", missing_role_ids=missing_role_ids
                )

            # Check if there are existing relations
            existing_statement = select(RolePermissionRelation).where(
                and_(
                    RolePermissionRelation.permission_id == permission_id,
                    RolePermissionRelation.role_id.in_(assignment_data.role_ids),
                    RolePermissionRelation.is_active,
                )
            )
            existing_result = await self.db_session.exec(existing_statement)
            existing_relations = existing_result.all()
            existing_assigned_role_ids = {rel.role_id for rel in existing_relations}

            # Filter out the relations that need to be created
            new_role_ids = set(assignment_data.role_ids) - existing_assigned_role_ids

            # Create new permission role relations
            new_relations = []
            for role_id in new_role_ids:
                relation = RolePermissionRelation(
                    permission_id=permission_id,
                    role_id=role_id,
                    assigned_by=assignment_data.assigned_by,
                    expires_at=assignment_data.expires_at,
                )
                self.db_session.add(relation)
                new_relations.append(relation)

            await self.db_session.commit()

            # Refresh related objects
            for relation in new_relations:
                await self.db_session.refresh(relation)

            self.logger.info(
                f"Successfully assigned {len(new_relations)} new roles to permission {permission_id}, skipped {len(existing_assigned_role_ids)} existing relations"
            )

            return new_relations

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            self.logger.error(
                f"Failed to assign roles to permission {permission_id}: {str(e)}"
            )
            await self.db_session.rollback()
            raise DatabaseError(
                "Failed to assign roles to permission", {"error": str(e)}
            )

    async def remove_role(self, permission_id: int, role_id: int) -> bool:
        """
        Remove role from permission

        Args:
            permission_id: Permission ID
            role_id: Role ID

        Returns:
            Whether removal is successful
        """
        try:
            # Check if permission exists
            permission = await self.get_by_id(permission_id)
            if not permission:
                raise NotFoundError(
                    "Permission does not exist", {"permission_id": permission_id}
                )

            # Find related relations
            statement = select(RolePermissionRelation).where(
                and_(
                    RolePermissionRelation.permission_id == permission_id,
                    RolePermissionRelation.role_id == role_id,
                    RolePermissionRelation.is_active,
                )
            )

            result = await self.db_session.exec(statement)
            relation = result.first()

            if not relation:
                raise NotFoundError(
                    "Permission and role are not associated",
                    {"permission_id": permission_id, "role_id": role_id},
                )

            # Delete related relations
            await self.db_session.delete(relation)
            await self.db_session.commit()

            self.logger.info(
                f"Successfully removed role {role_id} from permission {permission_id}"
            )
            return True

        except (DatabaseError, NotFoundError):
            raise
        except Exception as e:
            self.logger.error(
                f"Failed to remove role {role_id} from permission {permission_id}: {str(e)}"
            )
            await self.db_session.rollback()
            raise DatabaseError(
                "Failed to remove role from permission", {"error": str(e)}
            )

    async def _get_permission_by_code(self, code: str) -> Optional[Permission]:
        """
        Get permission by code

        Args:
            code: Permission code

        Returns:
            Permission instance or None
        """
        try:
            statement = select(Permission).where(Permission.code == code)
            result = await self.db_session.exec(statement)
            return result.first()

        except Exception as e:
            self.logger.error(f"Failed to get permission by code: {str(e)}")
            return None

    async def _get_permission_role_count(self, permission_id: int) -> int:
        """
        Get the number of roles associated with the permission

        Args:
            permission_id: Permission ID

        Returns:
            Number of related roles
        """
        try:
            statement = select(RolePermissionRelation.id).where(
                and_(
                    RolePermissionRelation.permission_id == permission_id,
                    RolePermissionRelation.is_active,
                )
            )

            result = await self.db_session.exec(statement)
            return len(result.all())

        except Exception as e:
            self.logger.error(
                f"Failed to get the number of roles associated with the permission {permission_id}: {str(e)}"
            )
            return 0

    async def get_permission_role_count(self, permission_id: int) -> int:
        """
        Public wrapper to get number of active roles associated with a permission.

        Args:
            permission_id: Permission ID

        Returns:
            Active related role count for the permission
        """
        return await self._get_permission_role_count(permission_id)
