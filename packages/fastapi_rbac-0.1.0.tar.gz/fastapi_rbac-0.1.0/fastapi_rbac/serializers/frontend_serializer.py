#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Frontend Serializer for RBAC Management System
Handles business logic for frontend dashboard and statistics
"""

from typing import Dict, Any
from sqlmodel import select
from sqlalchemy import func
from sqlmodel.ext.asyncio.session import AsyncSession

from ..models import Role, Permission, get_user_model
from .base_serializer import BaseSerializer
from .exceptions import create_base_error


class FrontendSerializer(BaseSerializer):
    """
    Frontend serializer for dashboard and statistics

    Handles business logic for frontend-specific operations like
    dashboard statistics and summary data aggregation.
    """

    def __init__(self, db_session: AsyncSession):
        super().__init__(db_session, None)  # No primary model for this serializer

    async def get_dashboard_stats(self) -> Dict[str, Any]:
        """
        Get dashboard statistics including total counts for users, roles, and permissions

        Returns:
            Dictionary containing:
            - total_users: Total number of users in the system
            - total_roles: Total number of roles in the system
            - total_permissions: Total number of permissions in the system

        Raises:
            DatabaseError: If database query fails
        """
        try:
            # Get current User model dynamically
            User = get_user_model()
            # Get total user count
            user_count_statement = select(func.count(User.id))
            user_count_result = await self.db_session.exec(user_count_statement)
            total_users = user_count_result.one()

            # Get total role count
            role_count_statement = select(func.count(Role.id))
            role_count_result = await self.db_session.exec(role_count_statement)
            total_roles = role_count_result.one()

            # Get total permission count
            permission_count_statement = select(func.count(Permission.id))
            permission_count_result = await self.db_session.exec(
                permission_count_statement
            )
            total_permissions = permission_count_result.one()

            stats = {
                "total_users": total_users,
                "total_roles": total_roles,
                "total_permissions": total_permissions,
            }

            self.logger.info(f"Dashboard statistics retrieved: {stats}")
            return stats

        except Exception as e:
            self.logger.error(f"Failed to get dashboard statistics: {str(e)}")
            raise create_base_error("DASHBOARD_STATS_QUERY_FAILED", {"error": str(e)})
