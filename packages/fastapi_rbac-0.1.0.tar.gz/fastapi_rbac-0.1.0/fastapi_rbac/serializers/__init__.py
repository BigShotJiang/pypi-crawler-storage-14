#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:38:11
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Serializer module initialization
    Export all RBAC-related serializer classes.

All Rights Reserved.
"""

from .base_serializer import BaseSerializer
from .base_user_serializer import BaseUserSerializer
from .role_serializer import RoleSerializer
from .permission_serializer import PermissionSerializer
from .exceptions import (
    create_user_error,
    create_user_not_found,
    create_role_error,
    create_permission_error,
    DatabaseError,
    NotFoundError,
)


class DynamicUserSerializer:
    """
    Dynamic UserSerializer that automatically selects the appropriate serializer
    based on the current configuration.
    """

    def __new__(cls, *args, **kwargs):
        """
        Dynamically create the appropriate UserSerializer instance
        """
        try:
            # Try to get the appropriate serializer class
            serializer_class = cls.get_class()
            return serializer_class(*args, **kwargs)
        except Exception:
            # Fallback to legacy serializer if configuration is not available
            return BaseUserSerializer(*args, **kwargs)

    @classmethod
    def get_class(cls):
        """
        Get the appropriate UserSerializer class
        """
        try:
            from ..config import get_rbac_config

            config = get_rbac_config()
            return config.user_serializer

        except Exception:
            # Fallback to legacy serializer if configuration is not available
            return BaseUserSerializer


# Create the dynamic UserSerializer alias
UserSerializer = DynamicUserSerializer


def get_user_serializer_factory():
    """Get user serializer factory for backward compatibility"""
    from .user_serializer_factory import UserSerializerFactory

    return UserSerializerFactory


def get_create_user_serializer():
    """Get create user serializer function for backward compatibility"""
    from .user_serializer_factory import create_user_serializer

    return create_user_serializer


__all__ = [
    # Base serializers
    "BaseSerializer",
    "BaseUserSerializer",
    # User serializers
    "UserSerializer",  # Dynamic serializer based on configuration
    "get_user_serializer_factory",
    "get_create_user_serializer",
    # Other serializers
    "RoleSerializer",
    "PermissionSerializer",
    # Exceptions
    "create_user_error",
    "create_user_not_found",
    "create_role_error",
    "create_permission_error",
    "DatabaseError",
    "NotFoundError",
]
