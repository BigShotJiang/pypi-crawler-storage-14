#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-26 18:35:52
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: User Serializer Factory
    Factory for creating appropriate user serializers based on configuration.
    Automatically selects the correct serializer based on the user model type.

All Rights Reserved.
"""

from typing import Type, Any
from sqlmodel.ext.asyncio.session import AsyncSession

from .base_user_serializer import BaseUserSerializer
from ..config import get_rbac_config


class UserSerializerFactory:
    """
    Factory for creating user serializers based on configuration

    This factory automatically determines which serializer to use based on
    the configured user serializer and returns the appropriate instance.
    """

    @staticmethod
    def create_serializer(db_session: AsyncSession) -> BaseUserSerializer:
        """
        Create the appropriate user serializer based on configuration

        Args:
            db_session: Database session

        Returns:
            Appropriate user serializer instance

        Raises:
            ValueError: If user serializer is not recognized
        """
        try:
            # Get current configuration
            config = get_rbac_config()
            user_serializer_class = config.user_serializer

            # Create serializer instance
            return user_serializer_class(db_session)

        except Exception as e:
            raise ValueError(f"Failed to create user serializer: {str(e)}")

    @staticmethod
    def get_serializer_class() -> Type[BaseUserSerializer]:
        """
        Get the appropriate serializer class from current configuration

        Returns:
            Appropriate serializer class

        Raises:
            RuntimeError: If configuration is not available
        """
        try:
            # Get current configuration
            config = get_rbac_config()
            return config.user_serializer

        except Exception as e:
            raise RuntimeError(f"Failed to get serializer class from config: {str(e)}")

    @staticmethod
    def get_user_model() -> Type[Any]:
        """
        Get the user model from the configured serializer

        Returns:
            User model class

        Raises:
            RuntimeError: If configuration is not available
        """
        try:
            # Get current configuration
            config = get_rbac_config()
            return config.user_serializer.user_model

        except Exception as e:
            raise RuntimeError(f"Failed to get user model from config: {str(e)}")


# Convenience function for backward compatibility
def create_user_serializer(db_session: AsyncSession) -> BaseUserSerializer:
    """
    Create user serializer (backward compatibility)

    Args:
        db_session: Database session

    Returns:
        Appropriate user serializer instance
    """
    return UserSerializerFactory.create_serializer(db_session)
