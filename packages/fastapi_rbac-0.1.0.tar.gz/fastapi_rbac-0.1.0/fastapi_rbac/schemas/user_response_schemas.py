#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-01-27 10:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: User Response Schemas
    Pydantic schemas for user API responses with sensitive field filtering.

All Rights Reserved.
"""

from typing import Optional, Any, Type
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict


class UserResponseBase(BaseModel):
    """
    Base user response schema with sensitive fields excluded
    """

    id: Optional[int] = Field(None, description="User ID")
    email: str = Field(..., description="Email address")
    name: Optional[str] = Field(None, description="Username")
    en_name: Optional[str] = Field(None, description="English name")
    mobile: Optional[str] = Field(None, description="Mobile phone")
    user_id: Optional[str] = Field(None, description="External system user ID")
    status: Optional[int] = Field(None, description="User status")
    locked: Optional[int] = Field(None, description="User lock status")
    created_at: Optional[datetime] = Field(None, description="Creation time")
    updated_at: Optional[datetime] = Field(None, description="Update time")
    last_login: Optional[datetime] = Field(None, description="Last login time")

    model_config = ConfigDict(
        from_attributes=True, str_strip_whitespace=True, arbitrary_types_allowed=True
    )


def create_user_response_model(user_model: Type[Any]) -> Type[UserResponseBase]:
    """
    Create a user response model based on the actual user model

    Args:
        user_model: The actual user model class

    Returns:
        A Pydantic model for user responses with sensitive fields excluded
    """
    # Get all fields from the user model
    if hasattr(user_model, "model_fields"):
        fields = user_model.model_fields
    elif hasattr(user_model, "__annotations__"):
        fields = user_model.__annotations__
    else:
        # Fallback to base fields
        return UserResponseBase

    # Create a new model class dynamically
    class UserResponse(UserResponseBase):
        pass

    # Add fields from the actual user model, excluding sensitive ones
    sensitive_fields = {"password"}

    for field_name, field_info in fields.items():
        if field_name not in sensitive_fields and not hasattr(
            UserResponse.model_fields, field_name
        ):
            # Add the field to the response model
            if hasattr(field_info, "default"):
                default_value = field_info.default
            else:
                default_value = None

            setattr(
                UserResponse,
                field_name,
                Field(default_value, description=f"{field_name} field"),
            )

    return UserResponse
