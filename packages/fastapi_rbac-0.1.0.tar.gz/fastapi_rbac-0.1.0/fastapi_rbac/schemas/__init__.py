"""
Schemas Module Initialization

Export all RBAC-related data transfer objects.
"""

from .user_schemas import (
    RoleInfo,
    UserWithRoles,
    UserSearchParams,
    LoginRequest,
    TokenResponse,
)

from .role_schemas import (
    RoleCreate,
    RoleUpdate,
    RoleResponse,
    UserInfo,
    RoleWithUsers,
    UserRoleAssignment,
    RoleSearchParams,
    PermissionRoleAssignment,
)

from .permission_schemas import (
    PermissionCreate,
    PermissionUpdate,
    PermissionResponse,
    PermissionWithRoles,
    RolePermissionAssignment,
    PermissionSearchParams,
)

from .common_schemas import (
    PaginationParams,
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse,
    BulkOperationResult,
)

# Export all Schema classes
__all__ = [
    # Common schemas
    "PaginationParams",
    "PaginatedResponse",
    "ErrorResponse",
    # User schemas (dynamic user model only)
    "UserWithRoles",
    "RoleInfo",
    "UserSearchParams",
    "LoginRequest",
    "TokenResponse",
    "UserRoleAssignment",
    # Role schemas
    "RoleCreate",
    "RoleUpdate",
    "RoleResponse",
    "RoleWithUsers",
    "UserInfo",
    "RoleSearchParams",
    "PermissionRoleAssignment",
    # Permission schemas
    "PermissionCreate",
    "PermissionUpdate",
    "PermissionResponse",
    "PermissionWithRoles",
    "RolePermissionAssignment",
    "PermissionSearchParams",
    # Common
    "BulkOperationResult",
    # Shared info classes
    "SuccessResponse",
]
