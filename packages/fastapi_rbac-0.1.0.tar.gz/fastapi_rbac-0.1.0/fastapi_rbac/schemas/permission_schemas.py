"""
Permission-related Data Transfer Objects (DTOs)

Defines input and output data structures for permission-related operations.
"""

from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class PermissionBase(BaseModel):
    """Permission base information"""

    code: str = Field(..., min_length=1, max_length=100, description="Permission code")
    name: str = Field(..., min_length=1, max_length=50, description="Permission name")
    description: Optional[str] = Field(
        None, max_length=200, description="Permission description"
    )
    resource: Optional[str] = Field(
        None, max_length=50, description="Permission resource identifier"
    )
    action: Optional[str] = Field(
        None, max_length=50, description="Permission action type"
    )
    permission_type: Optional[str] = Field(
        "function", max_length=20, description="Permission type: function/data/api"
    )


class PermissionCreate(PermissionBase):
    """Permission creation data"""

    is_active: bool = Field(True, description="Permission active status")
    is_system: bool = Field(False, description="System built-in permission")


class PermissionUpdate(BaseModel):
    """Permission update data"""

    code: Optional[str] = Field(
        None, min_length=1, max_length=100, description="Permission code"
    )
    name: Optional[str] = Field(
        None, min_length=1, max_length=50, description="Permission name"
    )
    description: Optional[str] = Field(
        None, max_length=200, description="Permission description"
    )
    resource: Optional[str] = Field(
        None, max_length=50, description="Permission resource identifier"
    )
    action: Optional[str] = Field(
        None, max_length=50, description="Permission action type"
    )
    permission_type: Optional[str] = Field(
        None, max_length=20, description="Permission type: function/data/api"
    )
    is_active: Optional[bool] = Field(None, description="Permission active status")


class PermissionResponse(PermissionBase):
    """Permission response data"""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(..., description="Permission ID")
    is_active: bool = Field(..., description="Permission active status")
    is_system: bool = Field(..., description="System built-in permission")
    created_at: datetime = Field(..., description="Creation time")
    updated_at: datetime = Field(..., description="Update time")


class RoleInfo(BaseModel):
    """Brief role information"""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(..., description="Role ID")
    name: str = Field(..., description="Role name")
    description: Optional[str] = Field(None, description="Role description")
    is_active: bool = Field(..., description="Role active status")
    is_system: bool = Field(..., description="System built-in role")


class PermissionWithRoles(PermissionResponse):
    """Permission information with roles"""

    roles: List[RoleInfo] = Field(
        default_factory=list, description="Roles that have this permission"
    )


class RolePermissionAssignment(BaseModel):
    """Role permission assignment data"""

    role_ids: List[int] = Field(..., min_length=1, description="Role ID list")
    assigned_by: Optional[int] = Field(None, description="Assignor ID")
    expires_at: Optional[datetime] = Field(
        None, description="Permission expiration time"
    )


class PermissionSearchParams(BaseModel):
    """Permission search parameters"""

    code: Optional[str] = Field(None, description="Permission code search")
    name: Optional[str] = Field(None, description="Permission name search")
    description: Optional[str] = Field(
        None, description="Permission description search"
    )
    resource: Optional[str] = Field(None, description="Permission resource search")
    action: Optional[str] = Field(None, description="Permission action type search")
    permission_type: Optional[str] = Field(None, description="Permission type search")
    is_active: Optional[bool] = Field(None, description="Active status filter")
    is_system: Optional[bool] = Field(None, description="System permission filter")
    created_after: Optional[datetime] = Field(None, description="Creation time start")
    created_before: Optional[datetime] = Field(None, description="Creation time end")
