"""
User-related Data Transfer Objects (DTOs)

Defines input and output data structures for user-related operations.
"""

from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class RoleInfo(BaseModel):
    """Brief role information"""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(..., description="Role ID")
    name: str = Field(..., description="Role name")
    description: Optional[str] = Field(None, description="Role description")
    is_active: bool = Field(..., description="Role active status")


class UserWithRoles(BaseModel):
    """User information with roles"""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(..., description="User ID")
    name: str = Field(..., description="Username")
    en_name: str = Field(..., description="English name")
    email: str = Field(..., description="Email address")
    mobile: str = Field(..., description="Mobile phone")
    user_id: Optional[str] = Field(None, description="External system user ID")
    status: int = Field(..., description="User status")
    locked: int = Field(..., description="User lock status")
    created_at: datetime = Field(..., description="Creation time")
    updated_at: datetime = Field(..., description="Update time")
    last_login: Optional[datetime] = Field(None, description="Last login time")
    roles: List[RoleInfo] = Field(default_factory=list, description="User role list")


class LoginRequest(BaseModel):
    """Login request body"""

    email: str = Field(..., description="Email")
    password: str = Field(..., min_length=6, max_length=128, description="Password")


class TokenResponse(BaseModel):
    """JWT token response"""

    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field(default="bearer", description="Token type")
    expires_in: int = Field(..., description="Expiration in seconds")


class UserSearchParams(BaseModel):
    """User search parameters"""

    name: Optional[str] = Field(None, description="Username search")
    en_name: Optional[str] = Field(None, description="English name search")
    email: Optional[str] = Field(None, description="Email search")
    mobile: Optional[str] = Field(None, description="Mobile phone search")
    user_id: Optional[str] = Field(None, description="External ID search")
    status: Optional[int] = Field(None, description="Status filter")
    locked: Optional[int] = Field(None, description="Lock status filter")
