"""
Permission Dependencies

This module provides dependency injection functions for permission-based access control.

Setup Instructions:
    1. Initialize RBAC configuration with your database session dependency:
       ```python
       from fastapi_rbac.config import init_rbac_config

       # Initialize with your session dependency
       init_rbac_config(
           db_session_deps=get_db_session,  # Your session dependency function
           enable_soft_delete=True,
           cache_ttl=300,
       )
       ```

    2. Use permission dependencies in your routes:
       ```python
       from fastapi_rbac.dependencies.permission_dependencies import require_permissions

       @app.get("/protected-endpoint")
       async def protected_route(
           _: bool = Depends(require_permissions("user:read", "user:write"))
       ):
           return {"message": "Access granted"}
       ```

The permission dependency will automatically:
    - Get the database session from your configured dependency
    - Check user authentication via RBAC middleware
    - Validate user permissions against the database
    - Return True if user has required permissions, raise HTTPException otherwise
"""

from typing import Callable
from fastapi import Depends, HTTPException, Request
from sqlmodel.ext.asyncio.session import AsyncSession


def require_permissions(*permission_codes: str) -> Callable:
    """
    Create a dependency that requires the user to have any of the specified permissions

    Args:
        *permission_codes: Permission codes that allow access (OR logic)

    Returns:
        A FastAPI dependency function

    Usage:
        @app.get("/protected-endpoint")
        async def protected_route(_: bool = Depends(require_permissions("user:read", "user:write"))):
            return {"message": "Access granted"}
    """
    from ..config import get_rbac_config

    rbac_config = get_rbac_config()

    async def permission_dependency(
        request: Request,
        db_session: AsyncSession = Depends(rbac_config.custom_session_maker),
    ) -> bool:
        """
        Check if the current user has any of the required permissions

        Args:
            request: FastAPI request object
            db_session: Database session

        Returns:
            True if user has permissions

        Raises:
            HTTPException: 401 if not authenticated, 403 if insufficient permissions, 500 for configuration errors
        """
        try:
            # Validate permission codes
            if not permission_codes:
                raise HTTPException(
                    status_code=500,
                    detail={
                        "error": "configuration_error",
                        "message": "No permission codes specified for this endpoint",
                        "endpoint": str(request.url.path),
                    },
                )

            # Validate permission codes format
            for code in permission_codes:
                if not isinstance(code, str) or not code.strip():
                    raise HTTPException(
                        status_code=500,
                        detail={
                            "error": "configuration_error",
                            "message": f"Invalid permission code format: {code}",
                            "endpoint": str(request.url.path),
                        },
                    )

            # Get the RBAC middleware instance
            rbac_middleware = getattr(request.app.state, "rbac_middleware", None)

            if not rbac_middleware:
                # For non-RBAC endpoints, require proper middleware configuration
                raise HTTPException(
                    status_code=500,
                    detail={
                        "error": "configuration_error",
                        "message": "RBAC middleware not configured properly. Please ensure app.state.rbac_middleware is set during application startup.",
                        "endpoint": str(request.url.path),
                    },
                )

            # Get current user ID for better error messages
            user_id = await rbac_middleware.get_current_user_id(request)
            if not user_id:
                raise HTTPException(
                    status_code=401,
                    detail={
                        "error": "authentication_required",
                        "message": "User authentication required. Please provide valid authentication credentials.",
                        "endpoint": str(request.url.path),
                    },
                )

            # Check user permissions
            has_permission = await rbac_middleware.check_user_permissions(
                request, list(permission_codes), db_session, user_id=user_id
            )

            if not has_permission:
                raise HTTPException(
                    status_code=403,
                    detail={
                        "error": "insufficient_permissions",
                        "message": "Access denied. User does not have required permissions.",
                        "required_permissions": list(permission_codes),
                        "permission_logic": "OR (any one of the required permissions)",
                        "endpoint": str(request.url.path),
                        "user_id": user_id,
                    },
                )

            return True

        except HTTPException:
            # Re-raise HTTP exceptions as-is
            raise
        except Exception as e:
            # Handle unexpected errors
            raise HTTPException(
                status_code=500,
                detail={
                    "error": "internal_server_error",
                    "message": "An unexpected error occurred during permission checking",
                    "endpoint": str(request.url.path),
                    "details": str(e),
                },
            )

    return permission_dependency
