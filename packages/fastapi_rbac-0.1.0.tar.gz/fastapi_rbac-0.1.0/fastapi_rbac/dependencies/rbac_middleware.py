"""
RBAC Middleware

This module provides middleware functionality for role-based and permission-based access control.
"""

from typing import Optional, List, Any, Dict
from datetime import datetime, timedelta, timezone
import jwt
from fastapi import Request
from sqlmodel import select, SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession
from ..config import get_rbac_config


class BaseRBACMiddleware:
    def __init__(self, rbac_plugin):
        self.rbac_plugin = rbac_plugin

    async def get_current_user_id(self, request: Request) -> Optional[int]:
        pass

    async def check_permission(
        self, request: Request, required_roles: List[str], db_session: AsyncSession
    ) -> bool:
        """
        Check user permissions based on roles

        Args:
            request: FastAPI request object
            required_roles: List of required role names
            db_session: Database session

        Returns:
            True if user has any of the required roles
        """
        user_id = await self.get_current_user_id(request)
        if not user_id:
            return False

        # Get user roles
        user_serializer = self.rbac_plugin.get_user_serializer(db_session)
        user_roles = await user_serializer.get_user_roles(user_id)

        # Check if user has any of the required roles
        user_role_names = {role.name for role in user_roles}
        return any(role in user_role_names for role in required_roles)

    async def check_user_permissions(
        self,
        request: Request,
        required_permissions: List[str],
        db_session: AsyncSession,
        user_id: Optional[int] = None,
    ) -> bool:
        """
        Check user permissions based on permission codes

        Args:
            request: FastAPI request object
            required_permissions: List of required permission codes
            db_session: Database session

        Returns:
            True if user has any of the required permissions
        """
        if user_id is None:
            user_id = await self.get_current_user_id(request)
        if not user_id:
            return False

        # Get user permissions
        user_serializer = self.rbac_plugin.get_user_serializer(db_session)
        user_permissions = await user_serializer.get_user_permissions(user_id)

        config = get_rbac_config()
        admin_permission_code = config.admin_permission_code

        if admin_permission_code in user_permissions:
            return True

        # Check if user has any of the required permissions (OR logic)
        user_permission_codes = set(user_permissions)
        return any(
            permission in user_permission_codes for permission in required_permissions
        )


class RBACMiddleware(BaseRBACMiddleware):
    """
    RBAC Middleware for handling authentication and authorization

    Supports both role-based and permission-based access control.
    """

    def __init__(self, rbac_plugin):
        """
        Initialize RBAC middleware

        Args:
            rbac_plugin: The RBACPlugin instance
        """
        self.rbac_plugin = rbac_plugin

    async def get_current_user_id(self, request: Request) -> Optional[int]:
        """
        Get current user ID from JWT in Authorization header or cookie.

        Header: `Authorization: Bearer <token>`
        Cookie: `rbac_token=<token>`
        """
        token: Optional[str] = None
        # auth_header = request.headers.get("Authorization")
        # if auth_header and auth_header.startswith("Bearer "):
        #     token = auth_header.split(" ", 1)[1].strip()
        if not token:
            # Fallback to cookie for navigation/page requests
            token = request.cookies.get("rbac_token")
        if not token:
            return None

        config = get_rbac_config()
        try:
            payload = jwt.decode(
                token,
                key=config.jwt_secret,
                algorithms=[config.jwt_algorithm],
                options={"verify_aud": False},
            )
        except Exception:
            return None

        user_id = payload.get("sub") or payload.get("user_id")
        if user_id is None:
            return None
        try:
            request.state.user_id = int(user_id)
            return int(user_id)
        except (TypeError, ValueError):
            return None

    async def get_current_user_ins_with_external_auth(
        self, request: Request, db_session: AsyncSession
    ) -> Optional[SQLModel]:
        """
        Get current user ID from external authentication headers.
        """
        from ..models import get_user_model

        auth_type = request.state.auth_type
        client_cls = self.rbac_plugin.config.get_external_auth_client(auth_type)
        if not client_cls:
            return None

        client = client_cls(self.rbac_plugin.config)

        UserModel = get_user_model()
        user_info = await client.get_user_info(request, db_session)

        user_stmt = await db_session.exec(
            select(UserModel).where(UserModel.email == user_info.email)
        )
        user = user_stmt.first()
        if user:
            # TODO: update user info
            return user
        else:
            db_session.add(user_info)
            await db_session.commit()
            await db_session.refresh(user_info)
        return user_info

    def create_access_token(
        self, *, subject: int, extra_claims: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create a signed JWT access token."""
        config = get_rbac_config()
        expire_delta = timedelta(minutes=config.access_token_expire_minutes)
        now = datetime.now(timezone.utc)
        payload: Dict[str, Any] = {
            "sub": str(subject),
            "iat": int(now.timestamp()),
            "exp": int((now + expire_delta).timestamp()),
            "type": "access",
        }
        if extra_claims:
            payload.update(extra_claims)
        token = jwt.encode(
            payload, key=config.jwt_secret, algorithm=config.jwt_algorithm
        )
        # pyjwt may return str or bytes depending on version; ensure str
        if isinstance(token, bytes):
            token = token.decode("utf-8")
        return token
