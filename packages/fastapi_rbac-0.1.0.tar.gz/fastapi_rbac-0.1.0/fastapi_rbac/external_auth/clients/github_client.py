#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-01-27 10:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: GitHub OAuth Client Implementation
All Rights Reserved.
"""

import os
import httpx
from typing import Dict, Any, Optional
from fastapi import Request
from sqlmodel.ext.asyncio.session import AsyncSession
from ..base_client import BaseExternalAuthClient
from ...config import RBACConfig
from ...models.github_user_model import GitHubUserModel
from loguru import logger


class GitHubOAuthClient(BaseExternalAuthClient):
    """
    GitHub OAuth Authentication Client

    Implements GitHub OAuth 2.0 authentication flow, including:
    1. Get user authorization code
    2. Exchange access token
    3. Get user information
    4. Validate token validity
    """

    def __init__(self, config: RBACConfig):
        super().__init__(config)

        # GitHub OAuth configuration
        self.client_id = os.environ.get("GITHUB_CLIENT_ID")
        self.client_secret = os.environ.get("GITHUB_CLIENT_SECRET")
        self.redirect_uri = os.environ.get("GITHUB_REDIRECT_URI")
        self.scope = "user:email"

        # GitHub API endpoints
        self.authorize_url = "https://github.com/login/oauth/authorize"
        self.token_url = "https://github.com/login/oauth/access_token"
        self.user_info_url = "https://api.github.com/user"
        self.user_emails_url = "https://api.github.com/user/emails"

        # HTTP client
        self.client = httpx.AsyncClient(
            headers={
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "FastAPI-RBAC-GitHub-OAuth",
            }
        )

    def _validate_config(self) -> None:
        """
        Validate GitHub OAuth configuration
        """
        pass

    async def get_user_info(
        self, request: Request, db_session: AsyncSession
    ) -> GitHubUserModel:
        """
        Get user information from GitHub

        Args:
            request: FastAPI request object
            db_session: Database session

        Returns:
            GitHubUserModel: GitHub user model object
        """
        # Get access token from request headers
        auth_token = request.state.auth_token
        if not auth_token:
            raise ValueError("Missing GitHub access token")

        # Get GitHub user information
        user_data = await self._fetch_github_user_info(auth_token)

        # Convert to GitHubUserModel
        github_user = GitHubUserModel(
            email=user_data.get("email", ""),
            name=user_data.get("name", user_data.get("login", "")),
            en_name=user_data.get("login", ""),
            mobile="",  # GitHub does not provide mobile number
            user_id=str(user_data.get("id", "")),
            github_id=user_data.get("id"),
            github_login=user_data.get("login"),
            github_avatar_url=user_data.get("avatar_url"),
            github_html_url=user_data.get("html_url"),
            github_public_repos=user_data.get("public_repos", 0),
            github_followers=user_data.get("followers", 0),
            github_following=user_data.get("following", 0),
            status=1,  # Active status
            locked=0,  # Unlocked
        )

        return github_user

    async def validate_token(self, auth_token: str) -> bool:
        """
        Validate GitHub access token

        Args:
            auth_token: GitHub access token

        Returns:
            bool: Whether the token is valid
        """
        try:
            response = await self.client.get(
                self.user_info_url, headers={"Authorization": f"token {auth_token}"}
            )

            if response.status_code == 200:
                logger.info("GitHub token validation successful")
                return True
            else:
                logger.warning(
                    f"GitHub token validation failed: {response.status_code}"
                )
                return False

        except Exception as e:
            logger.error(f"GitHub token validation exception: {str(e)}")
            return False

    def get_provider_name(self) -> str:
        """
        Get authentication provider name

        Returns:
            str: Provider name
        """
        return "github"

    async def _fetch_github_user_info(self, access_token: str) -> Dict[str, Any]:
        """
        Get user information from GitHub API

        Args:
            access_token: GitHub access token

        Returns:
            Dict[str, Any]: User information dictionary
        """
        try:
            # Get basic user information
            user_response = await self.client.get(
                self.user_info_url, headers={"Authorization": f"token {access_token}"}
            )

            if user_response.status_code != 200:
                raise Exception(
                    f"Failed to get GitHub user information: {user_response.status_code}"
                )

            user_data = user_response.json()

            # If user has no public email, try to get private email
            if not user_data.get("email"):
                emails_response = await self.client.get(
                    self.user_emails_url,
                    headers={"Authorization": f"token {access_token}"},
                )

                if emails_response.status_code == 200:
                    emails = emails_response.json()
                    # Find primary email or first email
                    primary_email = next(
                        (email["email"] for email in emails if email.get("primary")),
                        emails[0]["email"] if emails else None,
                    )
                    if primary_email:
                        user_data["email"] = primary_email

            return user_data

        except Exception as e:
            logger.error(f"Exception getting GitHub user information: {str(e)}")
            raise

    async def exchange_code_for_token(self, code: str) -> Dict[str, Any]:
        """
        Exchange authorization code for access token

        Args:
            code: GitHub authorization code

        Returns:
            Dict[str, Any]: Response containing access token
        """
        try:
            response = await self.client.post(
                self.token_url,
                data={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "code": code,
                    "redirect_uri": self.redirect_uri,
                },
                headers={"Accept": "application/json"},
            )

            if response.status_code == 200:
                token_data = response.json()
                if "access_token" in token_data:
                    logger.info("Successfully obtained GitHub access token")
                    return token_data
                else:
                    error_msg = token_data.get("error_description", "Unknown error")
                    raise Exception(f"Failed to get access token: {error_msg}")
            else:
                raise Exception(f"GitHub OAuth request failed: {response.status_code}")

        except Exception as e:
            logger.error(f"Exception exchanging GitHub access token: {str(e)}")
            raise

    def get_authorization_url(self, state: str = None) -> str:
        """
        Generate GitHub authorization URL

        Args:
            state: State parameter for CSRF protection

        Returns:
            str: Authorization URL
        """
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": self.scope,
            "response_type": "code",
        }

        if state:
            params["state"] = state

        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        return f"{self.authorize_url}?{query_string}"

    async def health_check(self) -> bool:
        """
        Check GitHub API service availability

        Returns:
            bool: Whether the service is available
        """
        try:
            response = await self.client.get("https://api.github.com/zen")
            return response.status_code == 200
        except Exception:
            return False
