"""
External Authentication Clients

This module contains example implementations of external authentication clients
for various third-party authentication systems.
"""
