#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:39:08
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""


from typing import AsyncGenerator, Callable, Optional, Any, Type, Dict
from fastapi import FastAPI
from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker, create_async_engine
from sqlmodel.ext.asyncio.session import AsyncSession
from loguru import logger

from .serializers.base_user_serializer import BaseUserSerializer
from .external_auth.base_client import BaseExternalAuthClient


class RBACConfig(BaseSettings):
    """
    RBAC Plugin Configuration Class

    Support configuration through environment variables or configuration files.
    """

    model_config = SettingsConfigDict(
        env_prefix="RBAC_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="allow",
    )

    # Database configuration
    # database_url: str = Field(
    #     description="Database connection URL",
    # )
    # database_params: dict[str, Any] = Field(
    #     default={},
    #     description="Database connection parameters",
    # )

    user_serializer: Type[BaseUserSerializer] = Field(
        description="User serializer class",
    )

    admin_permission_code: str = Field(
        default="admin:full_access",
        description="Admin permission code",
    )

    # [NOT IMPLEMENTED]
    # enable_soft_delete: bool = Field(default=True, description="Enable soft delete")

    # [NOT IMPLEMENTED]
    # Cache configuration
    cache_ttl: int = Field(default=3600, description="Cache expiration time (seconds)")

    enable_cache: bool = Field(default=False, description="Enable cache")

    # Role configuration
    default_user_role: Optional[str] = Field(
        default="User", description="Default user role name"
    )

    system_roles: list[str] = Field(
        default=["Super Admin", "Admin", "User"],
        description="System built-in role list",
    )

    # Logging configuration
    log_level: str = Field(default="INFO", description="Log level")

    # [NOT IMPLEMENTED] Keep operation history to a specific table
    enable_audit_log: bool = Field(default=True, description="Enable audit log")

    # JWT settings
    jwt_secret: str = Field(
        default="change-this-secret", description="JWT secret key for token signing"
    )
    jwt_algorithm: str = Field(default="HS256", description="JWT algorithm")
    access_token_expire_minutes: int = Field(
        default=60 * 24,
        ge=1,
        le=60 * 24 * 14,
        description="Access token expiration minutes (default 24h)",
    )

    # External authentication settings
    external_auth_clients: Dict[str, Type[BaseExternalAuthClient]] = Field(
        default={}, description="External authentication clients registry"
    )
    enable_external_auth: bool = Field(
        default=False, description="Enable external authentication support"
    )

    need_frontend: bool = Field(default=False, description="Enable frontend support")

    # Route prefix configuration
    api_prefix: str = Field(default="/api/rbac", description="API routes prefix")
    frontend_prefix: str = Field(
        default="/api/rbac-frontend/admin", description="Frontend routes prefix"
    )

    custom_session_maker: Callable[[], AsyncSession] = Field(
        description="Custom session maker"
    )

    @field_validator("user_serializer")
    @classmethod
    def validate_user_serializer(
        cls, v: Type[BaseUserSerializer]
    ) -> Type[BaseUserSerializer]:
        """validate BaseUserSerializer"""
        if not issubclass(v, BaseUserSerializer):
            raise ValueError(
                f"user_serializer '{v.__name__}' must inherit from BaseUserSerializer"
            )
        return v

    @field_validator("external_auth_clients")
    @classmethod
    def validate_external_auth_clients(
        cls, v: Dict[str, Type[BaseExternalAuthClient]]
    ) -> Dict[str, Type[BaseExternalAuthClient]]:
        """Validate external authentication clients"""
        for auth_type, client_class in v.items():
            if not issubclass(client_class, BaseExternalAuthClient):
                raise ValueError(
                    f"External auth client '{client_class.__name__}' must inherit from BaseExternalAuthClient"
                )
        return v

    @model_validator(mode="after")
    def validate_config(self) -> "RBACConfig":
        """validate config"""
        # validate default_user_role is in system_roles
        if self.default_user_role is not None:
            if self.default_user_role not in self.system_roles:
                raise ValueError(
                    f"default_user_role '{self.default_user_role}' is not in system_roles: {self.system_roles}"
                )
        return self

    def register_external_auth_client(
        self, auth_type: str, client_class: Type[BaseExternalAuthClient]
    ) -> None:
        """
        Register an external authentication client

        Args:
            auth_type: Authentication type identifier (e.g., "google", "microsoft")
            client_class: External authentication client class
        """
        if not issubclass(client_class, BaseExternalAuthClient):
            raise ValueError(
                f"Client class '{client_class.__name__}' must inherit from BaseExternalAuthClient"
            )

        self.external_auth_clients[auth_type] = client_class
        self.enable_external_auth = True

    def get_external_auth_client(
        self, auth_type: str
    ) -> Optional[Type[BaseExternalAuthClient]]:
        """
        Get external authentication client class by type

        Args:
            auth_type: Authentication type identifier

        Returns:
            External authentication client class or None if not found
        """
        return self.external_auth_clients.get(auth_type)


# Global configuration instance
_global_config: Optional[RBACConfig] = None
_database_url: Optional[str] = None
_database_params: Optional[dict[str, Any]] = None
_rbac_async_engine: Optional[AsyncEngine] = None
_rbac_async_session: Optional[async_sessionmaker[AsyncSession]] = None


def register_rbac_config(app: FastAPI, rbac_config: RBACConfig):
    """
    Register RBAC configuration
    """
    from .exceptions import register_exception_handlers

    global _global_config
    _global_config = rbac_config
    register_exception_handlers(app)


def get_rbac_config() -> RBACConfig:
    """
    Get RBAC configuration instance

    If global configuration is not initialized, returns default configuration.

    Returns:
        RBAC configuration instance
    """
    if _global_config is None:
        raise RuntimeError(
            "RBAC configuration is not initialized, please register RBACPlugin before define routes."
        )
    # assert _global_config is not None

    return _global_config


def set_rbac_db_config(database_url: str, database_params: dict[str, Any]):
    """
    Set RBAC database configuration
    ATTENTION:
        This function is only used for testing, do not use it in production environment.
    """
    global _database_url
    global _database_params
    _database_url = database_url
    _database_params = database_params


def create_async_session():
    try:
        global _rbac_async_engine

        if _rbac_async_engine is None:
            _rbac_async_engine = create_async_engine(
                _database_url,
                **_database_params,  # type: ignore
            )
        global _rbac_async_session
        if _rbac_async_session is None:
            _rbac_async_session = async_sessionmaker(
                _rbac_async_engine,
                class_=AsyncSession,
                expire_on_commit=False,
                close_resets_only=False,
            )
    except Exception as e:
        logger.error(f"Failed to create database session: {e}")
        raise RuntimeError(f"Failed to create database session: {e}") from e


def get_rbac_async_session() -> async_sessionmaker[AsyncSession]:
    create_async_session()
    assert _rbac_async_session is not None
    return _rbac_async_session


async def gen_rbac_async_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Generate a database session

    ATTENTION:
        This function is only used for testing, do not use it in production environment.
    """
    async_session = get_rbac_async_session()
    async with async_session() as session:
        logger.debug(f"Successfully created database session: {session}")
        # try:
        #     pool = session.get_bind().pool  # type: ignore
        #     logger.debug(
        #         f"Connection pool status - current connection count: {pool.checkedout()}, total connection count: {pool.size()}"  # type: ignore
        #     )
        # except Exception as pool_check_error:
        #     logger.warning(f"Failed to get connection pool status: {pool_check_error}")

        yield session
