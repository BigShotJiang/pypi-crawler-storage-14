#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Frontend Router for RBAC Management System
Provides API endpoints for frontend dashboard statistics
"""

from typing import Callable, Dict, Any, List
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel.ext.asyncio.session import AsyncSession
import logging

from typing import Optional
from pathlib import Path
from fastapi import Request, Query
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

from ..serializers import UserSerializer, RoleSerializer, PermissionSerializer
from ..serializers.frontend_serializer import FrontendSerializer
from ..schemas.permission_schemas import RolePermissionAssignment
from ..schemas import (
    UserSearchParams,
    RoleSearchParams,
    PermissionSearchParams,
    PaginationParams,
)
from ..serializers.exceptions import DatabaseError
from ..serializers.messages import get_router_error


def create_frontend_router(
    get_db_session: Callable, api_prefix: str = "/rbac", frontend_prefix: str = "/admin"
) -> APIRouter:
    """
    Create frontend router for dashboard statistics

    Args:
        get_db_session: Database session dependency function
        api_prefix: API routes prefix for backend calls
        frontend_prefix: Frontend routes prefix

    Returns:
        Configured frontend router
    """
    # Setup paths
    frontend_dir = Path(__file__).parent.parent / "frontend"
    templates_dir = frontend_dir / "templates"
    # static_dir = frontend_dir / "static"

    # Initialize Jinja2 templates
    templates = Jinja2Templates(directory=str(templates_dir))
    # Expose common Python builtins to Jinja to support templates using max/min/range
    templates.env.globals.update(
        {
            "max": max,
            "min": min,
            "range": range,
            "api_prefix": api_prefix,
            "frontend_prefix": frontend_prefix,
        }
    )

    # Logger for this router
    logger = logging.getLogger("fastapi_rbac.frontend_router")

    # Create routers
    router = APIRouter(prefix=frontend_prefix, tags=["RBAC Admin Interface"])
    public_router = APIRouter(tags=["Public Pages"])  # no prefix for root-level pages

    # Static files are now mounted at app level, so no need to mount here

    @public_router.get("/login.html", response_class=HTMLResponse, summary="Login Page")
    async def login_page(request: Request):
        """Render login page"""
        return templates.TemplateResponse(
            "login.html",
            {
                "request": request,
                "title": "Login",
            },
        )

    from ..dependencies.permission_dependencies import require_permissions

    @router.get("/", response_class=HTMLResponse, summary="Dashboard")
    async def dashboard(
        request: Request,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:dashboard")),
    ):
        """Main dashboard page with statistics"""
        try:
            # Get dashboard statistics
            frontend_serializer = FrontendSerializer(db_session)
            stats = await frontend_serializer.get_dashboard_stats()

            return templates.TemplateResponse(
                "dashboard/index.html",
                {
                    "request": request,
                    "title": "RBAC Management Dashboard",
                    "stats": stats,
                },
            )
        except Exception:
            # If stats fail, log and render dashboard without stats
            logger.exception("Failed to load dashboard stats")
            return templates.TemplateResponse(
                "dashboard/index.html",
                {
                    "request": request,
                    "title": "RBAC Management Dashboard",
                    "stats": {
                        "total_users": 0,
                        "total_roles": 0,
                        "total_permissions": 0,
                    },
                },
            )

    # User Management Routes
    @router.get("/users", response_class=HTMLResponse, summary="User List")
    async def users_list(
        request: Request,
        page: int = Query(1, ge=1),
        size: int = Query(20, ge=1, le=100),
        search: Optional[str] = Query(None),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:users")),
    ):
        """User list page with search and pagination"""
        try:
            # Build pagination and search parameters
            pagination = PaginationParams(page=page, size=size)
            search_params = (
                UserSearchParams(
                    name=search,
                    en_name=None,
                    email=search,
                    mobile=None,
                    user_id=None,
                    status=None,
                    locked=None,
                )
                if search
                else UserSearchParams(
                    name=None,
                    en_name=None,
                    email=None,
                    mobile=None,
                    user_id=None,
                    status=None,
                    locked=None,
                )
            )

            # Get users from API
            user_serializer = UserSerializer(db_session)
            result = await user_serializer.get_users(
                pagination=pagination, search_params=search_params, include_roles=False
            )

            return templates.TemplateResponse(
                "users/list.html",
                {
                    "request": request,
                    "title": "User Management",
                    "users": result.items,
                    "pagination": {
                        "page": result.page,
                        "size": result.size,
                        "total": result.total,
                        "pages": result.pages,
                    },
                    "search": search or "",
                },
            )
        except Exception as e:
            logger.exception("Failed to load users")
            raise HTTPException(
                status_code=500, detail=f"Failed to load users: {str(e)}"
            )

    @router.get("/users/{user_id}", response_class=HTMLResponse, summary="User Detail")
    async def user_detail(
        request: Request,
        user_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:users")),
    ):
        """User detail page"""
        try:
            user_serializer = UserSerializer(db_session)
            user = await user_serializer.get_user(user_id, include_roles=True)

            if not user:
                raise HTTPException(status_code=404, detail="User not found")

            # Get user roles
            roles = await user_serializer.get_user_roles(user_id)

            return templates.TemplateResponse(
                "users/detail.html",
                {
                    "request": request,
                    "title": f"User: {user.name}",
                    "user": user,
                    "roles": roles,
                },
            )
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Failed to load user detail: id=%s", user_id)
            raise HTTPException(
                status_code=500, detail=f"Failed to load user: {str(e)}"
            )

    # Role Management Routes
    @router.get("/roles", response_class=HTMLResponse, summary="Role List")
    async def roles_list(
        request: Request,
        page: int = Query(1, ge=1),
        size: int = Query(20, ge=1, le=100),
        search: Optional[str] = Query(None),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:roles")),
    ):
        """Role list page with search and pagination"""
        try:
            # Build pagination and search parameters
            pagination = PaginationParams(page=page, size=size)
            search_params = (
                RoleSearchParams(
                    name=search,
                    description=search,
                    is_active=None,
                    is_system=None,
                    created_after=None,
                    created_before=None,
                )
                if search
                else RoleSearchParams(
                    name=None,
                    description=None,
                    is_active=None,
                    is_system=None,
                    created_after=None,
                    created_before=None,
                )
            )

            # Get roles from API
            role_serializer = RoleSerializer(db_session)
            result = await role_serializer.get_roles(
                pagination=pagination, search_params=search_params
            )

            # Second round: fetch related user count for each role
            role_user_counts = {}
            for role in result.items:
                role_user_counts[role.id] = await role_serializer.get_role_user_count(
                    role.id
                )

            return templates.TemplateResponse(
                "roles/list.html",
                {
                    "request": request,
                    "title": "Role Management",
                    "roles": result.items,
                    "role_user_counts": role_user_counts,
                    "pagination": {
                        "page": result.page,
                        "size": result.size,
                        "total": result.total,
                        "pages": result.pages,
                    },
                    "search": search or "",
                },
            )
        except Exception as e:
            logger.exception("Failed to load roles")
            raise HTTPException(
                status_code=500, detail=f"Failed to load roles: {str(e)}"
            )

    @router.get("/roles/{role_id}", response_class=HTMLResponse, summary="Role Detail")
    async def role_detail(
        request: Request,
        role_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:roles")),
    ):
        """Role detail page"""
        try:
            role_serializer = RoleSerializer(db_session)
            role = await role_serializer.get_role(role_id, include_users=True)

            if not role:
                raise HTTPException(status_code=404, detail="Role not found")

            # Get role users
            users = await role_serializer.get_role_users(role_id)

            return templates.TemplateResponse(
                "roles/detail.html",
                {
                    "request": request,
                    "title": f"Role: {role.name}",
                    "role": role,
                    "users": users,
                },
            )
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Failed to load role detail: id=%s", role_id)
            raise HTTPException(
                status_code=500, detail=f"Failed to load role: {str(e)}"
            )

    # Permission Management Routes
    @router.get("/permissions", response_class=HTMLResponse, summary="Permission List")
    async def permissions_list(
        request: Request,
        page: int = Query(1, ge=1),
        size: int = Query(20, ge=1, le=100),
        search: Optional[str] = Query(None),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:permissions")),
    ):
        """Permission list page with search and pagination"""
        try:
            # Build pagination and search parameters
            pagination = PaginationParams(page=page, size=size)
            search_params = (
                PermissionSearchParams(
                    code=search,
                    name=search,
                    description=search,
                    resource=None,
                    action=None,
                    permission_type=None,
                    is_active=None,
                    is_system=None,
                    created_after=None,
                    created_before=None,
                )
                if search
                else PermissionSearchParams(
                    code=None,
                    name=None,
                    description=None,
                    resource=None,
                    action=None,
                    permission_type=None,
                    is_active=None,
                    is_system=None,
                    created_after=None,
                    created_before=None,
                )
            )

            # Get permissions from API
            permission_serializer = PermissionSerializer(db_session)
            result = await permission_serializer.get_permissions(
                pagination=pagination, search_params=search_params
            )

            # Second round: fetch related role count for each permission
            permission_role_counts = {}
            for permission in result.items:
                permission_role_counts[permission.id] = (
                    await permission_serializer.get_permission_role_count(permission.id)
                )

            return templates.TemplateResponse(
                "permissions/list.html",
                {
                    "request": request,
                    "title": "Permission Management",
                    "permissions": result.items,
                    "permission_role_counts": permission_role_counts,
                    "pagination": {
                        "page": result.page,
                        "size": result.size,
                        "total": result.total,
                        "pages": result.pages,
                    },
                    "search": search or "",
                },
            )
        except Exception as e:
            logger.exception("Failed to load permissions")
            raise HTTPException(
                status_code=500, detail=f"Failed to load permissions: {str(e)}"
            )

    @router.get(
        "/permissions/{permission_id}",
        response_class=HTMLResponse,
        summary="Permission Detail",
    )
    async def permission_detail(
        request: Request,
        permission_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:permissions")),
    ):
        """Permission detail page"""
        try:
            permission_serializer = PermissionSerializer(db_session)
            permission = await permission_serializer.get_permission(
                permission_id, include_roles=True
            )

            if not permission:
                raise HTTPException(status_code=404, detail="Permission not found")

            # Get permission roles
            roles = await permission_serializer.get_permission_roles(permission_id)

            return templates.TemplateResponse(
                "permissions/detail.html",
                {
                    "request": request,
                    "title": f"Permission: {permission.name}",
                    "permission": permission,
                    "roles": roles,
                },
            )
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Failed to load permission detail: id=%s", permission_id)
            raise HTTPException(
                status_code=500, detail=f"Failed to load permission: {str(e)}"
            )

    @router.get(
        "/stats",
        response_model=Dict[str, Any],
        summary="Get dashboard statistics",
        description="Get comprehensive dashboard statistics including user, role, and permission counts",
    )
    async def get_dashboard_stats(
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:dashboard")),
    ):
        """Get dashboard statistics"""
        try:
            frontend_serializer = FrontendSerializer(db_session)
            stats = await frontend_serializer.get_dashboard_stats()

            return stats

        except DatabaseError as e:
            logger.exception("DatabaseError in get_dashboard_stats")
            raise HTTPException(
                status_code=500,
                detail=f"{get_router_error('DATABASE_QUERY_FAILED')}: {e.message}",
            )
        except Exception as e:
            logger.exception("Unexpected error in get_dashboard_stats")
            raise HTTPException(
                status_code=500,
                detail=f"{get_router_error('SERVER_INTERNAL_ERROR')}: {str(e)}",
            )

    # Permission Role Management API Routes
    @router.get(
        "/permissions/{permission_id}/manage-roles",
        response_model=Dict[str, Any],
        summary="Get permission role management data",
        description="Get all roles and current permission roles for management interface",
    )
    async def get_permission_role_management_data(
        permission_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:permissions")),
    ):
        """Get permission role management data"""
        try:
            permission_serializer = PermissionSerializer(db_session)
            role_serializer = RoleSerializer(db_session)

            # Get current permission roles
            current_roles = await permission_serializer.get_permission_roles(
                permission_id
            )
            current_role_ids = {role.id for role in current_roles}

            # Get all available roles
            all_roles = await role_serializer.get_all_roles()

            return {
                "permission_id": permission_id,
                "all_roles": [
                    {
                        "id": role.id,
                        "name": role.name,
                        "description": role.description,
                        "is_system": role.is_system,
                        "is_assigned": role.id in current_role_ids,
                    }
                    for role in all_roles
                ],
                "current_role_count": len(current_roles),
            }

        except Exception as e:
            logger.exception(f"Failed to get permission role management data: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to get permission role management data: {str(e)}",
            )

    @router.post(
        "/permissions/{permission_id}/assign-roles",
        response_model=Dict[str, Any],
        summary="Assign roles to permission",
        description="Assign multiple roles to a permission",
    )
    async def assign_roles_to_permission(
        permission_id: int,
        role_ids: List[int],
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:assign_roles")),
    ):
        """Assign roles to permission"""
        try:
            permission_serializer = PermissionSerializer(db_session)

            assignment_data = RolePermissionAssignment(
                role_ids=role_ids, assigned_by=None, expires_at=None
            )
            relations = await permission_serializer.assign_roles(
                permission_id, assignment_data
            )

            return {
                "message": f"Successfully assigned {len(relations)} roles",
                "assigned_count": len(relations),
                "role_ids": [rel.role_id for rel in relations],
            }

        except Exception as e:
            logger.exception(f"Failed to assign roles to permission: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to assign roles: {str(e)}",
            )

    @router.delete(
        "/permissions/{permission_id}/remove-role/{role_id}",
        status_code=200,
        response_model=Dict[str, Any],
        summary="Remove role from permission",
        description="Remove a role from a permission",
    )
    async def remove_role_from_permission(
        permission_id: int,
        role_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("permission:assign_roles")),
    ):
        """Remove role from permission"""
        try:
            permission_serializer = PermissionSerializer(db_session)
            success = await permission_serializer.remove_role(permission_id, role_id)

            if not success:
                raise HTTPException(
                    status_code=500,
                    detail="Failed to remove role from permission",
                )

            return {
                "message": "Successfully removed role from permission",
                "permission_id": permission_id,
                "role_id": role_id,
            }

        except Exception as e:
            logger.exception(f"Failed to remove role from permission: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to remove role: {str(e)}",
            )

    # Aggregate routers
    main_router = APIRouter()
    main_router.include_router(public_router)
    main_router.include_router(router)

    return main_router


__all__ = ["create_frontend_router"]
