#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-28 10:24:23
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

from typing import List, Optional, Callable
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel.ext.asyncio.session import AsyncSession

from ..schemas import (
    RoleCreate,
    RoleUpdate,
    RoleResponse,
    UserInfo,
    RoleSearchParams,
    UserRoleAssignment,
    PaginationParams,
    PaginatedResponse,
    ErrorResponse,
    PermissionResponse,
    PermissionRoleAssignment,
)
from ..serializers import RoleSerializer
from ..dependencies.permission_dependencies import require_permissions


def create_role_router(get_db_session: Callable) -> APIRouter:
    """
    create role router

    Args:
        get_db_session: database session dependency function

    Returns:
        configured role router
    """
    router = APIRouter(prefix="/roles", tags=["role management"])

    @router.get(
        "",
        response_model=PaginatedResponse[RoleResponse],
        summary="get role list",
        description="paginated query role list, support multiple search conditions",
    )
    async def get_roles(
        page: int = Query(1, ge=1, description="page number"),
        size: int = Query(20, ge=1, le=100, description="page size"),
        name: Optional[str] = Query(None, description="role name search"),
        description: Optional[str] = Query(None, description="role description search"),
        is_active: Optional[bool] = Query(None, description="active status filter"),
        is_system: Optional[bool] = Query(None, description="system role filter"),
        include_users: bool = Query(
            False, description="whether to include user information"
        ),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:roles")),
    ):
        """get role list"""
        # build pagination parameters
        pagination = PaginationParams(page=page, size=size)

        # build search parameters
        search_params = RoleSearchParams(
            name=name,
            description=description,
            is_active=is_active,
            is_system=is_system,
            created_after=None,
            created_before=None,
        )

        # query role list
        role_serializer = RoleSerializer(db_session)
        result = await role_serializer.get_roles(
            pagination=pagination,
            search_params=search_params,
        )

        return result

    @router.post(
        "",
        response_model=RoleResponse,
        status_code=status.HTTP_201_CREATED,
        summary="create role",
        description="create new role",
    )
    async def create_role(
        role_data: RoleCreate,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:create")),
    ):
        """create role"""
        role_serializer = RoleSerializer(db_session)
        role = await role_serializer.create_role(role_data)

        return role

    @router.get(
        "/{role_id}",
        response_model=RoleResponse,
        summary="get role detail",
        description="get single role detail by role id",
    )
    async def get_role(
        role_id: int,
        include_users: bool = Query(
            False, description="whether to include user information"
        ),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:roles")),
    ):
        """get single role detail"""
        role_serializer = RoleSerializer(db_session)
        role = await role_serializer.get_role(role_id, include_users=include_users)

        if not role:
            raise HTTPException(
                status_code=404,
                detail=f"Role with ID {role_id} not found",
            )

        return role

    @router.put(
        "/{role_id}",
        response_model=RoleResponse,
        summary="update role",
        description="update role information",
    )
    async def update_role(
        role_id: int,
        role_data: RoleUpdate,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:edit")),
    ):
        """update role"""
        role_serializer = RoleSerializer(db_session)
        role = await role_serializer.update_role(role_id, role_data)

        return role

    @router.delete(
        "/{role_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="delete role",
        description="delete specified role",
    )
    async def delete_role(
        role_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:delete")),
    ):
        """delete role"""
        role_serializer = RoleSerializer(db_session)
        success = await role_serializer.delete_role(role_id)

        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete role")

        return None

    @router.get(
        "/{role_id}/users",
        response_model=List[UserInfo],
        summary="get role user list",
        description="get all user information of specified role",
    )
    async def get_role_users(
        role_id: int, db_session: AsyncSession = Depends(get_db_session)
    ):
        """get role user list"""
        role_serializer = RoleSerializer(db_session)
        users = await role_serializer.get_role_users(role_id)

        return users

    @router.post(
        "/{role_id}/users",
        response_model=dict,
        summary="assign users to role",
        description="assign users to specified role",
    )
    async def assign_users_to_role(
        role_id: int,
        assignment_data: UserRoleAssignment,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:assign_users")),
    ):
        """assign users to role"""
        role_serializer = RoleSerializer(db_session)
        relations = await role_serializer.assign_users(role_id, assignment_data)

        return {
            "message": f"Successfully assigned {len(relations)} users",
            "assigned_count": len(relations),
            "user_ids": [rel.user_id for rel in relations],
        }

    @router.delete(
        "/{role_id}/users/{user_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="remove user from role",
        description="remove user from specified role",
    )
    async def remove_user_from_role(
        role_id: int,
        user_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:assign_users")),
    ):
        """remove user from role"""
        role_serializer = RoleSerializer(db_session)
        success = await role_serializer.remove_user(role_id, user_id)

        if not success:
            raise HTTPException(
                status_code=500, detail="Failed to remove user from role"
            )

        return None

    @router.get(
        "/{role_id}/permissions",
        response_model=List[PermissionResponse],
        summary="get role permission list",
        description="get all permission information of specified role",
    )
    async def get_role_permissions(
        role_id: int, db_session: AsyncSession = Depends(get_db_session)
    ):
        """get role permission list"""
        role_serializer = RoleSerializer(db_session)
        permissions = await role_serializer.get_role_permissions(role_id)

        return permissions

    @router.post(
        "/{role_id}/permissions",
        response_model=dict,
        summary="assign permissions to role",
        description="assign permissions to specified role",
    )
    async def assign_permissions_to_role(
        role_id: int,
        assignment_data: PermissionRoleAssignment,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:assign_permissions")),
    ):
        """assign permissions to role"""
        role_serializer = RoleSerializer(db_session)
        relations = await role_serializer.assign_permissions(role_id, assignment_data)

        return {
            "message": "Successfully assigned permissions",
            "assigned_count": len(relations),
            "permission_ids": [rel.permission_id for rel in relations],
        }

    @router.delete(
        "/{role_id}/permissions/{permission_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="remove permission from role",
        description="remove permission from specified role",
    )
    async def remove_permission_from_role(
        role_id: int,
        permission_id: int,
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("role:assign_permissions")),
    ):
        """remove permission from role"""
        role_serializer = RoleSerializer(db_session)
        success = await role_serializer.remove_permission(role_id, permission_id)

        if not success:
            raise HTTPException(
                status_code=500,
                detail="Failed to remove permission from role",
            )

        return None

    return router


# response example (for documentation generation)
responses = {
    400: {"model": ErrorResponse, "description": "request parameter error"},
    404: {"model": ErrorResponse, "description": "role not found"},
    500: {"model": ErrorResponse, "description": "server internal error"},
}
