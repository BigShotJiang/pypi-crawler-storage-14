#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:42:17
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

from typing import List, Optional, Callable, Any, cast
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status, Response
from sqlmodel.ext.asyncio.session import AsyncSession

from ..dependencies.login_dependencies import require_external_login

from ..schemas import (
    RoleInfo,
    UserSearchParams,
    PaginationParams,
    PaginatedResponse,
    ErrorResponse,
    LoginRequest,
    TokenResponse,
)
from ..models import get_user_model
from ..serializers import UserSerializer
from ..dependencies.permission_dependencies import require_permissions
from ..dependencies.rbac_middleware import RBACMiddleware
from ..config import get_rbac_config


def create_user_router(get_db_session: Callable) -> APIRouter:
    """
    Create user router

    Args:
        get_db_session: Database session dependency function

    Returns:
        Configured user router
    """
    router = APIRouter(prefix="/users", tags=["User management"])

    UserModel: Any = get_user_model()

    @router.post(
        "/register",
        response_model=TokenResponse,
        status_code=status.HTTP_201_CREATED,
        summary="User register",
        description="Public registration: create user and return JWT token",
    )
    async def register(
        user_data: UserModel,  # type: ignore[valid-type]
        db_session: AsyncSession = Depends(get_db_session),
        response: Response = None,
    ):
        """Register a new user and return an access token."""
        # Basic normalization: ensure required fields exist
        if not user_data.status:
            user_data.status = 1
        if user_data.locked is None:
            user_data.locked = 0

        # Create user
        user_serializer = UserSerializer(db_session)
        user_model = user_serializer.user_model
        try:
            user_model.model_validate(user_data)
        except Exception as e:
            raise HTTPException(status_code=422, detail=str(e))

        user = await user_serializer.create_user(user_data)

        # Issue token
        rbac_middleware: RBACMiddleware = RBACMiddleware(rbac_plugin=None)
        config = get_rbac_config()
        expires_in = config.access_token_expire_minutes * 60
        token = rbac_middleware.create_access_token(subject=int(user.id))

        # Set auth cookie for navigation requests
        if response is not None:
            response.set_cookie(
                key="rbac_token",
                value=token,
                max_age=expires_in,
                path="/",
                httponly=True,
                samesite="lax",
            )

        return TokenResponse(
            access_token=token, token_type="bearer", expires_in=expires_in
        )

    @router.post(
        "/login",
        response_model=TokenResponse,
        summary="User login",
        description="Authenticate user and return JWT token",
    )
    async def login(
        payload: LoginRequest,
        db_session: AsyncSession = Depends(get_db_session),
        response: Response = None,
    ):
        # Find user by email
        # user_serializer = UserSerializer(db_session)
        # direct private method not exposed; re-implement minimal query
        from sqlmodel import select
        from ..models import get_user_model

        User: Any = cast(Any, get_user_model())
        result = await db_session.exec(select(User).where(User.email == payload.email))
        user: Any = result.first()

        if not user or not user.password:
            raise HTTPException(status_code=400, detail="Invalid credentials")

        # Verify password
        from passlib.context import CryptContext

        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        if not pwd_context.verify(payload.password, user.password):
            raise HTTPException(status_code=400, detail="Invalid credentials")

        # Issue token
        rbac_middleware: RBACMiddleware = RBACMiddleware(
            rbac_plugin=None
        )  # no plugin needed for token create
        config = get_rbac_config()
        expires_in = config.access_token_expire_minutes * 60
        user_id_value = getattr(user, "id", None)
        token = rbac_middleware.create_access_token(subject=int(user_id_value))

        # Update last_login
        user.last_login = datetime.now(timezone.utc)
        await db_session.commit()
        await db_session.refresh(user)

        # Set auth cookie for navigation requests
        if response is not None:
            response.set_cookie(
                key="rbac_token",
                value=token,
                max_age=expires_in,
                path="/",
                httponly=True,
                samesite="lax",
            )

        return TokenResponse(
            access_token=token, token_type="bearer", expires_in=expires_in
        )

    @router.post(
        "/login_with_external_auth",
        response_model=TokenResponse,
        summary="User login with external auth",
        description="Authenticate user with external auth and return JWT token",
    )
    async def login_with_external_auth(
        subject_id: int = Depends(require_external_login()),
    ):
        rbac_middleware: RBACMiddleware = RBACMiddleware(
            rbac_plugin=None
        )  # no plugin needed for token create
        config = get_rbac_config()
        expires_in = config.access_token_expire_minutes * 60
        token = rbac_middleware.create_access_token(subject=int(subject_id))

        return TokenResponse(
            access_token=token, token_type="bearer", expires_in=expires_in
        )

    @router.post(
        "/logout",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="User logout",
        description="Client-side should delete stored token. Server is stateless.",
    )
    async def logout(response: Response):
        response.delete_cookie(key="rbac_token", path="/")
        return None

    @router.get(
        "/search",
        response_model=List[UserModel],
        summary="Search users",
        description="Search users by keyword",
    )
    async def search_users(
        q: str = Query(..., description="Search keyword"),
        limit: int = Query(10, ge=1, le=50, description="Result limit"),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:users")),
    ):
        """Search users"""
        user_serializer = UserSerializer(db_session)
        users = await user_serializer.search_users(query=q, limit=limit)

        return users

    @router.get(
        "",
        response_model=PaginatedResponse[UserModel],
        summary="Get user list",
        description="Paginated query user list, support multiple search conditions",
    )
    async def get_users(
        page: int = Query(1, ge=1, description="Page number"),
        size: int = Query(20, ge=1, le=100, description="Page size"),
        name: Optional[str] = Query(None, description="Name search"),
        en_name: Optional[str] = Query(None, description="English name search"),
        email: Optional[str] = Query(None, description="Email search"),
        mobile: Optional[str] = Query(None, description="Mobile number search"),
        user_id: Optional[str] = Query(None, description="External user ID search"),
        status: Optional[int] = Query(None, description="Status filter"),
        locked: Optional[int] = Query(None, description="Locked status filter"),
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("view:users")),
    ):
        """Get user list"""
        # Build pagination parameters
        pagination = PaginationParams(page=page, size=size)

        # Build search parameters
        search_params = UserSearchParams(
            name=name,
            en_name=en_name,
            email=email,
            mobile=mobile,
            user_id=user_id,
            status=status,
            locked=locked,
        )

        # Query user list
        user_serializer = UserSerializer(db_session)
        result = await user_serializer.get_users(
            pagination=pagination, search_params=search_params, include_roles=False
        )

        return result

    @router.get(
        "/{user_id}",
        response_model=UserModel,
        summary="Get user details",
        description="Get detailed information for a single user by user ID",
    )
    async def get_user(
        user_id: int, db_session: AsyncSession = Depends(get_db_session)
    ):
        """Get single user details"""
        user_serializer = UserSerializer(db_session)
        user = await user_serializer.get_user(user_id, include_roles=False)

        if not user:
            raise HTTPException(
                status_code=404,
                detail=f"User with ID {user_id} not found",
            )

        return user

    @router.put(
        "/{user_id}",
        response_model=UserModel,
        summary="Update user",
        description="Update user information",
    )
    async def update_user(
        user_id: int,
        user_data: UserModel,  # type: ignore[valid-type]
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("user:edit")),
    ):
        """Update user"""
        user_serializer = UserSerializer(db_session)
        user = await user_serializer.update_user(user_id, user_data)

        return user

    @router.get(
        "/{user_id}/roles",
        response_model=List[RoleInfo],
        summary="Get user role list",
        description="Get all role information for a specified user",
    )
    async def get_user_roles(
        user_id: int, db_session: AsyncSession = Depends(get_db_session)
    ):
        """Get user role list"""
        user_serializer = UserSerializer(db_session)
        roles = await user_serializer.get_user_roles(user_id)

        return roles

    @router.post(
        "",
        response_model=UserModel,
        status_code=status.HTTP_201_CREATED,
        summary="Create user",
        description="Create new user",
    )
    async def create_user(
        user_data: UserModel,  # type: ignore[valid-type]
        db_session: AsyncSession = Depends(get_db_session),
        _: bool = Depends(require_permissions("user:create")),
    ):
        """Create user"""
        user_serializer = UserSerializer(db_session)
        user = await user_serializer.create_user(user_data)

        return user

    return router


# Response example (for documentation generation)
responses = {
    400: {"model": ErrorResponse, "description": "Request parameter error"},
    404: {"model": ErrorResponse, "description": "User not found"},
    500: {"model": ErrorResponse, "description": "Server internal error"},
}
