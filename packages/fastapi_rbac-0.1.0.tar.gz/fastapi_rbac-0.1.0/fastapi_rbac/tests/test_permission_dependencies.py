"""
Permission Dependencies Tests

Unit tests for permission-based dependency injection functionality.
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.testclient import TestClient
from sqlmodel.ext.asyncio.session import AsyncSession

from ..dependencies.permission_dependencies import require_permissions
from ..dependencies.rbac_middleware import RBACMiddleware


class TestRequirePermissions:
    """Test the require_permissions function"""

    def test_require_permissions_returns_callable(self, app):
        """Test that require_permissions returns a callable dependency function"""
        dependency = require_permissions("user:read")

        assert callable(dependency)
        assert hasattr(dependency, "__call__")

    def test_require_permissions_with_multiple_codes(self, app):
        """Test require_permissions with multiple permission codes"""
        dependency = require_permissions("user:read", "user:write", "admin:manage")

        assert callable(dependency)

    def test_require_permissions_with_empty_codes(self, app):
        """Test require_permissions with no permission codes"""
        dependency = require_permissions()

        assert callable(dependency)


class TestPermissionDependency:
    """Test the permission dependency function behavior"""

    @pytest.fixture
    def mock_request(self, app):
        """Create a mock FastAPI request"""
        mock_request = Mock(spec=Request)
        mock_request.url.path = "/test-endpoint"
        mock_request.app = Mock()
        mock_request.app.state = Mock()
        return mock_request

    @pytest.fixture
    def mock_rbac_middleware(self, app):
        """Create a mock RBAC middleware"""
        middleware = Mock(spec=RBACMiddleware)
        middleware.get_current_user_id = AsyncMock()
        middleware.check_user_permissions = AsyncMock()
        return middleware

    @pytest.fixture
    def mock_db_session(self, app):
        """Create a mock database session"""
        return Mock(spec=AsyncSession)

    @pytest.mark.asyncio
    async def test_permission_dependency_success(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test successful permission validation"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = 1
        mock_rbac_middleware.check_user_permissions.return_value = True

        # Create dependency
        dependency = require_permissions("user:read")

        # Execute
        result = await dependency(mock_request, mock_db_session)

        # Verify
        assert result is True
        mock_rbac_middleware.get_current_user_id.assert_called_once_with(mock_request)
        mock_rbac_middleware.check_user_permissions.assert_called_once_with(
            mock_request, ["user:read"], mock_db_session, user_id=1
        )

    @pytest.mark.asyncio
    async def test_permission_dependency_multiple_permissions_or_logic(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test permission dependency with multiple permissions (OR logic)"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = 1
        mock_rbac_middleware.check_user_permissions.return_value = True

        # Create dependency with multiple permissions
        dependency = require_permissions("user:read", "user:write", "admin:manage")

        # Execute
        result = await dependency(mock_request, mock_db_session)

        # Verify
        assert result is True
        mock_rbac_middleware.check_user_permissions.assert_called_once_with(
            mock_request,
            ["user:read", "user:write", "admin:manage"],
            mock_db_session,
            user_id=1,
        )

    @pytest.mark.asyncio
    async def test_permission_dependency_insufficient_permissions(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test permission denial when user lacks required permissions"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = 1
        mock_rbac_middleware.check_user_permissions.return_value = False

        # Create dependency
        dependency = require_permissions("admin:manage")

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request, mock_db_session)

        assert exc_info.value.status_code == 403
        assert exc_info.value.detail["error"] == "insufficient_permissions"
        assert exc_info.value.detail["required_permissions"] == ["admin:manage"]
        assert (
            exc_info.value.detail["permission_logic"]
            == "OR (any one of the required permissions)"
        )
        assert exc_info.value.detail["user_id"] == 1

    @pytest.mark.asyncio
    async def test_permission_dependency_not_authenticated(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test authentication required when user is not authenticated"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.return_value = None

        # Create dependency
        dependency = require_permissions("user:read")

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request, mock_db_session)

        assert exc_info.value.status_code == 401
        assert exc_info.value.detail["error"] == "authentication_required"
        assert "authentication required" in exc_info.value.detail["message"].lower()

    @pytest.mark.asyncio
    async def test_permission_dependency_no_permission_codes(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test configuration error when no permission codes are specified"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware

        # Create dependency with no permissions
        dependency = require_permissions()

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request, mock_db_session)

        assert exc_info.value.status_code == 500
        assert exc_info.value.detail["error"] == "configuration_error"
        assert "No permission codes specified" in exc_info.value.detail["message"]

    @pytest.mark.asyncio
    async def test_permission_dependency_invalid_permission_code_format(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test configuration error with invalid permission code format"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware

        # Create dependency with invalid permission codes
        dependency = require_permissions("", "   ", None)

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request, mock_db_session)

        assert exc_info.value.status_code == 500
        assert exc_info.value.detail["error"] == "configuration_error"
        assert "Invalid permission code format" in exc_info.value.detail["message"]

    @pytest.mark.asyncio
    async def test_permission_dependency_rbac_middleware_not_configured(
        self, app, mock_request, mock_db_session
    ):
        """Test configuration error when RBAC middleware is not configured"""
        # Setup - no rbac_middleware in app state
        mock_request.app.state.rbac_middleware = None

        # Create dependency
        dependency = require_permissions("user:read")

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request, mock_db_session)

        assert exc_info.value.status_code == 500
        assert exc_info.value.detail["error"] == "configuration_error"
        assert (
            "RBAC middleware not configured properly"
            in exc_info.value.detail["message"]
        )

    @pytest.mark.asyncio
    async def test_permission_dependency_unexpected_exception(
        self, app, mock_request, mock_rbac_middleware, mock_db_session
    ):
        """Test handling of unexpected exceptions"""
        # Setup
        mock_request.app.state.rbac_middleware = mock_rbac_middleware
        mock_rbac_middleware.get_current_user_id.side_effect = Exception(
            "Database connection error"
        )

        # Create dependency
        dependency = require_permissions("user:read")

        # Execute and verify exception
        with pytest.raises(HTTPException) as exc_info:
            await dependency(mock_request, mock_db_session)

        assert exc_info.value.status_code == 500
        assert exc_info.value.detail["error"] == "internal_server_error"
        assert "unexpected error occurred" in exc_info.value.detail["message"]
        assert "Database connection error" in exc_info.value.detail["details"]
