#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:45:18
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

import pytest
from fastapi.testclient import TestClient
from sqlmodel.ext.asyncio.session import AsyncSession
import uuid

from ..models import Role, UserRoleRelation
from ..models.pwd_user_model import UserWithPassword


class TestUserRoutes:
    """UserWithPassword router test"""

    def test_get_users_list(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test get user list"""
        response = client.get("/rbac/users")

        assert response.status_code == 200
        data = response.json()

        assert "items" in data
        assert "total" in data
        assert "page" in data
        assert "size" in data
        assert len(data["items"]) <= data["size"]

    def test_get_users_with_pagination(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test user list pagination"""
        response = client.get("/rbac/users?page=1&size=2")

        assert response.status_code == 200
        data = response.json()

        assert data["page"] == 1
        assert data["size"] == 2
        assert len(data["items"]) <= 2

    def test_get_users_with_search(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test user search"""
        response = client.get("/rbac/users?name=Saber")

        assert response.status_code == 200
        data = response.json()

        assert len(data["items"]) >= 0
        for item in data["items"]:
            assert "Saber" in item["name"]

    def test_get_user_by_id(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test get user by ID"""
        user_id = sample_users[0].id
        response = client.get(f"/rbac/users/{user_id}")

        assert response.status_code == 200
        data = response.json()

        assert data["id"] == user_id
        assert data["name"] == sample_users[0].name
        assert data["email"] == sample_users[0].email

    def test_get_user_not_found(self, client: TestClient):
        """Test get nonexistent user"""
        response = client.get("/rbac/users/99999")

        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

    def test_get_user_roles(
        self,
        client: TestClient,
        sample_users: list[UserWithPassword],
        sample_user_roles: list[UserRoleRelation],
    ):
        """Test get user roles"""
        user_id = sample_users[0].id  # Saber, should have roles
        response = client.get(f"/rbac/users/{user_id}/roles")

        assert response.status_code == 200
        data = response.json()

        assert isinstance(data, list)
        assert len(data) >= 1
        for role in data:
            assert "id" in role
            assert "name" in role

    def test_search_users(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test user search interface"""
        response = client.get("/rbac/users/search?q=Saber&limit=5")

        assert response.status_code == 200
        data = response.json()

        assert isinstance(data, list)
        assert len(data) <= 5
        for user in data:
            assert "Saber" in user["name"]

    def test_create_user(self, client: TestClient):
        """Test create user"""
        # Use UUID suffix to avoid user conflicts
        unique_suffix = str(uuid.uuid4())[:8]
        user_data = {
            "name": f"Test User_{unique_suffix}",
            "en_name": f"test_user_{unique_suffix}",
            "email": f"testuser_{unique_suffix}@example.com",
            "mobile": "13800138000",
            "user_id": f"test_user_{unique_suffix}",
            "status": 1,
            "locked": 0,
            "password": "testpassword123",  # Add required password field
        }

        response = client.post("/rbac/users", json=user_data)

        assert response.status_code == 201
        data = response.json()

        assert data["name"] == user_data["name"]
        assert data["email"] == user_data["email"]
        assert data["status"] == user_data["status"]
        assert "id" in data

    def test_create_user_duplicate_email(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test create user with duplicate email"""
        user_data = {
            "name": "Duplicate Email UserWithPassword",
            "en_name": "duplicate_email_user",
            "email": sample_users[0].email,  # Use existing email
            "mobile": "13900139000",
            "user_id": "duplicate_email_user",
            "status": 1,
            "locked": 0,
            "password": "testpassword123",  # Add required password field
        }

        response = client.post("/rbac/users", json=user_data)

        assert response.status_code == 400
        data = response.json()
        assert "already exists" in data["detail"]

    def test_update_user(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test update user"""
        user_id = sample_users[0].id
        update_data = {
            "name": "Updated UserWithPassword Name",
            "email": "updated_user@example.com",
        }

        response = client.put(f"/rbac/users/{user_id}", json=update_data)

        assert response.status_code == 200
        data = response.json()

        assert data["name"] == update_data["name"]
        assert data["email"] == update_data["email"]
        assert data["id"] == user_id

    def test_invalid_pagination_parameters(self, client: TestClient):
        """Test invalid pagination parameters"""
        # Test page number less than 1
        response = client.get("/rbac/users?page=0")
        assert response.status_code == 422

        # Test page size exceeds limit
        response = client.get("/rbac/users?size=200")
        assert response.status_code == 422


class TestRoleRoutes:
    """Role router test"""

    def test_get_roles_list(self, client: TestClient, sample_roles: list[Role]):
        """Test get role list"""
        response = client.get("/rbac/roles")

        assert response.status_code == 200
        data = response.json()

        assert "items" in data
        assert "total" in data
        assert len(data["items"]) <= data["size"]

    def test_get_roles_with_search(self, client: TestClient, sample_roles: list[Role]):
        """Test role search"""
        response = client.get("/rbac/roles?name=Admin")

        assert response.status_code == 200
        data = response.json()

        for item in data["items"]:
            assert "Admin" in item["name"]

    def test_create_role(self, client: TestClient):
        """Test create role"""
        # Use UUID suffix to avoid role name conflicts
        unique_suffix = str(uuid.uuid4())[:8]
        role_data = {
            "name": f"Test role_{unique_suffix}",
            "description": "This is a test role",
            "is_active": True,
            "is_system": False,
        }

        response = client.post("/rbac/roles", json=role_data)

        assert response.status_code == 201
        data = response.json()

        assert data["name"] == role_data["name"]
        assert data["description"] == role_data["description"]
        assert data["is_active"] == role_data["is_active"]
        assert data["is_system"] == role_data["is_system"]

    def test_create_duplicate_role(self, client: TestClient, sample_roles: list[Role]):
        """Test create duplicate role"""
        role_data = {
            "name": sample_roles[0].name,  # Use existing name
            "description": "Duplicate role",
        }

        response = client.post("/rbac/roles", json=role_data)

        assert response.status_code == 400
        data = response.json()
        assert "already exists" in data["detail"]

    def test_get_role_by_id(self, client: TestClient, sample_roles: list[Role]):
        """Test get role by ID"""
        role_id = sample_roles[0].id
        response = client.get(f"/rbac/roles/{role_id}")

        assert response.status_code == 200
        data = response.json()

        assert data["id"] == role_id
        assert data["name"] == sample_roles[0].name

    def test_get_role_not_found(self, client: TestClient):
        """Test get nonexistent role"""
        response = client.get("/rbac/roles/99999")

        assert response.status_code == 404

    def test_update_role(self, client: TestClient, sample_roles: list[Role]):
        """Test update role"""
        role_id = sample_roles[1].id  # Editor
        update_data = {"name": "Advanced Editor", "description": "Updated description"}

        response = client.put(f"/rbac/roles/{role_id}", json=update_data)

        assert response.status_code == 200
        data = response.json()

        assert data["name"] == update_data["name"]
        assert data["description"] == update_data["description"]

    def test_delete_role(self, client: TestClient, sample_roles: list[Role]):
        """Test delete role"""
        # Use disabled role (no associated users)
        role_id = sample_roles[3].id
        response = client.delete(f"/rbac/roles/{role_id}")

        assert response.status_code == 204

    def test_delete_system_role(self, client: TestClient, sample_roles: list[Role]):
        """Test delete system role (should fail)"""
        role_id = sample_roles[0].id  # Admin (system role)
        response = client.delete(f"/rbac/roles/{role_id}")

        assert response.status_code == 400
        data = response.json()
        assert "system role cannot be deleted" in data["detail"].lower()

    # Keep only one representative 404 test for roles: test_get_role_not_found

    def test_get_role_users(
        self,
        client: TestClient,
        sample_roles: list[Role],
        sample_user_roles: list[UserRoleRelation],
    ):
        """Test get role user list"""
        role_id = sample_roles[0].id  # Admin role
        response = client.get(f"/rbac/roles/{role_id}/users")

        assert response.status_code == 200
        data = response.json()

        assert isinstance(data, list)
        for user in data:
            assert "id" in user
            assert "name" in user

    def test_assign_users_to_role(
        self,
        client: TestClient,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test assign user to role"""
        role_id = sample_roles[2].id  # Viewer role
        user_id = sample_users[0].id  # Saber

        assignment_data = {"user_ids": [user_id], "assigned_by": 1}

        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)

        assert response.status_code == 200
        data = response.json()

        assert "message" in data
        assert "assigned_count" in data
        assert "user_ids" in data

    def test_assign_nonexistent_user_to_role(
        self, client: TestClient, sample_roles: list[Role]
    ):
        """Test assign nonexistent user to role"""
        role_id = sample_roles[0].id
        assignment_data = {"user_ids": [99999], "assigned_by": 1}  # Nonexistent user ID

        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)

        assert response.status_code == 400
        data = response.json()
        assert "users not found" in data["detail"].lower()

    def test_remove_user_from_role(
        self,
        client: TestClient,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
        sample_user_roles: list[UserRoleRelation],
    ):
        """Test remove user from role"""
        role_id = sample_roles[1].id  # Editor role (BaseEditor)
        user_id = sample_users[0].id  # Acher (id=2) - has BaseEditor role

        response = client.delete(f"/rbac/roles/{role_id}/users/{user_id}")

        assert response.status_code == 204

    def test_remove_nonexistent_user_from_role(
        self,
        client: TestClient,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test remove nonexistent user from role"""
        role_id = sample_roles[0].id  # BaseAdmin role
        user_id = sample_users[
            1
        ].id  # Caster (id=3) - ensure this user does not have BaseAdmin role

        response = client.delete(f"/rbac/roles/{role_id}/users/{user_id}")

        assert response.status_code == 400


class TestAPIValidation:
    """API parameter validation test"""

    def test_create_role_missing_required_fields(self, client: TestClient):
        """Test create role missing required fields"""
        role_data = {}  # Missing name field

        response = client.post("/rbac/roles", json=role_data)

        assert response.status_code == 422
        data = response.json()
        assert "detail" in data

    def test_create_role_invalid_field_types(self, client: TestClient):
        """Test create role field type error"""
        role_data = {
            "name": 123,
            "is_active": "yes",
        }  # Should be string  # Should be boolean

        response = client.post("/rbac/roles", json=role_data)

        assert response.status_code == 422

    def test_assign_users_missing_user_ids(
        self, client: TestClient, sample_roles: list[Role]
    ):
        """Test assign users missing user IDs"""
        role_id = sample_roles[0].id
        assignment_data = {}  # Missing user_ids field

        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)

        assert response.status_code == 422

    def test_assign_users_empty_user_ids(
        self, client: TestClient, sample_roles: list[Role]
    ):
        """Test assign users empty user IDs"""
        role_id = sample_roles[0].id
        assignment_data = {"user_ids": []}  # Empty list

        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)

        assert response.status_code == 422


class TestAPIPermissions:
    """API permissions test"""

    def test_role_operations_flow(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test role operations flow"""
        # Use UUID suffix to avoid role name conflicts
        unique_suffix = str(uuid.uuid4())[:8]

        # 1. Create role
        role_data = {
            "name": f"Flow test role_{unique_suffix}",
            "description": "Role for testing complete flow",
        }
        response = client.post("/rbac/roles", json=role_data)
        assert response.status_code == 201
        role_id = response.json()["id"]

        # 2. Get role details
        response = client.get(f"/rbac/roles/{role_id}")
        assert response.status_code == 200

        # 3. Update role
        update_data = {"description": "Updated description"}
        response = client.put(f"/rbac/roles/{role_id}", json=update_data)
        assert response.status_code == 200

        # 4. Assign users to role
        assignment_data = {"user_ids": [sample_users[0].id], "assigned_by": 1}
        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)
        assert response.status_code == 200

        # 5. Get role user list
        response = client.get(f"/rbac/roles/{role_id}/users")
        assert response.status_code == 200
        assert len(response.json()) >= 1

        # 6. Remove user
        response = client.delete(f"/rbac/roles/{role_id}/users/{sample_users[0].id}")
        assert response.status_code == 204

        # 7. Delete role
        response = client.delete(f"/rbac/roles/{role_id}")
        assert response.status_code == 204

    def test_user_operations_flow(self, client: TestClient):
        """Test user operations flow"""
        # Use UUID suffix to avoid user name conflicts
        unique_suffix = str(uuid.uuid4())[:8]

        # 1. Create user
        user_data = {
            "name": f"Flow test user_{unique_suffix}",
            "en_name": f"flow_test_user_{unique_suffix}",
            "email": f"flowtest_{unique_suffix}@example.com",
            "mobile": "13800138001",
            "user_id": f"flow_test_user_{unique_suffix}",
            "status": 1,
            "locked": 0,
            # "password": "testpassword123",  # Add required password field
        }
        response = client.post("/rbac/users", json=user_data)
        assert response.status_code == 201
        user_id = response.json()["id"]

        # 2. Get user details
        response = client.get(f"/rbac/users/{user_id}")
        assert response.status_code == 200

        # 3. Update user
        update_data = {"name": "Updated Flow Test UserWithPassword Name"}
        response = client.put(f"/rbac/users/{user_id}", json=update_data)
        assert response.status_code == 200

        # 4. Get user roles (should be empty initially)
        response = client.get(f"/rbac/users/{user_id}/roles")
        assert response.status_code == 200
        assert len(response.json()) == 0


class TestUserRouterExtended:
    pass


class TestRoleRouterExtended:
    pass


class TestErrorHandlingExtended:
    pass


class TestUserRouterExtendedNew:
    pass


class TestAPIResponseFormats:
    pass


class TestPermissionRoutes:
    """Permission route test"""

    @pytest.mark.asyncio
    async def test_get_permissions(self, client: TestClient, sample_permissions):
        """Test get permission list"""
        response = client.get("/rbac/permissions")

        assert response.status_code == 200
        data = response.json()

        assert "items" in data
        assert "total" in data
        assert "page" in data
        assert "size" in data
        assert len(data["items"]) <= data["total"]

    @pytest.mark.asyncio
    async def test_get_permissions_with_search(
        self, client: TestClient, sample_permissions
    ):
        """Test get permission with search"""
        response = client.get("/rbac/permissions?resource=user&is_active=true")

        assert response.status_code == 200
        data = response.json()

        # Validate search results
        for permission in data["items"]:
            assert permission["resource"] == "user"
            assert permission["is_active"] is True

    @pytest.mark.asyncio
    async def test_create_permission(self, client: TestClient):
        """Test create permission"""
        permission_data = {
            "code": "test:api:create",
            "name": "Test API create permission",
            "description": "Test permission created by API",
            "resource": "test",
            "action": "create",
            "permission_type": "function",
            "is_active": True,
            "is_system": False,
        }

        response = client.post("/rbac/permissions", json=permission_data)

        assert response.status_code == 201
        permission = response.json()

        assert permission["code"] == permission_data["code"]
        assert permission["name"] == permission_data["name"]
        assert permission["resource"] == permission_data["resource"]
        assert permission["is_active"] is True

    @pytest.mark.asyncio
    async def test_get_permission_by_id(self, client: TestClient, sample_permissions):
        """Test get permission by ID"""
        permission_id = sample_permissions[0].id
        response = client.get(f"/rbac/permissions/{permission_id}")

        assert response.status_code == 200
        permission = response.json()

        assert permission["id"] == permission_id
        assert permission["code"] == sample_permissions[0].code

    @pytest.mark.asyncio
    async def test_update_permission(self, client: TestClient, sample_permissions):
        """Test update permission"""
        permission_id = sample_permissions[0].id
        update_data = {
            "name": "Updated permission name",
            "description": "Updated permission description",
        }

        response = client.put(f"/rbac/permissions/{permission_id}", json=update_data)

        assert response.status_code == 200
        permission = response.json()

        assert permission["name"] == update_data["name"]
        assert permission["description"] == update_data["description"]

    @pytest.mark.asyncio
    async def test_delete_permission(self, client: TestClient):
        """Test delete permission"""
        # First create a permission for deletion
        permission_data = {
            "code": "test:delete:api",
            "name": "To be deleted permission",
            "is_system": False,
        }

        create_response = client.post("/rbac/permissions", json=permission_data)
        assert create_response.status_code == 201
        permission = create_response.json()

        # Delete permission
        response = client.delete(f"/rbac/permissions/{permission['id']}")

        assert response.status_code == 204

        # Verify permission is deleted
        get_response = client.get(f"/rbac/permissions/{permission['id']}")
        assert get_response.status_code == 404

    @pytest.mark.asyncio
    async def test_delete_system_permission(
        self, client: TestClient, sample_permissions
    ):
        """Test delete system permission"""
        # Find a system permission
        system_permission = next(p for p in sample_permissions if p.is_system)

        response = client.delete(f"/rbac/permissions/{system_permission.id}")

        assert response.status_code == 400
        assert (
            "cannot delete system built-in permission"
            in response.json()["detail"].lower()
        )

    @pytest.mark.asyncio
    async def test_get_permission_roles(self, client: TestClient, sample_permissions):
        """Test get permission role list"""
        permission_id = sample_permissions[0].id
        response = client.get(f"/rbac/permissions/{permission_id}/roles")

        assert response.status_code == 200
        roles = response.json()

        assert isinstance(roles, list)

    @pytest.mark.asyncio
    async def test_assign_roles_to_permission(
        self, client: TestClient, sample_permissions, sample_roles
    ):
        """Test assign roles to permission"""
        permission_id = sample_permissions[0].id
        assignment_data = {
            "role_ids": [sample_roles[0].id, sample_roles[1].id],
            "assigned_by": 1,
        }

        response = client.post(
            f"/rbac/permissions/{permission_id}/roles", json=assignment_data
        )

        assert response.status_code == 200
        data = response.json()

        assert "message" in data
        assert "assigned_count" in data
        assert data["assigned_count"] >= 0  # May have associated roles

    @pytest.mark.asyncio
    async def test_assign_nonexistent_roles(
        self, client: TestClient, sample_permissions
    ):
        """Test assign nonexistent roles to permission"""
        permission_id = sample_permissions[0].id
        assignment_data = {
            "role_ids": [99999, 99998],  # Non-existent role IDs
        }

        response = client.post(
            f"/rbac/permissions/{permission_id}/roles", json=assignment_data
        )

        assert response.status_code == 400
        assert "role not found" in response.json()["detail"].lower()

    @pytest.mark.asyncio
    async def test_remove_role_from_permission(
        self, client: TestClient, sample_permissions, sample_roles
    ):
        """Test remove role from permission"""
        permission_id = sample_permissions[0].id
        role_id = sample_roles[0].id

        # First assign role
        assignment_data = {
            "role_ids": [role_id],
        }
        client.post(f"/rbac/permissions/{permission_id}/roles", json=assignment_data)

        # Remove role
        response = client.delete(f"/rbac/permissions/{permission_id}/roles/{role_id}")

        assert response.status_code == 204

    @pytest.mark.asyncio
    async def test_remove_nonexistent_role_from_permission(
        self, client: TestClient, sample_permissions
    ):
        """Test remove nonexistent role association"""
        permission_id = sample_permissions[0].id

        response = client.delete(f"/rbac/permissions/{permission_id}/roles/99999")

        assert response.status_code == 404
        assert "not found" in response.json()["detail"].lower()

    @pytest.mark.asyncio
    async def test_permission_validation_errors(self, client: TestClient):
        """Test permission validation errors"""
        # Test missing required fields
        invalid_data = {
            "name": "Permission without code",
        }

        response = client.post("/rbac/permissions", json=invalid_data)

        assert response.status_code == 422  # Validation error

    @pytest.mark.asyncio
    async def test_permission_search_by_multiple_criteria(
        self, client: TestClient, sample_permissions
    ):
        """Test multi-criteria search permission"""
        response = client.get(
            "/rbac/permissions?permission_type=function&is_active=true&resource=user"
        )

        assert response.status_code == 200
        data = response.json()

        for permission in data["items"]:
            assert permission["permission_type"] == "function"
            assert permission["is_active"] is True
            if permission["resource"]:  # May be None
                assert permission["resource"] == "user"
