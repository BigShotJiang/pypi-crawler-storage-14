#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:39:08
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Test User Serializers
    Test cases for the optimized user serializer system.

All Rights Reserved.
"""

from pydantic import ValidationError
import pytest
from unittest.mock import AsyncMock, MagicMock
from sqlmodel.ext.asyncio.session import AsyncSession

from ..serializers.user_serializer_factory import UserSerializerFactory
from ..serializers.default_user_serializer import DefaultUserSerializer
from ..serializers.password_user_serializer import PasswordUserSerializer
from ..serializers.base_user_serializer import BaseUserSerializer
from ..config import RBACConfig


class TestUserSerializerFactory:
    """Test UserSerializerFactory functionality"""

    @pytest.fixture
    def mock_db_session(self):
        """Mock database session"""
        return AsyncMock(spec=AsyncSession)

    @pytest.fixture
    def mock_config(self):
        """Mock RBAC configuration"""
        config = MagicMock()
        config.user_serializer = DefaultUserSerializer
        return config

    def test_create_serializer_with_default_serializer(
        self, mock_db_session, mock_config
    ):
        """Test creating serializer with default serializer configuration"""
        # Mock the config getter
        with pytest.MonkeyPatch().context() as m:
            m.setattr(
                "fastapi_rbac.serializers.user_serializer_factory.get_rbac_config",
                lambda: mock_config,
            )

            serializer = UserSerializerFactory.create_serializer(mock_db_session)

            assert isinstance(serializer, DefaultUserSerializer)
            assert serializer.db_session == mock_db_session

    # def test_create_serializer_with_password_serializer(self, mock_db_session):
    #     """Test creating serializer with password serializer configuration"""
    #     config = MagicMock()
    #     config.user_serializer = PasswordUserSerializer

    #     with pytest.MonkeyPatch().context() as m:
    #         m.setattr("fastapi_rbac.serializer_factory.get_rbac_config", lambda: config)

    #         serializer = UserSerializerFactory.create_serializer(mock_db_session)

    #         assert isinstance(serializer, PasswordUserSerializer)
    #         assert serializer.db_session == mock_db_session

    def test_get_serializer_class(self, mock_config):
        """Test getting serializer class from configuration"""
        with pytest.MonkeyPatch().context() as m:
            m.setattr(
                "fastapi_rbac.serializers.user_serializer_factory.get_rbac_config",
                lambda: mock_config,
            )

            serializer_class = UserSerializerFactory.get_serializer_class()

            assert serializer_class == DefaultUserSerializer

    def test_get_user_model(self, mock_config):
        """Test getting user model from configured serializer"""
        with pytest.MonkeyPatch().context() as m:
            m.setattr(
                "fastapi_rbac.serializers.user_serializer_factory.get_rbac_config",
                lambda: mock_config,
            )

            user_model = UserSerializerFactory.get_user_model()

            # DefaultUserSerializer.user_model should be the User class
            from ..models.default_user_model import User

            assert user_model == User


class TestDefaultUserSerializer:
    """Test DefaultUserSerializer functionality"""

    @pytest.fixture
    def mock_db_session(self):
        """Mock database session"""
        return AsyncMock(spec=AsyncSession)

    @pytest.fixture
    def default_serializer(self, mock_db_session):
        """Default serializer instance"""
        return DefaultUserSerializer(mock_db_session)

    def test_user_model_class_variable(self, default_serializer):
        """Test that user_model class variable is properly set"""
        from ..models.default_user_model import User

        assert DefaultUserSerializer.user_model == User
        assert default_serializer.user_model == User

    def test_constructor(self, mock_db_session):
        """Test constructor properly initializes the serializer"""
        serializer = DefaultUserSerializer(mock_db_session)
        assert serializer.db_session == mock_db_session


class TestPasswordUserSerializer:
    """Test PasswordUserSerializer functionality"""

    @pytest.fixture
    def mock_db_session(self):
        """Mock database session"""
        return AsyncMock(spec=AsyncSession)

    @pytest.fixture
    def password_serializer(self, mock_db_session):
        """Password serializer instance"""
        return PasswordUserSerializer(mock_db_session)

    def test_user_model_class_variable(self, password_serializer):
        """Test that user_model class variable is properly set"""
        from ..models.pwd_user_model import UserWithPassword

        assert PasswordUserSerializer.user_model == UserWithPassword
        assert password_serializer.user_model == UserWithPassword

    def test_constructor(self, mock_db_session):
        """Test constructor properly initializes the serializer"""
        serializer = PasswordUserSerializer(mock_db_session)
        assert serializer.db_session == mock_db_session
        assert hasattr(serializer, "pwd_context")


class TestBaseUserSerializer:
    """Test BaseUserSerializer functionality"""

    @pytest.fixture
    def mock_db_session(self):
        """Mock database session"""
        return AsyncMock(spec=AsyncSession)

    def test_abstract_user_model_requirement(self):
        """Test that BaseUserSerializer requires user_model class variable"""

        # Create a mock serializer class without user_model
        class MockSerializer(BaseUserSerializer):
            pass

        # Should raise error when trying to instantiate
        with pytest.raises(AttributeError):
            MockSerializer(AsyncMock(spec=AsyncSession))

    def test_user_model_class_variable_usage(self):
        """Test that user_model class variable is used in constructor"""

        class MockSerializer(BaseUserSerializer):
            user_model = MagicMock()

        mock_session = AsyncMock(spec=AsyncSession)
        serializer = MockSerializer(mock_session)

        # Verify that the user_model was passed to BaseSerializer
        assert serializer.model_class == MockSerializer.user_model


class TestConfigurationIntegration:
    """Test configuration integration with serializers"""

    def test_rbac_config_validation(self, mock_gen_rbac_async_session):
        """Test that RBACConfig properly validates user_serializer"""
        # Valid configuration
        config = RBACConfig(
            custom_session_maker=mock_gen_rbac_async_session,
            user_serializer=DefaultUserSerializer,
        )
        assert config.user_serializer == DefaultUserSerializer

    def test_rbac_config_validation_failure(self, mock_gen_rbac_async_session):
        """Test that RBACConfig rejects invalid user_serializer"""

        class InvalidSerializer:
            pass

        with pytest.raises(ValidationError):
            RBACConfig(
                custom_session_maker=mock_gen_rbac_async_session,
                user_serializer=InvalidSerializer,
            )
