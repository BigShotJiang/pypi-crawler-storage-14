#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-09-28 17:01:43
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""
import pytest
from datetime import datetime
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
import uuid

from ...models import Role, UserRoleRelation, Permission
from ...models.pwd_user_model import UserWithPassword
from ...serializers import UserSerializer, RoleSerializer, DatabaseError, NotFoundError
from ...schemas import (
    UserSearchParams,
    RoleCreate,
    RoleUpdate,
    RoleSearchParams,
    UserRoleAssignment,
    PaginationParams,
    PermissionSearchParams,
)


class TestSerializerErrorHandling:
    """Serializer error handling tests"""

    @pytest.mark.asyncio
    async def test_remove_nonexistent_user_role(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test remove nonexistent user role relation"""
        role_serializer = RoleSerializer(db_session)
        # Use BaseAdmin role and Caster user (no active relation exists)
        role = next(r for r in sample_roles if r.name == "BaseAdmin")
        user = next(u for u in sample_users if u.name == "Caster")

        with pytest.raises(DatabaseError) as exc_info:
            await role_serializer.remove_user(role.id, user.id)

        assert "does not exist" in str(exc_info.value)
