#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-09-28 17:01:23
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""
import pytest
from datetime import datetime
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
import uuid

from ...models import Role, UserRoleRelation, Permission
from ...models.pwd_user_model import UserWithPassword
from ...serializers import UserSerializer, RoleSerializer, DatabaseError, NotFoundError
from ...schemas import (
    UserSearchParams,
    RoleCreate,
    RoleUpdate,
    RoleSearchParams,
    UserRoleAssignment,
    PaginationParams,
    PermissionSearchParams,
)


class TestPermissionSerializer:
    """Permission serializer tests"""

    @pytest.mark.asyncio
    async def test_create_permission(self, db_session: AsyncSession):
        """Test create permission"""
        from ...serializers import PermissionSerializer
        from ...schemas.permission_schemas import PermissionCreate

        serializer = PermissionSerializer(db_session)
        permission_data = PermissionCreate(
            code="test:create:permission",
            name="Test create permission",
            description="For testing permission creation",
            resource="test",
            action="create",
            permission_type="function",
            is_active=True,
            is_system=False,
        )

        permission = await serializer.create_permission(permission_data)

        assert permission.id is not None
        assert permission.code == "test:create:permission"
        assert permission.name == "Test create permission"
        assert permission.resource == "test"
        assert permission.action == "create"
        assert permission.is_active is True

    @pytest.mark.asyncio
    async def test_get_permission(self, db_session: AsyncSession, sample_permissions):
        """Test get permission"""
        from ...serializers import PermissionSerializer

        serializer = PermissionSerializer(db_session)
        permission = await serializer.get_permission(sample_permissions[0].id)

        assert permission is not None
        assert permission.id == sample_permissions[0].id
        assert permission.code == sample_permissions[0].code

    @pytest.mark.asyncio
    async def test_get_permissions_with_search(
        self, db_session: AsyncSession, sample_permissions
    ):
        """Test search permission query"""
        from ...serializers import PermissionSerializer
        from ...schemas.permission_schemas import PermissionSearchParams
        from ...schemas.common_schemas import PaginationParams

        serializer = PermissionSerializer(db_session)
        pagination = PaginationParams(page=1, size=10)
        search_params = PermissionSearchParams(
            code=None,
            name=None,
            description=None,
            resource="user",
            action=None,
            permission_type=None,
            is_active=True,
            is_system=None,
            created_after=None,
            created_before=None,
        )

        result = await serializer.get_permissions(pagination, search_params)

        assert result.total >= 1
        for permission in result.items:
            assert permission.resource == "user"
            assert permission.is_active is True

    @pytest.mark.asyncio
    async def test_update_permission(
        self, db_session: AsyncSession, sample_permissions
    ):
        """Test update permission"""
        from ...serializers import PermissionSerializer
        from ...schemas.permission_schemas import PermissionUpdate

        serializer = PermissionSerializer(db_session)
        permission_data = PermissionUpdate(
            code=sample_permissions[0].code,
            resource=sample_permissions[0].resource,
            action=sample_permissions[0].action,
            permission_type=sample_permissions[0].permission_type,
            is_active=sample_permissions[0].is_active,
            name="Updated permission name",
            description="Updated description",
        )

        permission = await serializer.update_permission(
            sample_permissions[0].id, permission_data
        )

        assert permission.name == "Updated permission name"
        assert permission.description == "Updated description"
        assert permission.code == sample_permissions[0].code  # Code remains unchanged

    @pytest.mark.asyncio
    async def test_update_permission_duplicate_code(
        self, db_session: AsyncSession, sample_permissions
    ):
        """Test update permission to duplicate code"""
        from ...serializers import PermissionSerializer, DatabaseError
        from ...schemas.permission_schemas import PermissionUpdate

        serializer = PermissionSerializer(db_session)
        permission_data = PermissionUpdate(
            code=sample_permissions[1].code,  # Use another permission code
            name=None,
            description=None,
            resource=None,
            action=None,
            permission_type=None,
            is_active=None,
        )

        with pytest.raises(DatabaseError) as exc_info:
            await serializer.update_permission(
                sample_permissions[0].id, permission_data
            )

        assert "already used by other permission" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_delete_permission(self, db_session: AsyncSession):
        """Test delete permission"""
        from ...serializers import PermissionSerializer

        # Create a permission for deletion
        permission = Permission(
            code="test:delete:permission",
            name="Delete permission",
            description="Test permission for deletion",
            resource="test",
            action="delete",
            permission_type="function",
            is_active=True,
            is_system=False,
        )
        db_session.add(permission)
        await db_session.commit()
        await db_session.refresh(permission)

        serializer = PermissionSerializer(db_session)
        success = await serializer.delete_permission(permission.id)

        assert success is True

        # Verify permission is deleted
        deleted_permission = await serializer.get_permission(permission.id)
        assert deleted_permission is None

    @pytest.mark.asyncio
    async def test_delete_system_permission(
        self, db_session: AsyncSession, sample_permissions
    ):
        """Test delete system permission (should fail)"""
        from ...serializers import PermissionSerializer, DatabaseError

        # Find a system permission
        system_permission = next(p for p in sample_permissions if p.is_system)

        serializer = PermissionSerializer(db_session)
        with pytest.raises(DatabaseError) as exc_info:
            await serializer.delete_permission(system_permission.id)

        assert "Cannot delete system built-in permission" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_assign_roles_to_permission(
        self, db_session: AsyncSession, sample_permissions, sample_roles
    ):
        """Test assign roles to permission"""
        from ...serializers import PermissionSerializer
        from ...schemas.permission_schemas import RolePermissionAssignment

        serializer = PermissionSerializer(db_session)
        assignment_data = RolePermissionAssignment(
            role_ids=[sample_roles[0].id, sample_roles[1].id],
            assigned_by=1,
            expires_at=None,
        )

        relations = await serializer.assign_roles(
            sample_permissions[0].id, assignment_data
        )

        assert len(relations) == 2
        assert all(rel.permission_id == sample_permissions[0].id for rel in relations)
        role_ids = {rel.role_id for rel in relations}
        assert role_ids == {sample_roles[0].id, sample_roles[1].id}

    @pytest.mark.asyncio
    async def test_assign_nonexistent_roles(
        self, db_session: AsyncSession, sample_permissions
    ):
        """Test assign nonexistent roles to permission"""
        from ...serializers import PermissionSerializer, DatabaseError
        from ...schemas.permission_schemas import RolePermissionAssignment

        serializer = PermissionSerializer(db_session)
        assignment_data = RolePermissionAssignment(
            role_ids=[99999, 99998],  # Nonexistent role ID
            assigned_by=1,
            expires_at=None,
        )

        with pytest.raises(DatabaseError) as exc_info:
            await serializer.assign_roles(sample_permissions[0].id, assignment_data)

        assert "Role not found:" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_get_permission_roles(
        self, db_session: AsyncSession, sample_permissions, sample_roles
    ):
        """Test get permission roles"""
        from ...serializers import PermissionSerializer
        from ...schemas.permission_schemas import RolePermissionAssignment

        serializer = PermissionSerializer(db_session)

        # Assign roles to permission first
        assignment_data = RolePermissionAssignment(
            role_ids=[sample_roles[0].id],
            assigned_by=1,
            expires_at=None,
        )
        await serializer.assign_roles(sample_permissions[0].id, assignment_data)

        # Get permission roles
        roles = await serializer.get_permission_roles(sample_permissions[0].id)

        assert len(roles) == 1
        role_ids = {role.id for role in roles}
        assert role_ids == {sample_roles[0].id}

    @pytest.mark.asyncio
    async def test_remove_role_from_permission(
        self, db_session: AsyncSession, sample_permissions, sample_roles
    ):
        """Test remove role from permission"""
        from ...serializers import PermissionSerializer
        from ...schemas.permission_schemas import RolePermissionAssignment

        serializer = PermissionSerializer(db_session)

        # Assign roles to permission first
        assignment_data = RolePermissionAssignment(
            role_ids=[sample_roles[0].id],
            assigned_by=1,
            expires_at=None,
        )
        await serializer.assign_roles(sample_permissions[0].id, assignment_data)

        # Remove role
        success = await serializer.remove_role(
            sample_permissions[0].id, sample_roles[0].id
        )

        assert success is True

        # Verify role is removed
        roles = await serializer.get_permission_roles(sample_permissions[0].id)
        assert len(roles) == 0

    @pytest.mark.asyncio
    async def test_remove_nonexistent_role(
        self, db_session: AsyncSession, sample_permissions
    ):
        """Test remove nonexistent role relation"""
        from ...serializers import PermissionSerializer, NotFoundError

        serializer = PermissionSerializer(db_session)

        with pytest.raises(Exception) as exc_info:
            await serializer.remove_role(sample_permissions[0].id, 99999)

        assert "not found" in str(exc_info.value)
