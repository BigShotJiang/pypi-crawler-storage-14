#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-09-28 17:00:25
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""
import pytest
from datetime import datetime
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
import uuid

from ...models import Role, UserRoleRelation, Permission
from ...models.pwd_user_model import UserWithPassword
from ...serializers import UserSerializer, RoleSerializer, DatabaseError, NotFoundError
from ...schemas import (
    UserSearchParams,
    RoleCreate,
    RoleUpdate,
    RoleSearchParams,
    UserRoleAssignment,
    PaginationParams,
    PermissionSearchParams,
)
from ...models import get_user_model


class TestUserSerializer:
    """UserWithPassword serializer tests"""

    @pytest.mark.asyncio
    async def test_get_user_by_id(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        """Test get user by ID"""
        user_serializer = UserSerializer(db_session)
        user = await user_serializer.get_user(sample_users[0].id)

        assert user is not None
        assert user.id == sample_users[0].id
        assert user.name == sample_users[0].name

    @pytest.mark.asyncio
    async def test_get_users_with_search(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        user_serializer = UserSerializer(db_session)
        pagination = PaginationParams(page=1, size=10)
        search_params = UserSearchParams(
            name="Saber",
            en_name="",
            email="",
            mobile="",
            user_id="",
            status=None,
            locked=None,
        )

        result = await user_serializer.get_users(
            pagination=pagination, search_params=search_params
        )

        assert len(result.items) >= 1
        assert all("Saber" in item.name for item in result.items)

    @pytest.mark.asyncio
    async def test_search_users(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        user_serializer = UserSerializer(db_session)
        users = await user_serializer.search_users(query="Saber", limit=5)

        assert isinstance(users, list)
        assert all("Saber" in user.name for user in users)

    @pytest.mark.asyncio
    async def test_create_user_via_sso(self, db_session: AsyncSession):
        """Test create user via SSO"""
        user_serializer = UserSerializer(db_session)
        # Use unique email address to avoid conflict with fixture data
        unique_suffix = str(uuid.uuid4())[:8]
        User = get_user_model()
        user_data = User(
            name="New UserWithPassword",
            en_name="New UserWithPassword",
            email=f"newuser_{unique_suffix}@example.com",
            mobile="13800138999",
            user_id=f"new_user_{unique_suffix}",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Create user using the serializer method
        user = await user_serializer.create_user(user_data)

        assert user.name == "New UserWithPassword"
        assert user.en_name == "New UserWithPassword"
        assert user.email == f"newuser_{unique_suffix}@example.com"
        assert user.status == 1
        assert user.id is not None

    @pytest.mark.asyncio
    async def test_get_user_roles(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_user_roles: list[UserRoleRelation],
    ):
        """Test get user roles"""
        user_serializer = UserSerializer(db_session)
        # Find Saber user who should have BaseAdmin role (id=1 -> role_id=1)
        saber_user = next(u for u in sample_users if u.name == "Saber")

        roles = await user_serializer.get_user_roles(saber_user.id)

        assert isinstance(roles, list)
        assert len(roles) >= 1
        assert any("BaseAdmin" in role.name for role in roles)

    @pytest.mark.asyncio
    async def test_assign_user_roles(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        pass  # Covered by assign_roles/assign_roles_with_validation tests

    @pytest.mark.asyncio
    async def test_remove_user_role(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
        sample_user_roles: list[UserRoleRelation],
    ):
        """Test remove user role"""
        user_serializer = UserSerializer(db_session)
        # Find Acher user who should have BaseEditor role
        user = next(u for u in sample_users if u.name == "Acher")
        # Find BaseEditor role
        role = next(r for r in sample_roles if r.name == "BaseEditor")

        # Find and delete relation - use more specific query with is_active=True
        statement = select(UserRoleRelation).where(
            UserRoleRelation.user_id == user.id,
            UserRoleRelation.role_id == role.id,
            UserRoleRelation.is_active,
        )
        result = await db_session.execute(statement)
        relation = result.scalar_one_or_none()

        if relation:
            # Perform soft delete by setting is_active to False
            relation.is_active = False
            await db_session.commit()
            success = True
        else:
            success = False

        assert success is True

    @pytest.mark.asyncio
    async def test_create_user_email_duplicate(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        """Test create user with duplicate email"""
        user_serializer = UserSerializer(db_session)
        existing_user = sample_users[0]

        # Use existing email to create user
        User = get_user_model()
        user_data = User(
            name="New UserWithPassword",
            en_name="new_user",
            email=existing_user.email,  # Use existing email
            mobile="13900139000",
            user_id="new_user_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        with pytest.raises(DatabaseError) as exc_info:
            await user_serializer.create_user(user_data)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "EMAIL_ALREADY_EXISTS"
        assert exc_info.value.message_category == "USER"

    @pytest.mark.asyncio
    async def test_update_user_email_conflict(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        """Test update user email conflict"""
        user_serializer = UserSerializer(db_session)
        user1 = sample_users[0]
        user2 = sample_users[1]

        # Try to update user1's email to user2's email
        User = get_user_model()
        update_data = User(
            name=user1.name,
            en_name=user1.en_name,
            email=user2.email,  # Conflict
            mobile=user1.mobile,
            user_id=user1.user_id,
            status=user1.status,
            locked=user1.locked,
            last_login=None,
            password="y6ZreZqlZeBeIl",
        )

        with pytest.raises(DatabaseError) as exc_info:
            await user_serializer.update_user(user1.id, update_data)

        assert "already used by other user" in str(exc_info.value.message)

    @pytest.mark.asyncio
    async def test_assign_roles_with_validation(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test validation logic when assigning roles"""
        user_serializer = UserSerializer(db_session)
        user = sample_users[2]  # Caster
        role_ids = [sample_roles[0].id, sample_roles[1].id]  # Admin and Editor

        # Assign roles
        relations = await user_serializer.assign_roles(user.id, role_ids, assigned_by=1)

        # Verify result
        assert isinstance(relations, list)
        # Verify assigned roles are actually added
        user_roles = await user_serializer.get_user_roles(user.id)
        assigned_role_ids = {role.id for role in user_roles}
        assert all(role_id in assigned_role_ids for role_id in role_ids)

    @pytest.mark.asyncio
    async def test_assign_roles_nonexistent_role(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        """Test assign nonexistent role"""
        user_serializer = UserSerializer(db_session)
        user = sample_users[0]
        nonexistent_role_ids = [99999]  # Nonexistent role ID

        with pytest.raises(DatabaseError) as exc_info:
            await user_serializer.assign_roles(
                user.id, nonexistent_role_ids, assigned_by=1
            )

        assert "Role not found:" in str(exc_info.value.message)

    @pytest.mark.asyncio
    async def test_assign_roles_duplicate_assignment(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test duplicate role assignment"""
        user_serializer = UserSerializer(db_session)
        user = sample_users[0]  # Saber
        role_ids = [sample_roles[0].id]  # Admin role

        # First assign roles
        first_relations = await user_serializer.assign_roles(
            user.id, role_ids, assigned_by=1
        )
        assert len(first_relations) >= 0  # May
        second_relations = await user_serializer.assign_roles(
            user.id, role_ids, assigned_by=1
        )

        # Second assignment should return empty list because relation already exists
        assert len(second_relations) == 0

    @pytest.mark.asyncio
    async def test_remove_roles_soft_delete(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test soft delete logic when removing roles"""
        user_serializer = UserSerializer(db_session)
        user = sample_users[0]  # Saber
        role_ids = [sample_roles[0].id]  # Admin role

        # First ensure user has this role
        await user_serializer.assign_roles(user.id, role_ids, assigned_by=1)

        # Verify role is assigned
        user_roles_before = await user_serializer.get_user_roles(user.id)
        role_ids_before = {role.id for role in user_roles_before}
        assert sample_roles[0].id in role_ids_before

        # Remove role
        removed_count = await user_serializer.remove_roles(user.id, role_ids)

        # Verify removed count
        assert removed_count > 0

        # Verify role is actually removed (soft delete)
        user_roles_after = await user_serializer.get_user_roles(user.id)
        remaining_role_ids = {role.id for role in user_roles_after}
        assert sample_roles[0].id not in remaining_role_ids

    @pytest.mark.asyncio
    async def test_remove_roles_nonexistent_relation(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test remove nonexistent role relation"""
        user_serializer = UserSerializer(db_session)
        user = sample_users[2]  # Caster, may not have editor role
        role_ids = [sample_roles[1].id]  # Editor role

        # Try to remove possibly nonexistent role relation
        removed_count = await user_serializer.remove_roles(user.id, role_ids)

        # Remove count should be 0 or actual removed count
        assert removed_count >= 0

    @pytest.mark.asyncio
    async def test_get_user_by_email_private_method(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        pass  # Do not test private methods to avoid coupling with implementation details

    @pytest.mark.asyncio
    async def test_get_users_complex_search_params(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        pass  # Duplicate coverage with test_get_users_with_search, removed

    @pytest.mark.asyncio
    async def test_get_user_with_roles(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        pass  # Related test cases for get_user_permissions/roles already covered

    @pytest.mark.asyncio
    async def test_get_users_with_roles(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        pass  # Duplicate with pagination/search combination

    @pytest.mark.asyncio
    async def test_get_users_with_email_search(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        pass  # Duplicate coverage with test_get_users_with_search

    @pytest.mark.asyncio
    async def test_get_users_with_filters(
        self, db_session: AsyncSession, sample_users: list[UserWithPassword]
    ):
        pass  # Filter combination coverage is redundant

    @pytest.mark.asyncio
    async def test_get_user_permissions(
        self,
        db_session: AsyncSession,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
        sample_permissions: list[Permission],
    ):
        """Test get user permissions"""
        user_serializer = UserSerializer(db_session)
        user = sample_users[0]  # Saber

        # First assign a role with permissions to the user
        await user_serializer.assign_roles(user.id, [sample_roles[0].id], assigned_by=1)

        permissions = await user_serializer.get_user_permissions(user.id)

        assert isinstance(permissions, list)

    @pytest.mark.asyncio
    async def test_get_user_permissions_nonexistent_user(
        self, db_session: AsyncSession
    ):
        """Test get permissions for nonexistent user"""
        user_serializer = UserSerializer(db_session)

        with pytest.raises(NotFoundError) as exc_info:
            await user_serializer.get_user_permissions(99999)

        # The error message format is different
        assert "User 99999 not found" in str(exc_info.value.message)
