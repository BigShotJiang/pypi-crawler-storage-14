"""
Auto Generate Permissions Tests

Unit tests for the auto_generate_permissions_from_app function
that automatically extracts permissions from FastAPI routes.
"""

import pytest
import inspect
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from fastapi import FastAPI, Depends, APIRouter
from fastapi.routing import APIRoute
from sqlmodel.ext.asyncio.session import AsyncSession

from ..config import RBACConfig
from ..serializers.password_user_serializer import PasswordUserSerializer
from ..plugin import RBACPlugin, auto_generate_permissions_from_app
from ..dependencies.permission_dependencies import require_permissions
from ..schemas.permission_schemas import PermissionCreate
from ..config import register_rbac_config


class TestAutoGeneratePermissionsFromApp:
    """Test the auto_generate_permissions_from_app function"""

    @pytest.fixture
    def mock_session(self):
        """Create a mock AsyncSession"""
        return Mock(spec=AsyncSession)

    @pytest.fixture
    def mock_permission_serializer(self):
        """Create a mock PermissionSerializer"""
        serializer = Mock()
        serializer._get_permission_by_code = AsyncMock()
        serializer.create_permission = AsyncMock()
        return serializer

    @pytest.fixture
    def sample_app_with_permissions(self, mock_gen_rbac_async_session):
        """Create a FastAPI app with permission-protected routes"""
        app = FastAPI()
        register_rbac_config(
            app,
            RBACConfig(
                user_serializer=PasswordUserSerializer,
                custom_session_maker=mock_gen_rbac_async_session,
            ),
        )

        # Create test endpoints with permissions
        @app.get("/users")
        async def get_users(_: bool = Depends(require_permissions("user:read"))):
            return {"users": []}

        @app.post("/users")
        async def create_user(_: bool = Depends(require_permissions("user:create"))):
            return {"created": True}

        @app.get("/admin")
        async def admin_panel(
            _: bool = Depends(require_permissions("admin:read", "admin:write"))
        ):
            return {"admin": True}

        return app

    @pytest.fixture
    def empty_app(self):
        """Create a FastAPI app without any routes"""
        return FastAPI()

    @pytest.fixture
    def app_without_permissions(self):
        """Create a FastAPI app with routes but no permission dependencies"""
        app = FastAPI()

        @app.get("/public")
        async def public_endpoint():
            return {"public": True}

        @app.get("/other")
        async def other_endpoint(param: str):
            return {"param": param}

        return app

    @pytest.fixture
    def app_with_non_permission_dependencies(self):
        """Create a FastAPI app with non-permission dependencies"""
        app = FastAPI()

        def custom_dependency():
            return "custom"

        @app.get("/custom")
        async def custom_endpoint(_: str = Depends(custom_dependency)):
            return {"custom": True}

        return app

    @pytest.mark.asyncio
    async def test_auto_generate_with_permission_routes(
        self, sample_app_with_permissions, mock_session, mock_permission_serializer
    ):
        """Test auto-generating permissions from app with permission-protected routes"""
        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ) as mock_serializer_class:

            # Setup: no existing permissions - make this an async mock that returns None
            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            await auto_generate_permissions_from_app(
                sample_app_with_permissions, mock_session
            )

            # Verify PermissionSerializer was created
            mock_serializer_class.assert_called_once_with(mock_session)

            # Verify permissions were checked
            expected_codes = {"user:read", "user:create", "admin:read", "admin:write"}
            actual_calls = {
                call[0][0]
                for call in mock_permission_serializer._get_permission_by_code.call_args_list
            }
            assert expected_codes == actual_calls

            # Verify permissions were created
            assert mock_permission_serializer.create_permission.call_count == 4

            # Verify the permission creation calls
            create_calls = mock_permission_serializer.create_permission.call_args_list
            created_codes = {call[0][0].code for call in create_calls}
            assert created_codes == expected_codes

    @pytest.mark.asyncio
    async def test_auto_generate_with_existing_permissions(
        self, sample_app_with_permissions, mock_session, mock_permission_serializer
    ):
        """Test auto-generating when some permissions already exist"""
        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ):
            # Setup: some permissions already exist
            async def mock_get_permission(code):
                if code == "user:read":
                    return Mock(code=code)  # Existing permission
                return None  # Not existing

            mock_permission_serializer._get_permission_by_code = AsyncMock(
                side_effect=mock_get_permission
            )

            await auto_generate_permissions_from_app(
                sample_app_with_permissions, mock_session
            )

            # Verify only missing permissions were created (3 out of 4)
            assert mock_permission_serializer.create_permission.call_count == 3

            # Verify the created permissions don't include the existing one
            create_calls = mock_permission_serializer.create_permission.call_args_list
            created_codes = {call[0][0].code for call in create_calls}
            assert "user:read" not in created_codes
            assert {"user:create", "admin:read", "admin:write"} == created_codes

    @pytest.mark.asyncio
    async def test_auto_generate_with_empty_app(
        self, empty_app, mock_session, mock_permission_serializer
    ):
        """Test auto-generating permissions from empty app"""
        with (
            patch(
                "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
                return_value=mock_permission_serializer,
            ),
            patch("builtins.print") as mock_print,
        ):

            await auto_generate_permissions_from_app(empty_app, mock_session)

            # Verify no permissions were processed
            mock_permission_serializer._get_permission_by_code.assert_not_called()
            mock_permission_serializer.create_permission.assert_not_called()

            # Verify appropriate message was printed
            mock_print.assert_called_with(
                "[auto_generate_permissions_from_app] No permissions found in app routes."
            )

    @pytest.mark.asyncio
    async def test_auto_generate_with_app_without_permissions(
        self, app_without_permissions, mock_session, mock_permission_serializer
    ):
        """Test auto-generating from app without permission dependencies"""
        with (
            patch(
                "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
                return_value=mock_permission_serializer,
            ),
            patch("builtins.print") as mock_print,
        ):

            await auto_generate_permissions_from_app(
                app_without_permissions, mock_session
            )

            # Verify no permissions were processed
            mock_permission_serializer._get_permission_by_code.assert_not_called()
            mock_permission_serializer.create_permission.assert_not_called()

            # Verify appropriate message was printed
            mock_print.assert_called_with(
                "[auto_generate_permissions_from_app] No permissions found in app routes."
            )

    @pytest.mark.asyncio
    async def test_auto_generate_with_non_permission_dependencies(
        self,
        app_with_non_permission_dependencies,
        mock_session,
        mock_permission_serializer,
    ):
        """Test auto-generating from app with non-permission dependencies"""
        with (
            patch(
                "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
                return_value=mock_permission_serializer,
            ),
            patch("builtins.print") as mock_print,
        ):

            await auto_generate_permissions_from_app(
                app_with_non_permission_dependencies, mock_session
            )

            # Verify no permissions were processed
            mock_permission_serializer._get_permission_by_code.assert_not_called()
            mock_permission_serializer.create_permission.assert_not_called()

            # Verify appropriate message was printed
            mock_print.assert_called_with(
                "[auto_generate_permissions_from_app] No permissions found in app routes."
            )

    @pytest.mark.asyncio
    async def test_permission_creation_with_colon_separator(
        self, mock_session, mock_permission_serializer
    ):
        """Test permission creation with resource:action format"""
        app = FastAPI()

        @app.get("/test")
        async def test_endpoint(_: bool = Depends(require_permissions("user:read"))):
            return {}

        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ):
            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            await auto_generate_permissions_from_app(app, mock_session)

            # Verify permission was created with correct resource and action
            create_call = mock_permission_serializer.create_permission.call_args_list[0]
            permission_data = create_call[0][0]

            assert permission_data.code == "user:read"
            assert permission_data.resource == "user"
            assert permission_data.action == "read"

    @pytest.mark.asyncio
    async def test_permission_creation_without_colon_separator(
        self, mock_session, mock_permission_serializer
    ):
        """Test permission creation without resource:action format"""
        app = FastAPI()

        @app.get("/test")
        async def test_endpoint(_: bool = Depends(require_permissions("admin_access"))):
            return {}

        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ):
            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            await auto_generate_permissions_from_app(app, mock_session)

            # Verify permission was created with default action
            create_call = mock_permission_serializer.create_permission.call_args_list[0]
            permission_data = create_call[0][0]

            assert permission_data.code == "admin_access"
            assert permission_data.resource == "admin_access"
            assert permission_data.action == "access"

    @pytest.mark.asyncio
    async def test_permission_creation_error_handling(
        self, sample_app_with_permissions, mock_session, mock_permission_serializer
    ):
        """Test error handling during permission creation"""
        with (
            patch(
                "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
                return_value=mock_permission_serializer,
            ),
            patch("builtins.print") as mock_print,
        ):

            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            # Make create_permission raise an exception for one permission
            async def mock_create_permission(permission_data):
                if permission_data.code == "user:read":
                    raise Exception("Database error")
                return Mock()

            mock_permission_serializer.create_permission.side_effect = (
                mock_create_permission
            )

            await auto_generate_permissions_from_app(
                sample_app_with_permissions, mock_session
            )

            # Verify error was printed but function continued
            error_prints = [
                call
                for call in mock_print.call_args_list
                if "Failed to create" in str(call)
            ]
            assert len(error_prints) > 0
            assert "user:read" in str(error_prints[0])
            assert "Database error" in str(error_prints[0])

    @pytest.mark.asyncio
    async def test_app_with_router_permissions(
        self, mock_session, mock_permission_serializer
    ):
        """Test auto-generating permissions from app with APIRouter"""
        app = FastAPI()
        router = APIRouter()

        @router.get("/router-endpoint")
        async def router_endpoint(
            _: bool = Depends(require_permissions("router:read")),
        ):
            return {}

        app.include_router(router)

        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ):
            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            await auto_generate_permissions_from_app(app, mock_session)

            # Verify router permissions were found and created
            assert mock_permission_serializer.create_permission.call_count == 1
            create_call = mock_permission_serializer.create_permission.call_args_list[0]
            assert create_call[0][0].code == "router:read"

    @pytest.mark.asyncio
    async def test_permission_data_structure(
        self, mock_session, mock_permission_serializer
    ):
        """Test the structure of created permission data"""
        app = FastAPI()

        @app.get("/test")
        async def test_endpoint(
            _: bool = Depends(require_permissions("test:permission")),
        ):
            return {}

        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ):
            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            await auto_generate_permissions_from_app(app, mock_session)

            # Verify permission data structure
            create_call = mock_permission_serializer.create_permission.call_args_list[0]
            permission_data = create_call[0][0]

            assert isinstance(permission_data, PermissionCreate)
            assert permission_data.code == "test:permission"
            assert permission_data.name == "test:permission"
            assert (
                permission_data.description
                == "Auto-generated permission for test:permission"
            )
            assert permission_data.resource == "test"
            assert permission_data.action == "permission"
            assert permission_data.permission_type == "function"
            assert permission_data.is_active is True
            assert permission_data.is_system is False

    @pytest.mark.asyncio
    async def test_complex_permission_extraction(
        self, mock_session, mock_permission_serializer
    ):
        """Test extraction from complex route setup"""
        app = FastAPI()

        # Multiple permissions in one endpoint
        @app.get("/multi")
        async def multi_permission_endpoint(
            _: bool = Depends(
                require_permissions("read:data", "write:data", "delete:data")
            )
        ):
            return {}

        # Mixed dependencies
        def other_dep():
            return "other"

        @app.post("/mixed")
        async def mixed_dependencies(
            _: str = Depends(other_dep),
            __: bool = Depends(require_permissions("mixed:access")),
        ):
            return {}

        with patch(
            "fastapi_rbac.serializers.permission_serializer.PermissionSerializer",
            return_value=mock_permission_serializer,
        ):
            mock_permission_serializer._get_permission_by_code = AsyncMock(
                return_value=None
            )

            await auto_generate_permissions_from_app(app, mock_session)

            # Should find 4 permissions total
            assert mock_permission_serializer.create_permission.call_count == 4

            # Verify all expected permissions were created
            create_calls = mock_permission_serializer.create_permission.call_args_list
            created_codes = {call[0][0].code for call in create_calls}
            expected_codes = {"read:data", "write:data", "delete:data", "mixed:access"}
            assert created_codes == expected_codes
