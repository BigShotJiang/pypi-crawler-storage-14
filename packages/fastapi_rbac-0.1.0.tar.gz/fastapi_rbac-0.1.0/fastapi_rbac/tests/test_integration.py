#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:44:06
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""


import pytest
from fastapi.testclient import TestClient
from sqlmodel.ext.asyncio.session import AsyncSession
import uuid

from ..models import Role, UserRoleRelation
from ..models.pwd_user_model import UserWithPassword


class TestRBACIntegration:
    """RBAC integration test"""

    def test_complete_rbac_workflow(
        self,
        client: TestClient,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test complete RBAC workflow"""
        # Use UUID suffix to avoid role name conflicts
        unique_suffix = str(uuid.uuid4())[:8]

        # 1. Create new role
        role_data = {
            "name": f"Integration test role_{unique_suffix}",
            "description": "Role for integration test",
            "is_active": True,
            "is_system": False,
        }

        response = client.post("/rbac/roles", json=role_data)
        assert response.status_code == 201
        role_id = response.json()["id"]

        # 2. Get user list
        response = client.get("/rbac/users")
        assert response.status_code == 200
        users_data = response.json()
        assert len(users_data["items"]) >= 3

        # 3. Assign user to role
        user_id = users_data["items"][0]["id"]
        assignment_data = {"user_ids": [user_id], "assigned_by": 1}

        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)
        assert response.status_code == 200

        # 4. Verify user role association
        response = client.get(f"/rbac/users/{user_id}/roles")
        assert response.status_code == 200
        user_roles = response.json()
        role_names = [role["name"] for role in user_roles]
        assert f"Integration test role_{unique_suffix}" in role_names

        # 5. Get role user list
        response = client.get(f"/rbac/roles/{role_id}/users")
        assert response.status_code == 200
        role_users = response.json()
        user_ids = [user["id"] for user in role_users]
        assert user_id in user_ids

        # 6. Remove user from role
        response = client.delete(f"/rbac/roles/{role_id}/users/{user_id}")
        assert response.status_code == 204

        # 7. Verify user role removed
        response = client.get(f"/rbac/users/{user_id}/roles")
        assert response.status_code == 200
        user_roles = response.json()
        role_names = [role["name"] for role in user_roles]
        assert f"Integration test role_{unique_suffix}" not in role_names

        # 8. Delete role
        response = client.delete(f"/rbac/roles/{role_id}")
        assert response.status_code == 204

        # 9. Verify role deleted
        response = client.get(f"/rbac/roles/{role_id}")
        assert response.status_code == 404

    def test_role_search_and_filter(self, client: TestClient, sample_roles: list[Role]):
        """Test role search and filter"""

        # Search by name
        response = client.get("/rbac/roles?name=Admin")
        assert response.status_code == 200
        data = response.json()
        assert len(data["items"]) >= 1
        for role in data["items"]:
            assert "Admin" in role["name"]

        # Filter by status
        response = client.get("/rbac/roles?is_active=true")
        assert response.status_code == 200
        data = response.json()
        for role in data["items"]:
            assert role["is_active"] is True

        # Filter by system role
        response = client.get("/rbac/roles?is_system=true")
        assert response.status_code == 200
        data = response.json()
        for role in data["items"]:
            assert role["is_system"] is True

    def test_user_search_and_filter(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test user search and filter"""

        # Search by name
        response = client.get("/rbac/users?name=Saber")
        assert response.status_code == 200
        data = response.json()
        assert "Saber" in [user["name"] for user in data["items"]]

        # Search by email
        response = client.get("/rbac/users?email=baseuser1@example.com")
        assert response.status_code == 200
        data = response.json()
        assert "baseuser1@example.com" in [user["email"] for user in data["items"]]

        # Filter by status
        response = client.get("/rbac/users?status=1")
        assert response.status_code == 200
        data = response.json()
        assert 1 in [user["status"] for user in data["items"]]

    def test_pagination_consistency(
        self,
        client: TestClient,
        sample_users: list[UserWithPassword],
        sample_roles: list[Role],
    ):
        """Test pagination consistency"""

        # Test user pagination
        page1_response = client.get("/rbac/users?page=1&size=2")
        assert page1_response.status_code == 200
        page1_data = page1_response.json()

        page2_response = client.get("/rbac/users?page=2&size=2")
        assert page2_response.status_code == 200
        page2_data = page2_response.json()

        # Ensure pagination data is not duplicated
        page1_ids = {user["id"] for user in page1_data["items"]}
        page2_ids = {user["id"] for user in page2_data["items"]}
        assert page1_ids.isdisjoint(page2_ids)

        # Test role pagination
        page1_response = client.get("/rbac/roles?page=1&size=2")
        assert page1_response.status_code == 200
        page1_data = page1_response.json()

        page2_response = client.get("/rbac/roles?page=2&size=2")
        assert page2_response.status_code == 200
        page2_data = page2_response.json()

        # Ensure pagination data is not duplicated
        page1_ids = {role["id"] for role in page1_data["items"]}
        page2_ids = {role["id"] for role in page2_data["items"]}
        assert page1_ids.isdisjoint(page2_ids)

    def test_concurrent_role_operations(
        self, client: TestClient, sample_users: list[UserWithPassword]
    ):
        """Test concurrent role operations"""
        # Use UUID suffix to avoid role name conflicts
        unique_suffix = str(uuid.uuid4())[:8]

        # Create multiple roles
        roles = []
        for i in range(3):
            role_data = {
                "name": f"Concurrent test role_{i}_{unique_suffix}",
                "description": f"The {i}th concurrent test role",
                "is_active": True,
                "is_system": False,
            }
            response = client.post("/rbac/roles", json=role_data)
            assert response.status_code == 201
            roles.append(response.json())

        # Assign multiple roles to the same user
        user_id = sample_users[0].id
        for role in roles:
            assignment_data = {"user_ids": [user_id], "assigned_by": 1}
            response = client.post(
                f"/rbac/roles/{role['id']}/users", json=assignment_data
            )
            assert response.status_code == 200

        # Verify user has all roles
        response = client.get(f"/rbac/users/{user_id}/roles")
        assert response.status_code == 200
        user_roles = response.json()
        role_names = {role["name"] for role in user_roles}

        for i in range(3):
            assert f"Concurrent test role_{i}_{unique_suffix}" in role_names

    def test_error_handling_integration(
        self, client: TestClient, sample_roles: list[Role]
    ):
        """Test error handling integration"""

        # Test creating duplicate role
        role_data = {
            "name": sample_roles[0].name,  # Use existing name
            "description": "Duplicate role test",
        }
        response = client.post("/rbac/roles", json=role_data)
        assert response.status_code == 400

        # Test assigning nonexistent user
        role_id = sample_roles[0].id
        assignment_data = {"user_ids": [99999], "assigned_by": 1}
        response = client.post(f"/rbac/roles/{role_id}/users", json=assignment_data)
        assert response.status_code == 400

        # Test deleting system role
        system_role = next((role for role in sample_roles if role.is_system), None)
        if system_role:
            response = client.delete(f"/rbac/roles/{system_role.id}")
            assert response.status_code == 400

        # Test invalid parameters
        response = client.get("/rbac/users?page=0")  # Page number cannot be 0
        assert response.status_code == 422

        response = client.get("/rbac/users?size=200")  # Page size exceeds limit
        assert response.status_code == 422
