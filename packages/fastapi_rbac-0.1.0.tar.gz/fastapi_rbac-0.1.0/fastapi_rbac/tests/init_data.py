#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-01-17
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Test data initialization utilities
All Rights Reserved.
"""

from typing import List
from sqlmodel.ext.asyncio.session import AsyncSession

from ..models import Role, UserRoleRelation, Permission
from ..models.pwd_user_model import UserWithPassword


def create_base_users() -> List[UserWithPassword]:
    """Create base users for testing"""
    return [
        UserWithPassword(
            name="Saber",
            en_name="Base User 1",
            email="baseuser1@example.com",
            mobile="13800138001",
            user_id="baseuser1",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        ),
        UserWithPassword(
            name="Acher",
            en_name="Base User 2",
            email="baseuser2@example.com",
            mobile="13800138002",
            user_id="baseuser2",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        ),
        UserWithPassword(
            name="Caster",
            en_name="Base User 3",
            email="baseuser3@example.com",
            mobile="13800138003",
            user_id="baseuser3",
            status=0,
            locked=1,
            password="y6ZreZqlZeBeIl",
        ),
    ]


def create_base_roles() -> List[Role]:
    """Create base roles for testing"""
    return [
        Role(
            name="BaseAdmin",
            description="Base admin role",
            is_active=True,
            is_system=True,
        ),
        Role(
            name="BaseEditor",
            description="Base editor role",
            is_active=True,
            is_system=False,
        ),
        Role(
            name="BaseViewer",
            description="Base viewer role",
            is_active=True,
            is_system=False,
        ),
        Role(
            name="BaseDisabled",
            description="Base disabled role",
            is_active=False,
            is_system=False,
        ),
    ]


def create_base_permissions() -> List[Permission]:
    """Create base permissions for testing"""
    return [
        Permission(
            code="base:user:read",
            name="Base user read permission",
            description="Allow reading user information",
            resource="user",
            action="read",
            permission_type="function",
            is_active=True,
            is_system=False,
        ),
        Permission(
            code="base:user:write",
            name="Base user write permission",
            description="Allow creating and updating users",
            resource="user",
            action="write",
            permission_type="function",
            is_active=True,
            is_system=False,
        ),
        Permission(
            code="base:role:manage",
            name="Base role management permission",
            description="Allow managing role information",
            resource="role",
            action="manage",
            permission_type="function",
            is_active=True,
            is_system=True,
        ),
        Permission(
            code="base:system:admin",
            name="Base system admin permission",
            description="Base system admin permission",
            resource="system",
            action="admin",
            permission_type="function",
            is_active=True,
            is_system=True,
        ),
        Permission(
            code="base:api:access",
            name="Base API access permission",
            description="Allow accessing API interfaces",
            resource="api",
            action="access",
            permission_type="api",
            is_active=False,
            is_system=False,
        ),
    ]


def create_base_user_role_relations(
    base_users: List[UserWithPassword], base_roles: List[Role]
) -> List[UserRoleRelation]:
    """Create base user role relations for testing"""
    # Ensure we have the IDs (should be available after refresh)
    if not all(user.id for user in base_users):
        raise ValueError(
            "User IDs are not available. Users need to be committed and refreshed first."
        )
    if not all(role.id for role in base_roles):
        raise ValueError(
            "Role IDs are not available. Roles need to be committed and refreshed first."
        )

    return [
        UserRoleRelation(
            user_id=base_users[0].id,
            role_id=base_roles[0].id,  # Saber -> BaseAdmin
            assigned_by=1,
            is_active=True,
        ),
        UserRoleRelation(
            user_id=base_users[1].id,
            role_id=base_roles[1].id,  # Acher -> BaseEditor
            assigned_by=1,
            is_active=True,
        ),
        UserRoleRelation(
            user_id=base_users[1].id,
            role_id=base_roles[2].id,  # Acher -> BaseViewer
            assigned_by=1,
            is_active=True,
        ),
        UserRoleRelation(
            user_id=base_users[2].id,
            role_id=base_roles[2].id,  # Caster -> BaseViewer
            assigned_by=1,
            is_active=False,  # Disabled
        ),
    ]


async def initialize_base_data(session: AsyncSession) -> None:
    """Initialize all base data in the database"""
    # Create base users
    base_users = create_base_users()
    session.add_all(base_users)
    await session.commit()

    # Create base roles
    base_roles = create_base_roles()
    session.add_all(base_roles)
    await session.commit()

    # Create base permissions
    base_permissions = create_base_permissions()
    session.add_all(base_permissions)
    await session.commit()

    # Create base user-role relations using explicit IDs
    # We know the IDs will be 1, 2, 3 for users and 1, 2, 3, 4 for roles
    base_user_roles = [
        UserRoleRelation(
            user_id=1,  # Saber
            role_id=1,  # BaseAdmin
            assigned_by=1,
            is_active=True,
        ),
        UserRoleRelation(
            user_id=2,  # Acher
            role_id=2,  # BaseEditor
            assigned_by=1,
            is_active=True,
        ),
        UserRoleRelation(
            user_id=2,  # Acher
            role_id=3,  # BaseViewer
            assigned_by=1,
            is_active=True,
        ),
        UserRoleRelation(
            user_id=3,  # Caster
            role_id=3,  # BaseViewer
            assigned_by=1,
            is_active=False,  # Disabled
        ),
    ]
    session.add_all(base_user_roles)
    await session.commit()


def create_dynamic_users(unique_suffix: str) -> List[UserWithPassword]:
    """Create dynamic users with unique suffix for testing"""
    return [
        UserWithPassword(
            name=f"DynamicUser1_{unique_suffix}",
            en_name=f"Dynamic User 1 {unique_suffix}",
            email=f"dynamicuser1_{unique_suffix}@example.com",
            mobile=f"1380013800{unique_suffix[:1]}",
            user_id=f"dynamicuser1_{unique_suffix}",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        ),
        UserWithPassword(
            name=f"DynamicUser2_{unique_suffix}",
            en_name=f"Dynamic User 2 {unique_suffix}",
            email=f"dynamicuser2_{unique_suffix}@example.com",
            mobile=f"1380013801{unique_suffix[:1]}",
            user_id=f"dynamicuser2_{unique_suffix}",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        ),
    ]


def create_dynamic_roles(unique_suffix: str) -> List[Role]:
    """Create dynamic roles with unique suffix for testing"""
    return [
        Role(
            name=f"DynamicRole1_{unique_suffix}",
            description=f"Dynamic role 1 {unique_suffix}",
            is_active=True,
            is_system=False,
        ),
        Role(
            name=f"DynamicRole2_{unique_suffix}",
            description=f"Dynamic role 2 {unique_suffix}",
            is_active=True,
            is_system=False,
        ),
    ]


def create_dynamic_permissions(unique_suffix: str) -> List[Permission]:
    """Create dynamic permissions with unique suffix for testing"""
    return [
        Permission(
            code=f"dynamic:test:read_{unique_suffix}",
            name=f"Dynamic test read permission {unique_suffix}",
            description="Dynamic test permission",
            resource="test",
            action="read",
            permission_type="function",
            is_active=True,
            is_system=False,
        ),
        Permission(
            code=f"dynamic:test:write_{unique_suffix}",
            name=f"Dynamic test write permission {unique_suffix}",
            description="Dynamic test permission",
            resource="test",
            action="write",
            permission_type="function",
            is_active=True,
            is_system=False,
        ),
    ]


async def create_dynamic_test_data(session: AsyncSession, unique_suffix: str) -> dict:
    """Create dynamic test data with unique suffix"""
    # Create dynamic users
    dynamic_users = create_dynamic_users(unique_suffix)

    # Create dynamic roles
    dynamic_roles = create_dynamic_roles(unique_suffix)

    # Create dynamic permissions
    dynamic_permissions = create_dynamic_permissions(unique_suffix)

    # Batch insert
    session.add_all(dynamic_users)
    session.add_all(dynamic_roles)
    session.add_all(dynamic_permissions)
    await session.commit()

    # Refresh to get IDs
    for user in dynamic_users:
        await session.refresh(user)
    for role in dynamic_roles:
        await session.refresh(role)
    for permission in dynamic_permissions:
        await session.refresh(permission)

    return {
        "users": dynamic_users,
        "roles": dynamic_roles,
        "permissions": dynamic_permissions,
        "unique_suffix": unique_suffix,
    }
