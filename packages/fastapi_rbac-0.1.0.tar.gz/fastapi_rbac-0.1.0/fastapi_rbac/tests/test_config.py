#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 14:19:04
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: ...
All Rights Reserved.
"""

from unittest.mock import patch
import os
import pytest

from ..config import (
    RBACConfig,
)


class TestRBACConfig:
    """RBAC Config Test"""

    def test_default_rbac_config(self, mock_gen_rbac_async_session):
        """Test default RBAC config"""
        from ..serializers.password_user_serializer import PasswordUserSerializer

        config = RBACConfig(
            # database_url="sqlite+aiosqlite:///:memory:",
            custom_session_maker=mock_gen_rbac_async_session,
            user_serializer=PasswordUserSerializer,
        )

        assert config.cache_ttl == 3600
        assert config.enable_cache is False

        assert config.default_user_role == "User"
        assert config.system_roles == ["Super Admin", "Admin", "User"]

        assert config.log_level == "INFO"
        assert config.enable_audit_log is True

    def test_rbac_config_with_env_vars(self, mock_gen_rbac_async_session):
        """Test RBAC config with environment variables"""
        from ..serializers.password_user_serializer import PasswordUserSerializer

        env_vars = {
            "RBAC_CACHE_TTL": "7200",
            "RBAC_DEFAULT_PAGE_SIZE": "10",
            "RBAC_MAX_PAGE_SIZE": "50",
            "RBAC_DEFAULT_USER_ROLE": "User",
            "RBAC_LOG_LEVEL": "DEBUG",
        }

        with patch.dict(os.environ, env_vars):
            config = RBACConfig(
                # database_url="sqlite+aiosqlite:///:memory:",
                custom_session_maker=mock_gen_rbac_async_session,
                user_serializer=PasswordUserSerializer,
            )

            assert config.cache_ttl == 7200
            assert config.enable_cache is False
            assert config.log_level == "DEBUG"

    def test_validation_default_user_role_in_system_roles(
        self, mock_gen_rbac_async_session
    ):
        """Test validation: default_user_role must be in system_roles"""
        from ..serializers.password_user_serializer import PasswordUserSerializer

        config = RBACConfig(
            # database_url="sqlite+aiosqlite:///:memory:",
            custom_session_maker=mock_gen_rbac_async_session,
            user_serializer=PasswordUserSerializer,
            default_user_role="User",
            system_roles=["Super Admin", "Admin", "User"],
        )
        assert config.default_user_role == "User"

    def test_validation_default_user_role_not_in_system_roles(
        self, mock_gen_rbac_async_session
    ):
        """Test validation: default_user_role not in system_roles should fail"""
        from ..serializers.password_user_serializer import PasswordUserSerializer

        with pytest.raises(
            ValueError, match="default_user_role 'Guest' is not in system_roles"
        ):
            RBACConfig(
                # database_url="sqlite+aiosqlite:///:memory:",
                custom_session_maker=mock_gen_rbac_async_session,
                user_serializer=PasswordUserSerializer,
                default_user_role="Guest",
                system_roles=["Super Admin", "Admin", "User"],
            )

    def test_validation_user_serializer_inheritance(self, mock_gen_rbac_async_session):
        """Test validation: user_serializer must inherit from BaseUserSerializer"""
        from ..serializers.password_user_serializer import PasswordUserSerializer

        config = RBACConfig(
            # database_url="sqlite+aiosqlite:///:memory:",
            custom_session_maker=mock_gen_rbac_async_session,
            user_serializer=PasswordUserSerializer,
        )
        assert config.user_serializer == PasswordUserSerializer

    def test_validation_user_serializer_invalid_type(self, mock_gen_rbac_async_session):
        """Test validation: invalid user_serializer type should fail"""
        from pydantic import ValidationError

        with pytest.raises(
            ValidationError, match="Input should be a subclass of BaseUserSerializer"
        ):
            RBACConfig(
                # database_url="sqlite+aiosqlite:///:memory:",
                custom_session_maker=mock_gen_rbac_async_session,
                user_serializer=str,
            )
