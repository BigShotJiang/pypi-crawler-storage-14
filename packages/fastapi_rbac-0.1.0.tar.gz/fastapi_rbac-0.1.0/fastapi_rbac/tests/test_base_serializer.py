#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 14:22:12
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Base serializer test
    Test BaseSerializer's generic CRUD operations and exception handling.
All Rights Reserved.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.exc import SQLAlchemyError

from ..serializers.exceptions import DatabaseError

from ..models.pwd_user_model import UserWithPassword
from ..serializers.base_serializer import BaseSerializer, NotFoundError
from ..schemas import PaginationParams
from ..models.pwd_user_model import UserWithPassword
from ..models import get_user_model


class TestDatabaseError:
    """Database error test"""

    def test_database_error_with_message_only(self):
        """Test database error with message only"""
        error = DatabaseError("Test error")
        assert error.message == "Test error"
        assert error.details == {}
        assert str(error) == "Test error"

    def test_database_error_with_details(self):
        """Test database error with details"""
        details = {"code": 500, "field": "email"}
        error = DatabaseError("Test error", details)
        assert error.message == "Test error"
        assert error.details == details


class TestNotFoundError:
    """Resource not found error test"""

    def test_not_found_error_creation(self):
        """Test NotFoundError creation"""
        error = NotFoundError("User", 123)
        assert error.resource == "User"
        assert error.identifier == 123
        assert error.message == "User with identifier 123 not found"
        assert str(error) == "User with identifier 123 not found"


class TestBaseSerializer:
    """Base serializer test"""

    @pytest.fixture
    def mock_db_session(self):
        """Mock database session"""
        return AsyncMock(spec=AsyncSession)

    @pytest.fixture
    def base_serializer(self, mock_db_session):
        """Base serializer instance"""
        return BaseSerializer(mock_db_session, UserWithPassword)

    @pytest.mark.asyncio
    async def test_create_success(self, base_serializer, mock_db_session):
        """Test successful record creation"""
        # Prepare test data
        create_data = UserWithPassword(
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Mock database operation
        # mock_user = UserWithPassword(id=1, **create_data.model_dump())
        mock_db_session.add = MagicMock()
        mock_db_session.commit = AsyncMock()
        mock_db_session.refresh = AsyncMock()

        # Execute create operation
        result = await base_serializer.create(create_data)

        # Verify result
        assert isinstance(result, UserWithPassword)
        mock_db_session.add.assert_called_once()
        mock_db_session.commit.assert_called_once()
        mock_db_session.refresh.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_sqlalchemy_error(self, base_serializer, mock_db_session):
        """Test SQLAlchemy error during record creation"""
        # User = get_user_model()
        create_data = UserWithPassword(
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Mock SQLAlchemy error
        mock_db_session.add = MagicMock()
        mock_db_session.commit = AsyncMock(
            side_effect=SQLAlchemyError("Database error")
        )
        mock_db_session.rollback = AsyncMock()

        # Verify exception
        with pytest.raises(DatabaseError) as exc_info:
            await base_serializer.create(create_data)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "CREATE_FAILED"
        assert exc_info.value.message_category == "BASE"
        assert "User" in exc_info.value.message
        mock_db_session.rollback.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_unknown_error(self, base_serializer, mock_db_session):
        """Test unknown error during record creation"""
        # User = get_user_model()
        create_data = UserWithPassword(
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="123456",
        )

        # Mock unknown error
        mock_db_session.add = MagicMock(side_effect=ValueError("Unknown error"))
        mock_db_session.rollback = AsyncMock()

        # Verify exception
        with pytest.raises(DatabaseError) as exc_info:
            await base_serializer.create(create_data)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "CREATE_FAILED"
        assert exc_info.value.message_category == "BASE"
        assert "User" in exc_info.value.message
        mock_db_session.rollback.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_by_id_success(self, base_serializer, mock_db_session):
        """Test successful record retrieval by ID"""
        # Mock query result
        mock_user = UserWithPassword(
            id=1,
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )
        mock_result = MagicMock()
        mock_result.first.return_value = mock_user
        mock_db_session.exec = AsyncMock(return_value=mock_result)

        # Execute query
        result = await base_serializer.get_by_id(1)

        # Verify result
        assert result == mock_user
        mock_db_session.exec.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_by_id_not_found(self, base_serializer, mock_db_session):
        """Test record not found by ID"""
        # Mock query result
        mock_result = MagicMock()
        mock_result.first.return_value = None
        mock_db_session.exec = AsyncMock(return_value=mock_result)

        # Execute query
        result = await base_serializer.get_by_id(999)

        # Verify result
        assert result is None

    @pytest.mark.asyncio
    async def test_get_by_id_sqlalchemy_error(self, base_serializer, mock_db_session):
        """Test SQLAlchemy error during record retrieval by ID"""
        # Mock SQLAlchemy error
        mock_db_session.exec = AsyncMock(
            side_effect=SQLAlchemyError("SQLAlchemy error")
        )

        # Verify exception
        with pytest.raises(DatabaseError) as exc_info:
            await base_serializer.get_by_id(1)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "GET_FAILED"
        assert exc_info.value.message_category == "BASE"
        assert "User" in exc_info.value.message

    @pytest.mark.asyncio
    async def test_get_by_id_or_404_success(self, base_serializer, mock_db_session):
        """Test successful record retrieval or 404"""
        # Mock query result
        mock_user = UserWithPassword(
            id=1,
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )
        mock_result = MagicMock()
        mock_result.first.return_value = mock_user
        mock_db_session.exec = AsyncMock(return_value=mock_result)

        # Execute query
        result = await base_serializer.get_by_id_or_404(1)

        # Verify result
        assert result == mock_user

    @pytest.mark.asyncio
    async def test_get_by_id_or_404_not_found(self, base_serializer, mock_db_session):
        """Test NotFoundError when record not found"""
        # Mock query result
        mock_result = MagicMock()
        mock_result.first.return_value = None
        mock_db_session.exec = AsyncMock(return_value=mock_result)

        # Verify exception
        with pytest.raises(NotFoundError) as exc_info:
            await base_serializer.get_by_id_or_404(999)

        assert "User" in exc_info.value.message and "999" in exc_info.value.message

    @pytest.mark.asyncio
    async def test_update_success(self, base_serializer, mock_db_session):
        """Test successful record update"""
        # Prepare test data
        # User = get_user_model()
        update_data = UserWithPassword(
            name="Updated user name",
            en_name="updated_user",
            email="updated@example.com",
            mobile="13800138001",
            user_id="updated_001",
            status=1,
            locked=0,
            last_login=None,
            password="y6ZreZqlZeBeIl",
        )
        mock_user = UserWithPassword(
            id=1,
            name="Original user name",
            en_name="original_user",
            email="original@example.com",
            mobile="13800138000",
            user_id="original_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Mock query and update
        mock_result = MagicMock()
        mock_result.first.return_value = mock_user
        mock_db_session.exec = AsyncMock(return_value=mock_result)
        mock_db_session.commit = AsyncMock()
        mock_db_session.refresh = AsyncMock()

        # Execute update
        result = await base_serializer.update(1, update_data)

        # Verify result
        assert result == mock_user
        assert mock_user.name == "Updated user name"
        assert mock_user.email == "updated@example.com"
        mock_db_session.commit.assert_called_once()
        mock_db_session.refresh.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_not_found(self, base_serializer, mock_db_session):
        """Test update not found"""
        # User = get_user_model()
        update_data = UserWithPassword(
            name="Updated user name",
            en_name="updated_user",
            email="updated@example.com",
            mobile="13800138001",
            user_id="updated_001",
            status=1,
            locked=0,
            last_login=None,
            password="y6ZreZqlZeBeIl",
        )

        # Mock query result
        mock_result = MagicMock()
        mock_result.first.return_value = None
        mock_db_session.exec = AsyncMock(return_value=mock_result)

        # Verify exception
        with pytest.raises(NotFoundError):
            await base_serializer.update(999, update_data)

    @pytest.mark.asyncio
    async def test_update_sqlalchemy_error(self, base_serializer, mock_db_session):
        """Test SQLAlchemy error during record update"""
        # User = get_user_model()
        update_data = UserWithPassword(
            name="Updated user name",
            en_name="updated_user",
            email="updated@example.com",
            mobile="13800138001",
            user_id="updated_001",
            status=1,
            locked=0,
            last_login=None,
            password="y6ZreZqlZeBeIl",
        )
        mock_user = UserWithPassword(
            id=1,
            name="Original user name",
            en_name="original_user",
            email="original@example.com",
            mobile="13800138000",
            user_id="original_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Mock query success but commit failed
        mock_result = MagicMock()
        mock_result.first.return_value = mock_user
        mock_db_session.exec = AsyncMock(return_value=mock_result)
        mock_db_session.commit = AsyncMock(side_effect=SQLAlchemyError("Update error"))
        mock_db_session.rollback = AsyncMock()

        # Verify exception
        with pytest.raises(DatabaseError) as exc_info:
            await base_serializer.update(1, update_data)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "UPDATE_FAILED"
        assert exc_info.value.message_category == "BASE"
        assert "User" in exc_info.value.message
        mock_db_session.rollback.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_success(self, base_serializer, mock_db_session):
        """Test successful record deletion"""
        mock_user = UserWithPassword(
            id=1,
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Mock query and delete
        mock_result = MagicMock()
        mock_result.first.return_value = mock_user
        mock_db_session.exec = AsyncMock(return_value=mock_result)
        mock_db_session.delete = AsyncMock()
        mock_db_session.commit = AsyncMock()

        # Execute delete
        result = await base_serializer.delete(1)

        # Verify result
        assert result is True
        mock_db_session.delete.assert_called_once_with(mock_user)
        mock_db_session.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_not_found(self, base_serializer, mock_db_session):
        """Test delete not found"""
        # Mock query result
        mock_result = MagicMock()
        mock_result.first.return_value = None
        mock_db_session.exec = AsyncMock(return_value=mock_result)

        # Verify exception
        with pytest.raises(NotFoundError):
            await base_serializer.delete(999)

    @pytest.mark.asyncio
    async def test_delete_sqlalchemy_error(self, base_serializer, mock_db_session):
        """Test SQLAlchemy error during record deletion"""
        mock_user = UserWithPassword(
            id=1,
            name="Test user",
            en_name="test_user",
            email="test@example.com",
            mobile="13800138000",
            user_id="test_001",
            status=1,
            locked=0,
            password="y6ZreZqlZeBeIl",
        )

        # Mock query success but delete failed
        mock_result = MagicMock()
        mock_result.first.return_value = mock_user
        mock_db_session.exec = AsyncMock(return_value=mock_result)
        mock_db_session.delete = AsyncMock(side_effect=SQLAlchemyError("Delete error"))
        mock_db_session.rollback = AsyncMock()

        # Verify exception
        with pytest.raises(DatabaseError) as exc_info:
            await base_serializer.delete(1)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "DELETE_FAILED"
        assert exc_info.value.message_category == "BASE"
        assert "User" in exc_info.value.message
        mock_db_session.rollback.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_paginated_success(self, base_serializer, mock_db_session):
        """Test successful paginated query"""
        # Prepare test data
        pagination = PaginationParams(page=1, size=10)
        mock_users = [
            UserWithPassword(
                id=1,
                name="User 1",
                en_name="user1",
                email="user1@example.com",
                mobile="13800138001",
                user_id="user_001",
                status=1,
                locked=0,
                password="y6ZreZqlZeBeIl",
            ),
            UserWithPassword(
                id=2,
                name="User 2",
                en_name="user2",
                email="user2@example.com",
                mobile="13800138002",
                user_id="user_002",
                status=1,
                locked=0,
                password="y6ZreZqlZeBeIl",
            ),
        ]

        # Mock query result
        mock_result = MagicMock()
        mock_result.all.return_value = mock_users
        mock_count_result = MagicMock()
        mock_count_result.all.return_value = [1, 2, 3, 4, 5]  # Total 5 records

        mock_db_session.exec = AsyncMock(side_effect=[mock_count_result, mock_result])

        # Execute paginated query
        result = await base_serializer.get_paginated(pagination)

        # Verify result
        assert result.items == mock_users
        assert result.total == 5
        assert result.page == 1
        assert result.size == 10

    @pytest.mark.asyncio
    async def test_get_paginated_with_filters(self, base_serializer, mock_db_session):
        """Test paginated query with filters"""
        pagination = PaginationParams(page=1, size=10)
        filters = [UserWithPassword.status == 1]
        mock_users = [
            UserWithPassword(
                id=1,
                name="Active user",
                en_name="active_user",
                email="active@example.com",
                mobile="13800138001",
                user_id="active_001",
                status=1,
                locked=0,
                password="y6ZreZqlZeBeIl",
            ),
        ]

        # Mock query result
        mock_result = MagicMock()
        mock_result.all.return_value = mock_users
        mock_count_result = MagicMock()
        mock_count_result.all.return_value = [1]

        mock_db_session.exec = AsyncMock(side_effect=[mock_count_result, mock_result])

        # Execute paginated query
        result = await base_serializer.get_paginated(pagination, filters=filters)

        # Verify result
        assert result.items == mock_users
        assert result.total == 1

    @pytest.mark.asyncio
    async def test_get_paginated_sqlalchemy_error(
        self, base_serializer, mock_db_session
    ):
        """Test SQLAlchemy error during paginated query"""
        pagination = PaginationParams(page=1, size=10)

        # Mock SQLAlchemy error
        mock_db_session.exec = AsyncMock(side_effect=SQLAlchemyError("Paginate error"))

        # Verify exception
        with pytest.raises(DatabaseError) as exc_info:
            await base_serializer.get_paginated(pagination)

        # Verify error message uses message key system
        assert exc_info.value.message_key == "PAGINATE_FAILED"
        assert exc_info.value.message_category == "BASE"
        assert "User" in exc_info.value.message
