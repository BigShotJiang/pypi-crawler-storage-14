#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-01-16 12:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: FastAPI exception handlers
    Centralized exception handling for the FastAPI application.

All Rights Reserved.
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from .serializers.exceptions import DatabaseError, NotFoundError
from .serializers.messages import get_router_error


def register_exception_handlers(app: FastAPI) -> None:
    """
    Register all exception handlers for the FastAPI application

    Args:
        app: FastAPI application instance
    """

    @app.exception_handler(NotFoundError)
    async def not_found_exception_handler(request: Request, exc: NotFoundError):
        """Handle NotFoundError exceptions"""
        return JSONResponse(
            status_code=404,
            content={
                "detail": exc.message,
                "error_type": "NOT_FOUND",
                "resource": getattr(exc, "resource", None),
                "identifier": getattr(exc, "identifier", None),
            },
        )

    @app.exception_handler(DatabaseError)
    async def database_exception_handler(request: Request, exc: DatabaseError):
        """Handle DatabaseError exceptions"""
        # Check for specific database errors that should return 400
        if any(
            keyword in exc.message.lower()
            for keyword in [
                "already exists",
                "already used",
                "already in use",
                "duplicate",
                "constraint",
                "unique",
                "foreign key",
                "not found",
                "users not found",
                "roles not found",
                "permissions not found",
                "system permission",
                "system role",
                "associated role",
                "associated user",
                "relation does not exist",
                "cannot delete system",
                "still has",
                "cannot be deleted",
            ]
        ):
            status_code = 400
        else:
            status_code = 500

        return JSONResponse(
            status_code=status_code,
            content={
                "detail": exc.message,
                "error_type": "DATABASE_ERROR",
                "message_key": getattr(exc, "message_key", None),
                "message_category": getattr(exc, "message_category", None),
            },
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ):
        """Handle request validation errors"""
        # Convert errors to JSON-serializable format
        serializable_errors = []
        for error in exc.errors():
            serializable_error = {}
            for key, value in error.items():
                if isinstance(value, bytes):
                    serializable_error[key] = value.decode("utf-8", errors="replace")
                else:
                    serializable_error[key] = value
            serializable_errors.append(serializable_error)

        return JSONResponse(
            status_code=422,
            content={
                "detail": "Request validation failed",
                "error_type": "VALIDATION_ERROR",
                "errors": serializable_errors,
            },
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        """Handle HTTP exceptions"""
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail, "error_type": "HTTP_ERROR"},
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """Handle all other exceptions"""
        return JSONResponse(
            status_code=500,
            content={
                "detail": f"{get_router_error('SERVER_INTERNAL_ERROR')}: {str(exc)}",
                "error_type": "INTERNAL_ERROR",
            },
        )


def create_error_response(
    status_code: int, detail: str, error_type: str = None, **kwargs
) -> dict:
    """
    Create a standardized error response

    Args:
        status_code: HTTP status code
        detail: Error detail message
        error_type: Type of error
        **kwargs: Additional error information

    Returns:
        Standardized error response dictionary
    """
    response = {"detail": detail, "error_type": error_type or "ERROR"}
    response.update(kwargs)
    return response
