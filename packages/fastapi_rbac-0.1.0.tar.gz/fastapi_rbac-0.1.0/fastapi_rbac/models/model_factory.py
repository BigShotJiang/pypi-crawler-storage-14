#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.com
@Create Time: 2025-05-29 11:39:08
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: Model Factory Module
    Provides a unified interface for accessing dynamic RBAC models.
    This module ensures that all serializers and routers can access
    the correct User model at runtime without import issues.

All Rights Reserved.
"""

from typing import Type, Dict
from sqlmodel import SQLModel


class ModelFactory:
    """
    Factory class for accessing dynamic RBAC models

    This class provides a clean interface for accessing models that
    may be dynamically configured at runtime.
    """

    @staticmethod
    def get_user_model() -> Type[SQLModel]:
        """
        Get the current User model dynamically

        Returns:
            Current User model class

        Raises:
            RuntimeError: If User model is not available
        """
        from ..serializers.user_serializer_factory import UserSerializerFactory

        try:
            return UserSerializerFactory.get_user_model()
        except Exception as e:
            raise RuntimeError(f"User model is not available: {str(e)}")

    @staticmethod
    def get_role_model() -> Type[SQLModel]:
        """
        Get the Role model

        Returns:
            Role model class
        """
        from ..models import get_current_models

        models = get_current_models()
        role_model = models.get("Role")
        if not role_model:
            raise RuntimeError("Role model is not available")
        return role_model

    @staticmethod
    def get_permission_model() -> Type[SQLModel]:
        """
        Get the Permission model

        Returns:
            Permission model class
        """
        from ..models import get_current_models

        models = get_current_models()
        permission_model = models.get("Permission")
        if not permission_model:
            raise RuntimeError("Permission model is not available")
        return permission_model

    @staticmethod
    def get_user_role_relation_model() -> Type[SQLModel]:
        """
        Get the UserRoleRelation model

        Returns:
            UserRoleRelation model class
        """
        from ..models import get_current_models

        models = get_current_models()
        user_role_relation_model = models.get("UserRoleRelation")
        if not user_role_relation_model:
            raise RuntimeError("UserRoleRelation model is not available")
        return user_role_relation_model

    @staticmethod
    def get_role_permission_relation_model() -> Type[SQLModel]:
        """
        Get the RolePermissionRelation model

        Returns:
            RolePermissionRelation model class
        """
        from ..models import get_current_models

        models = get_current_models()
        role_permission_relation_model = models.get("RolePermissionRelation")
        if not role_permission_relation_model:
            raise RuntimeError("RolePermissionRelation model is not available")
        return role_permission_relation_model

    @staticmethod
    def get_all_models() -> Dict[str, Type[SQLModel]]:
        """
        Get all current models

        Returns:
            Dictionary of all current model classes
        """
        from ..models import get_current_models

        return get_current_models()


# Convenience functions for backward compatibility
def get_user_model() -> Type[SQLModel]:
    """Get the current User model dynamically"""
    return ModelFactory.get_user_model()


def get_role_model() -> Type[SQLModel]:
    """Get the Role model"""
    return ModelFactory.get_role_model()


def get_permission_model() -> Type[SQLModel]:
    """Get the Permission model"""
    return ModelFactory.get_permission_model()


def get_user_role_relation_model() -> Type[SQLModel]:
    """Get the UserRoleRelation model"""
    return ModelFactory.get_user_role_relation_model()


def get_role_permission_relation_model() -> Type[SQLModel]:
    """Get the RolePermissionRelation model"""
    return ModelFactory.get_role_permission_relation_model()


def get_all_models() -> Dict[str, Type[SQLModel]]:
    """Get all current models"""
    return ModelFactory.get_all_models()


__all__ = [
    "ModelFactory",
    "get_user_model",
    "get_role_model",
    "get_permission_model",
    "get_user_role_relation_model",
    "get_role_permission_relation_model",
    "get_all_models",
]
