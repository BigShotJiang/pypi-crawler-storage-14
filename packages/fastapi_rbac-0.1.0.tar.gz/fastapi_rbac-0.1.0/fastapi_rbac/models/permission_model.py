"""
Permission Model Definition

This module defines the permission model in the RBAC system.
"""

from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import Field, Relationship

from .base_model import AsyncModel

if TYPE_CHECKING:
    # For type checking only; avoids runtime import cycles
    from .role_permission_relation import RolePermissionRelation  # noqa: F401


class Permission(AsyncModel, table=True):
    """
    Permission Model

    Used to define various permissions and their access control rules in the system.
    """

    __tablename__: str = "t_permissions"

    id: Optional[int] = Field(
        default=None, primary_key=True, description="Permission ID"
    )
    code: str = Field(
        index=True, max_length=100, description="Permission code, must be unique"
    )
    name: str = Field(max_length=50, description="Permission name")
    description: Optional[str] = Field(
        default=None, max_length=200, description="Permission description"
    )

    # Permission classification fields
    resource: Optional[str] = Field(
        default=None, max_length=50, description="Permission resource identifier"
    )
    action: Optional[str] = Field(
        default=None, max_length=50, description="Permission action type"
    )
    permission_type: Optional[str] = Field(
        default="function",
        max_length=20,
        description="Permission type: function/data/api",
    )

    # Status management
    is_active: bool = Field(default=True, description="Permission active status")
    is_system: bool = Field(default=False, description="System built-in permission")

    # Timestamp fields
    created_at: datetime = Field(
        default_factory=datetime.now, description="Creation time"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now, description="Update time"
    )

    # Relationship definitions
    permission_roles: List["RolePermissionRelation"] = Relationship(
        back_populates="permission",
        sa_relationship_kwargs={
            "primaryjoin": "Permission.id==RolePermissionRelation.permission_id",
            "foreign_keys": "[RolePermissionRelation.permission_id]",
            "cascade": "all, delete-orphan",
        },
    )

    class Config:
        """Model configuration"""

        from_attributes = True
        arbitrary_types_allowed = True
        str_strip_whitespace = True

    def __str__(self) -> str:
        return f"Permission(id={self.id}, code='{self.code}', name='{self.name}')"

    def __repr__(self) -> str:
        return f"Permission(id={self.id}, code='{self.code}', name='{self.name}', is_active={self.is_active}, is_system={self.is_system})"
