"""
Role Model Definition

This module defines the role model in the RBAC system.
"""

from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import Field, Relationship

from .base_model import AsyncModel

if TYPE_CHECKING:
    # For type checking only; avoids runtime import cycles
    from .user_role_relation import UserRoleRelation  # noqa: F401
    from .role_permission_relation import RolePermissionRelation  # noqa: F401


class Role(AsyncModel, table=True):
    """
    Role Model

    Used to define various roles and their permission scopes in the system.
    """

    __tablename__: str = "t_roles"

    id: Optional[int] = Field(default=None, primary_key=True, description="Role ID")
    name: str = Field(
        index=True, max_length=50, description="Role name, must be unique"
    )
    description: Optional[str] = Field(
        default=None, max_length=200, description="Role description"
    )

    # Status management
    is_active: bool = Field(default=True, description="Role active status")
    is_system: bool = Field(default=False, description="System built-in role")

    # Timestamp fields
    created_at: datetime = Field(
        default_factory=datetime.now, description="Creation time"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now, description="Update time"
    )

    # Relationship definitions
    role_users: List["UserRoleRelation"] = Relationship(
        back_populates="role",
        sa_relationship_kwargs={
            "primaryjoin": "Role.id==UserRoleRelation.role_id",
            "foreign_keys": "[UserRoleRelation.role_id]",
            "cascade": "all, delete-orphan",
        },
    )
    role_permissions: List["RolePermissionRelation"] = Relationship(
        back_populates="role",
        sa_relationship_kwargs={
            "primaryjoin": "Role.id==RolePermissionRelation.role_id",
            "foreign_keys": "[RolePermissionRelation.role_id]",
            "cascade": "all, delete-orphan",
        },
    )

    class Config:
        """Model configuration"""

        from_attributes = True
        arbitrary_types_allowed = True
        str_strip_whitespace = True

    def __str__(self) -> str:
        return f"Role(id={self.id}, name='{self.name}')"

    def __repr__(self) -> str:
        return f"Role(id={self.id}, name='{self.name}', is_active={self.is_active}, is_system={self.is_system})"
