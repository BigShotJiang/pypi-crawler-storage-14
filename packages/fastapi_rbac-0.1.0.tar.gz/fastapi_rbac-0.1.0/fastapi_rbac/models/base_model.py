"""
Base Model Definition

This module defines the base model for the RBAC system.
"""

from sqlalchemy.ext.asyncio import AsyncAttrs
from sqlmodel import SQLModel


class AsyncModel(AsyncAttrs, SQLModel):
    """
    Base Model
    """
