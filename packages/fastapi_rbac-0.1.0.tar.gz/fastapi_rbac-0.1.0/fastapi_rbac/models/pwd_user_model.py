"""
User Model Definition

This module defines the user model in the RBAC system. It introduces an abstract
`BaseUser` for permission checks and a concrete `User` model for persistence.
The `User.password` stores a hash, never plaintext.
"""

from sqlalchemy import event
from sqlmodel import Field, Relationship
from typing import Optional, List, TYPE_CHECKING
from datetime import datetime
from passlib.context import CryptContext


from .base_user_model import BaseUser

if TYPE_CHECKING:
    from .user_role_relation import UserRoleRelation  # noqa: F401


class UserWithPassword(BaseUser, table=True):

    __tablename__: str = "t_users_with_password"

    name: str = Field(index=True, max_length=50, min_length=5, description="Username")
    en_name: str = Field(index=True, max_length=50, description="English name")

    mobile: str = Field(index=True, max_length=100, description="Mobile phone")

    # External system integration fields
    user_id: Optional[str] = Field(
        default=None,
        index=True,
        max_length=100,
        description="External system user ID for SSO integration",
    )

    # Status management
    status: int = Field(default=0, description="User status")
    locked: int = Field(default=0, description="User lock status")

    # Timestamp fields
    created_at: datetime = Field(
        default_factory=datetime.now, description="Creation time"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="Update time",
        sa_column_kwargs={"onupdate": datetime.now},
    )
    last_login: Optional[datetime] = Field(default=None, description="Last login time")

    password: Optional[str] = Field(
        default=None,
        max_length=255,
        description="Hashed password (bcrypt). Never store plaintext.",
    )

    def verify_password(self, plain_password: str) -> bool:
        """
        Verify a plain password against the stored hash.

        Args:
            plain_password: The plain text password to verify

        Returns:
            True if password matches, False otherwise
        """
        if not self.password:
            return False
        return _pwd_context.verify(plain_password, self.password)

    def set_password(self, plain_password: str) -> None:
        """
        Set a new password with automatic hashing.

        Args:
            plain_password: The plain text password to hash and store
        """
        self.password = _pwd_context.hash(plain_password)

    def check_password(self, plain_password: str) -> bool:
        """
        Alias for verify_password for Django-style compatibility.

        Args:
            plain_password: The plain text password to verify

        Returns:
            True if password matches, False otherwise
        """
        return self.verify_password(plain_password)

    def __str__(self) -> str:
        return f"User(id={self.id}, name='{self.name}', email='{self.email}')"

    def __repr__(self) -> str:
        return f"User(id={self.id}, name='{self.name}', email='{self.email}', status={self.status})"

    # Relationship definitions
    user_roles: List["UserRoleRelation"] = Relationship(
        # back_populates="user",
        sa_relationship_kwargs={
            "primaryjoin": "UserWithPassword.id==UserRoleRelation.user_id",
            "foreign_keys": "[UserRoleRelation.user_id]",
            "cascade": "all, delete-orphan",
        },
    )


# Password hashing context (bcrypt)
_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def _is_bcrypt_hash(value: Optional[str]) -> bool:
    """Check if a string is already a bcrypt hash."""
    if not value:
        return False
    # Common bcrypt prefixes
    return (
        value.startswith("$2a$") or value.startswith("$2b$") or value.startswith("$2y$")
    )


def _hash_password_if_needed(target: "UserWithPassword") -> None:
    """Hash password if it's not already hashed."""
    if target.password and not _is_bcrypt_hash(target.password):
        target.password = _pwd_context.hash(target.password)


def _setup_password_events(model_class: type) -> None:
    """
    Set up SQLAlchemy events for password hashing on the given model class.

    Args:
        model_class: The model class to set up events for
    """

    @event.listens_for(model_class, "before_insert", propagate=True)
    def _before_insert(mapper, connection, target: "UserWithPassword") -> None:
        """Hash password before insert if needed."""
        if target.password:
            _hash_password_if_needed(target)

    @event.listens_for(model_class, "before_update", propagate=True)
    def _before_update(mapper, connection, target: "UserWithPassword") -> None:
        """Hash password before update if needed."""
        if target.password:
            _hash_password_if_needed(target)


# Set up password events for the User model
_setup_password_events(UserWithPassword)
