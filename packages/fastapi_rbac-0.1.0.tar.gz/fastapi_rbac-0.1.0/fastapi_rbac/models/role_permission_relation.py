"""
Role Permission Association Model Definition

This module defines the many-to-many association relationship between roles and permissions.
"""

from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlmodel import Field, Relationship

from .base_model import AsyncModel

if TYPE_CHECKING:
    from .role_model import Role
    from .permission_model import Permission


class RolePermissionRelation(AsyncModel, table=True):
    """
    Role Permission Association Model

    Manages the many-to-many relationship between roles and permissions, supporting audit tracking.
    """

    __tablename__: str = "t_role_permission_relations"

    id: Optional[int] = Field(
        default=None, primary_key=True, description="Association ID"
    )
    role_id: int = Field(description="Role ID")
    permission_id: int = Field(description="Permission ID")

    # Audit fields
    assigned_at: datetime = Field(
        default_factory=datetime.now, description="Assignment time"
    )
    assigned_by: Optional[int] = Field(
        default=None, description="Assigned by operator ID"
    )
    expires_at: Optional[datetime] = Field(
        default=None, description="Permission expiration time"
    )

    # Time
    created_at: Optional[datetime] = Field(
        default_factory=datetime.now, description="Creation time"
    )
    updated_at: Optional[datetime] = Field(
        description="Last update time",
        default_factory=datetime.now,
        sa_column_kwargs={"onupdate": datetime.now},
        # sa_column=Column(
        #     DateTime,
        #     server_default=func.now(),
        #     onupdate=func.now(),
        #     nullable=False,
        # ),
    )

    # Status management
    is_active: bool = Field(
        default=True, description="Whether the association is active"
    )

    # Relationship definitions
    role: "Role" = Relationship(
        back_populates="role_permissions",
        sa_relationship_kwargs={
            "primaryjoin": "Role.id==RolePermissionRelation.role_id",
            "foreign_keys": "[RolePermissionRelation.role_id]",
        },
    )
    permission: "Permission" = Relationship(
        back_populates="permission_roles",
        sa_relationship_kwargs={
            "primaryjoin": "Permission.id==RolePermissionRelation.permission_id",
            "foreign_keys": "[RolePermissionRelation.permission_id]",
        },
    )

    class Config:
        """Model configuration"""

        from_attributes = True
        arbitrary_types_allowed = True

    def __str__(self) -> str:
        return f"RolePermissionRelation(role_id={self.role_id}, permission_id={self.permission_id})"

    def __repr__(self) -> str:
        return (
            f"RolePermissionRelation(id={self.id}, role_id={self.role_id}, "
            f"permission_id={self.permission_id}, is_active={self.is_active})"
        )
