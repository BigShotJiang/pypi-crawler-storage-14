"""
User Role Association Model Definition

This module defines the many-to-many association relationship between users and roles.
"""

from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlmodel import Field, Relationship

from .base_model import AsyncModel

if TYPE_CHECKING:
    # from .user_model import User  # noqa: F401
    from .role_model import Role  # noqa: F401


class UserRoleRelation(AsyncModel, table=True):
    """
    User Role Association Model

    Manage the many-to-many relationship between users and roles, supporting audit tracking.
    """

    __tablename__: str = "t_user_role_relations"

    id: Optional[int] = Field(
        default=None, primary_key=True, description="Association ID"
    )
    user_id: int = Field(description="User ID")
    role_id: int = Field(description="Role ID")

    # Audit fields
    assigned_at: datetime = Field(
        default_factory=datetime.now, description="Allocation time"
    )
    assigned_by: Optional[int] = Field(
        default=None, description="Allocated operator ID"
    )
    expires_at: Optional[datetime] = Field(
        default=None, description="Role expiration time"
    )

    # Status management
    is_active: bool = Field(
        default=True, description="Whether the association is active"
    )

    # Relationship definition
    # TODO: Dynamic import user model
    # user: "User" = Relationship(
    #     back_populates="user_roles",
    #     sa_relationship_kwargs={
    #         "primaryjoin": "User.id==UserRoleRelation.user_id",
    #         "foreign_keys": "[UserRoleRelation.user_id]",
    #     },
    # )
    role: "Role" = Relationship(
        back_populates="role_users",
        sa_relationship_kwargs={
            "primaryjoin": "Role.id==UserRoleRelation.role_id",
            "foreign_keys": "[UserRoleRelation.role_id]",
        },
    )

    class Config:
        """Model configuration"""

        from_attributes = True
        arbitrary_types_allowed = True

    def __str__(self) -> str:
        return f"UserRoleRelation(user_id={self.user_id}, role_id={self.role_id})"

    def __repr__(self) -> str:
        return (
            f"UserRoleRelation(id={self.id}, user_id={self.user_id}, "
            f"role_id={self.role_id}, is_active={self.is_active})"
        )
