#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: harumonia
@Email: zxjlm233@gmail.net
@Create Time: 2025-01-27 10:00:00
@Software: Visual Studio Code
@Copyright: Copyright (c) 2025, harumonia
@Description: GitHub User Model Definition
All Rights Reserved.
"""

import typing
from sqlmodel import Field, Relationship
from datetime import datetime
from typing import List, Optional

from fastapi_rbac.models.base_user_model import BaseUser

if typing.TYPE_CHECKING:
    from fastapi_rbac.models.base_user_model import UserRoleRelation


class GitHubUserModel(BaseUser, table=True):
    """
    GitHub User Model

    Extend the base user model, add GitHub specific fields

    ATTENTION:
        Just For Example
    """

    __tablename__: str = "t_github_users"

    # Base user information
    name: str = Field(
        index=True, max_length=50, min_length=1, description="User display name"
    )
    en_name: str = Field(
        index=True, nullable=True, max_length=50, description="English name/username"
    )
    mobile: str = Field(
        index=True, max_length=100, default="", description="Mobile phone number"
    )

    # GitHub specific fields
    github_id: Optional[int] = Field(
        default=None, index=True, description="GitHub user ID"
    )
    github_login: Optional[str] = Field(
        default=None, index=True, max_length=100, description="GitHub username"
    )
    github_avatar_url: Optional[str] = Field(
        default=None, max_length=500, description="GitHub avatar URL"
    )
    github_html_url: Optional[str] = Field(
        default=None, max_length=500, description="GitHub personal homepage URL"
    )
    github_public_repos: int = Field(
        default=0, description="GitHub public repositories count"
    )
    github_followers: int = Field(default=0, description="GitHub followers count")
    github_following: int = Field(default=0, description="GitHub following count")
    github_bio: Optional[str] = Field(
        default=None, max_length=500, description="GitHub bio"
    )
    github_company: Optional[str] = Field(
        default=None, max_length=200, description="GitHub company information"
    )
    github_location: Optional[str] = Field(
        default=None, max_length=200, description="GitHub location information"
    )
    github_blog: Optional[str] = Field(
        default=None, max_length=500, description="GitHub blog URL"
    )
    github_twitter_username: Optional[str] = Field(
        default=None, max_length=100, description="GitHub Twitter username"
    )

    # External system integration fields
    user_id: Optional[str] = Field(
        default=None,
        index=True,
        max_length=100,
        description="External system user ID for SSO integration",
    )

    # Status management
    status: int = Field(default=1, description="User status: 0-disabled, 1-enabled")
    locked: int = Field(default=0, description="User lock status: 0-unlocked, 1-locked")

    # Timestamp fields
    created_at: datetime = Field(
        default_factory=datetime.now, description="Creation time"
    )
    updated_at: datetime = Field(
        default_factory=datetime.now,
        description="Update time",
        sa_column_kwargs={"onupdate": datetime.now},
    )
    last_login: Optional[datetime] = Field(default=None, description="Last login time")
    github_updated_at: Optional[datetime] = Field(
        default=None, description="GitHub information last update time"
    )

    def __str__(self) -> str:
        return f"GitHubUser(id={self.id}, name='{self.name}', email='{self.email}', github_login='{self.github_login}')"

    def __repr__(self) -> str:
        return f"GitHubUser(id={self.id}, name='{self.name}', email='{self.email}', github_id={self.github_id}, status={self.status})"

    # Relationship definitions
    user_roles: List["UserRoleRelation"] = Relationship(
        sa_relationship_kwargs={
            "primaryjoin": "GitHubUserModel.id==UserRoleRelation.user_id",
            "foreign_keys": "[UserRoleRelation.user_id]",
            "cascade": "all, delete-orphan",
        },
    )

    @property
    def display_name(self) -> str:
        """
        Get user display name

        Returns:
            str: Display name, prioritize name, then en_name
        """
        return self.name or self.en_name or self.github_login or "Unknown User"

    @property
    def github_profile_url(self) -> str:
        """
        Get GitHub profile URL

        Returns:
            str: GitHub profile URL
        """
        return self.github_html_url or f"https://github.com/{self.github_login}"

    def update_github_info(self, github_data: dict) -> None:
        """
        Update GitHub user information

        Args:
            github_data: User data returned from GitHub API
        """
        self.github_id = github_data.get("id")
        self.github_login = github_data.get("login")
        self.github_avatar_url = github_data.get("avatar_url")
        self.github_html_url = github_data.get("html_url")
        self.github_public_repos = github_data.get("public_repos", 0)
        self.github_followers = github_data.get("followers", 0)
        self.github_following = github_data.get("following", 0)
        self.github_bio = github_data.get("bio")
        self.github_company = github_data.get("company")
        self.github_location = github_data.get("location")
        self.github_blog = github_data.get("blog")
        self.github_twitter_username = github_data.get("twitter_username")
        self.github_updated_at = datetime.now()

        # Update basic information
        if github_data.get("name"):
            self.name = github_data["name"]
        if github_data.get("login"):
            self.en_name = github_data["login"]
        if github_data.get("email"):
            self.email = github_data["email"]
