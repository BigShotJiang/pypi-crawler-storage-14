from mchnpkg._core import hello_from_bin

from mchnpkg.model import LinearRegression

from .model import LinearRegression
__all__ = ["LinearRegression"]

from .model.regression import CauchyRegression

__all__ = ["CauchyRegression"]

from .model.cauchy_statsmodels import CauchyMLE, fit_cauchy_mle
__all__ += ["CauchyMLE", "fit_cauchy_mle"]

from .model.logit import LogisticRegressionGD
__all__ = ["LogisticRegressionGD"]

__all__ = []
__version__ = "0.2.0"

__all__ = []
__version__ = "0.2.0"

from .model.logit import LogisticRegressionGD
__all__ += ["LogisticRegressionGD"]


__all__ = []
__version__ = "0.2.0"

from .model.logit import LogisticRegressionGD
__all__ += ["LogisticRegressionGD"]








def hello() -> str:
    return hello_from_bin()



# neuralnet/__init__.py
__all__ = ["model"]

