# neuralnet/model/neuralnet.py
import torch
import torch.nn as nn

class TorchNet(nn.Module):
    """
    Feedforward neural network for binary classification.

    - Two hidden layers:
        * first:  4 neurons
        * second: 3 neurons
    - Output layer: 'output_dim' neurons (1 for binary classification)

    The network is flexible in input_dim and output_dim, so it
    can be reused across datasets (satisfies bonus requirement).
    """
    def __init__(self, input_dim: int, output_dim: int = 1,
                 hidden1: int = 4, hidden2: int = 3):
        super().__init__()

        self.fc1 = nn.Linear(input_dim, hidden1)
        self.fc2 = nn.Linear(hidden1, hidden2)
        self.fc3 = nn.Linear(hidden2, output_dim)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)      # raw logits; apply sigmoid in training code
        return x

