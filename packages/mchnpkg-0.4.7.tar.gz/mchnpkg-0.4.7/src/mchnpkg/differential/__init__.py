from .discrete import diff

__all__ = ['diff']

