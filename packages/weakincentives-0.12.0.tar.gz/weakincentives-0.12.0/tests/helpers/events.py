# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Test utilities for working with event buses."""

from __future__ import annotations

from weakincentives.runtime.events import EventHandler, PublishResult


class NullEventBus:
    """Event bus implementation that discards all events."""

    def subscribe(self, event_type: type[object], handler: EventHandler) -> None:
        """No-op subscription hook."""

    def publish(self, event: object) -> PublishResult:
        """Drop the provided event instance."""

        return PublishResult(
            event=event,
            handlers_invoked=(),
            errors=(),
        )


__all__ = ["NullEventBus"]
