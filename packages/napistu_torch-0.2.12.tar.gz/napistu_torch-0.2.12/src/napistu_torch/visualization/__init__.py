"""Visualization utilities for napistu-torch.

This subpackage provides visualization tools and utilities for visualizing embedding, model performance, and other metrics.
"""
