"""Data utilities for Napistu-Torch."""
