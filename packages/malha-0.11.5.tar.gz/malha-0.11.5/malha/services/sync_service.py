"""
TopologySyncService - Graph Topology Materializer (Helix Pattern)
==================================================================

This service materializes the graph topology from external data sources without
copying the actual data. It implements the "Helix" pattern where:

1. **Data stays external**: The actual records live in PostgreSQL, Parquet, S3, etc.
2. **Topology is local**: Only the relationships (edges) are stored in Kùzu
3. **RIDs are deterministic**: Virtual objects get stable identifiers via UUIDv5 hashing

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    Application Layer                            │
    │  ┌─────────────────────────────────────────────────────────┐   │
    │  │              TopologySyncService                         │   │
    │  │  • Reads keys from external sources (lightweight)        │   │
    │  │  • Generates deterministic RIDs (UUIDv5)                 │   │
    │  │  • Creates edges in Kùzu (Ghost Nodes)                   │   │
    │  └─────────────────────────────────────────────────────────┘   │
    └─────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                      Malha Kernel                               │
    │  • query_federated() - reads external data                      │
    │  • graph.create_edge() - creates edges with Ghost Nodes         │
    └─────────────────────────────────────────────────────────────────┘

Usage:
    from malha import connect
    from malha.services import TopologySyncService

    kernel = await connect(...)
    sync = TopologySyncService(kernel)

    # Sync relationships from SAP orders to Salesforce customers
    edges_created = await sync.sync_relationship(
        source_config={"type": "postgres", "dsn": "...", "table": "orders"},
        source_pk_column="id",
        source_fk_column="customer_id",
        source_type="OrderSAP",
        target_type="CustomerSalesforce",
        relationship_label="BELONGS_TO",
        sql_filter="created_at > '2024-01-01'"
    )
"""

import logging
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any
from uuid import NAMESPACE_DNS, uuid5

logger = logging.getLogger("malha.services.sync")


def generate_virtual_rid(namespace: str, external_id: str) -> str:
    """Generate a deterministic RID for a Virtual Object.

    Uses UUIDv5 (SHA-1 based) to create stable, reproducible identifiers
    from external primary keys. The same input always produces the same RID.

    Args:
        namespace: Type/source identifier (e.g., "CustomerSalesforce", "OrderSAP")
        external_id: Primary key from the external system

    Returns:
        RID in Registro format: ri.helix.virtual.<type>.<uuid>

    Example:
        >>> generate_virtual_rid("CustomerSalesforce", "SF-12345")
        'ri.helix.virtual.customersalesforce.a1b2c3d4-e5f6-7890-abcd-ef1234567890'

        # Same input always produces same output (deterministic)
        >>> generate_virtual_rid("CustomerSalesforce", "SF-12345")
        'ri.helix.virtual.customersalesforce.a1b2c3d4-e5f6-7890-abcd-ef1234567890'
    """
    # UUIDv5 is deterministic: same namespace+id = same UUID
    deterministic_uuid = uuid5(NAMESPACE_DNS, f"{namespace}:{external_id}")
    return f"ri.helix.virtual.{namespace.lower()}.{deterministic_uuid}"


class TopologySyncService:
    """Materializes graph topology from external data sources (Helix Pattern).

    This service reads only the key columns (PK + FK) from external sources
    and creates edges in the graph database. The actual data is never copied -
    it's accessed on-demand via federated queries.

    Key Features:
    - **Lightweight extraction**: Only reads key columns, not full records
    - **Deterministic RIDs**: Virtual objects get stable identifiers
    - **Ghost Nodes**: Kùzu creates stub nodes automatically via MERGE
    - **Incremental sync**: Supports filtering for delta updates

    Attributes:
        kernel: Reference to UnifiedDataManager
        stats: Dictionary tracking sync statistics
    """

    def __init__(self, kernel: "UnifiedDataManager"):  # noqa: F821
        """Initialize the sync service.

        Args:
            kernel: UnifiedDataManager instance (from malha.connect())
        """
        self.kernel = kernel
        self.stats: dict[str, int] = {
            "total_syncs": 0,
            "total_edges_created": 0,
            "total_errors": 0,
        }

    async def sync_relationship(
        self,
        source_config: dict[str, Any],
        source_pk_column: str,
        source_fk_column: str,
        source_type: str,
        target_type: str,
        relationship_label: str,
        sql_filter: str = "1=1",
        batch_size: int = 1000,
        on_progress: Callable[[int, int], None] | None = None,
    ) -> int:
        """Synchronize relationships between virtual objects.

        Reads key columns from an external source and creates edges in the graph.
        Uses Ghost Nodes (MERGE) to create stub nodes for RIDs that don't exist
        in the SQL layer.

        Args:
            source_config: Federation config for query_federated()
                Example: {"type": "postgres", "dsn": "...", "table": "orders"}
            source_pk_column: Primary key column in source (e.g., "id")
            source_fk_column: Foreign key column in source (e.g., "customer_id")
            source_type: Type name for source objects (e.g., "OrderSAP")
            target_type: Type name for target objects (e.g., "CustomerSalesforce")
            relationship_label: Edge label in graph (e.g., "BELONGS_TO")
            sql_filter: WHERE clause for incremental sync (default: all rows)
            batch_size: Number of rows to process per batch
            on_progress: Optional callback(processed, total) for progress tracking

        Returns:
            Number of edges successfully created

        Example:
            # Sync order->customer relationships from SAP
            edges = await sync.sync_relationship(
                source_config={
                    "type": "postgres",
                    "dsn": "dbname=sap user=reader host=sap.example.com",
                    "table": "orders"
                },
                source_pk_column="order_id",
                source_fk_column="customer_ref",
                source_type="OrderSAP",
                target_type="CustomerSalesforce",
                relationship_label="PLACED_BY",
                sql_filter="order_date > '2024-01-01'"
            )
            print(f"Created {edges} edges")
        """
        self.stats["total_syncs"] += 1
        edges_created = 0
        errors = 0

        logger.info(
            f"[SyncService] Starting topology sync: {source_type} -> {target_type} "
            f"via {relationship_label}",
        )

        try:
            # 1. Lightweight extraction: Only fetch key columns
            # This minimizes data transfer from external sources
            rows = await self.kernel.query_federated(
                source_config,
                sql_filter,
                columns=[source_pk_column, source_fk_column],
            )

            total_rows = len(rows)
            logger.info(f"[SyncService] Fetched {total_rows} rows for topology sync")

            if total_rows == 0:
                return 0

            # 2. Process in batches to avoid memory issues
            for i, row in enumerate(rows):
                try:
                    # Extract keys (handle None/null values)
                    pk_value = row.get(source_pk_column)
                    fk_value = row.get(source_fk_column)

                    if pk_value is None or fk_value is None:
                        logger.debug(
                            f"[SyncService] Skipping row with null key: "
                            f"pk={pk_value}, fk={fk_value}",
                        )
                        continue

                    # 3. Generate deterministic RIDs
                    source_rid = generate_virtual_rid(source_type, str(pk_value))
                    target_rid = generate_virtual_rid(target_type, str(fk_value))

                    # 4. Create edge in graph (with Ghost Nodes via MERGE)
                    await self.kernel.graph.create_edge(
                        src=source_rid,
                        dst=target_rid,
                        label=relationship_label,
                        props={
                            "synced_at": datetime.now(UTC).isoformat(),
                            "source_pk": str(pk_value),
                            "target_fk": str(fk_value),
                        },
                        create_ghost_nodes=True,  # Enable Helix pattern
                    )

                    edges_created += 1

                    # Progress callback
                    if on_progress and (i + 1) % 100 == 0:
                        on_progress(i + 1, total_rows)

                except Exception as e:
                    errors += 1
                    logger.warning(
                        f"[SyncService] Error creating edge for row {i}: {e}",
                    )
                    if errors > total_rows * 0.1:  # Fail if >10% errors
                        raise RuntimeError(
                            f"Too many errors ({errors}/{total_rows}), aborting sync",
                        )

            # Final progress callback
            if on_progress:
                on_progress(total_rows, total_rows)

            self.stats["total_edges_created"] += edges_created
            self.stats["total_errors"] += errors

            logger.info(
                f"[SyncService] Sync complete: {edges_created} edges created, "
                f"{errors} errors",
            )

            return edges_created

        except Exception as e:
            self.stats["total_errors"] += 1
            logger.exception(f"[SyncService] Sync failed: {e}")
            raise

    async def sync_bidirectional(
        self,
        source_config: dict[str, Any],
        pk_column_a: str,
        pk_column_b: str,
        type_a: str,
        type_b: str,
        relationship_label: str,
        sql_filter: str = "1=1",
    ) -> int:
        """Synchronize bidirectional relationships (many-to-many).

        For junction/bridge tables that represent many-to-many relationships.
        Creates edges in both directions.

        Args:
            source_config: Federation config for the junction table
            pk_column_a: First entity's key column
            pk_column_b: Second entity's key column
            type_a: Type name for first entity
            type_b: Type name for second entity
            relationship_label: Edge label (same in both directions)
            sql_filter: WHERE clause for filtering

        Returns:
            Number of edges created (count both directions)

        Example:
            # Sync product<->category relationships from junction table
            edges = await sync.sync_bidirectional(
                source_config={
                    "type": "sqlite",
                    "path": "/data/catalog.db",
                    "table": "product_categories"
                },
                pk_column_a="product_id",
                pk_column_b="category_id",
                type_a="Product",
                type_b="Category",
                relationship_label="IN_CATEGORY"
            )
        """
        # Forward direction: A -> B
        forward = await self.sync_relationship(
            source_config=source_config,
            source_pk_column=pk_column_a,
            source_fk_column=pk_column_b,
            source_type=type_a,
            target_type=type_b,
            relationship_label=relationship_label,
            sql_filter=sql_filter,
        )

        # Reverse direction: B -> A (with inverse label)
        reverse = await self.sync_relationship(
            source_config=source_config,
            source_pk_column=pk_column_b,
            source_fk_column=pk_column_a,
            source_type=type_b,
            target_type=type_a,
            relationship_label=f"{relationship_label}_INVERSE",
            sql_filter=sql_filter,
        )

        return forward + reverse

    async def bulk_create_edges(
        self,
        edges: list[tuple],
        relationship_label: str,
    ) -> int:
        """Create multiple edges in bulk.

        Optimized for cases where you've already computed the RIDs.

        Args:
            edges: List of (source_rid, target_rid) tuples
            relationship_label: Edge label for all edges

        Returns:
            Number of edges created

        Example:
            edges = [
                ("ri.helix.virtual.order.abc123", "ri.helix.virtual.customer.def456"),
                ("ri.helix.virtual.order.ghi789", "ri.helix.virtual.customer.jkl012"),
            ]
            await sync.bulk_create_edges(edges, "PLACED_BY")
        """
        created = 0
        now = datetime.now(UTC).isoformat()

        for src_rid, dst_rid in edges:
            try:
                await self.kernel.graph.create_edge(
                    src=src_rid,
                    dst=dst_rid,
                    label=relationship_label,
                    props={"synced_at": now},
                    create_ghost_nodes=True,
                )
                created += 1
            except Exception as e:
                logger.warning(f"[SyncService] Failed to create edge {src_rid} -> {dst_rid}: {e}")

        self.stats["total_edges_created"] += created
        return created

    def get_stats(self) -> dict[str, int]:
        """Get sync statistics.

        Returns:
            Dictionary with total_syncs, total_edges_created, total_errors
        """
        return self.stats.copy()

    def reset_stats(self) -> None:
        """Reset sync statistics to zero."""
        self.stats = {
            "total_syncs": 0,
            "total_edges_created": 0,
            "total_errors": 0,
        }
