# Malha v0.3.0 - Deployment Guide

## Production Deployment Checklist

### Prerequisites

- [ ] Python 3.13+
- [ ] PostgreSQL 14+ (recommended) or SQLite
- [ ] Network connectivity between nodes (for Synapse)
- [ ] Firewall rules configured (port 50051 for Synapse)

---

## Single Node Deployment

### 1. Install Malha

```bash
pip install malha
```

### 2. Configure Database

```python
# config.py
DATABASE_URL = "postgresql+asyncpg://user:password@localhost/malha"
KUZU_PATH = "/var/lib/malha/kuzu"
```

### 3. Initialize

```python
# app.py
from malha import connect

async def init_app():
    manager = await connect(
        url=DATABASE_URL,
        kuzu_path=KUZU_PATH
    )
    return manager
```

### 4. Run

```bash
python app.py
```

---

## Distributed Cluster Deployment

### Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Node 1        │────▶│   Node 2        │────▶│   Node 3        │
│   10.0.1.10     │◀────│   10.0.1.11     │◀────│   10.0.1.12     │
│   Port: 50051   │     │   Port: 50051   │     │   Port: 50051   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

### 1. Install with Synapse

```bash
pip install "malha[synapse]"
```

### 2. Compile Protos

```bash
pip install grpcio-tools
python scripts/compile_protos.py
```

**Expected output:**
```
Found 1 proto file(s):
  - synapse.proto

Compiling synapse.proto...
✓ Successfully compiled synapse.proto

✓ All proto files compiled successfully!
```

### 3. Configure Each Node

**Node 1 (10.0.1.10):**
```python
# node1_config.py
NODE_ID = "node-1"
SYNAPSE_PORT = 50051
PEERS = ["10.0.1.11:50051", "10.0.1.12:50051"]
DATABASE_URL = "postgresql+asyncpg://user:pass@10.0.1.10/malha"
KUZU_PATH = "/var/lib/malha/kuzu_node1"
```

**Node 2 (10.0.1.11):**
```python
# node2_config.py
NODE_ID = "node-2"
SYNAPSE_PORT = 50051
PEERS = ["10.0.1.10:50051", "10.0.1.12:50051"]
DATABASE_URL = "postgresql+asyncpg://user:pass@10.0.1.11/malha"
KUZU_PATH = "/var/lib/malha/kuzu_node2"
```

**Node 3 (10.0.1.12):**
```python
# node3_config.py
NODE_ID = "node-3"
SYNAPSE_PORT = 50051
PEERS = ["10.0.1.10:50051", "10.0.1.11:50051"]
DATABASE_URL = "postgresql+asyncpg://user:pass@10.0.1.12/malha"
KUZU_PATH = "/var/lib/malha/kuzu_node3"
```

### 4. Application Code

```python
# app.py
import os
from malha import connect
from malha.drivers.synapse import SynapseDriver

async def init_cluster_node():
    # Create Synapse driver
    synapse = SynapseDriver(
        kernel_ref=None,
        node_id=os.getenv("NODE_ID"),
        port=int(os.getenv("SYNAPSE_PORT", "50051")),
        peers=os.getenv("PEERS", "").split(",")
    )
    
    # Connect with replication
    manager = await connect(
        url=os.getenv("DATABASE_URL"),
        kuzu_path=os.getenv("KUZU_PATH"),
        replication_driver=synapse
    )
    
    return manager

# Usage
if __name__ == "__main__":
    import asyncio
    
    async def main():
        manager = await init_cluster_node()
        
        # Your application logic here
        # ...
        
        # Keep running
        await asyncio.Event().wait()
    
    asyncio.run(main())
```

### 5. Environment Variables

Create `.env` file for each node:

**Node 1:**
```bash
NODE_ID=node-1
SYNAPSE_PORT=50051
PEERS=10.0.1.11:50051,10.0.1.12:50051
DATABASE_URL=postgresql+asyncpg://user:pass@10.0.1.10/malha
KUZU_PATH=/var/lib/malha/kuzu_node1
```

### 6. Start Nodes

```bash
# Node 1
export $(cat .env | xargs) && python app.py

# Node 2
export $(cat .env | xargs) && python app.py

# Node 3
export $(cat .env | xargs) && python app.py
```

---

## Docker Deployment

### Dockerfile

```dockerfile
FROM python:3.13-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Compile protos
RUN python scripts/compile_protos.py

# Expose Synapse port
EXPOSE 50051

# Run application
CMD ["python", "app.py"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  node1:
    build: .
    environment:
      - NODE_ID=node-1
      - SYNAPSE_PORT=50051
      - PEERS=node2:50051,node3:50051
      - DATABASE_URL=postgresql+asyncpg://user:pass@postgres/malha
      - KUZU_PATH=/data/kuzu
    volumes:
      - node1_data:/data
    networks:
      - malha_network
    depends_on:
      - postgres

  node2:
    build: .
    environment:
      - NODE_ID=node-2
      - SYNAPSE_PORT=50051
      - PEERS=node1:50051,node3:50051
      - DATABASE_URL=postgresql+asyncpg://user:pass@postgres/malha
      - KUZU_PATH=/data/kuzu
    volumes:
      - node2_data:/data
    networks:
      - malha_network
    depends_on:
      - postgres

  node3:
    build: .
    environment:
      - NODE_ID=node-3
      - SYNAPSE_PORT=50051
      - PEERS=node1:50051,node2:50051
      - DATABASE_URL=postgresql+asyncpg://user:pass@postgres/malha
      - KUZU_PATH=/data/kuzu
    volumes:
      - node3_data:/data
    networks:
      - malha_network
    depends_on:
      - postgres

  postgres:
    image: postgres:14
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=malha
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - malha_network

volumes:
  node1_data:
  node2_data:
  node3_data:
  postgres_data:

networks:
  malha_network:
    driver: bridge
```

### Start Cluster

```bash
docker-compose up -d
```

---

## Kubernetes Deployment

### StatefulSet

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: malha
spec:
  serviceName: malha
  replicas: 3
  selector:
    matchLabels:
      app: malha
  template:
    metadata:
      labels:
        app: malha
    spec:
      containers:
      - name: malha
        image: your-registry/malha:0.3.0
        ports:
        - containerPort: 50051
          name: synapse
        env:
        - name: NODE_ID
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        - name: SYNAPSE_PORT
          value: "50051"
        - name: PEERS
          value: "malha-0.malha:50051,malha-1.malha:50051,malha-2.malha:50051"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: malha-secrets
              key: database-url
        volumeMounts:
        - name: data
          mountPath: /data
  volumeClaimTemplates:
  - metadata:
      name: data
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 10Gi
```

### Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: malha
spec:
  clusterIP: None
  selector:
    app: malha
  ports:
  - port: 50051
    name: synapse
```

---

## Monitoring

### Health Check Endpoint

```python
from fastapi import FastAPI

app = FastAPI()

@app.get("/health")
async def health_check():
    # Check database connection
    try:
        async with manager.sql.get_session() as session:
            await session.execute("SELECT 1")
        db_status = "healthy"
    except Exception as e:
        db_status = f"unhealthy: {e}"
    
    # Check outbox status
    async with await manager.sql.get_session() as session:
        from sqlmodel import select
        from malha.malha import SysOutbox
        
        pending = await session.execute(
            select(SysOutbox).where(SysOutbox.status == "PENDING")
        )
        pending_count = len(pending.scalars().all())
        
        dlq = await session.execute(
            select(SysOutbox).where(SysOutbox.status == "DEAD_LETTER")
        )
        dlq_count = len(dlq.scalars().all())
    
    return {
        "status": "healthy" if db_status == "healthy" else "degraded",
        "database": db_status,
        "outbox": {
            "pending": pending_count,
            "dlq": dlq_count
        }
    }
```

### Prometheus Metrics (Future)

```python
# TODO: v0.4.0
from prometheus_client import Counter, Histogram

replication_events = Counter('malha_replication_events_total', 'Total replication events')
replication_latency = Histogram('malha_replication_latency_seconds', 'Replication latency')
```

---

## Security

### Network Security

```bash
# Firewall rules (iptables)
iptables -A INPUT -p tcp --dport 50051 -s 10.0.1.0/24 -j ACCEPT
iptables -A INPUT -p tcp --dport 50051 -j DROP
```

### Database Security

```python
# Use SSL for PostgreSQL
DATABASE_URL = "postgresql+asyncpg://user:pass@host/db?ssl=require"
```

### Future: TLS for Synapse (v0.4.0)

```python
# TODO: Implement TLS
synapse = SynapseDriver(
    node_id="node-1",
    port=50051,
    peers=["node-2:50051"],
    tls_cert="/path/to/cert.pem",
    tls_key="/path/to/key.pem"
)
```

---

## Troubleshooting

### Check Synapse Connectivity

```bash
# Test gRPC connection
grpcurl -plaintext 10.0.1.10:50051 list
```

### Check Outbox Status

```sql
-- Pending events
SELECT COUNT(*) FROM sys_outbox WHERE status = 'PENDING';

-- Dead letter queue
SELECT * FROM sys_outbox WHERE status = 'DEAD_LETTER';

-- Retry schedule
SELECT rid, retries, next_retry_at 
FROM sys_outbox 
WHERE status = 'RETRY' 
ORDER BY next_retry_at;
```

### Logs

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(name)s | %(levelname)s | %(message)s'
)
```

---

## Performance Tuning

### PostgreSQL

```sql
-- Increase connection pool
ALTER SYSTEM SET max_connections = 200;

-- Optimize for writes
ALTER SYSTEM SET synchronous_commit = off;
ALTER SYSTEM SET wal_writer_delay = 10ms;
```

### Malha

```python
# Adjust outbox batch size
# In malha.py, line 891
.limit(100)  # Increase for higher throughput
```

---

## Backup & Recovery

### Database Backup

```bash
# PostgreSQL
pg_dump malha > malha_backup.sql

# Restore
psql malha < malha_backup.sql
```

### Kùzu Backup

```bash
# Simple copy
cp -r /var/lib/malha/kuzu /backup/kuzu_$(date +%Y%m%d)
```

---

## Support

- **Documentation:** [SYNAPSE.md](SYNAPSE.md)
- **Issues:** GitHub Issues
- **Email:** kevin@example.com

---

**Malha v0.3.0** - Production-Ready Distributed Data Kernel 🚀
