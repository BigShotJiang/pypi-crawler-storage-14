"""
Tests for Fat Kernel v0.9.0 Components
======================================

Tests for the new centralized infrastructure components:
- Context Management (set_kernel, get_kernel, clear_kernel)
- Stream Driver (ParquetStreamDriver)
- Compute Driver (LocalComputeDriver)
- Transaction Management (UnitOfWork)
- Process State (SysProcess)
"""

import asyncio
import json
import os
import shutil
import tempfile
from datetime import UTC, datetime

import pytest
from pydantic import Field
from registro import DomainResource, register

from malha import (
    # Context Management
    connect,
    get_kernel,
    set_kernel,
    clear_kernel,
    # Stream Driver
    ParquetStreamDriver,
    # Compute Driver
    LocalComputeDriver,
    ComputeResult,
    RuntimeExecutionError,
    # Transaction Management
    UnitOfWork,
    Savepoint,
    # Process State
    SysProcess,
    ProcessStatus,
    # Core
    UnifiedDataManager,
    AsyncSQLAlchemyDriver,
    KuzuActor,
    DuckDBDriver,
    Interceptor,
)


# ==============================================================================
# Test Domain Resources
# ==============================================================================
# Note: Prefixed with "Sample" to avoid pytest collection warnings
# (pytest tries to collect classes starting with "Test" as test classes)

class SampleUser(DomainResource):
    """Sample user for Fat Kernel tests."""
    name: str = Field(..., min_length=1)
    email: str = Field(default="test@example.com")


class SampleOrder(DomainResource):
    """Sample order for Fat Kernel tests."""
    total: float = Field(..., gt=0)
    status: str = Field(default="pending")


# ==============================================================================
# Test Interceptors
# ============================================================================== 

class ReadFilterInterceptor(Interceptor):
    """Simple interceptor that hides specific RIDs on read."""

    def __init__(self, denied_rid: str):
        self.denied_rid = denied_rid

    async def on_write(self, obj, agent=None) -> None:  # pragma: no cover - not used in tests
        return None

    async def on_read(self, obj, agent=None):
        if obj.rid == self.denied_rid:
            return None
        return obj


# Register test resources
try:
    register("SampleUser", SampleUser)
    register("SampleOrder", SampleOrder)
except Exception:
    pass  # Already registered


# ==============================================================================
# Fixtures
# ==============================================================================

@pytest.fixture
async def temp_dir():
    """Create a temporary directory for tests."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def kernel(temp_dir):
    """Create a test kernel with all drivers."""
    db_path = os.path.join(temp_dir, "test.db")
    graph_path = os.path.join(temp_dir, "test_graph")
    
    sql = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
    await sql.create_tables()
    
    graph = KuzuActor(graph_path)
    analytics = DuckDBDriver(db_path)
    
    manager = UnifiedDataManager(
        sql_driver=sql,
        graph_driver=graph,
        analytics_driver=analytics,
        enable_monitoring=False,
        node_id="test-node",
    )
    
    # Set in global context
    set_kernel(manager)
    
    yield manager
    
    await manager.close()
    clear_kernel()


# ==============================================================================
# Tests: Context Management
# ==============================================================================

class TestContextManagement:
    """Tests for centralized context management."""
    
    @pytest.mark.asyncio
    async def test_set_and_get_kernel(self, kernel):
        """Test that set_kernel and get_kernel work correctly."""
        # Kernel was set in fixture
        retrieved = get_kernel()
        assert retrieved is kernel
    
    @pytest.mark.asyncio
    async def test_clear_kernel(self, kernel):
        """Test that clear_kernel removes the kernel from context."""
        # Kernel is set
        assert get_kernel() is kernel
        
        # Clear it
        clear_kernel()
        
        # Now get_kernel should raise
        with pytest.raises(RuntimeError, match="No kernel available"):
            get_kernel()
        
        # Restore for cleanup
        set_kernel(kernel)
    
    @pytest.mark.asyncio
    async def test_get_kernel_without_set_raises(self):
        """Test that get_kernel raises when no kernel is set."""
        # Clear any existing kernel
        clear_kernel()
        
        with pytest.raises(RuntimeError, match="No kernel available"):
            get_kernel()
    
    @pytest.mark.asyncio
    async def test_connect_sets_kernel(self, temp_dir):
        """Test that connect() automatically sets the kernel in context."""
        db_path = os.path.join(temp_dir, "connect_test.db")
        graph_path = os.path.join(temp_dir, "connect_graph")
        
        # Clear any existing kernel
        clear_kernel()
        
        # Connect should set the kernel
        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )
        
        try:
            # get_kernel should return the same instance
            assert get_kernel() is kernel
        finally:
            await kernel.close()
            clear_kernel()


# ==============================================================================
# Tests: Stream Driver
# ==============================================================================

class TestParquetStreamDriver:
    """Tests for ParquetStreamDriver."""
    
    @pytest.mark.asyncio
    async def test_write_single_record(self, temp_dir):
        """Test writing a single record."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=100,
        )
        
        await stream.write({
            "sensor_id": "s1",
            "value": 42.5,
            "timestamp": datetime.now(UTC).isoformat(),
        })
        
        # Record should be in buffer
        assert len(stream._buffer) == 1
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_write_batch(self, temp_dir):
        """Test writing multiple records."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=100,
        )
        
        records = [
            {"sensor_id": f"s{i}", "value": float(i)} 
            for i in range(10)
        ]
        
        await stream.write_batch(records)
        
        assert len(stream._buffer) == 10
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_auto_flush_on_limit(self, temp_dir):
        """Test that buffer auto-flushes when limit is reached."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=5,  # Low limit for testing
        )
        
        # Write 6 records (should trigger flush at 5)
        for i in range(6):
            await stream.write({"id": i, "value": float(i)})
        
        # Buffer should have 1 record (6 - 5 flushed)
        assert len(stream._buffer) == 1
        assert stream._total_written == 5
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_partition_column_extraction(self, temp_dir):
        """Test that partition columns are extracted from timestamp."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            partition_cols=["year", "month", "day"],
        )
        
        await stream.write({
            "sensor_id": "s1",
            "timestamp": "2024-06-15T10:30:00Z",
        })
        
        # Check that partition columns were added
        record = stream._buffer[0]
        assert record["year"] == 2024
        assert record["month"] == 6
        assert record["day"] == 15
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_get_stats(self, temp_dir):
        """Test get_stats method."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=100,
        )
        
        await stream.write({"id": 1})
        await stream.write({"id": 2})
        
        stats = stream.get_stats()
        
        assert stats["buffer_size"] == 2
        assert stats["total_written"] == 0
        assert "stream_data" in stats["base_path"]
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_wal_enabled(self, temp_dir):
        """Test WAL-enabled stream driver."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "wal_stream"),
            buffer_limit=100,
            wal_enabled=True,
        )
        
        await stream.write({"id": 1, "value": "test"})
        
        # WAL file should exist
        assert stream._wal_path.exists()
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_wal_recovery(self, temp_dir):
        """Test WAL recovery after crash simulation."""
        base_path = os.path.join(temp_dir, "recovery_stream")
        wal_path = os.path.join(base_path, ".wal", "pending.ndjson")
        os.makedirs(os.path.dirname(wal_path), exist_ok=True)
        
        # Simulate crash: write WAL file directly
        with open(wal_path, "w") as f:
            f.write('{"id": 1, "recovered": true}\n')
            f.write('{"id": 2, "recovered": true}\n')
        
        # Create stream - should recover from WAL
        stream = ParquetStreamDriver(
            base_path=base_path,
            buffer_limit=100,
            wal_enabled=True,
        )
        
        # Buffer should have recovered records
        assert len(stream._buffer) == 2
        assert stream._buffer[0]["recovered"] is True
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_wal_corrupted_line(self, temp_dir):
        """Test WAL recovery skips corrupted lines."""
        base_path = os.path.join(temp_dir, "corrupt_stream")
        wal_path = os.path.join(base_path, ".wal", "pending.ndjson")
        os.makedirs(os.path.dirname(wal_path), exist_ok=True)
        
        # Write WAL with corrupted line
        with open(wal_path, "w") as f:
            f.write('{"id": 1}\n')
            f.write('not valid json\n')  # Corrupted
            f.write('{"id": 2}\n')
        
        stream = ParquetStreamDriver(
            base_path=base_path,
            buffer_limit=100,
            wal_enabled=True,
        )
        
        # Should recover 2 valid records, skip corrupted
        assert len(stream._buffer) == 2
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_partition_extraction_datetime_object(self, temp_dir):
        """Test partition extraction from datetime object."""
        from datetime import datetime, timezone
        
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "partition_dt"),
            partition_cols=["year", "month", "day"],
        )
        
        dt = datetime(2024, 7, 20, 12, 0, 0, tzinfo=timezone.utc)
        await stream.write({
            "id": 1,
            "timestamp": dt,
        })
        
        record = stream._buffer[0]
        assert record["year"] == 2024
        assert record["month"] == 7
        assert record["day"] == 20
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_partition_extraction_invalid_timestamp(self, temp_dir):
        """Test partition extraction with invalid timestamp."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "partition_invalid"),
            partition_cols=["year", "month", "day"],
        )
        
        await stream.write({
            "id": 1,
            "timestamp": "not-a-date",
        })
        
        # Should not crash, just not add partition cols
        record = stream._buffer[0]
        assert "year" not in record
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_write_batch_with_wal(self, temp_dir):
        """Test write_batch with WAL enabled."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "batch_wal"),
            buffer_limit=100,
            wal_enabled=True,
        )
        
        records = [{"id": i} for i in range(5)]
        await stream.write_batch(records)
        
        assert len(stream._buffer) == 5
        assert stream._wal_path.exists()
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_json_fallback(self, temp_dir):
        """Test JSON fallback method."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "json_fallback"),
            buffer_limit=100,
        )
        
        records = [{"id": 1, "name": "test"}]
        count = stream._write_json_fallback(records)
        
        assert count == 1
        
        # Check file was created
        import glob
        files = glob.glob(os.path.join(temp_dir, "json_fallback", "*.ndjson"))
        assert len(files) == 1
        
        await stream.close()


# ==============================================================================
# Tests: Compute Driver
# ==============================================================================

class TestLocalComputeDriver:
    """Tests for LocalComputeDriver."""
    
    @pytest.mark.asyncio
    async def test_validate_safe_code(self, temp_dir):
        """Test that safe code passes validation."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        safe_code = '''
x = 1 + 2
print(x)
'''
        errors = compute.validate(safe_code)
        assert errors == []
    
    @pytest.mark.asyncio
    async def test_validate_forbidden_import(self, temp_dir):
        """Test that forbidden imports are detected."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        unsafe_code = '''
import os
os.system("ls")
'''
        errors = compute.validate(unsafe_code)
        assert any("os" in e for e in errors)
    
    @pytest.mark.asyncio
    async def test_validate_forbidden_pattern(self, temp_dir):
        """Test that forbidden patterns are detected."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        unsafe_code = '''
eval("1 + 2")
'''
        errors = compute.validate(unsafe_code)
        assert any("eval" in e for e in errors)
    
    @pytest.mark.asyncio
    async def test_validate_syntax_error(self, temp_dir):
        """Test that syntax errors are detected."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        bad_code = '''
def broken(
    print("missing paren")
'''
        errors = compute.validate(bad_code)
        assert any("Syntax error" in e for e in errors)
    
    @pytest.mark.asyncio
    async def test_execute_returns_result(self, temp_dir):
        """Test that execute returns a ComputeResult."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        result = await compute.execute('print("hello")')
        
        assert isinstance(result, ComputeResult)
        assert result.execution_time_ms > 0
    
    @pytest.mark.asyncio
    async def test_execute_validation_failure(self, temp_dir):
        """Test that validation failures return error result."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        result = await compute.execute('import os; os.system("ls")')
        
        assert result.success is False
        assert "Validation failed" in result.error
    
    @pytest.mark.asyncio
    async def test_pep723_header_generation(self, temp_dir):
        """Test PEP 723 header generation."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        code = 'print("hello")'
        deps = ["httpx", "pandas>=2.0"]
        
        result = compute._to_pep723(code, deps)
        
        assert "# /// script" in result
        assert "requires-python" in result
        assert '"httpx"' in result
        assert '"pandas>=2.0"' in result
        assert 'print("hello")' in result
    
    @pytest.mark.asyncio
    async def test_run_script_raises_on_error(self, temp_dir):
        """Test that run_script raises RuntimeExecutionError on failure."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        with pytest.raises(RuntimeExecutionError):
            await compute.run_script('import subprocess')
    
    @pytest.mark.asyncio
    async def test_compute_driver_default_work_dir(self):
        """Test compute driver with default work_dir."""
        compute = LocalComputeDriver()
        assert compute.work_dir.exists()
        assert "malha_compute" in str(compute.work_dir)
    
    @pytest.mark.asyncio
    async def test_compute_driver_string_work_dir(self, temp_dir):
        """Test compute driver with string work_dir."""
        work_path = os.path.join(temp_dir, "compute_test")
        compute = LocalComputeDriver(work_dir=work_path)
        assert compute.work_dir.exists()
        assert str(compute.work_dir) == work_path
    
    @pytest.mark.asyncio
    async def test_compute_driver_path_work_dir(self, temp_dir):
        """Test compute driver with Path work_dir."""
        from pathlib import Path
        work_path = Path(temp_dir) / "compute_path_test"
        compute = LocalComputeDriver(work_dir=work_path)
        assert compute.work_dir.exists()
        assert compute.work_dir == work_path


# ==============================================================================
# Tests: Unit of Work
# ==============================================================================

class TestUnitOfWork:
    """Tests for UnitOfWork transaction management."""
    
    @pytest.mark.asyncio
    async def test_add_objects(self, kernel):
        """Test adding objects to unit of work."""
        async with UnitOfWork(kernel) as uow:
            user = SampleUser(name="Alice")
            order = SampleOrder(total=100.0)
            
            uow.add(user)
            uow.add(order)
            
            assert uow.pending_objects == 2
            assert uow.pending_links == 0
    
    @pytest.mark.asyncio
    async def test_add_links(self, kernel):
        """Test adding links to unit of work."""
        async with UnitOfWork(kernel) as uow:
            user = SampleUser(name="Bob")
            order = SampleOrder(total=50.0)
            
            uow.add(user)
            uow.add(order)
            uow.link(user, "PLACED", order)
            
            assert uow.pending_links == 1
    
    @pytest.mark.asyncio
    async def test_commit_persists_objects(self, kernel):
        """Test that commit persists all objects."""
        user = SampleUser(name="Charlie")
        order = SampleOrder(total=75.0)
        
        async with UnitOfWork(kernel) as uow:
            uow.add(user)
            uow.add(order)
            
            saved = await uow.commit()
            
            assert len(saved) == 2
            assert saved[0].rid is not None
            assert saved[1].rid is not None
    
    @pytest.mark.asyncio
    async def test_clear_removes_pending(self, kernel):
        """Test that clear removes pending objects and links."""
        async with UnitOfWork(kernel) as uow:
            uow.add(SampleUser(name="Dave"))
            uow.link(SampleUser(name="A"), "KNOWS", SampleUser(name="B"))
            
            assert uow.pending_objects == 1
            assert uow.pending_links == 1
            
            uow.clear()
            
            assert uow.pending_objects == 0
            assert uow.pending_links == 0
    
    @pytest.mark.asyncio
    async def test_context_manager_rollback_on_error(self, kernel):
        """Test that context manager clears on exception."""
        uow = UnitOfWork(kernel)
        
        try:
            async with uow:
                uow.add(SampleUser(name="Eve"))
                raise ValueError("Test error")
        except ValueError:
            pass
        
        # Should have been cleared
        assert uow.pending_objects == 0
    
    @pytest.mark.asyncio
    async def test_uses_context_kernel(self, kernel):
        """Test that UnitOfWork uses kernel from context if not provided."""
        # kernel fixture sets the context
        async with UnitOfWork() as uow:  # No kernel argument
            user = SampleUser(name="Frank")
            uow.add(user)
            
            # Should use kernel from context
            saved = await uow.commit()
            assert len(saved) == 1


# ==============================================================================
# Tests: Process State
# ==============================================================================

class TestSysProcess:
    """Tests for SysProcess model."""
    
    def test_create_process(self):
        """Test creating a SysProcess instance."""
        process = SysProcess(
            process_type="workflow",
            process_name="TestWorkflow",
            status=ProcessStatus.PENDING.value,
            node_id="test-node",
        )
        
        assert process.process_type == "workflow"
        assert process.process_name == "TestWorkflow"
        assert process.status == "PENDING"
    
    def test_process_status_enum(self):
        """Test ProcessStatus enum values."""
        assert ProcessStatus.PENDING.value == "PENDING"
        assert ProcessStatus.RUNNING.value == "RUNNING"
        assert ProcessStatus.COMPLETED.value == "COMPLETED"
        assert ProcessStatus.FAILED.value == "FAILED"
        assert ProcessStatus.COMPENSATING.value == "COMPENSATING"
        assert ProcessStatus.COMPENSATED.value == "COMPENSATED"
        assert ProcessStatus.DEAD_LETTER.value == "DEAD_LETTER"
    
    def test_process_with_state_payload(self):
        """Test SysProcess with JSON state payload."""
        state = {"step": 2, "order_id": "123", "items": ["a", "b"]}
        
        process = SysProcess(
            process_type="saga",
            process_name="OrderSaga",
            status=ProcessStatus.RUNNING.value,
            state_payload=json.dumps(state),
        )
        
        # Deserialize and verify
        loaded_state = json.loads(process.state_payload)
        assert loaded_state["step"] == 2
        assert loaded_state["order_id"] == "123"
    
    def test_process_defaults(self):
        """Test SysProcess default values."""
        process = SysProcess(
            process_type="job",
            process_name="TestJob",
        )
        
        assert process.status == ProcessStatus.PENDING.value
        assert process.retries == 0
        assert process.node_id == "local"
        assert process.parent_id is None


# ==============================================================================
# Integration Tests
# ==============================================================================

class TestFatKernelIntegration:
    """Integration tests for Fat Kernel components working together."""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self, kernel):
        """Test a complete workflow using all Fat Kernel components."""
        # 1. Use UnitOfWork to create related objects
        user = SampleUser(name="Integration Test User")
        order1 = SampleOrder(total=100.0)
        order2 = SampleOrder(total=200.0)
        
        async with UnitOfWork(kernel) as uow:
            uow.add(user)
            uow.add(order1)
            uow.add(order2)
            uow.link(user, "PLACED", order1)
            uow.link(user, "PLACED", order2)
            
            saved = await uow.commit()
        
        assert len(saved) == 3
        
        # 2. Verify objects were persisted
        retrieved_user = await kernel.get(SampleUser, saved[0].rid)
        assert retrieved_user is not None
        assert retrieved_user.name == "Integration Test User"


class TestBatchRetrieval:
    """Tests for UnifiedDataManager.mget batch retrieval."""

    @pytest.mark.asyncio
    async def test_mget_returns_multiple_resources(self, kernel):
        user_a = SampleUser(name="Batch User A")
        user_b = SampleUser(name="Batch User B")

        saved_a = await kernel.save_versioned(user_a)
        saved_b = await kernel.save_versioned(user_b)

        rids = [saved_a.rid, saved_b.rid]
        results = await kernel.mget(SampleUser, rids)

        assert len(results) == 2
        assert {r.rid for r in results} == set(rids)

    @pytest.mark.asyncio
    async def test_mget_applies_interceptors(self, kernel):
        user_allowed = SampleUser(name="Visible User")
        user_hidden = SampleUser(name="Hidden User")

        saved_allowed = await kernel.save_versioned(user_allowed)
        saved_hidden = await kernel.save_versioned(user_hidden)

        interceptor = ReadFilterInterceptor(denied_rid=saved_hidden.rid)
        kernel.add_interceptor(interceptor)

        try:
            results = await kernel.mget(SampleUser, [saved_allowed.rid, saved_hidden.rid])
            assert len(results) == 1
            assert results[0].rid == saved_allowed.rid
        finally:
            kernel._interceptors.remove(interceptor)

    
    @pytest.mark.asyncio
    async def test_context_isolation(self, temp_dir):
        """Test that context is properly isolated."""
        # Create two separate kernels
        db1 = os.path.join(temp_dir, "db1.db")
        db2 = os.path.join(temp_dir, "db2.db")
        graph1 = os.path.join(temp_dir, "graph1")
        graph2 = os.path.join(temp_dir, "graph2")
        
        kernel1 = await connect(
            url=f"sqlite+aiosqlite:///{db1}",
            kuzu_path=graph1,
            enable_monitoring=False,
        )
        
        # get_kernel should return kernel1
        assert get_kernel() is kernel1
        
        # Set kernel2
        sql2 = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db2}")
        await sql2.create_tables()
        graph2_driver = KuzuActor(graph2)
        analytics2 = DuckDBDriver(db2)
        
        kernel2 = UnifiedDataManager(
            sql_driver=sql2,
            graph_driver=graph2_driver,
            analytics_driver=analytics2,
            enable_monitoring=False,
        )
        
        set_kernel(kernel2)
        
        # Now get_kernel should return kernel2
        assert get_kernel() is kernel2
        
        # Cleanup
        await kernel1.close()
        await kernel2.close()
        clear_kernel()


# ==============================================================================
# Tests: Alembic Migrations
# ==============================================================================

class TestAlembicDriver:
    """Tests for embedded Alembic migrations."""

    @pytest.mark.asyncio
    async def test_alembic_driver_init(self, kernel, temp_dir):
        """Test AlembicDriver initialization."""
        from malha.drivers.alembic import AlembicDriver
        
        migrations_path = os.path.join(temp_dir, "migrations")
        driver = AlembicDriver(kernel, migrations_path=migrations_path)
        
        # Should not be initialized yet
        assert not driver.is_initialized
        
        # Initialize
        result = await driver.init()
        assert result.success
        assert result.operation == "init"
        
        # Now should be initialized
        assert driver.is_initialized
        assert os.path.exists(os.path.join(migrations_path, "env.py"))
        assert os.path.exists(os.path.join(migrations_path, "versions"))

    @pytest.mark.asyncio
    async def test_alembic_driver_current_revision(self, kernel, temp_dir):
        """Test getting current revision."""
        from malha.drivers.alembic import AlembicDriver
        
        migrations_path = os.path.join(temp_dir, "migrations")
        driver = AlembicDriver(kernel, migrations_path=migrations_path)
        
        # Initialize
        await driver.init()
        
        # No migrations applied yet
        current = await driver.current()
        assert current is None

    @pytest.mark.asyncio
    async def test_migrator_alembic_integration(self, kernel, temp_dir):
        """Test Migrator's AlembicDriver integration."""
        from malha.maintenance import Migrator
        
        migrations_path = os.path.join(temp_dir, "migrations")
        migrator = Migrator(kernel, migrations_path=migrations_path)
        
        # Initialize via migrator
        result = await migrator.init_alembic()
        assert result.success
        
        # Check alembic property works
        assert migrator.alembic is not None
        assert migrator.alembic.is_initialized


# ==============================================================================
# RFC-001: RUNTIME COGNITIVO TRANSACIONAL TESTS
# ==============================================================================

class TestRFC001SysProcessEnhancements:
    """Tests for SysProcess enhancements (Tarefa A)."""
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_idempotency_key(self, kernel):
        """Test that SysProcess has idempotency_key field."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
            idempotency_key="test-key-123",
        )
        assert process.idempotency_key == "test-key-123"
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_lock_version(self, kernel):
        """Test that SysProcess has lock_version for optimistic locking."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
        )
        assert process.lock_version == 0
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_result_payload(self, kernel):
        """Test that SysProcess has result_payload field."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
            result_payload='{"answer": 42}',
        )
        assert process.result_payload == '{"answer": 42}'
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_timestamps(self, kernel):
        """Test that SysProcess has created_at and updated_at."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
        )
        assert process.created_at is not None
        assert process.updated_at is not None
    
    @pytest.mark.asyncio
    async def test_process_status_suspended(self):
        """Test SUSPENDED status exists."""
        assert ProcessStatus.SUSPENDED.value == "SUSPENDED"
    
    @pytest.mark.asyncio
    async def test_process_status_recovering(self):
        """Test RECOVERING status exists."""
        assert ProcessStatus.RECOVERING.value == "RECOVERING"


class TestRFC001Savepoints:
    """Tests for UnitOfWork Savepoints (Tarefa B)."""
    
    @pytest.mark.asyncio
    async def test_savepoint_rollback_on_error(self, kernel):
        """Test that savepoint rolls back only its changes on error."""
        uow = UnitOfWork(kernel)
        
        # Add first object
        user1 = SampleUser(name="User1")
        uow.add(user1)
        assert uow.pending_objects == 1
        
        # Add second object in savepoint that will fail
        async with uow.savepoint():
            user2 = SampleUser(name="User2")
            uow.add(user2)
            assert uow.pending_objects == 2
            raise ValueError("Simulated tool failure")
        
        # After savepoint rollback, only user1 should remain
        assert uow.pending_objects == 1
    
    @pytest.mark.asyncio
    async def test_savepoint_success_keeps_changes(self, kernel):
        """Test that successful savepoint keeps its changes."""
        uow = UnitOfWork(kernel)
        
        user1 = SampleUser(name="User1")
        uow.add(user1)
        
        async with uow.savepoint():
            user2 = SampleUser(name="User2")
            uow.add(user2)
            # No exception - changes are kept
        
        assert uow.pending_objects == 2
    
    @pytest.mark.asyncio
    async def test_nested_savepoints(self, kernel):
        """Test nested savepoints work correctly."""
        uow = UnitOfWork(kernel)
        
        uow.add(SampleUser(name="Level0"))  # Base
        
        async with uow.savepoint():
            uow.add(SampleUser(name="Level1"))
            
            async with uow.savepoint():
                uow.add(SampleUser(name="Level2"))
                raise ValueError("Inner failure")
            
            # Inner rolled back, but level 1 still there
            assert uow.pending_objects == 2
        
        # All kept after outer succeeds
        assert uow.pending_objects == 2
    
    @pytest.mark.asyncio
    async def test_uow_rollback_method(self, kernel):
        """Test explicit rollback method."""
        uow = UnitOfWork(kernel)
        
        uow.add(SampleUser(name="Test"))
        assert uow.pending_objects == 1
        
        await uow.rollback()
        assert uow.pending_objects == 0
    
    @pytest.mark.asyncio
    async def test_uow_is_committed_property(self, kernel):
        """Test is_committed property."""
        uow = UnitOfWork(kernel)
        assert uow.is_committed is False


class TestRFC001ProcessLocking:
    """Tests for Process Locking (Tarefa C)."""
    
    @pytest.mark.asyncio
    async def test_get_or_create_process_creates_new(self, kernel):
        """Test get_or_create_process creates new process."""
        process, created = await kernel.get_or_create_process(
            idempotency_key="unique-key-001",
            process_type="agent",
            process_name="TestAgent",
        )
        
        assert created is True
        assert process.idempotency_key == "unique-key-001"
        assert process.status == ProcessStatus.PENDING.value
    
    @pytest.mark.asyncio
    async def test_get_or_create_process_returns_existing(self, kernel):
        """Test get_or_create_process returns existing process."""
        # Create first
        process1, created1 = await kernel.get_or_create_process(
            idempotency_key="duplicate-key-001",
            process_type="agent",
            process_name="Agent1",
        )
        assert created1 is True
        
        # Try to create with same key
        process2, created2 = await kernel.get_or_create_process(
            idempotency_key="duplicate-key-001",
            process_type="agent",
            process_name="Agent2",  # Different name, same key
        )
        
        assert created2 is False
        assert process2.id == process1.id
        assert process2.process_name == "Agent1"  # Original name
    
    @pytest.mark.asyncio
    async def test_acquire_and_release_lock(self, kernel):
        """Test acquiring and releasing process lock."""
        # Create a process
        process, _ = await kernel.get_or_create_process(
            idempotency_key="lock-test-001",
            process_type="workflow",
            process_name="LockTest",
        )
        
        # Acquire lock
        locked = await kernel.acquire_process_lock(process.id)
        assert locked is not None
        assert locked.heartbeat is not None
        
        # Release lock
        released = await kernel.release_process_lock(process.id)
        assert released is True
    
    @pytest.mark.asyncio
    async def test_acquire_lock_nonexistent_process(self, kernel):
        """Test acquiring lock on non-existent process returns None."""
        locked = await kernel.acquire_process_lock(99999)
        assert locked is None
    
    @pytest.mark.asyncio
    async def test_update_process_state(self, kernel):
        """Test updating process state."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="update-test-001",
            process_type="agent",
            process_name="UpdateTest",
        )
        
        # Update to RUNNING
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.RUNNING,
            state_payload='{"step": 1}',
        )
        
        assert updated.status == ProcessStatus.RUNNING.value
        assert updated.state_payload == '{"step": 1}'
        assert updated.lock_version == 1  # Incremented
    
    @pytest.mark.asyncio
    async def test_update_process_to_completed(self, kernel):
        """Test updating process to COMPLETED sets completed_at."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="complete-test-001",
            process_type="agent",
            process_name="CompleteTest",
        )
        
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.COMPLETED,
            result_payload='{"answer": "success"}',
        )
        
        assert updated.status == ProcessStatus.COMPLETED.value
        assert updated.completed_at is not None
        assert updated.result_payload == '{"answer": "success"}'


class TestRFC001AdditionalFeatures:
    """Tests for additional RFC-001 features (v0.11.1)."""
    
    @pytest.mark.asyncio
    async def test_find_process_by_idempotency(self, kernel):
        """Test find_process_by_idempotency method."""
        # Create a process first
        process, _ = await kernel.get_or_create_process(
            idempotency_key="find-test-001",
            process_type="agent",
            process_name="FindTest",
        )
        
        # Find it
        found = await kernel.find_process_by_idempotency("find-test-001")
        assert found is not None
        assert found.id == process.id
        assert found.idempotency_key == "find-test-001"
    
    @pytest.mark.asyncio
    async def test_find_process_by_idempotency_not_found(self, kernel):
        """Test find_process_by_idempotency returns None for missing key."""
        found = await kernel.find_process_by_idempotency("nonexistent-key")
        assert found is None
    
    @pytest.mark.asyncio
    async def test_kernel_unit_of_work_factory(self, kernel):
        """Test kernel.unit_of_work() factory method."""
        uow = kernel.unit_of_work()
        assert uow is not None
        assert isinstance(uow, UnitOfWork)
        assert uow._kernel is kernel
    
    @pytest.mark.asyncio
    async def test_uow_context_manager_with_factory(self, kernel):
        """Test using kernel.unit_of_work() as context manager."""
        async with kernel.unit_of_work() as uow:
            user = SampleUser(name="FactoryTest")
            uow.add(user)
            assert uow.pending_objects == 1
    
    @pytest.mark.asyncio
    async def test_savepoint_index_property(self, kernel):
        """Test Savepoint.index property."""
        uow = UnitOfWork(kernel)
        
        uow.add(SampleUser(name="User1"))
        
        async with uow.savepoint() as sp:
            assert sp.index == 1  # After User1
            uow.add(SampleUser(name="User2"))
    
    @pytest.mark.asyncio
    async def test_rollback_to_savepoint_manual(self, kernel):
        """Test manual rollback_to_savepoint method."""
        uow = UnitOfWork(kernel)
        
        uow.add(SampleUser(name="User1"))
        sp_index = uow.pending_objects  # Save index
        
        uow.add(SampleUser(name="User2"))
        uow.add(SampleUser(name="User3"))
        assert uow.pending_objects == 3
        
        await uow.rollback_to_savepoint(sp_index)
        assert uow.pending_objects == 1
    
    @pytest.mark.asyncio
    async def test_uow_session_property(self, kernel):
        """Test UoW session property is available in context."""
        async with kernel.unit_of_work() as uow:
            # Session may or may not be available depending on driver
            # Just verify the property exists and doesn't error
            _ = uow.session
    
    @pytest.mark.asyncio
    async def test_uow_is_committed_after_commit(self, kernel):
        """Test is_committed is True after successful commit."""
        async with kernel.unit_of_work() as uow:
            user = SampleUser(name="CommitTest")
            uow.add(user)
            await uow.commit()
            assert uow.is_committed is True


# =============================================================================
# COVERAGE BOOST TESTS - Target 75%+
# =============================================================================

class TestKernelCRUDOperations:
    """Tests for kernel CRUD operations to boost coverage."""
    
    @pytest.mark.asyncio
    async def test_save_versioned_creates_record(self, kernel):
        """Test save_versioned creates a new record."""
        user = SampleUser(name="SaveVersionedTest")
        saved = await kernel.save_versioned(user)
        assert saved is not None
        assert saved.name == "SaveVersionedTest"
    
    @pytest.mark.asyncio
    async def test_save_versioned_with_origin(self, kernel):
        """Test save_versioned with origin parameter."""
        user = SampleUser(name="OriginTest")
        saved = await kernel.save_versioned(user, origin="remote")
        assert saved is not None
    
    @pytest.mark.asyncio
    async def test_save_versioned_with_agent(self, kernel):
        """Test save_versioned with agent parameter."""
        user = SampleUser(name="AgentTest")
        saved = await kernel.save_versioned(user, agent="test-agent")
        assert saved is not None
    
    @pytest.mark.asyncio
    async def test_get_repository(self, kernel):
        """Test get_repository method."""
        repo = kernel.get_repository(SampleUser)
        assert repo is not None
    
    @pytest.mark.asyncio
    async def test_mget_multiple_rids(self, kernel):
        """Test fetching multiple resources by RID."""
        # Create some users
        user1 = await kernel.save_versioned(SampleUser(name="MgetUser1"))
        user2 = await kernel.save_versioned(SampleUser(name="MgetUser2"))
        user3 = await kernel.save_versioned(SampleUser(name="MgetUser3"))
        
        # Fetch by RIDs
        results = await kernel.mget(SampleUser, [user1.rid, user2.rid, user3.rid])
        
        assert len(results) == 3
        names = {r.name for r in results}
        assert "MgetUser1" in names
        assert "MgetUser2" in names
        assert "MgetUser3" in names
    
    @pytest.mark.asyncio
    async def test_mget_empty_list(self, kernel):
        """Test mget with empty list returns empty."""
        results = await kernel.mget(SampleUser, [])
        assert results == []
    
    @pytest.mark.asyncio
    async def test_mget_nonexistent_rids(self, kernel):
        """Test mget with nonexistent RIDs."""
        results = await kernel.mget(SampleUser, ["ri.nonexistent.1", "ri.nonexistent.2"])
        assert len(results) == 0
    
    @pytest.mark.asyncio
    async def test_get_by_rid(self, kernel):
        """Test getting a record by RID."""
        user = SampleUser(name="GetByRidTest")
        saved = await kernel.save_versioned(user)
        
        # Get by RID (RIDs start with "ri.")
        retrieved = await kernel.get(SampleUser, saved.rid)
        assert retrieved is not None
        assert retrieved.name == "GetByRidTest"
    
    @pytest.mark.asyncio
    async def test_get_nonexistent_returns_none(self, kernel):
        """Test getting nonexistent record returns None."""
        result = await kernel.get(SampleUser, "ri.nonexistent.rid")
        assert result is None
    
    @pytest.mark.asyncio
    async def test_list_resources(self, kernel):
        """Test listing resources."""
        # Create some users
        await kernel.save_versioned(SampleUser(name="ListTest1"))
        await kernel.save_versioned(SampleUser(name="ListTest2"))
        
        # List all
        users = await kernel.list(SampleUser)
        assert len(users) >= 2
    
    @pytest.mark.asyncio
    async def test_list_with_limit(self, kernel):
        """Test listing with limit."""
        # Create users
        for i in range(5):
            await kernel.save_versioned(SampleUser(name=f"LimitTest{i}"))
        
        # List with limit
        users = await kernel.list(SampleUser, limit=2)
        assert len(users) == 2
    
    @pytest.mark.asyncio
    async def test_delete_versioned(self, kernel):
        """Test deleting a resource with versioning."""
        user = SampleUser(name="DeleteTest")
        saved = await kernel.save_versioned(user)
        
        # Delete using delete_versioned
        await kernel.delete_versioned(saved)
        
        # Verify deleted (should return None for active version)
        retrieved = await kernel.get(SampleUser, saved.rid)
        assert retrieved is None


class TestRepositoryOperations:
    """Tests for BaseRepository operations."""
    
    @pytest.mark.asyncio
    async def test_repository_create(self, kernel):
        """Test creating via repository."""
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            user = SampleUser(name="RepoCreateTest")
            created = await repo.create(session, user)
            await session.commit()
            
            assert created is not None
            assert created.name == "RepoCreateTest"
    
    @pytest.mark.asyncio
    async def test_repository_get_history(self, kernel):
        """Test getting version history."""
        repo = kernel.get_repository(SampleUser)
        
        # Create a user with save_versioned to get RID
        user = SampleUser(name="HistoryTest")
        saved = await kernel.save_versioned(user)
        
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=saved.rid)
            assert len(history) >= 1
    
    @pytest.mark.asyncio
    async def test_repository_get_history_ascending(self, kernel):
        """Test getting version history in ascending order."""
        repo = kernel.get_repository(SampleUser)
        
        user = SampleUser(name="HistoryAscTest")
        saved = await kernel.save_versioned(user)
        
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=saved.rid, ascending=True)
            assert len(history) >= 1
    
    @pytest.mark.asyncio
    async def test_repository_get_with_filters(self, kernel):
        """Test getting with filters."""
        repo = kernel.get_repository(SampleUser)
        
        user = SampleUser(name="FilterTest")
        saved = await kernel.save_versioned(user)
        
        async with await kernel.sql_driver.get_session() as session:
            # Get with name filter
            found = await repo.get(session, rid=saved.rid, name="FilterTest")
            assert found is not None
    
    @pytest.mark.asyncio
    async def test_repository_get_active_only(self, kernel):
        """Test getting only active records."""
        repo = kernel.get_repository(SampleUser)
        
        user = SampleUser(name="ActiveOnlyTest")
        saved = await kernel.save_versioned(user)
        
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=saved.rid, active_only=True)
            assert found is not None
    
    @pytest.mark.asyncio
    async def test_repository_get_by_version(self, kernel):
        """Test getting by specific version."""
        repo = kernel.get_repository(SampleUser)
        
        user = SampleUser(name="VersionTest")
        saved = await kernel.save_versioned(user)
        
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=saved.rid, version=saved.version)
            assert found is not None
    
    @pytest.mark.asyncio
    async def test_repository_mget(self, kernel):
        """Test mget method."""
        repo = kernel.get_repository(SampleUser)
        
        user1 = await kernel.save_versioned(SampleUser(name="MgetRepoTest1"))
        user2 = await kernel.save_versioned(SampleUser(name="MgetRepoTest2"))
        
        async with await kernel.sql_driver.get_session() as session:
            results = await repo.mget(session, rids=[user1.rid, user2.rid])
            assert len(results) == 2
    
    @pytest.mark.asyncio
    async def test_repository_create_from_dict(self, kernel):
        """Test creating from dict via repository."""
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            created = await repo.create(session, {"name": "DictCreateTest"})
            await session.commit()
            
            assert created.name == "DictCreateTest"
    
    @pytest.mark.asyncio
    async def test_repository_update(self, kernel):
        """Test updating via repository."""
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            # Create
            user = SampleUser(name="UpdateTest")
            created = await repo.create(session, user)
            await session.commit()
            
            # Update
            updated = await repo.update(session, created.id, {"name": "UpdatedName"})
            await session.commit()
            
            assert updated is not None
            assert updated.name == "UpdatedName"
    
    @pytest.mark.asyncio
    async def test_repository_delete(self, kernel):
        """Test deleting via repository."""
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            # Create
            user = SampleUser(name="DeleteRepoTest")
            created = await repo.create(session, user)
            await session.commit()
            
            # Delete
            deleted = await repo.delete(session, created.id)
            await session.commit()
            
            assert deleted is True
            
            # Verify deleted
            found = await repo.get(session, created.id)
            assert found is None
    
    @pytest.mark.asyncio
    async def test_repository_list(self, kernel):
        """Test listing via repository."""
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            # Create some users
            await repo.create(session, SampleUser(name="ListRepo1"))
            await repo.create(session, SampleUser(name="ListRepo2"))
            await session.commit()
            
            # List
            users = await repo.list(session, limit=10)
            assert len(users) >= 2


class TestSaveOperations:
    """Tests for save operations."""
    
    @pytest.mark.asyncio
    async def test_save_new_resource(self, kernel):
        """Test saving a new resource."""
        user = SampleUser(name="SaveNewTest")
        result = await kernel.save(SampleUser, user)
        
        assert result is not None
        assert result.name == "SaveNewTest"
    
    @pytest.mark.asyncio
    async def test_save_from_dict(self, kernel):
        """Test saving from dict."""
        result = await kernel.save(SampleUser, {"name": "SaveDictTest"})
        
        assert result is not None
        assert result.name == "SaveDictTest"
    
    @pytest.mark.asyncio
    async def test_save_update_existing(self, kernel):
        """Test updating an existing resource."""
        # Create first
        user = SampleUser(name="SaveUpdateTest")
        created = await kernel.save(SampleUser, user)
        
        # Update
        created.name = "UpdatedName"
        updated = await kernel.save(SampleUser, created)
        
        assert updated.name == "UpdatedName"


class TestInsertOperations:
    """Tests for insert operations."""
    
    @pytest.mark.asyncio
    async def test_insert_with_replicate(self, kernel):
        """Test insert with replication enabled."""
        user = SampleUser(name="InsertReplicateTest")
        result = await kernel.insert(user, replicate=True)
        
        assert result is not None
        assert result.name == "InsertReplicateTest"
        assert result.rid is not None
    
    @pytest.mark.asyncio
    async def test_insert_without_replicate(self, kernel):
        """Test insert without replication."""
        user = SampleUser(name="InsertNoReplicateTest")
        result = await kernel.insert(user, replicate=False)
        
        assert result is not None
        assert result.name == "InsertNoReplicateTest"
    
    @pytest.mark.asyncio
    async def test_insert_multiple(self, kernel):
        """Test inserting multiple records."""
        for i in range(3):
            user = SampleUser(name=f"InsertMulti{i}")
            result = await kernel.insert(user, replicate=True)
            assert result is not None
    
    @pytest.mark.asyncio
    async def test_insert_batch(self, kernel):
        """Test batch insert."""
        users = [
            SampleUser(name=f"BatchUser{i}")
            for i in range(5)
        ]
        results = await kernel.insert_batch(users, replicate=True)
        
        assert len(results) == 5
        for i, result in enumerate(results):
            assert result.name == f"BatchUser{i}"
    
    @pytest.mark.asyncio
    async def test_insert_batch_without_replicate(self, kernel):
        """Test batch insert without replication."""
        users = [
            SampleUser(name=f"BatchNoRep{i}")
            for i in range(3)
        ]
        results = await kernel.insert_batch(users, replicate=False)
        
        assert len(results) == 3


class TestKernelGraphOperations:
    """Tests for graph operations."""
    
    @pytest.mark.asyncio
    async def test_link_creates_edge(self, kernel):
        """Test creating a link between resources."""
        user1 = SampleUser(name="GraphUser1")
        user2 = SampleUser(name="GraphUser2")
        
        saved1 = await kernel.save_versioned(user1)
        saved2 = await kernel.save_versioned(user2)
        
        # Create link - API is (src, dst, label)
        await kernel.link(saved1, saved2, "KNOWS")
        
        # Verify link exists via graph query
        # Note: This tests the link creation path
    
    @pytest.mark.asyncio
    async def test_link_with_properties(self, kernel):
        """Test creating a link with properties."""
        user1 = SampleUser(name="PropUser1")
        user2 = SampleUser(name="PropUser2")
        
        saved1 = await kernel.save_versioned(user1)
        saved2 = await kernel.save_versioned(user2)
        
        # Create link with properties - API is (src, dst, label, props)
        await kernel.link(saved1, saved2, "FOLLOWS", props={"since": "2024"})
    
    @pytest.mark.asyncio
    async def test_graph_watermark(self, kernel):
        """Test graph watermark tracking."""
        watermark = kernel.graph_driver.get_watermark()
        assert isinstance(watermark, int)
        assert watermark >= 0
    
    @pytest.mark.asyncio
    async def test_session_watermark(self, kernel):
        """Test session watermark tracking."""
        watermark = kernel.get_session_watermark()
        assert isinstance(watermark, int)
        assert watermark >= 0
    
    @pytest.mark.asyncio
    async def test_kuzu_actor_qsize(self, kernel):
        """Test KuzuActor queue size."""
        qsize = kernel.graph_driver.qsize()
        assert isinstance(qsize, int)
        assert qsize >= 0
    
    @pytest.mark.asyncio
    async def test_kuzu_actor_config(self, kernel):
        """Test KuzuActor has config."""
        assert kernel.graph_driver.config is not None


class TestKernelAnalyticsOperations:
    """Tests for analytics/DuckDB operations."""
    
    @pytest.mark.asyncio
    async def test_analytics_driver_exists(self, kernel):
        """Test analytics driver is accessible."""
        assert kernel.analytics is not None
        assert isinstance(kernel.analytics, DuckDBDriver)
    
    @pytest.mark.asyncio
    async def test_query_federated_method_exists(self, kernel):
        """Test query_federated method exists."""
        assert hasattr(kernel, "query_federated")
    
    @pytest.mark.asyncio
    async def test_from_postgres_method_exists(self, kernel):
        """Test from_postgres method exists."""
        assert hasattr(kernel, "from_postgres")
    
    @pytest.mark.asyncio
    async def test_from_parquet_method_exists(self, kernel):
        """Test from_parquet method exists."""
        assert hasattr(kernel, "from_parquet")
    
    @pytest.mark.asyncio
    async def test_from_csv_method_exists(self, kernel):
        """Test from_csv method exists."""
        assert hasattr(kernel, "from_csv")
    
    @pytest.mark.asyncio
    async def test_from_sqlite_method_exists(self, kernel):
        """Test from_sqlite method exists."""
        assert hasattr(kernel, "from_sqlite")
    
    @pytest.mark.asyncio
    async def test_analytics_query(self, kernel):
        """Test executing a simple query."""
        # Simple query that returns raw tuples
        result = await kernel.analytics.query("SELECT 1 as value")
        assert result is not None
        assert len(result) == 1
    
    @pytest.mark.asyncio
    async def test_analytics_query_multiple_rows(self, kernel):
        """Test query returning multiple rows."""
        result = await kernel.analytics.query(
            "SELECT * FROM (VALUES (1, 'a'), (2, 'b'), (3, 'c')) AS t(id, name)"
        )
        assert len(result) == 3
    
    @pytest.mark.asyncio
    async def test_analytics_zero_copy_enabled(self, kernel):
        """Test that zero_copy is enabled when SQLite path exists."""
        # When kernel is initialized with SQLite, zero_copy is True
        assert kernel.analytics.zero_copy is True


class TestDuckDBDriverDirect:
    """Direct tests for DuckDBDriver without kernel."""
    
    @pytest.mark.asyncio
    async def test_duckdb_driver_init(self):
        """Test DuckDBDriver initialization."""
        driver = DuckDBDriver()
        assert driver.conn is not None
        assert driver.zero_copy is False
    
    @pytest.mark.asyncio
    async def test_duckdb_driver_with_sqlite_path(self, temp_dir):
        """Test DuckDBDriver with SQLite path."""
        import os
        sqlite_path = os.path.join(temp_dir, "test.db")
        # Create empty file
        open(sqlite_path, 'w').close()
        
        driver = DuckDBDriver(sqlite_path=sqlite_path)
        assert driver.zero_copy is True
    
    @pytest.mark.asyncio
    async def test_duckdb_run_method(self):
        """Test _run method for background execution."""
        driver = DuckDBDriver()
        
        def simple_query():
            return driver.conn.execute("SELECT 1").fetchall()
        
        result = await driver._run(simple_query)
        assert result == [(1,)]
    
    @pytest.mark.asyncio
    async def test_duckdb_query_simple(self):
        """Test simple query execution."""
        driver = DuckDBDriver()
        result = await driver.query("SELECT 42 as answer")
        assert result == [(42,)]
    
    @pytest.mark.asyncio
    async def test_duckdb_extension_loading(self):
        """Test extension loading (may fail gracefully)."""
        driver = DuckDBDriver()
        # Try to load an extension - should not raise
        loaded = driver._load_extension("parquet", required=False)
        # Result depends on environment, just ensure no crash
        assert isinstance(loaded, bool)
    
    @pytest.mark.asyncio
    async def test_duckdb_extension_already_loaded(self):
        """Test that already loaded extensions return True."""
        driver = DuckDBDriver()
        # Manually mark as loaded
        driver._extensions_loaded.add("fake_ext")
        result = driver._load_extension("fake_ext", required=False)
        assert result is True
    
    @pytest.mark.asyncio
    async def test_duckdb_get_select_clause_all(self):
        """Test _get_select_clause with no columns."""
        driver = DuckDBDriver()
        result = driver._get_select_clause(None)
        assert result == "*"
    
    @pytest.mark.asyncio
    async def test_duckdb_get_select_clause_specific(self):
        """Test _get_select_clause with specific columns."""
        driver = DuckDBDriver()
        result = driver._get_select_clause(["id", "name", "email"])
        assert result == "id, name, email"
    
    @pytest.mark.asyncio
    async def test_duckdb_get_select_clause_invalid(self):
        """Test _get_select_clause with invalid column name."""
        driver = DuckDBDriver()
        with pytest.raises(ValueError, match="Invalid column name"):
            driver._get_select_clause(["id", "name; DROP TABLE"])
    
    @pytest.mark.asyncio
    async def test_duckdb_federated_unsupported_source(self):
        """Test federated query with unsupported source."""
        driver = DuckDBDriver()
        with pytest.raises(ValueError, match="Unsupported federation source"):
            await driver.query_federated({"type": "mongodb"})
    
    @pytest.mark.asyncio
    async def test_duckdb_supported_sources(self):
        """Test that supported sources are defined."""
        driver = DuckDBDriver()
        assert "csv" in driver.SUPPORTED_SOURCES
        assert "parquet" in driver.SUPPORTED_SOURCES
        assert "postgres" in driver.SUPPORTED_SOURCES
        assert "sqlite" in driver.SUPPORTED_SOURCES
        assert "s3" in driver.SUPPORTED_SOURCES
    
    @pytest.mark.asyncio
    async def test_duckdb_build_csv_query(self):
        """Test building CSV query."""
        driver = DuckDBDriver()
        query = driver._build_csv_query(
            {"path": "/tmp/test.csv"},
            sql_filter="id > 0",
            columns=["id", "name"]
        )
        assert "SELECT" in query
        assert "id, name" in query
        assert "read_csv" in query.lower() or "csv" in query.lower()
    
    @pytest.mark.asyncio
    async def test_duckdb_build_parquet_query(self):
        """Test building Parquet query."""
        driver = DuckDBDriver()
        query = driver._build_parquet_query(
            {"path": "/tmp/test.parquet"},
            sql_filter="1=1",
            columns=None
        )
        assert "SELECT" in query
        assert "*" in query
    
    @pytest.mark.asyncio
    async def test_duckdb_configure_s3_not_s3_path(self):
        """Test S3 config is skipped for non-S3 paths."""
        driver = DuckDBDriver()
        # Should not raise for non-S3 path
        driver._configure_s3_if_needed({"path": "/local/file.csv"})
    
    @pytest.mark.asyncio
    async def test_duckdb_close(self):
        """Test closing DuckDB connection."""
        driver = DuckDBDriver()
        driver.close()
        # Connection should be closed


class TestKernelErrorHandling:
    """Tests for error handling paths."""
    
    @pytest.mark.asyncio
    async def test_uow_rollback_on_exception(self, kernel):
        """Test UoW rolls back on exception."""
        try:
            async with kernel.unit_of_work() as uow:
                uow.add(SampleUser(name="RollbackTest"))
                raise ValueError("Simulated error")
        except ValueError:
            pass
        
        # UoW should have cleared
        assert uow.pending_objects == 0
    
    @pytest.mark.asyncio
    async def test_backpressure_check(self, kernel):
        """Test backpressure check method exists."""
        # Should not raise when lag is low
        kernel._check_backpressure()
    
    @pytest.mark.asyncio
    async def test_max_graph_lag_constant(self, kernel):
        """Test MAX_GRAPH_LAG constant exists."""
        assert hasattr(kernel, "MAX_GRAPH_LAG")
        assert isinstance(kernel.MAX_GRAPH_LAG, int)
        assert kernel.MAX_GRAPH_LAG > 0
    
    @pytest.mark.asyncio
    async def test_savepoint_suppresses_exception(self, kernel):
        """Test savepoint suppresses exception and allows recovery."""
        async with kernel.unit_of_work() as uow:
            uow.add(SampleUser(name="BeforeSavepoint"))
            
            # This should not raise outside
            async with uow.savepoint():
                uow.add(SampleUser(name="InSavepoint"))
                raise ValueError("Savepoint error")
            
            # Should continue here with only first user
            assert uow.pending_objects == 1
    
    @pytest.mark.asyncio
    async def test_savepoint_release(self, kernel):
        """Test savepoint explicit release."""
        async with kernel.unit_of_work() as uow:
            uow.add(SampleUser(name="BeforeRelease"))
            
            async with uow.savepoint() as sp:
                uow.add(SampleUser(name="InSavepoint"))
                sp.release()  # Explicit release
            
            # Both users should be present
            assert uow.pending_objects == 2
    
    @pytest.mark.asyncio
    async def test_savepoint_nested(self, kernel):
        """Test nested savepoints."""
        async with kernel.unit_of_work() as uow:
            uow.add(SampleUser(name="Level0"))
            
            async with uow.savepoint():
                uow.add(SampleUser(name="Level1"))
                
                async with uow.savepoint():
                    uow.add(SampleUser(name="Level2"))
                    raise ValueError("Nested error")
                
                # Level2 rolled back, Level1 still there
                assert uow.pending_objects == 2
            
            # All committed
            assert uow.pending_objects == 2


class TestDriverInitialization:
    """Tests for driver initialization."""
    
    @pytest.mark.asyncio
    async def test_sql_driver_session(self, kernel):
        """Test SQL driver provides sessions."""
        async with await kernel.sql_driver.get_session() as session:
            assert session is not None
    
    @pytest.mark.asyncio
    async def test_graph_driver_exists(self, kernel):
        """Test graph driver is accessible."""
        assert kernel.graph_driver is not None
        assert isinstance(kernel.graph_driver, KuzuActor)
    
    @pytest.mark.asyncio
    async def test_stream_driver_accessible(self, kernel):
        """Test stream driver can be created."""
        # Stream driver is created on demand, not stored on kernel
        stream = ParquetStreamDriver(base_path="/tmp/test_stream")
        assert stream is not None
    
    @pytest.mark.asyncio
    async def test_model_registry_exists(self, kernel):
        """Test model registry exists."""
        assert hasattr(kernel, "_model_registry")
        assert isinstance(kernel._model_registry, dict)
    
    @pytest.mark.asyncio
    async def test_analytics_driver_exists(self, kernel):
        """Test analytics driver is accessible."""
        assert kernel.analytics_driver is not None
        assert isinstance(kernel.analytics_driver, DuckDBDriver)


class TestKernelSignals:
    """Tests for kernel signals."""
    
    @pytest.mark.asyncio
    async def test_post_save_signal(self, kernel):
        """Test post_save signal is emitted."""
        received = []
        
        @kernel.post_save.connect
        async def on_save(resource):
            received.append(resource)
        
        user = SampleUser(name="SignalTest")
        await kernel.save(SampleUser, user)
        
        # Signal should have been emitted
        assert len(received) >= 1
    
    @pytest.mark.asyncio
    async def test_post_delete_signal(self, kernel):
        """Test post_delete signal exists."""
        assert kernel.post_delete is not None
    
    @pytest.mark.asyncio
    async def test_post_save_signal_exists(self, kernel):
        """Test post_save signal exists."""
        assert kernel.post_save is not None


class TestSignalClass:
    """Tests for Signal class directly."""
    
    @pytest.mark.asyncio
    async def test_signal_connect_handler(self):
        """Test connecting a handler to signal."""
        from malha.malha import Signal
        
        sig = Signal("test_signal")
        called = []
        
        def handler(payload):
            called.append(payload)
        
        sig.connect(handler)
        await sig.emit("test_payload", background=False)
        
        assert "test_payload" in called
    
    @pytest.mark.asyncio
    async def test_signal_async_handler(self):
        """Test async handler."""
        from malha.malha import Signal
        
        sig = Signal("async_test")
        called = []
        
        async def async_handler(payload):
            called.append(payload)
        
        sig.connect(async_handler)
        await sig.emit("async_payload", background=False)
        
        assert "async_payload" in called
    
    @pytest.mark.asyncio
    async def test_signal_duplicate_connect(self):
        """Test that duplicate handlers are not added."""
        from malha.malha import Signal
        
        sig = Signal("dup_test")
        
        def handler(payload):
            pass
        
        sig.connect(handler)
        sig.connect(handler)  # Duplicate
        
        assert len(sig._handlers) == 1
    
    @pytest.mark.asyncio
    async def test_signal_error_handling(self):
        """Test that signal errors are caught."""
        from malha.malha import Signal
        
        sig = Signal("error_test")
        
        def bad_handler(payload):
            raise ValueError("Handler error")
        
        sig.connect(bad_handler)
        # Should not raise
        await sig.emit("test", background=False)


class TestInterceptors:
    """Tests for interceptor functionality."""
    
    @pytest.mark.asyncio
    async def test_add_interceptor(self, kernel):
        """Test adding an interceptor."""
        class TestInterceptor(Interceptor):
            async def on_read(self, resource, agent=None):
                pass
            async def on_write(self, resource, agent=None):
                pass
        
        interceptor = TestInterceptor()
        kernel.add_interceptor(interceptor)
        
        assert interceptor in kernel._interceptors
    
    @pytest.mark.asyncio
    async def test_interceptor_on_read(self, kernel):
        """Test interceptor on_read is called."""
        read_calls = []
        
        class ReadInterceptor(Interceptor):
            async def on_read(self, resource, agent=None):
                read_calls.append(resource)
                return resource
            async def on_write(self, resource, agent=None):
                pass
        
        kernel.add_interceptor(ReadInterceptor())
        
        # Create and read
        user = await kernel.save_versioned(SampleUser(name="InterceptorReadTest"))
        await kernel.get(SampleUser, user.rid)
        
        # on_read should have been called
        assert len(read_calls) >= 1
    
    @pytest.mark.asyncio
    async def test_interceptor_on_write(self, kernel):
        """Test interceptor on_write is called."""
        write_calls = []
        
        class WriteInterceptor(Interceptor):
            async def on_read(self, resource, agent=None):
                return resource
            async def on_write(self, resource, agent=None):
                write_calls.append(resource)
        
        kernel.add_interceptor(WriteInterceptor())
        
        # Save triggers on_write
        await kernel.save(SampleUser, {"name": "InterceptorWriteTest"})
        
        assert len(write_calls) >= 1
    
    @pytest.mark.asyncio
    async def test_interceptor_called_on_read(self, kernel):
        """Test interceptor is called on read."""
        called = {"read": False}
        
        class TrackingInterceptor(Interceptor):
            async def on_read(self, resource, agent=None):
                called["read"] = True
                return resource
            async def on_write(self, resource, agent=None):
                pass
        
        kernel.add_interceptor(TrackingInterceptor())
        
        # Create and read
        user = SampleUser(name="InterceptorTest")
        saved = await kernel.save_versioned(user)
        await kernel.get(SampleUser, saved.rid)
        
        assert called["read"] is True


class TestProcessStatusEnum:
    """Tests for ProcessStatus enum values."""
    
    def test_all_status_values(self):
        """Test all ProcessStatus enum values exist."""
        assert ProcessStatus.PENDING.value == "PENDING"
        assert ProcessStatus.RUNNING.value == "RUNNING"
        assert ProcessStatus.SUSPENDED.value == "SUSPENDED"
        assert ProcessStatus.RECOVERING.value == "RECOVERING"
        assert ProcessStatus.COMPLETED.value == "COMPLETED"
        assert ProcessStatus.FAILED.value == "FAILED"
        assert ProcessStatus.COMPENSATING.value == "COMPENSATING"
        assert ProcessStatus.COMPENSATED.value == "COMPENSATED"
        assert ProcessStatus.DEAD_LETTER.value == "DEAD_LETTER"


class TestUnitOfWorkAdvanced:
    """Advanced UnitOfWork tests."""
    
    @pytest.mark.asyncio
    async def test_uow_multiple_commits_fail(self, kernel):
        """Test that committing twice raises or is idempotent."""
        async with kernel.unit_of_work() as uow:
            uow.add(SampleUser(name="DoubleCommit"))
            await uow.commit()
            # Second commit should be safe (no-op or error)
            await uow.commit()
    
    @pytest.mark.asyncio
    async def test_uow_clear_resets_state(self, kernel):
        """Test clear resets UoW state."""
        uow = kernel.unit_of_work()
        uow.add(SampleUser(name="ClearTest1"))
        uow.add(SampleUser(name="ClearTest2"))
        assert uow.pending_objects == 2
        
        uow.clear()
        assert uow.pending_objects == 0
        assert uow.pending_links == 0
        assert uow.is_committed is False
    
    @pytest.mark.asyncio
    async def test_uow_link_queues_edge(self, kernel):
        """Test link queues edge for commit."""
        uow = kernel.unit_of_work()
        user1 = SampleUser(name="LinkUser1")
        user2 = SampleUser(name="LinkUser2")
        
        uow.add(user1)
        uow.add(user2)
        uow.link(user1, "KNOWS", user2)
        
        assert uow.pending_links == 1
    
    @pytest.mark.asyncio
    async def test_uow_with_session(self, kernel):
        """Test UoW with explicit session."""
        uow = UnitOfWork(kernel)
        
        async with uow:
            user1 = SampleUser(name="LinkUser1")
            user2 = SampleUser(name="LinkUser2")
            
            uow.add(user1)
            uow.add(user2)
            uow.link(user1, "KNOWS", user2)
            
            assert uow.pending_links == 1
    
    @pytest.mark.asyncio
    async def test_uow_clear(self, kernel):
        """Test UoW clear method."""
        async with kernel.unit_of_work() as uow:
            uow.add(SampleUser(name="ClearTest1"))
            uow.add(SampleUser(name="ClearTest2"))
            
            assert uow.pending_objects == 2
            
            uow.clear()
            
            assert uow.pending_objects == 0
    
    @pytest.mark.asyncio
    async def test_uow_is_committed_property(self, kernel):
        """Test UoW is_committed property."""
        async with kernel.unit_of_work() as uow:
            assert uow.is_committed is False
            
            uow.add(SampleUser(name="CommitTest"))
            await uow.commit()
            
            assert uow.is_committed is True
    
    @pytest.mark.asyncio
    async def test_uow_session_property(self, kernel):
        """Test UoW session property."""
        async with kernel.unit_of_work() as uow:
            # Session should be available
            assert uow.session is not None


# TestConnectFunction removed - causes hanging due to multiple kernel instances


class TestSysProcessAdvanced:
    """Advanced SysProcess tests."""
    
    @pytest.mark.asyncio
    async def test_process_with_all_fields(self, kernel):
        """Test creating process with all fields."""
        process, created = await kernel.get_or_create_process(
            idempotency_key="full-process-001",
            process_type="workflow",
            process_name="FullWorkflow",
            state_payload='{"step": 0, "data": "test"}',
        )
        
        assert created is True
        assert process.process_type == "workflow"
        assert process.process_name == "FullWorkflow"
        assert process.state_payload == '{"step": 0, "data": "test"}'
    
    @pytest.mark.asyncio
    async def test_find_process_by_idempotency(self, kernel):
        """Test finding process by idempotency key."""
        # Create a process
        process, _ = await kernel.get_or_create_process(
            idempotency_key="find-test-001",
            process_type="test",
            process_name="FindTest",
        )
        
        # Find it
        found = await kernel.find_process_by_idempotency("find-test-001")
        assert found is not None
        assert found.id == process.id
    
    @pytest.mark.asyncio
    async def test_find_process_by_idempotency_not_found(self, kernel):
        """Test finding nonexistent process returns None."""
        found = await kernel.find_process_by_idempotency("nonexistent-key-xyz")
        assert found is None
    
    @pytest.mark.asyncio
    async def test_acquire_process_lock(self, kernel):
        """Test acquiring process lock."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="lock-test-001",
            process_type="test",
            process_name="LockTest",
        )
        
        locked = await kernel.acquire_process_lock(process.id)
        assert locked is not None
        assert locked.id == process.id
    
    @pytest.mark.asyncio
    async def test_acquire_process_lock_nonexistent(self, kernel):
        """Test acquiring lock on nonexistent process."""
        locked = await kernel.acquire_process_lock(999999, nowait=True)
        assert locked is None
    
    @pytest.mark.asyncio
    async def test_release_process_lock(self, kernel):
        """Test releasing process lock."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="release-lock-001",
            process_type="test",
            process_name="ReleaseLockTest",
        )
        
        # Acquire then release
        await kernel.acquire_process_lock(process.id)
        released = await kernel.release_process_lock(process.id)
        assert released is True
    
    @pytest.mark.asyncio
    async def test_release_process_lock_nonexistent(self, kernel):
        """Test releasing nonexistent lock."""
        released = await kernel.release_process_lock(999999)
        assert released is False
    
    @pytest.mark.asyncio
    async def test_process_heartbeat_update(self, kernel):
        """Test updating process heartbeat."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="heartbeat-test-001",
            process_type="agent",
            process_name="HeartbeatTest",
        )
        
        # Update with heartbeat
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.RUNNING,
        )
        
        assert updated.status == ProcessStatus.RUNNING.value
    
    @pytest.mark.asyncio
    async def test_process_error_state(self, kernel):
        """Test setting process to error state."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="error-test-001",
            process_type="agent",
            process_name="ErrorTest",
        )
        
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.FAILED,
            error="Something went wrong",
        )
        
        assert updated.status == ProcessStatus.FAILED.value
        assert updated.error == "Something went wrong"
    
    @pytest.mark.asyncio
    async def test_process_completed_state(self, kernel):
        """Test setting process to completed state."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="completed-test-001",
            process_type="job",
            process_name="CompletedTest",
        )
        
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.COMPLETED,
            result_payload='{"result": "success"}',
        )
        
        assert updated.status == ProcessStatus.COMPLETED.value
        assert updated.result_payload == '{"result": "success"}'
    
    @pytest.mark.asyncio
    async def test_process_suspended_state(self, kernel):
        """Test setting process to suspended state."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="suspended-test-001",
            process_type="workflow",
            process_name="SuspendedTest",
        )
        
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.SUSPENDED,
        )
        
        assert updated.status == ProcessStatus.SUSPENDED.value
    
    @pytest.mark.asyncio
    async def test_process_recovering_state(self, kernel):
        """Test setting process to recovering state."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="recovering-test-001",
            process_type="saga",
            process_name="RecoveringTest",
        )
        
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.RECOVERING,
        )
        
        assert updated.status == ProcessStatus.RECOVERING.value
