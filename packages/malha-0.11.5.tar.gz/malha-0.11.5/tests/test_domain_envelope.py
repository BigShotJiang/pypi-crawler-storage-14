"""
Test Suite: Domain Envelope Pattern
====================================

Testes completos para validar a refatoração do padrão Domain Envelope.
Cobre todos os componentes críticos: Repository, Kernel, Outbox, Synapse.
"""

import json
import os
import shutil
import tempfile

import pytest
from pydantic import Field, field_validator
from registro import DomainResource, register
from registro import Resource as RegistroResource

from malha import (
    AsyncSQLAlchemyDriver,
    DuckDBDriver,
    Interceptor,
    KuzuActor,
    UnifiedDataManager,
)

# ============================================================================
# Domain Resources para Testes
# ============================================================================


class User(DomainResource):
    """Recurso de domínio para usuários."""

    name: str = Field(..., min_length=1, max_length=100)
    email: str = Field(..., pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$")
    age: int | None = Field(None, ge=0, le=150)
    tags: list[str] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Name cannot be empty")
        return v.strip()

    def is_adult(self) -> bool:
        return self.age is not None and self.age >= 18


class Product(DomainResource):
    """Recurso de domínio para produtos."""

    name: str
    price: float = Field(..., gt=0)
    stock: int = Field(default=0, ge=0)
    category: str

    @property
    def is_available(self) -> bool:
        return self.stock > 0


# Registrar no global registry
register("User", User)
register("Product", Product)


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
async def temp_dir():
    """Cria diretório temporário para testes."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def sql_driver(temp_dir):
    """Driver SQL para testes."""
    db_path = os.path.join(temp_dir, "test.db")
    driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
    await driver.create_tables()
    return driver


@pytest.fixture
async def graph_driver(temp_dir):
    """Driver de grafo para testes."""
    graph_path = os.path.join(temp_dir, "test_graph")
    driver = KuzuActor(graph_path)
    yield driver
    await driver.close()


@pytest.fixture
async def analytics_driver(temp_dir):
    """Driver analytics para testes."""
    db_path = os.path.join(temp_dir, "test.db")
    driver = DuckDBDriver(db_path)
    yield driver
    driver.close()


@pytest.fixture
async def kernel(sql_driver, graph_driver, analytics_driver):
    """Kernel configurado para testes."""
    manager = UnifiedDataManager(
        sql_driver=sql_driver,
        graph_driver=graph_driver,
        analytics_driver=analytics_driver,
        enable_monitoring=False,  # Desabilita monitoring nos testes
        node_id="test-node",
    )
    await manager.boot()
    return manager


# ============================================================================
# Testes: DomainResource
# ============================================================================


class TestDomainResource:
    """Testa funcionalidades básicas de DomainResource."""

    def test_create_user(self):
        """Testa criação de usuário com validação."""
        user = User(
            name="Alice Silva",
            email="alice@example.com",
            age=25,
            tags=["developer", "python"],
        )

        assert user.name == "Alice Silva"
        assert user.email == "alice@example.com"
        assert user.age == 25
        assert user.is_adult() is True
        assert user.rid.startswith("ri.")
        assert user.version == 1

    def test_user_validation(self):
        """Testa validação Pydantic."""
        # Email inválido
        with pytest.raises(ValueError):
            User(name="Bob", email="invalid-email", age=30)

        # Nome vazio
        with pytest.raises(ValueError):
            User(name="", email="bob@example.com", age=30)

        # Idade negativa
        with pytest.raises(ValueError):
            User(name="Charlie", email="charlie@example.com", age=-5)

    def test_product_properties(self):
        """Testa propriedades computadas."""
        product = Product(
            name="Laptop",
            price=5000.00,
            stock=10,
            category="Electronics",
        )

        assert product.is_available is True

        product.stock = 0
        assert product.is_available is False

    def test_dynamic_fields(self):
        """Testa campos dinâmicos (extra='allow')."""
        user = User(
            name="Diana",
            email="diana@example.com",
            age=28,
            custom_field="custom value",
            nested_data={"key": "value"},
        )

        assert user.custom_field == "custom value"
        assert user.nested_data == {"key": "value"}


# ============================================================================
# Testes: Envelope Conversion
# ============================================================================


class TestEnvelopeConversion:
    """Testa conversão Domain ↔ Envelope."""

    def test_to_envelope(self):
        """Testa conversão Domain → Envelope."""
        user = User(
            name="Alice",
            email="alice@example.com",
            age=25,
            tags=["dev"],
            metadata={"dept": "Engineering"},
        )

        envelope = user.to_envelope()

        # Verifica que é um RegistroResource
        assert isinstance(envelope, RegistroResource)

        # Verifica colunas SQL
        assert envelope.rid == user.rid
        assert envelope.version == user.version

        # Verifica que campos extras foram para meta_tags
        assert envelope.meta_tags is not None
        assert "tags" in envelope.meta_tags
        assert "metadata" in envelope.meta_tags

    def test_from_envelope(self):
        """Testa conversão Envelope → Domain."""
        # Cria envelope físico
        envelope = RegistroResource(
            rid="ri.test.prod.user.123",
            version=1,
            meta_tags={
                "name": "Bob",
                "email": "bob@example.com",
                "age": 30,
                "tags": ["manager"],
            },
        )

        # Hidrata para domínio
        user = User.from_envelope(envelope)

        assert isinstance(user, User)
        assert user.name == "Bob"
        assert user.email == "bob@example.com"
        assert user.age == 30
        assert user.tags == ["manager"]
        assert user.rid == "ri.test.prod.user.123"

    def test_roundtrip_conversion(self):
        """Testa conversão bidirecional."""
        original = User(
            name="Charlie",
            email="charlie@example.com",
            age=35,
            tags=["senior", "architect"],
            custom_field="preserved",
        )

        # Domain → Envelope → Domain
        envelope = original.to_envelope()
        restored = User.from_envelope(envelope)

        assert restored.name == original.name
        assert restored.email == original.email
        assert restored.age == original.age
        assert restored.tags == original.tags
        assert restored.custom_field == original.custom_field


# ============================================================================
# Testes: BaseRepository
# ============================================================================


class TestBaseRepository:
    """Testa operações CRUD do repositório."""

    @pytest.mark.asyncio
    async def test_create(self, kernel):
        """Testa criação via repositório."""
        repo = kernel.get_repository(User)

        async with await kernel.sql_driver.get_session() as session:
            user = await repo.create(session, {
                "name": "Alice",
                "email": "alice@example.com",
                "age": 25,
            })
            await session.commit()

        assert isinstance(user, User)
        assert user.name == "Alice"
        assert user.email == "alice@example.com"
        assert user.id is not None
        assert user.rid is not None

    @pytest.mark.asyncio
    async def test_get(self, kernel):
        """Testa busca via repositório."""
        repo = kernel.get_repository(User)

        async with await kernel.sql_driver.get_session() as session:
            # Criar
            created = await repo.create(session, {
                "name": "Bob",
                "email": "bob@example.com",
                "age": 30,
            })
            await session.commit()

            # Buscar
            found = await repo.get(session, id=created.id)

        assert found is not None
        assert isinstance(found, User)
        assert found.name == "Bob"
        assert found.id == created.id

    @pytest.mark.asyncio
    async def test_update(self, kernel):
        """Testa atualização via repositório."""
        repo = kernel.get_repository(User)

        async with await kernel.sql_driver.get_session() as session:
            # Criar
            user = await repo.create(session, {
                "name": "Charlie",
                "email": "charlie@example.com",
                "age": 28,
            })
            await session.commit()

            # Atualizar
            updated = await repo.update(session, id=user.id, data={"age": 29})
            await session.commit()

        assert updated.age == 29
        assert updated.version == 2  # Versão incrementada

    @pytest.mark.asyncio
    async def test_delete(self, kernel):
        """Testa deleção via repositório."""
        repo = kernel.get_repository(User)

        async with await kernel.sql_driver.get_session() as session:
            # Criar
            user = await repo.create(session, {
                "name": "Diana",
                "email": "diana@example.com",
            })
            await session.commit()

            # Deletar
            deleted = await repo.delete(session, id=user.id)
            await session.commit()

            # Verificar que foi deletado
            found = await repo.get(session, id=user.id)

        assert deleted is True
        assert found is None

    @pytest.mark.asyncio
    async def test_list(self, kernel):
        """Testa listagem via repositório."""
        repo = kernel.get_repository(User)

        async with await kernel.sql_driver.get_session() as session:
            # Criar múltiplos usuários
            for i in range(5):
                await repo.create(session, {
                    "name": f"User {i}",
                    "email": f"user{i}@example.com",
                    "age": 20 + i,
                })
            await session.commit()

            # Listar
            users = await repo.list(session, skip=0, limit=10)

        assert len(users) == 5
        assert all(isinstance(u, User) for u in users)

    @pytest.mark.asyncio
    async def test_optimistic_locking(self, kernel):
        """Testa optimistic locking."""
        from malha import OptimisticLockError

        repo = kernel.get_repository(User)

        async with await kernel.sql_driver.get_session() as session:
            # Criar
            user = await repo.create(session, {
                "name": "Eve",
                "email": "eve@example.com",
            })
            await session.commit()

            # Tentar atualizar com versão errada
            with pytest.raises(OptimisticLockError):
                await repo.update(
                    session,
                    id=user.id,
                    data={"age": 25},
                    expected_version=999,  # Versão incorreta
                )


# ============================================================================
# Testes: UnifiedDataManager.save_versioned
# ============================================================================


class TestSaveVersioned:
    """Testa save_versioned com padrão Domain Envelope."""

    @pytest.mark.asyncio
    async def test_save_new_version(self, kernel):
        """Testa criação de nova versão bitemporal."""
        user = User(
            name="Alice",
            email="alice@example.com",
            age=25,
        )

        saved = await kernel.save_versioned(obj=user)

        assert isinstance(saved, User)
        assert saved.name == "Alice"
        assert saved.valid_from is not None
        assert saved.valid_to is None
        assert saved.tx_from is not None
        assert saved.tx_to is None

    @pytest.mark.asyncio
    async def test_save_updates_timestamps(self, kernel):
        """Testa que save_versioned atualiza timestamps corretamente."""
        user = User(
            name="Bob",
            email="bob@example.com",
            age=30,
        )

        # Salvar
        saved = await kernel.save_versioned(obj=user)

        # Verificar timestamps
        assert saved.valid_from is not None
        assert saved.valid_to is None
        assert saved.tx_from is not None
        assert saved.tx_to is None
        assert saved.created_at is not None
        # Note: updated_at is None for new records, only set on updates

    @pytest.mark.asyncio
    async def test_save_with_origin_tracking(self, kernel):
        """Testa origin tracking para prevenção de loops."""
        user = User(name="Diana", email="diana@example.com")

        # Salvar com origin local
        saved_local = await kernel.save_versioned(obj=user, origin="local")

        # Salvar outro usuário com origin remoto (simula replicação)
        user2 = User(name="Eve", email="eve@example.com", age=25)
        saved_remote = await kernel.save_versioned(obj=user2, origin="remote-node-1")

        # Ambos devem ter sido salvos
        assert saved_local.rid is not None
        assert saved_remote.rid is not None
        assert saved_local.rid != saved_remote.rid  # RIDs diferentes


# ============================================================================
# Testes: Interceptors
# ============================================================================


class TestInterceptors:
    """Testa interceptors com DomainResource."""

    @pytest.mark.asyncio
    async def test_interceptor_receives_domain_object(self, kernel):
        """Testa que interceptor recebe DomainResource."""
        intercepted_objects = []

        class TestInterceptor(Interceptor):
            async def on_write(self, obj: DomainResource, agent=None):
                intercepted_objects.append(obj)

            async def on_read(self, obj: DomainResource, agent=None):
                return obj

        kernel.add_interceptor(TestInterceptor())

        user = User(name="Alice", email="alice@example.com")
        await kernel.save_versioned(obj=user)

        assert len(intercepted_objects) == 1
        assert isinstance(intercepted_objects[0], User)
        assert intercepted_objects[0].name == "Alice"

    @pytest.mark.asyncio
    async def test_interceptor_can_validate_domain(self, kernel):
        """Testa validação de domínio em interceptor."""
        from malha import ValidationError

        class ValidationInterceptor(Interceptor):
            async def on_write(self, obj: DomainResource, agent=None):
                if isinstance(obj, User):
                    if obj.age and obj.age < 18:
                        raise ValidationError("User must be 18+")

            async def on_read(self, obj: DomainResource, agent=None):
                return obj

        kernel.add_interceptor(ValidationInterceptor())

        # Usuário menor de idade deve falhar
        young_user = User(name="Bob", email="bob@example.com", age=16)

        with pytest.raises(ValidationError):
            await kernel.save_versioned(obj=young_user)


# ============================================================================
# Testes: Outbox Processing
# ============================================================================


class TestOutboxProcessing:
    """Testa processamento de outbox com global_registry."""

    @pytest.mark.asyncio
    async def test_outbox_item_created(self, kernel):
        """Testa que item de outbox é criado."""
        from sqlalchemy import select

        from malha import SysOutbox

        user = User(name="Alice", email="alice@example.com")
        await kernel.save_versioned(obj=user, origin="local")

        # Verificar outbox
        async with await kernel.sql_driver.get_session() as session:
            stmt = select(SysOutbox).where(SysOutbox.rid == user.rid)
            result = await session.execute(stmt)
            outbox_items = result.scalars().all()

        assert len(outbox_items) >= 1
        assert outbox_items[0].operation == "UPSERT"
        assert outbox_items[0].status == "PENDING"

    @pytest.mark.asyncio
    async def test_outbox_payload_is_domain_object(self, kernel):
        """Testa que payload do outbox é o objeto de domínio."""
        from sqlalchemy import select

        from malha import SysOutbox

        user = User(
            name="Bob",
            email="bob@example.com",
            age=30,
            tags=["developer"],
        )
        await kernel.save_versioned(obj=user, origin="local")

        # Verificar payload
        async with await kernel.sql_driver.get_session() as session:
            stmt = select(SysOutbox).where(SysOutbox.rid == user.rid)
            result = await session.execute(stmt)
            outbox_item = result.scalars().first()

        payload = json.loads(outbox_item.payload)

        # Payload deve conter campos de domínio
        assert payload["name"] == "Bob"
        assert payload["email"] == "bob@example.com"
        assert payload["age"] == 30
        assert payload["tags"] == ["developer"]


# ============================================================================
# Testes: delete_versioned
# ============================================================================


class TestDeleteVersioned:
    """Testa delete_versioned com DomainResource."""

    @pytest.mark.asyncio
    async def test_delete_closes_version(self, kernel):
        """Testa que delete fecha a versão ativa."""
        from sqlalchemy import select

        user = User(name="Alice", email="alice@example.com")
        saved = await kernel.save_versioned(obj=user)
        rid = saved.rid

        # Deletar
        await kernel.delete_versioned(obj=saved)

        # Verificar que versão foi fechada
        async with await kernel.sql_driver.get_session() as session:
            stmt = select(RegistroResource).where(
                RegistroResource.rid == rid,
                RegistroResource.valid_to.is_(None),
            )
            result = await session.execute(stmt)
            active_versions = result.scalars().all()

        assert len(active_versions) == 0  # Nenhuma versão ativa


# ============================================================================
# Testes de Integração
# ============================================================================


class TestIntegration:
    """Testes de integração end-to-end."""

    @pytest.mark.asyncio
    async def test_full_lifecycle(self, kernel):
        """Testa ciclo completo: create → read → delete."""
        # Criar usuário
        user = User(
            name="Alice Silva",
            email="alice@example.com",
            age=25,
            tags=["developer", "python"],
        )

        # Salvar
        saved = await kernel.save_versioned(obj=user)
        assert saved.rid is not None
        assert saved.age == 25

        # Deletar
        await kernel.delete_versioned(obj=saved)

        # Verificar que não há versão ativa
        from sqlalchemy import select
        async with await kernel.sql_driver.get_session() as session:
            stmt = select(RegistroResource).where(
                RegistroResource.rid == saved.rid,
                RegistroResource.valid_to.is_(None),
            )
            result = await session.execute(stmt)
            active = result.scalars().first()

        assert active is None

    @pytest.mark.asyncio
    async def test_multiple_resource_types(self, kernel):
        """Testa múltiplos tipos de recursos."""
        # Criar usuário
        user = User(name="Bob", email="bob@example.com", age=30)
        saved_user = await kernel.save_versioned(obj=user)

        # Criar produto
        product = Product(
            name="Laptop",
            price=5000.00,
            stock=10,
            category="Electronics",
        )
        saved_product = await kernel.save_versioned(obj=product)

        # Ambos devem ter RIDs únicos
        assert saved_user.rid != saved_product.rid
        assert saved_user.rid.startswith("ri.")
        assert saved_product.rid.startswith("ri.")


# ============================================================================
# Testes de Performance
# ============================================================================


class TestPerformance:
    """Testes de performance básicos."""

    @pytest.mark.asyncio
    async def test_bulk_create(self, kernel):
        """Testa criação em massa."""
        import time

        start = time.time()

        # Criar 100 usuários
        for i in range(100):
            user = User(
                name=f"User {i}",
                email=f"user{i}@example.com",
                age=20 + (i % 50),
            )
            await kernel.save_versioned(obj=user)

        duration = time.time() - start

        # Deve completar em tempo razoável (< 10s para 100 registros)
        assert duration < 10.0
        print(f"\n✓ Created 100 users in {duration:.2f}s ({100/duration:.1f} users/s)")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
