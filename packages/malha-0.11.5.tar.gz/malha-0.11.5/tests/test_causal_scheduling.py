"""Tests for Implicit Causal Scheduling.

Tests the priority queue, watermark tracking, consistency barriers,
and backpressure mechanisms in KuzuActor and UnifiedDataManager.
"""

import asyncio
import tempfile
from pathlib import Path

import pytest

from malha import (
    KuzuActor,
    KuzuTask,
    SystemOverloadedError,
    connect,
)


class TestKuzuTask:
    """Tests for KuzuTask dataclass."""

    def test_priority_ordering(self):
        """Tasks should be ordered by priority (lower = higher priority)."""
        loop = asyncio.new_event_loop()
        future1 = loop.create_future()
        future2 = loop.create_future()
        loop.close()

        write_task = KuzuTask(priority=0, payload=("execute", [], {}), future=future1)
        read_task = KuzuTask(priority=10, payload=("query", [], {}), future=future2)

        # Writes should come before reads
        assert write_task < read_task

    def test_tx_id_tracking(self):
        """Tasks should track transaction IDs for watermark updates."""
        loop = asyncio.new_event_loop()
        future = loop.create_future()
        loop.close()

        task = KuzuTask(
            priority=0,
            payload=("execute", [], {}),
            future=future,
            tx_id=42,
        )

        assert task.tx_id == 42


class TestKuzuActorWatermark:
    """Tests for KuzuActor watermark tracking."""

    @pytest.fixture
    async def actor(self, tmp_path):
        """Create a KuzuActor for testing."""
        kuzu_path = tmp_path / "kuzu"
        actor = KuzuActor(str(kuzu_path))
        yield actor
        await actor.close()

    async def test_initial_watermark_is_zero(self, actor):
        """Watermark should start at 0."""
        assert actor.get_watermark() == 0

    async def test_watermark_updates_on_tracked_write(self, actor):
        """Watermark should update when a tracked write completes."""
        # Create a simple node table first
        await actor.execute("CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY)")

        # Execute a tracked write
        await actor.execute(
            "CREATE (n:TestNode {rid: $rid})",
            {"rid": "test:1"},
            tx_id=100,
        )

        # Watermark should be updated
        assert actor.get_watermark() == 100

    async def test_watermark_takes_max(self, actor):
        """Watermark should always be the maximum tx_id seen."""
        await actor.execute("CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY)")

        # Execute writes out of order
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:1"}, tx_id=50)
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:2"}, tx_id=100)
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:3"}, tx_id=75)

        # Watermark should be the max
        assert actor.get_watermark() == 100

    async def test_untracked_write_does_not_update_watermark(self, actor):
        """Writes without tx_id should not update watermark."""
        await actor.execute("CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY)")

        # Execute untracked write
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:1"})

        # Watermark should still be 0
        assert actor.get_watermark() == 0


class TestConsistencyBarrier:
    """Tests for consistency barrier (wait_for_consistency)."""

    @pytest.fixture
    async def actor(self, tmp_path):
        """Create a KuzuActor for testing."""
        kuzu_path = tmp_path / "kuzu"
        actor = KuzuActor(str(kuzu_path))
        await actor.execute("CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY)")
        yield actor
        await actor.close()

    async def test_query_without_watermark_executes_immediately(self, actor):
        """Queries without required_watermark should execute immediately."""
        result = await actor.query("MATCH (n:TestNode) RETURN n.rid")
        assert result == []

    async def test_query_with_satisfied_watermark_executes_immediately(self, actor):
        """Queries with satisfied watermark should execute immediately."""
        # First, create a write with tx_id
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:1"}, tx_id=10)

        # Query with watermark <= current should execute immediately
        result = await actor.query(
            "MATCH (n:TestNode) RETURN n.rid",
            required_watermark=10,
        )
        assert len(result) == 1

    async def test_query_waits_for_watermark(self, actor):
        """Queries should wait for required watermark to be satisfied."""
        # Start a query that requires watermark 50
        query_task = asyncio.create_task(
            actor.query("MATCH (n:TestNode) RETURN n.rid", required_watermark=50)
        )

        # Give the query time to start waiting
        await asyncio.sleep(0.1)
        assert not query_task.done()

        # Now execute a write with tx_id=50
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:1"}, tx_id=50)

        # Query should now complete
        result = await asyncio.wait_for(query_task, timeout=2.0)
        assert len(result) == 1

    async def test_query_timeout_on_missing_watermark(self, actor):
        """Queries should timeout if watermark is never satisfied."""
        # Set a short timeout for testing
        original_timeout = actor.CONSISTENCY_TIMEOUT
        actor.CONSISTENCY_TIMEOUT = 0.5

        try:
            # Query with watermark that will never be satisfied
            result = await actor.query(
                "MATCH (n:TestNode) RETURN n.rid",
                required_watermark=9999,
            )
            # Should complete with stale read after timeout
            assert result == []
        finally:
            actor.CONSISTENCY_TIMEOUT = original_timeout


class TestBackpressure:
    """Tests for backpressure mechanism."""

    @pytest.fixture
    async def kernel(self, tmp_path):
        """Create a kernel for testing."""
        db_path = tmp_path / "test.db"
        kuzu_path = tmp_path / "kuzu"

        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=str(kuzu_path),
            reset=True,
            enable_monitoring=False,
        )
        yield kernel
        await kernel.close()

    async def test_session_watermark_starts_at_zero(self, kernel):
        """Session watermark should start at 0."""
        assert kernel.get_session_watermark() == 0

    async def test_backpressure_check_passes_when_healthy(self, kernel):
        """Backpressure check should pass when lag is acceptable."""
        # Should not raise
        kernel._check_backpressure()

    async def test_backpressure_check_fails_when_overloaded(self, kernel):
        """Backpressure check should fail when lag exceeds threshold."""
        # Artificially set high session watermark
        kernel._session_watermark = kernel.MAX_GRAPH_LAG + 1000

        with pytest.raises(SystemOverloadedError) as exc_info:
            kernel._check_backpressure()

        assert "overloaded" in str(exc_info.value).lower()


class TestPriorityQueue:
    """Tests for priority queue behavior."""

    @pytest.fixture
    async def actor(self, tmp_path):
        """Create a KuzuActor for testing."""
        kuzu_path = tmp_path / "kuzu"
        actor = KuzuActor(str(kuzu_path))
        await actor.execute("CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY)")
        yield actor
        await actor.close()

    async def test_writes_processed_before_reads(self, actor):
        """Writes (priority 0) should be processed before reads (priority 10)."""
        # This is hard to test directly, but we can verify the queue accepts both
        # and processes them correctly
        
        # Queue a write
        await actor.execute("CREATE (n:TestNode {rid: $rid})", {"rid": "test:1"}, tx_id=1)
        
        # Queue a read
        result = await actor.query("MATCH (n:TestNode) RETURN n.rid")
        
        # The read should see the write
        assert len(result) == 1

    async def test_qsize_reflects_pending_operations(self, actor):
        """qsize should reflect pending operations."""
        # Initially empty
        assert actor.qsize() == 0


class TestIntegration:
    """Integration tests for the full causal scheduling flow."""

    @pytest.fixture
    async def kernel(self, tmp_path):
        """Create a kernel for testing."""
        db_path = tmp_path / "test.db"
        kuzu_path = tmp_path / "kuzu"

        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=str(kuzu_path),
            reset=True,
            enable_monitoring=False,
        )
        yield kernel
        await kernel.close()

    async def test_execute_with_tx_id_updates_watermark(self, kernel):
        """execute with tx_id should update watermark."""
        # Register schema
        await kernel.graph.execute(
            "CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY, name STRING)"
        )

        # Execute with tx_id
        await kernel.graph.execute(
            "CREATE (n:TestNode {rid: $rid, name: $name})",
            {"rid": "test:1", "name": "Alice"},
            tx_id=42,
        )

        # Watermark should be updated
        assert kernel.graph.get_watermark() == 42

    async def test_delete_with_tx_id_updates_watermark(self, kernel):
        """delete with tx_id should update watermark."""
        # Register schema
        await kernel.graph.execute(
            "CREATE NODE TABLE IF NOT EXISTS TestNode (rid STRING PRIMARY KEY, name STRING)"
        )

        # Create a node first
        await kernel.graph.execute(
            "CREATE (n:TestNode {rid: $rid, name: $name})",
            {"rid": "test:1", "name": "Alice"},
            tx_id=10,
        )

        # Delete with tx_id
        await kernel.graph.execute(
            "MATCH (n:TestNode {rid: $rid}) DELETE n",
            {"rid": "test:1"},
            tx_id=20,
        )

        # Watermark should be updated to the delete's tx_id
        assert kernel.graph.get_watermark() == 20
