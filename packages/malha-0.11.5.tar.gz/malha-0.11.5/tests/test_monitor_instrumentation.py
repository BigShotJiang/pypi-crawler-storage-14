"""
Test Suite: KernelMonitor and Instrumentation
==============================================

Tests for observability components: metrics collection, monitoring, and instrumentation.
"""

import asyncio
import os
import shutil
import tempfile
from datetime import UTC, datetime

import pytest

from malha import (
    DuckDBDriver,
    connect,
)
from malha.instrumentation import InMemoryMetrics, KernelInstrumentation, metrics
from malha.monitor import KernelMonitor, MetricTimer

# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def temp_dir():
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)

@pytest.fixture
async def analytics_driver(temp_dir):
    driver = DuckDBDriver()
    yield driver
    driver.close()

@pytest.fixture
async def monitor(analytics_driver):
    monitor = KernelMonitor(analytics_driver, node_id="test-node", batch_size=10)
    yield monitor
    await monitor.stop()


# ============================================================================
# Tests: InMemoryMetrics
# ============================================================================

class TestInMemoryMetrics:
    def test_increment_counter(self):
        m = InMemoryMetrics()
        m.increment("test.count")
        m.increment("test.count")
        m.increment("test.count", 5)
        assert m._counters["test.count"] == 7

    def test_set_gauge(self):
        m = InMemoryMetrics()
        m.set_gauge("test.gauge", 42.5)
        assert m._gauges["test.gauge"] == 42.5
        m.set_gauge("test.gauge", 100.0)
        assert m._gauges["test.gauge"] == 100.0

    def test_record_histogram(self):
        m = InMemoryMetrics()
        for i in range(10):
            m.record_histogram("test.latency", float(i))
        assert len(m._histograms["test.latency"]) == 10

    def test_timer_context_manager(self):
        m = InMemoryMetrics()
        with m.timer("test.operation"):
            pass  # Simulate work
        assert len(m._histograms["test.operation"]) == 1
        assert m._histograms["test.operation"][0] >= 0

    @pytest.mark.asyncio
    async def test_get_snapshot(self):
        m = InMemoryMetrics()
        m.increment("counter", 5)
        m.set_gauge("gauge", 42.0)
        m.record_histogram("hist", 10.0)
        m.record_histogram("hist", 20.0)

        snapshot = await m.get_snapshot()

        assert snapshot["counters"]["counter"] == 5
        assert snapshot["gauges"]["gauge"] == 42.0
        assert "hist" in snapshot["histograms"]
        assert snapshot["histograms"]["hist"]["count"] == 2
        assert snapshot["histograms"]["hist"]["avg"] == 15.0

    @pytest.mark.asyncio
    async def test_reset(self):
        m = InMemoryMetrics()
        m.increment("counter", 5)
        m.set_gauge("gauge", 42.0)
        m.record_histogram("hist", 10.0)

        await m.reset()

        assert len(m._counters) == 0
        assert len(m._gauges) == 0
        assert len(m._histograms) == 0


# ============================================================================
# Tests: KernelMonitor
# ============================================================================

class TestKernelMonitor:
    def test_initialization(self, analytics_driver):
        monitor = KernelMonitor(analytics_driver, node_id="test", batch_size=50)
        assert monitor.node_id == "test"
        assert monitor.batch_size == 50
        assert len(monitor._metrics_buffer) == 0

    @pytest.mark.asyncio
    async def test_collect_metric(self, monitor):
        await monitor.collect_metric(
            operation="test_op",
            duration_ms=45.2,
            status="success",
            resource_type="TestModel",
            metadata={"rid": "test:123"},
        )

        assert len(monitor._metrics_buffer) == 1
        assert monitor._metrics_buffer[0]["operation"] == "test_op"
        assert monitor._metrics_buffer[0]["duration_ms"] == 45.2

    @pytest.mark.asyncio
    async def test_collect_batch(self, monitor):
        metrics_batch = [
            {"timestamp": datetime.now(UTC), "operation": f"op{i}",
             "duration_ms": float(i), "status": "success", "resource_type": "Test",
             "node_id": "test", "metadata": {}}
            for i in range(5)
        ]

        await monitor.collect_batch(metrics_batch)
        assert len(monitor._metrics_buffer) == 5

    @pytest.mark.asyncio
    async def test_auto_flush_on_batch_size(self, analytics_driver):
        monitor = KernelMonitor(analytics_driver, batch_size=3)

        for i in range(5):
            await monitor.collect_metric(
                operation=f"op{i}", duration_ms=float(i), status="success",
            )

        # Buffer should have been flushed when it hit batch_size
        assert len(monitor._metrics_buffer) < 5

    @pytest.mark.asyncio
    async def test_start_auto_flush(self, monitor):
        await monitor.start_auto_flush()
        assert monitor._running is True
        assert monitor._flush_task is not None
        await monitor.stop()

    def test_query_metrics(self, monitor):
        # Query should work even with empty table
        results = monitor.query_metrics("SELECT COUNT(*) FROM kernel_metrics")
        assert isinstance(results, list)

    def test_get_summary(self, monitor):
        summary = monitor.get_summary(hours=24)
        assert "period_hours" in summary
        assert "total_operations" in summary


# ============================================================================
# Tests: MetricTimer
# ============================================================================

class TestMetricTimer:
    @pytest.mark.asyncio
    async def test_metric_timer_success(self, monitor):
        async with MetricTimer(monitor, "test_operation", resource_type="TestModel"):
            await asyncio.sleep(0.01)

        assert len(monitor._metrics_buffer) == 1
        assert monitor._metrics_buffer[0]["operation"] == "test_operation"
        assert monitor._metrics_buffer[0]["status"] == "success"
        assert monitor._metrics_buffer[0]["duration_ms"] > 0

    @pytest.mark.asyncio
    async def test_metric_timer_error(self, monitor):
        with pytest.raises(ValueError):
            async with MetricTimer(monitor, "failing_operation"):
                raise ValueError("Test error")

        assert len(monitor._metrics_buffer) == 1
        assert monitor._metrics_buffer[0]["status"] == "error"
        assert "error" in monitor._metrics_buffer[0]["metadata"]


# ============================================================================
# Tests: KernelInstrumentation
# ============================================================================

class TestKernelInstrumentation:
    def test_initialization(self, analytics_driver):
        instr = KernelInstrumentation(analytics_driver, interval=30, node_id="test")
        assert instr.interval == 30
        assert instr.node_id == "test"
        assert instr._running is False

    @pytest.mark.asyncio
    async def test_start_stop(self, analytics_driver):
        instr = KernelInstrumentation(analytics_driver, interval=1)
        await instr.start()
        assert instr._running is True
        assert instr._task is not None
        await instr.stop()
        assert instr._running is False

    @pytest.mark.asyncio
    async def test_flush_metrics(self, analytics_driver):
        instr = KernelInstrumentation(analytics_driver, interval=60)

        # Add some metrics
        metrics.increment("test.count", 5)
        metrics.set_gauge("test.gauge", 42.0)

        # Flush
        await instr._flush_metrics()

        # Verify data was written (query sys_metrics table)
        result = analytics_driver.conn.execute("SELECT COUNT(*) FROM sys_metrics").fetchone()
        assert result[0] >= 0  # May or may not have data depending on timing


# ============================================================================
# Tests: Global metrics instance
# ============================================================================

class TestGlobalMetrics:
    def test_global_metrics_available(self):
        assert metrics is not None
        assert isinstance(metrics, InMemoryMetrics)

    def test_global_metrics_increment(self):
        initial = metrics._counters.get("global.test", 0)
        metrics.increment("global.test")
        assert metrics._counters["global.test"] == initial + 1

    def test_global_metrics_timer(self):
        with metrics.timer("global.timer"):
            pass
        assert "global.timer" in metrics._histograms


# ============================================================================
# Tests: Integration with Kernel
# ============================================================================

class TestMonitoringIntegration:
    @pytest.mark.asyncio
    async def test_kernel_with_monitoring(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=True,
            node_id="monitored-node",
        )

        assert manager.monitor is not None
        assert manager.instrumentation is not None

        await manager.close()

    @pytest.mark.asyncio
    async def test_kernel_without_monitoring(self, temp_dir):
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")

        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )

        assert manager.monitor is None
        assert manager.instrumentation is None

        await manager.close()
