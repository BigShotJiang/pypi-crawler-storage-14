"""
Test Suite: DuckDB Federation (Helix)
=====================================

Tests for federated query support across multiple data sources.
"""

import csv
import os
import shutil
import sqlite3
import tempfile

import pytest

from malha.malha import DuckDBDriver

# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
def driver():
    """Create a DuckDB driver instance."""
    d = DuckDBDriver()
    yield d
    d.close()


@pytest.fixture
def sqlite_db(temp_dir):
    """Create a SQLite database with test data."""
    db_path = os.path.join(temp_dir, "test_federation.db")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create test table
    cursor.execute("""
        CREATE TABLE customers (
            id INTEGER PRIMARY KEY,
            name TEXT,
            email TEXT,
            status TEXT,
            balance REAL
        )
    """)

    # Insert test data
    customers = [
        (1, "Alice", "alice@example.com", "active", 1000.0),
        (2, "Bob", "bob@example.com", "active", 500.0),
        (3, "Charlie", "charlie@example.com", "inactive", 0.0),
        (4, "Diana", "diana@example.com", "active", 2500.0),
        (5, "Eve", "eve@example.com", "suspended", 100.0),
    ]
    cursor.executemany("INSERT INTO customers VALUES (?, ?, ?, ?, ?)", customers)
    conn.commit()
    conn.close()

    return db_path


@pytest.fixture
def csv_file(temp_dir):
    """Create a CSV file with test data."""
    csv_path = os.path.join(temp_dir, "products.csv")

    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "name", "price", "category"])
        writer.writerow([1, "Widget", 9.99, "electronics"])
        writer.writerow([2, "Gadget", 19.99, "electronics"])
        writer.writerow([3, "Book", 14.99, "media"])
        writer.writerow([4, "Pen", 1.99, "office"])

    return csv_path


@pytest.fixture
def parquet_file(temp_dir):
    """Create a Parquet file with test data."""
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError:
        pytest.skip("pyarrow not installed")

    parquet_path = os.path.join(temp_dir, "events.parquet")

    table = pa.table({
        "event_id": [1, 2, 3, 4, 5],
        "event_type": ["click", "purchase", "click", "signup", "purchase"],
        "user_id": [101, 102, 101, 103, 104],
        "amount": [0.0, 99.99, 0.0, 0.0, 49.99],
    })

    pq.write_table(table, parquet_path)
    return parquet_path


# ============================================================================
# Tests: DuckDBDriver Initialization
# ============================================================================

class TestDuckDBDriverInit:
    """Tests for DuckDB driver initialization."""

    def test_driver_creates_connection(self, driver):
        """Test driver creates a DuckDB connection."""
        assert driver.conn is not None
        assert driver.zero_copy is False

    def test_driver_tracks_extensions(self, driver):
        """Test driver tracks loaded extensions."""
        assert isinstance(driver._extensions_loaded, set)

    def test_driver_supported_sources(self, driver):
        """Test driver has correct supported sources."""
        expected = {"postgres", "parquet", "csv", "sqlite", "s3"}
        assert expected == driver.SUPPORTED_SOURCES

    def test_driver_with_sqlite_path(self, sqlite_db):
        """Test driver with SQLite zero-copy attachment."""
        driver = DuckDBDriver(sqlite_path=sqlite_db)
        assert driver.zero_copy is True
        driver.close()


# ============================================================================
# Tests: Extension Loading
# ============================================================================

class TestExtensionLoading:
    """Tests for DuckDB extension management."""

    def test_load_extension_success(self, driver):
        """Test loading an extension successfully."""
        # parquet is usually built-in
        result = driver._load_extension("parquet", required=False)
        # May or may not succeed depending on DuckDB version
        assert isinstance(result, bool)

    def test_load_extension_caches(self, driver):
        """Test extension loading is cached."""
        driver._extensions_loaded.add("test_ext")
        result = driver._load_extension("test_ext", required=False)
        assert result is True

    def test_load_extension_required_failure(self, driver):
        """Test required extension raises on failure."""
        with pytest.raises(RuntimeError, match="Required DuckDB extension"):
            driver._load_extension("nonexistent_extension_xyz", required=True)


# ============================================================================
# Tests: Query Methods
# ============================================================================

class TestQueryMethods:
    """Tests for basic query methods."""

    @pytest.mark.asyncio
    async def test_query_returns_tuples(self, driver):
        """Test query() returns raw tuples."""
        result = await driver.query("SELECT 1 as a, 'hello' as b")
        assert result == [(1, "hello")]

    @pytest.mark.asyncio
    async def test_query_df_returns_dicts(self, driver):
        """Test query_df() returns list of dicts."""
        result = await driver.query_df("SELECT 1 as a, 'hello' as b")
        assert result == [{"a": 1, "b": "hello"}]

    @pytest.mark.asyncio
    async def test_query_df_multiple_rows(self, driver):
        """Test query_df() with multiple rows."""
        driver.conn.execute("CREATE TABLE test (id INT, name VARCHAR)")
        driver.conn.execute("INSERT INTO test VALUES (1, 'Alice'), (2, 'Bob')")

        result = await driver.query_df("SELECT * FROM test ORDER BY id")
        assert len(result) == 2
        assert result[0]["name"] == "Alice"
        assert result[1]["name"] == "Bob"


# ============================================================================
# Tests: Federated Query - SQLite
# ============================================================================

class TestFederatedSQLite:
    """Tests for SQLite federation."""

    @pytest.mark.asyncio
    async def test_sqlite_federation_all_rows(self, driver, sqlite_db):
        """Test SQLite federation returns all rows."""
        result = await driver.query_federated({
            "type": "sqlite",
            "path": sqlite_db,
            "table": "customers",
        })

        assert len(result) == 5
        assert all("name" in r for r in result)

    @pytest.mark.asyncio
    async def test_sqlite_federation_with_filter(self, driver, sqlite_db):
        """Test SQLite federation with WHERE filter."""
        result = await driver.query_federated({
            "type": "sqlite",
            "path": sqlite_db,
            "table": "customers",
        }, "status = 'active'")

        assert len(result) == 3
        assert all(r["status"] == "active" for r in result)

    @pytest.mark.asyncio
    async def test_sqlite_federation_numeric_filter(self, driver, sqlite_db):
        """Test SQLite federation with numeric filter."""
        result = await driver.query_federated({
            "type": "sqlite",
            "path": sqlite_db,
            "table": "customers",
        }, "balance > 500")

        assert len(result) == 2
        assert all(r["balance"] > 500 for r in result)

    @pytest.mark.asyncio
    async def test_sqlite_federation_missing_path(self, driver):
        """Test SQLite federation raises on missing path."""
        with pytest.raises(ValueError, match="requires 'path' and 'table'"):
            await driver.query_federated({
                "type": "sqlite",
                "table": "customers",
            })

    @pytest.mark.asyncio
    async def test_sqlite_federation_missing_table(self, driver, sqlite_db):
        """Test SQLite federation raises on missing table."""
        with pytest.raises(ValueError, match="requires 'path' and 'table'"):
            await driver.query_federated({
                "type": "sqlite",
                "path": sqlite_db,
            })


# ============================================================================
# Tests: Federated Query - CSV
# ============================================================================

class TestFederatedCSV:
    """Tests for CSV federation."""

    @pytest.mark.asyncio
    async def test_csv_federation_all_rows(self, driver, csv_file):
        """Test CSV federation returns all rows."""
        result = await driver.query_federated({
            "type": "csv",
            "path": csv_file,
        })

        assert len(result) == 4
        assert all("name" in r for r in result)

    @pytest.mark.asyncio
    async def test_csv_federation_with_filter(self, driver, csv_file):
        """Test CSV federation with WHERE filter."""
        result = await driver.query_federated({
            "type": "csv",
            "path": csv_file,
        }, "category = 'electronics'")

        assert len(result) == 2
        assert all(r["category"] == "electronics" for r in result)

    @pytest.mark.asyncio
    async def test_csv_federation_numeric_filter(self, driver, csv_file):
        """Test CSV federation with numeric filter."""
        result = await driver.query_federated({
            "type": "csv",
            "path": csv_file,
        }, "price < 10")

        assert len(result) == 2  # Widget and Pen

    @pytest.mark.asyncio
    async def test_csv_federation_missing_path(self, driver):
        """Test CSV federation raises on missing path."""
        with pytest.raises(ValueError, match="requires 'path'"):
            await driver.query_federated({"type": "csv"})


# ============================================================================
# Tests: Federated Query - Parquet
# ============================================================================

class TestFederatedParquet:
    """Tests for Parquet federation."""

    @pytest.mark.asyncio
    async def test_parquet_federation_all_rows(self, driver, parquet_file):
        """Test Parquet federation returns all rows."""
        result = await driver.query_federated({
            "type": "parquet",
            "path": parquet_file,
        })

        assert len(result) == 5
        assert all("event_type" in r for r in result)

    @pytest.mark.asyncio
    async def test_parquet_federation_with_filter(self, driver, parquet_file):
        """Test Parquet federation with WHERE filter."""
        result = await driver.query_federated({
            "type": "parquet",
            "path": parquet_file,
        }, "event_type = 'purchase'")

        assert len(result) == 2
        assert all(r["event_type"] == "purchase" for r in result)

    @pytest.mark.asyncio
    async def test_parquet_federation_numeric_filter(self, driver, parquet_file):
        """Test Parquet federation with numeric filter."""
        result = await driver.query_federated({
            "type": "parquet",
            "path": parquet_file,
        }, "amount > 0")

        assert len(result) == 2
        assert all(r["amount"] > 0 for r in result)

    @pytest.mark.asyncio
    async def test_parquet_federation_missing_path(self, driver):
        """Test Parquet federation raises on missing path."""
        with pytest.raises(ValueError, match="requires 'path'"):
            await driver.query_federated({"type": "parquet"})


# ============================================================================
# Tests: Federated Query - S3 (Mocked)
# ============================================================================

class TestFederatedS3:
    """Tests for S3 federation (mocked)."""

    @pytest.mark.asyncio
    async def test_s3_auto_detect_parquet(self, driver):
        """Test S3 auto-detects parquet format."""
        query = driver._build_s3_query({
            "path": "s3://bucket/data.parquet",
        }, "id = 1")

        assert "read_parquet" in query
        assert "s3://bucket/data.parquet" in query

    @pytest.mark.asyncio
    async def test_s3_auto_detect_csv(self, driver):
        """Test S3 auto-detects CSV format."""
        query = driver._build_s3_query({
            "path": "s3://bucket/data.csv",
        }, "id = 1")

        assert "read_csv_auto" in query

    @pytest.mark.asyncio
    async def test_s3_auto_detect_json(self, driver):
        """Test S3 auto-detects JSON format."""
        query = driver._build_s3_query({
            "path": "s3://bucket/data.json",
        }, "id = 1")

        assert "read_json_auto" in query

    @pytest.mark.asyncio
    async def test_s3_missing_path(self, driver):
        """Test S3 federation raises on missing path."""
        with pytest.raises(ValueError, match="requires 'path'"):
            await driver.query_federated({"type": "s3"})

    def test_s3_credentials_configuration(self, driver):
        """Test S3 credentials are configured."""
        # Mock the extension loading
        driver._extensions_loaded.add("httpfs")

        config = {
            "path": "s3://bucket/data.parquet",
            "aws_access_key_id": "AKIATEST",
            "aws_secret_access_key": "secret123",
            "aws_region": "us-east-1",
        }

        # Should not raise
        driver._configure_s3_if_needed(config)

    def test_s3_skip_non_s3_paths(self, driver):
        """Test S3 config is skipped for non-S3 paths."""
        config = {"path": "/local/file.parquet"}
        # Should not raise or configure anything
        driver._configure_s3_if_needed(config)


# ============================================================================
# Tests: Federated Query - PostgreSQL (Mocked)
# ============================================================================

class TestFederatedPostgres:
    """Tests for PostgreSQL federation (mocked - requires actual Postgres for integration)."""

    def test_postgres_query_build(self, driver):
        """Test PostgreSQL query is built correctly."""
        # Mock extension as loaded
        driver._extensions_loaded.add("postgres")

        query = driver._build_postgres_query({
            "dsn": "dbname=test user=test",
            "table": "customers",
            "schema": "public",
        }, "status = 'active'")

        assert "postgres_scan" in query
        assert "dbname=test user=test" in query
        assert "public" in query
        assert "customers" in query
        assert "status = 'active'" in query

    def test_postgres_missing_dsn(self, driver):
        """Test PostgreSQL raises on missing DSN."""
        driver._extensions_loaded.add("postgres")

        with pytest.raises(ValueError, match="requires 'dsn' and 'table'"):
            driver._build_postgres_query({"table": "customers"}, "1=1")

    def test_postgres_missing_table(self, driver):
        """Test PostgreSQL raises on missing table."""
        driver._extensions_loaded.add("postgres")

        with pytest.raises(ValueError, match="requires 'dsn' and 'table'"):
            driver._build_postgres_query({"dsn": "dbname=test"}, "1=1")

    def test_postgres_default_schema(self, driver):
        """Test PostgreSQL uses public schema by default."""
        driver._extensions_loaded.add("postgres")

        query = driver._build_postgres_query({
            "dsn": "dbname=test",
            "table": "users",
        }, "1=1")

        assert "'public'" in query


# ============================================================================
# Tests: Unsupported Sources
# ============================================================================

class TestUnsupportedSources:
    """Tests for unsupported federation sources."""

    @pytest.mark.asyncio
    async def test_unsupported_source_raises(self, driver):
        """Test unsupported source type raises ValueError."""
        with pytest.raises(ValueError, match="Unsupported federation source"):
            await driver.query_federated({
                "type": "mongodb",
                "uri": "mongodb://localhost",
            })

    @pytest.mark.asyncio
    async def test_empty_source_type(self, driver):
        """Test empty source type raises ValueError."""
        with pytest.raises(ValueError, match="Unsupported federation source"):
            await driver.query_federated({"path": "/some/path"})


# ============================================================================
# Tests: Default Filter
# ============================================================================

class TestDefaultFilter:
    """Tests for default filter behavior."""

    @pytest.mark.asyncio
    async def test_default_filter_returns_all(self, driver, csv_file):
        """Test default filter (1=1) returns all rows."""
        # Without explicit filter
        result = await driver.query_federated({
            "type": "csv",
            "path": csv_file,
        })

        assert len(result) == 4

    @pytest.mark.asyncio
    async def test_explicit_1_equals_1(self, driver, csv_file):
        """Test explicit 1=1 filter returns all rows."""
        result = await driver.query_federated({
            "type": "csv",
            "path": csv_file,
        }, "1=1")

        assert len(result) == 4


# ============================================================================
# Tests: UnifiedDataManager Federation Proxy
# ============================================================================

class TestUnifiedDataManagerFederation:
    """Tests for federation through UnifiedDataManager."""

    @pytest.fixture
    async def kernel(self, temp_dir):
        """Create a kernel instance."""
        from malha import connect

        db_path = os.path.join(temp_dir, "kernel.db")
        graph_path = os.path.join(temp_dir, "graph")

        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )
        yield kernel
        await kernel.close()

    @pytest.mark.asyncio
    async def test_kernel_query_federated_csv(self, kernel, csv_file):
        """Test kernel.query_federated with CSV."""
        result = await kernel.query_federated({
            "type": "csv",
            "path": csv_file,
        })

        assert len(result) == 4
        assert all("name" in r for r in result)

    @pytest.mark.asyncio
    async def test_kernel_query_federated_sqlite(self, kernel, sqlite_db):
        """Test kernel.query_federated with SQLite."""
        result = await kernel.query_federated({
            "type": "sqlite",
            "path": sqlite_db,
            "table": "customers",
        }, "status = 'active'")

        assert len(result) == 3
        assert all(r["status"] == "active" for r in result)

    @pytest.mark.asyncio
    async def test_kernel_query_federated_parquet(self, kernel, parquet_file):
        """Test kernel.query_federated with Parquet."""
        result = await kernel.query_federated({
            "type": "parquet",
            "path": parquet_file,
        }, "event_type = 'purchase'")

        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_kernel_query_federated_error(self, kernel):
        """Test kernel.query_federated raises on invalid source."""
        with pytest.raises(ValueError, match="Unsupported federation source"):
            await kernel.query_federated({
                "type": "invalid_source",
            })


# ============================================================================
# Tests: Context Manager Support
# ============================================================================

class TestContextManager:
    """Tests for async context manager support."""

    @pytest.mark.asyncio
    async def test_async_with_connect(self, temp_dir):
        """Test async with connect() as kernel."""
        from malha import connect

        db_path = os.path.join(temp_dir, "ctx.db")
        graph_path = os.path.join(temp_dir, "ctx_graph")

        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )

        async with kernel:
            assert kernel is not None
            # Kernel should be usable
            assert hasattr(kernel, "from_csv")

        # After exiting, kernel should be closed

    @pytest.mark.asyncio
    async def test_context_manager_cleanup_on_error(self, temp_dir):
        """Test context manager cleans up even on error."""
        from malha import connect

        db_path = os.path.join(temp_dir, "ctx_err.db")
        graph_path = os.path.join(temp_dir, "ctx_err_graph")

        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )

        try:
            async with kernel:
                raise ValueError("Intentional error")
        except ValueError:
            pass  # Expected

        # Cleanup should have happened


# ============================================================================
# Tests: Federation Shortcuts
# ============================================================================

class TestFederationShortcuts:
    """Tests for federation shortcut methods."""

    @pytest.fixture
    async def kernel(self, temp_dir):
        """Create a kernel instance."""
        from malha import connect

        db_path = os.path.join(temp_dir, "shortcuts.db")
        graph_path = os.path.join(temp_dir, "shortcuts_graph")

        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )
        yield kernel
        await kernel.close()

    @pytest.mark.asyncio
    async def test_from_csv_shortcut(self, kernel, csv_file):
        """Test from_csv shortcut."""
        result = await kernel.from_csv(csv_file)
        assert len(result) == 4

        # With filter
        result = await kernel.from_csv(csv_file, "category = 'electronics'")
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_from_sqlite_shortcut(self, kernel, sqlite_db):
        """Test from_sqlite shortcut."""
        result = await kernel.from_sqlite(sqlite_db, "customers")
        assert len(result) == 5

        # With filter
        result = await kernel.from_sqlite(sqlite_db, "customers", "balance > 500")
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_from_parquet_shortcut(self, kernel, parquet_file):
        """Test from_parquet shortcut."""
        result = await kernel.from_parquet(parquet_file)
        assert len(result) == 5

        # With filter
        result = await kernel.from_parquet(parquet_file, "amount > 0")
        assert len(result) == 2


# ============================================================================
# Tests: Improved Error Messages
# ============================================================================

class TestImprovedErrorMessages:
    """Tests for improved error messages with examples."""

    @pytest.mark.asyncio
    async def test_unsupported_source_error_has_example(self, driver):
        """Test unsupported source error includes example."""
        with pytest.raises(ValueError) as exc_info:
            await driver.query_federated({"type": "mongodb"})

        error_msg = str(exc_info.value)
        assert "Example:" in error_msg
        assert "csv" in error_msg.lower()

    def test_postgres_error_has_example(self, driver):
        """Test PostgreSQL error includes example."""
        driver._extensions_loaded.add("postgres")

        with pytest.raises(ValueError) as exc_info:
            driver._build_postgres_query({"table": "users"}, "1=1")

        error_msg = str(exc_info.value)
        assert "Example:" in error_msg
        assert "dsn" in error_msg

    def test_sqlite_error_has_example(self, driver):
        """Test SQLite error includes example."""
        driver._extensions_loaded.add("sqlite")

        with pytest.raises(ValueError) as exc_info:
            driver._build_sqlite_query({"path": "/db.sqlite"}, "1=1")

        error_msg = str(exc_info.value)
        assert "Example:" in error_msg
        assert "table" in error_msg
