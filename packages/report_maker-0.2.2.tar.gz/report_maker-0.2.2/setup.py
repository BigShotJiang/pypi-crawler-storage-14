from extended_setup import ExtendedSetupManager
from setuptools import find_namespace_packages


ExtendedSetupManager('report_maker').setup \
(
    short_description = "A tool to convert Markdown documents into a single .docx report with proper formatting",
    category = 'report-maker',
    min_python_version = '3.12',
    entry_points = dict(console_scripts = [ 'report-maker = report_maker.main:main' ]),
    packages = find_namespace_packages(where='src'),
    classifiers =
    [
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
        'Topic :: Documentation',
        'Topic :: Text Processing :: Markup :: Markdown',
        'Topic :: Text Processing',
        'Topic :: Utilities',
        'Typing :: Typed',
    ]
)
