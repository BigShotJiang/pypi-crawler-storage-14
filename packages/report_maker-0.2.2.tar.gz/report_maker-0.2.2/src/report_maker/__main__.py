if (__name__ == '__main__'):
    from report_maker.main import main
    exit_code = main()
    exit(exit_code)
