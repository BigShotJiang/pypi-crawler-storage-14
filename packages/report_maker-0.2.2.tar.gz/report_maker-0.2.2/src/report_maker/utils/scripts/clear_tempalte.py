from pathlib import Path

from report_maker.core.interfaces.template_lodader import TemplateLoader
from report_maker.utils.docx_extras import document_clear, document_open, document_save


def clear_master_template(template_name: str) -> Path:
    template_loader = TemplateLoader(template_name)
    doc_path = template_loader.template_documents / 'master-template.docx'
    doc = document_open(doc_path)
    document_clear(doc)
    document_save(doc, doc_path)
    
    print(f"Document `{doc_path}` cleared")
    return doc_path


__all__ = \
[
    'clear_master_template',
]

def main():
    clear_master_template('gost-7.32')
    return 0

if (__name__ == '__main__'):
    exit_code = main()
    exit(exit_code)
