from collections import defaultdict
from typing import *

from docx.document import Document
from docx.styles.style import BaseStyle, CharacterStyle
from report_maker.core.concepts import StyleName
from report_maker.core.interfaces.template_lodader import TemplateLoader


type _Styles[S: BaseStyle] = Dict[Type[S], List[S]]

@overload
def style_name_repr(style: BaseStyle) -> str:
    ...
@overload
def style_name_repr(style: None) -> None:
    ...
def style_name_repr(style: BaseStyle | None) -> str | None:
    if (not style):
        return None
    return f"{style.name!r} [id={style.style_id}]"

def print_style(style: BaseStyle):
    print(f"{style_name_repr(style)} (quick={style.quick_style}", end='')
    if (hasattr(style, 'base_style')):
        style = cast(CharacterStyle, style)
        print(f", parent={style_name_repr(style.base_style)}", end='')
    print(')')

def print_styles_group(group: _Styles, group_name: str):
    print(f"Begin of {group_name} styles")
    for st_type, st_list in group.items():
        print(f"{st_type.__name__} ({group_name}): {len(st_list)}")
        for st in st_list:
            print(' * ', end='')
            print_style(st)
        else:
            print()
    else:
        print(f"End of {group_name} styles.", end='\n\n')


def inspect_styles(doc: Document):
    builtin_styles: _Styles = defaultdict(list)
    public_styles: _Styles = defaultdict(list)
    hidden_styles: _Styles = defaultdict(list)
    
    for st in doc.styles:
        if (st.builtin):
            styles_dict = builtin_styles
        elif (not st.hidden):
            styles_dict = public_styles
        else:
            styles_dict = hidden_styles
        
        styles_dict[type(st)].append(st)
    
    print_styles_group(builtin_styles, "builtin")
    print_styles_group(public_styles, "public")
    print_styles_group(hidden_styles, "hidden")

def inspect_hyperlinks(doc: Document):
    print("Inspecting hyperlinks:")
    for p in doc.paragraphs:
        for link in p.hyperlinks:
            print(f"Hyperlink: {link.url}:")
            for r in link.runs:
                print(f" * text: {r.text} (style: {style_name_repr(r.style)})")
            else:
                print()
    else:
        print("End of inspecting hyperlinks.", end='\n\n')

def get_properties(obj) -> Iterable[Tuple[str, Any]]:
    for name in dir(type(obj)):
        attr = getattr(type(obj), name)
        if isinstance(attr, property):
            try:
                yield name, getattr(obj, name)
            except:
                continue

def inspect_specific_style(doc: Document, style_name: StyleName):
    if (style_name in doc.styles):
        st: CharacterStyle = doc.styles[style_name]
        print(f"{style_name} style:")
        for k, v in get_properties(st):
            if (v is not None):
                print(f" * {k}: {v}")
        else:
            print()
        
        print(f"{style_name} font style:")
        for k, v in get_properties(st.font):
            if (v is not None):
                print(f" * {k}: {v}")
        else:
            print()
    
        print(f"{style_name} font color:")
        for k, v in get_properties(st.font.color):
            if (v is not None):
                print(f" * {k}: {v}")
        else:
            print()
    
    else:
        print(f"Style {style_name!r} is not defined.")
    
    print()


def inspect_document(doc: Document):
    inspect_styles(doc)
    inspect_hyperlinks(doc)
    inspect_specific_style(doc, StyleName('Heading 1'))

def main():
    # print("Inspecting empty document...")
    # doc = docx.Document()
    # inspect_document(doc)
    
    print("Inspecting document from template...")
    doc = TemplateLoader('gost-7.32').load_main_template()
    inspect_document(doc)
    
    return 0

if (__name__ == '__main__'):
    exit_code = main()
    exit(exit_code)
