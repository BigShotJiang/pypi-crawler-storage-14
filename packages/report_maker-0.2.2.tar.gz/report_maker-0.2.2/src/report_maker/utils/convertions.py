from dataclass_exceptions import BaseExceptionABC, dataclass_exception

from docx.shared import Cm, Inches, Length, Mm, Pt


@dataclass_exception
class LengthParseException(BaseExceptionABC, ValueError):
    input_string: str
    
    @property
    def message(self) -> str:
        return f"Cannot parse the length units from the input string {self.input_string!r}"


@dataclass_exception
class UnknownUnitException(LengthParseException, ValueError, KeyError):
    unit: str
    
    @property
    def message(self) -> str:
        return f"Unknown unit: {self.unit!r} from the input string {self.input_string!r}"


def parse_length_units(value: str) -> Length:
    try:
        number, unit = value.split()
        number = float(number)
    except ValueError as exc:
        raise LengthParseException(value) from exc
    
    match (unit):
        case 'mm':
            return Mm(number)
        case 'cm':
            return Cm(number)
        case 'in':
            return Inches(number)
        case 'pt':
            return Pt(number)
        case _:
            raise UnknownUnitException(value, unit)


__all__ = \
[
    'LengthParseException',
    'UnknownUnitException',
    
    'parse_length_units',
]
