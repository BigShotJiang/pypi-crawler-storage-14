"""
This module contains functions not declared in the high-level API of the `docx` package.
However, the low-level API for these elements exists.

From https://github.com/python-openxml/python-docx/issues/74
"""
from pathlib import Path
from typing import cast

import docx
import docx.opc.constants
import docx.oxml.ns
import docx.oxml.shared
import docx.shared
from docx.document import Document
from docx.styles.style import CharacterStyle
from docx.table import Table
from docx.text.hyperlink import Hyperlink
from docx.text.paragraph import Paragraph
from docx.text.run import Run


def hyperlink_add_run(hyperlink: Hyperlink, text: str | None = None, style: str | None = None) -> Run:
    new_run = docx.oxml.shared.OxmlElement('w:r')
    rPr = docx.oxml.shared.OxmlElement('w:rPr')
    
    new_run.append(rPr)
    new_run.text = text
    hyperlink._element.append(new_run)
    run_obj = Run(cast(docx.oxml.CT_R, new_run), hyperlink._parent)
    run_obj.style = style
    return run_obj


def add_hyperlink(paragraph: Paragraph, link_to: str, text: str = None, style: str | CharacterStyle = 'Hyperlink', *, is_external: bool) -> Hyperlink:
    """ Adds a hyperlink within a paragraph to an internal bookmark or an external url """
    
    part = paragraph.part
    
    hyperlink_el = docx.oxml.shared.OxmlElement('w:hyperlink')
    if is_external:
        r_id = part.relate_to(link_to, 
            docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, 
            is_external= is_external)
        
        hyperlink_el.set(docx.oxml.shared.qn('r:id'), r_id, )
    
    else:
        hyperlink_el.set(docx.oxml.shared.qn('w:anchor'), link_to, )
    
    paragraph._p.append(hyperlink_el)
    
    hyperlink_obj = Hyperlink(cast(docx.oxml.CT_Hyperlink, hyperlink_el), paragraph)
    if (text is not None):
        hyperlink_add_run(hyperlink_obj, text, style=style)
    
    return hyperlink_obj

def add_bookmark(run: Run, bookmark_name: str) -> Run:
    """ Adds a word bookmark to a run """
    tag = run._r
    start = docx.oxml.shared.OxmlElement('w:bookmarkStart')
    start.set(docx.oxml.ns.qn('w:id'), '0')
    start.set(docx.oxml.ns.qn('w:name'), bookmark_name)
    tag.append(start)
    
    text = docx.oxml.OxmlElement('w:r')
    tag.append(text)
    
    end = docx.oxml.shared.OxmlElement('w:bookmarkEnd')
    end.set(docx.oxml.ns.qn('w:id'), '0')
    end.set(docx.oxml.ns.qn('w:name'), bookmark_name)
    tag.append(end)

    return run

def delete_paragraph(paragraph: Paragraph):
    p = paragraph._element
    p.getparent().remove(p)
    paragraph._p = paragraph._element = None

def delete_run(run: Run):
    r = run._element
    r.getparent().remove(r)
    run._r = run._element = None

def delete_table(table: Table):
    t = table._element
    t.getparent().remove(t)
    table._tbl = table._element = None

def document_clear(doc: Document) -> Document:
    while (doc.paragraphs):
        delete_paragraph(doc.paragraphs[0])
    while (doc.tables):
        delete_table(doc.tables[0])
    
    return doc

def document_open(path: str | Path) -> Document:
    with Path(path).open('rb') as f:
        return docx.Document(f)

_ORIG_SAVE_METH = Document.save
def document_save(doc: Document, path: str | Path):
    _ORIG_SAVE_METH(doc, str(path))


def register():
    Run.add_bookmark = add_bookmark
    Run.remove = delete_run
    Hyperlink.add_run = hyperlink_add_run
    Paragraph.add_hyperlink = add_hyperlink
    Paragraph.remove = delete_paragraph
    Document.clear = document_clear
    Document.open = document_open
    Document.save = document_save
    Table.remove = delete_table


__all__ = \
[
    'add_bookmark',
    'add_hyperlink',
    'delete_paragraph',
    'document_clear',
    'document_open',
    'document_save',
    'hyperlink_add_run',
    'register',
]
