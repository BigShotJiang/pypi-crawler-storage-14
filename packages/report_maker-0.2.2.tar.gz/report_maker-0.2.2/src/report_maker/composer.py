import importlib
import warnings
from copy import deepcopy
from logging import Logger, getLogger
from typing import *

from dataclass_exceptions.errors import BaseExceptionABC, InvalidArgumentTypeError, dataclass_exception
from docx.document import Document
from docxcompose.composer import Composer
from pyhocon import ConfigTree

from .config import *
from .core.converter_base import ConverterInterface, GlobalConfig
from .core.interfaces.template_lodader import TemplateLoader
from .core.meta import MetaCounters
from .core.root import RootProcessor
from .utils import docx_extras


ClassName = NewType('ClassName', str)
ModuleRef = NewType('ModuleRef', str)
type ClassRef = Tuple[ModuleRef, ClassRef]

@dataclass_exception
class UnsupportedAppendix(BaseExceptionABC, ImportWarning, UserWarning):
    appendix_config: ComposerPartTypeAppendix
    
    @property
    def message(self) -> str:
        return f"Part of type {self.appendix_config.appendix.type!r}"       \
               " (within {self.appendix_config.name!r}) is not supported."  \
               " Wrapping in appendix has no effect."                       \


class ComposerOrchestrator:
    config: ComposerConfig
    logger: Logger
    
    template_loader: TemplateLoader
    counters: MetaCounters
    main_root_processor: RootProcessor
    
    def __init__(self, config: ComposerConfig):
        self.config = config
        self.logger = getLogger(f'{self.__class__.__module__}.{self.__class__.__qualname__}')
        self.logger.debug(f"Composer config: {self.config}")
        self.template_loader = TemplateLoader(config.template)
    
    def make_part__document(self, part: ComposerPartTypeDocument) -> Document:
        return docx_extras.document_open(part.document_path)
    
    def make_part__from_template(self, part: ComposerPartTypeFromTemplate) -> Document:
        return self.template_loader.load_document(part.document_path)
    
    def make_part__appendix(self, part: ComposerPartTypeAppendix) -> Document:
        if ((cls := self._match_composer_part_config__to_class(part.appendix)) is not None):
            from .extensions.builtin.appendix_wrapper import AppendixWrapper, AppendixConfig
            return self.run_processor_extension(AppendixWrapper, AppendixConfig(part, cls), extra_configs={ cls: part.appendix })
        else:
            warnings.warn(UnsupportedAppendix(part))
            return self.make_part(part.appendix)
    
    def _match_composer_part_config__to_class_ref(self, part: BaseComposerPart) -> ClassRef | Tuple[None, None]:
        match (part):
            case ComposerPartTypeMarkdown():
                return (ModuleRef('.extensions.builtin.md_converter'), ClassName('MarkdownConverter'))
            case ComposerPartTypeSourceCode():
                return (ModuleRef('.extensions.builtin.code_converter'), ClassName('CodeConverter'))
            case ComposerPartTypeTemplate():
                return (ModuleRef('.extensions.builtin.docx_template_converter'), ClassName('DocumentTemplateProcessor'))
            case ComposerPartTypeLicense():
                return (ModuleRef('.extensions.builtin.license'), ClassName('LicenseConverter'))
            case _:
                return None, None
    
    def _match_composer_part_config__to_class(self, part: BaseComposerPart) -> Type[ConverterInterface] | None:
        module_ref, class_name = self._match_composer_part_config__to_class_ref(part)
        if (class_name is not None):
            cls = getattr(importlib.import_module(module_ref, __package__), class_name)
            return cls
        else:
            return None
    
    type _ComposerPartToDocument[P: BaseComposerPart] = Callable[[P], Document]
    def _match_composer_part_config__to_processor[P: BaseComposerPart](self, part: P) -> _ComposerPartToDocument[P] | None:
        match (part):
            case ComposerPartTypeDocument():
                return self.make_part__document
            case ComposerPartTypeFromTemplate():
                return self.make_part__from_template
            case ComposerPartTypeAppendix():
                return self.make_part__appendix
            case _:
                return None
    
    # noinspection PyTypeChecker
    def make_part(self, part: BaseComposerPart) -> Document:
        self.logger.info(f"Processing part {part.name!r}...")
        if ((cls := self._match_composer_part_config__to_class(part)) is not None):
            return self.run_processor_extension(cls, part)
        elif ((callback := self._match_composer_part_config__to_processor(part)) is not None):
            return callback(part)
        else:
            raise InvalidArgumentTypeError('part', (ComposerPartTypeMarkdown, ComposerPartTypeSourceCode, ComposerPartTypeDocument, ComposerPartTypeFromTemplate, ComposerPartTypeTemplate, ComposerPartTypeLicense, ComposerPartTypeAppendix), part)
    
    def get_global_config(self, ext: Type[ConverterInterface] = None, section_value = None, extra_configs: Dict[Type[ConverterInterface], Any] = None) -> GlobalConfig:
        assert (ext is None) == (section_value is None), "Either 'section' and 'section_value' must be both None, or both not be None."
        
        overrides = self.config.overrides
        if (isinstance(section_value, WithOverrides)):
            overrides = ConfigTree.merge_configs(deepcopy(overrides), cast(WithOverrides, section_value).overrides)
        
        gcfg = GlobalConfig \
        (
            template=self.config.template,
            overrides=overrides,
            extension_configs=DefaultDict[Type[ConverterInterface], Any](ConfigTree),
        )
        
        if (ext is not None):
            gcfg.extension_configs[ext] = section_value
            self.main_root_processor.global_config.extension_configs[ext] = gcfg.extension_configs[ext]
            self.main_root_processor.declare_extension(ext)
        
        if (extra_configs is not None):
            gcfg.extension_configs.update(extra_configs)
            self.main_root_processor.global_config.extension_configs.update(extra_configs)
        
        return gcfg
    
    def get_master_template(self) -> Document:
        return self.template_loader.load_main_template()
    
    def run_processor_extension(self, ext: Type[ConverterInterface], ext_config: Any, extra_configs: Dict[Type[ConverterInterface], Any] = None) -> Document:
        gcfg = self.get_global_config(ext, ext_config, extra_configs)
        root_processor = RootProcessor(self.get_master_template(), gcfg, ext, counters=self.counters)
        return root_processor.run()
    
    def compose(self):
        self.counters = MetaCounters()
        self.main_root_processor = RootProcessor(self.get_master_template(), self.get_global_config(), counters=self.counters)
        
        self.logger.info("Converting...")
        parts = [ self.make_part(part) for part in self.config.parts ]
        
        self.logger.info("Composing...")
        self.main_root_processor.run()
        
        composer = Composer(self.main_root_processor.doc)
        for part in parts:
            composer.append(part)
        
        self.logger.info("Saving...")
        composer.reset_reference_mapping()
        self.config.target.parent.mkdir(parents=True, exist_ok=True)
        composer.save(self.config.target)
        
        self.logger.info(f"Saved as '{self.config.target}'.")
        return 0


def compose(config: ComposerConfig):
    orchestrator = ComposerOrchestrator(config)
    return orchestrator.compose()


__all__ = \
[
    'ComposerOrchestrator',
    'compose',
]
