import re
import warnings
from abc import ABC
from datetime import datetime
from pathlib import Path
from typing import Iterable, Tuple

from dataclass_exceptions import BaseExceptionABC, dataclass_exception
from docx.document import Document
from docx.text.paragraph import Paragraph
from docxcompose.composer import Composer
from pyhocon import ConfigMissingException

from report_maker.config import ComposerPartTypeTemplate as DocumentTemplateProcessorConfig
from report_maker.core.converter_base import ConverterBase
from report_maker.utils import docx_extras


variable_prefix = re.compile(re.escape('${'))
variable_suffix = re.compile(re.escape('}'))
variable_pattern = re.compile(r'\$\{(?P<name>\w[\w.]*)}')


@dataclass_exception
class DocumentTemplateProcessorException(BaseExceptionABC, ABC):
    module: 'DocumentTemplateProcessor'
    
    @property
    def module_ref(self) -> str:
        return f"module '{self.module.config.name}' (template: {self.module.config.template})"

@dataclass_exception
class TemplateKeyMissingException(DocumentTemplateProcessorException, KeyError):
    key: str
    
    @property
    def message(self) -> str:
        return f"Key {self.key!r} not found in the {self.module_ref} configuration"

@dataclass_exception
class CannotMergeStyleWarning(DocumentTemplateProcessorException, UserWarning):
    context: Tuple[str, ...] = ()
    
    @property
    def message(self) -> str:
        return f"Styles differ for the pattern-containing section, cannot merge paragraph runs for the {self.module_ref} at {', '.join(self.context)}"


class DocumentTemplateProcessor(ConverterBase):
    config: DocumentTemplateProcessorConfig
    template_file: Path
    
    def validate_config(self):
        if (self.config.template.is_absolute()):
            self.template_file = self.config.template
        else:
            self.template_file = self.template_loader.template_documents / self.config.template
        
        assert self.template_file.is_file(), f"Template file {self.template_file} does not exist"
        self.config.attributes.setdefault('year', datetime.now().year)
    
    def declare_extensions(self):
        pass
    def declare_tasks(self):
        pass
    def declare_styles(self):
        pass
    def define_styles(self):
        pass
    
    def _match_substitution(self, m: re.Match[str]) -> str:
        key = m.group('name')
        try:
            return str(self.config.attributes.get(key))
        except ConfigMissingException as exc:
            raise TemplateKeyMissingException(self, key) from exc
    
    def replace_in_paragraphs(self, paragraphs: Iterable[Paragraph], *ctx: str):
        for p, par in enumerate(paragraphs, start=1):
            if (not variable_pattern.search(par.text)):
                self.logger.debug(f"Paragraph {par.text!r} does not match the pattern, skipping...")
                continue
            else:
                self.logger.debug(f"Paragraph {par.text!r} matches the pattern, replacing...")
            
            i = 0
            while i < len(par.runs):
                run = par.runs[i]
                if ('${' not in run.text):
                    i += 1
                    continue
                
                while (not variable_pattern.search(run.text)):
                    if (i+1 >= len(par.runs)):
                        break
                    
                    elif ((next_run := par.runs[i+1]).style == run.style):
                        self.logger.debug(f"{run.text!r} << {next_run.text!r}")
                        run.text += next_run.text
                        docx_extras.delete_run(next_run)
                    
                    else:
                        warnings.warn(CannotMergeStyleWarning(self, (*ctx, f"paragraph #{p}", f"run #{i+1}")))
                        break
                
                run.text = variable_pattern.sub(self._match_substitution, run.text)
                i += 1
    
    def replace_in_document(self, template: Document):
        for t, table in enumerate(template.tables, start=1):
            for r, row in enumerate(table.rows, start=1):
                for c, cell in enumerate(row.cells, start=1):
                    self.replace_in_paragraphs(cell.paragraphs, f"table #{t}", "R{r}C{c}")
        
        self.replace_in_paragraphs(template.paragraphs)
    
    def run(self):
        template = docx_extras.document_open(self.template_file)
        self.replace_in_document(template)
        composer = Composer(self.doc)
        composer.append(template)


__all__ = \
[
    'CannotMergeStyleWarning',
    'DocumentTemplateProcessor',
    'DocumentTemplateProcessorConfig',
    'DocumentTemplateProcessorException',
    'TemplateKeyMissingException',
]
