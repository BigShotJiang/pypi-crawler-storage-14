from __future__ import annotations

import itertools
from dataclasses import dataclass
from datetime import timedelta as TimeDelta, datetime as DateTime
from pathlib import Path
from typing import *

import pygments
from docx.shared import RGBColor
from docx.styles.style import CharacterStyle
from pygments.lexers import get_lexer_by_name, get_lexer_for_filename
from pygments.styles import get_style_by_name
from pygments.util import ClassNotFound

from report_maker.config import ComposerPartTypeSourceCode as CodeConverterConfig
from report_maker.core.concepts import *
from report_maker.core.converter_base import ConverterBase, Skip
from report_maker.core.interfaces.file_discovery import SimpleFileDiscovering
from report_maker.extensions.builtin.styles import SharedStyles

if (TYPE_CHECKING):
    from pygments.style import _StyleDict, Style as PygmentsStyle
    from pygments.token import _TokenType


@dataclass(kw_only=True)
class Context:
    file: Path
    language: str
    lexer: pygments.lexer.Lexer | None = None


class CodeConverter(ConverterBase, SimpleFileDiscovering[CodeConverterConfig]):
    config: CodeConverterConfig
    stylesheet: SharedStyles
    profile: Type[PygmentsStyle]
    files: List[Path]
    
    # region Stages
    def validate_config(self):
        self.profile = get_style_by_name(self.config.style_profile)
    
    def declare_extensions(self):
        self.stylesheet = self.declare_extension(SharedStyles)
    
    def declare_tasks(self):
        self.files = self.discover_files(self.config)
    
    def declare_styles(self):
        all(itertools.starmap(self.declare_token_style, self.profile.list_styles()))
    
    def define_styles(self):
        all(itertools.starmap(self.define_token_style, self.profile.list_styles()))
    # endregion
    # region Implementation: Styles
    @overload
    def _token_style_to_docx_name(self, token_style: None) -> None:
        ...
    @overload
    def _token_style_to_docx_name(self, token_style: _TokenType) -> StyleName:
        ...
    def _token_style_to_docx_name(self, token_style: _TokenType | None) -> StyleName | None:
        return StyleName(f"Code: {token_style!r}") if (token_style is not None) else None
    
    def _token_color_to_docx_rgb(self, token_color: str | None) -> RGBColor | None:
        if (token_color is None):
            return None
        else:
            return RGBColor.from_string(token_color)
    
    def declare_token_style(self, token_type: _TokenType, token_style: _StyleDict) -> CharacterStyle:
        name = self._token_style_to_docx_name(token_type)
        if (name in self.doc.styles):
            return self.doc.styles[name]
        
        parent = self._token_style_to_docx_name(token_type.parent)
        if (parent is not None and parent not in self.doc.styles):
            self.declare_token_style(token_type.parent, token_style)
        elif (parent is None):
            parent = self.stylesheet.preformatted_style
        style = self.declare_style(name, CharacterStyle, parent, pubic=False)
        return style
    
    def define_token_style(self, token_type: _TokenType, token_style: _StyleDict):
        style = self.doc.styles[self._token_style_to_docx_name(token_type)]
        
        # Always present
        style.font.bold = token_style['bold']
        style.font.italic = token_style['italic']
        style.font.underline = token_style['underline']
        
        # Might be None
        style.font.color.rgb = self._token_color_to_docx_rgb(token_style['color'])
        
        return style
        
        if ((highlight := token_style.get('bgcolor', None)) is not None):
            raise NotImplementedError("Background color is not supported yet")
            style.font.highlight_color = token_style['bgcolor']
        
        if ((border := token_style.get('border', None)) is not None):
            raise NotImplementedError("Border color is not supported yet")
            # style.font.outline
            # style.font.border = token_style['border']
        
        # # Ignored
        # style.font.sans = token_style['sans']
        # style.font.mono = token_style['mono']
        # style.font.roman = token_style['roman']
        # style.font.ansicolor = token_style['ansicolor']
        # style.font.bgansicolor = token_style['bgansicolor']
    # endregion
    # region Implementation: Code
    def add_file_heading(self, file: Path):
        rel_path = file.relative_to(self.config.root)
        heading = self.doc.add_paragraph(f"Файл ", self.stylesheet.h2_no_numbering_style) # ToDo: String literal
        heading.add_run(rel_path.as_posix(), style=self.stylesheet.preformatted_style.name)
    
    def process_code_block(self, code: str, context: Context):
        p = self.doc.add_paragraph(style=self.stylesheet.code_block_style.name)
        start = DateTime.now()
        parts = pygments.lex(code, context.lexer)
        parsed = DateTime.now()
        for el_t, el_v in parts:
            p.add_run(el_v, style=self._token_style_to_docx_name(el_t))
        end = DateTime.now()
        self.time_for_parse += parsed - start
        self.time_for_process += end - parsed
    
    def process_code_with_split(self, code: str, context: Context):
        for block in code.split('\n\n'):
            block = block.strip('\n')
            self.process_code_block(block, context)
    
    time_for_parse: TimeDelta = TimeDelta()
    time_for_process: TimeDelta = TimeDelta()
    time_total: TimeDelta = TimeDelta()
    def process_file(self, file: Path):
        start = DateTime.now()
        with self.step(f"Processing file: {file}"):
            context = Context(file=file, language=file.suffix[1:])
            source_text = file.read_text()
            source_text = source_text.replace('\r\n', '\n')
            if (not source_text):
                raise Skip("File is empty")
            
            if (context.lexer is None):
                try:
                    context.lexer = get_lexer_by_name(context.language)
                except ClassNotFound as e:
                    self.logger.debug(f"Lexer not found: {e}")
            if (context.lexer is None):
                try:
                    context.lexer = get_lexer_for_filename(context.file)
                except ClassNotFound:
                    self.logger.debug(f"Lexer not found for file: {context.file}")
            if (context.lexer is None):
                self.logger.warning(f"Lexer not found for file: {context.file}")
                context.lexer = get_lexer_by_name('text')
            
            self.add_file_heading(file)
            if (self.config.split_code_blocks):
                self.process_code_with_split(source_text, context)
            else:
                self.process_code_block(source_text, context)
        
        end = DateTime.now()
        self.time_total += end - start
    
    def run(self):
        self.stylesheet.add_auto_header("Исходный код проекта")
        for f in self.files:
            self.process_file(f)
        
        self.logger.debug(f"Time total: {self.time_total}")
        self.logger.debug(f"Time to lex: {self.time_for_parse}")
        self.logger.debug(f"Time to doc: {self.time_for_process}")
    # endregion


__all__ = \
[
    'CodeConverter',
    'CodeConverterConfig',
]
