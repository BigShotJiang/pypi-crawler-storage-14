from docx.shared import RGBColor
from docx.styles.style import CharacterStyle

from report_maker.core.concepts import StyleName
from report_maker.core.converter_base import ConverterBase
from report_maker.extensions.builtin.styles import SharedStyles

from report_maker.utils import docx_extras

class HyperlinksProcessor(ConverterBase):
    stylesheet: SharedStyles
    HYPERLINK_STYLE_NAME: StyleName = StyleName('Hyperlink')
    hyperlink_style: CharacterStyle
    
    def declare_extensions(self):
        self.stylesheet = self.declare_extension(SharedStyles)
        docx_extras.register()
    def validate_config(self):
        pass
    def declare_tasks(self):
        pass
    def declare_styles(self):
        self.hyperlink_style = self.declare_style(self.HYPERLINK_STYLE_NAME, CharacterStyle, base=self.stylesheet.default_paragraph_font_style)
    def define_styles(self):
        try:
            self.hyperlink_style.font.color.theme_color = 'HYPERLINK'
        except ValueError:
            self.hyperlink_style.font.color.rgb = RGBColor.from_string('0000ff')
        self.hyperlink_style.font.underline = True



__all__ = \
[
    'HyperlinksProcessor',
]
