from dataclasses import dataclass
from typing import *

from report_maker.config import ComposerPartTypeAppendix
from report_maker.core.converter_base import ConverterBase, ConverterInterface
from report_maker.core.meta import AppendixMeta
from .styles import SharedStyles


@dataclass
class AppendixConfig[C: ConverterInterface]:
    data: ComposerPartTypeAppendix
    extension: Type[C]


class AppendixWrapper[C: ConverterInterface](ConverterBase):
    config: AppendixConfig[C]
    stylesheet: SharedStyles
    ext_impl: C
    
    def validate_config(self):
        pass
    def declare_extensions(self):
        self.stylesheet = self.declare_extension(SharedStyles)
        self.ext_impl = self.declare_extension(self.config.extension)
    def declare_tasks(self):
        self.ext_impl.declare_tasks()
    def declare_styles(self):
        pass
    def define_styles(self):
        pass
    def run(self):
        with self.stylesheet.apply_appendix_meta(AppendixMeta(is_appendix=True, is_numbered=self.config.data.numbered)):
            self.ext_impl.run()


__all__ = \
[
    'AppendixWrapper',
    'AppendixConfig',
]
