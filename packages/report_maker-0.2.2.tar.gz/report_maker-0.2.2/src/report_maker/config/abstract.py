from __future__ import annotations

from abc import ABC
from pathlib import Path
from typing import *

from pyhocon import ConfigTree

from .meta import *


@dataclass_config
class WithOverrides(ConfigABC, ABC):
    overrides: ConfigTree
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(WithOverrides, cls)._update_attrs(config, attrs)
        attrs['overrides'] = ConfigTree(config.get_config('overrides', dict()))


ComposerTypeMarkdownStringLiteral = Literal['markdown']
ComposerTypeSourceCodeStringLiteral = Literal['source-code']
ComposerTypeDocumentStringLiteral = Literal['document']
ComposerTypeFromTemplateStringLiteral = Literal['from-template']
ComposerTypeTemplateStringLiteral = Literal['template']
ComposerTypeLicenseStringLiteral = Literal['license']
ComposerTypeAppendixStringLiteral = Literal['appendix']

type ComposerTypeStringLiteral = Union \
[
    ComposerTypeMarkdownStringLiteral,
    ComposerTypeSourceCodeStringLiteral,
    ComposerTypeDocumentStringLiteral,
    ComposerTypeFromTemplateStringLiteral,
    ComposerTypeTemplateStringLiteral,
    ComposerTypeLicenseStringLiteral,
    ComposerTypeAppendixStringLiteral,
]


@dataclass_config
class BaseComposerPart[L: ComposerTypeStringLiteral](Discriminating[L], WithOverrides, base_class=True):
    type: L
    name: str
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(BaseComposerPart, cls)._update_attrs(config, attrs)
        attrs['name'] = config.get_string('name')


@dataclass_config
class DiscoveringFile(ConfigABC):
    file: Path = None
    glob: str = None
    is_main_body: bool = False
    
    def __post_init__(self):
        assert (self.file is None) != (self.glob is None), "Either file or glob must be specified, not both."
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(DiscoveringFile, cls)._update_attrs(config, attrs)
        attrs['file'] = init_respecting_none(Path, config.get_string('file', None))
        attrs['glob'] = config.get_string('glob', None)
        attrs['is_main_body'] = config.get_bool('is_main_body', False)

# @dataclass(kw_only=True, frozen=True, slots=True)
# class Discovering(ConfigABC):
#     discover: bool
#     root: Path
#     files: List[DiscoveringFile] = None
# 
#     def __post_init__(self):
#         assert not ((self.files is None) and self.discover), "At most one of 'files' and 'discover' must be specified."
# 
#     @classmethod
#     def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
#         super()._update_attrs(config, attrs)
#         attrs['discover'] = config.get_bool('discover')
#         attrs['root'] = Path(config.get_string('root'))
#         _files: List[ConfigTree] = config.get_list('files', None)
#         if (_files is not None):
#             attrs['files'] = [ DiscoveringFile.parse_config(f) for f in _files ]



# def recursive_config[C](cls: Type[C], config: ConfigTree) -> C:
#     assert dataclasses.is_dataclass(cls)
#     kwargs = dict()
#     for field in dataclasses.fields(cls):
#         match (field.type):
#             case T if issubclass(T, (Path, str)):
#                 v = config.get_string(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, bool):
#                 v = config.get_bool(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, float):
#                 v = config.get_float(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, int):
#                 v = config.get_int(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, Mapping):
#                 v = config.get_list(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             
#             case T if issubclass(T, Sequence):
#                 v = config.get_list(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
# 
#     return cls(**kwargs)


__all__ = \
[
    'BaseComposerPart',
    'ComposerTypeAppendixStringLiteral',
    'ComposerTypeDocumentStringLiteral',
    'ComposerTypeFromTemplateStringLiteral',
    'ComposerTypeLicenseStringLiteral',
    'ComposerTypeMarkdownStringLiteral',
    'ComposerTypeSourceCodeStringLiteral',
    'ComposerTypeStringLiteral',
    'DiscoveringFile',
    'Discriminating',
    'WithOverrides',
]
