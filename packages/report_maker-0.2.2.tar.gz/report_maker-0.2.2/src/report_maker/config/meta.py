from __future__ import annotations

import dataclasses
import logging
import types
import typing
from abc import ABC
from dataclasses import Field, dataclass, is_dataclass
from functools import lru_cache
from typing import *

from pyhocon import ConfigTree


if typing.TYPE_CHECKING:
    # noinspection PyTypedDict
    class DataclassConfigParams(TypedDict, total=False):
        init: bool = True
        repr: bool = True
        eq: bool = True
        order: bool = False,
        unsafe_hash: bool = False
        match_args: bool = True,
        weakref_slot: bool = False
        
        # Changed
        kw_only: bool = True
        frozen: bool = True
        slots: bool = True
    
    type IdentityFunction[T] = Callable[[T], T]


@dataclass_transform(kw_only_default=True, frozen_default=True, slots_default=True)
@overload
def dataclass_config(**kwargs: Unpack[DataclassConfigParams]) -> IdentityFunction:
    ...

@dataclass_transform(kw_only_default=True, frozen_default=True, slots_default=True)
@overload
def dataclass_config[C: ConfigABC](cls: Type[C], **kwargs: Unpack[DataclassConfigParams]) -> Type[C]:
    ...

@dataclass_transform(kw_only_default=True, frozen_default=True, slots_default=False)
def dataclass_config[C: ConfigABC](cls: Type[C] | None = None, /, **kwargs: Unpack[DataclassConfigParams]):
    kwargs.setdefault('kw_only', True)
    kwargs.setdefault('frozen', True)
    kwargs.setdefault('slots', False)
    
    wrapper = dataclass(**kwargs)
    if (cls is not None):
        return wrapper(cls)
    else:
        return wrapper


@dataclass_config
class ConfigABC(ABC):
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        pass
    
    @classmethod
    def parse_config(cls, config: ConfigTree) -> Self:
        attrs = dict()
        cls._update_attrs(config, attrs)
        # noinspection PyArgumentList
        return cls(**attrs)

def _classnametuple(cls: type) -> Tuple[str, str]:
    return (cls.__module__, cls.__qualname__)

def _classeq(a: type, b: type) -> bool:
    return _classnametuple(a) == _classnametuple(b)

@dataclass_config
class Discriminating[T](ConfigABC, ABC):
    _registry: ClassVar[Dict[str, Type[Self]]]
    type: T
    
    def __init_subclass__(cls, *, base_class: bool = False, **kwargs):
        if (base_class):
            cls._registry = dict()
            return
        
        kind = cls._get_kind()
        log_suffix = "subclass of Discriminating[T]: kind=%s for `%s.%s` (id=%s)"
        extra_args = (kind, cls.__module__, cls.__qualname__, id(cls))
        
        if (kind is None):
            logging.debug("No argument `kind` passed from the " + log_suffix, *extra_args)
            return
        elif ((old_value := cls._from_registry(kind, raise_error=False)) is not None): # type: Type[Self]
            if old_value is cls:
                pass
            elif (_classeq(old_value, cls) and not base_class):
                logging.debug("Re-registering " + log_suffix, *extra_args)
                cls._registry[kind] = cls
            else:
                raise ValueError(f"Discriminator value '{kind}' is already registered for class {old_value}.")
        else:
            logging.debug("Initializing " + log_suffix, *extra_args)
            cls._registry[kind] = cls
    
    @classmethod
    def _resolve_kind(cls, kind: Any) -> str | None:
        if (isinstance(kind, types.MemberDescriptorType)):
            kind = None
        if (isinstance(kind, Field)):
            kind = kind.default
        if (typing.get_origin(kind) is Literal):
            kind = typing.get_args(kind)[0]
        
        match kind:
            case str(s):
                return s
            case None | dataclasses.MISSING:
                return None
            case _:
                return str(kind)
    
    @classmethod
    @lru_cache
    def _get_kind(cls) -> str | None:
        dc_kind = None
        if (is_dataclass(cls)):
            try:
                dc_kind = cls.__dataclass_fields__['type']
            except (KeyError, NameError, TypeError):
                pass
            else:
                # noinspection PyUnresolvedReferences
                dc_kind = cls._resolve_kind(dc_kind)
        
        try:
            # noinspection PyTypeChecker
            attr_kind = cls.type
        except NameError:
            attr_kind = None
        else:
            attr_kind = cls._resolve_kind(attr_kind)
        
        match (dc_kind, attr_kind):
            case (None, None):
                return None
            case (None, str(value)):
                return value
            case (str(value), None):
                return value
            case _:
                raise RuntimeError(f"Conflicting kind values! {dc_kind=!r} & {attr_kind=!r}")
    
    @classmethod
    def _from_registry(cls, kind: T, *, raise_error: bool = True) -> Type[Self]:
        kind = cls._resolve_kind(kind)
        if (kind and kind in cls._registry):
            _tp_cls = cls._registry[kind]
        elif raise_error:
            raise KeyError(f"Discriminator value '{kind}' is not registered.")
        else:
            return None
        
        return _tp_cls
        # return globals()[_tp_cls.__name__]
    
    # def __new__(cls, *args, **kwargs):
    #     if ('type' in kwargs):
    #         _tp = kwargs['type']
    #         if (_tp in cls._registry):
    #             _tp_cls = cls._registry[_tp]
    #         elif (Literal[_tp] in cls._registry):
    #             _tp_cls = cls._registry[Literal[_tp]]
    #         else:
    #             raise ValueError(f"Unknown discriminator value '{_tp}'.")
    #         
    #         return super(Discriminating, cls).__new__(_tp_cls)
    #     
    #     else:
    #         return super(Discriminating, cls).__new__(cls)
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super()._update_attrs(config, attrs)
        attrs['type'] = config.get_string('type')
    
    @classmethod
    def parse_config(cls, config: ConfigTree) -> Self:
        impl_cls = cls._from_registry(config.get_string('type'))
        attrs = dict()
        impl_cls._update_attrs(config, attrs)
        return impl_cls(**attrs)


def init_respecting_none[T](cls: Type[T], arg: Any | None) -> T | None:
    return cls(arg) if (arg is not None) else None


__all__ = \
[
    'ConfigABC',
    'Discriminating',
    
    'dataclass_config',
    'init_respecting_none',
]
