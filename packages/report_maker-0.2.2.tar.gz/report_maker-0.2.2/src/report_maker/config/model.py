from __future__ import annotations

from copy import deepcopy
from dataclasses import field
from pathlib import Path
from typing import *

from pyhocon import ConfigFactory, ConfigTree

from .abstract import *
from .abstract import WithOverrides
from .meta import dataclass_config


ComposerTypeMarkdownStringLiteral = Literal['markdown']
ComposerTypeSourceCodeStringLiteral = Literal['source-code']
ComposerTypeDocumentStringLiteral = Literal['document']
ComposerTypeFromTemplateStringLiteral = Literal['from-template']
ComposerTypeTemplateStringLiteral = Literal['template']
ComposerTypeLicenseStringLiteral = Literal['license']
ComposerTypeAppendixStringLiteral = Literal['appendix']

type ComposerTypeStringLiteral = Union \
[
    ComposerTypeMarkdownStringLiteral,
    ComposerTypeSourceCodeStringLiteral,
    ComposerTypeDocumentStringLiteral,
    ComposerTypeFromTemplateStringLiteral,
    ComposerTypeTemplateStringLiteral,
    ComposerTypeLicenseStringLiteral,
    ComposerTypeAppendixStringLiteral,
]

@dataclass_config
class ComposerPartTypeDocument(BaseComposerPart[ComposerTypeDocumentStringLiteral]):
    type: ComposerTypeDocumentStringLiteral = 'document'
    document_path: Path
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeDocument, cls)._update_attrs(config, attrs)
        attrs['document_path'] = Path(config.get_string('document_path'))

@dataclass_config
class ComposerPartTypeFromTemplate(BaseComposerPart[ComposerTypeTemplateStringLiteral]):
    type: ComposerTypeFromTemplateStringLiteral = 'from-template'
    document_path: Path
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeFromTemplate, cls)._update_attrs(config, attrs)
        attrs['document_path'] = Path(config.get_string('document_path'))

@dataclass_config
class ComposerPartTypeTemplate(BaseComposerPart[ComposerTypeTemplateStringLiteral]):
    type: ComposerTypeTemplateStringLiteral = 'template'
    template: Path
    attributes: ConfigTree
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeTemplate, cls)._update_attrs(config, attrs)
        attrs['template'] = Path(config.get_string('template'))
        attrs['attributes'] = config.get_config('attributes', ConfigTree())


@dataclass_config
class ComposerPartTypeMarkdown(BaseComposerPart[ComposerTypeMarkdownStringLiteral]):
    type: ComposerTypeMarkdownStringLiteral = 'markdown'
    
    discover: bool
    root: Path
    files: List[DiscoveringFile] = None
    patterns: List[str] = field(default_factory=lambda: [ '*.md', '*.markdown' ])
    
    def __post_init__(self):
        assert not ((self.files is None) and self.discover), "At most one of 'files' and 'discover' must be specified."
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeMarkdown, cls)._update_attrs(config, attrs)
        attrs['discover'] = config.get_bool('discover')
        attrs['root'] = Path(config.get_string('root'))
        _files: List[ConfigTree] = config.get_list('files', None)
        if (_files is not None):
            attrs['files'] = [ DiscoveringFile.parse_config(f) for f in _files ]
        if ('patterns' in config):
            attrs['patterns'] = config.get_string('patterns')


@dataclass_config
class ComposerPartTypeSourceCode(BaseComposerPart[ComposerTypeSourceCodeStringLiteral]):
    type: ComposerTypeSourceCodeStringLiteral = 'source-code'
    style_profile: str = 'default'
    
    discover: bool
    root: Path
    files: List[DiscoveringFile] = None
    patterns: List[str] = field(default_factory=lambda: [ '*.py', '*.pyi' ])
    split_code_blocks: bool = True
    
    def __post_init__(self):
        assert not ((self.files is not None) and self.discover), "At most one of 'files' and 'discover' must be specified."
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeSourceCode, cls)._update_attrs(config, attrs)
        attrs['discover'] = config.get_bool('discover')
        attrs['root'] = Path(config.get_string('root'))
        _files: List[ConfigTree] = config.get_list('files', None)
        if (_files is not None):
            attrs['files'] = [DiscoveringFile.parse_config(f) for f in _files]
        if ('patterns' in config):
            attrs['patterns'] = config.get_list('patterns')


@dataclass_config
class ComposerPartTypeLicense(BaseComposerPart[ComposerTypeLicenseStringLiteral]):
    type: ComposerTypeLicenseStringLiteral = 'license'
    license_kind: Literal['custom', 'built-in'] = 'built-in'
    license_id: str = None
    license_name: str = None
    license_file: Path = None
    
    font_size_override: float = None
    options: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        match (self.license_kind):
            case 'custom':
                assert self.license_name is not None, "Custom license must have license name."
                assert self.license_file is not None, "Custom license must have license file."
            case 'built-in':
                assert self.license_id is not None, "Built-in license must have license id."
            case _:
                raise ValueError(f"Unknown license kind: {self.license_kind!r}")
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeLicense, cls)._update_attrs(config, attrs)
        attrs['license_kind'] = config.get_string('license_kind', 'builtin')
        attrs['license_id'] = config.get_string('license_id', None)
        attrs['license_name'] = config.get_string('license_name', None)
        attrs['license_file'] = init_respecting_none(Path, config.get_string('license_file', None))
        attrs['font_size_override'] = config.get_float('font_size_override', None)
        attrs['options'] = config.get_config('options', dict())

@dataclass_config
class ComposerPartTypeAppendix(BaseComposerPart[ComposerTypeAppendixStringLiteral]):
    type: ComposerTypeAppendixStringLiteral = 'appendix'
    appendix: BaseComposerPart
    numbered: bool = True
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerPartTypeAppendix, cls)._update_attrs(config, attrs)
        appendix_config: ConfigTree = deepcopy(config.get_config('appendix'))
        appendix_config.setdefault('name', f'{attrs['name']}.{appendix_config.type}')
        attrs['appendix'] = BaseComposerPart.parse_config(appendix_config)
        attrs['numbered'] = config.get_bool('numbered', True)

@dataclass_config
class ComposerConfig(WithOverrides):
    template: str
    
    build_dir: Path = Path('build')
    target: Path = Path('report.docx')
    
    parts: List[BaseComposerPart]
    
    @classmethod
    def parse_file(cls, file: str | Path) -> Self:
        return cls.parse_config(ConfigFactory.parse_file(str(file)).composer)
    
    @classmethod
    def _update_attrs(cls, config: ConfigTree, attrs: Dict[str, Any]):
        super(ComposerConfig, cls)._update_attrs(config, attrs)
        attrs['template'] = config.get_string('template')
        attrs['build_dir'] = Path(config.get_string('build_dir', 'build'))
        attrs['target'] = Path(config.get_string('target', 'report.docx'))
        attrs['parts'] = [ BaseComposerPart.parse_config(p) for p in config.get_list('parts') ]


def init_respecting_none[T](cls: Type[T], arg: Any | None) -> T | None:
    return cls(arg) if (arg is not None) else None

# def recursive_config[C](cls: Type[C], config: ConfigTree) -> C:
#     assert dataclasses.is_dataclass(cls)
#     kwargs = dict()
#     for field in dataclasses.fields(cls):
#         match (field.type):
#             case T if issubclass(T, (Path, str)):
#                 v = config.get_string(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, bool):
#                 v = config.get_bool(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, float):
#                 v = config.get_float(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, int):
#                 v = config.get_int(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             case T if issubclass(T, Mapping):
#                 v = config.get_list(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
#             
#             case T if issubclass(T, Sequence):
#                 v = config.get_list(field.name, field.default)
#                 assert v is not dataclasses.MISSING, f"Missing required field '{field.name}'."
#                 value = init_respecting_none(T, v)
# 
#     return cls(**kwargs)


__all__ = \
[
    'ComposerConfig',
    'ComposerPartTypeAppendix',
    'ComposerPartTypeDocument',
    'ComposerPartTypeFromTemplate',
    'ComposerPartTypeLicense',
    'ComposerPartTypeMarkdown',
    'ComposerPartTypeSourceCode',
    'ComposerPartTypeTemplate',
    'ComposerTypeAppendixStringLiteral',
    'ComposerTypeDocumentStringLiteral',
    'ComposerTypeFromTemplateStringLiteral',
    'ComposerTypeLicenseStringLiteral',
    'ComposerTypeMarkdownStringLiteral',
    'ComposerTypeSourceCodeStringLiteral',
    'ComposerTypeStringLiteral',
]
