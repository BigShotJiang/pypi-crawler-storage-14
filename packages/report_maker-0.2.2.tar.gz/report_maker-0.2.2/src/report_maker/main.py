import logging
from argparse import Namespace, ArgumentParser
from pathlib import Path
from typing import *

import report_maker as info

LogLevel = Literal['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']

def init_logging(level: int | LogLevel = logging.INFO):
    logging.basicConfig(level=level)
    logging.root.setLevel(level)
    logging.root.info("Logger initialized...")

class CommandLineArgs(Namespace):
    config: Path
    log_level: LogLevel
    
    @classmethod
    def get_parser(cls) -> ArgumentParser:
        parser = ArgumentParser(prog=info.__title__, usage='report-maker [OPTIONS]', description=info.__doc__, epilog=f"Report Maker v{info.__version__} by {info.__author__} ({info.__copyright__})")
        
        options = parser.add_argument_group("Options")
        options.add_argument('--config', '-c', type=Path, default='report-composer.conf', help="Path to the configuration file")
        options.add_argument('--log-level', '-l', choices=get_args(LogLevel), default=logging.getLevelName(logging.INFO), help="Logging level for the app")
        
        return parser
    
    @classmethod
    def parse_args(cls, args = None) -> Self:
        parser = cls.get_parser()
        self = cls()
        return parser.parse_args(args=args, namespace=self)

def _run(args: CommandLineArgs):
    from .composer import compose
    from .config import ComposerConfig
    from .utils import docx_extras
    
    init_logging(args.log_level)
    docx_extras.register()
    config = ComposerConfig.parse_file(args.config)
    compose(config)
    
    return 0

def main(args: CommandLineArgs = None):
    if (args is None):
        args = CommandLineArgs.parse_args()
    
    return _run(args)

__all__ = \
[
    'CommandLineArgs',
    
    'init_logging',
    'main',
]


if (__name__ == '__main__'):
    exit_code = main()
    exit(exit_code)
