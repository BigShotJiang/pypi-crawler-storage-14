"""
Report maker tool.
Used to convert Markdown documents into a single .docx report with proper formatting.
Automatically inserts source code as a document appendix.
"""

from collections import namedtuple

__title__ = 'report-maker'
__author__ = 'Peter Zaitcev'
__license__ = 'BSD 2-clause license'
__copyright__ = 'Copyright 2025 Peter Zaitcev'
__version__ = '0.2.2'

VersionInfo = namedtuple('VersionInfo', 'major minor micro releaselevel serial')
version_info = VersionInfo(*map(int, __version__.split('.')), releaselevel='alpha', serial=0)

__all__ = \
[
    'VersionInfo',
    'version_info',
    '__title__',
    '__author__',
    '__license__',
    '__copyright__',
    '__version__',
]

__pdoc__ = \
{
    '__title__': """ The name of this Python package. """,
    '__author__': """ The author of this Python package. """,
    '__license__': """ Name of the license this package is distributed under. """,
    '__copyright__': """ The copyright line for this Python package. """,
    '__version__': """ Current version of this Python package. """,
    'VersionInfo': False,
    'VersionInfo.major': """ The major (first) version number. """,
    'VersionInfo.minor': """ The minor (second) version number. """,
    'VersionInfo.micro': """ The micro (third) version number; also known as patch version. """,
    'VersionInfo.releaselevel': """ `str`. The release level for the project. Mostly ignored. """,
    'VersionInfo.serial': """ `int`. The serial number for the dev builds. Mostly ignored. """,
    'version_info': False,
}
