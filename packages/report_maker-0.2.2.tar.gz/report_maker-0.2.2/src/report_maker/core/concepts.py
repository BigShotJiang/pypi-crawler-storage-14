from typing import *

StyleName = NewType('StyleName', str)
# """ A `NewType` for storing Word style names (like Normal, Heading, etc.). """

FontName = NewType('FontName', str)
# """ A `NewType` for storing font family names (like Times New Roman, Calibri, etc.). """


__all__ = \
[
    'StyleName',
    'FontName',
]
