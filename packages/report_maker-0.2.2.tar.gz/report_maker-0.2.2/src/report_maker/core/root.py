import contextlib
import itertools
from functools import wraps
from typing import *

from docx.document import Document

from .converter_base import *
from .meta import Meta, MetaCounters


class RootProcessor(ConverterBase):
    top_level_extensions: Tuple[Type[ConverterInterface], ...]
    
    def __init__ \
    (
        self,
        doc: Document,
        global_config: GlobalConfig,
        *extensions: Type[ConverterInterface],
        counters: MetaCounters = None,
    ) -> None:
        self.top_level_extensions = extensions
        
        super().__init__ \
        (
            doc = doc,
            global_config= global_config,
            meta = Meta(counters=counters),
        )
    
    def validate_config(self):
        pass
    def declare_extensions(self):
        self.meta.extensions.Root = self
        for ext in self.top_level_extensions:
            self.declare_extension(ext)
    def declare_tasks(self):
        pass
    def declare_styles(self):
        pass
    def define_styles(self):
        pass
    
    @contextlib.contextmanager
    def enter_stage(self, stage_name: str):
        self.logger.info(f"STAGE: {stage_name}: Entering...")
        try:
            yield
        except Exception as e:
            self.logger.exception(f"STAGE: {stage_name}: FAILED: {e}")
            raise e
        else:
            self.logger.info(f"STAGE: {stage_name}: Done")
    
    @staticmethod
    def stage[F: Callable](stage_name: Optional[str] = None) -> Callable[[F], F]:
        def decorator(func: F) -> F:
            nonlocal stage_name
            if (stage_name is None):
                stage_name = func.__name__
                if (stage_name.startswith('stage_')):
                    stage_name = stage_name[6:]
                stage_name = stage_name.title()
            
            @wraps(func)
            def wrapper(self: Self, *args, **kwargs):
                with self.enter_stage(func.__name__):
                    return func(self, *args, **kwargs)
            
            return wrapper
        
        if (callable(stage_name)):
            return decorator(stage_name)
        else:
            return decorator
    
    @stage
    def stage_init(self):
        initialized: Set[Type[ConverterInterface]] = set()
        for i in itertools.count(1):
            extensions = list(self.meta.extensions.values())
            not_initialized: List[ConverterInterface] = [ext for ext in extensions if (ext.__class__ not in initialized)]
            if (not not_initialized):
                break
            
            self.logger.info(f"Validating configuration, pass #{i}...")
            for ext in not_initialized:
                ext.validate_config()
            self.logger.info(f"Declaring extensions, pass #{i}...")
            for ext in not_initialized:
                ext.declare_extensions()
            
            initialized.update(ext.__class__ for ext in not_initialized)
    
    @stage
    def stage_declare(self):
        self.logger.info("Declaring tasks...")
        for ext_cls in self.top_level_extensions:
            ext = self.meta.extensions[ext_cls]
            ext.declare_tasks()
        self.logger.info("Declaring document styles...")
        for ext in self.meta.extensions.values():
            ext.declare_styles()
    
    @stage
    def stage_define(self):
        self.logger.info("Defining document styles...")
        for ext in self.meta.extensions.values():
            ext.define_styles()
    
    @stage
    def stage_process(self):
        # Only process extensions explicitly declared.
        for ext in self.top_level_extensions:
            self.meta.extensions[ext].run()
    
    def run(self) -> Document:
        self.declare_extensions()
        
        self.stage_init()
        self.stage_declare()
        self.stage_define()
        self.stage_process()
        return self.doc


__all__ = \
[
    'RootProcessor',
]
