import itertools
from argparse import Namespace
from dataclasses import dataclass
from typing import *

from report_maker.core.converter_base import ConverterInterface
from report_maker.core.root import RootProcessor as _Root
from report_maker.extensions.builtin.code_converter import CodeConverter as _CodeConverter
from report_maker.extensions.builtin.hyperlinks_processor import HyperlinksProcessor as _HyperlinksProcessor
from report_maker.extensions.builtin.md_converter import MarkdownConverter as _MarkdownConverter
from report_maker.extensions.builtin.styles import SharedStyles as _SharedStyles


class Extensions[C: ConverterInterface](Namespace, Mapping[Type[C], C]):
    SharedStyles: _SharedStyles
    CodeConverter: _CodeConverter
    HyperlinksProcessor: _HyperlinksProcessor
    MarkdownConverter: _MarkdownConverter
    Root: _Root
    
    def __init__(self) -> None:
        super().__init__()
        self.__instances__ = dict()
    
    def __setitem__(self, key: Type[C], value: C, /) -> None: ...    
    def __getitem__(self, key: Type[C], /) -> ConverterInterface: ...
    def __iter__(self) -> Iterator[ConverterInterface]: ...
    def __len__(self) -> int: ...

class MetaCounters(Namespace):
    appendix_counter: itertools.count
    images_counter: itertools.count

@dataclass(kw_only=True)
class AppendixMeta:
    is_appendix: bool = False
    is_numbered: bool = True

class Meta(Namespace):
    extensions: Extensions
    counters: MetaCounters
    
    appendix_meta: AppendixMeta
    
    def __init__(self, *, counters: MetaCounters = None) -> None: ...


__all__ = \
[
    'AppendixMeta',
    'Meta',
    'MetaCounters',
]
