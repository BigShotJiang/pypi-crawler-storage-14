from __future__ import annotations

import functools
import importlib.resources
import re
import typing
from copy import deepcopy
from functools import cached_property
from pathlib import Path

from pyhocon import ConfigFactory

import report_maker as root_package
from report_maker.utils import docx_extras


if typing.TYPE_CHECKING:
    from docx.document import Document
    from pyhocon import ConfigTree
    from report_maker.config.meta import IdentityFunction
    from typing import *



def pythonize_name(name: str) -> str:
    return re.sub(r'\W+', '_', name).lower()

@typing.overload
def deepcopy_lru_cache(*, maxsize: int | None = 128, typed: bool = False) -> IdentityFunction:
    pass

@typing.overload
def deepcopy_lru_cache[C: Callable](func: C, /) -> C:
    pass

def deepcopy_lru_cache[C: Callable](_f: C = None, /, *lru_args, **lru_kwargs):
    """ A wrapper over `functools.lru_cache` that always returns a deep copy of the result. """
    
    def decorator(func: C) -> C:
        func = functools.lru_cache(*lru_args, **lru_kwargs)(func)
        @functools.wraps(func)
        def wrapper(*func_args, **func_kwargs):
            result = func(*func_args, **func_kwargs)
            return deepcopy(result)
        return wrapper
    
    if (_f is None):
        return decorator
    else:
        return decorator(_f)


class TemplateLoader:
    __match_args__: ClassVar[Tuple[str, ...]] = ('template_name', )
    
    template_name: Final[str]
    
    def __init__(self, template_name: str):
        self.template_name = template_name
    
    def __eq__(self, other: 'TemplateLoader | Any') -> bool:
        match (other):
            case TemplateLoader(template_name):
                return template_name == self.template_name
            case _:
                return NotImplemented
    
    def __hash__(self) -> int:
        return hash((type(self), self.template_name))
    
    @cached_property
    def template_root(self) -> Path:
        parts = \
        [
            root_package.__package__,
            'templates',
            pythonize_name(self.template_name),
        ]
        return Path(str(importlib.resources.files('.'.join(parts))))
    
    @cached_property
    def template_documents(self) -> Path:
        return self.template_root / 'documents'
    
    @cached_property
    def template_configs(self) -> Path:
        return self.template_root / 'configs'
    
    def load_document(self, document_name: str | Path) -> Document:
        return docx_extras.document_open(self.template_documents / document_name)
    def load_main_template(self) -> Document:
        return docx_extras.document_clear(self.load_document('master-template.docx'))
    
    @deepcopy_lru_cache()
    def load_config(self, config_name: str | Path) -> ConfigTree:
        return ConfigFactory.parse_file(self.template_configs / config_name)
    def load_main_config(self) -> ConfigTree:
        return self.load_config(f'{self.template_name}.conf')


__all__ = \
[
    'TemplateLoader',
    'pythonize_name',
]
