from abc import ABC, abstractmethod
from pathlib import Path
from typing import *

from report_maker.config import DiscoveringFile


class DiscoveringConfigProtocol(Protocol):
    discover: bool
    root: Path
    files: List[DiscoveringFile]
    patterns: List[str]


class FileDiscovering[C: DiscoveringConfigProtocol, R: Hashable](ABC):
    """ Interface which implements file discovery logic used by `MarkdownConverter` and `CodeConverter` """
    
    @abstractmethod
    def make_task(self, file: Path, df: DiscoveringFile | None = None) -> R:
        ...
    
    def discover_files(self, config: C) -> List[R]:
        result = list()
        
        if (config.discover):
            for pat in config.patterns:
                result.extend(self.make_task(f) for f in config.root.rglob(pat))
            result = list(set(result))
            result.sort()
        
        else:
            for df in config.files:
                if (df.glob):
                    result.extend(self.make_task(f, df) for f in config.root.glob(df.glob))
                else:
                    result.append(self.make_task(config.root / df.file, df))
        
        return result

class SimpleFileDiscovering[C: DiscoveringConfigProtocol](FileDiscovering[C, Path]):
    """ Minimalistic implementation of `FileDiscovering` which respects path and discards other metadata. """
    
    def make_task(self, file: Path, df: DiscoveringFile | None = None) -> Path:
        return file


__all__ = \
[
    'DiscoveringConfigProtocol',
    'FileDiscovering',
    'SimpleFileDiscovering',
]
