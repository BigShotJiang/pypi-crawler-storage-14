from __future__ import annotations

import itertools
from argparse import Namespace
from dataclasses import dataclass
from typing import *

if (TYPE_CHECKING):
    from .converter_base import ConverterInterface
    C = TypeVar('C', bound=ConverterInterface)
else:
    C = TypeVar('C')

class Extensions[C: ConverterInterface](Namespace, Mapping[Type[C], C]):
    __instances__: Dict[Type[C], C]
    
    def __init__(self) -> None:
        super().__init__()
        self.__instances__ = dict()
    
    def __contains__(self, item: Type[C]) -> bool:
        return item in self.__instances__
    
    def __setitem__(self, key: Type[C], value: C, /) -> None:
        assert key not in self.__instances__, "Cannot redeclare extension."
        self.__instances__.__setitem__(key, value)
        setattr(self, key.__name__, value)
    
    def __getitem__(self, key: Type[C] | C, /) -> ConverterInterface:
        if (not isinstance(key, type)):
            key = type(key)
        return self.__instances__[key]
    
    def __iter__(self) -> Iterator[ConverterInterface]:
        return iter(self.__instances__.values())
    
    def __len__(self) -> int:
        return len(self.__instances__)

class MetaCounters(Namespace):
    def __getattr__(self, name: str) -> itertools.count:
        counter = itertools.count(1)
        setattr(self, name, counter)
        return counter

@dataclass(kw_only=True)
class AppendixMeta:
    is_appendix: bool = False
    is_numbered: bool = True

class Meta(Namespace):
    extensions: Extensions
    counters: MetaCounters
    
    appendix_meta: AppendixMeta
    
    def __init__(self, *, counters: MetaCounters = None) -> None:
        super().__init__()
        self.extensions = Extensions()
        self.counters = counters or MetaCounters()
        self.appendix_meta = AppendixMeta()


__all__ = \
[
    'AppendixMeta',
    'Meta',
    'MetaCounters',
]
