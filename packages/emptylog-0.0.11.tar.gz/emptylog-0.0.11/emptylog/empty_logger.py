from emptylog.abstract_logger import AbstractLogger


class EmptyLogger(AbstractLogger):
    pass
