# Utility functions
