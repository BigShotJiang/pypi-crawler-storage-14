# Make cli a standard Python package
