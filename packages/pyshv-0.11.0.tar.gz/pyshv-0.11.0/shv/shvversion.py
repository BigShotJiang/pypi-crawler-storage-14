"""Constants declaring SHV standard version this library implements."""

SHV_VERSION_MAJOR = 3
SHV_VERSION_MINOR = 0
SHV_VERSION = (SHV_VERSION_MAJOR, SHV_VERSION_MINOR)
