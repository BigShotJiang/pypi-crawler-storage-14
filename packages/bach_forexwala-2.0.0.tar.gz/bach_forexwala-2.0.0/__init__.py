"""MCP Server for Forexwala"""
