use std::sync::Arc;
use std::{collections::HashMap, sync::Mutex};

use once_cell::sync::Lazy;
use probing_proto::prelude::{Ele, TimeSeries};
use probing_proto::types::series::DiscardStrategy;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyType};
use pyo3::{pyclass, pymethods, Bound, PyObject, PyResult, Python};

use crate::features::convert::{ele_to_python, python_to_ele};

fn value_to_object(py: Python, v: &probing_proto::prelude::Ele) -> PyObject {
    ele_to_python(py, v).unwrap_or_else(|_| py.None())
}

#[pyclass]
pub struct PyExternalTableConfig {
    #[pyo3(get)]
    chunk_size: usize,
    #[pyo3(get)]
    discard_threshold: usize,
    #[pyo3(get)]
    discard_strategy: String,
}

impl Default for PyExternalTableConfig {
    fn default() -> Self {
        PyExternalTableConfig {
            chunk_size: 10000,
            discard_threshold: 20_000_000,
            discard_strategy: "BaseMemorySize".to_string(),
        }
    }
}

impl FromPyObject<'_> for PyExternalTableConfig {
    fn extract_bound(ob: &Bound<'_, PyAny>) -> PyResult<Self> {
        let chunk_size: usize = ob.get_item("chunk_size")?.extract()?;
        let discard_threshold: usize = ob.get_item("discard_threshold")?.extract()?;
        let discard_strategy: String = ob
            .get_item("discard_strategy")
            .map_or(Ok("None".to_string()), |v| v.extract())?;
        Ok(PyExternalTableConfig {
            chunk_size,
            discard_threshold,
            discard_strategy,
        })
    }
}

impl From<PyExternalTableConfig> for DiscardStrategy {
    fn from(py_config: PyExternalTableConfig) -> Self {
        match py_config.discard_strategy.as_str() {
            "BaseElementCount" => DiscardStrategy::BaseElementCount {
                discard_threshold: py_config.discard_threshold,
                chunk_size: py_config.chunk_size,
            },
            "BaseMemorySize" => DiscardStrategy::BaseMemorySize {
                discard_threshold: py_config.discard_threshold,
                chunk_size: py_config.chunk_size,
            },
            _ => DiscardStrategy::None,
        }
    }
}

#[pymethods]
impl PyExternalTableConfig {
    #[new]
    fn new(chunk_size: usize, discard_threshold: usize, discard_strategy: String) -> Self {
        PyExternalTableConfig {
            chunk_size,
            discard_threshold,
            discard_strategy,
        }
    }

    fn into_py(&self, py: Python<'_>) -> PyObject {
        let dict = PyDict::new(py);
        dict.set_item("chunk_size", &self.chunk_size).unwrap();
        dict.set_item("discard_threshold", self.discard_threshold)
            .unwrap();
        dict.set_item("discard_strategy", &self.discard_strategy)
            .unwrap();
        dict.into()
    }
}

pub static EXTERN_TABLES: Lazy<Mutex<HashMap<String, Arc<Mutex<TimeSeries>>>>> =
    Lazy::new(|| Mutex::new(Default::default()));

#[pyclass]
#[derive(Clone, Debug)]
pub struct ExternalTable(Arc<Mutex<TimeSeries>>, usize);

#[pymethods]
impl ExternalTable {
    #[new]
    #[pyo3(signature = (name, columns, chunk_size = 10000, discard_threshold = 20_000_000, discard_strategy = "BaseMemorySize".to_string()))]
    fn new(
        name: &str,
        columns: Vec<String>,
        chunk_size: usize,
        discard_threshold: usize,
        discard_strategy: String,
    ) -> Self {
        let ncolumn = columns.len();
        let config = PyExternalTableConfig {
            chunk_size,
            discard_threshold,
            discard_strategy,
        };
        let config: DiscardStrategy = config.into();
        let ts = Arc::new(Mutex::new(
            TimeSeries::builder_with_config(config)
                .with_columns(columns)
                .build(),
        ));
        EXTERN_TABLES
            .lock()
            .unwrap()
            .insert(name.to_string(), ts.clone());
        ExternalTable(ts, ncolumn)
    }

    #[classmethod]
    fn get(_cls: &Bound<'_, PyType>, name: &str) -> PyResult<ExternalTable> {
        let binding = EXTERN_TABLES.lock().unwrap();
        let ts = binding.get(name);
        if let Some(ts) = ts {
            let ncolumn = ts.lock().unwrap().cols.len();
            Ok(ExternalTable(ts.clone(), ncolumn))
        } else {
            Err(pyo3::exceptions::PyValueError::new_err(format!(
                "table {name} not found"
            )))
        }
    }

    #[classmethod]
    #[pyo3(signature = (name, columns, chunk_size = 10000, discard_threshold = 20_000_000, discard_strategy = "BaseMemorySize".to_string()))]
    fn get_or_create(
        _cls: &Bound<'_, PyType>,
        name: &str,
        columns: Vec<String>,
        chunk_size: usize,
        discard_threshold: usize,
        discard_strategy: String,
    ) -> PyResult<ExternalTable> {
        let mut binding = EXTERN_TABLES.lock().unwrap();
        let ts = binding.get(name);
        if let Some(ts) = ts {
            let ncolumn = ts.lock().unwrap().cols.len();
            Ok(ExternalTable(ts.clone(), ncolumn))
        } else {
            let ncolumn = columns.len();
            let config = PyExternalTableConfig {
                chunk_size,
                discard_threshold,
                discard_strategy,
            };
            let config: DiscardStrategy = config.into();
            let ts = Arc::new(Mutex::new(
                TimeSeries::builder_with_config(config)
                    .with_columns(columns)
                    .build(),
            ));
            binding.insert(name.to_string(), ts.clone());
            Ok(ExternalTable(ts, ncolumn))
        }
    }

    #[classmethod]
    fn drop(_cls: &Bound<'_, PyType>, name: &str) -> PyResult<()> {
        let _ = EXTERN_TABLES.lock().unwrap().remove(name);
        Ok(())
    }

    fn names(&self) -> Vec<String> {
        self.0.lock().unwrap().names.clone()
    }

    fn append(&mut self, values: Vec<PyObject>) -> PyResult<()> {
        if values.len() != self.1 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "column count mismatch",
            ));
        }
        let t = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_micros() as i64;
        let values: Vec<Ele> = Python::with_gil(|py| {
            values
                .into_iter()
                .map(|v| {
                    let bound = v.bind(py);
                    python_to_ele(&bound).unwrap_or(Ele::Nil)
                })
                .collect()
        });
        match self.0.lock().unwrap().append(t.into(), values) {
            Ok(_) => Ok(()),
            Err(e) => Err(pyo3::exceptions::PyValueError::new_err(e.to_string())),
        }
    }

    fn append_ts(&mut self, t: i64, values: Vec<PyObject>) -> PyResult<()> {
        if values.len() != self.1 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "column count mismatch",
            ));
        }
        let values: Vec<Ele> = Python::with_gil(|py| {
            values
                .into_iter()
                .map(|v| {
                    let bound = v.bind(py);
                    python_to_ele(&bound).unwrap_or(Ele::Nil)
                })
                .collect()
        });
        let _ = self.0.lock().unwrap().append(t.into(), values);
        Ok(())
    }

    #[pyo3(signature = (limit=None))]
    fn take(&self, limit: Option<usize>) -> PyResult<Vec<(PyObject, Vec<PyObject>)>> {
        let result: Vec<(PyObject, Vec<PyObject>)> = self
            .0
            .lock()
            .unwrap()
            .take(limit)
            .iter()
            .map(|(t, vals)| {
                Python::with_gil(|py| {
                    let t = value_to_object(py, t);
                    let vals = vals
                        .iter()
                        .map(|v| value_to_object(py, v))
                        .collect::<Vec<_>>();
                    (t, vals)
                })
            })
            .collect();
        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::extensions::python::PythonPlugin;
    use probing_cc::extensions::envs::EnvPlugin;
    use probing_cc::extensions::files::FilesPlugin;
    use probing_core::core::Engine;
    use pyo3::ffi::c_str;

    fn setup() {
        // Module registration is now handled automatically via _core module
        // In test environment, we need to manually set up the probing module
        // since _core may not be importable as a Python module
        pyo3::prepare_freethreaded_python();
        Python::with_gil(|py| {
            use pyo3::types::PyModule;
            use pyo3::PyTypeInfo;

            // Get or create probing module
            let sys = PyModule::import(py, "sys").unwrap();
            let modules = sys.getattr("modules").unwrap();

            let probing = if modules.contains("probing").unwrap_or(false) {
                PyModule::import(py, "probing").unwrap()
            } else {
                let m = PyModule::new(py, "probing").unwrap();
                modules.set_item("probing", &m).unwrap();
                m
            };

            // Manually add ExternalTable to probing module for tests
            // This mimics what _core module does
            if !probing.hasattr("ExternalTable").unwrap_or(false) {
                probing
                    .setattr("ExternalTable", ExternalTable::type_object(py))
                    .unwrap();
            }
        });
    }

    fn setup_table3() {
        setup();
        Python::with_gil(|py| {
            py.run(
                c_str!(
                    r#"
import probing
table3 = probing.ExternalTable.get_or_create("table3", ["a", "b"])
table3.append([1, 2])
table3.append([3, 4])
table3.append([5, 6])
                "#
                ),
                None,
                None,
            )
            .unwrap();
        });
    }

    #[test]
    fn test_create_new_table() {
        setup();
        let table = ExternalTable::new(
            "table1",
            vec!["a".to_string(), "b".to_string()],
            10000,
            20000000,
            "BaseMemorySize".to_string(),
        );
        assert_eq!(table.names(), vec!["a", "b"]);
    }

    #[test]
    fn test_create_table_in_python() {
        setup();
        Python::with_gil(|py| {
            py.run(
                c_str!(
                    r#"
import probing
table = probing.ExternalTable.get_or_create("table2", ["a", "b"])
"#
                ),
                None,
                None,
            )
            .unwrap();
            let binding = EXTERN_TABLES.lock().unwrap();
            let table1 = binding.get("table2");
            assert!(table1.is_some());
        });
    }

    #[test]
    fn test_drop_table_in_python() {
        setup();
        Python::with_gil(|py| {
            // Create the table first
            py.run(
                c_str!(
                    r#"
import probing
probing.ExternalTable.get_or_create("table2", ["a", "b"])
                    "#
                ),
                None,
                None,
            )
            .unwrap();

            // Now drop it
            py.run(
                c_str!(
                    r#"
import probing
probing.ExternalTable.drop("table2")
                    "#
                ),
                None,
                None,
            )
            .unwrap();
            let binding = EXTERN_TABLES.lock().unwrap();
            let table1 = binding.get("table2");
            assert!(table1.is_none());
        });
    }

    #[test]
    fn test_see_py_table_in_engine() {
        setup_table3();
        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(4)
            .enable_all()
            .build()
            .unwrap();
        let engine = rt
            .block_on(async {
                Engine::builder()
                    .with_default_namespace("probe")
                    .with_plugin(PythonPlugin::create("python"))
                    .build()
                    .await
            })
            .unwrap();
        let tables = rt.block_on(async {
            engine
                .async_query(
                    "select * from probe.information_schema.tables where table_name = 'table3' ",
                )
                .await
                .unwrap()
        });
        // Query may return None if no tables found
        let df = tables.expect("Table 'table3' should be found in information_schema.tables");
        assert!(!df.cols.is_empty(), "Should have at least one column");
        // Check if we have any rows - DataFrame.len() returns number of rows
        assert!(
            df.len() > 0,
            "Table 'table3' should be found in information_schema.tables"
        );
    }

    #[test]
    fn test_see_py_table_data_in_engine() {
        setup_table3();
        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(4)
            .enable_all()
            .build()
            .unwrap();
        let engine = rt
            .block_on(async {
                Engine::builder()
                    .with_default_namespace("probe")
                    .with_plugin(PythonPlugin::create("python"))
                    .build()
                    .await
            })
            .unwrap();
        let tables = rt.block_on(async {
            engine
                .async_query("select * from python.table3 ")
                .await
                .unwrap()
        });
        let df = tables.expect("Table 'table3' should be queryable");
        // DataFrame.len() returns number of rows
        assert_eq!(df.len(), 3, "Should have 3 rows");
    }

    #[test]
    fn test_calculate_in_sql_with_filter() {
        setup_table3();
        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(4)
            .enable_all()
            .build()
            .unwrap();
        let engine = rt
            .block_on(async {
                Engine::builder()
                    .with_default_namespace("probe")
                    .with_plugin(PythonPlugin::create("python"))
                    .build()
                    .await
            })
            .unwrap();
        let tables = rt.block_on(async {
            engine
                .async_query("select a + b as c from python.table3 where a > 1")
                .await
                .unwrap()
        });
        let df = tables.expect("Query should return results");
        // DataFrame.len() returns number of rows
        assert_eq!(df.len(), 2, "Should have 2 rows where a > 1");
    }

    #[test]
    fn test_aggregate_in_sql() {
        setup_table3();
        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(4)
            .enable_all()
            .build()
            .unwrap();
        let engine = rt
            .block_on(async {
                Engine::builder()
                    .with_default_namespace("probe")
                    .with_plugin(PythonPlugin::create("python"))
                    .build()
                    .await
            })
            .unwrap();
        let tables = rt.block_on(async {
            engine
                .async_query("select sum(a), sum(b) from python.table3")
                .await
                .unwrap()
        });
        let df = tables.expect("Aggregation query should return results");
        println!("{df:?}");
        assert!(!df.cols.is_empty(), "Should have aggregation results");
    }
}
