This folder contains a modified version of `https://github.com/Artemis21/ptrace-inject`.
