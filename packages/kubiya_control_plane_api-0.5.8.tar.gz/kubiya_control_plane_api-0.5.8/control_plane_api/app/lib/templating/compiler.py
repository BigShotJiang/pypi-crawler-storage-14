"""
Template compilation logic.

Compiles templates by substituting variables with their values from a context.
"""

import structlog
from typing import Any
from control_plane_api.app.lib.templating.types import (
    TemplateContext,
    TemplateVariableType,
    CompileResult,
)
from control_plane_api.app.lib.templating.engine import TemplateEngine, get_default_engine
from control_plane_api.app.lib.templating.validator import TemplateValidator

logger = structlog.get_logger()


class TemplateCompiler:
    """
    Compiles templates by substituting variables with values from a context.

    The compiler:
    1. Validates the template
    2. Substitutes variables with their values
    3. Returns the compiled string
    """

    def __init__(self, engine: TemplateEngine = None):
        """
        Initialize the compiler with a template engine.

        Args:
            engine: Template engine to use. If None, uses default engine.
        """
        self.engine = engine if engine is not None else get_default_engine()
        self.validator = TemplateValidator(self.engine)

    def compile(self, template: str, context: TemplateContext) -> CompileResult:
        """
        Compile a template by substituting all variables with their values.

        Process:
        1. Parse the template to extract variables
        2. Validate that all variables exist in context
        3. Substitute variables with their values (in reverse order to preserve positions)

        Args:
            template: Template string to compile
            context: Template context with variable values

        Returns:
            CompileResult with compiled string or error
        """
        try:
            # Parse the template
            parse_result = self.engine.parse(template)

            # Check for syntax errors
            if not parse_result.is_valid:
                error_messages = [err.message for err in parse_result.errors]
                error_str = "; ".join(error_messages)
                logger.warning("template_syntax_errors", errors=error_messages)
                return CompileResult(
                    compiled="",
                    success=False,
                    error=f"Template syntax errors: {error_str}"
                )

            # Validate against context
            validation_result = self.validator.validate(template, context)
            if not validation_result.valid:
                error_messages = [err.message for err in validation_result.errors]
                error_str = "; ".join(error_messages)
                logger.warning("template_validation_errors", errors=error_messages)
                return CompileResult(
                    compiled="",
                    success=False,
                    error=f"Template validation errors: {error_str}"
                )

            # Substitute variables (process in reverse order to preserve positions)
            result = template
            for var in sorted(parse_result.variables, key=lambda v: v.start, reverse=True):
                try:
                    # Get the value based on variable type
                    value = self._get_variable_value(var.type, var, context)

                    # Convert to string
                    value_str = str(value) if value is not None else ""

                    # Substitute
                    result = result[:var.start] + value_str + result[var.end:]

                    logger.debug(
                        "variable_substituted",
                        variable_name=var.name,
                        variable_type=var.type.value,
                        has_value=bool(value),
                        value_length=len(value_str)
                    )

                except KeyError as e:
                    # This shouldn't happen if validation passed, but handle it gracefully
                    logger.error(
                        "variable_not_found_during_compilation",
                        variable_name=var.name,
                        error=str(e)
                    )
                    return CompileResult(
                        compiled="",
                        success=False,
                        error=f"Variable '{var.name}' not found in context during compilation"
                    )

            logger.info(
                "template_compiled_successfully",
                original_length=len(template),
                compiled_length=len(result),
                variable_count=len(parse_result.variables)
            )

            return CompileResult(
                compiled=result,
                success=True
            )

        except Exception as e:
            logger.error("template_compilation_failed", error=str(e), exc_info=True)
            return CompileResult(
                compiled="",
                success=False,
                error=f"Compilation failed: {str(e)}"
            )

    def _get_variable_value(
        self,
        var_type: TemplateVariableType,
        var,
        context: TemplateContext
    ) -> Any:
        """
        Get the value for a variable from the context.

        Args:
            var_type: Type of variable
            var: TemplateVariable object
            context: Template context

        Returns:
            Variable value

        Raises:
            KeyError: If variable not found in context
        """
        if var_type == TemplateVariableType.SECRET:
            return context.secrets[var.display_name]
        elif var_type == TemplateVariableType.ENV:
            return context.env_vars[var.display_name]
        else:  # SIMPLE
            return context.variables[var.name]
