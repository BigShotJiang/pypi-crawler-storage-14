# Gage Inspect

Gage interface and extensions for [Inspect AI].

Inspect AI is an open source toolkit for evaluating LLM models and
related tasks. Gage enables Inspect tasks to be run in production.

- Build Inspect AI tasks with developer/programmer oriented tools and
  workflow
- Deploy Inspect AI tasks in production

If you're using Gage for the first time, we recommend reading the [Get
started] guide online.

To use this library, install it using `pip`.

```shell
pip install gage-inspect
```

Here's a simple Inspect task that is run with Gage.

```python
from inspect_ai import task, Task
from inspect_ai.solver import user_prompt, generate

from gage_inspect.task import run_task

@task
def funny():
    return Task(solver=[
        user_prompt(
            "Say something funny about {prompt} in 5 words or less."
        ),
        generate()
    ])

if __name__ == "__main__":
    import sys

    run_task(funny(), sys.argv[0])
```

To run this task on OpenAI, you need the `openai` Python package.

```shell
pip install openai
```

Run the task from the command line. You need to specify the model and
API key as environment variables.

```shell
INSPECT_EVAL_MODEL=openai/gpt-4.1 OPENAI_API_KEY=#### python funny.py birds
```

<!-- Links -->

[Inspect AI]: https://inspect.aisi.org.uk/
[Get started]: https://gage.io/start
