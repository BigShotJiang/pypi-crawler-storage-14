from aicu import *
