"""Retry configuration with tenacity"""

from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log
)
import httpx
import logging

from .exceptions import ServiceUnavailableError


logger = logging.getLogger(__name__)


def get_retry_decorator(max_attempts: int = 3):
    """
    Get configured retry decorator.
    """
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((
            httpx.TimeoutException,
            httpx.NetworkError,
            httpx.ConnectError,
            ServiceUnavailableError
        )),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True
    )
