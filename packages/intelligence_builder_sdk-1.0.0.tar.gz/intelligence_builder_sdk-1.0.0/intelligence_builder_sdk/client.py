"""
Intelligence Builder SDK - Main Client
"""

import json as json_module
import uuid
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

import httpx
from pydantic import BaseModel, Field

from src.utils.http import ensure_json_response

from .auth import AuthenticationManager
from .cache import CacheManager
from .circuit_breaker import CircuitBreakerManager
from .exceptions import AuthenticationError, IntelligenceBuilderError, RateLimitError, ServiceUnavailableError
from .exceptions import ValidationError as SDKValidationError
from .models import (
    DocumentIngestionResponse,
    Entity,
    EntityListResponse,
    GraphNode,
    GraphPath,
    GraphTraversalRequest,
    GraphTraversalResponse,
    HealthCheckResponse,
    PathFindingRequest,
    PathFindingResponse,
    QueryRequest,
    QueryResponse,
    Relationship,
    RelationshipListResponse,
)
from .retry import get_retry_decorator

if TYPE_CHECKING:
    from uuid import UUID


class ClientConfig(BaseModel):
    """Client configuration"""

    base_url: str = Field(
        default="http://intelligence-builder:8100",
        description="Intelligence-Builder base URL",
    )
    api_key: str = Field(..., description="API key for authentication")
    timeout: int = Field(default=30, ge=1, le=300, description="Request timeout (seconds)")
    max_retries: int = Field(default=3, ge=0, le=10, description="Maximum retry attempts")
    cache_ttl: int = Field(default=300, ge=0, description="Cache TTL (seconds)")
    enable_circuit_breaker: bool = Field(default=True, description="Enable circuit breaker")
    circuit_breaker_threshold: int = Field(default=5, ge=1, description="Circuit breaker failure threshold")
    circuit_breaker_timeout: int = Field(default=60, ge=10, description="Circuit breaker timeout (seconds)")
    enable_caching: bool = Field(default=True, description="Enable response caching")
    cache_backend: str = Field(default="memory", description="Cache backend: memory, redis, file")
    redis_url: Optional[str] = Field(None, description="Redis URL (if cache_backend=redis)")
    user_agent: str = Field(default="intelligence-builder-sdk/1.0.0", description="User agent")


class IntelligenceBuilderClient:
    """
    Main client for Intelligence-Builder API.
    """

    def __init__(self, config: ClientConfig):
        """
        Initialize Intelligence Builder client.
        """
        self.config = config
        self._http_client: Optional[httpx.AsyncClient] = None
        self._request_counter = 0
        self._kg_base = "/v1/knowledge"

        # Initialize managers
        self._auth_manager = AuthenticationManager(base_url=config.base_url, api_key=config.api_key)
        self._cache_manager = (
            CacheManager(
                enabled=config.enable_caching,
                ttl=config.cache_ttl,
                backend=config.cache_backend,
                redis_url=config.redis_url,
            )
            if config.enable_caching
            else None
        )

        self._circuit_breaker = (
            CircuitBreakerManager(
                enabled=config.enable_circuit_breaker,
                failure_threshold=config.circuit_breaker_threshold,
                timeout=config.circuit_breaker_timeout,
            )
            if config.enable_circuit_breaker
            else None
        )

        # Request retry decorator
        self._retry = get_retry_decorator(max_attempts=config.max_retries)

    async def __aenter__(self):
        """Async context manager entry"""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.disconnect()
        return False

    async def connect(self):
        """
        Initialize HTTP client and authenticate.
        """
        if self._http_client:
            return

        self._http_client = httpx.AsyncClient(  # nosec B113 - timeout configured below
            base_url=self.config.base_url,
            timeout=httpx.Timeout(self.config.timeout),
            headers={
                "User-Agent": self.config.user_agent,
                "Content-Type": "application/json",
                "X-SDK-Version": "1.0.0",
            },
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100, keepalive_expiry=30.0),
        )

        self._auth_manager.set_http_client(self._http_client)

        await self._auth_manager.ensure_authenticated()

        if self._cache_manager:
            await self._cache_manager.connect()

    async def disconnect(self):
        """Close HTTP client and cleanup resources"""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

        if self._cache_manager:
            await self._cache_manager.disconnect()

        self._auth_manager.clear()

    def _generate_request_id(self) -> str:
        """Generate unique request ID for tracing"""
        self._request_counter += 1
        return f"sdk_{uuid.uuid4().hex[:8]}_{self._request_counter}"

    def _kg_endpoint(self, suffix: str) -> str:
        """Build knowledge graph endpoint paths."""
        if not suffix.startswith("/"):
            suffix = f"/{suffix}"
        return f"{self._kg_base}{suffix}"

    @staticmethod
    def _serialize_payload(payload: Union[BaseModel, Dict[str, Any]]) -> Dict[str, Any]:
        """Normalize BaseModel or dict payloads."""
        if isinstance(payload, BaseModel):
            return payload.model_dump(exclude_none=True)
        return payload

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        use_cache: bool = True,
    ) -> httpx.Response:
        """
        Make HTTP request with authentication, retry, and circuit breaker.
        """
        await self._auth_manager.ensure_authenticated()

        request_id = self._generate_request_id()
        cache_key = None

        cacheable = method.upper() == "GET" or endpoint == "/v1/query"
        if cacheable and use_cache and self._cache_manager:
            cache_payload = json if json is not None else params
            cache_key = self._cache_manager.generate_key(endpoint, cache_payload)
            cached = await self._cache_manager.get(cache_key)
            if cached:
                return httpx.Response(
                    status_code=200,
                    content=json_module.dumps(cached).encode(),
                    headers={
                        "X-Cache": "HIT",
                        "X-Request-ID": request_id,
                        "Content-Type": "application/json",
                    },
                )

        headers = {
            "Authorization": f"Bearer {self._auth_manager.token}",
            "X-Request-ID": request_id,
            "X-API-Key": self.config.api_key,
        }

        @self._retry
        async def _request():
            if self._circuit_breaker:
                return await self._circuit_breaker.call(
                    self._http_client.request,
                    method=method,
                    url=endpoint,
                    json=json,
                    data=data,
                    files=files,
                    params=params,
                    headers=headers,
                )
            else:
                return await self._http_client.request(
                    method=method,
                    url=endpoint,
                    json=json,
                    data=data,
                    files=files,
                    params=params,
                    headers=headers,
                )

        try:
            response = await _request()
            await self._handle_response_errors(response)

            if cacheable and use_cache and self._cache_manager and cache_key and response.is_success:
                await self._cache_manager.set(cache_key, await ensure_json_response(response))

            return response

        except httpx.HTTPStatusError as e:
            await self._handle_response_errors(e.response)
            raise

    async def _handle_response_errors(self, response: httpx.Response):
        """
        Handle HTTP error responses.
        """
        if response.is_success:
            return

        status_code = response.status_code

        try:
            error_data = await ensure_json_response(response)
            error_msg = error_data.get("detail", error_data.get("error", str(error_data)))
        except Exception:
            error_msg = response.text or f"HTTP {status_code}"

        if status_code == 401:
            raise AuthenticationError(f"Authentication failed: {error_msg}")
        elif status_code == 403:
            raise AuthenticationError(f"Access forbidden: {error_msg}")
        elif status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 60))
            raise RateLimitError(message=f"Rate limit exceeded: {error_msg}", retry_after=retry_after)
        elif status_code == 503:
            raise ServiceUnavailableError(f"Service unavailable: {error_msg}")
        elif status_code == 400:
            raise SDKValidationError(f"Invalid request: {error_msg}")
        else:
            raise IntelligenceBuilderError(f"Request failed with status {status_code}: {error_msg}")

    async def query(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
        options: Optional[Dict[str, Any]] = None,
        use_cache: bool = True,
    ) -> QueryResponse:
        """
        Send intelligent query to Intelligence-Builder.
        """
        request = QueryRequest(query=query, context=context or {}, options=options or {})

        response = await self._make_request(
            method="POST",
            endpoint="/v1/query",
            json=request.model_dump(exclude_none=True),
            use_cache=use_cache,
        )

        return QueryResponse(**await ensure_json_response(response))

    async def ingest_document(self, file_path: str, metadata: Optional[Dict[str, Any]] = None) -> DocumentIngestionResponse:
        """
        Ingest document into Intelligence-Builder knowledge base.
        """
        import aiofiles

        async with aiofiles.open(file_path, "rb") as f:
            file_content = await f.read()

        import os

        filename = os.path.basename(file_path)

        files = {"file": (filename, file_content)}
        data = {"metadata": (metadata or {})}

        response = await self._make_request(
            method="POST",
            endpoint="/v1/ingest",
            files=files,
            data=data,
            use_cache=False,
        )

        return DocumentIngestionResponse(**await ensure_json_response(response))

    async def list_entities(
        self,
        entity_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> EntityListResponse:
        """
        List entities from knowledge graph.
        """
        params = {"limit": min(limit, 1000), "offset": offset}
        if entity_type:
            params["type"] = entity_type

        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint("/entities"),
            params=params,
            use_cache=True,
        )

        return EntityListResponse(**await ensure_json_response(response))

    async def create_entity(
        self,
        entity_data: Union[BaseModel, Dict[str, Any]],
    ) -> Entity:
        """
        Create a single entity.
        """
        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/entities"),
            json=self._serialize_payload(entity_data),
            use_cache=False,
        )
        return Entity(**await ensure_json_response(response))

    async def create_entities_batch(
        self,
        entities: List[Union[BaseModel, Dict[str, Any]]],
    ) -> List[str]:
        """
        Batch create entities (up to 1000 records).
        """
        payload = [self._serialize_payload(entity) for entity in entities]
        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/entities/batch"),
            json={"entities": payload},
            use_cache=False,
        )
        data = await ensure_json_response(response)
        return [str(entity_id) for entity_id in data]

    async def get_entity(self, entity_id: Union[str, "UUID"]) -> Entity:
        """
        Retrieve an entity by ID.
        """
        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint(f"/entities/{entity_id}"),
            use_cache=True,
        )
        return Entity(**await ensure_json_response(response))

    async def search_entities(
        self,
        *,
        embedding: Optional[List[float]] = None,
        query_text: Optional[str] = None,
        limit: int = 10,
        threshold: float = 0.7,
        entity_types: Optional[List[str]] = None,
    ) -> List[Entity]:
        """
        Search entities via vector or text search endpoints.
        """
        if embedding is None and not query_text:
            raise ValueError("Provide either an embedding or query_text for entity search.")

        if embedding is not None:
            body: Dict[str, Any] = {
                "embedding": embedding,
                "threshold": threshold,
                "limit": limit,
            }
            if entity_types:
                body["entity_types"] = entity_types
            endpoint = self._kg_endpoint("/entities/search/vector")
        else:
            body = {
                "query": query_text,
                "limit": limit,
            }
            if entity_types:
                body["entity_types"] = entity_types
            endpoint = self._kg_endpoint("/entities/search/text")

        response = await self._make_request(
            method="POST",
            endpoint=endpoint,
            json=body,
            use_cache=True,
        )
        results = await ensure_json_response(response)
        return [Entity(**item) for item in results]

    async def search_graph(
        self,
        *,
        query_text: Optional[str] = None,
        embedding: Optional[List[float]] = None,
        limit: int = 10,
        threshold: float = 0.7,
        entity_types: Optional[List[str]] = None,
    ) -> List[Entity]:
        """
        Convenience wrapper that delegates to entity search helpers.
        """
        return await self.search_entities(
            embedding=embedding,
            query_text=query_text,
            limit=limit,
            threshold=threshold,
            entity_types=entity_types,
        )

    async def create_relationship(
        self,
        relationship_data: Union[BaseModel, Dict[str, Any]],
    ) -> Relationship:
        """
        Create a relationship between two entities.
        """
        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/relationships"),
            json=self._serialize_payload(relationship_data),
            use_cache=False,
        )
        return Relationship(**await ensure_json_response(response))

    async def create_relationships_batch(
        self,
        relationships: List[Union[BaseModel, Dict[str, Any]]],
    ) -> List[str]:
        """
        Batch create relationships.
        """
        payload = [self._serialize_payload(rel) for rel in relationships]
        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/relationships/batch"),
            json={"relationships": payload},
            use_cache=False,
        )
        data = await ensure_json_response(response)
        return [str(relationship_id) for relationship_id in data]

    async def get_relationship(self, relationship_id: Union[str, "UUID"]) -> Relationship:
        """
        Retrieve a relationship by ID.
        """
        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint(f"/relationships/{relationship_id}"),
            use_cache=True,
        )
        return Relationship(**await ensure_json_response(response))

    async def list_relationships(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> RelationshipListResponse:
        """
        List relationships with pagination.
        """
        params = {"limit": limit, "offset": offset}
        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint("/relationships"),
            params=params,
            use_cache=True,
        )
        return RelationshipListResponse(**await ensure_json_response(response))

    async def get_entity_relationships(
        self,
        entity_id: Union[str, "UUID"],
        direction: str = "both",
    ) -> List[Relationship]:
        """
        Return relationships connected to an entity.
        """
        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint(f"/relationships/entities/{entity_id}/relationships"),
            params={"direction": direction},
            use_cache=True,
        )
        data = await ensure_json_response(response)
        return [Relationship(**item) for item in data]

    async def traverse_graph(
        self,
        entity_id: str,
        depth: int = 2,
        relationship_types: Optional[List[str]] = None,
    ) -> GraphTraversalResponse:
        """
        Traverse knowledge graph from a starting entity.
        """
        request = GraphTraversalRequest(
            start_entity_id=entity_id,
            max_depth=max(1, min(depth, 10)),
            relationship_types=relationship_types or None,
        )

        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/graph/traverse"),
            json=request.model_dump(exclude_none=True),
            use_cache=True,
        )

        return GraphTraversalResponse(**await ensure_json_response(response))

    async def find_shortest_path(
        self,
        from_entity_id: str,
        to_entity_id: str,
        max_depth: int = 5,
        relationship_types: Optional[List[str]] = None,
    ) -> PathFindingResponse:
        """
        Find the shortest path between two entities.
        """
        request = PathFindingRequest(
            from_entity_id=from_entity_id,
            to_entity_id=to_entity_id,
            max_depth=max_depth,
            relationship_types=relationship_types,
        )
        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/graph/path/shortest"),
            json=request.model_dump(exclude_none=True),
            use_cache=False,
        )
        return PathFindingResponse(**await ensure_json_response(response))

    async def find_all_paths(
        self,
        from_entity_id: str,
        to_entity_id: str,
        max_depth: int = 5,
        relationship_types: Optional[List[str]] = None,
    ) -> PathFindingResponse:
        """
        Find all paths between two entities.
        """
        request = PathFindingRequest(
            from_entity_id=from_entity_id,
            to_entity_id=to_entity_id,
            max_depth=max_depth,
            relationship_types=relationship_types,
        )
        response = await self._make_request(
            method="POST",
            endpoint=self._kg_endpoint("/graph/paths"),
            json=request.model_dump(exclude_none=True),
            use_cache=False,
        )
        return PathFindingResponse(**await ensure_json_response(response))

    async def get_subgraph(self, entity_id: str, depth: int = 1) -> GraphTraversalResponse:
        """
        Retrieve a subgraph around a given entity.
        """
        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint(f"/graph/subgraph/{entity_id}"),
            params={"depth": depth},
            use_cache=True,
        )
        return GraphTraversalResponse(**await ensure_json_response(response))

    async def get_entity_neighbors(self, entity_id: str) -> List[Entity]:
        """
        Fetch immediate neighbors for an entity.
        """
        response = await self._make_request(
            method="GET",
            endpoint=self._kg_endpoint(f"/graph/entities/{entity_id}/neighbors"),
            use_cache=True,
        )
        data = await ensure_json_response(response)
        return [Entity(**item) for item in data]

    async def health_check(self) -> HealthCheckResponse:
        """
        Check Intelligence-Builder health status.
        """
        response = await self._make_request(method="GET", endpoint="/v1/health", use_cache=False)

        return HealthCheckResponse(**await ensure_json_response(response))

    async def get_statistics(self) -> Dict[str, Any]:
        """
        Get client statistics.
        """
        stats = {
            "requests_made": self._request_counter,
            "cache_hits": 0,
            "cache_misses": 0,
            "circuit_breaker_state": "closed",
            "average_latency_ms": 0,
        }

        if self._cache_manager:
            cache_stats = await self._cache_manager.get_statistics()
            stats.update(cache_stats)

        if self._circuit_breaker:
            stats["circuit_breaker_state"] = self._circuit_breaker.state

        return stats
