"""Authentication Manager with JWT token handling"""

import asyncio
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx

from src.utils.http import ensure_json_response
from .exceptions import AuthenticationError


class AuthenticationManager:
    """
    Manages JWT authentication with automatic token refresh.
    """

    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url
        self.api_key = api_key
        self._http_client: Optional[httpx.AsyncClient] = None
        self._token: Optional[str] = None
        self._token_expiry: Optional[datetime] = None
        self._lock = asyncio.Lock()

    def set_http_client(self, client: httpx.AsyncClient):
        """Set HTTP client for authentication requests"""
        self._http_client = client

    @property
    def token(self) -> Optional[str]:
        """Get current JWT token"""
        return self._token

    async def ensure_authenticated(self):
        """
        Ensure we have a valid JWT token.
        """
        async with self._lock:
            if self._needs_refresh():
                await self._authenticate()

    def _needs_refresh(self) -> bool:
        """Check if token needs refresh"""
        if not self._token or not self._token_expiry:
            return True

        refresh_threshold = datetime.now(timezone.utc) + timedelta(minutes=5)
        return self._token_expiry <= refresh_threshold

    async def _authenticate(self):
        """
        Authenticate and obtain JWT token.
        """
        if not self._http_client:
            raise AuthenticationError("HTTP client not initialized")

        try:
            response = await self._http_client.post(
                "/v1/auth/token",
                json={
                    "api_key": self.api_key,
                    "client": "sdk",
                    "client_version": "1.0.0"
                },
                headers={"X-API-Key": self.api_key}
            )
            response.raise_for_status()

            data = await ensure_json_response(response)
            self._token = data["access_token"]
            expires_in = data.get("expires_in", 3600)
            self._token_expiry = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

        except httpx.HTTPStatusError as e:
            raise AuthenticationError(
                f"Authentication failed: HTTP {e.response.status_code}"
            )
        except Exception as e:
            raise AuthenticationError(f"Authentication error: {e}")

    def clear(self):
        """Clear authentication state"""
        self._token = None
        self._token_expiry = None
