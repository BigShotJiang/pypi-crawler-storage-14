"""Pydantic models for requests and responses used by the SDK."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ============================================================================
# Query + Ingestion Models
# ============================================================================


class QueryRequest(BaseModel):
    """Query request payload."""

    query: str = Field(..., min_length=3, max_length=8000)
    context: Dict[str, Any] = Field(default_factory=dict)
    options: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("query")
    @classmethod
    def query_not_empty(cls, value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            raise ValueError("Query cannot be empty")
        return trimmed


class QueryResponse(BaseModel):
    """Structured answer returned by the API."""

    answer: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence: List[Dict[str, Any]] = Field(default_factory=list)
    recommendations: List[Dict[str, Any]] = Field(default_factory=list)
    query_id: str
    processing_time: float = Field(..., ge=0)
    provider_used: str
    model_used: str
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DocumentIngestionRequest(BaseModel):
    """Metadata envelope for document ingestion."""

    metadata: Dict[str, Any] = Field(default_factory=dict)


class DocumentIngestionResponse(BaseModel):
    """Response returned from document ingestion."""

    document_id: str
    status: str
    message: str
    processing_time: float = Field(..., ge=0)


# ============================================================================
# Entity Models
# ============================================================================


class EntityBase(BaseModel):
    """Shared fields for entity records."""

    entity_type: str = Field(..., max_length=50)
    name: str = Field(..., max_length=255)
    description: Optional[str] = None
    content: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    external_id: Optional[str] = Field(default=None, max_length=255)
    source_url: Optional[str] = None
    source_type: Optional[str] = Field(default=None, max_length=50)


class Entity(EntityBase):
    """Entity returned from the knowledge graph."""

    model_config = ConfigDict(from_attributes=True)

    entity_id: UUID
    embedding_model: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    accessed_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None


class EntityListResponse(BaseModel):
    """Paginated entity listing."""

    items: List[Entity] = Field(default_factory=list)
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1)
    offset: int = Field(..., ge=0)
    has_more: bool = False

    @property
    def entities(self) -> List[Entity]:
        """Backward compatible alias used by early SDK drafts."""
        return self.items


# ============================================================================
# Relationship Models
# ============================================================================


class Relationship(BaseModel):
    """Relationship between two entities."""

    model_config = ConfigDict(from_attributes=True)

    relationship_id: UUID
    from_entity_id: UUID
    to_entity_id: UUID
    relationship_type: str = Field(..., max_length=50)
    weight: float = Field(1.0, ge=0.0, le=1.0)
    confidence: float = Field(1.0, ge=0.0, le=1.0)
    properties: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None


class RelationshipListResponse(BaseModel):
    """Paginated relationship listing."""

    items: List[Relationship] = Field(default_factory=list)
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1)
    offset: int = Field(..., ge=0)
    has_more: bool = False

    @property
    def relationships(self) -> List[Relationship]:
        """Backward compatible alias for earlier SDK consumers."""
        return self.items


# ============================================================================
# Graph Models
# ============================================================================


class GraphNode(BaseModel):
    """Node returned by traversal endpoints."""

    entity_id: UUID
    name: str
    entity_type: str
    depth: int = Field(..., ge=0)
    path: List[UUID] = Field(default_factory=list)
    relationship_type: Optional[str] = None
    weight: Optional[float] = None


class GraphTraversalRequest(BaseModel):
    """Traversal request payload."""

    start_entity_id: UUID
    max_depth: int = Field(3, ge=1, le=10)
    relationship_types: Optional[List[str]] = Field(default=None)


class GraphTraversalResponse(BaseModel):
    """Traversal response envelope."""

    nodes: List[GraphNode] = Field(default_factory=list)
    total_nodes: int = Field(..., ge=0)


class GraphPath(BaseModel):
    """Path representation returned by path finding endpoints."""

    entities: List[UUID] = Field(default_factory=list)
    relationships: List[UUID] = Field(default_factory=list)
    total_weight: float = Field(0.0, ge=0.0)
    length: int = Field(..., ge=0)


class PathFindingRequest(BaseModel):
    """Path finding request payload."""

    from_entity_id: UUID
    to_entity_id: UUID
    max_depth: int = Field(5, ge=1, le=10)
    relationship_types: Optional[List[str]] = Field(default=None)


class PathFindingResponse(BaseModel):
    """Path finding response envelope."""

    paths: List[GraphPath] = Field(default_factory=list)
    shortest_path: Optional[GraphPath] = None


# ============================================================================
# Health Models
# ============================================================================


class HealthCheckResponse(BaseModel):
    """SDK health check response model."""

    status: str
    timestamp: datetime
    components: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
