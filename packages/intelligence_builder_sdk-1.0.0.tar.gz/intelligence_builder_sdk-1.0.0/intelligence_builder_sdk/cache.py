"""Multi-backend cache manager"""

import hashlib
import json
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

import aiofiles


class CacheBackend(ABC):
    """Abstract cache backend"""

    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        pass

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int):
        pass

    @abstractmethod
    async def delete(self, key: str):
        pass

    @abstractmethod
    async def clear(self):
        pass

    @abstractmethod
    async def connect(self):
        pass

    @abstractmethod
    async def disconnect(self):
        pass


class MemoryCacheBackend(CacheBackend):
    """In-memory cache backend"""

    def __init__(self):
        self._cache: Dict[str, tuple[Any, float]] = {}

    async def get(self, key: str) -> Optional[Any]:
        import time
        if key in self._cache:
            value, expiry = self._cache[key]
            if time.time() < expiry:
                return value
            else:
                del self._cache[key]
        return None

    async def set(self, key: str, value: Any, ttl: int):
        import time
        self._cache[key] = (value, time.time() + ttl)

    async def delete(self, key: str):
        self._cache.pop(key, None)

    async def clear(self):
        self._cache.clear()

    async def connect(self):
        pass

    async def disconnect(self):
        pass


class RedisCacheBackend(CacheBackend):
    """Redis cache backend"""

    def __init__(self, redis_url: str):
        self.redis_url = redis_url
        self._redis = None

    async def connect(self):
        import redis.asyncio as redis
        self._redis = await redis.from_url(self.redis_url)

    async def disconnect(self):
        if self._redis:
            await self._redis.close()

    async def get(self, key: str) -> Optional[Any]:
        value = await self._redis.get(key)
        if value:
            return json.loads(value)
        return None

    async def set(self, key: str, value: Any, ttl: int):
        await self._redis.set(key, json.dumps(value), ex=ttl)

    async def delete(self, key: str):
        await self._redis.delete(key)

    async def clear(self):
        await self._redis.flushdb()


class CacheManager:
    """
    Multi-backend cache manager.
    """

    def __init__(
        self,
        enabled: bool = True,
        ttl: int = 300,
        backend: str = "memory",
        redis_url: Optional[str] = None
    ):
        self.enabled = enabled
        self.ttl = ttl
        self._hits = 0
        self._misses = 0

        if not enabled:
            self._backend = None
            return

        if backend == "memory":
            self._backend = MemoryCacheBackend()
        elif backend == "redis":
            if not redis_url:
                raise ValueError("redis_url required for redis backend")
            self._backend = RedisCacheBackend(redis_url)
        else:
            raise ValueError(f"Unsupported cache backend: {backend}")

    async def connect(self):
        if self._backend:
            await self._backend.connect()

    async def disconnect(self):
        if self._backend:
            await self._backend.disconnect()

    def generate_key(self, endpoint: str, params: Optional[Dict] = None) -> str:
        """Generate cache key from endpoint and params"""
        key_data = f"{endpoint}:{json.dumps(params or {}, sort_keys=True)}"
        return hashlib.sha256(key_data.encode()).hexdigest()

    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        if not self.enabled or not self._backend:
            return None

        value = await self._backend.get(key)
        if value is not None:
            self._hits += 1
        else:
            self._misses += 1
        return value

    async def set(self, key: str, value: Any):
        """Set value in cache"""
        if self.enabled and self._backend:
            await self._backend.set(key, value, self.ttl)

    async def delete(self, key: str):
        """Delete value from cache"""
        if self.enabled and self._backend:
            await self._backend.delete(key)

    async def clear(self):
        """Clear all cached values"""
        if self.enabled and self._backend:
            await self._backend.clear()

    async def get_statistics(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0

        return {
            "cache_hits": self._hits,
            "cache_misses": self._misses,
            "cache_hit_rate": hit_rate
        }
