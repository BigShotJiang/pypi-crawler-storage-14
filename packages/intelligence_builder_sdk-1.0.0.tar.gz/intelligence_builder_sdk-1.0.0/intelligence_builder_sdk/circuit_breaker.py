"""Circuit breaker implementation using pybreaker"""

from typing import Callable, Any
from pybreaker import CircuitBreaker, CircuitBreakerError

from .exceptions import ServiceUnavailableError


class CircuitBreakerManager:
    """
    Circuit breaker manager for fault tolerance.
    """

    def __init__(
        self,
        enabled: bool = True,
        failure_threshold: int = 5,
        timeout: int = 60
    ):
        self.enabled = enabled

        if enabled:
            self._breaker = CircuitBreaker(
                fail_max=failure_threshold,
                reset_timeout=timeout,
                exclude=[ServiceUnavailableError]
            )
        else:
            self._breaker = None

    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Call function through circuit breaker.
        """
        if not self.enabled or not self._breaker:
            return await func(*args, **kwargs)

        try:
            return await self._breaker.call_async(func, *args, **kwargs)
        except CircuitBreakerError:
            raise ServiceUnavailableError(
                "Circuit breaker is open - service temporarily unavailable"
            )

    @property
    def state(self) -> str:
        """Get current circuit breaker state"""
        if not self._breaker:
            return "disabled"
        state = self._breaker.current_state
        if hasattr(state, "name"):
            return state.name.lower()
        return str(state).lower()
