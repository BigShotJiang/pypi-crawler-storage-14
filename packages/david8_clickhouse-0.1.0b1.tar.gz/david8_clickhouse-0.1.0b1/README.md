# david8_clickhouse

`david8_clickhouse` is [ClickHouse](https://clickhouse.com/) dialect for [david8](https://github.com/d-ganchar/david8)

See [Wiki](https://github.com/d-ganchar/david8_clickhouse/wiki)
