int8 = 'Int8'
int16 = 'Int16'
int32 = 'Int32'
int64 = 'Int64'
int128 = 'Int128'
int256 = 'Int256'

uint8 = 'UInt8'
uint16 = 'UInt16'
uint32 = 'UInt32'
uint64 = 'UInt64'
uint128 = 'UInt128'
uint256 = 'UInt256'

bfloat16 = 'BFloat16'
float32 = 'Float32'
float64 = 'Float64'

string = 'String'
