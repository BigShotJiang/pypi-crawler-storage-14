from videoipath_automation_tool.connector.vip_connector import *
