"""
Differential subpackage containing diff function.
"""
from .discrete import diff
__all__=['diff']