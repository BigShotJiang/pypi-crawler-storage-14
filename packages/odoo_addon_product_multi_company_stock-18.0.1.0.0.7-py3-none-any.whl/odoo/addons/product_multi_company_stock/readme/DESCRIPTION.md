This modules does not allow to remove a company from company_ids if
there is stock or moves in that company
