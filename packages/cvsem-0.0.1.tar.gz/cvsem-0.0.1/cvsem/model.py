#1

from skimage import measure
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load image and convert to grayscale
img = cv2.imread('C:\Sem7\Cv\models\code\image.png')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Sobel Edge Detection
sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0)  # Horizontal edges
sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1)  # Vertical edges
sobel = cv2.magnitude(sobelx, sobely)

# Prewitt Edge Detection (manual kernels)
kernelx = np.array([[1, 0, -1], [1, 0, -1], [1, 0, -1]])
kernely = np.array([[1, 1, 1], [0, 0, 0], [-1, -1, -1]])
prewittx = cv2.filter2D(gray, -1, kernelx).astype(np.float32)
prewitty = cv2.filter2D(gray, -1, kernely).astype(np.float32)
prewitt = cv2.magnitude(prewittx, prewitty)


# Laplacian Edge Detection
laplacian = cv2.Laplacian(gray, cv2.CV_64F)

# Canny Edge Detection
canny = cv2.Canny(gray, 100, 200)

# Visualization
fig, axs = plt.subplots(2, 2, figsize=(10, 8))
titles = ['Sobel', 'Prewitt', 'Laplacian', 'Canny']
images = [sobel, prewitt, laplacian, canny]
for i, ax in enumerate(axs.flatten()):
    ax.imshow(images[i], cmap='gray')
    ax.set_title(titles[i])
    ax.axis('off')
plt.tight_layout()
plt.show()


# Comments:
# - Sobel & Prewitt emphasize horizontal and vertical edges, but Sobel is more robust to noise.
# - Laplacian detects edges regardless of orientation but appears noisier.
# - Canny produces clean, thin edges and handles noise reasonably well.


def count_edge_pixels(edge_img):
    """
    Counts non-zero edge pixels.
    """
    count = np.count_nonzero(edge_img)
    print(f'Number of edge pixels: {count}')
    return count

num_edges = count_edge_pixels(canny)

# 3: Edge Quality Metrics (Sharpness & Continuity)


def edge_sharpness(edge_img):
    """
    Compute sharpness as ratio of edge area to total area.
    Higher is typically sharper.
    """
    edge_area = np.count_nonzero(edge_img)
    total_area = edge_img.size
    return edge_area / total_area


def edge_continuity(edge_img):
    """
    Continuity via average length of edge segments.
    """
    # Label connected edge pixels
    labels = measure.label(edge_img, connectivity=2)
    regions = measure.regionprops(labels)
    if not regions:
        return 0
    avg_length = np.mean([r.area for r in regions])
    return avg_length


# Example:
sharpness = edge_sharpness(canny)
continuity = edge_continuity(canny)
print(f"Edge Sharpness: {sharpness:.3f}")
print(f"Edge Continuity (avg edge segment length): {continuity:.2f}")


# Comments:
# - Sharpness: More edge pixels per area means sharper, but too high can mean noisy.
# - Continuity: Longer segments mean more continuous, fewer breaks.


#1b =============================================================================
#  HOG Feature Extraction & Visualization
from skimage import io, color
import pywt
import cv2
from skimage import io, color, feature
import matplotlib.pyplot as plt

# Load and convert to grayscale
# Use any professional/benchmark image here
img = io.imread('sample.jpg')
img_gray = color.rgb2gray(img)

# Extract HOG features and HOG visualization image
hog_features, hog_image = feature.hog(img_gray, orientations=8, pixels_per_cell=(16, 16),
                                      cells_per_block=(1, 1), visualize=True)

# Show original and HOG images side by side
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 6))
ax1.imshow(img_gray, cmap='gray')
ax1.set_title('Original Grayscale')
ax1.axis('off')
ax2.imshow(hog_image, cmap='gray')
ax2.set_title('HOG Features')
ax2.axis('off')
plt.show()

# 3. SIFT Matching – Two Images (Scale/Angle Variation)


img1 = cv2.imread('image1.jpg')
img2 = cv2.imread('image2.jpg')
gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

sift = cv2.SIFT_create()
kp1, des1 = sift.detectAndCompute(gray1, None)
kp2, des2 = sift.detectAndCompute(gray2, None)

bf = cv2.BFMatcher()
matches = bf.knnMatch(des1, des2, k=2)

# Ratio test - only valid matches
good = []
for m, n in matches:
    if m.distance < 0.75 * n.distance:
        good.append(m)

img_matches = cv2.drawMatches(gray1, kp1, gray2, kp2, good, None,
                              flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

plt.figure(figsize=(14, 6))
plt.imshow(img_matches)
plt.title(f"SIFT Matches ({len(good)} good matches)")
plt.axis('off')
plt.show()


img = cv2.imread('sample.jpg')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Create SIFT detector
sift = cv2.SIFT_create()

# Create ORB detector (free alternative to SURF)
orb = cv2.ORB_create()

# Detect keypoints and descriptors
kp_sift, des_sift = sift.detectAndCompute(gray, None)
kp_orb, des_orb = orb.detectAndCompute(gray, None)

# Draw keypoints
img_sift = cv2.drawKeypoints(
    gray, kp_sift, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
img_orb = cv2.drawKeypoints(
    gray, kp_orb, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

# Plot side-by-side
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
plt.imshow(img_sift, cmap='gray')
plt.title(f'SIFT Keypoints ({len(kp_sift)})')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(img_orb, cmap='gray')
plt.title(f'ORB Keypoints ({len(kp_orb)})')
plt.axis('off')

plt.show()

# 4. Image Decomposition Using 2D Haar DWT
img = io.imread('sample.jpg')
img_gray = color.rgb2gray(img)

coeffs2 = pywt.dwt2(img_gray, 'haar')
LL, (LH, HL, HH) = coeffs2

fig, axs = plt.subplots(2, 2, figsize=(10, 8))
axs[0, 0].imshow(LL, cmap='gray')
axs[0, 0].set_title('LL (Approximation)')
axs[0, 1].imshow(LH, cmap='gray')
axs[0, 1].set_title('LH (Horizontal Details)')
axs[1, 0].imshow(HL, cmap='gray')
axs[1, 0].set_title('HL (Vertical Details)')
axs[1, 1].imshow(HH, cmap='gray')
axs[1, 1].set_title('HH (Diagonal Details)')
for ax in axs.flatten():
    ax.axis('off')
plt.tight_layout()
plt.show()


# 5. Count Number of Keypoints for SIFT, SURF, HOG

def count_sift(gray_img):
    sift = cv2.SIFT_create()
    kp, _ = sift.detectAndCompute(gray_img, None)
    return len(kp)


def count_orb(gray_img):
    orb = cv2.ORB_create()
    kp, _ = orb.detectAndCompute(gray_img, None)
    return len(kp)


def count_hog(gray_img, pixels_per_cell=(16, 16)):
    h, w = gray_img.shape
    cells = (h // pixels_per_cell[0]) * (w // pixels_per_cell[1])
    return cells


# Example usage:
gray_img = cv2.cvtColor(cv2.imread('sample.jpg'), cv2.COLOR_BGR2GRAY)
num_sift = count_sift(gray_img)
num_orb = count_orb(gray_img)
num_hog = count_hog(gray_img)

print(
    f"SIFT keypoints: {num_sift}\nORB keypoints: {num_orb}\nHOG 'cells': {num_hog}"
)

# Comments:
# SIFT and SURF count actual detected keypoints in the image
# HOG produces features per cell, not discrete keypoints; so count is based on the grid settings
# SIFT often produces the highest actual keypoint count for detailed/complex images

#2======================================================================================
import cv2
import numpy as np
import matplotlib.pyplot as plt

# ---------- Read Image ----------
img = cv2.imread('brain_mri.jpg', cv2.IMREAD_GRAYSCALE)

# ---------- Edge-Based Method (Canny) ----------
blur = cv2.GaussianBlur(img, (5,5), 0)
edges = cv2.Canny(blur, 80, 150)

# ---------- Region Growing Method (Flood Fill) ----------
seed_point = (100, 100)  # Change based on tumor location
mask = np.zeros((img.shape[0]+2, img.shape[1]+2), np.uint8)
img_region = img.copy()
cv2.floodFill(img_region, mask, seed_point, 255, (10,)*3, (10,)*3, flags=8)

# ---------- Display ----------
plt.figure(figsize=(12,6))
plt.subplot(1,3,1); plt.title("Original MRI"); plt.imshow(img, cmap='gray')
plt.subplot(1,3,2); plt.title("Edge-Based (Canny)"); plt.imshow(edges, cmap='gray')
plt.subplot(1,3,3); plt.title("Region-Growing (Flood Fill)"); plt.imshow(img_region, cmap='gray')
plt.show()



# ---------- Read Image ----------
img = cv2.imread('coins.jpg', cv2.IMREAD_GRAYSCALE)

# ---------- Edge-Based (Canny) ----------
blur = cv2.GaussianBlur(img, (5,5), 0)
edges = cv2.Canny(blur, 100, 200)

# ---------- Region Growing (Flood Fill) ----------
img_region = img.copy()
mask = np.zeros((img.shape[0]+2, img.shape[1]+2), np.uint8)

# Choose seed point roughly on a coin area
seed_point = (120, 100)
cv2.floodFill(img_region, mask, seed_point, 255, (10,)*3, (10,)*3, flags=8)

# ---------- Display ----------
plt.figure(figsize=(12,6))
plt.subplot(1,3,1); plt.title("Original Image"); plt.imshow(img, cmap='gray')
plt.subplot(1,3,2); plt.title("Edge-Based (Canny)"); plt.imshow(edges, cmap='gray')
plt.subplot(1,3,3); plt.title("Region-Growing Result"); plt.imshow(img_region, cmap='gray')
plt.show()


#3===================================================================================
#face
from google.colab import drive
drive.mount('/content/drive')

from ultralytics import YOLO

model_path = '/content/drive/MyDrive/colab_models/yolov8n-face.pt'

yolo_detector = YOLO(model_path)

print("✅ Model successfully loaded from Google Drive!")
import torch
from sklearn.datasets import fetch_lfw_people
from facenet_pytorch import InceptionResnetV1
from PIL import Image
import numpy as np
from ultralytics import YOLO
from google.colab import drive

resnet_embedder = InceptionResnetV1(pretrained='vggface2', device=DEVICE).eval()

DISTANCE_THRESHOLD = 1.25

def generate_embedding_with_yolo(image_np, yolo, resnet):

    image_uint8 = (image_np * 255).astype(np.uint8)
    img_pil = Image.fromarray(image_uint8)

    results = yolo(img_pil,conf=0.1 ,verbose=False)

    best_face_crop = None
    highest_confidence = 0

    if results and len(results[0].boxes) > 0:
        for box in results[0].boxes:
            conf = box.conf.item()
            if conf > highest_confidence:
                highest_confidence = conf
                xyxy = box.xyxy[0].cpu().numpy().astype(int)
                best_face_crop = img_pil.crop((xyxy[0], xyxy[1], xyxy[2], xyxy[3]))

    if best_face_crop is None:
        return None

    resized_face = best_face_crop.resize((160, 160))
    face_np = np.array(resized_face)

    if len(face_np.shape) == 2:
        face_np = np.stack([face_np] * 3, axis=-1)

    face_tensor = torch.tensor(face_np, dtype=torch.float32).to(DEVICE)
    face_tensor = (face_tensor - 127.5) / 128.0
    face_tensor = face_tensor.permute(2, 0, 1)
    face_tensor = face_tensor.unsqueeze(0)

    with torch.no_grad():
        embedding = resnet(face_tensor)

    return embedding.cpu().numpy().flatten()


lfw_people = fetch_lfw_people(min_faces_per_person=50)
X = lfw_people.images
y = lfw_people.target
target_names = lfw_people.target_names
n_classes = target_names.shape[0]
print(f"Dataset loaded. Found {n_classes} individuals with at least 50 photos.")

student_database = {}
test_data = []

print("Simulating student enrollment...")
for i in range(n_classes):
    person_name = target_names[i]
    person_images = X[y == i]
    enrollment_image = person_images[0]
    embedding = generate_embedding_with_yolo(enrollment_image, yolo_detector, resnet_embedder)

    if embedding is not None:
        student_database[person_name] = embedding
        print(f" Enrolled {person_name}.")
    else:
        print(f" Could not detect a face for {person_name} during enrollment.")

    for j in range(1, len(person_images)):
        test_data.append({'name': person_name, 'image': person_images[j]})

print(f"\nEnrollment complete. {len(student_database)} students in the database.")
print(f"{len(test_data)} images will be used for the attendance simulation.\n")


print("="*40)
print(" STARTING LIVE ATTENDANCE SIMULATION ")
print("="*40)

attendance_sheet = {name: "Absent" for name in student_database.keys()}
correct_recognitions = 0
total_tests = 0

for test_case in test_data:
    true_name = test_case['name']
    image = test_case['image']
    live_embedding = generate_embedding_with_yolo(image, yolo_detector, resnet_embedder)

    if live_embedding is None:
        print(f"   - Could not detect a face for a test image of {true_name}.")
        continue

    total_tests += 1
    min_distance = float('inf')
    recognized_name = "Unknown"

    if not student_database:
      print("   - Database is empty")
      continue

    for name, stored_embedding in student_database.items():
        distance = np.linalg.norm(live_embedding - stored_embedding)
        if distance < min_distance:
            min_distance = distance
            recognized_name = name

    if min_distance <= DISTANCE_THRESHOLD:
        print(f"  Recognized: {recognized_name} (True Identity: {true_name}) - Distance: {min_distance:.2f}")
        if recognized_name == true_name:
            correct_recognitions += 1
        if attendance_sheet.get(recognized_name) == "Absent":
            attendance_sheet[recognized_name] = "Present"
    else:
        print(f"  Unknown Person Detected (True Identity: {true_name}) - Closest Match: {recognized_name}, Distance: {min_distance:.2f}")

print("\n" + "="*40)
print(" SIMULATION COMPLETE")
print("="*40)
print("\nFinal Attendance Sheet:")
for name, status in attendance_sheet.items():
    print(f"- {name}: {status}")

print("\n--- Recognition Accuracy ---")
if total_tests > 0:
    accuracy = (correct_recognitions / total_tests) * 100
    print(f"Correctly recognized {correct_recognitions} out of {total_tests} test images.")
    print(f"Accuracy: {accuracy:.2f}%")
else:
    print("No test images were processed, or the database was empty.")

#object
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np
from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt

train_datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2,   
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True
)

train_data = train_datagen.flow_from_directory(
    "products-dataset/",
    target_size=(128, 128),
    batch_size=8,
    class_mode="categorical",
    subset="training"
)

val_data = train_datagen.flow_from_directory(
    "products-dataset/",
    target_size=(128, 128),
    batch_size=8,
    class_mode="categorical",
    subset="validation"
)

print("Class indices:", train_data.class_indices)  # To check label mappings

model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, (3,3), activation="relu", input_shape=(128,128,3)),
    tf.keras.layers.MaxPooling2D(2,2),
    
    tf.keras.layers.Conv2D(64, (3,3), activation="relu"),
    tf.keras.layers.MaxPooling2D(2,2),
    
    tf.keras.layers.Conv2D(128, (3,3), activation="relu"),
    tf.keras.layers.MaxPooling2D(2,2),
    
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(128, activation="relu"),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(len(train_data.class_indices), activation="softmax")
])

model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

history = model.fit(
    train_data,
    validation_data=val_data,
    epochs=10
)

plt.plot(history.history['accuracy'], label='train_accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.legend()
plt.show()

img = image.load_img("can-test.jpeg", target_size=(128,128))
img_array = image.img_to_array(img) / 255.0
img_array = np.expand_dims(img_array, axis=0)

prediction = model.predict(img_array)
class_names = list(train_data.class_indices.keys())
predicted_label = class_names[np.argmax(prediction)]

plt.imshow(image.load_img("can-test.jpeg"))
plt.axis("off")
plt.title(f"Predicted: {predicted_label}")
plt.show()

img = image.load_img("bottle-test.jpeg", target_size=(128,128))
img_array = image.img_to_array(img) / 255.0
img_array = np.expand_dims(img_array, axis=0)

prediction = model.predict(img_array)
class_names = list(train_data.class_indices.keys())
predicted_label = class_names[np.argmax(prediction)]

plt.imshow(image.load_img("bottle-test.jpeg"))
plt.axis("off")
plt.title(f"Predicted: {predicted_label}")
plt.show()

img = image.load_img("chips-test.jpeg", target_size=(128,128))
img_array = image.img_to_array(img) / 255.0
img_array = np.expand_dims(img_array, axis=0)

prediction = model.predict(img_array)
class_names = list(train_data.class_indices.keys())
predicted_label = class_names[np.argmax(prediction)]

plt.imshow(image.load_img("chips-test.jpeg"))
plt.axis("off")
plt.title(f"Predicted: {predicted_label}")
plt.show()

#c
from ultralytics import YOLO
from PIL import Image
import numpy as np
import tensorflow as tf  # Or torch, depending on your scene classifier

# Load YOLOv8 pretrained model (object detection)
object_detector = YOLO('yolov8n.pt')  # General model – can use 'yolov8n.pt' or custom weights

# Load your scene classifier (suppose keras/tensorflow)
scene_classifier = tf.keras.models.load_model('scene_classifier_model.h5')  # Path to your scene model
scene_labels = ["classroom", "cafeteria", "parking_lot"]  # Adjust these as per your scenario

def detect_objects(image_path):
    image = Image.open(image_path)
    results = object_detector(image)
    objects = []
    for box in results[0].boxes:
        class_id = int(box.cls[0])
        conf = float(box.conf[0])
        label = object_detector.names[class_id]
        objects.append({'label': label, 'confidence': conf})
    return objects

def classify_scene(image_path):
    # Preprocess image as per your classifier's training
    img = Image.open(image_path).resize((128, 128))
    img = np.array(img) / 255.0
    img = np.expand_dims(img, axis=0)
    probs = scene_classifier.predict(img)
    scene_idx = np.argmax(probs)
    return scene_labels[scene_idx]

# --- Main loop (process one frame) ---
image_path = "test_university_scene.jpg"   # image from robot cam

objects_found = detect_objects(image_path)
scene = classify_scene(image_path)

print("Scene detected:", scene)
print("Objects found:")
for obj in objects_found:
    print(" -", obj['label'], f"(Confidence: {obj['confidence']:.2f})")

# Example decision logic
if scene == "classroom":
    print("Robot: In classroom – look for projectors, students, chairs")
elif scene == "cafeteria":
    print("Robot: In cafeteria – look out for food trays, tables, crowds")
elif scene == "parking_lot":
    print("Robot: In parking lot – cars, bikes, outdoors navigation")


#4===================================================================================
#captiontest

from pickle import load
from numpy import argmax
from keras.preprocessing.sequence import pad_sequences
from keras.applications.vgg16 import VGG16
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.applications.vgg16 import preprocess_input
from keras.models import Model
from keras.models import load_model
import cv2 
# extract features from each photo in the directory
def extract_features(filename):
	# load the model
	model = VGG16()
	# re-structure the model
	model.layers.pop()
	model = Model(inputs=model.inputs, outputs=model.layers[-1].output)
	# load the photo
	image = load_img(filename, target_size=(224, 224))
	# convert the image pixels to a numpy array
	image = img_to_array(image)
	# reshape data for the model
	image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
	# prepare the image for the VGG model
	image = preprocess_input(image)
	# get features
	feature = model.predict(image, verbose=0)
	return feature
 
# map an integer to a word
def word_for_id(integer, tokenizer):
	for word, index in tokenizer.word_index.items():
		if index == integer:
			return word
	return None
 
# generate a description for an image
def generate_desc(model, tokenizer, photo, max_length):
	# seed the generation process
	in_text = 'startseq'
	# iterate over the whole length of the sequence
	for i in range(max_length):
		# integer encode input sequence
		sequence = tokenizer.texts_to_sequences([in_text])[0]
		# pad input
		sequence = pad_sequences([sequence], maxlen=max_length)
		# predict next word
		yhat = model.predict([photo,sequence], verbose=0)
		# convert probability to integer
		yhat = argmax(yhat)
		# map integer to word
		word = word_for_id(yhat, tokenizer)
		# stop if we cannot map the word
		if word is None:
			break
		# append as input for generating the next word
		in_text += ' ' + word
		# stop if we predict the end of the sequence
		if word == 'endseq':
			break
	return in_text

# load the tokenizer
tokenizer = load(open('tokenizer.pkl', 'rb'))
# pre-define the max sequence length (from training)
max_length = 34
# load the model
model = load_model('model-ep004-loss3.572-val_loss3.833.h5')
# load and prepare the photograph
photo = extract_features('example.jpg')
# generate description
description = generate_desc(model, tokenizer, photo, max_length)
image = load_img('example.jpg')
image = img_to_array(image)
orig = cv2.imread('example.jpg')
cv2.putText(orig,description,(10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.6,(0,0,255),2,cv2.LINE_AA)
cv2.imshow("CAPTION GENERATION", orig)

cv2.waitKey(0)
print(description)

# load the image via OpenCV, draw the top prediction on the image,
# and display the image to our screen 

#==============================================================================
#5 Feature classification

import os
import numpy as np

import keras
from keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array

from keras.models import load_model
from keras import backend as K

from io import BytesIO
from PIL import Image
import cv2

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib import colors

import requests

K.set_learning_phase(0) #set the learning phase to not training


model = load_model('model.03-0.94.hdf5')


# Set the image generator
eval_datagen = ImageDataGenerator(rescale=1./255)
eval_dir = '../OCT2017/eval'
eval_generator = eval_datagen.flow_from_directory(eval_dir, target_size=(299, 299), \
                                                    batch_size=32, class_mode='categorical')
# Evaluate the model for a small set of images
loss = model.evaluate_generator(eval_generator, steps=10)
out = {}
for index, name in enumerate(model.metrics_names):
    print(name, loss[index])  

# Utility functions
classes = ['CNV', 'DME', 'DRUSEN', 'NORMAL']
# Preprocess the input
# Rescale the values to the same range that was used during training 
def preprocess_input(x):
    x = img_to_array(x) / 255.
    return np.expand_dims(x, axis=0) 

# Prediction for an image path in the local directory
def predict_from_image_path(image_path):
    return predict_image(load_img(image_path, target_size=(299, 299)))

# Prediction for an image URL path
def predict_from_image_url(image_url):
    res = requests.get(image_url)
    im = Image.open(BytesIO(res.content))
    return predict_from_image_path(im.fp)
    
# Predict an image
def predict_image(im):
    x = preprocess_input(im)
    pred = np.argmax(model.predict(x))
    return pred, classes[pred]


def grad_CAM(image_path):
    im = load_img(image_path, target_size=(299,299))
    x = preprocess_input(im)
    pred = model.predict(x)
    
    # Predicted class index
    index = np.argmax(pred)
    
    # Get the entry of the predicted class
    class_output = model.output[:, index]
    
    # The last convolution layer in Inception V3
    last_conv_layer = model.get_layer('conv2d_94')
    # Has 192 channels
    nmb_channels = last_conv_layer.output.shape[3]

    # Gradient of the predicted class with respect to the output feature map of the 
    # the convolution layer with 192 channels
    grads = K.gradients(class_output, last_conv_layer.output)[0]   
    
    # Vector of shape (192,), where each entry is the mean intensity of the gradient over 
    # a specific feature-map channel”
    pooled_grads = K.mean(grads, axis=(0, 1, 2))

    # Setup a function to extract the desired values
    iterate = K.function(model.inputs, [pooled_grads, last_conv_layer.output[0]])
    # Run the function to get the desired calues
    pooled_grads_value, conv_layer_output_value = iterate([x])
    
    # Multiply each channel in the feature-map array by “how important this channel is” with regard to the 
    # predicted class
 
    for i in range(nmb_channels):
        conv_layer_output_value[:, :, i] *= pooled_grads_value[i]
    
    # The channel-wise mean of the resulting feature map is the heatmap of the class activation.
    heatmap = np.mean(conv_layer_output_value, axis=-1)
    
    # Normalize the heatmap betwen 0 and 1 for visualization
    heatmap = np.maximum(heatmap, 0)
    heatmap /= np.max(heatmap)
       
    # Read the image again, now using cv2
    img = cv2.imread(image_path)
    # Size the heatmap to the size of the loaded image
    heatmap = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
    # Convert to RGB
    heatmap = np.uint8(255 * heatmap)
    # Pseudocolor/false color a grayscale image using OpenCV’s predefined colormaps
    heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
 
    # Superimpose the image with the required intensity
    superimposed_img = heatmap * 0.5 + img   
    
    # Write the image
    plt.figure(figsize=(24,12))
    cv2.imwrite('./tmp.jpg', superimposed_img)
    plt.imshow(mpimg.imread('./tmp.jpg'))
    plt.show() 


print(predict_from_image_path('../OCT2017/eval/DME/DME-15307-3.jpeg'))
grad_CAM('../OCT2017/eval/DME/DME-15307-3.jpeg')



for i, c in enumerate(classes):
    folder = './simple/test/' + c + '/'
    count = 1
    for file in os.listdir(folder):
        if file.endswith('.jpeg') == True:
            image_path = folder + file
            p, class_name = predict_from_image_path(image_path)
            if p == i:
                print(file, p, class_name)
            else:
                print(file, p, class_name, '**INCORRECT PREDICTION**')
                grad_CAM(image_path)
        count = count +1
        if count == 100:
            continue    

#==============================================================================
#6 Transfer classification

import os
import numpy as np

import keras
from keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array

from keras.models import load_model
from keras import backend as K

from io import BytesIO
from PIL import Image
import cv2

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib import colors

import requests

K.set_learning_phase(0) #set the learning phase to not training


model = load_model('model.03-0.94.hdf5')


# Set the image generator
eval_datagen = ImageDataGenerator(rescale=1./255)
eval_dir = '../OCT2017/eval'
eval_generator = eval_datagen.flow_from_directory(eval_dir, target_size=(299, 299), \
                                                    batch_size=32, class_mode='categorical')
# Evaluate the model for a small set of images
loss = model.evaluate_generator(eval_generator, steps=10)
out = {}
for index, name in enumerate(model.metrics_names):
    print(name, loss[index])  

# Utility functions
classes = ['CNV', 'DME', 'DRUSEN', 'NORMAL']
# Preprocess the input
# Rescale the values to the same range that was used during training 
def preprocess_input(x):
    x = img_to_array(x) / 255.
    return np.expand_dims(x, axis=0) 

# Prediction for an image path in the local directory
def predict_from_image_path(image_path):
    return predict_image(load_img(image_path, target_size=(299, 299)))

# Prediction for an image URL path
def predict_from_image_url(image_url):
    res = requests.get(image_url)
    im = Image.open(BytesIO(res.content))
    return predict_from_image_path(im.fp)
    
# Predict an image
def predict_image(im):
    x = preprocess_input(im)
    pred = np.argmax(model.predict(x))
    return pred, classes[pred]


def grad_CAM(image_path):
    im = load_img(image_path, target_size=(299,299))
    x = preprocess_input(im)
    pred = model.predict(x)
    
    # Predicted class index
    index = np.argmax(pred)
    
    # Get the entry of the predicted class
    class_output = model.output[:, index]
    
    # The last convolution layer in Inception V3
    last_conv_layer = model.get_layer('conv2d_94')
    # Has 192 channels
    nmb_channels = last_conv_layer.output.shape[3]

    # Gradient of the predicted class with respect to the output feature map of the 
    # the convolution layer with 192 channels
    grads = K.gradients(class_output, last_conv_layer.output)[0]   
    
    # Vector of shape (192,), where each entry is the mean intensity of the gradient over 
    # a specific feature-map channel”
    pooled_grads = K.mean(grads, axis=(0, 1, 2))

    # Setup a function to extract the desired values
    iterate = K.function(model.inputs, [pooled_grads, last_conv_layer.output[0]])
    # Run the function to get the desired calues
    pooled_grads_value, conv_layer_output_value = iterate([x])
    
    # Multiply each channel in the feature-map array by “how important this channel is” with regard to the 
    # predicted class
 
    for i in range(nmb_channels):
        conv_layer_output_value[:, :, i] *= pooled_grads_value[i]
    
    # The channel-wise mean of the resulting feature map is the heatmap of the class activation.
    heatmap = np.mean(conv_layer_output_value, axis=-1)
    
    # Normalize the heatmap betwen 0 and 1 for visualization
    heatmap = np.maximum(heatmap, 0)
    heatmap /= np.max(heatmap)
       
    # Read the image again, now using cv2
    img = cv2.imread(image_path)
    # Size the heatmap to the size of the loaded image
    heatmap = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
    # Convert to RGB
    heatmap = np.uint8(255 * heatmap)
    # Pseudocolor/false color a grayscale image using OpenCV’s predefined colormaps
    heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
 
    # Superimpose the image with the required intensity
    superimposed_img = heatmap * 0.5 + img   
    
    # Write the image
    plt.figure(figsize=(24,12))
    cv2.imwrite('./tmp.jpg', superimposed_img)
    plt.imshow(mpimg.imread('./tmp.jpg'))
    plt.show() 


print(predict_from_image_path('../OCT2017/eval/DME/DME-15307-3.jpeg'))
grad_CAM('../OCT2017/eval/DME/DME-15307-3.jpeg')



for i, c in enumerate(classes):
    folder = './simple/test/' + c + '/'
    count = 1
    for file in os.listdir(folder):
        if file.endswith('.jpeg') == True:
            image_path = folder + file
            p, class_name = predict_from_image_path(image_path)
            if p == i:
                print(file, p, class_name)
            else:
                print(file, p, class_name, '**INCORRECT PREDICTION**')
                grad_CAM(image_path)
        count = count +1
        if count == 100:
            continue    


'''
Q1 — Exercise 1 & 2 (Image difference; HOG feature extraction)
Exercise 1: Pixel-wise absolute difference



# q1_ex1_diff.py
import cv2
import numpy as np

M1 = cv2.imread('img1.png', cv2.IMREAD_GRAYSCALE)
M2 = cv2.imread('img2.png', cv2.IMREAD_GRAYSCALE)

if M1.shape != M2.shape:
    M2 = cv2.resize(M2, (M1.shape[1], M1.shape[0]))

out = cv2.absdiff(M1, M2)         

_, out_thresh = cv2.threshold(out, 30, 255, cv2.THRESH_BINARY)

cv2.imshow('Difference', out)
cv2.imshow('Difference Thresholded', out_thresh)
cv2.waitKey(0)
cv2.imwrite('difference.png', out)
cv2.destroyAllWindows()


Exercise 2: HOG feature extraction (step-by-step)

We implement HOG pipeline for a single image (64×128 typical window). The snippet below calculates gradients, magnitudes, orientations, forms 8×8-cell histograms, normalizes over 16×16 blocks, and returns the HOG descriptor.

import cv2
import numpy as np

def compute_hog(img, win_size=(64,128), cell_size=(8,8), block_size=(16,16), nbins=9):
    img = cv2.imread(img, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, win_size)
    gx = cv2.Sobel(img, cv2.CV_32F, 1, 0, ksize=1)
    gy = cv2.Sobel(img, cv2.CV_32F, 0, 1, ksize=1)
    mag, ang = cv2.cartToPolar(gx, gy, angleInDegrees=True)  # magnitude and angle
    
    ang = ang % 180

    cell_x = win_size[0] // cell_size[0]
    cell_y = win_size[1] // cell_size[1]

    bins = np.zeros((cell_y, cell_x, nbins), dtype=np.float32)
    bin_width = 180 / nbins
    for i in range(win_size[1]):
        for j in range(win_size[0]):
            c_x = j // cell_size[0]
            c_y = i // cell_size[1]
            bin_idx = int(ang[i, j] // bin_width) % nbins
            bins[c_y, c_x, bin_idx] += mag[i, j]

    block_stride = 1  # stride in cells
    hog_vector = []
    for by in range(cell_y - (block_size[1]//cell_size[1]) + 1):
        for bx in range(cell_x - (block_size[0]//cell_size[0]) + 1):
            block = bins[by:by+2, bx:bx+2, :].ravel()
            # L2-Hys normalization
            eps = 1e-6
            norm = np.linalg.norm(block) + eps
            block = block / norm
            # clip
            block = np.minimum(block, 0.2)
            # renormalize
            block = block / (np.linalg.norm(block) + eps)
            hog_vector.extend(block)
    return np.array(hog_vector, dtype=np.float32)

hog = compute_hog('person.png')
print('HOG length:', len(hog))




Q2 — Exercise 1 & 2 (Contrast stretching + linear filtering; Horse vs Human classification with ResNet)
Exercise 1: Contrast stretching & linear filtering + histogram

import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)

# contrast stretching: map min..max to 0..255
a, b = img.min(), img.max()
stretched = ((img - a) / (b - a) * 255).astype(np.uint8)

# linear filtering: simple averaging filter
kernel = np.ones((5,5), np.float32) / 25
filtered = cv2.filter2D(stretched, -1, kernel)

# Plot histograms
plt.figure(figsize=(10,4))
plt.subplot(1,3,1); plt.imshow(img, cmap='gray'); plt.title('Original'); plt.axis('off')
plt.subplot(1,3,2); plt.imshow(stretched, cmap='gray'); plt.title('Contrast Stretched'); plt.axis('off')
plt.subplot(1,3,3); plt.imshow(filtered, cmap='gray'); plt.title('Filtered'); plt.axis('off')
plt.show()

plt.figure()
plt.hist(img.ravel(), bins=256, alpha=0.5, label='orig')
plt.hist(stretched.ravel(), bins=256, alpha=0.5, label='stretched')
plt.legend(); plt.show()

Exercise 2: Binary classification (Horse vs Human) — ResNet transfer learning (Keras)

Use TensorFlow/Keras ImageDataGenerator and ResNet50 (pretrained) with custom top layers. This is a concise, robust approach for exam.

import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import ResNet50
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')
train_dir = r"horse-or-human\train"
test_dir = r"horse-or-human\validation"
train_datagen = ImageDataGenerator(rescale = 1./255)
test_datagen = ImageDataGenerator(rescale = 1./255)

train_gen = train_datagen.flow_from_directory(
    train_dir,
    target_size = (224, 224),
    batch_size = 32,
    class_mode = 'binary'
)

test_gen = test_datagen.flow_from_directory(
    test_dir,
    target_size = (224, 224),
    batch_size = 32,
    class_mode = 'binary'
)
print(f"Training Images: {train_gen.samples}")
print(f"Testing Images: {test_gen.samples}")

images, labels = next(train_gen)
plt.figure(figsize=(8,8))
for i in range(9):
    plt.subplot(3,3,i+1)
    plt.imshow(images[i])
    plt.title("Horse" if labels[i]==0 else "Human")
    plt.axis('off')
plt.show()

base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(224,224,3))
base_model.trainable = False


model = models.Sequential([
    base_model,
    layers.GlobalAveragePooling2D(),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(1, activation='sigmoid')  # Binary output
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history = model.fit(train_gen, validation_data=test_gen, epochs=8)


plt.figure(figsize=(8,4))
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Testing Accuracy')
plt.title('Training vs Testing Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.show()




Expected output: training & validation accuracy plots. 

Q3 — Exercise 1 & 2 (Geometrical transforms; SIFT feature extraction)
Exercise 1: Scaling, rotation, shearing



import cv2
import numpy as np

img = cv2.imread('image.jpg')
h,w = img.shape[:2]

# scaling
scaled = cv2.resize(img, (int(w*0.6), int(h*0.6)))

# rotation around center
M_rot = cv2.getRotationMatrix2D((w/2, h/2), 45, 1.0)
rotated = cv2.warpAffine(img, M_rot, (w, h))

# shearing (affine)
shear_factor = 0.3
M_shear = np.array([[1, shear_factor, 0],
                    [0, 1, 0]], dtype=np.float32)
sheared = cv2.warpAffine(img, M_shear, (w + int(h*shear_factor), h))

cv2.imshow('Original', img)
cv2.imshow('Scaled', scaled)
cv2.imshow('Rotated', rotated)
cv2.imshow('Sheared', sheared)
cv2.waitKey(0); cv2.destroyAllWindows()


Exercise 2: SIFT (Scale-Invariant Feature Transform)

import cv2

img = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)
sift = cv2.SIFT_create()  # requires opencv-contrib-python
keypoints, descriptors = sift.detectAndCompute(img, None)

img_kp = cv2.drawKeypoints(img, keypoints, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
cv2.imshow('SIFT keypoints', img_kp)
cv2.waitKey(0)
cv2.imwrite('sift_keypoints.png', img_kp)
print('Keypoints:', len(keypoints), 'Descriptor shape:', descriptors.shape)


Explain: SIFT builds scale-space by Gaussian blur at different scales, detects extrema in Difference-of-Gaussians; localizes keypoints and assigns orientation (dominant gradient) — descriptors are 128-D histograms (4×4×8).



Q4 — Exercise 1 & 2 (Extract frames from video; Horse vs Human again)
Exercise 1: Extract frames from video




import cv2
import os

video_path = '0001.avi'  # replace with your video path
output_folder = 'frames'  # folder to save frames

# Create folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Open the video
cap = cv2.VideoCapture(video_path)

frame_count = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break  # end of video
    # Save frame as image
    cv2.imwrite(os.path.join(output_folder, f'frame_{frame_count:04d}.jpg'), frame)
    frame_count += 1

cap.release()
print(f"Extracted {frame_count} frames to '{output_folder}'")


Exercise 2: Same as Q2 — I gave a ResNet transfer-learning recipe earlier. Reuse code and show metrics.



Q5 — MS-COCO classification + augmentation + Faster R-CNN



import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
import torchvision
import matplotlib.pyplot as plt
from PIL import Image

# -----------------------------
# Parameters
# -----------------------------
IMG_SIZE = 224
BATCH_SIZE = 16
EPOCHS = 5  # for demo

# -----------------------------
# a) Image augmentation & transforms
# -----------------------------
train_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(contrast=0.5),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])

val_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])

# -----------------------------
# b) Load MS-COCO subset (for demo, use folder of images with subfolders per class)
# -----------------------------
# Replace with your local folder structure if COCO is too big
train_dataset = datasets.ImageFolder('coco/train', transform=train_transforms)
val_dataset = datasets.ImageFolder('coco/val', transform=val_transforms)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# -----------------------------
# b) Show number of images
# -----------------------------
print("Training images:", len(train_dataset))
print("Validation images:", len(val_dataset))

# -----------------------------
# c) Plot some images
# -----------------------------
def imshow(img, title=''):
    img = img / 2 + 0.5  # unnormalize for display
    npimg = img.numpy()
    plt.imshow(np.transpose(npimg, (1,2,0)))
    plt.title(title)
    plt.show()

dataiter = iter(train_loader)
images, labels = next(dataiter)
imshow(torchvision.utils.make_grid(images[:4]), title=[train_dataset.classes[i] for i in labels[:4]])

# -----------------------------
# g) Build simple CNN for classification
# -----------------------------
num_classes = len(train_dataset.classes)
model = models.resnet18(pretrained=True)
for param in model.parameters():
    param.requires_grad = False  # freeze base
model.fc = nn.Sequential(
    nn.Linear(model.fc.in_features, 256),
    nn.ReLU(),
    nn.Dropout(0.5),
    nn.Linear(256, num_classes)
)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.fc.parameters(), lr=1e-4)

# -----------------------------
# h) Training loop
# -----------------------------
train_acc_history, val_acc_history = [], []

for epoch in range(EPOCHS):
    # Train
    model.train()
    correct, total = 0, 0
    for imgs, labels in train_loader:
        outputs = model(imgs)
        loss = criterion(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        _, preds = torch.max(outputs, 1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)
    train_acc = correct / total
    train_acc_history.append(train_acc)

    # Validation
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for imgs, labels in val_loader:
            outputs = model(imgs)
            _, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
    val_acc = correct / total
    val_acc_history.append(val_acc)

    print(f"Epoch {epoch+1}/{EPOCHS} - Train Acc: {train_acc:.4f}, Val Acc: {val_acc:.4f}")

# Plot accuracy
plt.plot(train_acc_history, label='train_acc')
plt.plot(val_acc_history, label='val_acc')
plt.legend()
plt.show()

# -----------------------------
# j) Build Faster R-CNN for object detection
# -----------------------------
# Using torchvision's pretrained model for COCO
faster_model = torchvision.models.detection.fasterrcnn_resnet50_fpn(pretrained=True)
faster_model.eval()

# Example of passing a single image
sample_img, _ = train_dataset[0]
sample_img = sample_img.unsqueeze(0)  # add batch dim
with torch.no_grad():
    pred = faster_model(sample_img)
print(pred)  # outputs bounding boxes, labels, scores




Q6 — BCCD dataset (blood cell classification with augmentation)



import os
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torchvision

# -----------------------------
# Parameters
# -----------------------------
IMG_SIZE = 224
BATCH_SIZE = 16
EPOCHS = 5  # for demo purposes

# Paths to BCCD dataset folders
train_dir = 'BCCD/train'
val_dir = 'BCCD/test'

# -----------------------------
# a) Load dataset without augmentation
# -----------------------------
basic_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
])

train_dataset = datasets.ImageFolder(train_dir, transform=basic_transform)
val_dataset = datasets.ImageFolder(val_dir, transform=basic_transform)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# -----------------------------
# b) Show number of images
# -----------------------------
print("Training images:", len(train_dataset))
print("Testing images:", len(val_dataset))

# -----------------------------
# c) Plot some images
# -----------------------------
def imshow(img, title=''):
    img = img / 2 + 0.5  # unnormalize if needed
    npimg = img.numpy()
    plt.imshow(np.transpose(npimg, (1,2,0)))
    plt.title(title)
    plt.show()

dataiter = iter(train_loader)
images, labels = next(dataiter)
imshow(torchvision.utils.make_grid(images[:4]), 
       title=[train_dataset.classes[i] for i in labels[:4]])

# -----------------------------
# d) Image augmentation
# -----------------------------
augmented_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(contrast=0.5),
    transforms.ToTensor(),
])

train_dataset_aug = datasets.ImageFolder(train_dir, transform=augmented_transforms)
train_loader_aug = DataLoader(train_dataset_aug, batch_size=BATCH_SIZE, shuffle=True)

# -----------------------------
# e) Show number of images after augmentation
# -----------------------------
# Note: ImageFolder still counts same number, augmentation is applied on-the-fly
print("Training images after augmentation (applied on-the-fly):", len(train_dataset_aug))
print("Testing images remain:", len(val_dataset))

# -----------------------------
# f) Normalizing the data (already included in transforms)
# -----------------------------
# If desired, can add normalization to transforms:
normalized_transforms = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(contrast=0.5),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])

# -----------------------------
# g) Build a CNN for training
# -----------------------------
num_classes = len(train_dataset.classes)
model = models.resnet18(pretrained=True)
for param in model.parameters():
    param.requires_grad = False  # freeze base layers
model.fc = nn.Sequential(
    nn.Linear(model.fc.in_features, 256),
    nn.ReLU(),
    nn.Dropout(0.5),
    nn.Linear(256, num_classes)
)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.fc.parameters(), lr=1e-4)

# -----------------------------
# h) Training loop function
# -----------------------------
def train_model(model, train_loader, val_loader, epochs):
    train_acc_history, val_acc_history = [], []
    for epoch in range(epochs):
        # Training
        model.train()
        correct, total = 0, 0
        for imgs, labels in train_loader:
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            _, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
        train_acc = correct / total
        train_acc_history.append(train_acc)
        
        # Validation
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for imgs, labels in val_loader:
                outputs = model(imgs)
                _, preds = torch.max(outputs, 1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)
        val_acc = correct / total
        val_acc_history.append(val_acc)
        print(f"Epoch {epoch+1}/{epochs} - Train Acc: {train_acc:.4f}, Val Acc: {val_acc:.4f}")
    return train_acc_history, val_acc_history

# -----------------------------
# i) Train on original dataset
# -----------------------------
print("Training on original dataset")
train_acc_orig, val_acc_orig = train_model(model, train_loader, val_loader, EPOCHS)

# -----------------------------
# j) Train on augmented dataset
# -----------------------------
print("Training on augmented dataset")
train_acc_aug, val_acc_aug = train_model(model, train_loader_aug, val_loader, EPOCHS)

# -----------------------------
# k) Compare accuracy
# -----------------------------
plt.plot(train_acc_orig, label='Train Acc Original')
plt.plot(val_acc_orig, label='Val Acc Original')
plt.plot(train_acc_aug, label='Train Acc Augmented')
plt.plot(val_acc_aug, label='Val Acc Augmented')
plt.legend()
plt.show()



Q7 — Edge detection (Canny) and Region Growing segmentation



Experiment 1: Canny edge detection (with steps)
import cv2

img = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)

# 1. Smoothing: Gaussian blur
blur = cv2.GaussianBlur(img, (5,5), 1.4)

# 2. Gradient : Sobel and compute magnitude & angle (for internal understanding)
gx = cv2.Sobel(blur, cv2.CV_64F, 1, 0, ksize=3)
gy = cv2.Sobel(blur, cv2.CV_64F, 0, 1, ksize=3)

# 3. Non-maximum suppression + double threshold + hysteresis are inside cv2.Canny
edges = cv2.Canny(blur, 50, 150)  # thresholds can be tuned

cv2.imshow('Edges', edges)
cv2.waitKey(0); cv2.destroyAllWindows()


Experiment 2: Region-growing segmentation (simple seed-based)

import numpy as np
import cv2
from collections import deque

def region_grow(img, seed, thresh=10):
    h,w = img.shape
    out = np.zeros((h,w), np.uint8)
    visited = np.zeros((h,w), np.bool_)
    seed_val = int(img[seed[1], seed[0]])
    q = deque([seed])
    visited[seed[1], seed[0]] = True
    out[seed[1], seed[0]] = 255
    while q:
        x,y = q.popleft()
        for dx in (-1,0,1):
            for dy in (-1,0,1):
                nx, ny = x+dx, y+dy
                if 0<=nx<w and 0<=ny<h and not visited[ny,nx]:
                    if abs(int(img[ny,nx]) - seed_val) <= thresh:
                        visited[ny,nx] = True
                        out[ny,nx] = 255
                        q.append((nx,ny))
    return out

img = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)
seed = (100,100)  # choose interactively in exam; explain how to pick
seg = region_grow(img, seed, thresh=15)
cv2.imshow('Segment', seg); cv2.waitKey(0)



requirements:

opencv-python
opencv-contrib-python
numpy
matplotlib
tensorflow
torch
torchvision
pillow
tqdm
'''