from setuptools import setup, find_packages
setup(
    name="cvsem",     # the package name on PyPI
    version="0.0.1",
    description="Small image processing helpers (assignment demo)",
    packages=find_packages(),
    python_requires=">=3.8",
)