
.. _ndx-multisubjects:

*****************
ndx-multisubjects
*****************

Version |release| |today|

.. .. contents::

.. include:: _format_auto_docs/format_spec_main.inc
