"""Validation tools - data quality checks, schema validation"""
