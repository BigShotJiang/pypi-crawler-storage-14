# Copyright (c) 2016 Adam Karpierz
# SPDX-License-Identifier: Zlib

__import__("pkg_about").about()
