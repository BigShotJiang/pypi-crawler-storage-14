"""Patch registry exports."""

from aiomoto.patches.core import CorePatcher


__all__ = ["CorePatcher"]
