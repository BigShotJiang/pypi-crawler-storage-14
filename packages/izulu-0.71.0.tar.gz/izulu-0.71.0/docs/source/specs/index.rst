Specifications
==============


``izulu`` bases on class definitions to provide handy instance creation.


.. toctree::
   :maxdepth: 2

   pillars
   mechanics
   toggles
   additional
   validations
