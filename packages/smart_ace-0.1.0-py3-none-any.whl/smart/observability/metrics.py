"""Metrics collection for smart-agent."""

import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any


@dataclass
class StepMetrics:
    """Metrics for a single step."""

    session_id: str
    step_index: int
    step_type: str
    duration: float
    tokens_used: int = 0
    cost: float = 0.0
    success: bool = True
    error: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)


class MetricsCollector:
    """Collects metrics for agent execution."""

    def __init__(self):
        """Initialize MetricsCollector."""
        self._metrics: List[StepMetrics] = []
        self._step_start_times: Dict[str, float] = {}

    def start_step(self, session_id: str, step_index: int) -> None:
        """Mark the start of a step.

        Args:
            session_id: Session ID
            step_index: Step index
        """
        key = f"{session_id}:{step_index}"
        self._step_start_times[key] = time.time()

    def record_step(
        self,
        step: Any,
        session_id: str,
        step_index: Optional[int] = None,
        cost: float = 0.0,
    ) -> None:
        """Record metrics for a step.

        Args:
            step: Step object
            session_id: Session ID
            step_index: Step index
            cost: Cost of the step
        """
        if step_index is None:
            step_index = len(self._metrics)

        key = f"{session_id}:{step_index}"
        start_time = self._step_start_times.pop(key, time.time())
        duration = time.time() - start_time

        metric = StepMetrics(
            session_id=session_id,
            step_index=step_index,
            step_type=type(step).__name__,
            duration=duration,
            tokens_used=getattr(step, "tokens_used", 0),
            cost=cost,
            success=not hasattr(step, "error"),
            error=getattr(step, "error", None),
            timestamp=datetime.now(),
        )
        self._metrics.append(metric)

    def get_session_metrics(self, session_id: str) -> List[StepMetrics]:
        """Get metrics for a session.

        Args:
            session_id: Session ID

        Returns:
            List of metrics
        """
        return [m for m in self._metrics if m.session_id == session_id]

    def get_summary(self, session_id: str) -> Dict[str, Any]:
        """Get summary metrics for a session.

        Args:
            session_id: Session ID

        Returns:
            Summary dict
        """
        metrics = self.get_session_metrics(session_id)

        if not metrics:
            return {
                "total_steps": 0,
                "total_duration": 0.0,
                "total_tokens": 0,
                "total_cost": 0.0,
                "success_rate": 0.0,
                "avg_step_duration": 0.0,
            }

        successful = sum(1 for m in metrics if m.success)

        return {
            "total_steps": len(metrics),
            "total_duration": sum(m.duration for m in metrics),
            "total_tokens": sum(m.tokens_used for m in metrics),
            "total_cost": sum(m.cost for m in metrics),
            "success_rate": successful / len(metrics) if metrics else 0.0,
            "avg_step_duration": sum(m.duration for m in metrics) / len(metrics)
            if metrics
            else 0.0,
        }

    def clear_metrics(self) -> None:
        """Clear all metrics."""
        self._metrics.clear()
        self._step_start_times.clear()

    def get_all_metrics(self) -> List[StepMetrics]:
        """Get all metrics.

        Returns:
            List of all metrics
        """
        return self._metrics.copy()
