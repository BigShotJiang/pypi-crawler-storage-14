"""Cost tracking for smart-agent."""

from typing import Dict, Any


class CostTracker:
    """Track costs per model with pricing data."""

    # Pricing per 1K tokens
    PRICING = {
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-3.5-turbo": {"input": 0.0015, "output": 0.002},
        "claude-3-opus": {"input": 0.015, "output": 0.075},
        "claude-3-sonnet": {"input": 0.003, "output": 0.015},
        "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
        "text-davinci-003": {"input": 0.02, "output": 0.02},
        "text-davinci-002": {"input": 0.02, "output": 0.02},
    }

    def __init__(self):
        """Initialize CostTracker."""
        self._custom_pricing: Dict[str, Dict[str, float]] = {}

    def set_pricing(self, model: str, input_cost: float, output_cost: float) -> None:
        """Set custom pricing for a model.

        Args:
            model: Model name
            input_cost: Cost per 1K input tokens
            output_cost: Cost per 1K output tokens
        """
        self._custom_pricing[model] = {"input": input_cost, "output": output_cost}

    def calculate_cost(
        self, model: str, input_tokens: int, output_tokens: int
    ) -> float:
        """Calculate cost for a model call.

        Args:
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens

        Returns:
            Cost in dollars
        """
        # Check custom pricing first
        pricing = self._custom_pricing.get(model)

        # Fall back to default pricing
        if not pricing:
            pricing = self.PRICING.get(model, {"input": 0, "output": 0})

        return (
            (input_tokens / 1000) * pricing["input"]
            + (output_tokens / 1000) * pricing["output"]
        )

    def get_available_models(self) -> list[str]:
        """Get list of models with known pricing.

        Returns:
            List of model names
        """
        return list(set(list(self.PRICING.keys()) + list(self._custom_pricing.keys())))
