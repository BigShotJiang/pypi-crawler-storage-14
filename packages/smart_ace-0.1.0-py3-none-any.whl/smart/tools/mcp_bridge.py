"""MCPBridge - Integration of MCP servers with SmartAgent.

Uses mcpadapt library and smolagents' native MCP support to connect
MCP servers and make their tools available to agents with full session
and metrics tracking.

Supports multiple transport protocols:
- Stdio (subprocess-based, local servers)
- Streamable HTTP (server-based, remote servers)
- SSE (legacy HTTP+EventStream)
"""

from typing import Optional, Union, Any, List, Dict
import logging

from smart.core.agent import SmartAgent
from smart.tools.manager import ToolManager

logger = logging.getLogger(__name__)


# Common MCP servers you can connect to
KNOWN_SERVERS = {
    "pubmed": {
        "name": "PubMed Search",
        "description": "Search PubMed medical literature",
        "stdio": {
            "command": "uvx",
            "args": ["pubmedmcp@0.1.3"],
        },
    },
    "github": {
        "name": "GitHub",
        "description": "GitHub repository access",
        "http": {
            "url": "http://localhost:3000/mcp",
            "transport": "streamable-http",
        },
    },
    "brave-search": {
        "name": "Brave Search",
        "description": "Web search via Brave Search API",
        "stdio": {
            "command": "uvx",
            "args": ["mcp-server-brave-search"],
        },
    },
    "filesystem": {
        "name": "Filesystem",
        "description": "Local file read/write operations",
        "stdio": {
            "command": "uvx",
            "args": ["mcp-server-filesystem"],
        },
    },
    "postgresql": {
        "name": "PostgreSQL",
        "description": "PostgreSQL database queries",
        "http": {
            "url": "http://localhost:3001/mcp",
            "transport": "streamable-http",
        },
    },
}


def create_stdio_server(
    command: str,
    args: Optional[List[str]] = None,
    env: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Create Stdio server parameters.

    Stdio servers run as subprocesses and communicate via stdin/stdout.
    Best for local, development, and self-contained tools.
    """
    return {
        "command": command,
        "args": args or [],
        "env": env,
    }


def create_http_server(
    url: str,
    transport: str = "streamable-http",
) -> Dict[str, str]:
    """Create HTTP server parameters.

    HTTP servers are network-based and can be hosted remotely.
    Best for cloud deployments and shared services.
    """
    if transport not in {"streamable-http", "sse"}:
        raise ValueError(
            f"Unsupported transport: {transport}. "
            f"Use 'streamable-http' or 'sse'"
        )

    return {
        "url": url,
        "transport": transport,
    }


def get_known_server(name: str) -> Optional[Dict[str, Any]]:
    """Get configuration for a known MCP server."""
    return KNOWN_SERVERS.get(name)


def list_known_servers() -> List[Dict[str, str]]:
    """List all known MCP servers."""
    return [
        {"name": k, "description": v["description"]}
        for k, v in KNOWN_SERVERS.items()
    ]


class MCPBridge:
    """Bridge between SmartAgent and MCP servers.

    Manages connections to MCP servers and integrates their tools with
    SmartAgent while maintaining session and metrics tracking.
    """

    def __init__(
        self,
        smart: SmartAgent,
        tool_manager: Optional[ToolManager] = None,
        structured_output: bool = False,
        adapter_kwargs: Optional[Dict[str, Any]] = None,
    ):
        """Initialize MCPBridge."""
        self.smart = smart
        self.tool_manager = tool_manager or ToolManager(smart)
        self.structured_output = structured_output
        self.adapter_kwargs = adapter_kwargs or {}
        self._mcp_client = None

    def connect_stdio(
        self,
        command: str,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        mcp_server_name: Optional[str] = None,
    ):
        """Connect to a Stdio-based MCP server (subprocess)."""
        try:
            from mcp import StdioServerParameters
        except ImportError:
            raise ImportError(
                "MCP Stdio transport requires 'mcp' package. "
                "Install with: uv add mcp"
            )

        server_params = StdioServerParameters(
            command=command,
            args=args or [],
            env=env,
        )
        return self._connect(server_params, mcp_server_name or "stdio")

    def connect_http(
        self,
        url: str,
        transport: str = "streamable-http",
        mcp_server_name: Optional[str] = None,
    ):
        """Connect to an HTTP-based MCP server."""
        if transport not in {"streamable-http", "sse"}:
            raise ValueError(
                f"Unsupported transport: {transport}. "
                f"Use 'streamable-http' or 'sse'"
            )

        server_params = {
            "url": url,
            "transport": transport,
        }
        return self._connect(server_params, mcp_server_name or "http")

    def _connect(self, server_params, mcp_server_name: str):
        """Internal method to connect to MCP server."""
        return _MCPContextManager(self, server_params, mcp_server_name)

    def get_mcp_tool_names(self) -> List[str]:
        """Get names of currently available MCP tools."""
        return self.tool_manager.get_tool_names(source="mcp")


class _MCPContextManager:
    """Context manager for MCP tool access.

    Handles connection lifecycle: connect on enter, disconnect on exit.
    Also manages MCP tool integration with SmartAgent via ToolManager.
    """

    def __init__(self, bridge: MCPBridge, server_params, mcp_server_name: str):
        self.bridge = bridge
        self.server_params = server_params
        self.mcp_server_name = mcp_server_name
        self.mcp_client = None
        self.tools = None

    def __enter__(self):
        """Connect to MCP server and add tools to agent."""
        try:
            from mcpadapt.core import MCPAdapt
            from mcpadapt.smolagents_adapter import SmolAgentsAdapter
        except ImportError:
            raise ImportError(
                "MCP integration requires 'mcpadapt' package. "
                "Install with: uv add mcpadapt"
            )

        try:
            # Create MCP client with smolagents adapter
            adapter = SmolAgentsAdapter(
                structured_output=self.bridge.structured_output
            )
            self.mcp_client = MCPAdapt(
                self.server_params,
                adapter,
                **self.bridge.adapter_kwargs,
            )

            # Connect and get tools
            self.tools = self.mcp_client.__enter__()

            # Add tools to agent via ToolManager
            self.bridge.tool_manager.add_mcp_tools(
                self.mcp_server_name,
                self.tools
            )

            logger.info(
                f"Connected to MCP server '{self.mcp_server_name}', "
                f"{len(self.tools)} tools available"
            )

            return self.tools

        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            raise

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Disconnect from MCP server and remove tools from agent."""
        try:
            # Remove MCP tools from agent via ToolManager
            self.bridge.tool_manager.remove_mcp_tools(self.mcp_server_name)

            # Disconnect from MCP server
            if self.mcp_client:
                self.mcp_client.__exit__(exc_type, exc_val, exc_tb)
                logger.info(f"Disconnected from MCP server '{self.mcp_server_name}'")

        except Exception as e:
            logger.error(f"Error disconnecting from MCP server: {e}")
            # Don't suppress the original exception
            if exc_type is None:
                raise

        return False  # Don't suppress exceptions


__all__ = [
    'MCPBridge',
    'create_stdio_server',
    'create_http_server',
    'get_known_server',
    'list_known_servers',
    'KNOWN_SERVERS',
]
