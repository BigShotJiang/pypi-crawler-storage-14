"""Tool management for SmartAgent.

Provides unified management of smolagents tools and MCP server tools,
with discovery, lifecycle management, and tool info tracking.
"""

from typing import Optional, List, Dict, Any, Union
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class ToolInfo:
    """Information about a tool."""

    name: str
    description: str
    source: str  # "smolagents" or "mcp"
    tool_object: Any  # The actual tool instance
    mcp_server: Optional[str] = None  # Which MCP server (if from MCP)
    metadata: Optional[Dict[str, Any]] = None  # Additional metadata


class ToolManager:
    """Unified manager for smolagents and MCP server tools.

    Features:
    - Manage both smolagents tools and MCP server tools
    - Tool discovery and info tracking
    - Safe tool lifecycle (add/remove)
    - Metadata and source tracking
    - Tool filtering and search

    Example:
        >>> from smart import create_smart
        >>> from smart.tools import ToolManager, create_stdio_server
        >>>
        >>> agent = create_smart("code", model=model)
        >>> manager = ToolManager(agent)
        >>>
        >>> # Add MCP tools
        >>> with manager.add_mcp_tools("pubmed", create_stdio_server(
        ...     command="uvx",
        ...     args=["pubmedmcp@0.1.3"]
        ... )) as tools:
        ...     result = agent.run("search PubMed for coronavirus")
        >>>
        >>> # Query tools
        >>> mcp_tools = manager.get_tools(source="mcp")
        >>> all_tools = manager.list_all()
    """

    def __init__(self, smart):
        """Initialize ToolManager.

        Args:
            smart: SmartAgent instance to manage tools for
        """
        self.smart = smart
        self._smolagent = smart._smolagent
        self._original_tools = None
        self._tool_registry: Dict[str, ToolInfo] = {}
        self._mcp_servers: Dict[str, Any] = {}  # Track MCP server connections

        # Register existing smolagents tools
        self._register_smolagents_tools()

    def _register_smolagents_tools(self) -> None:
        """Register all existing smolagents tools in the registry."""
        if hasattr(self._smolagent, 'tools'):
            for name, tool in self._smolagent.tools.items():
                info = ToolInfo(
                    name=name,
                    description=getattr(tool, 'description', ''),
                    source='smolagents',
                    tool_object=tool,
                )
                self._tool_registry[name] = info
                logger.debug(f"Registered smolagents tool: {name}")

    def add_mcp_tools(
        self,
        mcp_server_name: str,
        tools: List[Any],
    ) -> None:
        """Add tools from an MCP server.

        Args:
            mcp_server_name: Name/identifier of the MCP server
            tools: List of tool objects from MCP server

        Raises:
            ValueError: If tools is empty
        """
        if not tools:
            raise ValueError("Cannot add empty tool list")

        # Store original tools on first MCP connection
        if self._original_tools is None:
            self._original_tools = dict(self._smolagent.tools)

        # Add tools to agent and registry
        for tool in tools:
            tool_name = tool.name
            self._smolagent.tools[tool_name] = tool

            info = ToolInfo(
                name=tool_name,
                description=getattr(tool, 'description', ''),
                source='mcp',
                tool_object=tool,
                mcp_server=mcp_server_name,
            )
            self._tool_registry[tool_name] = info
            logger.info(f"Added MCP tool: {tool_name} (from {mcp_server_name})")

        self._mcp_servers[mcp_server_name] = {
            'tool_count': len(tools),
            'tool_names': [t.name for t in tools],
        }
        logger.info(
            f"Added {len(tools)} tools from MCP server '{mcp_server_name}'"
        )

    def remove_mcp_tools(self, mcp_server_name: Optional[str] = None) -> None:
        """Remove MCP tools (optionally from specific server).

        Args:
            mcp_server_name: If specified, remove only from this server.
                           If None, remove all MCP tools.
        """
        if self._original_tools is None:
            logger.warning("No MCP tools to remove")
            return

        # Remove from registry and agent
        tools_to_remove = []
        for name, info in list(self._tool_registry.items()):
            if info.source == 'mcp':
                if mcp_server_name is None or info.mcp_server == mcp_server_name:
                    tools_to_remove.append(name)

        for name in tools_to_remove:
            if name in self._smolagent.tools:
                del self._smolagent.tools[name]
            del self._tool_registry[name]
            logger.info(f"Removed tool: {name}")

        if mcp_server_name is None:
            # All MCP tools removed, restore to original
            self._smolagent.tools = self._original_tools
            self._original_tools = None
            self._mcp_servers.clear()
            logger.info("Removed all MCP tools, restored original tools")
        elif mcp_server_name in self._mcp_servers:
            del self._mcp_servers[mcp_server_name]
            logger.info(f"Removed tools from MCP server '{mcp_server_name}'")

    def get_tool(self, name: str) -> Optional[ToolInfo]:
        """Get info about a specific tool.

        Args:
            name: Tool name

        Returns:
            ToolInfo or None if not found
        """
        return self._tool_registry.get(name)

    def get_tools(self, source: Optional[str] = None) -> List[ToolInfo]:
        """Get tools filtered by source.

        Args:
            source: Filter by source ("smolagents", "mcp", or None for all)

        Returns:
            List of ToolInfo objects
        """
        tools = list(self._tool_registry.values())
        if source:
            tools = [t for t in tools if t.source == source]
        return tools

    def get_mcp_tools(self, mcp_server_name: Optional[str] = None) -> List[ToolInfo]:
        """Get MCP tools (optionally from specific server).

        Args:
            mcp_server_name: Filter by MCP server name (or None for all)

        Returns:
            List of ToolInfo objects from MCP
        """
        tools = [t for t in self._tool_registry.values() if t.source == 'mcp']
        if mcp_server_name:
            tools = [t for t in tools if t.mcp_server == mcp_server_name]
        return tools

    def get_smolagents_tools(self) -> List[ToolInfo]:
        """Get all smolagents (built-in) tools.

        Returns:
            List of ToolInfo objects from smolagents
        """
        return [t for t in self._tool_registry.values() if t.source == 'smolagents']

    def list_all(self) -> List[ToolInfo]:
        """Get all registered tools.

        Returns:
            List of all ToolInfo objects
        """
        return list(self._tool_registry.values())

    def get_tool_names(self, source: Optional[str] = None) -> List[str]:
        """Get tool names filtered by source.

        Args:
            source: Filter by source ("smolagents", "mcp", or None for all)

        Returns:
            List of tool names
        """
        return [t.name for t in self.get_tools(source=source)]

    def search_tools(self, query: str) -> List[ToolInfo]:
        """Search tools by name or description.

        Args:
            query: Search query (case-insensitive)

        Returns:
            List of matching ToolInfo objects
        """
        query_lower = query.lower()
        return [
            t for t in self._tool_registry.values()
            if query_lower in t.name.lower()
            or query_lower in t.description.lower()
        ]

    def get_mcp_servers(self) -> Dict[str, Dict[str, Any]]:
        """Get information about connected MCP servers.

        Returns:
            Dict mapping server names to their info (tool count, names, etc.)
        """
        return dict(self._mcp_servers)

    def summary(self) -> Dict[str, Any]:
        """Get summary of tool status.

        Returns:
            Dict with counts and server info
        """
        tools = self.list_all()
        return {
            'total_tools': len(tools),
            'smolagents_tools': len(self.get_smolagents_tools()),
            'mcp_tools': len(self.get_mcp_tools()),
            'mcp_servers': self.get_mcp_servers(),
            'tool_names': [t.name for t in tools],
        }


__all__ = ['ToolManager', 'ToolInfo']
