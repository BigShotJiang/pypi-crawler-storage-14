"""Tool management for SmartAgent.

Provides unified management of:
- Built-in smolagents tools
- MCP (Model Context Protocol) server tools
- Custom tools and tool lifecycle

Includes ToolManager for seamless tool integration and discovery.
"""

from smart.tools.manager import ToolManager, ToolInfo
from smart.tools.mcp_bridge import (
    MCPBridge,
    create_stdio_server,
    create_http_server,
    get_known_server,
    list_known_servers,
)

__all__ = [
    "ToolManager",
    "ToolInfo",
    "MCPBridge",
    "create_stdio_server",
    "create_http_server",
    "get_known_server",
    "list_known_servers",
]
