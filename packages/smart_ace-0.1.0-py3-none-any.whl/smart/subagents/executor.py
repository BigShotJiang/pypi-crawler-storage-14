"""Subagent executor for spawning and managing agent execution.

Handles execution of subagents with task decomposition, result aggregation,
and lifecycle management.
"""

from enum import Enum
from typing import Optional, Dict, Any, List, Callable
import asyncio
import logging
import time
from dataclasses import asdict

from smart.subagents.base import (
    SubagentConfig,
    SubagentContext,
    SubagentResult,
    SubagentManager,
    SubagentRole,
)

logger = logging.getLogger(__name__)


class ExecutionMode(Enum):
    """Execution mode for subagent."""
    SEQUENTIAL = "sequential"  # Execute subagents one by one
    PARALLEL = "parallel"  # Execute subagents in parallel
    ROUND_ROBIN = "round_robin"  # Execute with time slicing


class SubagentExecutor:
    """Executes subagents with decomposition and aggregation.

    Handles:
    - Task decomposition into subagent tasks
    - Parallel/sequential execution
    - Result aggregation
    - Context isolation
    - Error handling
    """

    def __init__(
        self,
        agent_factory: Callable,
        session_manager: Optional[Any] = None,
        checkpoint_manager: Optional[Any] = None,
    ):
        """Initialize executor.

        Args:
            agent_factory: Function to create SmartAgent instances
            session_manager: Optional session manager
            checkpoint_manager: Optional checkpoint manager
        """
        self.agent_factory = agent_factory
        self.session_manager = session_manager
        self.checkpoint_manager = checkpoint_manager
        self.managers: Dict[str, SubagentManager] = {}

    def create_manager(self, session_id: str) -> SubagentManager:
        """Create subagent manager for session.

        Args:
            session_id: Session ID

        Returns:
            SubagentManager
        """
        manager = SubagentManager(session_id)
        self.managers[session_id] = manager
        return manager

    def get_manager(self, session_id: str) -> Optional[SubagentManager]:
        """Get subagent manager for session.

        Args:
            session_id: Session ID

        Returns:
            SubagentManager or None
        """
        return self.managers.get(session_id)

    def spawn_subagent(
        self,
        parent_context: Optional[SubagentContext],
        config: SubagentConfig,
        parent_task: str,
        session_id: str,
        parent_result: Optional[Any] = None,
        shared_state: Optional[Dict[str, Any]] = None,
    ) -> SubagentContext:
        """Spawn a child subagent.

        Args:
            parent_context: Parent's SubagentContext (None for root)
            config: Subagent configuration
            parent_task: Parent task to decompose
            session_id: Session ID
            parent_result: Result from parent
            shared_state: Shared state dict

        Returns:
            SubagentContext for new subagent

        Raises:
            RuntimeError: If spawn conditions violated
        """
        # Get or create manager
        manager = self.managers.get(session_id)
        if not manager:
            manager = self.create_manager(session_id)

        # Create subagent context
        parent_id = parent_context.subagent_id if parent_context else None
        context = manager.create_subagent(
            parent_id=parent_id,
            config=config,
            parent_task=parent_task,
            parent_result=parent_result,
            shared_state=shared_state or {},
        )

        return context

    def decompose_task(
        self,
        task: str,
        num_subtasks: int = 2,
    ) -> List[str]:
        """Decompose task into subtasks.

        Simple strategy: split task by sentences and distribute.

        Args:
            task: Task to decompose
            num_subtasks: Number of subtasks

        Returns:
            List of subtasks
        """
        # Simple sentence-based splitting
        sentences = task.split(". ")
        if len(sentences) <= num_subtasks:
            return sentences

        # Distribute sentences across subtasks
        subtasks = [[] for _ in range(num_subtasks)]
        for i, sentence in enumerate(sentences):
            subtasks[i % num_subtasks].append(sentence)

        return [". ".join(s) + "." for s in subtasks if s]

    def execute_subagent(
        self,
        subagent_context: SubagentContext,
        task: str,
    ) -> SubagentResult:
        """Execute a single subagent.

        Args:
            subagent_context: SubagentContext for execution
            task: Task to execute

        Returns:
            SubagentResult
        """
        manager = self.managers.get(subagent_context.session_id)
        if not manager:
            return SubagentResult(
                subagent_id=subagent_context.subagent_id,
                success=False,
                output=None,
                error="No subagent manager for session",
            )

        # Check for infinite loops
        if manager.check_infinite_loop(subagent_context.subagent_id):
            return SubagentResult(
                subagent_id=subagent_context.subagent_id,
                success=False,
                output=None,
                error="Infinite loop detected in subagent execution",
            )

        manager.start_execution(subagent_context.subagent_id)
        start_time = time.time()

        try:
            # Create subagent instance
            agent = self.agent_factory(
                model=subagent_context.config.model,
                session_id=subagent_context.session_id,
            )

            # Execute task
            output = agent.run(task, session_id=subagent_context.session_id)

            duration = time.time() - start_time

            # Create result
            result = SubagentResult(
                subagent_id=subagent_context.subagent_id,
                success=True,
                output=output,
                duration_seconds=duration,
                steps_executed=0,  # Would be populated from agent metrics
                metadata={
                    "config": asdict(subagent_context.config),
                    "depth": subagent_context.depth,
                    "parent_id": subagent_context.parent_id,
                },
            )

            manager.register_result(result)
            return result

        except Exception as e:
            duration = time.time() - start_time

            result = SubagentResult(
                subagent_id=subagent_context.subagent_id,
                success=False,
                output=None,
                error=str(e),
                duration_seconds=duration,
                metadata={"exception_type": type(e).__name__},
            )

            manager.register_result(result)
            logger.error(f"Subagent execution failed: {e}")
            return result

        finally:
            manager.end_execution(subagent_context.subagent_id)

    async def execute_subagent_async(
        self,
        subagent_context: SubagentContext,
        task: str,
    ) -> SubagentResult:
        """Execute subagent asynchronously.

        Args:
            subagent_context: SubagentContext for execution
            task: Task to execute

        Returns:
            SubagentResult
        """
        # Run sync execution in thread pool
        return await asyncio.to_thread(
            self.execute_subagent,
            subagent_context,
            task,
        )

    def execute_parallel(
        self,
        subagent_configs: List[SubagentConfig],
        subtasks: List[str],
        session_id: str,
        parent_task: str,
    ) -> List[SubagentResult]:
        """Execute multiple subagents in parallel.

        Args:
            subagent_configs: List of subagent configs
            subtasks: List of subtasks to execute
            session_id: Session ID
            parent_task: Parent task

        Returns:
            List of SubagentResults
        """
        results = []

        for config, task in zip(subagent_configs, subtasks):
            context = self.spawn_subagent(
                parent_context=None,
                config=config,
                parent_task=parent_task,
                session_id=session_id,
            )
            result = self.execute_subagent(context, task)
            results.append(result)

        return results

    def execute_sequential(
        self,
        subagent_configs: List[SubagentConfig],
        subtasks: List[str],
        session_id: str,
        parent_task: str,
    ) -> List[SubagentResult]:
        """Execute subagents sequentially with result chaining.

        Args:
            subagent_configs: List of subagent configs
            subtasks: List of subtasks
            session_id: Session ID
            parent_task: Parent task

        Returns:
            List of SubagentResults
        """
        results = []
        previous_result = None

        for config, task in zip(subagent_configs, subtasks):
            context = self.spawn_subagent(
                parent_context=None,
                config=config,
                parent_task=parent_task,
                session_id=session_id,
                parent_result=previous_result,
            )

            result = self.execute_subagent(context, task)
            results.append(result)
            previous_result = result

            # If one fails, stop chain
            if not result.success:
                break

        return results

    def aggregate_results(
        self,
        results: List[SubagentResult],
        strategy: str = "concat",
    ) -> Dict[str, Any]:
        """Aggregate subagent results.

        Args:
            results: List of SubagentResults
            strategy: Aggregation strategy (concat, merge, list)

        Returns:
            Aggregated result dict
        """
        if strategy == "concat":
            # Concatenate outputs
            outputs = []
            for result in results:
                if result.success and result.output:
                    outputs.append(str(result.output))
            return {
                "combined_output": "\n".join(outputs),
                "all_successful": all(r.success for r in results),
                "total_duration": sum(r.duration_seconds for r in results),
            }

        elif strategy == "merge":
            # Merge dict outputs
            merged = {}
            for result in results:
                if result.success and isinstance(result.output, dict):
                    merged.update(result.output)
            return merged

        else:  # list
            # Return list of outputs
            return {
                "outputs": [r.output for r in results if r.success],
                "errors": [r.error for r in results if not r.success],
                "results": [
                    {
                        "subagent_id": r.subagent_id,
                        "success": r.success,
                        "output": r.output,
                    }
                    for r in results
                ],
            }

    def cleanup_session(self, session_id: str) -> None:
        """Cleanup subagent manager for session.

        Args:
            session_id: Session ID to cleanup
        """
        manager = self.managers.pop(session_id, None)
        if manager:
            manager.cleanup()
            logger.debug(f"Cleaned up subagent manager for session {session_id}")


__all__ = [
    "ExecutionMode",
    "SubagentExecutor",
]
