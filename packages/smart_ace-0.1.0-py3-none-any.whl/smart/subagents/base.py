"""Base classes for subagent system.

Defines configuration, context, results, and manager for hierarchical agents.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from enum import Enum
import logging
import uuid

logger = logging.getLogger(__name__)


class SubagentRole(Enum):
    """Role of subagent in hierarchy."""
    SPECIALIST = "specialist"  # Executes specific task
    COORDINATOR = "coordinator"  # Coordinates other agents
    MANAGER = "manager"  # Manages team of subagents
    SUPERVISOR = "supervisor"  # Supervises and delegates to specialists


@dataclass
class SubagentConfig:
    """Configuration for spawning a subagent.

    Attributes:
        name: Human-readable subagent name
        role: SubagentRole (specialist, coordinator, manager)
        model: Optional model override for subagent
        max_depth: Maximum nesting depth (default 5)
        allow_nested_spawning: Whether subagent can spawn children
        timeout_seconds: Execution timeout
        context_isolation: Isolate subagent context from parent
        memory_limit_mb: Optional memory limit
        tags: Metadata tags for categorization
    """
    name: str
    role: SubagentRole = SubagentRole.SPECIALIST
    model: Optional[str] = None
    max_depth: int = 5
    allow_nested_spawning: bool = True
    timeout_seconds: Optional[int] = None
    context_isolation: bool = True
    memory_limit_mb: Optional[int] = None
    tags: List[str] = field(default_factory=list)


@dataclass
class SubagentContext:
    """Context provided to subagent during execution.

    Attributes:
        subagent_id: Unique ID for this subagent
        parent_id: ID of parent agent (None if root)
        depth: Nesting depth (0 for root)
        session_id: Session inherited from parent
        parent_task: Task from parent agent
        config: Subagent configuration
        parent_result: Optional result from parent
        shared_state: Shared state with parent/siblings
    """
    subagent_id: str
    parent_id: Optional[str]
    depth: int
    session_id: str
    parent_task: str
    config: SubagentConfig
    parent_result: Optional[Any] = None
    shared_state: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SubagentResult:
    """Result of subagent execution.

    Attributes:
        subagent_id: ID of subagent that produced result
        success: Whether execution succeeded
        output: Execution output/result
        error: Error message if failed
        duration_seconds: Execution duration
        steps_executed: Number of steps executed
        children_results: Results from child subagents
        metadata: Additional execution metadata
    """
    subagent_id: str
    success: bool
    output: Any
    error: Optional[str] = None
    duration_seconds: float = 0.0
    steps_executed: int = 0
    children_results: List['SubagentResult'] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class SubagentManager:
    """Manages subagent lifecycle and coordination.

    Handles:
    - Subagent spawning with depth limits
    - Context isolation
    - Result aggregation
    - State sharing
    - Resource cleanup
    """

    def __init__(
        self,
        root_session_id: str,
        max_total_depth: int = 5,
    ):
        """Initialize subagent manager.

        Args:
            root_session_id: Root session ID
            max_total_depth: Maximum nesting depth across all agents
        """
        self.root_session_id = root_session_id
        self.max_total_depth = max_total_depth
        self.subagents: Dict[str, Dict[str, Any]] = {}
        self.results: Dict[str, SubagentResult] = {}
        self._execution_stack: List[str] = []  # Track execution stack for infinite loop detection

    def create_subagent(
        self,
        parent_id: Optional[str],
        config: SubagentConfig,
        parent_task: str,
        parent_result: Optional[Any] = None,
        shared_state: Optional[Dict[str, Any]] = None,
    ) -> SubagentContext:
        """Create a subagent context.

        Args:
            parent_id: ID of parent agent
            config: Subagent configuration
            parent_task: Task from parent
            parent_result: Result from parent (if any)
            shared_state: Shared state to inherit

        Returns:
            SubagentContext for the new subagent

        Raises:
            RuntimeError: If depth limits exceeded
        """
        # Calculate depth
        depth = 0
        if parent_id and parent_id in self.subagents:
            parent_depth = self.subagents[parent_id].get("depth", 0)
            depth = parent_depth + 1

        # Check depth limits
        if depth > self.max_total_depth:
            raise RuntimeError(
                f"Subagent depth {depth} exceeds maximum {self.max_total_depth}"
            )
        if depth > config.max_depth:
            raise RuntimeError(
                f"Subagent depth {depth} exceeds config maximum {config.max_depth}"
            )

        # Check if parent is allowed to spawn children
        if parent_id and parent_id in self.subagents:
            parent_config = self.subagents[parent_id].get("config")
            if parent_config and not parent_config.allow_nested_spawning:
                raise RuntimeError(
                    f"Parent subagent {parent_id} is not allowed to spawn children"
                )

        # Create context
        subagent_id = str(uuid.uuid4())
        context = SubagentContext(
            subagent_id=subagent_id,
            parent_id=parent_id,
            depth=depth,
            session_id=self.root_session_id,
            parent_task=parent_task,
            config=config,
            parent_result=parent_result,
            shared_state=shared_state or {},
        )

        # Track subagent
        self.subagents[subagent_id] = {
            "context": context,
            "depth": depth,
            "parent_id": parent_id,
            "config": config,
        }

        logger.debug(
            f"Created subagent {config.name} "
            f"(id: {subagent_id[:8]}..., depth: {depth})"
        )

        return context

    def register_result(
        self,
        result: SubagentResult,
    ) -> None:
        """Register execution result for a subagent.

        Args:
            result: SubagentResult to register
        """
        self.results[result.subagent_id] = result
        logger.debug(
            f"Registered result for subagent {result.subagent_id[:8]}... "
            f"(success: {result.success})"
        )

    def start_execution(self, subagent_id: str) -> None:
        """Mark start of subagent execution.

        Args:
            subagent_id: ID of subagent starting execution
        """
        self._execution_stack.append(subagent_id)

    def end_execution(self, subagent_id: str) -> None:
        """Mark end of subagent execution.

        Args:
            subagent_id: ID of subagent ending execution
        """
        if self._execution_stack and self._execution_stack[-1] == subagent_id:
            self._execution_stack.pop()

    def check_infinite_loop(self, subagent_id: str) -> bool:
        """Check if subagent is in infinite loop.

        Args:
            subagent_id: ID of subagent to check

        Returns:
            True if infinite loop detected, False otherwise
        """
        # Same subagent appearing more than once suggests loop
        count = self._execution_stack.count(subagent_id)
        return count > 1

    def get_subagent_info(self, subagent_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a subagent.

        Args:
            subagent_id: ID of subagent

        Returns:
            Dict with subagent info or None
        """
        return self.subagents.get(subagent_id)

    def get_result(self, subagent_id: str) -> Optional[SubagentResult]:
        """Get result for a subagent.

        Args:
            subagent_id: ID of subagent

        Returns:
            SubagentResult or None
        """
        return self.results.get(subagent_id)

    def get_children(self, parent_id: str) -> List[str]:
        """Get IDs of child subagents.

        Args:
            parent_id: ID of parent subagent

        Returns:
            List of child subagent IDs
        """
        return [
            sub_id
            for sub_id, info in self.subagents.items()
            if info.get("parent_id") == parent_id
        ]

    def get_execution_tree(self) -> Dict[str, Any]:
        """Get execution tree structure.

        Returns:
            Tree representation of subagent hierarchy
        """
        tree = {
            "total_subagents": len(self.subagents),
            "total_results": len(self.results),
            "max_depth": max(
                (info.get("depth", 0) for info in self.subagents.values()),
                default=0,
            ),
            "subagents": self.subagents,
            "results": {
                sub_id: {
                    "success": result.success,
                    "duration": result.duration_seconds,
                    "steps": result.steps_executed,
                    "children": len(result.children_results),
                }
                for sub_id, result in self.results.items()
            },
        }
        return tree

    def cleanup(self) -> None:
        """Cleanup subagent resources.

        Called when session ends to clean up subagent state.
        """
        logger.debug(f"Cleaning up {len(self.subagents)} subagents")
        self.subagents.clear()
        self.results.clear()
        self._execution_stack.clear()


__all__ = [
    "SubagentRole",
    "SubagentConfig",
    "SubagentContext",
    "SubagentResult",
    "SubagentManager",
]
