"""Subagent delegation system for hierarchical agent teams.

Enables spawning child agents with task decomposition, context isolation,
and result aggregation. Supports deep hierarchies with safeguards against
infinite nesting.

Features:
- Hierarchical agent spawning (2+ levels)
- Automatic context isolation
- Task decomposition and result aggregation
- Infinite nesting prevention
- Parent-child communication
"""

from smart.subagents.base import (
    SubagentRole,
    SubagentConfig,
    SubagentContext,
    SubagentResult,
    SubagentManager,
)
from smart.subagents.executor import (
    SubagentExecutor,
    ExecutionMode,
)
from smart.subagents.delegation import (
    DelegationStrategy,
    SpecialistCapability,
    SpecialistAgent,
    DelegationTask,
    DelegationResult,
    DelegationToolFactory,
    SupervisorDelegationManager,
)

__all__ = [
    "SubagentRole",
    "SubagentConfig",
    "SubagentContext",
    "SubagentResult",
    "SubagentManager",
    "SubagentExecutor",
    "ExecutionMode",
    "DelegationStrategy",
    "SpecialistCapability",
    "SpecialistAgent",
    "DelegationTask",
    "DelegationResult",
    "DelegationToolFactory",
    "SupervisorDelegationManager",
]
