"""Delegation system for supervisor-based task distribution.

Enables a SUPERVISOR agent to decompose tasks, delegate to specialists,
and coordinate results. Integrates with SubagentManager for hierarchical execution.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable
from enum import Enum
import logging
import json

from smart.subagents.base import (
    SubagentRole,
    SubagentConfig,
    SubagentContext,
    SubagentResult,
)

logger = logging.getLogger(__name__)


class DelegationStrategy(Enum):
    """Task delegation strategy."""

    ROUND_ROBIN = "round_robin"  # Distribute evenly across specialists
    CAPABILITY_MATCH = "capability_match"  # Match task to specialist capabilities
    LOAD_BALANCED = "load_balanced"  # Delegate to least loaded specialist
    SEQUENTIAL = "sequential"  # Delegate to specialists in order


@dataclass
class SpecialistCapability:
    """Capability of a specialist agent.

    Attributes:
        name: Capability name (e.g., "data_analysis", "code_generation")
        description: Human-readable description
        tags: Tags for categorization and matching
        confidence: Confidence level in this capability (0.0-1.0)
    """

    name: str
    description: str
    tags: List[str] = field(default_factory=list)
    confidence: float = 1.0


@dataclass
class SpecialistAgent:
    """Specialist agent configuration and metadata.

    Attributes:
        agent_id: Unique agent identifier
        name: Human-readable name
        role: SubagentRole.SPECIALIST
        capabilities: List of specialist capabilities
        load: Current load/workload (for load balancing)
        max_parallel_tasks: Maximum tasks to execute in parallel
    """

    agent_id: str
    name: str
    role: SubagentRole = SubagentRole.SPECIALIST
    capabilities: List[SpecialistCapability] = field(default_factory=list)
    load: int = 0
    max_parallel_tasks: int = 5


@dataclass
class DelegationTask:
    """Task to be delegated to a specialist.

    Attributes:
        task_id: Unique task identifier
        description: Task description
        required_capabilities: List of required capability names
        priority: Task priority (0-100)
        deadline_seconds: Optional deadline for execution
        context: Task context (inputs, parameters)
    """

    task_id: str
    description: str
    required_capabilities: List[str] = field(default_factory=list)
    priority: int = 50
    deadline_seconds: Optional[int] = None
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DelegationResult:
    """Result of delegation execution.

    Attributes:
        task_id: ID of delegated task
        specialist_id: ID of specialist who executed task
        success: Whether execution succeeded
        output: Execution output
        error: Error message if failed
        duration_seconds: Execution duration
        metrics: Execution metrics
    """

    task_id: str
    specialist_id: str
    success: bool
    output: Any = None
    error: Optional[str] = None
    duration_seconds: float = 0.0
    metrics: Dict[str, Any] = field(default_factory=dict)


class DelegationToolFactory:
    """Factory for creating delegation tools for agents.

    Provides tools that allow agents to delegate tasks to specialists.
    """

    def __init__(self, delegation_manager: "SupervisorDelegationManager"):
        """Initialize delegation tool factory.

        Args:
            delegation_manager: DelegationManager instance
        """
        self.delegation_manager = delegation_manager

    def create_delegation_tool(self) -> Callable:
        """Create a delegation tool for use by supervisor agents.

        Returns:
            Callable tool that accepts task description and returns result
        """

        def delegate_task(
            description: str,
            required_capabilities: Optional[List[str]] = None,
            priority: int = 50,
        ) -> Dict[str, Any]:
            """Delegate a task to appropriate specialist.

            Args:
                description: Task description
                required_capabilities: List of required capabilities
                priority: Task priority (0-100)

            Returns:
                Dict with delegation result
            """
            task = DelegationTask(
                task_id=self.delegation_manager._generate_task_id(),
                description=description,
                required_capabilities=required_capabilities or [],
                priority=priority,
            )

            result = self.delegation_manager.delegate(task)

            return {
                "success": result.success,
                "output": result.output,
                "specialist_id": result.specialist_id,
                "duration": result.duration_seconds,
                "error": result.error,
            }

        return delegate_task

    def create_specialist_registration_tool(self) -> Callable:
        """Create tool to register specialist agents.

        Returns:
            Callable tool for registering specialists
        """

        def register_specialist(
            agent_id: str,
            name: str,
            capabilities: List[Dict[str, Any]],
        ) -> Dict[str, Any]:
            """Register a specialist agent.

            Args:
                agent_id: Unique agent ID
                name: Human-readable name
                capabilities: List of capability dicts

            Returns:
                Registration result
            """
            cap_objs = [
                SpecialistCapability(
                    name=cap.get("name", ""),
                    description=cap.get("description", ""),
                    tags=cap.get("tags", []),
                    confidence=cap.get("confidence", 1.0),
                )
                for cap in capabilities
            ]

            specialist = SpecialistAgent(
                agent_id=agent_id,
                name=name,
                capabilities=cap_objs,
            )

            self.delegation_manager.register_specialist(specialist)

            return {
                "success": True,
                "message": f"Registered specialist {name} ({agent_id[:8]}...)",
                "capabilities_registered": len(cap_objs),
            }

        return register_specialist

    def create_query_specialists_tool(self) -> Callable:
        """Create tool to query available specialists.

        Returns:
            Callable tool for querying specialists
        """

        def query_specialists(
            capability: Optional[str] = None,
        ) -> Dict[str, Any]:
            """Query available specialists.

            Args:
                capability: Optional capability to filter by

            Returns:
                List of specialist information
            """
            specialists = self.delegation_manager.get_specialists()

            if capability:
                specialists = [
                    s
                    for s in specialists
                    if any(c.name == capability for c in s.capabilities)
                ]

            return {
                "total_specialists": len(specialists),
                "specialists": [
                    {
                        "agent_id": s.agent_id,
                        "name": s.name,
                        "load": s.load,
                        "capabilities": [
                            {
                                "name": c.name,
                                "description": c.description,
                                "confidence": c.confidence,
                            }
                            for c in s.capabilities
                        ],
                    }
                    for s in specialists
                ],
            }

        return query_specialists


class SupervisorDelegationManager:
    """Manages task delegation from supervisor to specialists.

    Handles specialist registration, task delegation, capability matching,
    and result aggregation.
    """

    def __init__(
        self,
        delegation_strategy: DelegationStrategy = DelegationStrategy.CAPABILITY_MATCH,
    ):
        """Initialize delegation manager.

        Args:
            delegation_strategy: Strategy for delegating tasks
        """
        self.delegation_strategy = delegation_strategy
        self.specialists: Dict[str, SpecialistAgent] = {}
        self.task_history: Dict[str, DelegationResult] = {}
        self._task_counter = 0
        self._results_queue: List[DelegationResult] = []

    def register_specialist(self, specialist: SpecialistAgent) -> None:
        """Register a specialist agent.

        Args:
            specialist: SpecialistAgent to register
        """
        self.specialists[specialist.agent_id] = specialist
        logger.debug(
            f"Registered specialist {specialist.name} "
            f"with {len(specialist.capabilities)} capabilities"
        )

    def unregister_specialist(self, agent_id: str) -> bool:
        """Unregister a specialist agent.

        Args:
            agent_id: ID of specialist to unregister

        Returns:
            True if unregistered, False if not found
        """
        if agent_id in self.specialists:
            self.specialists.pop(agent_id)
            logger.debug(f"Unregistered specialist {agent_id[:8]}...")
            return True
        return False

    def delegate(self, task: DelegationTask) -> DelegationResult:
        """Delegate a task to appropriate specialist.

        Args:
            task: DelegationTask to delegate

        Returns:
            DelegationResult from specialist execution
        """
        # Find suitable specialist
        specialist_id = self._select_specialist(task)

        if not specialist_id:
            return DelegationResult(
                task_id=task.task_id,
                specialist_id="",
                success=False,
                error=f"No suitable specialist found for task: {task.description}",
            )

        # Update load
        specialist = self.specialists[specialist_id]
        specialist.load += 1

        try:
            # Execute task (in real implementation, would call agent.run())
            output = self._execute_task(specialist, task)

            result = DelegationResult(
                task_id=task.task_id,
                specialist_id=specialist_id,
                success=True,
                output=output,
                metrics={
                    "specialist_load": specialist.load,
                    "priority": task.priority,
                },
            )

        except Exception as e:
            result = DelegationResult(
                task_id=task.task_id,
                specialist_id=specialist_id,
                success=False,
                error=str(e),
                metrics={"error_type": type(e).__name__},
            )

        finally:
            # Update load
            specialist.load = max(0, specialist.load - 1)

        # Store result
        self.task_history[task.task_id] = result
        self._results_queue.append(result)

        logger.debug(
            f"Delegated task {task.task_id[:8]}... to {specialist.name} "
            f"(success: {result.success})"
        )

        return result

    def _select_specialist(self, task: DelegationTask) -> Optional[str]:
        """Select specialist for task based on strategy.

        Args:
            task: Task to select specialist for

        Returns:
            ID of selected specialist or None
        """
        if not self.specialists:
            return None

        if self.delegation_strategy == DelegationStrategy.CAPABILITY_MATCH:
            return self._select_by_capability(task)
        elif self.delegation_strategy == DelegationStrategy.LOAD_BALANCED:
            return self._select_by_load()
        elif self.delegation_strategy == DelegationStrategy.ROUND_ROBIN:
            return self._select_round_robin()
        else:  # SEQUENTIAL
            return list(self.specialists.keys())[0]

    def _select_by_capability(self, task: DelegationTask) -> Optional[str]:
        """Select specialist with best capability match.

        Args:
            task: Task to match

        Returns:
            ID of best-matching specialist or None
        """
        best_specialist = None
        best_score = 0.0

        for specialist in self.specialists.values():
            # Skip if at capacity
            if specialist.load >= specialist.max_parallel_tasks:
                continue

            # Score specialist based on capability match
            score = 0.0
            matched_capabilities = 0

            for required_cap in task.required_capabilities:
                for cap in specialist.capabilities:
                    if cap.name == required_cap:
                        matched_capabilities += 1
                        score += cap.confidence

            # Normalize score
            if task.required_capabilities:
                score = score / len(task.required_capabilities)

            # Prefer less loaded specialists as tiebreaker
            score -= specialist.load * 0.01

            if score > best_score:
                best_score = score
                best_specialist = specialist.agent_id

        return best_specialist

    def _select_by_load(self) -> Optional[str]:
        """Select least loaded specialist.

        Returns:
            ID of least loaded specialist
        """
        available = [
            s
            for s in self.specialists.values()
            if s.load < s.max_parallel_tasks
        ]

        if not available:
            return None

        return min(available, key=lambda s: s.load).agent_id

    def _select_round_robin(self) -> Optional[str]:
        """Select next specialist in round-robin order.

        Returns:
            ID of next specialist
        """
        available = [
            s
            for s in self.specialists.values()
            if s.load < s.max_parallel_tasks
        ]

        if not available:
            return None

        # Simple round-robin using task counter
        specialist_ids = list(self.specialists.keys())
        index = self._task_counter % len(specialist_ids)
        return specialist_ids[index]

    def _execute_task(
        self, specialist: SpecialistAgent, task: DelegationTask
    ) -> Any:
        """Execute task on specialist.

        In real implementation, would call specialist agent.run().
        This is a stub that returns task execution info.

        Args:
            specialist: SpecialistAgent to execute task
            task: DelegationTask to execute

        Returns:
            Task execution output
        """
        # This would normally call:
        # agent = self.agent_factory(agent_id=specialist.agent_id)
        # output = agent.run(task.description)

        # Stub implementation returns task info
        return {
            "executed_by": specialist.name,
            "task_description": task.description,
            "status": "completed",
        }

    def get_specialists(self) -> List[SpecialistAgent]:
        """Get all registered specialists.

        Returns:
            List of SpecialistAgent instances
        """
        return list(self.specialists.values())

    def get_specialist(self, agent_id: str) -> Optional[SpecialistAgent]:
        """Get specialist by ID.

        Args:
            agent_id: ID of specialist

        Returns:
            SpecialistAgent or None
        """
        return self.specialists.get(agent_id)

    def get_task_result(self, task_id: str) -> Optional[DelegationResult]:
        """Get result for a delegated task.

        Args:
            task_id: ID of task

        Returns:
            DelegationResult or None
        """
        return self.task_history.get(task_id)

    def get_statistics(self) -> Dict[str, Any]:
        """Get delegation statistics.

        Returns:
            Dictionary with delegation statistics
        """
        successful = sum(1 for r in self.task_history.values() if r.success)
        total = len(self.task_history)

        return {
            "total_specialists": len(self.specialists),
            "total_tasks_delegated": total,
            "successful_tasks": successful,
            "success_rate": successful / total if total > 0 else 0.0,
            "specialist_load": {
                s.name: s.load for s in self.specialists.values()
            },
            "pending_results": len(self._results_queue),
        }

    def _generate_task_id(self) -> str:
        """Generate unique task ID.

        Returns:
            Unique task ID
        """
        self._task_counter += 1
        return f"task-{self._task_counter}"


__all__ = [
    "DelegationStrategy",
    "SpecialistCapability",
    "SpecialistAgent",
    "DelegationTask",
    "DelegationResult",
    "DelegationToolFactory",
    "SupervisorDelegationManager",
]
