"""Hook executors for bash commands and LLM-based decisions.

Implements specialized hooks for external integrations and AI-driven logic.
"""

import subprocess
import json
import logging
from typing import Optional, Callable, Dict, Any

from smart.hooks.base import Hook, HookType, HookEvent, HookResult

logger = logging.getLogger(__name__)


class BashHook(Hook):
    """Hook that executes bash commands.

    Useful for external integrations (logging, webhooks, etc.).
    """

    def __init__(
        self,
        hook_type: HookType,
        name: str,
        command: str,
        timeout_seconds: Optional[int] = 30,
        fail_silently: bool = False,
        parse_json: bool = False,
        enabled: bool = True,
        filter_fn: Optional[Callable[[HookEvent], bool]] = None,
    ):
        """Initialize bash hook.

        Args:
            hook_type: Type of hook
            name: Hook name
            command: Bash command to execute
            timeout_seconds: Command timeout
            fail_silently: If True, don't fail on command error
            parse_json: Try to parse command output as JSON
            enabled: Whether hook is enabled
            filter_fn: Optional filter function
        """
        super().__init__(hook_type, name, enabled, filter_fn)
        self.command = command
        self.timeout_seconds = timeout_seconds
        self.fail_silently = fail_silently
        self.parse_json = parse_json

    def execute(self, event: HookEvent) -> HookResult:
        """Execute bash command.

        Args:
            event: HookEvent with context

        Returns:
            HookResult with command output
        """
        try:
            # Replace template variables in command
            cmd = self.command.format(
                session_id=event.session_id,
                hook_type=event.hook_type.value,
                **event.event_data,
            )

            # Execute command
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
            )

            output = result.stdout.strip()

            # Try to parse as JSON if requested
            data = None
            if self.parse_json and output:
                try:
                    data = json.loads(output)
                except json.JSONDecodeError:
                    pass

            # Check return code
            if result.returncode != 0:
                if self.fail_silently:
                    logger.warning(
                        f"Bash hook {self.name} failed: {result.stderr}"
                    )
                    return HookResult(
                        success=False,
                        output=output,
                        error=result.stderr,
                    )
                else:
                    return HookResult(
                        success=False,
                        output=output,
                        error=f"Command failed with code {result.returncode}: {result.stderr}",
                    )

            return HookResult(
                success=True,
                output=data or output,
            )

        except subprocess.TimeoutExpired:
            error = f"Bash hook {self.name} timed out after {self.timeout_seconds}s"
            logger.error(error)
            return HookResult(
                success=False,
                error=error,
            )
        except Exception as e:
            error = f"Bash hook {self.name} failed: {str(e)}"
            logger.error(error)
            return HookResult(
                success=False,
                error=error,
            )


class LLMHook(Hook):
    """Hook that uses LLM for dynamic allow/block decisions.

    Uses an LLM to evaluate whether an action should be allowed based on context.
    """

    def __init__(
        self,
        hook_type: HookType,
        name: str,
        llm_model: str,
        decision_prompt: str,
        llm_client: Optional[Any] = None,
        allowed_responses: Optional[list] = None,
        enabled: bool = True,
        filter_fn: Optional[Callable[[HookEvent], bool]] = None,
    ):
        """Initialize LLM hook.

        Args:
            hook_type: Type of hook
            name: Hook name
            llm_model: LLM model to use
            decision_prompt: Prompt template for LLM
            llm_client: Optional LLM client (uses default if None)
            allowed_responses: List of responses that mean "allow"
            enabled: Whether hook is enabled
            filter_fn: Optional filter function
        """
        super().__init__(hook_type, name, enabled, filter_fn)
        self.llm_model = llm_model
        self.decision_prompt = decision_prompt
        self.llm_client = llm_client
        self.allowed_responses = allowed_responses or ["yes", "allow", "approve", "true"]

    def execute(self, event: HookEvent) -> HookResult:
        """Execute LLM-based decision.

        Args:
            event: HookEvent with context

        Returns:
            HookResult with allow/block decision
        """
        try:
            if not self.llm_client:
                logger.warning(f"No LLM client configured for hook {self.name}")
                return HookResult(
                    success=False,
                    error="No LLM client configured",
                )

            # Build prompt with context
            prompt = self._build_prompt(event)

            # Get LLM response
            response = self._get_llm_response(prompt)

            # Parse decision
            allowed = self._parse_decision(response)

            return HookResult(
                success=True,
                allowed=allowed,
                output=response,
                data_mutations={"llm_decision": response},
            )

        except Exception as e:
            logger.error(f"LLM hook {self.name} failed: {e}")
            return HookResult(
                success=False,
                error=str(e),
            )

    def _build_prompt(self, event: HookEvent) -> str:
        """Build prompt for LLM.

        Args:
            event: HookEvent with context

        Returns:
            Formatted prompt
        """
        context_str = json.dumps(event.event_data, indent=2)

        prompt = f"""{self.decision_prompt}

Context:
{context_str}

Session: {event.session_id}
Hook Type: {event.hook_type.value}

Respond with 'allow' or 'block'."""

        return prompt

    def _get_llm_response(self, prompt: str) -> str:
        """Get response from LLM.

        Args:
            prompt: Prompt to send to LLM

        Returns:
            LLM response text
        """
        # This would use actual LLM client in production
        # For now, return a placeholder
        if not hasattr(self.llm_client, "generate"):
            # Mock response for testing
            return "allow"

        response = self.llm_client.generate(
            model=self.llm_model,
            prompt=prompt,
        )
        return response

    def _parse_decision(self, response: str) -> bool:
        """Parse LLM response to allow/block decision.

        Args:
            response: LLM response text

        Returns:
            True if response indicates "allow", False otherwise
        """
        response_lower = response.lower().strip()

        for allowed_response in self.allowed_responses:
            if allowed_response in response_lower:
                return True

        return False


class CallableHook(Hook):
    """Hook that executes a Python callable.

    Simple way to add custom logic via functions.
    """

    def __init__(
        self,
        hook_type: HookType,
        name: str,
        callable_fn: Callable[[HookEvent], HookResult],
        enabled: bool = True,
        filter_fn: Optional[Callable[[HookEvent], bool]] = None,
    ):
        """Initialize callable hook.

        Args:
            hook_type: Type of hook
            name: Hook name
            callable_fn: Function that takes HookEvent and returns HookResult
            enabled: Whether hook is enabled
            filter_fn: Optional filter function
        """
        super().__init__(hook_type, name, enabled, filter_fn)
        self.callable_fn = callable_fn

    def execute(self, event: HookEvent) -> HookResult:
        """Execute the callable.

        Args:
            event: HookEvent with context

        Returns:
            HookResult from callable
        """
        try:
            result = self.callable_fn(event)

            if not isinstance(result, HookResult):
                # Convert non-HookResult returns
                result = HookResult(
                    success=True,
                    output=result,
                )

            return result

        except Exception as e:
            logger.error(f"Callable hook {self.name} failed: {e}")
            return HookResult(
                success=False,
                error=str(e),
            )


__all__ = [
    "BashHook",
    "LLMHook",
    "CallableHook",
]
