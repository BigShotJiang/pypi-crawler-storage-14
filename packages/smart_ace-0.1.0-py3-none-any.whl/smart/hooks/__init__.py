"""Hooks and automation system for smart-agent lifecycle events.

Provides lifecycle hooks for agent events with bash command and LLM-based
allow/block decisions.

Features:
- Lifecycle hooks (PreToolUse, PostToolUse, PreCheckpoint, PostCheckpoint, etc.)
- Bash command hooks for external integrations
- LLM-based decision hooks for dynamic allow/block logic
- Hook chaining and composition
- Event filtering and conditional execution
"""

from smart.hooks.base import (
    HookType,
    HookEvent,
    HookResult,
    Hook,
    HookRegistry,
)
from smart.hooks.executors import (
    BashHook,
    LLMHook,
    CallableHook,
)

__all__ = [
    "HookType",
    "HookEvent",
    "HookResult",
    "Hook",
    "HookRegistry",
    "BashHook",
    "LLMHook",
    "CallableHook",
]
