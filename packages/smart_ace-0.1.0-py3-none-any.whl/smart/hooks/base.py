"""Base classes for hook system.

Defines hook types, events, and registry for lifecycle automation.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Dict, Any, List, Callable
import logging

logger = logging.getLogger(__name__)


class HookType(Enum):
    """Types of lifecycle hooks."""
    # Execution hooks
    PRE_RUN = "pre_run"  # Before agent.run()
    POST_RUN = "post_run"  # After agent.run()
    PRE_TOOL_USE = "pre_tool_use"  # Before tool execution
    POST_TOOL_USE = "post_tool_use"  # After tool execution
    # Checkpoint hooks
    PRE_CHECKPOINT = "pre_checkpoint"  # Before creating checkpoint
    POST_CHECKPOINT = "post_checkpoint"  # After creating checkpoint
    # Rewind hooks
    PRE_REWIND = "pre_rewind"  # Before rewind operation
    POST_REWIND = "post_rewind"  # After rewind operation
    # Error hooks
    ON_ERROR = "on_error"  # On execution error
    ON_TOOL_ERROR = "on_tool_error"  # On tool execution error
    # Custom hooks
    CUSTOM = "custom"


@dataclass
class HookEvent:
    """Event data passed to hooks.

    Attributes:
        hook_type: Type of hook being executed
        timestamp: When event occurred
        session_id: Session ID
        agent_state: Current agent state (for inspection)
        event_data: Hook-specific event data
        context: Additional context
    """
    hook_type: HookType
    timestamp: float
    session_id: str
    agent_state: Optional[Dict[str, Any]] = None
    event_data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HookResult:
    """Result of hook execution.

    Attributes:
        success: Whether hook executed successfully
        allowed: Whether to allow the action (for allow/block hooks)
        output: Hook execution output
        error: Error message if failed
        should_continue: Whether to continue execution
        data_mutations: Data to merge into context
    """
    success: bool
    allowed: bool = True
    output: Any = None
    error: Optional[str] = None
    should_continue: bool = True
    data_mutations: Dict[str, Any] = field(default_factory=dict)


class Hook(ABC):
    """Base class for hooks.

    Provides interface for lifecycle event handlers.
    """

    def __init__(
        self,
        hook_type: HookType,
        name: str,
        enabled: bool = True,
        filter_fn: Optional[Callable[[HookEvent], bool]] = None,
    ):
        """Initialize hook.

        Args:
            hook_type: Type of hook
            name: Human-readable hook name
            enabled: Whether hook is enabled
            filter_fn: Optional filter to determine if hook should execute
        """
        self.hook_type = hook_type
        self.name = name
        self.enabled = enabled
        self.filter_fn = filter_fn

    def should_execute(self, event: HookEvent) -> bool:
        """Determine if hook should execute.

        Args:
            event: HookEvent to check

        Returns:
            True if hook should execute
        """
        if not self.enabled:
            return False
        if self.filter_fn:
            return self.filter_fn(event)
        return True

    @abstractmethod
    def execute(self, event: HookEvent) -> HookResult:
        """Execute the hook.

        Args:
            event: HookEvent with context

        Returns:
            HookResult with execution outcome
        """
        pass


class HookRegistry:
    """Registry for managing lifecycle hooks.

    Handles:
    - Hook registration
    - Event triggering
    - Hook chaining
    - Async execution
    """

    def __init__(self):
        """Initialize hook registry."""
        self.hooks: Dict[HookType, List[Hook]] = {}
        self.custom_hooks: Dict[str, Hook] = {}
        self.execution_history: List[Dict[str, Any]] = []

    def register(self, hook: Hook) -> None:
        """Register a hook.

        Args:
            hook: Hook instance to register
        """
        if hook.hook_type not in self.hooks:
            self.hooks[hook.hook_type] = []

        self.hooks[hook.hook_type].append(hook)
        logger.debug(f"Registered hook: {hook.name} ({hook.hook_type.value})")

    def register_custom(self, name: str, hook: Hook) -> None:
        """Register a custom hook by name.

        Args:
            name: Custom hook name
            hook: Hook instance
        """
        self.custom_hooks[name] = hook
        logger.debug(f"Registered custom hook: {name}")

    def unregister(self, hook: Hook) -> None:
        """Unregister a hook.

        Args:
            hook: Hook instance to unregister
        """
        if hook.hook_type in self.hooks:
            self.hooks[hook.hook_type] = [
                h for h in self.hooks[hook.hook_type] if h is not hook
            ]
            logger.debug(f"Unregistered hook: {hook.name}")

    def trigger(
        self,
        hook_type: HookType,
        event: HookEvent,
    ) -> List[HookResult]:
        """Trigger hooks for an event.

        Args:
            hook_type: Type of hooks to trigger
            event: HookEvent with context

        Returns:
            List of HookResults from all triggered hooks
        """
        results = []

        hooks_to_execute = self.hooks.get(hook_type, [])

        for hook in hooks_to_execute:
            if not hook.should_execute(event):
                continue

            try:
                result = hook.execute(event)
                results.append(result)

                # Record execution
                self.execution_history.append({
                    "hook_name": hook.name,
                    "hook_type": hook_type.value,
                    "success": result.success,
                    "timestamp": event.timestamp,
                })

                logger.debug(
                    f"Hook executed: {hook.name} "
                    f"(type: {hook_type.value}, success: {result.success})"
                )

                # If hook disallows action, stop chain
                if hook_type in [
                    HookType.PRE_TOOL_USE,
                    HookType.PRE_RUN,
                    HookType.PRE_CHECKPOINT,
                ] and not result.allowed:
                    logger.info(f"Action blocked by hook: {hook.name}")
                    break

            except Exception as e:
                logger.error(f"Hook execution failed: {hook.name}: {e}")
                results.append(
                    HookResult(
                        success=False,
                        allowed=False,
                        error=str(e),
                    )
                )

        return results

    def trigger_custom(
        self,
        hook_name: str,
        event: HookEvent,
    ) -> Optional[HookResult]:
        """Trigger a custom hook by name.

        Args:
            hook_name: Name of custom hook
            event: HookEvent with context

        Returns:
            HookResult or None if hook not found
        """
        hook = self.custom_hooks.get(hook_name)
        if not hook:
            return None

        return hook.execute(event)

    def get_hooks_for_type(self, hook_type: HookType) -> List[Hook]:
        """Get all hooks for a specific type.

        Args:
            hook_type: Type to get hooks for

        Returns:
            List of Hook instances
        """
        return self.hooks.get(hook_type, [])

    def disable_hook(self, hook: Hook) -> None:
        """Disable a hook.

        Args:
            hook: Hook to disable
        """
        hook.enabled = False

    def enable_hook(self, hook: Hook) -> None:
        """Enable a hook.

        Args:
            hook: Hook to enable
        """
        hook.enabled = True

    def clear_history(self) -> None:
        """Clear execution history."""
        self.execution_history.clear()

    def get_execution_stats(self) -> Dict[str, Any]:
        """Get hook execution statistics.

        Returns:
            Stats dict
        """
        total_executions = len(self.execution_history)
        successful = sum(1 for h in self.execution_history if h["success"])

        hook_counts = {}
        for entry in self.execution_history:
            hook_type = entry["hook_type"]
            hook_counts[hook_type] = hook_counts.get(hook_type, 0) + 1

        return {
            "total_executions": total_executions,
            "successful": successful,
            "failed": total_executions - successful,
            "by_hook_type": hook_counts,
            "success_rate": successful / total_executions
            if total_executions > 0
            else 0,
        }


__all__ = [
    "HookType",
    "HookEvent",
    "HookResult",
    "Hook",
    "HookRegistry",
]
