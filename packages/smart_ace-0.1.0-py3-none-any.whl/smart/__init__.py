"""Smart-Agent: Production-ready multi-agent framework."""

__version__ = "0.1.0"

# Core exports
from smart.core.agent import SmartAgent
from smart.core.session import SessionManager
from smart.core.factory import create_smart
from smart.core.registry import PluginRegistry, SmartAgentPlugin

# Persistence exports
from smart.persistence.base import PersistenceBackend, Session
from smart.persistence.markdown import MarkdownBackend
from smart.persistence.duckdb import DuckDBBackend
from smart.persistence.hybrid import HybridBackend

# Observability exports
from smart.observability.metrics import MetricsCollector, StepMetrics
from smart.observability.costs import CostTracker

# Async bridge exports
from smart.async_bridge import to_thread_safe, gather_sync

# Utils exports
from smart.utils.errors import SmartAgentError, SessionError, PersistenceError

# Coordination exports
from smart.coordination.base import CoordinationStrategy
from smart.coordination.sequential import SequentialCoordinator
from smart.coordination.parallel import ParallelCoordinator
from smart.coordination.pipeline import PipelineCoordinator
from smart.coordination.system import MultiAgentSystem
from smart.coordination.ace import ACECoordinator, ACEPhase, create_ace_system

# Model provider exports
from smart.models.provider_helper import ModelProvider

# UI exports
from smart.ui.dashboard_tools import (
    create_metrics_dashboard,
    create_session_report,
    format_execution_summary,
)
from smart.ui.gradio_wrapper import SmartAgentGradioUI
from smart.ui.knowledge_dashboard import (
    KnowledgeDashboard,
    create_knowledge_dashboard,
)

# Integration exports
from smart.integrations.langfuse_integration import LangfuseIntegration
from smart.integrations.mlflow_integration import MLflowIntegration
from smart.integrations.wandb_integration import WandBIntegration

# Tools exports (includes MCP)
from smart.tools.manager import ToolManager, ToolInfo
from smart.tools.mcp_bridge import (
    MCPBridge,
    create_stdio_server,
    create_http_server,
    get_known_server,
    list_known_servers,
)

# Checkpointing exports
from smart.checkpointing import (
    Checkpoint,
    CheckpointManager,
    RewindSystem,
)

# Commands exports
from smart.commands import (
    Command,
    CommandRegistry,
    CommandContext,
    CommandResult,
    RewindCommand,
    ResumeCommand,
    CostCommand,
    ContextCommand,
    ModelCommand,
    HelpCommand,
    LearnCommand,
    KnowledgeCommand,
)

# Subagents exports
from smart.subagents import (
    SubagentRole,
    SubagentConfig,
    SubagentContext,
    SubagentResult,
    SubagentManager,
    SubagentExecutor,
    ExecutionMode,
    DelegationStrategy,
    SpecialistCapability,
    SpecialistAgent,
    DelegationTask,
    DelegationResult,
    DelegationToolFactory,
    SupervisorDelegationManager,
)

# Hooks exports
from smart.hooks import (
    HookType,
    HookEvent,
    HookResult,
    Hook,
    HookRegistry,
    BashHook,
    LLMHook,
    CallableHook,
)

# Knowledge exports
from smart.knowledge import (
    KnowledgeEntry,
    KnowledgeBase,
    VectorKnowledgeStore,
    MarkdownKnowledgeStore,
    KnowledgeCurator,
    KnowledgeRetriever,
)

# Re-export smolagents for convenience
from smolagents import CodeAgent, ToolCallingAgent, Tool, tool

__all__ = [
    # Core
    "SmartAgent",
    "SessionManager",
    "create_smart",
    "PluginRegistry",
    "SmartAgentPlugin",
    # Persistence
    "PersistenceBackend",
    "Session",
    "MarkdownBackend",
    "DuckDBBackend",
    "HybridBackend",
    # Observability
    "MetricsCollector",
    "StepMetrics",
    "CostTracker",
    # Coordination
    "CoordinationStrategy",
    "SequentialCoordinator",
    "ParallelCoordinator",
    "PipelineCoordinator",
    "MultiAgentSystem",
    "ACECoordinator",
    "ACEPhase",
    "create_ace_system",
    # Models
    "ModelProvider",
    # UI/Dashboard
    "create_metrics_dashboard",
    "create_session_report",
    "format_execution_summary",
    "SmartAgentGradioUI",
    "KnowledgeDashboard",
    "create_knowledge_dashboard",
    # Integrations
    "LangfuseIntegration",
    "MLflowIntegration",
    "WandBIntegration",
    # Tools (includes MCP)
    "ToolManager",
    "ToolInfo",
    "MCPBridge",
    "create_stdio_server",
    "create_http_server",
    "get_known_server",
    "list_known_servers",
    # Checkpointing
    "Checkpoint",
    "CheckpointManager",
    "RewindSystem",
    # Commands
    "Command",
    "CommandRegistry",
    "CommandContext",
    "CommandResult",
    "RewindCommand",
    "ResumeCommand",
    "CostCommand",
    "ContextCommand",
    "ModelCommand",
    "HelpCommand",
    "LearnCommand",
    "KnowledgeCommand",
    # Subagents
    "SubagentRole",
    "SubagentConfig",
    "SubagentContext",
    "SubagentResult",
    "SubagentManager",
    "SubagentExecutor",
    "ExecutionMode",
    # Delegation
    "DelegationStrategy",
    "SpecialistCapability",
    "SpecialistAgent",
    "DelegationTask",
    "DelegationResult",
    "DelegationToolFactory",
    "SupervisorDelegationManager",
    # Hooks
    "HookType",
    "HookEvent",
    "HookResult",
    "Hook",
    "HookRegistry",
    "BashHook",
    "LLMHook",
    "CallableHook",
    # Knowledge
    "KnowledgeEntry",
    "KnowledgeBase",
    "VectorKnowledgeStore",
    "MarkdownKnowledgeStore",
    "KnowledgeCurator",
    "KnowledgeRetriever",
    # Async bridge
    "to_thread_safe",
    "gather_sync",
    # Utils
    "SmartAgentError",
    "SessionError",
    "PersistenceError",
    # Smolagents re-exports
    "CodeAgent",
    "ToolCallingAgent",
    "Tool",
    "tool",
]
