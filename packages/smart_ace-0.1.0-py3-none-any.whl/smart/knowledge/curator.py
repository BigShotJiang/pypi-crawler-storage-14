"""Knowledge curator for learning from sessions."""

from typing import Optional, List, Dict, Any
from smart.knowledge.base import KnowledgeEntry, KnowledgeBase
from smart.persistence.base import Session
from smart.observability.metrics import MetricsCollector


class KnowledgeCurator:
    """Learns from sessions and curates knowledge."""

    def __init__(
        self,
        knowledge_base: KnowledgeBase,
        metrics_collector: Optional[MetricsCollector] = None,
    ):
        """Initialize knowledge curator.

        Args:
            knowledge_base: Knowledge storage backend
            metrics_collector: Optional metrics collector for success evaluation
        """
        self.knowledge_base = knowledge_base
        self.metrics_collector = metrics_collector

    def learn_from_session(self, session: Session) -> Optional[KnowledgeEntry]:
        """Learn from a completed session.

        Args:
            session: Completed session to learn from

        Returns:
            KnowledgeEntry if learning was successful, None otherwise
        """
        if session.status != "completed":
            return None

        # Extract task type from session metadata or agent name
        task_type = self._extract_task_type(session)

        # Collect success metrics
        success_metrics = self._calculate_success_metrics(session)

        # Extract key learnings
        content = self._extract_learnings(session)

        if not content:
            return None

        # Create knowledge entry
        entry = KnowledgeEntry(
            content=content,
            task_type=task_type,
            success_metrics=success_metrics,
            source=f"session:{session.session_id}",
            tags=[session.agent_name, task_type],
            metadata={
                "session_id": session.session_id,
                "agent_name": session.agent_name,
                "step_count": len(session.steps),
            },
        )

        # Store in knowledge base
        entry_id = self.knowledge_base.add(entry)
        return entry

    def suggest_improvements(self, task: str) -> List[str]:
        """Suggest improvements based on similar past tasks.

        Args:
            task: Current task description

        Returns:
            List of improvement suggestions
        """
        # Search for similar past learnings
        similar_entries = self.knowledge_base.search(task, top_k=3)

        suggestions = []
        for entry in similar_entries:
            # Extract best practices from high-success entries
            if entry.success_metrics.get("success_rate", 0) > 0.7:
                suggestions.append(f"Based on '{entry.task_type}': {entry.content[:100]}...")

        return suggestions

    def auto_curate_on_completion(self, session: Session) -> bool:
        """Automatically curate knowledge after session completion.

        Args:
            session: Session that just completed

        Returns:
            True if curation was successful
        """
        entry = self.learn_from_session(session)
        return entry is not None

    def _extract_task_type(self, session: Session) -> str:
        """Extract task type from session.

        Args:
            session: Session object

        Returns:
            Task type string
        """
        # Try to infer from metadata
        if "task_type" in session.metadata:
            return session.metadata["task_type"]

        # Try to infer from agent name
        if session.agent_name:
            return session.agent_name.lower().replace(" ", "_")

        # Try to infer from task description
        if session.task:
            words = session.task.lower().split()
            if len(words) > 0:
                return words[0]

        return "general"

    def _calculate_success_metrics(self, session: Session) -> Dict[str, float]:
        """Calculate success metrics for a session.

        Args:
            session: Completed session

        Returns:
            Dictionary of metrics
        """
        metrics = {
            "success": 1.0 if session.status == "completed" else 0.0,
            "steps": float(len(session.steps)),
            "duration": float(session.metadata.get("duration", 0)),
        }

        # Add metrics from collector if available
        if self.metrics_collector:
            session_metrics = self.metrics_collector.get_session_metrics(
                session.session_id
            )
            if session_metrics:
                metrics["avg_step_duration"] = (
                    sum(m.duration for m in session_metrics) / len(session_metrics)
                    if session_metrics
                    else 0
                )
                metrics["total_tokens"] = sum(
                    m.tokens_used for m in session_metrics if m.tokens_used
                )
                metrics["total_cost"] = sum(m.cost for m in session_metrics)

        return metrics

    def _extract_learnings(self, session: Session) -> str:
        """Extract key learnings from session.

        Args:
            session: Session to extract learnings from

        Returns:
            Formatted learning string
        """
        learnings = []

        # Add task summary
        if session.task:
            learnings.append(f"Task: {session.task}")

        # Add final state/result if available
        if session.state and "result" in session.state:
            learnings.append(f"Result: {session.state['result']}")

        # Add key findings from steps
        if session.steps:
            # Collect unique step types
            step_types = set()
            for step in session.steps:
                if isinstance(step, dict) and "type" in step:
                    step_types.add(step["type"])

            if step_types:
                learnings.append(f"Process: {', '.join(sorted(step_types))}")

        # Add best practices from metadata
        if session.metadata and "best_practices" in session.metadata:
            learnings.append(f"Best Practices: {session.metadata['best_practices']}")

        return "\n".join(learnings) if learnings else ""

    def get_knowledge_for_task(self, task: str, top_k: int = 3) -> List[KnowledgeEntry]:
        """Get relevant knowledge for a task.

        Args:
            task: Task description
            top_k: Number of results

        Returns:
            List of relevant knowledge entries
        """
        return self.knowledge_base.search(task, top_k=top_k)

    def get_statistics(self) -> Dict[str, Any]:
        """Get knowledge base statistics.

        Returns:
            Dictionary with statistics
        """
        all_entries = self.knowledge_base.list_all(limit=10000)

        task_types = {}
        total_success = 0
        total_entries = len(all_entries)

        for entry in all_entries:
            if entry.task_type not in task_types:
                task_types[entry.task_type] = 0
            task_types[entry.task_type] += 1

            if entry.success_metrics.get("success", 0) > 0:
                total_success += 1

        return {
            "total_entries": total_entries,
            "task_types": task_types,
            "success_rate": total_success / total_entries if total_entries > 0 else 0,
            "unique_tasks": len(task_types),
        }
