"""Abstract base classes for knowledge management."""

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any


@dataclass
class KnowledgeEntry:
    """Single learned entry with embedding."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    task_type: str = ""
    success_metrics: Dict[str, float] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    created_at: datetime = field(default_factory=datetime.now)
    tags: List[str] = field(default_factory=list)
    source: str = ""  # e.g., "session:abc123", "manual"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for storage."""
        return {
            "id": self.id,
            "content": self.content,
            "task_type": self.task_type,
            "success_metrics": self.success_metrics,
            "embedding": self.embedding,
            "created_at": self.created_at.isoformat(),
            "tags": self.tags,
            "source": self.source,
            "metadata": self.metadata,
        }


class KnowledgeBase(ABC):
    """Abstract knowledge storage interface."""

    @abstractmethod
    def add(self, entry: KnowledgeEntry) -> str:
        """Add a knowledge entry.

        Args:
            entry: KnowledgeEntry to add

        Returns:
            ID of added entry
        """
        pass

    @abstractmethod
    def get(self, entry_id: str) -> Optional[KnowledgeEntry]:
        """Get a knowledge entry by ID.

        Args:
            entry_id: Entry ID

        Returns:
            KnowledgeEntry or None if not found
        """
        pass

    @abstractmethod
    def search(self, query: str, top_k: int = 5) -> List[KnowledgeEntry]:
        """Search for similar entries.

        Args:
            query: Search query
            top_k: Number of results to return

        Returns:
            List of similar entries
        """
        pass

    @abstractmethod
    def get_by_task_type(self, task_type: str, limit: int = 10) -> List[KnowledgeEntry]:
        """Get entries by task type.

        Args:
            task_type: Task type to filter by
            limit: Maximum number of results

        Returns:
            List of entries
        """
        pass

    @abstractmethod
    def delete(self, entry_id: str) -> bool:
        """Delete a knowledge entry.

        Args:
            entry_id: Entry ID to delete

        Returns:
            True if deleted, False if not found
        """
        pass

    @abstractmethod
    def list_all(self, limit: int = 100) -> List[KnowledgeEntry]:
        """List all knowledge entries.

        Args:
            limit: Maximum number of entries to return

        Returns:
            List of all entries
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """Clear all knowledge entries."""
        pass
