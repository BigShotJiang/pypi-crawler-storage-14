"""Knowledge storage implementations: Vector DB and Markdown."""

import json
from pathlib import Path
from typing import List, Optional
from datetime import datetime

from sentence_transformers import SentenceTransformer

from smart.knowledge.base import KnowledgeBase, KnowledgeEntry


class VectorKnowledgeStore(KnowledgeBase):
    """DuckDB VSS-based vector knowledge storage."""

    def __init__(self, db_path: Path, embedding_model: str = "all-MiniLM-L6-v2"):
        """Initialize vector knowledge store.

        Args:
            db_path: Path to DuckDB database file
            embedding_model: SentenceTransformer model name
        """
        self.db_path = Path(db_path)
        self.embedding_model_name = embedding_model
        self.encoder = SentenceTransformer(embedding_model)
        self.embedding_dim = self.encoder.get_sentence_embedding_dimension()

        # Import duckdb here to avoid issues if not installed
        try:
            import duckdb

            self.conn = duckdb.connect(str(self.db_path))
            self._setup_schema()
        except ImportError:
            raise ImportError("duckdb is required for VectorKnowledgeStore")

    def _setup_schema(self) -> None:
        """Set up database schema with VSS."""
        # Install and load VSS extension
        try:
            self.conn.execute("INSTALL vss;")
            self.conn.execute("LOAD vss;")
        except Exception:
            pass  # VSS might already be installed

        # Create knowledge table
        self.conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS knowledge (
                id VARCHAR PRIMARY KEY,
                content TEXT,
                task_type VARCHAR,
                success_metrics JSON,
                embedding FLOAT[{self.embedding_dim}],
                created_at TIMESTAMP,
                tags JSON,
                source VARCHAR,
                metadata JSON
            )
        """
        )

        # Create index for vector search
        try:
            self.conn.execute(
                """
                CREATE INDEX IF NOT EXISTS knowledge_embedding_idx
                ON knowledge USING HNSW (embedding)
            """
            )
        except Exception:
            pass  # Index might already exist

    def add(self, entry: KnowledgeEntry) -> str:
        """Add a knowledge entry.

        Args:
            entry: KnowledgeEntry to add

        Returns:
            ID of added entry
        """
        # Generate embedding if not present
        if entry.embedding is None:
            entry.embedding = self.encoder.encode(entry.content).tolist()

        # Upsert entry
        self.conn.execute(
            """
            INSERT OR REPLACE INTO knowledge (
                id, content, task_type, success_metrics, embedding,
                created_at, tags, source, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            [
                entry.id,
                entry.content,
                entry.task_type,
                json.dumps(entry.success_metrics),
                entry.embedding,
                entry.created_at,
                json.dumps(entry.tags),
                entry.source,
                json.dumps(entry.metadata),
            ],
        )
        return entry.id

    def get(self, entry_id: str) -> Optional[KnowledgeEntry]:
        """Get a knowledge entry by ID."""
        result = self.conn.execute(
            "SELECT * FROM knowledge WHERE id = ?", [entry_id]
        ).fetchall()

        if not result:
            return None

        row = result[0]
        return KnowledgeEntry(
            id=row[0],
            content=row[1],
            task_type=row[2],
            success_metrics=json.loads(row[3]),
            embedding=row[4],
            created_at=row[5],
            tags=json.loads(row[6]),
            source=row[7],
            metadata=json.loads(row[8]),
        )

    def search(self, query: str, top_k: int = 5) -> List[KnowledgeEntry]:
        """Search for similar entries using vector similarity."""
        # Generate query embedding
        query_embedding = self.encoder.encode(query).tolist()

        # Use DuckDB VSS for similarity search
        try:
            results = self.conn.execute(
                f"""
                SELECT *,
                       array_cosine_similarity(embedding, ?) as similarity
                FROM knowledge
                ORDER BY similarity DESC
                LIMIT ?
            """,
                [query_embedding, top_k],
            ).fetchall()
        except Exception:
            # Fallback to text search if VSS fails
            results = self.conn.execute(
                "SELECT *, NULL as similarity FROM knowledge LIMIT ?",
                [top_k],
            ).fetchall()

        entries = []
        for row in results:
            entries.append(
                KnowledgeEntry(
                    id=row[0],
                    content=row[1],
                    task_type=row[2],
                    success_metrics=json.loads(row[3]),
                    embedding=row[4],
                    created_at=row[5],
                    tags=json.loads(row[6]),
                    source=row[7],
                    metadata=json.loads(row[8]),
                )
            )

        return entries

    def get_by_task_type(self, task_type: str, limit: int = 10) -> List[KnowledgeEntry]:
        """Get entries by task type."""
        results = self.conn.execute(
            "SELECT * FROM knowledge WHERE task_type = ? LIMIT ?",
            [task_type, limit],
        ).fetchall()

        entries = []
        for row in results:
            entries.append(
                KnowledgeEntry(
                    id=row[0],
                    content=row[1],
                    task_type=row[2],
                    success_metrics=json.loads(row[3]),
                    embedding=row[4],
                    created_at=row[5],
                    tags=json.loads(row[6]),
                    source=row[7],
                    metadata=json.loads(row[8]),
                )
            )

        return entries

    def delete(self, entry_id: str) -> bool:
        """Delete a knowledge entry."""
        result = self.conn.execute(
            "DELETE FROM knowledge WHERE id = ?", [entry_id]
        )
        return result.total_changes > 0

    def list_all(self, limit: int = 100) -> List[KnowledgeEntry]:
        """List all knowledge entries."""
        results = self.conn.execute(
            "SELECT * FROM knowledge ORDER BY created_at DESC LIMIT ?", [limit]
        ).fetchall()

        entries = []
        for row in results:
            entries.append(
                KnowledgeEntry(
                    id=row[0],
                    content=row[1],
                    task_type=row[2],
                    success_metrics=json.loads(row[3]),
                    embedding=row[4],
                    created_at=row[5],
                    tags=json.loads(row[6]),
                    source=row[7],
                    metadata=json.loads(row[8]),
                )
            )

        return entries

    def clear(self) -> None:
        """Clear all knowledge entries."""
        self.conn.execute("DELETE FROM knowledge")


class MarkdownKnowledgeStore(KnowledgeBase):
    """Human-readable markdown knowledge storage."""

    def __init__(self, base_dir: Path):
        """Initialize markdown knowledge store.

        Args:
            base_dir: Base directory for markdown files
        """
        self.base_dir = Path(base_dir) / "knowledge"
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self._entries_index = {}  # Cache for fast lookup
        self._load_index()

    def _load_index(self) -> None:
        """Load index of all entries."""
        for entry_file in self.base_dir.rglob("*.json"):
            try:
                with open(entry_file) as f:
                    entry_data = json.load(f)
                    self._entries_index[entry_data["id"]] = str(entry_file)
            except Exception:
                pass

    def _get_filepath(self, entry: KnowledgeEntry) -> Path:
        """Get filepath for an entry based on task type and date."""
        task_type_dir = self.base_dir / entry.task_type
        task_type_dir.mkdir(parents=True, exist_ok=True)

        date_str = entry.created_at.strftime("%Y-%m")
        date_dir = task_type_dir / date_str
        date_dir.mkdir(parents=True, exist_ok=True)

        return date_dir / f"{entry.id}.md"

    def add(self, entry: KnowledgeEntry) -> str:
        """Add a knowledge entry as markdown + JSON."""
        filepath = self._get_filepath(entry)

        # Write markdown file
        with open(filepath, "w") as f:
            f.write(f"# {entry.task_type.replace('_', ' ').title()}\n\n")
            f.write(f"**ID**: {entry.id}\n")
            f.write(f"**Created**: {entry.created_at.isoformat()}\n")
            f.write(f"**Source**: {entry.source}\n")
            if entry.tags:
                f.write(f"**Tags**: {', '.join(entry.tags)}\n")
            f.write(f"\n## Content\n\n{entry.content}\n\n")
            if entry.success_metrics:
                f.write(f"## Metrics\n\n")
                for key, value in entry.success_metrics.items():
                    f.write(f"- {key}: {value}\n")

        # Write JSON file for structured access
        json_filepath = filepath.with_suffix(".json")
        with open(json_filepath, "w") as f:
            json.dump(entry.to_dict(), f, indent=2, default=str)

        self._entries_index[entry.id] = str(json_filepath)
        return entry.id

    def get(self, entry_id: str) -> Optional[KnowledgeEntry]:
        """Get a knowledge entry by ID."""
        if entry_id not in self._entries_index:
            return None

        try:
            with open(self._entries_index[entry_id]) as f:
                data = json.load(f)
                return KnowledgeEntry(
                    id=data["id"],
                    content=data["content"],
                    task_type=data["task_type"],
                    success_metrics=data.get("success_metrics", {}),
                    embedding=data.get("embedding"),
                    created_at=datetime.fromisoformat(data["created_at"]),
                    tags=data.get("tags", []),
                    source=data.get("source", ""),
                    metadata=data.get("metadata", {}),
                )
        except Exception:
            return None

    def search(self, query: str, top_k: int = 5) -> List[KnowledgeEntry]:
        """Search entries by text matching."""
        results = []
        query_lower = query.lower()

        for entry_id, filepath in list(self._entries_index.items())[:top_k * 3]:
            entry = self.get(entry_id)
            if entry and (
                query_lower in entry.content.lower()
                or query_lower in entry.task_type.lower()
            ):
                results.append(entry)

        return results[:top_k]

    def get_by_task_type(self, task_type: str, limit: int = 10) -> List[KnowledgeEntry]:
        """Get entries by task type."""
        results = []
        task_type_dir = self.base_dir / task_type

        if task_type_dir.exists():
            for json_file in list(task_type_dir.rglob("*.json"))[:limit]:
                try:
                    entry = self.get(json_file.stem)
                    if entry:
                        results.append(entry)
                except Exception:
                    pass

        return results

    def delete(self, entry_id: str) -> bool:
        """Delete a knowledge entry."""
        if entry_id not in self._entries_index:
            return False

        try:
            json_path = Path(self._entries_index[entry_id])
            json_path.unlink()
            md_path = json_path.with_suffix(".md")
            if md_path.exists():
                md_path.unlink()
            del self._entries_index[entry_id]
            return True
        except Exception:
            return False

    def list_all(self, limit: int = 100) -> List[KnowledgeEntry]:
        """List all knowledge entries."""
        results = []
        for entry_id in list(self._entries_index.keys())[:limit]:
            entry = self.get(entry_id)
            if entry:
                results.append(entry)
        return results

    def clear(self) -> None:
        """Clear all knowledge entries."""
        import shutil

        if self.base_dir.exists():
            shutil.rmtree(self.base_dir)
            self.base_dir.mkdir(parents=True, exist_ok=True)
        self._entries_index.clear()
