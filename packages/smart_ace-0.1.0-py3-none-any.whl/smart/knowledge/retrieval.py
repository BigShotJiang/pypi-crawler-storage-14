"""Knowledge retrieval for context augmentation."""

from typing import List, Optional
from smart.knowledge.base import KnowledgeBase, KnowledgeEntry


class KnowledgeRetriever:
    """Retrieves and augments context with knowledge."""

    def __init__(self, knowledge_base: KnowledgeBase):
        """Initialize knowledge retriever.

        Args:
            knowledge_base: Knowledge storage backend
        """
        self.knowledge_base = knowledge_base

    def augment_context(
        self, task: str, context: str = "", top_k: int = 3
    ) -> str:
        """Augment task context with relevant knowledge.

        Args:
            task: Current task description
            context: Existing context (optional)
            top_k: Number of knowledge entries to retrieve

        Returns:
            Augmented context string
        """
        # Search for relevant knowledge
        relevant_entries = self.knowledge_base.search(task, top_k=top_k)

        if not relevant_entries:
            return context

        # Build augmented context
        augmented = context

        if augmented:
            augmented += "\n\n"

        augmented += "## Relevant Past Learnings\n\n"

        for i, entry in enumerate(relevant_entries, 1):
            augmented += f"### Learning {i}: {entry.task_type}\n"
            augmented += f"{entry.content}\n\n"

            if entry.success_metrics:
                augmented += "**Metrics:**\n"
                for key, value in entry.success_metrics.items():
                    augmented += f"- {key}: {value}\n"
                augmented += "\n"

        return augmented

    def get_tool_suggestions(
        self, task: str, top_k: int = 5
    ) -> List[str]:
        """Get tool suggestions based on past similar tasks.

        Args:
            task: Task description
            top_k: Number of suggestions

        Returns:
            List of suggested tools
        """
        # Search for similar tasks
        similar_entries = self.knowledge_base.search(task, top_k=top_k)

        suggestions = set()
        for entry in similar_entries:
            # Extract tools mentioned in successful entries
            if entry.success_metrics.get("success", 0) > 0:
                # Look for tool mentions in metadata
                if "tools_used" in entry.metadata:
                    tools = entry.metadata["tools_used"]
                    if isinstance(tools, list):
                        suggestions.update(tools)
                    else:
                        suggestions.add(str(tools))

        return list(suggestions)[:top_k]

    def get_best_practices(self, task_type: str) -> List[str]:
        """Get best practices for a task type.

        Args:
            task_type: Type of task

        Returns:
            List of best practice strings
        """
        # Get entries for task type
        entries = self.knowledge_base.get_by_task_type(task_type, limit=10)

        best_practices = []

        # Find high-success entries
        high_success = [
            e
            for e in entries
            if e.success_metrics.get("success", 0) > 0.7
        ]

        if high_success:
            for entry in high_success[:3]:
                # Extract practices from successful entries
                best_practices.append(entry.content)

        return best_practices

    def get_failure_insights(self, task_type: str) -> List[str]:
        """Get insights about failures for a task type.

        Args:
            task_type: Type of task

        Returns:
            List of failure insights
        """
        # Get entries for task type
        entries = self.knowledge_base.get_by_task_type(task_type, limit=10)

        failure_insights = []

        # Find low-success entries to learn from failures
        low_success = [
            e
            for e in entries
            if e.success_metrics.get("success", 0) < 0.3
        ]

        if low_success:
            for entry in low_success[:3]:
                # Extract lessons from failures
                failure_insights.append(f"Avoid: {entry.content[:100]}...")

        return failure_insights

    def get_similar_solutions(self, task: str) -> List[KnowledgeEntry]:
        """Get similar solutions from past tasks.

        Args:
            task: Task description

        Returns:
            List of similar knowledge entries with solutions
        """
        # Search for similar tasks
        similar = self.knowledge_base.search(task, top_k=5)

        # Filter for entries with solutions
        solutions = [
            e
            for e in similar
            if "solution" in e.metadata or "result" in e.metadata
        ]

        return solutions

    def build_system_prompt_supplement(self, task: str) -> str:
        """Build a system prompt supplement from knowledge.

        Args:
            task: Task description

        Returns:
            Formatted prompt supplement
        """
        prompt_parts = []

        # Add best practices
        best_practices = self.get_best_practices(self._extract_task_type(task))
        if best_practices:
            prompt_parts.append("## Best Practices\n")
            for practice in best_practices[:2]:
                prompt_parts.append(f"- {practice}\n")

        # Add tool suggestions
        tools = self.get_tool_suggestions(task, top_k=3)
        if tools:
            prompt_parts.append("\n## Suggested Tools\n")
            for tool in tools:
                prompt_parts.append(f"- {tool}\n")

        # Add failure insights
        failure_insights = self.get_failure_insights(
            self._extract_task_type(task)
        )
        if failure_insights:
            prompt_parts.append("\n## Common Pitfalls to Avoid\n")
            for insight in failure_insights[:2]:
                prompt_parts.append(f"- {insight}\n")

        return "".join(prompt_parts)

    @staticmethod
    def _extract_task_type(task: str) -> str:
        """Extract task type from task string."""
        words = task.lower().split()
        if len(words) > 0:
            return words[0]
        return "general"
