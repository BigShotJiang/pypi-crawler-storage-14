"""Provider helper for easy model initialization.

Provides factory methods for common model providers. All methods
return native smolagents Model instances for maximum compatibility.
"""

import os
from typing import Optional, Any
from pathlib import Path


class ModelProvider:
    """Factory for creating models from various providers.

    All methods return smolagents Model instances. You can also use
    smolagents' Model classes directly for more control.

    Example:
        >>> from smart import ModelProvider
        >>> model = ModelProvider.create_openai(api_key="sk-...")
        >>> # OR
        >>> from smolagents import OpenAIModel
        >>> model = OpenAIModel(model_id="gpt-4o-mini", api_key="sk-...")
    """

    @staticmethod
    def create_openai(
        model_id: str = "gpt-4o-mini",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """Create an OpenAI model instance.

        Args:
            model_id: Model identifier (e.g., "gpt-4o-mini", "gpt-4o")
            api_key: OpenAI API key. If not provided, uses OPENAI_API_KEY env var
            base_url: Custom base URL for OpenAI-compatible APIs
            **kwargs: Additional parameters (temperature, max_tokens, etc.)

        Returns:
            smolagents.OpenAIModel instance
        """
        from smolagents import OpenAIModel

        if api_key is None:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError(
                    "OpenAI API key not provided and OPENAI_API_KEY env var not set"
                )

        return OpenAIModel(
            model_id=model_id,
            api_key=api_key,
            api_base=base_url,
            **kwargs,
        )

    @staticmethod
    def create_anthropic(
        model_id: str = "claude-3-5-sonnet-latest",
        api_key: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """Create an Anthropic Claude model instance.

        Uses LiteLLM backend for broader compatibility.

        Args:
            model_id: Model identifier (e.g., "claude-3-5-sonnet-latest")
            api_key: Anthropic API key. If not provided, uses ANTHROPIC_API_KEY env var
            **kwargs: Additional parameters (temperature, max_tokens, etc.)

        Returns:
            smolagents.LiteLLMModel instance
        """
        from smolagents import LiteLLMModel

        if api_key is None:
            api_key = os.getenv("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError(
                    "Anthropic API key not provided and ANTHROPIC_API_KEY env var not set"
                )

        return LiteLLMModel(
            model_id=f"anthropic/{model_id}",
            api_key=api_key,
            **kwargs,
        )

    @staticmethod
    def create_huggingface(
        model_id: str = "meta-llama/Llama-3.3-70B-Instruct",
        provider: str = "together",
        api_key: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """Create a Hugging Face Inference API model instance.

        Supports 100+ providers: together, fireworks, cerebras, cohere, etc.

        Args:
            model_id: Model identifier (HF model card ID)
            provider: Provider name ("together", "fireworks", "cerebras", etc.)
            api_key: Provider API key. If not provided, tries env var
            **kwargs: Additional parameters (temperature, max_tokens, etc.)

        Returns:
            smolagents.InferenceClientModel instance
        """
        from smolagents import InferenceClientModel

        if api_key is None:
            # Try to get from env var based on provider
            env_vars = {
                "together": "TOGETHER_API_KEY",
                "fireworks": "FIREWORKS_API_KEY",
                "cerebras": "CEREBRAS_API_KEY",
                "cohere": "COHERE_API_KEY",
                "replicate": "REPLICATE_API_KEY",
            }
            env_var = env_vars.get(provider, f"{provider.upper()}_API_KEY")
            api_key = os.getenv(env_var)
            if not api_key:
                raise ValueError(
                    f"{provider.upper()} API key not provided and {env_var} env var not set"
                )

        return InferenceClientModel(
            model_id=model_id,
            provider=provider,
            token=api_key,  # InferenceClient uses 'token' parameter
            **kwargs,
        )

    @staticmethod
    def create_azure(
        model_id: str = "gpt-4o-mini",
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """Create an Azure OpenAI model instance.

        Args:
            model_id: Deployment name on Azure
            api_key: Azure API key. If not provided, uses AZURE_OPENAI_API_KEY env var
            endpoint: Azure endpoint URL. If not provided, uses AZURE_OPENAI_ENDPOINT env var
            **kwargs: Additional parameters (temperature, max_tokens, etc.)

        Returns:
            smolagents.AzureOpenAIModel instance
        """
        from smolagents import AzureOpenAIModel

        if api_key is None:
            api_key = os.getenv("AZURE_OPENAI_API_KEY")
            if not api_key:
                raise ValueError(
                    "Azure API key not provided and AZURE_OPENAI_API_KEY env var not set"
                )

        if endpoint is None:
            endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
            if not endpoint:
                raise ValueError(
                    "Azure endpoint not provided and AZURE_OPENAI_ENDPOINT env var not set"
                )

        return AzureOpenAIModel(
            model_id=model_id,
            api_key=api_key,
            api_base=endpoint,
            **kwargs,
        )

    @staticmethod
    def create_bedrock(
        model_id: str = "anthropic.claude-3-5-sonnet-20241022-v2:0",
        region: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """Create an AWS Bedrock model instance.

        Requires boto3 and AWS credentials configured.

        Args:
            model_id: Bedrock model identifier
            region: AWS region (if not provided, uses AWS_REGION env var or default)
            **kwargs: Additional parameters (temperature, max_tokens, etc.)

        Returns:
            smolagents.AmazonBedrockModel instance
        """
        from smolagents import AmazonBedrockModel

        return AmazonBedrockModel(
            model_id=model_id,
            region_name=region or os.getenv("AWS_REGION"),
            **kwargs,
        )

    @staticmethod
    def from_env(model_type: str = "auto") -> Any:
        """Create a model from environment variables.

        Attempts to auto-detect available credentials and create appropriate model.

        Args:
            model_type: Model type to create. Options:
                - "auto": Detect from available env vars
                - "openai": Force OpenAI
                - "anthropic": Force Anthropic
                - "huggingface": Force Hugging Face (needs provider env var)
                - "azure": Force Azure OpenAI
                - "bedrock": Force AWS Bedrock

        Returns:
            smolagents Model instance

        Raises:
            ValueError: If no suitable credentials found
        """
        # Auto-detect mode
        if model_type == "auto":
            if os.getenv("OPENAI_API_KEY"):
                return ModelProvider.create_openai()
            elif os.getenv("ANTHROPIC_API_KEY"):
                return ModelProvider.create_anthropic()
            elif os.getenv("TOGETHER_API_KEY"):
                return ModelProvider.create_huggingface(provider="together")
            elif os.getenv("AZURE_OPENAI_API_KEY"):
                return ModelProvider.create_azure()
            elif os.getenv("AWS_ACCESS_KEY_ID"):
                return ModelProvider.create_bedrock()
            else:
                raise ValueError(
                    "No supported API credentials found in environment variables. "
                    "Set one of: OPENAI_API_KEY, ANTHROPIC_API_KEY, TOGETHER_API_KEY, "
                    "AZURE_OPENAI_API_KEY, AWS_ACCESS_KEY_ID"
                )

        # Explicit mode selection
        if model_type == "openai":
            return ModelProvider.create_openai()
        elif model_type == "anthropic":
            return ModelProvider.create_anthropic()
        elif model_type == "huggingface":
            provider = os.getenv("HF_PROVIDER", "together")
            return ModelProvider.create_huggingface(provider=provider)
        elif model_type == "azure":
            return ModelProvider.create_azure()
        elif model_type == "bedrock":
            return ModelProvider.create_bedrock()
        else:
            raise ValueError(f"Unknown model type: {model_type}")

    @staticmethod
    def list_providers() -> dict:
        """List all available provider methods.

        Returns:
            Dictionary with provider info
        """
        return {
            "openai": {
                "description": "OpenAI GPT models",
                "env_var": "OPENAI_API_KEY",
                "models": ["gpt-4o-mini", "gpt-4o", "gpt-4-turbo"],
            },
            "anthropic": {
                "description": "Anthropic Claude models",
                "env_var": "ANTHROPIC_API_KEY",
                "models": ["claude-3-5-sonnet-latest", "claude-3-5-haiku-latest"],
            },
            "huggingface": {
                "description": "100+ providers via HF Inference",
                "env_var": "TOGETHER_API_KEY (or provider-specific)",
                "models": ["meta-llama/Llama-3.3-70B-Instruct", "..."],
            },
            "azure": {
                "description": "Azure OpenAI deployments",
                "env_var": "AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT",
                "models": ["gpt-4o-mini", "gpt-4o"],
            },
            "bedrock": {
                "description": "AWS Bedrock models",
                "env_var": "AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY",
                "models": ["anthropic.claude-3-5-sonnet-...", "..."],
            },
        }


__all__ = ['ModelProvider']
