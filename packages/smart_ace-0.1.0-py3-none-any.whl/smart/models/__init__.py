"""Model provider helpers for easy initialization.

Provides convenient factory methods for common model providers while
still allowing direct use of smolagents' Model classes.
"""

from smart.models.provider_helper import ModelProvider

__all__ = ['ModelProvider']
