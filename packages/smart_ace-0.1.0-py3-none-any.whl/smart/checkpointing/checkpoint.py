"""Checkpoint creation and management for agent execution state.

Automatically saves snapshots of execution state before significant events
(tool executions, code modifications, etc.) to enable recovery and replay.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List
import json
import logging
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class CheckpointType(Enum):
    """Types of checkpoints."""
    MANUAL = "manual"  # User-initiated
    AUTO = "auto"  # Automatic before tool execution
    RECOVERY = "recovery"  # After error recovery
    SESSION_START = "session_start"


@dataclass
class Checkpoint:
    """A single checkpoint snapshot.

    Contains agent execution state at a specific point in time,
    enabling recovery and replay functionality.
    """
    checkpoint_id: str
    session_id: str
    timestamp: datetime
    checkpoint_type: CheckpointType
    agent_state: Dict[str, Any]  # Complete agent state
    session_state: Dict[str, Any]  # Session state (steps, metadata)
    code_state: Optional[Dict[str, str]] = None  # Modified files
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert checkpoint to dictionary for serialization."""
        return {
            "checkpoint_id": self.checkpoint_id,
            "session_id": self.session_id,
            "timestamp": self.timestamp.isoformat(),
            "checkpoint_type": self.checkpoint_type.value,
            "agent_state": self.agent_state,
            "session_state": self.session_state,
            "code_state": self.code_state,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Checkpoint":
        """Create checkpoint from dictionary."""
        return cls(
            checkpoint_id=data["checkpoint_id"],
            session_id=data["session_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            checkpoint_type=CheckpointType(data["checkpoint_type"]),
            agent_state=data["agent_state"],
            session_state=data["session_state"],
            code_state=data.get("code_state"),
            metadata=data.get("metadata", {}),
        )


class CheckpointManager:
    """Manages checkpoint creation, storage, and recovery.

    Handles:
    - Automatic checkpoint creation at key points
    - Checkpoint storage (git-based for code, JSON for state)
    - Checkpoint listing and filtering
    - 30-day auto-cleanup
    - Checkpoint size management
    """

    def __init__(
        self,
        checkpoint_dir: Path,
        retention_days: int = 30,
        max_checkpoints_per_session: int = 100,
    ):
        """Initialize checkpoint manager.

        Args:
            checkpoint_dir: Directory to store checkpoints
            retention_days: Keep checkpoints for this many days (30-day default like Claude Code)
            max_checkpoints_per_session: Maximum checkpoints per session before cleanup
        """
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.retention_days = retention_days
        self.max_checkpoints_per_session = max_checkpoints_per_session

        # Subdirectories
        self.metadata_dir = self.checkpoint_dir / "metadata"
        self.state_dir = self.checkpoint_dir / "state"
        self.code_dir = self.checkpoint_dir / "code"

        for d in [self.metadata_dir, self.state_dir, self.code_dir]:
            d.mkdir(exist_ok=True)

    def create_checkpoint(
        self,
        session_id: str,
        agent_state: Dict[str, Any],
        session_state: Dict[str, Any],
        checkpoint_type: CheckpointType = CheckpointType.AUTO,
        code_state: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Checkpoint:
        """Create a new checkpoint.

        Args:
            session_id: Session this checkpoint belongs to
            agent_state: Complete agent execution state
            session_state: Current session state (steps, results, etc.)
            checkpoint_type: Type of checkpoint (auto, manual, etc.)
            code_state: Modified files (path -> content)
            metadata: Additional metadata for checkpoint

        Returns:
            Created checkpoint
        """
        checkpoint_id = str(uuid.uuid4())
        now = datetime.now()

        checkpoint = Checkpoint(
            checkpoint_id=checkpoint_id,
            session_id=session_id,
            timestamp=now,
            checkpoint_type=checkpoint_type,
            agent_state=agent_state,
            session_state=session_state,
            code_state=code_state or {},
            metadata=metadata or {},
        )

        # Save checkpoint metadata
        metadata_path = self.metadata_dir / f"{checkpoint_id}.json"
        metadata_path.write_text(
            json.dumps(checkpoint.to_dict(), default=str, indent=2)
        )

        # Save state
        state_path = self.state_dir / f"{checkpoint_id}.json"
        state_path.write_text(
            json.dumps({
                "agent_state": agent_state,
                "session_state": session_state,
            }, default=str, indent=2)
        )

        # Save code state
        if code_state:
            code_path = self.code_dir / checkpoint_id
            code_path.mkdir(exist_ok=True)
            for file_path, content in code_state.items():
                file_obj = code_path / file_path.lstrip("/")
                file_obj.parent.mkdir(parents=True, exist_ok=True)
                file_obj.write_text(content)

        logger.info(f"Created checkpoint {checkpoint_id} for session {session_id}")

        # Cleanup if needed
        self._cleanup_old_checkpoints(session_id)

        return checkpoint

    def get_checkpoint(self, checkpoint_id: str) -> Optional[Checkpoint]:
        """Get a specific checkpoint.

        Args:
            checkpoint_id: ID of checkpoint to retrieve

        Returns:
            Checkpoint object or None if not found
        """
        metadata_path = self.metadata_dir / f"{checkpoint_id}.json"
        if not metadata_path.exists():
            return None

        data = json.loads(metadata_path.read_text())
        return Checkpoint.from_dict(data)

    def list_checkpoints(
        self,
        session_id: Optional[str] = None,
        checkpoint_type: Optional[CheckpointType] = None,
        limit: int = 20,
    ) -> List[Checkpoint]:
        """List checkpoints with optional filtering.

        Args:
            session_id: Filter by session ID
            checkpoint_type: Filter by checkpoint type
            limit: Maximum number to return (most recent first)

        Returns:
            List of checkpoints
        """
        checkpoints = []

        for metadata_file in sorted(
            self.metadata_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )[:limit]:
            data = json.loads(metadata_file.read_text())
            checkpoint = Checkpoint.from_dict(data)

            if session_id and checkpoint.session_id != session_id:
                continue
            if checkpoint_type and checkpoint.checkpoint_type != checkpoint_type:
                continue

            checkpoints.append(checkpoint)

        return checkpoints

    def restore_checkpoint(
        self,
        checkpoint_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Restore state from a checkpoint.

        Returns the complete checkpoint state for recovery.

        Args:
            checkpoint_id: ID of checkpoint to restore

        Returns:
            Checkpoint data dict or None if not found
        """
        state_path = self.state_dir / f"{checkpoint_id}.json"
        if not state_path.exists():
            return None

        return json.loads(state_path.read_text())

    def get_checkpoint_code(self, checkpoint_id: str) -> Optional[Dict[str, str]]:
        """Get code state from a checkpoint.

        Args:
            checkpoint_id: ID of checkpoint

        Returns:
            Dict of file paths to contents, or None if no code state
        """
        code_path = self.code_dir / checkpoint_id
        if not code_path.exists():
            return None

        code_state = {}
        for file_path in code_path.rglob("*"):
            if file_path.is_file():
                rel_path = file_path.relative_to(code_path)
                code_state[f"/{rel_path}"] = file_path.read_text()

        return code_state if code_state else None

    def delete_checkpoint(self, checkpoint_id: str) -> bool:
        """Delete a checkpoint.

        Args:
            checkpoint_id: ID of checkpoint to delete

        Returns:
            True if deleted, False if not found
        """
        deleted = False

        # Delete metadata
        metadata_path = self.metadata_dir / f"{checkpoint_id}.json"
        if metadata_path.exists():
            metadata_path.unlink()
            deleted = True

        # Delete state
        state_path = self.state_dir / f"{checkpoint_id}.json"
        if state_path.exists():
            state_path.unlink()
            deleted = True

        # Delete code
        code_path = self.code_dir / checkpoint_id
        if code_path.exists():
            import shutil
            shutil.rmtree(code_path)
            deleted = True

        return deleted

    def _cleanup_old_checkpoints(self, session_id: str) -> None:
        """Clean up old checkpoints for a session.

        Removes:
        1. Checkpoints older than retention_days
        2. Beyond max_checkpoints_per_session

        Args:
            session_id: Session to cleanup
        """
        checkpoints = self.list_checkpoints(session_id=session_id, limit=1000)
        now = datetime.now()
        cutoff = now - timedelta(days=self.retention_days)

        # Remove old checkpoints
        for checkpoint in checkpoints:
            if checkpoint.timestamp < cutoff:
                self.delete_checkpoint(checkpoint.checkpoint_id)
                logger.debug(f"Deleted old checkpoint {checkpoint.checkpoint_id}")

        # Remove excess checkpoints (keep most recent)
        session_checkpoints = [
            c for c in checkpoints
            if c.session_id == session_id
        ]

        if len(session_checkpoints) > self.max_checkpoints_per_session:
            to_delete = session_checkpoints[self.max_checkpoints_per_session:]
            for checkpoint in to_delete:
                self.delete_checkpoint(checkpoint.checkpoint_id)
                logger.debug(f"Deleted excess checkpoint {checkpoint.checkpoint_id}")


__all__ = ["Checkpoint", "CheckpointManager", "CheckpointType"]
