"""Rewind system for undoing agent actions.

Allows reverting to previous checkpoints with multiple rewind modes:
- Code-only: Restore only code state, keep conversation
- Conversation-only: Restore session steps, discard code changes
- Full: Complete rewind to checkpoint state
"""

from typing import Optional, List, Literal
from pathlib import Path
import logging

from smart.checkpointing.checkpoint import (
    Checkpoint,
    CheckpointManager,
)

logger = logging.getLogger(__name__)


class RewindSystem:
    """Manages rewinding to previous agent states.

    Provides Claude Code-style rewind functionality with multiple modes:
    - code: Restore only code modifications
    - session: Restore session/conversation state
    - full: Complete rewind to checkpoint
    """

    def __init__(self, checkpoint_manager: CheckpointManager):
        """Initialize rewind system.

        Args:
            checkpoint_manager: Manager for accessing checkpoints
        """
        self.checkpoint_manager = checkpoint_manager

    def get_available_rewinders(
        self,
        session_id: str,
        limit: int = 10,
    ) -> List[dict]:
        """Get available checkpoints for rewinding.

        Args:
            session_id: Session to get checkpoints for
            limit: Maximum number of checkpoints to return

        Returns:
            List of checkpoint info for UI display
        """
        checkpoints = self.checkpoint_manager.list_checkpoints(
            session_id=session_id,
            limit=limit,
        )

        return [
            {
                "checkpoint_id": c.checkpoint_id,
                "timestamp": c.timestamp.isoformat(),
                "type": c.checkpoint_type.value,
                "steps": len(c.session_state.get("steps", [])),
                "has_code": bool(c.code_state),
            }
            for c in checkpoints
        ]

    def rewind_to(
        self,
        checkpoint_id: str,
        mode: Literal["code", "session", "full"] = "full",
    ) -> Optional[dict]:
        """Rewind to a specific checkpoint.

        Args:
            checkpoint_id: ID of checkpoint to rewind to
            mode: Rewind mode
                - "code": Restore only code state
                - "session": Restore only session state
                - "full": Complete rewind (code + session)

        Returns:
            Rewind data with state to restore, or None if checkpoint not found
        """
        checkpoint = self.checkpoint_manager.get_checkpoint(checkpoint_id)
        if not checkpoint:
            logger.warning(f"Checkpoint {checkpoint_id} not found")
            return None

        state = self.checkpoint_manager.restore_checkpoint(checkpoint_id)
        code_state = self.checkpoint_manager.get_checkpoint_code(checkpoint_id)

        rewind_data = {
            "checkpoint_id": checkpoint_id,
            "timestamp": checkpoint.timestamp.isoformat(),
            "mode": mode,
        }

        # Include appropriate state based on mode
        if mode in ["session", "full"]:
            rewind_data["session_state"] = state.get("session_state")
            rewind_data["steps"] = state.get("session_state", {}).get("steps", [])

        if mode in ["code", "full"]:
            rewind_data["code_state"] = code_state
            rewind_data["code_changes"] = self._compute_code_changes(code_state)

        logger.info(
            f"Rewind available to checkpoint {checkpoint_id} "
            f"(type: {mode}, timestamp: {checkpoint.timestamp})"
        )

        return rewind_data

    def rewind_steps(
        self,
        session_id: str,
        steps_back: int = 1,
        mode: Literal["code", "session", "full"] = "full",
    ) -> Optional[dict]:
        """Rewind by N steps from most recent checkpoint.

        Args:
            session_id: Session to rewind
            steps_back: Number of steps to go back
            mode: Rewind mode (code, session, or full)

        Returns:
            Rewind data or None if not possible
        """
        checkpoints = self.checkpoint_manager.list_checkpoints(
            session_id=session_id,
            limit=steps_back + 1,
        )

        if len(checkpoints) <= steps_back:
            logger.warning(
                f"Only {len(checkpoints)} checkpoints available, "
                f"cannot rewind {steps_back} steps"
            )
            return None

        target_checkpoint = checkpoints[steps_back]
        return self.rewind_to(target_checkpoint.checkpoint_id, mode=mode)

    def list_rewind_history(
        self,
        session_id: str,
        limit: int = 20,
    ) -> List[dict]:
        """Get rewind history for a session (UI display).

        Args:
            session_id: Session to get history for
            limit: Maximum number to return

        Returns:
            List of rewindable checkpoints with metadata
        """
        return self.get_available_rewinders(session_id, limit=limit)

    @staticmethod
    def _compute_code_changes(code_state: Optional[dict]) -> dict:
        """Compute code changes from checkpoint state.

        Args:
            code_state: Code files in checkpoint

        Returns:
            Summary of code changes
        """
        if not code_state:
            return {"files_changed": 0, "files": []}

        return {
            "files_changed": len(code_state),
            "files": list(code_state.keys()),
        }


__all__ = ["RewindSystem"]
