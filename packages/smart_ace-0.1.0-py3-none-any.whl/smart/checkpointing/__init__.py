"""Checkpointing system for smart-agent.

Provides save/restore functionality for agent execution state,
similar to Claude Code's checkpoint mechanism.

Features:
- Automatic checkpoint creation before edits
- Rewind to previous states (code-only or full)
- Git-based diff tracking
- 30-day auto-cleanup of old checkpoints
"""

from smart.checkpointing.checkpoint import Checkpoint, CheckpointManager
from smart.checkpointing.rewind import RewindSystem

__all__ = [
    "Checkpoint",
    "CheckpointManager",
    "RewindSystem",
]
