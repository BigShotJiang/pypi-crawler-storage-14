"""Async/sync compatibility wrappers."""

import asyncio
from typing import TypeVar, Callable, Awaitable, List, Any

T = TypeVar("T")


async def to_thread_safe(func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run a sync function in a thread pool.

    Args:
        func: Sync function to run
        *args: Positional arguments
        **kwargs: Keyword arguments

    Returns:
        Result from function
    """
    return await asyncio.to_thread(func, *args, **kwargs)


async def gather_sync(*funcs: Callable[[], T]) -> List[T]:
    """Run multiple sync functions concurrently.

    Args:
        *funcs: Functions to run

    Returns:
        List of results
    """
    tasks = [asyncio.to_thread(f) for f in funcs]
    return await asyncio.gather(*tasks)
