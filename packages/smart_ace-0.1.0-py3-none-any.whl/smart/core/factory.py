"""Factory functions for creating SmartAgent instances."""

from pathlib import Path
from typing import Optional, List, Literal, Any
from smolagents import CodeAgent, ToolCallingAgent

from smart.core.agent import SmartAgent
from smart.core.session import SessionManager
from smart.core.registry import SmartAgentPlugin


def create_smart(
    agent_type: Literal["code", "toolcalling"],
    model: Any,
    tools: Optional[List[Any]] = None,
    *,
    persistence_dir: Optional[Path] = None,
    embedding_model: str = "all-MiniLM-L6-v2",
    enable_observability: bool = True,
    enable_async: bool = True,
    checkpoint_interval: int = 5,
    plugins: Optional[List[SmartAgentPlugin]] = None,
    include_dashboard_tools: bool = False,
    **smolagent_kwargs,
) -> SmartAgent:
    """Create a SmartAgent with sensible defaults.

    Args:
        agent_type: "code" or "toolcalling"
        model: Language model instance
        tools: List of tools
        persistence_dir: Directory for session persistence
        embedding_model: Model for embeddings
        enable_observability: Enable metrics collection
        enable_async: Enable async API
        checkpoint_interval: Save every N steps
        plugins: List of plugins to register
        include_dashboard_tools: Include dashboard creation tools
        **smolagent_kwargs: Additional kwargs for smolagents

    Returns:
        SmartAgent instance
    """
    if tools is None:
        tools = []

    # Add dashboard tools if requested
    if include_dashboard_tools:
        from smart.ui.dashboard_tools import (
            create_metrics_dashboard,
            create_session_report,
            format_execution_summary,
        )
        from smolagents import tool as smolagent_tool

        # Wrap dashboard functions as smolagents tools
        @smolagent_tool
        def dashboard_metrics(metrics: dict) -> str:
            """Create an HTML metrics dashboard.

            Args:
                metrics: Dictionary with keys like total_steps, total_duration, total_tokens, total_cost, success_rate, avg_step_duration

            Returns:
                HTML string for the dashboard
            """
            return create_metrics_dashboard(metrics)

        @smolagent_tool
        def report_session(session: dict, metrics: Optional[dict] = None) -> str:
            """Generate a session report.

            Args:
                session: Session dictionary
                metrics: Optional metrics dictionary

            Returns:
                JSON string report
            """
            return create_session_report(session, metrics)

        @smolagent_tool
        def summary_execution(session: dict, metrics: Optional[dict] = None) -> str:
            """Format an execution summary.

            Args:
                session: Session dictionary
                metrics: Optional metrics dictionary

            Returns:
                Formatted summary string
            """
            return format_execution_summary(session, metrics)

        # Add tools to the tools list
        tools = list(tools) if tools else []
        tools.extend([dashboard_metrics, report_session, summary_execution])

    # Create base smolagents agent
    if agent_type == "code":
        smolagent = CodeAgent(model=model, tools=tools, **smolagent_kwargs)
    elif agent_type == "toolcalling":
        smolagent = ToolCallingAgent(model=model, tools=tools, **smolagent_kwargs)
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")

    # Setup persistence
    session_manager = None
    if persistence_dir:
        persistence_dir = Path(persistence_dir)
        from smart.persistence.hybrid import HybridBackend

        backend = HybridBackend(
            base_dir=persistence_dir / "sessions",
            db_path=persistence_dir / "sessions.duckdb",
            embedding_model=embedding_model,
        )
        session_manager = SessionManager(backend)
    else:
        # Use in-memory session manager
        session_manager = SessionManager()

    # Setup observability
    metrics_collector = None
    if enable_observability:
        from smart.observability.metrics import MetricsCollector

        metrics_collector = MetricsCollector()

    # Create SmartAgent
    agent = SmartAgent(
        smolagent=smolagent,
        session_manager=session_manager,
        metrics_collector=metrics_collector,
        enable_async=enable_async,
    )

    # Register plugins
    if plugins:
        for plugin in plugins:
            plugin.initialize(agent)

    return agent
