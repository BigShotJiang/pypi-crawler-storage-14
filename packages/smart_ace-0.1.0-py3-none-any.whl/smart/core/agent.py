"""SmartAgent wrapper class for enhanced smolagents functionality."""

import asyncio
from typing import Optional, Any, AsyncIterator, Iterator
from datetime import datetime
from smolagents import MultiStepAgent
from smart.core.session import SessionManager
from smart.persistence.base import Session
from smart.utils.errors import SmartAgentError


class SmartAgent:
    """Enhanced agent wrapper with persistence, sessions, and observability.

    Integrates with smolagents' native step tracking (agent.memory) and
    uses step_callbacks for real-time metrics collection.
    """

    def __init__(
        self,
        smolagent: MultiStepAgent,
        session_manager: Optional[SessionManager] = None,
        metrics_collector: Optional[Any] = None,
        enable_async: bool = True,
    ):
        """Initialize SmartAgent.

        Args:
            smolagent: Base smolagents MultiStepAgent instance
            session_manager: SessionManager for persistence
            metrics_collector: MetricsCollector for observability
            enable_async: Enable async API
        """
        self._smolagent = smolagent
        self._session_manager = session_manager
        self._metrics = metrics_collector
        self._enable_async = enable_async
        self._current_session: Optional[Session] = None

        # Register callbacks for step-level metrics collection
        self._register_callbacks()

    def _register_callbacks(self) -> None:
        """Register step_callback with smolagent for real-time metrics."""
        if self._metrics and hasattr(self._smolagent, 'step_callbacks'):
            # Use smolagent's native step_callbacks instead of wrapping run()
            self._smolagent.step_callbacks.append(self._on_step)

    def _on_step(self, step: Any) -> None:
        """Handle step callback from smolagent.

        Called by smolagent at each step during execution.

        Args:
            step: Step object from smolagent
        """
        if self._metrics and self._current_session:
            try:
                # Record metrics in real-time
                self._metrics.record_step(
                    step,
                    session_id=self._current_session.session_id,
                    step_index=len(self._current_session.steps),
                )
            except Exception as e:
                # Don't let metrics collection fail the execution
                pass

    def _get_or_create_session(
        self, session_id: Optional[str] = None, resume: bool = False
    ) -> Session:
        """Get or create a session.

        Args:
            session_id: Optional session ID
            resume: Whether to resume an existing session

        Returns:
            Session
        """
        if session_id:
            if resume:
                session = self._session_manager.resume_session(session_id)
            else:
                session = self._session_manager.get_session(session_id)
                if not session:
                    raise SmartAgentError(f"Session {session_id} not found")
        else:
            agent_name = getattr(self._smolagent, "name", "agent")
            session = self._session_manager.create_session(agent_name, "")

        self._current_session = session
        return session

    def run(
        self,
        task: str,
        session_id: Optional[str] = None,
        resume: bool = False,
    ) -> Any:
        """Run agent synchronously.

        Args:
            task: Task to execute
            session_id: Optional session ID
            resume: Whether to resume previous session

        Returns:
            Agent result
        """
        session = self._get_or_create_session(session_id, resume)
        session.task = task

        try:
            result = self._smolagent.run(task)

            # Synchronize session.steps from smolagent's native memory
            self._sync_session_from_memory(session)

            session.mark_completed()
            return result
        except Exception as e:
            # Still try to sync what we can
            self._sync_session_from_memory(session)
            session.mark_failed(e)
            raise
        finally:
            if self._session_manager:
                self._session_manager.save_session(session)

    async def arun(
        self,
        task: str,
        session_id: Optional[str] = None,
        resume: bool = False,
    ) -> Any:
        """Run agent asynchronously.

        Args:
            task: Task to execute
            session_id: Optional session ID
            resume: Whether to resume previous session

        Returns:
            Agent result
        """
        if not self._enable_async:
            raise SmartAgentError("Async not enabled")

        # Run sync code in thread pool
        return await asyncio.to_thread(self.run, task, session_id, resume)

    def stream(
        self, task: str, session_id: Optional[str] = None
    ) -> Iterator[Any]:
        """Stream agent execution.

        Args:
            task: Task to execute
            session_id: Optional session ID

        Yields:
            Agent steps
        """
        session = self._get_or_create_session(session_id)
        session.task = task

        try:
            for step in self._smolagent._run_stream(task):
                # Steps are collected via step_callbacks for metrics
                # We just yield and sync at the end
                yield step

            # Synchronize all steps from smolagent's memory after completion
            self._sync_session_from_memory(session)
            session.mark_completed()
        except Exception as e:
            # Still try to sync what we can
            self._sync_session_from_memory(session)
            session.mark_failed(e)
            raise
        finally:
            if self._session_manager:
                self._session_manager.save_session(session)

    async def astream(
        self, task: str, session_id: Optional[str] = None
    ) -> AsyncIterator[Any]:
        """Stream agent execution asynchronously.

        Args:
            task: Task to execute
            session_id: Optional session ID

        Yields:
            Agent steps
        """
        for step in self.stream(task, session_id):
            yield step
            await asyncio.sleep(0)  # Yield control

    def _sync_session_from_memory(self, session: Session) -> None:
        """Synchronize session steps from smolagent's native memory.

        Reads from agent.memory (the authoritative source) instead of
        maintaining parallel tracking. This eliminates duplication and
        ensures session.steps reflects actual execution.

        Args:
            session: Session to synchronize
        """
        try:
            # Get full steps from smolagent's memory if available
            if hasattr(self._smolagent, 'memory') and hasattr(
                self._smolagent.memory, 'get_full_steps'
            ):
                full_steps = self._smolagent.memory.get_full_steps()
                # Convert to our session format
                session.steps = [
                    {
                        'type': type(step).__name__,
                        'content': str(step),
                        'data': step.__dict__ if hasattr(step, '__dict__') else {},
                    }
                    for step in full_steps
                ]
        except Exception as e:
            # If sync fails, continue - partial data is better than none
            pass

    def get_session(self, session_id: str) -> Optional[Session]:
        """Get a session.

        Args:
            session_id: Session ID

        Returns:
            Session or None
        """
        if self._session_manager:
            return self._session_manager.get_session(session_id)
        return None

    def __getattr__(self, name: str) -> Any:
        """Delegate unknown attributes to smolagent.

        Args:
            name: Attribute name

        Returns:
            Attribute value from smolagent
        """
        return getattr(self._smolagent, name)
