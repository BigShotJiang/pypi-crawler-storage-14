"""Session management for smart-agent."""

import uuid
import asyncio
from typing import Optional, List
from datetime import datetime
from smart.persistence.base import Session, PersistenceBackend
from smart.utils.errors import SessionError


class SessionManager:
    """Manages agent sessions with persistence."""

    def __init__(self, persistence_backend: Optional[PersistenceBackend] = None):
        """Initialize SessionManager.

        Args:
            persistence_backend: Backend for persisting sessions
        """
        self._backend = persistence_backend
        self._active_sessions: dict[str, Session] = {}

    def create_session(self, agent_name: str, task: str) -> Session:
        """Create a new session.

        Args:
            agent_name: Name of the agent
            task: Task description

        Returns:
            Created Session
        """
        session_id = str(uuid.uuid4())
        session = Session(
            session_id=session_id,
            agent_name=agent_name,
            task=task,
            status="active",
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        self._active_sessions[session_id] = session
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        """Get a session by ID.

        Args:
            session_id: Session ID

        Returns:
            Session or None if not found
        """
        # Try active sessions first
        if session_id in self._active_sessions:
            return self._active_sessions[session_id]

        # Try loading from persistence
        if self._backend:
            return self._backend.load_session(session_id)

        return None

    def save_session(self, session: Session) -> None:
        """Save a session.

        Args:
            session: Session to save
        """
        if self._backend:
            self._backend.save_session(session)

    async def asave_session(self, session: Session) -> None:
        """Save a session asynchronously.

        Args:
            session: Session to save
        """
        if self._backend:
            await asyncio.to_thread(self._backend.save_session, session)

    def resume_session(self, session_id: str) -> Session:
        """Resume a previous session.

        Args:
            session_id: ID of session to resume

        Returns:
            Resumed Session

        Raises:
            SessionError: If session not found
        """
        session = self.get_session(session_id)
        if not session:
            raise SessionError(f"Session {session_id} not found")

        session.mark_recovered()
        self._active_sessions[session_id] = session
        return session

    def list_sessions(self, status: Optional[str] = None) -> List[Session]:
        """List all sessions, optionally filtered by status.

        Args:
            status: Optional status to filter by

        Returns:
            List of sessions
        """
        if self._backend:
            return self._backend.list_sessions(status)
        return []

    def delete_session(self, session_id: str) -> None:
        """Delete a session.

        Args:
            session_id: Session ID to delete
        """
        if session_id in self._active_sessions:
            del self._active_sessions[session_id]

        if self._backend:
            self._backend.delete_session(session_id)
