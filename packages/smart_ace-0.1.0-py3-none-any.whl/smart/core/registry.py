"""Plugin registry system for smart-agent."""

from abc import ABC, abstractmethod
from typing import Dict, List, Callable, Any, Protocol


class SmartAgentPlugin(Protocol):
    """Protocol for smart-agent plugins."""

    def get_callbacks(self) -> Dict[type, List[Callable]]:
        """Return callbacks for step types.

        Returns:
            Dict mapping step types to list of callbacks
        """
        ...

    def initialize(self, agent: Any) -> None:
        """Initialize plugin with agent instance.

        Args:
            agent: SmartAgent instance
        """
        ...


class PluginRegistry:
    """Registry for managing plugins."""

    def __init__(self):
        """Initialize plugin registry."""
        self._plugins: List[SmartAgentPlugin] = []
        self._callbacks: Dict[type, List[Callable]] = {}

    def register(self, plugin: SmartAgentPlugin) -> "PluginRegistry":
        """Register a plugin.

        Args:
            plugin: Plugin to register

        Returns:
            Self for chaining
        """
        self._plugins.append(plugin)
        callbacks = plugin.get_callbacks()
        for step_type, cbs in callbacks.items():
            self._callbacks.setdefault(step_type, []).extend(cbs)
        return self

    def get_callbacks(self) -> Dict[type, List[Callable]]:
        """Get all registered callbacks.

        Returns:
            Dict of callbacks by step type
        """
        return self._callbacks

    def get_callbacks_for_type(self, step_type: type) -> List[Callable]:
        """Get callbacks for a specific step type.

        Args:
            step_type: Type of step

        Returns:
            List of callbacks
        """
        return self._callbacks.get(step_type, [])
