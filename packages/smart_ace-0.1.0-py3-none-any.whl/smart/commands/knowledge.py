"""Knowledge management commands for learning and querying knowledge base.

Provides /learn and /knowledge commands for curating and retrieving knowledge
from agent execution sessions.
"""

from typing import Optional
import logging

from smart.commands.base import Command, CommandContext, CommandResult

logger = logging.getLogger(__name__)


class LearnCommand(Command):
    """Command to learn from current or specified session.

    Usage:
        /learn - Learn from current session
        /learn session_id:abc123 - Learn from specific session
    """

    @staticmethod
    def _get_name() -> str:
        """Get command name."""
        return "learn"

    @staticmethod
    def _get_help() -> str:
        """Get help text."""
        return (
            "Learn from session execution and curate knowledge. "
            "Usage: /learn [session_id]\n"
            "  No args: Learn from current session\n"
            "  session_id: Learn from specific session"
        )

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute learn command.

        Args:
            context: Command context
            args: Optional session_id to learn from

        Returns:
            CommandResult with learning outcome
        """
        try:
            # Get knowledge curator if available
            curator = context.extra.get("knowledge_curator")
            if not curator:
                return CommandResult(
                    success=False,
                    output=None,
                    error="Knowledge curator not configured",
                )

            # Get session to learn from
            session_manager = context.extra.get("session_manager")
            if not session_manager:
                return CommandResult(
                    success=False,
                    output=None,
                    error="Session manager not available",
                )

            # Determine which session to learn from
            if args and args.strip():
                session_id = args.strip()
            else:
                session_id = context.session_id

            # Load session
            session = session_manager.get_session(session_id)
            if not session:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Session not found: {session_id}",
                )

            # Learn from session
            learned_entry = curator.learn_from_session(session)

            if learned_entry:
                output = {
                    "success": True,
                    "message": f"✓ Learned from session {session_id[:8]}...",
                    "entry_id": learned_entry.id,
                    "task_type": learned_entry.task_type,
                    "success_metrics": learned_entry.success_metrics,
                    "tags": learned_entry.tags,
                }
            else:
                output = {
                    "success": False,
                    "message": "No learnable content found in session",
                }

            return CommandResult(
                success=learned_entry is not None,
                output=output,
            )

        except Exception as e:
            logger.error(f"Learn command failed: {e}")
            return CommandResult(
                success=False,
                output=None,
                error=str(e),
            )


class KnowledgeCommand(Command):
    """Command to query knowledge base.

    Usage:
        /knowledge search:query - Search knowledge base
        /knowledge stats - Show knowledge base statistics
        /knowledge by-type:task_type - Get entries by task type
    """

    @staticmethod
    def _get_name() -> str:
        """Get command name."""
        return "knowledge"

    @staticmethod
    def _get_help() -> str:
        """Get help text."""
        return (
            "Query knowledge base. "
            "Usage: /knowledge [search:query|stats|by-type:task_type]\n"
            "  search:query - Search for knowledge\n"
            "  stats - Show knowledge statistics\n"
            "  by-type:type - Get entries by task type"
        )

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute knowledge command.

        Args:
            context: Command context
            args: Subcommand and arguments

        Returns:
            CommandResult with query results
        """
        try:
            # Get knowledge curator
            curator = context.extra.get("knowledge_curator")
            if not curator:
                return CommandResult(
                    success=False,
                    output=None,
                    error="Knowledge curator not configured",
                )

            if not args or not args.strip():
                return CommandResult(
                    success=False,
                    output=None,
                    error="Please specify subcommand: search, stats, or by-type",
                )

            # Parse subcommand
            parts = args.strip().split(":", 1)
            subcommand = parts[0].lower()

            if subcommand == "search":
                return self._handle_search(curator, parts)
            elif subcommand == "stats":
                return self._handle_stats(curator)
            elif subcommand == "by-type":
                return self._handle_by_type(curator, parts)
            else:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Unknown subcommand: {subcommand}",
                )

        except Exception as e:
            logger.error(f"Knowledge command failed: {e}")
            return CommandResult(
                success=False,
                output=None,
                error=str(e),
            )

    def _handle_search(self, curator, parts) -> CommandResult:
        """Handle search subcommand."""
        if len(parts) < 2:
            return CommandResult(
                success=False,
                output=None,
                error="Usage: /knowledge search:query",
            )

        query = parts[1]

        # Get knowledge retriever
        retriever = curator.knowledge_base.search(query, top_k=3)

        if not retriever:
            return CommandResult(
                success=True,
                output={
                    "message": f"No matching knowledge found for: {query}",
                    "results": [],
                },
            )

        results = [
            {
                "task_type": r.task_type,
                "content": r.content[:100] + "..." if len(r.content) > 100 else r.content,
                "success_metrics": r.success_metrics,
                "tags": r.tags,
            }
            for r in retriever
        ]

        return CommandResult(
            success=True,
            output={
                "message": f"Found {len(results)} matching entries",
                "query": query,
                "results": results,
            },
        )

    def _handle_stats(self, curator) -> CommandResult:
        """Handle stats subcommand."""
        stats = curator.get_statistics()

        return CommandResult(
            success=True,
            output={
                "message": "Knowledge base statistics",
                "statistics": stats,
            },
        )

    def _handle_by_type(self, curator, parts) -> CommandResult:
        """Handle by-type subcommand."""
        if len(parts) < 2:
            return CommandResult(
                success=False,
                output=None,
                error="Usage: /knowledge by-type:task_type",
            )

        task_type = parts[1]

        entries = curator.knowledge_base.get_by_task_type(task_type, limit=5)

        if not entries:
            return CommandResult(
                success=True,
                output={
                    "message": f"No entries found for task type: {task_type}",
                    "task_type": task_type,
                    "entries": [],
                },
            )

        results = [
            {
                "id": e.id[:8],
                "content": e.content[:80] + "..." if len(e.content) > 80 else e.content,
                "success_metrics": e.success_metrics,
                "tags": e.tags,
            }
            for e in entries
        ]

        return CommandResult(
            success=True,
            output={
                "message": f"Found {len(results)} entries for {task_type}",
                "task_type": task_type,
                "count": len(results),
                "entries": results,
            },
        )


__all__ = [
    "LearnCommand",
    "KnowledgeCommand",
]
