"""Slash commands system for smart-agent.

Provides Claude Code-style slash commands for agent control:
- /rewind - Rewind to previous checkpoints
- /resume - Resume from checkpoint
- /cost - Show execution costs
- /context - Manage context window
- /model - Switch AI model
- Custom commands from .claude/commands/
"""

from smart.commands.base import (
    Command,
    CommandRegistry,
    CommandContext,
    CommandResult,
)
from smart.commands.builtin import (
    RewindCommand,
    ResumeCommand,
    CostCommand,
    ContextCommand,
    ModelCommand,
    HelpCommand,
)
from smart.commands.knowledge import (
    LearnCommand,
    KnowledgeCommand,
)

__all__ = [
    "Command",
    "CommandRegistry",
    "CommandContext",
    "CommandResult",
    "RewindCommand",
    "ResumeCommand",
    "CostCommand",
    "ContextCommand",
    "ModelCommand",
    "HelpCommand",
    "LearnCommand",
    "KnowledgeCommand",
]
