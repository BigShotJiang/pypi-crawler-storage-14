"""Base command infrastructure for slash commands.

Provides command registry, parsing, and execution framework.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Callable, Literal
from pathlib import Path
import logging
import re

logger = logging.getLogger(__name__)


@dataclass
class CommandResult:
    """Result of command execution.

    Attributes:
        success: Whether command executed successfully
        output: Command output/result
        error: Error message if failed
        should_continue: Whether to continue agent execution
    """
    success: bool
    output: Any
    error: Optional[str] = None
    should_continue: bool = True


@dataclass
class CommandContext:
    """Context provided to commands during execution.

    Attributes:
        agent: Reference to SmartAgent instance
        session_id: Current session ID
        checkpoint_manager: Access to checkpoints
        rewind_system: Access to rewind functionality
        metrics: Access to metrics/cost data
        models_config: Available models configuration
    """
    agent: Any  # SmartAgent instance
    session_id: str
    checkpoint_manager: Any  # CheckpointManager
    rewind_system: Any  # RewindSystem
    metrics: Any  # MetricsCollector
    models_config: Optional[Dict[str, Any]] = None
    extra: Dict[str, Any] = field(default_factory=dict)


class Command(ABC):
    """Base class for slash commands.

    Provides command interface with name, help, argument parsing.
    """

    def __init__(self):
        """Initialize command."""
        self.name = self._get_name()
        self.help_text = self._get_help()

    @staticmethod
    def _get_name() -> str:
        """Get command name (without slash).

        Override in subclass or use class name in lowercase.
        """
        raise NotImplementedError

    @staticmethod
    def _get_help() -> str:
        """Get help text for command."""
        raise NotImplementedError

    @abstractmethod
    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute the command.

        Args:
            context: Command execution context
            args: Raw argument string (e.g., "1" for "/rewind 1")

        Returns:
            CommandResult with execution outcome
        """
        pass

    def parse_args(self, args: Optional[str]) -> List[str]:
        """Parse command arguments.

        Args:
            args: Raw argument string

        Returns:
            List of parsed arguments
        """
        if not args:
            return []
        # Simple shell-like parsing
        return args.strip().split()


class CommandRegistry:
    """Registry for managing slash commands.

    Handles command registration, parsing, and execution.
    """

    def __init__(self, custom_commands_dir: Optional[Path] = None):
        """Initialize command registry.

        Args:
            custom_commands_dir: Directory to load custom commands from
        """
        self.commands: Dict[str, Command] = {}
        self.custom_commands_dir = custom_commands_dir
        self._command_patterns: Dict[str, Callable] = {}

    def register(self, command: Command) -> None:
        """Register a command.

        Args:
            command: Command instance to register
        """
        self.commands[command.name] = command
        logger.debug(f"Registered command: /{command.name}")

    def register_from_builtin(self) -> None:
        """Register all built-in commands."""
        from smart.commands.builtin import (
            RewindCommand,
            ResumeCommand,
            CostCommand,
            ContextCommand,
            ModelCommand,
            HelpCommand,
        )

        for cmd_class in [
            RewindCommand,
            ResumeCommand,
            CostCommand,
            ContextCommand,
            ModelCommand,
            HelpCommand,
        ]:
            self.register(cmd_class())

    def load_custom_commands(self) -> None:
        """Load custom commands from .claude/commands/ directory.

        Looks for Python files containing Command subclasses.
        """
        if not self.custom_commands_dir or not self.custom_commands_dir.exists():
            return

        import importlib.util
        import sys

        for cmd_file in self.custom_commands_dir.glob("*.py"):
            if cmd_file.name.startswith("_"):
                continue

            try:
                spec = importlib.util.spec_from_file_location(
                    f"custom_command_{cmd_file.stem}",
                    cmd_file,
                )
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[spec.name] = module
                    spec.loader.exec_module(module)

                    # Find Command subclasses in module
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (
                            isinstance(attr, type)
                            and issubclass(attr, Command)
                            and attr is not Command
                        ):
                            self.register(attr())
                            logger.info(f"Loaded custom command: {attr_name}")

            except Exception as e:
                logger.error(f"Error loading custom command from {cmd_file}: {e}")

    def parse(self, text: str) -> tuple[Optional[str], Optional[str]]:
        """Parse command from text.

        Args:
            text: Input text that might contain a command

        Returns:
            Tuple of (command_name, args) or (None, None) if no command
        """
        # Match /command or /command args
        match = re.match(r"^/(\w+)(?:\s+(.*))?$", text.strip())
        if match:
            return match.group(1), match.group(2)
        return None, None

    def execute(
        self,
        context: CommandContext,
        command_text: str,
    ) -> CommandResult:
        """Parse and execute a command.

        Args:
            context: Command execution context
            command_text: Raw command text (e.g., "/rewind 1")

        Returns:
            CommandResult with execution outcome
        """
        command_name, args = self.parse(command_text)

        if not command_name:
            return CommandResult(
                success=False,
                output=None,
                error=f"Invalid command format: {command_text}",
            )

        if command_name not in self.commands:
            return CommandResult(
                success=False,
                output=None,
                error=f"Unknown command: /{command_name}. Use /help for available commands.",
            )

        try:
            command = self.commands[command_name]
            result = command.execute(context, args)
            logger.info(f"Executed command: /{command_name} {args or ''}")
            return result
        except Exception as e:
            logger.exception(f"Error executing command /{command_name}")
            return CommandResult(
                success=False,
                output=None,
                error=f"Command execution failed: {str(e)}",
            )

    def get_help(self, command_name: Optional[str] = None) -> str:
        """Get help text.

        Args:
            command_name: Specific command to get help for, or None for all

        Returns:
            Help text
        """
        if command_name:
            cmd = self.commands.get(command_name)
            if cmd:
                return f"/{cmd.name}: {cmd.help_text}"
            return f"Command not found: /{command_name}"

        # Return all commands
        help_lines = ["Available commands:\n"]
        for name in sorted(self.commands.keys()):
            cmd = self.commands[name]
            help_lines.append(f"  /{cmd.name}: {cmd.help_text}")
        return "\n".join(help_lines)

    def list_commands(self) -> List[Dict[str, str]]:
        """Get list of available commands.

        Returns:
            List of {name, help} dicts
        """
        return [
            {"name": cmd.name, "help": cmd.help_text}
            for cmd in sorted(
                self.commands.values(),
                key=lambda c: c.name,
            )
        ]


__all__ = [
    "Command",
    "CommandRegistry",
    "CommandContext",
    "CommandResult",
]
