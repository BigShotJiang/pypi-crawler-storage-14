"""Built-in slash commands for smart-agent.

Implements Claude Code-style commands:
- /rewind - Rewind to previous checkpoint
- /resume - Resume from checkpoint
- /cost - Show execution costs
- /context - Manage context
- /model - Switch model
- /help - Get help
"""

from typing import Optional
import logging

from smart.commands.base import Command, CommandContext, CommandResult

logger = logging.getLogger(__name__)


class RewindCommand(Command):
    """Rewind to a previous checkpoint.

    Usage:
      /rewind [steps_back]     - Rewind N steps (default 1)
      /rewind --list           - List available checkpoints
      /rewind --id <id>        - Rewind to specific checkpoint
    """

    @staticmethod
    def _get_name() -> str:
        return "rewind"

    @staticmethod
    def _get_help() -> str:
        return "Rewind to a previous checkpoint (code, session, or full)"

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute rewind command."""
        if not context.rewind_system:
            return CommandResult(
                success=False,
                output=None,
                error="Rewind system not initialized",
            )

        parsed_args = self.parse_args(args)

        # /rewind --list: List available checkpoints
        if parsed_args and parsed_args[0] == "--list":
            try:
                history = context.rewind_system.list_rewind_history(
                    context.session_id,
                    limit=20,
                )
                if not history:
                    return CommandResult(
                        success=True,
                        output="No checkpoints available",
                    )

                output = "Available checkpoints:\n"
                for i, cp in enumerate(history):
                    output += (
                        f"  {i}: {cp['checkpoint_id'][:8]}... "
                        f"({cp['timestamp']}, {cp['steps']} steps)\n"
                    )
                return CommandResult(success=True, output=output)
            except Exception as e:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Failed to list checkpoints: {str(e)}",
                )

        # /rewind --id <id>: Rewind to specific checkpoint
        if parsed_args and len(parsed_args) >= 2 and parsed_args[0] == "--id":
            checkpoint_id = parsed_args[1]
            try:
                rewind_data = context.rewind_system.rewind_to(
                    checkpoint_id,
                    mode="full",
                )
                if not rewind_data:
                    return CommandResult(
                        success=False,
                        output=None,
                        error=f"Checkpoint not found: {checkpoint_id}",
                    )

                output = f"Rewound to checkpoint {checkpoint_id[:8]}...\n"
                output += f"Timestamp: {rewind_data['timestamp']}\n"
                if rewind_data.get("code_changes"):
                    output += f"Code changes: {rewind_data['code_changes']}\n"
                if rewind_data.get("steps"):
                    output += f"Steps: {len(rewind_data['steps'])}\n"

                return CommandResult(
                    success=True,
                    output=output,
                    should_continue=False,  # Stop execution for manual review
                )
            except Exception as e:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Rewind failed: {str(e)}",
                )

        # /rewind [N]: Rewind N steps (default 1)
        steps_back = 1
        if parsed_args and parsed_args[0].isdigit():
            steps_back = int(parsed_args[0])

        try:
            rewind_data = context.rewind_system.rewind_steps(
                context.session_id,
                steps_back=steps_back,
                mode="full",
            )
            if not rewind_data:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Cannot rewind {steps_back} steps (not enough history)",
                )

            output = f"Rewound {steps_back} step(s)\n"
            output += f"Checkpoint: {rewind_data['checkpoint_id'][:8]}...\n"
            output += f"Timestamp: {rewind_data['timestamp']}\n"

            return CommandResult(
                success=True,
                output=output,
                should_continue=False,
            )
        except Exception as e:
            return CommandResult(
                success=False,
                output=None,
                error=f"Rewind failed: {str(e)}",
            )


class ResumeCommand(Command):
    """Resume execution from a saved checkpoint.

    Usage:
      /resume [checkpoint_id]  - Resume from checkpoint
    """

    @staticmethod
    def _get_name() -> str:
        return "resume"

    @staticmethod
    def _get_help() -> str:
        return "Resume execution from a checkpoint"

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute resume command."""
        if not context.rewind_system:
            return CommandResult(
                success=False,
                output=None,
                error="Rewind system not initialized",
            )

        parsed_args = self.parse_args(args)
        if not parsed_args:
            return CommandResult(
                success=False,
                output=None,
                error="/resume requires checkpoint ID. Use /rewind --list to see available checkpoints",
            )

        checkpoint_id = parsed_args[0]

        try:
            rewind_data = context.rewind_system.rewind_to(checkpoint_id, mode="full")
            if not rewind_data:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Checkpoint not found: {checkpoint_id}",
                )

            output = f"Resumed from checkpoint {checkpoint_id[:8]}...\n"
            output += f"Timestamp: {rewind_data['timestamp']}\n"
            output += "Execution continues from this point.\n"

            return CommandResult(
                success=True,
                output=output,
                should_continue=True,
            )
        except Exception as e:
            return CommandResult(
                success=False,
                output=None,
                error=f"Resume failed: {str(e)}",
            )


class CostCommand(Command):
    """Show execution costs and metrics.

    Usage:
      /cost               - Show total costs
      /cost --session     - Show costs for current session
      /cost --breakdown   - Show cost breakdown by tool
    """

    @staticmethod
    def _get_name() -> str:
        return "cost"

    @staticmethod
    def _get_help() -> str:
        return "Show execution costs and metrics"

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute cost command."""
        if not context.metrics:
            return CommandResult(
                success=False,
                output=None,
                error="Metrics not available",
            )

        parsed_args = self.parse_args(args)
        show_breakdown = "--breakdown" in parsed_args

        try:
            # Get current session metrics
            metrics = getattr(context.metrics, "current_session_metrics", {})

            output = "Execution Costs:\n"
            output += f"  Session: {context.session_id}\n"

            # Try to get cost information
            if hasattr(context.metrics, "get_costs"):
                costs = context.metrics.get_costs(context.session_id)
                output += f"  Total Cost: ${costs.get('total', 0):.4f}\n"
                output += f"  Token Count: {costs.get('tokens', 0)}\n"

                if show_breakdown and "breakdown" in costs:
                    output += "\n  Cost Breakdown:\n"
                    for tool, cost in costs["breakdown"].items():
                        output += f"    {tool}: ${cost:.4f}\n"
            else:
                output += "  (Cost data not available yet)\n"

            return CommandResult(success=True, output=output)
        except Exception as e:
            return CommandResult(
                success=False,
                output=None,
                error=f"Failed to get costs: {str(e)}",
            )


class ContextCommand(Command):
    """Manage context window.

    Usage:
      /context              - Show context usage
      /context --reset      - Reset context
      /context --limit N    - Set context limit
    """

    @staticmethod
    def _get_name() -> str:
        return "context"

    @staticmethod
    def _get_help() -> str:
        return "Show and manage context window usage"

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute context command."""
        parsed_args = self.parse_args(args)

        # /context --reset: Reset context
        if parsed_args and parsed_args[0] == "--reset":
            try:
                # This would be implemented by the agent's context manager
                output = "Context reset (implementation specific to agent)\n"
                return CommandResult(success=True, output=output)
            except Exception as e:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Failed to reset context: {str(e)}",
                )

        # /context --limit N: Set limit
        if parsed_args and len(parsed_args) >= 2 and parsed_args[0] == "--limit":
            if not parsed_args[1].isdigit():
                return CommandResult(
                    success=False,
                    output=None,
                    error="Context limit must be a number (tokens)",
                )
            limit = int(parsed_args[1])
            # Store in extra for agent to use
            context.extra["context_limit"] = limit
            return CommandResult(
                success=True,
                output=f"Context limit set to {limit} tokens\n",
            )

        # /context: Show current usage
        try:
            output = "Context Usage:\n"
            if hasattr(context.agent, "get_context_stats"):
                stats = context.agent.get_context_stats()
                output += f"  Used: {stats.get('used', 0)} tokens\n"
                output += f"  Limit: {stats.get('limit', 0)} tokens\n"
                output += f"  Available: {stats.get('available', 0)} tokens\n"
            else:
                output += "  (Context stats not available)\n"
            return CommandResult(success=True, output=output)
        except Exception as e:
            return CommandResult(
                success=False,
                output=None,
                error=f"Failed to get context info: {str(e)}",
            )


class ModelCommand(Command):
    """Switch or configure AI model.

    Usage:
      /model               - Show current model
      /model --list        - List available models
      /model --set NAME    - Switch to model
    """

    @staticmethod
    def _get_name() -> str:
        return "model"

    @staticmethod
    def _get_help() -> str:
        return "Switch or configure the AI model"

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute model command."""
        parsed_args = self.parse_args(args)

        # /model --list: List available models
        if parsed_args and parsed_args[0] == "--list":
            try:
                models = context.models_config or {}
                if not models:
                    return CommandResult(
                        success=True,
                        output="No models configured\n",
                    )

                output = "Available models:\n"
                for model_name in sorted(models.keys()):
                    output += f"  - {model_name}\n"
                return CommandResult(success=True, output=output)
            except Exception as e:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Failed to list models: {str(e)}",
                )

        # /model --set NAME: Switch to model
        if parsed_args and len(parsed_args) >= 2 and parsed_args[0] == "--set":
            model_name = parsed_args[1]
            try:
                if context.models_config and model_name not in context.models_config:
                    return CommandResult(
                        success=False,
                        output=None,
                        error=f"Model not found: {model_name}",
                    )

                context.extra["model"] = model_name
                return CommandResult(
                    success=True,
                    output=f"Switched to model: {model_name}\n",
                )
            except Exception as e:
                return CommandResult(
                    success=False,
                    output=None,
                    error=f"Failed to switch model: {str(e)}",
                )

        # /model: Show current model
        try:
            current_model = "unknown"
            if hasattr(context.agent, "model"):
                current_model = context.agent.model
            elif hasattr(context.agent, "_smolagent"):
                smolagent = context.agent._smolagent
                if hasattr(smolagent, "model"):
                    current_model = smolagent.model

            return CommandResult(
                success=True,
                output=f"Current model: {current_model}\n",
            )
        except Exception as e:
            return CommandResult(
                success=False,
                output=None,
                error=f"Failed to get model info: {str(e)}",
            )


class HelpCommand(Command):
    """Show help for commands.

    Usage:
      /help           - Show all commands
      /help COMMAND   - Show help for specific command
    """

    @staticmethod
    def _get_name() -> str:
        return "help"

    @staticmethod
    def _get_help() -> str:
        return "Show help for slash commands"

    def execute(
        self,
        context: CommandContext,
        args: Optional[str] = None,
    ) -> CommandResult:
        """Execute help command."""
        # Note: This will be executed through CommandRegistry which has access to all commands
        # For now, return a generic help message
        output = (
            "Slash Commands Help:\n"
            "  /rewind [N|--id ID|--list]  - Rewind to previous checkpoint\n"
            "  /resume [checkpoint_id]      - Resume from checkpoint\n"
            "  /cost [--breakdown]          - Show execution costs\n"
            "  /context [--reset|--limit N] - Manage context window\n"
            "  /model [--list|--set NAME]   - Switch AI model\n"
            "  /help [COMMAND]              - Show help\n"
            "\nUse /command -h for more details on a specific command.\n"
        )
        return CommandResult(success=True, output=output)


__all__ = [
    "RewindCommand",
    "ResumeCommand",
    "CostCommand",
    "ContextCommand",
    "ModelCommand",
    "HelpCommand",
]
