"""Smart-Agent Gradio UI wrapper extending smolagents' GradioUI.

Adds session persistence and metrics collection while maintaining
full compatibility with smolagents' native Gradio 6 interface.
"""

from typing import Optional, Any
import gradio as gr
from smolagents import GradioUI

from smart.core.agent import SmartAgent
from smart.core.session import SessionManager
from smart.observability.metrics import MetricsCollector


class SmartAgentGradioUI(GradioUI):
    """Extended GradioUI with session persistence and metrics.

    Wraps smolagents' GradioUI while adding:
    - Automatic session persistence after each interaction
    - Metrics collection and display
    - Session history access
    - Agent memory synchronization

    All smolagents' native features remain unchanged:
    - Streaming chat interface
    - Tool usage visualization
    - File uploads
    - Memory management

    Example:
        >>> from smart import create_smart, SmartAgentGradioUI
        >>> from pathlib import Path
        >>> agent = create_smart(
        ...     "code",
        ...     model=model,
        ...     tools=[...],
        ...     persistence_dir=Path("./sessions")
        ... )
        >>> ui = SmartAgentGradioUI(agent)
        >>> ui.launch(share=True)
    """

    def __init__(
        self,
        smart: SmartAgent,
        file_upload_folder: Optional[str] = None,
        show_metrics: bool = True,
        show_session_info: bool = True,
    ):
        """Initialize SmartAgentGradioUI.

        Args:
            smart: SmartAgent instance (not raw smolagent)
            file_upload_folder: Optional folder for file uploads
            show_metrics: Display metrics summary after each run
            show_session_info: Display session info in footer
        """
        # Store references before calling parent
        self.smart = smart
        self.session_manager = smart._session_manager
        self.metrics_collector = smart._metrics
        self.show_metrics = show_metrics
        self.show_session_info = show_session_info

        # Call parent GradioUI with underlying smolagent
        # GradioUI only accepts MultiStepAgent, not SmartAgent wrapper
        super().__init__(
            agent=smart._smolagent,
            file_upload_folder=file_upload_folder,
        )

    def interact_with_agent(
        self,
        prompt: str,
        files: list,
        history: list,
        reset: bool = False,
    ):
        """Process user interaction with metrics and session tracking.

        Extends parent's interact_with_agent to add:
        - Session synchronization
        - Metrics display
        - Session persistence

        Args:
            prompt: User prompt
            files: Uploaded files
            history: Chat history
            reset: Whether to reset agent memory

        Yields:
            Gradio ChatMessage objects
        """
        # Get or create session
        if self.session_manager:
            if reset or not self.smart._current_session:
                agent_name = getattr(self.smart._smolagent, "name", "agent")
                session = self.session_manager.create_session(agent_name, prompt)
                self.smart._current_session = session
            else:
                session = self.smart._current_session

        # Stream agent responses (from parent class)
        for message in super().interact_with_agent(
            prompt=prompt,
            files=files,
            history=history,
            reset=reset,
        ):
            yield message

        # Post-execution: sync session and collect metrics
        if self.session_manager and self.smart._current_session:
            session = self.smart._current_session

            # Sync session with agent memory
            self.smart._sync_session_from_memory(session)
            session.mark_completed()

            # Save session
            self.session_manager.save_session(session)

            # Display metrics if enabled
            if self.show_metrics and self.metrics_collector:
                metrics = self.metrics_collector.get_summary(session.session_id)
                metrics_msg = self._format_metrics_message(metrics)
                yield gr.ChatMessage(
                    role="assistant",
                    content=metrics_msg,
                    metadata={
                        "title": "📊 Execution Metrics",
                        "status": "complete",
                    },
                )

            # Display session info if enabled
            if self.show_session_info and self.session_manager:
                session_msg = self._format_session_info(session)
                yield gr.ChatMessage(
                    role="assistant",
                    content=session_msg,
                    metadata={
                        "title": "💾 Session Info",
                        "status": "complete",
                    },
                )

    def _format_metrics_message(self, metrics: dict) -> str:
        """Format metrics summary as markdown.

        Args:
            metrics: Metrics dictionary from MetricsCollector

        Returns:
            Markdown formatted message
        """
        if not metrics:
            return "No metrics available"

        return f"""**Execution Metrics**

- **Steps**: {metrics.get('total_steps', 0)}
- **Duration**: {metrics.get('total_duration', 0):.2f}s
- **Tokens**: {metrics.get('total_tokens', 0)}
- **Cost**: ${metrics.get('total_cost', 0):.4f}
- **Success Rate**: {metrics.get('success_rate', 0) * 100:.1f}%
- **Avg Step Time**: {metrics.get('avg_step_duration', 0):.2f}s
"""

    def _format_session_info(self, session: Any) -> str:
        """Format session info as markdown.

        Args:
            session: Session object

        Returns:
            Markdown formatted message
        """
        session_dict = session.to_dict()
        return f"""**Session Information**

- **ID**: `{session_dict['session_id']}`
- **Agent**: {session_dict['agent_name']}
- **Status**: {session_dict['status']}
- **Steps**: {len(session_dict['steps'])}
- **Created**: {session_dict['created_at']}
- **Updated**: {session_dict['updated_at']}
"""

    def get_session_history(self, limit: int = 10) -> list:
        """Get recent session history.

        Args:
            limit: Maximum number of sessions to return

        Returns:
            List of session dictionaries
        """
        if not self.session_manager:
            return []

        sessions = self.session_manager.list_sessions()
        return [s.to_dict() for s in sessions[-limit:]]

    def export_session(self, session_id: str, format: str = "json") -> str:
        """Export a session in specified format.

        Args:
            session_id: Session ID to export
            format: Export format ("json", "markdown", "csv")

        Returns:
            Exported session data as string
        """
        if not self.session_manager:
            raise ValueError("No session manager configured")

        session = self.session_manager.get_session(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")

        if format == "json":
            import json

            return json.dumps(session.to_dict(), indent=2)
        elif format == "markdown":
            from smart.ui.dashboard_tools import format_execution_summary

            metrics = (
                self.metrics_collector.get_summary(session_id)
                if self.metrics_collector
                else None
            )
            return format_execution_summary(session.to_dict(), metrics)
        else:
            raise ValueError(f"Unsupported export format: {format}")


__all__ = ['SmartAgentGradioUI']
