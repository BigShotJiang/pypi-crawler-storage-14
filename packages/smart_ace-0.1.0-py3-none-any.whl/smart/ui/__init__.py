"""UI modules for smart-agent.

Provides dashboard tools and Gradio UI wrapper for visualization.
"""

from smart.ui.dashboard_tools import (
    create_metrics_dashboard,
    create_session_report,
    format_execution_summary,
)
from smart.ui.gradio_wrapper import SmartAgentGradioUI
from smart.ui.knowledge_dashboard import (
    KnowledgeDashboard,
    create_knowledge_dashboard,
)

__all__ = [
    # Dashboard tools
    'create_metrics_dashboard',
    'create_session_report',
    'format_execution_summary',
    # Gradio UI
    'SmartAgentGradioUI',
    # Knowledge dashboard
    'KnowledgeDashboard',
    'create_knowledge_dashboard',
]
