"""Knowledge base dashboard for visualization and management.

Provides web-based UI for viewing knowledge base statistics, searching entries,
and managing the knowledge curation system.
"""

from typing import Optional, List, Dict, Any
from pathlib import Path
import json

try:
    import plotly.express as px
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
except ImportError:
    # Graceful degradation if plotly not available
    px = None
    go = None
    make_subplots = None


class KnowledgeDashboard:
    """Creates visualizations for knowledge base."""

    def __init__(self, knowledge_curator: Optional[Any] = None):
        """Initialize knowledge dashboard.

        Args:
            knowledge_curator: KnowledgeCurator instance
        """
        self.curator = knowledge_curator

    def generate_statistics_html(self, output_path: Optional[Path] = None) -> str:
        """Generate knowledge statistics HTML.

        Args:
            output_path: Optional path to save HTML file

        Returns:
            HTML string with statistics
        """
        if not self.curator:
            return "<p>No knowledge curator available</p>"

        stats = self.curator.get_statistics()

        html = """
        <html>
        <head>
            <title>Knowledge Base Statistics</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .stat-box {
                    display: inline-block;
                    background: #f0f0f0;
                    padding: 15px;
                    margin: 10px;
                    border-radius: 5px;
                    text-align: center;
                }
                .stat-number { font-size: 32px; font-weight: bold; color: #2196F3; }
                .stat-label { font-size: 14px; color: #666; margin-top: 5px; }
                .success-rate { color: #4CAF50; }
            </style>
        </head>
        <body>
            <h1>Knowledge Base Statistics</h1>
        """

        # Total entries
        total = stats.get("total_entries", 0)
        html += f"""
            <div class="stat-box">
                <div class="stat-number">{total}</div>
                <div class="stat-label">Total Entries</div>
            </div>
        """

        # Unique task types
        unique_tasks = stats.get("unique_tasks", 0)
        html += f"""
            <div class="stat-box">
                <div class="stat-number">{unique_tasks}</div>
                <div class="stat-label">Unique Task Types</div>
            </div>
        """

        # Success rate
        success_rate = stats.get("success_rate", 0)
        html += f"""
            <div class="stat-box">
                <div class="stat-number success-rate">{success_rate:.1%}</div>
                <div class="stat-label">Success Rate</div>
            </div>
        """

        # Task type breakdown
        html += """
            <h2>Knowledge by Task Type</h2>
            <table border="1" cellpadding="10">
                <tr>
                    <th>Task Type</th>
                    <th>Count</th>
                    <th>Success Rate</th>
                </tr>
        """

        task_stats = stats.get("task_stats", {})
        for task_type, task_data in task_stats.items():
            count = task_data.get("count", 0)
            success_rate = task_data.get("success_rate", 0)
            html += f"""
                <tr>
                    <td>{task_type}</td>
                    <td>{count}</td>
                    <td>{success_rate:.1%}</td>
                </tr>
            """

        html += """
            </table>
            </body>
            </html>
        """

        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(html)

        return html

    def generate_entry_list_html(
        self, task_type: Optional[str] = None, limit: int = 10, output_path: Optional[Path] = None
    ) -> str:
        """Generate HTML list of knowledge entries.

        Args:
            task_type: Optional filter by task type
            limit: Maximum entries to display
            output_path: Optional path to save HTML file

        Returns:
            HTML string with entry list
        """
        if not self.curator:
            return "<p>No knowledge curator available</p>"

        # Get entries
        if task_type:
            entries = self.curator.knowledge_base.get_by_task_type(task_type, limit=limit)
        else:
            entries = self.curator.knowledge_base.list_all(limit=limit)

        html = """
        <html>
        <head>
            <title>Knowledge Entries</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .entry {
                    background: #f9f9f9;
                    border-left: 4px solid #2196F3;
                    padding: 15px;
                    margin: 10px 0;
                    border-radius: 3px;
                }
                .entry-title { font-weight: bold; color: #2196F3; margin-bottom: 5px; }
                .entry-content { color: #333; margin: 10px 0; font-size: 14px; }
                .entry-meta { color: #999; font-size: 12px; margin-top: 8px; }
                .tags { margin-top: 5px; }
                .tag {
                    display: inline-block;
                    background: #e0e0e0;
                    padding: 2px 8px;
                    margin-right: 5px;
                    border-radius: 12px;
                    font-size: 12px;
                }
            </style>
        </head>
        <body>
            <h1>Knowledge Entries</h1>
        """

        if not entries:
            html += "<p>No entries found.</p>"
        else:
            for entry in entries:
                html += f"""
                <div class="entry">
                    <div class="entry-title">Task: {entry.task_type}</div>
                    <div class="entry-content">{entry.content[:200]}...</div>
                    <div class="entry-meta">
                        <strong>Success Metrics:</strong> {json.dumps(entry.success_metrics)}
                    </div>
                    <div class="tags">
                        {"".join(f'<span class="tag">{tag}</span>' for tag in entry.tags)}
                    </div>
                    <div class="entry-meta">
                        Source: {entry.source} | Created: {entry.created_at}
                    </div>
                </div>
                """

        html += """
            </body>
            </html>
        """

        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(html)

        return html

    def generate_comparison_html(
        self, task_type1: str, task_type2: str, output_path: Optional[Path] = None
    ) -> str:
        """Generate HTML comparing two task types.

        Args:
            task_type1: First task type to compare
            task_type2: Second task type to compare
            output_path: Optional path to save HTML file

        Returns:
            HTML string with comparison
        """
        if not self.curator:
            return "<p>No knowledge curator available</p>"

        entries1 = self.curator.knowledge_base.get_by_task_type(task_type1)
        entries2 = self.curator.knowledge_base.get_by_task_type(task_type2)

        # Calculate averages
        avg_success1 = (
            sum(e.success_metrics.get("success", 0) for e in entries1) / len(entries1)
            if entries1
            else 0
        )
        avg_success2 = (
            sum(e.success_metrics.get("success", 0) for e in entries2) / len(entries2)
            if entries2
            else 0
        )

        html = f"""
        <html>
        <head>
            <title>Knowledge Comparison</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .comparison {{ display: flex; justify-content: space-around; }}
                .column {{ flex: 1; margin: 20px; }}
                .column h2 {{ color: #2196F3; border-bottom: 2px solid #2196F3; padding-bottom: 10px; }}
                .stat {{ margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px; }}
            </style>
        </head>
        <body>
            <h1>Knowledge Comparison: {task_type1} vs {task_type2}</h1>
            <div class="comparison">
                <div class="column">
                    <h2>{task_type1}</h2>
                    <div class="stat"><strong>Total Entries:</strong> {len(entries1)}</div>
                    <div class="stat"><strong>Avg Success Rate:</strong> {avg_success1:.1%}</div>
                </div>
                <div class="column">
                    <h2>{task_type2}</h2>
                    <div class="stat"><strong>Total Entries:</strong> {len(entries2)}</div>
                    <div class="stat"><strong>Avg Success Rate:</strong> {avg_success2:.1%}</div>
                </div>
            </div>
        </body>
        </html>
        """

        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(html)

        return html


def create_knowledge_dashboard(
    knowledge_curator: Optional[Any] = None,
) -> KnowledgeDashboard:
    """Factory function to create knowledge dashboard.

    Args:
        knowledge_curator: Optional KnowledgeCurator instance

    Returns:
        KnowledgeDashboard instance
    """
    return KnowledgeDashboard(knowledge_curator)


__all__ = [
    "KnowledgeDashboard",
    "create_knowledge_dashboard",
]
