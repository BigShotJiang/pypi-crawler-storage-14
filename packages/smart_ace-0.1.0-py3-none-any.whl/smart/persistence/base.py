"""Abstract base class for persistence backends."""

from abc import ABC, abstractmethod
from typing import Optional, List, Any
from datetime import datetime


class Session:
    """Represents an agent session."""

    def __init__(
        self,
        session_id: str,
        agent_name: str,
        task: str,
        status: str = "active",
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
    ):
        self.session_id = session_id
        self.agent_name = agent_name
        self.task = task
        self.status = status
        self.created_at = created_at or datetime.now()
        self.updated_at = updated_at or datetime.now()
        self.steps: List[dict] = []
        self.state: dict = {}
        self.metadata: dict = {}
        self.checkpoint_interval = 5

    def add_step(self, step: dict) -> None:
        """Add a step to the session."""
        self.steps.append(step)
        self.updated_at = datetime.now()

    def mark_completed(self) -> None:
        """Mark session as completed."""
        self.status = "completed"
        self.updated_at = datetime.now()

    def mark_failed(self, error: Exception) -> None:
        """Mark session as failed with error."""
        self.status = "failed"
        self.metadata["error"] = str(error)
        self.updated_at = datetime.now()

    def mark_recovered(self) -> None:
        """Mark session as recovered."""
        self.status = "recovered"
        self.updated_at = datetime.now()

    def to_dict(self) -> dict:
        """Convert session to dictionary."""
        return {
            "session_id": self.session_id,
            "agent_name": self.agent_name,
            "task": self.task,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "steps": self.steps,
            "state": self.state,
            "metadata": self.metadata,
        }


class PersistenceBackend(ABC):
    """Abstract base class for persistence backends."""

    @abstractmethod
    def save_session(self, session: Session) -> None:
        """Save a session to persistent storage."""
        pass

    @abstractmethod
    def load_session(self, session_id: str) -> Optional[Session]:
        """Load a session from persistent storage."""
        pass

    @abstractmethod
    def list_sessions(self, status: Optional[str] = None) -> List[Session]:
        """List all sessions, optionally filtered by status."""
        pass

    @abstractmethod
    async def search_similar(self, query: str, limit: int = 5) -> List[dict]:
        """Search for similar session content (semantic search)."""
        pass

    @abstractmethod
    def delete_session(self, session_id: str) -> None:
        """Delete a session from persistent storage."""
        pass
