"""Hybrid persistence backend combining Markdown + DuckDB."""

from pathlib import Path
from typing import Optional, List
from smart.persistence.base import PersistenceBackend, Session
from smart.persistence.markdown import MarkdownBackend
from smart.persistence.duckdb import DuckDBBackend


class HybridBackend(PersistenceBackend):
    """Combines Markdown (human-readable) + DuckDB (fast queries)."""

    def __init__(
        self,
        base_dir: Path,
        db_path: Path,
        embedding_model: str = "all-MiniLM-L6-v2",
    ):
        """Initialize HybridBackend.

        Args:
            base_dir: Base directory for Markdown files
            db_path: Path to DuckDB database
            embedding_model: Model for embeddings
        """
        self.markdown = MarkdownBackend(base_dir)
        self.duckdb = DuckDBBackend(db_path, embedding_model=embedding_model)

    def save_session(self, session: Session) -> None:
        """Save to both Markdown and DuckDB.

        Args:
            session: Session to save
        """
        self.markdown.save_session(session)
        self.duckdb.save_session(session)

    def load_session(self, session_id: str) -> Optional[Session]:
        """Load from DuckDB (faster).

        Args:
            session_id: Session ID

        Returns:
            Session or None
        """
        return self.duckdb.load_session(session_id)

    def list_sessions(self, status: Optional[str] = None) -> List[Session]:
        """List from DuckDB.

        Args:
            status: Optional status filter

        Returns:
            List of sessions
        """
        return self.duckdb.list_sessions(status)

    def delete_session(self, session_id: str) -> None:
        """Delete from both backends.

        Args:
            session_id: Session ID
        """
        self.markdown.delete_session(session_id)
        self.duckdb.delete_session(session_id)

    async def search_similar(self, query: str, limit: int = 5) -> List[dict]:
        """Search using DuckDB VSS.

        Args:
            query: Search query
            limit: Max results

        Returns:
            List of similar results
        """
        return await self.duckdb.search_similar(query, limit)
