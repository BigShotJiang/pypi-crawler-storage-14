"""DuckDB persistence backend with vector similarity search."""

import json
from pathlib import Path
from typing import Optional, List
from datetime import datetime
import duckdb
from sentence_transformers import SentenceTransformer

from smart.persistence.base import PersistenceBackend, Session


class DuckDBBackend(PersistenceBackend):
    """Fast queries and vector similarity search using DuckDB + VSS."""

    def __init__(
        self,
        db_path: Path,
        embedding_model: str = "all-MiniLM-L6-v2",
        embedding_dim: Optional[int] = None,
    ):
        """Initialize DuckDBBackend.

        Args:
            db_path: Path to DuckDB database file
            embedding_model: SentenceTransformer model name
            embedding_dim: Embedding dimension (auto-detected if None)
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self.conn = duckdb.connect(str(self.db_path))
        self.embedding_model_name = embedding_model
        self.encoder = SentenceTransformer(embedding_model)
        self.embedding_dim = (
            embedding_dim or self.encoder.get_sentence_embedding_dimension()
        )

        self._setup_schema()

    def _setup_schema(self) -> None:
        """Set up database schema with VSS extension."""
        # Install and load VSS extension
        try:
            self.conn.execute("INSTALL vss;")
            self.conn.execute("LOAD vss;")
        except Exception:
            # VSS might already be installed
            pass

        # Create sessions table with summary embedding
        self.conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id VARCHAR PRIMARY KEY,
                agent_name VARCHAR,
                task TEXT,
                status VARCHAR,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                task_embedding FLOAT[{self.embedding_dim}],
                metadata JSON
            )
        """
        )

        # Create steps table with embeddings
        self.conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS steps (
                id INTEGER PRIMARY KEY,
                session_id VARCHAR,
                step_index INTEGER,
                step_type VARCHAR,
                content TEXT,
                embedding FLOAT[{self.embedding_dim}],
                created_at TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            )
        """
        )

        # Create index for vector search on steps
        try:
            self.conn.execute(
                """
                CREATE INDEX IF NOT EXISTS step_embedding_idx
                ON steps USING HNSW (embedding)
            """
            )
        except Exception:
            # Index might already exist
            pass

        # Create index for vector search on sessions
        try:
            self.conn.execute(
                f"""
                CREATE INDEX IF NOT EXISTS session_embedding_idx
                ON sessions USING HNSW (task_embedding)
            """
            )
        except Exception:
            # Index might already exist
            pass

    def save_session(self, session: Session) -> None:
        """Save session to database.

        Args:
            session: Session to save
        """
        # Generate task embedding
        task_embedding = None
        if session.task:
            try:
                task_embedding = self.encoder.encode(session.task).tolist()
            except Exception:
                pass

        # Upsert session record
        self.conn.execute(
            f"""
            INSERT OR REPLACE INTO sessions
            VALUES (?, ?, ?, ?, ?, ?, ?::FLOAT[{self.embedding_dim}], ?)
        """,
            [
                session.session_id,
                session.agent_name,
                session.task,
                session.status,
                session.created_at,
                session.updated_at,
                task_embedding,
                json.dumps(session.metadata),
            ],
        )

        # Clear old steps for this session
        self.conn.execute("DELETE FROM steps WHERE session_id = ?", [session.session_id])

        # Insert steps with embeddings
        for i, step in enumerate(session.steps):
            content = step.get("content", "")
            if content:
                try:
                    embedding = self.encoder.encode(content)
                    self.conn.execute(
                        f"""
                        INSERT INTO steps (session_id, step_index, step_type, content, embedding, created_at)
                        VALUES (?, ?, ?, ?, ?::FLOAT[{self.embedding_dim}], ?)
                    """,
                        [
                            session.session_id,
                            i,
                            step.get("type", "unknown"),
                            content,
                            embedding.tolist(),
                            datetime.now(),
                        ],
                    )
                except Exception:
                    # Skip if embedding fails
                    pass

        self.conn.commit()

    def load_session(self, session_id: str) -> Optional[Session]:
        """Load session from database.

        Args:
            session_id: Session ID

        Returns:
            Session or None if not found
        """
        result = self.conn.execute(
            "SELECT * FROM sessions WHERE session_id = ?", [session_id]
        ).fetchone()

        if not result:
            return None

        session = Session(
            session_id=result[0],
            agent_name=result[1],
            task=result[2],
            status=result[3],
            created_at=result[4],
            updated_at=result[5],
        )

        # result[6] is task_embedding, result[7] is metadata
        if result[7]:
            session.metadata = json.loads(result[7])

        return session

    def list_sessions(self, status: Optional[str] = None) -> List[Session]:
        """List sessions.

        Args:
            status: Optional status filter

        Returns:
            List of sessions
        """
        if status:
            query = "SELECT * FROM sessions WHERE status = ? ORDER BY updated_at DESC"
            results = self.conn.execute(query, [status]).fetchall()
        else:
            query = "SELECT * FROM sessions ORDER BY updated_at DESC"
            results = self.conn.execute(query).fetchall()

        sessions = []
        for result in results:
            session = Session(
                session_id=result[0],
                agent_name=result[1],
                task=result[2],
                status=result[3],
                created_at=result[4],
                updated_at=result[5],
            )
            if result[6]:
                session.metadata = json.loads(result[6])
            sessions.append(session)

        return sessions

    def delete_session(self, session_id: str) -> None:
        """Delete a session.

        Args:
            session_id: Session ID
        """
        self.conn.execute("DELETE FROM steps WHERE session_id = ?", [session_id])
        self.conn.execute("DELETE FROM sessions WHERE session_id = ?", [session_id])
        self.conn.commit()

    async def search_similar(self, query: str, limit: int = 5) -> List[dict]:
        """Search for similar content using vector similarity.

        Args:
            query: Search query
            limit: Max results

        Returns:
            List of similar results
        """
        try:
            query_embedding = self.encoder.encode(query)

            results = self.conn.execute(
                f"""
                SELECT
                    s.session_id,
                    s.agent_name,
                    st.content,
                    st.step_type,
                    array_distance(st.embedding, ?::FLOAT[{self.embedding_dim}]) as distance
                FROM steps st
                JOIN sessions s ON st.session_id = s.session_id
                ORDER BY distance ASC
                LIMIT ?
            """,
                [query_embedding.tolist(), limit],
            ).fetchall()

            return [
                {
                    "session_id": r[0],
                    "agent_name": r[1],
                    "content": r[2],
                    "step_type": r[3],
                    "similarity": float(1 - r[4]),
                }
                for r in results
            ]
        except Exception:
            return []

    def search_similar_sessions(
        self, query: str, limit: int = 5, min_similarity: float = 0.0
    ) -> List[dict]:
        """Search for similar sessions by task using vector similarity.

        Args:
            query: Search query (task description)
            limit: Max results
            min_similarity: Minimum similarity score (0.0-1.0)

        Returns:
            List of similar sessions with metadata
        """
        try:
            query_embedding = self.encoder.encode(query)

            results = self.conn.execute(
                f"""
                SELECT
                    session_id,
                    agent_name,
                    task,
                    status,
                    created_at,
                    array_distance(task_embedding, ?::FLOAT[{self.embedding_dim}]) as distance
                FROM sessions
                WHERE task_embedding IS NOT NULL
                ORDER BY distance ASC
                LIMIT ?
            """,
                [query_embedding.tolist(), limit],
            ).fetchall()

            # Filter by minimum similarity and convert distance to similarity
            return [
                {
                    "session_id": r[0],
                    "agent_name": r[1],
                    "task": r[2],
                    "status": r[3],
                    "created_at": r[4],
                    "similarity": float(1 - r[5]),
                }
                for r in results
                if float(1 - r[5]) >= min_similarity
            ]
        except Exception:
            return []

    def search_sessions_by_agent(self, agent_name: str) -> List[Session]:
        """Search sessions by agent name.

        Args:
            agent_name: Name of agent

        Returns:
            List of sessions for this agent
        """
        results = self.conn.execute(
            "SELECT * FROM sessions WHERE agent_name = ? ORDER BY created_at DESC",
            [agent_name],
        ).fetchall()

        sessions = []
        for result in results:
            session = Session(
                session_id=result[0],
                agent_name=result[1],
                task=result[2],
                status=result[3],
                created_at=result[4],
                updated_at=result[5],
            )
            if result[7]:
                session.metadata = json.loads(result[7])
            sessions.append(session)

        return sessions
