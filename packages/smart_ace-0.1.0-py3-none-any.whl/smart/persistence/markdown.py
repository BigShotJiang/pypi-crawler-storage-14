"""Markdown persistence backend for human-readable session logs."""

import json
from pathlib import Path
from typing import Optional, List
from datetime import datetime
from smart.persistence.base import PersistenceBackend, Session


class MarkdownBackend(PersistenceBackend):
    """Saves sessions as human-readable Markdown + JSON metadata."""

    def __init__(self, base_dir: Path):
        """Initialize MarkdownBackend.

        Args:
            base_dir: Base directory for session storage
        """
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def save_session(self, session: Session) -> None:
        """Save session to Markdown and JSON files.

        Args:
            session: Session to save
        """
        session_dir = self.base_dir / session.session_id
        session_dir.mkdir(exist_ok=True)

        # Save conversation as Markdown
        md_content = self._format_as_markdown(session)
        (session_dir / "conversation.md").write_text(md_content, encoding="utf-8")

        # Save metadata as JSON
        metadata = {
            "session_id": session.session_id,
            "agent_name": session.agent_name,
            "task": session.task,
            "status": session.status,
            "created_at": session.created_at.isoformat(),
            "updated_at": session.updated_at.isoformat(),
            "steps_count": len(session.steps),
            "custom_metadata": session.metadata,
        }
        (session_dir / "metadata.json").write_text(
            json.dumps(metadata, indent=2), encoding="utf-8"
        )

    def load_session(self, session_id: str) -> Optional[Session]:
        """Load session from storage.

        Args:
            session_id: Session ID

        Returns:
            Session or None if not found
        """
        session_dir = self.base_dir / session_id
        metadata_file = session_dir / "metadata.json"

        if not metadata_file.exists():
            return None

        try:
            metadata = json.loads(metadata_file.read_text(encoding="utf-8"))

            session = Session(
                session_id=metadata["session_id"],
                agent_name=metadata["agent_name"],
                task=metadata["task"],
                status=metadata.get("status", "active"),
                created_at=datetime.fromisoformat(metadata["created_at"]),
                updated_at=datetime.fromisoformat(metadata["updated_at"]),
            )
            session.metadata = metadata.get("custom_metadata", {})

            return session
        except Exception:
            return None

    def list_sessions(self, status: Optional[str] = None) -> List[Session]:
        """List all sessions.

        Args:
            status: Optional status filter

        Returns:
            List of sessions
        """
        sessions = []

        for session_dir in self.base_dir.iterdir():
            if not session_dir.is_dir():
                continue

            session = self.load_session(session_dir.name)
            if session:
                if status is None or session.status == status:
                    sessions.append(session)

        return sessions

    def delete_session(self, session_id: str) -> None:
        """Delete a session.

        Args:
            session_id: Session ID
        """
        session_dir = self.base_dir / session_id
        if session_dir.exists():
            # Remove all files in the session directory
            for file in session_dir.iterdir():
                file.unlink()
            session_dir.rmdir()

    async def search_similar(self, query: str, limit: int = 5) -> List[dict]:
        """Search for similar sessions (not implemented in markdown backend).

        Args:
            query: Search query
            limit: Max results

        Returns:
            Empty list (use HybridBackend for search)
        """
        return []

    @staticmethod
    def _format_as_markdown(session: Session) -> str:
        """Format session as Markdown.

        Args:
            session: Session to format

        Returns:
            Markdown string
        """
        lines = [
            f"# Session: {session.session_id}",
            f"",
            f"**Agent**: {session.agent_name}",
            f"**Task**: {session.task}",
            f"**Status**: {session.status}",
            f"**Created**: {session.created_at}",
            f"**Updated**: {session.updated_at}",
            f"",
            f"---",
            f"",
        ]

        if session.steps:
            lines.append("## Conversation")
            lines.append("")

            for i, step in enumerate(session.steps, 1):
                step_type = step.get("type", "Unknown")
                content = step.get("content", "")

                lines.append(f"### Step {i}: {step_type}")
                lines.append("")

                if content:
                    lines.append("```")
                    lines.append(content)
                    lines.append("```")
                    lines.append("")

        return "\n".join(lines)
