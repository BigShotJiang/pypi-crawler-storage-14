"""Weights & Biases (W&B) integration for experiment tracking.

Enables logging of agent runs, metrics, and parameters to Weights & Biases.
"""

from typing import Optional, Dict, Any


class WandBIntegration:
    """Integration with Weights & Biases for experiment tracking."""

    def __init__(self, project: Optional[str] = None, entity: Optional[str] = None):
        """Initialize Weights & Biases integration.

        Args:
            project: W&B project name
            entity: W&B entity (team) name
        """
        self.project = project or "smart-agent"
        self.entity = entity
        self._wandb = None
        self._enabled = False
        self._run = None

        try:
            import wandb

            self._wandb = wandb
            self._wandb.init(project=self.project, entity=self.entity)
            self._enabled = True
        except ImportError:
            pass

    def is_enabled(self) -> bool:
        """Check if integration is enabled."""
        return self._enabled

    def log_run(
        self,
        session_id: str,
        task: str,
        metrics: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log an agent run to W&B.

        Args:
            session_id: Session ID
            task: Task description
            metrics: Execution metrics
            metadata: Additional metadata
        """
        if not self._enabled:
            return

        try:
            # Log metrics
            log_data = {
                'session_id': session_id,
                'task': task,
                **metrics,
            }

            if metadata:
                log_data.update(metadata)

            self._wandb.log(log_data)

        except Exception:
            pass

    def log_metrics(self, metrics: Dict[str, float], step: Optional[int] = None) -> None:
        """Log metrics to W&B.

        Args:
            metrics: Metrics dictionary
            step: Optional step number
        """
        if not self._enabled:
            return

        try:
            if step is not None:
                self._wandb.log(metrics, step=step)
            else:
                self._wandb.log(metrics)
        except Exception:
            pass

    def log_config(self, config: Dict[str, Any]) -> None:
        """Log configuration to W&B.

        Args:
            config: Configuration dictionary
        """
        if not self._enabled:
            return

        try:
            self._wandb.config.update(config)
        except Exception:
            pass

    def log_artifact(self, file_path: str, artifact_type: Optional[str] = None) -> None:
        """Log an artifact to W&B.

        Args:
            file_path: Path to artifact file
            artifact_type: Type of artifact
        """
        if not self._enabled:
            return

        try:
            artifact = self._wandb.Artifact(
                name=f"artifact_{file_path.split('/')[-1]}",
                type=artifact_type or "model",
            )
            artifact.add_file(file_path)
            self._wandb.log_artifact(artifact)
        except Exception:
            pass

    def finish(self) -> None:
        """Finish the W&B run."""
        if self._enabled:
            try:
                self._wandb.finish()
            except Exception:
                pass


__all__ = ['WandBIntegration']
