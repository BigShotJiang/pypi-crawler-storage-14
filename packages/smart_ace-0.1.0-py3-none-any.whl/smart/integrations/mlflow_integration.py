"""MLflow integration for experiment tracking and logging.

Enables logging of agent runs, metrics, and parameters to MLflow.
"""

from typing import Optional, Dict, Any
from datetime import datetime


class MLflowIntegration:
    """Integration with MLflow for experiment tracking."""

    def __init__(self, experiment_name: Optional[str] = None, tracking_uri: Optional[str] = None):
        """Initialize MLflow integration.

        Args:
            experiment_name: Name of the MLflow experiment
            tracking_uri: MLflow tracking URI
        """
        self.experiment_name = experiment_name or "smart-agent"
        self.tracking_uri = tracking_uri
        self._mlflow = None
        self._enabled = False

        if tracking_uri:
            try:
                import mlflow

                self._mlflow = mlflow
                if tracking_uri:
                    self._mlflow.set_tracking_uri(tracking_uri)
                self._mlflow.set_experiment(self.experiment_name)
                self._enabled = True
            except ImportError:
                pass

    def is_enabled(self) -> bool:
        """Check if integration is enabled."""
        return self._enabled

    def start_run(self, session_id: str, params: Optional[Dict[str, Any]] = None) -> None:
        """Start an MLflow run.

        Args:
            session_id: Session ID
            params: Parameters to log
        """
        if not self._enabled:
            return

        try:
            self._mlflow.start_run(run_name=f"session_{session_id}")
            if params:
                self._mlflow.log_params(params)
        except Exception:
            pass

    def log_metrics(self, metrics: Dict[str, float]) -> None:
        """Log metrics to MLflow.

        Args:
            metrics: Metrics dictionary
        """
        if not self._enabled:
            return

        try:
            self._mlflow.log_metrics(metrics)
        except Exception:
            pass

    def log_execution(
        self,
        session_id: str,
        task: str,
        metrics: Dict[str, Any],
        status: str = "success",
    ) -> None:
        """Log a complete agent execution.

        Args:
            session_id: Session ID
            task: Task description
            metrics: Execution metrics
            status: Execution status (success, failed)
        """
        if not self._enabled:
            return

        try:
            with self._mlflow.start_run(run_name=f"execution_{session_id}") as run:
                # Log parameters
                self._mlflow.log_param("session_id", session_id)
                self._mlflow.log_param("task", task[:100])  # Limit to 100 chars
                self._mlflow.log_param("status", status)

                # Log metrics
                for key, value in metrics.items():
                    if isinstance(value, (int, float)):
                        self._mlflow.log_metric(key, value)

                # Log timestamp
                self._mlflow.set_tag("timestamp", datetime.now().isoformat())

        except Exception:
            pass

    def end_run(self) -> None:
        """End the current MLflow run."""
        if self._enabled:
            try:
                self._mlflow.end_run()
            except Exception:
                pass


__all__ = ['MLflowIntegration']
