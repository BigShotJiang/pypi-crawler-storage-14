"""Langfuse integration for smolagent observability.

Enables tracing and visualization of agent execution in Langfuse.
"""

from typing import Optional, Any
from datetime import datetime


class LangfuseIntegration:
    """Integration with Langfuse for trace visualization."""

    def __init__(self, public_key: Optional[str] = None, secret_key: Optional[str] = None):
        """Initialize Langfuse integration.

        Args:
            public_key: Langfuse public key
            secret_key: Langfuse secret key
        """
        self.public_key = public_key
        self.secret_key = secret_key
        self._client = None
        self._enabled = False

        if public_key and secret_key:
            try:
                from langfuse import Langfuse

                self._client = Langfuse(
                    public_key=public_key,
                    secret_key=secret_key,
                )
                self._enabled = True
            except ImportError:
                pass

    def is_enabled(self) -> bool:
        """Check if integration is enabled."""
        return self._enabled

    def trace_agent_run(
        self,
        session_id: str,
        task: str,
        result: Any,
        duration: float,
        metadata: Optional[dict] = None,
    ) -> None:
        """Trace an agent run in Langfuse.

        Args:
            session_id: Session ID
            task: Task description
            result: Agent result
            duration: Execution duration
            metadata: Additional metadata
        """
        if not self._enabled:
            return

        try:
            self._client.trace(
                name=f"agent_run_{session_id}",
                user_id=metadata.get('agent_name') if metadata else None,
                metadata={
                    'session_id': session_id,
                    'task': task,
                    'duration': duration,
                    **(metadata or {}),
                },
                tags=['agent_run'],
            )
        except Exception:
            # Don't fail agent execution due to tracing errors
            pass

    def trace_step(
        self,
        session_id: str,
        step_index: int,
        step_type: str,
        duration: float,
        metadata: Optional[dict] = None,
    ) -> None:
        """Trace a single step in Langfuse.

        Args:
            session_id: Session ID
            step_index: Step index
            step_type: Type of step
            duration: Step duration
            metadata: Additional metadata
        """
        if not self._enabled:
            return

        try:
            self._client.span(
                name=f"step_{step_index}",
                metadata={
                    'session_id': session_id,
                    'step_index': step_index,
                    'step_type': step_type,
                    'duration': duration,
                    **(metadata or {}),
                },
            )
        except Exception:
            pass

    def flush(self) -> None:
        """Flush pending traces to Langfuse."""
        if self._enabled and self._client:
            try:
                self._client.flush()
            except Exception:
                pass


__all__ = ['LangfuseIntegration']
