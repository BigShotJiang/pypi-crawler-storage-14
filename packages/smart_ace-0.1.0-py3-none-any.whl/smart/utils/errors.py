"""Custom exceptions for smart-agent."""


class SmartAgentError(Exception):
    """Base exception for all smart-agent errors."""

    pass


class SessionError(SmartAgentError):
    """Exception raised for session-related errors."""

    pass


class PersistenceError(SmartAgentError):
    """Exception raised for persistence-related errors."""

    pass
