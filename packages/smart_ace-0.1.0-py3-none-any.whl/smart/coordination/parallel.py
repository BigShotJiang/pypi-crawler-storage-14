"""Parallel coordination strategy."""

import asyncio
from typing import Dict, Any, List
from smart.coordination.base import CoordinationStrategy


class ParallelCoordinator(CoordinationStrategy):
    """Executes agents in parallel and aggregates results."""

    def __init__(self, aggregate_fn=None):
        """Initialize ParallelCoordinator.

        Args:
            aggregate_fn: Optional function to aggregate results
        """
        self.aggregate_fn = aggregate_fn or self._default_aggregate

    async def coordinate(
        self, agents: Dict[str, Any], task: str, **kwargs: Any
    ) -> Dict[str, Any]:
        """Execute agents in parallel.

        Args:
            agents: Dictionary of agent name to agent instance
            task: Task to execute
            **kwargs: Additional arguments

        Returns:
            Aggregated results from all agents
        """
        tasks = {}
        for agent_name, agent in agents.items():
            tasks[agent_name] = asyncio.create_task(agent.arun(task))

        results = {}
        for agent_name, task_obj in tasks.items():
            try:
                results[agent_name] = await task_obj
            except Exception as e:
                results[agent_name] = {"error": str(e)}

        return self.aggregate_fn(results)

    @staticmethod
    def _default_aggregate(results: Dict[str, Any]) -> Dict[str, Any]:
        """Default aggregation function.

        Args:
            results: Results from agents

        Returns:
            Aggregated results
        """
        return {
            "individual_results": results,
            "success_count": sum(1 for r in results.values() if "error" not in r),
            "total_agents": len(results),
        }
