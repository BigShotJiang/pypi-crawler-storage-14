"""Sequential coordination strategy."""

from typing import Dict, Any
from smart.coordination.base import CoordinationStrategy


class SequentialCoordinator(CoordinationStrategy):
    """Executes agents sequentially (one after another)."""

    async def coordinate(
        self, agents: Dict[str, Any], task: str, **kwargs: Any
    ) -> Dict[str, Any]:
        """Execute agents sequentially.

        Args:
            agents: Dictionary of agent name to agent instance
            task: Task to execute
            **kwargs: Additional arguments (agent_order for controlling execution order)

        Returns:
            Dictionary with agent names as keys and results as values
        """
        agent_order = kwargs.get("agent_order", list(agents.keys()))
        results = {}

        for agent_name in agent_order:
            if agent_name not in agents:
                continue

            agent = agents[agent_name]
            result = await agent.arun(task)
            results[agent_name] = result

        return results
