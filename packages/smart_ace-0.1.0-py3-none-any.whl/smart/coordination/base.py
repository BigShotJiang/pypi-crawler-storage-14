"""Base class for coordination strategies."""

from abc import ABC, abstractmethod
from typing import Dict, Any


class CoordinationStrategy(ABC):
    """Abstract base class for multi-agent coordination strategies."""

    @abstractmethod
    async def coordinate(
        self, agents: Dict[str, Any], task: str, **kwargs: Any
    ) -> Any:
        """Execute task across multiple agents.

        Args:
            agents: Dictionary of agent name to agent instance
            task: Task to execute
            **kwargs: Additional arguments

        Returns:
            Coordination result
        """
        pass
