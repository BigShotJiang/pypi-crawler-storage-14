"""Pipeline coordination strategy."""

from typing import Dict, Any, List
from smart.coordination.base import CoordinationStrategy


class PipelineCoordinator(CoordinationStrategy):
    """Chains agents where output of one becomes input of next."""

    def __init__(self, agent_order: List[str]):
        """Initialize PipelineCoordinator.

        Args:
            agent_order: List of agent names in execution order
        """
        self.agent_order = agent_order

    async def coordinate(
        self, agents: Dict[str, Any], task: str, **kwargs: Any
    ) -> Dict[str, Any]:
        """Execute agents in pipeline.

        Args:
            agents: Dictionary of agent name to agent instance
            task: Initial task
            **kwargs: Additional arguments

        Returns:
            Dictionary with final result and intermediate results
        """
        results = {}
        current_input = task

        for agent_name in self.agent_order:
            if agent_name not in agents:
                continue

            agent = agents[agent_name]
            result = await agent.arun(current_input)
            results[agent_name] = result

            # Use result as input for next agent
            current_input = str(result)

        return {
            "final_result": current_input,
            "intermediate_results": results,
            "execution_order": self.agent_order,
        }
