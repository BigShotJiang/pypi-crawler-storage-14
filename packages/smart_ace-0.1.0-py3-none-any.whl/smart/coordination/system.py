"""High-level multi-agent system orchestration."""

from typing import Dict, Any, Optional
from smart.core.session import SessionManager
from smart.coordination.base import CoordinationStrategy


class MultiAgentSystem:
    """Orchestrates multiple agents with configurable coordination strategy."""

    def __init__(self, session_manager: Optional[SessionManager] = None):
        """Initialize MultiAgentSystem.

        Args:
            session_manager: Optional session manager for persistence
        """
        self._agents: Dict[str, Any] = {}
        self._coordinator: Optional[CoordinationStrategy] = None
        self._session_manager = session_manager

    def add_agent(self, name: str, agent: Any) -> "MultiAgentSystem":
        """Add an agent to the system.

        Args:
            name: Agent name
            agent: Agent instance

        Returns:
            Self for chaining
        """
        self._agents[name] = agent
        return self

    def remove_agent(self, name: str) -> "MultiAgentSystem":
        """Remove an agent from the system.

        Args:
            name: Agent name

        Returns:
            Self for chaining
        """
        if name in self._agents:
            del self._agents[name]
        return self

    def set_coordinator(
        self, coordinator: CoordinationStrategy
    ) -> "MultiAgentSystem":
        """Set the coordination strategy.

        Args:
            coordinator: Coordination strategy instance

        Returns:
            Self for chaining
        """
        self._coordinator = coordinator
        return self

    def get_agent(self, name: str) -> Optional[Any]:
        """Get an agent by name.

        Args:
            name: Agent name

        Returns:
            Agent or None
        """
        return self._agents.get(name)

    def list_agents(self) -> Dict[str, Any]:
        """List all agents.

        Returns:
            Dictionary of agents
        """
        return self._agents.copy()

    async def run(self, task: str, **kwargs: Any) -> Any:
        """Run the multi-agent system.

        Args:
            task: Task to execute
            **kwargs: Additional arguments for coordinator

        Returns:
            Result from coordinator

        Raises:
            ValueError: If no coordinator is set
        """
        if not self._coordinator:
            raise ValueError("No coordinator set. Use set_coordinator() first.")

        if not self._agents:
            raise ValueError("No agents added. Use add_agent() first.")

        return await self._coordinator.coordinate(self._agents, task, **kwargs)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"MultiAgentSystem(agents={len(self._agents)}, "
            f"coordinator={type(self._coordinator).__name__ if self._coordinator else 'None'})"
        )
