"""ACE (Agent Creation Engine) orchestrator for 4-phase workflows."""

import asyncio
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime

from smart.coordination.base import CoordinationStrategy
from smart.knowledge.curator import KnowledgeCurator


@dataclass
class ACEPhase:
    """Represents a single phase in the ACE workflow."""

    name: str  # "planning", "generation", "review", "curation"
    role: str  # "PLANNER", "GENERATOR", "REVIEWER", "CURATOR"
    inputs: List[str] = field(default_factory=list)  # Variable names from prev phases
    outputs: List[str] = field(default_factory=list)  # Variable names to produce
    description: str = ""


class ACECoordinator(CoordinationStrategy):
    """4-phase ACE coordination strategy.

    Orchestrates a workflow through 4 explicit phases:
    1. PLANNER: Analyzes task and creates execution plan
    2. GENERATOR: Generates solution based on plan
    3. REVIEWER: Reviews solution for quality and improvements
    4. CURATOR: Curates learnings for future tasks
    """

    def __init__(
        self,
        knowledge_curator: Optional[KnowledgeCurator] = None,
        enable_learning: bool = True,
    ):
        """Initialize ACE coordinator.

        Args:
            knowledge_curator: Optional knowledge curator for learning
            enable_learning: Whether to curate knowledge after completion
        """
        self.knowledge_curator = knowledge_curator
        self.enable_learning = enable_learning

        # Define the 4 phases
        self.phases = [
            ACEPhase(
                name="planning",
                role="PLANNER",
                inputs=["task"],
                outputs=["plan", "analysis"],
                description="Analyze task and create execution plan",
            ),
            ACEPhase(
                name="generation",
                role="GENERATOR",
                inputs=["plan"],
                outputs=["solution", "steps"],
                description="Generate solution based on plan",
            ),
            ACEPhase(
                name="review",
                role="REVIEWER",
                inputs=["solution", "plan"],
                outputs=["review", "improvements"],
                description="Review solution and suggest improvements",
            ),
            ACEPhase(
                name="curation",
                role="CURATOR",
                inputs=["plan", "solution", "review"],
                outputs=["knowledge"],
                description="Curate learnings for future tasks",
            ),
        ]

        self.execution_history: List[Dict[str, Any]] = []

    async def coordinate(
        self,
        agents: Dict[str, Any],
        task: str,
        context: Optional[Dict] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Execute 4-phase ACE workflow.

        Args:
            agents: Dictionary mapping agent roles to SmartAgent instances
            task: Task to execute
            context: Optional context for task execution
            **kwargs: Additional arguments

        Returns:
            Dictionary with results from all 4 phases
        """
        # Initialize execution state
        execution_state = {
            "task": task,
            "context": context or {},
            "start_time": datetime.now(),
            "phases": {},
        }

        try:
            # Phase 1: PLANNER
            execution_state["phases"]["planning"] = await self._execute_phase(
                agents, 0, "task", execution_state
            )

            # Phase 2: GENERATOR
            execution_state["phases"]["generation"] = await self._execute_phase(
                agents, 1, "plan", execution_state
            )

            # Phase 3: REVIEWER
            execution_state["phases"]["review"] = await self._execute_phase(
                agents, 2, "solution", execution_state
            )

            # Phase 4: CURATOR (learning)
            if self.enable_learning:
                execution_state["phases"]["curation"] = await self._execute_curation(
                    execution_state
                )

            execution_state["status"] = "completed"
            execution_state["end_time"] = datetime.now()

        except Exception as e:
            execution_state["status"] = "failed"
            execution_state["error"] = str(e)
            execution_state["end_time"] = datetime.now()
            raise

        # Store execution history
        self.execution_history.append(execution_state)

        return self._format_output(execution_state)

    async def _execute_phase(
        self,
        agents: Dict[str, Any],
        phase_index: int,
        input_key: str,
        state: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute a single phase.

        Args:
            agents: Available agents
            phase_index: Index of phase to execute (0-3)
            input_key: Key in state to use as input
            state: Current execution state

        Returns:
            Phase result dictionary
        """
        phase = self.phases[phase_index]
        phase_state = {
            "name": phase.name,
            "role": phase.role,
            "description": phase.description,
            "start_time": datetime.now(),
        }

        try:
            # Get the agent for this role
            agent = agents.get(phase.role)
            if not agent:
                # Try lowercase version
                agent = agents.get(phase.role.lower())

            if not agent:
                raise ValueError(f"No agent found for role: {phase.role}")

            # Prepare input for this phase
            phase_input = self._prepare_phase_input(phase, input_key, state)

            # Execute phase
            result = await self._run_agent_async(agent, phase_input)

            # Store phase outputs
            for output_key in phase.outputs:
                state[output_key] = result

            phase_state["result"] = result
            phase_state["status"] = "completed"

        except Exception as e:
            phase_state["status"] = "failed"
            phase_state["error"] = str(e)
            raise

        finally:
            phase_state["end_time"] = datetime.now()

        return phase_state

    async def _execute_curation(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Execute curation phase (learning).

        Args:
            state: Current execution state

        Returns:
            Curation result dictionary
        """
        curation_state = {
            "name": "curation",
            "role": "CURATOR",
            "description": "Curate learnings for future tasks",
            "start_time": datetime.now(),
        }

        try:
            if self.knowledge_curator:
                # Extract learnings from execution
                learnings = self._extract_learnings(state)

                # Store in knowledge base
                entry = self.knowledge_curator.knowledge_base.add(learnings)
                curation_state["knowledge_entry_id"] = entry
                curation_state["learnings"] = learnings.to_dict()
                curation_state["status"] = "completed"
            else:
                curation_state["status"] = "skipped"
                curation_state["reason"] = "No knowledge curator available"

        except Exception as e:
            curation_state["status"] = "failed"
            curation_state["error"] = str(e)

        finally:
            curation_state["end_time"] = datetime.now()

        return curation_state

    def _prepare_phase_input(
        self, phase: ACEPhase, input_key: str, state: Dict[str, Any]
    ) -> str:
        """Prepare input for a phase.

        Args:
            phase: Phase to prepare input for
            input_key: Key to use from state
            state: Current execution state

        Returns:
            Formatted input string
        """
        input_value = state.get(input_key, "")

        # Build prompt for the phase
        prompt = f"{phase.description}\n\n"

        if input_key == "task":
            prompt += f"Task: {state['task']}\n"
            if state.get("context"):
                prompt += f"Context: {state['context']}\n"

        elif input_key == "plan":
            prompt += f"Plan: {state.get('plan', '')}\n"
            prompt += f"Analysis: {state.get('analysis', '')}\n"

        elif input_key == "solution":
            prompt += f"Solution: {state.get('solution', '')}\n"
            prompt += f"Plan: {state.get('plan', '')}\n"

        return prompt

    async def _run_agent_async(self, agent: Any, prompt: str) -> str:
        """Run agent asynchronously.

        Args:
            agent: Agent to run
            prompt: Prompt/task for agent

        Returns:
            Agent result
        """
        # Check if agent has async run method
        if hasattr(agent, "arun"):
            return await agent.arun(prompt)
        elif hasattr(agent, "run"):
            # Run sync method in thread pool
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, agent.run, prompt)
        else:
            raise ValueError(f"Agent {agent} has no run or arun method")

    def _extract_learnings(self, state: Dict[str, Any]) -> "KnowledgeEntry":
        """Extract learnings from execution state.

        Args:
            state: Execution state

        Returns:
            KnowledgeEntry with learnings
        """
        from smart.knowledge import KnowledgeEntry

        # Build learning content
        content_parts = []

        if state.get("solution"):
            content_parts.append(f"Solution: {state['solution'][:200]}")

        if state.get("review"):
            content_parts.append(f"Review feedback: {state['review'][:200]}")

        if state.get("improvements"):
            content_parts.append(f"Improvements: {state['improvements'][:200]}")

        content = "\n".join(content_parts)

        # Create learning entry
        entry = KnowledgeEntry(
            content=content,
            task_type=self._extract_task_type(state.get("task", "")),
            success_metrics={"success": 1.0},
            source=f"ace:{state.get('start_time')}",
            tags=["ace", "workflow"],
            metadata={
                "phases_completed": list(state.get("phases", {}).keys()),
                "execution_duration": str(
                    state.get("end_time", state.get("start_time"))
                    - state.get("start_time")
                ),
            },
        )

        return entry

    @staticmethod
    def _extract_task_type(task: str) -> str:
        """Extract task type from task string."""
        words = task.lower().split()
        if len(words) > 0:
            return words[0]
        return "ace_task"

    def _format_output(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Format final output from execution.

        Args:
            state: Execution state

        Returns:
            Formatted output dictionary
        """
        return {
            "task": state["task"],
            "status": state["status"],
            "plan": state.get("plan", ""),
            "solution": state.get("solution", ""),
            "review": state.get("review", ""),
            "improvements": state.get("improvements", ""),
            "knowledge_id": state.get("phases", {})
            .get("curation", {})
            .get("knowledge_entry_id"),
            "phases": state.get("phases", {}),
            "duration": str(state.get("end_time", state["start_time"]) - state["start_time"])
            if state.get("end_time")
            else "Unknown",
        }

    def get_execution_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent execution history.

        Args:
            limit: Maximum number of executions to return

        Returns:
            List of execution histories
        """
        return self.execution_history[-limit:]

    def get_statistics(self) -> Dict[str, Any]:
        """Get coordinator statistics.

        Returns:
            Dictionary with statistics
        """
        if not self.execution_history:
            return {
                "total_executions": 0,
                "success_rate": 0.0,
                "avg_duration": 0.0,
            }

        successful = sum(
            1 for e in self.execution_history if e.get("status") == "completed"
        )
        total_duration = sum(
            (e.get("end_time") - e.get("start_time")).total_seconds()
            for e in self.execution_history
            if e.get("end_time") and e.get("start_time")
        )

        return {
            "total_executions": len(self.execution_history),
            "successful_executions": successful,
            "success_rate": successful / len(self.execution_history)
            if self.execution_history
            else 0.0,
            "avg_duration_seconds": total_duration / len(self.execution_history)
            if self.execution_history
            else 0.0,
        }


def create_ace_system(
    model: Any, session_manager: Any, knowledge_curator: Optional[KnowledgeCurator] = None
) -> "MultiAgentSystem":
    """Factory to create pre-configured ACE system.

    Args:
        model: Language model to use
        session_manager: Session manager for persistence
        knowledge_curator: Optional knowledge curator for learning

    Returns:
        MultiAgentSystem configured for ACE workflow
    """
    from smart import MultiAgentSystem, create_smart

    # Create agents for each role
    planner = create_smart(
        "code",
        model=model,
        tools=[],
        session_manager=session_manager,
    )

    generator = create_smart(
        "code",
        model=model,
        tools=[],
        session_manager=session_manager,
    )

    reviewer = create_smart(
        "code",
        model=model,
        tools=[],
        session_manager=session_manager,
    )

    curator = create_smart(
        "code",
        model=model,
        tools=[],
        session_manager=session_manager,
    )

    # Create multi-agent system
    system = MultiAgentSystem(session_manager)
    system.add_agent("PLANNER", planner)
    system.add_agent("GENERATOR", generator)
    system.add_agent("REVIEWER", reviewer)
    system.add_agent("CURATOR", curator)

    # Set ACE coordinator
    ace_coordinator = ACECoordinator(
        knowledge_curator=knowledge_curator, enable_learning=True
    )
    system.set_coordinator(ace_coordinator)

    return system
