__version__ = "v2.1.3"
default_app_config = "azbankgateways.apps.AZIranianBankGatewaysConfig"
