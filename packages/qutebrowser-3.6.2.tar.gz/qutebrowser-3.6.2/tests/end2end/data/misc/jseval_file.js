console.log("Hello from JS!")
console.log("Hello again from JS!")
