document.addEventListener('DOMContentLoaded', (event) => {
    const elem = document.getElementById('text');
    elem.textContent = 'Script loaded';
    console.log('Script loaded');
})
