"""MCP integration tests."""
