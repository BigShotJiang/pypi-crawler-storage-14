from .microsoft365defender import microsoft_365_defender_pipeline

pipelines = {
    "microsoft_365_defender_pipeline": microsoft_365_defender_pipeline,  # DEPRECATED: Use microsoft_xdr_pipeline instead.
}
