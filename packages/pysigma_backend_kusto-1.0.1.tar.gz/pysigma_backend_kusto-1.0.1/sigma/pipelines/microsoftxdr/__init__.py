from .microsoftxdr import microsoft_xdr_pipeline

pipelines = {
    "microsoft_xdr_pipeline": microsoft_xdr_pipeline,
}
