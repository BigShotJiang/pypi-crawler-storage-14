from .azuremonitor import azure_monitor_pipeline

pipelines = {
    "azure_monitor": azure_monitor_pipeline,
}
