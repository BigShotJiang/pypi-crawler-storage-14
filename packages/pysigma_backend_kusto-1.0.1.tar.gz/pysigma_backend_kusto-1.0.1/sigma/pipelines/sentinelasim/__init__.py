from .sentinelasim import sentinel_asim_pipeline

pipelines = {
    "sentinel_asim": sentinel_asim_pipeline,  # TODO: adapt identifier to something approproiate
}
