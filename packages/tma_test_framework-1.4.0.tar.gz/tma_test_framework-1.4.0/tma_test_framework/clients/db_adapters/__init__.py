"""
Database adapters for different database backends.
"""
