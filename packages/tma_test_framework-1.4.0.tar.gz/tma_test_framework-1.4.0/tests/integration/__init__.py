"""
Integration tests for TMA Framework.
Tests verify interaction between multiple components and real services.
"""
