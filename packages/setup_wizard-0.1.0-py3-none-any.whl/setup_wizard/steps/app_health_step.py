from __future__ import annotations

from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step
from .venv_step import run_in_venv


def run_health_checks(cfg: Dict[str, Any], auto_yes: bool) -> None:
    section("Health checks")

    log(
        "I can run a basic health check by importing your application module "
        f"({cfg['paths']['app_import']}). This can catch obvious setup problems."
    )
    if not ask_yes_no(
        "Run health checks now?",
        default=True,
        auto_yes=auto_yes,
    ):
        record_step("health_check", "skipped", "User skipped")
        return

    try:
        run_in_venv(
            cfg,
            [
                "-c",
                f"import importlib; importlib.import_module('{cfg['paths']['app_import']}')",
            ],
        )
        record_step("health_check", "done", f"Imported {cfg['paths']['app_import']}")
        log("Import check succeeded.")
    except Exception as e:
        warn(f"Health check failed: {e}")
        record_step("health_check", "failed", str(e))
