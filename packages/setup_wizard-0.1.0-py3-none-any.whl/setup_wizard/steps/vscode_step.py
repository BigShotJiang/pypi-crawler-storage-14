from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step


def setup_vscode(cfg: Dict[str, Any], auto_yes: bool) -> None:
    vscode_cfg = cfg.get("vscode") or {}
    if not vscode_cfg.get("enable_launch", False):
        return

    section("VSCode integration")

    vscode_dir = Path(".vscode")
    vscode_dir.mkdir(exist_ok=True)

    entry_module = vscode_cfg.get("entry_module", "src")
    launch_path = vscode_dir / "launch.json"

    log(
        "I can create a basic VSCode launch configuration to run the app in debug "
        "mode using the project virtualenv."
    )
    if ask_yes_no(
        f"Create or update {launch_path}?",
        default=True,
        auto_yes=auto_yes,
    ):
        launch = {
            "version": "0.2.0",
            "configurations": [
                {
                    "name": "Python: Run app",
                    "type": "python",
                    "request": "launch",
                    "module": entry_module,
                    "justMyCode": True,
                    "envFile": cfg["paths"]["env_file"],
                }
            ],
        }
        try:
            launch_path.write_text(json.dumps(launch, indent=2), encoding="utf-8")
            log(f"Wrote VSCode launch configuration to {launch_path}")
            vs_launch_status = "done"
        except Exception as e:
            warn(f"Failed to write VSCode launch configuration: {e}")
            vs_launch_status = "failed"
    else:
        vs_launch_status = "skipped"
        log("Skipping VSCode launch configuration.")

    # Formatter setting
    formatter_status = "skipped"
    if vscode_cfg.get("use_black_formatter", False):
        log(
            "I can also configure VSCode to use Black as the code formatter for this "
            "workspace and enable format-on-save."
        )
        if ask_yes_no(
            "Set Black as the default formatter for this project?",
            default=True,
            auto_yes=auto_yes,
        ):
            settings_path = vscode_dir / "settings.json"
            settings: Dict[str, Any] = {}
            if settings_path.exists():
                try:
                    settings = json.loads(settings_path.read_text(encoding="utf-8"))
                except Exception:
                    warn(
                        "Existing .vscode/settings.json is not valid JSON; overwriting."
                    )

            settings.update(
                {
                    "python.formatting.provider": "black",
                    "editor.formatOnSave": True,
                }
            )
            try:
                settings_path.write_text(
                    json.dumps(settings, indent=2), encoding="utf-8"
                )
                log(f"Updated VSCode settings at {settings_path}")
                formatter_status = "done"
            except Exception as e:
                warn(f"Failed to write VSCode settings: {e}")
                formatter_status = "failed"
        else:
            formatter_status = "skipped"
            log("Skipping VSCode formatter configuration.")

    # Record combined status
    detail = f"launch={vs_launch_status}, formatter={formatter_status}"
    if "failed" in detail:
        record_step("vscode", "failed", detail)
    elif "done" in detail:
        record_step("vscode", "done", detail)
    else:
        record_step("vscode", "skipped", detail)
