### INTENTION and CONTEXT
Implement the scenario "{scenario_name}" of the feaure "{feature_file_name}". Ignore the other scenarios

{Further implementation specific context like files, methods, ...}


