# Epic Exploration: <descriptive title of exploration challenge>

- [Epic Exploration: ](#epic-exploration-)
- [initial exploration ...](#initial-exploration-)

# initial exploration ...
...