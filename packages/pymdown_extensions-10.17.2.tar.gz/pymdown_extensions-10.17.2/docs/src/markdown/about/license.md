---
icon: lucide/copyright
---
--8<-- "LICENSE.md"
