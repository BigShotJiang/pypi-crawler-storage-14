from pymodaq_utils import utils as daq_utils

from pymodaq_utils.warnings import deprecation_msg

deprecation_msg('Importing daq_utils stuff from pymodaq is deprecated in pymodaq>5.0.0,'
                'please use the pymodaq_utils.utils module')
