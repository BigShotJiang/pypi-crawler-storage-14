from pymodaq_utils.math_utils import *

from pymodaq_utils.warnings import deprecation_msg

deprecation_msg('Importing math_utils stuff from pymodaq is deprecated in pymodaq>5.0.0,'
                'please use the pymodaq_utils.math_utils module')
