# Pyarmor 9.2.1 (trial), 000000, 2025-12-01T12:40:15.404195
from .pyarmor_runtime import __pyarmor__
