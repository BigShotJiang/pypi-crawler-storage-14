"""Behaviour analysis functions for the IBL task."""
