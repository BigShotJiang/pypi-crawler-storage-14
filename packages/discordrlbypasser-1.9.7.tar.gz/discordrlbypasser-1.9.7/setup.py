import os
from setuptools import setup, find_packages

setup(
    name='DiscordRLBypasser',
    version='1.9.7',
    packages=find_packages(),
    install_requires=[
        'discord.py',
        'disnake',
    ],
    author='Welland',
    author_email='welland@gmail.com',
    description='A library to bypass Discord rate limits by syncing with various Discord libraries.',
    long_description=open('README.md').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://github.com/ghsgroupbots-collab/discordrlbypasser',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
