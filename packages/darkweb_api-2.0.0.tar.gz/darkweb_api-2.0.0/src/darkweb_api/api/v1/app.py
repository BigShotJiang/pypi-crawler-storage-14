import requests
from fastapi import FastAPI

from ...exceptions.routes_errors import (
    api_error,
    error_request_input,
    error_upstream_connection,
    value_error,
)
from ...models.breachinput import BreachSearchInput
from ...models.breachrecords import RecordOutPut

breachapp = FastAPI(
    title="Fense - Breach API",
    summary="Find the Dark Web Presence of Data",
    version="0.1.0",
    # swagger_ui_parameters={"defaultModelsExpandDepth": 0},
)


@breachapp.get("v1/health/")
async def health() -> str:
    return "Breach API is healthy"


@breachapp.get("v1/search/", response_model=RecordOutPut)
async def search_breach(breach_filter: BreachSearchInput) -> RecordOutPut:
    """
    Get the Breach Results based on the Search Criteria
    """
    _, err = breach_filter.validateQuery()
    if err:
        error_request_input(error_details=f"Invalid Query. Reason: {err}")

    try:
        webzurl, err = breach_filter.prepareRequestURL()
    except ValueError as e:
        value_error(detail=str(e))

    try:
        resp = requests.get(webzurl, timeout=10)
    except requests.RequestException as e:
        error_upstream_connection(
            detail=f"Error in Connection Upstream API. Reason: {e}"
        )

    if resp.status_code != 200:
        api_error(
            error_details=f"Error in Upstream API. Reason: {resp.text}",
            error_code=resp.status_code,
        )

    data = resp.json()

    ## fill the output RecordOutput Object
    records = RecordOutPut()
    records.records = data.get("records")
    records.requestLeft = data.get("requestsLeft")
    records.next = data.get("next")
    records.toatlResults = data.get("totalResults")
    records.moreResultsAvailable = data.get("moreResultsAvailable")
    records.totalResultsVerified = data.get("totalResultsVerified")

    return records
