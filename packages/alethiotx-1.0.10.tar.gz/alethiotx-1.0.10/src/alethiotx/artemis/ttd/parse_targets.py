import pandas as pd
import re
from UniProtMapper import ProtMapper
import urllib.request

def parse_targets(url: str = "https://ttd.idrblab.cn/files/download/", file: str = "P2-01-TTD_uniprot_all.txt") -> pd.DataFrame:
    """
    Parse therapeutic target data from TTD database and map to gene names.
    This function downloads and parses a text file from the Therapeutic Target Database (TTD)
    containing target information, extracts relevant fields, and maps UniProt IDs to gene names
    using the UniProt mapping service.
    :param url: Base URL path where the file is hosted, defaults to "https://ttd.idrblab.cn/files/download/"
    :type url: str, optional
    :param file: Name of the file to download, defaults to "P2-01-TTD_uniprot_all.txt"
    :type file: str, optional
    :returns: DataFrame containing parsed target information with columns:
        - Target ID: TTD target identifier
        - Uniprot ID: UniProt accession number (split if multiple IDs present)
        - Target Name: Name of the therapeutic target
        - Target Type: Classification of the target
        - Gene Name: Mapped gene name from UniProt (if available)
    :rtype: pd.DataFrame
    :raises urllib.error.URLError: If the file cannot be downloaded from the specified URL
    :raises Exception: If there are errors during UniProt ID mapping
    .. note::
        - The function automatically splits multiple UniProt IDs separated by '-', ';', or '/'
          into separate entries
        - Gene name mapping is performed in batches of 1000 IDs to avoid API limits
        - IDs marked as 'NOUNIPROTAC' or empty are excluded from mapping
        - The file format is expected to have a header section ending with dashes, followed
          by target entries with fields like TARGETID, UNIPROID, TARGNAME, and TARGTYPE
    **Example**
    >>> df = parse_targets()
    >>> print(df.head())
    >>> # Download from custom location
    >>> df = parse_targets(url="https://example.com/", file="targets.txt")
    """
    # Download the file from URL
    full_url = url + file
    print(f"Downloading file from {full_url}...")
    response = urllib.request.urlopen(full_url)
    lines = [line.decode('utf-8') for line in response.readlines()]
    print(f"Downloaded {len(lines)} lines")
    
    targets = []
    current_target = {}
    in_header = True
    
    for idx, line in enumerate(lines):
        line = line.strip()
        
        # Skip header section (ends at the dashed line after abbreviation index)
        if in_header:
            # Check if we're past the abbreviation section
            if line.startswith('---') and idx > 0:
                # Look back a few lines to see if 'TARGETID' appears (indicating abbreviation section)
                lookback = ''.join(lines[max(0, idx-5):idx])
                if 'TARGETID' in lookback or 'TARGTYPE' in lookback:
                    in_header = False
            continue
        
        # Skip empty lines
        if not line:
            # Save current target if we have data
            if current_target:
                # Split multiple Uniprot IDs if present
                if 'Uniprot ID' in current_target:
                    uniprot_ids = re.split(r'[-;/]', current_target['Uniprot ID'])
                    uniprot_ids = [uid.strip() for uid in uniprot_ids if uid.strip()]
                    
                    # Create a separate entry for each Uniprot ID
                    for uid in uniprot_ids:
                        target_entry = current_target.copy()
                        target_entry['Uniprot ID'] = uid
                        targets.append(target_entry)
                else:
                    targets.append(current_target.copy())
                current_target = {}
            continue
        
        # Parse fields
        if line.startswith('TARGETID\t'):
            # Save previous target if exists
            if current_target:
                # Split multiple Uniprot IDs if present
                if 'Uniprot ID' in current_target:
                    uniprot_ids = re.split(r'[-;/]', current_target['Uniprot ID'])
                    uniprot_ids = [uid.strip() for uid in uniprot_ids if uid.strip()]
                    
                    # Create a separate entry for each Uniprot ID
                    for uid in uniprot_ids:
                        target_entry = current_target.copy()
                        target_entry['Uniprot ID'] = uid
                        targets.append(target_entry)
                else:
                    targets.append(current_target.copy())
                current_target = {}
            current_target['Target ID'] = line.split('\t')[1]
        elif line.startswith('UNIPROID\t'):
            current_target['Uniprot ID'] = line.split('\t')[1]
        elif line.startswith('TARGNAME\t'):
            current_target['Target Name'] = line.split('\t')[1]
        elif line.startswith('TARGTYPE\t'):
            current_target['Target Type'] = line.split('\t')[1]
    
    # Don't forget the last target
    if current_target:
        if 'Uniprot ID' in current_target:
            uniprot_ids = re.split(r'[-;/]', current_target['Uniprot ID'])
            uniprot_ids = [uid.strip() for uid in uniprot_ids if uid.strip()]
            
            for uid in uniprot_ids:
                target_entry = current_target.copy()
                target_entry['Uniprot ID'] = uid
                targets.append(target_entry)
        else:
            targets.append(current_target)
    
    # Create DataFrame
    df = pd.DataFrame(targets)
    
    # Convert Uniprot IDs to Gene Names using UniProtMapper
    if len(df) > 0 and 'Uniprot ID' in df.columns:
        print("\nMapping Uniprot IDs to Gene Names...")
        
        # Get unique Uniprot IDs (excluding 'NOUNIPROTAC' and 'Uniprot ID' placeholders)
        unique_ids = df['Uniprot ID'].unique().tolist()
        valid_ids = [uid for uid in unique_ids if uid not in ['NOUNIPROTAC', 'Uniprot ID', '', None] and pd.notna(uid)]
        
        # Initialize mapper
        mapper = ProtMapper()
        
        # Map in batches to avoid API limits
        batch_size = 1000
        gene_name_map = {}
        
        for i in range(0, len(valid_ids), batch_size):
            batch = valid_ids[i:i+batch_size]
            print(f"  Mapping batch {i//batch_size + 1} ({len(batch)} IDs)...")
            
            try:
                result, failed = mapper.get(
                    ids=batch,
                    from_db="UniProtKB_AC-ID",
                    to_db="Gene_Name"
                )
                
                # Process results - result is a DataFrame
                if result is not None and len(result) > 0:
                    # Convert DataFrame to dictionary if needed
                    if hasattr(result, 'iterrows'):
                        # It's a DataFrame - iterate through rows
                        for idx, row in result.iterrows():
                            # The 'From' column contains the Uniprot ID
                            # The 'To' column contains the Gene Name
                            if 'From' in result.columns and 'To' in result.columns:
                                uniprot_id = row['From']
                                gene_name = row['To']
                                if pd.notna(gene_name) and gene_name:
                                    gene_name_map[uniprot_id] = str(gene_name)
                    elif isinstance(result, dict):
                        # It's a dictionary
                        for uniprot_id, gene_names in result.items():
                            if gene_names is not None:
                                if isinstance(gene_names, list) and len(gene_names) > 0:
                                    gene_name_map[uniprot_id] = gene_names[0]
                                elif isinstance(gene_names, str) and gene_names:
                                    gene_name_map[uniprot_id] = gene_names
                                elif hasattr(gene_names, '__iter__') and not isinstance(gene_names, str):
                                    gene_list = list(gene_names)
                                    if len(gene_list) > 0:
                                        gene_name_map[uniprot_id] = str(gene_list[0])
                
                if failed and len(failed) > 0:
                    print(f"    Warning: {len(failed)} IDs failed to map in this batch")
                    
            except Exception as e:
                print(f"    Error mapping batch: {e}")
                import traceback
                traceback.print_exc()
        
        # Add Gene Name column
        df['Gene Name'] = df['Uniprot ID'].apply(lambda x: gene_name_map.get(x, None) if pd.notna(x) else None)
        
        # For unmapped IDs, set to None or keep empty
        print(f"\nSuccessfully mapped {df['Gene Name'].notna().sum()} out of {len(df)} entries")

    df.rename(columns={
        'Target ID': 'TTD ID',
        'Gene Name': 'Target Gene'
    }, inplace=True)

    return df


if __name__ == '__main__':
    # Parse the file from URL
    df = parse_targets()
    
    # Display results
    print(f"\n{'='*60}")
    print(f"Parsed {len(df)} targets from TTD")
    print(f"\nDataFrame shape: {df.shape}")
    print(f"\nFirst 10 entries:")
    print(df.head(10))
    print(f"\nColumn names: {df.columns.tolist()}")
    print(f"\nData types:\n{df.dtypes}")
    print(f"\nTarget Gene mapping statistics:")
    print(f"  Mapped: {df['Target Gene'].notna().sum()}")
    print(f"  Unmapped: {df['Target Gene'].isna().sum()}")
    
    # Save to CSV
    output_file = 'ttd_targets_parsed.csv'
    df.to_csv(output_file, index=False)
    print(f"\nSaved to {output_file}")
