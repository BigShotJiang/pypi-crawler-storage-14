from pandas import DataFrame, read_excel

def parse_mappings(path: str = "https://ttd.idrblab.cn/files/download/", file: str = "P1-07-Drug-TargetMapping.xlsx") -> DataFrame:
    """
    Retrieve drug-target mapping data from the Therapeutic Target Database (TTD).

    This function downloads and processes the drug-target mapping Excel file from TTD,
    renaming columns to a standardized format for easier downstream analysis.

    :param path: Base URL path to download the TTD drug-target mapping Excel file.
                Defaults to the official TTD download link for Drug-Target Mapping (P1-07).
    :type path: str

    :param file: Filename of the TTD drug-target mapping Excel file. Defaults to ``P1-07-Drug-TargetMapping.xlsx``.
    :type file: str

    :return: A DataFrame containing the drug-target mappings with renamed columns:
             - 'Target ID' (formerly 'TargetID'): Unique identifier for the target
             - 'TTD ID' (formerly 'DrugID'): Unique identifier for the drug in TTD
             - 'Status' (formerly 'Highest_status'): Development status of the drug
             - 'Action Type' (formerly 'MOA'): Mechanism of action describing drug-target interaction
    :rtype: DataFrame

    :raises: May raise exceptions related to network connectivity or Excel file parsing
             if the URL is inaccessible or the file format is invalid.

    .. note::
       This function requires an active internet connection to download the data file.
       The default URL points to the official TTD database download resource.

    .. seealso::
       TTD Database: https://db.idrblab.net/ttd/
    """
    full_url = path + file
    print(f"Downloading file from {full_url}...")
    df = read_excel(full_url)
    print(f"Downloaded {len(df)} rows")

    df.rename(columns={
        'TargetID': 'Target ID',
        'DrugID': 'TTD ID',
        'Highest_status': 'Status',
        'MOA': 'Action Type'
    }, inplace=True)
    return df

if __name__ == '__main__':
    # Parse the file from URL
    df = parse_mappings()
    
    # Display results
    print(f"\n{'='*60}")
    print(f"Parsed {len(df)} mappings from TTD")
    print(f"\nDataFrame shape: {df.shape}")
    print(f"\nFirst 10 entries:")
    print(df.head(10))
    print(f"\nColumn names: {df.columns.tolist()}")
    print(f"\nData types:\n{df.dtypes}")
    
    # Save to CSV
    output_file = 'ttd_mappings_parsed.csv'
    df.to_csv(output_file, index=False)
    print(f"\nSaved to {output_file}")
