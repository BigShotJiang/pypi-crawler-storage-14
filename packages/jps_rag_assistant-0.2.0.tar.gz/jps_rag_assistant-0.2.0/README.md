# jps-rag-assistant

![Build & Test](https://github.com/jai-python3/jps-rag-assistant/actions/workflows/test.yml/badge.svg)
![Publish to PyPI](https://github.com/jai-python3/jps-rag-assistant/actions/workflows/publish-to-pypi.yml/badge.svg)
[![codecov](https://codecov.io/gh/jai-python3/jps-rag-assistant/branch/main/graph/badge.svg)](https://codecov.io/gh/jai-python3/jps-rag-assistant)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

**Your private, fully local RAG assistant** — securely ingest and query your personal knowledge from:

- Microsoft Outlook (emails + calendar)
- Jira (your assigned & updated issues)
- Confluence (your spaces and personal pages)

All data stays **100% on your machine**. Powered by **LlamaIndex + Ollama**, with incremental updates and zero cloud dependency.

---

### Features

- Fully **configuration-driven** via a single YAML file
- **Incremental ingestion** — only new or updated documents are re-processed
- **Concurrent loading** from Outlook, Jira, and Confluence
- Secure credentials via system **keyring** (no plaintext tokens)
- Modular, clean, type-annotated, and fully tested codebase
- Zero hard-coded values — everything (models, chunk size, timeouts, etc.) is configurable
- Supports macOS, Windows, and Linux

---

### Install Llama and Ollama


```bash
pip install llama-index llama-index-embeddings-nomic llama-index-llms-ollama \
llama-index-vector-stores-chroma chromadb chainlit \
atlassian-python-api msal jira keyring
```

Retrieve llama3.1:8b for testing

```bash
# for testing
ollama pull llama3.1:8b    

# or mixtral, or llama3.1:405b if you have the VRAM
ollama pull llama3.1:70b   

# one of the best open-source embedding models available, especially for local/private use
ollama pull nomic-embed-text
```

### Example Usage



```bash
# First time only — store your credentials securely
keyring set jira dude@msn.com          # Paste your Jira Personal Access Token
keyring set confluence dude@msn.com    # Paste your Confluence OAuth2 bearer token

# First time: Set up Outlook Graph API auth (one-time)
keyring set outlook-graph dude@msn.com_client_id     YOUR_CLIENT_ID
keyring set outlook-graph dude@msn.com_client_secret YOUR_CLIENT_SECRET
keyring set outlook-graph dude@msn.com_tenant_id     common

# Run ingestion (uses ~/.config/jps-rag-assistant/config.yaml by default)
jps-rag-assistant-ingest

# Or specify a custom config
jps-rag-assistant-ingest --config-file /path/to/my-config.yaml
```

After the first run, the vector store is persisted to ~/.jps-rag-assistant/ and will be incrementally updated on subsequent runs.

### Installation

```bash
# Clone and install in editable mode (recommended for development)
git clone https://github.com/jai-python3/jps-rag-assistant.git
cd jps-rag-assistant
make install    # runs: pip install -e ".[dev]"
```

Or install directly from GitHub:

```bash
pip install git+https://github.com/jai-python3/jps-rag-assistant.git
```

Headless Linux servers (or CI/CD environments)
On Linux systems without a graphical desktop (e.g. Ubuntu servers, Docker, GitHub Actions), avoid GUI-dependent keyring backends:

```bash
pip install -e ".[keyring-minimal]"
# or
pip install git+https://github.com/jai-python3/jps-rag-assistant.git#egg=jps-rag-assistant[keyring-minimal]
```

This installs only the appropriate keyring backend:

secretstorage on Linux x86_64 (uses GNOME Keyring or KDE Wallet if available, falls back to file)
Native backends on macOS and Windows
Prevents errors like No recommended backend was available


### Configuration
Place your config at:

```bash
~/.config/jps-rag-assistant/config.yaml
```

Example (with real defaults):

```yaml
---
ollama:
  model: llama3.1:70b
  embedding: nomic-embed-text
  request_timeout: 300

outlook:
  folder_names:
    - Inbox
    - Sent Items
  calendar:
    days: 180

jira:
  base_url: https://your-company.atlassian.net
  email: dude@msn.com
  days: 90

confluence:
  base_url: https://your-company.atlassian.net/wiki
  space_keys:
    - SoftwareEngineering
    - "~jsundaram"

vector_store:
  show_progress: true
  persist_dir: ~/.jps-rag-assistant

chunking:
  chunk_size: 512
  chunk_overlap: 50
```


### Development

```bash
# Format, lint, and fix
make fix
make format
make lint
```

### Run tests with coverage


```bash
make test
```
Pre-commit hooks are included — just run pre-commit install.

## License
MIT License © Jaideep Sundaram