from __future__ import annotations

from pathlib import Path

from llama_index.core import Document

from jps_rag_assistant.config import Config
from jps_rag_assistant.vector_store import build_or_update_index


def test_build_or_update_index_creates_store(tmp_path: Path, sample_config: Path):
    config = Config.load(sample_config)
    config.vector_store.persist_dir = str(tmp_path / "vector_store")

    docs = [
        Document(text="Hello world", doc_id="doc1"),
        Document(text="Test document", doc_id="doc2"),
    ]

    index = build_or_update_index(documents=docs, config=config)

    assert (tmp_path / "vector_store" / "docstore.json").exists()
    assert index is not None

    # Second run → should update, not recreate
    new_doc = Document(text="Updated content", doc_id="doc1")
    index2 = build_or_update_index(documents=[new_doc], config=config)
    assert index2 is not None
