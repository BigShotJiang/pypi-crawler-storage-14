class ReplayAttackError(Exception):
    """Raised when a replay attack is detected."""
