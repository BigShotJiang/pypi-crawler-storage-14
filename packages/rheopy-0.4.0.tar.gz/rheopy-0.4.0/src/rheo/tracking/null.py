"""Null object implementation of tracker."""

from ..domain.downloads import DownloadInfo
from ..events import BaseEmitter, NullEmitter
from .base import BaseTracker


class NullTracker(BaseTracker):
    """Null object implementation of tracker that does nothing."""

    def __init__(self) -> None:
        """Initialize null tracker with null emitter."""
        self._emitter = NullEmitter()

    @property
    def emitter(self) -> BaseEmitter:
        """Returns no-op emitter."""
        return self._emitter

    def get_download_info(self, download_id: str) -> DownloadInfo | None:
        """No-op: always returns None."""
        return None

    async def track_queued(self, download_id: str, url: str, priority: int = 1) -> None:
        pass

    async def track_started(
        self, download_id: str, url: str, total_bytes: int | None = None
    ) -> None:
        pass

    async def track_progress(
        self,
        download_id: str,
        url: str,
        bytes_downloaded: int,
        total_bytes: int | None = None,
    ) -> None:
        pass

    async def track_completed(
        self,
        download_id: str,
        url: str,
        total_bytes: int = 0,
        destination_path: str = "",
    ) -> None:
        pass

    async def track_speed_update(
        self,
        download_id: str,
        current_speed_bps: float,
        average_speed_bps: float,
        eta_seconds: float | None,
        elapsed_seconds: float,
    ) -> None:
        """No-op speed tracking."""
        pass

    async def track_failed(self, download_id: str, url: str, error: Exception) -> None:
        pass

    async def track_validation_started(
        self, download_id: str, url: str, algorithm: str
    ) -> None:
        pass

    async def track_validation_completed(
        self, download_id: str, url: str, algorithm: str, calculated_hash: str
    ) -> None:
        pass

    async def track_validation_failed(
        self,
        download_id: str,
        url: str,
        algorithm: str,
        expected_hash: str,
        actual_hash: str | None,
        error_message: str,
    ) -> None:
        pass
