from dataclasses import dataclass


@dataclass
class BLOBMetadata:
    size_bytes: int
