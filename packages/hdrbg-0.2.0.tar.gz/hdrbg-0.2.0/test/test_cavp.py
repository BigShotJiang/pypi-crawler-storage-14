from test import test


def test_it():
    test.check_against_nist_cavp()


if __name__ == '__main__':
    test_it()
