"""Command execution CLI package."""
