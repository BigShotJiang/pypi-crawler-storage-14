"""Utilities for dot-agent-kit.

Import from submodules:
- packaging: find_kit_manifest, get_package_path, get_package_version, is_package_installed
"""
