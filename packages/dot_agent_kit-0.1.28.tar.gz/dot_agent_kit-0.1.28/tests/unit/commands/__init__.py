"""Tests for commands."""
