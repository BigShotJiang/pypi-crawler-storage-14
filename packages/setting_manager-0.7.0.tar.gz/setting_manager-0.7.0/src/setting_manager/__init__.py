__version__ = "0.7.0"
__author__ = "Konstantin Zhmurko"


from .manager import SettingsManager

__all__ = ["SettingsManager"]
