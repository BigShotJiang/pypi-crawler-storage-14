import sys
import json
import os
import requests
from typing import Dict, Any

# MCP服务器地址 (可通过环境变量 MCP_SERVER_URL 覆盖，默认使用生产环境)
MCP_SERVER_URL = os.environ.get("MCP_SERVER_URL", "https://uther.xiaote.net/api/mcp/proxy")

def get_api_key():
    """获取API Key，优先从环境变量获取"""
    # 支持 TESLA_MCP_API_KEY（推荐）和旧版本 API_KEY（向后兼容）
    api_key = os.environ.get("TESLA_MCP_API_KEY") or os.environ.get("API_KEY") or os.environ.get("TESLA_MCP_KEY")
    if not api_key:
        # 如果缺少 API Key，直接退出，不输出 JSON-RPC 响应
        # 因为此时还没有读取到任何请求，无法构造有效的响应
        sys.stderr.write("错误: TESLA_MCP_API_KEY 环境变量未设置。请在 Claude Desktop 配置或环境变量中设置。\n")
        sys.exit(1)
    return api_key

def send_mcp_request(request: Dict[str, Any], api_key: str) -> Dict[str, Any]:
    """发送MCP请求到HTTP服务器"""
    try:
        response = requests.post(
            MCP_SERVER_URL,
            json={
                "api_key": api_key,
                "request": request
            },
            headers={"Content-Type": "application/json"},
            timeout=60  # 增加超时时间，因为车辆唤醒可能需要时间
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        # 确保 id 不是 None，JSON-RPC 2.0 要求 id 必须是 string 或 number
        request_id = request.get("id")
        if request_id is None:
            request_id = 0
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": -32603,
                "message": f"HTTP请求失败: {str(e)}"
            }
        }

def main():
    """主函数：从stdin读取请求，发送到HTTP服务器，输出响应"""
    api_key = get_api_key()
    
    # 强制设置 stdin/stdout 为 utf-8 编码，避免 Windows 下编码问题
    if sys.platform == 'win32':
        sys.stdin.reconfigure(encoding='utf-8')
        sys.stdout.reconfigure(encoding='utf-8')

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            request = json.loads(line)
            request_id = request.get("id")
            response = send_mcp_request(request, api_key)
            print(json.dumps(response, ensure_ascii=False), flush=True)
        except json.JSONDecodeError as e:
            # JSON 解析错误时，无法获取 request id，使用 0 作为默认值
            error_response = {
                "jsonrpc": "2.0",
                "id": 0,
                "error": {
                    "code": -32700,
                    "message": f"Parse error: {str(e)}"
                }
            }
            print(json.dumps(error_response, ensure_ascii=False), flush=True)
        except Exception as e:
            # 尝试从请求中获取 id，如果失败则使用 0
            try:
                request = json.loads(line)
                request_id = request.get("id", 0)
            except:
                request_id = 0
            error_response = {
                "jsonrpc": "2.0",
                "id": request_id if request_id is not None else 0,
                "error": {
                    "code": -32603,
                    "message": f"Internal error: {str(e)}"
                }
            }
            print(json.dumps(error_response, ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()

