from .models import config_gen


def get_root_path():
    print(config_gen.get_root_path())
