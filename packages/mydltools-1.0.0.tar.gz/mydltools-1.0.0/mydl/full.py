def run():
    import tensorflow as tf
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    from tensorflow.keras.applications import VGG16
    from tensorflow.keras.layers import Dense, Flatten, Dropout
    from tensorflow.keras.models import Model
    from sklearn.metrics import classification_report, confusion_matrix
    import numpy as np
    import matplotlib.pyplot as plt

    # ---------------------
    # 1️⃣ Load and Split Dataset
    # ---------------------

    DATASET_PATH = "dataset"  # change to your folder path

    datagen = ImageDataGenerator(
        rescale = 1/255.0,
        validation_split=0.2 # 80% train, 20% test
    )

    train_gen = datagen.flow_from_directory(
        DATASET_PATH,
        target_size=(224, 224),
        batch_size=32,
        class_mode="categorical",
        subset="training"
    )

    test_gen = datagen.flow_from_directory(
        DATASET_PATH,
        target_size=(224, 224),
        batch_size=32,
        class_mode="categorical",
        subset="validation",
        shuffle=False           
    )

    num_classes = len(train_gen.class_indices)

    # ---------------------
    # 2️⃣ Load VGG16 Pretrained Model
    # ---------------------

    base_model = VGG16(weights="imagenet", include_top=False, input_shape=(224, 224, 3))

    # Freeze pretrained layers
    for layer in base_model.layers:
        layer.trainable = False

    # Add classification layers
    x = Flatten()(base_model.output)
    x = Dense(256, activation="relu")(x)
    x = Dropout(0.5)(x)
    output = Dense(num_classes, activation="softmax")(x)

    model = Model(inputs=base_model.input, outputs=output)

    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    model.summary()

    # ---------------------
    # 3️⃣ Train Model
    # ---------------------

    history = model.fit(
        train_gen,
        epochs=10,
        validation_data=test_gen
    )

    # ---------------------
    # 4️⃣ Evaluate + Classification Report
    # ---------------------

    y_true = test_gen.classes
    y_pred = np.argmax(model.predict(test_gen), axis=1)

    print("\nClassification Report:")
    print(classification_report(y_true, y_pred, target_names=test_gen.class_indices.keys()))

    print("\nConfusion Matrix:")
    print(confusion_matrix(y_true, y_pred))

    # ---------------------
    # 5️⃣ Display Sample Predictions
    # ---------------------

    images, labels = next(test_gen)
    preds = np.argmax(model.predict(images), axis=1)

    class_names = list(test_gen.class_indices.keys())

    plt.figure(figsize=(12, 12))
    for i in range(9):
        plt.subplot(3, 3, i + 1)
        plt.imshow(images[i])
        plt.title(f"Real: {class_names[np.argmax(labels[i])]}  | Pred: {class_names[preds[i]]}")
        plt.axis("off")

    plt.show()
