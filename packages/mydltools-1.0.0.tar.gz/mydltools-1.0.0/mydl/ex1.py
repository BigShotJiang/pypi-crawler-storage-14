def run():
    import seaborn as sns
    import pandas as pd
    import matplotlib.pyplot as plt

    confusion_matrix = {
        "Apple": {"Apple": 92, "Banana": 0, "Orange": 3, "Mango": 2, "Grapes": 0},
        "Banana": {"Apple": 0, "Banana": 94, "Orange": 3, "Mango": 0, "Grapes": 3},
        "Orange": {"Apple": 2, "Banana": 0, "Orange": 95, "Mango": 0, "Grapes": 0},
        "Mango": {"Apple": 5, "Banana": 1, "Orange": 0, "Mango": 90, "Grapes": 1},
        "Grapes": {"Apple": 1, "Banana": 0, "Orange": 0, "Mango": 0, "Grapes": 99}
    }

    df = pd.DataFrame(confusion_matrix).T 
    plt.figure(figsize=(20, 20))
    sns.heatmap(df, annot=True, fmt="d", cmap="YlGnBu")
    plt.title("Confusion Matrix")
    plt.ylabel("Predicted")
    plt.xlabel("Actual")
    plt.show()