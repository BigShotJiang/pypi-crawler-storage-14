def run():
    from numpy import expand_dims
    from tensorflow.keras.preprocessing.image import load_img,img_to_array,ImageDataGenerator
    import matplotlib.pyplot as plt
    # Horizontal 
    img = load_img("bird.jpg")
    arr = img_to_array(img)
    samples = expand_dims(arr,0)
    datagen = ImageDataGenerator(zoom_range = [1,2])
    it = datagen.flow(samples,batch_size = 1)
    for i in range(9):
        plt.subplot(330+1+i)
        batch = next(it)
        shifted_img = batch[0].astype('uint8')
        plt.imshow(shifted_img)
    plt.show()

    # "Height Shift (0.5)": ImageDataGenerator(height_shift_range=0.5),
    # "Width Shift (-200 to 200)": ImageDataGenerator(width_shift_range=[-200,200]),
    # "Horizontal Flip": ImageDataGenerator(horizontal_flip=True),
    # "Rotation (0-90°)": ImageDataGenerator(rotation_range=90),
    # "Brightness (0.2 → 1.0)": ImageDataGenerator(brightness_range=[0.2,1.0]),
    # "Zoom (0.5 → 1.0)": ImageDataGenerator(zoom_range=[0.5,1.0])
