from setuptools import setup, find_packages

setup(
    name="mydltools",
    version="1.0.0",
    description="Custom deep learning and visualization examples",
    author="Batman",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
        "seaborn",
        "tensorflow",
        "keras",
        "pycm",
    ],
    python_requires=">=3.7"
)