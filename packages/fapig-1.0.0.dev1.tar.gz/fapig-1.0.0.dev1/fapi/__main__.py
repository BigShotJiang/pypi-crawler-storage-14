if __name__ == "__main__":
    from fapi.cli import app

    app()
