import typer

from fapi.commands import init

app = typer.Typer(
    name="Fapi: FastAPI Project Manager",
    help="A CLI tool to initialize FastAPI projects",
)

app.add_typer(init)

if __name__ == "__main__":
    app()
