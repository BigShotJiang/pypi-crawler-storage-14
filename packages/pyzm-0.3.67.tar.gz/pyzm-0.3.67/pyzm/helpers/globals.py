from pyzm.helpers.Base import ConsoleLog
logger = ConsoleLog()