# Chotulang Interpreter

This is the official interpreter for the Chotulang programming language.

## Installation

pip install chotueng_interpreter

