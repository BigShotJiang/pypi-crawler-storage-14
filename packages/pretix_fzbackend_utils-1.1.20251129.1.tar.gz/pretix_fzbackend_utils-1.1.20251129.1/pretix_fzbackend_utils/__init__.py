__version__ = "1.1.20251129.1"

import logging

logging.getLogger(__package__).setLevel(logging.DEBUG)
