class rawstr:
    ESC :str = "\033["
    
    # using ESC as a local variable.

    # ~2ms faster than global (diference
    # is almost unnoticable )
    # ~12ms faster than class attributes

    # also using % formatting instead of
    # f strings for more compatability
    # with older versions of python.

    @staticmethod
    def move(x: int, y: int) -> str: 
        esc = rawstr.ESC
        return "%s%s;%sH" % (esc, y, x)
    
    @staticmethod
    def cursor_up(i: int) -> str:
        esc = rawstr.ESC
        return "%s%sA" % (esc, i)
    
    @staticmethod
    def cursor_down(i: int) -> str:
        esc = rawstr.ESC
        return "%s%sB" % (esc, i)
    
    @staticmethod
    def cursor_forward(i: int) -> str:
        esc = rawstr.ESC
        return "%s%sC" % (esc, i)
    
    @staticmethod
    def cursor_back(i: int) -> str:
        esc = rawstr.ESC
        return "%s%sD" % (esc, i)
    
    @staticmethod
    def cursor_next_line(i: int= 1) -> str:
        esc = rawstr.ESC
        return "%s%sE" % (esc, i)
    
    @staticmethod
    def cursor_prev_line(i: int= 1) -> str:
        esc = rawstr.ESC
        return "%s%sF" % (esc, i)
    
    @staticmethod
    def rgb(r: int, g: int, b: int) -> str:
        esc = rawstr.ESC
        return "%s38;2;%s;%s;%sm" % (esc, r, g, b)
    
    @staticmethod
    def clear() -> str:
        esc = rawstr.ESC
        return "%s2J" % (esc)
    
    @staticmethod
    def scroll_up() -> str:
        esc = rawstr.ESC
        return "%snS" % (esc)
    
    @staticmethod
    def scroll_down() -> str:
        esc = rawstr.ESC
        return "%snT" % (esc)
    
    @staticmethod
    def style_bold() -> str:
        esc = rawstr.ESC
        return "%s1m" % (esc)
    
    @staticmethod
    def style_dim() -> str:
        esc = rawstr.ESC
        return "%s2m" % (esc)
    
    @staticmethod
    def style_italic() -> str:
        esc = rawstr.ESC
        return "%s3m" % (esc)
    
    @staticmethod
    def style_underlined() -> str:
        esc = rawstr.ESC
        return "%s4m" % (esc)
    
    @staticmethod
    def style_slow_blink() -> str:
        esc = rawstr.ESC
        return "%s5m" % (esc)
    
    @staticmethod
    def style_fast_blink() -> str:
        esc = rawstr.ESC
        return "%s6m" % (esc)
    
    @staticmethod
    def style_reverse() -> str:
        esc = rawstr.ESC
        return "%s7m" % (esc)
    
    @staticmethod
    def style_hide() -> str:
        esc = rawstr.ESC
        return "%s8m" % (esc)
    
    @staticmethod
    def style_strike() -> str:
        esc = rawstr.ESC
        return "%s9m" % (esc)
    
    @staticmethod
    def style_fraftur() -> str:
        esc = rawstr.ESC
        return "%s20m" % (esc)
    
    @staticmethod
    def reset() -> str:
        esc = rawstr.ESC
        return "%s0m" % (esc)