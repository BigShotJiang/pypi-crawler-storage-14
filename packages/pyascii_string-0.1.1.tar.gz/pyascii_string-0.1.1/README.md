## PyAscii | A mid level terminal ascii control

# Installation
on windows just run this command:
`pip -m install pyascii_str`
