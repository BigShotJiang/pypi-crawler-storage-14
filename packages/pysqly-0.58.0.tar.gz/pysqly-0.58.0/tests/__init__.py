"""Test package for pySQLY."""
