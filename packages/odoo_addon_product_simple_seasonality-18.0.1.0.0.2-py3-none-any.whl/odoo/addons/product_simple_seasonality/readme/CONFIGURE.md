Create seasonalities and assign them to products

Use case:

Season are recurring specific periods each year.

Apply product to season(s) allows to apply specific process to these products.

.. figure:: ../static/description/seasonality.png

.. figure:: ../static/description/product.png
