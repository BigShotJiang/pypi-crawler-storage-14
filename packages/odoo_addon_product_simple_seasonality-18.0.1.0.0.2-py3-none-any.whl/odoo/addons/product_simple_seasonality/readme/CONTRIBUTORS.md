* `Akretion <https://akretion.com>`:

  * Kevin Khao <kevin.khao@akretion.com>
  * David Beal <david.beal@akretion.com>

- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia
