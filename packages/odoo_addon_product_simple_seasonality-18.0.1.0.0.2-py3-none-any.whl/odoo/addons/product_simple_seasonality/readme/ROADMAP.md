We should consider the module product_seasonality by C2C so that they can be merged in some way.
