This module adds a simple concept of seasonality for products
