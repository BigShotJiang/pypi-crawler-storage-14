from core import preprocess, tokenize

txt = "This is an example sentence for NLP processing."

print("Tokens:", tokenize(txt))
print("Preprocessed:", preprocess(txt))
