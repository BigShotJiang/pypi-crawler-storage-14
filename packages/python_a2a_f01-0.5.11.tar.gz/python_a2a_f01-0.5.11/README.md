# Python A2A - Agent-to-Agent Protocol

A Python library for implementing Google's Agent-to-Agent (A2A) protocol.

## Installation

```bash
pip install python-a2a
```

## Features

- Complete implementation of Google's A2A protocol specification
- Robust data models for A2A messages and conversations
- Easy-to-use HTTP client and server components
- Built-in support for various LLM providers (OpenAI, Anthropic, Bedrock)
- First-class support for function calling between agents
- MCP (Model Context Protocol) integration
- Agent discovery and workflow orchestration

## Usage

See the [documentation](https://github.com/google/python-a2a) for more details.
