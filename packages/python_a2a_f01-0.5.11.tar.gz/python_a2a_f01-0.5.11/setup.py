from setuptools import setup, find_packages
import os

# Read README.md for long description
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()

# Custom package discovery for flat layout
# The root directory is the 'python_a2a' package
# Subdirectories like 'agent_flow' are subpackages 'python_a2a.agent_flow'
found_packages = find_packages(where='.', exclude=['tests', 'tests.*'])
packages = ['python_a2a'] + ['python_a2a.' + p for p in found_packages]

setup(
    name="python-a2a-f01",
    version="0.5.11",
    description="Python A2A - Agent-to-Agent Protocol",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/google/python-a2a",
    author="Google LLC",
    author_email="googleapis-packages@google.com",
    license="Apache-2.0",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    # Map 'python_a2a' package to the current directory ('.')
    package_dir={'python_a2a': '.'},
    packages=packages,
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "pydantic>=2.0.0",
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "server": ["flask", "uvicorn"],
        "mcp": ["fastapi", "uvicorn"],
        "llm": ["openai", "anthropic"],
        "all": ["flask", "fastapi", "uvicorn", "openai", "anthropic"],
    },
    entry_points={
        "console_scripts": [
            "python-a2a=python_a2a.cli:main",
        ],
    },
    include_package_data=True,
)
