"""Semantico - Ontologia Core - Camada Semântica."""

from .core import (
    CONSTRAINT_REGISTRY,
    Archetype,
    ArchetypeValidationError,
    Cardinality,
    Complexity,
    Constraint,
    Criticality,
    Interface,
    Length,
    Link,
    LinkDescriptor,
    LinkManager,
    Logic,
    Object,
    Property,
    Range,
    Regex,
    Sensitivity,
    VirtualObject,
    clear_kernel,
    computed,
    get_constraint_registry,
    get_kernel,
    logic,
    reconstruct_constraint,
    set_kernel,
)

__all__ = [
    # Dependency Injection
    "clear_kernel",
    "get_kernel",
    "set_kernel",
    # Constraints
    "CONSTRAINT_REGISTRY",
    "Constraint",
    "Length",
    "Range",
    "Regex",
    "get_constraint_registry",
    "reconstruct_constraint",
    # RFC-002: Governance Enums
    "Sensitivity",
    "Criticality",
    "Complexity",
    # Core Classes
    "Archetype",
    "ArchetypeValidationError",
    "Cardinality",
    "Interface",
    "Link",
    "LinkDescriptor",
    "LinkManager",
    "Logic",
    "Object",
    "Property",
    "VirtualObject",
    # Decorators
    "computed",
    "logic",
]

__version__ = "0.5.0"  # RFC-002: Semantico 2.0
