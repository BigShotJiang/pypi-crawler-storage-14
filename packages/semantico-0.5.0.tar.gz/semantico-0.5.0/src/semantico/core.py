# /// script
# requires-python = ">=3.13"
# dependencies = [
#     "pydantic>=2.12",
#     "registro>=0.7.0",
#     "malha>=0.10.7",
#     "politipo>=0.5.1"
# ]
# ///

"""
Ontologia Core - Camada Semântica (Pure Layer 5)
================================================
Definição Estrita de Nouns (Objetos), Adjectives (Properties) e Relationships (Links).

Design Pattern:
- Alinhado ao Palantir Foundry Ontology.
- Interfaces são Contratos de Dados (Shared Schema).
- Objetos são Active Records inteligentes.
- Links são Descritores de Grafo.

Refatorado para Malha v0.10.7:
- Delegação total de contexto para malha
- Consistência Causal via Watermarks
- Archetype como wrapper de UnitOfWork
"""

from __future__ import annotations

import abc
import inspect
from enum import Enum
import logging
import re
import uuid
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    ClassVar,
    Generic,
    TypeVar,
    cast,
)

from politipo import DataType
from pydantic import BaseModel, ConfigDict, Field

# --- Fundação & Motor ---
from registro import DomainResource
from registro import registry as global_registry
from registro.models.rid import RID

# --- Integração com Kernel (Fat Kernel Pattern) ---
from malha import (
    get_kernel as malha_get_kernel,
    set_kernel as malha_set_kernel,
    clear_kernel as malha_clear_kernel,
    UnifiedDataManager,
    UnitOfWork,
)

logger = logging.getLogger("ontologia.semantico")
TargetT = TypeVar("TargetT", bound="Object")
T = TypeVar("T", bound="Object")


# ==============================================================================
# Cardinality (Restrições de Multiplicidade)
# ==============================================================================


class Cardinality(str, Enum):
    """Define a multiplicidade permitida em Links."""
    ONE_TO_ONE = "1:1"    # Marido <-> Esposa (exclusivo em ambos os lados)
    ONE_TO_MANY = "1:N"   # Gerente -> Subordinados (um gerente, muitos subordinados)
    MANY_TO_ONE = "N:1"   # Empregados -> Departamento (muitos empregados, um departamento)
    MANY_TO_MANY = "N:N"  # Estudantes <-> Cursos (padrão, sem restrição)


# ==============================================================================
# Governance Enums (RFC-002: Semantic Tagging)
# ==============================================================================


class Sensitivity(str, Enum):
    """
    Nível de sensibilidade de dados para governança automática.
    
    Usado pelo GovernanceInterceptor para redação automática e
    pelo Cognitive Sentinel para controle de acesso.
    """
    PUBLIC = "PUBLIC"           # Dados públicos, sem restrição
    INTERNAL = "INTERNAL"       # Uso interno, não expor externamente
    CONFIDENTIAL = "CONFIDENTIAL"  # Dados confidenciais, acesso restrito
    SECRET = "SECRET"           # PII/PHI, requer permissão explícita


class Criticality(str, Enum):
    """
    Nível de criticidade para operações de escrita.
    
    Usado pelo Kinetic Bridge para instruir o LLM sobre
    o impacto de modificações em campos.
    """
    LOW = "LOW"       # Modificações seguras, baixo impacto
    MEDIUM = "MEDIUM" # Requer atenção, impacto moderado
    HIGH = "HIGH"     # Operação crítica, requer confirmação


class Complexity(str, Enum):
    """
    Complexidade computacional de uma Logic.
    
    Usado pelo orquestrador para estimar custo de computação
    e priorizar execuções.
    """
    O_1 = "O(1)"       # Tempo constante
    O_LOG_N = "O(log n)"  # Logarítmico
    O_N = "O(n)"       # Linear
    O_N_LOG_N = "O(n log n)"  # Linearítmico
    O_N2 = "O(n²)"     # Quadrático
    O_UNKNOWN = "O(?)" # Complexidade desconhecida


# ==============================================================================
# 0. Dependency Injection (Delegada ao Malha)
# ==============================================================================


def set_kernel(kernel: UnifiedDataManager) -> None:
    """Define o kernel no contexto atual (thread/async-safe). Delegado ao Malha."""
    malha_set_kernel(kernel)


def get_kernel() -> UnifiedDataManager:
    """Obtém o kernel do contexto atual. Delegado ao Malha."""
    return malha_get_kernel()


def clear_kernel() -> None:
    """Limpa o kernel do contexto. Delegado ao Malha."""
    malha_clear_kernel()


# ==============================================================================
# 1. Constraints (Regras de Integridade)
# ==============================================================================


class Constraint(BaseModel, abc.ABC):
    """Regra de validação serializável (Lógica como Dados)."""
    description: str = Field(default="Regra de validação")
    error_message: str = Field(default="Valor inválido")

    @abc.abstractmethod
    def validate(self, value: Any) -> None:
        pass


class Range(Constraint):
    """Constraint de intervalo numérico."""
    min: float | None = None
    max: float | None = None

    def validate(self, value: Any) -> None:
        if isinstance(value, (int, float)):
            if self.min is not None and value < self.min:
                raise ValueError(f"{self.error_message}: {value} < {self.min}")
            if self.max is not None and value > self.max:
                raise ValueError(f"{self.error_message}: {value} > {self.max}")

    def to_sql_check(self, column: str) -> str:
        """Exporta como CHECK constraint SQL."""
        checks = []
        if self.min is not None:
            checks.append(f"{column} >= {self.min}")
        if self.max is not None:
            checks.append(f"{column} <= {self.max}")
        return " AND ".join(checks) if checks else "TRUE"

    def to_pandera_check(self) -> dict[str, Any]:
        """Exporta como Pandera Check config."""
        return {"check_type": "in_range", "min_value": self.min, "max_value": self.max}


class Regex(Constraint):
    """Constraint de padrão regex."""
    pattern: str

    def validate(self, value: Any) -> None:
        if isinstance(value, str) and not re.match(self.pattern, value):
            raise ValueError(f"{self.error_message}: '{value}' não casa com {self.pattern}")

    def to_sql_check(self, column: str) -> str:
        """Exporta como CHECK constraint SQL (PostgreSQL)."""
        escaped = self.pattern.replace("'", "''")
        return f"{column} ~ '{escaped}'"

    def to_pandera_check(self) -> dict[str, Any]:
        """Exporta como Pandera Check config."""
        return {"check_type": "str_matches", "pattern": self.pattern}


class Length(Constraint):
    """Constraint de comprimento para strings."""
    min_length: int | None = None
    max_length: int | None = None

    def validate(self, value: Any) -> None:
        if isinstance(value, str):
            if self.min_length is not None and len(value) < self.min_length:
                raise ValueError(f"{self.error_message}: comprimento {len(value)} < {self.min_length}")
            if self.max_length is not None and len(value) > self.max_length:
                raise ValueError(f"{self.error_message}: comprimento {len(value)} > {self.max_length}")

    def to_sql_check(self, column: str) -> str:
        """Exporta como CHECK constraint SQL."""
        checks = []
        if self.min_length is not None:
            checks.append(f"LENGTH({column}) >= {self.min_length}")
        if self.max_length is not None:
            checks.append(f"LENGTH({column}) <= {self.max_length}")
        return " AND ".join(checks) if checks else "TRUE"

    def to_pandera_check(self) -> dict[str, Any]:
        """Exporta como Pandera Check config."""
        return {"check_type": "str_length", "min_value": self.min_length, "max_value": self.max_length}


# Registry de tipos de Constraint para reconstrução a partir de JSON
CONSTRAINT_REGISTRY: dict[str, type[Constraint]] = {
    "Range": Range,
    "Regex": Regex,
    "Length": Length,
}


def reconstruct_constraint(data: dict[str, Any]) -> Constraint | None:
    """Reconstrói uma Constraint a partir de seu dict serializado."""
    if "pattern" in data:
        return Regex(**data)
    if "min_length" in data or "max_length" in data:
        return Length(**data)
    if "min" in data or "max" in data:
        return Range(**data)
    return None


def get_constraint_registry() -> dict[str, dict[str, Any]]:
    """Retorna o registry de constraints como dicionário serializável."""
    registry = {}
    for name, cls in CONSTRAINT_REGISTRY.items():
        schema = cls.model_json_schema()
        registry[name] = {
            "name": name,
            "description": cls.__doc__ or "",
            "schema": schema,
            "fields": list(schema.get("properties", {}).keys()),
        }
    return registry


# ==============================================================================
# 2. Property (Definição de Campo Rico)
# ==============================================================================


def Property(
    type_spec: Any = DataType.STRING,
    *,
    title: str | None = None,
    unit: str | None = None,
    constraints: list[Constraint] | None = None,
    description: str = "",
    required: bool = True,
    default: Any = ...,
    primary_key: bool = False,
    # RFC-002: Semantic Tagging para Governança
    sensitivity: Sensitivity | str = Sensitivity.INTERNAL,
    criticality: Criticality | str = Criticality.LOW,
    immutable: bool = False,
    **kwargs,
) -> Any:
    """
    Define uma Propriedade da Ontologia com metadados semânticos.
    
    RFC-002 Enhancements:
    - sensitivity: Nível de sensibilidade (PUBLIC, INTERNAL, CONFIDENTIAL, SECRET)
    - criticality: Nível de criticidade para escrita (LOW, MEDIUM, HIGH)
    - immutable: Se True, campo não pode ser alterado após criação
    
    Esses metadados são serializados no json_schema_extra para consumo pelo:
    - GovernanceInterceptor: Redação automática de campos SECRET
    - Cognitive Sentinel: Controle de acesso baseado em sensibilidade
    - Kinetic Bridge: Instruções para o LLM sobre campos críticos
    
    Exemplo:
        class User(Object):
            name: str = Property(sensitivity=Sensitivity.PUBLIC)
            ssn: str = Property(sensitivity=Sensitivity.SECRET, immutable=True)
    """
    # Normaliza enums se passados como string
    if isinstance(sensitivity, str):
        sensitivity = Sensitivity(sensitivity)
    if isinstance(criticality, str):
        criticality = Criticality(criticality)
    
    json_schema_extra = {
        "semantic_type": "Property",
        "title": title,
        "unit": unit,
        "constraints": [c.model_dump() for c in (constraints or [])],
        "is_natural_key": primary_key,
        # RFC-002: Security metadata para Cognitive Sentinel e Kinetic Bridge
        "security": {
            "sensitivity": sensitivity.value,
            "criticality": criticality.value,
            "immutable": immutable,
        },
    }

    if default is ... and not required:
        default = None

    return Field(
        default=default, description=description, json_schema_extra=json_schema_extra, **kwargs
    )


def computed(func: Callable) -> property:
    """
    Decorator para propriedades computadas (derivadas).
    Marca o método para ser exposto na ontologia como 'read-only'.
    
    Exemplo:
        @computed
        def full_name(self) -> str:
            return f"{self.first_name} {self.last_name}"
    """
    func._is_computed_property = True
    return property(func)


# ==============================================================================
# 3. LinkManager (Implicit Causal Scheduling)
# ==============================================================================


class LinkManager(Generic[TargetT]):
    """
    Proxy runtime para navegar no grafo.
    
    Atualizado para Malha v0.10.7:
    - Usa Implicit Causal Scheduling (Watermarks)
    - Usa Batch Fetching (mget)
    """

    def __init__(
        self,
        source: "Object",
        label: str,
        target_cls: type[TargetT] | str,
        inverse: bool,
        cardinality: Cardinality = Cardinality.MANY_TO_MANY,
        *,
        kernel: UnifiedDataManager | None = None,
    ):
        self.source = source
        self.label = label
        self._target_cls_def = target_cls
        self.inverse = inverse
        self.cardinality = cardinality
        self._kernel = kernel

    def _get_kernel(self) -> UnifiedDataManager:
        """Obtém kernel injetado ou do contexto."""
        if self._kernel is not None:
            return self._kernel
        return get_kernel()

    @property
    def target_cls(self) -> type[TargetT]:
        if isinstance(self._target_cls_def, str):
            return cast(type[TargetT], global_registry.get_or_error(self._target_cls_def))
        return self._target_cls_def

    async def _check_cardinality(self, target: "Object") -> None:
        """Valida cardinalidade antes de escrever."""
        if self.cardinality == Cardinality.MANY_TO_MANY:
            return

        k = self._get_kernel()
        wm = getattr(k, "get_session_watermark", lambda: 0)()

        # Se for 1:1 ou N:1, source só pode ter 1 link
        if self.cardinality in (Cardinality.ONE_TO_ONE, Cardinality.MANY_TO_ONE):
            if await self.count() > 0:
                raise ValueError(
                    f"Cardinalidade {self.cardinality.value} violada: "
                    f"{self.source.rid} já possui uma conexão '{self.label}'."
                )

        # Se for 1:1 ou 1:N, target só pode ter 1 link (query inversa)
        if self.cardinality in (Cardinality.ONE_TO_ONE, Cardinality.ONE_TO_MANY):
            cypher = f"MATCH (n)-[:{self.label}]->(t) WHERE t.rid = $target_rid RETURN COUNT(n) as cnt"
            res = await k.graph.query(cypher, {"target_rid": target.rid}, required_watermark=wm)
            if res and res[0].get("cnt", 0) > 0:
                raise ValueError(
                    f"Cardinalidade {self.cardinality.value} violada: "
                    f"O alvo {target.rid} já é destino de uma conexão '{self.label}'."
                )

    async def add(
        self,
        target: "Object",
        props: dict[str, Any] | None = None,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> None:
        """Cria aresta (link)."""
        if not self.source.rid or not target.rid:
            raise ValueError("Objetos devem ser salvos antes de vincular.")

        await self._check_cardinality(target)

        k = kernel or self._get_kernel()
        src, dst = (target, self.source) if self.inverse else (self.source, target)
        await k.link(src.to_envelope(), dst.to_envelope(), self.label, props)

    async def remove(
        self,
        target: "Object",
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> None:
        """Remove aresta."""
        k = kernel or self._get_kernel()
        src, dst = (target, self.source) if self.inverse else (self.source, target)
        await k.unlink(src.to_envelope(), dst.to_envelope(), self.label)

    async def all(
        self,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> list[TargetT]:
        """
        Retorna objetos conectados.
        
        SotA Implementation:
        1. Pega Watermark de sessão (RYOW).
        2. Query no Grafo com barreira de consistência.
        3. Batch Fetch (mget) no SQL.
        """
        k = kernel or self._get_kernel()
        
        # 1. Causal Consistency Watermark
        wm = getattr(k, "get_session_watermark", lambda: 0)()
        
        # 2. Query no Grafo
        if self.inverse:
            cypher = f"MATCH (t)-[:{self.label}]->(s) WHERE s.rid = $rid RETURN t.rid"
        else:
            cypher = f"MATCH (s)-[:{self.label}]->(t) WHERE s.rid = $rid RETURN t.rid"

        results = await k.graph.query(cypher, {"rid": self.source.rid}, required_watermark=wm)
        
        # Extrai RIDs válidos
        target_rids = []
        for row in results:
            rid = row.get("t.rid") or row.get("t", {}).get("rid")
            if rid:
                target_rids.append(rid)
        
        if not target_rids:
            return []
        
        # 3. Batch Fetch (Otimização N+1)
        if hasattr(k, "mget"):
            return await k.mget(self.target_cls, rids=target_rids)
        
        # Fallback se kernel for antigo
        logger.warning("Kernel não suporta mget - usando fallback N+1.")
        objs = []
        for rid in target_rids:
            o = await k.get(self.target_cls, rid=rid)
            if o:
                objs.append(o)
        return objs

    async def first(
        self,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> TargetT | None:
        """Retorna o primeiro objeto conectado ou None."""
        res = await self.all(kernel=kernel)
        return res[0] if res else None

    async def count(
        self,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> int:
        """Conta objetos conectados sem carregá-los."""
        k = kernel or self._get_kernel()
        wm = getattr(k, "get_session_watermark", lambda: 0)()
        
        if self.inverse:
            cypher = f"MATCH (t)-[:{self.label}]->(s) WHERE s.rid = $rid RETURN COUNT(t) as cnt"
        else:
            cypher = f"MATCH (s)-[:{self.label}]->(t) WHERE s.rid = $rid RETURN COUNT(t) as cnt"

        res = await k.graph.query(cypher, {"rid": self.source.rid}, required_watermark=wm)
        return res[0].get("cnt", 0) if res else 0


class LinkDescriptor(Generic[TargetT]):
    """Define a topologia do grafo (Link Type Definition)."""

    def __init__(
        self,
        label: str,
        target: str | type[TargetT],
        cardinality: Cardinality = Cardinality.MANY_TO_MANY,
        inverse: bool = False,
    ):
        self.label = label.upper()
        self.target = target
        self.cardinality = cardinality
        self.inverse = inverse

    def __get__(
        self, instance: "Object | None", owner: type["Object"]
    ) -> "LinkDescriptor | LinkManager[TargetT]":
        if instance is None:
            return self
        kernel = getattr(instance, "_injected_kernel", None)
        return LinkManager(
            instance,
            self.label,
            self.target,
            self.inverse,
            self.cardinality,
            kernel=kernel,
        )


def Link(
    label: str,
    target: str | type[TargetT] = "Object",
    cardinality: Cardinality = Cardinality.MANY_TO_MANY,
    inverse: bool = False,
) -> Any:
    """Define um link (relação) entre Object Types."""
    return LinkDescriptor(label, target, cardinality, inverse)


# ==============================================================================
# 4. Interface (Contrato de Dados Compartilhado)
# ==============================================================================


class Interface(BaseModel):
    """
    Define um conjunto de Propriedades (Schema) que múltiplos Objetos podem implementar.
    Conceito Palantir: Interfaces permitem tratar objetos diferentes de forma polimórfica.
    """
    pass


# ==============================================================================
# 5. Object (Entidade Concreta)
# ==============================================================================


class Object(DomainResource):
    """
    Entidade base do Semântico.
    
    Integração SotA:
    - Kernel Injected (testabilidade).
    - Validation Fail-Fast.
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)
    _injected_kernel: UnifiedDataManager | None = None

    def __init__(self, *, kernel: UnifiedDataManager | None = None, **data):
        super().__init__(**data)
        object.__setattr__(self, "_injected_kernel", kernel)
        self._validate_constraints()

    def _get_kernel(self) -> UnifiedDataManager:
        """Obtém kernel injetado ou do contexto."""
        if self._injected_kernel is not None:
            return self._injected_kernel
        return get_kernel()

    def with_kernel(self: T, kernel: UnifiedDataManager) -> T:
        """Retorna o mesmo objeto com kernel injetado."""
        object.__setattr__(self, "_injected_kernel", kernel)
        return self

    def _validate_constraints(self) -> None:
        """Valida constraints em tempo de instanciação (Fail Fast)."""
        for field_name, field in self.__class__.model_fields.items():
            extra = field.json_schema_extra
            if not extra or not isinstance(extra, dict):
                continue

            constraints_data = extra.get("constraints", [])
            value = getattr(self, field_name, None)
            if value is None:
                continue

            for constraint_dict in constraints_data:
                constraint = reconstruct_constraint(constraint_dict)
                if constraint:
                    try:
                        constraint.validate(value)
                    except ValueError as e:
                        raise ValueError(f"Campo '{field_name}': {e}") from e

    def _before_save(self) -> None:
        """Hook executado antes de persistir."""
        self._validate_constraints()

    async def save(
        self,
        agent: Any = None,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> "Object":
        """Persiste (SCD2) no Kernel."""
        self._before_save()
        k = kernel or self._get_kernel()
        saved = await k.save_versioned(self, agent=agent)
        self.__dict__.update(saved.__dict__)
        return self

    async def delete(
        self,
        agent: Any = None,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> None:
        """Soft-delete."""
        k = kernel or self._get_kernel()
        await k.delete_versioned(self, agent=agent)

    @classmethod
    async def get(
        cls: type[T],
        rid: str,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> T | None:
        """Busca objeto por RID."""
        k = kernel or get_kernel()
        return await k.get(cls, rid=rid)

    @classmethod
    async def find(
        cls: type[T],
        *,
        kernel: UnifiedDataManager | None = None,
        **filters,
    ) -> list[T]:
        """Busca por propriedades (Search Service)."""
        k = kernel or get_kernel()
        return await k.list(cls, **filters)

    @classmethod
    async def mget(
        cls: type[T],
        rids: list[str],
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> list[T]:
        """Busca múltiplos objetos por RIDs em batch."""
        k = kernel or get_kernel()
        if hasattr(k, "mget"):
            return await k.mget(cls, rids=rids)
        
        # Fallback para queries individuais
        results = []
        for rid in rids:
            obj = await k.get(cls, rid=rid)
            if obj:
                results.append(obj)
        return results

    @classmethod
    def get_ddl_constraints(cls) -> dict[str, list[str]]:
        """Exporta constraints como CHECK constraints SQL."""
        ddl = {}
        for field_name, field in cls.model_fields.items():
            extra = field.json_schema_extra
            if not extra or not isinstance(extra, dict):
                continue
            
            constraints_data = extra.get("constraints", [])
            checks = []
            for constraint_dict in constraints_data:
                constraint = reconstruct_constraint(constraint_dict)
                if constraint and hasattr(constraint, "to_sql_check"):
                    check = constraint.to_sql_check(field_name)
                    if check and check != "TRUE":
                        checks.append(check)
            
            if checks:
                ddl[field_name] = checks
        
        return ddl

    @classmethod
    def get_pandera_schema(cls) -> dict[str, list[dict[str, Any]]]:
        """Exporta constraints como configuração Pandera."""
        schema = {}
        for field_name, field in cls.model_fields.items():
            extra = field.json_schema_extra
            if not extra or not isinstance(extra, dict):
                continue
            
            constraints_data = extra.get("constraints", [])
            checks = []
            for constraint_dict in constraints_data:
                constraint = reconstruct_constraint(constraint_dict)
                if constraint and hasattr(constraint, "to_pandera_check"):
                    checks.append(constraint.to_pandera_check())
            
            if checks:
                schema[field_name] = checks
        
        return schema


# ==============================================================================
# 6. VirtualObject (Federação / Helix)
# ==============================================================================


class VirtualObject(Object):
    """Objeto que vive em fonte externa (Postgres, S3, API). Read-only."""

    __source_config__: ClassVar[dict[str, Any]] = {}
    __primary_key__: ClassVar[str] = "id"

    def __init__(self, *, kernel: UnifiedDataManager | None = None, **data):
        # Geração de RID Determinístico para permitir Links sem persistência
        if "rid" not in data and self.__primary_key__ in data:
            pk_val = str(data[self.__primary_key__])
            unique_seed = f"{self.__class__.__name__}:{pk_val}"
            data["rid"] = RID.generate(
                service="external",
                instance="default",
                type_=self.__class__.__name__.lower(),
                locator=str(uuid.uuid5(uuid.NAMESPACE_DNS, unique_seed)),
            )
        super().__init__(kernel=kernel, **data)

    async def save(self, *args, **kwargs) -> "Object":
        raise NotImplementedError("VirtualObject é Read-Only. Use uma Action para Write-Back.")

    @classmethod
    async def query_external(
        cls,
        sql_filter: str = "1=1",
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> list["VirtualObject"]:
        """Query fonte externa federada."""
        k = kernel or get_kernel()
        if not hasattr(k, "query_federated"):
            raise NotImplementedError("Kernel requer suporte a query_federated.")
        raw_data = await k.query_federated(cls.__source_config__, sql_filter)
        return [cls(kernel=kernel, **row) for row in raw_data]


# ==============================================================================
# 7. Archetype (Transaction Wrapper via UnitOfWork)
# ==============================================================================


class ArchetypeValidationError(Exception):
    """
    Erro levantado quando a validação de invariantes do Archetype falha.
    
    Contém detalhes sobre quais invariantes foram violados para
    facilitar debugging e logging estruturado.
    """
    def __init__(self, message: str, violations: list[str] | None = None):
        super().__init__(message)
        self.violations = violations or []


class Archetype(abc.ABC):
    """
    Factory transacional para criar grafos complexos (Domain Transaction).
    
    RFC-002 Enhancements:
    - Integração com malha.UnitOfWork para atomicidade real
    - Hook validate() para verificação de invariantes de domínio
    - Commit só ocorre se validate() retornar True
    
    O Archetype atua como barreira de consistência do domínio,
    garantindo que nunca salvaremos dados órfãos ou estados inválidos.
    
    Exemplo:
        class OrderArchetype(Archetype):
            async def validate(self) -> bool:
                # Pedido deve ter cliente e pelo menos um item
                if not self._has_customer or len(self._items) == 0:
                    raise ArchetypeValidationError(
                        "Pedido inválido",
                        violations=["Pedido requer cliente e itens"]
                    )
                return True
    """

    def __init__(self, *, kernel: UnifiedDataManager | None = None):
        self._kernel = kernel
        self._uow: UnitOfWork | None = None
        # Mantém listas para compatibilidade com código legado
        self._objects: list[Object] = []
        self._links: list[tuple] = []
        # RFC-002: Flag para tracking de validação
        self._validated: bool = False

    def _get_kernel(self) -> UnifiedDataManager:
        """Obtém kernel injetado ou do contexto."""
        if self._kernel is not None:
            return self._kernel
        return get_kernel()

    def _ensure_uow(self) -> UnitOfWork:
        """Garante que UnitOfWork está inicializado."""
        if self._uow is None:
            self._uow = UnitOfWork(self._get_kernel())
        return self._uow

    def add_object(self, obj: T) -> T:
        """Adiciona objeto ao batch."""
        if hasattr(obj, "_before_save"):
            obj._before_save()
        self._objects.append(obj)
        self._ensure_uow().add(obj)
        # Invalida validação anterior quando estado muda
        self._validated = False
        return obj

    def add_link(
        self,
        src: Object,
        label: str,
        dst: Object,
        props: dict[str, Any] | None = None,
    ) -> None:
        """Adiciona link ao batch."""
        self._links.append((src, label, dst, props))
        self._ensure_uow().link(src, label, dst, props)
        # Invalida validação anterior quando estado muda
        self._validated = False

    @abc.abstractmethod
    def build(self, **kwargs) -> Object:
        """Constrói o grafo de objetos. Implementar em subclasses."""
        pass

    async def validate(self) -> bool:
        """
        Hook para validação de invariantes de domínio.
        
        RFC-002: Este método deve ser sobrescrito para implementar
        regras de negócio complexas antes do commit.
        
        Exemplos de invariantes:
        - "Um Pedido não pode existir sem um Cliente"
        - "Um Pedido deve ter pelo menos um Item"
        - "O total do pedido deve ser positivo"
        
        Returns:
            True se todas as invariantes são satisfeitas.
            
        Raises:
            ArchetypeValidationError: Se alguma invariante for violada.
        """
        # Implementação padrão: sempre válido
        # Subclasses devem sobrescrever para adicionar validações
        return True

    async def commit(
        self,
        agent: Any = None,
        *,
        kernel: UnifiedDataManager | None = None,
    ) -> list[Object]:
        """
        Persiste todos os objetos e links atomicamente via UnitOfWork.
        
        RFC-002: Chama validate() antes do commit. Se a validação
        falhar, o commit é abortado e nenhuma alteração é persistida.
        
        Raises:
            ArchetypeValidationError: Se validate() retornar False ou levantar exceção.
        """
        # RFC-002: Validação obrigatória antes do commit
        if not self._validated:
            try:
                is_valid = await self.validate()
                if not is_valid:
                    raise ArchetypeValidationError(
                        f"{self.__class__.__name__}: Validação de invariantes falhou"
                    )
                self._validated = True
            except ArchetypeValidationError:
                # Re-raise validation errors
                raise
            except Exception as e:
                # Wrap outras exceções em ArchetypeValidationError
                raise ArchetypeValidationError(
                    f"{self.__class__.__name__}: Erro durante validação: {e}"
                ) from e
        
        uow = self._ensure_uow()
        res = await uow.commit(agent=agent)
        return [r for r in res if isinstance(r, Object)]

    def clear(self) -> None:
        """Limpa o batch (objetos e links pendentes)."""
        self._objects.clear()
        self._links.clear()
        self._validated = False
        if self._uow:
            self._uow = None


# ==============================================================================
# 8. Logic (Raciocínio Puro / Functions)
# ==============================================================================


class Logic(abc.ABC):
    """
    Unidade de Raciocínio Puro (Stateless) - Pure Tools para Agentes.
    
    RFC-002 Enhancements:
    - InputModel tipado (Pydantic) para schema JSON exato
    - OutputModel tipado para validação de retorno
    - Complexity metadata para estimativa de custo
    
    Diferente de uma Action, uma Logic:
    1. É Read-Only (não altera estado do banco).
    2. É Determinística (mesmo input = mesmo output).
    3. Pode ser exposta como Tool segura para o LLM via PydanticAI.
    
    Exemplo:
        class CalculateDiscount(Logic):
            class Input(BaseModel):
                price: float
                discount_percent: float = Field(ge=0, le=100)
            
            class Output(BaseModel):
                final_price: float
                savings: float
            
            complexity = Complexity.O_1
            
            @classmethod
            def run(cls, input: Input) -> Output:
                savings = input.price * (input.discount_percent / 100)
                return cls.Output(
                    final_price=input.price - savings,
                    savings=savings
                )
    """

    display_name: ClassVar[str] = "Lógica Genérica"
    description: ClassVar[str] = ""
    cacheable: ClassVar[bool] = True
    
    # RFC-002: Complexity metadata para orquestrador
    complexity: ClassVar[Complexity] = Complexity.O_UNKNOWN
    
    # RFC-002: InputModel e OutputModel tipados
    # Subclasses devem definir estas classes internas
    class Input(BaseModel):
        """Schema de entrada padrão (vazio). Sobrescrever em subclasses."""
        pass
    
    class Output(BaseModel):
        """Schema de saída padrão. Sobrescrever em subclasses se necessário."""
        result: Any = None

    @classmethod
    @abc.abstractmethod
    def run(cls, input: "Logic.Input") -> "Logic.Output | Any":
        """
        Executa o cálculo puro.
        
        RFC-002: Método deve ser puramente funcional (sem side effects).
        Recebe um InputModel tipado e retorna OutputModel ou valor simples.
        """
        pass

    @classmethod
    def get_input_schema(cls) -> dict[str, Any]:
        """
        Retorna o JSON Schema do InputModel.
        
        Usado pelo Kinetic Bridge para gerar tool definitions
        compatíveis com PydanticAI e OpenAI Function Calling.
        """
        # Busca a classe Input definida na subclasse
        input_cls = getattr(cls, "Input", Logic.Input)
        return input_cls.model_json_schema()
    
    @classmethod
    def get_output_schema(cls) -> dict[str, Any]:
        """
        Retorna o JSON Schema do OutputModel.
        
        Usado para validação de retorno e documentação.
        """
        output_cls = getattr(cls, "Output", Logic.Output)
        return output_cls.model_json_schema()

    @classmethod
    def get_signature(cls) -> dict[str, Any]:
        """
        Retorna a assinatura completa da Logic para introspecção.
        
        RFC-002: Inclui schemas de Input/Output e complexity.
        """
        sig = inspect.signature(cls.run)
        return {
            "name": cls.__name__,
            "display_name": cls.display_name,
            "description": cls.description or cls.__doc__ or "",
            "cacheable": cls.cacheable,
            # RFC-002: Novos campos
            "complexity": cls.complexity.value if isinstance(cls.complexity, Complexity) else cls.complexity,
            "input_schema": cls.get_input_schema(),
            "output_schema": cls.get_output_schema(),
            # Legacy: mantém parameters para compatibilidade
            "parameters": {
                name: {
                    "annotation": (
                        str(param.annotation)
                        if param.annotation != inspect.Parameter.empty
                        else "Any"
                    ),
                    "default": param.default if param.default != inspect.Parameter.empty else None,
                }
                for name, param in sig.parameters.items()
                if name != "cls"
            },
            "return_type": (
                str(sig.return_annotation)
                if sig.return_annotation != inspect.Signature.empty
                else "Any"
            ),
        }
    
    @classmethod
    def as_tool_definition(cls) -> dict[str, Any]:
        """
        Retorna definição compatível com OpenAI Function Calling / PydanticAI.
        
        RFC-002: Formato pronto para ser registrado como Tool no Kinetic Bridge.
        """
        return {
            "type": "function",
            "function": {
                "name": cls.__name__,
                "description": cls.description or cls.__doc__ or cls.display_name,
                "parameters": cls.get_input_schema(),
            },
            "metadata": {
                "complexity": cls.complexity.value if isinstance(cls.complexity, Complexity) else cls.complexity,
                "cacheable": cls.cacheable,
            },
        }


def logic(
    display_name: str = "",
    cacheable: bool = True,
    complexity: Complexity = Complexity.O_UNKNOWN,
) -> Callable:
    """
    Decorator SotA: Transforma função pura em Logic.
    
    RFC-002: Agora suporta complexity metadata.
    
    Exemplo:
        @logic("Calcular Risco", complexity=Complexity.O_1)
        def calc_risk(score: int) -> float:
            return score / 100.0
    """
    def decorator(func: Callable) -> type[Logic]:
        class Wrapper(Logic):
            pass
        
        Wrapper.display_name = display_name or func.__name__
        Wrapper.description = func.__doc__ or ""
        Wrapper.cacheable = cacheable
        Wrapper.complexity = complexity
        Wrapper.run = staticmethod(func)
        Wrapper.__name__ = func.__name__
        
        return Wrapper
    return decorator
