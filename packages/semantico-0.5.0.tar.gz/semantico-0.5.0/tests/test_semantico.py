"""
Testes abrangentes para o módulo semantico.
Cobertura mínima: 70%
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel
from semantico import (
    CONSTRAINT_REGISTRY,
    Archetype,
    ArchetypeValidationError,
    Cardinality,
    Complexity,
    Criticality,
    Interface,
    Length,
    Link,
    LinkDescriptor,
    LinkManager,
    Logic,
    Object,
    Property,
    Range,
    Regex,
    Sensitivity,
    VirtualObject,
    clear_kernel,
    get_constraint_registry,
    get_kernel,
    logic,
    reconstruct_constraint,
    set_kernel,
)

# ==============================================================================
# Fixtures
# ==============================================================================


@pytest.fixture
def mock_kernel():
    """Mock do UnifiedDataManager (Kernel)."""
    kernel = MagicMock()
    kernel.save_versioned = AsyncMock(side_effect=lambda obj, **_: obj)
    kernel.delete_versioned = AsyncMock()
    kernel.get = AsyncMock(return_value=None)
    kernel.mget = AsyncMock(return_value=[])  # Batch fetch
    kernel.list = AsyncMock(return_value=[])
    kernel.link = AsyncMock()
    kernel.unlink = AsyncMock()
    kernel.graph = MagicMock()
    kernel.graph.query = AsyncMock(return_value=[])
    return kernel


@pytest.fixture
def mock_registry():
    """Mock do registro global."""
    with patch("semantico.core.global_registry") as mock_reg:
        yield mock_reg


# ==============================================================================
# Tests: Constraints
# ==============================================================================


class TestRange:
    """Testes para a constraint Range."""

    def test_range_valid_value_within_bounds(self):
        """Valor dentro dos limites deve passar."""
        constraint = Range(min=0, max=100, error_message="Fora do range")
        constraint.validate(50)  # Não deve levantar exceção

    def test_range_value_at_min_boundary(self):
        """Valor no limite mínimo deve passar."""
        constraint = Range(min=0, max=100)
        constraint.validate(0)

    def test_range_value_at_max_boundary(self):
        """Valor no limite máximo deve passar."""
        constraint = Range(min=0, max=100)
        constraint.validate(100)

    def test_range_value_below_min_raises(self):
        """Valor abaixo do mínimo deve falhar."""
        constraint = Range(min=0, max=100, error_message="Valor muito baixo")
        with pytest.raises(ValueError, match="Valor muito baixo"):
            constraint.validate(-1)

    def test_range_value_above_max_raises(self):
        """Valor acima do máximo deve falhar."""
        constraint = Range(min=0, max=100, error_message="Valor muito alto")
        with pytest.raises(ValueError, match="Valor muito alto"):
            constraint.validate(101)

    def test_range_with_only_min(self):
        """Range apenas com mínimo."""
        constraint = Range(min=10)
        constraint.validate(100)  # OK
        with pytest.raises(ValueError):
            constraint.validate(5)

    def test_range_with_only_max(self):
        """Range apenas com máximo."""
        constraint = Range(max=50)
        constraint.validate(25)  # OK
        with pytest.raises(ValueError):
            constraint.validate(51)

    def test_range_with_float_values(self):
        """Range com valores float."""
        constraint = Range(min=0.5, max=9.9)
        constraint.validate(5.5)
        with pytest.raises(ValueError):
            constraint.validate(0.4)

    def test_range_ignores_non_numeric(self):
        """Range ignora valores não numéricos."""
        constraint = Range(min=0, max=100)
        constraint.validate("not a number")  # Não deve levantar exceção
        constraint.validate(None)
        constraint.validate([1, 2, 3])


class TestRegex:
    """Testes para a constraint Regex."""

    def test_regex_valid_pattern_match(self):
        """String que casa com o padrão deve passar."""
        constraint = Regex(pattern=r"^\d{3}-\d{4}$", error_message="Formato inválido")
        constraint.validate("123-4567")

    def test_regex_invalid_pattern_raises(self):
        """String que não casa deve falhar."""
        constraint = Regex(pattern=r"^\d{3}-\d{4}$", error_message="Formato inválido")
        with pytest.raises(ValueError, match="Formato inválido"):
            constraint.validate("12-34567")

    def test_regex_email_pattern(self):
        """Teste com padrão de email."""
        constraint = Regex(pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$")
        constraint.validate("test@example.com")
        with pytest.raises(ValueError):
            constraint.validate("invalid-email")

    def test_regex_ignores_non_string(self):
        """Regex ignora valores não-string."""
        constraint = Regex(pattern=r"^\d+$")
        constraint.validate(12345)  # Não deve levantar exceção
        constraint.validate(None)

    def test_regex_to_sql_check(self):
        """Regex exporta para SQL CHECK."""
        constraint = Regex(pattern=r"^\d+$")
        sql = constraint.to_sql_check("phone")
        assert "phone ~ '^\\d+$'" in sql

    def test_regex_to_pandera_check(self):
        """Regex exporta para Pandera."""
        constraint = Regex(pattern=r"^\d+$")
        check = constraint.to_pandera_check()
        assert check["check_type"] == "str_matches"
        assert check["pattern"] == r"^\d+$"


class TestLength:
    """Testes para a constraint Length."""

    def test_length_valid_string(self):
        """String dentro dos limites deve passar."""
        constraint = Length(min_length=2, max_length=10)
        constraint.validate("hello")  # 5 chars, OK

    def test_length_at_min_boundary(self):
        """String no limite mínimo deve passar."""
        constraint = Length(min_length=3)
        constraint.validate("abc")

    def test_length_at_max_boundary(self):
        """String no limite máximo deve passar."""
        constraint = Length(max_length=5)
        constraint.validate("12345")

    def test_length_below_min_raises(self):
        """String abaixo do mínimo deve falhar."""
        constraint = Length(min_length=5, error_message="Muito curto")
        with pytest.raises(ValueError, match="Muito curto"):
            constraint.validate("abc")

    def test_length_above_max_raises(self):
        """String acima do máximo deve falhar."""
        constraint = Length(max_length=5, error_message="Muito longo")
        with pytest.raises(ValueError, match="Muito longo"):
            constraint.validate("abcdefgh")

    def test_length_ignores_non_string(self):
        """Length ignora valores não-string."""
        constraint = Length(min_length=5)
        constraint.validate(12345)  # Não deve levantar exceção
        constraint.validate(None)

    def test_length_to_sql_check(self):
        """Length exporta para SQL CHECK."""
        constraint = Length(min_length=2, max_length=10)
        sql = constraint.to_sql_check("name")
        assert "LENGTH(name) >= 2" in sql
        assert "LENGTH(name) <= 10" in sql

    def test_length_to_pandera_check(self):
        """Length exporta para Pandera."""
        constraint = Length(min_length=2, max_length=10)
        check = constraint.to_pandera_check()
        assert check["check_type"] == "str_length"
        assert check["min_value"] == 2
        assert check["max_value"] == 10


class TestRangeDDLExport:
    """Testes para exportação DDL do Range."""

    def test_range_to_sql_check(self):
        """Range exporta para SQL CHECK."""
        constraint = Range(min=0, max=100)
        sql = constraint.to_sql_check("price")
        assert "price >= 0" in sql
        assert "price <= 100" in sql

    def test_range_to_sql_check_only_min(self):
        """Range com apenas min exporta corretamente."""
        constraint = Range(min=0)
        sql = constraint.to_sql_check("value")
        assert "value >= 0" in sql
        assert "<=" not in sql

    def test_range_to_pandera_check(self):
        """Range exporta para Pandera."""
        constraint = Range(min=0, max=100)
        check = constraint.to_pandera_check()
        assert check["check_type"] == "in_range"
        assert check["min_value"] == 0
        assert check["max_value"] == 100


class TestConstraintBase:
    """Testes para a classe base Constraint."""

    def test_constraint_is_abstract(self):
        """Constraint não pode ser instanciada diretamente."""
        # Constraint é ABC, mas podemos testar seus campos default
        range_constraint = Range(min=0)
        assert range_constraint.description == "Regra de validação"
        assert range_constraint.error_message == "Valor inválido"

    def test_constraint_custom_description(self):
        """Constraint com descrição customizada."""
        constraint = Range(
            min=0, max=100, description="Percentual válido", error_message="Deve ser 0-100%"
        )
        assert constraint.description == "Percentual válido"
        assert constraint.error_message == "Deve ser 0-100%"


class TestConstraintReconstruction:
    """Testes para reconstrução de constraints a partir de JSON."""

    def test_constraint_registry_has_all_types(self):
        """Registry contém todos os tipos de constraint."""
        assert "Range" in CONSTRAINT_REGISTRY
        assert "Regex" in CONSTRAINT_REGISTRY
        assert "Length" in CONSTRAINT_REGISTRY
        assert CONSTRAINT_REGISTRY["Range"] is Range
        assert CONSTRAINT_REGISTRY["Regex"] is Regex
        assert CONSTRAINT_REGISTRY["Length"] is Length

    def test_reconstruct_range_constraint(self):
        """Reconstrói Range a partir de dict."""
        data = {"min": 0, "max": 100, "error_message": "Fora do range"}
        constraint = reconstruct_constraint(data)
        assert isinstance(constraint, Range)
        assert constraint.min == 0
        assert constraint.max == 100
        assert constraint.error_message == "Fora do range"

    def test_reconstruct_regex_constraint(self):
        """Reconstrói Regex a partir de dict."""
        data = {"pattern": r"^\d+$", "error_message": "Deve ser número"}
        constraint = reconstruct_constraint(data)
        assert isinstance(constraint, Regex)
        assert constraint.pattern == r"^\d+$"
        assert constraint.error_message == "Deve ser número"

    def test_reconstruct_unknown_returns_none(self):
        """Dict desconhecido retorna None."""
        data = {"unknown_field": "value"}
        constraint = reconstruct_constraint(data)
        assert constraint is None

    def test_reconstruct_range_with_only_min(self):
        """Reconstrói Range apenas com min."""
        data = {"min": 10}
        constraint = reconstruct_constraint(data)
        assert isinstance(constraint, Range)
        assert constraint.min == 10
        assert constraint.max is None

    def test_reconstruct_range_with_only_max(self):
        """Reconstrói Range apenas com max."""
        data = {"max": 100}
        constraint = reconstruct_constraint(data)
        assert isinstance(constraint, Range)
        assert constraint.min is None
        assert constraint.max == 100

    def test_reconstruct_length_constraint(self):
        """Reconstrói Length a partir de dict."""
        data = {"min_length": 2, "max_length": 50}
        constraint = reconstruct_constraint(data)
        assert isinstance(constraint, Length)
        assert constraint.min_length == 2
        assert constraint.max_length == 50


class TestConstraintRegistry:
    """Testes para o registry de constraints serializável."""

    def test_get_constraint_registry_returns_all_types(self):
        """Registry retorna todos os tipos de constraint."""
        registry = get_constraint_registry()
        assert "Range" in registry
        assert "Regex" in registry
        assert "Length" in registry

    def test_get_constraint_registry_has_schema(self):
        """Cada constraint no registry tem schema JSON."""
        registry = get_constraint_registry()
        for name, info in registry.items():
            assert "name" in info
            assert "schema" in info
            assert "fields" in info
            assert info["name"] == name

    def test_get_constraint_registry_range_fields(self):
        """Range tem campos min e max no registry."""
        registry = get_constraint_registry()
        range_info = registry["Range"]
        assert "min" in range_info["fields"]
        assert "max" in range_info["fields"]


class TestDependencyInjection:
    """Testes para o sistema de injeção de dependência via ContextVar."""

    def test_set_and_get_kernel(self):
        """set_kernel e get_kernel funcionam corretamente."""
        mock_kernel = MagicMock()
        set_kernel(mock_kernel)
        try:
            result = get_kernel()
            assert result is mock_kernel
        finally:
            clear_kernel()

    def test_clear_kernel(self):
        """clear_kernel limpa o contexto."""
        mock_kernel = MagicMock()
        set_kernel(mock_kernel)
        clear_kernel()
        # Após clear, deve tentar fallback para malha
        with patch("malha.get_kernel", side_effect=RuntimeError("No kernel")):
            with pytest.raises(RuntimeError):
                get_kernel()

    def test_get_kernel_delegates_to_malha(self):
        """get_kernel delega diretamente para malha.get_kernel."""
        mock_malha_kernel = MagicMock()
        # Patch no módulo semantico.core onde malha_get_kernel é importado
        with patch("semantico.core.malha_get_kernel", return_value=mock_malha_kernel):
            result = get_kernel()
            assert result is mock_malha_kernel


class TestRuntimeConstraintValidation:
    """Testes para validação de constraints em runtime (Fail Fast)."""

    def test_object_validates_range_constraint_on_init(self):
        """Object valida Range constraint na instanciação."""
        with patch("semantico.core.get_kernel"):

            class Product(Object):
                price: float = Property(
                    constraints=[Range(min=0, max=1000, error_message="Preço inválido")]
                )

            # Valor válido - não deve levantar exceção
            product = Product(price=500.0)
            assert product.price == 500.0

    def test_object_raises_on_range_violation(self):
        """Object levanta ValueError quando Range é violado."""
        with patch("semantico.core.get_kernel"):

            class Product(Object):
                price: float = Property(
                    constraints=[Range(min=0, max=1000, error_message="Preço inválido")]
                )

            with pytest.raises(ValueError, match="price.*Preço inválido"):
                Product(price=1500.0)

    def test_object_validates_regex_constraint_on_init(self):
        """Object valida Regex constraint na instanciação."""
        with patch("semantico.core.get_kernel"):

            class User(Object):
                email: str = Property(
                    constraints=[
                        Regex(pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$", error_message="Email inválido")
                    ]
                )

            # Valor válido
            user = User(email="test@example.com")
            assert user.email == "test@example.com"

    def test_object_raises_on_regex_violation(self):
        """Object levanta ValueError quando Regex é violado."""
        with patch("semantico.core.get_kernel"):

            class User(Object):
                email: str = Property(
                    constraints=[
                        Regex(pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$", error_message="Email inválido")
                    ]
                )

            with pytest.raises(ValueError, match="email.*Email inválido"):
                User(email="invalid-email")

    def test_object_validates_multiple_constraints(self):
        """Object valida múltiplas constraints no mesmo campo."""
        with patch("semantico.core.get_kernel"):

            class Score(Object):
                value: int = Property(
                    constraints=[
                        Range(min=0, error_message="Deve ser positivo"),
                        Range(max=100, error_message="Máximo é 100"),
                    ]
                )

            # Valor válido
            score = Score(value=50)
            assert score.value == 50

            # Viola primeira constraint
            with pytest.raises(ValueError, match="Deve ser positivo"):
                Score(value=-10)

            # Viola segunda constraint
            with pytest.raises(ValueError, match="Máximo é 100"):
                Score(value=150)

    def test_object_skips_none_values(self):
        """Object não valida campos None."""
        with patch("semantico.core.get_kernel"):

            class OptionalField(Object):
                value: int | None = Property(
                    required=False, constraints=[Range(min=0, error_message="Deve ser positivo")]
                )

            # None não é validado
            obj = OptionalField(value=None)
            assert obj.value is None

    def test_object_validates_multiple_fields(self):
        """Object valida constraints em múltiplos campos."""
        with patch("semantico.core.get_kernel"):

            class Person(Object):
                age: int = Property(
                    constraints=[Range(min=0, max=150, error_message="Idade inválida")]
                )
                email: str = Property(
                    constraints=[
                        Regex(pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$", error_message="Email inválido")
                    ]
                )

            # Ambos válidos
            person = Person(age=30, email="test@example.com")
            assert person.age == 30
            assert person.email == "test@example.com"

            # Idade inválida
            with pytest.raises(ValueError, match="age.*Idade inválida"):
                Person(age=-5, email="test@example.com")

            # Email inválido
            with pytest.raises(ValueError, match="email.*Email inválido"):
                Person(age=30, email="invalid")


# ==============================================================================
# Tests: Property
# ==============================================================================


class TestProperty:
    """Testes para a função Property."""

    def test_property_default_values(self):
        """Property com valores padrão."""
        field = Property()
        assert field.json_schema_extra["semantic_type"] == "Property"
        assert field.json_schema_extra["title"] is None
        assert field.json_schema_extra["unit"] is None
        assert field.json_schema_extra["constraints"] == []
        assert field.json_schema_extra["is_natural_key"] is False

    def test_property_with_title_and_unit(self):
        """Property com título e unidade."""
        field = Property(title="Temperatura", unit="°C")
        assert field.json_schema_extra["title"] == "Temperatura"
        assert field.json_schema_extra["unit"] == "°C"

    def test_property_with_constraints(self):
        """Property com constraints."""
        constraints = [Range(min=0, max=100), Regex(pattern=r"^\d+$")]
        field = Property(constraints=constraints)
        assert len(field.json_schema_extra["constraints"]) == 2

    def test_property_primary_key(self):
        """Property como chave primária."""
        field = Property(primary_key=True)
        assert field.json_schema_extra["is_natural_key"] is True

    def test_property_not_required_with_no_default(self):
        """Property não requerida sem default deve ter default None."""
        field = Property(required=False)
        assert field.default is None

    def test_property_with_explicit_default(self):
        """Property com default explícito."""
        field = Property(default="valor_padrao")
        assert field.default == "valor_padrao"

    def test_property_with_description(self):
        """Property com descrição."""
        field = Property(description="Campo de teste")
        assert field.description == "Campo de teste"


# ==============================================================================
# Tests: Interface
# ==============================================================================


class TestInterface:
    """Testes para a classe Interface."""

    def test_interface_is_base_model(self):
        """Interface herda de BaseModel."""
        assert issubclass(Interface, BaseModel)

    def test_interface_can_define_properties(self):
        """Interface pode definir propriedades."""

        class Locatable(Interface):
            latitude: float
            longitude: float

        loc = Locatable(latitude=-23.5, longitude=-46.6)
        assert loc.latitude == -23.5
        assert loc.longitude == -46.6

    def test_interface_as_mixin(self):
        """Interface pode ser usada como mixin."""

        class Timestamped(Interface):
            created_at: str
            updated_at: str

        class MyModel(Timestamped):
            name: str

        obj = MyModel(name="test", created_at="2024-01-01", updated_at="2024-01-02")
        assert obj.name == "test"
        assert obj.created_at == "2024-01-01"


# ==============================================================================
# Tests: Link e LinkDescriptor
# ==============================================================================


class TestLinkDescriptor:
    """Testes para LinkDescriptor."""

    def test_link_descriptor_creation(self):
        """Criação de LinkDescriptor."""
        descriptor = LinkDescriptor(label="owns", target="Asset")
        assert descriptor.label == "OWNS"  # Uppercase
        assert descriptor.target == "Asset"
        assert descriptor.inverse is False

    def test_link_descriptor_inverse(self):
        """LinkDescriptor com inverse."""
        descriptor = LinkDescriptor(label="owned_by", target="Owner", inverse=True)
        assert descriptor.inverse is True

    def test_link_function(self):
        """Função Link cria LinkDescriptor."""
        link = Link("manages", target="Team")
        assert isinstance(link, LinkDescriptor)
        assert link.label == "MANAGES"


class TestLinkManager:
    """Testes para LinkManager."""

    def test_link_manager_creation(self):
        """Criação de LinkManager."""
        with patch("semantico.core.get_kernel"):
            # Criar um Object mock
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls="Asset", inverse=False
            )

            assert manager.source == mock_source
            assert manager.label == "OWNS"
            assert manager.inverse is False

    def test_link_manager_target_cls_resolution_string(self):
        """LinkManager resolve target_cls de string."""
        with patch("semantico.core.global_registry") as mock_registry:
            mock_cls = MagicMock()
            mock_registry.get_or_error.return_value = mock_cls

            mock_source = MagicMock(spec=Object)
            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls="Asset", inverse=False
            )

            result = manager.target_cls
            mock_registry.get_or_error.assert_called_once_with("Asset")
            assert result == mock_cls

    def test_link_manager_target_cls_direct_class(self):
        """LinkManager usa classe diretamente."""
        mock_source = MagicMock(spec=Object)

        class MockTarget(Object):
            pass

        manager = LinkManager(
            source=mock_source, label="OWNS", target_cls=MockTarget, inverse=False
        )

        assert manager.target_cls == MockTarget

    @pytest.mark.asyncio
    async def test_link_manager_add(self, mock_kernel):
        """LinkManager.add cria aresta."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.source.1"
            mock_source.to_envelope.return_value = {"rid": "source"}
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.target.1"
            mock_target.to_envelope.return_value = {"rid": "target"}

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            await manager.add(mock_target, props={"weight": 1.0})

            mock_kernel.link.assert_called_once()

    @pytest.mark.asyncio
    async def test_link_manager_add_inverse(self, mock_kernel):
        """LinkManager.add com inverse inverte src/dst."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.source.1"
            mock_source.to_envelope.return_value = {"rid": "source"}
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.target.1"
            mock_target.to_envelope.return_value = {"rid": "target"}

            manager = LinkManager(source=mock_source, label="OWNS", target_cls=Object, inverse=True)

            await manager.add(mock_target)

            # Com inverse=True, target vira src e source vira dst
            call_args = mock_kernel.link.call_args
            assert call_args[0][0] == {"rid": "target"}  # src = target
            assert call_args[0][1] == {"rid": "source"}  # dst = source

    @pytest.mark.asyncio
    async def test_link_manager_remove(self, mock_kernel):
        """LinkManager.remove deleta aresta."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.to_envelope.return_value = {"rid": "source"}
            mock_target = MagicMock(spec=Object)
            mock_target.to_envelope.return_value = {"rid": "target"}

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            await manager.remove(mock_target)

            mock_kernel.unlink.assert_called_once()

    @pytest.mark.asyncio
    async def test_link_manager_all_empty(self, mock_kernel):
        """LinkManager.all retorna lista vazia quando não há conexões."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.all()

            assert result == []

    @pytest.mark.asyncio
    async def test_link_manager_all_with_results(self, mock_kernel):
        """LinkManager.all retorna objetos conectados usando batch fetch."""
        mock_obj = MagicMock(spec=Object)
        # Query retorna RID no formato novo (t.rid)
        mock_kernel.graph.query = AsyncMock(return_value=[{"t.rid": "ri.test.1-1.object.456"}])
        # mget é usado para batch fetch (resolve N+1)
        mock_kernel.mget = AsyncMock(return_value=[mock_obj])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.all()

            assert len(result) == 1
            assert result[0] == mock_obj
            mock_kernel.mget.assert_called_once()

    @pytest.mark.asyncio
    async def test_link_manager_all_inverse_query(self, mock_kernel):
        """LinkManager.all com inverse usa query invertida."""
        mock_kernel.graph.query = AsyncMock(return_value=[])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(source=mock_source, label="OWNS", target_cls=Object, inverse=True)

            await manager.all()

            # Verifica que a query usa direção inversa
            call_args = mock_kernel.graph.query.call_args
            cypher = call_args[0][0]
            assert "(t)-[:OWNS]->(s)" in cypher

    @pytest.mark.asyncio
    async def test_link_manager_all_uses_mget_batch(self, mock_kernel):
        """LinkManager.all usa mget para batch fetch (resolve N+1)."""
        mock_obj1 = MagicMock(spec=Object)
        mock_obj2 = MagicMock(spec=Object)
        mock_kernel.graph.query = AsyncMock(return_value=[
            {"t.rid": "rid1"},
            {"t.rid": "rid2"},
        ])
        mock_kernel.mget = AsyncMock(return_value=[mock_obj1, mock_obj2])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.all()

            # Deve usar mget ao invés de múltiplos get
            mock_kernel.mget.assert_called_once()
            assert len(result) == 2

    @pytest.mark.asyncio
    async def test_link_manager_all_fallback_without_mget(self, mock_kernel):
        """LinkManager.all faz fallback para get individual sem mget."""
        mock_obj = MagicMock(spec=Object)
        mock_kernel.graph.query = AsyncMock(return_value=[
            {"t.rid": "rid1"},
            {"t.rid": "rid2"},
        ])
        mock_kernel.get = AsyncMock(return_value=mock_obj)
        # Remove mget para forçar fallback
        if hasattr(mock_kernel, "mget"):
            delattr(mock_kernel, "mget")

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.all()

            # Deve ter chamado get duas vezes (fallback N+1)
            assert mock_kernel.get.call_count == 2
            assert len(result) == 2

    @pytest.mark.asyncio
    async def test_link_manager_with_explicit_kernel(self, mock_kernel):
        """LinkManager aceita kernel explícito."""
        mock_kernel.graph.query = AsyncMock(return_value=[])

        mock_source = MagicMock(spec=Object)
        mock_source.rid = "ri.test.1-1.object.123"

        manager = LinkManager(
            source=mock_source,
            label="OWNS",
            target_cls=Object,
            inverse=False,
            kernel=mock_kernel,
        )

        await manager.all()

        mock_kernel.graph.query.assert_called_once()

    @pytest.mark.asyncio
    async def test_link_manager_first(self, mock_kernel):
        """LinkManager.first retorna primeiro objeto."""
        mock_obj = MagicMock(spec=Object)
        mock_kernel.graph.query = AsyncMock(return_value=[{"t.rid": "rid1"}])
        mock_kernel.mget = AsyncMock(return_value=[mock_obj])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.first()

            assert result is mock_obj

    @pytest.mark.asyncio
    async def test_link_manager_first_empty(self, mock_kernel):
        """LinkManager.first retorna None quando vazio."""
        mock_kernel.graph.query = AsyncMock(return_value=[])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.first()

            assert result is None

    @pytest.mark.asyncio
    async def test_link_manager_count(self, mock_kernel):
        """LinkManager.count retorna contagem sem carregar objetos."""
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 5}])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.count()

            assert result == 5
            # Verifica que usou COUNT na query
            call_args = mock_kernel.graph.query.call_args
            cypher = call_args[0][0]
            assert "COUNT" in cypher


# ==============================================================================
# Tests: Cardinality
# ==============================================================================


class TestCardinality:
    """Testes para o enum Cardinality e validação de cardinalidade em Links."""

    def test_cardinality_enum_values(self):
        """Cardinality tem os valores corretos."""
        assert Cardinality.ONE_TO_ONE.value == "1:1"
        assert Cardinality.ONE_TO_MANY.value == "1:N"
        assert Cardinality.MANY_TO_ONE.value == "N:1"
        assert Cardinality.MANY_TO_MANY.value == "N:N"

    def test_link_descriptor_with_cardinality(self):
        """LinkDescriptor aceita cardinalidade."""
        descriptor = LinkDescriptor(
            label="spouse",
            target="Person",
            cardinality=Cardinality.ONE_TO_ONE
        )
        assert descriptor.cardinality == Cardinality.ONE_TO_ONE

    def test_link_function_with_cardinality(self):
        """Link() aceita parâmetro cardinality."""
        link = Link("WORKS_IN", target="Department", cardinality=Cardinality.MANY_TO_ONE)
        assert isinstance(link, LinkDescriptor)
        assert link.cardinality == Cardinality.MANY_TO_ONE

    def test_link_manager_has_cardinality(self):
        """LinkManager recebe cardinalidade do descriptor."""
        mock_source = MagicMock(spec=Object)
        mock_source.rid = "ri.test.1-1.object.123"

        manager = LinkManager(
            source=mock_source,
            label="SPOUSE",
            target_cls=Object,
            inverse=False,
            cardinality=Cardinality.ONE_TO_ONE
        )
        assert manager.cardinality == Cardinality.ONE_TO_ONE

    @pytest.mark.asyncio
    async def test_many_to_many_allows_multiple_links(self, mock_kernel):
        """N:N (padrão) permite múltiplos links."""
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 5}])  # Já tem 5 links

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.source.1"
            mock_source.to_envelope.return_value = {"rid": "source"}

            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.target.1"
            mock_target.to_envelope.return_value = {"rid": "target"}

            manager = LinkManager(
                source=mock_source,
                label="ENROLLED",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.MANY_TO_MANY
            )

            # Não deve levantar exceção (N:N permite tudo)
            await manager.add(mock_target)
            mock_kernel.link.assert_called_once()

    @pytest.mark.asyncio
    async def test_one_to_one_blocks_source_with_existing_link(self, mock_kernel):
        """1:1 bloqueia source que já tem link."""
        # count() retorna 1 (source já tem link)
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 1}])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.person.adam"
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.person.lilith"

            manager = LinkManager(
                source=mock_source,
                label="SPOUSE",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.ONE_TO_ONE
            )

            with pytest.raises(ValueError, match="1:1.*violada.*já possui"):
                await manager.add(mock_target)

    @pytest.mark.asyncio
    async def test_one_to_one_blocks_target_already_linked(self, mock_kernel):
        """1:1 bloqueia target que já é destino de outro link."""
        # Primeira query (count source): 0 - source não tem links
        # Segunda query (count target): 1 - target já é destino
        mock_kernel.graph.query = AsyncMock(side_effect=[
            [{"cnt": 0}],  # source count
            [{"cnt": 1}],  # target count
        ])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.person.steve"
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.person.eve"  # Eve já é spouse de Adam

            manager = LinkManager(
                source=mock_source,
                label="SPOUSE",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.ONE_TO_ONE
            )

            with pytest.raises(ValueError, match="1:1.*violada.*já é destino"):
                await manager.add(mock_target)

    @pytest.mark.asyncio
    async def test_many_to_one_blocks_source_with_existing_link(self, mock_kernel):
        """N:1 bloqueia source que já tem link (empregado só pode ter 1 departamento)."""
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 1}])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.employee.1"
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.department.ti"

            manager = LinkManager(
                source=mock_source,
                label="WORKS_IN",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.MANY_TO_ONE
            )

            with pytest.raises(ValueError, match="N:1.*violada.*já possui"):
                await manager.add(mock_target)

    @pytest.mark.asyncio
    async def test_many_to_one_allows_multiple_sources_to_same_target(self, mock_kernel):
        """N:1 permite múltiplos sources apontando para o mesmo target."""
        # count() retorna 0 (source não tem link ainda)
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 0}])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.employee.1"
            mock_source.to_envelope.return_value = {"rid": "emp1"}

            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.department.rh"  # RH já tem outros empregados
            mock_target.to_envelope.return_value = {"rid": "rh"}

            manager = LinkManager(
                source=mock_source,
                label="WORKS_IN",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.MANY_TO_ONE
            )

            # Não deve levantar exceção (N:1 não valida target)
            await manager.add(mock_target)
            mock_kernel.link.assert_called_once()

    @pytest.mark.asyncio
    async def test_one_to_many_blocks_target_already_linked(self, mock_kernel):
        """1:N bloqueia target que já é destino de outro link (subordinado só tem 1 gerente)."""
        # 1:N só valida target (não valida source), então apenas uma query é feita
        # target count: 1 (subordinado já tem gerente)
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 1}])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.manager.boss2"
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.employee.emp1"  # emp1 já tem gerente

            manager = LinkManager(
                source=mock_source,
                label="MANAGES",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.ONE_TO_MANY
            )

            with pytest.raises(ValueError, match="1:N.*violada.*já é destino"):
                await manager.add(mock_target)

    @pytest.mark.asyncio
    async def test_one_to_many_allows_source_to_link_multiple_targets(self, mock_kernel):
        """1:N permite source linkar múltiplos targets."""
        # target count: 0 (target ainda não tem links recebidos)
        mock_kernel.graph.query = AsyncMock(return_value=[{"cnt": 0}])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.manager.boss"
            mock_source.to_envelope.return_value = {"rid": "boss"}

            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.employee.emp2"
            mock_target.to_envelope.return_value = {"rid": "emp2"}

            manager = LinkManager(
                source=mock_source,
                label="MANAGES",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.ONE_TO_MANY
            )

            # Não deve levantar exceção (1:N não valida source)
            await manager.add(mock_target)
            mock_kernel.link.assert_called_once()

    @pytest.mark.asyncio
    async def test_add_validates_objects_have_rid(self, mock_kernel):
        """add() valida que objetos foram salvos (têm RID)."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = None  # Não salvo
            mock_target = MagicMock(spec=Object)
            mock_target.rid = "ri.test.1-1.target.1"

            manager = LinkManager(
                source=mock_source,
                label="OWNS",
                target_cls=Object,
                inverse=False,
                cardinality=Cardinality.MANY_TO_MANY
            )

            with pytest.raises(ValueError, match="devem ser salvos"):
                await manager.add(mock_target)


# ==============================================================================
# Tests: Object
# ==============================================================================


class TestObject:
    """Testes para a classe Object."""

    def test_object_creation(self):
        """Criação básica de Object."""
        with patch("semantico.core.get_kernel"):

            class TestObj(Object):
                name: str = Property()

            obj = TestObj(name="test")
            assert obj.name == "test"

    def test_object_has_rid(self):
        """Object tem RID."""
        with patch("semantico.core.get_kernel"):

            class TestObj(Object):
                name: str = Property()

            obj = TestObj(name="test")
            assert hasattr(obj, "rid")

    @pytest.mark.asyncio
    async def test_object_save(self, mock_kernel):
        """Object.save persiste no kernel."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            obj = TestObj(name="test")
            result = await obj.save()

            mock_kernel.save_versioned.assert_called_once()
            assert result == obj

    @pytest.mark.asyncio
    async def test_object_save_with_agent(self, mock_kernel):
        """Object.save com agent."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            obj = TestObj(name="test")
            agent = MagicMock()
            await obj.save(agent=agent)

            call_args = mock_kernel.save_versioned.call_args
            assert call_args[1]["agent"] == agent

    @pytest.mark.asyncio
    async def test_object_delete(self, mock_kernel):
        """Object.delete faz soft-delete."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            obj = TestObj(name="test")
            await obj.delete()

            mock_kernel.delete_versioned.assert_called_once()

    @pytest.mark.asyncio
    async def test_object_get(self, mock_kernel):
        """Object.get busca por RID."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            await TestObj.get("ri.test.1-1.object.123")

            mock_kernel.get.assert_called_once()

    @pytest.mark.asyncio
    async def test_object_find(self, mock_kernel):
        """Object.find busca por filtros."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            await TestObj.find(name="test")

            mock_kernel.list.assert_called_once()

    def test_object_with_kernel_injection(self, mock_kernel):
        """Object aceita kernel injetado no construtor."""

        class TestObj(Object):
            name: str = Property()

        obj = TestObj(name="test", kernel=mock_kernel)
        assert obj._injected_kernel is mock_kernel

    def test_object_with_kernel_method(self, mock_kernel):
        """Object.with_kernel injeta kernel após criação."""

        class TestObj(Object):
            name: str = Property()

        obj = TestObj(name="test")
        result = obj.with_kernel(mock_kernel)
        assert result is obj
        assert obj._injected_kernel is mock_kernel

    @pytest.mark.asyncio
    async def test_object_save_with_explicit_kernel(self, mock_kernel):
        """Object.save aceita kernel explícito."""

        class TestObj(Object):
            name: str = Property()

        obj = TestObj(name="test")
        await obj.save(kernel=mock_kernel)

        mock_kernel.save_versioned.assert_called_once()

    @pytest.mark.asyncio
    async def test_object_before_save_validates_constraints(self, mock_kernel):
        """Object._before_save re-valida constraints."""

        class Product(Object):
            price: float = Property(
                constraints=[Range(min=0, max=1000, error_message="Preço inválido")]
            )

        product = Product(price=500.0)
        # Modifica valor após instanciação
        product.price = 1500.0

        # save() deve falhar devido ao before_save
        with pytest.raises(ValueError, match="Preço inválido"):
            await product.save(kernel=mock_kernel)

    def test_object_get_ddl_constraints(self):
        """Object.get_ddl_constraints exporta constraints como SQL."""

        class Product(Object):
            price: float = Property(
                constraints=[Range(min=0, max=1000)]
            )
            name: str = Property(
                constraints=[Length(min_length=2, max_length=100)]
            )

        ddl = Product.get_ddl_constraints()
        assert "price" in ddl
        assert any("price >= 0" in check for check in ddl["price"])
        assert "name" in ddl
        assert any("LENGTH(name)" in check for check in ddl["name"])

    def test_object_get_pandera_schema(self):
        """Object.get_pandera_schema exporta constraints como Pandera config."""

        class Product(Object):
            price: float = Property(
                constraints=[Range(min=0, max=1000)]
            )

        schema = Product.get_pandera_schema()
        assert "price" in schema
        assert schema["price"][0]["check_type"] == "in_range"

    @pytest.mark.asyncio
    async def test_object_mget_with_kernel_support(self, mock_kernel):
        """Object.mget usa kernel.mget quando disponível."""
        mock_kernel.mget = AsyncMock(return_value=[])

        class TestObj(Object):
            name: str = Property()

        await TestObj.mget(["rid1", "rid2"], kernel=mock_kernel)

        mock_kernel.mget.assert_called_once()

    @pytest.mark.asyncio
    async def test_object_mget_fallback(self, mock_kernel):
        """Object.mget faz fallback para get individual."""
        # Remove mget para forçar fallback
        if hasattr(mock_kernel, "mget"):
            delattr(mock_kernel, "mget")

        class TestObj(Object):
            name: str = Property()

        await TestObj.mget(["rid1", "rid2"], kernel=mock_kernel)

        # Deve ter chamado get duas vezes
        assert mock_kernel.get.call_count == 2


# ==============================================================================
# Tests: VirtualObject
# ==============================================================================


class TestVirtualObject:
    """Testes para a classe VirtualObject."""

    def test_virtual_object_inherits_from_object(self):
        """VirtualObject herda de Object."""
        assert issubclass(VirtualObject, Object)

    def test_virtual_object_has_source_config(self):
        """VirtualObject tem __source_config__ como ClassVar."""
        assert hasattr(VirtualObject, "__source_config__")
        assert VirtualObject.__source_config__ == {}

    def test_virtual_object_has_primary_key(self):
        """VirtualObject tem __primary_key__ como ClassVar."""
        assert hasattr(VirtualObject, "__primary_key__")
        assert VirtualObject.__primary_key__ == "id"

    @pytest.mark.asyncio
    async def test_virtual_object_save_raises(self):
        """VirtualObject.save levanta NotImplementedError."""
        with patch("semantico.core.get_kernel"):
            # Criar VirtualObject com RID explícito para evitar geração
            class ExternalUser(VirtualObject):
                __primary_key__: str = "user_id"
                user_id: str = Property(primary_key=True)

            # Passar RID explícito para evitar geração automática
            obj = ExternalUser(
                rid="ri.external.1-1.user.01JDTEST00000000000000001", user_id="abc123"
            )

            with pytest.raises(NotImplementedError, match="Read-Only"):
                await obj.save()

    @pytest.mark.asyncio
    async def test_virtual_object_query_external_not_implemented(self):
        """VirtualObject.query_external sem suporte no kernel."""
        # Criar kernel mock sem query_federated
        kernel_without_federated = MagicMock(spec=[])  # spec vazio = sem atributos

        with patch("semantico.core.get_kernel", return_value=kernel_without_federated):

            class ExternalUser(VirtualObject):
                __primary_key__: str = "user_id"
                user_id: str = Property(primary_key=True)

            with pytest.raises(NotImplementedError, match="query_federated"):
                await ExternalUser.query_external()

    @pytest.mark.asyncio
    async def test_virtual_object_query_external_with_support(self, mock_kernel):
        """VirtualObject.query_external com suporte no kernel."""
        mock_kernel.query_federated = AsyncMock(return_value=[{"user_id": "abc", "name": "Test"}])

        with (
            patch("semantico.core.get_kernel", return_value=mock_kernel),
            patch("semantico.core.RID.generate") as mock_rid,
        ):
            mock_rid.return_value = "ri.external.1-1.externaluser.01JDTEST00000000000000001"

            class ExternalUser(VirtualObject):
                __source_config__ = {"connection": "postgres://..."}
                __primary_key__: str = "user_id"
                user_id: str = Property(primary_key=True)
                name: str = Property(required=False)

            results = await ExternalUser.query_external("user_id = 'abc'")

            assert len(results) == 1
            assert results[0].user_id == "abc"


# ==============================================================================
# Tests: Archetype
# ==============================================================================


class TestArchetype:
    """Testes para a classe Archetype."""

    def test_archetype_is_abstract(self):
        """Archetype é abstrato e requer implementação de build."""
        with pytest.raises(TypeError):
            Archetype()

    def test_archetype_add_object(self):
        """Archetype.add_object adiciona objeto à lista."""
        with patch("semantico.core.get_kernel"):

            class TestObj(Object):
                name: str = Property()

            class TestArchetype(Archetype):
                def build(self, **kwargs) -> Object:
                    obj = TestObj(name=kwargs.get("name", "default"))
                    return self.add_object(obj)

            archetype = TestArchetype()
            obj = archetype.build(name="test")

            assert len(archetype._objects) == 1
            assert archetype._objects[0] == obj

    def test_archetype_add_link(self):
        """Archetype.add_link adiciona link à lista."""
        with patch("semantico.core.get_kernel"):

            class TestObj(Object):
                name: str = Property()

            class TestArchetype(Archetype):
                def build(self, **kwargs) -> Object:
                    obj1 = self.add_object(TestObj(name="obj1"))
                    obj2 = self.add_object(TestObj(name="obj2"))
                    self.add_link(obj1, "RELATES_TO", obj2, {"weight": 1.0})
                    return obj1

            archetype = TestArchetype()
            archetype.build()

            assert len(archetype._links) == 1
            src, label, dst, props = archetype._links[0]
            assert label == "RELATES_TO"
            assert props == {"weight": 1.0}

    @pytest.mark.asyncio
    async def test_archetype_commit(self, mock_kernel):
        """Archetype.commit persiste objetos e links."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            class TestArchetype(Archetype):
                def build(self, **kwargs) -> Object:
                    obj1 = self.add_object(TestObj(name="obj1"))
                    obj2 = self.add_object(TestObj(name="obj2"))
                    self.add_link(obj1, "RELATES_TO", obj2)
                    return obj1

            archetype = TestArchetype()
            archetype.build()

            # Mock to_envelope para os objetos
            for obj in archetype._objects:
                obj.to_envelope = MagicMock(return_value={"rid": obj.rid})

            saved = await archetype.commit()

            assert len(saved) == 2
            assert mock_kernel.save_versioned.call_count == 2
            assert mock_kernel.link.call_count == 1

    @pytest.mark.asyncio
    async def test_archetype_commit_with_agent(self, mock_kernel):
        """Archetype.commit passa agent para save_versioned."""
        with patch("semantico.core.get_kernel", return_value=mock_kernel):

            class TestObj(Object):
                name: str = Property()

            class TestArchetype(Archetype):
                def build(self, **kwargs) -> Object:
                    return self.add_object(TestObj(name="test"))

            archetype = TestArchetype()
            archetype.build()

            agent = MagicMock()
            await archetype.commit(agent=agent)

            call_args = mock_kernel.save_versioned.call_args
            assert call_args[1]["agent"] == agent


# ==============================================================================
# Tests: Integration / Edge Cases
# ==============================================================================


class TestIntegration:
    """Testes de integração e casos de borda."""

    def test_object_with_link_descriptor(self):
        """Object com LinkDescriptor funciona corretamente."""
        with patch("semantico.core.get_kernel"):
            # Definir classes fora do contexto para evitar problemas de escopo
            descriptor = LinkDescriptor(label="OWNS", target="Asset")

            # Testar que o descriptor é criado corretamente
            assert descriptor.label == "OWNS"
            assert descriptor.target == "Asset"
            assert descriptor.inverse is False

            # Testar Link function
            link = Link("MANAGES", target="Team")
            assert isinstance(link, LinkDescriptor)
            assert link.label == "MANAGES"

    def test_constraint_serialization(self):
        """Constraints são serializáveis."""
        constraint = Range(min=0, max=100, description="Percentual")
        data = constraint.model_dump()

        assert data["min"] == 0
        assert data["max"] == 100
        assert data["description"] == "Percentual"

    def test_property_constraints_in_schema(self):
        """Constraints são incluídas no schema da Property."""
        constraints = [Range(min=0, max=100)]
        field = Property(constraints=constraints)

        schema_constraints = field.json_schema_extra["constraints"]
        assert len(schema_constraints) == 1
        assert schema_constraints[0]["min"] == 0
        assert schema_constraints[0]["max"] == 100

    def test_object_validate_constraints_called(self):
        """_validate_constraints é chamado na inicialização."""
        with patch("semantico.core.get_kernel"):

            class TestObj(Object):
                value: int = Property()

            # Não deve levantar exceção
            obj = TestObj(value=50)
            assert obj.value == 50

    def test_virtual_object_with_explicit_rid(self):
        """VirtualObject aceita RID explícito."""
        with patch("semantico.core.get_kernel"):

            class ExternalUser(VirtualObject):
                __primary_key__: str = "user_id"
                user_id: str = Property(primary_key=True)

            # Usar formato ULID válido para o locator
            explicit_rid = "ri.external.1-1.user.01JDTEST00000000000000001"
            obj = ExternalUser(rid=explicit_rid, user_id="abc123")

            assert obj.rid == explicit_rid

    @pytest.mark.asyncio
    async def test_link_manager_all_handles_missing_rid(self, mock_kernel):
        """LinkManager.all ignora resultados sem RID."""
        # Query retorna um resultado sem RID e outro com RID
        mock_kernel.graph.query = AsyncMock(
            return_value=[{"t": {}}, {"t.rid": "ri.test.1-1.object.456"}]  # Sem RID no primeiro
        )
        mock_obj = MagicMock(spec=Object)
        # mget é chamado apenas com o RID válido
        mock_kernel.mget = AsyncMock(return_value=[mock_obj])

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.all()

            # Apenas 1 resultado (o que tem RID)
            assert len(result) == 1
            # Verifica que mget foi chamado apenas com o RID válido
            mock_kernel.mget.assert_called_once()

    @pytest.mark.asyncio
    async def test_link_manager_all_handles_none_from_get(self, mock_kernel):
        """LinkManager.all ignora objetos não encontrados."""
        mock_kernel.graph.query = AsyncMock(return_value=[{"t": {"rid": "ri.test.1-1.object.456"}}])
        mock_kernel.get = AsyncMock(return_value=None)  # Objeto não encontrado

        with patch("semantico.core.get_kernel", return_value=mock_kernel):
            mock_source = MagicMock(spec=Object)
            mock_source.rid = "ri.test.1-1.object.123"

            manager = LinkManager(
                source=mock_source, label="OWNS", target_cls=Object, inverse=False
            )

            result = await manager.all()

            assert len(result) == 0


# ==============================================================================
# Tests: Logic
# ==============================================================================


class TestLogic:
    """Testes para a classe Logic."""

    def test_logic_is_abstract(self):
        """Logic é abstrato e requer implementação de run."""
        with pytest.raises(TypeError):
            Logic()

    def test_logic_subclass_must_implement_run(self):
        """Subclasse de Logic deve implementar run."""

        class IncompleteLogic(Logic):
            pass

        with pytest.raises(TypeError):
            IncompleteLogic()

    def test_logic_concrete_implementation(self):
        """Logic concreta pode ser instanciada e executada."""

        class AddNumbers(Logic):
            display_name = "Somar Números"
            description = "Soma dois números"

            @classmethod
            def run(cls, a: int, b: int) -> int:
                return a + b

        # Logic não precisa ser instanciada para executar
        result = AddNumbers.run(2, 3)
        assert result == 5

    def test_logic_default_class_vars(self):
        """Logic tem valores padrão para ClassVars."""

        class SimpleLogic(Logic):
            @classmethod
            def run(cls) -> None:
                pass

        assert SimpleLogic.display_name == "Lógica Genérica"
        assert SimpleLogic.description == ""
        assert SimpleLogic.cacheable is True

    def test_logic_custom_class_vars(self):
        """Logic permite customizar ClassVars."""

        class CustomLogic(Logic):
            display_name = "Lógica Customizada"
            description = "Uma lógica com descrição"
            cacheable = False

            @classmethod
            def run(cls) -> None:
                pass

        assert CustomLogic.display_name == "Lógica Customizada"
        assert CustomLogic.description == "Uma lógica com descrição"
        assert CustomLogic.cacheable is False

    def test_logic_get_signature(self):
        """Logic.get_signature retorna metadados da função."""

        class CalculateArea(Logic):
            display_name = "Calcular Área"
            description = "Calcula área de um retângulo"

            @classmethod
            def run(cls, width: float, height: float) -> float:
                return width * height

        sig = CalculateArea.get_signature()

        assert sig["name"] == "CalculateArea"
        assert sig["display_name"] == "Calcular Área"
        assert sig["description"] == "Calcula área de um retângulo"
        assert sig["cacheable"] is True
        assert "width" in sig["parameters"]
        assert "height" in sig["parameters"]
        assert "float" in sig["parameters"]["width"]["annotation"]
        assert "float" in sig["return_type"]

    def test_logic_get_signature_with_defaults(self):
        """Logic.get_signature captura valores padrão."""

        class Greet(Logic):
            @classmethod
            def run(cls, name: str, greeting: str = "Hello") -> str:
                return f"{greeting}, {name}!"

        sig = Greet.get_signature()

        assert sig["parameters"]["name"]["default"] is None
        assert sig["parameters"]["greeting"]["default"] == "Hello"

    def test_logic_get_signature_uses_docstring_as_fallback(self):
        """Logic.get_signature usa docstring se description vazio."""

        class DocumentedLogic(Logic):
            """Esta é a documentação da lógica."""

            @classmethod
            def run(cls) -> None:
                pass

        sig = DocumentedLogic.get_signature()
        assert "Esta é a documentação da lógica" in sig["description"]

    def test_logic_deterministic(self):
        """Logic deve ser determinística (mesmo input = mesmo output)."""

        class Square(Logic):
            @classmethod
            def run(cls, x: int) -> int:
                return x * x

        # Múltiplas chamadas com mesmo input devem retornar mesmo output
        assert Square.run(5) == 25
        assert Square.run(5) == 25
        assert Square.run(5) == Square.run(5)

    def test_logic_complex_calculation(self):
        """Logic pode fazer cálculos complexos."""
        import math

        class EuclideanDistance(Logic):
            display_name = "Distância Euclidiana"
            description = "Calcula distância linear em espaço 3D"

            @classmethod
            def run(cls, vec_a: list[float], vec_b: list[float]) -> float:
                return math.sqrt(sum((a - b) ** 2 for a, b in zip(vec_a, vec_b, strict=True)))

        result = EuclideanDistance.run([0, 0, 0], [3, 4, 0])
        assert result == 5.0

    def test_logic_with_object_input(self):
        """Logic pode receber Objects como input."""
        with patch("semantico.core.get_kernel"):

            class Person(Object):
                birth_year: int = Property()

            class CalculateAge(Logic):
                display_name = "Calcular Idade"

                @classmethod
                def run(cls, person: Person, current_year: int = 2024) -> int:
                    return current_year - person.birth_year

            person = Person(birth_year=1990)
            age = CalculateAge.run(person, current_year=2024)
            assert age == 34

    def test_logic_no_side_effects(self):
        """Logic não deve ter efeitos colaterais."""
        counter = {"value": 0}

        class PureLogic(Logic):
            @classmethod
            def run(cls, x: int) -> int:
                # Isso é um anti-pattern, mas testamos que Logic não impede
                # O contrato é que o desenvolvedor não faça isso
                return x * 2

        # A lógica deve apenas retornar um valor, não modificar estado externo
        result = PureLogic.run(5)
        assert result == 10
        assert counter["value"] == 0  # Contador não foi modificado


# ==============================================================================
# RFC-002: Testes de Semantic Tagging (Property 2.0)
# ==============================================================================


class TestPropertySemanticTagging:
    """Testes para RFC-002 Tarefa A: Property com metadados de governança."""

    def test_property_default_sensitivity_is_internal(self):
        """Property sem sensitivity explícita deve ser INTERNAL."""
        field = Property()
        security = field.json_schema_extra.get("security", {})
        assert security["sensitivity"] == "INTERNAL"

    def test_property_default_criticality_is_low(self):
        """Property sem criticality explícita deve ser LOW."""
        field = Property()
        security = field.json_schema_extra.get("security", {})
        assert security["criticality"] == "LOW"

    def test_property_default_immutable_is_false(self):
        """Property sem immutable explícito deve ser False."""
        field = Property()
        security = field.json_schema_extra.get("security", {})
        assert security["immutable"] is False

    def test_property_with_sensitivity_public(self):
        """Property com sensitivity PUBLIC."""
        field = Property(sensitivity=Sensitivity.PUBLIC)
        security = field.json_schema_extra.get("security", {})
        assert security["sensitivity"] == "PUBLIC"

    def test_property_with_sensitivity_secret(self):
        """Property com sensitivity SECRET (PII/PHI)."""
        field = Property(sensitivity=Sensitivity.SECRET)
        security = field.json_schema_extra.get("security", {})
        assert security["sensitivity"] == "SECRET"

    def test_property_with_sensitivity_as_string(self):
        """Property aceita sensitivity como string."""
        field = Property(sensitivity="CONFIDENTIAL")
        security = field.json_schema_extra.get("security", {})
        assert security["sensitivity"] == "CONFIDENTIAL"

    def test_property_with_criticality_high(self):
        """Property com criticality HIGH."""
        field = Property(criticality=Criticality.HIGH)
        security = field.json_schema_extra.get("security", {})
        assert security["criticality"] == "HIGH"

    def test_property_with_criticality_as_string(self):
        """Property aceita criticality como string."""
        field = Property(criticality="MEDIUM")
        security = field.json_schema_extra.get("security", {})
        assert security["criticality"] == "MEDIUM"

    def test_property_with_immutable_true(self):
        """Property com immutable=True."""
        field = Property(immutable=True)
        security = field.json_schema_extra.get("security", {})
        assert security["immutable"] is True

    def test_property_full_security_metadata(self):
        """Property com todos os metadados de segurança."""
        field = Property(
            sensitivity=Sensitivity.SECRET,
            criticality=Criticality.HIGH,
            immutable=True,
        )
        security = field.json_schema_extra.get("security", {})
        assert security["sensitivity"] == "SECRET"
        assert security["criticality"] == "HIGH"
        assert security["immutable"] is True

    def test_user_model_ssn_has_security_metadata(self):
        """DoD: User.model_fields['ssn'].json_schema_extra contém dados de sensibilidade."""
        with patch("semantico.core.get_kernel"):

            class User(Object):
                name: str = Property(sensitivity=Sensitivity.PUBLIC)
                ssn: str = Property(sensitivity=Sensitivity.SECRET, immutable=True)

            # Verificar que os metadados estão acessíveis via model_fields
            ssn_field = User.model_fields["ssn"]
            security = ssn_field.json_schema_extra.get("security", {})
            
            assert security["sensitivity"] == "SECRET"
            assert security["immutable"] is True

            name_field = User.model_fields["name"]
            name_security = name_field.json_schema_extra.get("security", {})
            assert name_security["sensitivity"] == "PUBLIC"

    def test_sensitivity_enum_values(self):
        """Sensitivity enum tem todos os valores esperados."""
        assert Sensitivity.PUBLIC.value == "PUBLIC"
        assert Sensitivity.INTERNAL.value == "INTERNAL"
        assert Sensitivity.CONFIDENTIAL.value == "CONFIDENTIAL"
        assert Sensitivity.SECRET.value == "SECRET"

    def test_criticality_enum_values(self):
        """Criticality enum tem todos os valores esperados."""
        assert Criticality.LOW.value == "LOW"
        assert Criticality.MEDIUM.value == "MEDIUM"
        assert Criticality.HIGH.value == "HIGH"


# ==============================================================================
# RFC-002: Testes de Archetype Validation
# ==============================================================================


class TestArchetypeValidation:
    """Testes para RFC-002 Tarefa B: Archetype com validate() hook."""

    @pytest.mark.asyncio
    async def test_archetype_validate_default_returns_true(self, mock_kernel):
        """Archetype.validate() padrão retorna True."""

        class SimpleArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

        archetype = SimpleArchetype(kernel=mock_kernel)
        result = await archetype.validate()
        assert result is True

    @pytest.mark.asyncio
    async def test_archetype_commit_calls_validate(self, mock_kernel):
        """Archetype.commit() chama validate() antes do UoW.commit()."""
        mock_kernel.save_versioned = AsyncMock(side_effect=lambda obj, **_: obj)
        
        validate_called = {"count": 0}

        class ValidatingArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

            async def validate(self) -> bool:
                validate_called["count"] += 1
                return True

        archetype = ValidatingArchetype(kernel=mock_kernel)
        await archetype.commit()

        assert validate_called["count"] == 1

    @pytest.mark.asyncio
    async def test_archetype_validation_failure_prevents_commit(self, mock_kernel):
        """DoD: Archetype que falha na validação impede uow.commit()."""
        uow_commit_called = {"count": 0}
        
        # Mock UnitOfWork
        mock_uow = MagicMock()
        async def mock_commit(**kwargs):
            uow_commit_called["count"] += 1
            return []
        mock_uow.commit = mock_commit

        class FailingArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

            async def validate(self) -> bool:
                raise ArchetypeValidationError(
                    "Pedido inválido",
                    violations=["Pedido requer cliente e itens"]
                )

        archetype = FailingArchetype(kernel=mock_kernel)
        archetype._uow = mock_uow

        with pytest.raises(ArchetypeValidationError) as exc_info:
            await archetype.commit()

        assert "Pedido inválido" in str(exc_info.value)
        assert exc_info.value.violations == ["Pedido requer cliente e itens"]
        # UoW.commit() NÃO deve ter sido chamado
        assert uow_commit_called["count"] == 0

    @pytest.mark.asyncio
    async def test_archetype_validation_false_raises_error(self, mock_kernel):
        """Archetype que retorna False em validate() levanta ArchetypeValidationError."""

        class FalseValidationArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

            async def validate(self) -> bool:
                return False

        archetype = FalseValidationArchetype(kernel=mock_kernel)

        with pytest.raises(ArchetypeValidationError) as exc_info:
            await archetype.commit()

        assert "Validação de invariantes falhou" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_archetype_add_object_invalidates_validation(self, mock_kernel):
        """Adicionar objeto invalida validação anterior."""

        class TrackingArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

        archetype = TrackingArchetype(kernel=mock_kernel)
        
        # Força validação
        archetype._validated = True
        assert archetype._validated is True

        # Adiciona objeto
        mock_obj = MagicMock(spec=Object)
        mock_obj._before_save = MagicMock()
        archetype.add_object(mock_obj)

        # Validação deve ter sido invalidada
        assert archetype._validated is False

    @pytest.mark.asyncio
    async def test_archetype_add_link_invalidates_validation(self, mock_kernel):
        """Adicionar link invalida validação anterior."""

        class TrackingArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

        archetype = TrackingArchetype(kernel=mock_kernel)
        
        # Força validação
        archetype._validated = True

        # Adiciona link
        src = MagicMock(spec=Object)
        dst = MagicMock(spec=Object)
        archetype.add_link(src, "OWNS", dst)

        # Validação deve ter sido invalidada
        assert archetype._validated is False

    @pytest.mark.asyncio
    async def test_archetype_clear_resets_validation(self, mock_kernel):
        """Clear reseta flag de validação."""

        class TrackingArchetype(Archetype):
            def build(self, **kwargs) -> Object:
                return MagicMock(spec=Object)

        archetype = TrackingArchetype(kernel=mock_kernel)
        archetype._validated = True

        archetype.clear()

        assert archetype._validated is False

    def test_archetype_validation_error_has_violations(self):
        """ArchetypeValidationError armazena lista de violações."""
        error = ArchetypeValidationError(
            "Múltiplas violações",
            violations=["Regra 1 violada", "Regra 2 violada"]
        )
        assert len(error.violations) == 2
        assert "Regra 1 violada" in error.violations


# ==============================================================================
# RFC-002: Testes de Logic Estruturada
# ==============================================================================


class TestLogicStructured:
    """Testes para RFC-002 Tarefa C: Logic com InputModel e Complexity."""

    def test_logic_has_complexity_attribute(self):
        """Logic tem atributo complexity."""
        assert hasattr(Logic, "complexity")
        assert Logic.complexity == Complexity.O_UNKNOWN

    def test_logic_has_input_class(self):
        """Logic tem classe Input interna."""
        assert hasattr(Logic, "Input")
        assert issubclass(Logic.Input, BaseModel)

    def test_logic_has_output_class(self):
        """Logic tem classe Output interna."""
        assert hasattr(Logic, "Output")
        assert issubclass(Logic.Output, BaseModel)

    def test_logic_get_input_schema(self):
        """Logic.get_input_schema() retorna JSON Schema."""
        schema = Logic.get_input_schema()
        assert isinstance(schema, dict)
        assert "type" in schema or "properties" in schema or "$defs" in schema or "title" in schema

    def test_logic_get_output_schema(self):
        """Logic.get_output_schema() retorna JSON Schema."""
        schema = Logic.get_output_schema()
        assert isinstance(schema, dict)

    def test_calculate_discount_example(self):
        """DoD: Implementação de CalculateDiscount com InputModel funciona."""
        from pydantic import Field as PydanticField

        class CalculateDiscount(Logic):
            """Calcula desconto em um preço."""
            display_name = "Calcular Desconto"
            complexity = Complexity.O_1

            class Input(BaseModel):
                price: float
                discount_percent: float = PydanticField(ge=0, le=100)

            class Output(BaseModel):
                final_price: float
                savings: float

            @classmethod
            def run(cls, input: "CalculateDiscount.Input") -> "CalculateDiscount.Output":
                savings = input.price * (input.discount_percent / 100)
                return cls.Output(
                    final_price=input.price - savings,
                    savings=savings
                )

        # Teste de execução
        input_data = CalculateDiscount.Input(price=100.0, discount_percent=20.0)
        result = CalculateDiscount.run(input_data)

        assert result.final_price == 80.0
        assert result.savings == 20.0

        # Teste de schema
        input_schema = CalculateDiscount.get_input_schema()
        assert "price" in input_schema.get("properties", {})
        assert "discount_percent" in input_schema.get("properties", {})

        # Teste de complexity
        assert CalculateDiscount.complexity == Complexity.O_1

    def test_logic_signature_includes_complexity(self):
        """get_signature() inclui complexity."""

        class ComplexLogic(Logic):
            complexity = Complexity.O_N

            @classmethod
            def run(cls, input: Logic.Input) -> Logic.Output:
                return cls.Output()

        sig = ComplexLogic.get_signature()
        assert "complexity" in sig
        assert sig["complexity"] == "O(n)"

    def test_logic_signature_includes_input_schema(self):
        """get_signature() inclui input_schema."""

        class SchemaLogic(Logic):
            class Input(BaseModel):
                value: int

            @classmethod
            def run(cls, input: "SchemaLogic.Input") -> Logic.Output:
                return cls.Output()

        sig = SchemaLogic.get_signature()
        assert "input_schema" in sig
        assert "value" in sig["input_schema"].get("properties", {})

    def test_logic_signature_includes_output_schema(self):
        """get_signature() inclui output_schema."""

        class OutputLogic(Logic):
            class Output(BaseModel):
                result: str

            @classmethod
            def run(cls, input: Logic.Input) -> "OutputLogic.Output":
                return cls.Output(result="ok")

        sig = OutputLogic.get_signature()
        assert "output_schema" in sig
        assert "result" in sig["output_schema"].get("properties", {})

    def test_logic_as_tool_definition(self):
        """as_tool_definition() retorna formato OpenAI Function Calling."""

        class ToolLogic(Logic):
            description = "Uma ferramenta de teste"
            complexity = Complexity.O_1

            class Input(BaseModel):
                query: str

            @classmethod
            def run(cls, input: "ToolLogic.Input") -> Logic.Output:
                return cls.Output()

        tool_def = ToolLogic.as_tool_definition()

        assert tool_def["type"] == "function"
        assert tool_def["function"]["name"] == "ToolLogic"
        assert "Uma ferramenta de teste" in tool_def["function"]["description"]
        assert "query" in tool_def["function"]["parameters"].get("properties", {})
        assert tool_def["metadata"]["complexity"] == "O(1)"
        assert tool_def["metadata"]["cacheable"] is True

    def test_complexity_enum_values(self):
        """Complexity enum tem todos os valores esperados."""
        assert Complexity.O_1.value == "O(1)"
        assert Complexity.O_LOG_N.value == "O(log n)"
        assert Complexity.O_N.value == "O(n)"
        assert Complexity.O_N_LOG_N.value == "O(n log n)"
        assert Complexity.O_N2.value == "O(n²)"
        assert Complexity.O_UNKNOWN.value == "O(?)"

    def test_logic_decorator_with_complexity(self):
        """Decorator @logic suporta complexity."""

        @logic("Calcular Risco", complexity=Complexity.O_1)
        def calc_risk(score: int) -> float:
            """Calcula risco baseado no score."""
            return score / 100.0

        assert calc_risk.complexity == Complexity.O_1
        assert calc_risk.display_name == "Calcular Risco"
        result = calc_risk.run(50)
        assert result == 0.5

    def test_logic_decorator_default_complexity(self):
        """Decorator @logic tem complexity padrão O_UNKNOWN."""

        @logic("Simples")
        def simple_func(x: int) -> int:
            return x * 2

        assert simple_func.complexity == Complexity.O_UNKNOWN
