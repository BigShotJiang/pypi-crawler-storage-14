import configparser
import os


class ConstantsManagement:
    def __init__(self):
        file_path = self.get_file_path()
        self.config = self.read_config(file_path)

    def get_file_path(self):
        file_name = "constants.ini"
        # get the directory where the current script is located
        script_dir = os.path.dirname(__file__)
        # construct the full path to the .ini file
        return os.path.join(script_dir, file_name)

    def read_config(self, file_path):
        config = configparser.ConfigParser()
        config.read(file_path)
        return config

    def get_config(self):
        return self.config
