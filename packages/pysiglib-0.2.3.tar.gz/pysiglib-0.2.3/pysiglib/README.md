<h1 align='center'>pySigLib</h1>

<h2 align='center'>A Python Wrapper for cpSIG and cuSIG</h2>

This directory contains source code for `pysiglib`, which is a python wrapper
for the C++ libraries `cpSIG` and `cuSIG`.