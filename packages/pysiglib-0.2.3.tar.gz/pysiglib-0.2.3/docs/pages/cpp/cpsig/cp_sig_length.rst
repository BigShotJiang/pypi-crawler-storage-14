sig_length
=============

.. doxygenfunction:: sig_length