sig_combine
=============

.. doxygenfunction:: sig_combine

batch_sig_combine
===================

.. doxygenfunction:: batch_sig_combine

sig_combine_backprop
=====================

.. doxygenfunction:: sig_combine_backprop

batch_sig_combine_backprop
============================

.. doxygenfunction:: batch_sig_combine_backprop