sig_kernel
============

.. doxygenfunction:: sig_kernel

batch_sig_kernel
=================

.. doxygenfunction:: batch_sig_kernel

sig_kernel_backprop
=====================

.. doxygenfunction:: sig_kernel_backprop

batch_sig_kernel_backprop
============================

.. doxygenfunction:: batch_sig_kernel_backprop
