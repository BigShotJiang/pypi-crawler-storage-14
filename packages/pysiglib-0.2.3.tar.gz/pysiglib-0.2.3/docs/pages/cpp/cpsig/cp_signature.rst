signature
============

.. doxygengroup:: signature_functions
   :content-only:

batch_signature
=================

.. doxygengroup:: batch_signature_functions
   :content-only:

sig_backprop
=================

.. doxygengroup:: sig_backprop_functions
   :content-only:

batch_sig_backprop
===================

.. doxygengroup:: batch_sig_backprop_functions
   :content-only: