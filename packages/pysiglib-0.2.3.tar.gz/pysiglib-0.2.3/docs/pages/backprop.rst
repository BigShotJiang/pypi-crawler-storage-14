Backpropagation
========================

.. toctree::
   :titlesonly:

   backprop/transform_path_backprop
   backprop/sig_backprop
   backprop/sig_combine_backprop
   backprop/sig_kernel_backprop
   backprop/sig_kernel_gram_backprop