pysiglib.sig_kernel
========================

.. autofunction:: pysiglib.sig_kernel