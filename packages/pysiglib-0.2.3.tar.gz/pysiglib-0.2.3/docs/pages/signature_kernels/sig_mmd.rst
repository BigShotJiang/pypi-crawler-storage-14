pysiglib.sig_mmd
========================

.. versionadded:: v0.2.1

.. autofunction:: pysiglib.sig_mmd