pysiglib.sig_score
========================

.. versionadded:: v0.2.1

.. autofunction:: pysiglib.sig_score