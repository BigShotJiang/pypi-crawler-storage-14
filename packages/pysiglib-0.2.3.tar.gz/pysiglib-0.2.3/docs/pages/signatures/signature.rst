pysiglib.signature
========================

.. autofunction:: pysiglib.signature