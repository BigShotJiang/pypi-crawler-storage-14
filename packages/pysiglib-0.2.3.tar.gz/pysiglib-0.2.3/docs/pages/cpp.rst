C++ Documentation
========================

Brief documentation for the ``cpSIG`` and ``cuSIG`` C++ libraries. We omit details
of the mathematical operations, for which we refer the user to the corresponding python documentation.

.. toctree::
   :titlesonly:

   cpp/cpsig
   cpp/cusig