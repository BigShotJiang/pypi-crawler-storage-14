Torch API
========================

.. versionadded:: v0.2

pySigLib provides a torch API which exposes all the same functions, but makes them torch differentiable.
Just import

.. code-block::

    import pysiglib.torch_api as pysiglib

