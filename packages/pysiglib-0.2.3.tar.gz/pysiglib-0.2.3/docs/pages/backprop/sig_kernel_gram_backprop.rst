pysiglib.sig_kernel_gram_backprop
===================================

.. versionadded:: v0.2.1

.. autofunction:: pysiglib.sig_kernel_gram_backprop