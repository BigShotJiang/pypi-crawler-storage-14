pysiglib.transform_path_backprop
=================================

.. versionadded:: v0.2

.. autofunction:: pysiglib.transform_path_backprop