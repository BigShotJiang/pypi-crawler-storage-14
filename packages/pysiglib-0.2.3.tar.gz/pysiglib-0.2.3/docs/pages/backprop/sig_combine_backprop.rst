pysiglib.sig_combine_backprop
================================

.. versionadded:: v0.2

.. autofunction:: pysiglib.sig_combine_backprop