pysiglib.transform_path
========================

.. versionadded:: v0.2

.. autofunction:: pysiglib.transform_path