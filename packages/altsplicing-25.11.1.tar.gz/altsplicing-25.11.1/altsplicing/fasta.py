# -*- coding: utf-8 -*-
"""Fasta related functions."""

__all__ = ["cleave_fastadb", "get_protein_id", "load_fastadb"]


from pyteomics import fasta, parser


def load_fastadb(fasta_filepath: str, flavor="UniProt") -> dict:
    """
    Load fasta from file and return dict {protein_str: protein_sequence}.

    :param fasta_filepath: path to the protein fasta.
    :param flavor: fasta format. If "UniProt", use fasta entry id for protein_str.
    :return: dict {protein_str: protein_sequence}.
    """

    def get_protein_str(fasta_header: str) -> str:
        return fasta_header.lstrip().split(sep=" ", maxsplit=1)[0]

    if flavor.lower() == "uniprot":
        fastadb = {
            f.description["id"]: f.sequence
            for f in fasta.IndexedFASTA(fasta_filepath, parser=fasta.parse)
        }
    else:
        fastadb = {
            get_protein_str(f.description["__raw__"]): f.sequence
            for f in fasta.IndexedFASTA(fasta_filepath, parser=fasta.parse)
        }

    return fastadb


def get_protein_id(protein_descr: str) -> str:
    """
    Extract accession number for UniProt entry: "sp|Q5T5U3-3|RHG21_HUMAN" -> "Q5T5U3-3".
    """
    return protein_descr.rsplit("|")[1]


def cleave_fastadb(
    fastadb: dict,
    enzyme_rule: str,
    max_missed_cleavages: int = 2,
    min_length: int = 6,
    max_length: int = 60,
) -> dict:
    """
    Cleave all proteins in fastadb and return dictionary

    {protein_id: [
            [peptides without missed_cleavages],
            [peptides with the single missed cleavage],
            ...
            [peptides with the maximum number of missed cleavages]
        ]
    }
    """

    enzyme_peptides = {
        prot_id: [None] * (max_missed_cleavages + 1) for prot_id in fastadb.keys()
    }
    for prot_id in enzyme_peptides:
        for mc_level in range(max_missed_cleavages + 1):
            enzyme_peptides[prot_id][mc_level] = parser.cleave(
                sequence=fastadb[prot_id],
                rule=enzyme_rule,
                missed_cleavages=mc_level,
                min_length=min_length,
                max_length=max_length,
            )
        for mc_level in range(max_missed_cleavages, 0, -1):
            enzyme_peptides[prot_id][mc_level] -= enzyme_peptides[prot_id][mc_level - 1]

    return enzyme_peptides
