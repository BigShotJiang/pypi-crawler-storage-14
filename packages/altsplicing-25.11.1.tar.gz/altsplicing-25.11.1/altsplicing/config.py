# -*- coding: utf-8 -*-
"""Global configuration."""

__all__ = [
    "CONFDIR",
    "load_config",
    "load_demo",
]


import os
import tomllib


CONFDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "conf")


def load_config(fpath: str) -> dict:
    """Load settings from file."""
    # Defaults from TMTCrunch and Identipy
    default_cfg = {
        "tmtcrunch_prefix": "tmtcrunch_",
        "enzyme": "trypsin",
        "missed_cleavages": 1,
        "peptide_minimum_length": 6,
        "peptide_maximum_length": 60,
    }
    with open(fpath, "rb") as f:
        cfg = tomllib.load(f)
    cfg["project_names"] = list(cfg["project"].keys())
    cfg["fasta_path"] = os.path.join(cfg["basedir"], "fasta", cfg["fasta_file"])
    cfg["sampleinfo_dir"] = os.path.join(cfg["basedir"], "sampleinfo")
    cfg["results_dir"] = os.path.join(cfg["basedir"], "results")
    cfg["isoforms_dir"] = os.path.join(cfg["results_dir"], "isoforms")
    cfg["figs_dir"] = os.path.join(cfg["results_dir"], "figs")
    cfg["kinase_dir"] = os.path.join(cfg["results_dir"], "kinase")
    cfg["peptidedb_dir"] = os.path.join(cfg["results_dir"], "peptidedb")
    cfg["smd_dir"] = os.path.join(cfg["results_dir"], "smd")
    cfg["peptidedb_path"] = os.path.join(cfg["peptidedb_dir"], "peptidedb.tsv")
    for pname, pcfg in cfg["project"].items():
        pcfg["project_path"] = os.path.join(cfg["basedir"], pcfg["project_dir"])
        pcfg["fasta_path"] = cfg["fasta_path"]
        pcfg["sampleinfo_path"] = os.path.join(
            cfg["sampleinfo_dir"], pcfg["sampleinfo_file"]
        )
        cfg["project"][pname] = default_cfg | pcfg
    return cfg


def load_demo() -> dict:
    """Load demo settings."""
    fpath = os.path.join(CONFDIR, "pxd_sets.toml")
    cfg = load_config(fpath)
    return cfg
