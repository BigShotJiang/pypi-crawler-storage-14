# -*- coding: utf-8 -*-
"""Miscellaneous functions."""

__all__ = ["intersection", "np_smd", "union", "uniq", "squeeze_nan"]


from collections.abc import Iterable
from typing import Union

import numpy as np
import pandas as pd


def uniq(x: Iterable[str], sort=True) -> list:
    """Return list with filtered out repeated elements from the input list."""
    y = list(set(x))
    y = sorted(y) if sort else y
    return y


def intersection(x: list[Iterable[str]]) -> set:
    """Return intersection of all sets in the intput list."""
    return set(x[0]).intersection(*tuple(x[1:]))


def union(x: list[Iterable]) -> set:
    """Return union of all sets in the intput list."""
    return set().union(*tuple(x))


def np_smd(a1: np.ndarray, a2: np.ndarray, axis: int = 1) -> np.ndarray:
    """Calculate smd between two arrays."""
    diff = np.mean(a2, axis=axis) - np.mean(a1, axis=axis)
    var = np.var(a2, axis=axis) + np.var(a1, axis=axis)
    smd = diff / np.sqrt(var)
    return smd


def squeeze_nan(x: Union[pd.DataFrame, np.ndarray]) -> Union[pd.DataFrame, np.ndarray]:
    """
    Squeeze 2d array row by row dropping missing values (NaN). Each row of the array
    must contain the same number of NaN.

    :param: Input ndarray or DataFrame.
    :return: Squeezed array.
    """
    if len(x.shape) != 2:
        raise ValueError("Expected 2d array.")
    index = None if isinstance(x, np.ndarray) else x.index
    x = np.array(x)
    squeezed = []
    for row in x:
        squeezed.append(row[~np.isnan(row)])
    squeezed = np.array(squeezed)
    if index is not None:
        squeezed = pd.DataFrame(data=squeezed, index=index)
    return squeezed
