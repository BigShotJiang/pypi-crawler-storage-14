# -*- coding: utf-8 -*-
"""Peptide proximity database."""

__all__ = [
    "init_peptide_db",
    "load_peptide_db",
    "save_peptide_db",
    "update_peptide_db",
]


import multiprocessing
from typing import Callable

import numpy as np
import pandas as pd
from tqdm import tqdm


def init_peptide_db(path: str, peptides: list[str]):
    """
    Initialize peptide proximity database with `peptides` and save it to file.

    param path:
        peptide db file path
    param peptides:
        list of peptides
    """
    df_peptide_db = pd.DataFrame(
        {
            "peptide": peptides,
            "min_distance": -1,
            "proteins": None,
            "subsequences": None,
            "positions": None,
        },
        dtype=object,
    )
    df_peptide_db.to_csv(path, sep="\t", index=False)


def load_peptide_db(path: str) -> pd.DataFrame:
    """Load peptide proximity database."""
    df_peptide_db = pd.read_table(
        path,
        index_col="peptide",
        dtype=object,
    )
    df_peptide_db = df_peptide_db.astype(dtype={"min_distance": np.int_})
    return df_peptide_db


def save_peptide_db(peptide_db: pd.DataFrame, path: str):
    """Save peptide proximity database."""
    df_peptides_db = peptide_db.reset_index(names="peptide")
    df_peptides_db.to_csv(path, sep="\t", index=False)


def update_peptide_db(
    path: str,
    mp_func: Callable[[str], tuple[str, tuple[int, list[str], list[str], list[int]]]],
    n_proc: int = 8,
    chunk_size: int = 10,
):
    """
    Update empty peptide db entries (those that have "min_distance == -1").
    The update proceeds in batches, the batch size is `n_proc` * `chunk_size`.

    param path:
        peptide db file path
    param mp_func:
        function of a peptide, which returns tuple of the
        peptide itself and peptide properties:
        peptide, (min_distance, proteins, subsequences, positions)
    param n_proc:
        maximum processes to use
    chunk_size:
        maximum entries per process
    """
    batch_size = n_proc * chunk_size
    df_peptide_db = load_peptide_db(path)
    peptides_to_update = df_peptide_db.query("min_distance == -1").index.to_list()

    batches = [
        peptides_to_update[i : i + batch_size]
        for i in range(0, len(peptides_to_update), batch_size)
    ]

    for peptides in tqdm(batches, unit="batch", desc="updated"):
        with multiprocessing.Pool(processes=n_proc) as pool:
            mp_res = pool.map(mp_func, peptides)
        for peptide, (min_distance, proteins, subsequences, positions) in mp_res:
            df_peptide_db.at[peptide, "min_distance"] = min_distance
            df_peptide_db.at[peptide, "proteins"] = proteins
            df_peptide_db.at[peptide, "subsequences"] = subsequences
            df_peptide_db.at[peptide, "positions"] = positions
        save_peptide_db(df_peptide_db, path)
