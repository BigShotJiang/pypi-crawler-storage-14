"""Functions for phospho-proteomics."""

__all__ = [
    "PeptideContext",
    "find_all_phosphosites",
    "get_peptide_context",
    "get_substrates",
    "modX_to_kl",
    "pad_sequence",
    "peptide_to_kl",
]


import re

from .utils import uniq


def peptide_to_kl(sequence: str, phos_indices: list[int]) -> str:
    """
    Convert plain amino-sequence to the sequence formatted for the Kinase Library, i.e.
    all phosphoacceptors are lowercased.

    :param sequence: plain amino-sequence.
    :param phos_indices: indices of phosphoacceptors.
    :return: kl-peptide.
    """
    kl_peptide = ""
    start = 0
    for i in phos_indices:
        kl_peptide += sequence[start:i]
        kl_peptide += sequence[i].lower()
        start = i + 1
    kl_peptide += sequence[start:]
    return kl_peptide


def modX_to_kl(
    modpeptide: str,
    mapping: dict = None,
) -> str:
    """
    Convert phospho-peptide in modX format to peptide formatted for the Kinase Library,
    i.e. all phosphoacceptors are lowercased.

    :param modpeptide: modX peptide.
    :param mapping: modX to kl conversion rules. Default is pX -> x for S, T, and Y.
    :return: kl-peptide.
    """
    if mapping is None:
        mapping = dict(pS="s", pT="t", pY="y")

    kl_peptide = modpeptide
    for old, new in mapping.items():
        kl_peptide = kl_peptide.replace(old, new)
    return kl_peptide


def find_all_phosphosites(kl_peptide: str, phosphoacceptor=r"[sty]") -> list[int]:
    """
    Return indices of phosphoacceptors.

    :param kl_peptide: peptide sequence.
    :param phosphoacceptor: regular expression for phosphorylated animo-acids.
    :return: list with the indices of phosphoacceptors.
    """
    prog = re.compile(phosphoacceptor)
    return [s.start() for s in prog.finditer(kl_peptide)]


def pad_sequence(sequence: str, width: int = 7, fillchar: str = "_") -> str:
    """
    Return a copy of the string `sequence` padded with `fillchar` on the both sides.
    """
    return sequence.center(len(sequence) + 2 * width, fillchar)


def find_all(sequence: str, peptide: str) -> list[int]:
    """
    Return indices of starting position of the `peptide` in the `sequence`.

    :param sequence: amino-sequence.
    :param peptide: peptide.
    :return: list with the starting indices.
    """
    prog = re.compile(peptide)
    return [s.start() for s in prog.finditer(sequence)]


from dataclasses import dataclass


@dataclass
class PeptideContext:
    """Class for peptide context."""

    sequences: list[str]
    border_width: int


def get_peptide_context(
    peptide: str, protein_group: list, fastadb: dict, border_width: int = 7
) -> PeptideContext:
    """
    Return list of unique sequences containing `peptide` with its surroundings in the
    sequences of proteins defined by the list of protein ids `protein_group` and by the
    `fastadb` mapping {'id':'sequence'}.

    :param peptide: peptide sequence.
    :param protein_group: list of protein id.
    :param fastadb: protein id to sequence mapping.
    :param border_width: width of surroundings.
    :return: PeptideContext
    """
    sequences = []
    for protein_id in protein_group:
        protein_seq = pad_sequence(fastadb[protein_id], width=border_width)
        starting_positions = find_all(protein_seq, peptide)
        for i in starting_positions:
            start = i - border_width
            end = i + len(peptide) + border_width
            sequences.append(protein_seq[start:end])
    return PeptideContext(uniq(sequences), border_width)


def get_substrates(modpeptide: str, peptide_context: PeptideContext) -> list[int]:
    """
    Return list of unique substrates for `modpeptide` using `peptide_context`.

    :param modpeptide: modX peptide.
    :param peptide_context: `PeptideContext`.
    :return: list of unique substrates suitable for kinase_library.
    """
    kl_peptide = pad_sequence(
        modX_to_kl(modpeptide), width=peptide_context.border_width
    )
    phos_pos = find_all_phosphosites(kl_peptide)
    substrates = []
    for sequence in peptide_context.sequences:
        phospho_sequence = peptide_to_kl(sequence, phos_pos)
        for i in phos_pos:
            start = i - peptide_context.border_width
            end = i + 1 + peptide_context.border_width
            substrates.append(phospho_sequence[start:end])
    return uniq(substrates)
