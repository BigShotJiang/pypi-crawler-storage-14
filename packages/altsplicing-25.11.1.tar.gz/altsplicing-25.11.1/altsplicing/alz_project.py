# -*- coding: utf-8 -*-
"""Alzheimer project class."""

__all__ = ["AlzProject", "estimate_smd"]

import os
import warnings
from ast import literal_eval

import numpy as np
import pandas as pd
from pyteomics import parser
from scipy.stats import ttest_ind
from tmtcrunch import TMTCrunchResults, TMTSampleInfo

from .bootstrap import bootstrap2, bootstrap2mv
from .fasta import load_fastadb
from .utils import np_smd


# TODO: Rename to AltSp
class AlzProject(TMTCrunchResults):
    """Helper class for datasets with alternative splicing."""

    def __init__(
        self,
        project_name: str,
        cfg: dict,
    ):
        self.cfg = cfg
        pcfg = cfg["project"][project_name]

        super().__init__(
            tmtcrunch_dir=os.path.join(pcfg["project_path"], "tmtcrunch"),
            sampleinfo=TMTSampleInfo(pcfg["sampleinfo_path"], gis_label="GIS"),
            tmtcrunch_prefix=pcfg["tmtcrunch_prefix"],
        )

        self.name = project_name

        self.patient_cols = self.sampleinfo.specimens(
            condition=cfg["patient_diagnosis"]
        )
        self.control_cols = self.sampleinfo.specimens(
            condition=cfg["control_diagnosis"]
        )

        self.enzyme = pcfg["enzyme"]
        self.fasta_path = pcfg["fasta_path"]
        self.missed_cleavages = pcfg["missed_cleavages"]
        self.peptide_minimum_length = pcfg["peptide_minimum_length"]
        self.peptide_maximum_length = pcfg["peptide_maximum_length"]

        # self.load_fastadb()
        self.fastadb = None
        # make_peptides_altsp()
        self.df_peptides_altsp = None
        # calculate_isoform_coverage()
        # self.df_coverage_any_batch = Nones
        # self.df_coverage_across_batches = None
        self.df_isoform_coverage = None
        # load_peptide_proximity()
        self.df_peptide_proximity = None
        # load_isoform_everything()
        self.df_isoform = None
        # quantify()
        self.quant = {level: None for level in self._agg_levels}
        # create_substrate_table()
        self.df_substrates = None

        # Deprecated, use self.abundance["protein"] instead.
        self.df_proteins = None
        # calculate_smd_proteins()
        self.smd_proteins = None

    def load_fastadb(self, reload=False):
        """Load UniProt fasta and generate dict {protein_id: protein_sequence}."""
        if not (reload or isinstance(self.fastadb, type(None))):
            return
        self.fastadb = load_fastadb(self.fasta_path, flavor="UniProt")

    def peptides_from_psm(self, level="peptide"):
        """
        Create self.df_peptides from PSMs DataFrame.

        Count PSMs and calculate ambiguity of peptide to gene assignment for each
        peptide.

        :param level: "peptide" or "modpeptide".
        """
        super().peptides_from_psm(level=level)
        self.df_peptides["num_missed_cleavages"] = self.df_peptides["peptide"].apply(
            lambda x: parser.num_sites(x, rule=self.enzyme, missed_cleavages=0)
        )

    def load_peptides(self, reload=False, level="peptide"):
        """
        Create self.df_peptides from PSMs DataFrame.

        Count PSMs and calculate ambiguity of peptide to gene assignment for each
        peptide.

        :param reload: unused.
        :param level: "peptide" or "modpeptide".
        """
        warnings.warn(
            "use peptides_from_psm() instead of", DeprecationWarning, stacklevel=2
        )
        self.peptides_from_psm(level=level)

    def load_proteins(self, drop_nan=True, reload=False, verbose=False):
        """
        Load abundance at the protein level from all batches.

        :param drop_nan: if True, if True, skip protein missing in any batch.
        :param reload: if True, reload data from files.
        :param verbose: if True, show progress bar.
        """
        warnings.warn(
            "use load_abundance() instead of", DeprecationWarning, stacklevel=2
        )
        if not (reload or isinstance(self.df_proteins, type(None))):
            return
        self.load_abundance(level="protein", skip_missing=drop_nan, verbose=verbose)

        self.df_proteins = self.abundance["protein"]

    def make_peptides_altsp(self, level: str = "peptide"):
        """
        Put isoform specific peptides to a separate table.

        :param level: "peptide" or "modpeptide".
        """
        self.peptides_from_psm(level=level)
        self.df_peptides_altsp = self.df_peptides[
            (self.df_peptides["psm_group"] == "isoform")
        ]

    def save_peptides_altsp(self, path: str = None):
        """Save table of isoform specific peptides to file."""
        if not path:
            path = os.path.join(
                self.cfg["isoforms_dir"], f"{self.name}_peptides_altsp.tsv"
            )
        os.makedirs(self.cfg["isoforms_dir"], exist_ok=True)
        self.df_peptides_altsp.to_csv(path, sep="\t", index=False)

    def load_peptides_altsp(self, path: str = None):
        """Load table of isoform specific peptides from file."""
        if not path:
            path = os.path.join(
                self.cfg["isoforms_dir"], f"{self.name}_peptides_altsp.tsv"
            )

        self.df_peptides_altsp = pd.read_table(
            path,
            converters={key: literal_eval for key in ["gene", "protein", "peptides"]},
        )

    def calculate_smd_proteins(self, **kwargs):
        """
        Estimate smd at protein level.

        :param kwargs:
            arguments for `estimate_smd`.
        """
        warnings.warn(
            "use quantify(level='protein') instead of", DeprecationWarning, stacklevel=2
        )
        self.smd_proteins = estimate_smd(self, df=self.abundance["protein"], **kwargs)

    def quantify(
        self,
        level: str,
        **bootstrap_kwargs: dict,
    ):
        """
        Quantify difference between patient and control cohorts.

        Use `self.bootstrap_cfg` to configure smd boostrapp estimator,
        `self.quant[level]` to access results.

        :param level: "modpeptide", "protein".
        :param bootstrap_kwargs: arguments for `bootstrap2mv`.
        """

        if level not in self._agg_levels:
            raise ValueError(f"unknown level '{level}'")
        self.load_abundance(level=level)
        df_quant = quantify(
            df=self.abundance[level],
            control_columns=self.control_cols,
            patient_columns=self.patient_cols,
            **bootstrap_kwargs,
        )
        self.quant[level] = df_quant

    def save_quantification(self, level: str, path: str = None) -> str:
        """
        Save quantification table to the path.

        :param level: "modpeptide", "protein".
        :param path: if None, the project subdirectory will be used.
        :return: path to the saved file.
        """
        if level not in self._agg_levels:
            raise ValueError(f"unknown level '{level}'")
        if not path:
            path = os.path.join(self.cfg["smd_dir"], f"{self.name}_{level}.tsv")
        os.makedirs(self.cfg["smd_dir"], exist_ok=True)
        df = self.quant[level].reset_index()
        df.to_csv(path, sep="\t", index=False)
        return path

    def load_quantification(self, level: str, path: str = None):
        """
        Load quantification table from the path.

        :param level: "modpeptide", "protein".
        :param path: if None, the project subdirectory will be used.
        """
        if level not in self._agg_levels:
            raise ValueError(f"unknown level '{level}'")
        if not path:
            path = os.path.join(self.cfg["smd_dir"], f"{self.name}_{level}.tsv")
        self.quant[level] = pd.read_table(path)

    def save_substrates(self, path: str = None) -> str:
        """
        Save tables with substrates.

        :param path: if None, the project subdirectory will be used.
        :return: path to the saved file.
        """
        if not path:
            path = os.path.join(self.cfg["kinase_dir"], f"{self.name}_substrates.tsv")
        self.df_substrates.to_csv(path, sep="\t", index=False)
        return path

    def load_substrates(self, path: str = None):
        """
        Load tables with substrates from the path.

        :param path: if None, the project subdirectory will be used.
        """
        if not path:
            path = os.path.join(self.cfg["kinase_dir"], f"{self.name}_substrates.tsv")
        self.df_substrates = pd.read_table(path)


def estimate_smd(
    project: AlzProject,
    df: pd.DataFrame,
    legacy_resampling: bool = True,
    **bootstrap_kwargs: dict,
) -> pd.DataFrame:
    """
    Estimate smd between `project.control_cols` and `project.patient_cols` cohorts via
    bootstrap resampling.

    :param project: AlzProject instance.
    :param df:
        DataFrame with patient and control columns,
        e.g. `project.df_proteins` or `project.df_genes`.
    :param legacy_resampling:
        If true, use `bootstrap2` for bootstrapping data without missing values.
        If false, use `bootstrap2mv` for bootstrapping data with missing values.
    :param bootstrap_kwargs:
        Arguments for `bootstrap2` or `bootstrap2mv`.
    """

    df_c = df[project.control_cols]
    df_p = df[project.patient_cols]

    if legacy_resampling:
        df_smd_samples = bootstrap2(
            df_control=df_c,
            df_patient=df_p,
            statistics=np_smd,
            **bootstrap_kwargs,
        )
        df_count = pd.DataFrame(
            {
                "n_c": len(project.control_cols),
                "n_p": len(project.patient_cols),
            },
            index=df_smd_samples.index,
        )
    else:
        df_smd_samples, df_count = bootstrap2mv(
            df_control=df_c,
            df_patient=df_p,
            statistics=np_smd,
            **bootstrap_kwargs,
        )

    df_smd = pd.DataFrame(
        {
            "mean": df_smd_samples.mean(axis=1),
            "std": df_smd_samples.std(axis=1),
            "abs": -1,
        },
        index=df_smd_samples.index,
    )
    df_smd["abs"] = df_smd["mean"].abs()
    df_smd = pd.concat([df_count, df_smd], axis=1)
    return df_smd


def quantify(
    df: pd.DataFrame,
    control_columns: list,
    patient_columns: list,
    control_min_size: int = 6,
    patient_min_size: int = 6,
    n_resamples: int = 100,
) -> pd.DataFrame:
    """
    Quantify difference between patient and control cohorts.

    Estimate smd using resampling, calculate fold change between the patient and control
    cohorts, and perform independent t-test without assuming equal population
    variances.

    :param df: DataFrame
    :param control_columns: columns of the control cohort.
    :param patient_columns: columns of the patient cohort.
    :param control_min_size: minimum size of control cohort.
    :param patient_min_size: minimum size of patient cohort.
    :param n_resamples: the number of bootstrap resamples.
    :return: DataFrame
    """
    df_c = df[control_columns]
    df_p = df[patient_columns]

    # fold change and p-value
    df_fold = pd.DataFrame(columns=["log2_fc", "pvalue", "t-statistic"], index=df.index)
    df_fold["log2_fc"] = (df_p.mean(axis=1) - df_c.mean(axis=1)) / np.log(2.0)
    stat, pval = ttest_ind(df_p, df_c, axis=1, equal_var=False, nan_policy="omit")
    df_fold["t-statistic"] = stat
    df_fold["pvalue"] = pval

    # smd
    df_resamples, df_size = bootstrap2mv(
        df_control=df_c,
        df_patient=df_p,
        statistics=np_smd,
        control_min_size=control_min_size,
        patient_min_size=patient_min_size,
        n_resamples=n_resamples,
    )
    df_smd = pd.DataFrame(
        data={
            "smd": df_resamples.mean(axis=1),
            "smd_std": df_resamples.std(axis=1),
            "smd_abs": -1,
        },
        index=df_resamples.index,
    )
    df_smd["smd_abs"] = df_smd["smd"].abs()

    return pd.concat([df_size, df_smd, df_fold], axis=1, join="inner")
