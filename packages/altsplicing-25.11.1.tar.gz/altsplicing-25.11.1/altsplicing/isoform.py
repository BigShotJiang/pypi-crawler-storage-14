# -*- coding: utf-8 -*-
"""Helpers for UniProt isoform."""

__all__ = [
    "find_similar_peptides",
    "is_canon",
    "is_isoform",
    "isoform_to_canon",
    "make_isoforms_for_canon",
    "normalize_leading_peptides",
    "protein_ids",
    "sequence_coverage",
    "strict_canon_peptides",
    "strict_isoform_peptides",
]


from collections import defaultdict, namedtuple
from typing import Callable

import numpy as np
import pandas as pd
from pyteomics import parser

from .utils import uniq

ProteinId = namedtuple("ProteinId", ["canon", "isoform"])


def is_canon(protein_id: str) -> bool:
    """
    Check whether protein is canonical.

    The format of `protein_id`
    is expected in form of "Q5T5U3-3".
    """
    return len(protein_id.rsplit("-")) == 1


def is_isoform(protein_id: str) -> bool:
    """
    Check whether protein is isoform.

    The format of `protein_id`
    is expected in form of "Q5T5U3-3".
    """
    return len(protein_id.rsplit("-")) > 1


def isoform_to_canon(isoform_id: str) -> str:
    """Get id of canonical protein for a given isoform id, e.g. "Q5T5U3-3" ->
    "Q5T5U3"."""
    return isoform_id.rsplit("-")[0]


def protein_ids(isoform: str) -> ProteinId:
    """Get isoform id and canonical protein id from the full isoform string, e.g.
    "sp|Q5T5U3-3|RHG21_HUMAN" -> ["Q5T5U3", "Q5T5U3-3"]"""
    isoform_id = isoform.rsplit("|")[1]
    canon_id = isoform_id.rsplit("-")[0]
    return ProteinId(canon_id, isoform_id)


def make_isoforms_for_canon(fastadb: dict) -> dict:
    """Create dict {canon_id: [list of isoform id]}."""

    isoforms_by_canon = defaultdict(list)
    for prot_id in fastadb.keys():
        if is_isoform(prot_id):
            isoforms_by_canon[isoform_to_canon(prot_id)] += [prot_id]
    return isoforms_by_canon


def strict_canon_peptides(
    canon_id: str,
    isoform_ids: list[str],
    fastadb: dict,
    enzyme_rule: str,
    max_missed_cleavages: int = 2,
    min_length: int = 6,
    max_length: int = 60,
) -> list[set]:
    """
    Return list containing sets of peptides unique to canonical proteoform for each
    value of missed cleavages from 0 up to max_missed_cleavages.

    :param canon_id: id of canonical protein.
    :param isoform_ids: List of isoform ids.
    :param fastadb: dictionary {protein_id: protein_sequence}.
    :param enzyme_rule: rule for `pyteomics.parser.cleave` function.
    :param max_missed_cleavages: maximum number of allowed missed cleavages.
    :param min_length: minimum peptide length.
    :param max_length: minimum peptide length.
    :return: List of peptide sets.
    """

    canon_peptides = []
    for missed_cleavages in range(max_missed_cleavages + 1):
        c_peptides = parser.cleave(
            fastadb[canon_id], rule=enzyme_rule, missed_cleavages=missed_cleavages
        )
        peptides = c_peptides
        for iid in isoform_ids:
            i_peptides = parser.cleave(
                fastadb[iid], rule=enzyme_rule, missed_cleavages=missed_cleavages
            )
            peptides -= i_peptides
        peptides = [pep for pep in peptides if min_length <= len(pep) <= max_length]
        peptides = set(peptides)
        canon_peptides.append(peptides)
    for i in range(max_missed_cleavages, 0, -1):
        canon_peptides[i] = canon_peptides[i] - canon_peptides[i - 1]
    return canon_peptides


def strict_isoform_peptides(
    isoform: str,
    fastadb: dict,
    enzyme_rule: str,
    max_missed_cleavages: int = 2,
    min_length: int = 6,
    max_length: int = 60,
) -> list[set]:
    """
    Return list containing sets of peptides unique to isoform for each value of
    missed cleavages from 0 up to max_missed_cleavages.

    :param isoform: UniProt isoform, e.g. "sp|Q5T5U3-3|RHG21_HUMAN".
    :param fastadb: dictionary {protein_id: protein_sequence}.
    :param enzyme_rule: rule for `pyteomics.parser.cleave` function.
    :param max_missed_cleavages: maximum number of allowed missed cleavages.
    :param min_length: minimum peptide length.
    :param max_length: minimum peptide length.
    :return: List of peptide sets.
    """

    cid, iid = protein_ids(isoform)
    isoform_peptides = []
    for missed_cleavages in range(max_missed_cleavages + 1):
        c_peptides = parser.cleave(
            fastadb[cid], rule=enzyme_rule, missed_cleavages=missed_cleavages
        )
        i_peptides = parser.cleave(
            fastadb[iid], rule=enzyme_rule, missed_cleavages=missed_cleavages
        )
        peptides = i_peptides - c_peptides
        peptides = [pep for pep in peptides if min_length <= len(pep) <= max_length]
        peptides = set(peptides)
        isoform_peptides.append(peptides)
    for i in range(max_missed_cleavages, 0, -1):
        isoform_peptides[i] = isoform_peptides[i] - isoform_peptides[i - 1]
    return isoform_peptides


# TODO: unify with strict_isoform_peptides()
def isoform_specific_peptides(
    isoform_id: str,
    fastadb: dict,
    enzyme_rule: str,
    max_missed_cleavages: int = 2,
    min_length: int = 6,
    max_length: int = 60,
) -> list[set,]:
    """
    Return list containing sets of peptides unique to isoform for each value of
    missed cleavages from 0 up to max_missed_cleavages.

    :param isoform_id: accession number of UniProt isoform, e.g. "Q5T5U3-3".
    :param fastadb: dictionary {protein_id: protein_sequence}.
    :param enzyme_rule: rule for `pyteomics.parser.cleave` function.
    :param max_missed_cleavages: maximum number of allowed missed cleavages.
    :param min_length: minimum peptide length.
    :param max_length: minimum peptide length.
    :return: List of peptide sets.
    """

    # canon_id, isoform_id = protein_ids(isoform)
    canon_id = isoform_to_canon(isoform_id)
    isoform_peptides = []
    for missed_cleavages in range(max_missed_cleavages + 1):
        c_peptides = parser.cleave(
            fastadb[canon_id], rule=enzyme_rule, missed_cleavages=missed_cleavages
        )
        i_peptides = parser.cleave(
            fastadb[isoform_id], rule=enzyme_rule, missed_cleavages=missed_cleavages
        )
        peptides = i_peptides - c_peptides
        peptides = [pep for pep in peptides if min_length <= len(pep) <= max_length]
        peptides = set(peptides)
        isoform_peptides.append(peptides)
    for i in range(max_missed_cleavages, 0, -1):
        isoform_peptides[i] = isoform_peptides[i] - isoform_peptides[i - 1]
    return isoform_peptides


def sequence_coverage(observed: list, total: list) -> float:
    """
    Calculate protein sequence coverage.

    :param observed: list of observed peptides
    :param total: list of all peptides
    :return: sequence coverage
    """
    observed_weight = sum(len(pep) for pep in observed)
    total_weight = sum(len(pep) for pep in total)
    # catch out of [0…1] cases
    return np.double(observed_weight) / total_weight


def normalize_leading_peptides(
    peptides: list, isoform_peptides: set, isoform_sequence: str
) -> tuple[bool, list, bool, list]:
    """
    Find leading peptides with N-terminal methionine clipped and replace them with the
    non-clipped sequence.

    # protein_sequence = "MVAGESGLGK...."
    ['VAGESGLGK', 'AGESGLGK'] -> ['MVAGESGLGK']
    """
    clipped_found = False
    stealth_found = False
    peptides = peptides.copy()
    leading_peptides = []
    for i, peptide in enumerate(peptides):
        if peptide in isoform_peptides:
            continue
        pep_length = len(peptide)
        for clipped_length in (1, 2):
            if (
                isoform_sequence[clipped_length : pep_length + clipped_length]
                == peptide
            ):
                leading_peptide = isoform_sequence[0 : pep_length + clipped_length]
                peptides[i] = leading_peptide
                clipped_found = True
                if leading_peptide not in isoform_peptides:
                    leading_peptides.append(leading_peptide)
                    stealth_found = True
    normalized_observed_peptides = uniq(peptides)
    normalized_isoform_peptides = uniq(leading_peptides + list(isoform_peptides))
    return (
        clipped_found,
        normalized_observed_peptides,
        stealth_found,
        normalized_isoform_peptides,
    )


def find_similar_peptides(
    peptide: str, fastadb: dict, distance: Callable[[str, str], int]
) -> tuple[int, list[str], list[str], list[int]]:
    """
    Find protein subsequences similar to the input peptide using function `distance` as
    a degree of proximity.

    param peptide: peptide string
    param fastadb: dict {protein_id:protein_sequence}
    param distance: function to calculate distance between two words
    return: tuple of minimal distance, list of protein ids,
            list of similar subsequences, list of starting positions
            in the protein sequence.
    """

    df_distance = pd.DataFrame(
        index=fastadb.keys(), columns=["distance", "subsequence", "position"]
    )
    df_distance.rename_axis(index="protein_id", inplace=True)

    pep_length = len(peptide)
    for protein_id, protein_seq in fastadb.items():
        dist = np.array(
            [
                distance(peptide, protein_seq[i : i + pep_length])
                for i in range(max(1, len(protein_seq) - pep_length + 1))
            ]
        )
        idx_min = np.argmin(dist)
        df_distance.loc[protein_id] = (
            dist[idx_min],
            protein_seq[idx_min : idx_min + pep_length],
            idx_min,
        )
    df_distance = df_distance.convert_dtypes()

    min_distance = df_distance["distance"].min(axis=0)
    ind = df_distance["distance"] == min_distance
    proteins = df_distance[ind].index.to_list()
    subsequences = df_distance[ind]["subsequence"].to_list()
    position = df_distance[ind]["position"].to_list()

    return min_distance, proteins, subsequences, position
