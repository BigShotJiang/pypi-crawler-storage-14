# -*- coding: utf-8 -*-
"""Bootstrap functions."""

__all__ = ["bootstrap2", "bootstrap2mv", "np_resample"]


from functools import partial
from typing import Callable

import numpy as np
import pandas as pd
from tqdm import trange

from .utils import squeeze_nan


def np_resample(a: np.ndarray, n: int = -1) -> np.ndarray:
    """Choose randomly columns in 2d array `n` times."""
    if n == -1:
        n = a.shape[1]
    cols = np.random.choice(a.shape[1], n)
    return a[:, cols]


def bootstrap2(
    df_control: pd.DataFrame,
    df_patient: pd.DataFrame,
    statistics: Callable[[np.array, np.array], np.array],
    control_sample_size: int = -1,
    patient_sample_size: int = -1,
    n_resamples: int = 1000,
    verbose: bool = True,
) -> pd.DataFrame:
    """
    Bootstrap statistics of two distributions using resamples of given sizes.

    :param df_control: Control cohort.
    :param df_patient: Patient cohort.
    :param statistics: The function of two distributions.
    :param control_sample_size: If positive, the size of resample from control cohort.
        If negative, the whole cohort is resampled.
    :param patient_sample_size: If positive, the size of resample from patient cohort.
        If negative, the whole cohort is resampled.
    :param n_resamples: The number of bootstrap resamples.
    :param verbose: If true, display progress bar.
    """

    if (df_control.shape[0] != df_patient.shape[0]) or not all(
        df_control.index == df_patient.index
    ):
        raise ValueError("DataFrames must have the same index.")

    if control_sample_size < 0:
        control_sample_size = df_control.shape[1]
    if patient_sample_size < 0:
        patient_sample_size = df_patient.shape[1]
    if control_sample_size < 2 or patient_sample_size < 2:
        raise ValueError("Bootstrapping signle sampled data makes no sense.")

    stats = []
    for _ in trange(n_resamples, unit="resample", disable=not verbose):
        control_cohort = np_resample(df_control.to_numpy(), control_sample_size)
        patient_cohort = np_resample(df_patient.to_numpy(), patient_sample_size)
        stats.append(statistics(control_cohort, patient_cohort))

    stats = np.array(stats).transpose()
    return pd.DataFrame(stats, index=df_control.index)


def bootstrap2mv(
    df_control: pd.DataFrame,
    df_patient: pd.DataFrame,
    statistics: Callable[[np.array, np.array], np.array],
    control_min_size: int,
    patient_min_size: int,
    n_resamples: int = 1000,
    verbose: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Bootstrap statistics of two distributions with missing values. This function is a
    wrapper around `bootstrap2`.

    :param df_control: Control cohort.
    :param df_patient: Patient cohort.
    :param statistics: The function of two distributions.
    :param control_min_size: If negative, missing values are not allowed. If positive,
        specifies a minimum allowed size for control cohort.
    :param patient_min_size: If negative, missing values are not allowed. If positive,
        specifies a minimum allowed size for patient cohort.
    :param n_resamples: The number of bootstrap resamples.
    :param verbose: If true, display progress bar.
    :return: Tuple of DataFrame for the bootstrap distribution, i.e. the value of
        statistic for each resample, and DataFrame of cohort sizes.
    """

    n_c = df_control.shape[1]
    n_p = df_patient.shape[1]
    if (df_control.shape[0] != df_patient.shape[0]) or not all(
        df_control.index == df_patient.index
    ):
        raise ValueError("DataFrames must have the same row labels.")

    if control_min_size < 0:
        control_min_size = n_c
    if patient_min_size < 0:
        patient_min_size = n_p
    if control_min_size < 2 or patient_min_size < 2:
        raise ValueError("Bootstrapping signle sampled data makes no sense.")
    if n_c < control_min_size:
        raise ValueError("Size of control cohort is less than `control_min_size`")
    if n_p < patient_min_size:
        raise ValueError("Size of patient cohort is less than `patient_min_size`")

    # df_count - count controls and patients for each row
    count_c = df_control.notna().sum(axis=1)
    count_p = df_patient.notna().sum(axis=1)
    df_count = pd.concat([count_c.rename("n_c"), count_p.rename("n_p")], axis=1)
    ind = (df_count["n_c"] >= control_min_size) & (df_count["n_p"] >= patient_min_size)
    df_count = df_count.loc[ind]

    stats = []
    # proceed in batches with the same number of missing values
    progress = partial(print, flush=True) if verbose else lambda x: x
    for row, df in df_count.groupby(["n_c", "n_p"]):
        _ = progress(
            f"control cohort: {row[0]:>3}\t"
            f"patient cohort: {row[1]:>3}\t"
            f"items: {df.shape[0]:>5}"
        )
        stats.append(
            bootstrap2(
                df_control=squeeze_nan(df_control.loc[df.index]),
                df_patient=squeeze_nan(df_patient.loc[df.index]),
                statistics=statistics,
                verbose=verbose,
                n_resamples=n_resamples,
            )
        )
    # assemble table and sort index
    df_stats = pd.concat(stats).loc[df_count.index]
    return df_stats, df_count
