# -*- coding: utf-8 -*-
"""Various helpers for use in examples and Jupyter notebooks."""

__all__ = [
    "print_cfg",
    "make_dirs",
    "calculate_isoform_coverage",
    "get_isoform_peptides",
    "create_peptide_proximity_table",
    "create_isoform_table",
    "create_substrate_table",
]

import os
from typing import Iterable

import numpy as np
import pandas as pd
from tmtcrunch.lib import protein_separator

from .alz_project import AlzProject
from .fasta import get_protein_id
from .isoform import (
    strict_isoform_peptides,
    normalize_leading_peptides,
    protein_ids,
    sequence_coverage,
)
from .phospho import (
    get_peptide_context,
    get_substrates,
    find_all_phosphosites,
    modX_to_kl,
)
from .utils import uniq


def print_cfg(cfg):
    for d in [
        "basedir",
        "sampleinfo_dir",
        "results_dir",
        "isoforms_dir",
        "kinase_dir",
        "figs_dir",
        "peptidedb_path",
        "fasta_path",
    ]:
        print(f"{d:<20} {cfg[d]}")


def make_dirs(cfg):
    subdirs = ["figs_dir", "kinase_dir", "smd_dir", "peptidedb_dir"]
    for d in subdirs:
        os.makedirs(cfg[d], exist_ok=True)


def calculate_isoform_coverage(project: AlzProject, fastadb: dict):
    """Calculate isoform subsequence coverage."""
    df_peptides = (
        project.df_peptides_altsp.drop(columns=["batch", "psm_group"])
        .sort_values(by="PSM count", ascending=False)
        .drop_duplicates(subset=["peptide", "protein_str"])
    )

    # isoforms observed at least once
    isoform_groups_any_batch = uniq(df_peptides["protein_str"].to_list())

    df_isoforms = (
        project.df_peptides_altsp.drop(
            columns=[
                "batch",
                "psm_group",
                "peptide",
                "num_missed_cleavages",
            ]
        )
        .sort_values(by="PSM count", ascending=False)
        .drop_duplicates(subset=["protein_str"])
    )

    df_isoforms = df_isoforms.set_index("protein_str").loc[isoform_groups_any_batch]

    df_isoforms_extra = pd.DataFrame(
        index=isoform_groups_any_batch,
        columns=[
            "missed_cleavages_level",
            "sequence_coverage",
            "n-term clipped",
            "stealth",
        ],
        dtype=object,
    )
    df_isoforms_extra.rename_axis(index="protein_str")

    #  iterate over protein_str, get peptides for a fixed value of missed_cleavages
    # For each isoform in protein_str calculate its sequence coverage.

    for igroup, df in df_peptides.groupby(["protein_str"]):
        missed_cleavages_level = -1
        observed_peptides = []
        while not observed_peptides:
            missed_cleavages_level += 1
            observed_peptides = df["peptide"][
                df["num_missed_cleavages"] == missed_cleavages_level
            ].to_list()

        sc = []
        clipped = False
        stealth = False
        for isoform in df_isoforms.loc[igroup]["protein"]:
            isoform_sequence = fastadb[protein_ids(isoform).isoform]

            isoform_peptides = strict_isoform_peptides(
                isoform,
                fastadb=fastadb,
                enzyme_rule=project.enzyme,
                max_missed_cleavages=missed_cleavages_level,
                min_length=project.peptide_minimum_length,
                max_length=project.peptide_maximum_length,
            )[missed_cleavages_level]

            (
                clipped,
                normalized_observed_peptides,
                stealth,
                normalized_isoform_peptides,
            ) = normalize_leading_peptides(
                observed_peptides,
                isoform_peptides,
                isoform_sequence,
            )

            sc.append(
                sequence_coverage(
                    normalized_observed_peptides, normalized_isoform_peptides
                )
            )

        df_isoforms_extra.at[igroup[0], "missed_cleavages_level"] = (
            missed_cleavages_level
        )
        df_isoforms_extra.at[igroup[0], "sequence_coverage"] = sc
        df_isoforms_extra.at[igroup[0], "n-term clipped"] = clipped
        df_isoforms_extra.at[igroup[0], "stealth"] = stealth

    df_isoforms_extra["sequence_coverage_min"] = df_isoforms_extra[
        "sequence_coverage"
    ].apply(lambda x: min(x))
    df_isoforms_extra["sequence_coverage_mean"] = df_isoforms_extra[
        "sequence_coverage"
    ].apply(lambda x: np.mean(x))
    df_isoforms_extra["sequence_coverage_max"] = df_isoforms_extra[
        "sequence_coverage"
    ].apply(lambda x: max(x))
    df_isoforms = pd.concat([df_isoforms, df_isoforms_extra], axis=1)

    project.df_coverage_any_batch = df_isoforms.reset_index(names="protein_str")
    project.df_isoform_coverage = df_isoforms_extra.drop(
        columns=["n-term clipped", "stealth"]
    ).reset_index(names="protein_str")


def get_isoform_peptides(projects: Iterable[AlzProject]) -> list:
    """Return list of isoform peptides from all projects."""
    all_peptides = set()
    print("  == Isoform peptides ==")
    txt_width = 26
    print("=" * txt_width)
    for project in projects:
        peptides = set(project.df_peptides_altsp["peptide"].to_list())
        all_peptides |= peptides
        print(f"{project.name:20}{len(peptides):6}")
    print("=" * txt_width)
    print(f"Total {len(all_peptides):20}")
    return sorted(all_peptides)


def create_peptide_proximity_table(project: AlzProject, peptide_db: pd.DataFrame):
    """
    Create table of canonical subsequencies resembling observed isoforms.
    """
    df_peptides = (
        project.df_peptides_altsp.drop(columns=["batch", "psm_group", "PSM count"])
        .drop_duplicates(subset=["peptide"])
        .set_index("peptide")
    )

    df_psm_count = (
        project.df_peptides_altsp[["peptide", "PSM count"]].groupby(["peptide"]).sum()
    )
    df_psm_count.rename(columns={"PSM count": "Total PSM"}, inplace=True)

    peptides_any_batch = uniq(project.df_peptides_altsp["peptide"].to_list())
    df_peptide_proximity = peptide_db.loc[peptides_any_batch]
    project.df_peptide_proximity = pd.concat(
        [df_peptides, df_psm_count, df_peptide_proximity], axis=1
    )
    project.df_peptide_proximity.reset_index(inplace=True, names=["peptide"])


def create_isoform_table(
    project: AlzProject, fastadb: dict, df_peptide_db: pd.DataFrame
):
    """Create overall isoform table with subsequence coverage and proximity data."""
    calculate_isoform_coverage(project, fastadb)
    create_peptide_proximity_table(project, df_peptide_db)
    df_isoform_coverage = project.df_isoform_coverage.set_index("protein_str")
    df_isoform_general = project.df_peptide_proximity[
        [
            "gene",
            "gene_str",
            "gene ambiguity",
            "protein",
            "protein_str",
            "protein ambiguity",
        ]
    ].drop_duplicates(subset="protein_str")
    df_isoform_general["igroup"] = df_isoform_general["protein_str"]
    df_isoform_general.set_index("igroup", inplace=True)

    df_isoform_extra = pd.DataFrame(
        index=df_isoform_coverage.index,
        columns={
            "peptides": list(),
            "Total peptides": -1,
            "Total PSM": -1,
            "OSA distance": -1,
        },
        dtype=object,
    )

    for igroup, df in project.df_peptide_proximity.groupby(["protein_str"]):
        total_peptides = len(df["peptide"])
        # This is a lower bound for isoform osa_distance.
        osa_distance = df["min_distance"].sum() + total_peptides
        df_isoform_extra.at[igroup[0], "peptides"] = df["peptide"].to_list()
        df_isoform_extra.at[igroup[0], "Total peptides"] = total_peptides
        df_isoform_extra.at[igroup[0], "Total PSM"] = df["Total PSM"].sum()
        df_isoform_extra.at[igroup[0], "OSA distance"] = osa_distance

    project.df_isoform = (
        pd.concat((df_isoform_general, df_isoform_extra, df_isoform_coverage), axis=1)
        .sort_values(by=["gene_str", "protein_str"])
        .reset_index()
        .drop(columns="index")
    )


def create_substrate_table(project: AlzProject, fastadb: dict, border_width: int = 7):
    """
    Prepare substrates for the Kinase Library: create project.df_substrates and
    project._df_modpeptides_extra tables.
    """
    if project.quant["modpeptide"] is None:
        raise ValueError(
            "project.quant['modpeptide'] DataFrame is empty. Run project.quantify(level='modpeptide') function."
        )

    def df_get_peptide_context(df, fastadb):
        return get_peptide_context(
            df.iloc[0], df.iloc[1], fastadb, border_width=border_width
        )

    def df_get_substrates(df):
        return get_substrates(df.iloc[0], df.iloc[1])

    df_modpep = project.quant["modpeptide"].reset_index().copy()
    df_modpep["protein_id_list"] = df_modpep["protein"].apply(
        lambda x: [get_protein_id(p) for p in x.split(protein_separator)]
    )

    df_modpep["smd_sigma"] = df_modpep["smd_abs"] / df_modpep["smd_std"]
    df_modpep["smd_rank"] = df_modpep["smd"] * df_modpep["smd_sigma"]

    df_modpep["kl_peptide"] = df_modpep["modpeptide"].apply(modX_to_kl)
    df_modpep["phosphosites"] = df_modpep["kl_peptide"].apply(find_all_phosphosites)
    df_modpep["n_phosphosites"] = df_modpep["phosphosites"].apply(len)
    df_modpep["context"] = df_modpep[["peptide", "protein_id_list"]].apply(
        df_get_peptide_context, axis=1, fastadb=fastadb
    )
    df_modpep["substrates"] = df_modpep[["modpeptide", "context"]].apply(
        df_get_substrates, axis=1
    )
    df_modpep["n_substrates"] = df_modpep["substrates"].apply(len)

    stat_cols = ["psm_group", "n_phosphosites"]
    df_stat = df_modpep[stat_cols].groupby(stat_cols).size()
    df_stat = pd.DataFrame(
        index=df_stat.index, data={"peptides": df_stat.values, "%": 0.0}
    )
    df_stat.reset_index(inplace=True)
    df_stat.rename(columns={"n_phosphosites": "phosphosites"}, inplace=True)
    for group, df in df_stat.groupby("psm_group"):
        _values = df["peptides"]
        df["%"] = np.round(100 * _values / _values.sum(), 1)
        print(f"{group:^12}".center(28, "="))
        print(df.set_index("phosphosites").drop(columns="psm_group"))

    project._df_modpeptides_extra = df_modpep
    ind = df_modpep["n_substrates"] > 0
    df_phospho = df_modpep[ind]

    columns = [
        "n_c",
        "n_p",
        "smd",
        "smd_std",
        "smd_sigma",
        "smd_rank",
        "log2_fc",
        "pvalue",
        "psm_group",
        "gene",
        "protein",
        "peptide",
        "modpeptide",
    ]
    df_phospho = df_phospho[["substrates"] + columns]
    _substrates = {col: [] for col in ["substrate"] + columns}

    for row in df_phospho.itertuples():
        row_asdict = row._asdict()
        for substrate in row_asdict["substrates"]:
            _substrates["substrate"].append(substrate)
            for col in columns:
                _substrates[col].append(row_asdict[col])

    df_substrates = pd.DataFrame(_substrates)
    df_substrates.insert(1, "site", "")
    df_substrates["site"] = df_substrates["substrate"].apply(lambda x: x[border_width])
    project.df_substrates = df_substrates
