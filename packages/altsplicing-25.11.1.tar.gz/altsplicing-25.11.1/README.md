# AltSplicing

Python module for analysis of the alternative splicing in proteomics and phospho-proteomics data.

## Installation

To install the latest release from the [Python Package Index](https://pypi.org/project/altsplicing/):
```shell
pip install altsplicing
```

## Jupyter notebook examples

* `examples/altsp_pxd_sets.ipynb` - the workflow configured for PXD006122 and PXD020296 projects.

The data required for the notebook is available at [Zenodo](https://zenodo.org/records/14541303). Download
`altsp_pxd.7z` archive and unpack it directly to `examples` directory using [7-zip](https://www.7-zip.org/) or any 7z
compatible utility.

## License

BSD License.
