"""Django Admin Advanced Search Package

This package provides advanced search functionality for Django Admin interface.
"""

__version__ = '0.1.4'
__author__ = 'shifenhutu'
__license__ = 'MIT'