from django.apps import AppConfig


class UserMediaFilesConfig(AppConfig):
    name = 'django_tools.serve_media_app'
    verbose_name = "Serve Media Files"
