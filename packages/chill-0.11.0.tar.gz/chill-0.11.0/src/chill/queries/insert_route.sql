insert into Route (path, node_id, weight, method)
  values (:path, :node_id, :weight, :method);
