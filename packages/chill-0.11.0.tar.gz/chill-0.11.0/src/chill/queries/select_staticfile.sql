select * from StaticFile where path = :path;
