insert into Node_Node (node_id, target_node_id) values (:node_id, :target_node_id);
