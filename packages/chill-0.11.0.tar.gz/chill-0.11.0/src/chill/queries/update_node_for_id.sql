update Node set (name, value) values (:name, :value)
where id = :node_id;
