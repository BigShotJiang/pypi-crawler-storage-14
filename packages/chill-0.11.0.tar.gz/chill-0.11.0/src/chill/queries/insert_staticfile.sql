insert into StaticFile (path) values (:path);
