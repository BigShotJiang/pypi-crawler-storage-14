insert into Query (name) values (:name);
