insert into Node_Picture (
    node_id,
    picture)
values (
    :node_id,
    :picture);
