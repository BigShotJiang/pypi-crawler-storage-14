select * from Picture where picturename = :picturename;
