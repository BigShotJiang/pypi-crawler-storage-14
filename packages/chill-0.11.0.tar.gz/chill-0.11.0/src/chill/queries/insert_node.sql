insert into Node (name, value) values (:name, :value);
