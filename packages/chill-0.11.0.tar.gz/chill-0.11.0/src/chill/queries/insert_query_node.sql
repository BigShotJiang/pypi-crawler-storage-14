update Node set query = :query_id where id = :node_id;
