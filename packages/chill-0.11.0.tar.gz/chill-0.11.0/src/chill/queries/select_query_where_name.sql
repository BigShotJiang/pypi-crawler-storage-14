select * from Query where name = :name;
