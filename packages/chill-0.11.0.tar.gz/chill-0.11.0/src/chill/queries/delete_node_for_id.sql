delete from Node where id = :node_id;
