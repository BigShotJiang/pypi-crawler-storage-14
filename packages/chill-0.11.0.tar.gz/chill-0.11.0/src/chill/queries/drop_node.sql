DROP TABLE if exists Node;

