insert or ignore into Template (name) values (:name);
