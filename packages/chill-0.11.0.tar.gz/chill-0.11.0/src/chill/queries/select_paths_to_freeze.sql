select path from Route where path not like '%<%>%';
