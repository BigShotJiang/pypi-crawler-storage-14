create table Query (
    id integer primary key,
    name varchar(255) not null
);
