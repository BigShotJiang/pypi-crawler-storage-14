select * from Node_Node where node_id = :node_id;
