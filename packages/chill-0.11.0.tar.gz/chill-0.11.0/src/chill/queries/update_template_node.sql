update Node set template = :template where id = :node_id;
