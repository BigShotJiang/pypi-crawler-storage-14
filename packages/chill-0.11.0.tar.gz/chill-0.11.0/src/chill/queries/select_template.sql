select t.id, t.name from Template as t where t.name = :name;
