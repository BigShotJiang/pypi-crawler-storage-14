DROP TABLE if exists Template;
