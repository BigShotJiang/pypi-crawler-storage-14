insert into Image (
    width,
    height,
    staticfile)
values (
    :width,
    :height,
    :staticfile);
