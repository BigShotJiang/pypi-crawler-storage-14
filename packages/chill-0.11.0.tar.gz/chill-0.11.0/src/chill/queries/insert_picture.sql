insert into Picture (
    picturename,
    title,
    description,
    author,
    created,
    image
) values (
    :picturename,
    :title,
    :description,
    :author,
    :created,
    :image);
