create table Template (
    id integer primary key,
    name varchar(255) unique not null
);
