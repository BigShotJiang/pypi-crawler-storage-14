# codefusion/core/scanner.py
import logging
from pathlib import Path
import typing as t

from .filter import FileFilter
from ..ignore.manager import IgnoreManager
from ..cache.manager import CacheManager

logger = logging.getLogger(__name__)

class FileScanner:
    def __init__(self, root_dir: Path, ignore_manager: IgnoreManager,
                 file_filter: FileFilter, include_dirs: t.Optional[t.List[str]] = None,
                 cache_manager: t.Optional[CacheManager] = None):
        self.root_dir = root_dir
        self.ignore_manager = ignore_manager
        self.file_filter = file_filter
        self.include_dirs = include_dirs
        self.cache_manager = cache_manager
        self.detected_extensions: t.Set[str] = set()

    def scan(self) -> t.Tuple[t.List[Path], t.Set[str]]:
        """
        Enhanced file collection with parallel processing and proper caching.
        """
        logger.info("Scanning directory and applying ignore rules...")
        candidate_files: t.List[Path] = []

        # Collect candidate files
        search_dirs = []
        if self.include_dirs:
            for inc_dir in self.include_dirs:
                current_dir = (self.root_dir / inc_dir).resolve()
                if current_dir.is_dir():
                    search_dirs.append(current_dir)
                else:
                    logger.warning(f"Directory not found: {current_dir}")
        else:
            search_dirs.append(self.root_dir)

        # Collect all files from search directories
        import os
        for search_dir in search_dirs:
            # Use os.walk for better control over directory traversal (pruning)
            # and error handling.
            for root, dirs, files in os.walk(str(search_dir), topdown=True):
                root_path = Path(root)
                
                # Check if current directory is excluded
                # If so, clear dirs to prevent descending further
                if self.ignore_manager.is_excluded(root_path):
                    dirs[:] = []
                    continue
                
                # Filter directories to traverse
                # We modify dirs in-place to prune the walk
                i = 0
                while i < len(dirs):
                    d_path = root_path / dirs[i]
                    # Check if directory is excluded
                    if self.ignore_manager.is_excluded(d_path):
                        # Remove from dirs so os.walk won't visit it
                        del dirs[i]
                    else:
                        i += 1
                
                # Process files in the current directory
                for file_name in files:
                    file_path = root_path / file_name
                    try:
                        # Check if file is excluded
                        if not self.ignore_manager.is_excluded(file_path):
                            candidate_files.append(file_path)
                    except OSError as e:
                        # Handle permission errors or other OS errors gracefully
                        logger.warning(f"Skipping file due to access error: {file_path} ({e})")
                        continue

        logger.info(f"Found {len(candidate_files)} candidate files after ignore rules.")

        # Filter text files (with parallel processing if we have many files)
        if len(candidate_files) > 100:
            text_files = self.file_filter.filter_text_files_parallel(candidate_files)
        else:
            text_files = self.file_filter.filter_text_files_sequential(candidate_files)
        
        logger.info(f"Found {len(text_files)} text files after binary filtering.")

        # Handle extensions
        if self.file_filter.user_extensions:
            target_extensions = self.file_filter.expand_extensions(self.file_filter.user_extensions)
            files_to_process = self.file_filter.filter_by_extensions(text_files, target_extensions)
        else:
            files_to_process = []
            for f in text_files:
                if self.file_filter.should_include_file(f):
                    files_to_process.append(f)
                    if f.suffix:
                        self.detected_extensions.add(f.suffix.lower())
                    else:
                        self.detected_extensions.add('[no extension]')
            target_extensions = self.detected_extensions

        logger.info(f"Final file count: {len(files_to_process)}")
        
        # Cleanup cache
        if self.cache_manager:
            self.cache_manager.cleanup()
            final_stats = self.cache_manager.get_stats()
            logger.debug(f"Cache cleanup: {final_stats['entry_count']} entries remaining, "
                        f"{final_stats['size_mb']:.2f}MB")
        
        return files_to_process, target_extensions
