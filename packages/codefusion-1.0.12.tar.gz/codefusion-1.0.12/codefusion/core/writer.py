# codefusion/core/writer.py
import logging
import sys
import typing as t
import json
import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeRemainingColumn, FileSizeColumn
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from .reader import read_file_content
from .grouper import FileGrouper
from ..templates import TemplateRenderer
from .. import __version__

logger = logging.getLogger(__name__)

class CodeWriter:
    def __init__(self, root_dir: Path, output_file: t.Optional[Path],
                 grouper: FileGrouper,
                 template: str = "default", no_grouping: bool = False,
                 to_stdout: bool = False, num_workers: int = 1):
        self.root_dir = root_dir
        self.output_file = output_file
        self.grouper = grouper
        self.template = template
        self.no_grouping = no_grouping
        self.to_stdout = to_stdout
        self.num_workers = num_workers
        self.renderer = TemplateRenderer()

    def write(self, files_to_process: t.List[Path], final_extensions: t.Set[str]) -> bool:
        total_files = len(files_to_process)

        if self.no_grouping:
            files_to_process.sort()
            grouped_files = [('all', files_to_process)]
        else:
            grouped_files = self.grouper.group_and_sort_files(files_to_process, self.root_dir)

        if self.output_file and self.output_file.exists() and not self.to_stdout:
            try:
                response = input(f"Output file '{self.output_file}' exists. Overwrite? (y/N): ")
                if response.lower() != 'y':
                    logger.info("Operation cancelled by user.")
                    return False
            except (EOFError, KeyboardInterrupt):
                logger.info("Operation cancelled by user.")
                return False

        processed_count = 0
        error_count = 0
        start_time = datetime.datetime.now()

        output_stream = self._setup_output_stream()
        if not output_stream:
            return False

        try:
            if self.template == 'json':
                self._write_json(output_stream, grouped_files, final_extensions, total_files, start_time)
            else:
                self._write_text(output_stream, grouped_files, final_extensions, total_files, start_time)

            return True

        except Exception as e:
            logger.error(f"❌ Fatal error during compilation: {e}")
            return False
        finally:
            if self.output_file and output_stream and not output_stream.closed:
                output_stream.close()

    def _setup_output_stream(self):
        if self.to_stdout:
            return sys.stdout
        elif self.output_file:
            self.output_file.parent.mkdir(parents=True, exist_ok=True)
            return self.output_file.open('w', encoding='utf-8')
        else:
            logger.error("No output destination specified")
            return None

    def _write_json(self, output_stream, grouped_files, final_extensions, total_files, start_time):
        # Note: True streaming JSON is complex because of the structure. 
        # We will build the structure but try to minimize holding file content in memory if possible.
        # However, standard json.dump requires the full object. 
        # For now, we update to handle the new reader signature.
        
        json_data = {}
        timestamp = start_time.strftime('%Y-%m-%d %H:%M:%S')
        extensions_str = ', '.join(sorted(final_extensions)) if final_extensions else 'Auto-detected'
        
        json_data['metadata'] = {
            'generated_at': timestamp,
            'source_directory': str(self.root_dir),
            'extensions': extensions_str,
            'total_files': total_files
        }
        
        json_data['groups'] = []
        processed_count = 0
        error_count = 0
        
        with ThreadPoolExecutor(max_workers=self.num_workers) as executor:
            for group_name, group_files in grouped_files:
                group_info = {
                    'group': group_name,
                    'description': self.grouper.get_group_description(group_name),
                    'file_count': len(group_files),
                    'files': []
                }
                
                future_to_file = {executor.submit(read_file_content, file_path): file_path for file_path in group_files}
                
                file_results = []
                for future in as_completed(future_to_file):
                    file_path = future_to_file[future]
                    try:
                        content, error_msg = future.result()
                        if error_msg:
                            error_count += 1
                            logger.error(f"Error processing {file_path.relative_to(self.root_dir).as_posix()}: {error_msg}")
                        else:
                            processed_count += 1
                            file_results.append({
                                'path': str(file_path.resolve()),
                                'content': content
                            })
                    except Exception as e:
                        logger.error(f"Error processing {file_path.relative_to(self.root_dir).as_posix()}: {e}")
                        error_count += 1
                
                file_results.sort(key=lambda x: x['path'])
                group_info['files'] = file_results
                json_data['groups'].append(group_info)

        completion_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        json_data['summary'] = {
            'processed_count': processed_count,
            'error_count': error_count,
            'completion_time': completion_time
        }
        
        output_stream.write(json.dumps(json_data, indent=2))

    def _write_text(self, output_stream, grouped_files, final_extensions, total_files, start_time):
        timestamp = start_time.strftime('%Y-%m-%d %H:%M:%S')
        extensions_str = ', '.join(sorted(final_extensions)) if final_extensions else 'Auto-detected'
        
        header = self.renderer.render_header(
            self.template,
            timestamp=timestamp,
            source_dir=self.root_dir,
            extensions=extensions_str,
            total_files=total_files
        )
        output_stream.write(header)

        logger.info(f"Compiling {total_files} files using {self.num_workers} workers...")
        
        processed_count = 0
        error_count = 0

        progress_columns = [
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeRemainingColumn(),
            FileSizeColumn(),
        ]

        with Progress(*progress_columns, transient=True) as progress:
            task = progress.add_task("Compiling...", total=total_files)

            for group_name, group_files in grouped_files:
                if not self.no_grouping:
                    group_description = self.grouper.get_group_description(group_name)
                    group_header = self.renderer.render_group_header(
                        self.template,
                        group_name,
                        group_description,
                        len(group_files)
                    )
                    output_stream.write(group_header)
                
                # Use map to process files in order and write immediately to save memory
                with ThreadPoolExecutor(max_workers=self.num_workers) as executor:
                    # group_files is already sorted by grouper.py
                    results = executor.map(self._read_and_format_file, group_files)
                    
                    for file_path, (file_output, error_msg) in zip(group_files, results):
                        rel_path_str = file_path.relative_to(self.root_dir).as_posix()
                        progress.update(task, advance=1, description=f"Processing [cyan]{rel_path_str}[/cyan]")
                        
                        if error_msg:
                            error_count += 1
                            logger.error(f"Error processing {rel_path_str}: {error_msg}")
                            # Optionally write error to output or skip
                            # For now, we skip content but maybe write a placeholder?
                            # The user wanted better error handling. 
                            # Let's write the error message into the file block so the LLM knows it's missing.
                            file_header = self.renderer.render_file_header(self.template, str(file_path.resolve()))
                            file_footer = self.renderer.render_file_footer(self.template)
                            output_stream.write(f"{file_header}\n[FAILED TO READ: {error_msg}]\n{file_footer}")
                        else:
                            processed_count += 1
                            output_stream.write(file_output)
                
                if not self.no_grouping and self.template == "json":
                    group_footer = self.renderer.render_group_footer(self.template)
                    output_stream.write(group_footer)

        completion_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        footer = self.renderer.render_footer(
            self.template,
            processed_count=processed_count,
            error_count=error_count,
            timestamp=completion_time
        )
        output_stream.write(footer)

        elapsed = datetime.datetime.now() - start_time
        if self.output_file:
            logger.info(f"✅ Compilation complete: {self.output_file.resolve()}")
        else:
            logger.info("✅ Compilation complete (output to stdout)")
        
        logger.info(f"📊 Processed {processed_count} files successfully in {elapsed.total_seconds():.2f}s")
        if error_count:
            logger.warning(f"⚠️  {error_count} files had read errors")

    def _read_and_format_file(self, file_path: Path) -> t.Tuple[t.Optional[str], t.Optional[str]]:
        abs_path_str = str(file_path.resolve())
        
        content, error_msg = read_file_content(file_path)
        
        if error_msg:
            return None, error_msg
            
        file_header = self.renderer.render_file_header(self.template, abs_path_str)
        file_footer = self.renderer.render_file_footer(self.template)
        
        formatted_content = f"{file_header}{content}{file_footer}"
        
        return formatted_content, None
