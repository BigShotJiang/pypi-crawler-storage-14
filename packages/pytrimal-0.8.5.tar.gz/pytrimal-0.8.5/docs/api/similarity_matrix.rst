SimilarityMatrix
================

.. currentmodule:: pytrimal


.. autoclass:: pytrimal.SimilarityMatrix(scoring_matrices.ScoringMatrix)
   :special-members: __init__
   :members:
