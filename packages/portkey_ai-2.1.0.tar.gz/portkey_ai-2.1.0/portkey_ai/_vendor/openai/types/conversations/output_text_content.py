# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..responses.response_output_text import ResponseOutputText

__all__ = ["OutputTextContent"]

OutputTextContent = ResponseOutputText
