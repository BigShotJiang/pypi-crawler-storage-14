import sys
def log(msg: str):
    print(msg)
    sys.stdout.flush()
