import pims
PyAVVideoReader = pims.PyAVVideoReader