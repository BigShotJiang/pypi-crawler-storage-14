# json-to-toon

json-to-toon is a simple, reliable Python library for converting data between JSON and TOON (TOML-style) formats. Install via `pip install json-to-toon` and import as `json_to_toon`. It offers clean APIs, fast conversions, and a handy CLI, making it ideal for configuration files, automation workflows, and projects needing seamless cross-format compatibility.

## Installation

```bash
pip install json-to-toon
```

## Usage

Install with `pip install json-to-toon`, then import with `from json_to_toon import ...`:

```python
from json_to_toon import to_toon, to_json

data = {
    "title": "My Config",
    "owner": {"name": "Admin", "id": 55},
}

toon_output = to_toon(data)
print(toon_output)

# Convert TOON string back to JSON
json_output = to_json(toon_output)
print(json_output)
```

## CLI

Use the bundled CLI to convert files by extension:

```bash
j2t input.json output.toon
j2t settings.toon output.json
```
