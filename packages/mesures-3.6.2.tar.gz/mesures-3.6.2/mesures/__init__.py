# -*- coding: utf-8 -*-
__version__ = '3.6.2'
__author__ = 'GISCE-TI S.L.'
