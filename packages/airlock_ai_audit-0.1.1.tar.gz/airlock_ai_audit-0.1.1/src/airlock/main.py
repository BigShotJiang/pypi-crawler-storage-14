import os
import sys
import subprocess
import typer
from rich.console import Console
from rich.markdown import Markdown
from openai import OpenAI
from dotenv import load_dotenv

# 1. Initialize the App
app = typer.Typer()
console = Console()
load_dotenv()


# 2. Helper Function: Get the Diff
def get_git_diff(branch: str = None):
    try:
        if branch:
            command = ["git", "diff", branch]
        else:
            command = ["git", "diff", "--staged"]
            
        result = subprocess.run(
            command, 
            capture_output=True, 
            text=True, 
            check=True,
            encoding="utf-8" # Fix for Windows emojis
        )
        return result.stdout
    except subprocess.CalledProcessError:
        console.print("[bold red]Error:[/bold red] Git command failed.")
        sys.exit(1)

# 3. Helper Function: Talk to AI
def analyze_with_ai(diff_text):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        console.print("[bold red]Error:[/bold red] OPENAI_API_KEY not found.")
        sys.exit(1)

    client = OpenAI(api_key=api_key)

    system_prompt = """
    You are a Senior Code Reviewer. Analyze the provided git diff.
    1. Summarize what changed in 1-2 sentences.
    2. Explain the "Why" behind the change if possible.
    3. ALERT: If you see hardcoded secrets, temporary debug code, or security risks.
    Format your response in simple Markdown.
    """

    user_prompt = f"Here is the git diff:\n\n{diff_text}"

    with console.status("[bold green]Consulting the AI agent...[/bold green]"):
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
        )
    
    return response.choices[0].message.content

# 4. The Command: Audit
@app.command()
def audit(branch: str = typer.Option(None, help="The branch to compare against")):
    """
    Run the AI audit.
    """
    console.print(f"[bold blue]🚀 Airlock: Starting Audit...[/bold blue]")
    
    diff = get_git_diff(branch)
    
    if not diff:
        console.print("[yellow]No changes found.[/yellow]")
        return

    try:
        summary = analyze_with_ai(diff)
        console.print("\n[bold]---------------- REPORT ----------------[/bold]\n")
        console.print(Markdown(summary))
        console.print("\n[bold]----------------------------------------[/bold]")

        # --- GATEKEEPER LOGIC (HARD STOP) ---
        if not typer.confirm("\n👮 Airlock: Do you want to proceed with this commit?"):
            console.print("[bold red]❌ Commit aborted by user.[/bold red]")
            sys.exit(1) # <--- THIS STOPS GIT

    except Exception as e:
        console.print(f"[bold red]An error occurred:[/bold red] {e}")
        sys.exit(1)

if __name__ == "__main__":
    app()