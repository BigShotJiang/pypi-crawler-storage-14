"""
    Package Anson.py3
    semantic share: Anson.java_src('anson')
    @since 0.2.6

    About
    =====
    This is a shared namespace for all semantics-*'s projects.

"""