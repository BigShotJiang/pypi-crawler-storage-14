# version.py

__version__ = "0.7.6"
