from wp21_train.utils.version import __version__
from .base_callback           import base_callback

__all__ = ["base_callback", "__version__"]
