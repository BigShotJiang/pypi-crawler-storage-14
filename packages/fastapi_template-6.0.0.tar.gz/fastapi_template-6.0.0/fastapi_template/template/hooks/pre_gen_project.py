"""
Pre generation hooks
"""