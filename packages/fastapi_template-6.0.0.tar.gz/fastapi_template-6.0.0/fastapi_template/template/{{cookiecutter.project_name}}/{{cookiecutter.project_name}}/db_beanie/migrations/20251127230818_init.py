class Forward:
    """Forward migrations."""


class Backward:
    """Backward migrations."""
