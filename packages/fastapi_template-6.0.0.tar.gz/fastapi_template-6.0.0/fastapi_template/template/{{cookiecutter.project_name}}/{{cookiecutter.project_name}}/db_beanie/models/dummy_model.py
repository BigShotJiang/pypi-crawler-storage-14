from beanie import Document

class DummyModel(Document):
    """Model for demo purpose."""
    name: str