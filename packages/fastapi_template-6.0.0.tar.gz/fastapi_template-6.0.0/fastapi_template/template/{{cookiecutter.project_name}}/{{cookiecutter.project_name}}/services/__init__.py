"""Services for {{cookiecutter.project_name}}."""
