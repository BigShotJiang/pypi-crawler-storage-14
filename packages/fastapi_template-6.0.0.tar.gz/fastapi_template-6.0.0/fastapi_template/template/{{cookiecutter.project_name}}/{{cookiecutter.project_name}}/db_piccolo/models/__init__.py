"""{{cookiecutter.project_name}} models."""
