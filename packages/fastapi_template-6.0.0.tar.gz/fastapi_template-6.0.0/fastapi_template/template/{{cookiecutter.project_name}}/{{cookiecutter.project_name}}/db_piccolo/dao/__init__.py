"""{{cookiecutter.project_name}} DAOs."""
