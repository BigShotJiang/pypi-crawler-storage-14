"""{{cookiecutter.project_name}} package."""
