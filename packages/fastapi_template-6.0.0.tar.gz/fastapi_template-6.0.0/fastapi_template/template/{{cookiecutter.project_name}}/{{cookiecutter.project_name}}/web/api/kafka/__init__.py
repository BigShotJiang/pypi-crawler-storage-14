"""API to interact with kafka."""
from {{cookiecutter.project_name}}.web.api.kafka.views import router

__all__ = ["router"]
