"""{{cookiecutter.project_name}} API package."""
