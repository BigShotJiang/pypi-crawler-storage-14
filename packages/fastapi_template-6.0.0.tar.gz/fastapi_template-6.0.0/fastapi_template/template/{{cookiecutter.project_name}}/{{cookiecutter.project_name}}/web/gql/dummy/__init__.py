"""Package for dummy model."""

from {{cookiecutter.project_name}}.web.gql.dummy.mutation import Mutation
from {{cookiecutter.project_name}}.web.gql.dummy.query import Query

__all__ = ["Query", "Mutation"]
