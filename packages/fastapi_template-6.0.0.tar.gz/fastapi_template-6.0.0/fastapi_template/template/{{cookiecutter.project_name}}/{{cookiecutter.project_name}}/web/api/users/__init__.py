"""API for checking project status."""
from {{cookiecutter.project_name}}.web.api.users.views import router

__all__ = ["router"]
