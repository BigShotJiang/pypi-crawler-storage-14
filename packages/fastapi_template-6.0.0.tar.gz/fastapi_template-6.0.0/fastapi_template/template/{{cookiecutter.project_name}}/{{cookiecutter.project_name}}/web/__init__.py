"""WEB API for {{cookiecutter.project_name}}."""
