"""API to interact with RabbitMQ."""
from {{cookiecutter.project_name}}.web.api.rabbit.views import router

__all__ = ["router"]
