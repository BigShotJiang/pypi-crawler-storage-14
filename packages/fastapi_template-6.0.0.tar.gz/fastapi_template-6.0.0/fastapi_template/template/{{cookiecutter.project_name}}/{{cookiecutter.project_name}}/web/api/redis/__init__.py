"""Redis API."""
from {{cookiecutter.project_name}}.web.api.redis.views import router

__all__ = ['router']
