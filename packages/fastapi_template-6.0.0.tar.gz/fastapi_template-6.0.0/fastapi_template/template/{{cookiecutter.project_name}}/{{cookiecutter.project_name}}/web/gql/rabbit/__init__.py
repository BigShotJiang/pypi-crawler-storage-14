"""Package to interact with rabbitMQ."""
from {{cookiecutter.project_name}}.web.gql.rabbit.mutation import Mutation

__all__ = ["Mutation"]
