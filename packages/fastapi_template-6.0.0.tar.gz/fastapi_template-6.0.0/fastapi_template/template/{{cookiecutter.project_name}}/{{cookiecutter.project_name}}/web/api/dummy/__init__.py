"""Dummy model API."""
from {{cookiecutter.project_name}}.web.api.dummy.views import router

__all__ = ['router']
