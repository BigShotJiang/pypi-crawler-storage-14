"""API for checking project status."""
from {{cookiecutter.project_name}}.web.api.monitoring.views import router

__all__ = ['router']
