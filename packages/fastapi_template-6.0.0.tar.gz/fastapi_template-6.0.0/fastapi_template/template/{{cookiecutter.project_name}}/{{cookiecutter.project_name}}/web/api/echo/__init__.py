"""Echo API."""
from {{cookiecutter.project_name}}.web.api.echo.views import router

__all__ = ['router']
