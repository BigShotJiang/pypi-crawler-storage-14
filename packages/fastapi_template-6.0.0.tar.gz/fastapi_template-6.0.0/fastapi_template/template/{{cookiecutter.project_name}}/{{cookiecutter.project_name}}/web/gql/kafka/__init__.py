"""Package to interact with kafka."""
from {{cookiecutter.project_name}}.web.gql.kafka.mutation import Mutation

__all__ = ["Mutation"]
