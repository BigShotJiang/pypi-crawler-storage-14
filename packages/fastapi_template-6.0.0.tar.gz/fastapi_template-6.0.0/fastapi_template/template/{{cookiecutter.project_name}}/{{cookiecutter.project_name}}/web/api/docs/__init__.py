"""Routes for swagger and redoc."""
from {{cookiecutter.project_name}}.web.api.docs.views import router

__all__ = ['router']
