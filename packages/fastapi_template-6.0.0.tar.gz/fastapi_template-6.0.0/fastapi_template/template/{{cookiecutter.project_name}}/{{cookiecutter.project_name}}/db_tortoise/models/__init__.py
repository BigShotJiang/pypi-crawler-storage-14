"""Models for {{cookiecutter.project_name}}."""
