"""Initial migration.

Revision ID: 819cbf6e030b
Revises:
Create Date: 2021-08-16 16:53:05.484024

"""


# revision identifiers, used by Alembic.
revision = "819cbf6e030b"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Run the upgrade migrations."""
    pass


def downgrade() -> None:
    """Run the downgrade migrations."""
    pass
