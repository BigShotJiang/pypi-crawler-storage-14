"""Tests for {{cookiecutter.project_name}}."""
