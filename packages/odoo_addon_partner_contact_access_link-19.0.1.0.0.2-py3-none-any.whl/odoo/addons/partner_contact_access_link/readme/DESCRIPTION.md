This module extends the functionality of the partners form and to allow
you to click on a button and open the full contact form while watching a
company form.
