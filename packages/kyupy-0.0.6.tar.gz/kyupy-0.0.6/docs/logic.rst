Multi-Valued Logic - :mod:`kyupy.logic`
=======================================

.. automodule:: kyupy.logic
   :members:


