.. include:: ../README.md
   :parser: myst_parser.sphinx_

API Reference
-------------

.. toctree::
   :maxdepth: 1

   circuit
   logic
   techlib
   parsers
   simulators
   miscellaneous

