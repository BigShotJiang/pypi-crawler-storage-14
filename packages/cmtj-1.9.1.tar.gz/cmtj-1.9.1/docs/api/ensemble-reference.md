# Ensemble functions

This module contains functions for computing simple fits and models.

::: cmtj.models.ensemble
