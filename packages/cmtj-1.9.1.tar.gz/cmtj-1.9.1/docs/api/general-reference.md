# Miscellaneous Utilities

Contains definition of a base vector object used in the models such as Domain Wall Dynamics or Smit-Beljers model.

::: cmtj.utils.general
