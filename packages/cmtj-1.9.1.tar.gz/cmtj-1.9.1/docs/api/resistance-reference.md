# Resistance functions

Those functions are used to compute the resistance of a given system.
They are all defined in the `resistance` module for version upside of 1.2.0.

::: cmtj.utils.resistance
