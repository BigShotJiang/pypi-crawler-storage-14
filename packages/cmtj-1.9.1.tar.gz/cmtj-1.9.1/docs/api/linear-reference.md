::: cmtj.utils.linear
