This module contains the basic implementation of the Smit-Beljers model. The model is based on the following paper which introduced a corrected model:
Rodríguez-Suárez et al.,
"Ferromagnetic resonance investigation of the residual coupling in spin-valve systems"
10.1103/PhysRevB.71.224406

::: cmtj.models.general_sb
