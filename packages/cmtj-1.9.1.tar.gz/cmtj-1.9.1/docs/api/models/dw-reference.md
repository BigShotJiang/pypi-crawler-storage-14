::: cmtj.models.domain_dynamics
