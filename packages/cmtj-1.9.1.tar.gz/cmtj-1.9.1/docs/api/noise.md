::: cmtj.noise
