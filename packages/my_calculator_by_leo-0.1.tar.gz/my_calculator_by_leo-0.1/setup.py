from setuptools import setup, find_packages

setup(
    name='my_calculator_by_leo',      # Название библиотеки
    version='0.1',             # Версия
    packages=find_packages(),  # Автоматически находит все пакеты
    install_requires=[],       # Если есть зависимости, их можно указать здесь
    author='Leonsii',        # Ваше имя
    author_email='your.email@example.com',  # Ваш email
    description='A simple Python calculator library for basic arithmetic operations.',
    long_description=open('README.md').read(),  # Описание библиотеки
    long_description_content_type='text/markdown',
    url='https://github.com/Leo9siy/scratch_item_task',  # Ссылка на репозиторий
)