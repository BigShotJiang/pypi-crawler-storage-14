def add(*args, **kwargs):
    """Sum of items"""

    return sum(args) + sum(kwargs.values())
