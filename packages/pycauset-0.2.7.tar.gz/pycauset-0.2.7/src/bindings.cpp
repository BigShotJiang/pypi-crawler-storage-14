#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include <fstream>
#include <filesystem>
#include "TriangularBitMatrix.hpp"
#include "DenseMatrix.hpp"
#include "DenseBitMatrix.hpp"
#include "DenseVector.hpp"
#include "TriangularMatrix.hpp"
#include "IdentityMatrix.hpp"
#include "StoragePaths.hpp"
#include "FileFormat.hpp"
#include "MatrixOperations.hpp"
#include "PersistentObject.hpp"
#include "ComplexMatrix.hpp"

namespace py = pybind11;

using FloatMatrix = DenseMatrix<double>;
using IntegerMatrix = DenseMatrix<int32_t>;
using DenseBitMatrix = DenseMatrix<bool>;
using FloatVector = DenseVector<double>;
using IntegerVector = DenseVector<int32_t>;
using BitVector = DenseVector<bool>;
using TriangularFloatMatrix = TriangularMatrix<double>;
using TriangularIntegerMatrix = TriangularMatrix<int32_t>;
using TriangularBitMatrix = TriangularMatrix<bool>;

using pycauset::make_unique_storage_file;

namespace {

// Forward declaration
std::unique_ptr<PersistentObject> from_numpy(py::object obj);
std::unique_ptr<MatrixBase> dispatch_matmul(const MatrixBase& a, const MatrixBase& b, std::string saveas);

// Helper functions and bind_arithmetic moved to PYBIND11_MODULE


// bind_vector_arithmetic and bind_arithmetic moved to PYBIND11_MODULE


// Dispatcher
std::unique_ptr<MatrixBase> dispatch_matmul(const MatrixBase& a, const MatrixBase& b, std::string saveas) {
    if (saveas.empty()) saveas = make_unique_storage_file("matmul");

    // Try to cast to known types
    auto* a_fm = dynamic_cast<const FloatMatrix*>(&a);
    auto* a_im = dynamic_cast<const IntegerMatrix*>(&a);
    auto* a_tfm = dynamic_cast<const TriangularFloatMatrix*>(&a);
    auto* a_tim = dynamic_cast<const TriangularIntegerMatrix*>(&a);
    auto* a_tbm = dynamic_cast<const TriangularBitMatrix*>(&a);
    auto* a_id = dynamic_cast<const IdentityMatrix*>(&a);

    auto* b_fm = dynamic_cast<const FloatMatrix*>(&b);
    auto* b_im = dynamic_cast<const IntegerMatrix*>(&b);
    auto* b_tfm = dynamic_cast<const TriangularFloatMatrix*>(&b);
    auto* b_tim = dynamic_cast<const TriangularIntegerMatrix*>(&b);
    auto* b_tbm = dynamic_cast<const TriangularBitMatrix*>(&b);
    auto* b_id = dynamic_cast<const IdentityMatrix*>(&b);

    // Identity x Identity -> Identity
    if (a_id && b_id) {
        return a_id->multiply(*b_id, saveas);
    }

    // If either is FloatMatrix (Dense<double>), result is FloatMatrix
    if (a_fm || b_fm) {
        // We need to implement mixed multiplication for all combinations.
        // For now, we can rely on DenseMatrix<double>::multiply which might handle templates if we implemented it.
        // But DenseMatrix::multiply expects DenseMatrix<T>.
        // We haven't implemented generic mixed multiply in DenseMatrix.hpp yet.
        // We only implemented multiply(const DenseMatrix<T>&).
        
        // Fallback: Convert both to FloatMatrix and multiply?
        // Or implement specific dispatch here.
        // Given the complexity, let's throw for mixed types not explicitly supported, 
        // or implement a slow fallback using get_element_as_double.
        
        // Implementing slow fallback for now to ensure correctness over speed for mixed types.
        // Ideally we would have optimized kernels.
        
        // Actually, let's just support FloatMatrix x FloatMatrix for now, and maybe others if easy.
        if (a_fm && b_fm) return a_fm->multiply(*b_fm, saveas);
        
        // TODO: Implement mixed kernels or conversion.
        throw std::runtime_error("Mixed Dense/Triangular multiplication not yet optimized. Convert to Dense first.");
    }

    // IntegerMatrix x IntegerMatrix
    if (a_im && b_im) return a_im->multiply(*b_im, saveas);

    // TriangularBitMatrix x TriangularBitMatrix -> TriangularIntegerMatrix
    if (a_tbm && b_tbm) return a_tbm->multiply(*b_tbm, saveas);

    // TriangularFloatMatrix x TriangularFloatMatrix -> TriangularFloatMatrix
    // We need to implement multiply for TriangularMatrix<T>.
    // Currently only TriangularMatrix<bool> has multiply implemented in .cpp.
    // TriangularMatrix<T> in .hpp doesn't have multiply implemented?
    // Wait, I didn't check TriangularMatrix.hpp for multiply implementation.
    // I should check.
    
    throw std::runtime_error("Unsupported matrix multiplication types.");
}

std::unique_ptr<PersistentObject> from_numpy(py::object obj) {
    if (!py::isinstance<py::array>(obj)) {
        try {
            obj = py::array(obj);
        } catch (...) {
            return nullptr;
        }
    }
    
    py::array arr = py::cast<py::array>(obj);
    auto info = arr.request();
    
    if (info.ndim == 1) {
        uint64_t n = info.shape[0];
        if (py::isinstance<py::array_t<double>>(arr)) {
            auto v = std::make_unique<FloatVector>(n, make_unique_storage_file("numpy_vec_float"));
            auto ptr = static_cast<double*>(info.ptr);
            for (uint64_t i = 0; i < n; ++i) v->set(i, ptr[i]);
            return v;
        } else if (py::isinstance<py::array_t<int32_t>>(arr) || py::isinstance<py::array_t<int64_t>>(arr)) {
            auto v = std::make_unique<IntegerVector>(n, make_unique_storage_file("numpy_vec_int"));
            if (info.format == "i" || info.format == "l") {
                 if (py::isinstance<py::array_t<int64_t>>(arr)) {
                     auto unchecked = arr.unchecked<int64_t, 1>();
                     for (uint64_t i = 0; i < n; ++i) v->set(i, (int32_t)unchecked(i));
                 } else {
                     auto unchecked = arr.unchecked<int32_t, 1>();
                     for (uint64_t i = 0; i < n; ++i) v->set(i, unchecked(i));
                 }
            }
            return v;
        } else if (py::isinstance<py::array_t<bool>>(arr)) {
            auto v = std::make_unique<BitVector>(n, make_unique_storage_file("numpy_vec_bool"));
            auto unchecked = arr.unchecked<bool, 1>();
            for (uint64_t i = 0; i < n; ++i) v->set(i, unchecked(i));
            return v;
        }
    } else if (info.ndim == 2) {
        if (info.shape[0] != info.shape[1]) {
            throw std::invalid_argument("Only square matrices are supported for now");
        }
        uint64_t n = info.shape[0];
        
        if (py::isinstance<py::array_t<double>>(arr)) {
            auto m = std::make_unique<FloatMatrix>(n, make_unique_storage_file("numpy_mat_float"));
            auto unchecked = arr.unchecked<double, 2>();
            for (uint64_t i = 0; i < n; ++i) {
                for (uint64_t j = 0; j < n; ++j) {
                    m->set(i, j, unchecked(i, j));
                }
            }
            return m;
        } else if (py::isinstance<py::array_t<int32_t>>(arr) || py::isinstance<py::array_t<int64_t>>(arr)) {
            auto m = std::make_unique<IntegerMatrix>(n, make_unique_storage_file("numpy_mat_int"));
            if (py::isinstance<py::array_t<int64_t>>(arr)) {
                auto unchecked = arr.unchecked<int64_t, 2>();
                for (uint64_t i = 0; i < n; ++i) {
                    for (uint64_t j = 0; j < n; ++j) {
                        m->set(i, j, (int32_t)unchecked(i, j));
                    }
                }
            } else {
                auto unchecked = arr.unchecked<int32_t, 2>();
                for (uint64_t i = 0; i < n; ++i) {
                    for (uint64_t j = 0; j < n; ++j) {
                        m->set(i, j, unchecked(i, j));
                    }
                }
            }
            return m;
        } else if (py::isinstance<py::array_t<bool>>(arr)) {
            auto m = std::make_unique<DenseBitMatrix>(n, make_unique_storage_file("numpy_mat_bool"));
            auto unchecked = arr.unchecked<bool, 2>();
            for (uint64_t i = 0; i < n; ++i) {
                for (uint64_t j = 0; j < n; ++j) {
                    m->set(i, j, unchecked(i, j));
                }
            }
            return m;
        }
    }
    return nullptr;
}

bool coerce_bool_like(py::object value) {
    if (py::isinstance<py::bool_>(value)) {
        return py::cast<bool>(value);
    }
    if (py::isinstance<py::int_>(value)) {
        long long v = py::cast<long long>(value);
        if (v == 0 || v == 1) {
            return v == 1;
        }
        throw py::type_error("Integer assignments must be 0 or 1.");
    }
    if (py::isinstance<py::float_>(value)) {
        double v = py::cast<double>(value);
        if (v == 0.0 || v == 1.0) {
            return v == 1.0;
        }
        throw py::type_error("Float assignments must be 0.0 or 1.0.");
    }
    throw py::type_error("BitMatrix entries accept bool, 0/1, or 0.0/1.0 values.");
}

} // namespace

PYBIND11_MODULE(pycauset, m) {
    m.doc() = "pycauset Python Interface";

    // Helper lambdas for casting unique_ptr results to python objects
    auto cast_matrix_result = [](std::unique_ptr<MatrixBase> res) -> py::object {
        if (auto* m = dynamic_cast<FloatMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        if (auto* m = dynamic_cast<IntegerMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        if (auto* m = dynamic_cast<DenseBitMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        if (auto* m = dynamic_cast<TriangularFloatMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        if (auto* m = dynamic_cast<TriangularIntegerMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        if (auto* m = dynamic_cast<TriangularBitMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        if (auto* m = dynamic_cast<IdentityMatrix*>(res.get())) {
            res.release();
            return py::cast(m, py::return_value_policy::take_ownership);
        }
        
        throw std::runtime_error("Unknown MatrixBase subclass in cast_matrix_result");
    };

    auto cast_vector_result = [](std::unique_ptr<VectorBase> res) -> py::object {
        if (auto* v = dynamic_cast<FloatVector*>(res.get())) {
            res.release();
            return py::cast(v, py::return_value_policy::take_ownership);
        }
        if (auto* v = dynamic_cast<IntegerVector*>(res.get())) {
            res.release();
            return py::cast(v, py::return_value_policy::take_ownership);
        }
        if (auto* v = dynamic_cast<BitVector*>(res.get())) {
            res.release();
            return py::cast(v, py::return_value_policy::take_ownership);
        }
            
        throw std::runtime_error("Unknown VectorBase subclass in cast_vector_result");
    };

    auto bind_vector_arithmetic = [&](auto& cls) {
        using T = typename std::remove_reference_t<decltype(cls)>::type;
        cls.def("__add__", [](const T& self, py::object other) {
            if (py::isinstance<VectorBase>(other)) {
                return pycauset::add_vectors(self, py::cast<const VectorBase&>(other), make_unique_storage_file("add_vector"));
            }
            auto temp = from_numpy(other);
            if (auto* v = dynamic_cast<VectorBase*>(temp.get())) {
                return pycauset::add_vectors(self, *v, make_unique_storage_file("add_vector"));
            }
            try {
                double s = py::cast<double>(other);
                return pycauset::scalar_add_vector(self, s, make_unique_storage_file("add_scalar_vector"));
            } catch (...) {}
            
            throw py::type_error("Unsupported operand type for +");
        });
        cls.def("__radd__", [](const T& self, py::object other) {
            if (py::isinstance<VectorBase>(other)) {
                return pycauset::add_vectors(self, py::cast<const VectorBase&>(other), make_unique_storage_file("add_vector"));
            }
            auto temp = from_numpy(other);
            if (auto* v = dynamic_cast<VectorBase*>(temp.get())) {
                return pycauset::add_vectors(self, *v, make_unique_storage_file("add_vector"));
            }
            try {
                double s = py::cast<double>(other);
                return pycauset::scalar_add_vector(self, s, make_unique_storage_file("add_scalar_vector"));
            } catch (...) {}
            throw py::type_error("Unsupported operand type for +");
        });
        cls.def("__sub__", [](const T& self, py::object other) {
            if (py::isinstance<VectorBase>(other)) {
                return pycauset::subtract_vectors(self, py::cast<const VectorBase&>(other), make_unique_storage_file("sub_vector"));
            }
            auto temp = from_numpy(other);
            if (auto* v = dynamic_cast<VectorBase*>(temp.get())) {
                return pycauset::subtract_vectors(self, *v, make_unique_storage_file("sub_vector"));
            }
            throw py::type_error("Unsupported operand type for -");
        });
        cls.def("__mul__", [](const T& self, py::object other) {
            try {
                double s = py::cast<double>(other);
                return pycauset::scalar_multiply_vector(self, s, make_unique_storage_file("mul_vector"));
            } catch (...) {}
            throw py::type_error("Unsupported operand type for * (Vector supports scalar multiplication only)");
        });
        cls.def("__rmul__", [](const T& self, py::object other) {
            try {
                double s = py::cast<double>(other);
                return pycauset::scalar_multiply_vector(self, s, make_unique_storage_file("mul_vector"));
            } catch (...) {}
            throw py::type_error("Unsupported operand type for *");
        });
        cls.def("dot", [](const T& self, py::object other) {
            if (py::isinstance<VectorBase>(other)) {
                return pycauset::dot_product(self, py::cast<const VectorBase&>(other));
            }
            auto temp = from_numpy(other);
            if (auto* v = dynamic_cast<VectorBase*>(temp.get())) {
                return pycauset::dot_product(self, *v);
            }
            throw py::type_error("Unsupported operand type for dot");
        });
        cls.def("__matmul__", [cast_matrix_result, cast_vector_result](const T& self, py::object other) -> py::object {
            if (py::isinstance<VectorBase>(other)) {
                const auto& other_vec = py::cast<const VectorBase&>(other);
                bool self_t = self.is_transposed();
                bool other_t = other_vec.is_transposed();
                
                if (!self_t && other_t) {
                    auto res = pycauset::outer_product(self, other_vec, make_unique_storage_file("outer"));
                    return cast_matrix_result(std::move(res));
                } else {
                    // Inner product
                    bool self_is_int = (py::isinstance<IntegerVector>(py::cast(self)) || py::isinstance<BitVector>(py::cast(self)));
                    bool other_is_int = (py::isinstance<IntegerVector>(py::cast(other_vec)) || py::isinstance<BitVector>(py::cast(other_vec)));
                    
                    double val = pycauset::dot_product(self, other_vec);
                    if (self_is_int && other_is_int) {
                        return py::cast((int64_t)val);
                    }
                    return py::cast(val);
                }
            }
            if (py::isinstance<MatrixBase>(other)) {
                auto res = pycauset::vector_matrix_multiply(self, py::cast<const MatrixBase&>(other), make_unique_storage_file("vec_mat_mul"));
                return cast_vector_result(std::move(res));
            }
            
            auto temp = from_numpy(other);
            if (auto* v = dynamic_cast<VectorBase*>(temp.get())) {
                const auto& other_vec = *v;
                bool self_t = self.is_transposed();
                bool other_t = other_vec.is_transposed();
                
                if (!self_t && other_t) {
                    auto res = pycauset::outer_product(self, other_vec, make_unique_storage_file("outer"));
                    return cast_matrix_result(std::move(res));
                } else {
                    double val = pycauset::dot_product(self, other_vec);
                    return py::cast(val);
                }
            }
            if (auto* m = dynamic_cast<MatrixBase*>(temp.get())) {
                auto res = pycauset::vector_matrix_multiply(self, *m, make_unique_storage_file("vec_mat_mul"));
                return cast_vector_result(std::move(res));
            }

            throw py::type_error("Unsupported operand type for @");
        });
        
        // NumPy export
        cls.def("__array__", [](const T& self, py::object dtype, py::object copy) {
            uint64_t n = self.size();
            if constexpr (std::is_same_v<T, BitVector>) {
                py::array_t<bool> result(n);
                auto ptr = result.mutable_unchecked<1>();
                for (py::ssize_t i = 0; i < (py::ssize_t)n; ++i) {
                    ptr(i) = self.get(i);
                }
                return result;
            } else if constexpr (std::is_same_v<T, IntegerVector>) {
                py::array_t<int32_t> result(n);
                auto ptr = result.mutable_unchecked<1>();
                for (py::ssize_t i = 0; i < (py::ssize_t)n; ++i) {
                    ptr(i) = self.get(i);
                }
                return result;
            } else {
                py::array_t<double> result(n);
                auto ptr = result.mutable_unchecked<1>();
                for (py::ssize_t i = 0; i < (py::ssize_t)n; ++i) {
                    ptr(i) = self.get_element_as_double(i);
                }
                return result;
            }
        }, py::arg("dtype") = py::none(), py::arg("copy") = py::none());
    };

    auto bind_arithmetic = [&](auto& cls) {
        using T = typename std::remove_reference_t<decltype(cls)>::type;
        cls.def("__add__", [](const T& self, py::object other) {
            if (py::isinstance<MatrixBase>(other)) {
                return pycauset::add(self, py::cast<const MatrixBase&>(other), make_unique_storage_file("add"));
            }
            auto temp = from_numpy(other);
            if (auto* m = dynamic_cast<MatrixBase*>(temp.get())) {
                return pycauset::add(self, *m, make_unique_storage_file("add"));
            }
            throw py::type_error("Unsupported operand type for +");
        });
        cls.def("__sub__", [](const T& self, py::object other) {
            if (py::isinstance<MatrixBase>(other)) {
                return pycauset::subtract(self, py::cast<const MatrixBase&>(other), make_unique_storage_file("sub"));
            }
            auto temp = from_numpy(other);
            if (auto* m = dynamic_cast<MatrixBase*>(temp.get())) {
                return pycauset::subtract(self, *m, make_unique_storage_file("sub"));
            }
            throw py::type_error("Unsupported operand type for -");
        });
        cls.def("__mul__", [](const T& self, py::object other) {
            if (py::isinstance<MatrixBase>(other)) {
                return pycauset::elementwise_multiply(self, py::cast<const MatrixBase&>(other), make_unique_storage_file("mul"));
            }
            try {
                double s = py::cast<double>(other);
                return self.multiply_scalar(s, make_unique_storage_file("scalar_mul"));
            } catch (...) {}
            
            auto temp = from_numpy(other);
            if (auto* m = dynamic_cast<MatrixBase*>(temp.get())) {
                return pycauset::elementwise_multiply(self, *m, make_unique_storage_file("mul"));
            }
            throw py::type_error("Unsupported operand type for *");
        });
        cls.def("__rmul__", [](const T& self, double scalar) {
            return self.multiply_scalar(scalar, make_unique_storage_file("scalar_mul"));
        });
        cls.def("__rmul__", [](const T& self, int64_t scalar) {
            return self.multiply_scalar(scalar, make_unique_storage_file("scalar_mul"));
        });
        cls.def("__matmul__", [cast_matrix_result, cast_vector_result](const T& self, py::object other) -> py::object {
            if (py::isinstance<VectorBase>(other)) {
                auto res = pycauset::matrix_vector_multiply(self, py::cast<const VectorBase&>(other), make_unique_storage_file("mat_vec_mul"));
                return cast_vector_result(std::move(res));
            }
            
            if (py::isinstance<MatrixBase>(other)) {
                auto res = dispatch_matmul(self, py::cast<const MatrixBase&>(other), "");
                return cast_matrix_result(std::move(res));
            }
            
            auto temp = from_numpy(other);
            if (auto* v = dynamic_cast<VectorBase*>(temp.get())) {
                auto res = pycauset::matrix_vector_multiply(self, *v, make_unique_storage_file("mat_vec_mul"));
                return cast_vector_result(std::move(res));
            }
            if (auto* m = dynamic_cast<MatrixBase*>(temp.get())) {
                auto res = dispatch_matmul(self, *m, "");
                return cast_matrix_result(std::move(res));
            }
            throw py::type_error("Unsupported operand type for @");
        });
        cls.def_property_readonly("T", [](const T& self) {
            return self.transpose(make_unique_storage_file("transpose"));
        });
        cls.def_property_readonly("H", [](const T& self) {
            return self.transpose(make_unique_storage_file("hermitian"));
        });
        
        // NumPy export
        cls.def("__array__", [](const T& self, py::object dtype, py::object copy) {
            uint64_t n = self.size();
            if constexpr (std::is_same_v<T, DenseBitMatrix> || std::is_same_v<T, TriangularBitMatrix>) {
                py::array_t<bool> result({n, n});
                auto ptr = result.mutable_unchecked<2>();
                for (py::ssize_t i = 0; i < (py::ssize_t)n; ++i) {
                    for (py::ssize_t j = 0; j < (py::ssize_t)n; ++j) {
                        ptr(i, j) = self.get(i, j);
                    }
                }
                return result;
            } else if constexpr (std::is_same_v<T, IntegerMatrix> || std::is_same_v<T, TriangularIntegerMatrix>) {
                py::array_t<int32_t> result({n, n});
                auto ptr = result.mutable_unchecked<2>();
                for (py::ssize_t i = 0; i < (py::ssize_t)n; ++i) {
                    for (py::ssize_t j = 0; j < (py::ssize_t)n; ++j) {
                        ptr(i, j) = (int32_t)self.get_element_as_double(i, j);
                    }
                }
                return result;
            } else {
                py::array_t<double> result({n, n});
                auto ptr = result.mutable_unchecked<2>();
                for (py::ssize_t i = 0; i < (py::ssize_t)n; ++i) {
                    for (py::ssize_t j = 0; j < (py::ssize_t)n; ++j) {
                        ptr(i, j) = self.get_element_as_double(i, j);
                    }
                }
                return result;
            }
        }, py::arg("dtype") = py::none(), py::arg("copy") = py::none());
    };


    m.def("asarray", [cast_matrix_result, cast_vector_result](py::object obj) -> py::object {
        auto res = from_numpy(obj);
        if (res) {
            if (auto* v = dynamic_cast<VectorBase*>(res.get())) {
                return cast_vector_result(std::unique_ptr<VectorBase>(static_cast<VectorBase*>(res.release())));
            }
            if (auto* m = dynamic_cast<MatrixBase*>(res.get())) {
                return cast_matrix_result(std::unique_ptr<MatrixBase>(static_cast<MatrixBase*>(res.release())));
            }
        }
        
        try {
            py::array arr = py::array(obj);
            if (arr.ndim() == 2 && py::isinstance<py::array_t<std::complex<double>>>(arr)) {
                uint64_t n = arr.shape(0);
                auto cm = std::make_unique<pycauset::ComplexMatrix>(n, make_unique_storage_file("numpy_c_real"), make_unique_storage_file("numpy_c_imag"));
                auto unchecked = arr.unchecked<std::complex<double>, 2>();
                for (uint64_t i = 0; i < n; ++i) {
                    for (uint64_t j = 0; j < n; ++j) {
                        cm->set(i, j, unchecked(i, j));
                    }
                }
                return py::cast(std::move(cm));
            }
        } catch (...) {}

        throw std::invalid_argument("Could not convert input to PyCauset object");
    }, "Convert a NumPy array (or compatible object) to a PyCauset object (disk-backed).");

    py::class_<PersistentObject>(m, "PersistentObject")
        .def_property("scalar", &PersistentObject::get_scalar, &PersistentObject::set_scalar)
        .def_property_readonly("seed", &PersistentObject::get_seed)
        .def_property("is_temporary", &PersistentObject::is_temporary, &PersistentObject::set_temporary)
        .def("close", &PersistentObject::close)
        .def("get_backing_file", &PersistentObject::get_backing_file);

    py::class_<MatrixBase, PersistentObject>(m, "MatrixBase");

    py::class_<VectorBase, PersistentObject>(m, "VectorBase")
        .def_property_readonly("T", [](const VectorBase& v) {
            return v.transpose();
        });

    // TriangularFloatMatrix
    py::class_<TriangularFloatMatrix, MatrixBase> tfm(m, "TriangularFloatMatrix");
    tfm.def(py::init<uint64_t, const std::string&>(), 
            py::arg("n"), py::arg("backing_file") = "")
        .def("get", &TriangularFloatMatrix::get)
        .def("get_element_as_double", &TriangularFloatMatrix::get_element_as_double)
        .def("set", &TriangularFloatMatrix::set)
        .def("close", &TriangularFloatMatrix::close)
        .def("size", &TriangularFloatMatrix::size)
        .def("get_backing_file", &TriangularFloatMatrix::get_backing_file)
        .def_property_readonly("shape", [](const TriangularFloatMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("__getitem__", [](const TriangularFloatMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get(idx.first, idx.second) * m.get_scalar();
        })
        .def("__setitem__", [](TriangularFloatMatrix& m, std::pair<uint64_t, uint64_t> idx, double value) {
            m.set(idx.first, idx.second, value);
        })
        .def("__repr__", [](const TriangularFloatMatrix& m) {
            return "<TriangularFloatMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        })
        .def("invert", [](const TriangularFloatMatrix& m) {
            return m.inverse(make_unique_storage_file("inverse"));
        }, "Matrix Inversion (Linear Algebra)")
        .def("__invert__", [](const TriangularFloatMatrix& m) {
            return m.bitwise_not(make_unique_storage_file("bitwise_not"));
        });
    bind_arithmetic(tfm);

    // TriangularIntegerMatrix
    py::class_<TriangularIntegerMatrix, MatrixBase> tim(m, "TriangularIntegerMatrix");
    tim.def(py::init<uint64_t, const std::string&>(), 
            py::arg("n"), py::arg("backing_file") = "")
        .def("get", &TriangularIntegerMatrix::get)
        .def("get_element_as_double", &TriangularIntegerMatrix::get_element_as_double)
        .def("set", &TriangularIntegerMatrix::set)
        .def("close", &TriangularIntegerMatrix::close)
        .def("size", &TriangularIntegerMatrix::size)
        .def("get_backing_file", &TriangularIntegerMatrix::get_backing_file)
        .def_property_readonly("shape", [](const TriangularIntegerMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("__getitem__", [](const TriangularIntegerMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get_element_as_double(idx.first, idx.second);
        })
        .def("__setitem__", [](TriangularIntegerMatrix& m, std::pair<uint64_t, uint64_t> idx, int32_t value) {
            m.set(idx.first, idx.second, value);
        })
        .def("__repr__", [](const TriangularIntegerMatrix& m) {
            return "<TriangularIntegerMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        })
        .def("invert", [](const TriangularIntegerMatrix& m) {
            return m.inverse(make_unique_storage_file("inverse"));
        }, "Matrix Inversion (Linear Algebra)")
        .def("__invert__", [](const TriangularIntegerMatrix& m) {
            return m.bitwise_not(make_unique_storage_file("bitwise_not"));
        });
    bind_arithmetic(tim);

    // FloatMatrix (Dense)
    py::class_<FloatMatrix, MatrixBase> fm(m, "FloatMatrix");
    fm.def(py::init<uint64_t, const std::string&>(), 
           py::arg("n"), py::arg("backing_file") = "")
        .def("get", &FloatMatrix::get)
        .def("get_element_as_double", &FloatMatrix::get_element_as_double)
        .def("set", &FloatMatrix::set)
        .def("close", &FloatMatrix::close)
        .def("size", &FloatMatrix::size)
        .def("get_backing_file", &FloatMatrix::get_backing_file)
        .def_property_readonly("shape", [](const FloatMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("__getitem__", [](const FloatMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get(idx.first, idx.second) * m.get_scalar();
        })
        .def("__setitem__", [](FloatMatrix& m, std::pair<uint64_t, uint64_t> idx, double value) {
            m.set(idx.first, idx.second, value);
        })
        .def("__repr__", [](const FloatMatrix& m) {
            return "<FloatMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        })
        .def("invert", [](const FloatMatrix& m) {
            return m.inverse(make_unique_storage_file("inverse"));
        }, "Matrix Inversion (Linear Algebra)")
        .def("__invert__", [](const FloatMatrix& m) {
            return m.bitwise_not(make_unique_storage_file("bitwise_not"));
        })
        .def("multiply", [](const FloatMatrix& self, const FloatMatrix& other, const std::string& saveas) {
            std::string target = saveas.empty() ? make_unique_storage_file("matmul_fm") : saveas;
            return self.multiply(other, target);
        }, py::arg("other"), py::arg("saveas") = "");
    bind_arithmetic(fm);

    m.def("compute_k_matrix", &compute_k_matrix, 
          py::arg("C"), py::arg("a"), py::arg("output_path"), py::arg("num_threads") = 0,
          "Compute K = C(aI + C)^-1");

    // IntegerMatrix (Dense)
    py::class_<IntegerMatrix, MatrixBase> im(m, "IntegerMatrix");
    im.def(py::init<uint64_t, const std::string&>(), 
           py::arg("n"), py::arg("backing_file") = "")
        .def("get", &IntegerMatrix::get)
        .def("get_element_as_double", &IntegerMatrix::get_element_as_double)
        .def("set", &IntegerMatrix::set)
        .def("close", &IntegerMatrix::close)
        .def("size", &IntegerMatrix::size)
        .def("get_backing_file", &IntegerMatrix::get_backing_file)
        .def_property_readonly("shape", [](const IntegerMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("__getitem__", [](const IntegerMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get_element_as_double(idx.first, idx.second);
        })
        .def("__setitem__", [](IntegerMatrix& m, std::pair<uint64_t, uint64_t> idx, int32_t value) {
            m.set(idx.first, idx.second, value);
        })
        .def("__repr__", [](const IntegerMatrix& m) {
            return "<IntegerMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        })
        .def("invert", [](const IntegerMatrix& m) {
            return m.inverse(make_unique_storage_file("inverse"));
        }, "Matrix Inversion (Linear Algebra)")
        .def("__invert__", [](const IntegerMatrix& m) {
            return m.bitwise_not(make_unique_storage_file("bitwise_not"));
        })
        .def("multiply", [](const IntegerMatrix& self, const IntegerMatrix& other, const std::string& saveas) {
            std::string target = saveas.empty() ? make_unique_storage_file("matmul_im") : saveas;
            return self.multiply(other, target);
        }, py::arg("other"), py::arg("saveas") = "");
    bind_arithmetic(im);

    // DenseBitMatrix
    py::class_<DenseBitMatrix, MatrixBase> dbm(m, "DenseBitMatrix");
    dbm.def(py::init<uint64_t, const std::string&>(), 
           py::arg("n"), py::arg("backing_file") = "")
        .def_static("random", &DenseBitMatrix::random, 
            py::arg("n"), py::arg("density") = 0.5, py::arg("backing_file") = "",
            py::arg("seed") = py::none())
        .def("get", &DenseBitMatrix::get)
        .def("set", [](DenseBitMatrix& m, uint64_t i, uint64_t j, py::object value) {
            bool boolVal = coerce_bool_like(value);
            m.set(i, j, boolVal);
        })
        .def("close", &DenseBitMatrix::close)
        .def("size", &DenseBitMatrix::size)
        .def("get_backing_file", &DenseBitMatrix::get_backing_file)
        .def_property_readonly("shape", [](const DenseBitMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("__getitem__", [](const DenseBitMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get(idx.first, idx.second);
        })
        .def("__setitem__", [](DenseBitMatrix& m, std::pair<uint64_t, uint64_t> idx, py::object value) {
            bool boolVal = coerce_bool_like(value);
            m.set(idx.first, idx.second, boolVal);
        })
        .def("__repr__", [](const DenseBitMatrix& m) {
            return "<DenseBitMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        })
        .def("invert", [](const DenseBitMatrix& m) {
            // DenseBitMatrix inversion? Not implemented in C++ yet, or maybe it is?
            // I didn't implement inverse() in DenseBitMatrix.hpp, only bitwise_not.
            // So I won't bind invert() for now, or bind it to throw.
            throw std::runtime_error("Inversion not supported for DenseBitMatrix");
        }, "Matrix Inversion (Linear Algebra)")
        .def("__invert__", [](const DenseBitMatrix& m) {
            return m.bitwise_not(make_unique_storage_file("bitwise_not"));
        })
        .def("multiply", [](const DenseBitMatrix& self, const DenseBitMatrix& other, const std::string& saveas) {
            std::string target = saveas.empty() ? make_unique_storage_file("matmul_dbm") : saveas;
            return self.multiply(other, target);
        }, py::arg("other"), py::arg("saveas") = "");
    bind_arithmetic(dbm);

    // TriangularBitMatrix
    py::class_<TriangularBitMatrix, MatrixBase> tbm(m, "TriangularBitMatrix");
    tbm.def(py::init<uint64_t, const std::string&>(), 
             py::arg("n"), py::arg("saveas") = "")
        // Numpy Constructor
        .def(py::init([](py::array_t<bool> arr, std::string backing_file) {
            auto buf = arr.unchecked<2>();
            if (buf.ndim() != 2 || buf.shape(0) != buf.shape(1)) {
                throw std::invalid_argument("Array must be a square 2D matrix");
            }
            
            uint64_t n = buf.shape(0);
            auto mat = std::make_unique<TriangularBitMatrix>(n, backing_file);
            
            for (py::ssize_t i = 0; i < n; ++i) {
                for (py::ssize_t j = i + 1; j < n; ++j) {
                    if (buf(i, j)) {
                        mat->set(i, j, true); 
                    }
                }
            }
            return mat;
        }), py::arg("array"), py::arg("backing_file") = "")
        
        // Random Factory
        .def_static("random", &TriangularBitMatrix::random, 
            py::arg("n"), py::arg("density") = 0.5, py::arg("backing_file") = "",
            py::arg("seed") = py::none())

        .def("set", [](TriangularBitMatrix& m, uint64_t i, uint64_t j, py::object value) {
            bool boolVal = coerce_bool_like(value);
            m.set(i, j, boolVal);
        })
        .def("get", &TriangularBitMatrix::get)
        .def("get_element_as_double", &TriangularBitMatrix::get_element_as_double)
        .def("size", &TriangularBitMatrix::size)
        .def_property_readonly("shape", [](const TriangularBitMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("close", &TriangularBitMatrix::close,
             "Release the memory-mapped backing file. The matrix becomes unusable afterward.")
        .def("__len__", &TriangularBitMatrix::size)
        .def("__getitem__", [](const TriangularBitMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get_element_as_double(idx.first, idx.second);
        })
        // Guardrailed __setitem__
        .def("__setitem__", [](TriangularBitMatrix& m, std::pair<uint64_t, uint64_t> idx, py::object value) {
            if (idx.first >= idx.second) {
                if (PyErr_WarnEx(PyExc_UserWarning, "Ignoring diagonal or lower-triangular set operation. TriangularBitMatrix is strictly upper triangular.", 1) == -1) {
                    throw py::error_already_set();
                }
                return;
            }
            bool boolVal = coerce_bool_like(value);
            m.set(idx.first, idx.second, boolVal);
        })
        // Advanced Indexing (Batch Set)
        .def("__setitem__", [](TriangularBitMatrix& m, std::pair<py::array_t<int64_t>, py::array_t<int64_t>> idx, py::array_t<bool> vals) {
            auto rows = idx.first.unchecked<1>();
            auto cols = idx.second.unchecked<1>();
            auto values = vals.unchecked<1>();
            
            if (rows.size() != cols.size() || rows.size() != values.size()) {
                throw std::invalid_argument("Index and value arrays must have the same size");
            }

            bool warned = false;
            for (py::ssize_t k = 0; k < rows.size(); ++k) {
                uint64_t r = rows(k);
                uint64_t c = cols(k);
                if (r >= c) {
                    if (!warned) {
                        if (PyErr_WarnEx(PyExc_UserWarning, "Ignoring diagonal or lower-triangular set operation in batch.", 1) == -1) {
                            throw py::error_already_set();
                        }
                        warned = true;
                    }
                    continue; 
                }
                m.set(r, c, values(k));
            }
        })
        .def("multiply", &TriangularBitMatrix::multiply, 
             py::arg("other"), py::arg("result_file") = "",
             "Multiply this matrix by another TriangularBitMatrix. Returns a TriangularIntegerMatrix.")
        .def("elementwise_multiply", [](const TriangularBitMatrix& self, const TriangularBitMatrix& other, const std::string& saveas) {
            return self.elementwise_multiply(other, saveas);
        }, py::arg("other"), py::arg("saveas") = "")
        .def("invert", [](const TriangularBitMatrix& m) {
            return m.inverse(make_unique_storage_file("inverse"));
        }, "Matrix Inversion (Linear Algebra)")
        .def("__invert__", [](const TriangularBitMatrix& m) {
            return m.bitwise_not(make_unique_storage_file("bitwise_not"));
        })
        .def("get_backing_file", &TriangularBitMatrix::get_backing_file)
        .def("__repr__", [](const TriangularBitMatrix& m) {
            return "<TriangularBitMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        });
    bind_arithmetic(tbm);

    m.def("matmul", &dispatch_matmul, py::arg("a"), py::arg("b"), py::arg("saveas") = "",
          "Generic matrix multiplication. Supports mixed types (Dense/Triangular).");

    m.def("save", [](const PersistentObject& obj, const std::string& path) {
        obj.copy_storage(path);
    }, "Save a persistent object to a specific path");

    m.def("load", [](const std::string& path) -> py::object {
        std::ifstream file(path, std::ios::binary);
        if (!file) {
            throw std::runtime_error("Failed to open file: " + path);
        }
        
        pycauset::FileHeader header;
        if (!file.read(reinterpret_cast<char*>(&header), sizeof(header))) {
             throw std::runtime_error("Failed to read file header: " + path);
        }
        file.close();

        if (std::strncmp(header.magic, "PYCAUSET", 8) != 0) {
             throw std::runtime_error("Invalid file format (Magic mismatch)");
        }
        
        uint64_t n = header.rows;
        uint64_t file_size = std::filesystem::file_size(path);
        if (file_size < sizeof(pycauset::FileHeader)) {
             throw std::runtime_error("File too small");
        }
        uint64_t data_size = file_size - sizeof(pycauset::FileHeader);
        
        auto mapper = std::make_unique<MemoryMapper>(path, data_size, false);
        
        switch (header.matrix_type) {
            case pycauset::MatrixType::CAUSAL:
                return py::cast(new TriangularBitMatrix(n, std::move(mapper)));
            case pycauset::MatrixType::INTEGER:
                // Assuming INTEGER is now Dense Integer
                return py::cast(new IntegerMatrix(n, std::move(mapper)));
            case pycauset::MatrixType::TRIANGULAR_FLOAT:
                 return py::cast(new TriangularFloatMatrix(n, std::move(mapper)));
            case pycauset::MatrixType::DENSE_FLOAT:
                 if (header.data_type == pycauset::DataType::BIT) {
                     return py::cast(new DenseBitMatrix(n, std::move(mapper)));
                 }
                 return py::cast(new FloatMatrix(n, std::move(mapper)));
            case pycauset::MatrixType::IDENTITY:
                 return py::cast(new IdentityMatrix(n, std::move(mapper)));
            case pycauset::MatrixType::VECTOR:
                 if (header.data_type == pycauset::DataType::BIT) {
                     return py::cast(new BitVector(n, std::move(mapper)));
                 } else if (header.data_type == pycauset::DataType::INT32) {
                     return py::cast(new IntegerVector(n, std::move(mapper)));
                 } else if (header.data_type == pycauset::DataType::FLOAT64) {
                     return py::cast(new FloatVector(n, std::move(mapper)));
                 }
                 throw std::runtime_error("Unknown vector data type");
            default:
                throw std::runtime_error("Unknown matrix type in file");
        }
    }, "Load a matrix from a file");

    // IdentityMatrix
    py::class_<IdentityMatrix, MatrixBase> idm(m, "IdentityMatrix");
    idm.def(py::init<uint64_t, const std::string&>(), 
            py::arg("n"), py::arg("backing_file") = "")
        .def("get", [](const IdentityMatrix& m, uint64_t i, uint64_t j) {
            return m.get_element_as_double(i, j);
        })
        .def("close", &IdentityMatrix::close)
        .def("size", &IdentityMatrix::size)
        .def("get_backing_file", &IdentityMatrix::get_backing_file)
        .def_property_readonly("shape", [](const IdentityMatrix& m) {
            return std::make_pair(m.size(), m.size());
        })
        .def("__getitem__", [](const IdentityMatrix& m, std::pair<uint64_t, uint64_t> idx) {
            return m.get_element_as_double(idx.first, idx.second);
        })
        .def("__repr__", [](const IdentityMatrix& m) {
            return "<IdentityMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        });
    bind_arithmetic(idm);

    // FloatVector
    py::class_<FloatVector, VectorBase> fv(m, "FloatVector");
    fv.def(py::init<uint64_t, const std::string&>(), py::arg("n"), py::arg("backing_file") = "")
      .def("__getitem__", &FloatVector::get)
      .def("__setitem__", &FloatVector::set)
      .def("__len__", &FloatVector::size)
      .def_property_readonly("shape", [](const FloatVector& v) { 
          if (v.is_transposed()) return py::make_tuple(1, v.size());
          return py::make_tuple(v.size()); 
      })
      .def("__repr__", [](const FloatVector& v) {
          std::string s = "<FloatVector size=" + std::to_string(v.size());
          if (v.is_transposed()) s += " transposed=True";
          s += ">";
          return s;
      });
    bind_vector_arithmetic(fv);

    // IntegerVector
    py::class_<IntegerVector, VectorBase> iv(m, "IntegerVector");
    iv.def(py::init<uint64_t, const std::string&>(), py::arg("n"), py::arg("backing_file") = "")
      .def("__getitem__", &IntegerVector::get)
      .def("__setitem__", &IntegerVector::set)
      .def("__len__", &IntegerVector::size)
      .def_property_readonly("shape", [](const IntegerVector& v) { 
          if (v.is_transposed()) return py::make_tuple(1, v.size());
          return py::make_tuple(v.size()); 
      })
      .def("__repr__", [](const IntegerVector& v) {
          std::string s = "<IntegerVector size=" + std::to_string(v.size());
          if (v.is_transposed()) s += " transposed=True";
          s += ">";
          return s;
      });
    bind_vector_arithmetic(iv);

    // BitVector
    py::class_<BitVector, VectorBase> bv(m, "BitVector");
    bv.def(py::init<uint64_t, const std::string&>(), py::arg("n"), py::arg("backing_file") = "")
      .def("__getitem__", &BitVector::get)
      .def("__setitem__", [](BitVector& v, uint64_t i, py::object val) {
          v.set(i, coerce_bool_like(val));
      })
      .def("__len__", &BitVector::size)
      .def_property_readonly("shape", [](const BitVector& v) { 
          if (v.is_transposed()) return py::make_tuple(1, v.size());
          return py::make_tuple(v.size()); 
      })
      .def("__repr__", [](const BitVector& v) {
          std::string s = "<BitVector size=" + std::to_string(v.size());
          if (v.is_transposed()) s += " transposed=True";
          s += ">";
          return s;
      });
    bind_vector_arithmetic(bv);

    // ComplexMatrix
    py::class_<pycauset::ComplexMatrix>(m, "ComplexMatrix")
        .def(py::init<uint64_t, const std::string&, const std::string&>(), 
             py::arg("n"), py::arg("backing_file_real") = "", py::arg("backing_file_imag") = "")
        .def("get", &pycauset::ComplexMatrix::get)
        .def("set", &pycauset::ComplexMatrix::set)
        .def("size", &pycauset::ComplexMatrix::size)
        .def("close", &pycauset::ComplexMatrix::close)
        .def_property_readonly("real", static_cast<const pycauset::FloatMatrix* (pycauset::ComplexMatrix::*)() const>(&pycauset::ComplexMatrix::real), py::return_value_policy::reference)
        .def_property_readonly("imag", static_cast<const pycauset::FloatMatrix* (pycauset::ComplexMatrix::*)() const>(&pycauset::ComplexMatrix::imag), py::return_value_policy::reference)
        .def("conjugate", [](const pycauset::ComplexMatrix& m) {
            return m.conjugate(make_unique_storage_file("conj_real"), make_unique_storage_file("conj_imag"));
        })
        .def_property_readonly("T", [](const pycauset::ComplexMatrix& m) {
            return m.transpose(make_unique_storage_file("trans_real"), make_unique_storage_file("trans_imag"));
        })
        .def_property_readonly("H", [](const pycauset::ComplexMatrix& m) {
            return m.hermitian(make_unique_storage_file("herm_real"), make_unique_storage_file("herm_imag"));
        }, "Hermitian Conjugate")
        .def("__add__", [](const pycauset::ComplexMatrix& self, const pycauset::ComplexMatrix& other) {
            return pycauset::add(self, other, make_unique_storage_file("cadd_real"), make_unique_storage_file("cadd_imag"));
        })
        .def("__mul__", [](const pycauset::ComplexMatrix& self, const pycauset::ComplexMatrix& other) {
            return pycauset::multiply(self, other, make_unique_storage_file("cmul_real"), make_unique_storage_file("cmul_imag"));
        })
        .def("__repr__", [](const pycauset::ComplexMatrix& m) {
            return "<ComplexMatrix shape=(" + std::to_string(m.size()) + ", " + std::to_string(m.size()) + ")>";
        });

    m.def("dot", &pycauset::dot_product, "Dot product of two vectors");

    m.def("set_memory_threshold", &pycauset::set_memory_threshold, 
          py::arg("bytes"),
          "Set the size threshold (in bytes) below which objects are stored in RAM instead of on disk.");
          
    m.def("get_memory_threshold", &pycauset::get_memory_threshold,
          "Get the current memory threshold in bytes.");
}
