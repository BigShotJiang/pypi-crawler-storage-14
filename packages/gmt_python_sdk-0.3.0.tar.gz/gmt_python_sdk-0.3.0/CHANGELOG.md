# Changelog

## 0.3.0 (2025-11-28)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([3d8f73c](https://github.com/cameo6/gmt-python-sdk/commit/3d8f73c03a372b6bacad14b4925d1350fab12548))

## 0.2.0 (2025-11-28)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([31f9595](https://github.com/cameo6/gmt-python-sdk/commit/31f9595ad1832708e52ebdd77acd34776e19a890))

## 0.1.0 (2025-11-28)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([0ba3d7e](https://github.com/cameo6/gmt-python-sdk/commit/0ba3d7e4e9a87866e89d244fd6c7ca98a59236af))
* **api:** manual updates ([81d9f33](https://github.com/cameo6/gmt-python-sdk/commit/81d9f33de9f266d7c5e06379cf75d55a40f1366a))


### Bug Fixes

* ensure streams are always closed ([5ab47f0](https://github.com/cameo6/gmt-python-sdk/commit/5ab47f0219cc85563e6e7352e460cda9275f1601))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([a1731e0](https://github.com/cameo6/gmt-python-sdk/commit/a1731e0758cf5de45fb93fd59fc03dbfbb1a806a))
* update SDK settings ([2d9f3a9](https://github.com/cameo6/gmt-python-sdk/commit/2d9f3a90bc50ded9e8df86031ffd6509852d9bd6))
* update SDK settings ([904acac](https://github.com/cameo6/gmt-python-sdk/commit/904acacb04e79821b2f5ac9990b09e8ec6bd8fdc))
