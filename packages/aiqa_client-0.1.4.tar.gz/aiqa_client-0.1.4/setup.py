"""
Setup script for aiqa-client (kept for compatibility).
Use pyproject.toml for modern builds.
"""

from setuptools import setup

setup()

