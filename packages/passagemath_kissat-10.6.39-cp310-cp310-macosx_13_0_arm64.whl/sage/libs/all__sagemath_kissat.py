# sage_setup: distribution = sagemath-kissat
