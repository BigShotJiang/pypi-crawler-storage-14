# Descripción de la estructura del directorio de pruebas

Este directorio contiene todos los archivos de prueba del proyecto redmine-mcp, organizados en tres categorías principales:

## 📁 Estructura del directorio

```
tests/
├── unit/              # Pruebas unitarias (pytest)
│   ├── test_config.py         # Pruebas de gestión de configuración
│   ├── test_redmine_client.py # Pruebas del cliente Redmine
│   └── test_validators.py     # Pruebas de validadores de datos
├── integration/       # Pruebas de integración (pytest)
│   ├── test_mcp_tools.py          # Pruebas de integración de herramientas MCP
│   └── test_advanced_mcp_tools.py # Pruebas avanzadas de herramientas MCP
└── scripts/          # Scripts de prueba (ejecutables directamente)
    ├── claude_integration.py # Prueba de integración con Claude Code
    ├── claude_setup.py       # Prueba de configuración de Claude Code
    ├── installation.py       # Prueba de instalación de paquetes
    └── mcp_integration.py    # Prueba completa de funcionalidades MCP
```

## 🧪 Tipos de pruebas

### Pruebas unitarias (Unit Tests)
- Propósito: Probar funciones y módulos individuales
- Características: Independientes, rápidas y repetibles
- Framework: pytest
- Ejecución: `uv run python -m pytest tests/unit/`

### Pruebas de integración (Integration Tests)
- Propósito: Verificar la interacción entre módulos
- Características: Pueden requerir servicios externos (p. ej. Redmine)
- Framework: pytest + mock
- Ejecución: `uv run python -m pytest tests/integration/`

### Scripts de prueba (Test Scripts)
- Propósito: Validación end-to-end y configuración de entornos
- Características: Ejecutables de forma independiente, incluyen lógica de configuración
- Framework: Python nativo
- Ejecución: `uv run python tests/scripts/<script_name>.py`

## 🚀 Inicio rápido

### Ejecutar todas las pruebas
```bash
# Ejecutar todas las pruebas con pytest
uv run python -m pytest tests/

# Ejecutar la prueba de integración completa
uv run python tests/scripts/mcp_integration.py
```

### Ejecutar tipos de pruebas específicos
```bash
# Ejecutar solo pruebas unitarias
uv run python -m pytest tests/unit/

# Ejecutar solo pruebas de integración
uv run python -m pytest tests/integration/

# Probar integración con Claude Code
uv run python tests/scripts/claude_integration.py

# Probar instalación de paquetes
uv run python tests/scripts/installation.py
```

### Flujo de pruebas durante el desarrollo
```bash
# 1. Después de cambiar el código, ejecutar las pruebas unitarias primero
uv run python -m pytest tests/unit/ -v

# 2. Si pasan, ejecutar las pruebas de integración
uv run python -m pytest tests/integration/ -v

# 3. Finalmente ejecutar la prueba funcional completa
uv run python tests/scripts/mcp_integration.py
```

## 📝 Descripción de los archivos de prueba

### Pruebas unitarias

#### `test_config.py`
- Prueba del módulo de gestión de configuración (`config.py`)
- Verifica lectura y validación de variables de entorno
- Prueba del nuevo mecanismo de variables de entorno dedicadas

#### `test_redmine_client.py`
- Pruebas del cliente de la API de Redmine (`redmine_client.py`)
- Mock de peticiones HTTP y respuestas
- Verifica el manejo de errores

#### `test_validators.py`
- Pruebas de los validadores (`validators.py`)
- Verifica formatos de entrada y validaciones de rango
- Prueba la generación de mensajes de error

### Pruebas de integración

#### `test_mcp_tools.py`
- Pruebas de las funcionalidades básicas de las herramientas MCP
- Simula respuestas del servicio Redmine
- Verifica el flujo de datos entre herramientas

#### `test_advanced_mcp_tools.py`
- Pruebas de funcionalidades avanzadas de las herramientas MCP
- Escenarios complejos y pruebas de bordes
- Verificación de rendimiento y estabilidad

### Scripts de prueba

#### `claude_integration.py`
- Prueba la integración con Claude Code
- Verifica que el servidor MCP sea ejecutable
- Comprueba el registro y disponibilidad de herramientas

#### `claude_setup.py`
- Prueba la configuración MCP para Claude Code
- Verifica la generación de archivos de configuración
- Prueba la configuración de variables de entorno

#### `installation.py`
- Prueba la instalación e importación de paquetes
- Verifica la disponibilidad de herramientas de línea de comandos
- Comprueba dependencias requeridas

#### `mcp_integration.py`
- Prueba end-to-end completa
- Requiere un servicio Redmine en ejecución
- Prueba las 14 herramientas MCP

## 🔧 Requisitos del entorno

### Pruebas unitarias
- Python 3.12+
- pytest
- Paquetes de mocking necesarios

### Pruebas de integración
- Todos los requisitos de las pruebas unitarias
- Servicio Redmine opcional (no necesario cuando se usa mock)

### Scripts de prueba
- Entorno de desarrollo completo
- Docker y Docker Compose (para ejecutar Redmine localmente)
- Conexión de red (para integrar con Claude Code)

## 📊 Cobertura de pruebas

Usa pytest-cov para comprobar la cobertura de pruebas:

```bash
# Instalar la herramienta de cobertura
uv add --dev pytest-cov

# Ejecutar pruebas y generar reporte de cobertura
uv run python -m pytest tests/ --cov=src/redmine_mcp --cov-report=html

# Abrir el reporte de cobertura
open htmlcov/index.html
```

## 🐛 Solución de problemas

### Problemas comunes

**Q: pytest no encuentra el módulo**
```bash
# Asegúrate de ejecutar desde la raíz del proyecto
cd /path/to/redmine-mcp
uv run python -m pytest tests/
```

**Q: Las pruebas de integración fallan**
- Comprueba si es necesario iniciar el servicio Redmine
- Verifica la conexión de red y la configuración de la API key

**Q: Errores al ejecutar los scripts de prueba**
- Verifica que las rutas de importación sean correctas
- Asegúrate de que todas las dependencias estén instaladas

### Consejos para depuración

```bash
# Ejecutar un archivo de pruebas específico
uv run python -m pytest tests/unit/test_config.py -v

# Ejecutar una función de prueba concreta
uv run python -m pytest tests/unit/test_config.py::TestRedmineConfig::test_config_with_valid_env -v

# Mostrar salida detallada
uv run python -m pytest tests/ -v -s

# Detener al primer fallo
uv run python -m pytest tests/ -x
```

## 🚀 Integración continua

Se recomienda el siguiente orden en CI/CD:

1. **Chequeo rápido**: pruebas unitarias
2. **Validación profunda**: pruebas de integración
3. **Confirmación final**: scripts de prueba críticos

```bash
# Ejemplo de flujo en CI
uv run python -m pytest tests/unit/ --maxfail=5
uv run python -m pytest tests/integration/ --maxfail=3
uv run python tests/scripts/installation.py
```
