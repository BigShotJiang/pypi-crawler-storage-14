"""
MCP Tools Tests
"""

import os
import pytest
from unittest.mock import patch, Mock
from redmine_mcp.server import get_issue, update_issue_status, update_issue_content, list_project_issues, health_check, get_trackers, get_priorities, get_time_entry_activities, get_document_categories
from redmine_mcp.redmine_client import RedmineIssue, RedmineProject


class TestMCPTools:
    """MCP Tools Tests"""
    
    def setup_method(self):
        """Setup before each test"""
        # Ensure test environment variables are set
        with patch.dict(os.environ, {
            'REDMINE_DOMAIN': 'https://test.redmine.com',
            'REDMINE_API_KEY': 'test_api_key'
        }):
            pass
    
    @patch('redmine_mcp.server.get_client')
    def test_health_check_success(self, mock_get_client):
        """Test health check success"""
        mock_client = Mock()
        mock_client.test_connection.return_value = True
        mock_get_client.return_value = mock_client
        
        with patch.dict(os.environ, {
            'REDMINE_DOMAIN': 'https://test.redmine.com',
            'REDMINE_API_KEY': 'test_api_key'
        }):
            result = health_check()
        
        assert "✓ Server is operational" in result
        assert "https://test.redmine.com" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_health_check_connection_failed(self, mock_get_client):
        """Test health check connection failed"""
        mock_client = Mock()
        mock_client.test_connection.return_value = False
        mock_get_client.return_value = mock_client
        
        with patch.dict(os.environ, {
            'REDMINE_DOMAIN': 'https://test.redmine.com',
            'REDMINE_API_KEY': 'test_api_key'
        }):
            result = health_check()
        
        assert "✗ Unable to connect to Redmine server" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_issue_success(self, mock_get_client):
        """Test get issue successfully"""
        mock_client = Mock()
        # Mock get_issue_raw method to return dictionary format
        mock_issue_data = {
            'id': 123,
            'subject': 'Test Issue',
            'description': 'Issue description',
            'status': {'name': 'New'},
            'priority': {'name': 'Normal'},
            'project': {'name': 'Test Project', 'id': 1},
            'tracker': {'name': 'Bug'},
            'author': {'name': 'Test User'},
            'assigned_to': {'name': 'Assigned User'},
            'created_on': '2024-01-01T10:00:00Z',
            'updated_on': '2024-01-02T15:30:00Z',
            'done_ratio': 50
        }
        mock_client.get_issue_raw.return_value = mock_issue_data
        mock_client.config.redmine_domain = 'https://test.redmine.com'
        mock_get_client.return_value = mock_client
        
        result = get_issue(123)
        
        assert "Issue #123: Test Issue" in result
        assert "Project: Test Project" in result
        assert "Status: New" in result
        assert "Done ratio: 50%" in result
        assert "Issue description" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_issue_error(self, mock_get_client):
        """Test get issue error"""
        mock_client = Mock()
        mock_client.get_issue_raw.side_effect = Exception("Issue does not exist")
        mock_get_client.return_value = mock_client
        
        result = get_issue(999)
        
        assert "System error" in result
        assert "Issue does not exist" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_issue_with_notes_and_attachments(self, mock_get_client):
        """Test get issue with notes and attachments"""
        mock_client = Mock()
        # Mock issue data with journals and attachments
        mock_issue_data = {
            'id': 123,
            'subject': 'Test Issue',
            'description': 'Issue description',
            'status': {'name': 'New'},
            'priority': {'name': 'Normal'},
            'project': {'name': 'Test Project', 'id': 1},
            'tracker': {'name': 'Bug'},
            'author': {'name': 'Test User'},
            'assigned_to': {'name': 'Assigned User'},
            'created_on': '2024-01-01T10:00:00Z',
            'updated_on': '2024-01-02T15:30:00Z',
            'done_ratio': 50,
            'journals': [
                {
                    'id': 1,
                    'user': {'name': 'User One'},
                    'notes': 'This is the first note',
                    'created_on': '2024-01-01T11:00:00Z'
                },
                {
                    'id': 2,
                    'user': {'name': 'User Two'},
                    'notes': 'This is the second note',
                    'created_on': '2024-01-01T12:00:00Z'
                }
            ],
            'attachments': [
                {
                    'id': 1,
                    'filename': 'test.jpg',
                    'filesize': 1048576,  # 1MB
                    'content_type': 'image/jpeg',
                    'author': {'name': 'User Three'},
                    'created_on': '2024-01-01T13:00:00Z'
                },
                {
                    'id': 2,
                    'filename': 'document.pdf',
                    'filesize': 512000,  # 500KB
                    'content_type': 'application/pdf',
                    'author': {'name': 'User Four'},
                    'created_on': '2024-01-01T14:00:00Z'
                }
            ]
        }
        mock_client.get_issue_raw.return_value = mock_issue_data
        mock_client.config.redmine_domain = 'https://test.redmine.com'
        mock_get_client.return_value = mock_client
        
        result = get_issue(123, include_details=True)
        
        # Check basic information
        assert "Issue #123: Test Issue" in result
        
        # Check attachment information
        assert "Attachments (2)" in result
        assert "test.jpg" in result
        assert "1.00 MB" in result
        assert "image/jpeg" in result
        assert "document.pdf" in result
        assert "512000 bytes" in result
        assert "application/pdf" in result
        assert "Download URL: https://test.redmine.com/attachments/download" in result
        
        # Check notes information
        assert "Notes/History (2)" in result
        assert "User One" in result
        assert "This is the first note" in result
        assert "User Two" in result
        assert "This is the second note" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_trackers_success(self, mock_get_client):
        """Test get trackers list success"""
        mock_client = Mock()
        mock_trackers = [
            {
                'id': 1,
                'name': 'Bug',
                'default_status': {'name': 'New'}
            },
            {
                'id': 2,
                'name': 'Feature',
                'default_status': {'name': 'New'}
            },
            {
                'id': 3,
                'name': 'Support',
                'default_status': {'name': 'New'}
            }
        ]
        mock_client.get_trackers.return_value = mock_trackers
        mock_get_client.return_value = mock_client
        
        result = get_trackers()
        
        assert "Available trackers" in result
        assert "Bug" in result
        assert "Feature" in result
        assert "Support" in result
        assert "New" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_trackers_empty(self, mock_get_client):
        """Test trackers list is empty"""
        mock_client = Mock()
        mock_client.get_trackers.return_value = []
        mock_get_client.return_value = mock_client
        
        result = get_trackers()
        
        assert "No trackers found" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_priorities_success(self, mock_get_client):
        """Test get priorities list success"""
        mock_client = Mock()
        mock_priorities = [
            {
                'id': 1,
                'name': 'Low',
                'is_default': False
            },
            {
                'id': 2,
                'name': 'Normal',
                'is_default': True
            },
            {
                'id': 3,
                'name': 'High-Handle ASAP',
                'is_default': False
            },
            {
                'id': 4,
                'name': 'Urgent-Within 2 days',
                'is_default': False
            },
            {
                'id': 5,
                'name': 'Critical-Immediate',
                'is_default': False
            }
        ]
        mock_client.get_priorities.return_value = mock_priorities
        mock_get_client.return_value = mock_client
        
        result = get_priorities()
        
        assert "Available priorities:" in result
        assert "Low" in result
        assert "Normal" in result
        assert "High-Handle ASAP" in result
        assert "Urgent-Within 2 days" in result
        assert "Critical-Immediate" in result
        assert "Yes" in result  # Check default marker
        assert "No" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_priorities_empty(self, mock_get_client):
        """Test priorities list is empty"""
        mock_client = Mock()
        mock_client.get_priorities.return_value = []
        mock_get_client.return_value = mock_client
        
        result = get_priorities()
        
        assert "No priorities found" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_time_entry_activities_success(self, mock_get_client):
        """Test get time tracking activities list success"""
        mock_client = Mock()
        mock_activities = [
            {'id': 1, 'name': 'Design', 'is_default': True},
            {'id': 2, 'name': 'Development', 'is_default': False},
            {'id': 3, 'name': 'Debugging', 'is_default': False},
            {'id': 4, 'name': 'Investigation', 'is_default': False},
            {'id': 5, 'name': 'Discussion', 'is_default': False},
            {'id': 6, 'name': 'Testing', 'is_default': False},
            {'id': 7, 'name': 'Maintenance', 'is_default': False},
            {'id': 8, 'name': 'Documentation', 'is_default': False},
            {'id': 9, 'name': 'Training', 'is_default': False},
            {'id': 10, 'name': 'Translation', 'is_default': False},
            {'id': 11, 'name': 'Other', 'is_default': False}
        ]
        mock_client.get_time_entry_activities.return_value = mock_activities
        mock_get_client.return_value = mock_client
        
        result = get_time_entry_activities()
        
        assert "Available time entry activities:" in result
        assert "Design" in result
        assert "Development" in result
        assert "Debugging" in result
        assert "Investigation" in result
        assert "Discussion" in result
        assert "Testing" in result
        assert "Maintenance" in result
        assert "Documentation" in result
        assert "Training" in result
        assert "Translation" in result
        assert "Other" in result
        assert "Yes" in result  # Check default marker
        assert "No" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_time_entry_activities_empty(self, mock_get_client):
        """Test time tracking activities list is empty"""
        mock_client = Mock()
        mock_client.get_time_entry_activities.return_value = []
        mock_get_client.return_value = mock_client
        
        result = get_time_entry_activities()
        
        assert "No time entry activities found" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_document_categories_success(self, mock_get_client):
        """Test get document categories list success"""
        mock_client = Mock()
        mock_categories = [
            {
                'id': 1,
                'name': 'User Manual',
                'is_default': True
            },
            {
                'id': 2,
                'name': 'Technical Documentation',
                'is_default': False
            },
            {
                'id': 3,
                'name': 'Application Form',
                'is_default': False
            },
            {
                'id': 4,
                'name': 'Requirements Document',
                'is_default': False
            }
        ]
        mock_client.get_document_categories.return_value = mock_categories
        mock_get_client.return_value = mock_client
        
        result = get_document_categories()
        
        assert "Available document categories" in result
        assert "User Manual" in result
        assert "Technical Documentation" in result
        assert "Application Form" in result
        assert "Requirements Document" in result
        assert "Yes" in result  # Check default marker
        assert "No" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_get_document_categories_empty(self, mock_get_client):
        """Test document categories list is empty"""
        mock_client = Mock()
        mock_client.get_document_categories.return_value = []
        mock_get_client.return_value = mock_client
        
        result = get_document_categories()
        
        assert "No document categories found" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_status_success(self, mock_get_client):
        """Test update issue status success"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        # Mock updated issue
        updated_issue = RedmineIssue(
            id=123,
            subject='Test Issue',
            description='Description',
            status={'name': 'In Progress'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'}
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_status(123, 2, "Status update note")
        
        assert "Issue status updated successfully" in result
        assert "Issue: #123 - Test Issue" in result
        assert "New status: In Progress" in result
        assert "Notes: Status update note" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(123, status_id=2, notes="Status update note")
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_status_without_notes(self, mock_get_client):
        """Test update issue status without notes"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Test Issue',
            description='Description',
            status={'name': 'Resolved'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'}
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_status(123, 3)
        
        assert "Issue status updated successfully" in result
        assert "New status: Resolved" in result
        assert "Notes:" not in result
        
        # Verify call parameters (no notes)
        mock_client.update_issue.assert_called_once_with(123, status_id=3)
    
    @patch('redmine_mcp.server.get_client')
    def test_list_project_issues_success(self, mock_get_client):
        """Test list project issues success"""
        mock_client = Mock()
        
        # Mock project info
        mock_project = RedmineProject(
            id=1,
            name='Test Project',
            identifier='test-project',
            description='Project description',
            status=1
        )
        mock_client.get_project.return_value = mock_project
        
        # Mock issues list
        mock_issues = [
            RedmineIssue(
                id=101,
                subject='First issue',
                description='Description 1',
                status={'name': 'New'},
                priority={'name': 'Normal'},
                project={'name': 'Test Project', 'id': 1},
                tracker={'name': 'Bug'},
                author={'name': 'User1'},
                assigned_to={'name': 'Assigned User1'},
                updated_on='2024-01-01'
            ),
            RedmineIssue(
                id=102,
                subject='Second issue',
                description='Description 2',
                status={'name': 'In Progress'},
                priority={'name': 'High'},
                project={'name': 'Test Project', 'id': 1},
                tracker={'name': 'Feature'},
                author={'name': 'User2'},
                assigned_to=None,
                updated_on='2024-01-02'
            )
        ]
        mock_client.list_issues.return_value = mock_issues
        mock_get_client.return_value = mock_client
        
        result = list_project_issues(1, "open", 20)
        
        assert "Project: Test Project" in result
        assert "Status filter: open" in result
        assert "Found 2 issues" in result
        assert "101" in result
        assert "First issue" in result
        assert "102" in result
        assert "Second issue" in result
        assert "Assigned User1" in result
        assert "Unassigned" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_list_project_issues_empty(self, mock_get_client):
        """Test list project issues is empty"""
        mock_client = Mock()
        mock_client.list_issues.return_value = []
        mock_get_client.return_value = mock_client
        
        result = list_project_issues(1, "all", 10)
        
        assert "No issues found in project 1 matching the criteria" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_list_project_issues_with_different_filters(self, mock_get_client):
        """Test project issues list with different status filters"""
        mock_client = Mock()
        mock_client.list_issues.return_value = []
        mock_get_client.return_value = mock_client
        
        # Test closed filter
        result = list_project_issues(1, "closed", 10)
        mock_client.list_issues.assert_called_with(
            project_id=1, limit=10, sort='updated_on:desc', status_id='c'
        )
        
        # Test all filter
        result = list_project_issues(1, "all", 10)
        mock_client.list_issues.assert_called_with(
            project_id=1, limit=10, sort='updated_on:desc'
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_list_project_issues_limit_bounds(self, mock_get_client):
        """Test project issues list limit boundaries"""
        mock_client = Mock()
        mock_client.list_issues.return_value = []
        mock_get_client.return_value = mock_client
        
        # Test exceeding maximum limit
        list_project_issues(1, "open", 150)
        args = mock_client.list_issues.call_args[1]
        assert args['limit'] == 100  # Should be limited to 100
        
        # Test below minimum limit
        list_project_issues(1, "open", -5)
        args = mock_client.list_issues.call_args[1]
        assert args['limit'] == 1  # Should be set to 1
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_with_tracker(self, mock_get_client):
        """Test update issue content including tracker"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Updated title',
            description='Updated description',
            status={'name': 'Newly created'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Feature'},
            author={'name': 'Test User'},
            done_ratio=50
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(123, subject='Updated title', tracker_id=2, done_ratio=50)
        
        assert "Issue content updated successfully" in result
        assert "Updated title" in result
        assert "Tracker ID: 2" in result
        assert "Done ratio: 50%" in result
        assert "Tracker: Feature" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(123, subject='Updated title', tracker_id=2, done_ratio=50)
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_tracker_only(self, mock_get_client):
        """Test update tracker only"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Test Issue',
            description='Description',
            status={'name': 'Newly created'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Feature'},
            author={'name': 'Test User'},
            done_ratio=0
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(123, tracker_id=2)
        
        assert "Issue content updated successfully" in result
        assert "Tracker ID: 2" in result
        assert "Tracker: Feature" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(123, tracker_id=2)
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_with_dates_and_hours(self, mock_get_client):
        """Test update issue dates and hours"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Test sub-issue',
            description='Description',
            status={'name': 'Newly created'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Feature'},
            author={'name': 'Test User'},
            done_ratio=0
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(
            123, 
            start_date='2025-06-26',
            due_date='2025-06-30',
            estimated_hours=8.5
        )
        
        assert "Issue content updated successfully" in result
        assert "Start date: 2025-06-26" in result
        assert "Due date: 2025-06-30" in result
        assert "Estimated hours: 8.5 hours" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(
            123, 
            start_date='2025-06-26',
            due_date='2025-06-30',
            estimated_hours=8.5
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_invalid_date_format(self, mock_get_client):
        """Test invalid date format"""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        # Test invalid start date
        result = update_issue_content(123, start_date='2025/06/26')
        assert "Error: start_date must be in YYYY-MM-DD format" in result
        
        # Test invalid due date
        result = update_issue_content(123, due_date='26-06-2025')
        assert "Error: due_date must be in YYYY-MM-DD format" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_invalid_hours(self, mock_get_client):
        """Test invalid hours"""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(123, estimated_hours=-5.0)
        assert "Error: estimated_hours cannot be negative" in result
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_with_parent_issue(self, mock_get_client):
        """Test set parent issue"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Test sub-issue',
            description='Description',
            status={'name': 'Newly created'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Feature'},
            author={'name': 'Test User'},
            done_ratio=0
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(123, parent_issue_id=100)
        
        assert "Issue content updated successfully" in result
        assert "Parent issue ID: 100" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(123, parent_issue_id=100)