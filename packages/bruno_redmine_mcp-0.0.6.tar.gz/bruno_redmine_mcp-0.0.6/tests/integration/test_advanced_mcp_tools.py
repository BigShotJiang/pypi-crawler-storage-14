"""
Advanced MCP Tools Tests
"""

import os
import pytest
from unittest.mock import patch, Mock
from redmine_mcp.server import (
    update_issue_content, add_issue_note, assign_issue,
    create_new_issue, get_my_issues, close_issue
)
from redmine_mcp.redmine_client import RedmineIssue, RedmineProject


class TestAdvancedMCPTools:
    """Advanced MCP Tools Tests"""
    
    def setup_method(self):
        """Setup before each test"""
        # Ensure test environment variables are set
        with patch.dict(os.environ, {
            'REDMINE_DOMAIN': 'https://test.redmine.com',
            'REDMINE_API_KEY': 'test_api_key'
        }):
            pass
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_success(self, mock_get_client):
        """Test update issue content successfully"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        # Mock updated issue
        updated_issue = RedmineIssue(
            id=123,
            subject='Updated title',
            description='Updated description',
            status={'name': 'In Progress'},
            priority={'name': 'High'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'},
            done_ratio=75
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(
            123,
            subject="Updated title",
            description="Updated description",
            done_ratio=75
        )
        
        assert "Issue content updated successfully" in result
        assert "Updated title" in result
        assert "Title: Updated title" in result
        assert "Description updated" in result
        assert "Done ratio: 75%" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(
            123, 
            subject="Updated title",
            description="Updated description",
            done_ratio=75
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_no_params(self, mock_get_client):
        """Test update issue content without parameters"""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(123)

        assert "Error: Please provide at least one field to update" in result
        mock_client.update_issue.assert_not_called()
    
    @patch('redmine_mcp.server.get_client')
    def test_update_issue_content_invalid_done_ratio(self, mock_get_client):
        """Test update issue content with invalid completion percentage"""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        result = update_issue_content(123, done_ratio=150)

        assert "Error: done_ratio must be between 0 and 100" in result
        mock_client.update_issue.assert_not_called()
    
    @patch('redmine_mcp.server.get_client')
    def test_add_issue_note_success(self, mock_get_client):
        """Test add issue note successfully"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        mock_issue = RedmineIssue(
            id=123,
            subject='Test Issue',
            description='Description',
            status={'name': 'New'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'}
        )
        mock_client.get_issue.return_value = mock_issue
        mock_get_client.return_value = mock_client
        
        result = add_issue_note(123, "This is a test note", private=True)
        
        assert "Note added successfully" in result
        assert "This is a test note" in result
        assert "Private" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(
            123, 
            notes="This is a test note",
            private_notes=True
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_add_issue_note_empty_notes(self, mock_get_client):
        """Test add issue note with empty content"""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        result = add_issue_note(123, "  ")

        assert "Error: note content cannot be empty" in result
        mock_client.update_issue.assert_not_called()
    
    @patch('redmine_mcp.server.get_client')
    def test_assign_issue_success(self, mock_get_client):
        """Test assign issue successfully"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Test Issue',
            description='Description',
            status={'name': 'New'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'},
            assigned_to={'name': 'Assigned User', 'id': 456}
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = assign_issue(123, 456, notes="Assign to test user")

        assert "Issue assignment updated successfully" in result
        assert "Assigned to user ID 456" in result
        assert "Assigned User" in result
        assert "Assign to test user" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(
            123, 
            assigned_to_id=456,
            notes="Assign to test user"
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_assign_issue_unassign(self, mock_get_client):
        """Test unassign issue"""
        mock_client = Mock()
        mock_client.update_issue.return_value = True
        
        updated_issue = RedmineIssue(
            id=123,
            subject='Test Issue',
            description='Description',
            status={'name': 'New'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'},
            assigned_to=None
        )
        mock_client.get_issue.return_value = updated_issue
        mock_get_client.return_value = mock_client
        
        result = assign_issue(123, None)
        
        assert "Issue assignment updated successfully" in result
        assert "Unassign" in result
        assert "Unassigned" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(123, assigned_to_id=None)
    
    @patch('redmine_mcp.server.get_client')
    def test_create_new_issue_success(self, mock_get_client):
        """Test create new issue successfully"""
        mock_client = Mock()
        mock_client.create_issue.return_value = 789
        
        new_issue = RedmineIssue(
            id=789,
            subject='New issue title',
            description='New issue description',
            status={'name': 'New'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Feature'},
            author={'name': 'Creating user'},
            assigned_to={'name': 'Assigned User'}
        )
        mock_client.get_issue.return_value = new_issue
        mock_get_client.return_value = mock_client
        
        result = create_new_issue(
            1, 
            "New issue title", 
            "New issue description",
            tracker_id=2,
            assigned_to_id=456
        )
        
        assert "New issue created successfully" in result
        assert "Issue ID: #789" in result
        assert "Title: New issue title" in result
        assert "Project: Test Project" in result
        assert "New issue description" in result
        
        # Verify call parameters
        mock_client.create_issue.assert_called_once_with(
            project_id=1,
            subject="New issue title",
            description="New issue description",
            tracker_id=2,
            priority_id=None,
            assigned_to_id=456
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_create_new_issue_empty_subject(self, mock_get_client):
        """Test create new issue with empty title"""
        mock_client = Mock()
        mock_get_client.return_value = mock_client
        
        result = create_new_issue(1, "  ")

        assert "Error: Issue subject cannot be empty" in result
        mock_client.create_issue.assert_not_called()
    
    @patch('redmine_mcp.server.get_client')
    def test_get_my_issues_success(self, mock_get_client):
        """Test get my issues successfully"""
        mock_client = Mock()
        
        # Mock current user
        mock_client.get_current_user.return_value = {
            'id': 123,
            'firstname': 'Test',
            'lastname': 'User'
        }
        
        # Mock issues list
        mock_issues = [
            RedmineIssue(
                id=101,
                subject='My issue 1',
                description='Description 1',
                status={'name': 'In Progress'},
                priority={'name': 'Normal'},
                project={'name': 'Project A', 'id': 1},
                tracker={'name': 'Bug'},
                author={'name': 'Other User'},
                updated_on='2024-01-01'
            )
        ]
        mock_client.list_issues.return_value = mock_issues
        mock_get_client.return_value = mock_client
        
        result = get_my_issues("open", 10)

        assert "Issues assigned to Test User" in result
        assert "Status filter: open" in result
        assert "Found 1 issue(s)" in result
        assert "My issue 1" in result
        
        # Verify call parameters
        mock_client.list_issues.assert_called_once_with(
            assigned_to_id=123,
            limit=10,
            sort='updated_on:desc',
            status_id='o'
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_close_issue_success(self, mock_get_client):
        """Test close issue successfully"""
        mock_client = Mock()
        
        # Mock statuses list
        mock_client.get_issue_statuses.return_value = [
            {'id': 1, 'name': 'New', 'is_closed': False},
            {'id': 5, 'name': 'Closed', 'is_closed': True}
        ]
        
        mock_client.update_issue.return_value = True
        
        closed_issue = RedmineIssue(
            id=123,
            subject='Closed issue',
            description='Description',
            status={'name': 'Closed'},
            priority={'name': 'Normal'},
            project={'name': 'Test Project', 'id': 1},
            tracker={'name': 'Bug'},
            author={'name': 'Test User'},
            done_ratio=100
        )
        mock_client.get_issue.return_value = closed_issue
        mock_get_client.return_value = mock_client
        
        result = close_issue(123, "Issue completed", 100)
        
        assert "Issue closed successfully" in result
        assert "Closed issue" in result
        assert "Status: Closed" in result
        assert "Done ratio: 100%" in result
        assert "Closing notes: Issue completed" in result
        
        # Verify call parameters
        mock_client.update_issue.assert_called_once_with(
            123,
            status_id=5,
            done_ratio=100,
            notes="Issue completed"
        )
    
    @patch('redmine_mcp.server.get_client')
    def test_close_issue_no_closed_status(self, mock_get_client):
        """Test close issue without closed status"""
        mock_client = Mock()
        
        # Mock without closed status
        mock_client.get_issue_statuses.return_value = [
            {'id': 1, 'name': 'New', 'is_closed': False},
            {'id': 2, 'name': 'In Progress', 'is_closed': False}
        ]
        
        mock_get_client.return_value = mock_client
        
        result = close_issue(123)
        
        assert "Error: No available closed status found" in result
        mock_client.update_issue.assert_not_called()