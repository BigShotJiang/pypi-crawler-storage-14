# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

This is an MCP (Model Context Protocol) server project that integrates with Redmine. It uses Python 3.12+ and the `uv` package manager.

## Development setup

### Dependency management
- Use `uv` as the package manager
- Install dependencies: `uv sync`
- Run tests: `uv run python -m pytest`

### Project structure
```
redmine-mcp/
├── src/redmine_mcp/          # main source code
│   ├── __init__.py           # package initialization
│   ├── server.py             # MCP server main program ✓ implemented
│   ├── redmine_client.py     # Redmine API client ✓ implemented
│   ├── config.py             # configuration management ✓ implemented
├── tests/                    # test files
├── docs/                     # documentation
│   ├── issues/               # development issues
│   └── manuals/              # technical manuals
├── pyproject.toml            # project config and dependencies
├── uv.lock                   # locked dependency versions
└── .env                      # environment variables (to be created)
```

## MCP development details

### Tech stack
- **MCP SDK**: mcp[cli] >= 1.9.4 (using FastMCP)
- **HTTP client**: requests >= 2.31.0
- **Configuration**: python-dotenv >= 1.0.0
- **Python version**: >= 3.12

### MCP server architecture
- Uses FastMCP to build the server
- Tools are registered with the `@mcp.tool()` decorator
- Supports async operations and type safety

### Redmine API integration
- Issue management: query, create, update, delete issues
- Project management: query, create, update, delete, archive projects
- User management: query users and get current user info
- Metadata queries: status, priorities, tracker lists
- Watcher management: add/remove issue watchers
- Full filtering support: multi-criteria filters and sorting

## Claude Code integration

### Installing to Claude Code
```bash
# Install MCP server
uv tool install .

# Or using pip
pip install .

# Add to Claude Code
claude mcp add redmine "redmine-mcp" \
  -e REDMINE_DOMAIN="https://your-redmine-domain.com" \
  -e REDMINE_API_KEY="your_api_key_here" \
  -e REDMINE_MCP_LOG_LEVEL="INFO" \
  -e REDMINE_MCP_TIMEOUT="30"
```

### Environment variables

To avoid collisions with other projects' environment variables, redmine-mcp uses an MCP-specific prefix:

- Required variables:
  - `REDMINE_DOMAIN`: Redmine server URL
  - `REDMINE_API_KEY`: Redmine API key

- Log level control:
  - `REDMINE_MCP_LOG_LEVEL`: MCP-specific log level (default: INFO)
  - `FASTMCP_LOG_LEVEL`: FastMCP built-in var (optional)
    - If not set, it will inherit `REDMINE_MCP_LOG_LEVEL`
    - Setting this allows controlling FastMCP logging independently

- Other configuration:
  - `REDMINE_MCP_TIMEOUT`: Request timeout (seconds)
  - `REDMINE_TIMEOUT`: Backwards compatible timeout variable

### Available MCP tools (22)
- Management: server_info, health_check, refresh_cache ✨ new
- Query: get_issue, list_project_issues, get_projects, get_issue_statuses, get_trackers, get_priorities, get_time_entry_activities, get_document_categories, search_issues, get_my_issues
- User tools: search_users, list_users, get_user ✨ new
- Edit tools: update_issue_status, update_issue_content, add_issue_note ✨ time-tracking support, assign_issue, close_issue ✨ name-parameter support
- Create tools: create_new_issue ✨ name-parameter support

## Common commands

```bash
# 安裝依賴
uv sync

# 執行 MCP 服務器
uv run python -m redmine_mcp.server

# 測試 Claude Code 整合
uv run python tests/scripts/claude_integration.py

# 執行單元測試
uv run python -m pytest tests/unit/

# 執行所有測試
uv run python -m pytest tests/

# 添加新依賴
uv add <package-name>
```

## Smart caching system ✨

### Cache features
- Multi-domain support: separate cache files are created per Redmine domain
- Auto-refresh: cache entries are refreshed every 24 hours
- Comprehensive coverage: caches enumerations (priorities, statuses, trackers) and user data
- File location: `~/.redmine_mcp/cache_{domain}_{hash}.json`

### Helper functions available
```python
client = get_client()

# Enumeration lookups
priority_id = client.find_priority_id_by_name("Low")           # → 5
status_id = client.find_status_id_by_name("In Progress")      # → 2
tracker_id = client.find_tracker_id_by_name("Bug")            # → 1

# User lookups
user_id = client.find_user_id("Redmine Admin")                # smart lookup (name or login)
user_id = client.find_user_id_by_name("Redmine Admin")        # name-only lookup
user_id = client.find_user_id_by_login("admin")               # login-only lookup

# Time entry activity lookup
activity_id = client.find_time_entry_activity_id_by_name("Development")  # → 11

# Get all available options
priorities = client.get_available_priorities()              # {"Low": 5, "Normal": 6, ...}
users = client.get_available_users()                        # {"by_name": {...}, "by_login": {...}}
activities = client.get_available_time_entry_activities()   # {"Design": 10, "Development": 11, ...}

# Manually refresh cache
client.refresh_cache()
```

### MCP tools
- `refresh_cache()`: manually refresh the cache and show statistics

## Name-parameter support ✨

### MCP tools that support name parameters
The following tools now accept names in addition to IDs:

```python
# Update issue status (using name)
update_issue_status(issue_id=1, status_name="In Progress")

# Update issue content (using names)
update_issue_content(
  issue_id=1,
  priority_name="High",
  tracker_name="Bug"
)

# Assign issue (by name or login)
assign_issue(issue_id=1, user_name="Redmine Admin")
assign_issue(issue_id=1, user_login="admin")

# Create new issue (using names)
create_new_issue(
  project_id=1,
  subject="New feature development",
  priority_name="Normal",
  tracker_name="Feature",
  assigned_to_name="Redmine Admin"
)
```

### Error handling
If a provided name does not exist, the tool will automatically list available options:
```
Priority name not found: "Ultra High"

Available priorities:
- Low
- Normal
- High
- Urgent
```

## Time tracking features ✨

### add_issue_note time-tracking support
You can now record work time when adding an issue note:

```python
# Add a note and record time (by activity name)
add_issue_note(
  issue_id=1,
  notes="Completed feature development",
  spent_hours=2.5,
  activity_name="Development"
)

# Add a note and record time (by activity ID)
add_issue_note(
  issue_id=1,
  notes="Fixed a bug",
  spent_hours=1.0,
  activity_id=12,
  spent_on="2025-06-25"  # specify the date for the time entry
)

# Private note + time tracking
add_issue_note(
  issue_id=1,
  notes="Internal discussion record",
  private=True,
  spent_hours=0.5,
  activity_name="Discussion"
)

# Add only a note (backwards compatible)
add_issue_note(issue_id=1, notes="General note")
```

### Time entry activities support
The system supports the following default activities:
- Design (ID: 10)
- Development (ID: 11)
- Debugging (ID: 12)
- Investigation (ID: 13)
- Discussion (ID: 14)
- Testing (ID: 15)
- Maintenance (ID: 16)
- Documentation (ID: 17)
- Training (ID: 18)
- Translation (ID: 19)
- Other (ID: 20)

### Key features
- **Smart cache**: time entry activities are cached to improve lookup performance
- **Name parameters**: supports activity names instead of IDs for easier usage
- **Backwards compatible**: preserves original `add_issue_note` functionality
- **Helpful errors**: invalid activity names will list available options
- **Flexible dates**: you can specify the date for the time entry (defaults to today)

## Notes

- This project is in early development.
- This file will be updated as the project progresses.

## Read-only mode

Read-only mode prevents mutating operations (create/update/delete) and is useful for running the MCP server in environments where changes to Redmine must be blocked (e.g., staging, demos, or audits).

How to enable
- Set the environment variable `REDMINE_MCP_READ_ONLY=1` or `REDMINE_READ_ONLY=true`.

Examples

Enable for the current PowerShell session:
```powershell
$env:REDMINE_MCP_READ_ONLY = '1'
```

Enable when launching the server (PowerShell):
```powershell
$env:REDMINE_MCP_READ_ONLY = '1'; uv run python -m redmine_mcp.server
```

Enable in Claude Code when adding the MCP:
```bash
claude mcp add redmine "redmine-mcp" \
  -e REDMINE_DOMAIN="https://your-redmine-domain.com" \
  -e REDMINE_API_KEY="your_api_key_here" \
  -e REDMINE_MCP_LOG_LEVEL="INFO" \
  -e REDMINE_MCP_TIMEOUT="30" \
  -e REDMINE_MCP_READ_ONLY="true"
```

Behavior
- When enabled, tools that would mutate remote data return a friendly message indicating the server is running in read-only mode and do not call the Redmine API to perform changes.
- Read-only is enforced by the configuration (`RedmineConfig.read_only`) and checked in server tool handlers before performing updates.

Notes
- This mode only blocks mutating tools in the MCP layer; it does not change Redmine server permissions. For security-sensitive environments also consider configuring Redmine user permissions appropriately.