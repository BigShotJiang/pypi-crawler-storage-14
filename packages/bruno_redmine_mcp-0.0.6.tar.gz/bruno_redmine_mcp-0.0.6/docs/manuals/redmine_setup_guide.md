# Redmine 完整設定指南

本指南提供詳細的 Redmine 初始化設定步驟，確保能夠正常使用 redmine-mcp 工具。

## 🎯 設定概覽

Redmine 設定需要以下步驟：
1. ✅ 啟用 REST API
2. ✅ 設定系統基本資料
3. ✅ 建立專案
4. ✅ 取得 API 金鑰

## 📋 詳細設定步驟

### 1. 啟用 REST API

# Redmine Setup Guide

This guide provides detailed steps to initialize Redmine so it can be used with the redmine-mcp tools.

## 🎯 Overview

Setting up Redmine for use with redmine-mcp includes the following steps:
1. ✅ Enable the REST API
2. ✅ Configure system settings
3. ✅ Create a project
4. ✅ Obtain an API key

## 📋 Detailed setup steps

### 1. Enable the REST API
> This must be done as an administrator

1. Log in to the Redmine administration interface
2. Go to Administration → Settings → API
3. Check "Enable REST web service"
4. Click Save

### 2. Configure roles and permissions
> Recommended minimum permissions

Create roles
1. Go to Administration → Roles and permissions
2. Click New role
3. Create the following roles:

| Role | Suggested permissions |
|------|----------------------|
| Developer | View issues, Add issues, Edit issues, Add notes, Manage watchers |
| Tester | View issues, Add issues, Edit issues, Add notes |
| Project Manager | All issue-related permissions, View project, Manage members |

Key permissions
- ✅ View issues — required for `get_issue`, `list_project_issues`, etc.
- ✅ Add issues — required for `create_new_issue`
- ✅ Edit issues — required for `update_issue_status`, `assign_issue`, etc.
- ✅ Add notes — required for `add_issue_note`
- ✅ Manage watchers — optional, used for watcher features

### 3. Configure trackers
> Suggested basic tracker types

1. Go to Administration → Trackers
2. Create the following trackers:

| Tracker | Purpose | Default status |
|---------|---------|----------------|
| Bug | Software defect tracking | New |
| Feature | New feature requests | New |
| Support | Technical support requests | New |

Tracker settings
- Set the default status for each tracker
- Select applicable custom fields (if any)

### 4. Configure issue statuses
> Suggested basic statuses

1. Go to Administration → Issue statuses
2. Create the following statuses:

| Status | Is closed? | Purpose |
|--------|------------|---------|
| New | ❌ | Newly created issues |
| In Progress | ❌ | Issues being worked on |
| Waiting for Feedback | ❌ | Awaiting user response |
| Resolved | ❌ | Fixed but pending verification |
| Closed | ✅ | Completed issues |
| Rejected | ✅ | Will not be handled |

Important
- There must be at least one "Closed" status (used by the `close_issue` tool)
- Set status colors appropriately for visual distinction

### 5. Configure issue priorities
> Define priority levels

1. Go to Administration → Enumerations → Issue priorities
2. Create or edit priorities:

| Priority | Suggested use | Default |
|----------|---------------|---------|
| Low | Non-urgent improvements | ❌ |
| Normal | Regular issues | ✅ |
| High | Important issues or bugs (prioritize) | ❌ |
| Urgent | Needs action within 2 days | ❌ |
| Critical | Immediate action required | ❌ |

### 6. Configure time tracking activities
> Define work types (if the time tracking module is enabled)

1. Go to Administration → Enumerations → Time tracking activities
2. Create activity types:

| Activity | Purpose | Default |
|---------|---------|--------|
| Design | System design and planning | ✅ |
| Development | Software development and coding | ❌ |
| Debugging | Bug fixes | ❌ |
| Investigation | Analysis and research | ❌ |
| Discussion | Meetings and technical discussions | ❌ |
| Testing | Tests and QA | ❌ |
| Maintenance | System maintenance and support | ❌ |
| Documentation | Writing and maintaining docs | ❌ |
| Training | Training and knowledge sharing | ❌ |
| Translation | Localization work | ❌ |
| Other | Other types of work | ❌ |

### 7. Configure document categories
> Define document organization categories (if the documents module is enabled)

1. Go to Administration → Enumerations → Document categories
2. Create document categories:

| Category | Purpose | Default |
|----------|---------|---------|
| User Manual | User guides and instructions | ✅ |
| Technical Documentation | Technical specs and design docs | ❌ |
| Forms | Various forms and templates | ❌ |
| Requirements | System requirements and specs | ❌ |

### 8. Configure workflows
> Define allowed status transitions

1. Go to Administration → Workflows
2. Select role and tracker combinations
3. Configure allowed transitions

Suggested basic workflow
```
New → In Progress → Resolved → Closed
  ↓      ↓        ↓
Waiting for Feedback ← ← ← ← ← ← ← ← ← (from any status)
  ↓
Rejected
```

Important reminders
- Ensure each role can perform basic transitions
- Test the critical path: New → In Progress → Closed
- Confirm the transition paths required by the `close_issue` tool are available

### 9. Create a project
> Set up your first test project

1. Go to Projects → New project
2. Fill in project information:
   - Name: Test Project
   - Identifier: test-project (used for API calls)
   - Description: Project for testing MCP tools
   - Home page: (optional)

3. Select modules:
   - ✅ Issues
   - ✅ Time tracking (optional)
   - ✅ Documents (optional)
   - ✅ Files (optional)

4. Configure trackers for the project:
   - Select the tracker types the project will use
   - At minimum, choose Bug and Feature

5. Add members:
   - Add users to the project and assign appropriate roles

### 10. Verify the setup
> Test that basic functionality works

Using the MCP tools
1. Obtain an API key and set environment variables
2. Run the following tests:

```bash
# Test connection
uv run python -c "from redmine_mcp.server import health_check; print(health_check())"

# Test project list
uv run python -c "from redmine_mcp.server import get_projects; print(get_projects())"

# Test status list
uv run python -c "from redmine_mcp.server import get_issue_statuses; print(get_issue_statuses())"

# Test trackers list
uv run python -c "from redmine_mcp.server import get_trackers; print(get_trackers())"

# Test priorities list
uv run python -c "from redmine_mcp.server import get_priorities; print(get_priorities())"

# Test time entry activities list
uv run python -c "from redmine_mcp.server import get_time_entry_activities; print(get_time_entry_activities())"

# Test document categories list
uv run python -c "from redmine_mcp.server import get_document_categories; print(get_document_categories())"
```

Manual issue test
1. Create a test issue in the project via the Redmine UI
2. Try changing the issue status
3. Add a note to the issue

## 🚨 Troubleshooting

### Problem: Cannot create an issue
Possible causes
- Workflow does not allow the transition
- User lacks required permissions
- Tracker configuration issue

Fixes
1. Check that the workflow allows transitioning from no status to "New"
2. Ensure the user has "Add issues" permission in the project
3. Make sure the tracker is enabled and has a default status

### Problem: Cannot update issue status
Possible causes
- Workflow does not permit the transition
- User role does not have the permission

Fixes
1. Check the workflow configuration
2. Ensure the user has "Edit issues" permission
3. Test a manual status transition in the UI

### Problem: Project or issue not found
Possible causes
- User does not have view permissions
- The project is archived

Fixes
1. Ensure the user is a project member
2. Check that the project status is Active
3. Confirm the user has "View issues" permission

## 📝 Setup checklist

Before using redmine-mcp, confirm the following:

- [ ] ✅ REST API is enabled
- [ ] ✅ At least one role exists with basic issue permissions
- [ ] ✅ At least one tracker is created
- [ ] ✅ Basic issue statuses are created (including at least one "Closed" status)
- [ ] ✅ Issue priorities are set (recommended: Low, Normal, High, Urgent)
- [ ] ✅ Time tracking activities are configured (if using time tracking)
- [ ] ✅ Document categories are configured (if using documents)
- [ ] ✅ Basic workflows are set up (allow transitions)
- [ ] ✅ At least one project is created
- [ ] ✅ Users added to the project with assigned roles
- [ ] ✅ API key obtained
- [ ] ✅ Basic MCP functionality tested

## 🔗 Resources

- [Redmine Administration Guide](https://www.redmine.org/projects/redmine/wiki/RedmineAdministration)
- [Redmine REST API documentation](https://www.redmine.org/projects/redmine/wiki/Rest_api)
- [Workflow configuration](https://www.redmine.org/projects/redmine/wiki/RedmineWorkflow)
- [Roles and permissions](https://www.redmine.org/projects/redmine/wiki/RedmineRoles)

---

After completing these steps, you should be ready to use all redmine-mcp features.