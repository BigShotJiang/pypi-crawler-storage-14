"""
Configuration management module
Responsible for loading and validating environment variable configuration
"""

import os
from typing import Optional
from dotenv import load_dotenv


class RedmineConfig:
    """Redmine MCP server configuration manager"""
    
    def __init__(self):
        # Load environment variables
        load_dotenv()
        
        # Required configuration
        self.redmine_domain = self._get_required_env("REDMINE_DOMAIN")
        self.redmine_api_key = self._get_required_env("REDMINE_API_KEY")
        
        # Optional configuration - prefer MCP-specific prefix to avoid collisions
        self.redmine_timeout = int(os.getenv("REDMINE_MCP_TIMEOUT") or os.getenv("REDMINE_TIMEOUT") or "30")
        
        # Log level resolution strategy:
        # 1. Prefer REDMINE_MCP_LOG_LEVEL (MCP-specific)
        # 2. Fallback to LOG_LEVEL (legacy)
        # 3. Default to INFO if none set
        # 4. FASTMCP_LOG_LEVEL will always follow the resolved log level
        redmine_log_level = os.getenv("REDMINE_MCP_LOG_LEVEL")
        if redmine_log_level:
            self.log_level = redmine_log_level.upper()
        else:
                # Backwards compatibility: if MCP-specific var is missing, check legacy LOG_LEVEL
            legacy_log_level = os.getenv("LOG_LEVEL")
            if legacy_log_level:
                self.log_level = legacy_log_level.upper()
            else:
                self.log_level = "INFO"
        
        # FastMCP log level control - always set to the resolved log level
        # This overrides any user-provided FASTMCP_LOG_LEVEL
        os.environ["FASTMCP_LOG_LEVEL"] = self.log_level
        self.fastmcp_log_level = self.log_level
        
        self.effective_log_level = self.log_level
        self.debug_mode = self.effective_log_level == "DEBUG"
        # Read-only mode: when true, mutating operations should be blocked
        ro_val = os.getenv("REDMINE_MCP_READ_ONLY") or os.getenv("REDMINE_READ_ONLY")
        if ro_val:
            self.read_only = str(ro_val).strip().lower() in ("1", "true", "yes", "on")
        else:
            self.read_only = False
        
        self._validate_config()
    
    def _get_required_env(self, key: str) -> str:
        """Return a required environment variable, raise if missing"""
        value = os.getenv(key)
        if not value:
            raise ValueError(f"Required environment variable {key} is not set")
        return value
    
    def _validate_config(self) -> None:
        """Validate configuration values"""
        # Validate domain format
        if not self.redmine_domain.startswith(('http://', 'https://')):
            raise ValueError("REDMINE_DOMAIN must start with http:// or https://")

        # Strip trailing slash
        self.redmine_domain = self.redmine_domain.rstrip('/')

        # Validate API key is not empty
        if not self.redmine_api_key.strip():
            raise ValueError("REDMINE_API_KEY cannot be empty")

        # Validate timeout value
        if self.redmine_timeout <= 0:
            raise ValueError("REDMINE_TIMEOUT must be greater than 0")

        # Validate log_level value
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.log_level not in valid_levels:
            raise ValueError(f"Log level must be one of: {', '.join(valid_levels)} (current: {self.log_level})")
    
    @property
    def api_headers(self) -> dict[str, str]:
        """Return headers required for API requests"""
        return {
            'X-Redmine-API-Key': self.redmine_api_key,
            'Content-Type': 'application/json'
        }
    
    def __repr__(self) -> str:
        """Debug-friendly string representation, hides sensitive info"""
        return f"RedmineConfig(domain='{self.redmine_domain}', timeout={self.redmine_timeout}, log_level='{self.log_level}', fastmcp_log_level='{self.fastmcp_log_level}', debug={self.debug_mode}, read_only={self.read_only})"


# Global configuration instance
_config: Optional[RedmineConfig] = None


def get_config() -> RedmineConfig:
    """Return the global configuration instance (singleton)"""
    global _config
    if _config is None:
        _config = RedmineConfig()
    return _config


def reload_config() -> RedmineConfig:
    """Reload configuration (primarily used for tests)"""
    global _config
    _config = None
    return get_config()