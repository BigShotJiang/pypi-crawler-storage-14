# PyPI 打包与发布指南 📦

本教程将指导你如何将 `aib` 工具打包并发布到 PyPI (Python Package Index)，让全世界的用户都能通过 `pip install aib` 安装它。

## 1. 准备工作

### 1.1 注册 PyPI 账号
如果你还没有账号，请前往 [PyPI 官网](https://pypi.org/) 注册。
*   建议开启 2FA (双重认证)。
*   前往 [Account Settings](https://pypi.org/manage/account/) -> **API tokens**，创建一个新的 Token。
    *   Scope 选择 "Entire account" (首次发布) 或指定项目。
    *   **保存好这个 Token** (以 `pypi-` 开头)，它只显示一次。

### 1.2 确认项目元数据
检查 `pyproject.toml` 文件，确保以下信息准确无误：
*   `name`: 包名 (注意：`aib` 可能已经被占用了，建议改为 `aib-cli` 或其他独特的名字)。
*   `version`: 版本号 (如 `1.0.0`)。
*   `description`: 项目简介。
*   `dependencies`: 依赖列表。

## 2. 构建 (Build)

我们将使用 `uv` 来构建项目的发行包 (Wheel 和 Source Distribution)。

在项目根目录下运行：

```powershell
uv build
```

运行成功后，你会发现根目录下多了一个 `dist/` 文件夹，里面包含：
*   `aib-1.0.0-py3-none-any.whl` (构建包)
*   `aib-1.0.0.tar.gz` (源码包)

## 3. 发布 (Publish)

### 方式 A: 使用 uv 发布 (推荐，最快)

`uv` 从 0.4.x 版本开始支持直接发布。

```powershell
# 使用你的 API Token 进行发布
uv publish --token pypi-xxxxxxxxxxxx
```

### 方式 B: 使用 Twine 发布 (传统，最稳)

如果你习惯使用标准的 `twine` 工具：

1.  安装 twine:
    ```powershell
    uv tool install twine
    ```

2.  上传包:
    ```powershell
    uv tool run twine upload dist/*
    ```

3.  输入凭证:
    *   Username: `__token__`
    *   Password: `pypi-xxxxxxxxxxxx` (你的 API Token)

## 4. 验证安装

发布成功后，等待几分钟，你就可以在任何地方安装你的工具了：

```bash
pip install aib-cli  # 替换为你发布的实际包名
```

## 5. 版本更新流程

当你开发了新功能需要更新时：

1.  修改 `pyproject.toml` 中的 `version` (例如改为 `1.0.1`)。
2.  重新构建: `uv build`
3.  重新发布: `uv publish`

---

## 💡 常见问题

*   **HTTP 403 Forbidden**: 说明包名 (`name`) 已经被别人注册了。你需要修改 `pyproject.toml` 中的 `name` 字段（例如改为 `my-aib-tool`），然后重新构建发布。
*   **File already exists**: PyPI 不允许覆盖已发布的版本。如果你修改了代码，必须增加版本号。
