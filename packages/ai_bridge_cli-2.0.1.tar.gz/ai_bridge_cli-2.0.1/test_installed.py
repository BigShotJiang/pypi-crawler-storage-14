#!/usr/bin/env python
"""测试安装后的包行为"""
import sys
import subprocess

# 测试1: 直接导入 web 模块
try:
    from aib.web.app import main as web_main
    print("[OK] 可以导入 aib.web.app")
except ImportError as e:
    print(f"[FAIL] 导入失败: {e}")

# 测试2: 测试 nicegui 是否可用
try:
    import nicegui
    print(f"[OK] nicegui 已安装，版本: {nicegui.__version__}")
except ImportError as e:
    print(f"[FAIL] nicegui 未安装: {e}")

# 测试3: 模拟命令行参数
print("\n--- 测试命令行 ---")
result = subprocess.run([sys.executable, "-m", "aib.cli", "--help"], 
                       capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("错误输出:", result.stderr)

# 测试4: 尝试启动 web (会失败因为没有配置)
print("\n--- 测试 web 启动 ---")
try:
    result = subprocess.run([sys.executable, "-m", "aib.cli", "--web", "--port", "8888"], 
                           capture_output=True, text=True, timeout=3)
    print("stdout:", result.stdout)
    print("stderr:", result.stderr)
except subprocess.TimeoutExpired:
    print("[OK] Web 启动尝试已执行 (超时，这是正常的)")