from pathlib import Path
import mimetypes
import time
from google import genai
from google.genai import types
from ..utils.common import parse_result

def handler(api_key, model, prompt, file_path=None, analyze_file=False, base_url=None, json_mode=False, **kwargs):
    client_kwargs = {"api_key": api_key}
    if base_url: client_kwargs["http_options"] = {"api_endpoint": base_url}
    client = genai.Client(**client_kwargs)
    
    # 动态配置 JSON Mode
    config_args = {"temperature": 0.1}
    if json_mode:
        config_args["response_mime_type"] = "application/json"
    config_args.update(kwargs)
    
    contents = []

    try:
        if analyze_file and file_path:
            if not file_path: return {"error": "缺少 file_path"}
            file_obj = Path(file_path)
            mime_type, _ = mimetypes.guess_type(file_obj.name.lower())
            if not mime_type:
                if file_obj.suffix.lower() in ['.mp4', '.mov']: mime_type = "video/mp4"
                elif file_obj.suffix.lower() == '.pdf': mime_type = "application/pdf"
                else: mime_type = "application/octet-stream"

            # 强制英文名规避 ASCII 错误
            with open(file_obj, "rb") as f:
                uploaded_file = client.files.upload(
                    file=f, 
                    config=types.UploadFileConfig(display_name="upload_doc", mime_type=mime_type)
                )
            
            # 视频/大文件等待逻辑
            while uploaded_file.state.name == "PROCESSING":
                time.sleep(1)
                uploaded_file = client.files.get(name=uploaded_file.name)
            
            if uploaded_file.state.name != "ACTIVE": return {"error": f"文件状态异常: {uploaded_file.state.name}"}
            contents.append(uploaded_file)
            contents.append(prompt)
        else:
            contents.append(prompt)

        response = client.models.generate_content(
            model=model, 
            contents=contents, 
            config=types.GenerateContentConfig(**config_args)
        )
        
        if response.usage_metadata:
            u = response.usage_metadata
            print(f"💰 [Gemini Token] In: {u.prompt_token_count} | Out: {u.candidates_token_count}")

        try:
            txt = response.text
        except ValueError:
            # 安全过滤可能导致 text 属性不可用
            return {"error": "Gemini Refused (Safety/Other)", "details": str(response.candidates)}

        return parse_result(txt, force_json=json_mode)
    except Exception as e: return {"error": f"Gemini Error: {str(e)}"}