"""工具函数模块"""
import os
from ..main import smart_process

async def run_smart_process_wrapper(**kwargs):
    """直接调用 smart_process（已经是异步的）"""
    return await smart_process(**kwargs)

def load_web_config(config_path=None):
    """加载 Web UI 配置
    
    优先级:
    1. 命令行参数 -c
    2. 环境变量 AIB_WEB_CONFIG
    3. 默认位置 ~/.aibatch/config.yaml
    """
    from ..config import load_config
    
    # 优先级 1: 命令行参数
    if config_path:
        return load_config(config_path)
    
    # 优先级 2: 环境变量
    env_path = os.getenv('AIB_WEB_CONFIG')
    if env_path:
        return load_config(env_path)
    
    # 优先级 3: 默认位置
    default_path = os.path.expanduser('~/.aibatch/config.yaml')
    if os.path.exists(default_path):
        return load_config(default_path)
    
    # 无配置 -> 返回空配置对象
    return {'vendors': {}, 'default_vendor': 'kimi'}
