"""主界面页面 - 现代 Chat 风格重构版"""
from nicegui import ui, events
from ..utils import run_smart_process_wrapper
import tempfile
import os

def main_page(state):
    """显示主界面"""
    ui.dark_mode().disable()
    
    # 全局样式
    ui.add_head_html('''
        <style>
            .q-field--outlined .q-field__control { border-radius: 12px; }
            .chat-bubble { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
            .upload-btn { transition: all 0.3s; }
            .upload-btn:hover { background-color: #f5f5f5; transform: scale(1.05); }
        </style>
    ''')

    # 状态容器
    uploaded_files = []
    
    # === 顶部导航 (必须是顶层元素) ===
    with ui.header().classes('bg-white text-grey-9 shadow-sm items-center h-14 px-4 border-b border-gray-200'):
        ui.icon('smart_toy', size='2rem').classes('text-primary')
        ui.label('AI Bridge').classes('text-h6 ml-2 font-bold')
        ui.space()

    # === 内容区 (左侧交互 + 右侧侧边栏) ===
    # Header 高度 h-14 (3.5rem)，主区域高度设为 100vh - 3.5rem
    with ui.row().classes('w-full h-[calc(100vh-3.5rem)] no-wrap gap-0 bg-gray-50 overflow-hidden'):
        
        # --- 左侧核心区 ---
        with ui.column().classes('flex-grow h-full relative'):
                
                # 1. 结果展示区 (Scroll Area - 自适应高度)
                with ui.scroll_area().classes('w-full flex-grow p-4') as scroll_container:
                    result_container = ui.column().classes('w-full max-w-4xl mx-auto gap-4 pb-4')
                    
                    # 初始欢迎语
                    with result_container:
                        if not state.history:
                            with ui.column().classes('w-full items-center justify-center mt-20 opacity-50'):
                                ui.icon('auto_awesome', size='4rem').classes('text-grey-4 mb-4')
                                ui.label('开始你的 AI 之旅').classes('text-h5 text-grey-5')
                                ui.label('选择厂商，输入 Prompt，或者上传文件').classes('text-grey-4')

                # 2. 底部输入区 (固定高度)
                with ui.column().classes('w-full bg-white border-t border-gray-200 p-4 flex-shrink-0'):
                    input_wrapper = ui.column().classes('w-full max-w-4xl mx-auto')
                    
                    with input_wrapper:
                        # === 上传/拖拽区域 ===
                        async def handle_upload(e: events.UploadEventArguments):
                            try:
                                # 修复：NiceGUI 2.0+ UploadEventArguments 包含 .file 属性
                                file_obj = e.file
                                file_name = file_obj.name or 'unknown_file'
                                
                                # 读取内容 (异步)
                                content = await file_obj.read()
                                
                                # === 优化: 保存到项目专用临时目录 ===
                                file_ext = os.path.splitext(file_name)[1] if file_name else '.bin'
                                tmp_dir = os.path.expanduser('~/.aibatch/tmp')
                                os.makedirs(tmp_dir, exist_ok=True)
                                
                                import uuid
                                tmp_filename = f"{uuid.uuid4().hex}{file_ext}"
                                tmp_path = os.path.join(tmp_dir, tmp_filename)
                                
                                with open(tmp_path, 'wb') as f:
                                    f.write(content)
                                
                                # 修复：存入字典而非纯路径，匹配 update_file_chips 的预期
                                uploaded_files.append({'path': tmp_path, 'name': file_name})
                                update_file_chips()
                                ui.notify(f'已添加: {file_name}', type='positive', position='top-left')
                            except Exception as ex:
                                ui.notify(f'文件读取失败: {str(ex)}', type='negative', position='top-left')
                            finally:
                                upload_element.run_method('reset')

                        upload_element = ui.upload(
                            label='点击选择或拖拽文件至此 (支持多选)',
                            multiple=True,
                            max_files=20,
                            auto_upload=True,
                            on_upload=handle_upload
                        ).props('flat bordered color=grey-7 text-color=grey-9 no-thumbnails').classes('w-full h-16 mb-2 bg-grey-1 border-dashed border-2 border-gray-300 rounded-lg transition-colors hover:bg-blue-50')

                        # 文件展示区 (Chips)
                        files_display = ui.row().classes('w-full gap-2 mb-2')
                        
                        def update_file_chips():
                            files_display.clear()
                            has_files = len(uploaded_files) > 0
                            
                            # 逻辑优化：有文件时隐藏大拖拽框，显示紧凑的 Chips 和添加按钮
                            upload_element.set_visibility(not has_files)
                            
                            with files_display:
                                for f_obj in uploaded_files:
                                    ui.chip(
                                        text=f_obj['name'], 
                                        removable=True, 
                                        on_value_change=lambda e, x=f_obj: remove_file(x) if not e.value else None
                                    ).classes('bg-blue-50 text-blue-800 text-sm max-w-[200px] truncate')
                                
                                # 如果有文件，在 Chips 后面显示一个小加号按钮继续上传
                                if has_files:
                                    ui.button(icon='add', on_click=lambda: upload_element.run_method('pickFiles')).props('round flat size=sm dense color=grey-6').tooltip('添加更多文件')
                        
                        def remove_file(file_obj):
                            if file_obj in uploaded_files:
                                uploaded_files.remove(file_obj)
                                update_file_chips()

                        # 发送逻辑
                        async def send_message():
                            text = prompt_input.value.strip()
                            if not text and not uploaded_files:
                                ui.notify('请输入内容或上传文件', type='warning', position='top-left')
                                return
                            
                            if not state.api_key:
                                ui.notify('请先在右侧配置 API Key', type='warning', position='top-left')
                                right_drawer.toggle()
                                tabs.set_value('settings')
                                return

                            # 1. UI 更新: 显示用户消息
                            with result_container:
                                # 用户气泡
                                with ui.row().classes('w-full justify-end'):
                                    with ui.card().classes('bg-blue-600 text-white p-3 rounded-2xl rounded-tr-sm max-w-[80%]'):
                                        if uploaded_files:
                                            # 显示前3个文件名
                                            names = [f['name'] for f in uploaded_files[:3]]
                                            if len(uploaded_files) > 3:
                                                names.append(f"...(+{len(uploaded_files)-3})")
                                            ui.label(f'[附件: {", ".join(names)}]').classes('text-xs opacity-80 mb-1 block')
                                        
                                        if text:
                                            ui.label(text).classes('whitespace-pre-wrap')
                            
                            # 滚动到底部 (增加延迟确保渲染完成)
                            import asyncio
                            await asyncio.sleep(0.1)
                            scroll_container.scroll_to(percent=1.0)
                            
                            # 2. 准备请求
                            request_data = {
                                'vendor': state.current_vendor,
                                'api_key': state.api_key,
                                'model': state.model,
                                'prompt': text or "Analyze the uploaded file(s).", # 如果没有文字，给个默认 prompt
                                'json_mode': state.json_mode,
                                'base_url': state.base_url or None
                            }
                            
                            # 提取文件路径用于请求
                            current_file_objs = list(uploaded_files) # 复制列表用于后续清理
                            current_file_paths = [f['path'] for f in current_file_objs]
                            
                            if current_file_paths:
                                request_data['input_target'] = current_file_paths[0] if len(current_file_paths) == 1 else current_file_paths
                            
                            # 清空输入
                            prompt_input.value = ''
                            
                            # 3. UI 更新: AI 思考中
                            with result_container:
                                loading_row = ui.row().classes('w-full justify-start')
                                with loading_row:
                                    with ui.row().classes('items-center gap-2 text-grey-6 bg-white p-3 rounded-2xl rounded-tl-sm shadow-sm'):
                                        ui.spinner('dots', size='sm')
                                        ui.label(f'{state.current_vendor} 正在思考...')
                            
                            await asyncio.sleep(0.1)
                            scroll_container.scroll_to(percent=1.0)

                            # 4. 执行请求
                            try:
                                result = await run_smart_process_wrapper(**request_data)
                                
                                # 移除 loading
                                result_container.remove(loading_row)
                                
                                # 显示 AI 回复
                                with result_container:
                                    with ui.row().classes('w-full justify-start'):
                                        with ui.column().classes('bg-white p-4 rounded-2xl rounded-tl-sm shadow-sm max-w-full overflow-hidden border border-gray-100'):
                                            # 顶部信息栏
                                            with ui.row().classes('w-full items-center text-xs text-grey-5 mb-2 gap-2 border-b border-gray-100 pb-1'):
                                                ui.icon('smart_toy', size='xs')
                                                ui.label(f'{state.current_vendor} | {state.model}')
                                                ui.space()
                                                ui.button(icon='content_copy', on_click=lambda: ui.clipboard.write(str(result))).props('flat round size=xs color=grey')

                                            # 内容展示
                                            if isinstance(result, (dict, list)):
                                                ui.json_editor({'content': {'json': result}, 'readOnly': True}).classes('w-full h-auto min-h-[100px]')
                                            else:
                                                # Markdown 渲染
                                                ui.markdown(str(result)).classes('w-full prose prose-sm max-w-none')
                                
                                state.add_to_history(request_data, result)
                                load_history_list()
                                
                            except Exception as e:
                                result_container.remove(loading_row)
                                with result_container:
                                    with ui.row().classes('w-full justify-start'):
                                        with ui.card().classes('bg-red-50 text-red-800 p-3 rounded-2xl rounded-tl-sm border border-red-100'):
                                            ui.label(f'Error: {str(e)}').classes('font-bold')
                            
                            finally:
                                # === 优化 2: 清理临时文件 ===
                                for f_obj in current_file_objs:
                                    try:
                                        path = f_obj['path']
                                        if os.path.exists(path):
                                            os.remove(path)
                                    except:
                                        pass
                                
                                # 清理已上传列表 UI
                                uploaded_files.clear()
                                update_file_chips()
                                
                                await asyncio.sleep(0.1)
                                scroll_container.scroll_to(percent=1.0)

                        # 输入框容器
                        # 使用 Flexbox 标准写法：ui.row 默认是 flex-row
                        # 关键点：textarea 需要 w-0 flex-grow 来正确占据剩余空间
                        with ui.row().classes('w-full gap-2 items-end no-wrap relative'):
                            # 1. 上传按钮
                            ui.button(icon='attach_file', on_click=lambda: upload_element.run_method('pickFiles')).props('round flat text-grey-7').classes('upload-btn mb-1 flex-shrink-0')
                            
                            # 2. Prompt 输入框 (w-0 是关键，防止默认宽度撑开导致换行)
                            prompt_input = ui.textarea(placeholder='输入提示词... (Ctrl+Enter 发送)').props('outlined autogrow rows=1 max-rows=8 bg-color=grey-1').classes('w-0 flex-grow text-lg').style('min-height: 56px')
                            
                            # 3. 发送按钮
                            ui.button(icon='send', on_click=send_message).props('round color=primary glossy').classes('mb-1 shadow-md flex-shrink-0')

                        # 隐藏的上传组件 (移出布局流，放在外面)
                        async def handle_upload(e: events.UploadEventArguments):
                            try:
                                # 修复：NiceGUI 2.0+ UploadEventArguments 包含 .file 属性
                                file_obj = e.file
                                file_name = file_obj.name or 'unknown_file'
                                
                                # 读取内容 (异步)
                                content = await file_obj.read()
                                
                                # === 优化: 保存到项目专用临时目录 ===
                                file_ext = os.path.splitext(file_name)[1] if file_name else '.bin'
                                tmp_dir = os.path.expanduser('~/.aibatch/tmp')
                                os.makedirs(tmp_dir, exist_ok=True)
                                
                                import uuid
                                tmp_filename = f"{uuid.uuid4().hex}{file_ext}"
                                tmp_path = os.path.join(tmp_dir, tmp_filename)
                                
                                with open(tmp_path, 'wb') as f:
                                    f.write(content)
                                
                                uploaded_files.append({'path': tmp_path, 'name': file_name})
                                update_file_chips()
                                ui.notify(f'已添加: {file_name}', type='positive')
                            except Exception as ex:
                                ui.notify(f'文件读取失败: {str(ex)}', type='negative')
                            finally:
                                upload_element.run_method('reset')

                        upload_element = ui.upload(on_upload=handle_upload, auto_upload=True).props('hide-upload-btn').classes('hidden')

                        # 绑定回车发送
                        prompt_input.on('keydown.ctrl.enter', send_message)

        # --- 右侧侧边栏 ---
        with ui.column().classes('w-80 h-full bg-white border-l border-gray-200 flex-shrink-0') as right_drawer:
            with ui.tabs().classes('w-full text-grey-8 bg-gray-50') as tabs:
                ui.tab('settings', label='配置', icon='settings')
                ui.tab('history', label='历史', icon='history')
            
            with ui.tab_panels(tabs, value='settings').classes('w-full flex-grow p-4'):
                
                # 配置面板
                with ui.tab_panel('settings').classes('p-0 gap-4'):
                    ui.label('厂商设置').classes('text-xs font-bold text-grey-5 uppercase tracking-wider mb-2')
                    
                    # 厂商选择
                    vendor_select = ui.select(
                        ['kimi', 'qwen', 'gemini', 'openai'],
                        label='Vendor',
                        value=state.current_vendor
                    ).classes('w-full').props('outlined dense')
                    
                    # 动态更新表单
                    def sync_form():
                        api_key_input.value = state.api_key
                        model_input.value = state.model
                        base_url_input.value = state.base_url
                    
                    def on_vendor_change(e):
                        state.switch_vendor(e.value)
                        sync_form()
                    
                    vendor_select.on_value_change(on_vendor_change)
                    
                    api_key_input = ui.input('API Key', password=True, password_toggle_button=True).classes('w-full').props('outlined dense').bind_value(state, 'api_key')
                    model_input = ui.input('Model').classes('w-full').props('outlined dense').bind_value(state, 'model')
                    base_url_input = ui.input('Base URL (Optional)').classes('w-full').props('outlined dense').bind_value(state, 'base_url')
                    
                    ui.separator().classes('my-2')
                    
                    ui.checkbox('JSON Mode').bind_value(state, 'json_mode').classes('text-grey-8')
                    
                    ui.space()
                    ui.label('配置仅在当前会话有效，如需永久生效请在 settings 页保存。').classes('text-xs text-grey-4 text-center mt-4')

                # 历史面板
                with ui.tab_panel('history').classes('p-0'):
                    history_list_container = ui.column().classes('w-full gap-2')
                    
                    def load_history_list():
                        history_list_container.clear()
                        with history_list_container:
                            if not state.history:
                                ui.label('暂无历史').classes('text-center text-grey-4 w-full mt-4')
                            for idx, item in enumerate(state.history):
                                with ui.card().classes('w-full p-3 bg-gray-50 border border-gray-100 cursor-pointer hover:bg-blue-50 transition-colors') as card:
                                    with ui.row().classes('w-full justify-between items-center mb-1'):
                                        ui.label(item['vendor']).classes('text-xs font-bold text-primary uppercase')
                                        import datetime
                                        dt = datetime.datetime.fromtimestamp(item['timestamp'])
                                        ui.label(dt.strftime('%H:%M')).classes('text-xs text-grey-4')
                                    
                                    ui.label(item['prompt']).classes('text-sm text-grey-7 line-clamp-2 leading-tight')
                                    
                                    # 点击恢复
                                    def restore(i=idx):
                                        hist = state.history[i]
                                        prompt_input.value = hist['full_request'].get('prompt', '')
                                        # 切换回 settings 确保 vendor 正确
                                        state.switch_vendor(hist['vendor'])
                                        vendor_select.value = hist['vendor']
                                        sync_form()
                                        ui.notify('已恢复 Prompt 和配置', type='info')
                                    
                                    card.on('click', restore)
                    
                    load_history_list()
