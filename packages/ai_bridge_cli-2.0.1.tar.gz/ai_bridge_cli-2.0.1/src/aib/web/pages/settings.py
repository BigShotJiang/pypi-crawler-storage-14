"""配置管理页面"""
from nicegui import ui
import yaml
import os

def settings_page(state):
    """显示配置管理页面"""
    with ui.header().classes('bg-primary'):
        ui.label('配置管理').classes('text-h5')
        ui.space()
        ui.button('返回主页', on_click=lambda: ui.navigate.to('/')).props('flat')
    
    with ui.column().classes('w-full p-6 gap-6'):
        # 当前配置展示
        ui.label('当前配置').classes('text-h6')
        
        with ui.card().classes('w-full p-4'):
            if state.config and state.config.get('vendors'):
                config_editor = ui.json_editor({
                    'content': {'json': state.config},
                    'mode': 'tree',
                    'mainMenuBar': False
                }).classes('w-full').style('height: 400px')
                
                ui.separator().classes('my-4')
                
                with ui.row().classes('gap-2'):
                    # 保存配置
                    def save_current_config():
                        try:
                            config_path = os.path.expanduser('~/.aibatch/config.yaml')
                            os.makedirs(os.path.dirname(config_path), exist_ok=True)
                            
                            # 获取编辑器中的配置
                            updated_config = config_editor.run_editor_method('get')
                            
                            with open(config_path, 'w', encoding='utf-8') as f:
                                yaml.dump(updated_config, f, allow_unicode=True, default_flow_style=False)
                            
                            ui.notify('配置已保存', type='positive')
                            # 重新加载配置
                            state.load_config(updated_config)
                        except Exception as e:
                            ui.notify(f'保存失败: {str(e)}', type='negative')
                    
                    ui.button('保存配置', on_click=save_current_config, icon='save').props('color=primary')
                    
                    # 导出配置
                    def export_config():
                        try:
                            config_yaml = yaml.dump(state.config, allow_unicode=True, default_flow_style=False)
                            ui.download(config_yaml.encode('utf-8'), 'config.yaml')
                            ui.notify('配置已导出', type='positive')
                        except Exception as e:
                            ui.notify(f'导出失败: {str(e)}', type='negative')
                    
                    ui.button('导出配置', on_click=export_config, icon='download')
                    
                    # 重置配置
                    def reset_config():
                        try:
                            config_path = os.path.expanduser('~/.aibatch/config.yaml')
                            if os.path.exists(config_path):
                                os.remove(config_path)
                                ui.notify('配置已重置，请刷新页面', type='warning')
                            else:
                                ui.notify('没有配置文件可重置', type='info')
                        except Exception as e:
                            ui.notify(f'重置失败: {str(e)}', type='negative')
                    
                    ui.button('重置配置', on_click=reset_config, icon='refresh').props('color=negative')
            else:
                ui.label('暂无配置').classes('text-grey-6')
                ui.button('去配置', on_click=lambda: ui.navigate.to('/')).props('color=primary')
        
        # 厂商信息
        ui.label('已配置厂商').classes('text-h6 mt-4')
        
        with ui.card().classes('w-full p-4'):
            if state.config and state.config.get('vendors'):
                vendors = state.config.get('vendors', {})
                
                for vendor, cfg in vendors.items():
                    with ui.expansion(f'{vendor.upper()}', icon='cloud'):
                        ui.label(f'Model: {cfg.get("model", "未设置")}').classes('mb-2')
                        ui.label(f'API Key: {cfg.get("api_key", "")[:10]}***').classes('mb-2')
                        if cfg.get('base_url'):
                            ui.label(f'Base URL: {cfg.get("base_url")}')
            else:
                ui.label('暂无配置的厂商').classes('text-grey-6')
