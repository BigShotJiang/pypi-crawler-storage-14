"""欢迎页和配置向导"""
from nicegui import ui
import yaml
import os

def welcome_page(state):
    """显示欢迎页面"""
    with ui.card().classes('absolute-center').style('min-width: 600px; padding: 2rem'):
        # 标题
        ui.label('欢迎使用 AI Bridge').classes('text-h4 text-center')
        ui.label('统一的 AI 调用桥梁').classes('text-subtitle1 text-center text-grey-6 mt-2')
        ui.separator().classes('my-6')
        
        ui.label('请选择配置方式').classes('text-h6 mb-4')
        
        # === 选项1: 上传配置文件 ===
        with ui.expansion('📤 上传已有配置文件', icon='upload_file').classes('mb-4'):
            ui.label('如果你已经有 config.yaml 文件，可以直接上传').classes('text-caption mb-2')
            
            upload_handler = lambda e: handle_config_upload(e, state)
            ui.upload(
                on_upload=upload_handler,
                auto_upload=True,
                label='选择 config.yaml'
            ).props('accept=".yaml,.yml"').classes('w-full')
        
        # === 选项2: 手动填写配置 ===
        with ui.expansion('✏️ 手动配置', icon='edit').classes('mb-4'):
            ui.label('填写厂商信息并保存到本地').classes('text-caption mb-2')
            
            with ui.column().classes('w-full gap-4'):
                vendor_input = ui.select(
                    ['kimi', 'qwen', 'gemini', 'openai'],
                    label='选择厂商',
                    value='kimi'
                ).classes('w-full')
                
                api_key_input = ui.input(
                    'API Key',
                    placeholder='sk-...',
                    password=True,
                    password_toggle_button=True
                ).classes('w-full')
                
                model_input = ui.input(
                    'Model',
                    placeholder='例如: kimi-latest'
                ).classes('w-full')
                
                def save_and_start():
                    if not api_key_input.value:
                        ui.notify('请输入 API Key', type='warning')
                        return
                    
                    if not model_input.value:
                        ui.notify('请输入 Model 名称', type='warning')
                        return
                    
                    # 构建配置
                    config = {
                        'default_vendor': vendor_input.value,
                        'concurrency': 5,
                        'system': {'max_retries': 3},
                        'vendors': {
                            vendor_input.value: {
                                'api_key': api_key_input.value,
                                'model': model_input.value
                            }
                        }
                    }
                    
                    # 保存到本地
                    save_result = save_config_to_file(config)
                    if save_result:
                        ui.notify('配置已保存到 ~/.aibatch/config.yaml', type='positive')
                        # 刷新页面
                        ui.navigate.to('/', new_tab=False)
                    else:
                        ui.notify('配置保存失败', type='negative')
                
                ui.button('保存并启动', on_click=save_and_start).classes('w-full')
        
        # === 选项3: 临时使用 ===
        with ui.expansion('🚀 临时使用（不保存）', icon='rocket_launch').classes('mb-4'):
            ui.label('快速开始，配置不会保存').classes('text-caption mb-2')
            
            with ui.column().classes('w-full gap-4'):
                temp_vendor = ui.select(
                    ['kimi', 'qwen', 'gemini', 'openai'],
                    label='选择厂商',
                    value='kimi'
                ).classes('w-full')
                
                temp_api_key = ui.input(
                    'API Key',
                    password=True,
                    password_toggle_button=True
                ).classes('w-full')
                
                temp_model = ui.input('Model').classes('w-full')
                
                def temp_start():
                    if not temp_api_key.value or not temp_model.value:
                        ui.notify('请填写完整信息', type='warning')
                        return
                    
                    # 仅加载到内存
                    config = {
                        'default_vendor': temp_vendor.value,
                        'vendors': {
                            temp_vendor.value: {
                                'api_key': temp_api_key.value,
                                'model': temp_model.value
                            }
                        }
                    }
                    state.load_config(config)
                    ui.notify('临时配置已加载', type='info')
                    ui.navigate.to('/', new_tab=False)
                
                ui.button('临时启动', on_click=temp_start).classes('w-full')

def handle_config_upload(e, state):
    """处理配置文件上传"""
    try:
        # 读取上传的文件内容
        content = e.content.read().decode('utf-8')
        config = yaml.safe_load(content)
        
        # 验证配置格式
        if not config.get('vendors'):
            ui.notify('配置文件格式错误：缺少 vendors 字段', type='negative')
            return
        
        # 保存到本地
        save_result = save_config_to_file(config)
        if save_result:
            ui.notify('配置已上传并保存', type='positive')
            # 刷新页面
            ui.navigate.to('/', new_tab=False)
        else:
            ui.notify('配置保存失败', type='negative')
            
    except yaml.YAMLError:
        ui.notify('YAML 格式错误', type='negative')
    except Exception as ex:
        ui.notify(f'上传失败: {str(ex)}', type='negative')

def save_config_to_file(config):
    """保存配置到 ~/.aibatch/config.yaml"""
    try:
        config_path = os.path.expanduser('~/.aibatch/config.yaml')
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
        
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False
