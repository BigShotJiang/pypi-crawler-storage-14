"""NiceGUI Web UI 主入口"""
from nicegui import ui
from .state import AppState
from .utils import load_web_config
from .pages.welcome import welcome_page
from .pages.main import main_page
from .pages.settings import settings_page

# 全局状态
state = AppState()

def main(config_path=None, port=8080):
    """启动 Web UI"""
    # 定义主页面
    @ui.page('/')
    def index():
        # 移除默认的页面 Padding 和 Gap
        ui.context.client.content.classes('p-0 gap-0')
        
        # 每次访问页面时都重新加载配置（动态检测）
        config = load_web_config(config_path)
        state.load_config(config)
        
        # 根据是否有配置决定显示哪个页面
        if not config.get('vendors'):
            # 无配置 -> 显示欢迎页
            ui.dark_mode().disable()  # 统一使用浅色主题
            welcome_page(state)
        else:
            # 有配置 -> 显示主界面（内部会设置主题）
            main_page(state)
    
    # 定义设置页面
    @ui.page('/settings')
    def settings():
        ui.context.client.content.classes('p-0 gap-0')
        ui.dark_mode().disable()
        
        # 确保配置最新
        config = load_web_config(config_path)
        state.load_config(config)
        
        settings_page(state)
    
    # 启动服务
    ui.run(
        port=port,
        title='AI Bridge',
        reload=False,
        show=True  # 自动打开浏览器
    )

if __name__ in {"__main__", "__mp_main__"}:
    main()
