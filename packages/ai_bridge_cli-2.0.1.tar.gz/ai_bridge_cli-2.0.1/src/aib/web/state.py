"""状态管理模块"""
import os

class AppState:
    """应用全局状态"""
    def __init__(self):
        self.config = {}
        self.current_vendor = 'kimi'
        self.api_key = ''
        self.model = ''
        self.base_url = ''
        self.prompt = ''
        self.json_mode = False
        self.uploaded_files = []
        self.history = []
        
    def load_config(self, config):
        """加载配置并初始化状态"""
        self.config = config
        self.current_vendor = config.get('default_vendor', 'kimi')
        self.update_from_config()
    
    def update_from_config(self):
        """根据当前厂商更新 API Key 等信息"""
        vendor_cfg = self.config.get('vendors', {}).get(self.current_vendor, {})
        self.api_key = vendor_cfg.get('api_key', '')
        self.model = vendor_cfg.get('model', '')
        self.base_url = vendor_cfg.get('base_url', '')
    
    def switch_vendor(self, vendor):
        """切换厂商并自动填充配置"""
        self.current_vendor = vendor
        self.update_from_config()
    
    def add_to_history(self, request_data, result):
        """添加到历史记录"""
        import time
        
        history_item = {
            'timestamp': time.time(),
            'vendor': request_data.get('vendor'),
            'model': request_data.get('model'),
            'prompt': request_data.get('prompt', '')[:100] + '...',  # 截断
            'result_preview': str(result)[:200] if result else 'Error',
            'full_request': request_data,
            'full_result': result
        }
        
        # 保留最近10条
        self.history.insert(0, history_item)
        if len(self.history) > 10:
            self.history = self.history[:10]
    
    def get_history(self):
        """获取历史记录"""
        return self.history
