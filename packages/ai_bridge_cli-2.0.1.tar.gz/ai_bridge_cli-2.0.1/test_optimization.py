import asyncio
import os
import json
import shutil
from src.aib.core.manager import BaseBatchManager

# 模拟一个假的 Batch Manager
class MockBatchManager(BaseBatchManager):
    async def check_status(self, job_id):
        print(f"   [Mock] Checking status for {job_id}...")
        return "completed"

async def test_job_persistence():
    print("🧪 开始测试: Job 状态持久化 (Job Persistence)")
    
    # 1. 准备环境
    jobs_file = os.path.expanduser("~/.aibatch/jobs.json")
    backup_file = jobs_file + ".bak"
    
    # 备份现有的 jobs.json (如果有)
    if os.path.exists(jobs_file):
        print(f"📦 备份现有任务记录到: {backup_file}")
        shutil.copy(jobs_file, backup_file)
    
    try:
        # 2. 模拟创建一个任务
        print("📝 模拟提交一个 Qwen Batch 任务...")
        manager = MockBatchManager(api_key="mock-key")
        fake_job_id = "job_test_12345"
        
        # 写入记录
        manager._save_job_record(fake_job_id, "qwen", "qwen-plus", "running", note="Test Job")
        
        # 验证文件是否存在
        if not os.path.exists(jobs_file):
            print("❌ 测试失败: jobs.json 未创建")
            return
            
        with open(jobs_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        found = any(j["job_id"] == fake_job_id for j in data)
        if found:
            print("✅ 成功: 任务记录已写入本地文件")
        else:
            print("❌ 测试失败: 未在文件中找到任务记录")
            return

        # 3. 测试 check_all_jobs (需要 Mock 掉实际的 API 调用)
        # 这里我们手动模拟 check_all_jobs 的一部分逻辑，因为 check_all_jobs 会重新实例化 Manager
        # 为了演示，我们直接调用 Manager 的更新逻辑
        
        print("🔄 模拟 CLI 检查状态 (aib --check-batch)...")
        new_status = await manager.check_status(fake_job_id)
        manager._save_job_record(fake_job_id, "qwen", "qwen-plus", new_status)
        
        # 再次读取验证状态更新
        with open(jobs_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        record = next((j for j in data if j["job_id"] == fake_job_id), None)
        if record and record["status"] == "completed":
            print(f"✅ 成功: 任务状态已更新为 {record['status']}")
        else:
            print(f"❌ 测试失败: 状态未更新, 当前为 {record.get('status')}")

    finally:
        # 4. 清理环境
        if os.path.exists(jobs_file):
            os.remove(jobs_file)
            print("🧹 清理测试数据")
            
        if os.path.exists(backup_file):
            shutil.move(backup_file, jobs_file)
            print("📦 恢复原有任务记录")

if __name__ == "__main__":
    asyncio.run(test_job_persistence())
