# AIB 优化功能测试指南

本指南将帮助你验证 `ai-batch-processor` 的最新优化：**任务状态持久化 (Job Persistence)** 和 **非阻塞 I/O (Non-blocking I/O)**。

## 1. 环境准备

确保你已经安装了项目依赖。虽然本次优化减少了对 `aiofiles` 的强依赖，但为了完整测试，建议确认环境：

```bash
# 可选：安装 aiofiles 以获得最佳性能 (本次优化的目的是即使没有它也能流畅运行)
pip install aiofiles

# 必须：确保核心依赖存在
pip install openai google-genai pyyaml
```

## 2. 自动化测试脚本

我在根目录创建了一个 `test_optimization.py`，它会模拟“提交任务 -> 保存记录 -> 更新状态”的流程，**不会消耗你的 API 额度**。

**运行方法：**

```bash
python test_optimization.py
```

**预期输出：**
- ✅ 成功: 任务记录已写入本地文件
- ✅ 成功: 任务状态已更新为 completed

## 3. 手动验证 (实战测试)

### 验证点 A: 任务持久化 (Job Persistence)

这个测试需要你真的提交一个 Batch 任务（建议使用 Qwen 或 Gemini，因为它们支持 Batch）。

1.  **提交任务** (使用 Offline 模式):
    ```bash
    # 随便找个文本文件测试，例如 config.yaml
    python -m src.aib.cli -v qwen --mode offline -m qwen-plus -i config.yaml -p "Summarize this"
    ```
    *注意：你需要配置好 API Key。*

2.  **中断程序**:
    当看到 `🚀 Job Created: job_xxxx` 后，直接按 `Ctrl+C` 强行终止程序。

3.  **检查状态**:
    运行新的检查命令：
    ```bash
    python -m src.aib.cli --check-batch
    ```

    **预期结果**:
    程序应该能列出你刚才中断的任务，并显示其当前状态 (如 `validating`, `in_progress` 或 `completed`)。
    ```text
    🔄 Checking 1 active jobs...
       [qwen] job_xxxx -> in_progress
    ```

### 验证点 B: 非阻塞 I/O (Non-blocking I/O)

验证在没有 `aiofiles` 的情况下，程序是否还能正常写日志且不报错。

1.  **临时卸载 aiofiles** (如果你装了的话):
    ```bash
    pip uninstall aiofiles -y
    ```

2.  **运行实时处理**:
    ```bash
    python -m src.aib.cli -v kimi -i config.yaml -p "Hi" --mode realtime
    ```

3.  **观察**:
    程序应该正常运行并输出结果，不会因为缺少 `aiofiles` 而崩溃，也不会因为使用了同步 `open()` 而在日志中出现 Event Loop 阻塞的警告（虽然肉眼难观测微秒级阻塞，但只要不报错即视为 Fallback 逻辑生效）。

---

## 常见问题

*   **找不到任务记录？**
    检查 `~/.aibatch/jobs.json` 文件是否存在。
*   **API Key 报错？**
    确保 `config.yaml` 或环境变量中配置了对应的 Key。
