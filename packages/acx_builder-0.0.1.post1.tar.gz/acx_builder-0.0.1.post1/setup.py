
from setuptools import setup

setup(
    name="acx-builder",
    version="0.0.1.post1",
    description="Alias package for ACX framework.",
    packages=["acx_builder"],
    install_requires=["acx"],
)
