import sys
from typing import NoReturn
import eggp


def main() -> NoReturn:
    sys.exit(eggp.main(sys.argv))


if __name__ == "__main__":
    main()
