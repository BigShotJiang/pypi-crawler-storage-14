"""gRPC bidirectional streaming client for Django communication.

Based on botserver's BotStreamingClient but following CRITICAL_REQUIREMENTS:
- Functions < 20 lines
- Complete type annotations (no Any)
- Custom exception hierarchy
- Pydantic v2 models
"""

import asyncio
import json
import os
import uuid
from datetime import datetime, timezone
from typing import AsyncIterator, Awaitable, Callable, Optional

import grpc
from google.protobuf.json_format import MessageToDict, ParseDict
from google.protobuf.struct_pb2 import Struct
from google.protobuf.timestamp_pb2 import Timestamp

from shared import get_logger

from ..exceptions import GRPCConnectionError, GRPCStreamError
from ..models.config import BotConfig
from ..models.enums import SignalType
from ..models.execution import ExecutionReport
from ..models.trading import TradingSignal
from .connection import ConnectionManager
from .generated import bot_streaming_service_pb2 as pb2
from .generated import bot_streaming_service_pb2_grpc as pb2_grpc

logger = get_logger(__name__)


class GRPCStreamingClient:
    """Bidirectional streaming client for bot-Django communication.

    Usage:
        client = GRPCStreamingClient(
            bot_id="uuid",
            host="grpc.stockapis.com",
            port=443,
            api_key="your-api-key",
        )
        await client.connect_and_run()
    """

    def __init__(
        self,
        bot_id: str,
        host: str = "localhost",
        port: int = 50051,
        api_key: str = "",
        use_tls: bool = False,
        heartbeat_interval: int = 30,
    ) -> None:
        """Initialize streaming client."""
        self._bot_id = bot_id
        self._host = host
        self._port = port
        self._api_key = api_key
        self._use_tls = use_tls
        self._heartbeat_interval = heartbeat_interval

        self._version = os.getenv("BOT_VERSION", "1.0.0")
        self._hostname = os.getenv("HOSTNAME", "botclient")

        self._stream: Optional[grpc.aio.StreamStreamCall[pb2.BotMessage, pb2.DjangoCommand]] = None
        self._running = False
        self._config_received = asyncio.Event()
        self._connected = False

        # Outbound message queue for generator
        self._outbound_queue: asyncio.Queue[pb2.BotMessage] = asyncio.Queue()

        # Store channel and stub for unary RPC calls (ExecutionReport)
        self._channel: Optional[grpc.aio.Channel] = None
        self._stub: Optional[pb2_grpc.BotStreamingServiceStub] = None

        # Config schema to send on registration (set by BotClient)
        self._config_schema: Optional[dict] = None
        self._default_settings: Optional[dict] = None

        # Command handlers
        self.on_start: Optional[Callable[[], None]] = None
        self.on_stop: Optional[Callable[[str], None]] = None
        self.on_pause: Optional[Callable[[str], None]] = None
        self.on_resume: Optional[Callable[[], None]] = None
        # on_config(config, raw_settings) - config is BotConfig, raw_settings is dict
        self.on_config: Optional[Callable[[BotConfig, dict], None]] = None
        self.on_signal: Optional[Callable[[TradingSignal], Awaitable[None]]] = None

        logger.info(f"Initialized GRPCStreamingClient: {host}:{port}")

    def set_config_schema(self, schema: dict, defaults: dict) -> None:
        """Set config schema to send on registration.

        Args:
            schema: JSON Schema from Pydantic model
            defaults: Default settings values
        """
        self._config_schema = schema
        self._default_settings = defaults
        logger.info(f"Config schema set: {len(schema.get('properties', {}))} properties")

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected and self._running

    @property
    def address(self) -> str:
        """Get server address."""
        return f"{self._host}:{self._port}"

    async def connect(self) -> bool:
        """Connect to server (alias for connect_and_run)."""
        try:
            await self.connect_and_run(max_retries=1)
            return True
        except GRPCConnectionError:
            return False

    async def disconnect(self) -> None:
        """Disconnect from server."""
        self._running = False
        self._connected = False
        self._stream = None
        logger.info("Disconnected from gRPC server")

    async def connect_and_run(
        self,
        max_retries: Optional[int] = None,
        initial_backoff: float = 1.0,
        max_backoff: float = 60.0,
    ) -> None:
        """Connect and run with auto-reconnect."""
        retry_count = 0
        backoff = initial_backoff

        while max_retries is None or retry_count < max_retries:
            try:
                if retry_count > 0:
                    await self._log_and_wait_retry(retry_count, backoff)

                await self._connect_once()
                break

            except GRPCConnectionError as e:
                retry_count, backoff = self._handle_connection_error(
                    e, retry_count, backoff, max_backoff, max_retries
                )
            except asyncio.CancelledError:
                logger.info("Connection cancelled")
                raise

    async def _log_and_wait_retry(self, retry_count: int, backoff: float) -> None:
        """Log retry attempt and wait."""
        logger.info(f"Reconnect attempt {retry_count} after {backoff:.1f}s...")
        await asyncio.sleep(backoff)

    def _handle_connection_error(
        self,
        error: GRPCConnectionError,
        retry_count: int,
        backoff: float,
        max_backoff: float,
        max_retries: Optional[int],
    ) -> tuple[int, float]:
        """Handle connection error and update retry state."""
        retry_count += 1
        logger.warning(f"Connection failed (attempt {retry_count}): {error}")

        if max_retries is not None and retry_count >= max_retries:
            raise error

        self._reset_connection_state()
        return retry_count, min(backoff * 2, max_backoff)

    def _reset_connection_state(self) -> None:
        """Reset connection state."""
        self._running = False
        self._connected = False
        self._stream = None
        self._config_received.clear()

    async def _connect_once(self) -> None:
        """Single connection attempt."""
        logger.info(f"Connecting to {self.address}...")
        self._channel = self._create_channel()

        async with self._channel:
            self._stub = pb2_grpc.BotStreamingServiceStub(self._channel)
            metadata = [("x-api-key", self._api_key)]

            # Clear outbound queue before connecting
            while not self._outbound_queue.empty():
                try:
                    self._outbound_queue.get_nowait()
                except asyncio.QueueEmpty:
                    break

            self._running = True
            self._connected = True

            # Create bidirectional stream WITH generator
            # Server expects AsyncIterator, so we pass our generator
            logger.info("Creating bidirectional stream with ConnectBot...")
            self._stream = self._stub.ConnectBot(
                self._request_generator(),
                metadata=metadata,
            )
            logger.info(f"Stream created: {type(self._stream)}")
            logger.info("Connected to Django gRPC server")

            # Run receive and heartbeat tasks concurrently
            logger.info("Starting receive and heartbeat tasks...")
            try:
                await asyncio.gather(
                    self._receive_commands(),
                    self._send_heartbeats(),
                )
            except asyncio.CancelledError:
                logger.info("Tasks cancelled")
                raise
            except GRPCConnectionError:
                raise
            finally:
                self._running = False
                self._stub = None

    async def _request_generator(self) -> AsyncIterator[pb2.BotMessage]:
        """Generate outbound messages for gRPC stream.

        CRITICAL: This generator must be FINITE (exit after yields).
        gRPC Python buffers/delays messages from generators that don't exit.
        See: test_finite_generator.py (PASSES) vs test_short_timeout_generator.py (FAILS)
        """
        # 1. Send registration message
        reg_msg = self._create_bot_message()
        reg_msg.register.CopyFrom(
            pb2.RegisterRequest(
                version=self._version,
                hostname=self._hostname,
                grpc_port=0,
                supported_exchanges=["binance"],
                supported_strategies=["default"],
                metadata={},
            )
        )
        logger.info("Yielding registration message...")
        yield reg_msg

        # 2. Send config schema (if set)
        if self._config_schema is not None:
            schema_msg = self._create_config_schema_message()
            if schema_msg:
                logger.info("Yielding config schema message...")
                yield schema_msg

        # Generator exits here - CRITICAL for gRPC to send messages immediately
        logger.info("Generator exited (finite)")

    def _enqueue_message(self, msg: pb2.BotMessage) -> bool:
        """Enqueue message for sending via generator."""
        if not self._running:
            return False
        try:
            self._outbound_queue.put_nowait(msg)
            return True
        except asyncio.QueueFull:
            logger.warning("Outbound queue full, dropping message")
            return False

    def _create_channel(self) -> grpc.aio.Channel:
        """Create gRPC channel."""
        options = self._get_channel_options()

        if self._use_tls:
            credentials = grpc.ssl_channel_credentials()
            return grpc.aio.secure_channel(self.address, credentials, options=options)
        return grpc.aio.insecure_channel(self.address, options=options)

    def _get_channel_options(self) -> list[tuple[str, int]]:
        """Get gRPC channel options."""
        return [
            ("grpc.dns_min_time_between_resolutions_ms", 10000),
            ("grpc.keepalive_time_ms", 30000),
            ("grpc.keepalive_timeout_ms", 10000),
            ("grpc.keepalive_permit_without_calls", 1),
        ]

    async def _send_heartbeats(self) -> None:
        """Send periodic heartbeats.

        NOTE: With finite generator, we cannot send heartbeats via gRPC stream.
        Server uses ping/pong mechanism for keepalive instead.
        This method now just logs heartbeat status locally.
        """
        await self._config_received.wait()

        while self._running:
            await asyncio.sleep(self._heartbeat_interval)
            if not self._running:
                break
            # Log heartbeat locally (server uses ping mechanism)
            logger.debug("Heartbeat (local, finite generator cannot send via stream)")

    async def _send_single_heartbeat(self) -> None:
        """Log heartbeat (cannot send with finite generator).

        NOTE: Server should use ping_strategy=INTERVAL to maintain connection.
        """
        logger.debug("Heartbeat check (server maintains via ping)")

    async def _receive_commands(self) -> None:
        """Receive and handle commands."""
        if self._stream is None:
            logger.error("_receive_commands: stream is None!")
            return

        logger.info("Starting to receive commands from server...")

        try:
            async for command in self._stream:
                if command == grpc.aio.EOF:
                    raise GRPCStreamError(
                        message="Stream closed by server",
                        code="STREAM_CLOSED",
                    )
                await self._handle_command(command)
        except grpc.aio.AioRpcError as e:
            logger.error(f"gRPC AioRpcError in _receive_commands: {e.code()}: {e.details()}")
            raise GRPCConnectionError(
                message=f"gRPC error: {e.details()}",
                code="GRPC_ERROR",
            ) from e
        except asyncio.CancelledError:
            logger.info("_receive_commands cancelled")
            raise
        except Exception as e:
            logger.exception(f"Unexpected error in _receive_commands: {e}")
            raise

    async def _handle_command(self, command: pb2.DjangoCommand) -> None:
        """Handle incoming command."""
        command_type = command.WhichOneof("payload")
        if command_type is None:
            return

        logger.info(f"Received {command_type.upper()} command")

        handlers = {
            "config_update": self._handle_config_update,
            "start": self._handle_start,
            "stop": self._handle_stop,
            "pause": self._handle_pause,
            "resume": self._handle_resume,
            "ping": self._handle_ping,
        }

        handler = handlers.get(command_type)
        if handler:
            await handler(command)

    async def _handle_config_update(self, command: pb2.DjangoCommand) -> None:
        """Handle config update command."""
        self._config_received.set()
        proto_config = command.config_update.config
        config, raw_settings = self._parse_config(proto_config)

        if self.on_config:
            self.on_config(config, raw_settings)
            logger.info("Config updated")

        await self._send_command_ack(command.command_id, True, "Config updated")

    def _parse_config(self, proto_config: pb2.BotConfig) -> tuple[BotConfig, dict]:
        """Parse protobuf config to Pydantic model and raw settings dict.

        Returns:
            Tuple of (BotConfig, raw_settings_dict)
        """
        # Extract raw settings as dict (for bot's Pydantic model)
        raw_settings = MessageToDict(proto_config.settings) if proto_config.HasField("settings") else {}

        # Create minimal BotConfig (metadata only)
        config = BotConfig(
            bot_id=proto_config.id,
            name=proto_config.name,
            enabled=proto_config.enabled,
            active=proto_config.active,
            description=proto_config.description,
        )

        return config, raw_settings

    async def _handle_start(self, command: pb2.DjangoCommand) -> None:
        """Handle start command."""
        success = False
        if self.on_start:
            self.on_start()
            success = True
        await self._send_command_ack(command.command_id, success, "Bot started")

    async def _handle_stop(self, command: pb2.DjangoCommand) -> None:
        """Handle stop command."""
        success = False
        reason = command.stop.reason if command.stop.reason else "No reason"
        if self.on_stop:
            self.on_stop(reason)
            success = True
        await self._send_command_ack(command.command_id, success, "Bot stopped")

    async def _handle_pause(self, command: pb2.DjangoCommand) -> None:
        """Handle pause command."""
        success = False
        reason = command.pause.reason if command.pause.reason else "No reason"
        if self.on_pause:
            self.on_pause(reason)
            success = True
        await self._send_command_ack(command.command_id, success, "Bot paused")

    async def _handle_resume(self, command: pb2.DjangoCommand) -> None:
        """Handle resume command."""
        success = False
        if self.on_resume:
            self.on_resume()
            success = True
        await self._send_command_ack(command.command_id, success, "Bot resumed")

    async def _handle_ping(self, command: pb2.DjangoCommand) -> None:
        """Handle ping command."""
        await self._send_single_heartbeat()

    async def _send_command_ack(
        self,
        command_id: str,
        success: bool,
        message: str,
    ) -> None:
        """Log command acknowledgment (finite generator cannot send).

        NOTE: With finite generator, we cannot send CommandAck via gRPC stream.
        Server should handle commands without requiring explicit ACK.
        """
        logger.info(f"CommandAck (local): {command_id} success={success} message={message}")

    async def send_execution_report(self, report: ExecutionReport) -> bool:
        """Send execution report via unary RPC (ReportExecution).

        Uses separate unary RPC call instead of bidirectional stream,
        which works around gRPC Python generator limitations.
        """
        if not self._running or self._stub is None:
            logger.warning("Cannot send report - not connected")
            return False

        try:
            proto_report = self._create_proto_execution(report)
            metadata = [("x-api-key", self._api_key)]

            ack = await self._stub.ReportExecution(proto_report, metadata=metadata)

            if ack.acknowledged:
                logger.info(f"ExecutionReport sent: {report.execution_id}")
                return True
            else:
                logger.warning(f"ExecutionReport rejected: {ack.message}")
                return False

        except grpc.aio.AioRpcError as e:
            logger.error(f"Failed to send ExecutionReport: {e.code()} - {e.details()}")
            return False

    def _create_proto_execution(self, report: ExecutionReport) -> pb2.ExecutionReport:
        """Create protobuf execution report."""
        return pb2.ExecutionReport(
            execution_id=report.execution_id,
            bot_id=self._bot_id,
            symbol=report.symbol,
            side=report.side.value,
            order_type=report.order_type,
            quantity=report.quantity,
            price=report.price,
            filled_quantity=report.filled_quantity,
            average_price=report.average_price,
            fee=report.fee,
            fee_currency=report.fee_currency,
            status=report.status,
            exchange=report.exchange,
            exchange_order_id=report.exchange_order_id or "",
        )

    def _create_bot_message(self) -> pb2.BotMessage:
        """Create base bot message."""
        return pb2.BotMessage(
            bot_id=self._bot_id,
            message_id=str(uuid.uuid4()),
            timestamp=self._current_timestamp(),
        )

    def _create_config_schema_message(self) -> Optional[pb2.BotMessage]:
        """Create config schema message to send to Django."""
        if self._config_schema is None:
            return None

        msg = self._create_bot_message()

        # Convert defaults dict to protobuf Struct
        # Must sanitize values - protobuf Struct doesn't support Decimal, etc.
        current_values = Struct()
        if self._default_settings:
            sanitized = self._sanitize_for_protobuf(self._default_settings)
            current_values.update(sanitized)

        msg.config_schema.CopyFrom(
            pb2.ConfigSchemaReport(
                schema_json=json.dumps(self._config_schema),
                current_values=current_values,
                pydantic_version="2",
                bot_version=self._version,
            )
        )
        return msg

    def _sanitize_for_protobuf(self, data: dict) -> dict:
        """Sanitize dict values for protobuf Struct.

        Converts Decimal to float, and other non-JSON types to strings.
        Protobuf Struct only supports: null, bool, number, string, list, dict.
        """
        from decimal import Decimal

        result: dict = {}
        for key, value in data.items():
            if isinstance(value, Decimal):
                result[key] = float(value)
            elif isinstance(value, dict):
                result[key] = self._sanitize_for_protobuf(value)
            elif isinstance(value, list):
                result[key] = [
                    float(v) if isinstance(v, Decimal) else v for v in value
                ]
            else:
                result[key] = value
        return result

    def _current_timestamp(self) -> Timestamp:
        """Get current UTC timestamp."""
        ts = Timestamp()
        ts.FromDatetime(datetime.now(timezone.utc))
        return ts

    async def send_heartbeat(self) -> None:
        """Public method to send heartbeat."""
        await self._send_single_heartbeat()

    async def send_registration(self) -> bool:
        """Public method to send registration via stream."""
        if not self._running or self._stream is None:
            return False
        await self._send_registration()
        return True

    async def receive_commands(self) -> AsyncIterator[tuple[BotConfig, dict]]:
        """Receive config commands from server.

        Yields:
            Tuple of (BotConfig, raw_settings_dict)
        """
        if self._stream is None:
            return

        async for command in self._stream:
            if command.HasField("config_update"):
                config, raw_settings = self._parse_config(command.config_update.config)
                yield config, raw_settings
