"""Binance exchange adapter.

Supports:
- Spot trading (testnet: testnet.binance.vision)
- Futures/USDM trading (testnet: testnet.binancefuture.com)
"""

import hashlib
import hmac
import time
from decimal import Decimal
from typing import Optional
from urllib.parse import urlencode

import aiohttp

from shared import get_logger

from ..exceptions import (
    ExchangeAuthenticationError,
    ExchangeConnectionError,
    OrderExecutionError,
)
from ..models.execution import OrderResult
from ..models.trading import AccountBalance, TickerInfo
from .base import BaseExchange

logger = get_logger(__name__)


class BinanceExchange(BaseExchange):
    """Binance exchange adapter with testnet support.

    Testnet URLs:
    - Spot: https://testnet.binance.vision
    - Futures: https://testnet.binancefuture.com

    Live URLs:
    - Spot: https://api.binance.com
    - Futures: https://fapi.binance.com
    """

    URLS: dict[str, dict[str, str]] = {
        "spot": {
            "live": "https://api.binance.com",
            "testnet": "https://testnet.binance.vision",
        },
        "swap": {
            "live": "https://fapi.binance.com",
            "testnet": "https://testnet.binancefuture.com",
        },
    }

    ENDPOINTS: dict[str, dict[str, str]] = {
        "spot": {
            "account": "/api/v3/account",
            "order": "/api/v3/order",
            "ticker": "/api/v3/ticker/price",
            "exchange_info": "/api/v3/exchangeInfo",
        },
        "swap": {
            "account": "/fapi/v2/account",
            "order": "/fapi/v1/order",
            "ticker": "/fapi/v1/ticker/price",
            "exchange_info": "/fapi/v1/exchangeInfo",
            "leverage": "/fapi/v1/leverage",
        },
    }

    @property
    def name(self) -> str:
        """Exchange name."""
        return "binance"

    @property
    def base_url(self) -> str:
        """Get base URL based on testnet and market type."""
        mode = "testnet" if self.testnet else "live"
        market = "swap" if self.market_type in ("swap", "futures", "perpetual") else "spot"
        return self.URLS[market][mode]

    @property
    def _endpoints(self) -> dict[str, str]:
        """Get endpoints for current market type."""
        market = "swap" if self.market_type in ("swap", "futures", "perpetual") else "spot"
        return self.ENDPOINTS[market]

    def _generate_signature(self, params: str) -> str:
        """Generate HMAC SHA256 signature."""
        return hmac.new(
            self.api_secret.encode("utf-8"),
            params.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[dict[str, str]] = None,
        signed: bool = False,
    ) -> dict[str, str]:
        """Make HTTP request to Binance API."""
        if params is None:
            params = {}

        if signed:
            params["timestamp"] = str(int(time.time() * 1000))

        query_string = urlencode(sorted(params.items()))

        if signed:
            signature = self._generate_signature(query_string)
            query_string += f"&signature={signature}"

        url = f"{self.base_url}{endpoint}"
        headers = {
            "X-MBX-APIKEY": self.api_key,
            "Content-Type": "application/json",
        }

        async with aiohttp.ClientSession() as session:
            response = await self._execute_request(
                session, method, url, query_string, headers
            )
            return response

    async def _execute_request(
        self,
        session: aiohttp.ClientSession,
        method: str,
        url: str,
        query_string: str,
        headers: dict[str, str],
    ) -> dict[str, str]:
        """Execute HTTP request and handle response."""
        if method == "GET":
            return await self._get_request(session, url, query_string, headers)
        elif method == "POST":
            return await self._post_request(session, url, query_string, headers)
        elif method == "DELETE":
            return await self._delete_request(session, url, query_string, headers)
        raise ValueError(f"Unsupported method: {method}")

    async def _get_request(
        self,
        session: aiohttp.ClientSession,
        url: str,
        query_string: str,
        headers: dict[str, str],
    ) -> dict[str, str]:
        """Execute GET request."""
        if query_string:
            url += f"?{query_string}"
        async with session.get(url, headers=headers) as response:
            return await self._handle_response(response)

    async def _post_request(
        self,
        session: aiohttp.ClientSession,
        url: str,
        query_string: str,
        headers: dict[str, str],
    ) -> dict[str, str]:
        """Execute POST request."""
        headers = {**headers, "Content-Type": "application/x-www-form-urlencoded"}
        async with session.post(url, data=query_string, headers=headers) as response:
            return await self._handle_response(response)

    async def _delete_request(
        self,
        session: aiohttp.ClientSession,
        url: str,
        query_string: str,
        headers: dict[str, str],
    ) -> dict[str, str]:
        """Execute DELETE request."""
        if query_string:
            url += f"?{query_string}"
        async with session.delete(url, headers=headers) as response:
            return await self._handle_response(response)

    async def _handle_response(
        self, response: aiohttp.ClientResponse
    ) -> dict[str, str]:
        """Handle API response."""
        data = await response.json()
        if response.status >= 400:
            error_msg = data.get("msg", str(data))
            error_code = str(data.get("code", response.status))
            self._raise_exchange_error(response.status, error_msg, error_code)
        return data

    def _raise_exchange_error(
        self, status: int, message: str, code: str
    ) -> None:
        """Raise appropriate exchange error."""
        if status == 401 or code in ("-2015", "-1022"):
            raise ExchangeAuthenticationError(
                message=f"Authentication failed: {message}",
                exchange=self.name,
            )
        raise ExchangeConnectionError(
            message=f"Binance API error {status}: {message}",
            exchange=self.name,
        )

    async def connect(self) -> bool:
        """Test connection by getting account info."""
        try:
            result = await self._request(
                "GET", self._endpoints["account"], signed=True
            )
            self._connected = self._validate_connection(result)
            if self._connected:
                mode = "TESTNET" if self.testnet else "LIVE"
                logger.info(f"Binance {mode} connected ({self.market_type})")
            return self._connected
        except ExchangeAuthenticationError:
            raise
        except Exception as e:
            logger.error(f"Binance connection failed: {e}")
            self._connected = False
            raise ExchangeConnectionError(
                message=str(e), exchange=self.name
            ) from e

    def _validate_connection(self, result: dict[str, str]) -> bool:
        """Validate connection response."""
        if self.market_type == "spot":
            return "balances" in result
        return "totalWalletBalance" in result

    async def get_ticker(self, symbol: str) -> TickerInfo:
        """Get current ticker info."""
        result = await self._request(
            "GET", self._endpoints["ticker"], {"symbol": symbol}
        )
        return TickerInfo(
            symbol=symbol,
            price=Decimal(str(result["price"])),
        )

    async def place_market_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        reduce_only: bool = False,
    ) -> OrderResult:
        """Place market order."""
        params = self._build_order_params(symbol, side, quantity, reduce_only)

        try:
            result = await self._request(
                "POST", self._endpoints["order"], params, signed=True
            )
            return self._parse_order_result(result, symbol, side, quantity)
        except ExchangeConnectionError as e:
            return self._create_failed_order(symbol, side, quantity, str(e))

    def _build_order_params(
        self,
        symbol: str,
        side: str,
        quantity: str,
        reduce_only: bool,
    ) -> dict[str, str]:
        """Build order parameters."""
        params: dict[str, str] = {
            "symbol": symbol,
            "side": side.upper(),
            "type": "MARKET",
            "quantity": quantity,
        }
        if self.market_type != "spot" and reduce_only:
            params["reduceOnly"] = "true"
        return params

    async def _parse_order_result(
        self,
        result: dict[str, str],
        symbol: str,
        side: str,
        quantity: str,
    ) -> OrderResult:
        """Parse order response into OrderResult."""
        avg_price = await self._calculate_avg_price(result, symbol)

        return OrderResult(
            success=True,
            order_id=str(result.get("orderId")),
            symbol=symbol,
            side=side.upper(),  # type: ignore
            order_type="MARKET",  # type: ignore
            quantity=quantity,
            filled_quantity=str(result.get("executedQty", "0")),
            average_price=avg_price,
            status=str(result.get("status", "FILLED")),
            raw_response={str(k): str(v) for k, v in result.items()},
        )

    async def _calculate_avg_price(
        self, result: dict[str, str], symbol: str
    ) -> str:
        """Calculate average price from order result."""
        avg_price = result.get("avgPrice") or result.get("price")
        cum_quote = result.get("cumQuote") or result.get("cummulativeQuoteQty")
        executed_qty = result.get("executedQty")

        if cum_quote and executed_qty:
            avg_price = self._compute_avg_from_quote(cum_quote, executed_qty, avg_price)

        if avg_price in ("0.00", "0", "0.0", None, ""):
            avg_price = await self._get_fallback_price(symbol)

        return str(avg_price) if avg_price else "0"

    def _compute_avg_from_quote(
        self,
        cum_quote: str,
        executed_qty: str,
        fallback: Optional[str],
    ) -> Optional[str]:
        """Compute average price from cumulative quote."""
        try:
            cum_quote_f = float(cum_quote)
            executed_qty_f = float(executed_qty)
            if executed_qty_f > 0:
                return str(cum_quote_f / executed_qty_f)
        except (ValueError, ZeroDivisionError):
            pass
        return fallback

    async def _get_fallback_price(self, symbol: str) -> Optional[str]:
        """Get fallback price from ticker."""
        try:
            ticker = await self.get_ticker(symbol)
            return str(ticker.price)
        except Exception as e:
            logger.warning(f"Could not get ticker price: {e}")
            return None

    def _create_failed_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        error: str,
    ) -> OrderResult:
        """Create failed order result."""
        return OrderResult(
            success=False,
            symbol=symbol,
            side=side.upper(),  # type: ignore
            order_type="MARKET",  # type: ignore
            quantity=quantity,
            error=error,
        )

    async def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        price: str,
        time_in_force: str = "GTC",
    ) -> OrderResult:
        """Place limit order."""
        params: dict[str, str] = {
            "symbol": symbol,
            "side": side.upper(),
            "type": "LIMIT",
            "quantity": quantity,
            "price": price,
            "timeInForce": time_in_force,
        }

        try:
            result = await self._request(
                "POST", self._endpoints["order"], params, signed=True
            )
            return OrderResult(
                success=True,
                order_id=str(result.get("orderId")),
                symbol=symbol,
                side=side.upper(),  # type: ignore
                order_type="LIMIT",  # type: ignore
                quantity=quantity,
                price=price,
                status=str(result.get("status", "NEW")),
                raw_response={str(k): str(v) for k, v in result.items()},
            )
        except ExchangeConnectionError as e:
            return OrderResult(
                success=False,
                symbol=symbol,
                side=side.upper(),  # type: ignore
                order_type="LIMIT",  # type: ignore
                quantity=quantity,
                price=price,
                error=str(e),
            )

    async def cancel_order(self, symbol: str, order_id: str) -> bool:
        """Cancel an order."""
        try:
            params: dict[str, str] = {"symbol": symbol, "orderId": order_id}
            result = await self._request(
                "DELETE", self._endpoints["order"], params, signed=True
            )
            return "orderId" in result
        except Exception as e:
            logger.error(f"Cancel order failed: {e}")
            return False

    async def get_account_balance(self) -> AccountBalance:
        """Get account balance."""
        result = await self._request(
            "GET", self._endpoints["account"], signed=True
        )

        if self.market_type == "spot":
            return self._parse_spot_balance(result)
        return self._parse_futures_balance(result)

    def _parse_spot_balance(self, result: dict[str, str]) -> AccountBalance:
        """Parse spot account balance."""
        balances = result.get("balances", [])
        usdt_balance = next(
            (b for b in balances if b["asset"] == "USDT"),
            {"free": "0", "locked": "0"},
        )
        total = Decimal(str(usdt_balance["free"])) + Decimal(str(usdt_balance["locked"]))
        available = Decimal(str(usdt_balance["free"]))
        return AccountBalance(
            total_balance=total,
            available_balance=available,
            currency="USDT",
        )

    def _parse_futures_balance(self, result: dict[str, str]) -> AccountBalance:
        """Parse futures account balance."""
        total = Decimal(str(result.get("totalWalletBalance", "0")))
        available = Decimal(str(result.get("availableBalance", "0")))
        unrealized = Decimal(str(result.get("totalUnrealizedProfit", "0")))
        return AccountBalance(
            total_balance=total,
            available_balance=available,
            unrealized_pnl=unrealized,
            currency="USDT",
        )

    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for futures."""
        if self.market_type == "spot":
            logger.warning("Leverage not applicable for spot trading")
            return True

        try:
            params: dict[str, str] = {
                "symbol": symbol,
                "leverage": str(leverage),
            }
            await self._request(
                "POST", self._endpoints["leverage"], params, signed=True
            )
            logger.info(f"Leverage set to {leverage}x for {symbol}")
            return True
        except Exception as e:
            logger.error(f"Set leverage failed: {e}")
            return False

    async def get_exchange_info(
        self, symbol: Optional[str] = None
    ) -> dict[str, str]:
        """Get exchange info including lot sizes."""
        params: dict[str, str] = {}
        if symbol:
            params["symbol"] = symbol
        return await self._request("GET", self._endpoints["exchange_info"], params)

    async def calculate_quantity(
        self,
        symbol: str,
        usdt_amount: float,
        leverage: int = 1,
    ) -> str:
        """Calculate quantity with proper precision from exchange info."""
        lot_info = await self._get_lot_info(symbol)
        min_qty = lot_info["min_qty"]
        step_size = lot_info["step_size"]

        ticker = await self.get_ticker(symbol)
        price = float(ticker.price)

        quantity = self._compute_quantity(usdt_amount, price, leverage, min_qty, step_size)
        return self._format_quantity(quantity)

    async def _get_lot_info(self, symbol: str) -> dict[str, float]:
        """Get lot size info for symbol."""
        try:
            exchange_info = await self.get_exchange_info(symbol)
            symbol_info = next(
                (s for s in exchange_info.get("symbols", []) if s["symbol"] == symbol),
                None,
            )
            if symbol_info:
                return self._extract_lot_filter(symbol_info)
        except Exception as e:
            logger.warning(f"Could not get exchange info: {e}, using defaults")
        return {"min_qty": 0.001, "step_size": 0.001}

    def _extract_lot_filter(self, symbol_info: dict[str, str]) -> dict[str, float]:
        """Extract lot filter from symbol info."""
        lot_filter = next(
            (f for f in symbol_info.get("filters", []) if f["filterType"] == "LOT_SIZE"),
            None,
        )
        if lot_filter:
            return {
                "min_qty": float(lot_filter.get("minQty", 0.001)),
                "step_size": float(lot_filter.get("stepSize", 0.001)),
            }
        return {"min_qty": 0.001, "step_size": 0.001}

    def _compute_quantity(
        self,
        usdt_amount: float,
        price: float,
        leverage: int,
        min_qty: float,
        step_size: float,
    ) -> float:
        """Compute order quantity."""
        if self.market_type == "spot":
            quantity = usdt_amount / price
        else:
            quantity = (usdt_amount * leverage) / price
        quantity = max(quantity, min_qty)
        quantity = round(quantity / step_size) * step_size
        return quantity

    def _format_quantity(self, quantity: float) -> str:
        """Format quantity without trailing zeros."""
        return f"{quantity:.8f}".rstrip("0").rstrip(".")
