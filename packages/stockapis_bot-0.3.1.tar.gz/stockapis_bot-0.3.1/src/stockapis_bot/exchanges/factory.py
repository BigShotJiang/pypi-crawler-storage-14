"""Exchange factory for creating exchange adapters."""

from ..exceptions import ConfigValidationError
from .base import BaseExchange
from .binance import BinanceExchange


class ExchangeFactory:
    """Factory for creating exchange adapters.

    Usage:
        exchange = ExchangeFactory.create(
            exchange_name="binance",
            api_key="...",
            api_secret="...",
            testnet=True,
            market_type="swap"
        )
    """

    _exchanges: dict[str, type[BaseExchange]] = {
        "binance": BinanceExchange,
    }

    @classmethod
    def create(
        cls,
        exchange_name: str,
        api_key: str,
        api_secret: str,
        testnet: bool = True,
        market_type: str = "swap",
    ) -> BaseExchange:
        """Create exchange adapter instance.

        Args:
            exchange_name: Name of exchange (binance, bybit)
            api_key: API key
            api_secret: API secret
            testnet: Use testnet environment
            market_type: Market type (spot, swap, futures)

        Returns:
            Configured exchange adapter.

        Raises:
            ConfigValidationError: If exchange not supported.
        """
        normalized_name = exchange_name.lower().strip()

        if normalized_name not in cls._exchanges:
            raise ConfigValidationError(
                message=f"Unsupported exchange: {exchange_name}",
                field="exchange_name",
            )

        exchange_class = cls._exchanges[normalized_name]
        return exchange_class(
            api_key=api_key,
            api_secret=api_secret,
            testnet=testnet,
            market_type=market_type,
        )

    @classmethod
    def register(cls, name: str, exchange_class: type[BaseExchange]) -> None:
        """Register a new exchange adapter.

        Args:
            name: Exchange name
            exchange_class: Exchange adapter class
        """
        cls._exchanges[name.lower()] = exchange_class

    @classmethod
    def available_exchanges(cls) -> list[str]:
        """Get list of available exchanges.

        Returns:
            List of exchange names.
        """
        return list(cls._exchanges.keys())
