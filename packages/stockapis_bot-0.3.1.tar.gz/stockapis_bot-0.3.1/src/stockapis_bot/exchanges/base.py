"""Base exchange adapter - abstract base class."""

from abc import ABC, abstractmethod
from typing import Optional

from ..models.execution import OrderResult
from ..models.trading import AccountBalance, TickerInfo


class BaseExchange(ABC):
    """Abstract base class for exchange adapters.

    Subclasses must implement all abstract methods.
    Uses ABC for explicit inheritance contract.
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        testnet: bool = True,
        market_type: str = "swap",
    ) -> None:
        """Initialize exchange adapter.

        Args:
            api_key: Exchange API key
            api_secret: Exchange API secret
            testnet: Use testnet environment
            market_type: Market type (spot, swap, futures)
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.market_type = market_type
        self._connected = False

    @property
    @abstractmethod
    def name(self) -> str:
        """Exchange name."""
        ...

    @property
    @abstractmethod
    def base_url(self) -> str:
        """Base API URL."""
        ...

    @property
    def is_connected(self) -> bool:
        """Check if connected to exchange."""
        return self._connected

    @abstractmethod
    async def connect(self) -> bool:
        """Connect to exchange API.

        Returns:
            True if connection successful.
        """
        ...

    async def disconnect(self) -> None:
        """Disconnect from exchange API."""
        self._connected = False

    @abstractmethod
    async def get_ticker(self, symbol: str) -> TickerInfo:
        """Get current ticker info.

        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')

        Returns:
            Current ticker info.
        """
        ...

    @abstractmethod
    async def place_market_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        reduce_only: bool = False,
    ) -> OrderResult:
        """Place market order.

        Args:
            symbol: Trading pair
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            reduce_only: If True, only reduce position

        Returns:
            Order result.
        """
        ...

    @abstractmethod
    async def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        price: str,
        time_in_force: str = "GTC",
    ) -> OrderResult:
        """Place limit order.

        Args:
            symbol: Trading pair
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            price: Limit price
            time_in_force: Time in force

        Returns:
            Order result.
        """
        ...

    @abstractmethod
    async def cancel_order(self, symbol: str, order_id: str) -> bool:
        """Cancel an order.

        Args:
            symbol: Trading pair
            order_id: Order ID to cancel

        Returns:
            True if cancellation successful.
        """
        ...

    @abstractmethod
    async def get_account_balance(self) -> AccountBalance:
        """Get account balance.

        Returns:
            Current account balance.
        """
        ...

    @abstractmethod
    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for futures trading.

        Args:
            symbol: Trading pair
            leverage: Leverage value

        Returns:
            True if successful.
        """
        ...

    @abstractmethod
    async def calculate_quantity(
        self,
        symbol: str,
        usdt_amount: float,
        leverage: int = 1,
    ) -> str:
        """Calculate order quantity from USDT amount.

        Args:
            symbol: Trading pair
            usdt_amount: Amount in USDT
            leverage: Leverage to apply

        Returns:
            Formatted quantity string.
        """
        ...

    async def get_exchange_info(self, symbol: Optional[str] = None) -> dict[str, str]:
        """Get exchange info including lot sizes.

        Args:
            symbol: Optional symbol to filter

        Returns:
            Exchange info dict.
        """
        return {}
