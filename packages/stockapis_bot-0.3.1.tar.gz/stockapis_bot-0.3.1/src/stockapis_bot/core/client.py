"""Main BotClient class - orchestrates all components."""

import asyncio
from typing import Optional

from shared import get_logger

from ..exceptions import BotClientError, BotNotRunningError
from ..exchanges.factory import ExchangeFactory
from ..grpc.client import GRPCStreamingClient
from ..models.config import BotConfig, ClientConfig
from ..signals.listener import RedisSignalListener
from ..models.enums import BotState, SignalAction
from ..models.execution import ExecutionReport, OrderResult, SignalDecision
from ..models.trading import AccountBalance, TickerInfo, TradingSignal
from .bot import TradingBot
from .protocols import ExchangeProtocol, GRPCClientProtocol, SignalListenerProtocol

logger = get_logger(__name__)


class BotClient:
    """Main SDK entry point.

    Orchestrates bot, exchange, gRPC, and signal handling.
    Uses dependency injection - no global state.

    Example:
        bot = MyBot(bot_id="my-bot", name="My Bot")
        config = ClientConfig(...)
        client = BotClient.create(bot, config)
        await client.run()
    """

    def __init__(
        self,
        bot: TradingBot,
        config: ClientConfig,
        exchange: Optional[ExchangeProtocol] = None,
        grpc_client: Optional[GRPCClientProtocol] = None,
        signal_listener: Optional[SignalListenerProtocol] = None,
    ) -> None:
        """Initialize BotClient.

        Args:
            bot: TradingBot instance
            config: Client configuration
            exchange: Exchange adapter (optional)
            grpc_client: gRPC client (optional)
            signal_listener: Signal listener (optional)
        """
        self._bot = bot
        self._config = config
        self._exchange = exchange
        self._grpc = grpc_client
        self._signal_listener = signal_listener
        self._running = False
        self._tasks: list[asyncio.Task[None]] = []

        # Link bot to client
        self._bot._set_client(self)

        # Set gRPC config callback
        if self._grpc:
            self._grpc.on_config = self._on_grpc_config

    @classmethod
    def create(
        cls,
        bot: TradingBot,
        config: ClientConfig,
    ) -> "BotClient":
        """Factory method with default components.

        Auto-creates gRPC client, Redis listener, and exchange from config.

        Args:
            bot: TradingBot instance
            config: Client configuration

        Returns:
            Configured BotClient instance
        """
        # Create exchange if configured
        exchange = None
        if config.exchange:
            exchange = ExchangeFactory.create(
                exchange_name=config.exchange.name,
                api_key=config.exchange.api_key,
                api_secret=config.exchange.api_secret,
                testnet=config.exchange.testnet,
                market_type=config.exchange.market_type.value,
            )

        # Create gRPC client if configured
        grpc_client = None
        if config.grpc:
            grpc_client = GRPCStreamingClient(
                bot_id=config.bot_id,
                host=config.grpc.host,
                port=config.grpc.port,
                api_key=config.grpc.api_key,
                use_tls=config.grpc.use_tls,
            )
            # Set bot's config schema for registration
            grpc_client.set_config_schema(
                schema=bot.get_settings_schema(),
                defaults=bot.get_default_settings(),
            )

        # Create Redis listener if configured
        signal_listener = None
        if config.redis:
            signal_listener = RedisSignalListener(config.redis)

        return cls(
            bot=bot,
            config=config,
            exchange=exchange,
            grpc_client=grpc_client,
            signal_listener=signal_listener,
        )

    @property
    def bot(self) -> TradingBot:
        """Get the trading bot instance."""
        return self._bot

    @property
    def is_running(self) -> bool:
        """Check if client is running."""
        return self._running

    def set_grpc_client(self, grpc_client: GRPCClientProtocol) -> None:
        """Set gRPC client.

        Args:
            grpc_client: gRPC client instance
        """
        self._grpc = grpc_client

    def set_signal_listener(self, listener: SignalListenerProtocol) -> None:
        """Set signal listener.

        Args:
            listener: Signal listener instance
        """
        self._signal_listener = listener

    async def run(self) -> None:
        """Start bot and run until stopped.

        This is the main entry point. Connects to services
        and runs the main event loop.
        """
        logger.info(f"Starting BotClient for {self._bot.name}")
        self._running = True

        try:
            await self._connect_services()
            await self._run_main_loop()
        except BotClientError:
            raise
        except asyncio.CancelledError:
            logger.info("BotClient cancelled")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            raise BotClientError(
                message=str(e),
                code="UNEXPECTED_ERROR",
            ) from e
        finally:
            await self._cleanup()

    async def stop(self) -> None:
        """Gracefully stop the bot."""
        logger.info("Stopping BotClient...")
        self._running = False
        await self._cancel_tasks()

    # === Trading Operations ===

    async def place_order(
        self,
        symbol: str,
        side: str,
        quantity: str,
        reduce_only: bool = False,
    ) -> OrderResult:
        """Place market order via exchange.

        Args:
            symbol: Trading pair
            side: 'BUY' or 'SELL'
            quantity: Order quantity
            reduce_only: If True, only reduce position

        Returns:
            Order execution result
        """
        self._ensure_exchange()
        return await self._exchange.place_market_order(
            symbol=symbol,
            side=side,
            quantity=quantity,
            reduce_only=reduce_only,
        )

    async def get_ticker(self, symbol: str) -> TickerInfo:
        """Get ticker from exchange.

        Args:
            symbol: Trading pair

        Returns:
            Current ticker info
        """
        self._ensure_exchange()
        return await self._exchange.get_ticker(symbol)

    async def get_balance(self) -> AccountBalance:
        """Get balance from exchange.

        Returns:
            Current account balance
        """
        self._ensure_exchange()
        return await self._exchange.get_account_balance()

    async def calculate_quantity(
        self,
        symbol: str,
        usdt_amount: float,
        leverage: int = 1,
    ) -> str:
        """Calculate quantity via exchange.

        Args:
            symbol: Trading pair
            usdt_amount: Amount in USDT
            leverage: Leverage to apply

        Returns:
            Formatted quantity string
        """
        self._ensure_exchange()
        return await self._exchange.calculate_quantity(
            symbol=symbol,
            usdt_amount=usdt_amount,
            leverage=leverage,
        )

    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for futures.

        Args:
            symbol: Trading pair
            leverage: Leverage value

        Returns:
            True if successful
        """
        self._ensure_exchange()
        return await self._exchange.set_leverage(symbol, leverage)

    # === Signal Processing ===

    async def process_signal(self, signal: TradingSignal) -> Optional[OrderResult]:
        """Process a trading signal.

        Routes signal to bot and executes decision.

        Args:
            signal: Trading signal to process

        Returns:
            Order result if trade executed, None otherwise
        """
        if not self._bot.is_running:
            logger.warning("Bot not running, skipping signal")
            return None

        decision = await self._bot.on_signal(signal)
        return await self._execute_decision(signal, decision)

    # === Internal Methods ===

    async def _connect_services(self) -> None:
        """Connect to all required services."""
        self._bot._set_state(BotState.CONNECTING)

        if self._exchange:
            await self._exchange.connect()

        if self._signal_listener:
            await self._signal_listener.connect()

        self._bot._set_state(BotState.RUNNING)
        await self._bot.on_start()

    async def _run_main_loop(self) -> None:
        """Main event loop."""
        tasks: list[asyncio.Task[None]] = []

        # Start gRPC connection task
        # connect() handles registration, receiving commands, heartbeats internally
        if self._grpc:
            tasks.append(asyncio.create_task(self._grpc.connect()))

        # Start Redis signal listener task
        if self._signal_listener:
            tasks.append(asyncio.create_task(self._signal_loop()))

        self._tasks = tasks

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        else:
            # No tasks, just wait for stop signal
            while self._running:
                await asyncio.sleep(1)

    async def _grpc_command_loop(self) -> None:
        """Process gRPC commands from Django."""
        if self._grpc is None:
            return

        try:
            async for config, raw_settings in self._grpc.receive_commands():
                await self._handle_config_update(config, raw_settings)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"gRPC command loop error: {e}")

    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeats to gRPC server."""
        if self._grpc is None:
            return

        interval = self._config.heartbeat_interval
        while self._running:
            try:
                await self._grpc.send_heartbeat()
            except Exception as e:
                logger.warning(f"Heartbeat failed: {e}")
            await asyncio.sleep(interval)

    async def _signal_loop(self) -> None:
        """Listen for and process trading signals."""
        if self._signal_listener is None:
            return

        try:
            async for signal in self._signal_listener.listen():
                if not self._running:
                    break
                await self._handle_signal(signal)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Signal loop error: {e}")

    async def _handle_signal(self, signal: TradingSignal) -> None:
        """Route signal to bot and execute."""
        try:
            decision = await self._bot.on_signal(signal)
            result = await self._execute_decision(signal, decision)
            if result and result.success:
                await self._send_execution_report(signal, result)
        except Exception as e:
            logger.error(f"Signal handling error: {e}")
            await self._bot.on_error(e)

    async def _execute_decision(
        self,
        signal: TradingSignal,
        decision: SignalDecision,
    ) -> Optional[OrderResult]:
        """Execute bot's decision.

        Args:
            signal: Original signal
            decision: Bot's decision

        Returns:
            Order result if trade executed
        """
        if decision.action == SignalAction.SKIP:
            logger.debug(f"Signal skipped: {decision.reason}")
            return None

        if not decision.quantity:
            logger.warning("Decision has no quantity, skipping")
            return None

        return await self._execute_order(signal, decision)

    async def _execute_order(
        self,
        signal: TradingSignal,
        decision: SignalDecision,
    ) -> OrderResult:
        """Execute order based on decision."""
        if decision.action == SignalAction.BUY:
            return await self.place_order(
                symbol=signal.symbol,
                side="BUY",
                quantity=decision.quantity or "0",
            )
        elif decision.action == SignalAction.SELL:
            return await self.place_order(
                symbol=signal.symbol,
                side="SELL",
                quantity=decision.quantity or "0",
            )
        return OrderResult(success=False, error="Invalid action")

    async def _send_execution_report(
        self,
        signal: TradingSignal,
        result: OrderResult,
    ) -> None:
        """Send execution report to Django via gRPC."""
        if self._grpc is None:
            return

        report = ExecutionReport.from_order_result(
            execution_id=f"exec_{signal.signal_id}",
            result=result,
            exchange=self._exchange.name if self._exchange else "unknown",
        )
        await self._grpc.send_execution_report(report)

    def _on_grpc_config(self, config: BotConfig, raw_settings: dict) -> None:
        """Callback for gRPC config updates (sync wrapper)."""
        asyncio.create_task(self._handle_config_update(config, raw_settings))

    async def _handle_config_update(self, config: BotConfig, raw_settings: dict) -> None:
        """Handle config update from Django."""
        logger.info(f"Config update received for {config.name}")

        if not config.enabled:
            self._bot._set_state(BotState.PAUSED)
            await self._bot.on_pause("Disabled by Django")
        elif config.active and self._bot.state == BotState.PAUSED:
            self._bot._set_state(BotState.RUNNING)
            await self._bot.on_resume()

        await self._bot.on_config_update(config, raw_settings)

    async def _cleanup(self) -> None:
        """Cleanup on shutdown."""
        self._bot._set_state(BotState.STOPPING)

        await self._cancel_tasks()

        self._bot._set_state(BotState.STOPPED)
        await self._bot.on_stop("Client shutdown")

        if self._grpc:
            await self._grpc.disconnect()

        if self._exchange:
            await self._exchange.disconnect()

        if self._signal_listener:
            await self._signal_listener.disconnect()

    async def _cancel_tasks(self) -> None:
        """Cancel all running tasks."""
        for task in self._tasks:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    def _ensure_exchange(self) -> ExchangeProtocol:
        """Ensure exchange is configured."""
        if self._exchange is None:
            raise BotNotRunningError(
                message="Exchange not configured. "
                "Provide ExchangeConfig in ClientConfig.",
                bot_id=self._bot.bot_id,
            )
        return self._exchange
