"""
Redis Signal Publisher - publishes signals directly to Redis pub/sub.

This allows Telegram Spy to send signals directly to BotClient
without going through Django.

Flow: Telegram Spy → Redis → BotClient → Custom Bot
"""

import json
from typing import Optional

from shared import get_logger

logger = get_logger(__name__)


class RedisSignalPublisher:
    """
    Publishes trading signals to Redis pub/sub.

    BotClient's RedisSignalListener will pick up these signals.

    Usage:
        publisher = RedisSignalPublisher(
            host="localhost",
            port=6379,
            channel="trading_signals",
        )
        await publisher.connect()
        await publisher.publish(
            symbol="BTCUSDT",
            signal_type="BUY",
            price="95000",
            confidence=0.85,
        )
        await publisher.disconnect()

    Or as context manager:
        async with RedisSignalPublisher(...) as pub:
            await pub.publish(symbol="BTCUSDT", signal_type="BUY")
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        password: Optional[str] = None,
        channel: str = "trading_signals",
        source: str = "telegram_spy",
    ) -> None:
        """Initialize Redis publisher.

        Args:
            host: Redis host
            port: Redis port
            password: Redis password (optional)
            channel: Pub/sub channel name
            source: Signal source identifier
        """
        self._host = host
        self._port = port
        self._password = password
        self._channel = channel
        self._source = source
        self._redis: Optional[object] = None
        self._connected = False

        logger.info(f"RedisSignalPublisher initialized: {host}:{port}/{channel}")

    @property
    def is_connected(self) -> bool:
        """Check if connected to Redis."""
        return self._connected

    @property
    def url(self) -> str:
        """Get Redis URL."""
        if self._password:
            return f"redis://:{self._password}@{self._host}:{self._port}"
        return f"redis://{self._host}:{self._port}"

    async def connect(self, timeout: float = 5.0) -> bool:
        """Connect to Redis.

        Args:
            timeout: Connection timeout in seconds

        Returns:
            True if connected successfully
        """
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                self.url,
                socket_timeout=timeout,
                decode_responses=True,
            )

            # Test connection
            await self._redis.ping()  # type: ignore

            self._connected = True
            logger.info(f"Connected to Redis: {self._host}:{self._port}")
            return True

        except ImportError:
            logger.error("redis package not installed. Install with: pip install redis")
            return False

        except Exception as e:
            logger.error(f"Redis connection failed: {e}")
            self._connected = False
            return False

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._redis:
            await self._redis.close()  # type: ignore
            self._redis = None
            self._connected = False
            logger.info("Disconnected from Redis")

    async def publish(
        self,
        symbol: str,
        signal_type: str,
        price: Optional[str] = None,
        stop_loss: Optional[str] = None,
        take_profit: Optional[str] = None,
        confidence: float = 0.5,
        leverage: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> bool:
        """
        Publish trading signal to Redis.

        Args:
            symbol: Trading pair (e.g., "BTCUSDT")
            signal_type: BUY, SELL, INFO, etc.
            price: Entry price
            stop_loss: Stop loss price
            take_profit: Take profit price
            confidence: Signal confidence 0-1
            leverage: Leverage for futures
            metadata: Additional metadata

        Returns:
            True if published successfully
        """
        if not self._connected or not self._redis:
            logger.warning("Not connected to Redis")
            return False

        # Build message matching RedisSignalListener format
        message = {
            "symbol": symbol.upper().replace("/", ""),
            "signal_type": signal_type.upper(),
            "source": self._source,
            "confidence": confidence,
        }

        if price:
            message["price"] = price
        if stop_loss:
            message["stop_loss"] = stop_loss
        if take_profit:
            message["take_profit"] = take_profit
        if leverage:
            message["leverage"] = leverage

        # Add metadata
        message["metadata"] = metadata or {}
        if stop_loss:
            message["metadata"]["stop_loss"] = stop_loss
        if take_profit:
            message["metadata"]["take_profit"] = take_profit

        try:
            await self._redis.publish(self._channel, json.dumps(message))  # type: ignore
            logger.info(f"Published signal: {symbol} {signal_type} (confidence={confidence:.0%})")
            return True

        except Exception as e:
            logger.error(f"Failed to publish signal: {e}")
            return False

    async def __aenter__(self) -> "RedisSignalPublisher":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
