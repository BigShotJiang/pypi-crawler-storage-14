"""
Telegram Spy CLI.

Usage:
    telegram-spy auth --api-id 12345 --api-hash abc123
    telegram-spy test --session "1BQA..."
    telegram-spy channels --session "1BQA..."
"""

from .commands import telegram_app as app

__all__ = ["app"]
