from .commands import telegram_app

if __name__ == "__main__":
    telegram_app()
