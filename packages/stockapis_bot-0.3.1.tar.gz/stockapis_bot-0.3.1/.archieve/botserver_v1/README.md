# 🤖 StockAPIS Tradebot-Py

FastAPI сервер для управления торговыми ботами с интеграцией Django API и gRPC.

**Статус:** ✅ PRODUCTION READY
**Версия:** 3.0.0
**Python:** 3.12+

---

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
# Перейти в директорию проекта
cd tradebot-py

# Установить зависимости (если нужно)
poetry install
```

### 2. Запустить Redis

```bash
# Проверить работает ли Redis
redis-cli ping

# Если не работает - запустить
redis-server
```

### 3. Запустить Django API (порт 8000)

```bash
# В отдельном терминале, перейти в Django проект
cd ../../../stockapis/solution/projects/django

# Запустить Django
poetry run python manage.py runserver 8000
```

### 4. Запустить FastAPI сервер

```bash
# Вернуться в tradebot-py
cd -

# Запустить сервер
python3.12 run_uvicorn.py
```

**🎉 Готово!** Сервер работает на http://localhost:8010

---

## ✅ Проверка работоспособности

### 1. Health Check

```bash
curl http://localhost:8010/health
```

**Ожидаемый ответ:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "redis": "ok",
  "django": "ok"
}
```

### 2. API Documentation

Открой в браузере: **http://localhost:8010/docs**

### 3. Проверить все сервисы

```bash
# Redis
redis-cli ping  # Должен вернуть PONG

# Django API
curl http://localhost:8000/api/health/  # 200 OK

# FastAPI
curl http://localhost:8010/health  # {"status": "healthy"}

# gRPC (проверить порт 50051)
lsof -i :50051  # Должен показать процесс Python
```

**Если все команды работают → система исправна! ✅**

---

## 📋 Доступные API Endpoints

### Core

- `GET /health` - Проверка здоровья системы
- `GET /docs` - Swagger UI (интерактивная документация)
- `GET /redoc` - ReDoc (альтернативная документация)

### Bot Management

- `GET /api/v1/bots/` - Список всех ботов
- `GET /api/v1/bots/{bot_id}` - Информация о конкретном боте
- `POST /api/v1/bots/{bot_id}/start` - Запустить бота
- `POST /api/v1/bots/{bot_id}/stop` - Остановить бота
- `POST /api/v1/bots/{bot_id}/restart` - Перезапустить бота
- `POST /api/v1/bots/{bot_id}/heartbeat` - Отправить heartbeat

### Health Monitoring

- `GET /api/v1/bots/health/stats` - Статистика мониторинга
- `GET /api/v1/bots/health/alerts` - Все алерты
- `GET /api/v1/bots/{bot_id}/alerts` - Алерты конкретного бота

### Statistics

- `GET /api/v1/bots/stats` - Общая статистика ботов

### Synchronization

- `POST /api/v1/bots/sync` - Синхронизация с Django

---

## 🏗️ Архитектура

```
┌─────────────────────────────────────┐
│ Django (Source of Truth)            │
│ - BotConfig, BotInstance            │
│ - OpenAPI schema                    │
└────────────┬────────────────────────┘
             │
             ▼ make api (auto-generated)
┌─────────────────────────────────────┐
│ Auto-Generated Python Clients       │
│ packages/shared/src/shared/clients/ │
│ - Pydantic models                   │
└────────────┬────────────────────────┘
             │
             ▼ Wrapped by
┌─────────────────────────────────────┐
│ Runtime Wrappers                    │
│ packages/shared/wrappers/           │
│ - BotConfigRuntime                  │
│ - BotInstanceRuntime                │
└────────────┬────────────────────────┘
             │
             ▼ Used by
┌─────────────────────────────────────┐
│ FastAPI Server (tradebot-py)        │
│ - BotManager (координация)          │
│ - BotRegistry (state)                │
│ - HealthMonitor (мониторинг)        │
│ - REST API                           │
│ - gRPC Server (bot streaming)        │
└─────────────────────────────────────┘
```

**Принцип:** Django - единственный источник правды. Все модели генерируются автоматически из Django OpenAPI схемы.

---

## 🔄 Обновление моделей из Django

Когда в Django изменились модели:

```bash
# 1. Перейти в Django проект
cd ../../../stockapis/solution/projects/django

# 2. Запустить генерацию и копирование
make api

# 3. Вернуться в tradebot-py
cd -

# 4. Перезапустить сервер
python3.12 run_uvicorn.py
```

**Готово!** Модели автоматически обновлены.

---

## 📦 Структура проекта

```
tradebot-py/
├── packages/
│   ├── server/              # FastAPI сервер
│   │   └── src/server/
│   │       ├── main.py      # Entry point
│   │       ├── api/         # REST endpoints
│   │       ├── grpc/        # gRPC server
│   │       ├── services/    # Business logic
│   │       └── infrastructure/  # Redis, etc.
│   │
│   └── shared/              # Shared code
│       └── src/shared/
│           ├── clients/     # Auto-generated Django clients
│           │   └── generated/
│           │       ├── trading/
│           │       └── signals/
│           └── wrappers/    # Runtime wrappers
│
├── @docs/                   # Документация
├── run_uvicorn.py          # Скрипт запуска
├── pyproject.toml          # Poetry dependencies
└── README.md               # Этот файл
```

---

## 🛠️ Разработка

### Запуск в dev режиме (с auto-reload)

```bash
poetry run uvicorn server.main:app --host 0.0.0.0 --port 8010 --reload
```

### Остановка сервера

```bash
# Найти и убить процесс на порту 8010
lsof -ti:8010 | xargs kill -9
```

### Логи

```bash
# Запустить с логами в файл
/usr/local/bin/python3.12 run_uvicorn.py > /tmp/fastapi.log 2>&1 &

# Смотреть логи
tail -f /tmp/fastapi.log

# Найти ошибки
grep -i error /tmp/fastapi.log
```

---

## 🔧 Настройка

### Переменные окружения

Проект поддерживает два режима работы: **Development** и **Production**.

#### Development (по умолчанию)

```bash
# Скопировать dev конфиг
cp .env.dev .env

# Или создать из примера
cp .env.example .env
```

Настройки для разработки (`.env.dev`):
- Django API: `http://localhost:8000`
- Redis: `redis://localhost:6379/0`
- Log Level: `DEBUG`

#### Production

```bash
# Скопировать prod конфиг
cp .env.prod .env

# Отредактировать переменные
nano .env
```

**ВАЖНО:** Обязательно заполни в `.env`:
- `DJANGO_API_KEY` - ключ доступа к Django API
- `REDIS_PASSWORD` - пароль Redis (если используется)

Настройки для production (`.env.prod`):
- Django API: `https://api.stockapis.com`
- Redis: настраивается индивидуально
- Log Level: `INFO`

**Безопасность:** Файл `.env.prod` добавлен в `.gitignore` и не попадет в репозиторий.

---

## 🚨 Troubleshooting

### Проблема: "Connection refused"

**Причина:** Redis или Django не запущены.

**Решение:**
```bash
# Проверить Redis
redis-cli ping

# Проверить Django
curl http://localhost:8000/api/health/

# Запустить если нужно
redis-server
cd /path/to/django && poetry run python manage.py runserver 8000
```

### Проблема: "Port 8010 already in use"

**Решение:**
```bash
# Убить процесс на порту 8010
lsof -ti:8010 | xargs kill -9

# Перезапустить
python3.12 run_uvicorn.py
```

### Проблема: Import errors после `make api`

**Причина:** Модели обновились, но сервер не перезапущен.

**Решение:**
```bash
# Перезапустить сервер
lsof -ti:8010 | xargs kill -9
python3.12 run_uvicorn.py
```

### Проблема: gRPC порт 50051 занят

**Решение:**
```bash
lsof -ti:50051 | xargs kill -9
```

---

## 📚 Документация

**Основные документы:**

- `@docs/13-PRODUCTION-STATUS.md` - ✅ Статус production
- `@docs/12-FIXING-CODE-GENERATORS.md` - Как чинить генераторы
- `@docs/10-MIGRATION-STATUS.md` - Статус миграции
- `@docs/09-API-SYNC.md` - Синхронизация с Django
- `HOW_TO_COMMIT_AND_PUSH.md` - Как коммитить и пушить

**Ключевые фичи:**

- ✅ Auto-generated модели из Django OpenAPI
- ✅ Runtime wrappers для бизнес-логики
- ✅ gRPC server для bot streaming
- ✅ Health monitoring с алертами
- ✅ Redis state management
- ✅ Django API V3 integration
- ✅ Interactive API documentation
- ✅ Graceful shutdown
- ✅ Zero warnings, zero errors

---

## 🔗 Связанные проекты

- **Django API:** `../../../stockapis/solution/projects/django`
- **Django-cfg-dev:** Генератор моделей
- **StockAPIS:** Внешний API для торговли

---

## 📞 Support

**GitLab:** gitlab.com:stockapis/bots/tradebot-py.git
**Author:** Reforms AI
**Last Update:** 2025-10-26

---

**Happy Trading! 🚀📈**
