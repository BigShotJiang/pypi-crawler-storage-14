# Listing Monitor

Cryptocurrency listing monitor and auto-trader package.

## Features

- 🔄 Real-time monitoring of new cryptocurrency listings
- 📊 Multi-exchange support (10+ exchanges)
- 🤖 Automated trading execution
- 📈 Position management with exit strategies
- 🔔 Telegram notifications
- ⚡ High-performance with price caching

## Supported Exchanges

- Bybit
- Binance
- BingX
- OKX
- Gate.io
- MEXC
- XT.com
- Bitget
- Hyperliquid
- DevServer (testing)

## Installation

From the monorepo root:

```bash
cd packages/listing-monitor
poetry install
```

## Usage

```bash
# Run the monitor
poetry run listing-monitor

# Or activate virtual environment
poetry shell
python -m listing_monitor
```

## Configuration

See `config/` for configuration examples (.env, proxies.json).

## Testing

```bash
# Run all tests
poetry run pytest

# Run with coverage
poetry run pytest --cov

# Run specific test file
poetry run pytest tests/unit/test_exchanges/test_bybit_basic.py
```

## Documentation

See `../../docs/` for detailed documentation.
