-- REM Optional Extensions
-- Description: Optional PostgreSQL extensions that enhance functionality but are not required
-- Version: 1.0.0
-- Date: 2025-11-29
--
-- These extensions are installed with try/catch - failures are logged but don't break the install.
-- This allows the same migration to work on:
--   - Custom images with extensions baked in (percolationlabs/rem-pg:18)
--   - Standard PostgreSQL images (extensions will be skipped)
--
-- Extensions:
--   - pg_net: Async HTTP/HTTPS requests from triggers and functions (Supabase)

-- ============================================================================
-- pg_net: Async HTTP Extension
-- ============================================================================
-- Enables PostgreSQL to make non-blocking HTTP requests from triggers and functions.
-- Requires: Custom image with pg_net compiled, shared_preload_libraries='pg_net'
--
-- Use cases:
--   - Webhook notifications on data changes
--   - Async event publishing to external APIs
--   - Background HTTP requests from triggers

DO $$
BEGIN
    -- Attempt to create pg_net extension
    CREATE EXTENSION IF NOT EXISTS pg_net;
    RAISE NOTICE '  pg_net extension installed successfully';
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE '  pg_net extension not available (this is OK if using standard PostgreSQL image)';
        RAISE NOTICE '  Error: %', SQLERRM;
END $$;

-- ============================================================================
-- pg_net Helper Functions (only created if extension exists)
-- ============================================================================
-- Wrapper functions for common HTTP operations with sensible defaults

DO $$
BEGIN
    -- Only create helpers if pg_net is available
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_net') THEN

        -- Helper: POST JSON to a URL with standard headers
        EXECUTE $func$
        CREATE OR REPLACE FUNCTION rem_http_post(
            p_url TEXT,
            p_body JSONB,
            p_headers JSONB DEFAULT '{}'::jsonb
        )
        RETURNS BIGINT AS $inner$
        DECLARE
            merged_headers JSONB;
            request_id BIGINT;
        BEGIN
            -- Merge default headers with provided headers
            merged_headers := '{"Content-Type": "application/json"}'::jsonb || p_headers;

            SELECT net.http_post(
                url := p_url,
                headers := merged_headers,
                body := p_body
            ) INTO request_id;

            RETURN request_id;
        END;
        $inner$ LANGUAGE plpgsql;
        $func$;

        RAISE NOTICE '  rem_http_post helper function created';

        -- Helper: GET from a URL
        EXECUTE $func$
        CREATE OR REPLACE FUNCTION rem_http_get(
            p_url TEXT,
            p_headers JSONB DEFAULT '{}'::jsonb
        )
        RETURNS BIGINT AS $inner$
        DECLARE
            request_id BIGINT;
        BEGIN
            SELECT net.http_get(
                url := p_url,
                headers := p_headers
            ) INTO request_id;

            RETURN request_id;
        END;
        $inner$ LANGUAGE plpgsql;
        $func$;

        RAISE NOTICE '  rem_http_get helper function created';

    ELSE
        RAISE NOTICE '  Skipping pg_net helper functions (extension not installed)';
    END IF;
END $$;

-- ============================================================================
-- RECORD INSTALLATION
-- ============================================================================

DO $$
BEGIN
    -- Only record if migrations table exists
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'rem_migrations') THEN
        INSERT INTO rem_migrations (name, type, version)
        VALUES ('003_optional_extensions.sql', 'install', '1.0.0')
        ON CONFLICT (name) DO UPDATE
        SET applied_at = CURRENT_TIMESTAMP,
            applied_by = CURRENT_USER;
    END IF;
END $$;

-- ============================================================================
-- COMPLETION
-- ============================================================================

DO $$
DECLARE
    pg_net_installed BOOLEAN;
BEGIN
    SELECT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_net') INTO pg_net_installed;

    RAISE NOTICE '============================================================';
    RAISE NOTICE 'Optional Extensions Installation Complete';
    RAISE NOTICE '============================================================';
    RAISE NOTICE '';
    IF pg_net_installed THEN
        RAISE NOTICE 'Installed:';
        RAISE NOTICE '  pg_net (async HTTP/HTTPS requests)';
        RAISE NOTICE '  rem_http_post() helper function';
        RAISE NOTICE '  rem_http_get() helper function';
    ELSE
        RAISE NOTICE 'Skipped (not available in this PostgreSQL image):';
        RAISE NOTICE '  pg_net';
        RAISE NOTICE '';
        RAISE NOTICE 'To enable pg_net, use the custom image: percolationlabs/rem-pg:18';
    END IF;
    RAISE NOTICE '============================================================';
END $$;
