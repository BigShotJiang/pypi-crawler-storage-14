# This file auto generated!
# DO NOT EDIT MANUALLY!

version: str = "0.7.0"
__version__: str = "0.7.0"

commit_hash: str = "g6a1b2b50a6835fe170fb5e9036e22537650f3a5d"
version_timestamp: str = "2025-11-29 23:56:07.377421+00:00"

tag: str = "0.7.0"
branch: str = "HEAD"
commit_date: str = "2025-11-29"
commit_count_since_tag: int = 0
