"""Runner for executing ML experiments with MLFlow tracking."""

# ToDo: Add support for estimator specific transformer: https://chatgpt.com/share/e/6923056a-7a44-8012-a36d-d822b913db60

from __future__ import annotations

import os
import tempfile
from typing import Any
import warnings

import mlflow
import numpy as np
import pandas as pd

try:
    import matplotlib

    matplotlib.use("Agg")  # Use non-interactive backend
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    r2_score,
    recall_score,
)
from sklearn.model_selection import GroupShuffleSplit, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .dataset import Dataset
from .experiment import Experiment
from .feature import Feature
from .model import Model


class ModelRunner:
    """Handles training, evaluation, and MLflow logging for a specific model.

    Responsibilities:
    - Create model-specific preprocessing pipeline
    - Create model-specific pipeline (preprocessor + model)
    - Train the model
    - Evaluate model performance
    - Calculate feature weights/importances
    - Log results to MLflow

    Parameters
    ----------
    model_name : str
        Name of the model to run
    numerical_features : List[str]
        List of numerical feature column names
    categorical_features : List[str]
        List of categorical feature column names
    experiment : Experiment
        Experiment specification
    X_train : pd.DataFrame
        Training features
    y_train : pd.Series
        Training target
    X_val : Optional[pd.DataFrame]
        Validation features (optional)
    y_val : Optional[pd.Series]
        Validation target (optional)
    X_test : pd.DataFrame
        Test features
    y_test : pd.Series
        Test target
    X_holdout : Optional[pd.DataFrame]
        Holdout features (optional)
    y_holdout : Optional[pd.Series]
        Holdout target (optional)
    verbose : bool, optional
        Whether to print progress information, by default True
    """

    def __init__(
        self,
        model_name: str,
        numerical_features: list[str],
        categorical_features: list[str],
        experiment: Experiment,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_test: pd.DataFrame,
        y_test: pd.Series,
        X_val: pd.DataFrame | None = None,
        y_val: pd.Series | None = None,
        X_holdout: pd.DataFrame | None = None,
        y_holdout: pd.Series | None = None,
        verbose: bool = True,
    ):
        self.model_name = model_name
        self.numerical_features = numerical_features
        self.categorical_features = categorical_features
        self.experiment = experiment
        self.config = experiment.config
        self.X_train = X_train
        self.y_train = y_train
        self.X_val = X_val
        self.y_val = y_val
        self.X_test = X_test
        self.y_test = y_test
        self.X_holdout = X_holdout
        self.y_holdout = y_holdout
        self.verbose = verbose

        # Pipeline and model storage
        self.preprocessor: ColumnTransformer | None = None
        self.model: Any | None = None
        self.full_pipeline: Pipeline | None = None

    def _log(self, message: str) -> None:
        """Print message if verbose is enabled."""
        if self.verbose:
            print(f"[ModelRunner:{self.model_name}] {message}")

    def _build_preprocessing_pipeline(self) -> ColumnTransformer:
        """Build preprocessing pipeline for features.

        Creates separate pipelines for numerical and categorical features:
        - Numerical: integer-to-float conversion + imputation + standardization
        - Categorical: imputation + one-hot encoding

        The integer-to-float conversion ensures MLflow schema compatibility by
        converting integer columns to float64, preventing schema enforcement
        errors when missing values are present at inference time.

        Returns
        -------
        ColumnTransformer
            Preprocessing pipeline
        """
        self._log("Building preprocessing pipeline")

        # Build transformers
        transformers = []

        if self.numerical_features:
            numerical_transformer = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="median")),
                    ("scaler", StandardScaler()),
                ]
            )
            transformers.append(("num", numerical_transformer, self.numerical_features))

        if self.categorical_features:
            categorical_transformer = Pipeline(
                steps=[
                    (
                        "imputer",
                        SimpleImputer(strategy="constant", fill_value="missing"),
                    ),
                    (
                        "onehot",
                        OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                    ),
                ]
            )
            transformers.append((
                "cat",
                categorical_transformer,
                self.categorical_features,
            ))

        if not transformers:
            raise ValueError("No features to process")

        self.preprocessor = ColumnTransformer(
            transformers=transformers, remainder="drop"
        )

        return self.preprocessor

    def _create_pipeline(self) -> Pipeline:
        """Create full pipeline with preprocessor and model.

        Returns
        -------
        Pipeline
            Full pipeline with preprocessor and model steps
        """
        # Build preprocessing pipeline if not already built
        if self.preprocessor is None:
            self._build_preprocessing_pipeline()

        # Load model configuration
        model_obj = Model(self.model_name, self.config)
        model_instance = model_obj.instantiate()

        # Create full pipeline
        pipeline = Pipeline(
            steps=[("preprocessor", self.preprocessor), ("model", model_instance)]
        )

        self.model = model_instance
        self.full_pipeline = pipeline

        return pipeline

    def _calculate_metrics(
        self,
        y_true: pd.Series,
        y_pred: np.ndarray,
        metrics_list: list[str] | None = None,
    ) -> dict[str, float]:
        """Calculate evaluation metrics.

        Parameters
        ----------
        y_true : pd.Series
            True target values
        y_pred : np.ndarray
            Predicted values
        metrics_list : Optional[List[str]]
            List of metric names to calculate. If None, uses experiment metrics.

        Returns
        -------
        Dict[str, float]
            Dictionary of metric names to values
        """
        if metrics_list is None:
            metrics_list = self.experiment.spec.metrics or ["r2", "mse"]

        results = {}

        for metric_name in metrics_list:
            metric_name_lower = metric_name.lower()

            try:
                if metric_name_lower.startswith("r2"):
                    results["r2_score"] = r2_score(y_true, y_pred)
                elif metric_name_lower in ["mse", "mean_squared_error"]:
                    results["mean_squared_error"] = mean_squared_error(y_true, y_pred)
                elif metric_name_lower in ["rmse", "root_mean_squared_error"]:
                    results["root_mean_squared_error"] = np.sqrt(
                        mean_squared_error(y_true, y_pred)
                    )
                elif metric_name_lower in ["mae", "mean_absolute_error"]:
                    results["mean_absolute_error"] = mean_absolute_error(y_true, y_pred)
                elif metric_name_lower.startswith("accuracy"):
                    results["accuracy_score"] = accuracy_score(y_true, y_pred)
                elif metric_name_lower.startswith("precision"):
                    results["precision_score"] = precision_score(
                        y_true, y_pred, average="weighted"
                    )
                elif metric_name_lower.startswith("recall"):
                    results["recall_score"] = recall_score(
                        y_true, y_pred, average="weighted"
                    )
                elif metric_name_lower.startswith("f1"):
                    results["f1_score"] = f1_score(y_true, y_pred, average="weighted")
                else:
                    self._log(f"Warning: Unknown metric '{metric_name}'")
            except Exception as e:
                self._log(f"Error calculating metric '{metric_name}': {e}")

        return results

    def _calculate_feature_weights(self) -> pd.DataFrame:
        """Calculate feature importances or coefficients.

        Returns
        -------
        pd.DataFrame
            DataFrame with feature names and their weights/importances
        """
        if self.model is None:
            raise RuntimeError(
                "Model must be trained before calculating feature weights"
            )
        if self.preprocessor is None:
            raise RuntimeError(
                "Preprocessor must exist before calculating feature weights"
            )

        # Get feature names from preprocessor
        feature_names = self.preprocessor.get_feature_names_out()
        # Drop prefix before '__' in feature names, if present
        feature_names = [
            name.split("__", 1)[-1] if "__" in name else name for name in feature_names
        ]
        # Get feature names after preprocessing
        # feature_names = []
        # for name, transformer, columns in self.preprocessor.transformers_:
        #     if name == 'num':
        #         feature_names.extend(columns)
        #     elif name == 'cat':
        #         # For one-hot encoded features, get names from encoder
        #         ohe = transformer.named_steps['onehot']
        #         if hasattr(ohe, 'get_feature_names_out'):
        #             cat_features = ohe.get_feature_names_out(columns)
        #             feature_names.extend(cat_features)
        #         else:
        #             # Fallback for older sklearn versions
        #             feature_names.extend(columns)

        # Extract weights/importances from model
        weights = None
        weight_type = None

        if hasattr(self.model, "coef_"):
            # Linear models (coefficients)
            weights = self.model.coef_
            weight_type = "coefficient"
        elif hasattr(self.model, "feature_importances_"):
            # Tree-based models (feature importances)
            weights = self.model.feature_importances_
            weight_type = "importance"
        else:
            self._log(
                "Warning: Model does not have coefficients or feature importances"
            )
            return pd.DataFrame()

        # Handle multi-dimensional coefficients (e.g., multi-class classification)
        if len(weights.shape) > 1:
            weights = np.abs(weights).mean(axis=0)

        # Create DataFrame
        df = pd.DataFrame({
            "feature": feature_names[: len(weights)],
            weight_type: weights,
        })
        df = df.sort_values(by=weight_type, ascending=False, key=abs)

        self._log(f"Top 5 features by {weight_type}:")
        for idx, row in df.head(5).iterrows():
            self._log(f"  {row['feature']}: {row[weight_type]:.6f}")

        return df

    def _create_confusion_matrix_plot(
        self, y_true: pd.Series, y_pred: np.ndarray, split_name: str
    ) -> str | None:
        """Create confusion matrix plot for classification.

        Parameters
        ----------
        y_true : pd.Series
            True target values
        y_pred : np.ndarray
            Predicted values
        split_name : str
            Name of the data split (e.g., 'test', 'val', 'holdout')

        Returns
        -------
        Optional[str]
            Path to saved plot file, or None if matplotlib is not available
        """
        if not MATPLOTLIB_AVAILABLE:
            self._log(
                "Warning: matplotlib not available, skipping confusion matrix plot"
            )
            return None

        try:
            # Get unique class labels
            classes = sorted(set(y_true.unique()) | set(y_pred))

            # Calculate confusion matrix with explicit labels
            cm = confusion_matrix(y_true, y_pred, labels=classes)

            # Create plot
            fig, ax = plt.subplots(figsize=(8, 6))

            # Use seaborn if available for better visualization
            try:
                import seaborn as sns

                sns.heatmap(
                    cm,
                    annot=True,
                    fmt="d",
                    cmap="Blues",
                    ax=ax,
                    cbar_kws={"label": "Count"},
                    xticklabels=classes,
                    yticklabels=classes,
                )
            except ImportError:
                # Fallback to matplotlib if seaborn not available
                im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
                ax.figure.colorbar(im, ax=ax)

                # Add text annotations
                thresh = cm.max() / 2.0
                for i in range(cm.shape[0]):
                    for j in range(cm.shape[1]):
                        ax.text(
                            j,
                            i,
                            format(cm[i, j], "d"),
                            ha="center",
                            va="center",
                            color="white" if cm[i, j] > thresh else "black",
                        )

            ax.set(
                xlabel="Predicted Label",
                ylabel="True Label",
                title=f"Confusion Matrix ({split_name})",
            )
            ax.set_xticks(np.arange(len(classes)))
            ax.set_yticks(np.arange(len(classes)))
            ax.set_xticklabels(classes)
            ax.set_yticklabels(classes)

            plt.tight_layout()

            # Save to temporary file
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_file:
                plot_path = tmp_file.name

            fig.savefig(plot_path, dpi=150, bbox_inches="tight")
            plt.close(fig)

            return plot_path
        except Exception as e:
            self._log(f"Error creating confusion matrix plot: {e}")
            return None

    def _create_regression_plots(
        self, y_true: pd.Series, y_pred: np.ndarray, split_name: str
    ) -> str | None:
        """Create actual vs predicted and residuals vs predicted plots for regression.

        Parameters
        ----------
        y_true : pd.Series
            True target values
        y_pred : np.ndarray
            Predicted values
        split_name : str
            Name of the data split (e.g., 'test', 'val', 'holdout')

        Returns
        -------
        Optional[str]
            Paths to saved plot files (actual_vs_predicted, residuals_vs_predicted),
            or (None, None) if matplotlib is not available
        """
        if not MATPLOTLIB_AVAILABLE:
            self._log("Warning: matplotlib not available, skipping regression plots")
            return None

        try:
            # Calculate residuals
            residuals = y_true.values - y_pred

            # Create figure with two subplots
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

            # Plot 1: Actual vs Predicted
            ax1.scatter(y_true, y_pred, alpha=0.6, s=20)

            # Add diagonal line (perfect prediction)
            min_val = min(y_true.min(), y_pred.min())
            max_val = max(y_true.max(), y_pred.max())
            ax1.plot(
                [min_val, max_val],
                [min_val, max_val],
                "r--",
                lw=2,
                label="Perfect prediction",
            )

            ax1.set_xlabel("Actual Values")
            ax1.set_ylabel("Predicted Values")
            ax1.set_title(f"Actual vs Predicted ({split_name})")
            ax1.legend()
            ax1.grid(True, alpha=0.3)

            # Plot 2: Residuals vs Predicted
            ax2.scatter(y_pred, residuals, alpha=0.6, s=20)

            # Add horizontal line at y=0
            ax2.axhline(y=0, color="r", linestyle="--", lw=2, label="Zero residual")

            ax2.set_xlabel("Predicted Values")
            ax2.set_ylabel("Residuals")
            ax2.set_title(f"Residuals vs Predicted ({split_name})")
            ax2.legend()
            ax2.grid(True, alpha=0.3)

            plt.tight_layout()

            # Save to temporary files
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_file1:
                actual_vs_pred_path = tmp_file1.name

            fig.savefig(actual_vs_pred_path, dpi=150, bbox_inches="tight")

            plt.close(fig)

            return actual_vs_pred_path
        except Exception as e:
            self._log(f"Error creating regression plots: {e}")
            return None

    def fit_and_evaluate(self) -> dict[str, Any]:
        """Train the model, evaluate it, and log to MLflow.

        This method encapsulates the full model lifecycle:
        - Creates the pipeline
        - Fits the model
        - Evaluates on test/validation/holdout sets
        - Calculates feature weights
        - Creates evaluation plots (confusion matrix for classification,
          actual/predicted and residuals plots for regression)
        - Logs everything to MLflow

        Returns
        -------
        Dict[str, Any]
            Dictionary containing metrics, feature_weights, and model pipeline
        """
        self._log("Starting model training and evaluation")

        # Create pipeline (integer-to-float conversion is handled in the pipeline)
        self._create_pipeline()

        # Log everything in the MLFlow run
        # Suppress MLflow autologging warnings about integer columns
        with warnings.catch_warnings():
            # Suppress the specific integer column warning from MLflow
            warnings.filterwarnings(
                "ignore",
                message=".*integer column.*",
                category=UserWarning,
                module="mlflow.utils.autologging_utils",
            )
            warnings.filterwarnings(
                "ignore",
                message=".*Inferred schema contains integer column.*",
                category=UserWarning,
            )
            warnings.filterwarnings(
                "ignore", message=".*Hint: Inferred schema.*", category=UserWarning
            )

            with mlflow.start_run():
                # Autolog everything in the MLFlow run - MUST be called BEFORE training
                mlflow.autolog()
                print("Active run:", mlflow.active_run())

                # Train the model (this will be automatically logged by autolog)
                self._log("Training model")
                self.full_pipeline.fit(self.X_train, self.y_train)
                self._log("Model training completed")

                # Determine experiment type
                experiment_type = self.experiment.get_type()
                assert experiment_type is not None, "Experiment type must be set"

                # Evaluate on all sets and collect metrics
                metrics = {}
                y_true_for_plot = None
                y_pred_for_plot = None
                split_name_for_plot = None

                # Evaluate validation set first (priority for plots)
                if self.X_val is not None and self.y_val is not None:
                    self._log("Evaluating model on validation set")
                    mlflow.log_metric("val_size", len(self.X_val))
                    y_pred_val = self.full_pipeline.predict(self.X_val)
                    val_metrics = self._calculate_metrics(self.y_val, y_pred_val)
                    for metric, value in val_metrics.items():
                        self._log(f"  val_{metric}: {value:.6f}")
                        mlflow.log_metric(f"val_{metric}", value)
                    metrics.update(val_metrics)

                    # Store for plotting (validation has priority)
                    y_true_for_plot = self.y_val
                    y_pred_for_plot = y_pred_val
                    split_name_for_plot = "val"

                # Evaluate test set
                if self.X_test is not None and self.y_test is not None:
                    self._log("Evaluating model on test set")
                    mlflow.log_metric("test_size", len(self.X_test))
                    y_pred_test = self.full_pipeline.predict(self.X_test)
                    test_metrics = self._calculate_metrics(self.y_test, y_pred_test)
                    for metric, value in test_metrics.items():
                        self._log(f"  test_{metric}: {value:.6f}")
                        mlflow.log_metric(f"test_{metric}", value)
                    metrics.update(test_metrics)

                    # Store for plotting
                    y_true_for_plot = self.y_test
                    y_pred_for_plot = y_pred_test
                    split_name_for_plot = "test"

                # Evaluate holdout set
                if self.X_holdout is not None and self.y_holdout is not None:
                    self._log("Evaluating model on holdout set")
                    mlflow.log_metric("holdout_size", len(self.X_holdout))
                    y_pred_holdout = self.full_pipeline.predict(self.X_holdout)
                    holdout_metrics = self._calculate_metrics(
                        self.y_holdout, y_pred_holdout
                    )
                    for metric, value in holdout_metrics.items():
                        self._log(f"  holdout_{metric}: {value:.6f}")
                        mlflow.log_metric(f"holdout_{metric}", value)
                    metrics.update(holdout_metrics)

                    # Store for plotting
                    y_true_for_plot = self.y_holdout
                    y_pred_for_plot = y_pred_holdout
                    split_name_for_plot = "holdout"

                # Create and log plots once (for validation if exists, otherwise test)
                if y_true_for_plot is not None and y_pred_for_plot is not None:
                    self._log(
                        f"Creating evaluation plots for {split_name_for_plot} set"
                    )
                    if experiment_type == "classification":
                        plot_path = self._create_confusion_matrix_plot(
                            y_true_for_plot, y_pred_for_plot, split_name_for_plot
                        )
                        if plot_path:
                            mlflow.log_artifact(plot_path, "plots")
                            os.unlink(plot_path)  # Clean up temporary file
                    elif experiment_type == "regression":
                        actual_vs_pred_path = self._create_regression_plots(
                            y_true_for_plot, y_pred_for_plot, split_name_for_plot
                        )
                        if actual_vs_pred_path:
                            mlflow.log_artifact(actual_vs_pred_path, "plots")
                            os.unlink(actual_vs_pred_path)

                # Calculate feature weights
                feature_weights = self._calculate_feature_weights()

                # Log feature weights
                if feature_weights is not None:
                    with tempfile.TemporaryDirectory() as tmpdir:
                        weights_path = os.path.join(tmpdir, "feature_weights.csv")
                        feature_weights.to_csv(weights_path, index=False)
                        mlflow.log_artifact(weights_path)

                mlflow.end_run()

        return {
            "metrics": metrics,
            "feature_weights": feature_weights,
            "model": self.full_pipeline,
        }


class Runner:
    """Execute ML experiments with full lifecycle management.

    Responsibilities:
    - Load datasets
    - Build preprocessing pipelines
    - Handle train/validation/test splits
    - Coordinate ModelRunner instances for each model

    Parameters
    ----------
    experiment : Experiment
        Experiment specification to run
    verbose : bool, optional
        Whether to print progress information, by default True
    """

    def __init__(self, experiment: Experiment, verbose: bool = True):
        self.experiment = experiment
        self.verbose = verbose
        self.config = experiment.config

        # Data storage
        self.dataset: pd.DataFrame | None = None
        self.X_train: pd.DataFrame | None = None
        self.X_val: pd.DataFrame | None = None
        self.X_test: pd.DataFrame | None = None
        self.y_train: pd.Series | None = None
        self.y_val: pd.Series | None = None
        self.y_test: pd.Series | None = None
        self.X_holdout: pd.DataFrame | None = None
        self.y_holdout: pd.Series | None = None

        # Feature tracking
        self.numerical_features: list[str] = []
        self.categorical_features: list[str] = []
        self.all_features: list[str] = []

        # ModelRunner instances
        self.model_runners: list[ModelRunner] = []

    def _log(self, message: str) -> None:
        """Print message if verbose is enabled."""
        if self.verbose:
            print(f"[Runner] {message}")

    def load_dataset(self) -> pd.DataFrame:
        """Load dataset specified in experiment.

        Also infers experiment type from target column if not specified in configuration.

        Returns
        -------
        pd.DataFrame
            Loaded dataset
        """
        self._log(f"Loading dataset: {self.experiment.spec.dataset}")
        dataset = Dataset(self.experiment.spec.dataset, self.config)
        self.dataset = dataset.read_pandas()
        self._log(
            f"Dataset loaded: {len(self.dataset)} rows, {len(self.dataset.columns)} columns"
        )

        # Infer experiment type from target if not specified
        if self.experiment.spec.type is None:
            inferred_type = self.experiment.infer_type_from_dataset(self.dataset)
            self._log(
                f"Inferred experiment type: {inferred_type} (from target column dtype)"
            )
        else:
            self._log(f"Using configured experiment type: {self.experiment.spec.type}")

        return self.dataset

    def _collect_features(self) -> tuple[list[str], list[str]]:
        """Collect and classify features from feature set.

        Returns
        -------
        Tuple[List[str], List[str]]
            Lists of (numerical_features, categorical_features)
        """
        numerical_cols = []
        categorical_cols = []

        feature_name = self.experiment.spec.features
        feature = Feature(feature_name, self.config)

        # Check if feature uses __all__ special keyword
        if feature.spec.numerical or feature.spec.categorical:
            numerical_cols.extend(feature.spec.numerical)
            categorical_cols.extend(feature.spec.categorical)
        else:
            # Feature has columns list - need to infer types from DataFrame
            # This should not happen if Feature class is properly implemented
            # but we handle it for robustness
            pass

        # Remove duplicates while preserving order
        numerical_cols = list(dict.fromkeys(numerical_cols))
        categorical_cols = list(dict.fromkeys(categorical_cols))

        return numerical_cols, categorical_cols

    def _infer_column_types(
        self, df: pd.DataFrame, columns: list[str]
    ) -> tuple[list[str], list[str]]:
        """Infer which columns are numerical vs categorical based on dtypes.

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame to infer from
        columns : List[str]
            Columns to classify

        Returns
        -------
        Tuple[List[str], List[str]]
            Lists of (numerical_features, categorical_features)
        """
        numerical = []
        categorical = []

        for col in columns:
            if col not in df.columns:
                self._log(f"Warning: Column '{col}' not found in dataset")
                continue

            dtype = df[col].dtype
            if pd.api.types.is_numeric_dtype(dtype):
                numerical.append(col)
            else:
                categorical.append(col)

        return numerical, categorical

    def prepare_features(self) -> tuple[list[str], list[str]]:
        """Prepare and classify features from feature set.

        Collects features from feature specifications and classifies them
        as numerical or categorical. If feature specifications don't include
        types, infers from DataFrame dtypes.

        Returns
        -------
        Tuple[List[str], List[str]]
            Lists of (numerical_features, categorical_features)
        """
        if self.dataset is None:
            raise RuntimeError("Dataset must be loaded before preparing features")

        self._log("Preparing features")

        # Collect features from feature specifications
        numerical_cols, categorical_cols = self._collect_features()

        # If no explicit type specifications, infer from all feature columns
        all_feature_cols = numerical_cols + categorical_cols

        # Remove target column if present
        target = self.experiment.spec.target
        all_feature_cols = [col for col in all_feature_cols if col != target]

        # If features still empty, try to get all columns except target
        if not all_feature_cols:
            self._log("No features specified, using all columns except target")
            all_feature_cols = [col for col in self.dataset.columns if col != target]
            numerical_cols, categorical_cols = self._infer_column_types(
                self.dataset, all_feature_cols
            )

        # For features with "columns" specification, we need to infer types
        # This happens when features use the columns: [...] syntax
        if numerical_cols or categorical_cols:
            # Re-infer to make sure types are correct based on actual dtypes
            numerical_cols, categorical_cols = self._infer_column_types(
                self.dataset, all_feature_cols
            )

        self.numerical_features = numerical_cols
        self.categorical_features = categorical_cols
        self.all_features = numerical_cols + categorical_cols

        self._log(f"Numerical features ({len(numerical_cols)}): {numerical_cols}")
        self._log(f"Categorical features ({len(categorical_cols)}): {categorical_cols}")

        return numerical_cols, categorical_cols

    def split_data(self) -> None:
        """Split data into train/validation/test sets.

        Respects:
        - hold_out configuration for creating a separate hold-out set
        - do_not_split_by for grouped splitting (prevents data leakage)
        - split configuration for train/validation/test proportions
        """
        if self.dataset is None:
            raise RuntimeError("Dataset must be loaded before splitting")

        self._log("Splitting data")

        target = self.experiment.spec.target
        if target not in self.dataset.columns:
            raise ValueError(f"Target column '{target}' not found in dataset")

        df = self.dataset.copy()

        # Separate features and target
        y = df[target]
        X = df[self.all_features]

        # Handle hold-out set first if specified
        hold_out_config = self.experiment.spec.hold_out
        hold_out_fraction = (
            hold_out_config.get("fraction", 0.0) if hold_out_config else 0.0
        )

        if hold_out_fraction > 0:
            self._log(f"Creating hold-out set: {hold_out_fraction:.1%}")
            hold_out_random_state = hold_out_config.get("random_state", 42)

            # Check if we need grouped splitting for hold-out
            do_not_split_by = self.experiment.spec.do_not_split_by
            if do_not_split_by:
                groups = X[do_not_split_by[0]]  # Use first grouping column
                splitter = GroupShuffleSplit(
                    n_splits=1,
                    test_size=hold_out_fraction,
                    random_state=hold_out_random_state,
                )
                train_idx, holdout_idx = next(splitter.split(X, y, groups=groups))
                X_remaining, self.X_holdout = X.iloc[train_idx], X.iloc[holdout_idx]
                y_remaining, self.y_holdout = y.iloc[train_idx], y.iloc[holdout_idx]
            else:
                X_remaining, self.X_holdout, y_remaining, self.y_holdout = (
                    train_test_split(
                        X,
                        y,
                        test_size=hold_out_fraction,
                        random_state=hold_out_random_state,
                    )
                )

            self._log(f"Hold-out set size: {len(self.X_holdout)}")
        else:
            X_remaining, y_remaining = X, y

        # Split into train/test
        split_config = self.experiment.spec.split
        test_size = split_config.get("test_size", 0.2) if split_config else 0.2
        random_state = split_config.get("random_state", 42) if split_config else 42

        do_not_split_by = self.experiment.spec.do_not_split_by

        if do_not_split_by:
            # Grouped splitting to prevent data leakage
            self._log(f"Performing grouped split by: {do_not_split_by}")
            groups = X_remaining[do_not_split_by[0]]  # Use first grouping column

            splitter = GroupShuffleSplit(
                n_splits=1, test_size=test_size, random_state=random_state
            )
            train_idx, test_idx = next(
                splitter.split(X_remaining, y_remaining, groups=groups)
            )
            X_train_temp, self.X_test = (
                X_remaining.iloc[train_idx],
                X_remaining.iloc[test_idx],
            )
            y_train_temp, self.y_test = (
                y_remaining.iloc[train_idx],
                y_remaining.iloc[test_idx],
            )
        else:
            X_train_temp, self.X_test, y_train_temp, self.y_test = train_test_split(
                X_remaining, y_remaining, test_size=test_size, random_state=random_state
            )

        # Split train into train/validation if validation_size specified
        validation_size = (
            split_config.get("validation_size", 0.0) if split_config else 0.0
        )

        if validation_size > 0:
            self._log(
                f"Creating validation set: {validation_size:.1%} of training data"
            )

            if do_not_split_by:
                groups_train = X_train_temp[do_not_split_by[0]]
                splitter = GroupShuffleSplit(
                    n_splits=1, test_size=validation_size, random_state=random_state
                )
                train_idx, val_idx = next(
                    splitter.split(X_train_temp, y_train_temp, groups=groups_train)
                )
                self.X_train, self.X_val = (
                    X_train_temp.iloc[train_idx],
                    X_train_temp.iloc[val_idx],
                )
                self.y_train, self.y_val = (
                    y_train_temp.iloc[train_idx],
                    y_train_temp.iloc[val_idx],
                )
            else:
                self.X_train, self.X_val, self.y_train, self.y_val = train_test_split(
                    X_train_temp,
                    y_train_temp,
                    test_size=validation_size,
                    random_state=random_state,
                )
        else:
            self.X_train = X_train_temp
            self.y_train = y_train_temp

        self._log(f"Train set size: {len(self.X_train)}")
        if self.X_val is not None:
            self._log(f"Validation set size: {len(self.X_val)}")
        self._log(f"Test set size: {len(self.X_test)}")

    def run(self) -> dict[str, Any]:
        """Execute the complete experiment workflow.

        Returns
        -------
        Dict[str, Any]
            Results dictionary containing metrics and artifacts for all models
        """
        self._log(f"Starting experiment: {self.experiment.name}")

        # Step 1: Load dataset
        self.load_dataset()

        # Step 2: Prepare features (classify as numerical/categorical)
        self.prepare_features()

        # Step 3: Split data
        self.split_data()

        # Step 4: Create ModelRunner instances for each model
        if not self.numerical_features and not self.categorical_features:
            raise RuntimeError("No features prepared before creating ModelRunners")
        if (
            self.X_train is None
            or self.y_train is None
            or self.X_test is None
            or self.y_test is None
        ):
            raise RuntimeError("Data must be split before creating ModelRunners")

        # Set up MLflow
        self._log("Logging to MLFlow")
        # Set experiment name
        experiment_name = self.experiment.name
        # Check if tracking server is Databricks; if so, add /Shared/ prefix only for Databricks
        tracking_uri = mlflow.get_tracking_uri()
        if tracking_uri.startswith("databricks"):
            experiment_path = f"/Shared/{experiment_name}"
        else:
            experiment_path = experiment_name
        mlflow.set_experiment(experiment_path)
        # Enable MLflow autologging
        # mlflow.autolog()

        self.model_runners = []
        for model_name in self.experiment.spec.models:
            model_runner = ModelRunner(
                model_name=model_name,
                numerical_features=self.numerical_features,
                categorical_features=self.categorical_features,
                experiment=self.experiment,
                X_train=self.X_train,
                y_train=self.y_train,
                X_test=self.X_test,
                y_test=self.y_test,
                X_val=self.X_val,
                y_val=self.y_val,
                X_holdout=self.X_holdout,
                y_holdout=self.y_holdout,
                verbose=self.verbose,
            )
            self.model_runners.append(model_runner)

        # Step 5: Run each ModelRunner
        results = {}

        for model_runner in self.model_runners:
            self._log(f"\n{'=' * 60}")
            self._log(f"Processing model: {model_runner.model_name}")
            self._log(f"{'=' * 60}")

            model_results = model_runner.fit_and_evaluate()
            results[model_runner.model_name] = model_results

        self._log(f"\n{'=' * 60}")
        self._log("Experiment completed successfully!")
        self._log(f"{'=' * 60}")

        return results


__all__ = ["Runner", "ModelRunner"]
