from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import fitz  # type: ignore

from .text_image import RasterImage, create_text_image
from .utils import add_pdf_extension, contains_chinese, ensure_parent_dir, resolve_output_path


@dataclass
class WatermarkResult:
    output_path: Path
    page_count: int
    watermark_description: str
    watermark_type: str


def _to_path(path_like: str) -> Path:
    return Path(path_like).expanduser().resolve()


def _scale_dimensions(width: float, height: float, max_width: float, max_height: float) -> tuple[float, float]:
    scale = min(max_width / width, max_height / height, 1.0)
    return width * scale, height * scale


def _compute_position(position: str, page_rect: fitz.Rect, width: float, height: float) -> fitz.Rect:
    pos_map = {
        "center": (page_rect.width / 2 - width / 2, page_rect.height / 2 - height / 2),
        "top-left": (36, page_rect.height - height - 36),
        "top-right": (page_rect.width - width - 36, page_rect.height - height - 36),
        "bottom-left": (36, 36),
        "bottom-right": (page_rect.width - width - 36, 36),
    }

    x, y = pos_map.get(position, pos_map["center"])
    return fitz.Rect(x, y, x + width, y + height)


def _prepare_watermark_image(
    watermark_text: Optional[str],
    watermark_image_path: Optional[str],
    font_size: int,
    color: str,
    background_color: str,
    opacity: float = 1.0,
) -> tuple[RasterImage, str, str]:
    from io import BytesIO
    from PIL import Image

    if watermark_image_path:
        image_path = _to_path(watermark_image_path)
        if not image_path.exists():
            raise FileNotFoundError(f"Watermark image not found: {image_path}")

        with Image.open(image_path) as img:
            rgba = img.convert("RGBA")
            if opacity < 1.0:
                alpha = rgba.split()[3]
                alpha = alpha.point(lambda p: int(p * opacity))
                rgba.putalpha(alpha)
            buffer = BytesIO()
            rgba.save(buffer, format="PNG")
            return (
                RasterImage(data=buffer.getvalue(), width=rgba.width, height=rgba.height),
                f"Image watermark: {image_path.name}",
                "image",
            )

    if not watermark_text:
        raise ValueError("Either text or image watermark must be provided")

    raster = create_text_image(
        text=watermark_text,
        font_size=font_size,
        color=color,
        background_color=background_color,
    )

    if opacity < 1.0:
        img = Image.open(BytesIO(raster.data))
        rgba = img.convert("RGBA")
        alpha = rgba.split()[3]
        alpha = alpha.point(lambda p: int(p * opacity))
        rgba.putalpha(alpha)
        buffer = BytesIO()
        rgba.save(buffer, format="PNG")
        raster = RasterImage(data=buffer.getvalue(), width=rgba.width, height=rgba.height)

    watermark_type = "CJK image watermark" if contains_chinese(watermark_text) else "Text watermark"
    description = f"{watermark_type}: \"{watermark_text}\""
    return raster, description, "image"


def add_watermark(
    input_path: str,
    output_path: str,
    watermark_text: Optional[str] = None,
    watermark_image_path: Optional[str] = None,
    opacity: float = 0.3,
    font_size: int = 24,
    position: str = "center",
    rotation: float = 0.0,
    layout: str = "single",
) -> WatermarkResult:
    source_path = _to_path(input_path)
    if not source_path.exists():
        raise FileNotFoundError(f"File not found: {source_path}")
    if source_path.suffix.lower() != ".pdf":
        raise ValueError("Input file must be a PDF")

    raster, description, watermark_type = _prepare_watermark_image(
        watermark_text,
        watermark_image_path,
        font_size,
        "#808080",
        "transparent",
        opacity=max(0.0, min(opacity, 1.0)),
    )

    doc = fitz.open(source_path)
    page_count = doc.page_count
    if page_count == 0:
        raise ValueError("Input PDF is empty")

    for page in doc:
        rect = page.rect
        max_width = rect.width * 0.4
        max_height = rect.height * 0.4
        width, height = _scale_dimensions(raster.width, raster.height, max_width, max_height)

        if layout == "corners":
            positions = [
                _compute_position("top-left", rect, width, height),
                _compute_position("top-right", rect, width, height),
                _compute_position("bottom-left", rect, width, height),
                _compute_position("bottom-right", rect, width, height),
            ]
            for target_rect in positions:
                page.insert_image(
                    target_rect,
                    stream=raster.data,
                    overlay=True,
                    keep_proportion=True,
                    rotate=rotation,
                )
        elif layout == "tile":
            spacing_x = width * 1.5
            spacing_y = height * 1.5
            cols = int(rect.width / spacing_x) + 1
            rows = int(rect.height / spacing_y) + 1
            for row in range(rows):
                for col in range(cols):
                    x = col * spacing_x
                    y = row * spacing_y
                    if x + width <= rect.width and y + height <= rect.height:
                        target_rect = fitz.Rect(x, y, x + width, y + height)
                        page.insert_image(
                            target_rect,
                            stream=raster.data,
                            overlay=True,
                            keep_proportion=True,
                            rotate=rotation,
                        )
        else:
            target_rect = _compute_position(position, rect, width, height)
            page.insert_image(
                target_rect,
                stream=raster.data,
                overlay=True,
                keep_proportion=True,
                rotate=rotation,
            )

    resolved_output_path = add_pdf_extension(resolve_output_path(source_path, output_path))
    ensure_parent_dir(resolved_output_path)
    doc.save(resolved_output_path)
    doc.close()

    layout_desc = {
        "single": "",
        "corners": "(corners)",
        "tile": "(tiled)",
    }.get(layout, "")

    return WatermarkResult(
        output_path=resolved_output_path,
        page_count=page_count,
        watermark_description=f"{description}{layout_desc}",
        watermark_type=watermark_type,
    )
