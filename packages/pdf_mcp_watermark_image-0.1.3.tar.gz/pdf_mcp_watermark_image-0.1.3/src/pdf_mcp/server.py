"""PDF MCP Server using FastMCP."""

from __future__ import annotations

import logging
from typing import Optional

from fastmcp import FastMCP

from .pdf_tools import add_watermark

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("PDF 添加图片水印")


@mcp.tool()
def add_pdf_watermark(
    input_path: str,
    output_path: str,
    watermark_text: Optional[str] = None,
    watermark_image_path: Optional[str] = None,
    opacity: float = 0.5,
    font_size: int = 24,
    position: str = "center",
    rotation: float = 0.0,
    layout: str = "tile",
) -> str:
    """为PDF添加水印。
    
    Args:
        input_path: 输入PDF文件路径
        output_path: 输出PDF文件路径
        watermark_text: 水印文字内容
        watermark_image_path: 水印图片路径
        opacity: 不透明度 (0.0-1.0)
        font_size: 文字大小
        position: 位置，可选 "center", "top-left", "top-right", "bottom-left", "bottom-right"
        rotation: 旋转角度
        layout: 布局模式，可选 "single"(单个), "corners"(四角), "tile"(平铺)
    
    Returns:
        添加水印结果的详细信息
    """
    
    try:
        result = add_watermark(
            input_path,
            output_path,
            watermark_text,
            watermark_image_path,
            opacity,
            font_size,
            position,
            rotation,
            layout,
        )
        return (
            f"✅ 添加水印成功\n"
            f"输出文件: {result.output_path}\n"
            f"页数: {result.page_count}\n"
            f"水印类型: {result.watermark_type}\n"
            f"水印描述: {result.watermark_description}"
        )
    
    except Exception as e:
        logger.error(f"Failed to add watermark: {e}")
        raise


def main():
    """启动MCP服务器。"""
    mcp.run()


if __name__ == "__main__":
    main()
