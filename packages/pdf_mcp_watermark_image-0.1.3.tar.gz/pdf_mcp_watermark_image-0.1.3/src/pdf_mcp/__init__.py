"""PDF操作的Model Context Protocol服务器。"""

from .server import main

__all__ = ["main"]
