# PDF 添加图片水印 MCP 服务

仅提供一个工具：`add_pdf_watermark`，用于为 PDF 添加图片或由文字生成的水印。

## 运行

```bash
uv run pdf-mcp-server
```

或：

```bash
$env:PYTHONPATH="src"; python -c "import pdf_mcp.server; pdf_mcp.server.main()"
```

## 工具：add_pdf_watermark

- `input_path` (str) 输入 PDF 文件路径
- `output_path` (str) 输出 PDF 文件路径
- `watermark_text` (str, 可选) 水印文字（将生成图片叠加）
- `watermark_image_path` (str, 可选) 水印图片路径
- `opacity` (float) 不透明度 (0.0-1.0)
- `font_size` (int) 文字水印基础字号
- `position` (str) 位置：`center`, `top-left`, `top-right`, `bottom-left`, `bottom-right`
- `rotation` (float) 旋转角度
- `layout` (str) 布局：`single`、`corners`、`tile`

## 示例

```
给 report.pdf 添加 "机密文件" 图片水印，居中并 45° 旋转
```

## 依赖

- `fastmcp`
- `pymupdf` (fitz)
- `pillow`

## License

MIT
