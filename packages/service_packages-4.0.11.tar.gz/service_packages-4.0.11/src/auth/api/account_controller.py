from litestar import Controller, post
from litestar.di import Provide
import msgspec

from auth.services import AuthService, provide_auth_service, provide_user_service


class SignUpRequestScheme(msgspec.Struct):
    email: str
    password: str


class SignUpResponseScheme(msgspec.Struct):
    message: str


class AccountController(Controller):
    path = "/account"

    dependencies = {
        "user_service": Provide(provide_user_service),
        "auth_service": Provide(provide_auth_service),
    }

    @post("/signup")
    async def sign_up(
        self, data: SignUpRequestScheme, auth_service: AuthService
    ) -> SignUpResponseScheme:
        return SignUpResponseScheme(message="success")
