"""CLI commands for mcp-skillset."""

from mcp_skills.cli.main import cli


__all__ = ["cli"]
