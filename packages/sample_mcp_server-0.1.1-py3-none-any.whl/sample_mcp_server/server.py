from mcp.server.fastmcp import FastMCP # FastMCP

mcp = FastMCP("Test Server") # FastMCPサーバを初期化

@mcp.tool()
def calculate_bmi(weight_kg: float,height_m: float) -> float:
  """BMIの計算"""
  return weight_kg/(height_m**2)

@mcp.prompt()
def review_code(code: str) -> str:
  return f"下記のコードをレビューして下さい:\n\n{code}"

@mcp.resource("config://app")
def get_config() -> str:
  """Static configuration data"""
  return "App configuration here"

if __name__=="__main__": # main関数
  mcp.run(transport="stdio") # MCPサーバ実行
