# 1     path to search

find $1 -name MERLIN_FINISHED -type f | wc -l
