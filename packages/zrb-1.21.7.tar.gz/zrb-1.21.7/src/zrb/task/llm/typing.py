from typing import Any

ListOfDict = list[dict[str, Any]]
