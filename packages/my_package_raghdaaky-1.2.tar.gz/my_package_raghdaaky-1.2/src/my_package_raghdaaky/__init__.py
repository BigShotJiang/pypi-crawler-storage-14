AUTHOR = "Raghda Yagoub"
VERSION = "0.0.1"

"""
ft_package is customized package that include all the modules that you might 
use later 
for now it only contains one file 
"""