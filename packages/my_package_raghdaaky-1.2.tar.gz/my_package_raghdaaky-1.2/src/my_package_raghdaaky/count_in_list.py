def count_in_list(l:list,s:str)->int:
 count :int= 0
 for item in l:
    if(item==s):
      count+=1
 return(count)


print(count_in_list(["toto", "tata", "toto"], "toto")) 
# print(count_in_list(["toto", "tata", "toto"], "tutu"))