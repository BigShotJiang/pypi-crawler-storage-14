# from setuptools import setup, find_packages
# setup(
#     name="my_package_raghdaaky",
#     version="1.0",
#     packages=find_packages(where="src"),  # look inside src/
#     package_dir={"": "src"},               # tells setuptools that packages are under src/
#     install_requires=[],                   # dependencies if any
#     python_requires=">=3.10",
# )

from setuptools import setup, find_packages

setup(
    name="my_package_raghdaaky",
    version="1.1",
    packages=find_packages(where="src"),  # look inside src/
    package_dir={"": "src"},               # tells setuptools the root for packages is src/
    install_requires=[],
    python_requires=">=3.10",
)
