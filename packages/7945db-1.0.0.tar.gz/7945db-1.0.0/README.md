# 7945DB - Güvenli ve Okunamaz Database Sistemi

**Python için özel olarak tasarlanmış, .7945db uzantılı güvenli database sistemi**

## 🚀 Özellikler

- 🔒 **Tamamen Okunamaz**: `.7945db` dosyaları şifrelenmiş formatta
- 📝 **Özel Fonksiyonlar**: `.7945d` dosyaları ile özel database fonksiyonları
- 🛡️ **Güvenli**: AES-256 şifreleme ile veri koruması
- 🔧 **Basit API**: Kolay anlaşılır metodlar
- 📊 **Zengin Fonksiyonlar**: Arama, istatistik, analiz ve daha fazlası

## 📦 Kurulum

```bash
pip install 7945db
```

## 🎯 Hızlı Başlangıç

### Temel Kullanım

```python
from 7945db import create_database

# Database oluştur
db = create_database()

# Database dosyasını ayarla
db.file('./veritabanim.7945db')

# Tablo ve değişken ekle
db.add(type='table', name='kullanıcılar')
db.add(
    type='variable',
    name='kullanıcı-adı',
    table='kullanıcılar',
    value='str',
    cstm_value='admin'
)
db.add(
    type='variable',
    name='şifre',
    table='kullanıcılar',
    value='str',
    cstm_value='123456'
)

# Değer oku
kullanici = db.get(table='kullanıcılar', name='kullanıcı-adı')
print(f'Kullanıcı: {kullanici}')  # "admin"

# Değer güncelle
db.set('kullanıcılar', 'şifre', 'yeniŞifre123')

# Database'i göster
db.show()
```

### Gelişmiş Fonksiyonlar

```python
# Tüm tabloları listele
tablolar = db.list_all_tables()
print(f'Tablolar: {tablolar}')

# Tablo detaylarını getir
tablo_bilgisi = db.get_table_info(tableName='kullanıcılar')
print(f'Tablo Bilgisi: {tablo_bilgisi}')

# Değer ara
sonuçlar = db.search_database(searchTerm='admin')
print(f'Arama Sonuçları: {sonuçlar}')

# İstatistikler
istatistikler = db.get_database_statistics()
print(f'İstatistikler: {istatistikler}')

# Değişkenleri listele
değişkenler = db.list_table_variables(tableName='kullanıcılar')
print(f'Değişkenler: {değişkenler}')
```

## 📁 Dosya Yapısı

### .7945db Dosyaları
- 🔒 Tamamen şifrelenmiş ve okunamaz
- 📁 Kullanıcı tarafından belirlenen herhangi bir yerde olabilir
- 💾 Otomatik kaydetme özelliği

### .7945d Dosyaları
- 📝 Özel database fonksiyonlarını içerir
- 🔧 Modülün çekirdek fonksiyonlarını tanımlar
- 🎯 Okuma, arama, analiz fonksiyonları

## 🛠️ API Referansı

### Temel Metodlar

#### `db.file(path)`
Database dosyasını ayarlar.

```python
db.file('./veritabanim.7945db')
```

#### `db.add(**kwargs)`
Tablo veya değişken ekler.

```python
# Tablo ekle
db.add(type='table', name='ürünler')

# Değişken ekle
db.add(
    type='variable',
    name='fiyat',
    table='ürünler',
    value='num',
    cstm_value=100
)
```

#### `db.get(**kwargs)`
Değişken değerini okur.

```python
deger = db.get(table='ürünler', name='fiyat')
```

#### `db.set(table, variable, value)`
Değişken değerini günceller.

```python
db.set('ürünler', 'fiyat', 150)
```

#### `db.show()`
Database içeriğini ekrana yazdırır.

```python
db.show()
```

### Gelişmiş Fonksiyonlar

#### `db.list_all_tables(**kwargs)`
Tüm tabloları listeler.

#### `db.get_table_info(**kwargs)`
Tablo detaylarını getirir.

#### `db.list_table_variables(**kwargs)`
Tablonun tüm değişkenlerini listeler.

#### `db.search_database(**kwargs)`
Database'de değer arar.

#### `db.get_database_statistics(**kwargs)`
Database istatistiklerini getirir.

#### `db.read_variable(**kwargs)`
Değişken değerini okur.

#### `db.conditional_read(**kwargs)`
Koşullu okuma yapar.

#### `db.find_relationships(**kwargs)`
Tablo ilişkilerini bulur.

#### `db.get_variable_history(**kwargs)`
Değişken geçmişini getirir.

#### `db.analyze_schema(**kwargs)`
Schema analizi yapar.

#### `db.read_backup(**kwargs)`
Backup dosyasını okur.

#### `db.generate_summary(**kwargs)`
Özet rapor oluşturur.

#### `db.export_data(**kwargs)`
Veri dışa aktarır.

#### `db.validate_data(**kwargs)`
Veri validasyonu yapar.

## 🔒 Güvenlik

7945DB, verilerinizi çok katmanlı şifreleme ile korur:

- 🔑 AES-256-CBC şifreleme
- 🎯 Özel binary format
- 📁 Dosya bütünlük kontrolleri
- ⚡ Otomatik şifreleme/çözme

## 💡 Örnek Senaryolar

### Kullanıcı Yönetimi
```python
from 7945db import create_database

db = create_database()
db.file('./kullanıcılar.7945db')

# Kullanıcı tablosu oluştur
db.add(type='table', name='kullanıcılar')
db.add(type='variable', name='email', table='kullanıcılar', value='str')
db.add(type='variable', name='şifre', table='kullanıcılar', value='str')
db.add(type='variable', name='rol', table='kullanıcılar', value='str', cstm_value='kullanıcı')

# Kullanıcı ekle
db.set('kullanıcılar', 'email', 'ali@example.com')
db.set('kullanıcılar', 'şifre', 'güvenliŞifre123')

# Kullanıcı ara
kullanıcılar = db.search_database(searchTerm='ali')
```

### Ürün Kataloğu
```python
from 7945db import create_database

db = create_database()
db.file('./ürünler.7945db')

db.add(type='table', name='ürünler')
db.add(type='variable', name='isim', table='ürünler', value='str')
db.add(type='variable', name='fiyat', table='ürünler', value='num')
db.add(type='variable', name='stok', table='ürünler', value='num')

# İstatistikleri görüntüle
stats = db.get_database_statistics()
print(f"Toplam {stats['tableCount']} tablo, {stats['totalVariables']} değişken")
```

## 🐛 Sorun Giderme

### Database dosyası okunamıyor
```python
try:
    db.file('./veritabanım.7945db')
except ValueError as error:
    print(f'Database hatası: {error}')
```

### Değişken bulunamadı hatası
```python
try:
    deger = db.get(table='tablo', name='değişken')
    print(f'Değer: {deger}')
except ValueError:
    print('Değişken bulunamadı')
```

## 📄 Lisans

MIT License - detaylar için LICENSE dosyasına bakın.

## sorunlar

[![github sorun](https://img.shields.io/badge/sorununuz-varsa_t%C4%B1klay%C4%B1n-blue?logo=github)](https://github.com/sbusiedcake7945/7945db-py/issues)

---

**7945DB** - Python için güvenli ve güçlü database çözümünüz! 🚀