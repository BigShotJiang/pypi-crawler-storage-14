from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="7945db",
    version="1.0.0",
    author="sbusiedcake7945",
    description="Güvenli .7945db database sistemi ve .7945d interpreter",
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
    install_requires=[
        "pycryptodome>=3.14.1",
    ],
    entry_points={
        "console_scripts": [
            "7945db=index:main",
        ],
    },
)