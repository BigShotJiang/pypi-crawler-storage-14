"""
This package contains heart-centered AI prompts.

Prompts are copied from the root project directory during installation,
keeping a single source of truth.
"""
