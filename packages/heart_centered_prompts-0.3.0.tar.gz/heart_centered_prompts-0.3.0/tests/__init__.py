"""
Unit tests for heart_centered_prompts package.
"""
