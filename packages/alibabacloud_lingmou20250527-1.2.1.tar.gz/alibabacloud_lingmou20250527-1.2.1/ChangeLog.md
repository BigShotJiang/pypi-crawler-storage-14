2025-10-29 Version: 1.2.0
- Support API CreateBackgroundPic.
- Support API CreateChatConfig.
- Support API CreateNoTrainPicAvatar.
- Support API GetUploadPolicy.


2025-08-20 Version: 1.1.0
- Support API CloseChatInstanceSessions.
- Support API QueryChatInstanceSessions.


2025-07-16 Version: 1.0.0
- Generated python 2025-05-27 for LingMou.

