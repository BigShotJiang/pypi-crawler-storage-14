"""Typer integration examples for valid8r."""
