"""Unit tests for examples."""

from __future__ import annotations
