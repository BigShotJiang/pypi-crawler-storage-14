<!-- 1. HEADER & BRANDING -->
<p align="center">
  <img src="https://raw.githubusercontent.com/imtt-dev/steer/main/assets/steer.png" alt="Steer Labs Logo" width="120">
</p>

<h1 align="center">Steer</h1>

<p align="center">
  <a href="https://steer-labs.com" target="_blank">steer-labs.com</a>
</p>

<p align="center">
  <strong>The Active Reliability Layer for AI Agents.</strong>
</p>

<p align="center">
  Stop debugging. Start teaching. <br>
  Steer turns runtime hallucinations into permanent fixes—instantly.
</p>

<p align="center">
  <!-- PyPI Version -->
  <a href="https://pypi.org/project/steer-sdk/">
    <img src="https://img.shields.io/pypi/v/steer-sdk?color=0070f3&label=pypi%20package" alt="PyPI">
  </a>
  <!-- License -->
  <a href="LICENSE">
    <img src="https://img.shields.io/badge/license-MIT-white" alt="License">
  </a>
  <!-- Twitter -->
  <a href="https://twitter.com/steerlabs">
    <img src="https://img.shields.io/badge/follow-%40steerlabs-1DA1F2?logo=twitter&style=flat" alt="Twitter">
  </a>
</p>

<br>

<!-- 2. THE HERO SHOT (Visual Proof) -->
<!-- Save a screenshot of your main dashboard list view to assets/dashboard-hero.png -->
<p align="center">
  <img src="https://raw.githubusercontent.com/imtt-dev/steer/main/assets/dashboard-hero.png" alt="Steer Mission Control" width="100%">
</p>
<p align="center">
  <em>Mission Control: Catching hallucinations locally and fixing them with one click.</em>
</p>

---

## ⚡ Quickstart

Get running in 30 seconds. No API keys required.

```bash
pip install steer-sdk
steer init   # Generates 3 interactive demo agents
steer ui     # Launches Mission Control dashboard
```

**Then run a demo:**
```bash
python 01_structure_guard.py
```

---

## 🧠 Why Steer?

Most AI tools are passive. Steer is **active**.

| Feature | The Old Way (Observability) | The Steer Way (Reliability) |
| :--- | :--- | :--- |
| **Reaction** | Alerts you *after* the user crashes. | **Blocks** the crash before it happens. |
| **Fixing** | You edit code, re-prompt, and re-deploy. | You **"Teach"** the agent a fix in the UI. |
| **Privacy** | Sends your prompts to a cloud logger. | **Local-First.** Data stays on your machine. |

---

## 🛑 The Problem: Logging isn't Enough

When an agent fails in production (e.g., outputs bad JSON or leaks PII), seeing a log doesn't help the user who just got a crash.

**Steer creates a "Teaching Layer" around your agent.**
1.  **Catch:** Intercept the failure in real-time.
2.  **Teach:** Provide a correction in the Dashboard.
3.  **Fix:** Steer injects that "memory" into the agent immediately.

---

## ⚡ The Loop: Catch → Teach → Fix

Steer provides a Human-in-the-Loop workflow to fix "Confident Idiot" agents.

### 1. Catch (The Guard)
Steer wraps your agent and blocks bad outputs *before* they return.

![JSON Structure Guard Demo](https://raw.githubusercontent.com/imtt-dev/steer/main/assets/demo_json.gif)

```text
[Steer] 🤖 Agent generating profile...
[Steer] 🚨 BLOCKED: Structure Guard (Detected Markdown wrapping).
[Steer] 🛡️ Execution halted.
```

### 2. Teach (The Fix)
Instead of editing code, go to **Steer Mission Control** (`steer ui`).
*   Click the blocked incident.
*   Click **"Teach"**.
*   Select the fix (e.g., **"Strict JSON Mode"**).

*Steer now remembers this rule for this agent.*

### 3. Fix (The Result)
Run the agent again. Steer automatically injects your teaching instruction. The agent self-corrects.

```text
[Steer] 🧠 Context loaded: "Strict JSON" rule found. Applying fix...
[Steer] ✅ SUCCESS: Agent output valid JSON.
```

---

## 🛡️ Supported Guardrails

Steer comes with 3 "Teach-Ready" verifiers out of the box:

| Verifier | The Problem | The "Teaching" Fix |
| :--- | :--- | :--- |
| **JsonVerifier** | Agent wraps code in \`\`\`json blocks | **"Force JSON"**: Inject system instruction to output raw JSON only. |
| **RegexVerifier** | Agent leaks PII (Emails/Keys) | **"Redact PII"**: Force agent to replace sensitive patterns with [REDACTED]. |
| **AmbiguityVerifier** | Agent guesses ambiguous answers | **"Ask Clarification"**: Force agent to ask user questions if >3 results found. |

---

## 🛠️ Integration

To add Steer to your own existing agent, just add `steer_rules` to your function arguments.

```python
from steer import capture
from steer.verifiers import JsonVerifier

# 1. Define Verifiers
json_check = JsonVerifier(name="Strict JSON")

# 2. Decorate your Agent Function
@capture(verifiers=[json_check])
def my_agent(user_input, steer_rules=""):
    
    # 3. Steer automatically injects rules here!
    # Pass 'steer_rules' to your system prompt.
    system_prompt = f"You are a helpful assistant.\n{steer_rules}"
    
    # ... Your LLM call ...
    return llm.call(system_prompt, user_input)
```

---

## 🔮 Roadmap: From Verification to Learning

Steer v0.1 provides the "Fast Path" (Runtime Guardrails + Human Teaching).
Steer v0.2+ will introduce the "Slow Path" (Automated Model Improvement).

**Coming Soon:**

*   **Query by Committee:** Automated consensus checks for ambiguous prompts.
*   **Automated Fine-Tuning:** A pipeline to turn your accumulated (Incident -> Fix) logs into a fine-tuned model that stops making those mistakes entirely.
*   **CI/CD Integration:** Block Pull Requests if an agent fails a reliability test suite.

---

## 🔑 Configuration (Optional)

The Quickstart demos run locally and require **no API keys**.

To use advanced LLM-based verifiers (like `FactConsistencyVerifier`) in production, set your keys:
```bash
export GEMINI_API_KEY=AIzaSy...
# OR
export OPENAI_API_KEY=sk-...
```