"""Custom exceptions for the Lumo SDK."""


class LumoError(Exception):
    """Base exception for all Lumo SDK errors."""

    pass


class LumoAPIError(LumoError):
    """Exception raised for API-related errors."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class LumoAuthenticationError(LumoAPIError):
    """Exception raised for authentication errors (401)."""

    pass


class LumoRateLimitError(LumoAPIError):
    """Exception raised for rate limit errors (429)."""

    pass


class LumoServerError(LumoAPIError):
    """Exception raised for server errors (500)."""

    pass

