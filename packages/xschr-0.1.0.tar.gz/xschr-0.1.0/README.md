# XSchr
simple job scheduler for personal deep-learning research.
