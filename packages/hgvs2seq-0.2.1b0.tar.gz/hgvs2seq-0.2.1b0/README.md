# hvgs2seq

From a tabulated file, with an hgvs column (e.g. `NM_000142.4:c.1953G>A`), build a transcriptomic 
sequence of a fixed size (31 by default) around the variant.

- the hgvs could be splitted in two columns (e.g. col 1: `NM_000142.4` and col 2: `c.1953G>A`)
- when the variant is an indel largest than the specified size, the insertion/deletion will be
  truncated
- when the variant is located at the edge of the transcript, it will not be centered.
- not all hgvs nomenclature is covered.

## Installation

With pip (recommended)

```
pip install hgvs2seq
```

With github

requiresite : biopython

```
git clone https://github.com/Bio2M/hgvs2seq.git
PATH=${PWD}/hgvs2seq/hgvs2seq:$PATH               # also in your .bashrc
```

## Usage

```
  -h, --help            show this help message and exit
  -q, --query QUERY     Query as TSV format
  -r, --ref, --reference REF
                        Annotation Fasta File, according the query
  -t, --out-type {ref,alt,both}
                        result contain only ALT, REF, or both sequences
  -c, --col, --column COL [COL ...]
                        column index of the HGVS notation. The first column is '1'
                        (or 'A'). If HGVS is splitted in two columns (refseq &
                        variant) specify the two columns, for example '5 10': 5 is
                        the column for the reference (ex: NM_004006.2) and 10 is
                        the column for the variant (ex: c.93+1G>T). 'E J' is the
                        same. If not specified, hgvs2seq will try to find it (one
                        column only).
  -s, --size SIZE       Output sequence size
  -a, --add-columns ADD_COLUMNS [ADD_COLUMNS ...]
                        Add one or more columns to header (ex: '-a 3 AA' will add
                        columns 3 and 27). The first column is '1' (or 'A')
  -o, --output OUTPUT   output file name (default: stdout)
  -f, --output-format {fa,tsv}
                        Output file format (default: fa)
  -n, --no-header       Query file has no header
  -w, --no-warnings     do not add warnings to fasta headers
  -m, --show-messages   Show Message explanations and quit
  -v, --version         show program's version number and exit
```
