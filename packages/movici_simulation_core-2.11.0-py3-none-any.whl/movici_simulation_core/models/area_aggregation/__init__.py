from .model import Model as AreaAggregationModel

__all__ = ["AreaAggregationModel"]
