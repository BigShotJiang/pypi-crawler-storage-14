from .model import Model as Corridor

__all__ = ["Corridor"]
