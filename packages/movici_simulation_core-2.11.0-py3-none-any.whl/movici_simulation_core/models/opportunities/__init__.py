from .model import Model as Opportunities

__all__ = ["Opportunities"]
