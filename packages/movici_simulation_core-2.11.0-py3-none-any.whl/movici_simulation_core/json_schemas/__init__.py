import pathlib

SCHEMA_PATH = PATH = pathlib.Path(__file__).parent

__all__ = ["SCHEMA_PATH", "PATH"]
