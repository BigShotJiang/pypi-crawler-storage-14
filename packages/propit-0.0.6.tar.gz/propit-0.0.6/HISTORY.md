# History

## 0.0.3 (2025-11-25)

* Add reader for comet target and decoy txt output files from separate search.

## 0.0.2 (2025-11-25)

* First release on PyPI.
