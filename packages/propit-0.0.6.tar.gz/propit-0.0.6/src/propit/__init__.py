"""Top-level package for Proteomics Pipeline Toolkit."""

__author__ = """Fabian Egli"""
__email__ = "fabianegli@users.noreply.github.com"
