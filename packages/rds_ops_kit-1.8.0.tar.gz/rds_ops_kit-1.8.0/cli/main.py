"""
RDS Ops Kit CLI entry point.

Dieses Modul implementiert die offizielle CLI-Oberfläche:

    rds-ops-kit [GLOBAL OPTIONS] <command> <subcommand> [OPTIONS]

Commands:
    pg          Parameter Group Presets (list/show/diff/export)
    plan        Deployment-Plan (generate/validate)
    readiness   Oracle → PostgreSQL Readiness-Analyse

Global Options:
    --profile, --region, --format, --verbose, --quiet, --version
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import click

try:
    # Single source of truth für die Version
    from rds_ops_kit import __version__
except Exception:  # Fallback, falls __version__ noch nicht gesetzt ist
    __version__ = "1.0.0"

# Engine-Module optional importieren – falls sie (noch) nicht existieren,
# bekommt der Nutzer eine saubere Fehlermeldung statt ImportError.
try:
    from rds_ops_kit.pg import engine as pg_engine  # type: ignore
except ImportError:  # pragma: no cover - optional
    pg_engine = None

try:
    from rds_ops_kit.planning import engine as planning_engine  # type: ignore
except ImportError:  # pragma: no cover
    planning_engine = None

try:
    from rds_ops_kit.readiness import engine as readiness_engine  # type: ignore
except ImportError:  # pragma: no cover
    readiness_engine = None


# ---------------------------------------------------------------------------
# Kontextobjekt für globale Optionen
# ---------------------------------------------------------------------------


@dataclass
class CLIContext:
    aws_profile: Optional[str] = None
    aws_region: Optional[str] = None
    output_format: str = "table"
    verbose: bool = False
    quiet: bool = False


pass_context = click.make_pass_decorator(CLIContext, ensure=True)


# ---------------------------------------------------------------------------
# Top-Level CLI
# ---------------------------------------------------------------------------


@click.group()
@click.option(
    "--profile",
    "-p",
    metavar="NAME",
    help="AWS CLI profile to use.",
)
@click.option(
    "--region",
    "-r",
    metavar="REGION",
    help="AWS region to use (overrides profile).",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json", "yaml"], case_sensitive=False),
    default="table",
    show_default=True,
    help="Default output format where supported.",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable verbose output/logging.",
)
@click.option(
    "--quiet",
    is_flag=True,
    default=False,
    help="Reduce output to minimum.",
)
@click.version_option(
    version=__version__,
    prog_name="rds-ops-kit",
    message="%(prog)s, version %(version)s",
)
@pass_context
def cli(
    ctx: CLIContext,
    profile: Optional[str],
    region: Optional[str],
    output_format: str,
    verbose: bool,
    quiet: bool,
) -> None:
    """
    RDS Ops Kit CLI.

    Toolkit für Parameter Groups, Deployment-Planning und
    Oracle→PostgreSQL Readiness-Analysen.
    """
    ctx.aws_profile = profile
    ctx.aws_region = region
    ctx.output_format = output_format
    ctx.verbose = verbose
    ctx.quiet = quiet

    if verbose and quiet:
        # Das ist bewusst ein klarer Fehler – beides gleichzeitig ist unsinnig.
        raise click.ClickException("Cannot use --verbose and --quiet at the same time.")


# ---------------------------------------------------------------------------
# PG COMMAND GROUP
# ---------------------------------------------------------------------------


@cli.group(help="Work with Parameter Group presets (list/show/diff/export).")
def pg() -> None:
    pass


@pg.command("list", help="List all available Parameter Group presets.")
@pass_context
def pg_list(ctx: CLIContext) -> None:
    if pg_engine is None:
        raise click.ClickException("PG engine is not available (import failed).")

    presets = pg_engine.list_presets(context=ctx)  # type: ignore[attr-defined]
    # Erwartet wird hier eine Liste von Namen/Objekten; Formatierung ist vereinfachbar
    for name in presets:
        click.echo(name)


@pg.command("show", help="Show details of a Parameter Group preset.")
@click.argument("preset", metavar="PRESET")
@pass_context
def pg_show(ctx: CLIContext, preset: str) -> None:
    if pg_engine is None:
        raise click.ClickException("PG engine is not available (import failed).")

    result = pg_engine.show_preset(preset, context=ctx)  # type: ignore[attr-defined]

    # Die Engine könnte z.B. dict zurückgeben; fürs erste einfach ausgeben:
    if isinstance(result, dict):
        if ctx.output_format == "json":
            import json

            click.echo(json.dumps(result, indent=2, sort_keys=True))
        else:
            # primitive table-artige Ausgabe
            for k, v in result.items():
                click.echo(f"{k}: {v}")
    else:
        click.echo(result)


@pg.command("diff", help="Diff two Parameter Group presets.")
@click.argument("preset_a", metavar="PRESET_A")
@click.argument("preset_b", metavar="PRESET_B")
@pass_context
def pg_diff(ctx: CLIContext, preset_a: str, preset_b: str) -> None:
    if pg_engine is None:
        raise click.ClickException("PG engine is not available (import failed).")

    diff_result = pg_engine.diff_presets(preset_a, preset_b, context=ctx)  # type: ignore[attr-defined]

    # Erwartet: Liste/Struktur von Differenzen
    if not diff_result:
        click.echo("No differences.")
        return

    if ctx.output_format == "json":
        import json

        click.echo(json.dumps(diff_result, indent=2, sort_keys=True))
    else:
        for line in diff_result:
            click.echo(line)


@pg.command("export", help="Export a preset to a target format (e.g. aws).")
@click.argument("target", type=click.Choice(["aws"], case_sensitive=False))
@click.argument("preset", metavar="PRESET")
@click.option(
    "--out",
    "-o",
    "out_file",
    metavar="FILE",
    required=True,
    help="Output file to write.",
)
@pass_context
def pg_export(ctx: CLIContext, target: str, preset: str, out_file: str) -> None:
    if pg_engine is None:
        raise click.ClickException("PG engine is not available (import failed).")

    export_data = pg_engine.export_preset(target.lower(), preset, context=ctx)  # type: ignore[attr-defined]

    import json
    from pathlib import Path

    path = Path(out_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(export_data, indent=2, sort_keys=True), encoding="utf-8")

    if not ctx.quiet:
        click.echo(f"Exported preset '{preset}' as '{target}' to {path}")


# ---------------------------------------------------------------------------
# PLAN COMMAND GROUP
# ---------------------------------------------------------------------------


@cli.group(help="Planning engine: generate and validate deployment plans.")
def plan() -> None:
    pass


@plan.command("generate", help="Generate a deployment plan from configuration.")
@click.option(
    "--config",
    "-c",
    "config_file",
    metavar="FILE",
    required=True,
    help="Configuration file (.env, .yaml, .yml, .json).",
)
@click.option(
    "--out",
    "-o",
    "out_file",
    metavar="FILE",
    required=True,
    help="Output plan JSON file.",
)
@pass_context
def plan_generate(ctx: CLIContext, config_file: str, out_file: str) -> None:
    if planning_engine is None:
        raise click.ClickException("Planning engine is not available (import failed).")

    from pathlib import Path

    plan_obj = planning_engine.generate_plan(  # type: ignore[attr-defined]
        config_path=config_file,
        context=ctx,
    )

    path = Path(out_file)
    path.parent.mkdir(parents=True, exist_ok=True)

    import json

    path.write_text(json.dumps(plan_obj, indent=2, sort_keys=True), encoding="utf-8")

    if not ctx.quiet:
        click.echo(f"Plan written to {path}")


@plan.command("validate", help="Validate a plan and configuration against AWS (read-only).")
@click.option(
    "--config",
    "-c",
    "config_file",
    metavar="FILE",
    required=True,
    help="Configuration file (.env, .yaml, .yml, .json).",
)
@click.option(
    "--plan",
    "-p",
    "plan_file",
    metavar="FILE",
    required=True,
    help="Plan JSON file generated by 'plan generate'.",
)
@pass_context
def plan_validate(ctx: CLIContext, config_file: str, plan_file: str) -> None:
    if planning_engine is None:
        raise click.ClickException("Planning engine is not available (import failed).")

    from pathlib import Path
    import json

    path = Path(plan_file)
    if not path.is_file():
        raise click.ClickException(f"Plan file not found: {plan_file}")

    plan_data = json.loads(path.read_text(encoding="utf-8"))

    result = planning_engine.validate_plan(  # type: ignore[attr-defined]
        config_path=config_file,
        plan=plan_data,
        context=ctx,
    )

    # result könnte bool, dict oder ein Objekt mit Fehlerliste sein.
    # Minimal: Exit-Code anhand des Ergebnisses.
    if isinstance(result, bool):
        if result:
            if not ctx.quiet:
                click.echo("Plan is valid.")
        else:
            raise click.ClickException("Plan validation failed.")
    else:
        # Falls komplexere Struktur: je nach Format ausgeben
        if ctx.output_format == "json":
            click.echo(json.dumps(result, indent=2, sort_keys=True))
        else:
            click.echo("Validation result:")
            click.echo(result)


# ---------------------------------------------------------------------------
# READINESS COMMAND GROUP
# ---------------------------------------------------------------------------


@cli.group(help="Readiness engine: Oracle → PostgreSQL migration analysis.")
def readiness() -> None:
    pass


@readiness.command("check", help="Run readiness checks and print summary to stdout.")
@click.option(
    "--source",
    "-s",
    "source_file",
    metavar="FILE",
    required=True,
    help="Oracle DDL file to analyze.",
)
@pass_context
def readiness_check(ctx: CLIContext, source_file: str) -> None:
    if readiness_engine is None:
        raise click.ClickException("Readiness engine is not available (import failed).")

    findings = readiness_engine.run_check(  # type: ignore[attr-defined]
        ddl_path=source_file,
        context=ctx,
        output_format=ctx.output_format,
    )

    # Erwartet: string / list / dict
    if isinstance(findings, str):
        click.echo(findings)
    elif isinstance(findings, dict):
        import json

        if ctx.output_format == "json":
            click.echo(json.dumps(findings, indent=2, sort_keys=True))
        else:
            for k, v in findings.items():
                click.echo(f"{k}: {v}")
    else:
        for line in findings:
            click.echo(line)


@readiness.command(
    "report",
    help="Generate an HTML readiness report from an Oracle DDL file.",
)
@click.option(
    "--source",
    "-s",
    "source_file",
    metavar="FILE",
    required=True,
    help="Oracle DDL file to analyze.",
)
@click.option(
    "--out",
    "-o",
    "out_file",
    metavar="FILE",
    required=True,
    help="Output HTML report file.",
)
@pass_context
def readiness_report(ctx: CLIContext, source_file: str, out_file: str) -> None:
    if readiness_engine is None:
        raise click.ClickException("Readiness engine is not available (import failed).")

    from pathlib import Path

    Path(out_file).parent.mkdir(parents=True, exist_ok=True)

    readiness_engine.write_html_report(  # type: ignore[attr-defined]
        ddl_path=source_file,
        out_path=out_file,
        context=ctx,
    )

    if not ctx.quiet:
        click.echo(f"Readiness report written to {out_file}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Console script entry point."""
    cli(obj=CLIContext())


# Backwards compatibility:
# Some tests and older code import `app` from cli.main.
# We expose `app` as an alias to the click CLI group.
app = cli

if __name__ == "__main__":
    main()
