# coding=utf-8


anne_ban = "https://sb.trygek.com/"
"""anne电信服网址，sourceban++"""
anne_ser = f"{anne_ban}l4d_stats/"
AnneRankApi = f"{anne_ser}ranking/index.php?type=coop"
AnnePlayerApi = f"{anne_ser}ranking/player.php?steamid="
# post
AnneSearchApi = f"{anne_ser}/ranking/search.php"

WorkshopApi = "https://steamworkshopdownloader.io/api/details/file"
