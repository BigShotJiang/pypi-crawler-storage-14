| Data                 | Source                                                                                                                     |
|----------------------|----------------------------------------------------------------------------------------------------------------------------|
| Blocks 2000          | https://www2.census.gov/geo/tiger/TIGER2010/TABBLOCK/2000/                                                                 |
| Blocks 2010          | https://www2.census.gov/geo/tiger/TIGER2018/TABBLOCK/                                                                      |
| Tracts 1990          | https://www2.census.gov/geo/tiger/PREVGENZ/tr/tr90shp/                                                                     |
| Tracts 2000          | https://www2.census.gov/geo/tiger/PREVGENZ/tr/tr00shp/                                                                     |
| Tracts 2010          | https://www2.census.gov/geo/tiger/TIGER2018/TRACT/                                                                         |
| MSA Definitions      | https://www2.census.gov/programs-surveys/metro-micro/geographies/reference-files/2018/delineation-files/list1_Sep_2018.xls |
| Inflation Adjustment | https://www.bls.gov/cpi/research-series/allitems.xlsx                                                                      |
