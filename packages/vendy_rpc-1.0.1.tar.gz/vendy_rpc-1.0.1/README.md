# Vendy RPC Modules

Discord RPC 모듈 - WebSocket을 통한 RPC 관리

## 설치

```bash
pip install vendy-rpc
```
## 사용법

### 기본 사용

```python
from Vendy_RPC_modules import RPCManager, RPCConfig, RPCUser

# 설정
CONFIG: RPCConfig = {
    "RESTART_INTERVAL_MS": 10 * 60 * 1000,  # 10분
    "STATUS_CHECK_INTERVAL_MS": 60 * 1000,  # 1분
    "LOGIN_RETRIES": 3,
    "LOGIN_RETRY_DELAY_MS": 5000,
}

# 사용자 데이터
USERS: list[RPCUser] = [
    {
        "userID": "YOUR_USER_ID",
        "token": "YOUR_DISCORD_TOKEN",
        "name": "사용자 이름",
        "type": "PLAYING",
        "state": "상태 텍스트",
        "details": "상세 정보",
        "large_image": "",
        "largete": "",
        "small_image": "",
        "smallte": "",
        "button1": "",
        "button1link": "",
        "button2": "",
        "button2link": "",
    },
]

# 실행
if __name__ == "__main__":
    manager = RPCManager(config=CONFIG, users=USERS)
    manager.run()
```



## 기능

- WebSocket을 통한  RPC
- 여러 클라이언트 동시 관리
- 자동 재시작 기능
- 상태 확인 루프
- 로그인 재시도 로직


## 요구사항

- Python 3.7 이상
- websocket-client >= 1.6.0

## 라이선스

MIT License

## 기여

이슈 및 풀 리퀘스트를 환영합니다!

