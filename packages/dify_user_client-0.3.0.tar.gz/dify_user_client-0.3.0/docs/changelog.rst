Changelog
=========

All notable changes to dify_user_client will be documented in this file.

[0.0.5] - 2025-04-17
--------------------

Added
~~~~~
- Initial public release
- Support for multiple app types (chat, completion, workflow, agent)
- Knowledge base management
- LLM integration
- Token management
- Workflow tools
- Type safety with Pydantic models

Changed
~~~~~~~
- None (initial release)

Deprecated
~~~~~~~~~~
- None

Removed
~~~~~~~
- None

Fixed
~~~~~
- None

Security
~~~~~~~~
- Initial security features implementation 