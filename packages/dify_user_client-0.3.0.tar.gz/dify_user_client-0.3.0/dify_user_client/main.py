def main():
    print("Hello from dify-utils!")


if __name__ == "__main__":
    main()
