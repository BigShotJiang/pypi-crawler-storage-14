from uiauth.enums import APIEndpoints, APIMethods  # noqa: F401,E402
from uiauth.models import Parameters  # noqa: F401,E402
from uiauth.service import FastAPIUIAuth  # noqa: F401,E402
from uiauth.version import version  # noqa: F401,E402

protect = FastAPIUIAuth
