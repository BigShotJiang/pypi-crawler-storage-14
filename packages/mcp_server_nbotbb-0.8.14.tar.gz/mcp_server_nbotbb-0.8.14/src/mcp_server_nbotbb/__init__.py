import os
from dotenv import load_dotenv  
import mysql.connector
from mysql.connector import Error
import json
from typing import Any, Dict, List, Sequence
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
import asyncio

load_dotenv()


sql_config = {
    'host': os.getenv('DB_HOST'),
    'port': int(os.getenv('DB_PORT', 3306)),  # 默认 3306
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME'),
    'charset': os.getenv('DB_CHARSET', 'utf8mb4'),
    'ssl_disabled': True,
}
print(sql_config)
def get_views_buys(prod_id):
    connection = None
    cursor = None
    try:
        required = ['host', 'user', 'password', 'database']
        for key in required:
            if not sql_config[key]:
                raise ValueError(f"环境变量 DB_{key.upper()} 未设置")

        connection = mysql.connector.connect(**sql_config)
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT views, buys FROM ls_prod WHERE prod_id = %s", (prod_id,))
        return cursor.fetchone()

    except Error as e:
        print(f"MySQL 错误: {e}")
        return {"error": "Database query failed", "details": str(e)}
    except Exception as e:
        print(f"配置错误: {e}")
        return {"error": "Database query failed", "details": str(e)}
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

# ========== MCP Server ==========
async def serve() -> None:
    server = Server("nbotbb-agro-mcp")
    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="get_views_buys",
                description="帮助用户查询指定prod_id的浏览数量和购买数量",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "prod_id": {
                            "type": "integer",
                            "description": "产品ID，例如：10655"
                        },
                    },
                    "required": ["prod_id"],
                    "additionalProperties": False
                }
            )
        ]
            
            
    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> Sequence[TextContent]:
        try:
            if name == "get_views_buys":
                prod_id = arguments.get("prod_id")
                if not isinstance(prod_id, int):
                    # 尝试转换（兼容字符串数字）
                    try:
                        prod_id = int(prod_id)
                    except (TypeError, ValueError):
                        raise ValueError("prod_id must be an integer")

                res = get_views_buys(prod_id)
                # 统一返回格式
                if res is None or "error" in res:
                    output = {"success": False, "data": None, "error": res.get("error", "Product not found")}
                else:
                    output = {"success": True, "data": res}
            else:
                raise ValueError(f"Unknown tool: {name}")

            return [TextContent(type="text", text=json.dumps(output, ensure_ascii=False))]
        except Exception as e:
            return [TextContent(type="text", text=json.dumps({"message": "Error", "error": str(e)}, ensure_ascii=False))]
            

    options = server.create_initialization_options()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, options)
def main():
    asyncio.run(serve())


if __name__ == "__main__":
    main()
