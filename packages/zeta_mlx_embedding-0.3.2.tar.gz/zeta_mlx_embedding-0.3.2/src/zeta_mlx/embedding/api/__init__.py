"""Embedding API 모듈"""
from zeta_mlx.embedding.api.app import create_app, create_app_with_engine

__all__ = ["create_app", "create_app_with_engine"]
