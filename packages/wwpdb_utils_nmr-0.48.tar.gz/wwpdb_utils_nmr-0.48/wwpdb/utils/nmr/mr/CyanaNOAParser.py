# Generated from CyanaNOAParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,73,212,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,1,0,1,0,1,0,1,0,5,
        0,29,8,0,10,0,12,0,32,9,0,1,0,1,0,1,1,1,1,5,1,38,8,1,10,1,12,1,41,
        9,1,1,1,1,1,1,2,1,2,1,2,3,2,48,8,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,
        3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,64,8,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,1,5,4,5,80,8,5,11,5,12,5,81,1,5,1,5,1,5,
        1,5,1,5,3,5,89,8,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,
        7,1,7,1,7,1,7,3,7,106,8,7,1,7,3,7,109,8,7,1,8,1,8,3,8,113,8,8,1,
        9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,
        9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,5,9,139,8,9,10,9,12,9,142,9,9,1,10,
        1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,11,1,11,1,11,1,11,1,11,1,11,
        1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,3,11,166,8,11,1,11,1,11,
        1,11,1,11,3,11,172,8,11,1,11,1,11,1,11,1,11,1,11,1,11,3,11,180,8,
        11,1,11,1,11,1,11,1,11,3,11,186,8,11,1,11,1,11,1,11,1,11,1,11,1,
        11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,
        11,1,11,1,11,1,11,1,11,1,11,1,11,0,0,12,0,2,4,6,8,10,12,14,16,18,
        20,22,0,6,1,1,73,73,1,0,4,5,1,0,53,54,1,0,10,13,2,0,54,54,57,57,
        1,0,59,62,217,0,30,1,0,0,0,2,35,1,0,0,0,4,44,1,0,0,0,6,49,1,0,0,
        0,8,68,1,0,0,0,10,79,1,0,0,0,12,90,1,0,0,0,14,101,1,0,0,0,16,110,
        1,0,0,0,18,114,1,0,0,0,20,143,1,0,0,0,22,151,1,0,0,0,24,29,3,2,1,
        0,25,29,3,4,2,0,26,29,3,18,9,0,27,29,3,22,11,0,28,24,1,0,0,0,28,
        25,1,0,0,0,28,26,1,0,0,0,28,27,1,0,0,0,29,32,1,0,0,0,30,28,1,0,0,
        0,30,31,1,0,0,0,31,33,1,0,0,0,32,30,1,0,0,0,33,34,5,0,0,1,34,1,1,
        0,0,0,35,39,5,63,0,0,36,38,5,71,0,0,37,36,1,0,0,0,38,41,1,0,0,0,
        39,37,1,0,0,0,39,40,1,0,0,0,40,42,1,0,0,0,41,39,1,0,0,0,42,43,7,
        0,0,0,43,3,1,0,0,0,44,45,3,6,3,0,45,47,3,8,4,0,46,48,3,10,5,0,47,
        46,1,0,0,0,47,48,1,0,0,0,48,5,1,0,0,0,49,50,5,1,0,0,50,51,5,57,0,
        0,51,52,5,2,0,0,52,53,5,69,0,0,53,54,5,47,0,0,54,55,5,58,0,0,55,
        56,5,51,0,0,56,57,5,58,0,0,57,63,5,3,0,0,58,64,5,56,0,0,59,60,5,
        56,0,0,60,61,7,1,0,0,61,64,5,56,0,0,62,64,5,6,0,0,63,58,1,0,0,0,
        63,59,1,0,0,0,63,62,1,0,0,0,64,65,1,0,0,0,65,66,5,48,0,0,66,67,5,
        49,0,0,67,7,1,0,0,0,68,69,5,57,0,0,69,70,5,7,0,0,70,71,5,57,0,0,
        71,72,5,8,0,0,72,73,5,51,0,0,73,74,5,9,0,0,74,75,5,52,0,0,75,76,
        5,58,0,0,76,77,5,49,0,0,77,9,1,0,0,0,78,80,3,12,6,0,79,78,1,0,0,
        0,80,81,1,0,0,0,81,79,1,0,0,0,81,82,1,0,0,0,82,88,1,0,0,0,83,84,
        5,15,0,0,84,85,5,57,0,0,85,86,5,16,0,0,86,87,5,56,0,0,87,89,5,50,
        0,0,88,83,1,0,0,0,88,89,1,0,0,0,89,11,1,0,0,0,90,91,5,64,0,0,91,
        92,5,64,0,0,92,93,5,57,0,0,93,94,7,2,0,0,94,95,5,64,0,0,95,96,5,
        64,0,0,96,97,5,57,0,0,97,98,7,3,0,0,98,99,5,57,0,0,99,100,3,14,7,
        0,100,13,1,0,0,0,101,102,5,57,0,0,102,103,7,4,0,0,103,105,7,4,0,
        0,104,106,5,14,0,0,105,104,1,0,0,0,105,106,1,0,0,0,106,108,1,0,0,
        0,107,109,3,16,8,0,108,107,1,0,0,0,108,109,1,0,0,0,109,15,1,0,0,
        0,110,112,7,5,0,0,111,113,3,16,8,0,112,111,1,0,0,0,112,113,1,0,0,
        0,113,17,1,0,0,0,114,115,5,17,0,0,115,116,5,49,0,0,116,117,5,58,
        0,0,117,118,5,18,0,0,118,119,5,49,0,0,119,120,5,58,0,0,120,121,5,
        19,0,0,121,122,5,49,0,0,122,123,5,57,0,0,123,124,5,20,0,0,124,125,
        5,49,0,0,125,126,5,57,0,0,126,127,5,21,0,0,127,128,5,49,0,0,128,
        129,5,22,0,0,129,130,5,49,0,0,130,131,5,56,0,0,131,132,5,23,0,0,
        132,133,5,24,0,0,133,134,5,26,0,0,134,135,5,25,0,0,135,136,5,27,
        0,0,136,140,5,28,0,0,137,139,3,20,10,0,138,137,1,0,0,0,139,142,1,
        0,0,0,140,138,1,0,0,0,140,141,1,0,0,0,141,19,1,0,0,0,142,140,1,0,
        0,0,143,144,5,64,0,0,144,145,5,64,0,0,145,146,5,57,0,0,146,147,5,
        58,0,0,147,148,5,57,0,0,148,149,5,57,0,0,149,150,5,57,0,0,150,21,
        1,0,0,0,151,152,5,25,0,0,152,153,5,49,0,0,153,154,5,29,0,0,154,155,
        5,49,0,0,155,156,5,57,0,0,156,157,5,30,0,0,157,158,5,49,0,0,158,
        159,5,57,0,0,159,160,5,31,0,0,160,161,5,49,0,0,161,165,5,57,0,0,
        162,163,5,32,0,0,163,164,5,49,0,0,164,166,5,57,0,0,165,162,1,0,0,
        0,165,166,1,0,0,0,166,171,1,0,0,0,167,168,5,33,0,0,168,169,5,56,
        0,0,169,170,5,49,0,0,170,172,5,57,0,0,171,167,1,0,0,0,171,172,1,
        0,0,0,172,179,1,0,0,0,173,174,5,34,0,0,174,175,5,58,0,0,175,176,
        5,37,0,0,176,177,5,56,0,0,177,178,5,49,0,0,178,180,5,57,0,0,179,
        173,1,0,0,0,179,180,1,0,0,0,180,185,1,0,0,0,181,182,5,35,0,0,182,
        183,5,56,0,0,183,184,5,49,0,0,184,186,5,57,0,0,185,181,1,0,0,0,185,
        186,1,0,0,0,186,187,1,0,0,0,187,188,5,36,0,0,188,189,5,49,0,0,189,
        190,5,57,0,0,190,191,5,38,0,0,191,192,5,49,0,0,192,193,5,39,0,0,
        193,194,5,49,0,0,194,195,5,57,0,0,195,196,5,40,0,0,196,197,5,49,
        0,0,197,198,5,57,0,0,198,199,5,41,0,0,199,200,5,44,0,0,200,201,5,
        49,0,0,201,202,5,57,0,0,202,203,5,42,0,0,203,204,5,45,0,0,204,205,
        5,49,0,0,205,206,5,57,0,0,206,207,5,43,0,0,207,208,5,46,0,0,208,
        209,5,49,0,0,209,210,5,57,0,0,210,23,1,0,0,0,15,28,30,39,47,63,81,
        88,105,108,112,140,165,171,179,185
    ]

class CyanaNOAParser ( Parser ):

    grammarFileName = "CyanaNOAParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'|i-j|'", "'from'", "'ppm;'", "'increased from'", 
                     "'|i-j|'", "'diagonal'", "'out of'", "<INVALID>", "'quality'", 
                     "'OK'", "'lone'", "'poor'", "'far'", "<INVALID>", "'Violated in'", 
                     "'structures by'", "'Average quality of peak assignments'", 
                     "'Average number of used assignments'", "'Peaks with increased upper limit'", 
                     "'Peaks with decreased upper limit'", "'Protons used in less than 30% of expected peaks'", 
                     "'Peak observation distance'", "'Atom'", "'Residue'", 
                     "'Peaks'", "'Shift'", "'Used'", "'Expect'", "'selected'", 
                     "'assigned'", "'unassigned'", "'without assignment possibility'", 
                     "'with violation below'", "'with violation between'", 
                     "'with violation above'", "'with diagonal assignment'", 
                     "'and'", "'Cross peaks'", "'with off-diagonal assignment'", 
                     "'with unique assignment'", "'with short-range assignment'", 
                     "'with medium-range assignment'", "'with long-range assignment'", 
                     "<INVALID>", "'1<|i-j|<5'", "<INVALID>", "'('", "')'", 
                     "':'", "'.'", "','", "'='", "'+'", "'-'", "'/'" ]

    symbolicNames = [ "<INVALID>", "Peak", "From", "Ppm_SC", "Increased_from", 
                      "Decreased_from", "Diagonal", "Out_of", "Assignments_used", 
                      "Quality", "Ok", "Lone", "Poor", "Far", "Distance_range", 
                      "Violated_in", "Structures_by", "Average_quality", 
                      "Average_number", "Peaks_inc_upl", "Peaks_dec_upl", 
                      "Protons_used_in_less", "Peak_obs_dist", "Atom", "Residue", 
                      "Peaks", "Shift", "Used", "Expect", "Selected", "Assigned", 
                      "Unassigned", "Without_possibility", "With_viol_below", 
                      "With_viol_between", "With_viol_above", "With_diagonal", 
                      "And", "Cross_peaks", "With_off_diagonal", "With_unique", 
                      "With_short_range", "With_medium_range", "With_long_range", 
                      "Short_range_ex", "Medium_range_ex", "Long_range_ex", 
                      "L_paren", "R_paren", "Colon", "Period", "Comma", 
                      "Equ_op", "Add_op", "Sub_op", "Div_op", "Angstrome", 
                      "Integer", "Float", "Numerical_report1", "Numerical_report2", 
                      "Numerical_report3", "Numerical_report4", "COMMENT", 
                      "Simple_name", "SPACE", "ENCLOSE_COMMENT", "SECTION_COMMENT", 
                      "LINE_COMMENT", "File_name", "SPACE_FN", "Any_name", 
                      "SPACE_CM", "RETURN_CM" ]

    RULE_cyana_noa = 0
    RULE_comment = 1
    RULE_noe_peaks = 2
    RULE_peak_header = 3
    RULE_peak_quality = 4
    RULE_noe_assignments = 5
    RULE_noe_assignment = 6
    RULE_numerical_report = 7
    RULE_extended_report = 8
    RULE_noe_stat = 9
    RULE_list_of_proton = 10
    RULE_peak_stat = 11

    ruleNames =  [ "cyana_noa", "comment", "noe_peaks", "peak_header", "peak_quality", 
                   "noe_assignments", "noe_assignment", "numerical_report", 
                   "extended_report", "noe_stat", "list_of_proton", "peak_stat" ]

    EOF = Token.EOF
    Peak=1
    From=2
    Ppm_SC=3
    Increased_from=4
    Decreased_from=5
    Diagonal=6
    Out_of=7
    Assignments_used=8
    Quality=9
    Ok=10
    Lone=11
    Poor=12
    Far=13
    Distance_range=14
    Violated_in=15
    Structures_by=16
    Average_quality=17
    Average_number=18
    Peaks_inc_upl=19
    Peaks_dec_upl=20
    Protons_used_in_less=21
    Peak_obs_dist=22
    Atom=23
    Residue=24
    Peaks=25
    Shift=26
    Used=27
    Expect=28
    Selected=29
    Assigned=30
    Unassigned=31
    Without_possibility=32
    With_viol_below=33
    With_viol_between=34
    With_viol_above=35
    With_diagonal=36
    And=37
    Cross_peaks=38
    With_off_diagonal=39
    With_unique=40
    With_short_range=41
    With_medium_range=42
    With_long_range=43
    Short_range_ex=44
    Medium_range_ex=45
    Long_range_ex=46
    L_paren=47
    R_paren=48
    Colon=49
    Period=50
    Comma=51
    Equ_op=52
    Add_op=53
    Sub_op=54
    Div_op=55
    Angstrome=56
    Integer=57
    Float=58
    Numerical_report1=59
    Numerical_report2=60
    Numerical_report3=61
    Numerical_report4=62
    COMMENT=63
    Simple_name=64
    SPACE=65
    ENCLOSE_COMMENT=66
    SECTION_COMMENT=67
    LINE_COMMENT=68
    File_name=69
    SPACE_FN=70
    Any_name=71
    SPACE_CM=72
    RETURN_CM=73

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Cyana_noaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CyanaNOAParser.EOF, 0)

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaNOAParser.CommentContext)
            else:
                return self.getTypedRuleContext(CyanaNOAParser.CommentContext,i)


        def noe_peaks(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaNOAParser.Noe_peaksContext)
            else:
                return self.getTypedRuleContext(CyanaNOAParser.Noe_peaksContext,i)


        def noe_stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaNOAParser.Noe_statContext)
            else:
                return self.getTypedRuleContext(CyanaNOAParser.Noe_statContext,i)


        def peak_stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaNOAParser.Peak_statContext)
            else:
                return self.getTypedRuleContext(CyanaNOAParser.Peak_statContext,i)


        def getRuleIndex(self):
            return CyanaNOAParser.RULE_cyana_noa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCyana_noa" ):
                listener.enterCyana_noa(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCyana_noa" ):
                listener.exitCyana_noa(self)




    def cyana_noa(self):

        localctx = CyanaNOAParser.Cyana_noaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_cyana_noa)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 30
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & -9223372036821090302) != 0):
                self.state = 28
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [63]:
                    self.state = 24
                    self.comment()
                    pass
                elif token in [1]:
                    self.state = 25
                    self.noe_peaks()
                    pass
                elif token in [17]:
                    self.state = 26
                    self.noe_stat()
                    pass
                elif token in [25]:
                    self.state = 27
                    self.peak_stat()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 32
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 33
            self.match(CyanaNOAParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(CyanaNOAParser.COMMENT, 0)

        def RETURN_CM(self):
            return self.getToken(CyanaNOAParser.RETURN_CM, 0)

        def EOF(self):
            return self.getToken(CyanaNOAParser.EOF, 0)

        def Any_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Any_name)
            else:
                return self.getToken(CyanaNOAParser.Any_name, i)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = CyanaNOAParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35
            self.match(CyanaNOAParser.COMMENT)
            self.state = 39
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==71:
                self.state = 36
                self.match(CyanaNOAParser.Any_name)
                self.state = 41
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 42
            _la = self._input.LA(1)
            if not(_la==-1 or _la==73):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Noe_peaksContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def peak_header(self):
            return self.getTypedRuleContext(CyanaNOAParser.Peak_headerContext,0)


        def peak_quality(self):
            return self.getTypedRuleContext(CyanaNOAParser.Peak_qualityContext,0)


        def noe_assignments(self):
            return self.getTypedRuleContext(CyanaNOAParser.Noe_assignmentsContext,0)


        def getRuleIndex(self):
            return CyanaNOAParser.RULE_noe_peaks

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNoe_peaks" ):
                listener.enterNoe_peaks(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNoe_peaks" ):
                listener.exitNoe_peaks(self)




    def noe_peaks(self):

        localctx = CyanaNOAParser.Noe_peaksContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_noe_peaks)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 44
            self.peak_header()
            self.state = 45
            self.peak_quality()
            self.state = 47
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==64:
                self.state = 46
                self.noe_assignments()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Peak(self):
            return self.getToken(CyanaNOAParser.Peak, 0)

        def Integer(self):
            return self.getToken(CyanaNOAParser.Integer, 0)

        def From(self):
            return self.getToken(CyanaNOAParser.From, 0)

        def File_name(self):
            return self.getToken(CyanaNOAParser.File_name, 0)

        def L_paren(self):
            return self.getToken(CyanaNOAParser.L_paren, 0)

        def Float(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Float)
            else:
                return self.getToken(CyanaNOAParser.Float, i)

        def Comma(self):
            return self.getToken(CyanaNOAParser.Comma, 0)

        def Ppm_SC(self):
            return self.getToken(CyanaNOAParser.Ppm_SC, 0)

        def R_paren(self):
            return self.getToken(CyanaNOAParser.R_paren, 0)

        def Colon(self):
            return self.getToken(CyanaNOAParser.Colon, 0)

        def Angstrome(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Angstrome)
            else:
                return self.getToken(CyanaNOAParser.Angstrome, i)

        def Diagonal(self):
            return self.getToken(CyanaNOAParser.Diagonal, 0)

        def Increased_from(self):
            return self.getToken(CyanaNOAParser.Increased_from, 0)

        def Decreased_from(self):
            return self.getToken(CyanaNOAParser.Decreased_from, 0)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_peak_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_header" ):
                listener.enterPeak_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_header" ):
                listener.exitPeak_header(self)




    def peak_header(self):

        localctx = CyanaNOAParser.Peak_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_peak_header)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 49
            self.match(CyanaNOAParser.Peak)
            self.state = 50
            self.match(CyanaNOAParser.Integer)
            self.state = 51
            self.match(CyanaNOAParser.From)
            self.state = 52
            self.match(CyanaNOAParser.File_name)
            self.state = 53
            self.match(CyanaNOAParser.L_paren)
            self.state = 54
            self.match(CyanaNOAParser.Float)
            self.state = 55
            self.match(CyanaNOAParser.Comma)
            self.state = 56
            self.match(CyanaNOAParser.Float)
            self.state = 57
            self.match(CyanaNOAParser.Ppm_SC)
            self.state = 63
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.state = 58
                self.match(CyanaNOAParser.Angstrome)
                pass

            elif la_ == 2:
                self.state = 59
                self.match(CyanaNOAParser.Angstrome)
                self.state = 60
                _la = self._input.LA(1)
                if not(_la==4 or _la==5):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 61
                self.match(CyanaNOAParser.Angstrome)
                pass

            elif la_ == 3:
                self.state = 62
                self.match(CyanaNOAParser.Diagonal)
                pass


            self.state = 65
            self.match(CyanaNOAParser.R_paren)
            self.state = 66
            self.match(CyanaNOAParser.Colon)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_qualityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Integer)
            else:
                return self.getToken(CyanaNOAParser.Integer, i)

        def Out_of(self):
            return self.getToken(CyanaNOAParser.Out_of, 0)

        def Assignments_used(self):
            return self.getToken(CyanaNOAParser.Assignments_used, 0)

        def Comma(self):
            return self.getToken(CyanaNOAParser.Comma, 0)

        def Quality(self):
            return self.getToken(CyanaNOAParser.Quality, 0)

        def Equ_op(self):
            return self.getToken(CyanaNOAParser.Equ_op, 0)

        def Float(self):
            return self.getToken(CyanaNOAParser.Float, 0)

        def Colon(self):
            return self.getToken(CyanaNOAParser.Colon, 0)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_peak_quality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_quality" ):
                listener.enterPeak_quality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_quality" ):
                listener.exitPeak_quality(self)




    def peak_quality(self):

        localctx = CyanaNOAParser.Peak_qualityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_peak_quality)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 68
            self.match(CyanaNOAParser.Integer)
            self.state = 69
            self.match(CyanaNOAParser.Out_of)
            self.state = 70
            self.match(CyanaNOAParser.Integer)
            self.state = 71
            self.match(CyanaNOAParser.Assignments_used)
            self.state = 72
            self.match(CyanaNOAParser.Comma)
            self.state = 73
            self.match(CyanaNOAParser.Quality)
            self.state = 74
            self.match(CyanaNOAParser.Equ_op)
            self.state = 75
            self.match(CyanaNOAParser.Float)
            self.state = 76
            self.match(CyanaNOAParser.Colon)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Noe_assignmentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def noe_assignment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaNOAParser.Noe_assignmentContext)
            else:
                return self.getTypedRuleContext(CyanaNOAParser.Noe_assignmentContext,i)


        def Violated_in(self):
            return self.getToken(CyanaNOAParser.Violated_in, 0)

        def Integer(self):
            return self.getToken(CyanaNOAParser.Integer, 0)

        def Structures_by(self):
            return self.getToken(CyanaNOAParser.Structures_by, 0)

        def Angstrome(self):
            return self.getToken(CyanaNOAParser.Angstrome, 0)

        def Period(self):
            return self.getToken(CyanaNOAParser.Period, 0)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_noe_assignments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNoe_assignments" ):
                listener.enterNoe_assignments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNoe_assignments" ):
                listener.exitNoe_assignments(self)




    def noe_assignments(self):

        localctx = CyanaNOAParser.Noe_assignmentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_noe_assignments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 78
                self.noe_assignment()
                self.state = 81 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==64):
                    break

            self.state = 88
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==15:
                self.state = 83
                self.match(CyanaNOAParser.Violated_in)
                self.state = 84
                self.match(CyanaNOAParser.Integer)
                self.state = 85
                self.match(CyanaNOAParser.Structures_by)
                self.state = 86
                self.match(CyanaNOAParser.Angstrome)
                self.state = 87
                self.match(CyanaNOAParser.Period)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Noe_assignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Simple_name)
            else:
                return self.getToken(CyanaNOAParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Integer)
            else:
                return self.getToken(CyanaNOAParser.Integer, i)

        def numerical_report(self):
            return self.getTypedRuleContext(CyanaNOAParser.Numerical_reportContext,0)


        def Add_op(self):
            return self.getToken(CyanaNOAParser.Add_op, 0)

        def Sub_op(self):
            return self.getToken(CyanaNOAParser.Sub_op, 0)

        def Ok(self):
            return self.getToken(CyanaNOAParser.Ok, 0)

        def Lone(self):
            return self.getToken(CyanaNOAParser.Lone, 0)

        def Poor(self):
            return self.getToken(CyanaNOAParser.Poor, 0)

        def Far(self):
            return self.getToken(CyanaNOAParser.Far, 0)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_noe_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNoe_assignment" ):
                listener.enterNoe_assignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNoe_assignment" ):
                listener.exitNoe_assignment(self)




    def noe_assignment(self):

        localctx = CyanaNOAParser.Noe_assignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_noe_assignment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90
            self.match(CyanaNOAParser.Simple_name)
            self.state = 91
            self.match(CyanaNOAParser.Simple_name)
            self.state = 92
            self.match(CyanaNOAParser.Integer)
            self.state = 93
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 94
            self.match(CyanaNOAParser.Simple_name)
            self.state = 95
            self.match(CyanaNOAParser.Simple_name)
            self.state = 96
            self.match(CyanaNOAParser.Integer)
            self.state = 97
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 15360) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 98
            self.match(CyanaNOAParser.Integer)
            self.state = 99
            self.numerical_report()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Numerical_reportContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Integer)
            else:
                return self.getToken(CyanaNOAParser.Integer, i)

        def Sub_op(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Sub_op)
            else:
                return self.getToken(CyanaNOAParser.Sub_op, i)

        def Distance_range(self):
            return self.getToken(CyanaNOAParser.Distance_range, 0)

        def extended_report(self):
            return self.getTypedRuleContext(CyanaNOAParser.Extended_reportContext,0)


        def getRuleIndex(self):
            return CyanaNOAParser.RULE_numerical_report

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumerical_report" ):
                listener.enterNumerical_report(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumerical_report" ):
                listener.exitNumerical_report(self)




    def numerical_report(self):

        localctx = CyanaNOAParser.Numerical_reportContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_numerical_report)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self.match(CyanaNOAParser.Integer)
            self.state = 102
            _la = self._input.LA(1)
            if not(_la==54 or _la==57):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 103
            _la = self._input.LA(1)
            if not(_la==54 or _la==57):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 105
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 104
                self.match(CyanaNOAParser.Distance_range)


            self.state = 108
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8646911284551352320) != 0):
                self.state = 107
                self.extended_report()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Extended_reportContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Numerical_report1(self):
            return self.getToken(CyanaNOAParser.Numerical_report1, 0)

        def Numerical_report2(self):
            return self.getToken(CyanaNOAParser.Numerical_report2, 0)

        def Numerical_report3(self):
            return self.getToken(CyanaNOAParser.Numerical_report3, 0)

        def Numerical_report4(self):
            return self.getToken(CyanaNOAParser.Numerical_report4, 0)

        def extended_report(self):
            return self.getTypedRuleContext(CyanaNOAParser.Extended_reportContext,0)


        def getRuleIndex(self):
            return CyanaNOAParser.RULE_extended_report

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtended_report" ):
                listener.enterExtended_report(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtended_report" ):
                listener.exitExtended_report(self)




    def extended_report(self):

        localctx = CyanaNOAParser.Extended_reportContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_extended_report)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 8646911284551352320) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 112
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 8646911284551352320) != 0):
                self.state = 111
                self.extended_report()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Noe_statContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Average_quality(self):
            return self.getToken(CyanaNOAParser.Average_quality, 0)

        def Colon(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Colon)
            else:
                return self.getToken(CyanaNOAParser.Colon, i)

        def Float(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Float)
            else:
                return self.getToken(CyanaNOAParser.Float, i)

        def Average_number(self):
            return self.getToken(CyanaNOAParser.Average_number, 0)

        def Peaks_inc_upl(self):
            return self.getToken(CyanaNOAParser.Peaks_inc_upl, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Integer)
            else:
                return self.getToken(CyanaNOAParser.Integer, i)

        def Peaks_dec_upl(self):
            return self.getToken(CyanaNOAParser.Peaks_dec_upl, 0)

        def Protons_used_in_less(self):
            return self.getToken(CyanaNOAParser.Protons_used_in_less, 0)

        def Peak_obs_dist(self):
            return self.getToken(CyanaNOAParser.Peak_obs_dist, 0)

        def Angstrome(self):
            return self.getToken(CyanaNOAParser.Angstrome, 0)

        def Atom(self):
            return self.getToken(CyanaNOAParser.Atom, 0)

        def Residue(self):
            return self.getToken(CyanaNOAParser.Residue, 0)

        def Shift(self):
            return self.getToken(CyanaNOAParser.Shift, 0)

        def Peaks(self):
            return self.getToken(CyanaNOAParser.Peaks, 0)

        def Used(self):
            return self.getToken(CyanaNOAParser.Used, 0)

        def Expect(self):
            return self.getToken(CyanaNOAParser.Expect, 0)

        def list_of_proton(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CyanaNOAParser.List_of_protonContext)
            else:
                return self.getTypedRuleContext(CyanaNOAParser.List_of_protonContext,i)


        def getRuleIndex(self):
            return CyanaNOAParser.RULE_noe_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNoe_stat" ):
                listener.enterNoe_stat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNoe_stat" ):
                listener.exitNoe_stat(self)




    def noe_stat(self):

        localctx = CyanaNOAParser.Noe_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_noe_stat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 114
            self.match(CyanaNOAParser.Average_quality)
            self.state = 115
            self.match(CyanaNOAParser.Colon)
            self.state = 116
            self.match(CyanaNOAParser.Float)
            self.state = 117
            self.match(CyanaNOAParser.Average_number)
            self.state = 118
            self.match(CyanaNOAParser.Colon)
            self.state = 119
            self.match(CyanaNOAParser.Float)
            self.state = 120
            self.match(CyanaNOAParser.Peaks_inc_upl)
            self.state = 121
            self.match(CyanaNOAParser.Colon)
            self.state = 122
            self.match(CyanaNOAParser.Integer)
            self.state = 123
            self.match(CyanaNOAParser.Peaks_dec_upl)
            self.state = 124
            self.match(CyanaNOAParser.Colon)
            self.state = 125
            self.match(CyanaNOAParser.Integer)
            self.state = 126
            self.match(CyanaNOAParser.Protons_used_in_less)
            self.state = 127
            self.match(CyanaNOAParser.Colon)
            self.state = 128
            self.match(CyanaNOAParser.Peak_obs_dist)
            self.state = 129
            self.match(CyanaNOAParser.Colon)
            self.state = 130
            self.match(CyanaNOAParser.Angstrome)
            self.state = 131
            self.match(CyanaNOAParser.Atom)
            self.state = 132
            self.match(CyanaNOAParser.Residue)
            self.state = 133
            self.match(CyanaNOAParser.Shift)
            self.state = 134
            self.match(CyanaNOAParser.Peaks)
            self.state = 135
            self.match(CyanaNOAParser.Used)
            self.state = 136
            self.match(CyanaNOAParser.Expect)
            self.state = 140
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==64:
                self.state = 137
                self.list_of_proton()
                self.state = 142
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class List_of_protonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Simple_name)
            else:
                return self.getToken(CyanaNOAParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Integer)
            else:
                return self.getToken(CyanaNOAParser.Integer, i)

        def Float(self):
            return self.getToken(CyanaNOAParser.Float, 0)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_list_of_proton

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterList_of_proton" ):
                listener.enterList_of_proton(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitList_of_proton" ):
                listener.exitList_of_proton(self)




    def list_of_proton(self):

        localctx = CyanaNOAParser.List_of_protonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_list_of_proton)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 143
            self.match(CyanaNOAParser.Simple_name)
            self.state = 144
            self.match(CyanaNOAParser.Simple_name)
            self.state = 145
            self.match(CyanaNOAParser.Integer)
            self.state = 146
            self.match(CyanaNOAParser.Float)
            self.state = 147
            self.match(CyanaNOAParser.Integer)
            self.state = 148
            self.match(CyanaNOAParser.Integer)
            self.state = 149
            self.match(CyanaNOAParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Peak_statContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Peaks(self):
            return self.getToken(CyanaNOAParser.Peaks, 0)

        def Colon(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Colon)
            else:
                return self.getToken(CyanaNOAParser.Colon, i)

        def Selected(self):
            return self.getToken(CyanaNOAParser.Selected, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Integer)
            else:
                return self.getToken(CyanaNOAParser.Integer, i)

        def Assigned(self):
            return self.getToken(CyanaNOAParser.Assigned, 0)

        def Unassigned(self):
            return self.getToken(CyanaNOAParser.Unassigned, 0)

        def With_diagonal(self):
            return self.getToken(CyanaNOAParser.With_diagonal, 0)

        def Cross_peaks(self):
            return self.getToken(CyanaNOAParser.Cross_peaks, 0)

        def With_off_diagonal(self):
            return self.getToken(CyanaNOAParser.With_off_diagonal, 0)

        def With_unique(self):
            return self.getToken(CyanaNOAParser.With_unique, 0)

        def With_short_range(self):
            return self.getToken(CyanaNOAParser.With_short_range, 0)

        def Short_range_ex(self):
            return self.getToken(CyanaNOAParser.Short_range_ex, 0)

        def With_medium_range(self):
            return self.getToken(CyanaNOAParser.With_medium_range, 0)

        def Medium_range_ex(self):
            return self.getToken(CyanaNOAParser.Medium_range_ex, 0)

        def With_long_range(self):
            return self.getToken(CyanaNOAParser.With_long_range, 0)

        def Long_range_ex(self):
            return self.getToken(CyanaNOAParser.Long_range_ex, 0)

        def Without_possibility(self):
            return self.getToken(CyanaNOAParser.Without_possibility, 0)

        def With_viol_below(self):
            return self.getToken(CyanaNOAParser.With_viol_below, 0)

        def Angstrome(self, i:int=None):
            if i is None:
                return self.getTokens(CyanaNOAParser.Angstrome)
            else:
                return self.getToken(CyanaNOAParser.Angstrome, i)

        def With_viol_between(self):
            return self.getToken(CyanaNOAParser.With_viol_between, 0)

        def Float(self):
            return self.getToken(CyanaNOAParser.Float, 0)

        def And(self):
            return self.getToken(CyanaNOAParser.And, 0)

        def With_viol_above(self):
            return self.getToken(CyanaNOAParser.With_viol_above, 0)

        def getRuleIndex(self):
            return CyanaNOAParser.RULE_peak_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPeak_stat" ):
                listener.enterPeak_stat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPeak_stat" ):
                listener.exitPeak_stat(self)




    def peak_stat(self):

        localctx = CyanaNOAParser.Peak_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_peak_stat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(CyanaNOAParser.Peaks)
            self.state = 152
            self.match(CyanaNOAParser.Colon)
            self.state = 153
            self.match(CyanaNOAParser.Selected)
            self.state = 154
            self.match(CyanaNOAParser.Colon)
            self.state = 155
            self.match(CyanaNOAParser.Integer)
            self.state = 156
            self.match(CyanaNOAParser.Assigned)
            self.state = 157
            self.match(CyanaNOAParser.Colon)
            self.state = 158
            self.match(CyanaNOAParser.Integer)
            self.state = 159
            self.match(CyanaNOAParser.Unassigned)
            self.state = 160
            self.match(CyanaNOAParser.Colon)
            self.state = 161
            self.match(CyanaNOAParser.Integer)
            self.state = 165
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==32:
                self.state = 162
                self.match(CyanaNOAParser.Without_possibility)
                self.state = 163
                self.match(CyanaNOAParser.Colon)
                self.state = 164
                self.match(CyanaNOAParser.Integer)


            self.state = 171
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 167
                self.match(CyanaNOAParser.With_viol_below)
                self.state = 168
                self.match(CyanaNOAParser.Angstrome)
                self.state = 169
                self.match(CyanaNOAParser.Colon)
                self.state = 170
                self.match(CyanaNOAParser.Integer)


            self.state = 179
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34:
                self.state = 173
                self.match(CyanaNOAParser.With_viol_between)
                self.state = 174
                self.match(CyanaNOAParser.Float)
                self.state = 175
                self.match(CyanaNOAParser.And)
                self.state = 176
                self.match(CyanaNOAParser.Angstrome)
                self.state = 177
                self.match(CyanaNOAParser.Colon)
                self.state = 178
                self.match(CyanaNOAParser.Integer)


            self.state = 185
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 181
                self.match(CyanaNOAParser.With_viol_above)
                self.state = 182
                self.match(CyanaNOAParser.Angstrome)
                self.state = 183
                self.match(CyanaNOAParser.Colon)
                self.state = 184
                self.match(CyanaNOAParser.Integer)


            self.state = 187
            self.match(CyanaNOAParser.With_diagonal)
            self.state = 188
            self.match(CyanaNOAParser.Colon)
            self.state = 189
            self.match(CyanaNOAParser.Integer)
            self.state = 190
            self.match(CyanaNOAParser.Cross_peaks)
            self.state = 191
            self.match(CyanaNOAParser.Colon)
            self.state = 192
            self.match(CyanaNOAParser.With_off_diagonal)
            self.state = 193
            self.match(CyanaNOAParser.Colon)
            self.state = 194
            self.match(CyanaNOAParser.Integer)
            self.state = 195
            self.match(CyanaNOAParser.With_unique)
            self.state = 196
            self.match(CyanaNOAParser.Colon)
            self.state = 197
            self.match(CyanaNOAParser.Integer)
            self.state = 198
            self.match(CyanaNOAParser.With_short_range)
            self.state = 199
            self.match(CyanaNOAParser.Short_range_ex)
            self.state = 200
            self.match(CyanaNOAParser.Colon)
            self.state = 201
            self.match(CyanaNOAParser.Integer)
            self.state = 202
            self.match(CyanaNOAParser.With_medium_range)
            self.state = 203
            self.match(CyanaNOAParser.Medium_range_ex)
            self.state = 204
            self.match(CyanaNOAParser.Colon)
            self.state = 205
            self.match(CyanaNOAParser.Integer)
            self.state = 206
            self.match(CyanaNOAParser.With_long_range)
            self.state = 207
            self.match(CyanaNOAParser.Long_range_ex)
            self.state = 208
            self.match(CyanaNOAParser.Colon)
            self.state = 209
            self.match(CyanaNOAParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





