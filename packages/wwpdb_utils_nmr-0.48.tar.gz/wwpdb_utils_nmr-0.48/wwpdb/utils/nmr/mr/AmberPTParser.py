# Generated from AmberPTParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,91,695,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,52,
        2,53,7,53,1,0,1,0,3,0,111,8,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,5,0,164,8,0,10,0,12,0,
        167,9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,179,8,1,1,1,
        1,1,1,2,1,2,1,2,5,2,186,8,2,10,2,12,2,189,9,2,1,2,1,2,1,3,1,3,1,
        3,5,3,196,8,3,10,3,12,3,199,9,3,1,3,1,3,1,4,1,4,1,4,5,4,206,8,4,
        10,4,12,4,209,9,4,1,4,1,4,1,5,1,5,1,5,5,5,216,8,5,10,5,12,5,219,
        9,5,1,5,1,5,1,6,1,6,1,6,5,6,226,8,6,10,6,12,6,229,9,6,1,6,1,6,1,
        7,1,7,1,7,5,7,236,8,7,10,7,12,7,239,9,7,1,7,1,7,1,8,1,8,1,8,5,8,
        246,8,8,10,8,12,8,249,9,8,1,8,1,8,1,9,1,9,1,9,5,9,256,8,9,10,9,12,
        9,259,9,9,1,9,1,9,1,10,1,10,1,10,5,10,266,8,10,10,10,12,10,269,9,
        10,1,10,1,10,1,11,1,11,1,11,5,11,276,8,11,10,11,12,11,279,9,11,1,
        11,1,11,1,12,1,12,1,12,5,12,286,8,12,10,12,12,12,289,9,12,1,12,1,
        12,1,13,1,13,1,13,5,13,296,8,13,10,13,12,13,299,9,13,1,13,1,13,1,
        14,1,14,1,14,5,14,306,8,14,10,14,12,14,309,9,14,1,14,1,14,1,15,1,
        15,1,15,5,15,316,8,15,10,15,12,15,319,9,15,1,15,1,15,1,16,1,16,1,
        16,5,16,326,8,16,10,16,12,16,329,9,16,1,16,1,16,1,17,1,17,1,17,5,
        17,336,8,17,10,17,12,17,339,9,17,1,17,1,17,1,18,1,18,1,18,5,18,346,
        8,18,10,18,12,18,349,9,18,1,18,1,18,1,19,1,19,1,19,5,19,356,8,19,
        10,19,12,19,359,9,19,1,19,1,19,1,20,1,20,1,20,5,20,366,8,20,10,20,
        12,20,369,9,20,1,20,1,20,1,21,1,21,1,21,5,21,376,8,21,10,21,12,21,
        379,9,21,1,21,1,21,1,22,1,22,1,22,5,22,386,8,22,10,22,12,22,389,
        9,22,1,22,1,22,1,23,1,23,1,23,5,23,396,8,23,10,23,12,23,399,9,23,
        1,23,1,23,1,24,1,24,1,24,5,24,406,8,24,10,24,12,24,409,9,24,1,24,
        1,24,1,25,1,25,1,25,5,25,416,8,25,10,25,12,25,419,9,25,1,25,1,25,
        1,26,1,26,1,26,5,26,426,8,26,10,26,12,26,429,9,26,1,26,1,26,1,27,
        1,27,1,27,5,27,436,8,27,10,27,12,27,439,9,27,1,27,1,27,1,28,1,28,
        1,28,5,28,446,8,28,10,28,12,28,449,9,28,1,28,1,28,1,29,1,29,1,29,
        5,29,456,8,29,10,29,12,29,459,9,29,1,29,1,29,1,30,1,30,1,30,5,30,
        466,8,30,10,30,12,30,469,9,30,1,30,1,30,1,31,1,31,1,31,5,31,476,
        8,31,10,31,12,31,479,9,31,1,31,1,31,1,32,1,32,1,32,5,32,486,8,32,
        10,32,12,32,489,9,32,1,32,1,32,1,33,1,33,1,33,5,33,496,8,33,10,33,
        12,33,499,9,33,1,33,1,33,1,34,1,34,1,34,5,34,506,8,34,10,34,12,34,
        509,9,34,1,34,1,34,1,35,1,35,1,35,5,35,516,8,35,10,35,12,35,519,
        9,35,1,35,1,35,1,36,1,36,1,36,5,36,526,8,36,10,36,12,36,529,9,36,
        1,36,1,36,1,37,1,37,1,37,5,37,536,8,37,10,37,12,37,539,9,37,1,37,
        1,37,1,38,1,38,1,38,5,38,546,8,38,10,38,12,38,549,9,38,1,38,1,38,
        1,39,1,39,1,39,5,39,556,8,39,10,39,12,39,559,9,39,1,39,1,39,1,40,
        1,40,1,40,5,40,566,8,40,10,40,12,40,569,9,40,1,40,1,40,1,41,1,41,
        1,41,5,41,576,8,41,10,41,12,41,579,9,41,1,41,1,41,1,42,1,42,1,42,
        5,42,586,8,42,10,42,12,42,589,9,42,1,42,1,42,1,43,1,43,1,43,5,43,
        596,8,43,10,43,12,43,599,9,43,1,43,1,43,1,44,1,44,1,44,5,44,606,
        8,44,10,44,12,44,609,9,44,1,44,1,44,1,45,1,45,1,45,4,45,616,8,45,
        11,45,12,45,617,1,45,1,45,1,46,1,46,1,46,5,46,625,8,46,10,46,12,
        46,628,9,46,1,46,1,46,1,47,1,47,1,47,5,47,635,8,47,10,47,12,47,638,
        9,47,1,47,1,47,1,48,1,48,1,48,5,48,645,8,48,10,48,12,48,648,9,48,
        1,48,1,48,1,49,1,49,1,49,5,49,655,8,49,10,49,12,49,658,9,49,1,49,
        1,49,1,50,1,50,1,50,5,50,665,8,50,10,50,12,50,668,9,50,1,50,1,50,
        1,51,1,51,1,51,5,51,675,8,51,10,51,12,51,678,9,51,1,51,1,51,1,52,
        1,52,1,52,5,52,685,8,52,10,52,12,52,688,9,52,1,52,1,52,1,53,1,53,
        1,53,1,53,0,0,54,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,
        36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,
        80,82,84,86,88,90,92,94,96,98,100,102,104,106,0,6,1,1,79,79,1,1,
        85,85,1,1,91,91,1,1,88,88,1,0,22,35,1,0,80,82,744,0,110,1,0,0,0,
        2,170,1,0,0,0,4,182,1,0,0,0,6,192,1,0,0,0,8,202,1,0,0,0,10,212,1,
        0,0,0,12,222,1,0,0,0,14,232,1,0,0,0,16,242,1,0,0,0,18,252,1,0,0,
        0,20,262,1,0,0,0,22,272,1,0,0,0,24,282,1,0,0,0,26,292,1,0,0,0,28,
        302,1,0,0,0,30,312,1,0,0,0,32,322,1,0,0,0,34,332,1,0,0,0,36,342,
        1,0,0,0,38,352,1,0,0,0,40,362,1,0,0,0,42,372,1,0,0,0,44,382,1,0,
        0,0,46,392,1,0,0,0,48,402,1,0,0,0,50,412,1,0,0,0,52,422,1,0,0,0,
        54,432,1,0,0,0,56,442,1,0,0,0,58,452,1,0,0,0,60,462,1,0,0,0,62,472,
        1,0,0,0,64,482,1,0,0,0,66,492,1,0,0,0,68,502,1,0,0,0,70,512,1,0,
        0,0,72,522,1,0,0,0,74,532,1,0,0,0,76,542,1,0,0,0,78,552,1,0,0,0,
        80,562,1,0,0,0,82,572,1,0,0,0,84,582,1,0,0,0,86,592,1,0,0,0,88,602,
        1,0,0,0,90,612,1,0,0,0,92,621,1,0,0,0,94,631,1,0,0,0,96,641,1,0,
        0,0,98,651,1,0,0,0,100,661,1,0,0,0,102,671,1,0,0,0,104,681,1,0,0,
        0,106,691,1,0,0,0,108,111,3,2,1,0,109,111,5,2,0,0,110,108,1,0,0,
        0,110,109,1,0,0,0,111,165,1,0,0,0,112,164,3,4,2,0,113,164,3,6,3,
        0,114,164,3,8,4,0,115,164,3,10,5,0,116,164,3,12,6,0,117,164,3,14,
        7,0,118,164,3,16,8,0,119,164,3,18,9,0,120,164,3,20,10,0,121,164,
        3,22,11,0,122,164,3,24,12,0,123,164,3,26,13,0,124,164,3,28,14,0,
        125,164,3,30,15,0,126,164,3,32,16,0,127,164,3,34,17,0,128,164,3,
        36,18,0,129,164,3,38,19,0,130,164,3,40,20,0,131,164,3,42,21,0,132,
        164,3,44,22,0,133,164,3,46,23,0,134,164,3,48,24,0,135,164,3,50,25,
        0,136,164,3,52,26,0,137,164,3,54,27,0,138,164,3,56,28,0,139,164,
        3,58,29,0,140,164,3,60,30,0,141,164,3,62,31,0,142,164,3,64,32,0,
        143,164,3,66,33,0,144,164,3,68,34,0,145,164,3,70,35,0,146,164,3,
        72,36,0,147,164,3,74,37,0,148,164,3,76,38,0,149,164,3,78,39,0,150,
        164,3,80,40,0,151,164,3,82,41,0,152,164,3,84,42,0,153,164,3,86,43,
        0,154,164,3,88,44,0,155,164,3,90,45,0,156,164,3,92,46,0,157,164,
        3,94,47,0,158,164,3,96,48,0,159,164,3,98,49,0,160,164,3,100,50,0,
        161,164,3,102,51,0,162,164,3,104,52,0,163,112,1,0,0,0,163,113,1,
        0,0,0,163,114,1,0,0,0,163,115,1,0,0,0,163,116,1,0,0,0,163,117,1,
        0,0,0,163,118,1,0,0,0,163,119,1,0,0,0,163,120,1,0,0,0,163,121,1,
        0,0,0,163,122,1,0,0,0,163,123,1,0,0,0,163,124,1,0,0,0,163,125,1,
        0,0,0,163,126,1,0,0,0,163,127,1,0,0,0,163,128,1,0,0,0,163,129,1,
        0,0,0,163,130,1,0,0,0,163,131,1,0,0,0,163,132,1,0,0,0,163,133,1,
        0,0,0,163,134,1,0,0,0,163,135,1,0,0,0,163,136,1,0,0,0,163,137,1,
        0,0,0,163,138,1,0,0,0,163,139,1,0,0,0,163,140,1,0,0,0,163,141,1,
        0,0,0,163,142,1,0,0,0,163,143,1,0,0,0,163,144,1,0,0,0,163,145,1,
        0,0,0,163,146,1,0,0,0,163,147,1,0,0,0,163,148,1,0,0,0,163,149,1,
        0,0,0,163,150,1,0,0,0,163,151,1,0,0,0,163,152,1,0,0,0,163,153,1,
        0,0,0,163,154,1,0,0,0,163,155,1,0,0,0,163,156,1,0,0,0,163,157,1,
        0,0,0,163,158,1,0,0,0,163,159,1,0,0,0,163,160,1,0,0,0,163,161,1,
        0,0,0,163,162,1,0,0,0,164,167,1,0,0,0,165,163,1,0,0,0,165,166,1,
        0,0,0,166,168,1,0,0,0,167,165,1,0,0,0,168,169,5,0,0,1,169,1,1,0,
        0,0,170,171,5,1,0,0,171,172,5,73,0,0,172,173,5,75,0,0,173,174,5,
        76,0,0,174,175,5,74,0,0,175,176,5,75,0,0,176,178,5,77,0,0,177,179,
        5,77,0,0,178,177,1,0,0,0,178,179,1,0,0,0,179,180,1,0,0,0,180,181,
        7,0,0,0,181,3,1,0,0,0,182,183,5,3,0,0,183,187,3,106,53,0,184,186,
        5,83,0,0,185,184,1,0,0,0,186,189,1,0,0,0,187,185,1,0,0,0,187,188,
        1,0,0,0,188,190,1,0,0,0,189,187,1,0,0,0,190,191,7,1,0,0,191,5,1,
        0,0,0,192,193,5,4,0,0,193,197,3,106,53,0,194,196,5,89,0,0,195,194,
        1,0,0,0,196,199,1,0,0,0,197,195,1,0,0,0,197,198,1,0,0,0,198,200,
        1,0,0,0,199,197,1,0,0,0,200,201,7,2,0,0,201,7,1,0,0,0,202,203,5,
        5,0,0,203,207,3,106,53,0,204,206,5,89,0,0,205,204,1,0,0,0,206,209,
        1,0,0,0,207,205,1,0,0,0,207,208,1,0,0,0,208,210,1,0,0,0,209,207,
        1,0,0,0,210,211,7,2,0,0,211,9,1,0,0,0,212,213,5,6,0,0,213,217,3,
        106,53,0,214,216,5,86,0,0,215,214,1,0,0,0,216,219,1,0,0,0,217,215,
        1,0,0,0,217,218,1,0,0,0,218,220,1,0,0,0,219,217,1,0,0,0,220,221,
        7,3,0,0,221,11,1,0,0,0,222,223,5,7,0,0,223,227,3,106,53,0,224,226,
        5,86,0,0,225,224,1,0,0,0,226,229,1,0,0,0,227,225,1,0,0,0,227,228,
        1,0,0,0,228,230,1,0,0,0,229,227,1,0,0,0,230,231,7,3,0,0,231,13,1,
        0,0,0,232,233,5,8,0,0,233,237,3,106,53,0,234,236,5,86,0,0,235,234,
        1,0,0,0,236,239,1,0,0,0,237,235,1,0,0,0,237,238,1,0,0,0,238,240,
        1,0,0,0,239,237,1,0,0,0,240,241,7,3,0,0,241,15,1,0,0,0,242,243,5,
        9,0,0,243,247,3,106,53,0,244,246,5,83,0,0,245,244,1,0,0,0,246,249,
        1,0,0,0,247,245,1,0,0,0,247,248,1,0,0,0,248,250,1,0,0,0,249,247,
        1,0,0,0,250,251,7,1,0,0,251,17,1,0,0,0,252,253,5,10,0,0,253,257,
        3,106,53,0,254,256,5,86,0,0,255,254,1,0,0,0,256,259,1,0,0,0,257,
        255,1,0,0,0,257,258,1,0,0,0,258,260,1,0,0,0,259,257,1,0,0,0,260,
        261,7,3,0,0,261,19,1,0,0,0,262,263,5,11,0,0,263,267,3,106,53,0,264,
        266,5,86,0,0,265,264,1,0,0,0,266,269,1,0,0,0,267,265,1,0,0,0,267,
        268,1,0,0,0,268,270,1,0,0,0,269,267,1,0,0,0,270,271,7,3,0,0,271,
        21,1,0,0,0,272,273,5,12,0,0,273,277,3,106,53,0,274,276,5,89,0,0,
        275,274,1,0,0,0,276,279,1,0,0,0,277,275,1,0,0,0,277,278,1,0,0,0,
        278,280,1,0,0,0,279,277,1,0,0,0,280,281,7,2,0,0,281,23,1,0,0,0,282,
        283,5,13,0,0,283,287,3,106,53,0,284,286,5,89,0,0,285,284,1,0,0,0,
        286,289,1,0,0,0,287,285,1,0,0,0,287,288,1,0,0,0,288,290,1,0,0,0,
        289,287,1,0,0,0,290,291,7,2,0,0,291,25,1,0,0,0,292,293,5,14,0,0,
        293,297,3,106,53,0,294,296,5,86,0,0,295,294,1,0,0,0,296,299,1,0,
        0,0,297,295,1,0,0,0,297,298,1,0,0,0,298,300,1,0,0,0,299,297,1,0,
        0,0,300,301,7,3,0,0,301,27,1,0,0,0,302,303,5,15,0,0,303,307,3,106,
        53,0,304,306,5,86,0,0,305,304,1,0,0,0,306,309,1,0,0,0,307,305,1,
        0,0,0,307,308,1,0,0,0,308,310,1,0,0,0,309,307,1,0,0,0,310,311,7,
        3,0,0,311,29,1,0,0,0,312,313,5,16,0,0,313,317,3,106,53,0,314,316,
        5,89,0,0,315,314,1,0,0,0,316,319,1,0,0,0,317,315,1,0,0,0,317,318,
        1,0,0,0,318,320,1,0,0,0,319,317,1,0,0,0,320,321,7,2,0,0,321,31,1,
        0,0,0,322,323,5,17,0,0,323,327,3,106,53,0,324,326,5,86,0,0,325,324,
        1,0,0,0,326,329,1,0,0,0,327,325,1,0,0,0,327,328,1,0,0,0,328,330,
        1,0,0,0,329,327,1,0,0,0,330,331,7,3,0,0,331,33,1,0,0,0,332,333,5,
        18,0,0,333,337,3,106,53,0,334,336,5,89,0,0,335,334,1,0,0,0,336,339,
        1,0,0,0,337,335,1,0,0,0,337,338,1,0,0,0,338,340,1,0,0,0,339,337,
        1,0,0,0,340,341,7,2,0,0,341,35,1,0,0,0,342,343,5,19,0,0,343,347,
        3,106,53,0,344,346,5,89,0,0,345,344,1,0,0,0,346,349,1,0,0,0,347,
        345,1,0,0,0,347,348,1,0,0,0,348,350,1,0,0,0,349,347,1,0,0,0,350,
        351,7,2,0,0,351,37,1,0,0,0,352,353,5,20,0,0,353,357,3,106,53,0,354,
        356,5,86,0,0,355,354,1,0,0,0,356,359,1,0,0,0,357,355,1,0,0,0,357,
        358,1,0,0,0,358,360,1,0,0,0,359,357,1,0,0,0,360,361,7,3,0,0,361,
        39,1,0,0,0,362,363,5,21,0,0,363,367,3,106,53,0,364,366,5,86,0,0,
        365,364,1,0,0,0,366,369,1,0,0,0,367,365,1,0,0,0,367,368,1,0,0,0,
        368,370,1,0,0,0,369,367,1,0,0,0,370,371,7,3,0,0,371,41,1,0,0,0,372,
        373,7,4,0,0,373,377,3,106,53,0,374,376,5,89,0,0,375,374,1,0,0,0,
        376,379,1,0,0,0,377,375,1,0,0,0,377,378,1,0,0,0,378,380,1,0,0,0,
        379,377,1,0,0,0,380,381,7,2,0,0,381,43,1,0,0,0,382,383,5,36,0,0,
        383,387,3,106,53,0,384,386,5,86,0,0,385,384,1,0,0,0,386,389,1,0,
        0,0,387,385,1,0,0,0,387,388,1,0,0,0,388,390,1,0,0,0,389,387,1,0,
        0,0,390,391,7,3,0,0,391,45,1,0,0,0,392,393,5,37,0,0,393,397,3,106,
        53,0,394,396,5,89,0,0,395,394,1,0,0,0,396,399,1,0,0,0,397,395,1,
        0,0,0,397,398,1,0,0,0,398,400,1,0,0,0,399,397,1,0,0,0,400,401,7,
        2,0,0,401,47,1,0,0,0,402,403,5,38,0,0,403,407,3,106,53,0,404,406,
        5,89,0,0,405,404,1,0,0,0,406,409,1,0,0,0,407,405,1,0,0,0,407,408,
        1,0,0,0,408,410,1,0,0,0,409,407,1,0,0,0,410,411,7,2,0,0,411,49,1,
        0,0,0,412,413,5,39,0,0,413,417,3,106,53,0,414,416,5,89,0,0,415,414,
        1,0,0,0,416,419,1,0,0,0,417,415,1,0,0,0,417,418,1,0,0,0,418,420,
        1,0,0,0,419,417,1,0,0,0,420,421,7,2,0,0,421,51,1,0,0,0,422,423,5,
        40,0,0,423,427,3,106,53,0,424,426,5,86,0,0,425,424,1,0,0,0,426,429,
        1,0,0,0,427,425,1,0,0,0,427,428,1,0,0,0,428,430,1,0,0,0,429,427,
        1,0,0,0,430,431,7,3,0,0,431,53,1,0,0,0,432,433,5,41,0,0,433,437,
        3,106,53,0,434,436,5,86,0,0,435,434,1,0,0,0,436,439,1,0,0,0,437,
        435,1,0,0,0,437,438,1,0,0,0,438,440,1,0,0,0,439,437,1,0,0,0,440,
        441,7,3,0,0,441,55,1,0,0,0,442,443,5,42,0,0,443,447,3,106,53,0,444,
        446,5,86,0,0,445,444,1,0,0,0,446,449,1,0,0,0,447,445,1,0,0,0,447,
        448,1,0,0,0,448,450,1,0,0,0,449,447,1,0,0,0,450,451,7,3,0,0,451,
        57,1,0,0,0,452,453,5,43,0,0,453,457,3,106,53,0,454,456,5,89,0,0,
        455,454,1,0,0,0,456,459,1,0,0,0,457,455,1,0,0,0,457,458,1,0,0,0,
        458,460,1,0,0,0,459,457,1,0,0,0,460,461,7,2,0,0,461,59,1,0,0,0,462,
        463,5,44,0,0,463,467,3,106,53,0,464,466,5,89,0,0,465,464,1,0,0,0,
        466,469,1,0,0,0,467,465,1,0,0,0,467,468,1,0,0,0,468,470,1,0,0,0,
        469,467,1,0,0,0,470,471,7,2,0,0,471,61,1,0,0,0,472,473,5,45,0,0,
        473,477,3,106,53,0,474,476,5,89,0,0,475,474,1,0,0,0,476,479,1,0,
        0,0,477,475,1,0,0,0,477,478,1,0,0,0,478,480,1,0,0,0,479,477,1,0,
        0,0,480,481,7,2,0,0,481,63,1,0,0,0,482,483,5,46,0,0,483,487,3,106,
        53,0,484,486,5,86,0,0,485,484,1,0,0,0,486,489,1,0,0,0,487,485,1,
        0,0,0,487,488,1,0,0,0,488,490,1,0,0,0,489,487,1,0,0,0,490,491,7,
        3,0,0,491,65,1,0,0,0,492,493,5,47,0,0,493,497,3,106,53,0,494,496,
        5,86,0,0,495,494,1,0,0,0,496,499,1,0,0,0,497,495,1,0,0,0,497,498,
        1,0,0,0,498,500,1,0,0,0,499,497,1,0,0,0,500,501,7,3,0,0,501,67,1,
        0,0,0,502,503,5,48,0,0,503,507,3,106,53,0,504,506,5,86,0,0,505,504,
        1,0,0,0,506,509,1,0,0,0,507,505,1,0,0,0,507,508,1,0,0,0,508,510,
        1,0,0,0,509,507,1,0,0,0,510,511,7,3,0,0,511,69,1,0,0,0,512,513,5,
        49,0,0,513,517,3,106,53,0,514,516,5,89,0,0,515,514,1,0,0,0,516,519,
        1,0,0,0,517,515,1,0,0,0,517,518,1,0,0,0,518,520,1,0,0,0,519,517,
        1,0,0,0,520,521,7,2,0,0,521,71,1,0,0,0,522,523,5,50,0,0,523,527,
        3,106,53,0,524,526,5,89,0,0,525,524,1,0,0,0,526,529,1,0,0,0,527,
        525,1,0,0,0,527,528,1,0,0,0,528,530,1,0,0,0,529,527,1,0,0,0,530,
        531,7,2,0,0,531,73,1,0,0,0,532,533,5,51,0,0,533,537,3,106,53,0,534,
        536,5,89,0,0,535,534,1,0,0,0,536,539,1,0,0,0,537,535,1,0,0,0,537,
        538,1,0,0,0,538,540,1,0,0,0,539,537,1,0,0,0,540,541,7,2,0,0,541,
        75,1,0,0,0,542,543,5,52,0,0,543,547,3,106,53,0,544,546,5,86,0,0,
        545,544,1,0,0,0,546,549,1,0,0,0,547,545,1,0,0,0,547,548,1,0,0,0,
        548,550,1,0,0,0,549,547,1,0,0,0,550,551,7,3,0,0,551,77,1,0,0,0,552,
        553,5,53,0,0,553,557,3,106,53,0,554,556,5,86,0,0,555,554,1,0,0,0,
        556,559,1,0,0,0,557,555,1,0,0,0,557,558,1,0,0,0,558,560,1,0,0,0,
        559,557,1,0,0,0,560,561,7,3,0,0,561,79,1,0,0,0,562,563,5,54,0,0,
        563,567,3,106,53,0,564,566,5,86,0,0,565,564,1,0,0,0,566,569,1,0,
        0,0,567,565,1,0,0,0,567,568,1,0,0,0,568,570,1,0,0,0,569,567,1,0,
        0,0,570,571,7,3,0,0,571,81,1,0,0,0,572,573,5,55,0,0,573,577,3,106,
        53,0,574,576,5,89,0,0,575,574,1,0,0,0,576,579,1,0,0,0,577,575,1,
        0,0,0,577,578,1,0,0,0,578,580,1,0,0,0,579,577,1,0,0,0,580,581,7,
        2,0,0,581,83,1,0,0,0,582,583,5,56,0,0,583,587,3,106,53,0,584,586,
        5,89,0,0,585,584,1,0,0,0,586,589,1,0,0,0,587,585,1,0,0,0,587,588,
        1,0,0,0,588,590,1,0,0,0,589,587,1,0,0,0,590,591,7,2,0,0,591,85,1,
        0,0,0,592,593,5,57,0,0,593,597,3,106,53,0,594,596,5,83,0,0,595,594,
        1,0,0,0,596,599,1,0,0,0,597,595,1,0,0,0,597,598,1,0,0,0,598,600,
        1,0,0,0,599,597,1,0,0,0,600,601,7,1,0,0,601,87,1,0,0,0,602,603,5,
        58,0,0,603,607,3,106,53,0,604,606,5,83,0,0,605,604,1,0,0,0,606,609,
        1,0,0,0,607,605,1,0,0,0,607,608,1,0,0,0,608,610,1,0,0,0,609,607,
        1,0,0,0,610,611,7,1,0,0,611,89,1,0,0,0,612,613,5,59,0,0,613,615,
        3,106,53,0,614,616,5,86,0,0,615,614,1,0,0,0,616,617,1,0,0,0,617,
        615,1,0,0,0,617,618,1,0,0,0,618,619,1,0,0,0,619,620,7,3,0,0,620,
        91,1,0,0,0,621,622,5,60,0,0,622,626,3,106,53,0,623,625,5,89,0,0,
        624,623,1,0,0,0,625,628,1,0,0,0,626,624,1,0,0,0,626,627,1,0,0,0,
        627,629,1,0,0,0,628,626,1,0,0,0,629,630,7,2,0,0,630,93,1,0,0,0,631,
        632,5,61,0,0,632,636,3,106,53,0,633,635,5,89,0,0,634,633,1,0,0,0,
        635,638,1,0,0,0,636,634,1,0,0,0,636,637,1,0,0,0,637,639,1,0,0,0,
        638,636,1,0,0,0,639,640,7,2,0,0,640,95,1,0,0,0,641,642,5,62,0,0,
        642,646,3,106,53,0,643,645,5,89,0,0,644,643,1,0,0,0,645,648,1,0,
        0,0,646,644,1,0,0,0,646,647,1,0,0,0,647,649,1,0,0,0,648,646,1,0,
        0,0,649,650,7,2,0,0,650,97,1,0,0,0,651,652,5,63,0,0,652,656,3,106,
        53,0,653,655,5,89,0,0,654,653,1,0,0,0,655,658,1,0,0,0,656,654,1,
        0,0,0,656,657,1,0,0,0,657,659,1,0,0,0,658,656,1,0,0,0,659,660,7,
        2,0,0,660,99,1,0,0,0,661,662,5,64,0,0,662,666,3,106,53,0,663,665,
        5,86,0,0,664,663,1,0,0,0,665,668,1,0,0,0,666,664,1,0,0,0,666,667,
        1,0,0,0,667,669,1,0,0,0,668,666,1,0,0,0,669,670,7,3,0,0,670,101,
        1,0,0,0,671,672,5,65,0,0,672,676,3,106,53,0,673,675,5,83,0,0,674,
        673,1,0,0,0,675,678,1,0,0,0,676,674,1,0,0,0,676,677,1,0,0,0,677,
        679,1,0,0,0,678,676,1,0,0,0,679,680,7,1,0,0,680,103,1,0,0,0,681,
        682,5,66,0,0,682,686,3,106,53,0,683,685,5,83,0,0,684,683,1,0,0,0,
        685,688,1,0,0,0,686,684,1,0,0,0,686,687,1,0,0,0,687,689,1,0,0,0,
        688,686,1,0,0,0,689,690,7,1,0,0,690,105,1,0,0,0,691,692,5,70,0,0,
        692,693,7,5,0,0,693,107,1,0,0,0,55,110,163,165,178,187,197,207,217,
        227,237,247,257,267,277,287,297,307,317,327,337,347,357,367,377,
        387,397,407,417,427,437,447,457,467,477,487,497,507,517,527,537,
        547,557,567,577,587,597,607,617,626,636,646,656,666,676,686
    ]

class AmberPTParser ( Parser ):

    grammarFileName = "AmberPTParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'%VERSION'", "<INVALID>", "'AMBER_ATOM_TYPE'", 
                     "'ANGLE_EQUIL_VALUE'", "'ANGLE_FORCE_CONSTANT'", "'ANGLES_INC_HYDROGEN'", 
                     "'ANGLES_WITHOUT_HYDROGEN'", "'ATOMIC_NUMBER'", "'ATOM_NAME'", 
                     "'ATOM_TYPE_INDEX'", "'ATOMS_PER_MOLECULE'", "'BOND_EQUIL_VALUE'", 
                     "'BOND_FORCE_CONSTANT'", "'BONDS_INC_HYDROGEN'", "'BONDS_WITHOUT_HYDROGEN'", 
                     "'BOX_DIMENSIONS'", "'CAP_INFO'", "'CAP_INFO2'", "'CHARGE'", 
                     "'CMAP_COUNT'", "'CMAP_RESOLUTION'", "'CMAP_PARAMETER_01'", 
                     "'CMAP_PARAMETER_02'", "'CMAP_PARAMETER_03'", "'CMAP_PARAMETER_04'", 
                     "'CMAP_PARAMETER_05'", "'CMAP_PARAMETER_06'", "'CMAP_PARAMETER_07'", 
                     "'CMAP_PARAMETER_08'", "'CMAP_PARAMETER_09'", "'CMAP_PARAMETER_10'", 
                     "'CMAP_PARAMETER_11'", "'CMAP_PARAMETER_12'", "'CMAP_PARAMETER_13'", 
                     "'CMAP_PARAMETER_14'", "'CMAP_INDEX'", "'DIHEDRAL_FORCE_CONSTANT'", 
                     "'DIHEDRAL_PERIODICITY'", "'DIHEDRAL_PHASE'", "'DIHEDRALS_INC_HYDROGEN'", 
                     "'DIHEDRALS_WITHOUT_HYDROGEN'", "'EXCLUDED_ATOMS_LIST'", 
                     "'HBCUT'", "'HBOND_ACOEF'", "'HBOND_BCOEF'", "'IPOL'", 
                     "'IROTAT'", "'JOIN_ARRAY'", "'LENNARD_JONES_ACOEF'", 
                     "'LENNARD_JONES_BCOEF'", "'MASS'", "'NONBONDED_PARM_INDEX'", 
                     "'NUMBER_EXCLUDED_ATOMS'", "'POINTERS'", "'POLARIZABILITY'", 
                     "'RADII'", "'RADIUS_SET'", "'RESIDUE_LABEL'", "'RESIDUE_POINTER'", 
                     "'SCEE_SCALE_FACTOR'", "'SCNB_SCALE_FACTOR'", "'SCREEN'", 
                     "'SOLTY'", "'SOLVENT_POINTERS'", "'TITLE'", "'TREE_CHAIN_CLASSIFICATION'", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'%FORMAT'", 
                     "<INVALID>", "<INVALID>", "'VERSION_STAMP'", "'DATE'", 
                     "'='" ]

    symbolicNames = [ "<INVALID>", "VERSION", "FLAG", "AMBER_ATOM_TYPE", 
                      "ANGLE_EQUIL_VALUE", "ANGLE_FORCE_CONSTANT", "ANGLES_INC_HYDROGEN", 
                      "ANGLES_WITHOUT_HYDROGEN", "ATOMIC_NUMBER", "ATOM_NAME", 
                      "ATOM_TYPE_INDEX", "ATOMS_PER_MOLECULE", "BOND_EQUIL_VALUE", 
                      "BOND_FORCE_CONSTANT", "BONDS_INC_HYDROGEN", "BONDS_WITHOUT_HYDROGEN", 
                      "BOX_DIMENSIONS", "CAP_INFO", "CAP_INFO2", "CHARGE", 
                      "CMAP_COUNT", "CMAP_RESOLUTION", "CMAP_PARAMETER_01", 
                      "CMAP_PARAMETER_02", "CMAP_PARAMETER_03", "CMAP_PARAMETER_04", 
                      "CMAP_PARAMETER_05", "CMAP_PARAMETER_06", "CMAP_PARAMETER_07", 
                      "CMAP_PARAMETER_08", "CMAP_PARAMETER_09", "CMAP_PARAMETER_10", 
                      "CMAP_PARAMETER_11", "CMAP_PARAMETER_12", "CMAP_PARAMETER_13", 
                      "CMAP_PARAMETER_14", "CMAP_INDEX", "DIHEDRAL_FORCE_CONSTANT", 
                      "DIHEDRAL_PERIODICITY", "DIHEDRAL_PHASE", "DIHEDRALS_INC_HYDROGEN", 
                      "DIHEDRALS_WITHOUT_HYDROGEN", "EXCLUDED_ATOMS_LIST", 
                      "HBCUT", "HBOND_ACOEF", "HBOND_BCOEF", "IPOL", "IROTAT", 
                      "JOIN_ARRAY", "LENNARD_JONES_ACOEF", "LENNARD_JONES_BCOEF", 
                      "MASS", "NONBONDED_PARM_INDEX", "NUMBER_EXCLUDED_ATOMS", 
                      "POINTERS", "POLARIZABILITY", "RADII", "RADIUS_SET", 
                      "RESIDUE_LABEL", "RESIDUE_POINTER", "SCEE_SCALE_FACTOR", 
                      "SCNB_SCALE_FACTOR", "SCREEN", "SOLTY", "SOLVENT_POINTERS", 
                      "TITLE", "TREE_CHAIN_CLASSIFICATION", "SHARP_COMMENT", 
                      "EXCLM_COMMENT", "SMCLN_COMMENT", "FORMAT", "SPACE", 
                      "LINE_COMMENT", "VERSION_STAMP", "DATE", "Equ_op", 
                      "Version", "Date_time", "SPACE_VS", "FLAG_VS", "Fortran_format_A", 
                      "Fortran_format_I", "Fortran_format_E", "Simple_name", 
                      "SPACE_AA", "FLAG_AA", "Integer", "SPACE_IA", "FLAG_IA", 
                      "Real", "SPACE_EA", "FLAG_EA" ]

    RULE_amber_pt = 0
    RULE_version_statement = 1
    RULE_amber_atom_type_statement = 2
    RULE_angle_equil_value_statement = 3
    RULE_angle_force_constant_statement = 4
    RULE_angles_inc_hydrogen_statement = 5
    RULE_angles_without_hydrogen_statement = 6
    RULE_atomic_number_statement = 7
    RULE_atom_name_statement = 8
    RULE_atom_type_index_statement = 9
    RULE_atoms_per_molecule_statement = 10
    RULE_bond_equil_value_statement = 11
    RULE_bond_force_constant_statement = 12
    RULE_bonds_inc_hydrogen_statement = 13
    RULE_bonds_without_hydrogen_statement = 14
    RULE_box_dimensions_statement = 15
    RULE_cap_info_statement = 16
    RULE_cap_info2_statement = 17
    RULE_charge_statement = 18
    RULE_cmap_count_statement = 19
    RULE_cmap_resolution_statement = 20
    RULE_cmap_parameter_statement = 21
    RULE_cmap_index_statement = 22
    RULE_dihedral_force_constant_statement = 23
    RULE_dihedral_periodicity_statement = 24
    RULE_dihedral_phase_statement = 25
    RULE_dihedrals_inc_hydrogen_statement = 26
    RULE_dihedrals_without_hydrogen_statement = 27
    RULE_excluded_atoms_list_statement = 28
    RULE_hbcut_statement = 29
    RULE_hbond_acoef_statement = 30
    RULE_hbond_bcoef_statement = 31
    RULE_ipol_statement = 32
    RULE_irotat_statement = 33
    RULE_join_array_statement = 34
    RULE_lennard_jones_acoef_statement = 35
    RULE_lennard_jones_bcoef_statement = 36
    RULE_mass_statement = 37
    RULE_nonbonded_parm_index_statement = 38
    RULE_number_excluded_atoms_statement = 39
    RULE_pointers_statement = 40
    RULE_polarizability_statement = 41
    RULE_radii_statement = 42
    RULE_radius_set_statement = 43
    RULE_residue_label_statement = 44
    RULE_residue_pointer_statement = 45
    RULE_scee_scale_factor_statement = 46
    RULE_scnb_scale_factor_statement = 47
    RULE_screen_statement = 48
    RULE_solty_statement = 49
    RULE_solvent_pointers_statement = 50
    RULE_title_statement = 51
    RULE_tree_chain_classification_statement = 52
    RULE_format_function = 53

    ruleNames =  [ "amber_pt", "version_statement", "amber_atom_type_statement", 
                   "angle_equil_value_statement", "angle_force_constant_statement", 
                   "angles_inc_hydrogen_statement", "angles_without_hydrogen_statement", 
                   "atomic_number_statement", "atom_name_statement", "atom_type_index_statement", 
                   "atoms_per_molecule_statement", "bond_equil_value_statement", 
                   "bond_force_constant_statement", "bonds_inc_hydrogen_statement", 
                   "bonds_without_hydrogen_statement", "box_dimensions_statement", 
                   "cap_info_statement", "cap_info2_statement", "charge_statement", 
                   "cmap_count_statement", "cmap_resolution_statement", 
                   "cmap_parameter_statement", "cmap_index_statement", "dihedral_force_constant_statement", 
                   "dihedral_periodicity_statement", "dihedral_phase_statement", 
                   "dihedrals_inc_hydrogen_statement", "dihedrals_without_hydrogen_statement", 
                   "excluded_atoms_list_statement", "hbcut_statement", "hbond_acoef_statement", 
                   "hbond_bcoef_statement", "ipol_statement", "irotat_statement", 
                   "join_array_statement", "lennard_jones_acoef_statement", 
                   "lennard_jones_bcoef_statement", "mass_statement", "nonbonded_parm_index_statement", 
                   "number_excluded_atoms_statement", "pointers_statement", 
                   "polarizability_statement", "radii_statement", "radius_set_statement", 
                   "residue_label_statement", "residue_pointer_statement", 
                   "scee_scale_factor_statement", "scnb_scale_factor_statement", 
                   "screen_statement", "solty_statement", "solvent_pointers_statement", 
                   "title_statement", "tree_chain_classification_statement", 
                   "format_function" ]

    EOF = Token.EOF
    VERSION=1
    FLAG=2
    AMBER_ATOM_TYPE=3
    ANGLE_EQUIL_VALUE=4
    ANGLE_FORCE_CONSTANT=5
    ANGLES_INC_HYDROGEN=6
    ANGLES_WITHOUT_HYDROGEN=7
    ATOMIC_NUMBER=8
    ATOM_NAME=9
    ATOM_TYPE_INDEX=10
    ATOMS_PER_MOLECULE=11
    BOND_EQUIL_VALUE=12
    BOND_FORCE_CONSTANT=13
    BONDS_INC_HYDROGEN=14
    BONDS_WITHOUT_HYDROGEN=15
    BOX_DIMENSIONS=16
    CAP_INFO=17
    CAP_INFO2=18
    CHARGE=19
    CMAP_COUNT=20
    CMAP_RESOLUTION=21
    CMAP_PARAMETER_01=22
    CMAP_PARAMETER_02=23
    CMAP_PARAMETER_03=24
    CMAP_PARAMETER_04=25
    CMAP_PARAMETER_05=26
    CMAP_PARAMETER_06=27
    CMAP_PARAMETER_07=28
    CMAP_PARAMETER_08=29
    CMAP_PARAMETER_09=30
    CMAP_PARAMETER_10=31
    CMAP_PARAMETER_11=32
    CMAP_PARAMETER_12=33
    CMAP_PARAMETER_13=34
    CMAP_PARAMETER_14=35
    CMAP_INDEX=36
    DIHEDRAL_FORCE_CONSTANT=37
    DIHEDRAL_PERIODICITY=38
    DIHEDRAL_PHASE=39
    DIHEDRALS_INC_HYDROGEN=40
    DIHEDRALS_WITHOUT_HYDROGEN=41
    EXCLUDED_ATOMS_LIST=42
    HBCUT=43
    HBOND_ACOEF=44
    HBOND_BCOEF=45
    IPOL=46
    IROTAT=47
    JOIN_ARRAY=48
    LENNARD_JONES_ACOEF=49
    LENNARD_JONES_BCOEF=50
    MASS=51
    NONBONDED_PARM_INDEX=52
    NUMBER_EXCLUDED_ATOMS=53
    POINTERS=54
    POLARIZABILITY=55
    RADII=56
    RADIUS_SET=57
    RESIDUE_LABEL=58
    RESIDUE_POINTER=59
    SCEE_SCALE_FACTOR=60
    SCNB_SCALE_FACTOR=61
    SCREEN=62
    SOLTY=63
    SOLVENT_POINTERS=64
    TITLE=65
    TREE_CHAIN_CLASSIFICATION=66
    SHARP_COMMENT=67
    EXCLM_COMMENT=68
    SMCLN_COMMENT=69
    FORMAT=70
    SPACE=71
    LINE_COMMENT=72
    VERSION_STAMP=73
    DATE=74
    Equ_op=75
    Version=76
    Date_time=77
    SPACE_VS=78
    FLAG_VS=79
    Fortran_format_A=80
    Fortran_format_I=81
    Fortran_format_E=82
    Simple_name=83
    SPACE_AA=84
    FLAG_AA=85
    Integer=86
    SPACE_IA=87
    FLAG_IA=88
    Real=89
    SPACE_EA=90
    FLAG_EA=91

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Amber_ptContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def version_statement(self):
            return self.getTypedRuleContext(AmberPTParser.Version_statementContext,0)


        def FLAG(self):
            return self.getToken(AmberPTParser.FLAG, 0)

        def amber_atom_type_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Amber_atom_type_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Amber_atom_type_statementContext,i)


        def angle_equil_value_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Angle_equil_value_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Angle_equil_value_statementContext,i)


        def angle_force_constant_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Angle_force_constant_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Angle_force_constant_statementContext,i)


        def angles_inc_hydrogen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Angles_inc_hydrogen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Angles_inc_hydrogen_statementContext,i)


        def angles_without_hydrogen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Angles_without_hydrogen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Angles_without_hydrogen_statementContext,i)


        def atomic_number_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Atomic_number_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Atomic_number_statementContext,i)


        def atom_name_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Atom_name_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Atom_name_statementContext,i)


        def atom_type_index_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Atom_type_index_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Atom_type_index_statementContext,i)


        def atoms_per_molecule_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Atoms_per_molecule_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Atoms_per_molecule_statementContext,i)


        def bond_equil_value_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Bond_equil_value_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Bond_equil_value_statementContext,i)


        def bond_force_constant_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Bond_force_constant_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Bond_force_constant_statementContext,i)


        def bonds_inc_hydrogen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Bonds_inc_hydrogen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Bonds_inc_hydrogen_statementContext,i)


        def bonds_without_hydrogen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Bonds_without_hydrogen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Bonds_without_hydrogen_statementContext,i)


        def box_dimensions_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Box_dimensions_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Box_dimensions_statementContext,i)


        def cap_info_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Cap_info_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Cap_info_statementContext,i)


        def cap_info2_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Cap_info2_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Cap_info2_statementContext,i)


        def charge_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Charge_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Charge_statementContext,i)


        def cmap_count_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Cmap_count_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Cmap_count_statementContext,i)


        def cmap_resolution_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Cmap_resolution_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Cmap_resolution_statementContext,i)


        def cmap_parameter_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Cmap_parameter_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Cmap_parameter_statementContext,i)


        def cmap_index_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Cmap_index_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Cmap_index_statementContext,i)


        def dihedral_force_constant_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Dihedral_force_constant_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Dihedral_force_constant_statementContext,i)


        def dihedral_periodicity_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Dihedral_periodicity_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Dihedral_periodicity_statementContext,i)


        def dihedral_phase_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Dihedral_phase_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Dihedral_phase_statementContext,i)


        def dihedrals_inc_hydrogen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Dihedrals_inc_hydrogen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Dihedrals_inc_hydrogen_statementContext,i)


        def dihedrals_without_hydrogen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Dihedrals_without_hydrogen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Dihedrals_without_hydrogen_statementContext,i)


        def excluded_atoms_list_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Excluded_atoms_list_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Excluded_atoms_list_statementContext,i)


        def hbcut_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Hbcut_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Hbcut_statementContext,i)


        def hbond_acoef_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Hbond_acoef_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Hbond_acoef_statementContext,i)


        def hbond_bcoef_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Hbond_bcoef_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Hbond_bcoef_statementContext,i)


        def ipol_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Ipol_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Ipol_statementContext,i)


        def irotat_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Irotat_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Irotat_statementContext,i)


        def join_array_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Join_array_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Join_array_statementContext,i)


        def lennard_jones_acoef_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Lennard_jones_acoef_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Lennard_jones_acoef_statementContext,i)


        def lennard_jones_bcoef_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Lennard_jones_bcoef_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Lennard_jones_bcoef_statementContext,i)


        def mass_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Mass_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Mass_statementContext,i)


        def nonbonded_parm_index_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Nonbonded_parm_index_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Nonbonded_parm_index_statementContext,i)


        def number_excluded_atoms_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Number_excluded_atoms_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Number_excluded_atoms_statementContext,i)


        def pointers_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Pointers_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Pointers_statementContext,i)


        def polarizability_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Polarizability_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Polarizability_statementContext,i)


        def radii_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Radii_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Radii_statementContext,i)


        def radius_set_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Radius_set_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Radius_set_statementContext,i)


        def residue_label_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Residue_label_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Residue_label_statementContext,i)


        def residue_pointer_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Residue_pointer_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Residue_pointer_statementContext,i)


        def scee_scale_factor_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Scee_scale_factor_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Scee_scale_factor_statementContext,i)


        def scnb_scale_factor_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Scnb_scale_factor_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Scnb_scale_factor_statementContext,i)


        def screen_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Screen_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Screen_statementContext,i)


        def solty_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Solty_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Solty_statementContext,i)


        def solvent_pointers_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Solvent_pointers_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Solvent_pointers_statementContext,i)


        def title_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Title_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Title_statementContext,i)


        def tree_chain_classification_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AmberPTParser.Tree_chain_classification_statementContext)
            else:
                return self.getTypedRuleContext(AmberPTParser.Tree_chain_classification_statementContext,i)


        def getRuleIndex(self):
            return AmberPTParser.RULE_amber_pt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAmber_pt" ):
                listener.enterAmber_pt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAmber_pt" ):
                listener.exitAmber_pt(self)




    def amber_pt(self):

        localctx = AmberPTParser.Amber_ptContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_amber_pt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.state = 108
                self.version_statement()
                pass
            elif token in [2]:
                self.state = 109
                self.match(AmberPTParser.FLAG)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 165
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while ((((_la - 3)) & ~0x3f) == 0 and ((1 << (_la - 3)) & -1) != 0):
                self.state = 163
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [3]:
                    self.state = 112
                    self.amber_atom_type_statement()
                    pass
                elif token in [4]:
                    self.state = 113
                    self.angle_equil_value_statement()
                    pass
                elif token in [5]:
                    self.state = 114
                    self.angle_force_constant_statement()
                    pass
                elif token in [6]:
                    self.state = 115
                    self.angles_inc_hydrogen_statement()
                    pass
                elif token in [7]:
                    self.state = 116
                    self.angles_without_hydrogen_statement()
                    pass
                elif token in [8]:
                    self.state = 117
                    self.atomic_number_statement()
                    pass
                elif token in [9]:
                    self.state = 118
                    self.atom_name_statement()
                    pass
                elif token in [10]:
                    self.state = 119
                    self.atom_type_index_statement()
                    pass
                elif token in [11]:
                    self.state = 120
                    self.atoms_per_molecule_statement()
                    pass
                elif token in [12]:
                    self.state = 121
                    self.bond_equil_value_statement()
                    pass
                elif token in [13]:
                    self.state = 122
                    self.bond_force_constant_statement()
                    pass
                elif token in [14]:
                    self.state = 123
                    self.bonds_inc_hydrogen_statement()
                    pass
                elif token in [15]:
                    self.state = 124
                    self.bonds_without_hydrogen_statement()
                    pass
                elif token in [16]:
                    self.state = 125
                    self.box_dimensions_statement()
                    pass
                elif token in [17]:
                    self.state = 126
                    self.cap_info_statement()
                    pass
                elif token in [18]:
                    self.state = 127
                    self.cap_info2_statement()
                    pass
                elif token in [19]:
                    self.state = 128
                    self.charge_statement()
                    pass
                elif token in [20]:
                    self.state = 129
                    self.cmap_count_statement()
                    pass
                elif token in [21]:
                    self.state = 130
                    self.cmap_resolution_statement()
                    pass
                elif token in [22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]:
                    self.state = 131
                    self.cmap_parameter_statement()
                    pass
                elif token in [36]:
                    self.state = 132
                    self.cmap_index_statement()
                    pass
                elif token in [37]:
                    self.state = 133
                    self.dihedral_force_constant_statement()
                    pass
                elif token in [38]:
                    self.state = 134
                    self.dihedral_periodicity_statement()
                    pass
                elif token in [39]:
                    self.state = 135
                    self.dihedral_phase_statement()
                    pass
                elif token in [40]:
                    self.state = 136
                    self.dihedrals_inc_hydrogen_statement()
                    pass
                elif token in [41]:
                    self.state = 137
                    self.dihedrals_without_hydrogen_statement()
                    pass
                elif token in [42]:
                    self.state = 138
                    self.excluded_atoms_list_statement()
                    pass
                elif token in [43]:
                    self.state = 139
                    self.hbcut_statement()
                    pass
                elif token in [44]:
                    self.state = 140
                    self.hbond_acoef_statement()
                    pass
                elif token in [45]:
                    self.state = 141
                    self.hbond_bcoef_statement()
                    pass
                elif token in [46]:
                    self.state = 142
                    self.ipol_statement()
                    pass
                elif token in [47]:
                    self.state = 143
                    self.irotat_statement()
                    pass
                elif token in [48]:
                    self.state = 144
                    self.join_array_statement()
                    pass
                elif token in [49]:
                    self.state = 145
                    self.lennard_jones_acoef_statement()
                    pass
                elif token in [50]:
                    self.state = 146
                    self.lennard_jones_bcoef_statement()
                    pass
                elif token in [51]:
                    self.state = 147
                    self.mass_statement()
                    pass
                elif token in [52]:
                    self.state = 148
                    self.nonbonded_parm_index_statement()
                    pass
                elif token in [53]:
                    self.state = 149
                    self.number_excluded_atoms_statement()
                    pass
                elif token in [54]:
                    self.state = 150
                    self.pointers_statement()
                    pass
                elif token in [55]:
                    self.state = 151
                    self.polarizability_statement()
                    pass
                elif token in [56]:
                    self.state = 152
                    self.radii_statement()
                    pass
                elif token in [57]:
                    self.state = 153
                    self.radius_set_statement()
                    pass
                elif token in [58]:
                    self.state = 154
                    self.residue_label_statement()
                    pass
                elif token in [59]:
                    self.state = 155
                    self.residue_pointer_statement()
                    pass
                elif token in [60]:
                    self.state = 156
                    self.scee_scale_factor_statement()
                    pass
                elif token in [61]:
                    self.state = 157
                    self.scnb_scale_factor_statement()
                    pass
                elif token in [62]:
                    self.state = 158
                    self.screen_statement()
                    pass
                elif token in [63]:
                    self.state = 159
                    self.solty_statement()
                    pass
                elif token in [64]:
                    self.state = 160
                    self.solvent_pointers_statement()
                    pass
                elif token in [65]:
                    self.state = 161
                    self.title_statement()
                    pass
                elif token in [66]:
                    self.state = 162
                    self.tree_chain_classification_statement()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 167
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 168
            self.match(AmberPTParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Version_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VERSION(self):
            return self.getToken(AmberPTParser.VERSION, 0)

        def VERSION_STAMP(self):
            return self.getToken(AmberPTParser.VERSION_STAMP, 0)

        def Equ_op(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Equ_op)
            else:
                return self.getToken(AmberPTParser.Equ_op, i)

        def Version(self):
            return self.getToken(AmberPTParser.Version, 0)

        def DATE(self):
            return self.getToken(AmberPTParser.DATE, 0)

        def Date_time(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Date_time)
            else:
                return self.getToken(AmberPTParser.Date_time, i)

        def FLAG_VS(self):
            return self.getToken(AmberPTParser.FLAG_VS, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def getRuleIndex(self):
            return AmberPTParser.RULE_version_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVersion_statement" ):
                listener.enterVersion_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVersion_statement" ):
                listener.exitVersion_statement(self)




    def version_statement(self):

        localctx = AmberPTParser.Version_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_version_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.match(AmberPTParser.VERSION)
            self.state = 171
            self.match(AmberPTParser.VERSION_STAMP)
            self.state = 172
            self.match(AmberPTParser.Equ_op)
            self.state = 173
            self.match(AmberPTParser.Version)
            self.state = 174
            self.match(AmberPTParser.DATE)
            self.state = 175
            self.match(AmberPTParser.Equ_op)
            self.state = 176
            self.match(AmberPTParser.Date_time)
            self.state = 178
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==77:
                self.state = 177
                self.match(AmberPTParser.Date_time)


            self.state = 180
            _la = self._input.LA(1)
            if not(_la==-1 or _la==79):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Amber_atom_type_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AMBER_ATOM_TYPE(self):
            return self.getToken(AmberPTParser.AMBER_ATOM_TYPE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_AA(self):
            return self.getToken(AmberPTParser.FLAG_AA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Simple_name)
            else:
                return self.getToken(AmberPTParser.Simple_name, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_amber_atom_type_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAmber_atom_type_statement" ):
                listener.enterAmber_atom_type_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAmber_atom_type_statement" ):
                listener.exitAmber_atom_type_statement(self)




    def amber_atom_type_statement(self):

        localctx = AmberPTParser.Amber_atom_type_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_amber_atom_type_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self.match(AmberPTParser.AMBER_ATOM_TYPE)
            self.state = 183
            self.format_function()
            self.state = 187
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==83:
                self.state = 184
                self.match(AmberPTParser.Simple_name)
                self.state = 189
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 190
            _la = self._input.LA(1)
            if not(_la==-1 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angle_equil_value_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ANGLE_EQUIL_VALUE(self):
            return self.getToken(AmberPTParser.ANGLE_EQUIL_VALUE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_angle_equil_value_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngle_equil_value_statement" ):
                listener.enterAngle_equil_value_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngle_equil_value_statement" ):
                listener.exitAngle_equil_value_statement(self)




    def angle_equil_value_statement(self):

        localctx = AmberPTParser.Angle_equil_value_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_angle_equil_value_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 192
            self.match(AmberPTParser.ANGLE_EQUIL_VALUE)
            self.state = 193
            self.format_function()
            self.state = 197
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 194
                self.match(AmberPTParser.Real)
                self.state = 199
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 200
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angle_force_constant_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ANGLE_FORCE_CONSTANT(self):
            return self.getToken(AmberPTParser.ANGLE_FORCE_CONSTANT, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_angle_force_constant_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngle_force_constant_statement" ):
                listener.enterAngle_force_constant_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngle_force_constant_statement" ):
                listener.exitAngle_force_constant_statement(self)




    def angle_force_constant_statement(self):

        localctx = AmberPTParser.Angle_force_constant_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_angle_force_constant_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.match(AmberPTParser.ANGLE_FORCE_CONSTANT)
            self.state = 203
            self.format_function()
            self.state = 207
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 204
                self.match(AmberPTParser.Real)
                self.state = 209
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 210
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angles_inc_hydrogen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ANGLES_INC_HYDROGEN(self):
            return self.getToken(AmberPTParser.ANGLES_INC_HYDROGEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_angles_inc_hydrogen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngles_inc_hydrogen_statement" ):
                listener.enterAngles_inc_hydrogen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngles_inc_hydrogen_statement" ):
                listener.exitAngles_inc_hydrogen_statement(self)




    def angles_inc_hydrogen_statement(self):

        localctx = AmberPTParser.Angles_inc_hydrogen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_angles_inc_hydrogen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.match(AmberPTParser.ANGLES_INC_HYDROGEN)
            self.state = 213
            self.format_function()
            self.state = 217
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 214
                self.match(AmberPTParser.Integer)
                self.state = 219
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 220
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angles_without_hydrogen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ANGLES_WITHOUT_HYDROGEN(self):
            return self.getToken(AmberPTParser.ANGLES_WITHOUT_HYDROGEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_angles_without_hydrogen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngles_without_hydrogen_statement" ):
                listener.enterAngles_without_hydrogen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngles_without_hydrogen_statement" ):
                listener.exitAngles_without_hydrogen_statement(self)




    def angles_without_hydrogen_statement(self):

        localctx = AmberPTParser.Angles_without_hydrogen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_angles_without_hydrogen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.match(AmberPTParser.ANGLES_WITHOUT_HYDROGEN)
            self.state = 223
            self.format_function()
            self.state = 227
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 224
                self.match(AmberPTParser.Integer)
                self.state = 229
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 230
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atomic_number_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATOMIC_NUMBER(self):
            return self.getToken(AmberPTParser.ATOMIC_NUMBER, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_atomic_number_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomic_number_statement" ):
                listener.enterAtomic_number_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomic_number_statement" ):
                listener.exitAtomic_number_statement(self)




    def atomic_number_statement(self):

        localctx = AmberPTParser.Atomic_number_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_atomic_number_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 232
            self.match(AmberPTParser.ATOMIC_NUMBER)
            self.state = 233
            self.format_function()
            self.state = 237
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 234
                self.match(AmberPTParser.Integer)
                self.state = 239
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 240
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_name_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATOM_NAME(self):
            return self.getToken(AmberPTParser.ATOM_NAME, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_AA(self):
            return self.getToken(AmberPTParser.FLAG_AA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Simple_name)
            else:
                return self.getToken(AmberPTParser.Simple_name, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_atom_name_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_name_statement" ):
                listener.enterAtom_name_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_name_statement" ):
                listener.exitAtom_name_statement(self)




    def atom_name_statement(self):

        localctx = AmberPTParser.Atom_name_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_atom_name_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            self.match(AmberPTParser.ATOM_NAME)
            self.state = 243
            self.format_function()
            self.state = 247
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==83:
                self.state = 244
                self.match(AmberPTParser.Simple_name)
                self.state = 249
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 250
            _la = self._input.LA(1)
            if not(_la==-1 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atom_type_index_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATOM_TYPE_INDEX(self):
            return self.getToken(AmberPTParser.ATOM_TYPE_INDEX, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_atom_type_index_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom_type_index_statement" ):
                listener.enterAtom_type_index_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom_type_index_statement" ):
                listener.exitAtom_type_index_statement(self)




    def atom_type_index_statement(self):

        localctx = AmberPTParser.Atom_type_index_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_atom_type_index_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 252
            self.match(AmberPTParser.ATOM_TYPE_INDEX)
            self.state = 253
            self.format_function()
            self.state = 257
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 254
                self.match(AmberPTParser.Integer)
                self.state = 259
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 260
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atoms_per_molecule_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATOMS_PER_MOLECULE(self):
            return self.getToken(AmberPTParser.ATOMS_PER_MOLECULE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_atoms_per_molecule_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtoms_per_molecule_statement" ):
                listener.enterAtoms_per_molecule_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtoms_per_molecule_statement" ):
                listener.exitAtoms_per_molecule_statement(self)




    def atoms_per_molecule_statement(self):

        localctx = AmberPTParser.Atoms_per_molecule_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_atoms_per_molecule_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 262
            self.match(AmberPTParser.ATOMS_PER_MOLECULE)
            self.state = 263
            self.format_function()
            self.state = 267
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 264
                self.match(AmberPTParser.Integer)
                self.state = 269
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 270
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bond_equil_value_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOND_EQUIL_VALUE(self):
            return self.getToken(AmberPTParser.BOND_EQUIL_VALUE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_bond_equil_value_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBond_equil_value_statement" ):
                listener.enterBond_equil_value_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBond_equil_value_statement" ):
                listener.exitBond_equil_value_statement(self)




    def bond_equil_value_statement(self):

        localctx = AmberPTParser.Bond_equil_value_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_bond_equil_value_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 272
            self.match(AmberPTParser.BOND_EQUIL_VALUE)
            self.state = 273
            self.format_function()
            self.state = 277
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 274
                self.match(AmberPTParser.Real)
                self.state = 279
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 280
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bond_force_constant_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOND_FORCE_CONSTANT(self):
            return self.getToken(AmberPTParser.BOND_FORCE_CONSTANT, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_bond_force_constant_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBond_force_constant_statement" ):
                listener.enterBond_force_constant_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBond_force_constant_statement" ):
                listener.exitBond_force_constant_statement(self)




    def bond_force_constant_statement(self):

        localctx = AmberPTParser.Bond_force_constant_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_bond_force_constant_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 282
            self.match(AmberPTParser.BOND_FORCE_CONSTANT)
            self.state = 283
            self.format_function()
            self.state = 287
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 284
                self.match(AmberPTParser.Real)
                self.state = 289
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 290
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bonds_inc_hydrogen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BONDS_INC_HYDROGEN(self):
            return self.getToken(AmberPTParser.BONDS_INC_HYDROGEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_bonds_inc_hydrogen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBonds_inc_hydrogen_statement" ):
                listener.enterBonds_inc_hydrogen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBonds_inc_hydrogen_statement" ):
                listener.exitBonds_inc_hydrogen_statement(self)




    def bonds_inc_hydrogen_statement(self):

        localctx = AmberPTParser.Bonds_inc_hydrogen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_bonds_inc_hydrogen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 292
            self.match(AmberPTParser.BONDS_INC_HYDROGEN)
            self.state = 293
            self.format_function()
            self.state = 297
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 294
                self.match(AmberPTParser.Integer)
                self.state = 299
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 300
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bonds_without_hydrogen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BONDS_WITHOUT_HYDROGEN(self):
            return self.getToken(AmberPTParser.BONDS_WITHOUT_HYDROGEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_bonds_without_hydrogen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBonds_without_hydrogen_statement" ):
                listener.enterBonds_without_hydrogen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBonds_without_hydrogen_statement" ):
                listener.exitBonds_without_hydrogen_statement(self)




    def bonds_without_hydrogen_statement(self):

        localctx = AmberPTParser.Bonds_without_hydrogen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_bonds_without_hydrogen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.match(AmberPTParser.BONDS_WITHOUT_HYDROGEN)
            self.state = 303
            self.format_function()
            self.state = 307
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 304
                self.match(AmberPTParser.Integer)
                self.state = 309
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 310
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Box_dimensions_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOX_DIMENSIONS(self):
            return self.getToken(AmberPTParser.BOX_DIMENSIONS, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_box_dimensions_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBox_dimensions_statement" ):
                listener.enterBox_dimensions_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBox_dimensions_statement" ):
                listener.exitBox_dimensions_statement(self)




    def box_dimensions_statement(self):

        localctx = AmberPTParser.Box_dimensions_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_box_dimensions_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 312
            self.match(AmberPTParser.BOX_DIMENSIONS)
            self.state = 313
            self.format_function()
            self.state = 317
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 314
                self.match(AmberPTParser.Real)
                self.state = 319
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 320
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cap_info_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CAP_INFO(self):
            return self.getToken(AmberPTParser.CAP_INFO, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_cap_info_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCap_info_statement" ):
                listener.enterCap_info_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCap_info_statement" ):
                listener.exitCap_info_statement(self)




    def cap_info_statement(self):

        localctx = AmberPTParser.Cap_info_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_cap_info_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.match(AmberPTParser.CAP_INFO)
            self.state = 323
            self.format_function()
            self.state = 327
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 324
                self.match(AmberPTParser.Integer)
                self.state = 329
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 330
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cap_info2_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CAP_INFO2(self):
            return self.getToken(AmberPTParser.CAP_INFO2, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_cap_info2_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCap_info2_statement" ):
                listener.enterCap_info2_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCap_info2_statement" ):
                listener.exitCap_info2_statement(self)




    def cap_info2_statement(self):

        localctx = AmberPTParser.Cap_info2_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_cap_info2_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 332
            self.match(AmberPTParser.CAP_INFO2)
            self.state = 333
            self.format_function()
            self.state = 337
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 334
                self.match(AmberPTParser.Real)
                self.state = 339
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 340
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Charge_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHARGE(self):
            return self.getToken(AmberPTParser.CHARGE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_charge_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCharge_statement" ):
                listener.enterCharge_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCharge_statement" ):
                listener.exitCharge_statement(self)




    def charge_statement(self):

        localctx = AmberPTParser.Charge_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_charge_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 342
            self.match(AmberPTParser.CHARGE)
            self.state = 343
            self.format_function()
            self.state = 347
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 344
                self.match(AmberPTParser.Real)
                self.state = 349
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 350
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cmap_count_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CMAP_COUNT(self):
            return self.getToken(AmberPTParser.CMAP_COUNT, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_cmap_count_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCmap_count_statement" ):
                listener.enterCmap_count_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCmap_count_statement" ):
                listener.exitCmap_count_statement(self)




    def cmap_count_statement(self):

        localctx = AmberPTParser.Cmap_count_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_cmap_count_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 352
            self.match(AmberPTParser.CMAP_COUNT)
            self.state = 353
            self.format_function()
            self.state = 357
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 354
                self.match(AmberPTParser.Integer)
                self.state = 359
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 360
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cmap_resolution_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CMAP_RESOLUTION(self):
            return self.getToken(AmberPTParser.CMAP_RESOLUTION, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_cmap_resolution_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCmap_resolution_statement" ):
                listener.enterCmap_resolution_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCmap_resolution_statement" ):
                listener.exitCmap_resolution_statement(self)




    def cmap_resolution_statement(self):

        localctx = AmberPTParser.Cmap_resolution_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_cmap_resolution_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 362
            self.match(AmberPTParser.CMAP_RESOLUTION)
            self.state = 363
            self.format_function()
            self.state = 367
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 364
                self.match(AmberPTParser.Integer)
                self.state = 369
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 370
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cmap_parameter_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def CMAP_PARAMETER_01(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_01, 0)

        def CMAP_PARAMETER_02(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_02, 0)

        def CMAP_PARAMETER_03(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_03, 0)

        def CMAP_PARAMETER_04(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_04, 0)

        def CMAP_PARAMETER_05(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_05, 0)

        def CMAP_PARAMETER_06(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_06, 0)

        def CMAP_PARAMETER_07(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_07, 0)

        def CMAP_PARAMETER_08(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_08, 0)

        def CMAP_PARAMETER_09(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_09, 0)

        def CMAP_PARAMETER_10(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_10, 0)

        def CMAP_PARAMETER_11(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_11, 0)

        def CMAP_PARAMETER_12(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_12, 0)

        def CMAP_PARAMETER_13(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_13, 0)

        def CMAP_PARAMETER_14(self):
            return self.getToken(AmberPTParser.CMAP_PARAMETER_14, 0)

        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_cmap_parameter_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCmap_parameter_statement" ):
                listener.enterCmap_parameter_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCmap_parameter_statement" ):
                listener.exitCmap_parameter_statement(self)




    def cmap_parameter_statement(self):

        localctx = AmberPTParser.Cmap_parameter_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_cmap_parameter_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 372
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 68715282432) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 373
            self.format_function()
            self.state = 377
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 374
                self.match(AmberPTParser.Real)
                self.state = 379
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 380
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cmap_index_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CMAP_INDEX(self):
            return self.getToken(AmberPTParser.CMAP_INDEX, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_cmap_index_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCmap_index_statement" ):
                listener.enterCmap_index_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCmap_index_statement" ):
                listener.exitCmap_index_statement(self)




    def cmap_index_statement(self):

        localctx = AmberPTParser.Cmap_index_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_cmap_index_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 382
            self.match(AmberPTParser.CMAP_INDEX)
            self.state = 383
            self.format_function()
            self.state = 387
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 384
                self.match(AmberPTParser.Integer)
                self.state = 389
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 390
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_force_constant_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIHEDRAL_FORCE_CONSTANT(self):
            return self.getToken(AmberPTParser.DIHEDRAL_FORCE_CONSTANT, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_dihedral_force_constant_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_force_constant_statement" ):
                listener.enterDihedral_force_constant_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_force_constant_statement" ):
                listener.exitDihedral_force_constant_statement(self)




    def dihedral_force_constant_statement(self):

        localctx = AmberPTParser.Dihedral_force_constant_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_dihedral_force_constant_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 392
            self.match(AmberPTParser.DIHEDRAL_FORCE_CONSTANT)
            self.state = 393
            self.format_function()
            self.state = 397
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 394
                self.match(AmberPTParser.Real)
                self.state = 399
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 400
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_periodicity_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIHEDRAL_PERIODICITY(self):
            return self.getToken(AmberPTParser.DIHEDRAL_PERIODICITY, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_dihedral_periodicity_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_periodicity_statement" ):
                listener.enterDihedral_periodicity_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_periodicity_statement" ):
                listener.exitDihedral_periodicity_statement(self)




    def dihedral_periodicity_statement(self):

        localctx = AmberPTParser.Dihedral_periodicity_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_dihedral_periodicity_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 402
            self.match(AmberPTParser.DIHEDRAL_PERIODICITY)
            self.state = 403
            self.format_function()
            self.state = 407
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 404
                self.match(AmberPTParser.Real)
                self.state = 409
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 410
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedral_phase_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIHEDRAL_PHASE(self):
            return self.getToken(AmberPTParser.DIHEDRAL_PHASE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_dihedral_phase_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedral_phase_statement" ):
                listener.enterDihedral_phase_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedral_phase_statement" ):
                listener.exitDihedral_phase_statement(self)




    def dihedral_phase_statement(self):

        localctx = AmberPTParser.Dihedral_phase_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_dihedral_phase_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 412
            self.match(AmberPTParser.DIHEDRAL_PHASE)
            self.state = 413
            self.format_function()
            self.state = 417
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 414
                self.match(AmberPTParser.Real)
                self.state = 419
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 420
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedrals_inc_hydrogen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIHEDRALS_INC_HYDROGEN(self):
            return self.getToken(AmberPTParser.DIHEDRALS_INC_HYDROGEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_dihedrals_inc_hydrogen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedrals_inc_hydrogen_statement" ):
                listener.enterDihedrals_inc_hydrogen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedrals_inc_hydrogen_statement" ):
                listener.exitDihedrals_inc_hydrogen_statement(self)




    def dihedrals_inc_hydrogen_statement(self):

        localctx = AmberPTParser.Dihedrals_inc_hydrogen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_dihedrals_inc_hydrogen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 422
            self.match(AmberPTParser.DIHEDRALS_INC_HYDROGEN)
            self.state = 423
            self.format_function()
            self.state = 427
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 424
                self.match(AmberPTParser.Integer)
                self.state = 429
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 430
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedrals_without_hydrogen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIHEDRALS_WITHOUT_HYDROGEN(self):
            return self.getToken(AmberPTParser.DIHEDRALS_WITHOUT_HYDROGEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_dihedrals_without_hydrogen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedrals_without_hydrogen_statement" ):
                listener.enterDihedrals_without_hydrogen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedrals_without_hydrogen_statement" ):
                listener.exitDihedrals_without_hydrogen_statement(self)




    def dihedrals_without_hydrogen_statement(self):

        localctx = AmberPTParser.Dihedrals_without_hydrogen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_dihedrals_without_hydrogen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 432
            self.match(AmberPTParser.DIHEDRALS_WITHOUT_HYDROGEN)
            self.state = 433
            self.format_function()
            self.state = 437
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 434
                self.match(AmberPTParser.Integer)
                self.state = 439
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 440
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Excluded_atoms_list_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EXCLUDED_ATOMS_LIST(self):
            return self.getToken(AmberPTParser.EXCLUDED_ATOMS_LIST, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_excluded_atoms_list_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExcluded_atoms_list_statement" ):
                listener.enterExcluded_atoms_list_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExcluded_atoms_list_statement" ):
                listener.exitExcluded_atoms_list_statement(self)




    def excluded_atoms_list_statement(self):

        localctx = AmberPTParser.Excluded_atoms_list_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_excluded_atoms_list_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 442
            self.match(AmberPTParser.EXCLUDED_ATOMS_LIST)
            self.state = 443
            self.format_function()
            self.state = 447
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 444
                self.match(AmberPTParser.Integer)
                self.state = 449
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 450
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Hbcut_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HBCUT(self):
            return self.getToken(AmberPTParser.HBCUT, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_hbcut_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHbcut_statement" ):
                listener.enterHbcut_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHbcut_statement" ):
                listener.exitHbcut_statement(self)




    def hbcut_statement(self):

        localctx = AmberPTParser.Hbcut_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_hbcut_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 452
            self.match(AmberPTParser.HBCUT)
            self.state = 453
            self.format_function()
            self.state = 457
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 454
                self.match(AmberPTParser.Real)
                self.state = 459
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 460
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Hbond_acoef_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HBOND_ACOEF(self):
            return self.getToken(AmberPTParser.HBOND_ACOEF, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_hbond_acoef_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHbond_acoef_statement" ):
                listener.enterHbond_acoef_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHbond_acoef_statement" ):
                listener.exitHbond_acoef_statement(self)




    def hbond_acoef_statement(self):

        localctx = AmberPTParser.Hbond_acoef_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_hbond_acoef_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 462
            self.match(AmberPTParser.HBOND_ACOEF)
            self.state = 463
            self.format_function()
            self.state = 467
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 464
                self.match(AmberPTParser.Real)
                self.state = 469
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 470
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Hbond_bcoef_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HBOND_BCOEF(self):
            return self.getToken(AmberPTParser.HBOND_BCOEF, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_hbond_bcoef_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHbond_bcoef_statement" ):
                listener.enterHbond_bcoef_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHbond_bcoef_statement" ):
                listener.exitHbond_bcoef_statement(self)




    def hbond_bcoef_statement(self):

        localctx = AmberPTParser.Hbond_bcoef_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_hbond_bcoef_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 472
            self.match(AmberPTParser.HBOND_BCOEF)
            self.state = 473
            self.format_function()
            self.state = 477
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 474
                self.match(AmberPTParser.Real)
                self.state = 479
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 480
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ipol_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IPOL(self):
            return self.getToken(AmberPTParser.IPOL, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_ipol_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIpol_statement" ):
                listener.enterIpol_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIpol_statement" ):
                listener.exitIpol_statement(self)




    def ipol_statement(self):

        localctx = AmberPTParser.Ipol_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_ipol_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 482
            self.match(AmberPTParser.IPOL)
            self.state = 483
            self.format_function()
            self.state = 487
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 484
                self.match(AmberPTParser.Integer)
                self.state = 489
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 490
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Irotat_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IROTAT(self):
            return self.getToken(AmberPTParser.IROTAT, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_irotat_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIrotat_statement" ):
                listener.enterIrotat_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIrotat_statement" ):
                listener.exitIrotat_statement(self)




    def irotat_statement(self):

        localctx = AmberPTParser.Irotat_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_irotat_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 492
            self.match(AmberPTParser.IROTAT)
            self.state = 493
            self.format_function()
            self.state = 497
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 494
                self.match(AmberPTParser.Integer)
                self.state = 499
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 500
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Join_array_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def JOIN_ARRAY(self):
            return self.getToken(AmberPTParser.JOIN_ARRAY, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_join_array_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoin_array_statement" ):
                listener.enterJoin_array_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoin_array_statement" ):
                listener.exitJoin_array_statement(self)




    def join_array_statement(self):

        localctx = AmberPTParser.Join_array_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_join_array_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 502
            self.match(AmberPTParser.JOIN_ARRAY)
            self.state = 503
            self.format_function()
            self.state = 507
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 504
                self.match(AmberPTParser.Integer)
                self.state = 509
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 510
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Lennard_jones_acoef_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LENNARD_JONES_ACOEF(self):
            return self.getToken(AmberPTParser.LENNARD_JONES_ACOEF, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_lennard_jones_acoef_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLennard_jones_acoef_statement" ):
                listener.enterLennard_jones_acoef_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLennard_jones_acoef_statement" ):
                listener.exitLennard_jones_acoef_statement(self)




    def lennard_jones_acoef_statement(self):

        localctx = AmberPTParser.Lennard_jones_acoef_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_lennard_jones_acoef_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 512
            self.match(AmberPTParser.LENNARD_JONES_ACOEF)
            self.state = 513
            self.format_function()
            self.state = 517
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 514
                self.match(AmberPTParser.Real)
                self.state = 519
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 520
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Lennard_jones_bcoef_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LENNARD_JONES_BCOEF(self):
            return self.getToken(AmberPTParser.LENNARD_JONES_BCOEF, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_lennard_jones_bcoef_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLennard_jones_bcoef_statement" ):
                listener.enterLennard_jones_bcoef_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLennard_jones_bcoef_statement" ):
                listener.exitLennard_jones_bcoef_statement(self)




    def lennard_jones_bcoef_statement(self):

        localctx = AmberPTParser.Lennard_jones_bcoef_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_lennard_jones_bcoef_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 522
            self.match(AmberPTParser.LENNARD_JONES_BCOEF)
            self.state = 523
            self.format_function()
            self.state = 527
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 524
                self.match(AmberPTParser.Real)
                self.state = 529
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 530
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mass_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MASS(self):
            return self.getToken(AmberPTParser.MASS, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_mass_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMass_statement" ):
                listener.enterMass_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMass_statement" ):
                listener.exitMass_statement(self)




    def mass_statement(self):

        localctx = AmberPTParser.Mass_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_mass_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 532
            self.match(AmberPTParser.MASS)
            self.state = 533
            self.format_function()
            self.state = 537
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 534
                self.match(AmberPTParser.Real)
                self.state = 539
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 540
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nonbonded_parm_index_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NONBONDED_PARM_INDEX(self):
            return self.getToken(AmberPTParser.NONBONDED_PARM_INDEX, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_nonbonded_parm_index_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNonbonded_parm_index_statement" ):
                listener.enterNonbonded_parm_index_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNonbonded_parm_index_statement" ):
                listener.exitNonbonded_parm_index_statement(self)




    def nonbonded_parm_index_statement(self):

        localctx = AmberPTParser.Nonbonded_parm_index_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_nonbonded_parm_index_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 542
            self.match(AmberPTParser.NONBONDED_PARM_INDEX)
            self.state = 543
            self.format_function()
            self.state = 547
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 544
                self.match(AmberPTParser.Integer)
                self.state = 549
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 550
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Number_excluded_atoms_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER_EXCLUDED_ATOMS(self):
            return self.getToken(AmberPTParser.NUMBER_EXCLUDED_ATOMS, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_number_excluded_atoms_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber_excluded_atoms_statement" ):
                listener.enterNumber_excluded_atoms_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber_excluded_atoms_statement" ):
                listener.exitNumber_excluded_atoms_statement(self)




    def number_excluded_atoms_statement(self):

        localctx = AmberPTParser.Number_excluded_atoms_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_number_excluded_atoms_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 552
            self.match(AmberPTParser.NUMBER_EXCLUDED_ATOMS)
            self.state = 553
            self.format_function()
            self.state = 557
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 554
                self.match(AmberPTParser.Integer)
                self.state = 559
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 560
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pointers_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def POINTERS(self):
            return self.getToken(AmberPTParser.POINTERS, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_pointers_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPointers_statement" ):
                listener.enterPointers_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPointers_statement" ):
                listener.exitPointers_statement(self)




    def pointers_statement(self):

        localctx = AmberPTParser.Pointers_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_pointers_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 562
            self.match(AmberPTParser.POINTERS)
            self.state = 563
            self.format_function()
            self.state = 567
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 564
                self.match(AmberPTParser.Integer)
                self.state = 569
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 570
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Polarizability_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def POLARIZABILITY(self):
            return self.getToken(AmberPTParser.POLARIZABILITY, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_polarizability_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPolarizability_statement" ):
                listener.enterPolarizability_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPolarizability_statement" ):
                listener.exitPolarizability_statement(self)




    def polarizability_statement(self):

        localctx = AmberPTParser.Polarizability_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_polarizability_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 572
            self.match(AmberPTParser.POLARIZABILITY)
            self.state = 573
            self.format_function()
            self.state = 577
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 574
                self.match(AmberPTParser.Real)
                self.state = 579
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 580
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Radii_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RADII(self):
            return self.getToken(AmberPTParser.RADII, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_radii_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRadii_statement" ):
                listener.enterRadii_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRadii_statement" ):
                listener.exitRadii_statement(self)




    def radii_statement(self):

        localctx = AmberPTParser.Radii_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_radii_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 582
            self.match(AmberPTParser.RADII)
            self.state = 583
            self.format_function()
            self.state = 587
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 584
                self.match(AmberPTParser.Real)
                self.state = 589
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 590
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Radius_set_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RADIUS_SET(self):
            return self.getToken(AmberPTParser.RADIUS_SET, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_AA(self):
            return self.getToken(AmberPTParser.FLAG_AA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Simple_name)
            else:
                return self.getToken(AmberPTParser.Simple_name, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_radius_set_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRadius_set_statement" ):
                listener.enterRadius_set_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRadius_set_statement" ):
                listener.exitRadius_set_statement(self)




    def radius_set_statement(self):

        localctx = AmberPTParser.Radius_set_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_radius_set_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 592
            self.match(AmberPTParser.RADIUS_SET)
            self.state = 593
            self.format_function()
            self.state = 597
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==83:
                self.state = 594
                self.match(AmberPTParser.Simple_name)
                self.state = 599
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 600
            _la = self._input.LA(1)
            if not(_la==-1 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Residue_label_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RESIDUE_LABEL(self):
            return self.getToken(AmberPTParser.RESIDUE_LABEL, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_AA(self):
            return self.getToken(AmberPTParser.FLAG_AA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Simple_name)
            else:
                return self.getToken(AmberPTParser.Simple_name, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_residue_label_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterResidue_label_statement" ):
                listener.enterResidue_label_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitResidue_label_statement" ):
                listener.exitResidue_label_statement(self)




    def residue_label_statement(self):

        localctx = AmberPTParser.Residue_label_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_residue_label_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 602
            self.match(AmberPTParser.RESIDUE_LABEL)
            self.state = 603
            self.format_function()
            self.state = 607
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==83:
                self.state = 604
                self.match(AmberPTParser.Simple_name)
                self.state = 609
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 610
            _la = self._input.LA(1)
            if not(_la==-1 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Residue_pointer_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RESIDUE_POINTER(self):
            return self.getToken(AmberPTParser.RESIDUE_POINTER, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_residue_pointer_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterResidue_pointer_statement" ):
                listener.enterResidue_pointer_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitResidue_pointer_statement" ):
                listener.exitResidue_pointer_statement(self)




    def residue_pointer_statement(self):

        localctx = AmberPTParser.Residue_pointer_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_residue_pointer_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 612
            self.match(AmberPTParser.RESIDUE_POINTER)
            self.state = 613
            self.format_function()
            self.state = 615 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 614
                self.match(AmberPTParser.Integer)
                self.state = 617 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==86):
                    break

            self.state = 619
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Scee_scale_factor_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SCEE_SCALE_FACTOR(self):
            return self.getToken(AmberPTParser.SCEE_SCALE_FACTOR, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_scee_scale_factor_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScee_scale_factor_statement" ):
                listener.enterScee_scale_factor_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScee_scale_factor_statement" ):
                listener.exitScee_scale_factor_statement(self)




    def scee_scale_factor_statement(self):

        localctx = AmberPTParser.Scee_scale_factor_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_scee_scale_factor_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 621
            self.match(AmberPTParser.SCEE_SCALE_FACTOR)
            self.state = 622
            self.format_function()
            self.state = 626
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 623
                self.match(AmberPTParser.Real)
                self.state = 628
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 629
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Scnb_scale_factor_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SCNB_SCALE_FACTOR(self):
            return self.getToken(AmberPTParser.SCNB_SCALE_FACTOR, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_scnb_scale_factor_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScnb_scale_factor_statement" ):
                listener.enterScnb_scale_factor_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScnb_scale_factor_statement" ):
                listener.exitScnb_scale_factor_statement(self)




    def scnb_scale_factor_statement(self):

        localctx = AmberPTParser.Scnb_scale_factor_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_scnb_scale_factor_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 631
            self.match(AmberPTParser.SCNB_SCALE_FACTOR)
            self.state = 632
            self.format_function()
            self.state = 636
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 633
                self.match(AmberPTParser.Real)
                self.state = 638
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 639
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Screen_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SCREEN(self):
            return self.getToken(AmberPTParser.SCREEN, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_screen_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScreen_statement" ):
                listener.enterScreen_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScreen_statement" ):
                listener.exitScreen_statement(self)




    def screen_statement(self):

        localctx = AmberPTParser.Screen_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_screen_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 641
            self.match(AmberPTParser.SCREEN)
            self.state = 642
            self.format_function()
            self.state = 646
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 643
                self.match(AmberPTParser.Real)
                self.state = 648
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 649
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Solty_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SOLTY(self):
            return self.getToken(AmberPTParser.SOLTY, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_EA(self):
            return self.getToken(AmberPTParser.FLAG_EA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Real)
            else:
                return self.getToken(AmberPTParser.Real, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_solty_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSolty_statement" ):
                listener.enterSolty_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSolty_statement" ):
                listener.exitSolty_statement(self)




    def solty_statement(self):

        localctx = AmberPTParser.Solty_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_solty_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 651
            self.match(AmberPTParser.SOLTY)
            self.state = 652
            self.format_function()
            self.state = 656
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==89:
                self.state = 653
                self.match(AmberPTParser.Real)
                self.state = 658
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 659
            _la = self._input.LA(1)
            if not(_la==-1 or _la==91):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Solvent_pointers_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SOLVENT_POINTERS(self):
            return self.getToken(AmberPTParser.SOLVENT_POINTERS, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_IA(self):
            return self.getToken(AmberPTParser.FLAG_IA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Integer)
            else:
                return self.getToken(AmberPTParser.Integer, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_solvent_pointers_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSolvent_pointers_statement" ):
                listener.enterSolvent_pointers_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSolvent_pointers_statement" ):
                listener.exitSolvent_pointers_statement(self)




    def solvent_pointers_statement(self):

        localctx = AmberPTParser.Solvent_pointers_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_solvent_pointers_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 661
            self.match(AmberPTParser.SOLVENT_POINTERS)
            self.state = 662
            self.format_function()
            self.state = 666
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==86:
                self.state = 663
                self.match(AmberPTParser.Integer)
                self.state = 668
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 669
            _la = self._input.LA(1)
            if not(_la==-1 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Title_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TITLE(self):
            return self.getToken(AmberPTParser.TITLE, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_AA(self):
            return self.getToken(AmberPTParser.FLAG_AA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Simple_name)
            else:
                return self.getToken(AmberPTParser.Simple_name, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_title_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTitle_statement" ):
                listener.enterTitle_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTitle_statement" ):
                listener.exitTitle_statement(self)




    def title_statement(self):

        localctx = AmberPTParser.Title_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_title_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 671
            self.match(AmberPTParser.TITLE)
            self.state = 672
            self.format_function()
            self.state = 676
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==83:
                self.state = 673
                self.match(AmberPTParser.Simple_name)
                self.state = 678
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 679
            _la = self._input.LA(1)
            if not(_la==-1 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tree_chain_classification_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TREE_CHAIN_CLASSIFICATION(self):
            return self.getToken(AmberPTParser.TREE_CHAIN_CLASSIFICATION, 0)

        def format_function(self):
            return self.getTypedRuleContext(AmberPTParser.Format_functionContext,0)


        def FLAG_AA(self):
            return self.getToken(AmberPTParser.FLAG_AA, 0)

        def EOF(self):
            return self.getToken(AmberPTParser.EOF, 0)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(AmberPTParser.Simple_name)
            else:
                return self.getToken(AmberPTParser.Simple_name, i)

        def getRuleIndex(self):
            return AmberPTParser.RULE_tree_chain_classification_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTree_chain_classification_statement" ):
                listener.enterTree_chain_classification_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTree_chain_classification_statement" ):
                listener.exitTree_chain_classification_statement(self)




    def tree_chain_classification_statement(self):

        localctx = AmberPTParser.Tree_chain_classification_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_tree_chain_classification_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 681
            self.match(AmberPTParser.TREE_CHAIN_CLASSIFICATION)
            self.state = 682
            self.format_function()
            self.state = 686
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==83:
                self.state = 683
                self.match(AmberPTParser.Simple_name)
                self.state = 688
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 689
            _la = self._input.LA(1)
            if not(_la==-1 or _la==85):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Format_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FORMAT(self):
            return self.getToken(AmberPTParser.FORMAT, 0)

        def Fortran_format_A(self):
            return self.getToken(AmberPTParser.Fortran_format_A, 0)

        def Fortran_format_I(self):
            return self.getToken(AmberPTParser.Fortran_format_I, 0)

        def Fortran_format_E(self):
            return self.getToken(AmberPTParser.Fortran_format_E, 0)

        def getRuleIndex(self):
            return AmberPTParser.RULE_format_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFormat_function" ):
                listener.enterFormat_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFormat_function" ):
                listener.exitFormat_function(self)




    def format_function(self):

        localctx = AmberPTParser.Format_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_format_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 691
            self.match(AmberPTParser.FORMAT)
            self.state = 692
            _la = self._input.LA(1)
            if not(((((_la - 80)) & ~0x3f) == 0 and ((1 << (_la - 80)) & 7) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





