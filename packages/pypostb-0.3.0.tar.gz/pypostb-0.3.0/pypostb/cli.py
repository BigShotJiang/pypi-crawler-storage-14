"""
命令行接口 - 简化的 CLI，只从 POSCAR 读取参数
"""

import argparse
import os
import sys
import logging
import warnings
from datetime import datetime
from .tight_binding_model import calculate_band_structure, create_pythtb_model
from .parameters import Parameters


class Tee:
    """同时输出到控制台和文件的类"""
    def __init__(self, *files):
        self.files = files
    
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush()
    
    def flush(self):
        for f in self.files:
            f.flush()


def setup_logging(log_file):
    """
    设置日志系统，将所有输出重定向到日志文件
    
    参数:
        log_file (str): 日志文件路径
    """
    # 创建日志目录（如果不存在）
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 打开日志文件
    log_file_handle = open(log_file, 'w', encoding='utf-8')
    
    # 创建 Tee 对象，同时输出到控制台和文件
    tee = Tee(sys.stdout, log_file_handle)
    
    # 重定向 stdout 和 stderr
    sys.stdout = tee
    sys.stderr = tee
    
    # 配置 logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.StreamHandler(tee),
            logging.FileHandler(log_file, mode='w', encoding='utf-8')
        ]
    )
    
    # 捕获 warnings
    warnings.showwarning = lambda message, category, filename, lineno, file=None, line=None: \
        logging.warning(f"{category.__name__}: {message}")
    
    # 打印日志文件信息
    print(f"=" * 80)
    print(f"日志文件: {log_file}")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"=" * 80)
    print()
    
    return log_file_handle


def main():
    parser = argparse.ArgumentParser(
        description="PyPOSTB - 从 POSCAR 文件计算紧束缚模型能带结构"
    )
    parser.add_argument('--version', '-v', action='version', version='%(prog)s 0.3.0')
    
    parser.add_argument('--poscar', '-p', type=str, default='POSCAR',
                       help='POSCAR 文件路径 (默认: POSCAR)')
    parser.add_argument('--output', '-o', type=str, default=None,
                       help='输出文件名 (默认: band_structure)')
    
    args = parser.parse_args()
    
    # 转换为绝对路径
    poscar_path = os.path.abspath(args.poscar)
    if not os.path.exists(poscar_path):
        print(f"错误: POSCAR 文件 '{poscar_path}' 未找到。")
        return 1
    
    # 确定输出文件名
    output_filename = args.output if args.output else "band_structure"
    
    # 设置日志文件路径
    log_file = f"{output_filename}.log"
    log_file_handle = None
    
    try:
        # 设置日志系统
        log_file_handle = setup_logging(log_file)
        
        # 从 POSCAR 读取参数
        print(f"正在从 '{poscar_path}' 读取参数...")
        params = Parameters(poscar_path)
        
        # 设置输出文件名
        params.output_filename = output_filename
        
        print(params)
        print()
        
        # 创建并计算模型
        print("正在创建紧束缚模型...")
        model = create_pythtb_model(params)
        print()
        
        print("正在计算能带结构...")
        calculate_band_structure(model, params)
        print()
        
        print(f"计算完成！结果已保存到 {params.output_filename}.{params.output_format}")
        print(f"日志已保存到 {log_file}")
        print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)
        
        return 0
        
    except FileNotFoundError as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    finally:
        # 恢复 stdout 和 stderr
        if log_file_handle:
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__
            log_file_handle.close()


if __name__ == '__main__':
    exit(main())

