"""Тесты для ParameterizedIterableTask."""

from __future__ import annotations

from typing import Any

import pytest

from task_sequencer.interfaces import (
    ExecutionContext,
    ParameterizedIterableTask,
    TaskResult,
)
from task_sequencer.progress import TaskStatus


class TestParameterizedIterableTask:
    """Тесты для ParameterizedIterableTask."""

    def test_parameterized_task_implementation(self) -> None:
        """Тест базовой реализации ParameterizedIterableTask."""

        class StringParamTask(ParameterizedIterableTask[str]):
            def __init__(self) -> None:
                self.processed: list[str] = []

            @property
            def name(self) -> str:
                return "string_param_task"

            @property
            def depends_on(self) -> list[str]:
                return []

            def get_parameters(self, context: ExecutionContext) -> list[str]:
                return ["param1", "param2", "param3"]

            def execute_for_parameter(
                self, param: str, context: ExecutionContext
            ) -> None:
                self.processed.append(param)

            def execute(self, context: ExecutionContext) -> TaskResult:
                for param in self.get_parameters(context):
                    self.execute_for_parameter(param, context)
                return TaskResult.success_result()

        task = StringParamTask()
        context = ExecutionContext(
            task_order=["string_param_task"],
            results={},
            metadata={},
            progress_tracker=None,
            mode="run",
        )

        result = task.execute(context)

        assert result.success is True
        assert result.status == TaskStatus.COMPLETED
        assert task.processed == ["param1", "param2", "param3"]

    def test_get_items_uses_get_parameters(self) -> None:
        """Тест, что get_items использует get_parameters."""

        class IntParamTask(ParameterizedIterableTask[int]):
            @property
            def name(self) -> str:
                return "int_param_task"

            @property
            def depends_on(self) -> list[str]:
                return []

            def get_parameters(self, context: ExecutionContext) -> list[int]:
                return [1, 2, 3]

            def execute_for_parameter(
                self, param: int, context: ExecutionContext
            ) -> None:
                pass

            def execute(self, context: ExecutionContext) -> TaskResult:
                for param in self.get_parameters(context):
                    self.execute_for_parameter(param, context)
                return TaskResult.success_result()

        task = IntParamTask()
        context = ExecutionContext(
            task_order=["int_param_task"],
            results={},
            metadata={},
            progress_tracker=None,
            mode="run",
        )

        items = list(task.get_items(context))
        assert items == [1, 2, 3]

    def test_execute_for_item_calls_execute_for_parameter(self) -> None:
        """Тест, что execute_for_item вызывает execute_for_parameter."""

        class TestTask(ParameterizedIterableTask[str]):
            def __init__(self) -> None:
                self.called_with: list[str] = []

            @property
            def name(self) -> str:
                return "test_task"

            @property
            def depends_on(self) -> list[str]:
                return []

            def get_parameters(self, context: ExecutionContext) -> list[str]:
                return []

            def execute_for_parameter(
                self, param: str, context: ExecutionContext
            ) -> None:
                self.called_with.append(param)

            def execute(self, context: ExecutionContext) -> TaskResult:
                for param in self.get_parameters(context):
                    self.execute_for_parameter(param, context)
                return TaskResult.success_result()

        task = TestTask()
        context = ExecutionContext(
            task_order=["test_task"],
            results={},
            metadata={},
            progress_tracker=None,
            mode="run",
        )

        task.execute_for_item("test_param", context)
        assert task.called_with == ["test_param"]

    def test_parameterized_task_with_context_data(self) -> None:
        """Тест ParameterizedIterableTask с данными из контекста."""

        class ContextParamTask(ParameterizedIterableTask[str]):
            def __init__(self) -> None:
                self.processed: list[str] = []

            @property
            def name(self) -> str:
                return "context_param_task"

            @property
            def depends_on(self) -> list[str]:
                return ["source_task"]

            def get_parameters(self, context: ExecutionContext) -> list[str]:
                source_result = context.results.get("source_task")
                if source_result and source_result.data:
                    return source_result.data.get("items", [])
                return []

            def execute_for_parameter(
                self, param: str, context: ExecutionContext
            ) -> None:
                self.processed.append(param)

            def execute(self, context: ExecutionContext) -> TaskResult:
                for param in self.get_parameters(context):
                    self.execute_for_parameter(param, context)
                return TaskResult.success_result()

        task = ContextParamTask()
        context = ExecutionContext(
            task_order=["source_task", "context_param_task"],
            results={
                "source_task": TaskResult.success_result(
                    data={"items": ["item1", "item2"]}
                )
            },
            metadata={},
            progress_tracker=None,
            mode="run",
        )

        result = task.execute(context)

        assert result.success is True
        assert task.processed == ["item1", "item2"]

    def test_abstract_methods_must_be_implemented(self) -> None:
        """Тест, что абстрактные методы должны быть реализованы."""

        class IncompleteTask(ParameterizedIterableTask[str]):
            @property
            def name(self) -> str:
                return "incomplete_task"

            @property
            def depends_on(self) -> list[str]:
                return []

            # Не реализованы get_parameters, execute_for_parameter и execute

        with pytest.raises(TypeError):
            IncompleteTask()


