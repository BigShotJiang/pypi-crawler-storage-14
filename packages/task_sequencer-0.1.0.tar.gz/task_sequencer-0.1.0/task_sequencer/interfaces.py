"""Интерфейсы для задач и трекеров прогресса."""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, ContextManager, Generic, Iterator, Literal, TypeVar

from task_sequencer.progress import TaskProgress, TaskStatus
from task_sequencer.types import ProgressTrackerProtocol

# Тип для режима выполнения задач
TaskMode = Literal["run", "dry-run", "resume"]


@dataclass
class TaskResult:
    """Результат выполнения задачи.

    Attributes:
        status: Статус выполнения задачи
        data: Данные, возвращаемые задачей
        error: Сообщение об ошибке (если есть)
        metadata: Дополнительные метаданные о результате
    """

    status: TaskStatus
    data: Any | None = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        """Флаг успешного выполнения (вычисляется из status).

        Returns:
            True, если статус COMPLETED, иначе False
        """
        return self.status == TaskStatus.COMPLETED

    @classmethod
    def success_result(
        cls, data: Any | None = None, metadata: dict[str, Any] | None = None
    ) -> TaskResult:
        """Создает успешный результат выполнения задачи.

        Args:
            data: Данные, возвращаемые задачей
            metadata: Дополнительные метаданные

        Returns:
            TaskResult со статусом COMPLETED
        """
        return cls(
            status=TaskStatus.COMPLETED,
            data=data,
            metadata=metadata or {},
        )

    @classmethod
    def failure_result(
        cls, error: str, metadata: dict[str, Any] | None = None
    ) -> TaskResult:
        """Создает результат с ошибкой выполнения задачи.

        Args:
            error: Сообщение об ошибке
            metadata: Дополнительные метаданные

        Returns:
            TaskResult со статусом FAILED
        """
        return cls(
            status=TaskStatus.FAILED,
            error=error,
            metadata=metadata or {},
        )


@dataclass
class ExecutionContext:
    """Контекст выполнения задачи.

    Предоставляет доступ к информации о текущем выполнении,
    трекеру прогресса и результатам других задач.

    Attributes:
        task_order: Список задач в порядке выполнения
        results: Результаты выполнения задач (имя задачи -> TaskResult)
        metadata: Дополнительные метаданные контекста
        progress_tracker: Трекер прогресса для сохранения состояния
        mode: Режим выполнения ('run', 'dry-run', 'resume')
    """

    task_order: list[str]
    results: dict[str, TaskResult]
    metadata: dict[str, Any]
    progress_tracker: ProgressTrackerProtocol | None = None
    mode: TaskMode = "run"


class Task(ABC):
    """Абстрактный базовый класс для задач.

    Все задачи должны наследоваться от этого класса и реализовывать
    обязательные методы.

    Пример использования:
        >>> from task_sequencer.interfaces import Task, TaskResult, ExecutionContext
        >>>
        >>> class MyTask(Task):
        ...     @property
        ...     def name(self) -> str:
        ...         return "my_task"
        ...     @property
        ...     def depends_on(self) -> list[str]:
        ...         return ["other_task"]
        ...     def execute(self, context: ExecutionContext) -> TaskResult:
        ...         # Получаем результат предыдущей задачи
        ...         other_result = context.results.get("other_task")
        ...         # Выполняем логику задачи
        ...         return TaskResult.success_result(data={"result": "done"})
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Уникальное имя задачи.

        Returns:
            Имя задачи
        """
        ...

    @property
    @abstractmethod
    def depends_on(self) -> list[str]:
        """Список имен задач, от которых зависит данная задача.

        Returns:
            Список имен задач-зависимостей
        """
        ...

    @abstractmethod
    def execute(self, context: ExecutionContext) -> TaskResult:
        """Выполняет задачу.

        Args:
            context: Контекст выполнения задачи

        Returns:
            TaskResult с результатом выполнения

        Raises:
            TaskExecutionError: Если произошла ошибка при выполнении
        """
        ...


class IterableTask(Task):
    """Абстрактный класс для итеративных задач.

    Итеративные задачи обрабатывают коллекции элементов.
    Наследуется от Task и добавляет методы для работы с элементами.

    Пример использования:
        >>> from task_sequencer.interfaces import IterableTask, TaskResult, ExecutionContext
        >>> from typing import Iterator
        >>>
        >>> class ProcessItemsTask(IterableTask):
        ...     @property
        ...     def name(self) -> str:
        ...         return "process_items"
        ...     @property
        ...     def depends_on(self) -> list[str]:
        ...         return []
        ...     def get_items(self, context: ExecutionContext) -> Iterator[str]:
        ...         return iter(["item1", "item2", "item3"])
        ...     def execute_for_item(self, item: str, context: ExecutionContext) -> None:
        ...         # Обработка одного элемента
        ...         print(f"Processing {item}")
        ...     def execute(self, context: ExecutionContext) -> TaskResult:
        ...         # Базовая реализация обрабатывает все элементы
        ...         for item in self.get_items(context):
        ...             self.execute_for_item(item, context)
        ...         return TaskResult.success_result()
    """

    @abstractmethod
    def get_items(self, context: ExecutionContext) -> Iterator[Any]:
        """Получает итератор элементов для обработки.

        Args:
            context: Контекст выполнения задачи

        Returns:
            Итератор элементов для обработки
        """
        ...

    @abstractmethod
    def execute_for_item(
        self, item: Any, context: ExecutionContext
    ) -> None:
        """Выполняет обработку одного элемента.

        Args:
            item: Элемент для обработки
            context: Контекст выполнения задачи

        Raises:
            TaskExecutionError: Если произошла ошибка при обработке элемента
        """
        ...


TParam = TypeVar("TParam")
"""Type variable для параметров ParameterizedIterableTask."""


class ParameterizedIterableTask(IterableTask, Generic[TParam]):
    """Задача, обрабатывающая элементы с внешними параметрами.

    Используется для случаев, когда элементы для обработки
    зависят от результатов других задач (например, *ForMatch методы).

    Пример использования:
        >>> from task_sequencer.interfaces import (
        ...     ParameterizedIterableTask, TaskResult, ExecutionContext
        ... )
        >>>
        >>> class StatsForMatchTask(ParameterizedIterableTask[str]):
        ...     @property
        ...     def name(self) -> str:
        ...         return "stats_for_match"
        ...     @property
        ...     def depends_on(self) -> list[str]:
        ...         return ["matches"]
        ...     def get_parameters(self, context: ExecutionContext) -> list[str]:
        ...         # Получаем match_ids из предыдущей задачи
        ...         matches_result = context.results.get("matches")
        ...         if matches_result and matches_result.data:
        ...             return matches_result.data.get("match_ids", [])
        ...         return []
        ...     def execute_for_parameter(self, match_id: str, context: ExecutionContext) -> None:
        ...         # Обрабатываем один match_id
        ...         print(f"Processing match {match_id}")
        ...     def execute(self, context: ExecutionContext) -> TaskResult:
        ...         # Базовая реализация обрабатывает все параметры
        ...         for param in self.get_parameters(context):
        ...             self.execute_for_parameter(param, context)
        ...         return TaskResult.success_result()
    """

    @abstractmethod
    def get_parameters(self, context: ExecutionContext) -> list[TParam]:
        """Получает параметры из контекста или предыдущих задач.

        Args:
            context: Контекст выполнения с результатами предыдущих задач

        Returns:
            Список параметров для обработки
        """
        ...

    def get_items(self, context: ExecutionContext) -> Iterator[Any]:
        """Реализация get_items через get_parameters.

        Args:
            context: Контекст выполнения задачи

        Returns:
            Итератор параметров для обработки
        """
        return iter(self.get_parameters(context))

    @abstractmethod
    def execute_for_parameter(
        self, param: TParam, context: ExecutionContext
    ) -> None:
        """Выполняет обработку для конкретного параметра.

        Args:
            param: Параметр для обработки
            context: Контекст выполнения

        Raises:
            TaskExecutionError: Если произошла ошибка при обработке параметра
        """
        ...

    def execute_for_item(self, item: Any, context: ExecutionContext) -> None:
        """Адаптер для execute_for_parameter.

        Args:
            item: Элемент для обработки (параметр)
            context: Контекст выполнения задачи

        Raises:
            TaskExecutionError: Если произошла ошибка при обработке элемента
        """
        self.execute_for_parameter(item, context)


class ProgressTracker(ABC):
    """Абстрактный класс для трекеров прогресса.

    Трекеры прогресса отвечают за сохранение и загрузку
    информации о прогрессе выполнения задач.

    Пример использования:
        >>> from task_sequencer.interfaces import ProgressTracker
        >>> from task_sequencer.progress import TaskProgress, TaskStatus
        >>>
        >>> class MyProgressTracker(ProgressTracker):
        ...     def __init__(self):
        ...         self._storage = {}
        ...     def save_progress(self, task_name: str, progress: TaskProgress) -> None:
        ...         self._storage[task_name] = progress
        ...     def get_progress(self, task_name: str) -> TaskProgress | None:
        ...         return self._storage.get(task_name)
        ...     def mark_completed(self, task_name: str) -> None:
        ...         if task_name in self._storage:
        ...             self._storage[task_name].status = TaskStatus.COMPLETED
        ...     def clear_progress(self, task_name: str) -> None:
        ...         self._storage.pop(task_name, None)
        >>>
        >>> tracker = MyProgressTracker()
        >>> progress = TaskProgress("task1", TaskStatus.IN_PROGRESS, total_items=10, processed_items=5)
        >>> tracker.save_progress("task1", progress)
        >>> saved = tracker.get_progress("task1")
    """

    @abstractmethod
    def save_progress(
        self, task_name: str, progress: TaskProgress
    ) -> None:
        """Сохраняет прогресс выполнения задачи.

        Args:
            task_name: Имя задачи
            progress: Информация о прогрессе

        Raises:
            ProgressError: Если не удалось сохранить прогресс
        """
        ...

    @abstractmethod
    def get_progress(self, task_name: str) -> TaskProgress | None:
        """Получает сохраненный прогресс выполнения задачи.

        Args:
            task_name: Имя задачи

        Returns:
            TaskProgress или None, если прогресс не найден

        Raises:
            ProgressError: Если произошла ошибка при загрузке прогресса
        """
        ...

    @abstractmethod
    def mark_completed(self, task_name: str) -> None:
        """Отмечает задачу как завершенную.

        Args:
            task_name: Имя задачи

        Raises:
            ProgressError: Если не удалось обновить статус
        """
        ...

    @abstractmethod
    def clear_progress(self, task_name: str) -> None:
        """Очищает сохраненный прогресс задачи.

        Args:
            task_name: Имя задачи

        Raises:
            ProgressError: Если не удалось очистить прогресс
        """
        ...

    @abstractmethod
    def transaction(self) -> ContextManager[None]:
        """Возвращает контекстный менеджер для изолированной транзакции прогресса.

        Используется для гарантии сохранения прогресса независимо от
        основной транзакции БД. Для MemoryProgressTracker это заглушка.

        Пример использования:
            >>> with progress_tracker.transaction():
            ...     progress_tracker.save_progress("task1", progress)
            ...     # Прогресс сохранится даже если основная транзакция откатится

        Returns:
            Контекстный менеджер для транзакции
        """
        ...

