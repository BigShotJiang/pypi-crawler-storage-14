<a href="https://pypi.org/project/orto/">
<img src="https://img.shields.io/badge/dynamic/json?label=PyPI%20&query=%24.info.version&url=https%3A%2F%2Fpypi.org%2Fpypi%2Forto%2Fjson" />
</a>

<a href="https://pypi.org/project/orto/">
<img src="https://img.shields.io/badge/dynamic/json?label=Python%20&query=%24.info.requires_python&url=https%3A%2F%2Fpypi.org%2Fpypi%2Forto%2Fjson" />
</a>

<a href="https://orto.kragskow.group/">
<img src="https://img.shields.io/website?label=Documentation&down_color=red&down_message=Offline&up_color=green&up_message=Online&url=https%3A%2F%2Forto.kragskow.group">
</a>

# orto

``orto`` (OrcaTools) - a python package for working with Orca.


# Installation

See the [Documentation](https://orto.kragskow.group) for Installation and Usage instructions
