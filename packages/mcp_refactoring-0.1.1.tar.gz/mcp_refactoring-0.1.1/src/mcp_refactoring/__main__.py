"""Entry point for running the MCP server."""

from mcp_refactoring.server import main

if __name__ == "__main__":
    main()
