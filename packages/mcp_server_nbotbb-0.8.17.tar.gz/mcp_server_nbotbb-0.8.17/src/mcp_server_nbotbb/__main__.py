from mcp_server_nbotbb import main

main()
