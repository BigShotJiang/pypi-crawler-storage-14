=======
History
=======

0.1.0 (2025-06-25)
------------------

* First release on PyPI.
