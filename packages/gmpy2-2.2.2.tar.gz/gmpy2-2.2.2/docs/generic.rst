Generic Functions
-----------------

.. currentmodule:: gmpy2

.. autofunction:: add
.. autofunction:: div
.. autofunction:: mul
.. autofunction:: sub

.. autofunction:: square

.. autofunction:: f2q

.. autofunction:: fma
.. autofunction:: fms

.. autofunction:: cmp_abs
