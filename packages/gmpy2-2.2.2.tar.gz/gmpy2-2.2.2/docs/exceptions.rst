Exceptions
----------

.. currentmodule:: gmpy2

.. autoexception:: RangeError
.. autoexception:: InexactResultError
.. autoexception:: OverflowResultError
.. autoexception:: UnderflowResultError
.. autoexception:: InvalidOperationError
.. autoexception:: DivisionByZeroError
