Rationals
=========

.. currentmodule:: gmpy2

mpq type
--------

.. autoclass:: mpq

mpq Functions
-------------

.. autofunction:: qdiv
