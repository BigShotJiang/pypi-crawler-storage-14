# SimpleArgParser
This is a module for parsing (command-line) argument that doesn't require pre-defining the positional and optional arguments and does not enforce positional before optional (allows mixed).  I needed something quick with less configuration and dynamic so it can be easily used by others.
