entry_points="""
    [trytond.modules]
    akademy_classe = trytond.modules.akademy_classe
    """

