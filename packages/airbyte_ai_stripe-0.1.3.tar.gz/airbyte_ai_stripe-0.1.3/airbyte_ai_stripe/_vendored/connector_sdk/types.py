"""Type definitions for Airbyte SDK."""

from __future__ import annotations

from enum import Enum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

from .constants import OPENAPI_DEFAULT_VERSION
from .schema.components import PathOverrideConfig


class Verb(str, Enum):
    """Supported verbs for Resource operations."""

    GET = "get"
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    LIST = "list"
    SEARCH = "search"
    DOWNLOAD = "download"
    AUTHORIZE = "authorize"


class AuthType(str, Enum):
    """Supported authentication types."""

    API_KEY = "api_key"
    BEARER_TOKEN = "bearer_token"
    BEARER = "bearer"
    HTTP = "http"
    BASIC = "basic"


class ContentType(str, Enum):
    """Supported content types for request bodies."""

    JSON = "application/json"
    FORM_URLENCODED = "application/x-www-form-urlencoded"
    FORM_DATA = "multipart/form-data"


class ParameterLocation(str, Enum):
    """Location of operation parameters."""

    PATH = "path"
    QUERY = "query"
    HEADER = "header"
    COOKIE = "cookie"


# All comprehensive OpenAPI 3.0 models are now in connector_sdk.schema package
# Import from connector_sdk.schema for: OpenAPIConnector, Components, Schema, Operation, etc.


class AuthConfig(BaseModel):
    """Authentication configuration."""

    type: AuthType
    config: dict[str, Any] = Field(default_factory=dict)


# Executor types (used by executor.py)
class EndpointDefinition(BaseModel):
    """Definition of an API endpoint."""

    method: str  # GET, POST, PUT, DELETE, etc.
    path: str  # e.g., /v1/customers/{id} (OpenAPI path)
    path_override: PathOverrideConfig | None = Field(
        None,
        description=(
            "Path override config from x-airbyte-path-override. "
            "When set, overrides the path for actual HTTP requests."
        ),
    )
    verb: Verb | None = None  # Semantic verb (get, list, create, update, delete)
    description: str | None = None
    body_fields: list[str] = Field(default_factory=list)  # For POST/PUT
    query_params: list[str] = Field(default_factory=list)  # For GET
    path_params: list[str] = Field(default_factory=list)  # Extracted from path
    content_type: ContentType = ContentType.JSON
    request_schema: dict[str, Any] | None = None
    response_schema: dict[str, Any] | None = None

    # GraphQL support (Airbyte extension)
    graphql_body: dict[str, Any] | None = Field(
        None,
        description="GraphQL body configuration from x-airbyte-body-type extension",
    )


class ResourceDefinition(BaseModel):
    """Definition of an API resource."""

    model_config = {"populate_by_name": True}

    name: str
    verbs: list[Verb]
    endpoints: dict[Verb, EndpointDefinition]
    resource_schema: dict[str, Any] | None = Field(default=None, alias="schema")


class ConnectorConfig(BaseModel):
    """Complete connector configuration loaded from YAML."""

    model_config = ConfigDict(use_enum_values=True)

    name: str
    version: str = OPENAPI_DEFAULT_VERSION
    base_url: str
    auth: AuthConfig
    resources: list[ResourceDefinition]
    openapi_spec: Any | None = None  # Optional reference to OpenAPIConnector
