"""Examples demonstrating valid8r usage."""

from __future__ import annotations
