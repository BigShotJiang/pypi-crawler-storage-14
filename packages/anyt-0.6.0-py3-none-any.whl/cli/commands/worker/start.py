"""
Worker start command for running automated task processing.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import typer
from rich.table import Table

from rich.markup import escape

from cli.commands.console import console
from cli.commands.worker.helpers import resolve_workflow_file
from cli.worker.coordinator import TaskCoordinator

if TYPE_CHECKING:
    from cli.config import WorkspaceConfig


def start(
    workspace_dir: Optional[Path] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace directory (default: current directory)",
    ),
    workflow: Optional[str] = typer.Option(
        None,
        "--workflow",
        help="Workflow to run (remote_dev, local_dev, dry_run). If not specified, shows interactive selection with remote_dev as default.",
    ),
    workflows_dir: Optional[Path] = typer.Option(
        None,
        "--workflows",
        help="Workflows directory (default: .anyt/workflows). If --workflow is specified, loads from this directory.",
    ),
    poll_interval: int = typer.Option(
        5,
        "--poll-interval",
        "-i",
        help="Polling interval in seconds",
    ),
    max_backoff: int = typer.Option(
        60,
        "--max-backoff",
        help="Maximum backoff interval in seconds",
    ),
    agent_id: Optional[str] = typer.Option(
        None,
        "--agent-id",
        "-a",
        help="Agent identifier to filter tasks (e.g., agent-xxx). If not provided, will prompt to select from available agents.",
    ),
    project_id: Optional[int] = typer.Option(
        None,
        "--project-id",
        "-p",
        help="Project ID to scope task suggestions. If not provided, loads from .anyt/anyt.json (current_project_id field).",
    ),
    skip_checks: bool = typer.Option(
        False,
        "--skip-checks",
        help="Skip workflow requirement validation before starting",
    ),
    force_check: bool = typer.Option(
        False,
        "--force-check",
        help="Force fresh requirement checks (bypass cache)",
    ),
    clone_repos: bool = typer.Option(
        False,
        "--clone-repos",
        help="Force clone project repos for all workflows (overrides workflow settings.clone_repo)",
    ),
    no_cleanup: bool = typer.Option(
        False,
        "--no-cleanup",
        help="Keep task workspaces after execution (overrides workflow settings.cleanup_workspace)",
    ),
) -> None:
    """
    Start the Claude task worker.

    The worker continuously polls for tasks and executes workflows automatically.

    Setup:
    1. Set ANYT_API_KEY environment variable for API authentication
    2. Create an agent at https://anyt.dev/home/agents
    3. Run 'anyt worker start' and select from available agents and workflow

    Agent Selection:
    - If --agent-id is provided: Uses that agent directly
    - If --agent-id is NOT provided: Shows interactive list of available agents
    - If no agents exist: Shows error with instructions to create one

    Note: ANYT_API_KEY (API key) and agent-id (agent identifier) are different:
    - ANYT_API_KEY: API key for authentication (e.g., anyt_agent_...)
    - agent-id: Agent identifier to filter tasks (e.g., agent-xxx)

    Workflow Selection:
    - If --workflow is NOT provided: Shows interactive workflow selector (default: remote_dev)
    - If --workflow is provided: Uses that specific workflow directly

    Workflow Options:
    - No options: Interactive workflow selection (default: remote_dev)
    - --workflow remote_dev: Runs ONLY remote_dev workflow (skips interactive selection)
    - --workflows-dir /custom: Custom workflows directory

    Built-in workflows (bundled with CLI, no setup required):
    - remote_dev (default): Clone remote GitHub repo, implement task, create PR
    - local_dev: Quick iterations on current branch, no branch management
    - dry_run: Test workflow without making actual changes (for testing)

    Workflow Comparison:
    | Workflow    | Clone Repo | Branch Mgmt | PR Creation | Best For           |
    |-------------|------------|-------------|-------------|--------------------|
    | remote_dev  | Yes        | Yes         | Yes         | Remote GitHub repos|
    | local_dev   | -          | -           | -           | Quick development  |
    | dry_run     | -          | -           | -           | Testing            |

    Example:
        export ANYT_API_KEY=anyt_agent_...  # API key for authentication
        anyt worker start  # Interactive agent and workflow selection
        anyt worker start --agent-id agent-xxx  # Direct agent, interactive workflow
        anyt worker start --workflow local_dev  # Direct workflow selection
        anyt worker start --project-id 123
        anyt worker start --poll-interval 10 --workspace /path/to/project
    """
    workspace = workspace_dir or Path.cwd()

    if not workspace.exists():
        console.print(
            f"[red]Error: Workspace directory does not exist: {workspace}[/red]"
        )
        raise typer.Exit(1)

    # Load workspace config to get defaults
    from cli.config import WorkspaceConfig

    workspace_config = WorkspaceConfig.load(workspace)
    if not workspace_config:
        console.print(
            f"[red]Error: No workspace config found at {workspace}/.anyt/anyt.json[/red]"
        )
        console.print(
            "[yellow]Hint: Initialize workspace with 'anyt workspace init'[/yellow]"
        )
        raise typer.Exit(1)

    # Get or prompt for agent_id
    resolved_agent_id = _resolve_agent_id(agent_id, workspace_config)

    # Use config defaults if not provided via CLI
    effective_project_id = project_id or workspace_config.current_project_id

    console.print(f"[dim]Using agent_id: {resolved_agent_id}[/dim]")
    if effective_project_id:
        console.print(f"[dim]Using project_id: {effective_project_id}[/dim]")

    # Prompt for workflow selection if not specified
    resolved_workflow = _resolve_workflow(workflow)

    # Resolve workflow file if --workflow is specified
    workflow_file: Optional[Path] = None
    if resolved_workflow:
        try:
            workflow_file = resolve_workflow_file(
                resolved_workflow, workspace, workflows_dir
            )
            console.print(
                f"[green]Using workflow:[/green] {resolved_workflow} (from {workflow_file.parent})"
            )
        except ValueError as e:
            console.print(f"[red]Error: {escape(str(e))}[/red]")
            raise typer.Exit(1)

    # Check workflow requirements before starting (unless skipped)
    if not skip_checks and workflow_file:
        _check_workflow_requirements(
            workflow_file, resolved_workflow, workspace, force_check
        )

    # Create coordinator and run
    coordinator = TaskCoordinator(
        workspace_dir=workspace,
        workflows_dir=workflows_dir,
        workflow_file=workflow_file,
        poll_interval=poll_interval,
        max_backoff=max_backoff,
        agent_id=resolved_agent_id,
        project_id=effective_project_id,
        clone_repos=clone_repos,
        cleanup_workspaces=not no_cleanup,
    )

    try:
        asyncio.run(coordinator.run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Worker stopped by user[/yellow]")


def _resolve_agent_id(
    agent_id: Optional[str], workspace_config: WorkspaceConfig
) -> str:
    """Resolve agent ID from option, config default, or interactive selection."""
    if agent_id:
        return agent_id

    # Try to use default agent from workspace config first
    if workspace_config.default_agent_id:
        from cli.commands.services import ServiceRegistry as services

        agents_client = services.get_agents_client()

        try:
            # Fetch the default agent to verify it exists
            agents = asyncio.run(
                agents_client.list_agents(workspace_id=workspace_config.workspace_id)
            )
            default_agent = next(
                (a for a in agents if a.id == workspace_config.default_agent_id),
                None,
            )

            if default_agent:
                console.print(
                    f"[green]Using default agent from config: {default_agent.agent_id} ({default_agent.name})[/green]"
                )
                return default_agent.agent_id
            else:
                console.print(
                    f"[yellow]Warning: Default agent (ID {workspace_config.default_agent_id}) not found[/yellow]"
                )
        except Exception as e:  # noqa: BLE001 - Intentionally broad: gracefully handle any agent verification failure to continue with agent selection
            console.print(
                f"[yellow]Warning: Could not verify default agent: {e}[/yellow]"
            )

    # Prompt for selection
    return _prompt_agent_selection(workspace_config)


def _prompt_agent_selection(workspace_config: WorkspaceConfig) -> str:
    """Interactive agent selection prompt."""
    from cli.commands.services import ServiceRegistry as services

    agents_client = services.get_agents_client()

    try:
        agents = asyncio.run(
            agents_client.list_agents(workspace_id=workspace_config.workspace_id)
        )
    except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error for any agent fetching failure
        console.print(f"[red]Error fetching agents: {escape(str(e))}[/red]")
        console.print()
        console.print(
            "[yellow]Hint: Create an agent at https://anyt.dev/home/agents[/yellow]"
        )
        raise typer.Exit(1)

    if not agents:
        console.print("[red]No agents found in this workspace.[/red]")
        console.print()
        console.print("[yellow]Steps to create an agent:[/yellow]")
        console.print("  1. Go to https://anyt.dev/home/agents")
        console.print("  2. Create a new agent")
        console.print("  3. Run: anyt worker start")
        console.print()
        console.print("[dim]Or specify --agent-id directly if you have one[/dim]")
        raise typer.Exit(1)

    # Display available agents
    console.print("[cyan]Available agents:[/cyan]")
    console.print()

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("Agent ID", style="cyan")
    table.add_column("Name", style="white")
    table.add_column("Type", style="yellow")
    table.add_column("Active", style="green")

    for idx, agent in enumerate(agents, 1):
        table.add_row(
            str(idx),
            agent.agent_id,
            agent.name,
            agent.agent_type.value
            if hasattr(agent.agent_type, "value")
            else str(agent.agent_type),
            "Yes" if agent.is_active else "No",
        )

    console.print(table)
    console.print()

    # Prompt for selection with default (first agent)
    default_agent = agents[0]
    console.print(
        f"[dim]Default: {default_agent.agent_id} ({default_agent.name})[/dim]"
    )
    console.print()

    while True:
        choice = typer.prompt(
            f"Select an agent (1-{len(agents)}, Enter for default, or 'q' to quit)",
            type=str,
            default="",
            show_default=False,
        )

        # Empty input = use default (first agent)
        if choice == "":
            console.print(
                f"[green]Using default agent: {default_agent.agent_id} ({default_agent.name})[/green]"
            )
            return default_agent.agent_id

        if choice.lower() == "q":
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

        try:
            choice_idx = int(choice)
            if 1 <= choice_idx <= len(agents):
                selected_agent = agents[choice_idx - 1]
                console.print(
                    f"[green]Selected agent: {selected_agent.agent_id} ({selected_agent.name})[/green]"
                )
                return selected_agent.agent_id
            else:
                console.print(
                    f"[red]Invalid choice. Please enter a number between 1 and {len(agents)}[/red]"
                )
        except ValueError:
            console.print("[red]Invalid input. Please enter a number or 'q'[/red]")


def _resolve_workflow(workflow: Optional[str]) -> str:
    """Resolve workflow from option or interactive selection."""
    if workflow:
        return workflow

    console.print()
    console.print("[cyan]Select a workflow to run:[/cyan]")
    console.print()

    # Define workflow descriptions
    workflow_descriptions = {
        "remote_dev": "Clone remote repo, implement task, create PR (for linked GitHub repos)",
        "local_dev": "Quick iterations on current branch (no branch management, commits directly)",
        "dry_run": "Test workflow without making actual changes (useful for testing)",
    }

    # Display workflow options table
    table = Table(show_header=True, header_style="bold cyan", box=None)
    table.add_column("#", style="dim", width=4)
    table.add_column("Workflow", style="cyan", width=30)
    table.add_column("Description", style="white")

    workflows_list = [
        ("remote_dev", workflow_descriptions["remote_dev"]),
        ("local_dev", workflow_descriptions["local_dev"]),
        ("dry_run", workflow_descriptions["dry_run"]),
    ]

    default_workflow = "remote_dev"

    for idx, (wf_name, wf_desc) in enumerate(workflows_list, 1):
        # Mark default with star and bold styling
        if wf_name == default_workflow:
            workflow_display = f"[bold green]{wf_name} * [DEFAULT][/bold green]"
        else:
            workflow_display = wf_name
        table.add_row(str(idx), workflow_display, wf_desc)

    console.print(table)
    console.print()
    console.print(
        "[bold green]* Default: remote_dev[/bold green] [dim](press Enter to use default)[/dim]"
    )
    console.print()

    # Prompt for selection
    while True:
        choice = typer.prompt(
            f"Select workflow [1-{len(workflows_list)}] or press [Enter] for default (remote_dev), 'q' to quit",
            type=str,
            default="",
            show_default=False,
        )

        # Empty input = use default (remote_dev)
        if choice == "":
            console.print(
                "[green]Using default workflow: remote_dev (clone remote repo)[/green]"
            )
            return "remote_dev"

        if choice.lower() == "q":
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

        try:
            choice_idx = int(choice)
            if 1 <= choice_idx <= len(workflows_list):
                selected_workflow = workflows_list[choice_idx - 1][0]
                console.print(f"[green]Selected workflow: {selected_workflow}[/green]")
                return selected_workflow
            else:
                console.print(
                    f"[red]Invalid choice. Please enter a number between 1 and {len(workflows_list)}[/red]"
                )
        except ValueError:
            console.print("[red]Invalid input. Please enter a number or 'q'[/red]")


def _check_workflow_requirements(
    workflow_file: Path,
    workflow_name: str,
    workspace: Path,
    force_check: bool,
) -> None:
    """Check workflow requirements before starting."""
    import yaml

    from cli.commands.workflow_formatters import display_check_results
    from cli.services.workflow_requirements import WorkflowRequirementsService
    from cli.worker.models import Workflow

    try:
        # Load workflow definition
        with open(workflow_file) as f:
            data = yaml.safe_load(f)
            # Fix YAML boolean key issue (on: becomes True)
            if True in data:
                data["on"] = data.pop(True)
            workflow_obj = Workflow(**data)

        # Check if workflow has requirements
        if workflow_obj.requirements and workflow_obj.requirements.has_requirements():
            console.print()
            console.print("[cyan]Checking workflow requirements...[/cyan]")

            # Run requirement checks
            service = WorkflowRequirementsService(workspace_dir=workspace)
            results = asyncio.run(
                service.check_requirements(
                    requirements=workflow_obj.requirements,
                    workflow_name=workflow_obj.name,
                    force=force_check,
                )
            )

            if results.is_success():
                # All checks passed - show what was validated
                for req_name, check_result in results.results:
                    if check_result.success:
                        console.print(
                            f"[green]✓[/green] {req_name}: {check_result.message}"
                        )
                    elif check_result.warning:
                        console.print(
                            f"[yellow]⚠[/yellow]  {req_name}: {check_result.message}"
                        )

                console.print()
                cache_status = " (cached)" if results.from_cache else ""
                console.print(f"[green]✓ All requirements met{cache_status}[/green]")
            else:
                # Some checks failed
                console.print()
                display_check_results(results)
                console.print()
                console.print(
                    "[yellow]Run [cyan]anyt worker check[/cyan] for detailed instructions[/yellow]"
                )
                raise typer.Exit(1)

    except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error for any workflow requirement check failure
        console.print(f"[red]Error checking requirements: {escape(str(e))}[/red]")
        raise typer.Exit(1)
