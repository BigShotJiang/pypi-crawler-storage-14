"""System worker commands for demo project automation."""

import asyncio
import os
from pathlib import Path
from typing import Optional

import typer

from rich.markup import escape

from cli.commands.console import console
from cli.services.system_worker_coordinator import SystemWorkerCoordinator

app = typer.Typer(help="System worker for demo projects")


@app.command()
def start(
    workspace_dir: Optional[Path] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace directory (default: /tmp/anyt-system-worker)",
    ),
    poll_interval: int = typer.Option(
        10,
        "--poll-interval",
        "-i",
        help="Polling interval in seconds",
    ),
    max_backoff: int = typer.Option(
        60,
        "--max-backoff",
        help="Maximum backoff interval in seconds",
    ),
) -> None:
    """
    Start the system worker for demo projects.

    This worker is operated by AnyTask company to automatically
    execute tasks in users' demo projects using a built-in workflow.

    The built-in demo_project.yaml workflow handles everything:
    - Clones demo repository
    - Executes task with Claude Code
    - Commits and pushes changes
    - Updates task status

    The workflow is bundled with the CLI and requires no setup.
    It can be overridden by placing a custom demo_project.yaml
    in the workspace's .anyt/workflows/ directory.

    Requirements:
        - WORKER_API_TOKEN environment variable must be set

    Example:
        export WORKER_API_TOKEN=secret-worker-token
        anyt system-worker start
        anyt system-worker start --workspace /tmp/worker --poll-interval 5
    """
    workspace = workspace_dir or Path("/tmp/anyt-system-worker")

    # Verify WORKER_API_TOKEN
    if not os.getenv("WORKER_API_TOKEN"):
        console.print("[red]Error: WORKER_API_TOKEN not set[/red]")
        console.print("[yellow]Set: export WORKER_API_TOKEN=your-token[/yellow]")
        raise typer.Exit(1)

    # Create workspace directory
    workspace.mkdir(parents=True, exist_ok=True)

    # Display startup banner
    console.print("[bold blue]AnyTask System Worker[/bold blue]")
    console.print("[dim]Uses built-in workflow: demo_project.yaml[/dim]")
    console.print(f"[dim]Workspace: {workspace}[/dim]")
    console.print(f"[dim]Poll interval: {poll_interval}s[/dim]\n")

    # Run worker
    try:
        coordinator = SystemWorkerCoordinator(
            workspace_dir=workspace,
            poll_interval=poll_interval,
            max_backoff=max_backoff,
        )
        asyncio.run(coordinator.run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Worker stopped by user[/yellow]")
    except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error
        # Display user-friendly error for any worker failure
        console.print(f"\n[red]Worker error: {escape(str(e))}[/red]")
        raise typer.Exit(1)
