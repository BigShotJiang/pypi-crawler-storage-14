"""Workspace commands for AnyTask CLI."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List

import typer
from typing_extensions import Annotated
from rich.table import Table
from rich.prompt import Prompt

from cli.commands.console import console
from cli.commands.decorators import async_command
from cli.commands.formatters import TableFormatter
from cli.commands.services import ServiceRegistry as services
from cli.config import WorkspaceConfig, get_effective_api_config
from cli.models.workspace import Workspace
from cli.models.project import ProjectCreate
from cli.models.common import ProjectStatus
from cli.services.project_service import ProjectService

app = typer.Typer(help="Manage workspaces")


async def _select_or_create_project(
    workspace_id: int, workspace_identifier: str, project_service: ProjectService
) -> int | None:
    """Interactive project selection or creation flow.

    Args:
        workspace_id: The workspace ID
        workspace_identifier: The workspace identifier
        project_service: ProjectService instance

    Returns:
        Selected or created project ID, or None if failed
    """
    # Fetch existing projects
    console.print("Fetching projects...")
    try:
        projects = await project_service.list_projects(workspace_id)
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project listing is optional
        # Project listing is optional; continue with empty list on any error
        console.print(f"[yellow]Warning:[/yellow] Could not fetch projects: {e}")
        projects = []

    # Show project selection menu
    if projects:
        table = Table(title="Available Projects")
        table.add_column("#", style="cyan", no_wrap=True)
        table.add_column("Name", style="green")
        table.add_column("Description", style="dim")

        for idx, project in enumerate(projects, 1):
            description_display = project.description or ""
            if len(description_display) > 50:
                description_display = description_display[:47] + "..."
            table.add_row(
                str(idx),
                project.name,
                description_display,
            )

        # Add "Create new project" option
        create_idx = len(projects) + 1
        table.add_row(
            str(create_idx),
            "[bold cyan]+ Create new project[/bold cyan]",
            "",
        )

        console.print(table)

        choice = Prompt.ask(
            f"Which project would you like to use? [{'/'.join(str(i) for i in range(1, create_idx + 1))}]",
            choices=[str(i) for i in range(1, create_idx + 1)],
            default="1",
        )

        choice_num = int(choice)
        if choice_num <= len(projects):
            # User selected an existing project
            selected_project = projects[choice_num - 1]
            console.print(f"[green]✓[/green] Selected project: {selected_project.name}")
            return selected_project.id
        # Otherwise, create new project (fall through to creation flow)
    else:
        console.print("[dim]No existing projects found[/dim]")
        create_choice = Prompt.ask(
            "Create a new project?", choices=["y", "N"], default="y"
        )
        if create_choice.lower() != "y":
            return None

    # Create new project
    console.print("\n[cyan]Creating new project[/cyan]")

    # Prompt for project name (required)
    project_name = Prompt.ask("Project name", default=f"{workspace_identifier} Project")

    # Prompt for description (optional)
    description_input: str = Prompt.ask("Description (optional)", default="")
    description: str | None = description_input if description_input else None

    # Prompt for status (optional)
    status_choices = [status.value for status in ProjectStatus]
    status_input = Prompt.ask(
        "Status",
        choices=status_choices,
        default=ProjectStatus.ACTIVE.value,
    )
    status = ProjectStatus(status_input)

    # Create project
    try:
        project_create = ProjectCreate(
            name=project_name,
            description=description,
            status=status,
        )
        new_project = await project_service.create_project(workspace_id, project_create)
        console.print(f"[green]✓[/green] Created project: {new_project.name}")
        return new_project.id
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project creation is optional
        # Project creation is optional; return None on any error
        console.print(f"[red]Error:[/red] Failed to create project: {e}")
        return None


@app.command()
@async_command()
async def init(
    workspace_id: Annotated[
        str | None,
        typer.Argument(help="Workspace ID or identifier to initialize (optional)"),
    ] = None,
    directory: Annotated[
        Path | None,
        typer.Option("--dir", "-d", help="Directory to initialize (default: current)"),
    ] = None,
) -> None:
    """Initialize a workspace in the current directory.

    Links an existing workspace to the current directory.
    Creates anyt.json workspace configuration file.
    """
    # Check authentication and get API config
    try:
        effective_config = get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()
    project_service = services.get_project_service()

    # Determine target directory
    target_dir = directory or Path.cwd()
    target_dir = target_dir.resolve()

    # Check if already initialized
    existing_config = WorkspaceConfig.load(target_dir)
    if existing_config:
        console.print(
            f"[yellow]Warning:[/yellow] Workspace config already exists: {existing_config.name}"
        )
        console.print(f"Workspace ID: {existing_config.workspace_id}")
        if existing_config.workspace_identifier:
            console.print(f"Identifier: {existing_config.workspace_identifier}")

        reset = Prompt.ask("Do you want to reset it?", choices=["y", "N"], default="N")

        if reset.lower() != "y":
            console.print("[green]✓[/green] Using existing workspace configuration")
            raise typer.Exit(0)

        # If reset (y), continue with initialization

    # Fetch available workspaces
    console.print("Fetching available workspaces...")
    workspaces = await workspace_service.list_workspaces()

    if not workspaces:
        console.print("[red]Error:[/red] No workspaces found")
        console.print(
            "\nPlease create a workspace first using the web interface or API."
        )
        raise typer.Exit(1)

    # Find target workspace
    target_ws: Workspace | None = None
    if workspace_id:
        # Find workspace by ID or identifier
        for ws in workspaces:
            if str(ws.id) == workspace_id or ws.identifier == workspace_id.upper():
                target_ws = ws
                break

        if not target_ws:
            console.print(f"[red]Error:[/red] Workspace '{workspace_id}' not found")
            raise typer.Exit(1)
    else:
        # Show workspace selection menu
        table = Table(title="Available Workspaces")
        table.add_column("#", style="cyan", no_wrap=True)
        table.add_column("Name", style="green")
        table.add_column("Identifier", style="yellow")
        table.add_column("ID", style="dim")

        for idx, ws in enumerate(workspaces, 1):
            table.add_row(
                str(idx),
                ws.name,
                ws.identifier,
                str(ws.id),
            )

        console.print(table)

        choice = Prompt.ask(
            "Select workspace",
            choices=[str(i) for i in range(1, len(workspaces) + 1)],
            default="1",
        )

        target_ws = workspaces[int(choice) - 1]

    console.print(
        f"[green]✓[/green] Selected workspace: {target_ws.name} ({target_ws.identifier})"
    )

    # Select or create project
    try:
        current_project_id = await _select_or_create_project(
            target_ws.id, target_ws.identifier, project_service
        )
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project setup is optional
        # Project setup is optional; continue without project on any error
        console.print(f"[yellow]Warning:[/yellow] Could not setup project: {e}")
        current_project_id = None

    # Save workspace config
    api_url = effective_config.get("api_url") or "https://api.anyt.dev"
    ws_config = WorkspaceConfig(
        workspace_id=target_ws.id,
        name=target_ws.name,
        api_url=api_url,
        workspace_identifier=target_ws.identifier,
        current_project_id=current_project_id,
        last_sync=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )
    ws_config.save(target_dir)

    console.print(
        f"[green]✓[/green] Initialized workspace config in {target_dir}/.anyt/anyt.json"
    )


@app.command()
@async_command()
async def list() -> None:
    """List all accessible workspaces."""
    # Check authentication
    try:
        get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()

    console.print("Fetching workspaces...")
    workspaces = await workspace_service.list_workspaces()

    # Check for local workspace
    local_ws = WorkspaceConfig.load()

    def format_workspace_row(ws: Workspace) -> List[str]:
        """Format a workspace row for table display."""
        ws_id = str(ws.id)
        is_current = local_ws and local_ws.workspace_id == ws.id
        status = "● active" if is_current else ""
        return [ws.name, ws.identifier, ws_id, status]

    TableFormatter().format_list(
        items=workspaces,
        columns=[
            ("Name", "green"),
            ("Identifier", "yellow"),
            ("ID", "dim"),
            ("Status", "cyan"),
        ],
        title="Accessible Workspaces",
        row_formatter=format_workspace_row,
        empty_message="No workspaces found",
    )


@app.command()
@async_command()
async def switch(
    workspace_id: Annotated[
        str | None,
        typer.Argument(help="Workspace ID or identifier to switch to"),
    ] = None,
    directory: Annotated[
        Path | None,
        typer.Option(
            "--dir", "-d", help="Directory to switch workspace in (default: current)"
        ),
    ] = None,
) -> None:
    """Switch the active workspace for the current directory.

    This updates the anyt.json file to point to a different workspace.
    """
    # Check authentication and get API config
    try:
        effective_config = get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Determine target directory
    target_dir = directory or Path.cwd()
    target_dir = target_dir.resolve()

    # Check if initialized
    existing_config = WorkspaceConfig.load(target_dir)
    if not existing_config:
        console.print("[red]Error:[/red] Directory not initialized with a workspace")
        console.print("Run [cyan]anyt workspace init[/cyan] first")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()
    project_service = services.get_project_service()

    console.print("Fetching available workspaces...")
    workspaces = await workspace_service.list_workspaces()

    if not workspaces:
        console.print("[yellow]No workspaces found[/yellow]")
        raise typer.Exit(0)

    # If workspace_id provided, find it
    target_ws: Workspace | None = None
    if workspace_id:
        for ws in workspaces:
            if str(ws.id) == workspace_id or ws.identifier == workspace_id.upper():
                target_ws = ws
                break

        if not target_ws:
            console.print(f"[red]Error:[/red] Workspace '{workspace_id}' not found")
            raise typer.Exit(1)
    else:
        # Show selection prompt
        table = Table(title="Available Workspaces")
        table.add_column("#", style="cyan", no_wrap=True)
        table.add_column("Name", style="green")
        table.add_column("Identifier", style="yellow")
        table.add_column("Current", style="dim")

        for idx, ws in enumerate(workspaces, 1):
            is_current = existing_config.workspace_id == ws.id

            table.add_row(
                str(idx),
                ws.name,
                ws.identifier,
                "●" if is_current else "",
            )

        console.print(table)

        choice = Prompt.ask(
            "Select workspace",
            choices=[str(i) for i in range(1, len(workspaces) + 1)],
            default="1",
        )

        target_ws = workspaces[int(choice) - 1]

    # Fetch current project for the workspace
    console.print("Fetching current project...")
    try:
        current_project = await project_service.get_or_create_default_project(
            target_ws.id, target_ws.identifier
        )
        current_project_id = current_project.id
    except Exception as e:  # noqa: BLE001 - Intentionally broad: project fetching is optional
        # Project fetching is optional; continue without project on any error
        console.print(f"[yellow]Warning:[/yellow] Could not fetch current project: {e}")
        current_project_id = None

    # Update workspace config
    api_url = effective_config.get("api_url") or "https://api.anyt.dev"
    ws_config = WorkspaceConfig(
        workspace_id=target_ws.id,
        name=target_ws.name,
        api_url=api_url,
        workspace_identifier=target_ws.identifier,
        current_project_id=current_project_id,
        last_sync=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )
    ws_config.save(target_dir)

    console.print(
        f"[green]✓[/green] Switched to workspace: {target_ws.name} ({target_ws.identifier})"
    )


@app.command()
@async_command()
async def use(
    workspace: Annotated[
        str,
        typer.Argument(help="Workspace ID or identifier to set as current"),
    ],
) -> None:
    """Set the current workspace for the active environment.

    This sets the default workspace that will be used for all task operations
    when no explicit workspace is specified via --workspace flag.
    """
    # Check authentication
    try:
        get_effective_api_config()
    except RuntimeError:
        console.print("[red]Error:[/red] Not authenticated")
        console.print("\nSet the ANYT_API_KEY environment variable:")
        console.print("  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]")
        raise typer.Exit(1)

    # Initialize services
    workspace_service = services.get_workspace_service()

    console.print("Fetching available workspaces...")
    workspaces = await workspace_service.list_workspaces()

    if not workspaces:
        console.print("[yellow]No workspaces found[/yellow]")
        raise typer.Exit(0)

    # Find the target workspace
    target_ws: Workspace | None = None
    for ws in workspaces:
        if str(ws.id) == workspace or ws.identifier == workspace.upper():
            target_ws = ws
            break

    if not target_ws:
        console.print(f"[red]Error:[/red] Workspace '{workspace}' not found")
        console.print("\nAvailable workspaces:")
        for ws in workspaces:
            console.print(f"  {ws.identifier} - {ws.name} (ID: {ws.id})")
        raise typer.Exit(1)

    # Note: This command is deprecated. Use 'anyt workspace switch' instead.
    console.print("[yellow]Note:[/yellow] The 'workspace use' command is deprecated.")
    console.print(
        f"Use [cyan]anyt workspace switch {workspace}[/cyan] instead to update your local workspace."
    )
    console.print()
    console.print(f"Target workspace: {target_ws.name} ({target_ws.identifier})")


@app.command()
@async_command()
async def current() -> None:
    """Show the current workspace from local config."""
    # Load local workspace config
    ws_config = WorkspaceConfig.load()

    if ws_config:
        # Check authentication to fetch workspace details
        try:
            get_effective_api_config()
            workspace_service = services.get_workspace_service()

            try:
                workspaces = await workspace_service.list_workspaces()
                current_ws: Workspace | None = None
                for ws in workspaces:
                    if ws.id == int(ws_config.workspace_id):
                        current_ws = ws
                        break

                if current_ws:
                    console.print(
                        f"Current workspace: [green]{current_ws.name}[/green] ([yellow]{current_ws.identifier}[/yellow])"
                    )
                    console.print(f"Workspace ID: {current_ws.id}")
                else:
                    console.print(
                        f"Workspace ID: [yellow]{ws_config.workspace_id}[/yellow]"
                    )
                    console.print(
                        "[dim](Workspace not found in accessible workspaces)[/dim]"
                    )
            except Exception:  # noqa: BLE001 - Intentionally broad: workspace info display is best-effort
                # Workspace info display is best-effort; show basic info on any error
                console.print(
                    f"Workspace ID: [yellow]{ws_config.workspace_id}[/yellow]"
                )

        except RuntimeError:
            # Not authenticated - just show the workspace ID from config
            console.print(f"Workspace: [yellow]{ws_config.name}[/yellow]")
            console.print(f"Workspace ID: {ws_config.workspace_id}")
            if ws_config.workspace_identifier:
                console.print(f"Identifier: {ws_config.workspace_identifier}")
    else:
        console.print("[dim]No workspace initialized[/dim]")
        console.print("\nInitialize a workspace with: [cyan]anyt workspace init[/cyan]")
