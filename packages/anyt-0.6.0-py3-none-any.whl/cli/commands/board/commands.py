"""Board, timeline, summary, and graph visualization commands for AnyTask CLI."""

import json
from typing import Any, Optional

from cli.services.task_service import TaskService

import typer
from typing_extensions import Annotated

from cli.commands.board.formatters import (
    format_board_json,
    format_compact_board,
    format_empty_graph_json,
    format_empty_tasks_json,
    format_error_json,
    format_graph_task_json,
    format_summary_json,
)
from cli.commands.board.graph_builder import build_workspace_dependency_graph
from cli.commands.board.grouping import (
    group_tasks_by_labels,
    group_tasks_by_owner,
    group_tasks_by_priority,
    group_tasks_by_status,
)
from cli.commands.board.renderers import (
    annotate_blocked_tasks_from_graph,
    render_board_footer,
    render_board_header,
    render_board_table,
    render_graph_footer,
    render_graph_header,
    render_priorities_section,
    render_progress_footer,
    render_summary_header,
    render_summary_section,
    render_task_dependency_graph,
)
from cli.commands.console import console
from cli.commands.context import CommandContext
from cli.commands.decorators import async_command
from cli.commands.guards import require_workspace_config
from cli.commands.services import ServiceRegistry as services
from cli.graph_renderer import render_ascii_graph, render_dot_graph, render_json_graph
from cli.models.common import Status
from cli.models.task import TaskFilters

app = typer.Typer(help="Board and visualization commands")


@app.command("board")
@async_command()
async def show_board(
    mine: Annotated[
        bool,
        typer.Option("--mine", help="Show only tasks assigned to you"),
    ] = False,
    assignee: Annotated[
        Optional[str],
        typer.Option(
            "--assignee", "-a", help="Filter by assignee (user ID or agent ID)"
        ),
    ] = None,
    me: Annotated[
        bool,
        typer.Option("--me", help="Show only my tasks (alias for --mine)"),
    ] = False,
    labels: Annotated[
        Optional[str],
        typer.Option("--labels", help="Filter by labels (comma-separated)"),
    ] = None,
    status: Annotated[
        Optional[str],
        typer.Option("--status", help="Filter by status (comma-separated)"),
    ] = None,
    phase: Annotated[
        Optional[str],
        typer.Option("--phase", help="Filter by phase/milestone"),
    ] = None,
    group_by: Annotated[
        str,
        typer.Option("--group-by", help="Group by: status, priority, owner, labels"),
    ] = "status",
    sort: Annotated[
        str,
        typer.Option("--sort", help="Sort within groups: priority, updated_at"),
    ] = "priority",
    compact: Annotated[
        bool,
        typer.Option("--compact", help="Compact display mode"),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", help="Max tasks per lane"),
    ] = 20,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format"),
    ] = False,
) -> None:
    """Display tasks in a Kanban board view."""
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        task_service = services.get_task_service()
        workspaces_client = services.get_workspaces_client()

        # Validate workspace config (guards against -O flag and provides type narrowing)
        workspace_config = require_workspace_config(ctx.workspace_config)

        try:
            # Parse filters
            status_list = None
            if status:
                status_list = [Status(s.strip()) for s in status.split(",")]

            label_list = None
            if labels:
                label_list = [label.strip() for label in labels.split(",")]

            # Handle owner filtering
            owner_filter = None
            if assignee:
                owner_filter = assignee
            elif mine or me:
                owner_filter = "me"

            # Fetch all tasks
            filters = TaskFilters(
                workspace_id=int(workspace_config.workspace_id),
                status=status_list,
                phase=phase,
                owner=owner_filter,
                labels=label_list,
                limit=100,
                sort_by=sort,
                order="desc",
            )
            task_list = await task_service.list_tasks(filters)
            tasks = [task.model_dump() for task in task_list]

            if not tasks:
                if json_output:
                    print(format_empty_tasks_json())
                else:
                    console.print("[yellow]No tasks found[/yellow]")
                    console.print(
                        "Create one with: [cyan]anyt task add 'Task title'[/cyan]"
                    )
                return

            # Fetch dependency graph
            graph = await workspaces_client.get_dependency_graph(
                workspace_id=int(workspace_config.workspace_id)
            )
            annotate_blocked_tasks_from_graph(tasks, graph)

            # Group tasks
            groups, group_order, group_labels = _get_task_groups(
                tasks, group_by, json_output
            )

            # Output
            if json_output:
                print(format_board_json(groups, group_order, group_labels, len(tasks)))
                return

            if compact:
                console.print(format_compact_board(groups, group_order, group_labels))
                return

            # Full board display
            workspace_name = workspace_config.workspace_identifier or "Workspace"
            render_board_header(workspace_name, console)
            render_board_table(groups, group_order, group_labels, limit, console)

            max_tasks = max(len(groups.get(g, [])) for g in group_order)
            max_display = min(max_tasks, limit)
            render_board_footer(len(tasks), max_display, console)

        except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error for any board loading failure
            if json_output:
                print(format_error_json(f"Failed to load board: {str(e)}"))
            else:
                console.print(f"[red]Error:[/red] Failed to load board: {e}")
            raise typer.Exit(1)


def _get_task_groups(
    tasks: list[dict[str, Any]],
    group_by: str,
    json_output: bool,
) -> tuple[dict[str, list[dict[str, Any]]], list[str], dict[str, str]]:
    """Get task groups based on grouping option."""
    if group_by == "status":
        groups = group_tasks_by_status(tasks)
        group_order = ["backlog", "active", "blocked", "done"]
        group_labels = {
            "backlog": "Backlog",
            "active": "Active",
            "blocked": "Blocked",
            "done": "Done",
        }
    elif group_by == "priority":
        groups = group_tasks_by_priority(tasks)
        group_order = ["highest", "high", "normal", "low", "lowest"]
        group_labels = {
            "highest": "Highest (2)",
            "high": "High (1)",
            "normal": "Normal (0)",
            "low": "Low (-1)",
            "lowest": "Lowest (-2)",
        }
    elif group_by == "owner":
        groups = group_tasks_by_owner(tasks)
        group_order = sorted(groups.keys(), key=lambda x: (x != "Unassigned", x))
        group_labels = {k: k for k in group_order}
    elif group_by == "labels":
        groups = group_tasks_by_labels(tasks)
        group_order = sorted(groups.keys(), key=lambda x: (x != "No Labels", x))
        group_labels = {k: k for k in group_order}
    else:
        if not json_output:
            console.print(
                f"[yellow]Unknown grouping '{group_by}', using status[/yellow]"
            )
        groups = group_tasks_by_status(tasks)
        group_order = ["backlog", "active", "blocked", "done"]
        group_labels = {
            "backlog": "Backlog",
            "active": "Active",
            "blocked": "Blocked",
            "done": "Done",
        }

    return groups, group_order, group_labels


@app.command("summary")
@async_command()
async def show_summary(
    period: Annotated[
        str,
        typer.Option("--period", help="Summary period: today, weekly, monthly"),
    ] = "today",
    phase: Annotated[
        Optional[str],
        typer.Option("--phase", help="Filter by phase/milestone"),
    ] = None,
    format_output: Annotated[
        str,
        typer.Option("--format", help="Output format: text, markdown, json"),
    ] = "text",
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format"),
    ] = False,
) -> None:
    """Generate workspace summary with done, active, blocked, and next priorities."""
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        task_service = services.get_task_service()
        workspaces_client = services.get_workspaces_client()

        # Validate workspace config (guards against -O flag and provides type narrowing)
        workspace_config = require_workspace_config(ctx.workspace_config)

        try:
            # Fetch all tasks
            filters = TaskFilters(
                workspace_id=int(workspace_config.workspace_id),
                phase=phase,
                limit=100,
                sort_by="updated_at",
                order="desc",
            )
            task_list = await task_service.list_tasks(filters)
            tasks = [task.model_dump() for task in task_list]
            total = len(tasks)

            if not tasks:
                console.print("[yellow]No tasks in workspace[/yellow]")
                return

            # Categorize tasks
            done_tasks = [t for t in tasks if t.get("status") == "done"]
            active_tasks = [t for t in tasks if t.get("status") == "active"]
            backlog_tasks = [t for t in tasks if t.get("status") in ["backlog", "todo"]]

            # Fetch dependency graph and annotate blocked tasks
            graph = await workspaces_client.get_dependency_graph(
                workspace_id=int(workspace_config.workspace_id)
            )
            annotate_blocked_tasks_from_graph(tasks, graph)
            blocked_tasks = [t for t in tasks if "blocked_by" in t]

            use_json = json_output or format_output == "json"

            if use_json:
                print(
                    format_summary_json(
                        period,
                        done_tasks,
                        active_tasks,
                        blocked_tasks,
                        backlog_tasks,
                        total,
                    )
                )
                return

            # Render summary
            render_summary_header(period, console)
            render_summary_section("Done", "✅", "green", done_tasks, 5, console)
            render_summary_section(
                "Active", "🔄", "yellow", active_tasks, 5, console, show_owner=True
            )

            if blocked_tasks:
                render_summary_section(
                    "Blocked", "🚫", "red", blocked_tasks, 10, console
                )

            high_priority_backlog = sorted(
                backlog_tasks, key=lambda t: t.get("priority", 0), reverse=True
            )
            render_priorities_section(high_priority_backlog, console)
            render_progress_footer(len(done_tasks), total, console)

        except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error for any summary generation failure
            use_json = json_output or format_output == "json"
            if use_json:
                print(format_error_json(f"Failed to generate summary: {str(e)}"))
            else:
                console.print(f"[red]Error:[/red] Failed to generate summary: {e}")
            raise typer.Exit(1)


@app.command("graph")
@async_command()
async def show_graph(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier to show dependencies for (shows all if not specified)"
        ),
    ] = None,
    format_output: Annotated[
        str,
        typer.Option("--format", help="Output format: ascii, dot, json"),
    ] = "ascii",
    status: Annotated[
        Optional[str],
        typer.Option("--status", help="Filter by status (comma-separated)"),
    ] = None,
    priority_min: Annotated[
        Optional[int],
        typer.Option("--priority-min", help="Filter by minimum priority"),
    ] = None,
    labels: Annotated[
        Optional[str],
        typer.Option("--labels", help="Filter by labels (comma-separated)"),
    ] = None,
    phase: Annotated[
        Optional[str],
        typer.Option("--phase", help="Filter by phase/milestone"),
    ] = None,
    mine: Annotated[
        bool,
        typer.Option("--mine", help="Show only tasks assigned to you"),
    ] = False,
    depth: Annotated[
        Optional[int],
        typer.Option("--depth", help="Max dependency depth to show"),
    ] = None,
    compact: Annotated[
        bool,
        typer.Option("--compact", help="Compact display mode"),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format"),
    ] = False,
) -> None:
    """Visualize task dependencies as ASCII art or DOT format."""
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        task_service = services.get_task_service()

        # Validate workspace config (guards against -O flag and provides type narrowing)
        workspace_config = require_workspace_config(ctx.workspace_config)

        try:
            if identifier:
                await _show_single_task_graph(
                    task_service, identifier, format_output, json_output
                )
            else:
                ws_identifier = workspace_config.workspace_identifier or "Workspace"
                await _show_workspace_graph(
                    task_service,
                    workspace_config.workspace_id,
                    ws_identifier,
                    status,
                    priority_min,
                    labels,
                    phase,
                    mine,
                    depth,
                    compact,
                    format_output,
                    json_output,
                )

        except Exception as e:  # noqa: BLE001 - Intentionally broad: display user-friendly error for any graph generation failure
            error_msg = str(e)
            use_json = json_output or format_output == "json"

            if use_json:
                error = (
                    "Task not found"
                    if "404" in error_msg
                    else f"Failed to generate graph: {error_msg}"
                )
                print(format_error_json(error, error_msg))
            else:
                if "404" in error_msg and identifier:
                    console.print(f"[red]Error:[/red] Task '{identifier}' not found")
                else:
                    console.print(f"[red]Error:[/red] Failed to generate graph: {e}")
            raise typer.Exit(1)


async def _show_single_task_graph(
    task_service: TaskService,
    identifier: str,
    format_output: str,
    json_output: bool,
) -> None:
    """Show dependencies for a specific task."""
    task = await task_service.get_task(identifier)
    task_id = task.identifier or str(task.id)
    title = task.title
    task_status = task.status.value if task.status else ""

    dependencies = await task_service.get_task_dependencies(identifier)
    dependents = await task_service.get_task_dependents(identifier)

    if json_output or format_output == "json":
        print(
            format_graph_task_json(
                task_id, title, task_status, dependencies, dependents
            )
        )
        return

    render_task_dependency_graph(
        task_id, title, task_status, dependencies, dependents, console
    )


async def _show_workspace_graph(
    task_service: TaskService,
    workspace_id: int,
    workspace_identifier: str,
    status: Optional[str],
    priority_min: Optional[int],
    labels: Optional[str],
    phase: Optional[str],
    mine: bool,
    depth: Optional[int],
    compact: bool,
    format_output: str,
    json_output: bool,
) -> None:
    """Show full workspace dependency graph."""
    # Parse filters
    status_list = None
    if status:
        status_list = [Status(s.strip()) for s in status.split(",")]

    label_list = None
    if labels:
        label_list = [label.strip() for label in labels.split(",")]

    owner_filter = "me" if mine else None

    # Build dependency graph
    graph = await build_workspace_dependency_graph(
        task_service=task_service,
        workspace_id=int(workspace_id),
        status_filter=status_list,
        priority_min=priority_min,
        labels_filter=label_list,
        phase_filter=phase,
        owner_filter=owner_filter,
        max_depth=depth,
    )

    if not graph.nodes:
        if json_output or format_output == "json":
            print(format_empty_graph_json())
        else:
            console.print("[yellow]No tasks found in workspace[/yellow]")
            console.print("Create one with: [cyan]anyt task add 'Task title'[/cyan]")
        return

    cycles = graph.find_cycles()
    if cycles and not (json_output or format_output == "json"):
        console.print(
            f"[yellow]⚠ Warning: {len(cycles)} circular dependencies detected![/yellow]"
        )
        console.print()

    use_json = json_output or format_output == "json"

    if use_json:
        data = render_json_graph(graph)
        print(json.dumps({"success": True, "data": data, "message": None}, indent=2))
    elif format_output == "dot":
        dot_output = render_dot_graph(graph)
        console.print(dot_output)
    else:
        render_graph_header(workspace_identifier, console)
        ascii_graph = render_ascii_graph(graph, compact=compact)
        console.print(ascii_graph)
        render_graph_footer(len(graph.nodes), len(graph.edges), cycles, console)
