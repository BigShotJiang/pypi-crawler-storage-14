"""API client for system worker operations."""

# pyright: reportUnknownVariableType=false, reportUnknownMemberType=false

import os
from typing import Any, Optional

from sdk.generated.api_config import APIConfig
from sdk.generated.models.AssigneeType import AssigneeType as GeneratedAssigneeType
from sdk.generated.models.CloneInfo import CloneInfo
from sdk.generated.models.Comment import Comment
from sdk.generated.models.CreateCommentRequest import CreateCommentRequest
from sdk.generated.models.Task import Task as GeneratedTask
from sdk.generated.models.TaskListResponse import TaskListResponse
from sdk.generated.models.TaskStatus import TaskStatus as GeneratedTaskStatus
from sdk.generated.models.TaskUpdate import TaskUpdate as GeneratedTaskUpdate
from cli.models.wrappers.task import Task

# Import generated service functions
from sdk.generated.services.async_Workers_service import (  # pyright: ignore[reportMissingImports]  # noqa: F401
    addWorkerComment,
    getProjectCloneInfo,
    getWorkerTask,
    listDemoTasks,
    updateWorkerTask,
)


class WorkersAPIClient:
    """API client for system worker operations.

    This client uses generated service functions for worker-specific endpoints
    that require worker token authentication (X-Worker-Token header).
    """

    def __init__(self, base_url: str, worker_token: str):
        """Initialize with API configuration and worker token.

        Args:
            base_url: Base URL for the API
            worker_token: Worker authentication token (from WORKER_API_TOKEN env var)

        Raises:
            ValueError: If worker_token is not provided
        """
        if not worker_token:
            raise ValueError("worker_token is required for WorkersAPIClient")
        self.base_url = base_url
        self.worker_token = worker_token

    @classmethod
    def from_env(cls) -> "WorkersAPIClient":
        """Create client from environment variables.

        Expects:
            WORKER_API_TOKEN: Worker authentication token (required)
            ANYT_API_URL: API base URL (optional, defaults to https://api.anyt.dev)

        Returns:
            WorkersAPIClient instance

        Raises:
            ValueError: If WORKER_API_TOKEN is not set
        """
        worker_token = os.getenv("WORKER_API_TOKEN")
        if not worker_token:
            raise ValueError(
                "WORKER_API_TOKEN environment variable is required for worker operations. "
                "Please set it to your worker authentication token."
            )

        # Use ANYT_API_URL if set, otherwise default
        base_url = os.getenv("ANYT_API_URL", "https://api.anyt.dev")

        return cls(base_url=base_url, worker_token=worker_token)

    def _get_api_config(self) -> APIConfig:
        """Get APIConfig for generated client calls."""
        if not self.base_url:
            raise ValueError("API base URL not configured")
        # Worker endpoints don't use Bearer auth, only X-Worker-Token
        return APIConfig(base_path=self.base_url, access_token=None)

    async def list_demo_tasks(
        self,
        status: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> list[Task]:
        """List tasks from demo projects.

        Args:
            status: Filter by task status (e.g., "todo", "active", "done")
            limit: Maximum number of tasks to return (default: 10)
            offset: Number of tasks to skip (default: 0)

        Returns:
            List of Task objects from demo projects

        Raises:
            APIError: On HTTP errors (401 for invalid token, etc.)
        """
        response = await listDemoTasks(
            api_config_override=self._get_api_config(),
            X_Worker_Token=self.worker_token,
            status=status,
            limit=limit,
            offset=offset,
        )

        # Extract items from response
        response_data: TaskListResponse = response
        items = response_data.items if response_data and response_data.items else []

        # Wrap generated models in domain wrappers
        return [Task(item) for item in items]

    async def get_task(self, identifier: str) -> Task:
        """Get task details by identifier.

        Args:
            identifier: Task identifier (e.g., DEMO-42)

        Returns:
            Task object

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        response = await getWorkerTask(
            api_config_override=self._get_api_config(),
            identifier=identifier,
            X_Worker_Token=self.worker_token,
        )

        task_data: GeneratedTask = response
        return Task(task_data)

    async def update_task(
        self,
        identifier: str,
        status: Optional[str] = None,
        assignee_type: Optional[str] = None,
        owner_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Task:
        """Update task fields.

        Args:
            identifier: Task identifier (e.g., DEMO-42)
            status: New task status (e.g., "todo", "active", "done")
            assignee_type: New assignee type ("human" or "agent")
            owner_id: New owner/assignee ID
            **kwargs: Additional fields to update (title, description, priority, etc.)

        Returns:
            Updated Task object

        Raises:
            NotFoundError: If task not found
            ValidationError: If update data is invalid
            APIError: On other HTTP errors
        """
        # Convert status string to TaskStatus enum if provided
        task_status: Optional[GeneratedTaskStatus] = None
        if status:
            task_status = GeneratedTaskStatus(status)

        # Convert assignee_type string to AssigneeType enum if provided
        task_assignee_type: Optional[GeneratedAssigneeType] = None
        if assignee_type:
            task_assignee_type = GeneratedAssigneeType(assignee_type)

        # Build TaskUpdate from parameters
        update_data = GeneratedTaskUpdate(
            status=task_status,
            assignee_type=task_assignee_type,
            owner_id=owner_id,
            title=kwargs.get("title"),
            description=kwargs.get("description"),
            priority=kwargs.get("priority"),
            parent_id=kwargs.get("parent_id"),
            goal_id=kwargs.get("goal_id"),
            labels=kwargs.get("labels"),
            estimate=kwargs.get("estimate"),
            phase=kwargs.get("phase"),
            project_id=kwargs.get("project_id"),
        )

        response = await updateWorkerTask(
            api_config_override=self._get_api_config(),
            identifier=identifier,
            X_Worker_Token=self.worker_token,
            data=update_data,
        )

        task_data: GeneratedTask = response
        return Task(task_data)

    async def add_comment(self, identifier: str, content: str) -> Comment:
        """Add a comment to a task.

        Args:
            identifier: Task identifier (e.g., DEMO-42)
            content: Comment content/text

        Returns:
            Created Comment object

        Raises:
            NotFoundError: If task not found
            ValidationError: If comment is invalid
            APIError: On other HTTP errors
        """
        comment_request = CreateCommentRequest(content=content)

        response = await addWorkerComment(
            api_config_override=self._get_api_config(),
            identifier=identifier,
            X_Worker_Token=self.worker_token,
            data=comment_request,
        )

        comment_data: Comment = response
        return comment_data

    async def get_clone_info(self, project_id: int) -> CloneInfo:
        """Get repository clone information for a demo project.

        Args:
            project_id: Demo project ID

        Returns:
            CloneInfo object with clone_url, branch, project_id, external_repo_id

        Raises:
            NotFoundError: If project not found
            APIError: On other HTTP errors
        """
        response = await getProjectCloneInfo(
            api_config_override=self._get_api_config(),
            project_id=project_id,
            X_Worker_Token=self.worker_token,
        )

        clone_info: CloneInfo = response
        return clone_info
