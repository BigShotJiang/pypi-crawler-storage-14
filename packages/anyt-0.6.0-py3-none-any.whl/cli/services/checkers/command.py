"""Command requirement checker."""

from __future__ import annotations

import asyncio
import platform
import shutil
from datetime import datetime, timedelta
from typing import ClassVar

from cli.models.workflow_requirements import CommandRequirement, RequirementCheckResult


class CommandChecker:
    """Checker for command-line tool requirements."""

    # Cache for check results (class-level to share across instances)
    _cache: ClassVar[dict[str, tuple[RequirementCheckResult, datetime]]] = {}
    _default_ttl: ClassVar[timedelta] = timedelta(minutes=5)

    async def check(
        self, requirement: CommandRequirement, use_cache: bool = True
    ) -> RequirementCheckResult:
        """
        Check if a command-line tool is installed and optionally validate it.

        Args:
            requirement: The command requirement to check
            use_cache: Whether to use cached results (default: True)

        Returns:
            RequirementCheckResult with success status and instructions
        """
        cache_key = f"command:{requirement.name}"

        # Check cache if enabled
        if use_cache and cache_key in self._cache:
            cached_result, timestamp = self._cache[cache_key]
            if datetime.now() - timestamp < self._default_ttl:
                # Return cached result with from_cache=True
                cached_result.from_cache = True
                return cached_result

        # Check if command exists
        if not shutil.which(requirement.name):
            result = RequirementCheckResult(
                success=False,
                message=f"{requirement.name} not found",
                fix_instructions=self._get_install_instructions(requirement),
                warning=not requirement.required,
                from_cache=False,
            )
            self._cache[cache_key] = (result, datetime.now())
            return result

        # If check_command is provided, run it to validate
        if requirement.check_command:
            try:
                version = await self._run_check_command(requirement.check_command)
                result = RequirementCheckResult(
                    success=True,
                    message=f"{requirement.name} installed ({version})",
                    fix_instructions=None,
                    warning=False,
                    from_cache=False,
                )
            except (OSError, RuntimeError) as e:
                # OSError: Command execution failed
                # RuntimeError: Command-specific validation errors
                result = RequirementCheckResult(
                    success=False,
                    message=f"{requirement.name} found but validation failed: {e}",
                    fix_instructions=self._get_install_instructions(requirement),
                    warning=not requirement.required,
                    from_cache=False,
                )
        else:
            # No check command, just confirm existence
            result = RequirementCheckResult(
                success=True,
                message=f"{requirement.name} installed",
                fix_instructions=None,
                warning=False,
                from_cache=False,
            )

        # Cache the result
        self._cache[cache_key] = (result, datetime.now())
        return result

    async def _run_check_command(self, command: str) -> str:
        """
        Run a check command and return its output.

        Args:
            command: The command to run (e.g., "git --version")

        Returns:
            The command output (stdout)

        Raises:
            Exception: If the command fails
        """
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()

        if process.returncode != 0:
            error_msg = stderr.decode().strip() if stderr else "Command failed"
            raise Exception(error_msg)

        return stdout.decode().strip()

    def _get_install_instructions(self, requirement: CommandRequirement) -> str:
        """
        Get OS-specific installation instructions.

        Args:
            requirement: The command requirement

        Returns:
            Formatted installation instructions for the current OS
        """
        if not requirement.install_instructions:
            return f"Please install {requirement.name}"

        # Get current OS
        current_os = platform.system().lower()
        os_map = {
            "darwin": "darwin",
            "linux": "linux",
            "windows": "windows",
        }
        os_key = os_map.get(current_os)

        # Get instructions for current OS
        if os_key and os_key in requirement.install_instructions:
            return requirement.install_instructions[os_key]

        # Fallback: show all available instructions
        if requirement.install_instructions:
            instructions = "\n".join(
                f"  {os_name}: {cmd}"
                for os_name, cmd in requirement.install_instructions.items()
            )
            return f"Install {requirement.name}:\n{instructions}"

        return f"Please install {requirement.name}"

    @classmethod
    def clear_cache(cls) -> None:
        """Clear the check result cache."""
        cls._cache.clear()
