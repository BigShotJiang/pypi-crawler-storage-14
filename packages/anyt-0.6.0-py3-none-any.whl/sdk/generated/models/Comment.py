from typing import *
from pydantic import BaseModel, Field

class Comment(BaseModel):
    """
    Comment model
        Full comment schema.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    content : str = Field(validation_alias="content" )
    
    mentioned_users : Optional[List[str]] = Field(validation_alias="mentioned_users" , default = None )
    
    id : int = Field(validation_alias="id" )
    
    task_id : int = Field(validation_alias="task_id" )
    
    author_id : str = Field(validation_alias="author_id" )
    
    author_type : str = Field(validation_alias="author_type" )
    
    parent_id : Optional[Union[int,None]] = Field(validation_alias="parent_id" , default = None )
    
    edited_at : Optional[Union[str,None]] = Field(validation_alias="edited_at" , default = None )
    
    created_at : str = Field(validation_alias="created_at" )
    
    updated_at : str = Field(validation_alias="updated_at" )
    
    deleted_at : Optional[Union[str,None]] = Field(validation_alias="deleted_at" , default = None )
    