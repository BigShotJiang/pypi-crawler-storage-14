from typing import *
from pydantic import BaseModel, Field
from .Label import Label

class LabelListResponse(BaseModel):
    """
    LabelListResponse model
        Response for paginated label list.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    items : List[Label] = Field(validation_alias="items" )
    
    total : int = Field(validation_alias="total" )
    
    limit : int = Field(validation_alias="limit" )
    
    offset : int = Field(validation_alias="offset" )
    