from typing import *
from pydantic import BaseModel, Field

class TemplateCreate(BaseModel):
    """
    TemplateCreate model
        Data required to create a template.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    name : str = Field(validation_alias="name" )
    
    slug : str = Field(validation_alias="slug" )
    
    description : Optional[Union[str,None]] = Field(validation_alias="description" , default = None )
    
    github_org : str = Field(validation_alias="github_org" )
    
    github_repo : str = Field(validation_alias="github_repo" )
    
    category : Optional[Union[str,None]] = Field(validation_alias="category" , default = None )
    
    icon_url : Optional[Union[str,None]] = Field(validation_alias="icon_url" , default = None )
    
    is_default : Optional[bool] = Field(validation_alias="is_default" , default = None )
    
    is_active : Optional[bool] = Field(validation_alias="is_active" , default = None )
    
    display_order : Optional[int] = Field(validation_alias="display_order" , default = None )
    