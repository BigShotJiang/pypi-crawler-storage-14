from typing import *
from pydantic import BaseModel, Field

class TemplateUpdate(BaseModel):
    """
    TemplateUpdate model
        Data for updating a template. All fields optional.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    name : Optional[Union[str,None]] = Field(validation_alias="name" , default = None )
    
    description : Optional[Union[str,None]] = Field(validation_alias="description" , default = None )
    
    github_org : Optional[Union[str,None]] = Field(validation_alias="github_org" , default = None )
    
    github_repo : Optional[Union[str,None]] = Field(validation_alias="github_repo" , default = None )
    
    category : Optional[Union[str,None]] = Field(validation_alias="category" , default = None )
    
    icon_url : Optional[Union[str,None]] = Field(validation_alias="icon_url" , default = None )
    
    is_default : Optional[Union[bool,None]] = Field(validation_alias="is_default" , default = None )
    
    is_active : Optional[Union[bool,None]] = Field(validation_alias="is_active" , default = None )
    
    display_order : Optional[Union[int,None]] = Field(validation_alias="display_order" , default = None )
    