import pytest

from sbom_cve_check.vuln.cve import CveId

cve_id_test_data: list[tuple[str, ...]] = [
    ("CVE-2025-0300", "2025", "0300"),
    ("CVE-2025-12345", "2025", "12345"),
]


@pytest.mark.parametrize("test_data", cve_id_test_data)
def test_cve_id(test_data: tuple[str, ...]) -> None:
    cve_id = CveId(test_data[0])
    assert CveId(test_data[0]) == CveId(test_data[0])
    assert test_data[0] == str(cve_id)
    assert cve_id.year_and_number == (test_data[1], test_data[2])
    assert cve_id.year == test_data[1]
    assert cve_id.number == test_data[2]
