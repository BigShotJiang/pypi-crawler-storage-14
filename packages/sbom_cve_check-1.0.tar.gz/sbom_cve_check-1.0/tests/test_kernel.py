import pathlib

import pytest
from checker.export_checker import ExportBuild, ExportCve
from checker.runner import generate_and_check_exports
from checker.sbom_spdx3 import Spdx3SbomBuilder, SwPackage

from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.vuln.cve import CveVexStatus


def _init_kernel_test(
    sbom_path: pathlib.Path,
    vers: str,
    build_srcs: list[str],
) -> ExportBuild:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("kernel-linux")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="kernel-linux",
                cpes=[
                    f"cpe:2.3:o:*:linux_kernel:{vers}:*:*:*:*:*:*:*",
                    f"cpe:2.3:o:linux:linux:{vers}:*:*:*:*:*:*:*",
                ],
                pkg_version=f"{vers}+git",
            )
        ],
    )

    if build_srcs:
        sbom.add_source_files(build, build_srcs)

    sbom.write_to_jsonld(sbom_path)

    return ExportBuild(
        build_name="kernel-linux",
        vers_ids=CompVersIds(
            ids=[
                CompId(part="o", name="linux_kernel"),
                CompId(part="o", vendor="linux", name="linux"),
            ],
            version=vers,
        ),
        cves=[],
    )


def test_all_annotations(tmp_dir: pathlib.Path) -> None:
    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    exp_build = _init_kernel_test(sbom_path, "6.17.7", [])
    exp_build.unexpected_cves = []
    generate_and_check_exports(
        tmp_dir, ["--sbom-path", str(sbom_path)], [exp_build], True
    )


def test_filters_01(tmp_dir: pathlib.Path) -> None:
    sbom_path = tmp_dir.joinpath("sbom.spdx.json")

    cves = [
        ExportCve(
            cve_id="CVE-2007-2764",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_20=7.8,
            cvss_vect_20="AV:N/AC:L/Au:N/C:N/I:N/A:C",
        ),
        ExportCve(
            cve_id="CVE-2017-6264",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_20=9.3,
            cvss_vect_20="AV:N/AC:M/Au:N/C:C/I:C/A:C",
            cvss_scor_30=7.8,
            cvss_vect_30="CVSS:3.0/AV:L/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2018-10902",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_20=4.6,
            cvss_vect_20="AV:L/AC:L/Au:N/C:P/I:P/A:P",
            cvss_scor_30=7.8,
            cvss_vect_30="CVSS:3.0/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2020-16119",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_20=4.6,
            cvss_vect_20="AV:L/AC:L/Au:N/C:P/I:P/A:P",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2020-27815",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_20=6.1,
            cvss_vect_20="AV:L/AC:L/Au:N/C:P/I:P/A:C",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2021-20194",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_20=4.6,
            cvss_vect_20="AV:L/AC:L/Au:N/C:P/I:P/A:P",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2021-4440",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=8.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2021-47342",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2022-2327",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2022-3534",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_31=8.0,
            cvss_vect_31="CVSS:3.1/AV:A/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2022-3636",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2023-3079",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_31=8.8,
            cvss_vect_31="CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2023-3640",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2023-52983",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2024-0193",
            status=CveVexStatus.AFFECTED,
            notes="no-version-ranges",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2024-26792",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2024-26800",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2024-40920",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2024-49854",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
        ExportCve(
            cve_id="CVE-2024-56766",
            status=CveVexStatus.AFFECTED,
            notes="version-in-range",
            cvss_scor_31=7.8,
            cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
        ),
    ]

    exp_build = _init_kernel_test(sbom_path, "6.17.7", [])
    exp_build.cves = cves
    generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            str(sbom_path),
            "--export-filter-vulnerable",
            "--export-filter-cve-min-cvss-score",
            "7.8",
        ],
        [exp_build],
        True,
    )


@pytest.mark.parametrize(
    "src_prefix,src_present",
    [
        (None, True),
        ("../", True),
        ("", True),
        ("/", True),
        ("linux-yocto-6.16.9+git/", True),
        ("/a/b/c/d/", True),
        ("build/", False),
    ],
)
def test_filter_build_src_01(
    tmp_dir: pathlib.Path, src_prefix: str | None, src_present: bool
) -> None:
    sbom_path = tmp_dir.joinpath("sbom.spdx.json")

    cve_vuln = ExportCve(
        cve_id="CVE-2024-56766",
        status=CveVexStatus.AFFECTED,
        notes="version-in-range",
        cvss_scor_31=7.8,
        cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
    )

    cve_not_vuln = ExportCve(
        cve_id="CVE-2024-56766",
        status=CveVexStatus.NOT_AFFECTED,
        notes="not-applicable-platform",
        cvss_scor_31=7.8,
        cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
    )

    build_srcs = [
        "arch/arm/kernel/process.c",
        "arch/arm/kernel/ptrace.c",
        "arch/arm/kernel/reboot.c",
        "arch/arm/kernel/reboot.h",
        "arch/arm/kernel/setup.c",
        "arch/arm/kernel/signal.c",
        "arch/arm/kernel/signal.h",
        "drivers/mtd/nand/raw/nand_base.c",
    ]

    is_vuln = False
    if src_present:
        build_srcs.append("drivers/mtd/nand/raw/atmel/pmecc.c")
        is_vuln = True

    if src_prefix is None:
        build_srcs = [s.split("/", maxsplit=1)[1] for s in build_srcs]
        is_vuln = False
    else:
        build_srcs = [f"{src_prefix}{s}" for s in build_srcs]

    exp_build = _init_kernel_test(sbom_path, "6.17.7", build_srcs)
    exp_build.cves = [cve_vuln if is_vuln else cve_not_vuln]
    exp_build.unexpected_cves = []
    generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            str(sbom_path),
            "--export-filter-cve-min-cvss-score",
            "7.8",
        ],
        [exp_build],
        True,
    )


@pytest.mark.parametrize(
    "add_all_src,add_affected_src",
    [(False, True), (True, True), (False, False)],
)
def test_filter_build_src_02(
    tmp_dir: pathlib.Path,
    add_all_src: bool,
    add_affected_src: bool,
) -> None:
    sbom_path = tmp_dir.joinpath("sbom.spdx.json")

    cve_vuln = ExportCve(
        cve_id="CVE-2025-37984",
        status=CveVexStatus.AFFECTED,
        notes="version-in-range",
        cvss_scor_31=5.5,
        cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H",
    )

    build_srcs = []

    if add_affected_src:
        build_srcs.extend(
            [
                "crypto/ecc.c",
                "crypto/ecdsa-p1363.c",
            ]
        )

    build_srcs.extend(
        [
            "arch/arm/kernel/process.c",
            "arch/arm/kernel/ptrace.c",
            "arch/arm/kernel/reboot.c",
            "arch/arm/kernel/reboot.h",
            "arch/arm/kernel/setup.c",
        ]
    )

    if add_affected_src and add_all_src:
        build_srcs.extend(
            [
                "crypto/ecdsa-x962.c",
                "include/linux/math.h",
            ]
        )

    exp_build = _init_kernel_test(sbom_path, "6.14.4", build_srcs)
    exp_build.cves = [cve_vuln] if add_affected_src else []
    exp_build.unexpected_cves = [] if add_affected_src else [cve_vuln.cve_id]
    generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            str(sbom_path),
            "--export-filter-vulnerable",
        ],
        [exp_build],
        True,
    )
