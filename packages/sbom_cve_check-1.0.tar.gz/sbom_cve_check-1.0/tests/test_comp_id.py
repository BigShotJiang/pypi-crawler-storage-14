from sbom_cve_check.sbom.component import CompId


def test_comp_id_str_01() -> None:
    c = CompId.build_from_cpe("cpe:2.3:a:haxx:libcurl:7.16.3:*:*:*:*:*:*:*")
    assert c is not None
    assert c.part == "a"
    assert c.vendor == "haxx"
    assert c.name == "libcurl"

    assert c.to_str() == "haxx:libcurl"
    assert c.to_str(False) == "haxx:libcurl"
    assert c.to_str(True) == "a:haxx:libcurl"
    assert str(c) == "a:haxx:libcurl"


def test_comp_id_str_02() -> None:
    c = CompId.build_from_cpe("cpe:2.3:-:haxx:libcurl:7.16.3:*:*:*:*:*:*:*")
    assert c is None

    c = CompId.build_from_cpe("cpe:2.3:a:-:libcurl:7.16.3:*:*:*:*:*:*:*")
    assert c is None

    c = CompId.build_from_cpe("cpe:2.3:a:haxx:-:7.16.3:*:*:*:*:*:*:*")
    assert c is None

    c = CompId.build_from_cpe("cpe:2.3:a:haxx:*:7.16.3:*:*:*:*:*:*:*")
    assert c is None


def test_comp_id_str_03() -> None:
    c = CompId.build_from_cpe("cpe:2.3:*:haxx:libcurl:7.16.3:*:*:*:*:*:*:*")
    assert c is not None
    assert c.part is None
    assert c.vendor == "haxx"
    assert c.name == "libcurl"

    assert c.to_str() == "haxx:libcurl"
    assert c.to_str(False) == "haxx:libcurl"
    assert c.to_str(True) == "haxx:libcurl"
    assert str(c) == "haxx:libcurl"


def test_comp_id_str_04() -> None:
    c = CompId.build_from_cpe("cpe:2.3:a:*:libcurl:7.16.3:*:*:*:*:*:*:*")
    assert c is not None
    assert c.part == "a"
    assert c.vendor is None
    assert c.name == "libcurl"

    assert c.to_str() == "libcurl"
    assert c.to_str(False) == "libcurl"
    assert c.to_str(True) == "a::libcurl"
    assert str(c) == "a::libcurl"


def test_comp_id_str_05() -> None:
    c = CompId.build_from_cpe("cpe:2.3:*:*:libcurl:7.16.3:*:*:*:*:*:*:*")
    assert c is not None
    assert c.part is None
    assert c.vendor is None
    assert c.name == "libcurl"

    assert c.to_str() == "libcurl"
    assert c.to_str(False) == "libcurl"
    assert c.to_str(True) == "libcurl"
    assert str(c) == "libcurl"
