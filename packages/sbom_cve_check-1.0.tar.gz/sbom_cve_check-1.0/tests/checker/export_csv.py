import csv
import pathlib

# noinspection PyProtectedMember
from sbom_cve_check.export.export_csv import _Column
from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.vuln.cve import CveVexStatus

from .export_checker import ExportBuild, ExportChecker, ExportCve


class ExportCsvChecker(ExportChecker):
    def __init__(self, path: pathlib.Path) -> None:
        super().__init__()
        self._read_csv(path)

    def _check_vers_ids(self, exported: CompVersIds, expected: CompVersIds) -> None:
        ids = {CompId(vendor=i.vendor, name=i.name) for i in expected.ids}
        expected = CompVersIds(ids=ids, version=expected.version)
        assert exported == expected

    @staticmethod
    def _read_cve(row: list[str]) -> ExportCve:
        status = CveVexStatus(row[_Column.STATUS])

        score_v2 = row[_Column.SCOREV2]
        score_v3 = row[_Column.SCOREV3]
        score_v4 = row[_Column.SCOREV4]

        return ExportCve(
            cve_id=row[_Column.CVE_ID],
            status=status,
            notes=f"{row[_Column.STATEMENT]} {row[_Column.NOTES]}",
            cvss_scor_20=float(score_v2) if score_v2 else None,
            cvss_vect_20=None,
            cvss_scor_30=float(score_v3) if score_v3 else None,
            cvss_vect_30=None,
            cvss_scor_31=None,
            cvss_vect_31=None,
            cvss_scor_40=float(score_v4) if score_v4 else None,
            cvss_vect_40=None,
        )

    @staticmethod
    def _read_build_info(build_name: str, row: list[str]) -> ExportBuild:
        ids: set[CompId] = set()
        product_names = row[_Column.PRODUCT_NAMES].split(";")
        for product_name in product_names:
            ids.add(CompId.build_from_vendor_product_str(product_name.strip()))

        version = row[_Column.VERSION]
        assert version

        return ExportBuild(
            build_name=build_name,
            vers_ids=CompVersIds(ids=ids, version=version),
            cves=[],
        )

    def _read_csv(self, path: pathlib.Path) -> None:
        with path.open(newline="", encoding="utf-8") as f:
            csv_reader = csv.reader(f)
            next(csv_reader)
            curr_build_name = None
            lst_cves: list[ExportCve] = []
            for row in csv_reader:
                build_name = row[_Column.BUILD_NAME]
                if curr_build_name != build_name:
                    build = self._read_build_info(build_name, row)
                    lst_cves = build.cves
                    self._builds.append(build)
                    curr_build_name = build_name

                lst_cves.append(self._read_cve(row))

    def check_cve(self, exported: ExportCve, expected: ExportCve) -> None:
        assert exported.cve_id == expected.cve_id
        assert exported.status == expected.status
        assert expected.notes in exported.notes

        assert exported.cvss_scor_20 == expected.cvss_scor_20
        if expected.cvss_scor_31 is not None:
            assert exported.cvss_scor_30 == expected.cvss_scor_31
        else:
            assert exported.cvss_scor_30 == expected.cvss_scor_30
        assert exported.cvss_scor_40 == expected.cvss_scor_40
