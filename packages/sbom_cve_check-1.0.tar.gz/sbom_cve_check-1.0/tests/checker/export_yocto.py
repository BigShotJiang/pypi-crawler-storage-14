import json
import pathlib
from typing import Any

from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.vuln.cpe import Cpe23
from sbom_cve_check.vuln.cve import CveVexStatus

from .export_checker import ExportBuild, ExportChecker, ExportCve


class ExportYoctoChecker(ExportChecker):
    def __init__(self, path: pathlib.Path) -> None:
        super().__init__()
        self._read_json(path)

    @staticmethod
    def _read_cve(issue_obj: dict[str, Any]) -> ExportCve:
        status_str = issue_obj["status"]
        if status_str == "Patched":
            status = CveVexStatus.FIXED
        elif status_str == "Unpatched":
            status = CveVexStatus.AFFECTED
        elif status_str == "Ignored":
            status = CveVexStatus.NOT_AFFECTED
        else:
            raise AssertionError(status_str)

        score_v2 = issue_obj["scorev2"]
        score_v3 = issue_obj["scorev3"]
        score_v4 = issue_obj["scorev4"]
        vector_str = issue_obj["vectorString"]
        vector_v2 = None
        vector_v3 = None
        vector_v4 = None
        if score_v4 != "0.0":
            vector_v4 = vector_str
        elif score_v3 != "0.0":
            vector_v3 = vector_str
        elif score_v2 != "0.0":
            vector_v2 = vector_str

        return ExportCve(
            cve_id=issue_obj["id"],
            status=status,
            notes=issue_obj["detail"],
            cvss_scor_20=float(score_v2) or None,
            cvss_vect_20=vector_v2,
            cvss_scor_30=float(score_v3) or None,
            cvss_vect_30=vector_v3,
            cvss_scor_31=None,
            cvss_vect_31=None,
            cvss_scor_40=float(score_v4) or None,
            cvss_vect_40=vector_v4,
        )

    def _read_package(self, pkg_obj: dict[str, Any]) -> None:
        ids: set[CompId] = set()
        version = None
        for cpe_str in pkg_obj["cpes"]:
            cpe = Cpe23.parse(cpe_str)
            assert cpe
            assert isinstance(cpe.version, str)
            comp_id = CompId.build_from_cpe(cpe)
            assert comp_id
            ids.add(comp_id)
            if version is None:
                version = cpe.version
            else:
                assert version == cpe.version

        assert version
        cves: list[ExportCve] = [self._read_cve(issue) for issue in pkg_obj["issue"]]

        self._builds.append(
            ExportBuild(
                build_name=pkg_obj["name"],
                vers_ids=CompVersIds(ids=ids, version=version),
                cves=cves,
            )
        )

    def _read_json(self, path: pathlib.Path) -> None:
        with path.open(encoding="utf-8") as f:
            doc: dict[str, Any] = json.load(f)

        for package in doc["package"]:
            self._read_package(package)

    def check_cve(self, exported: ExportCve, expected: ExportCve) -> None:
        assert exported.cve_id == expected.cve_id

        expected_status = expected.status
        if expected_status == CveVexStatus.UNDER_INVESTIGATION:
            expected_status = CveVexStatus.AFFECTED
        assert exported.status == expected_status

        if exported.notes:
            assert expected.notes in exported.notes

        assert exported.cvss_scor_20 == expected.cvss_scor_20
        if expected.cvss_scor_31 is not None:
            assert exported.cvss_scor_30 == expected.cvss_scor_31
        else:
            assert exported.cvss_scor_30 == expected.cvss_scor_30
        assert exported.cvss_scor_40 == expected.cvss_scor_40

        if expected.cvss_vect_40 is not None:
            assert exported.cvss_vect_40 == expected.cvss_vect_40
        elif expected.cvss_vect_31 is not None:
            assert exported.cvss_vect_30 == expected.cvss_vect_31
        elif expected.cvss_vect_30 is not None:
            assert exported.cvss_vect_30 == expected.cvss_vect_30
        elif expected.cvss_vect_20 is not None:
            assert exported.cvss_vect_20 == expected.cvss_vect_20
        else:
            assert exported.cvss_vect_20 is None
            assert exported.cvss_vect_30 is None
            assert exported.cvss_vect_31 is None
            assert exported.cvss_vect_40 is None
