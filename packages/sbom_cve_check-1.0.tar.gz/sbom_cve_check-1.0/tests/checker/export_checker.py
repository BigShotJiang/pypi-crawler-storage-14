import abc
import dataclasses
from collections import defaultdict

from sbom_cve_check.sbom.component import CompVersIds
from sbom_cve_check.vuln.cve import CveVexStatus


@dataclasses.dataclass
class ExportCve:
    cve_id: str
    status: CveVexStatus
    notes: str
    cvss_scor_20: float | None = None
    cvss_vect_20: str | None = None
    cvss_scor_30: float | None = None
    cvss_vect_30: str | None = None
    cvss_scor_31: float | None = None
    cvss_vect_31: str | None = None
    cvss_scor_40: float | None = None
    cvss_vect_40: str | None = None


@dataclasses.dataclass()
class ExportBuild:
    build_name: str
    vers_ids: CompVersIds
    cves: list[ExportCve]
    unexpected_cves: list[str] | None = None


class ExportChecker(abc.ABC):
    def __init__(self) -> None:
        self._builds: list[ExportBuild] = []

    @abc.abstractmethod
    def check_cve(self, exported: ExportCve, expected: ExportCve) -> None:
        pass

    def _check_vers_ids(self, exported: CompVersIds, expected: CompVersIds) -> None:
        assert exported == expected

    def check_build(
        self,
        exported: ExportBuild,
        expected: ExportBuild,
        unexpected_cves: list[str] | None,
    ) -> None:
        assert exported.build_name == expected.build_name
        self._check_vers_ids(exported.vers_ids, expected.vers_ids)

        exported_cves: dict[str, list[ExportCve]] = defaultdict(list)
        for cve_exported in exported.cves:
            exported_cves[cve_exported.cve_id].append(cve_exported)

        for cve_expected in expected.cves:
            lst_cves = exported_cves.get(cve_expected.cve_id)
            assert lst_cves
            for cve_exported in lst_cves:
                self.check_cve(cve_exported, cve_expected)
            del exported_cves[cve_expected.cve_id]

        if unexpected_cves is None:
            assert not exported_cves
        else:
            for cve_id in unexpected_cves:
                assert cve_id not in exported_cves

    def check(
        self, expected_builds: list[ExportBuild], is_full_build_list: bool
    ) -> None:
        exported_builds: dict[str, ExportBuild] = {}
        for exported in self._builds:
            assert exported.build_name not in exported_builds
            exported_builds[exported.build_name] = exported

        for expected_build in expected_builds:
            exported_build = exported_builds.get(expected_build.build_name)
            assert exported_build
            self.check_build(
                exported_build, expected_build, expected_build.unexpected_cves
            )
            del exported_builds[expected_build.build_name]

        if is_full_build_list:
            assert not exported_builds
