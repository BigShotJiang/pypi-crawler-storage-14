import pathlib
import subprocess
from typing import Any

from checker.export_checker import ExportBuild
from checker.export_csv import ExportCsvChecker
from checker.export_spdx3 import ExportSpdx3Checker
from checker.export_yocto import ExportYoctoChecker


def exec_tool(tmp_dir: pathlib.Path, args: list[str]) -> None:
    # Use an override to configure fixed git reference/commit/tag
    override_cfg = pathlib.Path(__file__).parent.joinpath("cve_db_git_ref.toml")

    # Build arguments and execute
    cmd = ["sbom-cve-check", "--config", override_cfg.resolve(strict=True).as_posix()]
    cmd.extend(args)

    subprocess.run(
        cmd,
        input="",
        capture_output=True,
        check=True,
        cwd=tmp_dir,
        encoding="utf-8",
    )


def generate_and_check_exports(
    tmp_dir: pathlib.Path,
    args: list[str],
    expected_builds: list[ExportBuild],
    is_full_build_list: bool,
) -> dict[str, ExportYoctoChecker | ExportSpdx3Checker | ExportCsvChecker]:
    cmd_args = [
        "--export-type",
        "yocto-cve-check-manifest",
        "--export-path",
        "out.yocto.json",
        "--export-type",
        "spdx3",
        "--export-path",
        "out.spdx.json",
        "--export-type",
        "csv",
        "--export-path",
        "out.csv",
    ]
    cmd_args.extend(args)
    exec_tool(tmp_dir, cmd_args)

    exports: dict[str, ExportYoctoChecker | ExportSpdx3Checker | ExportCsvChecker] = {
        "yocto": ExportYoctoChecker(tmp_dir.joinpath("out.yocto.json")),
        "spdx3": ExportSpdx3Checker(tmp_dir.joinpath("out.spdx.json")),
        "csv": ExportCsvChecker(tmp_dir.joinpath("out.csv")),
    }

    for export in exports.values():
        export.check(expected_builds, is_full_build_list)

    return exports


def generate_from_template(
    tpl_path: pathlib.Path, out_path: pathlib.Path, **kwargs: Any
) -> None:
    with tpl_path.open(encoding="utf-8") as f_in:
        doc_tpl = f_in.read()

    for key, val in kwargs.items():
        doc_tpl.replace(f"${key}$", val)

    with out_path.open("w", encoding="utf-8") as f_out:
        f_out.write(doc_tpl)
