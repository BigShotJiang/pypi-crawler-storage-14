import dataclasses
import pathlib

from spdx_python_model.bindings import v3_0_1 as spdx30  # type: ignore[import-untyped]

from sbom_cve_check.sbom.lib_spdx3 import ObjectSet
from sbom_cve_check.vuln.cpe import Cpe23

ROOTFS_BUILD_TYPE = "http://openembedded.org/bitbake/do_create_rootfs_spdx/rootfs"
RECIPE_BUILD_TYPE = "http://openembedded.org/bitbake/do_create_spdx/recipe"


@dataclasses.dataclass
class SwPackage:
    name: str
    cpes: list[str]
    pkg_version: str
    description: str = ""


class Spdx3SbomBuilder:
    def __init__(self) -> None:
        objset = ObjectSet.new_objset("test-doc")
        self.objset = objset

        tool_name = "sbom-cve-check"
        agent = objset.new_agent(pn=tool_name, agent_type="software", name=tool_name)
        tool = objset.new_tool(pn=tool_name, name=tool_name)
        creation_info = objset.new_creation_info(tools=[tool], agents=[agent])
        objset.set_doc_creation_info(creation_info)

        image_name = "test-image"
        self.image_name = image_name
        objset.add_sbom_as_doc_root_element(image_name)

        rootfs_archive = spdx30.software_Package(
            _id=objset.new_spdxid("rootfs", image_name, pn=image_name),
            creationInfo=objset.doc_creation_info,
            name=image_name,
            software_primaryPurpose=spdx30.software_SoftwarePurpose.archive,
        )
        objset.add_sbom_root_element(rootfs_archive)

        self.rootfs_build = spdx30.build_Build(
            _id=objset.new_spdxid("build", "rootfs", pn=image_name),
            creationInfo=objset.doc_creation_info,
            name=f"{image_name}:do_create_rootfs_spdx:rootfs",
            build_buildType=ROOTFS_BUILD_TYPE,
        )
        objset.add(self.rootfs_build)

        rel = objset.new_scoped_relationship(
            [self.rootfs_build],
            spdx30.RelationshipType.hasOutput,
            spdx30.LifecycleScopeType.build,
            [rootfs_archive],
            pn=image_name,
        )
        objset.add(rel[0])

        self.rootfs_packages: list[spdx30.software_Package] = []

    def write_to_jsonld(self, path_spdx: pathlib.Path) -> None:
        rel = self.objset.new_scoped_relationship(
            [self.rootfs_build],
            spdx30.RelationshipType.hasInput,
            spdx30.LifecycleScopeType.build,
            self.rootfs_packages,
            pn=self.image_name,
        )
        self.objset.add(rel[0])
        self.objset.write_to_jsonld(path_spdx)

    def add_recipe(self, name: str) -> spdx30.build_Build:
        recipe_build = spdx30.build_Build(
            _id=self.objset.new_spdxid("build", "recipe", pn=name),
            creationInfo=self.objset.doc_creation_info,
            name=f"{name}:do_create_spdx:recipe",
            build_buildType=RECIPE_BUILD_TYPE,
        )
        self.objset.add(recipe_build)
        return recipe_build

    def add_source_files(self, build: spdx30.build_Build, paths: list[str]) -> None:
        pn = build.name.split(":")[0]
        src_files = []
        for idx, path in enumerate(paths):
            src_file = spdx30.software_File(
                _id=self.objset.new_spdxid("sourcefile", str(idx), pn=pn),
                creationInfo=self.objset.doc_creation_info,
                name=path,
                software_primaryPurpose=spdx30.software_SoftwarePurpose.source,
            )
            self.objset.add(src_file)
            src_files.append(src_file)

        rel = self.objset.new_scoped_relationship(
            [build],
            spdx30.RelationshipType.hasInput,
            spdx30.LifecycleScopeType.build,
            src_files,
            pn=pn,
        )
        self.objset.add(rel[0])

    def add_packages(
        self, build: spdx30.build_Build, pkgs: list[SwPackage]
    ) -> list[spdx30.software_Package]:
        pn = build.name.split(":")[0]
        sw_pkgs: list[spdx30.software_Package] = []
        for pkg in pkgs:
            sw_pkg = spdx30.software_Package(
                _id=self.objset.new_spdxid("package", pkg.name, pn=pkg.name),
                creationInfo=self.objset.doc_creation_info,
                description=pkg.description,
                name=pkg.name,
                software_primaryPurpose=spdx30.software_SoftwarePurpose.install,
                software_packageVersion=pkg.pkg_version,
            )

            for cpe_str in pkg.cpes:
                cpe = Cpe23.parse(cpe_str)
                assert cpe is not None
                sw_pkg.externalIdentifier.append(
                    spdx30.ExternalIdentifier(
                        externalIdentifierType=spdx30.ExternalIdentifierType.cpe23,
                        identifier=str(cpe),
                    )
                )

            self.objset.add(sw_pkg)
            sw_pkgs.append(sw_pkg)

        rel = self.objset.new_scoped_relationship(
            [build],
            spdx30.RelationshipType.hasOutput,
            spdx30.LifecycleScopeType.build,
            sw_pkgs,
            pn=pn,
        )
        self.objset.add(rel[0])
        self.rootfs_packages.extend(sw_pkgs)
        return sw_pkgs
