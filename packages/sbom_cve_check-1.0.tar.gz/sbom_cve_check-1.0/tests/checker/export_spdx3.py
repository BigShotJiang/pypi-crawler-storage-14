import dataclasses
import pathlib

from spdx_python_model.bindings import v3_0_1 as spdx30  # type: ignore[import-untyped]

from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.sbom.lib_spdx3 import (
    ObjectSet,
    cve_vex_assessment_from_vuln_relationship,
    cvss_metric_from_vuln_relationship,
    vuln_get_cve_id,
)
from sbom_cve_check.vuln.cve import (
    CveVexAffectedAssessment,
    CveVexAssessment,
    CveVexNotAffectedAssessment,
)
from sbom_cve_check.vuln.cvss import CvssMetric, CvssVersion

from .export_checker import ExportBuild, ExportChecker, ExportCve


@dataclasses.dataclass
class _CompInfoBuilder:
    ids: set[CompId] = dataclasses.field(default_factory=set)
    version: str | None = None
    cves: list[ExportCve] = dataclasses.field(default_factory=list)


class ExportSpdx3Checker(ExportChecker):
    def __init__(self, path: pathlib.Path) -> None:
        super().__init__()
        with path.open(encoding="utf-8"):
            self.objset = ObjectSet.parse_jsonld(path)
        self._read_spdx()

    @staticmethod
    def _read_cve(
        vuln: spdx30.security_Vulnerability,
        rels: set[spdx30.security_VulnAssessmentRelationship],
    ) -> ExportCve:
        def _cvss_score(metric: CvssMetric | None) -> float | None:
            if metric is None:
                return None
            return metric.score

        def _cvss_vector(metric: CvssMetric | None) -> str | None:
            if metric is None:
                return None
            return metric.vector_str

        cve_id = vuln_get_cve_id(vuln)
        assert cve_id

        vex_assess: CveVexAssessment | None = None
        cvss_metrics: dict[CvssVersion, CvssMetric] = {}
        for rel in rels:
            v = cve_vex_assessment_from_vuln_relationship(rel)
            if v is not None:
                assert vex_assess is None
                vex_assess = v
                continue

            m = cvss_metric_from_vuln_relationship(rel)
            if m is not None:
                assert m.cvss_ver not in cvss_metrics
                cvss_metrics[m.cvss_ver] = m

        assert vex_assess is not None

        notes: list[str | None] = []
        if isinstance(vex_assess, CveVexAffectedAssessment):
            notes.append(vex_assess.action_statement)
        elif isinstance(vex_assess, CveVexNotAffectedAssessment):
            notes.append(vex_assess.impact_statement)
        notes.append(vex_assess.status_notes)

        return ExportCve(
            cve_id=cve_id,
            status=vex_assess.status,
            notes=" ".join(n for n in notes if n),
            cvss_scor_20=_cvss_score(cvss_metrics.get(CvssVersion.V2_0)),
            cvss_vect_20=_cvss_vector(cvss_metrics.get(CvssVersion.V2_0)),
            cvss_scor_30=_cvss_score(cvss_metrics.get(CvssVersion.V3_0)),
            cvss_vect_30=_cvss_vector(cvss_metrics.get(CvssVersion.V3_0)),
            cvss_scor_31=_cvss_score(cvss_metrics.get(CvssVersion.V3_1)),
            cvss_vect_31=_cvss_vector(cvss_metrics.get(CvssVersion.V3_1)),
            cvss_scor_40=_cvss_score(cvss_metrics.get(CvssVersion.V4_0)),
            cvss_vect_40=_cvss_vector(cvss_metrics.get(CvssVersion.V4_0)),
        )

    def _read_package(
        self,
        comp_info_builder: _CompInfoBuilder,
        pkg: spdx30.software_Package,
    ) -> None:
        for cpe in self.objset.list_cpe23(pkg):
            assert isinstance(cpe.version, str)
            comp_id = CompId.build_from_cpe(cpe)
            assert comp_id
            comp_info_builder.ids.add(comp_id)
            if comp_info_builder.version is None:
                comp_info_builder.version = cpe.version
            else:
                assert comp_info_builder.version == cpe.version

        for vuln, rels in self.objset.get_package_vulns(pkg).items():
            comp_info_builder.cves.append(self._read_cve(vuln, rels))

    def _read_spdx(self) -> None:
        for com_build in self.objset.iterate_builds():
            comp_info_builder = _CompInfoBuilder()
            pkgs = self.objset.get_build_recipe_packages(com_build)
            if not pkgs:
                continue
            for pkg in pkgs:
                self._read_package(comp_info_builder, pkg)

            assert comp_info_builder.version
            self._builds.append(
                ExportBuild(
                    build_name=com_build.name.split(":", 1)[0],
                    vers_ids=CompVersIds(
                        ids=comp_info_builder.ids, version=comp_info_builder.version
                    ),
                    cves=comp_info_builder.cves,
                )
            )

    def check_cve(self, exported: ExportCve, expected: ExportCve) -> None:
        assert exported.cve_id == expected.cve_id
        assert exported.status == expected.status
        assert expected.notes in exported.notes

        assert exported.cvss_scor_20 == expected.cvss_scor_20
        assert exported.cvss_scor_30 == expected.cvss_scor_30
        assert exported.cvss_scor_31 == expected.cvss_scor_31
        assert exported.cvss_scor_40 == expected.cvss_scor_40

        assert exported.cvss_vect_20 == expected.cvss_vect_20
        assert exported.cvss_vect_30 == expected.cvss_vect_30
        assert exported.cvss_vect_31 == expected.cvss_vect_31
        assert exported.cvss_vect_40 == expected.cvss_vect_40
