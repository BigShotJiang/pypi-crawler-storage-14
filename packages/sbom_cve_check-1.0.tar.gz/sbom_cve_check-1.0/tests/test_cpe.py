import dataclasses
import operator

import pytest

from sbom_cve_check.vuln.cpe import Cpe23, LogicalValue, parse_cpe_match
from sbom_cve_check.vuln.version import SemVerRange


@dataclasses.dataclass(frozen=True)
class _Cpe:
    encoded: str
    fields: tuple[str | LogicalValue, ...]


_ANY = LogicalValue.ANY
_NA = LogicalValue.NA

cpes_ok_test_data: list[_Cpe] = [
    _Cpe(
        "cpe:2.3:a:curl:libcurl:7.10.4:*:*:*:*:*:*:*",
        ("a", "curl", "libcurl", "7.10.4", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY),
    ),
    _Cpe(
        "cpe:2.3:a:ntp:ntp:4.2.8:p3:*:*:*:*:*:*",
        ("a", "ntp", "ntp", "4.2.8", "p3", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY),
    ),
    _Cpe(
        "cpe:2.3:*:abc:def:1.23\\+git:*:*:*:*:*:*:*",
        (_ANY, "abc", "def", "1.23+git", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY),
    ),
    _Cpe(
        "cpe:2.3:-:*:-:*:-:*:-:*:-:*:-",
        (_NA, _ANY, _NA, _ANY, _NA, _ANY, _NA, _ANY, _NA, _ANY, _NA),
    ),
    _Cpe(
        "cpe:2.3:*:-:*:-:*:-:*:-:*:-:*",
        (_ANY, _NA, _ANY, _NA, _ANY, _NA, _ANY, _NA, _ANY, _NA, _ANY),
    ),
    _Cpe(
        "cpe:2.3:a:vend:prod:1.4:upd-4:pro:en:swe:tsw:pc:oth",
        ("a", "vend", "prod", "1.4", "upd-4", "pro", "en", "swe", "tsw", "pc", "oth"),
    ),
]


@pytest.mark.parametrize("test_data", cpes_ok_test_data)
def test_cpe_encode_decode(test_data: _Cpe) -> None:
    cpe = Cpe23.parse(test_data.encoded)
    assert cpe is not None
    assert cpe.part == test_data.fields[0]
    assert cpe.vendor == test_data.fields[1]
    assert cpe.product == test_data.fields[2]
    assert cpe.version == test_data.fields[3]
    assert cpe.update == test_data.fields[4]
    assert cpe.edition == test_data.fields[5]
    assert cpe.language == test_data.fields[6]
    assert cpe.sw_edition == test_data.fields[7]
    assert cpe.target_sw == test_data.fields[8]
    assert cpe.target_hw == test_data.fields[9]
    assert cpe.other == test_data.fields[10]

    assert str(cpe) == test_data.encoded
    assert repr(cpe) == f'"{test_data.encoded}"'


cpes_ko_test_data: list[str | None] = [
    None,
    "a:curl:curl:7.10.4:*:*:*:*:*:*:*",
    "cpe:2.3:a:curl:curl:7.10.4:*:*:*:*:*:*",
    "cpe:2.3:a:abc:d\\ef:1.2.3:*:*:*:*:*:*:*",
]


@pytest.mark.parametrize("test_data", cpes_ko_test_data)
def test_cpe_invalid(test_data: str) -> None:
    cpe = Cpe23.parse(test_data)
    assert cpe is None


@dataclasses.dataclass(frozen=True)
class _CpeMatch:
    json_obj: dict[str, str | bool]
    cpe: Cpe23 | None
    v_range: SemVerRange | None
    cna: str | None


cpe_match_test_data: list[_CpeMatch] = [
    _CpeMatch(
        {
            "vulnerable": True,
            "criteria": "cpe:2.3:o:linux:linux_kernel:*:*:*:*:*:*:*:*",
            "versionStartIncluding": "6.12",
            "versionEndExcluding": "6.12.23",
        },
        Cpe23(
            "o", "linux", "linux_kernel", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY
        ),
        SemVerRange(
            vulnerable=True,
            from_cpe=True,
            from_cna="416baaa9-dc9f-4396-8d5f-8c081fb06d67",
            v_start="6.12",
            op_start=operator.ge,
            v_end="6.12.23",
            op_end=operator.lt,
        ),
        "416baaa9-dc9f-4396-8d5f-8c081fb06d67",
    ),
    _CpeMatch(
        {
            "vulnerable": False,
            "criteria": "cpe:2.3:o:linux:linux_kernel:*:*:*:*:*:*:*:*",
            "versionStartIncluding": "5.0.4",
        },
        Cpe23(
            "o", "linux", "linux_kernel", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY
        ),
        SemVerRange(
            vulnerable=False,
            from_cpe=True,
            from_cna="1234-xyz",
            v_start="5.0.4",
            op_start=operator.ge,
            v_end=None,
            op_end=None,
        ),
        "1234-xyz",
    ),
    _CpeMatch(
        {
            "vulnerable": True,
            "criteria": "cpe:2.3:a:ntp:ntp:4.2.8:p3:*:*:*:*:*:*",
        },
        Cpe23("a", "ntp", "ntp", "4.2.8", "p3", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY),
        SemVerRange(
            vulnerable=True,
            from_cpe=True,
            from_cna=None,
            v_start="4.2.8-p3",
            op_start=operator.eq,
            v_end=None,
            op_end=None,
        ),
        None,
    ),
    _CpeMatch(
        {
            "vulnerable": True,
            "criteria": "cpe:2.3:*:abc:def:1.2.3:*:*:*:*:*:*:*",
            "versionStartExcluding": "1.2.2",
            "versionEndIncluding": "1.4",
        },
        Cpe23(_ANY, "abc", "def", "1.2.3", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY),
        SemVerRange(
            vulnerable=True,
            from_cpe=True,
            from_cna=None,
            v_start="1.2.2",
            op_start=operator.gt,
            v_end="1.4",
            op_end=operator.le,
        ),
        None,
    ),
    _CpeMatch(
        {
            "vulnerable": True,
            "criteria": "cpe:2.3:*:abc:-:1.2.3:*:*:*:*:*:*:*",
            "versionStartExcluding": "1.2.2",
            "versionEndIncluding": "1.4",
        },
        None,
        None,
        None,
    ),
    _CpeMatch(
        {
            "vulnerable": True,
            "criteria": "cpe:2.3:*:abc:def:*:*:*:*:*:*:*:*",
        },
        Cpe23(_ANY, "abc", "def", _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY, _ANY),
        None,
        None,
    ),
]


@pytest.mark.parametrize("test_data", cpe_match_test_data)
def test_cpe_match(test_data: _CpeMatch) -> None:
    cpe, v_range = parse_cpe_match(test_data.json_obj, test_data.cna)
    assert cpe == test_data.cpe
    assert v_range == test_data.v_range
