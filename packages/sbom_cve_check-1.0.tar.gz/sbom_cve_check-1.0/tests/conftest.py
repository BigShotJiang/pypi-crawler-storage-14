import os
import pathlib
import tempfile
from collections.abc import Generator
from typing import Any

import pytest
from _pytest.config import Config, Parser  # type: ignore[attr-defined]
from _pytest.nodes import Item


def pytest_addoption(parser: Parser) -> None:
    parser.addoption("--run-slow", action="store_true", help="run slow tests")


def pytest_configure(config: Config) -> None:
    config.addinivalue_line("markers", "slow: mark test as slow to run")


def pytest_collection_modifyitems(config: Config, items: list[Item]) -> None:
    if config.getoption("--run-slow"):
        return
    skip_slow = pytest.mark.skip("need --run-slow option to run this test")
    for item in items:
        if "slow" in item.keywords:
            item.add_marker(skip_slow)


@pytest.fixture(scope="function")
def tmp_dir() -> Generator[pathlib.Path, None, None]:
    extra_opts: dict[str, Any] = {}
    if os.environ.get("SBOM_CVE_CHECK_TEST_KEEP_TMP") == "1":
        # The delete parameter was added in Python 3.12
        extra_opts["delete"] = False

    with tempfile.TemporaryDirectory(prefix="sbom-cve-check-", **extra_opts) as d:
        yield pathlib.Path(d)
