import dataclasses
import operator

import pytest

from sbom_cve_check.vuln.version import SemVerRange, Version, VersRangeStatus


@dataclasses.dataclass
class CmpVers:
    vers_a: str
    vers_b: str


# First element is greater than the second one
check_greater = [
    CmpVers("1.1", "1.0"),
    CmpVers("1.1", "1.0.2"),
    CmpVers("1.0.1", "1.0"),
    CmpVers("1.0", "0"),
    CmpVers("1.2", "1.1.*"),
    CmpVers("3.6.1", "3.5.12"),
    CmpVers("4.0", "3.5.12"),
    CmpVers("3.5.1", "3.5"),
    CmpVers("2.0", "1.*"),
    CmpVers("2.0", "1.0"),
    CmpVers("1.0.2", "1.0"),
    CmpVers("1.1", "1.0.2"),
    CmpVers("1.0.2", "1.0.2-dev"),
    CmpVers("1.1.1.1", "0"),
    # alphabetical
    CmpVers("1.0.2b", "1.0.2a"),
    CmpVers("1.0.2a", "1.0.2a-dev"),
    CmpVers("1.1.1.1", "1.1.1"),
    CmpVers("1.1.1.1", "1.1.1f"),
    # revision
    CmpVers("r123", "r122"),
    CmpVers("0.1.0", "r123"),
    # pre-release
    CmpVers("0.1.0-alpha1", "0.1.0-alpha"),
    CmpVers("0.1.0-alpha1", "0.1.0-alpha0"),
    CmpVers("0.1.0-beta", "0.1.0-alpha2"),
    CmpVers("0.1.0-pre", "0.1.0-beta"),
]

# First element is lesser than the second one
check_lesser = [
    CmpVers("1.0", "2.*"),
    CmpVers("1.0", "2.0"),
    CmpVers("1.0", "1.0.2"),
    CmpVers("1.0", "1.0.*"),
    CmpVers("1.0", "1.*"),
    CmpVers("1.0", "*"),
    CmpVers("1.0.2", "1.1"),
    CmpVers("1.3.2", "2.0"),
    CmpVers("0", "2.0"),
    CmpVers("1.0", "1.1"),
    CmpVers("1.0", "1.0.1"),
    CmpVers("1.0", "2.*"),
    CmpVers("3.5.12", "3.6.1"),
    CmpVers("3.5", "3.5.1"),
    CmpVers("0", "1.0.0"),
    CmpVers("1.1.1", "1.1.1.1"),
    CmpVers("0", "1.1.1"),
    CmpVers("0", "1.1.1.1"),
    CmpVers("1.0.2-dev", "1.0.2"),
    # alphabetical
    CmpVers("1.0.2a", "1.0.2b"),
    CmpVers("1.0.2a", "1.1.1"),
    CmpVers("1.0.2a-dev", "1.0.2a"),
    CmpVers("1.1.1f", "1.1.1.1"),
    # pre-release
    CmpVers("1.0.2-a1", "1.0.2"),
    CmpVers("1.0.2-a0", "1.0.2a"),
    CmpVers("1.0.2-a1", "1.0.2a"),
    CmpVers("1.0.2-a1", "1.0.2a-1"),
]

# Both elements are equal
check_equal = [
    CmpVers("1.0", "1.0"),
    CmpVers("1.0", "1.0.0"),
    CmpVers("1.1", "1.1.0"),
    CmpVers("1", "1.0.0"),
    CmpVers("0", "0.0.0"),
    CmpVers("1.1", "1.1.0"),
    # alphabetical
    CmpVers("1.0.2a", "1.0.2a"),
    # pre-release
    CmpVers("1.0.2-a0", "1.0.2-alpha"),
]


def _parse_versions(check: CmpVers) -> tuple[Version, Version]:
    a = Version(check.vers_a)
    b = Version(check.vers_b)
    assert a.is_valid(), a
    assert b.is_valid(), b
    return a, b


def test_version_greater() -> None:
    for check in check_greater:
        a, b = _parse_versions(check)
        assert a > b, (a, a._cmp_keys, b, b._cmp_keys)


def test_version_lesser() -> None:
    for check in check_lesser:
        a, b = _parse_versions(check)
        assert a < b, (a, a._cmp_keys, b, b._cmp_keys)


def test_version_equal() -> None:
    for check in check_equal:
        a, b = _parse_versions(check)
        assert a == b, (a, a._cmp_keys, b, b._cmp_keys)


@dataclasses.dataclass
class _SemVersRange:
    range: SemVerRange
    vers: Version
    status: VersRangeStatus


sem_vers_range_test_data: list[_SemVersRange] = [
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end="1.2.4",
            op_end=operator.lt,
        ),
        Version("1.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end="1.2.4",
            op_end=operator.lt,
        ),
        Version("1.2.2"),
        VersRangeStatus.SMALLER,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.gt,
            v_end="1.2.4",
            op_end=operator.lt,
        ),
        Version("1.2.3"),
        VersRangeStatus.SMALLER,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end="1.2.4",
            op_end=operator.lt,
        ),
        Version("1.2.4"),
        VersRangeStatus.GREATER,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end="1.2.4",
            op_end=operator.le,
        ),
        Version("1.2.4"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end="1.2.4",
            op_end=operator.le,
        ),
        Version("1.2.5"),
        VersRangeStatus.GREATER,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end=None,
            op_end=None,
        ),
        Version("1.2.2"),
        VersRangeStatus.SMALLER,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end=None,
            op_end=None,
        ),
        Version("1.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end=None,
            op_end=None,
        ),
        Version("2.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="1.2.3",
            op_start=operator.ge,
            v_end="foo-2.0",
            op_end=operator.lt,
        ),
        Version("2.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="foo-1.0",
            op_start=operator.ge,
            v_end="2.0",
            op_end=operator.lt,
        ),
        Version("1.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start="foo-1.0",
            op_start=operator.ge,
            v_end="foo-2.0",
            op_end=operator.lt,
        ),
        Version("1.2.3"),
        VersRangeStatus.NO_INFO,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start=None,
            op_start=None,
            v_end="1.2.4",
            op_end=operator.le,
        ),
        Version("1.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start=None,
            op_start=None,
            v_end="1.2.4",
            op_end=operator.le,
        ),
        Version("1.2.4"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange(
            vulnerable=True,
            v_start=None,
            op_start=None,
            v_end="1.2.4",
            op_end=operator.le,
        ),
        Version("1.2.5"),
        VersRangeStatus.GREATER,
    ),
    _SemVersRange(
        SemVerRange.build_single_vers(True, "1.2.3", True),
        Version("1.2.4"),
        VersRangeStatus.GREATER,
    ),
    _SemVersRange(
        SemVerRange.build_single_vers(True, "1.2.3", True),
        Version("1.2.2"),
        VersRangeStatus.SMALLER,
    ),
    _SemVersRange(
        SemVerRange.build_single_vers(True, "1.2.3", True),
        Version("1.2.3"),
        VersRangeStatus.IN_RANGE,
    ),
    _SemVersRange(
        SemVerRange.build_single_vers(True, "foo-1.0", True),
        Version("1.2.3"),
        VersRangeStatus.NO_INFO,
    ),
    _SemVersRange(
        SemVerRange.build_single_vers(True, "1.2.3", True),
        Version("foo-1.0"),
        VersRangeStatus.NO_INFO,
    ),
]


@pytest.mark.parametrize("test_data", sem_vers_range_test_data)
def test_sem_vers_check_in_range(test_data: _SemVersRange) -> None:
    s = test_data.range.check_in_range(test_data.vers)
    assert s == test_data.status
