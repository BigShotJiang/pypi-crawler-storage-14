import json
import pathlib

from checker.export_checker import ExportBuild, ExportCve
from checker.runner import generate_and_check_exports
from checker.sbom_spdx3 import Spdx3SbomBuilder, SwPackage

from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.vuln.cve import CveVexStatus


def test_without_annot(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("busybox")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="busybox",
                cpes=["cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*"],
                pkg_version="1.37.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    exp_build = ExportBuild(
        build_name="busybox",
        vers_ids=CompVersIds(ids=[CompId(name="busybox")], version="1.37.0"),
        cves=[
            ExportCve(
                cve_id="CVE-2023-42366",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_31=5.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:N/UI:R/S:U/C:N/I:N/A:H",
            ),
            ExportCve(
                cve_id="CVE-2024-58251",
                status=CveVexStatus.AFFECTED,
                notes="version-in-range",
                cvss_scor_31=2.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:H/PR:N/UI:R/S:U/C:N/I:N/A:L",
            ),
            ExportCve(
                cve_id="CVE-2025-46394",
                status=CveVexStatus.AFFECTED,
                notes="version-in-range",
                cvss_scor_31=3.3,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:L/A:N",
            ),
        ],
        unexpected_cves=[],
    )

    generate_and_check_exports(
        tmp_dir, ["--sbom-path", str(sbom_path)], [exp_build], True
    )


def test_simple_annotations(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("busybox")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="busybox",
                cpes=["cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*"],
                pkg_version="1.37.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    annot_db_path = tmp_dir.joinpath("annot-db")
    annot_db_path.mkdir()

    with annot_db_path.joinpath("CVE-2023-42366.yaml").open("w", encoding="utf-8") as f:
        f.write(
            "vulnerable: true\n"
            "last-review: '2025-01-01'\n"
            "cve-product: busybox\n"
            "versions: [1.37.0]\n"
            "comment: 'test1-is-vuln'\n"
        )

    with annot_db_path.joinpath("CVE-2024-58251.yaml").open("w", encoding="utf-8") as f:
        f.write(
            "vulnerable: 'no'\n"
            "last-review: '2025-01-01'\n"
            "cve-product: busybox\n"
            "versions: [1.37.0]\n"
            "comment: 'test2-is-not-vuln'\n"
        )

    with annot_db_path.joinpath("CVE-2025-46394.yaml").open("w", encoding="utf-8") as f:
        f.write(
            "vulnerable: false\n"
            "last-review: '2025-01-01'\n"
            "cve-product: busybox\n"
            "versions: [1.37.0]\n"
            "comment: 'test3-is-not-vuln'\n"
        )

    exp_build = ExportBuild(
        build_name="busybox",
        vers_ids=CompVersIds(ids=[CompId(name="busybox")], version="1.37.0"),
        cves=[
            ExportCve(
                cve_id="CVE-2023-42366",
                status=CveVexStatus.AFFECTED,
                notes="test1-is-vuln",
                cvss_scor_31=5.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:N/UI:R/S:U/C:N/I:N/A:H",
            ),
            ExportCve(
                cve_id="CVE-2024-58251",
                status=CveVexStatus.NOT_AFFECTED,
                notes="test2-is-not-vuln",
                cvss_scor_31=2.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:H/PR:N/UI:R/S:U/C:N/I:N/A:L",
            ),
            ExportCve(
                cve_id="CVE-2025-46394",
                status=CveVexStatus.NOT_AFFECTED,
                notes="test3-is-not-vuln",
                cvss_scor_31=3.3,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:L/A:N",
            ),
        ],
        unexpected_cves=[],
    )

    generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            sbom_path.as_posix(),
            "--add-db",
            "simple-annotations",
            annot_db_path.as_posix(),
            "globs=.",
        ],
        [exp_build],
        True,
    )


def test_openvex_annotations(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("busybox")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="busybox",
                cpes=["cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*"],
                pkg_version="1.37.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    annot_db_path = tmp_dir.joinpath("annot-db")
    annot_db_path.mkdir()

    openvex_json = {
        "@context": "https://openvex.dev/ns/v0.2.0",
        "@id": "https://openvex.dev/docs/example/vex-9fb3463de1b57",
        "author": "Tester",
        "timestamp": "2023-01-08T18:02:03.647787998-06:00",
        "version": 1,
        "statements": [
            {
                "vulnerability": {"name": "CVE-2023-42366"},
                "products": [
                    {
                        "identifiers": {
                            "cpe23": "cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*",
                        },
                    }
                ],
                "status_notes": "test1-is-vuln",
                "status": "affected",
            },
            {
                "vulnerability": {"name": "CVE-2024-58251"},
                "products": [
                    {
                        "identifiers": {
                            "cpe23": "cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*",
                        },
                    }
                ],
                "status_notes": "test2-is-not-vuln",
                "status": "not_affected",
                "justification": "component_not_present",
                "impact_statement": "Component not compiled by config",
            },
            {
                "vulnerability": {"name": "CVE-2025-46394"},
                "products": [
                    {
                        "identifiers": {
                            "cpe23": "cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*",
                        },
                    }
                ],
                "status_notes": "test3-is-not-vuln",
                "status": "not_affected",
                "justification": "vulnerable_code_not_in_execute_path",
                "impact_statement": "Component cannot be executed",
            },
        ],
    }

    with annot_db_path.joinpath("vex.json").open("w", encoding="utf-8") as f:
        json.dump(openvex_json, f)

    exp_build = ExportBuild(
        build_name="busybox",
        vers_ids=CompVersIds(ids=[CompId(name="busybox")], version="1.37.0"),
        cves=[
            ExportCve(
                cve_id="CVE-2023-42366",
                status=CveVexStatus.AFFECTED,
                notes="test1-is-vuln",
                cvss_scor_31=5.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:N/UI:R/S:U/C:N/I:N/A:H",
            ),
            ExportCve(
                cve_id="CVE-2024-58251",
                status=CveVexStatus.NOT_AFFECTED,
                notes="test2-is-not-vuln",
                cvss_scor_31=2.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:H/PR:N/UI:R/S:U/C:N/I:N/A:L",
            ),
            ExportCve(
                cve_id="CVE-2025-46394",
                status=CveVexStatus.NOT_AFFECTED,
                notes="test3-is-not-vuln",
                cvss_scor_31=3.3,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:L/A:N",
            ),
        ],
        unexpected_cves=[],
    )

    generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            sbom_path.as_posix(),
            "--add-db",
            "openvex-file",
            annot_db_path.joinpath("vex.json").as_posix(),
        ],
        [exp_build],
        True,
    )


def test_yocto_annotations(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("busybox")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="busybox",
                cpes=["cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*"],
                pkg_version="1.37.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    annot_db_path = tmp_dir.joinpath("annot-db")
    annot_db_path.mkdir()

    cvss_40_vector = "CVSS:4.0/AV:N/AC:L/AT:N/PR:L/UI:N/VC:H/VI:N/VA:N/SC:N/SI:N/SA:N"

    obj_json = {
        "version": 1,
        "package": [
            {
                "name": "busybox",
                "layer": "",
                "version": "1.37.0",
                "products": [{"product": "busybox", "cvesInRecord": "Yes"}],
                "issue": [
                    {
                        "id": "CVE-2023-42366",
                        "status": "Unpatched",
                        "scorev2": "4.3",
                        "scorev3": "5.5",
                        "scorev4": "7.1",
                        "vectorString": cvss_40_vector,
                        "detail": "unpatched",
                    },
                    {
                        "id": "CVE-2024-58251",
                        "status": "Ignored",
                        "detail": "not-applicable-config",
                    },
                    {
                        "id": "CVE-2025-46394",
                        "status": "Patched",
                        "detail": "fix-file-included",
                    },
                ],
                "cpes": ["cpe:2.3:*:*:busybox:1.37.0:*:*:*:*:*:*:*"],
            }
        ],
    }

    with annot_db_path.joinpath("vex.json").open("w", encoding="utf-8") as f:
        json.dump(obj_json, f)

    exp_build = ExportBuild(
        build_name="busybox",
        vers_ids=CompVersIds(ids=[CompId(name="busybox")], version="1.37.0"),
        cves=[
            ExportCve(
                cve_id="CVE-2023-42366",
                status=CveVexStatus.AFFECTED,
                notes="unpatched",
                cvss_scor_31=5.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:N/UI:R/S:U/C:N/I:N/A:H",
                cvss_scor_40=7.1,
                cvss_vect_40=cvss_40_vector,
            ),
            ExportCve(
                cve_id="CVE-2024-58251",
                status=CveVexStatus.NOT_AFFECTED,
                notes="not-applicable-config",
                cvss_scor_31=2.5,
                cvss_vect_31="CVSS:3.1/AV:L/AC:H/PR:N/UI:R/S:U/C:N/I:N/A:L",
            ),
            ExportCve(
                cve_id="CVE-2025-46394",
                status=CveVexStatus.FIXED,
                notes="fix-file-included",
                cvss_scor_31=3.3,
                cvss_vect_31="CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:L/A:N",
            ),
        ],
        unexpected_cves=[],
    )

    generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            sbom_path.as_posix(),
            "--add-db",
            "yocto-vex-manifest",
            annot_db_path.joinpath("vex.json").as_posix(),
        ],
        [exp_build],
        True,
    )
