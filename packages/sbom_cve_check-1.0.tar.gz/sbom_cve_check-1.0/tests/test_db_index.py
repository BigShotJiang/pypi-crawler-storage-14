import json
import pathlib

import pytest
from checker.runner import generate_and_check_exports
from checker.sbom_spdx3 import Spdx3SbomBuilder, SwPackage


def index_file_stats(index_obj: dict[str, list[str]]) -> tuple[int, int, int]:
    nb_names = 0
    nb_cves = 0
    uniq_cves: set[str] = set()
    for cves in index_obj.values():
        nb_names += 1
        nb_cves += len(cves)
        uniq_cves.update(cves)
    return nb_names, nb_cves, len(uniq_cves)


@pytest.mark.slow
@pytest.mark.parametrize("with_rejected", [False, True])
def test_database_index(tmp_dir: pathlib.Path, with_rejected: bool) -> None:
    conf_path = tmp_dir.joinpath("db-conf-test-index.toml")
    path_idx_nvd = tmp_dir.joinpath("tst-index-nvd-fkie.json")
    path_idx_list = tmp_dir.joinpath("tst-index-cvelist.json")
    with conf_path.open("w", encoding="utf-8") as f:
        f.write("[databases.nvd-fkie]\n")
        f.write(f'cache_index_path = "{path_idx_nvd}"\n')
        f.write("[databases.cvelist]\n")
        f.write(f'cache_index_path = "{path_idx_list}"\n')

    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("curl")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="curl",
                cpes=["cpe:2.3:a:curl:curl:8.17.0:*:*:*:*:*:*:*"],
                pkg_version="8.17.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    args = ["--config", str(conf_path), "--sbom-path", str(sbom_path)]
    if with_rejected:
        args.append("--export-list-rejected-cve")

    generate_and_check_exports(tmp_dir, args, [], False)

    with path_idx_list.open(encoding="utf-8") as f:
        index = json.load(f)
    assert index["commit"] == "9263572f02b49451c36a77c1ddc3cdc4e610aca8"
    nb_names, nb_cves, nb_uniq_cves = index_file_stats(index["index"])
    assert nb_names == 24369
    assert nb_cves == 140711
    assert nb_uniq_cves == 50290

    with path_idx_nvd.open(encoding="utf-8") as f:
        index = json.load(f)
    assert index["commit"] == "3a9392001a68254bcf11be0fee0cb05d320c520d"
    nb_names, nb_cves, nb_uniq_cves = index_file_stats(index["index"])
    assert nb_names == 109103
    assert nb_cves == 834737
    assert nb_uniq_cves == 274475
