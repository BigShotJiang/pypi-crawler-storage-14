import dataclasses
from enum import Enum

import pytest

from sbom_cve_check.vuln.cvss import (
    Cvss2AccessVector,
    Cvss3AttackVector,
    Cvss4AttackVector,
    CvssMetric,
    CvssSeverity,
    CvssVersion,
)


@dataclasses.dataclass(frozen=True)
class _CvssMetric:
    vector: str
    vers: CvssVersion
    score: float
    severity: CvssSeverity | None
    json_obj: dict[str, str | float | int]
    metrics: dict[str, Enum]


cvss_valid_test_data: list[_CvssMetric] = [
    _CvssMetric(
        "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H",
        CvssVersion.V3_1,
        6.5,
        CvssSeverity.MEDIUM,
        {
            "baseScore": 6.5,
            "baseSeverity": "MEDIUM",
            "version": "3.1",
        },
        {"AV": Cvss3AttackVector.NETWORK},
    ),
    _CvssMetric(
        "CVSS:4.0/AV:N/AC:L/AT:N/PR:L/UI:N/VC:H/VI:N/VA:N/SC:N/SI:N/SA:N",
        CvssVersion.V4_0,
        7.1,
        CvssSeverity.HIGH,
        {
            "baseScore": 7.1,
            "baseSeverity": "HIGH",
            "version": "4.0",
        },
        {"AV": Cvss4AttackVector.NETWORK},
    ),
    _CvssMetric(
        "AV:N/AC:H/Au:N/C:C/I:P/A:N",
        CvssVersion.V2_0,
        6.1,
        None,
        {"baseScore": 6.1, "version": "2.0"},
        {"AV": Cvss2AccessVector.NETWORK},
    ),
    _CvssMetric(
        "AV:N/AC:L/Au:S/C:N/I:P/A:N",
        CvssVersion.V2_0,
        4.0,
        None,
        {"baseScore": 4, "version": "2.0"},
        {"AV": Cvss2AccessVector.NETWORK},
    ),
    _CvssMetric(
        "CVSS:3.0/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:N/A:N",
        CvssVersion.V3_0,
        3.3,
        CvssSeverity.LOW,
        {
            "baseScore": 3.3,
            "baseSeverity": "LOW",
            "version": "3.0",
        },
        {"AV": Cvss3AttackVector.LOCAL},
    ),
]


@pytest.mark.parametrize("test_data", cvss_valid_test_data)
def test_valid_cvss_metric(test_data: _CvssMetric) -> None:
    t = test_data
    json_obj = test_data.json_obj.copy()
    json_obj["vectorString"] = t.vector
    cvss_parsed = CvssMetric.parse_cve_db_metric(json_obj)
    cvss_ref = CvssMetric(t.vers, t.score, t.vector, t.severity)
    assert cvss_parsed == cvss_ref
    assert str(cvss_parsed.score) == str(cvss_ref.score)
    assert cvss_parsed.decode_vector() == t.metrics


cvss_invalid_test_data: list[dict[str, str | float | int] | None] = [
    None,
    {
        "baseScore": 6.5,
        "vectorString": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H",
        "baseSeverity": "FOO",
        "version": "3.1",
    },
    {
        "baseScore": 6.5,
        "vectorString": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H",
        "version": "3.1",
    },
    {
        "baseScore": 6.5,
        "vectorString": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H",
        "baseSeverity": "MEDIUM",
        "version": "2.1",
    },
    {
        "vectorString": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H",
        "baseSeverity": "MEDIUM",
        "version": "3.1",
    },
]


@pytest.mark.parametrize("test_data", cvss_invalid_test_data)
def test_invalid_cvss_metric(test_data: dict[str, str | float | int]) -> None:
    cvss_parsed = CvssMetric.parse_cve_db_metric(test_data)
    assert cvss_parsed is None
