import json
import pathlib

import pytest
from checker.export_checker import ExportBuild, ExportCve
from checker.export_spdx3 import ExportSpdx3Checker
from checker.runner import generate_and_check_exports
from checker.sbom_spdx3 import Spdx3SbomBuilder, SwPackage

from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.utils import parsing
from sbom_cve_check.vuln.cve import (
    CveId,
    CveInfo,
    CveVexAffectedAssessment,
    CveVexJustification,
    CveVexNotAffectedAssessment,
    CveVexStatus,
)
from sbom_cve_check.vuln.cvss import CvssMetric, CvssSeverity, CvssVersion


def test_spdx3_update_01(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("curl")
    pkg = sbom.add_packages(
        build,
        [
            SwPackage(
                name="curl",
                cpes=["cpe:2.3:a:curl:curl:8.10.0:*:*:*:*:*:*:*"],
                pkg_version="8.10.0",
            )
        ],
    )[0]

    cvss4_vect = "CVSS:4.0/AV:L/AC:H/AT:P/PR:L/UI:A/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N"
    cvss3_vect = "CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:C/C:N/I:H/A:N"
    cve_info = CveInfo(
        cve_id=CveId("CVE-2024-9681"),
        cvss_metrics=[
            CvssMetric(
                CvssVersion.V3_1,
                6.1,
                cvss3_vect,
                CvssSeverity.MEDIUM,
            ),
            CvssMetric(
                CvssVersion.V4_0,
                5.4,
                cvss4_vect,
                CvssSeverity.MEDIUM,
            ),
        ],
        vex_assessment=CveVexNotAffectedAssessment(
            impact_statement="My statement",
            justification=CveVexJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH,
        ),
    )
    sbom.objset.add_cve_vulnerability(pkg, cve_info)

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    annot_db_path = tmp_dir.joinpath("annot-db")
    annot_db_path.mkdir()

    openvex_json = {
        "@context": "https://openvex.dev/ns/v0.2.0",
        "@id": "https://openvex.dev/docs/example/vex-9fb3463de1b57",
        "author": "Tester",
        "timestamp": "2023-01-08T18:02:03.647787998-06:00",
        "version": 1,
        "statements": [
            {
                "vulnerability": {"name": "CVE-2024-9681"},
                "products": [
                    {
                        "identifiers": {
                            "cpe23": "cpe:2.3:a:curl:curl:8.10.0:*:*:*:*:*:*:*",
                        },
                    }
                ],
                "status_notes": "is-not-vuln",
                "status": "fixed",
            },
        ],
    }

    annot_db_path = annot_db_path.joinpath("vex.json")
    with annot_db_path.open("w", encoding="utf-8") as f:
        json.dump(openvex_json, f)

    exp_build = ExportBuild(
        build_name="curl",
        vers_ids=CompVersIds(
            ids=[CompId(part="a", vendor="curl", name="curl")], version="8.10.0"
        ),
        cves=[
            ExportCve(
                cve_id="CVE-2024-9681",
                status=CveVexStatus.FIXED,
                notes="is-not-vuln",
                cvss_scor_31=6.5,
                cvss_vect_31="CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:H/A:L",
            ),
        ],
        unexpected_cves=[],
    )

    exports = generate_and_check_exports(
        tmp_dir,
        [
            "--sbom-path",
            str(sbom_path),
            "--ignore-sbom-annotations",
            "--add-db",
            "openvex-file",
            annot_db_path.as_posix(),
        ],
        [exp_build],
        True,
    )

    assert isinstance(exports["spdx3"], ExportSpdx3Checker)
    objset = exports["spdx3"].objset
    pkg = next(objset.find_package_by_name("curl"))
    vuln, _rels = objset.get_package_vuln(pkg, "CVE-2024-9681")
    assert vuln is not None
    desc: str = vuln.description
    assert desc.startswith("When curl is asked to use HSTS, the expiry time for a")
    assert len(vuln.externalRef) == 13
    assert vuln.security_publishedTime == parsing.datetime_from_iso_format(
        "2024-11-06T07:47:20Z"
    )
    assert vuln.security_modifiedTime == parsing.datetime_from_iso_format(
        "2025-11-03T21:18:48Z"
    )


@pytest.mark.parametrize("rm_rejected", [False, True])
def test_spdx3_rejected(tmp_dir: pathlib.Path, rm_rejected: bool) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("binutils")
    pkg = sbom.add_packages(
        build,
        [
            SwPackage(
                name="binutils",
                cpes=["cpe:2.3:a:gnu:binutils:2.35:*:*:*:*:*:*:*"],
                pkg_version="2.35",
            )
        ],
    )[0]

    cve_info = CveInfo(
        cve_id=CveId("CVE-2021-3487"),
        cvss_metrics=[
            CvssMetric(
                CvssVersion.V3_1,
                6.5,
                "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:N/A:H",
                CvssSeverity.MEDIUM,
            ),
        ],
        vex_assessment=CveVexAffectedAssessment(
            action_statement="is-vulnerable",
        ),
    )
    sbom.objset.add_cve_vulnerability(pkg, cve_info)

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    cve_exported = ExportCve(
        cve_id="CVE-2021-3487",
        status=CveVexStatus.NOT_AFFECTED,
        notes="cve-rejected",
        cvss_scor_31=6.5,
        cvss_vect_31="CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:N/A:H",
    )

    exp_build = ExportBuild(
        build_name="binutils",
        vers_ids=CompVersIds(
            ids=[CompId(part="a", vendor="gnu", name="binutils")], version="2.35"
        ),
        cves=[] if rm_rejected else [cve_exported],
        unexpected_cves=["CVE-2021-3487"] if rm_rejected else [],
    )

    args = ["--sbom-path", str(sbom_path)]
    if not rm_rejected:
        args.append("--export-list-rejected-cve")

    generate_and_check_exports(tmp_dir, args, [exp_build], True)
