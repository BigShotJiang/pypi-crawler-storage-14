import pathlib

from checker.export_checker import ExportBuild, ExportCve
from checker.runner import generate_and_check_exports
from checker.sbom_spdx3 import Spdx3SbomBuilder, SwPackage

from sbom_cve_check.sbom.component import CompId, CompVersIds
from sbom_cve_check.vuln.cve import (
    CveId,
    CveInfo,
    CveVexJustification,
    CveVexNotAffectedAssessment,
    CveVexStatus,
)
from sbom_cve_check.vuln.cvss import CvssMetric, CvssSeverity, CvssVersion


def test_analysis_01(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("curl")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="curl",
                cpes=["cpe:2.3:a:curl:curl:8.10.0:*:*:*:*:*:*:*"],
                pkg_version="8.10.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    exp_build = ExportBuild(
        build_name="curl",
        vers_ids=CompVersIds(
            ids=[CompId(part="a", vendor="curl", name="curl")], version="8.10.0"
        ),
        cves=[
            ExportCve(
                cve_id="CVE-2005-3185",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_20=7.5,
                cvss_vect_20="AV:N/AC:L/Au:N/C:P/I:P/A:P",
            ),
            ExportCve(
                cve_id="CVE-2009-0037",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_20=6.8,
                cvss_vect_20="AV:N/AC:M/Au:N/C:P/I:P/A:P",
            ),
            ExportCve(
                cve_id="CVE-2010-3842",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_20=5.8,
                cvss_vect_20="AV:N/AC:M/Au:N/C:N/I:P/A:P",
            ),
            ExportCve(
                cve_id="CVE-2012-0036",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_20=7.5,
                cvss_vect_20="AV:N/AC:L/Au:N/C:P/I:P/A:P",
            ),
            ExportCve(
                cve_id="CVE-2024-2398",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_31=8.6,
                cvss_vect_31="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:L",
            ),
            ExportCve(
                cve_id="CVE-2024-6197",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_31=7.5,
                cvss_vect_31="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H",
            ),
            ExportCve(
                cve_id="CVE-2024-8096",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_31=6.5,
                cvss_vect_31="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
            ),
            ExportCve(
                cve_id="CVE-2024-9681",
                status=CveVexStatus.AFFECTED,
                notes="version-in-range",
                cvss_scor_31=6.5,
                cvss_vect_31="CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:H/A:L",
            ),
        ],
    )

    generate_and_check_exports(
        tmp_dir, ["--sbom-path", str(sbom_path)], [exp_build], True
    )


def test_analysis_02(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("curl")
    sbom.add_packages(
        build,
        [
            SwPackage(
                name="curl",
                cpes=["cpe:2.3:a:curl:curl:8.11.0:*:*:*:*:*:*:*"],
                pkg_version="8.11.0",
            )
        ],
    )

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    exp_build = ExportBuild(
        build_name="curl",
        vers_ids=CompVersIds(
            ids=[CompId(part="a", vendor="curl", name="curl")], version="8.11.0"
        ),
        cves=[
            ExportCve(
                cve_id="CVE-2024-9681",
                status=CveVexStatus.FIXED,
                notes="version-not-in-range",
                cvss_scor_31=6.5,
                cvss_vect_31="CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:H/A:L",
            ),
        ],
        unexpected_cves=[],
    )

    generate_and_check_exports(
        tmp_dir, ["--sbom-path", str(sbom_path)], [exp_build], True
    )


def test_analysis_03(tmp_dir: pathlib.Path) -> None:
    sbom = Spdx3SbomBuilder()
    build = sbom.add_recipe("curl")
    pkg = sbom.add_packages(
        build,
        [
            SwPackage(
                name="curl",
                cpes=["cpe:2.3:a:curl:curl:8.10.0:*:*:*:*:*:*:*"],
                pkg_version="8.10.0",
            )
        ],
    )[0]

    cvss4_vect = "CVSS:4.0/AV:L/AC:H/AT:P/PR:L/UI:A/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N"
    cvss3_vect = "CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:C/C:N/I:H/A:N"
    cve_info = CveInfo(
        cve_id=CveId("CVE-2024-9681"),
        cvss_metrics=[
            CvssMetric(
                CvssVersion.V3_1,
                6.1,
                cvss3_vect,
                CvssSeverity.MEDIUM,
            ),
            CvssMetric(
                CvssVersion.V4_0,
                5.4,
                cvss4_vect,
                CvssSeverity.MEDIUM,
            ),
        ],
        vex_assessment=CveVexNotAffectedAssessment(
            impact_statement="My statement",
            justification=CveVexJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH,
        ),
    )
    sbom.objset.add_cve_vulnerability(pkg, cve_info)

    sbom_path = tmp_dir.joinpath("sbom.spdx.json")
    sbom.write_to_jsonld(sbom_path)

    exp_build = ExportBuild(
        build_name="curl",
        vers_ids=CompVersIds(
            ids=[CompId(part="a", vendor="curl", name="curl")], version="8.10.0"
        ),
        cves=[
            ExportCve(
                cve_id="CVE-2024-9681",
                status=CveVexStatus.NOT_AFFECTED,
                notes="My statement",
                cvss_scor_31=6.1,
                cvss_vect_31=cvss3_vect,
                cvss_scor_40=5.4,
                cvss_vect_40=cvss4_vect,
            ),
        ],
        unexpected_cves=[],
    )

    generate_and_check_exports(
        tmp_dir, ["--sbom-path", str(sbom_path)], [exp_build], True
    )
