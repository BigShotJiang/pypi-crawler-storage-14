# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import dataclasses
import logging
from enum import Enum
from typing import Any, Final, Literal, Optional

from .version import VersionRange, VersionRangeBuilder

_CPE23_ESCAPED_CHARS: Final = frozenset(
    [
        "\\", "!", '"', "#", "$", "%", "&", "'", "(", ")", "+", ",", "/", ":", ";",
        "<", "=", ">", "@", "[", "]", "^", "`", "{", "|", "}", "~", "?", "*",
    ]
)  # fmt: skip

_CPE23_ENCODE_TRANS_TABLE: Final = str.maketrans(
    {c: f"\\{c}" for c in _CPE23_ESCAPED_CHARS}
)

_CPE23_FIELD_NAMES: Final = [
    "part",
    "vendor",
    "product",
    "version",
    "update",
    "edition",
    "language",
    "sw_edition",
    "target_sw",
    "target_hw",
    "other",
]


_logger = logging.getLogger(__name__)


class LogicalValue(Enum):
    ANY = "*"
    NA = "-"


@dataclasses.dataclass(frozen=True)
class Cpe23:
    part: Literal["a", "o", "h"] | LogicalValue
    vendor: str | LogicalValue
    product: str | LogicalValue
    version: str | LogicalValue
    update: str | LogicalValue
    edition: str | LogicalValue
    language: str | LogicalValue
    sw_edition: str | LogicalValue
    target_sw: str | LogicalValue
    target_hw: str | LogicalValue
    other: str | LogicalValue

    def __str__(self) -> str:
        values = []
        for n in _CPE23_FIELD_NAMES:
            v = getattr(self, n)
            if isinstance(v, str):
                values.append(v.translate(_CPE23_ENCODE_TRANS_TABLE))
            else:
                values.append(v.value)
        return "cpe:2.3:" + ":".join(values)

    def __repr__(self) -> str:
        return f'"{self!s}"'

    @staticmethod
    def parse(cpe_str: str | None) -> Optional["Cpe23"]:
        if (cpe_str is None) or (not cpe_str.startswith("cpe:2.3:")):
            return None

        prev_backslash = False
        values = []
        value = ""
        for c in cpe_str[8:]:
            if prev_backslash:
                if c in _CPE23_ESCAPED_CHARS:
                    value += c
                    prev_backslash = False
                else:
                    _logger.debug("Unexpected escaped char %s in CPE: %s", c, cpe_str)
                    return None

            elif c == "\\":
                prev_backslash = True

            elif c == ":":
                values.append(value)
                value = ""

            else:
                value += c

        values.append(value)
        if len(values) != len(_CPE23_FIELD_NAMES):
            _logger.debug(
                "Unexpected number of attributes in CPE 2.3 string: %s", cpe_str
            )
            return None

        cpe_key_vals = {}

        for field_name, value in zip(_CPE23_FIELD_NAMES, values, strict=False):
            val: str | LogicalValue = value
            if value == "-":
                val = LogicalValue.NA
            elif value == "*":
                val = LogicalValue.ANY

            cpe_key_vals[field_name] = val

        return Cpe23(**cpe_key_vals)  # type: ignore[arg-type]


def parse_cpe_match(
    json_obj: dict[str, Any], cna_org: str | None
) -> tuple[Cpe23 | None, VersionRange | None]:
    vers_range_builder = VersionRangeBuilder(
        vulnerable=json_obj.get("vulnerable", True), from_cpe=True, from_cna=cna_org
    )
    cpe = Cpe23.parse(json_obj.get("criteria"))
    if cpe is not None:
        if cpe.product == LogicalValue.NA:
            # ignore when product is '-', which means N/A
            return None, None

        if isinstance(cpe.version, str):
            # Version is defined, this is a '=' match. If the CPE update field is
            # not '*', append it to the version
            if isinstance(cpe.update, str):
                vers_range_builder.set_start_version(
                    f"{cpe.version}-{cpe.update}", equal=True
                )
            else:
                vers_range_builder.set_start_version(cpe.version, equal=True)

    # Parse start version, end version and operators
    if "versionStartIncluding" in json_obj:
        vers_range_builder.set_start_version(
            json_obj["versionStartIncluding"], including=True
        )

    if "versionStartExcluding" in json_obj:
        vers_range_builder.set_start_version(
            json_obj["versionStartExcluding"], including=False
        )

    if "versionEndIncluding" in json_obj:
        vers_range_builder.set_end_version(
            json_obj["versionEndIncluding"], including=True
        )

    if "versionEndExcluding" in json_obj:
        vers_range_builder.set_end_version(
            json_obj["versionEndExcluding"], including=False
        )

    if vers_range_builder.is_valid():
        return cpe, vers_range_builder.sem_ver_range

    return cpe, None
