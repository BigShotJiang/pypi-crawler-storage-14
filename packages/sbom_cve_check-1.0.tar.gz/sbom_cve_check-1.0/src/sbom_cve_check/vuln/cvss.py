# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import dataclasses
from collections.abc import Callable, Iterable
from enum import Enum
from typing import Any, Optional, TypeVar

from ..utils.class_utils import Singleton

_CvssEnumT = TypeVar("_CvssEnumT", bound=Enum)
GroupByT = TypeVar("GroupByT")


class CvssMetricsRegistry(metaclass=Singleton):
    def __init__(self) -> None:
        self._metrics: dict[tuple[int, str], tuple[type[Enum], str]] = {}

    def register_type(self, t: type[Enum], vers: int, key: str, desc: str) -> None:
        metric_key = (vers, key)
        assert metric_key not in self._metrics
        self._metrics[metric_key] = (t, desc)

    def desc(self, vers: int, key: str) -> str | None:
        info = self._metrics.get((vers, key))
        return info[1] if info else None

    def value(self, vers: int, key: str, val: str) -> Enum | None:
        info = self._metrics.get((vers, key))
        if not info:
            return None
        return info[0](val)


def register_cvss_metric(
    vers: int, key: str, desc: str
) -> Callable[[type[_CvssEnumT]], type[_CvssEnumT]]:
    def decorator(cls: type[_CvssEnumT]) -> type[_CvssEnumT]:
        CvssMetricsRegistry().register_type(cls, vers, key, desc)
        return cls

    return decorator


class CvssVersion(Enum):
    UNKNOWN = (0, 0)
    V2_0 = (2, 0)
    V3_0 = (3, 0)
    V3_1 = (3, 1)
    V4_0 = (4, 0)


class CvssSeverity(Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@register_cvss_metric(2, "AV", "Access Vector")
class Cvss2AccessVector(Enum):
    LOCAL = "L"
    ADJACENT_NETWORK = "A"
    NETWORK = "N"


@register_cvss_metric(3, "AV", "Attack Vector")
class Cvss3AttackVector(Enum):
    LOCAL = "L"
    ADJACENT_NETWORK = "A"
    NETWORK = "N"
    PHYSICAL = "P"


@register_cvss_metric(4, "AV", "Attack Vector")
class Cvss4AttackVector(Enum):
    LOCAL = "L"
    ADJACENT = "A"
    NETWORK = "N"
    PHYSICAL = "P"


@dataclasses.dataclass(frozen=True)
class CvssMetric:
    cvss_ver: CvssVersion
    score: float
    vector_str: str
    severity: CvssSeverity | None = None
    source: str | None = None

    def cmp_key(self) -> tuple[Any, ...]:
        return (
            self.cvss_ver.value,
            self.score,
            tuple(sorted(self.vector_str.split("/"))),
        )

    def decode_vector(self) -> dict[str, Enum]:
        metrics: dict[str, Enum] = {}
        vers = self.cvss_ver.value[0]
        registry = CvssMetricsRegistry()
        vector_parts = self.vector_str.split("/")
        if vers > 2:
            vector_parts = vector_parts[1:]
        for metric in vector_parts:
            key, v = metric.split(":", 1)
            e = registry.value(vers, key, v)
            if e is not None:
                metrics[key] = e
        return metrics

    @staticmethod
    def compute_severity_from_score(score: float) -> CvssSeverity:
        if score < 0.1:
            return CvssSeverity.NONE
        if score < 4.0:
            return CvssSeverity.LOW
        if score < 7.0:
            return CvssSeverity.MEDIUM
        if score < 9.0:
            return CvssSeverity.HIGH
        return CvssSeverity.CRITICAL

    @staticmethod
    def parse_cve_db_metric(
        json_obj: dict[str, Any] | None,
        *,
        source: str | None = None,
        version: CvssVersion | None = None,
    ) -> Optional["CvssMetric"]:
        if json_obj is None:
            return None

        v = json_obj.get("version")
        cvss_ver: CvssVersion | None = version
        if v == "2.0":
            cvss_ver = CvssVersion.V2_0
        elif v == "3.0":
            cvss_ver = CvssVersion.V3_0
        elif v == "3.1":
            cvss_ver = CvssVersion.V3_1
        elif v == "4.0":
            cvss_ver = CvssVersion.V4_0

        if cvss_ver is None:
            return None

        if (version is not None) and (version != cvss_ver):
            raise ValueError(f"Unexpected CvssMetric version {version} != {cvss_ver}")

        score = json_obj.get("baseScore")
        vector_str = json_obj.get("vectorString")

        if (score is None) or (vector_str is None):
            return None

        severity = None
        if cvss_ver != CvssVersion.V2_0:
            sev: str | None = json_obj.get("baseSeverity")
            if sev is None:
                return None
            try:
                severity = CvssSeverity(sev.lower())
            except ValueError:
                return None

        return CvssMetric(
            cvss_ver=cvss_ver,
            score=float(score),
            vector_str=vector_str,
            severity=severity,
            source=source,
        )


def group_cvss_metrics(
    metrics: Iterable[CvssMetric], key: Callable[[CvssMetric], GroupByT]
) -> dict[GroupByT, tuple[CvssMetric, ...]]:
    """
    Returns CVSS metrics, associated with this CVE, grouped by any custom key
    derived from CVSS metric, then sort them by order of importance.
    """
    metrics_grouped: dict[GroupByT, list[CvssMetric]] = {}
    for metric in metrics:
        metrics_grouped.setdefault(key(metric), []).append(metric)
    return {
        k: tuple(
            sorted(
                m,
                key=lambda x: (
                    x.score,
                    x.cvss_ver.value,
                    len(x.vector_str),
                    x.source or "",
                    x.vector_str,
                ),
                reverse=True,
            )
        )
        for k, m in metrics_grouped.items()
    }
