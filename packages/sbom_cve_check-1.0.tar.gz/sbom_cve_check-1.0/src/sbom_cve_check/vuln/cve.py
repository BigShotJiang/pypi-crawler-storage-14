# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
import dataclasses
from datetime import datetime
from enum import Enum, auto

from .cvss import CvssMetric


class CveId:
    def __init__(self, cve_id: str) -> None:
        self._id = cve_id

    @property
    def id(self) -> str:
        return self._id

    @property
    def year_and_number(self) -> tuple[str, str]:
        parts = self._id.split("-")
        if (len(parts) != 3) or (parts[0] != "CVE"):
            raise ValueError(f"Invalid CVE identifier: {self._id}")
        return parts[1], parts[2]

    @property
    def year(self) -> str:
        return self.year_and_number[0]

    @property
    def number(self) -> str:
        return self.year_and_number[1]

    def __hash__(self) -> int:
        return hash(self._id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, CveId):
            return False
        return other._id == self._id

    def __repr__(self) -> str:
        return self._id


@dataclasses.dataclass(frozen=True, order=True)
class CveExtReference:
    url: str
    # ExternalRefType
    ref_type: str | None = dataclasses.field(default=None, hash=False, compare=False)


class CveVexStatus(Enum):
    UNKNOWN = None
    UNDER_INVESTIGATION = "under_investigation"
    AFFECTED = "affected"
    NOT_AFFECTED = "not_affected"
    FIXED = "fixed"

    def is_vulnerable(self) -> bool | None:
        if self in (CveVexStatus.NOT_AFFECTED, CveVexStatus.FIXED):
            return False
        if self in (CveVexStatus.AFFECTED, CveVexStatus.UNDER_INVESTIGATION):
            return True
        return None


@dataclasses.dataclass(kw_only=True)
class CveVexAssessment(abc.ABC):
    vex_version: str | None = None
    status_notes: str | None = None

    @property
    @abc.abstractmethod
    def status(self) -> CveVexStatus:
        pass

    def _detail(self, extra: list[str | None]) -> str | None:
        lst = []
        if self.status_notes:
            lst.append(self.status_notes)
        if extra:
            lst.extend(d for d in extra if d)
        if lst:
            return ": ".join(lst)
        return None

    @property
    def detail(self) -> str | None:
        """Provide statement and status notes"""
        return self._detail([])

    def __str__(self) -> str:
        d = self.detail
        if d:
            return f"{self.status.value} ({d})"
        return str(self.status.value)


@dataclasses.dataclass(kw_only=True)
class CveVexFixedAssessment(CveVexAssessment):
    @property
    def status(self) -> CveVexStatus:
        return CveVexStatus.FIXED


@dataclasses.dataclass(kw_only=True)
class CveVexOldVersNotVulnAssessment(CveVexFixedAssessment):
    pass


@dataclasses.dataclass(kw_only=True)
class CveVexAffectedAssessment(CveVexAssessment):
    action_statement: str
    action_statement_time: datetime | None = None

    @property
    def status(self) -> CveVexStatus:
        return CveVexStatus.AFFECTED

    @property
    def detail(self) -> str | None:
        return self._detail([self.action_statement])


@dataclasses.dataclass(kw_only=True)
class CveVexMissingVersionsAssessment(CveVexAffectedAssessment):
    pass


class CveVexJustification(Enum):
    COMPONENT_NOT_PRESENT = auto()
    INLINE_MITIGATIONS_ALREADY_EXIST = auto()
    VULNERABLE_CODE_CANNOT_BE_CONTROLLED_BY_ADVERSARY = auto()
    VULNERABLE_CODE_NOT_IN_EXECUTE_PATH = auto()
    VULNERABLE_CODE_NOT_PRESENT = auto()


@dataclasses.dataclass(kw_only=True)
class CveVexNotAffectedAssessment(CveVexAssessment):
    impact_statement: str
    impact_statement_time: datetime | None = None
    justification: CveVexJustification | None = None

    @property
    def status(self) -> CveVexStatus:
        return CveVexStatus.NOT_AFFECTED

    @property
    def detail(self) -> str | None:
        return self._detail(
            [
                self.justification.name.lower() if self.justification else None,
                self.impact_statement,
            ]
        )


@dataclasses.dataclass(kw_only=True)
class CveVexRejectedAssessment(CveVexNotAffectedAssessment):
    pass


@dataclasses.dataclass(kw_only=True)
class CveVexUnderInvestigationAssessment(CveVexAssessment):
    @property
    def status(self) -> CveVexStatus:
        return CveVexStatus.UNDER_INVESTIGATION


def find_most_appropriate_assessment(
    a: CveVexAssessment | None, b: CveVexAssessment | None
) -> CveVexAssessment | None:
    if (a is None) or (b is None):
        return a or b

    assessment_order = {
        CveVexStatus.UNKNOWN: 0,
        CveVexStatus.NOT_AFFECTED: 1,
        CveVexStatus.FIXED: 2,
        CveVexStatus.UNDER_INVESTIGATION: 3,
        CveVexStatus.AFFECTED: 4,
    }

    return a if assessment_order[a.status] >= assessment_order[b.status] else b


@dataclasses.dataclass
class CveInfo:
    cve_id: CveId
    date_published: datetime | None = None
    date_modified: datetime | None = None
    description: str | None = None
    cvss_metrics: list[CvssMetric] = dataclasses.field(default_factory=list)
    references: list[CveExtReference] = dataclasses.field(default_factory=list)
    vex_assessment: CveVexAssessment | None = None
