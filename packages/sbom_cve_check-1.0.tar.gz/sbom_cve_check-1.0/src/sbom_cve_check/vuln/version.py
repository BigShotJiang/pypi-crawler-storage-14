# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
import dataclasses
import functools
import itertools
import operator
import re
from collections.abc import Callable
from enum import Enum
from typing import Any, Final

_VERSION_PATTERN = r"""
    ^[rv]?
    (?:[0-9]:)?                                             # epoch
    (?P<release>                                            # release segment
        [0-9]+(?:\.(?:[0-9]+|\*))+
        |
        [0-9]+(?:-[0-9]+)+
        |
        (?:[0-9]+|\*)
    )
    (?:                                                     # alphabetical segment
        [._-]?(?P<letter>[a-z])
        (?:$|(?=[._-]))
    )?
    (?:                                                     # patch segment
        [._-]?
        (p|patch)_?
        (?P<patch_n>[0-9]+)
    )?
    (?:                                                     # pre-release
        [._-]?
        (?P<pre_l1>(alpha|beta|preview|pre|rc|dev))
        [._-]?
        (?P<pre_n1>[0-9]+)?
        |
        [._-]?
        (?P<pre_l2>(a|b|c))
        (?P<pre_n2>[0-9]+)
    )?
    (?:                                                     # post release
        (?:-(?P<post_n1>[0-9]+))
        |
        (?:
            [._-]?
            (?:post|rev|r)
            [._-]?
            (?P<post_n2>[0-9]+)?
        )
    )?
"""

_version_regex = re.compile(_VERSION_PATTERN, re.VERBOSE | re.IGNORECASE)


@functools.total_ordering
class InfinityType:
    def __repr__(self) -> str:
        return "Infinity"

    def __hash__(self) -> int:
        return hash(repr(self))

    def __eq__(self, other: object) -> bool:
        return isinstance(other, InfinityType)

    def __gt__(self, other: object) -> bool:
        return not isinstance(other, InfinityType)


INFINITY: Final = InfinityType()


@functools.total_ordering
class NegInfinityType:
    def __repr__(self) -> str:
        return "-Infinity"

    def __hash__(self) -> int:
        return hash(repr(self))

    def __eq__(self, other: object) -> bool:
        return isinstance(other, NegInfinityType)

    def __lt__(self, other: object) -> bool:
        return not isinstance(other, NegInfinityType)


NEG_INFINITY: Final = NegInfinityType()


def _parse_pre_release(
    letter: str | None, number: str | None
) -> tuple[str, int] | None:
    if letter is None:
        return None

    # We consider there to be an implicit 0 in a pre-release if there is not a numeral
    # associated with it.
    num_val = 0 if number is None else int(number)

    # We normalize any letters to their lower case form
    letter = letter.lower()

    # We consider some words to be alternate spellings of other words and in those
    # cases we want to normalize the spellings to our preferred spelling.
    if letter == "alpha":
        letter = "a"
    elif letter == "beta":
        letter = "b"
    elif letter in ["c", "pre", "preview"]:
        letter = "rc"

    return letter, num_val


def _parse_vers_number(v: str | None) -> int | None:
    if v is not None:
        return int(v)
    return None


def _create_compare_keys(version: str) -> tuple[Any, ...]:
    match = _version_regex.search(version)
    if not match:
        return ()

    rel_match = match.group("release")
    # If the version starts with a 'r', consider this is a simple CVS revision,
    # so create a fake version: 0.0.0.r
    if (version[0:1] == "r") and ("." not in rel_match):
        rel_match = f"0.0.0.{rel_match}"
    release = rel_match.replace("-", ".").split(".")
    letter = match.group("letter")
    patch = _parse_vers_number(match.group("patch_n"))
    pre = _parse_pre_release(
        match.group("pre_l1"), match.group("pre_n1")
    ) or _parse_pre_release(match.group("pre_l2"), match.group("pre_n2"))
    post = _parse_vers_number(match.group("post_n1") or match.group("post_n2"))

    # When we compare a release version, we want to compare it with all the trailing
    # zeros removed. So we'll reverse the list, drop all the now leading zeros until we
    # come to something non-zero, then take the rest re-reverse it back into the
    # correct order.
    release_p = [INFINITY if v == "*" else int(v) for v in release]
    _release = tuple(
        reversed(list(itertools.dropwhile(lambda x: x == 0, reversed(release_p))))
    )

    # Versions without a letter (after release part) should sort before those with one.
    _letter = NEG_INFINITY if letter is None else letter

    # Versions without a patch segment should sort before those with one.
    _patch = NEG_INFINITY if patch is None else patch

    # Versions without a pre-release should sort after those with one.
    _pre = INFINITY if pre is None else pre

    # Versions without a post segment should sort before those with one.
    _post = NEG_INFINITY if post is None else post

    return _release, _letter, _patch, _pre, _post


@functools.total_ordering
class Version:
    def __init__(self, v: str) -> None:
        self._version = v.strip()
        self._cmp_keys = _create_compare_keys(self._version)

    def __repr__(self) -> str:
        return self._version

    @property
    def original(self) -> str:
        return self._version

    def is_valid(self) -> bool:
        return bool(self._cmp_keys)

    def __hash__(self) -> int:
        return hash(self._cmp_keys)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Version):
            return NotImplemented
        return self._cmp_keys == other._cmp_keys

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, Version):
            return NotImplemented
        return self._cmp_keys > other._cmp_keys


_OPERATOR_TO_STR: Final[dict[Callable[[Version, Version], bool] | None, str]] = {
    operator.lt: "<",
    operator.le: "<=",
    operator.eq: "=",
    operator.ge: ">=",
    operator.gt: ">",
    None: "",
}


class VersRangeStatus(Enum):
    NO_INFO = None
    SMALLER = -1
    IN_RANGE = 0
    GREATER = 1


@dataclasses.dataclass(frozen=True, kw_only=True)
class VersionRange(abc.ABC):
    vulnerable: bool | None
    from_cpe: bool | None = None
    from_cna: str | None = None  # CNA organization identifier

    def is_not_vuln_trusted(self) -> bool:
        """
        :return: True if we trust version range that are declared not vulnerable.
        By default, do not trust it.
        """
        # Special case for kernel.org CNA
        return self.from_cna == "416baaa9-dc9f-4396-8d5f-8c081fb06d67"


@dataclasses.dataclass(frozen=True, kw_only=True)
class _CmpVersion:
    vers: Version
    op: Callable[[Version, Version], bool]

    def compare(self, pkg_version: Version) -> bool:
        return self.op(pkg_version, self.vers)


@dataclasses.dataclass(frozen=True, kw_only=True)
class SemVerRange(VersionRange):
    v_start: str | None
    op_start: Callable[[Version, Version], bool] | None
    v_end: str | None
    op_end: Callable[[Version, Version], bool] | None

    def __str__(self) -> str:
        s = f"[{_OPERATOR_TO_STR[self.op_start]} {self.v_start}"
        if self.v_end:
            s = f"{s}, {_OPERATOR_TO_STR[self.op_end]} {self.v_end}"
        return f"{s}]: vuln={self.vulnerable}"

    @staticmethod
    def build_single_vers(
        vulnerable: bool, v_start: str, from_cpe: bool
    ) -> "SemVerRange":
        return SemVerRange(
            vulnerable=vulnerable,
            from_cpe=from_cpe,
            v_start=v_start,
            op_start=operator.eq,
            v_end=None,
            op_end=None,
        )

    def check_strictly_equal(self, pkg_version: str) -> bool:
        """
        For annotation, check that the specified version is strictly equal to the start
        version. If this range does not specify a unique version, always return false
        """
        return (pkg_version == self.v_start) and (self.op_start == operator.eq)

    def check_in_range(self, pkg_version: Version) -> VersRangeStatus:
        """
        Check if a component version is within specified range. If this is not the case,
        indicate if the component version is smaller or greater than the specified
        version range.
        """
        if not pkg_version.is_valid():
            return VersRangeStatus.NO_INFO

        cmp_start: _CmpVersion | None = None
        if (self.v_start is not None) and (self.op_start is not None):
            v = Version(self.v_start)
            if v.is_valid():
                cmp_start = _CmpVersion(vers=v, op=self.op_start)

        cmp_end: _CmpVersion | None = None
        if (self.v_end is not None) and (self.op_end is not None):
            v = Version(self.v_end)
            if v.is_valid():
                cmp_end = _CmpVersion(vers=v, op=self.op_end)

        if (cmp_start is not None) and (cmp_end is not None):
            r_start = cmp_start.compare(pkg_version)
            r_end = cmp_end.compare(pkg_version)
            if r_start and r_end:
                return VersRangeStatus.IN_RANGE
            if not r_start:
                return VersRangeStatus.SMALLER
            return VersRangeStatus.GREATER

        if cmp_start is not None:
            r_start = cmp_start.compare(pkg_version)
            if self.op_start == operator.eq:
                if r_start:
                    return VersRangeStatus.IN_RANGE
                if pkg_version < cmp_start.vers:
                    return VersRangeStatus.SMALLER
                return VersRangeStatus.GREATER
            if r_start:
                return VersRangeStatus.IN_RANGE
            return VersRangeStatus.SMALLER

        if cmp_end is not None:
            r_end = cmp_end.compare(pkg_version)
            if r_end:
                return VersRangeStatus.IN_RANGE
            return VersRangeStatus.GREATER

        return VersRangeStatus.NO_INFO


@dataclasses.dataclass(frozen=True, kw_only=True)
class GitVerRange(VersionRange):
    # This git commit is that start version (included)
    v_start: str
    # This git commit is that end version (that may be included in the range)
    v_end: str | None = None
    end_included: bool = False


class VersionRangeBuilder:
    def __init__(
        self,
        *,
        vulnerable: bool | None,
        from_cpe: bool | None = None,
        from_cna: str | None = None,
    ) -> None:
        self._vulnerable: bool | None = vulnerable
        self._from_cpe: bool | None = from_cpe
        self._from_cna: str | None = from_cna
        self._v_start: str | None = None
        self._start_including: bool | None = None
        self._start_equal: bool | None = None
        self._v_end: str | None = None
        self._end_including: bool | None = None

    def set_start_version(
        self, version: str, *, including: bool = False, equal: bool = False
    ) -> None:
        self._v_start = version
        self._start_including = including
        self._start_equal = equal

    def set_end_version(self, version: str, *, including: bool = False) -> None:
        self._v_end = None if version == "*" else version
        self._end_including = including

    def is_valid(self) -> bool:
        return (self._v_start is not None) or (self._v_end is not None)

    @property
    def sem_ver_range(self) -> SemVerRange:
        op_start: Callable[[Version, Version], bool] | None = None
        if self._v_start is not None:
            if self._start_equal:
                op_start = operator.eq
            elif self._start_including:
                op_start = operator.ge
            else:
                op_start = operator.gt

        op_end = None
        if self._v_end is not None:
            op_end = operator.le if self._end_including else operator.lt

        return SemVerRange(
            vulnerable=self._vulnerable,
            from_cpe=self._from_cpe,
            from_cna=self._from_cna,
            v_start=self._v_start,
            op_start=op_start,
            v_end=self._v_end,
            op_end=op_end,
        )

    @property
    def git_ver_range(self) -> GitVerRange:
        if self._start_equal or not self._start_including:
            raise ValueError(
                'Start version for a git version range is always "including"'
            )

        if self._v_start is None:
            raise ValueError("Missing start version")

        return GitVerRange(
            vulnerable=self._vulnerable,
            from_cpe=self._from_cpe,
            from_cna=self._from_cna,
            v_start=self._v_start,
            v_end=self._v_end,
            end_included=bool(self._end_including),
        )
