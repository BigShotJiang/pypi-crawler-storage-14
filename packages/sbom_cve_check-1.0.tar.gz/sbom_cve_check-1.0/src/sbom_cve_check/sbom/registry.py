# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import pathlib
from collections.abc import Callable, Iterable
from typing import TypeVar

from ..utils.class_utils import Singleton
from ..utils.plugin import import_builtin_plugin
from .sbom_base import Sbom

_SbomT = TypeVar("_SbomT", bound=Sbom)


class SbomTypeRegistry(metaclass=Singleton):
    def __init__(self) -> None:
        self._sbom_types: dict[str, type[Sbom]] = {}

    def register_type(self, type_name: str, sbom_type: type[Sbom]) -> None:
        assert type_name not in self._sbom_types
        self._sbom_types[type_name] = sbom_type

    @property
    def type_names(self) -> Iterable[str]:
        return self._sbom_types.keys()

    def create(self, type_name: str | None, path: pathlib.Path) -> Sbom:
        if type_name is None:
            # Try to autodetect SBOM type from the file extension
            for name, sbom_type in self._sbom_types.items():
                if sbom_type.can_handle_sbom(path):
                    type_name = name
                    break
            else:
                raise ValueError(f"Can not autodetect SBOM format: {path.name}")

        cls_sbom: type[Sbom] = self._sbom_types[type_name]
        return cls_sbom(path)


def register_sbom(name: str) -> Callable[[type[_SbomT]], type[_SbomT]]:
    def decorator(cls: type[_SbomT]) -> type[_SbomT]:
        SbomTypeRegistry().register_type(name, cls)
        return cls

    return decorator


def __register_builtin_types() -> None:
    modules = [".sbom_spdx2", ".sbom_spdx3"]
    for mod in modules:
        import_builtin_plugin(__package__, mod)


__register_builtin_types()
