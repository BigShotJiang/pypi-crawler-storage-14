# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
import dataclasses
import functools
import logging
import pathlib
from collections.abc import Iterable
from enum import Enum
from typing import Any, Literal, Optional

from ..vuln.cpe import Cpe23, LogicalValue
from ..vuln.cve import CveInfo

_logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True, kw_only=True)
@functools.total_ordering
class CompId:
    """
    Object that represent a package identifier, to identify a software component.
    This object only contain information to identify the component: typically the
    product name or package name.
    This object does not contain version information.
    """

    part: Literal["a", "o", "h"] | None = None
    vendor: str | None = None
    name: str

    def to_str(self, full: bool = False) -> str:
        els: list[str] = []
        part: str | None = self.part if full and self.part else None
        if part:
            els.append(part)
        if self.vendor:
            els.append(self.vendor)
        elif part:
            els.append("")
        els.append(self.name)
        return ":".join(els)

    def __str__(self) -> str:
        return self.to_str(True)

    def is_matching(self, other: "CompId") -> bool:
        """
        Checks if another component, identified by a CPE, is the same component that is
        identified by this CPE. For now only check part and product/vendor.
        """
        if other.name != self.name:
            return False

        if (
            (self.part is not None)
            and (other.part is not None)
            and (self.part != other.part)
        ):
            return False

        return not (
            self.vendor is not None
            and other.vendor is not None
            and self.vendor != other.vendor
        )

    def is_matching_one_of(self, others: Iterable["CompId"]) -> bool:
        """
        :return: True if one of the component identifier specified as input matches
        with this component identifier
        """
        return any(self.is_matching(other) for other in others)

    def __tuple_for_cmp(self) -> tuple[str, ...]:
        return self.name, str(self.vendor or ""), str(self.part or "")

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, CompId):
            return NotImplemented
        return self.__tuple_for_cmp() < other.__tuple_for_cmp()

    @staticmethod
    def filter_best_ids(comp_ids: Iterable["CompId"]) -> set["CompId"]:
        """
        Keep only the best component identifiers (with vendor), but if in the list
        there is no identifier with vendor, return the original list
        """
        best_comp_ids: set[CompId] = set()
        list_has_vendor = False
        for comp_id in comp_ids:
            id_has_vendor = comp_id.vendor is not None
            if id_has_vendor and not list_has_vendor:
                best_comp_ids.clear()
                list_has_vendor = True

            if id_has_vendor == list_has_vendor:
                best_comp_ids.add(comp_id)

        return best_comp_ids

    @staticmethod
    def build_from_cpe(cpe: Cpe23 | str | None) -> Optional["CompId"]:
        if isinstance(cpe, str):
            cpe = Cpe23.parse(cpe)

        if cpe is None:
            return None

        product = cpe.product
        if not isinstance(product, str):
            return None

        if cpe.part == LogicalValue.NA:
            return None
        part: Literal["a", "o", "h"] | None = None
        if isinstance(cpe.part, str):
            part = cpe.part

        if cpe.vendor == LogicalValue.NA:
            return None
        vendor: str | None = None
        if isinstance(cpe.vendor, str):
            vendor = cpe.vendor

        return CompId(part=part, vendor=vendor, name=product)

    @staticmethod
    def build_from_vendor_product_str(vendor_product: str) -> "CompId":
        parts = vendor_product.split(":", maxsplit=1)
        if len(parts) == 1:
            return CompId(name=parts[0])
        return CompId(vendor=parts[0], name=parts[1])

    def build_cpe(self, **kwargs: Any) -> Cpe23:
        # noinspection PyTypeChecker
        return Cpe23(
            part=self.part or LogicalValue.ANY,
            vendor=self.vendor or LogicalValue.ANY,
            product=self.name,
            version=kwargs.get("version", LogicalValue.ANY),
            update=kwargs.get("update", LogicalValue.ANY),
            edition=kwargs.get("edition", LogicalValue.ANY),
            language=kwargs.get("language", LogicalValue.ANY),
            sw_edition=kwargs.get("sw_edition", LogicalValue.ANY),
            target_sw=kwargs.get("target_sw", LogicalValue.ANY),
            target_hw=kwargs.get("target_hw", LogicalValue.ANY),
            other=kwargs.get("other", LogicalValue.ANY),
        )


def comp_ids_is_matching_one_of(
    lst1_ids: Iterable[CompId], lst2_ids: Iterable[CompId]
) -> bool:
    """
    :return: True if one of the component identifier of the first list matches with
    one of the component identifier of the second list
    """
    return any(comp_id.is_matching_one_of(lst2_ids) for comp_id in lst1_ids)


@dataclasses.dataclass(frozen=True, order=True, init=False)
class CompVersIds:
    """
    Allow to identify a software component with the version.
    A software component may have multiple "identifier"
    (for example different vendor/product).
    """

    # Sorted component identifiers
    ids: tuple[CompId, ...]
    # Component version: Version used to identify a CVE is preferred
    version: str

    def __init__(self, *, ids: Iterable[CompId], version: str) -> None:
        object.__setattr__(self, "ids", tuple(sorted(set(ids))))
        object.__setattr__(self, "version", version)


class CompType(Enum):
    APPLICATION = ("application",)
    LIBRARY = "library"
    OS = "operating-system"
    DEVICE = "device"
    FIRMWARE = "firmware"
    FILE = "file"


class Component(abc.ABC):
    """Object that provides information about one package / software component."""

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """:return: Component / package / product name"""

    @property
    @abc.abstractmethod
    def version(self) -> str | None:
        """:return: The component version"""

    @property
    @abc.abstractmethod
    def supplier(self) -> str | None:
        """:return: The organization that supplied the component"""

    @property
    @abc.abstractmethod
    def comp_type(self) -> CompType | None:
        """:return: Specifies the type of component"""

    @property
    @abc.abstractmethod
    def identifiers(self) -> set[CompId]:
        """:return: A set of component identifier to be able to compare 2 components"""

    @property
    def purls(self) -> set[str]:
        """:return: A set of PURL that identify this component"""
        return set()

    @property
    def cpes(self) -> set[Cpe23]:
        """:return: A set of CPEs that identify this component"""
        return set()

    @property
    def description(self) -> str | None:
        """:return: A description of this component"""
        return None

    @property
    def license_expression(self) -> str | None:
        """:return: A license expression"""
        return None

    @property
    def source_urls(self) -> set[tuple[str, str]]:
        """
        :return: The set of sources used to build this component.
        The list contain a tuple of source type and URL.
        """
        return set()

    @property
    def depend_on(self) -> list["Component"]:
        """:return: The list of component that this component depends on"""
        return []

    def add_cve_vulnerability(
        self, cve_info: CveInfo, *, update_vuln_info: bool = True
    ) -> None:
        """
        Add new CVE vulnerability associated with this component, or if already exists,
        update the CVE information.
        """
        raise NotImplementedError


class CompBuild(abc.ABC):
    """
    Represent a group of components (split packages) that are built from the same
    "recipe". This object must only contain components with the same version and same
    identifiers.
    """

    def __init__(self, vers_ids: CompVersIds, comps: Iterable[Component]) -> None:
        self._vers_ids = vers_ids
        self._comps: tuple[Component, ...] = tuple(sorted(comps, key=lambda t: t.name))
        self._sources: set[str] | None = None
        self._srcs_index: dict[str, list[str]] | None = None

    @staticmethod
    def group_components_by_id(
        comps: Iterable[Component],
    ) -> dict[CompVersIds, list[Component]]:
        comps_grouped: dict[CompVersIds, list[Component]] = {}
        for comp in comps:
            comp_vers = comp.version
            if comp_vers is None:
                _logger.warning(
                    "Component %s (%s) doesn't have a version",
                    comp.name,
                    comp.identifiers,
                )
            else:
                comp_vers_ids = CompVersIds(ids=comp.identifiers, version=comp_vers)
                comps_grouped.setdefault(comp_vers_ids, []).append(comp)
        return comps_grouped

    @property
    def version(self) -> str:
        """:return: The components version"""
        return self._vers_ids.version

    @property
    def identifiers(self) -> tuple[CompId, ...]:
        """:return: The components identifiers (sorted)"""
        return self._vers_ids.ids

    def is_matching_one_of(self, others: Iterable[CompId]) -> bool:
        """
        :return: True if one of the component identifier matches with the ones provided
        by this build "recipe"
        """
        return comp_ids_is_matching_one_of(self._vers_ids.ids, others)

    @property
    def components(self) -> tuple[Component, ...]:
        """
        :return: The list of components (sorted by name) built by this "recipe". These
        components have the same version and same identifiers
        """
        return self._comps

    @property
    @abc.abstractmethod
    def build_name(self) -> str | None:
        """
        :return: The recipe name, script package name, used to generate these
        components/packages
        """

    @abc.abstractmethod
    def _get_compiled_sources(self) -> set[str]:
        """
        :return: Retrieve the sources files used to compile these components:
        Set of file paths
        """

    @property
    def compiled_sources(self) -> set[str]:
        """
        :return: The sources files used to compile these components:
        Set of file paths
        """
        if self._sources is None:
            self._sources = self._get_compiled_sources()
        return self._sources

    @property
    def compiled_sources_index(self) -> dict[str, list[str]]:
        """
        Provide sources files used to compile these components indexed by file name.
        :return: A map with the key containing a file name to a list of file paths
        """
        if self._srcs_index is None:
            index: dict[str, list[str]] = {}
            for compiled_source in self.compiled_sources:
                name = pathlib.Path(compiled_source).name
                if name:
                    index.setdefault(name, []).append(compiled_source)
            self._srcs_index = index
        return self._srcs_index
