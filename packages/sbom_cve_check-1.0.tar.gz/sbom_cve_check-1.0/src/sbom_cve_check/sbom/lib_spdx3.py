# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import hashlib
import pathlib
import re
import uuid
from collections import defaultdict
from collections.abc import Generator, Iterable
from datetime import UTC, datetime
from typing import Any, TypeVar, Union, cast

from spdx_python_model.bindings import v3_0_1 as spdx30  # type: ignore[import-untyped]

from ..utils.reproducible import ReproducibleDateTime
from ..vuln.cpe import Cpe23
from ..vuln.cve import (
    CveInfo,
    CveVexAffectedAssessment,
    CveVexAssessment,
    CveVexFixedAssessment,
    CveVexJustification,
    CveVexNotAffectedAssessment,
    CveVexUnderInvestigationAssessment,
)
from ..vuln.cvss import CvssMetric, CvssSeverity, CvssVersion

SPDX_VERSION = "3.0.1"

ListLikeSHACLObject = Union[  # noqa: UP007
    set[spdx30.SHACLObject], list[spdx30.SHACLObject], tuple[spdx30.SHACLObject]
]

_RelationshipT = TypeVar("_RelationshipT", bound=spdx30.Relationship)


def spdxid_hash(*items: Any) -> str:
    h = hashlib.md5()
    for i in items:
        if isinstance(i, spdx30.Element):
            # noinspection PyProtectedMember
            h.update(i._id.encode("utf-8"))
        else:
            h.update(repr(i).encode("utf-8"))
    return h.hexdigest()


def to_list(
    lst: ListLikeSHACLObject,
) -> list[spdx30.SHACLObject] | tuple[spdx30.SHACLObject]:
    if isinstance(lst, set):
        lst = sorted(lst)

    if not isinstance(lst, (list, tuple)):
        raise TypeError(f"Must be a list or tuple. Got {(type(lst))}")

    return lst


def cvss_severity_from_spdx3_type(severity: str) -> CvssSeverity:
    for name, url in spdx30.security_CvssSeverityType.NAMED_INDIVIDUALS.items():
        if severity == url:
            return CvssSeverity(name)
    raise ValueError(f"Unexpected CVSS spdx 3 severity: {severity}")


def cve_vex_justification_from_str(s: str) -> CveVexJustification | None:
    map_justification: dict[str, CveVexJustification] = {
        "componentNotPresent": CveVexJustification.COMPONENT_NOT_PRESENT,
        "vulnerableCodeNotPresent": CveVexJustification.VULNERABLE_CODE_NOT_PRESENT,
        "inlineMitigationsAlreadyExist":
            CveVexJustification.INLINE_MITIGATIONS_ALREADY_EXIST,
        "vulnerableCodeCannotBeControlledByAdversary":
            CveVexJustification.VULNERABLE_CODE_CANNOT_BE_CONTROLLED_BY_ADVERSARY,
        "vulnerableCodeNotInExecutePath":
            CveVexJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH,
    }  # fmt: skip

    return map_justification.get(s)


def cve_vex_justification_to_str(s: CveVexJustification) -> str:
    map_justification: dict[CveVexJustification, str] = {
        CveVexJustification.COMPONENT_NOT_PRESENT: "componentNotPresent",
        CveVexJustification.VULNERABLE_CODE_NOT_PRESENT: "vulnerableCodeNotPresent",
        CveVexJustification.INLINE_MITIGATIONS_ALREADY_EXIST:
            "inlineMitigationsAlreadyExist",
        CveVexJustification.VULNERABLE_CODE_CANNOT_BE_CONTROLLED_BY_ADVERSARY:
            "vulnerableCodeCannotBeControlledByAdversary",
        CveVexJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH:
            "vulnerableCodeNotInExecutePath",
    }  # fmt: skip

    return map_justification[s]


def cve_vex_assessment_from_vuln_relationship(
    r: spdx30.security_VulnAssessmentRelationship,
) -> CveVexAssessment | None:
    if not isinstance(r, spdx30.security_VexVulnAssessmentRelationship):
        return None

    vex_version = r.security_vexVersion
    status_notes = r.security_statusNotes

    if isinstance(r, spdx30.security_VexFixedVulnAssessmentRelationship):
        return CveVexFixedAssessment(vex_version=vex_version, status_notes=status_notes)

    if isinstance(r, spdx30.security_VexAffectedVulnAssessmentRelationship):
        return CveVexAffectedAssessment(
            vex_version=vex_version,
            status_notes=status_notes,
            action_statement=r.security_actionStatement,
            action_statement_time=r.security_actionStatementTime,
        )

    if isinstance(r, spdx30.security_VexNotAffectedVulnAssessmentRelationship):
        return CveVexNotAffectedAssessment(
            vex_version=vex_version,
            status_notes=status_notes,
            impact_statement=r.security_impactStatement,
            impact_statement_time=r.security_impactStatementTime,
            justification=cve_vex_justification_from_str(r.security_justificationType),
        )

    if isinstance(r, spdx30.security_VexUnderInvestigationVulnAssessmentRelationship):
        return CveVexUnderInvestigationAssessment(
            vex_version=vex_version, status_notes=status_notes
        )

    return None


def cvss_metric_from_vuln_relationship(
    r: spdx30.security_VulnAssessmentRelationship,
) -> CvssMetric | None:
    cvss_ver = None

    if isinstance(r, spdx30.security_CvssV2VulnAssessmentRelationship):
        cvss_ver = CvssVersion.V2_0
    elif isinstance(r, spdx30.security_CvssV3VulnAssessmentRelationship):
        if r.security_vectorString.startswith("CVSS:3.0/"):
            cvss_ver = CvssVersion.V3_0
        elif r.security_vectorString.startswith("CVSS:3.1/"):
            cvss_ver = CvssVersion.V3_1
    elif isinstance(
        r, spdx30.security_CvssV4VulnAssessmentRelationship
    ) and r.security_vectorString.startswith("CVSS:4.0/"):
        cvss_ver = CvssVersion.V4_0

    if cvss_ver is not None:
        severity = (
            cvss_severity_from_spdx3_type(r.security_severity)
            if cvss_ver != CvssVersion.V2_0
            else None
        )
        return CvssMetric(
            cvss_ver=cvss_ver,
            score=r.security_score,
            vector_str=r.security_vectorString,
            severity=severity,
        )
    return None


def vuln_get_cve_id(vuln: spdx30.security_Vulnerability) -> str | None:
    for ext_id in vuln.externalIdentifier:
        if ext_id.externalIdentifierType == spdx30.ExternalIdentifierType.cve:
            cve_id = ext_id.identifier
            if isinstance(cve_id, str):
                return cve_id
    return None


def _creation_info_cmp_key(obj: spdx30.CreationInfo) -> tuple[Any, ...]:
    return (
        obj.created or datetime.fromtimestamp(0, UTC),
        tuple(obj.createdBy),
        tuple(obj.createdUsing),
        obj.comment or "",
    )


def __creation_info_lt(self: spdx30.CreationInfo, other: object) -> bool:
    if not isinstance(other, spdx30.CreationInfo):
        return bool(super(spdx30.CreationInfo, self).__lt__(other))
    return _creation_info_cmp_key(self) < _creation_info_cmp_key(other)


# Hack to have repeatability in SPDX generation
spdx30.CreationInfo.__lt__ = __creation_info_lt


class ObjectSet(spdx30.SHACLObjectSet):  # type: ignore[misc]
    SPDX_UUID_NAMESPACE = "sbom-cve-check"
    SPDX_NAMESPACE_PREFIX = "http://spdx.org/spdxdocs"

    def __init__(self) -> None:
        super().__init__()

        # Unique spdx document and sbom object contained into this graph
        self._doc: spdx30.SpdxDocument | None = None
        self._sbom: spdx30.software_Sbom | None = None

        # Map (cache) between 'from' Relationship and all associated Relationships
        self._map_relation: dict[spdx30.SHACLObject, set[spdx30.Relationship]] = (
            defaultdict(set)
        )
        # Map (cache) between 'to' Relationship and all associated Relationships
        self._map_relation_rev: dict[spdx30.SHACLObject, set[spdx30.Relationship]] = (
            defaultdict(set)
        )
        # Map (cache) between CVE identifier and associated vulnerabilities
        self._map_cve_vulns: dict[str, set[spdx30.security_Vulnerability]] = (
            defaultdict(set)
        )
        # Map (cache) between a package and associated vulnerabilities and relationships
        self._map_pkg_vulns: dict[
            spdx30.software_Package,
            dict[
                spdx30.security_Vulnerability,
                set[spdx30.security_VulnAssessmentRelationship],
            ],
        ] = defaultdict(dict)

    def __add_assess_to_map_pkg_vulns(
        self, p: spdx30.software_Package, rel: spdx30.Relationship
    ) -> None:
        if rel.relationshipType == spdx30.RelationshipType.hasAssociatedVulnerability:
            for vuln in rel.to:
                assessment_rels = self._map_pkg_vulns[p].setdefault(vuln, set())
                for assessment in self._map_relation.get(vuln, []):
                    if (
                        isinstance(
                            assessment,
                            spdx30.security_VulnAssessmentRelationship,
                        )
                        and p in assessment.to
                    ):
                        assessment_rels.add(assessment)

    def _update_map_cache(self) -> None:
        self._map_relation.clear()
        self._map_relation_rev.clear()
        self._map_cve_vulns.clear()

        for r in self.foreach_type(spdx30.Relationship):
            self._map_relation[r.from_].add(r)
            for o in r.to:
                self._map_relation_rev[o].add(r)

        for v in self.foreach_type(spdx30.security_Vulnerability):
            cve_id = vuln_get_cve_id(v)
            if cve_id:
                self._map_cve_vulns[cve_id].add(v)

        for p in self.iterate_install_packages():
            rels = self._map_relation.get(p)
            if not rels:
                continue

            for rel in rels:
                self.__add_assess_to_map_pkg_vulns(p, rel)

    def _init_parsed_document(self) -> None:
        for d in self.foreach_type(spdx30.SpdxDocument):
            self._doc = d
            break

        if not self._doc:
            raise ValueError("Graph is missing an SpdxDocument node")

        self._sbom = None
        if len(self._doc.rootElement) == 1:
            sbom = self._doc.rootElement[0]
            if isinstance(sbom, spdx30.software_Sbom):
                self._sbom = sbom

        if not self._sbom:
            raise ValueError("SpdxDocument does not contain an Sbom node")

        self._update_map_cache()

    @classmethod
    def parse_jsonld(cls, path_spdx: str | pathlib.Path) -> "ObjectSet":
        object_set = cls()
        with pathlib.Path(path_spdx).open() as f:
            d = spdx30.JSONLDDeserializer()
            d.read(f, object_set)
        object_set._init_parsed_document()
        return object_set

    def _cleanup_creation_info(self) -> None:
        refed_ci: dict[tuple[Any, ...], spdx30.CreationInfo] = {}
        insta_ci: set[spdx30.CreationInfo] = set()

        for o in self.objects:
            if isinstance(o, spdx30.CreationInfo):
                insta_ci.add(o)
            elif isinstance(o, spdx30.Element):
                ci: spdx30.CreationInfo = o.creationInfo
                if ci:
                    key = _creation_info_cmp_key(ci)
                    similar_ci = refed_ci.get(key)
                    if similar_ci is not None:
                        o.creationInfo = similar_ci
                    else:
                        refed_ci[key] = ci

        insta_ci -= set(refed_ci.values())
        self.objects -= insta_ci

    def write_to_jsonld(self, path_spdx: str | pathlib.Path) -> None:
        self._cleanup_creation_info()
        with pathlib.Path(path_spdx).open("wb") as f:
            s = spdx30.JSONLDInlineSerializer()
            s.write(self, f)

    def add(self, obj: spdx30.SHACLObject) -> spdx30.SHACLObject:
        if isinstance(obj, spdx30.Relationship):
            self._map_relation[obj.from_].add(obj)
            for o in obj.to:
                self._map_relation_rev[o].add(obj)

        if isinstance(obj, spdx30.security_Vulnerability):
            cve_id = vuln_get_cve_id(obj)
            if cve_id:
                self._map_cve_vulns[cve_id].add(obj)

        return super().add(obj)

    @staticmethod
    def _remove_from_relation_map(
        rel_map: dict[spdx30.SHACLObject, set[spdx30.Relationship]],
        key: spdx30.SHACLObject,
        val: spdx30.Relationship,
    ) -> None:
        rels = rel_map.get(key)
        if rels:
            rels.discard(val)
            if rels:
                del rel_map[key]

    def _remove(self, obj: spdx30.SHACLObject) -> None:
        if not isinstance(obj, spdx30.Relationship):
            raise TypeError(f"Removing this kind of object is not supported: {obj}")

        self._remove_from_relation_map(self._map_relation, obj.from_, obj)
        for o in obj.to:
            self._remove_from_relation_map(self._map_relation_rev, o, obj)

        self.objects.discard(obj)

    def remove(self, obj: spdx30.SHACLObject) -> None:
        self._remove(obj)
        self.create_index()

    def iterate_builds(self) -> Generator[spdx30.build_Build, None, None]:
        yield from self.foreach_type(spdx30.build_Build)

    def iterate_install_packages(
        self,
    ) -> Generator[spdx30.software_Package, None, None]:
        return (
            p
            for p in self.foreach_type(spdx30.software_Package)
            if p.software_primaryPurpose == spdx30.software_SoftwarePurpose.install
        )

    def find_package_by_cpe(
        self, cpe: str
    ) -> Generator[spdx30.software_Package, None, None]:
        for p in self.foreach_type(spdx30.software_Package):
            for e in p.externalIdentifier:
                if e.identifier == cpe:
                    yield p

    def find_package_by_name(
        self, name: str
    ) -> Generator[spdx30.software_Package, None, None]:
        for p in self.foreach_type(spdx30.software_Package):
            if p.name == name:
                yield p

    @staticmethod
    def list_cpe23(element: spdx30.Element) -> set[Cpe23]:
        cpes = set()
        for e in element.externalIdentifier:
            if e.externalIdentifierType == spdx30.ExternalIdentifierType.cpe23:
                cpe = Cpe23.parse(e.identifier)
                if cpe is not None:
                    cpes.add(cpe)
        return cpes

    def get_package_vulns(
        self, pkg: spdx30.software_Package
    ) -> dict[
        spdx30.security_Vulnerability, set[spdx30.security_VulnAssessmentRelationship]
    ]:
        """Get the list of Vulnerability associated with this package"""
        return self._map_pkg_vulns.get(pkg, {})

    def get_package_vuln(
        self, pkg: spdx30.software_Package, cve_id: str
    ) -> tuple[
        spdx30.security_Vulnerability | None,
        set[spdx30.security_VulnAssessmentRelationship],
    ]:
        """Get the Vulnerability, associated with this package, with this CVE id"""
        for vuln, rels in self._map_pkg_vulns.get(pkg, {}).items():
            if vuln_get_cve_id(vuln) == cve_id:
                return vuln, rels
        return None, set()

    def get_all_vulns(
        self,
    ) -> dict[
        spdx30.security_Vulnerability,
        dict[spdx30.software_Package, set[spdx30.security_VulnAssessmentRelationship]],
    ]:
        """
        Get the list of all Vulnerabilities, with associated packages and assessments
        """
        vulns: dict[
            spdx30.security_Vulnerability,
            dict[
                spdx30.software_Package, set[spdx30.security_VulnAssessmentRelationship]
            ],
        ] = {}
        for pkg, vulns_rels in self._map_pkg_vulns.items():
            for vuln, rels in vulns_rels.items():
                pkgs_rels = vulns.setdefault(vuln, {})
                pkgs_rels.setdefault(pkg, set()).update(rels)

        return vulns

    def get_package_vuln_assessment_rels(
        self, pkg: spdx30.software_Package, vuln: spdx30.security_Vulnerability
    ) -> set[spdx30.security_VulnAssessmentRelationship] | None:
        """
        Get the vulnerability assessment relationships associated with a package and a
        vulnerability.
        :return: None if there is no relationship between this package and this
        vulnerability
        """
        vulns_rels = self._map_pkg_vulns.get(pkg)
        if vulns_rels:
            return vulns_rels.get(vuln)
        return None

    def get_build_recipe_packages(
        self, build_recipe: spdx30.build_Build
    ) -> set[spdx30.software_Package]:
        pkgs: set[spdx30.software_Package] = set()
        for rel in self._map_relation.get(build_recipe, []):
            if (
                isinstance(rel, spdx30.LifecycleScopedRelationship)
                and rel.relationshipType == spdx30.RelationshipType.hasOutput
            ):
                for pkg in rel.to:
                    if (
                        isinstance(pkg, spdx30.software_Package)
                        and pkg.software_primaryPurpose
                        == spdx30.software_SoftwarePurpose.install
                    ):
                        pkgs.add(pkg)
        return pkgs

    def get_build_recipe_sources(
        self, build_recipe: spdx30.build_Build
    ) -> set[spdx30.software_SoftwareArtifact]:
        pkg_sources: set[spdx30.software_SoftwareArtifact] = set()
        for rel in self._map_relation.get(build_recipe, []):
            if (
                isinstance(rel, spdx30.LifecycleScopedRelationship)
                and rel.relationshipType == spdx30.RelationshipType.hasInput
            ):
                for pkg_src_o in rel.to:
                    if (
                        isinstance(pkg_src_o, spdx30.software_SoftwareArtifact)
                        and pkg_src_o.software_primaryPurpose
                        == spdx30.software_SoftwarePurpose.source
                    ):
                        pkg_sources.add(pkg_src_o)
        return pkg_sources

    @classmethod
    def _get_namespace(cls, pn: str) -> str:
        namespace_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, cls.SPDX_UUID_NAMESPACE)
        return f"{cls.SPDX_NAMESPACE_PREFIX}/{uuid.uuid5(namespace_uuid, pn)!s}"

    @classmethod
    def new_spdxid(cls, *suffix: str, pn: str) -> str:
        items = [cls._get_namespace(pn)]
        items.extend(re.sub(r"[^a-zA-Z0-9_-]", "_", s) for s in suffix)
        return "/".join(items)

    @classmethod
    def new_agent(
        cls,
        *,
        pn: str,
        agent_type: str,
        name: str,
        comment: str | None = None,
        creation_info: spdx30.CreationInfo | None = None,
    ) -> spdx30.Agent:
        spdxid = cls.new_spdxid("agent", name, pn=pn)

        if agent_type == "person":
            agent = spdx30.Person(_id=spdxid, name=name)
        elif agent_type == "software":
            agent = spdx30.SoftwareAgent(_id=spdxid, name=name)
        elif agent_type == "organization":
            agent = spdx30.Organization(_id=spdxid, name=name)
        elif not agent_type or agent_type == "agent":
            agent = spdx30.Agent(_id=spdxid, name=name)
        else:
            raise ValueError(f"Unknown agent type: {agent_type}")

        if creation_info is not None:
            agent.creationInfo = creation_info
        if comment:
            agent.comment = comment

        return agent

    @classmethod
    def new_tool(
        cls, *, pn: str, name: str, creation_info: spdx30.CreationInfo = None
    ) -> spdx30.Tool:
        tool = spdx30.Tool(_id=cls.new_spdxid("tool", name, pn=pn), name=name)
        if creation_info is not None:
            tool.creationInfo = creation_info
        return tool

    @staticmethod
    def new_creation_info(
        *, tools: list[spdx30.Tool], agents: list[spdx30.Agent]
    ) -> spdx30.CreationInfo:
        creation_info = spdx30.CreationInfo()

        for tool in tools:
            if not tool.creationInfo:
                tool.creationInfo = creation_info

        for agent in agents:
            if not agent.creationInfo:
                agent.creationInfo = creation_info

        creation_info.created = ReproducibleDateTime().now
        creation_info.specVersion = SPDX_VERSION
        creation_info.createdBy = agents
        creation_info.createdUsing = tools

        return creation_info

    @classmethod
    def new_objset(cls, name: str) -> "ObjectSet":
        object_set = cls()

        document = spdx30.SpdxDocument(
            _id=object_set.new_spdxid("document", pn=name),
            name=name,
        )

        document.profileConformance = [
            spdx30.ProfileIdentifierType.build,
            spdx30.ProfileIdentifierType.core,
            spdx30.ProfileIdentifierType.security,
            spdx30.ProfileIdentifierType.simpleLicensing,
            spdx30.ProfileIdentifierType.software,
        ]

        object_set._doc = document
        object_set.add(document)

        return object_set

    def set_doc_creation_info(self, creation_info: spdx30.CreationInfo) -> None:
        for tool in creation_info.createdUsing:
            self.add(tool)

        for agent in creation_info.createdBy:
            self.add(agent)

        self.add(creation_info)
        assert self._doc is not None
        self._doc.creationInfo = creation_info

    @property
    def doc_creation_info(self) -> spdx30.CreationInfo:
        assert self._doc is not None
        return self._doc.creationInfo

    def add_sbom_as_doc_root_element(self, name: str) -> None:
        assert self._sbom is None
        self._sbom = spdx30.software_Sbom(
            _id=self.new_spdxid("sbom", pn=name),
            name=name,
            creationInfo=self.doc_creation_info,
            software_sbomType=[spdx30.software_SbomType.build],
        )

        self.add(self._sbom)
        assert self._doc is not None
        self._doc.rootElement = [self._sbom]

    def add_sbom_root_element(self, e: spdx30.Element) -> None:
        assert self._sbom is not None
        self._sbom.rootElement.append(e)

    def _new_relationship(
        self,
        cls: type[_RelationshipT],
        from_: ListLikeSHACLObject,
        typ: str,
        to: ListLikeSHACLObject,
        *,
        pn: str,
        spdxid_name: str = "relationship",
        **props: object,
    ) -> list[_RelationshipT]:
        from_ = to_list(from_)
        to = to_list(to)

        if not from_:
            return []

        if not to:
            to = [spdx30.IndividualElement.NoneElement]

        ret = []

        for f in from_:
            hash_args: list[object] = [typ, f]
            for _, p in sorted(props.items(), key=lambda t: t[0]):
                hash_args.append(p)
            hash_args.extend(to)

            relationship = self.add(
                cls(
                    _id=self.new_spdxid(spdxid_name, spdxid_hash(*hash_args), pn=pn),
                    creationInfo=self.doc_creation_info,
                    from_=f,
                    relationshipType=typ,
                    to=to,
                    **props,
                )
            )
            ret.append(relationship)

        return ret

    def new_relationship(
        self, from_: ListLikeSHACLObject, typ: str, to: ListLikeSHACLObject, *, pn: str
    ) -> list[spdx30.Relationship]:
        return self._new_relationship(spdx30.Relationship, from_, typ, to, pn=pn)

    def new_scoped_relationship(
        self,
        from_: ListLikeSHACLObject,
        typ: str,  # RelationshipType
        scope: str,  # LifecycleScopeType
        to: ListLikeSHACLObject,
        *,
        pn: str,
    ) -> list[spdx30.LifecycleScopedRelationship]:
        return self._new_relationship(
            spdx30.LifecycleScopedRelationship, from_, typ, to, scope=scope, pn=pn
        )

    def update_cve_vuln(
        self, vuln: spdx30.security_Vulnerability, cve_info: CveInfo
    ) -> None:
        updated = False

        # Update description
        if cve_info.description and (vuln.description != cve_info.description):
            vuln.description = cve_info.description
            updated = True

        # Add new external references
        map_ext_refs = {}
        for ext_ref in cve_info.references:
            map_ext_refs[ext_ref.url] = ext_ref

        for ext_ref in vuln.externalRef:
            for locator in ext_ref.locator:
                map_ext_refs.pop(locator, None)

        for ext_ref in map_ext_refs.values():
            props = (
                {}
                if ext_ref.ref_type is None
                else {"externalRefType": ext_ref.ref_type}
            )
            vuln.externalRef.append(spdx30.ExternalRef(locator=[ext_ref.url], **props))
            updated = True

        # Update last modification date time
        if cve_info.date_modified is not None:
            date_modified = cve_info.date_modified.astimezone(UTC)
            if date_modified != vuln.security_modifiedTime:
                vuln.security_modifiedTime = date_modified
                updated = True

        # Update published date time
        if cve_info.date_published is not None:
            date_published = cve_info.date_published.astimezone(UTC)
            if date_published != vuln.security_publishedTime:
                vuln.security_publishedTime = date_published
                updated = True

        if updated:
            vuln.creationInfo = self.doc_creation_info

    def new_cve_vuln(
        self, cve_info: CveInfo, *, pn: str
    ) -> spdx30.security_Vulnerability:
        cve_id = cve_info.cve_id.id
        vuln = spdx30.security_Vulnerability(
            _id=self.new_spdxid("vulnerability", cve_id, pn=pn)
        )
        vuln.creationInfo = self.doc_creation_info
        if cve_info.description is not None:
            vuln.description = cve_info.description

        if cve_info.date_modified is not None:
            vuln.security_modifiedTime = cve_info.date_modified.astimezone(UTC)

        if cve_info.date_published is not None:
            vuln.security_publishedTime = cve_info.date_published.astimezone(UTC)

        vuln.externalIdentifier.append(
            spdx30.ExternalIdentifier(
                externalIdentifierType=spdx30.ExternalIdentifierType.cve,
                identifier=cve_id,
                identifierLocator=[
                    f"https://cveawg.mitre.org/api/cve/{cve_id}",
                    f"https://www.cve.org/CVERecord?id={cve_id}",
                ],
            )
        )

        for ext_ref in cve_info.references:
            props = (
                {}
                if ext_ref.ref_type is None
                else {"externalRefType": ext_ref.ref_type}
            )
            vuln.externalRef.append(spdx30.ExternalRef(locator=[ext_ref.url], **props))

        return vuln

    @staticmethod
    def _props_for_vex_assessment(assessment: CveVexAssessment) -> dict[str, Any]:
        props: dict[str, Any] = {}

        if assessment.vex_version is not None:
            props["security_vexVersion"] = assessment.vex_version
        if assessment.status_notes is not None:
            props["security_statusNotes"] = assessment.status_notes

        if isinstance(assessment, CveVexAffectedAssessment):
            props["security_actionStatement"] = assessment.action_statement
            if assessment.action_statement_time is not None:
                props["security_actionStatementTime"] = (
                    assessment.action_statement_time.astimezone(tz=UTC)
                )

        elif isinstance(assessment, CveVexNotAffectedAssessment):
            props["security_impactStatement"] = assessment.impact_statement
            if assessment.impact_statement_time is not None:
                props["security_impactStatementTime"] = (
                    assessment.impact_statement_time.astimezone(tz=UTC)
                )
            if assessment.justification is not None:
                props["security_justificationType"] = (
                    spdx30.security_VexJustificationType.NAMED_INDIVIDUALS[
                        cve_vex_justification_to_str(assessment.justification)
                    ]
                )

        return props

    def update_vex_assessment_relationship(
        self,
        rel: spdx30.security_VexVulnAssessmentRelationship,
        assessment: CveVexAssessment,
    ) -> None:
        props = self._props_for_vex_assessment(assessment)
        if props:
            updated = False
            for key, val in props.items():
                if getattr(rel, key) != val:
                    setattr(rel, key, val)
                    updated = True

            if updated:
                rel.creationInfo = self.doc_creation_info

    def new_vex_assessment_relationship(
        self,
        from_: ListLikeSHACLObject,
        to: ListLikeSHACLObject,
        assessment: CveVexAssessment,
        *,
        pn: str,
    ) -> list[spdx30.security_VexVulnAssessmentRelationship]:
        if isinstance(assessment, CveVexFixedAssessment):
            cls = spdx30.security_VexFixedVulnAssessmentRelationship
            rel_typ = spdx30.RelationshipType.fixedIn
            spdxid_name = "vex-fixed"

        elif isinstance(assessment, CveVexAffectedAssessment):
            cls = spdx30.security_VexAffectedVulnAssessmentRelationship
            rel_typ = spdx30.RelationshipType.affects
            spdxid_name = "vex-affected"

        elif isinstance(assessment, CveVexNotAffectedAssessment):
            cls = spdx30.security_VexNotAffectedVulnAssessmentRelationship
            rel_typ = spdx30.RelationshipType.doesNotAffect
            spdxid_name = "vex-not-affected"

        elif isinstance(assessment, CveVexUnderInvestigationAssessment):
            cls = spdx30.security_VexUnderInvestigationVulnAssessmentRelationship
            rel_typ = spdx30.RelationshipType.underInvestigationFor
            spdxid_name = "vex-under-invest"

        else:
            raise TypeError(f"Unexpected assessment type: {assessment.status}")

        props = self._props_for_vex_assessment(assessment)

        return self._new_relationship(
            cls, from_, rel_typ, to, spdxid_name=spdxid_name, **props, pn=pn
        )

    def new_cvss_vuln_assessment_relationship(
        self,
        from_: ListLikeSHACLObject,
        to: ListLikeSHACLObject,
        cvss_metric: CvssMetric,
        *,
        pn: str,
    ) -> list[spdx30.security_VulnAssessmentRelationship]:
        if cvss_metric.cvss_ver == CvssVersion.V2_0:
            cls = spdx30.security_CvssV2VulnAssessmentRelationship
        elif cvss_metric.cvss_ver in (CvssVersion.V3_0, CvssVersion.V3_1):
            cls = spdx30.security_CvssV3VulnAssessmentRelationship
        elif cvss_metric.cvss_ver == CvssVersion.V4_0:
            cls = spdx30.security_CvssV4VulnAssessmentRelationship
        else:
            raise ValueError(f"Unexpected CVSS version: {cvss_metric.cvss_ver}")

        props = {}
        if cvss_metric.cvss_ver != CvssVersion.V2_0:
            assert cvss_metric.severity is not None
            props["security_severity"] = (
                spdx30.security_CvssSeverityType.NAMED_INDIVIDUALS[
                    cvss_metric.severity.value
                ]
            )

        if cvss_metric.source is not None:
            props["comment"] = cvss_metric.source

        return self._new_relationship(
            cls,
            from_,
            spdx30.RelationshipType.hasAssessmentFor,
            to,
            spdxid_name=f"cvss-{cvss_metric.cvss_ver.name}",
            security_score=cvss_metric.score,
            security_vectorString=cvss_metric.vector_str,
            **props,
            pn=pn,
        )

    def _create_vex_vuln_assessment_relationship(
        self,
        package: spdx30.software_Package,
        vuln: spdx30.security_Vulnerability,
        assessment: CveVexAssessment,
        rels: set[spdx30.security_VulnAssessmentRelationship],
    ) -> None:
        vex_rel: spdx30.security_VexVulnAssessmentRelationship | None = None

        # Check current Vex Vulnerability Assessment Relationship
        for r in list(rels):
            a = cve_vex_assessment_from_vuln_relationship(r)
            if a is None:
                continue
            if (a.status == assessment.status) and (vex_rel is None):
                # Ok, only need to update properties
                vex_rel = cast("spdx30.security_VexVulnAssessmentRelationship", r)
                self.update_vex_assessment_relationship(vex_rel, assessment)
            else:
                # The status changed, or there is a duplicated relationship,
                # need to destroy this old relationship
                self.remove(r)
                rels.discard(r)

        # If there was already a relationship with the appropriate status, return
        if vex_rel is not None:
            return

        # Create a new Vex Vulnerability Assessment Relationship
        vex_rel = self.new_vex_assessment_relationship(
            from_=[vuln], to=[package], assessment=assessment, pn=package.name
        )[0]
        self.add(vex_rel)
        rels.add(vex_rel)

    def _cleanup_cvss_vuln_assessment_relationship(
        self,
        cvss_metrics: Iterable[CvssMetric],
        rels: set[spdx30.security_VulnAssessmentRelationship],
        remove_old_metrics: bool,
    ) -> list[CvssMetric]:
        def _sort_rel(rel: spdx30.security_VulnAssessmentRelationship) -> int:
            return len(rel.comment or "")

        # Build a lookup between the CVSS key and the CVSS relationship
        metrics_doc: dict[
            tuple[Any, ...],
            list[spdx30.security_VulnAssessmentRelationship],
        ] = defaultdict(list)

        for r in rels:
            m_from_r = cvss_metric_from_vuln_relationship(r)
            if m_from_r:
                metrics_doc[m_from_r.cmp_key()].append(r)

        # Only append new metrics
        if not remove_old_metrics:
            return [m for m in cvss_metrics if (m.cmp_key() not in metrics_doc)]

        # Remove old metrics if different that new ones
        metrics_to_add: list[CvssMetric] = []
        for new_m in cvss_metrics:
            old_rels = metrics_doc.pop(new_m.cmp_key(), None)
            if not old_rels:
                metrics_to_add.append(new_m)
                continue

            if len(old_rels) == 1:
                continue

            del_rels = iter(sorted(old_rels, key=_sort_rel, reverse=True))
            next(del_rels)
            for r in del_rels:
                self.remove(r)
                rels.discard(r)

        # Remove old metrics left
        for old_rels in metrics_doc.values():
            for r in old_rels:
                self.remove(r)
                rels.discard(r)

        return metrics_to_add

    def create_vex_vuln_assessment_relationship(
        self,
        package: spdx30.software_Package,
        vuln: spdx30.security_Vulnerability,
        assessment: CveVexAssessment,
    ) -> bool:
        # Check if there is already a relation between the package and the vulnerability
        assess_rels = self.get_package_vuln_assessment_rels(package, vuln)
        if assess_rels is None:
            return False

        self._create_vex_vuln_assessment_relationship(
            package, vuln, assessment, assess_rels
        )
        return True

    def _create_cvss_vuln_assessment_relationship(
        self,
        package: spdx30.software_Package,
        vuln: spdx30.security_Vulnerability,
        cvss_metric: CvssMetric,
        rels: set[spdx30.security_VulnAssessmentRelationship],
    ) -> None:
        # Create a new CVSS Vulnerability Assessment Relationship
        r = self.new_cvss_vuln_assessment_relationship(
            from_=[vuln], to=[package], cvss_metric=cvss_metric, pn=package.name
        )[0]
        self.add(r)
        rels.add(r)

    def create_cvss_vuln_assessment_relationship(
        self,
        package: spdx30.software_Package,
        vuln: spdx30.security_Vulnerability,
        cvss_metric: CvssMetric,
    ) -> bool:
        # Check if there is already a relation between the package and the vulnerability
        assess_rels = self.get_package_vuln_assessment_rels(package, vuln)
        if assess_rels is None:
            return False

        self._create_cvss_vuln_assessment_relationship(
            package, vuln, cvss_metric, assess_rels
        )
        return True

    def add_cve_vulnerability(
        self,
        package: spdx30.software_Package,
        cve_info: CveInfo,
        *,
        update_vuln_info: bool = True,
        remove_old_metrics: bool = True,
    ) -> None:
        # Check if this CVE already exists
        vulns_rels = self._map_pkg_vulns[package]
        vulns_cve_id = self._map_cve_vulns[cve_info.cve_id.id]
        if not vulns_cve_id:
            # Create new CVE entry
            vuln = self.new_cve_vuln(cve_info, pn=package.name)
            self.add(vuln)
        else:
            # If there are duplicate CVE objects, try to find the right one
            # Otherwise use the first one that was found.
            if len(vulns_cve_id) == 1:
                vuln = next(iter(vulns_cve_id))
            else:
                for v in vulns_cve_id:
                    if v in vulns_rels:
                        vuln = v
                        break
                else:
                    vuln = next(iter(vulns_cve_id))

            if update_vuln_info:
                # Update CVE information using the ones provided in input
                self.update_cve_vuln(vuln, cve_info)

        # Search for a previous hasAssociatedVulnerability relationship,
        # and create it if not already exists
        assess_rels = vulns_rels.get(vuln)
        if assess_rels is None:
            for r in self._map_relation.get(package, []):
                if (
                    r.relationshipType
                    == spdx30.RelationshipType.hasAssociatedVulnerability
                ):
                    r.to.append(vuln)
                    r.creationInfo = self.doc_creation_info
                    break
            else:
                r = self.new_relationship(
                    from_=[package],
                    typ=spdx30.RelationshipType.hasAssociatedVulnerability,
                    to=[vuln],
                    pn=package.name,
                )[0]
                self.add(r)
            assess_rels = set()
            vulns_rels[vuln] = assess_rels

        # Create or update Vulnerability Assessment Relationships
        vex_assess = cve_info.vex_assessment
        if vex_assess is not None:
            self._create_vex_vuln_assessment_relationship(
                package, vuln, vex_assess, assess_rels
            )

        cvss_metrics = self._cleanup_cvss_vuln_assessment_relationship(
            cve_info.cvss_metrics, assess_rels, remove_old_metrics
        )
        for cvss_metric in cvss_metrics:
            self._create_cvss_vuln_assessment_relationship(
                package, vuln, cvss_metric, assess_rels
            )

    def remove_all_cve_vulnerability(self, cve_id: str) -> None:
        # Check if this CVE exists
        vulns_cve_id = self._map_cve_vulns.get(cve_id)
        if vulns_cve_id is None:
            return

        # For each vulnerability with this CVE identifier
        for vuln in vulns_cve_id:
            # Remove all relationships found associated with this CVE
            for r in list(self._map_relation.get(vuln, [])):
                self._remove(r)
            for r in list(self._map_relation_rev.get(vuln, [])):
                self._remove(r)

            # Update map between package and vulnerabilities
            for vulns_rels in self._map_pkg_vulns.values():
                vulns_rels.pop(vuln, None)

        # Recreate index
        self.create_index()
