# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only
"""
Implements SBOMs in the SPDX3 format.

SPDX3 is an open standard for Bill Of Materials, whose specification can be
found at https://spdx.github.io/spdx-spec/v3.0.1/front/introduction/.
"""

import datetime
import pathlib
from collections.abc import Generator, Iterable
from typing import Any

from spdx_python_model.bindings import v3_0_1 as spdx30  # type: ignore[import-untyped]

from ..cve_db.annot_spdx3 import Spdx3AnnotDatabase
from ..vuln.cpe import Cpe23
from ..vuln.cve import CveId, CveInfo
from .component import CompBuild, CompId, Component, CompType, CompVersIds
from .lib_spdx3 import ObjectSet
from .registry import register_sbom
from .sbom_base import Sbom


class Spdx3Component(Component):
    def __init__(self, objset: ObjectSet, pkg: spdx30.software_Package) -> None:
        self._objset = objset
        self._pkg = pkg

    @property
    def spdx_package(self) -> spdx30.software_Package:
        return self._pkg

    @property
    def name(self) -> str:
        return str(self._pkg.name)

    @property
    def version(self) -> str | None:
        for cpe in ObjectSet.list_cpe23(self._pkg):
            if isinstance(cpe.version, str):
                return cpe.version
        v = self._pkg.software_packageVersion
        return str(v) if v else None

    @property
    def supplier(self) -> str | None:
        for created_by in self._pkg.creationInfo.createdBy:
            if created_by.name:
                return str(created_by.name)
        return None

    @property
    def comp_type(self) -> CompType | None:
        for cpe in ObjectSet.list_cpe23(self._pkg):
            if cpe.part == "o":
                return CompType.OS
            if cpe.part == "a":
                return CompType.APPLICATION
        return None

    @property
    def identifiers(self) -> set[CompId]:
        comp_ids: set[CompId] = set()
        for cpe in ObjectSet.list_cpe23(self._pkg):
            comp_id = CompId.build_from_cpe(cpe)
            if comp_id is not None:
                comp_ids.add(comp_id)
        return comp_ids

    @property
    def cpes(self) -> set[Cpe23]:
        return ObjectSet.list_cpe23(self._pkg)

    @property
    def description(self) -> str | None:
        d = self._pkg.description
        return d if isinstance(d, str) else None

    def add_cve_vulnerability(
        self, cve_info: CveInfo, *, update_vuln_info: bool = True
    ) -> None:
        self._objset.add_cve_vulnerability(
            self._pkg, cve_info, update_vuln_info=update_vuln_info
        )


class Spdx3CompBuild(CompBuild):
    def __init__(
        self,
        vers_ids: CompVersIds,
        comps: Iterable[Component],
        objset: ObjectSet,
        build_obj: spdx30.build_Build,
    ) -> None:
        super().__init__(vers_ids, comps)
        self._objset = objset
        self._build = build_obj

    @property
    def build_name(self) -> str | None:
        name: str | None = self._build.name
        if (
            name
            and self._build.build_buildType
            and self._build.build_buildType.startswith(
                "http://openembedded.org/bitbake"
            )
        ):
            return name.split(":", 1)[0]
        return name

    def _get_compiled_sources(self) -> set[str]:
        sources: set[str] = set()
        for artifact in self._objset.get_build_recipe_sources(self._build):
            if isinstance(artifact, spdx30.software_File):
                path: str = artifact.name
                if path:
                    sources.add(path)
        return sources


@register_sbom("spdx3")
class Spdx3Sbom(Sbom):
    @classmethod
    def can_handle_sbom(cls, path: pathlib.Path) -> bool:
        return path.name.endswith(".spdx.json")

    def __init__(self, path: pathlib.Path) -> None:
        super().__init__(path)
        self._objset: ObjectSet = ObjectSet.parse_jsonld(path)

    def create_annot_database(self, **kwargs: Any) -> Spdx3AnnotDatabase | None:
        return Spdx3AnnotDatabase(path=None, objset=self._objset, **kwargs)

    def iterate_component_builds(self) -> Generator[CompBuild, None, None]:
        for build_obj in sorted(self._objset.iterate_builds(), key=lambda b: b.name):
            comps = (
                Spdx3Component(self._objset, pkg)
                for pkg in self._objset.get_build_recipe_packages(build_obj)
            )
            for vers_id, group in CompBuild.group_components_by_id(comps).items():
                yield Spdx3CompBuild(vers_id, group, self._objset, build_obj)

    @property
    def supplier(self) -> str | None:
        return None

    @property
    def timestamp(self) -> datetime.datetime | None:
        return None

    def update_sbom_generation_tools(self) -> None:
        tool_name = "sbom-cve-check"
        agent = self._objset.new_agent(
            pn=tool_name, agent_type="software", name=tool_name
        )
        tool = self._objset.new_tool(pn=tool_name, name=tool_name)
        creation_info = self._objset.new_creation_info(tools=[tool], agents=[agent])
        self._objset.set_doc_creation_info(creation_info)

    def write_to_file(self, path_sbom: str | pathlib.Path) -> None:
        self._objset.write_to_jsonld(path_sbom)

    def remove_all_cve_vulnerability(self, cve_id: CveId) -> None:
        self._objset.remove_all_cve_vulnerability(cve_id.id)
