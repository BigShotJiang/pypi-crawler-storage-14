# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only
"""
Implements the generic Software Bill Of Materials (SBOM) class.

The actual logic should live in a child class, such as e.g. Spdx3Sbom.
"""

import abc
import datetime
import logging
import pathlib
from collections.abc import Generator
from typing import Any

from ..cve_db.annot_base import AnnotDatabase
from ..vuln.cve import CveId
from .component import CompBuild

_logger = logging.getLogger(__name__)


class Sbom(abc.ABC):
    def __init__(self, path: pathlib.Path) -> None:
        self._sbom_path = path

    @classmethod
    @abc.abstractmethod
    def can_handle_sbom(cls, path: pathlib.Path) -> bool:
        """
        Indicates if this class can process/handle this SBOM file
        """

    def create_annot_database(self, **kwargs: Any) -> AnnotDatabase | None:
        """
        :return: If the SBOM contains CVE annotations, return associated annotation
        database
        """
        return None

    @property
    @abc.abstractmethod
    def supplier(self) -> str | None:
        """
        Provides the name of an entity that creates, defines, and identifies components
        :return: supplier name or None
        """

    @property
    @abc.abstractmethod
    def timestamp(self) -> datetime.datetime | None:
        """:return: The record of the date and time of the SBOM data assembly"""

    @abc.abstractmethod
    def iterate_component_builds(self) -> Generator[CompBuild, None, None]:
        """
        Provide each SBOM component build object. This object contains the various
        components that were built using the same "recipe". These components must share
        the same component identifiers and version.
        """

    def update_sbom_generation_tools(self) -> None:
        """Update agents and tools used to generate and write this new SBOM"""
        raise NotImplementedError

    def write_to_file(self, path_sbom: str | pathlib.Path) -> None:
        """Write SBOM to disk. The path should be a path to a file"""
        raise NotImplementedError

    def remove_all_cve_vulnerability(self, cve_id: CveId) -> None:
        """Remove all CVE vulnerabilities with this id and associated assessments"""
        raise NotImplementedError
