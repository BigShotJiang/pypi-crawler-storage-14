# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

__version__ = "1.0"
