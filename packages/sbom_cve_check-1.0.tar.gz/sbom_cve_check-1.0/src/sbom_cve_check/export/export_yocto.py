# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import json
import pathlib
from collections.abc import Generator
from datetime import UTC
from typing import Any

from ..cve_db.annot_aggregate import AggregateAnnotEntry
from ..sbom.component import CompBuild
from ..sbom.sbom_base import Sbom
from ..vuln.cve import CveVexStatus
from ..vuln.cvss import CvssMetric, CvssVersion
from .export_base import BaseExport
from .registry import register_export


def _group_cvss_metrics_by_vers(metric: CvssMetric) -> CvssVersion:
    return (
        CvssVersion.V3_0 if (metric.cvss_ver == CvssVersion.V3_1) else metric.cvss_ver
    )


def _get_cvss_metric_score(
    metrics: dict[CvssVersion, tuple[CvssMetric, ...]], vers: CvssVersion
) -> str:
    m = metrics.get(vers)
    return f"{m[0].score:.1f}" if m else "0.0"


def _get_modified_date(annotation: AggregateAnnotEntry) -> str | None:
    d = annotation.date_modified
    if d:
        return d.astimezone(UTC).replace(tzinfo=None).isoformat(timespec="milliseconds")
    return None


def _get_cve_status(annotation: AggregateAnnotEntry) -> str | None:
    s = annotation.vex_assessment.status
    if s == CveVexStatus.FIXED:
        return "Patched"
    if s in (CveVexStatus.AFFECTED, CveVexStatus.UNDER_INVESTIGATION):
        return "Unpatched"
    if s == CveVexStatus.NOT_AFFECTED:
        return "Ignored"
    return None


def _gen_issue_info(annotation: AggregateAnnotEntry) -> dict[str, str | None]:
    metrics = annotation.group_cvss_metrics(key=_group_cvss_metrics_by_vers)
    metric_vector = (
        metrics.get(CvssVersion.V4_0)
        or metrics.get(CvssVersion.V3_0)
        or metrics.get(CvssVersion.V2_0)
    )
    attack_vector = "UNKNOWN"
    vector_str = None
    if metric_vector:
        vector_str = metric_vector[0].vector_str
        enum_av = metric_vector[0].decode_vector().get("AV")
        if enum_av is not None:
            attack_vector = enum_av.name

    return {
        "id": annotation.identifier.id,
        "status": _get_cve_status(annotation),
        "link": f"https://nvd.nist.gov/vuln/detail/{annotation.identifier.id}",
        "summary": annotation.description or "",
        "scorev2": _get_cvss_metric_score(metrics, CvssVersion.V2_0),
        "scorev3": _get_cvss_metric_score(metrics, CvssVersion.V3_0),
        "scorev4": _get_cvss_metric_score(metrics, CvssVersion.V4_0),
        "modified": _get_modified_date(annotation),
        "vector": attack_vector,
        "vectorString": vector_str,
        "detail": annotation.vex_assessment.status_notes,
    }


@register_export("yocto-cve-check-manifest")
class YoctoCveCheckExport(BaseExport):
    def __init__(self, sbom: Sbom, out_path: pathlib.Path) -> None:
        super().__init__(sbom, out_path)
        self._packages: list[dict[str, Any]] = []

    def start_export(self) -> Generator[None, None, None]:
        yield
        json_obj = {"version": 1, "package": self._packages}
        with self._out_path.open("w", encoding="utf-8") as f:
            json.dump(json_obj, f, indent=2)

    def export_comp_info(
        self, comp_build: CompBuild
    ) -> Generator[None, tuple[bool, AggregateAnnotEntry], None]:
        issues = []
        try:
            while True:
                is_filtered, annotation = yield
                if not is_filtered:
                    issues.append(_gen_issue_info(annotation))
        finally:
            cves_in_rec = "Yes" if issues else "No"

            self._packages.append(
                {
                    "name": comp_build.build_name,
                    "layer": "",
                    "version": comp_build.version,
                    "products": [
                        {"product": n, "cvesInRecord": cves_in_rec}
                        for n in sorted({c.name for c in comp_build.identifiers})
                    ],
                    "issue": issues,
                    "cpes": [
                        str(c.build_cpe(version=comp_build.version))
                        for c in comp_build.identifiers
                    ],
                }
            )
