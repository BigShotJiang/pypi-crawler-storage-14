# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import contextlib
import logging
from collections.abc import Generator, Iterable

from ..cve_db.annot_aggregate import AggregateAnnotEntry
from ..cve_db.manager import CveDbManager
from ..sbom.sbom_base import Sbom
from ..vuln.cve import (
    CveVexMissingVersionsAssessment,
    CveVexRejectedAssessment,
    CveVexStatus,
)
from .export_base import BaseExport

_logger = logging.getLogger(__name__)


class ExportManager:
    def __init__(self, sbom: Sbom, cve_db_manager: CveDbManager) -> None:
        self._sbom = sbom
        self._manager = cve_db_manager
        self._exports: list[BaseExport] = []
        self._filter_rejected_cve: bool = True
        self._filter_status: tuple[CveVexStatus, ...] | None = None
        self._filter_no_cvss_score: bool = False
        self._filter_cvss_score: float | None = None
        self._filter_missing_versions: bool = False
        self._add_kernel_modules: bool = False

    def cfg_filter_rejected_cve(self, enable: bool) -> None:
        """If enable is true, do not export rejected CVE (which is the default)"""
        self._filter_rejected_cve = enable

    def cfg_filter_status(self, status: Iterable[CveVexStatus]) -> None:
        """
        Allow to configure export filter, to only export CVEs with specific VEX status
        """
        self._filter_status = tuple(status)

    def cfg_filter_no_cvss_score(self, enable: bool) -> None:
        """If enable is true, do not export CVE with missing CVSS score"""
        self._filter_no_cvss_score = enable

    def cfg_filter_cvss_score(self, threshold: float | None) -> None:
        """
        Only export CVE with CVSS score greater or equal to the specified threshold
        """
        self._filter_cvss_score = threshold

    def cfg_filter_missing_versions(self, enable: bool) -> None:
        """
        If enable is true, do not export CVE with missing version ranges information
        """
        self._filter_missing_versions = enable

    def cfg_add_kernel_modules(self, enable: bool) -> None:
        """If enable is true, add CVE annotations to all kernel modules"""
        self._add_kernel_modules = enable

    def _is_cve_filtered(self, annotation: AggregateAnnotEntry) -> bool:
        """Allow to check if this CVE needs to be exported"""
        assessment = annotation.vex_assessment

        if self._filter_rejected_cve and isinstance(
            assessment, CveVexRejectedAssessment
        ):
            return True

        if self._filter_status and (assessment.status not in self._filter_status):
            return True

        if self._filter_missing_versions and isinstance(
            assessment, CveVexMissingVersionsAssessment
        ):
            return True

        if self._filter_no_cvss_score and (not annotation.cvss_metrics):
            return True

        return bool(
            self._filter_cvss_score is not None
            and not any(
                metric.score >= self._filter_cvss_score
                for metric in annotation.cvss_metrics
            )
        )

    def add_exporter(self, e: BaseExport) -> None:
        """
        Add an exporter.

        Each exporter should generate an output (file, or something on stdout, ...)
        """
        self._exports.append(e)

    def process_export(self) -> None:
        """
        Process the export, use as input the SBOM to extract the components, and
        then for each component get applicable CVE.
        """

        main_gens: dict[BaseExport, Generator[None, None, None]] = {}

        for e in self._exports:
            _logger.info("Starting the export to %s", e.output_path.name)
            e.cfg_add_kernel_modules(self._add_kernel_modules)
            main_gen = e.start_export()
            next(main_gen)
            main_gens[e] = main_gen

        for comp_build in self._sbom.iterate_component_builds():
            _logger.info("Processing build: %s", comp_build.build_name)
            # Initialize generator
            gens: list[Generator[None, tuple[bool, AggregateAnnotEntry], None]] = []
            for e in self._exports:
                with contextlib.suppress(StopIteration):
                    gen = e.export_comp_info(comp_build)
                    next(gen)
                    gens.append(gen)

            # Export each annotation
            for annotation in self._manager.get_applicable_cves(comp_build):
                is_filtered = self._is_cve_filtered(annotation)
                _logger.debug(
                    " - Exporting %s%s",
                    annotation.identifier,
                    "" if is_filtered else " (filtered)",
                )
                for gen in gens:
                    gen.send((is_filtered, annotation))

            # Close generator
            for gen in gens:
                gen.close()

        for e, main_gen in main_gens.items():
            _logger.info("Finalizing the export to %s", e.output_path.name)
            with contextlib.suppress(StopIteration):
                next(main_gen)
