# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import pathlib
from collections.abc import Generator

from ..cve_db.annot_aggregate import AggregateAnnotEntry
from ..sbom.component import CompBuild
from ..sbom.sbom_base import Sbom
from ..sbom.sbom_spdx3 import Spdx3Sbom
from ..vuln.cve import CveInfo, CveVexRejectedAssessment
from .export_base import BaseExport
from .registry import register_export


@register_export("spdx3")
class Spdx3Export(BaseExport):
    """
    Export the CVE information in SPDX3 format.

    This requires having parsed an SPDX3 SBOM as input.
    """

    def __init__(self, sbom: Sbom, out_path: pathlib.Path) -> None:
        super().__init__(sbom, out_path)
        if not isinstance(self._sbom, Spdx3Sbom):
            raise NotImplementedError(
                "Export to SPDX3 is only supported with SPDX3 input file"
            )

    def start_export(self) -> Generator[None, None, None]:
        self._sbom.update_sbom_generation_tools()
        yield
        self._sbom.write_to_file(self._out_path)

    def _cleanup_filtered_cve(self, annotation: AggregateAnnotEntry) -> None:
        if isinstance(annotation.vex_assessment, CveVexRejectedAssessment):
            self._sbom.remove_all_cve_vulnerability(annotation.identifier)

    def export_comp_info(
        self, comp_build: CompBuild
    ) -> Generator[None, tuple[bool, AggregateAnnotEntry], None]:
        while True:
            is_filtered, annotation = yield
            if is_filtered:
                self._cleanup_filtered_cve(annotation)
                continue

            metrics = annotation.group_cvss_metrics(key=lambda x: x.cvss_ver)
            sorted_metrics = sorted(metrics.items(), key=lambda d: d[0].value)
            # noinspection PyTypeChecker
            ext_refs = sorted(annotation.external_refs)

            cve_info = CveInfo(
                cve_id=annotation.identifier,
                date_published=annotation.date_published,
                date_modified=annotation.date_modified,
                description=annotation.description,
                cvss_metrics=[m[0] for _, m in sorted_metrics],
                references=ext_refs,
                vex_assessment=annotation.vex_assessment,
            )

            update_vuln_info = True
            for comp in self._filter_components(comp_build):
                comp.add_cve_vulnerability(cve_info, update_vuln_info=update_vuln_info)
                update_vuln_info = False
