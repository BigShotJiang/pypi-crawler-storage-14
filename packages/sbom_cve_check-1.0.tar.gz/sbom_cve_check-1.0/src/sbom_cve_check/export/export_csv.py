# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import csv
import pathlib
from _csv import Writer
from collections.abc import Generator
from enum import IntEnum

from ..cve_db.annot_aggregate import AggregateAnnotEntry
from ..sbom.component import CompBuild
from ..sbom.sbom_base import Sbom
from ..vuln.cve import CveVexAffectedAssessment, CveVexNotAffectedAssessment
from ..vuln.cvss import CvssMetric, CvssVersion
from .export_base import BaseExport
from .registry import register_export

_CsvRow = list[str | float]


class _Column(IntEnum):
    """
    Map colum names to an integer, to be used for storing the corresponding
    information in the generated CSV's rows.
    Necessary because CSVs are organized as rows of 0-indexed fields, this
    integer will be the column's index in each row.
    """

    BUILD_NAME = 0
    PKG_NAMES = 1
    VERSION = 2
    PRODUCT_NAMES = 3
    CVE_ID = 4
    SCOREV2 = 5
    SCOREV3 = 6
    SCOREV4 = 7
    STATUS = 8
    STATEMENT = 9
    NOTES = 10
    OBSOLETES = 11
    NB_COLS = 12


def _group_cvss_metrics_by_col(metric: CvssMetric) -> _Column | None:
    if metric.cvss_ver == CvssVersion.V2_0:
        return _Column.SCOREV2
    if metric.cvss_ver in (CvssVersion.V3_0, CvssVersion.V3_1):
        return _Column.SCOREV3
    if metric.cvss_ver == CvssVersion.V4_0:
        return _Column.SCOREV4
    return None


def _gen_cve_info(row_common: _CsvRow, annotation: AggregateAnnotEntry) -> _CsvRow:
    row = row_common.copy()
    row[_Column.CVE_ID] = annotation.identifier.id

    for cvss_col, metrics in annotation.group_cvss_metrics(
        key=_group_cvss_metrics_by_col
    ).items():
        if cvss_col is not None:
            row[cvss_col] = metrics[0].score

    assessment = annotation.vex_assessment
    row[_Column.STATUS] = str(assessment.status.value)

    if isinstance(assessment, CveVexAffectedAssessment):
        row[_Column.STATEMENT] = assessment.action_statement
    elif isinstance(assessment, CveVexNotAffectedAssessment):
        row[_Column.STATEMENT] = assessment.impact_statement

    row[_Column.NOTES] = assessment.status_notes or ""
    row[_Column.OBSOLETES] = ";\n".join(str(o) for o in annotation.obsolete_assessments)
    return row


@register_export("csv")
class CsvExport(BaseExport):
    """Export the CVE information in CSV format."""

    def __init__(self, sbom: Sbom, out_path: pathlib.Path) -> None:
        super().__init__(sbom, out_path)
        self._csv_writer: Writer | None = None

    def start_export(self) -> Generator[None, None, None]:
        with self._out_path.open("w", newline="", encoding="utf-8") as f:
            self._csv_writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
            self._csv_writer.writerow(
                [
                    "build",
                    "package names",
                    "version",
                    "vendor-product",
                    "cve-id",
                    "scorev2",
                    "scorev3",
                    "scorev4",
                    "status",
                    "statement",
                    "notes",
                    "obsolete assessments",
                ]
            )
            yield

    def export_comp_info(
        self, comp_build: CompBuild
    ) -> Generator[None, tuple[bool, AggregateAnnotEntry], None]:
        assert self._csv_writer is not None

        if not comp_build.identifiers:
            return

        row_common: _CsvRow = [""] * _Column.NB_COLS
        row_common[_Column.BUILD_NAME] = comp_build.build_name or ""
        row_common[_Column.PKG_NAMES] = "; ".join(
            comp.name for comp in self._filter_components(comp_build)
        )
        row_common[_Column.VERSION] = comp_build.version
        row_common[_Column.PRODUCT_NAMES] = "; ".join(
            comp_id.to_str() for comp_id in comp_build.identifiers
        )

        while True:
            is_filtered, annotation = yield
            if not is_filtered:
                self._csv_writer.writerow(_gen_cve_info(row_common, annotation))
