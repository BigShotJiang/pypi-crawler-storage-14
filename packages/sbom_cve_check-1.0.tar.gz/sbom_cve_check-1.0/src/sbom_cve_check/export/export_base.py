# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
import pathlib
from collections.abc import Generator, Iterable

from ..cve_db.annot_aggregate import AggregateAnnotEntry
from ..sbom.component import CompBuild, CompId, Component
from ..sbom.sbom_base import Sbom

_LINUX_KERNEL_COMP_IDS = (
    CompId(name="linux_kernel"),
    CompId(vendor="linux", name="linux"),
)


class BaseExport(abc.ABC):
    def __init__(self, sbom: Sbom, out_path: pathlib.Path) -> None:
        self._sbom = sbom
        self._out_path = out_path
        self._add_kernel_modules: bool = False

    @property
    def output_path(self) -> pathlib.Path:
        return self._out_path

    @abc.abstractmethod
    def start_export(self) -> Generator[None, None, None]:
        """
        Initialize the export. Call before exporting each component builds.

        This function must yield once, which allow to finalize the export after that.
        This also allow to use a context manager.
        """

    @abc.abstractmethod
    def export_comp_info(
        self, comp_build: CompBuild
    ) -> Generator[None, tuple[bool, AggregateAnnotEntry], None]:
        """
        Export information about one component build (a "recipe").

        This object has associated components: Created packages from this "recipe".
        The build has associated CVE annotations provided by the aggregate annotation
        entries.
        """

    def cfg_add_kernel_modules(self, enable: bool) -> None:
        """If enable is true, add CVE annotations to all kernel modules"""
        self._add_kernel_modules = enable

    def _filter_components(self, comp_build: CompBuild) -> Iterable[Component]:
        """
        Filter the list of components from a component build object.

        Typically used to exclude kernel modules packages in the exported file.
        :return: The filtered list
        """
        if self._add_kernel_modules:
            return comp_build.components

        if not comp_build.is_matching_one_of(_LINUX_KERNEL_COMP_IDS):
            return comp_build.components

        fil_comps: list[Component] = [
            comp for comp in comp_build.components if "-module-" not in comp.name
        ]

        fil2_comps: list[Component] = [
            comp for comp in fil_comps if not comp.name.endswith("-modules")
        ]

        return fil2_comps or fil_comps or comp_build.components
