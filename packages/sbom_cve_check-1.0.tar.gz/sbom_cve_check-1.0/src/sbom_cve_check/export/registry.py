# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import pathlib
from collections.abc import Callable, Iterable
from typing import TypeVar

from ..sbom.sbom_base import Sbom
from ..utils.class_utils import Singleton
from ..utils.plugin import import_builtin_plugin
from .export_base import BaseExport

_ExportT = TypeVar("_ExportT", bound=BaseExport)


class ExportTypeRegistry(metaclass=Singleton):
    def __init__(self) -> None:
        self._export_types: dict[str, type[BaseExport]] = {}

    def register_type(self, type_name: str, export_type: type[BaseExport]) -> None:
        assert type_name not in self._export_types
        self._export_types[type_name] = export_type

    @property
    def type_names(self) -> Iterable[str]:
        return self._export_types.keys()

    def create(
        self,
        type_name: str,
        sbom: Sbom,
        out_path: pathlib.Path,
    ) -> BaseExport:
        cls_export = self._export_types[type_name]
        return cls_export(sbom, out_path)


def register_export(name: str) -> Callable[[type[_ExportT]], type[_ExportT]]:
    def decorator(cls: type[_ExportT]) -> type[_ExportT]:
        ExportTypeRegistry().register_type(name, cls)
        return cls

    return decorator


def __register_builtin_types() -> None:
    modules = [".export_csv", ".export_spdx3", ".export_yocto"]
    for mod in modules:
        import_builtin_plugin(__package__, mod)


__register_builtin_types()
