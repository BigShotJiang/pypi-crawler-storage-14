# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import dataclasses
import logging
import subprocess
import threading
from collections import defaultdict
from collections.abc import Generator

from ..sbom.component import CompBuild, CompId, comp_ids_is_matching_one_of
from ..vuln.cve import CveId
from .annot_aggregate import AggregateAnnotEntry
from .annot_base import AnnotDbEntry
from .db_base import CveDatabase, CveDbEntry

_logger = logging.getLogger(__name__)


@dataclasses.dataclass
class _ThreadDbInitData:
    db: CveDatabase
    exec: BaseException | None = None


def _init_and_index_database(
    data: _ThreadDbInitData,
    lock: threading.Lock,
    index_comp_cve: dict[str, set[str]],
    uniq_cve_ids: dict[str, str],
) -> None:
    try:
        _logger.info("Initializing and indexing the %s database", data.db.name)

        # First initialize the database
        data.db.initialize()

        # Create database index
        index_db = data.db.create_index()

        _logger.info("%s database indexing is complete", data.db.name)
    except BaseException as e:  # noqa: BLE001
        data.exec = e
        return

    # Merge indexes
    with lock:
        for comp_name, cve_ids in index_db.items():
            for cve_id in cve_ids:
                # Allow to reduce memory at the end of indexing:
                # Prevent duplication of CVE-ID strings
                index_comp_cve[comp_name].add(uniq_cve_ids.setdefault(cve_id, cve_id))


class CveDbManager:
    def __init__(self) -> None:
        self._databases: dict[int, list[CveDatabase]] = {}
        self._index_comp_cve: dict[str, tuple[str, ...]] = {}

    def add_db(self, db: CveDatabase, priority: int) -> None:
        # Register the database
        lst_db = self._databases.setdefault(priority, [])
        if lst_db:
            prev_name = lst_db[0].name
            if db.has_annotations:
                raise RuntimeError(
                    f"Annotation database {db.name} has same priority than {prev_name}"
                )
            if lst_db[0].has_annotations:
                raise RuntimeError(
                    f"Annotation database {prev_name} has same priority "
                    f"than CVE db {db.name}"
                )

        lst_db.append(db)

        # Clear index since no longer up-to-date
        self._index_comp_cve.clear()

    def create_index(self) -> None:
        threads: dict[threading.Thread, _ThreadDbInitData] = {}
        lock = threading.Lock()
        index_comp_cve: dict[str, set[str]] = defaultdict(set)
        uniq_cve_ids: dict[str, str] = {}
        self._index_comp_cve.clear()

        # First sort the databases by priority (highest to lowest)
        self._databases = dict(
            sorted(self._databases.items(), key=lambda d: d[0], reverse=True)
        )

        # Initialize and Index the various databases in "parallel"
        for dbs in self._databases.values():
            for db in dbs:
                data = _ThreadDbInitData(db=db)
                t = threading.Thread(
                    target=_init_and_index_database,
                    args=(data, lock, index_comp_cve, uniq_cve_ids),
                )
                threads[t] = data
                t.start()

        for t, data in threads.items():
            t.join()
            if data.exec:
                msg = f"{data.db.name} database init failed"
                if isinstance(data.exec, subprocess.CalledProcessError):
                    msg += "\n" + data.exec.stdout + "---\n" + data.exec.stderr
                raise RuntimeError(msg) from data.exec

        # Free non longer needed memory as soon as possible
        del threads
        del uniq_cve_ids

        # And finally build the final index: Replace set by list to reduce memory usage
        for comp_name, cve_ids in index_comp_cve.items():
            self._index_comp_cve[comp_name] = tuple(cve_ids)

    def get_applicable_cves(
        self, comp_build: CompBuild
    ) -> Generator[AggregateAnnotEntry, None, None]:
        """
        :return: The CVEs that is applicable to this component with associated
        generated annotation
        """
        assert self._index_comp_cve

        # First get a unique list of product name:
        # Group component identifiers by product name
        comp_ids_by_name: dict[str, set[CompId]] = defaultdict(set)
        for comp_id in comp_build.identifiers:
            comp_ids_by_name[comp_id.name].add(comp_id)

        # Query the index for associated CVE for each product name in order to build
        # a set of potential CVE IDs
        potential_cve_ids: set[str] = set()
        for comp_name in comp_ids_by_name:
            for cve_id_str in self._index_comp_cve.get(comp_name, ()):
                potential_cve_ids.add(cve_id_str)

        # For each potential CVE ID (sorted to have something reproducible)...
        for cve_id_str in sorted(potential_cve_ids):
            cve_id = CveId(cve_id_str)

            # Iterate over each database grouped by priority...
            cve_entries_by_prio: dict[int, list[CveDbEntry]] = defaultdict(list)
            cve_loosely_match_ids: dict[str, set[CompId]] = defaultdict(set)

            for prio, dbs in self._databases.items():
                for db in dbs:
                    cve_entry = db.get_cve(cve_id)
                    if cve_entry is None:
                        continue

                    # Build associated list of CVE entries (grouped by priority) but do
                    # not add entry if not applicable: For example if this is an
                    # annotation but the version does not match
                    if not isinstance(
                        cve_entry, AnnotDbEntry
                    ) or cve_entry.is_version_applicable(
                        comp_build.identifiers, comp_build.version
                    ):
                        cve_entries_by_prio[prio].append(cve_entry)

                    # Build a set of component identifiers, that loosely match,
                    # grouped by product name
                    for comp_name in comp_ids_by_name:
                        cve_loosely_match_ids[comp_name].update(
                            cve_entry.get_loosely_applicable_comp_ids(comp_name)
                        )

            if not cve_entries_by_prio:
                continue

            # For each component identifier (specified as input) try to find if it is
            # really associated with the CVE
            is_applicable = False
            for comp_name, comp_ids in comp_ids_by_name.items():
                if comp_ids_is_matching_one_of(
                    comp_ids, CompId.filter_best_ids(cve_loosely_match_ids[comp_name])
                ):
                    is_applicable = True
                    break

            if not is_applicable:
                continue

            # This CVE is applicable to the component identified by component
            # identifiers specified as input
            yield AggregateAnnotEntry(
                comp_build,
                tuple(tuple(lst) for lst in cve_entries_by_prio.values()),
            )
