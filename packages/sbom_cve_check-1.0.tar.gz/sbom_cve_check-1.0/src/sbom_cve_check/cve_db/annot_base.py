# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
from collections import defaultdict
from collections.abc import Generator, Iterable
from typing import Any

from sbom_cve_check.vuln.cpe import Cpe23
from sbom_cve_check.vuln.version import SemVerRange

from ..sbom.component import CompId
from ..utils import parsing
from ..vuln.cve import CveVexAssessment
from .db_base import CveDatabase, CveDatabaseT, CveDbEntry


class AnnotDbEntry(CveDbEntry, abc.ABC):
    """Represent one abstract annotation"""

    def is_annotation(self) -> bool:
        return True

    @property
    @abc.abstractmethod
    def vex_assessment(self) -> CveVexAssessment | None:
        """Provide the CVE VEX assessment"""

    @property
    def vulnerable(self) -> bool | None:
        a = self.vex_assessment
        if a:
            return a.status.is_vulnerable()
        return None

    def _iterate_cpes(self, pkg: Any) -> Generator[Cpe23, None, None]:
        """
        Iterate over all CPEs that are provided by this annotation
        """
        raise NotImplementedError

    def _get_vers_comp_ids(self, pkg: Any) -> dict[str | None, set[CompId]]:
        """
        Get all associated component identifiers with version that can be constructed
        for example from CPEs
        """
        vers_comp_ids: dict[str | None, set[CompId]] = defaultdict(set)

        for cpe in self._iterate_cpes(pkg):
            comp_id = CompId.build_from_cpe(cpe)
            if comp_id is not None:
                vers = cpe.version if isinstance(cpe.version, str) else None
                vers_comp_ids[vers].add(comp_id)

        return vers_comp_ids

    def _get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId], pkg_version: str | None, pkg: Any = None
    ) -> set[SemVerRange]:
        vers_ranges: set[SemVerRange] = set()
        is_vulnerable = self.vulnerable
        is_vuln = True if is_vulnerable is None else is_vulnerable

        add_pkg_version = False
        for vers, ids in self._get_vers_comp_ids(pkg).items():
            for comp_id in ids:
                if comp_id.is_matching_one_of(comp_ids):
                    if vers:
                        vers_ranges.add(
                            SemVerRange.build_single_vers(is_vuln, vers, True)
                        )
                    else:
                        add_pkg_version = True

        if add_pkg_version and pkg_version:
            vers_ranges.add(SemVerRange.build_single_vers(is_vuln, pkg_version, False))

        return vers_ranges

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        return self._get_associated_sem_ver_ranges(comp_ids, None)

    def _iterate_applicable_comp_ids(self) -> Generator[CompId, None, None]:
        for ids in self._get_vers_comp_ids(None).values():
            yield from ids

    def is_version_applicable(
        self, comp_ids: Iterable[CompId], version: str | None
    ) -> bool:
        """
        Indicates if this CVE annotation is applicable to the specified version:
        The specified version must strictly match with one of the annotation's versions
        """
        if version is None:
            return True
        for version_range in self.get_associated_sem_ver_ranges(comp_ids):
            if version_range.check_strictly_equal(version):
                return True
        return False


class AnnotDatabase(CveDatabase, abc.ABC):
    # By default, do not check for obsolete assessment, since it can be slow
    DEFAULT_OBSOLETE_ASSESSMENT_CHECK = False

    @classmethod
    def create_from_config(cls: type[CveDatabaseT], **kwargs: object) -> CveDatabaseT:
        parsing.update_boolean_param(kwargs, "obsolete_assessment_check")
        return super().create_from_config(**kwargs)

    def __init__(
        self, name: str, obsolete_assessment_check: bool | None = None
    ) -> None:
        super().__init__(name)
        if obsolete_assessment_check is None:
            obsolete_assessment_check = self.DEFAULT_OBSOLETE_ASSESSMENT_CHECK
        self.enable_obsolete_assessment_check = obsolete_assessment_check

    @property
    def has_annotations(self) -> bool:
        return True

    @property
    def obsolete_assessment_check_enabled(self) -> bool:
        return self.enable_obsolete_assessment_check
