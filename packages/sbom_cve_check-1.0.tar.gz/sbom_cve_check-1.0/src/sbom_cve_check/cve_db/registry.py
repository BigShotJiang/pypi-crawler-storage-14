# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

from collections.abc import Callable, Iterable
from typing import Any

from ..utils.class_utils import Singleton
from ..utils.plugin import import_builtin_plugin
from .db_base import CveDatabase, CveDatabaseT


class DbTypeRegistry(metaclass=Singleton):
    def __init__(self) -> None:
        self._db_types: dict[str, type[CveDatabase]] = {}

    def register_type(self, type_name: str, db_type: type[CveDatabase]) -> None:
        assert type_name not in self._db_types
        self._db_types[type_name] = db_type

    @property
    def type_names(self) -> Iterable[str]:
        return self._db_types.keys()

    def create_from_config(self, type_name: str, **kwargs: Any) -> CveDatabase:
        return self._db_types[type_name].create_from_config(**kwargs)


def register_cve_db(name: str) -> Callable[[type[CveDatabaseT]], type[CveDatabaseT]]:
    def decorator(cls: type[CveDatabaseT]) -> type[CveDatabaseT]:
        DbTypeRegistry().register_type(name, cls)
        return cls

    return decorator


def __register_builtin_types() -> None:
    modules = [
        ".annot_openvex",
        ".annot_simple",
        ".annot_spdx3",
        ".annot_yocto",
        ".db_cvelist",
        ".db_nvd",
    ]
    for mod in modules:
        import_builtin_plugin(__package__, mod)


__register_builtin_types()
