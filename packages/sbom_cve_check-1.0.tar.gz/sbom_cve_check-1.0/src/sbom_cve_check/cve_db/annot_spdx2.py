# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import re
from collections.abc import Generator, Iterable
from datetime import datetime
from typing import Any

from ..sbom import sbom_spdx2
from ..sbom.component import CompId
from ..vuln.cpe import Cpe23
from ..vuln.cve import (
    CveId,
    CveVexAssessment,
    CveVexFixedAssessment,
)
from ..vuln.version import SemVerRange
from .annot_base import AnnotDatabase, AnnotDbEntry
from .db_base import CveDatabase


class Spdx2AnnotEntry(AnnotDbEntry):
    def __init__(
        self,
        parent_db: CveDatabase,
        cve_id: CveId,
        cpes: set[Cpe23],
        pkg_version: str | None,
    ) -> None:
        super().__init__(parent_db)
        self._cve_id = cve_id
        self._cpes = cpes
        self._pkg_version = pkg_version

    def add_cpes(self, cpes: Iterable[Cpe23]) -> None:
        self._cpes.update(cpes)

    @property
    def identifier(self) -> CveId:
        return self._cve_id

    @property
    def date_modified(self) -> datetime | None:
        return None

    @property
    def description(self) -> str | None:
        return None

    @property
    def vex_assessment(self) -> CveVexAssessment | None:
        return CveVexFixedAssessment(vex_version="1.0", status_notes="patched")

    def _iterate_cpes(self, pkg: Any) -> Generator[Cpe23, None, None]:
        yield from self._cpes

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        return self._get_associated_sem_ver_ranges(comp_ids, self._pkg_version)


class Spdx2AnnotDatabase(AnnotDatabase):
    def __init__(
        self,
        name: str,
        sbom: "sbom_spdx2.Spdx2Sbom",
        **kwargs: Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self._sbom = sbom
        self._vulns: dict[CveId, Spdx2AnnotEntry] = {}

    def _initialize(self) -> None:
        re_cve = re.compile(r"CVE-[0-9]+-[0-9]+")

        for _, recipe_pkg in self._sbom.iterate_recipes():
            cpes = sbom_spdx2.parse_ext_refs_cpe(recipe_pkg)
            pkg_vers: str | None = recipe_pkg.get("versionInfo")
            source_info: str = recipe_pkg.get("sourceInfo", "")

            for cve in re_cve.findall(source_info):
                cve_id = CveId(cve)
                annot = self._vulns.get(cve_id)
                if annot:
                    annot.add_cpes(cpes)
                else:
                    self._vulns[cve_id] = Spdx2AnnotEntry(self, cve_id, cpes, pkg_vers)

    def get_cve(self, cve_id: CveId) -> Spdx2AnnotEntry | None:
        return self._vulns.get(cve_id)

    def iterate_cves(self) -> Generator[Spdx2AnnotEntry, None, None]:
        yield from self._vulns.values()
