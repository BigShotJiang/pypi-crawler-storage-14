# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
import datetime
from collections import defaultdict
from collections.abc import Callable, Generator, Iterable
from typing import Any, Optional, Self, TypeVar, final

from ..sbom.component import CompId
from ..vuln.cve import CveExtReference, CveId
from ..vuln.cvss import CvssMetric, GroupByT, group_cvss_metrics
from ..vuln.version import SemVerRange


class CveDbEntry(abc.ABC):
    def __init__(self, parent_db: Optional["CveDatabase"]) -> None:
        self._parent_db = parent_db

    @property
    def database(self) -> "CveDatabase":
        if self._parent_db is None:
            raise RuntimeError("This entry has no associated database")
        return self._parent_db

    @property
    @abc.abstractmethod
    def identifier(self) -> CveId:
        """The CVE unique identifier"""

    def is_annotation(self) -> bool:
        """Return True if this is an annotation, False if this a CVE database entry"""
        return False

    def is_rejected(self) -> bool | None:
        """Indicates if the CVE entry is in rejected state. None if unknown."""
        return None

    @property
    def date_published(self) -> datetime.datetime | None:
        """Specifies the time when the vulnerability was published."""
        return None

    @property
    @abc.abstractmethod
    def date_modified(self) -> datetime.datetime | None:
        """Specifies a time when the vulnerability assessment was modified"""

    @property
    @abc.abstractmethod
    def description(self) -> str | None:
        """Return the CVE description, and if possible in english"""

    @abc.abstractmethod
    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        """
        For the specified component identifiers, which identify one package/product,
        list all associated version ranges.
        :return: A list of version ranges
        """

    @property
    def cvss_metrics(self) -> list[CvssMetric]:
        """Returns a list of CVSS metrics associated with this CVE"""
        return []

    def group_cvss_metrics(
        self, key: Callable[[CvssMetric], GroupByT]
    ) -> dict[GroupByT, tuple[CvssMetric, ...]]:
        return group_cvss_metrics(self.cvss_metrics, key)

    @property
    def external_refs(self) -> set[CveExtReference]:
        """Provides external references: URLs associated with this CVE"""
        return set()

    @property
    def affected_sources(self) -> set[str]:
        """A list of the affected source code files"""
        return set()

    @abc.abstractmethod
    def _iterate_applicable_comp_ids(self) -> Generator[CompId, None, None]:
        """
        Iterate over all "applicable" component identifiers that can be constructed for
        example from CPEs:
         - For a CVE database this list only the vulnerable CPE.
         - For an annotation this list everything (vulnerable or not-vulnerable
           identifiers).
        """

    def get_loosely_applicable_comp_ids(self, name: str) -> set[CompId]:
        """
        Find all the component identifiers that loosely match (and which are applicable)
        with only component name specified as input.
        """
        applicable_ids: set[CompId] = set()

        for comp_id_cve in self._iterate_applicable_comp_ids():
            if comp_id_cve.name == name:
                applicable_ids.add(comp_id_cve)

        return applicable_ids

    def get_applicable_comp_names(self) -> set[str]:
        """
        Provides the list of component names, of "applicable" packages, that can be
        extracted from referenced CPEs.
        This function is used to index CVE by product name (ignoring vendor part, ...):
        The goal is to reduce the number of CVEs that need to be checked for a
        particular component (package/product).
        """
        products = set()
        for comp_id in self._iterate_applicable_comp_ids():
            if isinstance(comp_id.name, str):
                products.add(comp_id.name)
        return products


CveDatabaseT = TypeVar("CveDatabaseT", bound="CveDatabase")


class CveDatabase(abc.ABC):
    # Do not index rejected CVE since there are not exported (By default).
    # Also, the database entry is empty, at least for CVEList and NVD databases.
    INDEX_REJECTED_CVE = False

    @classmethod
    def create_from_config(cls, **kwargs: Any) -> Self:
        return cls(**kwargs)

    def __init__(self, name: str) -> None:
        self._name: str = name
        self.__initialized = False

    @property
    def name(self) -> str:
        """:return: A description or name of the database"""
        return self._name

    def get_default_priority(self, order: int, from_config: bool) -> int:
        """
        :return: Get default priority value based from where the database was declared
        (Command line or config file), and from the declaration order (last has a
        higher priority)
        """
        assert 0 <= order < 100
        return order + (200 if from_config else 100)

    @final
    def initialize(self) -> None:
        """Initialize this database if not already done"""
        if not self.__initialized:
            self._initialize()
            self.__initialized = True

    @abc.abstractmethod
    def _initialize(self) -> None:
        """Initialize this database"""

    @property
    def has_annotations(self) -> bool:
        """
        Return True if this database manage a pool of annotations, False if it manages
        CVE database entries
        """
        return False

    @property
    def obsolete_assessment_check_enabled(self) -> bool:
        """
        Return True if the CVE database entry, associated with this database, should be
        checked for obsolescence:
        A CVE entry of a lower priority provides the same kind of VEX assessment.
        This doesn't make much sense for a CVE database, but for annotation it makes a
        lot of sense.
        """
        return False

    @abc.abstractmethod
    def get_cve(self, cve_id: CveId) -> CveDbEntry | None:
        """
        Return the CVE object representing this CVE identifier
        (if present in the database).
        """

    @abc.abstractmethod
    def iterate_cves(self) -> Generator[CveDbEntry, None, None]:
        """Iterate over all CVE present in the database"""

    def create_index(self) -> dict[str, set[str]]:
        """
        Create a database index, mapping component/product name to a set of CVE
        identifier. The goal of this index is to speed up CVE look-up
        """
        index_comp_cve: dict[str, set[str]] = defaultdict(set)
        for cve_entry in self.iterate_cves():
            if self.INDEX_REJECTED_CVE or (not cve_entry.is_rejected()):
                for comp_name in cve_entry.get_applicable_comp_names():
                    index_comp_cve[comp_name].add(cve_entry.identifier.id)
        return index_comp_cve
