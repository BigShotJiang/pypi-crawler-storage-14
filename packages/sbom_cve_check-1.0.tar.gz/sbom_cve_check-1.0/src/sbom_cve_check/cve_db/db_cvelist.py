# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import json
import pathlib
from collections.abc import Generator, Iterable
from datetime import datetime
from typing import Any

from ..sbom.component import CompId
from ..utils import parsing
from ..vuln.cpe import parse_cpe_match
from ..vuln.cve import CveExtReference, CveId
from ..vuln.cvss import CvssMetric, CvssVersion
from ..vuln.version import SemVerRange, VersionRange, VersionRangeBuilder
from .db_base import CveDatabase, CveDbEntry
from .db_git import GitCveDatabase
from .registry import register_cve_db


class CveListCveEntry(CveDbEntry):
    def __init__(self, parent_db: CveDatabase, json_obj: dict[str, Any]) -> None:
        super().__init__(parent_db)
        self._json = json_obj

    @property
    def identifier(self) -> CveId:
        return CveId(self._json.get("cveMetadata", {}).get("cveId"))

    def is_annotation(self) -> bool:
        return False

    def is_rejected(self) -> bool:
        state = str(self._json.get("cveMetadata", {}).get("state"))
        return state == "REJECTED"

    @property
    def date_published(self) -> datetime | None:
        return parsing.datetime_from_iso_format(
            self._json.get("cveMetadata", {}).get("datePublished")
        )

    @property
    def date_modified(self) -> datetime | None:
        return parsing.datetime_from_iso_format(
            self._json.get("cveMetadata", {}).get("dateUpdated")
        )

    def _iterate_containers(self) -> Generator[dict[str, Any], None, None]:
        containers_obj = self._json.get("containers", {})
        cna = containers_obj.get("cna")
        if cna is not None:
            yield cna
        yield from containers_obj.get("adp", [])

    @staticmethod
    def _container_description(container: dict[str, Any]) -> str | None:
        descriptions = container.get("descriptions")
        if not descriptions:
            return None

        for desc in descriptions:
            if desc.get("lang") == "en":
                txt = desc.get("value")
                if txt:
                    return str(txt)

        d = descriptions[0].get("value")
        return d if isinstance(d, str) else None

    @staticmethod
    def _container_cna_org(container: dict[str, Any]) -> str | None:
        """:return: CNA organization identifier for this container"""
        org = container.get("providerMetadata", {}).get("orgId")
        return org if isinstance(org, str) else None

    @property
    def description(self) -> str | None:
        for c in self._iterate_containers():
            desc = self._container_description(c)
            if desc is not None:
                return desc

        return None

    @staticmethod
    def _iterate_cpe_matches(
        container: dict[str, Any],
    ) -> Generator[dict[str, Any], None, None]:
        for cpe_applicability in container.get("cpeApplicability", []):
            for node in cpe_applicability.get("nodes", []):
                yield from node.get("cpeMatch", [])

    @staticmethod
    def _parse_affected_version(
        json_obj: dict[str, Any], cna_org: str | None
    ) -> VersionRange | None:
        status = json_obj.get("status")
        if status == "affected":
            is_vuln = True
        elif status == "unaffected":
            is_vuln = False
        else:
            is_vuln = None

        vers_type: str | None = json_obj.get("versionType")
        vers_range_builder = VersionRangeBuilder(
            vulnerable=is_vuln, from_cpe=False, from_cna=cna_org
        )

        v_end_le = json_obj.get("lessThanOrEqual")
        if v_end_le:
            vers_range_builder.set_end_version(v_end_le, including=True)

        v_end_lt = json_obj.get("lessThan")
        if v_end_lt:
            vers_range_builder.set_end_version(v_end_lt, including=False)

        vers_val = json_obj.get("version")
        if vers_val is None:
            return None

        if v_end_le or v_end_lt or (vers_type == "git"):
            vers_range_builder.set_start_version(vers_val, including=True)
        else:
            vers_range_builder.set_start_version(vers_val, equal=True)

        if vers_range_builder.is_valid():
            if vers_type == "git":
                return vers_range_builder.git_ver_range
            return vers_range_builder.sem_ver_range

        return None

    def _iterate_applicable_comp_ids(self) -> Generator[CompId, None, None]:
        for c in self._iterate_containers():
            # Process affected blocks
            for affected in c.get("affected", []):
                # Check if there is at least one affected version
                is_vuln = False
                for version in affected.get("versions", []):
                    if version.get("status") == "affected":
                        is_vuln = True
                        break

                # If there is no vulnerable version, do not check CPEs
                if not is_vuln:
                    continue

                # Extract CPEs and package/component name
                for cpe in affected.get("cpes", []):
                    comp_id = CompId.build_from_cpe(cpe)
                    if comp_id is not None:
                        yield comp_id

                pkg_name = affected.get("packageName")
                if pkg_name:
                    yield CompId(name=pkg_name)

            # Process cpeMatch blocks
            for cpe_match in self._iterate_cpe_matches(c):
                if cpe_match.get("vulnerable", True):
                    comp_id = CompId.build_from_cpe(cpe_match.get("criteria"))
                    if comp_id is not None:
                        yield comp_id

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        vers_ranges: list[SemVerRange] = []
        cpe_applicable_comp_ids: set[CompId] = set()

        # First iterate over cpeMatch blocks
        for c in self._iterate_containers():
            cna_org = self._container_cna_org(c)

            for cpe_match_json in self._iterate_cpe_matches(c):
                cpe, vers_range = parse_cpe_match(cpe_match_json, cna_org)
                comp_id = CompId.build_from_cpe(cpe)
                if (comp_id is not None) and (vers_range is not None):
                    if vers_range.vulnerable:
                        cpe_applicable_comp_ids.add(comp_id)
                    if isinstance(
                        vers_range, SemVerRange
                    ) and comp_id.is_matching_one_of(comp_ids):
                        vers_ranges.append(vers_range)

        # Then, if there is only a unique component identifier specified, we could use
        # this component identifier for affected versions with missing CPE
        accept_version_without_comp_id = (len(cpe_applicable_comp_ids) == 1) and (
            len(vers_ranges) > 0
        )

        # Iterate over affected blocks
        for c in self._iterate_containers():
            cna_org = self._container_cna_org(c)

            for affected in c.get("affected", []):
                # Extract CPEs and package name to check if this block is applicable to
                # specified component identifier
                is_applicable = None if accept_version_without_comp_id else False
                for cpe in affected.get("cpes", []):
                    comp_id = CompId.build_from_cpe(cpe)
                    if comp_id is not None:
                        is_applicable = comp_id.is_matching_one_of(comp_ids)
                        if is_applicable:
                            break

                if not is_applicable:
                    pkg_name = affected.get("packageName")
                    if pkg_name:
                        is_applicable = CompId(name=pkg_name).is_matching_one_of(
                            comp_ids
                        )

                # If this block is not applicable, do not parse it, skip it
                if is_applicable is False:
                    continue

                # And finally parse each version
                for version in affected.get("versions", []):
                    vers_range = self._parse_affected_version(version, cna_org)
                    if (vers_range is not None) and isinstance(vers_range, SemVerRange):
                        vers_ranges.append(vers_range)

        return vers_ranges

    @property
    def cvss_metrics(self) -> list[CvssMetric]:
        def add_cvss_to_set(
            m: list[CvssMetric], cvss_obj: dict[str, Any], cvss_ver: CvssVersion
        ) -> None:
            if cvss_obj is not None:
                cvss_info = CvssMetric.parse_cve_db_metric(cvss_obj, version=cvss_ver)
                if cvss_info is not None:
                    m.append(cvss_info)

        cvss_metrics: list[CvssMetric] = []
        for c in self._iterate_containers():
            for metric in c.get("metrics", []):
                add_cvss_to_set(cvss_metrics, metric.get("cvssV2_0"), CvssVersion.V2_0)
                add_cvss_to_set(cvss_metrics, metric.get("cvssV3_0"), CvssVersion.V3_0)
                add_cvss_to_set(cvss_metrics, metric.get("cvssV3_1"), CvssVersion.V3_1)
                add_cvss_to_set(cvss_metrics, metric.get("cvssV4_0"), CvssVersion.V4_0)

        return cvss_metrics

    @property
    def external_refs(self) -> set[CveExtReference]:
        ext_refs = set()
        for c in self._iterate_containers():
            for ext_ref in c.get("references", []):
                url = ext_ref.get("url")
                if url:
                    ext_refs.add(CveExtReference(url))

        return ext_refs

    @property
    def affected_sources(self) -> set[str]:
        sources = set()
        for c in self._iterate_containers():
            for affected in c.get("affected", []):
                sources.update(affected.get("programFiles", []))
        return sources


@register_cve_db("cve-db-cvelist")
class CveListCveDatabase(GitCveDatabase):
    GIT_FETCH_URL = "https://github.com/CVEProject/cvelistV5.git"

    def __init__(
        self, path: pathlib.Path, name: str, git_url: str = GIT_FETCH_URL, **kwargs: Any
    ) -> None:
        super().__init__(path, name, git_url, **kwargs)

    def get_default_priority(self, order: int, from_config: bool) -> int:
        return 50

    def get_cve(self, cve_id: CveId) -> CveDbEntry | None:
        path_json = self._git_dir.joinpath(
            "cves", cve_id.year, cve_id.number[:-3] + "xxx", f"{cve_id.id}.json"
        )
        if path_json.is_file():
            with path_json.open(encoding="utf-8") as f:
                return CveListCveEntry(self, json.load(f))
        return None

    def iterate_cves(self) -> Generator[CveDbEntry, None, None]:
        for path_json in self._git_dir.glob("cves/*/*/CVE-*.json"):
            with path_json.open(encoding="utf-8") as f:
                yield CveListCveEntry(self, json.load(f))
