# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import pathlib
from collections.abc import Generator, Iterable
from datetime import datetime
from typing import Any

from spdx_python_model.bindings import v3_0_1 as spdx30  # type: ignore[import-untyped]

from ..sbom import lib_spdx3
from ..sbom.component import CompId
from ..vuln.cpe import Cpe23
from ..vuln.cve import (
    CveExtReference,
    CveId,
    CveVexAssessment,
    find_most_appropriate_assessment,
)
from ..vuln.cvss import CvssMetric
from ..vuln.version import SemVerRange
from .annot_base import AnnotDatabase, AnnotDbEntry
from .db_base import CveDatabase
from .registry import register_cve_db


class Spdx3AnnotEntry(AnnotDbEntry):
    """Represent one Vulnerability with associated VulnAssessmentRelationship"""

    def __init__(
        self,
        parent_db: CveDatabase,
        cve_id: str,
        vuln: spdx30.security_Vulnerability,
        pkgs_rels: dict[
            spdx30.software_Package, set[spdx30.security_VulnAssessmentRelationship]
        ],
    ) -> None:
        super().__init__(parent_db)
        self._cve_id: str = cve_id
        self._vuln = vuln
        self._pkgs_rels = pkgs_rels

    @property
    def identifier(self) -> CveId:
        return CveId(self._cve_id)

    @property
    def date_published(self) -> datetime | None:
        return self._vuln.security_publishedTime  # type: ignore[no-any-return]

    @property
    def date_modified(self) -> datetime | None:
        return self._vuln.security_modifiedTime  # type: ignore[no-any-return]

    @property
    def description(self) -> str | None:
        d = self._vuln.description
        return d if isinstance(d, str) else None

    @property
    def cvss_metrics(self) -> list[CvssMetric]:
        metrics: list[CvssMetric] = []
        for rels in self._pkgs_rels.values():
            for rel in rels:
                metric = lib_spdx3.cvss_metric_from_vuln_relationship(rel)
                if metric is not None:
                    metrics.append(metric)
        return metrics

    @property
    def external_refs(self) -> set[CveExtReference]:
        ext_refs: set[CveExtReference] = set()
        for ext_ref in self._vuln.externalRef:
            ext_refs.add(CveExtReference(ext_ref.locator, ext_ref.externalRefType))
        return ext_refs

    @property
    def vex_assessment(self) -> CveVexAssessment | None:
        assessment: CveVexAssessment | None = None
        for rels in self._pkgs_rels.values():
            for rel in rels:
                a = lib_spdx3.cve_vex_assessment_from_vuln_relationship(rel)
                assessment = find_most_appropriate_assessment(assessment, a)
        return assessment

    def _iterate_cpes(self, pkg: Any) -> Generator[Cpe23, None, None]:
        package: spdx30.software_Package = pkg
        for ext_id in package.externalIdentifier:
            if ext_id.externalIdentifierType == spdx30.ExternalIdentifierType.cpe23:
                cpe = Cpe23.parse(ext_id.identifier)
                if cpe:
                    yield cpe

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        for package in self._pkgs_rels:
            yield from self._get_associated_sem_ver_ranges(
                comp_ids, package.software_packageVersion, package
            )

    def _iterate_applicable_comp_ids(self) -> Generator[CompId, None, None]:
        for package in self._pkgs_rels:
            for ids in self._get_vers_comp_ids(package).values():
                yield from ids


@register_cve_db("spdx3-file")
class Spdx3AnnotDatabase(AnnotDatabase):
    def __init__(
        self,
        path: pathlib.Path | None,
        name: str,
        objset: lib_spdx3.ObjectSet | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(name, **kwargs)
        if (path is None) and (objset is None):
            raise ValueError("Path to SPDX3 file is missing")
        self._obj: lib_spdx3.ObjectSet | None = objset
        self._path_spdx: pathlib.Path | None = None
        if path is not None:
            self._path_spdx = path.resolve(strict=True)
        self._vulns: dict[CveId, Spdx3AnnotEntry] = {}

    def _initialize(self) -> None:
        if self._obj is None:
            assert self._path_spdx is not None
            self._obj = lib_spdx3.ObjectSet.parse_jsonld(self._path_spdx)
        self._vulns.clear()
        for vuln, pkgs_rels in self._obj.get_all_vulns().items():
            cve_id = lib_spdx3.vuln_get_cve_id(vuln)
            if cve_id is not None:
                self._vulns[CveId(cve_id)] = Spdx3AnnotEntry(
                    self, cve_id, vuln, pkgs_rels
                )

    def get_cve(self, cve_id: CveId) -> Spdx3AnnotEntry | None:
        return self._vulns.get(cve_id)

    def iterate_cves(self) -> Generator[Spdx3AnnotEntry, None, None]:
        yield from self._vulns.values()
