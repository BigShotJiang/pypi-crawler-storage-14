# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import json
import pathlib
from collections.abc import Generator, Iterable
from datetime import datetime
from typing import Any

from ..sbom.component import CompId
from ..utils import parsing
from ..vuln.cpe import parse_cpe_match
from ..vuln.cve import CveExtReference, CveId
from ..vuln.cvss import CvssMetric, CvssVersion
from ..vuln.version import SemVerRange
from .db_base import CveDatabase, CveDbEntry
from .db_git import GitCveDatabase
from .registry import register_cve_db


class NvdCveEntry(CveDbEntry):
    def __init__(self, parent_db: CveDatabase, json_obj: dict[str, Any]) -> None:
        super().__init__(parent_db)
        self._json = json_obj

    @property
    def identifier(self) -> CveId:
        return CveId(self._json["id"])

    def is_annotation(self) -> bool:
        return False

    def is_rejected(self) -> bool:
        return self._json.get("vulnStatus") == "Rejected"

    @property
    def date_published(self) -> datetime | None:
        return parsing.datetime_from_iso_format(self._json.get("published"))

    @property
    def date_modified(self) -> datetime | None:
        return parsing.datetime_from_iso_format(self._json.get("lastModified"))

    @property
    def description(self) -> str | None:
        descriptions = self._json.get("descriptions")
        if not descriptions:
            return None

        for desc in descriptions:
            if desc.get("lang") == "en":
                txt = desc.get("value")
                if txt:
                    return str(txt)

        d = descriptions[0].get("value")
        return d if isinstance(d, str) else None

    def _iterate_cpe_matches(self) -> Generator[dict[str, Any], None, None]:
        for cpe_applicability in self._json.get("configurations", []):
            for node in cpe_applicability.get("nodes", []):
                yield from node.get("cpeMatch", [])

    def _iterate_applicable_comp_ids(self) -> Generator[CompId, None, None]:
        for cpe_match in self._iterate_cpe_matches():
            if cpe_match.get("vulnerable", True):
                comp_id = CompId.build_from_cpe(cpe_match.get("criteria"))
                if comp_id is not None:
                    yield comp_id

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        vers_ranges: list[SemVerRange] = []

        # Get CNA organization identifier
        cna_org = self._json.get("sourceIdentifier")

        for cpe_match_json in self._iterate_cpe_matches():
            cpe, vers_range = parse_cpe_match(cpe_match_json, cna_org)
            comp_id = CompId.build_from_cpe(cpe)
            if (
                (comp_id is not None)
                and isinstance(vers_range, SemVerRange)
                and comp_id.is_matching_one_of(comp_ids)
            ):
                vers_ranges.append(vers_range)

        return vers_ranges

    @property
    def cvss_metrics(self) -> list[CvssMetric]:
        def add_cvss_to_set(
            m: list[CvssMetric], cvss_objs: list[dict[str, Any]], cvss_ver: CvssVersion
        ) -> None:
            for cvss_obj in cvss_objs:
                cvss_info = CvssMetric.parse_cve_db_metric(
                    cvss_obj.get("cvssData"),
                    source=cvss_obj.get("source"),
                    version=cvss_ver,
                )
                if cvss_info is not None:
                    m.append(cvss_info)

        cvss_metrics: list[CvssMetric] = []
        metric = self._json.get("metrics", {})
        add_cvss_to_set(cvss_metrics, metric.get("cvssMetricV2", []), CvssVersion.V2_0)
        add_cvss_to_set(cvss_metrics, metric.get("cvssMetricV30", []), CvssVersion.V3_0)
        add_cvss_to_set(cvss_metrics, metric.get("cvssMetricV31", []), CvssVersion.V3_1)
        add_cvss_to_set(cvss_metrics, metric.get("cvssMetricV40", []), CvssVersion.V4_0)

        return cvss_metrics

    @property
    def external_refs(self) -> set[CveExtReference]:
        ext_refs = set()

        for ext_ref in self._json.get("references", []):
            url = ext_ref.get("url")
            if url:
                ext_refs.add(CveExtReference(url))

        return ext_refs


@register_cve_db("cve-db-nvd-fkie")
class NvdFkieCveDatabase(GitCveDatabase):
    GIT_FETCH_URL = "https://github.com/fkie-cad/nvd-json-data-feeds.git"

    def __init__(
        self, path: pathlib.Path, name: str, git_url: str = GIT_FETCH_URL, **kwargs: Any
    ) -> None:
        super().__init__(path, name, git_url, **kwargs)

    def get_default_priority(self, order: int, from_config: bool) -> int:
        return 50

    def get_cve(self, cve_id: CveId) -> CveDbEntry | None:
        path_json = self._git_dir.joinpath(
            f"CVE-{cve_id.year}", cve_id.id[:-2] + "xx", f"{cve_id.id}.json"
        )
        if path_json.is_file():
            with path_json.open(encoding="utf-8") as f:
                return NvdCveEntry(self, json.load(f))
        return None

    def iterate_cves(self) -> Generator[CveDbEntry, None, None]:
        for path_json in self._git_dir.glob("CVE-*/CVE-*xx/CVE-*.json"):
            with path_json.open(encoding="utf-8") as f:
                yield NvdCveEntry(self, json.load(f))
