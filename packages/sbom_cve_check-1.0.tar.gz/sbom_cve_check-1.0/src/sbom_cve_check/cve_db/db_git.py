# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import abc
import contextlib
import fcntl
import hashlib
import json
import logging
import os
import pathlib
from collections.abc import Callable, Generator
from datetime import UTC, datetime, timedelta
from typing import Any

from ..utils import parsing
from ..utils.git import GitRepo
from .annot_base import AnnotDatabase
from .db_base import CveDatabase, CveDatabaseT

_logger = logging.getLogger(__name__)


class GitDatabase:
    @staticmethod
    def parse_init_params(args: dict[str, Any]) -> None:
        parsing.update_timedelta_param(
            args, "auto_update_max_age", special_vals={"off": None}
        )
        parsing.update_boolean_param(args, "max_age_since_last_commit")
        parsing.update_integer_param(args, "git_fetch_depth")

    def __init__(
        self,
        git_dir: pathlib.Path,
        git_url: str,
        is_annotation: bool,
        *,
        auto_update_max_age: timedelta | None = timedelta(hours=20),
        max_age_since_last_commit: bool | None = None,
        cache_index_path: str | None = ".sbom-cve-check-cache-index.json",
        git_branch: str | None = None,
        git_ref: str | None = None,
        git_fetch_depth: int | None = None,
    ) -> None:
        self._git_repo = GitRepo(git_dir)
        self._git_clone_url: str = git_url

        self.auto_update_max_age: timedelta | None = auto_update_max_age
        if max_age_since_last_commit is None:
            max_age_since_last_commit = not is_annotation
        self.max_age_since_last_commit: bool = max_age_since_last_commit

        self._cache_index_path: pathlib.Path | None = None
        if cache_index_path:
            cache_index_path = os.path.expandvars(cache_index_path)
            self._cache_index_path = pathlib.Path(cache_index_path).expanduser()
            if not self._cache_index_path.is_absolute():
                self._cache_index_path = self._git_repo.path.joinpath(cache_index_path)
            self._cache_index_path = self._cache_index_path.resolve()

        self._git_branch = git_branch
        self._git_ref = git_ref
        self._git_fetch_depth = git_fetch_depth
        self._lock_fd: int = -1

        self._git_repo.path.mkdir(parents=True, exist_ok=True)
        self._take_lock(False)

    def __del__(self) -> None:
        self._release_lock()

    def _take_lock(self, exclusive: bool) -> None:
        if self._lock_fd < 0:
            self._lock_fd = os.open(self._git_repo.path, os.O_RDONLY | os.O_NOCTTY)
        fcntl.flock(self._lock_fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)

    def _release_lock(self) -> None:
        if self._lock_fd >= 0:
            os.close(self._lock_fd)
            self._lock_fd = -1

    @contextlib.contextmanager
    def _lock_exclusive_taken(self) -> Generator[None, Any, None]:
        try:
            self._take_lock(True)
            yield None
        finally:
            self._take_lock(False)

    def initialize(self) -> None:
        """
        Initialize this database.
        When updating the git database, take the lock exclusively.
        """
        self.update(force_update=False)

    def update(self, force_update: bool = True) -> None:
        """Update the database to the latest version"""
        with self._lock_exclusive_taken():
            self._update(force_update)

    def _auto_update_needed(self) -> bool:
        if self.auto_update_max_age is None:
            return False

        if self.max_age_since_last_commit:
            d = self.get_date_last_commit()
        else:
            d = self.get_date_last_update()

        if d is not None:
            return self._compute_elapsed_time(d) >= self.auto_update_max_age
        return True

    def _update(self, force_update: bool) -> None:
        repo_dir = self._git_repo.path

        # If the repository does not exist yet, we need to clone it
        if not self._git_repo.is_git_repo():
            _logger.info("Downloading to %s from %s", repo_dir, self._git_clone_url)

            # If the branch name is missing consider that the ref is a tag
            branch = self._git_branch
            if self._git_ref and (not branch):
                branch = self._git_ref

            if self._git_fetch_depth is not None:
                depth = self._git_fetch_depth
            else:
                depth = 0 if self._git_ref else 1
            self._git_repo.clone(self._git_clone_url, branch, depth)
            return

        # Shortcut: If asked for a specific reference, and the reference already
        # exist in the git repository, switch to this revision
        if self._git_ref and self._git_repo.is_valid_object(self._git_ref):
            self._git_repo.switch_detach_head(self._git_ref, True)
            return

        # Get default remote branch if none was provided
        if not self._git_branch:
            self._git_branch = self._git_repo.get_default_remote_branch()
            if not self._git_branch:
                self._git_branch = self._git_repo.update_default_remote_branch()

        # We need to check if we are on the correct branch if the user did not ask
        # for a specific reference.
        curr_branch: str | None = None
        if not force_update:
            if not self._git_ref:
                curr_branch = self._git_repo.get_current_branch()
            else:
                force_update = True

        # If we are not on the correct branch, or if an update was forced, or if the
        # last update is too old, trigger a fetch
        if (
            force_update
            or (self._git_branch != curr_branch)
            or self._auto_update_needed()
        ):
            fetch_url = self._git_repo.get_fetch_url()
            _logger.info("Updating %s from %s", repo_dir, fetch_url)

            fetch_depths: list[int] = [
                0 if self._git_fetch_depth is None else self._git_fetch_depth,
                0,
            ]
            for fetch_depth in fetch_depths:
                unshallow = False
                if (fetch_depth <= 0) and self._git_ref:
                    unshallow = self._git_repo.is_shallow_repository()

                self._git_repo.fetch(self._git_branch, unshallow, fetch_depth)

                if (
                    (fetch_depth <= 0)
                    or (not self._git_ref)
                    or (self._git_repo.is_valid_object(self._git_ref))
                ):
                    break

        # And finally update the repository
        if self._git_ref:
            self._git_repo.switch_detach_head(self._git_ref, True)
        else:
            self._git_repo.switch_force_create_branch(self._git_branch, True)

    def get_date_last_commit(self) -> datetime | None:
        """
        Get the date time of last commit from the git repository.

        Get commiter date of the last commit (HEAD).
        Return None if the database does not exist yet.
        """
        if not self._git_repo.is_git_repo():
            return None
        return self._git_repo.get_date_last_commit()

    def get_date_last_update(self) -> datetime | None:
        return self._git_repo.get_date_last_update()

    @staticmethod
    def _compute_elapsed_time(start_date: datetime) -> timedelta:
        """
        Get the elapsed time since a start date (should be in UTC)
        """
        date_now = datetime.now(UTC)
        delta = date_now - start_date
        zero_delta = timedelta(0)
        return max(zero_delta, delta)

    def create_index(
        self,
        create_index: Callable[[], dict[str, set[str]]],
        cfg_hash: str,
    ) -> dict[str, set[str]]:
        """
        Create the database index if the index previously computed is not associated
        with the last git commit. Otherwise, load the previous index from disk.
        """

        def set_default(obj: object) -> list[str]:
            if isinstance(obj, set):
                return list(obj)
            raise TypeError

        if not self._git_repo.is_git_repo():
            raise RuntimeError(f"Database {self._git_repo.path} was not initialized")

        commit_id = self._git_repo.resolve_sha_ref("HEAD")

        if self._cache_index_path and self._cache_index_path.is_file():
            with self._cache_index_path.open(encoding="utf-8") as f:
                cache_obj = json.load(f)
                if isinstance(cache_obj, dict):
                    index_comp_cve = cache_obj.get("index")
                    cache_commit = cache_obj.get("commit")
                    cache_hash = cache_obj.get("cfg_hash")
                    if (
                        (cache_commit == commit_id)
                        and (cache_hash == cfg_hash)
                        and isinstance(index_comp_cve, dict)
                    ):
                        return index_comp_cve

        index_comp_cve = create_index()
        assert index_comp_cve

        if self._cache_index_path:
            with (
                self._lock_exclusive_taken(),
                self._cache_index_path.open("w", encoding="utf-8") as f,
            ):
                cache_obj = {
                    "commit": commit_id,
                    "cfg_hash": cfg_hash,
                    "index": index_comp_cve,
                }
                f.write(json.dumps(cache_obj, default=set_default))

        return index_comp_cve


class GitCveDatabase(CveDatabase, abc.ABC):
    @classmethod
    def create_from_config(cls: type[CveDatabaseT], **kwargs: Any) -> CveDatabaseT:
        GitDatabase.parse_init_params(kwargs)
        return super().create_from_config(**kwargs)

    def __init__(
        self, path: pathlib.Path, name: str, git_url: str, **kwargs: Any
    ) -> None:
        super().__init__(name)
        self._git_dir: pathlib.Path = path.resolve()
        self._git_db = GitDatabase(self._git_dir, git_url, False, **kwargs)

    @property
    def git_database(self) -> GitDatabase:
        return self._git_db

    def _initialize(self) -> None:
        self._git_db.initialize()

    def create_index(self) -> dict[str, set[str]]:
        return self._git_db.create_index(super().create_index, "")


class GitAnnotDatabase(AnnotDatabase, abc.ABC):
    @classmethod
    def create_from_config(cls: type[CveDatabaseT], **kwargs: Any) -> CveDatabaseT:
        GitDatabase.parse_init_params(kwargs)
        return super().create_from_config(**kwargs)

    def __init__(
        self,
        path: pathlib.Path,
        name: str,
        obsolete_assessment_check: bool | None = None,
        git_url: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(name, obsolete_assessment_check)
        self._db_dir: pathlib.Path = path.resolve(strict=not git_url)
        self._git_db: GitDatabase | None = None
        if git_url:
            self._git_db = GitDatabase(self._db_dir, git_url, True, **kwargs)

    @property
    def git_database(self) -> GitDatabase | None:
        return self._git_db

    def _initialize(self) -> None:
        if self._git_db is not None:
            self._git_db.initialize()

    @abc.abstractmethod
    def _get_index_cache_invalidation_data(self) -> bytes:
        """
        Raw data, used to build an invalidation key for cache_index

        Use to invalidate the index cache if the annotation database changed.
        """

    def create_index(self) -> dict[str, set[str]]:
        if self._git_db is not None:
            h = hashlib.sha256(self._get_index_cache_invalidation_data())
            h.update(b"||")
            h.update(self._db_dir.as_posix().encode())
            return self._git_db.create_index(super().create_index, h.hexdigest())
        return super().create_index()
