# -*- coding: utf-8 -*-

import pathlib
from collections import defaultdict
from collections.abc import Generator
from datetime import datetime
from typing import Any

import yaml  # type: ignore[import-untyped]

from ..sbom.component import CompId
from ..utils import parsing
from ..vuln.cve import (
    CveId,
    CveVexAffectedAssessment,
    CveVexAssessment,
    CveVexNotAffectedAssessment,
)
from .annot_base import AnnotDbEntry
from .db_base import CveDatabase, CveDatabaseT
from .db_git import GitAnnotDatabase
from .registry import register_cve_db


class SimpleCveAnnotEntry(AnnotDbEntry):
    """
    Represent one annotation. The file contains the following mandatory fields:
     - comment:
     - cve-product:
     - last-review:
     - versions:
     - vulnerable:
    """

    def __init__(
        self, parent_db: CveDatabase, path_yml: pathlib.Path, annot_info: dict[str, str]
    ) -> None:
        super().__init__(parent_db)
        self._cve_id = CveId(path_yml.stem)
        self._annot = annot_info

    @property
    def identifier(self) -> CveId:
        return self._cve_id

    @property
    def date_modified(self) -> datetime | None:
        return datetime.fromisoformat(self._annot["last-review"])

    @property
    def description(self) -> str | None:
        return None

    @property
    def vulnerable(self) -> bool | None:
        vuln_val = self._annot.get("vulnerable")
        return vuln_val if isinstance(vuln_val, bool) else (vuln_val != "no")

    @property
    def vex_assessment(self) -> CveVexAssessment | None:
        comment = self._annot.get("comment", "")
        if self.vulnerable:
            return CveVexAffectedAssessment(
                action_statement=comment, action_statement_time=self.date_modified
            )
        return CveVexNotAffectedAssessment(
            impact_statement=comment, impact_statement_time=self.date_modified
        )

    def _get_vers_comp_ids(self, pkg: Any) -> dict[str | None, set[CompId]]:
        vers_comp_ids: dict[str | None, set[CompId]] = defaultdict(set)
        comp_id = CompId.build_from_vendor_product_str(self._annot["cve-product"])

        for vers in self._annot["versions"]:
            vers_comp_ids[str(vers)].add(comp_id)

        return vers_comp_ids


@register_cve_db("simple-annotations")
class SimpleCveAnnotDatabase(GitAnnotDatabase):
    @classmethod
    def create_from_config(cls: type[CveDatabaseT], **kwargs: Any) -> CveDatabaseT:
        parsing.update_list_param(kwargs, "globs", required=True)
        return super().create_from_config(**kwargs)

    def __init__(
        self, path: pathlib.Path, name: str, globs: list[str], **kwargs: Any
    ) -> None:
        super().__init__(path, name, **kwargs)
        self._annotations: dict[CveId, SimpleCveAnnotEntry] = {}
        self._annot_globs = globs

    def _create_glob_pattern(self, annot_glob: str) -> str:
        if annot_glob.endswith((".yaml", ".yml")):
            return annot_glob
        if annot_glob.endswith("/"):
            return f"{annot_glob}CVE-*-*.yaml"
        if self._db_dir.joinpath(annot_glob).is_dir():
            return f"{annot_glob}/CVE-*-*.yaml"
        return annot_glob

    def _initialize(self) -> None:
        super()._initialize()
        self._annotations.clear()

        for annot_glob in self._annot_globs:
            glob_pattern = self._create_glob_pattern(annot_glob)
            for path_yml in self._db_dir.glob(glob_pattern):
                with path_yml.open(encoding="utf-8") as f:
                    a = SimpleCveAnnotEntry(self, path_yml, yaml.safe_load(f))
                    self._annotations[a.identifier] = a

    def _get_index_cache_invalidation_data(self) -> bytes:
        return str(self._annot_globs).encode()

    def get_cve(self, cve_id: CveId) -> SimpleCveAnnotEntry | None:
        return self._annotations.get(cve_id)

    def iterate_cves(self) -> Generator[SimpleCveAnnotEntry, None, None]:
        yield from self._annotations.values()
