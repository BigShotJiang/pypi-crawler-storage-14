# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import pathlib
from collections.abc import Generator, Iterable
from datetime import datetime
from typing import Any

from ..sbom.component import CompBuild, CompId
from ..utils.reproducible import ReproducibleDateTime
from ..vuln.cve import (
    CveExtReference,
    CveId,
    CveVexAffectedAssessment,
    CveVexAssessment,
    CveVexFixedAssessment,
    CveVexJustification,
    CveVexMissingVersionsAssessment,
    CveVexNotAffectedAssessment,
    CveVexOldVersNotVulnAssessment,
    CveVexRejectedAssessment,
)
from ..vuln.cvss import CvssMetric, CvssVersion
from ..vuln.version import SemVerRange, Version, VersRangeStatus
from .annot_base import AnnotDbEntry
from .db_base import CveDbEntry


class ObsoleteAssessment:
    def __init__(
        self,
        obs_assess: CveVexAssessment,
        obs_cve_entries: tuple[CveDbEntry, ...],
        sec_assess: CveVexAssessment,
        sec_cve_entries: tuple[CveDbEntry, ...],
        msg_tpl: str | None,
    ) -> None:
        # Information about obsolete assessment (higher priority)
        self._obs_assess = obs_assess
        self._obs_cve_entries = obs_cve_entries
        # Information about assessment with lower priority
        self._sec_assess = sec_assess
        self._sec_cve_entries = sec_cve_entries
        # Message template to generate a description
        if msg_tpl is None:
            msg_tpl = (
                "{cve_id} assessment {obs_assess}, from {obs_db_name}, is obsolete. "
                "Override assessment {sec_assess} from {sec_db_name}"
            )
        self._msg_tpl: str = msg_tpl

    def __str__(self) -> str:
        cve_id = self._obs_cve_entries[0].identifier.id
        obs_db_name = ", ".join(
            cve_entry.database.name for cve_entry in self._obs_cve_entries
        )
        sec_db_name = ", ".join(
            cve_entry.database.name for cve_entry in self._sec_cve_entries
        )

        return self._msg_tpl.format(
            cve_id=cve_id,
            obs_assess=self._obs_assess,
            obs_db_name=obs_db_name,
            sec_assess=self._sec_assess,
            sec_db_name=sec_db_name,
        )


class AggregateAnnotEntry(AnnotDbEntry):
    def __init__(
        self, comp_build: CompBuild, cve_db_entries: tuple[tuple[CveDbEntry, ...], ...]
    ) -> None:
        super().__init__(parent_db=None)
        self._comp_build = comp_build
        self._cve_db_entries = cve_db_entries
        self._timestamp = ReproducibleDateTime().now
        self._cvss_metrics: list[CvssMetric] | None = None
        self._assessment: CveVexAssessment | None = None
        self._obsolete_assessments: list[ObsoleteAssessment] = []
        self._cve_id: CveId = self._find_cve_id()

    def _find_cve_id(self) -> CveId:
        cve_id: CveId | None = None
        for cve_entry in self._iterate_cve_entries():
            if cve_id is None:
                cve_id = cve_entry.identifier
            elif cve_entry.identifier != cve_id:
                raise RuntimeError("Aggregation of different CVE identifiers")
        if cve_id is None:
            raise ValueError("This object must contain at least one database entry")
        return cve_id

    @property
    def identifier(self) -> CveId:
        return self._cve_id

    def is_rejected(self) -> bool | None:
        rejected = None
        for cve_entry in self._iterate_cve_entries():
            r = cve_entry.is_rejected()
            if r:
                return True
            if r is False:
                rejected = False
        return rejected

    @property
    def date_published(self) -> datetime | None:
        date_published: datetime | None = None
        for cve_entry in self._iterate_cve_entries():
            entry_date = cve_entry.date_published
            if entry_date and ((not date_published) or (entry_date < date_published)):
                date_published = entry_date
        return date_published

    @property
    def date_modified(self) -> datetime | None:
        last_modified: datetime | None = None
        for cve_entries in self._cve_db_entries:
            for cve_entry in cve_entries:
                entry_date = cve_entry.date_modified
                if entry_date and ((not last_modified) or (entry_date > last_modified)):
                    last_modified = entry_date
            if last_modified:
                return last_modified
        return None

    def _iterate_cve_entries(self) -> Generator[CveDbEntry, None, None]:
        for cve_entries in self._cve_db_entries:
            yield from cve_entries

    @property
    def description(self) -> str | None:
        for cve_entry in self._iterate_cve_entries():
            desc = cve_entry.description
            if desc:
                return desc
        return None

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        """
        Provides version ranges from the highest priority of CVE database entry
        (excluding annotation)
        """
        vers_ranges: list[SemVerRange] = []

        for cve_entries in self._cve_db_entries:
            for cve_entry in cve_entries:
                if not cve_entry.is_annotation():
                    vers_ranges.extend(
                        cve_entry.get_associated_sem_ver_ranges(comp_ids)
                    )
            if vers_ranges:
                break

        return vers_ranges

    @property
    def cvss_metrics(self) -> list[CvssMetric]:
        if self._cvss_metrics is not None:
            return self._cvss_metrics

        # Indicates the CVSS versions that were added from higher priorities
        metrics_vers: set[CvssVersion] = set()
        # We want to prioritize metrics with a source if this is the same metric
        metrics_dict: dict[tuple[Any, ...], CvssMetric] = {}

        for cve_entries in self._cve_db_entries:
            # Indicates the CVSS versions that were added for this database priority
            prio_vers: set[CvssVersion] = set()
            for cve_entry in cve_entries:
                for metric in cve_entry.cvss_metrics:
                    cmp_key = metric.cmp_key()
                    # If this CVSS version was not added in previous higher priorities
                    if metric.cvss_ver not in metrics_vers:
                        prev_metric = metrics_dict.get(cmp_key)
                        if (prev_metric is None) or (prev_metric.source is None):
                            metrics_dict[cmp_key] = metric
                            prio_vers.add(metric.cvss_ver)
            metrics_vers.update(prio_vers)

        self._cvss_metrics = list(metrics_dict.values())
        return self._cvss_metrics

    @property
    def external_refs(self) -> set[CveExtReference]:
        ext_refs = set()
        for cve_entry in self._iterate_cve_entries():
            ext_refs.update(cve_entry.external_refs)
        return ext_refs

    @property
    def affected_sources(self) -> set[str]:
        sources = set()
        for cve_entry in self._iterate_cve_entries():
            sources.update(cve_entry.affected_sources)
        return sources

    def _iterate_applicable_comp_ids(self) -> Generator[CompId, None, None]:
        for cve_entry in self._iterate_cve_entries():
            yield from cve_entry._iterate_applicable_comp_ids()

    def _add_obsolete_assessment(
        self,
        obs_assess: CveVexAssessment,
        obs_cve_entries: tuple[CveDbEntry, ...],
        sec_assess: CveVexAssessment,
        sec_cve_entries: tuple[CveDbEntry, ...],
        msg_tpl: str | None = None,
    ) -> None:
        self._obsolete_assessments.append(
            ObsoleteAssessment(
                obs_assess, obs_cve_entries, sec_assess, sec_cve_entries, msg_tpl
            )
        )

    def _vex_assessment_from_vers_ranges(
        self, vers_ranges: Iterable[SemVerRange]
    ) -> CveVexAssessment | None:
        is_vuln_match = False
        is_vuln_smaller = False
        is_vuln_greater = False
        is_not_vuln_match = False
        is_not_vuln_trusted = False
        is_maybe_vuln = False
        version = Version(self._comp_build.version)

        for vers_range in vers_ranges:
            s = vers_range.check_in_range(version)
            if vers_range.vulnerable:
                if s == VersRangeStatus.IN_RANGE:
                    is_vuln_match = True
                elif s == VersRangeStatus.SMALLER:
                    is_vuln_smaller = True
                elif s == VersRangeStatus.GREATER:
                    is_vuln_greater = True
            elif s == VersRangeStatus.IN_RANGE:
                is_not_vuln_match = True
                is_not_vuln_trusted = (
                    is_not_vuln_trusted or vers_range.is_not_vuln_trusted()
                )
            elif s != VersRangeStatus.NO_INFO:
                is_maybe_vuln = True

        if is_not_vuln_trusted:
            # Consider that this version was patched
            return CveVexFixedAssessment(
                vex_version="1", status_notes="version-not-in-range"
            )

        if is_vuln_match:
            # The version is within a vulnerable version range
            return CveVexAffectedAssessment(
                vex_version="1",
                action_statement="Mitigation action unknown",
                status_notes="version-in-range",
                action_statement_time=self._timestamp,
            )

        if (
            is_maybe_vuln
            and (not is_vuln_smaller)
            and (not is_vuln_greater)
            and (not is_not_vuln_match)
        ):
            # This version is maybe vulnerable: This is very unlikely to enter this
            # code path...
            return CveVexAffectedAssessment(
                vex_version="1",
                action_statement="Check if really vulnerable",
                status_notes="version-maybe-in-range",
                action_statement_time=self._timestamp,
            )

        if is_vuln_smaller and (not is_vuln_greater) and (not is_not_vuln_match):
            # Consider that this version was never impacted by this CVE (since too old)
            return CveVexOldVersNotVulnAssessment(
                vex_version="1",
                status_notes="version-not-in-range",
            )

        if is_vuln_greater or is_not_vuln_match:
            # Consider that this version was patched
            return CveVexFixedAssessment(
                vex_version="1", status_notes="version-not-in-range"
            )

        return None

    def _vex_assessment_from_compiled_sources(
        self, cve_entries: tuple[CveDbEntry, ...]
    ) -> CveVexAssessment | None:
        affected_files: set[str] = set()
        for cve_entry in cve_entries:
            affected_files.update(cve_entry.affected_sources)

        if not affected_files:
            return None

        compiled_files = self._comp_build.compiled_sources_index
        if not compiled_files:
            return None

        for affected_file in affected_files:
            name = pathlib.Path(affected_file).name
            paths = compiled_files.get(name)
            if not paths:
                continue
            p = f"/{affected_file}" if (affected_file[:1] != "/") else affected_file
            for path in paths:
                if f"/{path}".endswith(p):
                    return None

        return CveVexNotAffectedAssessment(
            vex_version="1",
            impact_statement="Code not compiled",
            status_notes="not-applicable-platform",
            impact_statement_time=self._timestamp,
            justification=CveVexJustification.VULNERABLE_CODE_NOT_PRESENT,
        )

    def _vex_assessment_from_rejected_cve(self) -> CveVexAssessment | None:
        # If the CVE is considered rejected by any databases (ignore priorities),
        # generate an assessment.
        assessment: CveVexAssessment | None = None
        rej_cve_entries: list[CveDbEntry] = []
        for cve_entries in reversed(self._cve_db_entries):
            if not cve_entries:
                continue

            if not rej_cve_entries:
                # Search if a database indicates that the CVE is rejected
                rej_cve_entries.extend(
                    cve_entry for cve_entry in cve_entries if cve_entry.is_rejected()
                )
                if rej_cve_entries:
                    assessment = CveVexRejectedAssessment(
                        vex_version="1",
                        impact_statement="CVE rejected",
                        status_notes="cve-rejected",
                        impact_statement_time=self._timestamp,
                        justification=CveVexJustification.VULNERABLE_CODE_NOT_PRESENT,
                    )
            else:
                # Verify if an annotation database requires checking for obsolete
                # assessments
                if not self._is_obsolete_check_needed(cve_entries):
                    continue

                cve_entry = cve_entries[0]
                if not isinstance(cve_entry, AnnotDbEntry):
                    continue

                assert assessment is not None
                a = cve_entry.vex_assessment
                if a is not None:
                    self._add_obsolete_assessment(
                        a,
                        cve_entries,
                        assessment,
                        tuple(rej_cve_entries),
                        "{cve_id} assessment {obs_assess}, from {obs_db_name}, "
                        "is obsolete since CVE is rejected by {sec_db_name}",
                    )
        return assessment

    @staticmethod
    def _is_obsolete_check_needed(cve_entries: tuple[CveDbEntry, ...]) -> bool:
        # Indicates if the obsolescence of the assessment, generated from these
        # database entries, needs to be verified. Also check if this group of CVE
        # entries contains annotation or CVE database entries and there are no mix up.
        is_annotation: bool | None = None
        obsolete_check: bool = False

        for cve_entry in cve_entries:
            obsolete_check = (
                obsolete_check or cve_entry.database.obsolete_assessment_check_enabled
            )
            entry_is_annot = cve_entry.is_annotation()
            if is_annotation is None:
                is_annotation = entry_is_annot
            elif is_annotation and entry_is_annot:
                raise RuntimeError(
                    "Cannot have multiple annotation databases with same priority"
                )
            elif is_annotation != entry_is_annot:
                raise RuntimeError(
                    "Cannot mix annotation with CVE database entry in the same priority"
                )

        assert is_annotation is not None
        return obsolete_check

    def _compute_assessment_from_cve_entries(
        self, cve_entries: tuple[CveDbEntry, ...], obsolete_check: bool
    ) -> tuple[CveVexAssessment | None, bool]:
        assessment: CveVexAssessment | None = None

        cve_entry = cve_entries[0]
        if isinstance(cve_entry, AnnotDbEntry):
            # If this is an annotation, just provide the annotation VEX assessment
            assessment = cve_entry.vex_assessment
        else:
            # For CVE database entries, version ranges need to be merged
            vers_ranges: list[SemVerRange] = []
            for cve_entry in cve_entries:
                vers_ranges.extend(
                    cve_entry.get_associated_sem_ver_ranges(
                        self._comp_build.identifiers
                    )
                )
            if vers_ranges:
                assessment = self._vex_assessment_from_vers_ranges(vers_ranges)

        # If no assessment was computed or if the component is vulnerable
        if (assessment is None) or assessment.status.is_vulnerable():
            # Then, if the CVE provides affected sources and if the components provide
            # compiled sources files, use that to generate an assessment that indicates
            # that the components are not affected
            a = self._vex_assessment_from_compiled_sources(cve_entries)
            if a is not None:
                if obsolete_check and (assessment is not None):
                    # Indicates that the previously obtained assessment is obsolete,
                    # since affected sources are not compiled
                    self._add_obsolete_assessment(
                        assessment,
                        cve_entries,
                        a,
                        cve_entries,
                        "{cve_id} assessment {obs_assess}, from {obs_db_name}, "
                        "is obsolete since affected sources are not compiled",
                    )
                    # There is no need to continue to check for obsolete assessments
                    obsolete_check = False
                assessment = a

        return assessment, (obsolete_check if assessment is not None else False)

    def _compute_assessment(self) -> None:
        # First check if the CVE is rejected, which is a special case
        assessment = self._vex_assessment_from_rejected_cve()
        if assessment is not None:
            self._assessment = assessment
            return

        # Variables associated with the computation of obsolete assessments
        compute_next_assess: bool = True
        prev_cve_entries: tuple[CveDbEntry, ...] = ()
        prev_assessment: CveVexAssessment | None = None

        # Next, iterate through each database priority (starting from the highest)
        for cve_entries in self._cve_db_entries:
            if not cve_entries:
                continue

            obsolete_check = self._is_obsolete_check_needed(cve_entries)
            if compute_next_assess or obsolete_check:
                a, obsolete_check = self._compute_assessment_from_cve_entries(
                    cve_entries, obsolete_check
                )
                # Keep only the first computed assessment
                if assessment is None:
                    assessment = a

                # Check if we need to compute next assessment
                if obsolete_check:
                    compute_next_assess = True
                elif a is not None:
                    compute_next_assess = False

                # Verify if previously computed assessment is not obsolete
                if (prev_assessment is not None) and (a is not None):
                    if (
                        prev_assessment.status.is_vulnerable()
                        == a.status.is_vulnerable()
                    ):
                        self._add_obsolete_assessment(
                            prev_assessment, prev_cve_entries, a, cve_entries
                        )
                    prev_cve_entries = ()
                    prev_assessment = None

                if obsolete_check:
                    prev_cve_entries = cve_entries
                    prev_assessment = a

        # If there is no assessment, provide a default one
        if assessment is None:
            assessment = CveVexMissingVersionsAssessment(
                vex_version="1",
                action_statement="Check package version",
                status_notes="no-version-ranges",
                action_statement_time=self._timestamp,
            )
        self._assessment = assessment

    @property
    def vex_assessment(self) -> CveVexAssessment:
        if self._assessment is None:
            self._compute_assessment()
        assert self._assessment is not None
        return self._assessment

    @property
    def obsolete_assessments(self) -> list[ObsoleteAssessment]:
        if self._assessment is None:
            self._compute_assessment()
        return self._obsolete_assessments
