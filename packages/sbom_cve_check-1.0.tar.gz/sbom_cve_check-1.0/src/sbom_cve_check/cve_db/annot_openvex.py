# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import json
import pathlib
from collections.abc import Generator
from datetime import datetime
from typing import Any

from ..utils import parsing
from ..vuln.cpe import Cpe23
from ..vuln.cve import (
    CveId,
    CveVexAffectedAssessment,
    CveVexAssessment,
    CveVexFixedAssessment,
    CveVexJustification,
    CveVexNotAffectedAssessment,
    CveVexStatus,
    CveVexUnderInvestigationAssessment,
)
from .annot_base import AnnotDbEntry
from .db_base import CveDatabase, CveDatabaseT
from .db_git import GitAnnotDatabase
from .registry import register_cve_db


def cve_vex_justification_from_str(s: str | None) -> CveVexJustification | None:
    map_justification: dict[str, CveVexJustification] = {
        "component_not_present": CveVexJustification.COMPONENT_NOT_PRESENT,
        "vulnerable_code_not_present": CveVexJustification.VULNERABLE_CODE_NOT_PRESENT,
        "inline_mitigations_already_exist":
            CveVexJustification.INLINE_MITIGATIONS_ALREADY_EXIST,
        "vulnerable_code_cannot_be_controlled_by_adversary":
            CveVexJustification.VULNERABLE_CODE_CANNOT_BE_CONTROLLED_BY_ADVERSARY,
        "vulnerable_code_not_in_execute_path":
            CveVexJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH,
    }  # fmt: skip

    return map_justification.get(s) if s else None


class OpenVexAnnotEntry(AnnotDbEntry):
    """Represent one OpenVEX statement"""

    def __init__(
        self,
        parent_db: CveDatabase,
        json_obj: dict[str, Any],
        doc_timestamp: datetime | None = None,
    ) -> None:
        super().__init__(parent_db)
        self._json = json_obj
        self._doc_timestamp = doc_timestamp

    @property
    def identifier(self) -> CveId:
        return CveId(self._json.get("vulnerability", {}).get("name"))

    @property
    def date_modified(self) -> datetime | None:
        return parsing.datetime_from_iso_format(self._json.get("last_updated"))

    @property
    def description(self) -> str | None:
        d = self._json.get("vulnerability", {}).get("description")
        return d if isinstance(d, str) else None

    @property
    def vex_assessment(self) -> CveVexAssessment | None:
        version = self._json.get("version")
        notes = self._json.get("status_notes")
        status = CveVexStatus(self._json.get("status"))
        timestamp = (
            parsing.datetime_from_iso_format(self._json.get("timestamp"))
            or self._doc_timestamp
        )

        if status == CveVexStatus.NOT_AFFECTED:
            statement = self._json.get("impact_statement", "")
            justification = self._json.get("justification")

            return CveVexNotAffectedAssessment(
                vex_version=version,
                status_notes=notes,
                impact_statement=statement,
                impact_statement_time=timestamp,
                justification=cve_vex_justification_from_str(justification),
            )

        if status == CveVexStatus.AFFECTED:
            statement = self._json.get("action_statement", "")
            statement_time = self._json.get("action_statement_timestamp")
            if not statement_time:
                statement_time = timestamp
            return CveVexAffectedAssessment(
                vex_version=version,
                status_notes=notes,
                action_statement=statement,
                action_statement_time=statement_time,
            )

        if status == CveVexStatus.FIXED:
            return CveVexFixedAssessment(vex_version=version, status_notes=notes)

        if status == CveVexStatus.UNDER_INVESTIGATION:
            return CveVexUnderInvestigationAssessment(
                vex_version=version, status_notes=notes
            )

        return None

    def _iterate_cpes(self, pkg: Any) -> Generator[Cpe23, None, None]:
        for product in self._json.get("products", []):
            cpe = Cpe23.parse(product.get("identifiers", {}).get("cpe23"))
            if cpe:
                yield cpe


@register_cve_db("openvex-dir")
class OpenVexAnnotDatabase(GitAnnotDatabase):
    @classmethod
    def create_from_config(cls: type[CveDatabaseT], **kwargs: Any) -> CveDatabaseT:
        parsing.update_list_param(kwargs, "globs", required=True)
        return super().create_from_config(**kwargs)

    def __init__(
        self, path: pathlib.Path, name: str, globs: list[str], **kwargs: Any
    ) -> None:
        super().__init__(path, name, **kwargs)
        self._vex_globs = globs
        self._statements: dict[CveId, OpenVexAnnotEntry] = {}

    def iterate_file_statements(
        self, path_vex: pathlib.Path
    ) -> Generator[OpenVexAnnotEntry, None, None]:
        with path_vex.open(encoding="utf-8") as f:
            doc = json.load(f)
            doc_timestamp = parsing.datetime_from_iso_format(doc.get("timestamp"))
            for s in doc.get("statements", []):
                yield OpenVexAnnotEntry(self, s, doc_timestamp)

    def _iterate_vex_files(self) -> Generator[pathlib.Path, None, None]:
        """Iterate over all VEX files managed by this database"""
        for vex_glob in self._vex_globs:
            yield from self._db_dir.glob(vex_glob)

    def _initialize(self) -> None:
        self._statements.clear()
        for path_json in self._iterate_vex_files():
            for a in self.iterate_file_statements(path_json):
                if a.identifier.id in self._statements:
                    raise RuntimeError(
                        f"Multiple statements for the same CVE: {a.identifier.id}"
                    )
                self._statements[a.identifier] = a

    def _get_index_cache_invalidation_data(self) -> bytes:
        return str(self._vex_globs).encode()

    def get_cve(self, cve_id: CveId) -> OpenVexAnnotEntry | None:
        return self._statements.get(cve_id)

    def iterate_cves(self) -> Generator[OpenVexAnnotEntry, None, None]:
        yield from self._statements.values()


@register_cve_db("openvex-file")
class OpenVexFileAnnotDatabase(OpenVexAnnotDatabase):
    @classmethod
    def create_from_config(cls: type[CveDatabaseT], **kwargs: Any) -> CveDatabaseT:
        kwargs["globs"] = []
        return super().create_from_config(**kwargs)

    def __init__(self, path: pathlib.Path, name: str, **kwargs: Any) -> None:
        kwargs.pop("globs", None)
        super().__init__(path.parent, name, globs=[path.name], **kwargs)
