# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import json
import pathlib
from collections.abc import Generator, Iterable
from datetime import UTC, datetime
from typing import Any

from ..sbom.component import CompId
from ..utils import parsing
from ..vuln.cpe import Cpe23
from ..vuln.cve import (
    CveId,
    CveVexAffectedAssessment,
    CveVexAssessment,
    CveVexFixedAssessment,
    CveVexJustification,
    CveVexNotAffectedAssessment,
)
from ..vuln.cvss import CvssMetric, CvssVersion
from ..vuln.version import SemVerRange
from .annot_base import AnnotDatabase, AnnotDbEntry
from .db_base import CveDatabase
from .registry import register_cve_db


class YoctoAnnotEntry(AnnotDbEntry):
    """Represent one Yocto statement"""

    def __init__(
        self,
        parent_db: CveDatabase,
        pkg_obj: dict[str, Any],
        issue_obj: dict[str, Any],
        doc_timestamp: datetime,
    ) -> None:
        super().__init__(parent_db)
        self._pkg_obj = pkg_obj
        self._issue_obj = issue_obj
        self._timestamp = (
            parsing.datetime_from_iso_format(self._issue_obj.get("modified"))
            or doc_timestamp
        )

    @property
    def identifier(self) -> CveId:
        return CveId(self._issue_obj["id"])

    @property
    def date_modified(self) -> datetime | None:
        return self._timestamp

    @property
    def description(self) -> str | None:
        return self._issue_obj.get("summary")

    @property
    def cvss_metrics(self) -> list[CvssMetric]:
        vect: str | None = self._issue_obj.get("vectorString")
        if not vect:
            return []

        score_str: str | None = self._issue_obj.get("scorev4")
        if score_str and score_str != "0.0" and vect.startswith("CVSS:4.0/"):
            score = float(score_str)
            sev = CvssMetric.compute_severity_from_score(score)
            return [CvssMetric(CvssVersion.V4_0, score, vect, sev)]

        score_str = self._issue_obj.get("scorev3")
        if score_str and score_str != "0.0":
            score = float(score_str)
            sev = CvssMetric.compute_severity_from_score(score)
            if vect.startswith("CVSS:3.1/"):
                return [CvssMetric(CvssVersion.V3_1, score, vect, sev)]
            if vect.startswith("CVSS:3.0/"):
                return [CvssMetric(CvssVersion.V3_0, score, vect, sev)]

        score_str = self._issue_obj.get("scorev2")
        if score_str and score_str != "0.0":
            score = float(score_str)
            return [CvssMetric(CvssVersion.V2_0, score, vect)]

        return []

    def _get_patch_files_msg(self, detail: str | None) -> str | None:
        if detail != "fix-file-included":
            return None

        files = self._issue_obj.get("patch-file")
        if not files:
            return None

        lst_files: list[str] = []
        if isinstance(files, str):
            lst_files.append(pathlib.Path(files).name)
        elif isinstance(files, list):
            lst_files.extend(pathlib.Path(f).name for f in files)

        return f"Fixed by: {lst_files}" if lst_files else None

    @property
    def vex_assessment(self) -> CveVexAssessment | None:
        status = self._issue_obj.get("status")
        detail = self._issue_obj.get("detail")
        description = self._issue_obj.get("description")

        if status == "Patched":
            patches = self._get_patch_files_msg(detail)
            return CveVexFixedAssessment(
                status_notes=": ".join(v for v in (detail, description, patches) if v)
            )

        if status == "Unpatched":
            return CveVexAffectedAssessment(
                status_notes=": ".join(v for v in (detail, description) if v),
                action_statement="Mitigation action unknown",
                action_statement_time=self._timestamp,
            )

        if status == "Ignored":
            justification = None
            if detail == "cpe-incorrect":
                justification = CveVexJustification.COMPONENT_NOT_PRESENT
            elif detail == "disputed":
                justification = CveVexJustification.VULNERABLE_CODE_NOT_PRESENT
            elif detail in ("not-applicable-config", "not-applicable-platform"):
                justification = CveVexJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH

            return CveVexNotAffectedAssessment(
                status_notes=detail,
                impact_statement=description or "",
                impact_statement_time=self._timestamp,
                justification=justification,
            )

        return None

    def _iterate_cpes(self, pkg: Any) -> Generator[Cpe23, None, None]:
        for cpe_str in self._pkg_obj.get("cpes", []):
            cpe = Cpe23.parse(cpe_str)
            if cpe:
                yield cpe

    def get_associated_sem_ver_ranges(
        self, comp_ids: Iterable[CompId]
    ) -> Iterable[SemVerRange]:
        return self._get_associated_sem_ver_ranges(
            comp_ids, self._pkg_obj.get("version")
        )


@register_cve_db("yocto-vex-manifest")
class YoctoAnnotDatabase(AnnotDatabase):
    def __init__(self, path: pathlib.Path, name: str, **kwargs: Any) -> None:
        super().__init__(name, **kwargs)
        self._manifest_file = path.resolve(strict=True)
        self._statements: dict[CveId, YoctoAnnotEntry] = {}

    def _initialize(self) -> None:
        self._statements.clear()

        with self._manifest_file.open(encoding="utf-8") as f:
            doc = json.load(f)

        doc_timestamp = datetime.fromtimestamp(
            self._manifest_file.stat().st_mtime, tz=UTC
        )

        for pkg in doc.get("package", []):
            for issue in pkg.get("issue", []):
                a = YoctoAnnotEntry(self, pkg, issue, doc_timestamp)
                if a.identifier.id in self._statements:
                    raise RuntimeError(
                        f"Multiple statements for the same CVE: {a.identifier.id}"
                    )
                self._statements[a.identifier] = a

    def get_cve(self, cve_id: CveId) -> YoctoAnnotEntry | None:
        return self._statements.get(cve_id)

    def iterate_cves(self) -> Generator[YoctoAnnotEntry, None, None]:
        yield from self._statements.values()
