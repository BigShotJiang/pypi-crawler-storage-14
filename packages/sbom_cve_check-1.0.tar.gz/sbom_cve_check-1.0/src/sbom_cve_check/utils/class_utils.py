# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

from typing import Any, ClassVar, TypeVar

_SingletonT = TypeVar("_SingletonT")


class Singleton(type):
    """
    Implement the Singleton design pattern, restricting children classes to
    having a single instance.
    """

    __instances: ClassVar[dict[Any, "Singleton"]] = {}

    def __call__(cls: type[_SingletonT], *args: Any, **kwargs: Any) -> _SingletonT:
        if not isinstance(cls, Singleton):
            raise TypeError("Not a Singleton metaclass")
        if cls not in cls.__instances:
            cls.__instances[cls] = super().__call__(*args, **kwargs)
        return cls.__instances[cls]
