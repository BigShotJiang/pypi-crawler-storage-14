# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import pathlib
import subprocess
from datetime import UTC, datetime


class GitRepo:
    def __init__(self, git_dir: pathlib.Path, remote_name: str = "origin") -> None:
        self._remote = remote_name
        self._git_dir = git_dir
        self._git_exe: str = "git"

    @property
    def path(self) -> pathlib.Path:
        return self._git_dir

    def _exec_git_cmd(self, args: list[str]) -> subprocess.CompletedProcess[str]:
        cmd = [self._git_exe]
        cmd.extend(args)
        return subprocess.run(
            cmd,
            input="",
            capture_output=True,
            check=True,
            cwd=self._git_dir,
            encoding="utf-8",
        )

    def is_git_repo(self) -> bool:
        return self._git_dir.joinpath(".git", "HEAD").is_file()

    def get_fetch_url(self) -> str | None:
        r = self._exec_git_cmd(["config", "--get", f"remote.{self._remote}.url"])
        return r.stdout.strip()

    def is_shallow_repository(self) -> bool:
        r = self._exec_git_cmd(["rev-parse", "--is-shallow-repository"])
        return r.stdout.strip() == "true"

    def resolve_sha_ref(self, ref: str) -> str | None:
        try:
            r = self._exec_git_cmd(["rev-parse", "--verify", ref + "^{object}"])
            return r.stdout.strip()
        except subprocess.CalledProcessError:
            return None

    def is_valid_object(self, ref: str) -> bool:
        try:
            self._exec_git_cmd(["cat-file", "-e", ref + "^{object}"])
        except subprocess.CalledProcessError:
            return False
        else:
            return True

    def get_current_branch(self) -> str | None:
        try:
            r = self._exec_git_cmd(["rev-parse", "--abbrev-ref", "HEAD"])
            return r.stdout.strip()
        except subprocess.CalledProcessError:
            return None

    def get_default_remote_branch(self) -> str | None:
        try:
            r = self._exec_git_cmd(
                ["symbolic-ref", "--short", f"refs/remotes/{self._remote}/HEAD"]
            )
            branch = r.stdout.strip()
            remote_prefix = f"{self._remote}/"
            if branch.startswith(remote_prefix):
                len_prefix = len(remote_prefix)
                return branch[len_prefix:]
        except subprocess.CalledProcessError:
            pass
        return None

    def update_default_remote_branch(self) -> str:
        self._exec_git_cmd(["remote", "set-head", self._remote, "--auto"])
        b = self.get_default_remote_branch()
        if not b:
            raise RuntimeError(f"Default branch not found for {self._git_dir}")
        return b

    def get_date_last_commit(self) -> datetime:
        """
        Get the commiter date time of last commit (HEAD) from the git repository.
        """
        r = self._exec_git_cmd(["show", "-s", "--format=%ci", "HEAD"])
        lastest_commit_date = r.stdout.strip()
        return datetime.fromisoformat(lastest_commit_date).astimezone(UTC)

    def get_date_last_update(self) -> datetime | None:
        """
        Get the date time of last database update.

        Get the modification date time of .git/ORIG_HEAD.
        Return None if the database does not exist yet.
        """
        orig_head = self._git_dir.joinpath(".git", "ORIG_HEAD")
        if not orig_head.is_file():
            return None
        return datetime.fromtimestamp(orig_head.stat().st_mtime, UTC)

    def clone(self, url: str, branch: str | None, depth: int = 0) -> None:
        cmd = ["clone"]
        if depth > 0:
            cmd.extend(["--depth", str(depth)])
        if branch:
            cmd.extend(["--single-branch", "-b", branch])
        cmd.append(url)
        cmd.append(".")

        self._git_dir.mkdir(parents=True, exist_ok=True)
        self._exec_git_cmd(cmd)

    def fetch(self, branch: str, unshallow: bool = False, depth: int = 0) -> None:
        cmd = ["fetch", "-f"]
        if depth > 0:
            cmd.extend(["--depth", str(depth)])
        if unshallow:
            cmd.append("--unshallow")
        cmd.append(self._remote)
        cmd.append(f"refs/heads/{branch}:refs/remotes/{self._remote}/{branch}")
        self._exec_git_cmd(cmd)

    def switch_force_create_branch(self, branch: str, discard_changes: bool) -> None:
        cmd = ["switch"]
        if discard_changes:
            cmd.append("-f")
        cmd.extend(["-C", branch, f"{self._remote}/{branch}"])
        self._exec_git_cmd(cmd)

    def switch_detach_head(self, ref: str, discard_changes: bool) -> None:
        cmd = ["switch"]
        if discard_changes:
            cmd.append("-f")
        cmd.extend(["--detach", ref])
        self._exec_git_cmd(cmd)
