# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import importlib
import importlib.machinery
import importlib.util
import logging
import pathlib
import pkgutil
import sys

_logger = logging.getLogger(__name__)


def import_builtin_plugin(pkg: str, mod: str) -> None:
    try:
        importlib.import_module(mod, pkg)
    except ImportError as e:
        _logger.debug("Fail to load %s%s builtin plugin: %s", pkg, mod, str(e))


def _load_plugin(spec: importlib.machinery.ModuleSpec | None, pkg_name: str) -> None:
    if spec is not None:
        plugin = importlib.util.module_from_spec(spec)
        if plugin is not None:
            sys.modules[pkg_name] = plugin
            if spec.loader is not None:
                try:
                    spec.loader.exec_module(plugin)
                except ImportError as e:
                    _logger.debug(
                        "Fail to load %s builtin plugin: %s", pkg_name, str(e)
                    )


def import_external_plugin(search_path: set[pathlib.Path]) -> None:
    plugin_namespace = f"{__package__}.plugins"
    if sys.modules.get(plugin_namespace) is None:
        ns_spec = importlib.machinery.ModuleSpec(
            plugin_namespace, None, is_package=True
        )
        _load_plugin(ns_spec, plugin_namespace)

    for search_pkg in [
        p for p in search_path if (p.is_dir() and p.joinpath("__init__.py").is_file())
    ]:
        search_path.remove(search_pkg)
        finder_pkg = pkgutil.get_importer(str(search_pkg.parent))
        if finder_pkg is not None:
            pkg_name = f"{plugin_namespace}.{search_pkg.name}"
            _load_plugin(finder_pkg.find_spec(pkg_name), pkg_name)

    for search_file in [p for p in search_path if (p.is_file() and p.suffix != ".zip")]:
        search_path.remove(search_file)
        pkg_name = f"{plugin_namespace}.{search_file.stem}"
        _load_plugin(
            importlib.util.spec_from_file_location(pkg_name, search_file), pkg_name
        )

    # noinspection PyTypeChecker
    for finder, name, _ in pkgutil.iter_modules(search_path):
        pkg_name = f"{plugin_namespace}.{name}"
        _load_plugin(finder.find_spec(pkg_name), pkg_name)  # type: ignore[call-arg]
