# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

from collections.abc import Callable
from configparser import ConfigParser
from datetime import UTC, datetime, timedelta
from typing import Any, TypeVar

__DURATION_MULTIPLIER = {
    "seconds": 1.0,
    "second": 1.0,
    "sec": 1.0,
    "s": 1.0,
    "minutes": 60.0,
    "minute": 60.0,
    "min": 60.0,
    "months": 2629800.0,
    "month": 2629800.0,
    "M": 2629800.0,
    "msec": 1.0e-3,
    "ms": 1.0e-3,
    "m": 60.0,
    "hours": 3600.0,
    "hour": 3600.0,
    "hr": 3600.0,
    "h": 3600.0,
    "days": 86400.0,
    "day": 86400.0,
    "d": 86400.0,
    "weeks": 604800.0,
    "week": 604800.0,
    "w": 604800.0,
}

_ParamT = TypeVar("_ParamT")


def parse_duration(v: object) -> timedelta:
    unit = "s"
    if isinstance(v, (int, float)):
        val = float(v)
    elif isinstance(v, str):
        idx_unit = next(
            (i for i, ch in enumerate(v) if not (ch.isdigit() or ch == ".")), -1
        )
        if idx_unit == 0:
            raise ValueError(f"Invalid duration: {v}")

        if idx_unit < 0:
            val = float(v.strip())
        else:
            val = float(v[:idx_unit].strip())
            unit = v[idx_unit:].strip()
    else:
        raise TypeError(f"Invalid duration type: {v}")

    multiplier = __DURATION_MULTIPLIER.get(unit)
    if not multiplier:
        raise ValueError(f"Invalid duration suffix: {v}")

    return timedelta(seconds=val * multiplier)


def parse_boolean(v: object) -> bool:
    """Parse the given value as a boolean. Currently, supports integers or strings."""
    b = None
    if isinstance(v, str):
        b = ConfigParser.BOOLEAN_STATES.get(v.lower())
    elif isinstance(v, int) and (v in {0, 1}):
        b = bool(v)

    if b is None:
        raise ValueError(f"Invalid boolean value: {v}")
    return b


def parse_list(v: object) -> list[str]:
    if not isinstance(v, str):
        raise TypeError(f"Cannot parse list, not a string: {v}")
    return [v.strip() for v in v.split(",")]


def _update_param_value(
    args: dict[str, Any],
    cfg_name: str,
    new_name: str | None,
    required: bool,
    param_type: type[_ParamT],
    parse_fn: Callable[[Any], _ParamT | None],
) -> None:
    """
    Low-level helper to update the parameter `cfg_name` in `args`,
    optionally under `new_name`.
    If the value in `args`'s `cfg_name` is not of type `param_type`, use
    `parse_fn` to convert it.
    """
    v = args.pop(cfg_name, None)
    if v is None:
        if required:
            raise ValueError(f"Missing {cfg_name} {param_type.__name__} parameter")
        return

    args[new_name or cfg_name] = v if isinstance(v, param_type) else parse_fn(v)


def update_boolean_param(
    args: dict[str, Any],
    cfg_name: str,
    new_name: str | None = None,
    required: bool = False,
) -> None:
    _update_param_value(args, cfg_name, new_name, required, bool, parse_boolean)


def update_integer_param(
    args: dict[str, Any],
    cfg_name: str,
    new_name: str | None = None,
    required: bool = False,
) -> None:
    _update_param_value(args, cfg_name, new_name, required, int, int)


def update_timedelta_param(
    args: dict[str, Any],
    cfg_name: str,
    special_vals: dict[str, timedelta | None],
    new_name: str | None = None,
    required: bool = False,
) -> None:
    def _parse_duration(s: str) -> timedelta | None:
        if s in special_vals:
            return special_vals[s]
        return parse_duration(s)

    _update_param_value(args, cfg_name, new_name, required, timedelta, _parse_duration)


def update_list_param(
    args: dict[str, Any],
    cfg_name: str,
    new_name: str | None = None,
    required: bool = False,
) -> None:
    _update_param_value(args, cfg_name, new_name, required, list, parse_list)


def datetime_from_iso_format(s: str | None) -> datetime | None:
    if not s:
        return None

    d = datetime.fromisoformat(s)
    if not d.tzinfo:
        return d.replace(tzinfo=UTC, microsecond=0)
    return d.replace(microsecond=0)
