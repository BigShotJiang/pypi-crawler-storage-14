# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-only

import os
from datetime import UTC, datetime

from .class_utils import Singleton


class ReproducibleDateTime(metaclass=Singleton):
    def __init__(self) -> None:
        self._now = self._get_now()

    @staticmethod
    def _get_now() -> datetime:
        src_date_epoch = os.environ.get("SOURCE_DATE_EPOCH")
        if src_date_epoch is not None:
            return datetime.fromtimestamp(int(src_date_epoch), tz=UTC)
        return datetime.now(UTC)

    @property
    def now(self) -> datetime:
        return self._now
