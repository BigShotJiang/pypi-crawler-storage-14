# -*- coding: utf-8 -*-
# PYTHON_ARGCOMPLETE_OK
# SPDX-License-Identifier: GPL-2.0-only

import argparse
import logging
import os
import pathlib
import tomllib
from collections import defaultdict
from collections.abc import Sequence
from typing import Any, no_type_check

from . import __version__
from .cve_db.annot_base import AnnotDatabase
from .cve_db.annot_yocto import YoctoAnnotDatabase
from .cve_db.db_base import CveDatabase
from .cve_db.manager import CveDbManager
from .cve_db.registry import DbTypeRegistry
from .export.manager import ExportManager
from .export.registry import ExportTypeRegistry
from .sbom.registry import SbomTypeRegistry
from .utils.plugin import import_external_plugin
from .vuln.cve import CveVexStatus


def load_plugins(
    cfgs_plugins: list[pathlib.Path], args_plugins: list[pathlib.Path]
) -> None:
    search_path = {p.resolve() for p in args_plugins}
    search_path.update(cfgs_plugins)
    plugins_env = os.environ.get("SBOM_CVE_CHECK_PLUGINS")
    if plugins_env:
        search_path.update(pathlib.Path(p).resolve() for p in plugins_env.split(":"))

    import_external_plugin(search_path)


def resolve_config_path(
    path_to_resolve: str, path_start_file: str | pathlib.Path
) -> pathlib.Path:
    path_to_resolve = os.path.expandvars(path_to_resolve)
    ret_path = pathlib.Path(path_to_resolve).expanduser()
    if ret_path.is_absolute():
        return ret_path.resolve()
    return pathlib.Path(path_start_file).parent.joinpath(path_to_resolve).resolve()


def create_database(
    from_config: bool,
    cfg_idx: int,
    db_type: str | type[CveDatabase],
    path: pathlib.Path,
    section_name: str | None = None,
    **kwargs: Any,
) -> tuple[CveDatabase, int]:
    prio_str: str | None = kwargs.pop("priority", None)
    name = kwargs.pop("name", None)
    if name is None:
        name = section_name
    if name is None:
        name = path.name

    if isinstance(db_type, str):
        db = DbTypeRegistry().create_from_config(
            db_type, name=name, path=path, **kwargs
        )
    else:
        db = db_type.create_from_config(name=name, path=path, **kwargs)

    if prio_str is None:
        priority = db.get_default_priority(from_config=from_config, order=cfg_idx)
    else:
        priority = int(prio_str)

    return db, priority


def get_config_file_paths(args: argparse.Namespace) -> list[pathlib.Path]:
    # Get the list of toml configuration files to read
    cfg_files: list[pathlib.Path] = []
    if not args.ignore_default_config:
        cfg_files.append(resolve_config_path("db_default.toml", __file__))
    if args.config:
        cfg_files.extend(args.config)
    return cfg_files


def parse_early_config(cfg_files: list[pathlib.Path]) -> argparse.Namespace:
    cfg = argparse.Namespace()

    plugin_paths: list[pathlib.Path] = []
    cfg.plugins = plugin_paths

    # Read configuration file and extract the plugin paths
    for cfg_file_path in cfg_files:
        with cfg_file_path.open("rb") as f:
            toml_data = tomllib.load(f)

        paths = toml_data.get("plugins", [])
        if isinstance(paths, str):
            paths = [paths]
        plugin_paths.extend(resolve_config_path(p, cfg_file_path) for p in paths)

    return cfg


def parse_config(cve_db_manager: CveDbManager, cfg_files: list[pathlib.Path]) -> None:
    # Read configuration files, and merge overrides
    databases_values: dict[str, dict[str, Any]] = defaultdict(dict)
    for cfg_file_path in cfg_files:
        with cfg_file_path.open("rb") as f:
            toml_data = tomllib.load(f)

        db_sections: dict[str, dict[str, Any]] = toml_data.get("databases", {})
        for section_name, db_values in db_sections.items():
            # Resolve relative database path
            path_str: str | None = db_values.pop("path", None)
            if path_str:
                db_values["path"] = resolve_config_path(path_str, cfg_file_path)

            # Merge configurations
            databases_values[section_name].update(db_values)

    # Create each declared databases
    for idx, (section_name, db_values) in enumerate(databases_values.items()):
        type_name: str | None = db_values.pop("type", None)
        if type_name is None:
            raise ValueError(f"[{section_name}] database type is missing")
        if type_name not in DbTypeRegistry().type_names:
            raise ValueError(f"[{section_name}] invalid database type: {type_name}")

        path: pathlib.Path | None = db_values.pop("path", None)
        if not path:
            raise ValueError(f"[{section_name}] database path is missing")

        db, prio = create_database(
            True, idx, type_name, path, section_name=section_name, **db_values
        )
        cve_db_manager.add_db(db, prio)


def create_databases_from_args(
    cve_db_manager: CveDbManager,
    db_args: list[tuple[str, pathlib.Path, dict[str, str]]],
) -> None:
    for idx, db_info in enumerate(db_args):
        db, prio = create_database(
            False, idx + 50, db_info[0], db_info[1], section_name=None, **db_info[2]
        )
        cve_db_manager.add_db(db, prio)


def handle_autocomplete(parser: argparse.ArgumentParser) -> None:
    try:
        import argcomplete  # noqa: PLC0415

        argcomplete.autocomplete(parser)
    except ImportError:
        pass


class DbConfigAction(argparse.Action):
    # noinspection PyShadowingBuiltins
    def __init__(
        self,
        option_strings: Sequence[str],
        dest: str,
        required: bool = False,
        help: str | None = None,  # noqa: A002
    ) -> None:
        super().__init__(
            option_strings=option_strings,
            dest=dest,
            nargs="*",
            required=required,
            help=help,
            metavar="TYPE PATH KEY=VALUE,",
        )
        self._init_autocomplete()

    @no_type_check
    def _init_autocomplete(self) -> None:
        try:
            from argcomplete.completers import FilesCompleter  # noqa: PLC0415
        except ImportError:
            return

        class DbConfigActionCompleter(FilesCompleter):
            # noinspection PyNoneFunctionAssignment
            def __call__(self, prefix: str, **kwargs: Any) -> dict[str, str]:
                # noinspection PyTypeChecker
                lst: list[str] = super().__call__(prefix, **kwargs)
                d = dict.fromkeys(lst, "File path")
                d.update((n, "Database type") for n in DbTypeRegistry().type_names)
                return d

        self.completer = DbConfigActionCompleter()

    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: str | Sequence[Any] | None,
        option_string: str | None = None,
    ) -> None:
        if not isinstance(values, Sequence) or len(values) <= 1:
            raise argparse.ArgumentError(self, "Unexpected number of arguments")

        type_name = values[0]
        if type_name not in DbTypeRegistry().type_names:
            raise argparse.ArgumentError(self, f"Invalid database type: {type_name}")

        path = pathlib.Path(values[1]).resolve()
        cfg_values = {}
        try:
            for params in values[2:]:
                k, v = params.split("=", 1)
                cfg_values[k.strip()] = v.strip()
        except ValueError as err:
            raise argparse.ArgumentError(self, str(err)) from err

        items = getattr(namespace, self.dest, None)
        if not items:
            items = []
        items.append((type_name, path, cfg_values))
        setattr(namespace, self.dest, items)


def process_early_config(parser: argparse.ArgumentParser) -> None:
    try:
        args, _ = parser.parse_known_args()
    except (argparse.ArgumentError, argparse.ArgumentTypeError):
        # The main parser should catch again the error, so just ignore the error here
        return

    # Set logging level
    levels = (logging.WARNING, logging.INFO, logging.DEBUG)
    logging.basicConfig(level=levels[min(len(levels) - 1, args.verbose)])

    # Parse configuration a first time to extract early config values
    cfg = parse_early_config(get_config_file_paths(args))

    # Inject environment variable with default value
    env_name_db_dir = "SBOM_CVE_CHECK_DATABASES_DIR"
    if args.databases_dir:
        os.environ[env_name_db_dir] = args.databases_dir.resolve().as_posix()
    elif env_name_db_dir not in os.environ:
        cache_env = os.environ.get("XDG_CACHE_HOME", "")
        if not cache_env.strip():
            cache_path = pathlib.Path("~/.cache").expanduser()
        else:
            cache_path = pathlib.Path(cache_env)
        os.environ[env_name_db_dir] = cache_path.joinpath(
            "sbom_cve_check", "databases"
        ).as_posix()

    # Load plugins from environment variable, from configuration files,
    # and from arguments
    load_plugins(cfg.plugins, args.plugins or [])


def main() -> None:
    early_p = argparse.ArgumentParser(
        add_help=False, exit_on_error=False, fromfile_prefix_chars="@"
    )
    early_p.add_argument(
        "--verbose",
        "-v",
        action="count",
        default=0,
        help="Increase logging level, can be specified multiple times",
    )
    early_p.add_argument(
        "--plugins",
        metavar="PATH",
        type=pathlib.Path,
        action="append",
        help="Path to plugin module or plugin directory",
    )
    early_p.add_argument(
        "--ignore-default-config",
        action="store_true",
        help="Do not load default database configuration",
    )
    early_p.add_argument(
        "--config",
        metavar="PATH",
        type=pathlib.Path,
        action="append",
        help="Path to one TOML configuration file",
    )
    early_p.add_argument(
        "--databases-dir",
        metavar="PATH",
        type=pathlib.Path,
        help="Path to the directory containing the databases to be downloaded. "
        "Override SBOM_CVE_CHECK_DATABASES_DIR",
    )

    parser = argparse.ArgumentParser(parents=[early_p], fromfile_prefix_chars="@")
    process_early_config(early_p)

    parser.add_argument(
        "--version", "-V", action="version", version=f"%(prog)s {__version__}"
    )

    sbom_p = parser.add_argument_group("Sbom")
    sbom_p.add_argument(
        "--sbom-type",
        "--sbom-format",
        "-F",
        choices=SbomTypeRegistry().type_names,
        help="Specify the format of the SBOM input file",
    )
    sbom_p.add_argument(
        "--sbom-path",
        "--sbom",
        "-S",
        metavar="PATH",
        required=True,
        type=pathlib.Path,
        help="Path to the SBOM input file",
    )
    sbom_p.add_argument(
        "--ignore-sbom-annotations",
        action="store_true",
        help="If set, do not load annotations from the SBOM file",
    )
    sbom_p.add_argument(
        "--sbom-annotation-priority",
        metavar="PRIO",
        type=int,
        help="Priority to use for the annotations read from SBOM input file",
    )
    sbom_p.add_argument(
        "--sbom-obsolete-assessment-check",
        action=argparse.BooleanOptionalAction,
        help="Enable or disable checks of obsolete assessments specified in SBOM",
    )

    conf_p = parser.add_argument_group("Database configuration")
    conf_p.add_argument(
        "--add-db",
        action=DbConfigAction,
        help="Allow to add CVE or annotation database from command line",
    )
    conf_p.add_argument(
        "--yocto-vex-manifest",
        metavar="PATH",
        type=pathlib.Path,
        action="append",
        help="Shortcut to specify a Yocto Vex manifest, with default configuration",
    )
    conf_p.add_argument(
        "--check-obsolete-assessment-by-default",
        action="store_true",
        help="If set, by default, check for obsolete assessment",
    )

    exp_p = parser.add_argument_group("Export file")
    exp_p.add_argument(
        "--export-type",
        "--export-format",
        "-f",
        required=True,
        action="append",
        choices=ExportTypeRegistry().type_names,
        help="Export format of generated file",
    )
    exp_p.add_argument(
        "--export-path",
        "--output",
        "-o",
        metavar="PATH",
        required=True,
        action="append",
        type=pathlib.Path,
        help="Path to the exported file",
    )

    filter_p = parser.add_argument_group("Export configuration")
    filter_p.add_argument(
        "--export-filter-vex-status",
        choices=[s.value for s in CveVexStatus if s.value is not None],
        nargs="+",
        help="Only add, in exported file, CVEs with the following VEX status",
    )
    filter_p.add_argument(
        "--export-filter-vulnerable",
        action="store_true",
        help="Only add, in exported file, CVEs which are considered vulnerable",
    )
    filter_p.add_argument(
        "--export-filter-cve-without-cvss-score",
        action="store_true",
        help="If set, do not add CVE without CVSS score, in exported file",
    )
    filter_p.add_argument(
        "--export-filter-cve-min-cvss-score",
        type=float,
        help="Only add, in exported file, CVEs with a minimum CVSS score",
    )
    filter_p.add_argument(
        "--export-filter-cve-without-versions",
        action="store_true",
        help="If set, do not add CVE without versions, in exported file",
    )
    filter_p.add_argument(
        "--export-add-kernel-modules",
        action="store_true",
        help="If set, add CVE information to kernel modules, in exported file",
    )
    filter_p.add_argument(
        "--export-list-rejected-cve",
        action="store_true",
        help="If set, list CVEs that are rejected, in exported file",
    )

    handle_autocomplete(parser)
    args = parser.parse_args()

    # First get default configuration values for databases
    AnnotDatabase.DEFAULT_OBSOLETE_ASSESSMENT_CHECK = (
        args.check_obsolete_assessment_by_default
    )
    CveDatabase.INDEX_REJECTED_CVE = args.export_list_rejected_cve

    # Check that export arguments are OK
    if len(args.export_type) != len(args.export_path):
        parser.error("Format and path must be specified for each exported file")

    # Instantiate CVE database manager to register all databases
    cve_db_manager = CveDbManager()

    # Get CVE and annotation databases
    try:
        if args.add_db:
            create_databases_from_args(cve_db_manager, args.add_db)
        parse_config(cve_db_manager, get_config_file_paths(args))

        for idx, m in enumerate(args.yocto_vex_manifest or []):
            path: pathlib.Path = m
            db, prio = create_database(False, idx + 1, YoctoAnnotDatabase, path)
            cve_db_manager.add_db(db, prio)

    except (ValueError, TypeError, FileNotFoundError) as err:
        parser.error(str(err))

    # Get input SBOM
    sbom_path: pathlib.Path = args.sbom_path
    try:
        sbom = SbomTypeRegistry().create(args.sbom_type, sbom_path.resolve(strict=True))
    except (FileNotFoundError, ValueError) as err:
        parser.error(str(err))

    # Create annotation database from SBOM
    if not args.ignore_sbom_annotations:
        sbom_annot_opts = {}
        if args.sbom_obsolete_assessment_check:
            sbom_annot_opts["obsolete_assessment_check"] = True
        elif args.sbom_obsolete_assessment_check is False:
            sbom_annot_opts["obsolete_assessment_check"] = False
        sbom_annot_db = sbom.create_annot_database(
            name=sbom_path.name, **sbom_annot_opts
        )
        if sbom_annot_db is not None:
            sbom_annot_prio: int | None = args.sbom_annotation_priority
            if sbom_annot_prio is None:
                sbom_annot_prio = sbom_annot_db.get_default_priority(
                    order=0, from_config=False
                )
            cve_db_manager.add_db(sbom_annot_db, sbom_annot_prio)

    # Initialize and Index databases
    cve_db_manager.create_index()

    # Initialize and configure export
    export_mng = ExportManager(sbom, cve_db_manager)

    for exp_type, exp_path in zip(args.export_type, args.export_path, strict=True):
        export_mng.add_exporter(ExportTypeRegistry().create(exp_type, sbom, exp_path))

    if args.export_filter_vulnerable:
        export_mng.cfg_filter_status(
            [CveVexStatus.UNDER_INVESTIGATION, CveVexStatus.AFFECTED]
        )

    if args.export_filter_vex_status:
        export_mng.cfg_filter_status(
            [CveVexStatus(n) for n in args.export_filter_vex_status]
        )

    export_mng.cfg_filter_rejected_cve(not args.export_list_rejected_cve)
    export_mng.cfg_filter_no_cvss_score(args.export_filter_cve_without_cvss_score)
    export_mng.cfg_filter_cvss_score(args.export_filter_cve_min_cvss_score)
    export_mng.cfg_filter_missing_versions(args.export_filter_cve_without_versions)
    export_mng.cfg_add_kernel_modules(args.export_add_kernel_modules)

    # And finally generate the export
    export_mng.process_export()
