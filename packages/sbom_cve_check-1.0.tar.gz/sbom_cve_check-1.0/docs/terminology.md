
# Terminology

:::{glossary}

Annotation

  A CVE Annotation is supplementary information added to an existing CVE entry
  that provides additional context—typically including an assessment of the
  vulnerability's relevance, severity, and impact.

Annotation database

  A database containing annotations for multiple CVE

Assessment

  A CVE Assessment is the process of analyzing, evaluating, and determining the
  relevance, severity, and impact of a specific CVE entry on an organization's
  systems, software, or infrastructure.

  It involves identifying whether a known vulnerability (as listed in the CVE
  database) affects the organization's assets, assessing the associated risks,
  and prioritizing appropriate remediation or mitigation actions.

BOM

  A Bill Of Materials is a list of the raw materials, subassemblies,
  intermediate assemblies, subcomponents, parts, and the quantities of each
  needed to manufacture an end product.

CPE

  Common Platform Enumeration is a standardized method used to identify and
  describe classes of applications, operating systems, and hardware devices
  within an information technology (IT) environment.

  A CPE 2.3 has typically the following format:
  `cpe:2.3:o:linux:linux_kernel:2.6.10:-:*:*:*:*:*:*`

  Where:
   - `o` is the *part*
   - `linux` is the *vendor*
   - `linux_kernel` is the *product* name

CVE

  Common Vulnerabilities and Exposures.

CVE database

  The CVE Database is a publicly available repository that provides standardized
  identifiers for known cybersecurity vulnerabilities and exposures in software
  and hardware systems. Each vulnerability is assigned a unique identifier known
  as a CVE ID.

CVSS

  The Common Vulnerability Scoring System (CVSS) is an open framework for rating
  the severity of security vulnerabilities in computing systems. Scores are
  calculated based on a formula with several metrics that approximate the ease
  and impact of an exploit.
  CVSS metrics are represented as a numeric value and also as a vector string.
  The vector string is a textual representation of the metric values used to
  determine the score.

Component

  A software artifact is composed of multiple components. A component is
  typically a package that can be installed into the device. A software
  component can generally be identified with a CPE.

JSON

  JavaScript Object Notation, is an open standard file format and data
  interchange format that uses human-readable text to store and transmit data
  objects.

JSON-LD

  JavaScript Object Notation for Linked Data is a method of encoding linked data
  using JSON and of serializing data similarly to traditional JSON.

NIST

  National Institute of Standards and Technology is an agency of the United
  States Department of Commerce.

NVD

  National Vulnerability Database is the U.S. government repository of
  standards-based vulnerability management data. NVD is managed by the U.S.
  government agency the National Institute of Standards and Technology (NIST).

OpenVEX

  OpenVEX is an implementation of the Vulnerability Exploitability Exchange
  (VEX).

SBOM

  A software bill of materials (SBOM) declares the inventory of components
  contained in a software artifact, typically the image deployed to the device.
  An SBOM can also declare the inventory of components used to build this
  software artifact.

SPDX

  System Package Data Exchange (SPDX, formerly Software Package Data Exchange)
  is an open standard capable of representing systems with digital components
  as bills of materials (BOMs)

TOML

  Tom's Obvious Minimal Language. TOML aims to be a minimal configuration file
  format that's easy to read due to obvious semantics. TOML is designed to map
  unambiguously to a hash table.

VEX

  Vulnerability Exploitability eXchange, an industry standard for describing
  software vulnerabilities and their exploitability.

FKIE

  Fraunhofer Institute for Communication, Information Processing and Ergonomics.

:::
