
# Introduction

In today's security landscape, maintaining awareness of known vulnerabilities
is essential to ensure the resilience and trustworthiness of software systems.
Every component in a software stack - from operating systems and libraries
to embedded firmware - can contain vulnerabilities that are publicly
disclosed through the Common Vulnerabilities and Exposures (CVE) system.
Regularly monitoring these CVEs allows developers and manufacturers to identify,
assess, and mitigate security risks before they can be exploited.

The adoption of Software Bills of Materials (SBOMs) has made it easier to gain
visibility into the components that make up a software product, enabling
security teams to trace dependencies and quickly identify which components are
affected by new vulnerabilities. However, having an SBOM is only part of the
solution - it must be continuously checked against current CVE data to remain
effective.

This process is becoming even more critical with emerging regulations, such as
the EU Cyber Resilience Act (CRA), which introduces mandatory cybersecurity
requirements for products with digital elements. The CRA emphasizes continuous
vulnerability management and timely patching throughout a product's lifecycle.
Regular checks for known CVEs help organizations demonstrate compliance with
these requirements and maintain a proactive security posture.

The **sbom-cve-check** tool was developed to simplify this process. It allows
users to automatically search for CVEs related to the components listed in an
SBOM. Although it was initially designed to analyze Yocto-generated SBOMs
for embedded devices, it can be used with any SBOM file (if the format is
supported) to perform vulnerability assessments outside of build environments.
This makes **sbom-cve-check** a valuable tool for developers, integrators,
and product security teams aiming to strengthen the security and compliance of
their software supply chain.

**Key Features**:
 - **Flexible Input**:

   Accepts a [SBOM](sbom.md) file as input. For now only the SPDX 2.2 and SPDX
   3.0 formats are supported, but more formats can be added very easily.

 - **Configurable CVE Sources**:

   Supports multiple [sources](cve-database.md) of vulnerability information,
   including the National Vulnerability Database (NVD), the official CVE List,
   and other custom CVE feeds that can be added.

 - **Annotation Support**:

   Can consume OpenVEX files, Yocto VEX annotations and custom annotations,
   enabling users to document and manage vulnerability assessments - such as
   confirming that a CVE does not affect a product under specific conditions.

 - **Configuration**:

   These various data [sources](cve-database.md) (CVE databases and annotations)
   are fully configurable from TOML configuration files or from the command
   line.

 - **Flexible Output**:

   Generates [exports](export.md) in multiple formats:
    - A simple CSV report for easy review or integration into reporting
      pipelines.
    - A similar format that Yocto *cve-check* generates.
    - An enriched SPDX 3.0 file, where the original SBOM is extended with CVE
      information and associated assessments, while preserving the complete
      vulnerability context in a machine-readable form.

 - **Plugins**:

   This tool supports [plugins](plugins.md) to add additional features, like
   new SBOM formats, new types of CVE database or annotation formats, or new
   export formats.

For an overview of how to use this tool, please refer to the
[user guide](user-guide.md) section.
