from testit_python_commons.client.models.threads_for_create_and_result import (
    ThreadForCreateAndResult,
    ThreadsForCreateAndResult
)
from testit_python_commons.client.models.threads_for_update_and_result import (
    ThreadForUpdateAndResult,
    ThreadsForUpdateAndResult
)
