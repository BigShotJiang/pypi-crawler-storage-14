class OutcomeType:
    PASSED = 'Passed'
    FAILED = 'Failed'
    SKIPPED = 'Skipped'
    BLOCKED = 'Blocked'
