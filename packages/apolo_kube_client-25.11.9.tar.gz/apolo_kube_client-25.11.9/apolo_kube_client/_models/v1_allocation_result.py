from datetime import datetime
from typing import Annotated, ClassVar, Final

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field

from .utils import _default_if_none
from .v1_device_allocation_result import V1DeviceAllocationResult
from .v1_node_selector import V1NodeSelector


__all__ = ("V1AllocationResult",)


class V1AllocationResult(BaseModel):
    """AllocationResult contains attributes of an allocated resource."""

    model_config = ConfigDict(
        extra="forbid",
        serialize_by_alias=True,
        validate_by_alias=True,
        validate_by_name=True,
    )

    kubernetes_ref: ClassVar[Final[str]] = "io.k8s.api.resource.v1.AllocationResult"

    allocation_timestamp: Annotated[
        datetime | None,
        Field(
            alias="allocationTimestamp",
            description="""AllocationTimestamp stores the time when the resources were allocated. This field is not guaranteed to be set, in which case that time is unknown.

This is an alpha field and requires enabling the DRADeviceBindingConditions and DRAResourceClaimDeviceStatus feature gate.""",
            exclude_if=lambda v: v is None,
        ),
    ] = None

    devices: Annotated[
        V1DeviceAllocationResult,
        Field(
            description="""Devices is the result of allocating devices.""",
            exclude_if=lambda v: not v.__pydantic_fields_set__,
        ),
        BeforeValidator(_default_if_none(V1DeviceAllocationResult)),
    ] = V1DeviceAllocationResult()

    node_selector: Annotated[
        V1NodeSelector | None,
        Field(
            alias="nodeSelector",
            description="""NodeSelector defines where the allocated resources are available. If unset, they are available everywhere.""",
            exclude_if=lambda v: v is None,
        ),
    ] = None
