# MSE UTIL

MSE UTIL is a command-line toolkit for the Morphic Semantic Engine (MSE).

It lets you:

- Convert table-like data (CSV, JSON, SQL) into a compact MSE seed (JSON)
- Reconstruct a deterministic synthetic table from an MSE seed
- Export reconstructed tables as CSV, JSON, or SQL

Data can be compressed to over 95% of the original table size. 

A typical database table compressed with the MSE is...

~60% less size than LZMA compression
~70% less size than ZIP compression

CSV, SQL and JSON data tables can be compressed by encoding the data to an MSE Seed and then stored as a single, minimized JSON string. 

When you ready to use the data, pull the seed from your database and decode it in your stack back to it's orginal format (or any other accepted file type). When the data changes, encode it back into the MSE seed and re-upload it to your database. 

See example.py for in-app use examples. 

---

## Demo

mse-db.streamlit.app

In this demo, you can freely convert between standard database table files and an MSE Seed then view and output the results.

---

## Installation

Install from PyPI:

    pip install mse-db

This will install a command called:

    mse

You can then run `mse encode` and `mse decode` from the terminal.

---

## Command Overview

The CLI has two main subcommands:

- `mse encode` – convert CSV / JSON / SQL into an MSE seed
- `mse decode` – convert an MSE seed into a synthetic table (CSV / JSON / SQL)

---

## Encode: CSV / JSON / SQL → MSE Seed

Basic form:

    mse encode <input_file>

Options:

    --format {csv,json,sql}
    --user-id <custom_user_id>
    --output <path>   or   -o <path>

Examples:

    mse encode data.csv -o seed.json
    mse encode data.json --format json -o seed.json
    mse encode dump.sql --format sql -o seed.json
    mse encode data.csv --user-id my_user_id -o seed.json

---

## Decode: MSE Seed → CSV / JSON / SQL

Basic form:

    mse decode <seed_file>

Options:

    --rows <N>                  (default: 30)
    --format {csv,json,sql}     (default: json)
    --table-name <name>         (SQL only)
    --output <path>             or   -o <path>

Examples:

    mse decode seed.json --format csv > table.csv
    mse decode seed.json --format json > table.json
    mse decode seed.json --format sql --table-name stats > table.sql
    mse decode seed.json --rows 100 --format csv > table_100.csv

---

## Quick Cheatsheet

Encode:

    mse encode file.csv -o seed.json
    mse encode file.json --format json -o seed.json
    mse encode file.sql  --format sql  -o seed.json

Decode:

    mse decode seed.json --format csv  > out.csv
    mse decode seed.json --format json > out.json
    mse decode seed.json --format sql  > out.sql

---

## Programmatic Usage (Python)

    from mse_db import build_mse_seed_from_df, build_table_from_seed
    import pandas as pd
    import json

    df = pd.read_csv("data.csv")

    seed, size = build_mse_seed_from_df(df)

    with open("seed.json", "w", encoding="utf-8") as f:
        json.dump(seed, f, indent=4)

    table = build_table_from_seed(seed, rows=50)
    print(table.head())

---

## Seed Format (Example)

    {
      "user_id": "table_12345678",
      "signature": [73, 77, 93, 82, 74],
      "series_seed": 2599,
      "mod": 9973,
      "constants": { "a": 3, "b": 5, "c": 7, "d": 11 },
      "source_columns": ["id", "name", "score"]
    }

---

## License

MIT License © 2025 Jason Dunn

---

## Contact

Author: Jason Dunn  
Email: jasongdunn@outlook.com  
GitHub: https://github.com/jgddesigns
MSE Demo: mse-db.streamlit.app