from typing import TypeAlias
from .question import Question

FormatedCorrectOptions = str
CorrectOptions = str
QuestionLike:TypeAlias = Question
HtmlLike = str