To use this module, you need to:

1.  Go to *Repair \> Configuration \> Settings*.
