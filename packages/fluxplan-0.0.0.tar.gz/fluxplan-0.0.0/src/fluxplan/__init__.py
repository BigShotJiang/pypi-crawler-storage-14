from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("fluxplan")
except PackageNotFoundError:
    __version__ = "0.0.0"