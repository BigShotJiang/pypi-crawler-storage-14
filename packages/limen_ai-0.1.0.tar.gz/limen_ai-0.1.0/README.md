# LIMEN-AI

LIMEN-AI (Łukasiewicz Interpretable Markov Engine for Neuralized AI) is a Python reference implementation of the LIMEN-AI SRM engine. It provides:

- Łukasiewicz fuzzy semantics and differentiable rule evaluation
- Energy-based inference (importance sampling, explanations, deduction)
- KB-driven inductive rule discovery using configurable templates

## Installation

```bash
cd code
pip install -e .
```

## Documentation

- `docs/api_overview.md` describes the main APIs and workflow.
- `notebooks/limen_ai_walkthrough.ipynb` demonstrates KB creation, inference, and induction.

