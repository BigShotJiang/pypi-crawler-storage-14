import os
import requests
import json
import gzip
import time

BASE_API = "https://api.sync.so"
S3_BUCKET = "https://prod-public-sync-user-assets.s3.us-east-1.amazonaws.com"

def leer_respuesta(response):
    content = response.content
    if response.headers.get('Content-Encoding') == 'gzip':
        try:
            return gzip.decompress(content).decode('utf-8')
        except Exception as e:
            print(f"Error descomprimiendo gzip: {e}")
            return content.decode('utf-8', errors='ignore')
    try:
        return content.decode('utf-8')
    except:
        return content.decode('latin1', errors='ignore')

def obtener_url_carga(nombre_archivo, content_type="audio/mpeg"):
    """Obtiene la URL para cargar el archivo directamente a S3."""
    session_token = os.environ.get("ACCESS_TOKEN")
    headers = {
        "Host": "api.sync.so",
        "Connection": "keep-alive",
        "sec-ch-ua-platform": '"Windows"',
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        "x-sync-source": "web",
        "sec-ch-ua-mobile": "?0",
        "Accept": "*/*",
        "Origin": "https://sync.so",
        "Sec-Fetch-Site": "same-site",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://sync.so/",
        "Accept-Language": "es-ES,es;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Cookie": f"__Secure-sync.session_token={session_token}"
    }

    input_data = {
        "json": {
            "fileName": nombre_archivo,
            "contentType": content_type,
            "isPublic": True
        }
    }
    url = f"{BASE_API}/trpc/fileStorage.getUploadUrl?input={requests.utils.quote(json.dumps(input_data))}"

    print("📤 Solicitando URL de carga...")
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Error {response.status_code}: {response.text}")

    content = leer_respuesta(response)
    data = json.loads(content)

    # Extraer uploadUrl y publicUrl
    upload_url = data["result"]["data"]["json"]["uploadUrl"]
    public_url = data["result"]["data"]["json"]["publicUrl"].strip()

    print("✅ URL de carga obtenida.")
    return upload_url, public_url

def subir_audio_a_s3(upload_url, archivo_path):
    """Sube el archivo al bucket S3 usando la URL presignada."""
    with open(archivo_path, 'rb') as f:
        contenido = f.read()

    headers = {
        "Content-Type": "audio/mpeg",
        "Content-Length": str(len(contenido))
    }

    print("📤 Subiendo audio a S3...")
    response = requests.put(upload_url, data=contenido, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Error en PUT: {response.status_code}, {response.text}")

    etag = response.headers.get('ETag', '').strip('"')
    print("✅ Audio subido a S3.")
    return etag

def crear_recurso(public_url, project_id="a449159c-7efa-4db6-8100-a408db68a538", nombre_audio=None):
    """Crea el recurso de tipo AUDIO."""
    session_token = os.environ.get("ACCESS_TOKEN")
    headers = {
        "Host": "api.sync.so",
        "Connection": "keep-alive",
        "sec-ch-ua-platform": '"Windows"',
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        "trpc-accept": "application/jsonl",
        "content-type": "application/json",
        "x-sync-source": "web",
        "sec-ch-ua-mobile": "?0",
        "Accept": "*/*",
        "Origin": "https://sync.so",
        "Sec-Fetch-Site": "same-site",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://sync.so/",
        "Accept-Language": "es-ES,es;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Cookie": f"__Secure-sync.session_token={session_token}"
    }

    if nombre_audio is None:
        nombre_audio = os.path.basename(public_url).split('?')[0]

    data = {
        "0": {
            "json": {
                "visibility": "USER",
                "projectId": project_id,
                "url": public_url.strip(),
                "type": "AUDIO",
                "name": nombre_audio
            }
        }
    }

    url = f"{BASE_API}/trpc/assets.create?batch=1"
    print("🎵 Creando recurso de audio...")
    response = requests.post(url, headers=headers, json=data)

    if response.status_code != 200:
        raise Exception(f"Error {response.status_code}: {response.text}")

    content = leer_respuesta(response)
    for line in content.split('\n'):
        line = line.strip()
        if not line:
            continue
        try:
            j = json.loads(line)
            if isinstance(j, dict) and 'json' in j:
                json_data = j['json']
                if isinstance(json_data, list) and len(json_data) >= 3 and json_data[0] == 2:
                    payload = json_data[2]
                    if isinstance(payload, list) and len(payload) > 0:
                        inner = payload[0]
                        if isinstance(inner, list) and len(inner) > 0:
                            obj = inner[0]
                            if isinstance(obj, dict) and 'id' in obj:
                                asset_id = obj['id']
                                print("✅ Recurso de audio creado.")
                                return asset_id
        except Exception as e:
            print(f"⚠️ Error al parsear línea: {e}")
            continue

    raise Exception("No se creó el recurso de audio.")

def obtener_recurso(asset_id):
    """Obtiene el recurso creado."""
    session_token = os.environ.get("ACCESS_TOKEN")
    headers = {
        "Host": "api.sync.so",
        "Connection": "keep-alive",
        "sec-ch-ua-platform": '"Windows"',
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        "trpc-accept": "application/jsonl",
        "content-type": "application/json",
        "x-sync-source": "web",
        "sec-ch-ua-mobile": "?0",
        "Accept": "*/*",
        "Origin": "https://sync.so",
        "Sec-Fetch-Site": "same-site",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://sync.so/",
        "Accept-Language": "es-ES,es;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Cookie": f"__Secure-sync.session_token={session_token}"
    }

    input_data = json.dumps({"0": {"json": {"id": asset_id}}})
    query = f"?batch=1&input={requests.utils.quote(input_data)}"
    url = f"{BASE_API}/trpc/assets.get{query}"

    print("🔍 Obteniendo recurso de audio...")
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Error {response.status_code}: {response.text}")

    content = leer_respuesta(response)
    for line in content.split('\n'):
        line = line.strip()
        if not line:
            continue
        try:
            j = json.loads(line)
            if isinstance(j, dict) and 'json' in j:
                json_data = j['json']
                if isinstance(json_data, list) and len(json_data) >= 3 and json_data[0] == 2:
                    payload = json_data[2]
                    if isinstance(payload, list) and len(payload) > 0:
                        inner = payload[0]
                        if isinstance(inner, list) and len(inner) > 0:
                            obj = inner[0]
                            if isinstance(obj, dict) and 'id' in obj and obj['id'] == asset_id:
                                print("✅ Recurso obtenido.")
                                return obj
        except Exception as e:
            print(f"⚠️ Error al parsear línea: {e}")
            continue

    raise Exception("No se encontró el recurso solicitado.")

# === FUNCIÓN PRINCIPAL PARA AUDIO ===
def subir_audio_a_sync_so(ruta_audio, project_id="a449159c-7efa-4db6-8100-a408db68a538", nombre_audio=None):
    """
    Sube un archivo de audio a sync.so usando el nuevo flujo.
    """
    if not os.path.exists(ruta_audio):
        raise FileNotFoundError(f"Archivo no encontrado: {ruta_audio}")

    nombre_archivo = os.path.basename(ruta_audio)
    tamano = os.path.getsize(ruta_audio)

    try:
        upload_url, public_url = obtener_url_carga(nombre_archivo, "audio/mpeg")
        etag = subir_audio_a_s3(upload_url, ruta_audio)
        asset_id = crear_recurso(public_url, project_id, nombre_audio or nombre_archivo)
        info = obtener_recurso(asset_id)

        return info['id'], info['name'], info['url']

    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return None

# Generar nombre dinámico
def generar_nombre():
    timestamp = int(time.time())
    return f"AUDIO-input-{timestamp}.mp3"

def up_audio(AUDIO_PATH):
    nombre_audio = generar_nombre()
    project_id = os.environ.get("PROJECT_ID")

    asset_id_audio, info_name_audio, info_url_audio = subir_audio_a_sync_so(AUDIO_PATH, project_id, nombre_audio)
    if asset_id_audio:
        print("✅ Audio subido exitosamente!")
        os.environ["ASSET_ID_AUDIO"] = asset_id_audio
        os.environ["INFO_NAME_AUDIO"] = info_name_audio
        os.environ["INFO_URL_AUDIO"] = info_url_audio