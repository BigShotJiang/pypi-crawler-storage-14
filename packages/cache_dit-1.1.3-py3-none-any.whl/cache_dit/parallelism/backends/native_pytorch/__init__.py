from cache_dit.parallelism.backends.native_pytorch.tensor_parallelism import (
    TensorParallelismPlannerRegister,
)
from cache_dit.parallelism.backends.native_pytorch.parallel_torch import (
    maybe_enable_parallelism,
)
