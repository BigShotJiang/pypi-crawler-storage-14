import torch
import torch.distributed as dist
from typing import Union, Optional
from transformers import PreTrainedTokenizerFast, PreTrainedTokenizer
from cache_dit.parallelism.parallel_backend import ParallelismBackend
from cache_dit.parallelism.parallel_config import ParallelismConfig
from cache_dit.utils import maybe_empty_cache
from cache_dit.logger import init_logger

logger = init_logger(__name__)


def enable_parallelism(
    transformer: torch.nn.Module,
    parallelism_config: ParallelismConfig,
) -> torch.nn.Module:
    assert isinstance(transformer, torch.nn.Module), (
        "transformer must be an instance of torch.nn.Module, " f"but got {type(transformer)}"
    )
    if getattr(transformer, "_is_parallelized", False):
        logger.warning("The transformer is already parallelized. " "Skipping parallelism enabling.")
        return transformer

    if parallelism_config.backend == ParallelismBackend.NATIVE_DIFFUSER:
        from cache_dit.parallelism.backends.native_diffusers import (
            maybe_enable_parallelism,
        )

        transformer = maybe_enable_parallelism(
            transformer,
            parallelism_config,
        )
    elif parallelism_config.backend == ParallelismBackend.NATIVE_PYTORCH:
        from cache_dit.parallelism.backends.native_pytorch import (
            maybe_enable_parallelism,
        )

        transformer = maybe_enable_parallelism(
            transformer,
            parallelism_config,
        )
    else:
        raise ValueError(f"Parallel backend {parallelism_config.backend} is not supported yet.")

    transformer._is_parallelized = True  # type: ignore[attr-defined]
    # Use `parallelism` not `parallel` to avoid name conflict with diffusers.
    transformer._parallelism_config = parallelism_config  # type: ignore[attr-defined]
    logger.info(
        f"Enabled parallelism: {parallelism_config.strify(True)}, "
        f"transformer id:{id(transformer)}"
    )

    # NOTE: Workaround for potential memory peak issue after parallelism
    # enabling, specially for tensor parallelism in native pytorch backend.
    maybe_empty_cache()

    return transformer


def remove_parallelism_stats(
    transformer: torch.nn.Module,
) -> torch.nn.Module:
    if not getattr(transformer, "_is_parallelized", False):
        logger.warning("The transformer is not parallelized. " "Skipping removing parallelism.")
        return transformer

    if hasattr(transformer, "_is_parallelized"):
        del transformer._is_parallelized  # type: ignore[attr-defined]
    if hasattr(transformer, "_parallelism_config"):
        del transformer._parallelism_config  # type: ignore[attr-defined]
    return transformer


def maybe_pad_prompt(
    tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast],
    prompt: str,
    extra_prompt: Optional[str] = None,  # e.g., negative prompt
    num_parition: Optional[int] = None,  # e.g., dist.get_world_size()
    pad_token: Optional[str] = None,  # e.g., default tokenizer.pad_token
    num_extra_tokens: Optional[int] = 0,  # e.g., negative prompt tokens length
    verbose: bool = True,
) -> str:
    """Pad the prompt to make sure the number of tokens is divisible by num_partition."""
    assert isinstance(tokenizer, (PreTrainedTokenizer, PreTrainedTokenizerFast)), (
        f"tokenizer must be an instance of PreTrainedTokenizer or PreTrainedTokenizerFast, "
        f"but got {type(tokenizer)}"
    )
    inputs_ids = tokenizer(prompt, return_tensors="pt")

    if num_parition is None:
        if dist.is_initialized():
            num_parition = dist.get_world_size()
        else:
            num_parition = 1

    if num_parition <= 1:
        return prompt

    if pad_token is None:
        pad_token = tokenizer.pad_token
        if pad_token is None:
            pad_token = tokenizer.eos_token
            if pad_token is None:
                pad_token = " "
                logger.warning(
                    "pad_token and eos_token are not set in the tokenizer. "
                    "Using space ' ' as the pad_token."
                )

    seq_len = inputs_ids.input_ids.shape[1]  # [batch_size, seq_len]

    # Add extra tokens length, e.g., negative prompt tokens length
    partition_seq_len = seq_len
    partition_seq_len += num_extra_tokens
    if extra_prompt is not None:
        extra_inputs_ids = tokenizer(extra_prompt, return_tensors="pt")
        partition_seq_len += extra_inputs_ids.input_ids.shape[1]
        num_extra_tokens += extra_inputs_ids.input_ids.shape[1]

    if partition_seq_len % num_parition != 0:
        pad_len = num_parition - (partition_seq_len % num_parition)
        if verbose:
            logger.info(
                f"Padding the prompt from seq_len {seq_len} to "
                f"{seq_len + pad_len} to make {seq_len + pad_len} + "
                f"{num_extra_tokens} = {seq_len + pad_len + num_extra_tokens} "
                f"divisible by num_partition {num_parition}."
            )
        pad_token_id = tokenizer.convert_tokens_to_ids(pad_token)
        assert isinstance(pad_token_id, int), f"pad_token {pad_token} has more than one token."

        pad_ids = torch.full(
            (1, pad_len),
            pad_token_id,
            dtype=inputs_ids.input_ids.dtype,
        )
        inputs_ids.input_ids = torch.cat([inputs_ids.input_ids, pad_ids], dim=1)

        prompt = tokenizer.decode(inputs_ids.input_ids[0])

        new_seq_len = tokenizer(prompt, return_tensors="pt").input_ids.shape[1]
        new_partition_seq_len = new_seq_len + num_extra_tokens
        assert new_partition_seq_len % num_parition == 0, (
            f"Failed to pad the prompt to make it divisible by num_partition {num_parition}. "
            f"Got new_seq_len {new_seq_len}, new_partition_seq_len {new_partition_seq_len}."
        )
    return prompt
