# This ensures that importlib_resources.files("aider.resources")
# doesn't raise ImportError, even if there are no other files in this
# dir.
