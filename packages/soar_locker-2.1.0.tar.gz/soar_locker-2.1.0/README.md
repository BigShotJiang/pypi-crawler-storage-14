# SOAR — Secure Obfuscated Archive Runtime

SOAR 提供 `.soa` 加密文件格式，使 Python 模块只能在授权机器上运行。

## 加密
soar myproject/
soar hello.py

shell
复制代码

## 运行
soar hello.soa

markdown
复制代码

## 特性
- 机器码绑定（fingerprint）
- AES 加密
- 完全兼容 Python 语义
- 不删除源代码，自动备份到 bak/