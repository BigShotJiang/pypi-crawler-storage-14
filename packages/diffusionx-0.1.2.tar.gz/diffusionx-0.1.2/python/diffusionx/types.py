from enum import Enum


class DType(Enum):
    Float = "float"
    Int = "int"
