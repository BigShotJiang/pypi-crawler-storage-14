
def input():
    consulta=input(ingresa una sentencia: )
