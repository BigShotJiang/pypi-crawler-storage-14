class CommonApiUrl:
    pass
