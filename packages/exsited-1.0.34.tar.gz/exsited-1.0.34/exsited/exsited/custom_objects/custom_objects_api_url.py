class CustomObjectsApiUrl:
    CO_ACCOUNT_LIST = "/api/v3/accounts/{id}/custom_objects"
    CO_ACCOUNT_DETAILS_UUID = "/api/v2/accounts/{id}/custom_objects/{uuid}"
    CO_LIST = "/api/v3/component/{cc_uuid}/{cc_id}/custom_objects"
    CO_DETAILS = "/api/v3/component/{cc_uuid}/{cc_id}/custom_objects/{co_uuid}"
    CO_INSTANCE_DELETE = "/api/v2/component/{component_uuid}/{component_id}/custom_objects_instances/{object_uuid}"
