class CustomComponentApiUrl:
    CUSTOM_COMPONENT = "/api/v3/settings/components"
    CUSTOM_COMPONENT_DETAILS = "/api/v2/component/{uuid}"
    CUSTOM_COMPONENT_UUID_DETAILS = "/api/v2/component/{uuid}/{id}"
    CUSTOM_COMPONENT_PDF = "/api/v2/component/{uuid}/{id}/pdf"
    ACCOUNT_COMPONENT_LIST = "/api/v2/accounts/{account_id}/component/{component_uuid}"
    ACCOUNT_COMPONENT_DETAILS = "/api/v2/accounts/{account_id}/component/{component_uuid}/{component_id}"

    WORKFLOW_STATUS = "/api/v2/workflow/account/{account_uuid}/component/{component_uuid}/status"
    COMPONENT_CHANGE_STATUS = "/api/v3/component/{component_uuid}/{order_id}/change_status"
    COMPONENT_ACTIVITY = "/api/v3/component/{component_uuid}/{order_id}/activity"
    COMPONENT_ACTIVITY_DETAILS = "/api/v3/component/{component_uuid}/{order_id}/activity/{activity_uuid}"
