class CustomAttributesApiUrl:
    CUSTOM_ATTRIBUTES_UPDATE = "/api/v3/custom_attributes/{uuid}/"
    CUSTOM_ATTRIBUTES = "api/v2/settings/custom_attributes"
    ATTRIBUTE_ATTACHMENT = "/api/v2/attribute_attachment/{file_uuid}"

