#!/usr/bin/env python3

"""
Mobile Simulate Example

This example demonstrates how to use the mobile simulate feature to simulate
different mobile devices across sessions.

1. Upload mobile info file for first time
2. Create first mobile session with mobile simulate configuration
3. Wait for mobile simulate to complete
4. Get device model after mobile simulate
5. Delete first mobile session
6. Create second mobile session with the same mobile simulate configuration
7. Wait for mobile simulate to complete
8. Get device model after mobile simulate
9. Delete second mobile session
"""
import asyncio
import os
from re import A
from socketserver import ForkingUDPServer
from agentbay import AgentBay
from agentbay.session_params import CreateSessionParams, ExtraConfigs
from agentbay.api.models import MobileExtraConfig, MobileSimulateConfig, MobileSimulateMode
from agentbay.session import Session
from agentbay.mobile_simulate import MobileSimulateService

session1: Session = None
session2: Session = None
mobile_sim_context_id: str = None


async def run_on_first_mobile_session(agent_bay: AgentBay):
    global session1
    global mobile_sim_context_id
    try:
        # Creating mobile simulate service and set simulate params
        print("Creating mobile simulate service and set simulate params...")
        simulate_service = MobileSimulateService(agent_bay)
        simulate_service.set_simulate_enable(True)
        simulate_service.set_simulate_mode(MobileSimulateMode.PROPERTIES_ONLY)

        # Upload mobile info file for first time
        # How to get the mobile info file please contact the support team.
        print("Uploading mobile info file for first time...")
        mobile_sim_context_id = None
        mobile_info_file_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))), 
                "resource", "mobile_info_model_a.json"
        )
        with open(mobile_info_file_path, "r") as f:
            mobile_info_content = f.read()
        upload_result = simulate_service.upload_mobile_info(mobile_info_content)
        if not upload_result.success:
            print(f"Failed to upload mobile info file: {upload_result.error_message}")
            return
        else:
            mobile_sim_context_id = upload_result.mobile_simulate_context_id
            print(f"Mobile simulate context id uploaded successfully: {mobile_sim_context_id}")

        params = CreateSessionParams(
            image_id="mobile_latest",
            extra_configs=ExtraConfigs(
                mobile=MobileExtraConfig(
                    # Set mobile simulate config
                    simulate_config=simulate_service.get_simulate_config()
                )
            )
        )

        print("Creating first session...")
        session_result = agent_bay.create(params)
        if not session_result.success or not session_result.session:
            print(f"Failed to create session: {session_result.error_message}")
            return

        session1 = session_result.session
        print(f"Session created with ID: {session1.session_id}")
        print(f"session = {session1}")

        # Wait for mobile simulate to complete
        await asyncio.sleep(5)

        print("Getting device model after mobile simulate ...")
        result = session1.command.execute_command("getprop ro.product.model")
        if not result.success:
            print(f"Failed to get device model: {result.error_message}")
            return
        product_model = result.output.strip()
        print(f"First session device model: {product_model}")

    except Exception as e:
        print(f"Error during run_on_first_mobile_session: {e}")

    finally:
        pass


async def run_on_second_mobile_session(agent_bay: AgentBay):
    global session2
    global mobile_sim_context_id
    try:
        # Creating mobile simulate service and set simulate params
        print("Creating mobile simulate service and set simulate params...")
        simulate_service = MobileSimulateService(agent_bay)
        simulate_service.set_simulate_enable(True)
        simulate_service.set_simulate_mode(MobileSimulateMode.PROPERTIES_ONLY)
        simulate_service.set_simulate_context_id(mobile_sim_context_id)

        # Use the same mobile simulate context id as the first session
        params = CreateSessionParams(
            image_id="mobile_latest",
            extra_configs=ExtraConfigs(
                mobile=MobileExtraConfig(
                    # Configure mobile simulate feature, simulate mode and simulated context id
                    simulate_config=simulate_service.get_simulate_config()
                )
            )
        )

        print("Creating second session...")
        session_result = agent_bay.create(params)
        if not session_result.success or not session_result.session:
            print(f"Failed to create session: {session_result.error_message}")
            return

        session2 = session_result.session
        print(f"Session created with ID: {session2.session_id}")
        print(f"session = {session2}")

        # Wait for mobile simulate to complete
        await asyncio.sleep(5)

        print("Getting device model after mobile simulate ...")
        result = session2.command.execute_command("getprop ro.product.model")
        if not result.success:
            print(f"Failed to get device model: {result.error_message}")
            return
        product_model = result.output.strip()
        print(f"Second session device model: {product_model}")

    except Exception as e:
        print(f"Error during run_on_second_mobile_session: {e}")

    finally:
        pass


def main():
    """Demonstrate browser context cookie persistence."""
    # Get API key from environment
    api_key = os.environ.get("AGENTBAY_API_KEY")
    if not api_key:
        print("Error: AGENTBAY_API_KEY environment variable not set")
        return

    # Initialize AgentBay client
    agent_bay = AgentBay(api_key)
    print("AgentBay client initialized")

    # Run on first mobile session
    asyncio.run(run_on_first_mobile_session(agent_bay))
    print("Deleting first session...")
    delete_result = agent_bay.delete(session1, sync_context=True)
    if not delete_result.success:
        print(f"Failed to delete first session: {delete_result.error_message}")
        return
    print(f"First session deleted successfully (RequestID: {delete_result.request_id})")

    # Run on second mobile session
    asyncio.run(run_on_second_mobile_session(agent_bay))
    print("Deleting second session...")
    delete_result = agent_bay.delete(session2, sync_context=True)
    if not delete_result.success:
        print(f"Failed to delete second session: {delete_result.error_message}")
        return
    print(f"Second session deleted successfully (RequestID: {delete_result.request_id})")


if __name__ == "__main__":
    main()

