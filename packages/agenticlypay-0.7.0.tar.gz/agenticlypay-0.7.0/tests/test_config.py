"""Tests for configuration module."""

import pytest
from agenticlypay.config import Config


class TestConfig:
    """Tests for Config class."""

    def test_default_fee_percentage(self):
        """Test default platform fee percentage is 6.5%."""
        config = Config()
        assert config.platform_fee_percentage == 0.065

    def test_default_fee_fixed(self):
        """Test default fixed fee is $0.30 (30 cents)."""
        config = Config()
        assert config.platform_fee_fixed == 30

    def test_calculate_fee_small_amount(self):
        """Test fee calculation for small amount ($10)."""
        config = Config()
        # $10.00 = 1000 cents
        # 6.5% of 1000 = 65 cents
        # Plus $0.30 fixed = 30 cents
        # Total fee = 95 cents
        fee = config.calculate_fee(1000)
        assert fee == 95

    def test_calculate_fee_large_amount(self):
        """Test fee calculation for larger amount ($100)."""
        config = Config()
        # $100.00 = 10000 cents
        # 6.5% of 10000 = 650 cents
        # Plus $0.30 fixed = 30 cents
        # Total fee = 680 cents
        fee = config.calculate_fee(10000)
        assert fee == 680

    def test_calculate_fee_minimum(self):
        """Test fee calculation for minimum amount ($1)."""
        config = Config()
        # $1.00 = 100 cents
        # 6.5% of 100 = 6 cents (rounded down from 6.5)
        # Plus $0.30 fixed = 30 cents
        # Total fee = 36 cents
        fee = config.calculate_fee(100)
        assert fee == 36

    def test_calculate_net_amount(self):
        """Test net amount calculation."""
        config = Config()
        # $100.00 = 10000 cents
        # Fee = 680 cents
        # Net = 10000 - 680 = 9320 cents
        net = config.calculate_net_amount(10000)
        assert net == 9320

    def test_calculate_net_amount_small(self):
        """Test net amount for small transaction."""
        config = Config()
        # $10.00 = 1000 cents
        # Fee = 95 cents
        # Net = 1000 - 95 = 905 cents
        net = config.calculate_net_amount(1000)
        assert net == 905

    def test_platform_name_default(self):
        """Test default platform name."""
        config = Config()
        assert config.platform_name == "AgenticlyPay"

    def test_api_defaults(self):
        """Test default API configuration."""
        config = Config()
        assert config.api_host == "0.0.0.0"
        assert config.api_port == 8000
        assert config.api_reload is False

    def test_frontend_url_default(self):
        """Test default frontend URL."""
        config = Config()
        assert config.frontend_url == "https://agenticlypay.com"

    def test_square_environment_default(self):
        """Test default Square environment."""
        config = Config()
        assert config.square_environment == "production"

