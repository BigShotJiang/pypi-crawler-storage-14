"""
    This file is part of python-webuntis

    :copyright: (c) 2012 by Markus Unterwaditzer.
    :license: BSD, see LICENSE for more details.
"""
__version__ = '0.1.24'
from webuntis.session import Session

from webuntis import errors
