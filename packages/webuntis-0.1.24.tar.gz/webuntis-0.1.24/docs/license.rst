===================
Credits and License
===================

.. note::

    The following 3-clause BSD license applies to the full sourcecode shipped
    as part of python-webuntis, as well as to the documentation.

    The license text basically says that you are free to modify and use
    python-webuntis, provided that the copyright sticks around. Furthermore,
    you may not use the author's name to promote derivatives of
    python-webuntis.


.. include:: ../LICENSE
