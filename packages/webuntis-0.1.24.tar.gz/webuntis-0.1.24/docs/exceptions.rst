=====================
Errors and Exceptions
=====================

`python-webuntis` tries to cover as many error codes received by the API as possible.

.. automodule:: webuntis.errors
    :members:
    :show-inheritance:
    :member-order: bysource
