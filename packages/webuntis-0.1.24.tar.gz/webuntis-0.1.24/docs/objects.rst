==================
Objects and Models
==================

.. note::
    
    The classes listed here never should be instantiated directly. Instead, use
    the methods of :py:class:`webuntis.Session`.

.. automodule:: webuntis.objects
    :members:
    :show-inheritance:
