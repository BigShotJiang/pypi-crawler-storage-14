# colorednoise
A clean implementation of colored noise variants with PyTorch. 
