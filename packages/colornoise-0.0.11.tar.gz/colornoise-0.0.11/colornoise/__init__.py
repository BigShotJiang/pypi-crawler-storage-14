from .functions import black_noise
from .functions import white_noise
from .functions import blue_noise
from .functions import violet_noise
from .functions import brown_noise
from .functions import pink_noise
from .functions import colored_noise
