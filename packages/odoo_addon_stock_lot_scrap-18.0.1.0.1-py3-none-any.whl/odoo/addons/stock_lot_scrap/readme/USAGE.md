- Go to *Inventory \> Products \> Lots/Serial Numbers*, and enter in
  view form mode.
- Click button *Scrap*
