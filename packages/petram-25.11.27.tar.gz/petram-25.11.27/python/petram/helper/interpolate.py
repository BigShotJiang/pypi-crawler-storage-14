from ifigure.utils.interpolate import interp1d, interp2d
