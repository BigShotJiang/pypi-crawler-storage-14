'''
for backward compatibility. we load names in geom_primitives to this module
'''
from petram.geom.geom_primitives import *
