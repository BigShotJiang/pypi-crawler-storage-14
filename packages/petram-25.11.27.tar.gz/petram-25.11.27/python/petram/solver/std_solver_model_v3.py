from petram.solver.std_solver_model import StdSolver
