from ayuai.suggestions import CodeSuggestions

def test_print_suggestion():
    cs = CodeSuggestions()
    out = cs.suggest("print('hi')")
    assert 'logging' in out.lower() or 'print' in out.lower()

def test_none_suggestion():
    cs = CodeSuggestions()
    out = cs.suggest('x == None')
    assert 'is None' in out
