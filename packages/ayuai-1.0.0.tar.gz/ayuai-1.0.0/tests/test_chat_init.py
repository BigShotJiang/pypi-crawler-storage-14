from ayuai.chat import ChatAI
import os
def test_chat_init_default():
    ai = ChatAI(provider='openai', api_key='fake', model='gpt-4o-mini')
    assert ai.provider == 'openai'
