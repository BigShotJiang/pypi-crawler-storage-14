# ayuai

A Python AI library integrating **ChatGPT**, **Google Gemini**, and a smart **code suggestion engine**.

## Installation (locally for testing)
1. Create and activate virtualenv:
   ```
   python -m venv venv
   source venv/bin/activate   # macOS / Linux
   venv\Scripts\activate    # Windows PowerShell
   ```
2. Install from local directory:
   ```
   pip install .
   ```

## Usage

### Chat (OpenAI / Gemini)
```python
from ayuai import ChatAI

# For OpenAI:
ai = ChatAI(provider="openai", api_key="YOUR_OPENAI_API_KEY", model="gpt-4o-mini")
print(ai.ask("Hello AyuAI!"))

# For Gemini (use API KEY or HTTP key as required by Google)
ai2 = ChatAI(provider="gemini", api_key="YOUR_GOOGLE_API_KEY", model="gemini-pro")
print(ai2.ask("Hello from Gemini!"))
```

### Code Suggestions
```python
from ayuai import CodeSuggestions

cs = CodeSuggestions()
print(cs.suggest("print('Hello world')"))
```

## Environment variables recommended
- `AYUAI_OPENAI_KEY` - Your OpenAI API key (if you don't pass it directly)
- `AYUAI_GOOGLE_KEY` - Your Google Generative AI key (for Gemini)

## Publishing to PyPI (summary)
1. Make sure you have an account on https://pypi.org/.
2. Build distribution:
   ```
   python -m pip install --upgrade build twine
   python -m build
   ```
3. Upload:
   ```
   python -m twine upload dist/*
   ```
4. After a successful upload, users can `pip install ayuai` (if the name is available).

## VS Code extension (simple demo)
A minimal VS Code extension scaffold is included under `vscode-extension/` that runs a quick Python script using this package to demonstrate suggestions. See that folder for usage.

## Security & Notes
- This project contains network calls to 3rd-party APIs; never store secrets in source control.
- Replace placeholder email and copyright where appropriate.

    ## Continuous Integration

This project includes GitHub Actions workflows:
- `.github/workflows/ci.yml`: runs tests on push and PRs to `main`.
- `.github/workflows/publish.yml`: builds and publishes to PyPI when you push a tag like `v1.0.0`.

## Publishing notes

Create a PyPI API token and add it as a repository secret `PYPI_API_TOKEN` in GitHub to enable the publish workflow.

Tagging example:
```
git tag v1.0.0
git push origin v1.0.0
```

The publish workflow will run and upload the built distribution to PyPI using the token.
