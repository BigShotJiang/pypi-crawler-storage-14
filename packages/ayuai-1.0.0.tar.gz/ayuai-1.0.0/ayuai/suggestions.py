class CodeSuggestions:
    """A minimal rule-based suggestion engine for Python code snippets."""
    def suggest(self, code):
        suggestions = []
        # Basic heuristics
        if 'print(' in code:
            suggestions.append('Consider using the `logging` module instead of `print` for production code.')
        if '== None' in code:
            suggestions.append("Use `is None` for comparisons to None (PEP8).")
        if 'import *' in code:
            suggestions.append('Avoid wildcard imports (import *). Import only needed names.')
        if 'exec(' in code or 'eval(' in code:
            suggestions.append('Avoid eval/exec; they are security risks if used with untrusted input.')
        if 'requests.post' in code and 'timeout' not in code:
            suggestions.append('Add a `timeout` parameter to network requests to avoid hanging.')

        if not suggestions:
            return 'No suggestions found. Code looks clean!'
        return "\n".join(suggestions)
