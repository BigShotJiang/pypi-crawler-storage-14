Filters were taken from https://www.legacysurvey.org/dr9/description/#obtaining-images-and-raw-data (Photometry section).
The "MzLS z-band with corrections" filter is used instead of "MzLS z-band".
For the BASS filters, the "res_qe_atm" column is used as it includes QE and atmospheric extinction
