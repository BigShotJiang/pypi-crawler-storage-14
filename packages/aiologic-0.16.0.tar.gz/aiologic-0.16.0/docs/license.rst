..
  SPDX-FileCopyrightText: 2025 Ilya Egorov <0x42005e1f@gmail.com>
  SPDX-License-Identifier: CC-BY-4.0

License
=======

.. include:: ../README.rst
  :start-after: .. license-start-marker
  :end-before: .. license-end-marker
