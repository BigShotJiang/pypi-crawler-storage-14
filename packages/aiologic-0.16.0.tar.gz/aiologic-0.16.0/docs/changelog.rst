..
  SPDX-FileCopyrightText: 2025 Ilya Egorov <0x42005e1f@gmail.com>
  SPDX-License-Identifier: CC-BY-4.0

.. include:: ../CHANGELOG.md
  :parser: myst_parser.sphinx_
