## [0.0.2] - 2025-11-25
### Fixed
- PyPI setup in project.toml

---

## [0.0.0] - 2025-11-24
### Added
- Initial TUI app with sidebar, stats, content panel
- SQLite backend
- Editable install and console script
