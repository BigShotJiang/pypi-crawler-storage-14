from .app import QnoteApp


def main():
    app = QnoteApp()
    app.run()
