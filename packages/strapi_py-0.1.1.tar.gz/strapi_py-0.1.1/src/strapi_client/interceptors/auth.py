from typing import Any, Tuple
from ..auth.manager import AuthManager
from ..errors.http import StrapiHTTPUnauthorizedError
from ..http_client import HttpClient
from ..http.interceptor_manager import Interceptor, RejectedInterceptor


class AuthInterceptors:
    @staticmethod
    def ensure_pre_authentication(auth_manager: AuthManager, http_client: HttpClient) -> Interceptor:
        async def interceptor(request: Any) -> Any:
            if auth_manager.strategy and not auth_manager.is_authenticated:
                await auth_manager.authenticate(http_client)
            return request
        return interceptor

    @staticmethod
    def authenticate_requests(auth_manager: AuthManager) -> Interceptor:
        def interceptor(request: Any) -> Any:
            auth_manager.authenticate_request(request)
            return request
        return interceptor

    @staticmethod
    def notify_on_unauthorized_response(auth_manager: AuthManager) -> Tuple[Interceptor, RejectedInterceptor]:
        def notify() -> None:
            auth_manager.handle_unauthorized_error()

        def fulfillment(response: Any) -> Any:
            if response.status_code == 401:
                notify()
            return response

        def rejection(payload: Any) -> Any:
            if isinstance(payload, StrapiHTTPUnauthorizedError):
                notify()
            return payload

        return fulfillment, rejection
