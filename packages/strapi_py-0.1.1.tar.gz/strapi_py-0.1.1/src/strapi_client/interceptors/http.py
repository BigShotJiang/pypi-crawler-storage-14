from typing import Any
from ..http_client import HttpClient
from ..http.interceptor_manager import Interceptor


class HttpInterceptors:
    @staticmethod
    def set_default_headers() -> Interceptor:
        DEFAULT_HEADERS = {"Content-Type": "application/json"}

        def interceptor(request: Any) -> Any:
            for key, value in DEFAULT_HEADERS.items():
                if key.lower() not in (h.lower() for h in request.headers):
                    if key == 'Content-Type' and request.content and hasattr(request.content, 'boundary'):
                        continue
                    request.headers[key] = value
            return request
        return interceptor

    @staticmethod
    def transform_errors() -> Interceptor:
        def interceptor(response: Any) -> Any:
            if 200 <= response.status_code < 300:
                return response
            
            raise HttpClient.map_response_to_http_error(response)
        return interceptor
