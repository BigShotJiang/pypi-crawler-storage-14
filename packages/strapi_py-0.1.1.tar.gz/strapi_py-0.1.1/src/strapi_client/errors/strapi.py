from .base import StrapiError, StrapiValidationError


class StrapiInitializationError(StrapiError):
    """Raised when the Strapi client fails to initialize."""
    def __init__(self, message: str = "Could not initialize the Strapi Client", cause: Exception = None):
        super().__init__(message)
        self.cause = cause

class StrapiURLParsingError(StrapiValidationError):
    """Raised when a URL cannot be parsed."""
    def __init__(self, url: str, message: str = None, cause: Exception = None):
        if message is None:
            message = f"Could not parse invalid URL: \"{url}\""
        super().__init__(message, cause)
        self.url = url
