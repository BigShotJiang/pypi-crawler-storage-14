class StrapiError(Exception):
    """Base class for all Strapi client errors."""
    def __init__(self, message: str = "An error occurred in the Strapi client. Please check the logs for more information.", cause: Exception = None):
        super().__init__(message)
        self.cause = cause

class StrapiValidationError(StrapiError):
    """Raised for validation errors."""
    def __init__(self, message: str = "Some of the provided values are not valid.", cause: Exception = None):
        super().__init__(message)
        self.cause = cause

