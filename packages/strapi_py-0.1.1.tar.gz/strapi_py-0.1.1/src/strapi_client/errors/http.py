import httpx
from .base import StrapiError


class StrapiHTTPError(StrapiError):
    """Raised for non-2xx responses."""
    def __init__(self, message: str, response: httpx.Response):
        super().__init__(message)
        self.response = response

class StrapiHTTPBadRequestError(StrapiHTTPError):
    """Raised for 400 Bad Request responses."""
    pass

class StrapiHTTPUnauthorizedError(StrapiHTTPError):
    """Raised for 401 Unauthorized responses."""
    pass

class StrapiHTTPForbiddenError(StrapiHTTPError):
    """Raised for 403 Forbidden responses."""
    pass

class StrapiHTTPNotFoundError(StrapiHTTPError):
    """Raised for 404 Not Found responses."""
    pass

class StrapiHTTPTimeoutError(StrapiHTTPError):
    """Raised for 408 Request Timeout responses."""
    pass

class StrapiHTTPInternalServerError(StrapiHTTPError):
    """Raised for 500 Internal Server Error responses."""
    pass
