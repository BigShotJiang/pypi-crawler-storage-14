import httpx
import json
from typing import Optional, Dict
from .auth.manager import AuthManager

from .errors.http import (
    StrapiHTTPError,
    StrapiHTTPBadRequestError,
    StrapiHTTPUnauthorizedError,
    StrapiHTTPForbiddenError,
    StrapiHTTPNotFoundError,
    StrapiHTTPTimeoutError,
    StrapiHTTPInternalServerError,
)


STATUS_CODE_TO_ERROR = {
    400: StrapiHTTPBadRequestError,
    401: StrapiHTTPUnauthorizedError,
    403: StrapiHTTPForbiddenError,
    404: StrapiHTTPNotFoundError,
    408: StrapiHTTPTimeoutError,
    500: StrapiHTTPInternalServerError,
}


class HttpClient:
    def __init__(
        self,
        base_url: str,
        headers: Optional[Dict[str, str]] = None,
        auth_manager: Optional[AuthManager] = None,
    ):
        self._client = httpx.Client(base_url=base_url, headers=headers or {})
        self._auth_manager = auth_manager

    def request(self, method: str, url: str, **kwargs):
        if self._auth_manager:
            self._auth_manager.authenticate(self)

        headers = kwargs.pop("headers", {})
        if self._auth_manager:
            headers = self._auth_manager.authenticate_request(headers)

        if headers:
            kwargs["headers"] = headers

        try:
            response = self._client.request(method, url, **kwargs)
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401 and self._auth_manager:
                self._auth_manager.handle_unauthorized_error()
            raise self.map_response_to_http_error(e.response) from e

    @staticmethod
    def map_response_to_http_error(response: httpx.Response) -> StrapiHTTPError:
        error_class = STATUS_CODE_TO_ERROR.get(response.status_code, StrapiHTTPError)
        
        detail_message = f"HTTP error occurred: {response.status_code}"
        try:
            error_data = response.json()
            if isinstance(error_data, dict):
                # Handle standard Strapi v4 error format: { error: {status, name, message, details } }
                if "error" in error_data:
                    error_obj = error_data["error"]
                    if isinstance(error_obj, dict):
                        message_parts = []
                        
                        if "name" in error_obj:
                            message_parts.append(f"[{error_obj['name']}]")
                        
                        if "message" in error_obj:
                            message_parts.append(error_obj["message"])
                        
                        if "details" in error_obj and error_obj["details"]:
                            details = error_obj["details"]
                            if isinstance(details, dict):
                                if "errors" in details:
                                    errors_list = details["errors"]
                                    if isinstance(errors_list, list) and errors_list:
                                        error_details = []
                                        for err in errors_list:
                                            if isinstance(err, dict):
                                                path = err.get("path", ["unknown"])
                                                path_str = ".".join(str(p) for p in path) if isinstance(path, list) else str(path)
                                                msg = err.get("message", "validation error")
                                                error_details.append(f"  - {path_str}: {msg}")
                                        if error_details:
                                            message_parts.append("\nValidation errors:\n" + "\n".join(error_details))
                                else:
                                    message_parts.append(f"\nDetails: {json.dumps(details, indent=2)}")
                            elif isinstance(details, str):
                                message_parts.append(f"\nDetails: {details}")
                        
                        if message_parts:
                            detail_message = f"Strapi API Error ({response.status_code}): {' '.join(message_parts)}"
                
                elif "message" in error_data:
                    detail_message = f"Strapi API Error ({response.status_code}): {error_data['message']}"
                
                if detail_message == f"HTTP error occurred: {response.status_code}":
                    response_text = response.text[:500]
                    detail_message = f"HTTP error occurred: {response.status_code}\nResponse: {response_text}"
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            response_text = response.text[:500] if response.text else "No response body"
            detail_message = f"HTTP error occurred: {response.status_code}\nResponse: {response_text}"
        
        return error_class(detail_message, response=response)

    def get(self, url: str, **kwargs):
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs):
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs):
        return self.request("PUT", url, **kwargs)

    def delete(self, url: str, **kwargs):
        return self.request("DELETE", url, **kwargs)
