from typing import Optional, Dict
from .client import StrapiClient

from .validators.client import validate_config
from .errors import (
    StrapiError,
    StrapiValidationError,
    StrapiHTTPError,
    StrapiHTTPBadRequestError,
    StrapiHTTPUnauthorizedError,
    StrapiHTTPForbiddenError,
    StrapiHTTPNotFoundError,
    StrapiHTTPTimeoutError,
    StrapiHTTPInternalServerError,
    StrapiInitializationError,
    StrapiURLParsingError,
)


def strapi(
    base_url: str,
    auth: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
) -> StrapiClient:
    """
    Creates a new instance of the Strapi Client.
    
    Args:
        base_url: The base URL of your Strapi API (e.g., "http://localhost:1337/api")
        auth: Optional API token for authentication
        headers: Optional custom headers to include in all requests
        
    Returns:
        StrapiClient: A configured Strapi client instance
        
    Raises:
        StrapiValidationError: If base_url is invalid or auth token is empty
        StrapiURLParsingError: If base_url cannot be parsed
        
    Example:
        >>> client = strapi(base_url="http://localhost:1337/api", auth="your-api-token")
        >>> response = client.fetch('/articles')
    """
    config = {"base_url": base_url, "auth_token": auth}
    try:
        validate_config(config)
    except StrapiValidationError as e:
        raise e
        
    return StrapiClient(base_url=base_url, auth_token=auth, headers=headers)

__all__ = [
    "strapi",
    "StrapiClient",
    # Error types
    "StrapiError",
    "StrapiValidationError",
    "StrapiHTTPError",
    "StrapiHTTPBadRequestError",
    "StrapiHTTPUnauthorizedError",
    "StrapiHTTPForbiddenError",
    "StrapiHTTPNotFoundError",
    "StrapiHTTPTimeoutError",
    "StrapiHTTPInternalServerError",
    "StrapiInitializationError",
    "StrapiURLParsingError",
]
