from ..errors.base import StrapiError
import httpx
from typing import Optional, Union


class FileError(StrapiError):
    """Base class for file-related errors."""
    def __init__(self, message: str = "An error occurred with file operations.", cause: Exception = None, file_id: Optional[int | str] = None, request: Optional[httpx.Request] = None, response: Optional[httpx.Response] = None):
        super().__init__(message, cause)
        self.file_id = file_id
        self.request = request
        self.response = response

class FileNotFoundError(FileError):
    """Raised when a file is not found."""
    def __init__(self, file_id: Union[int, str], message: str = None, cause: Exception = None, request: Optional[httpx.Request] = None, response: Optional[httpx.Response] = None):
        if message is None:
            message = f"File with ID {file_id} not found."
        super().__init__(message, cause, file_id, request, response)

class FileForbiddenError(FileError):
    """Raised when access to a file is forbidden."""
    def __init__(self, file_id: Optional[Union[int, str]] = None, message: str = None, cause: Exception = None, request: Optional[httpx.Request] = None, response: Optional[httpx.Response] = None):
        if message is None:
            if file_id:
                message = f"Access to file with ID {file_id} is forbidden."
            else:
                message = "Access to files is forbidden."
        super().__init__(message, cause, file_id, request, response)
