from typing import Optional, Dict, Any, Union, BinaryIO
from ..http_client import HttpClient
from ..errors import StrapiHTTPNotFoundError, StrapiHTTPForbiddenError
from .errors import FileNotFoundError, FileForbiddenError


class FilesManager:
    """
    Manager for Strapi file operations.
    
    Provides methods to upload, find, update, and delete files in Strapi's media library.
    Automatically maps HTTP errors to file-specific exceptions.
    """
    
    def __init__(self, http_client: HttpClient):
        """
        Initialize the files manager.
        
        Args:
            http_client: The HTTP client instance to use for requests
        """
        self._http_client = http_client
        self.path = "/upload/files"

    def _map_file_error(self, e: Exception, file_id: Optional[int | str] = None):
        """
        Map HTTP errors to file-specific exceptions.
        
        Args:
            e: The exception to map
            file_id: Optional file ID for context in error messages
            
        Raises:
            FileNotFoundError: If the file was not found (404)
            FileForbiddenError: If access to the file is forbidden (403)
            Exception: Re-raises the original exception if not a mappable HTTP error
        """
        if isinstance(e, StrapiHTTPNotFoundError):
            raise FileNotFoundError(file_id=file_id, cause=e, request=e.response.request, response=e.response) from e
        if isinstance(e, StrapiHTTPForbiddenError):
            raise FileForbiddenError(file_id=file_id, cause=e, request=e.response.request, response=e.response) from e
        raise e

    def find(self, params: Optional[Dict[str, Any]] = None):
        """
        Get a list of files from the media library.
        
        Args:
            params: Optional query parameters for filtering and sorting
                   Supports 'filters', 'sort', 'pagination', etc.
                   
        Returns:
            httpx.Response: Response containing array of file objects
            
        Example:
            >>> response = client.files.find()
            >>> files = response.json()
            >>> 
            >>> # Filter by mime type
            >>> response = client.files.find(params={
            ...     'filters': {'mime': {'$contains': 'image'}},
            ...     'sort': 'createdAt:desc'
            ... })
        """
        try:
            return self._http_client.get(self.path, params=params)
        except Exception as e:
            self._map_file_error(e)

    def find_one(self, file_id: Union[int, str], params: Optional[Dict[str, Any]] = None):
        """
        Get a single file by its ID.
        
        Args:
            file_id: The ID of the file to retrieve
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response containing the file object
            
        Raises:
            FileNotFoundError: If the file with the given ID doesn't exist
            
        Example:
            >>> response = client.files.find_one(1)
            >>> file_data = response.json()
            >>> print(f"File URL: {file_data['url']}")
        """
        try:
            return self._http_client.get(f"{self.path}/{file_id}", params=params)
        except Exception as e:
            self._map_file_error(e, file_id)

    def update(self, file_id: Union[int, str], file_info: Dict[str, Any], params: Optional[Dict[str, Any]] = None):
        """
        Update file metadata (name, alternativeText, caption, etc.).
        
        Note: This updates metadata only, not the file content itself.
        
        Args:
            file_id: The ID of the file to update
            file_info: Dictionary containing file metadata to update
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response containing the updated file object
            
        Raises:
            FileNotFoundError: If the file with the given ID doesn't exist
            
        Example:
            >>> response = client.files.update(
            ...     file_id=1,
            ...     file_info={
            ...         'name': 'new-filename.jpg',
            ...         'alternativeText': 'Updated alt text',
            ...         'caption': 'Updated caption'
            ...     }
            ... )
        """
        try:
            return self._http_client.put(f"{self.path}/{file_id}", json={"fileInfo": file_info}, params=params)
        except Exception as e:
            self._map_file_error(e, file_id)

    def delete(self, file_id: Union[int, str], params: Optional[Dict[str, Any]] = None):
        """
        Delete a file from the media library.
        
        Args:
            file_id: The ID of the file to delete
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response confirming deletion
            
        Raises:
            FileNotFoundError: If the file with the given ID doesn't exist
            FileForbiddenError: If you don't have permission to delete the file
            
        Example:
            >>> response = client.files.delete(1)
        """
        try:
            return self._http_client.delete(f"{self.path}/{file_id}", params=params)
        except Exception as e:
            self._map_file_error(e, file_id)

    def upload(
        self,
        file_data: Union[bytes, BinaryIO],
        filename: str,
        mimetype: str,
        file_info: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ):
        """
        Upload a file to the media library.
        
        Args:
            file_data: The file content as bytes or a file-like object
            filename: The name for the uploaded file
            mimetype: The MIME type of the file (e.g., 'image/jpeg', 'application/pdf')
            file_info: Optional metadata for the file (alternativeText, caption, etc.)
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response containing the uploaded file object(s)
            
        Raises:
            FileForbiddenError: If you don't have permission to upload files
            
        Example:
            >>> # Upload from bytes
            >>> with open('image.jpg', 'rb') as f:
            ...     file_data = f.read()
            >>> response = client.files.upload(
            ...     file_data=file_data,
            ...     filename='image.jpg',
            ...     mimetype='image/jpeg',
            ...     file_info={'alternativeText': 'My image', 'caption': 'A caption'}
            ... )
            >>> 
            >>> # Upload from file object
            >>> with open('document.pdf', 'rb') as f:
            ...     response = client.files.upload(
            ...         file_data=f,
            ...         filename='document.pdf',
            ...         mimetype='application/pdf'
            ...     )
        """
        files = {"files": (filename, file_data, mimetype)}
        data = {}
        if file_info:
            data["fileInfo"] = file_info

        try:
            return self._http_client.post("/upload", files=files, data=data, params=params)
        except Exception as e:
            self._map_file_error(e)