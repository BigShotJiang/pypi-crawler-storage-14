from abc import ABC
from typing import Optional, TypedDict
from ..http_client import HttpClient


class PluginConfig(TypedDict, total=False):
    name: str
    prefix: Optional[str]

class ContentTypeManagerOptions(TypedDict, total=False):
    resource: str
    path: Optional[str]
    plugin: Optional[PluginConfig]

class ContentTypeManager(ABC):
    def __init__(self, http_client: HttpClient, options: ContentTypeManagerOptions):
        self._http_client = http_client
        self._options = options
        self._resource = options["resource"]
        self._path = options.get("path")
        self._plugin = options.get("plugin")

        self._root_path = self._build_root_path()

    def _build_root_path(self) -> str:
        if self._path:
            return self._path

        if self._plugin:
            plugin_prefix = self._plugin.get("prefix")
            if plugin_prefix is not None:
                return f"/{plugin_prefix}/{self._resource}" if plugin_prefix else f"/{self._resource}"
            return f"/{self._plugin['name']}/{self._resource}"
        
        return f"/{self._resource}"
