from typing import Optional, Dict, Any, Union
from .base import ContentTypeManager, ContentTypeManagerOptions, HttpClient


class CollectionTypeManager(ContentTypeManager):
    """
    Manager for Strapi collection type operations (multi-entry content types).
    
    Collection types represent content with multiple entries like articles, products, or users.
    Provides CRUD operations (find, find_one, create, update, delete).
    """
    
    def __init__(self, http_client: HttpClient, options: ContentTypeManagerOptions):
        """Initialize the collection type manager."""
        super().__init__(http_client, options)
        self._is_users_permissions = self._plugin and self._plugin.get("name") == "users-permissions"

    def find(self, params: Optional[Dict[str, Any]] = None):
        """
        Get all entries of this collection type.
        
        Args:
            params: Optional query parameters (filters, sort, pagination, populate, etc.)
            
        Returns:
            httpx.Response: Response containing array of entries
            
        Example:
            >>> articles = client.collection('articles')
            >>> response = articles.find(params={
            ...     'filters': {'published': True},
            ...     'sort': ['createdAt:desc'],
            ...     'pagination': {'page': 1, 'pageSize': 10}
            ... })
        """
        return self._http_client.get(self._root_path, params=params)

    def find_one(self, entry_id: Union[int, str], params: Optional[Dict[str, Any]] = None):
        """
        Get a single entry by its ID.
        
        Args:
            entry_id: The ID of the entry to retrieve
            params: Optional query parameters (populate, fields, etc.)
            
        Returns:
            httpx.Response: Response containing the entry
            
        Example:
            >>> articles = client.collection('articles')
            >>> response = articles.find_one(1, params={'populate': '*'})
        """
        return self._http_client.get(f"{self._root_path}/{entry_id}", params=params)

    def create(self, data: Dict[str, Any], params: Optional[Dict[str, Any]] = None):
        """
        Create a new entry.
        
        Args:
            data: The entry data to create
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response containing the created entry
            
        Example:
            >>> articles = client.collection('articles')
            >>> response = articles.create(data={
            ...     'title': 'My Article',
            ...     'content': 'Article content here'
            ... })
        """
        payload = data if self._is_users_permissions else {"data": data}
        return self._http_client.post(self._root_path, json=payload, params=params)

    def update(self, entry_id: Union[int, str], data: Dict[str, Any], params: Optional[Dict[str, Any]] = None):
        """
        Update an existing entry.
        
        Args:
            entry_id: The ID of the entry to update
            data: The data to update
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response containing the updated entry
            
        Example:
            >>> articles = client.collection('articles')
            >>> response = articles.update(1, data={'title': 'Updated Title'})
        """
        payload = data if self._is_users_permissions else {"data": data}
        return self._http_client.put(f"{self._root_path}/{entry_id}", json=payload, params=params)

    def delete(self, entry_id: Union[int, str], params: Optional[Dict[str, Any]] = None):
        """
        Delete an entry.
        
        Args:
            entry_id: The ID of the entry to delete
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response confirming deletion
            
        Example:
            >>> articles = client.collection('articles')
            >>> response = articles.delete(1)
        """
        return self._http_client.delete(f"{self._root_path}/{entry_id}", params=params)
