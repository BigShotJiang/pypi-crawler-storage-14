from typing import Optional, Dict, Any
from .base import ContentTypeManager, ContentTypeManagerOptions
from ..http_client import HttpClient


class SingleTypeManager(ContentTypeManager):
    """
    Manager for Strapi single type operations (single-entry content types).
    
    Single types represent content with only one entry like homepage, about page, or global settings.
    Provides find, update, and delete operations (no create, as single types have only one entry).
    """
    
    def __init__(self, http_client: HttpClient, options: ContentTypeManagerOptions):
        """Initialize the single type manager."""
        super().__init__(http_client, options)
        self._is_users_permissions = self._plugin and self._plugin.get("name") == "users-permissions"

    def find(self, params: Optional[Dict[str, Any]] = None):
        """
        Get the single type entry.
        
        Args:
            params: Optional query parameters (populate, fields, locale, etc.)
            
        Returns:
            httpx.Response: Response containing the entry
            
        Example:
            >>> homepage = client.single('homepage')
            >>> response = homepage.find(params={'populate': '*'})
        """
        return self._http_client.get(self._root_path, params=params)

    def update(self, data: Dict[str, Any], params: Optional[Dict[str, Any]] = None):
        """
        Update the single type entry.
        
        Args:
            data: The data to update
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response containing the updated entry
            
        Example:
            >>> homepage = client.single('homepage')
            >>> response = homepage.update(data={
            ...     'title': 'Welcome',
            ...     'description': 'Welcome to our site'
            ... })
        """
        payload = data if self._is_users_permissions else {"data": data}
        return self._http_client.put(self._root_path, json=payload, params=params)

    def delete(self, params: Optional[Dict[str, Any]] = None):
        """
        Delete the single type entry.
        
        Args:
            params: Optional query parameters
            
        Returns:
            httpx.Response: Response confirming deletion
            
        Example:
            >>> homepage = client.single('homepage')
            >>> response = homepage.delete()
        """
        return self._http_client.delete(self._root_path, params=params)
