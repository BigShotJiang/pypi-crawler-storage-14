from typing import Callable, Dict, Any, Optional
from ..errors.base import StrapiError
from .providers.abstract import AuthProvider


class AuthProviderFactory:
    def __init__(self):
        self._creators: Dict[str, Callable[..., AuthProvider]] = {}

    def register(self, identifier: str, creator: Callable[..., AuthProvider]):
        self._creators[identifier] = creator

    def create(self, identifier: str, options: Optional[Dict[str, Any]] = None) -> AuthProvider:
        creator = self._creators.get(identifier)
        if not creator:
            raise StrapiError(f"Auth provider '{identifier}' is not registered.")
        return creator(**(options or {}))
