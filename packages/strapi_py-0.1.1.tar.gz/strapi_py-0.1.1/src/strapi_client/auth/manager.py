from typing import Optional, Dict, TYPE_CHECKING, Any
from .providers.abstract import AuthProvider
from .factory import AuthProviderFactory
from .providers.api_token import ApiTokenAuthProvider


if TYPE_CHECKING:
    from ...http_client import HttpClient

class AuthManager:
    def __init__(self, factory: Optional[AuthProviderFactory] = None):
        self._provider: Optional[AuthProvider] = None
        self._factory = factory or AuthProviderFactory()
        self._factory.register(ApiTokenAuthProvider.identifier, ApiTokenAuthProvider)

    def set_strategy(self, identifier: str, options: Optional[Dict[str, Any]] = None):
        self._provider = self._factory.create(identifier, options)

    def get_headers(self) -> Dict[str, str]:
        if self._provider:
            return self._provider.get_headers()
        return {}

    def authenticate(self, http_client: "HttpClient"):
        if self._provider:
            try:
                self._provider.authenticate(http_client)
            except Exception:
                self._provider = None
                raise

    def authenticate_request(self, headers: Dict[str, str]) -> Dict[str, str]:
        if self._provider:
            auth_headers = self._provider.get_headers()
            headers.update(auth_headers)
        return headers

    def handle_unauthorized_error(self):
        self._provider = None

    @property
    def is_authenticated(self) -> bool:
        return self._provider is not None
