from abc import ABC, abstractmethod
from typing import Dict, TYPE_CHECKING


if TYPE_CHECKING:
    from ...http_client import HttpClient

class AuthProvider(ABC):
    @abstractmethod
    def get_headers(self) -> Dict[str, str]:
        """
        Returns the headers required for authentication.
        """
        pass

    @abstractmethod
    def authenticate(self, http_client: "HttpClient"):
        """
        Performs authentication logic.
        """
        pass
