from .abstract import AuthProvider
from typing import Dict, TYPE_CHECKING
from ...errors import StrapiValidationError


if TYPE_CHECKING:
    from ...http_client import HttpClient

class ApiTokenAuthProvider(AuthProvider):
    identifier = "api-token"

    def __init__(self, token: str):
        if not isinstance(token, str) or not token.strip():
            raise StrapiValidationError("API Token must be a non-empty string.")
        self._token = token

    def get_headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}

    def authenticate(self, http_client: "HttpClient"):
        """
        For API tokens, authentication is handled by adding the token to the headers,
        so this method is a no-op.
        """
        pass
