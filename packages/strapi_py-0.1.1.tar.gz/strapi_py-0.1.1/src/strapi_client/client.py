from typing import Optional, Dict
from .http_client import HttpClient
from .auth.manager import AuthManager
from .auth.providers.api_token import ApiTokenAuthProvider
from .content_types.base import ContentTypeManagerOptions, PluginConfig
from .content_types.collection import CollectionTypeManager
from .content_types.single import SingleTypeManager

from .files.manager import FilesManager


class StrapiClient:
    """
    Main client for interacting with Strapi CMS API.
    
    Provides methods to work with collection types, single types, and file operations.
    Handles authentication and HTTP requests to Strapi endpoints.
    
    Attributes:
        base_url: The base URL of the Strapi API
        files: FilesManager instance for file operations
    """
    
    def __init__(
        self,
        base_url: str,
        auth_token: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
    ):
        """
        Initialize the Strapi client.
        
        Args:
            base_url: The base URL of your Strapi API (e.g., "http://localhost:1337/api")
            auth_token: Optional API token for authentication
            headers: Optional custom headers to include in all requests
        """
        self.base_url = base_url
        self._auth_manager = AuthManager()

        if auth_token:
            self._auth_manager.set_strategy(ApiTokenAuthProvider.identifier, {"token": auth_token})

        self._http_client = HttpClient(
            base_url=base_url, headers=headers, auth_manager=self._auth_manager
        )
        self._files = FilesManager(http_client=self._http_client)

    @property
    def files(self) -> "FilesManager":
        """
        Access the files manager for file upload, download, and management operations.
        
        Returns:
            FilesManager: Manager instance for file operations
        """
        return self._files

    def fetch(self, url: str, **kwargs):
        """
        Make a GET request to a custom endpoint.
        
        Useful for accessing custom endpoints or endpoints not covered by
        the collection/single type managers.
        
        Args:
            url: The endpoint URL (relative to base_url)
            **kwargs: Additional arguments to pass to the HTTP client
            
        Returns:
            httpx.Response: The HTTP response object
            
        Example:
            >>> response = client.fetch('/custom-endpoint')
            >>> data = response.json()
        """
        return self._http_client.request(method="GET", url=url, **kwargs)

    def collection(self, resource: str, path: Optional[str] = None, plugin: Optional[PluginConfig] = None) -> "CollectionTypeManager":
        """
        Create a manager for a collection type (multi-entry content type).
        
        Collection types represent multiple entries like articles, products, or users.
        
        Args:
            resource: The name of the collection resource (e.g., "articles")
            path: Optional custom path (overrides default path construction)
            plugin: Optional plugin configuration for plugin-specific endpoints
            
        Returns:
            CollectionTypeManager: Manager instance with CRUD operations
            
        Example:
            >>> articles = client.collection('articles')
            >>> response = articles.find()
            >>> response = articles.find_one(1)
            >>> response = articles.create(data={'title': 'New Article'})
        """
        options: ContentTypeManagerOptions = {"resource": resource}
        if path:
            options["path"] = path
        if plugin:
            options["plugin"] = plugin
        return CollectionTypeManager(http_client=self._http_client, options=options)

    def single(self, resource: str, path: Optional[str] = None, plugin: Optional[PluginConfig] = None) -> "SingleTypeManager":
        """
        Create a manager for a single type (single-entry content type).
        
        Single types represent a single entry like homepage, about page, or settings.
        
        Args:
            resource: The name of the single type resource (e.g., "homepage")
            path: Optional custom path (overrides default path construction)
            plugin: Optional plugin configuration for plugin-specific endpoints
            
        Returns:
            SingleTypeManager: Manager instance with find, update, and delete operations
            
        Example:
            >>> homepage = client.single('homepage')
            >>> response = homepage.find()
            >>> response = homepage.update(data={'title': 'Welcome'})
        """
        options: ContentTypeManagerOptions = {"resource": resource}
        if path:
            options["path"] = path
        if plugin:
            options["plugin"] = plugin
        return SingleTypeManager(http_client=self._http_client, options=options)
