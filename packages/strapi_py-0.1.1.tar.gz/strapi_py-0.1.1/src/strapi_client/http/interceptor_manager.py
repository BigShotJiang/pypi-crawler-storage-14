from typing import Any, Awaitable, Callable, Generic, List, Optional, TypeVar, Union
import copy


T = TypeVar('T')

Interceptor = Union[Callable[[T], Awaitable[T]], Callable[[T], T]]
RejectedInterceptor = Union[Callable[[Any], Awaitable[Any]], Callable[[Any], Any]]

class Handler(Generic[T]):
    def __init__(self, fulfilled: Optional[Interceptor[T]] = None, rejected: Optional[RejectedInterceptor] = None):
        self.fulfilled = fulfilled
        self.rejected = rejected

class HttpInterceptorManager(Generic[T]):
    def __init__(self, handlers: Optional[List[Handler[T]]] = None):
        self._handlers: List[Handler[T]] = handlers or []

    def use(self, fulfilled: Optional[Interceptor[T]] = None, rejected: Optional[RejectedInterceptor] = None) -> 'HttpInterceptorManager[T]':
        self._handlers.append(Handler(fulfilled, rejected))
        return self

    def clone(self) -> 'HttpInterceptorManager[T]':
        return HttpInterceptorManager(copy.deepcopy(self._handlers))

    async def execute(self, value: T) -> T:
        out = value
        for handler in self._handlers:
            try:
                if handler.fulfilled:
                    # Check if the interceptor is an async function
                    if hasattr(handler.fulfilled, '__await__'):
                        out = await handler.fulfilled(out)
                    else:
                        out = handler.fulfilled(out)
            except Exception as error:
                if handler.rejected:
                    if hasattr(handler.rejected, '__await__'):
                        out = await handler.rejected(error)
                    else:
                        out = handler.rejected(error)
                else:
                    raise error
        return out

    async def reject(self, error: Any) -> Any:
        out = error
        for handler in self._handlers:
            if handler.rejected:
                if hasattr(handler.rejected, '__await__'):
                    out = await handler.rejected(out)
                else:
                    out = handler.rejected(out)
        return out
