import re
from typing import Literal, TypedDict


SlashConfig = Literal['single', True, False]

class FormatterConfig(TypedDict, total=False):
    trailing_slashes: SlashConfig
    leading_slashes: SlashConfig

DEFAULT_CONFIG: FormatterConfig = {
    "trailing_slashes": False,
    "leading_slashes": False,
}

class PathFormatter:
    @staticmethod
    def format(path: str, config: FormatterConfig = None) -> str:
        if config is None:
            config = DEFAULT_CONFIG
        
        path = PathFormatter.format_trailing_slashes(path, config.get("trailing_slashes", DEFAULT_CONFIG["trailing_slashes"]))

        path = PathFormatter.format_leading_slashes(path, config.get("leading_slashes", DEFAULT_CONFIG["leading_slashes"]))

        return path

    @staticmethod
    def format_trailing_slashes(path: str, config: SlashConfig = DEFAULT_CONFIG["trailing_slashes"]) -> str:
        if config == 'single':
            return PathFormatter.ensure_single_trailing_slash(path)
        elif not config:
            return PathFormatter.remove_trailing_slashes(path)
        else:
            return path

    @staticmethod
    def remove_trailing_slashes(path: str) -> str:
        return re.sub(r'\/+$', '', path)

    @staticmethod
    def ensure_single_trailing_slash(path: str) -> str:
        return f"{PathFormatter.remove_trailing_slashes(path)}/"

    @staticmethod
    def format_leading_slashes(path: str, config: SlashConfig = DEFAULT_CONFIG["leading_slashes"]) -> str:
        if config == 'single':
            return PathFormatter.ensure_single_leading_slash(path)
        elif not config:
            return PathFormatter.remove_leading_slashes(path)
        else:
            return path

    @staticmethod
    def remove_leading_slashes(path: str) -> str:
        return re.sub(r'^\/+', '', path)

    @staticmethod
    def ensure_single_leading_slash(path: str) -> str:
        return f"/{PathFormatter.remove_leading_slashes(path)}"
