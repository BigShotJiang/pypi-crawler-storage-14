from typing import Dict, Any
from urllib.parse import urlparse
from ..errors import StrapiValidationError, StrapiURLParsingError


def validate_config(config: Dict[str, Any]):
    """
    Validates the client configuration.
    """
    base_url = config.get("base_url")
    if not base_url or not isinstance(base_url, str):
        raise StrapiValidationError("The `base_url` must be a string.")

    try:
        parsed_url = urlparse(base_url)
    except Exception as e:
        raise StrapiURLParsingError(url=base_url, cause=e)

    if parsed_url.scheme not in ["http", "https"] or not parsed_url.netloc:
        raise StrapiURLParsingError(url=base_url, message=f"Invalid `base_url`: {base_url}")

    auth_token = config.get("auth_token")
    if auth_token is not None and not isinstance(auth_token, str):
        raise StrapiValidationError("The `auth_token` must be a string.")
    if auth_token == "":
        raise StrapiValidationError("The `auth_token` cannot be an empty string.")

    headers = config.get("headers")
    if headers is not None:
        if not isinstance(headers, dict):
            raise StrapiValidationError("Headers must be a valid object.")
        for key, value in headers.items():
            if not isinstance(value, str):
                raise StrapiValidationError("Header values must be strings.")
