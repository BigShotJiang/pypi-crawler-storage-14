from typing import Any, Dict, Union
from urllib.parse import urlencode, urlparse, urlunparse, quote


def stringify_query_params(params: Dict[str, Any]) -> str:
    
    def encode_dict(data, prefix=''):
        encoded_pairs = []
        for key, value in data.items():
            new_prefix = f"{prefix}[{key}]" if prefix else key
            if isinstance(value, dict):
                encoded_pairs.extend(encode_dict(value, new_prefix))
            elif isinstance(value, list):
                encoded_pairs.extend(encode_list(value, new_prefix))
            else:
                encoded_pairs.append((new_prefix, value))
        return encoded_pairs

    def encode_list(data, prefix=''):
        encoded_pairs = []
        for i, item in enumerate(data):
            new_prefix = f"{prefix}[{i}]"
            if isinstance(item, dict):
                encoded_pairs.extend(encode_dict(item, new_prefix))
            elif isinstance(item, list):
                encoded_pairs.extend(encode_list(item, new_prefix))
            else:
                encoded_pairs.append((new_prefix, item))
        return encoded_pairs

    if not isinstance(params, dict):
        return ""
        
    all_pairs = encode_dict(params)
    return urlencode(all_pairs, doseq=True, quote_via=quote)

class URLHelper:
    @staticmethod
    def append_query_params(url: str, query_params: Dict[str, Any] = None) -> str:
        if not query_params:
            return url

        query_string = stringify_query_params(query_params)

        if not query_string:
            return url
            
        if '?' in url:
            return f"{url}&{query_string}"
        else:
            return f"{url}?{query_string}"

    @staticmethod
    def stringify_query_params(query_params: Dict[str, Any]) -> str:
        return stringify_query_params(query_params)

    @staticmethod
    def to_readable_path(url: Union[str, Any]) -> str:
        if not isinstance(url, str):
            url = str(url)
        parsed_url = urlparse(url)
        return urlunparse((parsed_url.scheme, parsed_url.netloc, parsed_url.path, '', '', ''))
