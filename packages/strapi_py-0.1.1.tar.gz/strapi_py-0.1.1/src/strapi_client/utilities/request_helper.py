from typing import Any
from .url_helper import URLHelper
import httpx


class RequestHelper:
    @staticmethod
    def format(input_request: Any) -> str:
        if not isinstance(input_request, httpx.Request):
            raise TypeError(f"Invalid input, expected a Request instance but found {type(input_request)}")

        return f"{input_request.method} - {URLHelper.to_readable_path(input_request.url)}"
