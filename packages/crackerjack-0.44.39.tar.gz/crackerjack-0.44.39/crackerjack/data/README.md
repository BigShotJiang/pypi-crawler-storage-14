> Crackerjack Docs: [Main](<../../README.md>) | [Crackerjack Package](<../README.md>) | [Data](<./README.md>)

# Data

Static data and assets used by the package (keep small; large assets belong elsewhere).

## Related

- [Crackerjack Package](<../README.md>) - Parent package
- [Documentation](<../documentation/README.md>) - Documentation helpers
- [UI Templates](<../ui/templates/README.md>) - UI template files
