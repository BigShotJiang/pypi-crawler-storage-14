# AnyLogic Export

Show help message.

```bash
anylogic-export -h
```

Export an AnyLogic model.

```bash
anylogic-export DistributionCenter/DistributionCenter.alpx
```

## Benchmarking

Originally developed for one of the biggest AnyLogic models in the world. Exporting should take less time for most projects.
