"""URI adapters for exploring non-file resources."""

from .env import EnvAdapter

__all__ = ['EnvAdapter']
