"""
Setup script para compatibilidade com instalação antiga.
Este arquivo é opcional quando usando pyproject.toml moderno.
"""

from setuptools import setup

# setup() é definido no pyproject.toml
# Este arquivo existe apenas para compatibilidade
setup()

