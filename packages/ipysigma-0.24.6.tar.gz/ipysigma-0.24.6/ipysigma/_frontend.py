#!/usr/bin/env python
# coding: utf-8

"""
Information about the frontend package of the widgets.
"""

module_name = "ipysigma"
module_version = "^0.24.6"
