# xl-network

一个功能强大的网络工具包，提供端口扫描等网络安全功能。

## 功能特性

- **快速端口扫描**：多线程并发扫描，提高扫描效率
- **灵活配置**：支持自定义端口范围、线程数、超时时间
- **命令行界面**：简单易用的CLI工具
- **跨平台**：支持Windows、Linux、macOS

## 安装

```bash
# 从源码安装
cd D:\git\libs\py-network
pip install -e .
```

## 使用方法

### 命令行使用

```bash
# 基本用法：扫描本地主机的前1024个端口
xl-network scan 127.0.0.1 1 1024

# 扫描指定主机的特定端口范围
xl-network scan localhost 80 443

# 使用自定义线程数和详细输出
xl-network scan example.com 1 65535 --threads 200 --verbose

# 设置连接超时时间
xl-network scan 192.168.1.1 1 1000 --timeout 2.0

# 查看帮助信息
xl-network scan --help
```

### 编程接口

```python
from xl_network import scan_ports, port_scan

# 扫描单个端口
open_port = port_scan("127.0.0.1", 80)
if open_port:
    print(f"端口 {open_port} 开放")

# 扫描端口范围
open_ports = scan_ports("127.0.0.1", 1, 1024, num_threads=50)
print(f"开放端口: {open_ports}")
```

## 命令行参数

- `host`: 目标主机（IP地址或域名）
- `start_port`: 起始端口号（1-65535）
- `end_port`: 结束端口号（1-65535）
- `--threads, -t`: 线程数量（默认：100）
- `--timeout`: 连接超时时间，秒（默认：1.0）
- `--verbose, -v`: 显示详细信息

## 示例

```bash
# 扫描常见的Web端口
xl-network scan example.com 80 443 --verbose

# 快速扫描本地主机
xl-network scan 127.0.0.1 1 1000 --threads 50

# 扫描整个端口范围（较慢）
xl-network scan 192.168.1.1 1 65535 --threads 300 --timeout 0.5
```

## 注意事项

- 请确保你有权限扫描目标主机
- 扫描大量端口可能会触发目标主机的安全防护措施
- 建议在授权的网络环境中使用此工具

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！