"""
CLI interface for xl-network package
"""

import sys
import argparse
from .port_scanner import scan_ports


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        prog="xl-network",
        description="网络工具包 - xl-network"
    )

    subparsers = parser.add_subparsers(dest='command', help='可用命令')

    # scan 子命令
    scan_parser = subparsers.add_parser(
        'scan',
        help='端口扫描工具',
        description='扫描指定主机的端口范围',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  xl-network scan 127.0.0.1 1 1024
  xl-network scan localhost 80 443 --threads 50 --verbose
  xl-network scan example.com 1 65535 --timeout 2
        """
    )

    scan_parser.add_argument('host', help='目标主机（IP地址或域名）')
    scan_parser.add_argument('start_port', type=int, help='起始端口号（1-65535）')
    scan_parser.add_argument('end_port', type=int, help='结束端口号（1-65535）')
    scan_parser.add_argument('--threads', '-t', type=int, default=100,
                            help='线程数量（默认：100）')
    scan_parser.add_argument('--timeout', type=float, default=1.0,
                            help='连接超时时间，秒（默认：1.0）')
    scan_parser.add_argument('--verbose', '-v', action='store_true',
                            help='显示详细信息')

    # 如果没有提供子命令，显示帮助
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)

    args = parser.parse_args()

    if args.command == 'scan':
        # 验证输入
        if args.start_port < 1 or args.end_port > 65535 or args.start_port > args.end_port:
            print("错误：端口范围无效！端口应在 1-65535 之间，且起始端口小于等于结束端口。", file=sys.stderr)
            sys.exit(1)

        if args.threads < 1 or args.threads > 1000:
            print("错误：线程数量应在 1-1000 之间。", file=sys.stderr)
            sys.exit(1)

        if args.timeout <= 0 or args.timeout > 10:
            print("错误：超时时间应在 0-10 秒之间。", file=sys.stderr)
            sys.exit(1)

        # 执行扫描
        try:
            scan_ports(
                host=args.host,
                start_port=args.start_port,
                end_port=args.end_port,
                num_threads=args.threads,
                verbose=args.verbose
            )
        except KeyboardInterrupt:
            print("\n\n扫描被用户中断。")
            sys.exit(0)
        except Exception as e:
            print(f"\n错误：{e}", file=sys.stderr)
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()