"""
Port scanner module for xl_network package
"""

import socket
import threading
from queue import Queue
import time
import argparse
import sys


def port_scan(host, port, timeout=1):
    """扫描单个端口"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        result = sock.connect_ex((host, port))
        if result == 0:
            return port
    except socket.gaierror:
        print("主机名无法解析")
    except socket.error:
        pass
    finally:
        sock.close()
    return None


def worker(host, queue, open_ports, verbose=False):
    """线程工作函数"""
    while not queue.empty():
        port = queue.get()
        if port_scan(host, port):
            open_ports.append(port)
            if verbose:
                print(f"发现开放端口: {port}")
        queue.task_done()


def scan_ports(host, start_port, end_port, num_threads=100, verbose=False):
    """扫描指定端口范围"""
    print(f"正在扫描 {host} 的端口 {start_port} 到 {end_port}...")
    if verbose:
        print(f"使用 {num_threads} 个线程进行扫描")

    start_time = time.time()

    # 创建端口队列
    queue = Queue()
    for port in range(start_port, end_port + 1):
        queue.put(port)

    # 存储开放端口
    open_ports = []

    # 创建并启动线程
    threads = []
    for _ in range(num_threads):
        t = threading.Thread(target=worker, args=(host, queue, open_ports, verbose))
        t.daemon = True
        t.start()
        threads.append(t)

    # 等待所有线程完成
    queue.join()

    # 输出结果
    if open_ports:
        print(f"\n发现以下开放端口：{sorted(open_ports)}")
        print(f"共发现 {len(open_ports)} 个开放端口")
    else:
        print("\n未发现开放端口")

    print(f"扫描耗时：{time.time() - start_time:.2f} 秒")
    return sorted(open_ports)


def main():
    """CLI主函数"""
    parser = argparse.ArgumentParser(
        description="端口扫描工具 - xl-network scan",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  xl-network scan 127.0.0.1 1 1024
  xl-network scan localhost 80 443 --threads 50 --verbose
  xl-network scan example.com 1 65535 --timeout 2
        """
    )

    parser.add_argument('host', help='目标主机（IP地址或域名）')
    parser.add_argument('start_port', type=int, help='起始端口号（1-65535）')
    parser.add_argument('end_port', type=int, help='结束端口号（1-65535）')
    parser.add_argument('--threads', '-t', type=int, default=100,
                       help='线程数量（默认：100）')
    parser.add_argument('--timeout', type=float, default=1.0,
                       help='连接超时时间，秒（默认：1.0）')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='显示详细信息')

    args = parser.parse_args()

    # 验证输入
    if args.start_port < 1 or args.end_port > 65535 or args.start_port > args.end_port:
        print("错误：端口范围无效！端口应在 1-65535 之间，且起始端口小于等于结束端口。", file=sys.stderr)
        sys.exit(1)

    if args.threads < 1 or args.threads > 1000:
        print("错误：线程数量应在 1-1000 之间。", file=sys.stderr)
        sys.exit(1)

    if args.timeout <= 0 or args.timeout > 10:
        print("错误：超时时间应在 0-10 秒之间。", file=sys.stderr)
        sys.exit(1)

    # 执行扫描
    try:
        scan_ports(
            host=args.host,
            start_port=args.start_port,
            end_port=args.end_port,
            num_threads=args.threads,
            verbose=args.verbose
        )
    except KeyboardInterrupt:
        print("\n\n扫描被用户中断。")
        sys.exit(0)
    except Exception as e:
        print(f"\n错误：{e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()