"""
Entry point for xl-network CLI
"""

from .port_scanner import main

if __name__ == "__main__":
    main()