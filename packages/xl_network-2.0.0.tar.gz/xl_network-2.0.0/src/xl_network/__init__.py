"""
xl_network - Network utilities package
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from .port_scanner import scan_ports, port_scan

__all__ = ["scan_ports", "port_scan"]