@echo off
echo 正在安装 xl-network 包...
cd /d "D:\git\libs\py-network"
pip install -e .
echo.
echo 安装完成！
echo 现在可以使用以下命令：
echo   xl-network scan --help
echo   xl-network scan 127.0.0.1 1 1024
pause