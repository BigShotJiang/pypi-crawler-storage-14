"""
Setup script for xl-network package
"""

from setuptools import setup, find_packages

setup(
    name="xl-network",
    use_scm_version=True,
    setup_requires=['setuptools_scm'],
    python_requires=">=3.7",
)