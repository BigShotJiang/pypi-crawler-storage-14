import logging

logger = logging.Logger("eql")
logger.setLevel(logging.INFO)
