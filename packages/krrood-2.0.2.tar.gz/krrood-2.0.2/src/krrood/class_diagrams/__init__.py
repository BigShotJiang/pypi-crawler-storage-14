from .class_diagram import ClassDiagram, ClassRelation
