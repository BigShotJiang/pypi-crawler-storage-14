import{l as o,c as r}from"../chunks/D2__QV4S.js";export{o as load_css,r as start};
