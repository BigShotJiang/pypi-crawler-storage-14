KAFKA_BOOTSTRAP = "localhost:9092"
TEST_TIMEOUT = 30.0  # seconds
