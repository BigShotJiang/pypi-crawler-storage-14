name = 'sseclient-py'
version = '1.8.0'
