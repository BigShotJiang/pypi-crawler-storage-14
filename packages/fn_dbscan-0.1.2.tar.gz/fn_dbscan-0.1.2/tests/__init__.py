"""Test suite for fn-dbscan package."""
