"""FastAPI main application."""

import logging
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from agenticlypay.config import config
from agenticlypay.api.routes import (
    connect,
    payments,
    payouts,
    tax,
    webhooks,
    console,
)
from agenticlypay.api.middleware.usage import usage_middleware
from agenticlypay.api.middleware.request_id import RequestIDMiddleware
from agenticlypay.api.exceptions import AgenticlyPayAPIError

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Rate limiter
limiter = Limiter(key_func=get_remote_address)

app = FastAPI(
    title="AgenticlyPay API",
    description="API for processing agentic payments (ACP, AP2, x402) via Stripe",
    version="0.8.0",
)

# Add rate limiter to app state
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Add request ID middleware for tracing
app.add_middleware(RequestIDMiddleware)

# CORS configuration - explicitly list allowed origins (no wildcard for security)
allowed_origins = [config.frontend_url]
# Add common development origins if in development mode
if config.frontend_url.startswith("http://localhost"):
    allowed_origins.extend([
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ])

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Usage logging middleware (non-intrusive)
app.middleware("http")(usage_middleware)

# Global exception handler for custom exceptions
@app.exception_handler(AgenticlyPayAPIError)
async def agenticlypay_exception_handler(request: Request, exc: AgenticlyPayAPIError):
    """Handle custom API exceptions."""
    request_id = getattr(request.state, "request_id", "unknown")
    logger.error(
        f"API Error [{request_id}]: {exc.error_code} - {exc.message}",
        extra={"request_id": request_id, "error_code": exc.error_code, "details": exc.details}
    )
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.to_dict()
    )

# Global exception handler for unhandled exceptions
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle unhandled exceptions - don't expose internal errors."""
    request_id = getattr(request.state, "request_id", "unknown")
    logger.exception(
        f"Unhandled exception [{request_id}]: {type(exc).__name__}",
        extra={"request_id": request_id, "exception_type": type(exc).__name__}
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An internal error occurred. Please try again later.",
                "details": {}
            }
        }
    )

# Include routers
app.include_router(connect.router, prefix="/api/v1/connect", tags=["Connect"])
app.include_router(payments.router, prefix="/api/v1/payments", tags=["Payments"])
app.include_router(payouts.router, prefix="/api/v1/payouts", tags=["Payouts"])
app.include_router(tax.router, prefix="/api/v1/tax", tags=["Tax"])
app.include_router(webhooks.router, prefix="/api/v1/webhooks", tags=["Webhooks"])
app.include_router(console.router, prefix="/api/v1/console", tags=["Console"])

# Square webhook endpoint at /api/v1/square (separate from webhooks router)
from agenticlypay.api.routes.webhooks import square_webhook
app.post("/api/v1/square", tags=["Webhooks"])(square_webhook)


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "AgenticlyPay API",
        "version": "0.8.0",
        "status": "running",
    }


@app.get("/health")
async def health():
    """Health check endpoint with dependency verification."""
    health_status = {"status": "healthy", "checks": {}}
    
    # Check Firestore connection (non-blocking - log warning but don't fail)
    try:
        from agenticlypay.utils.firestore_storage import db
        # Simple connectivity check with timeout
        db.collection("_health_check").limit(1).get()
        health_status["checks"]["firestore"] = "connected"
    except Exception as e:
        logger.warning(f"Firestore health check failed: {str(e)}")
        health_status["checks"]["firestore"] = "degraded"
        # Don't mark overall status as degraded for Firestore issues
        # Firestore is used for logging/analytics, not critical for payments
    
    # Check Stripe configuration
    if config.stripe_secret_key:
        health_status["checks"]["stripe"] = "configured"
    else:
        health_status["checks"]["stripe"] = "not configured"
        health_status["status"] = "degraded"
    
    # Check Square configuration (optional for payouts)
    if config.square_access_token:
        health_status["checks"]["square"] = "configured"
    else:
        health_status["checks"]["square"] = "not configured"
        # Square is optional, don't degrade status
    
    status_code = 200 if health_status["status"] == "healthy" else 503
    return JSONResponse(content=health_status, status_code=status_code)

