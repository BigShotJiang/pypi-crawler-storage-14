"""Tests for custom exception classes."""

import pytest
from agenticlypay.api.exceptions import (
    AgenticlyPayAPIError,
    ValidationError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    PaymentError,
    ConfigurationError,
)


class TestExceptionClasses:
    """Tests for custom exception classes."""

    def test_base_exception(self):
        """Test base exception class."""
        exc = AgenticlyPayAPIError("Test error", status_code=400, error_code="TEST_ERROR")
        assert exc.message == "Test error"
        assert exc.status_code == 400
        assert exc.error_code == "TEST_ERROR"
        
        error_dict = exc.to_dict()
        assert "error" in error_dict
        assert error_dict["error"]["code"] == "TEST_ERROR"
        assert error_dict["error"]["message"] == "Test error"

    def test_validation_error(self):
        """Test validation error."""
        exc = ValidationError("Invalid input", details={"field": "amount"})
        assert exc.status_code == 400
        assert exc.error_code == "VALIDATION_ERROR"
        assert "amount" in exc.details.get("field", "")

    def test_authentication_error(self):
        """Test authentication error."""
        exc = AuthenticationError()
        assert exc.status_code == 401
        assert exc.error_code == "AUTHENTICATION_ERROR"
        assert "required" in exc.message.lower()

    def test_authorization_error(self):
        """Test authorization error."""
        exc = AuthorizationError()
        assert exc.status_code == 403
        assert exc.error_code == "AUTHORIZATION_ERROR"

    def test_not_found_error(self):
        """Test not found error."""
        exc = NotFoundError("Resource not found")
        assert exc.status_code == 404
        assert exc.error_code == "NOT_FOUND"

    def test_payment_error(self):
        """Test payment error."""
        exc = PaymentError("Payment failed", details={"payment_id": "pi_123"})
        assert exc.status_code == 400
        assert exc.error_code == "PAYMENT_ERROR"

    def test_configuration_error(self):
        """Test configuration error."""
        exc = ConfigurationError("Missing required config")
        assert exc.status_code == 500
        assert exc.error_code == "CONFIGURATION_ERROR"

