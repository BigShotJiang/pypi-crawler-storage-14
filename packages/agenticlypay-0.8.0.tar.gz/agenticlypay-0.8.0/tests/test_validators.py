"""Tests for input validators."""

import pytest
from agenticlypay.api.validators import (
    validate_amount,
    validate_stripe_account_id,
    validate_currency,
)
from agenticlypay.api.exceptions import ValidationError


class TestAmountValidator:
    """Tests for amount validation."""

    def test_valid_amount(self):
        """Test that valid amounts pass validation."""
        assert validate_amount(100) == 100
        assert validate_amount(10000) == 10000
        assert validate_amount(100000000) == 100000000  # Max amount

    def test_negative_amount_fails(self):
        """Test that negative amounts fail validation."""
        with pytest.raises(ValidationError, match="at least"):
            validate_amount(-100)

    def test_zero_amount_fails(self):
        """Test that zero amount fails validation."""
        with pytest.raises(ValidationError, match="at least"):
            validate_amount(0)

    def test_too_large_amount_fails(self):
        """Test that amounts exceeding maximum fail validation."""
        with pytest.raises(ValidationError, match="exceeds maximum"):
            validate_amount(100_000_001)  # Over max


class TestAccountIDValidator:
    """Tests for Stripe account ID validation."""

    def test_valid_account_id(self):
        """Test that valid account IDs pass validation."""
        assert validate_stripe_account_id("acct_1234567890") == "acct_1234567890"
        assert validate_stripe_account_id("acct_abc123XYZ") == "acct_abc123XYZ"

    def test_missing_prefix_fails(self):
        """Test that account IDs without acct_ prefix fail."""
        with pytest.raises(ValidationError, match="Invalid account ID format"):
            validate_stripe_account_id("1234567890")

    def test_empty_account_id_fails(self):
        """Test that empty account ID fails."""
        with pytest.raises(ValidationError, match="required"):
            validate_stripe_account_id("")

    def test_invalid_characters_fail(self):
        """Test that account IDs with invalid characters fail."""
        with pytest.raises(ValidationError, match="Invalid account ID format"):
            validate_stripe_account_id("acct_123-456")  # Hyphen not allowed


class TestCurrencyValidator:
    """Tests for currency validation."""

    def test_valid_currencies(self):
        """Test that valid currencies pass validation."""
        assert validate_currency("usd") == "usd"
        assert validate_currency("USD") == "usd"  # Should lowercase
        assert validate_currency("eur") == "eur"
        assert validate_currency("gbp") == "gbp"

    def test_invalid_currency_fails(self):
        """Test that invalid currencies fail validation."""
        with pytest.raises(ValidationError, match="Unsupported currency"):
            validate_currency("xxx")

    def test_empty_currency_fails(self):
        """Test that empty currency fails."""
        with pytest.raises(ValidationError, match="required"):
            validate_currency("")

