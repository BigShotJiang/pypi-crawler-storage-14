"""Tests for data models."""

import pytest
from agenticlypay.models import DeveloperAccount, Transaction, Payout, TaxForm


class TestDeveloperAccount:
    """Tests for DeveloperAccount model."""

    def test_create_account(self):
        """Test creating a developer account."""
        account = DeveloperAccount(
            account_id="acct_123",
            email="dev@example.com",
            country="US",
            charges_enabled=True,
            payouts_enabled=True,
            details_submitted=True,
            created=1700000000,
        )
        assert account.account_id == "acct_123"
        assert account.email == "dev@example.com"
        assert account.country == "US"
        assert account.charges_enabled is True
        assert account.payouts_enabled is True
        assert account.details_submitted is True

    def test_account_defaults(self):
        """Test account default values."""
        account = DeveloperAccount(
            account_id="acct_456",
            email="test@example.com",
            created=1700000000,
        )
        assert account.country == "US"
        assert account.charges_enabled is False
        assert account.payouts_enabled is False
        assert account.details_submitted is False
        assert account.metadata == {}


class TestTransaction:
    """Tests for Transaction model."""

    def test_create_transaction(self):
        """Test creating a transaction."""
        transaction = Transaction(
            transaction_id="txn_123",
            payment_intent_id="pi_456",
            developer_account_id="acct_789",
            protocol="ACP",
            amount=10000,
            currency="usd",
            fee=680,
            net_amount=9320,
            status="succeeded",
            created=1700000000,
        )
        assert transaction.transaction_id == "txn_123"
        assert transaction.payment_intent_id == "pi_456"
        assert transaction.protocol == "ACP"
        assert transaction.amount == 10000
        assert transaction.fee == 680
        assert transaction.net_amount == 9320

    def test_transaction_with_metadata(self):
        """Test transaction with metadata."""
        transaction = Transaction(
            transaction_id="txn_meta",
            payment_intent_id="pi_meta",
            developer_account_id="acct_meta",
            protocol="AP2",
            amount=5000,
            fee=355,
            net_amount=4645,
            status="pending",
            created=1700000000,
            metadata={"mandate_id": "m_123", "agent_id": "agent_456"},
        )
        assert transaction.metadata["mandate_id"] == "m_123"
        assert transaction.metadata["agent_id"] == "agent_456"


class TestPayout:
    """Tests for Payout model."""

    def test_create_payout(self):
        """Test creating a payout."""
        payout = Payout(
            payout_id="po_123",
            transfer_id="tr_456",
            developer_account_id="acct_789",
            year=2024,
            month=11,
            amount=50000,
            currency="usd",
            transaction_count=25,
            created=1700000000,
            status="paid",
        )
        assert payout.payout_id == "po_123"
        assert payout.year == 2024
        assert payout.month == 11
        assert payout.amount == 50000
        assert payout.transaction_count == 25
        assert payout.status == "paid"


class TestTaxForm:
    """Tests for TaxForm model."""

    def test_create_tax_form(self):
        """Test creating a tax form."""
        tax_form = TaxForm(
            developer_account_id="acct_123",
            year=2024,
            amount=100000,
        )
        assert tax_form.developer_account_id == "acct_123"
        assert tax_form.year == 2024
        assert tax_form.amount == 100000
        assert tax_form.form_type == "us_1099_misc"
        assert tax_form.status == "pending"

    def test_tax_form_with_form_id(self):
        """Test tax form with form_id."""
        tax_form = TaxForm(
            form_id="form_456",
            developer_account_id="acct_789",
            year=2023,
            amount=75000,
            status="filed",
            created=1700000000,
        )
        assert tax_form.form_id == "form_456"
        assert tax_form.status == "filed"

