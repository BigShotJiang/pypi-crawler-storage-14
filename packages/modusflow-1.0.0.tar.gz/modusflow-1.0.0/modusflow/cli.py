#!/usr/bin/env python3
"""
ModusFlow CLI - Headless workflow execution and management
"""
import asyncio
import json
import sys
import argparse
from pathlib import Path
from typing import Dict, Any

from modusflow.models import Workflow
from modusflow.executor import executor
from modusflow.ai_generator import WorkflowGenerator


async def run_workflow(workflow_path: str, inputs: Dict[str, Any] = None):
    """Run a workflow from a JSON file"""
    path = Path(workflow_path)
    if not path.exists():
        print(f"Error: Workflow file not found: {workflow_path}", file=sys.stderr)
        sys.exit(1)
    
    with open(path) as f:
        data = json.load(f)
        workflow = Workflow(**data)
    
    print(f"Executing workflow: {workflow.name}")
    print(f"Nodes: {len(workflow.nodes)}, Edges: {len(workflow.edges)}")
    print("-" * 50)
    
    execution = await executor.execute(workflow, inputs or {})
    
    print(f"\nExecution {execution.id}")
    print(f"Status: {execution.status}")
    print(f"Duration: {execution.completed_at and execution.started_at}")
    
    if execution.error:
        print(f"Error: {execution.error}")
    
    print("\nNode Results:")
    for node_id, result in execution.node_results.items():
        status_icon = "✓" if result.status.value == "success" else "✗"
        print(f"  {status_icon} {node_id}: {result.status.value}")
        if result.error:
            print(f"    Error: {result.error}")
        if result.output:
            output_str = json.dumps(result.output)[:100]
            print(f"    Output: {output_str}...")
        if result.cost:
            print(f"    Cost: ${result.cost:.6f} | Tokens: {result.tokens}")
    
    sys.exit(0 if execution.status == "completed" else 1)


async def generate_workflow(prompt: str, output: str, provider: str = "anthropic"):
    """Generate a workflow from a prompt"""
    print(f"Generating workflow from prompt: {prompt}")
    print(f"Provider: {provider}")
    
    generator = WorkflowGenerator()
    workflow = await generator.generate(prompt, provider)
    
    output_path = Path(output)
    with open(output_path, "w") as f:
        json.dump(workflow.dict(), f, indent=2)
    
    print(f"\nWorkflow generated: {output_path}")
    print(f"Name: {workflow.name}")
    print(f"Nodes: {len(workflow.nodes)}")
    print(f"Edges: {len(workflow.edges)}")


def validate_workflow(workflow_path: str):
    """Validate a workflow file"""
    path = Path(workflow_path)
    if not path.exists():
        print(f"Error: Workflow file not found: {workflow_path}", file=sys.stderr)
        sys.exit(1)
    
    try:
        with open(path) as f:
            data = json.load(f)
            workflow = Workflow(**data)
        
        # Basic validation
        node_ids = {node.id for node in workflow.nodes}
        errors = []
        
        for edge in workflow.edges:
            if edge.source not in node_ids:
                errors.append(f"Edge {edge.id}: source node '{edge.source}' not found")
            if edge.target not in node_ids:
                errors.append(f"Edge {edge.id}: target node '{edge.target}' not found")
        
        if errors:
            print("Validation errors:", file=sys.stderr)
            for error in errors:
                print(f"  - {error}", file=sys.stderr)
            sys.exit(1)
        
        print("✓ Workflow is valid")
        print(f"  Name: {workflow.name}")
        print(f"  Nodes: {len(workflow.nodes)}")
        print(f"  Edges: {len(workflow.edges)}")
        
    except Exception as e:
        print(f"Error: Invalid workflow: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="ModusFlow CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run a workflow")
    run_parser.add_argument("workflow", help="Path to workflow JSON file")
    run_parser.add_argument("--input", help="JSON input file or inline JSON string")
    
    # Generate command
    gen_parser = subparsers.add_parser("generate", help="Generate a workflow from a prompt")
    gen_parser.add_argument("prompt", help="Natural language description of the workflow")
    gen_parser.add_argument("-o", "--output", default="workflow.json", help="Output file path")
    gen_parser.add_argument("-p", "--provider", default="anthropic", 
                          choices=["anthropic", "openai", "openrouter"],
                          help="AI provider to use")
    
    # Validate command
    validate_parser = subparsers.add_parser("validate", help="Validate a workflow file")
    validate_parser.add_argument("workflow", help="Path to workflow JSON file")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    if args.command == "run":
        inputs = {}
        if args.input:
            if args.input.startswith("{"):
                inputs = json.loads(args.input)
            else:
                with open(args.input) as f:
                    inputs = json.load(f)
        asyncio.run(run_workflow(args.workflow, inputs))
    
    elif args.command == "generate":
        asyncio.run(generate_workflow(args.prompt, args.output, args.provider))
    
    elif args.command == "validate":
        validate_workflow(args.workflow)


if __name__ == "__main__":
    main()

