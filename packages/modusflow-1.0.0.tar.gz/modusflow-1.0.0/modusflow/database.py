import aiosqlite
import os
from pathlib import Path

# Use user's home directory for data
DB_PATH = Path.home() / ".modusflow" / "modusflow.db"

async def init_db():
    """Initialize SQLite database for execution history"""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS executions (
                id TEXT PRIMARY KEY,
                workflow_id TEXT NOT NULL,
                workflow_name TEXT,
                status TEXT NOT NULL,
                started_at TEXT NOT NULL,
                completed_at TEXT,
                error TEXT,
                node_results TEXT,
                metadata TEXT
            )
        """)
        
        await db.execute("""
            CREATE TABLE IF NOT EXISTS node_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                execution_id TEXT NOT NULL,
                node_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL,
                FOREIGN KEY (execution_id) REFERENCES executions(id)
            )
        """)
        
        await db.commit()

async def get_db():
    """Get database connection"""
    return await aiosqlite.connect(DB_PATH)

