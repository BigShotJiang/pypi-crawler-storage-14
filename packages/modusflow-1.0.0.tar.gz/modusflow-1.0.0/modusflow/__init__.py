"""
ModusFlow - A self-hostable, zero-cost, local-first automation platform
"""
__version__ = "1.0.0"

from modusflow.executor import executor
from modusflow.models import Workflow, Node, Edge, NodeType

__all__ = [
    "executor",
    "Workflow",
    "Node",
    "Edge",
    "NodeType",
    "__version__",
]

