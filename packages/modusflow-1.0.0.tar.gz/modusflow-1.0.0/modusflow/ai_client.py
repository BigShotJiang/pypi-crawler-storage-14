import os
from typing import Optional, Tuple
from anthropic import Anthropic
from openai import AsyncOpenAI
import httpx

class AIClient:
    async def generate(
        self, 
        prompt: str, 
        system_prompt: Optional[str] = None,
        model: Optional[str] = None
    ) -> Tuple[str, float, int]:
        """Generate response, return (text, cost, tokens)"""
        raise NotImplementedError

class AnthropicClient(AIClient):
    def __init__(self):
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")
        self.client = Anthropic(api_key=api_key)
        self.model = "claude-3-haiku-20240307"  # Free-tier friendly
    
    async def generate(
        self, 
        prompt: str, 
        system_prompt: Optional[str] = None,
        model: Optional[str] = None
    ) -> Tuple[str, float, int]:
        model = model or self.model
        
        response = self.client.messages.create(
            model=model,
            max_tokens=4096,
            system=system_prompt or "",
            messages=[{"role": "user", "content": prompt}]
        )
        
        text = response.content[0].text
        tokens = response.usage.input_tokens + response.usage.output_tokens
        
        # Cost estimation (Haiku: $0.25/$1.25 per 1M tokens)
        cost = (response.usage.input_tokens * 0.25 + response.usage.output_tokens * 1.25) / 1_000_000
        
        return text, cost, tokens

class OpenAIClient(AIClient):
    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not set")
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = "gpt-3.5-turbo"  # Free-tier friendly
    
    async def generate(
        self, 
        prompt: str, 
        system_prompt: Optional[str] = None,
        model: Optional[str] = None
    ) -> Tuple[str, float, int]:
        model = model or self.model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        response = await self.client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=4096
        )
        
        text = response.choices[0].message.content
        tokens = response.usage.total_tokens
        
        # Cost estimation (GPT-3.5-turbo: $0.5/$1.5 per 1M tokens)
        cost = (response.usage.prompt_tokens * 0.5 + response.usage.completion_tokens * 1.5) / 1_000_000
        
        return text, cost, tokens

class OpenRouterClient(AIClient):
    def __init__(self):
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError("OPENROUTER_API_KEY not set")
        self.api_key = api_key
        self.base_url = "https://openrouter.ai/api/v1"
        self.model = "anthropic/claude-3-haiku"  # Free-tier friendly
    
    async def generate(
        self, 
        prompt: str, 
        system_prompt: Optional[str] = None,
        model: Optional[str] = None
    ) -> Tuple[str, float, int]:
        model = model or self.model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": model,
                    "messages": messages,
                    "max_tokens": 4096
                },
                timeout=60.0
            )
            response.raise_for_status()
            data = response.json()
        
        text = data["choices"][0]["message"]["content"]
        tokens = data.get("usage", {}).get("total_tokens", 0)
        
        # Rough cost estimation
        cost = tokens * 0.000001  # Conservative estimate
        
        return text, cost, tokens

def get_ai_client(provider: str) -> AIClient:
    """Get AI client for provider"""
    if provider == "anthropic":
        return AnthropicClient()
    elif provider == "openai":
        return OpenAIClient()
    elif provider == "openrouter":
        return OpenRouterClient()
    else:
        raise ValueError(f"Unknown provider: {provider}")

