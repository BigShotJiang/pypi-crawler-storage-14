from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List, Literal
from enum import Enum

class NodeType(str, Enum):
    PYTHON = "python"
    HTTP = "http"
    AI = "ai"
    SHELL = "shell"
    CONDITION = "condition"
    DELAY = "delay"

class NodeStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"

class Node(BaseModel):
    id: str
    type: NodeType
    label: str
    config: Dict[str, Any] = Field(default_factory=dict)
    position: Optional[Dict[str, float]] = None
    on_fail: Optional[str] = None  # Node ID to execute on failure
    retries: int = 0
    retry_delay: float = 1.0  # seconds

class Edge(BaseModel):
    id: str
    source: str
    target: str
    condition: Optional[str] = None  # For conditional edges

class Workflow(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    nodes: List[Node]
    edges: List[Edge]
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ExecutionRequest(BaseModel):
    workflow_id: str
    inputs: Dict[str, Any] = Field(default_factory=dict)

class NodeResult(BaseModel):
    node_id: str
    status: NodeStatus
    output: Optional[Any] = None
    error: Optional[str] = None
    duration: float = 0.0
    cost: Optional[float] = None  # For AI nodes
    tokens: Optional[int] = None  # For AI nodes

class Execution(BaseModel):
    id: str
    workflow_id: str
    workflow_name: str
    status: Literal["running", "completed", "failed", "cancelled"]
    started_at: str
    completed_at: Optional[str] = None
    error: Optional[str] = None
    node_results: Dict[str, NodeResult] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class AIGenerateRequest(BaseModel):
    prompt: str
    provider: Literal["anthropic", "openai", "openrouter"] = "anthropic"
    model: Optional[str] = None

