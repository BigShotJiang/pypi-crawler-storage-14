import json
from typing import Dict, Any
from modusflow.models import Workflow, Node, NodeType, Edge
from modusflow.ai_client import get_ai_client
import uuid

class WorkflowGenerator:
    """Generate workflows from natural language prompts using AI"""
    
    async def generate(self, prompt: str, provider: str = "anthropic", model: str = None) -> Workflow:
        """Generate a workflow from a natural language prompt"""
        
        system_prompt = """You are a workflow generation assistant. Generate a JSON workflow specification from user prompts.

The workflow should have:
- id: unique identifier
- name: descriptive name
- description: what the workflow does
- nodes: array of node objects
- edges: array of edge objects connecting nodes

Node structure:
{
  "id": "unique_id",
  "type": "python|http|ai|shell|delay|condition",
  "label": "Human readable label",
  "config": {
    // Type-specific configuration
    // python: { "code": "python code here" }
    // http: { "url": "...", "method": "GET|POST|...", "headers": {}, "body": {} }
    // ai: { "provider": "anthropic|openai|openrouter", "model": "...", "prompt": "...", "system_prompt": "..." }
    // shell: { "command": "shell command" }
    // delay: { "seconds": 1.0 }
  },
  "position": { "x": 0, "y": 0 },
  "retries": 0,
  "retry_delay": 1.0
}

Edge structure:
{
  "id": "unique_id",
  "source": "source_node_id",
  "target": "target_node_id"
}

Use node outputs in configs with ${node_id} syntax.
Return ONLY valid JSON, no markdown formatting."""

        user_prompt = f"""Generate a workflow for: {prompt}

Make it practical and complete. Include all necessary nodes and connections."""

        client = get_ai_client(provider)
        response, _, _ = await client.generate(
            prompt=user_prompt,
            system_prompt=system_prompt,
            model=model
        )
        
        # Parse JSON response
        try:
            # Remove markdown code blocks if present
            if "```json" in response:
                response = response.split("```json")[1].split("```")[0].strip()
            elif "```" in response:
                response = response.split("```")[1].split("```")[0].strip()
            
            workflow_data = json.loads(response)
            
            # Ensure required fields
            workflow_data.setdefault("id", str(uuid.uuid4()))
            workflow_data.setdefault("name", "Generated Workflow")
            workflow_data.setdefault("nodes", [])
            workflow_data.setdefault("edges", [])
            
            # Convert to Workflow model
            nodes = [Node(**node) for node in workflow_data["nodes"]]
            edges = [Edge(**edge) for edge in workflow_data["edges"]]
            
            return Workflow(
                id=workflow_data["id"],
                name=workflow_data["name"],
                description=workflow_data.get("description"),
                nodes=nodes,
                edges=edges,
                metadata=workflow_data.get("metadata", {})
            )
            
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse AI response as JSON: {e}\nResponse: {response}")

