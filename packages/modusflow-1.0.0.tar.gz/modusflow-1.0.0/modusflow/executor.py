import asyncio
import json
import subprocess
import time
import uuid
from typing import Dict, List, Optional, Any
from datetime import datetime
import aiohttp
import httpx
from modusflow.models import Workflow, Node, NodeResult, NodeStatus, NodeType, Execution
from modusflow.database import get_db
from modusflow.ai_client import get_ai_client

class WorkflowExecutor:
    def __init__(self):
        self.running_executions: Dict[str, Execution] = {}
    
    async def execute(self, workflow: Workflow, inputs: Dict[str, Any] = None) -> Execution:
        """Execute a workflow asynchronously"""
        execution_id = str(uuid.uuid4())
        inputs = inputs or {}
        
        execution = Execution(
            id=execution_id,
            workflow_id=workflow.id,
            workflow_name=workflow.name,
            status="running",
            started_at=datetime.utcnow().isoformat(),
            node_results={}
        )
        
        self.running_executions[execution_id] = execution
        
        try:
            # Build dependency graph
            graph = self._build_graph(workflow)
            
            # Execute nodes in topological order with parallelization
            await self._execute_graph(execution, workflow, graph, inputs)
            
            # Check if any node failed
            has_failures = any(
                r.status == NodeStatus.FAILED 
                for r in execution.node_results.values()
            )
            
            execution.status = "failed" if has_failures else "completed"
            execution.completed_at = datetime.utcnow().isoformat()
            
        except Exception as e:
            execution.status = "failed"
            execution.error = str(e)
            execution.completed_at = datetime.utcnow().isoformat()
        
        # Save to database
        await self._save_execution(execution)
        
        return execution
    
    def _build_graph(self, workflow: Workflow) -> Dict[str, List[str]]:
        """Build adjacency list representation of workflow graph"""
        graph = {node.id: [] for node in workflow.nodes}
        
        for edge in workflow.edges:
            if edge.source in graph:
                graph[edge.source].append(edge.target)
        
        return graph
    
    async def _execute_graph(
        self, 
        execution: Execution, 
        workflow: Workflow, 
        graph: Dict[str, List[str]], 
        inputs: Dict[str, Any]
    ):
        """Execute nodes in topological order with parallelization"""
        nodes_by_id = {node.id: node for node in workflow.nodes}
        in_degree = {node.id: 0 for node in workflow.nodes}
        
        # Calculate in-degrees
        for edge in workflow.edges:
            if edge.target in in_degree:
                in_degree[edge.target] += 1
        
        # Track node outputs
        node_outputs: Dict[str, Any] = {}
        node_outputs.update(inputs)
        
        # Queue of nodes ready to execute
        ready_queue = [node_id for node_id, degree in in_degree.items() if degree == 0]
        
        while ready_queue:
            # Execute all ready nodes in parallel
            tasks = []
            for node_id in ready_queue:
                node = nodes_by_id[node_id]
                task = self._execute_node_with_retries(
                    execution, node, node_outputs, workflow
                )
                tasks.append((node_id, task))
            
            # Wait for all parallel tasks
            results = await asyncio.gather(*[task for _, task in tasks], return_exceptions=True)
            
            # Process results and update ready queue
            next_ready = []
            for (node_id, _), result in zip(tasks, results):
                if isinstance(result, Exception):
                    # Handle exception
                    continue
                
                # Update outputs
                if node_id in execution.node_results:
                    result_obj = execution.node_results[node_id]
                    if result_obj.status == NodeStatus.SUCCESS:
                        node_outputs[node_id] = result_obj.output
                
                # Check if dependent nodes are now ready
                for target in graph.get(node_id, []):
                    in_degree[target] -= 1
                    if in_degree[target] == 0:
                        next_ready.append(target)
            
            ready_queue = next_ready
    
    async def _execute_node_with_retries(
        self,
        execution: Execution,
        node: Node,
        node_outputs: Dict[str, Any],
        workflow: Workflow
    ) -> NodeResult:
        """Execute a node with retry logic"""
        last_error = None
        
        for attempt in range(node.retries + 1):
            if attempt > 0:
                await asyncio.sleep(node.retry_delay * attempt)
                await self._log(execution.id, node.id, "info", f"Retry attempt {attempt}")
            
            result = await self._execute_node(node, node_outputs, execution.id)
            
            if result.status == NodeStatus.SUCCESS:
                execution.node_results[node.id] = result
                return result
            
            last_error = result.error
        
        # All retries failed
        result.status = NodeStatus.FAILED
        result.error = last_error
        execution.node_results[node.id] = result
        
        # Handle on_fail path
        if node.on_fail:
            await self._log(execution.id, node.id, "info", f"Executing on_fail: {node.on_fail}")
            fail_node = next((n for n in workflow.nodes if n.id == node.on_fail), None)
            if fail_node:
                fail_result = await self._execute_node(fail_node, node_outputs, execution.id)
                execution.node_results[node.on_fail] = fail_result
        
        return result
    
    async def _execute_node(
        self, 
        node: Node, 
        node_outputs: Dict[str, Any],
        execution_id: str
    ) -> NodeResult:
        """Execute a single node"""
        start_time = time.time()
        result = NodeResult(node_id=node.id, status=NodeStatus.RUNNING)
        
        await self._log(execution_id, node.id, "info", f"Executing {node.type} node: {node.label}")
        
        try:
            if node.type == NodeType.PYTHON:
                output = await self._execute_python(node, node_outputs, execution_id)
            elif node.type == NodeType.HTTP:
                output = await self._execute_http(node, node_outputs, execution_id)
            elif node.type == NodeType.AI:
                output, cost, tokens = await self._execute_ai(node, node_outputs, execution_id)
                result.cost = cost
                result.tokens = tokens
            elif node.type == NodeType.SHELL:
                output = await self._execute_shell(node, node_outputs, execution_id)
            elif node.type == NodeType.DELAY:
                output = await self._execute_delay(node, node_outputs)
            else:
                raise ValueError(f"Unknown node type: {node.type}")
            
            result.status = NodeStatus.SUCCESS
            result.output = output
            
        except Exception as e:
            result.status = NodeStatus.FAILED
            result.error = str(e)
            await self._log(execution_id, node.id, "error", f"Error: {str(e)}")
        
        result.duration = time.time() - start_time
        return result
    
    async def _execute_python(
        self, 
        node: Node, 
        node_outputs: Dict[str, Any],
        execution_id: str
    ) -> Any:
        """Execute Python code"""
        code = node.config.get("code", "")
        
        # Replace placeholders with node outputs
        for node_id, output in node_outputs.items():
            code = code.replace(f"${{{node_id}}}", json.dumps(output))
            code = code.replace(f"${{outputs.{node_id}}}", json.dumps(output))
        
        # Create execution context
        context = {
            "outputs": node_outputs,
            "json": json,
            "__name__": "__main__"
        }
        
        await self._log(execution_id, node.id, "info", f"Running Python code: {code[:100]}...")
        
        # Execute in subprocess for safety
        # Code should print JSON to stdout for structured output
        proc = await asyncio.create_subprocess_exec(
            "python", "-c", code,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await proc.communicate()
        
        if proc.returncode != 0:
            error_msg = stderr.decode() or stdout.decode()
            raise Exception(f"Python execution failed: {error_msg}")
        
        output = stdout.decode().strip()
        
        if not output:
            return None
        
        # Try to parse as JSON, otherwise return as string
        try:
            return json.loads(output)
        except json.JSONDecodeError:
            # If not JSON, return as string
            return output
    
    async def _execute_http(
        self, 
        node: Node, 
        node_outputs: Dict[str, Any],
        execution_id: str
    ) -> Any:
        """Execute HTTP request"""
        url = node.config.get("url", "")
        method = node.config.get("method", "GET").upper()
        headers = node.config.get("headers", {})
        body = node.config.get("body")
        
        # Replace placeholders
        url = self._replace_placeholders(url, node_outputs)
        if body:
            if isinstance(body, str):
                body = self._replace_placeholders(body, node_outputs)
            else:
                body = json.dumps(body)
                body = self._replace_placeholders(body, node_outputs)
                body = json.loads(body)
        
        await self._log(execution_id, node.id, "info", f"{method} {url}")
        
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=method,
                url=url,
                headers=headers,
                json=body if method in ["POST", "PUT", "PATCH"] else None,
                timeout=30.0
            )
            
            response.raise_for_status()
            
            # Try to parse JSON, otherwise return text
            try:
                return response.json()
            except:
                return response.text
    
    async def _execute_ai(
        self, 
        node: Node, 
        node_outputs: Dict[str, Any],
        execution_id: str
    ) -> tuple[Any, float, int]:
        """Execute AI model call"""
        provider = node.config.get("provider", "anthropic")
        model = node.config.get("model")
        prompt = node.config.get("prompt", "")
        system_prompt = node.config.get("system_prompt")
        
        # Replace placeholders
        prompt = self._replace_placeholders(prompt, node_outputs)
        if system_prompt:
            system_prompt = self._replace_placeholders(system_prompt, node_outputs)
        
        await self._log(execution_id, node.id, "info", f"Calling {provider} model: {model}")
        
        client = get_ai_client(provider)
        response, cost, tokens = await client.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            model=model
        )
        
        return response, cost, tokens
    
    async def _execute_shell(
        self, 
        node: Node, 
        node_outputs: Dict[str, Any],
        execution_id: str
    ) -> str:
        """Execute shell command"""
        command = node.config.get("command", "")
        
        # Replace placeholders
        command = self._replace_placeholders(command, node_outputs)
        
        await self._log(execution_id, node.id, "info", f"Running: {command}")
        
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await proc.communicate()
        
        if proc.returncode != 0:
            raise Exception(f"Command failed: {stderr.decode()}")
        
        return stdout.decode()
    
    async def _execute_delay(
        self, 
        node: Node, 
        node_outputs: Dict[str, Any]
    ) -> None:
        """Execute delay node"""
        seconds = node.config.get("seconds", 1.0)
        await asyncio.sleep(seconds)
        return {"delayed": seconds}
    
    def _replace_placeholders(self, text: str, node_outputs: Dict[str, Any]) -> str:
        """Replace ${node_id} placeholders with actual outputs"""
        import re
        pattern = r'\$\{([^}]+)\}'
        
        def replace(match):
            key = match.group(1)
            if key in node_outputs:
                value = node_outputs[key]
                # If value is a string, return it directly (for URLs, prompts, etc.)
                # If it's a complex type, JSON stringify it
                if isinstance(value, str):
                    return value
                else:
                    return json.dumps(value)
            return match.group(0)
        
        return re.sub(pattern, replace, text)
    
    async def _log(self, execution_id: str, node_id: str, level: str, message: str):
        """Log a message to database"""
        async with await get_db() as db:
            await db.execute(
                "INSERT INTO node_logs (execution_id, node_id, timestamp, level, message) VALUES (?, ?, ?, ?, ?)",
                (execution_id, node_id, datetime.utcnow().isoformat(), level, message)
            )
            await db.commit()
    
    async def _save_execution(self, execution: Execution):
        """Save execution to database"""
        async with await get_db() as db:
            await db.execute(
                """INSERT OR REPLACE INTO executions 
                   (id, workflow_id, workflow_name, status, started_at, completed_at, error, node_results, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    execution.id,
                    execution.workflow_id,
                    execution.workflow_name,
                    execution.status,
                    execution.started_at,
                    execution.completed_at,
                    execution.error,
                    json.dumps({k: v.dict() for k, v in execution.node_results.items()}),
                    json.dumps(execution.metadata)
                )
            )
            await db.commit()

executor = WorkflowExecutor()

