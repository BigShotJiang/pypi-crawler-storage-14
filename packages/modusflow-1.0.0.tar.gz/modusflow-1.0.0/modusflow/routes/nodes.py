from fastapi import APIRouter
from modusflow.models import NodeType
from typing import Dict, Any

router = APIRouter()

@router.get("/types")
async def get_node_types():
    """Get available node types and their schemas"""
    return {
        "python": {
            "name": "Python Script",
            "description": "Execute Python code",
            "config_schema": {
                "code": {"type": "string", "required": True, "description": "Python code to execute"}
            },
            "outputs": "Any Python value (JSON-serializable)"
        },
        "http": {
            "name": "HTTP Request",
            "description": "Make HTTP request",
            "config_schema": {
                "url": {"type": "string", "required": True},
                "method": {"type": "string", "default": "GET", "options": ["GET", "POST", "PUT", "DELETE", "PATCH"]},
                "headers": {"type": "object", "default": {}},
                "body": {"type": "any", "default": None}
            },
            "outputs": "Response body (JSON or text)"
        },
        "ai": {
            "name": "AI Model",
            "description": "Call AI model (Claude, GPT, etc.)",
            "config_schema": {
                "provider": {"type": "string", "default": "anthropic", "options": ["anthropic", "openai", "openrouter"]},
                "model": {"type": "string", "default": None},
                "prompt": {"type": "string", "required": True},
                "system_prompt": {"type": "string", "default": None}
            },
            "outputs": "AI response text"
        },
        "shell": {
            "name": "Shell Command",
            "description": "Execute shell command",
            "config_schema": {
                "command": {"type": "string", "required": True}
            },
            "outputs": "Command stdout"
        },
        "delay": {
            "name": "Delay",
            "description": "Wait for specified seconds",
            "config_schema": {
                "seconds": {"type": "number", "default": 1.0}
            },
            "outputs": "Delay confirmation"
        },
        "condition": {
            "name": "Condition",
            "description": "Conditional branching (future)",
            "config_schema": {},
            "outputs": "Boolean result"
        }
    }

@router.get("/templates")
async def get_templates():
    """Get workflow templates"""
    return {
        "web_scraper": {
            "name": "Web Scraper",
            "description": "Scrape a website and extract data",
            "nodes": [
                {"type": "http", "label": "Fetch Page"},
                {"type": "python", "label": "Parse HTML"},
                {"type": "ai", "label": "Extract Data"}
            ]
        },
        "ai_summarizer": {
            "name": "AI Summarizer",
            "description": "Summarize text with AI",
            "nodes": [
                {"type": "http", "label": "Fetch Content"},
                {"type": "ai", "label": "Summarize"},
                {"type": "python", "label": "Save Result"}
            ]
        },
        "alert_workflow": {
            "name": "Alert Workflow",
            "description": "Monitor and alert on conditions",
            "nodes": [
                {"type": "http", "label": "Check Status"},
                {"type": "condition", "label": "Check Condition"},
                {"type": "http", "label": "Send Alert"}
            ]
        }
    }

