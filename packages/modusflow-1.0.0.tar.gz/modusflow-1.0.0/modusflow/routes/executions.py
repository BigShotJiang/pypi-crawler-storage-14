from fastapi import APIRouter, HTTPException
from typing import List, Optional
import json
from modusflow.database import get_db
from modusflow.models import Execution, NodeResult

router = APIRouter()

@router.get("", response_model=List[Execution])
async def list_executions(limit: int = 50):
    """List recent executions"""
    async with await get_db() as db:
        async with db.execute(
            "SELECT * FROM executions ORDER BY started_at DESC LIMIT ?",
            (limit,)
        ) as cursor:
            rows = await cursor.fetchall()
    
    executions = []
    for row in rows:
        executions.append(Execution(
            id=row[0],
            workflow_id=row[1],
            workflow_name=row[2],
            status=row[3],
            started_at=row[4],
            completed_at=row[5],
            error=row[6],
            node_results={
                k: NodeResult(**v) 
                for k, v in json.loads(row[7] or "{}").items()
            },
            metadata=json.loads(row[8] or "{}")
        ))
    
    return executions

@router.get("/{execution_id}", response_model=Execution)
async def get_execution(execution_id: str):
    """Get a specific execution"""
    async with await get_db() as db:
        async with db.execute(
            "SELECT * FROM executions WHERE id = ?",
            (execution_id,)
        ) as cursor:
            row = await cursor.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail="Execution not found")
    
    return Execution(
        id=row[0],
        workflow_id=row[1],
        workflow_name=row[2],
        status=row[3],
        started_at=row[4],
        completed_at=row[5],
        error=row[6],
        node_results={
            k: NodeResult(**v) 
            for k, v in json.loads(row[7] or "{}").items()
        },
        metadata=json.loads(row[8] or "{}")
    )

@router.get("/{execution_id}/logs")
async def get_execution_logs(execution_id: str):
    """Get logs for an execution"""
    async with await get_db() as db:
        async with db.execute(
            """SELECT node_id, timestamp, level, message 
               FROM node_logs 
               WHERE execution_id = ? 
               ORDER BY timestamp""",
            (execution_id,)
        ) as cursor:
            rows = await cursor.fetchall()
    
    return [
        {
            "node_id": row[0],
            "timestamp": row[1],
            "level": row[2],
            "message": row[3]
        }
        for row in rows
    ]

