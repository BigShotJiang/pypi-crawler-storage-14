from fastapi import APIRouter, HTTPException
from typing import List
import json
import yaml
from pathlib import Path
from modusflow.models import Workflow, ExecutionRequest
from modusflow.executor import executor

router = APIRouter()

# Use user's home directory for workflows
WORKFLOWS_DIR = Path.home() / ".modusflow" / "workflows"
WORKFLOWS_DIR.mkdir(parents=True, exist_ok=True)

def _get_workflow_path(workflow_id: str) -> Path:
    return WORKFLOWS_DIR / f"{workflow_id}.json"

@router.get("", response_model=List[Workflow])
async def list_workflows():
    """List all workflows"""
    workflows = []
    for path in WORKFLOWS_DIR.glob("*.json"):
        try:
            with open(path) as f:
                data = json.load(f)
                workflows.append(Workflow(**data))
        except Exception as e:
            continue
    return workflows

@router.get("/{workflow_id}", response_model=Workflow)
async def get_workflow(workflow_id: str):
    """Get a specific workflow"""
    path = _get_workflow_path(workflow_id)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    with open(path) as f:
        data = json.load(f)
        return Workflow(**data)

@router.post("", response_model=Workflow)
async def create_workflow(workflow: Workflow):
    """Create or update a workflow"""
    path = _get_workflow_path(workflow.id)
    with open(path, "w") as f:
        json.dump(workflow.dict(), f, indent=2)
    return workflow

@router.put("/{workflow_id}", response_model=Workflow)
async def update_workflow(workflow_id: str, workflow: Workflow):
    """Update a workflow"""
    if workflow.id != workflow_id:
        raise HTTPException(status_code=400, detail="Workflow ID mismatch")
    
    path = _get_workflow_path(workflow_id)
    with open(path, "w") as f:
        json.dump(workflow.dict(), f, indent=2)
    return workflow

@router.delete("/{workflow_id}")
async def delete_workflow(workflow_id: str):
    """Delete a workflow"""
    path = _get_workflow_path(workflow_id)
    if path.exists():
        path.unlink()
    return {"status": "deleted"}

@router.post("/{workflow_id}/execute")
async def execute_workflow(workflow_id: str, request: ExecutionRequest):
    """Execute a workflow"""
    workflow = await get_workflow(workflow_id)
    execution = await executor.execute(workflow, request.inputs)
    return execution

@router.post("/{workflow_id}/export")
async def export_workflow(workflow_id: str, format: str = "json"):
    """Export workflow as JSON or YAML"""
    workflow = await get_workflow(workflow_id)
    
    if format == "yaml":
        return yaml.dump(workflow.dict(), default_flow_style=False)
    else:
        return workflow.dict()

