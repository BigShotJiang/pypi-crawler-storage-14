from fastapi import APIRouter, HTTPException
from modusflow.models import AIGenerateRequest, Workflow
from modusflow.ai_generator import WorkflowGenerator

router = APIRouter()
generator = WorkflowGenerator()

@router.post("/generate", response_model=Workflow)
async def generate_workflow(request: AIGenerateRequest):
    """Generate a workflow from a natural language prompt"""
    try:
        workflow = await generator.generate(
            prompt=request.prompt,
            provider=request.provider,
            model=request.model
        )
        return workflow
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/estimate")
async def estimate_cost(prompt: str, provider: str = "anthropic"):
    """Estimate token usage and cost for a workflow generation"""
    # Rough estimation based on prompt length
    estimated_tokens = len(prompt.split()) * 1.3  # Rough token estimate
    
    # Cost per 1M tokens (varies by provider)
    cost_per_million = {
        "anthropic": 0.25,  # Haiku input
        "openai": 0.5,      # GPT-3.5-turbo
        "openrouter": 1.0   # Conservative estimate
    }
    
    cost = (estimated_tokens / 1_000_000) * cost_per_million.get(provider, 1.0)
    
    return {
        "estimated_tokens": int(estimated_tokens),
        "estimated_cost": round(cost, 6),
        "provider": provider
    }

