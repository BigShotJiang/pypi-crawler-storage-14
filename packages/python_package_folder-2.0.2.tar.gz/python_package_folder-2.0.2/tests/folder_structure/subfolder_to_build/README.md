# Example subfolder 

Example subfolder built and published with https://github.com/alelom/python-package-folder.