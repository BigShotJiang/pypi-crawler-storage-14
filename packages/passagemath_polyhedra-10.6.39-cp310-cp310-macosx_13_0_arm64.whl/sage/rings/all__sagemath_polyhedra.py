# sage_setup: distribution = sagemath-polyhedra

from sage.rings.polynomial.all__sagemath_polyhedra import *
