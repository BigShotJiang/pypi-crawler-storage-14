# DPPS SimPipe: Integration and Release

The **CTAO DPPS Simulation Production Pipeline (SimPipe)** provides the software, workflows, and data models for generating accurate Monte Carlo simulations of the CTAO observatory.

## Installation

The following installation procedures are implemented in the gitlab CI/CD pipeline:

- simtools is installed using pip
- CORSIKA is installed using a tar-file (currently downloaded from a cloud storage)
- sim_telarray is installed using a tar-file (currently downloaded from a cloud storage); planned to be installed from gitlab
- simulation model databases - no installed required; configuration of secrets for access

Download of corsika / sim_telarray is facilitated by a private upload to the DESY Sync&Share.
Ask the maintainers to provide the token to you and define it in a `.env` file in this repository:

```console
SOFTWARE_DOWNLOAD_SECRET=<the token received from the maintainers>
```

Then run `make build-dev-docker` to build the simpipe container locally.

## Preparing a new release

Open a new branch from `main` for a release candidate.
Use the `update_simpipe.py` script to update the versions of the software components and the docker base image. This requires to define:

- simtools version (see [simtools releases](https://github.com/gammasim/simtools/releases))
- simulation-models version (see [simulation-models releases](https://gitlab.cta-observatory.org/cta-science/simulations/simulation-model/simulation-models/-/releases))
- dpps-aiv-toolkit version (see [dpps-aiv-toolkit releases](https://gitlab.cta-observatory.org/cta-computing/dpps/aiv/dpps-aiv-toolkit/-/releases))

 Example:

```console
python ./update_simpipe.py --simtools v0.21.0 --simulation-models v0.10.0 --dpps-aiv-submodule v3.0.0
```

After this open a merge request, get it reviewed and merge it into `main`.
Create a new release through the Gitlab interface.

## Developer Notes

- a local simulation models database is used for testing. Uploading details are defined in [chart/templates/bootstrapSimulationModel.yaml](chart/templates/bootstrapSimulationModel.yaml)
