simpipe v0.3.0 (2025-11-19)
---------------------------

New Features
~~~~~~~~~~~~

Updated to simtools v0.25.0.
Updated DB init scripts for integration tests.
Docker pulls from simtools GitHub registry instead of building from source.
Updated DB APIs and simtools calls to work with simtools v0.25.0.
Add script to simplify SimPipe updates with a single command.
[`!37 <https://gitlab.cta-observatory.org/cta-computing/dpps/simpipe/simpipe/-/merge_requests/37>`__]


simpipe v0.2.0 (2025-06-26)
---------------------------

Documentation
~~~~~~~~~~~~~

- First version of SimPipe documentation. [`!30 <https://gitlab.cta-observatory.org/cta-computing/dpps/simpipe/simpipe/-/merge_requests/30>`__]

simpipe 0.1.0 (2025-05-08)
--------------------------


Bugfixes
~~~~~~~~

- Update sim_telarray package to "20240927" (includes correct version of the testeff tool). [`!25 <https://gitlab.cta-observatory.org/cta-computing/dpps/simpipe/simpipe/-/merge_requests/25>`__]


simpipe v0.1.0-rc1 (2025-04-29)
-------------------------------


New Features
~~~~~~~~~~~~

- Initial setup of project environment. [`!1 <https://gitlab.cta-observatory.org/cta-computing/dpps/simpipe/simpipe/-/merge_requests/1>`__]
