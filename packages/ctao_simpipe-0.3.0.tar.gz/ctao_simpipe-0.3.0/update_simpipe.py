#!/usr/bin/env python3
r"""
SimPipe Version Update Automation Script.

This script automates version updates for the three core SimPipe components:
simtools, simulation-models, and dpps-aiv-toolkit submodule.

It updates version references across multiple configuration files and manages
git submodules automatically with proper commit handling.

Usage:
    python update_versions.py --simtools v0.21.0 --simulation-models v0.10.0 \\
                               --dpps-aiv-submodule v3.0.0

What it updates:
    - simtools: Dockerfile, chart/values.yaml
    - simulation-models: chart/values.yaml
    - dpps-aiv-toolkit: git submodule update and commit
    - simtools: git submodule update and commit
"""

import argparse
import re
import subprocess
import sys
from pathlib import Path


class VersionUpdater:
    """Handles version updates across SimPipe configuration files."""

    def __init__(self, repo_root: Path | None):
        """Initialize with repository root path."""
        self.repo_root = repo_root or Path(__file__).parent
        self.updated_files: list[str] = []

    def update_simtools_version(self, version: str) -> None:
        """Update simtools version in Dockerfile."""
        # Remove v prefix if present
        if version.startswith('v'):
            version = version[1:]

        files_to_update = [
            {
                'path': self.repo_root / 'Dockerfile',
                'pattern': r'ARG SIMTOOLS_VERSION="v?[\d\.]+"',
                'replacement': f'ARG SIMTOOLS_VERSION="{version}"'
            },
            {
                'path': self.repo_root / 'chart/values.yaml',
                'pattern': r'simtools_version:\s*"v?[\d\.]+"',
                'replacement': f'simtools_version: "{version}"'
            },
            {
                'path': self.repo_root / "aiv-config.yml",
                'pattern': r'SONAR_BRANCH:\s*refs/tags/v[\d\.]+',
                'replacement': f'SONAR_BRANCH: refs/tags/v{version}'
            },
        ]

        for file_info in files_to_update:
            self._update_file(file_info['path'], file_info['pattern'], file_info['replacement'])

    def update_simulation_models_version(self, version: str) -> None:
        """Update SimulationModels version in chart/values.yaml."""
        if not version.startswith('v'):
            version = f"v{version}"

        file_path = self.repo_root / 'chart/values.yaml'
        pattern = r'revision:\s*"v[\d\.]+"'
        replacement = f'revision: "{version}"'

        self._update_file(file_path, pattern, replacement)

    def update_submodule(self, submodule_name: str, branch_or_commit: str) -> None:
        """Update a git submodule to a specific branch or commit."""
        submodule_path = self.repo_root / submodule_name

        if not submodule_path.exists():
            print(f"✗ Submodule directory not found: {submodule_name}")
            return

        if not (submodule_path / '.git').exists():
            print(f"✗ {submodule_name} is not a git repository")
            return

        try:
            # Change to submodule directory and checkout the specified branch/commit
            print(f"Updating {submodule_name} to {branch_or_commit}...")

            # Fetch latest changes
            result = subprocess.run(
                ['git', 'fetch', 'origin'],
                cwd=submodule_path,
                capture_output=True,
                text=True,
                check=True
            )

            # Checkout the specified branch or commit
            result = subprocess.run(
                ['git', 'checkout', branch_or_commit],
                cwd=submodule_path,
                capture_output=True,
                text=True,
                check=True
            )

            # Get the current commit hash for the commit message
            result = subprocess.run(
                ['git', 'rev-parse', 'HEAD'],
                cwd=submodule_path,
                capture_output=True,
                text=True,
                check=True
            )
            commit_hash = result.stdout.strip()[:8]

            # Change back to repo root and stage the submodule
            subprocess.run(
                ['git', 'add', submodule_name],
                cwd=self.repo_root,
                check=True
            )

            # Create commit message
            commit_msg = f"Update {submodule_name} submodule to {branch_or_commit} ({commit_hash})"

            # Check if there are changes to commit
            result = subprocess.run(
                ['git', 'diff', '--cached', '--quiet'],
                cwd=self.repo_root,
                capture_output=True
            )

            if result.returncode != 0:  # There are staged changes
                # Skip pre-commit hooks for submodule updates to avoid conflicts
                # with the automation script itself
                subprocess.run(
                    ['git', 'commit', '--no-verify', '-m', commit_msg],
                    cwd=self.repo_root,
                    check=True
                )

                # Force update submodules recursively after commit
                print(f"Running git submodule update for {submodule_name}...")
                subprocess.run(
                    ['git', 'submodule', 'update', '--init', '--recursive', '--force'],
                    cwd=self.repo_root,
                    check=True
                )

                print(f"✓ Updated and committed {submodule_name} submodule")
                self.updated_files.append(f"{submodule_name} (submodule)")
            else:
                print(f"⚠ No changes in {submodule_name} submodule")

        except subprocess.CalledProcessError as e:
            print(f"✗ Failed to update {submodule_name} submodule: {e}")
        except Exception as e:
            print(f"✗ Error updating {submodule_name} submodule: {e}")

    def _update_file(self, file_path: Path, pattern: str, replacement: str) -> None:
        """Update a single file with the given pattern and replacement."""
        try:
            content = file_path.read_text(encoding='utf-8')
            updated_content, count = re.subn(pattern, replacement, content)
            relative_path = file_path.relative_to(self.repo_root)

            if count > 0:
                file_path.write_text(updated_content, encoding='utf-8')
                self.updated_files.append(str(relative_path))
                print(f"✓ Updated {relative_path}")
            else:
                print(f"⚠ No matches found in {relative_path} for pattern: {pattern}")

        except FileNotFoundError:
            print(f"✗ File not found: {file_path}")
        except Exception as e:
            print(f"✗ Error updating {file_path}: {e}")


def main():
    """Update SimPipe component versions."""
    parser = argparse.ArgumentParser(description='Update SimPipe component versions')
    parser.add_argument('--simtools', required=True,
                        help='Simtools version (e.g., v0.21.0) - also updates simtools submodule')
    parser.add_argument('--simulation-models', required=True,
                        help='SimulationModels version (e.g., v0.10.0)')
    parser.add_argument('--dpps-aiv-submodule', required=True,
                        help='dpps-aiv-toolkit submodule version (e.g., v3.0.0)')
    parser.add_argument('--repo-root', type=Path,
                        help='Repository root path (default: auto-detect)')

    args = parser.parse_args()
    updater = VersionUpdater(args.repo_root)

    try:
        print("Updating SimPipe component versions...")

        # Update in the specified order
        updater.update_simulation_models_version(args.simulation_models)
        updater.update_submodule('simtools', args.simtools)
        updater.update_simtools_version(args.simtools)
        updater.update_submodule('dpps-aiv-toolkit', args.dpps_aiv_submodule)

        print("\n✓ All updates completed successfully!")

    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
