# simpipe

![Version: 0.1.0-dev](https://img.shields.io/badge/Version-0.1.0--dev-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.1.0-dev](https://img.shields.io/badge/AppVersion-0.1.0--dev-informational?style=flat-square)

A helm chart to deploy the SimPipe service components

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | mongodb | 16.4.5 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| dev.client_image_tag | string | `nil` |  |
| dev.model_version | string | `"6.0.2"` |  |
| dev.mount_repo | bool | `true` |  |
| dev.runAsGroup | int | `1000` |  |
| dev.runAsUser | int | `1000` |  |
| dev.run_tests | bool | `true` |  |
| dev.sleep | bool | `false` |  |
| dev.start_long_running_client | bool | `false` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"harbor.cta-observatory.org/dpps/simpipe-prod"` |  |
| model_db.auth_db | string | `"admin"` |  |
| model_db.model_name | string | `"CTAO-Simulation-Model"` |  |
| model_db.password | string | `"topsecret"` |  |
| model_db.port | int | `27017` |  |
| model_db.server | string | `"simtools-mongodb"` |  |
| model_db.user | string | `"simpipe"` |  |
| mongodb.architecture | string | `"standalone"` |  |
| mongodb.auth.enabled | bool | `true` |  |
| mongodb.auth.rootPassword | string | `"topsecret"` |  |
| mongodb.auth.rootUser | string | `"root"` |  |
| mongodb.enabled | bool | `true` |  |
| mongodb.fullnameOverride | string | `"simtools-mongodb"` |  |
| mongodb.global.security.allowInsecureImages | bool | `true` |  |
| mongodb.image.registry | string | `"harbor.cta-observatory.org"` |  |
| mongodb.image.repository | string | `"proxy_cache/bitnamilegacy/mongodb"` |  |
| mongodb.image.tag | string | `"8.0.5-debian-12-r0"` |  |
| mongodb.initdbScriptsConfigMap | string | `"simpipe-setup-mongodb-user"` |  |
| mongodb.replicaCount | int | `1` |  |
| simulation_model | object | `{"enabled":true,"repository":"https://gitlab.cta-observatory.org/cta-science/simulations/simulation-model/simulation-models.git","revision":"v0.11.0","simtools_version":"0.25.0"}` | Configuration of the simulation model bootstrapping from source |
| simulation_model.repository | string | `"https://gitlab.cta-observatory.org/cta-science/simulations/simulation-model/simulation-models.git"` | Git repository with the model files |
| simulation_model.revision | string | `"v0.11.0"` | Git revision to checkout |
| simulation_model.simtools_version | string | `"0.25.0"` | simtools versions used to upload the simulation model |

