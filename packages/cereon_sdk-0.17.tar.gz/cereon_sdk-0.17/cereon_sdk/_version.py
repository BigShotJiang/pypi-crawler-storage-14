"""Single source of truth for package version."""

__version__ = "0.1.6"
