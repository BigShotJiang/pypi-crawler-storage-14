This library is dsestined to 
become a toolkit for running various
small scale calculations across STEM fields

For now it is just a WIP, stay tuned.