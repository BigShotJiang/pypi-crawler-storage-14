import stemToolkit as stk
from stemToolkit.constants import *
import math
import numpy as np

#stk.add_and_print(1,2)

argonMass = stk.QTT(6.6335209E-26, "kg")
reduced_mass = (argonMass * eM) / (argonMass + eM)
rA = (Ry*(reduced_mass/eM))
print(rA)

def n_star(lamb1, lamb2):
    return pow((2* rA.value)/(lamb2-lamb1),1/3)- 0.5

n1 = n_star(126832.8,126858.5)
n2 = n_star(126858.5,126880.8)

def calc_n1(lamb, n_star):
    return pow(1/((lamb/rA.value)+(1/(n_star**2))),1/2)

print(3-calc_n1(126832.8, n1))
print(3-calc_n1(126858.5, n2))



"""
length = stk.QTT(9, "m")
velocity = stk.QTT(3, "m s^-1")

weight = stk.QTT(1, "kg")
molweight = stk.QTT(0.018, "kg mol^-1")

print(9 / velocity)
charge1 = stk.QTT(2e-6, "A s")
charge2 = stk.QTT(3e-6, "A s")
distance = stk.QTT(0.5, "m")

force = round(((charge1*charge2)/(distance**2))/(e0*4*np.pi),3)
print(force)"""

