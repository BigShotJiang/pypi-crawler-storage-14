import numpy as np
from dataclasses import dataclass

siUnits = {"s":0, "m":1, "kg":2, "mol":3, "K":4, "A":5, "cd":6}
shortUnits = ("s", "m", "K", "kg", "mol", "K", "A", "cd")

def process_unit(unit):
    unitVect = np.zeros(len(siUnits))
    parts = unit.split(" ")

    def check_for_exponent(str):
        if str[0] == "^":
            exponent = ""
            for char in str[1:]:
                if char.isdigit() or char == "-":
                    exponent += char
                else:
                    break

            return float(exponent)

        else:
            return 1

    for i, part in enumerate(parts):
        length = len(part)
        if length == 0:
            return [0,0,0,0,0,0,0]
        if length <= 2:
            try:
                index = siUnits[part]
            except KeyError:
                print("there is an invalid unit")
                return None

            unitVect[index] += 1
            continue

        if length == 3 and "^" in part:
            exponent = int(part[2])
            try:
                index = siUnits[part[0]]
            except KeyError:
                print("there is an invalid unit")
                return None

            unitVect[index] += exponent
            continue

        if part == "mol":
            unitVect[3] += 1
            continue

        expIndex = part.index("^")
        unit = part[:expIndex]
        try:
            index = siUnits[unit]
        except KeyError:
            print("there is an invalid unit")
            return None

        exponent = check_for_exponent(part[expIndex:])
        unitVect[index] += exponent

    return unitVect

def to_string_unit(unitVect):
    unitString = ""
    for i,exp in enumerate(unitVect):
        if exp == 0:
            continue
        if exp == 1:
            unitString += shortUnits[i] + " "
            continue

        unitString += shortUnits[i] + "^"
        unitString += str(int(exp) if exp.is_integer() == True else exp) + " "

    return unitString[:-1]


@dataclass
class QTT:

    def __init__(self, value, unit):
        self.value = value
        self.unit = unit

        self.unitVect = process_unit(self.unit)


    # define string representation
    def __repr__(self):
        return f'{self.value} {self.unit}'


    # enable conversion to integer
    def __int__(self):
        return int(round(self.value))

    # enable conversion to float
    def __float__(self):
        return self.value

    # enable addition
    def __add__(self, other):

        #check if it is also a QTT, and only add if thery are
        #of the same unit
        if isinstance(other, QTT):

            if self.unit != other.unit:
                print("There is a Unit mismatch")
                return None

            return QTT(self.value + other.value, self.unit)

        # if it is just a constant being added
        elif isinstance(other, int) or isinstance(other, float):

            return QTT(self.value + other, self.unit)

        print("Type mismatch")
        return NotImplemented

    # enable reverse addition
    def __radd__(self, other):
        return self.__add__(other)

    # enable subtractions with the same logic as the addition
    def __sub__(self, other):
        if isinstance(other, QTT):

            if self.unit != other.unit:
                print("There is a Unit mismatch")
                return None

            return QTT(self.value - other.value, self.unit)

        elif isinstance(other, int) or isinstance(other, float):

            return QTT(self.value - other, self.unit)

        print("Type mismatch")
        return NotImplemented

    # implement reverse subtraction, since it is not commutative
    def __rsub__(self, other):
        if isinstance(other, QTT):

            if self.unit != other.unit:
                print("There is a Unit mismatch")
                return None

            return QTT(other.value - self.value, self.unit)

        elif isinstance(other, int) or isinstance(other, float):

            return QTT(other - self.value, self.unit)

        print("Type mismatch")
        return NotImplemented

    # enable multiplication
    def __mul__(self, other):

        # check if the multiplication is scalar or between QTTs.
        # The unit vectors are added, since they represent the exponents
        if isinstance(other, QTT):
            return QTT(self.value * other.value, to_string_unit(self.unitVect + other.unitVect))
        elif isinstance(other, int) or isinstance(other, float):
            return QTT(self.value * other, self.unit)

        print("Type mismatch")
        return NotImplemented

    # enable reverse multiplication, no changes needed, as it is commutative
    def __rmul__(self, other):
        return self.__mul__(other)

    # enable division using the same logic as in multiplication
    def __truediv__(self, other):
        if isinstance(other, QTT):
            return QTT(self.value / other.value, to_string_unit(self.unitVect - other.unitVect))
        elif isinstance(other, int) or isinstance(other, float):
            return QTT(self.value / other, self.unit)

        print("Type mismatch")
        return NotImplemented

    #enable reverse division, accounting for non commutability
    def __rtruediv__(self, other):
        if isinstance(other, QTT):
            return QTT(other.value / to_string_unit(other.unitVect - self.unitVect))
        elif isinstance(other, int) or isinstance(other, float):
            return QTT(other / self.value, to_string_unit(self.unitVect*-1)) # if we are in the case 1/unit we have to invert all powers

        print("Type mismatch")
        return NotImplemented


    # enable the power function
    def __pow__(self, other):
        if isinstance(other, QTT):
            return QTT(self.value ** other.value, to_string_unit(self.unitVect * other.unitVect))
        elif isinstance(other, int) or isinstance(other, float):
            return QTT(self.value ** other, to_string_unit(self.unitVect*other))

        print("Type mismatch")
        return NotImplemented

    # enable the round function
    def __round__(self, n=None):
        return QTT(round(self.value, n), self.unit)




