from .qtt import QTT


constants = {
    "Speed of light": {
        "symbol": "c",
        "unit": "m s^-1",
        "value": 299792458
    },
    "Gravitational constant": {
        "symbol": "G",
        "unit": "m^3 kg^-1 s^-2",
        "value": 6.67430e-11
    },
    "Planck constant": {
        "symbol": "h",
        "unit": "J s",
        "value": 6.62607015e-34
    },
    "Reduced Planck constant": {
        "symbol": "H",
        "unit": "J s",
        "value": 1.054571817e-34
    },
    "Elementary charge": {
        "symbol": "e",
        "unit": "C",
        "value": 1.602176634e-19
    },
    "Boltzmann constant": {
        "symbol": "k_B",
        "unit": "J K^-1",
        "value": 1.380649e-23
    },
    "Avogadro constant": {
        "symbol": "N_A",
        "unit": "mol^-1",
        "value": 6.02214076e23
    },
    "Gas constant": {
        "symbol": "R",
        "unit": "J mol^-1 K^-1",
        "value": 8.314462618
    },
    "Vacuum permittivity": {
        "symbol": "E0",
        "unit": "F m^-1",
        "value": 8.8541878128e-12
    },
    "Vacuum permeability": {
        "symbol": "U0",
        "unit": "N A^-2",
        "value": 1.25663706212e-6
    },
    "Coulomb constant": {
        "symbol": "k_e",
        "unit": "N m^2 C^-2",
        "value": 8.9875517923e9
    },
    "Electron mass": {
        "symbol": "m_e",
        "unit": "kg",
        "value": 9.1093837015e-31
    },
    "Proton mass": {
        "symbol": "m_p",
        "unit": "kg",
        "value": 1.67262192369e-27
    },
    "Neutron mass": {
        "symbol": "m_n",
        "unit": "kg",
        "value": 1.67492749804e-27
    },
    "Rydberg constant": {
        "symbol": "RY",
        "unit": "m^-1",
        "value": 10973731.568160
    },
    "Stefan-Boltzmann constant": {
        "symbol": "k_bolz",
        "unit": "W m^-2 K^-4",
        "value": 5.670374419e-8
    },
    "Faraday constant": {
        "symbol": "F",
        "unit": "C mol^-1",
        "value": 96485.33212
    },
    "Fine-structure constant": {
        "symbol": "a",
        "unit": "dimensionless",
        "value": 7.2973525693e-3
    },
    "Bohr radius": {
        "symbol": "a0",
        "unit": "m",
        "value": 5.29177210903e-11
    },
    "Bohr magneton": {
        "symbol": "uB",
        "unit": "J T^-1",
        "value": 9.2740100783e-24
    },
    "Nuclear magneton": {
        "symbol": "uN",
        "unit": "J T^-1",
        "value": 5.0507837461e-27
    },
    "Magnetic flux quantum": {
        "symbol": "psi_0",
        "unit": "Wb",
        "value": 2.067833848e-15
    },
    "Conductance quantum": {
        "symbol": "G_0",
        "unit": "S",
        "value": 7.748091729e-5
    },
    "Josephson constant": {
        "symbol": "K_J",
        "unit": "Hz V^-1",
        "value": 483597.8484e9
    },
    "von Klitzing constant": {
        "symbol": "R_K",
        "unit": "Ω",
        "value": 25812.80745
    },
    "Electron charge-to-mass ratio": {
        "symbol": "e/m_e",
        "unit": "C kg^-1",
        "value": 1.75882001076e11
    },
    "Molar mass constant": {
        "symbol": "M_u",
        "unit": "kg mol^-1",
        "value": 1e-3
    },
    "First radiation constant": {
        "symbol": "c1",
        "unit": "W m^2",
        "value": 3.741771852e-16
    },
    "Second radiation constant": {
        "symbol": "c2",
        "unit": "m K",
        "value": 1.438776877e-2
    },
    "Hartree energy": {
        "symbol": "E_h",
        "unit": "J",
        "value": 4.3597447222071e-18
    },
    "Thomson cross section": {
        "symbol": "o_T",
        "unit": "m^2",
        "value": 6.6524587321e-29
    },
    "Electron gyromagnetic ratio": {
        "symbol": "γ_e",
        "unit": "s^-1 T^-1",
        "value": 1.76085963023e11
    },
    "Proton gyromagnetic ratio": {
        "symbol": "γ_p",
        "unit": "s^-1 T^-1",
        "value": 2.6752218744e8
    },
    "Atomic mass constant": {
        "symbol": "m_u",
        "unit": "kg",
        "value": 1.66053906660e-27
    },
    "Solar mass": {
        "symbol": "M_sun",
        "unit": "kg",
        "value": 1.98847e30
    },
    "Astronomical unit": {
        "symbol": "AU",
        "unit": "m",
        "value": 1.495978707e11
    },
    "Parsec": {
        "symbol": "pc",
        "unit": "m",
        "value": 3.08567758149137e16
    },
    "Light year": {
        "symbol": "ly",
        "unit": "m",
        "value": 9.4607304725808e15
    }

}

# only generate the QTT class for the constant if it is actually called
# This saves alot of memory
def __getattr__(name):
    for c in constants:
        if constants[c]["symbol"] == name:
            constant = QTT(constants[c]["value"], constants[c]["unit"])
            return constant

    raise AttributeError(f"module has no attribute {name}")


# print an informational table of available constants
def info():
    print("The following constants are available: ")
    for c in constants:
        print(f"{c}, Callname: {constants[c]['symbol']}")


"""
This is the piece for version 0.1.0

c = QTT(299792456, "m s^-1")
G = QTT(6.67408E-11, "m^3 kg^-1 s^-2")
F = QTT(96485.33289, "A s mol^-1")
e0 = QTT(8.854E-12, "A^2 s^2 s^2 kg^-1 m^-1 m^-2")
e = QTT(1.6021766208E-19, "A s")
Ry = QTT(10973731.568157, "m^-1")
eM = QTT(9.1093837E-31, "kg")
h = QTT(6.626069E-34, "kg m^2 s^-1")
H  = QTT(6.626069E-34, "kg m^2 s^-1")
kb = QTT(1.38064852E-23, "kg m^2 s^-2 K")"""



