import numpy as np
import matplotlib.pyplot as plt

def add_and_print(a,b):
    print(a+b)

