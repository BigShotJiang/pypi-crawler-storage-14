import numpy as np
import stemToolkit.constants as c
lightspeed = c.c

c.info()

