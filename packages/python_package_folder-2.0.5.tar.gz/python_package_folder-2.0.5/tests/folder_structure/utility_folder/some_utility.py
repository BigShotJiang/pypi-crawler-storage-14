def print_something(to_print: str):
    print(to_print)
