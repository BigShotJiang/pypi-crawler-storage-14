# fabric-demos

[![PyPi version](https://badgen.net/pypi/v/fabric-demos/)](https://pypi.org/project/fabric-demos)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

fab-demos is a toolkit to easily install demos on Microsoft Fabric.

## Installation
Install fab-demos

```
%pip install fab-demos
```

## Usage within Fabric

Within a Python notebook, browse all demos:

```
import fabric_demos as fabdemos
fabdemos.browse()
```

Install a demo:

```
fabdemos.install(name="<demo_name>")
```

## Usage from CLI

Browse all demos:

```bash
$ fabdemos browse
```

Install a demo:

```bash
$ fabdemos install -n <demo_name> -ws <workspace_name>
```
