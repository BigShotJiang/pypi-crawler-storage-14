import os
from pathlib import Path

from notebookutils import credentials

from fabric_demos.core import constant
from fabric_demos.core.conf import FabricDemoConfig
from fabric_demos.core.exceptions import FabricDemoError


def setup_token_for_notebook(skip_auth: bool) -> None:
    if not skip_auth:
        try:
            get_ipython  # Check if IPython is available

            token = credentials.getToken("pbi")
            os.environ[constant.FAB_TOKEN_ENV_VAR] = token
            token = credentials.getToken("storage")
            os.environ[constant.FAB_TOKEN_ONELAKE_ENV_VAR] = token

        except NameError:
            pass


def load_demos_config() -> list:
    workspace_root = Path(__file__).parent.parent
    demos_file = workspace_root / constant.FABDEMOS_YML_FILE

    if not demos_file.exists():
        raise FabricDemoError(
            "demos.yml file not found in the workspace root",
            constant.ERROR_NOT_FOUND,
        )

    try:
        return FabricDemoConfig.from_yml(demos_file), workspace_root
    except Exception as e:
        raise FabricDemoError(
            f"Error reading demos.yml: {e}",
            constant.ERROR_UNEXPECTED_ERROR,
        )
