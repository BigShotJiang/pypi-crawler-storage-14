import json
import os
import re
import shutil
import subprocess

from fabric_demos.core import constant
from fabric_demos.core.exceptions import FabricDemoError
from fabric_demos.utils import ui


def fab_authenticate_spn(
    client_id: str = None, client_secret: str = None, tenant_id: str = None
) -> None:
    print("Authenticating with SPN")

    if client_id is None or client_secret is None or tenant_id is None:
        client_id = os.getenv("FABRIC_CLIENT_ID")
        client_secret = os.getenv("FABRIC_CLIENT_SECRET")
        tenant_id = os.getenv("FABRIC_TENANT_ID")

    if not tenant_id or not client_id or not client_secret:
        raise Exception(
            "! Environment variables FABRIC_CLIENT_ID, FABRIC_CLIENT_SECRET and FABRIC_TENANT_ID must be set"
        )

    run_fab_command("config set fab_encryption_fallback_enabled true")

    run_fab_command(
        f"auth login -u {client_id} -p {client_secret} --tenant {tenant_id}",
        include_secrets=True,
    )


def run_fab_command(
    command,
    capture_output: bool = False,
    include_secrets: bool = False,
    silently_continue: bool = False,
) -> str:
    result = subprocess.run(
        ["fab", "-c", command],
        capture_output=capture_output,
        text=True,
    )

    if not (silently_continue) and (result.returncode > 0 or result.stderr):
        raise FabricDemoError(
            f"! Error running fab command. exit_code: '{result.returncode}'; stderr: '{result.stderr}'",
            constant.ERROR_FAB_COMMAND_FAILED,
        )

    if capture_output:
        output = result.stdout.strip().split("\n")[-1]
        return output


def create_workspace(
    workspace_name, capacity_name: str = "none", upns: list = None
) -> str:
    command = f"create /{workspace_name}.Workspace"

    if capacity_name:
        command += f" -P capacityName={capacity_name}"

    run_fab_command(command, silently_continue=True)

    if upns is not None:
        upns = [x for x in upns if x.strip()]
        if len(upns) > 0:
            for upn in upns:
                run_fab_command(
                    f"acl set -f /{workspace_name}.Workspace -I {upn} -R admin"
                )

    workspace_id = run_fab_command(
        f"get /{workspace_name}.Workspace -q id", capture_output=True
    )

    return workspace_id


def create_connection(
    connection_name: str = None, parameters: dict = None, upns: list = None
) -> str:
    if parameters:
        param_str = ",".join(f"{key}={value}" for key, value in parameters.items())
        param_str = f"-P {param_str}"
    else:
        param_str = ""

    run_fab_command(
        f"create .connections/{connection_name}.Connection {param_str}",
        silently_continue=True,
    )

    connection_id = run_fab_command(
        f"get .connections/{connection_name}.Connection -q id", capture_output=True
    )

    if upns is not None:

        upns = [x for x in upns if x.strip()]

        if len(upns) > 0:
            for upn in upns:
                run_fab_command(
                    f"acl set -f .connections/{connection_name}.Connection -I {upn} -R admin"
                )

    return connection_id


def create_item(
    workspace_name: str = None,
    item_type: str = None,
    item_name: str = None,
    parameters: dict = None,
) -> str:
    if parameters:
        param_str = ",".join(f"{key}={value}" for key, value in parameters.items())
        param_str = f"-P {param_str}"
    else:
        param_str = ""

    run_fab_command(
        f"create /{workspace_name}.workspace/{item_name}.{item_type} {param_str}",
        silently_continue=True,
    )

    item_id = run_fab_command(
        f"get /{workspace_name}.workspace/{item_name}.{item_type} -q id",
        capture_output=True,
    )

    return item_id


def deploy_item(
    src_path,
    workspace_name,
    item_type: str = None,
    item_name: str = None,
    find_and_replace: dict = None,
    what_if: bool = False,
    func_after_staging=None,
) -> str:
    staging_path = copy_to_staging(src_path)

    # Call function that provides flexibility to change something in the staging files
    if func_after_staging:
        func_after_staging(staging_path)

    if os.path.exists(os.path.join(staging_path, ".platform")):
        with open(os.path.join(staging_path, ".platform"), "r") as file:
            platform_data = json.load(file)

        if item_name is None:
            item_name = platform_data["metadata"]["displayName"]

        if item_type is None:
            item_type = platform_data["metadata"]["type"]
    else:
        base_name = os.path.basename(staging_path)  # Get the last part of the path
        if "." in base_name:
            item_name, item_type = base_name.split(".", 1)  # Split into name and type
        else:
            raise FabricDemoError(
                f"Unable to determine item_name and item_type from staging path: {staging_path}",
                constant.ERROR_UNEXPECTED_ERROR,
            )

    # Loop through all files and apply the find & replace with regular expressions
    if find_and_replace:
        for root, _, files in os.walk(staging_path):
            for file in files:
                file_path = os.path.join(root, file)

                with open(file_path, "r") as file:
                    text = file.read()

                # Loop parameters and execute the find and replace in the ones that match the file path
                for key, replace_value in find_and_replace.items():
                    find_and_replace_file_filter = key[0]
                    find_and_replace_file_find = key[1]

                    if re.search(find_and_replace_file_filter, file_path):
                        text, count_subs = re.subn(
                            find_and_replace_file_find, replace_value, text
                        )
                        if count_subs > 0:

                            # print(
                            #     f"Find & replace in file '{file_path}' with regex '{find_and_replace_file_find}'"
                            # )

                            with open(file_path, "w") as file:
                                file.write(text)

    if not what_if:
        run_fab_command(
            f"import -f /{workspace_name}.workspace/{item_name}.{item_type} -i {staging_path}"
        )

        # Return id after deployment
        item_id = run_fab_command(
            f"get /{workspace_name}.workspace/{item_name}.{item_type} -q id",
            capture_output=True,
        )

        return item_id


def copy_to_staging(path: str) -> str:
    try:
        # Use __file__ if available (CLI execution)
        workspace_root = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "../..")
        )
    except NameError:
        # Fallback to current working directory (Notebook execution)
        workspace_root = os.getcwd()

    src_path = os.path.join(workspace_root, path)

    if not os.path.exists(src_path):
        raise FabricDemoError(
            f"Source path does not exist: {src_path}", constant.ERROR_INVALID_PATH
        )

    # Ensure staging folder exists at the root level
    path_staging = os.path.join(workspace_root, "_stg", os.path.basename(path))

    if os.path.exists(path_staging):
        shutil.rmtree(path_staging)

    os.makedirs(path_staging)

    # Copy files to staging folder
    shutil.copytree(
        src_path,
        path_staging,
        dirs_exist_ok=True,
        ignore=shutil.ignore_patterns("*.abf"),
    )

    return path_staging


def delete_staging_directory() -> None:
    try:
        # Determine the workspace root
        workspace_root = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "../..")
        )
        staging_dir = os.path.join(workspace_root, "_stg")

        # Check if the staging directory exists
        if os.path.exists(staging_dir):
            shutil.rmtree(staging_dir)
            # ui.print_grey(f"Staging directory '{staging_dir}' deleted")
        else:
            ui.print_grey(f"Staging directory '{staging_dir}' does not exist")
    except Exception as e:
        raise FabricDemoError(
            f"! Error deleting staging directory: {e}", constant.ERROR_UNEXPECTED_ERROR
        )
