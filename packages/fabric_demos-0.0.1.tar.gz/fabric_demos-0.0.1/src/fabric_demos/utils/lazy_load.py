def questionary():
    import questionary

    return questionary
