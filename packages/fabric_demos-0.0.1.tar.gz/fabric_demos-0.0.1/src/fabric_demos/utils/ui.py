import builtins
import html
import sys
from typing import Any, Optional, Sequence

from fabric_demos.core.exceptions import FabricDemoError
from fabric_demos.utils import lazy_load, ui


def print_done(text: str, to_stderr: bool = False) -> None:
    # Escape the text to avoid HTML injection and parsing issues
    escaped_text = html.escape(text)
    _safe_print_formatted_text(
        f"<ansigreen>*</ansigreen> {escaped_text}", escaped_text, to_stderr
    )


def print_warning(text: str, command: Optional[str] = None) -> None:
    # Escape the text to avoid HTML injection and parsing issues
    text = text.rstrip(".")
    escaped_text = html.escape(text)
    command_text = f"{command}: " if command else ""
    _safe_print_formatted_text(
        f"<ansiyellow>!</ansiyellow> {command_text}{escaped_text}",
        escaped_text,
        to_stderr=True,
    )


def print(text: str) -> None:
    _safe_print(text)


def print_grey(text: str, to_stderr: bool = True) -> None:
    _safe_print(text, style="fg:grey", to_stderr=to_stderr)


def print_version(args=None) -> None:
    ui.print(f"fabdemos version 0.0.1")
    ui.print("https://muredata.com/fabric-demos")


def print_output_error(
    error: FabricDemoError,
    command: Optional[str] = None,
    output_format_type: Optional[str] = None,
) -> None:
    _print_error_format_text(error.formatted_message(), command)


def _print_error_format_text(message: str, command: Optional[str] = None) -> None:
    command_text = f"{command}: " if command else ""
    _safe_print_formatted_text(f"<ansired>x</ansired> {command_text}{message}", message)


def prompt_select_item(question: str, choices: Sequence) -> Any:
    # Prompt the user to select a single item from a list of choices
    selected_item = (
        lazy_load.questionary()
        .select(question, choices=choices, pointer=">", style=_get_common_style())
        .ask()
    )

    return selected_item


def prompt_confirm(text: str = "Are you sure?") -> Any:
    return lazy_load.questionary().confirm(text, style=_get_common_style()).ask()


def display_help(
    commands: dict[str, dict[str, str]], custom_header: Optional[str] = None
) -> None:
    if not commands or len(commands) == 0:
        print("No commands available.")
        return
    # if custom_header:
    #     print(f"{custom_header} \n")
    # else:
    print("One-line installation Fabric demos.\n")
    print("Usage: fabdemos <command> [flags]\n")

    max_command_length = max(
        len(cmd) for cmd_dict in commands.values() for cmd in cmd_dict
    )

    for category, cmd_dict in commands.items():
        print(f"{category}:")
        for command, description in cmd_dict.items():
            padded_command = f"{command:<{max_command_length}}"
            print(f"  {padded_command}: {description}")
        print("")

    # Learn more
    print("Learn More:")
    print("  Browse demos in UI at https://muredata.com/fabric-demos.\n")


def _safe_print(
    text: str, style: Optional[str] = None, to_stderr: bool = False
) -> None:

    try:
        # Redirect to stderr if `to_stderr` is True
        output_stream = sys.stderr if to_stderr else sys.stdout
        questionary_module = lazy_load.questionary()
        questionary_module.print(text, style=style, file=output_stream)

    except (RuntimeError, AttributeError, Exception) as e:
        _print_fallback(text, e, to_stderr=to_stderr)


def _print_fallback(text: str, e: Exception, to_stderr: bool = False) -> None:
    # Fallback print
    # https://github.com/prompt-toolkit/python-prompt-toolkit/issues/406
    output_stream = sys.stderr if to_stderr else sys.stdout
    builtins.print(text, file=output_stream)
    if isinstance(e, AttributeError):  # Only re-raise AttributeError (pytest)
        raise


def _safe_print_formatted_text(
    formatted_text: str, escaped_text: str, to_stderr: bool = False
) -> None:
    from prompt_toolkit import HTML, print_formatted_text

    try:
        output_stream = sys.stderr if to_stderr else sys.stdout
        print_formatted_text(HTML(formatted_text), file=output_stream)
    except (RuntimeError, AttributeError, Exception) as e:
        _print_fallback(escaped_text, e, to_stderr)


# Utils


def _get_common_style():
    return lazy_load.questionary().Style(
        [
            ("qmark", "fg:#49C5B1"),
            ("question", ""),
            ("answer", "fg:#6c6c6c"),
            ("pointer", "fg:#49C5B1"),
            ("highlighted", "fg:#49C5B1"),
            ("selected", "fg:#49C5B1"),
            ("separator", "fg:#6c6c6c"),
            ("instruction", "fg:#49C5B1"),
            ("text", ""),
            ("disabled", "fg:#858585 italic"),
        ]
    )
