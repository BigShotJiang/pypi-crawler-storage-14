from argparse import Namespace

from IPython.core.display import HTML, display

from fabric_demos.commands import demos_install
from fabric_demos.core.decorators import handle_exceptions
from fabric_demos.utils import commons, ui


@handle_exceptions()
def exec_command(args: Namespace = None) -> None:
    demos, workspace_root = commons.load_demos_config()

    demos_dict = {}
    for demo in demos:
        category = demo.category.lower()
        if category not in demos_dict:
            demos_dict[category] = []
        demos_dict[category].append(demo)

    try:
        get_ipython  # Check if IPython is available
        html_content = _get_html_list_demos(demos_dict)
        display(HTML(html_content))
    except NameError:
        demo_count = sum(len(demo_list) for demo_list in demos_dict.values())
        ui.print_grey(f"{demo_count} demos found")

        # Create a list of demo names for selection
        demo_choices = []
        for category, demo_list in demos_dict.items():
            demo_list.sort(key=lambda demo: demo.name)
            for demo in demo_list:
                demo_choices.append(f"{demo.name} | {demo.description}")

        selected_demo = ui.prompt_select_item(
            "Select demo you want to install:", demo_choices
        )

        if selected_demo is None:
            return

        if ui.prompt_confirm():
            ui.print_grey("--------------------------------\n")
            demos_install.exec_command(name=selected_demo.split(" | ")[0])


# Utils


def _get_html_list_demos(demos: dict) -> str:
    CSS_LIST = """
    <style>
        .fabdemo {
            font-family: "Segoe Sans Display", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            max-width: 100%;
            overflow-x: hidden;
        }
        .menu_button {
            font-size: 15px;
            cursor: pointer;
            border: 0px;
            padding: 10px 20px 10px 20px;
            margin-right: 10px;
            background-color: rgb(238, 237, 233);
            border-radius: 20px;
        }
        .menu_button:hover {
            background-color: rgb(245, 244, 242)
        }
        .menu_button.selected {
            background-color: rgb(158, 214, 196)
        }
        .fabdemo_category {
            margin-top: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            max-height: 600px; /* Limit height */
            overflow-y: auto; /* Enable vertical scrolling */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .fabdemo_box {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background-color: white;
            width: 350px;
            box-sizing: border-box;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .fabdemo_box:hover {
            transform: translateY(-5px); /* Slight lift effect on hover */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        .fabdemo_logo {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .fabdemo_description {
            margin-top: 10px;
        }
        .fabdemo_description h2 {
            font-size: 18px;
            margin: 0;
            color: #333;
        }
        .fabdemo_description p {
            font-size: 14px;
            color: #666;
        }
        .code {
            font-family: monospace;
            background-color: #f4f4f4;
            padding: 5px;
            border-radius: 3px;
            margin-top: 10px;
            font-size: 12px;
            color: #333;
        }
        .new_tag {
            background-color: #ff0000;
            color: white;
            padding: 2px 5px;
            border-radius: 3px;
            margin-left: 5px;
            font-size: 12px;
        }
    </style>
    """

    JS_LIST = """
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const buttons = document.querySelectorAll(".menu_button");
            const categories = document.querySelectorAll(".fabdemo_category");

            buttons.forEach((button, index) => {
                button.addEventListener("click", () => {
                    // Remove 'selected' class from all buttons
                    buttons.forEach(btn => btn.classList.remove("selected"));
                    // Add 'selected' class to the clicked button
                    button.classList.add("selected");

                    // Hide all categories
                    categories.forEach(cat => cat.style.display = "none");
                    // Show the selected category
                    categories[index].style.display = "flex";
                });
            });
        });
    </script>
    """

    categories = list(demos.keys())
    content = f"""{CSS_LIST}<div class="fabdemo">
     <div style="padding: 10px 0px 20px 20px">"""
    for i, cat in enumerate(categories):
        content += f"""<button category="{cat}" class="menu_button {"selected" if i == 0 else ""}" type="button">{f'<span class="new_tag">NEW!</span>' if cat == 'AI-BI' else ''}<span>{cat.capitalize()}</span></button>"""
    content += """</div>"""
    for i, cat in enumerate(categories):
        content += f"""<div class="fabdemo_category {"active" if i == 0 else ""}" id="category-{cat}">"""
        ds = list(demos[cat])
        ds.sort(key=lambda d: d.name)  # Access attributes using dot notation
        for demo in ds:
            content += f"""
            <div class="fabdemo_box">
              <img class="fabdemo_logo" src="https://github.com/murggu/data-samples/raw/main/resources/icons/{demo.name}.jpg" />
              <div class="fabdemo_description">
                <h2>{demo.title}</h2>
                <p>{demo.description}</p>
              </div>
              <div class="code"> 
                fabdemos.install(name='{demo.name}')
              </div>
            </div>"""
        content += """</div>"""
    content += f"""</div>{JS_LIST}"""

    return content
