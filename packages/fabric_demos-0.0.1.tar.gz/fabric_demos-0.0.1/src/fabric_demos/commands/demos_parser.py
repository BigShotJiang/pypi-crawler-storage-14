from argparse import Namespace, _SubParsersAction

from fabric_demos.commands import demos
from fabric_demos.core import constant
from fabric_demos.utils import ui


def register_parser(subparsers: _SubParsersAction) -> None:

    # Subcommand for 'browse'
    parser_browse = subparsers.add_parser(
        "browse",
        help="Browse available demos",
    )
    parser_browse.set_defaults(func=demos.browse_demos)

    # Subcommand for 'install'
    install_examples = [
        "# install demo with workspace creation",
        "$ fabdemos install -n <demo_name>\n",
        "# install demo in a specific workspace",
        "$ fabdemos install -n <demo_name> --ws ws-fabdemos-01",
    ]

    parser_install = subparsers.add_parser(
        "install",
        help="Install a demo from a repository",
        fab_examples=install_examples,
        fab_learnmore=["_"],
    )
    parser_install.add_argument(
        "-n", "--name", metavar="", required=True, help="Name of the demo to install"
    )
    parser_install.add_argument(
        "-ws",
        "--workspace",
        metavar="",
        required=False,
        help="Workspace for the demo installation. Optional",
    )
    parser_install.add_argument(
        "--capacity",
        metavar="",
        required=False,
        help="Capacity name for the demo installation. Optional",
    )
    parser_install.set_defaults(func=demos.install_demo)

    # Subcommand for 'remove'
    parser_remove = subparsers.add_parser(
        "remove",
        help="Remove installed demo",
    )
    parser_remove.add_argument(
        "-n",
        "--name",
        metavar="",
        required=True,
        help="Name of the workspace demo to remove",
    )
    parser_remove.set_defaults(func=demos.remove_demo)


def show_help(args: Namespace) -> None:
    ui.display_help(constant.COMMANDS)
