from argparse import Namespace

from fabric_demos.core import constant
from fabric_demos.core.decorators import handle_exceptions
from fabric_demos.core.exceptions import FabricDemoError
from fabric_demos.utils import commons, fab, ui


@handle_exceptions()
def exec_command(
    args: Namespace = None,
    name: str = None,
    skip_auth: bool = False,
) -> None:

    if args:
        name = args.name

    if not name:
        raise FabricDemoError(
            "Demo name is required",
            constant.ERROR_INVALID_INPUT,
        )

    ui.print_grey(f"> Removing workspace demo '{name}'...")
    commons.setup_token_for_notebook(skip_auth)

    fab.run_fab_command(f"rm {name}.workspace -f")
