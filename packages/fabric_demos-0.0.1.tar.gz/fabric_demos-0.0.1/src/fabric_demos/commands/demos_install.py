import importlib.util
import os
import random
import string
import sys
from argparse import Namespace

from fabric_demos.core import constant
from fabric_demos.core.decorators import handle_exceptions
from fabric_demos.core.exceptions import FabricDemoError
from fabric_demos.utils import commons, fab, ui


@handle_exceptions()
def exec_command(
    args: Namespace = None,
    name: str = None,
    workspace: str = None,
    capacity: str = None,
    skip_auth: bool = False,
) -> None:
    if args:
        name = args.name
        workspace = args.workspace
        capacity = args.capacity

    if not name:
        raise FabricDemoError(
            "Demo name is required",
            constant.ERROR_INVALID_INPUT,
        )

    demos, workspace_root = commons.load_demos_config()

    # Check if the provided name exists in yml
    demo = next((demo for demo in demos if demo.name == name), None)
    if not demo:
        raise FabricDemoError(
            f"Demo '{name}' not found in demos.yml",
            constant.ERROR_INVALID_FORMAT,
        )

    # Get the repo_url for the demo
    repo_url = demo.repo_url
    if not repo_url:
        raise FabricDemoError(
            f"Demo '{name}' does not have a repository URL specified",
            constant.ERROR_INVALID_FORMAT,
        )

    # Resolve the path to the bundle.py file
    bundle_dir = workspace_root / repo_url
    bundle_file = bundle_dir / "bundle.py"
    if not bundle_file.exists():
        raise FabricDemoError(
            f"bundle.py not found in the repository path '{repo_url}' for demo '{name}'",
            constant.ERROR_INVALID_PATH,
        )

    # Dynamically import and execute the deploy function from bundle.py
    spec = importlib.util.spec_from_file_location("bundle", bundle_file)
    bundle_module = importlib.util.module_from_spec(spec)
    sys.modules["bundle"] = bundle_module
    spec.loader.exec_module(bundle_module)

    if not hasattr(bundle_module, "deploy"):
        raise FabricDemoError(
            f"deploy function not found in bundle.py for demo '{name}'",
            constant.ERROR_NOT_FOUND,
        )

    # Install the demo
    ui.print_grey(f"> Installing demo '{name}'...")
    commons.setup_token_for_notebook(skip_auth)

    workspace_name, workspace_id = _create_workspace_if_not_exists(
        workspace=workspace, demo_name=name, capacity_name=capacity
    )
    deployed_count = bundle_module.deploy(workspace_name, workspace_id)
    ui.print(f"\nReady! '{deployed_count}' items deployed successfully.")

    fab.delete_staging_directory()
    ui.print_grey(f"Open '{workspace_name}' workspace to explore the demo")


# Utils


def _create_workspace_if_not_exists(
    workspace: str, demo_name: str, capacity_name: str = None
) -> tuple[str, str]:
    if workspace:
        workspace_name = workspace
    else:
        workspace_name = (
            f"ws-{demo_name}-{''.join(random.choices(string.ascii_letters, k=3))}"
        )

    # Check if workspace exists
    workspace_exists = fab.run_fab_command(
        f"exists /{workspace_name}.workspace",
        capture_output=True,
    ).strip()
    workspace_exists = workspace_exists == "* true"

    if workspace_exists:
        workspace_id = fab.run_fab_command(
            f"get /{workspace_name}.workspace -q id",
            capture_output=True,
        ).strip()
        ui.print_grey(f"Using existing workspace '{workspace_name}'...")
        return workspace_name, workspace_id

    # If capacity_name is not provided and not in env, get the default capacity from fabcli config
    if capacity_name is None:
        capacity_name = os.environ.get(constant.FABDEMOS_CAPACITY)
        if capacity_name is None:  # If still None, fetch from fabcli config
            capacity_name = fab.run_fab_command(
                f"config get default_capacity",
                capture_output=True,
            ).strip()

    # Validate capacity
    if not capacity_name:
        raise FabricDemoError(
            "No capacity name provided and no default capacity found in fabcli config",
            constant.ERROR_INVALID_INPUT,
        )

    # Create workspace
    workspace_id = fab.create_workspace(
        workspace_name=workspace_name, capacity_name=capacity_name
    )

    return workspace_name, workspace_id
