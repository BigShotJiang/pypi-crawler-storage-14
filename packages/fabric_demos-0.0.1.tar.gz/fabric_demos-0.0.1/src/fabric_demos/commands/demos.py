from argparse import Namespace

from fabric_demos.commands import demos_browse, demos_install, demos_remove


def browse_demos(args: Namespace) -> None:
    demos_browse.exec_command(args)


def install_demo(args: Namespace) -> None:
    demos_install.exec_command(args)


def remove_demo(args: Namespace) -> None:
    demos_remove.exec_command(args)
