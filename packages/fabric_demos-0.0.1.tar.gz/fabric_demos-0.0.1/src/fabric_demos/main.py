import argparse
import re
import sys

from fabric_demos.commands import demos_parser
from fabric_demos.core import constant
from fabric_demos.utils import error_parser, ui


class CustomHelpFormatter(argparse.HelpFormatter):

    def __init__(
        self,
        prog,
        fab_examples=None,
        fab_aliases=None,
        fab_learnmore=None,
        *args,
        **kwargs,
    ):
        super().__init__(prog, *args, **kwargs)
        self.fab_examples = fab_examples or []
        self.fab_aliases = fab_aliases or []
        self.fab_learnmore = fab_learnmore or []

    def _format_args(self, action, default_metavar):
        if action.nargs in ("*", "+"):
            if action.option_strings:
                return ""
            else:
                # Ensure metavar is lowercase for positional arguments
                return f"<{action.dest}>"
        return super()._format_args(action, default_metavar)

    def _format_action_invocation(self, action):
        if not action.metavar and action.nargs in (None, "?"):
            # For no metavar and simple arguments
            return ", ".join(action.option_strings)
        elif action.nargs in ("*", "+"):
            metavar = self._format_args(action, action.dest)
            return ", ".join(action.option_strings) + metavar
        else:
            return super()._format_action_invocation(action)

    def format_help(self):
        help_message = super().format_help()

        # Custom output
        help_message = help_message.replace("usage:", "Usage:")
        help_message = help_message.replace("positional arguments:", "Arg(s):")
        help_message = help_message.replace("options:", "Flags:")

        help_message = re.sub(
            r"\s*-h, --help\s*(Show help for command|show this help message and exit)?",
            "",
            help_message,
        )
        help_message = help_message.replace("  -help\n", "")
        help_message = help_message.replace("[-h] ", "")
        help_message = help_message.replace("[-help] ", "")
        help_message = help_message.replace("[-help]", "")

        if "Flags:" in help_message:
            flags_section = help_message.split("Flags:")[1].strip()
            if not flags_section:  # If no flags follow the "Flags:" line, remove it
                help_message = help_message.replace("\nFlags:\n", "")

        # Add aliases
        if self.fab_aliases:
            help_message += "\nAliases:\n"
            for alias in self.fab_aliases:
                help_message += f"  {alias}\n"

        # Add examples
        if self.fab_examples:
            help_message += "\nExamples:\n"
            for example in self.fab_examples:
                if "#" in example:
                    # Grey color
                    help_message += f"  \033[38;5;243m{example}\033[0m\n"
                else:
                    help_message += f"  {example}\n"

        # Add learn more
        if self.fab_learnmore:
            help_message += "\nLearn more:\n"
            if self.fab_learnmore != ["_"]:
                for learn_more in self.fab_learnmore:
                    help_message += f"  {learn_more}\n"
            help_message += (
                "  To explore all demos, see https://muredata.com/fabric-demos\n"
            )

        return help_message + "\n"


class CustomArgumentParser(argparse.ArgumentParser):

    def __init__(
        self, *args, fab_examples=None, fab_aliases=None, fab_learnmore=None, **kwargs
    ):
        kwargs["formatter_class"] = lambda prog: CustomHelpFormatter(
            prog,
            fab_examples=fab_examples,
            fab_aliases=fab_aliases,
            fab_learnmore=fab_learnmore,
        )
        super().__init__(*args, **kwargs)
        # Add custom help and format flags
        self.fab_examples = fab_examples or []
        self.fab_aliases = fab_aliases or []

    def print_help(self, file=None):
        command_name = self.prog.split()[-1]

        help_functions = {
            "fabdemos": lambda: ui.display_help(constant.COMMANDS),
        }

        if command_name in help_functions:
            help_functions[command_name]()
        else:
            super().print_help(file)

    def error(self, message):
        if "invalid choice" in message:
            error_parser.invalid_choice(self, message)
        elif "unrecognized arguments" in message:
            error_parser.unrecognized_arguments(message)
        elif "the following arguments are required" in message:
            error_parser.missing_required_arguments(message)
        else:
            # Add more custom error parsers here
            print(message)

        sys.exit(2)


def main():
    parser = CustomArgumentParser(description="Fabric demos")
    # -version and --version
    parser.add_argument("-v", "--version", action="store_true")

    subparsers = parser.add_subparsers(dest="command", required=False)

    demos_parser.register_parser(subparsers)
    version_parser = subparsers.add_parser(
        "version", help=constant.COMMAND_VERSION_DESCRIPTION
    )
    version_parser.set_defaults(func=ui.print_version)
    args = parser.parse_args()

    # Handle -v or --version flags
    if args.version:
        ui.print_version()
        return

    # If no command is provided, show help
    if not hasattr(args, "func"):
        ui.display_help(constant.COMMANDS)
        return

    args.func(args)


if __name__ == "__main__":
    main()
