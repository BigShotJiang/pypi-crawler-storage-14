import json

from fabric_demos.core import constant
from fabric_demos.utils import fab

URL = f"{constant.FABDEMOS_BUNDLES_PATH}/tut-real-time-intelligence/workspace"


def deploy(workspace_name: str, workspace_id: str, skip_runs: bool = False) -> int:
    deployed_count = 0

    # Eventhouse
    eventhouse_id = fab.deploy_item(
        URL + "/Tutorial.Eventhouse",
        workspace_name=workspace_name,
    )
    deployed_count += 1

    # KQL database
    kql_database_name = "Tutorial"
    kql_database_id = fab.deploy_item(
        URL + f"/{kql_database_name}.KQLDatabase",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"DatabaseProperties.json",
                r'("parentEventhouseItemId"\s*:\s*)".*"',
            ): rf'\1"{eventhouse_id}"',
        },
    )
    deployed_count += 1

    # Eventstream
    fab.deploy_item(
        URL + "/TutorialEventstream.Eventstream",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"eventstream.json",
                r'("workspaceId"\s*:\s*)".*"',
            ): rf'\1"{workspace_id}"',
            (
                r"eventstream.json",
                r'("itemId"\s*:\s*)".*"',
            ): rf'\1"{kql_database_id}"',
        },
    )
    deployed_count += 1

    cluster_uri = fab.run_fab_command(
        f"api workspaces/{workspace_id}/kqlDatabases/{kql_database_id} -q text.properties.queryServiceUri",
        capture_output=True,
    )

    # KQLDashboard
    fab.deploy_item(
        URL + "/TutorialDashboard.KQLDashboard",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"RealTimeDashboard.json",
                r'("workspace"\s*:\s*)".*"',
            ): rf'\1"{workspace_id}"',
            (
                r"RealTimeDashboard.json",
                r'("database"\s*:\s*)".*"',
            ): rf'\1"{kql_database_id}"',
            (
                r"RealTimeDashboard.json",
                r'("clusterUri"\s*:\s*)".*"',
            ): rf'\1"{cluster_uri}"',
        },
    )
    deployed_count += 1

    # KQLQueryset x2
    kql_querysets = [
        "Tutorial_queryset",
        "TutorialQueryset",
    ]
    for queryset_name in kql_querysets:
        fab.deploy_item(
            URL + f"/{queryset_name}.KQLQueryset",
            workspace_name=workspace_name,
            find_and_replace={
                (
                    r"RealTimeQueryset.json",
                    r'("connections"\s*:\s*\[\s*{[^}]*"connectionString"\s*:\s*)".*"',
                ): rf'\1"{cluster_uri}"',
                (
                    r"RealTimeQueryset.json",
                    r'("connections"\s*:\s*\[\s*{[^}]*"initialCatalog"\s*:\s*)".*"',
                ): rf'\1"{kql_database_id}"',
                (
                    r"RealTimeQueryset.json",
                    r'("88a7ebfd-4b71-b41d-41ea-8bc0286d907e")',
                ): rf'"{kql_database_id}"',
            },
        )
        deployed_count += 1

    # SemanticModel
    semanticmodel_id = fab.deploy_item(
        URL + f"/TutorialReport.SemanticModel",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"definition/tables/Kusto Query Result.tmdl",
                r'("https://trd-56czdt1je8qzxvd82u.z7.kusto.fabric.microsoft.com/")',
            ): rf'"{cluster_uri}"',
            (
                r"definition/tables/Kusto Query Result.tmdl",
                r'("286d907e-8bc0-41ea-b41d-4b7188a7ebfd")',
            ): rf'"{kql_database_id}"',
        },
    )
    deployed_count += 1

    # Report
    fab.deploy_item(
        URL + f"/TutorialReport.Report",
        workspace_name=workspace_name,
        find_and_replace={
            ("definition.pbir", r"\{[\s\S]*\}"): json.dumps(
                {
                    "version": "4.0",
                    "datasetReference": {
                        "byConnection": {
                            "connectionString": None,
                            "pbiServiceModelId": None,
                            "pbiModelVirtualServerName": "sobe_wowvirtualserver",
                            "pbiModelDatabaseName": semanticmodel_id,
                            "name": "EntityDataSource",
                            "connectionType": "pbiServiceXmlaStyleLive",
                        }
                    },
                }
            )
        },
    )
    deployed_count += 1

    return deployed_count
