import json

from fabric_demos.core import constant
from fabric_demos.utils import fab

URL = f"{constant.FABDEMOS_BUNDLES_PATH}/tut-lakehouse/workspace"
LAKEHOUSE_NAME = "wwilakehouse"
SHORTCUT_NAME = "wwi-raw-data"


def deploy(workspace_name: str, workspace_id: str, skip_runs: bool = False) -> int:
    deployed_count = 0

    # Lakehouse
    lakehouse_id = fab.create_item(
        workspace_name=workspace_name,
        item_type="lakehouse",
        item_name=LAKEHOUSE_NAME,
        parameters={"enableSchemas": "false"},
    )
    deployed_count += 1

    # Connections
    connection_id_blob = fab.create_connection(
        connection_name=f"con_stfabdemos_blob_{workspace_name}",
        parameters={
            "connectionDetails.type": "AzureBlobs",
            "connectionDetails.parameters.account": "stfabdemos",
            "connectionDetails.parameters.domain": "blob.core.windows.net/fabdata",
            "credentialDetails.type": "Anonymous",
        },
    )
    connection_id_adls = fab.create_connection(
        connection_name=f"con_stfabdemos_adlsgen2_{workspace_name}",
        parameters={
            "connectionDetails.type": "AzureDataLakeStorage",
            "connectionDetails.parameters.server": "stfabdemos.dfs.core.windows.net",
            "connectionDetails.parameters.path": "fabdata",
            "credentialDetails.type": "SharedAccessSignature",
            "credentialDetails.Token": constant.SAS_TOKEN,
        },
    )
    deployed_count += 2

    # Pipeline
    fab.deploy_item(
        URL + "/IngestDataFromSourceToLakehouse.DataPipeline",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"pipeline-content.json",
                r'("workspaceId"\s*:\s*)".*"',
            ): rf'\1"{workspace_id}"',
            (
                r"pipeline-content.json",
                r'("artifactId"\s*:\s*)".*"',
            ): rf'\1"{lakehouse_id}"',
            (
                r"pipeline-content.json",
                r'("connection"\s*:\s*)".*"',
            ): rf'\1"{connection_id_blob}"',
        },
    )
    deployed_count += 1

    # Notebooks x2
    notebooks = [
        "01 - Create Delta Tables",
        "02 - Data Transformation - Business Aggregates",
    ]
    for notebook in notebooks:
        fab.deploy_item(
            URL + f"/{notebook}.Notebook",
            workspace_name=workspace_name,
            find_and_replace={
                (
                    r"notebook-content.ipynb",
                    r'("default_lakehouse"\s*:\s*)".*"',
                ): rf'\1"{lakehouse_id}"',
                (
                    r"notebook-content.ipynb",
                    r'("default_lakehouse_name"\s*:\s*)".*"',
                ): rf'\1"{LAKEHOUSE_NAME}"',
                (
                    r"notebook-content.ipynb",
                    r'("default_lakehouse_workspace_id"\s*:\s*)".*"',
                ): rf'\1"{workspace_id}"',
                (
                    r"notebook-content.ipynb",
                    r'("known_lakehouses"\s*:\s*)\[[\s\S]*?\]',
                ): rf'\1[{{"id": "{lakehouse_id}"}}]',
            },
        )
        deployed_count += 1

    # Shortcuts
    fab.run_fab_command(
        f"ln /{workspace_name}.workspace/{LAKEHOUSE_NAME}.lakehouse/Files/{SHORTCUT_NAME}.Shortcut "
        f"--type adlsGen2 "
        f'-i \'{{"location": "https://stfabdemos.dfs.core.windows.net/", '
        f'"subpath": "fabdata/WideWorldImportersDW", '
        f'"connectionId": "{connection_id_adls}"}}\' '
        f"-f"
    )
    deployed_count += 1

    # Job runs
    if not skip_runs:
        fab.run_fab_command(
            f"job run /{workspace_name}.workspace/IngestDataFromSourceToLakehouse.datapipeline"
        )
        fab.run_fab_command(
            f"job run /{workspace_name}.workspace/01 - Create Delta Tables.notebook"
        )
        fab.run_fab_command(
            f"job run /{workspace_name}.workspace/02 - Data Transformation - Business Aggregates.notebook"
        )

    # Metadata for SemanticModel
    lakehouse_conn_string = fab.run_fab_command(
        f"api workspaces/{workspace_id}/lakehouses/{lakehouse_id} -q text.properties.sqlEndpointProperties.connectionString",
        capture_output=True,
    )
    lakehouse_conn_id = fab.run_fab_command(
        f"api workspaces/{workspace_id}/lakehouses/{lakehouse_id} -q text.properties.sqlEndpointProperties.id",
        capture_output=True,
    )

    # SemanticModel
    semanticmodel_id = fab.deploy_item(
        URL + f"/wwilakehousesm.SemanticModel",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"definition/expressions.tmdl",
                r'("XUO7C7SW7ONUHHLEI7JMT7CN3E-5NMTCG4VCUAELMP2UGNFR7CLCI.datawarehouse.fabric.microsoft.com")',
            ): rf'"{lakehouse_conn_string}"',
            (
                r"definition/expressions.tmdl",
                r'("5ec27d10-f4e8-402c-8707-6c54fe94ef5c")',
            ): rf'"{lakehouse_conn_id}"',
        },
    )
    deployed_count += 1

    # Report
    fab.deploy_item(
        URL + f"/ProfitReporting.Report",
        workspace_name=workspace_name,
        find_and_replace={
            ("definition.pbir", r"\{[\s\S]*\}"): json.dumps(
                {
                    "version": "4.0",
                    "datasetReference": {
                        "byConnection": {
                            "connectionString": None,
                            "pbiServiceModelId": None,
                            "pbiModelVirtualServerName": "sobe_wowvirtualserver",
                            "pbiModelDatabaseName": semanticmodel_id,
                            "name": "EntityDataSource",
                            "connectionType": "pbiServiceXmlaStyleLive",
                        }
                    },
                }
            )
        },
    )
    deployed_count += 1

    return deployed_count
