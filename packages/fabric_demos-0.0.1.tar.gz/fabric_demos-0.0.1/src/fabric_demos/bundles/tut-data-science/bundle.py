import json

from fabric_demos.core import constant
from fabric_demos.utils import fab

URL = f"{constant.FABDEMOS_BUNDLES_PATH}/tut-data-science/workspace"
LAKEHOUSE_NAME = "lh_tut_datascience"


def deploy(workspace_name: str, workspace_id: str, skip_runs: bool = False) -> int:
    deployed_count = 0

    # Lakehouse
    lakehouse_id = fab.create_item(
        workspace_name=workspace_name,
        item_type="lakehouse",
        item_name=LAKEHOUSE_NAME,
        parameters={"enableSchemas": "false"},
    )
    deployed_count += 1

    # Notebooks x1
    notebooks = [
        "customer-churn",
    ]
    for notebook in notebooks:
        fab.deploy_item(
            URL + f"/{notebook}.Notebook",
            workspace_name=workspace_name,
            find_and_replace={
                (
                    r"notebook-content.ipynb",
                    r'("default_lakehouse"\s*:\s*)".*"',
                ): rf'\1"{lakehouse_id}"',
                (
                    r"notebook-content.ipynb",
                    r'("default_lakehouse_name"\s*:\s*)".*"',
                ): rf'\1"{LAKEHOUSE_NAME}"',
                (
                    r"notebook-content.ipynb",
                    r'("default_lakehouse_workspace_id"\s*:\s*)".*"',
                ): rf'\1"{workspace_id}"',
                (
                    r"notebook-content.ipynb",
                    r'("known_lakehouses"\s*:\s*)\[[\s\S]*?\]',
                ): rf'\1[{{"id": "{lakehouse_id}"}}]',
            },
        )
        deployed_count += 1

    # Metadata for SemanticModel
    lakehouse_conn_string = fab.run_fab_command(
        f"api workspaces/{workspace_id}/lakehouses/{lakehouse_id} -q text.properties.sqlEndpointProperties.connectionString",
        capture_output=True,
    )
    lakehouse_conn_id = fab.run_fab_command(
        f"api workspaces/{workspace_id}/lakehouses/{lakehouse_id} -q text.properties.sqlEndpointProperties.id",
        capture_output=True,
    )

    # SemanticModel
    semanticmodel_id = fab.deploy_item(
        URL + f"/bank-churn-predictions.SemanticModel",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"definition/expressions.tmdl",
                r'("XUO7C7SW7ONUHHLEI7JMT7CN3E-PIPPMNTPQLHUDNRNHY4CWQJVXQ.datawarehouse.fabric.microsoft.com")',
            ): rf'"{lakehouse_conn_string}"',
            (
                r"definition/expressions.tmdl",
                r'("a22df860-cf94-446e-bbde-ac2ac1eaf0fe")',
            ): rf'"{lakehouse_conn_id}"',
        },
    )
    deployed_count += 1

    # Report
    fab.deploy_item(
        URL + f"/bank-churn-predictions.Report",
        workspace_name=workspace_name,
        find_and_replace={
            ("definition.pbir", r"\{[\s\S]*\}"): json.dumps(
                {
                    "version": "4.0",
                    "datasetReference": {
                        "byConnection": {
                            "connectionString": None,
                            "pbiServiceModelId": None,
                            "pbiModelVirtualServerName": "sobe_wowvirtualserver",
                            "pbiModelDatabaseName": semanticmodel_id,
                            "name": "EntityDataSource",
                            "connectionType": "pbiServiceXmlaStyleLive",
                        }
                    },
                }
            )
        },
    )
    deployed_count += 1

    return deployed_count
