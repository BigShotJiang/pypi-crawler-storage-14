# tut-powerbi

This deploys the Power BI tutorial into your Fabric workspace.

This includes:
- 1 workspace
- 1 copy job
- 1 semantic model
- 1 Power BI report

    
## Notes
See notes below for additional info:

- Dataflow item type was replaced by a copy job. Dataflow uses Lakehouse with OAuth2 as sink, which is not possible to automate now.