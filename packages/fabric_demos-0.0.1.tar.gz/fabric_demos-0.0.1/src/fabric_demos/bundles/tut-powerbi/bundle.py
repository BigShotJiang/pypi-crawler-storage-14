import glob
import json

from fabric_demos.core import constant
from fabric_demos.utils import fab

URL = f"{constant.FABDEMOS_BUNDLES_PATH}/tut-powerbi/workspace"
LAKEHOUSE_NAME = "LH_STORE_RAW"


def deploy(workspace_name: str, workspace_id: str, skip_runs: bool = False) -> int:
    deployed_count = 0

    # Lakehouse
    lakehouse_id = fab.create_item(
        workspace_name=workspace_name,
        item_type="lakehouse",
        item_name=LAKEHOUSE_NAME,
        parameters={"enableSchemas": "true"},
    )
    deployed_count += 1

    # Connections
    connection_source_url = "https://raw.githubusercontent.com/pbi-tools/sales-sample/refs/heads/data/RAW-Sales.csv"
    connection_id = fab.create_connection(
        connection_name=f"con_web_{workspace_name}",
        parameters={
            "connectionDetails.type": "HttpServer",
            "connectionDetails.parameters.url": connection_source_url,
            "credentialDetails.type": "Anonymous",
        },
    )
    deployed_count += 1

    # Pipeline
    fab.deploy_item(
        URL + "/DP_INGST_CopyCSV.DataPipeline",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"pipeline-content.json",
                r'("workspaceId"\s*:\s*)".*"',
            ): rf'\1"{workspace_id}"',
            (
                r"pipeline-content.json",
                r'("artifactId"\s*:\s*)".*"',
            ): rf'\1"{lakehouse_id}"',
            (
                r"pipeline-content.json",
                r'("connection"\s*:\s*)".*"',
            ): rf'\1"{connection_id}"',
        },
    )
    deployed_count += 1

    # Notebook
    fab.deploy_item(
        URL + "/NB_TRNSF_Raw.Notebook",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"notebook-content.ipynb",
                r'("default_lakehouse"\s*:\s*)".*"',
            ): rf'\1"{lakehouse_id}"',
            (
                r"notebook-content.ipynb",
                r'("default_lakehouse_name"\s*:\s*)".*"',
            ): rf'\1"{LAKEHOUSE_NAME}"',
            (
                r"notebook-content.ipynb",
                r'("default_lakehouse_workspace_id"\s*:\s*)".*"',
            ): rf'\1"{workspace_id}"',
            (
                r"notebook-content.ipynb",
                r'("known_lakehouses"\s*:\s*)\[[\s\S]*?\]',
            ): rf'\1[{{"id": "{lakehouse_id}"}}]',
        },
    )
    deployed_count += 1

    # Job runs
    if not skip_runs:
        fab.run_fab_command(
            f"job run /{workspace_name}.workspace/DP_INGST_CopyCSV.DataPipeline"
        )
        fab.run_fab_command(
            f"job run /{workspace_name}.workspace/NB_TRNSF_Raw.Notebook"
        )

    # Metadata for SemanticModel
    lakehouse_conn_string = fab.run_fab_command(
        f"api workspaces/{workspace_id}/lakehouses/{lakehouse_id} -q text.properties.sqlEndpointProperties.connectionString",
        capture_output=True,
    )
    lakehouse_conn_id = fab.run_fab_command(
        f"api workspaces/{workspace_id}/lakehouses/{lakehouse_id} -q text.properties.sqlEndpointProperties.id",
        capture_output=True,
    )

    # SemanticModel
    semanticmodel_id = fab.deploy_item(
        URL + f"/SM_SalesSense.SemanticModel",
        workspace_name=workspace_name,
        find_and_replace={
            (
                r"expressions.tmdl",
                r'(expression\s+Server\s*=\s*)".*?"',
            ): rf'\1"{lakehouse_conn_string}"'
        },
    )
    deployed_count += 1

    # Reports
    for report_path in glob.glob(f"{URL}/*.Report"):
        fab.deploy_item(
            report_path,
            workspace_name=workspace_name,
            find_and_replace={
                ("definition.pbir", r"\{[\s\S]*\}"): json.dumps(
                    {
                        "version": "4.0",
                        "datasetReference": {
                            "byConnection": {
                                "connectionString": None,
                                "pbiServiceModelId": None,
                                "pbiModelVirtualServerName": "sobe_wowvirtualserver",
                                "pbiModelDatabaseName": semanticmodel_id,
                                "name": "EntityDataSource",
                                "connectionType": "pbiServiceXmlaStyleLive",
                            }
                        },
                    }
                )
            },
        )
    deployed_count += 2

    return deployed_count
