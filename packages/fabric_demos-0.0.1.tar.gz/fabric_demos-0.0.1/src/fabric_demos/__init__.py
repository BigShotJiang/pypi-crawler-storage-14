from fabric_demos.commands.demos_browse import exec_command as browse
from fabric_demos.commands.demos_install import exec_command as install
from fabric_demos.commands.demos_remove import exec_command as remove
