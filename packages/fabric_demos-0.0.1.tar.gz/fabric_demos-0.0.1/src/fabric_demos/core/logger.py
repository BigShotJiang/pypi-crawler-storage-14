from fabric_demos.utils import ui


def log_warning(message, command=None):
    ui.print_warning(message, command)
