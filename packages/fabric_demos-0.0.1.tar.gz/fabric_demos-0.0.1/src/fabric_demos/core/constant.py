COMMANDS = {
    "Core Commands": {
        "browse": "Browse available demos.",
        "install": "Install a demo from a repository.",
        "remove": "Remove an installed demo.",
    },
    "Flags": {
        "--help": "Show help for command.",
        "--version": "Show version.",
    },
}

FABDEMOS_YML_FILE = "demos.yml"
FABDEMOS_CAPACITY = "FABDEMOS_CAPACITY"
FABDEMOS_BUNDLES_PATH = "fabric_demos/bundles"
SAS_TOKEN = "sv=2022-11-02&ss=b&srt=co&sp=rlx&se=2026-12-31T18:59:36Z&st=2025-01-31T10:59:36Z&spr=https&sig=aL%2FIOiwz2AEj1fL9tRxH%2B4z%2FyfBl8qJ3KXinfPlaSEM%3D"

# Fabric CLI environment variables
FAB_TOKEN_ENV_VAR = "FAB_TOKEN"
FAB_TOKEN_ONELAKE_ENV_VAR = "FAB_TOKEN_ONELAKE"

# Error codes
ERROR_FAB_COMMAND_FAILED = "FabCommandFailed"
ERROR_INVALID_FORMAT = "InvalidFormat"
ERROR_INVALID_INPUT = "InvalidInput"
ERROR_INVALID_PATH = "InvalidPath"
ERROR_NOT_FOUND = "NotFound"
ERROR_UNEXPECTED_ERROR = "UnexpectedError"

COMMAND_VERSION_DESCRIPTION = "Show version information."
