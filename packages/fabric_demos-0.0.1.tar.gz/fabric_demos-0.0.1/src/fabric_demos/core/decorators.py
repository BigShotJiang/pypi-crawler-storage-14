from functools import wraps

from fabric_cli.core import fab_constant

from fabric_demos.core.exceptions import FabricDemoError
from fabric_demos.utils import ui


def handle_exceptions():
    """
    Decorator that catches FabricDemoError, logs the error, and returns
    an appropriate exit code based on error type.
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except FabricDemoError as e:
                command = getattr(args[0], "command", "unknown")
                ui.print_output_error(
                    e,
                    command,
                )
                # If the error is an unauthorized error, return 4
                if e.status_code == fab_constant.ERROR_UNAUTHORIZED:
                    return fab_constant.EXIT_CODE_AUTHORIZATION_REQUIRED
                # Return a generic error code
                return fab_constant.EXIT_CODE_ERROR

        return wrapper

    return decorator
