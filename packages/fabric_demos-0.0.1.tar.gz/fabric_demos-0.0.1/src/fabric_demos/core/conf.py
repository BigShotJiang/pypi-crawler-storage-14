from pathlib import Path

import yaml

from fabric_demos.core import constant
from fabric_demos.core.exceptions import FabricDemoError


class FabricDemoConfig:
    def __init__(
        self,
        name: str,
        category: str,
        title: str,
        description: str,
        repo_url: str = None,
        branch: str = None,
    ):
        self.name = name
        self.category = category
        self.title = title
        self.description = description
        self.repo_url = repo_url
        self.branch = branch

    @classmethod
    def from_yml(cls, yml_path: str) -> list["FabricDemoConfig"]:
        yml_path = Path(yml_path)
        if not yml_path.exists():
            raise FabricDemoError(
                f"YAML file not found: {yml_path}", constant.ERROR_NOT_FOUND
            )

        with yml_path.open("r", encoding="utf-8") as file:
            data = yaml.safe_load(file)

        demos = data.get("demos", [])
        if not demos:
            raise FabricDemoError(
                "No demos found in the YAML file", constant.ERROR_INVALID_FORMAT
            )

        return [
            cls(
                name=demo.get("name", "Unknown"),
                category=demo.get("category", "Uncategorized"),
                title=demo.get("title", "Untitled"),
                description=demo.get("description", "No description available"),
                repo_url=demo.get("repo_url"),
                branch=demo.get("branch"),
            )
            for demo in demos
        ]
