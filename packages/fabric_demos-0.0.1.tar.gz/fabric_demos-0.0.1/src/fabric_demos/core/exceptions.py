import html


class FabricDemoError(Exception):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.message = message.rstrip(".")
        self.status_code = status_code

    def __str__(self):
        return (
            f"[{self.status_code}] {self.args[0]}"
            if self.status_code
            else f"{self.args[0]}"
        )

    def formatted_message(self, verbose=False):
        escaped_text = html.escape(self.message)

        return (
            f"[{self.status_code}] {escaped_text}"
            if self.status_code
            else f"{escaped_text}"
        )
