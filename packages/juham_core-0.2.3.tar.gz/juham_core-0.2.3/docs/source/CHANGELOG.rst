Changelog
=========



[0.2.1] - November, 22 2025
---------------------------

- Support for supervisor thread added. The thread listens thread crash reports,
  logs them and restarts the crashed threads.


[0.1.7] - November, 15 2025
---------------------------

- Package version number and dependencies updated, no functional changes.


[0.1.6] - October, 31 2025
--------------------------

- Added `elapsed_seconds_in_interval()` to `timeutils`.
- Generalized `elapsed_seconds_in_hour()` and `elapsed_seconds_in_day()` to use the new method.



[0.1.4] - March, 09 2025
------------------------

- ``pyproject.toml`` - dependencies updated


[0.1.1] - March, 03 2025
------------------------

- Redundancy eliminated from the bloated Sphinx conf.py.


[0.0.8] - March, 02 2025
------------------------

- Documentation refactored.


[0.0.5, 0.0.6] - February, 16 2025
----------------------------------

- References to optional plugins removed from the example application ``examples/myapp.py``. 

- Version of the ``masterpiece`` dependency updated.

- ``README.rst`` updated.



[0.0.4] - February, 14 2025
---------------------------

- Time zone bug in timeutils.py fixed.
  

[0.0.3] - January, 25 2025
--------------------------

- **Refactorization:** Class names renamed for consistency.


[0.0.1] - January, 25 2025
--------------------------

- **Initial release:** ``Juham`` base class with MQTT and Timeseries abstraction.

