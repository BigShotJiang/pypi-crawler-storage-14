import json
import os
from pathlib import Path
from typing import Dict, Any, Set, List, Optional, Tuple

# ==============================================================================
# 目录配置 (统一管理)
# ==============================================================================
THREAD_ROOT = Path("threads")
THREAD_INDEX_JSON = THREAD_ROOT / "index.json"
THREAD_INDEX_TXT = THREAD_ROOT / "目录.txt"
MIN_FILE_SIZE = 1024 # 最小有效文件大小

# ==============================================================================
# 目录管理
# ==============================================================================

def update_thread_index(tid: int, title: str):
    """更新帖子ID与标题的映射目录"""
    THREAD_INDEX_JSON.parent.mkdir(parents=True, exist_ok=True)
    
    # 1. Load existing index
    index_map = {}
    if THREAD_INDEX_JSON.exists():
        try:
            with open(THREAD_INDEX_JSON, "r", encoding="utf-8") as f:
                index_map = json.load(f)
        except json.JSONDecodeError:
            index_map = {}
    
    tid_str = str(tid)
    
    # 2. Update map
    if tid_str not in index_map or index_map[tid_str] != title:
        index_map[tid_str] = title
        
        # 3. Save JSON
        with open(THREAD_INDEX_JSON, "w", encoding="utf-8") as f:
            json.dump(index_map, f, ensure_ascii=False, indent=2)
            
        # 4. Save readable TXT
        lines = ["----- 贴吧爬虫帖子目录 -----\n"]
        sorted_keys = sorted(index_map.keys(), key=lambda x: int(x))
        for t_id in sorted_keys:
            t_title = index_map[t_id]
            lines.append(f"帖子ID: {t_id:<12} | 标题: {t_title}\n")
            
        with open(THREAD_INDEX_TXT, "w", encoding="utf-8") as f:
            f.writelines(lines)

def load_index_map() -> Dict[int, str]:
    """加载帖子ID到标题的映射"""
    if THREAD_INDEX_JSON.exists():
        try:
            with open(THREAD_INDEX_JSON, "r", encoding="utf-8") as f:
                return {int(k): v for k, v in json.load(f).items()}
        except Exception:
            pass
    return {}

# ==============================================================================
# Checkpoint 逻辑
# ==============================================================================

def load_checkpoint(tid: int) -> Dict[str, Any]:
    """加载检查点文件，包括最后爬取的页码和已见的帖子ID"""
    f = Path(f"threads/{tid}/checkpoint.json")
    if f.exists():
        try:
            with open(f, "r", encoding="utf-8") as fh:
                data = json.load(fh)
                data['seen_pids'] = set(data.get('seen_pids', []))
                return data
        except:
            pass
    return {"last_page": 0, "seen_pids": set()}

def save_checkpoint(tid: int, last_page: int, seen_pids: Set[int]):
    """保存检查点文件"""
    f = Path(f"threads/{tid}/checkpoint.json")
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(f, "w", encoding="utf-8") as fh:
        json.dump(
            {"last_page": last_page, "seen_pids": list(seen_pids)},
            fh,
            ensure_ascii=False,
            indent=2
        )

# ==============================================================================
# 帖子目录信息获取 (用于 CLI list/convert)
# ==============================================================================

def get_thread_info_from_crawl(tid: int, index_map: Dict[int, str]) -> Optional[Tuple[int, str]]:
    """尝试从爬虫数据中获取帖子的最大页数和标题。"""
    TID_DIR = Path(f"threads/{tid}")
    
    title = index_map.get(tid, f"帖子 {tid} (无标题)")
    last_page = 0
    checkpoint_file = TID_DIR / "checkpoint.json"
    
    if checkpoint_file.exists():
        try:
            with open(checkpoint_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                last_page = data.get('last_page', 0)
        except:
            pass
    
    if last_page == 0 and (TID_DIR / "posts").exists():
        try:
            json_files = list((TID_DIR / "posts").glob("page_*.json"))
            if json_files:
                last_page = max(int(f.stem.split('_')[1]) for f in json_files)
        except:
            pass
    
    if last_page == 0:
        return None
    
    return last_page, title

def list_crawled_threads() -> List[Dict[str, Any]]:
    """列出所有已爬取帖子的信息 (tid, title, last_page, path)"""
    
    if not THREAD_ROOT.exists():
        return []
        
    dirs = [d for d in THREAD_ROOT.iterdir() if d.is_dir() and d.name.isdigit()]
    if not dirs:
        return []

    index_map = load_index_map()
    thread_data = []

    for d in dirs:
        tid_str = d.name
        try:
            tid = int(tid_str)
        except ValueError:
            continue
            
        info = get_thread_info_from_crawl(tid, index_map)
        
        if info:
            max_page, title = info
            # 只有 max_page > 0 且 posts 目录下有文件才认为是有效数据
            if max_page > 0 and any((d / "posts").glob("page_*.json")):
                thread_data.append({
                    'tid': tid,
                    'title': title,
                    'last_page': max_page,
                    'path': str(d)
                })
                
    thread_data.sort(key=lambda x: int(x['tid']))
    return thread_data