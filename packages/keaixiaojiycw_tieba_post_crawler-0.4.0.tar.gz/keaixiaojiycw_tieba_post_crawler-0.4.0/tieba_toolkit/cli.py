import argparse
import asyncio
import os
import sys

# 导入内部模块
from .crawler import TiebaCrawler, list_crawled_threads
from .converter import convert_to_html
from .utils import load_index_map 

def main():
    """主命令行入口函数。"""
    parser = argparse.ArgumentParser(
        description="贴吧一体化爬取与数据处理系统。\n\n请先设置环境变量：export TIEBA_BDUSS=\"你的BDUSS\"",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    # -----------------------------------------------------
    # 1. 检查 BDUSS
    # -----------------------------------------------------
    bduss = os.environ.get("TIEBA_BDUSS")
    if bduss is None:
        print("错误：请先设置 TIEBA_BDUSS 环境变量。")
        sys.exit(1)

    # -----------------------------------------------------
    # 2. 创建子命令 
    # -----------------------------------------------------
    subparsers = parser.add_subparsers(dest='command', required=True, help='可用操作命令')

    # A. crawl 命令
    crawl_parser = subparsers.add_parser('crawl', help='爬取贴吧帖子。')
    crawl_parser.add_argument('tid', type=int, help='要爬取的帖子 ID。')
    
    # B. convert 命令
    convert_parser = subparsers.add_parser('convert', help='将已爬取数据转换为 HTML 查看器。')
    convert_parser.add_argument('tid', type=int, help='要转换的帖子 ID。')
    convert_parser.add_argument('--start', type=int, default=1, help='转换的起始页码 (默认为 1)。')
    convert_parser.add_argument('--end', type=int, help='转换的结束页码 (默认为已爬取的最大页)。')

    # C. list 命令
    subparsers.add_parser('list', help='列出已爬取的所有帖子信息。')
    
    args = parser.parse_args()
    
    # -----------------------------------------------------
    # 3. 执行逻辑
    # -----------------------------------------------------
    
    if args.command == 'crawl':
        crawler = TiebaCrawler(bduss=bduss)
        asyncio.run(crawler.crawl_thread(args.tid))
        
    elif args.command == 'convert':
        threads_info = list_crawled_threads()
        target_tid = args.tid
        
        info = next((t for t in threads_info if t['tid'] == target_tid), None)
        
        if info:
            max_crawled_page = info['last_page']
            
            index_map = load_index_map()
            title = index_map.get(target_tid, info.get('title', f"帖子 {target_tid}"))
            
            end_page = args.end if args.end is not None else max_crawled_page
            
            if not (1 <= args.start <= end_page <= max_crawled_page):
                 print(f"错误：转换页码范围无效或超出已爬取范围 (1 - {max_crawled_page})。")
                 print(f"您输入的范围是: {args.start} - {end_page}")
                 sys.exit(1)
            
            # max_page 传入已爬取的最大页，用于 UI 显示总页数
            convert_to_html(target_tid, title, args.start, end_page, max_crawled_page)
        else:
            print(f"错误: 找不到 ID 为 {target_tid} 的帖子数据。请先运行 'tieba-crawler crawl {target_tid}'。")
            
    elif args.command == 'list':
        threads = list_crawled_threads()
        if not threads:
            print("未找到已爬取的帖子数据。")
            return

        print("\n" + "=" * 60)
        print(" ID           | Title (截断)             | 已爬页数")
        print("=" * 60)
        for t in threads:
            display_title = t['title'][:25] + ('...' if len(t['title']) > 25 else '')
            print(f"{t['tid']:<12} | {display_title:<25} | {t['last_page']:<8}")
        print("=" * 60)

if __name__ == '__main__':
    main()