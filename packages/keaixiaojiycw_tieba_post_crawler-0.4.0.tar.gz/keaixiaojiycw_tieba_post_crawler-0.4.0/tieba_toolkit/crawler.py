# -*- coding: utf-8 -*-

import asyncio
import aiofiles
import aiohttp
import json
import logging
import time
from pathlib import Path
from typing import Optional, Set, Dict, Any, List

import aiotieba as tb
from aiotieba.logging import get_logger as LOG

########################################
# 配置区
########################################

# 移除了全局 BDUSS 变量，现在 BDUSS 应该由 cli.py 从环境变量获取并传入 dump_thread 函数

IMAGE_WORKERS = 8
REQUEST_RETRIES = 5
RETRY_BASE_DELAY = 1.0
MAX_CONSECUTIVE_FAILURES = 3

# 续爬时，程序会重新检查并更新最后 N 页的内容
REVISIT_LAST_PAGES = 3

logging.basicConfig(
    level=logging.INFO, # 调整为 INFO 级别以减少控制台输出
    format="<%(asctime)s> [%(levelname)s] [%(name)s] %(message)s",
)

# 最小有效文件大小（字节）
MIN_FILE_SIZE = 1024

# 目录文件路径
# --- FIX 1: ADD MISSING THREAD_ROOT DEFINITION (解决 NameError) ---
THREAD_ROOT = Path("threads") 

THREAD_INDEX_JSON = THREAD_ROOT / "index.json"
THREAD_INDEX_TXT = THREAD_ROOT / "目录.txt"

########################################
# 目录管理
########################################

def update_thread_index(tid: int, title: str):
    """更新帖子ID与标题的映射目录"""
    THREAD_INDEX_JSON.parent.mkdir(parents=True, exist_ok=True)
    
    # 1. Load existing index
    index_map = {}
    if THREAD_INDEX_JSON.exists():
        try:
            with open(THREAD_INDEX_JSON, "r", encoding="utf-8") as f:
                index_map = json.load(f)
        except json.JSONDecodeError:
            LOG().warning("Failed to decode existing index.json. Creating new one.")
            index_map = {}
    
    tid_str = str(tid)
    
    # 2. Update map
    # 只有标题有变化时才写入
    if tid_str not in index_map or index_map[tid_str] != title:
        index_map[tid_str] = title
        
        # 3. Save JSON
        with open(THREAD_INDEX_JSON, "w", encoding="utf-8") as f:
            json.dump(index_map, f, ensure_ascii=False, indent=2)
            
        # 4. Save readable TXT
        lines = ["----- 贴吧爬虫帖子目录 -----\n"]
        # 按照 TID 排序以便于阅读
        sorted_keys = sorted(index_map.keys(), key=lambda x: int(x))
        for t_id in sorted_keys:
            t_title = index_map[t_id]
            lines.append(f"帖子ID: {t_id:<12} | 标题: {t_title}\n")
            
        with open(THREAD_INDEX_TXT, "w", encoding="utf-8") as f:
            f.writelines(lines)
            
        LOG().info(f"Updated thread index for TID {tid}: {title}")

########################################
# 工具函数
########################################

def extract_images(contents) -> list:
    """从 contents 中提取图片列表"""
    if not contents:
        return []
    return getattr(contents, "imgs", [])

def build_img_url(img) -> Optional[str]:
    """生成图片 URL：优先使用原图 origin_src"""
    origin_src = getattr(img, "origin_src", None)
    if origin_src:
        return origin_src
    
    big_src = getattr(img, "big_src", None)
    if big_src:
        return big_src

    src = getattr(img, "src", None)
    if src:
        return src
        
    return None

async def http_get_with_retries(session: aiohttp.ClientSession, url: str,
                                retries: int = REQUEST_RETRIES) -> Optional[bytes]:
    delay = RETRY_BASE_DELAY
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url, timeout=30) as resp:
                if resp.status == 200:
                    return await resp.read()
                elif resp.status in (429, 503):
                    LOG().warning(
                        f"HTTP {resp.status} (Rate limit/Service unavailable) for {url} attempt {attempt}/{retries}, backoff {delay:.1f}s"
                    )
                else:
                    LOG().error(f"HTTP {resp.status} for {url}")
                    return None
        except Exception as e:
            LOG().warning(f"GET {url} failed attempt {attempt}/{retries}: {e.__class__.__name__} - {e}")

        await asyncio.sleep(delay)
        delay *= 2

    LOG().error(f"Exhausted retries for {url}")
    return None

async def download_image_worker(queue: "asyncio.Queue[tuple[str, Path]]",
                                session: aiohttp.ClientSession):
    while True:
        item = await queue.get()
        if item is None:
            queue.task_done()
            break

        url, save_path = item
        try:
            # 检查文件大小，防止跳过损坏或空文件 (阈值设为 1024 字节)
            if save_path.exists() and save_path.stat().st_size > MIN_FILE_SIZE:
                continue
            
            data = await http_get_with_retries(session, url)
            if data:
                save_path.parent.mkdir(parents=True, exist_ok=True)
                async with aiofiles.open(save_path, "wb") as f:
                    await f.write(data)
            else:
                LOG().error(f"Failed to download image: {url}")
        except Exception as e:
            LOG().exception(f"Image worker error: {e}")
        finally:
            # 确保无论是跳过、成功下载还是下载失败，都只在此处标记任务完成
            queue.task_done()

########################################
# Checkpoint 逻辑
########################################

def load_checkpoint(tid: int) -> Dict[str, Any]:
    f = THREAD_ROOT / str(tid) / "checkpoint.json"
    if f.exists():
        try:
            return json.load(open(f, "r", encoding="utf-8"))
        except:
            pass
    return {"last_page": 0, "seen_pids": []}

def save_checkpoint(tid: int, last_page: int, seen_pids: Set[int]):
    f = THREAD_ROOT / str(tid) / "checkpoint.json"
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(f, "w", encoding="utf-8") as fh:
        json.dump(
            {"last_page": last_page, "seen_pids": list(seen_pids)},
            fh,
            ensure_ascii=False,
        )

########################################
# JSON 持久化 (支持三种格式)
########################################

def _get_local_img_name(idx: int, p=None, c=None, is_main_post: bool = False) -> str:
    """生成图片本地文件名"""
    
    if is_main_post and p:
        pid = getattr(p, "pid", "unknown_pid")
        return f"楼层_1_{pid}_图片{idx}.jpg"
    
    if c: # 楼中楼评论
        parent_pid = getattr(c, 'orig_pid', 'unknown_p')
        c_pid = getattr(c, 'pid', 'unknown_c')
        return f"楼中楼_{parent_pid}_{c_pid}_图片{idx}.jpg"
    
    if p: # 楼层回复 (非主贴)
        floor_num = getattr(p, "floor", 0)
        pid = getattr(p, "pid", 0)
        return f"楼层_{floor_num}_{pid}_图片{idx}.jpg"
        
    return f"unknown_img_{idx}.jpg"

async def _serialize_item(item, json_type: str = 'llm'):
    """
    序列化单个帖子或评论。
    """
    
    text = getattr(item, "text", "")
    if not text and hasattr(item, "contents"):
        text = getattr(item.contents, "text", "")
        
    user = getattr(item, "user", None)
    
    data = {
        "pid": getattr(item, "pid", None),
        "tid": getattr(item, "tid", None),
        "user_name": getattr(user, "user_name", None) if user else None,
        "user_id": getattr(user, "user_id", None) if user else None,
        "text": text,
        "time": getattr(item, "create_time", 0),
        "image_links": [],
        "img_urls_original": [],
    }
    
    is_comment = hasattr(item, 'orig_pid')
    data['is_comment'] = is_comment
    data['parent_pid'] = getattr(item, 'orig_pid', None) if is_comment else None
    
    floor_num = getattr(item, 'floor', 0)
    data['floor'] = floor_num
    is_main_post = (floor_num == 1 and not is_comment)
    
    contents = getattr(item, "contents", None)
    imgs_raw = extract_images(contents)
    
    for i, img in enumerate(imgs_raw, 1):
        url = build_img_url(img)
        if url:
            data["img_urls_original"].append(url)
            if json_type == 'html':
                if is_comment:
                    local_name = _get_local_img_name(i, c=item)
                else: 
                    local_name = _get_local_img_name(i, p=item, is_main_post=is_main_post)
                
                data["image_links"].append(f"images/{local_name}")
            else:
                data["image_links"].append(url)
                
    return data

async def save_page_json_list(tid: int, page_num: int, posts_list):
    """保存 page_xxxx.json (用于 HTML 转换, 图片链接指向本地)"""
    JSON_DIR = THREAD_ROOT / str(tid) / "posts"
    JSON_DIR.mkdir(parents=True, exist_ok=True)

    payload = []
    for p in posts_list:
        try:
            post_data = await _serialize_item(p, json_type='html')
            # 只有内容不为空的帖子才会被视为有效负载
            if post_data.get('pid') and (post_data.get('text') or post_data.get('image_links')):
                payload.append(post_data)
        except Exception as e:
            LOG().warning(f"Post serialize (html) failed pid={getattr(p, 'pid', 'unknown')}: {e}")

    # 【v3.4.4 优化点】如果序列化后的有效数据为空，则不创建文件，并使用 WARNING 明确提示
    if not payload:
        LOG().warning(f"Page {page_num} contains no valid posts. SKIPPING file creation (page_{page_num:04d}.json).")
        return

    async with aiofiles.open(JSON_DIR / f"page_{page_num:04d}.json",
                             "w",
                             encoding="utf-8") as f:
        await f.write(json.dumps(payload, ensure_ascii=False, indent=2))

async def append_to_jsonl(tid: int, items_list):
    """追加到 tid_dump.jsonl (用于 LLM, 图片链接指向原始 URL)"""
    JSONL_FILE = THREAD_ROOT / str(tid) / f"{tid}_dump.jsonl"
    JSONL_FILE.parent.mkdir(parents=True, exist_ok=True)

    async with aiofiles.open(JSONL_FILE, "a", encoding="utf-8") as f:
        for item in items_list:
            try:
                item_data = await _serialize_item(item, json_type='llm')
                # 移除 img_urls_original 字段，仅在 page_xxxx.json 中保留
                item_data.pop("img_urls_original", None)
                await f.write(json.dumps(item_data, ensure_ascii=False) + '\n')
            except Exception as e:
                LOG().warning(f"JSONL serialize failed pid={getattr(item, 'pid', 'unknown')}: {e}")

async def requeue_missing_images(tid: int, last_page: int, 
                                 img_queue: "asyncio.Queue[tuple[str, Path]]"):
    """
    检查已保存的 JSON 文件中的图片，将丢失或不完整的图片重新加入下载队列。
    """
    JSON_DIR = THREAD_ROOT / str(tid) / "posts"
    IMAGE_DIR = THREAD_ROOT / str(tid) / "images"
    
    LOG().info(f"Checking images for pages 1 to {last_page}...")
    requeued_count = 0
    
    for page_num in range(1, last_page + 1):
        json_file = JSON_DIR / f"page_{page_num:04d}.json"
        if not json_file.exists():
            continue
            
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                page_data = json.load(f)
                
            for item in page_data:
                # item["image_links"] 是本地相对路径，item["img_urls_original"] 是原始 URL
                local_links = item.get("image_links", [])
                original_urls = item.get("img_urls_original", [])
                
                min_len = min(len(local_links), len(original_urls))
                
                for i in range(min_len):
                    local_rel_path = local_links[i]
                    original_url = original_urls[i]
                    
                    save_path = IMAGE_DIR / Path(local_rel_path).name
                    
                    # 检查本地文件是否存在且大于最小尺寸
                    if not (save_path.exists() and save_path.stat().st_size > MIN_FILE_SIZE):
                        await img_queue.put((original_url, save_path))
                        requeued_count += 1
                        
        except Exception as e:
            LOG().warning(f"Error reading or processing {json_file.name} for image re-queue: {e}")

    if requeued_count > 0:
        LOG().info(f"Re-queued {requeued_count} missing/incomplete images from previous pages.")

########################################
# 主爬虫
########################################

# --- 修改函数签名，接受 bduss 参数 (从 cli.py 传入) ---
async def dump_thread(tid: int, bduss: str, max_pages: int = 2400):
    
    OUTPUT_TXT = THREAD_ROOT / str(tid) / f"{tid}_dump.txt"
    IMAGE_DIR = THREAD_ROOT / str(tid) / "images"
    JSONL_FILE = THREAD_ROOT / str(tid) / f"{tid}_dump.jsonl"

    OUTPUT_TXT.parent.mkdir(parents=True, exist_ok=True)
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)

    checkpoint = load_checkpoint(tid)
    start_page = checkpoint.get("last_page", 0) + 1
    seen_pids: Set[int] = set(checkpoint.get("seen_pids", []))
    LOG().info(f"--- Crawl Start: TID {tid} ---")
    LOG().info(f"Resume from page {start_page}, already seen PIDs={len(seen_pids)}")

    if start_page == 1:
        if OUTPUT_TXT.exists(): OUTPUT_TXT.unlink()
        if JSONL_FILE.exists(): JSONL_FILE.unlink()

    img_queue: "asyncio.Queue[tuple[str, Path]]" = asyncio.Queue()
    workers = []
    consecutive_failures = 0
    
    # --- 核心改动 1：使用 async with 确保 Client 和 Session 被正确关闭 ---
    async with aiohttp.ClientSession() as http_session, tb.Client(fname="tieba-toolkit") as client:
        # --- FIX 2: Manually add BDUSS cookie to client session (解决 TypeError: bduss) ---
        if bduss:
            client.add_cookie('BDUSS', bduss)

        try:
            for _ in range(IMAGE_WORKERS):
                workers.append(asyncio.create_task(download_image_worker(img_queue, http_session)))
                
            # ========================================================
            # 核心逻辑封装：抓取并处理单个页面
            # ========================================================
            async def _fetch_and_process_page(page: int, is_revisit: bool) -> tuple[Optional[List], bool]:
                """
                抓取一个页面，处理数据，并返回帖子列表和 has_more 状态。
                """
                nonlocal consecutive_failures 

                LOG().info(f"{'[REVISIT]' if is_revisit else ''} Fetching page {page}...")
                posts = None
                success = False
                
                # --- API 调用和重试 ---
                for attempt in range(3):
                    try:
                        posts = await client.get_posts(tid, pn=page, with_comments=True)
                        
                        if posts.err is not None:
                            LOG().warning(f"API Error page={page}: {posts.err}")
                            
                            # >>> 修正后的 429 检查 1: 贴吧应用层错误码 (posts.err是Tuple) <<<
                            if isinstance(posts.err, tuple) and posts.err[0] == 429:
                                LOG().info(f"Rate limit detected (App Error). Applying extended backoff.")
                                # 10秒起步的指数退避：10s, 20s, 40s
                                await asyncio.sleep(10.0 * (2 ** attempt)) 
                                continue # 跳过下面的默认 sleep，直接进行下一次尝试
                            # ------------------------------------------------
                        else:
                            success = True
                            break 
                    except Exception as e:
                        LOG().warning(f"Network error page={page} attempt={attempt}: {e}")

                        # >>> 修正后的 429 检查 2: 网络/HTTP 层异常 (如 HTTPStatusError) <<<
                        # 使用 getattr 安全地访问 status 属性，解决 'HTTPStatusError' object is not subscriptable 问题
                        if getattr(e, 'status', 0) == 429:
                            LOG().info(f"Rate limit (HTTP Status) detected in attempt {attempt}. Applying extended backoff.")
                            await asyncio.sleep(10.0 * (2 ** attempt)) 
                            continue # 继续重试循环

                    await asyncio.sleep(RETRY_BASE_DELAY * (2 ** attempt))

                # --- 失败处理 ---
                if not success or posts is None:
                    if not is_revisit: 
                        consecutive_failures += 1
                    return (None, True) 
                
                if not is_revisit:
                    consecutive_failures = 0

                # >>> 新增日志：成功获取页面的原始数据统计 <<<
                LOG().info(f"Page {page} fetched successfully. Total posts in raw response: {len(posts.objs)} (has_more: {posts.has_more})")
                
                # --- 判空处理 (aiotieba返回空列表时，直接跳过所有处理) ---
                if not posts.objs: 
                    return (None, posts.has_more) 

                # --- 核心数据处理 (帖子有内容) ---
                
                # [FIX v3.4.5] 1. 过滤帖子列表，防止将重复帖子（如末页的主楼复制）写入 JSON
                posts_for_json_save = [p for p in posts.objs if p.pid not in seen_pids]
                
                # >>> 新增日志：新内容统计 <<<
                LOG().info(f"Page {page}: {len(posts_for_json_save)} new posts/comments found in raw response.")

                # 2. 保存 JSON (无论重访还是新爬都需要) - 内部已检查payload是否为空
                # 传入过滤后的列表。如果 posts_for_json_save 为空，save_page_json_list 将跳过文件创建。
                await save_page_json_list(tid, page, posts_for_json_save)
                
                items_to_jsonl = [] 

                # 3. TXT 头部 (仅全新开始时处理 Page 1 的主贴信息)
                # 这里的逻辑必须使用 posts.objs (未经筛选的原始数据)
                if page == 1 and start_page == 1 and not is_revisit: 
                    thread_obj = posts.thread 
                    main_post_obj = posts.objs[0] 
                    
                    # --- 更新目录文件 ---
                    update_thread_index(tid, thread_obj.title)
                    # -----------------------------
                    
                    async with aiofiles.open(OUTPUT_TXT, "w", encoding="utf-8") as tx:
                        await tx.write("===== 主贴内容 =====\n")
                        await tx.write(f"标题: {thread_obj.title}\n")
                        
                        author_name = main_post_obj.user.user_name if main_post_obj.user else "未知"
                        await tx.write(f"作者: {author_name}\n")
                        await tx.write(f"内容: {thread_obj.text}\n\n")

                        if main_post_obj.contents:
                            main_imgs = extract_images(main_post_obj.contents)
                            for i, img in enumerate(main_imgs, 1):
                                url = build_img_url(img)
                                if url:
                                    local_name = _get_local_img_name(i, p=main_post_obj, is_main_post=True)
                                    await tx.write(f"图片URL[{i}]: {url} -> [本地路径: {IMAGE_DIR.name}/{local_name}]\n")
                                    
                        await tx.write("\n===== 回复区 =====\n")

                # 4. 追加回复内容到 TXT 和 JSONL (包括排队图片下载)
                # 这里的逻辑必须使用 posts.objs (未经筛选的原始数据)
                new_post_count = 0
                new_comment_count = 0
                
                async with aiofiles.open(OUTPUT_TXT, "a", encoding="utf-8") as tx:
                    for p in posts.objs: 
                        pid = p.pid
                        
                        is_new_post = pid not in seen_pids 
                        if is_new_post:
                            seen_pids.add(pid)
                            items_to_jsonl.append(p)
                            new_post_count += 1
                        
                        floor_num = getattr(p, "floor", 0)
                        p_user_name = p.user.user_name if p.user else "未知"
                        is_main_post = (floor_num == 1 and page == 1)

                        if is_new_post:
                            await tx.write("-" * 30 + "\n")
                            await tx.write(f"[楼层] {floor_num}楼 pid={pid}\n")
                            await tx.write(f"用户: {p_user_name}\n")
                            
                            if not is_main_post: 
                                await tx.write(f"内容: {p.text}\n")

                        # 楼层图片排队下载
                        imgs = extract_images(p.contents)
                        for i, img in enumerate(imgs, 1):
                            url = build_img_url(img)
                            if url:
                                local_name = _get_local_img_name(i, p=p, is_main_post=is_main_post)
                                
                                if is_new_post and not is_main_post:
                                    await tx.write(f"图片URL[{i}]: {url} -> [本地路径: {IMAGE_DIR.name}/{local_name}]\n")
                                    
                                await img_queue.put((url, IMAGE_DIR / local_name))

                        # 楼中楼
                        comments = p.comments 
                        for c in comments:
                            cpid = c.pid
                            is_new_comment = cpid not in seen_pids
                            
                            if is_new_comment:
                                seen_pids.add(cpid)
                                items_to_jsonl.append(c)
                                new_comment_count += 1

                                c_user_name = c.user.user_name if c.user else "未知"
                                await tx.write(f"  [评论] {c_user_name}: {c.text}\n")
                            
                                # 楼中楼图片排队下载
                                cimgs = extract_images(c.contents)
                                for i, img in enumerate(cimgs, 1):
                                    url = build_img_url(img)
                                    if url:
                                        local_name = _get_local_img_name(i, c=c)
                                        await tx.write(f"  图片URL[{i}]: {url} -> [本地路径: {IMAGE_DIR.name}/{local_name}]\n")
                                        await img_queue.put((url, IMAGE_DIR / local_name))

                # 5. 追加到 JSONL 文件 (只写入新增的内容)
                await append_to_jsonl(tid, items_to_jsonl)
                
                # >>> 新增日志：写入 JSONL 统计 <<<
                LOG().info(f"Page {page} processed: {new_post_count} new posts, {new_comment_count} new comments added to JSONL/TXT.")

                return (posts.objs, posts.has_more)
            
            # ========================================================
            # 续爬/重访逻辑
            # ========================================================
            if start_page > 1:
                last_crawled_page = start_page - 1
                await requeue_missing_images(tid, last_crawled_page, img_queue) 

                revisit_start_page = max(1, last_crawled_page - REVISIT_LAST_PAGES + 1)
                
                LOG().info(f"Starting revisit mode for pages {revisit_start_page} to {last_crawled_page} to check for new replies...")
                
                for page in range(revisit_start_page, start_page):
                    posts_objs, has_more = await _fetch_and_process_page(page, is_revisit=True)
                    
                    if posts_objs is None:
                        LOG().warning(f"Revisit page {page} failed or resulted in error.")
                
                LOG().info("Revisit mode finished. Starting main crawl.")


            # ========================================================
            # 主爬取循环（获取新页面）
            # ========================================================
            for page in range(start_page, max_pages + 1):
                
                posts_objs, has_more = await _fetch_and_process_page(page, is_revisit=False)

                if posts_objs is None:
                    # API调用失败或API返回了空的 posts.objs
                    if not has_more:
                        # 线程末尾页
                        LOG().info(f"Page {page} is empty, and server indicates no more pages. Stopping crawl. (Last checkpoint is Page {page-1})")
                        break 
                    else: 
                        # API调用失败或临时空页
                        if consecutive_failures > 0:
                            LOG().error(f"Page {page} failed. Consecutive failures: {consecutive_failures}")
                            if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                                save_checkpoint(tid, page - 1, seen_pids)
                                LOG().error(f"--- Crawl Paused: Max failures reached. Checkpoint saved: Page {page-1} (Total PIDs seen: {len(seen_pids)}) ---")
                                break
                            continue
                        # 临时空页
                        LOG().info(f"Page {page} is empty, but server indicates more pages exist. Saving checkpoint and skipping empty page.")
                        save_checkpoint(tid, page, seen_pids)
                        LOG().info(f"--- Checkpoint saved: Page {page} (Total PIDs seen: {len(seen_pids)}) ---")
                        continue

                # --- 成功处理完成后保存检查点 ---
                save_checkpoint(tid, page, seen_pids)
                # >>> 新增日志：检查点保存确认 <<<
                LOG().info(f"--- Checkpoint saved: Page {page} (Total PIDs seen: {len(seen_pids)}) ---")
                
                if not has_more:
                    LOG().info("No more pages.")
                    break

        finally:
            # --- 爬取循环结束，开始等待所有图片下载任务完成 ---
            
            LOG().info("All pages fetched. Shutting down image workers...")
            for _ in workers:
                await img_queue.put(None)
                
            await img_queue.join()
            
            for w in workers:
                w.cancel()
            
    # 因为使用了 async with，Client 和 Session 的清理（__aexit__）会在退出时自动完成。
    LOG().info(f"--- Crawl Finished: TID {tid} ---")

########################################
# 菜单 (已移除所有主流程交互函数，它们应该在 cli.py 中)
########################################

# 确保 cli.py 能够正常导入
# 您的 cli.py 应该包含以下逻辑：
# 1. 从环境变量获取 bduss
# 2. 调用 asyncio.run(dump_thread(tid, bduss))