# CERT UEFI Support Library

This is a python library that wraps a bunch of third-party
decompression libraries for use in parsing UEFI files.
