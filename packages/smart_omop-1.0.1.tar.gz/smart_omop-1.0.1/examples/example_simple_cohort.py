"""
Simple Cohort Building Example

Demonstrates creating cohorts using the simple CohortBuilder interface:
- Basic condition-based cohort
- Age and gender filters
- Creating cohort on WebAPI

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from smart_omop import CohortBuilder, Gender, OMOPClient

# Replace with your WebAPI URL
BASE_URL = "http://your-webapi:8080/WebAPI"

def main():
    # Build simple cohort
    builder = CohortBuilder("COPD Patients", "COPD diagnosis cohort")
    builder.with_condition("COPD", [255573, 40481087])
    builder.with_age_range(min_age=40)
    builder.with_gender(Gender.FEMALE)

    cohort_def = builder.build()

    print(f"Cohort: {cohort_def.name}")
    print(f"Description: {cohort_def.description}")

    # Create on WebAPI
    with OMOPClient(BASE_URL) as client:
        created = client.create_cohort(cohort_def.to_dict())
        print(f"\nCohort created with ID: {created['id']}")


if __name__ == "__main__":
    main()
