"""
Visualizations Example

Demonstrates creating interactive visualizations for cohort data:
- Age pyramid by gender
- Condition prevalence treemap
- Cohort dashboard

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from smart_omop import CohortVisualizer

def main():
    visualizer = CohortVisualizer(output_dir="./viz")

    # Age distribution
    age_data = {
        'male': [45, 52, 61, 67, 72, 58, 63, 69, 74, 55],
        'female': [48, 55, 59, 64, 70, 75, 62, 68, 73, 57]
    }
    age_path = visualizer.create_age_pyramid(age_data)
    print(f"Age pyramid created: {age_path}")

    # Condition prevalence
    condition_counts = {
        '255573': 100,  # COPD
        '316866': 45    # Hypertension
    }
    condition_names = {
        '255573': 'COPD',
        '316866': 'Hypertension'
    }
    treemap_path = visualizer.create_condition_treemap(condition_counts, condition_names)
    print(f"Condition treemap created: {treemap_path}")

    # Dashboard
    cohort_data = {
        'definition': {'name': 'COPD Cohort'},
        'results': {
            'personCount': 100,
            'recordCount': 100,
            'status': 'COMPLETE'
        }
    }
    dashboard_path = visualizer.create_dashboard(cohort_data)
    print(f"Dashboard created: {dashboard_path}")

    print("\nOpen HTML files in browser to view interactive charts")


if __name__ == "__main__":
    main()
