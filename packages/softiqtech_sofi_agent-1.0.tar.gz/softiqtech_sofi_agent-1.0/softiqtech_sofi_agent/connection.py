from agents import OpenAIChatCompletionsModel, RunConfig
from openai import AsyncOpenAI
from dotenv import load_dotenv
import os

load_dotenv()

gemini_api_key = os.getenv("GEMINI_API_KEY")

print("Gemini API Key:", gemini_api_key )

if not gemini_api_key:
    raise ValueError("Gemini API key must be present in the .env file")

client = AsyncOpenAI(
    api_key=gemini_api_key,
    base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
    timeout=30,
)


model = OpenAIChatCompletionsModel(
    model="gemini-2.5-flash-lite",
    openai_client= client
)

config = RunConfig(
    model=model,
    model_provider=client, # type: ignore
    tracing_disabled= True
)