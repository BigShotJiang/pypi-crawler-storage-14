import json
import os

FILE_PATH = "project_data.json"

def load_data():
    """Read JSON file"""
    if not os.path.exists(FILE_PATH):
        return {"completed_projects": {},
                "ongoing_projects": {},
                "upcoming_projects": {}
        }
    
    with open(FILE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data: dict):
    """Write JSON file"""
    with open(FILE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
