# setup.py
from setuptools import setup, find_packages
from pathlib import Path

README = Path("README.md").read_text(encoding="utf-8")

setup(
    name="softiqtech_sofi_agent",          # PyPI package name (what pip will install)
    version="1.0",
    author="SoftiqTech",
    author_email="infosoftiqtech@gmail.com",
    description="A FastAPI + Next.js website agent shipped as a pip package",
    long_description=README,
    long_description_content_type="text/markdown",
    packages=find_packages(exclude=("tests", "frontend_build")),
    include_package_data=True,  # include files specified in MANIFEST.in
    package_data={
        # if you want to include a frontend build inside the Python package:
        "softiqtech_sofi_agent": [
            "frontend_build/*",
            "frontend_build/**/*",
            "project_data.json"
        ],
    },
    install_requires=[
        "fastapi>=0.95.0",
        "uvicorn>=0.20.0",
        "openai-agents"
        # add other dependencies your code needs
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
