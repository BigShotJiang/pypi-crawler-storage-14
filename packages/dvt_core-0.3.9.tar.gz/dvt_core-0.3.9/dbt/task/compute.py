"""
Compute Task

Handles DVT compute engine management commands:
- list: List all registered compute engines
- register: Register a new compute engine
- test: Test connection to a compute engine
- remove: Remove a compute engine
"""

import sys
from pathlib import Path
from typing import Any, Dict, Optional

from dbt.config.compute import ComputeRegistry, SparkPlatform
from dbt_common.exceptions import DbtRuntimeError


class ComputeTask:
    """Task for managing DVT compute engines."""

    def __init__(self, project_dir: Optional[str] = None):
        """
        Initialize ComputeTask.

        :param project_dir: Path to project root directory (defaults to current directory)
        """
        self.project_dir = project_dir or str(Path.cwd())
        self.registry = ComputeRegistry(self.project_dir)

    def list_computes(self) -> None:
        """List all registered compute engines."""
        clusters = self.registry.list()

        if not clusters:
            print("No compute engines registered.")
            print(
                f"\nInitialize defaults: Edit {self.registry.compute_file} "
                "or use 'dvt compute register'"
            )
            return

        print("\nRegistered Compute Engines:")
        print("-" * 80)
        print(
            f"{'Name':<20} {'Type':<10} {'Platform':<15} {'Description':<30} {'Cost/Hr':<10}"
        )
        print("-" * 80)

        for cluster in clusters:
            platform = cluster.detect_platform().value
            description = cluster.description or "N/A"
            cost = f"${cluster.cost_per_hour:.2f}" if cluster.cost_per_hour else "N/A"

            print(
                f"{cluster.name:<20} {cluster.type:<10} {platform:<15} "
                f"{description[:30]:<30} {cost:<10}"
            )

        print("-" * 80)
        print(f"Default target: {self.registry.target_compute}")
        print(f"\nConfig file: {self.registry.compute_file}")

    def register_compute(
        self,
        name: str,
        compute_type: str = "spark",
        description: Optional[str] = None,
        replace: bool = False,
        **config_kwargs: Any,
    ) -> None:
        """
        Register a new compute engine.

        :param name: Unique name for the compute engine
        :param compute_type: Type of compute engine ('spark')
        :param description: Optional description
        :param replace: If True, replace existing engine with same name
        :param config_kwargs: Additional configuration parameters
        """
        try:
            self.registry.register(
                name=name,
                cluster_type=compute_type,
                config=config_kwargs,
                description=description,
                replace=replace,
            )
            print(f"✓ Registered compute engine: {name}")
            print(f"  Type: {compute_type}")
            print(f"  Config file: {self.registry.compute_file}")

            # Show detected platform
            cluster = self.registry.get(name)
            if cluster:
                platform = cluster.detect_platform()
                print(f"  Platform: {platform.value}")

        except DbtRuntimeError as e:
            print(f"✗ Error: {str(e)}", file=sys.stderr)
            sys.exit(1)

    def test_compute(self, name: str) -> bool:
        """
        Test connection to a compute engine.

        :param name: Name of compute engine to test
        :returns: True if test successful, False otherwise
        """
        cluster = self.registry.get(name)
        if not cluster:
            print(f"✗ Compute engine '{name}' not found", file=sys.stderr)
            print(
                f"\nAvailable engines: {', '.join([c.name for c in self.registry.list()])}",
                file=sys.stderr,
            )
            return False

        print(f"Testing connection to '{name}'...")
        print(f"  Type: {cluster.type}")

        platform = cluster.detect_platform()
        print(f"  Platform: {platform.value}")

        # Basic validation tests
        try:
            if cluster.type == "spark":
                # Check for required config keys based on platform
                if platform == SparkPlatform.DATABRICKS:
                    required = ["host", "token"]
                    missing = [k for k in required if k not in cluster.config]
                    if missing:
                        print(
                            f"✗ Missing required Databricks config: {', '.join(missing)}",
                            file=sys.stderr,
                        )
                        return False

                    # Check for cluster_id OR http_path
                    if (
                        "cluster_id" not in cluster.config
                        and "http_path" not in cluster.config
                    ):
                        print(
                            "✗ Missing required Databricks config: cluster_id or http_path",
                            file=sys.stderr,
                        )
                        return False

                    # Check databricks-connect availability
                    try:
                        import databricks.connect  # noqa: F401

                        print("  ✓ databricks-connect available")
                    except ImportError:
                        print(
                            "  ⚠ Warning: databricks-connect not installed "
                            "(install with: pip install 'dvt-core[databricks]')"
                        )

                elif platform == SparkPlatform.LOCAL:
                    # Check PySpark availability
                    try:
                        import pyspark  # noqa: F401

                        print("  ✓ PySpark available")
                    except ImportError:
                        print(
                            "  ✗ PySpark not installed (required for local Spark)",
                            file=sys.stderr,
                        )
                        return False

            print(f"✓ Configuration valid")
            return True

        except Exception as e:
            print(f"✗ Test failed: {str(e)}", file=sys.stderr)
            return False

    def remove_compute(self, name: str, confirm: bool = False) -> bool:
        """
        Remove a compute engine.

        :param name: Name of compute engine to remove
        :param confirm: If True, skip confirmation prompt
        :returns: True if removed, False otherwise
        """
        try:
            # Check if engine exists
            if not self.registry.get(name):
                print(f"✗ Compute engine '{name}' not found", file=sys.stderr)
                return False

            # Confirmation prompt if not already confirmed
            if not confirm:
                response = input(f"Are you sure you want to remove '{name}'? (y/N): ")
                if response.lower() != "y":
                    print("Removal cancelled")
                    return False

            # Check if it's the current target
            if self.registry.target_compute == name:
                print(
                    f"Warning: '{name}' is the current target_compute. "
                    "You may want to update target_compute in computes.yml after removal."
                )

            self.registry.remove(name)
            print(f"✓ Removed compute engine: {name}")
            print(f"  Config file: {self.registry.compute_file}")
            return True

        except DbtRuntimeError as e:
            print(f"✗ Error: {str(e)}", file=sys.stderr)
            return False

    def show_status(self) -> None:
        """Show the current compute configuration status."""
        config_path = Path(self.registry.compute_file)

        print("\nDVT Compute Configuration Status")
        print("=" * 80)

        # Check config file
        if config_path.exists():
            print(f"✓ Config file exists: {config_path}")

            # Show current target
            print(f"\nCurrent target compute: {self.registry.target_compute}")

            # Count engines
            engines = self.registry.list()
            print(f"Registered engines: {len(engines)}")

            if engines:
                # Show summary by type
                engine_types = {}
                for engine in engines:
                    engine_type = f"{engine.type} ({engine.detect_platform().value})"
                    engine_types[engine_type] = engine_types.get(engine_type, 0) + 1

                print("\nEngine types:")
                for engine_type, count in engine_types.items():
                    print(f"  - {engine_type}: {count}")

            # Check for default engines
            default_names = {
                "spark-local",
                "spark-cluster",
                "databricks",
                "emr",
                "dataproc",
            }
            has_defaults = any(e.name in default_names for e in engines)

            if has_defaults:
                print("\n✓ Default engines configured")
            else:
                print(
                    "\n⚠ No default engines found (run 'dvt compute register' to add)"
                )

        else:
            print(f"✗ Config file not found: {config_path}")
            print("\nTo initialize default configuration:")
            print("  1. Run 'dvt migrate' to set up .dvt/ directory")
            print("  2. Or manually create computes.yml")

        print("\n" + "=" * 80)

    def validate_all(self) -> bool:
        """
        Validate all compute engine configurations.

        :returns: True if all engines are valid, False otherwise
        """
        engines = self.registry.list()

        if not engines:
            print("No compute engines registered to validate")
            return True

        print(f"\nValidating {len(engines)} compute engine(s)...")
        print("-" * 60)

        all_valid = True

        for engine in engines:
            print(f"\n{engine.name}:")
            print(f"  Type: {engine.type}")

            platform = engine.detect_platform()
            print(f"  Platform: {platform.value}")

            # Basic validation
            valid = True

            if engine.type == "spark":
                if platform == SparkPlatform.DATABRICKS:
                    required = ["host", "token"]
                    missing = [k for k in required if k not in engine.config]
                    if missing:
                        print(f"  ✗ Missing config: {', '.join(missing)}")
                        valid = False
                    elif (
                        "cluster_id" not in engine.config
                        and "http_path" not in engine.config
                    ):
                        print("  ✗ Missing config: cluster_id or http_path")
                        valid = False
                    else:
                        print("  ✓ Configuration valid")

                elif platform == SparkPlatform.LOCAL:
                    # Check for local Spark
                    try:
                        import pyspark  # noqa: F401

                        print("  ✓ PySpark available")
                    except ImportError:
                        print("  ✗ PySpark not installed")
                        valid = False

                elif platform == SparkPlatform.EMR:
                    required = ["master", "cluster_id"]
                    missing = [k for k in required if k not in engine.config]
                    if missing:
                        print(f"  ✗ Missing config: {', '.join(missing)}")
                        valid = False
                    else:
                        print("  ✓ Configuration valid")

                elif platform == SparkPlatform.DATAPROC:
                    required = ["project", "region", "cluster"]
                    missing = [k for k in required if k not in engine.config]
                    if missing:
                        print(f"  ✗ Missing config: {', '.join(missing)}")
                        valid = False
                    else:
                        print("  ✓ Configuration valid")

                else:
                    print(f"  ✓ Generic Spark configuration")

            if not valid:
                all_valid = False

        print("\n" + "-" * 60)
        if all_valid:
            print("✓ All compute engines validated successfully")
        else:
            print("✗ Some compute engines have validation errors")

        return all_valid

    def set_target(self, name: str) -> None:
        """
        Set the default target compute engine.

        :param name: Name of compute engine to set as default
        """
        try:
            self.registry.target_compute = name
            print(f"✓ Set target_compute to: {name}")
            print(f"  Config file: {self.registry.compute_file}")

        except DbtRuntimeError as e:
            print(f"✗ Error: {str(e)}", file=sys.stderr)
            sys.exit(1)
