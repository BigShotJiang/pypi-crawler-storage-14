import inspect
import functools
import traceback
import time
from typing import Any, Dict, Optional, Tuple

from langchain_aws import ChatBedrock
from langchain_community.callbacks.bedrock_anthropic_callback import (
    BedrockAnthropicTokenUsageCallbackHandler,
)

from .trace_manager import (
    TraceManager,
    serialize_value,
    calculate_cost,
)


# ====================================================================================
# MAIN DECORATOR — track_llm_call
# ====================================================================================


def track_llm_call(name: str = "llm_call", *, tags=None):
    """
    Final universal LLM tracker.

    ✔ Works for raw Bedrock (converse, invoke_model)
    ✔ Works for LangChain ChatBedrock
    ✔ Works for LCEL pipelines (| operator)
    ✔ Works for sync + async
    ✔ Automatically inject token-usage callback for LangChain
    ✔ Automatically extracts Bedrock usage
    ✔ Sends final normalized usage + cost to TraceManager
    """

    def decorator(func):
        is_async = inspect.iscoroutinefunction(func)

        # ----------------------------------------------------------------------
        # Detect LangChain ChatBedrock or ChatBedrock inside LCEL chain
        # ----------------------------------------------------------------------
        def _detect_langchain(args, kwargs) -> bool:
            all_items = list(args) + list(kwargs.values())

            for item in all_items:
                # If the ChatBedrock model is directly passed
                if isinstance(item, ChatBedrock):
                    return True

                # If inside an LCEL RunnableSequence
                try:
                    if hasattr(item, "bound") and hasattr(item.bound, "arguments"):
                        for inner in item.bound.arguments.values():
                            if isinstance(inner, ChatBedrock):
                                return True
                except Exception:
                    pass

            return False

        # ----------------------------------------------------------------------
        # EXTRACT USAGE (raw Bedrock)
        # ----------------------------------------------------------------------
        def extract_raw_bedrock_usage(response: Any) -> Optional[Dict[str, int]]:
            """
            Extract usage from direct Bedrock responses.
            Raw Bedrock SDK returns:
            {
                "usage": {"inputTokens": X, "outputTokens": Y}
            }
            """
            if not isinstance(response, dict):
                return None

            usage = (
                response.get("usage")
                or response.get("response", {}).get("usage")
                or response.get("metrics", {}).get("usage")
                or response.get("ResponseMetadata", {}).get("usage")
            )

            if not usage:
                return None

            in_tok = usage.get("inputTokens") or usage.get("input_tokens") or 0
            out_tok = usage.get("outputTokens") or usage.get("output_tokens") or 0

            return {
                "input_tokens": in_tok,
                "output_tokens": out_tok,
                "total_tokens": in_tok + out_tok,
            }

        # ====================================================================================
        # ASYNC WRAPPER
        # ====================================================================================
        async def async_wrapper(*args, **kwargs):

            span_id = TraceManager.start_span(
                name,
                input_data={
                    "args": serialize_value(args),
                    "kwargs": serialize_value(kwargs),
                },
                tags=tags,
            )

            start = time.time()
            result = None
            usage_data = None

            try:
                # ------------------------------------------------------------------
                # LANGCHAIN CALL
                # ------------------------------------------------------------------
                if _detect_langchain(args, kwargs):
                    cb = BedrockAnthropicTokenUsageCallbackHandler()

                    # Inject callback into LCEL config
                    if "config" in kwargs and isinstance(kwargs["config"], dict):
                        kwargs["config"].setdefault("callbacks", []).append(cb)
                    else:
                        kwargs["config"] = {"callbacks": [cb]}

                    # Actual LLM call
                    result = await func(*args, **kwargs)

                    # Normalize LangChain usage
                    usage_data = {
                        "input_tokens": cb.prompt_tokens or 0,
                        "output_tokens": cb.completion_tokens or 0,
                        "total_tokens": cb.total_tokens or 0,
                    }

                # ------------------------------------------------------------------
                # RAW BEDROCK CALL
                # ------------------------------------------------------------------
                else:
                    result = await func(*args, **kwargs)
                    usage_data = extract_raw_bedrock_usage(result)

            except Exception as e:
                TraceManager.end_span(
                    span_id,
                    {
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                    },
                )
                raise

            # Finish span
            latency = int((time.time() - start) * 1000)
            cost = calculate_cost(usage_data or {})

            TraceManager.end_span(
                span_id,
                {
                    "status": "success",
                    "latency_ms": latency,
                    "usage": usage_data,
                    "cost": cost,
                    "output": serialize_value(result),
                },
            )

            return result

        # ====================================================================================
        # SYNC WRAPPER
        # ====================================================================================
        def sync_wrapper(*args, **kwargs):

            span_id = TraceManager.start_span(
                name,
                input_data={
                    "args": serialize_value(args),
                    "kwargs": serialize_value(kwargs),
                },
                tags=tags,
            )

            start = time.time()
            result = None
            usage_data = None

            try:
                if _detect_langchain(args, kwargs):
                    cb = BedrockAnthropicTokenUsageCallbackHandler()

                    if "config" in kwargs and isinstance(kwargs["config"], dict):
                        kwargs["config"].setdefault("callbacks", []).append(cb)
                    else:
                        kwargs["config"] = {"callbacks": [cb]}

                    result = func(*args, **kwargs)

                    usage_data = {
                        "input_tokens": cb.prompt_tokens or 0,
                        "output_tokens": cb.completion_tokens or 0,
                        "total_tokens": cb.total_tokens or 0,
                    }

                else:
                    result = func(*args, **kwargs)
                    usage_data = extract_raw_bedrock_usage(result)

            except Exception as e:
                TraceManager.end_span(
                    span_id,
                    {
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                    },
                )
                raise

            latency = int((time.time() - start) * 1000)
            cost = calculate_cost(usage_data or {})

            TraceManager.end_span(
                span_id,
                {
                    "status": "success",
                    "latency_ms": latency,
                    "usage": usage_data,
                    "cost": cost,
                    "output": serialize_value(result),
                },
            )

            return result

        return functools.wraps(func)(async_wrapper if is_async else sync_wrapper)

    return decorator
