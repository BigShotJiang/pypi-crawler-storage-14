import os
from typing import Tuple, Optional

import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter, ImageStat


class A3ToA4Processor:
  """A3试卷拆分为A4并增强处理的完整解决方案"""

  def __init__(self, dpi: int = 300, quality: int = 95):
    """
    初始化处理器

    Args:
        dpi: 输出图像分辨率，默认300
        quality: JPEG保存质量，默认95
    """
    self.dpi = dpi
    self.quality = quality
    self.a4_width = int(210 * dpi / 25.4)  # A4宽度（像素）
    self.a4_height = int(297 * dpi / 25.4)  # A4高度（像素）

  def auto_rotate(self, image: Image.Image) -> Image.Image:
    """根据EXIF信息自动旋转图像"""
    try:
      exif = image.getexif()
      orientation = exif.get(0x0112)
      if orientation:
        rotation_map = {3: 180, 6: 270, 8: 90}
        if orientation in rotation_map:
          image = image.rotate(rotation_map[orientation], expand=True)
    except Exception:
      pass
    return image

  def detect_and_correct_perspective(self, image: Image.Image,
                                     min_area_ratio: float = 0.3) -> Image.Image:
    """
    检测并校正透视变形

    Args:
        image: 输入图像
        min_area_ratio: 最小有效区域比例
    """
    img_cv = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)

    # 边缘检测
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)

    # 查找轮廓
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if not contours:
      return image

    # 找到最大矩形轮廓
    largest_contour = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(largest_contour)

    # 检查是否为有效试卷区域
    if area < min_area_ratio * img_cv.shape[0] * img_cv.shape[1]:
      return image

    # 近似为矩形
    epsilon = 0.02 * cv2.arcLength(largest_contour, True)
    approx = cv2.approxPolyDP(largest_contour, epsilon, True)

    if len(approx) == 4:
      # 排序四个角点
      pts = approx.reshape(4, 2)
      rect = np.zeros((4, 2), dtype="float32")

      s = pts.sum(axis=1)
      rect[0] = pts[np.argmin(s)]  # 左上
      rect[2] = pts[np.argmax(s)]  # 右下

      diff = np.diff(pts, axis=1)
      rect[1] = pts[np.argmin(diff)]  # 右上
      rect[3] = pts[np.argmax(diff)]  # 左下

      # 计算目标尺寸
      width = max(
        np.linalg.norm(rect[0] - rect[1]),
        np.linalg.norm(rect[2] - rect[3])
      )
      height = max(
        np.linalg.norm(rect[0] - rect[3]),
        np.linalg.norm(rect[1] - rect[2])
      )

      dst = np.array([
        [0, 0],
        [width - 1, 0],
        [width - 1, height - 1],
        [0, height - 1]
      ], dtype="float32")

      # 透视变换
      M = cv2.getPerspectiveTransform(rect, dst)
      warped = cv2.warpPerspective(img_cv, M, (int(width), int(height)))

      return Image.fromarray(cv2.cvtColor(warped, cv2.COLOR_BGR2RGB))

    return image

  def find_split_line(self, image: Image.Image, search_range: float = 0.1) -> int:
    """
    检测最佳拆分线位置（避开内容区域）

    Args:
        image: 输入图像
        search_range: 搜索范围（相对于宽度的比例）
    """
    img_array = np.array(image.convert('L'))
    width = img_array.shape[1]
    center = width // 2

    # 在中心附近搜索
    search_width = int(width * search_range)
    start = max(0, center - search_width)
    end = min(width, center + search_width)

    # 计算每列的"空白度"（像素值总和）
    column_whiteness = np.sum(img_array[:, start:end] > 200, axis=0)

    # 找到最"空白"的列
    relative_split = np.argmax(column_whiteness)
    split_position = start + relative_split

    return split_position

  def auto_crop(self, image: Image.Image) -> Image.Image:
    """自动裁剪图片四周空白区域"""
    img_cv = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)

    # 使用Canny边缘检测
    edges = cv2.Canny(gray, 50, 150)

    # 查找轮廓
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
      return image

    # 合并所有轮廓的边界框
    all_points = np.vstack(contours).squeeze()
    x, y, w, h = cv2.boundingRect(all_points)

    # 添加padding并裁剪
    padding = int(max(h, w) * 0.03)
    x1 = max(0, x - padding)
    y1 = max(0, y - padding)
    x2 = min(img_cv.shape[1], x + w + padding)
    y2 = min(img_cv.shape[0], y + h + padding)

    # 裁剪并转换回PIL.Image
    cropped_cv = img_cv[y1:y2, x1:x2]
    return Image.fromarray(cv2.cvtColor(cropped_cv, cv2.COLOR_BGR2RGB))

  def smart_resize(self, image: Image.Image,
                   target_width: int, target_height: int) -> Image.Image:
    """
    智能调整图像大小（保持宽高比，填充白色背景）

    Args:
        image: 输入图像
        target_width: 目标宽度
        target_height: 目标高度
    """
    # 计算缩放比例
    width_ratio = target_width / image.width
    height_ratio = target_height / image.height
    scale = min(width_ratio, height_ratio)

    new_width = int(image.width * scale)
    new_height = int(image.height * scale)

    # 使用LANCZOS插值算法
    resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)

    # 填充白色背景
    if resized_image.size != (target_width, target_height):
      background = Image.new("RGB", (target_width, target_height), (255, 255, 255))
      offset = ((target_width - new_width) // 2, (target_height - new_height) // 2)
      background.paste(resized_image, offset)
      return background
    return resized_image

  def adaptive_enhance_image(self, image: Image.Image) -> Image.Image:
    """
    基于图像特征自适应增强

    自动分析图像的亮度、对比度和清晰度，应用最佳增强参数
    """
    # 分析图像统计特征
    stat = ImageStat.Stat(image)

    # 1. 自适应亮度调整（更激进的提亮）
    mean_brightness = sum(stat.mean) / 3
    if mean_brightness < 120:  # 图像偏暗（提高阈值）
      brightness_factor = 1.0 + (120 - mean_brightness) / 150
    elif mean_brightness > 200:  # 图像偏亮
      brightness_factor = 1.0 - (mean_brightness - 200) / 300
    else:
      brightness_factor = 1.1  # 默认轻微提亮

    brightness_factor = max(0.9, min(1.5, brightness_factor))  # 允许更大范围
    enhancer = ImageEnhance.Brightness(image)
    image = enhancer.enhance(brightness_factor)

    # 2. 自适应对比度调整（增强文字清晰度）
    std_dev = sum(stat.stddev) / 3
    if std_dev < 40:  # 对比度低
      contrast_factor = 1.5  # 更强的对比度增强
    elif std_dev > 80:  # 对比度高
      contrast_factor = 1.1
    else:
      contrast_factor = 1.3

    enhancer = ImageEnhance.Contrast(image)
    image = enhancer.enhance(contrast_factor)

    # 3. 自适应锐化（增强文字边缘）
    if std_dev < 30:  # 图像模糊
      image = image.filter(ImageFilter.UnsharpMask(
        radius=2.5, percent=200, threshold=2
      ))
    else:
      image = image.filter(ImageFilter.UnsharpMask(
        radius=1.5, percent=150, threshold=3
      ))

    # 4. 可选：自适应降噪（针对扫描文档）
    img_array = np.array(image)
    if std_dev > 60:  # 噪声较多
      img_cv = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
      denoised = cv2.fastNlMeansDenoisingColored(img_cv, None, 10, 10, 7, 21)
      image = Image.fromarray(cv2.cvtColor(denoised, cv2.COLOR_BGR2RGB))

    return image

  def enhance_a4_image(self, image_path: str, output_path: Optional[str] = None) -> str:
    """
    增强单张A4图片（通用增强方法）

    Args:
        image_path: 输入图片路径
        output_path: 输出路径（可选）

    Returns:
        增强后的图像
    """
    # 读取图像
    image = Image.open(image_path)
    image = self.auto_rotate(image)

    # 透视校正
    image = self.detect_and_correct_perspective(image)

    # 自动裁剪空白
    image = self.auto_crop(image)

    # 调整到A4尺寸
    image = self.smart_resize(image, self.a4_width, self.a4_height)

    # 自适应增强
    image = self.adaptive_enhance_image(image)

    # 保存结果
    if not output_path:
      output_path = os.path.join(os.path.dirname(image_path), "_enhanced".join(os.path.splitext(os.path.basename(image_path))))

    image.save(output_path, "JPEG", quality=self.quality, dpi=(self.dpi, self.dpi))

    return output_path

  def process_a3_to_a4(self, image_path: str, output_folder: str,
                       enable_perspective_correction: bool = True,
                       enable_smart_split: bool = True) -> Tuple[str, str]:
    """
    完整的A3到A4处理流程

    Args:
        image_path: 输入A3图片路径
        output_folder: 输出文件夹
        enable_perspective_correction: 是否启用透视校正
        enable_smart_split: 是否启用智能拆分点检测

    Returns:
        (左半部分, 右半部分) 的元组
    """
    # 确保输出文件夹存在
    if not output_folder:
      output_folder = os.path.dirname(image_path)
    else:
      os.makedirs(output_folder, exist_ok=True)

    # 1. 读取并旋转
    image = Image.open(image_path)
    image = self.auto_rotate(image)

    # 2. 透视校正（可选）
    if enable_perspective_correction:
      image = self.detect_and_correct_perspective(image)

    # 3. 智能检测拆分点或简单从中间拆分
    width, height = image.size
    if enable_smart_split:
      split_pos = self.find_split_line(image)
    else:
      split_pos = width // 2

    # 4. 拆分
    leftImg = image.crop((0, 0, split_pos, height))
    rightImg = image.crop((split_pos, 0, width, height))

    # 5. 自动裁剪空白
    leftImg = self.auto_crop(leftImg)
    rightImg = self.auto_crop(rightImg)

    # 6. 调整到A4尺寸
    leftImgA4 = self.smart_resize(leftImg, self.a4_width, self.a4_height)
    rightImgA4 = self.smart_resize(rightImg, self.a4_width, self.a4_height)

    # 7. 自适应增强
    leftImgA4 = self.adaptive_enhance_image(leftImgA4)
    rightImgA4 = self.adaptive_enhance_image(rightImgA4)

    # 8. 保存
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    left_path = os.path.join(output_folder, f"{base_name}_left.jpg")
    right_path = os.path.join(output_folder, f"{base_name}_right.jpg")

    leftImgA4.save(left_path, "JPEG", quality=self.quality, dpi=(self.dpi, self.dpi))
    rightImgA4.save(right_path, "JPEG", quality=self.quality, dpi=(self.dpi, self.dpi))

    print(f"✓ 处理完成: {base_name}")
    print(f"  左半部分: {left_path}")
    print(f"  右半部分: {right_path}")

    return left_path, right_path

  def batch_process_a3(self, input_folder: str, output_folder: str,
                       extensions: Tuple[str, ...] = ('.jpg', '.jpeg', '.png')) -> int:
    """
    批量处理A3图片

    Args:
        input_folder: 输入文件夹
        output_folder: 输出文件夹
        extensions: 支持的文件扩展名

    Returns:
        处理的文件数量
    """
    count = 0
    for filename in os.listdir(input_folder):
      if filename.lower().endswith(extensions):
        input_path = os.path.join(input_folder, filename)
        try:
          self.process_a3_to_a4(input_path, output_folder)
          count += 1
        except Exception as e:
          print(f"✗ 处理失败: {filename} - {str(e)}")

    print(f"\n批量处理完成，共处理 {count} 个文件")
    return count

  def batch_enhance_a4(self, input_folder: str, output_folder: str,
                       extensions: Tuple[str, ...] = ('.jpg', '.jpeg', '.png')) -> int:
    """
    批量增强A4图片

    Args:
        input_folder: 输入文件夹
        output_folder: 输出文件夹
        extensions: 支持的文件扩展名

    Returns:
        处理的文件数量
    """
    os.makedirs(output_folder, exist_ok=True)
    count = 0

    for filename in os.listdir(input_folder):
      if filename.lower().endswith(extensions):
        input_path = os.path.join(input_folder, filename)
        output_path = os.path.join(output_folder, f"enhanced_{filename}")
        try:
          self.enhance_a4_image(input_path, output_path)
          print(f"✓ 增强完成: {filename}")
          count += 1
        except Exception as e:
          print(f"✗ 增强失败: {filename} - {str(e)}")

    print(f"\n批量增强完成，共处理 {count} 个文件")
    return count


if __name__ == "__main__":
  processor = A3ToA4Processor(dpi=300, quality=95)
  processor.process_a3_to_a4(
    image_path="C:\\Users\\97116\\OneDrive\\Desktop\\SplitA3\\第五单元2.jpg",
    output_folder="C:\\Users\\97116\\OneDrive\\Desktop\\SplitA3\\output"
  )
