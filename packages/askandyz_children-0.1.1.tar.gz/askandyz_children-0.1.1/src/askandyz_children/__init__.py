import os
from typing import Tuple

from fastmcp import FastMCP, settings
from fastmcp.experimental.sampling.handlers.openai import OpenAISamplingHandler
from openai import OpenAI

from a3_to_a4_processor import A3ToA4Processor

settings.json_response = True
mcp = FastMCP(
  name="Demo",
  sampling_handler=OpenAISamplingHandler(
    default_model="deepseek-ai/DeepSeek-V3",
    client=OpenAI(
      api_key=os.getenv("SILICON_FLOW_API_KEY"),
      base_url="https://api.siliconflow.cn"
    ),
  ),
  sampling_handler_behavior="fallback",
)


@mcp.tool()
def split_a3_image_to_a4(image_path: str,
                         output_path: str = None,
                         dpi=300,
                         quality=95,
                         target_brightness=255) -> Tuple[str, str]:
  """Split A3 image to A4."""
  processor = A3ToA4Processor(
    dpi=dpi,
    quality=quality,
    target_brightness=target_brightness
  )
  return processor.process_a3_to_a4(image_path)


@mcp.tool()
def enhance_a4_image(image_path: str,
                     output_path: str = None,
                     dpi=300,
                     quality=95,
                     target_brightness=255) -> str:
  """Enhance A4 image."""
  processor = A3ToA4Processor(
    dpi=dpi,
    quality=quality,
    target_brightness=target_brightness
  )
  processor.enhance_a4_image(image_path, output_path)
  return output_path


def main() -> None:
  mcp.run(transport="stdio")
