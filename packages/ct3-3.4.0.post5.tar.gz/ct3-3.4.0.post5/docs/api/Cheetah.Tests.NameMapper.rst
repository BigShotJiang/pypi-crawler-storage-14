Cheetah\.Tests\.NameMapper module
=================================

.. automodule:: Cheetah.Tests.NameMapper
    :members:
    :undoc-members:
    :show-inheritance:
