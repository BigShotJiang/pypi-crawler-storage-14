Non-HTML Output
===============


Cheetah can also output any other text format besides HTML.

Python source code
------------------


To be written. We're in the middle of working on an autoindenter to
make it easier to encode Python indentation in a Cheetah template.


