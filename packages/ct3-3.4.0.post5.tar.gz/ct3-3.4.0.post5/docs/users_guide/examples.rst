Examples
========


The Cheetah distribution comes with an 'examples' directory. Browse
the files in this directory and its subdirectories for examples of
how Cheetah can be used.

Syntax examples
---------------

The {Cheetah.Tests} module contains a large number of test cases
that can double as examples of how the Cheetah Language works. To
view these cases go to the base directory of your Cheetah
distribution and open the file {Cheetah/Tests/SyntaxAndOutput.py}
in a text editor.

Webware Examples
----------------

For examples of Cheetah in use with Webware visit the Cheetah and
Webware wikis or use google. We used to have more examples in the
cheetah source tarball, but they were out of date and confused
people.


