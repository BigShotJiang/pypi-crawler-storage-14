What's new in CheetahTemplate3
==============================

  - Tested with Python 3.14.
