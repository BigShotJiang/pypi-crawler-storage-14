#!/usr/bin/env python

# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

import tango
import argparse

parser = argparse.ArgumentParser(
    prog="cleanup_processing_ds",
    description="Cleanup processing devices from the Tango Database",
)

parser.add_argument("domain", default="id00", help="the Tango domain")
parser.add_argument(
    "--dry-run", default=False, action="store_true", help="the Tango domain"
)

args = parser.parse_args()

db = tango.Database()
devs = db.get_device_exported(args.domain + "/limaprocessing/*")

if args.dry_run:
    [print(dev) for dev in devs]
else:
    [db.delete_device(dev) for dev in devs]
