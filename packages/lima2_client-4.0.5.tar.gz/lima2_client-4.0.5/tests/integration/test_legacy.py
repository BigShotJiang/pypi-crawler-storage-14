# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test acquisition and processing with the legacy pipeline."""

import asyncio
import copy
import os
import shutil
import time
from typing import Any

import jsonschema_default
import pytest
import pytest_asyncio

from lima2.conductor.acquisition_system import AcquisitionSystem
from lima2.common.state import State

acq_params = {
    "acq": {
        "nb_frames": 1000,
        "expo_time": 125,
        "latency_time": 125,
        "trigger_mode": "internal",
        "nb_frames_per_trigger": 1,
        "acq_mode": "normal",
    },
    "img": {
        "binning": {"x": 1, "y": 1},
        "roi": {"topleft": {"x": 0, "y": 0}, "dimensions": {"x": 0, "y": 0}},
        "flip": "none",
    },
    "shut": {"mode": "manual"},
    "accu": {"nb_frames": 1, "expo_time": 1000, "saturated_threshold": 0},
    "vid": {"auto_exposure_mode": "off"},
    "xfer": {
        "alignment": {"col_alignment": 1, "row_alignment": 8, "header": 0, "footer": 0},
        "slice": {"start": 0, "stride": 1},
    },
    "det": {
        "image_source": "generator",
        "generator": {
            "type": "gauss",
            "gauss": {
                "peaks": [{"x0": 1024.0, "y0": 1024.0, "fwhm": 128.0, "max": 100.0}],
                "grow_factor": 0.0,
            },
            "diffraction": {
                "x0": 1024.0,
                "y0": 1024.0,
                "source_pos_x": 5.0,
                "source_pos_y": 5.0,
                "source_speed_x": 0.0,
                "source_speed_y": 0.0,
            },
            "pixel_type": "gray8",
            "nb_channels": 1,
        },
        "loader": {
            "base_path": "/tmp",
            "filename_format": "{filename_prefix}_{filename_rank}_{file_number:05d}{filename_suffix}",
            "filename_prefix": "lima2",
            "filename_rank": 0,
            "filename_suffix": ".h5",
            "start_number": 0,
            "nb_frames_per_file": 0,
            "frame_slice": {"start": 0, "count": 0, "stride": 1},
            "file_type": "nexus",
            "dataset_path": "/entry_0000/measurement/data",
        },
        "nb_prefetch_frames": 2,
        "dropped_frame_idx": 0,
        "failed_frame_idx": 0,
    },
}

ctl_params = copy.deepcopy(acq_params)


@pytest.fixture
def data_dir() -> str:
    return os.path.abspath("lima2_data")


@pytest_asyncio.fixture(loop_scope="session")
async def legacy_pipeline_params(
    acquisition_system: AcquisitionSystem, data_dir: str
) -> dict[str, Any]:
    schema = acquisition_system.receivers[0].fetch_proc_schema("LimaProcessingLegacy")
    params = jsonschema_default.create_from(schema)
    params["fifo"]["nb_fifo_frames"] = 1000

    if os.path.exists(data_dir):
        shutil.rmtree(data_dir)
    os.mkdir(data_dir)

    params["saving"]["enabled"] = True
    params["saving"]["base_path"] = data_dir
    params["saving"]["filename_format"] = "lima2_{filename_rank}_{file_number:05d}.h5"
    params["saving"]["file_exists_policy"] = "overwrite"
    params["saving"]["nb_frames_per_file"] = 100

    return params


@pytest.mark.asyncio(loop_scope="session")
async def test_legacy_ok(
    acquisition_system: AcquisitionSystem,
    legacy_pipeline_params: dict[str, Any],
    data_dir: str,
):
    await acquisition_system.prepare(
        ctl_params=ctl_params,
        acq_params=acq_params,
        proc_params=legacy_pipeline_params,
    )

    assert await acquisition_system.global_state() == State.PREPARED

    await acquisition_system.start()
    assert acquisition_system.acquisition.running()
    assert await acquisition_system.global_state() == State.RUNNING

    time_start = time.time()
    while acquisition_system.acquisition.running():
        print(
            f"Waiting for acquision end... {await acquisition_system.nb_frames_xferred()}"
        )

        if time.time() - time_start > 5.0:
            raise RuntimeError("Acquisition timed out")

        await asyncio.sleep(0.2)

    print("Acquisition finished")
    nb_frames_xferred = await acquisition_system.nb_frames_xferred()
    assert nb_frames_xferred.sum == acq_params["acq"]["nb_frames"]

    print("Wait for processing to end")

    time_start = time.time()
    while acquisition_system.current_pipeline.is_running():
        progress = await acquisition_system.current_pipeline.progress_counters()
        print(f"Waiting for processing end... {progress}")

        if time.time() - time_start > 5.0:
            raise RuntimeError("Processing timed out")

        await asyncio.sleep(0.2)

    for filename in [
        "lima2_0_00000",
        "lima2_0_00001",
        "lima2_1_00000",
        "lima2_1_00001",
    ]:
        assert os.path.exists(f"{data_dir}/{filename}.h5")
