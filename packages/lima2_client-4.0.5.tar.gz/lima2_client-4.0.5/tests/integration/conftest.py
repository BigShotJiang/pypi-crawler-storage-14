"""Common fixtures for Lima2 integration tests."""

import os
import shutil
import signal
import subprocess
import time

import pytest
import pytest_asyncio
import tango as tg
from nosqltangodb import helper

from lima2.conductor.acquisition_system import AcquisitionSystem
from lima2.conductor.tango.control import TangoControl
from lima2.conductor.tango.receiver import TangoReceiver
from lima2.conductor.topology import RoundRobin


@pytest.fixture(scope="session")
def tango_db():
    this_dir = os.path.dirname(__file__)
    with helper.running_db(
        name="2",
        db_access="yaml",
        yaml_root=f"{this_dir}/tango_db",
        port="auto",
        debug_protocol=True,
        update_tango_host=True,
        timeout=2,
    ) as db:
        print(f"Tango server running at '{os.environ['TANGO_HOST']}'")
        yield db


@pytest.fixture(scope="session")
def lima2_simulator(tango_db):
    log_dir = os.path.abspath("lima2_logs")
    if os.path.exists(log_dir):
        shutil.rmtree(log_dir)
    os.mkdir(log_dir)

    mpi_process = subprocess.Popen(
        args=[
            "mpiexec",
            "-n",
            "1",
            "lima2_tango",
            "--log-level",
            "trace",
            "--log-file-filename",
            "ctl.%N.log",
            "--log-file-path",
            log_dir,
            "simulator_ctl",
            ":",
            "-n",
            "1",
            "lima2_tango",
            "--log-level",
            "trace",
            "--log-file-filename",
            "rcv1.%N.log",
            "--log-file-path",
            log_dir,
            "simulator_rcv1",
            ":",
            "-n",
            "1",
            "lima2_tango",
            "--log-level",
            "trace",
            "--log-file-filename",
            "rcv2.%N.log",
            "--log-file-path",
            log_dir,
            "simulator_rcv2",
        ],
        preexec_fn=os.setsid,
    )
    print("Lima2 servers launched")

    # Wait for all devices to respond
    time_start = time.time()
    while True:
        if time.time() - time_start > 3:
            raise RuntimeError("No reponse from lima2 devices after 3 seconds")

        all_respond = True
        for url in [
            "id00/limacontrol/simulator",
            "id00/limareceiver/simulator1",
            "id00/limareceiver/simulator2",
        ]:
            dev = tg.DeviceProxy(url)
            try:
                dev.ping()
            except tg.ConnectionFailed:
                all_respond = False

        if all_respond:
            break

        time.sleep(0.5)

    yield mpi_process

    print("Kill lima2 processes")

    os.killpg(os.getpgid(mpi_process.pid), signal.SIGTERM)
    mpi_process.communicate(timeout=1.0)

    print("Lima2 servers offline")


@pytest_asyncio.fixture(loop_scope="session", scope="function")
async def acquisition_system(lima2_simulator):
    ctl = TangoControl(url="id00/limacontrol/simulator", timeout_ms=3000)
    rcvs = [
        TangoReceiver(url=f"id00/limareceiver/simulator{idx}", timeout_ms=3000)
        for idx in [1, 2]
    ]

    lima2 = AcquisitionSystem(
        control=ctl,
        receivers=rcvs,
        topology=RoundRobin(num_receivers=len(rcvs), ordering=[0, 1]),
        tango_timeout_s=5,
    )

    yield lima2

    # Cancel running tasks to suppress asyncio warning
    ctl.state_polling_task.cancel()
    for rcv in rcvs:
        rcv.state_polling_task.cancel()
