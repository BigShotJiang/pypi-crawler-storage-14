# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test acquisition and processing faults with the failing pipeline."""

import asyncio
import copy
import time
from typing import Any

import jsonschema_default
import pytest
import pytest_asyncio

from lima2.common.exceptions import Lima2BackendError
from lima2.common.state import DeviceState, State
from lima2.conductor.acquisition_system import AcquisitionSystem

acq_params = {
    "acq": {
        "nb_frames": 30,
        "expo_time": 1000,
        "latency_time": 5000,
        "trigger_mode": "internal",
        "nb_frames_per_trigger": 1,
        "acq_mode": "normal",
    },
    "img": {
        "binning": {"x": 1, "y": 1},
        "roi": {"topleft": {"x": 0, "y": 0}, "dimensions": {"x": 0, "y": 0}},
        "flip": "none",
    },
    "shut": {"mode": "manual"},
    "accu": {"nb_frames": 1, "expo_time": 1000, "saturated_threshold": 0},
    "vid": {"auto_exposure_mode": "off"},
    "xfer": {
        "alignment": {"col_alignment": 1, "row_alignment": 8, "header": 0, "footer": 0},
        "slice": {"start": 0, "stride": 1},
    },
    "det": {
        "image_source": "generator",
        "generator": {
            "type": "gauss",
            "gauss": {
                "peaks": [{"x0": 1024.0, "y0": 1024.0, "fwhm": 128.0, "max": 100.0}],
                "grow_factor": 0.0,
            },
            "diffraction": {
                "x0": 1024.0,
                "y0": 1024.0,
                "source_pos_x": 5.0,
                "source_pos_y": 5.0,
                "source_speed_x": 0.0,
                "source_speed_y": 0.0,
            },
            "pixel_type": "gray8",
            "nb_channels": 1,
        },
        "loader": {
            "base_path": "/tmp",
            "filename_format": "{filename_prefix}_{filename_rank}_{file_number:05d}{filename_suffix}",
            "filename_prefix": "lima2",
            "filename_rank": 0,
            "filename_suffix": ".h5",
            "start_number": 0,
            "nb_frames_per_file": 0,
            "frame_slice": {"start": 0, "count": 0, "stride": 1},
            "file_type": "nexus",
            "dataset_path": "/entry_0000/measurement/data",
        },
        "nb_prefetch_frames": 2,
        "dropped_frame_idx": 0,
        "failed_frame_idx": 0,
    },
}

ctl_params = copy.deepcopy(acq_params)


@pytest_asyncio.fixture(loop_scope="session")
async def failing_pipeline_params(
    acquisition_system: AcquisitionSystem,
) -> dict[str, Any]:
    return jsonschema_default.create_from(
        acquisition_system.receivers[0].fetch_proc_schema("LimaProcessingFailing")
    )


@pytest.mark.asyncio(loop_scope="session")
async def test_failing_ok(
    acquisition_system: AcquisitionSystem, failing_pipeline_params
):
    await acquisition_system.prepare(
        ctl_params=ctl_params,
        acq_params=acq_params,
        proc_params=failing_pipeline_params,
    )

    assert await acquisition_system.global_state() == State.PREPARED

    await acquisition_system.start()
    assert acquisition_system.acquisition.running()
    assert await acquisition_system.global_state() == State.RUNNING

    time_start = time.time()
    while acquisition_system.acquisition.running():
        print(
            f"Waiting for acquision end... {await acquisition_system.nb_frames_xferred()}"
        )

        if time.time() - time_start > 5.0:
            raise RuntimeError("Acquisition timed out")

        await asyncio.sleep(0.2)

    nb_frames_xferred = await acquisition_system.nb_frames_xferred()
    assert nb_frames_xferred.sum == acq_params["acq"]["nb_frames"]
    print("Acquisition finished")


@pytest.mark.asyncio(loop_scope="session")
async def test_failing_fail_on_prepare(
    acquisition_system: AcquisitionSystem, failing_pipeline_params: dict[str, Any]
):
    failing_pipeline_params["failed_on_prepare"] = True

    with pytest.raises(Lima2BackendError):
        await acquisition_system.prepare(
            ctl_params=ctl_params,
            acq_params=acq_params,
            proc_params=failing_pipeline_params,
        )
    assert acquisition_system.acquisition is None


@pytest.mark.asyncio(loop_scope="session")
async def test_failing_fail_on_activate(
    acquisition_system: AcquisitionSystem, failing_pipeline_params: dict[str, Any]
):
    failing_pipeline_params["failed_on_activate"] = True

    await acquisition_system.prepare(
        ctl_params=ctl_params,
        acq_params=acq_params,
        proc_params=failing_pipeline_params,
    )

    await acquisition_system.start()
    assert acquisition_system.acquisition.running()

    time_start = time.time()
    while not acquisition_system.acquisition.failed():
        await asyncio.sleep(0.1)
        if time.time() - time_start > 1.0:
            raise RuntimeError("Didn't reach FAULT state")

    for rcv in acquisition_system.receivers:
        assert await rcv.acq_state() == DeviceState.FAULT

    # NOTE(mdu): if the acquisition fails on activate, the processing devices
    # will never report that they are finished. Conductor has no way to
    # distinguish this from a pipeline that is still running, so we need to
    # clean up manually.
    await acquisition_system.current_pipeline.close()

    await acquisition_system.reset()

    assert await acquisition_system.global_state() == State.IDLE


@pytest.mark.asyncio(loop_scope="session")
async def test_failing_fail_on_frame(
    acquisition_system: AcquisitionSystem, failing_pipeline_params: dict[str, Any]
):
    failing_pipeline_params["failed_frame_idx"] = 10

    await acquisition_system.prepare(
        ctl_params=ctl_params,
        acq_params=acq_params,
        proc_params=failing_pipeline_params,
    )

    await acquisition_system.start()

    time_start = time.time()
    while not acquisition_system.acquisition.failed():
        await asyncio.sleep(0.1)
        if time.time() - time_start > 1.0:
            raise RuntimeError("Didn't reach FAULT state")

    await acquisition_system.reset()

    assert await acquisition_system.global_state() == State.IDLE
