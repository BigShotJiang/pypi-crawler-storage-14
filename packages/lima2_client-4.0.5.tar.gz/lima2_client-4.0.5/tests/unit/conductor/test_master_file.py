# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for master file generation (lima2/conductor/processing/master_file.py)"""

import os
from collections.abc import AsyncIterator
from unittest.mock import MagicMock, Mock

import h5py
import numpy as np
import numpy.testing as npt
import pytest

from lima2.common.types import FrameSource, FrameType
from lima2.conductor.processing import master_file
from lima2.conductor.tango.processing import FrameInfo
from lima2.conductor.topology import FrameMapping, LookupTable


async def single_receiver_fidx_iterator(num_frames: int) -> AsyncIterator[FrameMapping]:
    for i in range(num_frames):
        yield FrameMapping(receiver_idx=0, local_idx=i, frame_idx=i)


async def round_robin_fidx_iterator(
    num_frames: int, ordering: list[int]
) -> AsyncIterator[FrameMapping]:
    num_receivers = len(ordering)
    for i in range(num_frames):
        yield FrameMapping(
            receiver_idx=ordering[i % num_receivers],
            local_idx=i // num_receivers,
            frame_idx=i,
        )


async def dynamic_dispatch_fidx_iterator(
    num_receivers: int,
    receiver_list: np.ndarray[np.int32],
) -> AsyncIterator[FrameMapping]:
    cursors = [0 for _ in range(num_receivers)]
    for fidx, rcv_idx in enumerate(receiver_list):
        yield FrameMapping(
            receiver_idx=rcv_idx, local_idx=cursors[rcv_idx], frame_idx=fidx
        )
        cursors[rcv_idx] += 1


def mock_saving_params(
    base_path: str, enabled: bool = True, file_exists_policy: str = "overwrite"
) -> master_file.SavingParams:
    return master_file.SavingParams(
        base_path=base_path,
        filename_format="{formatme}",
        filename_prefix="limacafe",
        filename_rank=0,
        filename_suffix="efac",
        start_number=0,
        file_exists_policy=file_exists_policy,
        nb_frames_per_file=2,
        nb_frames_per_chunk=1,
        compression="none",
        nx_entry_name="entry_0000",
        nx_instrument_name="cafe_instrument",
        nx_detector_name="cafe_camera",
        nb_dimensions=1,
        include_frame_idx=False,
        enable_writer_stats=False,
        enabled=enabled,
    )


cafe_channel: master_file.FrameChannel = (
    FrameSource(
        getter_name="getCafe",
        frame_type=FrameType.DENSE,
        saving_channel="saving_cafe",
        label="cafe",
    ),
    FrameInfo(num_channels=2, width=1024, height=2048, pixel_type=np.int16),
    mock_saving_params(base_path="/cafe", enabled=True),
)


@pytest.fixture
def mock_file():
    """Returns a mock file and a context manager that yields it.

    Usage:
    ```
    file, MockFile = mock_file()
    # Now the object returned by h5py.File() is `file`
    monkeypatch.setattr(h5py, "File", MockFile)
    [...]
    file.create_virtual_dataset.assert_called_once()
    ```
    """

    file = MagicMock()

    def wrapped():
        class MockFile:
            def __init__(self, name: str, mode: str) -> None:
                self.filename = name

            def __enter__(self):
                return file

            def __exit__(self, exc_type, exc_value, traceback):
                pass

        # @contextlib.contextmanager
        # def MockFile(name: str, mode: str):
        #     yield file

        return file, MockFile

    return wrapped


def test_configure():
    channels = {
        "cafe": cafe_channel,
        "no_save": (
            (
                FrameSource(
                    getter_name="getNoSave",
                    frame_type=FrameType.DENSE,
                    saving_channel="no_saving",
                    label=None,
                ),
                FrameInfo(num_channels=1, width=1, height=4, pixel_type=np.int64),
                mock_saving_params(base_path="/no_save", enabled=False),
            )
        ),
        "beef": (
            (
                FrameSource(
                    getter_name="getBeef",
                    frame_type=FrameType.SPARSE,
                    saving_channel="saving_beef",
                    label=None,
                ),
                FrameInfo(num_channels=1, width=1, height=4, pixel_type=np.int64),
                mock_saving_params(base_path="/beef", enabled=True),
            )
        ),
        "volatile": (
            (
                FrameSource(
                    getter_name="getVolatile",
                    frame_type=FrameType.DENSE,
                    saving_channel=None,
                    label=None,
                ),
                FrameInfo(num_channels=1, width=1, height=4, pixel_type=np.int64),
                None,
            )
        ),
    }

    mfd = master_file.configure(channels=channels)

    assert "cafe" in mfd
    assert "beef" not in mfd  # SPARSE
    assert "no_save" not in mfd  # Saving disabled in saving params
    assert "volatile" not in mfd  # No saving params

    assert mfd["cafe"].base_path == "/cafe"
    assert mfd["cafe"].filename_prefix == "limacafe"
    assert mfd["cafe"].master_file_path == "/cafe/limacafe_master.h5"
    assert mfd["cafe"].frame_info == channels["cafe"][1]
    assert mfd["cafe"].params == channels["cafe"][2]


def test_configure_no_overwrite(monkeypatch):
    """A master file already exists, but file_exists_policy != overwrite"""
    channels = {
        "no_overwrite": (
            (
                FrameSource(
                    getter_name="getCafe",
                    frame_type=FrameType.DENSE,
                    saving_channel="saving_cafe",
                    label=None,
                ),
                FrameInfo(num_channels=2, width=1024, height=2048, pixel_type=np.int16),
                mock_saving_params(
                    base_path="/no_overwrite",
                    enabled=True,
                    file_exists_policy="abort",
                ),
            )
        ),
    }

    monkeypatch.setattr(os.path, "exists", lambda _: True)

    with pytest.raises(RuntimeError):
        master_file.configure(channels=channels)


@pytest.mark.asyncio
async def test_master_file_generator(mock_file, monkeypatch):
    mfg = master_file.MasterFileGenerator()

    mfg.prepare(frame_channels={"cafe": cafe_channel}, metadata={"cafe": "deca"})
    file, MockFile = mock_file()

    monkeypatch.setattr(h5py, "File", MockFile)
    mock_write_metadata = Mock()
    monkeypatch.setattr(master_file, "write_metadata", mock_write_metadata)

    lut = LookupTable(size_hint=16, num_receivers=1)

    await lut.build(frame_idx_iterator=single_receiver_fidx_iterator(num_frames=16))

    await mfg.write_master_files(num_receivers=1, lut=lut)

    file.create_virtual_dataset.assert_called_once()
    mock_write_metadata.assert_called_once()


def test_indexer():
    idxr = master_file.Indexer(
        file_size=10,
        base_path="/cafe",
        filename_prefix="deca",
        datapath="a/b/c/data",
        frame_info=FrameInfo(
            num_channels=3, width=1024, height=2048, pixel_type=np.float16
        ),
    )

    for i in range(9):
        idxr.index(frame_idx=i)
    assert idxr.num_indexed == 0

    assert len(idxr.vsources) == 0

    idxr.index(frame_idx=9)
    assert len(idxr.vsources) == 1
    _, vsource = idxr.vsources[0]
    assert vsource.path == "/cafe/deca_00000.h5"
    assert vsource.name == "a/b/c/data"
    assert vsource.shape == (10, 3, 2048, 1024)
    assert idxr.num_indexed == 10

    idxr.index(frame_idx=10)
    idxr.flush()
    assert len(idxr.vsources) == 2
    _, vsource = idxr.vsources[1]
    assert vsource.path == "/cafe/deca_00001.h5"
    assert vsource.name == "a/b/c/data"
    assert vsource.shape == (1, 3, 2048, 1024)
    assert idxr.num_indexed == 11


@pytest.mark.asyncio
@pytest.mark.parametrize("num_frames", [1, 3, 9, 16, 25, 27, 127, 256, 999])
async def test_build_index(num_frames):
    lut = LookupTable(size_hint=num_frames, num_receivers=4)
    rcv_ordering = [3, 1, 2, 0]
    await lut.build(
        frame_idx_iterator=round_robin_fidx_iterator(
            num_frames=num_frames, ordering=rcv_ordering
        )
    )

    indexers = await master_file.build_index(
        num_receivers=4,
        lookup_table=lut,
        frame_info=cafe_channel[1],
        base_path="/cafe",
        filename_prefix="deca",
        datapath="a/b/c/data",
        frames_per_file=10,
    )

    for rcv_idx, indexer in enumerate(indexers):
        for indices, vsource in indexer.vsources:
            assert np.all(indices % 4 == rcv_ordering[rcv_idx])
            file_idx = indices[0] // 10 // 4
            assert vsource.path == f"/cafe/deca_{rcv_idx}_{file_idx:05d}.h5"


@pytest.mark.asyncio
async def test_build_index_dynamic():
    num_receivers = 3
    reception_order = np.array([0, 2, 1, 2, 1, 1, 1, 1, 2, 0, 2, 2])
    lut = LookupTable(size_hint=reception_order.size, num_receivers=num_receivers)
    await lut.build(
        frame_idx_iterator=dynamic_dispatch_fidx_iterator(
            num_receivers=num_receivers, receiver_list=reception_order
        )
    )

    indexers = await master_file.build_index(
        num_receivers=num_receivers,
        lookup_table=lut,
        frame_info=cafe_channel[1],
        base_path="/cafe",
        filename_prefix="deca",
        datapath="a/b/c/data",
        frames_per_file=2,
    )

    assert len(indexers) == 3
    i0, i1, i2 = indexers
    # receiver 0 gets frames 0 and 9
    assert len(i0.vsources) == 1
    idx, vsrc = i0.vsources[0]
    npt.assert_equal(idx, [0, 9])
    assert vsrc.path == "/cafe/deca_0_00000.h5"

    # receiver 1 gets frames 2, 4, 5, 6, 7
    assert len(i1.vsources) == 3  # 5 // 2 + 5 % 2
    idx, vsrc = i1.vsources[0]
    npt.assert_equal(idx, [2, 4])
    assert vsrc.path == "/cafe/deca_1_00000.h5"
    idx, vsrc = i1.vsources[1]
    npt.assert_equal(idx, [5, 6])
    assert vsrc.path == "/cafe/deca_1_00001.h5"
    idx, vsrc = i1.vsources[2]
    npt.assert_equal(idx, [7])
    assert vsrc.path == "/cafe/deca_1_00002.h5"

    # receiver 2 gets frames 1, 3, 8, 10, 11
    assert len(i2.vsources) == 3
    idx, vsrc = i2.vsources[0]
    npt.assert_equal(idx, [1, 3])
    assert vsrc.path == "/cafe/deca_2_00000.h5"
    idx, vsrc = i2.vsources[1]
    npt.assert_equal(idx, [8, 10])
    assert vsrc.path == "/cafe/deca_2_00001.h5"
    idx, vsrc = i2.vsources[2]
    npt.assert_equal(idx, [11])
    assert vsrc.path == "/cafe/deca_2_00002.h5"


@pytest.mark.asyncio
@pytest.mark.parametrize("num_frames", [1, 3, 9, 16, 25, 27, 127, 256, 999])
async def test_build_layout(num_frames):
    lut = LookupTable(size_hint=num_frames, num_receivers=1)
    await lut.build(
        frame_idx_iterator=single_receiver_fidx_iterator(num_frames=num_frames)
    )

    await master_file.build_layout(
        num_receivers=1,
        lookup_table=lut,
        frame_info=cafe_channel[1],
        params=cafe_channel[2],
    )


def test_write_virtual_dataset():
    file = MagicMock()

    master_file.write_virtual_dataset(
        file=file,
        nx_entry_name="entry_1234",
        nx_instrument_name="cafe_instrument",
        nx_detector_name="cafe_camera",
        layout=Mock(),
    )

    file.create_virtual_dataset.assert_called_once()


def test_write_metadata(mock_file, monkeypatch):
    mf, MockFile = mock_file()
    monkeypatch.setattr(h5py, "File", MockFile)

    monkeypatch.setattr(os.path, "exists", lambda _: True)
    master_file.write_metadata(
        master_file=mf,
        nx_entry_name="cafe!",
        nx_instrument_name="deca!",
        nx_detector_name="mmmm!",
        metadata=master_file.MasterFileMetadata(
            acq_params={"hello": "acq", "answer": 1},
            proc_params={"hello": "proc", "answer": 2},
            det_info={"hello": "info", "answer": [1, 2, 3]},
        ),
    )

    mf.__getitem__.assert_called_with("cafe!")
    mf["cafe!"].__getitem__.assert_called_with("deca!")
    mf["cafe!"]["deca!"].__getitem__.assert_called_with("mmmm!")
    mf["cafe!"]["deca!"]["mmmm!"].__getitem__.assert_called_with("plot")

    mf["cafe!"]["deca!"]["mmmm!"].create_group.assert_any_call(name="params")
    mf["cafe!"]["deca!"]["mmmm!"].create_group.assert_any_call(name="info")


def test_determine_layout_shape():
    assert master_file.determine_layout_shape(
        num_frames=42,
        frame_info=FrameInfo(num_channels=1, width=16, height=32, pixel_type=int),
        nb_dimensions="dim_4d",
    ) == (42, 1, 32, 16)

    assert master_file.determine_layout_shape(
        num_frames=42,
        frame_info=FrameInfo(num_channels=1, width=16, height=32, pixel_type=int),
        nb_dimensions="dim_3d_or_4d",
    ) == (42, 32, 16)

    assert master_file.determine_layout_shape(
        num_frames=42,
        frame_info=FrameInfo(num_channels=3, width=16, height=32, pixel_type=int),
        nb_dimensions="dim_3d_or_4d",
    ) == (42, 3, 32, 16)

    assert master_file.determine_layout_shape(
        num_frames=42,
        frame_info=FrameInfo(num_channels=0, width=16, height=32, pixel_type=int),
        nb_dimensions="dim_3d_or_4d",
    ) == (42, 0, 32, 16)

    with pytest.raises(ValueError):
        master_file.determine_layout_shape(
            num_frames=42,
            frame_info=FrameInfo(num_channels=1, width=16, height=32, pixel_type=int),
            nb_dimensions="abcdef",
        )
