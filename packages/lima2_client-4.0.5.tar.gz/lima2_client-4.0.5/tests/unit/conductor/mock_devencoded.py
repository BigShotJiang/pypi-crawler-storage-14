"""Utility functions to generate devencoded-style data structures."""

import struct

from lima2.common.devencoded import structured_array as sa


def structured_array_header(
    magic=sa.DATA_MAGIC,
    version=1,
    header_size=sa.DATA_HEADER_SIZE,
    category=0,
    data_type=0,
    endianness=0,
    nb_dim=1,
    dim1=1,
    dim2=1,
    dim3=1,
    dim4=1,
    dim5=1,
    dim6=1,
    dim_step1=1,
    dim_step2=1,
    dim_step3=1,
    dim_step4=1,
    dim_step5=1,
    dim_step6=1,
    frame_idx=0,
):
    """Generate a header for a roi statistics frame."""
    return struct.pack(
        sa.DATA_HEADER_FORMAT,
        magic,
        version,
        header_size,
        category,
        data_type,
        endianness,
        nb_dim,
        dim1,
        dim2,
        dim3,
        dim4,
        dim5,
        dim6,
        dim_step1,
        dim_step2,
        dim_step3,
        dim_step4,
        dim_step5,
        dim_step6,
        frame_idx,
    )
