# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for the pipelines subpackage (lima2/conductor/processing/__init__.py)"""

import pytest
from lima2.conductor import processing


def test_processing_get_by_name_nominal():
    for name in ["Legacy", "Smx", "Xpcs", "Failing"]:
        pipeline_class = processing.pipeline_classes[f"LimaProcessing{name}"]
        assert pipeline_class.TANGO_CLASS == f"LimaProcessing{name}"


def test_processing_get_by_name_invalid():
    with pytest.raises(KeyError):
        _ = processing.pipeline_classes["LimaProcessingInvalid"]
