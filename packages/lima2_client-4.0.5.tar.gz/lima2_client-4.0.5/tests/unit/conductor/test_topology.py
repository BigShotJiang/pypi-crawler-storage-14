# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for topology logic (lima2/conductor/topology.py)"""

import asyncio
from unittest.mock import Mock, call
import numpy as np
import pytest

from lima2.common.exceptions import Lima2LookupError
from lima2.conductor.topology import (
    DynamicDispatch,
    FrameMapping,
    LookupTable,
    RoundRobin,
    SingleReceiver,
)

###############################################################################
# Topology subclasses
###############################################################################


def test_single_receiver():
    _ = SingleReceiver()


def test_round_robin_lookup():
    # Monotonic ordering
    _ = RoundRobin(num_receivers=4, ordering=[0, 1, 2, 3])
    _ = RoundRobin(num_receivers=4, ordering=[0, 3, 2, 1])


def test_dynamic_dispatch():
    _ = DynamicDispatch(num_receivers=13)


@pytest.mark.asyncio
async def test_lookup_table_build_iteration():
    mapping = [
        FrameMapping(receiver_idx=mr, local_idx=ml, frame_idx=mg)
        for mr, ml, mg in [
            (0, 0, 0),
            (1, 0, 1),
            (0, 1, 3),  # Note skipped one frame
            (1, 1, 2),
            (0, 2, 4),
            (1, 2, 5),
            (0, 3, 6),
            (1, 3, 7),
            (0, 4, 8),
        ]
    ]

    lut = LookupTable(size_hint=8, num_receivers=2)

    assert np.all(lut.lut == lut.UNKNOWN)

    lut._build_iteration(mapping=mapping[0])

    assert np.all(lut.lut[0] == (0, 0))
    assert np.all(lut.lut[1] == (LookupTable.UNKNOWN, LookupTable.UNKNOWN))
    assert lut.rlut[0, 0] == 0
    assert lut.num_contiguous() == 1

    assert lut.lookup(0) == mapping[0].receiver_idx
    with pytest.raises(Lima2LookupError):
        lut.lookup(1)
    with pytest.raises(Lima2LookupError):
        lut.lookup(8)

    lut._build_iteration(mapping=mapping[1])
    lut._build_iteration(mapping=mapping[2])  # non-contigous frame idx
    assert lut.num_contiguous() == 2
    assert np.all(lut.lut[1] == (1, 0))
    assert np.all(lut.lut[2] == (LookupTable.UNKNOWN, LookupTable.UNKNOWN))
    assert np.all(lut.lut[3] == (0, 1))
    assert lut.rlut[1, 0] == 3

    for i in range(3, 8):
        lut._build_iteration(mapping=mapping[i])

    assert lut.num_contiguous() == 8

    # Resize condition
    assert lut.lut.shape[0] == 8
    assert lut.rlut.shape[0] == 4

    lut._build_iteration(mapping=mapping[8])

    assert lut.lut.shape[0] == 16
    assert lut.rlut.shape[0] == 8


@pytest.mark.asyncio
async def test_lookup_table_build_loop(monkeypatch):
    mapping = [(i % 2, i // 2, i) for i in range(8)]

    async def fidx_stream():
        for mr, ml, mg in mapping:
            yield FrameMapping(mr, ml, mg)

    lut = LookupTable(size_hint=8, num_receivers=2)
    mock_build_iteration = Mock()
    monkeypatch.setattr(lut, "_build_iteration", mock_build_iteration)

    notified = False

    async def listen():
        nonlocal notified
        async with lut.new_data_cond:
            await lut.new_data_cond.wait()
        notified = True

    listen_task = asyncio.create_task(listen())
    await asyncio.sleep(0)  # Yield to listen_task so it waits

    await lut.build(frame_idx_iterator=fidx_stream())

    assert lut.build_done.is_set()

    await asyncio.wait_for(listen_task, timeout=0.1)
    assert notified

    mock_build_iteration.assert_has_calls(
        [call(FrameMapping(mr, ml, mg)) for mr, ml, mg in mapping]
    )


@pytest.mark.asyncio
async def test_lookup_table_build_loop_exception(monkeypatch):
    mapping = [(i % 2, i // 2, i) for i in range(8)]

    async def fidx_stream():
        for mr, ml, mg in mapping:
            yield FrameMapping(mr, ml, mg)

    lut = LookupTable(size_hint=8, num_receivers=2)

    class TestError(Exception):
        pass

    def mock_build_iteration(_):
        raise TestError()

    monkeypatch.setattr(lut, "_build_iteration", mock_build_iteration)

    with pytest.raises(TestError):
        await lut.build(fidx_stream())

    assert lut.build_done.is_set()


@pytest.mark.asyncio
async def test_lookup_table_iterate():
    lut = LookupTable(size_hint=8, num_receivers=2)

    mappings = [FrameMapping(receiver_idx=0, local_idx=0, frame_idx=0)]
    mappings_received = []

    async def iterate():
        async for mx in lut.iterate():
            mappings_received.append(mx)

    iterate_task = asyncio.create_task(iterate())

    # Add a frame
    lut._build_iteration(mappings[0])
    # Notify the task
    async with lut.new_data_cond:
        lut.new_data_cond.notify_all()

    # Yield to the task
    await asyncio.sleep(0)

    # Now the iterator has yielded one frame mapping
    # and is waiting for new data or end of build
    assert mappings_received == [mappings[0]]

    # Say acquisition is done after 1 frame
    lut.build_done.set()
    async with lut.new_data_cond:
        lut.new_data_cond.notify_all()

    await iterate_task
    assert mappings_received == [mappings[0]]

    # Repeat assuming size_hint == num_frames
    # This only tests the case where
    lut = LookupTable(size_hint=1, num_receivers=2)
    mappings = [
        FrameMapping(receiver_idx=0, local_idx=0, frame_idx=0),
        FrameMapping(receiver_idx=1, local_idx=0, frame_idx=1),
    ]
    mappings_received = []
    iterate_task = asyncio.create_task(iterate())

    lut._build_iteration(mappings[0])
    lut._build_iteration(mappings[1])

    async with lut.new_data_cond:
        lut.new_data_cond.notify_all()

    await asyncio.sleep(0)

    assert mappings_received == [mappings[0], mappings[1]]

    lut.build_done.set()
    async with lut.new_data_cond:
        lut.new_data_cond.notify_all()

    await iterate_task
    assert mappings_received == [mappings[0], mappings[1]]


def test_lookup_table_reverse_lookup():
    lut = LookupTable(size_hint=4, num_receivers=2)
    # Add a frame
    lut._build_iteration(FrameMapping(receiver_idx=0, local_idx=0, frame_idx=0))
    lut._build_iteration(FrameMapping(receiver_idx=1, local_idx=0, frame_idx=1))
    lut._build_iteration(FrameMapping(receiver_idx=0, local_idx=1, frame_idx=2))

    # No overflow
    assert np.all(
        lut.reverse_lookup(receiver_idx=0, from_idx=0, num_frames=3)
        == [0, 2, LookupTable.UNKNOWN]
    )
    assert np.all(
        lut.reverse_lookup(receiver_idx=1, from_idx=0, num_frames=3)
        == [1, LookupTable.UNKNOWN, LookupTable.UNKNOWN]
    )
    # Partial overflow
    assert np.all(
        lut.reverse_lookup(receiver_idx=0, from_idx=0, num_frames=5)
        == [0, 2, LookupTable.UNKNOWN, LookupTable.UNKNOWN, LookupTable.UNKNOWN]
    )
    # Full overflow
    assert np.all(
        lut.reverse_lookup(receiver_idx=0, from_idx=2, num_frames=2)
        == [LookupTable.UNKNOWN, LookupTable.UNKNOWN]
    )

    with pytest.raises(IndexError):
        # No receiver #2
        lut.reverse_lookup(receiver_idx=2, from_idx=0, num_frames=1)


@pytest.mark.asyncio
async def test_lookup_table_wait_reverse_lookup():
    lut = LookupTable(size_hint=4, num_receivers=2)
    lut._build_iteration(FrameMapping(receiver_idx=0, local_idx=0, frame_idx=0))
    lut._build_iteration(FrameMapping(receiver_idx=1, local_idx=0, frame_idx=1))
    lut._build_iteration(FrameMapping(receiver_idx=0, local_idx=1, frame_idx=2))

    # Lookup OK
    rl = await asyncio.wait_for(
        lut.wait_reverse_lookup(receiver_idx=0, from_idx=0, num_frames=2), timeout=0.01
    )
    assert np.all(rl == [0, 2])

    # Lookup hangs
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(
            lut.wait_reverse_lookup(receiver_idx=0, from_idx=0, num_frames=3),
            timeout=0.01,
        )


@pytest.mark.asyncio
async def test_lookup_table_wait_reverse_lookup_impossible():
    """
    A reverse lookup is attempted before the LUT is complete,
    But then, the frame idx iterator ends early and
    the LUT cannot be built up to the chunk's highest frame idx.

    In this case, reverse lookup will never return and
    we should cancel the feeding loop.
    """

    mapping = [(0, 0, 0), (1, 0, 1), (2, 0, 32000)]

    async def fidx_stream():
        for mr, ml, mg in mapping:
            yield FrameMapping(mr, ml, mg)

    lut = LookupTable(size_hint=4, num_receivers=2)

    task = asyncio.create_task(
        lut.wait_reverse_lookup(receiver_idx=0, from_idx=0, num_frames=2)
    )

    try:
        await lut.build(fidx_stream())
    except Exception:
        pass

    with pytest.raises(RuntimeError):
        # Reverse lookup should raise
        await asyncio.wait_for(task, timeout=0.01)
