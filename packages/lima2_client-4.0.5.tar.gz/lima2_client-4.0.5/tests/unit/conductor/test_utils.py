# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for utility functions (lima2/conductor/utils.py)"""

import asyncio
import json

import numpy as np
import pytest

from lima2.conductor.utils import (
    frame_info_to_shape_dtype,
    get_subschema,
    list_to_jsonpath,
    naturalsize,
    naturaltime,
    to_async,
    validate,
)


def test_validate():
    schema = json.dumps(
        {
            "$schema": "http://json-schema.org/draft-06/schema#",
            "type": "object",
            "properties": {"nb_frames": {"type": "integer"}, "pi": {"type": "number"}},
        }
    )

    params = {
        "nb_frames": 4.0,
        "pi": 4,
    }

    params = {
        "nb_frames": 4,
        "pi": 4,
    }
    # 4 is an int AND a number
    validate(instance=params, schema=schema)

    params = {
        "nb_frames": 4,
        "pi": 3.14,
    }
    # 4 is an int, 3.14 is a number
    validate(instance=params, schema=schema)


def test_get_subschema():
    assert get_subschema(
        schema={
            "properties": {
                "cafe": {"items": {"properties": {"deca": {"type": "string"}}}}
            }
        },
        path=[
            "properties",
            "cafe",
            "items",
            "properties",
            "deca",
        ],
    ) == {"type": "string"}

    assert (
        get_subschema(
            schema={
                "properties": {
                    "cafe": {
                        "items": {
                            "properties": {"deca": {"type": "integer", "minimum": 0}}
                        }
                    }
                }
            },
            path=["properties", "cafe", "items", "properties", "deca", "minimum"],
        )
        == 0
    )

    with pytest.raises(KeyError):
        get_subschema(schema={}, path=["properties"])

    assert get_subschema(schema={"properties": 123}, path=["properties"]) == 123


def test_list_to_jsonpath():
    assert list_to_jsonpath(["store", "books", 0, "title"]) == "$.store.books[0].title"


def test_frame_info_to_shape_dtype():
    shape_dtype = frame_info_to_shape_dtype(
        frame_info={
            "nb_channels": 3,
            "dimensions": {
                "x": 64,
                "y": 32,
            },
            "pixel_type": "gray32",
        }
    )
    assert shape_dtype["shape"] == (3, 32, 64)
    assert shape_dtype["dtype"] == np.uint32


def test_frame_info_to_shape_dtype_bad_type():
    with pytest.raises(KeyError):
        frame_info_to_shape_dtype(
            frame_info={
                "nb_channels": 3,
                "dimensions": {
                    "x": 32,
                    "y": 64,
                },
                "pixel_type": "cafedeca",
            }
        )


def test_naturalsize():
    assert naturalsize(1) == "1.00 B"
    assert naturalsize(1023, decimal_places=0) == "1023 B"
    assert naturalsize(1024, decimal_places=1) == "1.0 kiB"
    assert naturalsize(1024 * 1024 + 1024, decimal_places=3) == "1.001 MiB"
    assert naturalsize(1024**3, decimal_places=1) == "1.0 GiB"
    assert naturalsize(1024**4, decimal_places=1) == "1.0 TiB"
    assert naturalsize(1024**5, decimal_places=1) == "1.0 PiB"


def test_naturaltime():
    assert naturaltime(1e-12, decimal_places=2) == "1.00e-03 ns"
    assert naturaltime(1e-9, decimal_places=3) == "1.000 ns"
    assert naturaltime(1e-6) == "1.0 µs"
    assert naturaltime(1e-3) == "1.0 ms"
    assert naturaltime(0.1, decimal_places=0) == "100 ms"
    assert naturaltime(1) == "1.0 s"
    assert naturaltime(59, decimal_places=0) == "59 s"
    assert naturaltime(60, decimal_places=1) == "1.0 min"
    assert naturaltime(60 * 30, decimal_places=1) == "30.0 min"
    assert naturaltime(60 * 60, decimal_places=3) == "1.000 hrs"
    assert naturaltime(60 * 60 * 24, decimal_places=1) == "24.0 hrs"


@pytest.mark.asyncio
async def test_to_async():
    def helloworld(x: int) -> int:
        return x + 1

    async_helloworld = to_async(helloworld)

    assert asyncio.iscoroutinefunction(async_helloworld)
    assert await async_helloworld(123) == 124
