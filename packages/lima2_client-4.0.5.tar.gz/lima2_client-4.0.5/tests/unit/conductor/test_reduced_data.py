# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for reduced_data module (lima2/conductor/processing/reduced_data.py)"""

import asyncio
import struct
from unittest.mock import Mock

import numpy as np
import numpy.testing as npt
import pytest

from lima2.common.devencoded import structured_array
from lima2.common.exceptions import Lima2BackendError, Lima2NotFound
from lima2.conductor.processing import reduced_data
from lima2.conductor.topology import FrameMapping, LookupTable
from .mock_devencoded import structured_array_header

mock_roi_stats_params = {
    "enabled": True,
    "rect_rois": [
        {"topleft": {"x": 123, "y": 456}, "dimensions": {"x": 128, "y": 128}},
        {"topleft": {"x": 654, "y": 321}, "dimensions": {"x": 64, "y": 64}},
    ],
    "arc_rois": [
        {
            "center": {"x": 987, "y": 654},
            "r1": 150,
            "r2": 200,
            "a1": 45,
            "a2": 135,
        }
    ],
}

mock_profile_params = {
    "enabled": True,
    "rois": [
        {"topleft": {"x": 123, "y": 123}, "dimensions": {"x": 64, "y": 256}},
        {"topleft": {"x": 456, "y": 456}, "dimensions": {"x": 11, "y": 44}},
        {"topleft": {"x": 789, "y": 789}, "dimensions": {"x": 99, "y": 111}},
    ],
    "directions": [
        "vertical",
        "horizontal",
        "vertical",
    ],
}


def test_parse_roi_params():
    rois, profiles = reduced_data.parse_roi_params(
        roi_params=mock_roi_stats_params, profile_params=mock_profile_params
    )

    assert len(rois) == 3
    assert len(profiles) == 3

    assert profiles[0].length == 256
    assert profiles[1].length == 11
    assert profiles[2].length == 111


def test_data_source():
    cafe = reduced_data.ScalarDataSource(
        getter_name="getCafe",
        src_dtype=np.dtype([("deca", np.float128), ("idx", np.uint64)]),
        channel_keys=["deca"],
        num_elements=4,
    )

    assert cafe.total_length() == 4
    assert cafe.shapes() == [(), (), (), ()]
    assert cafe.stream_descriptions() == [(np.dtype([("deca", np.float128)]), ())] * 4
    chunk = np.array([[(0.1, 0), (0.2, 0), (0.3, 0), (0.4, 0)]], dtype=cafe.src_dtype)
    assert chunk.shape == (1, 4)  # 1 frame, 4 elements

    split_chunk = list(cafe.split(chunk=chunk))
    assert len(split_chunk) == 4
    for sc in split_chunk:
        assert sc.dtype["deca"] == np.float128
        assert sc.shape == (1,)

    vcafe = reduced_data.VectorDataSource(
        getter_name="getVCafe",
        src_dtype=np.dtype([("deca", np.float128), ("idx", np.uint64)]),
        channel_keys=["deca"],
        lengths=[1, 3, 5],
    )

    assert vcafe.total_length() == 9  # 1 + 3 + 5
    assert vcafe.shapes() == [(1,), (3,), (5,)]
    assert vcafe.stream_descriptions() == [
        (np.dtype([("deca", np.float128)]), (1,)),
        (np.dtype([("deca", np.float128)]), (3,)),
        (np.dtype([("deca", np.float128)]), (5,)),
    ]
    chunk = np.array(
        [
            [
                (0.1, 0),
                (0.2, 0),
                (0.3, 0),
                (0.4, 0),
                (0.5, 0),
                (0.6, 0),
                (0.7, 0),
                (0.8, 0),
                (0.9, 0),
            ]
        ],
        dtype=vcafe.src_dtype,
    )
    assert chunk.shape == (1, 9)  # 1 frame, 9 elements

    split_chunk = list(vcafe.split(chunk=chunk))
    assert len(split_chunk) == 3
    assert split_chunk[0].shape == (1, 1)
    assert split_chunk[0]["deca"].dtype == np.float128
    npt.assert_equal(split_chunk[0]["deca"], [[0.1]])

    assert split_chunk[1].shape == (1, 3)
    assert split_chunk[1]["deca"].dtype == np.float128
    npt.assert_equal(split_chunk[1]["deca"], [[0.2, 0.3, 0.4]])

    assert split_chunk[2].shape == (1, 5)
    assert split_chunk[2]["deca"].dtype == np.float128
    npt.assert_equal(split_chunk[2]["deca"], [[0.5, 0.6, 0.7, 0.8, 0.9]])


class MockProcessingDevice:
    def __init__(self):
        self.cafe = structured_array_header()
        self.vector_cafe = structured_array_header()
        self.pop_fidx_iteration = 0

    def set_cafe(self, payload: bytes):
        self.cafe = structured_array_header() + payload

    def set_vector_cafe(self, payload: bytes):
        self.vector_cafe = structured_array_header() + payload

    async def pop_reduced_data(self, getter_name: str) -> tuple[str, bytes]:
        if getter_name == "popCafe":
            cafe = self.cafe
            self.cafe = structured_array_header()
            return ("STRUCTURED_ARRAY", cafe)
        elif getter_name == "popVectorCafe":
            vector_cafe = self.vector_cafe
            self.vector_cafe = structured_array_header()
            return ("STRUCTURED_ARRAY", vector_cafe)
        elif getter_name == "popFrameIdx":
            if self.pop_fidx_iteration < 4:
                payload = np.array(
                    [(i, i) for i in range(256)],
                    dtype=reduced_data.FRAME_IDX_DTYPE,
                )
                self.pop_fidx_iteration += 1
                return (
                    "STRUCTURED_ARRAY",
                    structured_array_header() + payload.tobytes(),
                )
            else:
                return (
                    "STRUCTURED_ARRAY",
                    structured_array_header()
                    + np.array(
                        [],
                        dtype=reduced_data.FRAME_IDX_DTYPE,
                    ).tobytes(),
                )
        else:
            raise RuntimeError(f"No reduced data '{getter_name}'")


cafe_source = reduced_data.ScalarDataSource(
    getter_name="popCafe",
    src_dtype=np.dtype(
        [
            ("frame_idx", np.int32),
            ("milk", np.int32),
            ("sugar", np.float64),
        ]
    ),
    channel_keys=["milk", "sugar"],
    num_elements=3,
)

vector_cafe_source = reduced_data.VectorDataSource(
    getter_name="popVectorCafe",
    src_dtype=np.dtype(
        [
            ("frame_idx", np.int32),
            ("milk", np.int32),
            ("sugar", np.float64),
        ]
    ),
    channel_keys=["milk", "sugar"],
    lengths=[2, 3],
)

beef_source = reduced_data.ScalarDataSource(
    getter_name="popBeef",
    src_dtype=np.dtype(
        [
            ("frame_idx", np.int32),
            ("steak", np.float32),
        ]
    ),
    channel_keys=["steak"],
    num_elements=1,
)


def mock_cafe(num_frames: int, start_frame: int, count: int, stride=1) -> bytes:
    payload = [
        (i, -1 * i, 1.0 * i + j)
        for i in range(start_frame, start_frame + num_frames * stride, stride)
        for j in range(count)
    ]

    pack_fmt = "iid" * count
    flat_payload = sum(payload, start=())

    return struct.pack(pack_fmt * num_frames, *flat_payload)


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_reduced_data_fetcher(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    close_evt = asyncio.Event()
    rdf = reduced_data.ReducedDataFetcher(
        name="cafe",
        devices=devices,
        source=cafe_source,
        fetch_interval_s=0.01,
        close_request=close_evt,
    )

    for i, dev in enumerate(devices):
        dev.set_cafe(mock_cafe(num_frames=1, start_frame=i, count=3))

    await rdf.pop_decode_iteration(close_request=close_evt)

    chunks = await asyncio.wait_for(rdf.chunk_queue.get(), timeout=0.01)
    rdf.chunk_queue.task_done()

    assert len(chunks) == len(devices)

    for i, chunk in enumerate(chunks):
        assert np.all(chunk["frame_idx"] == i)
        assert np.all(chunk["milk"] == -i)

    for i, dev in enumerate(devices):
        dev.set_cafe(mock_cafe(num_frames=1, start_frame=i, count=3))

    rdf.close_request.set()

    at_idx = 0
    async for chunks in rdf.schunks():
        assert len(chunks) == len(devices)
        for chunk in chunks:
            assert np.all(chunk["frame_idx"] == at_idx)
            at_idx += 1


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_reduced_data_automatic_abort(num_receivers, monkeypatch):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    close_evt = asyncio.Event()
    rdf = reduced_data.ReducedDataFetcher(
        name="qweqwe",
        devices=devices,
        source=cafe_source,
        fetch_interval_s=0.01,
        close_request=close_evt,
    )

    # Simulate a device error
    with monkeypatch.context() as mp:

        async def bad_pop(*args, **kwargs):
            raise RuntimeError("Couldn't pop!")

        mp.setattr(devices[-1], "pop_reduced_data", bad_pop)

        with pytest.raises(Lima2BackendError):
            await rdf.pop_decode_iteration(close_request=close_evt)

    # Simulate a decode error
    with monkeypatch.context() as mp:

        def bad_decode(*args, **kwargs):
            raise RuntimeError("Couldn't decode!")

        mp.setattr(structured_array, "decode", bad_decode)

        with pytest.raises(Lima2BackendError):
            await rdf.pop_decode_iteration(close_request=close_evt)


def test_prepare():
    devices = [MockProcessingDevice() for _ in range(4)]
    rdf = reduced_data.ReducedData(devices=devices)
    lut = LookupTable(size_hint=64, num_receivers=len(devices))

    rdf.prepare(
        size_hint=64,
        lookup=lut,
        roi_stats_params=mock_roi_stats_params,
        profile_params=mock_profile_params,
        static_sources={
            "cafe": cafe_source,
            "vector_cafe": vector_cafe_source,
            "beef": beef_source,
        },
        fetch_interval_s=0.01,
    )

    assert "cafe" in rdf.sources
    assert "vector_cafe" in rdf.sources
    assert "beef" in rdf.sources
    assert "roi_stats" in rdf.sources
    assert "roi_profile" in rdf.sources

    # Check all expected reduced data streams have been allocated
    for name in [
        "cafe",
        "vector_cafe",
        "beef",
        "roi_stats",
        "roi_profile",
    ]:
        assert name in rdf.pipelines

    assert len(rdf.pipelines["cafe"].buffers) == 3
    assert rdf.pipelines["cafe"].buffers[0].shape == (64,)
    assert rdf.pipelines["cafe"].buffers[1].shape == (64,)
    assert rdf.pipelines["cafe"].buffers[2].shape == (64,)

    assert rdf.pipelines["vector_cafe"].buffers[0].shape == (64, 2)
    assert rdf.pipelines["vector_cafe"].buffers[1].shape == (64, 3)

    assert rdf.pipelines["roi_stats"].buffers[0].shape == (64,)
    assert rdf.pipelines["roi_stats"].buffers[1].shape == (64,)
    assert rdf.pipelines["roi_stats"].buffers[2].shape == (64,)

    assert rdf.pipelines["roi_profile"].buffers[0].shape == (64, 256)
    assert rdf.pipelines["roi_profile"].buffers[1].shape == (64, 11)
    assert rdf.pipelines["roi_profile"].buffers[2].shape == (64, 111)


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_dynamic_index(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    rd = reduced_data.ReducedData(devices=devices)

    rd.close_request.set()
    idx = rd.dynamic_index(fetch_interval_s=0.01)

    async for mx in idx:
        pass


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_start(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    rd = reduced_data.ReducedData(devices=devices)
    lut = LookupTable(size_hint=64, num_receivers=len(devices))

    rd.prepare(
        size_hint=64,
        lookup=lut,
        roi_stats_params=mock_roi_stats_params,
        profile_params=mock_profile_params,
        static_sources={
            "cafe": cafe_source,
            "vector_cafe": vector_cafe_source,
            "beef": beef_source,
        },
        fetch_interval_s=0.01,
    )

    rd.start()

    with pytest.raises(RuntimeError):
        rd.start()

    await rd.close()


@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
def test_reduced_data_pipeline(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    lut = LookupTable(size_hint=64, num_receivers=len(devices))
    close_evt = asyncio.Event()

    rdp = reduced_data.ReducedDataPipeline(
        name="beef",
        size_hint=64,
        devices=devices,
        close_request=close_evt,
        source=beef_source,
        lookup=lut,
        fetch_interval_s=0.01,
    )
    assert np.all(rdp.empty)

    indices = np.arange(0, 33)
    chunk = np.array(
        [[(fidx * num_receivers, float(fidx))] for fidx in indices],
        dtype=beef_source.src_dtype,
    )

    rdp.store_chunk(indices=indices, chunk=chunk)

    assert not np.any(rdp.empty[indices])

    # Expand buffers
    assert rdp.empty.size == 64
    assert rdp.buffers[0].shape[0] == 64

    rdp.store_chunk(indices=indices + 33, chunk=chunk)
    assert rdp.empty.size == 128
    assert rdp.buffers[0].shape[0] == 128


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_reduced_data_pipeline_lookup(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    lut = LookupTable(size_hint=64, num_receivers=len(devices))
    close_evt = asyncio.Event()

    rdp = reduced_data.ReducedDataPipeline(
        name="beef",
        size_hint=64,
        devices=devices,
        close_request=close_evt,
        source=beef_source,
        lookup=lut,
        fetch_interval_s=0.01,
    )

    indices = np.arange(0, 33)
    chunk = np.array(
        [[(fidx * num_receivers, float(fidx))] for fidx in indices],
        dtype=beef_source.src_dtype,
    )
    for i in range(33 * num_receivers):
        lut._build_iteration(
            FrameMapping(
                receiver_idx=i % num_receivers,
                local_idx=i // num_receivers,
                frame_idx=i,
            )
        )

    result = await rdp.lookup_chunk(rcv_idx=0, from_idx=0, chunk=chunk)
    assert np.all(result == indices * num_receivers)

    assert np.all(await rdp.lookup_chunk(rcv_idx=0, from_idx=0, chunk=chunk[:0]) == [])


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_reduced_data_pipeline_consume(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    lut = LookupTable(size_hint=64, num_receivers=len(devices))
    close_evt = asyncio.Event()

    rdp = reduced_data.ReducedDataPipeline(
        name="beef",
        size_hint=64,
        devices=devices,
        close_request=close_evt,
        source=beef_source,
        lookup=lut,
        fetch_interval_s=0.01,
    )

    indices = np.arange(0, 7)
    chunk = np.array(
        [[(fidx * num_receivers, float(fidx))] for fidx in indices],
        dtype=beef_source.src_dtype,
    )

    rdp.store_chunk(indices=indices, chunk=chunk)

    rdp.done_event.set()

    chunks = []
    async for x in rdp.consume(channel_idx=0):
        chunks.append(x)

    assert len(chunks) == 1
    assert np.all(chunks[0]["steak"] == chunk["steak"].flatten())


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_reduced_data_pipeline_feed_loop(num_receivers, monkeypatch):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    lut = LookupTable(size_hint=64, num_receivers=len(devices))
    close_evt = asyncio.Event()

    rdp = reduced_data.ReducedDataPipeline(
        name="beef",
        size_hint=64,
        devices=devices,
        close_request=close_evt,
        source=beef_source,
        lookup=lut,
        fetch_interval_s=0.01,
    )

    indices = np.arange(0, 7)

    async def mock_schunks():
        for i in range(1):
            yield [
                np.array(
                    [[(i + fidx * num_receivers, float(fidx))] for fidx in indices],
                    dtype=beef_source.src_dtype,
                )
                for i in range(num_receivers)
            ]

    for i in range(7 * num_receivers):
        lut._build_iteration(
            FrameMapping(
                receiver_idx=i % num_receivers,
                local_idx=i // num_receivers,
                frame_idx=i,
            )
        )

    monkeypatch.setattr(rdp.fetcher, "schunks", mock_schunks)

    task = asyncio.create_task(rdp.feed_loop())
    await asyncio.sleep(0)

    async with rdp.consume_cond:
        rdp.consume_cond.notify_all()

    await asyncio.wait_for(task, timeout=0.1)

    npt.assert_equal(
        rdp.buffers[0]["steak"][: 7 * num_receivers],
        np.repeat(np.arange(0, 7, dtype=np.float32), num_receivers),
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_close(num_receivers):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    rd = reduced_data.ReducedData(devices=devices)

    await rd.close()


@pytest.mark.asyncio
@pytest.mark.parametrize("num_receivers", [1, 2, 3, 4, 8, 16])
async def test_stream(num_receivers, monkeypatch):
    devices = [MockProcessingDevice() for _ in range(num_receivers)]
    rd = reduced_data.ReducedData(devices=devices)

    rd.prepare(
        size_hint=64,
        lookup=LookupTable(size_hint=64, num_receivers=num_receivers),
        roi_stats_params={},
        profile_params={},
        static_sources={
            "cafe": cafe_source,
        },
        fetch_interval_s=0.01,
    )
    chinfo = rd.channel_info()
    assert "cafe" in chinfo
    rd.close_request.set()

    with pytest.raises(Lima2NotFound):
        rd.stream(name="badstream", channel_idx=0)

    with pytest.raises(Lima2NotFound):
        rd.stream(name="cafe", channel_idx=3)

    mock_consume = Mock()
    monkeypatch.setattr(rd.pipelines["cafe"], "consume", mock_consume)

    _ = rd.stream(name="cafe", channel_idx=0)
    mock_consume.assert_called_once()
