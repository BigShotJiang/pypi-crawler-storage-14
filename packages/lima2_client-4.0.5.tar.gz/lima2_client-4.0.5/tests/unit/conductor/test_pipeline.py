# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for pipeline module (lima2/conductor/processing/pipeline.py)"""

import asyncio
import random
import weakref
from typing import Any
from unittest.mock import AsyncMock, Mock, call
from uuid import uuid1

import pytest

from lima2.common.exceptions import Lima2LookupError, Lima2NotFound, Lima2ValueError
from lima2.common.types import FrameType
from lima2.conductor.processing import failing, legacy, smx, xpcs
from lima2.conductor.processing.master_file import MasterFileDescription
from lima2.conductor.processing.pipeline import (
    FrameSource,
    Pipeline,
    round_robin_frame_iterator,
    single_receiver_frame_iterator,
)
from lima2.conductor.tango.processing import FrameInfo, ProcessingErrorEvent
from lima2.conductor.topology import (
    DynamicDispatch,
    FrameMapping,
    LookupTable,
    RoundRobin,
    SingleReceiver,
)


class CafePipeline(Pipeline):
    REDUCED_DATA_SOURCES = {}
    FRAME_SOURCES = {
        "cafedeca": FrameSource(
            getter_name="get_frame",
            frame_type=FrameType.DENSE,
            saving_channel=None,
            label=None,
        ),
        "empty": FrameSource(
            getter_name="get_no_frame",
            frame_type=FrameType.DENSE,
            saving_channel=None,
            label=None,
        ),
        "input_frame": FrameSource(
            getter_name="get_input_frame",
            frame_type=FrameType.DENSE,
            saving_channel=None,
            label=None,
        ),
        "sparse": FrameSource(
            getter_name="get_sparse_frame",
            frame_type=FrameType.SPARSE,
            saving_channel=None,
            label=None,
        ),
        "progressive": FrameSource(
            getter_name="get_progressive",
            frame_type=FrameType.DENSE,
            saving_channel=None,
            label="progressive",
        ),
        "cool": FrameSource(
            getter_name="get_cool",
            frame_type=FrameType.DENSE,
            saving_channel=None,
            label="cool",
        ),
        "saved": FrameSource(
            getter_name="get_saved",
            frame_type=FrameType.DENSE,
            saving_channel="saving",
            label="saved",
        ),
    }
    TANGO_CLASS = "LimaProcessingMock"
    PROGRESS_INDICATOR = "nb_frames_cool"


class MockProcessingDevice:
    """Mock TangoProcessing."""

    REDUCED_DATA = {"roi_stats": b"a roi stat !"}

    def __init__(self, name: str):
        self.name = name
        self._progress_counters: dict[str, int] = {}
        """Mutable dict of progress counters available to get from this device."""

        self._last_frames: dict[str, int] = {}
        """Mutable dict of last frame idx available to get from this device."""

        self.on_finished_callback = None
        self.on_error_callback = None

    async def ping(self) -> int:
        return 1337

    async def progress_counters(self) -> dict[str, int]:
        return self._progress_counters

    async def last_frames(self) -> dict[str, int]:
        return self._last_frames

    async def raw_frame_info(self) -> dict[str, Any]:
        return {
            "nb_channels": 3,
            "dimensions": {"x": 2048, "y": 1024},
            "pixel_type": "gray8",
        }

    async def input_frame_info(self) -> dict[str, Any]:
        return {
            "nb_channels": "yes",
            "dimensions": {"x": 420, "y": 69},
            "pixel_type": "gray32f",
        }

    async def processed_frame_info(self) -> dict[str, Any]:
        return {
            "nb_channels": "maybe",
            "dimensions": {"x": 69, "y": 420},
            "pixel_type": "gray16",
        }

    async def on_finished(self, callback):
        self.on_finished_callback = callback

    async def on_error(self, callback):
        self.on_error_callback = callback

    async def signal_finished(self):
        if self.on_finished_callback is not None:
            await self.on_finished_callback(self)

    async def signal_error(self, event: ProcessingErrorEvent):
        if self.on_finished_callback is not None:
            await self.on_error_callback(event)


processing_factory = pytest.mark.parametrize(
    "processing_factory",
    [
        # NOTE: we have to wrap a lambda around the processings
        # so that they are instantiated once every test.
        lambda: [MockProcessingDevice(name=f"proc_{i}") for i in range(1)],
        lambda: [MockProcessingDevice(name=f"proc_{i}") for i in range(4)],
        lambda: [MockProcessingDevice(name=f"proc_{i}") for i in range(9)],
        lambda: [MockProcessingDevice(name=f"proc_{i}") for i in range(16)],
    ],
)


@pytest.fixture
def processing_devices():
    # proc_devs = [Mock(spec=MockProcessingDevice) for _ in range(2)]
    proc_devs = [MockProcessingDevice(name=f"proc_{i}") for i in range(2)]

    return proc_devs


@pytest.fixture
def mock_pipeline(processing_factory):
    """Instantiate a MockPipeline using mock devices, assuming RoundRobin.

    Requires @processing_factory decorator on the test.
    """
    processing_devices = processing_factory()
    return CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=RoundRobin(
            num_receivers=len(processing_devices),
            ordering=range(len(processing_devices)),
        ),
    )


def test_constructor_single():
    """Construct a single-receiver Pipeline object."""
    processing_devices = [MockProcessingDevice(name="proc_0")]
    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=SingleReceiver(),
    )

    assert type(proc.topology) is SingleReceiver


@processing_factory
def test_constructor_dynamic(processing_factory):
    """Construct a single-receiver Pipeline object."""
    processing_devices = processing_factory()
    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=DynamicDispatch(num_receivers=len(processing_devices)),
    )

    assert type(proc.topology) is DynamicDispatch


def test_bad_subclass():
    with pytest.raises(ValueError):

        class NoFrameSourcePipeline(Pipeline):
            TANGO_CLASS = "badcafe"
            REDUCED_DATA_SOURCES = {}
            PROGRESS_INDICATOR = "cafe"
            # Missing FRAME_SOURCES

    with pytest.raises(ValueError):

        class NoTangoClassPipeline(Pipeline):
            FRAME_SOURCES = {}
            REDUCED_DATA_SOURCES = {}
            PROGRESS_INDICATOR = "cafe"
            # Missing TANGO_CLASS

    with pytest.raises(ValueError):

        class NoReducedDataSourcePipeline(Pipeline):
            TANGO_CLASS = "helloworld"
            FRAME_SOURCES = {}
            PROGRESS_INDICATOR = "cafe"
            # Missing REDUCED_DATA_SOURCES

    with pytest.raises(ValueError):

        class NoProgressIndicatorPipeline(Pipeline):
            TANGO_CLASS = "helloworld"
            FRAME_SOURCES = {}
            REDUCED_DATA_SOURCES = {}
            # Missing PROGRESS_INDICATOR


@pytest.mark.asyncio
async def test_single_receiver_frame_iterator():
    dev = MockProcessingDevice(name="only_dev")

    dev._progress_counters = {"nb_frames_source": 123}
    stop_evt = asyncio.Event()
    stop_evt.set()

    at_idx = 0
    async for mx in single_receiver_frame_iterator(
        device=dev, fetch_interval_s=0.01, stop_evt=stop_evt
    ):
        assert mx == FrameMapping(receiver_idx=0, local_idx=at_idx, frame_idx=at_idx)
        at_idx += 1


@pytest.mark.asyncio
@processing_factory
async def test_round_robin_frame_iterator(processing_factory):
    processing_devices: list[MockProcessingDevice] = processing_factory()
    num_receivers = len(processing_devices)

    for dev in processing_devices:
        dev._progress_counters = {"nb_frames_source": 123}

    stop_evt = asyncio.Event()
    stop_evt.set()

    ordering_seq = list(range(len(processing_devices)))
    ordering_mixed = (
        ordering_seq[: num_receivers // 2] + ordering_seq[num_receivers // 2 :]
    )

    at_idx = 0
    async for mx in round_robin_frame_iterator(
        devices=processing_devices,
        ordering=ordering_mixed,
        fetch_interval_s=0.01,
        stop_evt=stop_evt,
    ):
        assert mx == FrameMapping(
            receiver_idx=ordering_mixed[at_idx % num_receivers],
            local_idx=at_idx // num_receivers,
            frame_idx=at_idx,
        )
        at_idx += 1


@pytest.mark.asyncio
@processing_factory
async def test_frame_idx_iterator(processing_factory, monkeypatch):
    processing_devices: list[MockProcessingDevice] = processing_factory()
    for dev in processing_devices:
        dev._progress_counters = {"nb_frames_source": 4}

    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=RoundRobin(
            num_receivers=len(processing_devices),
            ordering=range(len(processing_devices)),
        ),
    )

    stop_evt = asyncio.Event()
    stop_evt.set()

    at_idx = 0
    async for mx in proc.frame_idx_iterator(fetch_interval_s=0.01, stop_evt=stop_evt):
        assert mx == FrameMapping(
            receiver_idx=proc.topology.ordering[at_idx % len(processing_devices)],
            local_idx=at_idx // len(processing_devices),
            frame_idx=at_idx,
        )
        at_idx += 1

    proc.topology = SingleReceiver()
    at_idx = 0
    async for mx in proc.frame_idx_iterator(fetch_interval_s=0.01, stop_evt=stop_evt):
        assert mx == FrameMapping(
            receiver_idx=0,
            local_idx=at_idx,
            frame_idx=at_idx,
        )
        at_idx += 1

    async def mock_dynamic_index(fetch_interval_s: float):
        cursors = [0 for _ in processing_devices]
        at_idx = 0
        for _ in range(123):
            rcv_idx = random.randint(0, len(processing_devices) - 1)
            yield FrameMapping(
                receiver_idx=rcv_idx, local_idx=cursors[rcv_idx], frame_idx=at_idx
            )
            at_idx += 1
            cursors[rcv_idx] += 1

    proc.topology = DynamicDispatch(num_receivers=len(processing_devices))
    monkeypatch.setattr(proc.reduced_data, "dynamic_index", mock_dynamic_index)
    async for mx in proc.frame_idx_iterator(fetch_interval_s=0.01, stop_evt=stop_evt):
        pass


@pytest.mark.asyncio
@processing_factory
async def test_event_callbacks(processing_factory, monkeypatch):
    processing_devices: list[MockProcessingDevice] = processing_factory()

    on_pipeline_finished = AsyncMock()
    on_error = AsyncMock()

    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=RoundRobin(
            num_receivers=len(processing_devices),
            ordering=range(len(processing_devices)),
        ),
    )

    mock_raw_frame_info = AsyncMock()
    mock_input_frame_info = AsyncMock()
    mock_processed_frame_info = AsyncMock()

    monkeypatch.setattr(processing_devices[0], "raw_frame_info", mock_raw_frame_info)
    monkeypatch.setattr(
        processing_devices[0], "input_frame_info", mock_input_frame_info
    )
    monkeypatch.setattr(
        processing_devices[0], "processed_frame_info", mock_processed_frame_info
    )

    await proc.populate()
    await proc.attach(on_finished=on_pipeline_finished, on_error=on_error)

    mock_raw_frame_info.assert_awaited()
    mock_input_frame_info.assert_awaited()
    mock_processed_frame_info.assert_awaited()

    for dev in processing_devices:
        assert not proc.is_running()
        await dev.signal_finished()
    on_pipeline_finished.assert_has_awaits([call()] * len(processing_devices))
    assert not proc.is_running()

    await processing_devices[0].signal_error(
        ProcessingErrorEvent(
            device_name="cafedeca",
            what="had a problem",
            info="abcdef",
        )
    )

    assert len(proc.errors) == 1
    assert "had a problem" in proc.errors[0]
    assert "cafedeca" in proc.errors[0]
    assert "abcdef" in proc.errors[0]

    on_error.assert_called_once()
    assert "had a problem" in proc.errors[-1]
    assert "cafedeca" in proc.errors[-1]
    assert "abcdef" in proc.errors[-1]

    proc.unregister()
    assert proc.on_error_callback != on_error
    assert proc.on_finished_callback != on_pipeline_finished

    proc_ref = weakref.ref(proc)
    assert proc_ref() is not None

    # Drop main reference
    proc = None
    # No internal references remain (caused by usage of `self` in callbacks)
    assert proc_ref() is None


@pytest.mark.asyncio
async def test_progress_counters(processing_devices):
    """Read progress_counters."""
    processing_devices[0]._progress_counters = {
        "nb_frames_cool": 42,
        "nice_counter": 4,
        "evil_counter": -13,
    }
    processing_devices[1]._progress_counters = {
        "nb_frames_cool": 43,
        "nice_counter": 3,
        "evil_counter": -37,
    }

    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=RoundRobin(
            num_receivers=len(processing_devices),
            ordering=range(len(processing_devices)),
        ),
    )

    pc = await proc.progress_counters()

    assert len(pc) == 3
    assert set(pc.keys()) == {
        "nb_frames_cool",
        "nice_counter",
        "evil_counter",
    }

    # channel progress
    cool_progress = await proc.channel_progress(channel="cool")
    assert cool_progress.sum == 42 + 43

    # label is None
    cafedeca_progress = await proc.channel_progress(channel="cafedeca")
    assert cafedeca_progress == cool_progress

    with pytest.raises(Lima2NotFound):
        await proc.channel_progress(channel="nowaythisexists")


@pytest.mark.asyncio
@processing_factory
async def test_prepare_start(mock_pipeline):
    mock_pipeline.frame_infos = {
        "cafedeca": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "empty": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "input_frame": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "sparse": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "progressive": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "cool": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "saved": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
    }

    mock_pipeline.reduced_data = Mock()

    mock_pipeline.prepare(
        acq_params={"acq": {"nb_frames": 12}},
        proc_params={
            "statistics": {"enabled": False},
            "profiles": {"enabled": False},
            "saving": {
                "base_path": "",
                "filename_prefix": "",
                "file_exists_policy": "",
                "nb_frames_per_file": "",
                "nx_entry_name": "",
                "nx_instrument_name": "",
                "nx_detector_name": "",
                "nb_dimensions": "",
                "enabled": "",
            },
        },
        det_info={},
    )
    mock_pipeline.reduced_data.prepare.assert_called_once()

    mock_pipeline.start()
    mock_pipeline.reduced_data.start.assert_called_once()

    mock_pipeline.reduced_data.channel_info.return_value = {
        "cafe": 123,
        "deca": 456,
    }
    assert mock_pipeline.reduced_data_channels() == {"cafe": 123, "deca": 456}


@pytest.mark.asyncio
@processing_factory
async def test_prepare_raw_saving(mock_pipeline):
    mock_pipeline.frame_infos = {
        "cafedeca": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "empty": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "input_frame": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "sparse": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "progressive": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "cool": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "saved": FrameInfo(num_channels=1, width=512, height=256, pixel_type=int),
        "raw_frame": FrameInfo(
            num_channels=42, width=512, height=256, pixel_type=float
        ),
    }

    mock_pipeline.reduced_data = Mock()
    mock_pipeline.master_file_generator = Mock()

    acq_params = {
        "acq": {"nb_frames": 12},
        "saving": {
            "base_path": "",
            "filename_prefix": "",
            "file_exists_policy": "",
            "nb_frames_per_file": "",
            "nx_entry_name": "",
            "nx_instrument_name": "",
            "nx_detector_name": "",
            "nb_dimensions": "",
            "enabled": "",
        },
    }
    proc_params = {
        "statistics": {"enabled": False},
        "profiles": {"enabled": False},
        "saving": {
            "base_path": "",
            "filename_prefix": "",
            "file_exists_policy": "",
            "nb_frames_per_file": "",
            "nx_entry_name": "",
            "nx_instrument_name": "",
            "nx_detector_name": "",
            "nb_dimensions": "",
            "enabled": "",
        },
    }
    mock_pipeline.prepare(
        acq_params=acq_params,
        proc_params=proc_params,
        det_info={},
    )
    master_file_prepare = mock_pipeline.master_file_generator.prepare
    master_file_prepare.assert_called_once()

    fchannels = master_file_prepare.mock_calls[0].kwargs["frame_channels"]
    fsource, finfo, fsav = fchannels["raw_frame"]
    assert fsource.label == "raw"
    assert fsource.frame_type == FrameType.DENSE
    assert fsource.saving_channel == "raw"

    assert finfo.num_channels == 42
    assert finfo.width == 512
    assert finfo.height == 256
    assert finfo.pixel_type is float


@pytest.mark.asyncio
@processing_factory
async def test_close(mock_pipeline):
    async def lut_loop():
        while True:
            if mock_pipeline.close_event.is_set():
                break
            await asyncio.sleep(0.01)

    mock_pipeline.lut_task = asyncio.create_task(lut_loop())
    mock_pipeline.master_file_task = asyncio.create_task(lut_loop())

    await mock_pipeline.close()


@processing_factory
def test_master_files(mock_pipeline):
    mock_pipeline.master_file_generator.mfd = {
        "mock_saved": MasterFileDescription(
            base_path=None,
            master_file_path="/abc/def/mock_saved.h5",
            filename_prefix="",
            frame_info=None,
            params={
                "nx_entry_name": "/cafe_0000",
                "nx_instrument_name": "ESRF-ID69",
                "nx_detector_name": "maxideca",
            },
        )
    }
    assert mock_pipeline.master_files() == {
        "mock_saved": ("/abc/def/mock_saved.h5", "/cafe_0000/ESRF-ID69/maxideca/data")
    }


@processing_factory
def test_lookup(processing_factory):
    processing_devices = processing_factory()
    num_receivers = len(processing_devices)
    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=RoundRobin(
            num_receivers=num_receivers,
            ordering=range(num_receivers),
        ),
    )

    proc.lut = LookupTable(size_hint=32, num_receivers=num_receivers)
    for i in range(32):
        proc.lut._build_iteration(
            mapping=FrameMapping(
                receiver_idx=i % num_receivers,
                local_idx=i // num_receivers,
                frame_idx=i,
            )
        )

    for i in range(32):
        assert proc.lookup(i) == processing_devices[i % num_receivers].name


@pytest.mark.asyncio
async def test_lookup_last_single():
    processing_devices = [MockProcessingDevice(name="proc_0")]
    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=SingleReceiver(),
    )

    processing_devices[0]._progress_counters = {
        "nb_frames_processed": 0,
    }
    assert await proc.lookup_last() == "proc_0"

    processing_devices[0]._progress_counters = {
        "nb_frames_processed": 123123,
    }
    assert await proc.lookup_last() == "proc_0"


@pytest.mark.asyncio
@processing_factory
async def test_lookup_last_round_robin(processing_factory):
    processing_devices = processing_factory()
    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=RoundRobin(
            num_receivers=len(processing_devices),
            ordering=range(len(processing_devices)),
        ),
    )

    for dev in processing_devices:
        dev._last_frames = {"processed_idx": -1}

    with pytest.raises(Lima2LookupError):
        # No frames yet -> lookup fails
        await proc.lookup_last()

    for dev in processing_devices:
        dev._last_frames = {"processed_idx": 4}
    rcv_url = await proc.lookup_last()
    # 4 frames each -> last frame is on last receiver
    assert rcv_url == processing_devices[-1].name

    # First receiver has 1 more frame
    processing_devices[0]._last_frames["processed_idx"] += 1
    rcv_url = await proc.lookup_last()
    assert rcv_url == processing_devices[0].name


@pytest.mark.asyncio
@processing_factory
async def test_lookup_last_dynamic(processing_factory):
    processing_devices = processing_factory()
    dd = DynamicDispatch(num_receivers=len(processing_devices))
    proc = CafePipeline(
        uuid=uuid1(),
        devices=processing_devices,
        topology=dd,
    )

    for dev in processing_devices:
        dev._last_frames = {"processed_idx": -1}
    with pytest.raises(Lima2LookupError):
        await proc.lookup_last()

    for dev in processing_devices:
        dev._last_frames = {"processed_idx": 0}
    # Priority to the last receiver
    assert await proc.lookup_last() == processing_devices[-1].name

    processing_devices[0]._last_frames = {"processed_idx": 1}
    assert await proc.lookup_last() == processing_devices[0].name


def test_legacy_finalize_params():
    rcv_idx = 1337

    proc_params = {
        "class_name": "LimaProcessingMock",
        "🍉": {"filename_rank": 0},  # Processing saving (FRAME_SOURCE.saving_channel)
        "saving": {"filename_rank": 0, "include_frame_idx": False},
        "frame_idx_enabled": False,
    }

    legacy.finalize_params(
        proc_params=proc_params,
        receiver_idx=rcv_idx,
        topology=SingleReceiver(),
    )

    assert not proc_params["frame_idx_enabled"]
    assert proc_params["saving"]["filename_rank"] == rcv_idx
    assert not proc_params["saving"]["include_frame_idx"]

    legacy.finalize_params(
        proc_params=proc_params,
        receiver_idx=rcv_idx,
        topology=DynamicDispatch(num_receivers=4),
    )

    assert proc_params["frame_idx_enabled"]
    assert proc_params["saving"]["include_frame_idx"]


def test_smx_finalize_params():
    rcv_idx = 3

    proc_params = {
        "class_name": "LimaProcessingMock",
        "🍉": {"filename_rank": 0},  # Processing saving (FRAME_SOURCE.saving_channel)
        "saving_dense": {"filename_rank": 0, "include_frame_idx": False},
        "saving_sparse": {"filename_rank": 0, "include_frame_idx": False},
        "saving_accumulation_corrected": {},
        "saving_accumulation_peak": {},
        "fai": {"acc_nb_frames_reset": 12, "acc_nb_frames_xfer": 12},
        "frame_idx_enabled": False,
    }

    smx.finalize_params(
        proc_params=proc_params,
        receiver_idx=rcv_idx,
        num_receivers=4,
        topology=RoundRobin(num_receivers=4, ordering=[0, 1, 2, 3]),
    )

    assert not proc_params["frame_idx_enabled"]
    assert proc_params["saving_dense"]["filename_rank"] == rcv_idx
    assert not proc_params["saving_dense"]["include_frame_idx"]
    assert proc_params["saving_sparse"]["filename_rank"] == rcv_idx
    assert not proc_params["saving_sparse"]["include_frame_idx"]

    proc_params = {
        "class_name": "LimaProcessingMock",
        "🍉": {"filename_rank": 0},  # Processing saving (FRAME_SOURCE.saving_channel)
        "saving_dense": {"filename_rank": 0, "include_frame_idx": False},
        "saving_sparse": {"filename_rank": 0, "include_frame_idx": False},
        "saving_accumulation_corrected": {},
        "saving_accumulation_peak": {},
        "fai": {"acc_nb_frames_reset": 12, "acc_nb_frames_xfer": 12},
        "frame_idx_enabled": False,
    }

    smx.finalize_params(
        proc_params=proc_params,
        receiver_idx=rcv_idx,
        num_receivers=4,
        topology=DynamicDispatch(num_receivers=4),
    )

    assert proc_params["frame_idx_enabled"]
    assert proc_params["saving_dense"]["filename_rank"] == rcv_idx
    assert proc_params["saving_dense"]["include_frame_idx"]
    assert proc_params["saving_sparse"]["filename_rank"] == rcv_idx
    assert proc_params["saving_sparse"]["include_frame_idx"]

    proc_params = {
        "class_name": "LimaProcessingMock",
        "🍉": {"filename_rank": 0},  # Processing saving (FRAME_SOURCE.saving_channel)
        "saving_dense": {"filename_rank": 0, "include_frame_idx": False},
        "saving_sparse": {"filename_rank": 0, "include_frame_idx": False},
        "saving_accumulation_corrected": {},
        "saving_accumulation_peak": {},
        "fai": {"acc_nb_frames_reset": 123, "acc_nb_frames_xfer": 12},
        "frame_idx_enabled": False,
    }
    with pytest.raises(Lima2ValueError):
        smx.finalize_params(
            proc_params=proc_params,
            receiver_idx=rcv_idx,
            num_receivers=4,
            topology=SingleReceiver(),
        )


def test_xpcs_finalize_params():
    rcv_idx = 1337

    proc_params = {
        "class_name": "LimaProcessingMock",
        "🍉": {"filename_rank": 0},  # Processing saving (FRAME_SOURCE.saving_channel)
        "saving_dense": {"filename_rank": 0, "include_frame_idx": False},
        "saving_sparse": {"filename_rank": 0, "include_frame_idx": False},
        "frame_idx_enabled": False,
    }

    xpcs.finalize_params(
        proc_params=proc_params,
        receiver_idx=rcv_idx,
        topology=SingleReceiver(),
    )

    assert not proc_params["frame_idx_enabled"]
    assert proc_params["saving_dense"]["filename_rank"] == rcv_idx
    assert not proc_params["saving_dense"]["include_frame_idx"]
    assert proc_params["saving_sparse"]["filename_rank"] == rcv_idx
    assert not proc_params["saving_sparse"]["include_frame_idx"]

    xpcs.finalize_params(
        proc_params=proc_params,
        receiver_idx=rcv_idx,
        topology=DynamicDispatch(num_receivers=4),
    )

    assert proc_params["frame_idx_enabled"]
    assert proc_params["saving_dense"]["filename_rank"] == rcv_idx
    assert proc_params["saving_dense"]["include_frame_idx"]
    assert proc_params["saving_sparse"]["filename_rank"] == rcv_idx
    assert proc_params["saving_sparse"]["include_frame_idx"]


def test_failing_finalize_params():
    proc_params = {
        "class_name": "LimaProcessingMock",
        "🍉": {"filename_rank": 0},  # Processing saving (FRAME_SOURCE.saving_channel)
        "saving": {"filename_rank": 0, "include_frame_idx": False},
        "frame_idx_enabled": False,
    }

    failing.finalize_params(
        proc_params=proc_params,
        topology=SingleReceiver(),
    )

    with pytest.raises(Lima2ValueError):
        failing.finalize_params(
            proc_params=proc_params,
            topology=DynamicDispatch(num_receivers=4),
        )
