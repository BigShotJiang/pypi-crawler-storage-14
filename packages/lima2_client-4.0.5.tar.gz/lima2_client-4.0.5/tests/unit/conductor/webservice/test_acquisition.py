# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""
Test suite for the conductor /acquisition endpoints
(lima2/conductor/webservice/acquisition.py).
"""

import contextlib
import json
from typing import Any
from uuid import UUID, uuid1

import jsonschema_default
import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from lima2.common.exceptions import Lima2Conflict, Lima2ValueError
from lima2.common.progress_counter import ProgressCounter, SingleCounter
from lima2.conductor.acquisition import Acquisition
from lima2.conductor.acquisition_system import LocalState
from lima2.conductor.webservice import acquisition


async def noop() -> None:
    pass


async def noop_1(_) -> None:
    pass


class MockAcquisitionSystem:
    def __init__(self):
        self.prepare_called = False
        self.start_called = False
        self.trigger_called = False
        self.stop_called = False
        self.reset_called = False
        self.acquisition = None

        class MockControl:
            def fetch_params_schema(self) -> str:
                return json.dumps(
                    {
                        "type": "object",
                        "properties": {"cafe": {"type": "string", "default": "deca"}},
                    }
                )

        class MockReceiver:
            def fetch_params_schema(self) -> str:
                return json.dumps(
                    {
                        "type": "object",
                        "properties": {"cafe": {"type": "string", "default": "1234"}},
                    }
                )

        self.control = MockControl()
        self.receivers = [MockReceiver()]

        self.state: LocalState = LocalState.IDLE

    async def prepare(
        self,
        ctl_params: dict[str, Any],
        acq_params: dict[str, Any],
        proc_params: dict[str, Any],
    ) -> UUID:
        self.prepare_called = True
        self.ctl_params = ctl_params
        self.acq_params = acq_params
        self.proc_params = proc_params
        self.state = LocalState.READY
        self.acquisition = Acquisition(
            uuid=uuid1(),
            num_receivers=len(self.receivers),
            on_end=noop_1,
            on_failure=noop,
        )

        return self.acquisition.uuid

    async def start(self) -> None:
        self.start_called = True
        self.state = LocalState.RUNNING

    async def trigger(self) -> None:
        self.trigger_called = True

    async def stop(self) -> None:
        self.stop_called = True
        self.state = LocalState.IDLE

    async def reset(self) -> None:
        self.reset_called = True
        self.state = LocalState.IDLE

    async def nb_frames_acquired(self) -> SingleCounter:
        return SingleCounter(name="nb_frames_acquired", value=123, source="dev/control")

    async def nb_frames_xferred(self) -> ProgressCounter:
        return ProgressCounter(
            name="nb_frames_acquierd",
            counters=[
                SingleCounter(
                    name="nb_frames_xferred", value=42 + i, source=f"dev/receiver{i}"
                )
                for i in range(4)
            ],
        )

    async def errors(self) -> list[str]:
        return ["first error", "second error"]


@contextlib.asynccontextmanager
async def mock_lifespan(app: Starlette):
    lima2 = app.state.lima2
    yield {"lima2": lima2, "user_lock": app.state.user_lock}


class MyLock:
    def __init__(self):
        self._locked = False

    def lock(self):
        self._locked = True

    def unlock(self):
        self._locked = False

    def locked(self):
        return self._locked

    @contextlib.contextmanager
    def ctx(self):
        self.lock()
        yield
        self.unlock()

    async def __aenter__(self):
        pass

    async def __aexit__(self, exc_type, exc, tb):
        pass


lima2 = MockAcquisitionSystem()
app = Starlette(routes=acquisition.routes, lifespan=mock_lifespan)
app.state.lima2 = lima2
app.state.user_lock = MyLock()

ctl_params = {"hello": "world"}
acq_params = {"cafe": "deca"}
proc_params = {"bye": "now"}


def test_commands():
    """Test control route handlers."""

    with TestClient(app) as client:
        client.post(
            "/prepare",
            json={
                "uuid": str(uuid1()),
                "control": ctl_params,
                "receiver": acq_params,
                "processing": proc_params,
            },
        )
        client.post("/start")
        client.post("/trigger")

        client.post("/stop")
        client.post("/reset")

        with app.state.user_lock.ctx():
            with pytest.raises(Lima2Conflict):
                client.post("/prepare")

            with pytest.raises(Lima2Conflict):
                client.post("/start")

            with pytest.raises(Lima2Conflict):
                client.post("/stop")

            with pytest.raises(Lima2Conflict):
                client.post("/reset")

    assert lima2.prepare_called
    assert lima2.ctl_params == ctl_params
    assert lima2.acq_params == acq_params
    assert lima2.proc_params == proc_params

    assert lima2.start_called
    assert lima2.trigger_called
    assert lima2.stop_called
    assert lima2.reset_called


def test_control_prepare_missing_params():
    """Prepare with missing key."""

    with TestClient(app) as client:
        with pytest.raises(Lima2ValueError):
            _ = client.post(
                "/prepare",
                json={
                    "receiver": acq_params,
                    "processing": proc_params,
                },
            )


def test_params():
    with TestClient(app) as client:
        schema = client.get("/params_schema").json()
        params = client.get("/default_params").json()

        assert params["receiver"] == jsonschema_default.create_from(schema["receiver"])
        assert params["control"] == jsonschema_default.create_from(schema["control"])


def test_state():
    with TestClient(app) as client:
        lima2.acquisition = None
        failed = client.get("/failed")
        running = client.get("/running")
        assert not failed.json()
        assert not running.json()

        lima2.acquisition = Acquisition(
            uuid=uuid1(), num_receivers=4, on_end=noop_1, on_failure=noop
        )
        lima2.acquisition.state.rcv_failed = True
        lima2.acquisition.state.started = True
        failed = client.get("/failed")
        running = client.get("/running")
        assert failed.json()
        assert running.json()

        state = client.get("/state")
        assert type(state.json()) is str


def test_counters():
    with TestClient(app) as client:
        nb_frames_acquired = client.get("/nb_frames_acquired").json()
        nb_frames_xferred = client.get("/nb_frames_xferred").json()

    assert nb_frames_acquired == {
        "name": "nb_frames_acquired",
        "value": 123,
        "source": "dev/control",
    }

    for key in ("min", "max", "avg", "sum", "counters"):
        assert key in nb_frames_xferred


def test_errors():
    with TestClient(app) as client:
        errors = client.get("/errors").json()

    assert errors == ["first error", "second error"]
