# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""Test suite for the conductor utils module (lima2/conductor/webservice/utils.py)"""

import logging
import os
from logging import INFO, LogRecord
from logging.handlers import RotatingFileHandler
from pathlib import Path

import pytest

from lima2.conductor.webservice.utils import (
    ColoredFormatter,
    configure_logger,
    env_or,
    env_or_die,
)


@pytest.fixture(scope="module")
def env():
    os.environ["CAFE"] = "DECA"


def test_env_or(env):
    assert env_or("CAFE", "BEEF") == "DECA"
    assert env_or("DEAD", "BEEF") == "BEEF"


def test_env_or_die(env):
    assert env_or_die("CAFE") == "DECA"

    with pytest.raises(EnvironmentError):
        env_or_die("NO_WAY_THIS_IS_DEFINED")


def test_colored_formatter():
    f = ColoredFormatter()
    res = f.format(
        LogRecord(
            name="name",
            level=INFO,
            pathname=Path.cwd(),
            lineno=42,
            msg="hello %s!",
            args="world",
            exc_info=None,
        )
    )
    # No need to be too rigorous. It works, just cover format().
    assert "hello world" in res


def test_configure_logger():
    configure_logger(file_path="/tmp/hi.txt", stdout_log_level="WARNING")

    logger = logging.getLogger("lima2")
    assert len(logger.handlers) == 2

    sh = logger.handlers[0]
    fh = logger.handlers[1]

    assert isinstance(sh.formatter, ColoredFormatter)
    assert isinstance(fh, RotatingFileHandler)
    assert fh.baseFilename == "/tmp/hi.txt"
    assert sh.level == logging.WARNING
