# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""Test suite for the conductor /benchmark endpoints (lima2/conductor/webservice/benchmark.py)"""

import contextlib
from typing import Any
from uuid import UUID, uuid1

import numpy as np
import numpy.testing as npt
from starlette.applications import Starlette
from starlette.testclient import TestClient

from lima2.common import progress_counter
from lima2.common.progress_counter import ProgressCounter, SingleCounter
from lima2.conductor.webservice import benchmark
from lima2.conductor.webservice.benchmark_generators.rois import (
    roi_stats_dtype,
    roi_stats_generator,
)


class MockPipeline:
    async def progress_counters(self) -> dict[str, ProgressCounter]:
        return {
            "cafe": progress_counter.aggregate(
                [SingleCounter(name="cafe", value=i, source="cafe0") for i in range(16)]
            ),
            "deca": progress_counter.aggregate(
                [
                    SingleCounter(name="deca", value=i * 10, source="deca0")
                    for i in range(16)
                ]
            ),
        }


class MockAcquisitionSystem:
    def __init__(self):
        self.pipelines = {uuid1(): MockPipeline() for i in range(3)}

    async def list_pipelines(self) -> list[UUID]:
        return self.pipelines.keys()

    async def get_pipeline(self, uuid: UUID) -> MockPipeline:
        return self.pipelines[uuid]

    async def det_capabilities(self) -> dict[str, Any]:
        return {"det": "capabilities"}


@contextlib.asynccontextmanager
async def mock_lifespan(app: Starlette):
    lima2 = app.state.lima2
    yield {"lima2": lima2}


lima2 = MockAcquisitionSystem()
app = Starlette(routes=benchmark.routes, lifespan=mock_lifespan)
app.state.lima2 = lima2


def test_benchmark_roi_stats():
    """Test /benchmark/roi_stats route handler"""
    seed = 1337
    num_frames = 4
    num_rois = 3

    # Generate the data locally and compare with the one received via /roi_stats
    generator = roi_stats_generator(num_frames, num_rois, seed)

    with TestClient(app) as client:
        res = client.get(
            "/roi_stats",
            params={"num_frames": num_frames, "num_rois": num_rois, "seed": 1337},
        )

        for chunk in res.iter_bytes(
            chunk_size=np.dtype(roi_stats_dtype).itemsize * num_rois
        ):
            expected = np.frombuffer(next(generator), dtype=roi_stats_dtype)
            received = np.frombuffer(chunk, dtype=roi_stats_dtype)

            npt.assert_equal(received, expected)
