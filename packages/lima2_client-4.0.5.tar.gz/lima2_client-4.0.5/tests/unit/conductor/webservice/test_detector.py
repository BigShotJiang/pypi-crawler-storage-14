# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""Test suite for the conductor /detector endpoints (lima2/conductor/webservice/detector.py)"""

import contextlib
from typing import Any

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from lima2.conductor.webservice import detector


class MockControl:
    async def command(self, name: str, arg: int) -> int:
        if name == "doCafe":
            return arg + 42
        else:
            raise NotImplementedError

    async def read_attribute(self, name: str) -> int:
        return self.attribute

    async def write_attribute(self, name: str, value: int) -> None:
        self.attribute = value


class MockAcquisitionSystem:
    def __init__(self):
        # /detector/command, /detector/attribute access control directly
        self.control = MockControl()

    async def det_info(self) -> dict[str, Any]:
        return {"det": "info"}

    async def det_status(self) -> dict[str, Any]:
        return {"det": "status"}

    async def det_capabilities(self) -> dict[str, Any]:
        return {"det": "capabilities"}


@contextlib.asynccontextmanager
async def mock_lifespan(app: Starlette):
    lima2 = app.state.lima2
    yield {"lima2": lima2}


lima2 = MockAcquisitionSystem()
app = Starlette(routes=detector.routes, lifespan=mock_lifespan)
app.state.lima2 = lima2


def test_detector_routes():
    """Test /detector route handlers"""

    with TestClient(app) as client:
        info = client.get("/info").json()
        status = client.get("/status").json()
        capabilities = client.get("/capabilities").json()
        command_ret = client.post("/command", json={"name": "doCafe", "arg": 24}).json()
        client.post("/attribute/cafe", json=42)
        attr = client.get("/attribute/cafe").json()

        with pytest.raises(RuntimeError):
            # Missing arg
            command_ret = client.post("/command", json={"name": "doCafe"}).json()

    assert info == {"det": "info"}
    assert status == {"det": "status"}
    assert capabilities == {"det": "capabilities"}
    assert command_ret == 24 + 42
    assert attr == 42
