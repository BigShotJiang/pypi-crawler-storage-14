# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""
Test suite for the conductor '/' endpoints
(lima2/conductor/webservice/webapp.py) and lifespan, app creation.
"""

import json
from dataclasses import dataclass
from unittest.mock import Mock

import pytest
from starlette.testclient import TestClient

from lima2.common import exceptions
from lima2.common.exceptions import Lima2ParamError
from lima2.common.progress_counter import ProgressCounter, SingleCounter
from lima2.common.state import DeviceState, State
from lima2.conductor.acquisition_system import LocalState
from lima2.conductor.webservice import webapp


@dataclass
class MockControl:
    name: str

    async def ping(self) -> int:
        return 124


@dataclass
class MockReceiver:
    name: str

    async def ping(self) -> int:
        return 126


class MockAcquisitionSystem:
    def __init__(self):
        self.control = MockControl(name="control")
        self.receivers = [MockReceiver(name=f"rcv{i}") for i in range(4)]
        self.state = LocalState.IDLE

    async def ping_all(self):
        pass

    async def register_event_callbacks(self):
        pass

    async def global_state(self) -> State:
        return State.IDLE

    async def device_states(self) -> list[DeviceState]:
        return [
            DeviceState.IDLE,
            DeviceState.RUNNING,
            DeviceState.FAULT,
            DeviceState.RUNNING,
            DeviceState.RUNNING,
        ]

    async def nb_frames_acquired(self) -> SingleCounter:
        return SingleCounter(name="nb_frames_acquired", value=25, source="control")

    async def nb_frames_xferred(self) -> ProgressCounter:
        return ProgressCounter(
            name="nb_frames_xferred",
            counters=[
                SingleCounter(name="nb_frames_xferred", value=24 + i, source=f"rcv_{i}")
                for i in range(2)
            ],
        )


lima2 = MockAcquisitionSystem()


def test_webapp_create_app(monkeypatch):
    # Not super relevant to unit test
    app = webapp.create_app(lima2=lima2)
    assert "lima2" in app.state._state
    assert not app.debug


def test_webapp_handlers():
    app = webapp.create_app(lima2=lima2)

    with TestClient(app) as client:
        homepage = client.get("/").json()
        schema = client.get("/schema")  # noqa: F841
        state = client.get("/state").json()
        ping = client.post("/ping").json()  # noqa: F841

    assert "state" in homepage

    assert "state" in state
    assert "conductor" in state
    assert "devices" in state


@pytest.mark.asyncio
async def test_webapp_exception_handlers():
    exc = Lima2ParamError(":/", where="cafe deca", path="$.abc.def", schema={})
    res = await webapp.error_handler(request=Mock(), exception=exc)
    assert res.status_code == 400
    body = json.loads(res.body)
    assert body["code"] == exceptions.by_type[Lima2ParamError][0]
    assert body["message"] == ":/"
    assert "payload" in body
    assert "trace" in body
    assert "where" in body["payload"]
    assert "path" in body["payload"]
    assert "schema" in body["payload"]
