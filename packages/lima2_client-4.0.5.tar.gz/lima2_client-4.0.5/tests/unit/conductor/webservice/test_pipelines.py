# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.


"""Test suite for the conductor /pipelines endpoints (lima2/conductor/webservice/pipelines.py)"""

import contextlib
import json
from typing import Any, AsyncIterator, Literal
from uuid import UUID, uuid1

import numpy as np
import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from lima2.common import progress_counter
from lima2.common.exceptions import Lima2LookupError, Lima2NotFound
from lima2.common.progress_counter import ProgressCounter, SingleCounter
from lima2.conductor import processing
from lima2.conductor.processing.reduced_data import ROI_STATS_DTYPE
from lima2.conductor.tango.processing import FrameInfo
from lima2.conductor.webservice import pipeline, webapp


class MockPipeline:
    TANGO_CLASS: str = "MockPipeline"
    PROGRESS_INDICATOR = "cafe"

    def __init__(self, uuid: UUID):
        self.uuid = uuid
        self.frame_infos: dict[str, FrameInfo] = {
            "cafe_frame": FrameInfo(
                num_channels=3,
                width=1337,
                height=4096,
                pixel_type=np.dtype(np.float64),
            )
        }
        self.errors = ["first error", "second error"]

    async def channel_progress(self, channel: str) -> ProgressCounter:
        return (await self.progress_counters())[channel]

    async def progress_counters(self) -> dict[str, ProgressCounter]:
        return {
            "cafe": progress_counter.aggregate(
                [SingleCounter(name="cafe", value=i, source="cafe0") for i in range(16)]
            ),
            "deca": progress_counter.aggregate(
                [
                    SingleCounter(name="deca", value=i * 10, source="deca0")
                    for i in range(16)
                ]
            ),
        }

    def is_running(self):
        return False

    def master_files(self) -> dict[str, str]:
        return {
            "saved_1": "/path/to/master_file_1.h5",
            "saved_2": "/path/to/master_file_2.h5",
        }

    def reduced_data_channels(
        self,
    ) -> dict[str, list[tuple[np.dtype, tuple[int, ...]]]]:
        return {
            "stream": [(np.dtype([("cafe", np.int32), ("deca", np.uint16)]), (3,))],
            "roi_stats": [(ROI_STATS_DTYPE, (1,))],
        }

    def reduced_data_stream(self, name: str, channel_idx: int) -> AsyncIterator[bytes]:
        if name == "stream" and channel_idx == 0:

            async def stream() -> AsyncIterator[bytes]:
                for _ in range(16):
                    yield np.array([[1, 2, 3]], dtype=np.int32)

            return stream()
        else:
            raise NotImplementedError(f"{name}:{channel_idx}")

    def lookup(self, frame_idx: int) -> str:
        if frame_idx == 1337:
            raise Lima2LookupError("sorry but no frame")
        else:
            return "device_you_are_looking_for"

    async def lookup_last(self) -> str:
        return "device_with_last_frame"


class MockReceiver:
    def fetch_proc_schema(self, proc_class: str) -> str:
        return json.dumps(
            {
                "title": proc_class,
                "type": "object",
                "properties": {"cafe": {"type": "string", "default": "deca"}},
            }
        )


class MockAcquisitionSystem:
    def __init__(self) -> None:
        self.pipelines: dict[UUID, MockPipeline] = {}
        for _ in range(3):
            uuid = uuid1()
            self.pipelines[uuid] = MockPipeline(uuid=uuid)

        self.current_pipeline: MockPipeline | None = None

        self.receivers = [MockReceiver()]

    async def list_pipelines(self) -> list[UUID]:
        return list(self.pipelines.keys())

    async def get_pipeline(self, uuid: Literal["current"] | str | UUID) -> MockPipeline:
        if uuid == "current":
            if self.current_pipeline is not None:
                return self.current_pipeline
            else:
                raise Lima2NotFound("No current pipeline: call prepare first")
        elif type(uuid) is str:
            uuid = UUID(uuid)
        else:
            raise ValueError(uuid)

        return self.pipelines[uuid]

    async def det_capabilities(self) -> dict[str, Any]:
        return {"det": "capabilities"}

    async def nb_frames_xferred(self) -> ProgressCounter:
        return ProgressCounter.from_single(
            SingleCounter(name="nb_frames_xferred", value=42, source="raw_frame")
        )

    async def clear_previous_pipelines(self) -> list[str]:
        cleared: list[str] = []
        for uuid in list(self.pipelines.keys()):
            if self.current_pipeline and uuid != self.current_pipeline.uuid:
                cleared.append(str(uuid))
                self.pipelines.pop(uuid)

        return cleared


@contextlib.asynccontextmanager
async def mock_lifespan(app: Starlette):
    lima2 = app.state.lima2
    yield {"lima2": lima2}


lima2 = MockAcquisitionSystem()
app = Starlette(
    routes=pipeline.routes,
    lifespan=mock_lifespan,
    exception_handlers={Lima2LookupError: webapp.error_handler},
)
app.state.lima2 = lima2


def test_pipelines_routes():
    """Test /pipelines route handlers"""

    with TestClient(app) as client:
        # Pipeline instances
        pipeline_list = client.get("/").json()
        assert set(lima2.pipelines.keys()) == set(
            [UUID(uuid_str) for uuid_str in pipeline_list]
        )

        # By UUID
        pipelines_by_uuid = [
            client.get(f"/{name}").json() for name in lima2.pipelines.keys()
        ]
        for p in pipelines_by_uuid:
            assert "running" in p
            assert "progress_counters" in p

        # Progress
        progress_by_uuid = [
            client.get(f"/{name}/progress").json() for name in lima2.pipelines.keys()
        ]
        for p in progress_by_uuid:
            assert type(p) is int
            assert p == sum(range(16))

        progress_by_uuid = [
            client.get(f"/{name}/progress/cafe").json()
            for name in lima2.pipelines.keys()
        ]
        for p in progress_by_uuid:
            assert type(p) is int
            assert p == sum(range(16))

        progress_by_uuid = [
            client.get(f"/{name}/progress/raw_frame").json()
            for name in lima2.pipelines.keys()
        ]
        for p in progress_by_uuid:
            assert p == 42

        progress_counters_by_uuid = [
            client.get(f"/{name}/progress_counters").json()
            for name in lima2.pipelines.keys()
        ]
        for p in progress_counters_by_uuid:
            assert type(p) is dict
            assert "cafe" in p
            assert "deca" in p

        # No current pipeline
        with pytest.raises(Lima2NotFound):
            current_pipeline = client.get("/current").json()

        # Set current pipeline
        lima2.current_pipeline = lima2.pipelines[max(lima2.pipelines.keys())]
        current_pipeline = client.get("/current").json()
        assert UUID(current_pipeline["uuid"]) == lima2.current_pipeline.uuid

        # Clear pipelines
        cleared = client.post("/clear").json()["cleared"]
        assert lima2.pipelines == {lima2.current_pipeline.uuid: lima2.current_pipeline}
        assert lima2.current_pipeline.uuid not in cleared

        # Master files
        master_files = client.get(f"/{lima2.current_pipeline.uuid}/master_files").json()
        assert master_files == lima2.current_pipeline.master_files()

        # Data streams
        streams = client.get(f"/{lima2.current_pipeline.uuid}/reduced_data").json()
        rdc = lima2.current_pipeline.reduced_data_channels()
        for key, channels in streams.items():
            assert len(channels) == len(rdc[key]) == 1
            exp_dtype, exp_shape = rdc[key][0]
            for i, subtype in enumerate(exp_dtype.descr):
                assert tuple(channels[0]["dtype"][i]) == subtype
            assert tuple(channels[0]["shape"]) == exp_shape

        res = client.get(f"/{lima2.current_pipeline.uuid}/reduced_data/stream/0")
        assert res.content == b"\x01\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00" * 16

        # Pipeline classes
        pipeline_classes = client.get("/class").json()
        assert set(pipeline_classes) == set(processing.pipeline_classes)

        some_class = client.get(f"/class/{pipeline_classes[0]}").json()
        assert some_class["default_params"] == {"cafe": "deca"}

        with pytest.raises(Lima2NotFound):
            _ = client.get("/class/NotAClass")

        # Schema
        schema = client.get(f"/class/{pipeline_classes[0]}/schema").json()
        assert schema == json.loads(
            lima2.receivers[0].fetch_proc_schema(pipeline_classes[0])
        )

        # Frame channels
        channels = client.get("/current/frames").json()
        assert "cafe_frame" in channels

        # Frame lookup
        lookup_ok = client.get("/current/lookup/0")
        assert lookup_ok.status_code == 200
        assert lookup_ok.json()["frame_idx"] == 0
        assert lookup_ok.json()["receiver_url"] == lima2.current_pipeline.lookup(0)

        # Lookup error
        lookup_error = client.get("/current/lookup/1337")
        assert lookup_error.status_code == 400
        assert "code" in lookup_error.json()
        assert lookup_error.json()["remote_type"] == "Lima2LookupError"
        assert lookup_error.json()["message"] == "sorry but no frame"
        # Latest frame
        lookup_last = client.get("/current/lookup/-1")
        assert lookup_last.status_code == 200
        assert lookup_last.json()["receiver_url"] == "device_with_last_frame"

        # Get errors
        errors = client.get("/current/errors")
        assert errors.status_code == 200
        assert errors.json() == ["first error", "second error"]
