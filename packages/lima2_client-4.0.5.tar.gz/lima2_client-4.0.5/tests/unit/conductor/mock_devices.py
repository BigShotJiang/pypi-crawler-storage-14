# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Mock lima2 devices."""

import random
from typing import Any, Awaitable, Callable
from uuid import UUID, uuid1

from lima2.common.exceptions import Lima2DeviceError
from lima2.common.progress_counter import SingleCounter
from lima2.common.state import DeviceState
from lima2.common.types import FrameType
from lima2.conductor import utils
from lima2.conductor.processing.pipeline import FrameSource
from lima2.conductor.tango.utils import TangoDevice
from lima2.conductor.topology import SingleReceiver


def mock_tango_error(method):
    """Decorator for async method to raise a DeviceError if connected==False."""

    async def wrapper(self, *args, **kwargs):
        if not self.connected:
            raise Lima2DeviceError("Simulate offline device", device_name=self.name)
        else:
            return await method(self, *args, **kwargs)

    return wrapper


class MockControl(TangoDevice):
    def __init__(self) -> None:
        self.state = DeviceState.IDLE
        self.params: dict[str, Any] = {}
        self.connected = True
        self.num_triggers = 0
        self.state_change_callback: (
            Callable[[DeviceState], Awaitable[None]] | None
        ) = None

    @property
    def name(self) -> str:
        return "control"

    @mock_tango_error
    async def ping(self):
        return random.randint(20, 80)

    async def prepare(self, uuid: UUID, params: dict[str, Any]) -> None:
        self.params = params
        if params["prepare_fail"]:
            raise ValueError("yes sir")
        self.state = DeviceState.PREPARED

    async def start(self) -> None:
        self.state = DeviceState.RUNNING

    async def trigger(self) -> None:
        self.num_triggers += 1

    async def stop(self) -> None:
        self.state = DeviceState.STOPPED

    async def close(self) -> None:
        self.state = DeviceState.IDLE

    async def reset(self) -> None:
        self.state = DeviceState.IDLE

    @mock_tango_error
    async def acq_state(self) -> DeviceState:
        return self.state

    async def nb_frames_acquired(self) -> SingleCounter:
        return SingleCounter(name="nb_frames_acquired", value=42, source=self.name)

    async def det_info(self) -> dict[str, Any]:
        return {"det": "info"}

    async def det_status(self) -> dict[str, Any]:
        return {"det": "status"}

    async def det_capabilities(self) -> dict[str, Any]:
        return {"det": "capabilities"}

    def on_state_change(
        self, callback: Callable[[DeviceState], Awaitable[None]]
    ) -> None:
        self.state_change_callback = callback

    def fetch_params_schema(self) -> str:
        return "{}"

    async def signal_state_change(self, new_state: DeviceState):
        if not self.state_change_callback:
            raise NotImplementedError
        await self.state_change_callback(new_state)


class MockReceiver(TangoDevice):
    def __init__(self, idx: int) -> None:
        self.state = DeviceState.IDLE
        self.idx = idx
        self.connected = True
        self.pipelines: list[str] = []
        self.fail_on_start = False
        self.state_change_callback: (
            Callable[[DeviceState], Awaitable[None]] | None
        ) = None

    @property
    def name(self) -> str:
        return f"receiver {self.idx}"

    @mock_tango_error
    async def ping(self):
        return random.randint(20, 80)

    async def prepare(
        self, uuid: UUID, acq_params: dict[str, Any], proc_params: dict[str, Any]
    ) -> None:
        self.state = DeviceState.PREPARED
        self.pipelines.append(str(uuid))

    async def start(self) -> None:
        if self.fail_on_start:
            raise ValueError("Simulate raise on device start()")
        self.state = DeviceState.RUNNING

    async def stop(self) -> None:
        self.state = DeviceState.IDLE

    async def reset(self) -> None:
        self.state = DeviceState.IDLE

    async def acq_state(self) -> DeviceState:
        return self.state

    def fetch_params_schema(self) -> str:
        return "{}"

    def fetch_proc_schema(self, proc_class: str) -> str:
        return "{}"

    async def nb_frames_xferred(self) -> SingleCounter:
        return SingleCounter(name="nb_frames_xferred", value=4, source=self.name)

    async def list_pipelines(self) -> list[str]:
        return list(self.pipelines)  # NOTE: force copy

    async def erase_pipeline(self, uuid: str) -> None:
        self.pipelines.remove(uuid)

    def on_state_change(
        self, callback: Callable[[DeviceState], Awaitable[None]]
    ) -> None:
        self.state_change_callback = callback

    async def signal_state_change(self, new_state: DeviceState):
        if not self.state_change_callback:
            raise NotImplementedError
        await self.state_change_callback(new_state)

    async def last_error(self) -> str:
        return "oh no D:"


class MockPipeline:
    """Mock Pipeline object for AcquisitionSystem tests."""

    def __init__(self, uuid=uuid1(), topology=SingleReceiver()):
        self.uuid = uuid
        self.topology = topology

        self.on_finished = utils.to_async(lambda: None)
        self.on_error = utils.to_async(lambda: None)

    FRAME_SOURCES = {
        "cafe": FrameSource(
            getter_name="get_cafe",
            frame_type=FrameType.DENSE,
            saving_channel="🍉",
            label="cafe",
        ),
    }

    async def populate(self):
        pass

    async def attach(self, on_finished, on_error):
        self.on_finished = on_finished
        self.on_error = on_error

    def unregister(self):
        self.on_finished = lambda: None
        self.on_error = lambda: None

    def prepare(
        self,
        acq_params: dict[str, Any],
        proc_params: dict[str, Any],
        det_info: dict[str, Any],
    ):
        pass

    def start(self):
        pass

    async def close(self):
        pass

    async def signal_finished(self):
        await self.on_finished()

    async def signal_error(self):
        await self.on_error()
