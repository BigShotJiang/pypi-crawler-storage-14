# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for the Lima2 tango devices (lima2/conductor/tango/*.py)"""

import asyncio
import json
from collections import namedtuple
from types import SimpleNamespace
from typing import Any, Awaitable, Callable
from unittest.mock import AsyncMock
from uuid import uuid1

import pytest
import tango

from lima2.common.exceptions import Lima2DeviceError
from lima2.common.state import DeviceState
from lima2.conductor.tango import processing
from lima2.conductor.tango.control import TangoControl
from lima2.conductor.tango.processing import ProcessingErrorEvent, TangoProcessing
from lima2.conductor.tango.receiver import TangoReceiver
from lima2.conductor.tango.utils import handle_tango_errors


class MockTangoDatabase:
    NUM_DEVICES = 128
    """Number of exported processing devices."""

    acq_params_schema: dict[str, Any] = {}
    """Mutable dict to influence get_class_attribute_property behaviour"""

    proc_params_schema: dict[str, Any] = {}
    """Mutable dict to influence get_class_attribute_property behaviour"""

    def get_class_attribute_property(
        self, dev_class: str, prop_name: str
    ) -> dict[str, dict[str, list[str]]]:
        if prop_name == "acq_params":
            schema = MockTangoDatabase.acq_params_schema
        elif prop_name == "proc_params":
            schema = MockTangoDatabase.proc_params_schema
        else:
            assert False

        if schema:
            return {prop_name: {"schema": [json.dumps(schema)]}}
        else:
            return {prop_name: {}}

    def get_device_exported(self, pattern: str) -> list[str]:
        if "cafe" in pattern.lower():
            return [f"dev@{i}" for i in range(MockTangoDatabase.NUM_DEVICES)]
        else:
            return []

    def get_device_info(self, url: str):
        DevInfo = namedtuple("DevInfo", ("class_name"))
        return DevInfo(class_name="LimaProcessingMock")


OriginalDeviceProxy = tango.DeviceProxy


@pytest.mark.asyncio
async def test_tango_handle_tango_errors():
    """
    The handle_tango_errors decorator re-raises any DevFailed exceptions as
    Lima2DeviceError.
    """

    class RaisingTangoDevice:
        async def raising_method(self):
            raise tango.DevFailed(SimpleNamespace(desc="QWEQWE"))

    class Control:
        def __init__(self, device):
            self._device = device
            self.name = "control!"

        @handle_tango_errors
        async def raising_wrapper(self):
            await self._device.raising_method()

    control = Control(RaisingTangoDevice())
    with pytest.raises(Lima2DeviceError):
        await control.raising_wrapper()


class MockDeviceProxy:
    def __init__(self, url: str, green_mode: tango.GreenMode):
        self._name = url
        self._state = 0
        self.num_triggers = 0
        self._written_attributes: dict[str, Any] = {}
        self._executed_commands: list[tuple[str, Any]] = []
        self._erased_pipelines: list[str] = []

    def set_timeout_millis(self, timeout: int) -> None:
        pass

    def dev_name(self) -> str:
        return self._name

    async def ping(self) -> int:
        return 42

    async def write_attribute(self, name: str, value: Any) -> None:
        self._written_attributes[name] = value

    async def read_attribute(self, name: str) -> Any:
        if name == "acq_state":
            return SimpleNamespace(value=self._state)
        elif name == "nb_frames_acquired":  # Control only
            return SimpleNamespace(value=42)
        elif name == "det_info":  # Control only
            return SimpleNamespace(value=json.dumps({"det": "info"}))
        elif name == "det_status":  # Control only
            return SimpleNamespace(value=json.dumps({"det": "status"}))
        elif name == "det_capabilities":  # Control only
            return SimpleNamespace(value=json.dumps({"det": "capabilities"}))
        elif name == "pipelines":  # Receiver only
            return SimpleNamespace(value=["pipeline 1", "pipeline 2"])
        elif name == "last_error":  # Receiver only
            return SimpleNamespace(value="oh no")
        elif name == "nb_frames_xferred":  # Receiver only
            return SimpleNamespace(value=1337)
        elif name in self._written_attributes:
            return SimpleNamespace(value=self._written_attributes[name])
        else:
            return NotImplementedError(name)

    async def command_inout(self, name, arg=None) -> Any:
        self._executed_commands.append((name, arg))
        return 42

    async def Prepare(self, uuid: str) -> None:
        self._state = DeviceState.PREPARED.value

    async def Start(self) -> None:
        self._state = DeviceState.RUNNING.value

    async def Stop(self) -> None:
        self._state = DeviceState.STOPPED.value

    async def Reset(self) -> None:
        self._state = DeviceState.IDLE.value

    async def erasePipeline(self, uuid: str) -> None:
        self._erased_pipelines.append(uuid)

    async def signal_state_change(self, new_state: DeviceState, err: bool):
        if err:
            self._state = DeviceState.OFFLINE.value
        else:
            self._state = new_state.value

    ##################
    # Control only
    ##################

    async def Close(self) -> None:
        self._state = DeviceState.IDLE.value

    async def Trigger(self) -> None:
        self.num_triggers += 1

    ###################
    # Receiver only
    ##################

    def fetch_params_schema(self) -> str:
        return "{}"

    def fetch_proc_schema(self, proc_class: str) -> str:
        return "{}"


################################################################################
# TangoControl
################################################################################


@pytest.mark.asyncio
async def test_tango_control(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)
    control = TangoControl("hi tango", 456)

    assert await control.ping() == 42

    assert await control.acq_state() == DeviceState.IDLE

    await control.prepare(uuid=uuid1(), params={})
    assert await control.acq_state() == DeviceState.PREPARED

    await control.start()
    assert await control.acq_state() == DeviceState.RUNNING

    await control.trigger()
    assert control.device.num_triggers == 1

    await control.stop()
    assert await control.acq_state() == DeviceState.STOPPED

    await control.close()
    assert await control.acq_state() == DeviceState.IDLE

    await control.start()
    await control.reset()
    assert await control.acq_state() == DeviceState.IDLE

    assert (await control.nb_frames_acquired()).value == 42
    assert await control.det_info() == {"det": "info"}
    assert await control.det_status() == {"det": "status"}
    assert await control.det_capabilities() == {"det": "capabilities"}

    await control.write_attribute("cafe", 123)
    assert control.device._written_attributes["cafe"] == 123
    assert (await control.read_attribute("cafe")) == 123

    ret = await control.command("doBeef", arg=None)
    assert ret == 42
    assert control.device._executed_commands == [("doBeef", None)]

    ret = await control.command("doCafe", 2323)
    assert ret == 42
    assert control.device._executed_commands == [("doBeef", None), ("doCafe", 2323)]


@pytest.mark.asyncio
async def test_tango_control_fetch_params_schema(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)
    monkeypatch.setattr(tango, "Database", MockTangoDatabase)
    control = TangoControl("hi tango", 456)

    # Simulate absence of schema
    assert MockTangoDatabase.acq_params_schema == {}
    with pytest.raises(RuntimeError):
        control.fetch_params_schema()

    MockTangoDatabase.acq_params_schema = {"cafe": "deca"}
    pschema = control.fetch_params_schema()
    assert json.loads(pschema) == {"cafe": "deca"}


@pytest.mark.asyncio
async def test_tango_control_on_state_change(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)
    control = TangoControl("hi tango", 456)

    states: list[DeviceState] = []

    state_changed = asyncio.Event()

    async def on_state_change(new_state: DeviceState) -> None:
        states.append(new_state)
        state_changed.set()

    control.on_state_change(callback=on_state_change)
    await control.device.signal_state_change(new_state=DeviceState.PREPARED, err=False)
    await state_changed.wait()
    assert states == [DeviceState.PREPARED]
    state_changed.clear()

    await control.device.signal_state_change(new_state=DeviceState.RUNNING, err=True)
    await state_changed.wait()
    assert states == [DeviceState.PREPARED, DeviceState.OFFLINE]
    state_changed.clear()

    await control.device.signal_state_change(new_state=DeviceState.TERMINATE, err=False)
    await state_changed.wait()
    assert states == [
        DeviceState.PREPARED,
        DeviceState.OFFLINE,
        DeviceState.TERMINATE,
    ]
    state_changed.clear()

    # Raising callback
    async def on_state_change(new_state: DeviceState) -> None:
        raise ValueError("oops")

    # Coverage only: the error is logged, no side effects
    control.on_state_change(callback=on_state_change)
    await control.device.signal_state_change(new_state=DeviceState.IDLE, err=False)


################################################################################
# TangoReceiver
################################################################################


@pytest.mark.asyncio
async def test_tango_receiver(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)
    receiver = TangoReceiver("hi tango", 123)

    assert await receiver.ping() == 42

    assert (await receiver.nb_frames_xferred()).value == 1337

    assert await receiver.acq_state() == DeviceState.IDLE

    erased_uuid = str(uuid1())
    await receiver.erase_pipeline(erased_uuid)
    assert erased_uuid in receiver.device._erased_pipelines

    await receiver.prepare(uuid=uuid1(), acq_params={}, proc_params={})
    assert await receiver.acq_state() == DeviceState.PREPARED

    await receiver.start()
    assert await receiver.acq_state() == DeviceState.RUNNING

    await receiver.stop()
    assert await receiver.acq_state() == DeviceState.STOPPED

    await receiver.start()
    await receiver.reset()
    assert await receiver.acq_state() == DeviceState.IDLE

    assert await receiver.list_pipelines() == ["pipeline 1", "pipeline 2"]
    assert await receiver.last_error() == "oh no"


@pytest.mark.asyncio
async def test_tango_receiver_fetch_params_schema(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)
    monkeypatch.setattr(tango, "Database", MockTangoDatabase)
    receiver = TangoReceiver("hi tango", 123)

    # Simulate absence of schema
    MockTangoDatabase.acq_params_schema = {}
    with pytest.raises(RuntimeError):
        receiver.fetch_params_schema()

    MockTangoDatabase.proc_params_schema = {}
    with pytest.raises(RuntimeError):
        receiver.fetch_proc_schema(proc_class="LimaProcessing🍏")

    MockTangoDatabase.acq_params_schema = {"cafe": "deca"}
    pschema = receiver.fetch_params_schema()
    assert json.loads(pschema) == {"cafe": "deca"}

    MockTangoDatabase.proc_params_schema = {"dead": "beef"}
    pschema = receiver.fetch_proc_schema(proc_class="LimaProcessing🍎")
    assert json.loads(pschema) == {"dead": "beef"}


@pytest.mark.asyncio
async def test_tango_receiver_on_state_change(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)
    receiver = TangoReceiver("hi tango", 123)

    states: list[DeviceState] = []

    state_changed = asyncio.Event()

    async def on_state_change(new_state: DeviceState) -> None:
        states.append(new_state)
        state_changed.set()

    receiver.on_state_change(callback=on_state_change)
    await receiver.device.signal_state_change(new_state=DeviceState.PREPARED, err=False)
    await state_changed.wait()
    assert states == [DeviceState.PREPARED]
    state_changed.clear()

    await receiver.device.signal_state_change(new_state=DeviceState.RUNNING, err=True)
    await state_changed.wait()
    assert states == [DeviceState.PREPARED, DeviceState.OFFLINE]
    state_changed.clear()

    await receiver.device.signal_state_change(
        new_state=DeviceState.TERMINATE, err=False
    )
    await state_changed.wait()
    assert states == [
        DeviceState.PREPARED,
        DeviceState.OFFLINE,
        DeviceState.TERMINATE,
    ]
    state_changed.clear()

    # Raising callback
    async def on_state_change(new_state: DeviceState) -> None:
        raise ValueError("oops")

    # Coverage only: the error is logged, no side effects
    receiver.on_state_change(callback=on_state_change)
    await receiver.device.signal_state_change(new_state=DeviceState.IDLE, err=False)


################################################################################
# TangoProcessing
################################################################################


class MockProcessingDeviceProxy:
    def __init__(self, url: str, green_mode: tango.GreenMode):
        self.name = url
        self.event_callbacks: dict[
            (str, tango.EventType),
            Callable[[tango.DataReadyEventData], Awaitable[None]],
        ] = {}
        self.unsubscribed: list[int] = []

    def set_timeout_millis(self, timeout: int) -> None:
        pass

    def get_command_list(self) -> list[str]:
        return ["getFrame", "cafe", "one command", "two commands", "..."]

    def dev_name(self) -> str:
        return self.name

    async def ping(self) -> int:
        return 42

    async def read_attribute(self, name: str):
        if name == "progress_counters":
            return SimpleNamespace(value=json.dumps({"nb_frames_processed": 123123}))
        elif name == "last_error":
            return SimpleNamespace(value="very error")
        else:
            return NotImplementedError(name)

    async def getFrame(self, frame_idx: int) -> bytes:
        return "🍪".encode()

    async def command_inout(self, name: str, *args, **kwargs) -> Any:
        if name == "cafe":
            return [1, 2, 3]
        elif name == "getFrame":
            return b"frame"
        else:
            assert False

    async def subscribe_event(
        self,
        name: str,
        evt_type: tango.EventType,
        handler: Callable[[tango.DataReadyEventData], Awaitable[None]],
    ) -> int:
        self.event_callbacks[(name, evt_type)] = handler
        return len(self.event_callbacks)

    async def unsubscribe_event(self, evt_id: int) -> None:
        self.unsubscribed.append(evt_id)

    async def signal_finished(self, err: bool):
        MockReadyEventData = namedtuple("MockReadyEventData", ("device", "err"))
        await self.event_callbacks[("is_finished", tango.EventType.DATA_READY_EVENT)](
            MockReadyEventData(device=self, err=err)
        )

    async def signal_error(self, err: bool):
        MockReadyEventData = namedtuple("MockReadyEventData", ("device", "err"))
        await self.event_callbacks[("last_error", tango.EventType.DATA_READY_EVENT)](
            MockReadyEventData(device=self, err=err)
        )


@pytest.mark.asyncio
async def test_tango_processing(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockProcessingDeviceProxy)

    dev_name = "it's a processing device!"
    dev = TangoProcessing(url=dev_name, class_name="LimaProcessingMock", timeout_s=1)

    assert dev.name == dev_name
    assert await dev.ping() == 42

    assert await dev.progress_counters() == {"nb_frames_processed": 123123}

    with pytest.raises(ValueError):
        await dev.pop_reduced_data(getter_name="invalid_command")

    cafe = await dev.pop_reduced_data(getter_name="cafe")
    assert cafe == [1, 2, 3]


@pytest.mark.asyncio
async def test_tango_processing_on_finished(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockProcessingDeviceProxy)
    dev = TangoProcessing(url="hello", class_name="LimaProcessingMock", timeout_s=1)

    on_finished = AsyncMock()

    await dev.on_finished(on_finished)

    await dev.device.signal_finished(err=False)
    on_finished.assert_awaited_once()

    on_finished_called = False
    await dev.device.signal_finished(err=True)
    assert not on_finished_called

    # Resubscribe
    await dev.on_finished(on_finished)
    assert 1 in dev.device.unsubscribed

    # Raising callback
    async def on_finished(dev_name: str):
        raise RuntimeError("bad bad")

    await dev.on_finished(on_finished)
    # Coverage only: the error is logged, no side effects
    await dev.device.signal_finished(err=False)


@pytest.mark.asyncio
async def test_tango_processing_on_error(monkeypatch):
    monkeypatch.setattr(tango, "DeviceProxy", MockProcessingDeviceProxy)
    dev = TangoProcessing(url="hello", class_name="LimaProcessingMock", timeout_s=1)

    on_error_called = False

    async def on_error(evt: ProcessingErrorEvent):
        nonlocal on_error_called
        on_error_called = True
        assert evt.error_msg == "very error"

    await dev.on_error(on_error)

    await dev.device.signal_error(err=False)
    assert on_error_called

    on_error_called = False
    await dev.device.signal_error(err=True)
    assert not on_error_called

    # Resubscribe
    await dev.on_error(on_error)
    assert 1 in dev.device.unsubscribed

    # Raising callback
    async def on_error(dev_name: str):
        raise RuntimeError("not good")

    await dev.on_error(on_error)
    # Coverage only: the error is logged, no side effects
    await dev.device.signal_error(err=False)


def test_from_uuid(monkeypatch):
    monkeypatch.setattr(tango, "Database", MockTangoDatabase)
    monkeypatch.setattr(tango, "DeviceProxy", MockProcessingDeviceProxy)

    devices = processing.from_uuid(uuid1(0xCAFE), timeout_s=1)
    # Make sure they are sorted by increasing index
    names = [dev.name for dev in devices]
    assert all(
        f"dev@{i}" == name
        for i, name in zip(range(MockTangoDatabase.NUM_DEVICES), names, strict=True)
    )

    assert all([dev.class_name == "LimaProcessingMock" for dev in devices])

    with pytest.raises(ValueError):
        processing.from_uuid(uuid1(0xDEAD), timeout_s=1)
