# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for the acquisition module (lima2/conductor/acquisition_state.py)"""

import asyncio
import weakref
from unittest.mock import AsyncMock, Mock
from uuid import uuid1

import pytest

from lima2.conductor.acquisition import Acquisition, AcquisitionEvent, AcquisitionState
from tests.unit.conductor.mock_devices import MockPipeline


@pytest.mark.asyncio
async def test_acquisition_state_handle():
    on_end = AsyncMock()
    on_failure = AsyncMock()
    state = AcquisitionState(num_receivers=3, on_end=on_end, on_failure=on_failure)

    assert type(state.describe()) is str

    events = await state._handle(AcquisitionEvent.ACQ_DEVICE_FAILED)
    assert state.num_rcv_done == 1
    assert state.rcv_failed
    assert AcquisitionEvent.FAILURE in events
    assert AcquisitionEvent.ACQ_FINISHED not in events

    events = await state._handle(AcquisitionEvent.ACQ_DEVICE_DONE)
    assert AcquisitionEvent.ACQ_FINISHED not in events

    events = await state._handle(AcquisitionEvent.ACQ_DEVICE_DONE)
    assert AcquisitionEvent.ACQ_FINISHED in events

    state.num_rcv_done -= 1
    events = await state._handle(AcquisitionEvent.ACQ_DEVICE_FAILED)
    assert AcquisitionEvent.ACQ_FINISHED in events

    events = await state._handle(AcquisitionEvent.ACQ_FINISHED)
    assert state.acq_finished
    assert AcquisitionEvent.FINISHED not in events

    state.proc_finished = True
    events = await state._handle(AcquisitionEvent.ACQ_FINISHED)
    assert AcquisitionEvent.FINISHED in events

    events = await state._handle(AcquisitionEvent.PROC_DEVICE_DONE)
    assert AcquisitionEvent.PROC_FINISHED not in events
    events = await state._handle(AcquisitionEvent.PROC_DEVICE_DONE)
    assert AcquisitionEvent.PROC_FINISHED not in events
    events = await state._handle(AcquisitionEvent.PROC_DEVICE_DONE)
    assert AcquisitionEvent.PROC_FINISHED in events

    events = await state._handle(AcquisitionEvent.PROC_DEVICE_FAILED)
    assert AcquisitionEvent.FAILURE in events

    state.acq_finished = False
    events = await state._handle(AcquisitionEvent.PROC_FINISHED)
    assert AcquisitionEvent.FINISHED not in events

    state.acq_finished = True
    events = await state._handle(AcquisitionEvent.PROC_FINISHED)
    assert AcquisitionEvent.FINISHED in events

    events = await state._handle(AcquisitionEvent.FINISHED)
    on_end.assert_awaited_once()

    state.rcv_failed = False
    state.proc_failed = False
    events = await state._handle(AcquisitionEvent.FINISHED)

    events = await state._handle(AcquisitionEvent.FAILURE)
    assert state.failed_once
    on_failure.assert_awaited_once()


async def noop_on_end(result):
    pass


async def noop():
    pass


@pytest.mark.asyncio
async def test_acquisition_state_loop():
    state = AcquisitionState(num_receivers=3, on_end=noop_on_end, on_failure=noop)

    state.start()
    assert state.started

    fut = await state.enqueue(AcquisitionEvent.ACQ_DEVICE_DONE)
    assert state.num_rcv_done == 0
    await fut
    assert state.num_rcv_done == 1

    await state.process(AcquisitionEvent.ACQ_DEVICE_DONE)
    assert state.num_rcv_done == 2

    await state.process(AcquisitionEvent.ACQ_DEVICE_FAILED)

    with pytest.raises(ValueError):
        await state.process("cafe")

    async def raise_on_end(result):
        raise RuntimeError()

    async def raise_on_failure():
        raise RuntimeError()

    state = AcquisitionState(
        num_receivers=3, on_end=raise_on_end, on_failure=raise_on_failure
    )
    state.start()

    # coverage
    await state.process(AcquisitionEvent.FAILURE)
    await state.process(AcquisitionEvent.FINISHED)

    await asyncio.wait_for(state.loop, timeout=0.1)

    state = AcquisitionState(
        num_receivers=3, on_end=raise_on_end, on_failure=raise_on_failure
    )
    state.start()
    state.detach()
    try:
        await asyncio.wait_for(state.loop, timeout=0.1)
    except asyncio.CancelledError:
        pass


@pytest.mark.asyncio
async def test_acquisition_start():
    acq = Acquisition(
        uuid=uuid1(), num_receivers=4, on_end=noop_on_end, on_failure=noop
    )
    with pytest.raises(RuntimeError):
        acq.start()

    acq.pipeline = Mock()
    acq.state = Mock()
    acq.start()
    acq.pipeline.start.assert_called_once()
    acq.state.start.assert_called_once()

    acq.detach()
    acq.pipeline.unregister.assert_called_once()
    acq.state.detach.assert_called_once()


@pytest.mark.asyncio
async def test_acquisition_events():
    acq = Acquisition(
        uuid=uuid1(), num_receivers=4, on_end=noop_on_end, on_failure=noop
    )
    pipeline = MockPipeline()
    await acq.attach(pipeline=pipeline)
    await acq.pipeline.signal_error()
    last_event = await asyncio.wait_for(acq.state.event_queue.get(), timeout=0.05)
    assert last_event[0] == AcquisitionEvent.PROC_DEVICE_FAILED

    await acq.pipeline.signal_finished()
    last_event = await asyncio.wait_for(acq.state.event_queue.get(), timeout=0.05)
    assert last_event[0] == AcquisitionEvent.PROC_DEVICE_DONE


@pytest.mark.asyncio
async def test_acquisition_referrers():
    """Acquisition has does not register callbacks referencing self."""
    acq = Acquisition(
        uuid=uuid1(), num_receivers=4, on_end=noop_on_end, on_failure=noop
    )
    pipeline = MockPipeline()
    await acq.attach(pipeline=pipeline)

    ref = weakref.ref(acq)
    assert ref() is not None

    # Drop main reference
    acq = None
    # No references remain (caused by usage of `self` in callbacks registered by
    # attach())
    assert ref() is None
