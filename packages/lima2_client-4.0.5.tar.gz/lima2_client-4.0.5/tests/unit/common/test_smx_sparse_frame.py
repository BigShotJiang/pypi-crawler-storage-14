# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT licence. See LICENSE for more info.

"""Test suite for the sparse_frame module (lima2/common/devencoded/sparse_frame.py)"""

import struct

import numpy as np
import numpy.testing as npt
import pytest

from lima2.common.devencoded import smx_sparse_frame
from lima2.common.devencoded.exception import DevEncodedFormatNotSupported


def test_decode_invalid_type():
    with pytest.raises(DevEncodedFormatNotSupported):
        smx_sparse_frame.decode(raw_data=("DEADBEEF", b"cafedeca"))


def encode(
    width=256,
    height=256,
    nb_bins=42,
    nb_peaks=42,
    frame_idx=0,
    index=None,
    intensity=None,
    background_avg=None,
    background_std=None,
):
    """Encode a frame as if it came out of recv.getSparseFrame()"""

    header_data = struct.pack(
        smx_sparse_frame.DATA_HEADER_FORMAT,
        width,
        height,
        nb_bins,
        nb_peaks,
        frame_idx,
    )

    if index is None:
        index = np.random.choice(width * height, size=nb_peaks, replace=False).astype(
            np.int32
        )

    if intensity is None:
        intensity = np.random.random(size=nb_peaks).astype(np.float32) * 1000.0

    if background_avg is None:
        background_avg = np.random.random(size=nb_bins).astype(np.float32) * 10.0

    if background_std is None:
        background_std = np.random.random(size=nb_bins).astype(np.float32) * 1.0

    return (
        header_data
        + index.tobytes()
        + intensity.tobytes()
        + background_avg.tobytes()
        + background_std.tobytes()
    )


def noisy_frame(data_type, dim1, dim2, dim3):
    # If data_type is not valid, use a default numpy dtype
    # This allows a test to set a bad data_type in the header
    try:
        dtype = smx_sparse_frame.MODE_TO_NUMPY[smx_sparse_frame.IMAGE_MODES(data_type)]
    except (ValueError, KeyError):
        dtype = np.float32

    return (
        (np.random.random_sample(size=(dim3, dim2, dim1)) * 10)
        .astype(dtype=dtype)
        .tobytes()
    )


def test_decode_ok():
    data = encode()
    _ = smx_sparse_frame.decode(raw_data=data)


def test_decode_tuple():
    data = encode()
    _ = smx_sparse_frame.decode(raw_data=("SMX_SPARSE_FRAME", data))


def test_encode_bad_tuple():
    data = encode()
    with pytest.raises(DevEncodedFormatNotSupported):
        _ = smx_sparse_frame.decode(raw_data=("DEAD_BEEF", data))


def test_is_empty():
    frame = smx_sparse_frame.SmxSparseFrame(
        index=np.ones(64, dtype=np.int32),
        intensity=np.ones(64) * 0.5,
        background_avg=0.1,
        background_std=0.01,
        idx=0,
        shape=(32, 32),
    )
    assert frame


def test_densify():
    shape = (32, 32)
    index = np.random.choice(32 * 32, size=64, replace=False)
    intensity = (np.random.random(size=64) * 1000).astype(np.int32)

    background_avg = np.random.randn(16) + 10
    background_std = np.random.randn(16) * 0.1 + 5

    frame = smx_sparse_frame.SmxSparseFrame(
        index=index,
        intensity=intensity,
        background_avg=background_avg,
        background_std=background_std,
        idx=1337,
        shape=shape,
    )

    mask = np.ones(shape)
    # Mask the first peak
    mask.flat[index[0]] = np.nan

    dense = frame.densify(
        mask=mask,
        radius=np.linspace(0, 32, 16),
        dummy=9999999,
        normalization=0.5,
    )

    assert dense.data.dtype == intensity.dtype
    assert dense.data.shape == frame.shape
    assert dense.idx == frame.idx

    assert dense.data.flat[index[0]] == 9999999
    npt.assert_equal(dense.data.flat[index[1:]], intensity[1:])

    peaks = frame.densify_peaks()
    assert peaks.shape == shape

    npt.assert_equal(frame.data, peaks)
