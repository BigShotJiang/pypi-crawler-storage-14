# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for progress counters (lima2/common/progress_counter.py)"""

from lima2.common import progress_counter
from lima2.common.progress_counter import ProgressCounter, SingleCounter


def test_aggregate_single():
    """Nominal case"""
    single_counters = [
        SingleCounter(name="my_counter", value=42, source="id00/some/device")
    ]

    counter = progress_counter.aggregate(single_counters=single_counters)

    assert counter.name == "my_counter"
    assert counter.sum == 42
    assert counter.min == 42
    assert counter.max == 42
    assert counter.avg == 42


def test_aggregate_multiple():
    """Nominal case"""
    single_counters = [
        SingleCounter(name="my_counter", value=42, source="id00/some/device"),
        SingleCounter(name="also_my_counter", value=43, source="id00/some/device"),
    ]

    counter = progress_counter.aggregate(single_counters=single_counters)

    assert counter.name == "my_counter"
    assert counter.sum == 42 + 43
    assert counter.min == 42
    assert counter.max == 43
    assert counter.avg == (42 + 43) / 2


def test_progress_counter_from_single():
    sc = SingleCounter(name="cafe", value=0xDECA, source="mmmm")
    pc = ProgressCounter.from_single(sc)
    assert pc.name == "cafe"
    assert pc.sum == 0xDECA
    assert len(pc.counters) == 1
    assert pc.counters[0] == sc


def test_progress_counter_operators():
    """Comparison, subtraction"""
    c1 = progress_counter.aggregate(
        [
            SingleCounter(name="c1", value=42, source="id00/some/device"),
            SingleCounter(name="c1", value=43, source="id00/some/device"),
        ]
    )

    c2 = progress_counter.aggregate(
        [
            SingleCounter(name="c2", value=44, source="id00/some/device"),
            SingleCounter(name="c2", value=45, source="id00/some/device"),
        ]
    )

    assert c1 < c2
    assert c1 != c2

    assert isinstance(c1 - c2, ProgressCounter)
    assert (c1 - c2).min == c1.min - c2.min
    assert (c1 - c2).max == c1.max - c2.max
    assert (c1 - c2).avg == c1.avg - c2.avg
    assert (c1 - c2).sum == c1.sum - c2.sum
