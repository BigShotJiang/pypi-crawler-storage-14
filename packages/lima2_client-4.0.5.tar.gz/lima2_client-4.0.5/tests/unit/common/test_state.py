# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for the state module (lima2/common/state.py)"""

import pytest

from lima2.common.state import DeviceState, State


@pytest.mark.parametrize(
    "device_state, system_state",
    [
        (DeviceState.IDLE, State.IDLE),
        (DeviceState.PREPARED, State.PREPARED),
        (DeviceState.RUNNING, State.RUNNING),
        (DeviceState.FAULT, State.FAULT),
        (DeviceState.TERMINATE, State.FAULT),
    ],
)
def test_state_from_device_states_all_equal(device_state, system_state):
    s = State.from_device_states(states=[device_state, device_state, device_state])

    assert s == system_state


def test_state_from_device_states_all_equal_invalid():
    with pytest.raises(NotImplementedError):
        State.from_device_states(states=[-999, -999, -999])


def test_state_from_device_states_mixed_idle_prepared():
    s = State.from_device_states(
        states=[DeviceState.PREPARED, DeviceState.PREPARED, DeviceState.IDLE]
    )

    assert s == State.IDLE


def test_state_from_device_states_mixed_running_idle():
    s = State.from_device_states(
        states=[DeviceState.IDLE, DeviceState.RUNNING, DeviceState.IDLE]
    )

    assert s == State.RUNNING


def test_state_from_device_states_one_fault():
    s = State.from_device_states(
        states=[DeviceState.RUNNING, DeviceState.FAULT, DeviceState.RUNNING]
    )

    assert s == State.FAULT


def test_state_from_device_states_inconsistent():
    s = State.from_device_states(
        states=[DeviceState.IDLE, DeviceState.RUNNING, DeviceState.PREPARED]
    )

    assert s == State.UNKNOWN
