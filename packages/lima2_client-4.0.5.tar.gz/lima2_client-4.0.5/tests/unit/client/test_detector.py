# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for lima2.client.services.detector."""

import pytest

from lima2.common import exceptions


def test_detector(detector, conductor_mock_get, conductor_mock_post):
    det_info = {"name": "cool_det"}
    det_status = {"good?": "probably?"}
    det_capabilities = {"capable": "highly"}
    det_command_result = {"status": "ok !"}
    det_cafe_get = {"cafe": "deca"}

    conductor_mock_get("/detector/info", json=det_info)
    conductor_mock_get("/detector/status", json=det_status)
    conductor_mock_get("/detector/capabilities", json=det_capabilities)
    conductor_mock_post("/detector/command", json=det_command_result)
    conductor_mock_get("/detector/attribute/cafe", json=det_cafe_get)
    conductor_mock_post("/detector/attribute/cafe", status_code=202)

    assert detector.info() == det_info
    assert detector.status() == det_status
    assert detector.capabilities() == det_capabilities
    assert detector.command(name="hello", arg="world") == det_command_result
    assert detector.read_attribute(name="cafe") == det_cafe_get
    detector.write_attribute(name="cafe", value=123)

    conductor_mock_post(
        "/detector/attribute/cafe",
        json=exceptions.serialize(exceptions.Lima2BackendError()),
        status_code=400,
    )
    with pytest.raises(exceptions.Lima2BackendError):
        detector.write_attribute(name="cafe", value=123)
