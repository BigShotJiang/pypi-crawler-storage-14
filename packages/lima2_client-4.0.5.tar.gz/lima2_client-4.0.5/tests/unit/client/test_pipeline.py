# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for lima2.client.services.pipeline."""

import struct
from uuid import UUID, uuid1

import numpy as np
import numpy.testing as npt
import pytest

from lima2.common import exceptions, pipelines
from lima2.common.devencoded import dense_frame
from lima2.common.progress_counter import ProgressCounter, SingleCounter
from lima2.common.types import FrameSource, FrameType
from lima2.conductor.processing.reduced_data import ROI_STATS_DTYPE


def test_pipeline_classes(pipeline, conductor_mock_get):
    mock_classes = ["LimaProcessingA", "LimaProcessingB", "LimaProcessingC"]
    conductor_mock_get(
        "/pipeline/class",
        json=mock_classes,
    )
    assert pipeline.classes() == mock_classes


def test_pipeline_default_params(pipeline, conductor_mock_get):
    conductor_mock_get(
        "/pipeline/class/LimaCoolProcessing",
        json={"default_params": {"cafe": "deca"}},
    )
    assert pipeline.default_params(processing_name="LimaCoolProcessing") == {
        "cafe": "deca"
    }


def test_pipeline_params_schema(pipeline, conductor_mock_get):
    schema = {"properties": {"a": {}, "b": {}, "c": {}}}
    conductor_mock_get("/pipeline/class/LimaCoolProcessing/schema", json=schema)
    assert pipeline.params_schema(processing_name="LimaCoolProcessing") == schema


def test_pipeline_uuids(pipeline, conductor_mock_get):
    uuids = [str(uuid1()) for _ in range(5)]
    conductor_mock_get("/pipeline/", json=uuids)
    assert pipeline.uuids() == [UUID(uuid) for uuid in uuids]

    conductor_mock_get("/pipeline/current", json={"uuid": uuids[0]})
    assert pipeline.current_pipeline() == UUID(uuids[0])

    for uuid in uuids:
        conductor_mock_get(f"/pipeline/{uuid}", json={"uuid": uuid})
        assert pipeline.pipeline(uuid=uuid)["uuid"] == uuid


def test_pipeline_errors(pipeline, conductor_mock_get):
    uuid = str(uuid1())
    conductor_mock_get(f"/pipeline/{uuid}/errors", json=["abc", "def"])
    assert pipeline.errors(uuid=uuid) == ["abc", "def"]


def test_pipeline_progress(pipeline, conductor_mock_get):
    uuid = uuid1()
    nb_cafe = ProgressCounter(
        name="nb_cafe",
        counters=[
            SingleCounter(name="nb_cafe", value=42 + i, source=f"dev/rcv{i}")
            for i in range(4)
        ],
    )

    conductor_mock_get(f"/pipeline/{uuid}/progress", json=nb_cafe.sum)
    conductor_mock_get(f"/pipeline/{uuid}/progress/deca", json=123)
    assert pipeline.progress(uuid=str(uuid)) == nb_cafe.sum
    assert pipeline.progress(channel="deca", uuid=str(uuid)) == 123


def test_pipeline_clear_previous_pipelines(pipeline, conductor_mock_post):
    cleared = [str(uuid1()), str(uuid1())]
    conductor_mock_post("/pipeline/clear", json={"cleared": cleared})
    assert pipeline.clear_previous_pipelines() == cleared


def test_pipeline_running(pipeline, conductor_mock_get):
    uuid = str(uuid1())
    conductor_mock_get(f"/pipeline/{uuid}/running", json=True)
    assert pipeline.running(uuid=uuid)
    conductor_mock_get(
        f"/pipeline/{uuid}/running",
        status_code=400,
        json={
            "code": exceptions.by_type[exceptions.Lima2NotFound][0],
            "remote_type": "Lima2NotFound",
            "message": ":(",
            "payload": {},
            "trace": "",
        },
    )
    assert not pipeline.running(uuid=uuid)


def test_pipeline_master_files(pipeline, conductor_mock_get):
    uuid = str(uuid1())
    master_files = {
        "saved_1": ("/path/to/saved_1.h5", "/cafe_0000/ESRF-ID69/maxideca/data"),
        "saved_2": ("/path/to/saved_2.h5", "/cafe_0000/ESRF-ID69/maxideca/data"),
    }
    conductor_mock_get(f"/pipeline/{uuid}/master_files", json=master_files)
    assert pipeline.master_files(uuid=uuid) == master_files


def test_pipeline_reduced_data_channels(pipeline, conductor_mock_get):
    uuid = str(uuid1())
    complex_dtype = np.dtype([("abc", np.float32, (4,))])
    conductor_mock_get(
        f"/pipeline/{uuid}/reduced_data",
        json={
            "roi_stats": [{"dtype": ROI_STATS_DTYPE.descr, "shape": (1,)}],
            "complex": [{"dtype": complex_dtype.descr, "shape": (3,)}],
        },
    )
    channels = pipeline.reduced_data_channels(uuid=uuid)
    assert "roi_stats" in channels
    assert len(channels["roi_stats"]) == 1
    assert type(channels["roi_stats"][0]) is tuple
    assert len(channels["roi_stats"][0]) == 2
    dtype, shape = channels["roi_stats"][0]
    assert dtype == ROI_STATS_DTYPE
    assert shape == (1,)

    assert "complex" in channels
    assert len(channels["complex"]) == 1
    dtype, shape = channels["complex"][0]
    assert dtype == complex_dtype
    assert shape == (3,)


def test_pipeline_frame_channels(pipeline, conductor_mock_get):
    uuid = str(uuid1())
    conductor_mock_get(
        f"/pipeline/{uuid}/frames",
        json={
            "cafe_frame": {
                "num_channels": 3,
                "width": 128,
                "height": 256,
                "pixel_type": np.dtype(np.float64).name,
            }
        },
    )

    cafe_frame = pipeline.frame_channels(uuid=uuid)["cafe_frame"]
    assert cafe_frame.num_channels == 3
    assert cafe_frame.width == 128
    assert cafe_frame.height == 256
    assert cafe_frame.pixel_type == np.float64


def test_pipeline_reduced_data(pipeline, conductor_mock_get):
    uuid = str(uuid1())

    CAFE_DTYPE = np.dtype([("frame_idx", "<i4"), ("beef", "<f8")])
    cafe_data = np.array(
        [
            [(0, 0.1), (0, 0.1), (0, 0.1)],
            [(1, 0.2), (1, 0.2), (1, 0.2)],
            [(2, 0.3), (2, 0.3), (2, 0.3)],
            [(3, 0.4), (3, 0.4), (3, 0.4)],
        ],
        dtype=CAFE_DTYPE,
    )

    conductor_mock_get(
        f"/pipeline/{uuid}/reduced_data",
        json={"cafe": [{"dtype": CAFE_DTYPE.descr, "shape": [3]}]},
    )
    conductor_mock_get(
        f"/pipeline/{uuid}/reduced_data/cafe/0", content=cafe_data.tobytes()
    )

    # requests-mock doesn't handle chunked responses. The loop will only
    # have one iteration, yielding all rows from cafe_data at once.
    for row in pipeline.reduced_data(name="cafe", channel_idx=0, uuid=uuid):
        npt.assert_equal(row.reshape((cafe_data.shape[0], -1)), cafe_data)


def test_pipeline_lookup(pipeline, conductor_mock_get):
    uuid = str(uuid1())
    conductor_mock_get(
        f"/pipeline/{uuid}/lookup/42",
        json={"frame_idx": 42, "receiver_url": "dev/receiver0"},
    )
    fidx, rcv_url = pipeline.lookup(frame_idx=42, uuid=uuid)
    assert fidx == 42
    assert rcv_url == "dev/receiver0"

    # Bad lookup (server error)
    conductor_mock_get(
        f"/pipeline/{uuid}/lookup/43",
        status_code=400,
        json=exceptions.serialize(exceptions.Lima2LookupError()),
    )

    with pytest.raises(exceptions.Lima2LookupError):
        pipeline.lookup(frame_idx=43, uuid=uuid)


def mock_frame(
    frame_data: bytes,
    version=1,
    nb_dim=3,
    dim1=2,
    dim2=3,
    dim3=4,
    dim4=1,
    dim5=1,
    dim6=1,
    dim_step1=1,
    dim_step2=1,
    dim_step3=1,
    dim_step4=1,
    dim_step5=1,
    dim_step6=1,
    frame_idx=0,
) -> bytes:
    return (
        struct.pack(
            dense_frame.DATA_HEADER_FORMAT,
            dense_frame.DATA_MAGIC,
            version,
            dense_frame.DATA_HEADER_SIZE,
            0,
            0,
            0,
            nb_dim,
            dim1,
            dim2,
            dim3,
            dim4,
            dim5,
            dim6,
            dim_step1,
            dim_step2,
            dim_step3,
            dim_step4,
            dim_step5,
            dim_step6,
            frame_idx,
        )
        + frame_data
    )


def test_pipeline_get_frame(pipeline, conductor_mock_get, monkeypatch):
    uuid = str(uuid1())
    conductor_mock_get(
        f"/pipeline/{uuid}/lookup/42",
        json={"frame_idx": 42, "receiver_url": "dev/receiver0"},
    )
    conductor_mock_get(
        f"/pipeline/{uuid}", json={"uuid": uuid, "type": "LimaCoolProcessing"}
    )
    conductor_mock_get(
        f"/pipeline/{uuid}/frame_sources/huh",
        status_code=404,
    )

    monkeypatch.setattr(
        pipelines,
        "by_name",
        {
            "LimaCoolProcessing": pipelines.Pipeline(
                class_name="LimaCoolProcessing",
                frame_sources={
                    "cafe_frame": FrameSource(
                        getter_name="getCafeFrame",
                        frame_type=FrameType.DENSE,
                        saving_channel=None,
                        label=None,
                    )
                },
                reduced_data_sources={},
                progress_indicator="cafe",
            )
        },
    )

    with pytest.raises(ValueError):
        pipeline.get_frame(frame_idx=42, source="huh", uuid=uuid)

    class MockDeviceProxy:
        def __init__(self, url):
            pass

        def getCafeFrame(self, frame_idx: int) -> bytes:
            frame_data = f"cafe{frame_idx}".encode()
            return mock_frame(
                frame_data=frame_data, dim1=len(frame_data), dim2=1, dim3=1
            )

    import tango

    monkeypatch.setattr(tango, "DeviceProxy", MockDeviceProxy)

    res = pipeline.get_frame(frame_idx=42, source="cafe_frame", uuid=uuid)
    assert res.data.tobytes() == b"cafe42"
