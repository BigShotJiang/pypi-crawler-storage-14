# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for lima2.client.session."""

import json
import pytest

from lima2.client.exceptions import (
    ConductorConnectionError,
    ConductorEndpointNotFound,
    MalformedConductorResponse,
)
from lima2.client.services import ConnectionState
from lima2.common import exceptions


def test_session_connection_error(services, session):
    # Make a request without mocking
    with pytest.raises(ConductorConnectionError):
        session.get("/")
    with pytest.raises(ConductorConnectionError):
        session.post("/")

    assert services.connection_state() == ConnectionState.CONDUCTOR_OFFLINE


def test_session_client_error_bad_error_code(
    session, conductor_mock_get, conductor_mock_post
):
    """Response has an unexpected error code."""
    conductor_mock_get("/", status_code=401, content=b"")

    with pytest.raises(NotImplementedError):
        session.get("/")

    conductor_mock_post("/", status_code=401, content=b"")

    with pytest.raises(NotImplementedError):
        session.post("/")


def test_session_client_error_bad_json(session, conductor_mock_get):
    """Response has a 400 status code but a malformed JSON payload."""
    malformed_json: bytes = r'{"error": "abc"'.encode()  # Missing '}'
    conductor_mock_get("/", status_code=400, content=malformed_json)

    with pytest.raises(MalformedConductorResponse) as e:
        session.get("/")

    # The malformed content is shown in the error message
    assert malformed_json.decode() in str(e.value)

    # Valid json but missing keys
    incomplete_json = r'{"abc": 123}'.encode()
    conductor_mock_get("/", status_code=400, content=incomplete_json)

    with pytest.raises(MalformedConductorResponse) as e:
        session.get("/")
    assert "is missing" in str(e.value)

    # Valid json but deserialization failed
    content = json.dumps(
        {
            "code": 10,
            "message": ":(",
            "payload": {},  # missing device_name
            "remote_type": "??",
            "trace": "",
        }
    ).encode()
    conductor_mock_get("/", status_code=400, content=content)

    with pytest.raises(MalformedConductorResponse) as e:
        session.get("/")
    assert "deserialize" in str(e.value)


def test_session_endpoint_not_found(session, conductor_mock_get, conductor_mock_post):
    """Invalid endpoint."""
    conductor_mock_get("/abcdef", status_code=404)
    with pytest.raises(ConductorEndpointNotFound):
        session.get("/abcdef")

    conductor_mock_post("/cafe", status_code=404)
    with pytest.raises(ConductorEndpointNotFound):
        session.post("/cafe")


def test_session_handled_error(session, conductor_mock_get, conductor_mock_post):
    """Error with a registered code."""
    conductor_mock_get(
        "/",
        status_code=400,
        json=exceptions.serialize(
            exceptions.Lima2DeviceError("hello world", device_name="cafe")
        ),
    )
    with pytest.raises(exceptions.Lima2DeviceError) as e:
        session.get("/")
    assert type(e.value) is exceptions.Lima2DeviceError
    assert e.value.device_name == "cafe"

    conductor_mock_post(
        "/",
        status_code=400,
        json=exceptions.serialize(
            exceptions.Lima2DeviceError("hello world", device_name="cafe")
        ),
    )
    with pytest.raises(exceptions.Lima2DeviceError) as e:
        session.post("/")
    assert type(e.value) is exceptions.Lima2DeviceError
    assert e.value.device_name == "cafe"


def test_session_unhandled_error(session, conductor_mock_get, conductor_mock_post):
    """Error without a registered code."""

    class MyNewException(Exception):
        pass

    conductor_mock_get(
        "/",
        status_code=400,
        json=exceptions.serialize(MyNewException("hello world")),
    )
    with pytest.raises(exceptions.Lima2Error) as e:
        session.get("/")
    assert type(e.value) is exceptions.Lima2Error

    conductor_mock_post(
        "/",
        status_code=400,
        json=exceptions.serialize(MyNewException("hello world")),
    )
    with pytest.raises(exceptions.Lima2Error) as e:
        session.post("/")
    assert type(e.value) is exceptions.Lima2Error


def test_session_requests(session, conductor_mock_get, conductor_mock_post):
    """No errors!"""
    conductor_mock_post("/", status_code=202, json={"abc": 123})
    res = session.post("/")
    assert res.json() == {"abc": 123}


def test_session_system_state(services, conductor_mock_get):
    conductor_mock_get(
        "/state",
        json={
            "state": "IDLE",
            "runstate": "NONE",
            "devices": {"a": "IDLE", "b": "PREPARED", "c": "RUNNING"},
        },
    )
    assert services.connection_state() == ConnectionState.ONLINE

    conductor_mock_get(
        "/state",
        json={
            "state": "DISCONNECTED",
            "runstate": "NONE",
            "devices": {"a": "IDLE", "b": "PREPARED", "c": "DISCONNECTED"},
        },
    )
    assert services.connection_state() == ConnectionState.DEVICES_OFFLINE


def test_session_connection_state(services):
    services.connection_state()
