# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Lima2 conductor client common fixtures."""

import pytest

from lima2.client.services import Acquisition, ConductorServices, Detector, Pipeline
from lima2.client.session import ConductorSession


@pytest.fixture
def conductor_hostname() -> str:
    return "cafedeca"


@pytest.fixture
def conductor_port() -> int:
    return 58712


@pytest.fixture
def conductor_url(conductor_hostname, conductor_port) -> str:
    return f"http://{conductor_hostname}:{conductor_port}"


@pytest.fixture
def conductor_mock_get(conductor_url, requests_mock):
    def wrapper(endpoint: str, status_code=200, **kwargs):
        requests_mock.get(
            f"{conductor_url}{endpoint}", status_code=status_code, **kwargs
        )

    return wrapper


@pytest.fixture
def conductor_mock_post(conductor_url, requests_mock):
    def wrapper(endpoint: str, status_code=202, **kwargs):
        requests_mock.post(
            f"{conductor_url}{endpoint}", status_code=status_code, **kwargs
        )

    return wrapper


@pytest.fixture
def session(conductor_hostname, conductor_port):
    return ConductorSession(hostname=conductor_hostname, port=conductor_port)


@pytest.fixture
def acquisition(session):
    return Acquisition(session)


@pytest.fixture
def detector(session):
    return Detector(session)


@pytest.fixture
def pipeline(session):
    return Pipeline(session)


@pytest.fixture
def services(acquisition, detector, pipeline, session):
    return ConductorServices(
        acquisition=acquisition, detector=detector, pipeline=pipeline, session=session
    )
