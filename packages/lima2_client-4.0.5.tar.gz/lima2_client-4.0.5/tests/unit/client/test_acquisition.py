# This file is part of the Lima2 project
#
# Copyright (c) 2020-2024 Beamline Control Unit, ESRF
# Distributed under the MIT license. See LICENSE for more info.

"""Test suite for lima2.client.services.acquisition."""

from uuid import uuid1

import pytest

from lima2.common import exceptions
from lima2.common.progress_counter import ProgressCounter, SingleCounter


def test_acquisition_counters(acquisition, conductor_mock_get):
    conductor_mock_get(
        "/acquisition/nb_frames_acquired",
        json=SingleCounter(
            name="nb_frames_acquired", value=42, source="dev/control"
        ).asdict(),
    )
    conductor_mock_get(
        "/acquisition/nb_frames_xferred",
        json=ProgressCounter(
            name="nb_frames_xferred",
            counters=[
                SingleCounter(
                    name="nb_frames_xferred", value=55 + i, source=f"dev/receiver{i}"
                )
                for i in range(4)
            ],
        ).asdict(),
    )

    assert acquisition.nb_frames_acquired() == 42
    assert acquisition.nb_frames_xferred() == sum([55 + i for i in range(4)])


def test_acquisition_run(acquisition, conductor_mock_get, conductor_mock_post):
    uuid = uuid1()
    conductor_mock_post(
        "/acquisition/prepare",
        json=str(uuid),
    )
    acq_uuid = acquisition.prepare(control={}, receiver={}, processing={})
    assert acq_uuid == uuid

    conductor_mock_post(
        "/acquisition/start",
        status_code=400,
        json=exceptions.serialize(exceptions.Lima2Error()),
    )
    with pytest.raises(exceptions.Lima2Error):
        acquisition.start()
    conductor_mock_post("/acquisition/start", status_code=202)
    acquisition.start()

    conductor_mock_post("/acquisition/trigger")
    acquisition.trigger()

    conductor_mock_post("/acquisition/stop")
    acquisition.stop()

    conductor_mock_post("/acquisition/reset")
    acquisition.reset()

    conductor_mock_get("/acquisition/errors", json=["first error", "second error"])
    assert acquisition.errors() == [
        "first error",
        "second error",
    ]


def test_acquisition_state(acquisition, conductor_mock_get):
    conductor_mock_get("/acquisition/state", json="Cafe")
    assert acquisition.state() == "Cafe"

    conductor_mock_get("/acquisition/running", json=True)
    conductor_mock_get("/acquisition/failed", json=False)
    assert acquisition.running()
    assert not acquisition.failed()


def test_acquisition_params(acquisition, conductor_mock_get):
    schema = {
        "control": {"type": "string", "default": "cafe"},
        "acquisition": {"type": "string", "default": "deca"},
    }
    conductor_mock_get("/acquisition/params_schema", json=schema)
    assert acquisition.params_schema() == schema
    default_params = {
        "control": {"hello": "world"},
        "receiver": {"cafe": "deca"},
    }
    conductor_mock_get("/acquisition/default_params", json=default_params)
    assert acquisition.default_params() == (
        default_params["control"],
        default_params["receiver"],
    )
