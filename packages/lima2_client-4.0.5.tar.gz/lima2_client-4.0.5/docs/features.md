# Features

The Lima2 system supports various [detectors](#detectors) and [processing
pipelines](#processing).

It is designed to scale with an experiment's needs by being
[distributed](#distributed-acquisition) across multiple processes and multiple
machines.

## Detectors

Lima2 currently supports the following detectors:

- [Dectris Pilatus4](https://dectris.com/en/detectors/x-ray-detectors/pilatus4/)
- [Dectris Eiger2](https://dectris.com/en/detectors/x-ray-detectors/eiger2/)
- [ESRF Smartpix](https://iopscience.iop.org/article/10.1088/1748-0221/10/01/C01019)
- [PSI Jungfrau](https://www.psi.ch/en/lxn/jungfrau)

For development and testing without any hardware, Lima2 provides a simulator
which can generate images or load an existing dataset from disk.

The simulator is designed to help you getting started with Lima and to test/play Lima without any hardware.

The simulator provides two modes of operations:

- **generator** generates frames with diffraction patterns and a set of parameters can be tuned to change those patterns like for instance the number and position of gaussian peaks;
- **loader** reads frames from files.

Both modes have a prefetched variant, where the frames are prefetched in memory before the acquisition is started. This feature allows to simulate high frame rates detectors.

## Processing

Lima2 implements the following processing pipelines:

- Legacy (aka Classic): a standard, CPU-based processing pipeline for generic image acquisition with optional [ROIs](./concepts.md#region-of-interest-roi).
- [Smx (Serial Macromolecular Crystallography)](https://www.esrf.fr/id29): involves GPU-based processing to perform online azimuthal integration.
- [XPCS (X-ray Photon Correlation Spectroscopy)](https://www.esrf.fr/UsersAndScience/Experiments/CBS/ID10): a pipeline dedicated to extracting temporal correlations from the images.

Naturally, depending on the chosen processing type, the kinds of frames and
[reduced data](./concepts.md#reduced-data) available to consumers changes.

## Distributed acquisition

Lima2 can be distributed across multiple processes and multiple machines. This
allows users to scale their integration depending on their processing needs and
the needs of their detector.

The Lima2 system supports three different frame-dispatching configurations ([_topologies_](./concepts.md#topology)):

- **Single-receiver**: a trivial topology where all frames are processed by one
  device.
- **Round robin**: a configuration where frames are sent to each receiver in turn,
  following a strict sequential ordering. This topology is implemented by the
  [PSI Jungfrau](./features.md#detectors).
- **Dynamic dispatch**: a non-deterministic configuration, where any receiver may
  receive the next frame. In such cases, the Conductor takes responsibility for
  building a [lookup table](./concepts.md#lookup). This topology is observed with the [Dectris Pilatus4](./features.md#detectors).

### Sequential frame data (master file)

In distributed acquisitions, each Lima2 receiver process will save files
independently, so consecutive frames in a file will typically not correspond to
consecutive frames from the detector.

In order to provide a time-ordered, sequential set of frames, the Conductor is
responsible for building a virtual dataset of the entire acquisition. This
sequential dataset is saved to the _master file_ alongside the other files.

The master file is not a copy of the raw data, but only contains references to
frames in the raw files saved by Lima2 receivers.
