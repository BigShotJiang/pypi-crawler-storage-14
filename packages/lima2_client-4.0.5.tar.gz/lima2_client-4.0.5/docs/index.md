# Introduction

Lima2 is an [ESRF](https://www.esrf.eu/about) project designed to provide a
single distributed image acquisition and processing system supporting a variety
of [2D X-ray cameras](./features.md#detectors) and [online processing
pipelines](./features.md#processing).

It is an open source project consisting of two repositories:

- [lima2](https://gitlab.esrf.fr/limagroup/lima2) is the C++ backend. It
  features heavily parallel and scalable image acquisition and processing.
  Binaries are published to [anaconda.org](https://anaconda.org/esrf-bcu/lima2),
- [lima2-client](https://gitlab.esrf.fr/limagroup/lima2-client) contains a
  Python orchestrator for distributed acquisitions, and a client library
  provided for developers of control, monitoring and analysis applications.

![Lima2 components and repos](./assets/lima2-components-and-repos.svg)

To get started with Lima2 in general, have a look at the
[features](./features.md), and follow the [quickstart guide](#quickstart).

To integrate Lima2 into your application, check out the [user
guide](./getting_started.md).

{!README.md!lines=1-99999999}
