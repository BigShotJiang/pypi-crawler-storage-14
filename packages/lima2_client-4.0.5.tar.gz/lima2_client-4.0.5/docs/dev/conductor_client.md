# Conductor client

The Conductor client (`lima2.client` package) is the Python front-end for the
Conductor, and thus the whole Lima2 system. It defines functions that wrap HTTP
requests to the Conductor into a Python API (see
[reference](../reference/index.md)).

The `lima2.client` library wraps all HTTP requests with an associated conductor
endpoint into python functions.

It is intended to be stateless: all services are accessible as long as the
conductor is running. The client only needs to provide the hostname and port of
the conductor webservice to instantiate service objects
