# Conductor design and implementation

!!! note

    This section describes the *initial* design and implementation of the Conductor. The
    code has since moved on in a few areas, but the broader original ideas remain.

## Architecture and design

This section describes the implementation details of the Conductor's mechanisms
and services.

The Conductor has a heavy I/O load, needing to communicate with tango devices on
one hand, and with clients on the other. Therefore, it builds on the foundation
of an asynchronous web server to handle requests from multiple clients, while
using the "async" flavor of tango to interact with the lima2 devices. Building
the Conductor on double-ended asynchronous communication frees it from waiting
on I/O calls, which makes it responsive despite the fact that it runs on a
single CPU thread.

To enable this cooperative concurrency, the entire call chain from, say, a user
command coming in, to its dispatch to the lima2 devices, is asynchronous. This
makes it possible for a second client request to be served while the first one
waits for I/O-bound calls, e.g. to fetch a large data blob.

![Conductor communication model](../assets/lima2-conductor-communication-model.svg)

### Framework

The Conductor builds on the asyncio framework of standard Python to make its
blocking I/O calls cooperatively concurrent.

The client-facing side of the Conductor, which handles e.g. user commands, is
written using the [Starlette web framework](https://www.starlette.io/) to define
endpoints, routes and request handlers in the asyncio scheme. The server-facing
side uses the "asyncio" mode of pytango's DeviceProxy objects.

The Conductor maintains an internal state which is impacted by user commands and
server-side events, and which is continually updated during image acquisitions.
Having all the necessary state in the Conductor process relieves clients from
having to store any state themselves, which naturally prevents the issue of
desynchronized clients present before the Conductor was added to Lima2.

### Initialization

When `lima2-conductor` is launched, an
[`AcquisitionSystem`](#acquisition-system) object is instantiated using the
names of the lima2 tango devices and the frame dispatch [topology](#topology).

Then, the `uvicorn` async web server starts running our webapp, defined in
`lima2.conductor.webservice`. The webapp keeps a reference to the
`AcquisitionSystem` object as part of its `state` (see [Starlette
lifespan state](https://www.starlette.io/lifespan/#lifespan-state)) so that
request handlers may access it. This effectively wraps the `AcquisitionSystem`
into the web server, enabling the client to run commands and retrieve data.

### Acquisition system

The `AcquisitionSystem` class is the brain of the Conductor. It contains all the
logic to prepare and run an acquisition, and process the results, exposing the
acquired and processed data to downstream consumers.

It communicates directly with the Lima2 devices via tango to dispatch commands
and query attributes. It also registers event handlers to stay updated of the
state of the running acquisition.

![Conductor modules and dependencies](../assets/lima2-conductor-modules.svg)

It is the coupling point between state, command-handling, data retrieval and
[master file](../concepts.md#master-file) generation logic. For instance, a call
to prepare will dispatch parameters to the lima2 devices and then instantiate a
Pipeline object, whose job will be to fetch reduced data from the processing
devices, handle processing errors, and generate the master files for persistent
frame channels according to the dispatching topology.

The `AcquisitionSystem` holds references to the lima2 tango devices (control,
receivers, processing) and has knowledge of the frame dispatch topology.

It is the entrypoint for sending commands to the devices, i.e. it has methods to
handle prepare, start, stop, reset, and trigger commands. It holds a light
internal state called RunState, which follows the evolution of the current
acquisition and can be used by clients to query the current run's status (see
[State](#state)).

The `AcquisitionSystem` establishes tango event channels with the devices in order
to detect end of acquisition and end of processing signals, and to relay errors
during acquisition or processing. On startup, the `AcquisitionSystem` registers
callbacks the the "acq_state" `CHANGE_EVENT` in order to detect end-of-acquisition
events. After calling `prepare()` to set up an acquisition, it also registers
callbacks to each processing device for the following events:

- "is_finished" `DATA_READY_EVENT` to detect end-of-processing,
- "last_error" `DATA_READY_EVENT` to detect an error during processing.

### State

The Conductor computes the system-wide state on demand, based on the individual
states of Lima2 devices. This value is transient and only valid at the time of
calling, since it is re-evaluated every time. This helps to avoid issues of
synchronization between the Conductor and devices.

During an acquisition, the Conductor additionally maintains a light acquisition
state, called RunState. The RunState encodes whether acquisition and/or
processing are still ongoing. It is updated by tango events coming from the
devices. It has a "fault" value, set when a receiver enters the `FAULT` state,
or when an exception is thrown in the processing thread. This state can be used
by clients to detect a failed run.

### Topology

[Topology](../concepts.md#topology) refers to the way frames are dispatched by
the detector to the receivers.

The currently supported topologies are:

- Single receiver: one receiver processes all the frames
- Round robin dispatch: receivers take turns receiving frames, in a static order
- Dynamic dispatch: frames are sent to receivers in an unpredictable, dynamic
  order

For example, the Jungfrau detector is known to dispatch frames according to a
strict round robin distribution, whereas the Dectris Pilatus4 has a
non-deterministic load-balancing mechanism which distributes frames depending on
the processing load of each receiver.

The current topology concept assumes homogeneous processing, i.e. where all
receivers apply the same processing to the frames.

### Processing

On **`prepare`**, the Conductor instantiates a `Pipeline` object which represents
the distributed processing system. It hands down to this object the
responsibilities tied to the current acquisition: reduced data
fetching/reordering, frame lookup and master file generation.

The Pipeline object additionally propagates any errors from the processing
devices up to the `AcquisitionSystem` so that it can report a FAULT to clients.

On **`start`**, the `Pipeline`'s reduced data fetching and master file
generation tasks are launched.

#### Reduced data

The Conductor is responsible for retrieving reduced data from the Lima2
processing devices and providing them in sequential order to any interested
clients. This task is the Conductor's most CPU-intensive, since it requires some
sorting of the data by frame index.

The Lima2 devices provide "pop" methods to retrieve all reduced data of a given
type since the last call. Hence there is some complexity in the reduced data
fetching and reordering algorithm, to pop data from each device, concatenate it
and reorder it at each iteration.

A convenient way to provide the reordered reduced data to consumers is as a HTTP
stream. A consumer makes one request at any point of the acquisition, and then
iterates over chunks of the response, which the server fills with data for each
frame.

Implementing this mechanism in the Starlette framework is relatively
straightforward, it only requires us to expose the ordered data as an async
iterator.

A special case of reduced data fetching is the `frame_idx` channel, which is
enabled by the `Pipeline` instance on `prepare`, in the case of a dynamic
dispatch topology. This allows the lookup table to be populated with (frame
index, receiver) pairs to assign each frame to a specific receiver, which
enables frame lookups and generation of the [master
file](#master-file-generation).

#### Master file generation

The Conductor uses knowledge of the [dispatch topology](#topology) to generate a
master file containing a sequentially ordered [Virtual
Dataset](https://docs.h5py.org/en/stable/vds.html) during the acquisition.

In the case of single-receiver and round robin topologies, the VDS can be
computed straight away, and the master file written early in the run.

In the dynamic dispatch topology, the VDS is populated during the run as the
lookup table fills up from fetching the `frame_idx` [reduced
data](#reduced-data).

#### Lookup

Lookup is implemented by the Topology subclass which corresponds to the
detector's frame dispatching strategy (see [Topology](../concepts.md#topology)).

In the case of dynamic dispatch, the `lookup()` call relies on a lookup table
object populated asynchronously by the reduced data fetching task in order to
assign each frame to a receiver.

The special case of looking up the latest frame available is handled by the
`Pipeline` instance, since it requires information from each processing device
to determine which one has the most recent frame. In a round robin topology, the
lookup returns the name of the receiver with the most frames processed. In
dynamic dispatch, the lookup table is queried instead to determine the receiver
with the most frames acquired.
