# Design docs

This section contains software design and implementation details for the
internals of the Lima2 Client and Conductor modules.
