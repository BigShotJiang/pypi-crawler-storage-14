# Conductor requirements

## Specification

The Lima2 Conductor is the centralized entry point in distributed image
acquisitions. It acts as a middleman between clients (bliss, blissdata) and the
lima2 control, receiver and processing devices. Its goal is to encapsulate the
complexity of the acquisition system, without causing unnecessary network or CPU
bottlenecks.

Its responsibility lies mostly in easing communication between clients and the
acquisition system, while trying to stay as conservative as possible on
CPU-bound tasks. Because it communicates with lima2 tango devices on one side,
and clients on the other, it needs to be able to handle heavy I/O loads,
especially when large amounts of reduced data must be transferred from
processing pipelines to bliss and/or online data analysis clients.

## Responsibilities

The Conductor holds the following responsibilities within the Lima2 acquisition system:

- **State**: the state of the system should be accurately represented, so that
  clients are aware of the current status during acquisition and of potential
  acquisition and processing errors.
- **Control**: user commands should be dispatched to the control and receiver
  devices when the state allows, and a mechanism should exist to prevent
  incompatible concurrent commands.
- **Progress**: up-to-date progress and potential errors of the current
  acquisition should be readily available. The conductor should provide a
  service to determine the range of frames available for consumption. Since the
  primary mechanism for consumption is slicing of the associated blissdata
  stream, the conductor must be able to provide an up-to-date contiguous range
  of frame indices ready for fetching from memory or file.
- **Reduced data aggregation**: data other than frames, produced by the
  processing pipelines on each receiver (e.g. ROI statistics), should be
  aggregated and ordered linearly by the Conductor. A service should allow
  clients to fetch this data as it becomes available during the acquisition.
- **Frame lookup**: a lookup service should be provided for clients to determine
  the location of any given frame, regardless of the frame dispatch topology.
- **Master file generation**: in distributed acquisitions, frames will be saved
  to different files by different receivers. The Conductor shall use its
  knowledge of the dispatch topology to write master files, where the temporal
  order is restored for ease of use by downstream processing pipelines.
