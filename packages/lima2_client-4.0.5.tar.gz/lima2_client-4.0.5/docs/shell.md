# `lima2-shell`

The `lima2-shell` is an interactive ipython session meant to allow simple
interactions with a running Conductor. After installing the `lima2-client[dev]`
dependencies, start the session using:

```sh
lima2-shell
```

If `lima2-conductor` is listening at `localhost:58712`, the shell should start
successfully. See [Quickstart instructions](./index.md#quickstart) for
instructions on running Lima2 and `lima2-conductor`. If `lima2-conductor` is
running elsewhere, use the `--conductor-hostname` and/or `--conductor-port`
parameters.

Inside the session, the [`acquisition`](./reference/acquisition.md),
[`detector`](./reference/detector.md) and [`pipeline`](./reference/pipeline.md)
objects give you access to all the conductor's services. A set of default
parameters (`ctl`, `acq`, `proc`) is provided to run an acquisition with the
[Legacy](./features.md#processing) pipeline:

```py
In [0]: acquisition.prepare(ctl, acq, proc)
Out[0]: UUID('ae08c23e-3d5a-11f0-9280-d119a03b783d')

In [1]: acquisition.start()

In [2]: acquisition.nb_frames_xferred()
Out[2]: 120

In [3]: pipeline.progress()
Out[3]: 120
```

All functions listed in the [API reference](./reference/index.md) are available
in the `lima2-shell`.
