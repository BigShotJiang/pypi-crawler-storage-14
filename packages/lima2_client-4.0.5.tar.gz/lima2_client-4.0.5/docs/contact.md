# Contact

The Lima/Lima2 development team can be reached at <lima@esrf.fr>.

To stay informed of any news, you may also want to subscribe
to our mailing list by sending a message to
[sympa@esrf.fr](mailto:sympa@esrf.fr?subject=subscribe%20lima) with
"`subscribe lima`" as subject.
