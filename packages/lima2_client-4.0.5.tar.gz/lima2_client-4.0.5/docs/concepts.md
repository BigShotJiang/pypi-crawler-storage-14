# Concepts

This section contains a listing of Lima2-specific terms used throughout the code
and documentation, with a short definition.

## Progress

In a distributed acquisition, progress refers to counters incremented by Lima2 at various stages of the acquisition and processing pipeline.

The Conductor has the role of aggregating counters from all devices in order to
present a coherent system-wide picture to the controlling application.

In the Legacy pipeline, progress counters such as "number of frames acquired",
"number of frames processed", and "number of frames saved" are exposed so that
clients can be aware of the exact status of processing.

## Topology

Topology refers to the dispatching mechanism used by the detector to send frames
to receivers in a distributed (multi-receiver) acquisition.

Topologies supported by the Lima2 system are listed
[here](./features.md#distributed-acquisition).

## Reduced data

Information extracted from raw frames by the Lima2 online processing pipeline.
This data is typically retrieved by the Conductor during the acquisition,
ordered sequentially in case of distributed acquisitions, so that consumers can
access it as if it came from a single source.

## Master file

The master file is the main post-acquisition lookup mechanism provided by the
Lima2 acquisition system. It is written to disk by the Conductor using its
knowledge of the [topology](#topology).

## Region of interest (ROI)

User-defined region of a frame where statistics are computed over all pixels (min, max, sum, average, standard deviation). These regions are fixed throughout the acquisition.

The 1D converse of the ROI is the ROI-profile. In a ROI-profile, statistics are computed over each column or each row of the region, yielding a horizontal or vertical profile, respectively.

## Lookup

In a distributed acquisition, the Conductor is responsible for knowing when
frames can be accessed by consumers, and from which receiver they should be
retrieved. Since frames are processed by different receivers at different rates,
it is not always simple to determine if a given frame is available for retrieval
at a given time. For this reason, the Conductor implements a topology-aware lookup mechanism.

For instance, in a round robin topology, it is trivial to determine which
receiver will receive a given frame, but one cannot hope to guess whether it is
available or not based on aggregated progress counters (since a receiver may lag
behind the others and throw off the guess).

Thus, a consumer wanting to retrieve a frame will always need to make a lookup
call to the Conductor first, so that the request can be properly handled and
dispatched to the correct receiver, or rejected if no receiver can satisfy it.
