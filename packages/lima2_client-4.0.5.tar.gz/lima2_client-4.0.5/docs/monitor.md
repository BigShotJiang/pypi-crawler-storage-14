# `lima2-monitor`

!!! warning

    This section is incomplete.

The `lima2-monitor` is an online visualization tool with a web-based frontend.

It is currently in development. More information to follow.
