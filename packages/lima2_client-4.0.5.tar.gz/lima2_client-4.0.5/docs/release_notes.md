# Release notes

See our [Releases page](https://gitlab.esrf.fr/limagroup/lima2-client/-/releases).
