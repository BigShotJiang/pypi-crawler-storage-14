# API reference

This is the `lima2.client` API reference.

- [`lima2.client.services.Acquisition`](./acquisition.md)
- [`lima2.client.services.Detector`](./detector.md)
- [`lima2.client.services.Pipeline`](./pipeline.md)
- [`lima2.client.session`](./session.md)
- [`lima2.client.exceptions`](./exceptions.md)
