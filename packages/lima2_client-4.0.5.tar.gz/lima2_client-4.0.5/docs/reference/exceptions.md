# Exceptions

::: lima2.common.exceptions
    options:
      toc_label: lima2.common.exceptions
      show_root_heading: true
      show_if_no_docstring: true
      summary:
        classes: true
      filters:
      - "!^_"
      members_order: source


::: lima2.client.exceptions
    options:
      toc_label: lima2.client.exceptions
      show_root_heading: true
      show_if_no_docstring: true
      summary:
        classes: true
      filters:
      - "!^_"
      members_order: source

