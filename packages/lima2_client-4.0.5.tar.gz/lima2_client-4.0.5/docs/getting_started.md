# Getting started

This guide is intended to help users of the `lima2.client` library. This mainly
includes developers of experiment control, monitoring and data analysis
software.

From a working Lima2 setup, we will run an image acquisition and query the
results via the conductor, using the `lima2.client` API.

Services exposed by the client library are documented in the
[reference](./reference/index.md). The API is further split into
[acquisition](./reference/acquisition.md), [detector](./reference/detector.md)
and [pipeline](./reference/pipeline.md).

## Setup

This guide assumes a working Lima2 setup with running simulator devices and a
conductor. The [quickstart instructions](./index.md#quickstart) should
help you to get this far.

## Using the services

Once your Lima2 setup is in place, using the `lima2.client` library in
your application only requires the
[`lima2-client`](https://pypi.org/project/lima2-client/) dependency, available
from PyPI.

Assuming you have running Lima2 devices and a `lima2-conductor` listening at
`localhost:58712`, initialize a session to get access to the services:

```py
from lima2.client import services

session = services.init(hostname="localhost", port=58712)
```

Now, you have access to the [`session.acquisition`](./reference/acquisition.md),
[`session.detector`](./reference/detector.md) and [`session.pipeline`](./reference/pipeline.md) service objects.

## Acquisition

Start by fetching a set of default parameters:

```py
control, receiver = session.acquisition.default_params()
processing = session.pipeline.default_params("LimaProcessingLegacy")
```

Now run an acquisition:

```py
# A few things happen when we prepare()
# 1. Parameters are dispatched to the lima2 devices
# 2. The detector is configured for this acquisition
# 3. The processing pipeline is instantiated on each receiver
session.acquisition.prepare(control, receiver, processing)

# If everything went well, we can now start the acquisition
session.acquisition.start()
```

The parameters are meant to be modified depending on your acquisition and
processing needs.

Acquisition params include the number of frames to acquire and the exposition
time for each frame, for instance. Detector-specific parameters can also be
tweaked there.

Processing params are entirely pipeline-dependent. For a
[Legacy](./features.md#processing) pipeline, one can e.g. add [regions of
interest](./concepts.md#region-of-interest-roi) and modify where frames are
saved to disk.

## Progress and data access

After starting the acquisition, everything happens asynchronously. You can query
how many frames have been transferred from the camera to the processing
pipeline:

```py
session.acquisition.nb_frames_xferred()
# -> 1
```

You can now also use the [`session.pipeline`](./reference/pipeline.md) service object to
query the progress of the **processing pipeline** itself, as well as any data it
has produced:

```py
session.pipeline.progress()
# -> 0
```

Obtaining frame data requires the client to communicate with Lima2 device
servers directly (using tango), so we must first set the `TANGO_HOST`
environment variable:

```py
import os
os.environ["TANGO_HOST"] = "localhost:10000"

session.pipeline.get_frame(frame_idx=-1, source="frame")
# -> Frame(data=array([[[0, 0, 0, ...
```

## Next steps

You can now configure and control Lima2 acquisitions, and query the outcomes.
For more details, the [reference](./reference/index.md) lists all available
services in the `lima2.client` API.

To get in touch with the dev team for support, see [contact](./contact.md).
