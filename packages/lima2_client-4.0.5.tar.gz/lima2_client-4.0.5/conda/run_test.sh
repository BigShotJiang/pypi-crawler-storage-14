#!/bin/bash
#
# Run lima2-client unit and integration tests

pip check

pytest tests/unit

# (Only available from PyPI)
pip install nosqltangodb

pytest tests/integration
