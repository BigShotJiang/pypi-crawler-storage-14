"""
MCP GIF 分割服务器

基于Model Context Protocol (MCP)的服务器，提供GIF动画分割功能。
将动态GIF拆分为多张静态图片，支持多种输出格式。
"""

__version__ = "0.1.0"
__author__ = "fengjinchao"
__email__ = "fengjinchao@example.com"

from .server import main

__all__ = [
    "main",
]
