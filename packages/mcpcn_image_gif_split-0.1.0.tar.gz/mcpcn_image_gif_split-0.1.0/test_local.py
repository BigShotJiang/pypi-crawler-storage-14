"""
本地测试脚本

用于测试 GIF 分割功能，无需启动完整的 MCP 服务器。
"""

import asyncio
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

from mcp_gif_split.server import split_gif_frames


async def test_split_gif():
    """测试 GIF 分割功能"""
    print("=" * 60)
    print("GIF 分割工具测试")
    print("=" * 60)

    # 提示用户输入测试文件
    gif_path = input("\n请输入要测试的 GIF 文件路径（或按 Enter 跳过）: ").strip()

    if not gif_path:
        print("\n⏭️  跳过测试（未提供 GIF 文件）")
        print("\n如需测试，请提供一个 GIF 文件路径，例如:")
        print("  /path/to/animation.gif")
        print("  ~/Downloads/test.gif")
        return

    print(f"\n📂 测试文件: {gif_path}")
    print("⚙️  使用默认设置进行分割...")

    try:
        result = await split_gif_frames(
            file_path=gif_path,
            output_dir=None,  # 使用默认输出目录
            filename_prefix="frame",
            image_format="PNG",
            keep_transparency=True
        )

        print("\n✅ 分割成功！")
        print(f"  输出目录: {result['output_dir']}")
        print(f"  帧数量: {result['frame_count']}")
        print(f"  图片格式: {result['image_format']}")
        print(f"\n  前 5 个文件:")
        for i, file in enumerate(result['files'][:5], 1):
            print(f"    {i}. {Path(file).name}")
        if result['frame_count'] > 5:
            print(f"    ... 还有 {result['frame_count'] - 5} 个文件")

    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()


async def test_custom_settings():
    """测试自定义设置"""
    print("\n" + "=" * 60)
    print("测试自定义设置")
    print("=" * 60)

    gif_path = input("\n请输入要测试的 GIF 文件路径（或按 Enter 跳过）: ").strip()

    if not gif_path:
        print("\n⏭️  跳过自定义测试")
        return

    print(f"\n📂 测试文件: {gif_path}")
    print("⚙️  使用自定义设置: WEBP 格式，不保留透明度")

    try:
        result = await split_gif_frames(
            file_path=gif_path,
            output_dir=None,
            filename_prefix="custom",
            image_format="WEBP",
            keep_transparency=False
        )

        print("\n✅ 自定义设置测试成功！")
        print(f"  输出目录: {result['output_dir']}")
        print(f"  帧数量: {result['frame_count']}")
        print(f"  图片格式: {result['image_format']}")

    except Exception as e:
        print(f"\n❌ 自定义测试失败: {e}")


async def main():
    """主函数"""
    print("\n🎬 MCP GIF 分割工具 - 本地测试\n")

    # 测试基本功能
    await test_split_gif()

    # 测试自定义设置
    # await test_custom_settings()

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
