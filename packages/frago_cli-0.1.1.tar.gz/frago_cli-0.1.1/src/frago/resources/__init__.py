"""
frago 资源包

存放随 frago 分发的资源文件：
- commands/: Claude Code slash 命令
- recipes/: 示例 recipe
"""
