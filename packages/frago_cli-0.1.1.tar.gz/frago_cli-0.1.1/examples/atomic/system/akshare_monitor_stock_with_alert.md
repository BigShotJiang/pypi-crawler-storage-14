---
name: akshare_monitor_stock_with_alert
type: atomic
runtime: python
description: "持续监控股票价格并在异常波动时告警（支持自定义阈值和监控时长）"
use_cases:
  - "实时监控重点关注股票的异常波动"
  - "触发价格告警时执行后续操作（如发送通知）"
  - "记录完整的价格变化历史供事后分析"
tags:
  - stock
  - akshare
  - monitoring
  - alert
  - realtime
output_targets:
  - stdout
  - file
inputs:
  symbol:
    type: string
    required: true
    description: "A股股票代码（6位数字）"
  interval:
    type: number
    required: false
    description: "轮询间隔（秒），默认60"
  duration:
    type: number
    required: false
    description: "监控时长（秒），默认300（5分钟）"
  output_dir:
    type: string
    required: false
    description: "输出目录，默认 'outputs'"
  alert_change_pct:
    type: number
    required: false
    description: "涨跌幅告警阈值（%），默认3.0"
  alert_amplitude:
    type: number
    required: false
    description: "振幅告警阈值（%），默认8.0"
outputs:
  data:
    type: object
    description: "包含监控摘要、告警记录和数据文件路径"
dependencies: []
version: "1.0.0"
---

# akshare_monitor_stock_with_alert

## 功能描述

持续监控指定股票的价格变化，并在触发告警条件时：
1. **记录告警**: 保存告警详情到 JSON 文件
2. **持久化数据**: 所有采样数据保存到 JSONL 文件
3. **实时输出**: 在 stderr 显示实时状态，stdout 输出最终结果
4. **自动重试**: 网络失败自动重试3次

**告警条件**：
- 涨跌幅超过阈值（默认±3%）
- 振幅超过阈值（默认8%）

适用于需要实时监控股价异常波动的场景，可集成到更复杂的监控和通知系统中。

## 使用方法

**基础监控**（默认5分钟，60秒间隔）：
```bash
uv run frago recipe run akshare_monitor_stock_with_alert \
  --params '{"symbol": "000001"}'
```

**自定义参数**：
```bash
uv run frago recipe run akshare_monitor_stock_with_alert \
  --params '{
    "symbol": "000001",
    "interval": 30,
    "duration": 1800,
    "alert_change_pct": 2.0,
    "alert_amplitude": 5.0,
    "output_dir": "my_monitoring"
  }' \
  --output-file monitoring_result.json
```

**后台运行**（长时间监控）：
```bash
nohup uv run frago recipe run akshare_monitor_stock_with_alert \
  --params '{"symbol": "000001", "duration": 14400}' \
  > monitor.log 2>&1 &
```

## 前置条件

- 已安装依赖: `uv pip install akshare pandas`
- 网络稳定（需持续访问API）
- 在交易时间执行（非交易时间无数据）

## 预期输出

### 实时输出（stderr）

```
🚀 开始监控股票 000001
⏰轮询间隔: 60秒
⏱️  监控时长: 300秒
📁 数据文件: outputs/monitor_000001_20251124_153000.jsonl
🔔 告警阈值: 涨跌幅±3.0%, 振幅>8.0%
============================================================
✅ [1] 2025-11-24 15:30:00 | 价格: ¥12.58 | 涨跌: +2.35% | 成交量: 152,345
✅ [2] 2025-11-24 15:31:00 | 价格: ¥12.62 | 涨跌: +2.68% | 成交量: 168,234
⚠️  [3] 告警: 涨跌幅 +3.20% 超过阈值 ±3.0%
✅ [3] 2025-11-24 15:32:00 | 价格: ¥12.70 | 涨跌: +3.20% | 成交量: 185,672
...
============================================================
📊 监控结束
⏱️  总耗时: 300秒
📝 采集次数: 5次
🔔 告警次数: 1次
```

### 最终结果（stdout JSON）

```json
{
  "success": true,
  "data": {
    "symbol": "000001",
    "start_time": "2025-11-24 15:30:00",
    "end_time": "2025-11-24 15:35:00",
    "duration_seconds": 300,
    "interval_seconds": 60,
    "total_samples": 5,
    "alert_count": 1,
    "alerts": [
      {
        "symbol": "000001",
        "timestamp": "2025-11-24 15:32:00",
        "alert": {
          "type": "price_change",
          "message": "涨跌幅 +3.20% 超过阈值 ±3.0%",
          "severity": "high"
        },
        "data": {
          "price": 12.70,
          "change_pct": 3.20,
          ...
        }
      }
    ],
    "data_file": "outputs/monitor_000001_20251124_153000.jsonl",
    "alert_dir": "outputs/alerts"
  }
}
```

### 生成的文件

1. **数据文件**（JSONL格式）: `outputs/monitor_<symbol>_<timestamp>.jsonl`
   ```jsonl
   {"symbol":"000001","timestamp":"2025-11-24 15:30:00","price":12.58,...}
   {"symbol":"000001","timestamp":"2025-11-24 15:31:00","price":12.62,...}
   ```

2. **告警文件**（JSON格式）: `outputs/alerts/alert_<symbol>_<timestamp>.json`
   ```json
   {
     "symbol": "000001",
     "timestamp": "2025-11-24 15:32:00",
     "alert": {...},
     "data": {...}
   }
   ```

## 注意事项

- **长时间运行**: 设置较长的 `duration` 时建议后台运行（nohup/screen/tmux）
- **磁盘空间**: JSONL 文件会持续增长，注意磁盘空间（每次采样约200字节）
- **API限流**: 不建议 `interval` 设置过小（<10秒），可能被限流
- **交易时间**: 非交易时间无法获取数据，监控会失败
- **网络稳定性**: 连续3次失败会输出警告，但不会中止监控
- **告警灵敏度**:
  - `alert_change_pct` 设置太小（如0.5%）会频繁告警
  - `alert_amplitude` 对波动较大的股票可能频繁触发

## 更新历史

| 日期 | 版本 | 变更说明 |
|------|------|----------|
| 2025-11-24 | v1.0.0 | 初始版本，支持自定义阈值和自动重试 |
