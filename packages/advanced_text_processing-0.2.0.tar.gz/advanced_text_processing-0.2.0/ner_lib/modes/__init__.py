"""Modes package."""

from ner_lib.modes.mode_a import ModeAResolver
from ner_lib.modes.mode_b import ModeBResolver

__all__ = ["ModeAResolver", "ModeBResolver"]
