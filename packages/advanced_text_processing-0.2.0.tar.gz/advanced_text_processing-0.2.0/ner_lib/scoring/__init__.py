"""Scoring package."""

from ner_lib.scoring.aggregation import WeightedAggregator

__all__ = ["WeightedAggregator"]
