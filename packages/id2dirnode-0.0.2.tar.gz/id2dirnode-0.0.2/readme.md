# Implementation of id_to_dirnode.

## Installation

You can install from [pypi](https://pypi.org/project/id2dirnode/)

```console
pip install -U id2dirnode
```

## Usage

```python
from id2dirnode import IdToDirnode
```
