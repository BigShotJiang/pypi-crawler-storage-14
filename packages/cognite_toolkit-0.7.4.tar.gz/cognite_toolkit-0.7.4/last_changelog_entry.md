## Changelog 

### Added

- `StreamsAcl` and `StreamRecordsAcl` class in capabilities for
`GroupYAML`