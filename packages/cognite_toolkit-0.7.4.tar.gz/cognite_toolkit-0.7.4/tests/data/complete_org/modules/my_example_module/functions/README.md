# cdf_functions_dummy

This module is an example for how to define a simple function as a template in a tookit module.
The functions can be found below the 'functions' folder, with one folder per function.
