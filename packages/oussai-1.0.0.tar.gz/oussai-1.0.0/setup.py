from setuptools import setup
setup(
    name="oussai",
    version="1.0.0",
    py_modules=["oussai"],
    install_requires=["requests"],
)
