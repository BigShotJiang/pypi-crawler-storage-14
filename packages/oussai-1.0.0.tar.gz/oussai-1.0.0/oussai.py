import requests
import json

history = []

def chat_stream(message):
    history.append({"role": "user", "content": message})
    
    response = requests.post(
        "https://free.oaibest.com/api/openai/v1/chat/completions",
        json={
            "messages": history,
            "stream": True,
            "model": "gpt-4o-mini",
            "temperature": 0.5
        },
        headers={'Content-Type': 'application/json'},
        stream=True
    )
    
    full_reply = ""
    
    for line in response.iter_lines():
        if not line:
            continue
            
        if line.startswith(b'data: '):
            data = line[6:].decode()
            
            if data == '[DONE]':
                continue
                
            try:
                chunk = json.loads(data)
                content = chunk['choices'][0]['delta'].get('content', '')
                
                if content:
                    full_reply += content
                    yield content
                    
            except json.JSONDecodeError:
                pass
    
    history.append({"role": "assistant", "content": full_reply})
