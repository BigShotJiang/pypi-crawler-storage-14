"""cmem_cmemc module"""
