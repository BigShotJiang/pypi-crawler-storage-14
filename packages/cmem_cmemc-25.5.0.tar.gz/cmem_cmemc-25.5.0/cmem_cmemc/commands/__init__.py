"""cmemc commands."""
