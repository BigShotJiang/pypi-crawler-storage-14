# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkoutboundbot.endpoint import endpoint_data

class SaveAnnotationMissionSessionListRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'OutboundBot', '2019-12-26', 'SaveAnnotationMissionSessionList','outboundbot')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_AgentId(self): # String
		return self.get_query_params().get('AgentId')

	def set_AgentId(self, AgentId):  # String
		self.add_query_param('AgentId', AgentId)
	def get_UserNick(self): # String
		return self.get_query_params().get('UserNick')

	def set_UserNick(self, UserNick):  # String
		self.add_query_param('UserNick', UserNick)
	def get_AgentKey(self): # String
		return self.get_query_params().get('AgentKey')

	def set_AgentKey(self, AgentKey):  # String
		self.add_query_param('AgentKey', AgentKey)
	def get_AnnotationMissionDataSourceType(self): # Long
		return self.get_query_params().get('AnnotationMissionDataSourceType')

	def set_AnnotationMissionDataSourceType(self, AnnotationMissionDataSourceType):  # Long
		self.add_query_param('AnnotationMissionDataSourceType', AnnotationMissionDataSourceType)
	def get_Environment(self): # Long
		return self.get_query_params().get('Environment')

	def set_Environment(self, Environment):  # Long
		self.add_query_param('Environment', Environment)
	def get_AnnotationMissionSessionLists(self): # RepeatList
		return self.get_query_params().get('AnnotationMissionSessionList')

	def set_AnnotationMissionSessionLists(self, AnnotationMissionSessionList):  # RepeatList
		for depth1 in range(len(AnnotationMissionSessionList)):
			if AnnotationMissionSessionList[depth1].get('AnnotationMissionId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionId'))
			if AnnotationMissionSessionList[depth1].get('JobId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.JobId', AnnotationMissionSessionList[depth1].get('JobId'))
			if AnnotationMissionSessionList[depth1].get('CreateTime') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.CreateTime', AnnotationMissionSessionList[depth1].get('CreateTime'))
			if AnnotationMissionSessionList[depth1].get('ScriptId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.ScriptId', AnnotationMissionSessionList[depth1].get('ScriptId'))
			if AnnotationMissionSessionList[depth1].get('ModifiedTime') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.ModifiedTime', AnnotationMissionSessionList[depth1].get('ModifiedTime'))
			if AnnotationMissionSessionList[depth1].get('InstanceId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.InstanceId', AnnotationMissionSessionList[depth1].get('InstanceId'))
			if AnnotationMissionSessionList[depth1].get('AnnotationMissionSessionId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionSessionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionSessionId'))
			if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList') is not None:
				for depth2 in range(len(AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList'))):
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('CreateTime') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.CreateTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('CreateTime'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('TagAnnotationStatus') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.TagAnnotationStatus', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('TagAnnotationStatus'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AsrAnnotationStatus') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AsrAnnotationStatus', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AsrAnnotationStatus'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationAsrResult') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationAsrResult', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationAsrResult'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionSessionId') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionSessionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionSessionId'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('SubStatus') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.SubStatus', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('SubStatus'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatId') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatId'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationStatus') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationStatus', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationStatus'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList') is not None:
						for depth3 in range(len(AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList'))):
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('CreateTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.CreateTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('CreateTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionSessionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.AnnotationMissionSessionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionSessionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.VocabularyId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionChatId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionChatId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('Delete') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.Delete', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('Delete'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.AnnotationMissionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('ModifiedTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.ModifiedTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('ModifiedTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('InstanceId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.InstanceId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('InstanceId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('Vocabulary') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.Vocabulary', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('Vocabulary'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyName') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.VocabularyName', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyName'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('Create') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.Create', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('Create'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyWeight') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.VocabularyWeight', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyWeight'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionChatVocabularyInfoId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatVocabularyInfoId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('AnnotationMissionChatVocabularyInfoId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyDescription') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatVocabularyInfoList.'  + str(depth3 + 1) + '.VocabularyDescription', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatVocabularyInfoList')[depth3].get('VocabularyDescription'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('SequenceId') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.SequenceId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('SequenceId'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList') is not None:
						for depth3 in range(len(AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList'))):
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('CreateTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.CreateTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('CreateTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionSessionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.AnnotationMissionSessionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionSessionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionChatId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionChatId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('IntentId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.IntentId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('IntentId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('DialogId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.DialogId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('DialogId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('Delete') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.Delete', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('Delete'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('Content') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.Content', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('Content'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.AnnotationMissionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('ModifiedTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.ModifiedTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('ModifiedTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('InstanceId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.InstanceId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('InstanceId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionChatIntentUserSayInfoId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatIntentUserSayInfoId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('AnnotationMissionChatIntentUserSayInfoId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('Create') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.Create', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('Create'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('BotId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatIntentUserSayInfoList.'  + str(depth3 + 1) + '.BotId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatIntentUserSayInfoList')[depth3].get('BotId'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionId') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionId'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('ModifiedTime') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.ModifiedTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('ModifiedTime'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('InstanceId') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.InstanceId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('InstanceId'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('IntentAnnotationStatus') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.IntentAnnotationStatus', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('IntentAnnotationStatus'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('OccurTime') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.OccurTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('OccurTime'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('Answer') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.Answer', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('Answer'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList') is not None:
						for depth3 in range(len(AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList'))):
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CreateTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.CreateTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CreateTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionSessionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.AnnotationMissionSessionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionSessionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionChatId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionChatId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.CustomizationDataId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('Delete') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.Delete', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('Delete'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('Content') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.Content', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('Content'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.AnnotationMissionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataWeight') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.CustomizationDataWeight', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataWeight'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('ModifiedTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.ModifiedTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('ModifiedTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('InstanceId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.InstanceId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('InstanceId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('Create') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.Create', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('Create'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionChatCustomizationDataInfoId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatCustomizationDataInfoId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('AnnotationMissionChatCustomizationDataInfoId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataDescription') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.CustomizationDataDescription', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataDescription'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataName') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatCustomizationDataInfoList.'  + str(depth3 + 1) + '.CustomizationDataName', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatCustomizationDataInfoList')[depth3].get('CustomizationDataName'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList') is not None:
						for depth3 in range(len(AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList'))):
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.AnnotationMissionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionTagInfoId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.AnnotationMissionTagInfoId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionTagInfoId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('CreateTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.CreateTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('CreateTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionTagInfoName') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.AnnotationMissionTagInfoName', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionTagInfoName'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionChatTagInfoId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatTagInfoId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionChatTagInfoId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('ModifiedTime') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.ModifiedTime', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('ModifiedTime'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('InstanceId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.InstanceId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('InstanceId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionSessionId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.AnnotationMissionSessionId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionSessionId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionChatId') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.AnnotationMissionChatId', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('AnnotationMissionChatId'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('Create') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.Create', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('Create'))
							if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('Delete') is not None:
								self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.AnnotationMissionChatTagInfoList.'  + str(depth3 + 1) + '.Delete', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('AnnotationMissionChatTagInfoList')[depth3].get('Delete'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('OriginalAsrResult') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.OriginalAsrResult', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('OriginalAsrResult'))
					if AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('TranslationError') is not None:
						self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationMissionChatList.'  + str(depth2 + 1) + '.TranslationError', AnnotationMissionSessionList[depth1].get('AnnotationMissionChatList')[depth2].get('TranslationError'))
			if AnnotationMissionSessionList[depth1].get('AnnotationStatus') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.AnnotationStatus', AnnotationMissionSessionList[depth1].get('AnnotationStatus'))
			if AnnotationMissionSessionList[depth1].get('JobGroupId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.JobGroupId', AnnotationMissionSessionList[depth1].get('JobGroupId'))
			if AnnotationMissionSessionList[depth1].get('SessionId') is not None:
				self.add_query_param('AnnotationMissionSessionList.' + str(depth1 + 1) + '.SessionId', AnnotationMissionSessionList[depth1].get('SessionId'))
	def get_AnnotationMissionSessionListJsonString(self): # String
		return self.get_query_params().get('AnnotationMissionSessionListJsonString')

	def set_AnnotationMissionSessionListJsonString(self, AnnotationMissionSessionListJsonString):  # String
		self.add_query_param('AnnotationMissionSessionListJsonString', AnnotationMissionSessionListJsonString)
