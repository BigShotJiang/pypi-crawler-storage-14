# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkoutboundbot.endpoint import endpoint_data

class ListAnnotationMissionRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'OutboundBot', '2019-12-26', 'ListAnnotationMission','outboundbot')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_CreateTimeStartFilter(self): # Long
		return self.get_query_params().get('CreateTimeStartFilter')

	def set_CreateTimeStartFilter(self, CreateTimeStartFilter):  # Long
		self.add_query_param('CreateTimeStartFilter', CreateTimeStartFilter)
	def get_AnnotationStatusListStringFilter(self): # String
		return self.get_query_params().get('AnnotationStatusListStringFilter')

	def set_AnnotationStatusListStringFilter(self, AnnotationStatusListStringFilter):  # String
		self.add_query_param('AnnotationStatusListStringFilter', AnnotationStatusListStringFilter)
	def get_AnnotationMissionId(self): # String
		return self.get_query_params().get('AnnotationMissionId')

	def set_AnnotationMissionId(self, AnnotationMissionId):  # String
		self.add_query_param('AnnotationMissionId', AnnotationMissionId)
	def get_AnnotationMissionName(self): # String
		return self.get_query_params().get('AnnotationMissionName')

	def set_AnnotationMissionName(self, AnnotationMissionName):  # String
		self.add_query_param('AnnotationMissionName', AnnotationMissionName)
	def get_InstanceId(self): # String
		return self.get_query_params().get('InstanceId')

	def set_InstanceId(self, InstanceId):  # String
		self.add_query_param('InstanceId', InstanceId)
	def get_CreateTimeEndFilter(self): # Long
		return self.get_query_params().get('CreateTimeEndFilter')

	def set_CreateTimeEndFilter(self, CreateTimeEndFilter):  # Long
		self.add_query_param('CreateTimeEndFilter', CreateTimeEndFilter)
	def get_AnnotationStatusListFilters(self): # RepeatList
		return self.get_query_params().get('AnnotationStatusListFilter')

	def set_AnnotationStatusListFilters(self, AnnotationStatusListFilter):  # RepeatList
		for depth1 in range(len(AnnotationStatusListFilter)):
			self.add_query_param('AnnotationStatusListFilter.' + str(depth1 + 1), AnnotationStatusListFilter[depth1])
	def get_PageSize(self): # Integer
		return self.get_query_params().get('PageSize')

	def set_PageSize(self, PageSize):  # Integer
		self.add_query_param('PageSize', PageSize)
	def get_PageIndex(self): # Integer
		return self.get_query_params().get('PageIndex')

	def set_PageIndex(self, PageIndex):  # Integer
		self.add_query_param('PageIndex', PageIndex)
