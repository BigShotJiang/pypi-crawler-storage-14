# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkoutboundbot.endpoint import endpoint_data
import json

class CreateAnnotationMissionRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'OutboundBot', '2019-12-26', 'CreateAnnotationMission','outboundbot')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_SessionEndReasonFilterListJsonString(self): # String
		return self.get_query_params().get('SessionEndReasonFilterListJsonString')

	def set_SessionEndReasonFilterListJsonString(self, SessionEndReasonFilterListJsonString):  # String
		self.add_query_param('SessionEndReasonFilterListJsonString', SessionEndReasonFilterListJsonString)
	def get_SamplingType(self): # Integer
		return self.get_query_params().get('SamplingType')

	def set_SamplingType(self, SamplingType):  # Integer
		self.add_query_param('SamplingType', SamplingType)
	def get_SessionEndReasonFilterLists(self): # RepeatList
		return self.get_query_params().get('SessionEndReasonFilterList')

	def set_SessionEndReasonFilterLists(self, SessionEndReasonFilterList):  # RepeatList
		for depth1 in range(len(SessionEndReasonFilterList)):
			self.add_query_param('SessionEndReasonFilterList.' + str(depth1 + 1), SessionEndReasonFilterList[depth1])
	def get_AnnotationMissionDataSourceType(self): # Integer
		return self.get_query_params().get('AnnotationMissionDataSourceType')

	def set_AnnotationMissionDataSourceType(self, AnnotationMissionDataSourceType):  # Integer
		self.add_query_param('AnnotationMissionDataSourceType', AnnotationMissionDataSourceType)
	def get_ScriptId(self): # String
		return self.get_query_params().get('ScriptId')

	def set_ScriptId(self, ScriptId):  # String
		self.add_query_param('ScriptId', ScriptId)
	def get_AnnotationMissionDebugDataSourceListJsonString(self): # String
		return self.get_query_params().get('AnnotationMissionDebugDataSourceListJsonString')

	def set_AnnotationMissionDebugDataSourceListJsonString(self, AnnotationMissionDebugDataSourceListJsonString):  # String
		self.add_query_param('AnnotationMissionDebugDataSourceListJsonString', AnnotationMissionDebugDataSourceListJsonString)
	def get_ConversationTimeEndFilter(self): # Long
		return self.get_query_params().get('ConversationTimeEndFilter')

	def set_ConversationTimeEndFilter(self, ConversationTimeEndFilter):  # Long
		self.add_query_param('ConversationTimeEndFilter', ConversationTimeEndFilter)
	def get_ConversationTimeStartFilter(self): # Long
		return self.get_query_params().get('ConversationTimeStartFilter')

	def set_ConversationTimeStartFilter(self, ConversationTimeStartFilter):  # Long
		self.add_query_param('ConversationTimeStartFilter', ConversationTimeStartFilter)
	def get_AgentId(self): # String
		return self.get_query_params().get('AgentId')

	def set_AgentId(self, AgentId):  # String
		self.add_query_param('AgentId', AgentId)
	def get_ExcludeOtherSession(self): # Boolean
		return self.get_query_params().get('ExcludeOtherSession')

	def set_ExcludeOtherSession(self, ExcludeOtherSession):  # Boolean
		self.add_query_param('ExcludeOtherSession', ExcludeOtherSession)
	def get_Finished(self): # Boolean
		return self.get_query_params().get('Finished')

	def set_Finished(self, Finished):  # Boolean
		self.add_query_param('Finished', Finished)
	def get_SamplingRate(self): # Integer
		return self.get_query_params().get('SamplingRate')

	def set_SamplingRate(self, SamplingRate):  # Integer
		self.add_query_param('SamplingRate', SamplingRate)
	def get_AgentKey(self): # String
		return self.get_query_params().get('AgentKey')

	def set_AgentKey(self, AgentKey):  # String
		self.add_query_param('AgentKey', AgentKey)
	def get_AnnotationMissionName(self): # String
		return self.get_query_params().get('AnnotationMissionName')

	def set_AnnotationMissionName(self, AnnotationMissionName):  # String
		self.add_query_param('AnnotationMissionName', AnnotationMissionName)
	def get_ChatbotId(self): # String
		return self.get_query_params().get('ChatbotId')

	def set_ChatbotId(self, ChatbotId):  # String
		self.add_query_param('ChatbotId', ChatbotId)
	def get_AnnotationMissionDebugDataSourceList(self): # Array
		return self.get_query_params().get('AnnotationMissionDebugDataSourceList')

	def set_AnnotationMissionDebugDataSourceList(self, AnnotationMissionDebugDataSourceList):  # Array
		self.add_query_param("AnnotationMissionDebugDataSourceList", json.dumps(AnnotationMissionDebugDataSourceList))
	def get_InstanceId(self): # String
		return self.get_query_params().get('InstanceId')

	def set_InstanceId(self, InstanceId):  # String
		self.add_query_param('InstanceId', InstanceId)
	def get_SamplingCount(self): # Integer
		return self.get_query_params().get('SamplingCount')

	def set_SamplingCount(self, SamplingCount):  # Integer
		self.add_query_param('SamplingCount', SamplingCount)
