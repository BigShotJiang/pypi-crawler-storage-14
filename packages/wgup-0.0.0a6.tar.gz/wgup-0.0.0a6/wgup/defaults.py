import os

PROG = "wgup"
VERSION = "0.0.0-alpha.6"

CONFIG_VERSION = 1
CONFIG_DIR = f"{os.path.expanduser("~")}/.wgup"
