# IconPurpose

A reason to use this icon. For example, may just be the name of the client which uses it. Some well-known agilicus ones are:  - agilicus-profile: Used by the profile web application. - agilicus-launcher: Used by the launcher. - default: Used by default if no other option is available. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | A reason to use this icon. For example, may just be the name of the client which uses it. Some well-known agilicus ones are:  - agilicus-profile: Used by the profile web application. - agilicus-launcher: Used by the launcher. - default: Used by default if no other option is available.  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


