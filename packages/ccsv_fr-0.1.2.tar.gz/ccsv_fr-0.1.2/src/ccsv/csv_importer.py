import csv
import os

class CSVImporter():

    def load_full_csv(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Le fichier '{file_path}' n'existe pas.")

        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            data = [row for row in reader]
        return data

    def load_range(self, file_path, start_row, end_row, start_col=None, end_col=None):
        full_data = self.load_full_csv(file_path)
        selected_rows = full_data[start_row-1:end_row]
        if start_col is not None and end_col is not None:
            selected_rows = [row[start_col-1:end_col] for row in selected_rows]
        return selected_rows
