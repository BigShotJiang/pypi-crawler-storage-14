"""
cf_basic_signal/steps.py

ProcessingStep implementations for the `cf.basic.signal` StepPackage.
Provides:
  - InlineSource
  - HandleSinkStep
  - FifoWindowBufferStep
  - AverageStep
  - OpcuaPhSource

These functions can call into an optional C++ backend via pybind11.
If the extension is not available, Python fallbacks are used.

Public entry point:
    register_steps(registry)

AlgorithmServer will import this module and call register_steps(registry)
after loading the package manifest and ontology fragment. The IRIs used
here must match exactly the ones in steps.ttl.
"""

from __future__ import annotations

import asyncio
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

# Optional C++ backend (pybind11). If it fails to import, fall back to Python.
try:
    from . import _dataproc_core  # type: ignore
    HAS_CPP = True
except Exception:
    _dataproc_core = None  # type: ignore
    HAS_CPP = False

# Cache for persistent OPC UA clients
_OPCUA_CLIENTS: Dict[str, Any] = {}
_OPCUA_CLIENT_LOOP: Optional[asyncio.AbstractEventLoop] = None


# ---------------------------------------------------------------------------
# INLINE SOURCE
# ---------------------------------------------------------------------------

def inline_source(payload: str) -> Dict[str, Any]:
    """
    Emit inline data. If the payload starts with 'inline://', parse the remaining
    content as JSON; otherwise return the raw string.
    Returns a dict with a single output: {"data": <object>}.
    """
    data_str = payload
    prefix = "inline://"
    if payload.startswith(prefix):
        data_str = payload[len(prefix) :]
        try:
            return {"data": json.loads(data_str)}
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid inline JSON payload: {exc}") from exc
    return {"data": data_str}


# ---------------------------------------------------------------------------
# HANDLE SINK
# ---------------------------------------------------------------------------

def _quote_identifier(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _prepare_row(data: Any, parameters: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    value_key = None
    if parameters:
        value_key = parameters.get("valueKey") or parameters.get("valueName")

    row: Dict[str, Any] = {}
    if isinstance(data, dict):
        row.update(data)
    else:
        row[value_key or "value"] = data

    if parameters:
        for key, value in parameters.items():
            if key == "handleUri":
                continue
            row.setdefault(key, value)
    return row


def _duckdb_status(handle_uri: str, table: str, path_obj: Path) -> str:
    table_part = table
    if not table_part:
        table_part = "sink_data"
    return f"handled via duckdb://{path_obj.as_posix()}?table={table_part}"


def _store_duckdb(handle_uri: str, data: Any, parameters: Optional[Dict[str, Any]]) -> str:
    parsed = urlparse(handle_uri)
    if parsed.scheme != "duckdb":
        return f"handled via {handle_uri}"

    db_path = (parsed.netloc + parsed.path) or ":memory:"
    query = parse_qs(parsed.query)
    table = (query.get("table") or ["sink_data"])[0] or "sink_data"
    mode = (query.get("mode") or ["append"])[0].lower()

    row = _prepare_row(data, parameters)
    target = Path(db_path)
    if target.is_dir():
        target = target / "sink.duckdb"
    target.parent.mkdir(parents=True, exist_ok=True)

    try:
        import duckdb  # type: ignore
    except Exception as exc:  # pragma: no cover - optional dependency guard
        raise RuntimeError("DuckDB sink requires duckdb") from exc

    def _infer_type(value: Any) -> str:
        if isinstance(value, bool):
            return "BOOLEAN"
        if isinstance(value, int):
            return "BIGINT"
        if isinstance(value, float):
            return "DOUBLE"
        return "VARCHAR"

    cols = list(row.keys())
    col_defs = ", ".join(f"{_quote_identifier(c)} {_infer_type(row[c])}" for c in cols)
    placeholders = ", ".join(["?"] * len(cols))
    table_sql = _quote_identifier(table)
    with duckdb.connect(target.as_posix()) as con:
        if mode == "replace":
            con.execute(f"DROP TABLE IF EXISTS {table_sql}")
        con.execute(f"CREATE TABLE IF NOT EXISTS {table_sql} ({col_defs})")
        con.execute(
            f"INSERT INTO {table_sql} ({', '.join(_quote_identifier(c) for c in cols)}) VALUES ({placeholders})",
            [row[c] for c in cols],
        )

    return _duckdb_status(handle_uri, table, target)


def _store_csv(handle_uri: str, data: Any, parameters: Optional[Dict[str, Any]]) -> str:
    path_str = handle_uri[len("csv://") :]
    target = Path(path_str)
    target.parent.mkdir(parents=True, exist_ok=True)
    row = _prepare_row(data, parameters)
    # Write header only if file is empty
    write_header = not target.exists() or target.stat().st_size == 0
    with target.open("a", encoding="utf-8", newline="") as f:
        if write_header:
            f.write(",".join(row.keys()) + "\n")
        f.write(",".join(str(row[k]) for k in row.keys()) + "\n")
    return f"handled via {handle_uri}"


def handle_sink(data: Any, handleUri: str, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Persist or forward data to a handle.

    Supported targets:
      - duckdb:///<path>?table=<name>&mode=append|replace (writes a single-row table insert)
      - inline://..., parquet://..., opcua://... (stubbed passthrough)
    """
    if handleUri.startswith("duckdb://"):
        status = _store_duckdb(handleUri, data, parameters)
    elif handleUri.startswith("csv://"):
        status = _store_csv(handleUri, data, parameters)
    else:
        status = f"handled via {handleUri}"
    return {"status": status}


# ---------------------------------------------------------------------------
# FIFO WINDOW BUFFER STEP
# ---------------------------------------------------------------------------

def _compute_fifo_window(values: List[float], window_size: int) -> List[float]:
    if window_size <= 0:
        return []
    if len(values) <= window_size:
        return list(values)
    return list(values[-window_size:])


def fifo_window_buffer(values: List[float], windowSize: int) -> Dict[str, Any]:
    """
    Sliding FIFO window buffer.

    Parameters
    ----------
    values : list[float]
        Input vector (DataCube).
    windowSize : int
        Number of elements to keep.

    Returns
    -------
    dict
        {"window": list[float]}
    """
    if HAS_CPP and _dataproc_core:
        window = _dataproc_core.fifo_window_buffer(values, int(windowSize))  # type: ignore[attr-defined]
        return {"window": window}

    # Python fallback (simple and not optimized)
    return {"window": _compute_fifo_window(values, windowSize)}


def fifo_window_buffer_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    values = kwargs.get("sampleChunk") or kwargs.get("values")
    if values is None and inputs:
        values = inputs.get("sampleChunk") or inputs.get("values")
    if values is None:
        values = []
    elif not isinstance(values, list):
        values = [values]
    window_size = kwargs.get("windowSize")
    if window_size is None:
        window_size = (parameters or {}).get("windowSize", 0)
    return fifo_window_buffer(list(values or []), int(window_size))


# ---------------------------------------------------------------------------
# AVERAGE STEP (arithmetic / geometric / harmonic)
# ---------------------------------------------------------------------------

def average(values: List[float], averageMethod: str = "arithmetic") -> Dict[str, Any]:
    """
    Compute mean and standard error for a vector of values.

    mode can be:
      - "arithmetic"
      - "geometric"
      - "harmonic"
    """
    mode = averageMethod
    if HAS_CPP and _dataproc_core:
        res = _dataproc_core.average(values, mode)  # type: ignore[attr-defined]
        # pybind returns AverageResult or tuple-like; normalize to dict
        mean = getattr(res, "mean", None)
        se = getattr(res, "standard_error", None) or getattr(res, "se", None)
        if isinstance(res, (tuple, list)) and len(res) >= 2:
            mean, se = res[0], res[1]
        return {"mean": mean, "se": se}

    n = len(values)
    if n == 0:
        return {"mean": float("nan"), "se": float("nan")}

    if mode == "arithmetic":
        mean = sum(values) / n
    elif mode == "geometric":
        # Guard non-positive values; geometric mean only defined for v > 0
        positives = [v for v in values if v > 0]
        if len(positives) != n:
            raise ValueError("Geometric mean requires all values > 0")
        mean = math.exp(sum(math.log(v) for v in positives) / n)
    elif mode == "harmonic":
        # Guard zeros to avoid division by zero
        if any(v == 0 for v in values):
            raise ValueError("Harmonic mean requires all values != 0")
        mean = n / sum((1.0 / v) for v in values)
    else:
        raise ValueError(f"Unknown average mode '{mode}'")

    # Standard error (unbiased variance estimate, then divide by sqrt(n))
    var = sum((v - mean) ** 2 for v in values) / max(n - 1, 1)
    se = math.sqrt(var / n)
    return {"mean": mean, "standardError": se, "se": se}


def average_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    values = kwargs.get("values")
    if values is None and inputs:
        values = inputs.get("values")
    mode = kwargs.get("averageMethod") or kwargs.get("mode")
    if mode is None and parameters:
        mode = parameters.get("averageMethod", "arithmetic")
    return average(list(values or []), averageMethod=str(mode or "arithmetic"))


# ---------------------------------------------------------------------------
# INLINE SOURCE + HANDLE SINK ADAPTERS
# ---------------------------------------------------------------------------

def inline_source_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    payload = kwargs.get("payload")
    if payload is None and parameters:
        payload = parameters.get("payload", "")
    return inline_source(str(payload or ""))


def handle_sink_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    data = kwargs.get("data")
    if data is None and inputs:
        data = inputs.get("data")
    handle_uri = kwargs.get("handleUri")
    if handle_uri is None and parameters:
        handle_uri = parameters.get("handleUri", "")
    params = parameters or kwargs
    return handle_sink(data, str(handle_uri or ""), parameters=params)


# ---------------------------------------------------------------------------
# OPC UA VIRTUAL pH SOURCE
# ---------------------------------------------------------------------------

DEFAULT_ENDPOINT = "opc.tcp://127.0.0.1:4840/VirtualPhServer"
DEFAULT_PH_NODE = "ns=2;s=VirtualPhMeter01.pH"
DEFAULT_TEMP_NODE = "ns=2;s=VirtualPhMeter01.Temperature"
_OPCUA_CLIENTS: Dict[str, Any] = {}


async def _read_opcua_once(endpoint: str, ph_node: str, temp_node: str) -> Tuple[float, float]:
    from asyncua import Client  # imported lazily to avoid hard dependency during packaging

    client = _OPCUA_CLIENTS.get(endpoint)
    if client is None:
        client = Client(url=endpoint)
        global _OPCUA_CLIENT_LOOP
        _OPCUA_CLIENT_LOOP = asyncio.get_running_loop()
        await client.connect()
        _OPCUA_CLIENTS[endpoint] = client
    ph_value = await client.get_node(ph_node).read_value()
    temp_value = await client.get_node(temp_node).read_value()
    return float(ph_value), float(temp_value)


async def opcua_ph_source_async(
    endpoint: str = DEFAULT_ENDPOINT,
    phNode: str = DEFAULT_PH_NODE,
    temperatureNode: str = DEFAULT_TEMP_NODE,
) -> Dict[str, float]:
    """
    Read the latest pH and temperature sample from an OPC UA server (async).

    Defaults target the bundled virtual server (virtual_ph_server.py).
    """
    ph_val, temp_val = await _read_opcua_once(endpoint, phNode, temperatureNode)
    ts = datetime.now(timezone.utc).isoformat()
    return {"pH": ph_val, "temperature": temp_val, "timestamp": ts}


def opcua_ph_source(
    endpoint: str = DEFAULT_ENDPOINT,
    phNode: str = DEFAULT_PH_NODE,
    temperatureNode: str = DEFAULT_TEMP_NODE,
) -> Dict[str, float]:
    """
    Synchronous wrapper around opcua_ph_source_async for compatibility.
    """
    try:
        ph_val, temp_val = _run_coroutine_sync(_read_opcua_once(endpoint, phNode, temperatureNode))
        ts = datetime.now(timezone.utc).isoformat()
        return {"pH": ph_val, "temperature": temp_val, "timestamp": ts}
    except RuntimeError as exc:  # pragma: no cover - defensive path
        raise RuntimeError(f"Failed to read OPC UA values: {exc}") from exc


def close_opcua_clients() -> None:
    """
    Disconnect and clear cached asyncua clients (best-effort).
    """
    if not _OPCUA_CLIENTS:
        return
    try:
        loop = _OPCUA_CLIENT_LOOP or asyncio.get_event_loop()
    except RuntimeError:
        loop = None
    if loop:
        coro = close_opcua_clients_async()
        if loop.is_running():
            fut = asyncio.run_coroutine_threadsafe(coro, loop)
            try:
                fut.result(timeout=2.0)
            except Exception:
                pass
        else:
            try:
                loop.run_until_complete(coro)
            except Exception:
                pass
    else:
        # Fallback: temp loop
        tmp_loop = asyncio.new_event_loop()
        try:
            tmp_loop.run_until_complete(close_opcua_clients_async())
        finally:
            tmp_loop.close()


async def close_opcua_clients_async() -> None:
    if not _OPCUA_CLIENTS:
        return
    tasks = []
    for _, client in list(_OPCUA_CLIENTS.items()):
        try:
            tasks.append(client.disconnect())
        except Exception:
            continue
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _OPCUA_CLIENTS.clear()


def _run_coroutine_sync(coro):
    """
    Run an async coroutine from synchronous context, even if an event loop is already running.
    """
    try:
        loop = asyncio.get_running_loop()
        tmp = asyncio.new_event_loop()
        try:
            if sys.platform.startswith(("win32", "cygwin")):
                asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]
            asyncio.set_event_loop(tmp)
            return tmp.run_until_complete(coro)
        finally:
            asyncio.set_event_loop(None)
            tmp.close()
    except RuntimeError:
        return asyncio.run(coro)


async def opcua_ph_source_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, float]:
    params = parameters or {}
    endpoint = kwargs.get("endpoint", params.get("endpoint", DEFAULT_ENDPOINT))
    ph_node = kwargs.get("phNode", params.get("phNode", DEFAULT_PH_NODE))
    temp_node = kwargs.get("temperatureNode", params.get("temperatureNode", DEFAULT_TEMP_NODE))
    return await opcua_ph_source_async(endpoint=str(endpoint), phNode=str(ph_node), temperatureNode=str(temp_node))


# ---------------------------------------------------------------------------
# STEP REGISTRATION
# ---------------------------------------------------------------------------

def register_steps(registry) -> None:
    """
    Called by AlgorithmServer when the StepPackage is loaded.

    All IRIs must match the ones declared in steps.ttl for this package:
      - cf:InlineSource
      - cf:HandleSinkStep
      - cf:FifoWindowBufferStep
      - cf:AverageStep
      - cf:OpcuaPhSource
    """
    def _register(iri: str, func) -> None:
        registry.register(iri, func)
        if ":" in iri:
            local = iri.split(":", 1)[1]
            if local:
                registry.register(local, func)

    _register("cf:InlineSource", inline_source_step)
    _register("cf:HandleSinkStep", handle_sink_step)
    _register("cf:FifoWindowBufferStep", fifo_window_buffer_step)
    _register("cf:AverageStep", average_step)
    _register("cf:OpcuaPhSource", opcua_ph_source_step)
