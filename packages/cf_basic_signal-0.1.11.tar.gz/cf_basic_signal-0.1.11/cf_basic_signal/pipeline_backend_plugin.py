from __future__ import annotations

from typing import Any, Dict, Iterable, Tuple

from . import steps


def _payload_dict(data: Any) -> Dict[str, Any]:
    """
    Extract the shared payload dict from pipeline_backend.Data.
    Raises a helpful error if the object is not compatible.
    """
    try:
        payload = data.payload  # type: ignore[attr-defined]
    except Exception as exc:
        raise TypeError("pipeline backend ops expect an object with a 'payload' mapping") from exc

    if not isinstance(payload, dict):
        raise TypeError("pipeline backend payload must be a dict-like object")
    return payload


def _list_from_payload(payload: Dict[str, Any], keys: Iterable[str]) -> Tuple[list[Any], Any]:
    """
    Pull the first non-None value for any of the given keys, normalize to list if possible,
    and return both the list and the raw value (for callers that need unwrapped values).
    """
    raw = None
    for key in keys:
        if key in payload:
            raw = payload.get(key)
            break

    if raw is None:
        return [], raw
    if isinstance(raw, list):
        return list(raw), raw
    return [raw], raw


def inline_source_op(data: Any) -> None:
    """
    Inline source: uses payload['inline_payload'] or payload['payload'] and writes to payload['data'].
    If the payload string starts with inline:// it is parsed as JSON, mirroring steps.inline_source().
    """
    payload = _payload_dict(data)
    source_value = payload.get("inline_payload")
    if source_value is None:
        source_value = payload.get("payload", "")

    if isinstance(source_value, str):
        result = steps.inline_source(source_value)
    else:
        # Allow callers to inject a pre-parsed object directly.
        result = {"data": source_value}

    payload.update(result)


def handle_sink_op(data: Any) -> None:
    """
    Handle sink: writes payload['data'] to a duckdb:// or csv:// target.
    Handle URI is read from payload['handleUri'] | payload['handle_uri'].
    """
    payload = _payload_dict(data)
    handle_uri = payload.get("handleUri") or payload.get("handle_uri") or payload.get("handle")
    parameters = payload.get("parameters")
    result = steps.handle_sink(payload.get("data"), str(handle_uri or "inline://dev-null"), parameters=parameters)
    payload.update(result)


def fifo_window_buffer_op(data: Any) -> None:
    """
    FIFO window buffer: consumes payload['values'] | payload['sampleChunk'] and writes payload['window'].
    Window size is read from payload['windowSize'] | payload['window_size'].
    """
    payload = _payload_dict(data)
    values, _ = _list_from_payload(payload, ("values", "sampleChunk", "data"))
    window_size = payload.get("windowSize", payload.get("window_size", 0))
    result = steps.fifo_window_buffer(values, windowSize=int(window_size or 0))
    payload.update(result)


def average_op(data: Any) -> None:
    """
    Average: consumes payload['window'] (fallback: payload['values']) and writes stats into payload.
    Mode is read from payload['averageMethod'] | payload['mode'].
    """
    payload = _payload_dict(data)
    values, raw = _list_from_payload(payload, ("window", "values"))
    mode = payload.get("averageMethod", payload.get("mode", "arithmetic"))
    result = steps.average(values if values else list(raw or []), averageMethod=str(mode))
    payload["stats"] = result
    payload.update(result)


def opcua_ph_source_op(data: Any) -> None:
    """
    OPC UA source: fetches a single pH/temperature sample and appends the pH to payload['values'].
    Endpoint and node IDs can be overridden in payload.
    """
    payload = _payload_dict(data)
    endpoint = payload.get("endpoint", steps.DEFAULT_ENDPOINT)  # type: ignore[attr-defined]
    ph_node = payload.get("phNode", steps.DEFAULT_PH_NODE)  # type: ignore[attr-defined]
    temp_node = payload.get("temperatureNode", steps.DEFAULT_TEMP_NODE)  # type: ignore[attr-defined]
    sample = steps.opcua_ph_source(endpoint=str(endpoint), phNode=str(ph_node), temperatureNode=str(temp_node))

    payload["opcua_sample"] = sample
    values, _ = _list_from_payload(payload, ("values", "sampleChunk"))
    values.append(float(sample.get("pH", 0.0)))
    payload["values"] = values
    payload.update(sample)


def register_pipeline_backend_ops() -> bool:
    """
    Register Python operations into pipeline_backend if it is available.
    Returns True when registration was attempted successfully.
    """
    try:
        import pipeline_backend as pb
    except ImportError:
        return False

    existing = {entry.get("name") for entry in pb.describe_ops()} if hasattr(pb, "describe_ops") else set()
    ops = {
        "inline_source": inline_source_op,
        "handle_sink": handle_sink_op,
        "fifo_window_buffer": fifo_window_buffer_op,
        "average": average_op,
        "opcua_ph_source": opcua_ph_source_op,
    }

    for name, fn in ops.items():
        if name in existing:
            continue
        pb.register_py_op(name, fn)

    return True


__all__ = [
    "register_pipeline_backend_ops",
    "inline_source_op",
    "handle_sink_op",
    "fifo_window_buffer_op",
    "average_op",
    "opcua_ph_source_op",
]
