#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "libdataproc_core.hpp"

namespace py = pybind11;

PYBIND11_MODULE(_dataproc_core, m) {
    m.doc() = "CF basic signal algorithms (FIFO, average, vector sum)";

    m.def("vector_sum", &cf_basic_signal::vector_sum, "Sum of a vector of doubles");

    m.def("fifo_window_buffer", &cf_basic_signal::fifo_window_buffer, py::arg("new_samples"),
          py::arg("window_size"), py::arg("fifo_id") = "default",
          "Update FIFO window and return current buffer");

    py::class_<cf_basic_signal::AverageResult>(m, "AverageResult")
        .def_readonly("mean", &cf_basic_signal::AverageResult::mean)
        .def_readonly("standard_error", &cf_basic_signal::AverageResult::standard_error);

    m.def(
        "average",
        [](const std::vector<double>& values, const std::string& method,
           const std::optional<std::vector<double>>& weights) {
            if (weights.has_value()) {
                return cf_basic_signal::average(values, method, &weights.value());
            }
            return cf_basic_signal::average(values, method, nullptr);
        },
        py::arg("values"), py::arg("method") = "arithmetic", py::arg("weights") = std::nullopt,
        "Compute mean and standard error for a vector of values");

    m.def("reset_fifo", &cf_basic_signal::reset_fifo, py::arg("fifo_id"), "Reset a single FIFO buffer");
    m.def("reset_all_fifos", &cf_basic_signal::reset_all_fifos, "Reset all FIFO buffers");
}
