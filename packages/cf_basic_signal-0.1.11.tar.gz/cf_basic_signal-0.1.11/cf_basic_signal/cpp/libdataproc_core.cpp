// Basic signal algorithms for cf_basic_signal package.

#include "libdataproc_core.hpp"

#include <cmath>
#include <mutex>
#include <numeric>
#include <stdexcept>
#include <unordered_map>

namespace {
std::unordered_map<std::string, std::vector<double>> g_fifo_store;
std::mutex g_mutex;
}  // namespace

namespace cf_basic_signal {

double vector_sum(const std::vector<double>& values) {
    return std::accumulate(values.begin(), values.end(), 0.0);
}

std::vector<double> fifo_window_buffer(const std::vector<double>& new_samples, std::size_t window_size,
                                       const std::string& fifo_id) {
    std::lock_guard<std::mutex> lock(g_mutex);
    auto& buf = g_fifo_store[fifo_id];
    buf.insert(buf.end(), new_samples.begin(), new_samples.end());
    if (window_size > 0 && buf.size() > window_size) {
        buf.erase(buf.begin(), buf.end() - static_cast<long long>(window_size));
    }
    return buf;
}

AverageResult average(const std::vector<double>& values, const std::string& method,
                      const std::vector<double>* weights) {
    AverageResult res{0.0, 0.0};
    if (values.empty()) {
        return res;
    }

    const auto n = values.size();
    std::string m = method;
    for (auto& c : m) c = static_cast<char>(std::tolower(c));

    if (m == "weighted" && weights && weights->size() == n) {
        double w_sum = std::accumulate(weights->begin(), weights->end(), 0.0);
        if (w_sum != 0.0) {
            for (std::size_t i = 0; i < n; ++i) {
                res.mean += values[i] * (*weights)[i];
            }
            res.mean /= w_sum;
        }
    } else if (m == "harmonic") {
        double denom = 0.0;
        for (auto v : values) {
            if (v != 0.0) {
                denom += 1.0 / v;
            }
        }
        res.mean = denom != 0.0 ? n / denom : 0.0;
    } else if (m == "geometric") {
        double log_sum = 0.0;
        for (auto v : values) {
            if (v <= 0.0) {
                throw std::invalid_argument("geometric mean is only defined for positive values");
            }
            log_sum += std::log(v);
        }
        res.mean = std::exp(log_sum / static_cast<double>(n));
    } else {
        res.mean = vector_sum(values) / static_cast<double>(n);
    }

    double variance = 0.0;
    for (auto v : values) {
        variance += (v - res.mean) * (v - res.mean);
    }
    variance /= static_cast<double>(n);
    res.standard_error = std::sqrt(variance / static_cast<double>(n));
    return res;
}

void reset_fifo(const std::string& fifo_id) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_fifo_store.erase(fifo_id);
}

void reset_all_fifos() {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_fifo_store.clear();
}

}  // namespace cf_basic_signal
