// Minimal SDK shim mirroring pipeline_backend's Data and OpFn definitions.
// This keeps the ABI aligned between the backend extension and this plugin.
#pragma once

#include <pybind11/pybind11.h>

namespace pipeline {

struct Data {
    // Matches pipeline_backend::Data (payload is a Python dict shared across ops).
    pybind11::dict payload;
};

using OpFn = void (*)(Data &);

}  // namespace pipeline
