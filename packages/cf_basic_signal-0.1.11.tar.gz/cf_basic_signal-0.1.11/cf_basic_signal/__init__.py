"""
cf_basic_signal package

Besides the Cogniflow StepPackage entrypoint, this package can act as a
pipeline_backend plugin by registering its Python ops on import when the
backend is available.
"""

from .pipeline_backend_plugin import register_pipeline_backend_ops

# Try to register C++ pipeline ops first (if backend + extension are available).
try:  # pragma: no cover - optional import side-effect
    from . import _pipeline_backend_ops  # type: ignore  # noqa: F401
except Exception:
    pass

# Optional OPC UA backend ops (requires open62541 + CF_BASIC_SIGNAL_ENABLE_OPCUA_CPP=1 at build time).
try:  # pragma: no cover - optional import side-effect
    from . import _opcua_backend_ops  # type: ignore  # noqa: F401
except Exception:
    pass

# Best-effort auto-registration for pipeline_backend users (Python fallback).
# This is a no-op when the compiled backend is not installed.
register_pipeline_backend_ops()

__all__ = ["register_pipeline_backend_ops"]
