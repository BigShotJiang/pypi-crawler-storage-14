"""
Activities for job execution tracking.

These activities handle creating execution records for scheduled jobs.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from temporalio import activity
import structlog
import uuid

logger = structlog.get_logger()


@dataclass
class ActivityCreateJobExecutionInput:
    """Input for creating job execution records"""
    execution_id: str
    job_id: Optional[str]
    organization_id: str
    entity_type: str  # "agent" or "team"
    entity_id: Optional[str]
    prompt: str
    trigger_type: str  # "cron", "webhook", "manual"
    trigger_metadata: Dict[str, Any]


@activity.defn
async def create_job_execution_record(input: ActivityCreateJobExecutionInput) -> dict:
    """
    Create execution and job_executions records for a scheduled job.

    This activity uses HTTP to communicate with the control plane API
    instead of directly accessing Supabase.

    Args:
        input: Execution creation input

    Returns:
        Dict with execution_id and status
    """
    from control_plane_api.worker.control_plane_client import get_control_plane_client

    client = get_control_plane_client()

    logger.info(
        "creating_job_execution_records_via_http",
        execution_id=input.execution_id,
        job_id=input.job_id,
        trigger_type=input.trigger_type,
    )

    try:
        result = await client.create_job_execution_record(
            execution_id=input.execution_id,
            job_id=input.job_id,
            organization_id=input.organization_id,
            entity_type=input.entity_type,
            entity_id=input.entity_id,
            prompt=input.prompt,
            trigger_type=input.trigger_type,
            trigger_metadata=input.trigger_metadata,
        )

        logger.info(
            "created_job_execution_records_via_http",
            execution_id=input.execution_id,
            job_id=input.job_id,
        )

        return result

    except Exception as e:
        logger.error(
            "failed_to_create_job_execution_records_via_http",
            execution_id=input.execution_id,
            job_id=input.job_id,
            error=str(e),
            exc_info=True,
        )
        raise


@activity.defn
async def update_job_execution_status(
    job_id: str,
    execution_id: str,
    status: str,
    duration_ms: Optional[int] = None,
    error_message: Optional[str] = None,
) -> dict:
    """
    Update job_executions record with execution results.

    This activity uses HTTP to communicate with the control plane API
    instead of directly accessing Supabase.

    Args:
        job_id: Job ID
        execution_id: Execution ID
        status: Final status (completed/failed)
        duration_ms: Execution duration in milliseconds
        error_message: Error message if failed

    Returns:
        Dict with update status
    """
    from control_plane_api.worker.control_plane_client import get_control_plane_client

    client = get_control_plane_client()

    logger.info(
        "updating_job_execution_status_via_http",
        job_id=job_id,
        execution_id=execution_id,
        status=status,
    )

    try:
        result = await client.update_job_execution_status(
            execution_id=execution_id,
            job_id=job_id,
            status=status,
            duration_ms=duration_ms,
            error_message=error_message,
        )

        logger.info(
            "updated_job_execution_status_via_http",
            job_id=job_id,
            execution_id=execution_id,
            status=status,
        )

        return result

    except Exception as e:
        logger.error(
            "failed_to_update_job_execution_status_via_http",
            job_id=job_id,
            execution_id=execution_id,
            error=str(e),
            exc_info=True,
        )
        raise
