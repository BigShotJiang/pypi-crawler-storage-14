"""
Shared utilities and constants accessible to both API and worker packages.
"""

from control_plane_api.shared.version import __version__, get_sdk_version

__all__ = ["__version__", "get_sdk_version"]
