CUTOUT_ADAPTER = 'daiquiri.cutout.adapter.SimpleCutOutAdapter'
CUTOUT_ANONYMOUS = False
