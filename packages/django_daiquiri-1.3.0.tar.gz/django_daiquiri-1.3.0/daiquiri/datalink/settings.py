DATALINK_ADAPTER = 'daiquiri.datalink.adapter.DefaultDatalinkAdapter'
DATALINK_TABLES = []
DATALINK_CUSTOM_SEMANTICS = {
    "#doi": "The access_url points to the Digital Object Identifier (DOI) of the object.",
}
