import daiquiri.core.env as env

AUTH_SIGNUP = env.get_bool('AUTH_SIGNUP')

AUTH_WORKFLOW = None
AUTH_DETAIL_KEYS = []
AUTH_TERMS_OF_USE = False
