from django.apps import AppConfig


class ConeSearchConfig(AppConfig):
    name = 'daiquiri.conesearch'
    label = 'daiquiri_conesearch'
    verbose_name = 'Cone search'
