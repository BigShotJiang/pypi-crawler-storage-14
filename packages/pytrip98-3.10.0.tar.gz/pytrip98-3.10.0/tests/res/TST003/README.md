Test CT cube TST003000

512x512x300 voxels

0.5 x 0.5 x 3 mm voxels

center 128,128,128 mm 

PTV is box on center with radius 50x50x50 side length
