
# Constants used in automatic layout

LEFT_MARGIN: int = 10    # Left margin
UP_MARGIN:   int = 10    # Up margin
H_SPACE:     int = 20     # Horizontal space (minimum value between nodes)
V_SPACE:     int = 50     # Vertical space (minimum value between nodes)
