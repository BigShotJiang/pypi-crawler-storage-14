
class InvalidPluginExtensionException(Exception):
    pass
