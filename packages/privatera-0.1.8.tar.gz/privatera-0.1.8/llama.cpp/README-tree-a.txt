.
├── build -> ../../llama.cpp/build
├── .gitignore
├── README-tree-a.txt
└── README-tree.txt

2 directories, 3 files
