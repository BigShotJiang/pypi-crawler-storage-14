.
├── README-tree-a.txt
├── README-tree.txt
└── target -> ../../meilisearch/target

2 directories, 2 files
