.
├── README-tree.txt
└── target -> ../../meilisearch/target

2 directories, 1 file
