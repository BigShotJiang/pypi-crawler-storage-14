from rdrag.util import ask
from rdrag import constants, corpora, util

__all__ = ['constants', 'corpora', 'util', ]


def main() -> None:
    print('Hello, from PrivateRA!')
    # util.main()
