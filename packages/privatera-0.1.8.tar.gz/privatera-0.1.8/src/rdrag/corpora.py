import logging
from pathlib import Path
from rdrag.constants import PKG_DIR

log = logging.getLogger(__name__)

WIKITITLES_DIR = PKG_DIR / 'data' / 'wikititles'

title_links = {}
for path in WIKITITLES_DIR.glob('*.txt'):
    print(path)
    # biochem = ['Virus', ...]
    title_links[path.name.split('.')[0]] = [t.strip() for t in open(path)]


def find_related_wikititles(titles: list[str] = 'Africa,Etheopia,Orinoko,Somalia,Nairobi,Kenya,South Africa,East Africa'.split(',')):
    for t in titles:
        path = (WIKITITLES_DIR / make_wiki_title(t).replace(' ', '_')).with_suffix('.txt')
        log.info(t, '>>', filename)
        try:
            p = wiki.get_page(t)
        except Exception as exc:
            log.error(str(exc))
        print(p)
        with open(path, 'w') as fout:
            fout.writelines([link + '\n' for link in p.links])
        log.info(f'{len(p.links)}')
