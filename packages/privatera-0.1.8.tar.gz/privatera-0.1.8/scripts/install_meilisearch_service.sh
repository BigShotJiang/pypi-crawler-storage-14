#!/bin/bash
TANGIBLE_DIR="/home/$USER/code/tangibleai/rdrag"
source "${TANGIBLE_DIR}/.env"

sudo cat >/etc/systemd/system/meilisearch.service <<EOF
[Unit]
Description=Meilisearch search engine (Rust)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${TANGIBLE_DIR}/meilisearch/target/release
ExecStart=${TANGIBLE_DIR}/scripts/meilisearch.sh
Restart=on-success
RestartSec=7s
StandardOutput=file:${TANGIBLE_DIR}/meilisearch-server.stdout.log
StandardError=file:${TANGIBLE_DIR}/meilisearch-server.stderr.log

[Install]
WantedBy=multi-user.target
EOF
