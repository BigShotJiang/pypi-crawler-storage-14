#!/usr/bin/env bash
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source $SCRIPT_DIR/../.env
echo LLM_URL=$LLM_URL
if [[ -z $LLM_TEMP ]] ; then
	export LLM_TEMP=0.2
	echo "WARNING: LLM_TEMP not set in $SCRIPT_DIR/../.env Default LLM_TEMP=$LLM_TEMP"
fi
if [[ -z $LLM_TOPK ]] ; then
	export LLM_TOPK=20
	echo "WARNING: LLM_TOPK not set in $SCRIPT_DIR/../.env Default LLM_TOPK=$LLM_TOPK"
fi
if [[ -z $LLM_TOPP ]] ; then
	export LLM_TOPP=0.8
	echo "WARNING: LLM_TOPP not set in $SCRIPT_DIR/../.env Default LLM_TOPP=$LLM_TOPP"
fi
if [[ -z $LLM_MINP ]] ; then
	export LLM_MINP=0.2
	echo "WARNING: LLM_MINP not set in $SCRIPT_DIR/../.env Default LLM_MINP=$LLM_MINP"
fi

# See llama-server --help
# --temp N                                temperature (default: 0.8)
# --top-k N                               top-k sampling (default: 40, 0 = disabled)
# --top-p N                               top-p sampling (default: 0.9, 1.0 = disabled)
# --min-p N                               min-p sampling (default: 0.1, 0.0 = disabled)
# --top-nsigma N                          top-n-sigma sampling (default: -1.0, -1.0 = disabled)
# --xtc-probability N                     xtc probability (default: 0.0, 0.0 = disabled)
# --xtc-threshold N                       xtc threshold (default: 0.1, 1.0 = disabled)
# --typical N                             locally typical sampling, parameter p (default: 1.0, 1.0 = disabled)
# --repeat-last-n N                       last n tokens to consider for penalize (default: 64, 0 = disabled, -1
#                                         = ctx_size)
# --repeat-penalty N                      penalize repeat sequence of tokens (default: 1.0, 1.0 = disabled)
$SCRIPT_DIR/../../llama.cpp/build/bin/llama-server \
	--props \
	--metrics \
	--port 8080 \
	--special \
	--temp $LLM_TEMP \
	--top-k $LLM_TOPK \
	--top-p $LLM_TOPP \
	--min-p $LLM_MINP \
	"$@"
