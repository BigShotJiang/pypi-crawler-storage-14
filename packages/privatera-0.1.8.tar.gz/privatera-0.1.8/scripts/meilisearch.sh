#!/usr/bin/env bash
# load MEILI_MASTER_KEY from .env before envoking meilisearch
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source $SCRIPT_DIR/../.env
echo LLM_URL=$LLM_URL
echo MEILI_URL=$MEILI_URL
if [[ -z $MEILI_MASTER_KEY ]] ; then
	echo "ERROR: MEILI_MASTER_KEY undefined in $SCRIPT_DIR/../.env "
else
	$SCRIPT_DIR/../../meilisearch/target/release/meilisearch \
		--no-analytics \
		--config-file-path $SCRIPT_DIR/../config-meilisearch.toml \
		--master-key $MEILI_MASTER_KEY \
		--log-level WARN \
		"$@"
fi
