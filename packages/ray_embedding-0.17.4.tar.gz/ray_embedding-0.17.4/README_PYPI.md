# Ray Embedding Service

`ray-embedding` packages everything needed to expose SentenceTransformers models through an OpenAI-compatible API that runs on a Ray Serve cluster.  
