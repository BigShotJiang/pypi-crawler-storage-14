# Ray Embedding package

`ray-embedding` is a Python package that includes everything required to host SentenceTransformers models in a Ray cluster. The models are exposed through an OpenAI-compatible API. The `ray-embedding` package provides:

- A `ModelRouter` that takes API requests and splits large batches into smaller batches, then fans out the work to instances/replicas of embedding models.
- An `EmbeddingModel` that encapsulates a `sentence-transformers`-compatible embedding model, handles Matryoshka truncation. It implements periodic GPU health checks so that GPU failures are reported. Inside the same health check logic, each replica of `EmbeddingModel` also checks if it is colocated with other replicas that have reported GPU failures - if this is the case then the replica also reports a failing health check.
- A `NodeRecycler` supervisor that tracks failure reports from replicas, informs replicas that other colocated replicas have failed, and recycles the underlying Ray worker node of replicas that have reported GPU failures. See [Node Recycling Workflow](#node-recycling-workflow) for the end-to-end path. 

These components are packaged as a Ray Serve application that can be deployed directly to a Ray cluster.

This library is designed for the [embedding-models Ray cluster](https://bitbucket.org/docorto/embedding-models/src/dev/), but can be embedded in any Serve app with similar requirements.  See the [reference Serve configuration](https://bitbucket.org/docorto/embedding-models/src/dev/serve-config/serve-config.yaml) for production defaults.

## Build

Refer to the [Build Instructions](Build.md).


## Serve Application

`ray-embedding` is deployed as the `embedding-service` Ray Serve application inside the Ray cluster.

![Serve application diagram](docs/diagrams/serve-application.png)



## Architecture

The `embedding-service` application is composed of three main building blocks: API ingress, model replicas, and the node recycler.

![Architecture diagram](docs/diagrams/architecture.png)

1. Clients call the REST API via ModelRouter using standard OpenAI embedding API.
2. The ModelRouter splits large requests into mini-batches and routes (concurrently) the mini-batches to embedding replicas. The ModelRouter aggregates the results computed by the replicas and returns a response to the client app.
3. Each EmbeddingModel replica has health check logic that can report GPU/CUDA failures to the NodeRecycler. The health check logic also checks if the node it is running in has already been tagged as unhealthy by a colocated replica - in which case the health check logic will also report unhealthy.
4. When a node is marked unhealthy, the NodeRecycler waits one recycle cycle for graceful shutdown, then it connects to the worker via SSH and issues a `docker stop ray_container` command. Ray will automatically re-creates the stopped Ray docker container. This resolves GPU driver issues.

## ModelRouter Dynamic Batch Resizing

The ModelRouter keeps replicas in a predictable steady state: it splits incoming batches into smaller "shards" sized for each model so GPUs stay busy without getting an OOM error. Larger embedding dimensions (e.g., `nomic v1` at 768d) run safely because the router sets a cap for the batch size, while lighter models (e.g., `nomic v1.5` at 384d) can take the same batch size, but we get more memory headroom.

- Incoming batches (each batch consists of 40 text chunks) are split using the per-model `batch_size` from `serve-config.yaml` (wired through `build_app` into the ModelRouter); both `nomic-embed-text-v1.5` and `nomic-embed-text-v1` split at 20 by default with the router controlling memory pressure.
- In the earlier, router-less setup the EmbeddingModel was hit directly with batch size 40, which caused a single replica’s GPU memory usage to spike; with the introduction of the ModelRouter, we now enforce uniform batch sizes so replicas get a controlled, repeatable load.
- A `max_concurrency` cap (default 32) limits asyncio fan-out so the router doesn’t flood model replicas with pending asyncio coroutines while the Ray autoscaler provisions new nodes (see Ray Serve autoscaling docs: https://docs.ray.io/en/latest/serve/advanced-guides/advanced-autoscaling.html). The request shards are dispatched in parallel, and the results aggregated in the original order. This keeps throughput high while minimising the risk of OOM.

![ModelRouter batch sharding diagram](docs/diagrams/modelrouter_batch_sharding.png)

## Deployment Topology

`ray-embedding` runs as a Ray Serve application inside a Ray cluster. Clients can reach it directly through the AWS ALB or indirectly through the openaiproxy service (which is based on litellm).

![Deployment diagram](docs/diagrams/deployment.png)

- Callers can hit the embeddings endpoints directly via the ALB, or call through the OpenAI-compatible proxy service (LiteLLM) that forwards to the same ALB endpoint.
- An AWS ALB fronts the cluster and targets the Ray head node where the Ray Serve HTTP proxy runs.
- The NodeRecycler is pinned to the head node (`resources: {"head_node": 1}`) so supervising and recycling worker nodes is unaffected by worker stopping and restarting.
- ModelRouter and EmbeddingModel replicas stay on GPU worker nodes (`resources: {"worker_node": 1}`) alongside the Ray worker runtime and GPUs.

## Node Recycling Workflow

When an EmbeddingModel replica detects a CUDA error (or any fatal condition), the recycler quarantines and stops the node so that Ray’s autoscaler can replaces the failed node. The NodeRecycler implements a workaround to address this [GH issue](https://github.com/ray-project/ray/issues/49594). In the GH issue, the recommended workarounds are not ideal (giving Docker more OS priviliges, cgroups changes) so the NodeRecycler uses a more straightforward method - SSH into the node and restart the Ray container. For context, this issue is specific to Ray+Docker on EC2; [KubeRay](https://docs.ray.io/en/latest/cluster/kubernetes/index.html) does not have this issue because K8s uses containerd/crio to run containers, not Docker.

![Failure workflow diagram](docs/diagrams/failure_workflow.png)

1. The ModelRouter dispatches a batch and receives an exception from a replica.
2. The replica reports the failure; the NodeRecycler records the node as unhealthy. Other replicas running on the same node will detect the failed node and begin failing their health checks.
3. During the next recycle cycle, the NodeRecycler stops the Ray worker’s Docker container via SSH so the node is replaced by Ray automatically.

## Quickstart

1. **Install dependencies for local development**
   ```bash
   pip install -r requirements.txt
   pip install -r requirements-build.txt  # optional, for packaging
   ```
2. **Deploy to Ray Serve** - See https://bitbucket.org/docorto/embedding-models/src/dev/


## Notes: 

To recreate the high-res png diagrams:

```bash
npx -y @mermaid-js/mermaid-cli@8.13.10 -i docs/diagrams/architecture.mmd -o docs/diagrams/architecture.png -w 1920
npx -y @mermaid-js/mermaid-cli@8.13.10 -i docs/diagrams/deployment.mmd -o docs/diagrams/deployment.png -w 1920
npx -y @mermaid-js/mermaid-cli@8.13.10 -i docs/diagrams/failure_workflow.mmd -o docs/diagrams/failure_workflow.png -w 1920
npx -y @mermaid-js/mermaid-cli@8.13.10 -i docs/diagrams/modelrouter_batch_sharding.mmd -o docs/diagrams/modelrouter_batch_sharding.png -w 1920
```

## Supported Backends

- pytorch-gpu
- pytorch-cpu

## Planned Backends

- onnx-gpu
- onnx-cpu
- openvino-cpu
