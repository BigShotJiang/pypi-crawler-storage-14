# -*- coding: utf-8 -*-
"""Implementations of feature detection methods."""

from pysteps.feature.interface import get_method
