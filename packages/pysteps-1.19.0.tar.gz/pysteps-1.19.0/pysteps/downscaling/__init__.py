# -*- coding: utf-8 -*-
"""Implementations of deterministic and ensemble downscaling methods."""

from pysteps.downscaling.interface import get_method
