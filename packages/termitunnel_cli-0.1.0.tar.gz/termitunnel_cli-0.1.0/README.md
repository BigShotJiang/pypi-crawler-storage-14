# TermiTunnel User Guide

TermiTunnel is a peer-to-peer communication tool that creates a secure, encrypted tunnel for private chat sessions directly in your terminal, powered by WireGuard.

---

### How It Works

1.  **Registry Server**: A central server acts as a phone book. It doesn't see or handle any communication, it just tells peers how to find each other.
2.  **TermiTunnel CLI**: The client tool you use to connect.
    - On `init`, it generates your unique cryptographic keys and registers you in the "phone book".
    - On `connect`, it gets the latest list of peers from the server and creates a local WireGuard configuration file.
3.  **WireGuard**: Once you activate the connection, WireGuard establishes a direct, end-to-end encrypted tunnel between you and the other peers. All communication from this point on is completely private.

---

### Prerequisites

1.  **Python**: You need Python 3 installed.
2.  **WireGuard Tools**: You must have the `wireguard-tools` package installed.
    - **macOS**: `brew install wireguard-tools`
    - **Debian/Ubuntu**: `sudo apt-get install wireguard-tools`
3.  **Project Files**: You need access to the `termitunnel` directory.

---

### Step-by-Step Usage

**Important**: All `python3` commands should be run from the directory *containing* the `termitunnel` folder.

#### 1. First-Time Setup (Run This Only Once)

Initialize your user profile. This creates your private keys and registers you with the server. Choose a unique username.

```bash
python3 termitunnel/client/termitunnel.py init --username <your-username>
```

#### 2. Connect to the Network

Before chatting, you must connect. This is a two-step process.

First, generate the WireGuard config file. This fetches the latest peer list.
```bash
python3 termitunnel/client/termitunnel.py connect
```

Second, activate the secure tunnel. This requires administrator privileges.
```bash
# On macOS or Linux
sudo wg-quick up ~/.termitunnel/wg0.conf
```
You are now connected to the private network.

#### 3. Chat with a Peer

You can see who is available on the network.
```bash
python3 termitunnel/client/termitunnel.py list-peers
```

To start a chat, get the commands for a specific user.
```bash
python3 termitunnel/client/termitunnel.py chat <username-of-peer>
```

The tool will give you two `netcat` commands. One person must **listen** and the other must **connect**.

- **Person A (Listen)**:
  ```bash
  nc -l 9999
  ```
- **Person B (Connect)**:
  ```bash
  nc <ip-of-person-a> 9999
  ```

Now, whatever you type in your terminal will appear in the other person's terminal. All communication is encrypted by WireGuard.

#### 4. Disconnect from the Network

When you are finished, bring the tunnel down. This also requires administrator privileges.
```bash
sudo wg-quick down ~/.termitunnel/wg0.conf
```

---
### For the Administrator

The registry server must be running on a machine that all users can access via its IP address or domain name. To start it, run the following command from within the `termitunnel` directory:

```bash
# Example:
uvicorn server.main:app --host 0.0.0.0 --port 8000
```
Users will then need to provide the server URL during initialization if it's not the default, for example:
`termitunnel init --username my-name --server http://<your-server-ip>:8000`
