import typer
import subprocess
import requests
import json
import time
import os
from pathlib import Path
from typing_extensions import Annotated

from rich.console import Console
from rich.text import Text
from rich.live import Live

app = typer.Typer(add_completion=False)

# --- ASCII Art and Banner ---

BANNER_TEXT = r"""
   ██████╗ ██████╗  ██████╗███████╗
  ██╔════╝██╔═══██╗██╔════╝██╔════╝
  ██║     ██║   ██║██║     ███████╗
  ██║     ██║   ██║██║     ╚════██║
  ╚██████╗╚██████╔╝╚██████╗███████║
   ╚═════╝ ╚═════╝  ╚═════╝╚═════╝
"""
SUB_BANNER_TEXT = "A P2P Chat Tunnel for SOCS by TermiTunnel"

console = Console()

def show_banner(animated: bool = False):
    """Displays the startup banner."""
    if not animated:
        banner = Text(BANNER_TEXT, style="bold cyan", justify="center")
        sub_banner = Text(SUB_BANNER_TEXT, style="bold green", justify="center")
        console.print(banner)
        console.print(sub_banner)
        console.print()
        return

    colors = ["bright_red", "red", "bright_magenta", "magenta", "purple"]
    with Live(console=console, screen=True, auto_refresh=False, vertical_overflow="visible") as live:
        for i in range(10):
            color = colors[i % len(colors)]
            banner = Text(BANNER_TEXT, style=f"bold {color}", justify="center")
            sub_banner = Text(SUB_BANNER_TEXT, style="bold green", justify="center")
            
            console.clear()
            console.print(banner)
            console.print(sub_banner)
            live.refresh()
            time.sleep(0.1)

@app.callback(invoke_without_command=True)
def main_callback(ctx: typer.Context):
    """
    TermiTunnel: A P2P Chat Tunnel for SOCS.
    Displays a banner and manages command execution.
    """
    # This function runs before any command.
    if ctx.invoked_subcommand is None:
        # No command was specified, show the full animated banner
        show_banner(animated=True)
        # Show help text
        console.print("\nWelcome to TermiTunnel! Use --help to see available commands.", style="yellow")

# --- App Configuration ---

SERVER_URL = "http://127.0.0.1:8000"
CONFIG_DIR = Path.home() / ".termitunnel"
CONFIG_FILE = CONFIG_DIR / "config.json"
WG_CONFIG_FILE = CONFIG_DIR / "wg0.conf"

# --- Helper Functions ---

def is_wireguard_installed():
    """Check if 'wg' command is available."""
    try:
        subprocess.run(["wg", "--version"], capture_output=True, check=True, text=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

# --- Commands ---

@app.command()
def init(
    username: str = typer.Option(..., "--username", "-u", help="Your unique username"),
    server: str = typer.Option(SERVER_URL, help="URL of the registry server")
):
    """
    Initialize TermiTunnel: generate keys and register with the server.
    """
    console.print("[bold cyan]Initializing TermiTunnel...[/bold cyan]")
    if not is_wireguard_installed():
        typer.secho("Error: WireGuard tools ('wg') not found.", fg=typer.colors.RED)
        typer.echo("Please install wireguard-tools (e.g., 'sudo apt-get install wireguard-tools' or 'brew install wireguard-tools')")
        raise typer.Exit(code=1)

    typer.echo("WireGuard tools found.")
    
    CONFIG_DIR.mkdir(exist_ok=True)
    if CONFIG_FILE.exists():
        typer.secho(f"Already initialized. Config file exists at {CONFIG_FILE}", fg=typer.colors.YELLOW)
        typer.echo("If you want to re-initialize, please remove this file first.")
        raise typer.Exit()

    typer.echo(f"Generating WireGuard keys...")
    try:
        private_key = subprocess.run(
            ["wg", "genkey"], capture_output=True, text=True, check=True
        ).stdout.strip()
        
        public_key = subprocess.run(
            ["wg", "pubkey"],
            input=private_key,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
    except subprocess.CalledProcessError as e:
        typer.secho(f"Failed to generate keys: {e.stderr}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    typer.echo("Keys generated successfully.")
    typer.echo(f"Registering '{username}' with server at {server}...")

    try:
        response = requests.post(
            f"{server}/register/",
            json={"username": username, "public_key": public_key},
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        typer.secho(f"Error connecting to server: {e}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if response.status_code == 200:
        peer_data = response.json()
        config = {
            "username": username,
            "private_key": private_key,
            "public_key": public_key,
            "ip_address": peer_data["ip_address"],
        }
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)
        
        typer.secho(f"Success! Registered as '{username}' with IP {peer_data['ip_address']}", fg=typer.colors.GREEN)
        typer.echo(f"Configuration saved to {CONFIG_FILE}")
    else:
        typer.secho(f"Error from server: {response.text}", fg=typer.colors.RED)
        raise typer.Exit(code=1)


@app.command()
def connect(server: str = typer.Option(SERVER_URL, help="URL of the registry server")):
    """
    Generate WireGuard config to connect to the TermiTunnel network.
    """
    show_banner()
    if not CONFIG_FILE.exists():
        typer.secho("Not initialized. Please run 'termitunnel init' first.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    with open(CONFIG_FILE, "r") as f:
        local_config = json.load(f)

    typer.echo("Fetching peer list from server...")
    try:
        response = requests.get(f"{server}/peers/")
        response.raise_for_status()
        peers = response.json()
    except requests.exceptions.RequestException as e:
        typer.secho(f"Error connecting to server: {e}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    wg_config = []
    wg_config.append("[Interface]")
    wg_config.append(f"PrivateKey = {local_config['private_key']}")
    wg_config.append(f"Address = {local_config['ip_address']}/24")
    wg_config.append("")

    typer.echo("Generating WireGuard configuration...")
    peer_count = 0
    for peer in peers:
        if peer['username'] == local_config['username']:
            continue
        peer_count += 1
        wg_config.append("[Peer]")
        wg_config.append(f"# {peer['username']}")
        wg_config.append(f"PublicKey = {peer['public_key']}")
        wg_config.append(f"AllowedIPs = {peer['ip_address']}/32")
        wg_config.append("")


    with open(WG_CONFIG_FILE, "w") as f:
        f.write("\n".join(wg_config))

    typer.secho(f"WireGuard configuration for {peer_count} peer(s) saved to {WG_CONFIG_FILE}", fg=typer.colors.GREEN)
    typer.echo("\nTo connect, run the following command:")
    typer.secho(f"  sudo wg-quick up {WG_CONFIG_FILE}", bold=True)


@app.command()
def disconnect():
    """
    Show the command to disconnect from the TermiTunnel network.
    """
    show_banner()
    if not WG_CONFIG_FILE.exists():
        typer.secho("Not connected or config file not found.", fg=typer.colors.YELLOW)
        raise typer.Exit(code=1)
    
    typer.echo("To disconnect, run the following command:")
    typer.secho(f"  sudo wg-quick down {WG_CONFIG_FILE}", bold=True)

@app.command(name="list-peers")
def list_peers(server: str = typer.Option(SERVER_URL, help="URL of the registry server")):
    """
    List all registered peers.
    """
    show_banner()
    typer.echo("Fetching peer list from server...")
    try:
        response = requests.get(f"{server}/peers/")
        response.raise_for_status()
        peers = response.json()
    except requests.exceptions.RequestException as e:
        typer.secho(f"Error connecting to server: {e}", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    
    from rich.table import Table

    table = Table("Username", "Tunnel IP", "Public Key")
    for peer in peers:
        table.add_row(peer['username'], peer['ip_address'], peer['public_key'])
    
    console.print(table)

@app.command()
def chat(
    username: Annotated[str, typer.Argument(help="The username of the peer you want to chat with.")],
    port: Annotated[int, typer.Option(help="The port to use for the chat.")] = 9999,
    server: str = typer.Option(SERVER_URL, help="URL of the registry server")
):
    """
    Show commands to start a P2P chat with a peer over the tunnel.
    """
    show_banner()
    typer.echo(f"Looking for peer '{username}'...")
    try:
        response = requests.get(f"{server}/peers/")
        response.raise_for_status()
        peers = response.json()
    except requests.exceptions.RequestException as e:
        typer.secho(f"Error connecting to server: {e}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    target_peer = next((p for p in peers if p['username'] == username), None)

    if not target_peer:
        typer.secho(f"Peer '{username}' not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    peer_ip = target_peer['ip_address']
    typer.secho(f"Found peer '{username}' at {peer_ip}", fg=typer.colors.GREEN)
    typer.echo("\n---")
    typer.echo("To start chatting, one person must listen and the other must connect.")
    typer.echo("Make sure your WireGuard tunnel is active first!\n")

    typer.echo("To connect to the peer (you type first):")
    typer.secho(f"  nc {peer_ip} {port}", bold=True)
    
    typer.echo("\nOR\n")

    typer.echo("To listen for a connection from the peer (they type first):")
    typer.secho(f"  nc -l {port}", bold=True)
    typer.echo("---")


if __name__ == "__main__":
    app()
