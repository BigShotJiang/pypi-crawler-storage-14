use pyo3::PyErr;
use pyo3::exceptions::{
    PyIndexError, PyNotImplementedError, PyRuntimeError, PyTypeError, PyValueError,
};
use pyo3::import_exception;
use std::fmt::Debug;
use std::result::Result;
use thiserror::Error;

import_exception!(pickle, PicklingError);
import_exception!(pickle, UnpicklingError);

#[allow(clippy::enum_variant_names)]
#[derive(Error, Debug)]
#[error("{0}")]
pub(crate) enum Exception {
    // builtins
    IndexError(String),
    NotImplementedError(String),
    RuntimeError(String),
    TypeError(String),
    ValueError(String),
    // pickle
    PicklingError(String),
    UnpicklingError(String),
    // some exception from pyo3 which we need to handle
    PyO3(#[from] PyErr),
}

impl From<Exception> for PyErr {
    fn from(err: Exception) -> PyErr {
        match err {
            // builtins
            Exception::IndexError(err) => PyIndexError::new_err(err),
            Exception::NotImplementedError(err) => PyNotImplementedError::new_err(err),
            Exception::RuntimeError(err) => PyRuntimeError::new_err(err),
            Exception::TypeError(err) => PyTypeError::new_err(err),
            Exception::ValueError(err) => PyValueError::new_err(err),
            // pickle
            Exception::PicklingError(err) => PicklingError::new_err(err),
            Exception::UnpicklingError(err) => UnpicklingError::new_err(err),
            // pyo3
            Exception::PyO3(err) => err,
        }
    }
}

impl From<light_curve_feature::EvaluatorError> for Exception {
    fn from(err: light_curve_feature::EvaluatorError) -> Self {
        Exception::RuntimeError(err.to_string())
    }
}

pub(crate) type Res<T> = Result<T, Exception>;
