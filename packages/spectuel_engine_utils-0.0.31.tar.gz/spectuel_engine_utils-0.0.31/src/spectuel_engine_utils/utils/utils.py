def get_default_cash_balance():
    return 10_000
