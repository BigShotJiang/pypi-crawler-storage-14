#
# Copyright (c) 2024 - 2025 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module containing some eric-ide version information.
"""

Version = "25.12 (rev. 80a1c9db702b)"
VersionOnly = "25.12"
