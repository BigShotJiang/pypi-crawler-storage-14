from django.apps import AppConfig


class ObjectsAPIClientConfig(AppConfig):
    name = "objectsapiclient"
