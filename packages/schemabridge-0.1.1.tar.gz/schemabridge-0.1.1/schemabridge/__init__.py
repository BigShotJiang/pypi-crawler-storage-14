"""SchemaBridge: Cross-language schema converter (Zod to Pydantic/TypeScript)."""

__version__ = "0.1.0"

__all__ = ["__version__"]
