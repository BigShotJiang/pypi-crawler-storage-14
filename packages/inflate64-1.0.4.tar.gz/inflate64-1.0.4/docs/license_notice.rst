.. _license_notice:

==============
License notice
==============

Inflate64 is distributed under GNU Lesser General Public License version 2.1
or any later version.

Inflate64 uses sources from zlib with modifications.
Here is a zlib license notification.
    Copyright (C) 1995-2022 Jean-loup Gailly and Mark Adler

    This software is provided 'as-is', without any express or implied
    warranty.  In no event will the authors be held liable for any damages
    arising from the use of this software.

    Permission is granted to anyone to use this software for any purpose,
    including commercial applications, and to alter it and redistribute it
    freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not
       claim that you wrote the original software. If you use this software
       in a product, an acknowledgment in the product documentation would be
       appreciated but is not required.
    2. Altered source versions must be plainly marked as such, and must not be
       misrepresented as being the original software.
    3. This notice may not be removed or altered from any source distribution.

       Jean-loup Gailly        Mark Adler
       jloup@gzip.org          madler@alumni.caltech.edu

    If you use the zlib library in a product, we would appreciate *not* receiving
    lengthy legal documents to sign.  The sources are provided for free but without
    warranty of any kind.  The library has been entirely written by Jean-loup
    Gailly and Mark Adler; it does not include third-party code.  We make all
    contributions to and distributions of this project solely in our personal
    capacity, and are not conveying any rights to any intellectual property of
    any third parties.

    If you redistribute modified sources, we would appreciate that you include in
    the file ChangeLog history information documenting your changes.  Please read
    the FAQ for more information on the distribution of modified source versions.
