Inflate64 Python module
=======================

Inflate is a wellknown compression technique as a ZLib compression library.
Inflate64 is a extension of the Inflate.
Please refer technical note for details.

The ``inflate64`` package uses C files from ``zlib``.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   getting_started
   contribution
   security_policy
   technote
   license_notice
   Changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
