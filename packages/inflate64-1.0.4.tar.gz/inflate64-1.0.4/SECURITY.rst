Security Policy
===============

Supported Versions
------------------

+---------+--------------------+
| Version | Status             |
+=========+====================+
| 1.0.x   | Production/Stable  |
+---------+--------------------+
| < 1.0   | not supported      |
+---------+--------------------+

Reporting a Vulnerability
-------------------------

Please disclose security vulnerabilities privately at miurahr@linux.com
