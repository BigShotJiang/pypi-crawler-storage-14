import os
from pathlib import Path
import typer
from rich.console import Console
from typing_extensions import Annotated
from opsgeniecli.commands import on_call, config, alerts, commands, alert_policies
from opsgenielib import Opsgenie


# [x] alerts
# [x] config
# [] escalations
# [] heartbeat
# [] integrations
# [] logs
# [x] on-call
# [x] override
# [x] policy-alerts
# [] policy-maintenance
# [] policy-notifications
# [] schedules
# [] teams
# [] teams-routing-rules
# [] user

console = Console()
app = typer.Typer(rich_markup_mode="rich", no_args_is_help=True)
app.add_typer(typer_instance=on_call.app, name="on-call")
app.add_typer(typer_instance=config.app, name="config")
app.add_typer(typer_instance=alerts.app, name="alerts")
app.add_typer(typer_instance=alert_policies.app, name="alert-policies")
app.add_typer(typer_instance=commands.app, name="commands")


class OpsgenieCli:
    def __init__(
        self, opsgenie: Opsgenie, config: config.Config, profile: config.ConfigProfile
    ) -> None:
        self.opsgenie = opsgenie
        self.config = config
        self.profile = profile


@app.callback()
def common(
    ctx: typer.Context,
    config_file: Annotated[str, typer.Option()] = os.path.expanduser(
        path=f"{Path.home()}/.config/opsgenie-cli/config.json"
    ),
    team_name: Annotated[str, typer.Option(envvar="OPSGENIE_TEAM_NAME")] = "",
    api_key: Annotated[str, typer.Option(envvar="OPSGENIE_API_KEY")] = "",
    profile: Annotated[str, typer.Option(envvar="OPSGENIE_PROFILE")] = "default",
) -> None:
    """Common Entry Point"""
    _config = config.read_config(config_file=config_file)
    _profile = _config.find_profile_by_name(profile_name=profile)

    # create function to override values?
    _profile.name = team_name if team_name else _profile.name
    _profile.api_key = api_key if api_key else _profile.api_key
    opsgenie = Opsgenie(api_key=_profile.api_key)

    ctx.obj = OpsgenieCli(opsgenie=opsgenie, config=_config, profile=_profile)


if __name__ == "__main__":
    app()
