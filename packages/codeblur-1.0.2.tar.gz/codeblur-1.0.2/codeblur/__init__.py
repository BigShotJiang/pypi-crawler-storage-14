"""
CodeBlur - A powerful GUI tool for obfuscating and deobfuscating code strings
"""

from .codeblur import main

__version__ = "1.0.1"
__author__ = "CodeBlur Team"
__all__ = ["main"]
