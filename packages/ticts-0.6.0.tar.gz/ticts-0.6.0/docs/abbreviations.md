*[HTML]: Hyper Text Markup Language
*[W3C]: World Wide Web Consortium
*[PEP]: Python Enhancement Proposal
