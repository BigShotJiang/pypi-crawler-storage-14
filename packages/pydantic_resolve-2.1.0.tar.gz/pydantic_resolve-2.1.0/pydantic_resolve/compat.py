from pydantic.version import VERSION as P_VERSION

PYDANTIC_VERSION = P_VERSION