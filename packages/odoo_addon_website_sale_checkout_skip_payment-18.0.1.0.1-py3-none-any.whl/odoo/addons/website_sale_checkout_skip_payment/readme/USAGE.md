To use this module, you need to:

1.  Go to *Website \> shop* and perform a checkout.
