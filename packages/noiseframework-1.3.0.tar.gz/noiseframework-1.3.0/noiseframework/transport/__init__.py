"""Transport layer for post-handshake encrypted communication."""

from noiseframework.transport.transport import NoiseTransport

__all__ = ["NoiseTransport"]
