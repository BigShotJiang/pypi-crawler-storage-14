"""Command-line interface for NoiseFramework."""
