"""Noise Protocol Framework implementation."""
