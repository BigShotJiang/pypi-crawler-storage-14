"""Cryptographic primitives for Noise Protocol."""
