//#region node_modules/.pnpm/esm-env@1.2.2/node_modules/esm-env/dev-fallback.js
const node_env = globalThis.process?.env?.NODE_ENV;
var dev_fallback_default = node_env && !node_env.toLowerCase().startsWith("prod");

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/shared/utils.js
var is_array = Array.isArray;
var index_of = Array.prototype.indexOf;
var array_from = Array.from;
var object_keys = Object.keys;
var define_property = Object.defineProperty;
var get_descriptor = Object.getOwnPropertyDescriptor;
var get_descriptors = Object.getOwnPropertyDescriptors;
var object_prototype = Object.prototype;
var array_prototype = Array.prototype;
var get_prototype_of = Object.getPrototypeOf;
var is_extensible = Object.isExtensible;
/** @param {Array<() => void>} arr */
function run_all(arr) {
	for (var i = 0; i < arr.length; i++) arr[i]();
}
/**
* TODO replace with Promise.withResolvers once supported widely enough
* @template T
*/
function deferred() {
	/** @type {(value: T) => void} */
	var resolve;
	/** @type {(reason: any) => void} */
	var reject;
	/** @type {Promise<T>} */
	var promise = new Promise((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return {
		promise,
		resolve,
		reject
	};
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/constants.js
const DERIVED = 2;
const EFFECT = 4;
const RENDER_EFFECT = 8;
const BLOCK_EFFECT = 16;
const BRANCH_EFFECT = 32;
const ROOT_EFFECT = 64;
const BOUNDARY_EFFECT = 128;
/**
* Indicates that a reaction is connected to an effect root — either it is an effect,
* or it is a derived that is depended on by at least one effect. If a derived has
* no dependents, we can disconnect it from the graph, allowing it to either be
* GC'd or reconnected later if an effect comes to depend on it again
*/
const CONNECTED = 512;
const CLEAN = 1024;
const DIRTY = 2048;
const MAYBE_DIRTY = 4096;
const INERT = 8192;
const DESTROYED = 16384;
/** Set once an effect that should run synchronously has run */
const EFFECT_RAN = 32768;
/**
* 'Transparent' effects do not create a transition boundary.
* This is on a block effect 99% of the time but may also be on a branch effect if its parent block effect was pruned
*/
const EFFECT_TRANSPARENT = 65536;
const EAGER_EFFECT = 1 << 17;
const HEAD_EFFECT = 1 << 18;
const EFFECT_PRESERVED = 1 << 19;
const USER_EFFECT = 1 << 20;
/**
* Tells that we marked this derived and its reactions as visited during the "mark as (maybe) dirty"-phase.
* Will be lifted during execution of the derived and during checking its dirty state (both are necessary
* because a derived might be checked but not executed).
*/
const WAS_MARKED = 32768;
const REACTION_IS_UPDATING = 1 << 21;
const ASYNC = 1 << 22;
const ERROR_VALUE = 1 << 23;
const STATE_SYMBOL = Symbol("$state");
const LEGACY_PROPS = Symbol("legacy props");
const LOADING_ATTR_SYMBOL = Symbol("");
const PROXY_PATH_SYMBOL = Symbol("proxy path");
/** allow users to ignore aborted signal errors if `reason.name === 'StaleReactionError` */
const STALE_REACTION = new class StaleReactionError extends Error {
	name = "StaleReactionError";
	message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
const TEXT_NODE = 3;
const COMMENT_NODE = 8;

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/errors.js
/**
* Cannot create a `$derived(...)` with an `await` expression outside of an effect tree
* @returns {never}
*/
function async_derived_orphan() {
	if (dev_fallback_default) {
		const error = new Error(`async_derived_orphan\nCannot create a \`$derived(...)\` with an \`await\` expression outside of an effect tree\nhttps://svelte.dev/e/async_derived_orphan`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/async_derived_orphan`);
}
/**
* A derived value cannot reference itself recursively
* @returns {never}
*/
function derived_references_self() {
	if (dev_fallback_default) {
		const error = new Error(`derived_references_self\nA derived value cannot reference itself recursively\nhttps://svelte.dev/e/derived_references_self`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/derived_references_self`);
}
/**
* `%rune%` cannot be used inside an effect cleanup function
* @param {string} rune
* @returns {never}
*/
function effect_in_teardown(rune) {
	if (dev_fallback_default) {
		const error = new Error(`effect_in_teardown\n\`${rune}\` cannot be used inside an effect cleanup function\nhttps://svelte.dev/e/effect_in_teardown`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/effect_in_teardown`);
}
/**
* Effect cannot be created inside a `$derived` value that was not itself created inside an effect
* @returns {never}
*/
function effect_in_unowned_derived() {
	if (dev_fallback_default) {
		const error = new Error(`effect_in_unowned_derived\nEffect cannot be created inside a \`$derived\` value that was not itself created inside an effect\nhttps://svelte.dev/e/effect_in_unowned_derived`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/effect_in_unowned_derived`);
}
/**
* `%rune%` can only be used inside an effect (e.g. during component initialisation)
* @param {string} rune
* @returns {never}
*/
function effect_orphan(rune) {
	if (dev_fallback_default) {
		const error = new Error(`effect_orphan\n\`${rune}\` can only be used inside an effect (e.g. during component initialisation)\nhttps://svelte.dev/e/effect_orphan`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/effect_orphan`);
}
/**
* Maximum update depth exceeded. This typically indicates that an effect reads and writes the same piece of state
* @returns {never}
*/
function effect_update_depth_exceeded() {
	if (dev_fallback_default) {
		const error = new Error(`effect_update_depth_exceeded\nMaximum update depth exceeded. This typically indicates that an effect reads and writes the same piece of state\nhttps://svelte.dev/e/effect_update_depth_exceeded`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/effect_update_depth_exceeded`);
}
/**
* Cannot use `flushSync` inside an effect
* @returns {never}
*/
function flush_sync_in_effect() {
	if (dev_fallback_default) {
		const error = new Error(`flush_sync_in_effect\nCannot use \`flushSync\` inside an effect\nhttps://svelte.dev/e/flush_sync_in_effect`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/flush_sync_in_effect`);
}
/**
* Failed to hydrate the application
* @returns {never}
*/
function hydration_failed() {
	if (dev_fallback_default) {
		const error = new Error(`hydration_failed\nFailed to hydrate the application\nhttps://svelte.dev/e/hydration_failed`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/hydration_failed`);
}
/**
* The `%rune%` rune is only available inside `.svelte` and `.svelte.js/ts` files
* @param {string} rune
* @returns {never}
*/
function rune_outside_svelte(rune) {
	if (dev_fallback_default) {
		const error = new Error(`rune_outside_svelte\nThe \`${rune}\` rune is only available inside \`.svelte\` and \`.svelte.js/ts\` files\nhttps://svelte.dev/e/rune_outside_svelte`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/rune_outside_svelte`);
}
/**
* Property descriptors defined on `$state` objects must contain `value` and always be `enumerable`, `configurable` and `writable`.
* @returns {never}
*/
function state_descriptors_fixed() {
	if (dev_fallback_default) {
		const error = new Error(`state_descriptors_fixed\nProperty descriptors defined on \`$state\` objects must contain \`value\` and always be \`enumerable\`, \`configurable\` and \`writable\`.\nhttps://svelte.dev/e/state_descriptors_fixed`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/state_descriptors_fixed`);
}
/**
* Cannot set prototype of `$state` object
* @returns {never}
*/
function state_prototype_fixed() {
	if (dev_fallback_default) {
		const error = new Error(`state_prototype_fixed\nCannot set prototype of \`$state\` object\nhttps://svelte.dev/e/state_prototype_fixed`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/state_prototype_fixed`);
}
/**
* Updating state inside `$derived(...)`, `$inspect(...)` or a template expression is forbidden. If the value should not be reactive, declare it without `$state`
* @returns {never}
*/
function state_unsafe_mutation() {
	if (dev_fallback_default) {
		const error = new Error(`state_unsafe_mutation\nUpdating state inside \`$derived(...)\`, \`$inspect(...)\` or a template expression is forbidden. If the value should not be reactive, declare it without \`$state\`\nhttps://svelte.dev/e/state_unsafe_mutation`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/state_unsafe_mutation`);
}
/**
* A `<svelte:boundary>` `reset` function cannot be called while an error is still being handled
* @returns {never}
*/
function svelte_boundary_reset_onerror() {
	if (dev_fallback_default) {
		const error = new Error(`svelte_boundary_reset_onerror\nA \`<svelte:boundary>\` \`reset\` function cannot be called while an error is still being handled\nhttps://svelte.dev/e/svelte_boundary_reset_onerror`);
		error.name = "Svelte error";
		throw error;
	} else throw new Error(`https://svelte.dev/e/svelte_boundary_reset_onerror`);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/constants.js
const EACH_ITEM_REACTIVE = 1;
const EACH_INDEX_REACTIVE = 2;
/** See EachBlock interface metadata.is_controlled for an explanation what this is */
const EACH_IS_CONTROLLED = 4;
const EACH_IS_ANIMATED = 8;
const EACH_ITEM_IMMUTABLE = 16;
const TEMPLATE_FRAGMENT = 1;
const TEMPLATE_USE_IMPORT_NODE = 2;
const HYDRATION_START = "[";
/** used to indicate that an `{:else}...` block was rendered */
const HYDRATION_START_ELSE = "[!";
const HYDRATION_END = "]";
const HYDRATION_ERROR = {};
const UNINITIALIZED = Symbol();
const FILENAME = Symbol("filename");
const HMR = Symbol("hmr");
const NAMESPACE_HTML = "http://www.w3.org/1999/xhtml";

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/warnings.js
var bold = "font-weight: bold";
var normal = "font-weight: normal";
/**
* An async derived, `%name%` (%location%) was not read immediately after it resolved. This often indicates an unnecessary waterfall, which can slow down your app
* @param {string} name
* @param {string} location
*/
function await_waterfall(name, location) {
	if (dev_fallback_default) console.warn(`%c[svelte] await_waterfall\n%cAn async derived, \`${name}\` (${location}) was not read immediately after it resolved. This often indicates an unnecessary waterfall, which can slow down your app\nhttps://svelte.dev/e/await_waterfall`, bold, normal);
	else console.warn(`https://svelte.dev/e/await_waterfall`);
}
/**
* The `%attribute%` attribute on `%html%` changed its value between server and client renders. The client value, `%value%`, will be ignored in favour of the server value
* @param {string} attribute
* @param {string} html
* @param {string} value
*/
function hydration_attribute_changed(attribute, html, value) {
	if (dev_fallback_default) console.warn(`%c[svelte] hydration_attribute_changed\n%cThe \`${attribute}\` attribute on \`${html}\` changed its value between server and client renders. The client value, \`${value}\`, will be ignored in favour of the server value\nhttps://svelte.dev/e/hydration_attribute_changed`, bold, normal);
	else console.warn(`https://svelte.dev/e/hydration_attribute_changed`);
}
/**
* Hydration failed because the initial UI does not match what was rendered on the server. The error occurred near %location%
* @param {string | undefined | null} [location]
*/
function hydration_mismatch(location) {
	if (dev_fallback_default) console.warn(`%c[svelte] hydration_mismatch\n%c${location ? `Hydration failed because the initial UI does not match what was rendered on the server. The error occurred near ${location}` : "Hydration failed because the initial UI does not match what was rendered on the server"}\nhttps://svelte.dev/e/hydration_mismatch`, bold, normal);
	else console.warn(`https://svelte.dev/e/hydration_mismatch`);
}
/**
* Tried to unmount a component that was not mounted
*/
function lifecycle_double_unmount() {
	if (dev_fallback_default) console.warn(`%c[svelte] lifecycle_double_unmount\n%cTried to unmount a component that was not mounted\nhttps://svelte.dev/e/lifecycle_double_unmount`, bold, normal);
	else console.warn(`https://svelte.dev/e/lifecycle_double_unmount`);
}
/**
* Reactive `$state(...)` proxies and the values they proxy have different identities. Because of this, comparisons with `%operator%` will produce unexpected results
* @param {string} operator
*/
function state_proxy_equality_mismatch(operator) {
	if (dev_fallback_default) console.warn(`%c[svelte] state_proxy_equality_mismatch\n%cReactive \`$state(...)\` proxies and the values they proxy have different identities. Because of this, comparisons with \`${operator}\` will produce unexpected results\nhttps://svelte.dev/e/state_proxy_equality_mismatch`, bold, normal);
	else console.warn(`https://svelte.dev/e/state_proxy_equality_mismatch`);
}
/**
* Tried to unmount a state proxy, rather than a component
*/
function state_proxy_unmount() {
	if (dev_fallback_default) console.warn(`%c[svelte] state_proxy_unmount\n%cTried to unmount a state proxy, rather than a component\nhttps://svelte.dev/e/state_proxy_unmount`, bold, normal);
	else console.warn(`https://svelte.dev/e/state_proxy_unmount`);
}
/**
* A `<svelte:boundary>` `reset` function only resets the boundary the first time it is called
*/
function svelte_boundary_reset_noop() {
	if (dev_fallback_default) console.warn(`%c[svelte] svelte_boundary_reset_noop\n%cA \`<svelte:boundary>\` \`reset\` function only resets the boundary the first time it is called\nhttps://svelte.dev/e/svelte_boundary_reset_noop`, bold, normal);
	else console.warn(`https://svelte.dev/e/svelte_boundary_reset_noop`);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/hydration.js
/**
* Use this variable to guard everything related to hydration code so it can be treeshaken out
* if the user doesn't use the `hydrate` method and these code paths are therefore not needed.
*/
let hydrating = false;
/** @param {boolean} value */
function set_hydrating(value) {
	hydrating = value;
}
/**
* The node that is currently being hydrated. This starts out as the first node inside the opening
* <!--[--> comment, and updates each time a component calls `$.child(...)` or `$.sibling(...)`.
* When entering a block (e.g. `{#if ...}`), `hydrate_node` is the block opening comment; by the
* time we leave the block it is the closing comment, which serves as the block's anchor.
* @type {TemplateNode}
*/
let hydrate_node;
/** @param {TemplateNode} node */
function set_hydrate_node(node) {
	if (node === null) {
		hydration_mismatch();
		throw HYDRATION_ERROR;
	}
	return hydrate_node = node;
}
function hydrate_next() {
	return set_hydrate_node(get_next_sibling(hydrate_node));
}
/** @param {TemplateNode} node */
function reset(node) {
	if (!hydrating) return;
	if (get_next_sibling(hydrate_node) !== null) {
		hydration_mismatch();
		throw HYDRATION_ERROR;
	}
	hydrate_node = node;
}
function next(count = 1) {
	if (hydrating) {
		var i = count;
		var node = hydrate_node;
		while (i--) node = get_next_sibling(node);
		hydrate_node = node;
	}
}
/**
* Skips or removes (depending on {@link remove}) all nodes starting at `hydrate_node` up until the next hydration end comment
* @param {boolean} remove
*/
function skip_nodes(remove = true) {
	var depth = 0;
	var node = hydrate_node;
	while (true) {
		if (node.nodeType === COMMENT_NODE) {
			var data = node.data;
			if (data === HYDRATION_END) {
				if (depth === 0) return node;
				depth -= 1;
			} else if (data === HYDRATION_START || data === HYDRATION_START_ELSE) depth += 1;
		}
		var next$1 = get_next_sibling(node);
		if (remove) node.remove();
		node = next$1;
	}
}
/**
*
* @param {TemplateNode} node
*/
function read_hydration_instruction(node) {
	if (!node || node.nodeType !== COMMENT_NODE) {
		hydration_mismatch();
		throw HYDRATION_ERROR;
	}
	return node.data;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/equality.js
/** @import { Equals } from '#client' */
/** @type {Equals} */
function equals(value) {
	return value === this.v;
}
/**
* @param {unknown} a
* @param {unknown} b
* @returns {boolean}
*/
function safe_not_equal(a, b) {
	return a != a ? b == b : a !== b || a !== null && typeof a === "object" || typeof a === "function";
}
/** @type {Equals} */
function safe_equals(value) {
	return !safe_not_equal(value, this.v);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/flags/index.js
/** True if experimental.async=true */
let async_mode_flag = false;
/** True if we're not certain that we only have Svelte 5 code in the compilation */
let legacy_mode_flag = false;
/** True if $inspect.trace is used */
let tracing_mode_flag = false;

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dev/tracing.js
/**
* @typedef {{
*   traces: Error[];
* }} TraceEntry
*/
/** @type {{ reaction: Reaction | null, entries: Map<Value, TraceEntry> } | null} */
let tracing_expressions = null;
/**
* @param {string} label
* @returns {Error & { stack: string } | null}
*/
function get_stack(label) {
	const limit = Error.stackTraceLimit;
	Error.stackTraceLimit = Infinity;
	let error = Error();
	Error.stackTraceLimit = limit;
	const stack$1 = error.stack;
	if (!stack$1) return null;
	const lines = stack$1.split("\n");
	const new_lines = ["\n"];
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		const posixified = line.replaceAll("\\", "/");
		if (line === "Error") continue;
		if (line.includes("validate_each_keys")) return null;
		if (posixified.includes("svelte/src/internal") || posixified.includes("node_modules/.vite")) continue;
		new_lines.push(line);
	}
	if (new_lines.length === 1) return null;
	define_property(error, "stack", { value: new_lines.join("\n") });
	define_property(error, "name", { value: label });
	return error;
}
/**
* @param {Value} source
* @param {string} label
*/
function tag(source$1, label) {
	source$1.label = label;
	tag_proxy(source$1.v, label);
	return source$1;
}
/**
* @param {unknown} value
* @param {string} label
*/
function tag_proxy(value, label) {
	value?.[PROXY_PATH_SYMBOL]?.(label);
	return value;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/context.js
/** @type {ComponentContext | null} */
let component_context = null;
/** @param {ComponentContext | null} context */
function set_component_context(context) {
	component_context = context;
}
/** @type {DevStackEntry | null} */
let dev_stack = null;
/** @param {DevStackEntry | null} stack */
function set_dev_stack(stack$1) {
	dev_stack = stack$1;
}
/**
* The current component function. Different from current component context:
* ```html
* <!-- App.svelte -->
* <Foo>
*   <Bar /> <!-- context == Foo.svelte, function == App.svelte -->
* </Foo>
* ```
* @type {ComponentContext['function']}
*/
let dev_current_component_function = null;
/** @param {ComponentContext['function']} fn */
function set_dev_current_component_function(fn) {
	dev_current_component_function = fn;
}
/**
* @param {Record<string, unknown>} props
* @param {any} runes
* @param {Function} [fn]
* @returns {void}
*/
function push(props, runes = false, fn) {
	component_context = {
		p: component_context,
		i: false,
		c: null,
		e: null,
		s: props,
		x: null,
		l: legacy_mode_flag && !runes ? {
			s: null,
			u: null,
			$: []
		} : null
	};
	if (dev_fallback_default) {
		component_context.function = fn;
		dev_current_component_function = fn;
	}
}
/**
* @template {Record<string, any>} T
* @param {T} [component]
* @returns {T}
*/
function pop(component) {
	var context = component_context;
	var effects = context.e;
	if (effects !== null) {
		context.e = null;
		for (var fn of effects) create_user_effect(fn);
	}
	if (component !== void 0) context.x = component;
	context.i = true;
	component_context = context.p;
	if (dev_fallback_default) dev_current_component_function = component_context?.function ?? null;
	return component ?? {};
}
/** @returns {boolean} */
function is_runes() {
	return !legacy_mode_flag || component_context !== null && component_context.l === null;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/task.js
/** @type {Array<() => void>} */
let micro_tasks = [];
function run_micro_tasks() {
	var tasks = micro_tasks;
	micro_tasks = [];
	run_all(tasks);
}
/**
* @param {() => void} fn
*/
function queue_micro_task(fn) {
	if (micro_tasks.length === 0 && !is_flushing_sync) {
		var tasks = micro_tasks;
		queueMicrotask(() => {
			if (tasks === micro_tasks) run_micro_tasks();
		});
	}
	micro_tasks.push(fn);
}
/**
* Synchronously run any queued tasks.
*/
function flush_tasks() {
	while (micro_tasks.length > 0) run_micro_tasks();
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/error-handling.js
const adjustments = /* @__PURE__ */ new WeakMap();
/**
* @param {unknown} error
*/
function handle_error(error) {
	var effect$1 = active_effect;
	if (effect$1 === null) {
		/** @type {Derived} */ active_reaction.f |= ERROR_VALUE;
		return error;
	}
	if (dev_fallback_default && error instanceof Error && !adjustments.has(error)) adjustments.set(error, get_adjustments(error, effect$1));
	if ((effect$1.f & EFFECT_RAN) === 0) {
		if ((effect$1.f & BOUNDARY_EFFECT) === 0) {
			if (dev_fallback_default && !effect$1.parent && error instanceof Error) apply_adjustments(error);
			throw error;
		}
		/** @type {Boundary} */ effect$1.b.error(error);
	} else invoke_error_boundary(error, effect$1);
}
/**
* @param {unknown} error
* @param {Effect | null} effect
*/
function invoke_error_boundary(error, effect$1) {
	while (effect$1 !== null) {
		if ((effect$1.f & BOUNDARY_EFFECT) !== 0) try {
			/** @type {Boundary} */ effect$1.b.error(error);
			return;
		} catch (e) {
			error = e;
		}
		effect$1 = effect$1.parent;
	}
	if (dev_fallback_default && error instanceof Error) apply_adjustments(error);
	throw error;
}
/**
* Add useful information to the error message/stack in development
* @param {Error} error
* @param {Effect} effect
*/
function get_adjustments(error, effect$1) {
	const message_descriptor = get_descriptor(error, "message");
	if (message_descriptor && !message_descriptor.configurable) return;
	var indent = is_firefox ? "  " : "	";
	var component_stack = `\n${indent}in ${effect$1.fn?.name || "<unknown>"}`;
	var context = effect$1.ctx;
	while (context !== null) {
		component_stack += `\n${indent}in ${context.function?.[FILENAME].split("/").pop()}`;
		context = context.p;
	}
	return {
		message: error.message + `\n${component_stack}\n`,
		stack: error.stack?.split("\n").filter((line) => !line.includes("svelte/src/internal")).join("\n")
	};
}
/**
* @param {Error} error
*/
function apply_adjustments(error) {
	const adjusted = adjustments.get(error);
	if (adjusted) {
		define_property(error, "message", { value: adjusted.message });
		define_property(error, "stack", { value: adjusted.stack });
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/batch.js
/**
* @typedef {{
*   parent: EffectTarget | null;
*   effect: Effect | null;
*   effects: Effect[];
*   render_effects: Effect[];
*   block_effects: Effect[];
* }} EffectTarget
*/
/** @type {Set<Batch>} */
const batches = /* @__PURE__ */ new Set();
/** @type {Batch | null} */
let current_batch = null;
/**
* This is needed to avoid overwriting inputs in non-async mode
* TODO 6.0 remove this, as non-async mode will go away
* @type {Batch | null}
*/
let previous_batch = null;
/**
* When time travelling (i.e. working in one batch, while other batches
* still have ongoing work), we ignore the real values of affected
* signals in favour of their values within the batch
* @type {Map<Value, any> | null}
*/
let batch_values = null;
/** @type {Effect[]} */
let queued_root_effects = [];
/** @type {Effect | null} */
let last_scheduled_effect = null;
let is_flushing = false;
let is_flushing_sync = false;
var Batch = class Batch {
	committed = false;
	/**
	* The current values of any sources that are updated in this batch
	* They keys of this map are identical to `this.#previous`
	* @type {Map<Source, any>}
	*/
	current = /* @__PURE__ */ new Map();
	/**
	* The values of any sources that are updated in this batch _before_ those updates took place.
	* They keys of this map are identical to `this.#current`
	* @type {Map<Source, any>}
	*/
	previous = /* @__PURE__ */ new Map();
	/**
	* When the batch is committed (and the DOM is updated), we need to remove old branches
	* and append new ones by calling the functions added inside (if/each/key/etc) blocks
	* @type {Set<() => void>}
	*/
	#commit_callbacks = /* @__PURE__ */ new Set();
	/**
	* If a fork is discarded, we need to destroy any effects that are no longer needed
	* @type {Set<(batch: Batch) => void>}
	*/
	#discard_callbacks = /* @__PURE__ */ new Set();
	/**
	* The number of async effects that are currently in flight
	*/
	#pending = 0;
	/**
	* The number of async effects that are currently in flight, _not_ inside a pending boundary
	*/
	#blocking_pending = 0;
	/**
	* A deferred that resolves when the batch is committed, used with `settled()`
	* TODO replace with Promise.withResolvers once supported widely enough
	* @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
	*/
	#deferred = null;
	/**
	* Deferred effects (which run after async work has completed) that are DIRTY
	* @type {Effect[]}
	*/
	#dirty_effects = [];
	/**
	* Deferred effects that are MAYBE_DIRTY
	* @type {Effect[]}
	*/
	#maybe_dirty_effects = [];
	/**
	* A set of branches that still exist, but will be destroyed when this batch
	* is committed — we skip over these during `process`
	* @type {Set<Effect>}
	*/
	skipped_effects = /* @__PURE__ */ new Set();
	is_fork = false;
	is_deferred() {
		return this.is_fork || this.#blocking_pending > 0;
	}
	/**
	*
	* @param {Effect[]} root_effects
	*/
	process(root_effects) {
		queued_root_effects = [];
		previous_batch = null;
		this.apply();
		/** @type {EffectTarget} */
		var target = {
			parent: null,
			effect: null,
			effects: [],
			render_effects: [],
			block_effects: []
		};
		for (const root$2 of root_effects) this.#traverse_effect_tree(root$2, target);
		if (!this.is_fork) this.#resolve();
		if (this.is_deferred()) {
			this.#defer_effects(target.effects);
			this.#defer_effects(target.render_effects);
			this.#defer_effects(target.block_effects);
		} else {
			previous_batch = this;
			current_batch = null;
			flush_queued_effects(target.render_effects);
			flush_queued_effects(target.effects);
			previous_batch = null;
			this.#deferred?.resolve();
		}
		batch_values = null;
	}
	/**
	* Traverse the effect tree, executing effects or stashing
	* them for later execution as appropriate
	* @param {Effect} root
	* @param {EffectTarget} target
	*/
	#traverse_effect_tree(root$2, target) {
		root$2.f ^= CLEAN;
		var effect$1 = root$2.first;
		while (effect$1 !== null) {
			var flags$1 = effect$1.f;
			var is_branch = (flags$1 & (BRANCH_EFFECT | ROOT_EFFECT)) !== 0;
			var is_skippable_branch = is_branch && (flags$1 & CLEAN) !== 0;
			var skip = is_skippable_branch || (flags$1 & INERT) !== 0 || this.skipped_effects.has(effect$1);
			if ((effect$1.f & BOUNDARY_EFFECT) !== 0 && effect$1.b?.is_pending()) target = {
				parent: target,
				effect: effect$1,
				effects: [],
				render_effects: [],
				block_effects: []
			};
			if (!skip && effect$1.fn !== null) {
				if (is_branch) effect$1.f ^= CLEAN;
				else if ((flags$1 & EFFECT) !== 0) target.effects.push(effect$1);
				else if (async_mode_flag && (flags$1 & RENDER_EFFECT) !== 0) target.render_effects.push(effect$1);
				else if (is_dirty(effect$1)) {
					if ((effect$1.f & BLOCK_EFFECT) !== 0) target.block_effects.push(effect$1);
					update_effect(effect$1);
				}
				var child$1 = effect$1.first;
				if (child$1 !== null) {
					effect$1 = child$1;
					continue;
				}
			}
			var parent = effect$1.parent;
			effect$1 = effect$1.next;
			while (effect$1 === null && parent !== null) {
				if (parent === target.effect) {
					this.#defer_effects(target.effects);
					this.#defer_effects(target.render_effects);
					this.#defer_effects(target.block_effects);
					target = target.parent;
				}
				effect$1 = parent.next;
				parent = parent.parent;
			}
		}
	}
	/**
	* @param {Effect[]} effects
	*/
	#defer_effects(effects) {
		for (const e of effects) {
			const target = (e.f & DIRTY) !== 0 ? this.#dirty_effects : this.#maybe_dirty_effects;
			target.push(e);
			this.#clear_marked(e.deps);
			set_signal_status(e, CLEAN);
		}
	}
	/**
	* @param {Value[] | null} deps
	*/
	#clear_marked(deps) {
		if (deps === null) return;
		for (const dep of deps) {
			if ((dep.f & DERIVED) === 0 || (dep.f & WAS_MARKED) === 0) continue;
			dep.f ^= WAS_MARKED;
			this.#clear_marked(
				/** @type {Derived} */
				dep.deps
			);
		}
	}
	/**
	* Associate a change to a given source with the current
	* batch, noting its previous and current values
	* @param {Source} source
	* @param {any} value
	*/
	capture(source$1, value) {
		if (!this.previous.has(source$1)) this.previous.set(source$1, value);
		if ((source$1.f & ERROR_VALUE) === 0) {
			this.current.set(source$1, source$1.v);
			batch_values?.set(source$1, source$1.v);
		}
	}
	activate() {
		current_batch = this;
		this.apply();
	}
	deactivate() {
		if (current_batch !== this) return;
		current_batch = null;
		batch_values = null;
	}
	flush() {
		this.activate();
		if (queued_root_effects.length > 0) {
			flush_effects();
			if (current_batch !== null && current_batch !== this) return;
		} else if (this.#pending === 0) this.process([]);
		this.deactivate();
	}
	discard() {
		for (const fn of this.#discard_callbacks) fn(this);
		this.#discard_callbacks.clear();
	}
	#resolve() {
		if (this.#blocking_pending === 0) {
			for (const fn of this.#commit_callbacks) fn();
			this.#commit_callbacks.clear();
		}
		if (this.#pending === 0) this.#commit();
	}
	#commit() {
		if (batches.size > 1) {
			this.previous.clear();
			var previous_batch_values = batch_values;
			var is_earlier = true;
			/** @type {EffectTarget} */
			var dummy_target = {
				parent: null,
				effect: null,
				effects: [],
				render_effects: [],
				block_effects: []
			};
			for (const batch of batches) {
				if (batch === this) {
					is_earlier = false;
					continue;
				}
				/** @type {Source[]} */
				const sources = [];
				for (const [source$1, value] of this.current) {
					if (batch.current.has(source$1)) if (is_earlier && value !== batch.current.get(source$1)) batch.current.set(source$1, value);
					else continue;
					sources.push(source$1);
				}
				if (sources.length === 0) continue;
				const others = [...batch.current.keys()].filter((s) => !this.current.has(s));
				if (others.length > 0) {
					var prev_queued_root_effects = queued_root_effects;
					queued_root_effects = [];
					/** @type {Set<Value>} */
					const marked = /* @__PURE__ */ new Set();
					/** @type {Map<Reaction, boolean>} */
					const checked = /* @__PURE__ */ new Map();
					for (const source$1 of sources) mark_effects(source$1, others, marked, checked);
					if (queued_root_effects.length > 0) {
						current_batch = batch;
						batch.apply();
						for (const root$2 of queued_root_effects) batch.#traverse_effect_tree(root$2, dummy_target);
						batch.deactivate();
					}
					queued_root_effects = prev_queued_root_effects;
				}
			}
			current_batch = null;
			batch_values = previous_batch_values;
		}
		this.committed = true;
		batches.delete(this);
	}
	/**
	*
	* @param {boolean} blocking
	*/
	increment(blocking) {
		this.#pending += 1;
		if (blocking) this.#blocking_pending += 1;
	}
	/**
	*
	* @param {boolean} blocking
	*/
	decrement(blocking) {
		this.#pending -= 1;
		if (blocking) this.#blocking_pending -= 1;
		this.revive();
	}
	revive() {
		for (const e of this.#dirty_effects) {
			set_signal_status(e, DIRTY);
			schedule_effect(e);
		}
		for (const e of this.#maybe_dirty_effects) {
			set_signal_status(e, MAYBE_DIRTY);
			schedule_effect(e);
		}
		this.#dirty_effects = [];
		this.#maybe_dirty_effects = [];
		this.flush();
	}
	/** @param {() => void} fn */
	oncommit(fn) {
		this.#commit_callbacks.add(fn);
	}
	/** @param {(batch: Batch) => void} fn */
	ondiscard(fn) {
		this.#discard_callbacks.add(fn);
	}
	settled() {
		return (this.#deferred ??= deferred()).promise;
	}
	static ensure() {
		if (current_batch === null) {
			const batch = current_batch = new Batch();
			batches.add(current_batch);
			if (!is_flushing_sync) Batch.enqueue(() => {
				if (current_batch !== batch) return;
				batch.flush();
			});
		}
		return current_batch;
	}
	/** @param {() => void} task */
	static enqueue(task) {
		queue_micro_task(task);
	}
	apply() {
		if (!async_mode_flag || !this.is_fork && batches.size === 1) return;
		batch_values = new Map(this.current);
		for (const batch of batches) {
			if (batch === this) continue;
			for (const [source$1, previous] of batch.previous) if (!batch_values.has(source$1)) batch_values.set(source$1, previous);
		}
	}
};
/**
* Synchronously flush any pending updates.
* Returns void if no callback is provided, otherwise returns the result of calling the callback.
* @template [T=void]
* @param {(() => T) | undefined} [fn]
* @returns {T}
*/
function flushSync(fn) {
	if (async_mode_flag && active_effect !== null) flush_sync_in_effect();
	var was_flushing_sync = is_flushing_sync;
	is_flushing_sync = true;
	try {
		var result;
		if (fn) {
			if (current_batch !== null) flush_effects();
			result = fn();
		}
		while (true) {
			flush_tasks();
			if (queued_root_effects.length === 0) {
				current_batch?.flush();
				if (queued_root_effects.length === 0) {
					last_scheduled_effect = null;
					return result;
				}
			}
			flush_effects();
		}
	} finally {
		is_flushing_sync = was_flushing_sync;
	}
}
function flush_effects() {
	var was_updating_effect = is_updating_effect;
	is_flushing = true;
	var source_stacks = dev_fallback_default ? /* @__PURE__ */ new Set() : null;
	try {
		var flush_count = 0;
		set_is_updating_effect(true);
		while (queued_root_effects.length > 0) {
			var batch = Batch.ensure();
			if (flush_count++ > 1e3) {
				if (dev_fallback_default) {
					var updates = /* @__PURE__ */ new Map();
					for (const source$1 of batch.current.keys()) for (const [stack$1, update$1] of source$1.updated ?? []) {
						var entry = updates.get(stack$1);
						if (!entry) {
							entry = {
								error: update$1.error,
								count: 0
							};
							updates.set(stack$1, entry);
						}
						entry.count += update$1.count;
					}
					for (const update$1 of updates.values()) if (update$1.error) console.error(update$1.error);
				}
				infinite_loop_guard();
			}
			batch.process(queued_root_effects);
			old_values.clear();
			if (dev_fallback_default) for (const source$1 of batch.current.keys())
 /** @type {Set<Source>} */ source_stacks.add(source$1);
		}
	} finally {
		is_flushing = false;
		set_is_updating_effect(was_updating_effect);
		last_scheduled_effect = null;
		if (dev_fallback_default) for (const source$1 of source_stacks) source$1.updated = null;
	}
}
function infinite_loop_guard() {
	try {
		effect_update_depth_exceeded();
	} catch (error) {
		if (dev_fallback_default) define_property(error, "stack", { value: "" });
		invoke_error_boundary(error, last_scheduled_effect);
	}
}
/** @type {Set<Effect> | null} */
let eager_block_effects = null;
/**
* @param {Array<Effect>} effects
* @returns {void}
*/
function flush_queued_effects(effects) {
	var length = effects.length;
	if (length === 0) return;
	var i = 0;
	while (i < length) {
		var effect$1 = effects[i++];
		if ((effect$1.f & (DESTROYED | INERT)) === 0 && is_dirty(effect$1)) {
			eager_block_effects = /* @__PURE__ */ new Set();
			update_effect(effect$1);
			if (effect$1.deps === null && effect$1.first === null && effect$1.nodes_start === null) if (effect$1.teardown === null && effect$1.ac === null) unlink_effect(effect$1);
			else effect$1.fn = null;
			if (eager_block_effects?.size > 0) {
				old_values.clear();
				for (const e of eager_block_effects) {
					if ((e.f & (DESTROYED | INERT)) !== 0) continue;
					/** @type {Effect[]} */
					const ordered_effects = [e];
					let ancestor = e.parent;
					while (ancestor !== null) {
						if (eager_block_effects.has(ancestor)) {
							eager_block_effects.delete(ancestor);
							ordered_effects.push(ancestor);
						}
						ancestor = ancestor.parent;
					}
					for (let j = ordered_effects.length - 1; j >= 0; j--) {
						const e$1 = ordered_effects[j];
						if ((e$1.f & (DESTROYED | INERT)) !== 0) continue;
						update_effect(e$1);
					}
				}
				eager_block_effects.clear();
			}
		}
	}
	eager_block_effects = null;
}
/**
* This is similar to `mark_reactions`, but it only marks async/block effects
* depending on `value` and at least one of the other `sources`, so that
* these effects can re-run after another batch has been committed
* @param {Value} value
* @param {Source[]} sources
* @param {Set<Value>} marked
* @param {Map<Reaction, boolean>} checked
*/
function mark_effects(value, sources, marked, checked) {
	if (marked.has(value)) return;
	marked.add(value);
	if (value.reactions !== null) for (const reaction of value.reactions) {
		const flags$1 = reaction.f;
		if ((flags$1 & DERIVED) !== 0) mark_effects(reaction, sources, marked, checked);
		else if ((flags$1 & (ASYNC | BLOCK_EFFECT)) !== 0 && (flags$1 & DIRTY) === 0 && depends_on(reaction, sources, checked)) {
			set_signal_status(reaction, DIRTY);
			schedule_effect(reaction);
		}
	}
}
/**
* @param {Reaction} reaction
* @param {Source[]} sources
* @param {Map<Reaction, boolean>} checked
*/
function depends_on(reaction, sources, checked) {
	const depends = checked.get(reaction);
	if (depends !== void 0) return depends;
	if (reaction.deps !== null) for (const dep of reaction.deps) {
		if (sources.includes(dep)) return true;
		if ((dep.f & DERIVED) !== 0 && depends_on(dep, sources, checked)) {
			checked.set(dep, true);
			return true;
		}
	}
	checked.set(reaction, false);
	return false;
}
/**
* @param {Effect} signal
* @returns {void}
*/
function schedule_effect(signal) {
	var effect$1 = last_scheduled_effect = signal;
	while (effect$1.parent !== null) {
		effect$1 = effect$1.parent;
		var flags$1 = effect$1.f;
		if (is_flushing && effect$1 === active_effect && (flags$1 & BLOCK_EFFECT) !== 0 && (flags$1 & HEAD_EFFECT) === 0) return;
		if ((flags$1 & (ROOT_EFFECT | BRANCH_EFFECT)) !== 0) {
			if ((flags$1 & CLEAN) === 0) return;
			effect$1.f ^= CLEAN;
		}
	}
	queued_root_effects.push(effect$1);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/reactivity/create-subscriber.js
/**
* Returns a `subscribe` function that integrates external event-based systems with Svelte's reactivity.
* It's particularly useful for integrating with web APIs like `MediaQuery`, `IntersectionObserver`, or `WebSocket`.
*
* If `subscribe` is called inside an effect (including indirectly, for example inside a getter),
* the `start` callback will be called with an `update` function. Whenever `update` is called, the effect re-runs.
*
* If `start` returns a cleanup function, it will be called when the effect is destroyed.
*
* If `subscribe` is called in multiple effects, `start` will only be called once as long as the effects
* are active, and the returned teardown function will only be called when all effects are destroyed.
*
* It's best understood with an example. Here's an implementation of [`MediaQuery`](https://svelte.dev/docs/svelte/svelte-reactivity#MediaQuery):
*
* ```js
* import { createSubscriber } from 'svelte/reactivity';
* import { on } from 'svelte/events';
*
* export class MediaQuery {
* 	#query;
* 	#subscribe;
*
* 	constructor(query) {
* 		this.#query = window.matchMedia(`(${query})`);
*
* 		this.#subscribe = createSubscriber((update) => {
* 			// when the `change` event occurs, re-run any effects that read `this.current`
* 			const off = on(this.#query, 'change', update);
*
* 			// stop listening when all the effects are destroyed
* 			return () => off();
* 		});
* 	}
*
* 	get current() {
* 		// This makes the getter reactive, if read in an effect
* 		this.#subscribe();
*
* 		// Return the current state of the query, whether or not we're in an effect
* 		return this.#query.matches;
* 	}
* }
* ```
* @param {(update: () => void) => (() => void) | void} start
* @since 5.7.0
*/
function createSubscriber(start) {
	let subscribers = 0;
	let version = source(0);
	/** @type {(() => void) | void} */
	let stop;
	if (dev_fallback_default) tag(version, "createSubscriber version");
	return () => {
		if (effect_tracking()) {
			get(version);
			render_effect(() => {
				if (subscribers === 0) stop = untrack(() => start(() => increment(version)));
				subscribers += 1;
				return () => {
					queue_micro_task(() => {
						subscribers -= 1;
						if (subscribers === 0) {
							stop?.();
							stop = void 0;
							increment(version);
						}
					});
				};
			});
		}
	};
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/blocks/boundary.js
/**
* @typedef {{
* 	 onerror?: (error: unknown, reset: () => void) => void;
*   failed?: (anchor: Node, error: () => unknown, reset: () => () => void) => void;
*   pending?: (anchor: Node) => void;
* }} BoundaryProps
*/
var flags = EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT;
/**
* @param {TemplateNode} node
* @param {BoundaryProps} props
* @param {((anchor: Node) => void)} children
* @returns {void}
*/
function boundary(node, props, children) {
	new Boundary(node, props, children);
}
var Boundary = class {
	/** @type {Boundary | null} */
	parent;
	#pending = false;
	/** @type {TemplateNode} */
	#anchor;
	/** @type {TemplateNode | null} */
	#hydrate_open = hydrating ? hydrate_node : null;
	/** @type {BoundaryProps} */
	#props;
	/** @type {((anchor: Node) => void)} */
	#children;
	/** @type {Effect} */
	#effect;
	/** @type {Effect | null} */
	#main_effect = null;
	/** @type {Effect | null} */
	#pending_effect = null;
	/** @type {Effect | null} */
	#failed_effect = null;
	/** @type {DocumentFragment | null} */
	#offscreen_fragment = null;
	/** @type {TemplateNode | null} */
	#pending_anchor = null;
	#local_pending_count = 0;
	#pending_count = 0;
	#is_creating_fallback = false;
	/**
	* A source containing the number of pending async deriveds/expressions.
	* Only created if `$effect.pending()` is used inside the boundary,
	* otherwise updating the source results in needless `Batch.ensure()`
	* calls followed by no-op flushes
	* @type {Source<number> | null}
	*/
	#effect_pending = null;
	#effect_pending_subscriber = createSubscriber(() => {
		this.#effect_pending = source(this.#local_pending_count);
		if (dev_fallback_default) tag(this.#effect_pending, "$effect.pending()");
		return () => {
			this.#effect_pending = null;
		};
	});
	/**
	* @param {TemplateNode} node
	* @param {BoundaryProps} props
	* @param {((anchor: Node) => void)} children
	*/
	constructor(node, props, children) {
		this.#anchor = node;
		this.#props = props;
		this.#children = children;
		this.parent = active_effect.b;
		this.#pending = !!this.#props.pending;
		this.#effect = block(() => {
			/** @type {Effect} */ active_effect.b = this;
			if (hydrating) {
				const comment$1 = this.#hydrate_open;
				hydrate_next();
				const server_rendered_pending = comment$1.nodeType === COMMENT_NODE && comment$1.data === HYDRATION_START_ELSE;
				if (server_rendered_pending) this.#hydrate_pending_content();
				else this.#hydrate_resolved_content();
			} else {
				var anchor = this.#get_anchor();
				try {
					this.#main_effect = branch(() => children(anchor));
				} catch (error) {
					this.error(error);
				}
				if (this.#pending_count > 0) this.#show_pending_snippet();
				else this.#pending = false;
			}
			return () => {
				this.#pending_anchor?.remove();
			};
		}, flags);
		if (hydrating) this.#anchor = hydrate_node;
	}
	#hydrate_resolved_content() {
		try {
			this.#main_effect = branch(() => this.#children(this.#anchor));
		} catch (error) {
			this.error(error);
		}
		this.#pending = false;
	}
	#hydrate_pending_content() {
		const pending = this.#props.pending;
		if (!pending) return;
		this.#pending_effect = branch(() => pending(this.#anchor));
		Batch.enqueue(() => {
			var anchor = this.#get_anchor();
			this.#main_effect = this.#run(() => {
				Batch.ensure();
				return branch(() => this.#children(anchor));
			});
			if (this.#pending_count > 0) this.#show_pending_snippet();
			else {
				pause_effect(this.#pending_effect, () => {
					this.#pending_effect = null;
				});
				this.#pending = false;
			}
		});
	}
	#get_anchor() {
		var anchor = this.#anchor;
		if (this.#pending) {
			this.#pending_anchor = create_text();
			this.#anchor.before(this.#pending_anchor);
			anchor = this.#pending_anchor;
		}
		return anchor;
	}
	/**
	* Returns `true` if the effect exists inside a boundary whose pending snippet is shown
	* @returns {boolean}
	*/
	is_pending() {
		return this.#pending || !!this.parent && this.parent.is_pending();
	}
	has_pending_snippet() {
		return !!this.#props.pending;
	}
	/**
	* @param {() => Effect | null} fn
	*/
	#run(fn) {
		var previous_effect = active_effect;
		var previous_reaction = active_reaction;
		var previous_ctx = component_context;
		set_active_effect(this.#effect);
		set_active_reaction(this.#effect);
		set_component_context(this.#effect.ctx);
		try {
			return fn();
		} catch (e) {
			handle_error(e);
			return null;
		} finally {
			set_active_effect(previous_effect);
			set_active_reaction(previous_reaction);
			set_component_context(previous_ctx);
		}
	}
	#show_pending_snippet() {
		const pending = this.#props.pending;
		if (this.#main_effect !== null) {
			this.#offscreen_fragment = document.createDocumentFragment();
			this.#offscreen_fragment.append(this.#pending_anchor);
			move_effect(this.#main_effect, this.#offscreen_fragment);
		}
		if (this.#pending_effect === null) this.#pending_effect = branch(() => pending(this.#anchor));
	}
	/**
	* Updates the pending count associated with the currently visible pending snippet,
	* if any, such that we can replace the snippet with content once work is done
	* @param {1 | -1} d
	*/
	#update_pending_count(d) {
		if (!this.has_pending_snippet()) {
			if (this.parent) this.parent.#update_pending_count(d);
			return;
		}
		this.#pending_count += d;
		if (this.#pending_count === 0) {
			this.#pending = false;
			if (this.#pending_effect) pause_effect(this.#pending_effect, () => {
				this.#pending_effect = null;
			});
			if (this.#offscreen_fragment) {
				this.#anchor.before(this.#offscreen_fragment);
				this.#offscreen_fragment = null;
			}
		}
	}
	/**
	* Update the source that powers `$effect.pending()` inside this boundary,
	* and controls when the current `pending` snippet (if any) is removed.
	* Do not call from inside the class
	* @param {1 | -1} d
	*/
	update_pending_count(d) {
		this.#update_pending_count(d);
		this.#local_pending_count += d;
		if (this.#effect_pending) internal_set(this.#effect_pending, this.#local_pending_count);
	}
	get_effect_pending() {
		this.#effect_pending_subscriber();
		return get(this.#effect_pending);
	}
	/** @param {unknown} error */
	error(error) {
		var onerror = this.#props.onerror;
		let failed = this.#props.failed;
		if (this.#is_creating_fallback || !onerror && !failed) throw error;
		if (this.#main_effect) {
			destroy_effect(this.#main_effect);
			this.#main_effect = null;
		}
		if (this.#pending_effect) {
			destroy_effect(this.#pending_effect);
			this.#pending_effect = null;
		}
		if (this.#failed_effect) {
			destroy_effect(this.#failed_effect);
			this.#failed_effect = null;
		}
		if (hydrating) {
			set_hydrate_node(this.#hydrate_open);
			next();
			set_hydrate_node(skip_nodes());
		}
		var did_reset = false;
		var calling_on_error = false;
		const reset$1 = () => {
			if (did_reset) {
				svelte_boundary_reset_noop();
				return;
			}
			did_reset = true;
			if (calling_on_error) svelte_boundary_reset_onerror();
			Batch.ensure();
			this.#local_pending_count = 0;
			if (this.#failed_effect !== null) pause_effect(this.#failed_effect, () => {
				this.#failed_effect = null;
			});
			this.#pending = this.has_pending_snippet();
			this.#main_effect = this.#run(() => {
				this.#is_creating_fallback = false;
				return branch(() => this.#children(this.#anchor));
			});
			if (this.#pending_count > 0) this.#show_pending_snippet();
			else this.#pending = false;
		};
		var previous_reaction = active_reaction;
		try {
			set_active_reaction(null);
			calling_on_error = true;
			onerror?.(error, reset$1);
			calling_on_error = false;
		} catch (error$1) {
			invoke_error_boundary(error$1, this.#effect && this.#effect.parent);
		} finally {
			set_active_reaction(previous_reaction);
		}
		if (failed) queue_micro_task(() => {
			this.#failed_effect = this.#run(() => {
				Batch.ensure();
				this.#is_creating_fallback = true;
				try {
					return branch(() => {
						failed(this.#anchor, () => error, () => reset$1);
					});
				} catch (error$1) {
					invoke_error_boundary(error$1, this.#effect.parent);
					return null;
				} finally {
					this.#is_creating_fallback = false;
				}
			});
		});
	}
};

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/blocks/each.js
/**
* The row of a keyed each block that is currently updating. We track this
* so that `animate:` directives have something to attach themselves to
* @type {EachItem | null}
*/
let current_each_item = null;
/**
* @param {any} _
* @param {number} i
*/
function index(_, i) {
	return i;
}
/**
* Pause multiple effects simultaneously, and coordinate their
* subsequent destruction. Used in each blocks
* @param {EachState} state
* @param {EachItem[]} to_destroy
* @param {null | Node} controlled_anchor
*/
function pause_effects(state$1, to_destroy, controlled_anchor) {
	/** @type {TransitionManager[]} */
	var transitions = [];
	var length = to_destroy.length;
	for (var i = 0; i < length; i++) pause_children(to_destroy[i].e, transitions, true);
	run_out_transitions(transitions, () => {
		var fast_path = transitions.length === 0 && controlled_anchor !== null;
		if (fast_path) {
			var anchor = controlled_anchor;
			var parent_node = anchor.parentNode;
			clear_text_content(parent_node);
			parent_node.append(anchor);
			state$1.items.clear();
			link(state$1, to_destroy[0].prev, to_destroy[length - 1].next);
		}
		for (var i$1 = 0; i$1 < length; i$1++) {
			var item = to_destroy[i$1];
			if (!fast_path) {
				state$1.items.delete(item.k);
				link(state$1, item.prev, item.next);
			}
			destroy_effect(item.e, !fast_path);
		}
		if (state$1.first === to_destroy[0]) state$1.first = to_destroy[0].prev;
	});
}
/**
* @template V
* @param {Element | Comment} node The next sibling node, or the parent node if this is a 'controlled' block
* @param {number} flags
* @param {() => V[]} get_collection
* @param {(value: V, index: number) => any} get_key
* @param {(anchor: Node, item: MaybeSource<V>, index: MaybeSource<number>) => void} render_fn
* @param {null | ((anchor: Node) => void)} fallback_fn
* @returns {void}
*/
function each(node, flags$1, get_collection, get_key, render_fn, fallback_fn = null) {
	var anchor = node;
	/** @type {Map<any, EachItem>} */
	var items = /* @__PURE__ */ new Map();
	/** @type {EachItem | null} */
	var first = null;
	var is_controlled = (flags$1 & EACH_IS_CONTROLLED) !== 0;
	var is_reactive_value = (flags$1 & EACH_ITEM_REACTIVE) !== 0;
	var is_reactive_index = (flags$1 & EACH_INDEX_REACTIVE) !== 0;
	if (is_controlled) {
		var parent_node = node;
		anchor = hydrating ? set_hydrate_node(get_first_child(parent_node)) : parent_node.appendChild(create_text());
	}
	if (hydrating) hydrate_next();
	/** @type {{ fragment: DocumentFragment | null, effect: Effect } | null} */
	var fallback = null;
	var each_array = derived_safe_equal(() => {
		var collection = get_collection();
		return is_array(collection) ? collection : collection == null ? [] : array_from(collection);
	});
	/** @type {V[]} */
	var array;
	var first_run = true;
	function commit() {
		reconcile(state$1, array, anchor, flags$1, get_key);
		if (fallback !== null) if (array.length === 0) {
			if (fallback.fragment) {
				anchor.before(fallback.fragment);
				fallback.fragment = null;
			} else resume_effect(fallback.effect);
			effect$1.first = fallback.effect;
		} else pause_effect(fallback.effect, () => {
			fallback = null;
		});
	}
	var effect$1 = block(() => {
		array = get(each_array);
		var length = array.length;
		/** `true` if there was a hydration mismatch. Needs to be a `let` or else it isn't treeshaken out */
		let mismatch = false;
		if (hydrating) {
			var is_else = read_hydration_instruction(anchor) === HYDRATION_START_ELSE;
			if (is_else !== (length === 0)) {
				anchor = skip_nodes();
				set_hydrate_node(anchor);
				set_hydrating(false);
				mismatch = true;
			}
		}
		var keys = /* @__PURE__ */ new Set();
		var batch = current_batch;
		var prev = null;
		var defer = should_defer_append();
		for (var i = 0; i < length; i += 1) {
			if (hydrating && hydrate_node.nodeType === COMMENT_NODE && hydrate_node.data === HYDRATION_END) {
				anchor = hydrate_node;
				mismatch = true;
				set_hydrating(false);
			}
			var value = array[i];
			var key = get_key(value, i);
			var item = first_run ? null : items.get(key);
			if (item) {
				if (is_reactive_value) internal_set(item.v, value);
				if (is_reactive_index) internal_set(item.i, i);
				else item.i = i;
				if (defer) batch.skipped_effects.delete(item.e);
			} else {
				item = create_item(first_run ? anchor : null, prev, value, key, i, render_fn, flags$1, get_collection);
				if (first_run) {
					item.o = true;
					if (prev === null) first = item;
					else prev.next = item;
					prev = item;
				}
				items.set(key, item);
			}
			keys.add(key);
		}
		if (length === 0 && fallback_fn && !fallback) if (first_run) fallback = {
			fragment: null,
			effect: branch(() => fallback_fn(anchor))
		};
		else {
			var fragment = document.createDocumentFragment();
			var target = create_text();
			fragment.append(target);
			fallback = {
				fragment,
				effect: branch(() => fallback_fn(target))
			};
		}
		if (hydrating && length > 0) set_hydrate_node(skip_nodes());
		if (!first_run) if (defer) {
			for (const [key$1, item$1] of items) if (!keys.has(key$1)) batch.skipped_effects.add(item$1.e);
			batch.oncommit(commit);
			batch.ondiscard(() => {});
		} else commit();
		if (mismatch) set_hydrating(true);
		get(each_array);
	});
	/** @type {EachState} */
	var state$1 = {
		effect: effect$1,
		flags: flags$1,
		items,
		first
	};
	first_run = false;
	if (hydrating) anchor = hydrate_node;
}
/**
* Add, remove, or reorder items output by an each block as its input changes
* @template V
* @param {EachState} state
* @param {Array<V>} array
* @param {Element | Comment | Text} anchor
* @param {number} flags
* @param {(value: V, index: number) => any} get_key
* @returns {void}
*/
function reconcile(state$1, array, anchor, flags$1, get_key) {
	var is_animated = (flags$1 & EACH_IS_ANIMATED) !== 0;
	var length = array.length;
	var items = state$1.items;
	var current = state$1.first;
	/** @type {undefined | Set<EachItem>} */
	var seen;
	/** @type {EachItem | null} */
	var prev = null;
	/** @type {undefined | Set<EachItem>} */
	var to_animate;
	/** @type {EachItem[]} */
	var matched = [];
	/** @type {EachItem[]} */
	var stashed = [];
	/** @type {V} */
	var value;
	/** @type {any} */
	var key;
	/** @type {EachItem | undefined} */
	var item;
	/** @type {number} */
	var i;
	if (is_animated) for (i = 0; i < length; i += 1) {
		value = array[i];
		key = get_key(value, i);
		item = items.get(key);
		item.a?.measure();
		(to_animate ??= /* @__PURE__ */ new Set()).add(item);
	}
	for (i = 0; i < length; i += 1) {
		value = array[i];
		key = get_key(value, i);
		item = items.get(key);
		state$1.first ??= item;
		if (!item.o) {
			item.o = true;
			var next$1 = prev ? prev.next : current;
			link(state$1, prev, item);
			link(state$1, item, next$1);
			move(item, next$1, anchor);
			prev = item;
			matched = [];
			stashed = [];
			current = prev.next;
			continue;
		}
		if ((item.e.f & INERT) !== 0) {
			resume_effect(item.e);
			if (is_animated) {
				item.a?.unfix();
				(to_animate ??= /* @__PURE__ */ new Set()).delete(item);
			}
		}
		if (item !== current) {
			if (seen !== void 0 && seen.has(item)) {
				if (matched.length < stashed.length) {
					var start = stashed[0];
					var j;
					prev = start.prev;
					var a = matched[0];
					var b = matched[matched.length - 1];
					for (j = 0; j < matched.length; j += 1) move(matched[j], start, anchor);
					for (j = 0; j < stashed.length; j += 1) seen.delete(stashed[j]);
					link(state$1, a.prev, b.next);
					link(state$1, prev, a);
					link(state$1, b, start);
					current = start;
					prev = b;
					i -= 1;
					matched = [];
					stashed = [];
				} else {
					seen.delete(item);
					move(item, current, anchor);
					link(state$1, item.prev, item.next);
					link(state$1, item, prev === null ? state$1.first : prev.next);
					link(state$1, prev, item);
					prev = item;
				}
				continue;
			}
			matched = [];
			stashed = [];
			while (current !== null && current.k !== key) {
				if ((current.e.f & INERT) === 0) (seen ??= /* @__PURE__ */ new Set()).add(current);
				stashed.push(current);
				current = current.next;
			}
			if (current === null) continue;
			item = current;
		}
		matched.push(item);
		prev = item;
		current = item.next;
	}
	if (current !== null || seen !== void 0) {
		var to_destroy = seen === void 0 ? [] : array_from(seen);
		while (current !== null) {
			if ((current.e.f & INERT) === 0) to_destroy.push(current);
			current = current.next;
		}
		var destroy_length = to_destroy.length;
		if (destroy_length > 0) {
			var controlled_anchor = (flags$1 & EACH_IS_CONTROLLED) !== 0 && length === 0 ? anchor : null;
			if (is_animated) {
				for (i = 0; i < destroy_length; i += 1) to_destroy[i].a?.measure();
				for (i = 0; i < destroy_length; i += 1) to_destroy[i].a?.fix();
			}
			pause_effects(state$1, to_destroy, controlled_anchor);
		}
	}
	if (is_animated) queue_micro_task(() => {
		if (to_animate === void 0) return;
		for (item of to_animate) item.a?.apply();
	});
}
/**
* @template V
* @param {Node | null} anchor
* @param {EachItem | null} prev
* @param {V} value
* @param {unknown} key
* @param {number} index
* @param {(anchor: Node, item: V | Source<V>, index: number | Value<number>, collection: () => V[]) => void} render_fn
* @param {number} flags
* @param {() => V[]} get_collection
* @returns {EachItem}
*/
function create_item(anchor, prev, value, key, index$1, render_fn, flags$1, get_collection) {
	var previous_each_item = current_each_item;
	var reactive = (flags$1 & EACH_ITEM_REACTIVE) !== 0;
	var mutable = (flags$1 & EACH_ITEM_IMMUTABLE) === 0;
	var v = reactive ? mutable ? mutable_source(value, false, false) : source(value) : value;
	var i = (flags$1 & EACH_INDEX_REACTIVE) === 0 ? index$1 : source(index$1);
	if (dev_fallback_default && reactive)
 /** @type {Value} */ v.trace = () => {
		var collection_index = typeof i === "number" ? index$1 : i.v;
		get_collection()[collection_index];
	};
	/** @type {EachItem} */
	var item = {
		i,
		v,
		k: key,
		a: null,
		e: null,
		o: false,
		prev,
		next: null
	};
	current_each_item = item;
	try {
		if (anchor === null) {
			var fragment = document.createDocumentFragment();
			fragment.append(anchor = create_text());
		}
		item.e = branch(() => render_fn(anchor, v, i, get_collection));
		if (prev !== null) prev.next = item;
		return item;
	} finally {
		current_each_item = previous_each_item;
	}
}
/**
* @param {EachItem} item
* @param {EachItem | null} next
* @param {Text | Element | Comment} anchor
*/
function move(item, next$1, anchor) {
	var end = item.next ? item.next.e.nodes_start : anchor;
	var dest = next$1 ? next$1.e.nodes_start : anchor;
	var node = item.e.nodes_start;
	while (node !== null && node !== end) {
		var next_node = get_next_sibling(node);
		dest.before(node);
		node = next_node;
	}
}
/**
* @param {EachState} state
* @param {EachItem | null} prev
* @param {EachItem | null} next
*/
function link(state$1, prev, next$1) {
	if (prev === null) {
		state$1.first = next$1;
		state$1.effect.first = next$1 && next$1.e;
	} else {
		if (prev.e.next) prev.e.next.prev = null;
		prev.next = next$1;
		prev.e.next = next$1 && next$1.e;
	}
	if (next$1 === null) state$1.effect.last = prev && prev.e;
	else {
		if (next$1.e.prev) next$1.e.prev.next = null;
		next$1.prev = prev;
		next$1.e.prev = prev && prev.e;
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/async.js
/**
* @param {Array<Promise<void>>} blockers
* @param {Array<() => any>} sync
* @param {Array<() => Promise<any>>} async
* @param {(values: Value[]) => any} fn
*/
function flatten(blockers, sync, async, fn) {
	const d = is_runes() ? derived : derived_safe_equal;
	if (async.length === 0 && blockers.length === 0) {
		fn(sync.map(d));
		return;
	}
	var batch = current_batch;
	var parent = active_effect;
	var restore = capture();
	function run() {
		Promise.all(async.map((expression) => async_derived(expression))).then((result) => {
			restore();
			try {
				fn([...sync.map(d), ...result]);
			} catch (error) {
				if ((parent.f & DESTROYED) === 0) invoke_error_boundary(error, parent);
			}
			batch?.deactivate();
			unset_context();
		}).catch((error) => {
			invoke_error_boundary(error, parent);
		});
	}
	if (blockers.length > 0) Promise.all(blockers).then(() => {
		restore();
		try {
			return run();
		} finally {
			batch?.deactivate();
			unset_context();
		}
	});
	else run();
}
/**
* Captures the current effect context so that we can restore it after
* some asynchronous work has happened (so that e.g. `await a + b`
* causes `b` to be registered as a dependency).
*/
function capture() {
	var previous_effect = active_effect;
	var previous_reaction = active_reaction;
	var previous_component_context = component_context;
	var previous_batch$1 = current_batch;
	if (dev_fallback_default) var previous_dev_stack = dev_stack;
	return function restore(activate_batch = true) {
		set_active_effect(previous_effect);
		set_active_reaction(previous_reaction);
		set_component_context(previous_component_context);
		if (activate_batch) previous_batch$1?.activate();
		if (dev_fallback_default) {
			set_from_async_derived(null);
			set_dev_stack(previous_dev_stack);
		}
	};
}
function unset_context() {
	set_active_effect(null);
	set_active_reaction(null);
	set_component_context(null);
	if (dev_fallback_default) {
		set_from_async_derived(null);
		set_dev_stack(null);
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/deriveds.js
/** @type {Effect | null} */
let current_async_effect = null;
/** @param {Effect | null} v */
function set_from_async_derived(v) {
	current_async_effect = v;
}
const recent_async_deriveds = /* @__PURE__ */ new Set();
/**
* @template V
* @param {() => V} fn
* @returns {Derived<V>}
*/
/* @__NO_SIDE_EFFECTS__ */
function derived(fn) {
	var flags$1 = DERIVED | DIRTY;
	var parent_derived = active_reaction !== null && (active_reaction.f & DERIVED) !== 0 ? active_reaction : null;
	if (active_effect !== null) active_effect.f |= EFFECT_PRESERVED;
	/** @type {Derived<V>} */
	const signal = {
		ctx: component_context,
		deps: null,
		effects: null,
		equals,
		f: flags$1,
		fn,
		reactions: null,
		rv: 0,
		v: UNINITIALIZED,
		wv: 0,
		parent: parent_derived ?? active_effect,
		ac: null
	};
	if (dev_fallback_default && tracing_mode_flag) signal.created = get_stack("created at");
	return signal;
}
/**
* @template V
* @param {() => V | Promise<V>} fn
* @param {string} [location] If provided, print a warning if the value is not read immediately after update
* @returns {Promise<Source<V>>}
*/
/* @__NO_SIDE_EFFECTS__ */
function async_derived(fn, location) {
	let parent = active_effect;
	if (parent === null) async_derived_orphan();
	var boundary$1 = parent.b;
	var promise = void 0;
	var signal = source(UNINITIALIZED);
	var should_suspend = !active_reaction;
	/** @type {Map<Batch, ReturnType<typeof deferred<V>>>} */
	var deferreds = /* @__PURE__ */ new Map();
	async_effect(() => {
		if (dev_fallback_default) current_async_effect = active_effect;
		/** @type {ReturnType<typeof deferred<V>>} */
		var d = deferred();
		promise = d.promise;
		try {
			Promise.resolve(fn()).then(d.resolve, d.reject).then(() => {
				if (batch === current_batch && batch.committed) batch.deactivate();
				unset_context();
			});
		} catch (error) {
			d.reject(error);
			unset_context();
		}
		if (dev_fallback_default) current_async_effect = null;
		var batch = current_batch;
		if (should_suspend) {
			var blocking = !boundary$1.is_pending();
			boundary$1.update_pending_count(1);
			batch.increment(blocking);
			deferreds.get(batch)?.reject(STALE_REACTION);
			deferreds.delete(batch);
			deferreds.set(batch, d);
		}
		/**
		* @param {any} value
		* @param {unknown} error
		*/
		const handler = (value, error = void 0) => {
			current_async_effect = null;
			batch.activate();
			if (error) {
				if (error !== STALE_REACTION) {
					signal.f |= ERROR_VALUE;
					internal_set(signal, error);
				}
			} else {
				if ((signal.f & ERROR_VALUE) !== 0) signal.f ^= ERROR_VALUE;
				internal_set(signal, value);
				for (const [b, d$1] of deferreds) {
					deferreds.delete(b);
					if (b === batch) break;
					d$1.reject(STALE_REACTION);
				}
				if (dev_fallback_default && location !== void 0) {
					recent_async_deriveds.add(signal);
					setTimeout(() => {
						if (recent_async_deriveds.has(signal)) {
							await_waterfall(signal.label, location);
							recent_async_deriveds.delete(signal);
						}
					});
				}
			}
			if (should_suspend) {
				boundary$1.update_pending_count(-1);
				batch.decrement(blocking);
			}
		};
		d.promise.then(handler, (e) => handler(null, e || "unknown"));
	});
	teardown(() => {
		for (const d of deferreds.values()) d.reject(STALE_REACTION);
	});
	if (dev_fallback_default) signal.f |= ASYNC;
	return new Promise((fulfil) => {
		/** @param {Promise<V>} p */
		function next$1(p) {
			function go() {
				if (p === promise) fulfil(signal);
				else next$1(promise);
			}
			p.then(go, go);
		}
		next$1(promise);
	});
}
/**
* @template V
* @param {() => V} fn
* @returns {Derived<V>}
*/
/* @__NO_SIDE_EFFECTS__ */
function user_derived(fn) {
	const d = /* @__PURE__ */ derived(fn);
	if (!async_mode_flag) push_reaction_value(d);
	return d;
}
/**
* @template V
* @param {() => V} fn
* @returns {Derived<V>}
*/
/* @__NO_SIDE_EFFECTS__ */
function derived_safe_equal(fn) {
	const signal = /* @__PURE__ */ derived(fn);
	signal.equals = safe_equals;
	return signal;
}
/**
* @param {Derived} derived
* @returns {void}
*/
function destroy_derived_effects(derived$1) {
	var effects = derived$1.effects;
	if (effects !== null) {
		derived$1.effects = null;
		for (var i = 0; i < effects.length; i += 1) destroy_effect(effects[i]);
	}
}
/**
* The currently updating deriveds, used to detect infinite recursion
* in dev mode and provide a nicer error than 'too much recursion'
* @type {Derived[]}
*/
let stack = [];
/**
* @param {Derived} derived
* @returns {Effect | null}
*/
function get_derived_parent_effect(derived$1) {
	var parent = derived$1.parent;
	while (parent !== null) {
		if ((parent.f & DERIVED) === 0) return (parent.f & DESTROYED) === 0 ? parent : null;
		parent = parent.parent;
	}
	return null;
}
/**
* @template T
* @param {Derived} derived
* @returns {T}
*/
function execute_derived(derived$1) {
	var value;
	var prev_active_effect = active_effect;
	set_active_effect(get_derived_parent_effect(derived$1));
	if (dev_fallback_default) {
		let prev_eager_effects = eager_effects;
		set_eager_effects(/* @__PURE__ */ new Set());
		try {
			if (stack.includes(derived$1)) derived_references_self();
			stack.push(derived$1);
			derived$1.f &= ~WAS_MARKED;
			destroy_derived_effects(derived$1);
			value = update_reaction(derived$1);
		} finally {
			set_active_effect(prev_active_effect);
			set_eager_effects(prev_eager_effects);
			stack.pop();
		}
	} else try {
		derived$1.f &= ~WAS_MARKED;
		destroy_derived_effects(derived$1);
		value = update_reaction(derived$1);
	} finally {
		set_active_effect(prev_active_effect);
	}
	return value;
}
/**
* @param {Derived} derived
* @returns {void}
*/
function update_derived(derived$1) {
	var value = execute_derived(derived$1);
	if (!derived$1.equals(value)) {
		if (!current_batch?.is_fork) derived$1.v = value;
		derived$1.wv = increment_write_version();
	}
	if (is_destroying_effect) return;
	if (batch_values !== null) {
		if (effect_tracking()) batch_values.set(derived$1, value);
	} else {
		var status = (derived$1.f & CONNECTED) === 0 ? MAYBE_DIRTY : CLEAN;
		set_signal_status(derived$1, status);
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/sources.js
/** @type {Set<any>} */
let eager_effects = /* @__PURE__ */ new Set();
/** @type {Map<Source, any>} */
const old_values = /* @__PURE__ */ new Map();
/**
* @param {Set<any>} v
*/
function set_eager_effects(v) {
	eager_effects = v;
}
let eager_effects_deferred = false;
function set_eager_effects_deferred() {
	eager_effects_deferred = true;
}
/**
* @template V
* @param {V} v
* @param {Error | null} [stack]
* @returns {Source<V>}
*/
function source(v, stack$1) {
	/** @type {Value} */
	var signal = {
		f: 0,
		v,
		reactions: null,
		equals,
		rv: 0,
		wv: 0
	};
	if (dev_fallback_default && tracing_mode_flag) {
		signal.created = stack$1 ?? get_stack("created at");
		signal.updated = null;
		signal.set_during_effect = false;
		signal.trace = null;
	}
	return signal;
}
/**
* @template V
* @param {V} v
* @param {Error | null} [stack]
*/
/* @__NO_SIDE_EFFECTS__ */
function state(v, stack$1) {
	const s = source(v, stack$1);
	push_reaction_value(s);
	return s;
}
/**
* @template V
* @param {V} initial_value
* @param {boolean} [immutable]
* @returns {Source<V>}
*/
/* @__NO_SIDE_EFFECTS__ */
function mutable_source(initial_value, immutable = false, trackable = true) {
	const s = source(initial_value);
	if (!immutable) s.equals = safe_equals;
	if (legacy_mode_flag && trackable && component_context !== null && component_context.l !== null) (component_context.l.s ??= []).push(s);
	return s;
}
/**
* @template V
* @param {Source<V>} source
* @param {V} value
* @param {boolean} [should_proxy]
* @returns {V}
*/
function set(source$1, value, should_proxy = false) {
	if (active_reaction !== null && (!untracking || (active_reaction.f & EAGER_EFFECT) !== 0) && is_runes() && (active_reaction.f & (DERIVED | BLOCK_EFFECT | ASYNC | EAGER_EFFECT)) !== 0 && !current_sources?.includes(source$1)) state_unsafe_mutation();
	let new_value = should_proxy ? proxy(value) : value;
	if (dev_fallback_default) tag_proxy(new_value, source$1.label);
	return internal_set(source$1, new_value);
}
/**
* @template V
* @param {Source<V>} source
* @param {V} value
* @returns {V}
*/
function internal_set(source$1, value) {
	if (!source$1.equals(value)) {
		var old_value = source$1.v;
		if (is_destroying_effect) old_values.set(source$1, value);
		else old_values.set(source$1, old_value);
		source$1.v = value;
		var batch = Batch.ensure();
		batch.capture(source$1, old_value);
		if (dev_fallback_default) {
			if (tracing_mode_flag || active_effect !== null) {
				source$1.updated ??= /* @__PURE__ */ new Map();
				const count = (source$1.updated.get("")?.count ?? 0) + 1;
				source$1.updated.set("", {
					error: null,
					count
				});
				if (tracing_mode_flag || count > 5) {
					const error = get_stack("updated at");
					if (error !== null) {
						let entry = source$1.updated.get(error.stack);
						if (!entry) {
							entry = {
								error,
								count: 0
							};
							source$1.updated.set(error.stack, entry);
						}
						entry.count++;
					}
				}
			}
			if (active_effect !== null) source$1.set_during_effect = true;
		}
		if ((source$1.f & DERIVED) !== 0) {
			if ((source$1.f & DIRTY) !== 0) execute_derived(source$1);
			set_signal_status(source$1, (source$1.f & CONNECTED) !== 0 ? CLEAN : MAYBE_DIRTY);
		}
		source$1.wv = increment_write_version();
		mark_reactions(source$1, DIRTY);
		if (is_runes() && active_effect !== null && (active_effect.f & CLEAN) !== 0 && (active_effect.f & (BRANCH_EFFECT | ROOT_EFFECT)) === 0) if (untracked_writes === null) set_untracked_writes([source$1]);
		else untracked_writes.push(source$1);
		if (!batch.is_fork && eager_effects.size > 0 && !eager_effects_deferred) flush_eager_effects();
	}
	return value;
}
function flush_eager_effects() {
	eager_effects_deferred = false;
	var prev_is_updating_effect = is_updating_effect;
	set_is_updating_effect(true);
	const inspects = Array.from(eager_effects);
	try {
		for (const effect$1 of inspects) {
			if ((effect$1.f & CLEAN) !== 0) set_signal_status(effect$1, MAYBE_DIRTY);
			if (is_dirty(effect$1)) update_effect(effect$1);
		}
	} finally {
		set_is_updating_effect(prev_is_updating_effect);
	}
	eager_effects.clear();
}
/**
* Silently (without using `get`) increment a source
* @param {Source<number>} source
*/
function increment(source$1) {
	set(source$1, source$1.v + 1);
}
/**
* @param {Value} signal
* @param {number} status should be DIRTY or MAYBE_DIRTY
* @returns {void}
*/
function mark_reactions(signal, status) {
	var reactions = signal.reactions;
	if (reactions === null) return;
	var runes = is_runes();
	var length = reactions.length;
	for (var i = 0; i < length; i++) {
		var reaction = reactions[i];
		var flags$1 = reaction.f;
		if (!runes && reaction === active_effect) continue;
		if (dev_fallback_default && (flags$1 & EAGER_EFFECT) !== 0) {
			eager_effects.add(reaction);
			continue;
		}
		var not_dirty = (flags$1 & DIRTY) === 0;
		if (not_dirty) set_signal_status(reaction, status);
		if ((flags$1 & DERIVED) !== 0) {
			var derived$1 = reaction;
			batch_values?.delete(derived$1);
			if ((flags$1 & WAS_MARKED) === 0) {
				if (flags$1 & CONNECTED) reaction.f |= WAS_MARKED;
				mark_reactions(derived$1, MAYBE_DIRTY);
			}
		} else if (not_dirty) {
			if ((flags$1 & BLOCK_EFFECT) !== 0) {
				if (eager_block_effects !== null) eager_block_effects.add(reaction);
			}
			schedule_effect(reaction);
		}
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/proxy.js
const regex_is_valid_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
/**
* @template T
* @param {T} value
* @returns {T}
*/
function proxy(value) {
	if (typeof value !== "object" || value === null || STATE_SYMBOL in value) return value;
	const prototype = get_prototype_of(value);
	if (prototype !== object_prototype && prototype !== array_prototype) return value;
	/** @type {Map<any, Source<any>>} */
	var sources = /* @__PURE__ */ new Map();
	var is_proxied_array = is_array(value);
	var version = state(0);
	var stack$1 = dev_fallback_default && tracing_mode_flag ? get_stack("created at") : null;
	var parent_version = update_version;
	/**
	* Executes the proxy in the context of the reaction it was originally created in, if any
	* @template T
	* @param {() => T} fn
	*/
	var with_parent = (fn) => {
		if (update_version === parent_version) return fn();
		var reaction = active_reaction;
		var version$1 = update_version;
		set_active_reaction(null);
		set_update_version(parent_version);
		var result = fn();
		set_active_reaction(reaction);
		set_update_version(version$1);
		return result;
	};
	if (is_proxied_array) {
		sources.set("length", state(
			/** @type {any[]} */
			value.length,
			stack$1
		));
		if (dev_fallback_default) value = inspectable_array(value);
	}
	/** Used in dev for $inspect.trace() */
	var path = "";
	let updating = false;
	/** @param {string} new_path */
	function update_path(new_path) {
		if (updating) return;
		updating = true;
		path = new_path;
		tag(version, `${path} version`);
		for (const [prop, source$1] of sources) tag(source$1, get_label(path, prop));
		updating = false;
	}
	return new Proxy(value, {
		defineProperty(_, prop, descriptor) {
			if (!("value" in descriptor) || descriptor.configurable === false || descriptor.enumerable === false || descriptor.writable === false) state_descriptors_fixed();
			var s = sources.get(prop);
			if (s === void 0) s = with_parent(() => {
				var s$1 = state(descriptor.value, stack$1);
				sources.set(prop, s$1);
				if (dev_fallback_default && typeof prop === "string") tag(s$1, get_label(path, prop));
				return s$1;
			});
			else set(s, descriptor.value, true);
			return true;
		},
		deleteProperty(target, prop) {
			var s = sources.get(prop);
			if (s === void 0) {
				if (prop in target) {
					const s$1 = with_parent(() => state(UNINITIALIZED, stack$1));
					sources.set(prop, s$1);
					increment(version);
					if (dev_fallback_default) tag(s$1, get_label(path, prop));
				}
			} else {
				set(s, UNINITIALIZED);
				increment(version);
			}
			return true;
		},
		get(target, prop, receiver) {
			if (prop === STATE_SYMBOL) return value;
			if (dev_fallback_default && prop === PROXY_PATH_SYMBOL) return update_path;
			var s = sources.get(prop);
			var exists = prop in target;
			if (s === void 0 && (!exists || get_descriptor(target, prop)?.writable)) {
				s = with_parent(() => {
					var p = proxy(exists ? target[prop] : UNINITIALIZED);
					var s$1 = state(p, stack$1);
					if (dev_fallback_default) tag(s$1, get_label(path, prop));
					return s$1;
				});
				sources.set(prop, s);
			}
			if (s !== void 0) {
				var v = get(s);
				return v === UNINITIALIZED ? void 0 : v;
			}
			return Reflect.get(target, prop, receiver);
		},
		getOwnPropertyDescriptor(target, prop) {
			var descriptor = Reflect.getOwnPropertyDescriptor(target, prop);
			if (descriptor && "value" in descriptor) {
				var s = sources.get(prop);
				if (s) descriptor.value = get(s);
			} else if (descriptor === void 0) {
				var source$1 = sources.get(prop);
				var value$1 = source$1?.v;
				if (source$1 !== void 0 && value$1 !== UNINITIALIZED) return {
					enumerable: true,
					configurable: true,
					value: value$1,
					writable: true
				};
			}
			return descriptor;
		},
		has(target, prop) {
			if (prop === STATE_SYMBOL) return true;
			var s = sources.get(prop);
			var has = s !== void 0 && s.v !== UNINITIALIZED || Reflect.has(target, prop);
			if (s !== void 0 || active_effect !== null && (!has || get_descriptor(target, prop)?.writable)) {
				if (s === void 0) {
					s = with_parent(() => {
						var p = has ? proxy(target[prop]) : UNINITIALIZED;
						var s$1 = state(p, stack$1);
						if (dev_fallback_default) tag(s$1, get_label(path, prop));
						return s$1;
					});
					sources.set(prop, s);
				}
				var value$1 = get(s);
				if (value$1 === UNINITIALIZED) return false;
			}
			return has;
		},
		set(target, prop, value$1, receiver) {
			var s = sources.get(prop);
			var has = prop in target;
			if (is_proxied_array && prop === "length") for (var i = value$1; i < s.v; i += 1) {
				var other_s = sources.get(i + "");
				if (other_s !== void 0) set(other_s, UNINITIALIZED);
				else if (i in target) {
					other_s = with_parent(() => state(UNINITIALIZED, stack$1));
					sources.set(i + "", other_s);
					if (dev_fallback_default) tag(other_s, get_label(path, i));
				}
			}
			if (s === void 0) {
				if (!has || get_descriptor(target, prop)?.writable) {
					s = with_parent(() => state(void 0, stack$1));
					if (dev_fallback_default) tag(s, get_label(path, prop));
					set(s, proxy(value$1));
					sources.set(prop, s);
				}
			} else {
				has = s.v !== UNINITIALIZED;
				var p = with_parent(() => proxy(value$1));
				set(s, p);
			}
			var descriptor = Reflect.getOwnPropertyDescriptor(target, prop);
			if (descriptor?.set) descriptor.set.call(receiver, value$1);
			if (!has) {
				if (is_proxied_array && typeof prop === "string") {
					var ls = sources.get("length");
					var n = Number(prop);
					if (Number.isInteger(n) && n >= ls.v) set(ls, n + 1);
				}
				increment(version);
			}
			return true;
		},
		ownKeys(target) {
			get(version);
			var own_keys = Reflect.ownKeys(target).filter((key$1) => {
				var source$2 = sources.get(key$1);
				return source$2 === void 0 || source$2.v !== UNINITIALIZED;
			});
			for (var [key, source$1] of sources) if (source$1.v !== UNINITIALIZED && !(key in target)) own_keys.push(key);
			return own_keys;
		},
		setPrototypeOf() {
			state_prototype_fixed();
		}
	});
}
/**
* @param {string} path
* @param {string | symbol} prop
*/
function get_label(path, prop) {
	if (typeof prop === "symbol") return `${path}[Symbol(${prop.description ?? ""})]`;
	if (regex_is_valid_identifier.test(prop)) return `${path}.${prop}`;
	return /^\d+$/.test(prop) ? `${path}[${prop}]` : `${path}['${prop}']`;
}
/**
* @param {any} value
*/
function get_proxied_value(value) {
	try {
		if (value !== null && typeof value === "object" && STATE_SYMBOL in value) return value[STATE_SYMBOL];
	} catch {}
	return value;
}
const ARRAY_MUTATING_METHODS = new Set([
	"copyWithin",
	"fill",
	"pop",
	"push",
	"reverse",
	"shift",
	"sort",
	"splice",
	"unshift"
]);
/**
* Wrap array mutating methods so $inspect is triggered only once and
* to prevent logging an array in intermediate state (e.g. with an empty slot)
* @param {any[]} array
*/
function inspectable_array(array) {
	return new Proxy(array, { get(target, prop, receiver) {
		var value = Reflect.get(target, prop, receiver);
		if (!ARRAY_MUTATING_METHODS.has(prop)) return value;
		/**
		* @this {any[]}
		* @param {any[]} args
		*/
		return function(...args) {
			set_eager_effects_deferred();
			var result = value.apply(this, args);
			flush_eager_effects();
			return result;
		};
	} });
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dev/equality.js
function init_array_prototype_warnings() {
	const array_prototype$1 = Array.prototype;
	const cleanup = Array.__svelte_cleanup;
	if (cleanup) cleanup();
	const { indexOf, lastIndexOf, includes } = array_prototype$1;
	array_prototype$1.indexOf = function(item, from_index) {
		const index$1 = indexOf.call(this, item, from_index);
		if (index$1 === -1) {
			for (let i = from_index ?? 0; i < this.length; i += 1) if (get_proxied_value(this[i]) === item) {
				state_proxy_equality_mismatch("array.indexOf(...)");
				break;
			}
		}
		return index$1;
	};
	array_prototype$1.lastIndexOf = function(item, from_index) {
		const index$1 = lastIndexOf.call(this, item, from_index ?? this.length - 1);
		if (index$1 === -1) {
			for (let i = 0; i <= (from_index ?? this.length - 1); i += 1) if (get_proxied_value(this[i]) === item) {
				state_proxy_equality_mismatch("array.lastIndexOf(...)");
				break;
			}
		}
		return index$1;
	};
	array_prototype$1.includes = function(item, from_index) {
		const has = includes.call(this, item, from_index);
		if (!has) {
			for (let i = 0; i < this.length; i += 1) if (get_proxied_value(this[i]) === item) {
				state_proxy_equality_mismatch("array.includes(...)");
				break;
			}
		}
		return has;
	};
	Array.__svelte_cleanup = () => {
		array_prototype$1.indexOf = indexOf;
		array_prototype$1.lastIndexOf = lastIndexOf;
		array_prototype$1.includes = includes;
	};
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/operations.js
/** @type {Window} */
var $window;
/** @type {Document} */
var $document;
/** @type {boolean} */
var is_firefox;
/** @type {() => Node | null} */
var first_child_getter;
/** @type {() => Node | null} */
var next_sibling_getter;
/**
* Initialize these lazily to avoid issues when using the runtime in a server context
* where these globals are not available while avoiding a separate server entry point
*/
function init_operations() {
	if ($window !== void 0) return;
	$window = window;
	$document = document;
	is_firefox = /Firefox/.test(navigator.userAgent);
	var element_prototype = Element.prototype;
	var node_prototype = Node.prototype;
	var text_prototype = Text.prototype;
	first_child_getter = get_descriptor(node_prototype, "firstChild").get;
	next_sibling_getter = get_descriptor(node_prototype, "nextSibling").get;
	if (is_extensible(element_prototype)) {
		element_prototype.__click = void 0;
		element_prototype.__className = void 0;
		element_prototype.__attributes = null;
		element_prototype.__style = void 0;
		element_prototype.__e = void 0;
	}
	if (is_extensible(text_prototype)) text_prototype.__t = void 0;
	if (dev_fallback_default) {
		element_prototype.__svelte_meta = null;
		init_array_prototype_warnings();
	}
}
/**
* @param {string} value
* @returns {Text}
*/
function create_text(value = "") {
	return document.createTextNode(value);
}
/**
* @template {Node} N
* @param {N} node
* @returns {Node | null}
*/
/* @__NO_SIDE_EFFECTS__ */
function get_first_child(node) {
	return first_child_getter.call(node);
}
/**
* @template {Node} N
* @param {N} node
* @returns {Node | null}
*/
/* @__NO_SIDE_EFFECTS__ */
function get_next_sibling(node) {
	return next_sibling_getter.call(node);
}
/**
* Don't mark this as side-effect-free, hydration needs to walk all nodes
* @template {Node} N
* @param {N} node
* @param {boolean} is_text
* @returns {Node | null}
*/
function child(node, is_text) {
	if (!hydrating) return /* @__PURE__ */ get_first_child(node);
	var child$1 = /* @__PURE__ */ get_first_child(hydrate_node);
	if (child$1 === null) child$1 = hydrate_node.appendChild(create_text());
	else if (is_text && child$1.nodeType !== TEXT_NODE) {
		var text$1 = create_text();
		child$1?.before(text$1);
		set_hydrate_node(text$1);
		return text$1;
	}
	set_hydrate_node(child$1);
	return child$1;
}
/**
* Don't mark this as side-effect-free, hydration needs to walk all nodes
* @param {TemplateNode} node
* @param {number} count
* @param {boolean} is_text
* @returns {Node | null}
*/
function sibling(node, count = 1, is_text = false) {
	let next_sibling = hydrating ? hydrate_node : node;
	var last_sibling;
	while (count--) {
		last_sibling = next_sibling;
		next_sibling = /* @__PURE__ */ get_next_sibling(next_sibling);
	}
	if (!hydrating) return next_sibling;
	if (is_text && next_sibling?.nodeType !== TEXT_NODE) {
		var text$1 = create_text();
		if (next_sibling === null) last_sibling?.after(text$1);
		else next_sibling.before(text$1);
		set_hydrate_node(text$1);
		return text$1;
	}
	set_hydrate_node(next_sibling);
	return next_sibling;
}
/**
* @template {Node} N
* @param {N} node
* @returns {void}
*/
function clear_text_content(node) {
	node.textContent = "";
}
/**
* Returns `true` if we're updating the current block, for example `condition` in
* an `{#if condition}` block just changed. In this case, the branch should be
* appended (or removed) at the same time as other updates within the
* current `<svelte:boundary>`
*/
function should_defer_append() {
	if (!async_mode_flag) return false;
	if (eager_block_effects !== null) return false;
	var flags$1 = active_effect.f;
	return (flags$1 & EFFECT_RAN) !== 0;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/elements/bindings/shared.js
/**
* @template T
* @param {() => T} fn
*/
function without_reactive_context(fn) {
	var previous_reaction = active_reaction;
	var previous_effect = active_effect;
	set_active_reaction(null);
	set_active_effect(null);
	try {
		return fn();
	} finally {
		set_active_reaction(previous_reaction);
		set_active_effect(previous_effect);
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/effects.js
/**
* @param {'$effect' | '$effect.pre' | '$inspect'} rune
*/
function validate_effect(rune) {
	if (active_effect === null) {
		if (active_reaction === null) effect_orphan(rune);
		effect_in_unowned_derived();
	}
	if (is_destroying_effect) effect_in_teardown(rune);
}
/**
* @param {Effect} effect
* @param {Effect} parent_effect
*/
function push_effect(effect$1, parent_effect) {
	var parent_last = parent_effect.last;
	if (parent_last === null) parent_effect.last = parent_effect.first = effect$1;
	else {
		parent_last.next = effect$1;
		effect$1.prev = parent_last;
		parent_effect.last = effect$1;
	}
}
/**
* @param {number} type
* @param {null | (() => void | (() => void))} fn
* @param {boolean} sync
* @returns {Effect}
*/
function create_effect(type, fn, sync) {
	var parent = active_effect;
	if (dev_fallback_default) while (parent !== null && (parent.f & EAGER_EFFECT) !== 0) parent = parent.parent;
	if (parent !== null && (parent.f & INERT) !== 0) type |= INERT;
	/** @type {Effect} */
	var effect$1 = {
		ctx: component_context,
		deps: null,
		nodes_start: null,
		nodes_end: null,
		f: type | DIRTY | CONNECTED,
		first: null,
		fn,
		last: null,
		next: null,
		parent,
		b: parent && parent.b,
		prev: null,
		teardown: null,
		transitions: null,
		wv: 0,
		ac: null
	};
	if (dev_fallback_default) effect$1.component_function = dev_current_component_function;
	if (sync) try {
		update_effect(effect$1);
		effect$1.f |= EFFECT_RAN;
	} catch (e$1) {
		destroy_effect(effect$1);
		throw e$1;
	}
	else if (fn !== null) schedule_effect(effect$1);
	/** @type {Effect | null} */
	var e = effect$1;
	if (sync && e.deps === null && e.teardown === null && e.nodes_start === null && e.first === e.last && (e.f & EFFECT_PRESERVED) === 0) {
		e = e.first;
		if ((type & BLOCK_EFFECT) !== 0 && (type & EFFECT_TRANSPARENT) !== 0 && e !== null) e.f |= EFFECT_TRANSPARENT;
	}
	if (e !== null) {
		e.parent = parent;
		if (parent !== null) push_effect(e, parent);
		if (active_reaction !== null && (active_reaction.f & DERIVED) !== 0 && (type & ROOT_EFFECT) === 0) {
			var derived$1 = active_reaction;
			(derived$1.effects ??= []).push(e);
		}
	}
	return effect$1;
}
/**
* Internal representation of `$effect.tracking()`
* @returns {boolean}
*/
function effect_tracking() {
	return active_reaction !== null && !untracking;
}
/**
* @param {() => void} fn
*/
function teardown(fn) {
	const effect$1 = create_effect(RENDER_EFFECT, null, false);
	set_signal_status(effect$1, CLEAN);
	effect$1.teardown = fn;
	return effect$1;
}
/**
* Internal representation of `$effect(...)`
* @param {() => void | (() => void)} fn
*/
function user_effect(fn) {
	validate_effect("$effect");
	if (dev_fallback_default) define_property(fn, "name", { value: "$effect" });
	var flags$1 = active_effect.f;
	var defer = !active_reaction && (flags$1 & BRANCH_EFFECT) !== 0 && (flags$1 & EFFECT_RAN) === 0;
	if (defer) {
		var context = component_context;
		(context.e ??= []).push(fn);
	} else return create_user_effect(fn);
}
/**
* @param {() => void | (() => void)} fn
*/
function create_user_effect(fn) {
	return create_effect(EFFECT | USER_EFFECT, fn, false);
}
/**
* Internal representation of `$effect.root(...)`
* @param {() => void | (() => void)} fn
* @returns {() => void}
*/
function effect_root(fn) {
	Batch.ensure();
	const effect$1 = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, fn, true);
	return () => {
		destroy_effect(effect$1);
	};
}
/**
* An effect root whose children can transition out
* @param {() => void} fn
* @returns {(options?: { outro?: boolean }) => Promise<void>}
*/
function component_root(fn) {
	Batch.ensure();
	const effect$1 = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, fn, true);
	return (options = {}) => {
		return new Promise((fulfil) => {
			if (options.outro) pause_effect(effect$1, () => {
				destroy_effect(effect$1);
				fulfil(void 0);
			});
			else {
				destroy_effect(effect$1);
				fulfil(void 0);
			}
		});
	};
}
/**
* @param {() => void | (() => void)} fn
* @returns {Effect}
*/
function effect(fn) {
	return create_effect(EFFECT, fn, false);
}
/**
* @param {() => void | (() => void)} fn
* @returns {Effect}
*/
function async_effect(fn) {
	return create_effect(ASYNC | EFFECT_PRESERVED, fn, true);
}
/**
* @param {() => void | (() => void)} fn
* @returns {Effect}
*/
function render_effect(fn, flags$1 = 0) {
	return create_effect(RENDER_EFFECT | flags$1, fn, true);
}
/**
* @param {(...expressions: any) => void | (() => void)} fn
* @param {Array<() => any>} sync
* @param {Array<() => Promise<any>>} async
* @param {Array<Promise<void>>} blockers
*/
function template_effect(fn, sync = [], async = [], blockers = []) {
	flatten(blockers, sync, async, (values) => {
		create_effect(RENDER_EFFECT, () => fn(...values.map(get)), true);
	});
}
/**
* @param {(() => void)} fn
* @param {number} flags
*/
function block(fn, flags$1 = 0) {
	var effect$1 = create_effect(BLOCK_EFFECT | flags$1, fn, true);
	if (dev_fallback_default) effect$1.dev_stack = dev_stack;
	return effect$1;
}
/**
* @param {(() => void)} fn
*/
function branch(fn) {
	return create_effect(BRANCH_EFFECT | EFFECT_PRESERVED, fn, true);
}
/**
* @param {Effect} effect
*/
function execute_effect_teardown(effect$1) {
	var teardown$1 = effect$1.teardown;
	if (teardown$1 !== null) {
		const previously_destroying_effect = is_destroying_effect;
		const previous_reaction = active_reaction;
		set_is_destroying_effect(true);
		set_active_reaction(null);
		try {
			teardown$1.call(null);
		} finally {
			set_is_destroying_effect(previously_destroying_effect);
			set_active_reaction(previous_reaction);
		}
	}
}
/**
* @param {Effect} signal
* @param {boolean} remove_dom
* @returns {void}
*/
function destroy_effect_children(signal, remove_dom = false) {
	var effect$1 = signal.first;
	signal.first = signal.last = null;
	while (effect$1 !== null) {
		const controller = effect$1.ac;
		if (controller !== null) without_reactive_context(() => {
			controller.abort(STALE_REACTION);
		});
		var next$1 = effect$1.next;
		if ((effect$1.f & ROOT_EFFECT) !== 0) effect$1.parent = null;
		else destroy_effect(effect$1, remove_dom);
		effect$1 = next$1;
	}
}
/**
* @param {Effect} signal
* @returns {void}
*/
function destroy_block_effect_children(signal) {
	var effect$1 = signal.first;
	while (effect$1 !== null) {
		var next$1 = effect$1.next;
		if ((effect$1.f & BRANCH_EFFECT) === 0) destroy_effect(effect$1);
		effect$1 = next$1;
	}
}
/**
* @param {Effect} effect
* @param {boolean} [remove_dom]
* @returns {void}
*/
function destroy_effect(effect$1, remove_dom = true) {
	var removed = false;
	if ((remove_dom || (effect$1.f & HEAD_EFFECT) !== 0) && effect$1.nodes_start !== null && effect$1.nodes_end !== null) {
		remove_effect_dom(effect$1.nodes_start, effect$1.nodes_end);
		removed = true;
	}
	destroy_effect_children(effect$1, remove_dom && !removed);
	remove_reactions(effect$1, 0);
	set_signal_status(effect$1, DESTROYED);
	var transitions = effect$1.transitions;
	if (transitions !== null) for (const transition of transitions) transition.stop();
	execute_effect_teardown(effect$1);
	var parent = effect$1.parent;
	if (parent !== null && parent.first !== null) unlink_effect(effect$1);
	if (dev_fallback_default) effect$1.component_function = null;
	effect$1.next = effect$1.prev = effect$1.teardown = effect$1.ctx = effect$1.deps = effect$1.fn = effect$1.nodes_start = effect$1.nodes_end = effect$1.ac = null;
}
/**
*
* @param {TemplateNode | null} node
* @param {TemplateNode} end
*/
function remove_effect_dom(node, end) {
	while (node !== null) {
		/** @type {TemplateNode | null} */
		var next$1 = node === end ? null : get_next_sibling(node);
		node.remove();
		node = next$1;
	}
}
/**
* Detach an effect from the effect tree, freeing up memory and
* reducing the amount of work that happens on subsequent traversals
* @param {Effect} effect
*/
function unlink_effect(effect$1) {
	var parent = effect$1.parent;
	var prev = effect$1.prev;
	var next$1 = effect$1.next;
	if (prev !== null) prev.next = next$1;
	if (next$1 !== null) next$1.prev = prev;
	if (parent !== null) {
		if (parent.first === effect$1) parent.first = next$1;
		if (parent.last === effect$1) parent.last = prev;
	}
}
/**
* When a block effect is removed, we don't immediately destroy it or yank it
* out of the DOM, because it might have transitions. Instead, we 'pause' it.
* It stays around (in memory, and in the DOM) until outro transitions have
* completed, and if the state change is reversed then we _resume_ it.
* A paused effect does not update, and the DOM subtree becomes inert.
* @param {Effect} effect
* @param {() => void} [callback]
* @param {boolean} [destroy]
*/
function pause_effect(effect$1, callback, destroy = true) {
	/** @type {TransitionManager[]} */
	var transitions = [];
	pause_children(effect$1, transitions, true);
	run_out_transitions(transitions, () => {
		if (destroy) destroy_effect(effect$1);
		if (callback) callback();
	});
}
/**
* @param {TransitionManager[]} transitions
* @param {() => void} fn
*/
function run_out_transitions(transitions, fn) {
	var remaining = transitions.length;
	if (remaining > 0) {
		var check = () => --remaining || fn();
		for (var transition of transitions) transition.out(check);
	} else fn();
}
/**
* @param {Effect} effect
* @param {TransitionManager[]} transitions
* @param {boolean} local
*/
function pause_children(effect$1, transitions, local) {
	if ((effect$1.f & INERT) !== 0) return;
	effect$1.f ^= INERT;
	if (effect$1.transitions !== null) {
		for (const transition of effect$1.transitions) if (transition.is_global || local) transitions.push(transition);
	}
	var child$1 = effect$1.first;
	while (child$1 !== null) {
		var sibling$1 = child$1.next;
		var transparent = (child$1.f & EFFECT_TRANSPARENT) !== 0 || (child$1.f & BRANCH_EFFECT) !== 0 && (effect$1.f & BLOCK_EFFECT) !== 0;
		pause_children(child$1, transitions, transparent ? local : false);
		child$1 = sibling$1;
	}
}
/**
* The opposite of `pause_effect`. We call this if (for example)
* `x` becomes falsy then truthy: `{#if x}...{/if}`
* @param {Effect} effect
*/
function resume_effect(effect$1) {
	resume_children(effect$1, true);
}
/**
* @param {Effect} effect
* @param {boolean} local
*/
function resume_children(effect$1, local) {
	if ((effect$1.f & INERT) === 0) return;
	effect$1.f ^= INERT;
	if ((effect$1.f & CLEAN) === 0) {
		set_signal_status(effect$1, DIRTY);
		schedule_effect(effect$1);
	}
	var child$1 = effect$1.first;
	while (child$1 !== null) {
		var sibling$1 = child$1.next;
		var transparent = (child$1.f & EFFECT_TRANSPARENT) !== 0 || (child$1.f & BRANCH_EFFECT) !== 0;
		resume_children(child$1, transparent ? local : false);
		child$1 = sibling$1;
	}
	if (effect$1.transitions !== null) {
		for (const transition of effect$1.transitions) if (transition.is_global || local) transition.in();
	}
}
/**
* @param {Effect} effect
* @param {DocumentFragment} fragment
*/
function move_effect(effect$1, fragment) {
	var node = effect$1.nodes_start;
	var end = effect$1.nodes_end;
	while (node !== null) {
		/** @type {TemplateNode | null} */
		var next$1 = node === end ? null : get_next_sibling(node);
		fragment.append(node);
		node = next$1;
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/legacy.js
/**
* @type {Set<Value> | null}
* @deprecated
*/
let captured_signals = null;

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/runtime.js
let is_updating_effect = false;
/** @param {boolean} value */
function set_is_updating_effect(value) {
	is_updating_effect = value;
}
let is_destroying_effect = false;
/** @param {boolean} value */
function set_is_destroying_effect(value) {
	is_destroying_effect = value;
}
/** @type {null | Reaction} */
let active_reaction = null;
let untracking = false;
/** @param {null | Reaction} reaction */
function set_active_reaction(reaction) {
	active_reaction = reaction;
}
/** @type {null | Effect} */
let active_effect = null;
/** @param {null | Effect} effect */
function set_active_effect(effect$1) {
	active_effect = effect$1;
}
/**
* When sources are created within a reaction, reading and writing
* them within that reaction should not cause a re-run
* @type {null | Source[]}
*/
let current_sources = null;
/** @param {Value} value */
function push_reaction_value(value) {
	if (active_reaction !== null && (!async_mode_flag || (active_reaction.f & DERIVED) !== 0)) if (current_sources === null) current_sources = [value];
	else current_sources.push(value);
}
/**
* The dependencies of the reaction that is currently being executed. In many cases,
* the dependencies are unchanged between runs, and so this will be `null` unless
* and until a new dependency is accessed — we track this via `skipped_deps`
* @type {null | Value[]}
*/
let new_deps = null;
let skipped_deps = 0;
/**
* Tracks writes that the effect it's executed in doesn't listen to yet,
* so that the dependency can be added to the effect later on if it then reads it
* @type {null | Source[]}
*/
let untracked_writes = null;
/** @param {null | Source[]} value */
function set_untracked_writes(value) {
	untracked_writes = value;
}
/**
* @type {number} Used by sources and deriveds for handling updates.
* Version starts from 1 so that unowned deriveds differentiate between a created effect and a run one for tracing
**/
let write_version = 1;
/** @type {number} Used to version each read of a source of derived to avoid duplicating depedencies inside a reaction */
let read_version = 0;
let update_version = read_version;
/** @param {number} value */
function set_update_version(value) {
	update_version = value;
}
function increment_write_version() {
	return ++write_version;
}
/**
* Determines whether a derived or effect is dirty.
* If it is MAYBE_DIRTY, will set the status to CLEAN
* @param {Reaction} reaction
* @returns {boolean}
*/
function is_dirty(reaction) {
	var flags$1 = reaction.f;
	if ((flags$1 & DIRTY) !== 0) return true;
	if (flags$1 & DERIVED) reaction.f &= ~WAS_MARKED;
	if ((flags$1 & MAYBE_DIRTY) !== 0) {
		var dependencies = reaction.deps;
		if (dependencies !== null) {
			var length = dependencies.length;
			for (var i = 0; i < length; i++) {
				var dependency = dependencies[i];
				if (is_dirty(dependency)) update_derived(dependency);
				if (dependency.wv > reaction.wv) return true;
			}
		}
		if ((flags$1 & CONNECTED) !== 0 && batch_values === null) set_signal_status(reaction, CLEAN);
	}
	return false;
}
/**
* @param {Value} signal
* @param {Effect} effect
* @param {boolean} [root]
*/
function schedule_possible_effect_self_invalidation(signal, effect$1, root$2 = true) {
	var reactions = signal.reactions;
	if (reactions === null) return;
	if (!async_mode_flag && current_sources?.includes(signal)) return;
	for (var i = 0; i < reactions.length; i++) {
		var reaction = reactions[i];
		if ((reaction.f & DERIVED) !== 0) schedule_possible_effect_self_invalidation(reaction, effect$1, false);
		else if (effect$1 === reaction) {
			if (root$2) set_signal_status(reaction, DIRTY);
			else if ((reaction.f & CLEAN) !== 0) set_signal_status(reaction, MAYBE_DIRTY);
			schedule_effect(reaction);
		}
	}
}
/** @param {Reaction} reaction */
function update_reaction(reaction) {
	var previous_deps = new_deps;
	var previous_skipped_deps = skipped_deps;
	var previous_untracked_writes = untracked_writes;
	var previous_reaction = active_reaction;
	var previous_sources = current_sources;
	var previous_component_context = component_context;
	var previous_untracking = untracking;
	var previous_update_version = update_version;
	var flags$1 = reaction.f;
	new_deps = null;
	skipped_deps = 0;
	untracked_writes = null;
	active_reaction = (flags$1 & (BRANCH_EFFECT | ROOT_EFFECT)) === 0 ? reaction : null;
	current_sources = null;
	set_component_context(reaction.ctx);
	untracking = false;
	update_version = ++read_version;
	if (reaction.ac !== null) {
		without_reactive_context(() => {
			/** @type {AbortController} */ reaction.ac.abort(STALE_REACTION);
		});
		reaction.ac = null;
	}
	try {
		reaction.f |= REACTION_IS_UPDATING;
		var fn = reaction.fn;
		var result = fn();
		var deps = reaction.deps;
		if (new_deps !== null) {
			var i;
			remove_reactions(reaction, skipped_deps);
			if (deps !== null && skipped_deps > 0) {
				deps.length = skipped_deps + new_deps.length;
				for (i = 0; i < new_deps.length; i++) deps[skipped_deps + i] = new_deps[i];
			} else reaction.deps = deps = new_deps;
			if (is_updating_effect && effect_tracking() && (reaction.f & CONNECTED) !== 0) for (i = skipped_deps; i < deps.length; i++) (deps[i].reactions ??= []).push(reaction);
		} else if (deps !== null && skipped_deps < deps.length) {
			remove_reactions(reaction, skipped_deps);
			deps.length = skipped_deps;
		}
		if (is_runes() && untracked_writes !== null && !untracking && deps !== null && (reaction.f & (DERIVED | MAYBE_DIRTY | DIRTY)) === 0) for (i = 0; i < untracked_writes.length; i++) schedule_possible_effect_self_invalidation(untracked_writes[i], reaction);
		if (previous_reaction !== null && previous_reaction !== reaction) {
			read_version++;
			if (untracked_writes !== null) if (previous_untracked_writes === null) previous_untracked_writes = untracked_writes;
			else previous_untracked_writes.push(...untracked_writes);
		}
		if ((reaction.f & ERROR_VALUE) !== 0) reaction.f ^= ERROR_VALUE;
		return result;
	} catch (error) {
		return handle_error(error);
	} finally {
		reaction.f ^= REACTION_IS_UPDATING;
		new_deps = previous_deps;
		skipped_deps = previous_skipped_deps;
		untracked_writes = previous_untracked_writes;
		active_reaction = previous_reaction;
		current_sources = previous_sources;
		set_component_context(previous_component_context);
		untracking = previous_untracking;
		update_version = previous_update_version;
	}
}
/**
* @template V
* @param {Reaction} signal
* @param {Value<V>} dependency
* @returns {void}
*/
function remove_reaction(signal, dependency) {
	let reactions = dependency.reactions;
	if (reactions !== null) {
		var index$1 = index_of.call(reactions, signal);
		if (index$1 !== -1) {
			var new_length = reactions.length - 1;
			if (new_length === 0) reactions = dependency.reactions = null;
			else {
				reactions[index$1] = reactions[new_length];
				reactions.pop();
			}
		}
	}
	if (reactions === null && (dependency.f & DERIVED) !== 0 && (new_deps === null || !new_deps.includes(dependency))) {
		set_signal_status(dependency, MAYBE_DIRTY);
		if ((dependency.f & CONNECTED) !== 0) {
			dependency.f ^= CONNECTED;
			dependency.f &= ~WAS_MARKED;
		}
		destroy_derived_effects(dependency);
		remove_reactions(dependency, 0);
	}
}
/**
* @param {Reaction} signal
* @param {number} start_index
* @returns {void}
*/
function remove_reactions(signal, start_index) {
	var dependencies = signal.deps;
	if (dependencies === null) return;
	for (var i = start_index; i < dependencies.length; i++) remove_reaction(signal, dependencies[i]);
}
/**
* @param {Effect} effect
* @returns {void}
*/
function update_effect(effect$1) {
	var flags$1 = effect$1.f;
	if ((flags$1 & DESTROYED) !== 0) return;
	set_signal_status(effect$1, CLEAN);
	var previous_effect = active_effect;
	var was_updating_effect = is_updating_effect;
	active_effect = effect$1;
	is_updating_effect = true;
	if (dev_fallback_default) {
		var previous_component_fn = dev_current_component_function;
		set_dev_current_component_function(effect$1.component_function);
		var previous_stack = dev_stack;
		set_dev_stack(effect$1.dev_stack ?? dev_stack);
	}
	try {
		if ((flags$1 & BLOCK_EFFECT) !== 0) destroy_block_effect_children(effect$1);
		else destroy_effect_children(effect$1);
		execute_effect_teardown(effect$1);
		var teardown$1 = update_reaction(effect$1);
		effect$1.teardown = typeof teardown$1 === "function" ? teardown$1 : null;
		effect$1.wv = write_version;
		if (dev_fallback_default && tracing_mode_flag && (effect$1.f & DIRTY) !== 0 && effect$1.deps !== null) {
			for (var dep of effect$1.deps) if (dep.set_during_effect) {
				dep.wv = increment_write_version();
				dep.set_during_effect = false;
			}
		}
	} finally {
		is_updating_effect = was_updating_effect;
		active_effect = previous_effect;
		if (dev_fallback_default) {
			set_dev_current_component_function(previous_component_fn);
			set_dev_stack(previous_stack);
		}
	}
}
/**
* @template V
* @param {Value<V>} signal
* @returns {V}
*/
function get(signal) {
	var flags$1 = signal.f;
	var is_derived = (flags$1 & DERIVED) !== 0;
	captured_signals?.add(signal);
	if (active_reaction !== null && !untracking) {
		var destroyed = active_effect !== null && (active_effect.f & DESTROYED) !== 0;
		if (!destroyed && !current_sources?.includes(signal)) {
			var deps = active_reaction.deps;
			if ((active_reaction.f & REACTION_IS_UPDATING) !== 0) {
				if (signal.rv < read_version) {
					signal.rv = read_version;
					if (new_deps === null && deps !== null && deps[skipped_deps] === signal) skipped_deps++;
					else if (new_deps === null) new_deps = [signal];
					else if (!new_deps.includes(signal)) new_deps.push(signal);
				}
			} else {
				(active_reaction.deps ??= []).push(signal);
				var reactions = signal.reactions;
				if (reactions === null) signal.reactions = [active_reaction];
				else if (!reactions.includes(active_reaction)) reactions.push(active_reaction);
			}
		}
	}
	if (dev_fallback_default) {
		recent_async_deriveds.delete(signal);
		if (tracing_mode_flag && !untracking && tracing_expressions !== null && active_reaction !== null && tracing_expressions.reaction === active_reaction) if (signal.trace) signal.trace();
		else {
			var trace = get_stack("traced at");
			if (trace) {
				var entry = tracing_expressions.entries.get(signal);
				if (entry === void 0) {
					entry = { traces: [] };
					tracing_expressions.entries.set(signal, entry);
				}
				var last = entry.traces[entry.traces.length - 1];
				if (trace.stack !== last?.stack) entry.traces.push(trace);
			}
		}
	}
	if (is_destroying_effect) {
		if (old_values.has(signal)) return old_values.get(signal);
		if (is_derived) {
			var derived$1 = signal;
			var value = derived$1.v;
			if ((derived$1.f & CLEAN) === 0 && derived$1.reactions !== null || depends_on_old_values(derived$1)) value = execute_derived(derived$1);
			old_values.set(derived$1, value);
			return value;
		}
	} else if (is_derived && !batch_values?.has(signal)) {
		derived$1 = signal;
		if (is_dirty(derived$1)) update_derived(derived$1);
		if (is_updating_effect && effect_tracking() && (derived$1.f & CONNECTED) === 0) reconnect(derived$1);
	}
	if (batch_values?.has(signal)) return batch_values.get(signal);
	if ((signal.f & ERROR_VALUE) !== 0) throw signal.v;
	return signal.v;
}
/**
* (Re)connect a disconnected derived, so that it is notified
* of changes in `mark_reactions`
* @param {Derived} derived
*/
function reconnect(derived$1) {
	if (derived$1.deps === null) return;
	derived$1.f ^= CONNECTED;
	for (const dep of derived$1.deps) {
		(dep.reactions ??= []).push(derived$1);
		if ((dep.f & DERIVED) !== 0 && (dep.f & CONNECTED) === 0) reconnect(dep);
	}
}
/** @param {Derived} derived */
function depends_on_old_values(derived$1) {
	if (derived$1.v === UNINITIALIZED) return true;
	if (derived$1.deps === null) return false;
	for (const dep of derived$1.deps) {
		if (old_values.has(dep)) return true;
		if ((dep.f & DERIVED) !== 0 && depends_on_old_values(dep)) return true;
	}
	return false;
}
/**
* When used inside a [`$derived`](https://svelte.dev/docs/svelte/$derived) or [`$effect`](https://svelte.dev/docs/svelte/$effect),
* any state read inside `fn` will not be treated as a dependency.
*
* ```ts
* $effect(() => {
*   // this will run when `data` changes, but not when `time` changes
*   save(data, {
*     timestamp: untrack(() => time)
*   });
* });
* ```
* @template T
* @param {() => T} fn
* @returns {T}
*/
function untrack(fn) {
	var previous_untracking = untracking;
	try {
		untracking = true;
		return fn();
	} finally {
		untracking = previous_untracking;
	}
}
const STATUS_MASK = ~(DIRTY | MAYBE_DIRTY | CLEAN);
/**
* @param {Signal} signal
* @param {number} status
* @returns {void}
*/
function set_signal_status(signal, status) {
	signal.f = signal.f & STATUS_MASK | status;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/utils.js
/**
* Attributes that are boolean, i.e. they are present or not present.
*/
const DOM_BOOLEAN_ATTRIBUTES = [
	"allowfullscreen",
	"async",
	"autofocus",
	"autoplay",
	"checked",
	"controls",
	"default",
	"disabled",
	"formnovalidate",
	"indeterminate",
	"inert",
	"ismap",
	"loop",
	"multiple",
	"muted",
	"nomodule",
	"novalidate",
	"open",
	"playsinline",
	"readonly",
	"required",
	"reversed",
	"seamless",
	"selected",
	"webkitdirectory",
	"defer",
	"disablepictureinpicture",
	"disableremoteplayback"
];
const DOM_PROPERTIES = [
	...DOM_BOOLEAN_ATTRIBUTES,
	"formNoValidate",
	"isMap",
	"noModule",
	"playsInline",
	"readOnly",
	"value",
	"volume",
	"defaultValue",
	"defaultChecked",
	"srcObject",
	"noValidate",
	"allowFullscreen",
	"disablePictureInPicture",
	"disableRemotePlayback"
];
/**
* Subset of delegated events which should be passive by default.
* These two are already passive via browser defaults on window, document and body.
* But since
* - we're delegating them
* - they happen often
* - they apply to mobile which is generally less performant
* we're marking them as passive by default for other elements, too.
*/
const PASSIVE_EVENTS = ["touchstart", "touchmove"];
/**
* Returns `true` if `name` is a passive event
* @param {string} name
*/
function is_passive_event(name) {
	return PASSIVE_EVENTS.includes(name);
}
const STATE_CREATION_RUNES = [
	"$state",
	"$state.raw",
	"$derived",
	"$derived.by"
];
const RUNES = [
	...STATE_CREATION_RUNES,
	"$state.eager",
	"$state.snapshot",
	"$props",
	"$props.id",
	"$bindable",
	"$effect",
	"$effect.pre",
	"$effect.tracking",
	"$effect.root",
	"$effect.pending",
	"$inspect",
	"$inspect().with",
	"$inspect.trace",
	"$host"
];

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/elements/events.js
/** @type {Set<string>} */
const all_registered_events = /* @__PURE__ */ new Set();
/** @type {Set<(events: Array<string>) => void>} */
const root_event_handles = /* @__PURE__ */ new Set();
/**
* @param {Array<string>} events
* @returns {void}
*/
function delegate(events) {
	for (var i = 0; i < events.length; i++) all_registered_events.add(events[i]);
	for (var fn of root_event_handles) fn(events);
}
let last_propagated_event = null;
/**
* @this {EventTarget}
* @param {Event} event
* @returns {void}
*/
function handle_event_propagation(event$1) {
	var handler_element = this;
	var owner_document = handler_element.ownerDocument;
	var event_name = event$1.type;
	var path = event$1.composedPath?.() || [];
	var current_target = path[0] || event$1.target;
	last_propagated_event = event$1;
	var path_idx = 0;
	var handled_at = last_propagated_event === event$1 && event$1.__root;
	if (handled_at) {
		var at_idx = path.indexOf(handled_at);
		if (at_idx !== -1 && (handler_element === document || handler_element === window)) {
			event$1.__root = handler_element;
			return;
		}
		var handler_idx = path.indexOf(handler_element);
		if (handler_idx === -1) return;
		if (at_idx <= handler_idx) path_idx = at_idx;
	}
	current_target = path[path_idx] || event$1.target;
	if (current_target === handler_element) return;
	define_property(event$1, "currentTarget", {
		configurable: true,
		get() {
			return current_target || owner_document;
		}
	});
	var previous_reaction = active_reaction;
	var previous_effect = active_effect;
	set_active_reaction(null);
	set_active_effect(null);
	try {
		/**
		* @type {unknown}
		*/
		var throw_error;
		/**
		* @type {unknown[]}
		*/
		var other_errors = [];
		while (current_target !== null) {
			/** @type {null | Element} */
			var parent_element = current_target.assignedSlot || current_target.parentNode || current_target.host || null;
			try {
				var delegated = current_target["__" + event_name];
				if (delegated != null && (!current_target.disabled || event$1.target === current_target)) delegated.call(current_target, event$1);
			} catch (error) {
				if (throw_error) other_errors.push(error);
				else throw_error = error;
			}
			if (event$1.cancelBubble || parent_element === handler_element || parent_element === null) break;
			current_target = parent_element;
		}
		if (throw_error) {
			for (let error of other_errors) queueMicrotask(() => {
				throw error;
			});
			throw throw_error;
		}
	} finally {
		event$1.__root = handler_element;
		delete event$1.currentTarget;
		set_active_reaction(previous_reaction);
		set_active_effect(previous_effect);
	}
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/reconciler.js
/** @param {string} html */
function create_fragment_from_html(html) {
	var elem = document.createElement("template");
	elem.innerHTML = html.replaceAll("<!>", "<!---->");
	return elem.content;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/template.js
/**
* @param {TemplateNode} start
* @param {TemplateNode | null} end
*/
function assign_nodes(start, end) {
	var effect$1 = active_effect;
	if (effect$1.nodes_start === null) {
		effect$1.nodes_start = start;
		effect$1.nodes_end = end;
	}
}
/**
* @param {string} content
* @param {number} flags
* @returns {() => Node | Node[]}
*/
/* @__NO_SIDE_EFFECTS__ */
function from_html(content, flags$1) {
	var is_fragment = (flags$1 & TEMPLATE_FRAGMENT) !== 0;
	var use_import_node = (flags$1 & TEMPLATE_USE_IMPORT_NODE) !== 0;
	/** @type {Node} */
	var node;
	/**
	* Whether or not the first item is a text/element node. If not, we need to
	* create an additional comment node to act as `effect.nodes.start`
	*/
	var has_start = !content.startsWith("<!>");
	return () => {
		if (hydrating) {
			assign_nodes(hydrate_node, null);
			return hydrate_node;
		}
		if (node === void 0) {
			node = create_fragment_from_html(has_start ? content : "<!>" + content);
			if (!is_fragment) node = get_first_child(node);
		}
		var clone = use_import_node || is_firefox ? document.importNode(node, true) : node.cloneNode(true);
		if (is_fragment) {
			var start = get_first_child(clone);
			var end = clone.lastChild;
			assign_nodes(start, end);
		} else assign_nodes(clone, clone);
		return clone;
	};
}
/**
* @param {string} content
* @param {number} flags
* @param {'svg' | 'math'} ns
* @returns {() => Node | Node[]}
*/
/* @__NO_SIDE_EFFECTS__ */
function from_namespace(content, flags$1, ns = "svg") {
	/**
	* Whether or not the first item is a text/element node. If not, we need to
	* create an additional comment node to act as `effect.nodes.start`
	*/
	var has_start = !content.startsWith("<!>");
	var is_fragment = (flags$1 & TEMPLATE_FRAGMENT) !== 0;
	var wrapped = `<${ns}>${has_start ? content : "<!>" + content}</${ns}>`;
	/** @type {Element | DocumentFragment} */
	var node;
	return () => {
		if (hydrating) {
			assign_nodes(hydrate_node, null);
			return hydrate_node;
		}
		if (!node) {
			var fragment = create_fragment_from_html(wrapped);
			var root$2 = get_first_child(fragment);
			if (is_fragment) {
				node = document.createDocumentFragment();
				while (get_first_child(root$2)) node.appendChild(get_first_child(root$2));
			} else node = get_first_child(root$2);
		}
		var clone = node.cloneNode(true);
		if (is_fragment) {
			var start = get_first_child(clone);
			var end = clone.lastChild;
			assign_nodes(start, end);
		} else assign_nodes(clone, clone);
		return clone;
	};
}
/**
* @param {string} content
* @param {number} flags
*/
/* @__NO_SIDE_EFFECTS__ */
function from_svg(content, flags$1) {
	return /* @__PURE__ */ from_namespace(content, flags$1, "svg");
}
/**
* Assign the created (or in hydration mode, traversed) dom elements to the current block
* and insert the elements into the dom (in client mode).
* @param {Text | Comment | Element} anchor
* @param {DocumentFragment | Element} dom
*/
function append(anchor, dom) {
	if (hydrating) {
		var effect$1 = active_effect;
		if ((effect$1.f & EFFECT_RAN) === 0 || effect$1.nodes_end === null) effect$1.nodes_end = hydrate_node;
		hydrate_next();
		return;
	}
	if (anchor === null) return;
	anchor.before(dom);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/render.js
/**
* This is normally true — block effects should run their intro transitions —
* but is false during hydration (unless `options.intro` is `true`) and
* when creating the children of a `<svelte:element>` that just changed tag
*/
let should_intro = true;
/**
* @param {Element} text
* @param {string} value
* @returns {void}
*/
function set_text(text$1, value) {
	var str = value == null ? "" : typeof value === "object" ? value + "" : value;
	if (str !== (text$1.__t ??= text$1.nodeValue)) {
		text$1.__t = str;
		text$1.nodeValue = str + "";
	}
}
/**
* Mounts a component to the given target and returns the exports and potentially the props (if compiled with `accessors: true`) of the component.
* Transitions will play during the initial render unless the `intro` option is set to `false`.
*
* @template {Record<string, any>} Props
* @template {Record<string, any>} Exports
* @param {ComponentType<SvelteComponent<Props>> | Component<Props, Exports, any>} component
* @param {MountOptions<Props>} options
* @returns {Exports}
*/
function mount(component, options) {
	return _mount(component, options);
}
/**
* Hydrates a component on the given target and returns the exports and potentially the props (if compiled with `accessors: true`) of the component
*
* @template {Record<string, any>} Props
* @template {Record<string, any>} Exports
* @param {ComponentType<SvelteComponent<Props>> | Component<Props, Exports, any>} component
* @param {{} extends Props ? {
* 		target: Document | Element | ShadowRoot;
* 		props?: Props;
* 		events?: Record<string, (e: any) => any>;
*  	context?: Map<any, any>;
* 		intro?: boolean;
* 		recover?: boolean;
* 	} : {
* 		target: Document | Element | ShadowRoot;
* 		props: Props;
* 		events?: Record<string, (e: any) => any>;
*  	context?: Map<any, any>;
* 		intro?: boolean;
* 		recover?: boolean;
* 	}} options
* @returns {Exports}
*/
function hydrate(component, options) {
	init_operations();
	options.intro = options.intro ?? false;
	const target = options.target;
	const was_hydrating = hydrating;
	const previous_hydrate_node = hydrate_node;
	try {
		var anchor = get_first_child(target);
		while (anchor && (anchor.nodeType !== COMMENT_NODE || anchor.data !== HYDRATION_START)) anchor = get_next_sibling(anchor);
		if (!anchor) throw HYDRATION_ERROR;
		set_hydrating(true);
		set_hydrate_node(anchor);
		const instance = _mount(component, {
			...options,
			anchor
		});
		set_hydrating(false);
		return instance;
	} catch (error) {
		if (error instanceof Error && error.message.split("\n").some((line) => line.startsWith("https://svelte.dev/e/"))) throw error;
		if (error !== HYDRATION_ERROR) console.warn("Failed to hydrate: ", error);
		if (options.recover === false) hydration_failed();
		init_operations();
		clear_text_content(target);
		set_hydrating(false);
		return mount(component, options);
	} finally {
		set_hydrating(was_hydrating);
		set_hydrate_node(previous_hydrate_node);
	}
}
/** @type {Map<string, number>} */
const document_listeners = /* @__PURE__ */ new Map();
/**
* @template {Record<string, any>} Exports
* @param {ComponentType<SvelteComponent<any>> | Component<any>} Component
* @param {MountOptions} options
* @returns {Exports}
*/
function _mount(Component, { target, anchor, props = {}, events, context, intro = true }) {
	init_operations();
	/** @type {Set<string>} */
	var registered_events = /* @__PURE__ */ new Set();
	/** @param {Array<string>} events */
	var event_handle = (events$1) => {
		for (var i = 0; i < events$1.length; i++) {
			var event_name = events$1[i];
			if (registered_events.has(event_name)) continue;
			registered_events.add(event_name);
			var passive = is_passive_event(event_name);
			target.addEventListener(event_name, handle_event_propagation, { passive });
			var n = document_listeners.get(event_name);
			if (n === void 0) {
				document.addEventListener(event_name, handle_event_propagation, { passive });
				document_listeners.set(event_name, 1);
			} else document_listeners.set(event_name, n + 1);
		}
	};
	event_handle(array_from(all_registered_events));
	root_event_handles.add(event_handle);
	/** @type {Exports} */
	var component = void 0;
	var unmount$1 = component_root(() => {
		var anchor_node = anchor ?? target.appendChild(create_text());
		boundary(anchor_node, { pending: () => {} }, (anchor_node$1) => {
			if (context) {
				push({});
				var ctx = component_context;
				ctx.c = context;
			}
			if (events)
 /** @type {any} */ props.$$events = events;
			if (hydrating) assign_nodes(anchor_node$1, null);
			should_intro = intro;
			component = Component(anchor_node$1, props) || {};
			should_intro = true;
			if (hydrating) {
				/** @type {Effect} */ active_effect.nodes_end = hydrate_node;
				if (hydrate_node === null || hydrate_node.nodeType !== COMMENT_NODE || hydrate_node.data !== HYDRATION_END) {
					hydration_mismatch();
					throw HYDRATION_ERROR;
				}
			}
			if (context) pop();
		});
		return () => {
			for (var event_name of registered_events) {
				target.removeEventListener(event_name, handle_event_propagation);
				var n = document_listeners.get(event_name);
				if (--n === 0) {
					document.removeEventListener(event_name, handle_event_propagation);
					document_listeners.delete(event_name);
				} else document_listeners.set(event_name, n);
			}
			root_event_handles.delete(event_handle);
			if (anchor_node !== anchor) anchor_node.parentNode?.removeChild(anchor_node);
		};
	});
	mounted_components.set(component, unmount$1);
	return component;
}
/**
* References of the components that were mounted or hydrated.
* Uses a `WeakMap` to avoid memory leaks.
*/
let mounted_components = /* @__PURE__ */ new WeakMap();
/**
* Unmounts a component that was previously mounted using `mount` or `hydrate`.
*
* Since 5.13.0, if `options.outro` is `true`, [transitions](https://svelte.dev/docs/svelte/transition) will play before the component is removed from the DOM.
*
* Returns a `Promise` that resolves after transitions have completed if `options.outro` is true, or immediately otherwise (prior to 5.13.0, returns `void`).
*
* ```js
* import { mount, unmount } from 'svelte';
* import App from './App.svelte';
*
* const app = mount(App, { target: document.body });
*
* // later...
* unmount(app, { outro: true });
* ```
* @param {Record<string, any>} component
* @param {{ outro?: boolean }} [options]
* @returns {Promise<void>}
*/
function unmount(component, options) {
	const fn = mounted_components.get(component);
	if (fn) {
		mounted_components.delete(component);
		return fn(options);
	}
	if (dev_fallback_default) if (STATE_SYMBOL in component) state_proxy_unmount();
	else lifecycle_double_unmount();
	return Promise.resolve();
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/blocks/branches.js
/**
* @typedef {{ effect: Effect, fragment: DocumentFragment }} Branch
*/
/**
* @template Key
*/
var BranchManager = class {
	/** @type {TemplateNode} */
	anchor;
	/** @type {Map<Batch, Key>} */
	#batches = /* @__PURE__ */ new Map();
	/**
	* Map of keys to effects that are currently rendered in the DOM.
	* These effects are visible and actively part of the document tree.
	* Example:
	* ```
	* {#if condition}
	* 	foo
	* {:else}
	* 	bar
	* {/if}
	* ```
	* Can result in the entries `true->Effect` and `false->Effect`
	* @type {Map<Key, Effect>}
	*/
	#onscreen = /* @__PURE__ */ new Map();
	/**
	* Similar to #onscreen with respect to the keys, but contains branches that are not yet
	* in the DOM, because their insertion is deferred.
	* @type {Map<Key, Branch>}
	*/
	#offscreen = /* @__PURE__ */ new Map();
	/**
	* Keys of effects that are currently outroing
	* @type {Set<Key>}
	*/
	#outroing = /* @__PURE__ */ new Set();
	/**
	* Whether to pause (i.e. outro) on change, or destroy immediately.
	* This is necessary for `<svelte:element>`
	*/
	#transition = true;
	/**
	* @param {TemplateNode} anchor
	* @param {boolean} transition
	*/
	constructor(anchor, transition = true) {
		this.anchor = anchor;
		this.#transition = transition;
	}
	#commit = () => {
		var batch = current_batch;
		if (!this.#batches.has(batch)) return;
		var key = this.#batches.get(batch);
		var onscreen = this.#onscreen.get(key);
		if (onscreen) {
			resume_effect(onscreen);
			this.#outroing.delete(key);
		} else {
			var offscreen = this.#offscreen.get(key);
			if (offscreen) {
				this.#onscreen.set(key, offscreen.effect);
				this.#offscreen.delete(key);
				/** @type {TemplateNode} */ offscreen.fragment.lastChild.remove();
				this.anchor.before(offscreen.fragment);
				onscreen = offscreen.effect;
			}
		}
		for (const [b, k] of this.#batches) {
			this.#batches.delete(b);
			if (b === batch) break;
			const offscreen$1 = this.#offscreen.get(k);
			if (offscreen$1) {
				destroy_effect(offscreen$1.effect);
				this.#offscreen.delete(k);
			}
		}
		for (const [k, effect$1] of this.#onscreen) {
			if (k === key || this.#outroing.has(k)) continue;
			const on_destroy = () => {
				const keys = Array.from(this.#batches.values());
				if (keys.includes(k)) {
					var fragment = document.createDocumentFragment();
					move_effect(effect$1, fragment);
					fragment.append(create_text());
					this.#offscreen.set(k, {
						effect: effect$1,
						fragment
					});
				} else destroy_effect(effect$1);
				this.#outroing.delete(k);
				this.#onscreen.delete(k);
			};
			if (this.#transition || !onscreen) {
				this.#outroing.add(k);
				pause_effect(effect$1, on_destroy, false);
			} else on_destroy();
		}
	};
	/**
	* @param {Batch} batch
	*/
	#discard = (batch) => {
		this.#batches.delete(batch);
		const keys = Array.from(this.#batches.values());
		for (const [k, branch$1] of this.#offscreen) if (!keys.includes(k)) {
			destroy_effect(branch$1.effect);
			this.#offscreen.delete(k);
		}
	};
	/**
	*
	* @param {any} key
	* @param {null | ((target: TemplateNode) => void)} fn
	*/
	ensure(key, fn) {
		var batch = current_batch;
		var defer = should_defer_append();
		if (fn && !this.#onscreen.has(key) && !this.#offscreen.has(key)) if (defer) {
			var fragment = document.createDocumentFragment();
			var target = create_text();
			fragment.append(target);
			this.#offscreen.set(key, {
				effect: branch(() => fn(target)),
				fragment
			});
		} else this.#onscreen.set(key, branch(() => fn(this.anchor)));
		this.#batches.set(batch, key);
		if (defer) {
			for (const [k, effect$1] of this.#onscreen) if (k === key) batch.skipped_effects.delete(effect$1);
			else batch.skipped_effects.add(effect$1);
			for (const [k, branch$1] of this.#offscreen) if (k === key) batch.skipped_effects.delete(branch$1.effect);
			else batch.skipped_effects.add(branch$1.effect);
			batch.oncommit(this.#commit);
			batch.ondiscard(this.#discard);
		} else {
			if (hydrating) this.anchor = hydrate_node;
			this.#commit();
		}
	}
};

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/blocks/if.js
/**
* @param {TemplateNode} node
* @param {(branch: (fn: (anchor: Node) => void, flag?: boolean) => void) => void} fn
* @param {boolean} [elseif] True if this is an `{:else if ...}` block rather than an `{#if ...}`, as that affects which transitions are considered 'local'
* @returns {void}
*/
function if_block(node, fn, elseif = false) {
	if (hydrating) hydrate_next();
	var branches = new BranchManager(node);
	var flags$1 = elseif ? EFFECT_TRANSPARENT : 0;
	/**
	* @param {boolean} condition,
	* @param {null | ((anchor: Node) => void)} fn
	*/
	function update_branch(condition, fn$1) {
		if (hydrating) {
			const is_else = read_hydration_instruction(node) === HYDRATION_START_ELSE;
			if (condition === is_else) {
				var anchor = skip_nodes();
				set_hydrate_node(anchor);
				branches.anchor = anchor;
				set_hydrating(false);
				branches.ensure(condition, fn$1);
				set_hydrating(true);
				return;
			}
		}
		branches.ensure(condition, fn$1);
	}
	block(() => {
		var has_branch = false;
		fn((fn$1, flag = true) => {
			has_branch = true;
			update_branch(flag, fn$1);
		});
		if (!has_branch) update_branch(false, null);
	}, flags$1);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/shared/attributes.js
const whitespace = [..." 	\n\r\f\xA0\v﻿"];
/**
*
* @param {Record<string,any>} styles
* @param {boolean} important
*/
function append_styles(styles, important = false) {
	var separator = important ? " !important;" : ";";
	var css = "";
	for (var key in styles) {
		var value = styles[key];
		if (value != null && value !== "") css += " " + key + ": " + value + separator;
	}
	return css;
}
/**
* @param {string} name
* @returns {string}
*/
function to_css_name(name) {
	if (name[0] !== "-" || name[1] !== "-") return name.toLowerCase();
	return name;
}
/**
* @param {any} value
* @param {Record<string, any> | [Record<string, any>, Record<string, any>]} [styles]
* @returns {string | null}
*/
function to_style(value, styles) {
	if (styles) {
		var new_style = "";
		/** @type {Record<string,any> | undefined} */
		var normal_styles;
		/** @type {Record<string,any> | undefined} */
		var important_styles;
		if (Array.isArray(styles)) {
			normal_styles = styles[0];
			important_styles = styles[1];
		} else normal_styles = styles;
		if (value) {
			value = String(value).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
			/** @type {boolean | '"' | "'"} */
			var in_str = false;
			var in_apo = 0;
			var in_comment = false;
			var reserved_names = [];
			if (normal_styles) reserved_names.push(...Object.keys(normal_styles).map(to_css_name));
			if (important_styles) reserved_names.push(...Object.keys(important_styles).map(to_css_name));
			var start_index = 0;
			var name_index = -1;
			const len = value.length;
			for (var i = 0; i < len; i++) {
				var c = value[i];
				if (in_comment) {
					if (c === "/" && value[i - 1] === "*") in_comment = false;
				} else if (in_str) {
					if (in_str === c) in_str = false;
				} else if (c === "/" && value[i + 1] === "*") in_comment = true;
				else if (c === "\"" || c === "'") in_str = c;
				else if (c === "(") in_apo++;
				else if (c === ")") in_apo--;
				if (!in_comment && in_str === false && in_apo === 0) {
					if (c === ":" && name_index === -1) name_index = i;
					else if (c === ";" || i === len - 1) {
						if (name_index !== -1) {
							var name = to_css_name(value.substring(start_index, name_index).trim());
							if (!reserved_names.includes(name)) {
								if (c !== ";") i++;
								var property = value.substring(start_index, i).trim();
								new_style += " " + property + ";";
							}
						}
						start_index = i + 1;
						name_index = -1;
					}
				}
			}
		}
		if (normal_styles) new_style += append_styles(normal_styles);
		if (important_styles) new_style += append_styles(important_styles, true);
		new_style = new_style.trim();
		return new_style === "" ? null : new_style;
	}
	return value == null ? null : String(value);
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/elements/style.js
/**
* @param {Element & ElementCSSInlineStyle} dom
* @param {Record<string, any>} prev
* @param {Record<string, any>} next
* @param {string} [priority]
*/
function update_styles(dom, prev = {}, next$1, priority) {
	for (var key in next$1) {
		var value = next$1[key];
		if (prev[key] !== value) if (next$1[key] == null) dom.style.removeProperty(key);
		else dom.style.setProperty(key, value, priority);
	}
}
/**
* @param {Element & ElementCSSInlineStyle} dom
* @param {string | null} value
* @param {Record<string, any> | [Record<string, any>, Record<string, any>]} [prev_styles]
* @param {Record<string, any> | [Record<string, any>, Record<string, any>]} [next_styles]
*/
function set_style(dom, value, prev_styles, next_styles) {
	var prev = dom.__style;
	if (hydrating || prev !== value) {
		var next_style_attr = to_style(value, next_styles);
		if (!hydrating || next_style_attr !== dom.getAttribute("style")) if (next_style_attr == null) dom.removeAttribute("style");
		else dom.style.cssText = next_style_attr;
		dom.__style = value;
	} else if (next_styles) if (Array.isArray(next_styles)) {
		update_styles(dom, prev_styles?.[0], next_styles[0]);
		update_styles(dom, prev_styles?.[1], next_styles[1], "important");
	} else update_styles(dom, prev_styles, next_styles);
	return next_styles;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/elements/attributes.js
const CLASS = Symbol("class");
const STYLE = Symbol("style");
const IS_CUSTOM_ELEMENT = Symbol("is custom element");
const IS_HTML = Symbol("is html");
/**
* @param {Element} element
* @param {string} attribute
* @param {string | null} value
* @param {boolean} [skip_warning]
*/
function set_attribute(element, attribute, value, skip_warning) {
	var attributes = get_attributes(element);
	if (hydrating) {
		attributes[attribute] = element.getAttribute(attribute);
		if (attribute === "src" || attribute === "srcset" || attribute === "href" && element.nodeName === "LINK") {
			if (!skip_warning) check_src_in_dev_hydration(element, attribute, value ?? "");
			return;
		}
	}
	if (attributes[attribute] === (attributes[attribute] = value)) return;
	if (attribute === "loading") element[LOADING_ATTR_SYMBOL] = value;
	if (value == null) element.removeAttribute(attribute);
	else if (typeof value !== "string" && get_setters(element).includes(attribute)) element[attribute] = value;
	else element.setAttribute(attribute, value);
}
/**
*
* @param {Element} element
*/
function get_attributes(element) {
	return element.__attributes ??= {
		[IS_CUSTOM_ELEMENT]: element.nodeName.includes("-"),
		[IS_HTML]: element.namespaceURI === NAMESPACE_HTML
	};
}
/** @type {Map<string, string[]>} */
var setters_cache = /* @__PURE__ */ new Map();
/** @param {Element} element */
function get_setters(element) {
	var cache_key = element.getAttribute("is") || element.nodeName;
	var setters = setters_cache.get(cache_key);
	if (setters) return setters;
	setters_cache.set(cache_key, setters = []);
	var descriptors;
	var proto = element;
	var element_proto = Element.prototype;
	while (element_proto !== proto) {
		descriptors = get_descriptors(proto);
		for (var key in descriptors) if (descriptors[key].set) setters.push(key);
		proto = get_prototype_of(proto);
	}
	return setters;
}
/**
* @param {any} element
* @param {string} attribute
* @param {string} value
*/
function check_src_in_dev_hydration(element, attribute, value) {
	if (!dev_fallback_default) return;
	if (attribute === "srcset" && srcset_url_equal(element, value)) return;
	if (src_url_equal(element.getAttribute(attribute) ?? "", value)) return;
	hydration_attribute_changed(attribute, element.outerHTML.replace(element.innerHTML, element.innerHTML && "..."), String(value));
}
/**
* @param {string} element_src
* @param {string} url
* @returns {boolean}
*/
function src_url_equal(element_src, url) {
	if (element_src === url) return true;
	return new URL(element_src, document.baseURI).href === new URL(url, document.baseURI).href;
}
/** @param {string} srcset */
function split_srcset(srcset) {
	return srcset.split(",").map((src) => src.trim().split(" ").filter(Boolean));
}
/**
* @param {HTMLSourceElement | HTMLImageElement} element
* @param {string} srcset
* @returns {boolean}
*/
function srcset_url_equal(element, srcset) {
	var element_urls = split_srcset(element.srcset);
	var urls = split_srcset(srcset);
	return urls.length === element_urls.length && urls.every(([url, width], i) => width === element_urls[i][1] && (src_url_equal(element_urls[i][0], url) || src_url_equal(url, element_urls[i][0])));
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/elements/bindings/this.js
/**
* @param {any} bound_value
* @param {Element} element_or_component
* @returns {boolean}
*/
function is_bound_this(bound_value, element_or_component) {
	return bound_value === element_or_component || bound_value?.[STATE_SYMBOL] === element_or_component;
}
/**
* @param {any} element_or_component
* @param {(value: unknown, ...parts: unknown[]) => void} update
* @param {(...parts: unknown[]) => unknown} get_value
* @param {() => unknown[]} [get_parts] Set if the this binding is used inside an each block,
* 										returns all the parts of the each block context that are used in the expression
* @returns {void}
*/
function bind_this(element_or_component = {}, update$1, get_value, get_parts) {
	effect(() => {
		/** @type {unknown[]} */
		var old_parts;
		/** @type {unknown[]} */
		var parts;
		render_effect(() => {
			old_parts = parts;
			parts = get_parts?.() || [];
			untrack(() => {
				if (element_or_component !== get_value(...parts)) {
					update$1(element_or_component, ...parts);
					if (old_parts && is_bound_this(get_value(...old_parts), element_or_component)) update$1(null, ...old_parts);
				}
			});
		});
		return () => {
			queue_micro_task(() => {
				if (parts && is_bound_this(get_value(...parts), element_or_component)) update$1(null, ...parts);
			});
		};
	});
	return element_or_component;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/reactivity/store.js
let IS_UNMOUNTED = Symbol();

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/legacy/legacy-client.js
/**
* Takes the same options as a Svelte 4 component and the component function and returns a Svelte 4 compatible component.
*
* @deprecated Use this only as a temporary solution to migrate your imperative component code to Svelte 5.
*
* @template {Record<string, any>} Props
* @template {Record<string, any>} Exports
* @template {Record<string, any>} Events
* @template {Record<string, any>} Slots
*
* @param {ComponentConstructorOptions<Props> & {
* 	component: ComponentType<SvelteComponent<Props, Events, Slots>> | Component<Props>;
* }} options
* @returns {SvelteComponent<Props, Events, Slots> & Exports}
*/
function createClassComponent(options) {
	return new Svelte4Component(options);
}
/**
* Support using the component as both a class and function during the transition period
* @typedef  {{new (o: ComponentConstructorOptions): SvelteComponent;(...args: Parameters<Component<Record<string, any>>>): ReturnType<Component<Record<string, any>, Record<string, any>>>;}} LegacyComponentType
*/
var Svelte4Component = class {
	/** @type {any} */
	#events;
	/** @type {Record<string, any>} */
	#instance;
	/**
	* @param {ComponentConstructorOptions & {
	*  component: any;
	* }} options
	*/
	constructor(options) {
		var sources = /* @__PURE__ */ new Map();
		/**
		* @param {string | symbol} key
		* @param {unknown} value
		*/
		var add_source = (key, value) => {
			var s = mutable_source(value, false, false);
			sources.set(key, s);
			return s;
		};
		const props = new Proxy({
			...options.props || {},
			$$events: {}
		}, {
			get(target, prop) {
				return get(sources.get(prop) ?? add_source(prop, Reflect.get(target, prop)));
			},
			has(target, prop) {
				if (prop === LEGACY_PROPS) return true;
				get(sources.get(prop) ?? add_source(prop, Reflect.get(target, prop)));
				return Reflect.has(target, prop);
			},
			set(target, prop, value) {
				set(sources.get(prop) ?? add_source(prop, value), value);
				return Reflect.set(target, prop, value);
			}
		});
		this.#instance = (options.hydrate ? hydrate : mount)(options.component, {
			target: options.target,
			anchor: options.anchor,
			props,
			context: options.context,
			intro: options.intro ?? false,
			recover: options.recover
		});
		if (!async_mode_flag && (!options?.props?.$$host || options.sync === false)) flushSync();
		this.#events = props.$$events;
		for (const key of Object.keys(this.#instance)) {
			if (key === "$set" || key === "$destroy" || key === "$on") continue;
			define_property(this, key, {
				get() {
					return this.#instance[key];
				},
				set(value) {
					this.#instance[key] = value;
				},
				enumerable: true
			});
		}
		this.#instance.$set = (next$1) => {
			Object.assign(props, next$1);
		};
		this.#instance.$destroy = () => {
			unmount(this.#instance);
		};
	}
	/** @param {Record<string, any>} props */
	$set(props) {
		this.#instance.$set(props);
	}
	/**
	* @param {string} event
	* @param {(...args: any[]) => any} callback
	* @returns {any}
	*/
	$on(event$1, callback) {
		this.#events[event$1] = this.#events[event$1] || [];
		/** @param {any[]} args */
		const cb = (...args) => callback.call(this, ...args);
		this.#events[event$1].push(cb);
		return () => {
			this.#events[event$1] = this.#events[event$1].filter(
				/** @param {any} fn */
				(fn) => fn !== cb
			);
		};
	}
	$destroy() {
		this.#instance.$destroy();
	}
};

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/client/dom/elements/custom-element.js
/**
* @typedef {Object} CustomElementPropDefinition
* @property {string} [attribute]
* @property {boolean} [reflect]
* @property {'String'|'Boolean'|'Number'|'Array'|'Object'} [type]
*/
/** @type {any} */
let SvelteElement;
if (typeof HTMLElement === "function") SvelteElement = class extends HTMLElement {
	/** The Svelte component constructor */
	$$ctor;
	/** Slots */
	$$s;
	/** @type {any} The Svelte component instance */
	$$c;
	/** Whether or not the custom element is connected */
	$$cn = false;
	/** @type {Record<string, any>} Component props data */
	$$d = {};
	/** `true` if currently in the process of reflecting component props back to attributes */
	$$r = false;
	/** @type {Record<string, CustomElementPropDefinition>} Props definition (name, reflected, type etc) */
	$$p_d = {};
	/** @type {Record<string, EventListenerOrEventListenerObject[]>} Event listeners */
	$$l = {};
	/** @type {Map<EventListenerOrEventListenerObject, Function>} Event listener unsubscribe functions */
	$$l_u = /* @__PURE__ */ new Map();
	/** @type {any} The managed render effect for reflecting attributes */
	$$me;
	/**
	* @param {*} $$componentCtor
	* @param {*} $$slots
	* @param {*} use_shadow_dom
	*/
	constructor($$componentCtor, $$slots, use_shadow_dom) {
		super();
		this.$$ctor = $$componentCtor;
		this.$$s = $$slots;
		if (use_shadow_dom) this.attachShadow({ mode: "open" });
	}
	/**
	* @param {string} type
	* @param {EventListenerOrEventListenerObject} listener
	* @param {boolean | AddEventListenerOptions} [options]
	*/
	addEventListener(type, listener, options) {
		this.$$l[type] = this.$$l[type] || [];
		this.$$l[type].push(listener);
		if (this.$$c) {
			const unsub = this.$$c.$on(type, listener);
			this.$$l_u.set(listener, unsub);
		}
		super.addEventListener(type, listener, options);
	}
	/**
	* @param {string} type
	* @param {EventListenerOrEventListenerObject} listener
	* @param {boolean | AddEventListenerOptions} [options]
	*/
	removeEventListener(type, listener, options) {
		super.removeEventListener(type, listener, options);
		if (this.$$c) {
			const unsub = this.$$l_u.get(listener);
			if (unsub) {
				unsub();
				this.$$l_u.delete(listener);
			}
		}
	}
	async connectedCallback() {
		this.$$cn = true;
		if (!this.$$c) {
			await Promise.resolve();
			if (!this.$$cn || this.$$c) return;
			/** @param {string} name */
			function create_slot(name) {
				/**
				* @param {Element} anchor
				*/
				return (anchor) => {
					const slot = document.createElement("slot");
					if (name !== "default") slot.name = name;
					append(anchor, slot);
				};
			}
			/** @type {Record<string, any>} */
			const $$slots = {};
			const existing_slots = get_custom_elements_slots(this);
			for (const name of this.$$s) if (name in existing_slots) if (name === "default" && !this.$$d.children) {
				this.$$d.children = create_slot(name);
				$$slots.default = true;
			} else $$slots[name] = create_slot(name);
			for (const attribute of this.attributes) {
				const name = this.$$g_p(attribute.name);
				if (!(name in this.$$d)) this.$$d[name] = get_custom_element_value(name, attribute.value, this.$$p_d, "toProp");
			}
			for (const key in this.$$p_d) if (!(key in this.$$d) && this[key] !== void 0) {
				this.$$d[key] = this[key];
				delete this[key];
			}
			this.$$c = createClassComponent({
				component: this.$$ctor,
				target: this.shadowRoot || this,
				props: {
					...this.$$d,
					$$slots,
					$$host: this
				}
			});
			this.$$me = effect_root(() => {
				render_effect(() => {
					this.$$r = true;
					for (const key of object_keys(this.$$c)) {
						if (!this.$$p_d[key]?.reflect) continue;
						this.$$d[key] = this.$$c[key];
						const attribute_value = get_custom_element_value(key, this.$$d[key], this.$$p_d, "toAttribute");
						if (attribute_value == null) this.removeAttribute(this.$$p_d[key].attribute || key);
						else this.setAttribute(this.$$p_d[key].attribute || key, attribute_value);
					}
					this.$$r = false;
				});
			});
			for (const type in this.$$l) for (const listener of this.$$l[type]) {
				const unsub = this.$$c.$on(type, listener);
				this.$$l_u.set(listener, unsub);
			}
			this.$$l = {};
		}
	}
	/**
	* @param {string} attr
	* @param {string} _oldValue
	* @param {string} newValue
	*/
	attributeChangedCallback(attr, _oldValue, newValue) {
		if (this.$$r) return;
		attr = this.$$g_p(attr);
		this.$$d[attr] = get_custom_element_value(attr, newValue, this.$$p_d, "toProp");
		this.$$c?.$set({ [attr]: this.$$d[attr] });
	}
	disconnectedCallback() {
		this.$$cn = false;
		Promise.resolve().then(() => {
			if (!this.$$cn && this.$$c) {
				this.$$c.$destroy();
				this.$$me();
				this.$$c = void 0;
			}
		});
	}
	/**
	* @param {string} attribute_name
	*/
	$$g_p(attribute_name) {
		return object_keys(this.$$p_d).find((key) => this.$$p_d[key].attribute === attribute_name || !this.$$p_d[key].attribute && key.toLowerCase() === attribute_name) || attribute_name;
	}
};
/**
* @param {string} prop
* @param {any} value
* @param {Record<string, CustomElementPropDefinition>} props_definition
* @param {'toAttribute' | 'toProp'} [transform]
*/
function get_custom_element_value(prop, value, props_definition, transform) {
	const type = props_definition[prop]?.type;
	value = type === "Boolean" && typeof value !== "boolean" ? value != null : value;
	if (!transform || !props_definition[prop]) return value;
	else if (transform === "toAttribute") switch (type) {
		case "Object":
		case "Array": return value == null ? null : JSON.stringify(value);
		case "Boolean": return value ? "" : null;
		case "Number": return value == null ? null : value;
		default: return value;
	}
	else switch (type) {
		case "Object":
		case "Array": return value && JSON.parse(value);
		case "Boolean": return value;
		case "Number": return value != null ? +value : value;
		default: return value;
	}
}
/**
* @param {HTMLElement} element
*/
function get_custom_elements_slots(element) {
	/** @type {Record<string, true>} */
	const result = {};
	element.childNodes.forEach((node) => {
		result[node.slot || "default"] = true;
	});
	return result;
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/index-client.js
if (dev_fallback_default) {
	/**
	* @param {string} rune
	*/
	function throw_rune_error(rune) {
		if (!(rune in globalThis)) {
			/** @type {any} */
			let value;
			Object.defineProperty(globalThis, rune, {
				configurable: true,
				get: () => {
					if (value !== void 0) return value;
					rune_outside_svelte(rune);
				},
				set: (v) => {
					value = v;
				}
			});
		}
	}
	throw_rune_error("$state");
	throw_rune_error("$effect");
	throw_rune_error("$derived");
	throw_rune_error("$inspect");
	throw_rune_error("$props");
	throw_rune_error("$bindable");
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/reactivity/url-search-params.js
const REPLACE = Symbol();
/**
* A reactive version of the built-in [`URLSearchParams`](https://developer.mozilla.org/en-US/docs/Web/API/URLSearchParams) object.
* Reading its contents (by iterating, or by calling `params.get(...)` or `params.getAll(...)` as in the [example](https://svelte.dev/playground/b3926c86c5384bab9f2cf993bc08c1c8) below) in an [effect](https://svelte.dev/docs/svelte/$effect) or [derived](https://svelte.dev/docs/svelte/$derived)
* will cause it to be re-evaluated as necessary when the params are updated.
*
* ```svelte
* <script>
* 	import { SvelteURLSearchParams } from 'svelte/reactivity';
*
* 	const params = new SvelteURLSearchParams('message=hello');
*
* 	let key = $state('key');
* 	let value = $state('value');
* </script>
*
* <input bind:value={key} />
* <input bind:value={value} />
* <button onclick={() => params.append(key, value)}>append</button>
*
* <p>?{params.toString()}</p>
*
* {#each params as [key, value]}
* 	<p>{key}: {value}</p>
* {/each}
* ```
*/
var SvelteURLSearchParams = class extends URLSearchParams {
	#version = dev_fallback_default ? tag(state(0), "SvelteURLSearchParams version") : state(0);
	#url = get_current_url();
	#updating = false;
	#update_url() {
		if (!this.#url || this.#updating) return;
		this.#updating = true;
		const search = this.toString();
		this.#url.search = search && `?${search}`;
		this.#updating = false;
	}
	/**
	* @param {URLSearchParams} params
	* @internal
	*/
	[REPLACE](params) {
		if (this.#updating) return;
		this.#updating = true;
		for (const key of [...super.keys()]) super.delete(key);
		for (const [key, value] of params) super.append(key, value);
		increment(this.#version);
		this.#updating = false;
	}
	/**
	* @param {string} name
	* @param {string} value
	* @returns {void}
	*/
	append(name, value) {
		super.append(name, value);
		this.#update_url();
		increment(this.#version);
	}
	/**
	* @param {string} name
	* @param {string=} value
	* @returns {void}
	*/
	delete(name, value) {
		var has_value = super.has(name, value);
		super.delete(name, value);
		if (has_value) {
			this.#update_url();
			increment(this.#version);
		}
	}
	/**
	* @param {string} name
	* @returns {string|null}
	*/
	get(name) {
		get(this.#version);
		return super.get(name);
	}
	/**
	* @param {string} name
	* @returns {string[]}
	*/
	getAll(name) {
		get(this.#version);
		return super.getAll(name);
	}
	/**
	* @param {string} name
	* @param {string=} value
	* @returns {boolean}
	*/
	has(name, value) {
		get(this.#version);
		return super.has(name, value);
	}
	keys() {
		get(this.#version);
		return super.keys();
	}
	/**
	* @param {string} name
	* @param {string} value
	* @returns {void}
	*/
	set(name, value) {
		var previous = super.getAll(name).join("");
		super.set(name, value);
		if (previous !== super.getAll(name).join("")) {
			this.#update_url();
			increment(this.#version);
		}
	}
	sort() {
		super.sort();
		this.#update_url();
		increment(this.#version);
	}
	toString() {
		get(this.#version);
		return super.toString();
	}
	values() {
		get(this.#version);
		return super.values();
	}
	entries() {
		get(this.#version);
		return super.entries();
	}
	[Symbol.iterator]() {
		return this.entries();
	}
	get size() {
		get(this.#version);
		return super.size;
	}
};

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/reactivity/url.js
/** @type {SvelteURL | null} */
let current_url = null;
function get_current_url() {
	return current_url;
}

//#endregion
//#region node_modules/.pnpm/@anywidget+svelte@0.1.0_svelte@5.43.14/node_modules/@anywidget/svelte/src/index.js
/** @import * as svelte from "svelte" */
/** @import { AnyWidget, AnyModel } from "@anywidget/types" */
/**
* @template {Record<string, any>} T
* @param {AnyModel<T>} model
* @returns T
*/
function createBindings(model) {
	/** @type {Record<string, () => void>} */
	let subscribes = {};
	return new Proxy({}, {
		get(_, name) {
			if (!(name in subscribes)) subscribes[name] = createSubscriber((update$1) => {
				model.on(`change:${name}`, update$1);
				return () => model.off(`change:${name}`, update$1);
			});
			subscribes[name]();
			return model.get(name);
		},
		set(_, name, newValue) {
			model.set(name, newValue);
			model.save_changes();
			return true;
		}
	});
}
/**
* Wraps a Svelte component as an anywidget with reactive model bindings.
*
* Sets up two-way binding between the model and Svelte's reactivity.
*
* @example
* ```ts
* import { defineWidget } from "@anywidget/svelte";
* import Widget from "./Widget.svelte";
*
* export default defineWidget(Widget);
* ```
*
* @template {Record<string, any>} T
* @param {svelte.Component<{ model?: AnyModel<T>, bindings?: T }>} Widget
* @returns {AnyWidget<T>}
*/
function defineWidget(Widget$1) {
	return () => {
		/** @type {T | undefined} */
		let bindings = void 0;
		return {
			initialize({ model }) {
				bindings = createBindings(model);
			},
			render({ model, el }) {
				let app = mount(Widget$1, {
					target: el,
					props: {
						model,
						bindings
					}
				});
				return () => unmount(app);
			}
		};
	};
}

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/version.js
const PUBLIC_VERSION = "5";

//#endregion
//#region node_modules/.pnpm/svelte@5.43.14/node_modules/svelte/src/internal/disclose-version.js
if (typeof window !== "undefined") ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add(PUBLIC_VERSION);

//#endregion
//#region web/Entity.svelte
var root_2 = from_html(`<span class="badge bg-yellow-400 text-yellow-900 text-xs px-2 py-0.5 rounded font-semibold">PK</span>`);
var root_3 = from_html(`<span class="badge bg-green-400 text-green-900 text-xs px-2 py-0.5 rounded font-semibold">FK</span>`);
var root_1$1 = from_html(`<div class="attribute-row px-4 py-2 border-b border-gray-200 last:border-b-0 flex items-center justify-between"><div class="flex items-center gap-2 flex-1"><span class="attribute-name font-medium text-gray-800"> </span> <span class="attribute-type text-sm text-gray-500"> </span></div> <div class="flex items-center gap-1"><!> <!></div></div>`);
var root$1 = from_html(`<div class="absolute cursor-move bg-white border-2 border-gray-800 rounded-lg shadow-lg min-w-[200px] select-none active:cursor-grabbing focus:outline-none" role="button" tabindex="0"><div class="entity-header bg-blue-600 text-white font-bold px-4 py-2 rounded-t-md"> </div> <div class="entity-attributes"></div></div>`);
function Entity($$anchor, $$props) {
	push($$props, true);
	var div = root$1();
	div.__mousedown = (e) => {
		e.preventDefault();
		$$props.onDragStart(e);
	};
	var div_1 = child(div);
	var text$1 = child(div_1, true);
	reset(div_1);
	var div_2 = sibling(div_1, 2);
	each(div_2, 21, () => $$props.entity.attributes, index, ($$anchor$1, attr) => {
		var div_3 = root_1$1();
		var div_4 = child(div_3);
		var span = child(div_4);
		var text_1 = child(span, true);
		reset(span);
		var span_1 = sibling(span, 2);
		var text_2 = child(span_1);
		reset(span_1);
		reset(div_4);
		var div_5 = sibling(div_4, 2);
		var node = child(div_5);
		{
			var consequent = ($$anchor$2) => {
				var span_2 = root_2();
				append($$anchor$2, span_2);
			};
			if_block(node, ($$render) => {
				if (get(attr).primary_key) $$render(consequent);
			});
		}
		var node_1 = sibling(node, 2);
		{
			var consequent_1 = ($$anchor$2) => {
				var span_3 = root_3();
				append($$anchor$2, span_3);
			};
			if_block(node_1, ($$render) => {
				if (get(attr).foreign_key) $$render(consequent_1);
			});
		}
		reset(div_5);
		reset(div_3);
		template_effect(() => {
			set_text(text_1, get(attr).name);
			set_text(text_2, `(${get(attr).datatype ?? ""})`);
		});
		append($$anchor$1, div_3);
	});
	reset(div_2);
	reset(div);
	template_effect(() => {
		set_style(div, `left: ${$$props.x ?? ""}px; top: ${$$props.y ?? ""}px;`);
		set_text(text$1, $$props.entity.name);
	});
	append($$anchor, div);
	pop();
}
delegate(["mousedown"]);

//#endregion
//#region web/Widget.svelte
var root_1 = from_svg(`<line stroke="#4B5563" stroke-width="2" marker-end="url(#arrowhead)"></line>`);
var root = from_html(`<div class="relative bg-gray-50 font-sans border border-gray-300 rounded-lg w-full"><div class="relative w-full"><svg class="absolute inset-0 pointer-events-none z-0 w-full h-full"><!><defs><marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto"><polygon points="0 0, 10 3, 0 6" fill="#4B5563"></polygon></marker></defs></svg> <div class="entities-container relative z-10"></div></div> <button class="absolute bottom-4 right-4 bg-blue-600 text-white px-4 py-2 rounded-lg shadow-lg hover:bg-blue-700 transition-colors z-20">Auto Layout</button></div>`);
function Widget($$anchor, $$props) {
	push($$props, true);
	/** @type {{ bindings: { entities: Array<any>, width: number, height: number } }}*/
	let entityPositions = state(proxy(/* @__PURE__ */ new Map()));
	let draggedEntity = state(null);
	let dragOffset = state(proxy({
		x: 0,
		y: 0
	}));
	let isDragging = state(false);
	let containerRef = state(null);
	let canvasRef = state(null);
	let measuredWidth = state(1e3);
	const containerWidth = user_derived(() => $$props.bindings.width && $$props.bindings.width > 0 ? $$props.bindings.width : get(measuredWidth));
	const containerHeight = user_derived(() => $$props.bindings.height ?? 700);
	user_effect(() => {
		if (!get(containerRef)) return;
		const resizeObserver = new ResizeObserver((entries) => {
			for (const entry of entries) {
				const width = entry.contentRect.width;
				if (width > 0) set(measuredWidth, width, true);
			}
		});
		const parent = get(containerRef).parentElement;
		if (parent) {
			resizeObserver.observe(parent);
			const initialWidth = parent.getBoundingClientRect().width;
			if (initialWidth > 0) set(measuredWidth, initialWidth, true);
		}
		return () => {
			resizeObserver.disconnect();
		};
	});
	user_effect(() => {
		const entities = $$props.bindings.entities || [];
		if (entities.length > 0) {
			const currentEntityNames = new Set(Array.from(get(entityPositions).keys()));
			const newEntityNames = new Set(entities.map((e) => e.name));
			if (currentEntityNames.size !== newEntityNames.size || ![...currentEntityNames].every((name) => newEntityNames.has(name))) autoLayout(entities);
		}
	});
	function autoLayout(entities) {
		const positions = /* @__PURE__ */ new Map();
		const centerX = get(containerWidth) / 2;
		const centerY = get(containerHeight) / 2;
		const radius = Math.min(get(containerWidth), get(containerHeight)) / 3;
		if (entities.length === 1) positions.set(entities[0].name, {
			x: centerX - 100,
			y: centerY - 100
		});
		else entities.forEach((entity, index$1) => {
			const angle = 2 * Math.PI * index$1 / entities.length;
			const x = centerX + radius * Math.cos(angle) - 100;
			const y = centerY + radius * Math.sin(angle) - 100;
			positions.set(entity.name, {
				x,
				y
			});
		});
		set(entityPositions, positions, true);
	}
	function getEntityPosition(entityName) {
		return get(entityPositions).get(entityName) || {
			x: 100,
			y: 100
		};
	}
	function setEntityPosition(entityName, x, y) {
		const newPositions = new Map(get(entityPositions));
		newPositions.set(entityName, {
			x,
			y
		});
		set(entityPositions, newPositions, true);
	}
	function handleDragStart(entityName, event$1) {
		if (!get(canvasRef)) return;
		const pos = getEntityPosition(entityName);
		const rect = get(canvasRef).getBoundingClientRect();
		set(draggedEntity, entityName, true);
		set(dragOffset, {
			x: event$1.clientX - rect.left - pos.x,
			y: event$1.clientY - rect.top - pos.y
		}, true);
		set(isDragging, true);
		const handleMouseMove = (e) => {
			if (get(draggedEntity) && get(canvasRef)) {
				const rect$1 = get(canvasRef).getBoundingClientRect();
				const newX = e.clientX - rect$1.left - get(dragOffset).x;
				const newY = e.clientY - rect$1.top - get(dragOffset).y;
				const constrainedX = Math.max(0, Math.min(newX, get(containerWidth) - 200));
				const constrainedY = Math.max(0, Math.min(newY, get(containerHeight) - 100));
				setEntityPosition(get(draggedEntity), constrainedX, constrainedY);
			}
		};
		const handleMouseUp = () => {
			set(isDragging, false);
			set(draggedEntity, null);
			document.removeEventListener("mousemove", handleMouseMove);
			document.removeEventListener("mouseup", handleMouseUp);
		};
		document.addEventListener("mousemove", handleMouseMove);
		document.addEventListener("mouseup", handleMouseUp);
	}
	function getConnectionPoint(entityName, attributeIndex, isSource) {
		const pos = getEntityPosition(entityName);
		const entity = $$props.bindings.entities?.find((e) => e.name === entityName);
		if (!entity) return {
			x: pos.x,
			y: pos.y
		};
		const boxWidth = 200;
		const headerHeight = 40;
		const attributeRowHeight = 40;
		const y = pos.y + headerHeight + attributeIndex * attributeRowHeight + attributeRowHeight / 2;
		const x = isSource ? pos.x + boxWidth : pos.x;
		return {
			x,
			y
		};
	}
	function getRelationships() {
		const entities = $$props.bindings.entities || [];
		const relationships = [];
		entities.forEach((entity) => {
			entity.attributes.forEach((attr, attrIndex) => {
				if (attr.foreign_key) {
					const targetEntity = entities.find((e) => e.name === attr.foreign_key.entity);
					const targetAttrIndex = targetEntity?.attributes.findIndex((a) => a.name === attr.foreign_key.attribute) ?? -1;
					if (targetAttrIndex >= 0) relationships.push({
						from: entity.name,
						to: attr.foreign_key.entity,
						fromAttr: attr.name,
						toAttr: attr.foreign_key.attribute,
						fromAttrIndex: attrIndex,
						toAttrIndex: targetAttrIndex
					});
				}
			});
		});
		return relationships;
	}
	function getEntities() {
		return $$props.bindings.entities || [];
	}
	var div = root();
	var div_1 = child(div);
	var svg = child(div_1);
	var node = child(svg);
	each(node, 17, getRelationships, index, ($$anchor$1, rel) => {
		const fromPos = user_derived(() => getConnectionPoint(get(rel).from, get(rel).fromAttrIndex, true));
		const toPos = user_derived(() => getConnectionPoint(get(rel).to, get(rel).toAttrIndex, false));
		var line = root_1();
		template_effect(() => {
			set_attribute(line, "x1", get(fromPos).x);
			set_attribute(line, "y1", get(fromPos).y);
			set_attribute(line, "x2", get(toPos).x);
			set_attribute(line, "y2", get(toPos).y);
		});
		append($$anchor$1, line);
	});
	next();
	reset(svg);
	var div_2 = sibling(svg, 2);
	each(div_2, 21, getEntities, index, ($$anchor$1, entity) => {
		const pos = user_derived(() => getEntityPosition(get(entity).name));
		Entity($$anchor$1, {
			get entity() {
				return get(entity);
			},
			get x() {
				return get(pos).x;
			},
			get y() {
				return get(pos).y;
			},
			onDragStart: (e) => handleDragStart(get(entity).name, e),
			onDrag: () => {},
			onDragEnd: () => {}
		});
	});
	reset(div_2);
	reset(div_1);
	bind_this(div_1, ($$value) => set(canvasRef, $$value), () => get(canvasRef));
	var button = sibling(div_1, 2);
	button.__click = () => autoLayout(getEntities());
	reset(div);
	bind_this(div, ($$value) => set(containerRef, $$value), () => get(containerRef));
	template_effect(() => {
		set_style(div, `height: ${get(containerHeight) ?? ""}px;`);
		set_style(div_1, `height: ${get(containerHeight) ?? ""}px;`);
	});
	append($$anchor, div);
	pop();
}
delegate(["click"]);

//#endregion
//#region web/index.js
var web_default = defineWidget(Widget);

//#endregion
export { web_default as default };