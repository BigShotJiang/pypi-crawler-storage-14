# MCP Git Analyzer

Git 저장소를 분석하여 코드 구조, 알고리즘 패턴, 문서를 추출하고 DB에 저장하는 MCP 서버입니다.

## Features

- **저장소 클론 및 관리**: Git URL로 저장소 클론, 브랜치 지정 가능
- **코드 분석**: 함수, 클래스, import, docstring 추출
- **패턴 감지**: 알고리즘 패턴 (재귀, DP, 정렬 등) 식별
- **전문 검색**: SQLite FTS5 기반 키워드 검색
- **LLM 친화적**: 구조화된 JSON 응답

## Installation

```bash
uv pip install -e .
```

## Configuration

환경변수로 저장 경로를 설정합니다:

| 환경변수 | 설명 | 기본값 |
|---------|------|--------|
| `GIT_ANALYZER_REPOS_PATH` | 클론된 저장소 저장 경로 | `~/.mcp-git-analyzer/repos` |
| `GIT_ANALYZER_DB_PATH` | SQLite DB 파일 경로 | `~/.mcp-git-analyzer/analysis.db` |

## Claude Desktop 설정

`claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "git-analyzer": {
      "command": "uv",
      "args": ["run", "mcp-git-analyzer"],
      "env": {
        "GIT_ANALYZER_REPOS_PATH": "C:/repos",
        "GIT_ANALYZER_DB_PATH": "C:/repos/analysis.db"
      }
    }
  }
}
```

## Available Tools

### Git 관리
- `clone_repo(url, branch?)` - 저장소 클론
- `list_repos()` - 등록된 저장소 목록
- `get_repo_tree(repo_id)` - 저장소 파일 구조

### 분석
- `analyze_repo(repo_id)` - 전체 저장소 분석
- `get_symbol_details(name)` - 심볼 상세 정보

### 검색
- `search_code(query, type?)` - 코드 검색
- `find_patterns(pattern_type)` - 패턴 검색

## License

MIT
