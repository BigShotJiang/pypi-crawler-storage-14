"""MCP Git Analyzer Server - FastMCP implementation."""

from typing import Annotated, Literal
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass

from mcp.server.fastmcp import FastMCP, Context

from mcp_git_analyzer.db import Database
from mcp_git_analyzer.tools import GitTools, AnalysisTools, SearchTools, ReportTools, AlgorithmTools


@dataclass
class AppContext:
    """Application context with typed dependencies."""
    db: Database
    git: GitTools
    analysis: AnalysisTools
    search: SearchTools
    report: ReportTools
    algorithm: AlgorithmTools


# Lifespan context to manage database and tools
@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Initialize database and tools on startup."""
    db = Database()
    git_tools = GitTools(db)
    analysis_tools = AnalysisTools(db)
    search_tools = SearchTools(db)
    report_tools = ReportTools(db, analysis_tools, search_tools)
    algorithm_tools = AlgorithmTools(db)
    
    yield AppContext(
        db=db,
        git=git_tools,
        analysis=analysis_tools,
        search=search_tools,
        report=report_tools,
        algorithm=algorithm_tools
    )


# Initialize MCP server
mcp = FastMCP(
    "Git Analyzer",
    lifespan=lifespan
)


# ============================================================================
# Git Management Tools
# ============================================================================

@mcp.tool()
def clone_repo(
    url: Annotated[str, "Git repository URL (HTTPS or SSH)"],
    branch: Annotated[str | None, "Branch to checkout (default: repository's default branch)"] = None,
    ctx: Context = None
) -> dict:
    """
    Clone a Git repository for analysis.
    
    Downloads the repository to local storage and registers it in the database.
    Use this before analyzing a repository.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.clone_repo(url, branch)


@mcp.tool()
def list_repos(ctx: Context = None) -> dict:
    """
    List all registered repositories.
    
    Returns all repositories that have been cloned, along with their
    analysis status and basic statistics.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.list_repos()


@mcp.tool()
def get_repo_tree(
    repo_id: Annotated[int, "Repository ID from list_repos"],
    max_depth: Annotated[int, "Maximum directory depth to show"] = 3,
    ctx: Context = None
) -> dict:
    """
    Get the file structure of a repository.
    
    Returns a tree view of directories and files with language detection.
    Useful for understanding project organization.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.get_repo_tree(repo_id, max_depth)


@mcp.tool()
def delete_repo(
    repo_id: Annotated[int, "Repository ID to delete"],
    delete_files: Annotated[bool, "Also delete cloned files from disk"] = False,
    ctx: Context = None
) -> dict:
    """
    Delete a repository from the database.
    
    Removes the repository record and all associated analysis data.
    Optionally deletes the cloned files from disk.
    """
    git: GitTools = ctx.request_context.lifespan_context.git
    return git.delete_repo(repo_id, delete_files)


# ============================================================================
# Analysis Tools
# ============================================================================

@mcp.tool()
async def analyze_repo(
    repo_id: Annotated[int, "Repository ID to analyze"],
    languages: Annotated[list[str] | None, "Languages to analyze (default: all supported)"] = None,
    include_call_graph: Annotated[bool, "Extract function call graph (optional, slower)"] = False,
    ctx: Context = None
) -> dict:
    """
    Analyze all files in a repository.
    
    Parses source code to extract:
    - Functions, classes, and methods with signatures
    - Docstrings and documentation
    - Import statements and dependencies
    - Algorithm and design patterns
    - Function call graph (optional)
    
    Results are stored in the database for future queries.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    
    # Report progress
    msg = f"Starting analysis of repository {repo_id}"
    if include_call_graph:
        msg += " (with call graph extraction)"
    await ctx.info(msg)
    
    result = analysis.analyze_repo(repo_id, languages, include_call_graph)
    
    if result.get("status") == "success":
        stats = result.get("statistics", {})
        msg = f"Completed: {stats.get('analyzed_files', 0)} files, {stats.get('total_symbols', 0)} symbols"
        if include_call_graph:
            msg += f", {stats.get('total_calls', 0)} calls"
        await ctx.info(msg)
    
    return result


@mcp.tool()
def get_file_analysis(
    repo_id: Annotated[int, "Repository ID"],
    file_path: Annotated[str, "Relative path to file within repository"],
    ctx: Context = None
) -> dict:
    """
    Get detailed analysis for a specific file.
    
    Returns all extracted symbols, imports, and detected patterns
    for the specified file.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_file_analysis(repo_id, file_path)


@mcp.tool()
def get_symbol_details(
    symbol_name: Annotated[str, "Name of the symbol (function, class, method)"],
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    ctx: Context = None
) -> dict:
    """
    Get detailed information about a symbol.
    
    Returns signature, docstring, parameters, location, and any
    detected patterns associated with the symbol.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_symbol_details(symbol_name, repo_id)


@mcp.tool()
def get_repo_summary(
    repo_id: Annotated[int, "Repository ID"],
    ctx: Context = None
) -> dict:
    """
    Get comprehensive summary of a repository's analysis.
    
    Returns:
    - Language breakdown with line counts
    - Symbol counts by type
    - Top detected patterns
    - Most used imports/dependencies
    - Key classes and their methods
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_repo_summary(repo_id)


# ============================================================================
# Search Tools
# ============================================================================

@mcp.tool()
def search_code(
    query: Annotated[str, "Search query (supports: AND, OR, NOT, 'phrase', prefix*)"],
    search_type: Annotated[Literal["all", "function", "class", "method"], "Filter by symbol type"] = "all",
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    limit: Annotated[int, "Maximum results to return"] = 20,
    ctx: Context = None
) -> dict:
    """
    Search symbols using full-text search.
    
    Searches across function/class/method names, signatures, and docstrings.
    Use this to find specific functionality in the codebase.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.search_code(query, search_type, repo_id, limit)


@mcp.tool()
def find_patterns(
    pattern_type: Annotated[Literal["algorithm", "design_pattern", "all"], "Type of pattern to find"] = "all",
    pattern_name: Annotated[str | None, "Specific pattern name (e.g., 'recursion', 'singleton')"] = None,
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    min_confidence: Annotated[float, "Minimum confidence threshold (0.0-1.0)"] = 0.5,
    ctx: Context = None
) -> dict:
    """
    Find detected algorithm and design patterns.
    
    Patterns include:
    - Algorithms: recursion, dynamic_programming, binary_search, graph_traversal, etc.
    - Design patterns: singleton, factory, decorator, iterator, context_manager
    
    Returns pattern locations with confidence scores and evidence.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.find_patterns(pattern_type, pattern_name, repo_id, min_confidence)


@mcp.tool()
def find_imports(
    module: Annotated[str | None, "Module name to search for (partial match)"] = None,
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    include_relative: Annotated[bool, "Include relative imports"] = False,
    limit: Annotated[int, "Maximum results to return"] = 50,
    ctx: Context = None
) -> dict:
    """
    Find import statements across the codebase.
    
    Useful for understanding dependencies and how modules are used.
    Returns import locations and a summary of most-used modules.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.find_imports(module, repo_id, include_relative, limit)


@mcp.tool()
def list_symbols(
    repo_id: Annotated[int, "Repository ID"],
    symbol_type: Annotated[Literal["function", "class", "method", "all"], "Filter by symbol type"] = "all",
    file_path: Annotated[str | None, "Filter by specific file path"] = None,
    limit: Annotated[int, "Maximum results to return"] = 100,
    ctx: Context = None
) -> dict:
    """
    List all symbols in a repository.
    
    Returns a comprehensive list of functions, classes, and methods
    with their signatures and locations.
    """
    search: SearchTools = ctx.request_context.lifespan_context.search
    return search.list_symbols(repo_id, symbol_type, file_path, limit)


# ============================================================================
# Call Graph Tools
# ============================================================================

@mcp.tool()
def get_call_graph(
    repo_id: Annotated[int, "Repository ID"],
    symbol_name: Annotated[str | None, "Focus on specific function/method (shows calls to/from it)"] = None,
    depth: Annotated[int, "Maximum traversal depth from target symbol"] = 3,
    direction: Annotated[Literal["callers", "callees", "both"], "Direction to traverse"] = "both",
    output_format: Annotated[Literal["json", "mermaid"], "Output format"] = "json",
    ctx: Context = None
) -> dict:
    """
    Get function call graph for a repository.
    
    Shows which functions call which other functions.
    Can focus on a specific symbol to see its callers and/or callees.
    
    Requires: Run analyze_repo with include_call_graph=True first.
    
    Output formats:
    - json: Structured data with nodes and edges
    - mermaid: Flowchart diagram for visualization
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.get_call_graph(repo_id, symbol_name, depth, direction, output_format)


@mcp.tool()
def find_callers(
    symbol_name: Annotated[str, "Name of the function or method to find callers of"],
    repo_id: Annotated[int | None, "Repository ID to limit search"] = None,
    ctx: Context = None
) -> dict:
    """
    Find all callers of a specific function or method.
    
    Returns a list of all places where this function is called,
    with file paths and line numbers.
    
    Requires: Run analyze_repo with include_call_graph=True first.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.find_callers(symbol_name, repo_id)


@mcp.tool()
def find_callees(
    symbol_name: Annotated[str, "Name of the function or method"],
    repo_id: Annotated[int, "Repository ID"],
    ctx: Context = None
) -> dict:
    """
    Find all functions called by a specific function or method.
    
    Returns a list of all function calls made within this function,
    with line numbers and whether they are external/resolved.
    
    Requires: Run analyze_repo with include_call_graph=True first.
    """
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    return analysis.find_callees(symbol_name, repo_id)


# ============================================================================
# Report Generation Tools
# ============================================================================

@mcp.tool()
def generate_report(
    repo_id: Annotated[int, "Repository ID"],
    report_type: Annotated[
        Literal["summary", "detailed", "dependencies", "architecture"],
        "Type of report: summary (overview), detailed (all data), dependencies (imports), architecture (classes + call graph)"
    ] = "summary",
    output_format: Annotated[
        Literal["json", "markdown", "html"],
        "Output format for the report"
    ] = "markdown",
    save_path: Annotated[str | None, "Optional file path to save the report (adds extension automatically)"] = None,
    ctx: Context = None
) -> dict:
    """
    Generate an analysis report for a repository.
    
    Report types:
    - summary: High-level overview with key statistics, top patterns, key classes
    - detailed: Full analysis with all symbols, patterns, imports, and call graph
    - dependencies: Focus on external/internal dependencies and import analysis
    - architecture: Class hierarchy, file distribution, and Mermaid call graph
    
    Output formats:
    - json: Structured data for programmatic use
    - markdown: Human-readable with tables and formatting
    - html: Styled HTML with Mermaid diagram support
    
    If save_path is provided, the report is saved to that location.
    """
    report: ReportTools = ctx.request_context.lifespan_context.report
    return report.generate_report(repo_id, report_type, output_format, save_path)


# ============================================================================
# Algorithm Analysis Tools
# ============================================================================

@mcp.tool()
async def extract_algorithms(
    repo_id: Annotated[int, "Repository ID to extract algorithms from"],
    min_lines: Annotated[int, "Minimum line count for extraction (default: 5)"] = 5,
    force_reextract: Annotated[bool, "Re-extract even if already exists"] = False,
    ctx: Context = None
) -> dict:
    """
    Extract and analyze all algorithms from a repository.
    
    Analyzes functions and methods to compute:
    - Complexity metrics (cyclomatic, nesting depth, loops, conditionals)
    - AST-based structural hash for duplicate detection
    - Static category classification (sorting, searching, graph, dp, math, etc.)
    
    Requires: Run analyze_repo first to populate symbols.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    
    await ctx.info(f"Extracting algorithms from repository {repo_id}...")
    result = algorithm.extract_algorithms(repo_id, min_lines, force_reextract)
    
    if result.get("status") == "success":
        stats = result.get("statistics", {})
        await ctx.info(f"Extracted {stats.get('extracted', 0)} algorithms")
    
    return result


@mcp.tool()
def get_llm_analysis_prompt(
    algorithm_id: Annotated[int, "Algorithm ID to get prompt for"],
    ctx: Context = None
) -> dict:
    """
    Get the standard LLM analysis prompt for an algorithm.
    
    Returns a structured prompt with the algorithm's source code.
    The client should:
    1. Call their LLM with the returned 'prompt' field
    2. Parse the LLM's JSON response
    3. Save the result using save_llm_analysis
    
    The prompt asks for: purpose, category, time/space complexity,
    use cases, and potential improvements.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.get_llm_analysis_prompt(algorithm_id)


@mcp.tool()
def save_llm_analysis(
    algorithm_id: Annotated[int, "Algorithm ID to save analysis for"],
    analysis: Annotated[str, "LLM analysis result as JSON string with: purpose, category, time_complexity, space_complexity, use_cases, improvements"],
    ctx: Context = None
) -> dict:
    """
    Save LLM analysis results for an algorithm.
    
    Expected JSON structure:
    {
        "purpose": "Description of what the algorithm does",
        "category": "sorting|searching|graph|dp|math|string|tree|io|other",
        "time_complexity": {"notation": "O(...)", "explanation": "..."},
        "space_complexity": {"notation": "O(...)", "explanation": "..."},
        "use_cases": ["case1", "case2"],
        "improvements": ["improvement1", "improvement2"]
    }
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.save_llm_analysis(algorithm_id, analysis)


@mcp.tool()
def save_algorithm_embedding(
    algorithm_id: Annotated[int, "Algorithm ID to save embedding for"],
    embedding: Annotated[list[float], "Embedding vector as list of floats"],
    model_name: Annotated[str, "Name of the embedding model used (e.g., 'text-embedding-3-small')"],
    ctx: Context = None
) -> dict:
    """
    Save an embedding vector for an algorithm.
    
    The client should generate the embedding using their preferred model
    (e.g., OpenAI text-embedding-3-small, Cohere embed-v3, etc.) and
    provide it here for similarity search.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.save_embedding(algorithm_id, embedding, model_name)


@mcp.tool()
def find_similar_algorithms(
    algorithm_id: Annotated[int, "Algorithm ID to find similar algorithms for"],
    method: Annotated[Literal["hash", "embedding", "both"], "Comparison method"] = "both",
    threshold: Annotated[float, "Similarity threshold for embedding search (0.0-1.0)"] = 0.8,
    limit: Annotated[int, "Maximum results"] = 20,
    ctx: Context = None
) -> dict:
    """
    Find algorithms similar to the specified algorithm.
    
    Methods:
    - hash: Find structurally identical algorithms (exact AST match)
    - embedding: Find semantically similar algorithms using embeddings
    - both: Combine hash and embedding results
    
    Requires: Embeddings must be saved first for embedding-based search.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.find_similar(algorithm_id, method, threshold, limit)


@mcp.tool()
def get_algorithm(
    algorithm_id: Annotated[int, "Algorithm ID to retrieve"],
    ctx: Context = None
) -> dict:
    """
    Get detailed information about an algorithm.
    
    Returns complete algorithm details including:
    - Source code (original and normalized)
    - Complexity metrics
    - Static and LLM categories
    - LLM analysis results (if available)
    - Embedding status
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.get_algorithm(algorithm_id)


@mcp.tool()
def list_algorithms(
    repo_id: Annotated[int, "Repository ID"],
    category: Annotated[str | None, "Filter by category (sorting, searching, graph, dp, math, string, tree, io, other)"] = None,
    category_type: Annotated[Literal["static", "llm", "any"], "Which category to filter by"] = "static",
    min_complexity: Annotated[int | None, "Minimum cyclomatic complexity"] = None,
    limit: Annotated[int, "Maximum results"] = 100,
    ctx: Context = None
) -> dict:
    """
    List algorithms in a repository with optional filters.
    
    Filters:
    - category: Filter by algorithm category
    - category_type: Use 'static' (auto-detected), 'llm' (LLM-determined), or 'any'
    - min_complexity: Filter by minimum cyclomatic complexity
    
    Returns algorithm list with category summary.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.list_algorithms(repo_id, category, category_type, min_complexity, limit)


@mcp.tool()
def search_algorithms(
    query: Annotated[str, "Search query (supports FTS5 operators: AND, OR, NOT, 'phrase', prefix*)"],
    repo_id: Annotated[int | None, "Optional repository ID filter"] = None,
    limit: Annotated[int, "Maximum results"] = 20,
    ctx: Context = None
) -> dict:
    """
    Search algorithms using full-text search.
    
    Searches in source code and LLM analysis.
    Use this to find algorithms by keywords, patterns, or descriptions.
    """
    algorithm: AlgorithmTools = ctx.request_context.lifespan_context.algorithm
    return algorithm.search_algorithms(query, repo_id, limit)


# ============================================================================
# Resources
# ============================================================================

@mcp.resource("repo://{repo_id}/summary")
def get_repo_summary_resource(repo_id: int, ctx: Context = None) -> str:
    """Get repository analysis summary as a resource."""
    analysis: AnalysisTools = ctx.request_context.lifespan_context.analysis
    result = analysis.get_repo_summary(int(repo_id))
    
    if result.get("status") != "success":
        return f"Error: {result.get('message', 'Unknown error')}"
    
    # Format as readable text
    repo = result.get("repository", {})
    lines = [
        f"# Repository: {repo.get('name', 'Unknown')}",
        f"URL: {repo.get('url', 'N/A')}",
        f"Last analyzed: {repo.get('last_analyzed', 'Never')}",
        "",
        "## Language Breakdown",
    ]
    
    for lang in result.get("languages", []):
        lines.append(f"- {lang['language']}: {lang['file_count']} files, {lang['total_lines']} lines")
    
    lines.extend(["", "## Symbol Counts"])
    for stype, count in result.get("symbol_counts", {}).items():
        lines.append(f"- {stype}: {count}")
    
    lines.extend(["", "## Top Patterns"])
    for pattern in result.get("top_patterns", []):
        lines.append(f"- {pattern['pattern_type']}/{pattern['pattern_name']}: {pattern['count']} occurrences")
    
    lines.extend(["", "## Top Dependencies"])
    for imp in result.get("top_imports", [])[:10]:
        lines.append(f"- {imp['module']}: {imp['count']} uses")
    
    return "\n".join(lines)


# ============================================================================
# Entry Point
# ============================================================================

def main():
    """Run the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
