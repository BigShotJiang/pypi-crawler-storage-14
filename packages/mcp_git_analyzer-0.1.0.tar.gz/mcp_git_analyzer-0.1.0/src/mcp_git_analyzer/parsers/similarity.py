"""Similarity analysis module for algorithm comparison.

Provides hash-based duplicate detection and embedding-based similarity search.
"""

import struct
from dataclasses import dataclass
from typing import Any

from mcp_git_analyzer.db import Database


@dataclass
class SimilarAlgorithm:
    """Represents a similar algorithm found in the database."""
    algorithm_id: int
    symbol_name: str
    file_path: str
    repo_name: str
    similarity_score: float
    match_method: str  # 'hash' or 'embedding'
    
    def to_dict(self) -> dict:
        return {
            "algorithm_id": self.algorithm_id,
            "symbol_name": self.symbol_name,
            "file_path": self.file_path,
            "repo_name": self.repo_name,
            "similarity_score": self.similarity_score,
            "match_method": self.match_method,
        }


class SimilarityAnalyzer:
    """Analyze similarity between algorithms using hash and embedding methods."""
    
    def __init__(self, db: Database):
        self.db = db
    
    def find_duplicates_by_hash(
        self, 
        ast_hash: str, 
        repo_id: int | None = None,
        exclude_algorithm_id: int | None = None
    ) -> list[SimilarAlgorithm]:
        """
        Find algorithms with identical AST structure hash.
        
        Args:
            ast_hash: AST hash to search for
            repo_id: Optional repository ID to limit search
            exclude_algorithm_id: Optional algorithm ID to exclude from results
        
        Returns:
            List of SimilarAlgorithm with exact hash matches
        """
        query = """
            SELECT 
                ca.id as algorithm_id,
                s.name as symbol_name,
                f.path as file_path,
                r.name as repo_name
            FROM core_algorithms ca
            JOIN symbols s ON ca.symbol_id = s.id
            JOIN files f ON ca.file_id = f.id
            JOIN repositories r ON ca.repo_id = r.id
            WHERE ca.ast_hash = ?
        """
        params: list[Any] = [ast_hash]
        
        if repo_id is not None:
            query += " AND ca.repo_id = ?"
            params.append(repo_id)
        
        if exclude_algorithm_id is not None:
            query += " AND ca.id != ?"
            params.append(exclude_algorithm_id)
        
        rows = self.db.execute(query, tuple(params))
        
        return [
            SimilarAlgorithm(
                algorithm_id=row["algorithm_id"],
                symbol_name=row["symbol_name"],
                file_path=row["file_path"],
                repo_name=row["repo_name"],
                similarity_score=1.0,  # Exact hash match
                match_method="hash"
            )
            for row in rows
        ]
    
    def compute_cosine_similarity(
        self, 
        embedding1: bytes, 
        embedding2: bytes
    ) -> float:
        """
        Compute cosine similarity between two embedding vectors.
        
        Args:
            embedding1: First embedding as bytes (float32 array)
            embedding2: Second embedding as bytes (float32 array)
        
        Returns:
            Cosine similarity score (0.0 to 1.0)
        """
        # Decode embeddings from bytes to float list
        vec1 = self._bytes_to_floats(embedding1)
        vec2 = self._bytes_to_floats(embedding2)
        
        if len(vec1) != len(vec2):
            raise ValueError(f"Embedding dimensions don't match: {len(vec1)} vs {len(vec2)}")
        
        # Compute dot product and magnitudes
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = sum(a * a for a in vec1) ** 0.5
        magnitude2 = sum(b * b for b in vec2) ** 0.5
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def find_similar_by_embedding(
        self,
        embedding: bytes,
        repo_id: int | None = None,
        threshold: float = 0.8,
        limit: int = 20,
        exclude_algorithm_id: int | None = None
    ) -> list[SimilarAlgorithm]:
        """
        Find algorithms with similar embeddings using cosine similarity.
        
        Note: This performs a brute-force comparison. For large datasets,
        consider using approximate nearest neighbor methods.
        
        Args:
            embedding: Query embedding as bytes (float32 array)
            repo_id: Optional repository ID to limit search
            threshold: Minimum similarity threshold (0.0 to 1.0)
            limit: Maximum number of results
            exclude_algorithm_id: Optional algorithm ID to exclude
        
        Returns:
            List of SimilarAlgorithm sorted by similarity (descending)
        """
        # Get all algorithms with embeddings
        query = """
            SELECT 
                ca.id as algorithm_id,
                ca.embedding,
                s.name as symbol_name,
                f.path as file_path,
                r.name as repo_name
            FROM core_algorithms ca
            JOIN symbols s ON ca.symbol_id = s.id
            JOIN files f ON ca.file_id = f.id
            JOIN repositories r ON ca.repo_id = r.id
            WHERE ca.embedding IS NOT NULL
        """
        params: list[Any] = []
        
        if repo_id is not None:
            query += " AND ca.repo_id = ?"
            params.append(repo_id)
        
        if exclude_algorithm_id is not None:
            query += " AND ca.id != ?"
            params.append(exclude_algorithm_id)
        
        rows = self.db.execute(query, tuple(params))
        
        # Compute similarities
        results: list[SimilarAlgorithm] = []
        for row in rows:
            try:
                similarity = self.compute_cosine_similarity(embedding, row["embedding"])
                if similarity >= threshold:
                    results.append(SimilarAlgorithm(
                        algorithm_id=row["algorithm_id"],
                        symbol_name=row["symbol_name"],
                        file_path=row["file_path"],
                        repo_name=row["repo_name"],
                        similarity_score=round(similarity, 4),
                        match_method="embedding"
                    ))
            except ValueError:
                # Skip if embedding dimensions don't match
                continue
        
        # Sort by similarity and limit
        results.sort(key=lambda x: x.similarity_score, reverse=True)
        return results[:limit]
    
    def find_similar(
        self,
        algorithm_id: int,
        method: str = "both",
        threshold: float = 0.8,
        limit: int = 20
    ) -> dict:
        """
        Find algorithms similar to the given algorithm.
        
        Args:
            algorithm_id: ID of the algorithm to compare against
            method: 'hash', 'embedding', or 'both'
            threshold: Similarity threshold for embedding search
            limit: Maximum results per method
        
        Returns:
            Dict with hash_matches, embedding_matches, and combined results
        """
        # Get the algorithm's hash and embedding
        query = """
            SELECT ast_hash, embedding, repo_id
            FROM core_algorithms
            WHERE id = ?
        """
        rows = self.db.execute(query, (algorithm_id,))
        
        if not rows:
            return {"status": "error", "message": f"Algorithm {algorithm_id} not found"}
        
        algo = rows[0]
        ast_hash = algo["ast_hash"]
        embedding = algo["embedding"]
        repo_id = algo["repo_id"]
        
        result: dict[str, Any] = {
            "status": "success",
            "algorithm_id": algorithm_id,
            "method": method,
            "hash_matches": [],
            "embedding_matches": [],
        }
        
        # Find hash duplicates
        if method in ("hash", "both") and ast_hash:
            hash_matches = self.find_duplicates_by_hash(
                ast_hash, 
                exclude_algorithm_id=algorithm_id
            )
            result["hash_matches"] = [m.to_dict() for m in hash_matches]
        
        # Find embedding similarities
        if method in ("embedding", "both") and embedding:
            embedding_matches = self.find_similar_by_embedding(
                embedding,
                threshold=threshold,
                limit=limit,
                exclude_algorithm_id=algorithm_id
            )
            result["embedding_matches"] = [m.to_dict() for m in embedding_matches]
        elif method in ("embedding", "both") and not embedding:
            result["embedding_warning"] = "No embedding stored for this algorithm"
        
        # Combine and deduplicate
        seen_ids = set()
        combined = []
        
        # Hash matches first (exact matches)
        for match in result["hash_matches"]:
            if match["algorithm_id"] not in seen_ids:
                seen_ids.add(match["algorithm_id"])
                combined.append(match)
        
        # Then embedding matches
        for match in result["embedding_matches"]:
            if match["algorithm_id"] not in seen_ids:
                seen_ids.add(match["algorithm_id"])
                combined.append(match)
        
        result["combined"] = combined
        result["total_matches"] = len(combined)
        
        return result
    
    @staticmethod
    def floats_to_bytes(floats: list[float]) -> bytes:
        """
        Convert a list of floats to bytes for storage.
        
        Args:
            floats: List of float values (embedding vector)
        
        Returns:
            Bytes representation (float32 format)
        """
        return struct.pack(f"{len(floats)}f", *floats)
    
    @staticmethod
    def _bytes_to_floats(data: bytes) -> list[float]:
        """
        Convert bytes to a list of floats.
        
        Args:
            data: Bytes in float32 format
        
        Returns:
            List of float values
        """
        count = len(data) // 4  # float32 is 4 bytes
        return list(struct.unpack(f"{count}f", data))
