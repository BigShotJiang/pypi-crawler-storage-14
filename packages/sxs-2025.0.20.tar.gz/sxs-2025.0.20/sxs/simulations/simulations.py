"""Container interface to the catalog of SXS simulations"""
from sxscatalog.simulations.simulations import *
