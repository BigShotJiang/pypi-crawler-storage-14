"""Container for metadata of individual simulations"""
from sxscatalog.metadata.metadata import *
