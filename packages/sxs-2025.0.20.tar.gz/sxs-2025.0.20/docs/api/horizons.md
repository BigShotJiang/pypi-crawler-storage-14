# Horizons

## `Horizons` class
::: sxs.Horizons

## `HorizonQuantities` class
::: sxs.HorizonQuantities
