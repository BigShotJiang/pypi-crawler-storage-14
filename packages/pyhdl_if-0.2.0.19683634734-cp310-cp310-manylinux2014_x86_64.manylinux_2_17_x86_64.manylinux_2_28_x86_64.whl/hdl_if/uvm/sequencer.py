
import abc
from .object import uvm_object

class uvm_sequencer(uvm_object):
    pass
