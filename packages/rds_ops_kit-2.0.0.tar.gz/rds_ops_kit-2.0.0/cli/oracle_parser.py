from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Datentypen & Hilfsstrukturen
# ---------------------------------------------------------------------------


@dataclass
class ColumnInfo:
    schema: str
    table: str
    name: str
    data_type: str
    precision: Optional[int] = None
    scale: Optional[int] = None
    char_length: Optional[int] = None


@dataclass
class IndexInfo:
    schema: str
    table: str
    name: str
    uniqueness: str
    column_count: int


@dataclass
class ForeignKeyInfo:
    schema: str
    table: str
    name: str
    r_schema: str
    r_table: str
    delete_rule: str


@dataclass
class ViewInfo:
    schema: str
    name: str
    text: str


@dataclass
class TriggerInfo:
    schema: str
    name: str
    table: str
    timing: str  # BEFORE/AFTER
    level: str   # ROW/STATEMENT
    events: List[str]  # INSERT/UPDATE/DELETE


Check = Dict[str, Any]


# ---------------------------------------------------------------------------
# Allgemeine Helfer
# ---------------------------------------------------------------------------


def _add_check(
    checks: List[Check],
    *,
    check_id: str,
    severity: str,
    status: str,
    details: str,
    schema: Optional[str] = None,
    object_type: Optional[str] = None,
    object_name: Optional[str] = None,
) -> None:
    checks.append(
        {
            "id": check_id,
            "severity": severity,
            "status": status,
            "details": details,
            "schema": schema or "-",
            "object_type": object_type or "-",
            "object_name": object_name or "-",
        }
    )


def _norm_ident(name: str) -> str:
    """
    Sehr einfache Normalisierung von Oracle-Identifikatoren:
    Entfernt doppelte Anführungszeichen und uppercased.
    """
    name = name.strip()
    if name.startswith('"') and name.endswith('"') and len(name) >= 2:
        name = name[1:-1]
    return name.upper()


# ---------------------------------------------------------------------------
# DDL-Datei: einfache Parser-Heuristiken
# ---------------------------------------------------------------------------


def _parse_ddl_tables(sql: str) -> List[ColumnInfo]:
    """
    Sehr vereinfachte DDL-Auswertung:
    - Sucht CREATE TABLE ... ( ... );
    - zerlegt Spalten grob in Name / Datentyp.
    """
    result: List[ColumnInfo] = []

    table_re = re.compile(
        r"CREATE\s+TABLE\s+(?P<name>[A-Z0-9_\"\.]+)\s*\((?P<cols>.*?)\)\s*;",
        re.IGNORECASE | re.DOTALL,
    )

    for m in table_re.finditer(sql):
        full_name = m.group("name")
        cols_block = m.group("cols")

        if "." in full_name:
            schema_name, table_name = full_name.split(".", 1)
        else:
            schema_name, table_name = "APP", full_name

        schema_name = _norm_ident(schema_name)
        table_name = _norm_ident(table_name)

        col_lines = re.split(r",\s*(?![^()]*\))", cols_block)

        for raw in col_lines:
            line = raw.strip()
            if not line or line.upper().startswith("CONSTRAINT "):
                continue

            mcol = re.match(
                r"(?P<col>[A-Z0-9_\"]+)\s+(?P<type>[A-Z0-9_]+)(?P<rest>\(.*?\))?",
                line,
                re.IGNORECASE,
            )
            if not mcol:
                continue

            col_name = _norm_ident(mcol.group("col"))
            dt = mcol.group("type").upper()
            rest = mcol.group("rest") or ""

            prec = None
            scale = None
            char_len = None

            if dt == "NUMBER":
                mnum = re.search(r"\((\d+)\s*(?:,\s*(\d+))?\)", rest)
                if mnum:
                    prec = int(mnum.group(1))
                    if mnum.group(2):
                        scale = int(mnum.group(2))
            elif dt in ("VARCHAR2", "NVARCHAR2", "NCHAR", "CHAR"):
                mchar = re.search(r"\((\d+)\)", rest)
                if mchar:
                    char_len = int(mchar.group(1))

            result.append(
                ColumnInfo(
                    schema=schema_name,
                    table=table_name,
                    name=col_name,
                    data_type=dt,
                    precision=prec,
                    scale=scale,
                    char_length=char_len,
                )
            )

    return result


def _parse_ddl_indexes(sql: str) -> List[IndexInfo]:
    idx_re = re.compile(
        r"CREATE\s+(UNIQUE\s+)?INDEX\s+(?P<idx>[A-Z0-9_\"\.]+)\s+ON\s+"
        r"(?P<table>[A-Z0-9_\"\.]+)\s*\((?P<cols>.*?)\)",
        re.IGNORECASE | re.DOTALL,
    )

    result: List[IndexInfo] = []

    for m in idx_re.finditer(sql):
        idx_name = m.group("idx")
        table_name = m.group("table")
        cols_block = m.group("cols")

        if "." in table_name:
            schema_name, tbl = table_name.split(".", 1)
        else:
            schema_name, tbl = "APP", table_name

        schema_name = _norm_ident(schema_name)
        tbl = _norm_ident(tbl)
        idx_name = _norm_ident(idx_name)

        cols = re.split(r",\s*(?![^()]*\))", cols_block)
        col_count = len([c for c in cols if c.strip()])

        uniqueness = "UNIQUE" if m.group(1) else "NONUNIQUE"

        result.append(
            IndexInfo(
                schema=schema_name,
                table=tbl,
                name=idx_name,
                uniqueness=uniqueness,
                column_count=col_count,
            )
        )

    return result


def _parse_ddl_foreign_keys(sql: str) -> List[ForeignKeyInfo]:
    """
    Sucht CONSTRAINT ... FOREIGN KEY ... REFERENCES ... (ON DELETE CASCADE|SET NULL)?
    Das ist sehr heuristisch, reicht aber für grundlegende Checks.
    """
    fk_re = re.compile(
        r"CONSTRAINT\s+(?P<cname>[A-Z0-9_\"]+)\s+FOREIGN\s+KEY\s*\(.*?\)\s+"
        r"REFERENCES\s+(?P<ref>[A-Z0-9_\"\.]+).*?(ON\s+DELETE\s+(?P<rule>CASCADE|SET\s+NULL))?",
        re.IGNORECASE | re.DOTALL,
    )

    result: List[ForeignKeyInfo] = []

    # Wir brauchen den aktuellen Table-Kontext → grob über CREATE TABLE-Blocks iterieren
    table_re = re.compile(
        r"CREATE\s+TABLE\s+(?P<tname>[A-Z0-9_\"\.]+)\s*\((?P<body>.*?)\)\s*;",
        re.IGNORECASE | re.DOTALL,
    )

    for tm in table_re.finditer(sql):
        full_name = tm.group("tname")
        body = tm.group("body")

        if "." in full_name:
            schema_name, tbl = full_name.split(".", 1)
        else:
            schema_name, tbl = "APP", full_name

        schema_name = _norm_ident(schema_name)
        tbl = _norm_ident(tbl)

        for fm in fk_re.finditer(body):
            cname = _norm_ident(fm.group("cname"))
            ref = fm.group("ref")
            rule = fm.group("rule") or ""
            rule = rule.upper().replace("  ", " ")

            if "." in ref:
                r_schema, r_table = ref.split(".", 1)
            else:
                r_schema, r_table = schema_name, ref

            r_schema = _norm_ident(r_schema)
            r_table = _norm_ident(r_table)

            result.append(
                ForeignKeyInfo(
                    schema=schema_name,
                    table=tbl,
                    name=cname,
                    r_schema=r_schema,
                    r_table=_norm_ident(r_table),
                    delete_rule=rule or "NO ACTION",
                )
            )

    return result


def _parse_ddl_views(sql: str) -> List[ViewInfo]:
    view_re = re.compile(
        r"CREATE\s+(OR\s+REPLACE\s+)?VIEW\s+(?P<name>[A-Z0-9_\"\.]+)\s+AS\s+(?P<text>.*?);",
        re.IGNORECASE | re.DOTALL,
    )

    result: List[ViewInfo] = []

    for m in view_re.finditer(sql):
        full_name = m.group("name")
        text = m.group("text")

        if "." in full_name:
            schema_name, vname = full_name.split(".", 1)
        else:
            schema_name, vname = "APP", full_name

        schema_name = _norm_ident(schema_name)
        vname = _norm_ident(vname)

        result.append(ViewInfo(schema=schema_name, name=vname, text=text))

    return result


def _parse_ddl_triggers(sql: str) -> List[TriggerInfo]:
    trig_re = re.compile(
        r"CREATE\s+(OR\s+REPLACE\s+)?TRIGGER\s+(?P<name>[A-Z0-9_\"\.]+)\s+"
        r"(?P<timing>BEFORE|AFTER)\s+(?P<events>INSERT|UPDATE|DELETE"
        r"(?:\s+OR\s+(?:INSERT|UPDATE|DELETE))*)\s+"
        r"ON\s+(?P<table>[A-Z0-9_\"\.]+)"
        r"(?:.*?FOR\s+EACH\s+ROW)?",
        re.IGNORECASE | re.DOTALL,
    )

    result: List[TriggerInfo] = []

    for m in trig_re.finditer(sql):
        full_name = m.group("name")
        timing = (m.group("timing") or "").upper()
        events_raw = m.group("events") or ""
        table_name = m.group("table")

        events = [
            e.strip().upper()
            for e in re.split(r"\s+OR\s+", events_raw, flags=re.IGNORECASE)
            if e.strip()
        ]

        if "." in full_name:
            schema_name, tname = full_name.split(".", 1)
        else:
            schema_name, tname = "APP", full_name

        schema_name = _norm_ident(schema_name)
        tname = _norm_ident(tname)

        if "." in table_name:
            tschema, tbl = table_name.split(".", 1)
        else:
            tschema, tbl = schema_name, table_name

        tschema = _norm_ident(tschema)
        tbl = _norm_ident(tbl)

        # Grobe Heuristik: FOR EACH ROW?
        level = "STATEMENT"
        mrow = re.search(
            r"FOR\s+EACH\s+ROW", m.group(0), re.IGNORECASE | re.DOTALL
        )
        if mrow:
            level = "ROW"

        result.append(
            TriggerInfo(
                schema=tschema,
                name=tname,
                table=tbl,
                timing=timing,
                level=level,
                events=events,
            )
        )

    return result


# ---------------------------------------------------------------------------
# Heuristische Checks auf Basis der DDL-Infos
# ---------------------------------------------------------------------------


def _checks_for_columns(cols: Iterable[ColumnInfo]) -> List[Check]:
    checks: List[Check] = []

    # Gruppierung nach Tabelle
    tables: Dict[Tuple[str, str], List[ColumnInfo]] = {}
    for col in cols:
        key = (col.schema, col.table)
        tables.setdefault(key, []).append(col)

    for (schema, table), columns in tables.items():
        # NUMBER-Checks
        risky_nums: List[ColumnInfo] = []
        date_cols: List[ColumnInfo] = []
        lob_cols: List[ColumnInfo] = []
        nls_cols: List[ColumnInfo] = []

        for c in columns:
            dt = c.data_type.upper()
            if dt == "NUMBER":
                if c.precision is None or (c.precision is not None and c.precision > 18):
                    risky_nums.append(c)
            if dt == "DATE":
                date_cols.append(c)
            if dt in ("CLOB", "BLOB", "NCLOB"):
                lob_cols.append(c)
            if dt in ("NVARCHAR2", "NCHAR"):
                nls_cols.append(c)

        if risky_nums:
            col_list = ", ".join(
                f"{c.name} (NUMBER"
                + (
                    f"({c.precision},{c.scale})" if c.precision is not None else ""
                )
                + ")"
                for c in risky_nums
            )
            _add_check(
                checks,
                check_id="DATATYPE_NUMERIC_PRECISION",
                severity="HIGH",
                status="RISK",
                details=(
                    "Gefundene kritische NUMBER-Definitionen (Präzision > 18 oder "
                    f"unbounded): {col_list}"
                ),
                schema=schema,
                object_type="TABLE",
                object_name=table,
            )

        if date_cols:
            col_list = ", ".join(c.name for c in date_cols)
            _add_check(
                checks,
                check_id="DATATYPE_DATE_TIMESTAMP",
                severity="MEDIUM",
                status="RISK",
                details=(
                    "Es wurden DATE-Spalten gefunden. Prüfen, ob diese als "
                    f"TIMESTAMP WITH/WITHOUT TIME ZONE modelliert werden sollen: {col_list}"
                ),
                schema=schema,
                object_type="TABLE",
                object_name=table,
            )

        if lob_cols:
            col_list = ", ".join(f"{c.name} ({c.data_type})" for c in lob_cols)
            _add_check(
                checks,
                check_id="LOB_MIGRATION",
                severity="MEDIUM",
                status="CHECK_MANUALLY",
                details=(
                    "Es wurden CLOB/BLOB/NCLOB-Spalten gefunden. Migration von "
                    f"LOBs (Größe, Zugriffsmuster, TOAST) genau planen: {col_list}"
                ),
                schema=schema,
                object_type="TABLE",
                object_name=table,
            )

        if nls_cols:
            col_list = ", ".join(f"{c.name} ({c.data_type})" for c in nls_cols)
            _add_check(
                checks,
                check_id="NLS_COLLATION",
                severity="HIGH",
                status="RISK",
                details=(
                    "Es wurden NLS-sensitive Typen (NVARCHAR2/NCHAR) gefunden. "
                    "Collation, Encoding und Sortierreihenfolge in PostgreSQL prüfen: "
                    f"{col_list}"
                ),
                schema=schema,
                object_type="TABLE",
                object_name=table,
            )

    return checks


def _checks_for_indexes(idxs: Iterable[IndexInfo]) -> List[Check]:
    checks: List[Check] = []

    tables: Dict[Tuple[str, str], List[IndexInfo]] = {}
    for ix in idxs:
        key = (ix.schema, ix.table)
        tables.setdefault(key, []).append(ix)

    for (schema, table), indexes in tables.items():
        total = len(indexes)
        wide = [ix for ix in indexes if ix.column_count >= 4]
        unique_cnt = sum(1 for ix in indexes if ix.uniqueness == "UNIQUE")

        if total >= 10 or wide:
            details_parts = [
                f"{total} Indexe insgesamt",
                f"{len(wide)} breite Indexe (>= 4 Spalten)",
                f"{unique_cnt} UNIQUE-Indexe",
            ]
            _add_check(
                checks,
                check_id="INDEX_STRATEGY",
                severity="MEDIUM",
                status="CHECK_MANUALLY",
                details=(
                    "Komplexe Index-Situation. "
                    + "; ".join(details_parts)
                    + ". Indexstrategie zwischen Oracle und PostgreSQL abgleichen."
                ),
                schema=schema,
                object_type="TABLE",
                object_name=table,
            )

    return checks


def _checks_for_foreign_keys(fks: Iterable[ForeignKeyInfo]) -> List[Check]:
    checks: List[Check] = []

    for fk in fks:
        if fk.delete_rule in ("CASCADE", "SET NULL"):
            _add_check(
                checks,
                check_id="CONSTRAINTS_TRIGGERS",
                severity="MEDIUM",
                status="CHECK_MANUALLY",
                details=(
                    f"FK {fk.name} ({fk.schema}.{fk.table} → "
                    f"{fk.r_schema}.{fk.r_table}) mit ON DELETE {fk.delete_rule}. "
                    "Verhalten in PostgreSQL explizit modellieren."
                ),
                schema=fk.schema,
                object_type="FOREIGN_KEY",
                object_name=fk.name,
            )

    return checks


def _checks_for_views(views: Iterable[ViewInfo]) -> List[Check]:
    checks: List[Check] = []

    for v in views:
        text = v.text.upper()
        join_count = len(re.findall(r"\bJOIN\b", text))
        subselect_count = len(re.findall(r"\bSELECT\b", text)) - 1  # 1 = Hauptselect

        if join_count >= 5 or subselect_count >= 2:
            severity = "HIGH" if join_count >= 8 or subselect_count >= 3 else "MEDIUM"
            _add_check(
                checks,
                check_id="VIEW_COMPLEXITY",
                severity=severity,
                status="CHECK_MANUALLY",
                details=(
                    f"View hat {join_count} JOINs und {subselect_count} Subselects. "
                    "Komplexe Logik kann beim Rewrite nach PostgreSQL Aufwand erzeugen."
                ),
                schema=v.schema,
                object_type="VIEW",
                object_name=v.name,
            )

    return checks


def _checks_for_triggers(trigs: Iterable[TriggerInfo]) -> List[Check]:
    checks: List[Check] = []

    for t in trigs:
        # Business-Logik in Row-Level-Triggern ist oft kritisch
        if t.level == "ROW" and any(ev in ("INSERT", "UPDATE", "DELETE") for ev in t.events):
            _add_check(
                checks,
                check_id="TRIGGER_BUSINESS_LOGIC",
                severity="HIGH",
                status="CHECK_MANUALLY",
                details=(
                    f"Row-Level-Trigger {t.name} auf {t.schema}.{t.table} "
                    f"({t.timing} {', '.join(t.events)}). "
                    "Geschäftslogik muss in PostgreSQL (Trigger/Anwendung) neu modelliert werden."
                ),
                schema=t.schema,
                object_type="TRIGGER",
                object_name=t.name,
            )

    return checks


# ---------------------------------------------------------------------------
# Öffentliche API – DDL-Datei
# ---------------------------------------------------------------------------


def analyze_file_for_readiness(path: Path) -> List[Check]:
    """
    Analysiert eine DDL-Datei heuristisch für typische Migrationsrisiken.

    Liefert eine Liste von Check-Dicts mit:
      - id
      - severity
      - status
      - details
      - schema
      - object_type
      - object_name
    """
    if not path.exists():
        raise FileNotFoundError(f"DDL-Datei nicht gefunden: {path}")

    sql = path.read_text(encoding="utf-8", errors="ignore")

    cols = _parse_ddl_tables(sql)
    idxs = _parse_ddl_indexes(sql)
    fks = _parse_ddl_foreign_keys(sql)
    views = _parse_ddl_views(sql)
    trigs = _parse_ddl_triggers(sql)

    checks: List[Check] = []
    checks.extend(_checks_for_columns(cols))
    checks.extend(_checks_for_indexes(idxs))
    checks.extend(_checks_for_foreign_keys(fks))
    checks.extend(_checks_for_views(views))
    checks.extend(_checks_for_triggers(trigs))

    # Wenn nichts gefunden wurde, zumindest Info-Check zurückgeben
    if not checks:
        _add_check(
            checks,
            check_id="SOURCE_PARSE_RESULT",
            severity="LOW",
            status="INFO",
            details="In der Quelldatei wurden keine CREATE TABLE/SEQUENCE-Statements erkannt.",
            schema="-",
            object_type="-",
            object_name="-",
        )

    return checks


# ---------------------------------------------------------------------------
# Öffentliche API – Oracle-Schema (Data Dictionary)
# ---------------------------------------------------------------------------


def analyze_oracle_schema_for_readiness(
    *,
    dsn: str,
    user: str,
    password: str,
    schema: str,
    object_types: List[str],
) -> List[Check]:
    """
    Nutzt das Oracle Data Dictionary, um ein Schema zu scannen.

    - object_types: z.B. ["TABLE","INDEX","FOREIGN_KEY","VIEW","MATERIALIZED_VIEW","TRIGGER"]
    """
    try:
        import oracledb  # type: ignore[import]
    except ImportError:
        raise RuntimeError(
            "Das Paket 'oracledb' ist nicht installiert. Bitte mit 'pip install oracledb' nachinstallieren."
        )

    schema_u = schema.upper()
    ot = {t.upper() for t in object_types}

    conn = oracledb.connect(user=user, password=password, dsn=dsn)
    try:
        cur = conn.cursor()

        checks: List[Check] = []

        # TABLE / COLUMNS
        if "TABLE" in ot:
            cur.execute(
                """
                SELECT owner, table_name, column_name, data_type,
                       data_precision, data_scale, char_length
                FROM   all_tab_columns
                WHERE  owner = :owner
                """,
                owner=schema_u,
            )
            cols: List[ColumnInfo] = []
            for owner, table_name, col_name, data_type, prec, scale, char_len in cur:
                cols.append(
                    ColumnInfo(
                        schema=owner,
                        table=table_name,
                        name=col_name,
                        data_type=(data_type or "").upper(),
                        precision=prec,
                        scale=scale,
                        char_length=char_len,
                    )
                )
            checks.extend(_checks_for_columns(cols))

        # INDEXES
        if "INDEX" in ot:
            cur.execute(
                """
                SELECT owner, index_name, table_name, uniqueness
                FROM   all_indexes
                WHERE  owner = :owner
                """,
                owner=schema_u,
            )
            idxs: List[IndexInfo] = []
            for owner, idx_name, table_name, uniqueness in cur:
                # Spaltenanzahl grob via all_ind_columns zählen
                cur.execute(
                    """
                    SELECT COUNT(*)
                    FROM   all_ind_columns
                    WHERE  index_owner = :owner
                    AND    index_name  = :idx
                    """,
                    owner=owner,
                    idx=idx_name,
                )
                (col_count,) = cur.fetchone()
                idxs.append(
                    IndexInfo(
                        schema=owner,
                        table=table_name,
                        name=idx_name,
                        uniqueness=(uniqueness or "NONUNIQUE"),
                        column_count=int(col_count or 0),
                    )
                )
            checks.extend(_checks_for_indexes(idxs))

        # FOREIGN KEYS
        if "FOREIGN_KEY" in ot:
            cur.execute(
                """
                SELECT owner, constraint_name, table_name,
                       r_owner, r_constraint_name, delete_rule
                FROM   all_constraints
                WHERE  owner = :owner
                AND    constraint_type = 'R'
                """,
                owner=schema_u,
            )
            fks: List[ForeignKeyInfo] = []
            for (
                owner,
                cname,
                table_name,
                r_owner,
                r_cname,
                delete_rule,
            ) in cur:
                # Ziel-Tabelle über referenzierte PK/UK holen
                cur.execute(
                    """
                    SELECT owner, table_name
                    FROM   all_constraints
                    WHERE  owner = :r_owner
                    AND    constraint_name = :r_cname
                    """,
                    r_owner=r_owner,
                    r_cname=r_cname,
                )
                row = cur.fetchone()
                if row:
                    tgt_owner, tgt_table = row
                else:
                    tgt_owner, tgt_table = r_owner, "<UNKNOWN>"

                fks.append(
                    ForeignKeyInfo(
                        schema=owner,
                        table=table_name,
                        name=cname,
                        r_schema=tgt_owner,
                        r_table=tgt_table,
                        delete_rule=(delete_rule or "NO ACTION"),
                    )
                )
            checks.extend(_checks_for_foreign_keys(fks))

        # VIEWS
        if "VIEW" in ot:
            cur.execute(
                """
                SELECT owner, view_name, text
                FROM   all_views
                WHERE  owner = :owner
                """,
                owner=schema_u,
            )
            views: List[ViewInfo] = []
            for owner, vname, text in cur:
                views.append(
                    ViewInfo(
                        schema=owner,
                        name=vname,
                        text=text or "",
                    )
                )
            checks.extend(_checks_for_views(views))

        # MATERIALIZED VIEWS
        if "MATERIALIZED_VIEW" in ot or "MVIEW" in ot:
            cur.execute(
                """
                SELECT owner, mview_name, query
                FROM   all_mviews
                WHERE  owner = :owner
                """,
                owner=schema_u,
            )
            mviews: List[ViewInfo] = []
            for owner, mvname, query in cur:
                mviews.append(
                    ViewInfo(
                        schema=owner,
                        name=mvname,
                        text=query or "",
                    )
                )
            checks.extend(_checks_for_views(mviews))

        # TRIGGERS
        if "TRIGGER" in ot:
            cur.execute(
                """
                SELECT owner, trigger_name, table_name,
                       triggering_event, trigger_type
                FROM   all_triggers
                WHERE  table_owner = :owner
                """,
                owner=schema_u,
            )
            trigs: List[TriggerInfo] = []
            for owner, tname, table_name, events, trig_type in cur:
                timing = "BEFORE" if "BEFORE" in (trig_type or "").upper() else "AFTER"
                level = "ROW" if "EACH ROW" in (trig_type or "").upper() else "STATEMENT"
                evs = [e.strip().upper() for e in (events or "").split(" OR ") if e.strip()]
                trigs.append(
                    TriggerInfo(
                        schema=owner,
                        name=tname,
                        table=table_name,
                        timing=timing,
                        level=level,
                        events=evs,
                    )
                )
            checks.extend(_checks_for_triggers(trigs))

        # Wenn trotz allem nichts gefunden: Info-Check
        if not checks:
            _add_check(
                checks,
                check_id="SCHEMA_PARSE_RESULT",
                severity="LOW",
                status="INFO",
                details=(
                    f"Im Schema {schema_u} wurden keine relevanten Objekte für die "
                    "Readiness-Analyse gefunden."
                ),
                schema=schema_u,
                object_type="-",
                object_name="-",
            )

        return checks

    finally:
        try:
            conn.close()
        except Exception:
            pass
