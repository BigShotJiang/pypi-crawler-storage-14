from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("rds-ops-kit")
except PackageNotFoundError:
    __version__ = "0.0.0"

