from pathlib import Path
import types

from click.testing import CliRunner

import webapp.app as webapp_app


runner = CliRunner()


def _stub_webapp_readiness_engine():
    """Stub für die Readiness Engine auf Webapp-Ebene."""
    def run_check(ddl_path=None, context=None, output_format=None, **kwargs):
        return {
            "ddl_path": ddl_path,
            "summary": "stub-ok",
            "issues": [
                {"severity": "high", "object": "T.ID", "message": "HIGH issue"},
                {"severity": "low", "object": "T.NAME", "message": "LOW issue"},
            ],
        }

    def write_html_report(ddl_path=None, out_path=None, context=None, **kwargs):
        Path(out_path).write_text(
            f"<html><body>Stub report for {ddl_path}</body></html>",
            encoding="utf-8",
        )

    webapp_app.readiness_engine = types.SimpleNamespace(
        run_check=run_check,
        write_html_report=write_html_report,
    )


def _stub_compute_score():
    """Stub für die Score-Funktion, damit das Ergebnis deterministisch ist."""
    def compute(findings: dict) -> int:
        # Egal was reinkommt → Score 42, damit der Test einfach prüfen kann.
        return 42

    webapp_app._compute_readiness_score = compute  # type: ignore[attr-defined]


def test_generate_readiness_html_creates_file_and_contains_score(tmp_path):
    _stub_webapp_readiness_engine()
    _stub_compute_score()

    ddl_file = tmp_path / "schema_oracle.sql"
    ddl_file.write_text("CREATE TABLE T (ID NUMBER);", encoding="utf-8")

    out_file = tmp_path / "readiness-web.html"

    webapp_app.generate_readiness_html(str(ddl_file), str(out_file))

    assert out_file.is_file()

    html = out_file.read_text(encoding="utf-8")
    assert "Score: 42" in html
    assert "HIGH issue" in html or "LOW issue" in html
    assert "schema_oracle.sql" in html or str(ddl_file) in html
