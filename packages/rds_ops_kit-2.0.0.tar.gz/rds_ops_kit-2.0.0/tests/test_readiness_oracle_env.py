import types
from pathlib import Path

from click.testing import CliRunner

import cli.main as cli_main


runner = CliRunner()


def _stub_readiness_engine():
    """Stub für Readiness Engine speziell für diese Tests."""
    def run_check(ddl_path=None, context=None, output_format=None, **kwargs):
        return {
            "ddl_path": ddl_path,
            "summary": "ok",
            "issues": [
                {"type": "datatype", "severity": "low", "object": "T.ID"},
            ],
        }

    def write_html_report(ddl_path=None, out_path=None, context=None, **kwargs):
        Path(out_path).write_text(
            f"<html><body>Readiness report for {ddl_path}</body></html>",
            encoding="utf-8",
        )

    cli_main.readiness_engine = types.SimpleNamespace(
        run_check=run_check,
        write_html_report=write_html_report,
    )


def test_readiness_check_json_like_output(tmp_path):
    _stub_readiness_engine()

    ddl_path = tmp_path / "schema_oracle.sql"
    ddl_path.write_text(
        "CREATE TABLE T (ID NUMBER PRIMARY KEY);",
        encoding="utf-8",
    )

    # Standard-Output-Format (table/json/yaml) wird vom CLI gesteuert;
    # hier testen wir nur, dass der Befehl durchläuft.
    result = runner.invoke(
        cli_main.app,
        ["readiness", "check", "--source", str(ddl_path)],
    )
    assert result.exit_code == 0
    # Irgendein Hinweis auf Summary/Issues
    assert "summary" in result.output.lower() or "issues" in result.output.lower()


def test_readiness_report_generates_file(tmp_path):
    _stub_readiness_engine()

    ddl_path = tmp_path / "schema_oracle.sql"
    ddl_path.write_text(
        "CREATE TABLE T (ID NUMBER PRIMARY KEY);",
        encoding="utf-8",
    )

    out_file = tmp_path / "readiness-oracle.html"

    result = runner.invoke(
        cli_main.app,
        [
            "readiness",
            "report",
            "--source",
            str(ddl_path),
            "--out",
            str(out_file),
        ],
    )
    assert result.exit_code == 0
    assert out_file.is_file()

    content = out_file.read_text(encoding="utf-8")
    assert "Readiness report" in content or "schema_oracle.sql" in content
