import json
import types
from pathlib import Path

from click.testing import CliRunner

import cli.main as cli_main


runner = CliRunner()


def _stub_pg_engine():
    """Ersetzt pg_engine im cli.main Modul durch einen einfachen Stub."""
    def list_presets(context=None):
        return ["preset-a", "preset-b"]

    def show_preset(name, context=None):
        return {"name": name, "value": "dummy"}

    def diff_presets(a, b, context=None):
        return [f"- {a}.param1 = 1", f"+ {b}.param1 = 2"]

    def export_preset(target, name, context=None):
        return {"target": target, "name": name, "exported": True}

    cli_main.pg_engine = types.SimpleNamespace(
        list_presets=list_presets,
        show_preset=show_preset,
        diff_presets=diff_presets,
        export_preset=export_preset,
    )


def _stub_planning_engine():
    """Ersetzt planning_engine im cli.main Modul durch einen einfachen Stub."""
    def generate_plan(config_path=None, context=None, **kwargs):
        return {
            "config_path": config_path,
            "plan": True,
            "engine": "dummy",
        }

    def validate_plan(config_path=None, plan=None, context=None, **kwargs):
        # Für den Test einfach "gültig"
        return True

    cli_main.planning_engine = types.SimpleNamespace(
        generate_plan=generate_plan,
        validate_plan=validate_plan,
    )


def _stub_readiness_engine():
    """Ersetzt readiness_engine im cli.main Modul durch einen einfachen Stub."""
    def run_check(ddl_path=None, context=None, output_format=None, **kwargs):
        return {
            "ddl_path": ddl_path,
            "summary": "ok",
            "issues": [],
        }

    def write_html_report(ddl_path=None, out_path=None, context=None, **kwargs):
        Path(out_path).write_text(
            f"<html><body>Report for {ddl_path}</body></html>",
            encoding="utf-8",
        )

    cli_main.readiness_engine = types.SimpleNamespace(
        run_check=run_check,
        write_html_report=write_html_report,
    )


def test_cli_help_runs():
    result = runner.invoke(cli_main.app, ["--help"])
    assert result.exit_code == 0
    assert "RDS Ops Kit" in result.output or "Toolkit" in result.output


def test_cli_version_runs():
    result = runner.invoke(cli_main.app, ["--version"])
    assert result.exit_code == 0
    assert "rds-ops-kit" in result.output
    assert "version" in result.output.lower()


def test_pg_list_runs_with_stub(tmp_path):
    _stub_pg_engine()

    result = runner.invoke(cli_main.app, ["pg", "list"])
    assert result.exit_code == 0
    # beide Presets sollten ausgegeben werden
    assert "preset-a" in result.output
    assert "preset-b" in result.output


def test_pg_show_runs_with_stub():
    _stub_pg_engine()

    result = runner.invoke(cli_main.app, ["pg", "show", "preset-a"])
    assert result.exit_code == 0
    # einfache Key:Value Ausgabe
    assert "name: preset-a" in result.output


def test_pg_diff_runs_with_stub():
    _stub_pg_engine()

    result = runner.invoke(cli_main.app, ["pg", "diff", "preset-a", "preset-b"])
    assert result.exit_code == 0
    assert "preset-a" in result.output or "preset-b" in result.output


def test_pg_export_writes_file(tmp_path):
    _stub_pg_engine()

    out_file = tmp_path / "pg-export.json"
    result = runner.invoke(
        cli_main.app,
        ["pg", "export", "aws", "preset-a", "--out", str(out_file)],
    )
    assert result.exit_code == 0
    assert out_file.is_file()

    data = json.loads(out_file.read_text(encoding="utf-8"))
    assert data["exported"] is True
    assert data["name"] == "preset-a"


def test_plan_generate_creates_plan_file(tmp_path):
    _stub_planning_engine()

    config_path = "config/prod.env"
    out_file = tmp_path / "plan.json"

    result = runner.invoke(
        cli_main.app,
        ["plan", "generate", "--config", config_path, "--out", str(out_file)],
    )
    assert result.exit_code == 0
    assert out_file.is_file()

    data = json.loads(out_file.read_text(encoding="utf-8"))
    assert data["plan"] is True
    assert data["config_path"] == config_path


def test_plan_validate_uses_stub(tmp_path):
    _stub_planning_engine()

    # fake plan file
    plan_file = tmp_path / "plan.json"
    plan_file.write_text(json.dumps({"dummy": True}), encoding="utf-8")

    result = runner.invoke(
        cli_main.app,
        [
            "plan",
            "validate",
            "--config",
            "config/prod.env",
            "--plan",
            str(plan_file),
        ],
    )
    assert result.exit_code == 0
    assert "valid" in result.output.lower() or result.output.strip() == ""


def test_readiness_check_uses_stub(tmp_path):
    _stub_readiness_engine()

    ddl_path = tmp_path / "schema.sql"
    ddl_path.write_text("CREATE TABLE t (id NUMBER);", encoding="utf-8")

    result = runner.invoke(
        cli_main.app,
        ["readiness", "check", "--source", str(ddl_path)],
    )
    assert result.exit_code == 0
    assert "summary" in result.output or "ok" in result.output.lower()


def test_readiness_report_writes_html(tmp_path):
    _stub_readiness_engine()

    ddl_path = tmp_path / "schema.sql"
    ddl_path.write_text("CREATE TABLE t (id NUMBER);", encoding="utf-8")

    out_file = tmp_path / "readiness.html"
    result = runner.invoke(
        cli_main.app,
        ["readiness", "report", "--source", str(ddl_path), "--out", str(out_file)],
    )
    assert result.exit_code == 0
    assert out_file.is_file()

    content = out_file.read_text(encoding="utf-8")
    assert "Report for" in content
