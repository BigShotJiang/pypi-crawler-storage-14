📘 RDS Ops Kit

Automatisiertes Planning, Validation und Readiness-Checks für Amazon RDS / Aurora PostgreSQL und Oracle-→PostgreSQL-Migrationen.

RDS Ops Kit ist ein CLI-Toolkit für Engineers, die wiederkehrende RDS-Deployments, Parameter-Gruppen-Management und Migrations-Readiness nicht jedes Mal manuell bauen wollen.
Es kombiniert:

Plan-Generator für RDS/Aurora-Deployments

Parameter-Group Presets + Diff/Export

Readiness-Analyse für Oracle-DDL

Preflight-Checks gegen AWS (READ-only)

Report-Generierung (HTML/JSON)

🚀 Features
✔️ Plan Generation

Erzeugt reproduzierbare JSON-Deploy-Pläne basierend auf einer einzelnen Konfigurationsdatei (ENV/YAML/JSON).

✔️ Plan Validation

Validiert Konfigurationen read-only gegen AWS (Parameter Groups, Engine-Versionen, Subnet Groups, Storage Optionen).

✔️ Parameter-Group Engine

Presets (PostgreSQL / Aurora PostgreSQL)

Diff zwischen Presets

Export nach AWS-kompatiblen Strukturen

✔️ Readiness Check (Oracle → PostgreSQL)

Analysiert Oracle-DDL und erzeugt eine Readiness-Bewertung inklusive HTML-Report.

📦 Installation
Option A: Install via pip (lokale venv empfohlen)
python -m venv .venv
source .venv/bin/activate     # Windows: .\.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install rds-ops-kit

Option B: Installation aus Source (für Entwicklung)
git clone https://github.com/gcon-cli/rds_ops_kit
cd rds_ops_kit
python -m venv .venv
source .venv/bin/activate
pip install -e .

🧩 CLI Overview

Das Toolkit folgt einer klar strukturierten CLI-Architektur:

rds-ops-kit [GLOBAL-OPTIONS] <command> <subcommand> [OPTIONS]

Globale Optionen
Flag	Beschreibung
--profile <name>	AWS Profile
--region <aws-region>	AWS Region
`--format table	json
--verbose, --quiet	Logging
--version	CLI Version
🔧 Commands
1) Parameter Groups
Liste aller Presets
rds-ops-kit pg list

Preset anzeigen
rds-ops-kit pg show aurora14-default

Diff zwischen zwei Presets
rds-ops-kit pg diff aurora14-default custom-prod

Export eines Presets (z. B. AWS-Format)
rds-ops-kit pg export aws aurora14-default --out pg.json

2) Deployment Planning
Plan aus Konfiguration generieren
rds-ops-kit plan generate \
  --config config/orders.env \
  --out plans/orders-plan.json

Plan validieren (READ-only AWS-Checks)
rds-ops-kit plan validate \
  --config config/orders.env \
  --plan plans/orders-plan.json

Bald verfügbar (0.5.x):
rds-ops-kit deploy apply --plan plans/orders-plan.json


(echtes Provisioning)

3) Readiness (Oracle → PostgreSQL)
CLI-Check (übersichtlich, stdout)
rds-ops-kit readiness check --source oracle/schema.sql

HTML-Report erzeugen
rds-ops-kit readiness report \
  --source oracle/schema.sql \
  --out reports/readiness.html

📁 Projektstruktur
.
├── cli/                     # Haupt-Implementierung
├── scripts/                 # interne Utilities
├── templates/               # PG-Presets, Config-Templates
├── tests/                   # Unit- und Integrationstests
├── docs/                    # Dokumentation
├── examples/                # Beispiel-Pläne & Reports
├── plans/                  # (ignored) runtime output
├── reports/                # (ignored) runtime output
└── README.md

🧹 Git Hygiene

RDS Ops Kit versioniert nur Quellcode & Doku.
Alle generierten Artefakte bleiben lokal.

Wichtige Regeln:

Nie committen: .venv/, venv/, plans/, reports/, *.html, *.log, plan.json

Beispieldateien: in examples/

Alles andere: über .gitignore geregelt

🛠 Entwicklungs-Setup
1. Repo klonen
git clone https://github.com/gcon-cli/rds_ops_kit
cd rds_ops_kit

2. venv + Editable-Install
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e .

3. Tests ausführen
pytest -q

📅 Roadmap
0.3.x

Stabilisierung Plan-Generator

Validierungs-Engine erweitern

CLI-API vereinheitlichen

0.4.x

Oracle-DDL-Parser

Verbesserte Readiness-Analyse

Multi-Format Reports (JSON, HTML, Markdown)

0.5.x

Deploy-Engine (apply) inkl.

DB-Cluster

Parameter Groups

Subnet Groups

Tags / IAM / Storage

1.0

API-Freeze

Vollständige Semver-Stabilität

CI/CD Release-Pipeline

Plugin-System (optional)

🤝 Contribution

Pull Requests sind willkommen.
Bitte folgende Regeln beachten:

Black + isort für Code-Formatierung

Tests (pytest) müssen bestehen

Für neue Features: Doku im docs/-Verzeichnis erweitern

CLI-Änderungen müssen backward-kompatibel beginnen (0.x)

📣 Support

Issues und Feature-Requests bitte über GitHub:
https://github.com/gcon-cli/rds_ops_kit/issues

📝 Lizenz

MIT License – freie Nutzung, Anpassung und Weitergabe erlaubt.