from setuptools import setup, find_packages

setup(
    name="mrs-scaffold",
    version="1.1.4",
    packages=find_packages(),
    description="MRS (Modular Reasoning Scaffold): a mesoscale architecture for symbolic meta-reasoning and recursive cognitive pipelines.",
    author="Sabouhi",
    license="MIT",
    url="https://github.com/rjsabouhi/Modular-Reasoning-Scaffold",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ]
)
