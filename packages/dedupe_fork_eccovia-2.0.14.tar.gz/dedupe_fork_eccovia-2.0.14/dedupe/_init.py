from dedupe.api import StaticDedupe, Dedupe  # noqa: F401
from dedupe.api import StaticRecordLink, RecordLink  # noqa: F401
from dedupe.api import StaticGazetteer, Gazetteer  # noqa: F401
from dedupe.convenience import console_label, training_data_dedupe, training_data_link, canonicalize  # noqa: F401
