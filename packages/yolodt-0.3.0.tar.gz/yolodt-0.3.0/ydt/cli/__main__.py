"""Allow running CLI with python -m cli"""

import sys

from .main import main

if __name__ == "__main__":
    sys.exit(main())
