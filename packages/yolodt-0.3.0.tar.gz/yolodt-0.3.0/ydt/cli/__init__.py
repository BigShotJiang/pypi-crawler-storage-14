"""
Command-line interface module
"""

# Don't import main here to avoid conflicts with entry point
# from .main import main, create_parser

__all__ = []
