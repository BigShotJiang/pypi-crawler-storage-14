#pragma once

#include "unary.h"

#include "binary.h"

#include "ternary.h"

#include "custom.h"
