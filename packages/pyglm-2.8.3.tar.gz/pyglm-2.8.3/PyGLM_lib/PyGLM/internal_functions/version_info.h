#pragma once

#include "../compiler_setup.h"

static PyObject* PyGLM_VERSION_STRING = NULL;
static PyObject* PyGLM_LICENSE_STRING = NULL;