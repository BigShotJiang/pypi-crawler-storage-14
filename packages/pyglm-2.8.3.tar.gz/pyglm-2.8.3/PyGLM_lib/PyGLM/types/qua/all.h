#ifndef TYPES_QUA_ALL_H
#define TYPES_QUA_ALL_H

#include "forward_declarations.h"

#include "double/quat.h"

#include "float/quat.h"

#endif