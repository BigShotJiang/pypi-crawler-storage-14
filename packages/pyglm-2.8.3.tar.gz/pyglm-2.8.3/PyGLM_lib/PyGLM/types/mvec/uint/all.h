#ifndef TYPES_MVEC_UINT_ALL_H
#define TYPES_MVEC_UINT_ALL_H

#include "mvec2.h"

#include "mvec3.h"

#include "mvec4.h"

#endif