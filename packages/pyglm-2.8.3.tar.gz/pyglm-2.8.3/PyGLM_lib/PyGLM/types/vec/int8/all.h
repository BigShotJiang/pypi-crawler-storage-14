#ifndef TYPES_VEC_INT8_ALL_H
#define TYPES_VEC_INT8_ALL_H

#include "vec1.h"

#include "vec2.h"

#include "vec3.h"

#include "vec4.h"

#endif