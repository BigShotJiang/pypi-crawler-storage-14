#ifndef TYPES_VEC_ALL_H
#define TYPES_VEC_ALL_H

#include "forward_declarations.h"

#include "bool/all.h"

#include "double/all.h"

#include "float/all.h"

#include "int8/all.h"

#include "int16/all.h"

#include "int32/all.h"

#include "int64/all.h"

#include "uint8/all.h"

#include "uint16/all.h"

#include "uint32/all.h"

#include "uint64/all.h"

#endif