# MSKR_tiktok

TikTok username checker library.

## Install
```
pip install MSKR_tiktok
```

## Usage
```python
from MSKR_tiktok import TikTokChecker

c = TikTokChecker()
print(c.check_user("muslim"))
```
