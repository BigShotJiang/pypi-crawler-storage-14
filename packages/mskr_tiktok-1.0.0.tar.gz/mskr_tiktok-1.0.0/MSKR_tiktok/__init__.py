from .checker import TikTokChecker, run_cli
