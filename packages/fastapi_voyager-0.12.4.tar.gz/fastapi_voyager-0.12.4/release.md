release by pushing the tag

```shell
git tag v1.0.0
git push origin v1.0.0
```

 