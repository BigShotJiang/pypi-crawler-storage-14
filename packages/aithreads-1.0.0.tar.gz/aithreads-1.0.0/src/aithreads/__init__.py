"""
aithreads - Official Python SDK for aithreads.io

Email infrastructure for AI agents.
"""

from ._async_client import AsyncAIThreadsClient
from ._exceptions import (
    AIThreadsError,
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .client import AIThreadsClient
from .types import (
    # Common
    ApiError,
    EmailAddress,
    PaginatedResponse,
    Pagination,
    SuccessResponse,
    # Inbox
    CreateInboxRequest,
    Inbox,
    InboxResponse,
    UpdateInboxRequest,
    # Thread
    EmailPreview,
    Thread,
    ThreadListParams,
    ThreadResponse,
    UpdateThreadRequest,
    # Email
    Email,
    EmailAddressInput,
    SendEmailRequest,
    SendEmailResponse,
    # Label
    CreateLabelRequest,
    InboxLabel,
    Label,
    UpdateLabelRequest,
    # Document
    DocumentContext,
    DocumentSearchResult,
    InboxDocument,
)

__version__ = "1.0.0"

__all__ = [
    # Clients
    "AIThreadsClient",
    "AsyncAIThreadsClient",
    # Errors
    "AIThreadsError",
    "AuthenticationError",
    "ConflictError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    # Types - Common
    "ApiError",
    "EmailAddress",
    "PaginatedResponse",
    "Pagination",
    "SuccessResponse",
    # Types - Inbox
    "CreateInboxRequest",
    "Inbox",
    "InboxResponse",
    "UpdateInboxRequest",
    # Types - Thread
    "EmailPreview",
    "Thread",
    "ThreadListParams",
    "ThreadResponse",
    "UpdateThreadRequest",
    # Types - Email
    "Email",
    "EmailAddressInput",
    "SendEmailRequest",
    "SendEmailResponse",
    # Types - Label
    "CreateLabelRequest",
    "InboxLabel",
    "Label",
    "UpdateLabelRequest",
    # Types - Document
    "DocumentContext",
    "DocumentSearchResult",
    "InboxDocument",
]

