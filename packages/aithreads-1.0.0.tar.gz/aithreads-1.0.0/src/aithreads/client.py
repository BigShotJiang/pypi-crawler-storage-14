"""AIThreads Client - Main entry point for the SDK."""

from ._base_client import BaseClient
from .resources import (
    DocumentResource,
    EmailResource,
    InboxLabelResource,
    InboxResource,
    LabelResource,
    ThreadResource,
)

DEFAULT_BASE_URL = "https://api.aithreads.io/v1"
DEFAULT_TIMEOUT = 30.0
DEFAULT_RETRIES = 3


class AIThreadsClient:
    """
    Synchronous AIThreads SDK Client.

    Args:
        api_key: API key for authentication (required)
        base_url: Base URL for the API (default: https://api.aithreads.io/v1)
        timeout: Request timeout in seconds (default: 30.0)
        retries: Number of retries for failed requests (default: 3)

    Example:
        >>> from aithreads import AIThreadsClient
        >>>
        >>> client = AIThreadsClient(api_key="ait_xxx...")
        >>>
        >>> # List inboxes
        >>> inboxes = client.inboxes.list()
        >>>
        >>> # Send an email
        >>> email = client.emails.send(
        ...     inbox_id=inboxes[0].id,
        ...     to=[{"email": "user@example.com"}],
        ...     subject="Hello",
        ...     text="Hi there!",
        ... )
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
    ):
        self._client = BaseClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retries=retries,
        )

        # Initialize resources
        self.inboxes = InboxResource(self._client)
        self.threads = ThreadResource(self._client)
        self.emails = EmailResource(self._client)
        self.labels = LabelResource(self._client)
        self.inbox_labels = InboxLabelResource(self._client)
        self.documents = DocumentResource(self._client)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "AIThreadsClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()

