"""Base HTTP client for making API requests."""

from __future__ import annotations

import time
from typing import Any, Dict, Optional, Type, TypeVar

import httpx

from ._exceptions import AIThreadsError

T = TypeVar("T")

DEFAULT_BASE_URL = "https://api.aithreads.io/v1"
DEFAULT_TIMEOUT = 30.0
DEFAULT_RETRIES = 3


class BaseClient:
    """Base synchronous HTTP client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
    ):
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self._client: Optional[httpx.Client] = None

    @property
    def client(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "BaseClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Make an HTTP request with retry logic."""
        # Filter out None values from params
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        last_error: Optional[Exception] = None

        for attempt in range(self.retries + 1):
            try:
                response = self.client.request(
                    method=method,
                    url=endpoint,
                    params=params,
                    json=json,
                    **kwargs,
                )

                if response.status_code == 204:
                    return None

                data = response.json()

                if not response.is_success:
                    raise AIThreadsError.from_response(
                        status=response.status_code,
                        error=data.get("error", "unknown_error"),
                        message=data.get("message", f"HTTP {response.status_code}"),
                        details=data.get("details"),
                    )

                return data

            except AIThreadsError as e:
                # Don't retry client errors except 429
                if e.status < 500 and e.status != 429:
                    raise
                last_error = e
            except Exception as e:
                last_error = e

            # Wait before retrying (exponential backoff)
            if attempt < self.retries:
                time.sleep(2**attempt)

        if last_error:
            raise last_error
        raise RuntimeError("Request failed")

    def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """GET request."""
        return self._request("GET", endpoint, params=params)

    def post(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """POST request."""
        return self._request("POST", endpoint, json=json)

    def patch(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """PATCH request."""
        return self._request("PATCH", endpoint, json=json)

    def delete(self, endpoint: str) -> Any:
        """DELETE request."""
        return self._request("DELETE", endpoint)

    def upload(
        self,
        endpoint: str,
        file: bytes,
        filename: str,
        name: str,
    ) -> Any:
        """Upload a file."""
        files = {"file": (filename, file)}
        data = {"name": name}

        response = self.client.post(
            endpoint,
            files=files,
            data=data,
            headers={"Authorization": f"Bearer {self.api_key}"},
        )

        if not response.is_success:
            data = response.json()
            raise AIThreadsError.from_response(
                status=response.status_code,
                error=data.get("error", "unknown_error"),
                message=data.get("message", f"HTTP {response.status_code}"),
                details=data.get("details"),
            )

        return response.json()


class AsyncBaseClient:
    """Base asynchronous HTTP client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
    ):
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "AsyncBaseClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Make an async HTTP request with retry logic."""
        import asyncio

        # Filter out None values from params
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        last_error: Optional[Exception] = None

        for attempt in range(self.retries + 1):
            try:
                response = await self.client.request(
                    method=method,
                    url=endpoint,
                    params=params,
                    json=json,
                    **kwargs,
                )

                if response.status_code == 204:
                    return None

                data = response.json()

                if not response.is_success:
                    raise AIThreadsError.from_response(
                        status=response.status_code,
                        error=data.get("error", "unknown_error"),
                        message=data.get("message", f"HTTP {response.status_code}"),
                        details=data.get("details"),
                    )

                return data

            except AIThreadsError as e:
                # Don't retry client errors except 429
                if e.status < 500 and e.status != 429:
                    raise
                last_error = e
            except Exception as e:
                last_error = e

            # Wait before retrying (exponential backoff)
            if attempt < self.retries:
                await asyncio.sleep(2**attempt)

        if last_error:
            raise last_error
        raise RuntimeError("Request failed")

    async def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """GET request."""
        return await self._request("GET", endpoint, params=params)

    async def post(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """POST request."""
        return await self._request("POST", endpoint, json=json)

    async def patch(
        self,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """PATCH request."""
        return await self._request("PATCH", endpoint, json=json)

    async def delete(self, endpoint: str) -> Any:
        """DELETE request."""
        return await self._request("DELETE", endpoint)

    async def upload(
        self,
        endpoint: str,
        file: bytes,
        filename: str,
        name: str,
    ) -> Any:
        """Upload a file."""
        files = {"file": (filename, file)}
        data = {"name": name}

        response = await self.client.post(
            endpoint,
            files=files,
            data=data,
            headers={"Authorization": f"Bearer {self.api_key}"},
        )

        if not response.is_success:
            data = response.json()
            raise AIThreadsError.from_response(
                status=response.status_code,
                error=data.get("error", "unknown_error"),
                message=data.get("message", f"HTTP {response.status_code}"),
                details=data.get("details"),
            )

        return response.json()

