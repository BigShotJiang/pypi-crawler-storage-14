"""Inbox types."""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class Inbox(BaseModel):
    """Inbox model."""

    id: str
    organization_id: str
    address: str
    local_part: str
    domain: str
    display_name: Optional[str] = None
    agent_prompt: Optional[str] = None
    webhook_url: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime


class InboxResponse(Inbox):
    """Inbox response with statistics."""

    thread_count: int
    unread_thread_count: int


class CreateInboxRequest(BaseModel):
    """Request to create an inbox."""

    username: str = Field(..., min_length=1, max_length=64, description="Local part of email address")
    name: Optional[str] = Field(None, max_length=100, description="Display name for the inbox")
    webhook_url: Optional[str] = Field(None, description="Webhook URL for incoming emails")


class UpdateInboxRequest(BaseModel):
    """Request to update an inbox."""

    display_name: Optional[str] = Field(None, max_length=100)
    agent_prompt: Optional[str] = Field(None, max_length=10000)
    webhook_url: Optional[str] = None
    is_active: Optional[bool] = None

