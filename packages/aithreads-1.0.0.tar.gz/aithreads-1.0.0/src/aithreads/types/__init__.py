"""Type exports."""

from .common import (
    ApiError,
    EmailAddress,
    PaginatedResponse,
    Pagination,
    SuccessResponse,
)
from .document import (
    DocumentContext,
    DocumentSearchResult,
    InboxDocument,
)
from .email import (
    Email,
    EmailAddressInput,
    SendEmailRequest,
    SendEmailResponse,
)
from .inbox import (
    CreateInboxRequest,
    Inbox,
    InboxResponse,
    UpdateInboxRequest,
)
from .label import (
    CreateLabelRequest,
    InboxLabel,
    Label,
    UpdateLabelRequest,
)
from .thread import (
    EmailPreview,
    Thread,
    ThreadListParams,
    ThreadResponse,
    UpdateThreadRequest,
)

__all__ = [
    # Common
    "ApiError",
    "EmailAddress",
    "PaginatedResponse",
    "Pagination",
    "SuccessResponse",
    # Inbox
    "CreateInboxRequest",
    "Inbox",
    "InboxResponse",
    "UpdateInboxRequest",
    # Thread
    "EmailPreview",
    "Thread",
    "ThreadListParams",
    "ThreadResponse",
    "UpdateThreadRequest",
    # Email
    "Email",
    "EmailAddressInput",
    "SendEmailRequest",
    "SendEmailResponse",
    # Label
    "CreateLabelRequest",
    "InboxLabel",
    "Label",
    "UpdateLabelRequest",
    # Document
    "DocumentContext",
    "DocumentSearchResult",
    "InboxDocument",
]

