"""Document types (Knowledge Base)."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel


class InboxDocument(BaseModel):
    """Inbox document model."""

    id: str
    name: str
    file_name: str
    content_type: str
    size: int
    created_at: datetime


class DocumentSearchResult(InboxDocument):
    """Document search result."""

    score: Optional[float] = None


class DocumentContext(BaseModel):
    """Context response for AI."""

    context: str
    sources: List[dict]

