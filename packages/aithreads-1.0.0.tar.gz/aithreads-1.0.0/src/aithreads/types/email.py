"""Email types."""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .common import EmailAddress


class Email(BaseModel):
    """Email message model."""

    id: str
    thread_id: str
    inbox_id: str
    organization_id: str
    message_id: str
    in_reply_to: Optional[str] = None
    references: List[str] = Field(default_factory=list)
    from_: EmailAddress = Field(alias="from")
    to: List[EmailAddress]
    cc: List[EmailAddress] = Field(default_factory=list)
    bcc: List[EmailAddress] = Field(default_factory=list)
    reply_to: Optional[EmailAddress] = None
    subject: str
    text_body: Optional[str] = None
    html_body: Optional[str] = None
    headers: Dict[str, str] = Field(default_factory=dict)
    direction: Literal["inbound", "outbound"]
    status: Literal["received", "sent", "failed", "queued"]
    sent_at: Optional[datetime] = None
    received_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        populate_by_name = True


class EmailAddressInput(BaseModel):
    """Email address input for sending emails."""

    email: str
    name: Optional[str] = None


class SendEmailRequest(BaseModel):
    """Request to send an email."""

    from_: Optional[EmailAddressInput] = Field(None, alias="from")
    to: List[EmailAddressInput] = Field(..., min_length=1)
    cc: Optional[List[EmailAddressInput]] = None
    bcc: Optional[List[EmailAddressInput]] = None
    reply_to: Optional[EmailAddressInput] = None
    subject: str = Field(..., max_length=998)
    text: Optional[str] = None
    html: Optional[str] = None
    reply_to_message_id: Optional[str] = None
    labels: Optional[List[str]] = None

    class Config:
        populate_by_name = True


class SendEmailResponse(BaseModel):
    """Response after sending an email."""

    id: str
    message_id: str
    thread_id: str
    status: Literal["sent", "queued"]

