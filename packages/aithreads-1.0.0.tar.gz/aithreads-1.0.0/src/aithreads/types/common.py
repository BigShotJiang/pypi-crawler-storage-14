"""Common types shared across the SDK."""

from typing import Any, Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field


class EmailAddress(BaseModel):
    """Email address with optional display name."""

    email: str
    name: Optional[str] = None


class Pagination(BaseModel):
    """Pagination metadata in responses."""

    total: int
    limit: int
    offset: int
    has_more: bool
    next_cursor: Optional[str] = None


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Paginated response wrapper."""

    data: List[T]
    pagination: Pagination


class ApiError(BaseModel):
    """Standard API error response."""

    error: str
    message: str
    details: Optional[dict[str, Any]] = None


class SuccessResponse(BaseModel):
    """Success response for operations without data."""

    message: str

