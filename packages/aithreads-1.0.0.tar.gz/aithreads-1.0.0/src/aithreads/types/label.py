"""Label types."""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class Label(BaseModel):
    """Label model (organization-level)."""

    id: str
    organization_id: str
    name: str
    color: str
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class InboxLabel(Label):
    """Inbox-specific label."""

    inbox_id: str


class CreateLabelRequest(BaseModel):
    """Request to create a label."""

    name: str = Field(..., min_length=1, max_length=50)
    color: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")
    description: Optional[str] = Field(None, max_length=255)


class UpdateLabelRequest(BaseModel):
    """Request to update a label."""

    name: Optional[str] = Field(None, min_length=1, max_length=50)
    color: Optional[str] = Field(None, pattern=r"^#[0-9A-Fa-f]{6}$")
    description: Optional[str] = Field(None, max_length=255)

