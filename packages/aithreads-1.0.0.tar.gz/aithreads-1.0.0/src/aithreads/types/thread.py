"""Thread types."""

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel


class Thread(BaseModel):
    """Thread model."""

    id: str
    inbox_id: str
    organization_id: str
    subject: str
    participants: List[str]
    message_count: int
    last_message_at: datetime
    labels: List[str]
    is_read: bool
    is_archived: bool
    created_at: datetime
    updated_at: datetime


class EmailPreview(BaseModel):
    """Email preview for thread listings."""

    id: str
    from_: str = None  # Will be populated from 'from' field
    subject: str
    snippet: str
    direction: Literal["inbound", "outbound"]
    sent_at: str

    class Config:
        populate_by_name = True

    def __init__(self, **data):
        # Handle 'from' field which is a reserved keyword in Python
        if "from" in data:
            data["from_"] = data.pop("from")
        super().__init__(**data)


class ThreadResponse(Thread):
    """Thread response with latest message preview."""

    latest_message: Optional[EmailPreview] = None


class ThreadListParams(BaseModel):
    """Parameters for listing threads."""

    limit: Optional[int] = 20
    offset: Optional[int] = 0
    is_read: Optional[bool] = None
    is_archived: Optional[bool] = None
    labels: Optional[List[str]] = None
    participant: Optional[str] = None


class UpdateThreadRequest(BaseModel):
    """Request to update a thread."""

    labels: Optional[List[str]] = None
    is_read: Optional[bool] = None
    is_archived: Optional[bool] = None

