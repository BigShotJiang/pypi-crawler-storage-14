"""Document resource for managing inbox knowledge base documents."""

from typing import TYPE_CHECKING, List

from ..types import InboxDocument

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient


class DocumentResource:
    """Synchronous document operations."""

    def __init__(self, client: "BaseClient"):
        self._client = client

    def list(self, inbox_id: str) -> List[InboxDocument]:
        """List documents in an inbox."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}/documents")
        return [InboxDocument(**doc) for doc in data]

    def upload(
        self,
        inbox_id: str,
        file: bytes,
        filename: str,
        name: str,
    ) -> InboxDocument:
        """Upload a document to an inbox."""
        data = self._client.upload(
            f"/agent/inboxes/{inbox_id}/documents",
            file=file,
            filename=filename,
            name=name,
        )
        return InboxDocument(**data)

    def delete(self, inbox_id: str, doc_id: str) -> None:
        """Delete a document."""
        self._client.delete(f"/agent/inboxes/{inbox_id}/documents/{doc_id}")

    def get_download_url(self, inbox_id: str, doc_id: str) -> str:
        """Get download URL for a document."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}/documents/{doc_id}/download")
        return data.get("url", "")

    def search(self, inbox_id: str, query: str) -> List[InboxDocument]:
        """Search documents by query."""
        data = self._client.get(
            f"/agent/inboxes/{inbox_id}/documents/search",
            params={"q": query},
        )
        return [InboxDocument(**doc) for doc in data]

    def get_context(self, inbox_id: str, query: str, limit: int = 5) -> str:
        """Get relevant context from documents for AI."""
        data = self._client.get(
            f"/agent/inboxes/{inbox_id}/documents/context",
            params={"q": query, "limit": limit},
        )
        return data.get("context", "")


class AsyncDocumentResource:
    """Asynchronous document operations."""

    def __init__(self, client: "AsyncBaseClient"):
        self._client = client

    async def list(self, inbox_id: str) -> List[InboxDocument]:
        """List documents in an inbox."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/documents")
        return [InboxDocument(**doc) for doc in data]

    async def upload(
        self,
        inbox_id: str,
        file: bytes,
        filename: str,
        name: str,
    ) -> InboxDocument:
        """Upload a document to an inbox."""
        data = await self._client.upload(
            f"/agent/inboxes/{inbox_id}/documents",
            file=file,
            filename=filename,
            name=name,
        )
        return InboxDocument(**data)

    async def delete(self, inbox_id: str, doc_id: str) -> None:
        """Delete a document."""
        await self._client.delete(f"/agent/inboxes/{inbox_id}/documents/{doc_id}")

    async def get_download_url(self, inbox_id: str, doc_id: str) -> str:
        """Get download URL for a document."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/documents/{doc_id}/download")
        return data.get("url", "")

    async def search(self, inbox_id: str, query: str) -> List[InboxDocument]:
        """Search documents by query."""
        data = await self._client.get(
            f"/agent/inboxes/{inbox_id}/documents/search",
            params={"q": query},
        )
        return [InboxDocument(**doc) for doc in data]

    async def get_context(self, inbox_id: str, query: str, limit: int = 5) -> str:
        """Get relevant context from documents for AI."""
        data = await self._client.get(
            f"/agent/inboxes/{inbox_id}/documents/context",
            params={"q": query, "limit": limit},
        )
        return data.get("context", "")

