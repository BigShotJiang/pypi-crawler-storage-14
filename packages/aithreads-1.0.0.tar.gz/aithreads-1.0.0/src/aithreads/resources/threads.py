"""Thread resource for managing email threads."""

from typing import TYPE_CHECKING, List, Optional

from ..types import (
    PaginatedResponse,
    Pagination,
    ThreadResponse,
    UpdateThreadRequest,
)

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient


class ThreadResource:
    """Synchronous thread operations."""

    def __init__(self, client: "BaseClient"):
        self._client = client

    def list(
        self,
        inbox_id: str,
        limit: int = 20,
        offset: int = 0,
        is_read: Optional[bool] = None,
        is_archived: Optional[bool] = None,
        labels: Optional[List[str]] = None,
        participant: Optional[str] = None,
    ) -> PaginatedResponse[ThreadResponse]:
        """List threads in an inbox."""
        params = {
            "limit": limit,
            "offset": offset,
            "is_read": is_read,
            "is_archived": is_archived,
            "labels": ",".join(labels) if labels else None,
            "participant": participant,
        }
        data = self._client.get(f"/agent/inboxes/{inbox_id}/threads", params=params)
        return PaginatedResponse[ThreadResponse](
            data=[ThreadResponse(**t) for t in data["data"]],
            pagination=Pagination(**data["pagination"]),
        )

    def find_by_email(
        self,
        inbox_id: str,
        email: str,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResponse[ThreadResponse]:
        """Find all threads where the given email is a participant."""
        return self.list(inbox_id, limit=limit, offset=offset, participant=email)

    def get(self, inbox_id: str, thread_id: str) -> ThreadResponse:
        """Get thread by ID."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}/threads/{thread_id}")
        # API returns {thread: {...}, emails: [...]}
        thread_data = data.get("thread", data)
        return ThreadResponse(**thread_data)

    def update(
        self,
        inbox_id: str,
        thread_id: str,
        labels: Optional[List[str]] = None,
        is_read: Optional[bool] = None,
        is_archived: Optional[bool] = None,
    ) -> ThreadResponse:
        """Update a thread."""
        request = UpdateThreadRequest(
            labels=labels,
            is_read=is_read,
            is_archived=is_archived,
        )
        data = self._client.patch(
            f"/agent/inboxes/{inbox_id}/threads/{thread_id}",
            json=request.model_dump(exclude_none=True),
        )
        thread_data = data.get("thread", data)
        return ThreadResponse(**thread_data)

    def delete(self, inbox_id: str, thread_id: str) -> None:
        """Delete a thread."""
        self._client.delete(f"/agent/inboxes/{inbox_id}/threads/{thread_id}")

    def mark_as_read(self, inbox_id: str, thread_id: str) -> None:
        """Mark thread as read."""
        self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/read")

    def mark_as_unread(self, inbox_id: str, thread_id: str) -> None:
        """Mark thread as unread."""
        self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/unread")

    def archive(self, inbox_id: str, thread_id: str) -> None:
        """Archive a thread."""
        self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/archive")

    def unarchive(self, inbox_id: str, thread_id: str) -> None:
        """Unarchive a thread."""
        self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/unarchive")


class AsyncThreadResource:
    """Asynchronous thread operations."""

    def __init__(self, client: "AsyncBaseClient"):
        self._client = client

    async def list(
        self,
        inbox_id: str,
        limit: int = 20,
        offset: int = 0,
        is_read: Optional[bool] = None,
        is_archived: Optional[bool] = None,
        labels: Optional[List[str]] = None,
        participant: Optional[str] = None,
    ) -> PaginatedResponse[ThreadResponse]:
        """List threads in an inbox."""
        params = {
            "limit": limit,
            "offset": offset,
            "is_read": is_read,
            "is_archived": is_archived,
            "labels": ",".join(labels) if labels else None,
            "participant": participant,
        }
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/threads", params=params)
        return PaginatedResponse[ThreadResponse](
            data=[ThreadResponse(**t) for t in data["data"]],
            pagination=Pagination(**data["pagination"]),
        )

    async def find_by_email(
        self,
        inbox_id: str,
        email: str,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResponse[ThreadResponse]:
        """Find all threads where the given email is a participant."""
        return await self.list(inbox_id, limit=limit, offset=offset, participant=email)

    async def get(self, inbox_id: str, thread_id: str) -> ThreadResponse:
        """Get thread by ID."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/threads/{thread_id}")
        thread_data = data.get("thread", data)
        return ThreadResponse(**thread_data)

    async def update(
        self,
        inbox_id: str,
        thread_id: str,
        labels: Optional[List[str]] = None,
        is_read: Optional[bool] = None,
        is_archived: Optional[bool] = None,
    ) -> ThreadResponse:
        """Update a thread."""
        request = UpdateThreadRequest(
            labels=labels,
            is_read=is_read,
            is_archived=is_archived,
        )
        data = await self._client.patch(
            f"/agent/inboxes/{inbox_id}/threads/{thread_id}",
            json=request.model_dump(exclude_none=True),
        )
        thread_data = data.get("thread", data)
        return ThreadResponse(**thread_data)

    async def delete(self, inbox_id: str, thread_id: str) -> None:
        """Delete a thread."""
        await self._client.delete(f"/agent/inboxes/{inbox_id}/threads/{thread_id}")

    async def mark_as_read(self, inbox_id: str, thread_id: str) -> None:
        """Mark thread as read."""
        await self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/read")

    async def mark_as_unread(self, inbox_id: str, thread_id: str) -> None:
        """Mark thread as unread."""
        await self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/unread")

    async def archive(self, inbox_id: str, thread_id: str) -> None:
        """Archive a thread."""
        await self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/archive")

    async def unarchive(self, inbox_id: str, thread_id: str) -> None:
        """Unarchive a thread."""
        await self._client.post(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/unarchive")

