"""Email resource for sending and reading emails."""

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from ..types import Email, EmailAddressInput, SendEmailRequest, SendEmailResponse

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient


class EmailResource:
    """Synchronous email operations."""

    def __init__(self, client: "BaseClient"):
        self._client = client

    def send(
        self,
        inbox_id: str,
        to: List[Dict[str, str]],
        subject: str,
        text: Optional[str] = None,
        html: Optional[str] = None,
        cc: Optional[List[Dict[str, str]]] = None,
        bcc: Optional[List[Dict[str, str]]] = None,
        reply_to: Optional[Dict[str, str]] = None,
        from_address: Optional[Dict[str, str]] = None,
        reply_to_message_id: Optional[str] = None,
        labels: Optional[List[str]] = None,
    ) -> SendEmailResponse:
        """Send an email from an inbox."""
        request_data: Dict[str, Any] = {
            "to": [EmailAddressInput(**addr) for addr in to],
            "subject": subject,
        }

        if text:
            request_data["text"] = text
        if html:
            request_data["html"] = html
        if cc:
            request_data["cc"] = [EmailAddressInput(**addr) for addr in cc]
        if bcc:
            request_data["bcc"] = [EmailAddressInput(**addr) for addr in bcc]
        if reply_to:
            request_data["reply_to"] = EmailAddressInput(**reply_to)
        if from_address:
            request_data["from_"] = EmailAddressInput(**from_address)
        if reply_to_message_id:
            request_data["reply_to_message_id"] = reply_to_message_id
        if labels:
            request_data["labels"] = labels

        request = SendEmailRequest(**request_data)
        # Use by_alias to convert from_ back to 'from' for the API
        data = self._client.post(
            f"/agent/inboxes/{inbox_id}/messages",
            json=request.model_dump(exclude_none=True, by_alias=True),
        )
        return SendEmailResponse(**data)

    def list_by_thread(self, inbox_id: str, thread_id: str) -> List[Email]:
        """List emails in a thread."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/messages")
        emails = data.get("emails", data)
        return [Email(**email) for email in emails]

    def get(self, email_id: str) -> Email:
        """Get email by ID."""
        data = self._client.get(f"/agent/emails/{email_id}")
        return Email(**data)

    def get_raw(self, email_id: str) -> str:
        """Get raw email content (RFC 5322 format)."""
        data = self._client.get(f"/agent/emails/{email_id}/raw")
        if isinstance(data, str):
            return data
        return data.get("content", "")


class AsyncEmailResource:
    """Asynchronous email operations."""

    def __init__(self, client: "AsyncBaseClient"):
        self._client = client

    async def send(
        self,
        inbox_id: str,
        to: List[Dict[str, str]],
        subject: str,
        text: Optional[str] = None,
        html: Optional[str] = None,
        cc: Optional[List[Dict[str, str]]] = None,
        bcc: Optional[List[Dict[str, str]]] = None,
        reply_to: Optional[Dict[str, str]] = None,
        from_address: Optional[Dict[str, str]] = None,
        reply_to_message_id: Optional[str] = None,
        labels: Optional[List[str]] = None,
    ) -> SendEmailResponse:
        """Send an email from an inbox."""
        request_data: Dict[str, Any] = {
            "to": [EmailAddressInput(**addr) for addr in to],
            "subject": subject,
        }

        if text:
            request_data["text"] = text
        if html:
            request_data["html"] = html
        if cc:
            request_data["cc"] = [EmailAddressInput(**addr) for addr in cc]
        if bcc:
            request_data["bcc"] = [EmailAddressInput(**addr) for addr in bcc]
        if reply_to:
            request_data["reply_to"] = EmailAddressInput(**reply_to)
        if from_address:
            request_data["from_"] = EmailAddressInput(**from_address)
        if reply_to_message_id:
            request_data["reply_to_message_id"] = reply_to_message_id
        if labels:
            request_data["labels"] = labels

        request = SendEmailRequest(**request_data)
        data = await self._client.post(
            f"/agent/inboxes/{inbox_id}/messages",
            json=request.model_dump(exclude_none=True, by_alias=True),
        )
        return SendEmailResponse(**data)

    async def list_by_thread(self, inbox_id: str, thread_id: str) -> List[Email]:
        """List emails in a thread."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/threads/{thread_id}/messages")
        emails = data.get("emails", data)
        return [Email(**email) for email in emails]

    async def get(self, email_id: str) -> Email:
        """Get email by ID."""
        data = await self._client.get(f"/agent/emails/{email_id}")
        return Email(**data)

    async def get_raw(self, email_id: str) -> str:
        """Get raw email content (RFC 5322 format)."""
        data = await self._client.get(f"/agent/emails/{email_id}/raw")
        if isinstance(data, str):
            return data
        return data.get("content", "")

