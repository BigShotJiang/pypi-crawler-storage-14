"""Inbox resource for managing email inboxes."""

from typing import TYPE_CHECKING, List, Optional, Union

from ..types import CreateInboxRequest, InboxResponse, UpdateInboxRequest

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient


class InboxResource:
    """Synchronous inbox operations."""

    def __init__(self, client: "BaseClient"):
        self._client = client

    def list(self) -> List[InboxResponse]:
        """List all inboxes."""
        data = self._client.get("/agent/inboxes")
        return [InboxResponse(**inbox) for inbox in data]

    def create(
        self,
        username: str,
        name: Optional[str] = None,
        webhook_url: Optional[str] = None,
    ) -> InboxResponse:
        """Create a new inbox."""
        request = CreateInboxRequest(
            username=username,
            name=name,
            webhook_url=webhook_url,
        )
        data = self._client.post("/agent/inboxes", json=request.model_dump(exclude_none=True))
        return InboxResponse(**data)

    def get(self, inbox_id: str) -> InboxResponse:
        """Get inbox by ID."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}")
        return InboxResponse(**data)

    def update(
        self,
        inbox_id: str,
        display_name: Optional[str] = None,
        agent_prompt: Optional[str] = None,
        webhook_url: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> InboxResponse:
        """Update an inbox."""
        request = UpdateInboxRequest(
            display_name=display_name,
            agent_prompt=agent_prompt,
            webhook_url=webhook_url,
            is_active=is_active,
        )
        data = self._client.patch(
            f"/agent/inboxes/{inbox_id}",
            json=request.model_dump(exclude_none=True),
        )
        return InboxResponse(**data)

    def delete(self, inbox_id: str) -> None:
        """Delete an inbox."""
        self._client.delete(f"/agent/inboxes/{inbox_id}")


class AsyncInboxResource:
    """Asynchronous inbox operations."""

    def __init__(self, client: "AsyncBaseClient"):
        self._client = client

    async def list(self) -> List[InboxResponse]:
        """List all inboxes."""
        data = await self._client.get("/agent/inboxes")
        return [InboxResponse(**inbox) for inbox in data]

    async def create(
        self,
        username: str,
        name: Optional[str] = None,
        webhook_url: Optional[str] = None,
    ) -> InboxResponse:
        """Create a new inbox."""
        request = CreateInboxRequest(
            username=username,
            name=name,
            webhook_url=webhook_url,
        )
        data = await self._client.post("/agent/inboxes", json=request.model_dump(exclude_none=True))
        return InboxResponse(**data)

    async def get(self, inbox_id: str) -> InboxResponse:
        """Get inbox by ID."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}")
        return InboxResponse(**data)

    async def update(
        self,
        inbox_id: str,
        display_name: Optional[str] = None,
        agent_prompt: Optional[str] = None,
        webhook_url: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> InboxResponse:
        """Update an inbox."""
        request = UpdateInboxRequest(
            display_name=display_name,
            agent_prompt=agent_prompt,
            webhook_url=webhook_url,
            is_active=is_active,
        )
        data = await self._client.patch(
            f"/agent/inboxes/{inbox_id}",
            json=request.model_dump(exclude_none=True),
        )
        return InboxResponse(**data)

    async def delete(self, inbox_id: str) -> None:
        """Delete an inbox."""
        await self._client.delete(f"/agent/inboxes/{inbox_id}")

