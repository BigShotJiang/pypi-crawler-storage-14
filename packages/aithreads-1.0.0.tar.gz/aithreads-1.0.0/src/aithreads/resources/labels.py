"""Label resource for managing organization and inbox labels."""

from typing import TYPE_CHECKING, List, Optional

from ..types import (
    CreateLabelRequest,
    InboxLabel,
    Label,
    UpdateLabelRequest,
)

if TYPE_CHECKING:
    from .._base_client import AsyncBaseClient, BaseClient


class LabelResource:
    """Synchronous organization label operations."""

    def __init__(self, client: "BaseClient"):
        self._client = client

    def list(self) -> List[Label]:
        """List all organization labels."""
        data = self._client.get("/agent/labels")
        return [Label(**label) for label in data]

    def create(
        self,
        name: str,
        color: str,
        description: Optional[str] = None,
    ) -> Label:
        """Create a new label."""
        request = CreateLabelRequest(name=name, color=color, description=description)
        data = self._client.post("/agent/labels", json=request.model_dump(exclude_none=True))
        return Label(**data)

    def get(self, label_id: str) -> Label:
        """Get label by ID."""
        data = self._client.get(f"/agent/labels/{label_id}")
        return Label(**data)

    def update(
        self,
        label_id: str,
        name: Optional[str] = None,
        color: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Label:
        """Update a label."""
        request = UpdateLabelRequest(name=name, color=color, description=description)
        data = self._client.patch(
            f"/agent/labels/{label_id}",
            json=request.model_dump(exclude_none=True),
        )
        return Label(**data)

    def delete(self, label_id: str) -> None:
        """Delete a label."""
        self._client.delete(f"/agent/labels/{label_id}")


class InboxLabelResource:
    """Synchronous inbox-specific label operations."""

    def __init__(self, client: "BaseClient"):
        self._client = client

    def list(self, inbox_id: str) -> List[InboxLabel]:
        """List labels for an inbox."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}/labels")
        return [InboxLabel(**label) for label in data]

    def create(
        self,
        inbox_id: str,
        name: str,
        color: str,
        description: Optional[str] = None,
    ) -> InboxLabel:
        """Create a new inbox label."""
        request = CreateLabelRequest(name=name, color=color, description=description)
        data = self._client.post(
            f"/agent/inboxes/{inbox_id}/labels",
            json=request.model_dump(exclude_none=True),
        )
        return InboxLabel(**data)

    def get(self, inbox_id: str, label_id: str) -> InboxLabel:
        """Get inbox label by ID."""
        data = self._client.get(f"/agent/inboxes/{inbox_id}/labels/{label_id}")
        return InboxLabel(**data)

    def update(
        self,
        inbox_id: str,
        label_id: str,
        name: Optional[str] = None,
        color: Optional[str] = None,
        description: Optional[str] = None,
    ) -> InboxLabel:
        """Update an inbox label."""
        request = UpdateLabelRequest(name=name, color=color, description=description)
        data = self._client.patch(
            f"/agent/inboxes/{inbox_id}/labels/{label_id}",
            json=request.model_dump(exclude_none=True),
        )
        return InboxLabel(**data)

    def delete(self, inbox_id: str, label_id: str) -> None:
        """Delete an inbox label."""
        self._client.delete(f"/agent/inboxes/{inbox_id}/labels/{label_id}")


class AsyncLabelResource:
    """Asynchronous organization label operations."""

    def __init__(self, client: "AsyncBaseClient"):
        self._client = client

    async def list(self) -> List[Label]:
        """List all organization labels."""
        data = await self._client.get("/agent/labels")
        return [Label(**label) for label in data]

    async def create(
        self,
        name: str,
        color: str,
        description: Optional[str] = None,
    ) -> Label:
        """Create a new label."""
        request = CreateLabelRequest(name=name, color=color, description=description)
        data = await self._client.post("/agent/labels", json=request.model_dump(exclude_none=True))
        return Label(**data)

    async def get(self, label_id: str) -> Label:
        """Get label by ID."""
        data = await self._client.get(f"/agent/labels/{label_id}")
        return Label(**data)

    async def update(
        self,
        label_id: str,
        name: Optional[str] = None,
        color: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Label:
        """Update a label."""
        request = UpdateLabelRequest(name=name, color=color, description=description)
        data = await self._client.patch(
            f"/agent/labels/{label_id}",
            json=request.model_dump(exclude_none=True),
        )
        return Label(**data)

    async def delete(self, label_id: str) -> None:
        """Delete a label."""
        await self._client.delete(f"/agent/labels/{label_id}")


class AsyncInboxLabelResource:
    """Asynchronous inbox-specific label operations."""

    def __init__(self, client: "AsyncBaseClient"):
        self._client = client

    async def list(self, inbox_id: str) -> List[InboxLabel]:
        """List labels for an inbox."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/labels")
        return [InboxLabel(**label) for label in data]

    async def create(
        self,
        inbox_id: str,
        name: str,
        color: str,
        description: Optional[str] = None,
    ) -> InboxLabel:
        """Create a new inbox label."""
        request = CreateLabelRequest(name=name, color=color, description=description)
        data = await self._client.post(
            f"/agent/inboxes/{inbox_id}/labels",
            json=request.model_dump(exclude_none=True),
        )
        return InboxLabel(**data)

    async def get(self, inbox_id: str, label_id: str) -> InboxLabel:
        """Get inbox label by ID."""
        data = await self._client.get(f"/agent/inboxes/{inbox_id}/labels/{label_id}")
        return InboxLabel(**data)

    async def update(
        self,
        inbox_id: str,
        label_id: str,
        name: Optional[str] = None,
        color: Optional[str] = None,
        description: Optional[str] = None,
    ) -> InboxLabel:
        """Update an inbox label."""
        request = UpdateLabelRequest(name=name, color=color, description=description)
        data = await self._client.patch(
            f"/agent/inboxes/{inbox_id}/labels/{label_id}",
            json=request.model_dump(exclude_none=True),
        )
        return InboxLabel(**data)

    async def delete(self, inbox_id: str, label_id: str) -> None:
        """Delete an inbox label."""
        await self._client.delete(f"/agent/inboxes/{inbox_id}/labels/{label_id}")

