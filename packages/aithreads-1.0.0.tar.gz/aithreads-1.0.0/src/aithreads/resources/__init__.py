"""Resource exports."""

from .documents import AsyncDocumentResource, DocumentResource
from .emails import AsyncEmailResource, EmailResource
from .inboxes import AsyncInboxResource, InboxResource
from .labels import (
    AsyncInboxLabelResource,
    AsyncLabelResource,
    InboxLabelResource,
    LabelResource,
)
from .threads import AsyncThreadResource, ThreadResource

__all__ = [
    "DocumentResource",
    "AsyncDocumentResource",
    "EmailResource",
    "AsyncEmailResource",
    "InboxResource",
    "AsyncInboxResource",
    "InboxLabelResource",
    "AsyncInboxLabelResource",
    "LabelResource",
    "AsyncLabelResource",
    "ThreadResource",
    "AsyncThreadResource",
]

