"""Custom exception classes for the AIThreads SDK."""

from typing import Any, Dict, Optional


class AIThreadsError(Exception):
    """Base exception for AIThreads SDK."""

    def __init__(
        self,
        message: str,
        code: str,
        status: int,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status = status
        self.details = details or {}

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, code={self.code!r}, status={self.status})"

    @classmethod
    def from_response(
        cls,
        status: int,
        error: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> "AIThreadsError":
        """Create appropriate error class based on status code."""
        error_class = _get_error_class(status)
        return error_class(message=message, code=error, status=status, details=details)


class ValidationError(AIThreadsError):
    """Raised for validation errors (400)."""

    def __init__(
        self,
        message: str,
        code: str = "validation_error",
        status: int = 400,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


class AuthenticationError(AIThreadsError):
    """Raised for authentication errors (401)."""

    def __init__(
        self,
        message: str,
        code: str = "unauthorized",
        status: int = 401,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


class ForbiddenError(AIThreadsError):
    """Raised for permission errors (403)."""

    def __init__(
        self,
        message: str,
        code: str = "forbidden",
        status: int = 403,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


class NotFoundError(AIThreadsError):
    """Raised when resource not found (404)."""

    def __init__(
        self,
        message: str,
        code: str = "not_found",
        status: int = 404,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


class ConflictError(AIThreadsError):
    """Raised for conflict errors (409)."""

    def __init__(
        self,
        message: str,
        code: str = "conflict",
        status: int = 409,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


class RateLimitError(AIThreadsError):
    """Raised when rate limited (429)."""

    def __init__(
        self,
        message: str,
        code: str = "rate_limited",
        status: int = 429,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


class ServerError(AIThreadsError):
    """Raised for server errors (5xx)."""

    def __init__(
        self,
        message: str,
        code: str = "internal_error",
        status: int = 500,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, code, status, details)


def _get_error_class(status: int) -> type:
    """Get appropriate error class based on status code."""
    if status == 400:
        return ValidationError
    elif status == 401:
        return AuthenticationError
    elif status == 403:
        return ForbiddenError
    elif status == 404:
        return NotFoundError
    elif status == 409:
        return ConflictError
    elif status == 429:
        return RateLimitError
    elif status >= 500:
        return ServerError
    else:
        return AIThreadsError

