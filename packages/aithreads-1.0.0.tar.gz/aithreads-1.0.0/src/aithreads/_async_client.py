"""Async AIThreads Client."""

from ._base_client import AsyncBaseClient
from .resources import (
    AsyncDocumentResource,
    AsyncEmailResource,
    AsyncInboxLabelResource,
    AsyncInboxResource,
    AsyncLabelResource,
    AsyncThreadResource,
)

DEFAULT_BASE_URL = "https://api.aithreads.io/v1"
DEFAULT_TIMEOUT = 30.0
DEFAULT_RETRIES = 3


class AsyncAIThreadsClient:
    """
    Asynchronous AIThreads SDK Client.

    Args:
        api_key: API key for authentication (required)
        base_url: Base URL for the API (default: https://api.aithreads.io/v1)
        timeout: Request timeout in seconds (default: 30.0)
        retries: Number of retries for failed requests (default: 3)

    Example:
        >>> from aithreads import AsyncAIThreadsClient
        >>> import asyncio
        >>>
        >>> async def main():
        ...     client = AsyncAIThreadsClient(api_key="ait_xxx...")
        ...
        ...     # List inboxes
        ...     inboxes = await client.inboxes.list()
        ...
        ...     # Send an email
        ...     email = await client.emails.send(
        ...         inbox_id=inboxes[0].id,
        ...         to=[{"email": "user@example.com"}],
        ...         subject="Hello",
        ...         text="Hi there!",
        ...     )
        ...
        ...     await client.close()
        >>>
        >>> asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
    ):
        self._client = AsyncBaseClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retries=retries,
        )

        # Initialize resources
        self.inboxes = AsyncInboxResource(self._client)
        self.threads = AsyncThreadResource(self._client)
        self.emails = AsyncEmailResource(self._client)
        self.labels = AsyncLabelResource(self._client)
        self.inbox_labels = AsyncInboxLabelResource(self._client)
        self.documents = AsyncDocumentResource(self._client)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.close()

    async def __aenter__(self) -> "AsyncAIThreadsClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

