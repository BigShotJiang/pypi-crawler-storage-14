
from ..utility import WORKING_DIR

SESSION_DIR = WORKING_DIR.joinpath("session")
SESSION_DIR.mkdir(parents=True, exist_ok=True)
