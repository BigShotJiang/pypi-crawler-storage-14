"""Prompt templates for LIMEN-AI + LLM orchestration."""

from __future__ import annotations

from textwrap import dedent

from .schema import SchemaRegistry


def build_extraction_prompt(chunk: str, registry: SchemaRegistry) -> str:
    """Prompt instructing the LLM to extract structured facts."""

    instruction = registry.as_instruction()
    prompt = f"""
You are an information extraction assistant. Analyse the following text chunk and emit
JSON with the format:
[
  {{
    "predicate": "predicate_name",
    "args": ["arg1", "arg2", ...],
    "confidence": 0.0-1.0,
    "provenance": "optional source snippet"
  }}
]
Only use predicates from the schema below, and make sure the number of arguments matches the definition.
If no facts are found, return an empty JSON list [].
Always fill the arguments with the concrete entity names that appear in the text (e.g., "alice", "srv3").
Never echo placeholder labels such as "user", "host", "source_host", or "target_asset".

Example:
Text: "Alice failed to authenticate twice on srv3."
JSON:
[
  {{"predicate": "failedLoginOn", "args": ["alice", "srv3"], "confidence": 0.92}}
]

{instruction}

Text chunk:
\"\"\"
{chunk}
\"\"\"

JSON:
"""
    return dedent(prompt).strip()


def build_schema_induction_prompt(text: str, max_predicates: int = 6) -> str:
    """Prompt that asks the LLM to propose predicate schemas from free-form text."""

    prompt = f"""
You are designing predicate schemas for the LIMEN-AI probabilistic logic engine.
Read the narrative below and derive up to {max_predicates} predicate definitions that
would help represent its facts in first-order logic form.

Respond strictly in JSON:
{{
  "predicates": [
    {{
      "name": "camelCasePredicateName",
      "arity": 2,
      "arg_names": ["argOne", "argTwo"],
      "description": "Concise natural-language description"
    }}
  ]
}}

Guidelines:
- Use camelCase predicate names without spaces or punctuation.
- Set the arity equal to the length of arg_names.
- Each arg_names entry must be a descriptive camelCase identifier.
- Only include predicates that are clearly supported by the text.
- Avoid duplicate or overlapping predicates; prefer concise coverage.

Narrative:
\"\"\"
{text}
\"\"\"

JSON:
"""
    return dedent(prompt).strip()


def build_query_prompt(question: str, registry: SchemaRegistry) -> str:
    """Prompt that translates a user question into predicate calls."""

    instruction = registry.as_instruction()
    prompt = f"""
Translate the user's question into a list of predicate calls from the schema below.
Respond in JSON with the format:
{{
  "queries": [
    {{"predicate": "name", "args": ["arg1", "arg2", ...]}}
  ]
}}
If the question cannot be mapped, respond with {{"queries": []}}.

{instruction}

Question: \"{question}\"
JSON:
"""
    return dedent(prompt).strip()


def build_response_prompt(structured_answer: str, user_question: str) -> str:
    """Prompt instructing the LLM to turn structured data into natural language."""

    prompt = f"""
You are an analyst assistant. Convert the following structured LIMEN-AI answer into
a short, user-friendly explanation. Ensure you mention the key predicates involved and
highlight any provenance.

Question: {user_question}

Structured answer:
{structured_answer}

Response:
"""
    return dedent(prompt).strip()

