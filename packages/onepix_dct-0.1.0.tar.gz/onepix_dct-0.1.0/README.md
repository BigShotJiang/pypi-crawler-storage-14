# Discrete Cosine Transform (DCT) Imaging Method  
---  
## Overview  
The *DCT* (Discrete Cosine Transform) imaging method is a classical single-pixel imaging technique based on discrete cosine patterns. This orthogonal pattern basis is the same one historically used in JPEG compression.  

| Development Status | Technique Specificity | Measurement Output Format | Example Patterns |
|--------------------|-----------------------|----------------------------|------------------|
| Functional and final | Classical SPI | Raw measurements: spectra / masks / metadata | <p align="center"> <img src="img/DCT_pattern.png" alt="hub" width="100"/> </p> |

## install 
tested with python 3.9
```bash
pip install onepix_dct
```

## 🔗 Source Code  
📁 Access the source code on GitHub:  
👉 [ONE-PIX – DCT Imaging Method](https://github.com/PhotonicsOpenProjects/ONE-PIX/tree/main/plugins/imaging_methods/DCT)

## 🧪 Author & Contributor  
🔧 Made by [POP](https://www.photonics-open-projects.com/) 💡