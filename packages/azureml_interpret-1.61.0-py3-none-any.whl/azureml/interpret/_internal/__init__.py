# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Init file for azureml-interpret/azureml/interpret/_internal."""
from .explanation_client import _translate_y_to_indices

__all__ = ["_translate_y_to_indices"]

"""Update the user agent with the current package version."""
try:
    import azureml._base_sdk_common.user_agent as user_agent
    import os
    current_package = __package__ or os.path.splitext(os.path.basename(__file__))[0]
    user_agent.append(current_package, "no_version")
except Exception:
    # Silently continue if user agent update fails
    pass
