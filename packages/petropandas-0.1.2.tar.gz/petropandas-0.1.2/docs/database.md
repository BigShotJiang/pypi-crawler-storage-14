::: petropandas.database
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members:
         - PetroDB
         - PetroDBProject
         - PetroDBSample
         - PetroDBSpot
         - PetroDBArea
         - PetroDBProfile
         - PetroDBProfileSpot
         - PetroDBRecords
         - PetroDBAdmin
