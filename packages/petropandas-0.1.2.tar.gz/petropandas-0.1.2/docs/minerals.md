::: petropandas.minerals
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members:
         - Mineral
         - Feldspar
         - Garnet
         - Garnet_Fe2
         - Pyroxene
         - Pyroxene_Fe2
         - StrucForm
         - Site
