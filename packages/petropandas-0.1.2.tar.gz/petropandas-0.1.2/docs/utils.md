::: petropandas.pandas_accessors.PetroAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members_order: "source"

::: petropandas.pandas_accessors.IsoplotAccessor
    handler: python
    options:
        group_by_category: true
        show_root_heading: true
        show_source: false
        members_order: "source"
