from serializall.factory import SerializableFactory, SerializableBase, SERIALIZABLE
from serializall import serializer  #to register base types
