"""Helper tools for jsonl-normalizer (CLI utilities, etc.)."""
