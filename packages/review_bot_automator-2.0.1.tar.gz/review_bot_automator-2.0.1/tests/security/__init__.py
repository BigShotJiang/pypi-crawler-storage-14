"""Security tests for the Review Bot Automator."""
