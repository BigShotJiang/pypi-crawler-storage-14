"""Core conflict resolution logic."""
