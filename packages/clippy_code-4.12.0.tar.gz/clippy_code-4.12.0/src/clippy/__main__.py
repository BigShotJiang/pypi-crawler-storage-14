"""Entry point for running clippy as a module."""

from .cli import main

if __name__ == "__main__":
    main()
