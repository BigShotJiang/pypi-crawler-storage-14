# We can remove this file when the default pip version
# that Python installs is pip >= 21.3
from setuptools import setup

setup()
