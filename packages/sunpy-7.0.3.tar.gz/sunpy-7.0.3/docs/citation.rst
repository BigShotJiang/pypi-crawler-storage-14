.. include:: ../sunpy/CITATION.rst
