.. _funding:

.. warning:: HEAVY WIP

*********************
Submodule and funding
*********************

Here we list whatever parts of the SunPy project have been funded by external sources such as grants or Google Summer of Code (GSoC) and the like.

Database
========

Google Summer of Code (2013)
----------------------------

Parts of the now removed ``sunpy.database`` module.

Net
---

Google Summer of Code (2014)
----------------------------

fido_factory.py, vso.py, most of the dataretriever submodule

ESA Summer of Code in Space (2011)
----------------------------------

attr.py
tools/hektemplate.py
tools/hek_mkcls.py
