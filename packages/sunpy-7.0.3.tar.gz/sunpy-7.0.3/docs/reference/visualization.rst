Visualization (`sunpy.visualization`)
*************************************

`sunpy.visualization` contains plotting helpers and functions.

.. automodapi:: sunpy.visualization

.. automodapi:: sunpy.visualization.colormaps

.. automodapi:: sunpy.visualization.colormaps.color_tables

.. automodapi:: sunpy.visualization.animator

.. automodapi:: sunpy.visualization.wcsaxes_compat

.. automodapi:: sunpy.visualization.drawing
