Time (`sunpy.time`)
*******************

``sunpy.time`` contains helpers for converting strings to `astropy.time.Time`
objects and handling common operations on these objects. As well as this a
`~sunpy.time.TimeRange` object is provided for representing a period of time
and performing operations on that range.

.. automodapi:: sunpy.time
