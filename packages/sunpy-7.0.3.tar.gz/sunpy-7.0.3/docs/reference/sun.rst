.. _sun_code_ref:

Solar properties (``sunpy.sun``)
********************************

``sunpy.sun`` contains constants, parameters and models of the Sun.

.. automodapi:: sunpy.sun.constants
   :include-all-objects:

.. automodapi:: sunpy.sun.models
   :include-all-objects:
