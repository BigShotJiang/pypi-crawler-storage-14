Computer Vision Techniques
==========================

Examples of using computer vision techniques to analyze solar data
