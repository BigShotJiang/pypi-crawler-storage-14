Map
===

Examples using `~sunpy.map.Map` with solar data
