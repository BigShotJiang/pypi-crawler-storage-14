Differential Rotation of the Sun
================================

Examples of accounting for differential rotation (i.e., the latitude-dependent rotation rate of the Sun) in the coordinates framework
