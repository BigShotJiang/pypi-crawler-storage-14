Acquiring Data
==============

Examples of downloading solar data located on remote servers
