Coordinates, times, and units
=============================

Examples of working with coordinate information, times, and scientific units
