Plotting
========

Examples of visualizing supported data types
