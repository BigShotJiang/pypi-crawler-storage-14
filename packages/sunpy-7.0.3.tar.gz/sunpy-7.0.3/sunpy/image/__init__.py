# Check if user has installed the image extras
from sunpy.util.sysinfo import _warn_missing_deps

_warn_missing_deps('image')
