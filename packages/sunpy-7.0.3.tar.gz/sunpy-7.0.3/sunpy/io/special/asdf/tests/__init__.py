import pytest

pytest.importorskip("asdf")
