********
Licenses
********

This directory holds license and credit information for works sunpy is derived from or distributes.

The license file for the sunpy package itself is placed in the root directory of this repository as LICENSE.rst.
