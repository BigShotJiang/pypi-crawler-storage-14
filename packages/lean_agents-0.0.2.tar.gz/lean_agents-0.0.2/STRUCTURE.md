# Lean Agents 專案結構

```
lean-agents/
├── .gitignore                    # Git 忽略文件配置
├── pyproject.toml                # 專案配置和依賴管理（uv/pip）
├── README.md                     # 專案說明文件
├── STRUCTURE.md                  # 專案結構說明（本文件）
│
├── src/
│   └── lean_agents/              # 主要套件目錄
│       ├── __init__.py          # 套件初始化，導出主要 API
│       ├── py.typed             # Type hints 標記文件
│       ├── agent.py             # Agent 配置類別
│       ├── runner.py            # AsyncRunner 執行類別
│       │
│       └── utils/               # 工具模組
│           ├── __init__.py      # 工具模組初始化
│           └── schema.py        # 函數 schema 轉換工具
│
└── examples/                    # 使用範例
    ├── basic_example.py         # 基本使用範例（async）
    └── advanced_example.py      # 進階多工具範例（async）
```

## 架構設計理念

Lean Agents 採用 **關注點分離（Separation of Concerns）** 設計，API 風格參考 [OpenAI Agents SDK](https://github.com/openai/openai-agents-python)：

- **Agent** (agent.py): 純配置對象，負責定義 agent 的行為
- **Runner** (runner.py): 靜態執行類別，提供 `run()` 和 `run_sync()` 方法

這種設計的優點：
- ✅ 配置與執行邏輯分離
- ✅ 靜態方法無需實例化，使用更簡潔
- ✅ 同時支援 async 和 sync 兩種執行方式
- ✅ API 與 OpenAI Agents SDK 一致，降低學習成本
- ✅ 測試更容易（可單獨測試配置和執行邏輯）
- ✅ 更符合單一職責原則

## 核心模組說明

### `src/lean_agents/agent.py`
包含 `Agent` 類別，這是 agent 的配置對象：
- 存儲 instructions、model、api_key
- 管理 tools 字典和 tools_schema
- **不包含執行邏輯**

主要屬性：
- `instructions`: 系統指令
- `model`: OpenAI 模型名稱
- `api_key`: API 金鑰
- `tools`: 函數名稱到函數的映射
- `tools_schema`: OpenAI function calling schemas

### `src/lean_agents/runner.py`
包含 `Runner` 類別和 `RunResult` 類別：

**Runner 類別**：負責執行 agent
- 提供靜態方法，無需實例化
- 管理 OpenAI API 連接（async 和 sync）
- 處理函數調用和回應
- 實現對話循環邏輯

主要靜態方法：
- `async run(agent, input)`: 異步執行 agent 並返回 RunResult
- `run_sync(agent, input)`: 同步執行 agent 並返回 RunResult
- `_handle_function_call_item()`: 處理不同類型的回應項目
- `_get_client()`: 獲取 OpenAI 客戶端（async 或 sync）

**RunResult 類別**：封裝執行結果
- `final_output`: 最終文字回應
- `items`: 所有回應項目的列表

### `src/lean_agents/utils/schema.py`
提供函數 schema 轉換功能：
- `fn_to_schema()`: 將 Python 函數轉換為 OpenAI function calling schema
- `_python_type_to_json_schema()`: 將 Python 類型轉換為 JSON Schema 類型

這個模組自動解析：
- 函數簽名和參數
- 類型提示（type hints）
- Docstring 作為描述

### `src/lean_agents/__init__.py`
套件的公開 API：
```python
from .agent import Agent
from .runner import Runner, RunResult
from .utils.schema import fn_to_schema

__version__ = "0.1.0"
__all__ = ["Agent", "Runner", "RunResult", "fn_to_schema"]
```

## 使用流程

1. **定義工具函數**：使用類型提示和 docstring
2. **建立 Agent 配置**：傳入 instructions 和 tools 到 `Agent`
3. **執行 Agent**：
   - Async: `result = await Runner.run(agent, input)`
   - Sync: `result = Runner.run_sync(agent, input)`
4. **獲取結果**：從 `RunResult` 對象中取得 `final_output` 和 `items`

範例：
```python
# Async 版本
import asyncio
from lean_agents import Agent, Runner

async def main():
    agent = Agent(instructions="...", tools=[...])
    result = await Runner.run(agent, "user input")
    print(result.final_output)

asyncio.run(main())

# Sync 版本
agent = Agent(instructions="...", tools=[...])
result = Runner.run_sync(agent, "user input")
print(result.final_output)
```

## 開發指令

```bash
# 安裝依賴
uv sync

# 安裝開發依賴
uv sync --extra dev

# 執行範例
cd examples
python basic_example.py

# 格式化程式碼
black src/

# 檢查程式碼
ruff check src/

# 執行測試（需要先建立測試）
pytest
```

## 擴展建議

可以考慮添加的功能：

### 測試相關
1. **tests/** 目錄：單元測試和整合測試
2. Mock OpenAI API 的測試工具

### 文檔相關
3. **docs/** 目錄：詳細的 API 文件
4. 更多使用案例和教學

### 功能擴展
5. **不同的 Runner 實現**：
   - `StreamingRunner`: 支援串流輸出回調
   - `BatchRunner`: 批次處理多個請求
   - `RetryRunner`: 自動重試失敗的請求
6. **事件處理系統**：
   - 函數調用前後的 hooks
   - 錯誤處理回調
   - 進度追蹤回調
7. **會話管理**：
   - 歷史訊息追蹤
   - 會話狀態持久化
8. **監控和日誌**：
   - 結構化日誌
   - 性能指標收集
   - 費用追蹤

### 工具增強
9. **更好的 schema 生成**：
   - 支援更複雜的類型（Union, Optional, Literal）
   - 從 Pydantic models 生成 schema
10. **Tool decorators**：
    ```python
    @tool(name="add", description="Add numbers")
    def add(a: int, b: int) -> int:
        return a + b
    ```
