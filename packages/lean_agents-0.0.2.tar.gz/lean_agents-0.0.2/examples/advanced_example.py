"""
Advanced example showing multiple tools and complex interactions with async execution.

This demonstrates:
1. Multiple tool functions
2. Different parameter types
3. Error handling in tools
4. Async execution with Runner.run()
"""

import asyncio

from lean_agents import Agent, Runner


def add(a: int, b: int) -> int:
    """Add two numbers together."""
    return int(a) + int(b)


def multiply(a: int, b: int) -> int:
    """Multiply two numbers together."""
    return int(a) * int(b)


def divide(a: float, b: float) -> float:
    """Divide a by b. Returns error message if b is zero."""
    if b == 0:
        return "Error: Division by zero"
    return a / b


def get_weather(city: str) -> str:
    """Get the weather for a city (mock function)."""
    # This is a mock function - in real use you'd call an API
    weather_data = {
        "taipei": "Sunny, 25°C",
        "tokyo": "Rainy, 18°C",
        "london": "Cloudy, 15°C",
    }
    return weather_data.get(city.lower(), f"Weather data not available for {city}")


async def main():
    # Create an agent with multiple tools
    agent = Agent(
        instructions="""You are a helpful assistant with access to math and weather tools.
        Use the appropriate tool based on the user's question.
        For math problems, show your work step by step.""",
        tools=[add, multiply, divide, get_weather],
        model="gpt-4o-mini",
    )

    # Example 1: Math calculation
    print("\n=== Example 1: Complex Math ===")
    result1 = await Runner.run(agent, "Calculate (123 + 456) * 2 and then divide by 3")
    print(f"\nAnswer: {result1.final_output}\n")

    # Example 2: Weather query
    print("\n=== Example 2: Weather Query ===")
    result2 = await Runner.run(agent, "What's the weather like in Taipei?")
    print(f"\nAnswer: {result2.final_output}\n")

    # Example 3: Mixed operations
    print("\n=== Example 3: Mixed Operations ===")
    result3 = await Runner.run(
        agent,
        "If it costs 100 dollars per person and we have 15 people, what's the total? "
        "Also, what's the weather in Tokyo?",
    )
    print(f"\nAnswer: {result3.final_output}\n")


if __name__ == "__main__":
    asyncio.run(main())
