"""
Synchronous example of using Agent with Runner.run_sync().

This demonstrates how to use Agent in synchronous code without async/await.
"""

from lean_agents import Agent, Runner


def add(a: int, b: int) -> int:
    """Add two numbers together and return the result."""
    return int(a) + int(b)


def multiply(a: int, b: int) -> int:
    """Multiply two numbers together."""
    return int(a) * int(b)


def main():
    # Create an agent with tools
    agent = Agent(
        instructions="You are a helpful math assistant. Use the provided tools to solve problems.",
        tools=[add, multiply],
        model="gpt-4o-mini",
    )

    # Run synchronously (no async/await needed)
    result = Runner.run_sync(agent, "What is (12 + 8) * 5?")

    print("\n" + "=" * 50)
    print("Final Answer:", result.final_output)
    print("=" * 50)


if __name__ == "__main__":
    main()
