"""
Basic example of using Agent with Runner and a simple add function.

This demonstrates how to:
1. Define a tool function with type hints and docstring
2. Create an Agent with instructions and tools
3. Run the agent asynchronously with Runner.run()
"""

import asyncio

from lean_agents import Agent, Runner


def add(a: int, b: int) -> int:
    """Add two numbers together and return the result."""
    return int(a) + int(b)


async def main():
    # Create an agent with the add tool
    agent = Agent(
        instructions="You are a helpful assistant that can handle adding numbers with tool `add`.",
        tools=[add],
        model="gpt-4o-mini",  # or "gpt-4o", "o1-mini", etc.
    )

    # Run the agent (static method, no need to instantiate Runner)
    result = await Runner.run(agent, "123122+3532434 等於多少? 請用 add 工具")

    print("\n" + "=" * 50)
    print("Final Answer:", result.final_output)
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
