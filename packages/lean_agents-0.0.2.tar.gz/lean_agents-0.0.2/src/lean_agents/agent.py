from typing import Any, Callable

from .utils.schema import fn_to_schema


class Agent:
    """
    A lightweight AI agent configuration object.

    Agent holds the configuration for an AI agent including instructions,
    model selection, and available tools. It does not execute requests directly;
    use AsyncRunner to run the agent.

    Attributes:
        instructions: System instructions for the agent
        model: The OpenAI model to use
        api_key: OpenAI API key (optional, uses OPENAI_API_KEY env var if not provided)
        tools: Dictionary mapping function names to callable functions
        tools_schema: List of function schemas for OpenAI API

    Example:
        >>> def add(a: int, b: int) -> int:
        ...     '''Add two numbers together.'''
        ...     return a + b
        >>> agent = Agent(
        ...     instructions="You are a helpful assistant.",
        ...     tools=[add],
        ...     model="gpt-4o-mini"
        ... )
        >>> runner = AsyncRunner()
        >>> result = await runner.run(agent, "What is 2 + 3?")
    """

    instructions: str = ""
    model: str = "gpt-4o-mini"
    api_key: str | None = None
    tools: dict[str, Callable] = {}
    tools_schema: list[dict[str, Any]] = []

    def __init__(
        self,
        instructions: str,
        tools: list[Callable],
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
    ):
        """
        Initialize an Agent configuration.

        Args:
            instructions: System instructions that guide the agent's behavior
            tools: List of callable functions that the agent can use
            model: OpenAI model name (default: "gpt-4o-mini")
            api_key: OpenAI API key (if not provided, uses OPENAI_API_KEY env var)
        """
        self.instructions = instructions
        self.model = model
        self.api_key = api_key
        self.tools = {fn.__name__: fn for fn in tools}
        self.tools_schema = [fn_to_schema(fn) for fn in tools]
