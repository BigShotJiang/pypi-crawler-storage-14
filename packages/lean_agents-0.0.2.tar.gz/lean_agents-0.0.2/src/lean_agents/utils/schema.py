import inspect
from typing import Any, Callable, get_type_hints


def fn_to_schema(fn: Callable) -> dict[str, Any]:
    """
    Convert a Python function to OpenAI function calling schema.

    Args:
        fn: A Python function with type hints and docstring

    Returns:
        A dictionary conforming to OpenAI function calling schema

    Example:
        >>> def add(a: int, b: int) -> int:
        ...     '''Add two numbers together.'''
        ...     return a + b
        >>> schema = fn_to_schema(add)
        >>> schema['name']
        'add'
    """
    sig = inspect.signature(fn)
    type_hints = get_type_hints(fn)

    # Extract function description from docstring
    description = inspect.getdoc(fn) or fn.__name__

    # Build parameters schema
    properties = {}
    required = []

    for param_name, param in sig.parameters.items():
        if param_name == "self":
            continue

        param_type = type_hints.get(param_name, Any)
        param_schema = _python_type_to_json_schema(param_type)

        # Extract parameter description from docstring if available
        properties[param_name] = param_schema

        # Mark as required if no default value
        if param.default == inspect.Parameter.empty:
            required.append(param_name)

    schema = {
        "type": "function",
        "name": fn.__name__,
        "description": description,
        "parameters": {
            "type": "object",
            "properties": properties,
            "required": required,
        },
    }

    return schema


def _python_type_to_json_schema(python_type: type) -> dict[str, Any]:
    """Convert Python type hints to JSON Schema types."""
    type_mapping = {
        int: {"type": "integer"},
        float: {"type": "number"},
        str: {"type": "string"},
        bool: {"type": "boolean"},
        list: {"type": "array"},
        dict: {"type": "object"},
    }

    # Handle basic types
    if python_type in type_mapping:
        return type_mapping[python_type]

    # Handle typing.List, typing.Dict, etc.
    origin = getattr(python_type, "__origin__", None)
    if origin is list:
        return {"type": "array"}
    if origin is dict:
        return {"type": "object"}

    # Default fallback
    return {"type": "string"}
