import json
from typing import Any

from openai import AsyncOpenAI, OpenAI

from .agent import Agent


class RunResult:
    """
    Result object returned by Runner.run() and Runner.run_sync().

    Attributes:
        final_output: The final text response from the agent
        items: List of all response items (messages, function calls, reasoning, etc.)
    """

    def __init__(self, final_output: str, items: list):
        self.final_output = final_output
        self.items = items


class Runner:
    """
    Runner for executing Agent interactions.

    Provides static methods for both async and sync execution:
    - Runner.run(agent, input) - async version
    - Runner.run_sync(agent, input) - sync version

    Example:
        >>> agent = Agent(instructions="...", tools=[add])
        >>> result = await Runner.run(agent, "What is 2 + 3?")
        >>> print(result.final_output)
    """

    @staticmethod
    def _get_client(agent: Agent, is_async: bool = True):
        """Get OpenAI client (async or sync)."""
        if is_async:
            return AsyncOpenAI(api_key=agent.api_key)
        return OpenAI(api_key=agent.api_key)

    @staticmethod
    def _handle_function_call_item(
        item, agent: Agent
    ) -> list[dict[str, Any]]:
        """
        Handle different types of response items from OpenAI.

        Args:
            item: Response item from OpenAI stream
            agent: The Agent configuration with tools

        Returns:
            List of function call outputs to send back to the API
        """
        if item.type == "reasoning":
            print("[reasoning] " + "".join(item.summary))
            return []

        if item.type == "message":
            txt = "".join(p.text for p in item.content if p.type == "output_text")
            print("[message] " + txt)
            return []

        if item.type == "function_call":
            args = json.loads(item.arguments or "{}")
            print("[function_call] " + f"{item.name}({json.dumps(args)})")

            # Execute the function
            result = (
                agent.tools[item.name](**args) if args else agent.tools[item.name]()
            )
            print("[function_output] " + json.dumps(result))

            return [
                {
                    "type": "function_call_output",
                    "call_id": item.call_id,
                    "output": json.dumps(result),
                }
            ]

        return []

    @staticmethod
    async def run(agent: Agent, input: str) -> RunResult:
        """
        Run the agent asynchronously.

        Args:
            agent: The Agent configuration to run
            input: The user's input text

        Returns:
            RunResult object with final_output and items

        Example:
            >>> agent = Agent(instructions="...", tools=[add])
            >>> result = await Runner.run(agent, "What is 5 + 7?")
            >>> print(result.final_output)
            '12'
        """
        print("Input:", input)

        client = Runner._get_client(agent, is_async=True)
        turn_input = [{"role": "user", "content": input}]

        prev_id = None
        items = []

        while turn_input:
            stream = await client.responses.create(
                model=agent.model,
                instructions=agent.instructions,
                tools=agent.tools_schema,
                input=turn_input,
                previous_response_id=prev_id,
                stream=True,
            )
            turn_input = []  # collect next-turn inputs

            async for event in stream:
                if event.type == "response.output_item.done":
                    turn_input += Runner._handle_function_call_item(event.item, agent)
                    items.append(event.item)

                if event.type == "response.completed":
                    prev_id = event.response.id

        final_output = items[-1].content[0].text
        return RunResult(final_output=final_output, items=items)

    @staticmethod
    def run_sync(agent: Agent, input: str) -> RunResult:
        """
        Run the agent synchronously.

        Args:
            agent: The Agent configuration to run
            input: The user's input text

        Returns:
            RunResult object with final_output and items

        Example:
            >>> agent = Agent(instructions="...", tools=[add])
            >>> result = Runner.run_sync(agent, "What is 5 + 7?")
            >>> print(result.final_output)
            '12'
        """
        print("Input:", input)

        client = Runner._get_client(agent, is_async=False)
        turn_input = [{"role": "user", "content": input}]

        prev_id = None
        items = []

        while turn_input:
            stream = client.responses.create(
                model=agent.model,
                instructions=agent.instructions,
                tools=agent.tools_schema,
                input=turn_input,
                previous_response_id=prev_id,
                stream=True,
            )
            turn_input = []  # collect next-turn inputs

            for event in stream:
                if event.type == "response.output_item.done":
                    turn_input += Runner._handle_function_call_item(event.item, agent)
                    items.append(event.item)

                if event.type == "response.completed":
                    prev_id = event.response.id

        final_output = items[-1].content[0].text
        return RunResult(final_output=final_output, items=items)
