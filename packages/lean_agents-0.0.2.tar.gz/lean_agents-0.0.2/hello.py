def main():
    print("Hello from lean-agents!")


if __name__ == "__main__":
    main()
