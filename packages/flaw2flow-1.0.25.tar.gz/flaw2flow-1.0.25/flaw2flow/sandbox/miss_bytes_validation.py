def foo(b: bytes) -> bytes:
    """MUST FAIL — missing validation."""
    return b
