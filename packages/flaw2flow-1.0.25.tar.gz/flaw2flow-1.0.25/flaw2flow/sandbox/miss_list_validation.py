def foo(lst: list[str]) -> list[str]:
    """MUST FAIL — missing validator."""
    return lst
