# https://github.com/trezor/python-mnemonic/tree/v0.21
from .mnemonic import Mnemonic

__all__ = ["Mnemonic"]
