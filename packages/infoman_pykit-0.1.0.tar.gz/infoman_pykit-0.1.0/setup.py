import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

base_requirements = [
    'uvloop~=0.21.0',
    'loguru==0.6.0',
    'pyyaml~=6.0.2',
    'aiohttp>=3.12.13',
    'aiofiles~=24.1.0',
    'httpx==0.25.2',
    'python-dotenv==0.21.1',
]

extras_require = {
    'service': [
        'pytz==2025.2',
        'psutil==7.0.0',
        'pydantic==2.12.5',
        'PyJWT==2.10.1',

        'redis==7.1.0',
        'tortoise-orm==0.19.0',
        'aiomysql==0.2.0',

        'fastapi==0.122.0',
        'uvicorn[standard]==0.38.0',
        'gunicorn==23.0.0',

        'cryptography==45.0.4',
        'marshmallow==3.13.0',
        'qdrant-client==1.14.3',
        'nats-py==2.10.0',
        'fastapi-cache2==0.2.2'
    ],
    'llm': [
        'litellm==1.75.0'
    ]
}

extras_require['all'] = [
    dep for deps in extras_require.values() for dep in deps
]

setuptools.setup(
    name='infoman',
    version='1.0.0',
    description='A Python toolkit for advanced data processing and API interactions',
    author='Infoman',
    author_email='louishwh@gmail.com',
    url='',
    packages=setuptools.find_packages(),
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires='>=3.11',
    install_requires=base_requirements,
    extras_require=extras_require,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    project_urls={
        "Bug Tracker": "https://github.com/infoman/infoman-pykit/issues",
        "Documentation": "https://doc.infoman.ai/",
        "Source Code": "https://github.com/infoman-pykit",
    },
    keywords='api, toolkit'
)