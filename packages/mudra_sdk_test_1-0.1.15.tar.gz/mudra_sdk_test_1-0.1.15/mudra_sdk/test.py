import mudra_sdk.models.mudra_device as mudra_device

def function_1():
    print("Function 1")
    x = mudra_device.MudraDevice(1, 2)
    print(x.sum_parameters())
    return 1

function_1()