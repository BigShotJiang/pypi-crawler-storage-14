"""Utilies for SBART application"""

from .concurrent_tools.open_buffers import open_buffer

try:
    from .cython_codes.matmul import second_term

    CYTHON_UNAVAILABLE = False
except ImportError:
    from SBART.utils.create_logger import sbart_logger as logger

    logger.critical(
        "s-BART Cython interface is not found, please make sure that the installation went smoothly (no matmul)"
    )
    CYTHON_UNAVAILABLE = True

from .find_nearby_wavelengths import find_close_lambdas
from .parameter_validators import validator
from .paths_tools.build_filename import build_filename
from .roll_arrays import roll_array
from .RV_utilities import RVerror, build_blocks, find_wavelength_limits
from .units import kilometer_second, meter_second
