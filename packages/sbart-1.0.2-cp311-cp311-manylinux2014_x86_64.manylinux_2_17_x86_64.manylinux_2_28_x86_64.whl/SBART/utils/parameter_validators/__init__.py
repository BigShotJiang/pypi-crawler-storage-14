from .class_decorator import validator
