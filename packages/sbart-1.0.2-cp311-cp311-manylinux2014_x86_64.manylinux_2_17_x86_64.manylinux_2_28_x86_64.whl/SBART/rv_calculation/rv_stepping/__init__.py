"""Classical template matching algorithm
"""

from .RV_step import RV_step
