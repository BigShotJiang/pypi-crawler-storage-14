"""Test suite for the dlsite_async package."""
