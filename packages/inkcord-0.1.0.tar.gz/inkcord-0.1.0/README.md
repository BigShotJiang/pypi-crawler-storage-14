# inkcord
![CodeFactor Grade](https://img.shields.io/codefactor/grade/github/sunset-hue/inkcord?style=for-the-badge)
![Static Badge](https://img.shields.io/badge/Documentation-v0.1.0-orange?style=for-the-badge)

A discord API wrapper made from standard libraries, not requiring any dependencies (except websocket, since it's really complicated to implement)

## Why use this wrapper?
uhh it's cool and also it doesn't really require a lot of package downloading and downloads a lot faster
The structure of this library is a bit of discord.py inspiredness and the rest is my dumb design

## Usage
You can check [the documentation](https://inkcord-docs.github.io) for documentation, and how to make your first bot with it.
