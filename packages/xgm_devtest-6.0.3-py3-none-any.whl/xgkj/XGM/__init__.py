
from .mds24_driver import fpgadev as mds24