# yllm-chat

A simple CLI tool for chatting with OpenAI-compatible APIs.

## Installation

```bash
pip install yllm-chat
```

## Usage

### Command Line

```bash
# Direct message
yllm "Explain Python decorators"

# With custom system prompt
yllm -s "You are a Python expert" "What are generators?"

# Pipe input
echo "Summarize this" | yllm

# Disable streaming
yllm --no-stream "Hello"
```

### As a Library

```python
from yllm import chat_with_openai

# Streaming (prints to stdout)
chat_with_openai("Hello, world!")

# Non-streaming (returns string)
response = chat_with_openai("Hello", stream=False)
print(response)
```

## Configuration

Set these environment variables (or use a `.env` file):

| Variable          | Required | Description                                      |
| ----------------- | -------- | ------------------------------------------------ |
| `OPENAI_API_KEY`  | Yes      | Your API key                                     |
| `OPENAI_BASE_URL` | No       | Custom API endpoint (for OpenAI-compatible APIs) |
| `OPENAI_MODEL`    | No       | Model to use (default: `gpt-4o-mini`)            |

## Development

```bash
# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check .
```

## License

MIT
