"""Utility functions for yllm."""

from yllm.utils.chat import chat_with_openai

__all__ = ["chat_with_openai"]
