"""Chat utilities for OpenAI-compatible APIs."""

import os

from openai import OpenAI


def chat_with_openai(
    user_message: str,
    system_message: str = "You are a helpful assistant.",
    stream: bool = True,
) -> str | None:
    """
    Send a message to an OpenAI-compatible API and get a response.

    Args:
        user_message: The user's message to send.
        system_message: The system prompt. Defaults to a helpful assistant.
        stream: Whether to stream the response. Defaults to True.

    Returns:
        The complete response text if not streaming, None if streaming.

    Environment Variables:
        OPENAI_API_KEY: Your API key.
        OPENAI_BASE_URL: Optional custom base URL for the API.
        OPENAI_MODEL: The model to use (defaults to 'gpt-4o-mini').
    """
    client = OpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        base_url=os.getenv("OPENAI_BASE_URL"),
    )

    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_message},
        ],
        stream=stream,
    )

    if stream:
        for chunk in response:
            if chunk.choices[0].delta.content is not None:
                print(chunk.choices[0].delta.content, end="", flush=True)
        print()  # Newline after streaming
        return None
    else:
        return response.choices[0].message.content
