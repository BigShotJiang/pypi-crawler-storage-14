"""yllm-chat - A simple CLI tool for chatting with OpenAI-compatible APIs."""

__version__ = "0.1.0"

from yllm.utils.chat import chat_with_openai

__all__ = ["chat_with_openai"]
