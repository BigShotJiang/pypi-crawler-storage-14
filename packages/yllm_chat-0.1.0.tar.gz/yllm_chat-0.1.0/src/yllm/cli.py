"""Command-line interface for yllm."""

import argparse
import sys

from dotenv import load_dotenv

from yllm.utils.chat import chat_with_openai


def main() -> int:
    """Main entry point for the yllm CLI."""
    load_dotenv()

    parser = argparse.ArgumentParser(
        prog="yllm",
        description="Chat with OpenAI-compatible APIs from the command line.",
    )
    parser.add_argument(
        "message",
        nargs="?",
        help="The message to send. If not provided, reads from stdin.",
    )
    parser.add_argument(
        "-s",
        "--system",
        default="You are a helpful assistant.",
        help="System message/prompt.",
    )
    parser.add_argument(
        "--no-stream",
        action="store_true",
        help="Disable streaming output.",
    )

    args = parser.parse_args()

    # Get message from argument or stdin
    if args.message:
        message = args.message
    elif not sys.stdin.isatty():
        message = sys.stdin.read().strip()
    else:
        parser.print_help()
        return 1

    if not message:
        print("Error: No message provided.", file=sys.stderr)
        return 1

    result = chat_with_openai(
        user_message=message,
        system_message=args.system,
        stream=not args.no_stream,
    )

    if result:
        print(result)

    return 0


if __name__ == "__main__":
    sys.exit(main())
