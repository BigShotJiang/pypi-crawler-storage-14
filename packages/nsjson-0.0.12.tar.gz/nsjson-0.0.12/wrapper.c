#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <structmember.h>
#include "nsjson.h"
#include "numpa.h"

static PyObject *NSJSONError;

typedef struct {
    PyObject *true_obj;
    PyObject *false_obj;
    PyObject *null_obj;
    PyObject *empty_dict;
    PyObject *empty_list;
} ObjectPool;

typedef struct {
    Py_ssize_t pos;
    PyObject *current_key;
    PyObject *current_value;
} IteratorState;

static inline size_t num_utf8_chars(const char *src, size_t len) {
    size_t count = 0;
    size_t i = 0;
    
    while (i < len) {
        unsigned char c = (unsigned char)src[i];
        
        if (c < 0x80) {
            count++;
            i++;
        } else if ((c & 0xE0) == 0xC0) {
            if (i + 1 >= len || (src[i+1] & 0xC0) != 0x80) {
                return len;
            }
            count++;
            i += 2;
        } else if ((c & 0xF0) == 0xE0) {
            if (i + 2 >= len || (src[i+1] & 0xC0) != 0x80 || (src[i+2] & 0xC0) != 0x80) {
                return len;
            }
            count++;
            i += 3;
        } else if ((c & 0xF8) == 0xF0) {
            if (i + 3 >= len || (src[i+1] & 0xC0) != 0x80 || (src[i+2] & 0xC0) != 0x80 || (src[i+3] & 0xC0) != 0x80) {
                return len;
            }
            count++;
            i += 4;
        } else {
            return len;
        }
    }
    return count;
}

static inline PyObject *unicode_from_str(const char *src, size_t len) {
#ifndef PYPY_VERSION
    size_t num_chars = num_utf8_chars(src, len);

    if (num_chars == len) {
        PyObject *uni = PyUnicode_New(len, 127);
        if (!uni) return NULL;
        PyASCIIObject *uni_ascii = (PyASCIIObject *)uni;
        memcpy(uni_ascii + 1, src, len);
        return uni;
    }
#endif

    return PyUnicode_DecodeUTF8(src, len, "strict");
}

static JSOBJ new_string_callback(void *prv, const char *str, size_t len, int is_raw) {
    if (is_raw) {
        const uint32_t *codes = (const uint32_t*)str;
        PyObject *unicode = PyUnicode_New(len, 1114111);
        if (!unicode) return NULL;
        
        for (size_t i = 0; i < len; i++) {
            Py_UCS4 ch = codes[i];
            PyUnicode_WriteChar(unicode, i, ch);
        }
        return unicode;
    } else {
        return unicode_from_str(str, len);
    }
}

static void object_add_key_callback(void *prv, JSOBJ obj, JSOBJ name, JSOBJ value) {
    PyDict_SetItem(obj, name, value);
}

static void array_add_item_callback(void *prv, JSOBJ obj, JSOBJ value) {
    PyList_Append(obj, value);
}

static JSOBJ new_true_callback(void *prv) {
    Py_RETURN_TRUE;
}

static JSOBJ new_false_callback(void *prv) {
    Py_RETURN_FALSE;
}

static JSOBJ new_null_callback(void *prv) {
    Py_RETURN_NONE;
}

static JSOBJ new_nan_callback(void *prv) {
    return PyFloat_FromDouble(Py_NAN);
}

static JSOBJ new_pos_inf_callback(void *prv) {
    return PyFloat_FromDouble(Py_HUGE_VAL);
}

static JSOBJ new_neg_inf_callback(void *prv) {
    return PyFloat_FromDouble(-Py_HUGE_VAL);
}

static JSOBJ new_object_callback(void *prv) {
    return PyDict_New();
}

static JSOBJ new_array_callback(void *prv) {
    return PyList_New(0);
}

static JSOBJ new_int_callback(void *prv, JSINT32 value) {
    return PyLong_FromLong(value);
}

static JSOBJ new_long_callback(void *prv, JSINT64 value) {
    return PyLong_FromLongLong(value);
}

static JSOBJ new_unsigned_long_callback(void *prv, JSUINT64 value) {
    return PyLong_FromUnsignedLongLong(value);
}

static JSOBJ new_integer_from_string_callback(void *prv, char *value, size_t length) {
    PyObject *str = PyUnicode_DecodeUTF8(value, length, "strict");
    if (!str) return NULL;
    PyObject *result = PyLong_FromUnicodeObject(str, 10);
    Py_DECREF(str);
    return result;
}

static JSOBJ new_double_callback(void *prv, double value) {
    return PyFloat_FromDouble(value);
}

static void release_object_callback(void *prv, JSOBJ obj) {
    if (obj != Py_True && obj != Py_False && obj != Py_None) {
        Py_DECREF(obj);
    }
}

static JSOBJ get_cached_object_callback(void *prv, const char *key, size_t key_len) {
    ObjectPool *pool = (ObjectPool*)prv;
    if (!pool) return NULL;
    
    if (key_len == 4 && memcmp(key, "true", 4) == 0 && pool->true_obj) {
        Py_INCREF(pool->true_obj);
        return pool->true_obj;
    } else if (key_len == 5 && memcmp(key, "false", 5) == 0 && pool->false_obj) {
        Py_INCREF(pool->false_obj);
        return pool->false_obj;
    } else if (key_len == 4 && memcmp(key, "null", 4) == 0 && pool->null_obj) {
        Py_INCREF(pool->null_obj);
        return pool->null_obj;
    } else if (key_len == 2 && memcmp(key, "[]", 2) == 0 && pool->empty_list) {
        Py_INCREF(pool->empty_list);
        return pool->empty_list;
    } else if (key_len == 2 && memcmp(key, "{}", 2) == 0 && pool->empty_dict) {
        Py_INCREF(pool->empty_dict);
        return pool->empty_dict;
    }
    
    return NULL;
}

static void cache_object_callback(void *prv, JSOBJ obj, const char *key, size_t key_len) {
}

static PyTypeObject* type_for_conversion(PyObject *obj) {
    if (PyUnicode_Check(obj)) {
        return &PyUnicode_Type;
    } else if (PyLong_Check(obj)) {
        return &PyLong_Type;
    } else if (PyFloat_Check(obj)) {
        return &PyFloat_Type;
    } else if (PyDict_Check(obj)) {
        return &PyDict_Type;
    } else if (PyList_Check(obj)) {
        return &PyList_Type;
    } else if (PyBool_Check(obj)) {
        return &PyBool_Type;
    } else if (obj == Py_None) {
        return Py_None->ob_type;
    }
    return NULL;
}

static void begin_type_context_callback(JSOBJ obj, JSONTypeContext *tc, JSONObjectEncoder *enc) {
    tc->prv = NULL;
    tc->encoder_prv = NULL;
    
    PyTypeObject *ob_type = type_for_conversion(obj);
    
    if (ob_type == &PyUnicode_Type) {
        tc->type = JT_UTF8;
    } else if (ob_type == &PyLong_Type) {
        int overflow = 0;
        PyLong_AsLongAndOverflow(obj, &overflow);
        if (overflow == 0) {
            tc->type = JT_LONG;
        } else {
            if (PyLong_AsUnsignedLongLong(obj) != (unsigned long long)-1 || !PyErr_Occurred()) {
                tc->type = JT_ULONG;
            } else {
                PyErr_Clear();
                tc->type = JT_DOUBLE;
            }
        }
    } else if (ob_type == &PyFloat_Type) {
        tc->type = JT_DOUBLE;
    } else if (ob_type == &PyDict_Type) {
        tc->type = JT_OBJECT;
        
        IteratorState *state = enc->malloc(sizeof(IteratorState));
        if (state) {
            state->pos = 0;
            state->current_key = NULL;
            state->current_value = NULL;
            tc->prv = state;
        }
    } else if (ob_type == &PyList_Type) {
        tc->type = JT_ARRAY;
        
        IteratorState *state = enc->malloc(sizeof(IteratorState));
        if (state) {
            state->pos = 0;
            state->current_key = NULL;
            state->current_value = NULL;
            tc->prv = state;
        }
    } else if (ob_type == &PyBool_Type) {
        if (obj == Py_True) {
            tc->type = JT_TRUE;
        } else {
            tc->type = JT_FALSE;
        }
    } else if (obj == Py_None) {
        tc->type = JT_NULL;
    } else {
        tc->type = JT_INVALID;
    }
}

static void end_type_context_callback(JSOBJ obj, JSONTypeContext *tc) {
    if (tc->encoder_prv) {
        PyObject *bytes = (PyObject*)tc->encoder_prv;
        Py_DECREF(bytes);
        tc->encoder_prv = NULL;
    }
    
    if (tc->prv) {
        IteratorState *state = (IteratorState*)tc->prv;
        Py_XDECREF(state->current_key);
        Py_XDECREF(state->current_value);
        free(tc->prv);
        tc->prv = NULL;
    }
}

static const char* get_string_value_callback(JSOBJ obj, JSONTypeContext *tc, size_t *out_len) {
    PyObject *bytes = PyUnicode_AsUTF8String(obj);
    if (!bytes) return NULL;
    
    char *result = PyBytes_AsString(bytes);
    *out_len = PyBytes_Size(bytes);
    
    tc->encoder_prv = bytes;
    
    return result;
}

static JSINT64 get_long_value_callback(JSOBJ obj, JSONTypeContext *tc) {
    return PyLong_AsLongLong(obj);
}

static JSUINT64 get_unsigned_long_value_callback(JSOBJ obj, JSONTypeContext *tc) {
    return PyLong_AsUnsignedLongLong(obj);
}

static double get_double_value_callback(JSOBJ obj, JSONTypeContext *tc) {
    return PyFloat_AsDouble(obj);
}

static int iter_next_callback(JSOBJ obj, JSONTypeContext *tc) {
    IteratorState *state = (IteratorState*)tc->prv;
    if (!state) return 0;
    
    Py_XDECREF(state->current_key);
    Py_XDECREF(state->current_value);
    state->current_key = NULL;
    state->current_value = NULL;

    if (tc->type == JT_OBJECT && PyDict_Check(obj)) {
        PyObject *key, *value;
        if (PyDict_Next(obj, &state->pos, &key, &value)) {
            Py_INCREF(key);
            state->current_key = key;
            Py_INCREF(value);
            state->current_value = value;
            return 1;
        }
    } else if (tc->type == JT_ARRAY && PyList_Check(obj)) {
        Py_ssize_t size = PyList_GET_SIZE(obj);
        if (state->pos < size) {
            PyObject *value = PyList_GET_ITEM(obj, state->pos);
            Py_INCREF(value);
            state->current_value = value;
            state->pos++;
            return 1;
        }
    }
    
    return 0;
}

static void iter_end_callback(JSOBJ obj, JSONTypeContext *tc) {
}

static JSOBJ iter_get_value_callback(JSOBJ obj, JSONTypeContext *tc) {
    IteratorState *state = (IteratorState*)tc->prv;
    if (!state || !state->current_value) return NULL;
    
    Py_INCREF(state->current_value);
    return state->current_value;
}

static char* iter_get_name_callback(JSOBJ obj, JSONTypeContext *tc, size_t *out_len) {
    IteratorState *state = (IteratorState*)tc->prv;
    *out_len = 0;
    
    if (!state || !state->current_key) return "";
    
    if (tc->encoder_prv) {
        Py_DECREF((PyObject*)tc->encoder_prv);
        tc->encoder_prv = NULL;
    }
    
    PyObject *bytes = PyUnicode_AsUTF8String(state->current_key);
    if (!bytes) {
        return "";
    }
    
    char *result = PyBytes_AsString(bytes);
    *out_len = PyBytes_Size(bytes);
    
    tc->encoder_prv = bytes;
    
    return result;
}

static void release_object_callback_encoder(JSOBJ obj) {
}

static PyObject* nsjson_loads(PyObject* self, PyObject* args, PyObject* kwargs) {
    const char* json_str;
    Py_ssize_t length;
    int strict = 0;
    int allow_nan_inf = 0;
    int validate_utf8 = 1;
    int object_pooling = 1;
    
    static char* kwlist[] = {"s", "strict", "allow_nan_inf", "validate_utf8", "object_pooling", NULL};
    
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s#|pppp", kwlist,
                                    &json_str, &length, &strict, &allow_nan_inf, 
                                    &validate_utf8, &object_pooling)) {
        return NULL;
    }
    
    ObjectPool pool = {0};
    if (object_pooling) {
        pool.true_obj = Py_True;
        pool.false_obj = Py_False; 
        pool.null_obj = Py_None;
        pool.empty_dict = PyDict_New();
        pool.empty_list = PyList_New(0);
    }
    
    JSONObjectDecoder decoder = {
        .newString = new_string_callback,
        .objectAddKey = object_add_key_callback,
        .arrayAddItem = array_add_item_callback,
        .newTrue = new_true_callback,
        .newFalse = new_false_callback,
        .newNull = new_null_callback,
        .newNaN = new_nan_callback,
        .newPosInf = new_pos_inf_callback,
        .newNegInf = new_neg_inf_callback,
        .newObject = new_object_callback,
        .newArray = new_array_callback,
        .newInt = new_int_callback,
        .newLong = new_long_callback,
        .newUnsignedLong = new_unsigned_long_callback,
        .newIntegerFromString = new_integer_from_string_callback,
        .newDouble = new_double_callback,
        .releaseObject = release_object_callback,
        .getCachedObject = get_cached_object_callback,
        .cacheObject = cache_object_callback,
        .malloc = malloc,
        .free = free,
        .realloc = realloc,
        .prv = &pool,
        .errorStr = NULL,
        .errorOffset = NULL,
        .flags = 0
    };
    
    if (strict) decoder.flags |= JSON_STRICT_MODE;
    if (allow_nan_inf) decoder.flags |= JSON_ALLOW_NAN_INF;
    if (validate_utf8) decoder.flags |= JSON_VALIDATE_UTF8;
    if (object_pooling) decoder.flags |= JSON_OBJECT_POOLING;
    
    JSOBJ result = JSON_DecodeObject(&decoder, json_str, length);
    
    if (object_pooling) {
        Py_DECREF(pool.empty_dict);
        Py_DECREF(pool.empty_list);
    }
    
    if (decoder.errorStr) {
        PyErr_SetString(NSJSONError, decoder.errorStr);
        return NULL;
    }
    
    return result;
}

static PyObject* nsjson_dumps(PyObject* self, PyObject* args, PyObject* kwargs) {
    PyObject* obj;
    int indent = 0;
    int ensure_ascii = 1;
    int sort_keys = 0;
    int escape_forward_slashes = 0;
    int allow_nan = 1;
    
    static char* kwlist[] = {"obj", "indent", "ensure_ascii", "sort_keys", 
                           "escape_forward_slashes", "allow_nan", NULL};
    
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O|iiiii", kwlist, 
                                    &obj, &indent, &ensure_ascii, &sort_keys, 
                                    &escape_forward_slashes, &allow_nan)) {
        return NULL;
    }
    
    JSONObjectEncoder encoder = {
        .beginTypeContext = begin_type_context_callback,
        .endTypeContext = end_type_context_callback,
        .getStringValue = get_string_value_callback,
        .getLongValue = get_long_value_callback,
        .getUnsignedLongValue = get_unsigned_long_value_callback,
        .getDoubleValue = get_double_value_callback,
        .iterNext = iter_next_callback,
        .iterEnd = iter_end_callback,
        .iterGetValue = iter_get_value_callback,
        .iterGetName = iter_get_name_callback,
        .releaseObject = release_object_callback_encoder,
        .malloc = malloc,
        .realloc = realloc,
        .free = free,
        .recursionMax = 512,
        .forceASCII = ensure_ascii,
        .encodeHTMLChars = 0,
        .escapeForwardSlashes = escape_forward_slashes,
        .sortKeys = sort_keys,
        .indent = indent,
        .allowNan = allow_nan,
        .rejectBytes = 0,
        .itemSeparatorLength = 1,
        .itemSeparatorChars = ",",
        .keySeparatorLength = 1,
        .keySeparatorChars = ":",
        .prv = NULL,
        .start = NULL,
        .offset = NULL,
        .end = NULL,
        .heap = 0,
        .level = 0,
        .errorMsg = NULL,
        .errorObj = NULL
    };
    
    size_t output_length;
    char* result = JSON_EncodeObject(obj, &encoder, NULL, 0, &output_length);
    
    if (encoder.errorMsg) {
        PyErr_SetString(NSJSONError, encoder.errorMsg);
        if (encoder.heap && result) {
            free(result);
        }
        return NULL;
    }
    
    PyObject* py_result = PyUnicode_DecodeUTF8(result, output_length, "strict");
    
    if (encoder.heap && result) {
        free(result);
    }
    
    return py_result;
}

static PyMethodDef nsjson_methods[] = {
    {"loads", (PyCFunction)nsjson_loads, METH_VARARGS | METH_KEYWORDS, "Parse JSON string"},
    {"dumps", (PyCFunction)nsjson_dumps, METH_VARARGS | METH_KEYWORDS, "Serialize to JSON"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef nsjson_module = {
    PyModuleDef_HEAD_INIT,
    "nsjson",
    "Ultra-fast JSON library",
    -1,
    nsjson_methods,
    NULL, NULL, NULL, NULL
};

PyMODINIT_FUNC PyInit_nsjson(void) {
    PyObject* module = PyModule_Create(&nsjson_module);
    if (module == NULL) {
        return NULL;
    }
    
    NSJSONError = PyErr_NewException("nsjson.Error", NULL, NULL);
    Py_INCREF(NSJSONError);
    PyModule_AddObject(module, "Error", NSJSONError);
    
    PyModule_AddIntConstant(module, "STRICT_MODE", JSON_STRICT_MODE);
    PyModule_AddIntConstant(module, "ALLOW_NAN_INF", JSON_ALLOW_NAN_INF);
    PyModule_AddIntConstant(module, "VALIDATE_UTF8", JSON_VALIDATE_UTF8);
    PyModule_AddIntConstant(module, "OBJECT_POOLING", JSON_OBJECT_POOLING);
    
    PyModule_AddStringConstant(module, "__version__", "1.0.0");
    
    return module;
}