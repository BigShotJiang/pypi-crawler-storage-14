#include "nsjson.h"
#include <math.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <float.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#if ( (defined(_WIN32) || defined(WIN32) ) && ( defined(_MSC_VER) ) )
#define snprintf sprintf_s
#endif

#define RESERVE_STRING(_len) (2 + ((_len) * 6))
#define JSON_MAX_RECURSION_DEPTH 512

static const char HEX_CHARS[] = "0123456789abcdef";
static const char ESCAPE_CHARS[] = "0123456789\\b\\t\\n\\f\\r\\\"\\\\\\/\\/";

static const uint8_t ASCII_OUTPUT_TABLE[256] = {
    0, 30, 30, 30, 30, 30, 30, 30, 10, 12, 14, 30, 16, 18, 30, 30,
    30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
    1, 1, 20, 1, 1, 1, 29, 1, 1, 1, 1, 1, 1, 1, 1, 24,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 29, 1, 29, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 22, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 1, 1
};

static void EncoderSetError(JSOBJ obj, JSONObjectEncoder *enc, const char *message) {
    enc->errorMsg = (char*)message;
    enc->errorObj = obj;
}

static void Buffer_Realloc(JSONObjectEncoder *enc, size_t needed) {
    size_t free_space = enc->end - enc->offset;
    if (free_space >= needed) return;
    
    size_t current_size = enc->end - enc->start;
    size_t new_size = current_size;
    size_t offset = enc->offset - enc->start;

#ifdef DEBUG
    new_size = offset + needed;
#else
    while (new_size < current_size + needed) new_size *= 2;
#endif

    if (enc->heap) {
        char *new_buffer = enc->realloc(enc->start, new_size);
        if (!new_buffer) {
            EncoderSetError(NULL, enc, "Could not reserve memory block");
            return;
        }
        enc->start = new_buffer;
    } else {
        char *old_start = enc->start;
        enc->heap = 1;
        enc->start = enc->malloc(new_size);
        if (!enc->start) {
            EncoderSetError(NULL, enc, "Could not reserve memory block");
            return;
        }
        memcpy(enc->start, old_start, offset);
    }
    
    enc->offset = enc->start + offset;
    enc->end = enc->start + new_size;
}

#define Buffer_Reserve(enc, len) \
    if ((size_t)((enc)->end - (enc)->offset) < (size_t)(len)) Buffer_Realloc((enc), (len))

static void *Buffer_memcpy(JSONObjectEncoder *enc, const void *src, size_t n) {
    void *out;
#ifdef DEBUG
    if ((size_t)(enc->end - enc->offset) < n) abort();
#endif
    out = memcpy(enc->offset, src, n);
    enc->offset += n;
    return out;
}

static inline void Buffer_AppendShortHexUnchecked(char *output, uint16_t value) {
    output[0] = HEX_CHARS[(value & 0xF000) >> 12];
    output[1] = HEX_CHARS[(value & 0x0F00) >> 8];
    output[2] = HEX_CHARS[(value & 0x00F0) >> 4];
    output[3] = HEX_CHARS[(value & 0x000F)];
}

static int Buffer_EscapeStringUnvalidated(JSONObjectEncoder *enc, const char *input, const char *end) {
    char *output = enc->offset;

    while (input < end) {
#ifdef DEBUG
        if (enc->end - output < 6) abort();
#endif
        unsigned char c = *input;
        
        if (c == 0x00) {
            memcpy(output, "\\u0000", 6);
            output += 6;
            input++;
            continue;
        }

        switch (c) {
            case '\"': memcpy(output, "\\\"", 2); output += 2; break;
            case '\\': memcpy(output, "\\\\", 2); output += 2; break;
            case '\b': memcpy(output, "\\b", 2); output += 2; break;
            case '\f': memcpy(output, "\\f", 2); output += 2; break;
            case '\n': memcpy(output, "\\n", 2); output += 2; break;
            case '\r': memcpy(output, "\\r", 2); output += 2; break;
            case '\t': memcpy(output, "\\t", 2); output += 2; break;
            case '/':
                if (enc->escapeForwardSlashes) {
                    memcpy(output, "\\/", 2);
                    output += 2;
                } else *output++ = c;
                break;
            case '&': case '<': case '>':
                if (enc->encodeHTMLChars) {
                    *output++ = '\\'; *output++ = 'u'; *output++ = '0'; *output++ = '0';
                    *output++ = HEX_CHARS[(c & 0xF0) >> 4]; *output++ = HEX_CHARS[c & 0x0F];
                } else *output++ = c;
                break;
            default:
                if (c < 32) {
                    *output++ = '\\'; *output++ = 'u'; *output++ = '0'; *output++ = '0';
                    *output++ = HEX_CHARS[(c & 0xF0) >> 4]; *output++ = HEX_CHARS[c & 0x0F];
                } else *output++ = c;
                break;
        }
        input++;
    }

    enc->offset = output;
    return TRUE;
}

static int Buffer_EscapeStringValidated(JSOBJ obj, JSONObjectEncoder *enc, const char *input, const char *end) {
    uint32_t ucs;
    char *output = enc->offset;

    while (input < end) {
#ifdef DEBUG
        if (enc->end - output < 6 * (end - input)) abort();
#endif
        uint8_t utf_len = ASCII_OUTPUT_TABLE[(unsigned char)*input];

        switch (utf_len) {
            case 0:
                if (input < end) {
                    memcpy(output, "\\u0000", 6);
                    output += 6;
                    input++;
                    continue;
                }
                enc->offset = output;
                return TRUE;
            case 1:
                *output++ = *input++;
                continue;
            case 2: {
                if (end - input < 2) {
                    enc->offset = output;
                    EncoderSetError(obj, enc, "Unterminated UTF-8 sequence");
                    return FALSE;
                }
                uint16_t in16;
                memcpy(&in16, input, sizeof(uint16_t));
#ifdef __LITTLE_ENDIAN__
                ucs = ((in16 & 0x1F) << 6) | ((in16 >> 8) & 0x3F);
#else
                ucs = ((in16 & 0x1F00) >> 2) | (in16 & 0x3F);
#endif
                if (ucs < 0x80) {
                    enc->offset = output;
                    EncoderSetError(obj, enc, "Overlong 2-byte UTF-8 sequence");
                    return FALSE;
                }
                input += 2;
                break;
            }
            case 3: {
                if (end - input < 3) {
                    enc->offset = output;
                    EncoderSetError(obj, enc, "Unterminated UTF-8 sequence");
                    return FALSE;
                }
                uint32_t in;
                memcpy(&in, input, 3);
#ifdef __LITTLE_ENDIAN__
                ucs = ((in & 0x0F) << 12) | ((in & 0x3F00) >> 2) | ((in & 0x3F0000) >> 16);
#else
                ucs = ((in & 0x0F0000) >> 4) | ((in & 0x3F00) >> 2) | (in & 0x3F);
#endif
                if (ucs < 0x800) {
                    enc->offset = output;
                    EncoderSetError(obj, enc, "Overlong 3-byte UTF-8 sequence");
                    return FALSE;
                }
                input += 3;
                break;
            }
            case 4: {
                if (end - input < 4) {
                    enc->offset = output;
                    EncoderSetError(obj, enc, "Unterminated UTF-8 sequence");
                    return FALSE;
                }
                uint32_t in;
                memcpy(&in, input, sizeof(uint32_t));
#ifdef __LITTLE_ENDIAN__
                ucs = ((in & 0x07) << 18) | ((in & 0x3F00) << 4) | ((in & 0x3F0000) >> 10) | ((in & 0x3F000000) >> 24);
#else
                ucs = ((in & 0x07000000) >> 6) | ((in & 0x3F0000) >> 4) | ((in & 0x3F00) >> 2) | (in & 0x3F);
#endif
                if (ucs < 0x10000) {
                    enc->offset = output;
                    EncoderSetError(obj, enc, "Overlong 4-byte UTF-8 sequence");
                    return FALSE;
                }
                input += 4;
                break;
            }
            case 5: case 6:
                enc->offset = output;
                EncoderSetError(obj, enc, "Unsupported UTF-8 sequence length");
                return FALSE;
            case 29:
                if (enc->encodeHTMLChars) ;
                else {
                    *output++ = *input++;
                    continue;
                }
            case 30:
                *output++ = '\\'; *output++ = 'u'; *output++ = '0'; *output++ = '0';
                *output++ = HEX_CHARS[(*input & 0xF0) >> 4]; *output++ = HEX_CHARS[*input & 0x0F];
                input++;
                continue;
            case 10: case 12: case 14: case 16: case 18: case 20: case 22:
                *output++ = ESCAPE_CHARS[utf_len]; *output++ = ESCAPE_CHARS[utf_len + 1];
                input++;
                continue;
            case 24:
                if (enc->escapeForwardSlashes) {
                    *output++ = ESCAPE_CHARS[utf_len]; *output++ = ESCAPE_CHARS[utf_len + 1];
                } else *output++ = *input;
                input++;
                continue;
            default: ucs = 0; break;
        }

        if (ucs >= 0x10000) {
            ucs -= 0x10000;
            *output++ = '\\'; *output++ = 'u';
            Buffer_AppendShortHexUnchecked(output, (uint16_t)((ucs >> 10) + 0xD800));
            output += 4;
            *output++ = '\\'; *output++ = 'u';
            Buffer_AppendShortHexUnchecked(output, (uint16_t)((ucs & 0x3FF) + 0xDC00));
            output += 4;
        } else {
            *output++ = '\\'; *output++ = 'u';
            Buffer_AppendShortHexUnchecked(output, (uint16_t)ucs);
            output += 4;
        }
    }

    enc->offset = output;
    return TRUE;
}

static inline void Buffer_AppendCharUnchecked(JSONObjectEncoder *enc, char chr) {
#ifdef DEBUG
    if (enc->end <= enc->offset) abort();
#endif
    *(enc->offset++) = chr;
}

static inline void str_reverse(char* begin, char* end) {
    char temp;
    while (end > begin) {
        temp = *end;
        *end-- = *begin;
        *begin++ = temp;
    }
}

static void Buffer_AppendIndentNewlineUnchecked(JSONObjectEncoder *enc) {
    if (enc->indent > 0) Buffer_AppendCharUnchecked(enc, '\n');
}

static void Buffer_AppendIndentUnchecked(JSONObjectEncoder *enc, int32_t level) {
    if (enc->indent > 0) {
        while (level-- > 0) {
            for (int i = 0; i < enc->indent; i++) Buffer_AppendCharUnchecked(enc, ' ');
        }
    }
}

static void Buffer_AppendLongUnchecked(JSONObjectEncoder *enc, int64_t value) {
    char* write_pos = enc->offset;
    uint64_t uvalue = (value == INT64_MIN) ? (uint64_t)INT64_MAX + 1 : (value < 0) ? -value : value;

#ifdef DEBUG
    if (enc->end - enc->offset < 21) abort();
#endif

    do *write_pos++ = (char)('0' + (uvalue % 10)); while(uvalue /= 10);
    if (value < 0) *write_pos++ = '-';
    str_reverse(enc->offset, write_pos - 1);
    enc->offset = write_pos;
}

static void Buffer_AppendUnsignedLongUnchecked(JSONObjectEncoder *enc, uint64_t value) {
    char* write_pos = enc->offset;

#ifdef DEBUG
    if (enc->end - enc->offset < 21) abort();
#endif

    do *write_pos++ = (char)('0' + (value % 10)); while(value /= 10);
    str_reverse(enc->offset, write_pos - 1);
    enc->offset = write_pos;
}

static int Buffer_AppendDouble(JSOBJ obj, JSONObjectEncoder *enc, double value) {
    char buffer[128];
    int length;
    
#ifdef DEBUG
    if ((size_t)(enc->end - enc->offset) < sizeof(buffer)) abort();
#endif

    if (isnan(value)) {
        if (!enc->allowNan) {
            EncoderSetError(obj, enc, "NaN not allowed");
            return FALSE;
        }
        length = snprintf(buffer, sizeof(buffer), "NaN");
    } else if (isinf(value)) {
        if (!enc->allowNan) {
            EncoderSetError(obj, enc, "Infinity not allowed");
            return FALSE;
        }
        if (value > 0) {
            length = snprintf(buffer, sizeof(buffer), "Infinity");
        } else {
            length = snprintf(buffer, sizeof(buffer), "-Infinity");
        }
    } else {
        length = snprintf(buffer, sizeof(buffer), "%.17g", value);
    }
    
    if (length < 0 || (size_t)length >= sizeof(buffer)) {
        EncoderSetError(obj, enc, "Double value too large");
        return FALSE;
    }

    Buffer_memcpy(enc, buffer, length);
    return TRUE;
}

static void encode(JSOBJ obj, JSONObjectEncoder *enc, const char *name, size_t name_len) {
    const char *str_value;
    char *obj_name;
    int count, result;
    JSOBJ iter_obj;
    size_t str_len;
    JSONTypeContext type_context;

    if (enc->level > enc->recursionMax) {
        EncoderSetError(obj, enc, "Maximum recursion depth reached");
        return;
    }

    if (enc->errorMsg) return;

    if (name) {
        Buffer_Reserve(enc, RESERVE_STRING(name_len) + enc->keySeparatorLength);
        Buffer_AppendCharUnchecked(enc, '\"');

        if (enc->forceASCII) {
            if (!Buffer_EscapeStringValidated(obj, enc, name, name + name_len)) return;
        } else {
            if (!Buffer_EscapeStringUnvalidated(enc, name, name + name_len)) return;
        }

        Buffer_AppendCharUnchecked(enc, '\"');
        Buffer_memcpy(enc, enc->keySeparatorChars, enc->keySeparatorLength);
    }

    type_context.encoder_prv = enc->prv;
    enc->beginTypeContext(obj, &type_context, enc);
    Buffer_Reserve(enc, 128);

    switch (type_context.type) {
        case JT_INVALID:
            EncoderSetError(obj, enc, "Invalid type");
            enc->level--;
            return;
        case JT_ARRAY:
            count = 0;
            Buffer_AppendCharUnchecked(enc, '[');
            while (enc->iterNext(obj, &type_context)) {
                Buffer_Reserve(enc, enc->indent * (enc->level + 1) + enc->itemSeparatorLength + 1);
                if (count > 0) Buffer_memcpy(enc, enc->itemSeparatorChars, enc->itemSeparatorLength);
                Buffer_AppendIndentNewlineUnchecked(enc);
                iter_obj = enc->iterGetValue(obj, &type_context);
                enc->level++;
                Buffer_AppendIndentUnchecked(enc, enc->level);
                encode(iter_obj, enc, NULL, 0);
                if (enc->errorMsg) {
                    enc->iterEnd(obj, &type_context);
                    enc->endTypeContext(obj, &type_context);
                    enc->level--;
                    return;
                }
                count++;
            }
            enc->iterEnd(obj, &type_context);
            if (count > 0) {
                Buffer_Reserve(enc, enc->indent * enc->level + 1);
                Buffer_AppendIndentNewlineUnchecked(enc);
                Buffer_AppendIndentUnchecked(enc, enc->level);
            }
            Buffer_Reserve(enc, 1);
            Buffer_AppendCharUnchecked(enc, ']');
            break;
        case JT_OBJECT:
            count = 0;
            Buffer_AppendCharUnchecked(enc, '{');
            while ((result = enc->iterNext(obj, &type_context))) {
                Buffer_Reserve(enc, enc->indent * (enc->level + 1) + enc->itemSeparatorLength + 1);
                if (result < 0) {
                    enc->iterEnd(obj, &type_context);
                    enc->endTypeContext(obj, &type_context);
                    enc->level--;
                    return;
                }
                if (count > 0) Buffer_memcpy(enc, enc->itemSeparatorChars, enc->itemSeparatorLength);
                Buffer_AppendIndentNewlineUnchecked(enc);
                iter_obj = enc->iterGetValue(obj, &type_context);
                obj_name = enc->iterGetName(obj, &type_context, &str_len);
                enc->level++;
                Buffer_AppendIndentUnchecked(enc, enc->level);
                encode(iter_obj, enc, obj_name, str_len);
                if (enc->errorMsg) {
                    enc->iterEnd(obj, &type_context);
                    enc->endTypeContext(obj, &type_context);
                    enc->level--;
                    return;
                }
                count++;
            }
            enc->iterEnd(obj, &type_context);
            if (count > 0) {
                Buffer_Reserve(enc, enc->indent * enc->level + 1);
                Buffer_AppendIndentNewlineUnchecked(enc);
                Buffer_AppendIndentUnchecked(enc, enc->level);
            }
            Buffer_Reserve(enc, 1);
            Buffer_AppendCharUnchecked(enc, '}');
            break;
        case JT_LONG:
            Buffer_AppendLongUnchecked(enc, enc->getLongValue(obj, &type_context));
            break;
        case JT_ULONG:
            Buffer_AppendUnsignedLongUnchecked(enc, enc->getUnsignedLongValue(obj, &type_context));
            break;
        case JT_TRUE:
            Buffer_memcpy(enc, "true", 4);
            break;
        case JT_FALSE:
            Buffer_memcpy(enc, "false", 5);
            break;
        case JT_NULL:
            Buffer_memcpy(enc, "null", 4);
            break;
        case JT_DOUBLE:
            if (!Buffer_AppendDouble(obj, enc, enc->getDoubleValue(obj, &type_context))) {
                enc->endTypeContext(obj, &type_context);
                enc->level--;
                return;
            }
            break;
        case JT_UTF8:
            str_value = enc->getStringValue(obj, &type_context, &str_len);
            if (!str_value) {
                EncoderSetError(obj, enc, "UTF-8 encoding error");
                return;
            }
            Buffer_Reserve(enc, RESERVE_STRING(str_len));
            if (enc->errorMsg) {
                enc->endTypeContext(obj, &type_context);
                return;
            }
            Buffer_AppendCharUnchecked(enc, '\"');
            if (enc->forceASCII) {
                if (!Buffer_EscapeStringValidated(obj, enc, str_value, str_value + str_len)) {
                    enc->endTypeContext(obj, &type_context);
                    enc->level--;
                    return;
                }
            } else {
                if (!Buffer_EscapeStringUnvalidated(enc, str_value, str_value + str_len)) {
                    enc->endTypeContext(obj, &type_context);
                    enc->level--;
                    return;
                }
            }
            Buffer_AppendCharUnchecked(enc, '\"');
            break;
        case JT_RAW:
            str_value = enc->getStringValue(obj, &type_context, &str_len);
            if (!str_value) {
                EncoderSetError(obj, enc, "String encoding error");
                return;
            }
            Buffer_Reserve(enc, str_len);
            if (enc->errorMsg) {
                enc->endTypeContext(obj, &type_context);
                return;
            }
            Buffer_memcpy(enc, str_value, str_len);
            break;
        case JT_INT:
        case JT_NAN:
        case JT_POS_INF:
        case JT_NEG_INF:
            EncoderSetError(obj, enc, "Unsupported type");
            enc->endTypeContext(obj, &type_context);
            enc->level--;
            return;
    }

    enc->endTypeContext(obj, &type_context);
    enc->level--;
}

char *JSON_EncodeObject(JSOBJ obj, JSONObjectEncoder *enc, char *buffer, size_t buffer_size, size_t *output_length) {
    enc->malloc = enc->malloc ? enc->malloc : malloc;
    enc->free = enc->free ? enc->free : free;
    enc->realloc = enc->realloc ? enc->realloc : realloc;
    enc->errorMsg = NULL;
    enc->errorObj = NULL;
    enc->level = 0;

    if (enc->recursionMax < 1) enc->recursionMax = JSON_MAX_RECURSION_DEPTH;

    if (buffer == NULL) {
        buffer_size = 32768;
        enc->start = enc->malloc(buffer_size);
        if (!enc->start) {
            EncoderSetError(obj, enc, "Could not allocate memory");
            return NULL;
        }
        enc->heap = 1;
    } else {
        enc->start = buffer;
        enc->heap = 0;
    }

    enc->end = enc->start + buffer_size;
    enc->offset = enc->start;

    encode(obj, enc, NULL, 0);

    if (enc->errorMsg) {
        if (enc->heap) enc->free(enc->start);
        return NULL;
    }

    *output_length = enc->offset - enc->start;
    return enc->start;
}