# NSJSON API Usage

NSJSON provides a simple, fast, and intuitive interface for JSON serialization and deserialization in Python. Its API closely mirrors Python's standard `json` module, so switching is easy and straightforward.

---

## Installation

```bash
# Clone and build NSJSON C core
git clone https://github.com/yourusername/nsjson.git
cd nsjson
make

# Install Python bindings
pip install ./python


---

Basic Usage

Importing NSJSON

import nsjson


---

Serialize Python objects to JSON

data = {
    "name": "Max",
    "age": 12,
    "items": [1, 2, 3],
    "active": True,
    "score": None
}

# Convert Python object to JSON string
json_str = nsjson.dumps(data)
print(json_str)

Output Example:

{"name":"Max","age":12,"items":[1,2,3],"active":true,"score":null}


---

Deserialize JSON string to Python object

parsed_data = nsjson.loads(json_str)
print(parsed_data["name"])  # Output: Max


---

Supported Types

dict

list

str

int, float

bool

None


NSJSON handles nested structures seamlessly.


---

Optional Parameters (Python)

# Pretty-print JSON with indentation
pretty_json = nsjson.dumps(data, indent=4)

# Sort keys alphabetically
sorted_json = nsjson.dumps(data, sort_keys=True)

Example:

{
    "age": 12,
    "active": true,
    "items": [
        1,
        2,
        3
    ],
    "name": "Max",
    "score": null
}


---

Performance Tips

Use nsjson.dumps and nsjson.loads for maximum speed.

Avoid repeated conversions in tight loops—store intermediate results if possible.

NSJSON is optimized for large datasets, keeping encoding and decoding times minimal.



---

Comparison with Python json module

Feature	json	nsjson

Encoding speed	Moderate	Nano Fast
Decoding speed	Moderate	Nano Fast
Nested objects support	✅	✅
Compact output	✅	✅
Pretty-print support	✅	✅
Python 3.7+ support	✅	✅



---

NSJSON is intended for developers who need high-performance JSON processing with minimal code changes from the standard json module.