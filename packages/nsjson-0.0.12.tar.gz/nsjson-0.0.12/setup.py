from setuptools import setup, Extension

ext_module = Extension(
    'nsjson',  # имя C-расширения
    sources=[
        'decode.c',
        'encode.c',
        'numpa.c',
        'wrapper.c',
    ],
    include_dirs=['.'],  # текущая папка с nsjson.h
    extra_compile_args=['-O3', '-fPIC'],
    define_macros=[('PY_SSIZE_T_CLEAN', '1')],
)

setup(
    name="nsjson",
    version="0.0.12",
    description="Nano Fast JSON written in C with Python bindings",
    packages=['.'],  # пакет на базе __init__.py в текущей папке
    ext_modules=[ext_module],
    python_requires=">=3.6",
)