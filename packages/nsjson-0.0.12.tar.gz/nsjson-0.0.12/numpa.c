#include "numpa.h"
#include <stdlib.h>
#include <math.h>
#include <errno.h>
#include <limits.h>

static inline uint64_t parse_uint64_fast(const char *digits, size_t len) {
    uint64_t value = 0;
    for (size_t i = 0; i < len; i++) {
        value = value * 10 + (digits[i] - '0');
    }
    return value;
}

static inline double parse_double_fast(const char *str, size_t len, int is_negative) {
    // Быстрый парсинг без копирования и strtod
    double result = 0.0;
    double fraction = 0.0;
    double divisor = 1.0;
    int in_fraction = 0;
    int exponent = 0;
    int exp_sign = 1;
    int in_exponent = 0;
    
    for (size_t i = 0; i < len; i++) {
        char c = str[i];
        
        if (c >= '0' && c <= '9') {
            if (in_exponent) {
                exponent = exponent * 10 + (c - '0');
            } else if (in_fraction) {
                fraction = fraction * 10 + (c - '0');
                divisor *= 10.0;
            } else {
                result = result * 10 + (c - '0');
            }
        } else if (c == '.') {
            in_fraction = 1;
        } else if (c == 'e' || c == 'E') {
            in_exponent = 1;
            if (i + 1 < len && str[i + 1] == '-') {
                exp_sign = -1;
                i++;
            } else if (i + 1 < len && str[i + 1] == '+') {
                i++;
            }
        }
    }
    
    double value = result + (fraction / divisor);
    if (exponent) {
        value *= pow(10.0, exp_sign * exponent);
    }
    return is_negative ? -value : value;
}

ParseNumberResult parse_json_number(const char *str, size_t len, int allow_nan_inf, int strict_mode) {
    ParseNumberResult result = {0};
    
    if (len == 0) {
        result.error = "Empty number";
        return result;
    }
    
    int offset = 0;
    int is_negative = 0;

    // Обработка отрицательного знака
    if (str[offset] == '-') {
        is_negative = 1;
        offset++;
        if (offset >= (int)len) {
            result.error = "Incomplete negative number";
            return result;
        }
    }

    // NaN/Infinity (оставляем как есть)
    if ((str[offset] == 'N' || str[offset] == 'I') && allow_nan_inf) {
        if (str[offset] == 'N' && len - offset >= 3 && memcmp(str + offset, "NaN", 3) == 0) {
            result.type = NP_DOUBLE;
            result.value.double_val = NAN;
            result.processed_chars = offset + 3;
            return result;
        }
        if (str[offset] == 'I' && len - offset >= 8 && memcmp(str + offset, "Infinity", 8) == 0) {
            result.type = NP_DOUBLE;
            result.value.double_val = is_negative ? -INFINITY : INFINITY;
            result.processed_chars = offset + 8;
            return result;
        }
        result.error = "Invalid NaN/Infinity literal";
        return result;
    }

    // Strict mode проверка
    if (strict_mode && offset < (int)len && str[offset] == '0') {
        if (offset + 1 < (int)len && str[offset + 1] >= '0' && str[offset + 1] <= '9') {
            result.error = "Leading zeros not allowed in strict mode";
            return result;
        }
    }

    // Парсим цифры
    int integer_start = offset;
    int has_digits = 0;
    while (offset < (int)len && str[offset] >= '0' && str[offset] <= '9') {
        offset++;
        has_digits = 1;
    }

    if (!has_digits) {
        result.error = "No digits in number";
        return result;
    }

    // Проверяем дробную часть
    int has_fraction = 0;
    if (offset < (int)len && str[offset] == '.') {
        has_fraction = 1;
        offset++;
        int fraction_start = offset;
        while (offset < (int)len && str[offset] >= '0' && str[offset] <= '9') {
            offset++;
        }
        if (offset == fraction_start) {
            result.error = "Invalid fraction part";
            return result;
        }
    }

    // Проверяем экспоненту
    int has_exponent = 0;
    if (offset < (int)len && (str[offset] == 'e' || str[offset] == 'E')) {
        has_exponent = 1;
        offset++;
        if (offset < (int)len && (str[offset] == '+' || str[offset] == '-')) {
            offset++;
        }
        int exp_start = offset;
        while (offset < (int)len && str[offset] >= '0' && str[offset] <= '9') {
            offset++;
        }
        if (offset == exp_start) {
            result.error = "Invalid exponent";
            return result;
        }
    }

    result.processed_chars = offset;

    // ОПТИМИЗАЦИЯ: Быстрый путь для целых чисел
    if (!has_fraction && !has_exponent) {
        size_t digits_len = offset - integer_start;
        
        if (digits_len <= 19) { // Вмещаемся в uint64
            uint64_t value = parse_uint64_fast(str + integer_start, digits_len);
            
            if (is_negative) {
                if (value > (uint64_t)INT64_MAX + 1) {
                    result.error = "Number too large";
                    return result;
                }
                int64_t signed_value = (value == (uint64_t)INT64_MAX + 1) 
                    ? INT64_MIN : -(int64_t)value;
                    
                if (signed_value >= INT32_MIN) {
                    result.type = NP_INT32;
                    result.value.int32_val = (int32_t)signed_value;
                } else {
                    result.type = NP_INT64;
                    result.value.int64_val = signed_value;
                }
            } else {
                if (value > INT64_MAX) {
                    result.type = NP_UINT64;
                    result.value.uint64_val = value;
                } else if (value > INT32_MAX) {
                    result.type = NP_INT64;
                    result.value.int64_val = (int64_t)value;
                } else {
                    result.type = NP_INT32;
                    result.value.int32_val = (int32_t)value;
                }
            }
            return result;
        }
    }

    // ОПТИМИЗАЦИЯ: Быстрый парсинг дробных чисел
    double double_val = parse_double_fast(str + (is_negative ? 1 : 0), 
                                        result.processed_chars - (is_negative ? 1 : 0), 
                                        is_negative);
    
    result.type = NP_DOUBLE;
    result.value.double_val = double_val;
    return result;
}