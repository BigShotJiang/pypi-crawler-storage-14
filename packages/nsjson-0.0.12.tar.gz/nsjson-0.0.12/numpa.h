#ifndef NUMBER_PARSER_H
#define NUMBER_PARSER_H

#include <stdint.h>
#include <stddef.h>

typedef enum {
    NP_INT32,
    NP_INT64, 
    NP_UINT64,
    NP_DOUBLE,
    NP_INVALID
} NumberType;

typedef struct {
    NumberType type;
    union {
        int32_t int32_val;
        int64_t int64_val;
        uint64_t uint64_val;
        double double_val;
    } value;
    int processed_chars;
    const char *error;
} ParseNumberResult;

ParseNumberResult parse_json_number(const char *str, size_t len, int allow_nan_inf, int strict_mode);

#endif