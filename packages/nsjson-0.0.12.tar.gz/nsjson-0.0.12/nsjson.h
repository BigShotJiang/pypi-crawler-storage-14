#ifndef NSJSON_H
#define NSJSON_H

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void* JSOBJ;
typedef int32_t JSINT32;
typedef int64_t JSINT64;
typedef uint32_t JSUINT32;
typedef uint64_t JSUINT64;
typedef uint16_t JSUTF16;
typedef uint32_t JSUTF32;

typedef enum {
    JT_INVALID = 0,
    JT_NULL,
    JT_TRUE,
    JT_FALSE,
    JT_INT,
    JT_LONG,
    JT_ULONG,
    JT_DOUBLE,
    JT_UTF8,
    JT_RAW,
    JT_ARRAY,
    JT_OBJECT,
    JT_NAN,
    JT_POS_INF,
    JT_NEG_INF
} JSONType;

typedef struct JSONObjectDecoder JSONObjectDecoder;
typedef struct JSONObjectEncoder JSONObjectEncoder;
typedef struct JSONTypeContext JSONTypeContext;

typedef void (*JSPFN_ITEREND)(JSOBJ obj, JSONTypeContext *tc);
typedef int (*JSPFN_ITERNEXT)(JSOBJ obj, JSONTypeContext *tc);
typedef JSOBJ (*JSPFN_ITERGETVALUE)(JSOBJ obj, JSONTypeContext *tc);
typedef char* (*JSPFN_ITERGETNAME)(JSOBJ obj, JSONTypeContext *tc, size_t *outLen);

#define JSON_STRICT_MODE 0x01
#define JSON_ALLOW_NAN_INF 0x02
#define JSON_VALIDATE_UTF8 0x04
#define JSON_REJECT_DUPLICATES 0x08
#define JSON_OBJECT_POOLING 0x10

struct JSONObjectDecoder {
    JSOBJ (*newString)(void *prv, const char *str, size_t len, int is_raw);
    void (*objectAddKey)(void *prv, JSOBJ obj, JSOBJ name, JSOBJ value);
    void (*arrayAddItem)(void *prv, JSOBJ obj, JSOBJ value);
    JSOBJ (*newTrue)(void *prv);
    JSOBJ (*newFalse)(void *prv);
    JSOBJ (*newNull)(void *prv);
    JSOBJ (*newNaN)(void *prv);
    JSOBJ (*newPosInf)(void *prv);
    JSOBJ (*newNegInf)(void *prv);
    JSOBJ (*newObject)(void *prv);
    JSOBJ (*newArray)(void *prv);
    JSOBJ (*newInt)(void *prv, JSINT32 value);
    JSOBJ (*newLong)(void *prv, JSINT64 value);
    JSOBJ (*newUnsignedLong)(void *prv, JSUINT64 value);
    JSOBJ (*newIntegerFromString)(void *prv, char *value, size_t length);
    JSOBJ (*newDouble)(void *prv, double value);
    void (*releaseObject)(void *prv, JSOBJ obj);
    JSOBJ (*getCachedObject)(void *prv, const char *key, size_t key_len);
    void (*cacheObject)(void *prv, JSOBJ obj, const char *key, size_t key_len);
    void* (*malloc)(size_t size);
    void (*free)(void *ptr);
    void* (*realloc)(void *ptr, size_t size);
    void *prv;
    char *errorStr;
    char *errorOffset;
    int flags;
};

struct JSONObjectEncoder {
    void (*beginTypeContext)(JSOBJ obj, JSONTypeContext *tc, JSONObjectEncoder *enc);
    void (*endTypeContext)(JSOBJ obj, JSONTypeContext *tc);
    const char* (*getStringValue)(JSOBJ obj, JSONTypeContext *tc, size_t *_outLen);
    JSINT64 (*getLongValue)(JSOBJ obj, JSONTypeContext *tc);
    JSUINT64 (*getUnsignedLongValue)(JSOBJ obj, JSONTypeContext *tc);
    double (*getDoubleValue)(JSOBJ obj, JSONTypeContext *tc);
    int (*iterNext)(JSOBJ obj, JSONTypeContext *tc);
    void (*iterEnd)(JSOBJ obj, JSONTypeContext *tc);
    JSOBJ (*iterGetValue)(JSOBJ obj, JSONTypeContext *tc);
    char* (*iterGetName)(JSOBJ obj, JSONTypeContext *tc, size_t *outLen);
    void (*releaseObject)(JSOBJ _obj);
    void* (*malloc)(size_t size);
    void* (*realloc)(void *ptr, size_t size);
    void (*free)(void *ptr);
    int recursionMax;
    int forceASCII;
    int encodeHTMLChars;
    int escapeForwardSlashes;
    int sortKeys;
    int indent;
    int allowNan;
    int rejectBytes;
    size_t itemSeparatorLength;
    char *itemSeparatorChars;
    size_t keySeparatorLength;
    char *keySeparatorChars;
    void *prv;
    char *start;
    char *offset;
    char *end;
    int heap;
    int level;
    char *errorMsg;
    JSOBJ errorObj;
};

struct JSONTypeContext {
    void *prv;
    void *encoder_prv;
    JSONType type;
};

JSOBJ JSON_DecodeObject(JSONObjectDecoder *dec, const char *buffer, size_t bufferSize);
char *JSON_EncodeObject(JSOBJ obj, JSONObjectEncoder *enc, char *buffer, size_t buffer_size, size_t *output_length);

#ifdef __cplusplus
}
#endif

#endif