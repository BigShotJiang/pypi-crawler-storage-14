#include "nsjson.h"
#include "numpa.h"
#include <math.h>
#include <assert.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <stdint.h>
#include <stdbool.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define MAX_STACK_BUFFER_SIZE 4096
#define MAX_OBJECT_DEPTH 1024
#define INITIAL_ESCAPE_BUFFER_SIZE 256

#define JSON_VALIDATE_UTF8          (1 << 0)
#define JSON_ALLOW_NAN_INF          (1 << 1)
#define JSON_STRICT_MODE            (1 << 2)
#define JSON_FAST_NUMERICS          (1 << 3)

typedef struct DecoderState {
    char *start;
    char *end;
    uint32_t *escStart;
    uint32_t *escEnd;
    int escHeap;
    int lastType;
    uint32_t objDepth;
    void *prv;
    JSONObjectDecoder *dec;
    int flags;
} DecoderState;

static JSOBJ decode_any(DecoderState *ds);
static JSOBJ SetError(DecoderState *ds, int offset, const char *message);
static void SkipWhitespace(DecoderState *ds);
static JSOBJ decode_string(DecoderState *ds);
static JSOBJ decode_number(DecoderState *ds);
static JSOBJ decode_true(DecoderState *ds);
static JSOBJ decode_false(DecoderState *ds);
static JSOBJ decode_null(DecoderState *ds);
static JSOBJ decode_array(DecoderState *ds);
static JSOBJ decode_object(DecoderState *ds);
static JSOBJ decode_numeric_fast(DecoderState *ds);
static JSOBJ decodeDouble(DecoderState *ds);

static const uint8_t DECODER_LOOKUP[256] = {
    0x20, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 0x21, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0x22, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    4, 4, 4, 4, 4, 4, 4, 4, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23
};

static int is_unicode_noncharacter(uint32_t cp) {
    return (cp >= 0xFDD0 && cp <= 0xFDEF) || 
           (cp >= 0xFFFE && cp <= 0xFFFF) ||
           (cp >= 0x1FFFE && cp <= 0x1FFFF) ||
           (cp >= 0x2FFFE && cp <= 0x2FFFF) ||
           (cp >= 0x3FFFE && cp <= 0x3FFFF) ||
           (cp >= 0x4FFFE && cp <= 0x4FFFF) ||
           (cp >= 0x5FFFE && cp <= 0x5FFFF) ||
           (cp >= 0x6FFFE && cp <= 0x6FFFF) ||
           (cp >= 0x7FFFE && cp <= 0x7FFFF) ||
           (cp >= 0x8FFFE && cp <= 0x8FFFF) ||
           (cp >= 0x9FFFE && cp <= 0x9FFFF) ||
           (cp >= 0xAFFFE && cp <= 0xAFFFF) ||
           (cp >= 0xBFFFE && cp <= 0xBFFFF) ||
           (cp >= 0xCFFFE && cp <= 0xCFFFF) ||
           (cp >= 0xDFFFE && cp <= 0xDFFFF) ||
           (cp >= 0xEFFFE && cp <= 0xEFFFF) ||
           (cp >= 0xFFFFE && cp <= 0xFFFFF) ||
           (cp >= 0x10FFFE && cp <= 0x10FFFF);
}

static JSOBJ SetError(DecoderState *ds, int offset, const char *message) {
    ds->dec->errorOffset = ds->start + offset;
    ds->dec->errorStr = (char *)message;
    return NULL;
}

static int isDigit(char c) {
    return (c >= '0' && c <= '9');
}

static int hexCharToInt(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static void SkipWhitespace(DecoderState *ds) {
    char *pos = ds->start;
    while (pos < ds->end) {
        char c = *pos;
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
            pos++;
        } else {
            break;
        }
    }
    ds->start = pos;
}

static int ensureEscapeBuffer(DecoderState *ds, size_t required) {
    size_t currentSize = ds->escEnd - ds->escStart;
    if (currentSize >= required) return 1;
    
    size_t newSize = currentSize * 2;
    while (newSize < required) newSize *= 2;
    
    if (newSize > SIZE_MAX / sizeof(uint32_t)) return 0;
    
    uint32_t *newBuffer;
    if (ds->escHeap) {
        newBuffer = ds->dec->realloc(ds->escStart, newSize * sizeof(uint32_t));
    } else {
        newBuffer = ds->dec->malloc(newSize * sizeof(uint32_t));
        if (newBuffer && ds->escStart) {
            memcpy(newBuffer, ds->escStart, currentSize * sizeof(uint32_t));
        }
        ds->escHeap = 1;
    }
    
    if (!newBuffer) return 0;
    
    ds->escStart = newBuffer;
    ds->escEnd = newBuffer + newSize;
    return 1;
}

static uint32_t decodeUtf8Char(uint8_t **input, DecoderState *ds) {
    uint8_t *pos = *input;
    uint8_t first = *pos++;
    uint32_t codePoint;
    
    if (first < 0x80) {
        codePoint = first;
    } else if ((first & 0xE0) == 0xC0) {
        if (pos >= (uint8_t*)ds->end || (pos[0] & 0xC0) != 0x80) return (uint32_t)-1;
        codePoint = ((first & 0x1F) << 6) | (pos[0] & 0x3F);
        pos++;
        if (codePoint < 0x80) return (uint32_t)-1;
    } else if ((first & 0xF0) == 0xE0) {
        if (pos + 1 >= (uint8_t*)ds->end || (pos[0] & 0xC0) != 0x80 || (pos[1] & 0xC0) != 0x80) return (uint32_t)-1;
        codePoint = ((first & 0x0F) << 12) | ((pos[0] & 0x3F) << 6) | (pos[1] & 0x3F);
        pos += 2;
        if (codePoint < 0x800) return (uint32_t)-1;
    } else if ((first & 0xF8) == 0xF0) {
        if (pos + 2 >= (uint8_t*)ds->end || (pos[0] & 0xC0) != 0x80 || 
            (pos[1] & 0xC0) != 0x80 || (pos[2] & 0xC0) != 0x80) return (uint32_t)-1;
        codePoint = ((first & 0x07) << 18) | ((pos[0] & 0x3F) << 12) | 
                   ((pos[1] & 0x3F) << 6) | (pos[2] & 0x3F);
        pos += 3;
        if (codePoint < 0x10000) return (uint32_t)-1;
    } else {
        return (uint32_t)-1;
    }
    
    *input = pos;
    
    if ((ds->flags & JSON_VALIDATE_UTF8) && is_unicode_noncharacter(codePoint)) {
        return (uint32_t)-2;
    }
    
    return codePoint;
}

static JSOBJ decode_string_fast_path(DecoderState *ds) {
    char *start = ds->start + 1;
    char *pos = start;
    
    while (pos < ds->end) {
        uint8_t lookup = DECODER_LOOKUP[(uint8_t)*pos];
        
        if (lookup == 0x21) {
            size_t len = pos - start;
            ds->start = pos + 1;
            ds->lastType = JT_UTF8;
            
            uint8_t *utf_check = (uint8_t*)start;
            while (utf_check < (uint8_t*)pos) {
                if (DECODER_LOOKUP[*utf_check] >= 2) {
                    uint32_t cp = decodeUtf8Char(&utf_check, ds);
                    if (cp == (uint32_t)-1) return SetError(ds, -1, "Invalid UTF-8 sequence");
                    if (cp == (uint32_t)-2) return SetError(ds, -1, "Unicode non-character not allowed");
                } else {
                    utf_check++;
                }
            }
            
            return ds->dec->newString(ds->prv, start, len, 0);
        }
        
        if (lookup == 0x22 || lookup == 0x20 || lookup >= 2) {
            break;
        }
        
        pos++;
    }
    
    return NULL;
}

static JSOBJ decode_string(DecoderState *ds) {
    JSOBJ fast_result = decode_string_fast_path(ds);
    if (fast_result) return fast_result;
    
    uint32_t *escPos = ds->escStart;
    uint8_t *input = (uint8_t*)(ds->start + 1);
    uint32_t lastHighSurrogate = 0;
    int has_high_surrogate = 0;
    
    ds->lastType = JT_INVALID;

    while (input < (uint8_t*)ds->end) {
        if ((size_t)(escPos - ds->escStart) >= (size_t)((ds->escEnd - ds->escStart) / 2)) {
            if (!ensureEscapeBuffer(ds, (escPos - ds->escStart) * 2)) {
                return SetError(ds, -1, "Failed to allocate escape buffer");
            }
            escPos = ds->escStart + (escPos - ds->escStart);
        }
        
        uint8_t c = *input;
        uint8_t lookup = DECODER_LOOKUP[c];
        
        if (lookup == 0x21) {
            if (has_high_surrogate) {
                return SetError(ds, -1, "Unpaired UTF-16 surrogate");
            }
            ds->lastType = JT_UTF8;
            ds->start = (char*)(input + 1);
            
            size_t unicode_len = escPos - ds->escStart;
            if (unicode_len == 0) {
                return ds->dec->newString(ds->prv, "", 0, 0);
            }
            
            size_t utf8_len = 0;
            for (size_t i = 0; i < unicode_len; i++) {
                uint32_t cp = ds->escStart[i];
                if (cp <= 0x7F) utf8_len += 1;
                else if (cp <= 0x7FF) utf8_len += 2;
                else if (cp <= 0xFFFF) utf8_len += 3;
                else utf8_len += 4;
            }
            
            char *utf8_buffer = ds->dec->malloc(utf8_len);
            if (!utf8_buffer) {
                return SetError(ds, -1, "Failed to allocate UTF-8 buffer");
            }
            
            char *utf8_pos = utf8_buffer;
            for (size_t i = 0; i < unicode_len; i++) {
                uint32_t cp = ds->escStart[i];
                if (cp <= 0x7F) {
                    *utf8_pos++ = (char)cp;
                } else if (cp <= 0x7FF) {
                    *utf8_pos++ = (char)(0xC0 | (cp >> 6));
                    *utf8_pos++ = (char)(0x80 | (cp & 0x3F));
                } else if (cp <= 0xFFFF) {
                    *utf8_pos++ = (char)(0xE0 | (cp >> 12));
                    *utf8_pos++ = (char)(0x80 | ((cp >> 6) & 0x3F));
                    *utf8_pos++ = (char)(0x80 | (cp & 0x3F));
                } else {
                    *utf8_pos++ = (char)(0xF0 | (cp >> 18));
                    *utf8_pos++ = (char)(0x80 | ((cp >> 12) & 0x3F));
                    *utf8_pos++ = (char)(0x80 | ((cp >> 6) & 0x3F));
                    *utf8_pos++ = (char)(0x80 | (cp & 0x3F));
                }
            }
            
            JSOBJ result = ds->dec->newString(ds->prv, utf8_buffer, utf8_len, 0);
            ds->dec->free(utf8_buffer);
            return result;
        }
        
        if (lookup == 0x22) {
            input++;
            if (input >= (uint8_t*)ds->end) return SetError(ds, -1, "Unterminated escape sequence");
            
            switch (*input) {
                case '\\': *escPos++ = '\\'; break;
                case '"':  *escPos++ = '"'; break;
                case '/':  *escPos++ = '/'; break;
                case 'b':  *escPos++ = '\b'; break;
                case 'f':  *escPos++ = '\f'; break;
                case 'n':  *escPos++ = '\n'; break;
                case 'r':  *escPos++ = '\r'; break;
                case 't':  *escPos++ = '\t'; break;
                case 'u': {
                    input++;
                    if (input + 4 > (uint8_t*)ds->end) return SetError(ds, -1, "Incomplete unicode escape");
                    
                    uint32_t codePoint = 0;
                    for (int i = 0; i < 4; i++) {
                        int hexValue = hexCharToInt(*input);
                        if (hexValue == -1) return SetError(ds, -1, "Invalid hex digit in unicode escape");
                        codePoint = (codePoint << 4) | hexValue;
                        input++;
                    }
                    input--;
                    
                    if (codePoint >= 0xD800 && codePoint <= 0xDBFF) {
                        if (has_high_surrogate) {
                            return SetError(ds, -1, "Multiple high surrogates in sequence");
                        }
                        lastHighSurrogate = codePoint;
                        has_high_surrogate = 1;
                    } else if (codePoint >= 0xDC00 && codePoint <= 0xDFFF) {
                        if (!has_high_surrogate) {
                            return SetError(ds, -1, "Unpaired low surrogate");
                        }
                        codePoint = 0x10000 + ((lastHighSurrogate - 0xD800) << 10) + (codePoint - 0xDC00);
                        lastHighSurrogate = 0;
                        has_high_surrogate = 0;
                        *escPos++ = codePoint;
                    } else {
                        if (has_high_surrogate) {
                            return SetError(ds, -1, "Unpaired high surrogate");
                        }
                        *escPos++ = codePoint;
                    }
                    break;
                }
                default: return SetError(ds, -1, "Invalid escape sequence");
            }
            input++;
        } else if (lookup == 0x20) {
            return SetError(ds, -1, "Control character in string");
        } else if (lookup >= 2) {
            uint32_t codePoint = decodeUtf8Char(&input, ds);
            if (codePoint == (uint32_t)-1) {
                return SetError(ds, -1, "Invalid UTF-8 sequence");
            }
            if (codePoint == (uint32_t)-2) {
                return SetError(ds, -1, "Unicode non-character not allowed");
            }
            *escPos++ = codePoint;
        } else {
            *escPos++ = c;
            input++;
        }
    }
    
    return SetError(ds, -1, "Unterminated string");
}

static JSOBJ decodeDouble(DecoderState *ds) {
    char *start = ds->start;
    size_t remaining = ds->end - ds->start;
    
    int allow_nan_inf = (ds->flags & JSON_ALLOW_NAN_INF) != 0;
    int strict_mode = (ds->flags & JSON_STRICT_MODE) != 0;
    
    ParseNumberResult parse_result = parse_json_number(start, remaining, allow_nan_inf, strict_mode);
    
    if (parse_result.error) {
        return SetError(ds, 0, parse_result.error);
    }
    
    ds->start += parse_result.processed_chars;
    ds->lastType = JT_DOUBLE;
    return ds->dec->newDouble(ds->prv, parse_result.value.double_val);
}

static JSOBJ decode_numeric_fast(DecoderState *ds) {
    int isNegative = 0;
    int hasOverflow = 0;
    uint64_t value = 0;
    char *pos = ds->start;

    if (*pos == '-') {
        isNegative = 1;
        pos++;
    }

    if (*pos == 'I') {
        pos++;
        if (memcmp(pos, "nfinity", 7) != 0) return SetError(ds, -1, "Invalid Infinity literal");
        pos += 7;
        ds->start = pos;
        if (isNegative) {
            ds->lastType = JT_NEG_INF;
            return ds->dec->newNegInf(ds->prv);
        } else {
            ds->lastType = JT_POS_INF;
            return ds->dec->newPosInf(ds->prv);
        }
    } else if (*pos == 'N') {
        pos++;
        if (pos[0] != 'a' || pos[1] != 'N') return SetError(ds, -1, "Invalid NaN literal");
        pos += 2;
        ds->lastType = JT_NAN;
        ds->start = pos;
        return ds->dec->newNaN(ds->prv);
    }

    while (pos < ds->end) {
        char c = *pos;
        
        if (isDigit(c)) {
            uint64_t newValue = value * 10 + (c - '0');
            if (newValue < value) hasOverflow = 1;
            value = newValue;
            pos++;
        } else if (c == '.' || c == 'e' || c == 'E') {
            ds->start = pos;
            return decodeDouble(ds);
        } else {
            break;
        }
    }

    if (hasOverflow) {
        char *strStart = ds->start;
        ds->lastType = JT_INT;
        ds->start = pos;
        return ds->dec->newIntegerFromString(ds->prv, strStart, pos - strStart);
    }

    ds->lastType = JT_INT;
    ds->start = pos;

    if (isNegative) {
        if (value > (uint64_t)INT64_MAX + 1) {
            return ds->dec->newIntegerFromString(ds->prv, ds->start - (pos - ds->start), pos - ds->start);
        }
        int64_t signedValue = (int64_t)(-((int64_t)value));
        return (signedValue >= INT_MIN && signedValue <= INT_MAX) ?
               ds->dec->newInt(ds->prv, (int32_t)signedValue) :
               ds->dec->newLong(ds->prv, signedValue);
    } else {
        if (value > INT64_MAX) {
            return ds->dec->newUnsignedLong(ds->prv, value);
        } else if (value > INT_MAX) {
            return ds->dec->newLong(ds->prv, (int64_t)value);
        } else {
            return ds->dec->newInt(ds->prv, (int32_t)value);
        }
    }
}

static JSOBJ decode_number(DecoderState *ds) {
    if (ds->flags & JSON_FAST_NUMERICS) {
        return decode_numeric_fast(ds);
    }
    
    char *start = ds->start;
    size_t remaining = ds->end - ds->start;
    
    int allow_nan_inf = (ds->flags & JSON_ALLOW_NAN_INF) != 0;
    int strict_mode = (ds->flags & JSON_STRICT_MODE) != 0;
    
    ParseNumberResult parse_result = parse_json_number(start, remaining, allow_nan_inf, strict_mode);
    
    if (parse_result.error) {
        return SetError(ds, 0, parse_result.error);
    }
    
    if (parse_result.processed_chars == 0) {
        return SetError(ds, 0, "Invalid number format");
    }
    
    ds->start += parse_result.processed_chars;
    
    switch (parse_result.type) {
        case NP_INT32:
            ds->lastType = JT_INT;
            return ds->dec->newInt(ds->prv, parse_result.value.int32_val);
        case NP_INT64:
            ds->lastType = JT_LONG;
            return ds->dec->newLong(ds->prv, parse_result.value.int64_val);
        case NP_UINT64:
            ds->lastType = JT_ULONG;
            return ds->dec->newUnsignedLong(ds->prv, parse_result.value.uint64_val);
        case NP_DOUBLE:
            ds->lastType = JT_DOUBLE;
            return ds->dec->newDouble(ds->prv, parse_result.value.double_val);
        case NP_INVALID:
        default:
            return SetError(ds, 0, "Invalid number type");
    }
}

static JSOBJ decode_true(DecoderState *ds) {
    if (ds->end - ds->start >= 4 && memcmp(ds->start + 1, "rue", 3) == 0) {
        ds->lastType = JT_TRUE;
        ds->start += 4;
        return ds->dec->newTrue(ds->prv);
    }
    return SetError(ds, -1, "Invalid true literal");
}

static JSOBJ decode_false(DecoderState *ds) {
    if (ds->end - ds->start >= 5 && memcmp(ds->start + 1, "alse", 4) == 0) {
        ds->lastType = JT_FALSE;
        ds->start += 5;
        return ds->dec->newFalse(ds->prv);
    }
    return SetError(ds, -1, "Invalid false literal");
}

static JSOBJ decode_null(DecoderState *ds) {
    if (ds->end - ds->start >= 4 && memcmp(ds->start + 1, "ull", 3) == 0) {
        ds->lastType = JT_NULL;
        ds->start += 4;
        return ds->dec->newNull(ds->prv);
    }
    return SetError(ds, -1, "Invalid null literal");
}

static JSOBJ decode_array(DecoderState *ds) {
    JSOBJ array = ds->dec->newArray(ds->prv);
    
    ds->objDepth++;
    if (ds->objDepth > MAX_OBJECT_DEPTH) {
        ds->dec->releaseObject(ds->prv, array);
        return SetError(ds, -1, "Maximum object depth exceeded");
    }
    
    ds->start++;
    SkipWhitespace(ds);
    
    if (*ds->start == ']') {
        ds->start++;
        ds->objDepth--;
        return array;
    }
    
    while (ds->start < ds->end) {
        SkipWhitespace(ds);
        JSOBJ item = decode_any(ds);
        if (!item) {
            ds->dec->releaseObject(ds->prv, array);
            return NULL;
        }
        
        ds->dec->arrayAddItem(ds->prv, array, item);
        SkipWhitespace(ds);
        
        if (ds->start >= ds->end) {
            ds->dec->releaseObject(ds->prv, array);
            return SetError(ds, -1, "Unterminated array");
        }
        
        char delimiter = *ds->start++;
        if (delimiter == ']') {
            ds->objDepth--;
            return array;
        } else if (delimiter != ',') {
            ds->dec->releaseObject(ds->prv, array);
            return SetError(ds, -1, "Expected ',' or ']' in array");
        }
    }
    
    ds->dec->releaseObject(ds->prv, array);
    return SetError(ds, -1, "Unterminated array");
}

static JSOBJ decode_object(DecoderState *ds) {
    JSOBJ object = ds->dec->newObject(ds->prv);
    
    ds->objDepth++;
    if (ds->objDepth > MAX_OBJECT_DEPTH) {
        ds->dec->releaseObject(ds->prv, object);
        return SetError(ds, -1, "Maximum object depth exceeded");
    }
    
    ds->start++;
    SkipWhitespace(ds);
    
    if (*ds->start == '}') {
        ds->start++;
        ds->objDepth--;
        return object;
    }
    
    while (ds->start < ds->end) {
        SkipWhitespace(ds);
        JSOBJ key = decode_any(ds);
        if (!key) {
            ds->dec->releaseObject(ds->prv, object);
            return NULL;
        }
        
        if (ds->lastType != JT_UTF8) {
            ds->dec->releaseObject(ds->prv, object);
            ds->dec->releaseObject(ds->prv, key);
            return SetError(ds, -1, "Object key must be string");
        }
        
        SkipWhitespace(ds);
        if (ds->start >= ds->end || *ds->start != ':') {
            ds->dec->releaseObject(ds->prv, object);
            ds->dec->releaseObject(ds->prv, key);
            return SetError(ds, -1, "Expected ':' after object key");
        }
        ds->start++;
        
        SkipWhitespace(ds);
        JSOBJ value = decode_any(ds);
        if (!value) {
            ds->dec->releaseObject(ds->prv, object);
            ds->dec->releaseObject(ds->prv, key);
            return NULL;
        }
        
        ds->dec->objectAddKey(ds->prv, object, key, value);
        SkipWhitespace(ds);
        
        if (ds->start >= ds->end) {
            ds->dec->releaseObject(ds->prv, object);
            return SetError(ds, -1, "Unterminated object");
        }
        
        char delimiter = *ds->start++;
        if (delimiter == '}') {
            ds->objDepth--;
            return object;
        } else if (delimiter != ',') {
            ds->dec->releaseObject(ds->prv, object);
            return SetError(ds, -1, "Expected ',' or '}' in object");
        }
    }
    
    ds->dec->releaseObject(ds->prv, object);
    return SetError(ds, -1, "Unterminated object");
}

static JSOBJ decode_any(DecoderState *ds) {
    while (ds->start < ds->end) {
        char c = *ds->start;
        switch (c) {
            case '"': return decode_string(ds);
            case '[': return decode_array(ds);
            case '{': return decode_object(ds);
            case 't': return decode_true(ds);
            case 'f': return decode_false(ds);
            case 'n': return decode_null(ds);
            case '-': case '0': case '1': case '2': case '3': case '4':
            case '5': case '6': case '7': case '8': case '9':
            case 'I': case 'N':
                return decode_number(ds);
            case ' ': case '\t': case '\r': case '\n':
                ds->start++;
                continue;
            default: return SetError(ds, 0, "Unexpected character");
        }
    }
    return SetError(ds, 0, "Unexpected end of input");
}

JSOBJ JSON_DecodeObject(JSONObjectDecoder *dec, const char *buffer, size_t bufferSize) {
    DecoderState ds;
    uint32_t stackBuffer[MAX_STACK_BUFFER_SIZE / sizeof(uint32_t)];
    JSOBJ result;
    
    ds.start = (char*)buffer;
    ds.end = ds.start + bufferSize;
    ds.escStart = stackBuffer;
    ds.escEnd = stackBuffer + (MAX_STACK_BUFFER_SIZE / sizeof(uint32_t));
    ds.escHeap = 0;
    ds.prv = dec->prv;
    ds.dec = dec;
    ds.dec->errorStr = NULL;
    ds.dec->errorOffset = NULL;
    ds.objDepth = 0;
    ds.flags = dec->flags;
    
    result = decode_any(&ds);
    
    if (ds.escHeap && ds.escStart) dec->free(ds.escStart);
    
    if (result && !dec->errorStr) {
        SkipWhitespace(&ds);
        if (ds.start != ds.end) {
            dec->releaseObject(ds.prv, result);
            return SetError(&ds, 0, "Trailing data after JSON");
        }
    }
    
    return result;
}