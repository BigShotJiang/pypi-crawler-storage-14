import nsjson
from typing import Any, Union, Dict, List, Optional

class NSJSON:
    def __init__(self):
        self._encoder = _nsjson
    
    def loads(self, 
              s: str, 
              *,
              strict: bool = False,
              allow_nan_inf: bool = False,
              validate_utf8: bool = True,
              object_pooling: bool = True) -> Any:
        # Преобразуем строку в bytes
        if isinstance(s, str):
            s = s.encode('utf-8')
        return self._encoder.loads(
            s, 
            strict=strict,
            allow_nan_inf=allow_nan_inf,
            validate_utf8=validate_utf8,
            object_pooling=object_pooling
        )
    
    def dumps(self,
              obj: Any,
              *,
              indent: Optional[int] = None,
              ensure_ascii: bool = True,
              sort_keys: bool = False,
              escape_forward_slashes: bool = False,
              allow_nan: bool = True) -> str:
        return self._encoder.dumps(
            obj,
            indent=indent,
            ensure_ascii=ensure_ascii,
            sort_keys=sort_keys,
            escape_forward_slashes=escape_forward_slashes,
            allow_nan=allow_nan
        )
    
    def benchmark(self, data: Any, iterations: int = 1000) -> Dict[str, Any]:
        return self._encoder.benchmark(data, iterations)

nsjson = NSJSON()

loads = nsjson.loads
dumps = nsjson.dumps
benchmark = nsjson.benchmark

STRICT_MODE = nsjson.STRICT_MODE
ALLOW_NAN_INF = nsjson.ALLOW_NAN_INF
VALIDATE_UTF8 = nsjson.VALIDATE_UTF8
OBJECT_POOLING = nsjson.OBJECT_POOLING

__version__ = getattr(_nsjson, '__version__', '0.0.12')

__all__ = [
    'loads',
    'dumps', 
    'benchmark',
    'nsjson',
    'NSJSON',
    'STRICT_MODE',
    'ALLOW_NAN_INF',
    'VALIDATE_UTF8',
    'OBJECT_POOLING',
    '__version__'
]