import nsjson
import ujson
import json
import time

try:
    import yyjson
    YYJSON_AVAILABLE = True
except ImportError:
    print("⚠️  yyjson not available, install with: pip install yyjson")
    YYJSON_AVAILABLE = False

def quick_functionality_test():
    """Быстрая проверка функциональности"""
    print("🔧 QUICK FUNCTIONALITY TEST")
    print("=" * 50)

    test_cases = [
        {'s': 't'},
        [1, 2, 3],
        {'n': {'data': [1, 2, 3]}},
        {'u': 'Hello 世界 🌍'},
        {'num': [1, 2.5, -3, 1e10]},
        {'spec': [True, False, None]},
    ]

    libraries = [('nsjson', nsjson), ('ujson', ujson), ('json', json)]
    if YYJSON_AVAILABLE:
        libraries.append(('yyjson', yyjson))

    for i, test_data in enumerate(test_cases):
        print(f"\nTest {i+1}: {type(test_data).__name__}")

        for lib_name, lib in libraries:
            try:
                # Энкодинг
                encoded = lib.dumps(test_data)

                # Декодинг
                decoded = lib.loads(encoded)

                # Проверка целостности
                if test_data == decoded:
                    print(f"  ✅ {lib_name:8} - OK (size: {len(encoded)} bytes)")
                else:
                    print(f"  ❌ {lib_name:8} - DATA CORRUPTION!")

            except Exception as e:
                print(f"  ❌ {lib_name:8} - ERROR: {e}")

def quick_performance_test():
    """Быстрый тест производительности"""
    print("\n⚡ QUICK PERFORMANCE TEST")
    print("=" * 50)

    # Тестовые данные
    data = {
        'u': [
            {
                'i': i,
                'n': f'User_{i}',
                'prf': {'age': 20 + i % 50, 'active': i % 3 == 0},
                'scr': list(range(10))
            } for i in range(1000)
        ]
    }

    libraries = [('nsjson', nsjson), ('ujson', ujson), ('json', json)]
    if YYJSON_AVAILABLE:
        libraries.append(('yyjson', yyjson))
    
    iterations = 1000

    for lib_name, lib in libraries:
        try:
            # Тест энкодинга
            encode_times = []
            for _ in range(iterations):
                start = time.perf_counter()
                encoded = lib.dumps(data)
                encode_times.append(time.perf_counter() - start)

            # Тест декодинга
            encoded_data = lib.dumps(data)
            decode_times = []
            for _ in range(iterations):
                start = time.perf_counter()
                decoded = lib.loads(encoded_data)
                decode_times.append(time.perf_counter() - start)

            encode_avg = sum(encode_times) / len(encode_times)
            decode_avg = sum(decode_times) / len(decode_times)

            print(f"{lib_name:8} | Encode: {encode_avg:.6f}s | Decode: {decode_avg:.6f}s | "
                  f"Size: {len(encoded_data):,} bytes")

        except Exception as e:
            print(f"{lib_name:8} | ❌ Error: {e}")

def benchmark_large_data():
    """Бенчмарк с большими данными"""
    if not YYJSON_AVAILABLE:
        return
        
    print("\n📊 LARGE DATA BENCHMARK")
    print("=" * 50)
    
    # Создаем большой JSON (1MB+)
    large_data = {
        'arr': [[i * j for j in range(50)] for i in range(100)],
        'str': [f'string_{i}_' + 'x' * (i % 100) for i in range(500)],
        'nest': {f'key_{i}': {f'subkey_{j}': j * 1.5 for j in range(20)} for i in range(50)}
    }
    
    libraries = [('nsjson', nsjson), ('ujson', ujson), ('json', json), ('yyjson', yyjson)]
    iterations = 100
    
    print(f"Data size: {len(json.dumps(large_data)):,} bytes")
    
    for lib_name, lib in libraries:
        try:
            # Энкодинг
            encode_times = []
            for _ in range(iterations):
                start = time.perf_counter()
                encoded = lib.dumps(large_data)
                encode_times.append(time.perf_counter() - start)

            # Декодинг
            decode_times = []
            for _ in range(iterations):
                start = time.perf_counter()
                decoded = lib.loads(encoded)
                decode_times.append(time.perf_counter() - start)

            encode_avg = sum(encode_times) / len(encode_times)
            decode_avg = sum(decode_times) / len(decode_times)

            print(f"{lib_name:8} | Encode: {encode_avg:.6f}s | Decode: {decode_avg:.6f}s")

        except Exception as e:
            print(f"{lib_name:8} | ❌ Error: {e}")

if __name__ == "__main__":
    quick_functionality_test()
    quick_performance_test()
