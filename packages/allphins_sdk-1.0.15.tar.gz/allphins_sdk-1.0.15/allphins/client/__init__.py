"""Get resources from Allphins API."""

from allphins.client.client import Client

__all__ = ["Client"]
