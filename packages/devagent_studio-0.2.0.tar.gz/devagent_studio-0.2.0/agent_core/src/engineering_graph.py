import os
import operator
from typing import TypedDict, Annotated, Sequence
from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode  # Updated import

from src.components.tools import tools
from src.components.engineer_agent import software_engineer_agent

# --- 1. Define the Tools ---
# Use ToolNode instead of ToolExecutor
tool_node = ToolNode(tools)


# --- 2. Define the Graph State ---
class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], operator.add]


# --- 3. Define the Nodes ---
def call_model(state: AgentState):
    print("---CALLING MODEL---")
    messages = state['messages']
    response = software_engineer_agent.invoke({"messages": messages})

    return {"messages": [response]}

def call_tools(state: AgentState):
    """
    This function now delegates to ToolNode which handles tool execution automatically
    """
    print("---EXECUTING TOOLS---")
    # ToolNode handles all the tool execution logic
    return tool_node.invoke(state)

# --- 4. Define the Conditional Edges ---
def should_continue(state: AgentState):
    """
    Decide whether to continue to tools or end
    """
    last_message = state['messages'][-1]
    
    # Check if the last message has tool calls
    if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
        print("---TOOLS NEEDED---")
        return "call_tools"
    else:
        print("---NO TOOLS NEEDED, ENDING---")
        return "end"


# --- 5. Build the Graph ---
workflow = StateGraph(AgentState)

# Add nodes
workflow.add_node("call_model", call_model)
workflow.add_node("call_tools", call_tools)


# Set entry point
workflow.set_entry_point("call_model")

# Add conditional edges
workflow.add_conditional_edges(
    "call_model",
    should_continue,
    {
        "call_tools": "call_tools",
        "end": END                 
    }
)

# Add edge from tools back to model
workflow.add_edge("call_tools", "call_model")

# Compile the graph
app = workflow.compile()