package_name = 'mgraph_ai_service_cache_client'
path         = __path__[0]