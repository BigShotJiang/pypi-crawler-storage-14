class FacebookAccountLostAccessException(Exception):
    """Raised when we cannot access to an account."""
    pass
