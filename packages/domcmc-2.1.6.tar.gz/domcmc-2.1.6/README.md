High level API for reading data from "standard" files produced at Environment Canada. 

<br>
Check out the documentation for installation instructions and examples: <br>
https://goc-dx.science.gc.ca/~dja001/domcmc/

<br>
Source code can be obtained from <br>
https://gitlab.science.gc.ca/dja001/domcmc



