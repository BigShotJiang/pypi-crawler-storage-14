# coding:utf-8

__project__ = "xkits-sheet"
__version__ = "0.2"
__urlhome__ = "https://github.com/bondbox/xsheet/"
__description__ = "Form module"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
