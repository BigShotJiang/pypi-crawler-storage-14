# Modular Reasoning Scaffold (MRS)

A mesoscale meta-reasoning architecture.
