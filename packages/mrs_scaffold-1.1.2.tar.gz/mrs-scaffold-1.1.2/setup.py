from setuptools import setup, find_packages

setup(
    name="mrs-scaffold",
    version="1.1.2",
    packages=find_packages(),
    description="Modular Reasoning Scaffold (MRS): a mesoscale meta-reasoning architecture.",
    author="Sabouhi",
    license="MIT",
)
