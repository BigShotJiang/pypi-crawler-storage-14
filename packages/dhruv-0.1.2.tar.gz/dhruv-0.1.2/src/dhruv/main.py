# src/dhruv/main.py

def hello():
    return "Hello from Dhruv!"
