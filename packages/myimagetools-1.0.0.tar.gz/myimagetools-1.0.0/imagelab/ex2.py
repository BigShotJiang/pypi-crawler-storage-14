# ---------------------------
# IMPORT LIBRARIES
# ---------------------------
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
from tensorflow.keras import layers, models

# ---------------------------
# (a) LOAD DATASETS
# ---------------------------
from tensorflow.keras.datasets import cifar10, mnist

# Load CIFAR-10
(x_train_cifar, y_train_cifar), (x_test_cifar, y_test_cifar) = cifar10.load_data()

# Load MNIST
(x_train_mnist, y_train_mnist), (x_test_mnist, y_test_mnist) = mnist.load_data()

print("\n---- DATA LOADED SUCCESSFULLY ----\n")

# ---------------------------
# (b) VIEW NUMBER OF IMAGES
# ---------------------------
print("CIFAR-10 Training Images:", x_train_cifar.shape[0])
print("CIFAR-10 Testing Images:", x_test_cifar.shape[0])

print("\nMNIST Training Images:", x_train_mnist.shape[0])
print("MNIST Testing Images:", x_test_mnist.shape[0])

# ---------------------------
# (c) PLOT SAMPLE IMAGES
# ---------------------------
plt.figure(figsize=(8,4))
for i in range(6):
    plt.subplot(2,3,i+1)
    plt.imshow(x_train_cifar[i])
    plt.title(f"CIFAR Label: {y_train_cifar[i][0]}")
    plt.axis('off')
plt.suptitle("Sample CIFAR-10 Images")
plt.show()

plt.figure(figsize=(8,4))
for i in range(6):
    plt.subplot(2,3,i+1)
    plt.imshow(x_train_mnist[i], cmap='gray')
    plt.title(f"MNIST Label: {y_train_mnist[i]}")
    plt.axis('off')
plt.suptitle("Sample MNIST Images")
plt.show()

# ---------------------------
# (d) NORMALIZATION
# ---------------------------
x_train_cifar = x_train_cifar.astype("float32") / 255
x_test_cifar = x_test_cifar.astype("float32") / 255

x_train_mnist = x_train_mnist.astype("float32") / 255
x_test_mnist = x_test_mnist.astype("float32") / 255

# Reshape MNIST to match ANN/CNN input
x_train_mnist_flat = x_train_mnist.reshape(len(x_train_mnist), -1)
x_test_mnist_flat = x_test_mnist.reshape(len(x_test_mnist), -1)

# Flatten CIFAR-10 for ANN
x_train_cifar_flat = x_train_cifar.reshape(len(x_train_cifar), -1)
x_test_cifar_flat = x_test_cifar.reshape(len(x_test_cifar), -1)

# ---------------------------
# (e) SIMPLE ANN MODEL
# ---------------------------
def build_ann(input_shape, num_classes):
    ann = models.Sequential([
        layers.Dense(256, activation='relu', input_shape=[input_shape]),
        layers.Dense(128, activation='relu'),
        layers.Dense(num_classes, activation='softmax')
    ])
    ann.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return ann

# Train ANN for MNIST
ann_mnist = build_ann(x_train_mnist_flat.shape[1], 10)
history_ann_mnist = ann_mnist.fit(x_train_mnist_flat, y_train_mnist, epochs=5, validation_data=(x_test_mnist_flat, y_test_mnist))

# Train ANN for CIFAR-10
ann_cifar = build_ann(x_train_cifar_flat.shape[1], 10)
history_ann_cifar = ann_cifar.fit(x_train_cifar_flat, y_train_cifar, epochs=5, validation_data=(x_test_cifar_flat, y_test_cifar))

# ---------------------------
# (f) CNN MODEL
# ---------------------------
def build_cnn(input_shape):
    cnn = models.Sequential([
        layers.Conv2D(32, (3,3), activation='relu', input_shape=input_shape),
        layers.MaxPooling2D(2,2),
        
        layers.Conv2D(64, (3,3), activation='relu'),
        layers.MaxPooling2D(2,2),
        
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dense(10, activation='softmax')
    ])
    cnn.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return cnn

# Train CNN for MNIST
x_train_mnist_cnn = x_train_mnist.reshape(-1,28,28,1)
x_test_mnist_cnn = x_test_mnist.reshape(-1,28,28,1)
cnn_mnist = build_cnn((28,28,1))
history_cnn_mnist = cnn_mnist.fit(x_train_mnist_cnn, y_train_mnist, epochs=5, validation_data=(x_test_mnist_cnn, y_test_mnist))

# Train CNN for CIFAR-10
cnn_cifar = build_cnn((32,32,3))
history_cnn_cifar = cnn_cifar.fit(x_train_cifar, y_train_cifar, epochs=5, validation_data=(x_test_cifar, y_test_cifar))

# ---------------------------
# (g) DISPLAY ACCURACY
# ---------------------------
print("\n===== FINAL ACCURACY RESULTS =====")

print("\nMNIST ANN Accuracy:")
print("Train:", history_ann_mnist.history['accuracy'][-1])
print("Test:", history_ann_mnist.history['val_accuracy'][-1])

print("\nCIFAR-10 ANN Accuracy:")
print("Train:", history_ann_cifar.history['accuracy'][-1])
print("Test:", history_ann_cifar.history['val_accuracy'][-1])

print("\nMNIST CNN Accuracy:")
print("Train:", history_cnn_mnist.history['accuracy'][-1])
print("Test:", history_cnn_mnist.history['val_accuracy'][-1])

print("\nCIFAR-10 CNN Accuracy:")
print("Train:", history_cnn_cifar.history['accuracy'][-1])
print("Test:", history_cnn_cifar.history['val_accuracy'][-1])
