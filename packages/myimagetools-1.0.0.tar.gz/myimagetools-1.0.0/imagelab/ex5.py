# -----------------------------
# IMPORT LIBRARIES
# -----------------------------
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
import numpy as np
from tensorflow.keras import layers, models

# -----------------------------
# (a) LOAD DATASET
# -----------------------------
train_dir = "/content/fruits-360/Training"   # <-- change if needed
test_dir = "/content/fruits-360/Test"

img_size = (150,150)
batch = 32

# Without Augmentation (original dataset)
train_datagen = ImageDataGenerator()
test_datagen = ImageDataGenerator()

train_data = train_datagen.flow_from_directory(
    train_dir, target_size=img_size, batch_size=batch, class_mode='categorical'
)
test_data = test_datagen.flow_from_directory(
    test_dir, target_size=img_size, batch_size=batch, class_mode='categorical'
)

# -----------------------------
# (b) PRINT NUMBER OF IMAGES
# -----------------------------
print("Training images:", train_data.samples)
print("Testing images:", test_data.samples)

# -----------------------------
# (c) PLOT SAMPLE IMAGES
# -----------------------------
x, y = next(train_data)
plt.figure(figsize=(7,7))
for i in range(9):
    plt.subplot(3,3,i+1)
    plt.imshow(x[i].astype("uint8"))
    plt.title(list(train_data.class_indices.keys())[np.argmax(y[i])])
    plt.axis("off")
plt.show()

# -----------------------------
# (d) IMAGE AUGMENTATION
# -----------------------------
aug_train_gen = ImageDataGenerator(
    rotation_range=20,
    horizontal_flip=True,
    vertical_flip=True,
    zoom_range=0.2,
    width_shift_range=0.1,
    height_shift_range=0.1
)

aug_train_data = aug_train_gen.flow_from_directory(
    train_dir, target_size=img_size, batch_size=batch, class_mode='categorical'
)

# -----------------------------
# (e) SHOW NUMBER OF IMAGES AFTER AUGMENTATION
# -----------------------------
print("Training images after augmentation:", aug_train_data.samples)

# -----------------------------
# (f) NORMALIZATION
# -----------------------------
norm_gen = ImageDataGenerator(rescale=1./255)

train_norm = norm_gen.flow_from_directory(
    train_dir, target_size=img_size, batch_size=batch, class_mode='categorical'
)
test_norm = norm_gen.flow_from_directory(
    test_dir, target_size=img_size, batch_size=batch, class_mode='categorical'
)

# -----------------------------
# (g) BUILD CNN BEFORE AUGMENTATION
# -----------------------------
def build_model(num_classes):
    model = models.Sequential([
        layers.Conv2D(32,(3,3),activation='relu',input_shape=(150,150,3)),
        layers.MaxPooling2D(2,2),
        layers.Conv2D(64,(3,3),activation='relu'),
        layers.MaxPooling2D(2,2),
        layers.Conv2D(128,(3,3),activation='relu'),
        layers.MaxPooling2D(2,2),
        layers.Flatten(),
        layers.Dense(128,activation='relu'),
        layers.Dense(num_classes,activation='softmax')
    ])
    
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

num_classes = len(train_data.class_indices)

model_before = build_model(num_classes)

history_before = model_before.fit(
    train_norm, epochs=5, validation_data=test_norm
)

# -----------------------------
# (h) SHOW TRAINING & TEST ACCURACY BEFORE AUG
# -----------------------------
print("\nAccuracy before augmentation:")
print("Train:", history_before.history['accuracy'][-1])
print("Test:", history_before.history['val_accuracy'][-1])

# -----------------------------
# (i) BUILD CNN AFTER AUGMENTATION (same model)
# -----------------------------
model_after = build_model(num_classes)

history_after = model_after.fit(
    aug_train_data, epochs=5, validation_data=test_norm
)

# -----------------------------
# (j) SHOW TRAINING & TEST ACCURACY AFTER AUG
# -----------------------------
print("\nAccuracy after augmentation:")
print("Train:", history_after.history['accuracy'][-1])
print("Test:", history_after.history['val_accuracy'][-1])

# -----------------------------
# (k) COMPARE RESULTS
# -----------------------------
print("\n------- COMPARISON -------")
print(f"Training Accuracy Before: {history_before.history['accuracy'][-1]:.4f}")
print(f"Testing Accuracy Before: {history_before.history['val_accuracy'][-1]:.4f}")
print(f"Training Accuracy After: {history_after.history['accuracy'][-1]:.4f}")
print(f"Testing Accuracy After: {history_after.history['val_accuracy'][-1]:.4f}")

# -----------------------------
# (l) PLOT ACCURACY CURVES
# -----------------------------
plt.figure(figsize=(10,5))
plt.plot(history_before.history['val_accuracy'], label="Without Augmentation")
plt.plot(history_after.history['val_accuracy'], label="With Augmentation")
plt.xlabel("Epochs")
plt.ylabel("Validation Accuracy")
plt.title("Accuracy Comparison Before and After Augmentation")
plt.legend()
plt.show()
