# --------------------------------------
# IMPORT REQUIRED LIBRARIES
# --------------------------------------
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import numpy as np

# --------------------------------------
# (a) LOAD THE DATASET
# --------------------------------------
train_path = "imagenet/train"
test_path = "imagenet/test"
img_size = (224, 224)
batch = 32

train_gen = ImageDataGenerator()
test_gen = ImageDataGenerator()

train_data = train_gen.flow_from_directory(train_path, target_size=img_size, batch_size=batch, class_mode='categorical')
test_data = test_gen.flow_from_directory(test_path, target_size=img_size, batch_size=batch, class_mode='categorical')

# --------------------------------------
# (b) SHOW NUMBER OF TRAIN & TEST IMAGES
# --------------------------------------
print("\nTraining Images:", train_data.samples)
print("Testing Images:", test_data.samples)

# --------------------------------------
# (c) DISPLAY SAMPLE IMAGES
# --------------------------------------
x, y = next(train_data)
plt.figure(figsize=(6,6))
for i in range(9):
    plt.subplot(3,3,i+1)
    plt.imshow(x[i].astype("uint8"))
    plt.axis("off")
plt.suptitle("Sample Images from ImageNet Subset")
plt.show()

# --------------------------------------
# (d) IMAGE AUGMENTATION
# --------------------------------------
augmented_gen = ImageDataGenerator(
    rotation_range=20,
    horizontal_flip=True,
    vertical_flip=True,
    contrast_stretching=True,
    brightness_range=[0.5, 1.5]
)

aug_train_data = augmented_gen.flow_from_directory(train_path, target_size=img_size, batch_size=batch, class_mode='categorical')

# --------------------------------------
# (e) SHOW NUMBER OF IMAGES AFTER AUGMENTATION
# --------------------------------------
print("\nTraining Images After Augmentation:", aug_train_data.samples)

# --------------------------------------
# (f) NORMALIZATION
# --------------------------------------
norm_gen = ImageDataGenerator(rescale=1./255)
train_norm = norm_gen.flow_from_directory(train_path, target_size=img_size, batch_size=batch, class_mode='categorical')
test_norm = norm_gen.flow_from_directory(test_path, target_size=img_size, batch_size=batch, class_mode='categorical')

# --------------------------------------
# (g) BUILD CNN MODEL
# --------------------------------------
def build_cnn(num_classes):
    model = models.Sequential([
        layers.Conv2D(32, (3,3), activation='relu', input_shape=(224,224,3)),
        layers.MaxPooling2D(2,2),

        layers.Conv2D(64, (3,3), activation='relu'),
        layers.MaxPooling2D(2,2),

        layers.Conv2D(128, (3,3), activation='relu'),
        layers.MaxPooling2D(2,2),

        layers.Flatten(),
        layers.Dense(256, activation='relu'),
        layers.Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    return model

num_classes = train_data.num_classes
cnn_model = build_cnn(num_classes)

# Train before augmentation
history_before = cnn_model.fit(train_norm, epochs=5, validation_data=test_norm)

# --------------------------------------
# (h) SHOW TRAINING & TEST ACCURACY BEFORE AUGMENTATION
# --------------------------------------
print("\nCNN Accuracy BEFORE Augmentation:")
print("Training Accuracy:", history_before.history['accuracy'][-1])
print("Testing Accuracy:", history_before.history['val_accuracy'][-1])

# --------------------------------------
# (i) BUILD AN R-CNN MODEL (Transfer Learning)
# --------------------------------------
base_model = tf.keras.applications.ResNet50(weights='imagenet', include_top=False, input_shape=(224,224,3))
base_model.trainable = False  # Freeze pre-trained weights

rcnn_model = models.Sequential([
    base_model,
    layers.GlobalAveragePooling2D(),
    layers.Dense(256, activation='relu'),
    layers.Dense(num_classes, activation='softmax')
])

rcnn_model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

# Train WITH AUGMENTATION
history_after = rcnn_model.fit(aug_train_data, epochs=5, validation_data=test_norm)

# --------------------------------------
# (j) SHOW ACCURACY AFTER AUGMENTATION
# --------------------------------------
print("\nR-CNN Accuracy AFTER Augmentation:")
print("Training Accuracy:", history_after.history['accuracy'][-1])
print("Testing Accuracy:", history_after.history['val_accuracy'][-1])

# --------------------------------------
# (k) COMPARE RESULTS
# --------------------------------------
print("\n------------- ACCURACY COMPARISON ----------------")
print(f"Before Augmentation:\nTrain: {history_before.history['accuracy'][-1]:.4f}, Test: {history_before.history['val_accuracy'][-1]:.4f}")
print(f"After Augmentation (R-CNN):\nTrain: {history_after.history['accuracy'][-1]:.4f}, Test: {history_after.history['val_accuracy'][-1]:.4f}")
