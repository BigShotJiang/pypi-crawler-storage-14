from setuptools import setup, find_packages

setup(
    name="myimagetools",          
    version="1.0.0",
    description="Image Lab",
    author="Batman",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
        "seaborn",
        "tensorflow",
        "keras",
        "pycm",
    ],
    python_requires=">=3.7"
)
