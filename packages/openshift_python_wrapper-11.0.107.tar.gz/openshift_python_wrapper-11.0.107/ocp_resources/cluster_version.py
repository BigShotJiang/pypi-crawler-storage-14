from ocp_resources.resource import Resource


class ClusterVersion(Resource):
    api_group = Resource.ApiGroup.CONFIG_OPENSHIFT_IO
