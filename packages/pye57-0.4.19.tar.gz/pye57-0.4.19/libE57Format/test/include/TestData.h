#pragma once
// libE57Format testing Copyright © 2022 Andy Maloney <asmaloney@gmail.com>
// SPDX-License-Identifier: MIT

#include <string>

namespace TestData
{
   bool Exists();

   const std::string &Path();
}
