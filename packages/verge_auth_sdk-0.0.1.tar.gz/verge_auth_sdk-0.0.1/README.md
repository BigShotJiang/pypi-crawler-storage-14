🔐 Verge Auth SDK (verge_auth_sdk)
Plug-and-Play Central Authentication for FastAPI & Microservices

Verge Auth SDK is a lightweight, production-ready authentication middleware that allows any FastAPI or microservice application to integrate with a central authentication server using one single line of code.

It is built for teams developing microservices, SaaS products, and enterprise-grade systems where authentication must be centralized, secure, and reusable across multiple services.

⚠️ Note:
This SDK requires a running Verge Auth Server.
This package only provides the client-side authentication layer for your microservices.

🔧 Environment Configuration

Add these required environment variables to your service's .env file:

Auth Server Endpoints
AUTH_INTROSPECT_URL=https://auth.yourdomain.com/introspect
AUTH_LOGIN_URL=https://auth.yourdomain.com/auth/login

SDK Credentials
Free Tier
VERGE_CLIENT_ID=your_company_name
VERGE_CLIENT_SECRET=free-tier

Paid Tier (provided by Verge Infosoft)
# VERGE_CLIENT_ID=client_abc123
# VERGE_CLIENT_SECRET=secret_xyz789


⚠️ Free-tier users must keep:
VERGE_CLIENT_SECRET=free-tier

Optional (Future Integrations)
DATABASE_URL=your_database_url

✨ Features
Feature	Description
✅ Single-line integration	Add add_central_auth(app) and you're done
✅ Centralized authentication	All microservices use a single auth server
✅ Token introspection	Every request is validated securely
✅ RBAC	Role-based access control support
✅ Cookie + Header JWT support	Works for browser + API clients
✅ Automatic redirects	HTML requests are redirected to login
✅ Context injection	request.state.user & request.state.roles
🧠 How It Works

User sends a request to your microservice

Verge Auth SDK intercepts it

The SDK sends the token to the central auth server

Auth server validates session, roles, and tenant

SDK allows or denies the request

+-------------------+
|   Your Service    |
+-------------------+
         |
         | Validate Token
         v
+-------------------+
| Verge Auth Server |
+-------------------+

📦 Installation
From PyPI
pip install verge_auth_sdk

From GitHub
pip install git+https://github.com/verge-infosoft/verge-auth.git

⚡ Quick Start
from fastapi import FastAPI
from verge_auth_sdk import add_central_auth

app = FastAPI()

# Enable centralized authentication
add_central_auth(app)


That’s it! 🎉
Your service is now fully protected with centralized authentication.

🔐 Token Handling

The middleware automatically:

Extracts Authorization: Bearer <token>

Falls back to access_token cookie for browser clients

Redirects to login when unauthenticated (HTML only)

Validates tokens through the central auth server

🧑‍💼 Role-Based Access

After introspection, the SDK injects:

request.state.user     # User object
request.state.roles    # List of roles


Use this to build fine-grained permissions.

Role Flow
Role	Behavior
Super Admin	Full access, including admin dashboard
Admin	Full access except super-admin privileges
User	Redirected to application UI
🧱 Architecture
Client → Microservice → Verge Auth SDK → Auth Server
                                ↓
                           Allow / Reject

🚀 Roadmap

✔ FastAPI Support

🔜 Django SDK

🔜 Flask SDK

🔜 Node.js SDK

🔜 Go SDK

🔜 Developer Dashboard

🔜 API Gateway Reverse Proxy Mode

📌 License

MIT License © 2025 Verge Infosoft

👨‍💻 Maintained By

Verge Infosoft
📧 contactus@vergeinfosoft.com

🌐 https://vergeinfosoft.com