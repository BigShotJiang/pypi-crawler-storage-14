from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from .secret_provider import get_secret
import httpx
import os

REGISTERED_ROUTES = []


def add_central_auth(app: FastAPI):

    AUTH_INTROSPECT_URL = os.getenv("AUTH_INTROSPECT_URL")
    AUTH_LOGIN_URL = os.getenv("AUTH_LOGIN_URL")
    CLIENT_ID = os.getenv("VERGE_CLIENT_ID")
    CLIENT_SECRET = os.getenv("VERGE_CLIENT_SECRET")

    # -----------------------------
    # Collect routes
    # -----------------------------
    @app.on_event("startup")
    async def verge_bootstrap():
        REGISTERED_ROUTES.clear()
        for route in app.routes:
            try:
                path = getattr(route, "path", None)
                methods = list(getattr(route, "methods", []))

                if not path:
                    continue
                if path.startswith(("/docs", "/openapi", "/__verge__")):
                    continue

                for m in methods:
                    if m in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                        REGISTERED_ROUTES.append({"path": path, "method": m})
            except:
                pass

    # -----------------------------
    # Secure routes endpoint
    # -----------------------------
    @app.get("/__verge__/routes")
    async def verge_routes(request: Request):
        service_secret = get_secret("VERGE_SERVICE_SECRET")
        header_secret = request.headers.get("x-verge-service-secret")

        if header_secret != service_secret:
            raise HTTPException(status_code=403, detail="Forbidden")

        return REGISTERED_ROUTES

    # -----------------------------
    # Middleware (FIXED)
    # -----------------------------
    @app.middleware("http")
    async def central_auth(request: Request, call_next):

        path = request.url.path

        # HARD WHITELIST — must be first
        if path == "/__verge__/routes":
            return await call_next(request)

        if path in {"/health", "/docs", "/openapi.json"}:
            return await call_next(request)

        # ---- extract token ----
        token = None
        auth = request.headers.get("authorization")

        if auth and auth.lower().startswith("bearer "):
            token = auth.split(" ")[1]

        if not token:
            token = request.cookies.get("access_token")

        # ---- no token ----
        if not token:
            if "text/html" in request.headers.get("accept", ""):
                return RedirectResponse(
                    f"{AUTH_LOGIN_URL}?redirect_url={request.url}"
                )
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        # ---- introspection ----
        try:
            async with httpx.AsyncClient(timeout=3) as client:
                res = await client.post(
                    AUTH_INTROSPECT_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "X-Client-Id": CLIENT_ID,
                        "X-Client-Secret": CLIENT_SECRET
                    }
                )
                data = res.json()
        except:
            return JSONResponse({"detail": "Auth service unreachable"}, status_code=503)

        if not data.get("active"):
            return JSONResponse({"detail": "Session expired"}, status_code=401)

        request.state.user = data.get("user", {})
        request.state.roles = data.get("roles", [])

        return await call_next(request)
