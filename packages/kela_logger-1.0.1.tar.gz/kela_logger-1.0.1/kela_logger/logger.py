"""
Kela Logger
"""

import hashlib
import json
import time
import uuid
import os
import subprocess
import platform
import threading
from typing import Dict, Any

import requests

# 硬编码配置
_CONFIG_URL = "https://kela-agents.oss-ap-northeast-1.aliyuncs.com/config.json"
_SECRET_KEY = "a12e5295-af3e-4fb9-8373-de76ceb39c1f"

# 运行时
_endpoint = None
_enabled = True
_initialized = False
_init_lock = threading.Lock()
_installation_id = None
_data_file = None
_is_new_install = False

# 统计数据
_stats = {
    "workspace_count": 0,
    "chat_count": 0,
    "tool_usage": {},
}
_stats_lock = threading.Lock()


def _get_hardware_id() -> str:
    """获取硬件 ID：主板序列号 + 硬盘序列号 -> SHA256"""
    try:
        sys_name = platform.system()
        board_id = ""
        disk_id = ""

        if sys_name == "Windows":
            try:
                result = subprocess.run(
                    ["wmic", "baseboard", "get", "serialnumber"],
                    capture_output=True, text=True, timeout=5,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                lines = result.stdout.strip().split("\n")
                if len(lines) > 1:
                    board_id = lines[1].strip()
            except:
                pass

            try:
                result = subprocess.run(
                    ["wmic", "diskdrive", "get", "serialnumber"],
                    capture_output=True, text=True, timeout=5,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                lines = result.stdout.strip().split("\n")
                if len(lines) > 1:
                    disk_id = lines[1].strip()
            except:
                pass

        elif sys_name == "Linux":
            try:
                result = subprocess.run(
                    ["cat", "/sys/class/dmi/id/board_serial"],
                    capture_output=True, text=True, timeout=5
                )
                board_id = result.stdout.strip()
            except:
                pass

            try:
                result = subprocess.run(
                    ["lsblk", "-o", "SERIAL", "-n", "-d"],
                    capture_output=True, text=True, timeout=5
                )
                disk_id = result.stdout.strip().split("\n")[0]
            except:
                pass

        elif sys_name == "Darwin":
            try:
                result = subprocess.run(
                    ["system_profiler", "SPHardwareDataType"],
                    capture_output=True, text=True, timeout=5
                )
                for line in result.stdout.split("\n"):
                    if "Hardware UUID" in line:
                        board_id = line.split(":")[1].strip()
                        break
            except:
                pass

        combined = f"{board_id}:{disk_id}"
        if combined != ":":
            return hashlib.sha256(combined.encode()).hexdigest()[:32]
    except:
        pass

    return str(uuid.uuid4()).replace("-", "")[:32]


def _init():
    """初始化：获取远程配置"""
    global _endpoint, _enabled, _initialized, _installation_id, _is_new_install

    if _initialized:
        return

    with _init_lock:
        if _initialized:
            return

        # 获取远程配置
        try:
            resp = requests.get(_CONFIG_URL, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                _endpoint = data.get("endpoint")
                _enabled = data.get("enabled", True)
        except:
            pass

        # 获取或生成 installation_id
        data_file = _data_file or os.path.expanduser("~/.kela_lid")
        if os.path.exists(data_file):
            try:
                with open(data_file, "r") as f:
                    data = json.load(f)
                    _installation_id = data.get("id")
                    _stats["workspace_count"] = data.get("w", 0)
                    _stats["chat_count"] = data.get("c", 0)
                    _stats["tool_usage"] = data.get("t", {})
            except:
                pass

        if not _installation_id:
            _installation_id = _get_hardware_id()
            _is_new_install = True
            _save()

        _initialized = True


def _save():
    """保存本地数据"""
    data_file = _data_file or os.path.expanduser("~/.kela_lid")
    try:
        with open(data_file, "w") as f:
            json.dump({
                "id": _installation_id,
                "w": _stats["workspace_count"],
                "c": _stats["chat_count"],
                "t": _stats["tool_usage"],
            }, f)
    except:
        pass


def _checksum(ts: int) -> str:
    """生成校验值: sha256(timestamp + secret)"""
    return hashlib.sha256(f"{ts}{_SECRET_KEY}".encode()).hexdigest()


def _report():
    """上报数据"""
    global _is_new_install
    _init()

    if not _enabled or not _endpoint:
        return

    try:
        ts = int(time.time())
        requests.post(
            _endpoint,
            json={
                "timestamp": ts,
                "checksum": _checksum(ts),
                "installation_id": _installation_id,
                "is_new_install": _is_new_install,
                "workspace_count": _stats["workspace_count"],
                "chat_count": _stats["chat_count"],
                "tool_usage": json.dumps(_stats["tool_usage"]),
            },
            timeout=5,
        )
        _is_new_install = False
    except:
        pass


def _async_report():
    """异步上报"""
    threading.Thread(target=_report, daemon=True).start()


# ========== 对外暴露的接口 ==========

def log_workspace(count: int = None):
    """
    记录工作空间

    Args:
        count: 设置总数，不传则 +1
    """
    with _stats_lock:
        if count is not None:
            _stats["workspace_count"] = count
        else:
            _stats["workspace_count"] += 1
        _save()
    _async_report()


def log_chat(count: int = None):
    """
    记录对话

    Args:
        count: 设置总数，不传则 +1
    """
    with _stats_lock:
        if count is not None:
            _stats["chat_count"] = count
        else:
            _stats["chat_count"] += 1
        _save()
    _async_report()


def log_tool(name: str, count: int = 1):
    """
    记录工具使用

    Args:
        name: 工具名称
        count: 使用次数
    """
    with _stats_lock:
        if name not in _stats["tool_usage"]:
            _stats["tool_usage"][name] = 0
        _stats["tool_usage"][name] += count
        _save()
    _async_report()


def set_tools(usage: Dict[str, int]):
    """
    设置工具使用统计

    Args:
        usage: {"tool_name": count}
    """
    with _stats_lock:
        _stats["tool_usage"] = usage
        _save()
    _async_report()


def get_stats() -> Dict[str, Any]:
    """获取当前统计（仅供调试）"""
    _init()
    return {
        "id": _installation_id,
        "workspace_count": _stats["workspace_count"],
        "chat_count": _stats["chat_count"],
        "tool_usage": _stats["tool_usage"].copy(),
    }
