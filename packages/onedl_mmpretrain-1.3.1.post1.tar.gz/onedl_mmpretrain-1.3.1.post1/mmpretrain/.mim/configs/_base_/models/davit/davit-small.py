model = dict(type='ImageClassifier',
             backbone=dict(type='DaViT',
                           arch='small',
                           out_indices=(3, ),
                           drop_path_rate=0.2),
             neck=dict(type='GlobalAveragePooling'),
             head=dict(
                 type='LinearClsHead',
                 num_classes=1000,
                 in_channels=768,
                 loss=dict(type='LabelSmoothLoss',
                           label_smooth_val=0.1,
                           mode='original'),
             ),
             train_cfg=dict(augments=[
                 dict(type='Mixup', alpha=0.8),
                 dict(type='CutMix', alpha=1.0)
             ]))
