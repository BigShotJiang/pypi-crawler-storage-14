from .role_repository import RoleRepository
from .permission_repository import PermissionRepository

__all__ = ["RoleRepository", "PermissionRepository"]
