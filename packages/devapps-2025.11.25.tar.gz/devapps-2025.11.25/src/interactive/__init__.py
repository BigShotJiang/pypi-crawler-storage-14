preview_args_sep = '\x01'
preview_cmd_flag = 'p'
fzf_forkpty_flag = 'forkfzf'
cb_args_sep = ':'
# preview_args_sep = 'Z'
execute_args_sep = '\x02'

item_delimiter = '\u2001'
nil = '\x01'
