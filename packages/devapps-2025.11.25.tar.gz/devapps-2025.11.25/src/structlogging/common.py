proc_modules = []


selected_by_name_processors = {}

transient_data_key = '_transient'
