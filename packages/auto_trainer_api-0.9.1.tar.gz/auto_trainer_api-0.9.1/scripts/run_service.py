from autotrainer.api import run_server

if __name__ == '__main__':
    # Starts a simple application in lieu of a real auto-trainer application to publish heartbeat messages and receive
    # command requests for development and testing.
    run_server()
