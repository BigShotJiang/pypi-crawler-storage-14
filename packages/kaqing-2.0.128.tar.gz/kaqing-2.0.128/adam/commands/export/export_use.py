from adam.commands.command import Command
from adam.commands.export.utils_export import ExportDatabases, Exporter, display_export_session
from adam.repl_state import ReplState, RequiredState
from adam.utils import lines_to_tabular, log, log2
from adam.utils_athena import Athena

class ExportUse(Command):
    COMMAND = '&use'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ExportUse, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ExportUse.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not args:
            if state.in_repl:
                log2('Specify database to use.')
            else:
                log2('* database is missing.')

                Command.display_help()

            return 'command-missing'

        state.export_session = args[0]
        Athena.clear_cache()

        display_export_session(state.export_session)

        return state

    def completion(self, state: ReplState):
        if state.sts:
            # warm up the caches
            ExportDatabases.database_names()

            return super().completion(state, {n: None for n in ExportDatabases.database_names()})

        return {}

    def help(self, _: ReplState):
        return f'{ExportUse.COMMAND} <export db name>\t use Export Database'