"""
Coordinator Infrastructure Module
Infrastructure components for the coordinator.
"""

from .auto_scaler import AutoScaler, get_auto_scaler

__all__ = [
    'AutoScaler',
    'get_auto_scaler'
]