"""
EmpoorioLM API Endpoints
Endpoints REST para el servicio EmpoorioLM.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional, AsyncGenerator
import logging
import json

from ...empoorio_lm.service import EmpoorioLMService
from ...auth.dependencies import get_current_user
from typing import Dict

logger = logging.getLogger(__name__)

# Crear router
router = APIRouter(prefix="/empoorio-lm", tags=["empoorio-lm"])

# Modelos Pydantic para requests/responses
class GenerationRequest(BaseModel):
    """Request para generación de texto."""
    prompt: str = Field(..., description="Texto de entrada para generación")
    max_tokens: int = Field(100, ge=1, le=1000, description="Máximo número de tokens a generar")
    temperature: float = Field(1.0, ge=0.0, le=2.0, description="Temperatura de sampling")
    top_p: float = Field(1.0, ge=0.0, le=1.0, description="Top-p sampling")
    top_k: int = Field(50, ge=1, le=100, description="Top-k sampling")
    repetition_penalty: float = Field(1.0, ge=0.0, le=2.0, description="Penalización de repetición")
    model_version: Optional[str] = Field(None, description="Versión específica del modelo")

class BatchGenerationRequest(BaseModel):
    """Request para generación por lotes."""
    requests: List[GenerationRequest] = Field(..., description="Lista de requests de generación")
    model_version: Optional[str] = Field(None, description="Versión específica del modelo para todos los requests")

class GenerationResponse(BaseModel):
    """Response de generación de texto."""
    request_id: str
    generated_text: str
    model_version: str
    tokens_generated: int
    processing_time: float
    metadata: Dict[str, Any] = Field(default_factory=dict)

class BatchGenerationResponse(BaseModel):
    """Response de generación por lotes."""
    batch_id: str
    status: str
    message: str

class VersionActivationRequest(BaseModel):
    """Request para activar versión."""
    version_id: str
    is_default: bool = False
    traffic_percentage: Optional[float] = Field(None, ge=0.0, le=1.0)

class ServiceStatusResponse(BaseModel):
    """Response de estado del servicio."""
    service_name: str
    is_initialized: bool
    is_running: bool
    uptime_seconds: float
    total_requests: int
    total_tokens_generated: int
    active_versions: Dict[str, Any]
    performance_metrics: Dict[str, Any]
    inference_stats: Dict[str, Any]
    model_cache_stats: Dict[str, Any]

class HealthResponse(BaseModel):
    """Response de health check."""
    status: str  # "healthy", "warning", "unhealthy"
    checks: Dict[str, Dict[str, Any]]

# Dependencia para obtener el servicio EmpoorioLM
def get_empoorio_lm_service() -> EmpoorioLMService:
    """Obtener instancia del servicio EmpoorioLM."""
    # En implementación real, esto vendría de un dependency injection container
    # o de una variable global inicializada en el startup del app
    from ...empoorio_lm.service import create_empoorio_lm_service
    return create_empoorio_lm_service()

@router.post("/generate", response_model=GenerationResponse)
async def generate_text(
    request: GenerationRequest,
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """
    Generar texto usando EmpoorioLM.

    - **prompt**: Texto de entrada
    - **max_tokens**: Máximo tokens a generar (1-1000)
    - **temperature**: Temperatura de sampling (0.0-2.0)
    - **top_p**: Top-p sampling (0.0-1.0)
    - **top_k**: Top-k sampling (1-100)
    - **model_version**: Versión específica del modelo (opcional)
    """
    try:
        # Preparar parámetros
        parameters = {
            "max_new_tokens": request.max_tokens,
            "temperature": request.temperature,
            "top_p": request.top_p,
            "top_k": request.top_k,
            "repetition_penalty": request.repetition_penalty,
            "do_sample": request.temperature > 0.0
        }

        # Generar texto
        result = await service.generate_text(
            prompt=request.prompt,
            parameters=parameters,
            model_preference=request.model_version
        )

        if result is None:
            raise HTTPException(status_code=500, detail="Failed to generate text")

        return GenerationResponse(**result)

    except Exception as e:
        logger.error(f"Error generating text: {e}")
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")

@router.post("/generate/stream")
async def generate_text_stream(
    request: GenerationRequest,
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """
    Generar texto con streaming usando EmpoorioLM.

    Retorna un stream de texto generado en tiempo real.
    """
    try:
        # Preparar parámetros
        parameters = {
            "max_new_tokens": request.max_tokens,
            "temperature": request.temperature,
            "top_p": request.top_p,
            "top_k": request.top_k,
            "repetition_penalty": request.repetition_penalty,
            "do_sample": request.temperature > 0.0
        }

        # Iniciar streaming
        stream_generator = await service.stream_generate_text(
            prompt=request.prompt,
            parameters=parameters,
            model_preference=request.model_version
        )

        if stream_generator is None:
            raise HTTPException(status_code=500, detail="Failed to start streaming")

        # Crear response de streaming
        async def generate_stream():
            try:
                async for chunk in stream_generator:
                    # Enviar chunk como JSON line
                    yield f"data: {json.dumps({'chunk': chunk})}\n\n"
            except Exception as e:
                logger.error(f"Error in streaming: {e}")
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
            }
        )

    except Exception as e:
        logger.error(f"Error starting stream: {e}")
        raise HTTPException(status_code=500, detail=f"Streaming failed: {str(e)}")

@router.post("/generate/batch", response_model=BatchGenerationResponse)
async def generate_text_batch(
    request: BatchGenerationRequest,
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """
    Generar texto por lotes usando EmpoorioLM.

    - **requests**: Lista de requests de generación
    - **model_version**: Versión específica del modelo para todos los requests (opcional)
    """
    try:
        # Validar límites
        if len(request.requests) > 50:  # Límite arbitrario
            raise HTTPException(status_code=400, detail="Too many requests in batch (max 50)")

        # Preparar requests para batch
        batch_requests = []
        for req in request.requests:
            parameters = {
                "max_new_tokens": req.max_tokens,
                "temperature": req.temperature,
                "top_p": req.top_p,
                "top_k": req.top_k,
                "repetition_penalty": req.repetition_penalty,
                "do_sample": req.temperature > 0.0
            }
            batch_requests.append((req.prompt, parameters))

        # Enviar batch
        batch_id = await service.generate_batch(
            requests=batch_requests,
            model_preference=request.model_version
        )

        if batch_id is None:
            raise HTTPException(status_code=500, detail="Failed to submit batch")

        return BatchGenerationResponse(
            batch_id=batch_id,
            status="submitted",
            message=f"Batch submitted successfully with {len(request.requests)} requests"
        )

    except Exception as e:
        logger.error(f"Error submitting batch: {e}")
        raise HTTPException(status_code=500, detail=f"Batch submission failed: {str(e)}")

@router.get("/batch/{batch_id}")
async def get_batch_status(
    batch_id: str,
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """
    Obtener estado de un batch.

    - **batch_id**: ID del batch
    """
    # Obtener estado real del servicio
    status_data = service.get_batch_status(batch_id)
    
    if status_data.get("status") == "not_found":
        raise HTTPException(status_code=404, detail=f"Batch {batch_id} not found")

    return status_data

@router.post("/versions/activate")
async def activate_model_version(
    request: VersionActivationRequest,
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """
    Activar una versión del modelo.

    - **version_id**: ID de la versión a activar
    - **is_default**: Si debe ser la versión por defecto
    - **traffic_percentage**: Porcentaje de tráfico (0.0-1.0)
    """
    try:
        success = await service.activate_model_version(
            version_id=request.version_id,
            is_default=request.is_default,
            traffic_percentage=request.traffic_percentage
        )

        if not success:
            raise HTTPException(status_code=400, detail="Failed to activate version")

        return {
            "success": True,
            "message": f"Version {request.version_id} activated successfully",
            "is_default": request.is_default,
            "traffic_percentage": request.traffic_percentage
        }

    except Exception as e:
        logger.error(f"Error activating version: {e}")
        raise HTTPException(status_code=500, detail=f"Version activation failed: {str(e)}")

@router.delete("/versions/{version_id}")
async def deactivate_model_version(
    version_id: str,
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """
    Desactivar una versión del modelo.

    - **version_id**: ID de la versión a desactivar
    """
    try:
        success = await service.deactivate_model_version(version_id)

        if not success:
            raise HTTPException(status_code=404, detail="Version not found or failed to deactivate")

        return {
            "success": True,
            "message": f"Version {version_id} deactivated successfully"
        }

    except Exception as e:
        logger.error(f"Error deactivating version: {e}")
        raise HTTPException(status_code=500, detail=f"Version deactivation failed: {str(e)}")

@router.get("/versions")
async def list_active_versions(
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Listar versiones activas del modelo."""
    try:
        status = service.get_service_status()
        return {
            "active_versions": status["active_versions"],
            "total_active": status["active_versions"].get("total_active", 0),
            "default_version": status["active_versions"].get("default_version")
        }

    except Exception as e:
        logger.error(f"Error listing versions: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list versions: {str(e)}")

@router.get("/status", response_model=ServiceStatusResponse)
async def get_service_status(
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Obtener estado completo del servicio EmpoorioLM."""
    try:
        return ServiceStatusResponse(**service.get_service_status())

    except Exception as e:
        logger.error(f"Error getting service status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get service status: {str(e)}")

@router.get("/health", response_model=HealthResponse)
async def get_service_health(
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Obtener estado de salud del servicio EmpoorioLM."""
    try:
        return HealthResponse(**service.get_service_health())

    except Exception as e:
        logger.error(f"Error getting service health: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get service health: {str(e)}")

@router.get("/performance")
async def get_performance_report(
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Obtener reporte de rendimiento del servicio."""
    try:
        return service.get_performance_report()

    except Exception as e:
        logger.error(f"Error getting performance report: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get performance report: {str(e)}")

@router.get("/recommendations")
async def get_optimization_recommendations(
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Obtener recomendaciones de optimización."""
    try:
        return {
            "recommendations": service.get_optimization_recommendations()
        }

    except Exception as e:
        logger.error(f"Error getting recommendations: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get recommendations: {str(e)}")

@router.get("/models")
async def list_available_models(
    current_user: Dict = Depends(get_current_user),
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Listar modelos disponibles (incluyendo versiones)."""
    try:
        # En implementación real, esto debería venir del version manager
        # Por ahora, retornar información básica
        status = service.get_service_status()
        return {
            "available_models": ["EmpoorioLM"],
            "active_versions": status["active_versions"],
            "default_version": status["active_versions"].get("default_version")
        }

    except Exception as e:
        logger.error(f"Error listing models: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list models: {str(e)}")

# Endpoints administrativos (requieren permisos especiales)
@router.post("/admin/initialize")
async def initialize_service(
    current_user: Dict = Depends(get_current_user),  # En producción, verificar permisos admin
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Inicializar el servicio (solo admin)."""
    try:
        success = await service.initialize()
        if not success:
            raise HTTPException(status_code=500, detail="Service initialization failed")

        return {
            "success": True,
            "message": "Service initialized successfully"
        }

    except Exception as e:
        logger.error(f"Error initializing service: {e}")
        raise HTTPException(status_code=500, detail=f"Service initialization failed: {str(e)}")

@router.post("/admin/start")
async def start_service(
    current_user: Dict = Depends(get_current_user),  # En producción, verificar permisos admin
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Iniciar el servicio (solo admin)."""
    try:
        success = await service.start()
        if not success:
            raise HTTPException(status_code=500, detail="Service start failed")

        return {
            "success": True,
            "message": "Service started successfully"
        }

    except Exception as e:
        logger.error(f"Error starting service: {e}")
        raise HTTPException(status_code=500, detail=f"Service start failed: {str(e)}")

@router.post("/admin/stop")
async def stop_service(
    current_user: Dict = Depends(get_current_user),  # En producción, verificar permisos admin
    service: EmpoorioLMService = Depends(get_empoorio_lm_service)
):
    """Detener el servicio (solo admin)."""
    try:
        await service.stop()
        return {
            "success": True,
            "message": "Service stopped successfully"
        }

    except Exception as e:
        logger.error(f"Error stopping service: {e}")
        raise HTTPException(status_code=500, detail=f"Service stop failed: {str(e)}")