"""
API endpoints for notifications management.
Provides REST endpoints for managing user notification preferences, sending test notifications, and retrieving notification history.
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user
from ....notifications.service import NotificationService
from ....notifications.models import (
    NotificationType, NotificationPriority, NotificationStatus,
    UserNotificationPreferences, Notification, WebSocketEventType
)
from ....settings.service import SettingsService

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class NotificationPreferencesRequest(BaseModel):
    """Request model for updating notification preferences."""
    email_enabled: Optional[bool] = Field(None, description="Enable email notifications")
    push_enabled: Optional[bool] = Field(None, description="Enable push notifications")
    websocket_enabled: Optional[bool] = Field(None, description="Enable WebSocket notifications")
    realtime_enabled: Optional[bool] = Field(None, description="Enable real-time notifications")
    email_address: Optional[str] = Field(None, description="Email address for notifications")
    push_token: Optional[str] = Field(None, description="Push notification token (FCM/APNs)")
    websocket_subscriptions: Optional[List[str]] = Field(None, description="WebSocket event subscriptions")
    quiet_hours_start: Optional[str] = Field(None, description="Quiet hours start time (HH:MM)")
    quiet_hours_end: Optional[str] = Field(None, description="Quiet hours end time (HH:MM)")
    timezone: Optional[str] = Field(None, description="User timezone")

    @validator('quiet_hours_start', 'quiet_hours_end')
    def validate_time_format(cls, v):
        if v is not None:
            try:
                datetime.strptime(v, "%H:%M")
            except ValueError:
                raise ValueError('Time must be in HH:MM format')
        return v

    @validator('timezone')
    def validate_timezone(cls, v):
        if v is not None and v not in ["Europe/Madrid", "UTC", "America/New_York", "Asia/Tokyo"]:
            raise ValueError('Invalid timezone')
        return v


class NotificationPreferencesResponse(BaseModel):
    """Response model for notification preferences."""
    user_id: int
    email_enabled: bool
    push_enabled: bool
    websocket_enabled: bool
    realtime_enabled: bool
    email_address: Optional[str]
    push_token: Optional[str]
    websocket_subscriptions: List[str]
    quiet_hours_start: Optional[str]
    quiet_hours_end: Optional[str]
    timezone: str


class TestNotificationRequest(BaseModel):
    """Request model for sending test notifications."""
    type: str = Field(..., description="Type of notification to test")
    title: Optional[str] = Field(None, description="Custom title for test notification")
    body: Optional[str] = Field(None, description="Custom body for test notification")

    @validator('type')
    def validate_type(cls, v):
        if v not in ["push", "email", "both"]:
            raise ValueError('type must be "push", "email", or "both"')
        return v


class NotificationHistoryItem(BaseModel):
    """Response model for notification history item."""
    id: str
    type: str
    priority: str
    title: str
    body: str
    status: str
    sent_at: Optional[datetime]
    created_at: datetime
    error_message: Optional[str]


class NotificationHistoryResponse(BaseModel):
    """Response model for notification history."""
    notifications: List[NotificationHistoryItem]
    total: int
    page: int
    per_page: int


# Helper functions
def get_user_id_from_token(current_user: Dict) -> int:
    """Extract user ID from JWT token payload."""
    try:
        # Assuming user_id is stored in token sub field as integer
        return int(current_user.get('sub', '').split('_')[-1])
    except (ValueError, IndexError):
        raise HTTPException(status_code=400, detail="Invalid user ID in token")


def notification_to_history_item(notification: Notification) -> NotificationHistoryItem:
    """Convert Notification model to history item."""
    return NotificationHistoryItem(
        id=notification.id,
        type=notification.type.value,
        priority=notification.priority.value,
        title=notification.title,
        body=notification.body,
        status=notification.status.value,
        sent_at=notification.sent_at,
        created_at=notification.created_at,
        error_message=notification.error_message
    )


# API Endpoints
@router.get("/preferences", response_model=NotificationPreferencesResponse,
            summary="Obtener preferencias de notificación",
            description="""
            Obtiene las preferencias de notificación del usuario actual.

            **Incluye:**
            - Habilitación de emails y push notifications
            - Dirección de email y token push
            - Horas de silencio
            - Zona horaria

            **Códigos de respuesta:**
            - 200: Preferencias obtenidas exitosamente
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Preferencias de notificación obtenidas exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "user_id": 1,
                                "email_enabled": True,
                                "push_enabled": True,
                                "email_address": "user@example.com",
                                "push_token": None,
                                "quiet_hours_start": "22:00",
                                "quiet_hours_end": "08:00",
                                "timezone": "Europe/Madrid"
                            }
                        }
                    }
                },
                401: {
                    "description": "Usuario no autenticado",
                    "content": {
                        "application/json": {
                            "example": {"detail": "Not authenticated"}
                        }
                    }
                }
            })
async def get_notification_preferences(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's notification preferences.

    - Returns all notification settings
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize notification service
        settings_service = SettingsService()
        notification_service = NotificationService(settings_service)

        # Get user preferences
        preferences = await notification_service.get_user_preferences(user_id)

        return NotificationPreferencesResponse(
            user_id=preferences.user_id,
            email_enabled=preferences.email_enabled,
            push_enabled=preferences.push_enabled,
            websocket_enabled=preferences.websocket_enabled,
            realtime_enabled=preferences.realtime_enabled,
            email_address=preferences.email_address,
            push_token=preferences.push_token,
            websocket_subscriptions=preferences.websocket_subscriptions,
            quiet_hours_start=preferences.quiet_hours_start,
            quiet_hours_end=preferences.quiet_hours_end,
            timezone=preferences.timezone
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get notification preferences error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/preferences", response_model=NotificationPreferencesResponse,
            summary="Actualizar preferencias de notificación",
            description="""
            Actualiza las preferencias de notificación del usuario actual.

            **Campos opcionales:**
            - email_enabled: Habilitar notificaciones por email (boolean)
            - push_enabled: Habilitar notificaciones push (boolean)
            - email_address: Dirección de email
            - push_token: Token FCM/APNs para push notifications
            - quiet_hours_start: Inicio de horas de silencio (HH:MM)
            - quiet_hours_end: Fin de horas de silencio (HH:MM)
            - timezone: Zona horaria del usuario

            **Códigos de respuesta:**
            - 200: Preferencias actualizadas exitosamente
            - 400: Datos inválidos
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Preferencias de notificación actualizadas exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "user_id": 1,
                                "email_enabled": False,
                                "push_enabled": True,
                                "email_address": "newemail@example.com",
                                "push_token": "fcm_token_123",
                                "quiet_hours_start": "23:00",
                                "quiet_hours_end": "07:00",
                                "timezone": "UTC"
                            }
                        }
                    }
                },
                400: {
                    "description": "Datos inválidos",
                    "content": {
                        "application/json": {
                            "example": {"detail": "Invalid time format"}
                        }
                    }
                }
            })
async def update_notification_preferences(
    request: NotificationPreferencesRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Update notification preferences for current user.

    - Updates notification settings
    - Validates all input data
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize notification service
        settings_service = SettingsService()
        notification_service = NotificationService(settings_service)

        # Update preferences
        updated_preferences = await notification_service.update_user_preferences(
            user_id=user_id,
            email_enabled=request.email_enabled,
            push_enabled=request.push_enabled,
            websocket_enabled=request.websocket_enabled,
            realtime_enabled=request.realtime_enabled,
            email_address=request.email_address,
            push_token=request.push_token,
            websocket_subscriptions=request.websocket_subscriptions
        )

        # For now, we don't update quiet hours and timezone in the service
        # This would need to be extended in the NotificationService
        if request.quiet_hours_start is not None:
            updated_preferences.quiet_hours_start = request.quiet_hours_start
        if request.quiet_hours_end is not None:
            updated_preferences.quiet_hours_end = request.quiet_hours_end
        if request.timezone is not None:
            updated_preferences.timezone = request.timezone

        return NotificationPreferencesResponse(
            user_id=updated_preferences.user_id,
            email_enabled=updated_preferences.email_enabled,
            push_enabled=updated_preferences.push_enabled,
            websocket_enabled=updated_preferences.websocket_enabled,
            realtime_enabled=updated_preferences.realtime_enabled,
            email_address=updated_preferences.email_address,
            push_token=updated_preferences.push_token,
            websocket_subscriptions=updated_preferences.websocket_subscriptions,
            quiet_hours_start=updated_preferences.quiet_hours_start,
            quiet_hours_end=updated_preferences.quiet_hours_end,
            timezone=updated_preferences.timezone
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update notification preferences error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/test", response_model=Dict[str, Any],
             summary="Enviar notificación de prueba",
             description="""
             Envía una notificación de prueba al usuario actual.

             **Campos requeridos:**
             - type: Tipo de notificación ("push", "email", "both")

             **Campos opcionales:**
             - title: Título personalizado para la notificación de prueba
             - body: Cuerpo personalizado para la notificación de prueba

             **Códigos de respuesta:**
             - 200: Notificación de prueba enviada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 404: Usuario no encontrado
             - 500: Error interno del servidor
             """,
             responses={
                 200: {
                     "description": "Notificación de prueba enviada exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "success": True,
                                 "message": "Test notification sent successfully",
                                 "notification_id": "123e4567-e89b-12d3-a456-426614174000"
                             }
                         }
                     }
                 },
                 400: {
                     "description": "Datos inválidos",
                     "content": {
                         "application/json": {
                             "example": {"detail": "Invalid notification type"}
                         }
                     }
                 }
             })
async def send_test_notification(
    request: TestNotificationRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Send a test notification to current user.

    - Creates and sends a test notification
    - Supports push, email, or both
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize notification service
        settings_service = SettingsService()
        notification_service = NotificationService(settings_service)

        # Create test notification
        notification_type = NotificationType(request.type)

        title = request.title or f"Test {request.type.title()} Notification"
        body = request.body or f"This is a test {request.type} notification sent at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}."

        notification = notification_service.create_notification(
            user_id=user_id,
            title=title,
            body=body,
            notification_type=notification_type,
            priority=NotificationPriority.NORMAL
        )

        # Send notification
        success = await notification_service.send_notification(notification)

        if success:
            return {
                "success": True,
                "message": "Test notification sent successfully",
                "notification_id": notification.id
            }
        else:
            return {
                "success": False,
                "message": "Failed to send test notification",
                "notification_id": notification.id
            }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Send test notification error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/history", response_model=NotificationHistoryResponse,
            summary="Obtener historial de notificaciones",
            description="""
            Obtiene el historial de notificaciones del usuario actual.

            **Parámetros de consulta:**
            - page: Número de página (por defecto: 1)
            - per_page: Elementos por página (por defecto: 20, máximo: 100)

            **Códigos de respuesta:**
            - 200: Historial obtenido exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Historial de notificaciones obtenido exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "notifications": [
                                    {
                                        "id": "123e4567-e89b-12d3-a456-426614174000",
                                        "type": "push",
                                        "priority": "normal",
                                        "title": "Test Notification",
                                        "body": "This is a test notification",
                                        "status": "sent",
                                        "sent_at": "2023-11-10T23:34:24.032Z",
                                        "created_at": "2023-11-10T23:34:24.032Z",
                                        "error_message": None
                                    }
                                ],
                                "total": 1,
                                "page": 1,
                                "per_page": 20
                            }
                        }
                    }
                }
            })
async def get_notification_history(
    page: int = 1,
    per_page: int = 20,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get notification history for current user.

    - Returns paginated list of notifications
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Validate pagination parameters
        if page < 1:
            page = 1
        if per_page < 1 or per_page > 100:
            per_page = 20

        # For now, return empty history as we don't have persistence implemented
        # This would need to be implemented with a proper database storage
        notifications = []

        return NotificationHistoryResponse(
            notifications=notifications,
            total=0,
            page=page,
            per_page=per_page
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get notification history error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Nuevos endpoints para WebSocket

@router.post("/websocket/subscribe", response_model=Dict[str, Any],
             summary="Suscribirse a eventos WebSocket",
             description="""
             Permite a un usuario suscribirse a eventos específicos de WebSocket.

             **Campos requeridos:**
             - event_types: Lista de tipos de eventos a los que suscribirse

             **Eventos disponibles:**
             - ai_response: Respuestas de IA
             - task_completed: Tareas completadas
             - session_update: Actualizaciones de sesión
             - training_progress: Progreso de entrenamiento
             - system_alert: Alertas del sistema
             - user_message: Mensajes de usuario
             - node_status: Estado de nodos
             - reward_earned: Recompensas ganadas
             - marketplace_update: Actualizaciones del marketplace
             - federated_event: Eventos federados

             **Códigos de respuesta:**
             - 200: Suscripción exitosa
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def subscribe_websocket_events(
    event_types: List[str],
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Subscribe user to specific WebSocket events.

    - Updates user's WebSocket subscriptions
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize notification service
        settings_service = SettingsService()
        notification_service = NotificationService(settings_service)

        # Get current preferences
        preferences = await notification_service.get_user_preferences(user_id)

        # Subscribe to events
        for event_type in event_types:
            preferences.subscribe_to_websocket_event(event_type)

        # Update preferences
        await notification_service.update_user_preferences(
            user_id=user_id,
            websocket_subscriptions=preferences.websocket_subscriptions
        )

        return {
            "success": True,
            "message": f"Subscribed to events: {', '.join(event_types)}",
            "subscribed_events": preferences.websocket_subscriptions
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Subscribe WebSocket events error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/websocket/unsubscribe", response_model=Dict[str, Any],
             summary="Desuscribirse de eventos WebSocket",
             description="""
             Permite a un usuario desuscribirse de eventos específicos de WebSocket.

             **Campos requeridos:**
             - event_types: Lista de tipos de eventos de los que desuscribirse

             **Códigos de respuesta:**
             - 200: Desuscripción exitosa
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def unsubscribe_websocket_events(
    event_types: List[str],
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Unsubscribe user from specific WebSocket events.

    - Updates user's WebSocket subscriptions
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize notification service
        settings_service = SettingsService()
        notification_service = NotificationService(settings_service)

        # Get current preferences
        preferences = await notification_service.get_user_preferences(user_id)

        # Unsubscribe from events
        for event_type in event_types:
            preferences.unsubscribe_from_websocket_event(event_type)

        # Update preferences
        await notification_service.update_user_preferences(
            user_id=user_id,
            websocket_subscriptions=preferences.websocket_subscriptions
        )

        return {
            "success": True,
            "message": f"Unsubscribed from events: {', '.join(event_types)}",
            "subscribed_events": preferences.websocket_subscriptions
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unsubscribe WebSocket events error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/websocket/events", response_model=Dict[str, Any],
            summary="Obtener eventos WebSocket disponibles",
            description="""
            Obtiene la lista de eventos WebSocket disponibles para suscripción.

            **Códigos de respuesta:**
            - 200: Lista de eventos obtenida exitosamente
            - 401: Usuario no autenticado
            """)
async def get_available_websocket_events(
    current_user: Dict = Depends(get_current_user)
):
    """
    Get list of available WebSocket events for subscription.

    - Returns all available event types
    - Requires authentication
    """
    try:
        available_events = {
            "ai_response": "Respuestas de IA en tiempo real",
            "task_completed": "Notificaciones cuando se completan tareas",
            "session_update": "Actualizaciones del estado de sesiones federadas",
            "training_progress": "Progreso de rondas de entrenamiento",
            "system_alert": "Alertas y notificaciones del sistema",
            "user_message": "Mensajes de otros usuarios",
            "node_status": "Cambios en el estado de nodos",
            "reward_earned": "Recompensas ganadas",
            "marketplace_update": "Actualizaciones del marketplace de datos",
            "federated_event": "Eventos del sistema federado"
        }

        return {
            "events": available_events,
            "total": len(available_events)
        }

    except Exception as e:
        logger.error(f"Get available WebSocket events error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")