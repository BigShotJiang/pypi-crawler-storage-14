"""
API endpoints for model management and federated inference.
"""

import os
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from ...database.connection import get_db
from ...models.schemas import (
    ModelResponse, ModelCreate, ModelUpdate, APIResponse, PaginatedResponse
)
from ...models.base import Model
from ...services.model_service import model_service
from ...auth.dependencies import get_current_node, get_current_admin
from ...core.exceptions import CoordinatorException


# Federated Inference Models
class FederatedQueryRequest(BaseModel):
    """Request for federated inference query."""
    model_id: str = Field(..., description="ID of the model to use")
    prompt: str = Field(..., description="Input prompt for inference")
    max_tokens: Optional[int] = Field(512, description="Maximum tokens to generate")
    temperature: Optional[float] = Field(0.7, description="Sampling temperature")
    top_p: Optional[float] = Field(0.9, description="Top-p sampling parameter")
    top_k: Optional[int] = Field(50, description="Top-k sampling parameter")
    stream: bool = Field(False, description="Enable streaming response")
    encrypted: bool = Field(False, description="Request encrypted processing")
    wallet_signature: Optional[str] = Field(None, description="Wallet signature for authentication")


class FederatedBatchQueryRequest(BaseModel):
    """Request for batch federated inference."""
    model_id: str = Field(..., description="ID of the model to use")
    prompts: List[str] = Field(..., description="List of input prompts")
    max_tokens: Optional[int] = Field(512, description="Maximum tokens to generate")
    temperature: Optional[float] = Field(0.7, description="Sampling temperature")
    batch_size: Optional[int] = Field(8, description="Batch size for processing")
    encrypted: bool = Field(False, description="Request encrypted processing")
    wallet_signature: Optional[str] = Field(None, description="Wallet signature for authentication")


class FederatedQueryResponse(BaseModel):
    """Response for federated inference query."""
    text: str = Field(..., description="Generated text")
    usage: Dict[str, Any] = Field(..., description="Token usage statistics")
    model_version: str = Field(..., description="Model version used")
    federated_nodes: List[str] = Field(..., description="Nodes that participated in inference")
    processing_time: float = Field(..., description="Total processing time in seconds")
    encrypted: bool = Field(False, description="Whether response was encrypted")
    generated_at: datetime = Field(default_factory=datetime.utcnow, description="Response generation timestamp")


class FederatedBatchQueryResponse(BaseModel):
    """Response for batch federated inference."""
    results: List[FederatedQueryResponse] = Field(..., description="List of individual responses")
    total_usage: Dict[str, Any] = Field(..., description="Aggregated usage statistics")
    batch_processing_time: float = Field(..., description="Total batch processing time")
    encrypted: bool = Field(False, description="Whether responses were encrypted")


class InferenceStatusResponse(BaseModel):
    """Response for inference service status."""
    status: str = Field(..., description="Service status (healthy/unhealthy)")
    federated_coordinator_status: str = Field(..., description="Federated coordinator status")
    model_registry_status: str = Field(..., description="Model registry status")
    active_models: List[str] = Field(..., description="List of active model IDs")
    federated_nodes: List[Dict[str, Any]] = Field(..., description="Status of federated nodes")
    metrics: Dict[str, Any] = Field(..., description="Performance metrics")


# Model Management Models
class ModelDeploymentRequest(BaseModel):
    """Request to deploy a model."""
    model_id: str = Field(..., description="ID of the model to deploy")
    target_nodes: Optional[List[str]] = Field(None, description="Specific nodes to deploy to")
    auto_scale: bool = Field(True, description="Enable auto-scaling")
    encryption_enabled: bool = Field(True, description="Enable encryption for model")
    wallet_signature: Optional[str] = Field(None, description="Wallet signature for authorization")


class ModelUndeploymentRequest(BaseModel):
    """Request to undeploy a model."""
    model_id: str = Field(..., description="ID of the model to undeploy")
    target_nodes: Optional[List[str]] = Field(None, description="Specific nodes to undeploy from")
    wallet_signature: Optional[str] = Field(None, description="Wallet signature for authorization")


class ModelDeploymentStatus(BaseModel):
    """Status of model deployment."""
    model_id: str = Field(..., description="Model ID")
    status: str = Field(..., description="Deployment status")
    deployed_nodes: List[str] = Field(..., description="Nodes where model is deployed")
    deployment_time: Optional[datetime] = Field(None, description="Deployment timestamp")
    errors: Optional[List[str]] = Field(None, description="Deployment errors")


# Authentication and Encryption Models
class WalletAuthRequest(BaseModel):
    """Wallet authentication request."""
    wallet_address: str = Field(..., description="Wallet address")
    signature: str = Field(..., description="Signature for authentication")
    message: str = Field(..., description="Signed message")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Request timestamp")


class EncryptedRequest(BaseModel):
    """Encrypted request wrapper."""
    encrypted_data: str = Field(..., description="Base64 encoded encrypted data")
    encryption_method: str = Field("AES-256-GCM", description="Encryption method used")
    wallet_address: str = Field(..., description="Sender's wallet address")
    nonce: str = Field(..., description="Encryption nonce")


class EncryptedResponse(BaseModel):
    """Encrypted response wrapper."""
    encrypted_data: str = Field(..., description="Base64 encoded encrypted data")
    encryption_method: str = Field("AES-256-GCM", description="Encryption method used")
    signature: str = Field(..., description="Response signature")


router = APIRouter()


@router.get("/marketplace")
async def get_models_marketplace(
    type_filter: str = Query("", description="Tipo de modelo: data, llm"),
    license_filter: str = Query("", description="Licencia del modelo"),
    min_quality: float = Query(0, ge=0, le=100, description="Calidad mínima"),
    max_price: float = Query(None, description="Precio máximo"),
    limit: int = Query(50, ge=1, le=200, description="Límite de resultados")
):
    """Obtener lista de modelos disponibles en el marketplace con datos mock."""
    try:
        # Datos mock para el marketplace
        mock_models = [
            {
                "id": "model_001",
                "name": "GPT-2 Small",
                "description": "Modelo de lenguaje GPT-2 pequeño pre-entrenado",
                "type": "llm",
                "license": "mit",
                "size_gb": 0.5,
                "quality_score": 85,
                "price_drs": 100,
                "provider": "OpenAI",
                "tags": ["language", "generation", "gpt"],
                "download_count": 1250,
                "status": "available",
                "created_at": "2024-01-15T10:00:00Z",
                "updated_at": "2024-01-15T10:00:00Z"
            },
            {
                "id": "model_002",
                "name": "Wikipedia Dataset 9.3GB",
                "description": "Dataset completo de Wikipedia comprimido",
                "type": "data",
                "license": "wikipedia",
                "size_gb": 9.3,
                "quality_score": 95,
                "price_drs": 500,
                "provider": "Wikipedia Foundation",
                "tags": ["wikipedia", "text", "dataset"],
                "download_count": 340,
                "status": "available",
                "created_at": "2024-01-10T08:00:00Z",
                "updated_at": "2024-01-10T08:00:00Z"
            },
            {
                "id": "model_003",
                "name": "Stable Diffusion v1.5",
                "description": "Modelo de generación de imágenes Stable Diffusion",
                "type": "llm",
                "license": "apache",
                "size_gb": 4.2,
                "quality_score": 92,
                "price_drs": 200,
                "provider": "Stability AI",
                "tags": ["image", "generation", "diffusion"],
                "download_count": 890,
                "status": "available",
                "created_at": "2024-01-12T14:00:00Z",
                "updated_at": "2024-01-12T14:00:00Z"
            }
        ]

        # Aplicar filtros
        filtered_models = mock_models.copy()

        if type_filter:
            filtered_models = [m for m in filtered_models if m["type"] == type_filter]

        if license_filter:
            filtered_models = [m for m in filtered_models if m["license"] == license_filter]

        if min_quality > 0:
            filtered_models = [m for m in filtered_models if m["quality_score"] >= min_quality]

        if max_price is not None:
            filtered_models = [m for m in filtered_models if m.get("price_drs", 0) <= max_price]

        # Limitar resultados
        filtered_models = filtered_models[:limit]

        return {"models": filtered_models, "total": len(filtered_models)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo modelos: {str(e)}")


@router.get("/stats")
async def get_model_stats():
    """Obtener estadísticas del marketplace de modelos con datos mock."""
    try:
        # Estadísticas mock
        mock_stats = {
            "total_models": 3,
            "total_downloads": 2480,
            "active_providers": 3,
            "average_quality": 90.67
        }
        return mock_stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo estadísticas: {str(e)}")


@router.get("/list", response_model=PaginatedResponse)
async def list_models(
    skip: int = Query(0, ge=0, description="Number of models to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of models to return"),
    model_type: Optional[str] = Query(None, description="Filter by model type"),
    session_id: Optional[str] = Query(None, description="Filter by session ID"),
    is_public: Optional[bool] = Query(None, description="Filter by public availability"),
    status: Optional[str] = Query(None, description="Filter by model status"),
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """List models with optional filtering and pagination."""
    try:
        # Obtener modelos reales del servicio
        models_db = model_service.list_models(
            db=db,
            skip=skip,
            limit=limit,
            model_type=model_type,
            session_id=session_id,
            is_public=is_public,
            status=status
        )

        # Convertir a formato de respuesta
        models = [
            {
                "id": model.id,
                "name": model.name,
                "model_type": model.model_type,
                "version": model.version,
                "status": model.status,
                "is_public": model.is_public,
                "description": model.description,
                "created_at": model.created_at.isoformat() if model.created_at else None,
                "metrics": model.metrics or {},
                "tags": model.tags or []
            }
            for model in models_db
        ]

        # Obtener total para paginación
        total_query = db.query(Model)
        if model_type:
            total_query = total_query.filter(Model.model_type == model_type)
        if session_id:
            total_query = total_query.filter(Model.session_id == session_id)
        if is_public is not None:
            total_query = total_query.filter(Model.is_public == is_public)
        if status:
            total_query = total_query.filter(Model.status == status)
        total = total_query.count()

        return PaginatedResponse(
            success=True,
            message="Models retrieved successfully",
            data=models,
            total=total,
            page=(skip // limit) + 1,
            page_size=limit,
            total_pages=(total + limit - 1) // limit
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving models: {str(e)}")


@router.post("/", response_model=APIResponse)
async def create_model(
    model_data: ModelCreate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Create a new model."""
    try:
        # Crear modelo real usando el servicio
        model = await model_service.create_model(
            db=db,
            model_data=model_data,
            created_by=current_admin.get("id", "admin")
        )

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "model_type": model.model_type,
            "version": model.version,
            "status": model.status,
            "description": model.description,
            "created_at": model.created_at.isoformat() if model.created_at else None
        }

        return APIResponse(
            success=True,
            message="Model created successfully",
            data=model_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating model: {str(e)}")


@router.get("/{model_id}", response_model=APIResponse)
async def get_model(
    model_id: str,
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get a specific model by ID."""
    try:
        # Obtener modelo real del servicio
        model = model_service.get_model(db, model_id)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {model_id} not found")

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "model_type": model.model_type,
            "version": model.version,
            "status": model.status,
            "is_public": model.is_public,
            "description": model.description,
            "config": model.config or {},
            "metrics": model.metrics or {},
            "tags": model.tags or [],
            "ipfs_cid": model.ipfs_cid,
            "created_at": model.created_at.isoformat() if model.created_at else None,
            "updated_at": model.updated_at.isoformat() if model.updated_at else None,
            "published_at": model.published_at.isoformat() if model.published_at else None
        }

        return APIResponse(
            success=True,
            message="Model retrieved successfully",
            data=model_data
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving model: {str(e)}")


@router.put("/{model_id}", response_model=APIResponse)
async def update_model(
    model_id: str,
    model_update: ModelUpdate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Update a model."""
    try:
        # Actualizar modelo real usando el servicio
        model = await model_service.update_model(
            db=db,
            model_id=model_id,
            model_update=model_update,
            updated_by=current_admin.get("id", "admin")
        )

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "model_type": model.model_type,
            "version": model.version,
            "status": model.status,
            "description": model.description,
            "updated_at": model.updated_at.isoformat() if model.updated_at else None
        }

        return APIResponse(
            success=True,
            message="Model updated successfully",
            data=model_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating model: {str(e)}")


@router.delete("/{model_id}", response_model=APIResponse)
async def delete_model(
    model_id: str,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Delete a model."""
    try:
        # Eliminar modelo real usando el servicio
        await model_service.delete_model(db, model_id)

        return APIResponse(
            success=True,
            message="Model deleted successfully"
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting model: {str(e)}")


@router.post("/{model_id}/publish", response_model=APIResponse)
async def publish_model(
    model_id: str,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Publish a model to make it publicly available."""
    try:
        # Publicar modelo real usando el servicio
        model = await model_service.publish_model(
            db=db,
            model_id=model_id,
            published_by=current_admin.get("id", "admin")
        )

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "is_public": model.is_public,
            "ipfs_cid": model.ipfs_cid,
            "published_at": model.published_at.isoformat() if model.published_at else None
        }

        return APIResponse(
            success=True,
            message="Model published successfully",
            data=model_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error publishing model: {str(e)}")


@router.post("/{model_id}/unpublish", response_model=APIResponse)
async def unpublish_model(
    model_id: str,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Unpublish a model."""
    try:
        # Despublicar modelo real usando el servicio
        model = await model_service.unpublish_model(db, model_id)

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "is_public": model.is_public
        }

        return APIResponse(
            success=True,
            message="Model unpublished successfully",
            data=model_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error unpublishing model: {str(e)}")


@router.get("/session/{session_id}", response_model=APIResponse)
async def get_models_by_session(
    session_id: str,
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get all models for a session."""
    try:
        # Obtener modelos reales de la sesión
        models_db = model_service.get_models_by_session(db, session_id)

        # Convertir a formato de respuesta
        models = [
            {
                "id": model.id,
                "name": model.name,
                "model_type": model.model_type,
                "version": model.version,
                "status": model.status,
                "created_at": model.created_at.isoformat() if model.created_at else None
            }
            for model in models_db
        ]

        return APIResponse(
            success=True,
            message="Session models retrieved successfully",
            data=models
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving session models: {str(e)}")


@router.get("/public", response_model=APIResponse)
async def get_public_models(
    model_type: Optional[str] = Query(None, description="Filter by model type"),
    limit: Optional[int] = Query(100, ge=1, le=1000, description="Maximum number of models to return"),
    db: Session = Depends(get_db)
):
    """Get publicly available models."""
    try:
        # Obtener modelos públicos reales
        models_db = model_service.get_public_models(
            db=db,
            model_type=model_type,
            limit=limit
        )

        # Convertir a formato de respuesta
        models = [
            {
                "id": model.id,
                "name": model.name,
                "model_type": model.model_type,
                "version": model.version,
                "description": model.description,
                "metrics": model.metrics or {},
                "tags": model.tags or [],
                "ipfs_cid": model.ipfs_cid,
                "published_at": model.published_at.isoformat() if model.published_at else None
            }
            for model in models_db
        ]

        return APIResponse(
            success=True,
            message="Public models retrieved successfully",
            data=models
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving public models: {str(e)}")


@router.put("/{model_id}/metrics", response_model=APIResponse)
async def update_model_metrics(
    model_id: str,
    metrics: dict,
    global_parameters_hash: Optional[str] = Query(None, description="Global parameters hash"),
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """Update model metrics and global parameters hash."""
    try:
        # Actualizar métricas reales usando el servicio
        model = await model_service.update_model_metrics(
            db=db,
            model_id=model_id,
            metrics=metrics,
            global_parameters_hash=global_parameters_hash
        )

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "metrics": model.metrics or {},
            "global_parameters_hash": model.global_parameters_hash
        }

        return APIResponse(
            success=True,
            message="Model metrics updated successfully",
            data=model_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating model metrics: {str(e)}")


@router.post("/upload", response_model=APIResponse)
async def upload_model(
    name: str = Form(..., description="Model name"),
    model_type: str = Form(..., description="Model type"),
    description: Optional[str] = Form(None, description="Model description"),
    version: Optional[str] = Form("1.0.0", description="Model version"),
    tags: Optional[str] = Form(None, description="Model tags as JSON string"),
    file: UploadFile = File(..., description="Model file"),
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Upload a model file for federated learning."""
    try:
        # Parse tags if provided
        parsed_tags = None
        if tags:
            try:
                import json
                parsed_tags = json.loads(tags)
            except:
                parsed_tags = [tag.strip() for tag in tags.split(',') if tag.strip()]

        # Create upload object
        from ..models.schemas import ModelUpload
        model_upload = ModelUpload(
            name=name,
            model_type=model_type,
            description=description,
            version=version,
            tags=parsed_tags,
            file=file
        )

        # Upload model using service
        model = await model_service.upload_model(
            db=db,
            model_upload=model_upload,
            uploaded_by=current_node.get("id", "unknown")
        )

        # Convert to response format
        model_data = {
            "id": model.id,
            "name": model.name,
            "model_type": model.model_type,
            "version": model.version,
            "description": model.description,
            "file_hash": model.file_hash,
            "file_size": model.file_size,
            "ipfs_cid": model.ipfs_cid,
            "storage_location": model.storage_location,
            "tags": model.tags or [],
            "created_at": model.created_at.isoformat() if model.created_at else None
        }

        return APIResponse(
            success=True,
            message="Model uploaded successfully",
            data=model_data
        )
    except CoordinatorException as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading model: {str(e)}")


@router.get("/download/{model_id}")
async def download_model(
    model_id: str,
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Download a model file."""
    try:
        # Get model from database
        model = model_service.get_model(db, model_id)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {model_id} not found")

        # Check if model is public or owned by current node
        if not model.is_public and model.owner_node_id != current_node.get("id"):
            raise HTTPException(status_code=403, detail="Access denied to this model")

        # Check if file exists
        if not model.storage_location or not os.path.exists(model.storage_location):
            raise HTTPException(status_code=404, detail="Model file not found")

        # Return file
        return FileResponse(
            path=model.storage_location,
            filename=f"{model.name}_{model.version}{os.path.splitext(model.storage_location)[1]}",
            media_type='application/octet-stream'
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error downloading model: {str(e)}")


@router.get("/versions/{name}/{model_type}", response_model=APIResponse)
async def get_model_versions(
    name: str,
    model_type: str,
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get all versions of a model by name and type."""
    try:
        # Obtener versiones reales del modelo
        models_db = model_service.get_model_versions(db, name, model_type)

        # Convertir a formato de respuesta
        models = [
            {
                "id": model.id,
                "name": model.name,
                "model_type": model.model_type,
                "version": model.version,
                "status": model.status,
                "created_at": model.created_at.isoformat() if model.created_at else None
            }
            for model in models_db
        ]

        return APIResponse(
            success=True,
            message="Model versions retrieved successfully",
            data=models
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving model versions: {str(e)}")


@router.get("/latest/{name}/{model_type}", response_model=APIResponse)
async def get_latest_model_version(
    name: str,
    model_type: str,
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get the latest version of a model."""
    try:
        # Obtener la versión más reciente real
        model = model_service.get_latest_model_version(db, name, model_type)
        if not model:
            raise HTTPException(status_code=404, detail=f"No versions found for model {name} of type {model_type}")

        # Convertir a formato de respuesta
        model_data = {
            "id": model.id,
            "name": model.name,
            "model_type": model.model_type,
            "version": model.version,
            "status": model.status,
            "description": model.description,
            "metrics": model.metrics or {},
            "created_at": model.created_at.isoformat() if model.created_at else None
        }

        return APIResponse(
            success=True,
            message="Latest model version retrieved successfully",
            data=model_data
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving latest model version: {str(e)}")