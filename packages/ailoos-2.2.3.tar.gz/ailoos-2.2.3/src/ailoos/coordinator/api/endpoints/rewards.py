"""
API endpoints for rewards and incentives management.
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...models.schemas import APIResponse, PaginatedResponse
from ...auth.dependencies import get_current_user

router = APIRouter()


@router.get("/api/v1/rewards")
async def get_rewards(
    session_id: Optional[str] = Query(None, description="Filter by session ID"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of rewards to return"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get rewards list with optional filtering."""
    try:
        # Mock data for now - in real implementation, query database
        rewards = [
            {
                "id": "reward_1",
                "session_id": session_id or "session_123",
                "node_id": "node_456",
                "amount": 10.5,
                "currency": "DRACMA",
                "type": "training_contribution",
                "status": "distributed",
                "created_at": "2024-01-15T10:30:00Z",
                "distributed_at": "2024-01-15T11:00:00Z"
            }
        ]

        return {"rewards": rewards[:limit]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving rewards: {str(e)}")


@router.get("/api/v1/rewards/my-rewards")
async def get_my_rewards(
    session_id: Optional[str] = Query(None, description="Filter by session ID"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of rewards to return"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get current user's rewards."""
    try:
        # Mock data for now - in real implementation, query database
        my_rewards = [
            {
                "id": "my_reward_1",
                "session_id": session_id or "session_123",
                "node_id": current_user.get("node_id", "current_node"),
                "amount": 25.75,
                "currency": "DRACMA",
                "type": "training_contribution",
                "status": "distributed",
                "created_at": "2024-01-15T10:30:00Z",
                "distributed_at": "2024-01-15T11:00:00Z"
            }
        ]

        return {"rewards": my_rewards[:limit]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving my rewards: {str(e)}")


@router.get("/api/v1/rewards/stats/session")
async def get_reward_stats(session_id: Optional[str] = Query(None, description="Session ID"), db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Get reward statistics for a session."""
    try:
        # Mock data for now - in real implementation, query database
        stats = {
            "session_id": session_id or "session_123",
            "total_rewards_distributed": 1250.50,
            "total_participants": 15,
            "average_reward_per_participant": 83.37,
            "total_training_contributions": 45,
            "rewards_by_type": {
                "training_contribution": 1000.00,
                "data_quality": 150.50,
                "uptime_bonus": 100.00
            }
        }

        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving reward stats: {str(e)}")