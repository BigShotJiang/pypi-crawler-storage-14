"""
Marketplace API endpoints.
Provides complete marketplace functionality with real DRACMA transactions.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ....marketplace import marketplace
from ....marketplace.data_listing import DataCategory
from ...database.connection import get_db
from ...auth.jwt import get_current_user
# from ..auth.permissions import require_permissions  # Commented out - function not defined

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class CreateListingRequest(BaseModel):
    """Request model for creating a data listing."""
    title: str = Field(..., min_length=1, max_length=255)
    description: str = Field(..., min_length=1, max_length=1000)
    category: str = Field(..., description="Data category (e.g., 'healthcare', 'finance', 'iot')")
    data_hash: str = Field(..., min_length=64, max_length=128, description="SHA-256 hash of the data")
    ipfs_cid: str = Field(..., min_length=1, max_length=100, description="IPFS Content Identifier")
    price_dracma: float = Field(..., gt=0, description="Price in DRACMA tokens")
    data_size_mb: float = Field(..., gt=0, description="Data size in MB")
    sample_count: int = Field(..., gt=0, description="Number of data samples")
    quality_score: float = Field(..., ge=0, le=1, description="Data quality score (0-1)")
    tags: List[str] = Field(default_factory=list, max_items=10)
    duration_days: int = Field(default=30, ge=1, le=365, description="Listing duration in days")


class SearchListingsRequest(BaseModel):
    """Request model for searching listings."""
    query: Optional[str] = Field(None, max_length=100)
    category: Optional[str] = None
    min_price: float = Field(default=0, ge=0)
    max_price: Optional[float] = Field(None, gt=0)
    min_quality: float = Field(default=0, ge=0, le=1)
    tags: List[str] = Field(default_factory=list, max_items=10)
    limit: int = Field(default=20, ge=1, le=100)


class PurchaseDataRequest(BaseModel):
    """Request model for purchasing data."""
    listing_id: str = Field(..., min_length=1, max_length=64)


class TransferTokensRequest(BaseModel):
    """Request model for transferring tokens."""
    receiver_address: str = Field(..., min_length=42, max_length=42, pattern=r"^0x[a-fA-F0-9]{40}$")
    amount: float = Field(..., gt=0)


class StakeTokensRequest(BaseModel):
    """Request model for staking tokens."""
    amount: float = Field(..., gt=0)


class ListingResponse(BaseModel):
    """Response model for listing details."""
    listing_id: str
    title: str
    description: str
    category: str
    price_dracma: float
    data_size_mb: float
    sample_count: int
    quality_score: float
    tags: List[str]
    seller_address: str
    ipfs_cid: str
    created_at: datetime
    expires_at: datetime


class PortfolioResponse(BaseModel):
    """Response model for user portfolio."""
    address: Optional[str]
    balance_dracma: float
    staked_dracma: float
    total_value_dracma: float
    staking_multiplier: float
    estimated_daily_reward: float
    estimated_monthly_reward: float
    recent_transactions: int
    portfolio_health: str
    active_listings: int
    total_purchases: int
    active_listings_value: float


class TransactionResponse(BaseModel):
    """Response model for transaction details."""
    tx_hash: str
    type: str
    amount: float
    timestamp: float
    status: str
    sender: str
    receiver: str
    data: Optional[Dict[str, Any]]


# API Endpoints
@router.post("/listings", response_model=Dict[str, Any])
async def create_data_listing(
    request: CreateListingRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create a new data listing in the marketplace.

    - Validates user has wallet
    - Creates listing with real DRACMA pricing
    - Returns listing ID
    """
    try:
        user_id = current_user.sub

        # Validate category
        try:
            data_category = DataCategory(request.category.lower())
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid category: {request.category}. Valid categories: {[c.value for c in DataCategory]}"
            )

        # Create listing
        listing_id = marketplace.create_data_listing(
            seller_id=user_id,
            title=request.title,
            description=request.description,
            category=data_category.value,
            data_hash=request.data_hash,
            ipfs_cid=request.ipfs_cid,
            price_dracma=request.price_dracma,
            data_size_mb=request.data_size_mb,
            sample_count=request.sample_count,
            quality_score=request.quality_score,
            tags=request.tags,
            duration_days=request.duration_days
        )

        logger.info(f"User {user_id} created listing {listing_id}")

        return {
            "listing_id": listing_id,
            "message": "Data listing created successfully",
            "status": "active"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Create listing error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/listings/search", response_model=Dict[str, Any])
async def search_listings(
    query: Optional[str] = None,
    category: Optional[str] = None,
    min_price: float = 0,
    max_price: Optional[float] = None,
    min_quality: float = 0,
    tags: Optional[str] = None,  # Comma-separated
    limit: int = 20,
    current_user: Optional[Dict] = Depends(get_current_user)
):
    """
    Search available data listings.

    - Supports filtering by multiple criteria
    - Returns formatted listing results
    """
    try:
        # Parse tags
        tag_list = []
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]

        # Search listings
        results = marketplace.search_datasets(
            query=query,
            category=category,
            min_price=min_price,
            max_price=max_price,
            min_quality=min_quality,
            tags=tag_list,
            limit=limit
        )

        return {
            "listings": results,
            "total": len(results),
            "query": {
                "search_term": query,
                "category": category,
                "price_range": f"{min_price}-{max_price or '∞'}",
                "min_quality": min_quality,
                "tags": tag_list,
                "limit": limit
            }
        }

    except Exception as e:
        logger.error(f"Search listings error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/listings/{listing_id}", response_model=ListingResponse)
async def get_listing_details(
    listing_id: str,
    current_user: Optional[Dict] = Depends(get_current_user)
):
    """
    Get detailed information about a specific listing.

    - Returns complete listing information
    - Includes seller details and validation status
    """
    try:
        from ...marketplace.data_listing import data_marketplace

        listing = data_marketplace.get_listing_details(listing_id)
        if not listing:
            raise HTTPException(status_code=404, detail="Listing not found")

        return ListingResponse(
            listing_id=listing.listing_id,
            title=listing.title,
            description=listing.description,
            category=listing.category.value,
            price_dracma=listing.price_dracma,
            data_size_mb=listing.data_size_mb,
            sample_count=listing.sample_count,
            quality_score=listing.quality_score,
            tags=listing.tags,
            seller_address=listing.seller_address,
            ipfs_cid=listing.ipfs_cid,
            created_at=listing.created_at,
            expires_at=listing.expires_at
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get listing details error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/purchase", response_model=Dict[str, Any])
async def purchase_data(
    request: PurchaseDataRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Purchase data from the marketplace.

    - Validates buyer has sufficient balance
    - Executes real DRACMA transaction
    - Records purchase in marketplace
    - Returns transaction details
    """
    try:
        user_id = current_user.sub

        # Execute purchase
        tx_hash = await marketplace.purchase_data(
            buyer_id=user_id,
            listing_id=request.listing_id
        )

        logger.info(f"User {user_id} purchased listing {request.listing_id}, tx: {tx_hash}")

        return {
            "transaction_hash": tx_hash,
            "listing_id": request.listing_id,
            "message": "Purchase completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Purchase data error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/portfolio", response_model=PortfolioResponse)
async def get_user_portfolio(
    current_user: Dict = Depends(get_current_user)
):
    """
    Get user's complete portfolio information.

    - Returns wallet balance, staking info, listings, purchases
    - Provides portfolio health assessment
    """
    try:
        user_id = current_user.sub

        portfolio = await marketplace.get_user_portfolio(user_id)

        # Handle case where user has no wallet
        if isinstance(portfolio, dict) and "error" in portfolio:
            return PortfolioResponse(
                address=None,
                balance_dracma=0.0,
                staked_dracma=0.0,
                total_value_dracma=0.0,
                staking_multiplier=1.0,
                estimated_daily_reward=0.0,
                estimated_monthly_reward=0.0,
                recent_transactions=0,
                portfolio_health="no_wallet",
                active_listings=0,
                total_purchases=0,
                active_listings_value=0.0
            )

        return PortfolioResponse(**portfolio)

    except Exception as e:
        logger.error(f"Get portfolio error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/transfer", response_model=Dict[str, Any])
async def transfer_tokens(
    request: TransferTokensRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Transfer DRACMA tokens to another address.

    - Validates sender has sufficient balance
    - Executes real blockchain transaction
    - Returns transaction hash
    """
    try:
        user_id = current_user.sub

        # Execute transfer
        tx_hash = await marketplace.transfer_tokens(
            sender_id=user_id,
            receiver_address=request.receiver_address,
            amount=request.amount
        )

        logger.info(f"User {user_id} transferred {request.amount} DRACMA to {request.receiver_address}, tx: {tx_hash}")

        return {
            "transaction_hash": tx_hash,
            "amount": request.amount,
            "receiver": request.receiver_address,
            "message": "Transfer completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Transfer tokens error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/stake", response_model=Dict[str, Any])
async def stake_tokens(
    request: StakeTokensRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Stake DRACMA tokens for rewards.

    - Locks tokens in staking contract
    - Provides multiplier for future rewards
    - Returns transaction hash
    """
    try:
        user_id = current_user.sub

        # Execute staking
        tx_hash = await marketplace.stake_tokens(
            user_id=user_id,
            amount=request.amount
        )

        logger.info(f"User {user_id} staked {request.amount} DRACMA, tx: {tx_hash}")

        return {
            "transaction_hash": tx_hash,
            "amount_staked": request.amount,
            "message": "Staking completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Stake tokens error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/unstake", response_model=Dict[str, Any])
async def unstake_tokens(
    request: StakeTokensRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Unstake DRACMA tokens.

    - Releases tokens from staking contract
    - Returns tokens to wallet balance
    """
    try:
        user_id = current_user.sub

        # Execute unstaking
        tx_hash = await marketplace.unstake_tokens(
            user_id=user_id,
            amount=request.amount
        )

        logger.info(f"User {user_id} unstaked {request.amount} DRACMA, tx: {tx_hash}")

        return {
            "transaction_hash": tx_hash,
            "amount_unstaked": request.amount,
            "message": "Unstaking completed successfully",
            "status": "confirmed"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unstake tokens error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/transactions", response_model=Dict[str, Any])
async def get_transaction_history(
    limit: int = 20,
    current_user: Dict = Depends(get_current_user)
):
    """
    Get user's transaction history.

    - Returns recent transactions
    - Includes transfers, purchases, staking
    """
    try:
        user_id = current_user.sub

        transactions = await marketplace.get_transaction_history(
            user_id=user_id,
            limit=limit
        )

        # Format transactions
        formatted_txs = []
        for tx in transactions:
            formatted_txs.append(TransactionResponse(
                tx_hash=tx.tx_hash,
                type=tx.tx_type.value,
                amount=tx.amount,
                timestamp=tx.timestamp,
                status=tx.status.value,
                sender=tx.sender,
                receiver=tx.receiver,
                data=tx.data
            ))

        return {
            "transactions": formatted_txs,
            "total": len(formatted_txs),
            "limit": limit
        }

    except Exception as e:
        logger.error(f"Get transaction history error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/recommendations", response_model=Dict[str, Any])
async def get_recommendations(
    limit: int = 5,
    current_user: Dict = Depends(get_current_user)
):
    """
    Get personalized data recommendations.

    - Based on user's purchase history
    - Considers categories and quality preferences
    """
    try:
        user_id = current_user.sub

        recommendations = marketplace.get_recommendations(
            user_id=user_id,
            limit=limit
        )

        return {
            "recommendations": recommendations,
            "total": len(recommendations),
            "based_on_history": True
        }

    except Exception as e:
        logger.error(f"Get recommendations error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/stats", response_model=Dict[str, Any])
async def get_marketplace_stats():
    """
    Get marketplace statistics.

    - Total listings, volume, active users
    - Public endpoint, no authentication required
    """
    try:
        stats = marketplace.get_market_stats()

        return {
            "marketplace_stats": stats,
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Get marketplace stats error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/validate-purchase", response_model=Dict[str, Any])
async def validate_data_purchase(
    listing_id: str,
    downloaded_hash: str,
    current_user: Dict = Depends(get_current_user)
):
    """
    Validate integrity of purchased data.

    - Verifies user purchased the listing
    - Checks data hash matches original
    - Confirms data integrity
    """
    try:
        user_id = current_user.sub

        is_valid = marketplace.validate_data_purchase(
            user_id=user_id,
            listing_id=listing_id,
            downloaded_hash=downloaded_hash
        )

        if is_valid:
            return {
                "valid": True,
                "message": "Data integrity verified successfully",
                "listing_id": listing_id
            }
        else:
            return {
                "valid": False,
                "message": "Data integrity check failed",
                "listing_id": listing_id
            }

    except Exception as e:
        logger.error(f"Validate purchase error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Admin endpoints
@router.get("/admin/listings", response_model=Dict[str, Any])
async def list_all_listings(
    skip: int = 0,
    limit: int = 100,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Admin endpoint to list all marketplace listings.

    - Requires admin permissions
    - Returns complete listing information
    """
    try:
        from ...marketplace.data_listing import data_marketplace

        # Get all listings (admin function)
        all_listings = data_marketplace._listings.copy()  # Access private attribute for admin

        listings_list = list(all_listings.values())
        paginated_listings = listings_list[skip:skip + limit]

        # Format response
        formatted_listings = []
        for listing in paginated_listings:
            formatted_listings.append({
                "listing_id": listing.listing_id,
                "title": listing.title,
                "seller_address": listing.seller_address,
                "price_dracma": listing.price_dracma,
                "status": listing.status.value,
                "category": listing.category.value,
                "created_at": listing.created_at,
                "expires_at": listing.expires_at
            })

        return {
            "listings": formatted_listings,
            "total": len(listings_list),
            "skip": skip,
            "limit": limit
        }

    except Exception as e:
        logger.error(f"List all listings error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")