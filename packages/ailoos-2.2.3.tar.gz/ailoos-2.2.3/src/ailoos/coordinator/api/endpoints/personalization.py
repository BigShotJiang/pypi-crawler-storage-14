"""
APIs de perfil personal en src/ailoos/coordinator/api/endpoints/personalization.py.
Esta API debe proporcionar endpoints REST para gestionar el perfil de personalización de EmpoorioLM,
incluyendo configuración de estilo de conversación, información personal del usuario, y estado del fine-tuning personalizado.
Debe integrar con el servicio de configuraciones y proporcionar endpoints para iniciar y monitorear el proceso de personalización.
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, Request, BackgroundTasks
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user
from ailoos.settings.service import SettingsService
from ailoos.settings.models import PersonalizationSettings
from ...empoorio_lm.service import EmpoorioLMService

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class PersonalizationProfileResponse(BaseModel):
    """Response model for personalization profile."""
    enable_personalization: bool
    custom_instructions: bool
    base_style_tone: str
    nickname: str
    occupation: str
    more_about_you: str
    reference_chat_history: bool
    updated_at: datetime


class PersonalizationProfileUpdateRequest(BaseModel):
    """Request model for updating personalization profile."""
    enable_personalization: Optional[bool] = None
    custom_instructions: Optional[bool] = None
    base_style_tone: Optional[str] = None
    nickname: Optional[str] = Field(None, max_length=50)
    occupation: Optional[str] = Field(None, max_length=100)
    more_about_you: Optional[str] = Field(None, max_length=500)
    reference_chat_history: Optional[bool] = None

    @validator('base_style_tone')
    def validate_base_style_tone(cls, v):
        if v is not None and v not in ["talkative", "witty", "professional", "casual"]:
            raise ValueError('base_style_tone must be "talkative", "witty", "professional", or "casual"')
        return v


class FineTuningStatusResponse(BaseModel):
    """Response model for fine-tuning status."""
    is_active: bool
    status: str  # "idle", "training", "completed", "failed"
    progress: float  # 0.0 to 1.0
    current_epoch: int
    total_epochs: int
    loss: Optional[float] = None
    accuracy: Optional[float] = None
    estimated_time_remaining: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None


class FineTuningStartRequest(BaseModel):
    """Request model for starting fine-tuning."""
    dataset_size: str = Field(..., description="Size of dataset to use")  # "small", "medium", "large"
    training_hours: int = Field(..., ge=1, le=24, description="Maximum training hours")
    priority: str = Field("normal", description="Training priority")  # "low", "normal", "high"

    @validator('dataset_size')
    def validate_dataset_size(cls, v):
        if v not in ["small", "medium", "large"]:
            raise ValueError('dataset_size must be "small", "medium", or "large"')
        return v

    @validator('priority')
    def validate_priority(cls, v):
        if v not in ["low", "normal", "high"]:
            raise ValueError('priority must be "low", "normal", or "high"')
        return v


class FineTuningHistoryResponse(BaseModel):
    """Response model for fine-tuning history."""
    session_id: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str
    final_loss: Optional[float] = None
    final_accuracy: Optional[float] = None
    dataset_size: str
    training_hours: int


# Helper functions
def get_user_id_from_token(current_user: Dict) -> int:
    """Extract user ID from JWT token payload."""
    try:
        # Assuming user_id is stored in token sub field as integer
        return int(current_user.get('sub', '').split('_')[-1])
    except (ValueError, IndexError):
        raise HTTPException(status_code=400, detail="Invalid user ID in token")


def extract_personalization_settings(personalization: PersonalizationSettings) -> Dict[str, Any]:
    """Extract personalization settings from PersonalizationSettings object."""
    return {
        'enable_personalization': personalization.enable_personalization,
        'custom_instructions': personalization.custom_instructions,
        'base_style_tone': personalization.base_style_tone,
        'nickname': personalization.nickname,
        'occupation': personalization.occupation,
        'more_about_you': personalization.more_about_you,
        'reference_chat_history': personalization.reference_chat_history,
        'updated_at': personalization.updated_at
    }


# API Endpoints

@router.get("/profile", response_model=PersonalizationProfileResponse,
            summary="Obtener perfil de personalización",
            description="""
            Obtiene el perfil de personalización completo del usuario actual.

            **Incluye:**
            - Configuración de personalización habilitada
            - Instrucciones personalizadas
            - Estilo y tono base de conversación
            - Información personal (nickname, ocupación, más sobre ti)
            - Referencia al historial de chat

            **Códigos de respuesta:**
            - 200: Perfil obtenido exitosamente
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Perfil de personalización obtenido exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "enable_personalization": True,
                                "custom_instructions": False,
                                "base_style_tone": "witty",
                                "nickname": "Alex",
                                "occupation": "Software Engineer",
                                "more_about_you": "I love coding and AI",
                                "reference_chat_history": True,
                                "updated_at": "2023-11-10T23:34:24.032Z"
                            }
                        }
                    }
                }
            })
async def get_personalization_profile(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's personalization profile.

    - Returns all personalization settings
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize settings service
        settings_service = SettingsService()

        # Get user settings
        user_settings = settings_service.get_user_settings(user_id)

        # Extract personalization settings
        personalization_data = extract_personalization_settings(user_settings.personalization)

        return PersonalizationProfileResponse(**personalization_data)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get personalization profile error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/profile", response_model=PersonalizationProfileResponse,
            summary="Actualizar perfil de personalización completo",
            description="""
            Actualiza el perfil de personalización completo del usuario actual.

            **Campos opcionales:**
            - enable_personalization: Habilitar personalización (boolean)
            - custom_instructions: Usar instrucciones personalizadas (boolean)
            - base_style_tone: Estilo base ("talkative", "witty", "professional", "casual")
            - nickname: Apodo del usuario (máx 50 caracteres)
            - occupation: Ocupación (máx 100 caracteres)
            - more_about_you: Más información sobre ti (máx 500 caracteres)
            - reference_chat_history: Referenciar historial de chat (boolean)

            **Códigos de respuesta:**
            - 200: Perfil actualizado exitosamente
            - 400: Datos inválidos
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Perfil de personalización actualizado exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "enable_personalization": True,
                                "custom_instructions": True,
                                "base_style_tone": "professional",
                                "nickname": "Dr. Smith",
                                "occupation": "Data Scientist",
                                "more_about_you": "Expert in machine learning and AI ethics",
                                "reference_chat_history": True,
                                "updated_at": "2023-11-10T23:34:24.032Z"
                            }
                        }
                    }
                }
            })
async def update_personalization_profile(
    request: PersonalizationProfileUpdateRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Update complete personalization profile for current user.

    - Updates multiple personalization settings at once
    - Validates all input data
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize settings service
        settings_service = SettingsService()

        # Prepare update data
        update_data = {}
        if request.enable_personalization is not None:
            update_data['enable_personalization'] = request.enable_personalization
        if request.custom_instructions is not None:
            update_data['custom_instructions'] = request.custom_instructions
        if request.base_style_tone is not None:
            update_data['base_style_tone'] = request.base_style_tone
        if request.nickname is not None:
            update_data['nickname'] = request.nickname
        if request.occupation is not None:
            update_data['occupation'] = request.occupation
        if request.more_about_you is not None:
            update_data['more_about_you'] = request.more_about_you
        if request.reference_chat_history is not None:
            update_data['reference_chat_history'] = request.reference_chat_history

        # Update settings
        updated_settings = settings_service.update_category_settings(
            user_id=user_id,
            category='personalization',
            settings=update_data,
            validate=True
        )

        # Extract and return personalization settings
        personalization_data = extract_personalization_settings(updated_settings.personalization)

        logger.info(f"Personalization profile updated for user ID: {user_id}")
        return PersonalizationProfileResponse(**personalization_data)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update personalization profile error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.patch("/profile/style", response_model=PersonalizationProfileResponse,
              summary="Actualizar estilo de conversación",
              description="""
              Actualiza el estilo y tono base de conversación del perfil de personalización.

              **Campos requeridos:**
              - base_style_tone: Estilo base ("talkative", "witty", "professional", "casual")

              **Códigos de respuesta:**
              - 200: Estilo actualizado exitosamente
              - 400: Datos inválidos
              - 401: Usuario no autenticado
              - 404: Usuario no encontrado
              - 500: Error interno del servidor
              """)
async def update_conversation_style(
    base_style_tone: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Update conversation style settings.

    - Updates base style and tone
    - Requires authentication
    """
    try:
        # Validate input
        if base_style_tone not in ["talkative", "witty", "professional", "casual"]:
            raise HTTPException(status_code=400, detail="Invalid base_style_tone value")

        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize settings service
        settings_service = SettingsService()

        # Update style settings
        update_data = {'base_style_tone': base_style_tone}

        updated_settings = settings_service.update_category_settings(
            user_id=user_id,
            category='personalization',
            settings=update_data,
            validate=True
        )

        # Extract and return personalization settings
        personalization_data = extract_personalization_settings(updated_settings.personalization)

        logger.info(f"Conversation style updated for user ID: {user_id}")
        return PersonalizationProfileResponse(**personalization_data)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update conversation style error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.patch("/profile/personal-info", response_model=PersonalizationProfileResponse,
              summary="Actualizar información personal",
              description="""
              Actualiza la información personal del perfil de personalización.

              **Campos opcionales:**
              - nickname: Apodo del usuario (máx 50 caracteres)
              - occupation: Ocupación (máx 100 caracteres)
              - more_about_you: Más información sobre ti (máx 500 caracteres)

              **Códigos de respuesta:**
              - 200: Información personal actualizada exitosamente
              - 400: Datos inválidos
              - 401: Usuario no autenticado
              - 404: Usuario no encontrado
              - 500: Error interno del servidor
              """)
async def update_personal_info(
    nickname: Optional[str] = None,
    occupation: Optional[str] = None,
    more_about_you: Optional[str] = None,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Update personal information settings.

    - Updates nickname, occupation, and additional info
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize settings service
        settings_service = SettingsService()

        # Prepare update data
        update_data = {}
        if nickname is not None:
            if len(nickname) > 50:
                raise HTTPException(status_code=400, detail="Nickname too long (max 50 characters)")
            update_data['nickname'] = nickname
        if occupation is not None:
            if len(occupation) > 100:
                raise HTTPException(status_code=400, detail="Occupation too long (max 100 characters)")
            update_data['occupation'] = occupation
        if more_about_you is not None:
            if len(more_about_you) > 500:
                raise HTTPException(status_code=400, detail="More about you too long (max 500 characters)")
            update_data['more_about_you'] = more_about_you

        updated_settings = settings_service.update_category_settings(
            user_id=user_id,
            category='personalization',
            settings=update_data,
            validate=True
        )

        # Extract and return personalization settings
        personalization_data = extract_personalization_settings(updated_settings.personalization)

        logger.info(f"Personal info updated for user ID: {user_id}")
        return PersonalizationProfileResponse(**personalization_data)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update personal info error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/fine-tuning/status", response_model=FineTuningStatusResponse,
            summary="Obtener estado del fine-tuning personalizado",
            description="""
            Obtiene el estado actual del proceso de fine-tuning personalizado del usuario.

            **Estados posibles:**
            - idle: Sin proceso activo
            - training: Entrenamiento en progreso
            - completed: Entrenamiento completado exitosamente
            - failed: Entrenamiento fallido

            **Códigos de respuesta:**
            - 200: Estado obtenido exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Estado del fine-tuning obtenido exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "is_active": True,
                                "status": "training",
                                "progress": 0.65,
                                "current_epoch": 13,
                                "total_epochs": 20,
                                "loss": 0.234,
                                "accuracy": 0.89,
                                "estimated_time_remaining": "2h 30m",
                                "started_at": "2023-11-10T20:00:00.000Z",
                                "completed_at": None,
                                "error_message": None
                            }
                        }
                    }
                }
            })
async def get_fine_tuning_status(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current fine-tuning status for the user.

    - Returns training progress and status
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # TODO: Implement actual fine-tuning status retrieval
        # For now, return mock data
        return FineTuningStatusResponse(
            is_active=False,
            status="idle",
            progress=0.0,
            current_epoch=0,
            total_epochs=0,
            loss=None,
            accuracy=None,
            estimated_time_remaining=None,
            started_at=None,
            completed_at=None,
            error_message=None
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get fine-tuning status error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/fine-tuning/start", response_model=Dict[str, Any],
             summary="Iniciar proceso de fine-tuning personalizado",
             description="""
             Inicia un nuevo proceso de fine-tuning personalizado basado en el perfil del usuario.

             **Parámetros:**
             - dataset_size: Tamaño del dataset ("small", "medium", "large")
             - training_hours: Horas máximas de entrenamiento (1-24)
             - priority: Prioridad del entrenamiento ("low", "normal", "high")

             **Códigos de respuesta:**
             - 200: Fine-tuning iniciado exitosamente
             - 400: Datos inválidos o ya hay un proceso activo
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """,
             responses={
                 200: {
                     "description": "Fine-tuning iniciado exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "message": "Fine-tuning started successfully",
                                 "session_id": "ft_session_123456",
                                 "estimated_completion": "2023-11-11T02:00:00.000Z"
                             }
                         }
                     }
                 }
             })
async def start_fine_tuning(
    request: FineTuningStartRequest,
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Start personalized fine-tuning process.

    - Validates user has sufficient data
    - Starts background training process
    - Returns session information
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # TODO: Check if user already has an active fine-tuning session
        # TODO: Validate user has sufficient personalization data
        # TODO: Start actual fine-tuning process in background

        # For now, simulate starting the process
        session_id = f"ft_session_{user_id}_{int(datetime.utcnow().timestamp())}"

        # Add background task (placeholder)
        background_tasks.add_task(simulate_fine_tuning, session_id, user_id, request.training_hours)

        logger.info(f"Fine-tuning started for user ID: {user_id}, session: {session_id}")

        return {
            "message": "Fine-tuning started successfully",
            "session_id": session_id,
            "estimated_completion": (datetime.utcnow().replace(hour=2, minute=0, second=0, microsecond=0)).isoformat() + "Z"
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Start fine-tuning error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/fine-tuning/stop", response_model=Dict[str, Any],
             summary="Detener proceso de fine-tuning activo",
             description="""
             Detiene el proceso de fine-tuning personalizado actualmente activo.

             **Códigos de respuesta:**
             - 200: Fine-tuning detenido exitosamente
             - 400: No hay proceso activo para detener
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def stop_fine_tuning(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Stop active fine-tuning process.

    - Stops the current training session
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # TODO: Implement actual fine-tuning stop logic

        logger.info(f"Fine-tuning stopped for user ID: {user_id}")

        return {
            "message": "Fine-tuning stopped successfully"
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Stop fine-tuning error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/fine-tuning/history", response_model=List[FineTuningHistoryResponse],
            summary="Obtener historial de fine-tuning",
            description="""
            Obtiene el historial completo de sesiones de fine-tuning del usuario.

            **Códigos de respuesta:**
            - 200: Historial obtenido exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def get_fine_tuning_history(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get fine-tuning history for the user.

    - Returns list of past training sessions
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # TODO: Implement actual history retrieval from database

        # Return empty list for now
        return []

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get fine-tuning history error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/fine-tuning/reset", response_model=Dict[str, Any],
             summary="Resetear perfil personalizado a valores por defecto",
             description="""
             Resetea el perfil de personalización a valores por defecto y elimina el modelo personalizado.

             **Códigos de respuesta:**
             - 200: Perfil reseteado exitosamente
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def reset_personalization_profile(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Reset personalization profile to defaults.

    - Resets all personalization settings
    - Removes custom model if exists
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize settings service
        settings_service = SettingsService()

        # Reset personalization settings to defaults
        updated_settings = settings_service.reset_user_settings_to_default(user_id)

        # TODO: Remove custom model files and database entries

        logger.info(f"Personalization profile reset for user ID: {user_id}")

        return {
            "message": "Personalization profile reset to defaults successfully"
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Reset personalization profile error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Background task functions (placeholders)
async def simulate_fine_tuning(session_id: str, user_id: int, training_hours: int):
    """
    Simulate fine-tuning process (placeholder).

    In production, this would:
    1. Prepare user data for training
    2. Start actual model fine-tuning
    3. Monitor progress and update status
    4. Save trained model
    """
    logger.info(f"Starting simulated fine-tuning for session {session_id}, user {user_id}")

    # Simulate training time
    import asyncio
    await asyncio.sleep(5)  # Simulate 5 seconds of training

    logger.info(f"Completed simulated fine-tuning for session {session_id}")