"""
Parental Controls API endpoints.
Provides REST endpoints for managing parental controls including PIN management, time limits, content filtering, and usage statistics.
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user
from ailoos.parental_controls import (
    get_parental_controls_manager,
    ParentalControlsManager,
    ContentFilterLevel,
    AgeRestriction,
    InvalidParentalPinError,
    ParentalControlDisabledError,
    TimeLimitExceededError,
    ContentBlockedError,
    AgeRestrictionError,
    UserProfile,
    TimeUsage,
    ContentAnalysis
)

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response

class ParentalPinSetRequest(BaseModel):
    """Request model for setting parental PIN."""
    pin: str = Field(..., description="Parental PIN (4-8 digits)", min_length=4, max_length=8)

    @validator('pin')
    def validate_pin(cls, v):
        if not v.isdigit() or not (4 <= len(v) <= 8):
            raise ValueError('PIN must be 4-8 digits')
        return v


class ParentalPinVerifyRequest(BaseModel):
    """Request model for verifying parental PIN."""
    pin: str = Field(..., description="Parental PIN to verify", min_length=4, max_length=8)

    @validator('pin')
    def validate_pin(cls, v):
        if not v.isdigit() or not (4 <= len(v) <= 8):
            raise ValueError('PIN must be 4-8 digits')
        return v


class ParentalPinResponse(BaseModel):
    """Response model for PIN operations."""
    success: bool
    message: str
    is_set: bool = None


class TimeLimitsResponse(BaseModel):
    """Response model for time limits check."""
    allowed: bool
    reason: str
    remaining_time: Optional[int] = None  # minutes
    used_today: Optional[int] = None  # minutes
    limit_today: Optional[int] = None  # minutes


class TimeUsageRecordRequest(BaseModel):
    """Request model for recording time usage."""
    minutes: int = Field(..., description="Minutes used", gt=0)
    activity_type: str = Field("general", description="Type of activity")


class ContentCheckRequest(BaseModel):
    """Request model for content access check."""
    content: str = Field(..., description="Content to check")
    content_type: str = Field("text", description="Type of content")


class ContentCheckResponse(BaseModel):
    """Response model for content check."""
    allowed: bool
    reason: str
    risk_score: float
    categories: List[str]
    filter_level: str


class ContentModerateRequest(BaseModel):
    """Request model for content moderation."""
    content: str = Field(..., description="Content to moderate")
    content_type: str = Field("text", description="Type of content")


class ContentModerateResponse(BaseModel):
    """Response model for content moderation."""
    original_content: str
    moderated_content: str
    was_moderated: bool


class AgeValidationRequest(BaseModel):
    """Request model for age validation."""
    required_age: str = Field(..., description="Required age restriction")
    content_category: Optional[str] = Field(None, description="Content category")

    @validator('required_age')
    def validate_age_restriction(cls, v):
        valid_restrictions = ["all_ages", "7_plus", "13_plus", "16_plus", "18_plus"]
        if v not in valid_restrictions:
            raise ValueError(f'required_age must be one of: {valid_restrictions}')
        return v


class AgeValidationResponse(BaseModel):
    """Response model for age validation."""
    allowed: bool
    reason: str
    user_age: Optional[int] = None


class UserAgeSetRequest(BaseModel):
    """Request model for setting user age."""
    age: int = Field(..., description="User age in years", ge=1, le=120)
    parent_pin: str = Field(..., description="Parental PIN for authorization", min_length=4, max_length=8)

    @validator('parent_pin')
    def validate_pin(cls, v):
        if not v.isdigit() or not (4 <= len(v) <= 8):
            raise ValueError('PIN must be 4-8 digits')
        return v


class UserProfileResponse(BaseModel):
    """Response model for user profile."""
    user_id: int
    age: Optional[int]
    is_child: bool
    parent_user_id: Optional[int]
    restrictions: List[str]
    created_at: datetime
    updated_at: datetime


class TimeUsageResponse(BaseModel):
    """Response model for time usage statistics."""
    user_id: int
    date: str
    total_minutes: int
    session_minutes: int
    last_activity: Optional[datetime]
    daily_limit: int
    session_limit: int


class UsageStatisticsResponse(BaseModel):
    """Response model for usage statistics."""
    user_id: int
    current_time_limits: TimeLimitsResponse
    time_usage_today: TimeUsageResponse
    profile: UserProfileResponse
    parental_pin_set: bool


# Helper functions

def get_user_id_from_token(current_user: Dict) -> int:
    """Extract user ID from JWT token payload."""
    try:
        # Assuming user_id is stored in token sub field as integer
        return int(current_user.get('sub', '').split('_')[-1])
    except (ValueError, IndexError):
        raise HTTPException(status_code=400, detail="Invalid user ID in token")


def convert_age_restriction_to_enum(age_str: str) -> AgeRestriction:
    """Convert string age restriction to enum."""
    mapping = {
        "all_ages": AgeRestriction.ALL_AGES,
        "7_plus": AgeRestriction.AGE_7_PLUS,
        "13_plus": AgeRestriction.AGE_13_PLUS,
        "16_plus": AgeRestriction.AGE_16_PLUS,
        "18_plus": AgeRestriction.AGE_18_PLUS
    }
    return mapping.get(age_str)


def convert_user_profile_to_response(profile: UserProfile) -> UserProfileResponse:
    """Convert UserProfile dataclass to Pydantic response."""
    return UserProfileResponse(
        user_id=profile.user_id,
        age=profile.age,
        is_child=profile.is_child,
        parent_user_id=profile.parent_user_id,
        restrictions=profile.restrictions,
        created_at=profile.created_at,
        updated_at=profile.updated_at
    )


def convert_time_usage_to_response(usage: TimeUsage) -> TimeUsageResponse:
    """Convert TimeUsage dataclass to Pydantic response."""
    return TimeUsageResponse(
        user_id=usage.user_id,
        date=usage.date,
        total_minutes=usage.total_minutes,
        session_minutes=usage.session_minutes,
        last_activity=usage.last_activity,
        daily_limit=usage.daily_limit,
        session_limit=usage.session_limit
    )


# API Endpoints

@router.post("/pin/set", response_model=ParentalPinResponse,
             summary="Establecer PIN parental",
             description="""
             Establece un PIN parental para el usuario actual.

             **Campos requeridos:**
             - pin: PIN de 4-8 dígitos numéricos

             **Códigos de respuesta:**
             - 200: PIN establecido exitosamente
             - 400: PIN inválido
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def set_parental_pin(
    request: ParentalPinSetRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Set parental PIN for current user.

    - Sets a new parental PIN
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Set PIN
        manager.set_parental_pin(user_id, request.pin)

        logger.info(f"Parental PIN set for user ID: {user_id}")
        return ParentalPinResponse(
            success=True,
            message="PIN parental establecido exitosamente",
            is_set=True
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Set parental PIN error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/pin/verify", response_model=ParentalPinResponse,
             summary="Verificar PIN parental",
             description="""
             Verifica el PIN parental del usuario actual.

             **Campos requeridos:**
             - pin: PIN a verificar (4-8 dígitos)

             **Códigos de respuesta:**
             - 200: PIN verificado exitosamente
             - 400: PIN inválido
             - 401: Usuario no autenticado
             - 403: PIN incorrecto
             - 500: Error interno del servidor
             """)
async def verify_parental_pin(
    request: ParentalPinVerifyRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Verify parental PIN for current user.

    - Verifies the provided PIN
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Verify PIN
        manager.verify_parental_pin(user_id, request.pin)

        logger.info(f"Parental PIN verified for user ID: {user_id}")
        return ParentalPinResponse(
            success=True,
            message="PIN parental verificado exitosamente",
            is_set=True
        )

    except InvalidParentalPinError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except ParentalControlDisabledError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Verify parental PIN error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/pin/status", response_model=ParentalPinResponse,
            summary="Verificar estado del PIN parental",
            description="""
            Verifica si hay un PIN parental configurado para el usuario actual.

            **Códigos de respuesta:**
            - 200: Estado del PIN obtenido exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def check_parental_pin_status(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Check if parental PIN is set for current user.

    - Returns PIN status
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Check PIN status
        is_set = manager.is_parental_pin_set(user_id)

        return ParentalPinResponse(
            success=True,
            message="Estado del PIN parental obtenido",
            is_set=is_set
        )

    except Exception as e:
        logger.error(f"Check parental PIN status error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/time-limits", response_model=TimeLimitsResponse,
            summary="Verificar límites de tiempo",
            description="""
            Verifica los límites de tiempo actuales para el usuario.

            **Devuelve:**
            - Si el acceso está permitido
            - Tiempo restante (minutos)
            - Tiempo usado hoy
            - Límite diario

            **Códigos de respuesta:**
            - 200: Límites de tiempo obtenidos exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def check_time_limits(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Check current time limits for user.

    - Returns time limits status
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Check time limits
        result = manager.check_time_limits(user_id)

        return TimeLimitsResponse(**result)

    except Exception as e:
        logger.error(f"Check time limits error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/time-usage/record",
             summary="Registrar uso de tiempo",
             description="""
             Registra minutos de uso para el usuario actual.

             **Campos requeridos:**
             - minutes: Minutos usados (debe ser positivo)

             **Campos opcionales:**
             - activity_type: Tipo de actividad (por defecto "general")

             **Códigos de respuesta:**
             - 200: Uso de tiempo registrado exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def record_time_usage(
    request: TimeUsageRecordRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Record time usage for current user.

    - Records minutes used
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Record time usage
        manager.record_time_usage(user_id, request.minutes, request.activity_type)

        logger.info(f"Time usage recorded for user ID: {user_id}, minutes: {request.minutes}")
        return {"message": "Uso de tiempo registrado exitosamente"}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Record time usage error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/time-usage/reset",
             summary="Resetear uso diario de tiempo",
             description="""
             Resetea el contador de uso diario de tiempo (tarea programada).

             **Códigos de respuesta:**
             - 200: Uso diario reseteado exitosamente
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def reset_daily_time_usage(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Reset daily time usage counter.

    - Resets daily usage to zero
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Reset daily usage
        manager.reset_daily_usage(user_id)

        logger.info(f"Daily time usage reset for user ID: {user_id}")
        return {"message": "Uso diario de tiempo reseteado exitosamente"}

    except Exception as e:
        logger.error(f"Reset daily time usage error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/content/check", response_model=ContentCheckResponse,
             summary="Verificar acceso a contenido",
             description="""
             Verifica si el contenido está permitido según los filtros parentales.

             **Campos requeridos:**
             - content: Contenido a verificar

             **Campos opcionales:**
             - content_type: Tipo de contenido ("text", "url", etc.)

             **Devuelve:**
             - Si el acceso está permitido
             - Puntaje de riesgo
             - Categorías detectadas
             - Nivel de filtro aplicado

             **Códigos de respuesta:**
             - 200: Verificación completada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def check_content_access(
    request: ContentCheckRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Check if content is allowed by parental filters.

    - Analyzes content against filters
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Check content access
        result = manager.check_content_access(user_id, request.content, request.content_type)

        return ContentCheckResponse(**result)

    except Exception as e:
        logger.error(f"Check content access error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/content/moderate", response_model=ContentModerateResponse,
             summary="Moderar contenido en tiempo real",
             description="""
             Modera contenido aplicando filtros parentales en tiempo real.

             **Campos requeridos:**
             - content: Contenido a moderar

             **Campos opcionales:**
             - content_type: Tipo de contenido ("text", "url", etc.)

             **Devuelve:**
             - Contenido original
             - Contenido moderado
             - Si fue moderado

             **Códigos de respuesta:**
             - 200: Moderación completada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 403: Contenido bloqueado
             - 500: Error interno del servidor
             """)
async def moderate_content(
    request: ContentModerateRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Moderate content in real-time using parental filters.

    - Applies content moderation
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Moderate content
        moderated = manager.moderate_content_realtime(user_id, request.content, request.content_type)

        was_moderated = moderated != request.content

        return ContentModerateResponse(
            original_content=request.content,
            moderated_content=moderated,
            was_moderated=was_moderated
        )

    except ContentBlockedError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except Exception as e:
        logger.error(f"Moderate content error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/age/validate", response_model=AgeValidationResponse,
             summary="Validar acceso por edad",
             description="""
             Valida si el usuario puede acceder a contenido basado en restricciones de edad.

             **Campos requeridos:**
             - required_age: Edad mínima requerida ("all_ages", "7_plus", "13_plus", "16_plus", "18_plus")

             **Campos opcionales:**
             - content_category: Categoría específica de contenido

             **Devuelve:**
             - Si el acceso está permitido
             - Razón del resultado
             - Edad del usuario

             **Códigos de respuesta:**
             - 200: Validación completada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 403: Acceso denegado por edad
             - 500: Error interno del servidor
             """)
async def validate_age_access(
    request: AgeValidationRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Validate age-based access to content.

    - Checks age restrictions
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Convert age restriction
        age_restriction = convert_age_restriction_to_enum(request.required_age)

        # Validate age access
        allowed = manager.validate_age_access(user_id, age_restriction, request.content_category)

        # Get user profile for age info
        profile = manager._get_user_profile(user_id)

        reason = "Acceso permitido" if allowed else "Acceso denegado por restricción de edad"

        return AgeValidationResponse(
            allowed=allowed,
            reason=reason,
            user_age=profile.age
        )

    except AgeRestrictionError as e:
        return AgeValidationResponse(
            allowed=False,
            reason=str(e),
            user_age=None
        )
    except Exception as e:
        logger.error(f"Validate age access error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/user/age", response_model=UserProfileResponse,
            summary="Establecer edad del usuario",
            description="""
            Establece la edad del usuario actual (requiere PIN parental).

            **Campos requeridos:**
            - age: Edad en años (1-120)
            - parent_pin: PIN parental para autorización

            **Códigos de respuesta:**
            - 200: Edad actualizada exitosamente
            - 400: Datos inválidos
            - 401: Usuario no autenticado
            - 403: PIN parental incorrecto
            - 500: Error interno del servidor
            """)
async def set_user_age(
    request: UserAgeSetRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Set user age (requires parental PIN).

    - Sets user age with parental authorization
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Set user age
        manager.set_user_age(user_id, request.age, request.parent_pin)

        # Get updated profile
        profile = manager._get_user_profile(user_id)

        logger.info(f"User age set for user ID: {user_id}, age: {request.age}")
        return convert_user_profile_to_response(profile)

    except InvalidParentalPinError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Set user age error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/user/profile", response_model=UserProfileResponse,
            summary="Obtener perfil del usuario",
            description="""
            Obtiene el perfil parental del usuario actual.

            **Devuelve:**
            - ID del usuario
            - Edad
            - Si es menor de edad
            - ID del padre/tutor
            - Restricciones aplicadas
            - Fechas de creación y actualización

            **Códigos de respuesta:**
            - 200: Perfil obtenido exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def get_user_profile(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's parental profile.

    - Returns user profile information
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Get user profile
        profile = manager._get_user_profile(user_id)

        return convert_user_profile_to_response(profile)

    except Exception as e:
        logger.error(f"Get user profile error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/time-usage", response_model=TimeUsageResponse,
            summary="Obtener uso de tiempo actual",
            description="""
            Obtiene las estadísticas de uso de tiempo del usuario actual.

            **Devuelve:**
            - Minutos totales usados hoy
            - Minutos de sesión actual
            - Última actividad
            - Límites diarios y de sesión

            **Códigos de respuesta:**
            - 200: Estadísticas obtenidas exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def get_time_usage(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current time usage statistics for user.

    - Returns time usage data
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Get time usage
        usage = manager._get_time_usage(user_id)

        return convert_time_usage_to_response(usage)

    except Exception as e:
        logger.error(f"Get time usage error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/statistics", response_model=UsageStatisticsResponse,
            summary="Obtener estadísticas completas de uso",
            description="""
            Obtiene estadísticas completas de uso parental para el usuario actual.

            **Devuelve:**
            - Estado actual de límites de tiempo
            - Uso de tiempo de hoy
            - Perfil del usuario
            - Estado del PIN parental

            **Códigos de respuesta:**
            - 200: Estadísticas obtenidas exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def get_usage_statistics(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get complete usage statistics for parental controls.

    - Returns comprehensive usage data
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get parental controls manager
        manager = get_parental_controls_manager()

        # Get all statistics
        time_limits = manager.check_time_limits(user_id)
        time_usage = manager._get_time_usage(user_id)
        profile = manager._get_user_profile(user_id)
        pin_set = manager.is_parental_pin_set(user_id)

        return UsageStatisticsResponse(
            user_id=user_id,
            current_time_limits=TimeLimitsResponse(**time_limits),
            time_usage_today=convert_time_usage_to_response(time_usage),
            profile=convert_user_profile_to_response(profile),
            parental_pin_set=pin_set
        )

    except Exception as e:
        logger.error(f"Get usage statistics error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")