"""
Servicio de hibernación inteligente para nodos inactivos.
Implementa zero-scaling automático para reducir costos de cómputo.
"""

from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from ..models.base import Node, FederatedSession, SessionParticipant, Contribution
from ..core.exceptions import NodeNotFoundError
from .node_service import NodeService
from .session_service import SessionService


class HibernationService:
    """Servicio para gestionar hibernación automática de nodos."""

    @staticmethod
    async def check_inactive_nodes(
        db: Session,
        inactivity_threshold_minutes: int = 30,
        contribution_threshold_hours: int = 24
    ) -> List[Dict[str, Any]]:
        """
        Detecta nodos inactivos que pueden ser hibernados.

        Args:
            db: Sesión de base de datos
            inactivity_threshold_minutes: Minutos sin heartbeat para considerar inactivo
            contribution_threshold_hours: Horas sin contribuciones para considerar inactivo

        Returns:
            Lista de nodos candidatos a hibernación
        """
        now = datetime.utcnow()
        heartbeat_threshold = now - timedelta(minutes=inactivity_threshold_minutes)
        contribution_threshold = now - timedelta(hours=contribution_threshold_hours)

        # Nodos con heartbeat antiguo
        inactive_nodes = db.query(Node).filter(
            and_(
                Node.status.in_(["active", "registered"]),
                or_(
                    Node.last_heartbeat.is_(None),
                    Node.last_heartbeat < heartbeat_threshold
                )
            )
        ).all()

        candidates = []

        for node in inactive_nodes:
            # Verificar si tiene contribuciones recientes
            recent_contributions = db.query(Contribution).filter(
                and_(
                    Contribution.node_id == node.id,
                    Contribution.submitted_at > contribution_threshold
                )
            ).count()

            # Verificar si está en sesiones activas
            active_sessions = db.query(SessionParticipant).join(FederatedSession).filter(
                and_(
                    SessionParticipant.node_id == node.id,
                    FederatedSession.status.in_(["active", "running"])
                )
            ).count()

            # Si no tiene contribuciones recientes ni sesiones activas, es candidato
            if recent_contributions == 0 and active_sessions == 0:
                candidates.append({
                    "node_id": node.id,
                    "last_heartbeat": node.last_heartbeat,
                    "last_contribution": db.query(func.max(Contribution.submitted_at)).filter(
                        Contribution.node_id == node.id
                    ).scalar(),
                    "active_sessions": active_sessions,
                    "recent_contributions": recent_contributions
                })

        return candidates

    @staticmethod
    async def hibernate_node(
        db: Session,
        node_id: str,
        reason: str = "automatic_inactivity"
    ) -> bool:
        """
        Pone un nodo en hibernación.

        Args:
            db: Sesión de base de datos
            node_id: ID del nodo
            reason: Razón de la hibernación

        Returns:
            True si se hibernó exitosamente
        """
        try:
            node = db.query(Node).filter(Node.id == node_id).first()
            if not node:
                raise NodeNotFoundError(node_id)

            if node.status == "hibernated":
                return True  # Ya está hibernado

            # Cambiar status
            node.status = "hibernated"
            node.updated_at = datetime.utcnow()

            # TODO: Enviar notificación al nodo vía WebSocket
            # await _notify_node_hibernation(node_id, reason)

            db.commit()
            return True

        except Exception as e:
            db.rollback()
            raise e

    @staticmethod
    async def wake_up_node(
        db: Session,
        node_id: str,
        reason: str = "demand_detected"
    ) -> bool:
        """
        Activa un nodo hibernado.

        Args:
            db: Sesión de base de datos
            node_id: ID del nodo
            reason: Razón del wake-up

        Returns:
            True si se activó exitosamente
        """
        try:
            node = db.query(Node).filter(Node.id == node_id).first()
            if not node:
                raise NodeNotFoundError(node_id)

            if node.status != "hibernated":
                return True  # Ya está activo

            # Cambiar status a registered (para que se reactive)
            node.status = "registered"
            node.updated_at = datetime.utcnow()

            # TODO: Enviar notificación al nodo vía WebSocket
            # await _notify_node_wake_up(node_id, reason)

            db.commit()
            return True

        except Exception as e:
            db.rollback()
            raise e

    @staticmethod
    async def get_hibernation_stats(db: Session) -> Dict[str, Any]:
        """
        Obtiene estadísticas de hibernación.

        Returns:
            Diccionario con estadísticas
        """
        total_nodes = db.query(Node).count()
        active_nodes = db.query(Node).filter(Node.status == "active").count()
        hibernated_nodes = db.query(Node).filter(Node.status == "hibernated").count()
        registered_nodes = db.query(Node).filter(Node.status == "registered").count()

        return {
            "total_nodes": total_nodes,
            "active_nodes": active_nodes,
            "hibernated_nodes": hibernated_nodes,
            "registered_nodes": registered_nodes,
            "hibernation_rate": hibernated_nodes / total_nodes if total_nodes > 0 else 0
        }

    @staticmethod
    async def auto_hibernate_inactive_nodes(
        db: Session,
        inactivity_threshold_minutes: int = 30,
        contribution_threshold_hours: int = 24,
        max_hibernations_per_run: int = 10
    ) -> Dict[str, Any]:
        """
        Ejecuta hibernación automática de nodos inactivos.

        Args:
            db: Sesión de base de datos
            inactivity_threshold_minutes: Umbral de inactividad en minutos
            contribution_threshold_hours: Umbral de contribuciones en horas
            max_hibernations_per_run: Máximo de hibernaciones por ejecución

        Returns:
            Resultado de la operación
        """
        candidates = await HibernationService.check_inactive_nodes(
            db, inactivity_threshold_minutes, contribution_threshold_hours
        )

        hibernated_count = 0
        errors = []

        for candidate in candidates[:max_hibernations_per_run]:
            try:
                success = await HibernationService.hibernate_node(
                    db, candidate["node_id"], "auto_hibernation"
                )
                if success:
                    hibernated_count += 1
            except Exception as e:
                errors.append(f"Error hibernando {candidate['node_id']}: {str(e)}")

        return {
            "candidates_found": len(candidates),
            "hibernated_count": hibernated_count,
            "errors": errors
        }

    @staticmethod
    async def should_wake_up_nodes(db: Session) -> bool:
        """
        Determina si hay demanda suficiente para despertar nodos.

        Returns:
            True si hay demanda
        """
        # Verificar sesiones activas que necesitan más nodos
        active_sessions = db.query(FederatedSession).filter(
            FederatedSession.status.in_(["active", "running"])
        ).all()

        for session in active_sessions:
            current_participants = db.query(SessionParticipant).filter(
                and_(
                    SessionParticipant.session_id == session.id,
                    SessionParticipant.status == "active"
                )
            ).count()

            if current_participants < session.min_nodes:
                return True

        # Verificar si hay contribuciones pendientes
        pending_contributions = db.query(Contribution).filter(
            Contribution.status == "pending"
        ).count()

        return pending_contributions > 0

    @staticmethod
    async def wake_up_nodes_for_demand(
        db: Session,
        max_wake_ups: int = 5
    ) -> Dict[str, Any]:
        """
        Despierta nodos hibernados cuando hay demanda.

        Args:
            db: Sesión de base de datos
            max_wake_ups: Máximo de wake-ups por ejecución

        Returns:
            Resultado de la operación
        """
        if not await HibernationService.should_wake_up_nodes(db):
            return {"woke_up_count": 0, "reason": "no_demand"}

        # Obtener nodos hibernados ordenados por reputación
        hibernated_nodes = db.query(Node).filter(
            Node.status == "hibernated"
        ).order_by(Node.reputation_score.desc()).limit(max_wake_ups).all()

        woke_up_count = 0
        errors = []

        for node in hibernated_nodes:
            try:
                success = await HibernationService.wake_up_node(
                    db, node.id, "demand_detected"
                )
                if success:
                    woke_up_count += 1
            except Exception as e:
                errors.append(f"Error despertando {node.id}: {str(e)}")

        return {
            "woke_up_count": woke_up_count,
            "errors": errors
        }