"""
Service layer for federated session management operations.
"""

from datetime import datetime, timedelta
from typing import List, Optional, Tuple, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func
import logging

from ..models.base import FederatedSession, SessionParticipant, Node, Model
from ..models.schemas import (
    FederatedSessionResponse, FederatedSessionCreate, FederatedSessionUpdate,
    SessionParticipantResponse
)
from ..core.exceptions import SessionNotFoundError, ValidationError, NodeNotFoundError
from ..core.config import Config
from ..consensus_manager import get_consensus_manager
from ...verification.contribution_verifier import ContributionVerifier, VerificationResult

logger = logging.getLogger(__name__)


class SessionService:
    """Service for managing federated learning sessions."""

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.contribution_verifier = ContributionVerifier(self.config)

    @staticmethod
    async def list_sessions(
        db: Session,
        skip: int = 0,
        limit: int = 100,
        status: Optional[str] = None,
        model_type: Optional[str] = None,
        coordinator_node_id: Optional[str] = None
    ) -> Tuple[List[FederatedSessionResponse], int]:
        """List sessions with optional filtering."""
        query = db.query(FederatedSession)

        # Apply filters
        if status:
            query = query.filter(FederatedSession.status == status)
        if model_type:
            query = query.filter(FederatedSession.model_type == model_type)
        if coordinator_node_id:
            query = query.filter(FederatedSession.coordinator_node_id == coordinator_node_id)

        # Get total count
        total = query.count()

        # Apply pagination
        sessions = query.offset(skip).limit(limit).all()

        # Convert to response models
        session_responses = []
        for session in sessions:
            session_responses.append(FederatedSessionResponse(
                id=session.id,
                name=session.name,
                description=session.description,
                model_type=session.model_type,
                dataset_info=session.dataset_info,
                configuration=session.configuration,
                min_nodes=session.min_nodes,
                max_nodes=session.max_nodes,
                total_rounds=session.total_rounds,
                status=session.status,
                coordinator_node_id=session.coordinator_node_id,
                current_round=session.current_round,
                started_at=session.started_at,
                completed_at=session.completed_at,
                estimated_completion=session.estimated_completion,
                created_at=session.created_at,
                updated_at=session.updated_at
            ))

        return session_responses, total

    @staticmethod
    async def get_session_by_id(db: Session, session_id: str) -> FederatedSessionResponse:
        """Get a session by ID."""
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            raise SessionNotFoundError(session_id)

        return FederatedSessionResponse(
            id=session.id,
            name=session.name,
            description=session.description,
            model_type=session.model_type,
            dataset_info=session.dataset_info,
            configuration=session.configuration,
            min_nodes=session.min_nodes,
            max_nodes=session.max_nodes,
            total_rounds=session.total_rounds,
            status=session.status,
            coordinator_node_id=session.coordinator_node_id,
            current_round=session.current_round,
            started_at=session.started_at,
            completed_at=session.completed_at,
            estimated_completion=session.estimated_completion,
            created_at=session.created_at,
            updated_at=session.updated_at
        )

    @staticmethod
    async def create_session(
        db: Session,
        session_data: FederatedSessionCreate,
        coordinator_node_id: Optional[str] = None
    ) -> FederatedSessionResponse:
        """Create a new federated session."""
        # Validate coordinator node if provided
        if coordinator_node_id:
            coordinator = db.query(Node).filter(Node.id == coordinator_node_id).first()
            if not coordinator:
                raise NodeNotFoundError(coordinator_node_id)

        # Create session
        session = FederatedSession(
            id=session_data.id,
            name=session_data.name,
            description=session_data.description,
            model_type=session_data.model_type,
            dataset_info=session_data.dataset_info,
            configuration=session_data.configuration,
            min_nodes=session_data.min_nodes,
            max_nodes=session_data.max_nodes,
            total_rounds=session_data.total_rounds,
            coordinator_node_id=coordinator_node_id
        )

        db.add(session)
        db.commit()
        db.refresh(session)

        return await SessionService.get_session_by_id(db, session.id)

    @staticmethod
    async def update_session(
        db: Session,
        session_id: str,
        session_update: FederatedSessionUpdate
    ) -> FederatedSessionResponse:
        """Update session information."""
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            raise SessionNotFoundError(session_id)

        # Update fields
        update_data = session_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(session, field, value)

        session.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(session)

        return await SessionService.get_session_by_id(db, session_id)

    @staticmethod
    async def delete_session(db: Session, session_id: str) -> None:
        """Delete a session."""
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            raise SessionNotFoundError(session_id)

        # Check if session can be deleted (not active)
        if session.status in ['active', 'running']:
            raise ValidationError("Cannot delete active session")

        db.delete(session)
        db.commit()

    @staticmethod
    async def start_session(db: Session, session_id: str) -> FederatedSessionResponse:
        """Start a federated session."""
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            raise SessionNotFoundError(session_id)

        if session.status != 'created':
            raise ValidationError(f"Session is already {session.status}")

        # Check minimum participants
        participant_count = db.query(SessionParticipant).filter(
            and_(
                SessionParticipant.session_id == session_id,
                SessionParticipant.status == 'joined'
            )
        ).count()

        if participant_count < session.min_nodes:
            raise ValidationError(f"Insufficient participants: {participant_count}/{session.min_nodes}")

        # Propose session start via consensus
        consensus_manager = get_consensus_manager()
        if consensus_manager:
            success, message = await consensus_manager.propose_critical_operation(
                'start_session',
                {
                    'session_id': session_id,
                    'name': session.name,
                    'model_type': session.model_type,
                    'min_nodes': session.min_nodes,
                    'max_nodes': session.max_nodes,
                    'total_rounds': session.total_rounds
                }
            )

            if not success:
                raise ValidationError(f"Consensus failed for session start: {message}")

        # Start session
        session.status = 'active'
        session.started_at = datetime.utcnow()
        session.current_round = 1

        # Calculate estimated completion
        avg_round_time = session.configuration.get('estimated_round_time_hours', 24) if session.configuration else 24
        session.estimated_completion = session.started_at + timedelta(hours=avg_round_time * session.total_rounds)

        db.commit()
        db.refresh(session)

        # Broadcast session start event
        from ..websocket.event_broadcaster import event_broadcaster
        from ..websocket.notification_service import notification_service

        await event_broadcaster.notify_session_started(session_id, {
            "name": session.name,
            "model_type": session.model_type,
            "min_nodes": session.min_nodes,
            "max_nodes": session.max_nodes,
            "total_rounds": session.total_rounds
        })

        # Send notifications to participants
        await notification_service.notify_on_session_start(session_id, {
            "name": session.name,
            "model_type": session.model_type
        })

        # Iniciar descarga simultánea del modelo inicial a todos los nodos participantes
        await SessionService._start_concurrent_model_download(db, session_id)

        return await SessionService.get_session_by_id(db, session_id)

    @staticmethod
    async def complete_session(db: Session, session_id: str) -> FederatedSessionResponse:
        """Complete a federated session."""
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            raise SessionNotFoundError(session_id)

        if session.status not in ['active', 'running']:
            raise ValidationError(f"Session is not active: {session.status}")

        # Propose session completion via consensus
        consensus_manager = get_consensus_manager()
        if consensus_manager:
            success, message = await consensus_manager.propose_critical_operation(
                'complete_session',
                {
                    'session_id': session_id,
                    'completed_at': datetime.utcnow().isoformat(),
                    'total_rounds': session.current_round,
                    'status': 'completed'
                }
            )

            if not success:
                raise ValidationError(f"Consensus failed for session completion: {message}")

        session.status = 'completed'
        session.completed_at = datetime.utcnow()

        db.commit()
        db.refresh(session)

        # Broadcast session completion event
        from ..websocket.event_broadcaster import event_broadcaster
        from ..websocket.notification_service import notification_service

        await event_broadcaster.notify_session_completed(session_id, {
            "completed_at": session.completed_at.isoformat(),
            "total_rounds": session.current_round,
            "status": "completed"
        })

        # Send notifications to participants
        await notification_service.notify_on_session_complete(session_id, {
            "completed_at": session.completed_at.isoformat(),
            "total_rounds": session.current_round
        })

        return await SessionService.get_session_by_id(db, session_id)

    @staticmethod
    async def add_participant(
        db: Session,
        session_id: str,
        node_id: str
    ) -> SessionParticipantResponse:
        """Add a node as participant to a session."""
        # Validate session
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            raise SessionNotFoundError(session_id)

        # Validate node
        node = db.query(Node).filter(Node.id == node_id).first()
        if not node:
            raise NodeNotFoundError(node_id)

        # Check if already participant
        existing = db.query(SessionParticipant).filter(
            and_(
                SessionParticipant.session_id == session_id,
                SessionParticipant.node_id == node_id
            )
        ).first()

        if existing:
            raise ValidationError(f"Node {node_id} is already a participant in session {session_id}")

        # Check max participants
        current_count = db.query(SessionParticipant).filter(
            SessionParticipant.session_id == session_id
        ).count()

        if current_count >= session.max_nodes:
            raise ValidationError(f"Session has reached maximum participants: {session.max_nodes}")

        # Create participant
        participant = SessionParticipant(
            session_id=session_id,
            node_id=node_id,
            status='invited'
        )

        db.add(participant)
        db.commit()
        db.refresh(participant)

        return SessionParticipantResponse(
            session_id=participant.session_id,
            node_id=participant.node_id,
            status=participant.status,
            joined_at=participant.joined_at,
            last_contribution_at=participant.last_contribution_at,
            contributions_count=participant.contributions_count,
            rewards_earned=participant.rewards_earned,
            performance_metrics=participant.performance_metrics,
            created_at=participant.created_at,
            updated_at=participant.updated_at
        )

    @staticmethod
    async def join_session(db: Session, session_id: str, node_id: str) -> SessionParticipantResponse:
        """Node joins a session."""
        participant = db.query(SessionParticipant).filter(
            and_(
                SessionParticipant.session_id == session_id,
                SessionParticipant.node_id == node_id
            )
        ).first()

        if not participant:
            raise ValidationError(f"Node {node_id} is not invited to session {session_id}")

        if participant.status != 'invited':
            raise ValidationError(f"Participant status is {participant.status}")

        participant.status = 'joined'
        participant.joined_at = datetime.utcnow()

        db.commit()
        db.refresh(participant)

        return SessionParticipantResponse(
            session_id=participant.session_id,
            node_id=participant.node_id,
            status=participant.status,
            joined_at=participant.joined_at,
            last_contribution_at=participant.last_contribution_at,
            contributions_count=participant.contributions_count,
            rewards_earned=participant.rewards_earned,
            performance_metrics=participant.performance_metrics,
            created_at=participant.created_at,
            updated_at=participant.updated_at
        )

    @staticmethod
    async def get_session_participants(
        db: Session,
        session_id: str,
        status: Optional[str] = None
    ) -> List[SessionParticipantResponse]:
        """Get participants for a session."""
        query = db.query(SessionParticipant).filter(SessionParticipant.session_id == session_id)

        if status:
            query = query.filter(SessionParticipant.status == status)

        participants = query.all()

        return [
            SessionParticipantResponse(
                session_id=p.session_id,
                node_id=p.node_id,
                status=p.status,
                joined_at=p.joined_at,
                last_contribution_at=p.last_contribution_at,
                contributions_count=p.contributions_count,
                rewards_earned=p.rewards_earned,
                performance_metrics=p.performance_metrics,
                created_at=p.created_at,
                updated_at=p.updated_at
            )
            for p in participants
        ]

    @staticmethod
    async def get_active_sessions_count(db: Session) -> int:
        """Get count of active sessions."""
        return db.query(FederatedSession).filter(
            FederatedSession.status.in_(['active', 'running'])
        ).count()

    @staticmethod
    async def get_sessions_by_status(db: Session, status: str, limit: Optional[int] = None) -> List[FederatedSessionResponse]:
        """Get sessions by status."""
        query = db.query(FederatedSession).filter(FederatedSession.status == status)

        if limit:
            query = query.limit(limit)

        sessions = query.all()

        return [
            FederatedSessionResponse(
                id=s.id,
                name=s.name,
                description=s.description,
                model_type=s.model_type,
                dataset_info=s.dataset_info,
                configuration=s.configuration,
                min_nodes=s.min_nodes,
                max_nodes=s.max_nodes,
                total_rounds=s.total_rounds,
                status=s.status,
                coordinator_node_id=s.coordinator_node_id,
                current_round=s.current_round,
                started_at=s.started_at,
                completed_at=s.completed_at,
                estimated_completion=s.estimated_completion,
                created_at=s.created_at,
                updated_at=s.updated_at
            )
            for s in sessions
        ]

    async def validate_contribution(
        self,
        db: Session,
        session_id: str,
        node_id: str,
        contribution_data: Dict[str, Any]
    ) -> VerificationResult:
        """
        Valida una contribución usando verificación ZKP.

        Args:
            db: Sesión de base de datos
            session_id: ID de la sesión
            node_id: ID del nodo
            contribution_data: Datos de la contribución incluyendo:
                - training_proof: Prueba ZKP de entrenamiento
                - model_parameters: Parámetros del modelo
                - training_metadata: Metadatos del entrenamiento
                - node_signature: Firma digital del nodo
                - node_public_key: Clave pública del nodo

        Returns:
            VerificationResult: Resultado de la verificación
        """
        try:
            logger.info(f"🔍 Iniciando validación ZKP para contribución de nodo {node_id} en sesión {session_id}")

            # Obtener información de la sesión
            session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
            if not session:
                raise SessionNotFoundError(session_id)

            # Obtener información del nodo
            node = db.query(Node).filter(Node.id == node_id).first()
            if not node:
                raise NodeNotFoundError(node_id)

            # Extraer datos de contribución
            training_proof = contribution_data.get('training_proof', {})
            model_parameters = contribution_data.get('model_parameters', {})
            training_metadata = contribution_data.get('training_metadata', {})
            node_signature = contribution_data.get('node_signature', '')
            node_public_key = contribution_data.get('node_public_key', node.public_key)

            # Generar ID único para la contribución
            contribution_id = f"{session_id}_{node_id}_{session.current_round}"

            # Verificar contribución usando ZKP
            verification_result = await self.contribution_verifier.verify_contribution(
                node_id=node_id,
                session_id=session_id,
                round_number=session.current_round,
                contribution_id=contribution_id,
                training_proof=training_proof,
                model_parameters=model_parameters,
                training_metadata=training_metadata,
                node_signature=node_signature,
                node_public_key=node_public_key,
                session_context={
                    'session_type': session.model_type,
                    'current_round': session.current_round,
                    'total_rounds': session.total_rounds
                }
            )

            # Procesar resultado de verificación
            if verification_result.is_valid:
                logger.info(f"✅ Contribución válida de nodo {node_id} - Actualizando reputación")
                await self._update_node_reputation(db, node_id, verification_result.confidence_score)
            else:
                logger.warning(f"❌ Contribución inválida de nodo {node_id} - Razones: {verification_result.failure_reasons}")
                await self._flag_suspicious_node(db, node_id, verification_result.failure_reasons)

            # Log detallado
            logger.info(f"📊 Resultado verificación: confianza={verification_result.confidence_score:.3f}, "
                       f"riesgo={verification_result.risk_level}, "
                       f"válido={verification_result.is_valid}")

            return verification_result

        except Exception as e:
            logger.error(f"❌ Error durante validación ZKP de contribución {node_id}: {str(e)}")
            # Crear resultado de error
            error_result = VerificationResult(
                node_id=node_id,
                session_id=session_id,
                round_number=0,  # No disponible en error
                contribution_id=f"{session_id}_{node_id}_error",
                is_valid=False,
                confidence_score=0.0,
                risk_level="critical",
                failure_reasons=[f"Error interno: {str(e)}"]
            )
            await self._flag_suspicious_node(db, node_id, error_result.failure_reasons)
            return error_result

    async def _flag_suspicious_node(
        self,
        db: Session,
        node_id: str,
        failure_reasons: List[str]
    ) -> None:
        """
        Marca un nodo como sospechoso basado en fallos de verificación.

        Args:
            db: Sesión de base de datos
            node_id: ID del nodo
            failure_reasons: Razones del fallo
        """
        try:
            node = db.query(Node).filter(Node.id == node_id).first()
            if not node:
                logger.warning(f"Nodo {node_id} no encontrado para marcar como sospechoso")
                return

            # Actualizar estado del nodo
            node.status = 'suspicious'
            node.trust_level = 'suspicious'
            node.reputation_score = max(0.0, node.reputation_score - 0.3)  # Penalización significativa

            # Log de auditoría
            logger.warning(f"🚨 Nodo {node_id} marcado como sospechoso. Razones: {failure_reasons}")

            # Notificar vía websocket si es necesario
            from ..websocket.event_broadcaster import event_broadcaster
            await event_broadcaster.notify_node_suspicious(node_id, {
                "failure_reasons": failure_reasons,
                "new_reputation": node.reputation_score
            })

            db.commit()

        except Exception as e:
            logger.error(f"Error marcando nodo {node_id} como sospechoso: {str(e)}")
            db.rollback()

    async def _update_node_reputation(
        self,
        db: Session,
        node_id: str,
        confidence_score: float
    ) -> None:
        """
        Actualiza la reputación de un nodo basado en contribuciones válidas.

        Args:
            db: Sesión de base de datos
            node_id: ID del nodo
            confidence_score: Puntuación de confianza de la verificación
        """
        try:
            node = db.query(Node).filter(Node.id == node_id).first()
            if not node:
                logger.warning(f"Nodo {node_id} no encontrado para actualizar reputación")
                return

            # Calcular nueva reputación (promedio ponderado)
            current_reputation = node.reputation_score
            # Dar más peso a contribuciones recientes
            new_reputation = (current_reputation * 0.7) + (confidence_score * 0.3)
            new_reputation = max(0.0, min(1.0, new_reputation))  # Clamp entre 0 y 1

            node.reputation_score = new_reputation

            # Actualizar nivel de confianza basado en reputación
            if new_reputation >= 0.8:
                node.trust_level = 'high'
            elif new_reputation >= 0.6:
                node.trust_level = 'medium'
            else:
                node.trust_level = 'low'

            # Log de actualización
            logger.info(f"📈 Reputación de nodo {node_id} actualizada: {current_reputation:.3f} -> {new_reputation:.3f}")

            db.commit()

        except Exception as e:
            logger.error(f"Error actualizando reputación de nodo {node_id}: {str(e)}")
            db.rollback()

    @staticmethod
    async def _start_concurrent_model_download(db: Session, session_id: str):
        """Iniciar descarga simultánea del modelo inicial a nodos participantes."""
        try:
            # Obtener información de la sesión
            session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
            if not session:
                logger.error(f"Session {session_id} not found for concurrent download")
                return

            # Obtener nodos participantes que han unido la sesión
            participants = db.query(SessionParticipant).filter(
                and_(
                    SessionParticipant.session_id == session_id,
                    SessionParticipant.status == 'joined'
                )
            ).all()

            if not participants:
                logger.warning(f"No joined participants found for session {session_id}")
                return

            node_ids = [p.node_id for p in participants]
            logger.info(f"Starting concurrent download for session {session_id} to {len(node_ids)} nodes")

            # Buscar modelo inicial para la sesión
            # Primero buscar modelos existentes para esta sesión
            model = db.query(Model).filter(
                and_(
                    Model.session_id == session_id,
                    Model.status == 'active'
                )
            ).order_by(Model.created_at.desc()).first()

            # Si no hay modelo para la sesión, buscar el modelo más reciente del tipo correcto
            if not model:
                model = db.query(Model).filter(
                    and_(
                        Model.model_type == session.model_type,
                        Model.is_public == True
                    )
                ).order_by(Model.created_at.desc()).first()

            if not model:
                logger.error(f"No suitable model found for session {session_id} (type: {session.model_type})")
                return

            # Importar y usar el servicio de descarga concurrente
            from .concurrent_download_service import get_concurrent_download_service
            download_service = get_concurrent_download_service()

            # Iniciar descarga concurrente
            result = await download_service.start_concurrent_download(
                session_id=session_id,
                model_id=model.id,
                node_ids=node_ids
            )

            logger.info(f"Concurrent download initiated for session {session_id}: "
                       f"{result.successful_downloads}/{result.total_nodes} successful")

        except Exception as e:
            logger.error(f"Error starting concurrent model download for session {session_id}: {str(e)}")