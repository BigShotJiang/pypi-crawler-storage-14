"""
EmpoorioLM Version Controller
Controlador de versiones activas para el servicio EmpoorioLM.
"""

import asyncio
import time
import threading
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
import logging
from collections import defaultdict

from .version_manager import EmpoorioLMVersionManager

logger = logging.getLogger(__name__)


@dataclass
class ActiveVersion:
    """Versión activa con métricas de uso."""

    version_id: str
    model_name: str
    activated_at: float
    last_used: float
    usage_count: int = 0
    error_count: int = 0
    avg_response_time: float = 0.0
    is_default: bool = False
    traffic_percentage: float = 0.0  # 0.0-1.0


@dataclass
class VersionControllerConfig:
    """Configuración del Version Controller."""

    # Configuración de versiones activas
    max_active_versions: int = 5
    default_version_ttl_hours: int = 24

    # Configuración de A/B testing
    enable_ab_testing: bool = True
    ab_test_traffic_split: Dict[str, float] = field(default_factory=dict)  # version -> percentage

    # Configuración de canary deployments
    enable_canary_deployments: bool = True
    canary_traffic_percentage: float = 0.1  # 10% inicial

    # Configuración de fallback
    enable_fallback_versions: bool = True
    fallback_versions: List[str] = field(default_factory=list)

    # Configuración de monitoreo
    enable_performance_monitoring: bool = True
    performance_check_interval_seconds: int = 300  # 5 minutos

    # Configuración de auto-scaling
    enable_auto_promotion: bool = True
    promotion_threshold_success_rate: float = 0.95
    demotion_threshold_error_rate: float = 0.05


class VersionController:
    """
    Controlador de versiones activas para EmpoorioLM.

    Funcionalidades:
    - Gestión de versiones activas
    - A/B testing entre versiones
    - Canary deployments
    - Auto-promotion/demotion basado en métricas
    - Fallback automático
    - Routing inteligente de requests
    """

    def __init__(self, config: VersionControllerConfig, version_manager: EmpoorioLMVersionManager):
        self.config = config
        self.version_manager = version_manager

        # Estado de versiones activas
        self.active_versions: Dict[str, ActiveVersion] = {}
        self.default_version: Optional[str] = None

        # Estadísticas de routing
        self.routing_stats = {
            "total_requests": 0,
            "version_routing": defaultdict(int),
            "ab_test_distributions": defaultdict(int),
            "fallback_activations": 0
        }

        # Locks para thread safety
        self.routing_lock = threading.RLock()

        # Monitoreo
        self.monitoring_active = False
        self.monitoring_thread: Optional[threading.Thread] = None

        logger.info(f"🎛️ Version Controller inicializado - Max versiones activas: {config.max_active_versions}")

    async def activate_version(
        self,
        version_id: str,
        model_name: str = "EmpoorioLM",
        is_default: bool = False,
        traffic_percentage: Optional[float] = None
    ) -> bool:
        """
        Activar una versión para uso en producción.

        Args:
            version_id: ID de la versión
            model_name: Nombre del modelo
            is_default: Si es la versión por defecto
            traffic_percentage: Porcentaje de tráfico (0.0-1.0)

        Returns:
            True si se activó correctamente
        """
        try:
            # Verificar que la versión existe
            version_info = self.version_manager.get_version_info(version_id)
            if not version_info:
                logger.error(f"❌ Versión no encontrada: {version_id}")
                return False

            # Verificar límites
            if len(self.active_versions) >= self.config.max_active_versions and version_id not in self.active_versions:
                logger.warning(f"⚠️ Límite de versiones activas alcanzado ({self.config.max_active_versions})")
                # Intentar desactivar versión menos usada
                await self._cleanup_old_versions()

            # Crear versión activa
            active_version = ActiveVersion(
                version_id=version_id,
                model_name=model_name,
                activated_at=time.time(),
                last_used=time.time(),
                is_default=is_default,
                traffic_percentage=traffic_percentage or (1.0 if is_default else 0.1)
            )

            self.active_versions[version_id] = active_version

            # Actualizar versión por defecto
            if is_default:
                old_default = self.default_version
                self.default_version = version_id
                if old_default and old_default != version_id:
                    logger.info(f"🔄 Versión por defecto cambiada: {old_default} → {version_id}")

            # Recalcular distribución de tráfico
            await self._recalculate_traffic_distribution()

            logger.info(f"✅ Versión activada: {version_id} "
                       f"(default: {is_default}, traffic: {active_version.traffic_percentage:.1%})")
            return True

        except Exception as e:
            logger.error(f"❌ Error activando versión {version_id}: {e}")
            return False

    async def deactivate_version(self, version_id: str) -> bool:
        """
        Desactivar una versión.

        Args:
            version_id: ID de la versión a desactivar

        Returns:
            True si se desactivó correctamente
        """
        if version_id not in self.active_versions:
            return False

        # No permitir desactivar la versión por defecto sin reemplazo
        if version_id == self.default_version:
            # Buscar otra versión para hacer default
            other_versions = [v for v in self.active_versions.keys() if v != version_id]
            if other_versions:
                await self.set_default_version(other_versions[0])
            else:
                logger.warning("⚠️ Desactivando última versión activa")

        del self.active_versions[version_id]

        # Recalcular distribución
        await self._recalculate_traffic_distribution()

        logger.info(f"📴 Versión desactivada: {version_id}")
        return True

    async def set_default_version(self, version_id: str) -> bool:
        """
        Establecer versión por defecto.

        Args:
            version_id: ID de la versión

        Returns:
            True si se estableció correctamente
        """
        if version_id not in self.active_versions:
            logger.error(f"❌ Versión no activa: {version_id}")
            return False

        old_default = self.default_version
        self.default_version = version_id

        # Actualizar flags
        if old_default:
            self.active_versions[old_default].is_default = False
        self.active_versions[version_id].is_default = True

        # Recalcular distribución
        await self._recalculate_traffic_distribution()

        logger.info(f"🎯 Versión por defecto establecida: {version_id}")
        return True

    def route_request(self, model_preference: Optional[str] = None) -> Optional[str]:
        """
        Routing inteligente de requests basado en configuración.

        Args:
            model_preference: Preferencia de modelo específica (opcional)

        Returns:
            ID de versión a usar o None
        """
        with self.routing_lock:
            self.routing_stats["total_requests"] += 1

            # Si hay preferencia específica, intentar usarla
            if model_preference and model_preference in self.active_versions:
                version_id = model_preference
            else:
                # Aplicar lógica de routing
                version_id = self._select_version_for_request()

            if version_id:
                self.routing_stats["version_routing"][version_id] += 1
                self.active_versions[version_id].usage_count += 1
                self.active_versions[version_id].last_used = time.time()

            return version_id

    def _select_version_for_request(self) -> Optional[str]:
        """Seleccionar versión para un request basado en configuración."""
        if not self.active_versions:
            return None

        # Si solo hay una versión, usarla
        if len(self.active_versions) == 1:
            return next(iter(self.active_versions.keys()))

        # Aplicar A/B testing si está habilitado
        if self.config.enable_ab_testing and self.config.ab_test_traffic_split:
            return self._select_ab_test_version()

        # Aplicar canary deployment si está habilitado
        if self.config.enable_canary_deployments:
            canary_version = self._select_canary_version()
            if canary_version:
                return canary_version

        # Usar distribución de tráfico configurada
        return self._select_weighted_version()

    def _select_ab_test_version(self) -> Optional[str]:
        """Seleccionar versión para A/B testing."""
        # Implementación simplificada
        # En producción, usar distribución estadística más sofisticada
        import random

        versions = list(self.config.ab_test_traffic_split.keys())
        weights = list(self.config.ab_test_traffic_split.values())

        if not versions or not any(weights):
            return self.default_version

        selected = random.choices(versions, weights=weights, k=1)[0]

        # Registrar para estadísticas
        self.routing_stats["ab_test_distributions"][selected] += 1

        return selected

    def _select_canary_version(self) -> Optional[str]:
        """Seleccionar versión canary."""
        import random

        # Encontrar versiones canary (no default, con bajo porcentaje de tráfico)
        canary_versions = [
            v_id for v_id, v in self.active_versions.items()
            if not v.is_default and v.traffic_percentage <= self.config.canary_traffic_percentage
        ]

        if not canary_versions:
            return None

        # Probabilidad basada en configuración
        if random.random() < self.config.canary_traffic_percentage:
            return random.choice(canary_versions)

        return None

    def _select_weighted_version(self) -> Optional[str]:
        """Seleccionar versión basada en pesos de tráfico."""
        import random

        versions = []
        weights = []

        for v_id, v in self.active_versions.items():
            versions.append(v_id)
            weights.append(v.traffic_percentage)

        if not versions or not any(weights):
            return self.default_version

        return random.choices(versions, weights=weights, k=1)[0]

    async def _recalculate_traffic_distribution(self):
        """Recalcular distribución de tráfico entre versiones activas."""
        if not self.active_versions:
            return

        total_weight = sum(v.traffic_percentage for v in self.active_versions.values())

        # Normalizar porcentajes
        for version in self.active_versions.values():
            if total_weight > 0:
                version.traffic_percentage = version.traffic_percentage / total_weight
            else:
                # Distribución uniforme si no hay pesos
                version.traffic_percentage = 1.0 / len(self.active_versions)

    async def _cleanup_old_versions(self):
        """Limpiar versiones antiguas poco usadas."""
        if len(self.active_versions) <= self.config.max_active_versions:
            return

        # Ordenar por último uso y contar de uso
        sorted_versions = sorted(
            self.active_versions.items(),
            key=lambda x: (x[1].last_used, x[1].usage_count)
        )

        # Desactivar la menos usada (excluyendo default)
        for version_id, version in sorted_versions:
            if not version.is_default:
                await self.deactivate_version(version_id)
                break

    def record_request_metrics(
        self,
        version_id: str,
        response_time: float,
        success: bool,
        error_type: Optional[str] = None
    ):
        """
        Registrar métricas de un request.

        Args:
            version_id: ID de la versión usada
            response_time: Tiempo de respuesta
            success: Si el request fue exitoso
            error_type: Tipo de error si falló
        """
        if version_id not in self.active_versions:
            return

        version = self.active_versions[version_id]

        # Actualizar métricas
        if success:
            # Actualizar promedio de tiempo de respuesta
            version.avg_response_time = (
                (version.avg_response_time * version.usage_count) + response_time
            ) / (version.usage_count + 1)
        else:
            version.error_count += 1

    async def check_version_health(self, version_id: str) -> Dict[str, Any]:
        """
        Verificar salud de una versión.

        Args:
            version_id: ID de la versión

        Returns:
            Dict con métricas de salud
        """
        if version_id not in self.active_versions:
            return {"healthy": False, "error": "Version not active"}

        version = self.active_versions[version_id]

        # Calcular métricas de salud
        total_requests = version.usage_count
        error_rate = version.error_count / max(1, total_requests)
        success_rate = 1.0 - error_rate

        health_metrics = {
            "healthy": success_rate >= self.config.promotion_threshold_success_rate,
            "success_rate": success_rate,
            "error_rate": error_rate,
            "avg_response_time": version.avg_response_time,
            "total_requests": total_requests,
            "error_count": version.error_count,
            "last_used": version.last_used
        }

        return health_metrics

    async def auto_promote_demote_versions(self):
        """Auto-promover o degradar versiones basado en métricas."""
        if not self.config.enable_auto_promotion:
            return

        for version_id, version in list(self.active_versions.items()):
            health = await self.check_version_health(version_id)

            # --- Lógica de Degradación ---
            if not health["healthy"] and health["error_rate"] >= self.config.demotion_threshold_error_rate:
                logger.warning(f"📉 DEGRADANDO: La versión {version_id} tiene un alto error rate ({health['error_rate']:.2%}).")
                
                if not version.is_default:
                    # Reducir drásticamente el tráfico o desactivar
                    if version.traffic_percentage > 0.01:
                        version.traffic_percentage = 0.01 # Bajar a 1%
                        logger.info(f"  ... Tráfico de {version_id} reducido a 1%.")
                    else:
                        await self.deactivate_version(version_id)
                        logger.info(f"  ... Versión {version_id} desactivada por bajo rendimiento.")
                else:
                    logger.warning(f"  ... No se puede desactivar la versión por defecto {version_id}, pero se recomienda revisión manual.")
                
                await self._recalculate_traffic_distribution()

            # --- Lógica de Promoción ---
            elif health["healthy"] and version.traffic_percentage < 0.9 and not version.is_default:
                # Promocionar versiones 'canary' que son saludables
                if version.usage_count > 100 and health["success_rate"] > self.config.promotion_threshold_success_rate:
                     logger.info(f"📈 PROMOVIENDO: Versión canary {version_id} es saludable y estable.")
                     
                     # Aumentar tráfico gradualmente
                     new_traffic = min(version.traffic_percentage + 0.1, 0.5) # Aumentar 10%, hasta un 50%
                     version.traffic_percentage = new_traffic
                     logger.info(f"  ... Tráfico de {version_id} aumentado a {new_traffic:.1%}.")
                     
                     await self._recalculate_traffic_distribution()

    def start_monitoring(self):
        """Iniciar monitoreo en background."""
        if self.monitoring_active:
            return

        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

        logger.info("📊 Monitoreo de Version Controller iniciado")

    def stop_monitoring(self):
        """Detener monitoreo."""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)

        logger.info("📊 Monitoreo de Version Controller detenido")

    def _monitoring_loop(self):
        """Loop de monitoreo en background."""
        while self.monitoring_active:
            try:
                # Verificar salud de versiones
                asyncio.run(self._check_all_versions_health())

                # Auto-promover/demotir si está habilitado
                asyncio.run(self.auto_promote_demote_versions())

                # Limpiar versiones expiradas
                asyncio.run(self._cleanup_expired_versions())

            except Exception as e:
                logger.error(f"Error en monitoreo: {e}")

            time.sleep(self.config.performance_check_interval_seconds)

    async def _check_all_versions_health(self):
        """Verificar salud de todas las versiones activas."""
        unhealthy_versions = []

        for version_id in self.active_versions.keys():
            health = await self.check_version_health(version_id)
            if not health["healthy"]:
                unhealthy_versions.append((version_id, health))

        if unhealthy_versions:
            logger.warning(f"⚠️ {len(unhealthy_versions)} versiones con problemas de salud")

    async def _cleanup_expired_versions(self):
        """Limpiar versiones expiradas."""
        current_time = time.time()
        ttl_seconds = self.config.default_version_ttl_hours * 3600

        expired_versions = [
            v_id for v_id, v in self.active_versions.items()
            if (current_time - v.last_used) > ttl_seconds and not v.is_default
        ]

        for version_id in expired_versions:
            logger.info(f"⏰ Versión expirada, desactivando: {version_id}")
            await self.deactivate_version(version_id)

    def get_active_versions_info(self) -> Dict[str, Any]:
        """Obtener información de versiones activas."""
        versions_info = {}

        for version_id, version in self.active_versions.items():
            versions_info[version_id] = {
                "model_name": version.model_name,
                "activated_at": version.activated_at,
                "last_used": version.last_used,
                "usage_count": version.usage_count,
                "error_count": version.error_count,
                "avg_response_time": version.avg_response_time,
                "is_default": version.is_default,
                "traffic_percentage": version.traffic_percentage
            }

        return {
            "active_versions": versions_info,
            "default_version": self.default_version,
            "total_active": len(self.active_versions)
        }

    def get_routing_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de routing."""
        with self.routing_lock:
            stats = dict(self.routing_stats)

        # Añadir porcentajes
        total_requests = stats["total_requests"]
        if total_requests > 0:
            stats["version_percentages"] = {
                v: count / total_requests
                for v, count in stats["version_routing"].items()
            }

        return stats

    def get_controller_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del controller."""
        return {
            "active_versions_count": len(self.active_versions),
            "default_version": self.default_version,
            "max_active_versions": self.config.max_active_versions,
            "ab_testing_enabled": self.config.enable_ab_testing,
            "canary_deployments_enabled": self.config.enable_canary_deployments,
            "auto_promotion_enabled": self.config.enable_auto_promotion,
            "monitoring_active": self.monitoring_active
        }


# Funciones de conveniencia
def create_version_controller(
    version_manager: EmpoorioLMVersionManager,
    config: Optional[VersionControllerConfig] = None
) -> VersionController:
    """Crear instancia del Version Controller."""
    if config is None:
        config = VersionControllerConfig()

    controller = VersionController(config, version_manager)

    # Iniciar monitoreo si está habilitado
    if config.enable_performance_monitoring:
        controller.start_monitoring()

    return controller