"""
Integration Tests for EmpoorioLM Service
Pruebas de integración end-to-end para el servicio completo EmpoorioLM.
"""

import pytest
import asyncio
import time
from unittest.mock import Mock, patch, AsyncMock
import torch
import numpy as np
from fastapi.testclient import TestClient
from fastapi import FastAPI

from ..service import EmpoorioLMService, EmpoorioLMServiceConfig
from ..inference_engine import InferenceEngineConfig
from ...api.endpoints.empoorio_lm import router as empoorio_lm_router
from ...auth.dependencies import get_current_user


class TestEmpoorioLMAPIIntegration:
    """Integration tests for EmpoorioLM API endpoints."""

    @pytest.fixture
    def test_app(self):
        """Create test FastAPI application."""
        app = FastAPI(title="Test EmpoorioLM API")

        # Mock authentication
        async def mock_get_current_user():
            return Mock(id=1, username="test_user", email="test@example.com")

        app.dependency_overrides[get_current_user] = mock_get_current_user

        # Include router
        app.include_router(empoorio_lm_router)

        return app

    @pytest.fixture
    def client(self, test_app):
        """Create test client."""
        return TestClient(test_app)

    @pytest.fixture
    async def mock_service(self):
        """Create mock EmpoorioLM service."""
        service = Mock(spec=EmpoorioLMService)

        # Mock methods
        service.generate_text = AsyncMock(return_value={
            "request_id": "test_req_123",
            "generated_text": "This is a test response from EmpoorioLM.",
            "model_version": "v1.0.0-test",
            "tokens_generated": 8,
            "processing_time": 0.234,
            "metadata": {"input_tokens": 5}
        })

        service.stream_generate_text = AsyncMock(return_value=self._mock_stream_generator())

        service.generate_batch = AsyncMock(return_value="batch_test_123")

        service.activate_model_version = AsyncMock(return_value=True)
        service.deactivate_model_version = AsyncMock(return_value=True)

        service.get_service_status = Mock(return_value={
            "service_name": "test_service",
            "is_initialized": True,
            "is_running": True,
            "uptime_seconds": 3600.0,
            "total_requests": 150,
            "total_tokens_generated": 2500,
            "active_versions": {"total_active": 2, "default_version": "v1.0.0"},
            "performance_metrics": {"status": "healthy"},
            "inference_stats": {"active_requests": 0},
            "model_cache_stats": {"current_models_loaded": 1}
        })

        service.get_service_health = Mock(return_value={
            "status": "healthy",
            "checks": {
                "service_initialized": {"status": "pass", "message": "Service is initialized"},
                "service_running": {"status": "pass", "message": "Service is running"},
                "inference_engine": {"status": "pass", "message": "Inference Engine healthy"},
                "model_manager": {"status": "pass", "message": "Model Manager healthy"},
                "version_controller": {"status": "pass", "message": "Version Controller healthy"}
            }
        })

        service.get_performance_report = Mock(return_value={
            "current_metrics": {"cpu_usage": 45.0, "memory_usage": 2.1},
            "averages_last_10": {"response_time": 245.0, "requests_per_second": 4.1}
        })

        service.get_optimization_recommendations = Mock(return_value=[
            {
                "type": "cache_optimization",
                "priority": "medium",
                "description": "Cache hit rate could be improved",
                "current_value": "78%",
                "recommended_action": "Increase max_models_in_memory"
            }
        ])

        return service

    async def _mock_stream_generator(self):
        """Mock streaming generator."""
        chunks = ["Hello", " world", " from", " EmpoorioLM", "!"]
        for chunk in chunks:
            yield chunk
            await asyncio.sleep(0.01)  # Small delay to simulate real streaming

    @pytest.fixture
    def mock_get_empoorio_lm_service(self, mock_service):
        """Mock the service dependency."""
        async def mock_service_func():
            return mock_service
        return mock_service_func

    def test_generate_text_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test POST /api/empoorio-lm/generate endpoint."""
        # Mock the service dependency
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            request_data = {
                "prompt": "Write a short story about AI",
                "max_tokens": 50,
                "temperature": 0.7,
                "model_version": "v1.0.0"
            }

            response = client.post("/api/empoorio-lm/generate", json=request_data)

            assert response.status_code == 200
            data = response.json()

            assert "request_id" in data
            assert "generated_text" in data
            assert "model_version" in data
            assert "tokens_generated" in data
            assert "processing_time" in data

            assert data["generated_text"] == "This is a test response from EmpoorioLM."
            assert data["model_version"] == "v1.0.0-test"

            # Verify service was called
            mock_service.generate_text.assert_called_once()

    def test_generate_text_stream_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test POST /api/empoorio-lm/generate/stream endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            request_data = {
                "prompt": "Tell me a joke",
                "max_tokens": 30,
                "temperature": 0.8
            }

            response = client.post("/api/empoorio-lm/generate/stream", json=request_data)

            assert response.status_code == 200
            assert response.headers["content-type"] == "text/plain; charset=utf-8"

            # Verify service was called
            mock_service.stream_generate_text.assert_called_once()

    def test_generate_batch_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test POST /api/empoorio-lm/generate/batch endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            request_data = {
                "requests": [
                    {
                        "prompt": "What is machine learning?",
                        "max_tokens": 20,
                        "temperature": 0.5
                    },
                    {
                        "prompt": "Explain neural networks",
                        "max_tokens": 25,
                        "temperature": 0.6
                    }
                ],
                "model_version": "v1.0.0"
            }

            response = client.post("/api/empoorio-lm/generate/batch", json=request_data)

            assert response.status_code == 200
            data = response.json()

            assert "batch_id" in data
            assert "status" in data
            assert "message" in data

            assert data["batch_id"] == "batch_test_123"
            assert data["status"] == "submitted"

            # Verify service was called
            mock_service.generate_batch.assert_called_once()

    def test_activate_version_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test POST /api/empoorio-lm/versions/activate endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            request_data = {
                "version_id": "empoorio_lm_v1.1.0_1234567890",
                "is_default": True,
                "traffic_percentage": 0.8
            }

            response = client.post("/api/empoorio-lm/versions/activate", json=request_data)

            assert response.status_code == 200
            data = response.json()

            assert data["success"] == True
            assert "message" in data

            # Verify service was called
            mock_service.activate_model_version.assert_called_once_with(
                version_id="empoorio_lm_v1.1.0_1234567890",
                is_default=True,
                traffic_percentage=0.8
            )

    def test_deactivate_version_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test DELETE /api/empoorio-lm/versions/{version_id} endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            version_id = "empoorio_lm_v1.0.0_1234567890"

            response = client.delete(f"/api/empoorio-lm/versions/{version_id}")

            assert response.status_code == 200
            data = response.json()

            assert data["success"] == True
            assert "message" in data

            # Verify service was called
            mock_service.deactivate_model_version.assert_called_once_with(version_id)

    def test_list_active_versions_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test GET /api/empoorio-lm/versions endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            response = client.get("/api/empoorio-lm/versions")

            assert response.status_code == 200
            data = response.json()

            assert "active_versions" in data
            assert "total_active" in data
            assert "default_version" in data

            assert data["total_active"] == 2
            assert data["default_version"] == "v1.0.0"

    def test_service_status_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test GET /api/empoorio-lm/status endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            response = client.get("/api/empoorio-lm/status")

            assert response.status_code == 200
            data = response.json()

            assert data["service_name"] == "test_service"
            assert data["is_initialized"] == True
            assert data["is_running"] == True
            assert data["uptime_seconds"] == 3600.0
            assert data["total_requests"] == 150
            assert "active_versions" in data
            assert "performance_metrics" in data

    def test_service_health_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test GET /api/empoorio-lm/health endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            response = client.get("/api/empoorio-lm/health")

            assert response.status_code == 200
            data = response.json()

            assert data["status"] == "healthy"
            assert "checks" in data

            # Verify all checks are present
            expected_checks = ["service_initialized", "service_running", "inference_engine", "model_manager", "version_controller"]
            for check in expected_checks:
                assert check in data["checks"]
                assert "status" in data["checks"][check]
                assert "message" in data["checks"][check]

    def test_performance_report_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test GET /api/empoorio-lm/performance endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            response = client.get("/api/empoorio-lm/performance")

            assert response.status_code == 200
            data = response.json()

            assert "current_metrics" in data
            assert "averages_last_10" in data
            assert data["current_metrics"]["cpu_usage"] == 45.0

    def test_optimization_recommendations_endpoint(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test GET /api/empoorio-lm/recommendations endpoint."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            response = client.get("/api/empoorio-lm/recommendations")

            assert response.status_code == 200
            data = response.json()

            assert "recommendations" in data
            assert len(data["recommendations"]) == 1

            rec = data["recommendations"][0]
            assert rec["type"] == "cache_optimization"
            assert rec["priority"] == "medium"
            assert "description" in rec

    def test_invalid_request_data(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test endpoints with invalid request data."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            # Test generate with missing prompt
            response = client.post("/api/empoorio-lm/generate", json={"max_tokens": 50})
            assert response.status_code == 422  # Validation error

            # Test generate with invalid temperature
            response = client.post("/api/empoorio-lm/generate", json={
                "prompt": "Test",
                "temperature": 3.0  # Invalid: > 2.0
            })
            assert response.status_code == 422  # Validation error

    def test_batch_generation_validation(self, client, mock_service, mock_get_empoorio_lm_service):
        """Test batch generation validation."""
        with patch('src.ailoos.coordinator.api.endpoints.empoorio_lm.get_empoorio_lm_service', mock_get_empoorio_lm_service):
            # Test empty batch
            response = client.post("/api/empoorio-lm/generate/batch", json={"requests": []})
            assert response.status_code == 200  # Should handle gracefully

            # Test too many requests (if we had a limit)
            # This would depend on our implementation limits


class TestEmpoorioLMEndToEnd:
    """End-to-end tests for EmpoorioLM service."""

    @pytest.mark.asyncio
    async def test_service_initialization_flow(self):
        """Test complete service initialization flow."""
        config = EmpoorioLMServiceConfig(
            service_name="e2e_test_service",
            auto_initialize_base_model=False,  # Skip for this test
        )

        # Create service with minimal mocking
        with patch('src.ailoos.coordinator.empoorio_lm.service.EmpoorioLMVersionManager') as mock_vm_class:
            mock_vm = Mock()
            mock_vm_class.return_value = mock_vm

            service = EmpoorioLMService(config)

            # Test that service can be created
            assert service.config.service_name == "e2e_test_service"

            # Test status before initialization
            status = service.get_service_status()
            assert not status["is_initialized"]
            assert not status["is_running"]

    @pytest.mark.asyncio
    async def test_concurrent_inference_simulation(self):
        """Test concurrent inference handling simulation."""
        config = EmpoorioLMServiceConfig(
            inference_engine=InferenceEngineConfig(
                max_concurrent_requests=5,
                max_workers=3,
            )
        )

        with patch('src.ailoos.coordinator.empoorio_lm.service.EmpoorioLMVersionManager'):
            service = EmpoorioLMService(config)

            # Verify configuration is applied
            assert service.inference_engine.config.max_concurrent_requests == 5
            assert service.inference_engine.config.max_workers == 3

            # Test that components are properly configured
            assert service.inference_engine is not None
            assert service.model_manager is not None
            assert service.version_controller is not None
            assert service.performance_optimizer is not None


if __name__ == "__main__":
    # Run integration tests
    pytest.main([__file__, "-v"])