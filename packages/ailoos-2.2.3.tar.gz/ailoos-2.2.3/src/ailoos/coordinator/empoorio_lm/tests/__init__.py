"""
Tests for EmpoorioLM Service
Pruebas unitarias y de integración para el servicio completo EmpoorioLM.
"""

# Este archivo marca el directorio como paquete Python