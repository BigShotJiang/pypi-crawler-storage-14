"""
EmpoorioLM Configuration
Configuración completa para el servicio EmpoorioLM.
"""

import os
from typing import Optional
from pathlib import Path


def get_empoorio_lm_config():
    """
    Obtener configuración completa para EmpoorioLM desde variables de entorno.

    Returns:
        Diccionario con configuración completa
    """
    # Configuración del servicio
    service_config = {
        "service_name": os.getenv("EMPOORIO_LM_SERVICE_NAME", "empoorio_lm_service"),
        "enable_health_checks": os.getenv("EMPOORIO_LM_ENABLE_HEALTH_CHECKS", "true").lower() == "true",
        "enable_metrics": os.getenv("EMPOORIO_LM_ENABLE_METRICS", "true").lower() == "true",
        "auto_initialize_base_model": os.getenv("EMPOORIO_LM_AUTO_INIT_BASE_MODEL", "true").lower() == "true",
        "default_model_version": os.getenv("EMPOORIO_LM_DEFAULT_VERSION", "v1.0.0"),
    }

    # Configuración de rutas
    base_dir = Path(os.getenv("EMPOORIO_LM_BASE_DIR", "./models/empoorio_lm"))
    service_config.update({
        "models_dir": str(base_dir / "versions"),
        "sessions_dir": str(base_dir / "data" / "sessions"),
        "checkpoints_dir": str(base_dir / "data" / "checkpoints"),
    })

    # Configuración del Model Manager
    service_config["model_manager"] = {
        "max_memory_gb": float(os.getenv("EMPOORIO_LM_MAX_MEMORY_GB", "8.0")),
        "max_models_in_memory": int(os.getenv("EMPOORIO_LM_MAX_MODELS_IN_MEMORY", "3")),
        "cache_ttl_seconds": int(os.getenv("EMPOORIO_LM_CACHE_TTL_SECONDS", "3600")),
        "lru_eviction_enabled": os.getenv("EMPOORIO_LM_LRU_EVICTION", "true").lower() == "true",
        "prefer_gpu": os.getenv("EMPOORIO_LM_PREFER_GPU", "true").lower() == "true",
        "gpu_memory_fraction": float(os.getenv("EMPOORIO_LM_GPU_MEMORY_FRACTION", "0.8")),
        "enable_monitoring": os.getenv("EMPOORIO_LM_ENABLE_MODEL_MONITORING", "true").lower() == "true",
        "monitoring_interval_seconds": int(os.getenv("EMPOORIO_LM_MODEL_MONITORING_INTERVAL", "60")),
    }

    # Configuración del Inference Engine
    service_config["inference_engine"] = {
        "max_concurrent_requests": int(os.getenv("EMPOORIO_LM_MAX_CONCURRENT_REQUESTS", "10")),
        "max_batch_size": int(os.getenv("EMPOORIO_LM_MAX_BATCH_SIZE", "8")),
        "request_timeout_seconds": int(os.getenv("EMPOORIO_LM_REQUEST_TIMEOUT_SECONDS", "300")),
        "enable_streaming": os.getenv("EMPOORIO_LM_ENABLE_STREAMING", "true").lower() == "true",
        "stream_chunk_size": int(os.getenv("EMPOORIO_LM_STREAM_CHUNK_SIZE", "10")),
        "enable_dynamic_batching": os.getenv("EMPOORIO_LM_ENABLE_DYNAMIC_BATCHING", "true").lower() == "true",
        "batch_timeout_ms": int(os.getenv("EMPOORIO_LM_BATCH_TIMEOUT_MS", "50")),
        "enable_quality_filtering": os.getenv("EMPOORIO_LM_ENABLE_QUALITY_FILTERING", "true").lower() == "true",
        "min_confidence_threshold": float(os.getenv("EMPOORIO_LM_MIN_CONFIDENCE_THRESHOLD", "0.1")),
        "max_workers": int(os.getenv("EMPOORIO_LM_MAX_WORKERS", "4")),
        "enable_gpu_optimization": os.getenv("EMPOORIO_LM_ENABLE_GPU_OPTIMIZATION", "true").lower() == "true",
    }

    # Configuración del Version Controller
    service_config["version_controller"] = {
        "max_active_versions": int(os.getenv("EMPOORIO_LM_MAX_ACTIVE_VERSIONS", "5")),
        "default_version_ttl_hours": int(os.getenv("EMPOORIO_LM_DEFAULT_VERSION_TTL_HOURS", "24")),
        "enable_ab_testing": os.getenv("EMPOORIO_LM_ENABLE_AB_TESTING", "true").lower() == "true",
        "canary_traffic_percentage": float(os.getenv("EMPOORIO_LM_CANARY_TRAFFIC_PERCENTAGE", "0.1")),
        "enable_canary_deployments": os.getenv("EMPOORIO_LM_ENABLE_CANARY_DEPLOYMENTS", "true").lower() == "true",
        "enable_fallback_versions": os.getenv("EMPOORIO_LM_ENABLE_FALLBACK_VERSIONS", "true").lower() == "true",
        "enable_performance_monitoring": os.getenv("EMPOORIO_LM_ENABLE_VERSION_MONITORING", "true").lower() == "true",
        "performance_check_interval_seconds": int(os.getenv("EMPOORIO_LM_VERSION_CHECK_INTERVAL", "300")),
        "enable_auto_promotion": os.getenv("EMPOORIO_LM_ENABLE_AUTO_PROMOTION", "true").lower() == "true",
        "promotion_threshold_success_rate": float(os.getenv("EMPOORIO_LM_PROMOTION_SUCCESS_THRESHOLD", "0.95")),
        "demotion_threshold_error_rate": float(os.getenv("EMPOORIO_LM_DEMOTION_ERROR_THRESHOLD", "0.05")),
    }

    # Configuración del Performance Optimizer
    service_config["performance_optimizer"] = {
        "cpu_usage_threshold_high": float(os.getenv("EMPOORIO_LM_CPU_THRESHOLD_HIGH", "80.0")),
        "cpu_usage_threshold_low": float(os.getenv("EMPOORIO_LM_CPU_THRESHOLD_LOW", "20.0")),
        "memory_usage_threshold_high": float(os.getenv("EMPOORIO_LM_MEMORY_THRESHOLD_HIGH", "85.0")),
        "memory_usage_threshold_low": float(os.getenv("EMPOORIO_LM_MEMORY_THRESHOLD_LOW", "30.0")),
        "gpu_memory_threshold_high": float(os.getenv("EMPOORIO_LM_GPU_MEMORY_THRESHOLD_HIGH", "90.0")),
        "gpu_memory_threshold_low": float(os.getenv("EMPOORIO_LM_GPU_MEMORY_THRESHOLD_LOW", "40.0")),
        "max_response_time_ms": int(os.getenv("EMPOORIO_LM_MAX_RESPONSE_TIME_MS", "5000")),
        "max_queue_size": int(os.getenv("EMPOORIO_LM_MAX_QUEUE_SIZE", "100")),
        "enable_auto_scaling": os.getenv("EMPOORIO_LM_ENABLE_AUTO_SCALING", "true").lower() == "true",
        "enable_cache_optimization": os.getenv("EMPOORIO_LM_ENABLE_CACHE_OPTIMIZATION", "true").lower() == "true",
        "enable_model_preloading": os.getenv("EMPOORIO_LM_ENABLE_MODEL_PRELOADING", "true").lower() == "true",
        "metrics_collection_interval_seconds": int(os.getenv("EMPOORIO_LM_METRICS_INTERVAL", "30")),
        "optimization_check_interval_seconds": int(os.getenv("EMPOORIO_LM_OPTIMIZATION_INTERVAL", "60")),
        "metrics_history_size": int(os.getenv("EMPOORIO_LM_METRICS_HISTORY_SIZE", "100")),
        "scale_up_cooldown_seconds": int(os.getenv("EMPOORIO_LM_SCALE_UP_COOLDOWN", "300")),
        "scale_down_cooldown_seconds": int(os.getenv("EMPOORIO_LM_SCALE_DOWN_COOLDOWN", "600")),
    }

    return service_config


def create_empoorio_lm_service_from_env():
    """
    Crear configuración completa del servicio EmpoorioLM desde variables de entorno.

    Returns:
        EmpoorioLMServiceConfig: Configuración completa del servicio
    """
    from .service import EmpoorioLMServiceConfig

    config_dict = get_empoorio_lm_config()

    # Crear configuración del servicio
    service_config = EmpoorioLMServiceConfig(
        service_name=config_dict["service_name"],
        enable_health_checks=config_dict["enable_health_checks"],
        enable_metrics=config_dict["enable_metrics"],
        models_dir=config_dict["models_dir"],
        auto_initialize_base_model=config_dict["auto_initialize_base_model"],
        default_model_version=config_dict["default_model_version"],
    )

    # Configurar componentes internos
    from .model_manager import ModelManagerConfig
    from .inference_engine import InferenceEngineConfig
    from .version_controller import VersionControllerConfig
    from .performance_optimizer import PerformanceOptimizerConfig

    service_config.model_manager = ModelManagerConfig(**config_dict["model_manager"])
    service_config.inference_engine = InferenceEngineConfig(**config_dict["inference_engine"])
    service_config.version_controller = VersionControllerConfig(**config_dict["version_controller"])
    service_config.performance_optimizer = PerformanceOptimizerConfig(**config_dict["performance_optimizer"])

    return service_config


# Variables de configuración por defecto para desarrollo
DEFAULT_EMPOORIO_LM_CONFIG = {
    "service_name": "empoorio_lm_service",
    "enable_health_checks": True,
    "enable_metrics": True,
    "models_dir": "./models/empoorio_lm/versions",
    "sessions_dir": "./models/empoorio_lm/data/sessions",
    "checkpoints_dir": "./models/empoorio_lm/data/checkpoints",
    "auto_initialize_base_model": True,
    "default_model_version": "v1.0.0",

    "model_manager": {
        "max_memory_gb": 8.0,
        "max_models_in_memory": 3,
        "cache_ttl_seconds": 3600,
        "lru_eviction_enabled": True,
        "prefer_gpu": True,
        "gpu_memory_fraction": 0.8,
        "enable_monitoring": True,
        "monitoring_interval_seconds": 60,
    },

    "inference_engine": {
        "max_concurrent_requests": 10,
        "max_batch_size": 8,
        "request_timeout_seconds": 300,
        "enable_streaming": True,
        "stream_chunk_size": 10,
        "enable_dynamic_batching": True,
        "batch_timeout_ms": 50,
        "enable_quality_filtering": True,
        "min_confidence_threshold": 0.1,
        "max_workers": 4,
        "enable_gpu_optimization": True,
    },

    "version_controller": {
        "max_active_versions": 5,
        "default_version_ttl_hours": 24,
        "enable_ab_testing": True,
        "canary_traffic_percentage": 0.1,
        "enable_canary_deployments": True,
        "enable_fallback_versions": True,
        "enable_performance_monitoring": True,
        "performance_check_interval_seconds": 300,
        "enable_auto_promotion": True,
        "promotion_threshold_success_rate": 0.95,
        "demotion_threshold_error_rate": 0.05,
    },

    "performance_optimizer": {
        "cpu_usage_threshold_high": 80.0,
        "cpu_usage_threshold_low": 20.0,
        "memory_usage_threshold_high": 85.0,
        "memory_usage_threshold_low": 30.0,
        "gpu_memory_threshold_high": 90.0,
        "gpu_memory_threshold_low": 40.0,
        "max_response_time_ms": 5000,
        "max_queue_size": 100,
        "enable_auto_scaling": True,
        "enable_cache_optimization": True,
        "enable_model_preloading": True,
        "metrics_collection_interval_seconds": 30,
        "optimization_check_interval_seconds": 60,
        "metrics_history_size": 100,
        "scale_up_cooldown_seconds": 300,
        "scale_down_cooldown_seconds": 600,
    }
}