"""
AILOOS APIs - Interfaces REST para el sistema completo.
Incluye marketplace, federated learning, gestión de nodos y wallets blockchain.
"""

from .marketplace_api import MarketplaceAPI, create_marketplace_app, marketplace_api
from .federated_api import FederatedAPI, create_federated_app, federated_api
from .wallet_api import WalletAPI, create_wallet_app, wallet_api
from .empoorio_api import EmpoorioLMApi, EmpoorioLMAPI, create_empoorio_app, empoorio_lm_api
from .technical_dashboard_api import TechnicalDashboardAPI, create_technical_dashboard_app, technical_dashboard_api
from .rag_api import RAGAPI, create_rag_app, rag_api
from .models_api import ModelsAPI, create_models_app, models_api
from .analytics_api import AnalyticsAPI, create_analytics_app, analytics_api
from .system_tools_api import SystemToolsAPI, create_system_tools_app, system_tools_api
from .datahub_api import DataHubAPI, create_datahub_app, datahub_api

__all__ = [
    'MarketplaceAPI',
    'FederatedAPI',
    'WalletAPI',
    'EmpoorioLMApi',
    'EmpoorioLMAPI',
    'TechnicalDashboardAPI',
    'ModelsAPI',
    'create_marketplace_app',
    'create_federated_app',
    'create_wallet_app',
    'create_empoorio_app',
    'create_technical_dashboard_app',
    'create_rag_app',
    'create_models_app',
    'marketplace_api',
    'federated_api',
    'wallet_api',
    'empoorio_lm_api',
    'technical_dashboard_api',
    'models_api'
]