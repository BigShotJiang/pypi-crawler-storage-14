#!/usr/bin/env python3
"""
AILOOS Simple NIAH Benchmark Runner
===================================

Simple command-line interface for running NIAH benchmarks.
"""

import sys
import os
import asyncio
from datetime import datetime

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Import NIAH components directly
import importlib.util

def load_niah_module(module_name, file_path):
    """Load a NIAH module directly."""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    print("AILOOS Professional NIAH Benchmark Suite")
    print("="*50)

    # Load modules
    generator_module = load_niah_module('niah_generator', 'src/ailoos/benchmarking/niah/generator.py')
    evaluator_module = load_niah_module('niah_evaluator', 'src/ailoos/benchmarking/niah/evaluator.py')
    visualizer_module = load_niah_module('niah_visualizer', 'src/ailoos/benchmarking/niah/visualizer.py')

    NIAHGenerator = generator_module.NIAHGenerator
    NIAHEvaluator = evaluator_module.NIAHEvaluator
    NIAHVisualizer = visualizer_module.NIAHVisualizer

    print("Loading NIAH components...")

    # Initialize components
    generator = NIAHGenerator()
    evaluator = NIAHEvaluator()
    visualizer = NIAHVisualizer(config={'output_dir': 'reports/niah'})

    print("Components initialized successfully!")

    # Run quick test
    print("\nRunning quick NIAH test...")

    # Generate test case
    context, question, expected, needle = generator.generate_test_case(
        context_length=1000,
        depth_percent=0.5,
        domain='technical',
        needle_type='fact'
    )

    print(f"Generated test case: {len(context)} chars context")
    print(f"Question: {question}")
    print(f"Expected answer: {expected[:50]}...")

    # Mock model response (since we don't have a real model loaded)
    mock_response = expected  # Perfect match for demo

    # Evaluate
    result = evaluator.evaluate_response(mock_response, expected, needle_type='fact')

    print("\nEvaluation Results:")
    print(f"  Score: {result.score:.1f}/10.0")
    print(f"  Success: {result.success}")
    print(f"  Confidence: {result.confidence:.2f}")

    # Generate simple report
    test_results = [{
        'context_length': 1000,
        'depth_percent': 50,
        'domain': 'technical',
        'needle_type': 'fact',
        'score': result.score,
        'success': result.success,
        'response': mock_response,
        'expected': expected,
        'retrieval_time': 0.1
    }]

    # Try to generate heatmap (will fail gracefully without matplotlib)
    try:
        saved_files = visualizer.generate_heatmap(test_results, 'NIAH-Demo', save_formats=['png'])
        print(f"\nHeatmap saved: {saved_files.get('png', 'N/A')}")
    except Exception as e:
        print(f"\nHeatmap generation skipped (matplotlib not available): {e}")

    print("\nQuick test completed!")
    print("For full benchmarks with real models, use the validation script:")
    print("  python examples/validation_report_fase12.py")


if __name__ == "__main__":
    main()