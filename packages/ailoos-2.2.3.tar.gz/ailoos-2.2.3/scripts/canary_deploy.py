#!/usr/bin/env python3
"""
Canary Deployment Script for Federated Services in GKE
Implements automated canary deployments starting with 5% of nodes.
"""

import subprocess
import sys
import time
import argparse
from pathlib import Path
from typing import List, Dict, Optional
import yaml
import json

class CanaryDeployer:
    def __init__(self, namespace: str = "default", canary_percentage: int = 5):
        self.namespace = namespace
        self.canary_percentage = canary_percentage
        self.deployments = ["ailoos-coordinator", "ailoos-empoorio"]

    def run_kubectl(self, args: List[str], capture_output: bool = False) -> subprocess.CompletedProcess:
        """Run kubectl command."""
        cmd = ["kubectl"] + args
        if capture_output:
            return subprocess.run(cmd, capture_output=True, text=True, check=True)
        else:
            return subprocess.run(cmd, check=True)

    def get_deployment_info(self, deployment_name: str) -> Dict:
        """Get current deployment information."""
        try:
            result = self.run_kubectl([
                "get", "deployment", deployment_name,
                "-n", self.namespace,
                "-o", "json"
            ], capture_output=True)

            return json.loads(result.stdout)
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to get deployment info for {deployment_name}: {e}")
            return {}

    def update_deployment_image(self, deployment_name: str, new_image: str) -> bool:
        """Update deployment image for canary deployment."""
        try:
            print(f"🔄 Updating {deployment_name} to image: {new_image}")

            self.run_kubectl([
                "set", "image",
                f"deployment/{deployment_name}",
                f"{deployment_name.split('-')[1]}={new_image}",
                "-n", self.namespace
            ])

            print(f"✅ Image updated for {deployment_name}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to update image for {deployment_name}: {e}")
            return False

    def set_rolling_update_strategy(self, deployment_name: str, max_unavailable: str = "5%", max_surge: str = "5%") -> bool:
        """Set rolling update strategy for canary deployment."""
        try:
            patch = {
                "spec": {
                    "strategy": {
                        "type": "RollingUpdate",
                        "rollingUpdate": {
                            "maxUnavailable": max_unavailable,
                            "maxSurge": max_surge
                        }
                    }
                }
            }

            self.run_kubectl([
                "patch", "deployment", deployment_name,
                "-n", self.namespace,
                "--type", "merge",
                "-p", json.dumps(patch)
            ])

            print(f"✅ Rolling update strategy set for {deployment_name} (maxUnavailable: {max_unavailable})")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to set rolling update strategy for {deployment_name}: {e}")
            return False

    def wait_for_rollout(self, deployment_name: str, timeout: int = 600) -> bool:
        """Wait for deployment rollout to complete."""
        try:
            print(f"⏳ Waiting for rollout of {deployment_name}...")

            self.run_kubectl([
                "rollout", "status", f"deployment/{deployment_name}",
                "-n", self.namespace,
                "--timeout", f"{timeout}s"
            ])

            print(f"✅ Rollout completed for {deployment_name}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Rollout failed or timed out for {deployment_name}")
            return False

    def check_deployment_health(self, deployment_name: str) -> bool:
        """Check if deployment is healthy after rollout."""
        try:
            result = self.run_kubectl([
                "get", "deployment", deployment_name,
                "-n", self.namespace,
                "-o", "jsonpath={.status.conditions[?(@.type=='Available')].status}"
            ], capture_output=True)

            if result.stdout.strip() == "True":
                print(f"✅ {deployment_name} is healthy")
                return True
            else:
                print(f"❌ {deployment_name} is not healthy")
                return False
        except subprocess.CalledProcessError:
            print(f"❌ Failed to check health for {deployment_name}")
            return False

    def rollback_deployment(self, deployment_name: str) -> bool:
        """Rollback deployment to previous version."""
        try:
            print(f"🔄 Rolling back {deployment_name}...")

            self.run_kubectl([
                "rollout", "undo", f"deployment/{deployment_name}",
                "-n", self.namespace
            ])

            print(f"✅ Rollback completed for {deployment_name}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Rollback failed for {deployment_name}: {e}")
            return False

    def perform_canary_deployment(self, new_image_tag: str) -> bool:
        """Perform canary deployment for all federated services."""
        print("🚀 Starting Canary Deployment for Federated Services")
        print("=" * 60)
        print(f"Target image tag: {new_image_tag}")
        print(f"Canary percentage: {self.canary_percentage}%")
        print()

        success_count = 0

        for deployment in self.deployments:
            print(f"📦 Processing deployment: {deployment}")
            print("-" * 40)

            # Set rolling update strategy for canary
            if not self.set_rolling_update_strategy(deployment, f"{self.canary_percentage}%", f"{self.canary_percentage}%"):
                print(f"❌ Failed to configure canary strategy for {deployment}")
                continue

            # Update image
            image_name = f"gcr.io/{self.get_project_id()}/{deployment.replace('ailoos-', '')}:{new_image_tag}"
            if not self.update_deployment_image(deployment, image_name):
                print(f"❌ Failed to update image for {deployment}")
                continue

            # Wait for rollout
            if not self.wait_for_rollout(deployment):
                print(f"❌ Rollout failed for {deployment}")

                # Attempt rollback
                if self.rollback_deployment(deployment):
                    print(f"✅ Rollback successful for {deployment}")
                else:
                    print(f"❌ Rollback failed for {deployment}")
                continue

            # Check health
            if not self.check_deployment_health(deployment):
                print(f"❌ Health check failed for {deployment}")

                # Rollback on failure
                if self.rollback_deployment(deployment):
                    print(f"✅ Rollback successful for {deployment}")
                continue

            print(f"✅ Canary deployment successful for {deployment}")
            success_count += 1
            print()

        print("📊 Deployment Summary:")
        print(f"   Total deployments: {len(self.deployments)}")
        print(f"   Successful: {success_count}")
        print(f"   Failed: {len(self.deployments) - success_count}")

        return success_count == len(self.deployments)

    def get_project_id(self) -> str:
        """Get GCP project ID."""
        try:
            result = self.run_kubectl([
                "config", "current-context"
            ], capture_output=True)

            # This is a simplified way; in practice, you might need to parse gcloud config
            # For now, assume it's set via environment or config
            return "ailoos-oauth-473213"  # From the deployment files
        except:
            return "ailoos-oauth-473213"

    def validate_environment(self) -> bool:
        """Validate that kubectl is configured and cluster is accessible."""
        try:
            self.run_kubectl(["cluster-info"], capture_output=True)
            print("✅ Kubernetes cluster is accessible")
            return True
        except subprocess.CalledProcessError:
            print("❌ Cannot access Kubernetes cluster. Check kubectl configuration.")
            return False

def main():
    parser = argparse.ArgumentParser(description="Canary Deployment for Federated Services")
    parser.add_argument(
        '--image-tag',
        required=True,
        help='New image tag for deployment'
    )
    parser.add_argument(
        '--namespace',
        default='default',
        help='Kubernetes namespace (default: default)'
    )
    parser.add_argument(
        '--canary-percentage',
        type=int,
        default=5,
        help='Percentage of nodes for canary deployment (default: 5)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Perform dry run without actual deployment'
    )

    args = parser.parse_args()

    deployer = CanaryDeployer(args.namespace, args.canary_percentage)

    if not deployer.validate_environment():
        sys.exit(1)

    if args.dry_run:
        print("🔍 Dry run mode - no changes will be made")
        print(f"Would deploy image tag: {args.image_tag}")
        print(f"To deployments: {', '.join(deployer.deployments)}")
        print(f"With canary percentage: {args.canary_percentage}%")
        sys.exit(0)

    success = deployer.perform_canary_deployment(args.image_tag)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()