#!/usr/bin/env python3
"""
Demo de Inferencia Edge - Demostración de EmpoorioLM ejecutándose en ONNX

Esta demo muestra cómo cargar y ejecutar un modelo EmpoorioLM exportado a ONNX,
simulando el uso en un dispositivo móvil o edge.

Requisitos:
- pip install onnxruntime
- Modelo ONNX exportado con export_to_edge.py
"""

import argparse
import json
import time
from pathlib import Path
from typing import Dict, Any, List

try:
    import onnxruntime as ort
    import numpy as np
    ONNX_AVAILABLE = True
except ImportError:
    print("⚠️  ONNX Runtime no disponible. Instalar con: pip install onnxruntime")
    ONNX_AVAILABLE = False


class EdgeInferenceDemo:
    """Demo de inferencia usando modelo ONNX exportado."""

    def __init__(self, model_dir: str):
        """
        Inicializar demo de inferencia edge.

        Args:
            model_dir: Directorio con modelo ONNX y metadatos
        """
        self.model_dir = Path(model_dir)
        self.session = None
        self.metadata = None
        self.tokenizer = None

        if not ONNX_AVAILABLE:
            raise RuntimeError("ONNX Runtime no disponible")

        self.load_model()

    def load_model(self):
        """Cargar modelo ONNX y metadatos."""
        print("📥 Cargando modelo ONNX y metadatos...")

        # Cargar modelo ONNX
        onnx_path = self.model_dir / "model.onnx"
        if not onnx_path.exists():
            raise FileNotFoundError(f"Modelo ONNX no encontrado: {onnx_path}")

        # Crear sesión ONNX con optimizaciones para CPU
        options = ort.SessionOptions()
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL

        self.session = ort.InferenceSession(
            str(onnx_path),
            options,
            providers=['CPUExecutionProvider']  # CPU para demo
        )

        print(f"✅ Modelo ONNX cargado - Entradas: {[inp.name for inp in self.session.get_inputs()]}")

        # Cargar metadatos
        metadata_path = self.model_dir / "metadata.json"
        if metadata_path.exists():
            with open(metadata_path, 'r', encoding='utf-8') as f:
                self.metadata = json.load(f)
            print("✅ Metadatos cargados")
        else:
            print("⚠️  Metadatos no encontrados, usando valores por defecto")
            self.metadata = self._create_default_metadata()

        # Simular tokenizer (en producción usar tokenizer real)
        self.tokenizer = MockTokenizer(self.metadata)

    def _create_default_metadata(self) -> Dict[str, Any]:
        """Crear metadatos por defecto si no existen."""
        return {
            "model_info": {
                "name": "EmpoorioLM-Edge",
                "vocab_size": 30000,
                "max_context": 1024
            },
            "tokenizer_config": {
                "bos_token": "<|endoftext|>",
                "eos_token": "<|endoftext|>"
            },
            "inference_config": {
                "temperature": 1.0,
                "top_k": 50,
                "max_length": 100
            }
        }

    def run_inference(self, prompt: str, max_length: int = 50) -> Dict[str, Any]:
        """
        Ejecutar inferencia con el modelo ONNX.

        Args:
            prompt: Texto de entrada
            max_length: Longitud máxima de generación

        Returns:
            Diccionario con resultados
        """
        start_time = time.time()

        # Tokenizar input
        input_ids = self.tokenizer.encode(prompt)
        if len(input_ids) > self.metadata["model_info"]["max_context"]:
            input_ids = input_ids[:self.metadata["model_info"]["max_context"]]

        # Convertir a tensor numpy
        input_array = np.array([input_ids], dtype=np.int64)

        print(f"🔍 Input tokens: {len(input_ids)} - Shape: {input_array.shape}")

        # Ejecutar inferencia
        outputs = self.session.run(
            None,  # Todas las salidas
            {"input_ids": input_array}
        )

        logits = outputs[0]  # [batch_size, seq_len, vocab_size]
        inference_time = time.time() - start_time

        # Decodificar (simulación simple)
        generated_tokens = self._greedy_decode(logits[0], max_length)
        generated_text = self.tokenizer.decode(generated_tokens)

        return {
            "prompt": prompt,
            "generated_text": generated_text,
            "full_response": prompt + generated_text,
            "input_tokens": len(input_ids),
            "output_tokens": len(generated_tokens),
            "inference_time_ms": inference_time * 1000,
            "tokens_per_second": len(generated_tokens) / inference_time if inference_time > 0 else 0,
            "model_info": self.metadata["model_info"]
        }

    def _greedy_decode(self, logits: np.ndarray, max_length: int) -> List[int]:
        """Decodificación greedy simple para demo."""
        tokens = []

        for _ in range(max_length):
            # Obtener último token
            next_token_logits = logits[-1, :]  # [vocab_size]

            # Greedy: seleccionar token con mayor probabilidad
            next_token = np.argmax(next_token_logits)

            tokens.append(int(next_token))

            # Simular siguiente paso (en producción usar modelo completo)
            # Aquí solo añadimos ruido para demo
            break  # Solo un token para demo simple

        return tokens

    def benchmark_inference(self, prompts: List[str], num_runs: int = 5) -> Dict[str, Any]:
        """Benchmark de rendimiento de inferencia."""
        print(f"🏃 Ejecutando benchmark con {len(prompts)} prompts, {num_runs} runs cada uno...")

        results = []

        for prompt in prompts:
            prompt_results = []

            for run in range(num_runs):
                result = self.run_inference(prompt, max_length=20)
                prompt_results.append(result["inference_time_ms"])

            avg_time = np.mean(prompt_results)
            std_time = np.std(prompt_results)
            min_time = np.min(prompt_results)
            max_time = np.max(prompt_results)

            results.append({
                "prompt": prompt[:50] + "..." if len(prompt) > 50 else prompt,
                "avg_time_ms": avg_time,
                "std_time_ms": std_time,
                "min_time_ms": min_time,
                "max_time_ms": max_time,
                "runs": num_runs
            })

        # Estadísticas globales
        all_times = [r["avg_time_ms"] for r in results]
        global_stats = {
            "total_prompts": len(prompts),
            "global_avg_ms": np.mean(all_times),
            "global_std_ms": np.std(all_times),
            "global_min_ms": np.min(all_times),
            "global_max_ms": np.max(all_times)
        }

        return {
            "results": results,
            "global_stats": global_stats
        }

    def show_model_info(self):
        """Mostrar información del modelo cargado."""
        print("\n🤖 Información del Modelo Edge")
        print("=" * 50)

        if self.metadata:
            model_info = self.metadata.get("model_info", {})
            print(f"📛 Nombre: {model_info.get('name', 'Unknown')}")
            print(f"🔢 Parámetros: {model_info.get('parameters', 'Unknown'):,}")
            print(f"📏 Contexto máximo: {model_info.get('max_context', 'Unknown')}")
            print(f"📚 Vocabulario: {model_info.get('vocab_size', 'Unknown')}")

            export_info = self.metadata.get("export_info", {})
            print(f"📦 Formato: {export_info.get('format', 'Unknown')}")
            print(f"⚙️  Opset: {export_info.get('opset_version', 'Unknown')}")
            print(f"🗜️  Cuantizado: {export_info.get('quantized', 'Unknown')}")

        if self.session:
            input_info = self.session.get_inputs()[0]
            print(f"🔌 Input shape: {input_info.shape}")
            print(f"🏷️  Input name: {input_info.name}")

        print("=" * 50)


class MockTokenizer:
    """Tokenizer mock para demo (reemplazar con tokenizer real)."""

    def __init__(self, metadata: Dict[str, Any]):
        self.vocab_size = metadata.get("model_info", {}).get("vocab_size", 30000)
        self.bos_token = metadata.get("tokenizer_config", {}).get("bos_token", "<|endoftext|>")
        self.eos_token = metadata.get("tokenizer_config", {}).get("eos_token", "<|endoftext|>")

    def encode(self, text: str) -> List[int]:
        """Codificación simple mock."""
        # Simulación básica: cada caracter es un token
        tokens = [ord(c) % self.vocab_size for c in text]
        return [1] + tokens + [2]  # BOS + content + EOS

    def decode(self, tokens: List[int]) -> str:
        """Decodificación simple mock."""
        # Solo decodificar tokens de contenido
        chars = []
        for token in tokens:
            if token > 2:  # Ignorar BOS/EOS
                chars.append(chr(token % 256))
        return "".join(chars)


def main():
    """Función principal de la demo."""
    parser = argparse.ArgumentParser(description="Demo de inferencia edge con EmpoorioLM ONNX")
    parser.add_argument("--model_dir", required=True, help="Directorio con modelo ONNX exportado")
    parser.add_argument("--prompt", default="Hola, ¿cómo estás?", help="Prompt para inferencia")
    parser.add_argument("--benchmark", action="store_true", help="Ejecutar benchmark de rendimiento")
    parser.add_argument("--max_length", type=int, default=50, help="Longitud máxima de generación")

    args = parser.parse_args()

    if not ONNX_AVAILABLE:
        print("❌ ONNX Runtime no disponible. Instalar con: pip install onnxruntime")
        return

    try:
        # Crear demo
        demo = EdgeInferenceDemo(args.model_dir)

        # Mostrar información del modelo
        demo.show_model_info()

        if args.benchmark:
            # Ejecutar benchmark
            prompts = [
                "Hola, ¿cómo estás?",
                "¿Qué es la inteligencia artificial?",
                "Explica el aprendizaje automático en una oración.",
                "Genera una lista de tareas pendientes.",
                "¿Cuál es la capital de Francia?"
            ]

            print("\n🏃 Ejecutando Benchmark de Rendimiento")
            print("=" * 50)

            benchmark_results = demo.benchmark_inference(prompts, num_runs=3)

            print("\n📊 Resultados del Benchmark:")
            print(f"Prompts evaluados: {benchmark_results['global_stats']['total_prompts']}")
            print(f"Tiempo promedio global: {benchmark_results['global_stats']['global_avg_ms']:.2f} ms")
            print(f"Desviación estándar: {benchmark_results['global_stats']['global_std_ms']:.2f} ms")
            print(f"Tiempo mínimo: {benchmark_results['global_stats']['global_min_ms']:.2f} ms")
            print(f"Tiempo máximo: {benchmark_results['global_stats']['global_max_ms']:.2f} ms")
            print("\nDetalle por prompt:")
            for result in benchmark_results['results']:
                print(f"  {result['prompt']}: {result['avg_time_ms']:.1f} ± {result['std_time_ms']:.1f} ms")
        else:
            # Inferencia simple
            print(f"\n🗣️  Ejecutando inferencia con prompt: '{args.prompt}'")
            print("=" * 50)

            result = demo.run_inference(args.prompt, args.max_length)

            print("📝 Resultado:")
            print(f"Prompt: {result['prompt']}")
            print(f"Generado: {result['generated_text']}")
            print(f"Respuesta completa: {result['full_response']}")
            print("\n📊 Métricas:")
            print(f"Input tokens: {result['input_tokens']}")
            print(f"Output tokens: {result['output_tokens']}")
            print(f"Tiempo de inferencia: {result['inference_time_ms']:.2f} ms")
            print(f"Tokens/segundo: {result['tokens_per_second']:.1f}")
    except Exception as e:
        print(f"❌ Error en demo: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()