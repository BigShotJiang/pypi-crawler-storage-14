"""
Scripts para cargar datasets de evaluación funcionales desde Hugging Face.
Incluye MMLU, GSM8k y tareas personalizadas de AILOOS.
"""

import os
import time
import hashlib
import logging
import argparse
from typing import Dict, List, Any, Optional
from datasets import load_dataset, Dataset
import pandas as pd

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BenchmarkDatasetLoader:
    """Clase base para cargar y gestionar datasets de evaluación."""

    def __init__(self, cache_dir: str = "./data_cache"):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

    def load_dataset(self, name: str, config: Optional[str] = None, split: str = "test") -> Dataset:
        """Carga un dataset desde Hugging Face."""
        start_time = time.time()
        try:
            dataset = load_dataset(name, config, split=split, cache_dir=self.cache_dir)
            load_time = time.time() - start_time
            logger.info(f"Dataset {name} cargado en {load_time:.2f} segundos")
            return dataset
        except Exception as e:
            logger.error(f"Error cargando dataset {name}: {e}")
            raise

    def validate_integrity(self, dataset: Dataset, expected_count: int) -> bool:
        """Valida la integridad del dataset."""
        count = len(dataset)
        if count < expected_count:
            logger.warning(f"Dataset tiene {count} muestras, esperado al menos {expected_count}")
            return False
        logger.info(f"Dataset validado: {count} muestras")
        return True

    def save_locally(self, dataset: Dataset, filename: str) -> str:
        """Guarda el dataset localmente en formato parquet."""
        path = os.path.join(self.cache_dir, f"{filename}.parquet")
        dataset.to_pandas().to_parquet(path)
        logger.info(f"Dataset guardado en {path}")
        return path

    def compute_metrics(self, dataset: Dataset) -> Dict[str, Any]:
        """Computa métricas básicas del dataset."""
        return {
            "num_samples": len(dataset),
            "columns": list(dataset.column_names),
            "features": str(dataset.features),
        }

    def show_examples(self, dataset: Dataset, num_examples: int = 3) -> None:
        """Muestra ejemplos del dataset."""
        for i in range(min(num_examples, len(dataset))):
            print(f"Ejemplo {i+1}:")
            print(dataset[i])
            print("-" * 50)

class MMLULoader(BenchmarkDatasetLoader):
    """Cargador para MMLU (Massive Multitask Language Understanding)."""

    def load_mmlu(self) -> Dataset:
        """Carga un subconjunto del dataset MMLU para evitar rate limits."""
        import time
        # MMLU tiene múltiples configuraciones, cargamos un subconjunto de tareas
        all_data = []
        subjects = [
            "abstract_algebra", "anatomy", "astronomy", "business_ethics", "clinical_knowledge",
            "college_biology", "college_chemistry", "college_computer_science", "college_mathematics",
            "college_medicine"
        ]  # Solo 10 subjects para evitar rate limits

        for subject in subjects:
            try:
                data = self.load_dataset("cais/mmlu", subject, split="test")
                all_data.extend(data)
                time.sleep(1)  # Delay para evitar rate limits
            except Exception as e:
                logger.warning(f"Error cargando {subject}: {e}")

        # Crear dataset combinado
        combined_dataset = Dataset.from_list(all_data)
        return combined_dataset

    def run(self) -> Dict[str, Any]:
        """Ejecuta la carga completa de MMLU."""
        dataset = self.load_mmlu()
        if not self.validate_integrity(dataset, 1000):
            raise ValueError("Dataset MMLU no cumple con los requisitos mínimos")

        path = self.save_locally(dataset, "mmlu")
        metrics = self.compute_metrics(dataset)
        print("Ejemplos MMLU:")
        self.show_examples(dataset)

        return {
            "dataset": dataset,
            "path": path,
            "metrics": metrics,
        }

class GSM8kLoader(BenchmarkDatasetLoader):
    """Cargador para GSM8k (Grade School Math)."""

    def load_gsm8k(self) -> Dataset:
        """Carga el dataset GSM8k."""
        return self.load_dataset("gsm8k", "main", split="test")

    def run(self) -> Dict[str, Any]:
        """Ejecuta la carga completa de GSM8k."""
        dataset = self.load_gsm8k()
        if not self.validate_integrity(dataset, 1000):
            raise ValueError("Dataset GSM8k no cumple con los requisitos mínimos")

        path = self.save_locally(dataset, "gsm8k")
        metrics = self.compute_metrics(dataset)
        print("Ejemplos GSM8k:")
        self.show_examples(dataset)

        return {
            "dataset": dataset,
            "path": path,
            "metrics": metrics,
        }

class LegalContractLoader(BenchmarkDatasetLoader):
    """Cargador para análisis de contratos legales (CUAD)."""

    def load_cuad(self) -> Dataset:
        """Carga el dataset CUAD para análisis de contratos."""
        return self.load_dataset("lex_glue", "ledgar", split="test")

    def run(self) -> Dict[str, Any]:
        """Ejecuta la carga completa de CUAD."""
        dataset = self.load_cuad()
        if not self.validate_integrity(dataset, 1000):
            raise ValueError("Dataset CUAD no cumple con los requisitos mínimos")

        path = self.save_locally(dataset, "cuad_legal_contracts")
        metrics = self.compute_metrics(dataset)
        print("Ejemplos CUAD (Contratos Legales):")
        self.show_examples(dataset)

        return {
            "dataset": dataset,
            "path": path,
            "metrics": metrics,
        }

class EmailSummarizationLoader(BenchmarkDatasetLoader):
    """Cargador para resumen de emails (CNN/DailyMail)."""

    def load_emailsum(self) -> Dataset:
        """Carga el dataset CNN/DailyMail para resumen de textos (simulando emails)."""
        return self.load_dataset("cnn_dailymail", "3.0.0", split="test")

    def run(self) -> Dict[str, Any]:
        """Ejecuta la carga completa de EmailSum."""
        dataset = self.load_emailsum()
        if not self.validate_integrity(dataset, 1000):
            raise ValueError("Dataset EmailSum no cumple con los requisitos mínimos")

        path = self.save_locally(dataset, "emailsum")
        metrics = self.compute_metrics(dataset)
        print("Ejemplos EmailSum (Resumen de Emails):")
        self.show_examples(dataset)

        return {
            "dataset": dataset,
            "path": path,
            "metrics": metrics,
        }

class AppliedMathReasoningLoader(BenchmarkDatasetLoader):
    """Cargador para razonamiento matemático aplicado (SVAMP)."""

    def load_math(self) -> Dataset:
        """Carga el dataset Math QA para razonamiento matemático aplicado."""
        return self.load_dataset("math_qa", split="test")

    def run(self) -> Dict[str, Any]:
        """Ejecuta la carga completa de MATH."""
        dataset = self.load_math()
        if not self.validate_integrity(dataset, 1000):
            raise ValueError("Dataset MATH no cumple con los requisitos mínimos")

        path = self.save_locally(dataset, "competition_math")
        metrics = self.compute_metrics(dataset)
        print("Ejemplos MATH (Razonamiento Matemático Aplicado):")
        self.show_examples(dataset)

        return {
            "dataset": dataset,
            "path": path,
            "metrics": metrics,
        }

loaders = {
    "mmlu": MMLULoader,
    "gsm8k": GSM8kLoader,
    "legal": LegalContractLoader,
    "emailsum": EmailSummarizationLoader,
    "math": AppliedMathReasoningLoader,
}

def run_all():
    """Función para ejecutar todas las cargas de datasets."""
    loader = BenchmarkDatasetLoader()

    print("Cargando MMLU...")
    mmlu_loader = MMLULoader()
    mmlu_result = mmlu_loader.run()

    print("\nCargando GSM8k...")
    gsm8k_loader = GSM8kLoader()
    gsm8k_result = gsm8k_loader.run()

    print("\nCargando CUAD (Contratos Legales)...")
    legal_loader = LegalContractLoader()
    legal_result = legal_loader.run()

    print("\nCargando CNN/DailyMail (Resumen de Emails)...")
    email_loader = EmailSummarizationLoader()
    email_result = email_loader.run()

    print("\nCargando SVAMP (Razonamiento Matemático)...")
    math_loader = AppliedMathReasoningLoader()
    math_result = math_loader.run()

    print("\nResumen de cargas:")
    results = {
        "MMLU": mmlu_result["metrics"],
        "GSM8k": gsm8k_result["metrics"],
        "Legal Contracts": legal_result["metrics"],
        "Email Summarization (CNN/DailyMail)": email_result["metrics"],
        "Applied Math (SVAMP)": math_result["metrics"],
    }

    for name, metrics in results.items():
        print(f"{name}: {metrics['num_samples']} muestras")

def main():
    parser = argparse.ArgumentParser(description="Benchmark Dataset Loader")
    parser.add_argument("--list-datasets", action="store_true", help="List available datasets")
    parser.add_argument("--download-all", action="store_true", help="Download all datasets")
    parser.add_argument("--load-dataset", type=str, help="Load a specific dataset by name")

    args = parser.parse_args()

    if args.list_datasets:
        print("Available datasets:")
        for name in loaders.keys():
            print(f"- {name}")
    elif args.download_all:
        for name, LoaderClass in loaders.items():
            print(f"Loading {name}...")
            loader = LoaderClass()
            try:
                result = loader.run()
                print(f"Loaded {name}: {result['metrics']['num_samples']} samples")
            except Exception as e:
                print(f"Error loading {name}: {e}")
    elif args.load_dataset:
        name = args.load_dataset.lower()
        if name in loaders:
            loader = loaders[name]()
            try:
                result = loader.run()
                print(f"Loaded {name}: {result['metrics']['num_samples']} samples")
            except Exception as e:
                print(f"Error loading {name}: {e}")
        else:
            print(f"Dataset {name} not found. Use --list-datasets to see available options.")
    else:
        run_all()

if __name__ == "__main__":
    main()