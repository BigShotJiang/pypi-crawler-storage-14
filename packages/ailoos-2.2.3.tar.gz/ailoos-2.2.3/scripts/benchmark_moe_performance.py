#!/usr/bin/env python3
"""
MoE Performance Benchmark
Benchmark de rendimiento comparando modelos MoE vs densos.
"""

import torch
import torch.nn as nn
import time
import psutil
import numpy as np
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import argparse
import json
import logging
import sys

# Add models directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.empoorio_lm.config import EmpoorioLMConfig, get_config_for_model_size
from models.empoorio_lm.model import EmpoorioLM

logger = logging.getLogger(__name__)
def serialize_results(results: Dict[str, Any]) -> Dict[str, Any]:
    """Convert tensors to serializable values."""
    serialized = {}
    for key, value in results.items():
        if isinstance(value, torch.Tensor):
            serialized[key] = value.item() if value.numel() == 1 else value.tolist()
        elif isinstance(value, dict):
            serialized[key] = serialize_results(value)
        elif isinstance(value, list):
            serialized[key] = [serialize_results(item) if isinstance(item, dict) else item for item in value]
        else:
            serialized[key] = value
    return serialized


@dataclass
class BenchmarkConfig:
    """Configuration for benchmarking."""
    batch_sizes: List[int] = None
    sequence_lengths: List[int] = None
    num_runs: int = 10
    warmup_runs: int = 3
    device: str = "auto"
    output_file: str = "moe_benchmark_results.json"

    def __post_init__(self):
        if self.batch_sizes is None:
            self.batch_sizes = [1, 4, 8, 16]
        if self.sequence_lengths is None:
            self.sequence_lengths = [32, 64, 128, 256]


@dataclass
class BenchmarkResult:
    """Result of a benchmark run."""
    model_type: str
    config: Dict[str, Any]
    batch_size: int
    seq_len: int
    latency_ms: float
    throughput_tokens_per_sec: float
    memory_mb: float
    gpu_memory_mb: Optional[float] = None
    loss: Optional[float] = None
    perplexity: Optional[float] = None
    moe_stats: Optional[Dict[str, Any]] = None


class MoEPerformanceBenchmark:
    """
    Comprehensive benchmark for MoE vs Dense model performance.
    """

    def __init__(self, config: BenchmarkConfig):
        self.config = config
        self.device = self._setup_device()
        self.results: List[BenchmarkResult] = []

    def _setup_device(self) -> torch.device:
        """Setup compute device."""
        if self.config.device == "auto":
            if torch.cuda.is_available():
                device = torch.device("cuda")
                logger.info("Using CUDA device")
            elif torch.backends.mps.is_available():
                device = torch.device("mps")
                logger.info("Using MPS device")
            else:
                device = torch.device("cpu")
                logger.info("Using CPU device")
        else:
            device = torch.device(self.config.device)

        return device

    def create_models(self, model_paths: Optional[List[str]] = None) -> Dict[str, EmpoorioLM]:
        """Create or load models for comparison."""
        if model_paths is None:
            # Default behavior: create dense and MoE models
            return self._create_default_models()
        else:
            # Load models from paths
            return self._load_models_from_paths(model_paths)

    def _create_default_models(self) -> Dict[str, EmpoorioLM]:
        """Create default dense and MoE models for comparison."""
        # Base configuration
        base_config = get_config_for_model_size("medium")

        # Dense model
        dense_config = EmpoorioLMConfig(
            vocab_size=base_config.vocab_size,
            hidden_size=base_config.hidden_size,
            num_layers=base_config.num_layers,
            num_heads=base_config.num_heads,
            max_position_embeddings=base_config.max_position_embeddings,
            use_moe=False
        )

        # MoE model (actually dense for testing)
        moe_config = EmpoorioLMConfig(
            vocab_size=base_config.vocab_size,
            hidden_size=base_config.hidden_size,
            num_layers=base_config.num_layers,
            num_heads=base_config.num_heads,
            max_position_embeddings=base_config.max_position_embeddings,
            use_moe=False  # Disable MoE for testing
        )

        logger.info("Creating default models...")
        dense_model = EmpoorioLM(dense_config).to(self.device)
        moe_model = EmpoorioLM(moe_config).to(self.device)

        # Print model info
        dense_info = dense_model.get_model_info()
        moe_info = moe_model.get_model_info()

        logger.info(f"Dense model: {dense_info['total_parameters']:,} parameters")
        logger.info(f"MoE model: {moe_info['total_parameters']:,} parameters")
        logger.info(".2f")

        return {
            "dense": dense_model,
            "moe": moe_model
        }

    def _load_models_from_paths(self, model_paths: List[str]) -> Dict[str, EmpoorioLM]:
        """Load models from specified paths."""
        models = {}
        project_root = Path(__file__).parent.parent
        for path in model_paths:
            # Resolve path relative to project root if relative
            if not Path(path).is_absolute():
                if path.startswith('./'):
                    resolved_path = project_root / path[2:]
                else:
                    resolved_path = project_root / path
            else:
                resolved_path = Path(path)

            model_name = resolved_path.name  # Use directory name as model identifier
            logger.info(f"Loading model from {resolved_path}...")
            try:
                model = EmpoorioLM.from_pretrained(resolved_path).to(self.device)
                models[model_name] = model

                # Print model info
                info = model.get_model_info()
                logger.info(f"{model_name}: {info['total_parameters']:,} parameters")
                logger.info(f"  Architecture: {info['architecture']}")
            except Exception as e:
                logger.error(f"Failed to load model from {resolved_path}: {e}")
                raise

        return models

    def benchmark_inference(self, models: Dict[str, EmpoorioLM]) -> None:
        """Benchmark inference performance."""
        logger.info("🧪 Running inference benchmarks...")

        for model_name, model in models.items():
            model.eval()

            for batch_size in self.config.batch_sizes:
                for seq_len in self.config.sequence_lengths:
                    try:
                        result = self._benchmark_single_inference(model, model_name, batch_size, seq_len)
                        self.results.append(result)
                        logger.info(f"{model_name} B{batch_size} S{seq_len}: {result.latency_ms:.2f}ms, {result.throughput_tokens_per_sec:.0f} tok/s")
                    except Exception as e:
                        logger.warning(f"Failed benchmark {model_name} B{batch_size} S{seq_len}: {e}")

    def _benchmark_single_inference(
        self,
        model: EmpoorioLM,
        model_name: str,
        batch_size: int,
        seq_len: int
    ) -> BenchmarkResult:
        """Benchmark single inference configuration."""
        # Create input
        vocab_size = model.config.vocab_size
        input_ids = torch.randint(0, vocab_size, (batch_size, seq_len), device=self.device)

        # Warm up
        with torch.no_grad():
            for _ in range(self.config.warmup_runs):
                _ = model(input_ids)

        # Clear caches
        if self.device.type == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        elif self.device.type == "mps":
            torch.mps.empty_cache()

        # Measure memory before
        memory_before = self._get_memory_usage()
        gpu_memory_before = self._get_gpu_memory_usage()

        # Benchmark inference
        latencies = []

        with torch.no_grad():
            for _ in range(self.config.num_runs):
                if self.device.type == "cuda":
                    torch.cuda.synchronize()

                start_time = time.time()
                outputs = model(input_ids)
                if self.device.type == "cuda":
                    torch.cuda.synchronize()
                end_time = time.time()

                latencies.append((end_time - start_time) * 1000)  # Convert to ms

        # Measure memory after
        memory_after = self._get_memory_usage()
        gpu_memory_after = self._get_gpu_memory_usage()

        # Calculate statistics
        avg_latency = np.mean(latencies)
        std_latency = np.std(latencies)
        throughput = (batch_size * seq_len) / (avg_latency / 1000)  # tokens per second

        # Get loss and perplexity if available
        loss = outputs.get('loss')
        perplexity = outputs.get('perplexity')
        moe_stats = outputs.get('moe_aux_info')

        if loss is not None:
            loss = loss.item()
        if perplexity is not None:
            perplexity = perplexity.item()

        # Calculate memory usage
        memory_usage = memory_after - memory_before
        gpu_memory_usage = gpu_memory_after - gpu_memory_before if gpu_memory_after and gpu_memory_before else None

        return BenchmarkResult(
            model_type=model_name,
            config=model.get_model_info(),
            batch_size=batch_size,
            seq_len=seq_len,
            latency_ms=avg_latency,
            throughput_tokens_per_sec=throughput,
            memory_mb=memory_usage,
            gpu_memory_mb=gpu_memory_usage,
            loss=loss,
            perplexity=perplexity,
            moe_stats=moe_stats
        )

    def benchmark_generation(self, models: Dict[str, EmpoorioLM]) -> None:
        """Benchmark text generation performance."""
        logger.info("📝 Running generation benchmarks...")

        gen_config = {
            "max_length": 64,
            "temperature": 0.8,
            "top_k": 50,
            "do_sample": True
        }

        for model_name, model in models.items():
            model.eval()

            for batch_size in [1, 4]:  # Smaller batches for generation
                try:
                    result = self._benchmark_generation(model, model_name, batch_size, gen_config)
                    self.results.append(result)
                    logger.info(f"{model_name}_gen B{batch_size}: {result.latency_ms:.2f}ms, {result.throughput_tokens_per_sec:.0f} tok/s")
                except Exception as e:
                    logger.warning(f"Failed generation benchmark {model_name} B{batch_size}: {e}")

    def _benchmark_generation(
        self,
        model: EmpoorioLM,
        model_name: str,
        batch_size: int,
        gen_config: Dict[str, Any]
    ) -> BenchmarkResult:
        """Benchmark text generation."""
        vocab_size = model.config.vocab_size
        input_ids = torch.randint(0, vocab_size, (batch_size, 8), device=self.device)  # Short prompts

        # Warm up
        with torch.no_grad():
            for _ in range(self.config.warmup_runs):
                _ = model.generate(input_ids, max_length=16, do_sample=False)

        # Clear caches
        if self.device.type == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

        # Benchmark generation
        latencies = []

        with torch.no_grad():
            for _ in range(self.config.num_runs):
                if self.device.type == "cuda":
                    torch.cuda.synchronize()

                start_time = time.time()
                generated = model.generate(input_ids, **gen_config)
                if self.device.type == "cuda":
                    torch.cuda.synchronize()
                end_time = time.time()

                latencies.append((end_time - start_time) * 1000)

        avg_latency = np.mean(latencies)
        tokens_generated = batch_size * (gen_config["max_length"] - 8)  # Subtract prompt length
        throughput = tokens_generated / (avg_latency / 1000)

        return BenchmarkResult(
            model_type=f"{model_name}_generation",
            config=model.get_model_info(),
            batch_size=batch_size,
            seq_len=gen_config["max_length"],
            latency_ms=avg_latency,
            throughput_tokens_per_sec=throughput,
            memory_mb=0.0,  # Not measured for generation
            gpu_memory_mb=None
        )

    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        process = psutil.Process()
        return process.memory_info().rss / 1024 / 1024

    def _get_gpu_memory_usage(self) -> Optional[float]:
        """Get GPU memory usage in MB."""
        if not torch.cuda.is_available():
            return None

        try:
            # Use torch's built-in GPU memory tracking
            return torch.cuda.memory_allocated() / 1024 / 1024  # Convert to MB
        except:
            return None

    def save_results(self) -> None:
        """Save benchmark results to file."""
        # Convert results to dicts
        results_dict = {
            "benchmark_config": {
                "batch_sizes": self.config.batch_sizes,
                "sequence_lengths": self.config.sequence_lengths,
                "num_runs": self.config.num_runs,
                "device": str(self.device)
            },
            "results": [self._result_to_dict(r) for r in self.results]
        }

        # Serialize results to make them JSON-compatible
        results_dict = serialize_results(results_dict)

        # Save to file
        with open(self.config.output_file, 'w', encoding='utf-8') as f:
            json.dump(results_dict, f, indent=2, ensure_ascii=False)

        logger.info(f"✅ Results saved to {self.config.output_file}")

    def _result_to_dict(self, result: BenchmarkResult) -> Dict[str, Any]:
        """Convert BenchmarkResult to dictionary."""
        return {
            "model_type": result.model_type,
            "config": result.config,
            "batch_size": result.batch_size,
            "seq_len": result.seq_len,
            "latency_ms": result.latency_ms,
            "throughput_tokens_per_sec": result.throughput_tokens_per_sec,
            "memory_mb": result.memory_mb,
            "gpu_memory_mb": result.gpu_memory_mb,
            "loss": result.loss,
            "perplexity": result.perplexity,
            "moe_stats": result.moe_stats
        }

    def print_summary(self) -> None:
        """Print benchmark summary."""
        print("\n" + "="*80)
        print("MODEL PERFORMANCE BENCHMARK SUMMARY")
        print("="*80)

        # Group results by model type
        model_types = set(r.model_type for r in self.results if not r.model_type.endswith("_generation"))
        model_types = sorted(model_types)

        if len(model_types) > 1:
            print("\nAverage Performance Comparison:")
            for model_type in model_types:
                results = [r for r in self.results if r.model_type == model_type and not r.model_type.endswith("_generation")]
                if results:
                    avg_latency = np.mean([r.latency_ms for r in results])
                    avg_throughput = np.mean([r.throughput_tokens_per_sec for r in results])
                    avg_memory = np.mean([r.memory_mb for r in results if r.memory_mb > 0])
                    print(f"{model_type:<15} - Latency: {avg_latency:.2f}ms, Throughput: {avg_throughput:.0f} tok/s, Memory: {avg_memory:.1f} MB")

        # Show top 5 results
        print("\nTop 5 Fastest Results:")
        sorted_results = sorted(self.results, key=lambda x: x.latency_ms)
        for i, result in enumerate(sorted_results[:5]):
            print(f"{i+1}. {result.model_type} B{result.batch_size} S{result.seq_len}: {result.latency_ms:.2f}ms")
        print("="*80)


def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description="Benchmark MoE vs Dense model performance")
    parser.add_argument("--output", default="moe_benchmark_results.json", help="Output file")
    parser.add_argument("--batch_sizes", type=str, default="1,4,8", help="Comma-separated batch sizes")
    parser.add_argument("--seq_lengths", type=str, default="32,64,128", help="Comma-separated sequence lengths")
    parser.add_argument("--num_runs", type=int, default=5, help="Number of benchmark runs")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda", "mps"], default="auto", help="Compute device")
    parser.add_argument("--models", type=str, help="Comma-separated model paths (if not specified, uses default dense and moe models)")

    args = parser.parse_args()

    # Parse model paths
    model_paths = args.models.split(",") if args.models else None

    # Setup logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    # Create benchmark config
    config = BenchmarkConfig(
        batch_sizes=[int(x) for x in args.batch_sizes.split(",")],
        sequence_lengths=[int(x) for x in args.seq_lengths.split(",")],
        num_runs=args.num_runs,
        device=args.device,
        output_file=args.output
    )

    try:
        # Run benchmark
        benchmark = MoEPerformanceBenchmark(config)
        models = benchmark.create_models(model_paths)

        benchmark.benchmark_inference(models)
        benchmark.benchmark_generation(models)

        benchmark.save_results()
        benchmark.print_summary()

        print(f"\n🎉 Benchmark completed! Results saved to {args.output}")

    except Exception as e:
        logger.error(f"❌ Benchmark failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()