#!/usr/bin/env python3
"""
PRUEBA DE FUEGO LINGÜÍSTICA - FASE REAL-6
Entrenamiento real de EmpoorioLM con texto usando el motor validado
"""

import asyncio
import sys
import torch
import torch.nn as nn
from pathlib import Path
from torch.utils.data import Dataset, DataLoader

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig, EmpoorioLMTokenizer

class TextDataset(Dataset):
    """Dataset simple para texto."""

    def __init__(self, texts, tokenizer, max_length=128):
        self.tokenizer = tokenizer
        self.max_length = max_length

        # Procesar textos
        self.data = []
        for text in texts:
            tokens = tokenizer.encode(text, max_length=max_length)
            if len(tokens) >= 2:  # Necesitamos al menos input y target
                self.data.append(tokens)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        tokens = self.data[idx]
        # Para language modeling: input = todos menos último, target = todos menos primero
        input_ids = torch.tensor(tokens[:-1], dtype=torch.long)
        labels = torch.tensor(tokens[1:], dtype=torch.long)
        return input_ids, labels

def collate_fn(batch):
    """Collate function para DataLoader."""
    inputs, labels = zip(*batch)

    # Pad sequences to max length in batch
    max_len = max(len(seq) for seq in inputs)

    padded_inputs = []
    padded_labels = []

    for inp, lab in zip(inputs, labels):
        pad_len = max_len - len(inp)

        # Pad inputs and labels
        padded_input = torch.cat([inp, torch.zeros(pad_len, dtype=torch.long)])
        padded_label = torch.cat([lab, torch.full((pad_len,), -100, dtype=torch.long)])

        padded_inputs.append(padded_input)
        padded_labels.append(padded_label)

    return torch.stack(padded_inputs), torch.stack(padded_labels)

async def test_linguistic_training():
    """Prueba de fuego: entrenar EmpoorioLM con texto real."""
    print("🔥 PRUEBA DE FUEGO LINGÜÍSTICA - FASE REAL-6")
    print("=" * 60)
    print("Entrenando EmpoorioLM con TEXTO REAL")
    print("Usando el motor de aprendizaje VALIDADO en FASE REAL-5")
    print()

    # Configurar dispositivo
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Dispositivo: {device}")

    # Crear modelo pequeño para demo
    config = EmpoorioLMConfig(
        vocab_size=30000,
        hidden_size=256,  # Pequeño para demo rápida
        num_layers=4,
        num_heads=8,
        max_position_embeddings=128
    )

    model = EmpoorioLM(config)
    model.to(device)

    tokenizer = EmpoorioLMTokenizer()

    print("✅ Modelo EmpoorioLM creado:")
    print(f"   Parámetros: {sum(p.numel() for p in model.parameters()):,}")
    print(f"   Capas: {config.num_layers}")
    print(f"   Cabezas de atención: {config.num_heads}")
    print(f"   Dimensión oculta: {config.hidden_size}")

    # Datos de entrenamiento - texto real pequeño pero representativo
    training_texts = [
        "To be or not to be, that is the question.",
        "All the world's a stage, and all the men and women merely players.",
        "The course of true love never did run smooth.",
        "Brevity is the soul of wit.",
        "Uneasy lies the head that wears a crown.",
        "This above all: to thine own self be true.",
        "Though this be madness, yet there is method in't.",
        "There are more things in heaven and earth, Horatio, than are dreamt of in your philosophy.",
        "The lady doth protest too much, methinks.",
        "Something is rotten in the state of Denmark.",
        # Más texto para mejor entrenamiento
        "Friends, Romans, countrymen, lend me your ears.",
        "The better part of valour is discretion.",
        "A horse! A horse! My kingdom for a horse!",
        "Cry 'Havoc,' and let slip the dogs of war.",
        "Now is the winter of our discontent.",
        "Heavy is the head that wears the crown.",
        "All that glitters is not gold.",
        "The pen is mightier than the sword.",
        "Ask not what your country can do for you.",
        "I have a dream that one day this nation."
    ] * 5  # Multiplicar para más datos

    print(f"\n📚 Datos de entrenamiento: {len(training_texts)} textos")

    # Crear dataset y dataloader
    dataset = TextDataset(training_texts, tokenizer, max_length=64)
    dataloader = DataLoader(dataset, batch_size=8, shuffle=True, collate_fn=collate_fn)

    print(f"   Secuencias procesadas: {len(dataset)}")
    print(f"   Batch size: 8")

    # Optimizador - usando AdamW como en FASE REAL-5
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)
    criterion = nn.CrossEntropyLoss(ignore_index=-100)

    print("
🚀 Iniciando entrenamiento lingüístico..."    print("Objetivo: Loss < 2.0 (buen aprendizaje lingüístico)")

    model.train()
    losses = []

    # Entrenamiento real
    for epoch in range(50):  # Suficiente para ver aprendizaje
        epoch_loss = 0.0
        num_batches = 0

        for batch_inputs, batch_labels in dataloader:
            batch_inputs = batch_inputs.to(device)
            batch_labels = batch_labels.to(device)

            optimizer.zero_grad()

            # Forward pass
            outputs = model(batch_inputs, labels=batch_labels)
            loss = outputs["loss"]

            # Backward pass
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            num_batches += 1

        avg_epoch_loss = epoch_loss / num_batches
        losses.append(avg_epoch_loss)

        perplexity = torch.exp(torch.tensor(avg_epoch_loss)).item()

        print("4d"
        # Early stopping si converge bien
        if avg_epoch_loss < 2.0 and epoch > 10:
            print("🎯 ¡CONVERGENCIA LINGÜÍSTICA LOGRADA!")
            break

    # Resultados finales
    final_loss = losses[-1]
    initial_loss = losses[0]
    improvement = (initial_loss - final_loss) / initial_loss * 100
    final_perplexity = torch.exp(torch.tensor(final_loss)).item()

    print("
📊 RESULTADOS FINALES - APRENDIZAJE LINGÜÍSTICO:"    print(".4f"    print(".4f"    print(".1f"    print(".2f"
    # Evaluar aprendizaje lingüístico
    linguistic_learning_achieved = final_loss < 3.0 and improvement > 30

    if linguistic_learning_achieved:
        print("✅ APRENDIZAJE LINGÜÍSTICO CONFIRMADO!")
        print("✅ EmpoorioLM APRENDE LENGUAJE REAL!")
        return True
    else:
        print("⚠️ Aprendizaje lingüístico limitado")
        return False

async def test_text_generation():
    """Probar generación de texto después del entrenamiento."""
    print("\n🎨 PRUEBA DE GENERACIÓN DE TEXTO")
    print("-" * 40)

    # Configurar modelo pequeño
    config = EmpoorioLMConfig(
        vocab_size=30000,
        hidden_size=256,
        num_layers=4,
        num_heads=8,
        max_position_embeddings=128
    )

    model = EmpoorioLM(config)
    tokenizer = EmpoorioLMTokenizer()

    # Texto de entrada
    prompt = "To be or not to"
    print(f"Prompt: '{prompt}'")

    # Tokenizar
    inputs = tokenizer(prompt, return_tensors="pt")
    input_ids = inputs["input_ids"]

    print(f"Tokens de entrada: {input_ids.tolist()}")

    # Generar texto
    model.eval()
    with torch.no_grad():
        generated = model.generate(
            input_ids,
            max_length=20,
            temperature=0.8,
            do_sample=True,
            eos_token_id=tokenizer.eos_token_id
        )

    # Decodificar
    generated_text = tokenizer.decode(generated[0].tolist())
    print(f"Texto generado: '{generated_text}'")

    # Evaluar si tiene sentido lingüístico básico
    has_meaningful_words = any(word in generated_text.lower() for word in ["the", "and", "that", "with", "from"])
    not_repeated = len(set(generated_text.split())) > len(generated_text.split()) * 0.5

    generation_quality = has_meaningful_words and not_repeated

    if generation_quality:
        print("✅ GENERACIÓN DE TEXTO FUNCIONAL!")
        return True
    else:
        print("⚠️ Generación de texto básica")
        return False

async def main():
    """Función principal - Prueba de Fuego Lingüística."""
    print("🎯 FASE REAL-6: PRUEBA DE FUEGO LINGÜÍSTICA")
    print("=" * 55)
    print("Conectando el motor de aprendizaje VALIDADO")
    print("con el Transformer GPT-2 para entrenar LENGUAJE REAL")
    print()

    start_time = time.time()

    # Ejecutar pruebas lingüísticas
    training_success = await test_linguistic_training()
    generation_success = await test_text_generation()

    elapsed = time.time() - start_time

    # Resultados finales
    print("\n" + "=" * 55)
    print("🎊 RESULTADOS FASE REAL-6")
    print("=" * 55)

    if training_success and generation_success:
        print("✅ PRUEBA DE FUEGO LINGÜÍSTICA SUPERADA!")
        print("✅ EmpoorioLM APRENDE LENGUAJE REAL!")
        print("✅ SISTEMA COMPLETO OPERATIVO!")
        print("\n🏆 FASE REAL-6: ÉXITO TOTAL")
        print("💡 El sistema APRENDE PATRONES LINGÜÍSTICOS REALES")
        print("🚀 LISTO PARA ESCALADO A DATASETS GRANDES")
    else:
        print("⚠️ Prueba de fuego parcialmente completada")

    print("
📊 MÉTRICAS FINALES:"    print("   • Entrenamiento lingüístico:", "✅" if training_success else "❌")
    print("   • Generación de texto:", "✅" if generation_success else "❌")

    print(".2f"
    return 0 if (training_success and generation_success) else 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)