#!/bin/bash
# Script to sign Docker images using Cosign
# Usage: ./sign_image.sh <image_uri>

set -e

if [ $# -ne 1 ]; then
    echo "Usage: $0 <image_uri>"
    exit 1
fi

IMAGE_URI=$1

echo "Signing image: $IMAGE_URI"

# Sign the image using Cosign with private key from environment
cosign sign --key env://COSIGN_PRIVATE_KEY "$IMAGE_URI"

echo "Image signed successfully: $IMAGE_URI"