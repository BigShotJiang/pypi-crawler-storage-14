#!/usr/bin/env python3
"""
SCRIPT DE TEST: Prueba directa del API de chat
Demuestra que el API route funciona pero el frontend no lo usa.
"""

import requests
import json
import time

def test_chat_api():
    """Prueba el API de chat directamente."""
    print("🧪 TESTING CHAT API DIRECTLY")
    print("=" * 40)

    # URL del frontend (debe estar corriendo)
    base_url = "http://localhost:3000"

    # Test 1: Verificar que el frontend responde
    try:
        response = requests.get(f"{base_url}/", timeout=5)
        if response.status_code == 200:
            print("✅ Frontend está corriendo en localhost:3000")
        else:
            print(f"⚠️  Frontend responde con status {response.status_code}")
    except Exception as e:
        print(f"❌ Frontend no disponible: {e}")
        print("💡 Asegúrate de que 'npm run dev' esté corriendo en el directorio frontend")
        return

    # Test 2: Probar el API de chat directamente
    print("\n🔍 Probando API /api/chat...")

    test_message = "Hola EmpoorioLM, ¿cómo estás?"
    payload = {
        "message": test_message,
        "prevMessages": [],
        "id": "test_chat_123"
    }

    try:
        start_time = time.time()
        response = requests.post(
            f"{base_url}/api/chat",
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        latency = time.time() - start_time

        print(f"📡 Status: {response.status_code}")
        print(f"⏱️  Latencia: {latency:.2f}s")

        if response.status_code == 200:
            data = response.json()
            print("📨 Respuesta del API:")
            print(f"   ID: {data.get('id', 'N/A')}")
            print(f"   Role: {data.get('role', 'N/A')}")
            print(f"   Content: {data.get('content', 'N/A')[:100]}...")
            print(f"   Usage: {data.get('usage', 'N/A')}")

            # Verificar si es respuesta mock o real
            if "Hola! Soy EmpoorioLM" in data.get('content', ''):
                print("🎭 DETECTADO: El API está devolviendo respuestas MOCK")
                print("💡 Esto confirma que el backend real no está disponible")
            else:
                print("🤖 El API está conectado a un backend real de EmpoorioLM")

        else:
            print(f"❌ Error en API: {response.text}")

    except Exception as e:
        print(f"❌ Error conectando al API: {e}")

    # Test 3: Verificar configuración del cliente EmpoorioLM
    print("\n🔧 Verificando configuración del cliente...")

    # Simular la lógica del cliente EmpoorioLM
    empoorio_api_url = "https://api.ailoos.com/empoorio-lm"  # URL por defecto

    try:
        health_response = requests.get(f"{empoorio_api_url}/api/v1/empoorio-lm/health", timeout=5)
        if health_response.status_code == 200:
            print("✅ Backend de EmpoorioLM disponible en la URL configurada")
        else:
            print(f"❌ Backend de EmpoorioLM NO disponible (status: {health_response.status_code})")
    except Exception as e:
        print(f"❌ Backend de EmpoorioLM NO disponible: {e}")

    print("\n" + "=" * 40)
    print("📋 RESULTADO DEL TEST:")
    print("✅ El API route /api/chat existe y funciona")
    print("❌ El frontend NO está conectado al API route")
    print("❌ No hay backend real de EmpoorioLM corriendo")
    print("🎭 El chat usa respuestas mock por ahora")

if __name__ == "__main__":
    test_chat_api()