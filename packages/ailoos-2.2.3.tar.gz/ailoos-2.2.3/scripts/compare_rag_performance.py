#!/usr/bin/env python3
"""
Script para comparación completa de rendimiento RAG + CAG vs RAG estándar con EmpoorioLM.

Este script ejecuta múltiples benchmarks para comparar:
- Rendimiento con/sin cache aumentado
- Eficiencia en diferentes tipos de consultas
- Consumo de recursos
- Calidad de respuestas
- Costos operativos

Uso:
    python scripts/compare_rag_performance.py --test_types latency,hit_rate,quality --num_queries 100
"""

import argparse
import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import sys
import psutil
import os

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.rag.cache_augmented.cache_augmented_rag import CacheAugmentedRAG
from ailoos.rag.techniques.naive_rag import NaiveRAG
from ailoos.rag.core.generators import EmpoorioLMGenerator
from ailoos.rag.core.retrievers import VectorRetriever
from ailoos.rag.core.evaluators import BasicRAGEvaluator

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class RAGPerformanceComparator:
    """Comparador de rendimiento entre RAG con/sin Cache Augmented Generation."""

    def __init__(self, config: Dict[str, Any]):
        """
        Inicializar el comparador.

        Args:
            config: Configuración del experimento
        """
        self.config = config
        self.results = {
            'experiment_config': config,
            'test_results': {},
            'summary': {},
            'timestamp': time.time()
        }

    def get_system_resources(self) -> Dict[str, Any]:
        """Obtener métricas de recursos del sistema."""
        return {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'memory_used_mb': psutil.virtual_memory().used / 1024 / 1024,
            'disk_usage_percent': psutil.disk_usage('/').percent
        }

    def setup_rag_systems(self) -> Tuple[CacheAugmentedRAG, NaiveRAG]:
        """Configurar ambos sistemas RAG para comparación."""
        logger.info("Configurando sistemas RAG para comparación...")

        # Configuración común
        base_config = {
            'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
            'vector_store': {
                'type': 'chroma',
                'collection_name': 'performance_comparison',
                'persist_directory': './data/performance_comparison'
            }
        }

        retriever_config = base_config

        generator_config = {
            'empoorio_api_config': {
                'model_path': self.config.get('model_path', './models/empoorio_lm/v1.0.0'),
                'device': 'cpu',
                'max_tokens': 512,
                'temperature': 0.7
            },
            'generation_config': {
                'max_new_tokens': 256,
                'temperature': 0.7,
                'do_sample': True
            },
            'caching': {
                'max_size': 100,
                'ttl_seconds': 3600
            }
        }

        evaluator_config = {}

        base_rag_config = {
            'retriever_class': VectorRetriever,
            'retriever_config': retriever_config,
            'generator_class': EmpoorioLMGenerator,
            'generator_config': generator_config,
            'evaluator_class': BasicRAGEvaluator,
            'evaluator_config': evaluator_config
        }

        # Sistema con CAG
        cache_config = {
            'model_name': 'all-MiniLM-L6-v2',
            'similarity_threshold': self.config.get('similarity_threshold', 0.8),
            'max_size': self.config.get('cache_max_size', 1000),
            'eviction_policy': self.config.get('eviction_policy', 'LRU'),
            'cache_file': f'./cache/performance_comparison_{int(time.time())}.pkl'
        }

        cag_config = {
            'base_rag_class': NaiveRAG,
            'base_rag_config': base_rag_config,
            'cache_config': cache_config,
            'cache_enabled': True,
            'quality_config': {}
        }

        rag_with_cag = CacheAugmentedRAG(cag_config)
        rag_without_cag = NaiveRAG(base_rag_config)

        logger.info("Sistemas RAG configurados para comparación")
        return rag_with_cag, rag_without_cag

    def generate_test_queries(self) -> Dict[str, List[str]]:
        """Generar diferentes tipos de consultas de prueba."""
        query_sets = {
            'simple': [
                "¿Qué es la IA?",
                "¿Cómo funciona el machine learning?",
                "¿Qué es el deep learning?",
                "¿Qué es el NLP?",
                "¿Qué es la visión por computadora?"
            ],
            'complex': [
                "¿Cuáles son las principales diferencias entre aprendizaje supervisado, no supervisado y por refuerzo, y en qué situaciones se aplicaría cada uno?",
                "¿Cómo afecta el sesgo en los datos de entrenamiento a la calidad y equidad de los modelos de IA?",
                "¿Qué técnicas existen para explicar las decisiones de modelos de aprendizaje profundo complejos?",
                "¿Cómo se mide y evalúa la calidad de un modelo de lenguaje grande como EmpoorioLM?"
            ],
            'repeated': [
                "¿Qué es la inteligencia artificial?",
                "¿Qué es la inteligencia artificial?",  # Repetida
                "¿Qué es la inteligencia artificial?",  # Repetida
                "¿Cómo funciona el aprendizaje automático?",
                "¿Cómo funciona el aprendizaje automático?",  # Repetida
                "¿Cómo funciona el aprendizaje automático?"   # Repetida
            ],
            'similar': [
                "¿Qué es la IA?",
                "¿Qué significa IA?",
                "¿Qué es la inteligencia artificial?",
                "¿Cómo opera el machine learning?",
                "¿Cómo funciona el aprendizaje automático?",
                "¿Cómo se entrena un modelo de ML?"
            ]
        }

        # Expandir cada conjunto según necesidad
        for key, queries in query_sets.items():
            num_repetitions = max(1, self.config.get('num_queries', 50) // len(queries))
            query_sets[key] = (queries * num_repetitions)[:self.config.get('num_queries', 50)]

        logger.info(f"Generados conjuntos de prueba: {list(query_sets.keys())}")
        return query_sets

    async def run_latency_test(self, rag_system: Any, queries: List[str],
                             system_name: str) -> Dict[str, Any]:
        """Ejecutar prueba de latencia."""
        logger.info(f"Ejecutando prueba de latencia para {system_name}...")

        latencies = []
        resources_start = self.get_system_resources()

        start_time = time.time()
        for query in queries:
            query_start = time.time()
            try:
                result = rag_system.run(query)
                latency = time.time() - query_start
                latencies.append(latency)
            except Exception as e:
                logger.warning(f"Error en query: {e}")
                latencies.append(0.0)

        total_time = time.time() - start_time
        resources_end = self.get_system_resources()

        return {
            'system': system_name,
            'total_queries': len(queries),
            'total_time': total_time,
            'avg_latency': sum(latencies) / len(latencies) if latencies else 0,
            'throughput_qps': len(latencies) / total_time if total_time > 0 else 0,
            'resources_start': resources_start,
            'resources_end': resources_end,
            'latencies': latencies
        }

    async def run_hit_rate_test(self, rag_system: CacheAugmentedRAG,
                              queries: List[str]) -> Dict[str, Any]:
        """Ejecutar prueba de cache hit rate."""
        logger.info("Ejecutando prueba de cache hit rate...")

        hits = 0
        misses = 0
        hit_latencies = []
        miss_latencies = []

        for query in queries:
            query_start = time.time()
            try:
                result = rag_system.run(query)
                latency = time.time() - query_start

                cache_hit = result['metadata'].get('cache_hit', False)
                if cache_hit:
                    hits += 1
                    hit_latencies.append(latency)
                else:
                    misses += 1
                    miss_latencies.append(latency)

            except Exception as e:
                logger.warning(f"Error en query: {e}")
                misses += 1

        total_queries = hits + misses
        hit_rate = hits / total_queries if total_queries > 0 else 0

        return {
            'total_queries': total_queries,
            'cache_hits': hits,
            'cache_misses': misses,
            'hit_rate': hit_rate,
            'avg_hit_latency': sum(hit_latencies) / len(hit_latencies) if hit_latencies else 0,
            'avg_miss_latency': sum(miss_latencies) / len(miss_latencies) if miss_latencies else 0
        }

    async def run_quality_test(self, rag_system: Any, queries: List[str],
                             system_name: str) -> Dict[str, Any]:
        """Ejecutar prueba de calidad de respuestas."""
        logger.info(f"Ejecutando prueba de calidad para {system_name}...")

        quality_scores = []
        response_lengths = []

        for query in queries:
            try:
                result = rag_system.run(query)
                response = result.get('response', '')

                # Calcular métricas de calidad simples
                length_score = min(len(response.split()) / 100, 1.0)  # Normalizar longitud
                coherence_score = 1.0 if len(response.split('.')) > 2 else 0.5  # Múltiples oraciones
                completeness_score = 1.0 if '?' not in response[-50:] else 0.7  # No termina con pregunta

                overall_quality = (length_score + coherence_score + completeness_score) / 3
                quality_scores.append(overall_quality)
                response_lengths.append(len(response))

            except Exception as e:
                logger.warning(f"Error en query: {e}")
                quality_scores.append(0.0)
                response_lengths.append(0)

        return {
            'system': system_name,
            'avg_quality_score': sum(quality_scores) / len(quality_scores) if quality_scores else 0,
            'avg_response_length': sum(response_lengths) / len(response_lengths) if response_lengths else 0,
            'quality_scores': quality_scores
        }

    async def run_comparison_test(self, test_type: str, queries: List[str]) -> Dict[str, Any]:
        """Ejecutar una comparación específica."""
        logger.info(f"Ejecutando comparación: {test_type}")

        rag_with_cag, rag_without_cag = self.setup_rag_systems()

        if test_type == 'latency':
            with_cag_results = await self.run_latency_test(rag_with_cag, queries, "RAG+CAG")
            without_cag_results = await self.run_latency_test(rag_without_cag, queries, "RAG")
            return {
                'test_type': 'latency',
                'with_cag': with_cag_results,
                'without_cag': without_cag_results
            }

        elif test_type == 'hit_rate':
            hit_rate_results = await self.run_hit_rate_test(rag_with_cag, queries)
            return {
                'test_type': 'hit_rate',
                'results': hit_rate_results
            }

        elif test_type == 'quality':
            with_cag_quality = await self.run_quality_test(rag_with_cag, queries, "RAG+CAG")
            without_cag_quality = await self.run_quality_test(rag_without_cag, queries, "RAG")
            return {
                'test_type': 'quality',
                'with_cag': with_cag_quality,
                'without_cag': without_cag_quality
            }

        else:
            raise ValueError(f"Tipo de test desconocido: {test_type}")

    async def run_experiment(self) -> Dict[str, Any]:
        """Ejecutar experimento completo."""
        logger.info("Iniciando experimento de comparación de rendimiento RAG...")

        test_types = self.config.get('test_types', ['latency'])
        query_sets = self.generate_test_queries()

        # Ejecutar cada tipo de test
        for test_type in test_types:
            logger.info(f"=== EJECUTANDO TEST: {test_type.upper()} ===")

            # Usar queries apropiadas para cada test
            if test_type == 'hit_rate':
                queries = query_sets.get('repeated', query_sets['simple'])
            elif test_type == 'quality':
                queries = query_sets.get('complex', query_sets['simple'])
            else:
                queries = query_sets.get('simple', [])

            # Limitar número de queries
            queries = queries[:self.config.get('num_queries', 50)]

            try:
                results = await self.run_comparison_test(test_type, queries)
                self.results['test_results'][test_type] = results
            except Exception as e:
                logger.error(f"Error en test {test_type}: {e}")
                self.results['test_results'][test_type] = {'error': str(e)}

        # Generar resumen
        self.generate_summary()

        logger.info("Experimento completado")
        return self.results

    def generate_summary(self):
        """Generar resumen ejecutivo de los resultados."""
        summary = {
            'total_tests_run': len(self.results['test_results']),
            'key_findings': [],
            'recommendations': []
        }

        # Analizar resultados de latencia
        if 'latency' in self.results['test_results']:
            latency_data = self.results['test_results']['latency']
            with_cag = latency_data['with_cag']
            without_cag = latency_data['without_cag']

            latency_improvement = (
                (without_cag['avg_latency'] - with_cag['avg_latency']) /
                without_cag['avg_latency'] * 100
                if without_cag['avg_latency'] > 0 else 0
            )

            throughput_improvement = (
                (with_cag['throughput_qps'] - without_cag['throughput_qps']) /
                without_cag['throughput_qps'] * 100
                if without_cag['throughput_qps'] > 0 else 0
            )

            summary['key_findings'].extend([
                f"Mejora de latencia: {latency_improvement:.1f}%",
                f"Mejora de throughput: {throughput_improvement:.1f}%"
            ])

        # Analizar resultados de hit rate
        if 'hit_rate' in self.results['test_results']:
            hit_rate_data = self.results['test_results']['hit_rate']['results']
            hit_rate = hit_rate_data['hit_rate'] * 100
            summary['key_findings'].append(f"Tasa de aciertos del cache: {hit_rate:.1f}%")

        # Analizar resultados de calidad
        if 'quality' in self.results['test_results']:
            quality_data = self.results['test_results']['quality']
            cag_quality = quality_data['with_cag']['avg_quality_score']
            rag_quality = quality_data['without_cag']['avg_quality_score']

            quality_diff = ((cag_quality - rag_quality) / rag_quality * 100) if rag_quality > 0 else 0
            summary['key_findings'].append(f"Diferencia de calidad: {quality_diff:.1f}%")

        # Generar recomendaciones
        if 'latency' in self.results['test_results']:
            latency_data = self.results['test_results']['latency']
            if latency_data['with_cag']['avg_latency'] < latency_data['without_cag']['avg_latency']:
                summary['recommendations'].append(
                    "Se recomienda usar Cache Augmented Generation para mejorar rendimiento"
                )

        if 'hit_rate' in self.results['test_results']:
            hit_rate = self.results['test_results']['hit_rate']['results']['hit_rate']
            if hit_rate > 0.5:
                summary['recommendations'].append(
                    "La tasa de aciertos del cache es buena (>50%), considere aumentar el tamaño del cache"
                )
            else:
                summary['recommendations'].append(
                    "La tasa de aciertos del cache es baja, considere ajustar el umbral de similitud"
                )

        self.results['summary'] = summary

    def save_results(self, output_file: str):
        """Guardar resultados en archivo JSON."""
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        logger.info(f"Resultados guardados en {output_path}")

    def print_summary(self):
        """Imprimir resumen de resultados."""
        summary = self.results.get('summary', {})

        print("\n" + "="*80)
        print("RESUMEN EJECUTIVO - COMPARACIÓN RAG vs RAG+CAG")
        print("="*80)

        print(f"\nTests ejecutados: {summary.get('total_tests_run', 0)}")

        print("\nHALLAZGOS PRINCIPALES:")
        for finding in summary.get('key_findings', []):
            print(f"  • {finding}")

        print("\nRECOMENDACIONES:")
        for rec in summary.get('recommendations', []):
            print(f"  • {rec}")

        print("\nDETALLES POR TEST:")
        for test_type, test_results in self.results.get('test_results', {}).items():
            print(f"\n{test_type.upper()}:")
            if 'error' in test_results:
                print(f"  ❌ Error: {test_results['error']}")
            else:
                # Mostrar métricas clave según el tipo de test
                if test_type == 'latency':
                    for system_key in ['with_cag', 'without_cag']:
                        if system_key in test_results:
                            data = test_results[system_key]
                            system_name = data.get('system', system_key)
                            print(f"  {system_name}:")
                            print(".2f")
                            print(".3f")
                elif test_type == 'hit_rate':
                    data = test_results.get('results', {})
                    print(".1f")
                    print(".3f")
                    print(".3f")
                elif test_type == 'quality':
                    for system_key in ['with_cag', 'without_cag']:
                        if system_key in test_results:
                            data = test_results[system_key]
                            system_name = data.get('system', system_key)
                            print(f"  {system_name}:")
                            print(".3f")
                            print(".0f")

        print("="*80)


async def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Comparar rendimiento RAG vs RAG+CAG')
    parser.add_argument('--test_types', type=str, default='latency,hit_rate',
                       help='Tipos de tests a ejecutar (separados por coma)')
    parser.add_argument('--num_queries', type=int, default=30,
                       help='Número de consultas por test')
    parser.add_argument('--similarity_threshold', type=float, default=0.8,
                       help='Umbral de similitud para cache hits')
    parser.add_argument('--cache_max_size', type=int, default=1000,
                       help='Tamaño máximo del cache')
    parser.add_argument('--model_path', type=str, default='./models/empoorio_lm/v1.0.0',
                       help='Ruta al modelo EmpoorioLM')
    parser.add_argument('--output_file', type=str, default='benchmark_results/rag_performance_comparison.json',
                       help='Archivo de salida para resultados')
    parser.add_argument('--eviction_policy', type=str, default='LRU', choices=['LRU', 'LFU'],
                       help='Política de eviction del cache')

    args = parser.parse_args()

    # Configuración del experimento
    config = {
        'test_types': args.test_types.split(','),
        'num_queries': args.num_queries,
        'similarity_threshold': args.similarity_threshold,
        'cache_max_size': args.cache_max_size,
        'model_path': args.model_path,
        'eviction_policy': args.eviction_policy
    }

    # Crear comparador
    comparator = RAGPerformanceComparator(config)

    try:
        # Ejecutar experimento
        results = await comparator.run_experiment()

        # Guardar resultados
        comparator.save_results(args.output_file)

        # Imprimir resumen
        comparator.print_summary()

        logger.info(f"Comparación completada. Resultados guardados en {args.output_file}")

    except Exception as e:
        logger.error(f"Error en la comparación: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())