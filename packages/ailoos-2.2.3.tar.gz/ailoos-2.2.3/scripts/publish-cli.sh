#!/bin/bash

# Publish AILOOS CLI to npm registry
# Run this after testing locally with test-cli-local.sh

echo "🚀 Publishing AILOOS CLI to npm..."
echo ""

# Check if user is logged in to npm
if ! npm whoami &> /dev/null; then
    echo "❌ Not logged in to npm. Please run:"
    echo "   npm login"
    exit 1
fi

echo "✅ Logged in as: $(npm whoami)"
echo ""

# Go to CLI directory
cd ailoos-cli

# Create package
echo "📦 Creating package..."
npm pack

# Publish to npm
echo "📤 Publishing to npm registry..."
npm publish

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Successfully published ailoos-cli to npm!"
    echo ""
    echo "📦 Package: https://www.npmjs.com/package/ailoos-cli"
    echo ""
    echo "🚀 Now users can install with:"
    echo "   npm install -g ailoos-cli"
    echo "   pnpm add -g ailoos-cli"
    echo "   npx ailoos-cli"
    echo ""
    echo "📚 Verify installation:"
    echo "   npx ailoos-cli --help"
else
    echo ""
    echo "❌ Failed to publish. Check the error messages above."
    echo ""
    echo "💡 Common issues:"
    echo "   - Package name already taken: Change name in package.json"
    echo "   - Version already exists: Increment version in package.json"
    echo "   - Permission denied: Check npm login"
    exit 1
fi