#!/usr/bin/env python3
"""
Demo del Sistema de Expertos Pluggables
=======================================

Esta demo muestra cómo funciona el sistema de expertos desacoplables de EmpoorioLM,
permitiendo cargar especialistas por dominio de forma modular.

Características demostradas:
- Carga selectiva de expertos
- Routing inteligente por dominio
- Inferencia con expertos especializados
"""

import sys
from pathlib import Path

# Añadir el directorio raíz al path
script_dir = Path(__file__).parent
root_dir = script_dir.parent
sys.path.insert(0, str(root_dir))

from src.ailoos.models.empoorio_lm.expert_system import (
    ExpertManager, PluggableEmpoorioLM, Domain, create_expert_manager,
    create_pluggable_empoorio_lm, setup_default_routing
)
from src.ailoos.models.empoorio_lm import EmpoorioLMConfig


def create_mock_expert(expert_manager: ExpertManager, domain: Domain, expert_name: str):
    """Crear un experto mock para demo (en producción vendría de entrenamiento)."""
    from src.ailoos.models.empoorio_lm.expert_system import ExpertConfig

    # Configuración del experto
    config = ExpertConfig(
        domain=domain,
        name=expert_name,
        description=f"Experto mock para {domain.value}",
        target_layers=[4, 7],  # Capas MoE típicas
        expert_indices=[6, 7],  # Expertos específicos
        dataset_info={"type": "mock", "samples": 100},
        version="1.0.0"
    )

    # Crear pesos mock (en producción vendrían del entrenamiento)
    expert_weights = {}
    hidden_size = 768  # Debe coincidir con la config del modelo

    # Crear pesos para cada experto
    for expert_idx in config.expert_indices:
        expert_weights[f"expert_{expert_idx}"] = {
            "0.weight": torch.randn(4 * hidden_size, hidden_size),
            "0.bias": torch.randn(4 * hidden_size),
            "2.weight": torch.randn(hidden_size, 4 * hidden_size),
            "2.bias": torch.randn(hidden_size)
        }

    # Guardar experto
    expert_manager.save_expert(config, expert_weights, domain, expert_name)
    print(f"✅ Experto mock creado: {domain.value}/{expert_name}")


def demo_expert_loading():
    """Demo de carga y gestión de expertos."""
    print("🔧 Demo: Sistema de Expertos Pluggables")
    print("=" * 50)

    # Crear gestor de expertos
    expert_manager = create_expert_manager("models/experts")

    # Configurar routing por defecto
    setup_default_routing(expert_manager)

    # Crear expertos mock para diferentes dominios
    create_mock_expert(expert_manager, Domain.LEGAL, "legal_expert_v1")
    create_mock_expert(expert_manager, Domain.MEDICAL, "medical_expert_v1")
    create_mock_expert(expert_manager, Domain.CODING, "coding_expert_v1")

    # Mostrar estadísticas
    stats = expert_manager.get_expert_statistics()
    print("\n📊 Estadísticas del Sistema de Expertos:")
    print(f"   Total de expertos: {stats['total_experts']}")
    print(f"   Dominios activos: {stats['active_domains']}")

    for domain, domain_stats in stats['experts_by_domain'].items():
        print(f"   {domain}: {domain_stats['count']} expertos")

    return expert_manager


def demo_pluggable_model(expert_manager: ExpertManager):
    """Demo del modelo pluggable con expertos."""
    print("\n🤖 Demo: Modelo Pluggable con Expertos")
    print("=" * 50)

    # Crear configuración del modelo
    config = EmpoorioLMConfig(
        vocab_size=30000,
        hidden_size=768,
        num_layers=12,
        num_heads=12,
        use_moe=True,
        num_experts=8,
        moe_layers=[4, 7, 10]
    )

    # Crear modelo pluggable
    model = create_pluggable_empoorio_lm(config, expert_manager)
    print("✅ Modelo PluggableEmpoorioLM creado")

    # Cargar expertos para un dominio
    domain = Domain.LEGAL
    loaded_count = model.load_domain_experts(domain)
    print(f"✅ Cargados {loaded_count} expertos para dominio {domain.value}")

    # Mostrar estado de expertos
    status = model.get_expert_status()
    print("\n📊 Estado del Modelo:")
    print(f"   Expertos conectados: {status['plugged_experts_count']}")
    print(f"   Capas con expertos: {status['plugged_layers']}")

    return model


def demo_domain_routing(expert_manager: ExpertManager, model: PluggableEmpoorioLM):
    """Demo de routing inteligente por dominio."""
    print("\n🎯 Demo: Routing Inteligente por Dominio")
    print("=" * 50)

    test_prompts = [
        ("¿Cómo se estructura un contrato de compraventa?", Domain.LEGAL),
        ("¿Cuáles son los síntomas del COVID-19?", Domain.MEDICAL),
        ("¿Cómo implementar un algoritmo de ordenamiento?", Domain.CODING),
        ("¿Cuál es la capital de Francia?", Domain.GENERAL)
    ]

    for prompt, expected_domain in test_prompts:
        # Detectar dominio automáticamente
        detected_domain = expert_manager.detect_domain_from_prompt(prompt)

        print(f"\n📝 Prompt: '{prompt}'")
        print(f"   Dominio esperado: {expected_domain.value}")
        print(f"   Dominio detectado: {detected_domain.value if detected_domain else 'None'}")

        # Simular tokens (en producción usar tokenizer real)
        mock_tokens = torch.tensor([[1, 2, 3, 4, 5]], dtype=torch.long)  # Mock input

        # Aplicar routing si se detecta dominio
        if detected_domain:
            routed_tokens = model.apply_domain_routing(detected_domain, mock_tokens)
            print("   ✅ Routing aplicado")
        else:
            print("   ⚪ Sin routing específico (dominio general)")


def demo_inference_with_experts(model: PluggableEmpoorioLM):
    """Demo de inferencia con expertos cargados."""
    print("\n🧠 Demo: Inferencia con Expertos Especializados")
    print("=" * 50)

    # Tokens mock para inferencia
    mock_input = torch.tensor([[1, 2, 3, 4, 5, 6, 7, 8]], dtype=torch.long)

    domains_to_test = [Domain.LEGAL, Domain.MEDICAL, Domain.CODING, None]

    for domain in domains_to_test:
        print(f"\n🔍 Probando dominio: {domain.value if domain else 'GENERAL'}")

        # Forward pass con dominio específico
        with torch.no_grad():
            outputs = model(mock_input, domain=domain)

        logits = outputs["logits"]
        print(f"   📊 Shape de logits: {logits.shape}")
        print(f"   🎯 Valor máximo: {logits.max().item():.4f}")
        print(f"   📈 Tokens generados: {logits.argmax(dim=-1)[0].tolist()[:5]}")


def main():
    """Función principal de la demo."""
    print("🚀 Demo del Sistema de Expertos Pluggables de EmpoorioLM")
    print("Este demo muestra cómo los expertos se cargan y usan de forma modular.")
    print()

    try:
        # Demo 1: Sistema de gestión de expertos
        expert_manager = demo_expert_loading()

        # Demo 2: Modelo pluggable
        model = demo_pluggable_model(expert_manager)

        # Demo 3: Routing por dominio
        demo_domain_routing(expert_manager, model)

        # Demo 4: Inferencia con expertos
        demo_inference_with_experts(model)

        print("\n🎉 ¡Demo completada exitosamente!")
        print("\n💡 Resumen de lo demostrado:")
        print("   ✅ Carga modular de expertos por dominio")
        print("   ✅ Routing inteligente basado en contenido")
        print("   ✅ Modelo pluggable sin recargar todo")
        print("   ✅ Inferencia especializada por dominio")
        print("\n🏆 El 'Enjambre de Especialistas' está listo para conquistar el mundo!")

    except Exception as e:
        print(f"\n❌ Error en demo: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Import torch aquí para evitar problemas de importación
    try:
        import torch
        main()
    except ImportError:
        print("❌ PyTorch no disponible. Instalar con: pip install torch")