#!/bin/bash
# Script to prune old Docker images from Google Cloud Artifact Registry
# Usage: ./prune_old_images.sh <project_id> <location> <repository> [days_old]

set -e

if [ $# -lt 3 ]; then
    echo "Usage: $0 <project_id> <location> <repository> [days_old]"
    echo "Example: $0 my-project us-central1 my-repo 30"
    exit 1
fi

PROJECT_ID=$1
LOCATION=$2
REPOSITORY=$3
DAYS_OLD=${4:-30}

echo "Pruning images older than $DAYS_OLD days from repository: $REPOSITORY in project: $PROJECT_ID location: $LOCATION"

# Calculate cutoff date
CUTOFF_DATE=$(date -d "$DAYS_OLD days ago" +%Y-%m-%dT%H:%M:%SZ)

echo "Cutoff date: $CUTOFF_DATE"

# List images and their create times
IMAGES=$(gcloud artifacts docker images list --repository="$REPOSITORY" --location="$LOCATION" --project="$PROJECT_ID" --format="value(name,createTime)")

DELETED_COUNT=0

echo "$IMAGES" | while IFS= read -r line; do
    if [ -z "$line" ]; then
        continue
    fi

    IMAGE_URI=$(echo "$line" | awk '{print $1}')
    CREATE_TIME=$(echo "$line" | awk '{print $2}')

    if [ "$CREATE_TIME" \< "$CUTOFF_DATE" ]; then
        echo "Deleting old image: $IMAGE_URI (created: $CREATE_TIME)"
        gcloud artifacts docker images delete "$IMAGE_URI" --quiet --project="$PROJECT_ID" --location="$LOCATION"
        ((DELETED_COUNT++))
    fi
done

echo "Pruning completed. Deleted $DELETED_COUNT images older than $DAYS_OLD days."