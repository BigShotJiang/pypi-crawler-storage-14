"""
Script de validación exhaustiva para la implementación completa de FASE 4.
Valida estructura de archivos, sintaxis de código y componentes clave sin ejecutar modelos.
"""

import os
import sys
import ast
import json
import importlib.util
from pathlib import Path
from typing import Dict, List, Any, Tuple
import subprocess


class FASE4Validator:
    """
    Validador exhaustivo para FASE 4.
    """

    def __init__(self, base_path: str = "."):
        self.base_path = Path(base_path)
        self.results = {
            'file_structure': {},
            'syntax_validation': {},
            'component_validation': {},
            'integration_checks': {},
            'summary': {}
        }

    def validate_file_structure(self) -> Dict[str, Any]:
        """Validar estructura de archivos requerida para FASE 4."""
        print("📁 Validando estructura de archivos FASE 4...")

        required_files = {
            'API de inferencia': [
                'src/ailoos/inference/api.py',
                'src/ailoos/inference/__init__.py'
            ],
            'Modelos': [
                'src/ailoos/models/__init__.py'
            ],
            'Coordinador': [
                'src/ailoos/coordinator/__init__.py',
                'src/ailoos/coordinator/services/__init__.py'
            ],
            'Sistema federado': [
                'src/ailoos/federated/__init__.py',
                'src/ailoos/federated/federated_data_loader.py',
                'src/ailoos/federated/secure_data_preprocessor.py',
                'src/ailoos/federated/privacy_preserving_aggregator.py'
            ],
            'Schemas': [
                'src/ailoos/schemas/__init__.py'
            ],
            'Tests': [
                'tests/test_inference_maturity2.py',
                'tests/test_federated_convergence_integration.py'
            ],
            'Scripts de prueba': [
                'run_inference_performance_test.py',
                'run_security_compliance_test.py'
            ]
        }

        structure_results = {}

        for category, files in required_files.items():
            category_results = {}
            for file_path in files:
                full_path = self.base_path / file_path
                exists = full_path.exists()
                category_results[file_path] = {
                    'exists': exists,
                    'size': full_path.stat().st_size if exists else 0
                }

            all_exist = all(r['exists'] for r in category_results.values())
            structure_results[category] = {
                'files': category_results,
                'complete': all_exist
            }

        self.results['file_structure'] = structure_results
        return structure_results

    def validate_syntax(self) -> Dict[str, Any]:
        """Validar sintaxis de archivos Python críticos."""
        print("🔍 Validando sintaxis de archivos Python...")

        critical_files = [
            'src/ailoos/inference/api.py',
            'src/ailoos/federated/federated_data_loader.py',
            'src/ailoos/federated/secure_data_preprocessor.py',
            'src/ailoos/federated/privacy_preserving_aggregator.py',
            'run_inference_performance_test.py',
            'run_security_compliance_test.py'
        ]

        syntax_results = {}

        for file_path in critical_files:
            full_path = self.base_path / file_path
            result = {'valid': False, 'errors': []}

            if full_path.exists():
                try:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        source = f.read()

                    # Parsear sintaxis
                    ast.parse(source, filename=str(full_path))
                    result['valid'] = True

                except SyntaxError as e:
                    result['errors'].append(f"SyntaxError: {e}")
                except Exception as e:
                    result['errors'].append(f"Error: {e}")

            syntax_results[file_path] = result

        self.results['syntax_validation'] = syntax_results
        return syntax_results

    def validate_components(self) -> Dict[str, Any]:
        """Validar componentes clave de FASE 4."""
        print("🔧 Validando componentes clave...")

        components = {
            'inference_api': {
                'file': 'src/ailoos/inference/api.py',
                'required_classes': ['EmpoorioLMInferenceAPI', 'InferenceConfig'],
                'required_functions': ['generate', 'generate_stream']
            },
            'federated_system': {
                'file': 'src/ailoos/federated/federated_data_loader.py',
                'required_classes': ['FederatedDataLoader'],
                'required_functions': ['load_data', 'preprocess_data']
            }
        }

        component_results = {}

        for comp_name, comp_config in components.items():
            file_path = self.base_path / comp_config['file']
            result = {
                'file_exists': file_path.exists(),
                'classes_found': [],
                'functions_found': [],
                'complete': False
            }

            if file_path.exists():
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        source = f.read()

                    tree = ast.parse(source)

                    # Buscar clases
                    for node in ast.walk(tree):
                        if isinstance(node, ast.ClassDef):
                            result['classes_found'].append(node.name)
                        elif isinstance(node, ast.FunctionDef):
                            result['functions_found'].append(node.name)

                    # Verificar requisitos
                    required_classes = set(comp_config.get('required_classes', []))
                    required_functions = set(comp_config.get('required_functions', []))

                    classes_ok = required_classes.issubset(set(result['classes_found']))
                    functions_ok = required_functions.issubset(set(result['functions_found']))

                    result['complete'] = classes_ok and functions_ok

                except Exception as e:
                    result['error'] = str(e)

            component_results[comp_name] = result

        self.results['component_validation'] = component_results
        return component_results

    def validate_integration(self) -> Dict[str, Any]:
        """Validar integraciones entre componentes."""
        print("🔗 Validando integraciones...")

        integration_checks = {
            'federated_inference_coordinator': {
                'description': 'Verificar integración entre sistema federado y coordinador de inferencia',
                'check_type': 'import_check',
                'target_file': 'src/ailoos/inference/api.py',
                'imports': ['InferenceCoordinator']
            },
            'performance_test_structure': {
                'description': 'Verificar estructura del script de pruebas de rendimiento',
                'check_type': 'file_content',
                'target_file': 'run_inference_performance_test.py',
                'contains': ['InferencePerformanceTestSuite', 'test_latency_percentiles']
            }
        }

        integration_results = {}

        for check_name, check_config in integration_checks.items():
            result = {'passed': False, 'details': ''}

            if check_config['check_type'] == 'import_check':
                file_path = self.base_path / check_config['target_file']
                if file_path.exists():
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read()

                        # Verificar imports
                        imports_found = []
                        for import_name in check_config['imports']:
                            if import_name in content:
                                imports_found.append(import_name)

                        result['passed'] = len(imports_found) == len(check_config['imports'])
                        result['details'] = f"Imports found: {imports_found}"

                    except Exception as e:
                        result['details'] = f"Error: {e}"

            elif check_config['check_type'] == 'file_content':
                file_path = self.base_path / check_config['target_file']
                if file_path.exists():
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read()

                        contains_all = all(keyword in content for keyword in check_config['contains'])
                        result['passed'] = contains_all
                        result['details'] = f"Contains required keywords: {contains_all}"

                    except Exception as e:
                        result['details'] = f"Error: {e}"

            integration_results[check_name] = result

        self.results['integration_checks'] = integration_results
        return integration_results

    def run_test_execution_checks(self) -> Dict[str, Any]:
        """Verificar que las pruebas pueden ejecutarse (al menos sintácticamente)."""
        print("🧪 Verificando ejecución de pruebas...")

        test_scripts = [
            'run_security_compliance_test.py',
            'tests/test_federated_convergence_integration.py'
        ]

        execution_results = {}

        for script in test_scripts:
            script_path = self.base_path / script
            result = {
                'can_import': False,
                'syntax_ok': False,
                'details': ''
            }

            if script_path.exists():
                try:
                    # Verificar sintaxis con python -m py_compile
                    result_py = subprocess.run(
                        [sys.executable, '-m', 'py_compile', str(script_path)],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )

                    result['syntax_ok'] = result_py.returncode == 0
                    if result_py.returncode != 0:
                        result['details'] = result_py.stderr

                except subprocess.TimeoutExpired:
                    result['details'] = 'Timeout during syntax check'
                except Exception as e:
                    result['details'] = f"Error: {e}"

            execution_results[script] = result

        return execution_results

    def generate_summary(self) -> Dict[str, Any]:
        """Generar resumen completo de validación."""
        print("📊 Generando resumen de validación...")

        # Calcular estadísticas
        file_structure_ok = all(cat['complete'] for cat in self.results['file_structure'].values())
        syntax_ok = all(res['valid'] for res in self.results['syntax_validation'].values())
        components_ok = all(comp['complete'] for comp in self.results['component_validation'].values())
        integrations_ok = all(check['passed'] for check in self.results['integration_checks'].values())

        # Calcular puntuación general
        checks = [file_structure_ok, syntax_ok, components_ok, integrations_ok]
        overall_score = sum(checks) / len(checks)

        summary = {
            'overall_status': 'PASSED' if overall_score >= 0.8 else 'FAILED',
            'overall_score': overall_score,
            'file_structure_ok': file_structure_ok,
            'syntax_ok': syntax_ok,
            'components_ok': components_ok,
            'integrations_ok': integrations_ok,
            'validation_timestamp': str(Path.cwd()),
            'critical_issues': []
        }

        # Identificar problemas críticos
        if not file_structure_ok:
            summary['critical_issues'].append('Missing required files')

        if not syntax_ok:
            summary['critical_issues'].append('Syntax errors in critical files')

        if not components_ok:
            summary['critical_issues'].append('Missing required components')

        self.results['summary'] = summary
        return summary

    def run_complete_validation(self) -> Dict[str, Any]:
        """Ejecutar validación completa de FASE 4."""
        print("🚀 Iniciando validación completa de FASE 4...")

        # Ejecutar todas las validaciones
        self.validate_file_structure()
        self.validate_syntax()
        self.validate_components()
        self.validate_integration()
        execution_checks = self.run_test_execution_checks()
        self.results['execution_checks'] = execution_checks
        self.generate_summary()

        return self.results

    def print_report(self):
        """Imprimir reporte detallado."""
        print("\n" + "="*80)
        print("📋 REPORTE DE VALIDACIÓN FASE 4")
        print("="*80)

        summary = self.results.get('summary', {})

        status_emoji = "✅" if summary.get('overall_status') == 'PASSED' else "❌"
        print(f"Estado general: {status_emoji} {summary.get('overall_status', 'UNKNOWN')}")
        print(f"Puntuación general: {summary.get('overall_score', 0):.1f}")

        files_emoji = "✅" if summary.get('file_structure_ok') else "❌"
        print(f"Archivos: {files_emoji} {'OK' if summary.get('file_structure_ok') else 'FAIL'}")

        syntax_emoji = "✅" if summary.get('syntax_ok') else "❌"
        print(f"Sintaxis: {syntax_emoji} {'OK' if summary.get('syntax_ok') else 'FAIL'}")

        comp_emoji = "✅" if summary.get('components_ok') else "❌"
        print(f"Componentes: {comp_emoji} {'OK' if summary.get('components_ok') else 'FAIL'}")

        int_emoji = "✅" if summary.get('integrations_ok') else "❌"
        print(f"Integraciones: {int_emoji} {'OK' if summary.get('integrations_ok') else 'FAIL'}")

        if summary.get('critical_issues'):
            print("\n🚨 PROBLEMAS CRÍTICOS:")
            for issue in summary['critical_issues']:
                print(f"   • {issue}")

        print("\n" + "="*80)


def main():
    """Función principal."""
    validator = FASE4Validator()

    try:
        results = validator.run_complete_validation()
        validator.print_report()

        # Guardar resultados
        with open('fase4_validation_results.json', 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False, default=str)

        # Determinar código de salida
        summary = results.get('summary', {})
        if summary.get('overall_status') == 'PASSED':
            print("🎉 Validación de FASE 4 completada exitosamente!")
            sys.exit(0)
        else:
            print("⚠️  Validación de FASE 4 completada con problemas.")
            sys.exit(1)

    except Exception as e:
        print(f"❌ Error durante validación: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()