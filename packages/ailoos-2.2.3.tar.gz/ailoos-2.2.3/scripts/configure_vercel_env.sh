e#!/bin/bash

# Script para configurar automáticamente las variables de entorno en Vercel
# para AILOOS

set -e

echo "🔧 Configurando variables de entorno en Vercel para AILOOS..."

# Cambiar al directorio frontend
cd frontend

# Función para agregar variable de entorno
add_env_var() {
    local var_name=$1
    local var_value=$2
    local target=${3:-"production"}

    echo "Configurando $var_name para $target..."

    # Crear archivo temporal con el valor
    local temp_file=$(mktemp)
    echo -n "$var_value" > "$temp_file"

    # Agregar variable de entorno
    vercel env add "$var_name" "$target" < "$temp_file"

    # Limpiar archivo temporal
    rm "$temp_file"
}

# 1. AUTH_SECRET (generado anteriormente)
echo "📝 Configurando AUTH_SECRET..."
add_env_var "AUTH_SECRET" "9Jn4U/S3Wtpj4EhETZ7YQ+UGh91n40dpETCuzB9RMyQ=" "secret"

# 2. DATABASE_URL (placeholder - necesita configuración real)
echo "🗄️  Configurando DATABASE_URL..."
# Para desarrollo, usar una base de datos temporal
# En producción, esto debe ser reemplazado con la URL real de Cloud SQL
add_env_var "DATABASE_URL" "postgresql://user:password@localhost:5432/ailoos_dev"

# 3. BLOB_READ_WRITE_TOKEN (placeholder)
echo "📦 Configurando BLOB_READ_WRITE_TOKEN..."
# Esto necesita ser configurado desde Vercel Dashboard > Storage > Blob
echo "⚠️  BLOB_READ_WRITE_TOKEN debe configurarse manualmente desde Vercel Dashboard > Storage > Blob"
echo "   Crea un store y genera un token con permisos read/write"

# 4. AI_GATEWAY_API_KEY (placeholder)
echo "🤖 Configurando AI_GATEWAY_API_KEY..."
# Para desarrollo, usar un placeholder
# En producción, configurar la API key real
add_env_var "AI_GATEWAY_API_KEY" "placeholder-api-key-replace-with-real-key" "secret"

# 5. Variables opcionales pero útiles
echo "🌍 Configurando variables opcionales..."

add_env_var "ENVIRONMENT" "production"
add_env_var "DOMAIN" "ailoos.com"
add_env_var "GCP_PROJECT_ID" "ailoos-oauth-473213"

# Variables de GCP (placeholders)
add_env_var "REDIS_URL" "redis://localhost:6379"
add_env_var "STORAGE_BUCKET" "gs://ailoos-dev-bucket"

echo ""
echo "✅ Variables básicas configuradas en Vercel"
echo ""
echo "⚠️  IMPORTANTE: Las siguientes variables necesitan configuración manual:"
echo "   - DATABASE_URL: Configurar con URL real de Cloud SQL"
echo "   - BLOB_READ_WRITE_TOKEN: Obtener desde Vercel Dashboard > Storage > Blob"
echo "   - AI_GATEWAY_API_KEY: Configurar con API key real (OpenAI, Anthropic, etc.)"
echo "   - GCP_SA_KEY: Configurar con JSON de service account"
echo ""
echo "📋 Para configurar manualmente:"
echo "   vercel env add VARIABLE_NAME"
echo ""
echo "🔍 Verificar configuración:"
echo "   ../scripts/verify_vercel_env.sh"