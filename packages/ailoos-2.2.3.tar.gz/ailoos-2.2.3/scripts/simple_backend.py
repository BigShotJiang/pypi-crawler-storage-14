#!/usr/bin/env python3
"""
Simple backend server for AILOOS frontend testing.
Provides basic endpoints without complex dependencies.
"""

import asyncio
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="AILOOS Simple Backend",
    description="Simple backend for frontend testing",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check
@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "simple-backend"}

# Root endpoint
@app.get("/")
async def root():
    return {"message": "AILOOS Simple Backend", "status": "running"}

# Federated endpoints
@app.get("/api/federated/stats")
async def get_federated_stats():
    """Get federated learning statistics."""
    return {
        "total_nodes": 42,
        "active_nodes": 28,
        "total_sessions": 25,
        "active_sessions": 5,
        "total_rounds_completed": 150,
        "active_rounds": 3,
        "total_dracma_distributed": 12500.50,
        "network_accuracy": 87.5,
        "network_health": "good",
        "last_updated": "2024-01-15T10:30:00Z"
    }

@app.get("/api/federated/nodes/")
async def get_federated_nodes():
    """Get federated nodes."""
    return {
        "node_status": {
            "node_id": "macbook_m4_a1b2c3d4",
            "hardware_type": "Apple M4",
            "status": "active",
            "is_registered": True,
            "training_stats": {
                "rounds_completed": 15,
                "total_samples_processed": 50000,
                "total_training_time": 3600,
                "best_accuracy": 0.92,
                "dracma_earned": 125.50
            },
            "hardware_info": {
                "system": "Darwin",
                "machine": "arm64",
                "cpu_count": 10,
                "memory_gb": 16,
                "gpu_available": True,
                "gpu_count": 1
            },
            "coordinator_url": "http://localhost:8000"
        }
    }

# IPFS endpoints
@app.get("/api/v1/ipfs/status")
async def get_ipfs_status():
    """Get IPFS status."""
    return {
        "connected": False,
        "endpoint": "http://localhost:5001",
        "gateway": "http://localhost:8080",
        "version": None,
        "peers": 0,
        "error": "IPFS daemon no está ejecutándose",
        "daemon_running": False,
        "auto_setup_available": True
    }

@app.post("/api/v1/ipfs/install")
async def install_ipfs():
    """Install IPFS."""
    return {
        "success": False,
        "message": "Instalación de IPFS no disponible en backend simple",
        "daemon_started": False
    }

@app.get("/api/v1/ipfs/install/progress")
async def get_install_progress():
    """Get install progress."""
    return {"status": "not_started"}

# Sessions endpoint
@app.get("/api/federated/sessions")
async def get_sessions():
    """Get sessions."""
    return {
        "sessions": [
            {
                "id": "session_001",
                "name": "Test Session 1",
                "description": "Federated learning session for testing",
                "model_type": "transformer",
                "status": "active",
                "current_round": 3,
                "total_rounds": 10,
                "min_nodes": 5,
                "max_nodes": 20,
                "active_participants": 8,
                "created_at": "2024-01-15T10:00:00Z",
                "started_at": "2024-01-15T10:30:00Z"
            }
        ]
    }

if __name__ == "__main__":
    logger.info("🚀 Starting Simple AILOOS Backend on 0.0.0.0:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)