#!/bin/bash

# AILOOS CLI Installation Script
# Installs the beautiful Node.js CLI that works with npx

echo "🚀 Installing AILOOS Neural Link Terminal..."
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 14+ first:"
    echo "   https://nodejs.org/"
    exit 1
fi

# Check if pnpm is installed, fallback to npm
if command -v pnpm &> /dev/null; then
    PACKAGE_MANAGER="pnpm"
    INSTALL_CMD="pnpm add -g"
    echo "✅ Using pnpm (recommended)"
elif command -v npm &> /dev/null; then
    PACKAGE_MANAGER="npm"
    INSTALL_CMD="npm install -g"
    echo "✅ Using npm"
else
    echo "❌ Neither pnpm nor npm found. Please install Node.js first:"
    echo "   https://nodejs.org/"
    exit 1
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+ first:"
    echo "   https://python.org/"
    exit 1
fi

echo "✅ Prerequisites check passed"
echo ""

# Install pnpm if not available but recommended
if [ "$PACKAGE_MANAGER" = "npm" ]; then
    echo "💡 Tip: Consider installing pnpm for better performance:"
    echo "   curl -fsSL https://get.pnpm.io/install.sh | sh"
    echo ""
fi

# Install the CLI globally
echo "📦 Installing ailoos-cli globally..."
$INSTALL_CMD ailoos-cli

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Installation successful!"
    echo ""
    echo "🚀 Usage:"
    echo "   npx ailoos                    # Launch the terminal"
    echo "   npx ailoos --help            # Show help"
    echo ""
    echo "📚 What you get:"
    echo "   • Beautiful cinematic interface"
    echo "   • Clean terminal experience (no Python logs)"
    echo "   • Interactive menus for all AILOOS features"
    echo "   • Wallet management, dataset operations, federated training"
    echo ""
    echo "🔗 Requirements:"
    echo "   • Python 3.8+ with 'pip install ailoos'"
    echo "   • Node.js 14+ (already installed)"
    echo ""
    if [ "$PACKAGE_MANAGER" = "pnpm" ]; then
        echo "🌟 Try it now: pnpm dlx ailoos-cli"
        echo "   Or: ailoos-cli (if installed globally)"
    else
        echo "🌟 Try it now: npx ailoos-cli"
        echo "   Or: ailoos-cli (if installed globally)"
    fi
else
    echo ""
    echo "❌ Installation failed. Please check the error messages above."
    exit 1
fi