#!/bin/bash

# 🚀 Deploy AILOOS Backend to Google Cloud Run
# Uses the existing GCP project: ailoos-oauth-473213

set -e

echo "🚀 Deploying AILOOS Backend to Google Cloud Run"
echo "================================================"

# Configuration
PROJECT_ID="ailoos-oauth-473213"
SERVICE_NAME="ailoos-api"
REGION="europe-west1"
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if gcloud is installed and authenticated
check_gcloud() {
    print_status "Checking Google Cloud SDK..."

    if ! command -v gcloud &> /dev/null; then
        print_error "gcloud CLI is not installed. Please install Google Cloud SDK first."
        print_status "Download from: https://cloud.google.com/sdk/docs/install"
        exit 1
    fi

    # Check if authenticated
    if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | head -n 1 > /dev/null; then
        print_warning "Not authenticated with Google Cloud. Running authentication..."
        gcloud auth login
    fi

    # Set project
    gcloud config set project $PROJECT_ID

    print_success "Google Cloud SDK configured"
}

# Build and push Docker image
build_and_push() {
    print_status "Building Docker image..."

    # Build the image for AMD64 architecture
    docker build --platform linux/amd64 -f Dockerfile.backend -t $IMAGE_NAME .

    print_status "Pushing image to Google Container Registry..."
    gcloud auth configure-docker --quiet
    docker push $IMAGE_NAME

    print_success "Image built and pushed: $IMAGE_NAME"
}

# Deploy to Cloud Run
deploy_to_cloud_run() {
    print_status "Deploying to Cloud Run..."

    # Create env vars file
    cat > /tmp/cloud_run_env_vars.yaml << EOF
NODE_ENV: production
CORS_ALLOWED_ORIGINS: https://www.ailoos.com,https://ailoos.com,http://localhost:3000,http://localhost:8000
EOF

    # Deploy with proper configuration
    gcloud run deploy $SERVICE_NAME \
        --image $IMAGE_NAME \
        --platform managed \
        --region $REGION \
        --allow-unauthenticated \
        --port 8000 \
        --memory 2Gi \
        --cpu 1 \
        --max-instances 3 \
        --concurrency 80 \
        --timeout 300 \
        --min-instances 1 \
        --env-vars-file /tmp/cloud_run_env_vars.yaml

    # Get the service URL
    SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")

    print_success "Backend deployed to Cloud Run"
    print_status "Service URL: $SERVICE_URL"
    print_status "Health check: $SERVICE_URL/v1/health"
}

# Update Vercel environment variables
update_vercel_env() {
    print_status "Updating Vercel environment variables..."

    cd frontend

    # Remove old environment variables
    for var in NEXT_PUBLIC_COORDINATOR_API_URL NEXT_PUBLIC_FEDERATED_API_URL NEXT_PUBLIC_MARKETPLACE_API_URL NEXT_PUBLIC_WALLET_API_URL NEXT_PUBLIC_EMPOORIO_API_URL NEXT_PUBLIC_SETTINGS_API_URL NEXT_PUBLIC_ANALYTICS_API_URL; do
        echo "y" | vercel env rm $var production 2>/dev/null || true
    done

    # Add new environment variables pointing to Cloud Run
    vercel env add NEXT_PUBLIC_COORDINATOR_API_URL production <<< "$SERVICE_URL"
    vercel env add NEXT_PUBLIC_FEDERATED_API_URL production <<< "$SERVICE_URL"
    vercel env add NEXT_PUBLIC_MARKETPLACE_API_URL production <<< "$SERVICE_URL"
    vercel env add NEXT_PUBLIC_WALLET_API_URL production <<< "$SERVICE_URL"
    vercel env add NEXT_PUBLIC_EMPOORIO_API_URL production <<< "$SERVICE_URL"
    vercel env add NEXT_PUBLIC_SETTINGS_API_URL production <<< "$SERVICE_URL"
    vercel env add NEXT_PUBLIC_ANALYTICS_API_URL production <<< "$SERVICE_URL"

    # Redeploy frontend
    print_status "Redeploying frontend with new API URLs..."
    vercel --prod

    print_success "Vercel environment updated"
}

# Test the deployment
test_deployment() {
    print_status "Testing deployment..."

    # Wait a bit for the service to be ready
    sleep 10

    # Test health endpoint
    if curl -f -s "$SERVICE_URL/v1/health" > /dev/null 2>&1; then
        print_success "Backend health check passed"
    else
        print_error "Backend health check failed"
        print_status "Check logs: gcloud logs read --limit=50 --filter=\"resource.type=cloud_run_revision\" --project=$PROJECT_ID"
        exit 1
    fi
}

# Main function
main() {
    echo "AILOOS Backend Deployment to Google Cloud Run"
    echo "=============================================="
    echo ""
    echo "This will deploy the backend to your existing GCP project: $PROJECT_ID"
    echo "Free tier: 2 million requests/month, 400,000 GB-seconds/month"
    echo ""

    read -p "Continue with deployment? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_status "Deployment cancelled"
        exit 0
    fi

    check_gcloud
    build_and_push
    deploy_to_cloud_run
    update_vercel_env
    test_deployment

    echo ""
    print_success "🎉 AILOOS Backend successfully deployed to Google Cloud Run!"
    echo ""
    echo "Service Details:"
    echo "- URL: $SERVICE_URL"
    echo "- Region: $REGION"
    echo "- Free tier: 2M requests/month"
    echo ""
    echo "Frontend has been updated and redeployed to use the new backend."
    echo "Your app should now work at: https://www.ailoos.com"
    echo ""
    echo "Monitor your service:"
    echo "gcloud run services logs read $SERVICE_NAME --region=$REGION"
}

# Run main function
main "$@"