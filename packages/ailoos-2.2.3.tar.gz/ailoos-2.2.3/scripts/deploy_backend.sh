#!/bin/bash

# AILOOS Backend Deployment Script for GCP
# Despliega todos los servicios backend en Google Cloud Platform

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Función de ayuda
usage() {
    echo "Uso: $0 [OPTIONS]"
    echo ""
    echo "Despliega el backend de AILOOS en GCP"
    echo ""
    echo "OPTIONS:"
    echo "  -e, --environment ENV    Ambiente (staging|production) [default: staging]"
    echo "  -p, --project-id ID       GCP Project ID [default: ailoos-ia]"
    echo "  -r, --region REGION       GCP Region [default: us-central1]"
    echo "  -t, --tag TAG             Docker tag [default: latest]"
    echo "  -s, --skip-build          Saltar construcción de imágenes"
    echo "  -h, --help                Mostrar esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 --environment production"
    echo "  $0 -e staging -p my-project -r us-west1"
}

# Valores por defecto
ENVIRONMENT="staging"
PROJECT_ID="ailoos-oauth-473213"
REGION="us-central1"
DOCKER_TAG="latest"
SKIP_BUILD=false

# Parsear argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -p|--project-id)
            PROJECT_ID="$2"
            shift 2
            ;;
        -r|--region)
            REGION="$2"
            shift 2
            ;;
        -t|--tag)
            DOCKER_TAG="$2"
            shift 2
            ;;
        -s|--skip-build)
            SKIP_BUILD=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Opción desconocida: $1"
            usage
            exit 1
            ;;
    esac
done

# Validar ambiente
if [[ "$ENVIRONMENT" != "staging" && "$ENVIRONMENT" != "production" ]]; then
    error "Ambiente inválido: $ENVIRONMENT. Debe ser 'staging' o 'production'"
    exit 1
fi

log "🚀 Iniciando despliegue del backend AILOOS"
log "Ambiente: $ENVIRONMENT"
log "Proyecto GCP: $PROJECT_ID"
log "Región: $REGION"
log "Tag Docker: $DOCKER_TAG"

# Verificar autenticación GCP
log "Verificando autenticación GCP..."
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    error "No hay cuenta GCP activa. Ejecuta: gcloud auth login"
    exit 1
fi

# Configurar proyecto GCP
log "Configurando proyecto GCP: $PROJECT_ID"
gcloud config set project "$PROJECT_ID"
gcloud config set compute/region "$REGION"

# Verificar que el proyecto existe
if ! gcloud projects describe "$PROJECT_ID" &>/dev/null; then
    error "Proyecto GCP '$PROJECT_ID' no existe o no tienes acceso"
    exit 1
fi

# Habilitar APIs necesarias
log "Habilitando APIs de GCP..."
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable containerregistry.googleapis.com
gcloud services enable sqladmin.googleapis.com
gcloud services enable redis.googleapis.com
gcloud services enable storage.googleapis.com

# Definir servicios a desplegar
SERVICES=(
    "coordinator:src/ailoos"
    "compliance:src/ailoos"
    "dashboard:src/ailoos"
    "monitoring:src/ailoos"
    "integration:src/ailoos"
)

# Función para construir y subir imagen
build_and_push_image() {
    local service_name=$1
    local source_path=$2
    local image_name="gcr.io/$PROJECT_ID/ailoos-$service_name:$DOCKER_TAG"

    log "Construyendo imagen para $service_name..."

    # Crear directorio temporal para el build
    local temp_dir="/tmp/ailoos-$service_name-build"
    mkdir -p "$temp_dir"

    # Copiar código fuente
    cp -r "$source_path"/* "$temp_dir/"

    # Copiar requirements.txt si existe
    if [[ -f "$source_path/../requirements.txt" ]]; then
        cp "$source_path/../requirements.txt" "$temp_dir/"
    fi

    # Crear Dockerfile
    cat > "$temp_dir/Dockerfile" << EOF
FROM python:3.9-slim

WORKDIR /app

# Instalar dependencias del sistema
RUN apt-get update && apt-get install -y \\
    gcc \\
    && rm -rf /var/lib/apt/lists/*

# Copiar requirements desde el directorio raíz del proyecto
COPY ../../../../requirements_minimal.txt ./requirements.txt
RUN pip install --no-cache-dir -r requirements.txt

# Copiar código fuente
COPY . .

# Exponer puerto
EXPOSE 8000

# Comando de inicio basado en el servicio
EOF

    # Agregar comando específico por servicio
    case $service_name in
        coordinator)
            echo 'CMD ["python", "-m", "ailoos.api.coordinator_api"]' >> "$temp_dir/Dockerfile"
            ;;
        compliance)
            echo 'CMD ["python", "-m", "ailoos.api.compliance_api"]' >> "$temp_dir/Dockerfile"
            ;;
        dashboard)
            echo 'CMD ["python", "-m", "ailoos.api.dashboard_api"]' >> "$temp_dir/Dockerfile"
            ;;
        monitoring)
            echo 'CMD ["python", "-m", "ailoos.monitoring.api"]' >> "$temp_dir/Dockerfile"
            ;;
        integration)
            echo 'CMD ["python", "-m", "ailoos.api.integration_api"]' >> "$temp_dir/Dockerfile"
            ;;
        *)
            echo 'CMD ["python", "main.py"]' >> "$temp_dir/Dockerfile"
            ;;
    esac

    # Construir imagen
    gcloud builds submit "$temp_dir" \
        --tag "$image_name" \
        --timeout=1800 \
        --machine-type=e2-highcpu-8

    # Limpiar directorio temporal
    rm -rf "$temp_dir"

    success "Imagen construida: $image_name"
}

# Función para desplegar servicio Cloud Run
deploy_service() {
    local service_name=$1
    local image_name="gcr.io/$PROJECT_ID/ailoos-$service_name:$DOCKER_TAG"
    local service_url=""

    log "Desplegando servicio $service_name..."

    # Variables de entorno específicas por servicio
    local env_vars="--set-env-vars ENVIRONMENT=$ENVIRONMENT"

    # Desplegar a Cloud Run
    gcloud run deploy "ailoos-$service_name-api-$ENVIRONMENT" \
        --image "$image_name" \
        --platform managed \
        --region "$REGION" \
        --allow-unauthenticated \
        --port 8000 \
        --memory 2Gi \
        --cpu 2 \
        --max-instances 10 \
        --min-instances 1 \
        --timeout 900 \
        --concurrency 80 \
        $env_vars

    # Obtener URL del servicio
    service_url=$(gcloud run services describe "ailoos-$service_name-api-$ENVIRONMENT" \
        --region="$REGION" \
        --format="value(status.url)")

    success "Servicio desplegado: $service_name -> $service_url"

    # Guardar URL para configuración posterior
    echo "$service_name=$service_url" >> "deployed_services_$ENVIRONMENT.txt"
}

# Construir imágenes si no se salta
if [[ "$SKIP_BUILD" == false ]]; then
    log "🏗️  Construyendo imágenes Docker..."

    for service_info in "${SERVICES[@]}"; do
        IFS=':' read -r service_name source_path <<< "$service_info"
        build_and_push_image "$service_name" "$source_path"
    done

    success "Todas las imágenes construidas"
else
    warning "Saltando construcción de imágenes (--skip-build)"
fi

# Desplegar servicios
log "🚀 Desplegando servicios a Cloud Run..."

# Limpiar archivo de servicios anteriores
rm -f "deployed_services_$ENVIRONMENT.txt"

for service_info in "${SERVICES[@]}"; do
    IFS=':' read -r service_name source_path <<< "$service_info"
    deploy_service "$service_name"
done

success "Todos los servicios desplegados"

# Configurar API Gateway si es necesario
log "Configurando API Gateway..."

# Crear configuración del API Gateway
cat > "api_config_$ENVIRONMENT.yaml" << EOF
swagger: "2.0"
info:
  title: "AILOOS API Gateway - $ENVIRONMENT"
  version: "1.0.0"
host: "ailoos-gateway-$ENVIRONMENT-\$(PROJECT_NUMBER).uc.gateway.dev"
schemes:
  - "https"
paths:
EOF

# Agregar rutas para cada servicio
while IFS='=' read -r service_name service_url; do
    cat >> "api_config_$ENVIRONMENT.yaml" << EOF
  /$service_name/*:
    get:
      operationId: "get$service_name"
      x-google-backend:
        address: "$service_url"
      responses:
        '200':
          description: "Success"
EOF
done < "deployed_services_$ENVIRONMENT.txt"

# Desplegar API Gateway
gcloud api-gateway api-configs create "ailoos-api-config-$ENVIRONMENT" \
    --api="ailoos-api-$ENVIRONMENT" \
    --openapi-spec="api_config_$ENVIRONMENT.yaml" \
    --project="$PROJECT_ID"

gcloud api-gateway gateways create "ailoos-gateway-$ENVIRONMENT" \
    --api="ailoos-api-$ENVIRONMENT" \
    --api-config="ailoos-api-config-$ENVIRONMENT" \
    --location="$REGION" \
    --project="$PROJECT_ID"

gateway_url=$(gcloud api-gateway gateways describe "ailoos-gateway-$ENVIRONMENT" \
    --location="$REGION" \
    --format="value(defaultHostname)")

success "API Gateway configurado: https://$gateway_url"

# Configurar monitoring y alertas
log "Configurando monitoring y alertas..."

# Crear políticas de alerta para cada servicio
while IFS='=' read -r service_name service_url; do
    # Alerta de CPU alta
    gcloud monitoring alert-policies create "high-cpu-$service_name-$ENVIRONMENT" \
        --display-name="High CPU Usage - $service_name ($ENVIRONMENT)" \
        --condition-filter="metric.type=\"run.googleapis.com/container/cpu/utilization\" AND resource.type=\"cloud_run_revision\" AND resource.label.service_name=\"ailoos-$service_name-api-$ENVIRONMENT\"" \
        --condition-threshold=0.8 \
        --duration=300s \
        --notification-channels="email-admin" \
        --project="$PROJECT_ID"

    # Alerta de latencia alta
    gcloud monitoring alert-policies create "high-latency-$service_name-$ENVIRONMENT" \
        --display-name="High Latency - $service_name ($ENVIRONMENT)" \
        --condition-filter="metric.type=\"run.googleapis.com/request_latencies\" AND resource.type=\"cloud_run_revision\" AND resource.label.service_name=\"ailoos-$service_name-api-$ENVIRONMENT\"" \
        --condition-threshold=5000 \
        --duration=300s \
        --notification-channels="email-admin" \
        --project="$PROJECT_ID"
done < "deployed_services_$ENVIRONMENT.txt"

# Configurar uptime checks
while IFS='=' read -r service_name service_url; do
    gcloud monitoring uptime-check-configs create "uptime-$service_name-$ENVIRONMENT" \
        --display-name="Uptime Check - $service_name ($ENVIRONMENT)" \
        --http-check-path="/health" \
        --http-check-port=443 \
        --use-ssl \
        --resource-type="uptime_url" \
        --selected-regions="$REGION" \
        --project="$PROJECT_ID"
done < "deployed_services_$ENVIRONMENT.txt"

success "Monitoring y alertas configurados"

# Limpiar archivos temporales
log "Limpiando archivos temporales..."
rm -f "api_config_$ENVIRONMENT.yaml"

# Mostrar resumen del despliegue
log "📋 Resumen del despliegue:"
echo ""
echo "Ambiente: $ENVIRONMENT"
echo "Proyecto: $PROJECT_ID"
echo "Región: $REGION"
echo ""
echo "Servicios desplegados:"
while IFS='=' read -r service_name service_url; do
    echo "  $service_name: $service_url"
done < "deployed_services_$ENVIRONMENT.txt"
echo ""
echo "API Gateway: https://$gateway_url"
echo ""

success "🎉 Despliegue del backend completado exitosamente!"
warning "Recuerda actualizar las variables de entorno del frontend con las nuevas URLs"

# Guardar configuración para el frontend
cat > "backend_config_$ENVIRONMENT.json" << EOF
{
  "environment": "$ENVIRONMENT",
  "project_id": "$PROJECT_ID",
  "region": "$REGION",
  "gateway_url": "https://$gateway_url",
  "services": {
EOF

while IFS='=' read -r service_name service_url; do
    echo "    \"$service_name\": \"$service_url\"," >> "backend_config_$ENVIRONMENT.json"
done < "deployed_services_$ENVIRONMENT.txt"

# Remover última coma
sed -i '$ s/,$//' "backend_config_$ENVIRONMENT.json"

cat >> "backend_config_$ENVIRONMENT.json" << EOF
  }
}
EOF

success "Configuración guardada en backend_config_$ENVIRONMENT.json"