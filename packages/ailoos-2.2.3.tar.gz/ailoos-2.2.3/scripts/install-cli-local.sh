#!/bin/bash

# Install AILOOS CLI locally (without npm registry)
# Creates permanent installation in user's home directory

echo "🏠 Installing AILOOS CLI locally..."
echo ""

# Check prerequisites
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 14+ first:"
    echo "   https://nodejs.org/"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+ first:"
    echo "   https://python.org/"
    exit 1
fi

if ! python3 -c "import ailoos; print('OK')" &> /dev/null; then
    echo "❌ AILOOS Python SDK not found. Installing..."
    pip install ailoos
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install AILOOS Python SDK"
        exit 1
    fi
fi

echo "✅ Prerequisites check passed"
echo ""

# Create local CLI directory
CLI_DIR="$HOME/.ailoos-cli"
echo "📁 Creating CLI directory: $CLI_DIR"

if [ -d "$CLI_DIR" ]; then
    echo "🗑️  Removing existing installation..."
    rm -rf "$CLI_DIR"
fi

mkdir -p "$CLI_DIR"
cp -r ailoos-cli/* "$CLI_DIR/"

# Install dependencies locally
echo "📦 Installing dependencies..."
cd "$CLI_DIR"
npm install --production

# Create executable script
EXECUTABLE="$HOME/.local/bin/ailoos-terminal"
EXECUTABLE_ALT="$HOME/.local/bin/ailoos-dashboard"

echo "🔗 Creating executable scripts..."

# Ensure ~/.local/bin exists
mkdir -p "$HOME/.local/bin"

# Create main executable
cat > "$EXECUTABLE" << 'EOF'
#!/bin/bash
# AILOOS Neural Link Terminal Launcher
CLI_DIR="$HOME/.ailoos-cli"

# Check if we're in the AILOOS project directory
if [ -f "ailoos-cli/index.js" ] && [ -f "pyproject.toml" ]; then
    # We're in the project directory, use local CLI
    cd "ailoos-cli" && node index.js "$@"
else
    # Use installed CLI
    cd "$CLI_DIR" && node index.js "$@"
fi
EOF

chmod +x "$EXECUTABLE"

# Create alternative executable
cat > "$EXECUTABLE_ALT" << 'EOF'
#!/bin/bash
# AILOOS Terminal Launcher
CLI_DIR="$HOME/.ailoos-cli"
cd "$CLI_DIR" && node index.js "$@"
EOF

chmod +x "$EXECUTABLE_ALT"

# Add ~/.local/bin to PATH if not already there
SHELL_RC=""
if [ -n "$ZSH_VERSION" ]; then
    SHELL_RC="$HOME/.zshrc"
elif [ -n "$BASH_VERSION" ]; then
    SHELL_RC="$HOME/.bashrc"
fi

if [ -n "$SHELL_RC" ] && ! grep -q 'export PATH="$HOME/.local/bin:$PATH"' "$SHELL_RC" 2>/dev/null; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$SHELL_RC"
    echo "📝 Added ~/.local/bin to PATH in $SHELL_RC"
    echo "   Please run: source $SHELL_RC"
fi

echo ""
echo "🎉 Installation successful!"
echo ""
echo "🚀 Usage:"
echo "   ailoos-terminal          # Launch Neural Link Terminal (Dashboard)"
echo "   ailoos-dashboard         # Alternative command"
echo "   ailoos                   # Python CLI (existing)"
echo ""
echo "📚 Commands:"
echo "   ailoos-terminal --help   # Show dashboard help"
echo "   ailoos --help           # Show Python CLI help"
echo ""
echo "🧪 Test the dashboard:"
echo "   ailoos-terminal"
echo ""
echo "📁 Installation location: $CLI_DIR"
echo "🔗 Executables: $EXECUTABLE, $EXECUTABLE_ALT"
echo ""
if [ -n "$SHELL_RC" ]; then
    echo "💡 If 'command not found', run: source $SHELL_RC"
fi