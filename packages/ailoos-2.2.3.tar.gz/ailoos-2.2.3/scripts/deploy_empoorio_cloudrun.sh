#!/bin/bash

#!/bin/bash

# AILOOS EmpoorioLM Cloud Run Deployment Script
# Despliega EmpoorioLM API a Google Cloud Run

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

info() {
    echo -e "${PURPLE}ℹ️  $1${NC}"
}

# Valores por defecto
PROJECT_ID="${PROJECT_ID:-ailoos-oauth-473213}"
REGION="${REGION:-us-central1}"
SERVICE_NAME="empoorio-lm-api"
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

# Función de ayuda
usage() {
    echo "Uso: $0 [OPTIONS]"
    echo ""
    echo "Despliega EmpoorioLM API a Google Cloud Run"
    echo ""
    echo "OPTIONS:"
    echo "  -p, --project-id ID     GCP Project ID [default: ailoos-oauth-473213]"
    echo "  -r, --region REGION     GCP Region [default: us-central1]"
    echo "  -s, --service-name NAME Nombre del servicio [default: empoorio-lm-api]"
    echo "  -h, --help              Mostrar esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 --project-id my-project"
    echo "  $0 -r europe-west1"
}

# Parsear argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -p|--project-id)
            PROJECT_ID="$2"
            shift 2
            ;;
        -r|--region)
            REGION="$2"
            shift 2
            ;;
        -s|--service-name)
            SERVICE_NAME="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Opción desconocida: $1"
            usage
            exit 1
            ;;
    esac
done

# Actualizar IMAGE_NAME con el project ID correcto
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

log "🚀 Iniciando despliegue de EmpoorioLM a Cloud Run"
log "Proyecto GCP: ${PROJECT_ID}"
log "Región: ${REGION}"
log "Servicio: ${SERVICE_NAME}"
log "Imagen: ${IMAGE_NAME}"

# Verificar prerrequisitos
log "Verificando prerrequisitos..."

# Verificar gcloud
if ! command -v gcloud &> /dev/null; then
    error "gcloud CLI no está instalado. Instálalo desde: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

# Verificar docker
if ! command -v docker &> /dev/null; then
    error "Docker no está instalado. Instálalo desde: https://docs.docker.com/get-docker/"
    exit 1
fi

# Verificar autenticación
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    error "No hay cuenta GCP activa. Ejecuta: gcloud auth login"
    exit 1
fi

# Configurar proyecto
log "Configurando proyecto GCP: ${PROJECT_ID}"
gcloud config set project "${PROJECT_ID}"

# Habilitar APIs necesarias
log "Habilitando APIs necesarias..."
gcloud services enable run.googleapis.com
gcloud services enable containerregistry.googleapis.com

# Usar Cloud Build para construir la imagen directamente
log "Construyendo imagen con Cloud Build..."
gcloud builds submit src \
  --config=src/cloudbuild.yaml

# Desplegar a Cloud Run
log "Desplegando a Cloud Run..."
DEPLOY_COMMAND="gcloud run deploy ${SERVICE_NAME} \
  --image ${IMAGE_NAME}:latest \
  --platform managed \
  --region ${REGION} \
  --allow-unauthenticated \
  --port 8000 \
  --memory 1Gi \
  --cpu 1 \
  --max-instances 10 \
  --concurrency 80 \
  --set-env-vars ENVIRONMENT=production"

# Ejecutar despliegue
if eval "$DEPLOY_COMMAND"; then
    success "Despliegue completado exitosamente"

    # Obtener la URL del servicio
    SERVICE_URL=$(gcloud run services describe ${SERVICE_NAME} --region=${REGION} --format="value(status.url)")

    if [ -n "$SERVICE_URL" ]; then
        success "URL del servicio: ${SERVICE_URL}"

        # Probar el servicio
        log "Probando el servicio..."
        if curl -f -s "${SERVICE_URL}/health" > /dev/null 2>&1; then
            success "Servicio funcionando correctamente"
        else
            warning "No se pudo verificar el servicio automáticamente"
        fi

        # Mostrar información para configuración
        echo ""
        info "📋 Información para configuración:"
        echo "URL de EmpoorioLM API: ${SERVICE_URL}"
        echo ""
        echo "Para configurar en Vercel:"
        echo "vercel env add NEXT_PUBLIC_EMPOORIO_API_URL production"
        echo "Valor: ${SERVICE_URL}"
        echo ""
        echo "Para probar localmente:"
        echo "curl \"${SERVICE_URL}/api/v1/empoorio-lm/generate\" \\"
        echo "  -H \"Content-Type: application/json\" \\"
        echo "  -d '{\"prompt\": \"Hola, ¿cómo estás?\"}'"

    else
        warning "No se pudo obtener la URL del servicio"
    fi

else
    error "Error en el despliegue"
    exit 1
fi

log "🎉 Despliegue de EmpoorioLM completado"