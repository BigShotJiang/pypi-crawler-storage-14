# AILOOS - Decentralized AI Learning Orchestration System

AILOOS is a comprehensive SDK for federated learning and decentralized AI training, featuring privacy-preserving machine learning, secure data infrastructure, and complete economic system with DRACMA tokens.

## 🚀 Installation

### 🎨 Option 1: Beautiful CLI (Recommended for Users)

For a cinematic, clean terminal experience like Gemini CLI:

```bash
# Local install (recommended - works immediately)
./install-cli-local.sh

# Or test locally first
./test-cli-local.sh

# Or install from npm registry (after publishing)
npm install -g @ailoos/terminal
pnpm add -g @ailoos/terminal

# Launch the neural link
ailoos-terminal          # Neural Link Terminal (Dashboard)
ailoos-dashboard         # Alternative command
npx @ailoos/terminal      # From npm registry
pnpm dlx @ailoos/terminal # From npm registry
ailoos                   # Python CLI (existing)
```

**Features:**
- 🎭 Cinematic ASCII interface
- 🧹 Clean terminal (no Python logs)
- 🎯 Interactive menus
- ⚡ Fast startup

### 🔧 Option 2: Python SDK (For Developers)

For programmatic use and development:

```bash
pip install ailoos
```

**Features:**
- 🐍 Full Python SDK
- 🔧 All CLI commands
- 📊 Detailed logging
- 🛠️ Development tools

## 🎛️ Interactive Dashboard

AILOOS now includes a beautiful web-based dashboard for complete system management:

```bash
# Install with dashboard support
pip install ailoos[dashboard]

# Launch the interactive dashboard
ailoos-dashboard

# Or run all APIs together
python scripts/run_dashboard.py
```

**Dashboard Features:**
- 🔄 **Data Refinery**: Real-time pipeline monitoring and management
- 💻 **Hardware Monitor**: Live system metrics and alerts
- 💰 **Wallet Management**: DRACMA transactions and staking
- 🤖 **Federated Learning**: Mission control and node orchestration
- 📊 **Real-time Updates**: WebSocket-powered live data
- 🎨 **Modern UI**: Responsive web interface

**Access Points:**
- **Dashboard**: http://localhost:3000/dashboard
- **API**: http://localhost:8003 (unified API)
- **WebSocket**: ws://localhost:8003/ws/dashboard

## � Requirements

- **For CLI**: Node.js 14+, Python 3.8+
- **For SDK**: Python 3.8+
- **For Dashboard**: Python 3.8+, Node.js 18+ (for frontend)
- Internet connection for IPFS operations

## 🛠️ Quick Start

### 🎨 CLI Experience (Recommended)

```bash
# Install beautiful CLI
./install-cli.sh

# Launch cinematic interface
npx ailoos
```

### 🔧 SDK Experience

```python
from ailoos import quick_setup

# Setup AILOOS automatically
success = quick_setup(verbose=True)
if success:
    print("AILOOS is ready!")
```

### Configuration

```bash
# Initialize configuration
ailoos config init

# Show current configuration
ailoos config show

# Set configuration values
ailoos config set node.coordinator_url "http://localhost:5001"
```

### Start Federated Node

```python
import asyncio
from ailoos import start_federated_node

# Start a federated learning node
await start_federated_node()
```

## 📚 Key Features

- **Federated Learning**: Privacy-preserving distributed training
- **Secure Data Infrastructure**: PII scrubbing and IPFS integration
- **Economic System**: DRACMA token management and staking
- **Zero Configuration**: Automatic setup and discovery
- **GDPR Compliance**: Built-in privacy protection

## 🔧 Advanced Usage

### Data Processing

```python
from ailoos.data.dataset_manager import dataset_manager

# Process a dataset with automatic PII scrubbing
result = dataset_manager.process_text_file(
    file_path="data.txt",
    dataset_name="my_dataset",
    shard_size_mb=10
)
```

### Wallet Operations

```python
from ailoos.blockchain.wallet_manager import get_wallet_manager

wm = get_wallet_manager()
wallet_id = wm.create_wallet("user123", "secure_password")
balance = wm.get_balance(wallet_id)
```

## 📖 Documentation

For complete documentation, visit:
- [GitHub Repository](https://github.com/empoorio/ailoos)
- [Official Documentation](https://docs.ailoos.dev)
- [CLI Documentation](ailoos-cli/README.md)

## 🛠️ Development & Publishing

### Testing Locally
```bash
# Test CLI before publishing
./test-cli-local.sh
```

### Publishing CLI to npm
```bash
# Publish CLI to npm registry
./publish-cli.sh
```

### Building Python SDK
```bash
# Build and publish Python package
python setup.py sdist bdist_wheel
twine upload dist/*
```

## 📝 License

Copyright © 2024 AILOOS Technologies & Empoorio Ecosystem. All rights reserved.

## 📞 Support

- **Email**: dev@empoorio.com
- **GitHub Issues**: [github.com/empoorio/ailoos/issues](https://github.com/empoorio/ailoos/issues)
- **Discord**: https://discord.gg/ailoos

---

**AILOOS** - *Sovereign Decentralized AI Library with complete economic system.* 🚀

## 🎯 Quick Reference

| Component | Install | Run | Purpose |
|-----------|---------|-----|---------|
| **Neural Link Terminal** | `./install-cli-local.sh` | `ailoos-terminal` | Beautiful cinematic interface |
| **CLI npm** | `npm install -g @ailoos/terminal` | `npx @ailoos/terminal` | Terminal from registry |
| **Python SDK** | `pip install ailoos` | `ailoos` | Full CLI with 60+ commands |
| **Local Test** | `./test-cli-local.sh` | - | Test before publishing |
| **Publish** | `./publish-cli.sh` | - | Release to npm |
