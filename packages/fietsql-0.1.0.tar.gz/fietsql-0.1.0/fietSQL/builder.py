import re
import sqlite3
from dataclasses import dataclass
from typing import Dict, Set, List, Tuple


def build_prompt(schema: str, question: str) -> str:
    """
    Build a chat-style prompt for a text-to-SQL model.

    :param schema: DDL string representing the database schema.
    :param question: Natural language question.
    :param sql: (Optional) SQL to include as assistant output (for few-shot, etc.).
    :param include_sql: If True, include `sql` as the assistant's answer; otherwise, leave assistant turn open.
    """
    system = (
        "You are an expert text-to-SQL model. "
        "Given a database schema and a natural language question, "
        "you must output a valid SQL query that answers the question."
    )

    user = (
        f"SCHEMA:\n{schema}\n\n"
        f"QUESTION:\n{question}\n\n"
        "Write the SQL query that answers the question."
    )

    prompt = (
        f"<|im_start|>system\n{system}\n<|im_end|>\n"
        f"<|im_start|>user\n{user}\n<|im_end|>\n"
        f"<|im_start|>assistant\n"
    )

    return prompt


@dataclass
class ExecutabilityReport:
    """Result of evaluating SQL executability against a schema."""
    is_executable: bool
    missing_tables: Set[str]
    missing_columns: Set[str]
    details: str


def _parse_schema_tables_and_columns(schema: str) -> Dict[str, Set[str]]:
    """
    Very lightweight DDL parser for statements like:

        CREATE TABLE table_name (
            col1 INT,
            col2 TEXT,
            PRIMARY KEY (col1)
        );

    Returns {table_name: {col1, col2, ...}}.
    """
    tables: Dict[str, Set[str]] = {}

    create_table_pattern = re.compile(
        r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"
        r"([`\"]?)(?P<name>[\w\.]+)\1\s*\((?P<body>.*?)\);",
        re.IGNORECASE | re.DOTALL,
    )

    for match in create_table_pattern.finditer(schema):
        table_name = match.group("name")
        body = match.group("body")

        cols: Set[str] = set()
        # Split body by lines, handle commas at line ends.
        for raw_line in body.splitlines():
            line = raw_line.strip().rstrip(",")
            if not line:
                continue

            # Skip table-level constraints
            upper = line.upper()
            if upper.startswith(("PRIMARY KEY", "FOREIGN KEY", "UNIQUE", "CONSTRAINT", "CHECK", "INDEX")):
                continue

            # Column line – first token is the column name
            col_match = re.match(r"([`\"]?)(?P<col>\w+)\1\s+", line)
            if col_match:
                cols.add(col_match.group("col"))

        tables[table_name] = cols

    return tables


def _extract_sql_tables(sql: str) -> Set[str]:
    """
    Extract table names from common clauses (FROM, JOIN, UPDATE, INSERT INTO).
    """
    patterns = [
        r"\bFROM\s+([`\"]?)(?P<table>\w+)\1",
        r"\bJOIN\s+([`\"]?)(?P<table>\w+)\1",
        r"\bUPDATE\s+([`\"]?)(?P<table>\w+)\1",
        r"\bINTO\s+([`\"]?)(?P<table>\w+)\1",  # for INSERT INTO
    ]

    tables: Set[str] = set()
    for pat in patterns:
        for match in re.finditer(pat, sql, flags=re.IGNORECASE):
            tables.add(match.group("table"))
    return tables


def _extract_sql_columns(sql: str) -> Tuple[Set[str], Set[str]]:
    """
    Extract column references from SQL.

    Returns:
        qualified: set of "table.column"
        unqualified: set of "column"
    """
    qualified: Set[str] = set()
    unqualified: Set[str] = set()

    # table.column (qualified)
    for match in re.finditer(
        r"([`\"]?)(?P<table>\w+)\1\.\s*([`\"]?)(?P<col>\w+)\3",
        sql,
        flags=re.IGNORECASE,
    ):
        t = match.group("table")
        c = match.group("col")
        qualified.add(f"{t}.{c}")

    # Unqualified columns are trickier; this is a heuristic:
    # - Look for tokens in SELECT, WHERE, GROUP BY, ORDER BY that look like identifiers.
    # - Ignore SQL keywords and numbers.
    sql_clean = re.sub(r"[(),=+\-*/<>]", " ", sql)
    tokens = re.findall(r"\b\w+\b", sql_clean)

    keywords = {
        "SELECT", "FROM", "WHERE", "JOIN", "INNER", "LEFT", "RIGHT", "FULL",
        "ON", "GROUP", "BY", "ORDER", "LIMIT", "OFFSET", "AS", "AND", "OR",
        "NOT", "IN", "IS", "NULL", "DESC", "ASC", "INSERT", "INTO", "VALUES",
        "UPDATE", "SET", "DELETE", "HAVING", "DISTINCT", "TOP",
    }

    for tok in tokens:
        up = tok.upper()
        if up in keywords:
            continue
        if tok.isdigit():
            continue
        # We'll treat all other tokens as potential identifiers; some will be table names,
        # but we primarily use these to detect completely unknown column names.
        unqualified.add(tok)

    return qualified, unqualified


def evaluate_executability(schema: str, sql: str) -> ExecutabilityReport:
    """
    Evaluate executability by actually applying the schema to an in-memory SQLite
    database and running the provided SQL against it.

    :param schema: DDL string with CREATE TABLE statements.
    :param sql: SQL query generated by the model.
    :return: ExecutabilityReport with details.
    """
    conn = sqlite3.connect(":memory:")

    try:
        try:
            conn.executescript(schema)
        except sqlite3.Error as exc:
            return ExecutabilityReport(
                is_executable=False,
                missing_tables=set(),
                missing_columns=set(),
                details=f"Failed to apply schema: {exc}",
            )

        try:
            conn.executescript(sql)
        except sqlite3.Error as exc:
            return ExecutabilityReport(
                is_executable=False,
                missing_tables=set(),
                missing_columns=set(),
                details=f"SQL failed to execute: {exc}",
            )

        return ExecutabilityReport(
            is_executable=True,
            missing_tables=set(),
            missing_columns=set(),
            details="SQL executed successfully against in-memory SQLite database.",
        )
    finally:
        conn.close()
