import unittest

from fietSQL.builder import evaluate_executability


SCHEMA = """
CREATE TABLE customers (
    id INT,
    name TEXT,
    email TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE orders (
    id INT,
    customer_id INT,
    total NUMERIC,
    PRIMARY KEY (id)
);
"""


class EvaluateExecutabilityTests(unittest.TestCase):
    def test_sql_executes_successfully(self) -> None:
        sql = """
        SELECT c.id, c.name, SUM(o.total) AS total_spent
        FROM customers c
        JOIN orders o ON o.customer_id = c.id
        GROUP BY c.id, c.name;
        """

        report = evaluate_executability(SCHEMA, sql)

        self.assertTrue(report.is_executable)
        self.assertEqual(
            report.details,
            "SQL executed successfully against in-memory SQLite database.",
        )

    def test_sql_failure_reports_error(self) -> None:
        sql = """
        SELECT p.name
        FROM products p;
        """

        report = evaluate_executability(SCHEMA, sql)

        self.assertFalse(report.is_executable)
        self.assertIn("SQL failed to execute", report.details)


if __name__ == "__main__":
    unittest.main()
