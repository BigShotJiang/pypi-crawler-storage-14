from fietSQL import build_prompt, evaluate_executability

schema = """
CREATE TABLE customers (
    id INT,
    name TEXT,
    email TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE orders (
    id INT,
    customer_id INT,
    total NUMERIC,
    PRIMARY KEY (id)
);
"""

question = "What is the total sales per customer?"
sql = """
SELECT c.id, c.name, SUM(o.total) AS total_spent
FROM customers c
JOIN orders o ON o.customer_id = c.id
GROUP BY c.id, c.name;
"""

prompt = build_prompt(schema, question)
report = evaluate_executability(schema, sql)

print(prompt)
print(report.is_executable)     # True (most likely)
print(report.details)           # "SQL executed successfully against in-memory SQLite database."
