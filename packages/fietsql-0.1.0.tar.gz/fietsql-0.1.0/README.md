# FietSQL Prompt & Eval Toolkit

Utilities for building high-quality prompts and validating SQL produced by the [cwolff/fietSQL](https://huggingface.co/cwolff/fietSQL) text-to-SQL model (also packaged for Ollama as `cowolff/fietSQL`). Supply your database schema plus a natural-language question, and this package will both format the chat prompt expected by the model and sanity-check the SQL it returns by running it inside an in-memory SQLite database.

## Features

- Prompt builder: creates the `<|im_start|>` style prompt template used to steer the fietSQL model.
- Schema-aware evaluation: applies your DDL to SQLite and runs the generated SQL to verify executability.
- Lightweight footprint: pure-Python utilities that work in notebooks, batch jobs, or services.

## Installation

```bash
pip install fietSQL
```

Or install straight from source:

```bash
pip install git+https://github.com/trl-lab/FietSQL-Package.git
```

## Quick start

```python
from fietSQL import build_prompt, evaluate_executability

SCHEMA = '''
CREATE TABLE customers (
    id INTEGER PRIMARY KEY,
    name TEXT,
    city TEXT
);

CREATE TABLE orders (
    id INTEGER PRIMARY KEY,
    customer_id INTEGER,
    total NUMERIC
);
'''

question = "Which city has the highest total sales?"

prompt = build_prompt(SCHEMA, question)

# send `prompt` to cwolff/fietSQL via Hugging Face or Ollama

sql = '''
SELECT c.city, SUM(o.total) AS total_sales
FROM customers c
JOIN orders o ON o.customer_id = c.id
GROUP BY c.city
ORDER BY total_sales DESC
LIMIT 1;
'''

report = evaluate_executability(SCHEMA, sql)
assert report.is_executable, report.details
```

## Related resources

- Hugging Face model card: <https://huggingface.co/cwolff/fietSQL>
- Pulling the Ollama build: `ollama pull cowolff/fietSQL`
- Issues and discussions: <https://github.com/trl-lab/FietSQL-Package/issues>

## License

Released under the MIT License. See `LICENSE` for details.