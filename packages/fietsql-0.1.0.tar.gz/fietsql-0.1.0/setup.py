from setuptools import setup, find_packages

setup(
    name="ddl2prompt",
    version="0.2.0",
    packages=find_packages(),
    author="Your Name",
    description="Utility to build text-to-SQL prompts from DDL and questions, and validate SQL executability",
    install_requires=[],
    python_requires=">=3.8",
)
