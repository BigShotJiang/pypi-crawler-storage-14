# IM_COOL_BOOY_GMAIL/main.py
#!/usr/bin/env python3

import webbrowser
import time
import sys
import re
import dns.resolver
import os
import requests

def main_function():
    print("This is the main_function.")

# ------------------------- COLORS -------------------------
BLUE = "\033[94m"
CYAN = "\033[96m"
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[92m"

# ------------------------- GOOGLE URLS -------------------------
RECOVERY_URL = "https://accounts.google.com/signin/recovery"
SECURITY_CHECKUP_URL = "https://myaccount.google.com/security-checkup"
ACCOUNT_COMPROMISED_URL = "https://support.google.com/accounts/answer/6294825"
REPORT_ABUSE_URL = "https://support.google.com/mail/contact/abuse?hl=en"

# ------------------------- GOOGLE VALID SENDERS -------------------------
OFFICIAL_GOOGLE_SENDERS = [
    "no-reply@google.com",
    "no-reply@accounts.google.com",
    "security@google.com",
    "google-noreply@google.com",
    "account-recovery-noreply@google.com"
]

# ------------------------- EMAIL CHECKERS -------------------------
def validate_email_format(email):
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(pattern, email) is not None

def check_domain_mx(domain):
    try:
        dns.resolver.resolve(domain, "MX")
        return True
    except:
        return False

def detect_phishing(text):
    phishing_signs = [
        "verify your account",
        "your password will expire",
        "login immediately",
        "suspend your account",
        "urgent",
        "click below",
        "verify identity",
        "update your payment",
        "security alert",
        "reset your password now",
    ]
    return [w for w in phishing_signs if w.lower() in text.lower()]

def check_fake_google(sender):
    return sender.lower() in OFFICIAL_GOOGLE_SENDERS

def report_gmail_abuse():
    print("\n🌍 Hacked Activity Report Page...\n")
    url = REPORT_ABUSE_URL
    try:
        os.system(f'am start -a android.intent.action.VIEW -d "{url}" >/dev/null 2>&1')
    except:
        webbrowser.open(url)

# ------------------------- BANNER & MENU -------------------------
def banner():
    print(
        BLUE + BOLD + """
╔════════════════════════════════════════════════╗
║       💠  GMAIL SECURITY ANALYZER TOOL         ║
║       🔰  SL Android Official ™                ║
║       📌️  DEVELOPER: 𝐈𝐌 𝐂𝐎𝐎𝐋 𝐁𝐎𝐎𝐘 𝓢𝓱𝓪𝓭𝓸𝔀 𝓚𝓲𝓷𝓰  ║
╚════════════════════════════════════════════════╝
""" + RESET
    )

def cli_menu():
    print(
        CYAN + BOLD + """
╔════════════════════ MENU ═════════════════════╗
║  [1] Recover Hacked Gmail Account             ║
║  [2] Google Security Checkup                  ║
║  [3] Account Compromised Guide                ║
║  [4] Username Generator & Public Social Scan  ║
║───────────────────────────────────────────────║
║  [5] Validate Email Format                    ║
║  [6] Check Domain MX Records                  ║
║  [7] Detect Phishing in Email/Text            ║
║  [8] Verify Google Sender Authenticity        ║
║  [9] Report Gmail Abuse / Hack Activity       ║
║───────────────────────────────────────────────║
║  [10] Exit                                    ║
╚═══════════════════════════════════════════════╝
""" + RESET
    )

def open_link(url):
    try:
        os.system(f'am start -a android.intent.action.VIEW -d "{url}" >/dev/null 2>&1')
    except:
        webbrowser.open(url)

# ------------------------- USERNAME GENERATOR & SOCIAL SCAN -------------------------
def generate_usernames_from_input(text):
    names = []
    text = text.strip()
    if "@" in text:
        local = text.split("@")[0].replace('"','').replace("'","")
        names.append(local)
        names.append(local.replace(".", ""))
        names.append(local.replace("_", ""))
        names.append(local.replace("-", ""))
        parts = re.split(r"[._\-]", local)
        parts = [p for p in parts if p]
        if len(parts) >= 2:
            first, last = parts[0], parts[-1]
            names += [first+last, first+"."+last, first[0]+last, first+last[0], last+first, first+"_"+last]
        for n in range(3):
            names.append(local+str(n))
    else:
        parts = text.split()
        parts = [p for p in parts if p]
        if len(parts)==1:
            names.append(parts[0].lower())
            names.append(parts[0].lower().replace(".", ""))
        else:
            first, last = parts[0].lower(), parts[-1].lower()
            names += [first+last, f"{first}.{last}", f"{first}_{last}", f"{first[0]}{last}", f"{first}{last[0]}", f"{last}{first}", f"{first}{last}123"]
    out=[]
    for n in names:
        n=n.lower()
        n=re.sub(r"[^a-z0-9._\-]","",n)
        if n and n not in out:
            out.append(n)
        leet = n.replace("a","4").replace("e","3").replace("o","0")
        if leet!=n and leet not in out:
            out.append(leet)
    return out[:40]

def build_public_search_urls(usernames):
    sites={
        "facebook":["https://www.facebook.com/{u}","https://m.facebook.com/public/{u}","https://www.facebook.com/search/top/?q={u}"],
        "instagram":["https://www.instagram.com/{u}/","https://www.instagram.com/{u}/?hl=en","https://www.instagram.com/explore/tags/{u}/"],
        "x":["https://x.com/{u}","https://twitter.com/{u}","https://mobile.twitter.com/search?q={u}"],
        "tiktok":["https://www.tiktok.com/@{u}","https://www.tiktok.com/search?q={u}"],
        "linkedin":["https://www.linkedin.com/in/{u}","https://www.linkedin.com/search/results/all/?keywords={u}"],
        "github":["https://github.com/{u}","https://github.com/search?q={u}"],
        "reddit":["https://www.reddit.com/user/{u}","https://www.reddit.com/search/?q={u}"],
        "youtube":["https://www.youtube.com/@{u}","https://www.youtube.com/results?search_query={u}"],
        "pinterest":["https://www.pinterest.com/{u}/","https://www.pinterest.com/search/pins/?q={u}"]
    }
    results={}
    for site,patterns in sites.items():
        results[site]=[]
        for u in usernames:
            for p in patterns:
                results[site].append(p.format(u=u))
    return results

def username_search_flow():
    print(CYAN + "\nUsername Generator & Public Social Scan\n" + RESET)
    inp=input("Enter email or full name: ").strip()
    if not inp:
        print("No input provided."); return
    usernames=generate_usernames_from_input(inp)
    if not usernames:
        print("No usernames generated."); return
    urls=build_public_search_urls(usernames)
    MAX_CHECKS=120; checks_done=0; total_links=sum(len(v) for v in urls.values())
    scan_results={site:[] for site in urls.keys()}
    headers={"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/115.0 Safari/537.36"}
    print(GREEN+f"\nScanning {total_links} public profile/search URLs...\n"+RESET)
    for site, link_list in urls.items():
        for link in link_list:
            if checks_done>=MAX_CHECKS: break
            try:
                resp=requests.head(link, headers=headers, timeout=6, allow_redirects=True)
                status=resp.status_code
                ok=status in (200,301,302)
            except:
                status=None; ok=False
            scan_results[site].append((link, status, ok))
            checks_done+=1
            percent=int((checks_done/total_links)*100)
            bar_len=50; filled_len=int(bar_len*percent/100)
            bar="█"*filled_len+"-"*(bar_len-filled_len)
            print(f"\rScanning: |{bar}| {percent}% ({checks_done}/{total_links}) URLs checked", end="", flush=True)
            time.sleep(0.12)
        if checks_done>=MAX_CHECKS: break
    print("\n\n"+GREEN+"Scan complete."+RESET)
    save_path="/sdcard/cool.txt"
    try:
        with open(save_path,"w",encoding="utf-8") as f:
            f.write(f"Username scan for input: {inp}\n\nGenerated usernames:\n")
            for u in usernames: f.write(f"- {u}\n")
            f.write("\nScan results (site, url, http_status, reachable):\n")
            for site, entries in scan_results.items():
                f.write(f"\n=== {site.upper()} ({len(entries)} urls checked) ===\n")
                for url,status,ok in entries:
                    f.write(f"{'OK' if ok else 'NO'}\t{status}\t{url}\n")
        saved=True
    except Exception as e:
        saved=False; err_msg=str(e)
    reachable_summary=[]; total_reachable=0
    for site,entries in scan_results.items():
        hits=[url for url,status,ok in entries if ok]
        if hits: reachable_summary.append((site,len(hits))); total_reachable+=len(hits)
    if reachable_summary:
        print(GREEN+f"Found reachable public profiles on {len(reachable_summary)} sites; total hits: {total_reachable}."+RESET)
        for site,count in reachable_summary:
            print(f" - {site}: {count} reachable link(s)")
    else: print("No reachable public profile links detected (within check limits).")
    if saved:
        short_desc=f"Saved full scan results (usernames + all checked URLs) to: {save_path}"
        print("\n"+CYAN+short_desc+RESET)
        print("\nShort summary:")
        print(f" - File path: {save_path}")
        print(f" - Total usernames: {len(usernames)}")
        print(f" - Total reachable hits: {total_reachable}")
    else:
        print(f"\n❌ Failed to save results: {err_msg}")

# ------------------------- CLI -------------------------
def run_cli():
    banner()
    while True:
        cli_menu()
        choice=input("🔰🔰 SELECT AN OPTION: ").strip()
        if choice=="1": open_link(RECOVERY_URL)
        elif choice=="2": open_link(SECURITY_CHECKUP_URL)
        elif choice=="3": open_link(ACCOUNT_COMPROMISED_URL)
        elif choice=="4": username_search_flow()
        elif choice=="5":
            email=input("🔰 Enter email: ")
            print("✔ Valid Email Format" if validate_email_format(email) else "❌ Invalid Email Format")
        elif choice=="6":
            domain=input("🔰 Enter domain (example.com): ")
            print("✔ Domain has MX Records" if check_domain_mx(domain) else "❌ Domain has no MX Records")
        elif choice=="7":
            text=input("🔰 Paste email text: ")
            result=detect_phishing(text)
            print("⚠️ Phishing signs found:", result if result else "✔ No phishing detected")
        elif choice=="8":
            sender=input("🔰 Enter sender email: ")
            print("✔ Legit Google Email" if check_fake_google(sender) else "❌ Fake Google Email")
        elif choice=="9": report_gmail_abuse()
        elif choice=="10":
            print(GREEN+"🔰 SL Android Official ™"+RESET)
            print(GREEN+"📌️ DEVELOPER: 𝐈𝐌 𝐂𝐎𝐎𝐋 𝐁𝐎𝐎𝐘 𝓢𝓱𝓪𝓭𝓸𝔀 𝓚𝓲𝓷𝓰"+RESET)
            sys.exit()
        else:
            print("❌ Invalid option.\n")

def main():
    run_cli()

if __name__=="__main__":
    main()
