from django.apps import AppConfig

class DjangoVladikSelect2Config(AppConfig):
    name = "django_vladik_select2"
    verbose_name = "Django Vladik Select2"


