default_app_config = "django_vladik_select2.apps.DjangoVladikSelect2Config"

