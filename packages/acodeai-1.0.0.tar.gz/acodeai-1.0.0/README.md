# 🐍 A-CodeAI Python SDK

**One-line installation for Korean Medicine Intelligence and Self-Evolving Memory**

---

## ⚡ Quick Start

### Installation

```bash
pip install acodeai
```

### Basic Usage

```python
from acodeai import JemaClient, AthenaClient

# Initialize clients
jema = JemaClient(api_key="your_api_key")
athena = AthenaClient(api_key="your_api_key")

# Analyze constitution (one line!)
result = jema.analyze_constitution(
    survey_answers=[{"question": "체질", "answer": "활발함"}]
)
print(f"Your constitution: {result.constitution}")

# Store memory (one line!)
memory = athena.store_memory(
    content="User prefers Python over JavaScript",
    category="preference"
)
print(f"Memory ID: {memory.memory_id}")

# Search memory (one line!)
results = athena.search_memory(
    query="What does the user prefer?",
    limit=5
)
print(f"Found {len(results)} memories")
```

---

## 📚 Full Documentation

- [API Reference](https://docs.mkmlife.com/sdk/python)
- [Examples](examples/)
- [Changelog](CHANGELOG.md)

---

**© 2025 MKM Lab. All rights reserved.**

