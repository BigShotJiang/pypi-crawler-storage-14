"""
Setup script for Jema AI & Athena AI Python SDK
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="acodeai",  # 변경: jema-ai → acodeai (브랜드 통일)
    version="1.0.0",
    author="MKM Lab",
    author_email="support@mkmlife.com",
    description="A-CodeAI SDK - Korean Medicine Intelligence & Self-Evolving Memory API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mkmlab-hq/acodeai-python",
    packages=find_packages(exclude=["examples", "tests", "docs", "*.tests", "*.tests.*", "tests.*"]),  # 불필요한 폴더 제외
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",  # 변경: MIT 라이선스
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.11",
    install_requires=[
        "requests>=2.28.0",  # 버전을 너무 타이트하게 잡지 않음 (충돌 방지)
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
        ],
    },
)

