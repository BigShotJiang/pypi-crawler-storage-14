"""
Athena AI Client

Python SDK for Athena API (Self-Evolving Memory).
"""
import requests
from typing import Dict, List, Any, Optional

class AthenaClient:
    """
    Athena AI Client
    
    One-line API access for Self-Evolving Memory.
    """
    
    def __init__(self, api_key: str, base_url: str = "https://api.mkmlife.com"):
        """
        Initialize Athena AI client
        
        Args:
            api_key: Your API key
            base_url: API base URL (default: https://api.mkmlife.com)
        """
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def store_memory(
        self,
        content: str,
        category: str = "general",
        tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Store memory (메모리 저장)
        
        Args:
            content: Memory content
            category: Memory category
            tags: Optional tags
        
        Returns:
            Storage result
        """
        url = f"{self.base_url}/api/v1/athena/memory/store"
        
        payload = {
            "content": content,
            "category": category
        }
        if tags:
            payload["tags"] = tags
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def search_memory(
        self,
        query: str,
        limit: int = 5,
        category: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Search memory (메모리 검색)
        
        Args:
            query: Search query
            limit: Maximum results
            category: Optional category filter
        
        Returns:
            Search results
        """
        url = f"{self.base_url}/api/v1/athena/memory/search"
        
        payload = {
            "query": query,
            "limit": limit
        }
        if category:
            payload["category"] = category
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def fusion_reasoning(
        self,
        query: str,
        limit: int = 10
    ) -> Dict[str, Any]:
        """
        Fusion reasoning (융합 추론)
        
        Args:
            query: Query
            limit: Maximum results
        
        Returns:
            Fusion reasoning result
        """
        url = f"{self.base_url}/api/v1/athena/memory/fusion-reasoning"
        
        payload = {
            "query": query,
            "limit": limit
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def recognize_pattern(
        self,
        task_description: str
    ) -> Dict[str, Any]:
        """
        Recognize pattern (패턴 인식)
        
        Args:
            task_description: Task description
        
        Returns:
            Pattern recognition result
        """
        url = f"{self.base_url}/api/v1/athena/pattern/recognize"
        
        payload = {"task_description": task_description}
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def tag_emotion(
        self,
        task: str,
        result: str,
        success: bool,
        unexpected: bool = False
    ) -> Dict[str, Any]:
        """
        Tag emotion (감정 태깅)
        
        Args:
            task: Task description
            result: Task result
            success: Success status
            unexpected: Unexpected result
        
        Returns:
            Emotion tagging result
        """
        url = f"{self.base_url}/api/v1/athena/emotion/tag"
        
        payload = {
            "task": task,
            "result": result,
            "success": success,
            "unexpected": unexpected
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()

