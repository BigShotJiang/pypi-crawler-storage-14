"""
Athena AI Python SDK

Self-Evolving Memory API client for Python.
"""
from .client import AthenaClient

__version__ = "1.0.0"
__all__ = ["AthenaClient"]

