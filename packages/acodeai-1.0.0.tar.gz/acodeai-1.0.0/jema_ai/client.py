"""
Jema AI Client

Python SDK for Jema API (Korean Medicine Intelligence).
"""
import requests
from typing import Dict, List, Any, Optional

class JemaClient:
    """
    Jema AI Client
    
    One-line API access for Korean Medicine Intelligence.
    """
    
    def __init__(self, api_key: str, base_url: str = "https://api.mkmlife.com"):
        """
        Initialize Jema AI client
        
        Args:
            api_key: Your API key
            base_url: API base URL (default: https://api.mkmlife.com)
        """
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def analyze_constitution(
        self,
        survey_answers: List[Dict[str, Any]],
        user_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyze constitution (사상체질 분석)
        
        Args:
            survey_answers: Survey answers
            user_data: Optional user data
        
        Returns:
            Analysis result
        """
        url = f"{self.base_url}/api/v1/jema/constitution/analyze"
        
        payload = {"survey_answers": survey_answers}
        if user_data:
            payload["user_data"] = user_data
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def recommend_food(
        self,
        constitution: str,
        health_condition: Optional[Dict[str, Any]] = None,
        preferences: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Recommend food (음식 추천)
        
        Args:
            constitution: User constitution
            health_condition: Optional health condition
            preferences: Optional food preferences
        
        Returns:
            Food recommendations
        """
        url = f"{self.base_url}/api/v1/jema/recommendations/food"
        
        payload = {"constitution": constitution}
        if health_condition:
            payload["health_condition"] = health_condition
        if preferences:
            payload["preferences"] = preferences
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def recommend_exercise(
        self,
        constitution: str,
        health_condition: Optional[Dict[str, Any]] = None,
        fitness_level: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Recommend exercise (운동 추천)
        
        Args:
            constitution: User constitution
            health_condition: Optional health condition
            fitness_level: Optional fitness level
        
        Returns:
            Exercise recommendations
        """
        url = f"{self.base_url}/api/v1/jema/recommendations/exercise"
        
        payload = {"constitution": constitution}
        if health_condition:
            payload["health_condition"] = health_condition
        if fitness_level:
            payload["fitness_level"] = fitness_level
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def analyze_health(
        self,
        user_data: Dict[str, Any],
        constitution: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Analyze health condition (건강 상태 분석)
        
        Args:
            user_data: User health data
            constitution: Optional constitution
        
        Returns:
            Health analysis result
        """
        url = f"{self.base_url}/api/v1/jema/health/analyze"
        
        payload = {"user_data": user_data}
        if constitution:
            payload["constitution"] = constitution
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    def check_medicine_interaction(
        self,
        medicines: List[str],
        constitution: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Check medicine interaction (약물 상호작용 체크)
        
        Args:
            medicines: List of medicine names
            constitution: Optional constitution
        
        Returns:
            Interaction check result
        """
        url = f"{self.base_url}/api/v1/jema/medicine/interaction-check"
        
        payload = {"medicines": medicines}
        if constitution:
            payload["constitution"] = constitution
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()

