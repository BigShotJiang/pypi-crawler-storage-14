from .tool import WebScrapingTool, ScrapingResult


__all__ = (
    "WebScrapingTool",
    "ScrapingResult",
)
