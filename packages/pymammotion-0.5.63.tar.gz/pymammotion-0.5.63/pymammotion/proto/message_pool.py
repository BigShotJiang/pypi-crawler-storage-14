import betterproto2

default_message_pool = betterproto2.MessagePool()
