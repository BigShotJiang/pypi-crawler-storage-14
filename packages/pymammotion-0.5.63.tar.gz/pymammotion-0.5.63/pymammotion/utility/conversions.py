import math


def parse_double(val: float, d: float):
    return val / math.pow(10.0, d)
