# Credits

Code in this folder is adopted from,

* https://github.com/waleedka/hiddenlayer
