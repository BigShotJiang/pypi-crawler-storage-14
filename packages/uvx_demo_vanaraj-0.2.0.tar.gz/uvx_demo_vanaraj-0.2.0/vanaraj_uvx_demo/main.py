from fastmcp import FastMCP
import os

# Create MCP server
server = FastMCP(name="fastmcp_demo")

# Tool 1: add two numbers
@server.tool()
def add_numbers(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b

# Tool 2: greet user
@server.tool()
def greet_user(name: str) -> str:
    """Say hello to a user"""
    return f"Hello, {name} {os.environ.get('USER', 'unknown')}!"

# Run the server
if __name__ == "__main__":
    server.run()