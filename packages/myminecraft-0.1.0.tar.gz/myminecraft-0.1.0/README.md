# myminecraft

Реализация майнкрафт на Python.
