import pyfiglet
import webbrowser
import os
import datetime

styles = """
body {
    background: linear-gradient(to bottom, #00f, #0ff);
    font-family: 'Comic Sans MS', cursive, sans-serif;
    text-align: center;
    padding: 50px;
}
p {
    background-color: #fff;
    color: #f00;
    border: 3px dashed #000;
    padding: 20px;
    font-size: 22px;
}"""




def minecraft():
    nname = input("Введите ваш ник для начала 'игры': ")
    s = pyfiglet.figlet_format("Sosal?")
    print(s)

    file_path = os.path.abspath("doc.html")

    # создаём HTML файл после ввода ника
    with open(file_path, "w", encoding="utf-8") as f:
        htm = f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <style>{styles}</style>
</head>
<body>
  <h1>сертификат</h1>
  <p>Официально подтверждается, что {nname} был затролен, ведь майнкрафт на Python реализовать невозможно. Также {nname} получает титул глупенького мальчугана.</p>
  <button>Дата выдачи : {datetime.datetime.now()}</button>
  <button>срок действия : всегда</button>
</body>
</html>"""
        f.write(htm)

    # открываем в браузере
    webbrowser.open(f"file://{file_path}")

if __name__ == "__main__":
    minecraft()

import pyfiglet
import webbrowser
import os
import datetime

styles = """
body {
    background: linear-gradient(to bottom, #00f, #0ff);
    font-family: 'Comic Sans MS', cursive, sans-serif;
    text-align: center;
    padding: 50px;
}
p {
    background-color: #fff;
    color: #f00;
    border: 3px dashed #000;
    padding: 20px;
    font-size: 22px;
}
button {
    margin: 10px;
    padding: 10px 20px;
    font-size: 18px;
}
"""

def minecraft():
    nname = input("Введите ваш ник для начала 'игры': ")
    s = pyfiglet.figlet_format("Sosal?")
    print(s)

    file_path = os.path.abspath("doc.html")
    date_now = datetime.datetime.now().strftime("%d.%m.%Y %H:%M")

    # создаём HTML файл после ввода ника
    with open(file_path, "w", encoding="utf-8") as f:
        htm = f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <style>{styles}</style>
</head>
<body>
  <h1>Сертификат</h1>
  <p>Официально подтверждается, что {nname} был затролен, ведь майнкрафт на Python реализовать невозможно. Также {nname} получает титул глупенького мальчугана.</p>
  <button>Дата выдачи: {date_now}</button>
  <button>Срок действия: всегда</button>
</body>
</html>"""
        f.write(htm)

    # открываем в браузере
    webbrowser.open(f"file://{file_path}")

if __name__ == "__main__":
    minecraft()
