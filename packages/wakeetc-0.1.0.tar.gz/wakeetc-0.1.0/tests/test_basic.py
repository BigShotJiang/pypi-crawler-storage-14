from wakeetc import keep_awake, allow_sleep
import time

def test_run():
    keep_awake()
    time.sleep(0.1)
    allow_sleep()

