import ctypes

ES_CONTINUOUS       = 0x80000000
ES_SYSTEM_REQUIRED  = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

def keep_awake(display: bool = True) -> None:
    flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED
    if display:
        flags |= ES_DISPLAY_REQUIRED

    result = ctypes.windll.kernel32.SetThreadExecutionState(flags)
    if result == 0:
        raise OSError("SetThreadExecutionState failed")


def allow_sleep() -> None:
    result = ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
    if result == 0:
        raise OSError("SetThreadExecutionState reset failed")
