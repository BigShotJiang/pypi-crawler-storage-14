
from .core import keep_awake, allow_sleep

__all__ = ["keep_awake", "allow_sleep"]
__version__ = "0.1.0"
