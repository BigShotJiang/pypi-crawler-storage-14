import argparse
import time
from datetime import datetime
from .core import keep_awake, allow_sleep


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Prevent Windows from sleeping (like caffeinate for macOS)"
    )
    parser.add_argument(
        "-t", "--time",
        type=int,
        default=0,
        help="Time in seconds to stay awake (0 = infinite until Ctrl+C).",
    )
    parser.add_argument(
        "--no-display",
        action="store_true",
        help="Don't keep the display awake, only the system.",
    )
    args = parser.parse_args()

    print(f"[wakeetc] START at {datetime.now().strftime('%H:%M:%S')}")

    keep_awake(display=not args.no_display)

    if args.time > 0:
        print(f"[wakeetc] Keeping system awake for {args.time} seconds...")
    else:
        print("[wakeetc] Keeping system awake until you press Ctrl+C...")

    try:
        if args.time > 0:
            time.sleep(args.time)
        else:
            while True:
                time.sleep(60)
    except KeyboardInterrupt:
        print("\n[wakeetc] Stopped by user (Ctrl+C).")
    finally:
        allow_sleep()
        print(f"[wakeetc] END at {datetime.now().strftime('%H:%M:%S')}")
        print("[wakeetc] Sleep behavior restored.")
