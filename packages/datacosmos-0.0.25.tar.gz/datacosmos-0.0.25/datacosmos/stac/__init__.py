"""STAC package for interacting with the STAC API, providing query and fetch functionalities.

It enables interaction with STAC (SpatioTemporal Asset Catalog) services
using an authenticated Datacosmos client.
"""
