"""STAC package for interacting with items from the STAC API, providing query and fetch functionalities.

It enables interaction with items from the STAC using an authenticated Datacosmos client.
"""
