"""Models for validation of API response."""
