def abstract_ai_gui():
    from .gpt_classes.gpt_manager import GptManager
    GptManager()
