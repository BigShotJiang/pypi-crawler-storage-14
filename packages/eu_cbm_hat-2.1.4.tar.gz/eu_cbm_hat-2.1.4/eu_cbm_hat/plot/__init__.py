#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Visualize the output of the EU Carbon Budget Model.
"""
