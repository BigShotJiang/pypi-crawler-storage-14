"""Tools that prepare data on classifiers, change column order or reshape data.
"""
