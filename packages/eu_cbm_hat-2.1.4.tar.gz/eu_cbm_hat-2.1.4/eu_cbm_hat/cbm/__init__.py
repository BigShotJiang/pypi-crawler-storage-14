"""Objects that permit an interaction with CBM within the time loop."""
