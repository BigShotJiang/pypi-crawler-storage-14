"""Define associations for administrative boundaries, ecological boundaries,
tree species and disturbances. Prepare these into the JSON file format used by
libcbm."""
