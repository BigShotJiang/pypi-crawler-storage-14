"""Typing stubs for VapourSynth."""

from .cli import __version__
from .func import output_stubs

__all__ = ["__version__", "output_stubs"]
