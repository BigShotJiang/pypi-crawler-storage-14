"""Init command for creating new storyboard projects."""

import os
import shutil
from pathlib import Path

from rich.console import Console
from rich.prompt import Prompt

console = Console()


def init_command(args):
    project_name = args.name

    if not project_name:
        project_name = Prompt.ask("Enter project name")

    if not project_name or not project_name.strip():
        console.print("[red]Error: Project name cannot be empty[/red]")
        return 1

    project_name = project_name.strip()
    target_dir = Path.cwd() / project_name

    if target_dir.exists():
        console.print(f"[red]Error: Directory '{project_name}' already exists[/red]")
        return 1

    example_dir = Path(__file__).parent.parent.parent.parent / "example"

    if not example_dir.exists():
        console.print(f"[red]Error: Example directory not found at {example_dir}[/red]")
        return 1

    try:
        console.print(f"Creating project '{project_name}'...")

        shutil.copytree(
            example_dir,
            target_dir,
            ignore=shutil.ignore_patterns("output", ".DS_Store", "__pycache__", "*.pyc")
        )

        console.print(f"[green]✓[/green] Project '{project_name}' created successfully!")
        console.print(f"\nNext steps:")
        console.print(f"  1. cd {project_name}")
        console.print(f"  2. cp .env.example .env")
        console.print(f"  3. Edit .env and add your GEMINI_API_KEY")
        console.print(f"  4. Run: storyboard run --input content/main.yaml")

        return 0

    except Exception as e:
        console.print(f"[red]Error creating project: {e}[/red]")
        if target_dir.exists():
            shutil.rmtree(target_dir)
        return 1
