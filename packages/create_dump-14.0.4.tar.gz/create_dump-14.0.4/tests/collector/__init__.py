# tests/collector/__init__.py

