from .md2data import *

__doc__ = md2data.__doc__
if hasattr(md2data, "__all__"):
    __all__ = md2data.__all__