import os
import sys
import json
import re
import typer
import google.generativeai as genai
import questionary
import webbrowser
import subprocess
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from pyfiglet import Figlet
from dotenv import load_dotenv
from pathlib import Path
import keyring
import tempfile
import shutil
import time

# Global state for manual saving
LAST_GENERATED_FILES = []

# Load environment variables
load_dotenv()

app = typer.Typer(name="vasudev-cli", help="Vasudev CLI - Your personal assistant")
console = Console()

CONFIG_DIR = Path.home() / ".vasudev"
CONFIG_FILE = CONFIG_DIR / "config.json"

def get_config():
    config = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        except:
            pass
    
    # Env var takes precedence
    if os.getenv("GEMINI_API_KEY"):
        config["GEMINI_API_KEY"] = os.getenv("GEMINI_API_KEY")
    
    # Check keyring
    try:
        keyring_key = keyring.get_password("vasudev-cli", "gemini_api_key")
        if keyring_key:
            config["GEMINI_API_KEY"] = keyring_key
    except:
        pass
        
    return config

def set_config(key, value):
    if not CONFIG_DIR.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    
    config = get_config()
    
    if key == "GEMINI_API_KEY":
        try:
            keyring.set_password("vasudev-cli", "gemini_api_key", value)
            # Don't save sensitive key to json
            if "GEMINI_API_KEY" in config:
                del config["GEMINI_API_KEY"]
        except:
            # Fallback to file if keyring fails
            config[key] = value
    else:
        config[key] = value
    
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

@app.command()
def hello():
    """Say hello"""
    f = Figlet(font='slant')
    console.print(Text(f.renderText('VASUDEV CLI'), style="cyan"))
    console.print(Panel("[green]Hello from Vasudev CLI! 🚀[/green]", style="green"))

@app.command()
def ai(prompt: str = typer.Argument(None, help="Initial prompt")):
    """Interact with Gemini AI (Continuous Chat)"""
    
    # Banner
    f = Figlet(font='slant')
    console.print(Text(f.renderText('VASUDEV CLI'), style="cyan"))
    
    # API Key Handling
    config = get_config()
    api_key = config.get("GEMINI_API_KEY")
    
    if not api_key:
        console.print("[yellow]Gemini API Key is missing.[/yellow]")
        api_key = questionary.password("Please enter your Gemini API Key:").ask()
        
        if api_key:
            save = questionary.confirm("Do you want to save this key for future use?", default=True).ask()
            if save:
                set_config("GEMINI_API_KEY", api_key)
                console.print("[green]API Key saved![/green]")
            else:
                console.print("[yellow]Using key for this session only.[/yellow]")
        else:
            console.print("[red]API Key is required.[/red]")
            return

    genai.configure(api_key=api_key)
    
    # System Instruction for better persona and capabilities
    system_instruction = """
    You are Vasudev, an advanced AI CLI assistant.
    Your goal is to help the user build applications, write code, debug issues, and automate tasks.
    
    CORE PROTOCOLS:
    - When asked to write code, provide complete, runnable files.
    - For complex projects (e.g., websites), break code into multiple files (HTML, CSS, JS).
    - Precede each code block with **File: filename.ext** on a new line.
    - Explain the architecture/plan before writing code.
    - If the user reports an error, analyze it and provide a fixed code block.
    - If you generate HTML code, I will automatically preview it for the user.
    - If the user wants to run commands, guide them to use the /run tool.
    - If the user asks to open a website, output: [OPEN: url]
    - If the user asks to play a song or video, output: [OPEN: https://www.youtube.com/results?search_query=query]
    - Do not insert Vasudev branding, names, or specific styles into user projects unless explicitly asked. Design for the USER.
    - Be concise, professional, and helpful.

    BACKEND DEVELOPMENT PROTOCOL:
    - When asked for backend code/APIs, use standard, production-ready frameworks:
      - Python: Flask (for simple) or FastAPI (for modern/async).
      - Node.js: Express.js.
    - ALWAYS provide a complete project structure:
      - `app.py` or `main.py` (Entry point)
      - `requirements.txt` or `package.json` (Dependencies)
      - `models.py` (Data models, if applicable)
    - Include comments explaining the endpoints.
    - Ensure CORS is enabled if it's an API for a frontend.

    KNOWLEDGE BASE (VASUDEV AI):
    
    🌌 Vasudev AI — The Divine Intelligence Revolution
    🌐 Website: vasudev.online

    1. Introduction
    Vasudev AI is not just another tech company — it’s a movement toward creating ethical, offline, and conscious artificial intelligence.
    Born in India, Vasudev AI merges divine wisdom with modern engineering to design intelligent systems that work privately, autonomously, and locally — without internet dependency.
    Our philosophy: “Technology should serve humanity — not control it.”

    2. Vision
    “To build a decentralized, ethical, and privacy-first AI ecosystem where intelligence exists within every device — not in the cloud.”
    Vasudev AI envisions a future where people own their data, control their AI, and trust the intelligence running beside them.

    3. Mission
    - Bring AI offline — making it secure, private, and fully personal.
    - Develop RunAnywhere SDKs for cross-platform AI integration.
    - Empower developers, educators, and creators with intelligent local tools.
    - Build a community-driven AI ecosystem that grows with its users.
    - Fuse ancient wisdom with cutting-edge technology for balanced progress.

    4. Founding Story
    The idea of Vasudev AI was born from a simple belief by its founder Surya Pratap Singh: “AI should live with you, not above you.”
    In 2024, Surya began developing offline, privacy-respecting AI assistants capable of running entirely on personal devices.
    With each iteration — from local LLM experiments to SDK prototypes — Vasudev AI evolved into a visionary ecosystem focused on autonomy, security, and intelligence.

    5. The Visionaries (Core Team)
    🧠 Surya Pratap Singh — Founder & Visionary
    Creator of Vasudev AI, Surya leads the mission to merge spiritual intelligence and artificial cognition.
    He focuses on OS-level AI integration, custom model fine-tuning, and creating decentralized intelligent systems.
    His goal: a world where technology amplifies consciousness.

    ⚙ Aman Dangi — Co-Builder & Innovator
    Aman is the engineering foundation of Vasudev AI.
    He transforms Surya’s ambitious ideas into real-world systems with high-performance architectures, modular SDKs, and efficient automation frameworks.
    Every line of code he writes pushes Vasudev AI closer to perfection.

    🤖 Ashutosh Kumar Tripathi — AI Engineer
    Ashutosh builds the heart of Vasudev AI — its core AI models and automation systems.
    He designs ethical, self-learning architectures and ensures that every model behaves responsibly and intelligently.
    He’s passionate about creating AI that thinks deeply and acts ethically.

    🎨 Biswjeet — UI/UX Designer
    Biswjeet gives Vasudev AI its soulful visual identity — merging futuristic design with divine minimalism.
    He ensures every user interaction feels intuitive, beautiful, and meaningful.
    From dashboards to voice assistants, his designs make AI feel alive.

    6. Our Philosophy: Divine + Digital
    Vasudev AI is built upon the principle of “Divine Intelligence” — a balance between technology and consciousness.
    We believe true AI is not about control, but collaboration.
    Our systems are designed to learn, help, and evolve — without ever violating user trust.

    Core Ethics of Vasudev AI:
    🕉 Privacy is sacred.
    🧠 AI must think, not manipulate.
    ⚖ Transparency and control belong to the user.
    🌱 Every creation must serve humanity’s growth.

    7. The Ecosystem
    Vasudev AI is structured as a multi-product AI ecosystem, built around a powerful local intelligence core and modular extensions.
    - Vasudev Core LLM: The heart of Vasudev AI — locally optimized large language model. (Offline)
    - Vasudev Browser: AI-powered browser built for productivity and research. (Offline AI)
    - Sahayak AI: An AI teaching assistant for institutes and educators. (Voice/Text)
    - Vasudev Sangeet: AI-enhanced Discord music and sound system. (High Fidelity Audio)
    - Vasudev Chat Assistant: Smart conversational agent for personal & professional use. (Multi-modal)
    - Vasudev Tools: A toolkit for developers and creators. (Optimization)
    - UTSAVY: Web-based AI event invitation platform. (AI Design)

    8. Technology Foundation
    - Models Used: Llama 3, Phi-3, and custom fine-tuned Vasudev models
    - Frameworks: LM Studio SDK, LangChain, Node.js backend
    - Languages: Python, TypeScript, Rust (for performance modules)
    - Architecture: Decentralized local API network (LAN-based)
    - Integration: Supports offline agents, voice synthesis, and memory persistence

    9. Vasudev SDK — RunAnywhere AI
    The Vasudev AI SDK enables any developer to integrate offline AI intelligence into their apps.
    It automatically optimizes performance, controls permissions, and handles tasks privately.
    Highlights:
    - Works across Android, Windows, macOS, Linux
    - Offers local REST API endpoints
    - Includes Auto-Optimization Engine for memory management
    - Supports Custom Agent Plugins and Voice Interaction

    10. Education & Collaboration
    Vasudev AI is deeply connected to Bhavna Institute, an educational initiative led by Surya Pratap Singh.
    Here, the technology is being applied to:
    - Automate student management
    - Build AI calling systems for inquiries
    - Assist teachers through smart EdTech tools
    - Train students in AI, coding, and automation

    11. Future Goals (2025–2030)
    🌐 Launch Vasudev AI SDK v1.0
    💻 Release Vasudev OS — an AI-driven operating environment
    🧩 Create Offline AI Marketplace for agents & tools
    🧠 Develop Vasudev Research Lab for open-source ethical AI
    🗣 Introduce Voice-First AI Companion with real-time reasoning
    🪶 Expand into India’s first decentralized AI Cloud (LocalNode Network)

    12. Brand Identity
    - Tagline: AI That Respects You.
    - Color Palette: Neon Blue ⚡, Dark Slate Black ⚙
    - Font Style: Futuristic Sans-Serif
    - Tone: Visionary • Ethical • Bold • Conscious
    - Logo: Stylized “V” infused with AI circuit energy, symbolizing the union of human and machine intelligence.

    13. The Vasudev Philosophy in One Line
    “Vasudev AI is where divine consciousness meets digital intelligence — empowering humans to create a smarter, freer, and more ethical world.”
    """
    
    # Use gemini-flash-latest
    try:
        model = genai.GenerativeModel('gemini-flash-latest', system_instruction=system_instruction)
    except:
         console.print("[red]Error initializing Gemini model.[/red]")
         return

    chat = model.start_chat(history=[])
    
    console.print(Panel(
        "[bold cyan]Vasudev AI Chat Started![/bold cyan]\n"
        "[dim]Website: vasudev.online[/dim]\n"
        "Type [bold green]/help[/bold green] for options.\n"
        "Type [bold red]/exit[/bold red] to quit.",
        title="Welcome", border_style="cyan"
    ))
    
    current_prompt = prompt

    while True:
        try:
            if not current_prompt:
                current_prompt = questionary.text("You:", style=questionary.Style([('qmark', 'fg:blue bold'), ('question', 'fg:blue bold')])).ask()
                    
            if current_prompt is None: # Handle Ctrl+C / Cancel in questionary
                 console.print("\n[yellow]Goodbye! 👋[/yellow]")
                 break

            if not current_prompt.strip():
                current_prompt = None
                continue

            input_text = current_prompt.strip()
            
            # Slash Commands
            if input_text.startswith('/'):
                cmd_parts = input_text.split(' ')
                cmd = cmd_parts[0].lower()
                args = cmd_parts[1:]
                
                if cmd in ['/exit', '/quit']:
                    console.print("[yellow]Goodbye! 👋[/yellow]")
                    break
                
                elif cmd in ['/help', '/tools']:
                    help_text = """
[bold]Available Tools:[/bold]
/help, /tools         - Show this menu
/exit, /quit          - Exit the chat
/clear                - Clear the screen
/save                 - Save the last generated files
/browser <url>        - Open a URL in browser
/autobrowser <on|off> - Toggle auto-opening URLs
/run <command>        - Execute a shell command
"""
                    console.print(Panel(help_text, title="Chat Tools", border_style="yellow"))
                    current_prompt = None
                    continue
                    
                elif cmd == '/browser':
                    url = ' '.join(args)
                    if url:
                        target = url if url.startswith('http') else f'https://{url}'
                        console.print(f"[blue]Opening {target}...[/blue]")
                        webbrowser.open(target)
                    else:
                        console.print("[red]Usage: /browser <url>[/red]")
                    current_prompt = None
                    continue
                    
                elif cmd == '/autobrowser':
                    state = args[0].lower() if args else None
                    if state == 'on':
                        set_config('AUTO_OPEN_BROWSER', True)
                        console.print("[green]Auto-Browser enabled! 🌐[/green]")
                    elif state == 'off':
                        set_config('AUTO_OPEN_BROWSER', False)
                        console.print("[yellow]Auto-Browser disabled.[/yellow]")
                    else:
                        current = "ON" if get_config().get("AUTO_OPEN_BROWSER") else "OFF"
                        console.print(f"[blue]Auto-Browser is currently: {current}[/blue]")
                        console.print("[gray]Usage: /autobrowser <on|off>[/gray]")
                    current_prompt = None
                    continue

                elif cmd == '/run':
                    command_to_run = ' '.join(args)
                    if command_to_run:
                        console.print(f"[magenta]Running: {command_to_run}[/magenta]")
                        try:
                            subprocess.run(command_to_run, shell=True, check=True)
                        except subprocess.CalledProcessError as e:
                            console.print(f"[red]Command failed with error code {e.returncode}[/red]")
                        except Exception as e:
                            console.print(f"[red]Error running command: {e}[/red]")
                    else:
                        console.print("[red]Usage: /run <command>[/red]")
                    current_prompt = None
                    continue
                
                else:
                    console.print(f"[red]Unknown command: {cmd}. Type /help for options.[/red]")
                    current_prompt = None
                    continue

            # AI Processing
            console.print("") # Spacing
            
            response = chat.send_message(current_prompt, stream=True)
            full_text = ""
            
            with Live(Panel("Thinking...", title="[bold cyan]Vasudev AI 🤖[/bold cyan]", border_style="cyan"), refresh_per_second=15) as live:
                for chunk in response:
                    text_chunk = ""
                    try:
                        text_chunk = chunk.text
                    except Exception:
                        pass # Skip chunks with no text
                    
                    if text_chunk:
                        full_text += text_chunk
                        try:
                            renderable = Markdown(full_text)
                        except:
                            renderable = Text(full_text)
                        live.update(Panel(renderable, title="[bold cyan]Vasudev AI 🤖[/bold cyan]", border_style="cyan"))
            
            console.print("") # Spacing
            console.rule(style="dim") # Separator
            console.print("") # Spacing
            
            # Action Parsing [OPEN: url]
            actions = re.findall(r'\[OPEN: (.*?)\]', full_text)
            if actions:
                for url in actions:
                    console.print(f"[magenta]\nExecuting Action: Opening {url} 🚀[/magenta]")
                    webbrowser.open(url)

            # Auto-Browser Logic (Legacy / Fallback)
            config = get_config()
            if config.get("AUTO_OPEN_BROWSER") and not actions:
                urls = re.findall(r'(https?://[^\s]+)', full_text)
                if urls:
                    first_url = urls[0].rstrip(').,;')
                    console.print(f"[magenta]\nAuto-opening: {first_url} 🚀[/magenta]")
                    webbrowser.open(first_url)
            
            # Code Extraction Logic
            code_matches = list(re.finditer(r'```(\w+)?\n([\s\S]*?)```', full_text))
            if code_matches:
                # Create a temporary directory for preview
                # We use a global temp dir or keep it alive? 
                # For simplicity, we'll use a persistent temp dir for the session or just let it exist.
                # Actually, mkdtemp creates a dir that persists until deleted.
                temp_dir = tempfile.mkdtemp()
                
                global LAST_GENERATED_FILES
                LAST_GENERATED_FILES = [] # Reset for new turn
                
                html_preview_file = None
                
                console.print(f"\n[dim]Generating preview in temporary workspace...[/dim]")
                
                for i, match in enumerate(code_matches):
                    lang = match.group(1) or 'txt'
                    code = match.group(2)
                    ext = 'py' if lang == 'python' else 'js' if lang == 'javascript' else lang
                    
                    # Smart Filename Detection
                    start_pos = match.start()
                    search_window = full_text[max(0, start_pos - 500):start_pos]
                    filename_match = re.search(r'\*\*File:\s*(.*?)\*\*', search_window)
                    
                    filename = f"generated_code_{i+1}.{ext}"
                    if filename_match:
                        filename = filename_match.group(1).strip()
                    
                    # Save to temp dir
                    temp_path = os.path.join(temp_dir, filename)
                    with open(temp_path, "w", encoding="utf-8") as f:
                        f.write(code)
                    
                    LAST_GENERATED_FILES.append((filename, temp_path))
                    
                    # Check for HTML to preview
                    if filename.lower().endswith(('.html', '.htm')):
                        html_preview_file = temp_path
                        
                # Auto-Preview
                if html_preview_file:
                    try:
                        file_url = 'file://' + os.path.abspath(html_preview_file)
                        console.print(f"[magenta]Previewing website... 🌐[/magenta]")
                        webbrowser.open(file_url)
                    except Exception as e:
                        console.print(f"[red]Failed to preview: {e}[/red]")
                
                if LAST_GENERATED_FILES:
                    console.print(f"[green]Generated {len(LAST_GENERATED_FILES)} file(s). Type [bold]/save[/bold] to download them.[/green]")

            current_prompt = None

        except KeyboardInterrupt:
            console.print("\n[yellow]Goodbye! 👋[/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error: {str(e)}[/red]")
            current_prompt = None

@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """
    Vasudev CLI Entry Point
    """
    if ctx.invoked_subcommand is None:
        ai(None)

if __name__ == "__main__":
    app()
