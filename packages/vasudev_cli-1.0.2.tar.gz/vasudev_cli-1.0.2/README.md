# Vasudev CLI 🚀

Vasudev CLI is your personal AI assistant in the terminal. It helps you write code, build applications, automate tasks, and control your browser using natural language.

## Features ✨

-   **AI Chat**: Powered by Google Gemini (Flash 1.5).
-   **Natural Language Actions**:
    -   "Open Google" -> Opens browser.
    -   "Play Believer" -> Plays song on YouTube.
-   **Shell Execution**: Run commands directly via `/run <command>`.
-   **Code Writer**: Automatically detects and saves code blocks.
-   **Auto-Browser**: Toggle automatic URL opening with `/autobrowser on`.

## Installation 🛠️

### Option 1: Easy Install (Windows) - Recommended ⚡
1.  Download the project folder.
2.  Double-click **`install_win.bat`**.
3.  Wait for it to finish. It will install the CLI and fix your PATH automatically.

### Option 2: Manual Install
You can install Vasudev CLI via pip:

```bash
pip install vasudev-cli
```

Or if you are installing from source:

```bash
git clone https://github.com/yourusername/vasudev-cli.git
cd vasudev-cli
pip install .
```

## Usage 🚀

Once installed, you can run Vasudev from **any terminal** (CMD, PowerShell, Git Bash) using:

```bash
vasudev
# OR
vc
```

### First Run
On the first run, the CLI will ask for your **Gemini API Key**.
-   It will securely save it to `~/.vasudev/config.json`.
-   You can get a key from [Google AI Studio](https://aistudio.google.com/).

### Commands
-   **Chat**: Just type your message!
-   `/help`: Show available tools.
-   `/run <cmd>`: Execute a shell command (e.g., `/run dir`).
-   `/exit`: Quit the CLI.

## Project Structure 📂

-   `src/main.py`: Main source code.
-   `vc.bat`: Launcher script.
-   `requirements.txt`: Python dependencies.

---
*Built with ❤️ by Vasudev AI*
