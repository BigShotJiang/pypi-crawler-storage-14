"""
iq devcontainer command - Create DevContainer configuration.
"""

from __future__ import annotations

from pathlib import Path

import click

from iq_sdk.cli import (
    console,
    copy_template_dir,
)


@click.command()
@click.option("--output", "-o", default=".devcontainer", help="Output directory")
def devcontainer(output: str) -> None:
    """Create DevContainer configuration."""
    output_path = Path(output)

    if output_path.exists():
        if not click.confirm(f"Directory {output_path} exists. Overwrite?"):
            raise click.Abort()

    context = {"name": Path.cwd().name}
    copy_template_dir("devcontainer", output_path, context)

    console.print(f"[bold green]✓ DevContainer created in {output_path}[/bold green]")
