"""
iq worker commands - Manage workers (tool runtime).

A "worker" is the runtime process that executes tools. Each tool runs as a
child process with configurable threads. The worker connects to sites and
listens on tool queues for incoming tasks.
"""

from __future__ import annotations

import asyncio
import importlib.util
import sys
from pathlib import Path

import click
from rich.table import Table

from iq_sdk.cli import console
from iq_sdk.config import load_settings


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
def worker() -> None:
    """Manage workers (tool runtime)."""
    pass


@worker.command("list")
@click.option("--site", "-s", "site_id", help="Filter by site ID")
@click.option("--config", "-c", "config_file", help="Config file path")
@click.option("--check", is_flag=True, help="Check tool availability on hosts")
@click.pass_context
def worker_list(
    ctx: click.Context,
    site_id: str | None,
    config_file: str | None,
    check: bool,
) -> None:
    """
    List configured workers/tools.

    Shows all tools configured across sites with their queue names.
    Use --check to verify tool availability on remote hosts.
    """
    if config_file is None:
        config_file = ctx.obj.get("config_file")

    settings = load_settings(config_file)

    # Filter sites
    if site_id:
        sites = settings.get_sites([site_id])
        if not sites:
            console.print(f"[red]Site '{site_id}' not found[/red]")
            sys.exit(1)
    else:
        sites = settings.get_sites()

    # Gather check results if needed
    check_results = {}
    if check:
        check_results = _check_tools_on_sites(sites)

    # Build table
    table = Table(title="Configured Tools/Workers")
    table.add_column("Site", style="cyan")
    table.add_column("Tool", style="green")
    table.add_column("Queue", style="yellow")
    table.add_column("Threads")
    table.add_column("Enabled")

    if check:
        table.add_column("On Host")
        table.add_column("Signature")

    worker_id = settings.get_worker_id()

    for site in sites:
        tools = site.get_tools()
        is_default = " (default)" if site.id == settings.site.id else ""

        if not tools:
            row = [
                f"{site.id}{is_default}",
                "[dim]No tools configured[/dim]",
                "-",
                "-",
                "-",
            ]
            if check:
                row.extend(["-", "-"])
            table.add_row(*row)
            continue

        for i, tool in enumerate(tools):
            site_label = f"{site.id}{is_default}" if i == 0 else ""

            enabled = "[green]✓[/green]" if tool.enabled else "[red]✗[/red]"

            # Use site-specific threads or default
            threads = tool.threads or site.threads or settings.worker.threads

            row = [
                site_label,
                tool.name,
                tool.get_queue(),
                str(threads),
                enabled,
            ]

            if check:
                result = check_results.get((site.id, tool.name), {})
                on_host = "[green]✓[/green]" if result.get("exists") else "[red]✗[/red]"
                sig_match = (
                    "[green]✓[/green]" if result.get("signature_match") else "[yellow]?[/yellow]"
                )
                row.extend([on_host, sig_match])

            table.add_row(*row)

    console.print(table)
    console.print(f"\n[dim]Worker ID: {worker_id}[/dim]")


def _check_tools_on_sites(sites: list) -> dict:
    """Check tool availability on sites."""
    from iq_sdk.client import IQHttpClient

    results = {}

    async def _check():
        for site in sites:
            try:
                async with IQHttpClient(
                    site.get_host(),
                    api_key=site.get_api_key(),
                    api_secret=site.load_api_secret(),
                    timeout=5.0,
                ) as client:
                    remote_tools = await client.list_tools()
                    remote_by_name = {t.name: t for t in remote_tools}

                    for tool in site.get_tools():
                        remote = remote_by_name.get(tool.name)
                        results[(site.id, tool.name)] = {
                            "exists": remote is not None,
                            "signature_match": True,  # TODO: implement signature check
                            "remote_workers": remote.worker_count if remote else 0,
                        }
            except Exception as e:
                for tool in site.get_tools():
                    results[(site.id, tool.name)] = {
                        "exists": False,
                        "signature_match": False,
                        "error": str(e)[:30],
                    }

    try:
        asyncio.run(_check())
    except Exception:
        pass

    return results


@worker.command("start")
@click.option(
    "--site", "-s", "site_ids", multiple=True, help="Sites to connect to (can be repeated)"
)
@click.option(
    "--tool",
    "-t",
    "tool_names",
    multiple=True,
    help="Specific tools to run (default: all configured)",
)
@click.option("--threads", type=int, help="Override threads per tool")
@click.option("--max-threads", type=int, help="Maximum threads for autoscaling")
@click.option("--autoscale", is_flag=True, help="Enable autoscaling")
@click.option("--config", "-c", "config_file", help="Config file path")
@click.option("--worker-id", "worker_id_override", help="Override worker ID")
@click.pass_context
def worker_start(
    ctx: click.Context,
    site_ids: tuple,
    tool_names: tuple,
    threads: int | None,
    max_threads: int | None,
    autoscale: bool,
    config_file: str | None,
    worker_id_override: str | None,
) -> None:
    """
    Start worker process.

    Connects to configured sites and starts tool processes.
    Each tool runs as a child process listening on its queue.
    """
    if config_file is None:
        config_file = ctx.obj.get("config_file")

    # Build overrides from CLI options
    overrides: dict = {}

    if threads:
        overrides.setdefault("worker", {})["threads"] = threads
    if max_threads:
        overrides.setdefault("worker", {})["max_threads"] = max_threads
    if autoscale:
        overrides.setdefault("worker", {})["autoscale"] = True
    if worker_id_override:
        overrides["worker_id"] = worker_id_override

    # Load settings
    settings = load_settings(config_file, overrides)

    # Get target sites
    if site_ids:
        target_sites = settings.get_sites(list(site_ids))
    else:
        target_sites = settings.get_sites()

    if not target_sites:
        console.print("[red]No sites configured[/red]")
        sys.exit(1)

    worker_id = settings.get_worker_id()

    console.print(f"[bold blue]Starting worker '{worker_id}'[/bold blue]")

    # Collect tools to run
    tools_to_run = []
    for site in target_sites:
        site_tools = site.get_tools()

        # Filter by tool names if specified
        if tool_names:
            site_tools = [t for t in site_tools if t.name in tool_names]

        # Filter to enabled tools
        site_tools = [t for t in site_tools if t.enabled]

        for tool in site_tools:
            tools_to_run.append((site, tool))

    if not tools_to_run:
        console.print("[yellow]No tools to run[/yellow]")
        if tool_names:
            console.print(f"[dim]Requested tools: {', '.join(tool_names)}[/dim]")
        sys.exit(1)

    console.print(f"  Worker ID: {worker_id}")
    console.print(f"  Sites: {len(target_sites)}")
    console.print(f"  Tools: {len(tools_to_run)}")

    for site, tool in tools_to_run:
        tool_threads = tool.threads or site.threads or settings.worker.threads
        console.print(
            f"    → {site.id}/{tool.name} (queue:{tool.get_queue()}, threads:{tool_threads})"
        )

    if settings.worker.autoscale:
        console.print(f"  Autoscale: {settings.worker.min_threads}-{settings.worker.max_threads}")

    # Load and validate tools
    tools_path = Path(settings.tools_dir)
    loaded_tools = []

    for site, tool_config in tools_to_run:
        tool_dir = tools_path / tool_config.name
        if not tool_dir.exists():
            console.print(
                f"[yellow]Warning: Tool '{tool_config.name}' not found in {tools_path}[/yellow]"
            )
            continue

        # Try to import tool
        try:
            tool_module_path = tool_dir / "tool.py"
            if tool_module_path.exists():
                tool_spec = importlib.util.spec_from_file_location(
                    f"tools.{tool_config.name}.tool", tool_module_path
                )
                if tool_spec and tool_spec.loader:
                    tool_module = importlib.util.module_from_spec(tool_spec)
                    tool_spec.loader.exec_module(tool_module)

                    # Find tool class
                    from iq_sdk.tool import BaseTool

                    for _attr_name, obj in vars(tool_module).items():
                        if (
                            isinstance(obj, type)
                            and issubclass(obj, BaseTool)
                            and obj is not BaseTool
                        ):
                            loaded_tools.append((site, tool_config, obj))
                            break
        except Exception as e:
            console.print(
                f"[yellow]Warning: Failed to load tool '{tool_config.name}': {e}[/yellow]"
            )

    if not loaded_tools:
        console.print("[red]No tools could be loaded[/red]")
        sys.exit(1)

    console.print(f"\n[green]Loaded {len(loaded_tools)} tools[/green]")

    # Run worker
    try:
        asyncio.run(_run_worker(settings, loaded_tools))
    except KeyboardInterrupt:
        console.print("\n[yellow]Worker stopped by user[/yellow]")


async def _run_worker(settings, loaded_tools: list) -> None:
    """Run the worker process."""
    from iq_sdk.client import IQConnection

    worker_id = settings.get_worker_id()

    # Group tools by site
    tools_by_site: dict = {}
    for site, tool_config, tool_class in loaded_tools:
        if site.id not in tools_by_site:
            tools_by_site[site.id] = {
                "site": site,
                "tools": [],
            }
        tools_by_site[site.id]["tools"].append((tool_config, tool_class))

    # Create connections for each site
    connections = []
    for _site_id, site_data in tools_by_site.items():
        site = site_data["site"]
        tools = site_data["tools"]

        conn = IQConnection(
            host=site.get_host(),
            worker_id=worker_id,
            api_key=site.get_api_key(),
            api_secret=site.load_api_secret(),
            reconnect=site.reconnect,
            reconnect_attempts=site.reconnect_attempts,
        )

        connections.append((conn, site, tools))

    # Connect and register
    for conn, site, tools in connections:
        console.print(f"[dim]Connecting to {site.id}...[/dim]")

        if await conn.connect():
            tool_names = [t[0].name for t in tools]
            queues = [t[0].get_queue() for t in tools]

            await conn.register_worker(tool_names, queues)
            console.print(f"[green]Connected to {site.id}[/green]")

            # Register task handlers
            for tool_config, tool_class in tools:
                instance = tool_class()
                conn.on_task(tool_config.name, instance.execute)
        else:
            console.print(f"[red]Failed to connect to {site.id}: {conn.state.error}[/red]")

    # Wait for tasks
    console.print("\n[bold]Waiting for tasks... (Ctrl+C to stop)[/bold]")

    try:
        await asyncio.gather(*[conn.wait_for_tasks() for conn, _, _ in connections])
    finally:
        for conn, _, _ in connections:
            await conn.disconnect()
