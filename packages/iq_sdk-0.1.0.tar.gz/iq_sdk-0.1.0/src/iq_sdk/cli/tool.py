"""
iq tool commands - Manage tools.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click
from rich.prompt import Confirm, Prompt
from rich.table import Table

from iq_sdk.cli import console
from iq_sdk.config import load_settings
from iq_sdk.properties import ExposureCategory

# ============================================================================
# DATA STRUCTURES
# ============================================================================


@dataclass
class ToolVersion:
    """Represents a tool version."""

    major: int
    minor: int

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}"

    @property
    def file_suffix(self) -> str:
        return f"{self.major}_{self.minor}"

    @classmethod
    def parse(cls, s: str) -> ToolVersion:
        """Parse version from string like '1.0' or '1_0'."""
        s = s.replace("_", ".")
        parts = s.split(".")
        return cls(major=int(parts[0]), minor=int(parts[1]) if len(parts) > 1 else 0)


@dataclass
class PropertyDef:
    """Property definition collected from user input."""

    name: str
    label: str
    data_type: str
    required: bool
    default: Any
    python_type: str = ""

    def __post_init__(self):
        # Map data_type to Python type string
        type_mapping = {
            "str": "str",
            "int": "int",
            "float": "float",
            "bool": "bool",
            "list": "list",
            "dict": "dict",
            "date": "date",
            "datetime": "datetime",
            "file": "str",
            "image": "str",
            "json": "dict",
        }
        self.python_type = type_mapping.get(self.data_type.lower(), "str")


@dataclass
class ToolContext:
    """Context for tool template rendering."""

    name: str
    name_snake: str
    class_name: str
    class_name_base: str
    tool_file_base: str
    version: ToolVersion
    major_version: int
    minor_version: int
    general_properties: list[PropertyDef] = field(default_factory=list)
    input_properties: list[PropertyDef] = field(default_factory=list)
    output_properties: list[PropertyDef] = field(default_factory=list)
    versions: list[ToolVersion] = field(default_factory=list)
    is_minor_update: bool = False
    shared_properties: dict[str, list[str]] = field(default_factory=dict)
    copy_properties_from: Path | None = None  # Path to copy properties.py from

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "name_snake": self.name_snake,
            "class_name": self.class_name,
            "class_name_base": self.class_name_base,
            "tool_file_base": self.tool_file_base,
            "version": str(self.version),
            "major_version": self.major_version,
            "minor_version": self.minor_version,
            "general_properties": self.general_properties,
            "input_properties": self.input_properties,
            "output_properties": self.output_properties,
            "versions": self.versions,
            "shared_properties": self.shared_properties,
        }


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def to_snake_case(name: str) -> str:
    """Convert name to snake_case."""
    # Replace hyphens with underscores
    name = name.replace("-", "_")
    # Convert CamelCase to snake_case
    name = re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()
    # Clean up multiple underscores
    name = re.sub(r"_+", "_", name)
    return name.strip("_")


def to_class_name(name: str) -> str:
    """Convert name to PascalCase class name."""
    # Split by underscores and hyphens
    parts = re.split(r"[-_]", name)
    return "".join(word.title() for word in parts if word)


def get_tool_dir_name(name: str, major_version: int) -> str:
    """Get tool directory name with major version suffix."""
    snake = to_snake_case(name)
    return f"{snake}_{major_version}"


def get_tool_file_name(name: str, version: ToolVersion) -> str:
    """Get tool file name with full version suffix."""
    snake = to_snake_case(name)
    return f"{snake}_{version.file_suffix}.py"


def find_existing_tool(tools_path: Path, name: str) -> tuple[Path | None, list[ToolVersion]]:
    """
    Find existing tool directories and versions.

    Returns:
        Tuple of (latest_dir, list_of_versions)
    """
    snake = to_snake_case(name)
    pattern = re.compile(rf"^{re.escape(snake)}_(\d+)$")

    versions: list[ToolVersion] = []
    latest_dir: Path | None = None
    latest_major = 0

    if not tools_path.exists():
        return None, []

    for d in tools_path.iterdir():
        if not d.is_dir():
            continue
        match = pattern.match(d.name)
        if match:
            major = int(match.group(1))

            # Find all .py files with version suffix in this dir
            file_pattern = re.compile(rf"^{re.escape(snake)}_(\d+)_(\d+)\.py$")
            for f in d.iterdir():
                if f.is_file():
                    file_match = file_pattern.match(f.name)
                    if file_match:
                        v = ToolVersion(
                            major=int(file_match.group(1)),
                            minor=int(file_match.group(2)),
                        )
                        versions.append(v)

            if major > latest_major:
                latest_major = major
                latest_dir = d

    # Sort versions
    versions.sort(key=lambda v: (v.major, v.minor))

    return latest_dir, versions


def collect_property_name(category_name: str) -> str | None:
    """
    Interactively collect just the property name from user.

    Returns:
        Property name (snake_case) or None if user wants to skip
    """
    console.print(f"\n[cyan]Add property for {category_name}:[/cyan]")

    name = Prompt.ask(
        "  Property name (or N to skip)",
        default="N",
    ).strip()

    if name.upper() == "N" or not name:
        return None

    # Validate and convert to snake_case
    return to_snake_case(name)


def collect_property_details(name: str) -> PropertyDef:
    """
    Collect remaining property details after name is known.

    Args:
        name: The property name (already validated)

    Returns:
        Complete PropertyDef
    """
    label = Prompt.ask(
        "  Label",
        default=name.replace("_", " ").title(),
    )

    data_type = Prompt.ask(
        "  Data type",
        choices=[
            "str",
            "int",
            "float",
            "bool",
            "list",
            "dict",
            "date",
            "datetime",
            "file",
            "image",
            "json",
        ],
        default="str",
    )

    required = Confirm.ask("  Required?", default=True)

    default: Any = None
    if not required:
        default_str = Prompt.ask(
            "  Default value",
            default="None",
        )
        if default_str.lower() != "none":
            # Try to parse the default value
            if data_type == "int":
                try:
                    default = int(default_str)
                except ValueError:
                    default = None
            elif data_type == "float":
                try:
                    default = float(default_str)
                except ValueError:
                    default = None
            elif data_type == "bool":
                default = default_str.lower() in ("true", "1", "yes")
            else:
                default = default_str

    return PropertyDef(
        name=name,
        label=label,
        data_type=data_type,
        required=required,
        default=default,
    )


def collect_properties_for_category(
    category: ExposureCategory,
    existing_names: set[str],
) -> tuple[list[PropertyDef], set[str]]:
    """
    Collect all properties for a category.

    If a property name already exists in existing_names, it's noted
    as a shared property (added to multiple categories) and skipped
    WITHOUT asking for details.

    Returns:
        Tuple of (new_properties, shared_property_names)
    """
    props: list[PropertyDef] = []
    shared_names: set[str] = set()

    console.print(f"\n[bold]{category.info.icon} {category.info.name}[/bold]")
    console.print(f"[dim]{category.info.description}[/dim]")

    while True:
        # First, just get the name
        name = collect_property_name(category.info.name)
        if name is None:
            break

        # Check if property already exists (duplicate) BEFORE asking for details
        if name in existing_names:
            console.print(
                f"  [green]✓ Added known property '{name}' to {category.info.name}[/green]"
            )
            shared_names.add(name)
            continue

        # Only now collect the remaining details
        prop = collect_property_details(name)
        props.append(prop)
        existing_names.add(name)
        console.print(f"  [green]✓ Added: {prop.name}[/green]")

    return props, shared_names


def render_template_file(template_path: Path, context: dict) -> str:
    """Render a Jinja2 template file with custom filters."""
    from jinja2 import BaseLoader, Environment

    content = template_path.read_text()

    # Create environment with custom filters
    env = Environment(loader=BaseLoader())
    env.filters["repr"] = repr  # Add Python's repr as a filter

    template = env.from_string(content)
    return template.render(**context)


def create_tool_files(
    tools_path: Path,
    ctx: ToolContext,
    templates_dir: Path,
) -> Path:
    """
    Create tool files from templates.

    Returns:
        Path to the created tool directory
    """
    tool_dir = tools_path / get_tool_dir_name(ctx.name, ctx.major_version)
    tool_dir.mkdir(parents=True, exist_ok=True)

    template_context = ctx.to_dict()

    # Create or update __init__.py
    init_template = templates_dir / "tool" / "__init__.py.j2"
    init_content = render_template_file(init_template, template_context)
    (tool_dir / "__init__.py").write_text(init_content)

    # Create properties.py only for new tools/major versions (not minor updates)
    if not ctx.is_minor_update:
        if ctx.copy_properties_from and ctx.copy_properties_from.exists():
            # Copy properties from previous major version
            import shutil

            shutil.copy(ctx.copy_properties_from, tool_dir / "properties.py")
        else:
            # Generate new properties from template
            props_template = templates_dir / "tool" / "properties.py.j2"
            props_content = render_template_file(props_template, template_context)
            (tool_dir / "properties.py").write_text(props_content)

    # Create the tool file
    tool_template = templates_dir / "tool" / "tool.py.j2"
    tool_content = render_template_file(tool_template, template_context)
    tool_file = tool_dir / get_tool_file_name(ctx.name, ctx.version)
    tool_file.write_text(tool_content)

    return tool_dir


# ============================================================================
# CLI COMMANDS
# ============================================================================


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
def tool() -> None:
    """Manage tools."""
    pass


@tool.command("create")
@click.argument("name")
@click.option("--output", "-o", "tools_dir", default="tools", help="Tools directory")
@click.option("--no-interactive", "-n", is_flag=True, help="Skip interactive property input")
def tool_create(name: str, tools_dir: str, no_interactive: bool) -> None:
    """
    Create a new tool.

    For new tools, creates version 1.0. For existing tools, prompts
    for major (breaking) or minor (compatible) version update.
    """
    from iq_sdk.cli import TEMPLATES_DIR

    tools_path = Path(tools_dir)
    snake_name = to_snake_case(name)
    class_name_base = to_class_name(name)

    # Check for existing tool
    existing_dir, existing_versions = find_existing_tool(tools_path, name)

    if existing_versions:
        # Tool exists - show versions and ask for action
        latest = existing_versions[-1]
        console.print(f"\n[yellow]Tool '{name}' already exists[/yellow]")

        # Show existing versions grouped by major
        versions_by_major: dict[int, list[ToolVersion]] = {}
        for v in existing_versions:
            versions_by_major.setdefault(v.major, []).append(v)

        console.print("\n[bold]Existing versions:[/bold]")
        for major, minors in sorted(versions_by_major.items()):
            minor_strs = [f"{major}.{v.minor}" for v in sorted(minors, key=lambda x: x.minor)]
            console.print(f"  v{major}.x: {', '.join(minor_strs)}")

        console.print(f"\n[dim]Latest: v{latest}[/dim]")
        console.print()

        version_type = Prompt.ask(
            "Create (M)ajor, mi(N)or, or (C)ancel",
            choices=["m", "n", "c"],
            default="n",
        )

        if version_type == "c":
            console.print("[dim]Cancelled[/dim]")
            return

        if version_type == "m":
            # Major version - new directory, copies properties from previous major
            version = ToolVersion(major=latest.major + 1, minor=0)
            is_minor = False
            is_major_upgrade = True
            console.print(f"[cyan]Creating major version {version}[/cyan]")
        else:
            # Minor version - same directory, same interface
            version = ToolVersion(major=latest.major, minor=latest.minor + 1)
            is_minor = True
            is_major_upgrade = False
            console.print(f"[cyan]Creating minor version {version} (same interface)[/cyan]")
    else:
        # New tool
        version = ToolVersion(major=1, minor=0)
        is_minor = False
        is_major_upgrade = False
        console.print(f"\n[cyan]Creating new tool '{name}' v{version}[/cyan]")

    # Build class name with version
    class_name = f"{class_name_base}_{version.file_suffix}"

    # Create context
    ctx = ToolContext(
        name=name,
        name_snake=snake_name,
        class_name=class_name,
        class_name_base=class_name_base,
        tool_file_base=snake_name,
        version=version,
        major_version=version.major,
        minor_version=version.minor,
        versions=[v for v in existing_versions if v.major == version.major] + [version],
        is_minor_update=is_minor,
    )

    # Handle properties based on version type
    shared_property_names: dict[str, list[str]] = {}  # name -> list of categories
    copy_properties_from: Path | None = None

    if is_major_upgrade:
        # Major upgrade: copy properties from previous major version
        prev_major_dir = tools_path / get_tool_dir_name(name, latest.major)
        prev_props_file = prev_major_dir / "properties.py"
        if prev_props_file.exists():
            copy_properties_from = prev_props_file
            console.print(f"[dim]Copying properties from v{latest.major}.x[/dim]")
    elif not is_minor and not no_interactive:
        # New tool: collect properties interactively
        console.print("\n[bold]Define tool properties[/bold]")
        console.print(
            "[dim]Properties define the tool's interface. Press Enter/N to skip a category.[/dim]"
        )
        console.print(
            "[dim]If you enter a property name that already exists, it will be shared across categories.[/dim]"
        )

        existing_names: set[str] = set()

        ctx.general_properties, general_shared = collect_properties_for_category(
            ExposureCategory.GENERAL, existing_names
        )
        for prop_name in general_shared:
            shared_property_names.setdefault(prop_name, ["GENERAL"]).append("GENERAL")

        ctx.input_properties, input_shared = collect_properties_for_category(
            ExposureCategory.INPUT, existing_names
        )
        for prop_name in input_shared:
            shared_property_names.setdefault(prop_name, []).append("INPUT")

        ctx.output_properties, output_shared = collect_properties_for_category(
            ExposureCategory.OUTPUT, existing_names
        )
        for prop_name in output_shared:
            shared_property_names.setdefault(prop_name, []).append("OUTPUT")

        # Store shared properties info in context for template
        ctx.shared_properties = shared_property_names

    # Store copy source in context
    ctx.copy_properties_from = copy_properties_from

    # Create files
    tool_dir = create_tool_files(tools_path, ctx, TEMPLATES_DIR)
    tool_file = get_tool_file_name(name, version)

    console.print(f"\n[bold green]✓ Tool '{name}' v{version} created[/bold green]")
    console.print(f"  Directory: {tool_dir}")
    console.print(f"  Tool file: {tool_dir / tool_file}")

    if not is_minor:
        console.print(f"  Properties: {tool_dir / 'properties.py'}")
    else:
        console.print(
            f"\n[dim]Minor update uses existing properties.py from v{version.major}.0[/dim]"
        )

    console.print("\n[dim]Edit the tool file to implement your logic.[/dim]")


@tool.command("list")
@click.option("--dir", "-d", "tools_dir", default="tools", help="Tools directory")
def tool_list(tools_dir: str) -> None:
    """List available tools."""
    tools_path = Path(tools_dir)

    if not tools_path.exists():
        console.print(f"[yellow]Tools directory '{tools_dir}' does not exist[/yellow]")
        return

    table = Table(title="Available Tools")
    table.add_column("Name", style="cyan")
    table.add_column("Version", style="green")
    table.add_column("Path", style="dim")
    table.add_column("Files", style="dim")

    # Group by base tool name
    tools: dict[str, list[tuple[Path, ToolVersion]]] = {}

    for tool_dir in tools_path.iterdir():
        if not tool_dir.is_dir() or tool_dir.name.startswith("_"):
            continue

        # Parse directory name for major version
        match = re.match(r"^(.+)_(\d+)$", tool_dir.name)
        if not match:
            continue

        base_name = match.group(1)

        # Find version files
        file_pattern = re.compile(rf"^{re.escape(base_name)}_(\d+)_(\d+)\.py$")
        for f in tool_dir.iterdir():
            if f.is_file():
                file_match = file_pattern.match(f.name)
                if file_match:
                    v = ToolVersion(
                        major=int(file_match.group(1)),
                        minor=int(file_match.group(2)),
                    )
                    if base_name not in tools:
                        tools[base_name] = []
                    tools[base_name].append((tool_dir, v))

    # Display grouped by tool
    for base_name, versions in sorted(tools.items()):
        versions.sort(key=lambda x: (x[1].major, x[1].minor))
        latest = versions[-1]

        version_strs = [str(v) for _, v in versions]

        table.add_row(
            base_name.replace("_", "-"),
            ", ".join(version_strs),
            str(latest[0]),
            str(len(versions)),
        )

    if not tools:
        console.print("[dim]No tools found[/dim]")
    else:
        console.print(table)


@tool.command("register")
@click.argument("tool_name")
@click.option("--site", "-s", "site_ids", multiple=True, help="Sites to register with")
@click.pass_context
def tool_register(ctx: click.Context, tool_name: str, site_ids: tuple) -> None:
    """Register a tool with site(s)."""
    config_file = ctx.obj.get("config_file") if ctx.obj else None
    settings = load_settings(config_file)

    # Get target sites
    if site_ids:
        sites = settings.get_sites(list(site_ids))
    else:
        sites = [settings.site]

    if not sites:
        console.print("[red]No matching sites found[/red]")
        sys.exit(1)

    console.print(f"[bold blue]Registering tool '{tool_name}'...[/bold blue]")
    for s in sites:
        console.print(f"  → {s.id} ({s.get_host()})")

    console.print("\n[yellow]Note: Tool registration requires running worker connection.[/yellow]")
    console.print(f"Start a worker with: iq worker start --tool {tool_name}")


@tool.command("unregister")
@click.argument("tool_name")
@click.option("--site", "-s", "site_ids", multiple=True, help="Sites to unregister from")
@click.pass_context
def tool_unregister(ctx: click.Context, tool_name: str, site_ids: tuple) -> None:
    """Unregister a tool from site(s)."""
    config_file = ctx.obj.get("config_file") if ctx.obj else None
    settings = load_settings(config_file)

    # Get target sites
    if site_ids:
        sites = settings.get_sites(list(site_ids))
    else:
        sites = [settings.site]

    if not sites:
        console.print("[red]No matching sites found[/red]")
        sys.exit(1)

    console.print(f"[bold blue]Unregistering tool '{tool_name}'...[/bold blue]")
    for s in sites:
        console.print(f"  → {s.id} ({s.get_host()})")

    console.print("\n[yellow]Note: Tool unregistration handled on worker disconnect.[/yellow]")


@tool.command("delete")
@click.argument("tool_name")
@click.option("--dir", "-d", "tools_dir", default="tools", help="Tools directory")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.option("--all", "-a", "delete_all", is_flag=True, help="Delete all versions")
@click.option(
    "--version",
    "-v",
    "version_str",
    default=None,
    help="Specific version to delete (e.g., 1.0 or 1.x)",
)
def tool_delete(
    tool_name: str, tools_dir: str, yes: bool, delete_all: bool, version_str: str | None
) -> None:
    """
    Delete a tool and its versions.

    Shows all available versions and allows deletion of:
    - A single minor version (e.g., 1.0)
    - A major version with all minors (e.g., all 1.x)
    - All versions of the tool

    Examples:
        iq tool delete my-tool --all -y      # Delete all, no confirm
        iq tool delete my-tool -v 1.0 -y     # Delete specific version
        iq tool delete my-tool -v 1.x        # Delete all 1.x versions
    """
    import shutil

    tools_path = Path(tools_dir)
    snake_name = to_snake_case(tool_name)

    # Find all versions
    existing_dir, existing_versions = find_existing_tool(tools_path, tool_name)

    if not existing_versions:
        console.print(f"[red]Tool '{tool_name}' not found[/red]")
        sys.exit(1)

    # Group by major version
    versions_by_major: dict[int, list[ToolVersion]] = {}
    for v in existing_versions:
        versions_by_major.setdefault(v.major, []).append(v)

    # Show available versions
    console.print(f"\n[bold]Tool '{tool_name}' versions:[/bold]")
    for major, minors in sorted(versions_by_major.items()):
        minor_strs = [f"{major}.{v.minor}" for v in sorted(minors, key=lambda x: x.minor)]
        console.print(f"  Major {major}: {', '.join(minor_strs)}")

    console.print()

    # Determine selection
    if delete_all:
        selection = "A"
    elif version_str:
        selection = version_str
    else:
        # Build selection options
        options = []
        for major, minors in sorted(versions_by_major.items()):
            for v in sorted(minors, key=lambda x: x.minor):
                options.append(f"{v.major}.{v.minor}")
            # Always allow major number (e.g., "1" or "2") to delete all minors
            options.append(str(major))
        options.append("A")

        default_selection = "A" if len(existing_versions) == 1 else options[0]
        selection = Prompt.ask(
            "Delete which version? (e.g., '1.0', '1' for all 1.x, 'A' for all)",
            choices=options,
            default=default_selection,
        )

    # Determine what to delete
    to_delete: list[tuple[Path, ToolVersion]] = []
    dirs_to_check: set[Path] = set()

    if selection.upper() == "A":
        # Delete all
        for v in existing_versions:
            tool_dir = tools_path / get_tool_dir_name(tool_name, v.major)
            tool_file = tool_dir / get_tool_file_name(tool_name, v)
            to_delete.append((tool_file, v))
            dirs_to_check.add(tool_dir)
    elif selection.endswith(".x") or selection.isdigit():
        # Delete all minors of a major (e.g., "1.x" or just "1")
        major = int(selection.replace(".x", ""))
        for v in existing_versions:
            if v.major == major:
                tool_dir = tools_path / get_tool_dir_name(tool_name, v.major)
                tool_file = tool_dir / get_tool_file_name(tool_name, v)
                to_delete.append((tool_file, v))
                dirs_to_check.add(tool_dir)
    else:
        # Delete specific version
        version = ToolVersion.parse(selection)
        tool_dir = tools_path / get_tool_dir_name(tool_name, version.major)
        tool_file = tool_dir / get_tool_file_name(tool_name, version)
        to_delete.append((tool_file, version))
        dirs_to_check.add(tool_dir)

    # Confirm
    if not yes:
        console.print("\n[yellow]Will delete:[/yellow]")
        for path, _v in to_delete:
            console.print(f"  • {path}")

        # Check if directories will be removed
        for d in dirs_to_check:
            remaining_files = [
                f
                for f in d.iterdir()
                if f.is_file()
                and f.suffix == ".py"
                and f.name not in ["__init__.py", "properties.py"]
                and not any(str(p) == str(f) for p, _ in to_delete)
            ]
            if not remaining_files:
                console.print(f"  • {d}/ (entire directory)")

        if not Confirm.ask("\nProceed?", default=False):
            console.print("[dim]Cancelled[/dim]")
            return

    # Delete files
    deleted_count = 0
    for path, _v in to_delete:
        if path.exists():
            path.unlink()
            deleted_count += 1
            console.print(f"[green]✓ Deleted {path.name}[/green]")

    # Check if directories should be removed (no more tool files)
    for d in dirs_to_check:
        if d.exists():
            remaining_tool_files = [
                f
                for f in d.iterdir()
                if f.is_file()
                and f.suffix == ".py"
                and f.name not in ["__init__.py", "properties.py"]
                and re.match(rf"^{re.escape(snake_name)}_\d+_\d+\.py$", f.name)
            ]
            if not remaining_tool_files:
                shutil.rmtree(d)
                console.print(f"[green]✓ Deleted directory {d}[/green]")

    console.print(
        f"\n[bold green]✓ Deleted {deleted_count} version(s) of '{tool_name}'[/bold green]"
    )
