"""
iq site commands - Manage site configurations.
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

import click
from rich.table import Table

from iq_sdk.cli import (
    console,
    load_config_file,
    save_config_file,
)
from iq_sdk.config import (
    load_settings,
    save_env_template,
)


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
def site() -> None:
    """Manage sites."""
    pass


@site.command("add")
@click.argument("site_id")
@click.option("--host", "-H", required=True, help="Socket.IO server URL")
@click.option("--api-key", "-k", default="", help="API key for authentication")
@click.option(
    "--config", "-c", "config_file", default="config/settings.yml", help="Config file to modify"
)
@click.pass_context
def site_add(
    ctx: click.Context,
    site_id: str,
    host: str,
    api_key: str,
    config_file: str,
) -> None:
    """Add a new site configuration."""
    config_path = Path(config_file)
    config_data = load_config_file(config_path)

    # Initialize sites list if not present
    if "sites" not in config_data:
        config_data["sites"] = []

    # Check if site already exists
    existing_ids = [s.get("id") for s in config_data.get("sites", [])]
    if config_data.get("site", {}).get("id") == site_id:
        console.print(
            f"[yellow]Site '{site_id}' is the default site. Use 'iq site update' to modify.[/yellow]"
        )
        return

    if site_id in existing_ids:
        if not click.confirm(f"Site '{site_id}' already exists. Overwrite?"):
            raise click.Abort()
        config_data["sites"] = [s for s in config_data["sites"] if s.get("id") != site_id]

    # Add new site
    new_site = {
        "id": site_id,
        "host": host,
        "api_key": api_key,
    }
    config_data["sites"].append(new_site)

    # Save config
    save_config_file(config_path, config_data)

    console.print(f"[bold green]✓ Site '{site_id}' added to {config_path}[/bold green]")

    # Remind about API secret
    site_id_upper = site_id.upper().replace("-", "_")
    console.print("\n[yellow]Don't forget to set the API secret:[/yellow]")
    console.print(f"  export IQ_SITE_{site_id_upper}_API_SECRET='your-secret'")
    console.print("  # or add to .env file:")
    console.print(f"  IQ_SITE_{site_id_upper}_API_SECRET=your-secret")


@site.command("list")
@click.argument("site_id", required=False)
@click.option("--check", is_flag=True, help="Check host connectivity and permissions")
@click.pass_context
def site_list(ctx: click.Context, site_id: str | None, check: bool) -> None:
    """List site configuration(s)."""
    config_file = ctx.obj.get("config_file")
    settings = load_settings(config_file)

    if site_id:
        # Show specific site
        site_config = settings.get_site(site_id)
        if not site_config:
            console.print(f"[red]Site '{site_id}' not found[/red]")
            sys.exit(1)

        console.print(f"\n[bold]Site: {site_config.id}[/bold]")
        console.print(f"  Host:       {site_config.get_host()}")
        console.print(f"  API Key:    {site_config.get_api_key() or '(not set)'}")

        # Show custom env vars
        env_vars = site_config.get_env()
        if env_vars:
            console.print(f"  Env vars:   {len(env_vars)} defined")
            for k, v in env_vars.items():
                console.print(f"    {k}={v}")

        # Show tools
        tools = site_config.get_tools()
        if tools:
            console.print(f"  Tools:      {len(tools)} configured")
            for t in tools:
                console.print(f"    {t.name} → queue:{t.get_queue()} threads:{t.threads}")

        # Check API secret status
        site_id_upper = site_config.id.upper().replace("-", "_")
        has_env_secret = f"IQ_SITE_{site_id_upper}_API_SECRET" in os.environ
        has_file_secret = f"IQ_SITE_{site_id_upper}_API_SECRET_FILE" in os.environ
        has_config_secret = bool(site_config.api_secret)

        if has_env_secret:
            console.print("  API Secret: [green]✓ Set via ENV[/green]")
        elif has_file_secret:
            console.print("  API Secret: [green]✓ Set via FILE[/green]")
        elif has_config_secret:
            console.print("  API Secret: [yellow]⚠ Set in config (not recommended)[/yellow]")
        else:
            console.print("  API Secret: [red]✗ Not set[/red]")

        if check:
            _check_site_connectivity(site_config)
    else:
        # Show all sites
        table = Table(title="Configured Sites")
        table.add_column("ID", style="cyan")
        table.add_column("Host", style="dim")
        table.add_column("API Key")
        table.add_column("Secret")
        table.add_column("Tools")
        table.add_column("Worker ID", style="magenta")

        if check:
            table.add_column("Reachable")
            table.add_column("Auth")

        all_sites = [settings.site] + settings.sites

        # Gather check results if needed
        check_results = {}
        if check:
            check_results = _check_sites_connectivity(all_sites)

        for s in all_sites:
            site_id_upper = s.id.upper().replace("-", "_")
            has_env_secret = f"IQ_SITE_{site_id_upper}_API_SECRET" in os.environ
            has_file_secret = f"IQ_SITE_{site_id_upper}_API_SECRET_FILE" in os.environ
            has_config_secret = bool(s.api_secret)

            if has_env_secret or has_file_secret:
                secret_status = "[green]✓[/green]"
            elif has_config_secret:
                secret_status = "[yellow]⚠[/yellow]"
            else:
                secret_status = "[red]✗[/red]"

            is_default = " (default)" if s.id == settings.site.id else ""

            # Tools count
            tools = s.get_tools()
            tools_str = str(len(tools)) if tools else "-"

            # Worker ID from settings
            worker_id = settings.get_worker_id()

            row = [
                f"{s.id}{is_default}",
                s.get_host(),
                s.get_api_key() or "-",
                secret_status,
                tools_str,
                worker_id,
            ]

            if check:
                result = check_results.get(s.id, {})
                reachable = "[green]✓[/green]" if result.get("reachable") else "[red]✗[/red]"
                auth = "[green]✓[/green]" if result.get("auth") else "[red]✗[/red]"
                if result.get("error"):
                    reachable = f"[red]✗[/red] {result['error'][:20]}"
                row.extend([reachable, auth])

            table.add_row(*row)

        console.print(table)


def _check_site_connectivity(site_config) -> None:
    """Check connectivity for a single site."""
    from iq_sdk.client import IQHttpClient

    console.print("\n[bold]Connectivity Check:[/bold]")

    async def _check():
        async with IQHttpClient(
            site_config.get_host(),
            api_key=site_config.get_api_key(),
            api_secret=site_config.load_api_secret(),
        ) as client:
            # Ping
            ping_result = await client.ping()
            if ping_result.reachable:
                latency = f" ({ping_result.latency_ms}ms)" if ping_result.latency_ms else ""
                console.print(f"  Reachable: [green]✓{latency}[/green]")
            else:
                console.print(f"  Reachable: [red]✗ {ping_result.error}[/red]")

            # Auth check
            if ping_result.reachable:
                auth_result = await client.check_auth()
                if auth_result.success:
                    console.print("  Auth:      [green]✓[/green]")
                    console.print(
                        f"    Can register workers: {'✓' if auth_result.can_register_workers else '✗'}"
                    )
                    console.print(
                        f"    Can register tools:   {'✓' if auth_result.can_register_tools else '✗'}"
                    )
                    console.print(
                        f"    Can unregister tools: {'✓' if auth_result.can_unregister_tools else '✗'}"
                    )
                else:
                    console.print(f"  Auth:      [red]✗ {auth_result.error}[/red]")

    try:
        asyncio.run(_check())
    except Exception as e:
        console.print(f"  [red]Check failed: {e}[/red]")


def _check_sites_connectivity(sites: list) -> dict:
    """Check connectivity for multiple sites."""
    from iq_sdk.client import IQHttpClient

    results = {}

    async def _check_all():
        for site in sites:
            try:
                async with IQHttpClient(
                    site.get_host(),
                    api_key=site.get_api_key(),
                    api_secret=site.load_api_secret(),
                    timeout=5.0,
                ) as client:
                    ping = await client.ping()
                    auth = await client.check_auth() if ping.reachable else None

                    results[site.id] = {
                        "reachable": ping.reachable,
                        "auth": auth.success if auth else False,
                        "error": ping.error,
                    }
            except Exception as e:
                results[site.id] = {
                    "reachable": False,
                    "auth": False,
                    "error": str(e)[:30],
                }

    try:
        asyncio.run(_check_all())
    except Exception:
        pass

    return results


@site.command("drop")
@click.argument("site_id")
@click.option(
    "--config", "-c", "config_file", default="config/settings.yml", help="Config file to modify"
)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def site_drop(site_id: str, config_file: str, yes: bool) -> None:
    """Remove a site configuration."""
    config_path = Path(config_file)
    config_data = load_config_file(config_path)

    # Check if it's the default site
    if config_data.get("site", {}).get("id") == site_id:
        console.print(f"[red]Cannot drop default site '{site_id}'[/red]")
        sys.exit(1)

    # Find and remove site
    sites = config_data.get("sites", [])
    original_count = len(sites)
    config_data["sites"] = [s for s in sites if s.get("id") != site_id]

    if len(config_data["sites"]) == original_count:
        console.print(f"[yellow]Site '{site_id}' not found[/yellow]")
        return

    if not yes and not click.confirm(f"Remove site '{site_id}'?"):
        raise click.Abort()

    save_config_file(config_path, config_data)
    console.print(f"[bold green]✓ Site '{site_id}' removed from {config_path}[/bold green]")


@site.command("env-template")
@click.option("--output", "-o", default=".env.template", help="Output file")
@click.pass_context
def site_env_template(ctx: click.Context, output: str) -> None:
    """Generate .env template with site password entries."""
    config_file = ctx.obj.get("config_file")
    settings = load_settings(config_file)

    output_path = save_env_template(settings, output)
    console.print(f"[bold green]✓ Environment template created: {output_path}[/bold green]")
