"""
Socket.IO connection for IQ hosts.

Handles persistent connections for worker registration and task execution.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import socketio  # type: ignore[import-untyped]


@dataclass
class ConnectionState:
    """Current state of connection."""

    connected: bool = False
    authenticated: bool = False
    registered_tools: list[str] = field(default_factory=list)
    error: str | None = None


@dataclass
class WorkerRegistration:
    """Worker registration info."""

    worker_id: str
    tools: list[str]
    queues: list[str]


class IQConnection:
    """
    Socket.IO connection to IQ host.

    Manages:
    - Connection lifecycle
    - Worker registration
    - Tool queue subscriptions
    - Task execution callbacks
    """

    def __init__(
        self,
        host: str,
        worker_id: str | None = None,
        api_key: str | None = None,
        api_secret: str | None = None,
        reconnect: bool = True,
        reconnect_attempts: int = 5,
    ):
        """
        Initialize connection.

        Args:
            host: Socket.IO server URL
            worker_id: Unique worker identifier
            api_key: API key for authentication
            api_secret: API secret for authentication
            reconnect: Whether to auto-reconnect
            reconnect_attempts: Max reconnection attempts
        """
        self.host = host
        self.worker_id = worker_id
        self.api_key = api_key
        self.api_secret = api_secret
        self.reconnect = reconnect
        self.reconnect_attempts = reconnect_attempts

        self._sio: socketio.AsyncClient | None = None
        self._state = ConnectionState()
        self._task_handlers: dict[str, Callable[..., Any]] = {}

    @property
    def state(self) -> ConnectionState:
        """Get current connection state."""
        return self._state

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._state.connected

    async def connect(self) -> bool:
        """
        Establish connection to host.

        Returns:
            True if connection successful
        """
        # TODO: Implement actual Socket.IO connection
        # This is a stub

        if self._sio is not None:
            return self._state.connected

        self._sio = socketio.AsyncClient(
            reconnection=self.reconnect,
            reconnection_attempts=self.reconnect_attempts,
        )

        # Register event handlers
        @self._sio.on("connect")  # type: ignore[misc]
        async def on_connect() -> None:
            self._state.connected = True
            self._state.error = None

        @self._sio.on("disconnect")  # type: ignore[misc]
        async def on_disconnect() -> None:
            self._state.connected = False

        @self._sio.on("error")  # type: ignore[misc]
        async def on_error(data: Any) -> None:
            self._state.error = str(data)

        try:
            auth = {}
            if self.api_key:
                auth["api_key"] = self.api_key
            if self.api_secret:
                auth["api_secret"] = self.api_secret
            if self.worker_id:
                auth["worker_id"] = self.worker_id

            await self._sio.connect(
                self.host,
                auth=auth if auth else None,
            )

            return True

        except Exception as e:
            self._state.error = str(e)
            return False

    async def disconnect(self) -> None:
        """Disconnect from host."""
        if self._sio:
            await self._sio.disconnect()
            self._sio = None
            self._state.connected = False

    async def authenticate(self) -> bool:
        """
        Authenticate with host.

        Returns:
            True if authentication successful
        """
        # TODO: Implement actual authentication
        # This is a stub

        if not self._sio or not self._state.connected:
            return False

        try:
            response = await self._sio.call(
                "authenticate",
                {
                    "api_key": self.api_key,
                    "api_secret": self.api_secret,
                    "worker_id": self.worker_id,
                },
            )

            self._state.authenticated = response.get("success", False)
            return self._state.authenticated

        except Exception as e:
            self._state.error = str(e)
            return False

    async def register_worker(
        self,
        tools: list[str],
        queues: list[str] | None = None,
    ) -> WorkerRegistration | None:
        """
        Register worker with host.

        Args:
            tools: List of tool names to register
            queues: Optional custom queue names (defaults to tool names)

        Returns:
            WorkerRegistration or None on failure
        """
        # TODO: Implement actual worker registration
        # This is a stub

        if not self._sio or not self._state.connected:
            return None

        if queues is None:
            queues = tools

        try:
            response = await self._sio.call(
                "register_worker",
                {
                    "worker_id": self.worker_id,
                    "tools": tools,
                    "queues": queues,
                },
            )

            if response.get("success"):
                self._state.registered_tools = tools
                return WorkerRegistration(
                    worker_id=self.worker_id or "",
                    tools=tools,
                    queues=queues,
                )
            return None

        except Exception as e:
            self._state.error = str(e)
            return None

    async def unregister_worker(self) -> bool:
        """
        Unregister worker from host.

        Returns:
            True if unregistration successful
        """
        # TODO: Implement actual worker unregistration
        # This is a stub

        if not self._sio or not self._state.connected:
            return False

        try:
            response = await self._sio.call(
                "unregister_worker",
                {"worker_id": self.worker_id},
            )

            if response.get("success"):
                self._state.registered_tools = []
                return True
            return False

        except Exception as e:
            self._state.error = str(e)
            return False

    def on_task(self, tool_name: str, handler: Callable[..., Any]) -> None:
        """
        Register task handler for a tool.

        Args:
            tool_name: Tool name to handle tasks for
            handler: Async callback function
        """
        self._task_handlers[tool_name] = handler

    async def wait_for_tasks(self) -> None:
        """
        Wait for and process incoming tasks.

        Blocks until disconnected.
        """
        # TODO: Implement actual task waiting
        # This is a stub

        if not self._sio:
            return

        @self._sio.on("task")  # type: ignore[misc]
        async def on_task(data: dict[str, Any]) -> dict[str, Any]:
            tool_name = data.get("tool")
            if tool_name in self._task_handlers:
                try:
                    result = await self._task_handlers[tool_name](data.get("payload"))
                    return {"success": True, "result": result}
                except Exception as e:
                    return {"success": False, "error": str(e)}
            return {"success": False, "error": f"No handler for tool: {tool_name}"}

        await self._sio.wait()

    async def __aenter__(self) -> IQConnection:
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.disconnect()
