"""
IQ Client - HTTP/Socket.IO client for IQ hosts.

This module provides connectivity to IQ hosts for:
- Health checks (ping)
- Authentication
- Worker/tool registration
- Queue management
"""

from iq_sdk.client.connection import IQConnection
from iq_sdk.client.http import IQHttpClient

__all__ = [
    "IQHttpClient",
    "IQConnection",
]
