"""
HTTP client for IQ host connectivity.

Uses httpx for async HTTP requests.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class PingResult:
    """Result of a ping/health check."""

    reachable: bool
    status_code: int | None = None
    latency_ms: float | None = None
    error: str | None = None
    version: str | None = None


@dataclass
class AuthResult:
    """Result of authentication check."""

    success: bool
    can_register_workers: bool = False
    can_register_tools: bool = False
    can_unregister_tools: bool = False
    error: str | None = None


@dataclass
class ToolInfo:
    """Information about a registered tool on host."""

    name: str
    queue: str
    signature: str | None = None
    worker_count: int = 0


class IQHttpClient:
    """
    HTTP client for IQ host API.

    Provides health checks, authentication verification,
    and tool/worker information retrieval.
    """

    def __init__(
        self,
        host: str,
        timeout: float = 10.0,
        user: str | None = None,
        password: str | None = None,
    ):
        """
        Initialize HTTP client.

        Args:
            host: Base URL of the IQ host (e.g., http://localhost:3000)
            timeout: Request timeout in seconds
            user: Username for authentication
            password: Password for authentication
        """
        self.host = host.rstrip("/")
        self.timeout = timeout
        self.user = user
        self.password = password
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> IQHttpClient:
        """Async context manager entry."""
        self._client = httpx.AsyncClient(
            base_url=self.host,
            timeout=self.timeout,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        if self._client:
            await self._client.aclose()
            self._client = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get HTTP client, creating if needed."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.host,
                timeout=self.timeout,
            )
        return self._client

    async def ping(self) -> PingResult:
        """
        Check if host is reachable.

        Performs a simple HTTP GET to /health or / endpoint.

        Returns:
            PingResult with reachability info
        """
        import time

        start = time.monotonic()

        try:
            # Try /health first, then /api/health, then /
            for endpoint in ["/health", "/api/health", "/"]:
                try:
                    response = await self.client.get(endpoint)
                    latency = (time.monotonic() - start) * 1000

                    # Try to get version from response
                    version = None
                    if response.headers.get("content-type", "").startswith("application/json"):
                        try:
                            data = response.json()
                            version = data.get("version")
                        except Exception:
                            pass

                    return PingResult(
                        reachable=True,
                        status_code=response.status_code,
                        latency_ms=round(latency, 2),
                        version=version,
                    )
                except httpx.HTTPStatusError:
                    continue

            # If all endpoints failed with HTTP errors, still consider reachable
            latency = (time.monotonic() - start) * 1000
            return PingResult(
                reachable=True,
                status_code=response.status_code if "response" in locals() else None,
                latency_ms=round(latency, 2),
            )

        except httpx.ConnectError as e:
            return PingResult(
                reachable=False,
                error=f"Connection failed: {e}",
            )
        except httpx.TimeoutException:
            return PingResult(
                reachable=False,
                error=f"Timeout after {self.timeout}s",
            )
        except Exception as e:
            return PingResult(
                reachable=False,
                error=str(e),
            )

    async def check_auth(self) -> AuthResult:
        """
        Check authentication and permissions.

        Returns:
            AuthResult with permission info
        """
        # TODO: Implement actual authentication check against host API
        # This is a stub - actual implementation depends on host API

        if not self.user or not self.password:
            return AuthResult(
                success=False,
                error="No credentials provided",
            )

        try:
            # Placeholder: would call /api/auth/check or similar
            response = await self.client.post(
                "/api/auth/check",
                json={"user": self.user, "password": self.password},
            )

            if response.status_code == 200:
                data = response.json()
                return AuthResult(
                    success=True,
                    can_register_workers=data.get("can_register_workers", False),
                    can_register_tools=data.get("can_register_tools", False),
                    can_unregister_tools=data.get("can_unregister_tools", False),
                )
            else:
                return AuthResult(
                    success=False,
                    error=f"Auth failed: {response.status_code}",
                )

        except httpx.HTTPStatusError as e:
            return AuthResult(
                success=False,
                error=f"Auth endpoint error: {e.response.status_code}",
            )
        except Exception as e:
            return AuthResult(
                success=False,
                error=str(e),
            )

    async def list_tools(self) -> list[ToolInfo]:
        """
        List tools registered on host.

        Returns:
            List of ToolInfo objects
        """
        # TODO: Implement actual tool listing from host API
        # This is a stub

        try:
            response = await self.client.get("/api/tools")

            if response.status_code == 200:
                data = response.json()
                return [
                    ToolInfo(
                        name=t.get("name", ""),
                        queue=t.get("queue", ""),
                        signature=t.get("signature"),
                        worker_count=t.get("worker_count", 0),
                    )
                    for t in data.get("tools", [])
                ]
            return []

        except Exception:
            return []

    async def get_tool_info(self, tool_name: str) -> ToolInfo | None:
        """
        Get information about a specific tool.

        Args:
            tool_name: Name of the tool

        Returns:
            ToolInfo or None if not found
        """
        # TODO: Implement actual tool info retrieval
        # This is a stub

        try:
            response = await self.client.get(f"/api/tools/{tool_name}")

            if response.status_code == 200:
                data = response.json()
                return ToolInfo(
                    name=data.get("name", tool_name),
                    queue=data.get("queue", ""),
                    signature=data.get("signature"),
                    worker_count=data.get("worker_count", 0),
                )
            return None

        except Exception:
            return None

    async def check_tool_signature(
        self,
        tool_name: str,
        local_signature: str,
    ) -> tuple[bool, str | None]:
        """
        Check if local tool signature matches remote.

        Args:
            tool_name: Name of the tool
            local_signature: Local tool signature hash

        Returns:
            Tuple of (matches, remote_signature)
        """
        # TODO: Implement actual signature check
        # This is a stub

        tool_info = await self.get_tool_info(tool_name)
        if tool_info is None:
            return False, None

        return tool_info.signature == local_signature, tool_info.signature


def ping_sync(host: str, timeout: float = 5.0) -> PingResult:
    """
    Synchronous ping helper.

    Args:
        host: Host URL to ping
        timeout: Timeout in seconds

    Returns:
        PingResult
    """

    async def _ping() -> PingResult:
        async with IQHttpClient(host, timeout=timeout) as client:
            return await client.ping()

    return asyncio.run(_ping())
