"""
iq-sdk - SDK for creating and managing distributed workers and tools.

This SDK provides:
- CLI for project scaffolding and worker management
- Base classes for creating tools and workers
- Socket.IO connectivity for distributed task processing
- Configuration management with YAML and environment overrides
"""

__version__ = "0.1.0"
__author__ = "IQ Company"

from iq_sdk.config import Settings, load_settings
from iq_sdk.tool import BaseTool
from iq_sdk.worker import BaseWorker

__all__ = [
    "__version__",
    "BaseTool",
    "BaseWorker",
    "Settings",
    "load_settings",
]
