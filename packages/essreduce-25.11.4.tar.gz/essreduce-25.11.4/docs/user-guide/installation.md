# Installation

To install ESSreduce and all of its dependencies, use

`````{tab-set}
````{tab-item} pip
```sh
pip install essreduce
```
````
````{tab-item} conda
```sh
conda install -c conda-forge essreduce
```
````
`````
