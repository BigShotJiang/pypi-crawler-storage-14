Bug: get_project_memories returns memories without matching run_id when run_id is specified

  When calling get_project_memories with a specific run_id, the response includes memories that have undefined/missing run_id in their metadata. These are older memories stored at
   the ticket level before run_id was being set.

  Repro:
  {
    "app_id": "covenant",
    "project_id": "portal",
    "ticket_id": "smart-actions-test",
    "run_id": "swarm_1764236557294_j5384sjkc",
    "children_depth": 0
  }

  Expected: Only return chunks where metadata.run_id === "swarm_1764236557294_j5384sjkc"

  Actual: Returns 170 chunks - includes chunks with run_id: undefined

  Fix: When run_id is specified in the request, filter out chunks where metadata.run_id doesn't match (including undefined).