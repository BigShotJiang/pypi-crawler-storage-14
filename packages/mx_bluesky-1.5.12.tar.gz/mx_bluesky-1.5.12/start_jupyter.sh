source .venv/bin/activate
jupyter-lab --matplotlib=qt5 ./src/mx_bluesky/jupyter_example.ipynb
