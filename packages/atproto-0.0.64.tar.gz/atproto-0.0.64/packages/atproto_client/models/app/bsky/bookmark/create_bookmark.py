##################################################################
# THIS IS THE AUTO-GENERATED CODE. DON'T EDIT IT BY HANDS!
# Copyright (C) 2024 Ilya (Marshal) <https://github.com/MarshalX>.
# This file is part of Python atproto SDK. Licenced under MIT.
##################################################################


import typing as t

from atproto_client.models import base, string_formats


class Data(base.DataModelBase):
    """Input data model for :obj:`app.bsky.bookmark.createBookmark`."""

    cid: string_formats.Cid  #: Cid.
    uri: string_formats.AtUri  #: Uri.


class DataDict(t.TypedDict):
    cid: string_formats.Cid  #: Cid.
    uri: string_formats.AtUri  #: Uri.
