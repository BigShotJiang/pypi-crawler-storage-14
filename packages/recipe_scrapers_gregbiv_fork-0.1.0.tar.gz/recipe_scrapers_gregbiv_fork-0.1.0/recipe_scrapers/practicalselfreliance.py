from .creativecanning import CreativeCanning


class PracticalSelfReliance(CreativeCanning):
    @classmethod
    def host(cls):
        return "practicalselfreliance.com"
