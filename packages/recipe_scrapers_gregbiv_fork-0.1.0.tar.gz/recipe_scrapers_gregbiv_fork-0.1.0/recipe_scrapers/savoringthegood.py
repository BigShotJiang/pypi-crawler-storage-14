from ._abstract import AbstractScraper
from ._wprm import WPRMMixin


class SavoringTheGood(WPRMMixin, AbstractScraper):
    @classmethod
    def host(cls):
        return "savoringthegood.com"
