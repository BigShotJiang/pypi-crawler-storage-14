SUPPRESS_EXCEPTIONS = True


# The most powerful feature is adding custom plugins
# for example to add "inner-most" plugin:
# PLUGINS += (
#     "path.to.my.custom_plugin"
# )
#
# and to add "outer-most" plugin:
# PLUGINS = (
#     "path.to.my.custom_plugin",
# ) + PLUGINS
