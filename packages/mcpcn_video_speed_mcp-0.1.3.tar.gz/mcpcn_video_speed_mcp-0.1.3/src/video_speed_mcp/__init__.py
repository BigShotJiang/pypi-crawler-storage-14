"""
Video Speed MCP Server

A MCP server for changing video playback speed with proper audio sync.
"""

__version__ = "0.1.0"

from .main import main

__all__ = ["main"]