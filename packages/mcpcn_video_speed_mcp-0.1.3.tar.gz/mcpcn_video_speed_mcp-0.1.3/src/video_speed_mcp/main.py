from mcp.server.fastmcp import FastMCP
import ffmpeg
import os
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import tempfile

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

package = "video-speed-mcp"

log_dir = Path(tempfile.gettempdir()) / package
log_dir.mkdir(exist_ok=True)
log_file = log_dir / "debug.log"

file_handler = RotatingFileHandler(
    str(log_file), maxBytes=5_000_000, backupCount=3, encoding="utf-8"
)
file_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
)
logger.addHandler(file_handler)
logger.propagate = False

FFMPEG_BINARY = os.environ.get("FFMPEG_BINARY")
FFPROBE_BINARY = os.environ.get("FFPROBE_BINARY")


def _ffmpeg_run(stream_spec, **kwargs):
    if "overwrite_output" not in kwargs:
        kwargs["overwrite_output"] = True
    return ffmpeg.run(stream_spec, cmd=FFMPEG_BINARY, **kwargs)


def _ffprobe_probe(path: str, **kwargs):
    return ffmpeg.probe(path, cmd=FFPROBE_BINARY, **kwargs)


def _prepare_path(input_path: str, output_path: str) -> None:
    if not os.path.exists(input_path):
        raise RuntimeError(f"Error: Input file not found at {input_path}")
    try:
        parent_dir = os.path.dirname(output_path)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
    except Exception as e:
        raise RuntimeError(
            f"Error creating output directory for {output_path}: {str(e)}"
        )
    if os.path.exists(output_path):
        raise RuntimeError(
            f"Error: Output file already exists at {output_path}. Please choose a different path or delete the existing file."
        )


mcp = FastMCP("VideoSpeedServer")


def _process_single_video(
    video_path: str, output_video_path: str, speed_factor: float
) -> str:
    """处理单个视频的调速。"""
    _prepare_path(video_path, output_video_path)

    atempo_value = speed_factor
    atempo_filters = []
    if speed_factor < 0.5:
        while atempo_value < 0.5:
            atempo_filters.append("atempo=0.5")
            atempo_value *= 2
        if atempo_value < 0.99:
            atempo_filters.append(f"atempo={atempo_value}")
    elif speed_factor > 2.0:
        while atempo_value > 2.0:
            atempo_filters.append("atempo=2.0")
            atempo_value /= 2
        if atempo_value > 1.01:
            atempo_filters.append(f"atempo={atempo_value}")
    else:
        atempo_filters.append(f"atempo={speed_factor}")

    probe = _ffprobe_probe(video_path)
    has_audio = any(s["codec_type"] == "audio" for s in probe["streams"])

    input_stream = ffmpeg.input(video_path)

    pts_factor = 1.0 / speed_factor
    video = input_stream.video.filter("setpts", f"{pts_factor}*PTS")

    if has_audio:
        audio = input_stream.audio
        for filter_str in atempo_filters:
            if filter_str == "atempo=0.5":
                tempo_val = 0.5
            elif filter_str == "atempo=2.0":
                tempo_val = 2.0
            elif filter_str.startswith("atempo="):
                tempo_val = float(filter_str.replace("atempo=", ""))
            else:
                tempo_val = speed_factor
            audio = audio.filter("atempo", tempo_val)

        output = ffmpeg.output(
            video, audio, output_video_path, vcodec="libx264", acodec="aac"
        )
    else:
        output = ffmpeg.output(video, output_video_path, vcodec="libx264")

    _ffmpeg_run(output, capture_stdout=True, capture_stderr=True)
    return output_video_path


@mcp.tool()
def change_video_speed(
    video_paths: list[str], output_dir: str, speed_factor: float
) -> str:
    """改变视频的播放速度（同时处理音频）。

    Args:
        video_paths: 输入视频文件路径列表，支持多个视频文件。
        output_dir: 输出目录路径，处理后的视频将保存到此目录。
        speed_factor: 倍速因子（>0，例如 2.0 表示 2 倍速，0.5 表示半速）。

    Returns:
        A status message indicating success or failure.
    """
    if speed_factor <= 0:
        raise RuntimeError("Error: Speed factor must be positive.")

    if not video_paths:
        raise RuntimeError("Error: No video files provided.")

    # 确保输出目录存在
    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    results = []
    errors = []

    for video_path in video_paths:
        try:
            # 生成输出文件路径
            filename = os.path.basename(video_path)
            name, ext = os.path.splitext(filename)
            output_filename = f"{name}_speed_{speed_factor}x{ext}"
            output_video_path = os.path.join(output_dir, output_filename)

            output_path = _process_single_video(video_path, output_video_path, speed_factor)
            results.append(output_path)
            logger.info(f"Successfully processed: {video_path} -> {output_path}")
        except ffmpeg.Error as e:
            error_message = e.stderr.decode("utf8") if e.stderr else str(e)
            errors.append(f"{video_path}: {error_message}")
            logger.error(f"Error processing {video_path}: {error_message}")
        except Exception as e:
            errors.append(f"{video_path}: {str(e)}")
            logger.error(f"Error processing {video_path}: {str(e)}")

    # 构建返回消息
    message_parts = []
    if results:
        message_parts.append(f"Successfully processed {len(results)} video(s) with speed factor {speed_factor}x:")
        for path in results:
            message_parts.append(f"  - {path}")

    if errors:
        message_parts.append(f"\nFailed to process {len(errors)} video(s):")
        for error in errors:
            message_parts.append(f"  - {error}")

    result_message = "\n".join(message_parts)

    # 如果全部失败，抛出异常以设置 isError: true
    if not results and errors:
        raise RuntimeError(result_message)

    return result_message


def main():
    """Main entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
