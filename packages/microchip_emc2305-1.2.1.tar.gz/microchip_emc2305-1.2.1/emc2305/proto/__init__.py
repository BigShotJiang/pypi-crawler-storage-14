"""
Protocol Definitions

gRPC protocol buffers for remote control (optional feature).
"""

# Proto definitions can be added if gRPC support is needed
