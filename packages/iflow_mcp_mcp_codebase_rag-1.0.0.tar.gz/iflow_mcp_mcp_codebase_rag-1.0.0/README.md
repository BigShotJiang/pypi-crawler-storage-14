
# Codebase RAG MCP Server

This MCP server provides semantic codebase search and file retrieval using embeddings and a PostgreSQL database. It exposes tools for searching code, listing files, and retrieving file contents.

## Features

- **Semantic Code Search**: Uses Voyage embedding model to convert queries into vectors and search code snippets by similarity.
- **File Listing**: Lists all tracked files in the codebase.
- **File Content Retrieval**: Fetches the full content of a file by filename.

## Tools

- **search_codebase**
  - Returns code snippets relevant to the query.
  - Inputs:
    - `query` (string): Search terms

- **get_files**
  - Lists all files in the codebase.

- **get_file_content**
  - Returns the content of the specified file.
  - Inputs:
    - `filename` (string): Filename

## Configuration

### Getting a Voyage API Key

1. Sign up for a [Voyage API account](https://voyageapi.com/)
2. Generate your API key from the dashboard

### Environment Variables

- `DATABASE_URL`: PostgreSQL connection string.
- `VOYAGE_API_KEY`: API key for embedding model.
- `EMBEDDING_TABLE`: Table name for code embeddings.
- `TRACKING_TABLE`: Table name for file tracking.

### Docker

```json
{
  "mcpServers": {
    "codebase-rag": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "-e",
        "DATABASE_URL",
        "-e",
        "VOYAGE_API_KEY",
        "-e",
        "EMBEDDING_TABLE",
        "-e",
        "TRACKING_TABLE",
        "-p",
        "8080:8080",
        "allentcm/mcp-codebase-rag:1.0.0"
      ],
      "env": {
        "DATABASE_URL": "postgres://cocoindex:cocoindex@localhost/cocoindex",
        "VOYAGE_API_KEY": "voyage_api_key",
        "EMBEDDING_TABLE": "codebase__code_embeddings",
        "TRACKING_TABLE": "codebase__cocoindex_tracking"
      }
    }
  }
}
```

## License

This MCP server is licensed under the MIT License. You are free to use, modify, and distribute the software, subject to the terms and conditions of the MIT License. For more details, please see the LICENSE file in the project repository.
