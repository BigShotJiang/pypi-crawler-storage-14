
# I floss with my hair, and who cares? My pet rock does.

from ._classes import *
init()

from .window import *
from .math import *
from .gui import *
from .event import *
from .constants import *
from .draw import *
from .audio import *
from .load import *
from .file import *
from .util import *
from .camera import *
from .collision import *
from .image import *

__version__ = "0.1.5"
__copyright__ = "© Annes - 2025"

# im afraid there will be a segfault
