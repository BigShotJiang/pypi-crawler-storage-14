"""Test suite initialization for multimodal package."""

# This file makes the tests directory a Python package
