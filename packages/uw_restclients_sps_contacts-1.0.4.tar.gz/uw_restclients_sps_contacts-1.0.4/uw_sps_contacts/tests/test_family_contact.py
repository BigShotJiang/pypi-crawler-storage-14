# Copyright 2025 UW-IT, University of Washington
# SPDX-License-Identifier: Apache-2.0

import json
import mock
from unittest import TestCase
from restclients_core.exceptions import DataFailureException
from restclients_core.models import MockHTTP
from uw_sps_contacts import FamilyContacts
from uw_sps_contacts.models import FamilyContact


class FamilyContactsTest(TestCase):

    def test_family_contact_url(self):
        contact = FamilyContacts()
        self.assertEqual(
            "/student/registration/v1/address/12345",
            contact._get_contact_url(12345),
        )

    @mock.patch.object(FamilyContacts, "_get_resource")
    def test_error_401(self, mock):
        response = MockHTTP()
        response.status = 401
        response.data = "Not Authorized"
        mock.return_value = response
        with self.assertRaises(DataFailureException):
            FamilyContacts().get_contact(12345)

    def test_family_contact_javerage(self):
        fcontacts = FamilyContacts()
        contact = fcontacts.get_contact(12345)

        self.assertEqual('NAME,PARENT', contact.name)
        self.assertEqual('2064444444', contact.phoneNumber)

        resp = fcontacts._get_resource(12345, clear_cached_token=True)
        self.assertIsNotNone(resp)

    def test_json_data(self):
        contact = FamilyContact()
        contact.name = "Jake Doe"
        contact.phoneNumber = "5555551234"
        self.assertIsInstance(contact.json_data(), dict)
        string_data = (
            '{"name": "Jake Doe",'
            '"phoneNumber": "5555551234"}'
        )
        self.assertEqual(contact.json_data(), json.loads(string_data))
