from exegol.config.ConstantConfig import __version__

__title__ = "exegol"
