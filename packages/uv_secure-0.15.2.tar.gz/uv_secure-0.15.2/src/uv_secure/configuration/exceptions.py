class UvSecureConfigurationError(Exception):
    pass
