"""sissf - Spatial Intelligence Scene State Format"""

__version__ = "0.0.1"
