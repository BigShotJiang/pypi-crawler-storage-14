# sissf

Spatial Intelligence Scene State Format:
* A platform-agnostic, human and machine readable 3D scene representation standard.
* A Python library for working with the Spatial Intelligence Scene State Format - used by [sisglib](https://github.com/3D-Intelligence/sisglib) (Spatial Intelligence Scene Generation Library).

**Status:** Under active development. Full release coming soon.

## About

Spatial Intelligence is pioneering the next generation of artificial intelligence, enabling machines to understand, construct, and interact with the 3D world with unprecedented accuracy and efficiency.

Repository: [Coming Soon]

For more information: [spatial-intelligence.co.uk](spatial-intelligence.co.uk)  
For inquiries: [hello@spatial-intelligence.co.uk](mailto:hello@spatial-intelligence.co.uk)