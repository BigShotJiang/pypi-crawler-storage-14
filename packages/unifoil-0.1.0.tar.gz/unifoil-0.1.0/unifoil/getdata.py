import csv
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional
import urllib.request
import urllib.error


@dataclass(frozen=True)
class DownloadSpec:
    """Describes a single remote file that should be fetched."""

    url: str
    filename: str
    description: str
    convert_tsv_to_csv: bool = False


class GetData:
    """
    Helper to download and stage UniFoil data assets.

    The class focuses on automation tasks such as fetching CSV metadata files
    that are mandatory for the rest of the tooling to run.
    """

    # Minimal manifest – expand as we identify additional compulsory assets.
    COMPULSORY_FILES: List[DownloadSpec] = [
        DownloadSpec(
            url="https://dataverse.harvard.edu/api/access/datafile/11478347",
            filename="Airfoil_Case_Data_Trans_Lam.csv",
            description="Transition/laminar case metadata",
            convert_tsv_to_csv=True,
        ),
        DownloadSpec(
            url="https://dataverse.harvard.edu/api/access/datafile/11478352",
            filename="Airfoil_Case_Data_turb.csv",
            description="Fully turbulent case metadata",
            convert_tsv_to_csv=True,
        ),
    ]

    def __init__(self, data_root: Optional[str] = None):
        self.data_root = Path(data_root) if data_root else Path(os.getcwd())
        self.data_root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def get_compulsory(self, overwrite: bool = False, extra_items: Optional[Iterable[DownloadSpec]] = None) -> List[Path]:
        """
        Download all files that are absolutely required to run UniFoil helpers.

        Parameters
        ----------
        overwrite : bool
            If True, existing files will be replaced.
        extra_items : Iterable[DownloadSpec], optional
            Additional assets to download alongside the built-in set.

        Returns
        -------
        list[pathlib.Path]
            Paths to the downloaded (or already existing) files.
        """
        manifest = list(self.COMPULSORY_FILES)
        if extra_items:
            manifest.extend(extra_items)

        saved_paths: List[Path] = []
        for spec in manifest:
            target = self.data_root / spec.filename

            if target.exists() and not overwrite:
                print(f"[getdata] Skipping '{target.name}' (already exists).")
                saved_paths.append(target)
                continue

            try:
                downloaded_path = self._download_to_temp(spec.url, spec.description)
            except Exception as exc:  # pragma: no cover - network failure path
                print(f"[getdata] Failed downloading '{spec.description}': {exc}")
                continue

            final_path = target
            try:
                if spec.convert_tsv_to_csv:
                    final_path = self._convert_tsv_to_csv(downloaded_path, target)
                else:
                    self._move_into_place(downloaded_path, target)
                saved_paths.append(final_path)
                print(f"[getdata] Saved '{final_path.name}'.")
            finally:
                if downloaded_path.exists():
                    downloaded_path.unlink(missing_ok=True)

        return saved_paths

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _download_to_temp(self, url: str, label: str) -> Path:
        """
        Stream the remote asset into a temporary file.
        """
        tmp_fd, tmp_path = tempfile.mkstemp(prefix="unifoil_", suffix=".download")
        tmp_file = Path(tmp_path)
        os.close(tmp_fd)

        print(f"[getdata] Downloading {label} ...")
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; UniFoil-GetData/1.0)",
                "Accept": "*/*",
            },
        )
        try:
            with urllib.request.urlopen(request) as response, open(tmp_file, "wb") as dst:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    dst.write(chunk)
        except urllib.error.URLError as exc:
            tmp_file.unlink(missing_ok=True)
            raise RuntimeError(f"Download error: {exc}") from exc

        return tmp_file

    def _convert_tsv_to_csv(self, source_path: Path, target_path: Path) -> Path:
        """
        Convert a TSV file to CSV format.
        """
        target_path.parent.mkdir(parents=True, exist_ok=True)
        with open(source_path, "r", encoding="utf-8") as src, open(target_path, "w", newline="", encoding="utf-8") as dst:
            reader = csv.reader(src, delimiter="\t")
            writer = csv.writer(dst)
            for row in reader:
                writer.writerow(row)
        return target_path

    @staticmethod
    def _move_into_place(source_path: Path, target_path: Path) -> None:
        target_path.parent.mkdir(parents=True, exist_ok=True)
        source_path.replace(target_path)
