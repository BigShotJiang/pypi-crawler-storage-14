# coding=utf-8
from .._impl import (
    timeseries_channelmetadata_ChannelMetadataService as ChannelMetadataService,
)

__all__ = [
    'ChannelMetadataService',
]

