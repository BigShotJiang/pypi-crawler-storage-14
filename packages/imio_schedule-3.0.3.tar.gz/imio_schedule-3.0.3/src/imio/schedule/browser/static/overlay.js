/* The jQuery here above will load a jQuery popup */

jQuery(function($){
    // parcel history popup
    $('#task_status a').prepOverlay({
       subtype: 'ajax',
   });
});
