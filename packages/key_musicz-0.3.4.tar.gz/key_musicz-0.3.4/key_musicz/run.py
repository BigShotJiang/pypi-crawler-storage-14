#

from .conf import test
from buildz import pyz

pyz.lc(locals(), test)