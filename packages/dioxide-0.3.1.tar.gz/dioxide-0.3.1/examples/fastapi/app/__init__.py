"""FastAPI example application using dioxide for dependency injection."""
