```{include} ../README.md

```

```{toctree}
:caption: API Documentation
:maxdepth: 2
:glob:

autoapi/nucleotide_archive_mcp/index
```
