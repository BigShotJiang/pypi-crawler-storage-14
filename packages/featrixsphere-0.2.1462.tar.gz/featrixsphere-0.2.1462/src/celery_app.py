#!/usr/bin/env python3
"""
Celery app for async batch prediction jobs.
Training jobs continue to use the existing featrix_queue system.
"""

from celery import Celery
from config import config
import json
import traceback
import sys
import pickle
import gc
import logging
from pathlib import Path

# Set up proper logging for Celery
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)-8s] %(name)-45s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Install Featrix exception hook for better error tracking
try:
    from lib.featrix_debug import install_featrix_excepthook
    install_featrix_excepthook()
except Exception:
    pass  # Don't fail if debug module not available

# CRITICAL: Set up Python path BEFORE any featrix imports to avoid circular dependencies
lib_path = Path(__file__).parent / "lib"
current_path = Path(__file__).parent

if str(lib_path.resolve()) not in sys.path:
    sys.path.insert(0, str(lib_path.resolve()))
if str(current_path.resolve()) not in sys.path:
    sys.path.insert(0, str(current_path.resolve()))

logger.info(f"🔧 Celery module loading - Python paths set up")
logger.info(f"  lib_path: {lib_path.resolve()}")
logger.info(f"  current_path: {current_path.resolve()}")

# Import NON-CUDA modules at module level only
# CRITICAL: Do NOT import torch here - causes CUDA fork issues
try:
    import numpy as np
    import pandas as pd
    logger.info(f"✅ Non-CUDA modules imported at module level")
except ImportError as e:
    logger.warning(f"⚠️ Core modules not available: {e}")

# Will check torch availability inside tasks after fork
TORCH_AVAILABLE = False

try:
    from featrix_queue import load_session
    FEATRIX_QUEUE_AVAILABLE = True
    logger.info(f"✅ featrix_queue imported at module level")
except ImportError as e:
    FEATRIX_QUEUE_AVAILABLE = False
    logger.warning(f"⚠️ featrix_queue not available: {e}")

# CRITICAL: Do NOT import featrix modules at module level
# They contain torch imports which cause CUDA fork issues in Celery
# Will import them inside tasks after the fork happens
logger.info(f"🔧 Skipping featrix imports at module level to avoid CUDA fork issues")
logger.info(f"🔧 Will import torch and featrix modules inside task after fork")

# Initialize Celery app
app = Celery('sphere_predictions')

# Configure Celery to use Redis as broker and result backend
app.conf.update(
    broker_url='redis://localhost:6379/1',
    result_backend='redis://localhost:6379/1',
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='America/New_York',
    enable_utc=True,
    result_expires=3600,  # Results expire after 1 hour
    task_routes={
        'celery_app.predict_batch': {'queue': 'predictions'},
        'celery_app.project_training_movie_frame': {'queue': 'cpu_worker'},
        'celery_app.create_structured_data': {'queue': 'cpu_worker'},
        'celery_app.run_clustering': {'queue': 'cpu_worker'},
        'celery_app.dump_to_backplane': {'queue': 'cpu_worker'},
    },
    worker_prefetch_multiplier=1,  # One task at a time for GPU jobs
    worker_max_tasks_per_child=10,  # Restart worker after 10 tasks to prevent memory leaks
    task_acks_late=True,
    worker_disable_rate_limits=True,
    # Logging configuration
    worker_log_format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    worker_task_log_format='%(asctime)s - %(name)s - %(levelname)s - [%(task_name)s(%(task_id)s)] %(message)s',
    worker_hijack_root_logger=False,  # Let our logging config work
)

@app.task(bind=True)
def predict_batch(self, session_id: str, records: list, prediction_options: dict = None):
    """
    Celery task for batch predictions.
    
    Args:
        session_id: Session ID with trained single predictor
        records: List of record dictionaries to predict
        prediction_options: Optional parameters (batch_size, etc.)
    
    Returns:
        dict with predictions or error info
    """
    import pickle
    from pathlib import Path
    
    logger.info(f"🚀 CELERY TASK STARTED - Session: {session_id}, Records: {len(records)}")
    
    try:
        # Update task state to indicate processing has started
        self.update_state(
            state='PROGRESS',
            meta={
                'current': 0,
                'total': len(records),
                'status': 'Loading model...'
            }
        )
        
        # Paths already set up at module level - no need to repeat
        logger.info(f"🔧 Python paths already configured at module level")
        
        # Load the session and single predictor
        if not FEATRIX_QUEUE_AVAILABLE:
            raise ImportError("featrix_queue module not available")
            
        logger.info(f"🔧 Loading session {session_id}...")
        try:
            session = load_session(session_id)
            logger.info(f"✅ Session loaded successfully")
        except Exception as session_error:
            logger.error(f"❌ SESSION LOAD FAILED: {session_error}")
            logger.error(f"❌ Session traceback: {traceback.format_exc()}")
            raise
        
        # Get the single predictor path (backwards compatible)
        single_predictors = session.get("single_predictors")
        single_predictor = session.get("single_predictor")
        
        # Set prediction options (need this before accessing it below)
        options = prediction_options or {}
        
        # Helper function to generate predictor ID
        def generate_predictor_id(predictor_path: str) -> str:
            import hashlib
            import os
            filename = os.path.basename(predictor_path) if predictor_path else 'unknown'
            # Remove .pickle extension from user-facing ID
            if filename.endswith('.pickle'):
                filename = filename[:-7]
            path_hash = hashlib.md5(predictor_path.encode('utf-8')).hexdigest()[:8]
            return f"{filename}_{path_hash}"
        
        # NEW: Check if predictor_id or target_column specified in options
        requested_predictor_id = options.get('predictor_id')
        requested_target_column = options.get('target_column')
        logger.info(f"🔍 CELERY PREDICT_BATCH - predictor_id='{requested_predictor_id}', target_column='{requested_target_column}'")
        
        predictor_path = None
        if single_predictors and isinstance(single_predictors, list):
            # NEW: If multiple predictors exist, REQUIRE target_column or predictor_id
            if len(single_predictors) > 1 and not requested_predictor_id and not requested_target_column:
                # Get available targets for error message
                available_targets = []
                available_ids = []
                for pred_path in single_predictors:
                    # Get predictor_id
                    if Path(pred_path).exists():
                        available_ids.append(generate_predictor_id(pred_path))
                    
                    # Get target_column from metadata
                    metadata_path = str(Path(pred_path).parent / "model_metadata.json")
                    if Path(metadata_path).exists():
                        try:
                            import json
                            with open(metadata_path, 'r') as f:
                                metadata = json.load(f)
                                target_col = metadata.get('target_column')
                                if target_col:
                                    available_targets.append(target_col)
                        except Exception:
                            pass
                
                error_msg = f"Multiple predictors found ({len(single_predictors)}) - must specify 'target_column' or 'predictor_id'. Available targets: {available_targets}, Available IDs: {available_ids}"
                logger.error(f"❌ CELERY PREDICT_BATCH - {error_msg}")
                raise ValueError(error_msg)
            
            # PRIORITY 1: predictor_id (most precise)
            if requested_predictor_id:
                logger.info(f"🔍 CELERY PREDICT_BATCH - Looking for predictor with predictor_id='{requested_predictor_id}'")
                predictor_found = False
                available_predictor_ids = []
                
                for pred_path in single_predictors:
                    if Path(pred_path).exists():
                        current_predictor_id = generate_predictor_id(pred_path)
                        available_predictor_ids.append(current_predictor_id)
                        
                        if current_predictor_id == requested_predictor_id:
                            predictor_path = pred_path
                            predictor_found = True
                            logger.info(f"✅ CELERY PREDICT_BATCH - Found matching predictor by ID: {pred_path}")
                            break
                
                if not predictor_found:
                    raise ValueError(f"No predictor found for predictor_id '{requested_predictor_id}'. Available IDs: {available_predictor_ids}")
            
            # PRIORITY 2: target_column (semantic match)
            elif requested_target_column:
                logger.info(f"🔍 CELERY PREDICT_BATCH - Looking for predictor with target_column='{requested_target_column}'")
                predictor_found = False
                
                for pred_path in single_predictors:
                    # Skip None or invalid paths
                    if not pred_path:
                        logger.warning(f"⚠️  CELERY PREDICT_BATCH - Skipping None predictor path in list")
                        continue
                    
                    # Load predictor metadata to check target_column
                    metadata_path = str(Path(pred_path).parent / "model_metadata.json")
                    if Path(metadata_path).exists():
                        try:
                            import json
                            with open(metadata_path, 'r') as f:
                                metadata = json.load(f)
                                target_col = metadata.get('target_column')
                                
                                logger.info(f"🔍 CELERY PREDICT_BATCH - Checking predictor {pred_path}: target_column='{target_col}'")
                                
                                if target_col == requested_target_column:
                                    predictor_path = pred_path
                                    predictor_found = True
                                    logger.info(f"✅ CELERY PREDICT_BATCH - Found matching predictor: {pred_path}")
                                    break
                        except Exception as metadata_error:
                            logger.warning(f"⚠️  CELERY PREDICT_BATCH - Could not read metadata for {pred_path}: {metadata_error}")
                            continue
                
                if not predictor_found:
                    raise ValueError(f"No predictor found for target column '{requested_target_column}'")
            
            # PRIORITY 3: Single predictor fallback (backwards compatibility)
            else:
                # Only allow fallback if there's exactly one predictor
                if len(single_predictors) == 1:
                    predictor_path = single_predictors[0]
                    logger.info(f"🔍 CELERY PREDICT_BATCH - Single predictor session, using: {predictor_path}")
                else:
                    # This should never be reached due to check above, but keep for safety
                    raise ValueError(f"Multiple predictors found ({len(single_predictors)}) but no target_column or predictor_id specified")
        elif single_predictor:
            predictor_path = single_predictor
        else:
            raise ValueError("No single predictor found in session")
        
        if not predictor_path or not Path(predictor_path).exists():
            raise ValueError(f"Single predictor not found at: {predictor_path}")
        
        # Update progress
        self.update_state(
            state='PROGRESS',
            meta={
                'current': 0,
                'total': len(records),
                'status': 'Loading single predictor model...'
            }
        )
        
        # NEW APPROACH: Use subprocess to avoid all import/fork/CUDA issues
        logger.info(f"🚀 Using subprocess approach to avoid fork/CUDA issues")
        logger.info(f"📦 Predictor path: {predictor_path}")
        
        # Create temporary files for input/output
        import tempfile
        import uuid
        import subprocess
        import json
        import redis
        import time
        
        # Initialize Redis for progress monitoring
        try:
            redis_client = redis.Redis(host='localhost', port=6379, db=1, decode_responses=True)
            redis_available = True
            logger.info(f"✅ Redis connected for progress monitoring")
        except Exception as redis_error:
            logger.warning(f"⚠️ Redis not available for progress monitoring: {redis_error}")
            redis_available = False
        
        temp_dir = Path("/tmp") / f"celery_prediction_{uuid.uuid4().hex[:8]}"
        temp_dir.mkdir(exist_ok=True)
        
        input_file = temp_dir / "input.json"
        output_file = temp_dir / "output.json"
        
        logger.info(f"📁 Created temp directory: {temp_dir}")
        
        # Set prediction options
        options = prediction_options or {}
        
        try:
            # Write input data to file
            with open(input_file, 'w') as f:
                json.dump({
                    'session_id': session_id,
                    'predictor_path': predictor_path,
                    'records': records,
                    'batch_size': options.get('batch_size', 256)
                }, f)
            logger.info(f"✅ Written {len(records)} records to {input_file}")
            
            # Run subprocess prediction
            script_path = Path(__file__).parent / "standalone_prediction.py"
            
            logger.info(f"🔧 Running subprocess: python {script_path} {input_file} {output_file}")
            
            # Use subprocess to call the standalone prediction script
            import sys
            
            # Get task ID for Redis progress tracking
            task_id = self.request.id
            redis_key = f"prediction_progress:{task_id}"
            
            # Start subprocess asynchronously - write output to log file to avoid pipe deadlock
            logger.info(f"🚀 Starting subprocess with Redis progress tracking...")
            
            # Create log files in temp directory
            subprocess_log = temp_dir / "subprocess.log"
            subprocess_err = temp_dir / "subprocess_error.log"
            
            with open(subprocess_log, 'w') as stdout_file, open(subprocess_err, 'w') as stderr_file:
                process = subprocess.Popen(
                    [sys.executable, str(script_path), str(input_file), str(output_file), task_id],
                    stdout=stdout_file,
                    stderr=stderr_file,
                    text=True
                )
                
                # Poll for subprocess completion while monitoring Redis progress
                start_time = time.time()
                last_progress_percentage = 0
                
                while process.poll() is None:
                    # Check for timeout (1 hour)
                    if time.time() - start_time > 3600:
                        process.terminate()
                        process.wait()
                        raise Exception("Prediction subprocess timed out after 1 hour")
                    
                    # Check Redis for progress updates
                    if redis_available:
                        try:
                            progress_data = redis_client.get(redis_key)
                            if progress_data:
                                progress_info = json.loads(progress_data)
                                current = progress_info.get('current', 0)
                                total = progress_info.get('total', 100)
                                status = progress_info.get('status', 'Processing...')
                                percentage = progress_info.get('percentage', 0)
                                
                                # Only update Celery state if progress percentage has changed
                                if percentage != last_progress_percentage:
                                    self.update_state(
                                        state='PROGRESS',
                                        meta={
                                            'current': current,
                                            'total': total,
                                            'status': status,
                                            'percentage': percentage,
                                            'timestamp': progress_info.get('timestamp')
                                        }
                                    )
                                    last_progress_percentage = percentage
                                    logger.info(f"📊 Relayed progress: {percentage}% - {status}")
                        except Exception as redis_err:
                            logger.warning(f"Failed to read progress from Redis: {redis_err}")
                    
                    # Sleep briefly to avoid busy polling
                    time.sleep(2)
            
            # Check final return code
            if process.returncode != 0:
                # Read error logs
                with open(subprocess_err, 'r') as f:
                    stderr_content = f.read()
                logger.error(f"❌ Subprocess failed with return code {process.returncode}")
                logger.error(f"❌ STDERR: {stderr_content}")
                raise Exception(f"Prediction subprocess failed: {stderr_content}")
            
            logger.info(f"✅ Subprocess completed successfully")
            
            # Log subprocess output for debugging
            if subprocess_log.exists():
                with open(subprocess_log, 'r') as f:
                    stdout_content = f.read()
                    if stdout_content:
                        logger.info(f"📊 Subprocess output logged to {subprocess_log}")
            
            # Read results from output file
            if not output_file.exists():
                raise Exception(f"Output file not created: {output_file}")
            
            with open(output_file, 'r') as f:
                result_data = json.load(f)
            
            logger.info(f"✅ Results loaded: {result_data.get('successful_predictions', 0)} successful predictions")
            
            # Handle both JSON Tables and legacy formats
            output_format = result_data.get('format', 'legacy')
            logger.info(f"📊 Output format: {output_format}")
            
            if output_format == 'json_tables' and 'results_table' in result_data:
                # Convert JSON Tables to legacy format for backward compatibility
                # But KEEP the results_table too for consistent API format
                try:
                    from jsontables import JSONTablesDecoder
                    
                    results_table = result_data['results_table']
                    records_with_predictions = JSONTablesDecoder.to_records(results_table)
                    
                    # Convert to legacy prediction format for backward compatibility
                    predictions = []
                    for i, record in enumerate(records_with_predictions):
                        # Extract prediction data from the enhanced record
                        prediction_obj = {
                            'row_index': record.get('row_index', i),
                            'prediction_id': None,  # Not stored in JSON Tables format
                            'error': record.get('prediction_error'),
                            'metadata': {}
                        }
                        
                        # Extract the actual prediction probabilities
                        if record.get('prediction_error') is None:
                            # Look for pred_* columns
                            prediction_probs = {}
                            for key, value in record.items():
                                if key.startswith('pred_') and key != 'pred_':
                                    class_name = key[5:]  # Remove 'pred_' prefix
                                    prediction_probs[class_name] = value
                            
                            if prediction_probs:
                                prediction_obj['prediction'] = prediction_probs
                            elif 'prediction' in record:
                                prediction_obj['prediction'] = record['prediction']
                            else:
                                prediction_obj['prediction'] = None
                                prediction_obj['error'] = "No prediction data found"
                            
                            # Add guardrails if available
                            if 'guardrails' in record:
                                prediction_obj['metadata']['guardrails'] = record['guardrails']
                        else:
                            prediction_obj['prediction'] = None
                        
                        predictions.append(prediction_obj)
                    
                    # Add legacy format alongside JSON Tables format
                    result_data['predictions'] = predictions
                    # Keep results_table as-is for consistent API format
                    logger.info(f"✅ Added legacy predictions format alongside JSON Tables: {len(predictions)} predictions")
                    
                except ImportError:
                    logger.warning(f"⚠️ JSON Tables not available for conversion, keeping raw format")
                except Exception as convert_error:
                    logger.warning(f"⚠️ Failed to convert JSON Tables format: {convert_error}")
                    # Keep the original format but log the issue
            
            elif output_format == 'legacy' and 'predictions' in result_data:
                logger.info(f"✅ Using legacy prediction format")
            else:
                logger.warning(f"⚠️ Unknown output format: {output_format}")
            
            # DON'T call update_state(state='SUCCESS') - Celery does this automatically
            # when the task returns. Calling it manually overwrites the return value!
            # Just update progress one final time with PROGRESS state
            self.update_state(
                state='PROGRESS',  # Use PROGRESS, not SUCCESS!
                meta={
                    'current': len(records),
                    'total': len(records),
                    'status': f"Completed: {result_data.get('successful_predictions', 0)} successful, {result_data.get('failed_predictions', 0)} failed",
                    'output_format': output_format,
                    'percentage': 100
                }
            )
            
            # Log what we're returning for debugging
            logger.info(f"📦 Returning result_data keys: {list(result_data.keys())}")
            logger.info(f"📦 results_table type: {type(result_data.get('results_table'))}")
            logger.info(f"📦 predictions count: {len(result_data.get('predictions', []))}")
            
            # Return the full result - Celery will automatically set state to SUCCESS
            return result_data
            
        except subprocess.TimeoutExpired:
            logger.error(f"❌ Subprocess timed out after 1 hour")
            raise Exception("Prediction subprocess timed out")
            
        except Exception as subprocess_error:
            logger.error(f"❌ Subprocess error: {subprocess_error}")
            logger.error(f"❌ Subprocess traceback: {traceback.format_exc()}")
            raise Exception(f"Prediction subprocess failed: {subprocess_error}")
            
        finally:
            # Cleanup temp files
            try:
                if input_file.exists():
                    input_file.unlink()
                if output_file.exists():
                    output_file.unlink()
                temp_dir.rmdir()
                logger.info(f"✅ Cleaned up temp directory: {temp_dir}")
            except Exception as cleanup_err:
                logger.warning(f"⚠️ Failed to cleanup temp files: {cleanup_err}")

        
    except Exception as e:
        # Log the full error
        error_msg = str(e)
        error_traceback = traceback.format_exc()
        
        # Log to worker logs for debugging
        logger.error(f"CELERY WORKER ERROR: {error_msg}")
        logger.error(f"CELERY WORKER TRACEBACK:\n{error_traceback}")
        
        # Return error state instead of re-raising
        return {
            'success': False,
            'error': error_msg,
            'traceback': error_traceback,
            'session_id': session_id,
            'total_records': len(records) if 'records' in locals() else 0,
            'exc_type': type(e).__name__,
            'exc_message': str(e)
        }
        
    finally:
        # Minimal cleanup since subprocess handles GPU/model cleanup
        try:
            import gc
            gc.collect()
            logger.info(f"✅ Python garbage collection completed")
        except Exception as cleanup_error:
            logger.warning(f"Cleanup failed: {cleanup_error}")

@app.task(bind=True)
def project_training_movie_frame(self, job_spec: dict):
    """
    Celery task to generate a training movie frame from an embedding space checkpoint on CPU.
    
    This is triggered every time an ES checkpoint is saved (best model or epoch checkpoint).
    It loads the checkpoint, encodes points using the embedding space, and saves a single frame.
    
    Args:
        job_spec: Dict containing:
            - checkpoint_path: Path to model checkpoint (.pt file)
            - data_snapshot_path: Path to saved data sample (.json)
            - output_dir: Where to save the projection
            - session_id: Session ID
            - epoch: Epoch number
    
    Returns:
        dict with success status and output file path
    """
    from pathlib import Path
    from lib.featrix.neural.movie_frame_task import generate_movie_frame_on_cpu
    
    logger.info(f"🎬 CELERY PROJECT_TRAINING_MOVIE_FRAME STARTED - Session: {job_spec.get('session_id')}, Epoch: {job_spec.get('epoch')}")
    
    try:
        # Update task state
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Loading checkpoint...',
                'epoch': job_spec.get('epoch'),
                'session_id': job_spec.get('session_id')
            }
        )
        
        # Extract parameters
        checkpoint_path = job_spec['checkpoint_path']
        data_snapshot_path = job_spec['data_snapshot_path']
        output_dir = job_spec['output_dir']
        session_id = job_spec['session_id']
        epoch = job_spec['epoch']
        
        # Validate paths
        if not Path(checkpoint_path).exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        if not Path(data_snapshot_path).exists():
            raise FileNotFoundError(f"Data snapshot not found: {data_snapshot_path}")
        
        logger.info(f"   Checkpoint: {checkpoint_path}")
        logger.info(f"   Data snapshot: {data_snapshot_path}")
        logger.info(f"   Output dir: {output_dir}")
        
        # Update progress
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Building projections...',
                'epoch': epoch
            }
        )
        
        # Call the existing movie frame generation function
        # This handles loading checkpoint, encoding points, and saving projections
        output_file = generate_movie_frame_on_cpu(
            checkpoint_path=checkpoint_path,
            data_snapshot_path=data_snapshot_path,
            epoch=epoch,
            output_dir=output_dir,
            session_id=session_id
        )
        
        if output_file:
            logger.info(f"✅ Projections built successfully: {output_file}")
            return {
                'success': True,
                'output_file': output_file,
                'epoch': epoch,
                'session_id': session_id
            }
        else:
            raise Exception("Projection building returned None")
            
    except Exception as e:
        logger.error(f"❌ PROJECT_TRAINING_MOVIE_FRAME FAILED: {e}")
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return {
            'success': False,
            'error': str(e),
            'epoch': job_spec.get('epoch'),
            'session_id': job_spec.get('session_id'),
            'traceback': traceback.format_exc()
        }

@app.task(bind=True)
def create_structured_data(self, job_spec: dict, job_id: str, data_file: str = None, session_id: str = None):
    """
    Celery task to create structured data from raw input (CSV/JSON).
    
    This processes the input data file, creates the SQLite database, and prepares
    the data for embedding space training.
    
    Args:
        job_spec: Dict containing job parameters (column_overrides, s3 paths, etc.)
        job_id: Job identifier
        data_file: Path to input data file (CSV/JSON)
        session_id: Session ID
    
    Returns:
        dict with output paths (sqlite_db, structured_data, etc.)
    """
    from pathlib import Path
    
    logger.info(f"📊 CELERY CREATE_STRUCTURED_DATA STARTED - Job: {job_id}, Session: {session_id}")
    
    try:
        # Update task state
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Loading data...',
                'job_id': job_id,
                'session_id': session_id
            }
        )
        
        # Import here to avoid CUDA fork issues
        if not FEATRIX_QUEUE_AVAILABLE:
            raise ImportError("featrix_queue module not available")
        
        from featrix_queue import run_create_structured_data
        
        # Convert data_file to Path if provided
        data_file_path = Path(data_file) if data_file else None
        
        # Call the existing function
        output = run_create_structured_data(
            job_spec=job_spec,
            job_id=job_id,
            data_file=data_file_path,
            session_id=session_id
        )
        
        # Update session with output (matching file-based queue behavior)
        from featrix_queue import load_session, save_session
        session = load_session(session_id)
        session = {**session, **output}
        save_session(session_id=session_id, session_doc=session, exist_ok=True)
        logger.info(f"✅ Session updated with structured data output")
        
        # CRITICAL: Call step_session to queue next job (matching file-based queue behavior)
        from featrix_queue import step_session
        import time
        logger.info(f"🚀 create_structured_data job {job_id} completed, calling step_session for session {session_id}")
        try:
            time.sleep(0.1)  # Small delay to ensure locks are released
            step_session(session_id=session_id)
            logger.info(f"✅ step_session completed successfully for session {session_id}")
        except Exception as step_error:
            logger.error(f"❌ CRITICAL: Failed to step session {session_id} after create_structured_data job {job_id}: {step_error}")
            logger.error(f"   This means the next job in the plan was NOT queued!")
            logger.error(f"   Traceback: {traceback.format_exc()}")
            # Don't fail the task - stepping is a separate concern
        
        logger.info(f"✅ Structured data created successfully")
        return {
            'success': True,
            'output': output,
            'job_id': job_id,
            'session_id': session_id
        }
        
    except Exception as e:
        logger.error(f"❌ CREATE_STRUCTURED_DATA FAILED: {e}")
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return {
            'success': False,
            'error': str(e),
            'job_id': job_id,
            'session_id': session_id,
            'traceback': traceback.format_exc()
        }

@app.task(bind=True)
def run_clustering(self, job_spec: dict):
    """
    Celery task to run clustering/projections for an embedding space.
    
    This generates the final projections and preview image for a trained embedding space.
    
    Args:
        job_spec: Dict containing:
            - model_path: Path to embedding space model (.pickle)
            - sqlite_db: Path to SQLite database
            - strings_cache: Path to strings cache (optional)
    
    Returns:
        dict with output paths (projections, preview_png)
    """
    from pathlib import Path
    
    logger.info(f"🔍 CELERY RUN_CLUSTERING STARTED")
    
    try:
        # Update task state
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Loading embedding space...',
                'model_path': job_spec.get('model_path')
            }
        )
        
        # Import here to avoid CUDA fork issues
        if not FEATRIX_QUEUE_AVAILABLE:
            raise ImportError("featrix_queue module not available")
        
        from featrix_queue import run_clustering_job
        
        # Extract parameters
        model_path = job_spec['model_path']
        sqlite_db = job_spec['sqlite_db']
        strings_cache = job_spec.get('strings_cache')
        
        logger.info(f"   Model path: {model_path}")
        logger.info(f"   SQLite DB: {sqlite_db}")
        
        # Update progress
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Running clustering...',
            }
        )
        
        # Call the existing function
        output = run_clustering_job(
            model_path=Path(model_path),
            sqlite_db=Path(sqlite_db),
            strings_cache=strings_cache
        )
        
        # Update session with output (matching file-based queue behavior)
        session_id = job_spec.get('session_id')
        if session_id:
            from featrix_queue import load_session, save_session
            try:
                session = load_session(session_id)
                session = {**session, **output}
                save_session(session_id=session_id, session_doc=session, exist_ok=True)
                logger.info(f"✅ Session updated with clustering output")
            except Exception as session_error:
                logger.warning(f"⚠️  Could not update session {session_id}: {session_error}")
        
        logger.info(f"✅ Clustering completed successfully")
        return {
            'success': True,
            'output': output
        }
        
    except Exception as e:
        logger.error(f"❌ RUN_CLUSTERING FAILED: {e}")
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return {
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }

@app.task(bind=True)
def dump_to_backplane(self, session_id: str):
    """
    Celery task to copy a session's workspace to /backplane/backplane1.
    
    This task:
    1. Verifies /backplane/backplane1 is mounted and different from /backplane
    2. Rsyncs the session workspace to the backplane
    3. Creates a LAST_HOST_DUMP.json marker file with metadata
    
    Args:
        session_id: Session ID to dump
    
    Returns:
        dict with success status and dump metadata
    """
    import os
    import subprocess
    import socket
    import json
    from pathlib import Path
    from datetime import datetime
    
    logger.info(f"💾 CELERY DUMP_TO_BACKPLANE STARTED - Session: {session_id}")
    
    try:
        # Update task state
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Verifying filesystem...',
                'session_id': session_id
            }
        )
        
        # Verify /backplane/backplane1 exists and is a directory
        backplane1 = Path("/backplane/backplane1")
        backplane = Path("/backplane")
        
        if not backplane1.exists():
            raise FileNotFoundError(f"/backplane/backplane1 does not exist")
        
        if not backplane1.is_dir():
            raise ValueError(f"/backplane/backplane1 is not a directory")
        
        # Verify it's mounted (check if it's a different filesystem from /backplane)
        try:
            stat_backplane = os.statvfs(str(backplane))
            stat_backplane1 = os.statvfs(str(backplane1))
            
            # Compare filesystem IDs (f_fsid on Linux, f_fsid on macOS)
            if hasattr(stat_backplane, 'f_fsid') and hasattr(stat_backplane1, 'f_fsid'):
                if stat_backplane.f_fsid == stat_backplane1.f_fsid:
                    raise ValueError(f"/backplane/backplane1 is the same filesystem as /backplane - not a separate mount")
        except Exception as fs_check_error:
            logger.warning(f"⚠️  Could not verify filesystem mount: {fs_check_error}")
            # Continue anyway - might be a different OS or permission issue
        
        # Get session workspace path
        if not FEATRIX_QUEUE_AVAILABLE:
            raise ImportError("featrix_queue module not available")
        
        from config import config
        source_dir = config.output_dir / session_id
        
        if not source_dir.exists():
            raise FileNotFoundError(f"Session workspace not found: {source_dir}")
        
        # Destination path
        dest_dir = backplane1 / session_id
        
        logger.info(f"   Source: {source_dir}")
        logger.info(f"   Destination: {dest_dir}")
        
        # Update progress
        self.update_state(
            state='PROGRESS',
            meta={
                'status': 'Copying files...',
            }
        )
        
        # Run rsync
        rsync_cmd = [
            'rsync',
            '-a',  # Archive mode (preserves permissions, timestamps, etc.)
            '--progress',
            f"{source_dir}/",
            str(dest_dir)
        ]
        
        logger.info(f"   Running: {' '.join(rsync_cmd)}")
        result = subprocess.run(rsync_cmd, capture_output=True, text=True, check=False)
        
        if result.returncode != 0:
            raise Exception(f"Rsync failed with exit code {result.returncode}: {result.stderr}")
        
        # Count files and calculate size
        file_count = 0
        total_size = 0
        for root, dirs, files in os.walk(dest_dir):
            file_count += len(files)
            for f in files:
                try:
                    total_size += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        
        # Get training status and epochs from session
        training_status = "unknown"
        epochs = None
        try:
            from featrix_queue import load_session
            session = load_session(session_id)
            training_status = session.get('status', 'unknown')
            # Try to get epoch count from training logs or model checkpoints
            # This is approximate - we'd need to parse logs or checkpoints
        except Exception as session_error:
            logger.warning(f"Could not load session for metadata: {session_error}")
        
        # Create marker file
        marker_file = dest_dir / "LAST_HOST_DUMP.json"
        marker_data = {
            "host": socket.gethostname(),
            "session_id": session_id,
            "dumped_at": datetime.utcnow().isoformat() + "Z",
            "training_status": training_status,
            "epochs": epochs,
            "source_path": str(source_dir),
            "destination_path": str(dest_dir),
            "rsync_exit_code": result.returncode,
            "file_count": file_count,
            "total_size_bytes": total_size
        }
        
        with open(marker_file, 'w') as f:
            json.dump(marker_data, f, indent=2)
        
        logger.info(f"✅ Dump completed successfully")
        logger.info(f"   Files: {file_count}, Size: {total_size / 1024 / 1024:.2f} MB")
        logger.info(f"   Marker file: {marker_file}")
        
        return {
            'success': True,
            'session_id': session_id,
            'destination': str(dest_dir),
            'file_count': file_count,
            'total_size_bytes': total_size,
            'marker_file': str(marker_file)
        }
        
    except Exception as e:
        logger.error(f"❌ DUMP_TO_BACKPLANE FAILED: {e}")
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return {
            'success': False,
            'error': str(e),
            'session_id': session_id,
            'traceback': traceback.format_exc()
        }

if __name__ == '__main__':
    app.start() 