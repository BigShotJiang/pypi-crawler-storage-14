from datetime import datetime

def convert_to_iso(timestamp: datetime | None) -> str | None:
    if timestamp is None:
        return None
    
    return timestamp.isoformat()


def convert_from_iso(timestamp: str | None) -> datetime | None:
    if timestamp is None:
        return None
    
    return datetime.fromisoformat(timestamp)