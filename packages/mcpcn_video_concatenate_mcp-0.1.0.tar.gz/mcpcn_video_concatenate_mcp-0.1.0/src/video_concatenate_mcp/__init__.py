"""
Video Concatenate MCP Server

A MCP server for concatenating videos with optional transition effects.
"""

__version__ = "0.1.0"

from .main import main

__all__ = ["main"]
