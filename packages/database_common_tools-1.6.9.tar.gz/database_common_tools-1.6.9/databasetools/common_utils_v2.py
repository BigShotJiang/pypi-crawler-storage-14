import hashlib
import requests
import bson.json_util
import json
from datetime import datetime, timedelta, timezone
from typing import Optional, Union

class CommonUtils:
    """常用日期格式"""
    FORMAT_ISO = "%Y-%m-%d"  # 2024-11-25
    FORMAT_ISO_DATETIME = "%Y-%m-%d %H:%M:%S"  # 2024-11-25 15:30:00
    FORMAT_SLASH = "%Y/%m/%d"  # 2024/11/25
    FORMAT_COMPACT = "%Y%m%d"  # 20241125
    FORMAT_CHINESE = "%Y年%m月%d日"  # 2024年11月25日
    FORMAT_US = "%m/%d/%Y"  # 11/25/2024
    FORMAT_MONTH_DAY = "%m-%d"  # 11-25
    FORMAT_YEAR_MONTH = "%Y-%m"  # 2024-11

    def __init__(self, log):
        self.log = log

    def dump_load(self, fn):
        with open(fn, 'r') as f:
            try:
                jmap = json.loads(f.read())
                return dict(jmap)
            except Exception as e:
                self.log.error('exception ... {}\tfile={}'.format(e, fn))
                return dict()
    
    def dump_loads(self, value):
        try:
            return bson.json_util.loads(value)
        except Exception as e:
            self.log.error('exception ... {}\tvalue={}'.format(e, value))
            return dict()
        
    def unix_to_formatted_time(self, unix_timestamp):
        """
        将Unix时间戳转换为格式化的时间字符串
        :param unix_timestamp: Unix时间戳(以秒为单位)
        :return: 格式化的时间字符串，格式为'%Y-%m-%d %H:%M:%S'
        """
        dt_object = datetime.fromtimestamp(unix_timestamp)
        formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S')
        return formatted_time
    
    def unix_to_formatted_datetime(self, unix_timestamp, tz=timezone.utc):
        """
        将Unix时间戳转换为datetime对象并将微妙去掉
        :param unix_timestamp: Unix时间戳(以秒为单位)
        :param tz: Unix时间戳时区 默认为UTC时间
        :return: datetime对象去除微秒部分'
        """
        dt_object_utc = datetime.fromtimestamp(unix_timestamp, tz=tz).replace(microsecond=0)
        return dt_object_utc
    
    def unix_to_formatted_datetime_hours(self, unix_timestamp, tz=timezone.utc, hours_to_add=0):
        """
        将Unix时间戳转换为datetime对象并将微妙去掉
        :param unix_timestamp: Unix时间戳(以秒为单位)
        :param tz: Unix时间戳时区 默认为UTC时间
        :return: datetime对象去除微秒部分'
        """
        dt_object_utc = datetime.fromtimestamp(unix_timestamp, tz=tz).replace(microsecond=0)
        if hours_to_add != 0:
            dt_object_utc += timedelta(hours=hours_to_add)
        return dt_object_utc
    
    def get_unix_time(self, time_str):
        """
        将格式化的时间字符串转换为Unix时间戳
        :param time_str: 格式化的时间字符串，格式为'%Y-%m-%d %H:%M:%S'
        :return: Unix时间戳(以秒为单位)
        """
        if time_str:
            try:
                dt_obj = datetime.strptime(str(time_str), "%Y-%m-%d %H:%M:%S")
                unix_timestamp = int(dt_obj.timestamp())
                return unix_timestamp
            except ValueError as e:
                try:
                    dt_obj = datetime.strptime(str(time_str), "%Y-%m-%d")
                    unix_timestamp = int(dt_obj.timestamp())
                    return unix_timestamp
                except ValueError as e:
                    return 0
        else:
            return 0
    
    def image_exists_get(self, url, timeout=10, max_retries=3):
        """
        Check if an image exists at the given URL.
        
        :param url: Image URL
        :param timeout: Timeout for the request in seconds
        :param max_retries: Maximum number of retries
        :return: True if image exists, False otherwise
        """
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.get(url, timeout=timeout)
                if response.status_code == 200:
                    return True
                else:
                    return False
            except requests.RequestException as e:
                self.log.error('Check image exist error: '.format(e))
            attempt += 1
        return False

    def image_exists_head(self, url, timeout=10, max_retries=3):
        """
        Check if an image exists at the given URL.
        
        :param url: Image URL
        :param timeout: Timeout for the request in seconds
        :param max_retries: Maximum number of retries
        :return: True if image exists, False otherwise
        """
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.head(url, timeout=timeout)
                if response.status_code == 200:
                    return True
                else:
                    return False
            except requests.RequestException as e:
                self.log.error('Check image exist error: '.format(e))
            attempt += 1
        return False

    def parse_sql_result(self, cursor):
        """
        Parse SQL result from a cursor object and return as list of dictionaries.
        
        :param cursor: SQL cursor object
        :return: List of dictionaries with column names as keys
        """
        columns = [col[0] for col in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    def calculate_md5(self, input):
        """
        计算输入字符串的MD5哈希值, 并返回32位的十六进制字符串
        :param input_string: 输入字符串
        :return: 32位的MD5十六进制字符串
        """
        if isinstance(input, str):
            # 创建MD5哈希对象
            md5 = hashlib.md5()
            # 更新哈希对象的输入内容
            md5.update(input.encode())
            # 获取十六进制表示的MD5哈希值，并去除特殊符号
            md5_hex = md5.hexdigest()
            # 去除MD5字符串中的特殊符号
            md5_cleaned = ''.join(c for c in md5_hex if c.isalnum())
            # 返回32位的MD5十六进制字符串（无特殊符号）
            return md5_cleaned[:32]
        else:
            self.log.error('input not str,please input type str!')

    def get_time_threshold(self, time_unit, interval):
        """
        根据传入的时间单位和时间间隔计算时间阈值。

        参数:
        :param time_unit (str): 时间单位，可以是 'minutes', 'hours', 'days' 等。
        :param interval (int): 时间间隔。

        返回值:
        :return: datetime: 计算得到的时间阈值。
        """
        # 获取当前时间并设置为北京时区,并精确到秒
        current_time = datetime.now(timezone.utc).replace(microsecond=0)

        # 根据传入的时间单位和间隔计算时间阈值
        if time_unit == 'minutes':
            time_threshold = current_time - timedelta(minutes=interval)
        elif time_unit == 'hours':
            time_threshold = current_time - timedelta(hours=interval)
        elif time_unit == 'days':
            time_threshold = current_time - timedelta(days=interval)
        else:
            self.log.error("不支持的时间单位。请使用 'minutes', 'hours' 或 'days'。")

        return time_threshold

    @staticmethod
    def get_envs_from_file(file_path="/etc/environment"):
        envs = {}
        with open(file_path) as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    envs[k] = v
        return envs

    def get_env(self,env_name,file_path="/etc/environment"):
        envs = self.get_envs_from_file(file_path)
        return envs.get(env_name)

    def get_days_ago(self, n: int,date_format: str = "%Y-%m-%d",from_date: Optional[Union[str, datetime]] = None,from_date_format: Optional[str] = None) -> str:
        """
        获取前n天的日期
        Args:
            n: 天数，正数表示过去，负数表示未来
            date_format: 返回的日期格式，默认为 "%Y-%m-%d"
            from_date: 起始日期，可以是字符串或datetime对象，默认为今天
            from_date_format: 起始日期的格式（当from_date为字符串时需要）
        Returns:
            格式化后的日期字符串
        Examples:
            >>> get_days_ago(7)  # 7天前
            '2024-11-18'
            >>> get_days_ago(7, "%Y/%m/%d")  # 自定义格式
            '2024/11/18'
            >>> get_days_ago(-3)  # 3天后
            '2024-11-28'
            >>> get_days_ago(7, from_date="2024-01-15")  # 从指定日期开始计算
            '2024-01-08'
        """
        # 确定起始日期
        if from_date is None:
            base_date = datetime.now()
        elif isinstance(from_date, datetime):
            base_date = from_date
        elif isinstance(from_date, str):
            if from_date_format is None:
                # 尝试常见格式
                for fmt in ["%Y-%m-%d", "%Y/%m/%d", "%Y%m%d", "%Y-%m-%d %H:%M:%S"]:
                    try:
                        base_date = datetime.strptime(from_date, fmt)
                        break
                    except ValueError:
                        continue
                else:
                    raise ValueError(f"无法解析日期 '{from_date}'，请指定 from_date_format")
            else:
                base_date = datetime.strptime(from_date, from_date_format)
        else:
            raise TypeError("from_date 必须是 str 或 datetime 对象")

        # 计算目标日期
        target_date = base_date - timedelta(days=n)

        # 格式化返回
        return target_date.strftime(date_format)

    def get_date_range(self,start_days_ago: int,end_days_ago: int = 0,date_format: str = "%Y-%m-%d",from_date: Optional[Union[str, datetime]] = None) -> list[str]:
        """
        获取日期范围列表

        Args:
            start_days_ago: 开始天数（距今天）
            end_days_ago: 结束天数（距今天），默认为0（今天）
            date_format: 日期格式
            from_date: 起始日期

        Returns:
            日期字符串列表

        Examples:
            >>> get_date_range(7)  # 最近7天
            ['2024-11-18', '2024-11-19', ..., '2024-11-25']

            >>> get_date_range(7, 3)  # 7天前到3天前
            ['2024-11-18', '2024-11-19', '2024-11-20', '2024-11-21', '2024-11-22']
        """
        dates = []
        for i in range(start_days_ago, end_days_ago - 1, -1):
            dates.append(self.get_days_ago(i, date_format, from_date))
        return dates

    def get_multiple_dates(slef,days_list: list[int],date_format: str = "%Y-%m-%d",from_date: Optional[Union[str, datetime]] = None) -> dict[int, str]:
        """
        批量获取多个日期

        Args:
            days_list: 天数列表
            date_format: 日期格式
            from_date: 起始日期

        Returns:
            天数到日期的映射字典

        Examples:
            >>> get_multiple_dates([1, 7, 30])
            {1: '2024-11-24', 7: '2024-11-18', 30: '2024-10-26'}
        """
        return {days: slef.get_days_ago(days, date_format, from_date) for days in days_list}

    # ============================================
    # 常用日期格式预设
    # ============================================

    # 快捷函数
    def yesterday(self,date_format: str = FORMAT_ISO) -> str:
        """获取昨天的日期"""
        return self.get_days_ago(1, date_format)

    def last_week(self,date_format: str = FORMAT_ISO) -> str:
        """获取上周今日的日期"""
        return self.get_days_ago(7, date_format)

    def last_month(self,date_format: str = FORMAT_ISO) -> str:
        """获取上个月今日的日期（约30天）"""
        return self.get_days_ago(30, date_format)

    def tomorrow(self,date_format: str = FORMAT_ISO) -> str:
        """获取明天的日期"""
        return self.get_days_ago(-1, date_format)

    def last_n_days(self,n: int, date_format: str = FORMAT_ISO) -> list[str]:
        """获取最近n天的日期列表（包含今天）"""
        return self.get_date_range(n - 1, 0, date_format)

# if __name__ == '__main__':
#     print("=" * 70)
#     print("CommonUtils 类使用示例")
#     print("=" * 70)
#
#     # 创建实例
#     utils = CommonUtils()
#     print(f"\n当前实例: {utils}")
#
#     # 示例1: 基础用法
#     print("\n" + "=" * 70)
#     print("1. 基础用法")
#     print("=" * 70)
#     print(f"今天:             {utils.today()}")
#     print(f"昨天:             {utils.yesterday()}")
#     print(f"7天前:            {utils.get_days_ago(7)}")
#     print(f"3天后:            {utils.get_days_ago(-3)}")
#     print(f"上周今日:         {utils.last_week()}")
#     print(f"上月今日:         {utils.last_month()}")
#
#     # 示例2: 不同格式
#     print("\n" + "=" * 70)
#     print("2. 不同的日期格式")
#     print("=" * 70)
#     date = utils.get_days_ago(7)
#     print(f"ISO格式:          {utils.get_days_ago(7, CommonUtils.FORMAT_ISO)}")
#     print(f"斜杠格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_SLASH)}")
#     print(f"紧凑格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_COMPACT)}")
#     print(f"中文格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_CHINESE)}")
#     print(f"美式格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_US)}")
#
#     # 示例3: 日期范围
#     print("\n" + "=" * 70)
#     print("3. 获取日期范围")
#     print("=" * 70)
#     last_7 = utils.last_n_days(7)
#     print(f"最近7天: {last_7[0]} 至 {last_7[-1]}")
#     print(f"详细列表: {last_7}")
#
#     next_3 = utils.next_n_days(3)
#     print(f"\n未来3天: {next_3[0]} 至 {next_3[-1]}")
#
#     # 示例4: 批量获取
#     print("\n" + "=" * 70)
#     print("4. 批量获取多个日期")
#     print("=" * 70)
#     dates_dict = utils.get_multiple_dates([1, 7, 30, 90])
#     for days, date in dates_dict.items():
#         print(f"{days:3d}天前: {date}")
#
#     # 示例5: 自定义起始日期
#     print("\n" + "=" * 70)
#     print("5. 从指定日期开始计算")
#     print("=" * 70)
#     custom_base = "2024-01-15"
#     print(f"基准日期: {custom_base}")
#     print(f"往前7天:  {utils.get_days_ago(7, from_date=custom_base)}")
#     print(f"往后7天:  {utils.get_days_ago(-7, from_date=custom_base)}")
#
#     # 示例6: 日期格式转换
#     print("\n" + "=" * 70)
#     print("6. 日期格式转换")
#     print("=" * 70)
#     original = "2024-11-25"
#     print(f"原始格式:         {original}")
#     print(f"转为中文:         {utils.format_date(original, DateUtils.FORMAT_CHINESE)}")
#     print(f"转为紧凑:         {utils.format_date(original, DateUtils.FORMAT_COMPACT)}")
#     print(f"转为美式:         {utils.format_date(original, DateUtils.FORMAT_US)}")
#
#     # 示例7: 日期计算
#     print("\n" + "=" * 70)
#     print("7. 日期差值计算")
#     print("=" * 70)
#     date1 = "2024-11-25"
#     date2 = "2024-11-18"
#     diff = utils.date_diff(date1, date2)
#     print(f"{date1} 和 {date2} 相差 {diff} 天")
#
#     # 示例8: 星期判断
#     print("\n" + "=" * 70)
#     print("8. 星期相关功能")
#     print("=" * 70)
#     print(f"今天是:           {utils.get_weekday_name(chinese=True)}")
#     print(f"今天是周末吗:     {utils.is_weekend()}")
#     print(f"2024-11-23 是:    {utils.get_weekday_name('2024-11-23', chinese=True)}")
#     print(f"2024-11-23 周末:  {utils.is_weekend('2024-11-23')}")
#
#     # 示例9: 时间戳操作
#     print("\n" + "=" * 70)
#     print("9. 时间戳相关操作（类方法）")
#     print("=" * 70)
#     print(f"当前时间:         {DateUtils.now()}")
#     print(f"当前时间戳(秒):   {DateUtils.now_timestamp()}")
#     print(f"当前时间戳(毫秒): {DateUtils.now_timestamp_ms()}")
#
#     timestamp = 1700000000
#     print(f"\n时间戳 {timestamp} 转日期: {DateUtils.from_timestamp(timestamp)}")
#
#     date_str = "2024-11-25"
#     print(f"日期 {date_str} 转时间戳: {DateUtils.to_timestamp(date_str)}")
#
#     # 示例10: 实际业务场景
#     print("\n" + "=" * 70)
#     print("10. 实际业务场景示例")
#     print("=" * 70)
#
#     # 场景1: 生成日志文件名
#     print("\n场景1: 生成日志文件名")
#     log_file = f"app_{utils.today(DateUtils.FORMAT_COMPACT)}.log"
#     print(f"  {log_file}")
#
#     # 场景2: 数据库查询条件
#     print("\n场景2: 构建数据库查询条件")
#     start_date = utils.get_days_ago(30)
#     end_date = utils.today()
#     print(f"  WHERE date BETWEEN '{start_date}' AND '{end_date}'")
#
#     # 场景3: 生成报表
#     print("\n场景3: 生成报表标题")
#     report_date = utils.yesterday(DateUtils.FORMAT_CHINESE)
#     weekday = utils.get_weekday_name(utils.yesterday(), chinese=True)
#     print(f"  《{report_date}（{weekday}）销售日报》")
#
#     # 场景4: API参数
#     print("\n场景4: 构建API查询参数")
#     params = {
#         'start_date': utils.get_days_ago(7),
#         'end_date': utils.today(),
#         'date_list': utils.last_n_days(3)
#     }
#     print(f"  {params}")
#
#     # 场景5: 批量处理文件
#     print("\n场景5: 批量处理最近7天的数据文件")
#     for date in utils.last_n_days(7):
#         filename = f"data_{date.replace('-', '')}.csv"
#         print(f"  处理文件: {filename}")
#
#     # 场景6: 使用自定义默认格式的实例
#     print("\n场景6: 创建使用中文格式的实例")
#     cn_utils = DateUtils(default_format=DateUtils.FORMAT_CHINESE)
#     print(f"  实例: {cn_utils}")
#     print(f"  今天: {cn_utils.today()}")
#     print(f"  昨天: {cn_utils.yesterday()}")
#
#     print("\n" + "=" * 70)
#     print("所有示例运行完成！")
#     print("=" * 70)
