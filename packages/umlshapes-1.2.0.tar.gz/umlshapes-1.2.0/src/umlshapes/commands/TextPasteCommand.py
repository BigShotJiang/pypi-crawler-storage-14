
from typing import TYPE_CHECKING
from typing import cast

from logging import Logger
from logging import getLogger

from umlmodel.Text import Text
from umlmodel.UmlModelBase import UmlModelBase

from umlshapes.commands.BasePasteCommand import BasePasteCommand

from umlshapes.pubsubengine.IUmlPubSubEngine import IUmlPubSubEngine

from umlshapes.types.UmlPosition import UmlPosition

if TYPE_CHECKING:
    from umlshapes.frames.UmlFrame import UmlFrame
    from umlshapes.ShapeTypes import UmlShapeGenre


class TextPasteCommand(BasePasteCommand):
    def __init__(self, umlModelBase: UmlModelBase, umlPosition: UmlPosition, umlFrame: 'UmlFrame', umlPubSubEngine: IUmlPubSubEngine):
        """

        Args:
            umlModelBase:         We will build the appropriate UML Shape from this
            umlPosition:        The location to paste it to
            umlFrame:           The UML Frame we are pasting to
            umlPubSubEngine:    The event handler that is injected
        """
        from umlshapes.shapes.UmlText import UmlText

        self.logger: Logger = getLogger(__name__)

        super().__init__(partialName='', umlModelBase=umlModelBase, umlPosition=umlPosition, umlFrame=umlFrame, umlPubSubEngine=umlPubSubEngine)

        self._umlText: UmlText = cast(UmlText, None)

    def Do(self) -> bool:
        from umlshapes.ShapeTypes import UmlShapeGenre

        umlShape: UmlShapeGenre = self._createPastedShape(umlModelBase=self._baseAttributes)

        self._setupUmlShape(umlShape=umlShape)
        self._umlText = umlShape  # type: ignore

        return True

    def Undo(self) -> bool:
        self._undo(umlShape=self._umlText)
        return True

    def _createPastedShape(self, umlModelBase: UmlModelBase) -> 'UmlShapeGenre':
        from umlshapes.shapes.UmlText import UmlText
        from umlshapes.shapes.eventhandlers.UmlTextEventHandler import UmlTextEventHandler

        umlShape:     UmlText             = UmlText(cast(Text, umlModelBase))
        eventHandler: UmlTextEventHandler = UmlTextEventHandler()

        self._setupEventHandler(umlShape=umlShape, eventHandler=eventHandler)

        return umlShape
