"""
Integration tests for Memory Machines SDK.

These tests run against the live API and require:
- MM_TEST_API_KEY environment variable set
- Network access to the API

Run with: pytest tests/test_integration.py -v
"""
import os
import pytest
import tempfile
from pathlib import Path

# Skip all tests in this module if no API key is set
pytestmark = pytest.mark.skipif(
    not os.environ.get("MM_TEST_API_KEY"),
    reason="MM_TEST_API_KEY not set - skipping integration tests"
)


@pytest.fixture
def client():
    """Create a real client for integration tests."""
    from memorymachines import MemoryClient
    return MemoryClient(
        api_key=os.environ.get("MM_TEST_API_KEY"),
        base_url=os.environ.get(
            "MM_TEST_BASE_URL",
            "https://memorymachines-core-api-mvp-gateway-6v1lw71z.uc.gateway.dev"
        )
    )


class TestHealthCheckIntegration:
    """Integration tests for health check endpoint."""

    def test_health_check_returns_true(self, client):
        """Health check should return True for live API."""
        result = client.health_check()
        assert result is True


class TestRecallIntegration:
    """Integration tests for recall endpoint."""

    def test_recall_returns_dict(self, client):
        """Recall should return a dictionary with expected keys."""
        result = client.recall("test query")

        assert isinstance(result, dict)
        assert "memories" in result
        assert "qa" in result
        assert "chunks" in result

    def test_recall_memories_is_list(self, client):
        """Recall memories should be a list."""
        result = client.recall("meetings")

        assert isinstance(result["memories"], list)

    def test_recall_with_specific_query(self, client):
        """Recall with specific query returns results."""
        result = client.recall("what happened today")

        # Should always return the structure even if no memories
        assert "memories" in result


class TestAskIntegration:
    """Integration tests for ask endpoint."""

    def test_ask_returns_response(self, client):
        """Ask should return a response dictionary."""
        result = client.ask("What do you know about me?")

        assert isinstance(result, dict)
        assert "response" in result
        assert isinstance(result["response"], str)

    def test_ask_with_specific_question(self, client):
        """Ask with specific question returns meaningful response."""
        result = client.ask("Tell me about my recent activities")

        assert result["response"]  # Non-empty response
        assert len(result["response"]) > 0


class TestMemorizeIntegration:
    """Integration tests for memorize endpoint."""

    def test_memorize_text_file(self, client):
        """Memorize should accept a text file."""
        # Create a temporary text file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("This is a test document for SDK integration testing.\n")
            f.write("It contains some sample content to memorize.\n")
            temp_path = f.name

        try:
            result = client.memorize(
                file=temp_path,
                user_name="SDK Test User",
                item_id=f"sdk_integration_test_{os.urandom(4).hex()}",
                source_type="text"
            )

            assert isinstance(result, dict)
            assert result.get("status") == "success"
            assert "item_id" in result
            assert "user_id" in result
        finally:
            os.unlink(temp_path)

    def test_memorize_bytes_content(self, client):
        """Memorize should accept bytes content."""
        content = b"This is test content as bytes for integration testing."

        result = client.memorize(
            file=content,
            user_name="SDK Test User",
            item_id=f"sdk_bytes_test_{os.urandom(4).hex()}",
            filename="test_bytes.txt"
        )

        assert isinstance(result, dict)
        assert result.get("status") == "success"


class TestFeedbackIntegration:
    """Integration tests for feedback endpoint."""

    def test_feedback_positive_rating(self, client):
        """Feedback should accept positive rating."""
        # First get a memory to rate
        recall_result = client.recall("test")

        if recall_result["memories"]:
            memory_id = recall_result["memories"][0]["custom_id"]

            result = client.feedback(
                memory_id=memory_id,
                rating=1,
                query_text="test"
            )

            assert isinstance(result, dict)
            assert result.get("status") == "success"
        else:
            pytest.skip("No memories available to rate")

    def test_feedback_negative_rating(self, client):
        """Feedback should accept negative rating."""
        recall_result = client.recall("test")

        if recall_result["memories"]:
            memory_id = recall_result["memories"][0]["custom_id"]

            result = client.feedback(
                memory_id=memory_id,
                rating=-1,
                query_text="test"
            )

            assert isinstance(result, dict)
            assert result.get("status") == "success"
        else:
            pytest.skip("No memories available to rate")

    def test_feedback_remove_rating(self, client):
        """Feedback should accept rating removal (0)."""
        recall_result = client.recall("test")

        if recall_result["memories"]:
            memory_id = recall_result["memories"][0]["custom_id"]

            result = client.feedback(
                memory_id=memory_id,
                rating=0,
                query_text="test"
            )

            assert isinstance(result, dict)
            assert result.get("status") == "success"
        else:
            pytest.skip("No memories available to rate")


class TestErrorHandlingIntegration:
    """Integration tests for error handling."""

    def test_invalid_api_key_raises_error(self):
        """Invalid API key should raise an authentication error."""
        from memorymachines import MemoryClient
        from memorymachines.exceptions import AuthenticationError

        client = MemoryClient(
            api_key="invalid_key_12345",
            base_url=os.environ.get(
                "MM_TEST_BASE_URL",
                "https://memorymachines-core-api-mvp-gateway-6v1lw71z.uc.gateway.dev"
            )
        )

        with pytest.raises(AuthenticationError):
            client.recall("test")

    def test_empty_query_handled(self, client):
        """Empty query should be handled gracefully."""
        # The API may accept empty queries or return an error
        # Either way, it shouldn't crash
        try:
            result = client.recall("")
            assert isinstance(result, dict)
        except Exception as e:
            # If it raises, it should be a proper SDK exception
            from memorymachines.exceptions import MemoryMachinesError
            assert isinstance(e, MemoryMachinesError)


class TestClientContextManager:
    """Test client context manager functionality."""

    def test_context_manager_usage(self):
        """Client should work as context manager."""
        from memorymachines import MemoryClient

        with MemoryClient(api_key=os.environ.get("MM_TEST_API_KEY")) as client:
            result = client.health_check()
            assert result is True

    def test_context_manager_closes_session(self):
        """Context manager should close session on exit."""
        from memorymachines import MemoryClient

        with MemoryClient(api_key=os.environ.get("MM_TEST_API_KEY")) as client:
            session = client.session

        # Session should be closed after exiting context
        # Note: requests.Session doesn't have an is_closed property,
        # but we can verify the close method was called by trying to use it
        # This is more of a smoke test
        assert True  # Context manager completed without error
