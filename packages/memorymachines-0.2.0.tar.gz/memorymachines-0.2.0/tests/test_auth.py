"""
Unit tests for auth module.
"""
import os
import pytest
from unittest.mock import patch, mock_open
from pathlib import Path

from memorymachines.auth import (
    login,
    logout,
    get_token,
    set_active_profile,
    list_profiles,
    whoami,
    get_config_path,
    DEFAULT_CONFIG_DIR,
    ENV_VAR_NAME
)


class TestGetConfigPath:
    """Tests for get_config_path function."""

    def test_default_path(self):
        """Returns default path when no env var set."""
        with patch.dict(os.environ, {}, clear=True):
            # Remove MM_CONFIG_PATH if it exists
            os.environ.pop("MM_CONFIG_PATH", None)
            path = get_config_path()
            assert path == DEFAULT_CONFIG_DIR / "config.yaml"

    def test_custom_path_from_env(self):
        """Returns custom path from environment variable."""
        with patch.dict(os.environ, {"MM_CONFIG_PATH": "/custom/path/config.yaml"}):
            path = get_config_path()
            assert path == Path("/custom/path/config.yaml")


class TestLogin:
    """Tests for login function."""

    def test_login_creates_config_dir(self, tmp_path):
        """Login creates config directory if it doesn't exist."""
        config_file = tmp_path / ".memorymachines" / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("test_token_123")

        assert config_file.parent.exists()
        assert config_file.exists()

    def test_login_saves_token(self, tmp_path):
        """Login saves token to config file."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("my_api_key_xyz")

        import yaml
        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert config["profiles"]["default"]["api_key"] == "my_api_key_xyz"

    def test_login_with_profile(self, tmp_path):
        """Login saves token under specified profile."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("work_key", profile="work")

        import yaml
        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert config["profiles"]["work"]["api_key"] == "work_key"

    def test_login_sets_active_profile_first_time(self, tmp_path):
        """Login sets active profile on first login."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token", profile="custom")

        import yaml
        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert config["active_profile"] == "custom"

    def test_login_preserves_existing_profiles(self, tmp_path):
        """Login preserves existing profiles."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token1", profile="profile1")
            login("token2", profile="profile2")

        import yaml
        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert "profile1" in config["profiles"]
        assert "profile2" in config["profiles"]

    def test_login_sets_file_permissions(self, tmp_path):
        """Login sets restrictive file permissions."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token")

        # Check permissions (0o600 = owner read/write only)
        mode = config_file.stat().st_mode & 0o777
        assert mode == 0o600


class TestLogout:
    """Tests for logout function."""

    def test_logout_removes_config_file(self, tmp_path):
        """Logout removes entire config file."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token")
            assert config_file.exists()

            logout()
            assert not config_file.exists()

    def test_logout_specific_profile(self, tmp_path):
        """Logout removes specific profile."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token1", profile="work")
            login("token2", profile="personal")
            logout(profile="work")

        import yaml
        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert "work" not in config["profiles"]
        assert "personal" in config["profiles"]

    def test_logout_updates_active_profile(self, tmp_path):
        """Logout updates active profile when current is removed."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token1", profile="work")
            login("token2", profile="personal")

            # Set work as active
            import yaml
            with open(config_file) as f:
                config = yaml.safe_load(f)
            config["active_profile"] = "work"
            with open(config_file, "w") as f:
                yaml.safe_dump(config, f)

            logout(profile="work")

        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert config["active_profile"] == "personal"

    def test_logout_no_config_file(self, tmp_path, capsys):
        """Logout handles missing config file gracefully."""
        config_file = tmp_path / "nonexistent.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            logout()

        captured = capsys.readouterr()
        assert "Already logged out" in captured.out

    def test_logout_nonexistent_profile(self, tmp_path, capsys):
        """Logout handles nonexistent profile gracefully."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token", profile="default")
            logout(profile="nonexistent")

        captured = capsys.readouterr()
        assert "not found" in captured.out


class TestGetToken:
    """Tests for get_token function."""

    def test_get_token_from_env(self, tmp_path):
        """get_token returns token from environment variable."""
        with patch.dict(os.environ, {ENV_VAR_NAME: "env_token_123"}):
            token = get_token()
            assert token == "env_token_123"

    def test_get_token_from_config(self, tmp_path):
        """get_token returns token from config file."""
        config_file = tmp_path / "config.yaml"

        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop(ENV_VAR_NAME, None)

            with patch('memorymachines.auth.get_config_path', return_value=config_file):
                login("config_token")
                token = get_token()

        assert token == "config_token"

    def test_get_token_env_takes_precedence(self, tmp_path):
        """Environment variable takes precedence over config."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("config_token")

        with patch.dict(os.environ, {ENV_VAR_NAME: "env_token"}):
            with patch('memorymachines.auth.get_config_path', return_value=config_file):
                token = get_token()

        assert token == "env_token"

    def test_get_token_specific_profile(self, tmp_path):
        """get_token returns token for specific profile."""
        config_file = tmp_path / "config.yaml"

        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop(ENV_VAR_NAME, None)

            with patch('memorymachines.auth.get_config_path', return_value=config_file):
                login("default_token", profile="default")
                login("work_token", profile="work")

                token = get_token(profile="work")

        assert token == "work_token"

    def test_get_token_returns_none_when_not_found(self, tmp_path):
        """get_token returns None when no token available."""
        config_file = tmp_path / "nonexistent.yaml"

        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop(ENV_VAR_NAME, None)

            with patch('memorymachines.auth.get_config_path', return_value=config_file):
                token = get_token()

        assert token is None


class TestSetActiveProfile:
    """Tests for set_active_profile function."""

    def test_set_active_profile(self, tmp_path):
        """set_active_profile changes active profile."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token1", profile="profile1")
            login("token2", profile="profile2")

            set_active_profile("profile2")

        import yaml
        with open(config_file) as f:
            config = yaml.safe_load(f)

        assert config["active_profile"] == "profile2"

    def test_set_active_profile_nonexistent(self, tmp_path):
        """set_active_profile raises error for nonexistent profile."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token", profile="default")

            with pytest.raises(ValueError) as exc_info:
                set_active_profile("nonexistent")

            assert "not found" in str(exc_info.value)

    def test_set_active_profile_no_config(self, tmp_path):
        """set_active_profile raises error when no config exists."""
        config_file = tmp_path / "nonexistent.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            with pytest.raises(FileNotFoundError):
                set_active_profile("default")


class TestListProfiles:
    """Tests for list_profiles function."""

    def test_list_profiles_empty(self, tmp_path):
        """list_profiles returns empty dict when no config."""
        config_file = tmp_path / "nonexistent.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            profiles = list_profiles()

        assert profiles == {}

    def test_list_profiles_single(self, tmp_path):
        """list_profiles returns single profile."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token", profile="default")
            profiles = list_profiles()

        assert "default" in profiles
        assert profiles["default"]["active"] is True

    def test_list_profiles_multiple(self, tmp_path):
        """list_profiles returns multiple profiles with active status."""
        config_file = tmp_path / "config.yaml"

        with patch('memorymachines.auth.get_config_path', return_value=config_file):
            login("token1", profile="default")
            login("token2", profile="work")
            profiles = list_profiles()

        assert "default" in profiles
        assert "work" in profiles
        # First profile is active by default
        assert profiles["default"]["active"] is True
        assert profiles["work"]["active"] is False


class TestWhoami:
    """Tests for whoami function."""

    def test_whoami_logged_in(self, tmp_path, capsys):
        """whoami shows profile when logged in."""
        config_file = tmp_path / "config.yaml"

        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop(ENV_VAR_NAME, None)

            with patch('memorymachines.auth.get_config_path', return_value=config_file):
                login("token", profile="myprofile")

                # Set active profile
                import yaml
                with open(config_file) as f:
                    config = yaml.safe_load(f)
                config["active_profile"] = "myprofile"
                with open(config_file, "w") as f:
                    yaml.safe_dump(config, f)

                result = whoami()

        assert result == "myprofile"
        captured = capsys.readouterr()
        assert "myprofile" in captured.out

    def test_whoami_not_logged_in(self, tmp_path, capsys):
        """whoami shows message when not logged in."""
        config_file = tmp_path / "nonexistent.yaml"

        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop(ENV_VAR_NAME, None)

            with patch('memorymachines.auth.get_config_path', return_value=config_file):
                result = whoami()

        assert result is None
        captured = capsys.readouterr()
        assert "Not logged in" in captured.out

    def test_whoami_env_var(self, capsys):
        """whoami shows env when using environment variable."""
        with patch.dict(os.environ, {ENV_VAR_NAME: "env_token"}):
            with patch('memorymachines.auth.get_config_path') as mock_path:
                mock_path.return_value.exists.return_value = False
                result = whoami()

        assert result == "env"
        captured = capsys.readouterr()
        assert "environment variable" in captured.out
