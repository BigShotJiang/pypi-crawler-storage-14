"""
Unit tests for MemoryClient.
"""
import pytest
from unittest.mock import Mock, patch, MagicMock, mock_open
from pathlib import Path
import requests

from memorymachines import MemoryClient
from memorymachines.exceptions import (
    AuthenticationError,
    ValidationError,
    NotFoundError,
    RateLimitError,
    APIError
)


class TestMemoryClientInit:
    """Tests for MemoryClient initialization."""

    def test_init_with_explicit_api_key(self):
        """Client initializes with explicit API key."""
        client = MemoryClient(api_key="test_key_123")
        assert client.api_key == "test_key_123"
        assert client.base_url == "https://memorymachines-core-api-mvp-gateway-6v1lw71z.uc.gateway.dev"

    def test_init_with_custom_base_url(self):
        """Client initializes with custom base URL."""
        client = MemoryClient(api_key="test_key", base_url="https://custom.api.com")
        assert client.base_url == "https://custom.api.com"

    def test_init_strips_trailing_slash(self):
        """Base URL trailing slash is stripped."""
        client = MemoryClient(api_key="test_key", base_url="https://api.com/")
        assert client.base_url == "https://api.com"

    def test_init_without_api_key_raises_error(self):
        """Client raises AuthenticationError when no API key found."""
        with patch('memorymachines.auth.get_token', return_value=None):
            with pytest.raises(AuthenticationError) as exc_info:
                MemoryClient()
            assert "No API key found" in str(exc_info.value)

    def test_init_discovers_api_key_from_env(self):
        """Client discovers API key from environment."""
        with patch('memorymachines.client.get_token', return_value="env_key_123"):
            client = MemoryClient()
            assert client.api_key == "env_key_123"

    def test_init_with_profile(self):
        """Client initializes with specific profile."""
        with patch('memorymachines.client.get_token', return_value="profile_key") as mock_get:
            client = MemoryClient(profile="work")
            mock_get.assert_called_once_with(profile="work")
            assert client.api_key == "profile_key"

    def test_session_created(self):
        """Session is created on init."""
        client = MemoryClient(api_key="test_key")
        assert client.session is not None
        assert isinstance(client.session, requests.Session)


class TestHealthCheck:
    """Tests for health_check method."""

    def test_health_check_success(self, client_with_mock_session, mock_response):
        """Health check returns True on 200 response."""
        client = client_with_mock_session
        client.session.get.return_value = mock_response(200, {"status": "healthy"})

        result = client.health_check()

        assert result is True
        client.session.get.assert_called_once()
        call_url = client.session.get.call_args[0][0]
        assert "/v1/health" in call_url

    def test_health_check_failure(self, client_with_mock_session, mock_response):
        """Health check returns False on non-200 response."""
        client = client_with_mock_session
        client.session.get.return_value = mock_response(500)

        result = client.health_check()

        assert result is False

    def test_health_check_connection_error(self, client_with_mock_session):
        """Health check returns False on connection error."""
        client = client_with_mock_session
        client.session.get.side_effect = requests.exceptions.ConnectionError()

        result = client.health_check()

        assert result is False

    def test_health_check_timeout(self, client_with_mock_session):
        """Health check returns False on timeout."""
        client = client_with_mock_session
        client.session.get.side_effect = requests.exceptions.Timeout()

        result = client.health_check()

        assert result is False


class TestRecall:
    """Tests for recall method."""

    def test_recall_success(self, client_with_mock_session, mock_response, sample_recall_response):
        """Recall returns memories on success."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_recall_response)

        result = client.recall("test query")

        assert "memories" in result
        assert len(result["memories"]) == 1
        client.session.post.assert_called_once()

    def test_recall_sends_correct_data(self, client_with_mock_session, mock_response):
        """Recall sends correct form data."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, {"memories": [], "qa": [], "chunks": []})

        client.recall("my test query")

        call_kwargs = client.session.post.call_args[1]
        assert call_kwargs["data"]["text"] == "my test query"
        assert "x-api-key" in call_kwargs["headers"]

    def test_recall_validates_query_length(self, client_with_mock_session):
        """Recall validates query length."""
        client = client_with_mock_session
        long_query = "x" * 1001

        with pytest.raises(ValidationError) as exc_info:
            client.recall(long_query)
        assert "1000 characters" in str(exc_info.value)

    def test_recall_accepts_max_length_query(self, client_with_mock_session, mock_response):
        """Recall accepts query at max length."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, {"memories": [], "qa": [], "chunks": []})
        max_query = "x" * 1000

        result = client.recall(max_query)

        assert result is not None


class TestAsk:
    """Tests for ask method."""

    def test_ask_success(self, client_with_mock_session, mock_response, sample_ask_response):
        """Ask returns AI response on success."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_ask_response)

        result = client.ask("What meetings did I have?")

        assert "response" in result
        assert "Alice and Bob" in result["response"]

    def test_ask_sends_correct_data(self, client_with_mock_session, mock_response):
        """Ask sends correct form data."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, {"response": "test"})

        client.ask("my question")

        call_kwargs = client.session.post.call_args[1]
        assert call_kwargs["data"]["text"] == "my question"
        assert "x-api-key" in call_kwargs["headers"]

    def test_ask_validates_query_length(self, client_with_mock_session):
        """Ask validates query length."""
        client = client_with_mock_session
        long_query = "x" * 1001

        with pytest.raises(ValidationError) as exc_info:
            client.ask(long_query)
        assert "1000 characters" in str(exc_info.value)

    def test_ask_url_correct(self, client_with_mock_session, mock_response):
        """Ask calls correct endpoint."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, {"response": "test"})

        client.ask("test")

        call_url = client.session.post.call_args[0][0]
        assert "/v1/memories/ask" in call_url


class TestMemorize:
    """Tests for memorize method."""

    def test_memorize_with_file_path(self, client_with_mock_session, mock_response, sample_memorize_response, tmp_path):
        """Memorize works with file path."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_memorize_response)

        # Create a test file
        test_file = tmp_path / "test.txt"
        test_file.write_text("Test content")

        result = client.memorize(str(test_file), user_name="Test User")

        assert result["status"] == "success"
        assert "item_id" in result

    def test_memorize_with_path_object(self, client_with_mock_session, mock_response, sample_memorize_response, tmp_path):
        """Memorize works with Path object."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_memorize_response)

        test_file = tmp_path / "test.txt"
        test_file.write_text("Test content")

        result = client.memorize(Path(test_file), user_name="Test User")

        assert result["status"] == "success"

    def test_memorize_with_bytes(self, client_with_mock_session, mock_response, sample_memorize_response):
        """Memorize works with bytes content."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_memorize_response)

        result = client.memorize(b"Test content bytes", user_name="Test User", filename="test.txt")

        assert result["status"] == "success"

    def test_memorize_bytes_default_filename(self, client_with_mock_session, mock_response, sample_memorize_response):
        """Memorize uses default filename for bytes."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_memorize_response)

        client.memorize(b"Test content", user_name="Test User")

        call_kwargs = client.session.post.call_args[1]
        file_tuple = call_kwargs["files"]["file"]
        assert file_tuple[0] == "upload.txt"

    def test_memorize_with_optional_params(self, client_with_mock_session, mock_response, sample_memorize_response):
        """Memorize sends optional parameters."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_memorize_response)

        client.memorize(
            b"Test content",
            user_name="Test User",
            item_id="custom_id_123",
            source_type="email"
        )

        call_kwargs = client.session.post.call_args[1]
        assert call_kwargs["data"]["user_name"] == "Test User"
        assert call_kwargs["data"]["item_id"] == "custom_id_123"
        assert call_kwargs["data"]["source_type"] == "email"

    def test_memorize_file_not_found(self, client_with_mock_session):
        """Memorize raises error for non-existent file."""
        client = client_with_mock_session

        with pytest.raises(ValidationError) as exc_info:
            client.memorize("/nonexistent/file.txt", user_name="Test")
        assert "File not found" in str(exc_info.value)

    def test_memorize_invalid_file_type(self, client_with_mock_session):
        """Memorize raises error for invalid file type."""
        client = client_with_mock_session

        with pytest.raises(ValidationError) as exc_info:
            client.memorize(12345, user_name="Test")  # Invalid type
        assert "must be a path string" in str(exc_info.value)

    def test_memorize_url_correct(self, client_with_mock_session, mock_response, sample_memorize_response):
        """Memorize calls correct endpoint."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_memorize_response)

        client.memorize(b"test", user_name="Test")

        call_url = client.session.post.call_args[0][0]
        assert "/v1/memorize" in call_url


class TestFeedback:
    """Tests for feedback method."""

    def test_feedback_positive(self, client_with_mock_session, mock_response, sample_feedback_response):
        """Feedback works with positive rating."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, sample_feedback_response)

        result = client.feedback("memory_123", rating=1, query_text="test query")

        assert result["status"] == "success"
        assert result["action"] == "rated"

    def test_feedback_negative(self, client_with_mock_session, mock_response):
        """Feedback works with negative rating."""
        client = client_with_mock_session
        response_data = {"status": "success", "action": "rated", "memory_id": "mem_1", "rating": -1}
        client.session.post.return_value = mock_response(200, response_data)

        result = client.feedback("mem_1", rating=-1, query_text="test")

        assert result["rating"] == -1

    def test_feedback_remove(self, client_with_mock_session, mock_response):
        """Feedback works with zero rating (remove)."""
        client = client_with_mock_session
        response_data = {"status": "success", "action": "removed", "memory_id": "mem_1", "rating": 0}
        client.session.post.return_value = mock_response(200, response_data)

        result = client.feedback("mem_1", rating=0, query_text="test")

        assert result["action"] == "removed"

    def test_feedback_invalid_rating(self, client_with_mock_session):
        """Feedback validates rating value."""
        client = client_with_mock_session

        with pytest.raises(ValidationError) as exc_info:
            client.feedback("mem_1", rating=5, query_text="test")
        assert "Rating must be -1, 0, or 1" in str(exc_info.value)

    def test_feedback_invalid_rating_negative(self, client_with_mock_session):
        """Feedback rejects invalid negative rating."""
        client = client_with_mock_session

        with pytest.raises(ValidationError):
            client.feedback("mem_1", rating=-2, query_text="test")

    def test_feedback_validates_query_length(self, client_with_mock_session):
        """Feedback validates query text length."""
        client = client_with_mock_session
        long_query = "x" * 1001

        with pytest.raises(ValidationError) as exc_info:
            client.feedback("mem_1", rating=1, query_text=long_query)
        assert "1000 characters" in str(exc_info.value)

    def test_feedback_sends_correct_data(self, client_with_mock_session, mock_response):
        """Feedback sends correct form data."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(200, {"status": "success", "action": "rated", "memory_id": "mem_1", "rating": 1})

        client.feedback("mem_1", rating=1, query_text="my query")

        call_kwargs = client.session.post.call_args[1]
        assert call_kwargs["data"]["memory_id"] == "mem_1"
        assert call_kwargs["data"]["rating"] == 1
        assert call_kwargs["data"]["query_text"] == "my query"


class TestErrorHandling:
    """Tests for API error handling."""

    def test_401_raises_authentication_error(self, client_with_mock_session, mock_response):
        """401 response raises AuthenticationError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(401, {"detail": "Invalid API key"})

        with pytest.raises(AuthenticationError) as exc_info:
            client.recall("test")
        assert "Invalid" in str(exc_info.value)

    def test_403_raises_authentication_error(self, client_with_mock_session, mock_response):
        """403 response raises AuthenticationError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(403, {"detail": "Forbidden"})

        with pytest.raises(AuthenticationError) as exc_info:
            client.recall("test")
        assert "Forbidden" in str(exc_info.value)

    def test_404_raises_not_found_error(self, client_with_mock_session, mock_response):
        """404 response raises NotFoundError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(404, {"detail": "Memory not found"})

        with pytest.raises(NotFoundError) as exc_info:
            client.feedback("nonexistent", rating=1, query_text="test")
        assert "not found" in str(exc_info.value).lower()

    def test_409_raises_validation_error(self, client_with_mock_session, mock_response):
        """409 response raises ValidationError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(409, {"detail": "Item already exists"})

        with pytest.raises(ValidationError) as exc_info:
            client.memorize(b"test", user_name="Test")
        assert "Conflict" in str(exc_info.value)

    def test_429_raises_rate_limit_error(self, client_with_mock_session, mock_response):
        """429 response raises RateLimitError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(429, {"detail": "Too many requests"})

        with pytest.raises(RateLimitError) as exc_info:
            client.recall("test")
        assert "Rate limit" in str(exc_info.value)

    def test_400_raises_validation_error(self, client_with_mock_session, mock_response):
        """400 response raises ValidationError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(400, {"detail": "Invalid input"})

        with pytest.raises(ValidationError) as exc_info:
            client.recall("test")
        assert "Invalid" in str(exc_info.value)

    def test_500_raises_api_error(self, client_with_mock_session, mock_response):
        """500 response raises APIError."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(500, {"detail": "Internal error"})

        with pytest.raises(APIError) as exc_info:
            client.recall("test")
        assert "500" in str(exc_info.value)

    def test_error_with_message_field(self, client_with_mock_session, mock_response):
        """Error handling works with 'message' field."""
        client = client_with_mock_session
        client.session.post.return_value = mock_response(400, {"message": "Bad request message"})

        with pytest.raises(ValidationError) as exc_info:
            client.recall("test")
        assert "Bad request message" in str(exc_info.value)

    def test_error_with_text_fallback(self, client_with_mock_session):
        """Error handling falls back to response text."""
        client = client_with_mock_session

        response = Mock(spec=requests.Response)
        response.status_code = 400
        response.text = "Plain text error"
        response.json.side_effect = ValueError("No JSON")
        response.raise_for_status.side_effect = requests.exceptions.HTTPError(response=response)

        client.session.post.return_value = response

        with pytest.raises(ValidationError) as exc_info:
            client.recall("test")
        assert "Plain text error" in str(exc_info.value)
