"""
Memory Machines API Client
"""
import requests
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from .exceptions import (
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    APIError
)
from .auth import get_token


class MemoryMachines:
    """
    Official Python client for Memory Machines API.

    Example:
        >>> from memorymachines import MemoryMachines

        # Auto-discover API key from config file or environment
        >>> mm = MemoryMachines()

        # Or specify explicitly
        >>> mm = MemoryMachines(api_key="your_api_key")

        # Or use a specific profile
        >>> mm = MemoryMachines(profile="work")

        >>> response = mm.ask("what did I discuss last week?")
        >>> print(response['response'])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        profile: Optional[str] = None,
        base_url: str = "https://memorymachines-core-api-mvp-gateway-6v1lw71z.uc.gateway.dev"
    ):
        """
        Initialize Memory Machines client.

        API key resolution order:
        1. Explicit api_key parameter
        2. MM_API_KEY environment variable
        3. ~/.memorymachines/config.yaml (active profile or specified profile)

        Args:
            api_key: Your Memory Machines API key. If not provided, auto-discovered.
            profile: Config profile to use (default: active profile)
            base_url: API base URL (default: production)

        Raises:
            AuthenticationError: If no API key found
        """
        # Auto-discover API key if not provided
        if api_key is None:
            api_key = get_token(profile=profile)

        if api_key is None:
            raise AuthenticationError(
                "No API key found. Either:\n"
                "  1. Pass api_key='...' to MemoryMachines()\n"
                "  2. Set MM_API_KEY environment variable\n"
                "  3. Run `memorymachines login` or `login(token='...')`"
            )

        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()

    def _handle_response(self, response: requests.Response) -> Any:
        """Handle API response and raise appropriate exceptions."""
        try:
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code

            try:
                error_data = e.response.json()
                error_msg = error_data.get('detail', error_data.get('message', 'Unknown error'))
            except:
                error_msg = e.response.text or 'Unknown error'

            if status_code == 401:
                raise AuthenticationError(f"Invalid or expired API key: {error_msg}")
            elif status_code == 403:
                raise AuthenticationError(f"Forbidden: {error_msg}")
            elif status_code == 404:
                raise NotFoundError(f"Resource not found: {error_msg}")
            elif status_code == 409:
                raise ValidationError(f"Conflict: {error_msg}")
            elif status_code == 429:
                raise RateLimitError("Rate limit exceeded. Please try again later.")
            elif status_code == 400:
                raise ValidationError(f"Invalid request: {error_msg}")
            else:
                raise APIError(f"API error ({status_code}): {error_msg}")

    def memorize(
        self,
        file: Union[str, Path, bytes],
        user_name: str,
        item_id: Optional[str] = None,
        source_type: Optional[str] = None,
        filename: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Upload a document for memory extraction and processing.

        Args:
            file: File path, Path object, or bytes content to upload
            user_name: User's name for first-person narratives in memory extraction
            item_id: Optional unique identifier for this item (auto-generated if not provided)
            source_type: Optional source type (text, email, pdf, stream, browser, vscode, calendar, github, slack)
            filename: Filename to use when passing bytes (required if file is bytes)

        Returns:
            Response dict with status, user_id, item_id, and workflow_execution

        Example:
            >>> result = client.memorize("meeting_notes.pdf", user_name="John")
            >>> print(result['item_id'])

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If input is invalid
            RateLimitError: If rate limit is exceeded
        """
        # Prepare file for upload
        if isinstance(file, bytes):
            if filename is None:
                filename = "upload.txt"
            file_tuple = (filename, file)
        elif isinstance(file, (str, Path)):
            file_path = Path(file)
            if not file_path.exists():
                raise ValidationError(f"File not found: {file}")
            file_tuple = (file_path.name, open(file_path, 'rb'))
        else:
            raise ValidationError("file must be a path string, Path object, or bytes")

        # Prepare form data
        data = {'user_name': user_name}
        if item_id:
            data['item_id'] = item_id
        if source_type:
            data['source_type'] = source_type

        try:
            response = self.session.post(
                f"{self.base_url}/v1/memorize",
                headers={'x-api-key': self.api_key},
                files={'file': file_tuple},
                data=data
            )
            return self._handle_response(response)
        finally:
            # Close file handle if we opened it
            if isinstance(file, (str, Path)) and hasattr(file_tuple[1], 'close'):
                file_tuple[1].close()

    def ask(self, text: str) -> Dict[str, Any]:
        """
        Ask a question and get AI-generated responses based on your memories.

        Args:
            text: Query text (max 1000 characters)

        Returns:
            Response dict with 'response' containing the AI-generated answer

        Example:
            >>> result = client.ask("What did I discuss about the product launch?")
            >>> print(result['response'])

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If query is invalid
            RateLimitError: If rate limit is exceeded
        """
        if len(text) > 1000:
            raise ValidationError("Query text must be 1000 characters or less")

        response = self.session.post(
            f"{self.base_url}/v1/memories/ask",
            headers={'x-api-key': self.api_key},
            data={'text': text}
        )
        return self._handle_response(response)

    def recall(self, text: str) -> Dict[str, Any]:
        """
        Recall memories based on semantic similarity.

        Args:
            text: Query text (max 1000 characters)

        Returns:
            Response dict with 'memories', 'qa', and 'chunks' arrays

        Example:
            >>> result = client.recall("meetings about Q4 goals")
            >>> for memory in result['memories']:
            ...     print(memory)

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If query is invalid
            RateLimitError: If rate limit is exceeded
        """
        if len(text) > 1000:
            raise ValidationError("Query text must be 1000 characters or less")

        response = self.session.post(
            f"{self.base_url}/v1/memories/recall",
            headers={'x-api-key': self.api_key},
            data={'text': text}
        )
        return self._handle_response(response)

    def feedback(
        self,
        memory_id: str,
        rating: int,
        query_text: str
    ) -> Dict[str, Any]:
        """
        Rate a memory as relevant or not relevant for a specific query.

        Args:
            memory_id: The memory custom_id to rate
            rating: Rating value (1 for positive, -1 for negative, 0 to remove rating)
            query_text: The query that surfaced this memory (max 1000 characters)

        Returns:
            Response dict with status, action, memory_id, and rating

        Example:
            >>> client.feedback("item123_memory_0", rating=1, query_text="Q4 goals")

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If input is invalid
            NotFoundError: If memory not found
        """
        if rating not in (-1, 0, 1):
            raise ValidationError("Rating must be -1, 0, or 1")
        if len(query_text) > 1000:
            raise ValidationError("Query text must be 1000 characters or less")

        response = self.session.post(
            f"{self.base_url}/v1/memories/feedback",
            headers={'x-api-key': self.api_key},
            data={
                'memory_id': memory_id,
                'rating': rating,
                'query_text': query_text
            }
        )
        return self._handle_response(response)

    def health_check(self) -> bool:
        """
        Check if API is accessible.

        Returns:
            True if API is healthy
        """
        try:
            response = self.session.get(f"{self.base_url}/v1/health")
            return response.status_code == 200
        except:
            return False

    def close(self):
        """Close the underlying session."""
        if self.session:
            self.session.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close session."""
        self.close()
        return False
