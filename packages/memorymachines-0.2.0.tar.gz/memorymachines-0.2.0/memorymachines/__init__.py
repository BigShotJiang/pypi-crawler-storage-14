"""
Memory Machines Python SDK

Official Python SDK for Memory Machines API.

Quick Start:
    # First time: save your API key
    >>> from memorymachines import login
    >>> login("mm_sk_...")

    # Then just use it (no api_key needed)
    >>> from memorymachines import MemoryMachines
    >>> mm = MemoryMachines()
    >>> mm.ask("what did I discuss last week?")
"""

from .client import MemoryMachines

from .auth import (
    login,
    logout,
    whoami,
    get_token,
    list_profiles,
    set_active_profile,
)
from .exceptions import (
    MemoryMachinesError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    APIError
)

__version__ = "0.2.0"
__all__ = [
    # Client
    "MemoryMachines",
    # Auth
    "login",
    "logout",
    "whoami",
    "get_token",
    "list_profiles",
    "set_active_profile",
    # Exceptions
    "MemoryMachinesError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "APIError",
]
