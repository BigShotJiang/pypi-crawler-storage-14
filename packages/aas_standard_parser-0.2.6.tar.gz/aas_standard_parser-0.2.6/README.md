# aas-standard-parser
Some auxiliary functions for parsing standard submodels
