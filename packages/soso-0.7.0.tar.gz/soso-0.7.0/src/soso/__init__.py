"""soso: For creating Science On Schema.Org (SOSO) markup."""

from importlib.metadata import version

__version__ = version("soso")
