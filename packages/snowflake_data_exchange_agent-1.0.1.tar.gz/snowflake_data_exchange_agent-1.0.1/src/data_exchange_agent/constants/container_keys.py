"""Container-related constants."""

SF_LOGGER = "sf_logger"
PROGRAM_CONFIG = "program_config"
TASK_SOURCE_ADAPTER = "task_source_adapter"
TASK_MANAGER = "task_manager"
