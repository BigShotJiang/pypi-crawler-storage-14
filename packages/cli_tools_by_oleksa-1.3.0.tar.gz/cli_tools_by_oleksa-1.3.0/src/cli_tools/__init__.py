import warnings

from .utils import  safe_int, safe_float, split, extract_match, safe_run, try_until_ok, format_iterable, format_table
from .cli import valid_input, get_valid_input, choose_from_list, print_iterable, print_table, print_header


__all__ = [
    'safe_run',
    'try_until_ok',
    'safe_int',
    'safe_float',
    'split',
    'extract_match',
    'format_iterable',
    'format_table',
    'valid_input',
    'get_valid_input',
    'choose_from_list',
    'print_iterable',
    'print_table',
    'print_header'
]


def print_zipped_iterable(*args, **kwargs):
    warnings.warn(
        "print_zipped_iterable is deprecated and will be removed in a future version. Use print_table instead.",
        DeprecationWarning,
        stacklevel=2
    )
    return print_table(*args, **kwargs)
