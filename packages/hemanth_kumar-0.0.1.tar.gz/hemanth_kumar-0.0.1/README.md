** this is a library where you can check the Simple anomaly detector for sensor readings using PyOD's Isolation Forest.
Features used: temperature, humidity.
