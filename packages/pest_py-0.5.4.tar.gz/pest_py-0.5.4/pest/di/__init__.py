from .injection import inject as inject
from .injection import inject as injected

__all__ = ['inject', 'injected']
