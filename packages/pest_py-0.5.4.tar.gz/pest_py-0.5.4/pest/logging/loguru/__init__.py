from .loguru import Loguru

__all__ = [
    'Loguru',
]
