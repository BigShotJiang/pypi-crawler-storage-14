# Tools for making decorators.

## Installation

You can install from [pypi](https://pypi.org/project/python-decotools/)

```console
pip install -U python-decotools
```

## Usage

```python
import decotools
```
