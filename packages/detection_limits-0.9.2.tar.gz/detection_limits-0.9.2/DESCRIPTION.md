# NIST detection limits and image quality metrics for SEM images

This package provides tools for:

- Extracting image quality metrics from simulated SEM image collections.
- Merging image quality metrics with AI model accuracy metrics.
- Plotting relationships between image quality and AI detection performance.
