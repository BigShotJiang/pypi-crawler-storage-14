# Copyright (c) 2014 Plivo Team. See LICENSE.txt for details.
#  Copyright (c) 2025 Flowdacity Development Team. See LICENSE.txt for details.
from .queue import FQ

__version__ = "0.1.0"
__all__ = ["FQ", "__version__"]
