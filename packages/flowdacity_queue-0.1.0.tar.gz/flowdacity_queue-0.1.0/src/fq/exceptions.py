# -*- coding: utf-8 -*-
# Copyright (c) 2014 Plivo Team. See LICENSE.txt for details.


class FQException(Exception):
    pass


class BadArgumentException(FQException):
    pass
