"""
Athena - AI-powered infrastructure orchestration CLI.

A natural language interface for managing infrastructure,
executing commands, and automating operations.
"""

__version__ = "0.1.0"
__author__ = "Athena Contributors"
