class Course:
    def __init__(self, name, duration, link):
        self.name = name
        self.duration = duration
        self.link = link

    def __str__(self):
        return f"{self.name} dura {self.duration} horas y su link es: {self.link}"

courses = [
    Course("Introduccion a Linux", 15, "https://hack4u.io/cursos/introduccion-a-linux/"),
    Course("Personalizacion de Linux", 3, "https://hack4u.io/cursos/personalizacion-de-entorno-en-linux"),
    Course("Introduccion al Hacking", 53, "https://hack4u.io/cursos/introduccion-al-hacking/")
]

def list_courses():
    for course in courses:
        print(course)

def search_course_by_name(course_name):
    for course in courses:
        if course.name == course_name:
            return course
    raise ValueError(f"[!] No se ha encontrado el curso por el nombre {course_name}")
