from .courses import courses

def total_duration():
    return sum(course.duration for course in courses) # devuelve la sumatoria de la duracion de todos los cursos
