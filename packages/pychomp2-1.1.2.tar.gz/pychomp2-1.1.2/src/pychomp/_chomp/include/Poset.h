/// Poset.h
/// Shaun Harker
/// 2018-03-13
/// MIT LICENSE

