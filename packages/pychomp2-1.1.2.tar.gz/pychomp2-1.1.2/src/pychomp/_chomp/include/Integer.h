/// Integer.h
/// Shaun Harker
/// 2017-07-18
/// MIT LICENSE

#pragma once

#include <cstdint>

typedef int64_t Integer;
