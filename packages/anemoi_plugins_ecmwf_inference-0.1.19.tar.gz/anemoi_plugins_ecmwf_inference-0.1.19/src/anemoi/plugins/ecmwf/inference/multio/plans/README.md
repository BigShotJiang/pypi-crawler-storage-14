# Example plans for multio

This directory contains example plans to be used with this output plugin.
