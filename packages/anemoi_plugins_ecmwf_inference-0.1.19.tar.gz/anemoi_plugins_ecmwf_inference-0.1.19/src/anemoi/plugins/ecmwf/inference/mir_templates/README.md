# An anemoi-inference mir grib templates plugin

Use `mir` to dynamically create grib templates of the correct geometry.

## Example

Use with the grib output

```yaml

output:
  grib:
    path: data.grib
    templates: 'mir'

```
