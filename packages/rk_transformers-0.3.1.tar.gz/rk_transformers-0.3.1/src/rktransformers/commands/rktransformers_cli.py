# Copyright 2025 Emmanuel Cortes. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from optimum.commands.base import CommandInfo, RootOptimumCLICommand

from rktransformers.commands.register.register_rknn import REGISTER_COMMANDS


def main():
    root = RootOptimumCLICommand("RKTransformers CLI", usage="rk-transformers-cli")

    for command_cls, _ in REGISTER_COMMANDS:
        command_info = CommandInfo(
            name=command_cls.COMMAND.name,
            help=command_cls.COMMAND.help,
            subcommand_class=command_cls,
        )
        root.register_subcommand(command_info)

    args = root.parser.parse_args()

    if not hasattr(args, "func"):
        root.parser.print_help()
        exit(1)

    service = args.func(args)
    service.run()


if __name__ == "__main__":
    main()
