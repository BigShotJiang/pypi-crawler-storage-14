from .time import clear
