# logger.py
import datetime
#import time

def log_method_called(parameters):
    with open("log.txt", "a", encoding="utf-8") as log_file:
        log_file.write(f"{datetime.datetime.now()} - Method called with parameters: {parameters}\n")

def log_state_start(state):
    with open("log.txt", "a", encoding="utf-8") as log_file:
        log_file.write(f"{datetime.datetime.now()} - Pattern started with state: {state}\n")

def log_state_end(state):
    with open("log.txt", "a", encoding="utf-8") as log_file:
        log_file.write(f"{datetime.datetime.now()} - Pattern ended with state: {state}\n")

log_method_called("test")
log_state_start("test")
log_state_end("test")