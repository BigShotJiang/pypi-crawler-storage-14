# base of this module is from step two of:
# https://realpython.com/conway-game-of-life-python/#step-2-code-the-game-of-lifes-grid


import collections

#import patterns
#import logger
from . import logger
from . import patterns

# global constants
ALIVE = "¤"
DEAD = "‧"


class Grid:
    def __init__(self, pattern):
        self.pattern = pattern

    def evolve(self):
        # define the delta coordinates for the neighbors of the target cell.
        neighbors = (
            (-1, -1),  # Above left
            (-1, 0),  # Above
            (-1, 1),  # Above right
            (0, -1),  # Left
            (0, 1),  # Right
            (1, -1),  # Below left
            (1, 0),  # Below
            (1, 1),  # Below right
        )
        # creates a dictionary for counting the number of living neighbors. In this line, you use the defaultdict class from the collections module to build the counter with the int class as its default factory.
        num_neighbors = collections.defaultdict(int)

        # runs a loop over the currently alive cells, which are stored in the .pattern object. This loop allows you to check the neighbors of each living cell so that you can determine the next generation of living cells.
        for row, column in self.pattern.alive_cells:
            # starts a loop over the neighbor deltas. This inner loop counts how many cells the current cell neighbors. This count allows you to know the number of living neighbors for both living and dead cells.
            for drow, dcolumn in neighbors:
                num_neighbors[(row + drow, column + dcolumn)] += 1

        #  build a set containing the cells that will stay alive. To do this, you first create a set of neighbors that have two or three alive neighbors themselves. Then, you find the cells that are common to both this set and .alive_cells.
        stay_alive = {cell for cell, num in num_neighbors.items() if num in {2, 3}} & self.pattern.alive_cells # Bitwise AND Assignment Operator

        # create a set with the cells that will come alive. In this case, you create a set of neighbors that have exactly three living neighbors. Then, you determine the cells that come alive by removing cells that are already in .alive_cells.
        come_alive = {cell for cell, num in num_neighbors.items() if num == 3} - self.pattern.alive_cells

        # updates .alive_cells with the set that results as the union of the cells that stay alive and those that come alive.
        self.pattern.alive_cells = stay_alive | come_alive # Bitwise OR Assignment Operator

    def to_string(self, bounding_box):

        logger.log_method_called(bounding_box)

        #  unpack the bounding box coordinates into four variables
        # These variables define which part of the infinite grid the program will display on the screen
        start_column, start_row, end_column, end_row = bounding_box

        # a list containing the pattern’s name
        display = [self.pattern.name.center(2 * (end_column - start_column))]

        # iterates over the range of rows inside the view
        for row in range(start_row, end_row):
            # new list containing the alive and dead cells in the current row
            display_row = [
                # to figure out if a given cell is alive,  check if its coordinates are in the set of alive cells
                ALIVE if (row, column) in self.pattern.alive_cells else DEAD
                for column in range(start_column, end_column)]

            #  append the row as a string to the display list
            display.append(" ".join(display_row))
        # join together every string using a newline character (\n) to create the life grid as a string
        return "\n ".join(display)

    def __str__(self):
        return (f"{self.pattern.name}:\n"
            f"Alive cells -> {sorted(self.pattern.alive_cells)}")

blinker = patterns.Pattern("Blinker", {(2, 1), (2, 2), (2, 3)})
grid = Grid(blinker)
print(grid.to_string((0, 0, 5, 5)))
#grid.evolve()
#print(grid.to_string((0, 0, 5, 5)))