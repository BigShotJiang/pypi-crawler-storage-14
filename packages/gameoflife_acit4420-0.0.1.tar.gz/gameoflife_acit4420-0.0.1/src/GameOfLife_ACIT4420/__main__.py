# following tutorial from https://realpython.com/conway-game-of-life-python
# then modifying to fit project requirements, as much as possible

#import patterns, views
from . import patterns, views
import sys

import re

def _show_pattern(view, pattern,generations,frame_rate,boundary_box ):
    try:
        view(pattern=pattern, generations=generations, frame_rate=frame_rate, boundary_box=boundary_box).show()
    except Exception as error:
        print(error, file=sys.stderr)

def main():
    #views.CursesView(patterns.get_pattern("Blinker"), generations=100).show()

    View = getattr(views, "CursesView")
    generations = 10
    frame_rate = 2
    boundary_box = (0, 0, 6, 5)


    print("\nGame of Life module begun")
    print("This module simply shows the patterns within the included pattern.toml")
    print("If the user wishes to add more patterns, this will have to be done within patterns.toml")
    print("Generations can be thought of as long the patterns evolve, and frame rate is how quickly it goes through the generations")
    while True:
        print("\nEnter the number of the option to continue")
        print("1. Show all patterns")
        print("2. Choose a pattern")
        #print("3. Add a pattern")
        print("3. Change view of grid")
        print("4. Change generations and frame rate")
        print("5. Quit")
        answer = input()

        if answer == "1":
            for pattern in patterns.get_all_patterns():
                _show_pattern(View, pattern, generations, frame_rate, boundary_box)

        elif answer == "2":

            pattern_options = ""
            for pat in patterns.get_all_patterns():
                pattern_options += pat.name.lower() + ", "
            pattern_options = pattern_options[:-2] # removes the extra comma and space at end

            pattern_validity = False
            while not pattern_validity:
                print("Pattern Choices")
                print(pattern_options)
                pattern = input()
                pattern = pattern.lower()

                match = re.search(rf'\b{re.escape(pattern)}\b', pattern_options)
                try:
                    pattern = pattern[0].upper() + pattern[1:]  # Capitalizes the first letter, as the first letters are capitalized in the toml
                    if not match:
                        print("Invalid pattern, try again")
                    else:
                       pattern_validity = True
                       _show_pattern(View, patterns.get_pattern(pattern), generations, frame_rate, boundary_box)
                except Exception as error:
                    print(error)
                    print("Invalid pattern, try again")



        elif answer == "3":

            columns = 6
            rows = 5

            columns_validity = False
            while not columns_validity:
                try:
                    print("Input first value for view, this value is the amount of columns, default is 6")
                    columns = int(input("Enter the number of columns: "))
                    columns_validity = True
                    if columns < 5:
                        print("WARNING, number of columns may be too low to see all patterns")
                except ValueError:
                    print("Invalid input, try again")


            rows_validity = False
            while not rows_validity:
                try:
                    print("Input second value for view, this value is the amount of rows, default is 5")
                    rows = int(input("Enter the number of rows: "))
                    rows_validity = True
                    if rows < 4:
                        print("WARNING, number of rows may be too low to see all patterns")
                except ValueError:
                    print("Invalid input, try again")

            boundary_box = (0, 0, columns, rows)

        elif answer == "4":
            generations_validity = False
            while not generations_validity:
                try:
                    print("Input new value for generations, default is 100")
                    generations = int(input("Enter the number of generations: "))
                    generations_validity = True
                except ValueError:
                    print("Invalid input, try again")

            frameRate_validity = False
            while not frameRate_validity:
                try:
                    print("Input new value for frame rate, default is 2")
                    frame_rate = int(input("Enter the new frame rate: "))
                    frameRate_validity = True
                except ValueError:
                    print("Invalid input, try again")

        elif answer == "5":
            exit(0)

main()

       # elif answer == "3":

       #     name = input("Enter the name: ")

      #      print("Enter the cell coordinates as pairs . Type 'done' when finished.")

        #    alive_cells = []  # List to store the cell coordinates
       #     while True:
       #         cell_input = input("Enter a cell coordinate or 'done' to finish: ")
       #         if cell_input.lower() == "done":
       #             break
       #         try:
        #            x, y = map(int, cell_input.split(","))
        #            alive_cells.append([x, y])
        #        except ValueError:
        #            print("Invalid input. Please enter coordinates in the format x,y")

        #    data = {name: {"alive_cells": alive_cells}}
         #   patterns.add_pattern(data)