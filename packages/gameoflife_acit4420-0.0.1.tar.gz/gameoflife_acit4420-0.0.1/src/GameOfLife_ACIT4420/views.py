# https://realpython.com/conway-game-of-life-python/#step-4-write-the-games-view

# https://pypi.org/project/windows-curses/
import curses
from time import sleep

#import grid
#import logger

from . import grid
from . import logger

# The special __all__ attribute allows you to define the list of names that the underlying module will export as part of its public interface.
# In this example, __all__ contains only one view object because that’s what you have so far.
# You can implement your own views as part of your practice and add them to this list so that the user can use them when running the game.
__all__ = ["CursesView"]


class CursesView:
    def __init__(self, pattern, generations=10, frame_rate=2, boundary_box=(0, 0, 6, 5)):
        self.pattern = pattern
        self.generations = generations
        self.frame_rate = frame_rate
        self.boundary_box = boundary_box
        parameters = [pattern, generations, frame_rate, boundary_box]
        logger.log_method_called(parameters)

    def show(self):
        curses.wrapper(self._draw)

    #  takes a screen or curses window object as an argument. This object is automatically passed in when you call curses.wrapper() with ._draw() as an argument.
    def _draw(self, screen):
        # defines the life grid by instantiating the LifeGrid class with the current pattern as an argument
        current_grid = grid.Grid(self.pattern)
        # set the cursor’s visibility, 0 sets it to invisible
        curses.curs_set(0)
        screen.clear()

        try:
            screen.addstr(0, 0, current_grid.to_string(self.boundary_box))
        #  raises a ValueError exception when the current terminal window doesn’t have enough space to display the life grid
        except curses.error:
            raise ValueError(f"Error: terminal too small for pattern '{self.pattern.name}'")

        logger.log_state_start(screen.addstr(0, 0, current_grid.to_string(self.boundary_box)))

        # will run as many times as the number of generations
        for _ in range(self.generations):
            #  calls .evolve() on the grid to evolve the game to the next generation
            current_grid.evolve()
            #  calls .addstr() on the current screen object. The first two arguments define the row and column where you want to start drawing the life grid. In this tutorial, you’ll start the drawing at (0, 0), which is the upper left corner of the terminal window.
            screen.addstr(0, 0, current_grid.to_string(self.boundary_box))
            # This call updates the screen immediately to reflect the changes from the previous call to .addstr()
            screen.refresh()

            # calls sleep() to set the frame rate that you’ll use to display consecutive generations in the grid
            sleep(1 / self.frame_rate)

        logger.log_state_end(screen.addstr(0, 0, current_grid.to_string(self.boundary_box)))
