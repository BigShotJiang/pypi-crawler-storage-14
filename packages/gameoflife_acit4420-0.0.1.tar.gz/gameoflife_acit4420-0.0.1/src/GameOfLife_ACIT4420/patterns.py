# https://realpython.com/conway-game-of-life-python/#step-3-define-and-load-the-life-patterns

# todo: change from toml to txt, perhaps will improve usage of regex

from dataclasses import dataclass
from pathlib import Path
#import re

import tomllib
# import tomli as tomllib

# tomllib does not support writing, hence tomli-w
# import tomli_w

PATTERNS_FILE = Path(__file__).parent / "patterns.toml"

@dataclass
class Pattern:
    name: str
    alive_cells: set[tuple[int, int]]
    """
    @classmethod
    def from_regex(cls, name, alive_cells_data):
        # Create and return an instance of the class
        return cls(
            name,
            # Convert string representation of alive_cells into a set of tuples
            alive_cells={tuple(cell) for cell in eval(alive_cells_data)},)
    """
    @classmethod
    # clas is the current class
    def from_toml(cls, name, toml_data):
        # create and return an instance of the class
        return cls(name,
            # set comprehension
            #  create a set of tuples from the list of lists that you get from the TOML file
            #  each tuple will contain the coordinates of a living cell on the life grid
            alive_cells={tuple(cell) for cell in toml_data["alive_cells"]})


"""
# Function to get a specific pattern by name using regex
def get_pattern(name, filename=PATTERNS_FILE):
    # Read the file content
    file_content = filename.read_text(encoding="utf-8")
    print(file_content)

    # Use regex to find the specific pattern section
    #pattern_regex = rf'$$"{name}"$$\s+alive_cells\s*=\s*($$\[.*?$$\])'
    match = re.search(pattern_regex, file_content, re.DOTALL)

    if match:
        alive_cells_data = match.group(1)  # Extract the alive_cells data
        return Pattern.from_regex(name, alive_cells_data)
    else:
        print(f"Pattern '{name}' not found in the file.")


# Function to get all patterns from the file using regex
def get_all_patterns(filename=PATTERNS_FILE):
    # Read the file content
    file_content = filename.read_text(encoding="utf-8")

    # Use regex to find all pattern sections
    pattern_regex = r'$$"(.*?)"$$\s+alive_cells\s*=\s*($$\[.*?$$\])'
    matches = re.findall(pattern_regex, file_content, re.DOTALL)

    # Create a list of Pattern instances
    return [Pattern.from_regex(name, alive_cells_data) for name, alive_cells_data in matches]
"""

# takes the name of a target pattern and the name of the TOML file as arguments and returns a Pattern instance representing the pattern whose name matches the name argument.
def get_pattern(name, filename=PATTERNS_FILE):
    #  load the content of patterns.toml using the TOML library of choice
    # .loads() method returns a dictionary
    data = tomllib.loads(filename.read_text(encoding="utf-8"))
    # create the instance of Pattern using the .from_toml() constructor and return the result
    return Pattern.from_toml(name, toml_data=data[name])

# gets all the patterns from the TOML file.
def get_all_patterns(filename=PATTERNS_FILE):
    # same as get_pattern
    data = tomllib.loads(filename.read_text(encoding="utf-8"))
    # create a list of instances of Pattern using a comprehension
    return [Pattern.from_toml(name, toml_data) for name, toml_data in data.items()]
"""
def add_pattern(data, filename=PATTERNS_FILE):
    print(data)
    existing_data = tomllib.loads(filename.read_text(encoding="utf-8"))
    if str(data.get("name")) in existing_data:
        print(f"'{data["name"]}' already exists.")
        return
    # tomli_w always wipes the file, so need to append new data to old data
    existing_data.update(data)
    with open(filename, "wb") as toml_file:  # Open in binary write mode
        tomli_w.dump(existing_data, toml_file)
"""
#print(get_pattern("Blinker"))
#print(get_all_patterns())
#print(add_pattern({"name":"block", "alive_cells": [[1, 1], [1, 2], [2, 2],[2,1]]}))