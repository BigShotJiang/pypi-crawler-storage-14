# ACIT4420 Final Assignment Part 2

## Description & Usage

from GameOfLife_ACIT4420 import main