#!/usr/bin/env python
"""
Tests for the `openedx-authz` models module.
"""
