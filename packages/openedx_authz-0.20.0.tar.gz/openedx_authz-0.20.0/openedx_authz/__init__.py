"""
Open edX AuthZ provides the architecture and foundations of the authorization framework.
"""

import os

__version__ = "0.20.0"

ROOT_DIRECTORY = os.path.dirname(os.path.abspath(__file__))
