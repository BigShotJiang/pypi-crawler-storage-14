# GoQuality Documentation Plan

> **Purpose:** Define the structure, content, and scope of GoQuality's documentation site.

---

## Overview

### Documentation Goals

1. **Onboard new users in < 5 minutes** - Quick start to first validation
2. **Enable self-service** - Users find answers without support
3. **Showcase AI differentiation** - Emphasize YAML-as-AI-interface
4. **Drive adoption** - Clear path from trial → paid conversion
5. **Build trust** - Comprehensive reference establishes credibility

### Target Audiences

| Audience | Needs | Priority |
|----------|-------|----------|
| **Data Engineers** | Quick setup, CLI mastery, CI/CD integration | Primary |
| **Analytics Engineers** | dbt integration, type composition | Primary |
| **Data Platform Teams** | Architecture, scaling, multi-DB | Secondary |
| **Engineering Managers** | ROI, comparison with alternatives | Tertiary |

### Documentation Principles

- **Code-first**: Every concept has runnable examples
- **Progressive disclosure**: Simple → Advanced
- **Copy-paste friendly**: All examples work as-is
- **Version-aware**: Docs match CLI version

---

## Site Structure

```
docs/
├── index.md                    # Landing page
├── getting-started/
│   ├── introduction.md
│   ├── installation.md
│   ├── quickstart.md
│   └── first-validation.md
├── concepts/
│   ├── philosophy.md
│   ├── types-vs-tests.md
│   ├── ai-generation.md
│   └── yaml-as-interface.md
├── guides/
│   ├── defining-types.md
│   ├── mapping-models.md
│   ├── running-checks.md
│   ├── ci-cd-integration.md
│   ├── dbt-integration.md
│   └── team-workflows.md
├── type-library/
│   ├── overview.md
│   ├── core.md
│   ├── finance.md
│   ├── healthcare.md
│   ├── ecommerce.md
│   ├── regional.md
│   └── custom-types.md
├── databases/
│   ├── overview.md
│   ├── postgresql.md
│   ├── snowflake.md
│   ├── bigquery.md
│   └── duckdb.md
├── cli-reference/
│   ├── overview.md
│   ├── init.md
│   ├── generate.md
│   ├── check.md
│   ├── validate.md
│   ├── types.md
│   ├── doctor.md
│   └── stats.md
├── configuration/
│   ├── goquality-yaml.md
│   ├── connections.md
│   ├── environment-variables.md
│   └── project-structure.md
├── advanced/
│   ├── custom-validators.md
│   ├── plugin-system.md
│   ├── extending-types.md
│   └── performance.md
├── integrations/
│   ├── github-actions.md
│   ├── gitlab-ci.md
│   ├── airflow.md
│   ├── prefect.md
│   └── slack-alerts.md
├── troubleshooting/
│   ├── common-errors.md
│   ├── debugging.md
│   └── faq.md
├── api-reference/
│   └── python-sdk.md
└── resources/
    ├── changelog.md
    ├── migration-guide.md
    ├── comparison.md
    └── glossary.md
```

---

## Section Details

### 1. Getting Started

**Goal:** User runs first validation in under 5 minutes.

#### 1.1 Introduction (`getting-started/introduction.md`)

**Content:**
- What is GoQuality? (2-3 sentences)
- The problem it solves (data quality at scale)
- Key differentiator: "Types, not tests"
- AI-native: YAML as the interface between humans and AI
- 30-second video/GIF demo

**Structure:**
```markdown
# Introduction

## What is GoQuality?
One paragraph explaining the core value proposition.

## The Problem
- Data teams write repetitive validation logic
- Tests are scattered, inconsistent, hard to maintain
- No leverage from AI - every rule is manual

## The Solution
- Define types once, validate everywhere
- AI generates type mappings from your schema
- Human governance over machine-generated rules
- Version-controlled YAML = audit trail

## How It Works
[Diagram: Database → AI Inference → YAML → Validation]

## Key Features
- 300+ pre-built types
- Multi-database support
- AI-powered type inference
- CI/CD ready
- Extensible plugin system

## Next Steps
→ [Installation](installation.md)
→ [5-Minute Quickstart](quickstart.md)
```

**Assets needed:**
- Hero diagram showing the flow
- 30-second terminal recording (asciinema)
- Feature comparison table

---

#### 1.2 Installation (`getting-started/installation.md`)

**Content:**
- System requirements
- pip installation (basic + extras)
- Docker option
- Verifying installation
- Shell completion setup

**Structure:**
```markdown
# Installation

## Requirements
- Python 3.10+
- pip or pipx

## Quick Install
pip install goquality

## Database Drivers
[Table of extras: postgres, snowflake, bigquery, all]

## Docker
docker pull goquality/goquality:latest

## Verify Installation
goquality version
goquality doctor

## Shell Completion
[Bash, Zsh, Fish instructions]

## Troubleshooting
- Permission errors
- Python version issues
- Missing dependencies
```

---

#### 1.3 Quickstart (`getting-started/quickstart.md`)

**Content:**
- End-to-end example in 5 minutes
- Uses DuckDB (no external DB needed)
- Sample CSV data included
- Shows init → generate → check flow

**Structure:**
```markdown
# 5-Minute Quickstart

## What You'll Build
A data quality check for a sample e-commerce dataset.

## Step 1: Install
pip install goquality

## Step 2: Get Sample Data
curl -O https://goquality.dev/samples/orders.csv

## Step 3: Initialize
goquality init

## Step 4: Generate Types (AI)
export OPENAI_API_KEY=your-key
goquality generate --source orders.csv

## Step 5: Review Generated Config
[Show generated YAML with annotations]

## Step 6: Run Checks
goquality check --source orders.csv

## Step 7: Interpret Results
[Explain output table]

## What's Next?
- Connect to your real database
- Customize types
- Set up CI/CD

[Link to each next step]
```

---

#### 1.4 First Real Validation (`getting-started/first-validation.md`)

**Content:**
- Connect to real PostgreSQL/Snowflake
- Generate types for existing table
- Edit/customize the generated YAML
- Run validation and fix issues

**Structure:**
```markdown
# Your First Real Validation

## Prerequisites
- GoQuality installed
- Access to a database (Postgres, Snowflake, etc.)

## Step 1: Connect to Your Database
goquality doctor --source postgres://...

## Step 2: Generate Types
goquality generate --source postgres://... --schema public

## Step 3: Understand the Output
[Annotated YAML walkthrough]

## Step 4: Customize
- Change a type
- Add a constraint
- Mark a column as nullable

## Step 5: Validate
goquality check --source postgres://...

## Step 6: Fix Issues
[Common patterns: wrong type, missing nullable, regex too strict]

## Step 7: Commit to Version Control
git add goquality.yaml
git commit -m "Add data quality types"
```

---

### 2. Concepts

**Goal:** Build mental model for effective use.

#### 2.1 Philosophy (`concepts/philosophy.md`)

**Content:**
- Why "types" instead of "tests"
- Inspiration from TypeScript/Rust
- Composition over repetition
- Declarative > Imperative
- Human governance, machine execution

**Key Points:**
```markdown
# Philosophy

## Types > Tests

Traditional approach:
- Write test: "email column matches regex"
- Write test: "email column is not null"
- Write test: "email column is unique"
- Repeat for every table...

GoQuality approach:
- Define type: Email (pattern, not null, unique)
- Map: users.email → Email
- Done.

## The Type Hierarchy
[Diagram showing inheritance: String → Email → CorporateEmail]

## Declarative Configuration
What you want, not how to check it.

## AI as Co-pilot
AI suggests, human approves.
YAML is the contract between them.
```

---

#### 2.2 Types vs Tests (`concepts/types-vs-tests.md`)

**Content:**
- Side-by-side comparison with dbt tests
- Side-by-side with Great Expectations
- When to use each approach
- Migration path from existing tools

**Structure:**
```markdown
# Types vs Tests: A Comparison

## The Traditional Approach
[dbt schema.yml example - verbose, repetitive]

## The GoQuality Approach
[Equivalent goquality.yaml - concise, reusable]

## Line Count Comparison
| Scenario | dbt tests | GoQuality |
|----------|-----------|-----------|
| 10 tables, 5 columns each | 250 lines | 50 lines |
| Add new table | +25 lines | +5 lines |
| Change email regex | 10 file edits | 1 line |

## When to Use What
- GoQuality: Schema-level, reusable validations
- dbt tests: Business logic, row-level calculations
- Great Expectations: Complex statistical checks

## Migration Guide
[Link to migration docs]
```

---

#### 2.3 AI Generation (`concepts/ai-generation.md`)

**Content:**
- How the LLM inference works
- What data is sent to the LLM
- Privacy considerations
- Prompt engineering under the hood
- Supported providers

**Structure:**
```markdown
# AI-Powered Type Generation

## How It Works
1. GoQuality profiles your database schema
2. Extracts: column names, SQL types, sample values, statistics
3. Sends profile to LLM with type library context
4. LLM returns type mappings
5. You review and approve

## What Data Is Sent?
[Exact payload example]

- Column names ✓
- Data types ✓
- Sample values (first 5) ✓
- Statistics (null %, cardinality) ✓
- Actual data rows ✗ (never sent)

## Privacy & Security
- No raw data leaves your system
- Use Ollama for fully local inference
- Anthropic/OpenAI: data not used for training

## Under the Hood
[Show actual prompt structure]

## Choosing a Provider
| Provider | Pros | Cons |
|----------|------|------|
| OpenAI | Best accuracy | Cloud-based |
| Anthropic | Great reasoning | Cloud-based |
| Ollama | Fully local | Requires GPU |

## Improving Results
- Better column names = better inference
- Add descriptions to your schema
- Review and correct first run, AI learns patterns
```

---

#### 2.4 YAML as Interface (`concepts/yaml-as-interface.md`)

**Content:**
- Why YAML (not Python, not SQL, not JSON)
- YAML as contract between AI and humans
- Version control benefits
- Diffability and code review
- Schema validation

**Structure:**
```markdown
# YAML: The Language of AI-Native Data Governance

## Why YAML?

### For Humans
- Readable without training
- Editable in any text editor
- Familiar to data engineers (dbt, Kubernetes, etc.)

### For AI
- Structured enough to generate
- Flexible enough to express complex rules
- Standard format with good tooling

### For Teams
- Git-friendly (meaningful diffs)
- Code review workflows
- Audit trail built-in

## The Contract
[Diagram: AI generates → YAML → Human reviews → YAML → Machine executes]

## Schema Validation
goquality validate

## IDE Support
- VS Code extension (coming soon)
- JSON Schema for autocomplete
```

---

### 3. Guides

**Goal:** Task-oriented walkthroughs for common workflows.

#### 3.1 Defining Types (`guides/defining-types.md`)

**Content:**
- Creating custom types from scratch
- Extending stdlib types
- Type inheritance patterns
- Composition strategies
- Best practices

**Structure:**
```markdown
# Defining Custom Types

## When to Create Custom Types
- Domain-specific formats (employee ID, internal codes)
- Stricter versions of stdlib types
- Company-wide standards

## Basic Type Definition
types:
  - name: EmployeeId
    base: String
    pattern: "^EMP-[0-9]{6}$"

## Extending Existing Types
types:
  - name: CorporateEmail
    extends: Email
    pattern: "^.*@acme\\.com$"

## Type Inheritance Chain
[Diagram: String → Email → CorporateEmail]

## Composition Patterns

### Pattern 1: Strictness Layers
Email → VerifiedEmail → CorporateEmail

### Pattern 2: Domain Grouping
types/finance.yaml → USD, EUR, CreditCard
types/users.yaml → Email, Phone, Address

### Pattern 3: Environment Variants
ProductionEmail (strict) vs TestEmail (relaxed)

## Best Practices
1. Start with stdlib, customize only when needed
2. Use extends, don't copy-paste
3. Group related types in separate files
4. Add descriptions and examples
5. Use tags for discoverability
```

---

#### 3.2 Mapping Models (`guides/mapping-models.md`)

**Content:**
- Mapping tables to types
- Column-level overrides
- Handling nullable columns
- Schema prefixes
- Wildcards and patterns

**Structure:**
```markdown
# Mapping Database Models

## Basic Mapping
models:
  - table: users
    columns:
      - name: email
        type: Email

## Schema Qualification
models:
  - table: public.users
  - table: analytics.events

## Column Overrides
columns:
  - name: discount
    type: Percentage
    allow_null: true  # Override type default

## Unmapped Columns
By default, unmapped columns are ignored.
Use --strict to require all columns.

## Pattern Matching (Coming Soon)
models:
  - table: "*_audit"
    columns:
      - name: created_at
        type: Timestamp
```

---

#### 3.3 Running Checks (`guides/running-checks.md`)

**Content:**
- Basic check command
- Filtering by table
- Output formats
- Interpreting results
- Handling failures

**Structure:**
```markdown
# Running Validation Checks

## Basic Usage
goquality check --source postgres://...

## Check Specific Table
goquality check --source ... --table users

## Output Formats

### Table (Default)
Human-readable, colored output

### JSON
goquality check --output json
For programmatic processing

### Markdown
goquality check --output markdown > report.md
For documentation/PRs

### CSV
goquality check --output csv > results.csv
For spreadsheet analysis

## Understanding Results
[Annotated output example]

## Failure Thresholds
goquality check --fail-threshold 5
Allow up to 5% failures

## Exit Codes
- 0: All checks passed
- 1: Failures detected
- 2: Configuration error

## Quiet Mode
goquality check --quiet
Only show summary and errors
```

---

#### 3.4 CI/CD Integration (`guides/ci-cd-integration.md`)

**Content:**
- GitHub Actions complete setup
- GitLab CI complete setup
- Generic CI patterns
- Secrets management
- Scheduled runs
- PR comments

**Structure:**
```markdown
# CI/CD Integration

## Design Principles
1. Fail fast on configuration errors
2. Allow threshold for data issues
3. Generate artifacts for debugging
4. Notify on regressions

## GitHub Actions

### Basic Workflow
[Complete YAML]

### With PR Comments
[Using actions/github-script]

### Scheduled Daily Runs
[Cron example]

## GitLab CI
[Complete YAML]

## Generic CI
[Shell script approach]

## Secrets Management
- Never commit connection strings
- Use CI secrets/variables
- Rotate credentials regularly

## Artifacts
- Save JSON output
- Generate trend reports
- Archive for compliance
```

---

#### 3.5 dbt Integration (`guides/dbt-integration.md`)

**Content:**
- Using alongside dbt
- Generating from dbt schema
- Complementary testing strategy
- Shared type definitions

**Structure:**
```markdown
# dbt Integration

## GoQuality + dbt: Better Together

dbt excels at:
- Transformation logic tests
- Row-level business rules
- Freshness checks

GoQuality excels at:
- Schema-level type validation
- Reusable type definitions
- AI-powered setup

## Workflow

### Option 1: Parallel
Run both independently:
dbt test && goquality check

### Option 2: GoQuality First
Validate raw data before dbt runs

### Option 3: dbt Generates, GoQuality Validates
Use dbt schema.yml as input

## Generating from dbt Schema
goquality generate --from-dbt models/schema.yml

## Sharing Definitions
[Pattern for shared types file]
```

---

#### 3.6 Team Workflows (`guides/team-workflows.md`)

**Content:**
- Multi-developer setup
- Code review for type changes
- Branching strategies
- Handling conflicts
- Documentation standards

**Structure:**
```markdown
# Team Workflows

## Repository Structure
project/
├── goquality/
│   ├── types/
│   │   ├── core.yaml
│   │   ├── finance.yaml
│   │   └── users.yaml
│   ├── models/
│   │   ├── warehouse.yaml
│   │   └── application.yaml
│   └── goquality.yaml (imports above)

## Code Review Checklist
- [ ] Type name follows conventions
- [ ] Description is clear
- [ ] Pattern tested with examples
- [ ] No duplicate types
- [ ] Breaking changes documented

## Branching Strategy
- main: Production types
- feature/*: New types/changes
- PR required for main

## Handling Conflicts
[Git merge strategies for YAML]

## Documentation Standards
Every custom type needs:
- Description
- At least 2 examples
- Tags for discoverability
```

---

### 4. Type Library Reference

**Goal:** Comprehensive reference for all built-in types.

#### 4.1 Overview (`type-library/overview.md`)

**Content:**
- How to browse types
- Type categories
- Inheritance hierarchy
- Contributing new types

**Structure:**
```markdown
# Type Library Overview

## Browsing Types

### CLI
goquality types
goquality types --search email
goquality types --tag finance
goquality types --show Email

### Online
https://goquality.dev/types

## Categories
- Core: Basic string/number validations
- Finance: Currency, banking, payments
- Healthcare: Medical codes, identifiers
- E-commerce: Products, orders
- Regional: Country-specific formats
- Analytics: Metrics, KPIs
- IoT: Sensors, devices
- SaaS: API keys, tokens

## Inheritance Tree
[Visual hierarchy diagram]

## Contributing
[Link to contribution guide]
```

---

#### 4.2-4.7 Category Pages

Each category gets its own page with:

```markdown
# Finance Types

## Overview
Types for financial data validation.

## Types

### USD
**Base:** Decimal
**Description:** US Dollar amount
**Constraints:**
- Precision: 2 decimal places
- Min: 0 (configurable)

**Example:**
columns:
  - name: total
    type: USD

**Valid values:** 99.99, 0.00, 1234567.89
**Invalid values:** -5.00, 99.999, "free"

---

### CreditCardNumber
**Base:** String
**Description:** Credit card number (Luhn validated)
**Constraints:**
- Pattern: 13-19 digits
- Luhn checksum

[... etc for each type ...]
```

---

### 5. Database Guides

**Goal:** Database-specific setup and optimization.

#### Structure (same for each DB):

```markdown
# PostgreSQL Guide

## Installation
pip install goquality[postgres]

## Connection String
postgres://user:pass@host:port/database

## Connection Options
- SSL mode
- Connection pooling
- Timeout settings

## Schema Discovery
goquality generate --source ... --schema public

## Performance Tips
- Use read replicas
- Limit sample size
- Index considerations

## Troubleshooting
- Connection refused
- Authentication failed
- SSL errors

## Example
[Complete working example]
```

---

### 6. CLI Reference

**Goal:** Complete reference for every command and option.

#### Structure (same for each command):

```markdown
# goquality check

## Synopsis
goquality check [OPTIONS]

## Description
Run validation checks against a database.

## Options

### --config, -c
**Type:** Path
**Default:** goquality.yaml
**Description:** Path to configuration file.

### --source, -s
**Type:** String
**Required:** Yes (unless in config)
**Description:** Database connection string.

[... all options ...]

## Examples

### Basic check
goquality check --source postgres://...

### JSON output for CI
goquality check --source ... --output json

[... more examples ...]

## Exit Codes
| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Validation failures |
| 2 | Configuration error |

## See Also
- [goquality validate](validate.md)
- [goquality doctor](doctor.md)
```

---

### 7. Configuration Reference

**Goal:** Complete reference for all configuration options.

#### 7.1 goquality.yaml (`configuration/goquality-yaml.md`)

```markdown
# goquality.yaml Reference

## File Location
GoQuality looks for configuration in:
1. --config flag
2. ./goquality.yaml
3. ./goquality.yml
4. ./.goquality/config.yaml

## Schema

### Top-level
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| types | array | No | Custom type definitions |
| models | array | Yes | Table-column mappings |
| checks | array | No | Ad-hoc SQL checks |
| imports | array | No | Other YAML files to include |

### Type Definition
[Full field reference table]

### Model Definition
[Full field reference table]

### Check Definition
[Full field reference table]

## JSON Schema
Available at: https://goquality.dev/schema.json

## VS Code Setup
settings.json:
{
  "yaml.schemas": {
    "https://goquality.dev/schema.json": "goquality.yaml"
  }
}
```

---

### 8. Advanced Topics

#### 8.1 Custom Validators (`advanced/custom-validators.md`)

```markdown
# Custom Validators

## When to Use
- Domain-specific logic not covered by patterns
- Complex checksums
- External API validation
- Cross-column rules

## Python Validators

### Simple Function
@register_validator("is_palindrome")
def is_palindrome(value: str) -> bool:
    return value == value[::-1]

### With Parameters
@register_validator("divisible_by")
def divisible_by(value: int, divisor: int) -> bool:
    return value % divisor == 0

## SQL Validators
validators:
  - name: recent_order
    sql: "{column} > CURRENT_DATE - INTERVAL '30 days'"

## Using Custom Validators
types:
  - name: RecentTimestamp
    base: Timestamp
    validators:
      - recent_order

## Testing Validators
[pytest examples]
```

---

#### 8.2 Plugin System (`advanced/plugin-system.md`)

```markdown
# Plugin System

## Architecture
[Diagram of plugin lifecycle]

## Creating a Plugin

### Directory Structure
.goquality/plugins/
├── __init__.py
├── my_validators.py
└── my_types.yaml

### Plugin Metadata
@plugin(
    name="acme-validators",
    version="1.0.0",
    author="ACME Corp"
)
class AcmeValidators(ValidatorPlugin):
    ...

## Loading Plugins
goquality check --plugins .goquality/plugins/

## Publishing Plugins
[PyPI distribution guide]
```

---

### 9. Integrations

Each integration gets a dedicated page:

```markdown
# GitHub Actions Integration

## Overview
Automate data quality checks on every push.

## Basic Setup
[Complete workflow YAML]

## Advanced: PR Comments
[Workflow with commenting]

## Advanced: Scheduled Runs
[Cron-based workflow]

## Advanced: Matrix Testing
[Multiple databases]

## Secrets Required
| Secret | Description |
|--------|-------------|
| DATABASE_URL | Connection string |
| OPENAI_API_KEY | For AI generation |

## Troubleshooting
[Common issues]
```

---

### 10. Troubleshooting

#### 10.1 Common Errors (`troubleshooting/common-errors.md`)

```markdown
# Common Errors

## Configuration Errors

### "Config file not found"
**Cause:** No goquality.yaml in current directory
**Solution:** Run `goquality init` or specify `--config`

### "Unknown type: X"
**Cause:** Type not in stdlib or custom types
**Solution:** Check spelling, define custom type, or use `goquality types --search`

[... 20+ common errors with solutions ...]

## Connection Errors
[Database-specific errors]

## Runtime Errors
[Validation execution errors]
```

---

### 11. Resources

#### 11.1 Comparison (`resources/comparison.md`)

```markdown
# GoQuality vs Alternatives

## Comparison Matrix

| Feature | GoQuality | dbt tests | Great Expectations | Soda |
|---------|-----------|-----------|-------------------|------|
| AI generation | ✓ | ✗ | ✗ | ✗ |
| Type system | ✓ | ✗ | ✗ | ✗ |
| YAML config | ✓ | ✓ | ✗ | ✓ |
| Multi-DB | ✓ | ✓ | ✓ | ✓ |
| Reusable rules | ✓ | Limited | ✓ | Limited |
| Setup time | 5 min | 30 min | 1 hour | 30 min |
| Learning curve | Low | Medium | High | Medium |

## Detailed Comparisons
- [GoQuality vs dbt tests](comparison-dbt.md)
- [GoQuality vs Great Expectations](comparison-gx.md)
- [GoQuality vs Soda](comparison-soda.md)

## Migration Guides
- [From dbt tests](migration-dbt.md)
- [From Great Expectations](migration-gx.md)
```

---

## Implementation Plan

### Phase 1: Core Documentation (Week 1)
- [ ] Getting Started (all 4 pages)
- [ ] CLI Reference (all commands)
- [ ] Configuration Reference

### Phase 2: Concepts & Guides (Week 2)
- [ ] Concepts (all 4 pages)
- [ ] Guides (6 pages)

### Phase 3: Reference (Week 3)
- [ ] Type Library (7 pages)
- [ ] Database Guides (4 pages)

### Phase 4: Advanced & Polish (Week 4)
- [ ] Advanced Topics (4 pages)
- [ ] Integrations (5 pages)
- [ ] Troubleshooting
- [ ] Resources
- [ ] Search implementation
- [ ] Version selector

---

## Technical Implementation

### Documentation Framework
**Recommended:** [MkDocs Material](https://squidfunk.github.io/mkdocs-material/)

**Why:**
- Beautiful out of the box
- Excellent search
- Version support
- Dark mode
- Mermaid diagrams
- Code syntax highlighting
- Admonitions (tips, warnings)
- Copy button on code blocks

### Hosting
**Option 1:** GitHub Pages (free)
**Option 2:** Netlify (free tier)
**Option 3:** ReadTheDocs (free for open source)

### Configuration

```yaml
# mkdocs.yml
site_name: GoQuality Documentation
site_url: https://goquality.dev/docs
repo_url: https://github.com/goquality/goquality

theme:
  name: material
  palette:
    - scheme: default
      primary: indigo
      accent: amber
      toggle:
        icon: material/brightness-7
        name: Switch to dark mode
    - scheme: slate
      primary: indigo
      accent: amber
      toggle:
        icon: material/brightness-4
        name: Switch to light mode
  features:
    - navigation.instant
    - navigation.tabs
    - navigation.sections
    - navigation.expand
    - search.suggest
    - search.highlight
    - content.code.copy
    - content.tabs.link

plugins:
  - search
  - git-revision-date-localized

markdown_extensions:
  - admonition
  - pymdownx.highlight
  - pymdownx.superfences:
      custom_fences:
        - name: mermaid
          class: mermaid
          format: !!python/name:pymdownx.superfences.fence_code_format
  - pymdownx.tabbed:
      alternate_style: true
  - pymdownx.tasklist:
      custom_checkbox: true

nav:
  - Home: index.md
  - Getting Started:
    - Introduction: getting-started/introduction.md
    - Installation: getting-started/installation.md
    - Quickstart: getting-started/quickstart.md
    - First Validation: getting-started/first-validation.md
  - Concepts:
    - Philosophy: concepts/philosophy.md
    - Types vs Tests: concepts/types-vs-tests.md
    - AI Generation: concepts/ai-generation.md
    - YAML as Interface: concepts/yaml-as-interface.md
  # ... rest of nav
```

---

## Content Guidelines

### Writing Style
- Use second person ("you")
- Present tense
- Active voice
- Short sentences
- One idea per paragraph

### Code Examples
- Every example must be runnable
- Include expected output
- Use realistic data (not "foo", "bar")
- Add comments for complex sections

### Formatting
- Use admonitions for tips, warnings, notes
- Tables for comparisons and options
- Diagrams for architecture
- Screenshots for UI elements

### Accessibility
- Alt text for all images
- Sufficient color contrast
- Keyboard navigation
- Screen reader compatible

---

## Metrics & Success Criteria

### Documentation Metrics
- Time to first validation: < 5 minutes
- Search success rate: > 80%
- Page bounce rate: < 40%
- Feedback rating: > 4/5

### Content Metrics
- Every CLI command documented
- Every config option documented
- Every stdlib type documented
- Every error has troubleshooting

### Maintenance
- Weekly review of feedback
- Monthly content audit
- Version sync with releases
- Quarterly user testing
