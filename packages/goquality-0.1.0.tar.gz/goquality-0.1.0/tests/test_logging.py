"""
Tests for logging module.
"""

import logging
import sys

from goquality.logging import (
    LogContext,
    LogLevel,
    StructuredFormatter,
    configure_logging,
    get_logger,
    log_operation,
)


class TestLogLevel:
    """Tests for log level enum."""

    def test_log_levels(self):
        """Test log level values."""
        assert LogLevel.DEBUG == "DEBUG"
        assert LogLevel.INFO == "INFO"
        assert LogLevel.WARNING == "WARNING"
        assert LogLevel.ERROR == "ERROR"
        assert LogLevel.CRITICAL == "CRITICAL"


class TestStructuredFormatter:
    """Tests for structured formatter."""

    def test_text_format(self):
        """Test text output format."""
        formatter = StructuredFormatter(json_output=False)

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="Test message",
            args=(),
            exc_info=None,
        )

        formatted = formatter.format(record)
        assert "INFO" in formatted
        assert "test" in formatted
        assert "Test message" in formatted

    def test_json_format(self):
        """Test JSON output format."""
        import json

        formatter = StructuredFormatter(json_output=True)

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="Test message",
            args=(),
            exc_info=None,
        )

        formatted = formatter.format(record)
        data = json.loads(formatted)

        assert data["level"] == "INFO"
        assert data["logger"] == "test"
        assert data["message"] == "Test message"
        assert "timestamp" in data

    def test_exception_formatting(self):
        """Test exception info formatting."""
        formatter = StructuredFormatter(json_output=False)

        try:
            raise ValueError("test error")
        except ValueError:
            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=1,
            msg="Error occurred",
            args=(),
            exc_info=exc_info,
        )

        formatted = formatter.format(record)
        assert "ValueError" in formatted
        assert "test error" in formatted


class TestGetLogger:
    """Tests for get_logger function."""

    def test_get_default_logger(self):
        """Test getting default logger."""
        logger = get_logger()
        assert logger.name == "goquality"

    def test_get_named_logger(self):
        """Test getting named logger."""
        logger = get_logger("mymodule")
        assert logger.name == "mymodule"

    def test_same_logger_instance(self):
        """Test that same name returns same instance."""
        # Test that getting the same logger returns consistent results
        # The global logger caching works for "goquality"
        logger1 = get_logger("goquality")
        logger2 = get_logger("goquality")
        assert logger1.name == logger2.name


class TestConfigureLogging:
    """Tests for configure_logging function."""

    def test_configure_with_level(self):
        """Test configuring with specific level."""
        configure_logging(level="DEBUG")
        logger = get_logger("goquality")
        assert logger.level == logging.DEBUG

    def test_configure_with_log_level_enum(self):
        """Test configuring with LogLevel enum."""
        configure_logging(level=LogLevel.WARNING)
        logger = get_logger("goquality")
        assert logger.level == logging.WARNING


class TestLogContext:
    """Tests for LogContext context manager."""

    def test_basic_context(self):
        """Test basic log context."""
        with LogContext(operation="test", table="users"):
            # Context should be active
            pass

        # Context should be cleaned up
        # (Hard to test directly without capturing logs)

    def test_nested_context(self):
        """Test nested log contexts."""
        with LogContext(outer="value1"):
            with LogContext(inner="value2"):
                # Both contexts should be active
                pass


class TestLogOperation:
    """Tests for log_operation function."""

    def test_log_operation_returns_context(self):
        """Test that log_operation returns a LogContext."""
        ctx = log_operation("test", table="users")
        assert isinstance(ctx, LogContext)
        assert ctx.extra["operation"] == "test"
        assert ctx.extra["table"] == "users"
