"""
Tests for security module.
"""

import pytest

from goquality.security import (
    build_safe_query,
    escape_sql_string,
    is_safe_sql_identifier,
    mask_connection_string,
    mask_credentials,
    mask_dict,
    quote_sql_identifier,
    sanitize_sql_identifier,
)


class TestMaskCredentials:
    """Tests for credential masking."""

    def test_mask_postgres_connection_string(self):
        """Test masking PostgreSQL connection strings."""
        conn = "postgres://user:secret123@localhost:5432/mydb"
        masked = mask_credentials(conn)
        assert "secret123" not in masked
        assert "****" in masked
        assert "user" in masked
        assert "localhost" in masked

    def test_mask_postgresql_connection_string(self):
        """Test masking PostgreSQL connection strings with full scheme."""
        conn = "postgresql://admin:p@ssw0rd!@db.example.com:5432/prod"
        masked = mask_credentials(conn)
        assert "p@ssw0rd!" not in masked

    def test_mask_snowflake_connection_string(self):
        """Test masking Snowflake connection strings."""
        conn = "snowflake://myuser:MySecret@myaccount/mydb/myschema"
        masked = mask_credentials(conn)
        assert "MySecret" not in masked

    def test_mask_api_key(self):
        """Test masking API keys."""
        text = "api_key=sk-1234567890abcdef"
        masked = mask_credentials(text)
        assert "sk-1234567890abcdef" not in masked

    def test_mask_bearer_token(self):
        """Test masking Bearer tokens."""
        text = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        masked = mask_credentials(text)
        assert "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" not in masked

    def test_mask_password_field(self):
        """Test masking password fields."""
        text = "password=mysecretpassword"
        masked = mask_credentials(text)
        assert "mysecretpassword" not in masked

    def test_no_credentials(self):
        """Test text without credentials is unchanged (except for pattern matches)."""
        text = "SELECT * FROM users WHERE id = 1"
        masked = mask_credentials(text)
        assert masked == text


class TestMaskConnectionString:
    """Tests for connection string masking."""

    def test_mask_postgres_password(self):
        """Test masking password in PostgreSQL URL."""
        conn = "postgres://user:secret@localhost:5432/db"
        masked = mask_connection_string(conn)
        assert masked == "postgres://user:****@localhost:5432/db"

    def test_mask_postgres_no_port(self):
        """Test masking without port."""
        conn = "postgres://user:secret@localhost/db"
        masked = mask_connection_string(conn)
        assert masked == "postgres://user:****@localhost/db"

    def test_no_password(self):
        """Test connection string without password."""
        conn = "postgres://localhost:5432/db"
        masked = mask_connection_string(conn)
        assert masked == conn


class TestMaskDict:
    """Tests for dictionary masking."""

    def test_mask_password_key(self):
        """Test masking password key."""
        data = {"user": "admin", "password": "secret123"}
        masked = mask_dict(data)
        assert masked["user"] == "admin"
        assert masked["password"] == "****"

    def test_mask_nested_dict(self):
        """Test masking nested dictionaries."""
        data = {"database": {"host": "localhost", "password": "secret"}}
        masked = mask_dict(data)
        assert masked["database"]["host"] == "localhost"
        assert masked["database"]["password"] == "****"

    def test_mask_api_key(self):
        """Test masking api_key."""
        data = {"api_key": "sk-1234567890"}
        masked = mask_dict(data)
        assert masked["api_key"] == "****"

    def test_custom_sensitive_keys(self):
        """Test custom sensitive keys."""
        data = {"custom_field": "sensitive"}
        masked = mask_dict(data, sensitive_keys={"custom_field"})
        assert masked["custom_field"] == "****"


class TestSQLIdentifiers:
    """Tests for SQL identifier handling."""

    def test_safe_identifier(self):
        """Test valid SQL identifiers."""
        assert is_safe_sql_identifier("users") is True
        assert is_safe_sql_identifier("user_id") is True
        assert is_safe_sql_identifier("_private") is True
        assert is_safe_sql_identifier("Table1") is True

    def test_unsafe_identifier(self):
        """Test invalid SQL identifiers."""
        assert is_safe_sql_identifier("") is False
        assert is_safe_sql_identifier("123table") is False
        assert is_safe_sql_identifier("user-id") is False
        assert is_safe_sql_identifier("table.name") is False
        assert is_safe_sql_identifier("user; DROP TABLE") is False

    def test_sanitize_identifier(self):
        """Test sanitizing identifiers."""
        assert sanitize_sql_identifier("users") == "users"
        assert sanitize_sql_identifier("user-id") == "userid"
        assert sanitize_sql_identifier("123table") == "_123table"

    def test_sanitize_empty_raises(self):
        """Test sanitizing empty string raises."""
        with pytest.raises(ValueError):
            sanitize_sql_identifier("---")

    def test_quote_postgres(self):
        """Test quoting for PostgreSQL."""
        assert quote_sql_identifier("users", "postgres") == '"users"'
        assert quote_sql_identifier("MyTable", "snowflake") == '"MyTable"'

    def test_quote_mysql(self):
        """Test quoting for MySQL/BigQuery."""
        assert quote_sql_identifier("users", "mysql") == "`users`"
        assert quote_sql_identifier("MyTable", "bigquery") == "`MyTable`"

    def test_quote_with_quotes_raises(self):
        """Test that identifiers with quotes raise."""
        with pytest.raises(ValueError):
            quote_sql_identifier('user"name', "postgres")


class TestEscapeSQL:
    """Tests for SQL string escaping."""

    def test_escape_single_quote(self):
        """Test escaping single quotes."""
        assert escape_sql_string("O'Brien") == "O''Brien"

    def test_escape_backslash(self):
        """Test escaping backslashes."""
        assert escape_sql_string("path\\to\\file") == "path\\\\to\\\\file"

    def test_no_escaping_needed(self):
        """Test string without special characters."""
        assert escape_sql_string("normal text") == "normal text"


class TestBuildSafeQuery:
    """Tests for safe query building."""

    def test_build_with_identifiers(self):
        """Test building query with identifiers."""
        query = build_safe_query(
            "SELECT * FROM {schema}.{table}",
            identifiers={"schema": "public", "table": "users"},
            dialect="postgres",
        )
        assert '"public"' in query
        assert '"users"' in query

    def test_build_with_values(self):
        """Test building query with values."""
        query = build_safe_query(
            "SELECT * FROM users WHERE name = %(name)s",
            values={"name": "O'Brien"},
            dialect="postgres",
        )
        assert "O''Brien" in query  # Escaped

    def test_build_with_null(self):
        """Test building query with NULL value."""
        query = build_safe_query(
            "SELECT * FROM users WHERE deleted_at = %(deleted_at)s",
            values={"deleted_at": None},
            dialect="postgres",
        )
        assert "NULL" in query
