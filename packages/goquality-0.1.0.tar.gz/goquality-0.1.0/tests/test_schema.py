"""
Comprehensive tests for schema models and type registry.
"""

import pytest

from goquality.schema.models import (
    BaseType,
    CheckRule,
    ColumnMapping,
    GoQualityConfig,
    ModelMapping,
    TypeDefinition,
)
from goquality.schema.registry import ResolvedType


class TestBaseType:
    """Tests for BaseType enum."""

    def test_all_base_types_exist(self):
        """Verify all expected base types exist."""
        expected = {"String", "Integer", "Decimal", "Boolean", "Date", "Timestamp"}
        actual = {bt.value for bt in BaseType}
        assert actual == expected

    def test_base_type_values(self):
        """Test base type value access."""
        assert BaseType.STRING.value == "String"
        assert BaseType.INTEGER.value == "Integer"
        assert BaseType.DECIMAL.value == "Decimal"


class TestTypeDefinition:
    """Tests for TypeDefinition model."""

    def test_valid_string_type(self):
        """Test creating a valid string type."""
        t = TypeDefinition(
            name="Email",
            description="Email address",
            base=BaseType.STRING,
            pattern=r"^[a-z]+@[a-z]+\.[a-z]+$",
            max_length=255,
        )
        assert t.name == "Email"
        assert t.base == BaseType.STRING
        assert t.allow_null is False
        assert t.pattern is not None

    def test_valid_numeric_type(self):
        """Test creating a valid numeric type."""
        t = TypeDefinition(
            name="Percentage",
            description="Percentage 0-100",
            base=BaseType.DECIMAL,
            min=0,
            max=100,
            precision=2,
        )
        assert t.min == 0
        assert t.max == 100
        assert t.precision == 2

    def test_valid_integer_type(self):
        """Test creating a valid integer type."""
        t = TypeDefinition(
            name="PositiveInt",
            description="Positive integer",
            base=BaseType.INTEGER,
            min=1,
        )
        assert t.base == BaseType.INTEGER
        assert t.min == 1

    def test_enum_type(self):
        """Test creating an enum type."""
        t = TypeDefinition(
            name="Status",
            description="Status enum",
            base=BaseType.STRING,
            enum=["active", "inactive", "pending"],
        )
        assert t.enum == ["active", "inactive", "pending"]

    def test_nullable_type(self):
        """Test nullable type."""
        t = TypeDefinition(
            name="OptionalEmail",
            description="Optional email",
            base=BaseType.STRING,
            allow_null=True,
        )
        assert t.allow_null is True

    def test_type_with_inheritance(self):
        """Test type with extends field."""
        t = TypeDefinition(
            name="CorporateEmail",
            description="Corporate email",
            base=BaseType.STRING,
            extends="Email",
            pattern=r"^.+@corp\.com$",
        )
        assert t.extends == "Email"

    def test_type_with_tags(self):
        """Test type with tags."""
        t = TypeDefinition(
            name="SSN",
            description="Social Security Number",
            base=BaseType.STRING,
            pattern=r"^\d{3}-\d{2}-\d{4}$",
            tags=["pii", "sensitive"],
        )
        assert "pii" in t.tags
        assert "sensitive" in t.tags

    def test_type_with_examples(self):
        """Test type with examples."""
        t = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            examples=["test@example.com", "user@domain.org"],
        )
        assert len(t.examples) == 2

    def test_deprecated_type(self):
        """Test deprecated type."""
        t = TypeDefinition(
            name="OldType",
            description="Deprecated type",
            base=BaseType.STRING,
            deprecated=True,
        )
        assert t.deprecated is True

    def test_invalid_name_lowercase(self):
        """Test that lowercase names are rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="email",  # Should be PascalCase
                description="Email",
                base=BaseType.STRING,
            )

    def test_invalid_name_with_spaces(self):
        """Test that names with spaces are rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="Email Type",
                description="Email",
                base=BaseType.STRING,
            )

    def test_invalid_pattern(self):
        """Test that invalid regex is rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadPattern",
                description="Bad pattern",
                base=BaseType.STRING,
                pattern="[invalid",  # Unclosed bracket
            )

    def test_string_with_numeric_constraints(self):
        """Test that numeric constraints on strings are rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadType",
                description="Bad type",
                base=BaseType.STRING,
                min=0,  # Invalid for String
            )

    def test_numeric_with_string_constraints(self):
        """Test that string constraints on numerics are rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadType",
                description="Bad type",
                base=BaseType.INTEGER,
                pattern="^\\d+$",  # Invalid for Integer
            )

    def test_integer_with_precision(self):
        """Test that precision on integers is rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadType",
                description="Bad type",
                base=BaseType.INTEGER,
                precision=2,  # Invalid for Integer
            )

    def test_empty_description_rejected(self):
        """Test that empty description is rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadType",
                description="",
                base=BaseType.STRING,
            )

    def test_negative_min_length_rejected(self):
        """Test that negative min_length is rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadType",
                description="Bad type",
                base=BaseType.STRING,
                min_length=-1,
            )

    def test_zero_max_length_rejected(self):
        """Test that zero max_length is rejected."""
        with pytest.raises(ValueError):
            TypeDefinition(
                name="BadType",
                description="Bad type",
                base=BaseType.STRING,
                max_length=0,
            )


class TestTypeRegistry:
    """Tests for TypeRegistry."""

    def test_register_and_resolve_simple(self, empty_registry):
        """Test registering and resolving a simple type."""
        email_type = TypeDefinition(
            name="Email",
            description="Email address",
            base=BaseType.STRING,
            pattern=r"^.+@.+$",
        )
        empty_registry.register(email_type)

        resolved = empty_registry.resolve("Email")
        assert resolved.name == "Email"
        assert resolved.pattern == r"^.+@.+$"

    def test_has_type(self, empty_registry):
        """Test has_type method."""
        email_type = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
        )
        empty_registry.register(email_type)

        assert empty_registry.has_type("Email") is True
        assert empty_registry.has_type("Unknown") is False

    def test_get_type(self, empty_registry):
        """Test get_type method."""
        email_type = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
        )
        empty_registry.register(email_type)

        assert empty_registry.get_type("Email") == email_type
        assert empty_registry.get_type("Unknown") is None

    def test_list_types(self, empty_registry):
        """Test list_types method."""
        empty_registry.register(TypeDefinition(
            name="Email", description="Email", base=BaseType.STRING
        ))
        empty_registry.register(TypeDefinition(
            name="URL", description="URL", base=BaseType.STRING
        ))

        types = empty_registry.list_types()
        assert "Email" in types
        assert "URL" in types
        assert types == sorted(types)  # Should be sorted

    def test_inheritance_single_level(self, empty_registry):
        """Test single-level type inheritance."""
        # Parent type
        email = TypeDefinition(
            name="Email",
            description="Email address",
            base=BaseType.STRING,
            pattern=r"^.+@.+$",
            max_length=255,
        )
        empty_registry.register(email)

        # Child type
        corp_email = TypeDefinition(
            name="CorporateEmail",
            description="Corporate email",
            base=BaseType.STRING,
            extends="Email",
            pattern=r"^.+@acme\.com$",  # Override pattern
        )
        empty_registry.register(corp_email)

        resolved = empty_registry.resolve("CorporateEmail")
        assert resolved.name == "CorporateEmail"
        assert resolved.pattern == r"^.+@acme\.com$"  # Child's pattern
        assert resolved.max_length == 255  # Inherited from parent

    def test_inheritance_multi_level(self, empty_registry):
        """Test multi-level type inheritance."""
        # Grandparent
        string_type = TypeDefinition(
            name="ValidString",
            description="Non-empty string",
            base=BaseType.STRING,
            min_length=1,
        )
        empty_registry.register(string_type)

        # Parent
        email = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            extends="ValidString",
            pattern=r"^.+@.+$",
        )
        empty_registry.register(email)

        # Child
        corp_email = TypeDefinition(
            name="CorporateEmail",
            description="Corporate email",
            base=BaseType.STRING,
            extends="Email",
            max_length=100,
        )
        empty_registry.register(corp_email)

        resolved = empty_registry.resolve("CorporateEmail")
        assert resolved.min_length == 1  # From grandparent
        assert resolved.pattern == r"^.+@.+$"  # From parent
        assert resolved.max_length == 100  # From child
        assert resolved.extends_chain == ["CorporateEmail", "Email", "ValidString"]

    def test_inheritance_override_nullability(self, empty_registry):
        """Test that child can override nullability."""
        parent = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            allow_null=False,
        )
        child = TypeDefinition(
            name="OptionalEmail",
            description="Optional email",
            base=BaseType.STRING,
            extends="Email",
            allow_null=True,
        )

        empty_registry.register(parent)
        empty_registry.register(child)

        resolved = empty_registry.resolve("OptionalEmail")
        assert resolved.allow_null is True

    def test_circular_inheritance_detected(self, empty_registry):
        """Test that circular inheritance is detected."""
        a = TypeDefinition(
            name="TypeA",
            description="A",
            base=BaseType.STRING,
            extends="TypeB",
        )
        b = TypeDefinition(
            name="TypeB",
            description="B",
            base=BaseType.STRING,
            extends="TypeA",
        )

        empty_registry.register(a)
        empty_registry.register(b)

        with pytest.raises(ValueError, match="Circular"):
            empty_registry.resolve("TypeA")

    def test_unknown_parent_type(self, empty_registry):
        """Test error when parent type doesn't exist."""
        child = TypeDefinition(
            name="Child",
            description="Child",
            base=BaseType.STRING,
            extends="NonExistent",
        )
        empty_registry.register(child)

        with pytest.raises(KeyError, match="NonExistent"):
            empty_registry.resolve("Child")

    def test_unknown_type_resolution(self, empty_registry):
        """Test error when resolving unknown type."""
        with pytest.raises(KeyError, match="Unknown"):
            empty_registry.resolve("Unknown")

    def test_validate_references(self, empty_registry):
        """Test validating type references."""
        empty_registry.register(TypeDefinition(
            name="Email", description="Email", base=BaseType.STRING
        ))

        missing = empty_registry.validate_references({"Email", "Unknown", "Also Unknown"})
        assert "Unknown" in missing
        assert "Also Unknown" in missing
        assert "Email" not in missing

    def test_search_types(self, empty_registry):
        """Test type search functionality."""
        empty_registry.register(TypeDefinition(
            name="Email",
            description="Email address format",
            base=BaseType.STRING,
        ))
        empty_registry.register(TypeDefinition(
            name="URL",
            description="Web URL",
            base=BaseType.STRING,
        ))
        empty_registry.register(TypeDefinition(
            name="CorporateEmail",
            description="Corporate email at company domain",
            base=BaseType.STRING,
        ))

        # Search by name
        results = empty_registry.search_types("email")
        names = [t.name for t in results]
        assert "Email" in names
        assert "CorporateEmail" in names
        assert "URL" not in names

        # Search by description
        results = empty_registry.search_types("web")
        assert len(results) == 1
        assert results[0].name == "URL"

    def test_get_types_by_tag(self, empty_registry):
        """Test getting types by tag."""
        empty_registry.register(TypeDefinition(
            name="SSN",
            description="SSN",
            base=BaseType.STRING,
            tags=["pii", "us"],
        ))
        empty_registry.register(TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            tags=["pii", "contact"],
        ))
        empty_registry.register(TypeDefinition(
            name="URL",
            description="URL",
            base=BaseType.STRING,
            tags=["web"],
        ))

        pii_types = empty_registry.get_types_by_tag("pii")
        assert "SSN" in pii_types
        assert "Email" in pii_types
        assert "URL" not in pii_types

    def test_cache_invalidation(self, empty_registry):
        """Test that resolved cache is invalidated on new registration."""
        email = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            max_length=100,
        )
        empty_registry.register(email)

        # Resolve to populate cache
        resolved1 = empty_registry.resolve("Email")
        assert resolved1.max_length == 100

        # Register new type (should invalidate cache)
        empty_registry.register(TypeDefinition(
            name="URL", description="URL", base=BaseType.STRING
        ))

        # Re-register Email with different value
        email2 = TypeDefinition(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            max_length=200,
        )
        empty_registry.register(email2)

        # Should get new value
        resolved2 = empty_registry.resolve("Email")
        assert resolved2.max_length == 200


class TestResolvedType:
    """Tests for ResolvedType."""

    def test_get_validation_rules(self):
        """Test getting validation rules from resolved type."""
        resolved = ResolvedType(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            pattern=r"^.+@.+$",
            max_length=255,
            allow_null=False,
        )

        rules = resolved.get_validation_rules()
        assert rules["pattern"] == r"^.+@.+$"
        assert rules["max_length"] == 255
        assert rules["allow_null"] is False
        assert "min" not in rules  # Should not include None values

    def test_get_validation_rules_numeric(self):
        """Test getting validation rules from numeric type."""
        resolved = ResolvedType(
            name="Percentage",
            description="Percentage",
            base=BaseType.DECIMAL,
            min=0,
            max=100,
            allow_null=False,
        )

        rules = resolved.get_validation_rules()
        assert rules["min"] == 0
        assert rules["max"] == 100


class TestColumnMapping:
    """Tests for ColumnMapping."""

    def test_basic_mapping(self):
        """Test basic column mapping."""
        col = ColumnMapping(name="email", type="Email")
        assert col.name == "email"
        assert col.type == "Email"
        assert col.allow_null is None
        assert col.confidence is None

    def test_mapping_with_override(self):
        """Test column mapping with nullability override."""
        col = ColumnMapping(name="email", type="Email", allow_null=True)
        assert col.allow_null is True

    def test_mapping_with_confidence(self):
        """Test column mapping with AI confidence."""
        col = ColumnMapping(name="email", type="Email", confidence="high")
        assert col.confidence == "high"

    def test_invalid_confidence(self):
        """Test that invalid confidence is rejected."""
        with pytest.raises(ValueError):
            ColumnMapping(name="email", type="Email", confidence="invalid")


class TestModelMapping:
    """Tests for ModelMapping."""

    def test_basic_mapping(self):
        """Test creating a basic model mapping."""
        mapping = ModelMapping(
            table="public.users",
            columns=[
                ColumnMapping(name="email", type="Email"),
                ColumnMapping(name="id", type="UUID"),
            ],
        )
        assert mapping.table == "public.users"
        assert mapping.schema_name == "public"
        assert mapping.table_name == "users"
        assert len(mapping.columns) == 2

    def test_no_schema(self):
        """Test mapping without schema."""
        mapping = ModelMapping(
            table="users",
            columns=[ColumnMapping(name="id", type="UUID")],
        )
        assert mapping.schema_name is None
        assert mapping.table_name == "users"

    def test_empty_columns_rejected(self):
        """Test that empty columns list is rejected."""
        with pytest.raises(ValueError):
            ModelMapping(table="users", columns=[])


class TestCheckRule:
    """Tests for CheckRule."""

    def test_basic_check(self):
        """Test basic check rule."""
        check = CheckRule(
            on="orders",
            rules=["amount > 0", "quantity >= 1"],
        )
        assert check.on == "orders"
        assert len(check.rules) == 2

    def test_check_with_name(self):
        """Test check rule with name."""
        check = CheckRule(
            on="orders",
            name="Positive amounts check",
            rules=["amount > 0"],
        )
        assert check.name == "Positive amounts check"

    def test_empty_rules_rejected(self):
        """Test that empty rules list is rejected."""
        with pytest.raises(ValueError):
            CheckRule(on="orders", rules=[])


class TestGoQualityConfig:
    """Tests for GoQualityConfig."""

    def test_empty_config(self):
        """Test empty configuration."""
        config = GoQualityConfig()
        assert config.types == []
        assert config.models == []
        assert config.checks == []

    def test_config_with_all_fields(self, custom_types):
        """Test configuration with all fields."""
        config = GoQualityConfig(
            types=custom_types,
            models=[
                ModelMapping(
                    table="users",
                    columns=[ColumnMapping(name="email", type="Email")],
                )
            ],
            checks=[
                CheckRule(on="orders", rules=["amount > 0"])
            ],
        )
        assert len(config.types) == 3
        assert len(config.models) == 1
        assert len(config.checks) == 1

    def test_get_tables(self, sample_config):
        """Test getting all table names."""
        tables = sample_config.get_tables()
        assert "users" in tables
        assert "orders" in tables

    def test_get_type_names(self, sample_config):
        """Test getting custom type names."""
        names = sample_config.get_type_names()
        assert "UserStatus" in names
        assert "OrderAmount" in names
        assert "AcmeEmail" in names

    def test_get_referenced_types(self, sample_config):
        """Test extracting referenced types."""
        refs = sample_config.get_referenced_types()
        assert "Email" in refs
        assert "UUID" in refs
        assert "UserStatus" in refs
        assert "Percentage" in refs


class TestStdlibLoading:
    """Tests for loading the standard library."""

    def test_stdlib_loads(self, stdlib_registry):
        """Test that stdlib loads successfully."""
        types = stdlib_registry.list_types()
        assert len(types) > 100  # Should have 100+ types

    def test_stdlib_has_core_types(self, stdlib_registry):
        """Test that core types exist."""
        core_types = ["Email", "UUID", "URL", "IPv4", "Percentage"]
        for name in core_types:
            assert stdlib_registry.has_type(name), f"Missing core type: {name}"

    def test_stdlib_has_finance_types(self, stdlib_registry):
        """Test that finance types exist."""
        finance_types = ["USD", "EUR", "IBAN", "CreditCardNumber"]
        for name in finance_types:
            assert stdlib_registry.has_type(name), f"Missing finance type: {name}"

    def test_stdlib_has_geo_types(self, stdlib_registry):
        """Test that geo types exist."""
        geo_types = ["CountryISO2", "StateUS", "ZipCodeUS"]
        for name in geo_types:
            assert stdlib_registry.has_type(name), f"Missing geo type: {name}"

    def test_stdlib_email_resolves(self, stdlib_registry):
        """Test that Email type resolves correctly."""
        email = stdlib_registry.resolve("Email")
        assert email.base == BaseType.STRING
        assert email.pattern is not None
        assert email.allow_null is False

    def test_stdlib_nullable_inherits(self, stdlib_registry):
        """Test that Nullable variants inherit correctly."""
        email = stdlib_registry.resolve("Email")
        email_nullable = stdlib_registry.resolve("EmailNullable")

        assert email.pattern == email_nullable.pattern  # Same pattern
        assert email.allow_null is False
        assert email_nullable.allow_null is True

    def test_stdlib_percentage_range(self, stdlib_registry):
        """Test Percentage type range."""
        pct = stdlib_registry.resolve("Percentage")
        assert pct.min == 0
        assert pct.max == 100
