"""
Tests for error handling module.
"""

import pytest

from goquality.errors import (
    ColumnValidationError,
    ConfigurationError,
    ConnectionError,
    ErrorCollector,
    ErrorSeverity,
    GoQualityError,
    RateLimitError,
    ValidationError,
    safe_execute,
    with_error_handling,
)


class TestGoQualityError:
    """Tests for base error class."""

    def test_basic_error(self):
        """Test creating a basic error."""
        error = GoQualityError("Test error")
        assert error.message == "Test error"
        assert error.details == {}
        assert error.cause is None

    def test_error_with_details(self):
        """Test error with details."""
        error = GoQualityError(
            "Test error",
            details={"key": "value"},
        )
        assert error.details == {"key": "value"}

    def test_error_with_cause(self):
        """Test error with cause."""
        original = ValueError("original error")
        error = GoQualityError("Wrapped error", cause=original)
        assert error.cause is original

    def test_to_dict(self):
        """Test converting error to dictionary."""
        original = ValueError("original")
        error = GoQualityError(
            "Test error",
            details={"key": "value"},
            cause=original,
        )

        d = error.to_dict()
        assert d["error_type"] == "GoQualityError"
        assert d["message"] == "Test error"
        assert d["details"] == {"key": "value"}
        assert "original" in d["cause"]


class TestErrorSeverities:
    """Tests for error severity levels."""

    def test_configuration_error_is_critical(self):
        """Test ConfigurationError is critical."""
        assert ConfigurationError.severity == ErrorSeverity.CRITICAL

    def test_connection_error_is_critical(self):
        """Test ConnectionError is critical."""
        assert ConnectionError.severity == ErrorSeverity.CRITICAL

    def test_validation_error_is_error(self):
        """Test ValidationError is error level."""
        assert ValidationError.severity == ErrorSeverity.ERROR

    def test_column_validation_error_is_warning(self):
        """Test ColumnValidationError is warning level."""
        assert ColumnValidationError.severity == ErrorSeverity.WARNING

    def test_rate_limit_error_is_warning(self):
        """Test RateLimitError is warning level."""
        assert RateLimitError.severity == ErrorSeverity.WARNING


class TestErrorCollector:
    """Tests for error collector."""

    def test_empty_collector(self):
        """Test empty collector."""
        collector = ErrorCollector()
        assert collector.has_errors is False
        assert collector.has_warnings is False
        assert collector.error_count == 0
        assert collector.warning_count == 0

    def test_add_error(self):
        """Test adding an error."""
        collector = ErrorCollector()
        collector.add(ValidationError("Test error"))

        assert collector.has_errors is True
        assert collector.error_count == 1

    def test_add_warning(self):
        """Test adding a warning."""
        collector = ErrorCollector()
        collector.add(ColumnValidationError("Test warning"))

        assert collector.has_warnings is True
        assert collector.warning_count == 1
        assert collector.has_errors is False

    def test_add_with_context(self):
        """Test adding error with context."""
        collector = ErrorCollector()
        collector.add(
            ValidationError("Test error"),
            context={"table": "users", "column": "email"},
        )

        summary = collector.get_summary()
        assert summary["errors"][0]["context"] == {"table": "users", "column": "email"}

    def test_add_unknown_exception(self):
        """Test adding unknown exception type."""
        collector = ErrorCollector()
        collector.add(ValueError("Unknown error"))

        assert collector.has_errors is True

    def test_get_summary(self):
        """Test getting summary."""
        collector = ErrorCollector()
        collector.add(ValidationError("Error 1"))
        collector.add(ColumnValidationError("Warning 1"))

        summary = collector.get_summary()
        assert summary["error_count"] == 1
        assert summary["warning_count"] == 1
        assert len(summary["errors"]) == 1
        assert len(summary["warnings"]) == 1

    def test_raise_if_errors(self):
        """Test raise_if_errors."""
        collector = ErrorCollector()

        # Should not raise when empty
        collector.raise_if_errors()

        # Should raise after adding error
        collector.add(ValidationError("Test error"))
        with pytest.raises(GoQualityError, match="1 error"):
            collector.raise_if_errors()


class TestWithErrorHandling:
    """Tests for error handling decorator."""

    def test_successful_execution(self):
        """Test successful function execution."""
        @with_error_handling("test_op")
        def success():
            return 42

        result = success()
        assert result == 42

    def test_error_with_fallback(self):
        """Test error with fallback value."""
        @with_error_handling("test_op", on_error=lambda e: -1)
        def fail():
            raise ValueError("oops")

        result = fail()
        assert result == -1

    def test_error_reraise(self):
        """Test error re-raising."""
        @with_error_handling("test_op", reraise=True)
        def fail():
            raise ValueError("oops")

        with pytest.raises(ValueError, match="oops"):
            fail()

    def test_error_no_reraise(self):
        """Test error without re-raising."""
        @with_error_handling("test_op", reraise=False)
        def fail():
            raise ValueError("oops")

        result = fail()
        assert result is None


class TestSafeExecute:
    """Tests for safe_execute function."""

    def test_successful_execution(self):
        """Test successful execution."""
        def success():
            return 42

        result = safe_execute(success)
        assert result == 42

    def test_execution_with_args(self):
        """Test execution with arguments."""
        def add(a, b):
            return a + b

        result = safe_execute(add, 1, 2)
        assert result == 3

    def test_default_on_error(self):
        """Test default value on error."""
        def fail():
            raise ValueError("oops")

        result = safe_execute(fail, default=-1)
        assert result == -1

    def test_error_collector(self):
        """Test error collection."""
        collector = ErrorCollector()

        def fail():
            raise ValueError("oops")

        result = safe_execute(
            fail,
            default=None,
            error_collector=collector,
            context={"operation": "test"},
        )

        assert result is None
        assert collector.has_errors is True
        assert collector.get_summary()["errors"][0]["context"] == {"operation": "test"}
