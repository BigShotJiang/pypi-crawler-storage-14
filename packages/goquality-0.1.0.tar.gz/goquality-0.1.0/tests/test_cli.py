"""
Comprehensive tests for the CLI module.
"""

import re
from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from goquality.cli.connection import check_connection, connect, parse_connection_string
from goquality.cli.main import app

runner = CliRunner()


def strip_ansi(text: str) -> str:
    """Strip ANSI escape codes from text."""
    ansi_pattern = re.compile(r'\x1b\[[0-9;]*m')
    return ansi_pattern.sub('', text)


class TestParseConnectionString:
    """Tests for parse_connection_string function."""

    def test_postgres_full_url(self):
        """Test parsing full PostgreSQL URL."""
        result = parse_connection_string("postgres://user:pass@host.com:5433/mydb")

        assert result["driver"] == "postgres"
        assert result["user"] == "user"
        assert result["password"] == "pass"
        assert result["host"] == "host.com"
        assert result["port"] == 5433
        assert result["database"] == "mydb"

    def test_postgres_default_port(self):
        """Test PostgreSQL URL with default port."""
        result = parse_connection_string("postgres://user:pass@localhost/db")

        assert result["port"] == 5432
        assert result["host"] == "localhost"

    def test_postgresql_scheme(self):
        """Test 'postgresql://' scheme."""
        result = parse_connection_string("postgresql://user:pass@host/db")

        assert result["driver"] == "postgres"

    def test_duckdb_memory(self):
        """Test DuckDB in-memory connection."""
        result = parse_connection_string("duckdb://:memory:")

        assert result["driver"] == "duckdb"
        assert result["path"] == ":memory:"

    def test_duckdb_file(self):
        """Test DuckDB file connection."""
        result = parse_connection_string("duckdb:///path/to/db.duckdb")

        assert result["driver"] == "duckdb"
        assert result["path"] == "/path/to/db.duckdb"

    def test_local_csv_file(self):
        """Test local CSV file path."""
        result = parse_connection_string("/data/test.csv")

        assert result["driver"] == "duckdb"
        assert result["path"] == "/data/test.csv"

    def test_local_parquet_file(self):
        """Test local Parquet file path."""
        result = parse_connection_string("/data/test.parquet")

        assert result["driver"] == "duckdb"
        assert result["path"] == "/data/test.parquet"

    def test_relative_path(self):
        """Test relative file path."""
        result = parse_connection_string("./data/test.db")

        assert result["driver"] == "duckdb"
        # Path normalization may remove leading "./"
        assert "data/test.db" in result["path"]

    def test_unsupported_database(self):
        """Test unsupported database scheme."""
        with pytest.raises(ValueError, match="Unsupported database"):
            parse_connection_string("mysql://user:pass@host/db")

    def test_unsupported_file_type(self):
        """Test unsupported file extension."""
        with pytest.raises(ValueError, match="Unsupported file type"):
            parse_connection_string("/data/test.xlsx")


class TestConnect:
    """Tests for connect function."""

    def test_connect_duckdb_memory(self):
        """Test connecting to in-memory DuckDB."""
        conn = connect("duckdb://:memory:")

        assert conn is not None
        # Should be able to list tables
        tables = conn.list_tables()
        assert isinstance(tables, list)

    def test_connect_postgres_mock(self):
        """Test connecting to PostgreSQL with mock."""
        with patch("ibis.postgres.connect") as mock_connect:
            mock_conn = Mock()
            mock_connect.return_value = mock_conn

            connect("postgres://user:pass@localhost/testdb")

            mock_connect.assert_called_once_with(
                user="user",
                password="pass",
                host="localhost",
                port=5432,
                database="testdb",
            )

    def test_connect_unsupported_driver(self):
        """Test connecting with unsupported driver."""
        with pytest.raises(ValueError, match="Unsupported"):
            parse_connection_string("mysql://localhost/db")


class TestCheckConnection:
    """Tests for check_connection function."""

    def test_duckdb_memory_connection(self):
        """Test connection check with in-memory DuckDB."""
        result = check_connection("duckdb://:memory:")

        assert result is True


class TestCLIInit:
    """Tests for the init command."""

    def test_init_creates_config(self, tmp_path):
        """Test that init creates config file."""
        config_path = tmp_path / "goquality.yaml"

        result = runner.invoke(app, ["init", "--path", str(config_path)])

        assert result.exit_code == 0
        assert config_path.exists()
        assert "Created" in result.output

    def test_init_prompts_overwrite(self, tmp_path):
        """Test that init prompts before overwriting."""
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("existing: content")

        result = runner.invoke(app, ["init", "--path", str(config_path)], input="n\n")

        # Should abort
        assert "Aborted" in result.output or result.exit_code != 0
        # Content should be unchanged
        assert "existing: content" in config_path.read_text()

    def test_init_with_overwrite(self, tmp_path):
        """Test that init overwrites when confirmed."""
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("existing: content")

        result = runner.invoke(app, ["init", "--path", str(config_path)], input="y\n")

        assert result.exit_code == 0
        assert "existing: content" not in config_path.read_text()


class TestCLIValidate:
    """Tests for the validate command."""

    def test_validate_valid_config(self, tmp_path):
        """Test validating a valid config file."""
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("""
types:
  - name: CustomEmail
    description: Custom email type
    base: String
    extends: Email

models:
  - table: users
    columns:
      - name: email
        type: Email
      - name: id
        type: UUID
""")

        result = runner.invoke(app, ["validate", "--config", str(config_path)])

        assert result.exit_code == 0
        assert "Valid" in result.output

    def test_validate_missing_file(self, tmp_path):
        """Test validating a non-existent file."""
        config_path = tmp_path / "nonexistent.yaml"

        result = runner.invoke(app, ["validate", "--config", str(config_path)])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_validate_invalid_yaml(self, tmp_path):
        """Test validating invalid YAML syntax."""
        config_path = tmp_path / "bad.yaml"
        config_path.write_text("""
types:
  - name: bad  # lowercase - invalid
    description: x
    base: String
""")

        result = runner.invoke(app, ["validate", "--config", str(config_path)])

        assert result.exit_code == 1

    def test_validate_unknown_type_reference(self, tmp_path):
        """Test validating config with unknown type reference."""
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("""
types: []
models:
  - table: users
    columns:
      - name: email
        type: NonExistentType
""")

        result = runner.invoke(app, ["validate", "--config", str(config_path)])

        assert result.exit_code == 1
        assert "Unknown types" in result.output


class TestCLITypes:
    """Tests for the types command."""

    def test_types_list_all(self):
        """Test listing all types."""
        result = runner.invoke(app, ["types"])

        assert result.exit_code == 0
        assert "Email" in result.output
        assert "UUID" in result.output
        assert "Available Types" in result.output

    def test_types_search(self):
        """Test searching types."""
        result = runner.invoke(app, ["types", "--search", "email"])

        assert result.exit_code == 0
        assert "Email" in result.output
        # Should not show unrelated types
        # (might show types with "email" in description though)

    def test_types_show_detail(self):
        """Test showing type details."""
        result = runner.invoke(app, ["types", "--show", "Email"])

        assert result.exit_code == 0
        assert "Email" in result.output
        assert "String" in result.output or "Base type" in result.output

    def test_types_show_unknown(self):
        """Test showing unknown type."""
        result = runner.invoke(app, ["types", "--show", "NonExistent"])

        assert result.exit_code == 1
        assert "Unknown type" in result.output

    def test_types_filter_by_tag(self):
        """Test filtering types by tag."""
        result = runner.invoke(app, ["types", "--tag", "pii"])

        assert result.exit_code == 0
        # PII types should be in output
        # Exact types depend on stdlib


class TestCLIVersion:
    """Tests for the version command."""

    def test_version_output(self):
        """Test version command output."""
        result = runner.invoke(app, ["version"])

        assert result.exit_code == 0
        assert "GoQuality" in result.output
        assert "v" in result.output


class TestCLIHelp:
    """Tests for help output."""

    def test_main_help(self):
        """Test main help output."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "init" in result.output
        assert "generate" in result.output
        assert "check" in result.output
        assert "validate" in result.output
        assert "types" in result.output

    def test_init_help(self):
        """Test init command help."""
        result = runner.invoke(app, ["init", "--help"])
        output = strip_ansi(result.output)

        assert result.exit_code == 0
        assert "--source" in output
        assert "--path" in output

    def test_generate_help(self):
        """Test generate command help."""
        result = runner.invoke(app, ["generate", "--help"])
        output = strip_ansi(result.output)

        assert result.exit_code == 0
        assert "--source" in output
        assert "--output" in output
        assert "--provider" in output

    def test_check_help(self):
        """Test check command help."""
        result = runner.invoke(app, ["check", "--help"])
        output = strip_ansi(result.output)

        assert result.exit_code == 0
        assert "--config" in output
        assert "--source" in output
        assert "--table" in output


class TestCLICheck:
    """Tests for the check command."""

    def test_check_missing_config(self, tmp_path):
        """Test check with missing config file."""
        result = runner.invoke(app, [
            "check",
            "--config", str(tmp_path / "nonexistent.yaml"),
            "--source", "duckdb://:memory:",
        ])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_check_no_source(self, tmp_path):
        """Test check without source."""
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("""
types: []
models:
  - table: test
    columns:
      - name: id
        type: UUID
""")

        result = runner.invoke(app, [
            "check",
            "--config", str(config_path),
        ])

        assert result.exit_code == 1
        assert "connection" in result.output.lower()


class TestCLIIntegration:
    """Integration tests for CLI with DuckDB."""

    def test_full_workflow(self, tmp_path, duckdb_conn):
        """Test full workflow: init -> check."""
        # Create test data in DuckDB
        duckdb_conn.raw_sql("""
            CREATE TABLE users AS
            SELECT * FROM (VALUES
                ('alice@example.com', '550e8400-e29b-41d4-a716-446655440000'),
                ('bob@test.org', '550e8400-e29b-41d4-a716-446655440001'),
                ('invalid', 'not-a-uuid')
            ) AS t(email, id)
        """)

        # Create config
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("""
types: []
models:
  - table: users
    columns:
      - name: email
        type: Email
      - name: id
        type: UUID
""")

        # We can't easily test check without a real database file
        # But we can validate the config
        result = runner.invoke(app, ["validate", "--config", str(config_path)])
        assert result.exit_code == 0
