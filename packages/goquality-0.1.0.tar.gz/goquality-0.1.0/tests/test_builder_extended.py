"""
Extended tests for builder module including ad-hoc checks.
"""

from goquality.compiler.builder import (
    AdHocCheck,
    AdHocCheckResult,
    SQLPredicateRule,
    compile_check_rules,
    parse_sql_predicate,
)


class TestCompileCheckRules:
    """Tests for compile_check_rules function."""

    def test_compile_simple_comparison(self):
        """Test compiling simple comparison rules."""
        rules = compile_check_rules(["amount > 0", "quantity >= 1"])

        assert len(rules) == 2
        assert all(isinstance(r, SQLPredicateRule) for r in rules)

    def test_compile_is_not_null(self):
        """Test compiling IS NOT NULL rules."""
        rules = compile_check_rules(["status IS NOT NULL"])

        assert len(rules) == 1
        assert "must not be null" in rules[0].describe()

    def test_compile_is_null(self):
        """Test compiling IS NULL rules."""
        rules = compile_check_rules(["deleted_at IS NULL"])

        assert len(rules) == 1
        assert "must be null" in rules[0].describe()

    def test_compile_in_clause(self):
        """Test compiling IN clause rules."""
        rules = compile_check_rules(["status IN ('active', 'pending', 'completed')"])

        assert len(rules) == 1
        assert "in allowed values" in rules[0].describe()

    def test_compile_between(self):
        """Test compiling BETWEEN rules."""
        rules = compile_check_rules(["age BETWEEN 0 AND 150"])

        assert len(rules) == 1
        assert "between" in rules[0].describe().lower()

    def test_compile_like(self):
        """Test compiling LIKE rules."""
        rules = compile_check_rules(["email LIKE '%@%'"])

        assert len(rules) == 1
        assert "pattern" in rules[0].describe().lower()


class TestParseSQLPredicate:
    """Tests for parse_sql_predicate function."""

    def test_parse_greater_than(self):
        """Test parsing greater than."""
        rule = parse_sql_predicate("amount > 0")

        assert rule is not None
        assert rule.column_name == "amount"
        assert "greater than" in rule.description

    def test_parse_greater_equal(self):
        """Test parsing greater than or equal."""
        rule = parse_sql_predicate("quantity >= 1")

        assert rule is not None
        assert "greater than or equal" in rule.description

    def test_parse_less_than(self):
        """Test parsing less than."""
        rule = parse_sql_predicate("price < 1000")

        assert rule is not None
        assert "less than" in rule.description

    def test_parse_equal(self):
        """Test parsing equal."""
        rule = parse_sql_predicate("status = 'active'")

        assert rule is not None
        assert "equal to" in rule.description

    def test_parse_not_equal(self):
        """Test parsing not equal."""
        rule = parse_sql_predicate("type != 'deleted'")

        assert rule is not None
        assert "not equal" in rule.description

    def test_parse_not_equal_ansi(self):
        """Test parsing ANSI not equal (<>)."""
        rule = parse_sql_predicate("type <> 'deleted'")

        assert rule is not None
        assert "not equal" in rule.description

    def test_parse_is_not_null(self):
        """Test parsing IS NOT NULL."""
        rule = parse_sql_predicate("email IS NOT NULL")

        assert rule is not None
        assert rule.column_name == "email"
        assert "not be null" in rule.description

    def test_parse_is_null(self):
        """Test parsing IS NULL."""
        rule = parse_sql_predicate("deleted_at IS NULL")

        assert rule is not None
        assert rule.column_name == "deleted_at"
        assert "must be null" in rule.description

    def test_parse_in(self):
        """Test parsing IN clause."""
        rule = parse_sql_predicate("status IN ('a', 'b', 'c')")

        assert rule is not None
        assert rule.column_name == "status"

    def test_parse_between(self):
        """Test parsing BETWEEN."""
        rule = parse_sql_predicate("age BETWEEN 0 AND 120")

        assert rule is not None
        assert rule.column_name == "age"
        assert "0" in rule.description
        assert "120" in rule.description

    def test_parse_like(self):
        """Test parsing LIKE."""
        rule = parse_sql_predicate("name LIKE 'John%'")

        assert rule is not None
        assert rule.column_name == "name"

    def test_parse_unknown_returns_none(self):
        """Test that unknown patterns return None."""
        rule = parse_sql_predicate("COMPLEX EXPRESSION()")

        # Should return None for unrecognized patterns
        # (compile_check_rules will create a generic rule)
        assert rule is None

    def test_case_insensitive(self):
        """Test case insensitive parsing."""
        rule1 = parse_sql_predicate("status is not null")
        rule2 = parse_sql_predicate("status IS NOT NULL")

        assert rule1 is not None
        assert rule2 is not None


class TestSQLPredicateRule:
    """Tests for SQLPredicateRule class."""

    def test_basic_rule(self):
        """Test basic rule creation."""
        rule = SQLPredicateRule(
            predicate="amount > 0",
            column_name="amount",
            description="amount must be positive",
        )

        assert rule.name == "sql_predicate"
        assert rule.predicate == "amount > 0"
        assert rule.column_name == "amount"
        assert rule.describe() == "amount must be positive"

    def test_describe_with_empty_description(self):
        """Test describe() with empty description."""
        rule = SQLPredicateRule(predicate="x > 0")

        assert "x > 0" in rule.describe()


class TestAdHocCheck:
    """Tests for AdHocCheck dataclass."""

    def test_basic_check(self):
        """Test basic check creation."""
        check = AdHocCheck(
            table="users",
            name="User age check",
            rules=["age > 0", "age < 150"],
        )

        assert check.table == "users"
        assert check.name == "User age check"
        assert len(check.rules) == 2


class TestAdHocCheckResult:
    """Tests for AdHocCheckResult dataclass."""

    def test_passing_result(self):
        """Test passing check result."""
        result = AdHocCheckResult(
            table="users",
            name="Test check",
            rule="age > 0",
            total_rows=100,
            passing_rows=100,
            failing_rows=0,
            passed=True,
        )

        assert result.passed is True
        assert result.failing_rows == 0

    def test_failing_result(self):
        """Test failing check result."""
        result = AdHocCheckResult(
            table="users",
            name="Test check",
            rule="age > 0",
            total_rows=100,
            passing_rows=90,
            failing_rows=10,
            passed=False,
            sample_failures=["row1", "row2"],
        )

        assert result.passed is False
        assert result.failing_rows == 10
        assert len(result.sample_failures) == 2
