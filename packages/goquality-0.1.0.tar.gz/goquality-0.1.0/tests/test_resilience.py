"""
Tests for resilience module.
"""

import time

import pytest

from goquality.resilience import (
    CircuitBreaker,
    CircuitOpenError,
    ConnectionPool,
    RateLimiter,
    RateLimiterRegistry,
    RetryConfig,
    calculate_backoff,
    retry,
    retry_with_backoff,
)


class TestRetryConfig:
    """Tests for retry configuration."""

    def test_default_config(self):
        """Test default retry configuration."""
        config = RetryConfig()
        assert config.max_attempts == 3
        assert config.initial_delay == 1.0
        assert config.max_delay == 60.0
        assert config.exponential_base == 2.0
        assert config.jitter is True


class TestCalculateBackoff:
    """Tests for backoff calculation."""

    def test_exponential_backoff(self):
        """Test exponential backoff calculation."""
        config = RetryConfig(initial_delay=1.0, exponential_base=2.0, jitter=False)

        assert calculate_backoff(0, config) == 1.0  # 1 * 2^0 = 1
        assert calculate_backoff(1, config) == 2.0  # 1 * 2^1 = 2
        assert calculate_backoff(2, config) == 4.0  # 1 * 2^2 = 4

    def test_max_delay_cap(self):
        """Test that delay is capped at max_delay."""
        config = RetryConfig(initial_delay=1.0, max_delay=10.0, exponential_base=2.0, jitter=False)

        assert calculate_backoff(10, config) == 10.0  # Would be 1024, capped at 10

    def test_jitter_adds_variation(self):
        """Test that jitter adds variation."""
        config = RetryConfig(initial_delay=10.0, jitter=True)

        delays = [calculate_backoff(0, config) for _ in range(10)]
        # With jitter, not all delays should be equal
        assert len(set(delays)) > 1


class TestRetryDecorator:
    """Tests for retry decorator."""

    def test_successful_execution(self):
        """Test successful function execution."""
        call_count = 0

        @retry(max_attempts=3)
        def success_func():
            nonlocal call_count
            call_count += 1
            return "success"

        result = success_func()
        assert result == "success"
        assert call_count == 1

    def test_retry_on_failure(self):
        """Test retry on failure."""
        call_count = 0

        @retry(max_attempts=3, initial_delay=0.01)
        def fail_twice():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("not yet")
            return "success"

        result = fail_twice()
        assert result == "success"
        assert call_count == 3

    def test_max_attempts_exceeded(self):
        """Test that exception is raised after max attempts."""
        call_count = 0

        @retry(max_attempts=2, initial_delay=0.01)
        def always_fail():
            nonlocal call_count
            call_count += 1
            raise ValueError("always fails")

        with pytest.raises(ValueError, match="always fails"):
            always_fail()

        assert call_count == 2

    def test_specific_exception_retry(self):
        """Test retrying only specific exceptions."""
        config = RetryConfig(
            max_attempts=3,
            initial_delay=0.01,
            retry_exceptions=(ValueError,),
        )

        call_count = 0

        @retry(config=config)
        def fail_with_type_error():
            nonlocal call_count
            call_count += 1
            raise TypeError("wrong type")

        # TypeError should not be retried
        with pytest.raises(TypeError):
            fail_with_type_error()

        assert call_count == 1


class TestRetryWithBackoff:
    """Tests for retry_with_backoff function."""

    def test_successful_call(self):
        """Test successful function call."""
        def success():
            return 42

        result = retry_with_backoff(success)
        assert result == 42

    def test_retry_call(self):
        """Test retry with backoff."""
        attempts = []

        def fail_once():
            attempts.append(1)
            if len(attempts) < 2:
                raise ValueError("fail")
            return "ok"

        config = RetryConfig(max_attempts=3, initial_delay=0.01)
        result = retry_with_backoff(fail_once, config=config)
        assert result == "ok"
        assert len(attempts) == 2


class TestRateLimiter:
    """Tests for rate limiter."""

    def test_basic_rate_limiting(self):
        """Test basic rate limiting."""
        limiter = RateLimiter(rate=10, per_seconds=1.0)

        # Should be able to acquire 10 tokens immediately
        for _ in range(10):
            assert limiter.try_acquire() is True

        # 11th should fail (non-blocking)
        assert limiter.try_acquire() is False

    def test_token_refill(self):
        """Test that tokens refill over time."""
        limiter = RateLimiter(rate=10, per_seconds=0.1)  # 10 per 0.1s = 100/s

        # Exhaust tokens
        for _ in range(10):
            limiter.try_acquire()

        assert limiter.try_acquire() is False

        # Wait for refill
        time.sleep(0.15)

        # Should have tokens again
        assert limiter.try_acquire() is True

    def test_blocking_acquire(self):
        """Test blocking acquire."""
        limiter = RateLimiter(rate=5, per_seconds=0.1)

        # Exhaust tokens
        for _ in range(5):
            limiter.acquire(blocking=False)

        # This should block but eventually succeed
        start = time.time()
        result = limiter.acquire(blocking=True, timeout=1.0)
        elapsed = time.time() - start

        assert result is True
        assert elapsed >= 0.01  # Should have waited

    def test_timeout(self):
        """Test acquire timeout."""
        limiter = RateLimiter(rate=1, per_seconds=10.0)  # Very slow refill

        # Use the one token
        limiter.acquire()

        # Should timeout
        result = limiter.acquire(blocking=True, timeout=0.05)
        assert result is False


class TestRateLimiterRegistry:
    """Tests for rate limiter registry."""

    def test_get_creates_limiter(self):
        """Test that get creates a new limiter."""
        RateLimiterRegistry.reset()

        limiter1 = RateLimiterRegistry.get("test", rate=10, per_seconds=1.0)
        limiter2 = RateLimiterRegistry.get("test", rate=100, per_seconds=1.0)

        # Should return same instance
        assert limiter1 is limiter2

    def test_different_names_different_limiters(self):
        """Test that different names get different limiters."""
        RateLimiterRegistry.reset()

        limiter1 = RateLimiterRegistry.get("test1", rate=10, per_seconds=1.0)
        limiter2 = RateLimiterRegistry.get("test2", rate=10, per_seconds=1.0)

        assert limiter1 is not limiter2

    def test_reset(self):
        """Test resetting registry."""
        RateLimiterRegistry.reset()

        limiter1 = RateLimiterRegistry.get("test", rate=10, per_seconds=1.0)
        RateLimiterRegistry.reset("test")
        limiter2 = RateLimiterRegistry.get("test", rate=10, per_seconds=1.0)

        assert limiter1 is not limiter2


class TestCircuitBreaker:
    """Tests for circuit breaker."""

    def test_closed_state(self):
        """Test normal operation in closed state."""
        breaker = CircuitBreaker(failure_threshold=3)

        # Should work normally
        with breaker:
            pass

        assert breaker.state == "CLOSED"

    def test_opens_after_failures(self):
        """Test circuit opens after threshold failures."""
        breaker = CircuitBreaker(failure_threshold=2)

        # Fail twice
        for _ in range(2):
            try:
                with breaker:
                    raise ValueError("fail")
            except ValueError:
                pass

        assert breaker.state == "OPEN"

        # Should raise CircuitOpenError
        with pytest.raises(CircuitOpenError):
            with breaker:
                pass

    def test_half_open_after_timeout(self):
        """Test circuit goes to half-open after timeout."""
        breaker = CircuitBreaker(failure_threshold=1, reset_timeout=0.05)

        # Open the circuit
        try:
            with breaker:
                raise ValueError("fail")
        except ValueError:
            pass

        assert breaker.state == "OPEN"

        # Wait for timeout
        time.sleep(0.1)

        # Should allow one request (half-open)
        with breaker:
            pass

        assert breaker.state == "HALF_OPEN"

    def test_closes_after_success_in_half_open(self):
        """Test circuit closes after success in half-open."""
        breaker = CircuitBreaker(
            failure_threshold=1,
            success_threshold=2,
            reset_timeout=0.01,
        )

        # Open the circuit
        try:
            with breaker:
                raise ValueError("fail")
        except ValueError:
            pass

        # Wait for half-open
        time.sleep(0.02)

        # Two successes should close it
        with breaker:
            pass
        with breaker:
            pass

        assert breaker.state == "CLOSED"

    def test_reset(self):
        """Test manual reset."""
        breaker = CircuitBreaker(failure_threshold=1)

        # Open the circuit
        try:
            with breaker:
                raise ValueError("fail")
        except ValueError:
            pass

        assert breaker.state == "OPEN"

        breaker.reset()
        assert breaker.state == "CLOSED"


class TestConnectionPool:
    """Tests for connection pool."""

    def test_acquire_and_release(self):
        """Test acquiring and releasing connections."""
        connections_created = []

        def factory():
            conn = f"conn_{len(connections_created)}"
            connections_created.append(conn)
            return conn

        pool = ConnectionPool(factory=factory, max_size=2)

        conn1 = pool.acquire()
        assert conn1 == "conn_0"

        conn2 = pool.acquire()
        assert conn2 == "conn_1"

        # Release and re-acquire
        pool.release(conn1)
        conn3 = pool.acquire()
        assert conn3 == "conn_0"  # Should reuse

    def test_max_size_limit(self):
        """Test pool respects max size."""
        pool = ConnectionPool(factory=lambda: object(), max_size=1, timeout=0.05)

        conn1 = pool.acquire()

        # Should timeout trying to get second connection
        with pytest.raises(TimeoutError):
            pool.acquire(timeout=0.05)

        # Release and should be able to acquire again
        pool.release(conn1)
        conn2 = pool.acquire()
        assert conn2 is conn1

    def test_context_manager(self):
        """Test using pool as context manager."""
        pool = ConnectionPool(factory=lambda: "conn", max_size=2)

        with pool.connection() as conn:
            assert conn == "conn"

        # Connection should be released back to pool
        assert len(pool._pool) == 1

    def test_close_all(self):
        """Test closing all connections."""
        closed = []

        class MockConn:
            def close(self):
                closed.append(self)

        pool = ConnectionPool(factory=MockConn, max_size=3)

        # Create and release some connections
        conns = [pool.acquire() for _ in range(3)]
        for conn in conns:
            pool.release(conn)

        pool.close_all()

        assert len(closed) == 3
        assert pool._size == 0
