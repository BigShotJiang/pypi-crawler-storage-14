"""
Comprehensive tests for the inference module.
"""

from unittest.mock import Mock

import pytest

from goquality.inference.generator import (
    LLMConfig,
    TypeInferenceGenerator,
    create_llm_client,
    extract_yaml_from_response,
)
from goquality.inference.prompt import (
    OUTPUT_FORMAT,
    SYSTEM_PROMPT,
    build_inference_prompt,
    format_database_profile,
    format_type_library,
)
from goquality.profiler.schema import (
    ColumnProfile,
    DatabaseProfile,
    TableProfile,
)
from goquality.schema.models import BaseType, TypeDefinition


class TestLLMConfig:
    """Tests for LLMConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = LLMConfig()

        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.temperature == 0.1
        assert config.max_tokens == 4096

    def test_custom_config(self):
        """Test custom configuration."""
        config = LLMConfig(
            provider="anthropic",
            model="claude-3-opus",
            temperature=0.5,
            max_tokens=8192,
        )

        assert config.provider == "anthropic"
        assert config.model == "claude-3-opus"
        assert config.temperature == 0.5
        assert config.max_tokens == 8192

    def test_from_env_openai(self, monkeypatch):
        """Test creating config from environment for OpenAI."""
        monkeypatch.setenv("OPENAI_API_KEY", "test-key")
        monkeypatch.setenv("OPENAI_MODEL", "gpt-4-turbo")

        config = LLMConfig.from_env("openai")

        assert config.provider == "openai"
        assert config.model == "gpt-4-turbo"
        assert config.api_key == "test-key"

    def test_from_env_anthropic(self, monkeypatch):
        """Test creating config from environment for Anthropic."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("ANTHROPIC_MODEL", "claude-3-haiku")

        config = LLMConfig.from_env("anthropic")

        assert config.provider == "anthropic"
        assert config.model == "claude-3-haiku"
        assert config.api_key == "test-key"

    def test_from_env_ollama(self, monkeypatch):
        """Test creating config from environment for Ollama."""
        monkeypatch.setenv("OLLAMA_MODEL", "codellama")
        monkeypatch.setenv("OLLAMA_BASE_URL", "http://custom:11434")

        config = LLMConfig.from_env("ollama")

        assert config.provider == "ollama"
        assert config.model == "codellama"
        assert config.base_url == "http://custom:11434"

    def test_from_env_unknown_provider(self):
        """Test error for unknown provider."""
        with pytest.raises(ValueError, match="Unknown provider"):
            LLMConfig.from_env("unknown")


class TestExtractYamlFromResponse:
    """Tests for extract_yaml_from_response function."""

    def test_yaml_in_code_block(self):
        """Test extracting YAML from code block."""
        response = """
Here is the generated configuration:

```yaml
types:
  - name: CustomType
    base: String
```

This is the configuration.
"""
        yaml = extract_yaml_from_response(response)

        assert "types:" in yaml
        assert "CustomType" in yaml

    def test_yaml_code_block_without_language(self):
        """Test extracting YAML from code block without language tag."""
        response = """
```
types:
  - name: Test
    base: String
```
"""
        yaml = extract_yaml_from_response(response)

        assert "types:" in yaml
        assert "Test" in yaml

    def test_multiple_code_blocks(self):
        """Test extracting largest YAML from multiple blocks."""
        response = """
Here's a small example:
```yaml
test: small
```

And here's the full config:
```yaml
types:
  - name: LargerType
    description: A type
    base: String
models:
  - table: users
    columns:
      - name: email
        type: Email
```
"""
        yaml = extract_yaml_from_response(response)

        # Should get the larger block
        assert "models:" in yaml
        assert "LargerType" in yaml

    def test_no_code_blocks(self):
        """Test when response has no code blocks."""
        response = """types:
  - name: DirectYaml
    base: String"""

        yaml = extract_yaml_from_response(response)

        assert "DirectYaml" in yaml


class TestFormatTypeLibrary:
    """Tests for format_type_library function."""

    def test_format_simple_types(self, empty_registry):
        """Test formatting a few simple types."""
        empty_registry.register(TypeDefinition(
            name="Email",
            description="Email address",
            base=BaseType.STRING,
        ))
        empty_registry.register(TypeDefinition(
            name="Age",
            description="Human age",
            base=BaseType.INTEGER,
        ))

        formatted = format_type_library(empty_registry)

        assert "Available Types" in formatted
        assert "Email" in formatted
        assert "Age" in formatted
        assert "String" in formatted
        assert "Integer" in formatted

    def test_excludes_deprecated_types(self, empty_registry):
        """Test that deprecated types are excluded."""
        empty_registry.register(TypeDefinition(
            name="OldType",
            description="Deprecated",
            base=BaseType.STRING,
            deprecated=True,
        ))
        empty_registry.register(TypeDefinition(
            name="NewType",
            description="Current",
            base=BaseType.STRING,
        ))

        formatted = format_type_library(empty_registry)

        assert "OldType" not in formatted
        assert "NewType" in formatted

    def test_truncates_long_descriptions(self, empty_registry):
        """Test that long descriptions are truncated."""
        long_desc = "x" * 100  # Very long description
        empty_registry.register(TypeDefinition(
            name="LongType",
            description=long_desc,
            base=BaseType.STRING,
        ))

        formatted = format_type_library(empty_registry)

        assert "..." in formatted
        # Original description should be truncated
        assert long_desc not in formatted


class TestFormatDatabaseProfile:
    """Tests for format_database_profile function."""

    def test_format_single_table(self):
        """Test formatting a single table profile."""
        col = ColumnProfile(
            name="email",
            db_type="VARCHAR",
            nullable=True,
            sample_values=["a@b.com", "c@d.org"],
            total_rows=100,
            null_count=5,
            distinct_count=80,
        )
        table = TableProfile(
            schema="public",
            name="users",
            columns=[col],
            row_count=100,
        )
        profile = DatabaseProfile(tables=[table])

        formatted = format_database_profile(profile)

        assert "Database Profile" in formatted
        assert "public.users" in formatted
        assert "email" in formatted
        assert "VARCHAR" in formatted
        assert "a@b.com" in formatted
        assert "80" in formatted  # distinct count

    def test_format_multiple_tables(self):
        """Test formatting multiple tables."""
        col1 = ColumnProfile(name="id", db_type="INT", nullable=False)
        col2 = ColumnProfile(name="email", db_type="VARCHAR", nullable=True)

        table1 = TableProfile(schema=None, name="users", columns=[col1, col2])
        table2 = TableProfile(schema=None, name="orders", columns=[col1])

        profile = DatabaseProfile(tables=[table1, table2])

        formatted = format_database_profile(profile)

        assert "users" in formatted
        assert "orders" in formatted

    def test_format_null_ratio_display(self):
        """Test null ratio percentage display."""
        col = ColumnProfile(
            name="email",
            db_type="VARCHAR",
            nullable=True,
            total_rows=100,
            null_count=25,
            distinct_count=50,
        )
        table = TableProfile(schema=None, name="test", columns=[col])
        profile = DatabaseProfile(tables=[table])

        formatted = format_database_profile(profile)

        assert "25.0%" in formatted


class TestBuildInferencePrompt:
    """Tests for build_inference_prompt function."""

    def test_returns_system_and_user_prompts(self, stdlib_registry):
        """Test that it returns both prompts."""
        col = ColumnProfile(name="email", db_type="VARCHAR", nullable=True)
        table = TableProfile(schema=None, name="users", columns=[col])
        profile = DatabaseProfile(tables=[table])

        system, user = build_inference_prompt(stdlib_registry, profile)

        assert len(system) > 0
        assert len(user) > 0
        assert "data governance" in system.lower()

    def test_user_prompt_contains_library(self, stdlib_registry):
        """Test that user prompt contains type library."""
        profile = DatabaseProfile(tables=[])

        _, user = build_inference_prompt(stdlib_registry, profile)

        assert "Available Types" in user
        assert "Email" in user  # Should have Email from stdlib

    def test_user_prompt_contains_format(self, stdlib_registry):
        """Test that user prompt contains output format."""
        profile = DatabaseProfile(tables=[])

        _, user = build_inference_prompt(stdlib_registry, profile)

        assert "Output Format" in user
        assert "yaml" in user.lower()


class TestTypeInferenceGenerator:
    """Tests for TypeInferenceGenerator."""

    def test_generator_initialization(self):
        """Test generator initialization with config."""
        config = LLMConfig(provider="ollama", base_url="http://localhost:11434")

        # Use Ollama which doesn't require API key
        gen = TypeInferenceGenerator(config)
        assert gen.config == config

    def test_generate_calls_client(self, stdlib_registry):
        """Test that generate calls the LLM client."""
        mock_client = Mock()
        mock_client.generate.return_value = """
```yaml
types: []
models:
  - table: users
    columns:
      - name: email
        type: Email
        confidence: high
```
"""

        gen = TypeInferenceGenerator.__new__(TypeInferenceGenerator)
        gen.client = mock_client
        gen.config = LLMConfig()

        col = ColumnProfile(name="email", db_type="VARCHAR", nullable=True)
        table = TableProfile(schema=None, name="users", columns=[col])
        profile = DatabaseProfile(tables=[table])

        result = gen.generate(stdlib_registry, profile)

        mock_client.generate.assert_called_once()
        assert "models:" in result


class TestCreateLLMClient:
    """Tests for create_llm_client factory."""

    def test_create_openai_client(self):
        """Test creating OpenAI client."""
        # OpenAI is already installed as a dependency
        config = LLMConfig(provider="openai", api_key="test-key")
        from goquality.inference.generator import OpenAIClient
        client = create_llm_client(config)
        assert isinstance(client, OpenAIClient)

    def test_create_anthropic_client(self):
        """Test creating Anthropic client."""
        # Anthropic is already installed as a dependency
        config = LLMConfig(provider="anthropic", api_key="test-key")
        from goquality.inference.generator import AnthropicClient
        client = create_llm_client(config)
        assert isinstance(client, AnthropicClient)

    def test_create_ollama_client(self):
        """Test creating Ollama client."""
        config = LLMConfig(provider="ollama", base_url="http://localhost:11434")
        from goquality.inference.generator import OllamaClient
        client = create_llm_client(config)
        assert isinstance(client, OllamaClient)

    def test_unknown_provider_raises(self):
        """Test that unknown provider raises error."""
        config = LLMConfig(provider="unknown")

        with pytest.raises(ValueError, match="Unknown provider"):
            create_llm_client(config)


class TestSystemPrompt:
    """Tests for the system prompt content."""

    def test_contains_key_instructions(self):
        """Test that system prompt contains key instructions."""
        assert "data governance" in SYSTEM_PROMPT.lower()
        assert "semantic types" in SYSTEM_PROMPT.lower()
        assert "library" in SYSTEM_PROMPT.lower()
        assert "confidence" in SYSTEM_PROMPT.lower()

    def test_mentions_enum_creation(self):
        """Test that system prompt mentions enum type creation."""
        assert "enum" in SYSTEM_PROMPT.lower()
        assert "low-cardinality" in SYSTEM_PROMPT.lower() or "<20 distinct" in SYSTEM_PROMPT


class TestOutputFormat:
    """Tests for the output format specification."""

    def test_format_contains_structure(self):
        """Test that format contains expected YAML structure."""
        assert "types:" in OUTPUT_FORMAT
        assert "models:" in OUTPUT_FORMAT
        assert "columns:" in OUTPUT_FORMAT
        assert "confidence:" in OUTPUT_FORMAT

    def test_format_has_examples(self):
        """Test that format has example values."""
        assert "table:" in OUTPUT_FORMAT
        assert "name:" in OUTPUT_FORMAT
        assert "type:" in OUTPUT_FORMAT
