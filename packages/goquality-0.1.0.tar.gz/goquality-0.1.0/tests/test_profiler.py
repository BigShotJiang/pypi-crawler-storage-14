"""
Comprehensive tests for the database profiler.

Uses DuckDB for fast in-memory testing.
"""

import ibis
import pandas as pd

from goquality.profiler.schema import (
    ColumnProfile,
    DatabaseProfile,
    TableProfile,
    profile_column,
    profile_database,
    profile_table,
)


class TestColumnProfile:
    """Tests for ColumnProfile data class."""

    def test_basic_column_profile(self):
        """Test creating a basic column profile."""
        profile = ColumnProfile(
            name="email",
            db_type="VARCHAR",
            nullable=True,
            sample_values=["a@b.com", "c@d.org"],
            total_rows=100,
            null_count=5,
            distinct_count=80,
        )

        assert profile.name == "email"
        assert profile.db_type == "VARCHAR"
        assert profile.nullable is True
        assert len(profile.sample_values) == 2

    def test_null_ratio(self):
        """Test null ratio calculation."""
        profile = ColumnProfile(
            name="col",
            db_type="VARCHAR",
            nullable=True,
            total_rows=100,
            null_count=25,
            distinct_count=10,
        )

        assert profile.null_ratio == 0.25

    def test_null_ratio_empty_table(self):
        """Test null ratio with empty table."""
        profile = ColumnProfile(
            name="col",
            db_type="VARCHAR",
            nullable=True,
            total_rows=0,
            null_count=0,
            distinct_count=0,
        )

        assert profile.null_ratio == 0.0

    def test_is_low_cardinality_true(self):
        """Test low cardinality detection (enum-like)."""
        profile = ColumnProfile(
            name="status",
            db_type="VARCHAR",
            nullable=False,
            total_rows=1000,
            null_count=0,
            distinct_count=5,
        )

        assert profile.is_low_cardinality is True

    def test_is_low_cardinality_false(self):
        """Test high cardinality detection."""
        profile = ColumnProfile(
            name="email",
            db_type="VARCHAR",
            nullable=False,
            total_rows=1000,
            null_count=0,
            distinct_count=950,
        )

        assert profile.is_low_cardinality is False

    def test_is_low_cardinality_boundary(self):
        """Test boundary of low cardinality (exactly 20 is not low)."""
        profile = ColumnProfile(
            name="col",
            db_type="VARCHAR",
            nullable=False,
            distinct_count=20,
        )

        assert profile.is_low_cardinality is False

        profile.distinct_count = 19
        assert profile.is_low_cardinality is True

    def test_to_dict(self):
        """Test conversion to dictionary."""
        profile = ColumnProfile(
            name="amount",
            db_type="DECIMAL",
            nullable=False,
            sample_values=[100.5, 200.0, 300.25],
            total_rows=1000,
            null_count=0,
            distinct_count=500,
            min_value=0.01,
            max_value=99999.99,
        )

        d = profile.to_dict()

        assert d["name"] == "amount"
        assert d["db_type"] == "DECIMAL"
        assert d["min_value"] == 0.01
        assert d["max_value"] == 99999.99
        assert d["null_ratio"] == 0.0
        assert len(d["sample_values"]) == 3

    def test_to_dict_limits_samples(self):
        """Test that to_dict limits sample values to 10."""
        profile = ColumnProfile(
            name="col",
            db_type="VARCHAR",
            nullable=True,
            sample_values=list(range(20)),
        )

        d = profile.to_dict()
        assert len(d["sample_values"]) == 10


class TestTableProfile:
    """Tests for TableProfile data class."""

    def test_basic_table_profile(self):
        """Test creating a basic table profile."""
        col1 = ColumnProfile(name="id", db_type="INTEGER", nullable=False)
        col2 = ColumnProfile(name="name", db_type="VARCHAR", nullable=True)

        profile = TableProfile(
            schema="public",
            name="users",
            columns=[col1, col2],
            row_count=1000,
        )

        assert profile.schema == "public"
        assert profile.name == "users"
        assert profile.full_name == "public.users"
        assert len(profile.columns) == 2
        assert profile.row_count == 1000

    def test_full_name_no_schema(self):
        """Test full name without schema."""
        profile = TableProfile(
            schema=None,
            name="users",
            columns=[],
            row_count=100,
        )

        assert profile.full_name == "users"

    def test_to_dict(self):
        """Test conversion to dictionary."""
        col1 = ColumnProfile(name="id", db_type="INTEGER", nullable=False)
        profile = TableProfile(
            schema="public",
            name="users",
            columns=[col1],
            row_count=100,
        )

        d = profile.to_dict()

        assert d["table"] == "public.users"
        assert d["row_count"] == 100
        assert len(d["columns"]) == 1
        assert d["columns"][0]["name"] == "id"


class TestDatabaseProfile:
    """Tests for DatabaseProfile data class."""

    def test_basic_database_profile(self):
        """Test creating a basic database profile."""
        table1 = TableProfile(
            schema=None,
            name="users",
            columns=[ColumnProfile(name="id", db_type="INT", nullable=False)],
        )
        table2 = TableProfile(
            schema=None,
            name="orders",
            columns=[
                ColumnProfile(name="id", db_type="INT", nullable=False),
                ColumnProfile(name="amount", db_type="DECIMAL", nullable=False),
            ],
        )

        profile = DatabaseProfile(tables=[table1, table2])

        assert profile.total_tables == 2
        assert profile.total_columns == 3

    def test_empty_database(self):
        """Test empty database profile."""
        profile = DatabaseProfile()

        assert profile.total_tables == 0
        assert profile.total_columns == 0

    def test_to_dict(self):
        """Test conversion to dictionary."""
        table1 = TableProfile(
            schema=None,
            name="users",
            columns=[ColumnProfile(name="id", db_type="INT", nullable=False)],
        )
        profile = DatabaseProfile(tables=[table1])

        d = profile.to_dict()

        assert d["total_tables"] == 1
        assert d["total_columns"] == 1
        assert len(d["tables"]) == 1


class TestProfileColumn:
    """Tests for profile_column function."""

    def test_profile_string_column(self):
        """Test profiling a string column."""
        conn = ibis.duckdb.connect()
        df = pd.DataFrame({
            "email": ["a@b.com", "c@d.org", None, "long-email@domain.co.uk"]
        })
        table = ibis.memtable(df)

        profile = profile_column(
            connection=conn,
            table=table,
            column_name="email",
            column_type="VARCHAR",
            is_nullable=True,
        )

        assert profile.name == "email"
        assert profile.total_rows == 4
        assert profile.null_count == 1
        assert profile.distinct_count == 3
        assert profile.min_length is not None
        assert profile.max_length is not None

    def test_profile_numeric_column(self):
        """Test profiling a numeric column."""
        conn = ibis.duckdb.connect()
        df = pd.DataFrame({
            "amount": [100.5, 200.0, -50.25, 1000.0, None]
        })
        table = ibis.memtable(df)

        profile = profile_column(
            connection=conn,
            table=table,
            column_name="amount",
            column_type="DECIMAL",
            is_nullable=True,
        )

        assert profile.name == "amount"
        assert profile.total_rows == 5
        assert profile.null_count == 1
        assert profile.min_value == -50.25
        assert profile.max_value == 1000.0

    def test_profile_integer_column(self):
        """Test profiling an integer column."""
        conn = ibis.duckdb.connect()
        df = pd.DataFrame({
            "count": [1, 5, 10, 100, 1000]
        })
        table = ibis.memtable(df)

        profile = profile_column(
            connection=conn,
            table=table,
            column_name="count",
            column_type="INTEGER",
            is_nullable=False,
        )

        assert profile.min_value == 1
        assert profile.max_value == 1000

    def test_profile_sample_size(self):
        """Test sample size limitation."""
        conn = ibis.duckdb.connect()
        df = pd.DataFrame({
            "value": list(range(100))  # 100 distinct values
        })
        table = ibis.memtable(df)

        profile = profile_column(
            connection=conn,
            table=table,
            column_name="value",
            column_type="INTEGER",
            is_nullable=False,
            sample_size=5,
        )

        assert len(profile.sample_values) <= 5

    def test_profile_low_cardinality(self):
        """Test profiling a low-cardinality column."""
        conn = ibis.duckdb.connect()
        df = pd.DataFrame({
            "status": ["active", "pending", "inactive"] * 100
        })
        table = ibis.memtable(df)

        profile = profile_column(
            connection=conn,
            table=table,
            column_name="status",
            column_type="VARCHAR",
            is_nullable=False,
        )

        assert profile.distinct_count == 3
        assert profile.is_low_cardinality is True


class TestProfileTable:
    """Tests for profile_table function with DuckDB."""

    def test_profile_simple_table(self, duckdb_conn):
        """Test profiling a simple table."""
        # Create a table in DuckDB
        duckdb_conn.raw_sql("""
            CREATE TABLE users AS
            SELECT * FROM (VALUES
                ('alice@example.com', 'active', 25),
                ('bob@test.org', 'pending', 30),
                (NULL, 'inactive', NULL)
            ) AS t(email, status, age)
        """)

        profile = profile_table(
            connection=duckdb_conn,
            table_name="users",
        )

        assert profile.name == "users"
        assert profile.row_count == 3
        assert len(profile.columns) == 3

        # Check column profiles
        email_col = next(c for c in profile.columns if c.name == "email")
        assert email_col.null_count == 1

        status_col = next(c for c in profile.columns if c.name == "status")
        assert status_col.distinct_count == 3
        assert status_col.is_low_cardinality is True


class TestProfileDatabase:
    """Tests for profile_database function."""

    def test_profile_multiple_tables(self, duckdb_conn):
        """Test profiling multiple tables."""
        # Create multiple tables
        duckdb_conn.raw_sql("""
            CREATE TABLE users AS
            SELECT * FROM (VALUES
                (1, 'alice@example.com'),
                (2, 'bob@test.org')
            ) AS t(id, email)
        """)

        duckdb_conn.raw_sql("""
            CREATE TABLE orders AS
            SELECT * FROM (VALUES
                (1, 100.50, 'USD'),
                (2, 200.00, 'EUR')
            ) AS t(user_id, amount, currency)
        """)

        profile = profile_database(
            connection=duckdb_conn,
        )

        assert profile.total_tables == 2
        # users: id, email (2) + orders: user_id, amount, currency (3) = 5
        assert profile.total_columns == 5

        table_names = [t.name for t in profile.tables]
        assert "users" in table_names
        assert "orders" in table_names

    def test_profile_include_tables(self, duckdb_conn):
        """Test filtering tables with include_tables."""
        duckdb_conn.raw_sql("CREATE TABLE users AS SELECT 1 as id")
        duckdb_conn.raw_sql("CREATE TABLE orders AS SELECT 1 as id")
        duckdb_conn.raw_sql("CREATE TABLE internal AS SELECT 1 as id")

        profile = profile_database(
            connection=duckdb_conn,
            include_tables=["users", "orders"],
        )

        assert profile.total_tables == 2
        table_names = [t.name for t in profile.tables]
        assert "users" in table_names
        assert "orders" in table_names
        assert "internal" not in table_names

    def test_profile_exclude_tables(self, duckdb_conn):
        """Test filtering tables with exclude_tables."""
        duckdb_conn.raw_sql("CREATE TABLE users AS SELECT 1 as id")
        duckdb_conn.raw_sql("CREATE TABLE orders AS SELECT 1 as id")
        duckdb_conn.raw_sql("CREATE TABLE internal AS SELECT 1 as id")

        profile = profile_database(
            connection=duckdb_conn,
            exclude_tables=["internal"],
        )

        assert profile.total_tables == 2
        table_names = [t.name for t in profile.tables]
        assert "users" in table_names
        assert "orders" in table_names
        assert "internal" not in table_names


class TestProfilerWithSampleData:
    """Integration tests with sample test data."""

    def test_profile_users_sample(self, sample_users_data):
        """Test profiling the sample users data."""
        conn = ibis.duckdb.connect()
        table = ibis.memtable(sample_users_data)

        # Profile email column
        email_profile = profile_column(
            connection=conn,
            table=table,
            column_name="email",
            column_type="VARCHAR",
            is_nullable=True,
        )

        assert email_profile.total_rows == 7
        assert email_profile.null_count == 1
        assert len(email_profile.sample_values) <= 10

    def test_profile_orders_sample(self, sample_orders_data):
        """Test profiling the sample orders data."""
        conn = ibis.duckdb.connect()
        table = ibis.memtable(sample_orders_data)

        # Profile amount column
        amount_profile = profile_column(
            connection=conn,
            table=table,
            column_name="amount",
            column_type="DECIMAL",
            is_nullable=False,
        )

        assert amount_profile.min_value == -25.0
        assert amount_profile.max_value == 1000.5

        # Profile currency column (low cardinality)
        currency_profile = profile_column(
            connection=conn,
            table=table,
            column_name="currency",
            column_type="VARCHAR",
            is_nullable=False,
        )

        assert currency_profile.is_low_cardinality is True
        assert currency_profile.distinct_count == 4
