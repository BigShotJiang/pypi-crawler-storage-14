"""
Tests for the plugin system.
"""

import pytest

from goquality.plugins import (
    PluginManager,
    PluginType,
    PythonValidator,
    SQLValidator,
    ValidatorRegistry,
)
from goquality.plugins.builtin import (
    ean13_checksum,
    iban_checksum,
    is_base64,
    is_json,
    is_valid_email_mx,
    is_valid_ipv4,
    is_valid_ipv6,
    is_valid_mac_address,
    isbn10_checksum,
    isbn13_checksum,
    luhn_checksum,
    upc_checksum,
)


class TestLuhnChecksum:
    """Tests for Luhn algorithm validator."""

    def test_valid_credit_card(self):
        """Test valid credit card numbers."""
        # Test cards (not real)
        assert luhn_checksum("4532015112830366") is True
        assert luhn_checksum("4716347184862961") is True

    def test_invalid_credit_card(self):
        """Test invalid credit card numbers."""
        assert luhn_checksum("4532015112830367") is False
        assert luhn_checksum("1234567890123456") is False

    def test_with_spaces(self):
        """Test numbers with spaces."""
        assert luhn_checksum("4532 0151 1283 0366") is True

    def test_with_dashes(self):
        """Test numbers with dashes."""
        assert luhn_checksum("4532-0151-1283-0366") is True

    def test_null_value(self):
        """Test null value passes."""
        assert luhn_checksum(None) is True

    def test_invalid_characters(self):
        """Test non-digit characters fail."""
        assert luhn_checksum("ABCD1234") is False

    def test_too_short(self):
        """Test too short values fail."""
        assert luhn_checksum("1") is False


class TestIBANChecksum:
    """Tests for IBAN validator."""

    def test_valid_german_iban(self):
        """Test valid German IBAN."""
        assert iban_checksum("DE89370400440532013000") is True

    def test_valid_uk_iban(self):
        """Test valid UK IBAN."""
        assert iban_checksum("GB82WEST12345698765432") is True

    def test_invalid_iban(self):
        """Test invalid IBAN."""
        assert iban_checksum("DE89370400440532013001") is False

    def test_iban_with_spaces(self):
        """Test IBAN with spaces."""
        assert iban_checksum("DE89 3704 0044 0532 0130 00") is True

    def test_null_value(self):
        """Test null value passes."""
        assert iban_checksum(None) is True

    def test_too_short(self):
        """Test too short IBAN."""
        assert iban_checksum("DE89") is False

    def test_wrong_format(self):
        """Test wrong format IBAN."""
        assert iban_checksum("1234567890123456789") is False


class TestISBNChecksum:
    """Tests for ISBN validators."""

    def test_valid_isbn10(self):
        """Test valid ISBN-10."""
        assert isbn10_checksum("0306406152") is True
        assert isbn10_checksum("080442957X") is True  # X check digit

    def test_invalid_isbn10(self):
        """Test invalid ISBN-10."""
        assert isbn10_checksum("0306406153") is False

    def test_isbn10_with_dashes(self):
        """Test ISBN-10 with dashes."""
        assert isbn10_checksum("0-306-40615-2") is True

    def test_valid_isbn13(self):
        """Test valid ISBN-13."""
        assert isbn13_checksum("9780306406157") is True
        assert isbn13_checksum("9780140449136") is True

    def test_invalid_isbn13(self):
        """Test invalid ISBN-13."""
        assert isbn13_checksum("9780306406158") is False

    def test_isbn13_must_start_with_978_or_979(self):
        """Test ISBN-13 prefix."""
        assert isbn13_checksum("1234567890123") is False


class TestEAN13Checksum:
    """Tests for EAN-13 validator."""

    def test_valid_ean13(self):
        """Test valid EAN-13."""
        assert ean13_checksum("4006381333931") is True

    def test_invalid_ean13(self):
        """Test invalid EAN-13."""
        assert ean13_checksum("4006381333932") is False

    def test_null_value(self):
        """Test null value passes."""
        assert ean13_checksum(None) is True


class TestUPCChecksum:
    """Tests for UPC-A validator."""

    def test_valid_upc(self):
        """Test valid UPC-A."""
        assert upc_checksum("012345678905") is True

    def test_invalid_upc(self):
        """Test invalid UPC-A."""
        assert upc_checksum("012345678906") is False


class TestEmailFormat:
    """Tests for email format validator."""

    def test_valid_email(self):
        """Test valid email addresses."""
        assert is_valid_email_mx("user@example.com") is True
        assert is_valid_email_mx("user.name@example.co.uk") is True

    def test_invalid_email(self):
        """Test invalid email addresses."""
        assert is_valid_email_mx("not-an-email") is False
        assert is_valid_email_mx("user@") is False
        assert is_valid_email_mx("@example.com") is False

    def test_consecutive_dots(self):
        """Test email with consecutive dots."""
        assert is_valid_email_mx("user..name@example.com") is False


class TestIPValidators:
    """Tests for IP address validators."""

    def test_valid_ipv4(self):
        """Test valid IPv4 addresses."""
        assert is_valid_ipv4("192.168.1.1") is True
        assert is_valid_ipv4("0.0.0.0") is True
        assert is_valid_ipv4("255.255.255.255") is True

    def test_invalid_ipv4(self):
        """Test invalid IPv4 addresses."""
        assert is_valid_ipv4("256.1.1.1") is False
        assert is_valid_ipv4("1.2.3") is False
        assert is_valid_ipv4("192.168.1.01") is False  # Leading zero

    def test_valid_ipv6(self):
        """Test valid IPv6 addresses."""
        assert is_valid_ipv6("2001:0db8:85a3:0000:0000:8a2e:0370:7334") is True
        assert is_valid_ipv6("::1") is True
        assert is_valid_ipv6("::") is True

    def test_invalid_ipv6(self):
        """Test invalid IPv6 addresses."""
        assert is_valid_ipv6("not-an-ip") is False


class TestMACAddress:
    """Tests for MAC address validator."""

    def test_valid_mac_colon(self):
        """Test valid MAC with colons."""
        assert is_valid_mac_address("00:1A:2B:3C:4D:5E") is True

    def test_valid_mac_dash(self):
        """Test valid MAC with dashes."""
        assert is_valid_mac_address("00-1A-2B-3C-4D-5E") is True

    def test_valid_mac_compact(self):
        """Test valid MAC without separators."""
        assert is_valid_mac_address("001A2B3C4D5E") is True

    def test_invalid_mac(self):
        """Test invalid MAC addresses."""
        assert is_valid_mac_address("00:1A:2B:3C:4D") is False
        assert is_valid_mac_address("GHIJ12345678") is False


class TestJSONValidator:
    """Tests for JSON validator."""

    def test_valid_json(self):
        """Test valid JSON strings."""
        assert is_json('{"key": "value"}') is True
        assert is_json('[1, 2, 3]') is True
        assert is_json('"string"') is True

    def test_invalid_json(self):
        """Test invalid JSON strings."""
        assert is_json('{key: value}') is False
        assert is_json('not json') is False


class TestBase64Validator:
    """Tests for Base64 validator."""

    def test_valid_base64(self):
        """Test valid Base64 strings."""
        assert is_base64("SGVsbG8gV29ybGQ=") is True
        assert is_base64("dGVzdA==") is True

    def test_invalid_base64(self):
        """Test invalid Base64 strings."""
        assert is_base64("!!!invalid!!!") is False


class TestPythonValidator:
    """Tests for PythonValidator class."""

    def test_create_validator(self):
        """Test creating a Python validator."""
        def is_even(value: int) -> bool:
            return value % 2 == 0

        validator = PythonValidator(
            name="is_even",
            validate_func=is_even,
            description="Check if number is even",
        )

        assert validator.name == "is_even"
        assert validator.validate(4) is True
        assert validator.validate(3) is False

    def test_null_value_passes(self):
        """Test that null values pass by default."""
        def always_fail(value):
            return False

        validator = PythonValidator(
            name="always_fail",
            validate_func=always_fail,
            description="Always fails",
        )

        assert validator.validate(None) is True

    def test_exception_returns_false(self):
        """Test that exceptions in validator return False."""
        def raise_error(value):
            raise ValueError("Test error")

        validator = PythonValidator(
            name="raise_error",
            validate_func=raise_error,
            description="Always raises",
        )

        assert validator.validate("test") is False


class TestSQLValidator:
    """Tests for SQLValidator class."""

    def test_create_validator(self):
        """Test creating a SQL validator."""
        validator = SQLValidator(
            name="positive",
            sql_template="{column} > 0",
            description="Value must be positive",
        )

        assert validator.name == "positive"
        assert validator.supports_sql is True

    def test_python_fallback(self):
        """Test SQL validator with Python fallback."""
        validator = SQLValidator(
            name="positive",
            sql_template="{column} > 0",
            python_fallback=lambda x: x > 0,
        )

        assert validator.validate(5) is True
        assert validator.validate(-1) is False

    def test_no_fallback_raises(self):
        """Test SQL-only validator raises for Python validation."""
        validator = SQLValidator(
            name="sql_only",
            sql_template="{column} IS NOT NULL",
        )

        with pytest.raises(NotImplementedError):
            validator.validate("test")


class TestValidatorRegistry:
    """Tests for ValidatorRegistry class."""

    def test_register_and_get(self):
        """Test registering and getting validators."""
        registry = ValidatorRegistry()

        validator = PythonValidator(
            name="test_validator",
            validate_func=lambda x: True,
            description="Test",
        )
        registry.register(validator)

        retrieved = registry.get("test_validator")
        assert retrieved is not None
        assert retrieved.name == "test_validator"

    def test_list_validators(self):
        """Test listing validators."""
        registry = ValidatorRegistry()

        registry.register(PythonValidator(
            name="v1",
            validate_func=lambda x: True,
            description="V1",
        ))
        registry.register(PythonValidator(
            name="v2",
            validate_func=lambda x: True,
            description="V2",
        ))

        validators = registry.list()
        assert "v1" in validators
        assert "v2" in validators

    def test_validate_method(self):
        """Test validate method."""
        registry = ValidatorRegistry()

        registry.register(PythonValidator(
            name="is_positive",
            validate_func=lambda x: x > 0,
            description="Positive",
        ))

        assert registry.validate("is_positive", 5) is True
        assert registry.validate("is_positive", -1) is False

    def test_validate_unknown_raises(self):
        """Test validating with unknown validator raises."""
        registry = ValidatorRegistry()

        with pytest.raises(ValueError, match="Unknown validator"):
            registry.validate("unknown", "value")


class TestPluginManager:
    """Tests for PluginManager class."""

    def test_register_plugin(self):
        """Test registering a plugin."""
        manager = PluginManager()

        validator = PythonValidator(
            name="test",
            validate_func=lambda x: True,
            description="Test",
        )
        manager.register(validator)

        assert "test" in manager.list_validators()

    def test_register_duplicate_raises(self):
        """Test registering duplicate plugin raises."""
        manager = PluginManager()

        validator = PythonValidator(
            name="dup",
            validate_func=lambda x: True,
            description="Dup",
        )
        manager.register(validator)

        with pytest.raises(ValueError, match="already registered"):
            manager.register(validator)

    def test_unregister_plugin(self):
        """Test unregistering a plugin."""
        manager = PluginManager()

        validator = PythonValidator(
            name="removable",
            validate_func=lambda x: True,
            description="Removable",
        )
        manager.register(validator)
        assert "removable" in manager.list_validators()

        result = manager.unregister("removable")
        assert result is True
        assert "removable" not in manager.list_validators()

    def test_unregister_nonexistent(self):
        """Test unregistering nonexistent plugin."""
        manager = PluginManager()
        result = manager.unregister("nonexistent")
        assert result is False

    def test_get_validator(self):
        """Test getting validator from manager."""
        manager = PluginManager()

        validator = PythonValidator(
            name="getter_test",
            validate_func=lambda x: True,
            description="Test",
        )
        manager.register(validator)

        retrieved = manager.get_validator("getter_test")
        assert retrieved is not None

    def test_list_plugins_by_type(self):
        """Test listing plugins by type."""
        manager = PluginManager()

        validator = PythonValidator(
            name="validator_plugin",
            validate_func=lambda x: True,
            description="Test",
        )
        manager.register(validator)

        validators = manager.list_plugins(PluginType.VALIDATOR)
        assert "validator_plugin" in validators

    def test_hooks(self):
        """Test hook system."""
        manager = PluginManager()
        results = []

        def hook_callback(value):
            results.append(value)
            return value * 2

        manager.register_hook("test_hook", hook_callback)

        hook_results = manager.call_hook("test_hook", 5)
        assert results == [5]
        assert hook_results == [10]
