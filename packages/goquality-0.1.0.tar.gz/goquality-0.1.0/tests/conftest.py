"""
Pytest configuration and fixtures for GoQuality tests.

Uses DuckDB (via Ibis) for fast, in-memory testing.
"""

from pathlib import Path
from typing import Generator

import ibis
import pandas as pd
import pytest

from goquality.schema import GoQualityConfig, TypeRegistry, load_stdlib
from goquality.schema.models import BaseType, ColumnMapping, ModelMapping, TypeDefinition

# ============================================================
# DATABASE FIXTURES
# ============================================================

@pytest.fixture
def duckdb_conn() -> Generator[ibis.BaseBackend, None, None]:
    """Create an in-memory DuckDB connection."""
    conn = ibis.duckdb.connect()
    yield conn


@pytest.fixture
def sample_users_data() -> pd.DataFrame:
    """Sample users table with mix of valid/invalid data."""
    return pd.DataFrame({
        # Valid and invalid emails
        "email": [
            "alice@example.com",
            "bob@test.org",
            "invalid-email",
            None,
            "charlie@acme.com",
            "",
            "user@domain.co.uk",
        ],
        # Valid and invalid UUIDs
        "id": [
            "550e8400-e29b-41d4-a716-446655440000",
            "invalid-uuid",
            "123e4567-e89b-12d3-a456-426614174000",
            None,
            "not-a-uuid",
            "550e8400-e29b-41d4-a716-446655440001",
            "550e8400-e29b-41d4-a716-446655440002",
        ],
        # Status enum
        "status": [
            "active",
            "pending",
            "inactive",
            "INVALID",
            "active",
            None,
            "pending",
        ],
        # Age (should be 0-150)
        "age": [25, 30, -5, 200, 45, None, 0],
        # Created timestamp
        "created_at": [
            "2024-01-15",
            "2024-02-20",
            "invalid-date",
            None,
            "2024-03-10",
            "2023-12-01",
            "2024-01-01",
        ],
    })


@pytest.fixture
def sample_orders_data() -> pd.DataFrame:
    """Sample orders table with financial data."""
    return pd.DataFrame({
        "order_id": [
            "ORD-001",
            "ORD-002",
            "ORD-003",
            "ORD-004",
            "ORD-005",
        ],
        # Amount (should be positive)
        "amount": [99.99, 150.00, -25.00, 0.00, 1000.50],
        # Discount percentage (0-100)
        "discount_pct": [10.0, 0.0, 50.0, 110.0, -5.0],
        # Currency code
        "currency": ["USD", "EUR", "GBP", "INVALID", "USD"],
        # Country code
        "country": ["US", "DE", "GB", "XX", "CA"],
    })


@pytest.fixture
def sample_contacts_data() -> pd.DataFrame:
    """Sample contacts with phone/address data."""
    return pd.DataFrame({
        "phone": [
            "+14155551234",
            "415-555-1234",
            "invalid",
            None,
            "+442071234567",
        ],
        "zip_code": [
            "94102",
            "10001",
            "1234",  # Too short
            "123456",  # Too long
            "90210",
        ],
        "state": ["CA", "NY", "XX", "TX", "FL"],
        "country": ["US", "US", "US", "US", "US"],
    })


@pytest.fixture
def users_table(sample_users_data: pd.DataFrame) -> ibis.expr.types.Table:
    """Ibis table from sample users data."""
    return ibis.memtable(sample_users_data)


@pytest.fixture
def orders_table(sample_orders_data: pd.DataFrame) -> ibis.expr.types.Table:
    """Ibis table from sample orders data."""
    return ibis.memtable(sample_orders_data)


@pytest.fixture
def contacts_table(sample_contacts_data: pd.DataFrame) -> ibis.expr.types.Table:
    """Ibis table from sample contacts data."""
    return ibis.memtable(sample_contacts_data)


# ============================================================
# TYPE REGISTRY FIXTURES
# ============================================================

@pytest.fixture
def empty_registry() -> TypeRegistry:
    """Empty type registry."""
    return TypeRegistry()


@pytest.fixture
def stdlib_registry() -> TypeRegistry:
    """Type registry with stdlib loaded."""
    registry = TypeRegistry()
    load_stdlib(registry)
    return registry


@pytest.fixture
def custom_types() -> list[TypeDefinition]:
    """Custom type definitions for testing."""
    return [
        TypeDefinition(
            name="UserStatus",
            description="User account status",
            base=BaseType.STRING,
            enum=["active", "pending", "inactive", "deleted"],
        ),
        TypeDefinition(
            name="OrderAmount",
            description="Order amount in USD",
            base=BaseType.DECIMAL,
            min=0.01,
            max=100000.00,
            precision=2,
        ),
        TypeDefinition(
            name="AcmeEmail",
            description="Email at acme.com domain",
            base=BaseType.STRING,
            extends="Email",
            pattern=r"^[a-zA-Z0-9._%+-]+@acme\.com$",
        ),
    ]


@pytest.fixture
def registry_with_custom(
    stdlib_registry: TypeRegistry, custom_types: list[TypeDefinition]
) -> TypeRegistry:
    """Registry with stdlib + custom types."""
    stdlib_registry.register_types(custom_types)
    return stdlib_registry


# ============================================================
# CONFIGURATION FIXTURES
# ============================================================

@pytest.fixture
def sample_config(custom_types: list[TypeDefinition]) -> GoQualityConfig:
    """Sample GoQuality configuration."""
    return GoQualityConfig(
        types=custom_types,
        models=[
            ModelMapping(
                table="users",
                columns=[
                    ColumnMapping(name="email", type="Email"),
                    ColumnMapping(name="id", type="UUID"),
                    ColumnMapping(name="status", type="UserStatus"),
                    ColumnMapping(name="age", type="Age"),
                ],
            ),
            ModelMapping(
                table="orders",
                columns=[
                    ColumnMapping(name="order_id", type="OrderId"),
                    ColumnMapping(name="amount", type="OrderAmount"),
                    ColumnMapping(name="discount_pct", type="Percentage"),
                    ColumnMapping(name="currency", type="CurrencyCodeISO"),
                    ColumnMapping(name="country", type="CountryISO2"),
                ],
            ),
        ],
    )


# ============================================================
# FILE FIXTURES
# ============================================================

@pytest.fixture
def temp_config_file(tmp_path: Path, sample_config: GoQualityConfig) -> Path:
    """Write sample config to temp file."""
    import yaml

    config_path = tmp_path / "goquality.yaml"

    # Convert to dict for YAML serialization
    config_dict = {
        "types": [
            {
                "name": t.name,
                "description": t.description,
                "base": t.base.value,
                **({"extends": t.extends} if t.extends else {}),
                **({"pattern": t.pattern} if t.pattern else {}),
                **({"min": t.min} if t.min is not None else {}),
                **({"max": t.max} if t.max is not None else {}),
                **({"precision": t.precision} if t.precision is not None else {}),
                **({"enum": t.enum} if t.enum else {}),
            }
            for t in sample_config.types
        ],
        "models": [
            {
                "table": m.table,
                "columns": [
                    {"name": c.name, "type": c.type}
                    for c in m.columns
                ],
            }
            for m in sample_config.models
        ],
    }

    with open(config_path, "w") as f:
        yaml.dump(config_dict, f)

    return config_path


@pytest.fixture
def temp_csv_file(tmp_path: Path, sample_users_data: pd.DataFrame) -> Path:
    """Write sample data to CSV for DuckDB testing."""
    csv_path = tmp_path / "users.csv"
    sample_users_data.to_csv(csv_path, index=False)
    return csv_path
