"""
Comprehensive tests for the compiler and validation rules.

Uses DuckDB (via ibis.memtable) for fast in-memory testing.
"""

import ibis

from goquality.compiler.builder import QueryBuilder, ValidationResult
from goquality.compiler.rules import (
    EnumRule,
    MaxLengthRule,
    MaxRule,
    MinLengthRule,
    MinRule,
    NullableRule,
    PatternRule,
    compose_rules,
    rules_from_resolved_type,
)
from goquality.schema.models import BaseType, ColumnMapping, ModelMapping
from goquality.schema.registry import ResolvedType


class TestPatternRule:
    """Tests for PatternRule."""

    def test_email_pattern(self):
        """Test email pattern matching."""
        table = ibis.memtable({
            "email": ["test@example.com", "invalid", "user@test.org", None]
        })

        rule = PatternRule(r"^.+@.+\..+$")
        result = table.select(
            table["email"],
            rule.compile(table["email"]).name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # test@example.com
        assert not result.iloc[1]["is_valid"]  # invalid
        assert result.iloc[2]["is_valid"]  # user@test.org

    def test_uuid_pattern(self):
        """Test UUID pattern matching."""
        table = ibis.memtable({
            "id": [
                "550e8400-e29b-41d4-a716-446655440000",
                "not-a-uuid",
                "550e8400-e29b-41d4-a716-44665544000",  # Too short
            ]
        })

        rule = PatternRule(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
        result = table.select(
            table["id"],
            rule.compile(table["id"]).name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]
        assert not result.iloc[1]["is_valid"]
        assert not result.iloc[2]["is_valid"]

    def test_zip_code_pattern(self):
        """Test US ZIP code pattern."""
        table = ibis.memtable({
            "zip": ["94102", "1234", "123456", "ABCDE"]
        })

        rule = PatternRule(r"^\d{5}$")
        result = table.select(
            table["zip"],
            rule.compile(table["zip"]).name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # 94102
        assert not result.iloc[1]["is_valid"]  # 1234 (too short)
        assert not result.iloc[2]["is_valid"]  # 123456 (too long)
        assert not result.iloc[3]["is_valid"]  # ABCDE (not digits)

    def test_describe(self):
        """Test rule description."""
        rule = PatternRule(r"^test$")
        assert "pattern" in rule.describe().lower()


class TestMinRule:
    """Tests for MinRule."""

    def test_min_zero(self):
        """Test minimum value of zero."""
        table = ibis.memtable({
            "amount": [100.0, -50.0, 0.0, 150.5]
        })

        rule = MinRule(0)
        result = table.select(
            table["amount"],
            rule.compile(table["amount"]).name("is_valid")
        ).execute()

        assert result[result["amount"] == 100.0]["is_valid"].iloc[0]
        assert not result[result["amount"] == -50.0]["is_valid"].iloc[0]
        assert result[result["amount"] == 0.0]["is_valid"].iloc[0]  # Inclusive
        assert result[result["amount"] == 150.5]["is_valid"].iloc[0]

    def test_min_positive(self):
        """Test minimum value > 0."""
        table = ibis.memtable({
            "count": [0, 1, 5, -1]
        })

        rule = MinRule(1)
        result = table.select(
            table["count"],
            rule.compile(table["count"]).name("is_valid")
        ).execute()

        assert not result[result["count"] == 0]["is_valid"].iloc[0]
        assert result[result["count"] == 1]["is_valid"].iloc[0]
        assert result[result["count"] == 5]["is_valid"].iloc[0]

    def test_min_negative(self):
        """Test negative minimum value."""
        table = ibis.memtable({
            "temp": [-100, -50, 0, 50]
        })

        rule = MinRule(-50)
        result = table.select(
            table["temp"],
            rule.compile(table["temp"]).name("is_valid")
        ).execute()

        assert not result[result["temp"] == -100]["is_valid"].iloc[0]
        assert result[result["temp"] == -50]["is_valid"].iloc[0]

    def test_describe(self):
        """Test rule description."""
        rule = MinRule(10)
        assert ">=" in rule.describe()
        assert "10" in rule.describe()


class TestMaxRule:
    """Tests for MaxRule."""

    def test_max_hundred(self):
        """Test maximum value of 100."""
        table = ibis.memtable({
            "pct": [0.0, 50.0, 100.0, 100.1, 150.0]
        })

        rule = MaxRule(100)
        result = table.select(
            table["pct"],
            rule.compile(table["pct"]).name("is_valid")
        ).execute()

        assert result[result["pct"] == 0.0]["is_valid"].iloc[0]
        assert result[result["pct"] == 100.0]["is_valid"].iloc[0]  # Inclusive
        assert not result[result["pct"] == 100.1]["is_valid"].iloc[0]
        assert not result[result["pct"] == 150.0]["is_valid"].iloc[0]

    def test_describe(self):
        """Test rule description."""
        rule = MaxRule(100)
        assert "<=" in rule.describe()
        assert "100" in rule.describe()


class TestMinLengthRule:
    """Tests for MinLengthRule."""

    def test_min_length_one(self):
        """Test minimum length of 1 (non-empty)."""
        table = ibis.memtable({
            "name": ["John", "", "A", "  "]
        })

        rule = MinLengthRule(1)
        result = table.select(
            table["name"],
            rule.compile(table["name"]).name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # "John"
        assert not result.iloc[1]["is_valid"]  # ""
        assert result.iloc[2]["is_valid"]  # "A"
        assert result.iloc[3]["is_valid"]  # "  " (spaces count)

    def test_min_length_five(self):
        """Test minimum length of 5."""
        table = ibis.memtable({
            "code": ["AB", "ABCD", "ABCDE", "ABCDEF"]
        })

        rule = MinLengthRule(5)
        result = table.select(
            table["code"],
            rule.compile(table["code"]).name("is_valid")
        ).execute()

        assert not result.iloc[0]["is_valid"]  # "AB"
        assert not result.iloc[1]["is_valid"]  # "ABCD"
        assert result.iloc[2]["is_valid"]  # "ABCDE"
        assert result.iloc[3]["is_valid"]  # "ABCDEF"


class TestMaxLengthRule:
    """Tests for MaxLengthRule."""

    def test_max_length_ten(self):
        """Test maximum length of 10."""
        table = ibis.memtable({
            "code": ["short", "exactly10!", "this is too long"]
        })

        rule = MaxLengthRule(10)
        result = table.select(
            table["code"],
            rule.compile(table["code"]).name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # "short"
        assert result.iloc[1]["is_valid"]  # "exactly10!"
        assert not result.iloc[2]["is_valid"]  # "this is too long"


class TestEnumRule:
    """Tests for EnumRule."""

    def test_string_enum(self):
        """Test string enumeration."""
        table = ibis.memtable({
            "status": ["active", "pending", "inactive", "INVALID", "deleted"]
        })

        rule = EnumRule(["active", "pending", "inactive"])
        result = table.select(
            table["status"],
            rule.compile(table["status"]).name("is_valid")
        ).execute()

        assert result[result["status"] == "active"]["is_valid"].iloc[0]
        assert result[result["status"] == "pending"]["is_valid"].iloc[0]
        assert result[result["status"] == "inactive"]["is_valid"].iloc[0]
        assert not result[result["status"] == "INVALID"]["is_valid"].iloc[0]
        assert not result[result["status"] == "deleted"]["is_valid"].iloc[0]

    def test_numeric_enum(self):
        """Test numeric enumeration."""
        table = ibis.memtable({
            "rating": [1, 2, 3, 4, 5, 6, 0]
        })

        rule = EnumRule([1, 2, 3, 4, 5])
        result = table.select(
            table["rating"],
            rule.compile(table["rating"]).name("is_valid")
        ).execute()

        assert result[result["rating"] == 1]["is_valid"].iloc[0]
        assert result[result["rating"] == 5]["is_valid"].iloc[0]
        assert not result[result["rating"] == 6]["is_valid"].iloc[0]
        assert not result[result["rating"] == 0]["is_valid"].iloc[0]

    def test_describe_short_list(self):
        """Test description with short enum list."""
        rule = EnumRule(["a", "b", "c"])
        desc = rule.describe()
        assert "a" in desc
        assert "b" in desc
        assert "c" in desc

    def test_describe_long_list(self):
        """Test description with long enum list."""
        rule = EnumRule(list(range(100)))
        desc = rule.describe()
        assert "100" in desc  # Should mention count


class TestNullableRule:
    """Tests for NullableRule."""

    def test_not_nullable(self):
        """Test non-nullable validation."""
        table = ibis.memtable({
            "value": ["a", None, "b", None]
        })

        rule = NullableRule(allow_null=False)
        result = table.select(
            table["value"],
            rule.compile(table["value"]).name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # "a"
        assert not result.iloc[1]["is_valid"]  # None
        assert result.iloc[2]["is_valid"]  # "b"
        assert not result.iloc[3]["is_valid"]  # None

    def test_nullable(self):
        """Test nullable validation (always passes)."""
        table = ibis.memtable({
            "value": ["a", None, "b"]
        })

        rule = NullableRule(allow_null=True)
        result = table.select(
            table["value"],
            rule.compile(table["value"]).name("is_valid")
        ).execute()

        # When allow_null=True, this rule itself always passes
        # (null handling is done in compose_rules)
        assert all(result["is_valid"])


class TestRuleComposition:
    """Tests for composing multiple rules."""

    def test_compose_min_max(self):
        """Test composing min and max rules."""
        table = ibis.memtable({
            "value": [50, 0, 100, -10, 150]
        })

        rules = [MinRule(0), MaxRule(100)]
        composed = compose_rules(table["value"], rules, allow_null=False)

        result = table.select(
            table["value"],
            composed.name("is_valid")
        ).execute()

        assert result[result["value"] == 50]["is_valid"].iloc[0]
        assert result[result["value"] == 0]["is_valid"].iloc[0]
        assert result[result["value"] == 100]["is_valid"].iloc[0]
        assert not result[result["value"] == -10]["is_valid"].iloc[0]
        assert not result[result["value"] == 150]["is_valid"].iloc[0]

    def test_compose_pattern_and_length(self):
        """Test composing pattern and length rules."""
        table = ibis.memtable({
            "code": ["AB12", "A1", "ABCD1234", "AB", "1234"]
        })

        rules = [
            PatternRule(r"^[A-Z]+\d+$"),  # Letters then digits
            MinLengthRule(3),
            MaxLengthRule(6),
        ]
        composed = compose_rules(table["code"], rules, allow_null=False)

        result = table.select(
            table["code"],
            composed.name("is_valid")
        ).execute()

        assert result[result["code"] == "AB12"]["is_valid"].iloc[0]
        assert not result[result["code"] == "A1"]["is_valid"].iloc[0]  # Too short
        assert not result[result["code"] == "ABCD1234"]["is_valid"].iloc[0]  # Too long
        assert not result[result["code"] == "AB"]["is_valid"].iloc[0]  # No digits
        assert not result[result["code"] == "1234"]["is_valid"].iloc[0]  # No pattern match

    def test_compose_with_null_not_allowed(self):
        """Test composition with nulls not allowed."""
        table = ibis.memtable({
            "value": [50, None, 100]
        })

        rules = [MinRule(0), MaxRule(100)]
        composed = compose_rules(table["value"], rules, allow_null=False)

        result = table.select(
            table["value"],
            composed.name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # 50
        assert not result.iloc[1]["is_valid"]  # None
        assert result.iloc[2]["is_valid"]  # 100

    def test_compose_with_null_allowed(self):
        """Test composition with nulls allowed."""
        table = ibis.memtable({
            "value": [50, None, 150]
        })

        rules = [MinRule(0), MaxRule(100)]
        composed = compose_rules(table["value"], rules, allow_null=True)

        result = table.select(
            table["value"],
            composed.name("is_valid")
        ).execute()

        assert result.iloc[0]["is_valid"]  # 50
        assert result.iloc[1]["is_valid"]  # None (allowed)
        assert not result.iloc[2]["is_valid"]  # 150 (exceeds max)

    def test_compose_empty_rules(self):
        """Test composing empty rules list."""
        table = ibis.memtable({
            "value": [1, 2, None, 4]
        })

        composed = compose_rules(table["value"], [], allow_null=False)
        result = table.select(composed.name("is_valid")).execute()

        # Empty rules means everything passes
        assert all(result["is_valid"])


class TestRulesFromResolvedType:
    """Tests for extracting rules from resolved types."""

    def test_string_type_rules(self):
        """Test extracting rules from a string type."""
        resolved = ResolvedType(
            name="Email",
            description="Email",
            base=BaseType.STRING,
            pattern=r"^.+@.+$",
            min_length=5,
            max_length=255,
        )

        rules = rules_from_resolved_type(resolved)
        rule_names = {r.name for r in rules}

        assert "pattern" in rule_names
        assert "min_length" in rule_names
        assert "max_length" in rule_names
        assert len(rules) == 3

    def test_numeric_type_rules(self):
        """Test extracting rules from a numeric type."""
        resolved = ResolvedType(
            name="Percentage",
            description="Percentage",
            base=BaseType.DECIMAL,
            min=0,
            max=100,
        )

        rules = rules_from_resolved_type(resolved)
        rule_names = {r.name for r in rules}

        assert "min" in rule_names
        assert "max" in rule_names
        assert len(rules) == 2

    def test_enum_type_rules(self):
        """Test extracting rules from an enum type."""
        resolved = ResolvedType(
            name="Status",
            description="Status",
            base=BaseType.STRING,
            enum=["active", "inactive"],
        )

        rules = rules_from_resolved_type(resolved)
        rule_names = {r.name for r in rules}

        assert "enum" in rule_names
        assert len(rules) == 1

    def test_empty_type_rules(self):
        """Test type with no validation rules."""
        resolved = ResolvedType(
            name="AnyString",
            description="Any string",
            base=BaseType.STRING,
        )

        rules = rules_from_resolved_type(resolved)
        assert len(rules) == 0

    def test_combined_rules(self):
        """Test type with multiple rule types."""
        resolved = ResolvedType(
            name="BoundedDecimal",
            description="Bounded decimal",
            base=BaseType.DECIMAL,
            min=0,
            max=100,
            enum=[0, 25, 50, 75, 100],
        )

        rules = rules_from_resolved_type(resolved)
        rule_names = {r.name for r in rules}

        assert "min" in rule_names
        assert "max" in rule_names
        assert "enum" in rule_names


class TestQueryBuilder:
    """Tests for QueryBuilder."""

    def test_add_model(self, stdlib_registry):
        """Test adding a model to query builder."""
        builder = QueryBuilder(stdlib_registry)

        model = ModelMapping(
            table="users",
            columns=[
                ColumnMapping(name="email", type="Email"),
                ColumnMapping(name="id", type="UUID"),
            ],
        )
        builder.add_model(model)

        assert "users" in builder.get_tables()
        checks = builder.get_checks("users")
        assert len(checks) == 2

    def test_column_check_properties(self, stdlib_registry):
        """Test ColumnCheck properties."""
        builder = QueryBuilder(stdlib_registry)

        model = ModelMapping(
            table="users",
            columns=[
                ColumnMapping(name="email", type="Email"),
            ],
        )
        builder.add_model(model)

        checks = builder.get_checks("users")
        assert len(checks) == 1

        check = checks[0]
        assert check.table == "users"
        assert check.column == "email"
        assert check.type_name == "Email"
        assert len(check.rules) > 0  # Email has pattern rule
        assert check.allow_null is False

    def test_nullability_override(self, stdlib_registry):
        """Test that column mapping can override type nullability."""
        builder = QueryBuilder(stdlib_registry)

        model = ModelMapping(
            table="users",
            columns=[
                ColumnMapping(name="email", type="Email", allow_null=True),
            ],
        )
        builder.add_model(model)

        checks = builder.get_checks("users")
        assert checks[0].allow_null is True  # Overridden

    def test_get_tables(self, stdlib_registry):
        """Test getting all tables."""
        builder = QueryBuilder(stdlib_registry)

        builder.add_model(ModelMapping(
            table="users",
            columns=[ColumnMapping(name="id", type="UUID")],
        ))
        builder.add_model(ModelMapping(
            table="orders",
            columns=[ColumnMapping(name="id", type="UUID")],
        ))

        tables = builder.get_tables()
        assert "users" in tables
        assert "orders" in tables


class TestValidationResult:
    """Tests for ValidationResult."""

    def test_passed_result(self):
        """Test a passing validation result."""
        result = ValidationResult(
            table="users",
            column="email",
            type_name="Email",
            total_rows=1000,
            null_count=0,
            valid_count=1000,
            invalid_count=0,
        )

        assert result.passed is True
        assert result.pass_rate == 1.0

    def test_failed_result(self):
        """Test a failing validation result."""
        result = ValidationResult(
            table="users",
            column="email",
            type_name="Email",
            total_rows=1000,
            null_count=10,
            valid_count=900,
            invalid_count=100,
            sample_failures=["invalid", "also-invalid"],
        )

        assert result.passed is False
        assert result.pass_rate == 0.9
        assert len(result.sample_failures) == 2

    def test_empty_table_result(self):
        """Test result for empty table."""
        result = ValidationResult(
            table="users",
            column="email",
            type_name="Email",
            total_rows=0,
            null_count=0,
            valid_count=0,
            invalid_count=0,
        )

        assert result.passed is True
        assert result.pass_rate == 1.0  # No rows means no failures


class TestFullValidationPipeline:
    """Integration tests for the full validation pipeline."""

    def test_validate_email_column(self, stdlib_registry, users_table):
        """Test validating an email column end-to-end."""
        builder = QueryBuilder(stdlib_registry)
        builder.add_model(ModelMapping(
            table="users",
            columns=[ColumnMapping(name="email", type="Email")],
        ))

        # Build validation query
        checks = builder.get_checks("users")
        validation_query = builder.build_validation_query(users_table, checks)

        # Execute
        result = validation_query.execute()

        assert result["total_rows"].iloc[0] == 7
        # Valid emails: alice@example.com, bob@test.org, charlie@acme.com, user@domain.co.uk
        # Invalid: "invalid-email", "", None
        assert result["email__invalid"].iloc[0] >= 3

    def test_validate_percentage_column(self, stdlib_registry, orders_table):
        """Test validating a percentage column."""
        builder = QueryBuilder(stdlib_registry)
        builder.add_model(ModelMapping(
            table="orders",
            columns=[ColumnMapping(name="discount_pct", type="Percentage")],
        ))

        checks = builder.get_checks("orders")
        validation_query = builder.build_validation_query(orders_table, checks)
        result = validation_query.execute()

        assert result["total_rows"].iloc[0] == 5
        # Valid: 10.0, 0.0, 50.0 | Invalid: 110.0, -5.0
        assert result["discount_pct__invalid"].iloc[0] == 2

    def test_validate_multiple_columns(self, stdlib_registry, orders_table):
        """Test validating multiple columns in one query."""
        builder = QueryBuilder(stdlib_registry)
        builder.add_model(ModelMapping(
            table="orders",
            columns=[
                ColumnMapping(name="discount_pct", type="Percentage"),
                ColumnMapping(name="currency", type="CurrencyCodeISO"),
            ],
        ))

        checks = builder.get_checks("orders")
        validation_query = builder.build_validation_query(orders_table, checks)
        result = validation_query.execute()

        assert "discount_pct__valid" in result.columns
        assert "discount_pct__invalid" in result.columns
        assert "currency__valid" in result.columns
        assert "currency__invalid" in result.columns

    def test_validate_country_code(self, stdlib_registry, orders_table):
        """Test validating country codes."""
        builder = QueryBuilder(stdlib_registry)
        builder.add_model(ModelMapping(
            table="orders",
            columns=[ColumnMapping(name="country", type="CountryISO2")],
        ))

        checks = builder.get_checks("orders")
        validation_query = builder.build_validation_query(orders_table, checks)
        result = validation_query.execute()

        # Valid: US, DE, GB, CA | Invalid: XX
        assert result["country__invalid"].iloc[0] >= 1

    def test_sample_failures_query(self, stdlib_registry, users_table):
        """Test building sample failures query."""
        builder = QueryBuilder(stdlib_registry)
        builder.add_model(ModelMapping(
            table="users",
            columns=[ColumnMapping(name="email", type="Email")],
        ))

        checks = builder.get_checks("users")
        check = checks[0]

        sample_query = builder.build_sample_failures_query(users_table, check, limit=5)
        result = sample_query.execute()

        # Should contain invalid emails
        invalid_emails = result["email"].tolist()
        assert "invalid-email" in invalid_emails or "" in invalid_emails
