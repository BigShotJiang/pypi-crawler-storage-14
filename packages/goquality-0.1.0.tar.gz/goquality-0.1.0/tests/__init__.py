"""GoQuality tests."""
