"""
Comprehensive tests for the YAML loader.
"""

from pathlib import Path

import pytest

from goquality.schema.loader import (
    STDLIB_DIR,
    create_default_config,
    find_config_file,
    load_config,
    load_stdlib,
    load_types_from_yaml,
    load_yaml,
)
from goquality.schema.models import GoQualityConfig
from goquality.schema.registry import TypeRegistry


class TestLoadYaml:
    """Tests for load_yaml function."""

    def test_load_valid_yaml(self, tmp_path):
        """Test loading a valid YAML file."""
        yaml_file = tmp_path / "test.yaml"
        yaml_file.write_text("""
name: test
values:
  - one
  - two
""")

        data = load_yaml(yaml_file)

        assert data["name"] == "test"
        assert data["values"] == ["one", "two"]

    def test_load_empty_yaml(self, tmp_path):
        """Test loading an empty YAML file."""
        yaml_file = tmp_path / "empty.yaml"
        yaml_file.write_text("")

        data = load_yaml(yaml_file)

        assert data == {}

    def test_load_nonexistent_file(self, tmp_path):
        """Test loading a nonexistent file."""
        yaml_file = tmp_path / "nonexistent.yaml"

        with pytest.raises(FileNotFoundError):
            load_yaml(yaml_file)


class TestLoadTypesFromYaml:
    """Tests for load_types_from_yaml function."""

    def test_load_valid_types(self, tmp_path):
        """Test loading valid type definitions."""
        yaml_file = tmp_path / "types.yaml"
        yaml_file.write_text("""
types:
  - name: Email
    description: Email address
    base: String
    pattern: "^.+@.+$"
  - name: Age
    description: Human age
    base: Integer
    min: 0
    max: 150
""")

        types = load_types_from_yaml(yaml_file)

        assert len(types) == 2
        assert types[0].name == "Email"
        assert types[0].pattern == "^.+@.+$"
        assert types[1].name == "Age"
        assert types[1].min == 0
        assert types[1].max == 150

    def test_load_no_types(self, tmp_path):
        """Test loading file with no types key."""
        yaml_file = tmp_path / "no_types.yaml"
        yaml_file.write_text("other: value")

        types = load_types_from_yaml(yaml_file)

        assert types == []

    def test_load_invalid_type(self, tmp_path):
        """Test loading an invalid type definition."""
        yaml_file = tmp_path / "invalid.yaml"
        yaml_file.write_text("""
types:
  - name: invalid  # Invalid: lowercase name
    description: Bad type
    base: String
""")

        with pytest.raises(ValueError, match="Invalid type"):
            load_types_from_yaml(yaml_file)


class TestLoadConfig:
    """Tests for load_config function."""

    def test_load_minimal_config(self, tmp_path):
        """Test loading a minimal configuration."""
        config_file = tmp_path / "goquality.yaml"
        config_file.write_text("""
types: []
models: []
""")

        config = load_config(config_file)

        assert isinstance(config, GoQualityConfig)
        assert config.types == []
        assert config.models == []

    def test_load_full_config(self, tmp_path):
        """Test loading a full configuration."""
        config_file = tmp_path / "goquality.yaml"
        config_file.write_text("""
types:
  - name: CustomEmail
    description: Custom email
    base: String
    pattern: "^.+@example[.]com$"

models:
  - table: users
    columns:
      - name: email
        type: CustomEmail
      - name: id
        type: UUID

checks:
  - "on": orders
    rules:
      - "amount > 0"
""")

        config = load_config(config_file)

        assert len(config.types) == 1
        assert config.types[0].name == "CustomEmail"
        assert len(config.models) == 1
        assert config.models[0].table == "users"
        assert len(config.models[0].columns) == 2
        assert len(config.checks) == 1

    def test_load_config_path_as_string(self, tmp_path):
        """Test loading config with path as string."""
        config_file = tmp_path / "goquality.yaml"
        config_file.write_text("types: []")

        config = load_config(str(config_file))

        assert isinstance(config, GoQualityConfig)


class TestLoadStdlib:
    """Tests for load_stdlib function."""

    def test_stdlib_directory_exists(self):
        """Test that stdlib directory exists."""
        assert STDLIB_DIR.exists()
        assert STDLIB_DIR.is_dir()

    def test_stdlib_has_yaml_files(self):
        """Test that stdlib has YAML files."""
        yaml_files = list(STDLIB_DIR.rglob("*.yaml"))
        assert len(yaml_files) > 0

    def test_load_stdlib_into_registry(self):
        """Test loading stdlib into registry."""
        registry = TypeRegistry()
        count = load_stdlib(registry)

        assert count > 100  # We have 100+ types

        # Verify some common types exist
        assert registry.has_type("Email")
        assert registry.has_type("UUID")
        assert registry.has_type("URL")
        assert registry.has_type("Percentage")

    def test_load_stdlib_twice_replaces(self):
        """Test that loading stdlib twice works (replaces)."""
        registry = TypeRegistry()
        count1 = load_stdlib(registry)
        count2 = load_stdlib(registry)

        # Should have same count both times
        assert count1 == count2


class TestFindConfigFile:
    """Tests for find_config_file function."""

    def test_find_in_current_dir(self, tmp_path):
        """Test finding config in current directory."""
        config_file = tmp_path / "goquality.yaml"
        config_file.write_text("types: []")

        found = find_config_file(tmp_path)

        assert found == config_file

    def test_find_in_parent_dir(self, tmp_path):
        """Test finding config in parent directory."""
        config_file = tmp_path / "goquality.yaml"
        config_file.write_text("types: []")

        subdir = tmp_path / "sub" / "dir"
        subdir.mkdir(parents=True)

        found = find_config_file(subdir)

        assert found == config_file

    def test_find_dot_goquality(self, tmp_path):
        """Test finding .goquality/config.yaml."""
        dot_dir = tmp_path / ".goquality"
        dot_dir.mkdir()
        config_file = dot_dir / "config.yaml"
        config_file.write_text("types: []")

        found = find_config_file(tmp_path)

        assert found == config_file

    def test_no_config_found(self, tmp_path):
        """Test when no config file is found."""
        # Create an empty directory tree
        subdir = tmp_path / "project" / "src"
        subdir.mkdir(parents=True)

        found = find_config_file(subdir)

        # Might find one in parent dirs if running in a goquality project
        # Just check it returns either Path or None
        assert found is None or isinstance(found, Path)


class TestCreateDefaultConfig:
    """Tests for create_default_config function."""

    def test_create_in_new_directory(self, tmp_path):
        """Test creating config in a new directory."""
        config_path = tmp_path / "project" / "goquality.yaml"

        create_default_config(config_path)

        assert config_path.exists()
        content = config_path.read_text()
        assert "types:" in content
        assert "models:" in content

    def test_overwrite_existing(self, tmp_path):
        """Test overwriting existing config."""
        config_path = tmp_path / "goquality.yaml"
        config_path.write_text("old content")

        create_default_config(config_path)

        content = config_path.read_text()
        assert "types:" in content
        assert "old content" not in content

    def test_default_config_is_valid(self, tmp_path):
        """Test that default config is valid YAML."""
        config_path = tmp_path / "goquality.yaml"

        create_default_config(config_path)

        # Should be valid YAML
        data = load_yaml(config_path)
        assert "types" in data or data == {}


class TestStdlibCategories:
    """Tests to verify stdlib type categories."""

    @pytest.fixture
    def registry(self):
        """Registry with stdlib loaded."""
        reg = TypeRegistry()
        load_stdlib(reg)
        return reg

    def test_core_string_types(self, registry):
        """Test core string types exist."""
        core = ["Email", "URL", "UUID", "IPv4", "IPv6", "Slug", "Hostname"]
        for name in core:
            assert registry.has_type(name), f"Missing core type: {name}"

    def test_finance_types(self, registry):
        """Test finance types exist."""
        finance = ["USD", "EUR", "GBP", "IBAN", "CreditCardNumber", "BTC", "ETH"]
        for name in finance:
            assert registry.has_type(name), f"Missing finance type: {name}"

    def test_geo_types(self, registry):
        """Test geo types exist."""
        geo = ["CountryISO2", "CountryISO3", "StateUS", "ZipCodeUS"]
        for name in geo:
            assert registry.has_type(name), f"Missing geo type: {name}"

    def test_identifier_types(self, registry):
        """Test identifier types exist."""
        ids = ["UUID", "ULID", "NanoID", "CUID", "ObjectId"]
        for name in ids:
            assert registry.has_type(name), f"Missing identifier type: {name}"

    def test_temporal_types(self, registry):
        """Test temporal types exist."""
        temporal = ["ISO8601Date", "ISO8601DateTime", "TimeHHMM", "TimeHHMMSS", "YearMonth"]
        for name in temporal:
            assert registry.has_type(name), f"Missing temporal type: {name}"

    def test_pii_types(self, registry):
        """Test PII types exist."""
        pii = ["SSN", "EIN", "DriversLicenseUS", "PassportUS"]
        for name in pii:
            assert registry.has_type(name), f"Missing PII type: {name}"

    def test_nullable_variants_exist(self, registry):
        """Test that nullable variants exist."""
        nullable = ["EmailNullable", "URLNullable", "ISO8601DateNullable"]
        for name in nullable:
            assert registry.has_type(name), f"Missing nullable type: {name}"
            resolved = registry.resolve(name)
            assert resolved.allow_null is True
