"""
Tests for database connector abstraction layer.
"""

import pytest

from goquality.connectors import (
    ConnectionConfig,
    DatabaseConnector,
    DatabaseInfo,
    DuckDBConnector,
    connect,
    create_connector,
    get_connector,
    list_connectors,
    parse_connection_string,
)


class TestConnectionConfig:
    """Tests for ConnectionConfig dataclass."""

    def test_basic_postgres_config(self):
        """Test creating a PostgreSQL config."""
        config = ConnectionConfig(
            dialect="postgres",
            host="localhost",
            port=5432,
            database="mydb",
            user="user",
            password="pass",
        )

        assert config.dialect == "postgres"
        assert config.host == "localhost"
        assert config.port == 5432

    def test_duckdb_memory_config(self):
        """Test creating a DuckDB in-memory config."""
        config = ConnectionConfig(
            dialect="duckdb",
            path=":memory:",
        )

        assert config.dialect == "duckdb"
        assert config.path == ":memory:"

    def test_to_connection_string_postgres(self):
        """Test converting config back to connection string."""
        config = ConnectionConfig(
            dialect="postgres",
            host="localhost",
            port=5432,
            database="mydb",
            user="user",
            password="pass",
        )

        conn_str = config.to_connection_string()
        assert "postgresql://" in conn_str
        assert "user:pass@" in conn_str
        assert "localhost:5432" in conn_str
        assert "/mydb" in conn_str

    def test_to_connection_string_duckdb(self):
        """Test converting DuckDB config to connection string."""
        config = ConnectionConfig(
            dialect="duckdb",
            path=":memory:",
        )

        conn_str = config.to_connection_string()
        assert conn_str == "duckdb://:memory:"


class TestParseConnectionString:
    """Tests for parse_connection_string function."""

    def test_parse_postgres(self):
        """Test parsing PostgreSQL connection string."""
        config = parse_connection_string(
            "postgres://user:pass@localhost:5432/mydb"
        )

        assert config.dialect == "postgres"
        assert config.host == "localhost"
        assert config.port == 5432
        assert config.database == "mydb"
        assert config.user == "user"
        assert config.password == "pass"

    def test_parse_postgresql_scheme(self):
        """Test parsing with postgresql:// scheme."""
        config = parse_connection_string(
            "postgresql://user:pass@localhost/mydb"
        )

        assert config.dialect == "postgres"

    def test_parse_duckdb_memory(self):
        """Test parsing DuckDB in-memory connection string."""
        config = parse_connection_string("duckdb://:memory:")

        assert config.dialect == "duckdb"
        assert config.path == ":memory:"

    def test_parse_duckdb_file(self):
        """Test parsing DuckDB file connection string."""
        config = parse_connection_string("duckdb:///path/to/file.db")

        assert config.dialect == "duckdb"
        assert config.path == "/path/to/file.db"

    def test_parse_local_csv(self):
        """Test parsing local CSV file path."""
        config = parse_connection_string("/data/file.csv")

        assert config.dialect == "duckdb"
        assert config.path == "/data/file.csv"

    def test_parse_local_parquet(self):
        """Test parsing local Parquet file path."""
        config = parse_connection_string("/data/file.parquet")

        assert config.dialect == "duckdb"
        assert config.path == "/data/file.parquet"

    def test_parse_snowflake(self):
        """Test parsing Snowflake connection string."""
        config = parse_connection_string(
            "snowflake://user@account/database/schema?warehouse=WH"
        )

        assert config.dialect == "snowflake"
        assert config.host == "account"
        assert config.user == "user"
        assert config.database == "database"
        assert config.schema == "schema"
        assert config.options.get("warehouse") == "WH"

    def test_parse_bigquery(self):
        """Test parsing BigQuery connection string."""
        config = parse_connection_string("bigquery://project-id/dataset")

        assert config.dialect == "bigquery"
        assert config.database == "project-id"
        assert config.schema == "dataset"

    def test_parse_unsupported_scheme(self):
        """Test that unsupported scheme raises error."""
        with pytest.raises(ValueError, match="Unsupported"):
            parse_connection_string("mysql://localhost/db")


class TestDuckDBConnector:
    """Tests for DuckDB connector."""

    def test_memory_connector(self):
        """Test creating in-memory DuckDB connector."""
        connector = DuckDBConnector.memory()

        assert connector.is_connected
        assert connector.dialect == "duckdb"

        connector.disconnect()
        assert not connector.is_connected

    def test_context_manager(self):
        """Test using connector as context manager."""
        config = ConnectionConfig(dialect="duckdb", path=":memory:")

        with DuckDBConnector(config) as conn:
            assert conn.is_connected
            tables = conn.list_tables()
            assert isinstance(tables, list)

    def test_test_connection(self):
        """Test the test_connection method."""
        connector = DuckDBConnector.memory()
        assert connector.test_connection() is True
        connector.disconnect()

    def test_get_info(self):
        """Test getting database info."""
        connector = DuckDBConnector.memory()
        info = connector.get_info()

        assert isinstance(info, DatabaseInfo)
        assert info.dialect == "duckdb"
        assert info.connected is True

        connector.disconnect()

    def test_register_dataframe(self):
        """Test registering a pandas DataFrame."""
        import pandas as pd

        connector = DuckDBConnector.memory()
        df = pd.DataFrame({
            "name": ["Alice", "Bob"],
            "age": [30, 25],
        })

        table_name = connector.register_dataframe(df, "people")
        assert table_name == "people"
        assert "people" in connector.list_tables()

        connector.disconnect()

    def test_create_table_from_values(self):
        """Test creating table from values."""
        connector = DuckDBConnector.memory()

        connector.create_table_from_values(
            "test_table",
            {
                "id": [1, 2, 3],
                "name": ["A", "B", "C"],
            }
        )

        assert "test_table" in connector.list_tables()
        connector.disconnect()


class TestConnectorRegistry:
    """Tests for connector registry functions."""

    def test_list_connectors(self):
        """Test listing available connectors."""
        connectors = list_connectors()

        assert "duckdb" in connectors
        assert "postgres" in connectors
        assert "postgresql" in connectors

    def test_get_connector_duckdb(self):
        """Test getting DuckDB connector class."""
        connector_class = get_connector("duckdb")
        assert connector_class == DuckDBConnector

    def test_get_connector_unknown(self):
        """Test getting unknown connector raises error."""
        with pytest.raises(ValueError, match="Unsupported"):
            get_connector("unknown_db")


class TestConnect:
    """Tests for the connect convenience function."""

    def test_connect_duckdb_memory(self):
        """Test connecting to DuckDB in-memory."""
        conn = connect("duckdb://:memory:")

        # Should return Ibis backend
        assert hasattr(conn, "list_tables")
        tables = conn.list_tables()
        assert isinstance(tables, list)

    def test_create_connector(self):
        """Test create_connector function."""
        connector = create_connector("duckdb://:memory:")

        assert isinstance(connector, DatabaseConnector)
        assert connector.is_connected

        connector.disconnect()
