"""
Validation Rules: Composable units of validation logic.

Each rule knows how to compile itself to a SQL predicate.
Rules are independent and can be combined for a type.

Design principle: Composition over inheritance.
A type is simply a collection of rules applied together.

Rule Categories:
1. Column Rules - validate individual values (PatternRule, MinRule, etc.)
2. Table Rules - validate based on table context (UniqueRule, ForeignKeyRule)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import ibis
from ibis.expr.types import BooleanColumn, Column, Table

if TYPE_CHECKING:
    from goquality.schema.registry import ResolvedType


class ValidationRule(ABC):
    """
    Base class for all validation rules.

    Each rule can compile itself to an Ibis boolean expression
    that returns True for valid values, False for invalid.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable rule name."""
        pass

    @abstractmethod
    def compile(self, column: Column) -> BooleanColumn:
        """
        Compile this rule to an Ibis boolean expression.

        Args:
            column: The Ibis column to validate

        Returns:
            Boolean expression (True = valid, False = invalid)
        """
        pass

    @abstractmethod
    def describe(self) -> str:
        """Human-readable description of this rule."""
        pass


class TableAwareRule(ValidationRule):
    """
    Base class for rules that need table-level context.

    These rules may need access to other columns or the full table
    to perform validation (e.g., unique checks, foreign key checks).
    """

    @abstractmethod
    def compile_with_table(self, column: Column, table: Table) -> BooleanColumn:
        """
        Compile this rule with table context.

        Args:
            column: The Ibis column to validate
            table: The full table for context

        Returns:
            Boolean expression (True = valid, False = invalid)
        """
        pass

    def compile(self, column: Column) -> BooleanColumn:
        """Default compile without table - may not work for all table-aware rules."""
        raise NotImplementedError(
            f"{self.__class__.__name__} requires table context. "
            "Use compile_with_table() instead."
        )


@dataclass
class PatternRule(ValidationRule):
    """
    Validates string matches a regex pattern.

    Uses SQL REGEXP/SIMILAR TO depending on dialect.
    """

    pattern: str

    @property
    def name(self) -> str:
        return "pattern"

    def compile(self, column: Column) -> BooleanColumn:
        # Ibis .re_search() compiles to appropriate SQL regex
        return column.re_search(self.pattern)

    def describe(self) -> str:
        return f"must match pattern: {self.pattern}"


@dataclass
class MinRule(ValidationRule):
    """Validates numeric value >= minimum."""

    min_value: float

    @property
    def name(self) -> str:
        return "min"

    def compile(self, column: Column) -> BooleanColumn:
        return column >= self.min_value

    def describe(self) -> str:
        return f"must be >= {self.min_value}"


@dataclass
class MaxRule(ValidationRule):
    """Validates numeric value <= maximum."""

    max_value: float

    @property
    def name(self) -> str:
        return "max"

    def compile(self, column: Column) -> BooleanColumn:
        return column <= self.max_value

    def describe(self) -> str:
        return f"must be <= {self.max_value}"


@dataclass
class MinLengthRule(ValidationRule):
    """Validates string length >= minimum."""

    min_length: int

    @property
    def name(self) -> str:
        return "min_length"

    def compile(self, column: Column) -> BooleanColumn:
        return column.length() >= self.min_length

    def describe(self) -> str:
        return f"length must be >= {self.min_length}"


@dataclass
class MaxLengthRule(ValidationRule):
    """Validates string length <= maximum."""

    max_length: int

    @property
    def name(self) -> str:
        return "max_length"

    def compile(self, column: Column) -> BooleanColumn:
        return column.length() <= self.max_length

    def describe(self) -> str:
        return f"length must be <= {self.max_length}"


@dataclass
class EnumRule(ValidationRule):
    """Validates value is in allowed set."""

    allowed_values: list[Any]

    @property
    def name(self) -> str:
        return "enum"

    def compile(self, column: Column) -> BooleanColumn:
        return column.isin(self.allowed_values)

    def describe(self) -> str:
        if len(self.allowed_values) <= 5:
            return f"must be one of: {self.allowed_values}"
        return f"must be one of {len(self.allowed_values)} allowed values"


@dataclass
class NullableRule(ValidationRule):
    """
    Handles null checking.

    If allow_null=False, null values fail.
    If allow_null=True, null values pass (skip other validations).
    """

    allow_null: bool

    @property
    def name(self) -> str:
        return "nullable"

    def compile(self, column: Column) -> BooleanColumn:
        if self.allow_null:
            # Nulls are allowed - this rule always passes
            # (actual null handling done in compose_rules)
            return ibis.literal(True)
        else:
            # Nulls not allowed - must be non-null
            return column.notnull()

    def describe(self) -> str:
        if self.allow_null:
            return "null values allowed"
        return "must not be null"


@dataclass
class NotEmptyRule(ValidationRule):
    """
    Validates string is not empty or whitespace-only.

    This is more strict than just checking for NULL - it also
    catches empty strings and strings that are only whitespace.
    """

    trim_whitespace: bool = True

    @property
    def name(self) -> str:
        return "not_empty"

    def compile(self, column: Column) -> BooleanColumn:
        if self.trim_whitespace:
            # Trim and check length > 0
            return column.strip().length() > 0
        else:
            # Just check length > 0
            return column.length() > 0

    def describe(self) -> str:
        if self.trim_whitespace:
            return "must not be empty or whitespace-only"
        return "must not be empty"


@dataclass
class PrecisionRule(ValidationRule):
    """
    Validates decimal precision (digits after decimal point).

    Ensures numeric values don't have more decimal places than specified.
    """

    precision: int  # Maximum digits after decimal point

    @property
    def name(self) -> str:
        return "precision"

    def compile(self, column: Column) -> BooleanColumn:
        # Multiply by 10^precision, round, and check if equal to original scaled value
        # e.g., for precision=2, 12.34 -> 1234.0 -> 1234 -> matches -> valid
        # e.g., for precision=2, 12.345 -> 1234.5 -> 1234 or 1235 -> doesn't match -> invalid
        scale_factor = 10**self.precision
        scaled = column * scale_factor
        rounded = scaled.round(0)
        return scaled == rounded

    def describe(self) -> str:
        return f"must have at most {self.precision} decimal places"


@dataclass
class UniqueRule(TableAwareRule):
    """
    Validates column values are unique (no duplicates).

    This is a table-aware rule that checks for duplicates across all rows.
    Note: This rule marks ALL duplicate rows as invalid, not just the second occurrence.
    """

    @property
    def name(self) -> str:
        return "unique"

    def compile_with_table(self, column: Column, table: Table) -> BooleanColumn:
        """
        Check uniqueness by counting occurrences of each value.

        A value is valid if it appears exactly once in the column.
        We use a window function to count occurrences.
        """
        # Get the column name
        col_name = column.get_name()

        # Count occurrences using window function
        count_expr = table[col_name].count().over(ibis.window(group_by=table[col_name]))

        # Valid if count == 1 (unique) or value is NULL (nulls don't count as duplicates)
        return (count_expr == 1) | table[col_name].isnull()

    def compile(self, column: Column) -> BooleanColumn:
        """Uniqueness can't be checked without table context."""
        raise NotImplementedError(
            "UniqueRule requires table context. Use compile_with_table() instead."
        )

    def describe(self) -> str:
        return "must be unique (no duplicates)"


@dataclass
class ForeignKeyRule(TableAwareRule):
    """
    Validates values exist in a referenced table/column.

    This is a referential integrity check - every value in the source
    column must exist in the referenced column.
    """

    ref_table: Table  # Reference table (Ibis table expression)
    ref_column: str  # Column name in reference table

    @property
    def name(self) -> str:
        return "foreign_key"

    def compile_with_table(self, column: Column, table: Table) -> BooleanColumn:
        """
        Check referential integrity by verifying values exist in reference table.

        Uses a left semi-join approach: values are valid if they exist in reference.
        """
        col_name = column.get_name()

        # Get distinct values from reference column
        ref_values = self.ref_table[self.ref_column].distinct()

        # Check if column value exists in reference values
        # NULL values pass (NULL foreign keys are typically allowed)
        return table[col_name].isin(ref_values) | table[col_name].isnull()

    def compile(self, column: Column) -> BooleanColumn:
        """Foreign key can't be checked without table context."""
        raise NotImplementedError(
            "ForeignKeyRule requires table context. Use compile_with_table() instead."
        )

    def describe(self) -> str:
        return f"must exist in {self.ref_column}"


@dataclass
class CompositeUniqueRule(TableAwareRule):
    """
    Validates uniqueness across multiple columns (composite unique constraint).

    The combination of values across all specified columns must be unique.
    """

    columns: list[str] = field(default_factory=list)

    @property
    def name(self) -> str:
        return "composite_unique"

    def compile_with_table(self, column: Column, table: Table) -> BooleanColumn:
        """
        Check composite uniqueness using window function.
        """
        # Build group_by columns list
        group_cols = [table[col] for col in self.columns]

        # Count occurrences of each combination
        count_expr = ibis.literal(1).count().over(ibis.window(group_by=group_cols))

        # Valid if count == 1 (unique combination)
        return count_expr == 1

    def compile(self, column: Column) -> BooleanColumn:
        """Composite uniqueness can't be checked without table context."""
        raise NotImplementedError(
            "CompositeUniqueRule requires table context. "
            "Use compile_with_table() instead."
        )

    def describe(self) -> str:
        return f"combination of ({', '.join(self.columns)}) must be unique"


@dataclass
class ConditionalRule(ValidationRule):
    """
    Applies a rule only when a condition is met.

    Example: "status must be 'shipped' when ship_date is not null"
    """

    condition: BooleanColumn | None = None  # When to apply the rule
    rule: ValidationRule | None = None  # Rule to apply

    @property
    def name(self) -> str:
        return "conditional"

    def compile(self, column: Column) -> BooleanColumn:
        if self.condition is None or self.rule is None:
            return ibis.literal(True)

        # If condition is True, apply rule; otherwise, pass
        rule_result = self.rule.compile(column)
        return (~self.condition) | rule_result

    def describe(self) -> str:
        if self.rule is None:
            return "conditional rule (not configured)"
        return f"when condition met: {self.rule.describe()}"


@dataclass
class CustomSQLRule(ValidationRule):
    """
    Allows arbitrary SQL expressions as validation rules.

    The expression should evaluate to TRUE for valid rows.
    Use {column} as a placeholder for the column name.
    """

    expression: str  # SQL expression with {column} placeholder
    description_text: str = "custom SQL validation"

    @property
    def name(self) -> str:
        return "custom_sql"

    def compile(self, column: Column) -> BooleanColumn:
        # We use Ibis literal SQL for custom expressions
        # Note: This is dialect-specific and should be used carefully
        col_name = column.get_name()
        sql = self.expression.replace("{column}", col_name)
        return ibis.literal(sql).cast("boolean")

    def describe(self) -> str:
        return self.description_text


def compose_rules(
    column: Column,
    rules: list[ValidationRule],
    allow_null: bool = False
) -> BooleanColumn:
    """
    Compose multiple validation rules into a single boolean expression.

    Logic:
    - If allow_null=True: NULL values pass, non-null values must pass all rules
    - If allow_null=False: NULL values fail, non-null values must pass all rules

    This is the key composition function - rules are independent,
    and this function combines them correctly.
    """
    if not rules:
        return ibis.literal(True)

    # Compile all rules
    conditions = [rule.compile(column) for rule in rules]

    # Combine with AND
    combined = conditions[0]
    for condition in conditions[1:]:
        combined = combined & condition

    # Handle nullability
    if allow_null:
        # NULL values pass (skip validation), non-null must pass
        return column.isnull() | combined
    else:
        # NULL values fail, non-null must pass
        return column.notnull() & combined


def rules_from_resolved_type(
    resolved_type: "ResolvedType",
    include_table_rules: bool = False
) -> list[ValidationRule]:
    """
    Extract validation rules from a resolved type.

    This is the bridge between schema and compiler.

    Args:
        resolved_type: The resolved type to extract rules from
        include_table_rules: If True, include table-aware rules (unique, foreign_key)
                            These require special handling with table context.

    Returns:
        List of ValidationRule instances
    """

    rules: list[ValidationRule] = []

    # String validations
    if resolved_type.pattern is not None:
        rules.append(PatternRule(resolved_type.pattern))
    if resolved_type.min_length is not None:
        rules.append(MinLengthRule(resolved_type.min_length))
    if resolved_type.max_length is not None:
        rules.append(MaxLengthRule(resolved_type.max_length))
    if resolved_type.not_empty:
        rules.append(NotEmptyRule())

    # Numeric validations
    if resolved_type.min is not None:
        rules.append(MinRule(resolved_type.min))
    if resolved_type.max is not None:
        rules.append(MaxRule(resolved_type.max))
    if resolved_type.precision is not None:
        rules.append(PrecisionRule(resolved_type.precision))

    # Enum validation
    if resolved_type.enum is not None:
        rules.append(EnumRule(resolved_type.enum))

    # Table-level validations (only if requested)
    if include_table_rules:
        if resolved_type.unique:
            rules.append(UniqueRule())
        # Note: ForeignKeyRule requires the reference table, which must be
        # provided by the caller since we don't have DB connection here

    return rules


def get_table_rules(resolved_type: "ResolvedType") -> list[TableAwareRule]:
    """
    Extract table-aware validation rules from a resolved type.

    These rules require table context and are handled separately.

    Returns:
        List of TableAwareRule instances (excluding foreign key, which needs ref table)
    """

    rules: list[TableAwareRule] = []

    if resolved_type.unique:
        rules.append(UniqueRule())

    return rules
