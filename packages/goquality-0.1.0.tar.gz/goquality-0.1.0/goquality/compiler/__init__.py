"""
SQL Compiler for GoQuality types.

Transforms type definitions into SQL validation queries.
"""

from goquality.compiler.builder import QueryBuilder, ValidationResult
from goquality.compiler.rules import (
    CompositeUniqueRule,
    ConditionalRule,
    CustomSQLRule,
    EnumRule,
    ForeignKeyRule,
    MaxLengthRule,
    MaxRule,
    MinLengthRule,
    MinRule,
    NotEmptyRule,
    NullableRule,
    PatternRule,
    PrecisionRule,
    TableAwareRule,
    UniqueRule,
    ValidationRule,
)

__all__ = [
    # Base classes
    "ValidationRule",
    "TableAwareRule",
    # Column rules
    "PatternRule",
    "MinRule",
    "MaxRule",
    "MinLengthRule",
    "MaxLengthRule",
    "EnumRule",
    "NullableRule",
    "NotEmptyRule",
    "PrecisionRule",
    "ConditionalRule",
    "CustomSQLRule",
    # Table-aware rules
    "UniqueRule",
    "ForeignKeyRule",
    "CompositeUniqueRule",
    # Builder
    "QueryBuilder",
    "ValidationResult",
]
