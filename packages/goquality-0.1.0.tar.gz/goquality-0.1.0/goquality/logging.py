"""
Structured logging for GoQuality.

Provides consistent, configurable logging across all modules.
Supports JSON output for production environments.
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timezone
from enum import Enum
from typing import Any

# Module-level logger
_logger: logging.Logger | None = None


class LogLevel(str, Enum):
    """Log level options."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class StructuredFormatter(logging.Formatter):
    """
    Formatter that outputs structured log messages.

    In JSON mode, outputs machine-readable JSON.
    In text mode, outputs human-readable formatted text.
    """

    def __init__(self, json_output: bool = False):
        super().__init__()
        self.json_output = json_output

    def format(self, record: logging.LogRecord) -> str:
        """Format the log record."""
        # Build base log data
        log_data = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add extra fields if present
        if hasattr(record, "extra_data"):
            log_data.update(record.extra_data)

        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        # Add location info for debug level
        if record.levelno == logging.DEBUG:
            log_data["location"] = f"{record.filename}:{record.lineno}"

        if self.json_output:
            import json
            return json.dumps(log_data, default=str)
        else:
            # Human-readable format
            level_colors = {
                "DEBUG": "\033[36m",    # Cyan
                "INFO": "\033[32m",     # Green
                "WARNING": "\033[33m",  # Yellow
                "ERROR": "\033[31m",    # Red
                "CRITICAL": "\033[35m", # Magenta
            }
            reset = "\033[0m"

            # Only use colors if output is a TTY
            use_color = sys.stderr.isatty()

            if use_color:
                level_str = f"{level_colors.get(record.levelname, '')}{record.levelname:8}{reset}"
            else:
                level_str = f"{record.levelname:8}"

            msg = f"[{log_data['timestamp'][:19]}] {level_str} {record.name}: {log_data['message']}"

            if record.exc_info:
                msg += f"\n{log_data['exception']}"

            return msg


def get_logger(name: str = "goquality") -> logging.Logger:
    """
    Get a configured logger instance.

    Args:
        name: Logger name (default: goquality)

    Returns:
        Configured logger
    """
    global _logger

    if _logger is not None and name == "goquality":
        return _logger

    logger = logging.getLogger(name)

    # Only configure if not already configured
    if not logger.handlers:
        configure_logging()

    if name == "goquality":
        _logger = logger

    return logger


def configure_logging(
    level: str | LogLevel | None = None,
    json_output: bool | None = None,
) -> None:
    """
    Configure logging for the application.

    Args:
        level: Log level (default: from GOQUALITY_LOG_LEVEL env or INFO)
        json_output: Whether to output JSON (default: from GOQUALITY_LOG_JSON env or False)
    """
    # Determine settings from environment or arguments
    if level is None:
        level = os.environ.get("GOQUALITY_LOG_LEVEL", "INFO")
    if isinstance(level, LogLevel):
        level = level.value

    if json_output is None:
        json_output = os.environ.get("GOQUALITY_LOG_JSON", "").lower() in ("true", "1", "yes")

    # Get the root goquality logger
    logger = logging.getLogger("goquality")
    logger.setLevel(getattr(logging, level.upper()))

    # Remove existing handlers
    logger.handlers.clear()

    # Create handler
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(StructuredFormatter(json_output=json_output))
    logger.addHandler(handler)

    # Don't propagate to root logger
    logger.propagate = False


class LogContext:
    """
    Context manager for adding extra data to log messages.

    Usage:
        with LogContext(operation="validate", table="users"):
            logger.info("Starting validation")
    """

    def __init__(self, **kwargs: Any):
        self.extra = kwargs
        self.logger = get_logger()
        self._old_factory = None

    def __enter__(self) -> "LogContext":
        # Store old factory
        self._old_factory = logging.getLogRecordFactory()

        # Create new factory that adds our extra data
        extra = self.extra
        old_factory = self._old_factory

        def record_factory(*args, **kwargs):
            record = old_factory(*args, **kwargs)
            record.extra_data = getattr(record, 'extra_data', {})
            record.extra_data.update(extra)
            return record

        logging.setLogRecordFactory(record_factory)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        # Restore old factory
        if self._old_factory:
            logging.setLogRecordFactory(self._old_factory)


def log_operation(
    operation: str,
    **kwargs: Any,
) -> LogContext:
    """
    Create a logging context for an operation.

    Args:
        operation: Name of the operation being performed
        **kwargs: Additional context data

    Returns:
        LogContext context manager
    """
    return LogContext(operation=operation, **kwargs)
