"""
Error handling and custom exceptions for GoQuality.

Provides:
- Custom exception hierarchy
- Error recovery utilities
- Graceful degradation helpers
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, TypeVar

from goquality.logging import get_logger

logger = get_logger(__name__)

T = TypeVar("T")


class ErrorSeverity(str, Enum):
    """Severity levels for errors."""
    WARNING = "warning"      # Non-blocking, can continue
    ERROR = "error"          # Blocking for this item, can skip
    CRITICAL = "critical"    # Fatal, must stop


class GoQualityError(Exception):
    """Base exception for all GoQuality errors."""

    severity: ErrorSeverity = ErrorSeverity.ERROR

    def __init__(
        self,
        message: str,
        details: dict[str, Any] | None = None,
        cause: Exception | None = None,
    ):
        self.message = message
        self.details = details or {}
        self.cause = cause
        super().__init__(message)

    def to_dict(self) -> dict[str, Any]:
        """Convert error to dictionary for JSON serialization."""
        return {
            "error_type": self.__class__.__name__,
            "severity": self.severity.value,
            "message": self.message,
            "details": self.details,
            "cause": str(self.cause) if self.cause else None,
        }


class ConfigurationError(GoQualityError):
    """Error in configuration file or settings."""
    severity = ErrorSeverity.CRITICAL


class ConnectionError(GoQualityError):
    """Database connection error."""
    severity = ErrorSeverity.CRITICAL


class ValidationError(GoQualityError):
    """Validation rule error."""
    severity = ErrorSeverity.ERROR


class TypeResolutionError(GoQualityError):
    """Error resolving type definition."""
    severity = ErrorSeverity.ERROR


class ColumnValidationError(GoQualityError):
    """Error validating a specific column."""
    severity = ErrorSeverity.WARNING  # Can skip and continue


class TableValidationError(GoQualityError):
    """Error validating a table."""
    severity = ErrorSeverity.WARNING  # Can skip and continue


class LLMError(GoQualityError):
    """Error communicating with LLM provider."""
    severity = ErrorSeverity.ERROR


class RateLimitError(LLMError):
    """Rate limit exceeded for LLM API."""
    severity = ErrorSeverity.WARNING  # Can retry


@dataclass
class ErrorCollector:
    """
    Collects errors during operations for graceful degradation.

    Instead of failing on first error, collect all errors and
    report them at the end, allowing partial completion.

    Usage:
        collector = ErrorCollector()
        for table in tables:
            try:
                validate(table)
            except Exception as e:
                collector.add(e, context={"table": table})

        if collector.has_errors:
            collector.report()
    """

    errors: list[tuple[Exception, dict[str, Any]]] = field(default_factory=list)
    warnings: list[tuple[Exception, dict[str, Any]]] = field(default_factory=list)

    def add(
        self,
        error: Exception,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Add an error to the collector."""
        context = context or {}

        # Determine severity
        if isinstance(error, GoQualityError):
            if error.severity == ErrorSeverity.WARNING:
                self.warnings.append((error, context))
                logger.warning(f"{error.message}", extra={"context": context})
            else:
                self.errors.append((error, context))
                logger.error(f"{error.message}", extra={"context": context})
        else:
            # Treat unknown exceptions as errors
            self.errors.append((error, context))
            logger.error(f"Unexpected error: {error}", extra={"context": context})

    @property
    def has_errors(self) -> bool:
        """Check if any errors were collected."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if any warnings were collected."""
        return len(self.warnings) > 0

    @property
    def error_count(self) -> int:
        """Get number of errors."""
        return len(self.errors)

    @property
    def warning_count(self) -> int:
        """Get number of warnings."""
        return len(self.warnings)

    def get_summary(self) -> dict[str, Any]:
        """Get summary of collected errors."""
        return {
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "errors": [
                {
                    "type": type(e).__name__,
                    "message": str(e),
                    "context": ctx,
                }
                for e, ctx in self.errors
            ],
            "warnings": [
                {
                    "type": type(e).__name__,
                    "message": str(e),
                    "context": ctx,
                }
                for e, ctx in self.warnings
            ],
        }

    def raise_if_errors(self, message: str = "Operation completed with errors") -> None:
        """Raise an exception if errors were collected."""
        if self.has_errors:
            raise GoQualityError(
                message=f"{message}: {self.error_count} error(s)",
                details=self.get_summary(),
            )


def with_error_handling(
    operation_name: str,
    on_error: Callable[[Exception], T] | None = None,
    reraise: bool = True,
) -> Callable[[Callable[..., T]], Callable[..., T | None]]:
    """
    Decorator for adding error handling to functions.

    Args:
        operation_name: Name of operation for logging
        on_error: Callback to call on error (returns fallback value)
        reraise: Whether to re-raise the exception after handling

    Usage:
        @with_error_handling("validate_column", on_error=lambda e: None)
        def validate_column(col):
            ...
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T | None]:
        def wrapper(*args, **kwargs) -> T | None:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(
                    f"Error in {operation_name}: {e}",
                    exc_info=True,
                )

                if on_error is not None:
                    return on_error(e)

                if reraise:
                    raise

                return None

        return wrapper

    return decorator


def safe_execute(
    func: Callable[..., T],
    *args,
    default: T | None = None,
    error_collector: ErrorCollector | None = None,
    context: dict[str, Any] | None = None,
    **kwargs,
) -> T | None:
    """
    Safely execute a function, returning default on error.

    Args:
        func: Function to execute
        *args: Positional arguments
        default: Default value on error
        error_collector: Optional collector for errors
        context: Context for error logging
        **kwargs: Keyword arguments

    Returns:
        Function result or default on error
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        if error_collector is not None:
            error_collector.add(e, context=context)
        else:
            logger.warning(f"Error executing {func.__name__}: {e}")
        return default
