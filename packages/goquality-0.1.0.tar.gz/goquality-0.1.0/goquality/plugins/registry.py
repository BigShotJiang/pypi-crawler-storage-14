"""
Plugin Registry and Discovery.

Provides functions for registering and discovering plugins.
"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable

from goquality.plugins.base import Plugin, PluginManager, ValidatorPlugin
from goquality.plugins.validators import PythonValidator, ValidatorRegistry

# Global plugin manager instance
_plugin_manager: PluginManager | None = None


def get_plugin_manager() -> PluginManager:
    """Get the global plugin manager instance."""
    global _plugin_manager
    if _plugin_manager is None:
        _plugin_manager = PluginManager()
        _load_builtin_validators()
    return _plugin_manager


def register_plugin(plugin: Plugin) -> None:
    """
    Register a plugin with the global manager.

    Args:
        plugin: Plugin instance
    """
    manager = get_plugin_manager()
    manager.register(plugin)


def register_validator(
    name: str | None = None,
    description: str = "",
    tags: list[str] | None = None,
) -> Callable:
    """
    Decorator to register a function as a validator.

    Usage:
        @register_validator("is_even", description="Check if number is even")
        def is_even(value: int) -> bool:
            return value % 2 == 0

    Args:
        name: Validator name (uses function name if None)
        description: Description
        tags: Optional tags

    Returns:
        Decorator function
    """
    def decorator(func: Callable[[Any], bool]) -> Callable[[Any], bool]:
        validator_name = name or func.__name__
        validator = PythonValidator(
            name=validator_name,
            validate_func=func,
            description=description or func.__doc__ or "",
            tags=tags or [],
        )

        # Store validator on function for later discovery
        func._goquality_validator = validator  # type: ignore

        # Register with global manager
        try:
            register_plugin(validator)
        except ValueError:
            # Already registered
            pass

        # Also register with validator registry
        ValidatorRegistry.get_instance().register(validator)

        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator


def load_plugins(path: str | None = None) -> list[Plugin]:
    """
    Load plugins from a directory or module.

    Args:
        path: Path to plugins directory (uses default locations if None)

    Returns:
        List of loaded plugins
    """
    manager = get_plugin_manager()

    if path:
        return manager.load_from_directory(path)

    # Load from default locations
    default_paths = [
        ".goquality/plugins",
        "goquality_plugins",
    ]

    loaded = []
    for default_path in default_paths:
        try:
            loaded.extend(manager.load_from_directory(default_path))
        except Exception:
            pass

    return loaded


def get_validator(name: str) -> ValidatorPlugin | None:
    """
    Get a validator by name.

    Args:
        name: Validator name

    Returns:
        ValidatorPlugin or None
    """
    manager = get_plugin_manager()
    return manager.get_validator(name)


def list_validators() -> list[str]:
    """
    List all registered validators.

    Returns:
        List of validator names
    """
    manager = get_plugin_manager()
    return manager.list_validators()


def _load_builtin_validators() -> None:
    """Load built-in validators."""
    from goquality.plugins.builtin import register_builtin_validators
    register_builtin_validators()
