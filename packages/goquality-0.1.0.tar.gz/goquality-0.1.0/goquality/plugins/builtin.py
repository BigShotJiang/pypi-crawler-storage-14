"""
Built-in Validators.

Provides commonly needed validation functions that go beyond simple regex.
"""

from __future__ import annotations

from typing import Any

from goquality.plugins.validators import PythonValidator, ValidatorRegistry


def luhn_checksum(value: Any) -> bool:
    """
    Validate a number using the Luhn algorithm (mod 10).

    Used for:
    - Credit card numbers
    - IMEI numbers
    - Canadian Social Insurance Numbers
    - National Provider Identifier (NPI)

    Args:
        value: String of digits to validate

    Returns:
        True if valid Luhn checksum
    """
    if value is None:
        return True

    # Remove spaces and dashes
    digits = str(value).replace(" ", "").replace("-", "")

    if not digits.isdigit():
        return False

    if len(digits) < 2:
        return False

    # Luhn algorithm
    total = 0
    for i, digit in enumerate(reversed(digits)):
        n = int(digit)
        if i % 2 == 1:  # Every second digit from the right
            n *= 2
            if n > 9:
                n -= 9
        total += n

    return total % 10 == 0


def iban_checksum(value: Any) -> bool:
    """
    Validate an IBAN (International Bank Account Number) checksum.

    Validates:
    - Country code (2 letters)
    - Check digits (2 digits)
    - BBAN (Basic Bank Account Number)

    Args:
        value: IBAN string

    Returns:
        True if valid IBAN checksum
    """
    if value is None:
        return True

    # Remove spaces
    iban = str(value).upper().replace(" ", "")

    if len(iban) < 4:
        return False

    # Check format: 2 letters + 2 digits + alphanumeric
    if not iban[:2].isalpha() or not iban[2:4].isdigit():
        return False

    # Move first 4 chars to end and convert letters to numbers
    rearranged = iban[4:] + iban[:4]
    numeric = ""
    for char in rearranged:
        if char.isdigit():
            numeric += char
        elif char.isalpha():
            # A=10, B=11, ..., Z=35
            numeric += str(ord(char) - 55)
        else:
            return False

    # Check if mod 97 == 1
    return int(numeric) % 97 == 1


def isbn10_checksum(value: Any) -> bool:
    """
    Validate an ISBN-10 checksum.

    Args:
        value: ISBN-10 string (with or without dashes)

    Returns:
        True if valid ISBN-10 checksum
    """
    if value is None:
        return True

    # Remove dashes and spaces
    isbn = str(value).replace("-", "").replace(" ", "").upper()

    if len(isbn) != 10:
        return False

    # Check digits (last can be X)
    for i, char in enumerate(isbn):
        if i == 9 and char == "X":
            continue
        if not char.isdigit():
            return False

    # Calculate checksum
    total = 0
    for i, char in enumerate(isbn):
        if char == "X":
            digit = 10
        else:
            digit = int(char)
        total += digit * (10 - i)

    return total % 11 == 0


def isbn13_checksum(value: Any) -> bool:
    """
    Validate an ISBN-13 checksum (same as EAN-13).

    Args:
        value: ISBN-13 string

    Returns:
        True if valid ISBN-13 checksum
    """
    if value is None:
        return True

    # Remove dashes and spaces
    isbn = str(value).replace("-", "").replace(" ", "")

    if len(isbn) != 13 or not isbn.isdigit():
        return False

    # Must start with 978 or 979
    if not isbn.startswith(("978", "979")):
        return False

    # Calculate checksum
    total = 0
    for i, char in enumerate(isbn):
        digit = int(char)
        if i % 2 == 0:
            total += digit
        else:
            total += digit * 3

    return total % 10 == 0


def ean13_checksum(value: Any) -> bool:
    """
    Validate an EAN-13 barcode checksum.

    Args:
        value: EAN-13 string

    Returns:
        True if valid EAN-13 checksum
    """
    if value is None:
        return True

    ean = str(value).replace(" ", "")

    if len(ean) != 13 or not ean.isdigit():
        return False

    # Calculate checksum (same algorithm as ISBN-13)
    total = 0
    for i, char in enumerate(ean):
        digit = int(char)
        if i % 2 == 0:
            total += digit
        else:
            total += digit * 3

    return total % 10 == 0


def upc_checksum(value: Any) -> bool:
    """
    Validate a UPC-A barcode checksum.

    Args:
        value: UPC-A string (12 digits)

    Returns:
        True if valid UPC checksum
    """
    if value is None:
        return True

    upc = str(value).replace(" ", "")

    if len(upc) != 12 or not upc.isdigit():
        return False

    # Calculate checksum
    odd_sum = sum(int(upc[i]) for i in range(0, 11, 2))
    even_sum = sum(int(upc[i]) for i in range(1, 11, 2))
    total = odd_sum * 3 + even_sum
    check_digit = (10 - (total % 10)) % 10

    return int(upc[-1]) == check_digit


def is_valid_email_mx(value: Any) -> bool:
    """
    Validate email format (basic check, no DNS/MX lookup).

    More lenient than strict RFC 5322 but catches common issues.

    Args:
        value: Email string

    Returns:
        True if valid email format
    """
    if value is None:
        return True

    import re

    email = str(value).strip().lower()

    # Basic pattern
    pattern = r"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
    if not re.match(pattern, email):
        return False

    # Additional checks
    if ".." in email:  # No consecutive dots
        return False
    if email.count("@") != 1:
        return False

    local, domain = email.split("@")
    if len(local) > 64 or len(domain) > 253:
        return False

    return True


def is_valid_ipv4(value: Any) -> bool:
    """
    Validate IPv4 address format.

    Args:
        value: IP address string

    Returns:
        True if valid IPv4
    """
    if value is None:
        return True

    ip = str(value).strip()
    parts = ip.split(".")

    if len(parts) != 4:
        return False

    for part in parts:
        if not part.isdigit():
            return False
        num = int(part)
        if num < 0 or num > 255:
            return False
        # No leading zeros (except for 0 itself)
        if len(part) > 1 and part[0] == "0":
            return False

    return True


def is_valid_ipv6(value: Any) -> bool:
    """
    Validate IPv6 address format.

    Args:
        value: IPv6 address string

    Returns:
        True if valid IPv6
    """
    if value is None:
        return True

    import re

    ipv6 = str(value).strip().lower()

    # Full pattern for IPv6 (simplified)
    # This handles most common formats including :: compression
    hex_group = r"[0-9a-f]{1,4}"

    patterns = [
        # Full form
        rf"^({hex_group}:){{7}}{hex_group}$",
        # With :: compression
        rf"^({hex_group}:){{0,6}}:({hex_group}:){{0,6}}{hex_group}$",
        rf"^::({hex_group}:){{0,6}}{hex_group}$",
        rf"^({hex_group}:){{0,6}}{hex_group}::$",
        r"^::$",
    ]

    for pattern in patterns:
        if re.match(pattern, ipv6):
            return True

    return False


def is_valid_mac_address(value: Any) -> bool:
    """
    Validate MAC address format.

    Supports:
    - Colon separated (AA:BB:CC:DD:EE:FF)
    - Dash separated (AA-BB-CC-DD-EE-FF)
    - No separator (AABBCCDDEEFF)

    Args:
        value: MAC address string

    Returns:
        True if valid MAC address
    """
    if value is None:
        return True

    import re

    mac = str(value).strip().upper()

    patterns = [
        r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$",
        r"^([0-9A-F]{2}-){5}[0-9A-F]{2}$",
        r"^[0-9A-F]{12}$",
    ]

    for pattern in patterns:
        if re.match(pattern, mac):
            return True

    return False


def is_future_date(value: Any) -> bool:
    """
    Check if date is in the future.

    Args:
        value: Date value (string, date, or datetime)

    Returns:
        True if date is in the future
    """
    if value is None:
        return True

    from datetime import date, datetime

    if isinstance(value, datetime):
        return value.date() > date.today()
    elif isinstance(value, date):
        return value > date.today()
    elif isinstance(value, str):
        # Try to parse ISO format
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.date() > date.today()
        except ValueError:
            return False

    return False


def is_past_date(value: Any) -> bool:
    """
    Check if date is in the past.

    Args:
        value: Date value

    Returns:
        True if date is in the past
    """
    if value is None:
        return True

    from datetime import date, datetime

    if isinstance(value, datetime):
        return value.date() < date.today()
    elif isinstance(value, date):
        return value < date.today()
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.date() < date.today()
        except ValueError:
            return False

    return False


def is_within_n_days(n: int):
    """
    Factory for date validators that check if within N days.

    Args:
        n: Number of days

    Returns:
        Validator function
    """
    def validator(value: Any) -> bool:
        if value is None:
            return True

        from datetime import date, datetime, timedelta

        today = date.today()
        cutoff = today - timedelta(days=n)

        if isinstance(value, datetime):
            return value.date() >= cutoff
        elif isinstance(value, date):
            return value >= cutoff
        elif isinstance(value, str):
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
                return parsed.date() >= cutoff
            except ValueError:
                return False

        return False

    return validator


def is_json(value: Any) -> bool:
    """
    Check if string is valid JSON.

    Args:
        value: String value

    Returns:
        True if valid JSON
    """
    if value is None:
        return True

    import json

    try:
        json.loads(str(value))
        return True
    except (json.JSONDecodeError, TypeError):
        return False


def is_base64(value: Any) -> bool:
    """
    Check if string is valid Base64 encoded.

    Args:
        value: String value

    Returns:
        True if valid Base64
    """
    if value is None:
        return True

    import base64

    try:
        # Remove potential padding issues
        s = str(value).strip()
        # Add padding if needed
        padding = 4 - len(s) % 4
        if padding != 4:
            s += "=" * padding

        base64.b64decode(s, validate=True)
        return True
    except Exception:
        return False


def register_builtin_validators() -> None:
    """Register all built-in validators."""
    registry = ValidatorRegistry.get_instance()

    validators = [
        PythonValidator(
            name="luhn",
            validate_func=luhn_checksum,
            description="Luhn algorithm checksum (credit cards, etc.)",
            tags=["checksum", "finance"],
        ),
        PythonValidator(
            name="iban",
            validate_func=iban_checksum,
            description="IBAN checksum validation",
            tags=["checksum", "finance", "banking"],
        ),
        PythonValidator(
            name="isbn10",
            validate_func=isbn10_checksum,
            description="ISBN-10 checksum validation",
            tags=["checksum", "book"],
        ),
        PythonValidator(
            name="isbn13",
            validate_func=isbn13_checksum,
            description="ISBN-13 checksum validation",
            tags=["checksum", "book"],
        ),
        PythonValidator(
            name="ean13",
            validate_func=ean13_checksum,
            description="EAN-13 barcode checksum",
            tags=["checksum", "barcode"],
        ),
        PythonValidator(
            name="upc",
            validate_func=upc_checksum,
            description="UPC-A barcode checksum",
            tags=["checksum", "barcode"],
        ),
        PythonValidator(
            name="email_format",
            validate_func=is_valid_email_mx,
            description="Email format validation",
            tags=["email", "format"],
        ),
        PythonValidator(
            name="ipv4",
            validate_func=is_valid_ipv4,
            description="IPv4 address format",
            tags=["network", "ip"],
        ),
        PythonValidator(
            name="ipv6",
            validate_func=is_valid_ipv6,
            description="IPv6 address format",
            tags=["network", "ip"],
        ),
        PythonValidator(
            name="mac_address",
            validate_func=is_valid_mac_address,
            description="MAC address format",
            tags=["network"],
        ),
        PythonValidator(
            name="future_date",
            validate_func=is_future_date,
            description="Date must be in the future",
            tags=["date", "temporal"],
        ),
        PythonValidator(
            name="past_date",
            validate_func=is_past_date,
            description="Date must be in the past",
            tags=["date", "temporal"],
        ),
        PythonValidator(
            name="within_30_days",
            validate_func=is_within_n_days(30),
            description="Date within last 30 days",
            tags=["date", "temporal"],
        ),
        PythonValidator(
            name="within_90_days",
            validate_func=is_within_n_days(90),
            description="Date within last 90 days",
            tags=["date", "temporal"],
        ),
        PythonValidator(
            name="within_365_days",
            validate_func=is_within_n_days(365),
            description="Date within last year",
            tags=["date", "temporal"],
        ),
        PythonValidator(
            name="json",
            validate_func=is_json,
            description="Valid JSON string",
            tags=["format", "json"],
        ),
        PythonValidator(
            name="base64",
            validate_func=is_base64,
            description="Valid Base64 encoded string",
            tags=["format", "encoding"],
        ),
    ]

    for validator in validators:
        registry.register(validator)
