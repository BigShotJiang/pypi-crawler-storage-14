"""
Validator Plugin Implementations.

Provides base classes and utilities for creating validation plugins.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

import ibis

from goquality.plugins.base import PluginMetadata, PluginType, ValidatorPlugin

if TYPE_CHECKING:
    from ibis.expr.types import BooleanColumn, Column


class PythonValidator(ValidatorPlugin):
    """
    A validator that uses a Python function.

    This is the simplest way to create a custom validator.
    Validation is performed row-by-row in Python.

    Example:
        def is_palindrome(value: str) -> bool:
            clean = value.lower().replace(" ", "")
            return clean == clean[::-1]

        validator = PythonValidator(
            name="palindrome",
            validate_func=is_palindrome,
            description="Check if string is a palindrome",
        )
    """

    def __init__(
        self,
        name: str,
        validate_func: Callable[[Any], bool],
        description: str = "",
        version: str = "1.0.0",
        tags: list[str] | None = None,
    ):
        self._name = name
        self.validate_func = validate_func
        self._description = description
        self._version = version
        self._tags = tags or []

    @property
    def name(self) -> str:
        return self._name

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name=self._name,
            version=self._version,
            description=self._description,
            plugin_type=PluginType.VALIDATOR,
            tags=self._tags,
        )

    def validate(self, value: Any) -> bool:
        if value is None:
            return True  # NULL values pass by default
        try:
            return self.validate_func(value)
        except Exception:
            return False

    def describe(self) -> str:
        return self._description or f"Python validator: {self._name}"


class SQLValidator(ValidatorPlugin):
    """
    A validator that compiles to SQL.

    More efficient for large datasets as validation happens in the database.

    Example:
        validator = SQLValidator(
            name="positive",
            sql_template="{column} > 0",
            description="Check if value is positive",
        )
    """

    def __init__(
        self,
        name: str,
        sql_template: str,
        description: str = "",
        version: str = "1.0.0",
        tags: list[str] | None = None,
        python_fallback: Callable[[Any], bool] | None = None,
    ):
        self._name = name
        self.sql_template = sql_template
        self._description = description
        self._version = version
        self._tags = tags or []
        self.python_fallback = python_fallback

    @property
    def name(self) -> str:
        return self._name

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name=self._name,
            version=self._version,
            description=self._description,
            plugin_type=PluginType.VALIDATOR,
            tags=self._tags,
        )

    @property
    def supports_sql(self) -> bool:
        return True

    def validate(self, value: Any) -> bool:
        """Python fallback validation."""
        if value is None:
            return True
        if self.python_fallback:
            try:
                return self.python_fallback(value)
            except Exception:
                return False
        raise NotImplementedError(
            f"Validator {self._name} is SQL-only. No Python fallback provided."
        )

    def compile_sql(self, column: "Column") -> "BooleanColumn":
        """Compile to SQL expression."""
        col_name = column.get_name()
        sql = self.sql_template.replace("{column}", col_name)
        # Use Ibis literal SQL
        return ibis.literal(sql).cast("boolean")

    def describe(self) -> str:
        return self._description or f"SQL validator: {self._name}"


class RegexValidator(ValidatorPlugin):
    """
    A validator that uses regex pattern matching.

    Supports both Python and SQL compilation.
    """

    def __init__(
        self,
        name: str,
        pattern: str,
        description: str = "",
        flags: int = 0,
    ):
        self._name = name
        self.pattern = pattern
        self._description = description
        self.flags = flags
        self._compiled_pattern = None

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name=self._name,
            description=self._description,
            plugin_type=PluginType.VALIDATOR,
            tags=["regex", "pattern"],
        )

    @property
    def supports_sql(self) -> bool:
        return True

    def _get_compiled_pattern(self):
        if self._compiled_pattern is None:
            import re
            self._compiled_pattern = re.compile(self.pattern, self.flags)
        return self._compiled_pattern

    def validate(self, value: Any) -> bool:
        if value is None:
            return True
        if not isinstance(value, str):
            value = str(value)
        return bool(self._get_compiled_pattern().match(value))

    def compile_sql(self, column: "Column") -> "BooleanColumn":
        return column.re_search(self.pattern)

    def describe(self) -> str:
        return self._description or f"must match pattern: {self.pattern}"


class ValidatorRegistry:
    """
    Registry for validator plugins.

    Provides a central place to register and look up validators.
    """

    _instance: "ValidatorRegistry | None" = None

    def __init__(self):
        self._validators: dict[str, ValidatorPlugin] = {}

    @classmethod
    def get_instance(cls) -> "ValidatorRegistry":
        """Get the singleton registry instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def register(self, validator: ValidatorPlugin) -> None:
        """Register a validator."""
        self._validators[validator.name] = validator

    def get(self, name: str) -> ValidatorPlugin | None:
        """Get a validator by name."""
        return self._validators.get(name)

    def list(self) -> list[str]:
        """List all registered validators."""
        return list(self._validators.keys())

    def validate(self, name: str, value: Any) -> bool:
        """
        Validate a value using a named validator.

        Args:
            name: Validator name
            value: Value to validate

        Returns:
            Validation result

        Raises:
            ValueError: If validator not found
        """
        validator = self._validators.get(name)
        if validator is None:
            raise ValueError(f"Unknown validator: {name}")
        return validator.validate(value)

    def compile(self, name: str, column: "Column") -> "BooleanColumn":
        """
        Compile a named validator to SQL.

        Args:
            name: Validator name
            column: Ibis column

        Returns:
            Boolean expression

        Raises:
            ValueError: If validator not found
            NotImplementedError: If validator doesn't support SQL
        """
        validator = self._validators.get(name)
        if validator is None:
            raise ValueError(f"Unknown validator: {name}")
        return validator.compile_sql(column)


# Convenience function for creating validators from functions
def create_validator(
    name: str,
    func: Callable[[Any], bool] | None = None,
    sql: str | None = None,
    description: str = "",
    tags: list[str] | None = None,
) -> ValidatorPlugin:
    """
    Create a validator from a function or SQL template.

    Args:
        name: Validator name
        func: Python validation function
        sql: SQL template with {column} placeholder
        description: Description
        tags: Optional tags

    Returns:
        ValidatorPlugin instance
    """
    tags = tags or []

    if sql:
        return SQLValidator(
            name=name,
            sql_template=sql,
            description=description,
            tags=tags,
            python_fallback=func,
        )
    elif func:
        return PythonValidator(
            name=name,
            validate_func=func,
            description=description,
            tags=tags,
        )
    else:
        raise ValueError("Must provide either func or sql")
