"""
GoQuality Plugin System.

Provides extensibility through custom validators and transformations.

Plugin Types:
- Validators: Custom validation logic (Python or SQL)
- Type Extensions: New type definitions
- Connectors: Database connector plugins

Usage:
    # Register a custom validator
    @register_validator("luhn_checksum")
    def luhn_checksum(value: str) -> bool:
        ...

    # In YAML config:
    types:
      - name: CreditCardWithChecksum
        base: String
        validators:
          - luhn_checksum
"""

from goquality.plugins.base import (
    Plugin,
    PluginManager,
    PluginType,
    ValidatorPlugin,
)
from goquality.plugins.registry import (
    get_plugin_manager,
    load_plugins,
    register_plugin,
    register_validator,
)
from goquality.plugins.validators import (
    PythonValidator,
    SQLValidator,
    ValidatorRegistry,
)

__all__ = [
    # Base classes
    "Plugin",
    "PluginType",
    "ValidatorPlugin",
    "PluginManager",
    # Validators
    "PythonValidator",
    "SQLValidator",
    "ValidatorRegistry",
    # Registry functions
    "register_plugin",
    "register_validator",
    "load_plugins",
    "get_plugin_manager",
]
