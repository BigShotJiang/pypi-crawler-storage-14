"""
Plugin System Base Classes.

Defines the core plugin architecture for extending GoQuality.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from ibis.expr.types import BooleanColumn, Column


class PluginType(str, Enum):
    """Types of plugins supported by GoQuality."""
    VALIDATOR = "validator"
    TYPE_EXTENSION = "type_extension"
    CONNECTOR = "connector"
    TRANSFORMATION = "transformation"


@dataclass
class PluginMetadata:
    """Metadata about a plugin."""
    name: str
    version: str = "1.0.0"
    description: str = ""
    author: str = ""
    plugin_type: PluginType = PluginType.VALIDATOR
    tags: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)


class Plugin(ABC):
    """
    Base class for all GoQuality plugins.

    Plugins extend GoQuality's functionality in various ways:
    - Validators: Custom validation logic
    - Type Extensions: New type definitions
    - Connectors: Database connector plugins
    - Transformations: Data transformation logic
    """

    @property
    @abstractmethod
    def metadata(self) -> PluginMetadata:
        """Plugin metadata."""
        pass

    @property
    def name(self) -> str:
        """Plugin name."""
        return self.metadata.name

    @property
    def plugin_type(self) -> PluginType:
        """Plugin type."""
        return self.metadata.plugin_type

    def setup(self) -> None:
        """
        Called when the plugin is loaded.

        Override to perform initialization tasks.
        """
        pass

    def teardown(self) -> None:
        """
        Called when the plugin is unloaded.

        Override to perform cleanup tasks.
        """
        pass

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name}>"


class ValidatorPlugin(Plugin):
    """
    Base class for validation plugins.

    Validation plugins can implement custom validation logic that
    is executed either in Python (row-by-row) or compiled to SQL.

    Example:
        class LuhnValidator(ValidatorPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="luhn",
                    description="Luhn checksum validation",
                    plugin_type=PluginType.VALIDATOR,
                )

            def validate(self, value: str) -> bool:
                # Luhn algorithm implementation
                ...

            def compile_sql(self, column: Column) -> BooleanColumn:
                # SQL implementation (optional)
                raise NotImplementedError
    """

    @property
    def supports_sql(self) -> bool:
        """Whether this validator can be compiled to SQL."""
        return False

    @abstractmethod
    def validate(self, value: Any) -> bool:
        """
        Validate a single value.

        Args:
            value: The value to validate

        Returns:
            True if valid, False if invalid
        """
        pass

    def validate_batch(self, values: list[Any]) -> list[bool]:
        """
        Validate a batch of values.

        Default implementation calls validate() for each value.
        Override for more efficient batch processing.

        Args:
            values: List of values to validate

        Returns:
            List of validation results
        """
        return [self.validate(v) for v in values]

    def compile_sql(self, column: "Column") -> "BooleanColumn":
        """
        Compile validator to SQL expression.

        Override this method to provide SQL-based validation,
        which is more efficient for large datasets.

        Args:
            column: Ibis column to validate

        Returns:
            Boolean expression for validation

        Raises:
            NotImplementedError: If SQL compilation not supported
        """
        raise NotImplementedError(
            f"SQL compilation not supported for {self.name}. "
            "Validation will be performed in Python."
        )

    def describe(self) -> str:
        """Human-readable description of the validation."""
        return self.metadata.description or f"Custom validator: {self.name}"


class PluginManager:
    """
    Manages plugin registration and discovery.

    Usage:
        manager = PluginManager()
        manager.load_plugins("./plugins")
        manager.register(MyValidator())

        validator = manager.get_validator("luhn")
        result = validator.validate("4532015112830366")
    """

    def __init__(self):
        self._plugins: dict[str, Plugin] = {}
        self._validators: dict[str, ValidatorPlugin] = {}
        self._hooks: dict[str, list[Callable]] = {}

    def register(self, plugin: Plugin) -> None:
        """
        Register a plugin.

        Args:
            plugin: Plugin instance to register

        Raises:
            ValueError: If plugin with same name already registered
        """
        if plugin.name in self._plugins:
            raise ValueError(f"Plugin already registered: {plugin.name}")

        plugin.setup()
        self._plugins[plugin.name] = plugin

        if isinstance(plugin, ValidatorPlugin):
            self._validators[plugin.name] = plugin

    def unregister(self, name: str) -> bool:
        """
        Unregister a plugin.

        Args:
            name: Plugin name

        Returns:
            True if unregistered, False if not found
        """
        if name not in self._plugins:
            return False

        plugin = self._plugins[name]
        plugin.teardown()
        del self._plugins[name]

        if name in self._validators:
            del self._validators[name]

        return True

    def get_plugin(self, name: str) -> Plugin | None:
        """Get a plugin by name."""
        return self._plugins.get(name)

    def get_validator(self, name: str) -> ValidatorPlugin | None:
        """Get a validator plugin by name."""
        return self._validators.get(name)

    def list_plugins(self, plugin_type: PluginType | None = None) -> list[str]:
        """
        List registered plugins.

        Args:
            plugin_type: Optional filter by type

        Returns:
            List of plugin names
        """
        if plugin_type is None:
            return list(self._plugins.keys())

        return [
            name for name, plugin in self._plugins.items()
            if plugin.plugin_type == plugin_type
        ]

    def list_validators(self) -> list[str]:
        """List registered validator names."""
        return list(self._validators.keys())

    def load_from_module(self, module) -> list[Plugin]:
        """
        Load plugins from a module.

        Looks for:
        - Plugin subclasses
        - Functions decorated with @register_validator

        Args:
            module: Python module to scan

        Returns:
            List of loaded plugins
        """
        loaded = []

        for name in dir(module):
            obj = getattr(module, name)

            # Check for Plugin subclasses
            if (
                isinstance(obj, type) and
                issubclass(obj, Plugin) and
                obj is not Plugin and
                obj is not ValidatorPlugin
            ):
                try:
                    plugin = obj()
                    self.register(plugin)
                    loaded.append(plugin)
                except Exception:
                    pass

            # Check for decorated validators
            if hasattr(obj, "_goquality_validator"):
                try:
                    self.register(obj._goquality_validator)
                    loaded.append(obj._goquality_validator)
                except Exception:
                    pass

        return loaded

    def load_from_directory(self, path: str) -> list[Plugin]:
        """
        Load plugins from a directory.

        Scans for Python files and loads any Plugin subclasses.

        Args:
            path: Directory path

        Returns:
            List of loaded plugins
        """
        import importlib.util
        from pathlib import Path

        loaded = []
        plugin_dir = Path(path)

        if not plugin_dir.is_dir():
            return loaded

        for py_file in plugin_dir.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            try:
                spec = importlib.util.spec_from_file_location(
                    py_file.stem, py_file
                )
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    loaded.extend(self.load_from_module(module))
            except Exception:
                pass

        return loaded

    def register_hook(self, hook_name: str, callback: Callable) -> None:
        """
        Register a hook callback.

        Hooks allow plugins to extend core functionality at specific points.

        Args:
            hook_name: Name of the hook
            callback: Callback function
        """
        if hook_name not in self._hooks:
            self._hooks[hook_name] = []
        self._hooks[hook_name].append(callback)

    def call_hook(self, hook_name: str, *args, **kwargs) -> list[Any]:
        """
        Call all callbacks registered for a hook.

        Args:
            hook_name: Name of the hook
            *args, **kwargs: Arguments to pass to callbacks

        Returns:
            List of callback results
        """
        callbacks = self._hooks.get(hook_name, [])
        results = []
        for callback in callbacks:
            try:
                result = callback(*args, **kwargs)
                results.append(result)
            except Exception:
                pass
        return results
