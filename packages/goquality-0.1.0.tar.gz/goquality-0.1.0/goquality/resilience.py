"""
Resilience utilities for GoQuality.

Provides:
- Retry logic with exponential backoff
- Rate limiting
- Circuit breaker pattern
- Connection pooling helpers
"""

from __future__ import annotations

import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, TypeVar

from goquality.logging import get_logger

logger = get_logger(__name__)

T = TypeVar("T")


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""

    max_attempts: int = 3
    initial_delay: float = 1.0  # seconds
    max_delay: float = 60.0  # seconds
    exponential_base: float = 2.0
    jitter: bool = True  # Add randomness to prevent thundering herd

    # Exceptions to retry on (empty means retry all)
    retry_exceptions: tuple[type[Exception], ...] = ()

    # Exceptions to never retry on
    fatal_exceptions: tuple[type[Exception], ...] = ()


def calculate_backoff(
    attempt: int,
    config: RetryConfig,
) -> float:
    """
    Calculate delay for next retry attempt.

    Args:
        attempt: Current attempt number (0-indexed)
        config: Retry configuration

    Returns:
        Delay in seconds
    """
    # Exponential backoff
    delay = config.initial_delay * (config.exponential_base ** attempt)

    # Cap at max delay
    delay = min(delay, config.max_delay)

    # Add jitter (±25%)
    if config.jitter:
        jitter_range = delay * 0.25
        delay = delay + random.uniform(-jitter_range, jitter_range)

    return max(0, delay)


def retry(
    config: RetryConfig | None = None,
    max_attempts: int | None = None,
    initial_delay: float | None = None,
    retry_on: tuple[type[Exception], ...] | None = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator for retrying a function with exponential backoff.

    Args:
        config: Full retry configuration
        max_attempts: Override max attempts
        initial_delay: Override initial delay
        retry_on: Specific exceptions to retry on

    Returns:
        Decorated function

    Usage:
        @retry(max_attempts=3, retry_on=(ConnectionError, TimeoutError))
        def connect():
            ...
    """
    if config is None:
        config = RetryConfig()

    # Apply overrides
    if max_attempts is not None:
        config.max_attempts = max_attempts
    if initial_delay is not None:
        config.initial_delay = initial_delay
    if retry_on is not None:
        config.retry_exceptions = retry_on

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_exception: Exception | None = None

            for attempt in range(config.max_attempts):
                try:
                    return func(*args, **kwargs)
                except config.fatal_exceptions:
                    # Never retry these
                    raise
                except Exception as e:
                    last_exception = e

                    # Check if we should retry this exception
                    if config.retry_exceptions:
                        if not isinstance(e, config.retry_exceptions):
                            raise

                    # Check if we have more attempts
                    if attempt + 1 >= config.max_attempts:
                        logger.error(
                            f"All {config.max_attempts} attempts failed for {func.__name__}: {e}"
                        )
                        raise

                    # Calculate delay and wait
                    delay = calculate_backoff(attempt, config)
                    logger.warning(
                        f"Attempt {attempt + 1}/{config.max_attempts} failed "
                        f"for {func.__name__}: {e}. Retrying in {delay:.2f}s..."
                    )
                    time.sleep(delay)

            # Should not reach here, but just in case
            if last_exception:
                raise last_exception
            raise RuntimeError("Retry loop exited unexpectedly")

        return wrapper

    return decorator


def retry_with_backoff(
    func: Callable[..., T],
    *args,
    config: RetryConfig | None = None,
    **kwargs,
) -> T:
    """
    Execute a function with retry logic.

    Args:
        func: Function to execute
        *args: Positional arguments
        config: Retry configuration
        **kwargs: Keyword arguments

    Returns:
        Function result

    Usage:
        result = retry_with_backoff(connect, host="localhost", config=config)
    """
    if config is None:
        config = RetryConfig()

    @retry(config=config)
    def _wrapped():
        return func(*args, **kwargs)

    return _wrapped()


@dataclass
class RateLimiter:
    """
    Token bucket rate limiter.

    Limits the rate of operations to prevent overwhelming external services.

    Usage:
        limiter = RateLimiter(rate=10, per_seconds=60)  # 10 requests per minute

        for item in items:
            limiter.acquire()  # Blocks if rate exceeded
            process(item)
    """

    rate: int  # Number of tokens
    per_seconds: float  # Time period

    # Internal state
    _tokens: float = field(init=False)
    _last_update: float = field(init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False)

    def __post_init__(self):
        self._tokens = float(self.rate)
        self._last_update = time.time()

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - self._last_update

        # Add tokens based on elapsed time
        tokens_to_add = elapsed * (self.rate / self.per_seconds)
        self._tokens = min(self.rate, self._tokens + tokens_to_add)
        self._last_update = now

    def acquire(self, tokens: int = 1, blocking: bool = True, timeout: float | None = None) -> bool:
        """
        Acquire tokens from the bucket.

        Args:
            tokens: Number of tokens to acquire
            blocking: Whether to block until tokens available
            timeout: Maximum time to wait (None = infinite)

        Returns:
            True if tokens acquired, False if not (when not blocking)
        """
        deadline = None
        if timeout is not None:
            deadline = time.time() + timeout

        while True:
            with self._lock:
                self._refill()

                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return True

                if not blocking:
                    return False

                # Calculate wait time
                tokens_needed = tokens - self._tokens
                wait_time = tokens_needed * (self.per_seconds / self.rate)

                # Check deadline
                if deadline is not None:
                    remaining = deadline - time.time()
                    if remaining <= 0:
                        return False
                    wait_time = min(wait_time, remaining)

            time.sleep(wait_time)

    def try_acquire(self, tokens: int = 1) -> bool:
        """
        Try to acquire tokens without blocking.

        Args:
            tokens: Number of tokens to acquire

        Returns:
            True if tokens acquired, False otherwise
        """
        return self.acquire(tokens=tokens, blocking=False)


class RateLimiterRegistry:
    """
    Global registry for rate limiters.

    Provides named rate limiters that can be shared across modules.
    """

    _limiters: dict[str, RateLimiter] = {}
    _lock: threading.Lock = threading.Lock()

    @classmethod
    def get(
        cls,
        name: str,
        rate: int = 60,
        per_seconds: float = 60.0,
    ) -> RateLimiter:
        """
        Get or create a named rate limiter.

        Args:
            name: Limiter name
            rate: Requests per period
            per_seconds: Period in seconds

        Returns:
            RateLimiter instance
        """
        with cls._lock:
            if name not in cls._limiters:
                cls._limiters[name] = RateLimiter(rate=rate, per_seconds=per_seconds)
            return cls._limiters[name]

    @classmethod
    def reset(cls, name: str | None = None) -> None:
        """Reset a limiter or all limiters."""
        with cls._lock:
            if name is None:
                cls._limiters.clear()
            elif name in cls._limiters:
                del cls._limiters[name]


def rate_limited(
    name: str,
    rate: int = 60,
    per_seconds: float = 60.0,
    tokens: int = 1,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator for rate limiting function calls.

    Args:
        name: Limiter name (shared across decorated functions with same name)
        rate: Requests per period
        per_seconds: Period in seconds
        tokens: Tokens consumed per call

    Returns:
        Decorated function

    Usage:
        @rate_limited("openai_api", rate=60, per_seconds=60)
        def call_openai():
            ...
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            limiter = RateLimiterRegistry.get(name, rate=rate, per_seconds=per_seconds)
            limiter.acquire(tokens=tokens)
            return func(*args, **kwargs)

        return wrapper

    return decorator


@dataclass
class CircuitBreaker:
    """
    Circuit breaker pattern implementation.

    Prevents repeated calls to a failing service by "opening" the circuit
    after a threshold of failures.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Failing, requests are rejected immediately
    - HALF_OPEN: Testing if service recovered

    Usage:
        breaker = CircuitBreaker(failure_threshold=5, reset_timeout=60)

        try:
            with breaker:
                result = call_service()
        except CircuitOpenError:
            # Circuit is open, service is failing
            use_fallback()
    """

    failure_threshold: int = 5  # Failures before opening
    success_threshold: int = 2  # Successes to close from half-open
    reset_timeout: float = 60.0  # Seconds before trying again

    # Internal state
    _failures: int = field(default=0, init=False)
    _successes: int = field(default=0, init=False)
    _state: str = field(default="CLOSED", init=False)
    _last_failure_time: float | None = field(default=None, init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False)

    def __enter__(self) -> "CircuitBreaker":
        with self._lock:
            if self._state == "OPEN":
                # Check if we should try again
                if self._last_failure_time is not None:
                    elapsed = time.time() - self._last_failure_time
                    if elapsed >= self.reset_timeout:
                        self._state = "HALF_OPEN"
                        self._successes = 0
                        logger.info("Circuit breaker entering HALF_OPEN state")
                    else:
                        raise CircuitOpenError(
                            f"Circuit is OPEN, will retry in {self.reset_timeout - elapsed:.0f}s"
                        )
                else:
                    raise CircuitOpenError("Circuit is OPEN")

        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        with self._lock:
            if exc_type is not None:
                # Failure
                self._failures += 1
                self._last_failure_time = time.time()

                if self._state == "HALF_OPEN":
                    # Back to open on any failure
                    self._state = "OPEN"
                    logger.warning("Circuit breaker back to OPEN state after failure in HALF_OPEN")
                elif self._failures >= self.failure_threshold:
                    self._state = "OPEN"
                    logger.warning(
                        f"Circuit breaker OPENED after {self._failures} failures"
                    )
            else:
                # Success
                self._successes += 1

                if self._state == "HALF_OPEN":
                    if self._successes >= self.success_threshold:
                        # Close the circuit
                        self._state = "CLOSED"
                        self._failures = 0
                        logger.info("Circuit breaker CLOSED after successful recovery")
                elif self._state == "CLOSED":
                    # Reset failure count on success
                    self._failures = 0

    @property
    def is_open(self) -> bool:
        """Check if circuit is open."""
        return self._state == "OPEN"

    @property
    def state(self) -> str:
        """Get current circuit state."""
        return self._state

    def reset(self) -> None:
        """Reset circuit to closed state."""
        with self._lock:
            self._state = "CLOSED"
            self._failures = 0
            self._successes = 0
            self._last_failure_time = None


class CircuitOpenError(Exception):
    """Raised when circuit breaker is open."""
    pass


@dataclass
class ConnectionPool:
    """
    Simple connection pool for database connections.

    Maintains a pool of reusable connections to avoid
    connection overhead for repeated operations.

    Usage:
        pool = ConnectionPool(
            factory=lambda: create_connection(),
            max_size=10,
        )

        conn = pool.acquire()
        try:
            use_connection(conn)
        finally:
            pool.release(conn)

        # Or using context manager:
        with pool.connection() as conn:
            use_connection(conn)
    """

    factory: Callable[[], Any]  # Creates new connections
    max_size: int = 10
    timeout: float = 30.0  # Seconds to wait for connection

    # Internal state
    _pool: deque = field(default_factory=deque, init=False)
    _size: int = field(default=0, init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False)
    _condition: threading.Condition = field(init=False)

    def __post_init__(self):
        self._condition = threading.Condition(self._lock)

    def acquire(self, timeout: float | None = None) -> Any:
        """
        Acquire a connection from the pool.

        Args:
            timeout: Max time to wait (None uses default)

        Returns:
            Connection object

        Raises:
            TimeoutError: If no connection available within timeout
        """
        if timeout is None:
            timeout = self.timeout

        deadline = time.time() + timeout

        with self._condition:
            while True:
                # Try to get from pool
                if self._pool:
                    return self._pool.popleft()

                # Try to create new
                if self._size < self.max_size:
                    self._size += 1
                    try:
                        return self.factory()
                    except Exception:
                        self._size -= 1
                        raise

                # Wait for release
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise TimeoutError(
                        f"Could not acquire connection within {timeout}s"
                    )

                self._condition.wait(timeout=remaining)

    def release(self, connection: Any) -> None:
        """
        Release a connection back to the pool.

        Args:
            connection: Connection to release
        """
        with self._condition:
            self._pool.append(connection)
            self._condition.notify()

    def connection(self):
        """
        Context manager for connection usage.

        Returns:
            Context manager that yields connection
        """
        return _PooledConnection(self)

    def close_all(self) -> None:
        """Close all connections in the pool."""
        with self._lock:
            while self._pool:
                conn = self._pool.popleft()
                try:
                    if hasattr(conn, 'close'):
                        conn.close()
                    elif hasattr(conn, 'disconnect'):
                        conn.disconnect()
                except Exception:
                    pass
            self._size = 0


class _PooledConnection:
    """Context manager for pooled connections."""

    def __init__(self, pool: ConnectionPool):
        self.pool = pool
        self.connection = None

    def __enter__(self):
        self.connection = self.pool.acquire()
        return self.connection

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connection is not None:
            self.pool.release(self.connection)
            self.connection = None
