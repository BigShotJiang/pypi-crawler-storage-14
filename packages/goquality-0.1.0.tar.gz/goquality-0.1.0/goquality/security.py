"""
Security utilities for GoQuality.

Provides:
- Credential masking
- Safe string handling
- SQL injection prevention
"""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse, urlunparse

__all__ = [
    "mask_credentials",
    "mask_connection_string",
    "mask_dict",
    "is_safe_sql_identifier",
    "sanitize_sql_identifier",
    "quote_sql_identifier",
    "escape_sql_string",
    "build_safe_query",
]


# Patterns for sensitive data that should be masked
SENSITIVE_PATTERNS = [
    # Connection string passwords
    (r"(postgres(?:ql)?://[^:]+:)([^@]+)(@)", r"\1****\3"),
    (r"(snowflake://[^:]+:)([^@]+)(@)", r"\1****\3"),
    (r"(mysql://[^:]+:)([^@]+)(@)", r"\1****\3"),

    # API keys in URLs or strings
    (r"(api[_-]?key[=:]\s*)([^\s&\"']+)", r"\1****"),
    (r"(apikey[=:]\s*)([^\s&\"']+)", r"\1****"),
    (r"(key[=:]\s*)([a-zA-Z0-9_-]{20,})", r"\1****"),

    # Bearer tokens
    (r"(Bearer\s+)([^\s\"']+)", r"\1****"),
    (r"(Authorization[=:]\s*)([^\s\"']+)", r"\1****"),

    # Password fields
    (r"(password[=:]\s*)([^\s&\"']+)", r"\1****", re.IGNORECASE),
    (r"(passwd[=:]\s*)([^\s&\"']+)", r"\1****", re.IGNORECASE),
    (r"(secret[=:]\s*)([^\s&\"']+)", r"\1****", re.IGNORECASE),
    (r"(token[=:]\s*)([^\s&\"']+)", r"\1****", re.IGNORECASE),

    # AWS credentials
    (r"(AKIA[A-Z0-9]{16})", r"****"),
    (r"(aws[_-]?secret[_-]?access[_-]?key[=:]\s*)([^\s&\"']+)", r"\1****", re.IGNORECASE),
]

# SQL identifiers that are safe (alphanumeric + underscore)
SQL_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def mask_credentials(text: str) -> str:
    """
    Mask sensitive credentials in text.

    Args:
        text: Text that may contain credentials

    Returns:
        Text with credentials masked

    Example:
        >>> mask_credentials("postgres://user:secret123@localhost/db")
        'postgres://user:****@localhost/db'
    """
    result = text

    for pattern_tuple in SENSITIVE_PATTERNS:
        if len(pattern_tuple) == 3:
            pattern, replacement, flags = pattern_tuple
            result = re.sub(pattern, replacement, result, flags=flags)
        else:
            pattern, replacement = pattern_tuple
            result = re.sub(pattern, replacement, result)

    return result


def mask_connection_string(conn_str: str) -> str:
    """
    Mask password in a database connection string.

    Args:
        conn_str: Database connection string

    Returns:
        Connection string with password masked

    Example:
        >>> mask_connection_string("postgres://user:mypass@localhost:5432/db")
        'postgres://user:****@localhost:5432/db'
    """
    try:
        parsed = urlparse(conn_str)

        # If there's a password, mask it
        if parsed.password:
            # Reconstruct netloc without password
            if parsed.port:
                netloc = f"{parsed.username}:****@{parsed.hostname}:{parsed.port}"
            else:
                netloc = f"{parsed.username}:****@{parsed.hostname}"

            # Reconstruct URL
            masked = urlunparse((
                parsed.scheme,
                netloc,
                parsed.path,
                parsed.params,
                parsed.query,
                parsed.fragment,
            ))
            return masked

        return conn_str
    except Exception:
        # If parsing fails, use regex fallback
        return mask_credentials(conn_str)


def mask_dict(data: dict[str, Any], sensitive_keys: set[str] | None = None) -> dict[str, Any]:
    """
    Mask sensitive values in a dictionary.

    Args:
        data: Dictionary that may contain sensitive values
        sensitive_keys: Additional keys to mask (default: password, secret, token, key, api_key)

    Returns:
        Dictionary with sensitive values masked
    """
    default_sensitive = {"password", "secret", "token", "key", "api_key", "apikey",
                         "private_key", "credentials", "auth", "authorization"}

    if sensitive_keys:
        default_sensitive.update(sensitive_keys)

    result = {}
    for key, value in data.items():
        key_lower = key.lower()

        if any(s in key_lower for s in default_sensitive):
            if value is not None:
                result[key] = "****"
            else:
                result[key] = None
        elif isinstance(value, dict):
            result[key] = mask_dict(value, sensitive_keys)
        elif isinstance(value, str):
            result[key] = mask_credentials(value)
        else:
            result[key] = value

    return result


def is_safe_sql_identifier(identifier: str) -> bool:
    """
    Check if a string is a safe SQL identifier.

    Safe identifiers contain only alphanumeric characters and underscores,
    and start with a letter or underscore.

    Args:
        identifier: String to check

    Returns:
        True if safe, False otherwise
    """
    if not identifier:
        return False
    return bool(SQL_IDENTIFIER_PATTERN.match(identifier))


def sanitize_sql_identifier(identifier: str) -> str:
    """
    Sanitize a SQL identifier by removing unsafe characters.

    Args:
        identifier: Identifier to sanitize

    Returns:
        Sanitized identifier

    Raises:
        ValueError: If identifier is empty after sanitization
    """
    # Remove any character that's not alphanumeric or underscore
    sanitized = re.sub(r"[^a-zA-Z0-9_]", "", identifier)

    # Ensure it starts with a letter or underscore
    if sanitized and sanitized[0].isdigit():
        sanitized = "_" + sanitized

    if not sanitized:
        raise ValueError(f"Invalid SQL identifier: {identifier}")

    return sanitized


def quote_sql_identifier(identifier: str, dialect: str = "postgres") -> str:
    """
    Safely quote a SQL identifier for use in queries.

    This is the preferred method for including identifiers in SQL
    that may contain special characters.

    Args:
        identifier: Identifier to quote
        dialect: SQL dialect (postgres, snowflake, bigquery, mysql)

    Returns:
        Quoted identifier
    """
    # First validate the identifier doesn't contain quotes
    if '"' in identifier and dialect in ("postgres", "snowflake"):
        raise ValueError(f"Identifier cannot contain quotes: {identifier}")
    if '`' in identifier and dialect in ("mysql", "bigquery"):
        raise ValueError(f"Identifier cannot contain backticks: {identifier}")

    if dialect in ("postgres", "snowflake"):
        # Double-quote for Postgres/Snowflake
        return f'"{identifier}"'
    elif dialect in ("mysql", "bigquery"):
        # Backticks for MySQL/BigQuery
        return f"`{identifier}`"
    else:
        # Default to double-quotes
        return f'"{identifier}"'


def escape_sql_string(value: str) -> str:
    """
    Escape a string value for safe inclusion in SQL.

    Note: Always prefer parameterized queries over string escaping.
    This function is for cases where parameterization is not available.

    Args:
        value: String value to escape

    Returns:
        Escaped string (without surrounding quotes)
    """
    # Escape single quotes by doubling them
    escaped = value.replace("'", "''")
    # Escape backslashes
    escaped = escaped.replace("\\", "\\\\")
    return escaped


def build_safe_query(
    query_template: str,
    identifiers: dict[str, str] | None = None,
    values: dict[str, Any] | None = None,
    dialect: str = "postgres",
) -> str:
    """
    Build a SQL query safely with proper escaping.

    Args:
        query_template: Query template with {identifier_name} placeholders for identifiers
                       and %(value_name)s for values
        identifiers: Dict of identifier names to values (will be quoted)
        values: Dict of value names to values (will be escaped)
        dialect: SQL dialect

    Returns:
        Safe SQL query string

    Example:
        >>> build_safe_query(
        ...     "SELECT * FROM {schema}.{table} WHERE name = %(name)s",
        ...     identifiers={"schema": "public", "table": "users"},
        ...     values={"name": "O'Brien"},
        ... )
        'SELECT * FROM "public"."users" WHERE name = \\'O\\'Brien\\''
    """
    result = query_template

    # Replace identifiers with quoted versions
    if identifiers:
        for name, value in identifiers.items():
            quoted = quote_sql_identifier(value, dialect)
            result = result.replace(f"{{{name}}}", quoted)

    # Replace values with escaped versions
    if values:
        for name, value in values.items():
            if value is None:
                escaped = "NULL"
            elif isinstance(value, str):
                escaped = f"'{escape_sql_string(value)}'"
            elif isinstance(value, bool):
                escaped = "TRUE" if value else "FALSE"
            elif isinstance(value, (int, float)):
                escaped = str(value)
            else:
                escaped = f"'{escape_sql_string(str(value))}'"

            result = result.replace(f"%({name})s", escaped)

    return result
