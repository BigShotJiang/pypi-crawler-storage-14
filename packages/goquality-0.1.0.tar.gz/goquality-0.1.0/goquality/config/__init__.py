"""Configuration management for GoQuality."""

from goquality.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]
