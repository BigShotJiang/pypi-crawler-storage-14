"""
Application Settings.

Uses pydantic-settings for environment variable support.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """GoQuality application settings."""

    # Database
    database_url: Optional[str] = Field(
        None,
        description="Default database connection string",
    )

    # LLM
    llm_provider: str = Field(
        "openai",
        description="LLM provider (openai, anthropic, ollama)",
    )
    openai_api_key: Optional[str] = Field(
        None,
        description="OpenAI API key",
    )
    anthropic_api_key: Optional[str] = Field(
        None,
        description="Anthropic API key",
    )
    ollama_base_url: str = Field(
        "http://localhost:11434",
        description="Ollama API base URL",
    )
    llm_model: Optional[str] = Field(
        None,
        description="LLM model to use (default depends on provider)",
    )

    # Paths
    config_dir: Path = Field(
        Path(".goquality"),
        description="Configuration directory",
    )

    # Behavior
    sample_size: int = Field(
        10,
        description="Number of sample values to collect per column",
    )

    class Config:
        env_prefix = "GOQUALITY_"
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
