"""
Type Inference Generator: Calls LLM and parses results.

Supports multiple providers: OpenAI, Anthropic, Ollama.
Uses a common interface for all providers.

Features:
- Rate limiting to prevent API quota exhaustion
- Retry logic with exponential backoff
- Proper error handling and logging
"""

from __future__ import annotations

import os
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING

import yaml

from goquality.errors import LLMError, RateLimitError
from goquality.logging import get_logger
from goquality.resilience import (
    CircuitBreaker,
    CircuitOpenError,
    RateLimiterRegistry,
    RetryConfig,
    retry,
)

if TYPE_CHECKING:
    from goquality.profiler.schema import DatabaseProfile
    from goquality.schema.models import GoQualityConfig
    from goquality.schema.registry import TypeRegistry

logger = get_logger(__name__)

# Rate limits for different providers (requests per minute)
PROVIDER_RATE_LIMITS = {
    "openai": {"rate": 60, "per_seconds": 60},      # 60 RPM for GPT-4
    "anthropic": {"rate": 50, "per_seconds": 60},   # 50 RPM for Claude
    "ollama": {"rate": 120, "per_seconds": 60},     # Local, more generous
}

# Retry configuration for LLM calls
LLM_RETRY_CONFIG = RetryConfig(
    max_attempts=3,
    initial_delay=2.0,
    max_delay=30.0,
    jitter=True,
    retry_exceptions=(Exception,),
    fatal_exceptions=(ValueError, ImportError),
)


@dataclass
class LLMConfig:
    """LLM provider configuration."""

    provider: str = "openai"  # openai, anthropic, ollama
    model: str = "gpt-4o"
    api_key: str | None = None
    base_url: str | None = None  # For Ollama or custom endpoints
    temperature: float = 0.1
    max_tokens: int = 4096

    # Rate limiting
    rate_limit: int | None = None  # Requests per minute (None = use default)

    # Retry settings
    max_retries: int = 3
    retry_delay: float = 2.0

    @classmethod
    def from_env(cls, provider: str = "openai") -> "LLMConfig":
        """Create config from environment variables."""
        if provider == "openai":
            return cls(
                provider="openai",
                model=os.getenv("OPENAI_MODEL", "gpt-4o"),
                api_key=os.getenv("OPENAI_API_KEY"),
                rate_limit=int(os.getenv("OPENAI_RATE_LIMIT", "60")),
            )
        elif provider == "anthropic":
            return cls(
                provider="anthropic",
                model=os.getenv("ANTHROPIC_MODEL", "claude-3-sonnet-20240229"),
                api_key=os.getenv("ANTHROPIC_API_KEY"),
                rate_limit=int(os.getenv("ANTHROPIC_RATE_LIMIT", "50")),
            )
        elif provider == "ollama":
            return cls(
                provider="ollama",
                model=os.getenv("OLLAMA_MODEL", "llama3"),
                base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
                rate_limit=int(os.getenv("OLLAMA_RATE_LIMIT", "120")),
            )
        else:
            raise ValueError(f"Unknown provider: {provider}")


class LLMClient(ABC):
    """Abstract base class for LLM clients."""

    def __init__(self, config: LLMConfig):
        self.config = config
        self._circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            success_threshold=2,
            reset_timeout=60.0,
        )

    @abstractmethod
    def _generate_impl(self, system: str, user: str) -> str:
        """Internal implementation of generate."""
        pass

    def generate(self, system: str, user: str) -> str:
        """
        Generate a response from the LLM with rate limiting and retry.

        Args:
            system: System prompt
            user: User prompt

        Returns:
            Generated response text

        Raises:
            LLMError: If generation fails after retries
            CircuitOpenError: If circuit breaker is open
        """
        # Get rate limiter for this provider
        rate_config = PROVIDER_RATE_LIMITS.get(
            self.config.provider,
            {"rate": 60, "per_seconds": 60}
        )
        if self.config.rate_limit:
            rate_config["rate"] = self.config.rate_limit

        limiter = RateLimiterRegistry.get(
            f"llm_{self.config.provider}",
            rate=rate_config["rate"],
            per_seconds=rate_config["per_seconds"],
        )

        # Acquire rate limit token
        logger.debug(f"Acquiring rate limit token for {self.config.provider}")
        limiter.acquire()

        # Execute with circuit breaker
        try:
            with self._circuit_breaker:
                return self._generate_with_retry(system, user)
        except CircuitOpenError:
            logger.error(f"Circuit breaker open for {self.config.provider}")
            raise LLMError(
                message=f"LLM service {self.config.provider} is temporarily unavailable",
                details={"provider": self.config.provider},
            )

    @retry(config=LLM_RETRY_CONFIG)
    def _generate_with_retry(self, system: str, user: str) -> str:
        """Generate with retry logic."""
        try:
            logger.debug(f"Calling {self.config.provider} API with model {self.config.model}")
            result = self._generate_impl(system, user)
            logger.debug(f"Received response from {self.config.provider}")
            return result
        except Exception as e:
            error_str = str(e).lower()

            # Check for rate limit errors
            if "rate" in error_str and "limit" in error_str:
                logger.warning(f"Rate limit hit for {self.config.provider}")
                raise RateLimitError(
                    message=f"Rate limit exceeded for {self.config.provider}",
                    details={"provider": self.config.provider},
                    cause=e,
                )

            logger.error(f"LLM error from {self.config.provider}: {e}")
            raise LLMError(
                message=f"Failed to generate response from {self.config.provider}",
                details={"provider": self.config.provider, "model": self.config.model},
                cause=e,
            )


class OpenAIClient(LLMClient):
    """OpenAI API client with rate limiting and retry."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)

        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("openai package required. Install with: pip install openai")

        if not config.api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable.")

        self.client = OpenAI(api_key=config.api_key)

    def _generate_impl(self, system: str, user: str) -> str:
        response = self.client.chat.completions.create(
            model=self.config.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        )
        return response.choices[0].message.content or ""


class AnthropicClient(LLMClient):
    """Anthropic API client with rate limiting and retry."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)

        try:
            from anthropic import Anthropic
        except ImportError:
            raise ImportError("anthropic package required. Install with: pip install anthropic")

        if not config.api_key:
            raise ValueError(
                "Anthropic API key is required. Set ANTHROPIC_API_KEY env var."
            )

        self.client = Anthropic(api_key=config.api_key)

    def _generate_impl(self, system: str, user: str) -> str:
        response = self.client.messages.create(
            model=self.config.model,
            system=system,
            messages=[{"role": "user", "content": user}],
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        )
        return response.content[0].text


class OllamaClient(LLMClient):
    """Ollama local LLM client with rate limiting and retry."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)

        import importlib.util
        if importlib.util.find_spec("httpx") is None:
            raise ImportError("httpx package required. Install with: pip install httpx")

        self.base_url = config.base_url or "http://localhost:11434"

    def _generate_impl(self, system: str, user: str) -> str:
        import httpx

        response = httpx.post(
            f"{self.base_url}/api/generate",
            json={
                "model": self.config.model,
                "system": system,
                "prompt": user,
                "stream": False,
                "options": {
                    "temperature": self.config.temperature,
                },
            },
            timeout=120.0,
        )
        response.raise_for_status()
        return response.json().get("response", "")


def create_llm_client(config: LLMConfig) -> LLMClient:
    """Factory function to create appropriate LLM client."""
    if config.provider == "openai":
        return OpenAIClient(config)
    elif config.provider == "anthropic":
        return AnthropicClient(config)
    elif config.provider == "ollama":
        return OllamaClient(config)
    else:
        raise ValueError(f"Unknown provider: {config.provider}")


def extract_yaml_from_response(response: str) -> str:
    """Extract YAML content from LLM response."""
    # Try to find YAML in code blocks
    yaml_pattern = r"```(?:yaml)?\s*([\s\S]*?)```"
    matches = re.findall(yaml_pattern, response)

    if matches:
        # Return the largest match (most likely the full config)
        return max(matches, key=len).strip()

    # If no code blocks, assume entire response is YAML
    return response.strip()


class TypeInferenceGenerator:
    """
    Generates type mappings using LLM inference.

    Features:
    - Rate limiting to prevent API quota exhaustion
    - Retry logic with exponential backoff
    - Circuit breaker for failing services
    - Proper error handling and logging

    Usage:
        generator = TypeInferenceGenerator(config)
        config_yaml = generator.generate(registry, profile)
    """

    def __init__(self, config: LLMConfig | None = None):
        self.config = config or LLMConfig.from_env()
        self.client = create_llm_client(self.config)
        logger.info(f"Initialized type inference generator with {self.config.provider}")

    def generate(
        self,
        registry: "TypeRegistry",
        profile: "DatabaseProfile",
    ) -> str:
        """
        Generate type mappings from database profile.

        Args:
            registry: Type registry with stdlib types
            profile: Database profile with columns and samples

        Returns:
            YAML string with types and model mappings

        Raises:
            LLMError: If generation fails
        """
        from goquality.inference.prompt import build_inference_prompt

        logger.info(
            f"Generating type mappings for {profile.total_tables} tables, "
            f"{profile.total_columns} columns"
        )

        system_prompt, user_prompt = build_inference_prompt(registry, profile)

        try:
            response = self.client.generate(system_prompt, user_prompt)
            logger.info("Successfully generated type mappings")
            return extract_yaml_from_response(response)
        except LLMError:
            raise
        except Exception as e:
            logger.error(f"Failed to generate type mappings: {e}")
            raise LLMError(
                message="Failed to generate type mappings",
                details={
                    "provider": self.config.provider,
                    "tables": profile.total_tables,
                    "columns": profile.total_columns,
                },
                cause=e,
            )

    def generate_and_parse(
        self,
        registry: "TypeRegistry",
        profile: "DatabaseProfile",
    ) -> "GoQualityConfig":
        """
        Generate and parse type mappings.

        Returns a validated GoQualityConfig object.

        Raises:
            LLMError: If generation fails
            ValueError: If parsing fails
        """
        from goquality.schema.models import GoQualityConfig

        yaml_str = self.generate(registry, profile)

        try:
            data = yaml.safe_load(yaml_str)
            return GoQualityConfig(**data)
        except Exception as e:
            logger.error(f"Failed to parse generated YAML: {e}")
            raise ValueError(f"Failed to parse generated type mappings: {e}")
