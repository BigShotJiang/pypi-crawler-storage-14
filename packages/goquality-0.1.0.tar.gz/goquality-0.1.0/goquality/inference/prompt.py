"""
Prompt Builder: Constructs prompts for AI type inference.

The prompt includes:
1. The type library (as a menu to choose from)
2. The database profile (columns + samples)
3. Instructions for matching and creating types
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from goquality.profiler.schema import DatabaseProfile
    from goquality.schema.registry import TypeRegistry


SYSTEM_PROMPT = """You are a data governance expert. \
Your task is to assign semantic types to database columns.

You will be given:
1. A library of pre-defined types (use these when possible)
2. A database profile with column metadata and sample values

Your job is to:
1. Match each column to an existing type from the library
2. Create new types only when no library type fits
3. Explain your reasoning briefly

Rules:
- Prefer library types over creating new ones (consistency)
- Use column names as hints (e.g., "user_email" → Email)
- Use sample values to verify your choice
- For low-cardinality strings (<20 distinct), create an enum type
- Mark confidence: high, medium, or needs_review"""


def format_type_library(registry: "TypeRegistry") -> str:
    """Format the type library as a concise menu for the LLM."""
    lines = ["## Available Types (Standard Library)\n"]
    lines.append("| Type | Base | Description |")
    lines.append("|------|------|-------------|")

    for type_name in sorted(registry.list_types()):
        type_def = registry.get_type(type_name)
        if type_def and not type_def.deprecated:
            # Truncate description if too long
            desc = type_def.description
            if len(desc) > 60:
                desc = desc[:60] + "..."
            lines.append(f"| {type_name} | {type_def.base.value} | {desc} |")

    return "\n".join(lines)


def format_database_profile(profile: "DatabaseProfile") -> str:
    """Format the database profile for the LLM."""
    lines = ["## Database Profile\n"]

    for table in profile.tables:
        lines.append(f"### Table: {table.full_name}")
        lines.append(f"Rows: {table.row_count:,}\n")
        lines.append("| Column | Type | Nullable | Samples | Distinct | Null% |")
        lines.append("|--------|------|----------|---------|----------|-------|")

        for col in table.columns:
            samples = ", ".join(str(v)[:20] for v in col.sample_values[:3])
            if len(col.sample_values) > 3:
                samples += ", ..."
            samples = f'"{samples}"' if samples else "(empty)"

            null_pct = f"{col.null_ratio * 100:.1f}%" if col.total_rows > 0 else "N/A"

            lines.append(
                f"| {col.name} | {col.db_type} | {'Yes' if col.nullable else 'No'} | "
                f"{samples} | {col.distinct_count} | {null_pct} |"
            )

        lines.append("")  # Blank line between tables

    return "\n".join(lines)


OUTPUT_FORMAT = """## Output Format

Respond with valid YAML in this exact format:

```yaml
# New types (only if no stdlib type fits)
types:
  - name: MyEnumType
    description: "Brief description"
    base: String
    enum: ["value1", "value2"]

  - name: MyPatternType
    description: "Brief description"
    base: String
    pattern: "^regex$"

# Column mappings
models:
  - table: schema.table_name
    columns:
      - name: column_name
        type: TypeName        # Use stdlib type or new type
        confidence: high      # high, medium, or needs_review

      - name: nullable_column
        type: TypeName
        allow_null: true      # Set true if column has nulls
        confidence: medium
```

Important:
- Only define new types if nothing in the library fits
- Always include confidence level
- Set allow_null: true if null_ratio > 5%
- Use PascalCase for type names"""


def build_inference_prompt(
    registry: "TypeRegistry",
    profile: "DatabaseProfile",
) -> tuple[str, str]:
    """
    Build the complete prompt for type inference.

    Returns:
        Tuple of (system_prompt, user_prompt)
    """
    user_parts = [
        format_type_library(registry),
        "\n---\n",
        format_database_profile(profile),
        "\n---\n",
        OUTPUT_FORMAT,
        "\n---\n",
        "Now analyze the database profile and generate the YAML output.",
    ]

    return SYSTEM_PROMPT, "\n".join(user_parts)
