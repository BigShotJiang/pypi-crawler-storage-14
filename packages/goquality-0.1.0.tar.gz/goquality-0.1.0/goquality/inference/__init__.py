"""
AI Type Inference: Uses LLMs to infer types from database profiles.
"""

from goquality.inference.generator import TypeInferenceGenerator
from goquality.inference.prompt import build_inference_prompt

__all__ = [
    "TypeInferenceGenerator",
    "build_inference_prompt",
]
