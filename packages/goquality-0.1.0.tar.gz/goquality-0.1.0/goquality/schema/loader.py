"""
YAML loader for GoQuality configuration.

Handles loading from:
1. Stdlib types (shipped with package)
2. User config files (goquality.yaml)

DRY principle: One loader function handles all YAML parsing and validation.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import yaml
from pydantic import ValidationError

from goquality.schema.models import GoQualityConfig, TypeDefinition

if TYPE_CHECKING:
    from goquality.schema.registry import TypeRegistry


# Stdlib location relative to this file
STDLIB_DIR = Path(__file__).parent.parent / "stdlib"


def load_yaml(path: Path) -> dict:
    """Load a YAML file and return parsed dict."""
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    return data or {}


def load_types_from_yaml(path: Path) -> list[TypeDefinition]:
    """
    Load type definitions from a YAML file.

    Expected format:
        types:
          - name: Email
            description: ...
            base: String
            pattern: ...
    """
    data = load_yaml(path)

    if "types" not in data:
        return []

    types = []
    for type_data in data["types"]:
        try:
            type_def = TypeDefinition(**type_data)
            types.append(type_def)
        except ValidationError as e:
            raise ValueError(f"Invalid type definition in {path}: {e}")

    return types


def load_config(path: Path | str) -> GoQualityConfig:
    """
    Load a GoQuality configuration file.

    Args:
        path: Path to goquality.yaml

    Returns:
        Validated GoQualityConfig
    """
    path = Path(path)
    data = load_yaml(path)

    try:
        return GoQualityConfig(**data)
    except ValidationError as e:
        raise ValueError(f"Invalid configuration in {path}: {e}")


def load_stdlib(registry: "TypeRegistry") -> int:
    """
    Load all stdlib types into the registry.

    Scans stdlib/ directory for YAML files and loads types from each.

    Returns:
        Number of types loaded
    """
    if not STDLIB_DIR.exists():
        raise FileNotFoundError(f"Stdlib directory not found: {STDLIB_DIR}")

    count = 0

    # Walk through all subdirectories
    for yaml_file in sorted(STDLIB_DIR.rglob("*.yaml")):
        types = load_types_from_yaml(yaml_file)
        registry.register_types(types)
        count += len(types)

    return count


def find_config_file(start_dir: Path | None = None) -> Path | None:
    """
    Find goquality.yaml by searching upward from start_dir.

    Looks for:
    1. goquality.yaml in start_dir
    2. .goquality/config.yaml in start_dir
    3. Recursively in parent directories
    """
    if start_dir is None:
        start_dir = Path.cwd()

    start_dir = Path(start_dir).resolve()

    for directory in [start_dir] + list(start_dir.parents):
        # Check for goquality.yaml
        config_path = directory / "goquality.yaml"
        if config_path.exists():
            return config_path

        # Check for .goquality/config.yaml
        config_path = directory / ".goquality" / "config.yaml"
        if config_path.exists():
            return config_path

    return None


def create_default_config(path: Path) -> None:
    """Create a default goquality.yaml configuration file."""
    default_config = """\
# GoQuality Configuration
# https://goquality.dev/docs

# Custom type definitions (extend or override stdlib)
types: []

# Model mappings (column → type)
models: []
#   - table: public.users
#     columns:
#       - name: email
#         type: Email
#       - name: id
#         type: UUID

# Ad-hoc checks (quick SQL rules)
checks: []
#   - on: orders
#     rules:
#       - "amount > 0"
#       - "created_at <= NOW()"
"""

    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(default_config)
