"""
Type Registry: Resolves type inheritance and composition.

This is the key to DRY - types inherit from parents, and the registry
resolves the full set of validation rules for any type.

Design:
1. Load stdlib types first (base layer)
2. Load custom types (can override/extend stdlib)
3. Resolve inheritance chains
4. Return fully-resolved types for compilation
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from goquality.schema.models import BaseType, TypeDefinition


@dataclass
class ResolvedType:
    """
    A fully-resolved type with all inherited rules applied.

    This is what the compiler uses - no more inheritance to resolve,
    just concrete validation rules.
    """

    name: str
    description: str
    base: BaseType

    # String validations
    pattern: str | None = None
    min_length: int | None = None
    max_length: int | None = None
    not_empty: bool = False

    # Numeric validations
    min: float | None = None
    max: float | None = None
    precision: int | None = None

    # Enum validation
    enum: list[Any] | None = None

    # Nullability
    allow_null: bool = False

    # Table-level validations
    unique: bool = False
    foreign_key: str | None = None  # "table.column" format

    # Lineage tracking
    extends_chain: list[str] = field(default_factory=list)

    def get_validation_rules(self) -> dict[str, Any]:
        """Get all non-null validation rules as dict."""
        rules = {}
        for attr in [
            "pattern", "min_length", "max_length", "not_empty",
            "min", "max", "precision", "enum",
            "unique", "foreign_key"
        ]:
            val = getattr(self, attr)
            if val is not None and val is not False:
                rules[attr] = val
        rules["allow_null"] = self.allow_null
        return rules

    def has_table_rules(self) -> bool:
        """Check if this type has any table-level validation rules."""
        return self.unique or self.foreign_key is not None


class TypeRegistry:
    """
    Registry for type definitions with inheritance resolution.

    Usage:
        registry = TypeRegistry()
        registry.load_stdlib()
        registry.register_types(custom_types)

        resolved = registry.resolve("CorporateEmail")
        # Returns ResolvedType with all inherited rules
    """

    def __init__(self):
        self._types: dict[str, TypeDefinition] = {}
        self._resolved_cache: dict[str, ResolvedType] = {}

    def register(self, type_def: TypeDefinition) -> None:
        """Register a type definition."""
        self._types[type_def.name] = type_def
        # Invalidate cache when types change
        self._resolved_cache.clear()

    def register_types(self, types: list[TypeDefinition]) -> None:
        """Register multiple type definitions."""
        for t in types:
            self.register(t)

    def has_type(self, name: str) -> bool:
        """Check if type exists."""
        return name in self._types

    def get_type(self, name: str) -> TypeDefinition | None:
        """Get raw type definition (before resolution)."""
        return self._types.get(name)

    def list_types(self) -> list[str]:
        """List all registered type names."""
        return sorted(self._types.keys())

    def resolve(self, name: str) -> ResolvedType:
        """
        Resolve a type by applying inheritance chain.

        If type A extends B extends C:
        1. Start with C's rules
        2. Override with B's rules
        3. Override with A's rules

        This means child rules always win (composition).
        """
        if name in self._resolved_cache:
            return self._resolved_cache[name]

        if name not in self._types:
            raise KeyError(f"Unknown type: {name}")

        # Build inheritance chain (child -> parent -> grandparent)
        chain = self._build_chain(name)

        # Resolve by starting from root and applying overrides
        resolved = self._merge_chain(chain)

        self._resolved_cache[name] = resolved
        return resolved

    def _build_chain(self, name: str, seen: set[str] | None = None) -> list[TypeDefinition]:
        """Build inheritance chain from child to root."""
        if seen is None:
            seen = set()

        if name in seen:
            raise ValueError(f"Circular inheritance detected: {name}")
        seen.add(name)

        type_def = self._types[name]
        chain = [type_def]

        if type_def.extends:
            if type_def.extends not in self._types:
                raise KeyError(f"Type '{name}' extends unknown type: {type_def.extends}")
            parent_chain = self._build_chain(type_def.extends, seen)
            chain.extend(parent_chain)

        return chain

    def _merge_chain(self, chain: list[TypeDefinition]) -> ResolvedType:
        """
        Merge inheritance chain into resolved type.

        Chain is [child, parent, grandparent, ...]
        We reverse it to apply root first, then overrides.
        """
        # Start with the root (last in chain)
        root = chain[-1]

        resolved = ResolvedType(
            name=chain[0].name,  # Final name is the child
            description=chain[0].description,  # Final description is child's
            base=root.base,  # Base type comes from root
            extends_chain=[t.name for t in chain],
        )

        # Apply each type's rules, root to child (child overrides)
        for type_def in reversed(chain):
            self._apply_rules(resolved, type_def)

        return resolved

    def _apply_rules(self, resolved: ResolvedType, type_def: TypeDefinition) -> None:
        """Apply a type's rules to resolved type (override if not None)."""
        # String validations - only override if explicitly set
        if type_def.pattern is not None:
            resolved.pattern = type_def.pattern
        if type_def.min_length is not None:
            resolved.min_length = type_def.min_length
        if type_def.max_length is not None:
            resolved.max_length = type_def.max_length
        if type_def.not_empty:
            resolved.not_empty = True

        # Numeric validations
        if type_def.min is not None:
            resolved.min = type_def.min
        if type_def.max is not None:
            resolved.max = type_def.max
        if type_def.precision is not None:
            resolved.precision = type_def.precision

        # Enum validation
        if type_def.enum is not None:
            resolved.enum = type_def.enum

        # Table-level validations
        if type_def.unique:
            resolved.unique = True
        if type_def.foreign_key is not None:
            resolved.foreign_key = type_def.foreign_key

        # Nullability - always takes the child's value
        resolved.allow_null = type_def.allow_null

    def validate_references(self, type_refs: set[str]) -> list[str]:
        """
        Check that all type references can be resolved.

        Returns list of missing type names.
        """
        missing = []
        for ref in type_refs:
            if ref not in self._types:
                missing.append(ref)
        return missing

    def get_types_by_tag(self, tag: str) -> list[str]:
        """Get all types with a specific tag."""
        return [
            name for name, t in self._types.items()
            if tag in t.tags
        ]

    def search_types(self, query: str) -> list[TypeDefinition]:
        """Search types by name or description."""
        query = query.lower()
        return [
            t for t in self._types.values()
            if query in t.name.lower() or query in t.description.lower()
        ]
