"""
Core Pydantic models for GoQuality configuration.

Design principles:
1. TypeDefinition is the source of truth - all validation rules in one place
2. Inheritance via 'extends' field - child types inherit parent rules
3. Composition over duplication - rules combine, don't repeat
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class BaseType(str, Enum):
    """Supported base data types."""
    STRING = "String"
    INTEGER = "Integer"
    DECIMAL = "Decimal"
    BOOLEAN = "Boolean"
    DATE = "Date"
    TIMESTAMP = "Timestamp"


class TypeDefinition(BaseModel):
    """
    A reusable type definition with validation rules.

    This is the core building block. Types can inherit from other types
    via the 'extends' field, composing their validation rules.

    Example:
        types:
          - name: Email
            base: String
            pattern: "^[a-z]+@[a-z]+\\.[a-z]+$"

          - name: CorporateEmail
            extends: Email
            pattern: "^[a-z]+@acme\\.com$"  # Overrides parent pattern
    """

    # Identity
    name: str = Field(..., pattern=r"^[A-Z][a-zA-Z0-9]*$", description="PascalCase type name")
    description: str = Field(..., min_length=1, description="Human-readable description")
    base: BaseType = Field(..., description="Underlying data type")

    # Inheritance - key to composition
    extends: str | None = Field(None, description="Parent type to inherit from")

    # String validations
    pattern: str | None = Field(None, description="Regex pattern for string validation")
    min_length: int | None = Field(None, ge=0, description="Minimum string length")
    max_length: int | None = Field(None, ge=1, description="Maximum string length")
    not_empty: bool = Field(False, description="Reject empty/whitespace strings")

    # Numeric validations
    min: float | None = Field(None, description="Minimum numeric value (inclusive)")
    max: float | None = Field(None, description="Maximum numeric value (inclusive)")
    precision: int | None = Field(None, ge=0, le=18, description="Decimal precision")

    # Enum validation - works for any base type
    enum: list[Any] | None = Field(None, min_length=1, description="Allowed values")

    # Nullability
    allow_null: bool = Field(False, description="Whether NULL values are permitted")

    # Table-level validations (applied during validation phase)
    unique: bool = Field(False, description="Values must be unique (no duplicates)")
    foreign_key: str | None = Field(
        None,
        pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*$",
        description="Reference table.column for foreign key validation"
    )

    # Metadata
    tags: list[str] = Field(default_factory=list, description="Searchable tags")
    examples: list[str] = Field(default_factory=list, description="Example valid values")
    deprecated: bool = Field(False, description="Mark type as deprecated")

    @field_validator("pattern")
    @classmethod
    def validate_pattern(cls, v: str | None) -> str | None:
        """Ensure pattern is valid regex."""
        if v is not None:
            import re
            try:
                re.compile(v)
            except re.error as e:
                raise ValueError(f"Invalid regex pattern: {e}")
        return v

    @model_validator(mode="after")
    def validate_type_constraints(self) -> "TypeDefinition":
        """Ensure validation rules match base type."""
        string_only = {"pattern", "min_length", "max_length", "not_empty"}
        numeric_only = {"min", "max", "precision"}

        if self.base == BaseType.STRING:
            for fld in numeric_only:
                if getattr(self, fld) is not None:
                    raise ValueError(f"Field '{fld}' not valid for String type")
        elif self.base in (BaseType.INTEGER, BaseType.DECIMAL):
            for fld in string_only:
                val = getattr(self, fld)
                # Skip boolean fields that are False
                if val is not None and val is not False:
                    raise ValueError(f"Field '{fld}' not valid for numeric type")
            if self.base == BaseType.INTEGER and self.precision is not None:
                raise ValueError("Field 'precision' not valid for Integer type")

        return self


class ColumnMapping(BaseModel):
    """Maps a database column to a type."""

    name: str = Field(..., description="Column name")
    type: str = Field(..., description="Type reference (stdlib or custom)")

    # Optional overrides
    allow_null: bool | None = Field(None, description="Override type's nullability")
    description: str | None = Field(None, description="Column-specific description")

    # AI metadata
    confidence: str | None = Field(
        None,
        pattern=r"^(high|medium|needs_review)$",
        description="AI confidence level"
    )


class ModelMapping(BaseModel):
    """Maps a database table to typed columns."""

    table: str = Field(..., description="Fully qualified table name (schema.table)")
    columns: list[ColumnMapping] = Field(..., min_length=1)

    @property
    def schema_name(self) -> str | None:
        """Extract schema from table name."""
        parts = self.table.split(".")
        return parts[0] if len(parts) > 1 else None

    @property
    def table_name(self) -> str:
        """Extract table name without schema."""
        return self.table.split(".")[-1]


class CheckRule(BaseModel):
    """
    Ad-hoc SQL check rules (Level 1).

    For quick validation without defining types.
    """

    on: str = Field(..., description="Table to check")
    name: str | None = Field(None, description="Human-readable check name")
    rules: list[str] = Field(..., min_length=1, description="SQL predicates")


class GoQualityConfig(BaseModel):
    """
    Root configuration model.

    Combines:
    - Custom type definitions (extend or override stdlib)
    - Model mappings (column → type)
    - Ad-hoc checks (quick SQL rules)
    """

    types: list[TypeDefinition] = Field(default_factory=list)
    models: list[ModelMapping] = Field(default_factory=list)
    checks: list[CheckRule] = Field(default_factory=list)

    def get_tables(self) -> list[str]:
        """Get all unique table names."""
        tables = {m.table for m in self.models}
        tables.update(c.on for c in self.checks)
        return sorted(tables)

    def get_type_names(self) -> set[str]:
        """Get all custom type names."""
        return {t.name for t in self.types}

    def get_referenced_types(self) -> set[str]:
        """Get all type names referenced in models."""
        refs = set()
        for model in self.models:
            for col in model.columns:
                refs.add(col.type)
        return refs
