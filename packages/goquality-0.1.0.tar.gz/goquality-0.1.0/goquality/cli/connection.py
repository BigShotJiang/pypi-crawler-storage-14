"""
Database Connection Helper.

Parses connection strings and creates Ibis connections.
Supports: PostgreSQL, DuckDB (local files).
"""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

import ibis


def parse_connection_string(conn_str: str) -> dict:
    """
    Parse a connection string into components.

    Supports:
    - postgres://user:pass@host:port/database
    - postgresql://user:pass@host:port/database
    - duckdb://path/to/file.db
    - duckdb://:memory:
    - /path/to/file.csv (DuckDB with CSV)
    - /path/to/file.parquet (DuckDB with Parquet)
    """
    # Check for local file paths
    if conn_str.startswith("/") or conn_str.startswith("./"):
        path = Path(conn_str)
        if path.suffix in (".csv", ".parquet", ".db", ".duckdb"):
            return {"driver": "duckdb", "path": str(path)}
        raise ValueError(f"Unsupported file type: {path.suffix}")

    parsed = urlparse(conn_str)

    if parsed.scheme in ("postgres", "postgresql"):
        return {
            "driver": "postgres",
            "user": parsed.username,
            "password": parsed.password,
            "host": parsed.hostname or "localhost",
            "port": parsed.port or 5432,
            "database": parsed.path.lstrip("/"),
        }
    elif parsed.scheme == "duckdb":
        # Handle different path formats
        path = parsed.path or parsed.netloc
        # Special case for :memory:
        if path == ":memory:" or parsed.netloc == ":memory:":
            return {"driver": "duckdb", "path": ":memory:"}
        return {"driver": "duckdb", "path": path}
    else:
        raise ValueError(f"Unsupported database: {parsed.scheme}")


def connect(conn_str: str) -> ibis.BaseBackend:
    """
    Create an Ibis connection from a connection string.

    Args:
        conn_str: Database connection string

    Returns:
        Ibis backend connection
    """
    config = parse_connection_string(conn_str)
    driver = config.pop("driver")

    if driver == "postgres":
        return ibis.postgres.connect(**config)
    elif driver == "duckdb":
        path = config.get("path", ":memory:")
        conn = ibis.duckdb.connect(path)

        # If path is a CSV or Parquet file, register it
        if path.endswith(".csv"):
            table_name = Path(path).stem
            conn.register(path, table_name=table_name)
        elif path.endswith(".parquet"):
            table_name = Path(path).stem
            conn.register(path, table_name=table_name)

        return conn
    else:
        raise ValueError(f"Unsupported driver: {driver}")


def check_connection(conn_str: str) -> bool:
    """
    Check a database connection.

    Returns True if connection succeeds, raises exception otherwise.
    """
    conn = connect(conn_str)

    # Try to list tables to verify connection works
    conn.list_tables()

    return True
