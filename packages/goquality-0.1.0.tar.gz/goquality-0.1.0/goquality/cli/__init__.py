"""
GoQuality CLI.
"""

from goquality.cli.main import app

__all__ = ["app"]
