"""
Database Profiler: Extracts schema and statistics for AI inference.
"""

from goquality.profiler.schema import (
    ColumnProfile,
    DatabaseProfile,
    TableProfile,
    profile_database,
)

__all__ = [
    "ColumnProfile",
    "TableProfile",
    "DatabaseProfile",
    "profile_database",
]
