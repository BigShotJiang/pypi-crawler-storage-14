"""
Database Schema Profiler.

Extracts table/column metadata and sample values for AI type inference.
Designed to minimize data exposure while providing enough context for good inference.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import ibis
from ibis import BaseBackend


@dataclass
class ColumnProfile:
    """Profile of a single database column."""

    name: str
    db_type: str
    nullable: bool

    # Statistics (computed from sample)
    sample_values: list[Any] = field(default_factory=list)
    total_rows: int = 0
    null_count: int = 0
    distinct_count: int = 0

    # String-specific stats
    min_length: int | None = None
    max_length: int | None = None

    # Numeric-specific stats
    min_value: float | None = None
    max_value: float | None = None

    @property
    def null_ratio(self) -> float:
        if self.total_rows == 0:
            return 0.0
        return self.null_count / self.total_rows

    @property
    def is_low_cardinality(self) -> bool:
        """Likely an enum if < 20 distinct values."""
        return self.distinct_count < 20 and self.distinct_count > 0

    def to_dict(self) -> dict:
        """Convert to dict for JSON serialization."""
        return {
            "name": self.name,
            "db_type": self.db_type,
            "nullable": self.nullable,
            "sample_values": [str(v) for v in self.sample_values[:10]],
            "total_rows": self.total_rows,
            "null_count": self.null_count,
            "null_ratio": round(self.null_ratio, 3),
            "distinct_count": self.distinct_count,
            "is_low_cardinality": self.is_low_cardinality,
            "min_length": self.min_length,
            "max_length": self.max_length,
            "min_value": self.min_value,
            "max_value": self.max_value,
        }


@dataclass
class TableProfile:
    """Profile of a database table."""

    schema: str | None
    name: str
    columns: list[ColumnProfile] = field(default_factory=list)
    row_count: int = 0

    @property
    def full_name(self) -> str:
        if self.schema:
            return f"{self.schema}.{self.name}"
        return self.name

    def to_dict(self) -> dict:
        return {
            "table": self.full_name,
            "row_count": self.row_count,
            "columns": [c.to_dict() for c in self.columns],
        }


@dataclass
class DatabaseProfile:
    """Profile of an entire database."""

    tables: list[TableProfile] = field(default_factory=list)

    @property
    def total_tables(self) -> int:
        return len(self.tables)

    @property
    def total_columns(self) -> int:
        return sum(len(t.columns) for t in self.tables)

    def to_dict(self) -> dict:
        return {
            "total_tables": self.total_tables,
            "total_columns": self.total_columns,
            "tables": [t.to_dict() for t in self.tables],
        }


def profile_column(
    connection: BaseBackend,
    table: ibis.expr.types.Table,
    column_name: str,
    column_type: str,
    is_nullable: bool,
    sample_size: int = 10,
) -> ColumnProfile:
    """
    Profile a single column.

    Extracts statistics and sample values in a single query for efficiency.
    """
    col = table[column_name]

    # Build aggregation query
    aggs = [
        table.count().name("total_rows"),
        col.isnull().sum().name("null_count"),
        col.nunique().name("distinct_count"),
    ]

    # Add type-specific aggregations
    type_lower = column_type.lower()
    is_string = any(t in type_lower for t in ["char", "text", "string", "varchar"])
    numeric_types = ["int", "decimal", "numeric", "float", "double", "real"]
    is_numeric = any(t in type_lower for t in numeric_types)

    if is_string:
        # String length stats
        aggs.extend([
            col.length().min().name("min_length"),
            col.length().max().name("max_length"),
        ])
    elif is_numeric:
        # Numeric range stats
        aggs.extend([
            col.min().name("min_value"),
            col.max().name("max_value"),
        ])

    # Execute stats query
    stats_result = connection.execute(table.aggregate(aggs)).iloc[0]

    # Get sample values (distinct, non-null)
    sample_query = (
        table
        .filter(col.notnull())
        .select(column_name)
        .distinct()
        .limit(sample_size)
    )
    sample_df = connection.execute(sample_query)
    sample_values = sample_df[column_name].tolist() if len(sample_df) > 0 else []

    # Build profile
    profile = ColumnProfile(
        name=column_name,
        db_type=column_type,
        nullable=is_nullable,
        sample_values=sample_values,
        total_rows=int(stats_result.get("total_rows", 0)),
        null_count=int(stats_result.get("null_count", 0)),
        distinct_count=int(stats_result.get("distinct_count", 0)),
    )

    if is_string:
        min_len = stats_result.get("min_length")
        max_len = stats_result.get("max_length")
        profile.min_length = int(min_len) if min_len is not None else None
        profile.max_length = int(max_len) if max_len is not None else None
    elif is_numeric:
        min_val = stats_result.get("min_value")
        max_val = stats_result.get("max_value")
        profile.min_value = float(min_val) if min_val is not None else None
        profile.max_value = float(max_val) if max_val is not None else None

    return profile


def profile_table(
    connection: BaseBackend,
    table_name: str,
    schema: str | None = None,
    sample_size: int = 10,
) -> TableProfile:
    """
    Profile a single table.

    Gets schema info and profiles each column.
    """
    # Get table reference
    if schema:
        table = connection.table(table_name, schema=schema)
    else:
        table = connection.table(table_name)

    # Get row count
    row_count = connection.execute(table.count())

    # Get column info from Ibis schema
    ibis_schema = table.schema()

    # Profile each column
    columns = []
    for col_name, col_type in ibis_schema.items():
        # Determine if nullable (Ibis types can indicate this)
        is_nullable = col_type.nullable if hasattr(col_type, 'nullable') else True

        try:
            col_profile = profile_column(
                connection=connection,
                table=table,
                column_name=col_name,
                column_type=str(col_type),
                is_nullable=is_nullable,
                sample_size=sample_size,
            )
            columns.append(col_profile)
        except Exception:
            # Skip columns that fail to profile (e.g., complex types)
            columns.append(ColumnProfile(
                name=col_name,
                db_type=str(col_type),
                nullable=is_nullable,
            ))

    return TableProfile(
        schema=schema,
        name=table_name,
        columns=columns,
        row_count=int(row_count),
    )


def profile_database(
    connection: BaseBackend,
    schema: str | None = None,
    include_tables: list[str] | None = None,
    exclude_tables: list[str] | None = None,
    sample_size: int = 10,
) -> DatabaseProfile:
    """
    Profile all tables in a database or schema.

    Args:
        connection: Ibis database connection
        schema: Schema to profile (None for default)
        include_tables: Only profile these tables (None for all)
        exclude_tables: Skip these tables
        sample_size: Number of sample values per column

    Returns:
        DatabaseProfile with all table/column metadata
    """
    exclude_tables = exclude_tables or []

    # Get list of tables
    if schema:
        tables = connection.list_tables(schema=schema)
    else:
        tables = connection.list_tables()

    # Filter tables
    if include_tables:
        tables = [t for t in tables if t in include_tables]
    tables = [t for t in tables if t not in exclude_tables]

    # Profile each table
    profiles = []
    for table_name in tables:
        try:
            table_profile = profile_table(
                connection=connection,
                table_name=table_name,
                schema=schema,
                sample_size=sample_size,
            )
            profiles.append(table_profile)
        except Exception:
            # Skip tables that fail to profile
            pass

    return DatabaseProfile(tables=profiles)
