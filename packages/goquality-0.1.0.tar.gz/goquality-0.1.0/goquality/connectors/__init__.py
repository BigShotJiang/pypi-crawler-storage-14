"""
Database Connectors for GoQuality.

Provides a unified interface for connecting to different database backends.
Each connector wraps Ibis backend-specific functionality.

Supported backends:
- PostgreSQL (postgres://)
- DuckDB (duckdb://)
- Snowflake (snowflake://)
- BigQuery (bigquery://)
"""

from goquality.connectors.base import (
    ConnectionConfig,
    DatabaseConnector,
    DatabaseInfo,
)
from goquality.connectors.duckdb import DuckDBConnector
from goquality.connectors.factory import (
    connect,
    create_connector,
    get_connector,
    list_connectors,
    parse_connection_string,
    register_connector,
)
from goquality.connectors.postgres import PostgresConnector

# Optional connectors (only available if dependencies installed)
try:
    from goquality.connectors.snowflake import SnowflakeConnector
except ImportError:
    SnowflakeConnector = None  # type: ignore

try:
    from goquality.connectors.bigquery import BigQueryConnector
except ImportError:
    BigQueryConnector = None  # type: ignore

__all__ = [
    # Base classes
    "DatabaseConnector",
    "ConnectionConfig",
    "DatabaseInfo",
    # Factory functions
    "connect",
    "create_connector",
    "get_connector",
    "parse_connection_string",
    "register_connector",
    "list_connectors",
    # Concrete connectors
    "PostgresConnector",
    "DuckDBConnector",
    "SnowflakeConnector",
    "BigQueryConnector",
]
