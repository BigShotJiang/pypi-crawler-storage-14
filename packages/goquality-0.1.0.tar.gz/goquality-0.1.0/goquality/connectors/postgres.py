"""
PostgreSQL Database Connector.

Provides PostgreSQL-specific connection handling using ibis-postgres.
"""

from __future__ import annotations

import ibis

from goquality.connectors.base import (
    ConnectionConfig,
    DatabaseConnector,
    DatabaseInfo,
)
from goquality.errors import ConnectionError as GQConnectionError
from goquality.logging import get_logger
from goquality.resilience import RetryConfig, retry
from goquality.security import is_safe_sql_identifier, mask_connection_string

logger = get_logger(__name__)

# Retry configuration for database connections
DB_RETRY_CONFIG = RetryConfig(
    max_attempts=3,
    initial_delay=1.0,
    max_delay=30.0,
    retry_exceptions=(Exception,),  # Retry on any exception
)


class PostgresConnector(DatabaseConnector):
    """
    PostgreSQL database connector.

    Supports connection via:
    - postgres://user:pass@host:port/database
    - postgresql://user:pass@host:port/database

    Features:
    - SSL/TLS support
    - Schema-aware querying
    - Connection pooling (via psycopg2)
    - Retry on connection failures
    - SQL injection protection
    """

    DIALECT = "postgres"

    def __init__(self, config: ConnectionConfig):
        """Initialize PostgreSQL connector."""
        if config.dialect not in ("postgres", "postgresql"):
            raise ValueError(f"Invalid dialect for PostgresConnector: {config.dialect}")
        super().__init__(config)

    @retry(config=DB_RETRY_CONFIG)
    def connect(self) -> None:
        """Establish PostgreSQL connection with retry logic."""
        try:
            masked_conn = mask_connection_string(self.config.to_connection_string())
            logger.debug(f"Connecting to PostgreSQL: {masked_conn}")
            self._connection = ibis.postgres.connect(
                host=self.config.host or "localhost",
                port=self.config.port or 5432,
                user=self.config.user,
                password=self.config.password,
                database=self.config.database,
                **self.config.options,
            )
            logger.info("Successfully connected to PostgreSQL")
        except Exception as e:
            logger.error(f"Failed to connect to PostgreSQL: {e}")
            raise GQConnectionError(
                message="Failed to connect to PostgreSQL",
                details={"host": self.config.host, "database": self.config.database},
                cause=e,
            ) from e

    def disconnect(self) -> None:
        """Close PostgreSQL connection."""
        if self._connection is not None:
            try:
                logger.debug("Disconnecting from PostgreSQL")
                # Ibis connections don't always have explicit close methods
                # but we should clean up the reference
                self._connection = None
            except Exception as e:
                logger.warning(f"Error during disconnect: {e}")

    def test_connection(self) -> bool:
        """Test PostgreSQL connection validity."""
        try:
            if not self.is_connected:
                self.connect()
            # Execute simple query
            self.connection.raw_sql("SELECT 1")
            return True
        except Exception as e:
            logger.debug(f"Connection test failed: {e}")
            return False

    def get_info(self) -> DatabaseInfo:
        """Get PostgreSQL database information."""
        info = DatabaseInfo(
            dialect=self.dialect,
            database=self.config.database,
            schema=self.config.schema or "public",
            connected=self.is_connected,
        )

        if self.is_connected:
            try:
                # Get PostgreSQL version
                result = self.connection.raw_sql("SELECT version()")
                version_str = result.fetchone()[0]
                info.version = version_str.split()[1] if version_str else None

                # Get table list
                info.tables = self.list_tables()

                # Get schema list
                info.metadata["schemas"] = self.list_schemas()

            except Exception as e:
                logger.warning(f"Error getting database info: {e}")

        return info

    def list_schemas(self) -> list[str]:
        """List PostgreSQL schemas."""
        try:
            result = self.connection.raw_sql(
                """
                SELECT schema_name
                FROM information_schema.schemata
                WHERE schema_name NOT IN ('pg_catalog', 'information_schema')
                ORDER BY schema_name
                """
            )
            return [row[0] for row in result.fetchall()]
        except Exception as e:
            logger.warning(f"Error listing schemas: {e}")
            return []

    def get_table_info(self, table: str, schema: str = "public") -> dict:
        """
        Get detailed information about a table.

        Uses parameterized queries to prevent SQL injection.

        Args:
            table: Table name
            schema: Schema name (default: public)

        Returns:
            Dictionary with table metadata

        Raises:
            ValueError: If table or schema name is invalid
        """
        # Validate identifiers to prevent SQL injection
        if not is_safe_sql_identifier(table):
            raise ValueError(f"Invalid table name: {table}")
        if not is_safe_sql_identifier(schema):
            raise ValueError(f"Invalid schema name: {schema}")

        # Use Ibis table for safe querying
        info_schema = self.connection.table(
            "columns",
            schema="information_schema"
        )

        # Build query using Ibis (which handles parameterization)
        query = (
            info_schema
            .filter(
                (info_schema.table_schema == schema) &
                (info_schema.table_name == table)
            )
            .select(
                "column_name",
                "data_type",
                "is_nullable",
                "column_default",
                "ordinal_position"
            )
            .order_by("ordinal_position")
        )

        result_df = self.connection.execute(query)

        columns = []
        for _, row in result_df.iterrows():
            columns.append({
                "name": row["column_name"],
                "type": row["data_type"],
                "nullable": row["is_nullable"] == "YES",
                "default": row["column_default"],
            })

        return {
            "name": table,
            "schema": schema,
            "columns": columns,
        }

    @classmethod
    def from_connection_string(cls, conn_str: str) -> "PostgresConnector":
        """
        Create connector from connection string.

        Args:
            conn_str: PostgreSQL connection string

        Returns:
            Configured PostgresConnector
        """
        from goquality.connectors.factory import parse_connection_string
        config = parse_connection_string(conn_str)
        return cls(config)
