"""
Connection Configuration File Support.

Allows users to store connection configurations in YAML files,
supporting multiple named connections and environment variable interpolation.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from goquality.connectors.base import ConnectionConfig


@dataclass
class ConnectionEntry:
    """A named connection configuration entry."""

    name: str
    connection_string: str | None = None

    # Direct configuration (alternative to connection string)
    dialect: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    schema: str | None = None
    user: str | None = None
    password: str | None = None
    path: str | None = None

    # Additional options
    options: dict[str, Any] = field(default_factory=dict)

    # Metadata
    description: str | None = None
    is_default: bool = False

    def to_connection_config(self) -> ConnectionConfig:
        """Convert to ConnectionConfig."""
        if self.connection_string:
            from goquality.connectors.factory import parse_connection_string
            return parse_connection_string(self.connection_string)

        if not self.dialect:
            raise ValueError(f"Connection '{self.name}' missing dialect")

        return ConnectionConfig(
            dialect=self.dialect,
            host=self.host,
            port=self.port,
            database=self.database,
            schema=self.schema,
            user=self.user,
            password=self.password,
            path=self.path,
            options=self.options,
        )


class ConnectionConfigFile:
    """
    Manages connection configurations from a file.

    Supports:
    - Multiple named connections
    - Default connection
    - Environment variable interpolation (${VAR} or $VAR)
    - Connection strings or structured config

    Example config file:

        default: prod

        connections:
          local:
            connection_string: duckdb://:memory:
            description: Local testing

          dev:
            dialect: postgres
            host: ${PG_HOST}
            port: 5432
            database: myapp_dev
            user: ${PG_USER}
            password: ${PG_PASSWORD}

          prod:
            connection_string: postgres://${PROD_USER}:${PROD_PASS}@prod.example.com/myapp
            description: Production database
    """

    DEFAULT_PATHS = [
        Path(".goquality/connections.yaml"),
        Path(".goquality/connections.yml"),
        Path("goquality-connections.yaml"),
        Path("~/.config/goquality/connections.yaml"),
    ]

    def __init__(self, path: Path | None = None):
        """
        Initialize connection config file.

        Args:
            path: Path to config file (auto-discovered if None)
        """
        self.path = path
        self._connections: dict[str, ConnectionEntry] = {}
        self._default: str | None = None
        self._loaded = False

    @classmethod
    def find_config_file(cls) -> Path | None:
        """
        Find a connection config file in default locations.

        Returns:
            Path to config file, or None if not found
        """
        for path in cls.DEFAULT_PATHS:
            expanded = Path(os.path.expanduser(str(path)))
            if expanded.exists():
                return expanded
        return None

    def load(self) -> None:
        """Load connections from config file."""
        if self.path is None:
            self.path = self.find_config_file()

        if self.path is None or not self.path.exists():
            self._loaded = True
            return

        with open(self.path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        if not data:
            self._loaded = True
            return

        # Get default connection name
        self._default = data.get("default")

        # Parse connections
        connections = data.get("connections", {})
        for name, config in connections.items():
            entry = self._parse_connection_entry(name, config)
            self._connections[name] = entry

        self._loaded = True

    def _parse_connection_entry(self, name: str, config: dict) -> ConnectionEntry:
        """Parse a connection entry from config dict."""
        # Interpolate environment variables
        config = self._interpolate_env_vars(config)

        return ConnectionEntry(
            name=name,
            connection_string=config.get("connection_string"),
            dialect=config.get("dialect"),
            host=config.get("host"),
            port=config.get("port"),
            database=config.get("database"),
            schema=config.get("schema"),
            user=config.get("user"),
            password=config.get("password"),
            path=config.get("path"),
            options=config.get("options", {}),
            description=config.get("description"),
            is_default=(name == self._default),
        )

    def _interpolate_env_vars(self, value: Any) -> Any:
        """Recursively interpolate environment variables in config."""
        if isinstance(value, str):
            # Match ${VAR} or $VAR patterns
            pattern = r"\$\{([^}]+)\}|\$([A-Za-z_][A-Za-z0-9_]*)"

            def replace(match):
                var_name = match.group(1) or match.group(2)
                env_value = os.environ.get(var_name)
                if env_value is None:
                    raise ValueError(
                        f"Environment variable not set: {var_name}"
                    )
                return env_value

            return re.sub(pattern, replace, value)
        elif isinstance(value, dict):
            return {k: self._interpolate_env_vars(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._interpolate_env_vars(item) for item in value]
        return value

    @property
    def connections(self) -> dict[str, ConnectionEntry]:
        """Get all connections."""
        if not self._loaded:
            self.load()
        return self._connections

    @property
    def default_connection(self) -> ConnectionEntry | None:
        """Get the default connection."""
        if not self._loaded:
            self.load()
        if self._default and self._default in self._connections:
            return self._connections[self._default]
        return None

    def get_connection(self, name: str) -> ConnectionEntry | None:
        """
        Get a named connection.

        Args:
            name: Connection name

        Returns:
            ConnectionEntry or None if not found
        """
        if not self._loaded:
            self.load()
        return self._connections.get(name)

    def get_connection_config(self, name: str | None = None) -> ConnectionConfig:
        """
        Get ConnectionConfig for a named connection.

        Args:
            name: Connection name (uses default if None)

        Returns:
            ConnectionConfig

        Raises:
            ValueError: If connection not found
        """
        if not self._loaded:
            self.load()

        if name is None:
            entry = self.default_connection
            if entry is None:
                raise ValueError("No default connection configured")
        else:
            entry = self._connections.get(name)
            if entry is None:
                available = ", ".join(self._connections.keys())
                raise ValueError(
                    f"Connection '{name}' not found. Available: {available}"
                )

        return entry.to_connection_config()

    def list_connections(self) -> list[str]:
        """
        List all connection names.

        Returns:
            List of connection names
        """
        if not self._loaded:
            self.load()
        return list(self._connections.keys())

    def save(self) -> None:
        """Save connections to config file."""
        if self.path is None:
            self.path = Path(".goquality/connections.yaml")

        # Build config dict
        data: dict[str, Any] = {}

        if self._default:
            data["default"] = self._default

        connections = {}
        for name, entry in self._connections.items():
            conn_data: dict[str, Any] = {}

            if entry.connection_string:
                conn_data["connection_string"] = entry.connection_string
            else:
                if entry.dialect:
                    conn_data["dialect"] = entry.dialect
                if entry.host:
                    conn_data["host"] = entry.host
                if entry.port:
                    conn_data["port"] = entry.port
                if entry.database:
                    conn_data["database"] = entry.database
                if entry.schema:
                    conn_data["schema"] = entry.schema
                if entry.user:
                    conn_data["user"] = entry.user
                if entry.password:
                    conn_data["password"] = entry.password
                if entry.path:
                    conn_data["path"] = entry.path
                if entry.options:
                    conn_data["options"] = entry.options

            if entry.description:
                conn_data["description"] = entry.description

            connections[name] = conn_data

        data["connections"] = connections

        # Ensure directory exists
        self.path.parent.mkdir(parents=True, exist_ok=True)

        with open(self.path, "w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, default_flow_style=False, sort_keys=False)

    def add_connection(
        self,
        name: str,
        connection_string: str | None = None,
        set_default: bool = False,
        **kwargs,
    ) -> None:
        """
        Add a new connection.

        Args:
            name: Connection name
            connection_string: Connection string (optional)
            set_default: Whether to set as default
            **kwargs: Additional connection parameters
        """
        entry = ConnectionEntry(
            name=name,
            connection_string=connection_string,
            **kwargs,
        )
        self._connections[name] = entry

        if set_default:
            self._default = name

    def remove_connection(self, name: str) -> bool:
        """
        Remove a connection.

        Args:
            name: Connection name

        Returns:
            True if removed, False if not found
        """
        if name in self._connections:
            del self._connections[name]
            if self._default == name:
                self._default = None
            return True
        return False

    def set_default(self, name: str) -> None:
        """
        Set the default connection.

        Args:
            name: Connection name

        Raises:
            ValueError: If connection not found
        """
        if name not in self._connections:
            raise ValueError(f"Connection '{name}' not found")
        self._default = name


def get_connection_string(name_or_string: str) -> str:
    """
    Resolve a connection name or string.

    If the input looks like a connection string (contains ://),
    returns it directly. Otherwise, looks up the named connection
    in the config file.

    Args:
        name_or_string: Connection name or connection string

    Returns:
        Connection string
    """
    # If it looks like a connection string, return as-is
    if "://" in name_or_string or name_or_string.startswith("/"):
        return name_or_string

    # Otherwise, look up in config file
    config_file = ConnectionConfigFile()
    config = config_file.get_connection_config(name_or_string)
    return config.to_connection_string()
