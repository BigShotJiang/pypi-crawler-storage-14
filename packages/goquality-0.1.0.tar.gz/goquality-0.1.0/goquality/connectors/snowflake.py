"""
Snowflake Database Connector.

Provides Snowflake-specific connection handling using ibis-snowflake.
"""

from __future__ import annotations

from goquality.connectors.base import (
    ConnectionConfig,
    DatabaseConnector,
    DatabaseInfo,
)
from goquality.errors import ConnectionError as GQConnectionError
from goquality.logging import get_logger
from goquality.resilience import RetryConfig, retry
from goquality.security import is_safe_sql_identifier, quote_sql_identifier

logger = get_logger(__name__)

# Retry configuration for database connections
DB_RETRY_CONFIG = RetryConfig(
    max_attempts=3,
    initial_delay=2.0,
    max_delay=60.0,
    retry_exceptions=(Exception,),
)


class SnowflakeConnector(DatabaseConnector):
    """
    Snowflake database connector.

    Supports connection via:
    - snowflake://user@account/database/schema?warehouse=COMPUTE_WH
    - Environment variables (SNOWFLAKE_USER, SNOWFLAKE_PASSWORD, etc.)

    Features:
    - Warehouse specification
    - Role-based access
    - Schema/database switching
    - Key-pair authentication support
    """

    DIALECT = "snowflake"

    def __init__(self, config: ConnectionConfig):
        """Initialize Snowflake connector."""
        if config.dialect != "snowflake":
            raise ValueError(f"Invalid dialect for SnowflakeConnector: {config.dialect}")
        super().__init__(config)

    @retry(config=DB_RETRY_CONFIG)
    def connect(self) -> None:
        """Establish Snowflake connection with retry logic."""
        try:
            import ibis

            logger.debug(f"Connecting to Snowflake account: {self.config.host}")

            # Extract connection parameters
            connect_args = {
                "user": self.config.user,
                "password": self.config.password,
                "account": self.config.host,  # Snowflake uses account identifier
                "database": self.config.database,
                "schema": self.config.schema or "PUBLIC",
            }

            # Add optional parameters from options
            if "warehouse" in self.config.options:
                connect_args["warehouse"] = self.config.options["warehouse"]
            if "role" in self.config.options:
                connect_args["role"] = self.config.options["role"]

            # Handle key-pair authentication
            if "private_key_path" in self.config.options:
                connect_args["private_key_path"] = self.config.options["private_key_path"]
                # Remove password if using key-pair
                connect_args.pop("password", None)

            self._connection = ibis.snowflake.connect(**connect_args)
            logger.info("Successfully connected to Snowflake")

        except ImportError:
            raise ImportError(
                "Snowflake connector requires 'snowflake-connector-python'. "
                "Install with: pip install goquality[snowflake]"
            )
        except Exception as e:
            logger.error(f"Failed to connect to Snowflake: {e}")
            raise GQConnectionError(
                message="Failed to connect to Snowflake",
                details={"account": self.config.host, "database": self.config.database},
                cause=e,
            ) from e

    def disconnect(self) -> None:
        """Close Snowflake connection."""
        if self._connection is not None:
            try:
                self._connection = None
            except Exception:
                pass

    def test_connection(self) -> bool:
        """Test Snowflake connection validity."""
        try:
            if not self.is_connected:
                self.connect()
            self.connection.raw_sql("SELECT CURRENT_VERSION()")
            return True
        except Exception:
            return False

    def get_info(self) -> DatabaseInfo:
        """Get Snowflake database information."""
        info = DatabaseInfo(
            dialect=self.dialect,
            database=self.config.database,
            schema=self.config.schema,
            connected=self.is_connected,
        )

        if self.is_connected:
            try:
                # Get Snowflake version
                result = self.connection.raw_sql("SELECT CURRENT_VERSION()")
                info.version = result.fetchone()[0]

                # Get current context
                context_result = self.connection.raw_sql("""
                    SELECT
                        CURRENT_ACCOUNT(),
                        CURRENT_DATABASE(),
                        CURRENT_SCHEMA(),
                        CURRENT_WAREHOUSE(),
                        CURRENT_ROLE()
                """)
                context = context_result.fetchone()
                info.metadata = {
                    "account": context[0],
                    "database": context[1],
                    "schema": context[2],
                    "warehouse": context[3],
                    "role": context[4],
                }

                # Get table list
                info.tables = self.list_tables()

            except Exception:
                pass

        return info

    def list_schemas(self) -> list[str]:
        """List Snowflake schemas in current database."""
        try:
            result = self.connection.raw_sql("SHOW SCHEMAS")
            # SHOW SCHEMAS returns: created_on, name, is_default, is_current, database_name, ...
            return [row[1] for row in result.fetchall()]
        except Exception:
            return []

    def list_databases(self) -> list[str]:
        """List available databases."""
        try:
            result = self.connection.raw_sql("SHOW DATABASES")
            return [row[1] for row in result.fetchall()]
        except Exception:
            return []

    def list_warehouses(self) -> list[str]:
        """List available warehouses."""
        try:
            result = self.connection.raw_sql("SHOW WAREHOUSES")
            return [row[0] for row in result.fetchall()]
        except Exception:
            return []

    def use_database(self, database: str) -> None:
        """Switch to a different database."""
        if not is_safe_sql_identifier(database):
            raise ValueError(f"Invalid database name: {database}")
        quoted = quote_sql_identifier(database, "snowflake")
        self.connection.raw_sql(f"USE DATABASE {quoted}")
        self.config.database = database

    def use_schema(self, schema: str) -> None:
        """Switch to a different schema."""
        if not is_safe_sql_identifier(schema):
            raise ValueError(f"Invalid schema name: {schema}")
        quoted = quote_sql_identifier(schema, "snowflake")
        self.connection.raw_sql(f"USE SCHEMA {quoted}")
        self.config.schema = schema

    def use_warehouse(self, warehouse: str) -> None:
        """Switch to a different warehouse."""
        if not is_safe_sql_identifier(warehouse):
            raise ValueError(f"Invalid warehouse name: {warehouse}")
        quoted = quote_sql_identifier(warehouse, "snowflake")
        self.connection.raw_sql(f"USE WAREHOUSE {quoted}")
        self.config.options["warehouse"] = warehouse

    def get_table_info(self, table: str) -> dict:
        """
        Get detailed information about a table.

        Uses safe identifier quoting to prevent SQL injection.

        Args:
            table: Table name

        Returns:
            Dictionary with table metadata

        Raises:
            ValueError: If table name is invalid
        """
        if not is_safe_sql_identifier(table):
            raise ValueError(f"Invalid table name: {table}")

        quoted_table = quote_sql_identifier(table, "snowflake")
        result = self.connection.raw_sql(f"DESCRIBE TABLE {quoted_table}")
        columns = []
        for row in result.fetchall():
            columns.append({
                "name": row[0],
                "type": row[1],
                "nullable": row[3] == "Y",
                "default": row[4],
                "primary_key": row[5] == "Y",
            })

        return {
            "name": table,
            "database": self.config.database,
            "schema": self.config.schema,
            "columns": columns,
        }

    @classmethod
    def from_env(cls) -> "SnowflakeConnector":
        """
        Create connector from environment variables.

        Expected variables:
        - SNOWFLAKE_ACCOUNT
        - SNOWFLAKE_USER
        - SNOWFLAKE_PASSWORD
        - SNOWFLAKE_DATABASE
        - SNOWFLAKE_SCHEMA (optional, defaults to PUBLIC)
        - SNOWFLAKE_WAREHOUSE (optional)
        - SNOWFLAKE_ROLE (optional)

        Returns:
            Configured SnowflakeConnector
        """
        import os

        config = ConnectionConfig(
            dialect="snowflake",
            host=os.environ.get("SNOWFLAKE_ACCOUNT"),
            user=os.environ.get("SNOWFLAKE_USER"),
            password=os.environ.get("SNOWFLAKE_PASSWORD"),
            database=os.environ.get("SNOWFLAKE_DATABASE"),
            schema=os.environ.get("SNOWFLAKE_SCHEMA", "PUBLIC"),
            options={
                "warehouse": os.environ.get("SNOWFLAKE_WAREHOUSE"),
                "role": os.environ.get("SNOWFLAKE_ROLE"),
            },
        )

        # Remove None values from options
        config.options = {k: v for k, v in config.options.items() if v is not None}

        return cls(config)

    @classmethod
    def from_connection_string(cls, conn_str: str) -> "SnowflakeConnector":
        """
        Create connector from connection string.

        Args:
            conn_str: Snowflake connection string

        Returns:
            Configured SnowflakeConnector
        """
        from goquality.connectors.factory import parse_connection_string
        config = parse_connection_string(conn_str)
        return cls(config)
