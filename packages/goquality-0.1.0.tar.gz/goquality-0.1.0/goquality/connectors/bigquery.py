"""
BigQuery Database Connector.

Provides BigQuery-specific connection handling using ibis-bigquery.
"""

from __future__ import annotations

from goquality.connectors.base import (
    ConnectionConfig,
    DatabaseConnector,
    DatabaseInfo,
)
from goquality.errors import ConnectionError as GQConnectionError
from goquality.logging import get_logger
from goquality.resilience import RetryConfig, retry
from goquality.security import is_safe_sql_identifier, quote_sql_identifier

logger = get_logger(__name__)

# Retry configuration for BigQuery connections
DB_RETRY_CONFIG = RetryConfig(
    max_attempts=3,
    initial_delay=2.0,
    max_delay=60.0,
    retry_exceptions=(Exception,),
)


class BigQueryConnector(DatabaseConnector):
    """
    Google BigQuery database connector.

    Supports connection via:
    - bigquery://project-id/dataset
    - Service account credentials (JSON key file)
    - Application Default Credentials (ADC)

    Features:
    - Dataset-scoped queries
    - Billing project specification
    - Large result handling
    - Geographic location support
    """

    DIALECT = "bigquery"

    def __init__(self, config: ConnectionConfig):
        """Initialize BigQuery connector."""
        if config.dialect != "bigquery":
            raise ValueError(f"Invalid dialect for BigQueryConnector: {config.dialect}")
        super().__init__(config)

    @retry(config=DB_RETRY_CONFIG)
    def connect(self) -> None:
        """Establish BigQuery connection with retry logic."""
        try:
            import ibis

            logger.debug(f"Connecting to BigQuery project: {self.config.database}")

            connect_args = {
                "project_id": self.config.database,  # project-id
                "dataset_id": self.config.schema,  # dataset
            }

            # Handle credentials
            if "credentials_path" in self.config.options:
                connect_args["credentials_path"] = self.config.options["credentials_path"]

            if "location" in self.config.options:
                connect_args["location"] = self.config.options["location"]

            self._connection = ibis.bigquery.connect(**connect_args)
            logger.info("Successfully connected to BigQuery")

        except ImportError:
            raise ImportError(
                "BigQuery connector requires 'google-cloud-bigquery'. "
                "Install with: pip install goquality[bigquery]"
            )
        except Exception as e:
            logger.error(f"Failed to connect to BigQuery: {e}")
            raise GQConnectionError(
                message="Failed to connect to BigQuery",
                details={"project": self.config.database, "dataset": self.config.schema},
                cause=e,
            ) from e

    def disconnect(self) -> None:
        """Close BigQuery connection."""
        if self._connection is not None:
            try:
                self._connection = None
            except Exception:
                pass

    def test_connection(self) -> bool:
        """Test BigQuery connection validity."""
        try:
            if not self.is_connected:
                self.connect()
            # Simple query to verify connection
            self.connection.raw_sql("SELECT 1")
            return True
        except Exception:
            return False

    def get_info(self) -> DatabaseInfo:
        """Get BigQuery project/dataset information."""
        info = DatabaseInfo(
            dialect=self.dialect,
            database=self.config.database,  # project-id
            schema=self.config.schema,  # dataset
            connected=self.is_connected,
        )

        if self.is_connected:
            try:
                # Get table list
                info.tables = self.list_tables()

                info.metadata = {
                    "project_id": self.config.database,
                    "dataset_id": self.config.schema,
                    "location": self.config.options.get("location"),
                }

            except Exception:
                pass

        return info

    def list_datasets(self) -> list[str]:
        """List datasets in the project."""
        try:
            result = self.connection.raw_sql("""
                SELECT schema_name
                FROM INFORMATION_SCHEMA.SCHEMATA
                ORDER BY schema_name
            """)
            return [row[0] for row in result.fetchall()]
        except Exception:
            return []

    def list_tables(self, schema: str | None = None) -> list[str]:
        """
        List tables in a dataset.

        Args:
            schema: Dataset name (defaults to configured dataset)

        Returns:
            List of table names
        """
        dataset = schema or self.config.schema
        if not dataset:
            return []

        # Validate identifiers
        if not is_safe_sql_identifier(dataset):
            logger.warning(f"Invalid dataset name: {dataset}")
            return []

        try:
            # Use backtick quoting for BigQuery identifiers
            project_quoted = quote_sql_identifier(self.config.database, "bigquery")
            dataset_quoted = quote_sql_identifier(dataset, "bigquery")

            result = self.connection.raw_sql(f"""
                SELECT table_name
                FROM {project_quoted}.{dataset_quoted}.INFORMATION_SCHEMA.TABLES
                ORDER BY table_name
            """)
            return [row[0] for row in result.fetchall()]
        except Exception as e:
            logger.warning(f"Error listing tables: {e}")
            return []

    def get_table_info(self, table: str, dataset: str | None = None) -> dict:
        """
        Get detailed information about a table.

        Uses safe identifier handling to prevent SQL injection.

        Args:
            table: Table name
            dataset: Dataset name (defaults to configured dataset)

        Returns:
            Dictionary with table metadata

        Raises:
            ValueError: If table or dataset name is invalid
        """
        ds = dataset or self.config.schema

        # Validate identifiers
        if not is_safe_sql_identifier(table):
            raise ValueError(f"Invalid table name: {table}")
        if not is_safe_sql_identifier(ds):
            raise ValueError(f"Invalid dataset name: {ds}")

        project_quoted = quote_sql_identifier(self.config.database, "bigquery")
        dataset_quoted = quote_sql_identifier(ds, "bigquery")
        full_table = f"{self.config.database}.{ds}.{table}"

        # Use Ibis for safe querying where possible
        # For INFORMATION_SCHEMA, we need to use safe string building
        result = self.connection.raw_sql(f"""
            SELECT
                column_name,
                data_type,
                is_nullable,
                column_default
            FROM {project_quoted}.{dataset_quoted}.INFORMATION_SCHEMA.COLUMNS
            WHERE table_name = @table_name
            ORDER BY ordinal_position
        """.replace("@table_name", f"'{table}'"))  # BigQuery string literal

        columns = []
        for row in result.fetchall():
            columns.append({
                "name": row[0],
                "type": row[1],
                "nullable": row[2] == "YES",
                "default": row[3],
            })

        return {
            "name": table,
            "full_name": full_table,
            "project": self.config.database,
            "dataset": ds,
            "columns": columns,
        }

    def get_table_size(self, table: str, dataset: str | None = None) -> dict:
        """
        Get table size information.

        Args:
            table: Table name
            dataset: Dataset name

        Returns:
            Dictionary with size metrics
        """
        ds = dataset or self.config.schema

        # Validate identifiers
        if not is_safe_sql_identifier(table):
            raise ValueError(f"Invalid table name: {table}")
        if not is_safe_sql_identifier(ds):
            raise ValueError(f"Invalid dataset name: {ds}")

        project_quoted = quote_sql_identifier(self.config.database, "bigquery")
        dataset_quoted = quote_sql_identifier(ds, "bigquery")

        result = self.connection.raw_sql(f"""
            SELECT
                size_bytes,
                num_rows,
                TIMESTAMP_MILLIS(last_modified_time) as last_modified
            FROM {project_quoted}.{dataset_quoted}.__TABLES__
            WHERE table_id = '{table}'
        """)

        row = result.fetchone()
        if row:
            return {
                "size_bytes": row[0],
                "num_rows": row[1],
                "last_modified": row[2],
            }
        return {}

    def use_dataset(self, dataset: str) -> None:
        """Switch to a different dataset."""
        self.config.schema = dataset

    @classmethod
    def from_env(cls) -> "BigQueryConnector":
        """
        Create connector from environment variables.

        Expected variables:
        - GOOGLE_CLOUD_PROJECT or BIGQUERY_PROJECT
        - BIGQUERY_DATASET
        - GOOGLE_APPLICATION_CREDENTIALS (optional, path to JSON key)
        - BIGQUERY_LOCATION (optional)

        Returns:
            Configured BigQueryConnector
        """
        import os

        project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("BIGQUERY_PROJECT")

        config = ConnectionConfig(
            dialect="bigquery",
            database=project,
            schema=os.environ.get("BIGQUERY_DATASET"),
            options={
                "credentials_path": os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"),
                "location": os.environ.get("BIGQUERY_LOCATION"),
            },
        )

        # Remove None values from options
        config.options = {k: v for k, v in config.options.items() if v is not None}

        return cls(config)

    @classmethod
    def from_connection_string(cls, conn_str: str) -> "BigQueryConnector":
        """
        Create connector from connection string.

        Args:
            conn_str: BigQuery connection string

        Returns:
            Configured BigQueryConnector
        """
        from goquality.connectors.factory import parse_connection_string
        config = parse_connection_string(conn_str)
        return cls(config)
