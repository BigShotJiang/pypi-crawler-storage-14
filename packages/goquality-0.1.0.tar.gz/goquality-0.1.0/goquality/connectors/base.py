"""
Base Database Connector Interface.

Defines the abstract interface that all database connectors must implement.
This enables polymorphic database access and easy extension to new backends.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from ibis import BaseBackend
from ibis.expr.types import Table


@dataclass
class ConnectionConfig:
    """
    Database connection configuration.

    This is a normalized representation of connection parameters
    that can be parsed from connection strings or config files.
    """

    dialect: str  # postgres, duckdb, snowflake, bigquery, etc.
    host: str | None = None
    port: int | None = None
    database: str | None = None
    schema: str | None = None
    user: str | None = None
    password: str | None = None
    path: str | None = None  # For file-based DBs like DuckDB

    # Additional connection options
    options: dict[str, Any] = field(default_factory=dict)

    def to_connection_string(self) -> str:
        """Convert config back to a connection string."""
        if self.dialect in ("postgres", "postgresql"):
            auth = f"{self.user}:{self.password}@" if self.user else ""
            port = f":{self.port}" if self.port else ""
            return f"postgresql://{auth}{self.host}{port}/{self.database}"
        elif self.dialect == "duckdb":
            return f"duckdb://{self.path or ':memory:'}"
        elif self.dialect == "snowflake":
            return (
                f"snowflake://{self.user}@{self.host}/"
                f"{self.database}/{self.schema}"
            )
        elif self.dialect == "bigquery":
            return f"bigquery://{self.database}"
        else:
            raise ValueError(f"Unknown dialect: {self.dialect}")


@dataclass
class DatabaseInfo:
    """
    Information about a database connection.

    Provides metadata about the connected database for diagnostics.
    """

    dialect: str
    version: str | None = None
    database: str | None = None
    schema: str | None = None
    tables: list[str] = field(default_factory=list)
    connected: bool = False

    # Additional metadata
    metadata: dict[str, Any] = field(default_factory=dict)


class DatabaseConnector(ABC):
    """
    Abstract base class for database connectors.

    Each database backend (PostgreSQL, DuckDB, Snowflake, etc.) implements
    this interface to provide consistent access patterns.

    Usage:
        connector = PostgresConnector(config)
        connector.connect()

        # Access Ibis backend
        table = connector.table("users")

        # Run queries
        result = connector.execute("SELECT * FROM users")

        connector.disconnect()
    """

    def __init__(self, config: ConnectionConfig):
        """Initialize connector with configuration."""
        self.config = config
        self._connection: BaseBackend | None = None

    @property
    def dialect(self) -> str:
        """Database dialect name."""
        return self.config.dialect

    @property
    def is_connected(self) -> bool:
        """Check if currently connected."""
        return self._connection is not None

    @property
    def connection(self) -> BaseBackend:
        """Get the underlying Ibis connection."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._connection

    @abstractmethod
    def connect(self) -> None:
        """
        Establish connection to the database.

        Raises:
            ConnectionError: If connection fails
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close the database connection."""
        pass

    @abstractmethod
    def test_connection(self) -> bool:
        """
        Test if the connection is valid.

        Returns:
            True if connection is valid, False otherwise
        """
        pass

    @abstractmethod
    def get_info(self) -> DatabaseInfo:
        """
        Get information about the connected database.

        Returns:
            DatabaseInfo with connection details
        """
        pass

    def table(self, name: str) -> Table:
        """
        Get an Ibis table reference.

        Args:
            name: Table name (may include schema)

        Returns:
            Ibis Table expression
        """
        return self.connection.table(name)

    def list_tables(self, schema: str | None = None) -> list[str]:
        """
        List tables in the database.

        Args:
            schema: Optional schema to filter by

        Returns:
            List of table names
        """
        if schema:
            return self.connection.list_tables(schema=schema)
        return self.connection.list_tables()

    def list_schemas(self) -> list[str]:
        """
        List available schemas.

        Returns:
            List of schema names
        """
        try:
            return self.connection.list_schemas()
        except (AttributeError, NotImplementedError):
            return []

    def execute(self, query: str) -> Any:
        """
        Execute a raw SQL query.

        Args:
            query: SQL query string

        Returns:
            Query result (varies by backend)
        """
        return self.connection.raw_sql(query)

    def __enter__(self) -> "DatabaseConnector":
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.disconnect()

    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return f"<{self.__class__.__name__} dialect={self.dialect} {status}>"
