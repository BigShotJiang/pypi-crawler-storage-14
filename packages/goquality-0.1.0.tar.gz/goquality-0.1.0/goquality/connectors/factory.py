"""
Database Connector Factory.

Provides unified connection creation and connector registration.
Supports multiple database backends through a single interface.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, urlparse

from goquality.connectors.base import ConnectionConfig, DatabaseConnector

if TYPE_CHECKING:
    from ibis import BaseBackend

# Connector registry
_CONNECTORS: dict[str, type[DatabaseConnector]] = {}


def register_connector(dialect: str, connector_class: type[DatabaseConnector]) -> None:
    """
    Register a database connector class.

    Args:
        dialect: Database dialect name (e.g., 'postgres', 'duckdb')
        connector_class: DatabaseConnector subclass
    """
    _CONNECTORS[dialect] = connector_class


def get_connector(dialect: str) -> type[DatabaseConnector]:
    """
    Get a connector class by dialect.

    Args:
        dialect: Database dialect name

    Returns:
        DatabaseConnector subclass

    Raises:
        ValueError: If dialect is not supported
    """
    if dialect not in _CONNECTORS:
        available = ", ".join(sorted(_CONNECTORS.keys()))
        raise ValueError(
            f"Unsupported database dialect: {dialect}. "
            f"Available: {available}"
        )
    return _CONNECTORS[dialect]


def list_connectors() -> list[str]:
    """
    List all registered connector dialects.

    Returns:
        List of dialect names
    """
    return sorted(_CONNECTORS.keys())


def parse_connection_string(conn_str: str) -> ConnectionConfig:
    """
    Parse a connection string into a ConnectionConfig.

    Supports:
    - postgres://user:pass@host:port/database
    - postgresql://user:pass@host:port/database
    - duckdb://path/to/file.db
    - duckdb://:memory:
    - snowflake://user@account/database/schema?warehouse=WH
    - bigquery://project-id/dataset
    - /path/to/file.csv (auto-detect DuckDB)
    - /path/to/file.parquet (auto-detect DuckDB)

    Args:
        conn_str: Database connection string

    Returns:
        ConnectionConfig with parsed parameters
    """
    # Handle local file paths (auto-detect as DuckDB)
    if conn_str.startswith("/") or conn_str.startswith("./"):
        path = Path(conn_str)
        if path.suffix in (".csv", ".parquet", ".db", ".duckdb"):
            return ConnectionConfig(dialect="duckdb", path=str(path))
        raise ValueError(f"Unsupported file type: {path.suffix}")

    parsed = urlparse(conn_str)
    query_params = parse_qs(parsed.query)

    # Convert query params from lists to single values
    options = {k: v[0] if len(v) == 1 else v for k, v in query_params.items()}

    # PostgreSQL
    if parsed.scheme in ("postgres", "postgresql"):
        return ConnectionConfig(
            dialect="postgres",
            host=parsed.hostname or "localhost",
            port=parsed.port or 5432,
            user=parsed.username,
            password=parsed.password,
            database=parsed.path.lstrip("/"),
            options=options,
        )

    # DuckDB
    elif parsed.scheme == "duckdb":
        path = parsed.path or parsed.netloc
        # Special case for :memory:
        if path == ":memory:" or parsed.netloc == ":memory:":
            path = ":memory:"
        return ConnectionConfig(
            dialect="duckdb",
            path=path,
            options=options,
        )

    # Snowflake
    # Format: snowflake://user@account/database/schema?warehouse=WH
    elif parsed.scheme == "snowflake":
        parts = parsed.path.strip("/").split("/")
        database = parts[0] if len(parts) > 0 else None
        schema = parts[1] if len(parts) > 1 else "PUBLIC"

        return ConnectionConfig(
            dialect="snowflake",
            host=parsed.hostname,  # account identifier
            user=parsed.username,
            password=parsed.password,
            database=database,
            schema=schema,
            options=options,
        )

    # BigQuery
    # Format: bigquery://project-id/dataset
    elif parsed.scheme == "bigquery":
        parts = parsed.path.strip("/").split("/")
        project = parsed.hostname
        dataset = parts[0] if len(parts) > 0 else None

        return ConnectionConfig(
            dialect="bigquery",
            database=project,  # project-id
            schema=dataset,  # dataset
            options=options,
        )

    else:
        raise ValueError(f"Unsupported database scheme: {parsed.scheme}")


def connect(conn_str: str) -> "BaseBackend":
    """
    Create a database connection from a connection string.

    This is a convenience function that parses the connection string,
    creates the appropriate connector, and returns the Ibis backend.

    Args:
        conn_str: Database connection string

    Returns:
        Ibis BaseBackend connection

    Example:
        >>> conn = connect("postgres://user:pass@localhost/mydb")
        >>> conn = connect("duckdb://:memory:")
        >>> conn = connect("./data.csv")
    """
    config = parse_connection_string(conn_str)
    connector_class = get_connector(config.dialect)
    connector = connector_class(config)
    connector.connect()
    return connector.connection


def create_connector(conn_str: str) -> DatabaseConnector:
    """
    Create a database connector from a connection string.

    Unlike connect(), this returns the full connector object,
    allowing access to database-specific functionality.

    Args:
        conn_str: Database connection string

    Returns:
        DatabaseConnector instance (connected)

    Example:
        >>> connector = create_connector("snowflake://user@account/db/schema")
        >>> connector.get_info()
        >>> connector.list_tables()
    """
    config = parse_connection_string(conn_str)
    connector_class = get_connector(config.dialect)
    connector = connector_class(config)
    connector.connect()
    return connector


# Register built-in connectors
def _register_builtin_connectors() -> None:
    """Register all built-in database connectors."""
    from goquality.connectors.duckdb import DuckDBConnector
    from goquality.connectors.postgres import PostgresConnector

    register_connector("postgres", PostgresConnector)
    register_connector("postgresql", PostgresConnector)
    register_connector("duckdb", DuckDBConnector)

    # Register optional connectors if available
    try:
        from goquality.connectors.snowflake import SnowflakeConnector
        register_connector("snowflake", SnowflakeConnector)
    except ImportError:
        pass

    try:
        from goquality.connectors.bigquery import BigQueryConnector
        register_connector("bigquery", BigQueryConnector)
    except ImportError:
        pass


# Auto-register on module load
_register_builtin_connectors()
