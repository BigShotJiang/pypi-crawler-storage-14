"""
DuckDB Database Connector.

Provides DuckDB-specific connection handling using ibis-duckdb.
Supports in-memory databases, file databases, and CSV/Parquet files.
"""

from __future__ import annotations

from pathlib import Path

import ibis

from goquality.connectors.base import (
    ConnectionConfig,
    DatabaseConnector,
    DatabaseInfo,
)


class DuckDBConnector(DatabaseConnector):
    """
    DuckDB database connector.

    Supports connection via:
    - duckdb://:memory: (in-memory database)
    - duckdb:///path/to/file.db
    - /path/to/file.csv (auto-detected)
    - /path/to/file.parquet (auto-detected)

    Features:
    - Zero-copy data sharing
    - CSV/Parquet direct querying
    - In-memory for testing
    - Extension support
    """

    DIALECT = "duckdb"

    def __init__(self, config: ConnectionConfig):
        """Initialize DuckDB connector."""
        if config.dialect != "duckdb":
            raise ValueError(f"Invalid dialect for DuckDBConnector: {config.dialect}")
        super().__init__(config)
        self._registered_files: list[str] = []

    def connect(self) -> None:
        """Establish DuckDB connection."""
        try:
            path = self.config.path or ":memory:"
            self._connection = ibis.duckdb.connect(path)

            # Auto-register files if needed
            if path.endswith((".csv", ".parquet")):
                self._register_file(path)

        except Exception as e:
            raise ConnectionError(f"Failed to connect to DuckDB: {e}") from e

    def disconnect(self) -> None:
        """Close DuckDB connection."""
        if self._connection is not None:
            try:
                self._connection = None
            except Exception:
                pass
        self._registered_files = []

    def test_connection(self) -> bool:
        """Test DuckDB connection validity."""
        try:
            if not self.is_connected:
                self.connect()
            self.connection.raw_sql("SELECT 1")
            return True
        except Exception:
            return False

    def get_info(self) -> DatabaseInfo:
        """Get DuckDB database information."""
        info = DatabaseInfo(
            dialect=self.dialect,
            database=self.config.path or ":memory:",
            connected=self.is_connected,
        )

        if self.is_connected:
            try:
                # Get DuckDB version
                result = self.connection.raw_sql("SELECT version()")
                info.version = result.fetchone()[0]

                # Get table list
                info.tables = self.list_tables()

                # Get registered files
                info.metadata["registered_files"] = self._registered_files

            except Exception:
                pass

        return info

    def _register_file(self, path: str) -> str:
        """
        Register a file (CSV/Parquet) as a table.

        Args:
            path: File path

        Returns:
            Table name
        """
        table_name = Path(path).stem
        self.connection.register(path, table_name=table_name)
        self._registered_files.append(path)
        return table_name

    def register_csv(self, path: str, table_name: str | None = None) -> str:
        """
        Register a CSV file as a table.

        Args:
            path: Path to CSV file
            table_name: Optional custom table name

        Returns:
            Table name
        """
        name = table_name or Path(path).stem
        self.connection.register(path, table_name=name)
        self._registered_files.append(path)
        return name

    def register_parquet(self, path: str, table_name: str | None = None) -> str:
        """
        Register a Parquet file as a table.

        Args:
            path: Path to Parquet file
            table_name: Optional custom table name

        Returns:
            Table name
        """
        name = table_name or Path(path).stem
        self.connection.register(path, table_name=name)
        self._registered_files.append(path)
        return name

    def register_dataframe(self, df, table_name: str) -> str:
        """
        Register a pandas DataFrame as a table.

        Args:
            df: Pandas DataFrame
            table_name: Table name

        Returns:
            Table name
        """
        # Use memtable to create an in-memory table from the dataframe
        # Then insert into a permanent table
        mem_table = ibis.memtable(df)
        self.connection.create_table(table_name, mem_table)
        return table_name

    def create_table_from_values(
        self,
        table_name: str,
        columns: dict[str, list],
    ) -> str:
        """
        Create a table from column values.

        Args:
            table_name: Table name
            columns: Dict of column_name -> values

        Returns:
            Table name
        """
        import pandas as pd
        df = pd.DataFrame(columns)
        return self.register_dataframe(df, table_name)

    def install_extension(self, extension: str) -> None:
        """
        Install a DuckDB extension.

        Args:
            extension: Extension name (e.g., 'httpfs', 'json', 'parquet')
        """
        self.connection.raw_sql(f"INSTALL {extension}")
        self.connection.raw_sql(f"LOAD {extension}")

    def query_remote_file(self, url: str, table_name: str | None = None) -> str:
        """
        Query a remote CSV/Parquet file via HTTP(S).

        Requires httpfs extension.

        Args:
            url: File URL
            table_name: Optional table name

        Returns:
            Table name
        """
        self.install_extension("httpfs")
        name = table_name or "remote_data"

        if url.endswith(".csv"):
            self.connection.raw_sql(
                f"CREATE TABLE {name} AS SELECT * FROM read_csv_auto('{url}')"
            )
        elif url.endswith(".parquet"):
            self.connection.raw_sql(
                f"CREATE TABLE {name} AS SELECT * FROM read_parquet('{url}')"
            )
        else:
            raise ValueError(f"Unsupported file type for URL: {url}")

        return name

    @classmethod
    def memory(cls) -> "DuckDBConnector":
        """
        Create an in-memory DuckDB connector.

        Returns:
            Connected DuckDBConnector with in-memory database
        """
        config = ConnectionConfig(dialect="duckdb", path=":memory:")
        connector = cls(config)
        connector.connect()
        return connector

    @classmethod
    def from_file(cls, path: str) -> "DuckDBConnector":
        """
        Create a DuckDB connector from a file path.

        Args:
            path: Path to .db, .csv, or .parquet file

        Returns:
            Connected DuckDBConnector
        """
        config = ConnectionConfig(dialect="duckdb", path=path)
        connector = cls(config)
        connector.connect()
        return connector

    @classmethod
    def from_connection_string(cls, conn_str: str) -> "DuckDBConnector":
        """
        Create connector from connection string.

        Args:
            conn_str: DuckDB connection string

        Returns:
            Configured DuckDBConnector
        """
        from goquality.connectors.factory import parse_connection_string
        config = parse_connection_string(conn_str)
        return cls(config)
