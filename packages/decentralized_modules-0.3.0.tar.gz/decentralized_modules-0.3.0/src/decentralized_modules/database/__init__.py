# decentralized-modules/src/database/__init__.py
"""
Database package for Decentralized Modules
"""