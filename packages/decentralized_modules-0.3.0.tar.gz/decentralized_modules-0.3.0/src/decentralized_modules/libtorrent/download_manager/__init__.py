# decentralized-modules/src/libtorrent/download_manager/__init__.py
"""
Download Manager package for Decentralized Modules
"""