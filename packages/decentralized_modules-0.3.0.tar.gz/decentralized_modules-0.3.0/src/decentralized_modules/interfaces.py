from typing import TYPE_CHECKING, Callable, Any, Dict, List

if TYPE_CHECKING:
    from .core.session import Session

from abc import ABC, abstractmethod


class RESTEndpoint:
    """
    REST API 端点定义
    """
    def __init__(self, path: str, handler: Callable[..., Any], methods: List[str] = None):
        """
        :param path: URL 路径 (例如 "/api/status")
        :param handler: 处理函数 (async def handler(request) -> dict)
        :param methods: 支持的 HTTP 方法列表 (默认 ["GET", "POST"])
        """
        self.path = path
        self.handler = handler
        self.methods = methods or ["GET", "POST"]


class IModule(ABC):
    """所有模块都必须实现的标准化接口。"""

    @property
    @abstractmethod
    def name(self) -> str:
        """一个唯一的、人类可读的模块名称。"""
        pass

    @property
    def dependencies(self) -> List[str]:
        """返回此模块所依赖的模块名称列表。"""
        return []

    @abstractmethod
    async def initialize(self, session: 'Session') -> None:
        """在应用程序启动序列中初始化模块。"""
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """在应用程序关闭序列中平稳地关闭模块。"""
        pass

    def get_endpoints(self) -> List[RESTEndpoint]:
        """返回此模块暴露的 REST API 端点列表。"""
        return []
