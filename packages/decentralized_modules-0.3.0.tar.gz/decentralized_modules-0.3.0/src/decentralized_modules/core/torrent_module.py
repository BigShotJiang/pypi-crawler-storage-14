"""
Torrent Module
P2P 网络 BitTorrent 协议功能实现
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional
import sys

# 尝试导入 libtorrent，如果不存在则使用 Mock 保护
try:
    import libtorrent as lt
    HAS_LIBTORRENT = True
except ImportError:
    HAS_LIBTORRENT = False
    # Mock lt for type hinting or usage in else blocks if needed
    class lt:
        class session:
            pass
        class add_torrent_params:
            pass
        class torrent_info:
            def __init__(self, data): pass

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session


@dataclass
class TorrentInfo:
    """种子信息"""
    infohash: str
    name: str
    size: int
    files: List[Dict[str, Any]]
    trackers: List[str]
    piece_length: int
    num_pieces: int


@dataclass
class DownloadConfig:
    """下载配置"""
    save_path: str = "./downloads"
    max_upload_rate: int = 0  # 0 表示无限制
    max_download_rate: int = 0  # 0 表示无限制
    upload_limit: int = 0 # alias for compatibility
    download_limit: int = 0 # alias for compatibility

    def __post_init__(self):
        if self.upload_limit == 0 and self.max_upload_rate > 0:
            self.upload_limit = self.max_upload_rate
        if self.download_limit == 0 and self.max_download_rate > 0:
            self.download_limit = self.max_download_rate


@dataclass
class TorrentStatus:
    """种子状态"""
    infohash: str
    state: str  # downloading, seeding, completed, paused, error, checking
    progress: float  # 0.0 到 1.0
    download_rate: int  # 字节/秒
    upload_rate: int  # 字节/秒
    num_seeders: int
    num_leechers: int
    eta: int  # 预计剩余时间（秒）
    total_wanted: int = 0
    total_wanted_done: int = 0


class ITorrentEngine(ABC):
    """种子引擎抽象接口"""
    
    @abstractmethod
    async def add_torrent(self, torrent_data: bytes, config: DownloadConfig) -> bool:
        """添加种子"""
        pass
    
    @abstractmethod
    async def remove_torrent(self, infohash: str) -> bool:
        """移除种子"""
        pass
    
    @abstractmethod
    async def get_torrent_status(self, infohash: str) -> Optional[TorrentStatus]:
        """获取种子状态"""
        pass
    
    @abstractmethod
    async def get_all_torrents(self) -> List[TorrentStatus]:
        """获取所有种子状态"""
        pass
    
    @abstractmethod
    async def start_torrent(self, infohash: str) -> bool:
        """开始下载/做种"""
        pass
    
    @abstractmethod
    async def stop_torrent(self, infohash: str) -> bool:
        """停止种子"""
        pass


class DefaultTorrentEngine(ITorrentEngine):
    """
    默认种子引擎实现 (Mock)

    用于开发和测试环境，或者当 libtorrent 不可用时。
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._torrents: Dict[str, TorrentStatus] = {}
        self._initialized = False
    
    async def initialize(self):
        """初始化种子引擎"""
        self.logger.info("初始化种子引擎 (Mock)...")
        self._initialized = True
    
    async def shutdown(self):
        """关闭种子引擎"""
        self.logger.info("关闭种子引擎 (Mock)...")
        self._initialized = False
    
    async def add_torrent(self, torrent_data: bytes, config: DownloadConfig) -> bool:
        """添加种子 (Mock)"""
        if not self._initialized:
            return False
        
        import hashlib
        infohash = hashlib.sha1(torrent_data).hexdigest()

        self.logger.info(f"添加种子 (Mock): {infohash}")

        if infohash not in self._torrents:
            status = TorrentStatus(
                infohash=infohash,
                state="paused",
                progress=0.0,
                download_rate=0,
                upload_rate=0,
                num_seeders=0,
                num_leechers=0,
                eta=0
            )
            self._torrents[infohash] = status
            return True
        return False
    
    async def remove_torrent(self, infohash: str) -> bool:
        """移除种子 (Mock)"""
        if infohash in self._torrents:
            del self._torrents[infohash]
            self.logger.info(f"移除种子: {infohash}")
            return True
        return False
    
    async def get_torrent_status(self, infohash: str) -> Optional[TorrentStatus]:
        """获取种子状态 (Mock)"""
        return self._torrents.get(infohash)
    
    async def get_all_torrents(self) -> List[TorrentStatus]:
        """获取所有种子状态 (Mock)"""
        return list(self._torrents.values())
    
    async def start_torrent(self, infohash: str) -> bool:
        """开始种子 (Mock)"""
        if infohash in self._torrents:
            self._torrents[infohash].state = "downloading"
            self.logger.info(f"开始种子: {infohash}")
            return True
        return False
    
    async def stop_torrent(self, infohash: str) -> bool:
        """停止种子 (Mock)"""
        if infohash in self._torrents:
            self._torrents[infohash].state = "paused"
            self.logger.info(f"停止种子: {infohash}")
            return True
        return False


class LibTorrentEngine(ITorrentEngine):
    """
    基于 LibTorrent 的真实种子引擎实现
    """

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.lt_session = None
        self._handles: Dict[str, Any] = {} # infohash -> lt.torrent_handle
        self._initialized = False

    async def initialize(self):
        """初始化 LibTorrent 会话"""
        if not HAS_LIBTORRENT:
             self.logger.error("LibTorrent library not available.")
             raise ImportError("libtorrent not installed")

        self.logger.info("初始化 LibTorrent 引擎...")

        # 配置 LibTorrent 会话
        settings = {
            'user_agent': 'DecentralizedModule/1.0',
            'listen_interfaces': '0.0.0.0:6881',
            'alert_mask': lt.alert.category_t.all_categories
        }

        self.lt_session = lt.session(settings)
        self._initialized = True
        self.logger.info("LibTorrent 引擎初始化完成")

    async def shutdown(self):
        """关闭引擎"""
        if self.lt_session:
            self.logger.info("暂停 LibTorrent 会话...")
            self.lt_session.pause()
            # 移除所有种子
            # for handle in self._handles.values():
            #     self.lt_session.remove_torrent(handle)
        self._initialized = False

    async def add_torrent(self, torrent_data: bytes, config: DownloadConfig) -> bool:
        """添加种子"""
        if not self._initialized:
            return False

        try:
            e = lt.bdecode(torrent_data)
            info = lt.torrent_info(e)
            infohash = str(info.info_hash())

            if infohash in self._handles:
                self.logger.info(f"种子 {infohash} 已存在")
                return True

            params = {
                'ti': info,
                'save_path': config.save_path,
                'storage_mode': lt.storage_mode_t.storage_mode_sparse
            }

            handle = self.lt_session.add_torrent(params)

            # 应用限速配置
            if config.max_download_rate > 0:
                handle.set_download_limit(config.max_download_rate)
            if config.max_upload_rate > 0:
                handle.set_upload_limit(config.max_upload_rate)

            self._handles[infohash] = handle
            self.logger.info(f"已添加种子: {info.name()} ({infohash})")
            return True

        except Exception as e:
            self.logger.error(f"添加种子失败: {e}")
            return False

    async def remove_torrent(self, infohash: str) -> bool:
        """移除种子"""
        if not self._initialized:
            return False

        handle = self._handles.get(infohash)
        if handle:
            self.lt_session.remove_torrent(handle)
            del self._handles[infohash]
            self.logger.info(f"已移除种子: {infohash}")
            return True
        return False

    async def get_torrent_status(self, infohash: str) -> Optional[TorrentStatus]:
        """获取单个种子状态"""
        handle = self._handles.get(infohash)
        if not handle:
            return None

        return self._create_status_from_handle(infohash, handle)

    async def get_all_torrents(self) -> List[TorrentStatus]:
        """获取所有种子状态"""
        statuses = []
        for infohash, handle in self._handles.items():
            if not handle.is_valid():
                continue
            status = self._create_status_from_handle(infohash, handle)
            statuses.append(status)
        return statuses

    def _create_status_from_handle(self, infohash: str, handle: Any) -> TorrentStatus:
        """从 lt.torrent_handle 创建状态对象"""
        status = handle.status()

        state_str = "unknown"
        if status.state == lt.torrent_status.states.downloading:
            state_str = "downloading"
        elif status.state == lt.torrent_status.states.seeding:
            state_str = "seeding"
        elif status.state == lt.torrent_status.states.finished:
            state_str = "completed"
        elif status.state == lt.torrent_status.states.checking_files:
            state_str = "checking"
        elif status.paused:
            state_str = "paused"
        elif status.errc:
            state_str = "error"

        # 预估时间计算
        eta = 0
        if status.download_payload_rate > 0:
             remain = status.total_wanted - status.total_wanted_done
             eta = int(remain / status.download_payload_rate)

        return TorrentStatus(
            infohash=infohash,
            state=state_str,
            progress=status.progress,
            download_rate=status.download_payload_rate,
            upload_rate=status.upload_payload_rate,
            num_seeders=status.num_seeds,
            num_leechers=status.num_peers - status.num_seeds, # 简单估算
            eta=eta,
            total_wanted=status.total_wanted,
            total_wanted_done=status.total_wanted_done
        )

    async def start_torrent(self, infohash: str) -> bool:
        """开始 (恢复) 种子"""
        handle = self._handles.get(infohash)
        if handle:
            handle.resume()
            # 强制不自动管理，确保立即启动
            handle.auto_managed(False)
            return True
        return False

    async def stop_torrent(self, infohash: str) -> bool:
        """停止 (暂停) 种子"""
        handle = self._handles.get(infohash)
        if handle:
            handle.pause()
            return True
        return False


class TorrentModule(IModule):
    """
    TorrentModule - 负责处理 BitTorrent 协议的核心功能
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._name = "torrent-module"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = None
        self.initialized = False
        self.torrent_engine: Optional[ITorrentEngine] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return ["network-module", "database-module"]

    async def initialize(self, session: 'Session') -> None:
        """初始化种子模块"""
        try:
            self.logger.info("Initializing Torrent Module...")
            self.session = session
            
            # 策略：优先尝试使用 LibTorrentEngine，如果失败（如库缺失）则回退到 Mock
            if HAS_LIBTORRENT and not self.config.get("force_mock", False):
                try:
                    self.logger.info("Attempting to use LibTorrentEngine...")
                    self.torrent_engine = LibTorrentEngine()
                    await self.torrent_engine.initialize()
                    self.logger.info("LibTorrentEngine initialized successfully.")
                except ImportError:
                    self.logger.warning("LibTorrent not found/loadable, falling back to DefaultTorrentEngine.")
                    self.torrent_engine = DefaultTorrentEngine()
                    await self.torrent_engine.initialize()
                except Exception as e:
                    self.logger.error(f"Failed to initialize LibTorrentEngine: {e}, falling back to Mock.")
                    self.torrent_engine = DefaultTorrentEngine()
                    await self.torrent_engine.initialize()
            else:
                self.logger.info("Using DefaultTorrentEngine (Mock) by configuration or environment.")
                self.torrent_engine = DefaultTorrentEngine()
                await self.torrent_engine.initialize()
            
            session.context.register_service("torrent_engine", self.torrent_engine)
            
            self.initialized = True
            self.logger.info("Torrent Module initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize Torrent Module: {e}")
            raise

    async def shutdown(self) -> None:
        """关闭种子模块"""
        try:
            self.logger.info("Shutting down Torrent Module...")
            if self.torrent_engine:
                await self.torrent_engine.shutdown()
            self.initialized = False
            self.logger.info("Torrent Module shutdown completed")
        except Exception as e:
            self.logger.error(f"Error during Torrent Module shutdown: {e}")

    # ... [Proxy methods below delegate to self.torrent_engine] ...

    async def add_torrent(self, torrent_data: bytes, config: DownloadConfig = None) -> bool:
        if not self.initialized or not self.torrent_engine:
            self.logger.warning("TorrentModule not initialized")
            return False
        config = config or DownloadConfig()
        return await self.torrent_engine.add_torrent(torrent_data, config)

    async def remove_torrent(self, infohash: str) -> bool:
        if not self.initialized or not self.torrent_engine: return False
        return await self.torrent_engine.remove_torrent(infohash)

    async def get_torrent_status(self, infohash: str) -> Optional[TorrentStatus]:
        if not self.initialized or not self.torrent_engine: return None
        return await self.torrent_engine.get_torrent_status(infohash)

    async def get_all_torrents(self) -> List[TorrentStatus]:
        if not self.initialized or not self.torrent_engine: return []
        return await self.torrent_engine.get_all_torrents()

    async def start_torrent(self, infohash: str) -> bool:
        if not self.initialized or not self.torrent_engine: return False
        return await self.torrent_engine.start_torrent(infohash)

    async def stop_torrent(self, infohash: str) -> bool:
        if not self.initialized or not self.torrent_engine: return False
        return await self.torrent_engine.stop_torrent(infohash)

    def get_services(self) -> Dict[str, Any]:
        return {"torrent_engine": self.torrent_engine}

    def get_endpoints(self) -> List[RESTEndpoint]:
        return [
            RESTEndpoint("/api/torrents/add", self.handle_add_torrent),
            RESTEndpoint("/api/torrents/remove", self.handle_remove_torrent),
            RESTEndpoint("/api/torrents/list", self.handle_list_torrents),
            RESTEndpoint("/api/torrents/start", self.handle_start_torrent),
            RESTEndpoint("/api/torrents/stop", self.handle_stop_torrent),
            RESTEndpoint("/api/torrents/status", self.handle_torrent_status),
        ]

    # ... [Handler methods] ...
    async def handle_add_torrent(self, request: Any) -> Dict[str, Any]:
        try:
            torrent_data = request.get("torrent_data")
            if not torrent_data: return {"error": "Missing torrent_data"}
            config = DownloadConfig(**request.get("config", {}))
            success = await self.add_torrent(torrent_data, config)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling add torrent request: {e}")
            return {"error": str(e), "success": False}

    async def handle_remove_torrent(self, request: Any) -> Dict[str, Any]:
        try:
            infohash = request.get("infohash")
            if not infohash: return {"error": "Missing infohash"}
            success = await self.remove_torrent(infohash)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling remove torrent request: {e}")
            return {"error": str(e), "success": False}

    async def handle_list_torrents(self, request: Any) -> Dict[str, Any]:
        try:
            torrents = await self.get_all_torrents()
            return {"torrents": [t.__dict__ for t in torrents], "count": len(torrents)}
        except Exception as e:
            self.logger.error(f"Error handling list torrents request: {e}")
            return {"error": str(e), "torrents": []}

    async def handle_start_torrent(self, request: Any) -> Dict[str, Any]:
        try:
            infohash = request.get("infohash")
            if not infohash: return {"error": "Missing infohash"}
            success = await self.start_torrent(infohash)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling start torrent request: {e}")
            return {"error": str(e), "success": False}

    async def handle_stop_torrent(self, request: Any) -> Dict[str, Any]:
        try:
            infohash = request.get("infohash")
            if not infohash: return {"error": "Missing infohash"}
            success = await self.stop_torrent(infohash)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling stop torrent request: {e}")
            return {"error": str(e), "success": False}

    async def handle_torrent_status(self, request: Any) -> Dict[str, Any]:
        try:
            infohash = request.get("infohash")
            if not infohash: return {"error": "Missing infohash"}
            status = await self.get_torrent_status(infohash)
            if status: return {"status": status.__dict__}
            else: return {"error": "Torrent not found"}
        except Exception as e:
            self.logger.error(f"Error handling torrent status request: {e}")
            return {"error": str(e)}

    def get_health_status(self) -> dict:
        engine_type = "mock"
        if isinstance(self.torrent_engine, LibTorrentEngine):
            engine_type = "libtorrent"

        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "engine_type": engine_type,
                "torrent_engine_available": self.torrent_engine is not None,
                # Use duck typing or check type to access protected members if needed for stats
                "torrent_count": len(self.torrent_engine.get_all_torrents()) if hasattr(self.torrent_engine, "get_all_torrents") and asyncio.iscoroutinefunction(self.torrent_engine.get_all_torrents) is False else 0 # Careful with async calls in sync status check
            }
        }
