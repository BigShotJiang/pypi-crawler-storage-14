"""
Tunnel Module
网络隧道与匿名通信模块
"""

import asyncio
import logging
from typing import List, Dict, Optional, Any, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum
from abc import ABC, abstractmethod

# 尝试导入 ipv8 相关组件
try:
    from ipv8.messaging.anonymization.tunnel import Tunnel
    from ipv8.messaging.anonymization.community import HiddenTunnelCommunity
    HAS_IPV8_TUNNEL = True
except ImportError:
    HAS_IPV8_TUNNEL = False
    # Mock classes for type hinting
    class Tunnel: pass
    class HiddenTunnelCommunity: pass

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session


class TunnelState(Enum):
    """隧道状态枚举"""
    INITIALIZING = "initializing"
    ESTABLISHED = "established"
    CONNECTING = "connecting"
    DISCONNECTED = "disconnected"
    ERROR = "error"


@dataclass
class TunnelInfo:
    """隧道信息"""
    tunnel_id: str
    circuit_id: int
    state: TunnelState
    target_host: str
    target_port: int
    local_port: int
    uptime: int  # 秒
    bytes_up: int
    bytes_down: int


@dataclass
class TunnelConfig:
    """隧道配置"""
    max_circuits: int = 3
    circuit_timeout: int = 30  # 秒
    enable_anonymous: bool = True
    encryption_level: str = "medium"  # low, medium, high
    hops: int = 2 # 隧道跳数


class ITunnelEngine(ABC):
    """隧道引擎抽象接口"""
    
    @abstractmethod
    async def create_tunnel(self, target_host: str, target_port: int, config: TunnelConfig) -> Optional[str]:
        """Create a new tunnel"""
        pass
    
    @abstractmethod
    async def destroy_tunnel(self, tunnel_id: str) -> bool:
        """Destroy a tunnel"""
        pass
    
    @abstractmethod
    async def get_tunnel_info(self, tunnel_id: str) -> Optional[TunnelInfo]:
        """Get information about a tunnel"""
        pass
    
    @abstractmethod
    async def get_all_tunnels(self) -> List[TunnelInfo]:
        """Get information about all tunnels"""
        pass
    
    @abstractmethod
    async def get_tunnel_stats(self) -> Dict[str, Any]:
        """Get tunnel statistics"""
        pass


class DefaultTunnelEngine(ITunnelEngine):
    """
    默认隧道引擎实现 (Mock)

    模拟隧道创建和连接过程。
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._tunnels: Dict[str, TunnelInfo] = {}
        self._circuits: Dict[int, Any] = {}
        self._next_circuit_id = 1
        self._next_tunnel_id = 1
        self._initialized = False
    
    async def initialize(self):
        """初始化隧道引擎"""
        self.logger.info("初始化隧道引擎 (Mock)...")
        self._initialized = True
    
    async def shutdown(self):
        """关闭隧道引擎"""
        self.logger.info("关闭隧道引擎 (Mock)...")
        # Close all tunnels
        for tunnel_id in list(self._tunnels.keys()):
            await self.destroy_tunnel(tunnel_id)
        self._initialized = False
    
    async def create_tunnel(self, target_host: str, target_port: int, config: TunnelConfig) -> Optional[str]:
        """创建新隧道"""
        if not self._initialized:
            return None
        
        self.logger.info(f"创建隧道至 {target_host}:{target_port}")
        
        # Generate tunnel ID
        tunnel_id = f"tunnel_{self._next_tunnel_id}"
        self._next_tunnel_id += 1
        
        # Create circuit
        circuit_id = self._next_circuit_id
        self._next_circuit_id += 1
        
        # Create tunnel info
        tunnel_info = TunnelInfo(
            tunnel_id=tunnel_id,
            circuit_id=circuit_id,
            state=TunnelState.CONNECTING,
            target_host=target_host,
            target_port=target_port,
            local_port=0,
            uptime=0,
            bytes_up=0,
            bytes_down=0
        )
        
        # Store tunnel
        self._tunnels[tunnel_id] = tunnel_info
        self._circuits[circuit_id] = tunnel_info
        
        # Simulate tunnel establishment
        await asyncio.sleep(0.1)  # Simulate connection time
        tunnel_info.state = TunnelState.ESTABLISHED
        tunnel_info.local_port = 12345 + circuit_id  # Mock local port
        
        self.logger.info(f"隧道 {tunnel_id} 已建立")
        return tunnel_id
    
    async def destroy_tunnel(self, tunnel_id: str) -> bool:
        """Destroy a tunnel"""
        if tunnel_id not in self._tunnels:
            return False
        
        tunnel_info = self._tunnels[tunnel_id]
        self.logger.info(f"Destroying tunnel {tunnel_id}")
        
        if tunnel_info.circuit_id in self._circuits:
            del self._circuits[tunnel_info.circuit_id]
        
        del self._tunnels[tunnel_id]
        return True
    
    async def get_tunnel_info(self, tunnel_id: str) -> Optional[TunnelInfo]:
        """Get information about a tunnel"""
        return self._tunnels.get(tunnel_id)
    
    async def get_all_tunnels(self) -> List[TunnelInfo]:
        """Get information about all tunnels"""
        return list(self._tunnels.values())
    
    async def get_tunnel_stats(self) -> Dict[str, Any]:
        """Get tunnel statistics"""
        total_up = sum(t.bytes_up for t in self._tunnels.values())
        total_down = sum(t.bytes_down for t in self._tunnels.values())
        
        return {
            "total_tunnels": len(self._tunnels),
            "total_circuits": len(self._circuits),
            "bytes_up": total_up,
            "bytes_down": total_down,
            "uptime": sum(t.uptime for t in self._tunnels.values())
        }


class IPv8TunnelEngine(ITunnelEngine):
    """
    基于 IPv8 的真实隧道引擎
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.community = None # HiddenTunnelCommunity 实例
        self._tunnels: Dict[str, TunnelInfo] = {}
        self._initialized = False

    async def initialize(self):
        """初始化"""
        if not HAS_IPV8_TUNNEL:
             self.logger.error("IPv8 Tunnel libraries not found")
             raise ImportError("IPv8 not installed")

        self.logger.info("初始化 IPv8 隧道引擎...")

        network_module = self.session.get_module("network-module")
        if network_module and network_module.service.ipv8:
            # 在真实场景中，创建 HiddenTunnelCommunity 并添加到 ipv8 overlays
            # self.community = HiddenTunnelCommunity(network_module.service.ipv8.endpoint, ...)
            # network_module.service.ipv8.add_overlay(self.community)
            pass

        self._initialized = True
        self.logger.info("IPv8 隧道引擎初始化完成")

    async def shutdown(self):
        self._initialized = False

    async def create_tunnel(self, target_host: str, target_port: int, config: TunnelConfig) -> Optional[str]:
        if not self._initialized: return None

        self.logger.info(f"IPv8 隧道构建请求: {target_host}:{target_port}, hops={config.hops}")

        # 真实 API 调用逻辑 (如果 community 存在)
        circuit_id = 0
        local_port = 0
        state = TunnelState.ERROR

        if self.community:
            try:
                # 假设 build_tunnels 返回 circuit
                circuit = await self.community.build_tunnels(config.hops)
                if circuit:
                    circuit_id = circuit.circuit_id
                    state = TunnelState.ESTABLISHED
                    # 创建 Exit Tunnel (需要更多参数，如 exit node)
                    # exit_socket = self.community.create_exit_socket(circuit, target_host, target_port)
                    # local_port = exit_socket.getsockname()[1]
            except Exception as e:
                self.logger.error(f"Failed to build tunnel: {e}")
        else:
             # 如果没有真实 community，我们仅记录意图，不进行 Mock (因为这是 Real Engine)
             self.logger.warning("No HiddenTunnelCommunity available to build tunnel")
             return None

        # 仅当真实创建成功时记录
        if state == TunnelState.ESTABLISHED:
            tunnel_id = f"ipv8_tunnel_{circuit_id}"
            info = TunnelInfo(
                tunnel_id=tunnel_id,
                circuit_id=circuit_id,
                state=state,
                target_host=target_host,
                target_port=target_port,
                local_port=local_port,
                uptime=0,
                bytes_up=0,
                bytes_down=0
            )
            self._tunnels[tunnel_id] = info
            return tunnel_id

        return None

    async def destroy_tunnel(self, tunnel_id: str) -> bool:
        if tunnel_id in self._tunnels:
            if self.community:
                # self.community.remove_tunnel(self._tunnels[tunnel_id].circuit_id)
                pass
            del self._tunnels[tunnel_id]
            return True
        return False

    async def get_tunnel_info(self, tunnel_id: str) -> Optional[TunnelInfo]:
        return self._tunnels.get(tunnel_id)

    async def get_all_tunnels(self) -> List[TunnelInfo]:
        return list(self._tunnels.values())

    async def get_tunnel_stats(self) -> Dict[str, Any]:
        return {"active_tunnels": len(self._tunnels)}


class TunnelModule(IModule):
    """
    TunnelModule - 负责网络隧道和匿名通信功能
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._name = "tunnel-module"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = None
        self.initialized = False
        self.tunnel_engine = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return ["event-notification-module", "network-module"]

    async def initialize(self, session: 'Session') -> None:
        """初始化隧道模块"""
        try:
            self.logger.info("Initializing Tunnel Module...")
            self.session = session
            
            # 策略：优先尝试 IPv8TunnelEngine
            if HAS_IPV8_TUNNEL and not self.config.get("force_mock", False):
                 try:
                     self.tunnel_engine = IPv8TunnelEngine(session)
                     await self.tunnel_engine.initialize()
                     self.logger.info("Using IPv8TunnelEngine")
                 except Exception as e:
                     self.logger.error(f"Failed to init IPv8TunnelEngine: {e}")
                     self.tunnel_engine = DefaultTunnelEngine()
                     await self.tunnel_engine.initialize()
            else:
                 self.tunnel_engine = DefaultTunnelEngine()
                 await self.tunnel_engine.initialize()
            
            session.context.register_service("tunnel_engine", self.tunnel_engine)
            
            self.initialized = True
            self.logger.info("Tunnel Module initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize Tunnel Module: {e}")
            raise

    async def shutdown(self) -> None:
        """关闭隧道模块"""
        try:
            self.logger.info("Shutting down Tunnel Module...")
            if self.tunnel_engine:
                await self.tunnel_engine.shutdown()
            self.initialized = False
            self.logger.info("Tunnel Module shutdown completed")
        except Exception as e:
            self.logger.error(f"Error during Tunnel Module shutdown: {e}")

    # ... [Proxy methods] ...

    async def create_tunnel(self, target_host: str, target_port: int, config: TunnelConfig = None) -> Optional[str]:
        if not self.initialized or not self.tunnel_engine:
            self.logger.warning("TunnelModule not initialized")
            return None
        config = config or TunnelConfig()
        return await self.tunnel_engine.create_tunnel(target_host, target_port, config)

    async def destroy_tunnel(self, tunnel_id: str) -> bool:
        if not self.initialized or not self.tunnel_engine: return False
        return await self.tunnel_engine.destroy_tunnel(tunnel_id)

    async def get_tunnel_info(self, tunnel_id: str) -> Optional[TunnelInfo]:
        if not self.initialized or not self.tunnel_engine: return None
        return await self.tunnel_engine.get_tunnel_info(tunnel_id)

    async def get_all_tunnels(self) -> List[TunnelInfo]:
        if not self.initialized or not self.tunnel_engine: return []
        return await self.tunnel_engine.get_all_tunnels()

    async def get_tunnel_stats(self) -> Dict[str, Any]:
        if not self.initialized or not self.tunnel_engine: return {}
        return await self.tunnel_engine.get_tunnel_stats()

    def get_services(self) -> Dict[str, Any]:
        return {"tunnel_engine": self.tunnel_engine}

    def get_endpoints(self) -> List[RESTEndpoint]:
        return [
            RESTEndpoint("/api/tunnels/create", self.handle_create_tunnel),
            RESTEndpoint("/api/tunnels/destroy", self.handle_destroy_tunnel),
            RESTEndpoint("/api/tunnels/list", self.handle_list_tunnels),
            RESTEndpoint("/api/tunnels/info", self.handle_tunnel_info),
            RESTEndpoint("/api/tunnels/stats", self.handle_tunnel_stats),
        ]

    # ... [Handler methods] ...
    async def handle_create_tunnel(self, request: Any) -> Dict[str, Any]:
        try:
            target_host = request.get("target_host")
            target_port = request.get("target_port")
            if not target_host or not target_port:
                return {"error": "Missing target_host or target_port"}
            
            config_dict = request.get("config", {})
            config = TunnelConfig(**config_dict)
            
            tunnel_id = await self.create_tunnel(target_host, target_port, config)
            if tunnel_id:
                return {"success": True, "tunnel_id": tunnel_id}
            else:
                return {"success": False, "error": "Failed to create tunnel"}
        except Exception as e:
            self.logger.error(f"Error handling create tunnel request: {e}")
            return {"error": str(e), "success": False}

    async def handle_destroy_tunnel(self, request: Any) -> Dict[str, Any]:
        try:
            tunnel_id = request.get("tunnel_id")
            if not tunnel_id: return {"error": "Missing tunnel_id"}
            success = await self.destroy_tunnel(tunnel_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling destroy tunnel request: {e}")
            return {"error": str(e), "success": False}

    async def handle_list_tunnels(self, request: Any) -> Dict[str, Any]:
        try:
            tunnels = await self.get_all_tunnels()
            return {"tunnels": [t.__dict__ for t in tunnels], "count": len(tunnels)}
        except Exception as e:
            self.logger.error(f"Error handling list tunnels request: {e}")
            return {"error": str(e), "tunnels": []}

    async def handle_tunnel_info(self, request: Any) -> Dict[str, Any]:
        try:
            tunnel_id = request.get("tunnel_id")
            if not tunnel_id: return {"error": "Missing tunnel_id"}
            tunnel_info = await self.get_tunnel_info(tunnel_id)
            if tunnel_info: return {"info": tunnel_info.__dict__}
            else: return {"error": "Tunnel not found"}
        except Exception as e:
            self.logger.error(f"Error handling tunnel info request: {e}")
            return {"error": str(e)}

    async def handle_tunnel_stats(self, request: Any) -> Dict[str, Any]:
        try:
            stats = await self.get_tunnel_stats()
            return {"stats": stats}
        except Exception as e:
            self.logger.error(f"Error handling tunnel stats request: {e}")
            return {"error": str(e), "stats": {}}

    def get_health_status(self) -> dict:
        engine_type = "mock"
        if isinstance(self.tunnel_engine, IPv8TunnelEngine):
            engine_type = "ipv8"

        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "engine_type": engine_type,
                "tunnel_engine_available": self.tunnel_engine is not None,
                "active_tunnels": len(self.tunnel_engine._tunnels) if self.tunnel_engine else 0
            }
        }
