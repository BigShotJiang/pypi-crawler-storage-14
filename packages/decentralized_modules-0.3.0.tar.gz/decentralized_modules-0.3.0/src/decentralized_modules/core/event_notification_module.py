"""
Event Notification Module
事件通知模块，提供系统级发布-订阅机制
"""

from typing import TYPE_CHECKING, List
import logging
from .notifier import Notifier

if TYPE_CHECKING:
    from .session import Session

from ..interfaces import IModule, RESTEndpoint


class EventNotificationModule(IModule):
    """
    事件通知模块 (EventNotificationModule)

    该模块提供了一个系统级的、解耦的发布-订阅事件总线。
    它允许系统的不同部分之间进行异步通信，而无需直接相互依赖。

    主要功能：
    - 提供全局 Notifier 实例
    - 支持事件订阅和发布

    使用示例：

    ```python
    # 获取模块
    event_module = session.get_module("event-notification-module")
    notifier = session.notifier  # 或者通过 session 直接访问

    # 订阅事件
    def on_torrent_finished(infohash, name, hidden):
        print(f"Torrent finished: {name}")

    notifier.add("torrent_finished", on_torrent_finished)

    # 发布事件 (通常由其他模块触发)
    notifier.notify("torrent_finished", infohash="abc...", name="My File", hidden=False)
    ```
    """

    def __init__(self):
        super().__init__()
        self._name = "event-notification-module"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.initialized = False

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, session: 'Session') -> None:
        """
        初始化事件通知模块。

        此方法会创建一个 Notifier 实例，并将其附加到 Session 对象上，
        使其成为全局可访问的事件总线。
        """
        self.logger.info("Initializing EventNotificationModule...")

        # 实例化 Notifier 服务
        notifier = Notifier()

        # 将 Notifier 实例附加到 Session，以供其他模块和服务使用
        session.notifier = notifier
        session.context.register_service("notifier", notifier)

        self.initialized = True
        self.logger.info("EventNotificationModule initialized")

    async def shutdown(self) -> None:
        """
        关闭模块。
        """
        self.logger.info("Shutting down EventNotificationModule...")
        self.initialized = False

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []
