"""
模块依赖管理器
管理模块间的依赖关系和服务注入
"""

from typing import Dict, List, Optional, Any, Type
from ..interfaces import IModule
class ServiceRegistry:
    """
    服务注册表，用于管理模块间的服务依赖
    """

    def __init__(self):
        self._services: Dict[str, Any] = {}
        self._service_providers: Dict[str, str] = {}  # service_name -> module_name

    def register_service(self, name: str, service: Any, provider_module: str) -> None:
        """
        注册服务

        :param name: 服务名称
        :param service: 服务实例
        :param provider_module: 提供服务的模块名称
        """
        self._services[name] = service
        self._service_providers[name] = provider_module

    def get_service(self, name: str) -> Optional[Any]:
        """
        获取服务

        :param name: 服务名称
        :return: 服务实例，如果不存在则返回 None
        """
        return self._services.get(name)

    def unregister_service(self, name: str) -> bool:
        """
        注销服务

        :param name: 服务名称
        :return: 是否成功注销
        """
        if name in self._services:
            del self._services[name]
            del self._service_providers[name]
            return True
        return False

    def get_service_provider(self, name: str) -> Optional[str]:
        """
        获取服务的提供模块

        :param name: 服务名称
        :return: 模块名称，如果不存在则返回 None
        """
        return self._service_providers.get(name)

    def list_services(self) -> List[str]:
        """
        列出所有注册的服务

        :return: 服务名称列表
        """
        return list(self._services.keys())
class DependencyManager:
    """
    依赖管理器，处理模块间的依赖关系
    """

    def __init__(self):
        self._modules: Dict[str, IModule] = {}
        self._dependencies: Dict[str, List[str]] = {}  # module_name -> [dependency_names]
        self._dependents: Dict[str, List[str]] = {}  # module_name -> [dependent_names]
        self._service_registry = ServiceRegistry()

    def register_module(self, module: IModule) -> None:
        """
        注册模块

        :param module: 模块实例
        """
        self._modules[module.name] = module
        self._dependencies[module.name] = module.dependencies

        # 更新反向依赖关系
        for dep in module.dependencies:
            if dep not in self._dependents:
                self._dependents[dep] = []
            self._dependents[dep].append(module.name)

    def unregister_module(self, name: str) -> bool:
        """
        注销模块

        :param name: 模块名称
        :return: 是否成功注销
        """
        if name not in self._modules:
            return False

        # 检查是否有其他模块依赖此模块
        if name in self._dependents and self._dependents[name]:
            raise ValueError(f"Cannot unregister module '{name}' as it is required by: {self._dependents[name]}")

        # 移除依赖关系
        for dep in self._dependencies.get(name, []):
            if dep in self._dependents and name in self._dependents[dep]:
                self._dependents[dep].remove(name)

        # 注销服务
        services_to_remove = []
        for service_name, provider in self._service_registry._service_providers.items():
            if provider == name:
                services_to_remove.append(service_name)

        for service_name in services_to_remove:
            self._service_registry.unregister_service(service_name)

        # 移除模块
        del self._modules[name]
        del self._dependencies[name]
        if name in self._dependents:
            del self._dependents[name]

        return True

    def get_module(self, name: str) -> Optional[IModule]:
        """
        获取模块

        :param name: 模块名称
        :return: 模块实例，如果不存在则返回 None
        """
        return self._modules.get(name)

    def get_initialization_order(self) -> List[str]:
        """
        获取模块初始化顺序（拓扑排序）

        :return: 模块名称列表，按依赖关系排序
        """
        # 简化的拓扑排序实现
        order = []
        remaining = set(self._modules.keys())

        while remaining:
            # 找到没有未满足依赖的模块
            ready = []
            for module_name in remaining:
                deps = self._dependencies.get(module_name, [])
                if all(dep not in remaining for dep in deps):
                    ready.append(module_name)

            if not ready:
                # 存在循环依赖
                raise ValueError("Circular dependency detected")

            for module_name in ready:
                order.append(module_name)
                remaining.remove(module_name)

        return order

    def get_service_registry(self) -> ServiceRegistry:
        """
        获取服务注册表

        :return: 服务注册表实例
        """
        return self._service_registry

    def check_dependencies(self, module_name: str) -> List[str]:
        """
        检查模块的依赖是否满足

        :param module_name: 模块名称
        :return: 未满足的依赖列表
        """
        if module_name not in self._modules:
            return [f"Module '{module_name}' not found"]

        missing_deps = []
        for dep in self._dependencies.get(module_name, []):
            if dep not in self._modules:
                missing_deps.append(dep)

        return missing_deps