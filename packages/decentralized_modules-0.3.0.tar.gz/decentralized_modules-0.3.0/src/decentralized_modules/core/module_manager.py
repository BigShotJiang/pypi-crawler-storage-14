"""
模块管理器 - 管理模块的注册、依赖和生命周期
"""

import asyncio
import logging
from typing import Dict, List, Optional, TYPE_CHECKING, Any

from ..interfaces import IModule
from .dependency_manager import DependencyManager

if TYPE_CHECKING:
    from .session import Session
class ModuleManager:
    """
    模块管理器，负责管理所有模块的生命周期
    """
    def __init__(self, session: 'Session'):
        self.session = session
        self.dependency_manager = DependencyManager()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.initialized = False

    def register(self, module: IModule) -> None:
        """
        注册一个模块
        """
        if module.name in self.dependency_manager._modules:
            self.logger.warning(f"Module {module.name} already registered, skipping.")
            return

        self.dependency_manager.register_module(module)
        self.logger.info(f"Registered module: {module.name}")

    def get_module(self, name: str) -> Optional[IModule]:
        """
        获取指定名称的模块
        """
        return self.dependency_manager.get_module(name)

    def get_all_modules(self) -> List[IModule]:
        """
        获取所有已注册的模块
        """
        return list(self.dependency_manager._modules.values())

    def get_service_registry(self):
        """
        获取服务注册表
        """
        return self.dependency_manager.get_service_registry()

    async def initialize_all(self) -> None:
        """
        按照依赖顺序初始化所有模块
        """
        if self.initialized:
            self.logger.warning("Modules already initialized")
            return

        self.logger.info("Initializing all modules...")

        # 检查依赖关系
        for module_name in self.dependency_manager._modules:
            missing_deps = self.dependency_manager.check_dependencies(module_name)
            if missing_deps:
                self.logger.warning(f"Module {module_name} has missing dependencies: {missing_deps}")

        # 按依赖顺序排序
        try:
            init_order = self.dependency_manager.get_initialization_order()
        except ValueError as e:
            self.logger.error(f"Initialization failed: {e}")
            raise

        # 初始化所有模块
        for module_name in init_order:
            module = self.dependency_manager.get_module(module_name)
            if module:
                self.logger.info(f"Initializing module: {module.name}")
                try:
                    await module.initialize(self.session)

                    # 注册模块提供的服务
                    if hasattr(module, 'get_services'):
                        services = module.get_services()
                        for service_name, service in services.items():
                            self.dependency_manager.get_service_registry().register_service(
                                service_name, service, module.name
                            )

                except Exception as e:
                    self.logger.error(f"Failed to initialize module {module.name}: {e}")
                    raise

        self.initialized = True
        self.logger.info("All modules initialized successfully")

    async def shutdown_all(self) -> None:
        """
        按照依赖顺序关闭所有模块
        """
        self.logger.info("Shutting down all modules...")

        # 按依赖顺序的逆序关闭
        try:
            shutdown_order = self.dependency_manager.get_initialization_order()
            shutdown_order.reverse()
        except ValueError:
            # 如果存在循环依赖导致排序失败，则回退到简单的列表顺序
            shutdown_order = list(self.dependency_manager._modules.keys())

        for module_name in shutdown_order:
            module = self.dependency_manager.get_module(module_name)
            if module:
                self.logger.info(f"Shutting down module: {module.name}")
                try:
                    await module.shutdown()
                except Exception as e:
                    self.logger.error(f"Error shutting down module {module.name}: {e}")

        self.initialized = False
        self.logger.info("All modules shut down successfully")

    def get_health_status(self) -> Dict[str, Any]:
        """获取所有模块的健康状态"""
        health_status = {
            "overall_status": "healthy" if self.initialized else "uninitialized",
            "timestamp": asyncio.get_event_loop().time(),
            "modules": {},
            "services": {}
        }

        for name, module in self.dependency_manager._modules.items():
            try:
                if hasattr(module, 'get_health_status'):
                    health = module.get_health_status()
                else:
                    health = {"status": "healthy", "initialized": True}
                health_status["modules"][name] = health
            except Exception as e:
                health_status["modules"][name] = {
                    "status": "error",
                    "error": str(e)
                }

        # 添加服务状态
        service_registry = self.dependency_manager.get_service_registry()
        for service_name in service_registry.list_services():
            health_status["services"][service_name] = {
                "status": "available",
                "provider": service_registry.get_service_provider(service_name)
            }

        return health_status