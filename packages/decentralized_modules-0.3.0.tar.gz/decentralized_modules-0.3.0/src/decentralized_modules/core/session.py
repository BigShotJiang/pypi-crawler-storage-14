"""
通用会话接口和实现
"""

import asyncio
import logging
from typing import Optional, TYPE_CHECKING, Dict, Any

from .module_manager import ModuleManager

if TYPE_CHECKING:
    from ..interfaces import IModule


class ISessionContext:
    """
    会话上下文接口，提供模块间通信的基础设施
    """
    
    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._services: Dict[str, Any] = {}
    
    def set_data(self, key: str, value: Any) -> None:
        """设置会话数据"""
        self._data[key] = value
    
    def get_data(self, key: str, default: Any = None) -> Any:
        """获取会话数据"""
        return self._data.get(key, default)
    
    def register_service(self, name: str, service: Any) -> None:
        """注册服务"""
        self._services[name] = service
    
    def get_service(self, name: str) -> Optional[Any]:
        """获取服务"""
        return self._services.get(name)


class Session:
    """
    通用会话类，提供模块化架构的基础
    不依赖特定应用层逻辑
    """
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.context = ISessionContext()
        self.module_manager = ModuleManager(self)
        self.logger = logging.getLogger(self.__class__.__name__)
        self._initialized = False
        
    def register_module(self, module: 'IModule') -> None:
        """
        注册一个模块
        """
        self.module_manager.register(module)

    def get_module(self, name: str) -> Optional['IModule']:
        """
        获取指定名称的模块
        """
        return self.module_manager.get_module(name)

    async def start(self):
        """启动会话"""
        if self._initialized:
            self.logger.warning("Session already initialized")
            return
            
        self.logger.info("Starting session...")
        await self.module_manager.initialize_all()
        self._initialized = True
        self.logger.info("Session started successfully")

    async def shutdown(self):
        """关闭会话"""
        if not self._initialized:
            return
            
        self.logger.info("Shutting down session...")
        await self.module_manager.shutdown_all()
        self._initialized = False
        self.logger.info("Session shut down successfully")

    async def stop(self):
        """停止会话（shutdown的别名，为了兼容性）"""
        await self.shutdown()
    
    @property
    def is_initialized(self) -> bool:
        """检查会话是否已初始化"""
        return self._initialized