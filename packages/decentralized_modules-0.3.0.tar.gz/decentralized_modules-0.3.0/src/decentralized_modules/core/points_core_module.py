"""
PointsCoreModule

描述: 积分核心模块，负责管理整个生态系统中用户积分的生命周期。
"""

import asyncio
import hashlib
import logging
import time
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

# 移除对 pony orm 的直接依赖，改用 DatabaseModule
# from pony import orm

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session
    # 假设 DatabaseModule 提供了类似的存储接口
    # from ..foundation.database_module import MetadataStore

logger = logging.getLogger(__name__)


class TransactionType(str, Enum):
    """交易类型枚举"""
    EARN_SEEDING = "earn_seeding"
    EARN_RESCUE = "earn_rescue"
    EARN_REFERRAL = "earn_referral"
    EARN_BONUS = "earn_bonus"
    EARN_GIFT = "earn_gift"
    SPEND_DOWNLOAD = "spend_download"
    SPEND_GIFT = "spend_gift"


class PointsService:
    """
    积分服务，包含积分系统的所有业务逻辑。

    主要功能：
    - 管理用户积分余额
    - 处理积分赚取（做种、推荐等）
    - 处理积分消费（下载、赠送等）
    - 持久化交易记录到数据库

    使用示例：

    ```python
    # 假设已获取 session
    points_module = session.get_module("points-core-module")
    service = points_module.service

    # 获取余额
    balance = await service.get_user_balance("user123")
    print(f"User balance: {balance['balance']}")

    # 赚取积分
    await service.earn_points("user123", 50, "earn_seeding", "Seeding reward")
    ```
    """

    def __init__(self, session: 'Session', config: dict = None):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.db_module = None # 将在初始化时获取
        self.last_upload_amounts: Dict[str, int] = {}
        self.last_download_amounts: Dict[str, int] = {}
        # 使用配置参数，如果没有提供则使用默认值
        self.config = config or {
            "points_per_hour_seeding": 10,
            "points_per_mb_upload": 1,
            "points_per_share": 5,
            "points_per_rescue": 20,
            "points_per_mb_download": 1,
            "daily_bonus_points": 50,
            "referral_bonus_points": 100,
            "max_points_per_day": 1000,
            "min_balance_for_bonus": 10
        }

    async def start(self) -> None:
        self.logger.info("启动积分服务...")
        await self._initialize_dependencies()

        # 启动后台任务
        asyncio.create_task(self._check_seeding_status())
        asyncio.create_task(self._monitor_download_consumption())
        self.logger.info("积分服务启动完成")

    async def _initialize_dependencies(self) -> None:
        """初始化依赖，如数据库连接"""
        try:
            # 尝试从 Session 获取 DatabaseModule
            self.db_module = self.session.get_module("database-module")
            if self.db_module and getattr(self.db_module, 'initialized', False):
                self.logger.info("成功连接到 DatabaseModule")
            else:
                self.logger.warning("DatabaseModule 不可用或未初始化，积分持久化将不可用")
        except Exception as e:
            self.logger.error(f"初始化依赖失败: {e}")

    async def _check_seeding_status(self) -> None:
        """
        检查做种状态并发放奖励。
        注意：此处逻辑被简化，因为原逻辑依赖具体的 download_manager 实现。
        需要适配新的 DownloadManager 接口。
        """
        while True:
            try:
                # 示例：假设 session 有一个 download_manager
                if hasattr(self.session, 'download_manager') and self.session.download_manager:
                    # 这里需要根据实际的 DownloadManager API 进行调整
                    # 目前仅作占位符
                    pass
            except Exception as e:
                self.logger.error(f"积分计算错误: {e}")
            await asyncio.sleep(600)

    async def _monitor_download_consumption(self) -> None:
        """监控下载消耗并扣除积分"""
        while True:
            try:
                pass # 同样需要适配新的 DownloadManager
            except Exception as e:
                self.logger.error(f"下载扣费监控错误: {e}")
            await asyncio.sleep(60)

    async def stop(self) -> None:
        self.logger.info("停止积分服务...")
        self.logger.info("积分服务已停止")

    def _get_current_user_id(self) -> str:
        # 这里应该通过 IdentityModule 或类似机制获取
        return "default_user"

    async def get_user_balance(self, user_id: str) -> Dict[str, Any]:
        """获取用户余额"""
        balance = 0
        if self.db_module and self.db_module.store and self.db_module.store.connection:
            try:
                cursor = self.db_module.store.connection.cursor()
                cursor.execute("SELECT SUM(amount) FROM transactions WHERE user_id = ?", (user_id,))
                result = cursor.fetchone()
                balance = result[0] if result[0] is not None else 0
            except Exception as e:
                self.logger.error(f"Failed to get user balance: {e}")

        return {"user_id": user_id, "balance": balance, "last_updated": time.time()}

    async def earn_points(self, user_id: Optional[str], amount: int, transaction_type: Union[TransactionType, str] = TransactionType.EARN_SEEDING, description: str = "") -> Dict[str, Any]:
        """
        赚取积分

        :param user_id: 用户ID，如果为None则使用当前用户
        :param amount: 积分数量（必须为正数）
        :param transaction_type: 交易类型
        :param description: 交易描述
        :return: 包含交易结果的字典
        """
        if user_id is None:
            user_id = self._get_current_user_id()
        if amount <= 0:
             return {"success": False, "error": "Amount must be positive"}
        return await self._create_transaction(user_id, amount, transaction_type, description)

    async def spend_points(self, user_id: Optional[str], amount: int, transaction_type: Union[TransactionType, str] = TransactionType.SPEND_DOWNLOAD, description: str = "") -> Dict[str, Any]:
        """
        消费积分

        :param user_id: 用户ID，如果为None则使用当前用户
        :param amount: 积分数量（必须为正数）
        :param transaction_type: 交易类型
        :param description: 交易描述
        :return: 包含交易结果的字典
        """
        if user_id is None:
            user_id = self._get_current_user_id()
        if amount <= 0:
             return {"success": False, "error": "Amount must be positive"}

        # 简单检查余额
        balance_data = await self.get_user_balance(user_id)
        if balance_data["balance"] < amount:
            return {"success": False, "error": "Insufficient points"}

        return await self._create_transaction(user_id, -amount, transaction_type, description)

    async def _create_transaction(self, user_id: str, amount: int, transaction_type: Union[TransactionType, str], description: str) -> Dict[str, Any]:
        """创建交易记录"""
        timestamp = time.time()
        tx_id = hashlib.sha256(f"{user_id}:{amount}:{timestamp}".encode()).hexdigest()

        transaction = {
            "global_tx_id": tx_id,
            "user_id": user_id,
            "amount": amount,
            "type": str(transaction_type),
            "timestamp": timestamp,
            "description": description,
            "verified": True # 简化验证
        }

        new_balance = 0
        if self.db_module and self.db_module.store and self.db_module.store.connection:
            try:
                cursor = self.db_module.store.connection.cursor()
                cursor.execute("""
                    INSERT INTO transactions (global_tx_id, user_id, amount, type, timestamp, description)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    transaction["global_tx_id"],
                    transaction["user_id"],
                    transaction["amount"],
                    transaction["type"],
                    transaction["timestamp"],
                    transaction.get("description", "")
                ))
                self.db_module.store.connection.commit()

                # Get new balance
                cursor.execute("SELECT SUM(amount) FROM transactions WHERE user_id = ?", (user_id,))
                result = cursor.fetchone()
                new_balance = result[0] if result[0] is not None else 0

            except Exception as e:
                self.logger.error(f"Failed to persist transaction: {e}")
        else:
            self.logger.warning("Database module not available, transaction not persisted")

        self.logger.info(f"Transaction created: {tx_id} for user {user_id}, amount {amount}")
        return {"success": True, "new_balance": new_balance, "transaction": transaction}


class PointsCoreModule(IModule):
    """积分核心模块，负责管理整个生态系统中用户积分的生命周期"""

    def __init__(self, config: dict = None):
        """初始化模块，接收配置参数"""
        self.config = config or {}
        self.initialized = False
        self.service: Optional[PointsService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        """返回模块名称"""
        return "points-core-module"

    @property
    def dependencies(self) -> List[str]:
        """返回依赖模块列表"""
        return ["database-module"] # 明确依赖数据库模块

    async def initialize(self, session: 'Session') -> None:
        """
        初始化模块

        初始化过程包括：
        1. 获取 Session 实例
        2. 启动积分服务
        3. 初始化数据库表结构（如果使用了 DatabaseModule）

        :param session: 全局会话对象
        :raises Exception: 如果初始化失败则抛出异常
        """
        try:
            self.session = session
            self.service = PointsService(self.session, self.config)
            await self.service.start()

            # 初始化数据库表
            if self.session:
                db_module = self.session.get_module("database-module")
                if db_module and db_module.store and db_module.store.connection:
                    try:
                        cursor = db_module.store.connection.cursor()
                        # 创建transactions表
                        cursor.execute("""
                            CREATE TABLE IF NOT EXISTS transactions (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                global_tx_id TEXT UNIQUE NOT NULL,
                                user_id TEXT NOT NULL,
                                amount INTEGER NOT NULL,
                                type TEXT NOT NULL,
                                timestamp REAL NOT NULL,
                                description TEXT
                            )
                        """)
                        # 创建索引
                        cursor.execute("CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions (user_id)")
                        db_module.store.connection.commit()
                        logger.info("PointsCoreModule: Transactions table initialized")
                    except Exception as e:
                        logger.error(f"PointsCoreModule: Failed to initialize database tables: {e}")
                        # 可以在这里决定是否因为DB初始化失败而终止模块初始化，
                        # 或者允许模块以降级模式运行（无持久化）

            self.initialized = True

            logger.info("PointsCoreModule initialized.")
        except Exception as e:
            logger.error(f"Failed to initialize PointsCoreModule: {e}")
            raise

    async def shutdown(self) -> None:
        """关闭模块"""
        try:
            if self.service:
                await self.service.stop()
            self.initialized = False
            # 释放资源
            self.service = None
            self.session = None

            logger.info("PointsCoreModule shutdown completed.")
        except Exception as e:
            logger.error(f"Error during PointsCoreModule shutdown: {e}")
            self.initialized = False

    def get_endpoints(self) -> List[RESTEndpoint]:
        """返回API端点"""
        return []

    def get_health_status(self) -> dict:
        """返回模块健康状态"""
        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "service_available": self.service is not None
            }
        }
