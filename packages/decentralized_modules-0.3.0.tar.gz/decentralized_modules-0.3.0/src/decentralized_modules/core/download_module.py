"""
Download Module
P2P 下载管理模块，负责管理所有下载任务
"""

import asyncio
import logging
from typing import List, Dict, Optional, Any, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from abc import ABC, abstractmethod

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session


class DownloadState(Enum):
    """下载状态枚举"""
    QUEUED = "queued"
    DOWNLOADING = "downloading"
    SEEDING = "seeding"
    COMPLETED = "completed"
    PAUSED = "paused"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class DownloadInfo:
    """下载信息"""
    download_id: str
    infohash: str
    name: str
    size: int
    download_path: str
    state: DownloadState
    progress: float  # 0.0 到 1.0
    download_rate: int  # 字节/秒
    upload_rate: int  # 字节/秒
    eta: int  # 预计剩余时间（秒）
    num_seeders: int
    num_leechers: int
    pieces_total: int
    pieces_completed: int


@dataclass
class DownloadConfig:
    """下载配置"""
    save_path: str = "./downloads"
    max_upload_rate: int = 0  # 0 表示无限制
    max_download_rate: int = 0  # 0 表示无限制
    max_connections: int = 50
    prioritize_first_last_piece: bool = True
    sequential_download: bool = False


class IDownloadEngine(ABC):
    """下载引擎抽象接口"""
    
    @abstractmethod
    async def add_download(self, torrent_data: bytes, config: DownloadConfig) -> Optional[str]:
        """Add a download"""
        pass
    
    @abstractmethod
    async def remove_download(self, download_id: str) -> bool:
        """Remove a download"""
        pass
    
    @abstractmethod
    async def get_download_info(self, download_id: str) -> Optional[DownloadInfo]:
        """Get information about a download"""
        pass
    
    @abstractmethod
    async def get_all_downloads(self) -> List[DownloadInfo]:
        """Get information about all downloads"""
        pass
    
    @abstractmethod
    async def start_download(self, download_id: str) -> bool:
        """Start a download"""
        pass
    
    @abstractmethod
    async def stop_download(self, download_id: str) -> bool:
        """Stop a download"""
        pass
    
    @abstractmethod
    async def pause_download(self, download_id: str) -> bool:
        """Pause a download"""
        pass
    
    @abstractmethod
    async def resume_download(self, download_id: str) -> bool:
        """Resume a paused download"""
        pass


class DefaultDownloadEngine(IDownloadEngine):
    """
    默认下载引擎实现

    模拟下载管理，生成唯一的 download_id。
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._downloads: Dict[str, DownloadInfo] = {}
        self._next_download_id = 1
        self._initialized = False
    
    async def initialize(self):
        """初始化下载引擎"""
        self.logger.info("初始化下载引擎...")
        
        # 确保存储目录存在
        download_dir = Path("./downloads")
        download_dir.mkdir(parents=True, exist_ok=True)
        
        self._initialized = True
    
    async def shutdown(self):
        """关闭下载引擎"""
        self.logger.info("关闭下载引擎...")
        self._initialized = False
    
    async def add_download(self, torrent_data: bytes, config: DownloadConfig) -> Optional[str]:
        """添加下载"""
        if not self._initialized:
            return None
        
        import hashlib
        infohash = hashlib.sha1(torrent_data).hexdigest()[:8]

        self.logger.info(f"添加下载 (Mock): {infohash}")
        
        # 生成下载ID
        download_id = f"download_{self._next_download_id}"
        self._next_download_id += 1
        
        # 创建下载信息
        download_info = DownloadInfo(
            download_id=download_id,
            infohash=infohash,
            name=f"Mock Download {infohash}",
            size=1024 * 1024 * 100,  # 100MB
            download_path=config.save_path,
            state=DownloadState.QUEUED,
            progress=0.0,
            download_rate=0,
            upload_rate=0,
            eta=3600,
            num_seeders=0,
            num_leechers=0,
            pieces_total=100,
            pieces_completed=0
        )
        
        # 存储下载
        self._downloads[download_id] = download_info
        return download_id
    
    async def remove_download(self, download_id: str) -> bool:
        """Remove a download"""
        if download_id not in self._downloads:
            return False
        
        self.logger.info(f"Removing download {download_id}")
        del self._downloads[download_id]
        return True
    
    async def get_download_info(self, download_id: str) -> Optional[DownloadInfo]:
        """Get information about a download"""
        return self._downloads.get(download_id)
    
    async def get_all_downloads(self) -> List[DownloadInfo]:
        """Get information about all downloads"""
        return list(self._downloads.values())
    
    async def start_download(self, download_id: str) -> bool:
        """Start a download"""
        if download_id not in self._downloads:
            return False
        
        download_info = self._downloads[download_id]
        download_info.state = DownloadState.DOWNLOADING
        self.logger.info(f"Started download {download_id}")
        return True
    
    async def stop_download(self, download_id: str) -> bool:
        """Stop a download"""
        if download_id not in self._downloads:
            return False
        
        download_info = self._downloads[download_id]
        download_info.state = DownloadState.STOPPED
        self.logger.info(f"Stopped download {download_id}")
        return True
    
    async def pause_download(self, download_id: str) -> bool:
        """Pause a download"""
        if download_id not in self._downloads:
            return False
        
        download_info = self._downloads[download_id]
        if download_info.state == DownloadState.DOWNLOADING:
            download_info.state = DownloadState.PAUSED
            self.logger.info(f"Paused download {download_id}")
            return True
        return False
    
    async def resume_download(self, download_id: str) -> bool:
        """Resume a paused download"""
        if download_id not in self._downloads:
            return False
        
        download_info = self._downloads[download_id]
        if download_info.state == DownloadState.PAUSED:
            download_info.state = DownloadState.DOWNLOADING
            self.logger.info(f"Resumed download {download_id}")
            return True
        return False


class DownloadModule(IModule):
    """
    DownloadModule - 负责处理P2P下载管理功能

    该模块管理所有的下载任务，包括：
    - 添加新的下载任务
    - 暂停/恢复/停止下载
    - 监控下载进度和速度
    - 管理下载文件的存储位置

    使用示例：

    ```python
    download_module = session.get_module("download-module")

    # 添加下载
    with open("video.torrent", "rb") as f:
        data = f.read()
    dl_id = await download_module.add_download(data)
    print(f"Added download: {dl_id}")

    # 开始下载
    await download_module.start_download(dl_id)

    # 查询进度
    info = await download_module.get_download_info(dl_id)
    print(f"Progress: {info.progress * 100}%")
    ```
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._name = "download-module"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = None
        self.initialized = False
        self.download_engine = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        """返回依赖模块列表"""
        return ["points-core-module", "tunnel-module"]

    async def initialize(self, session: 'Session') -> None:
        """初始化下载模块"""
        try:
            self.logger.info("Initializing Download Module...")
            self.session = session
            
            # 初始化下载引擎
            self.download_engine = DefaultDownloadEngine()
            await self.download_engine.initialize()
            
            # 将下载引擎注册到会话上下文，供其他模块使用
            session.context.register_service("download_engine", self.download_engine)
            
            self.initialized = True
            self.logger.info("Download Module initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize Download Module: {e}")
            raise

    async def shutdown(self) -> None:
        """关闭下载模块"""
        try:
            self.logger.info("Shutting down Download Module...")
            if self.download_engine:
                await self.download_engine.shutdown()
            self.initialized = False
            self.logger.info("Download Module shutdown completed")
        except Exception as e:
            self.logger.error(f"Error during Download Module shutdown: {e}")

    async def add_download(self, torrent_data: bytes, config: DownloadConfig = None) -> Optional[str]:
        """
        添加下载
        
        :param torrent_data: 种子文件数据
        :param config: 下载配置
        :return: 下载ID，如果失败则返回None
        """
        if not self.initialized or not self.download_engine:
            self.logger.warning("DownloadModule not initialized")
            return None
        
        config = config or DownloadConfig()
        return await self.download_engine.add_download(torrent_data, config)

    async def remove_download(self, download_id: str) -> bool:
        """
        移除下载
        
        :param download_id: 下载ID
        :return: 是否成功
        """
        if not self.initialized or not self.download_engine:
            return False
        
        return await self.download_engine.remove_download(download_id)

    async def get_download_info(self, download_id: str) -> Optional[DownloadInfo]:
        """
        获取下载信息
        
        :param download_id: 下载ID
        :return: 下载信息
        """
        if not self.initialized or not self.download_engine:
            return None
        
        return await self.download_engine.get_download_info(download_id)

    async def get_all_downloads(self) -> List[DownloadInfo]:
        """
        获取所有下载信息
        
        :return: 下载信息列表
        """
        if not self.initialized or not self.download_engine:
            return []
        
        return await self.download_engine.get_all_downloads()

    async def start_download(self, download_id: str) -> bool:
        """
        开始下载
        
        :param download_id: 下载ID
        :return: 是否成功
        """
        if not self.initialized or not self.download_engine:
            return False
        
        return await self.download_engine.start_download(download_id)

    async def stop_download(self, download_id: str) -> bool:
        """
        停止下载
        
        :param download_id: 下载ID
        :return: 是否成功
        """
        if not self.initialized or not self.download_engine:
            return False
        
        return await self.download_engine.stop_download(download_id)

    async def pause_download(self, download_id: str) -> bool:
        """
        暂停下载
        
        :param download_id: 下载ID
        :return: 是否成功
        """
        if not self.initialized or not self.download_engine:
            return False
        
        return await self.download_engine.pause_download(download_id)

    async def resume_download(self, download_id: str) -> bool:
        """
        恢复下载
        
        :param download_id: 下载ID
        :return: 是否成功
        """
        if not self.initialized or not self.download_engine:
            return False
        
        return await self.download_engine.resume_download(download_id)

    def get_services(self) -> Dict[str, Any]:
        """
        获取模块提供的服务
        
        :return: 服务字典
        """
        return {
            "download_engine": self.download_engine
        }

    def get_endpoints(self) -> List[RESTEndpoint]:
        """返回API端点"""
        return [
            RESTEndpoint("/api/downloads/add", self.handle_add_download),
            RESTEndpoint("/api/downloads/remove", self.handle_remove_download),
            RESTEndpoint("/api/downloads/list", self.handle_list_downloads),
            RESTEndpoint("/api/downloads/start", self.handle_start_download),
            RESTEndpoint("/api/downloads/stop", self.handle_stop_download),
            RESTEndpoint("/api/downloads/pause", self.handle_pause_download),
            RESTEndpoint("/api/downloads/resume", self.handle_resume_download),
            RESTEndpoint("/api/downloads/info", self.handle_download_info),
        ]

    async def handle_add_download(self, request: Any) -> Dict[str, Any]:
        """处理添加下载请求"""
        try:
            torrent_data = request.get("torrent_data")
            if not torrent_data:
                return {"error": "Missing torrent_data"}
            
            config_dict = request.get("config", {})
            config = DownloadConfig(**config_dict)
            
            download_id = await self.add_download(torrent_data, config)
            if download_id:
                return {"success": True, "download_id": download_id}
            else:
                return {"success": False, "error": "Failed to add download"}
        except Exception as e:
            self.logger.error(f"Error handling add download request: {e}")
            return {"error": str(e), "success": False}

    async def handle_remove_download(self, request: Any) -> Dict[str, Any]:
        """处理移除下载请求"""
        try:
            download_id = request.get("download_id")
            if not download_id:
                return {"error": "Missing download_id"}
            
            success = await self.remove_download(download_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling remove download request: {e}")
            return {"error": str(e), "success": False}

    async def handle_list_downloads(self, request: Any) -> Dict[str, Any]:
        """处理列出下载请求"""
        try:
            downloads = await self.get_all_downloads()
            return {
                "downloads": [d.__dict__ for d in downloads],
                "count": len(downloads)
            }
        except Exception as e:
            self.logger.error(f"Error handling list downloads request: {e}")
            return {"error": str(e), "downloads": []}

    async def handle_start_download(self, request: Any) -> Dict[str, Any]:
        """处理开始下载请求"""
        try:
            download_id = request.get("download_id")
            if not download_id:
                return {"error": "Missing download_id"}
            
            success = await self.start_download(download_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling start download request: {e}")
            return {"error": str(e), "success": False}

    async def handle_stop_download(self, request: Any) -> Dict[str, Any]:
        """处理停止下载请求"""
        try:
            download_id = request.get("download_id")
            if not download_id:
                return {"error": "Missing download_id"}
            
            success = await self.stop_download(download_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling stop download request: {e}")
            return {"error": str(e), "success": False}

    async def handle_pause_download(self, request: Any) -> Dict[str, Any]:
        """处理暂停下载请求"""
        try:
            download_id = request.get("download_id")
            if not download_id:
                return {"error": "Missing download_id"}
            
            success = await self.pause_download(download_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling pause download request: {e}")
            return {"error": str(e), "success": False}

    async def handle_resume_download(self, request: Any) -> Dict[str, Any]:
        """处理恢复下载请求"""
        try:
            download_id = request.get("download_id")
            if not download_id:
                return {"error": "Missing download_id"}
            
            success = await self.resume_download(download_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling resume download request: {e}")
            return {"error": str(e), "success": False}

    async def handle_download_info(self, request: Any) -> Dict[str, Any]:
        """处理下载信息请求"""
        try:
            download_id = request.get("download_id")
            if not download_id:
                return {"error": "Missing download_id"}
            
            download_info = await self.get_download_info(download_id)
            if download_info:
                return {"info": download_info.__dict__}
            else:
                return {"error": "Download not found"}
        except Exception as e:
            self.logger.error(f"Error handling download info request: {e}")
            return {"error": str(e)}

    def get_health_status(self) -> dict:
        """返回模块健康状态"""
        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "download_engine_available": self.download_engine is not None,
                "active_downloads": len([d for d in self.download_engine._downloads.values() if d.state in [DownloadState.DOWNLOADING, DownloadState.SEEDING]]) if self.download_engine else 0
            }
        }