"""
Bootstrap Module
网络引导模块，负责节点发现和网络拓扑构建
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any, TYPE_CHECKING
from dataclasses import dataclass
from enum import Enum
from abc import ABC, abstractmethod

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session
    from .torrent_module import LibTorrentEngine


class BootstrapState(Enum):
    """引导状态枚举"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    BOOTSTRAPPING = "bootstrapping"
    READY = "ready"
    ERROR = "error"


@dataclass
class BootstrapNode:
    """引导节点信息"""
    node_id: str
    host: str
    port: int
    public_key: str
    last_seen: datetime
    trust_level: float  # 0.0 到 1.0
    is_bootstrap: bool


@dataclass
class BootstrapConfig:
    """引导配置"""
    bootstrap_nodes: List[str] = None
    max_bootstrap_attempts: int = 5
    bootstrap_timeout: int = 30  # 秒
    enable_dht_bootstrap: bool = True
    min_peers: int = 10
    max_peers: int = 50


class IBootstrapEngine(ABC):
    """引导引擎抽象接口"""
    
    @abstractmethod
    async def add_bootstrap_node(self, host: str, port: int, public_key: str) -> bool:
        """添加引导节点"""
        pass
    
    @abstractmethod
    async def remove_bootstrap_node(self, node_id: str) -> bool:
        """移除引导节点"""
        pass
    
    @abstractmethod
    async def get_bootstrap_nodes(self) -> List[BootstrapNode]:
        """获取所有引导节点"""
        pass
    
    @abstractmethod
    async def bootstrap(self) -> bool:
        """开始引导过程"""
        pass
    
    @abstractmethod
    async def get_network_stats(self) -> Dict[str, Any]:
        """获取网络统计"""
        pass


class DefaultBootstrapEngine(IBootstrapEngine):
    """
    默认引导引擎实现 (Mock)

    模拟引导过程。
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._nodes: Dict[str, BootstrapNode] = {}
        self._config = BootstrapConfig()
        self._state = BootstrapState.DISCONNECTED
        self._initialized = False
    
    async def initialize(self, config: BootstrapConfig = None):
        """初始化引导引擎"""
        if config:
            self._config = config
        
        self.logger.info("初始化引导引擎 (Mock)...")
        self._initialized = True
        
        # 添加配置的引导节点
        if self._config.bootstrap_nodes:
            for node_str in self._config.bootstrap_nodes:
                try:
                    host, port = node_str.split(':')
                    port = int(port)
                    public_key = f"mock_key_{host}_{port}"
                    await self.add_bootstrap_node(host, port, public_key)
                except ValueError:
                    self.logger.warning(f"无效的引导节点格式: {node_str}")
    
    async def shutdown(self):
        """关闭引导引擎"""
        self.logger.info("关闭引导引擎 (Mock)...")
        self._state = BootstrapState.DISCONNECTED
        self._initialized = False
    
    async def add_bootstrap_node(self, host: str, port: int, public_key: str) -> bool:
        """添加引导节点"""
        if not self._initialized:
            return False
        
        node_id = f"node_{host}_{port}"
        bootstrap_node = BootstrapNode(
            node_id=node_id,
            host=host,
            port=port,
            public_key=public_key,
            last_seen=datetime.now(),
            trust_level=0.5,
            is_bootstrap=True
        )
        
        self._nodes[node_id] = bootstrap_node
        self.logger.info(f"添加引导节点: {node_id}")
        return True
    
    async def remove_bootstrap_node(self, node_id: str) -> bool:
        """移除引导节点"""
        if node_id in self._nodes:
            del self._nodes[node_id]
            self.logger.info(f"移除引导节点: {node_id}")
            return True
        return False
    
    async def get_bootstrap_nodes(self) -> List[BootstrapNode]:
        """获取所有引导节点"""
        return list(self._nodes.values())
    
    async def bootstrap(self) -> bool:
        """开始引导过程"""
        if not self._initialized:
            return False
        
        self.logger.info("开始引导过程...")
        self._state = BootstrapState.BOOTSTRAPPING
        
        try:
            await asyncio.sleep(0.1)

            if not self._nodes:
                self.logger.warning("无可用引导节点")
            
            for node in self._nodes.values():
                try:
                    await asyncio.sleep(0.1)
                    self.logger.info(f"已连接到引导节点: {node.node_id}")
                    self._state = BootstrapState.CONNECTED
                    break
                except Exception as e:
                    self.logger.error(f"连接失败 {node.node_id}: {e}")
            
            if self._state == BootstrapState.CONNECTED or not self._nodes:
                 if not self._nodes:
                     self.logger.warning("无节点可连接，但引导过程结束")
                 else:
                     self._state = BootstrapState.READY
                 self.logger.info("引导完成")
                 return True

            return False
                
        except Exception as e:
            self.logger.error(f"引导失败: {e}")
            self._state = BootstrapState.ERROR
            return False
    
    async def get_network_stats(self) -> Dict[str, Any]:
        """获取网络统计"""
        return {
            "state": self._state.value,
            "bootstrap_nodes": len(self._nodes),
            "connected_nodes": len([n for n in self._nodes.values() if n.last_seen > (datetime.now() - timedelta(minutes=5))]),
            "last_updated": datetime.now().isoformat()
        }


class LibTorrentBootstrapEngine(DefaultBootstrapEngine):
    """
    基于 LibTorrent 的引导引擎

    该引擎利用 LibTorrent 的 DHT 功能进行节点发现。
    它依赖于 TorrentModule 中的 LibTorrentEngine 实例。
    """

    def __init__(self, session: 'Session'):
        super().__init__()
        self.session = session
        self.lt_engine = None

    async def initialize(self, config: BootstrapConfig = None):
        """初始化"""
        await super().initialize(config)

        # 尝试获取 LibTorrentEngine 实例
        torrent_module = self.session.get_module("torrent-module")
        if torrent_module and torrent_module.initialized:
            # 需要检查 engine 类型，这里使用简单的属性检查
            # 注意：这里我们假设 TorrentModule 暴露了 engine 且我们能访问它
            engine = torrent_module.torrent_engine
            # 简单的鸭子类型检查
            if hasattr(engine, "lt_session") and engine.lt_session:
                self.lt_engine = engine
                self.logger.info("已连接到 LibTorrent 引擎，将使用 DHT 进行引导")
            else:
                self.logger.warning("TorrentModule 未使用 LibTorrentEngine，回退到 Mock 引导模式")
        else:
            self.logger.warning("TorrentModule 不可用，回退到 Mock 引导模式")

    async def add_bootstrap_node(self, host: str, port: int, public_key: str) -> bool:
        """添加引导节点到 DHT"""
        # 首先添加到内部列表
        await super().add_bootstrap_node(host, port, public_key)

        # 如果启用了 DHT，则添加到 libtorrent 会话
        if self.lt_engine and self.lt_engine.lt_session:
            try:
                self.lt_engine.lt_session.add_dht_router(host, port)
                self.logger.info(f"添加 DHT 路由节点: {host}:{port}")
                return True
            except Exception as e:
                self.logger.error(f"添加 DHT 路由失败: {e}")
                return False
        return True

    async def bootstrap(self) -> bool:
        """执行引导"""
        # 1. 执行 Mock 引导流程以更新内部状态
        await super().bootstrap()

        # 2. 检查 libtorrent 状态
        if self.lt_engine and self.lt_engine.lt_session:
            # 检查 DHT 状态
            is_dht_running = self.lt_engine.lt_session.is_dht_running()
            if not is_dht_running:
                 self.logger.info("启动 DHT...")
                 # 在 libtorrent 初始化时通常已配置 dht，这里确保启动
                 # 注意：具体启动方法取决于 lt 版本和配置，这里假设已通过 settings 启动
                 pass

            # 可以在这里添加等待 DHT 节点数增加的逻辑
            return True

        return self._state in [BootstrapState.CONNECTED, BootstrapState.READY]


class BootstrapModule(IModule):
    """
    BootstrapModule - 负责网络引导和节点发现功能
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._name = "bootstrap-module"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = None
        self.initialized = False
        self.bootstrap_engine = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        # 强依赖 torrent-module 以获取底层 P2P 引擎
        return ["network-module", "event-notification-module", "torrent-module"]

    async def initialize(self, session: 'Session') -> None:
        """初始化引导模块"""
        try:
            self.logger.info("Initializing Bootstrap Module...")
            self.session = session
            
            # 决定使用哪个引擎
            # 默认尝试使用增强版引擎，它会自动检测环境
            self.bootstrap_engine = LibTorrentBootstrapEngine(session)
            
            bootstrap_config = BootstrapConfig(
                bootstrap_nodes=self.config.get("bootstrap_nodes", []),
                max_bootstrap_attempts=self.config.get("max_bootstrap_attempts", 5),
                bootstrap_timeout=self.config.get("bootstrap_timeout", 30),
                enable_dht_bootstrap=self.config.get("enable_dht_bootstrap", True),
                min_peers=self.config.get("min_peers", 10),
                max_peers=self.config.get("max_peers", 50)
            )
            
            await self.bootstrap_engine.initialize(bootstrap_config)
            
            session.context.register_service("bootstrap_engine", self.bootstrap_engine)
            
            self.initialized = True
            self.logger.info("Bootstrap Module initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize Bootstrap Module: {e}")
            raise

    async def shutdown(self) -> None:
        """关闭引导模块"""
        try:
            self.logger.info("Shutting down Bootstrap Module...")
            if self.bootstrap_engine:
                await self.bootstrap_engine.shutdown()
            self.initialized = False
            self.logger.info("Bootstrap Module shutdown completed")
        except Exception as e:
            self.logger.error(f"Error during Bootstrap Module shutdown: {e}")

    # ... [Proxy methods] ...

    async def add_bootstrap_node(self, host: str, port: int, public_key: str) -> bool:
        if not self.initialized or not self.bootstrap_engine:
            self.logger.warning("BootstrapModule not initialized")
            return False
        return await self.bootstrap_engine.add_bootstrap_node(host, port, public_key)

    async def remove_bootstrap_node(self, node_id: str) -> bool:
        if not self.initialized or not self.bootstrap_engine: return False
        return await self.bootstrap_engine.remove_bootstrap_node(node_id)

    async def get_bootstrap_nodes(self) -> List[BootstrapNode]:
        if not self.initialized or not self.bootstrap_engine: return []
        return await self.bootstrap_engine.get_bootstrap_nodes()

    async def bootstrap(self) -> bool:
        if not self.initialized or not self.bootstrap_engine:
            self.logger.warning("BootstrapModule not initialized")
            return False
        return await self.bootstrap_engine.bootstrap()

    async def get_network_stats(self) -> Dict[str, Any]:
        if not self.initialized or not self.bootstrap_engine: return {}
        return await self.bootstrap_engine.get_network_stats()

    def get_services(self) -> Dict[str, Any]:
        return {"bootstrap_engine": self.bootstrap_engine}

    def get_endpoints(self) -> List[RESTEndpoint]:
        return [
            RESTEndpoint("/api/bootstrap/status", self.handle_status),
            RESTEndpoint("/api/bootstrap/nodes", self.handle_nodes),
            RESTEndpoint("/api/bootstrap/add_node", self.handle_add_node),
            RESTEndpoint("/api/bootstrap/remove_node", self.handle_remove_node),
            RESTEndpoint("/api/bootstrap/start", self.handle_start_bootstrap),
            RESTEndpoint("/api/bootstrap/stats", self.handle_network_stats),
        ]

    # ... [Handler methods - Identical to previous version] ...
    async def handle_status(self, request: Any) -> Dict[str, Any]:
        try:
            stats = await self.get_network_stats()
            return {"status": stats}
        except Exception as e:
            self.logger.error(f"Error handling status request: {e}")
            return {"error": str(e), "status": {}}

    async def handle_nodes(self, request: Any) -> Dict[str, Any]:
        try:
            nodes = await self.get_bootstrap_nodes()
            return {"nodes": [n.__dict__ for n in nodes], "count": len(nodes)}
        except Exception as e:
            self.logger.error(f"Error handling nodes request: {e}")
            return {"error": str(e), "nodes": []}

    async def handle_add_node(self, request: Any) -> Dict[str, Any]:
        try:
            host = request.get("host")
            port = request.get("port")
            public_key = request.get("public_key")
            if not all([host, port, public_key]): return {"error": "Missing required parameters"}
            success = await self.add_bootstrap_node(host, port, public_key)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling add node request: {e}")
            return {"error": str(e), "success": False}

    async def handle_remove_node(self, request: Any) -> Dict[str, Any]:
        try:
            node_id = request.get("node_id")
            if not node_id: return {"error": "Missing node_id"}
            success = await self.remove_bootstrap_node(node_id)
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling remove node request: {e}")
            return {"error": str(e), "success": False}

    async def handle_start_bootstrap(self, request: Any) -> Dict[str, Any]:
        try:
            success = await self.bootstrap()
            return {"success": success}
        except Exception as e:
            self.logger.error(f"Error handling start bootstrap request: {e}")
            return {"error": str(e), "success": False}

    async def handle_network_stats(self, request: Any) -> Dict[str, Any]:
        try:
            stats = await self.get_network_stats()
            return {"stats": stats}
        except Exception as e:
            self.logger.error(f"Error handling network stats request: {e}")
            return {"error": str(e), "stats": {}}

    def get_health_status(self) -> dict:
        is_dht = False
        if isinstance(self.bootstrap_engine, LibTorrentBootstrapEngine):
            is_dht = self.bootstrap_engine.lt_engine is not None

        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "engine_type": "libtorrent-dht" if is_dht else "mock",
                "bootstrap_engine_available": self.bootstrap_engine is not None,
                "bootstrap_state": self.bootstrap_engine._state.value if self.bootstrap_engine else "unknown",
                "bootstrap_nodes": len(self.bootstrap_engine._nodes) if self.bootstrap_engine else 0
            }
        }
