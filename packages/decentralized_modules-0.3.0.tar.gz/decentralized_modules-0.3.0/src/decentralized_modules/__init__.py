# decentralized-modules/src/__init__.py
"""
Decentralized Modules - A modular, reusable core functionality library for decentralized network applications
"""

__version__ = "0.3.0"
__author__ = "Decentralized Modules Team"

# 导入核心模块
from .core.points_core_module import PointsCoreModule
from .core.event_notification_module import EventNotificationModule
from .core.ipv8_storage_module import IPv8StorageModule
from .core.torrent_module import TorrentModule
from .core.tunnel_module import TunnelModule
from .core.download_module import DownloadModule
from .core.bootstrap_module import BootstrapModule

# 导入基础模块
from .foundation.cache_management_module import CacheManagementModule
from .foundation.configuration_module import ConfigurationModule
from .foundation.crypto_service_module import CryptoServiceModule
from .foundation.data_validation_module import DataValidationModule
from .foundation.database_module import DatabaseModule
from .foundation.fault_tolerance_module import FaultToleranceModule
from .foundation.health_monitor_module import HealthMonitorModule
from .foundation.logging_monitoring_module import LoggingMonitoringModule
from .foundation.network_communication_module import NetworkCommunicationModule
from .foundation.network_module import NetworkModule
from .foundation.resource_manager_module import ResourceManagerModule
from .foundation.security_module import SecurityModule
from .foundation.state_management_module import StateManagementModule
from .foundation.task_queue_module import TaskQueueModule
from .foundation.trust_chain_module import TrustChainModule
from .foundation.api_server_module import ApiServerModule

# 导入扩展模块
# ContentDiscoveryModule 和 SearchModule 已迁移到 decentralized-extensions
# from .extensions.content_discovery_module import ContentDiscoveryModule
# from .extensions.search_module import SearchModule

# 导入扩展模块
from .extensions.content_discovery_module import ContentDiscoveryModule

__all__ = [
    # Core Modules
    'PointsCoreModule',
    'EventNotificationModule',
    'IPv8StorageModule',
    'TorrentModule',
    'TunnelModule',
    'DownloadModule',
    'BootstrapModule',

    # Foundation Modules
    'CacheManagementModule',
    'ConfigurationModule',
    'CryptoServiceModule',
    'DataValidationModule',
    'DatabaseModule',
    'FaultToleranceModule',
    'HealthMonitorModule',
    'LoggingMonitoringModule',
    'NetworkCommunicationModule',
    'NetworkModule',
    'ResourceManagerModule',
    'SecurityModule',
    'StateManagementModule',
    'TaskQueueModule',
    'TrustChainModule',
    'ApiServerModule',

    # Extensions
    # ContentDiscoveryModule 和 SearchModule 已迁移到 decentralized-extensions
    # 'ContentDiscoveryModule',
    # 'SearchModule',
]
