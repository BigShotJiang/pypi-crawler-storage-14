"""
State Management Module
状态管理模块，负责应用程序状态的持久化和恢复
"""

import json
import logging
import os
from typing import TYPE_CHECKING, Dict, Any, Optional, List
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session


class StateManager:
    """
    状态管理器 (StateManager)

    负责管理应用程序的运行时状态，支持状态的保存和加载。
    这对于应用程序重启后恢复上下文非常有用。

    主要功能：
    - 保存状态到文件
    - 加载状态
    - 获取/更新状态

    使用示例：

    ```python
    state_manager = session.get_module("state-management-module").service

    # 更新状态
    state_manager.update_state("last_user", "user123")
    state_manager.update_state("window_position", {"x": 100, "y": 100})

    # 保存状态
    await state_manager.save_state()

    # 获取状态
    user = state_manager.get_state("last_user")
    ```
    """

    def __init__(self, session: 'Session', state_file: str = "app_state.json"):
        self.session = session
        self.state_file = state_file
        self.logger = logging.getLogger(self.__class__.__name__)
        self._state: Dict[str, Any] = {}

    async def load_state(self) -> bool:
        """加载状态"""
        if not os.path.exists(self.state_file):
            return False

        try:
            import asyncio
            await asyncio.sleep(0) # 模拟异步

            with open(self.state_file, 'r', encoding='utf-8') as f:
                self._state = json.load(f)
            self.logger.info("状态加载成功")
            return True
        except Exception as e:
            self.logger.error(f"加载状态失败: {e}")
            return False

    async def save_state(self) -> bool:
        """保存状态"""
        try:
            import asyncio
            await asyncio.sleep(0) # 模拟异步

            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(self._state, f, indent=4)
            self.logger.info("状态保存成功")
            return True
        except Exception as e:
            self.logger.error(f"保存状态失败: {e}")
            return False

    def get_state(self, key: str, default: Any = None) -> Any:
        """获取状态值"""
        return self._state.get(key, default)

    def update_state(self, key: str, value: Any) -> None:
        """更新状态值"""
        self._state[key] = value


class StateManagementModule(IModule):
    """
    状态管理模块 (StateManagementModule)

    基础模块之一，用于应用状态持久化。

    使用示例：

    ```python
    module = session.get_module("state-management-module")
    module.service.update_state("is_running", True)
    ```
    """

    def __init__(self, state_file: str = "app_state.json"):
        super().__init__()
        self._name = "state-management-module"
        self.state_file = state_file
        self.service: Optional[StateManager] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化状态管理模块"""
        self.session = session
        self.service = StateManager(self.session, self.state_file)
        await self.service.load_state()

        session.context.register_service("state_manager", self.service)

    async def shutdown(self) -> None:
        """关闭状态管理模块"""
        if self.service:
            await self.service.save_state()

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []
