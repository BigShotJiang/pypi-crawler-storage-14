"""
API Server Module
API 服务器模块，负责将所有模块的 RESTEndpoint 暴露为 HTTP 服务
"""

import logging
import asyncio
import json
from typing import List, TYPE_CHECKING, Optional

# 尝试导入 aiohttp
try:
    from aiohttp import web
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session


class ApiServerModule(IModule):
    """
    API Server Module

    使用 aiohttp 启动一个 HTTP 服务器，自动聚合所有已注册模块的 endpoint。
    """

    def __init__(self, port: int = 8080):
        self._name = "api-server-module"
        self.port = port
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = None
        self.app = None
        self.runner = None
        self.site = None
        self.initialized = False

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        # 依赖所有可能提供 endpoint 的模块... 但这会导致循环依赖
        # 所以我们不声明硬依赖，而是利用 Session 获取已加载的模块
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化 API 服务器"""
        self.session = session

        if not HAS_AIOHTTP:
            self.logger.warning("aiohttp not installed, API Server will not start.")
            self.initialized = True
            return

        self.logger.info("Initializing API Server...")
        self.app = web.Application()

        # 注册路由
        self._register_routes()

        # 启动服务器 (在后台任务中，或者作为 initialize 的一部分)
        # 注意：web.AppRunner 需要在 loop 中运行
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        self.site = web.TCPSite(self.runner, '0.0.0.0', self.port)
        await self.site.start()

        self.logger.info(f"API Server running at http://0.0.0.0:{self.port}")
        self.initialized = True

    def _register_routes(self):
        """扫描所有模块并注册路由"""
        modules = self.session.module_manager.get_all_modules()
        count = 0

        for module in modules:
            endpoints = module.get_endpoints()
            for ep in endpoints:
                self._add_endpoint(ep, module.name)
                count += 1

        self.logger.info(f"Registered {count} endpoints from {len(modules)} modules")

    def _add_endpoint(self, endpoint: RESTEndpoint, module_name: str):
        """添加单个 endpoint"""

        async def wrapper(request):
            # 解析请求数据
            data = {}
            if request.can_read_body:
                try:
                    data = await request.json()
                except Exception:
                    data = dict(request.query)
            else:
                data = dict(request.query)

            # 调用处理函数
            try:
                result = await endpoint.handler(data)
                return web.json_response(result)
            except Exception as e:
                self.logger.error(f"Error handling {endpoint.path}: {e}")
                return web.json_response({"error": str(e)}, status=500)

        # 注册支持的方法
        for method in endpoint.methods:
            self.app.router.add_route(method, endpoint.path, wrapper)
            self.logger.debug(f"Added route: {method} {endpoint.path} -> {module_name}")

    async def shutdown(self) -> None:
        """关闭 API 服务器"""
        if self.runner:
            self.logger.info("Stopping API Server...")
            await self.runner.cleanup()
        self.initialized = False

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []

    def get_health_status(self) -> dict:
        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "info": {
                "port": self.port,
                "has_aiohttp": HAS_AIOHTTP,
                "running": self.site is not None
            }
        }
