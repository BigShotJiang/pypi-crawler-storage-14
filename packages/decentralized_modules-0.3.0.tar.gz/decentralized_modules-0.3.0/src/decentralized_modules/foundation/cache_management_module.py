"""
Cache Management Module
缓存管理模块，提供内存缓存功能
"""

import time
import logging
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class CacheService:
    """
    缓存服务 (CacheService)

    提供简单的内存键值缓存，支持过期时间 (TTL)。

    主要功能：
    - 设置缓存 (支持 TTL)
    - 获取缓存
    - 删除缓存
    - 清理过期缓存

    使用示例：

    ```python
    cache = session.get_module("cache-management-module").service

    # 设置缓存，10秒后过期
    cache.set("my_key", "my_value", ttl=10)

    # 获取缓存
    value = cache.get("my_key")
    print(value)
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self._cache: Dict[str, Tuple[Any, float]] = {}

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """
        设置缓存

        :param key: 键
        :param value: 值
        :param ttl: 生存时间(秒)，None表示不过期
        """
        expiry = time.time() + ttl if ttl else float('inf')
        self._cache[key] = (value, expiry)
        self.logger.debug(f"缓存已设置: {key}, TTL: {ttl}")

    def get(self, key: str, default: Any = None) -> Any:
        """
        获取缓存

        :param key: 键
        :param default: 默认值
        :return: 缓存值或默认值
        """
        if key not in self._cache:
            return default

        value, expiry = self._cache[key]
        if time.time() > expiry:
            del self._cache[key]
            return default

        return value

    def delete(self, key: str) -> bool:
        """
        删除缓存

        :param key: 键
        :return: 是否删除成功
        """
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear_expired(self) -> int:
        """
        清理所有过期缓存

        :return: 清理的数量
        """
        now = time.time()
        expired_keys = [k for k, (_, exp) in self._cache.items() if now > exp]
        for k in expired_keys:
            del self._cache[k]
        return len(expired_keys)
class CacheManagementModule(IModule):
    """
    缓存管理模块 (CacheManagementModule)

    基础模块之一，提供通用缓存服务。

    使用示例：

    ```python
    module = session.get_module("cache-management-module")
    module.service.set("config", {"a": 1})
    ```
    """

    def __init__(self):
        super().__init__()
        self._name = "cache-management-module"
        self.service: Optional[CacheService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化缓存管理模块"""
        self.session = session
        self.service = CacheService(self.session)
        # 注册服务
        session.context.register_service("cache", self.service)

    async def shutdown(self) -> None:
        """关闭缓存管理模块"""
        if self.service:
            self.service._cache.clear()

    def get_endpoints(self) -> list:
        return []
