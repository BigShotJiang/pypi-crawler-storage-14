"""
Health Monitor Module
健康监控模块，监控系统资源使用情况
"""

import logging
import time
import os
from typing import TYPE_CHECKING, Dict, Any, Optional
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class HealthService:
    """
    健康服务 (HealthService)

    监控系统基础资源（CPU、内存、磁盘）的使用情况。
    目前使用 `psutil` 库（如果可用）或模拟数据。

    主要功能：
    - 获取系统健康状态
    - 检查关键资源指标

    使用示例：

    ```python
    health = session.get_module("health-monitor-module").service
    status = health.get_status()
    print(f"System Load: {status.get('cpu_load')}%")
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)

    def get_status(self) -> Dict[str, Any]:
        """
        获取系统健康状态

        :return: 包含资源使用情况的字典
        """
        stats = {
            "timestamp": time.time(),
            "status": "healthy"
        }

        # 尝试使用 psutil 获取真实数据
        try:
            import psutil
            stats["cpu_load"] = psutil.cpu_percent(interval=None)
            stats["memory_usage"] = psutil.virtual_memory().percent
            stats["disk_usage"] = psutil.disk_usage('/').percent
        except ImportError:
            self.logger.debug("psutil not found, returning mock health data")
            stats["cpu_load"] = 0.0
            stats["memory_usage"] = 0.0
            stats["disk_usage"] = 0.0
            stats["note"] = "Install 'psutil' for real metrics"

        return stats
class HealthMonitorModule(IModule):
    """
    健康监控模块 (HealthMonitorModule)

    基础模块之一，提供系统健康状态监控。
    """

    def __init__(self):
        super().__init__()
        self._name = "health-monitor-module"
        self.service: Optional[HealthService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化健康监控模块"""
        self.session = session
        self.service = HealthService(self.session)
        session.context.register_service("health_monitor", self.service)

    async def shutdown(self) -> None:
        """关闭模块"""
        pass

    def get_endpoints(self) -> list:
        return []
