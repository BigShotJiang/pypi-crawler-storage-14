"""
DatabaseModule

描述: 数据库管理模块，负责存储和检索Tribler系统的各类数据。
"""

import asyncio
import logging
import os
import sqlite3
from typing import TYPE_CHECKING, List, Optional

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class MetadataStore:
    """
    元数据存储 (MetadataStore)
    """

    def __init__(self, session: 'Session', config: dict = None):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)

        # 默认配置
        self.default_config = {
            "database_path": "./tribler.db",
            "enable_wal": True,
            "connection_pool_size": 5,
            "enable_encryption": False,
            "backup_interval": 3600
        }

        # 合并配置
        self.config = self.default_config.copy()
        if config:
            self.config.update(config)

        self.connection = None
        self.is_initialized = False
        self.stats = {
            "torrents": 0,
            "channels": 0,
            "comments": 0,
            "votes": 0,
            "last_backup": 0
        }

    async def start(self):
        """启动元数据存储"""
        self.logger.info("启动元数据存储...")

        # 确保数据库目录存在 (如果是内存数据库则跳过)
        if self.config["database_path"] != ":memory:":
            db_dir = os.path.dirname(self.config["database_path"])
            if db_dir:
                os.makedirs(db_dir, exist_ok=True)

        # 初始化数据库连接
        await self._init_database()

        self.is_initialized = True
        self.logger.info("元数据存储启动完成")

    async def _init_database(self):
        """初始化数据库"""
        try:
            # 连接数据库
            self.connection = sqlite3.connect(self.config["database_path"], check_same_thread=False)

            # 启用WAL模式（如果启用且非内存数据库，虽然内存DB也支持WAL但不常见）
            if self.config.get("enable_wal", True):
                try:
                    self.connection.execute("PRAGMA journal_mode=WAL")
                except Exception as e:
                    self.logger.warning(f"无法启用 WAL 模式: {e}")

            # 创建表结构
            await self._create_tables()

        except Exception as e:
            self.logger.error(f"数据库初始化失败: {e}")
            raise

    async def _create_tables(self):
        """创建数据库表"""
        cursor = self.connection.cursor()

        # 创建torrents表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS torrents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                infohash TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                size INTEGER,
                category TEXT,
                num_seeders INTEGER DEFAULT 0,
                num_leechers INTEGER DEFAULT 0,
                created_date REAL,
                last_check REAL
            )
        """)

        self.connection.commit()
        self.logger.info("数据库表创建完成")

    async def stop(self):
        """停止元数据存储"""
        self.logger.info("停止元数据存储...")
        if self.connection:
            self.connection.close()
        self.is_initialized = False
        self.logger.info("元数据存储已停止")
class DatabaseModule(IModule):
    """
    数据库模块 (DatabaseModule)

    基础模块之一，提供 SQLite 数据库连接池或单例连接管理。
    """

    def __init__(self, config: dict = None):
        """初始化模块，接收配置参数"""
        self.config = config or {}
        self.initialized = False
        self.store = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        """返回模块名称"""
        return "database-module"

    @property
    def dependencies(self) -> List[str]:
        """返回依赖模块列表"""
        return ["event-notification-module"]

    async def initialize(self, session: 'Session') -> None:
        """初始化模块"""
        try:
            self.session = session
            self.store = MetadataStore(self.session, self.config)
            await self.store.start()
            self.initialized = True
        except Exception as e:
            # 记录详细日志以便调试
            logging.getLogger(self.__class__.__name__).error(f"DatabaseModule init failed: {e}")
            raise

    async def shutdown(self) -> None:
        """关闭模块"""
        try:
            if self.store:
                await self.store.stop()
            self.initialized = False
            self.store = None
            self.session = None
        except Exception as e:
            self.initialized = False

    def get_endpoints(self) -> List[RESTEndpoint]:
        """返回API端点"""
        return []

    def get_health_status(self) -> dict:
        """返回模块健康状态"""
        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "store_available": self.store is not None
            }
        }
