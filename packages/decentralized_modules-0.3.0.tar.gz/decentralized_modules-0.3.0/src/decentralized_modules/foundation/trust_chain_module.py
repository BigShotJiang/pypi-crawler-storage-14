"""
Trust Chain Module
信任链模块，管理节点信任关系
"""

import logging
from typing import TYPE_CHECKING, Optional, Dict, List
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class TrustService:
    """
    信任服务 (TrustService)

    管理节点间的信任评分和黑白名单。

    主要功能：
    - 更新节点信任分
    - 检查节点是否可信

    使用示例：

    ```python
    trust = session.get_module("trust-chain-module").service

    trust.report_behavior("node_123", positive=True)
    if trust.is_trusted("node_123"):
        print("Trusted node")
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.scores: Dict[str, float] = {}

    def report_behavior(self, node_id: str, positive: bool) -> None:
        """
        报告节点行为

        :param node_id: 节点ID
        :param positive: 是否为正面行为
        """
        current = self.scores.get(node_id, 0.5)
        delta = 0.1 if positive else -0.2
        self.scores[node_id] = max(0.0, min(1.0, current + delta))
        self.logger.debug(f"节点 {node_id} 信任分更新为: {self.scores[node_id]}")

    def is_trusted(self, node_id: str, threshold: float = 0.4) -> bool:
        """
        检查节点是否可信

        :param node_id: 节点ID
        :param threshold: 信任阈值
        :return: 是否可信
        """
        return self.scores.get(node_id, 0.5) >= threshold
class TrustChainModule(IModule):
    """
    信任链模块 (TrustChainModule)

    基础模块之一，维护 P2P 网络信任体系。
    """

    def __init__(self):
        super().__init__()
        self._name = "trust-chain-module"
        self.service: Optional[TrustService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化信任链模块"""
        self.session = session
        self.service = TrustService(self.session)
        session.context.register_service("trust", self.service)

    async def shutdown(self) -> None:
        """关闭模块"""
        pass

    def get_endpoints(self) -> list:
        return []
