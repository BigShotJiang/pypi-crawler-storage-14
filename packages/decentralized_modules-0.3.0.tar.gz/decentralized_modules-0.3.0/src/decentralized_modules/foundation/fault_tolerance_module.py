"""
Fault Tolerance Module
容错模块，提供重试机制和熔断保护
"""

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Callable, Any, Optional
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class FaultToleranceService:
    """
    容错服务 (FaultToleranceService)

    提供重试机制和简单的熔断保护，用于增强系统的健壮性。

    主要功能：
    - 异步函数重试装饰器/包装器
    - 熔断器状态管理

    使用示例：

    ```python
    ft = session.get_module("fault-tolerance-module").service

    async def unstable_task():
        # 模拟可能失败的任务
        pass

    # 带重试的执行
    result = await ft.retry(unstable_task, max_retries=3)
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)

    async def retry(self, func: Callable, max_retries: int = 3, delay: float = 1.0, *args, **kwargs) -> Any:
        """
        重试执行异步函数

        :param func: 异步目标函数
        :param max_retries: 最大重试次数
        :param delay: 重试间隔(秒)
        :param args: 函数参数
        :param kwargs: 函数关键字参数
        :return: 函数执行结果
        :raises: 最后一次失败的异常
        """
        last_exception = None

        for attempt in range(max_retries + 1):
            try:
                if attempt > 0:
                    self.logger.info(f"Retrying task {func.__name__} (Attempt {attempt}/{max_retries})...")
                    await asyncio.sleep(delay)

                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                self.logger.warning(f"Task {func.__name__} failed: {e}")

        raise last_exception
class FaultToleranceModule(IModule):
    """
    容错模块 (FaultToleranceModule)

    基础模块之一，提供系统容错能力。
    """

    def __init__(self):
        super().__init__()
        self._name = "fault-tolerance-module"
        self.service: Optional[FaultToleranceService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化容错模块"""
        self.session = session
        self.service = FaultToleranceService(self.session)
        session.context.register_service("fault_tolerance", self.service)

    async def shutdown(self) -> None:
        """关闭模块"""
        pass

    def get_endpoints(self) -> list:
        return []
