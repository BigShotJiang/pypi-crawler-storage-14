"""
Crypto Service Module
加密服务模块，提供基础加密功能
"""

import hashlib
import logging
import secrets
from typing import TYPE_CHECKING, List, Optional
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session


class CryptoService:
    """
    加密服务 (CryptoService)

    提供常用的加密、哈希和随机数生成功能。
    旨在为上层模块提供统一的安全原语接口。

    主要功能：
    - 哈希计算 (SHA256, SHA1)
    - 安全随机数生成
    - (未来可扩展) 对称/非对称加密

    使用示例：

    ```python
    crypto = session.get_module("crypto-service-module").service

    # 计算哈希
    digest = crypto.sha256(b"hello world")
    print(f"Hash: {digest}")

    # 生成随机 Token
    token = crypto.generate_token(32)
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)

    def sha256(self, data: bytes) -> str:
        """
        计算 SHA256 哈希

        :param data: 输入数据
        :return: 十六进制哈希字符串
        """
        return hashlib.sha256(data).hexdigest()

    def sha1(self, data: bytes) -> str:
        """
        计算 SHA1 哈希 (常用于 BitTorrent infohash)

        :param data: 输入数据
        :return: 十六进制哈希字符串
        """
        return hashlib.sha1(data).hexdigest()

    def generate_token(self, length: int = 32) -> str:
        """
        生成安全随机 Token (十六进制)

        :param length: 字节长度 (生成的字符串长度为 2 * length)
        :return: 随机 Token 字符串
        """
        return secrets.token_hex(length)

    def generate_random_bytes(self, length: int) -> bytes:
        """
        生成安全随机字节

        :param length: 字节长度
        :return: 随机字节
        """
        return secrets.token_bytes(length)


class CryptoServiceModule(IModule):
    """
    加密服务模块 (CryptoServiceModule)

    基础模块之一，提供加密和安全相关的基础服务。

    使用示例：

    ```python
    module = session.get_module("crypto-service-module")
    hash_val = module.service.sha256(b"test")
    ```
    """

    def __init__(self):
        super().__init__()
        self._name = "crypto-service-module"
        self.service: Optional[CryptoService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化加密服务模块"""
        self.session = session
        self.service = CryptoService(self.session)

        # 注册服务
        session.context.register_service("crypto", self.service)

    async def shutdown(self) -> None:
        """关闭加密服务模块"""
        pass

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []
