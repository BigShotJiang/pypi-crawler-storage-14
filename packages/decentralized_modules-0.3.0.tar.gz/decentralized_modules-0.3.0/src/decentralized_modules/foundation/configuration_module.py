# decentralized-modules/src/foundation/configuration_module.py
"""
Configuration Module
配置模块 - 管理系统配置和设置
"""

import json
import os
import logging
from typing import TYPE_CHECKING, Optional, Dict, Any, Union
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session


class ConfigurationService:
    """
    配置服务 (ConfigurationService)

    负责加载、保存和管理应用程序的全局配置。
    支持从 JSON 文件加载配置，并提供键值对的读写接口。

    主要功能：
    - 加载/保存配置到文件
    - 获取/设置配置项
    - 支持嵌套键访问 (例如 "network.port")

    使用示例：

    ```python
    config_service = session.get_module("configuration-module").service

    # 获取配置
    port = config_service.get("network.port", 8080)

    # 设置配置
    config_service.set("network.port", 9090)

    # 保存更改
    await config_service.save()
    ```
    """

    def __init__(self, session: 'Session', config_path: str = "config.json"):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.config_path = config_path
        self._config_data: Dict[str, Any] = {}
        
    async def start(self):
        """启动配置服务并加载配置"""
        self.logger.info(f"启动配置服务，配置文件路径: {self.config_path}")
        await self.load()
        
    async def stop(self):
        """停止配置服务"""
        self.logger.info("停止配置服务")

    async def load(self) -> bool:
        """
        从文件加载配置

        :return: 是否加载成功
        """
        if not os.path.exists(self.config_path):
            self.logger.warning(f"配置文件 {self.config_path} 不存在，使用默认配置")
            return False

        try:
            # 简单模拟异步文件读取
            import asyncio
            # 在实际生产中，应使用 aiofiles
            await asyncio.sleep(0)

            with open(self.config_path, 'r', encoding='utf-8') as f:
                self._config_data = json.load(f)
            self.logger.info("配置加载成功")
            return True
        except Exception as e:
            self.logger.error(f"加载配置文件失败: {e}")
            return False

    async def save(self) -> bool:
        """
        保存配置到文件

        :return: 是否保存成功
        """
        try:
            # 简单模拟异步文件写入
            import asyncio
            await asyncio.sleep(0)

            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self._config_data, f, indent=4)
            self.logger.info("配置保存成功")
            return True
        except Exception as e:
            self.logger.error(f"保存配置文件失败: {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置项

        :param key: 配置键，支持点号分隔的嵌套键 (e.g., "network.port")
        :param default: 默认值
        :return: 配置值
        """
        keys = key.split('.')
        value = self._config_data

        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default

    def set(self, key: str, value: Any) -> None:
        """
        设置配置项

        :param key: 配置键，支持点号分隔的嵌套键
        :param value: 配置值
        """
        keys = key.split('.')
        target = self._config_data

        for k in keys[:-1]:
            if k not in target or not isinstance(target[k], dict):
                target[k] = {}
            target = target[k]

        target[keys[-1]] = value


class ConfigurationModule(IModule):
    """
    配置模块 (ConfigurationModule)

    基础模块之一，为整个系统提供统一的配置管理能力。

    使用示例：

    ```python
    module = session.get_module("configuration-module")
    module.service.set("debug", True)
    await module.service.save()
    ```
    """

    def __init__(self, config_path: str = "config.json"):
        super().__init__()
        self._name = "configuration-module"
        self.config_path = config_path
        self.service: Optional[ConfigurationService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化配置模块"""
        self.session = session
        self.service = ConfigurationService(self.session, self.config_path)
        await self.service.start()

        # 注册服务到 Session Context，方便全局调用
        session.context.register_service("config", self.service)

    async def shutdown(self) -> None:
        """关闭配置模块"""
        if self.service:
            await self.service.stop()

    def get_endpoints(self) -> list[RESTEndpoint]:
        return []
