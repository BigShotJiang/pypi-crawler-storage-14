"""
Monitor Module
监控模块，负责收集应用程序的运行指标
"""

import logging
import time
from typing import TYPE_CHECKING, Dict, Any, Optional
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class MetricService:
    """
    指标服务 (MetricService)

    负责收集和存储应用程序的运行指标（Metrics），如计数器、仪表盘等。
    类似于 Prometheus 的数据模型。

    主要功能：
    - 计数器 (Counter): 只增不减
    - 仪表盘 (Gauge): 可增可减
    - 获取所有指标快照

    使用示例：

    ```python
    metrics = session.get_module("monitor-module").service

    # 增加计数
    metrics.inc_counter("requests_total")

    # 设置数值
    metrics.set_gauge("active_connections", 10)

    # 获取快照
    print(metrics.get_metrics())
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self._counters: Dict[str, int] = {}
        self._gauges: Dict[str, float] = {}
        self._start_time = time.time()

    def inc_counter(self, name: str, value: int = 1) -> None:
        """
        增加计数器

        :param name: 指标名称
        :param value: 增加量 (默认1)
        """
        if value < 0:
            self.logger.warning("Counter increment must be non-negative")
            return
        self._counters[name] = self._counters.get(name, 0) + value

    def set_gauge(self, name: str, value: float) -> None:
        """
        设置仪表盘数值

        :param name: 指标名称
        :param value: 数值
        """
        self._gauges[name] = value

    def get_metrics(self) -> Dict[str, Any]:
        """
        获取所有指标

        :return: 包含 counters, gauges 和 uptime 的字典
        """
        return {
            "counters": self._counters.copy(),
            "gauges": self._gauges.copy(),
            "uptime": time.time() - self._start_time
        }
class MonitorModule(IModule):
    """
    监控模块 (MonitorModule)

    基础模块之一，用于收集应用层面的业务指标。
    区别于 HealthMonitorModule (关注系统资源)，本模块关注业务逻辑产生的数据。
    """

    def __init__(self):
        super().__init__()
        self._name = "monitor-module"
        self.service: Optional[MetricService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化监控模块"""
        self.session = session
        self.service = MetricService(self.session)
        session.context.register_service("metrics", self.service)

    async def shutdown(self) -> None:
        """关闭模块"""
        pass

    def get_endpoints(self) -> list:
        return []
