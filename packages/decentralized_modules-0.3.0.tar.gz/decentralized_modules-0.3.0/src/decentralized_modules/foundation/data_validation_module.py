"""
Data Validation Module
数据验证模块，提供数据格式校验功能
"""

import logging
from typing import TYPE_CHECKING, Any, Dict, Optional, List, Type, Tuple
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class ValidationService:
    """
    数据验证服务 (ValidationService)

    提供基础的数据验证功能，确保数据符合预期的格式和类型。

    主要功能：
    - 类型检查
    - 必填字段检查
    - 范围检查

    使用示例：

    ```python
    validator = session.get_module("data-validation-module").service

    data = {"name": "Alice", "age": 30}
    schema = {
        "name": {"type": str, "required": True},
        "age": {"type": int, "min": 0}
    }

    is_valid, error = validator.validate(data, schema)
    if not is_valid:
        print(f"Validation error: {error}")
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)

    def validate(self, data: Dict[str, Any], schema: Dict[str, Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """
        验证数据

        :param data: 待验证的字典数据
        :param schema: 验证模式定义
        :return: (是否通过, 错误信息)
        """
        for field, rules in schema.items():
            # 检查必填
            if rules.get("required", False) and field not in data:
                return False, f"Missing required field: {field}"

            if field in data:
                value = data[field]

                # 检查类型
                expected_type = rules.get("type")
                if expected_type and not isinstance(value, expected_type):
                    return False, f"Field '{field}' expected type {expected_type.__name__}, got {type(value).__name__}"

                # 检查范围 (仅数字)
                if isinstance(value, (int, float)):
                    if "min" in rules and value < rules["min"]:
                        return False, f"Field '{field}' value {value} is less than min {rules['min']}"
                    if "max" in rules and value > rules["max"]:
                        return False, f"Field '{field}' value {value} is greater than max {rules['max']}"

        return True, None
from typing import Tuple

class DataValidationModule(IModule):
    """
    数据验证模块 (DataValidationModule)

    基础模块之一，提供通用数据验证服务。
    """

    def __init__(self):
        super().__init__()
        self._name = "data-validation-module"
        self.service: Optional[ValidationService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化数据验证模块"""
        self.session = session
        self.service = ValidationService(self.session)
        session.context.register_service("validator", self.service)

    async def shutdown(self) -> None:
        """关闭模块"""
        pass

    def get_endpoints(self) -> list:
        return []
