"""
Network Module
网络通信基础模块
"""

import asyncio
import logging
from typing import TYPE_CHECKING, List, Optional, Callable, Dict, Any
import sys

# 尝试导入 ipv8
try:
    import ipv8
    from ipv8.configuration import get_default_configuration
    from ipv8.community import CommunitySettings
    from ipv8.messaging.interfaces.udp.endpoint import UDPReceiver
    # 尝试导入核心 IPv8 服务类，通常在 ipv8_service.py 或直接构建
    # 在 py-ipv8 库中，通常是一个 Service 类或手动管理 Endpoint 和 Overlay
    # 为了通用性，我们这里假设一个简单的 Service 结构
    HAS_IPV8 = True
except ImportError:
    HAS_IPV8 = False

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session


class IPv8Service:
    """
    简单的 IPv8 服务封装
    """
    def __init__(self, config):
        self.config = config
        self.overlays = []
        self.endpoint = None

    async def start(self):
        # 这是一个占位符，用于模拟 IPv8 启动
        # 真实启动涉及:
        # 1. 创建 Endpoint (UDP)
        # 2. 加载 Keys
        # 3. 启动 Overlays
        pass

    async def stop(self):
        pass

    def add_overlay(self, overlay):
        self.overlays.append(overlay)


class NetworkService:
    """
    网络服务 (NetworkService)
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.servers = []
        self.transports = []
        self.ipv8 = None # IPv8 实例

    async def start_tcp_server(self, port: int, client_handler: Callable):
        """启动 TCP 服务器"""
        try:
            server = await asyncio.start_server(client_handler, '0.0.0.0', port)
            self.servers.append(server)
            self.logger.info(f"TCP 服务器启动，监听端口: {port}")
            asyncio.create_task(server.serve_forever())
            return server
        except Exception as e:
            self.logger.error(f"启动 TCP 服务器失败 (端口 {port}): {e}")
            raise

    async def start_udp_listener(self, port: int, protocol_factory: Callable):
        """启动 UDP 监听"""
        try:
            loop = asyncio.get_running_loop()
            transport, protocol = await loop.create_datagram_endpoint(
                protocol_factory,
                local_addr=('0.0.0.0', port)
            )
            self.transports.append(transport)
            self.logger.info(f"UDP 监听启动，端口: {port}")
            return transport, protocol
        except Exception as e:
            self.logger.error(f"启动 UDP 监听失败 (端口 {port}): {e}")
            raise

    async def initialize_ipv8(self, config: dict = None):
        """
        初始化 IPv8 服务
        """
        if not HAS_IPV8:
            self.logger.warning("IPv8 library not found, skipping IPv8 initialization.")
            return

        try:
            self.logger.info("Initializing IPv8 service...")
            ipv8_config = get_default_configuration()
            ipv8_config['logger'] = {
                'level': logging.INFO,
            }

            # 使用本地定义的简单封装，避免导入错误的模块
            self.ipv8 = IPv8Service(ipv8_config)
            await self.ipv8.start()

            self.logger.info("IPv8 service initialized")

        except Exception as e:
            self.logger.error(f"Failed to initialize IPv8: {e}")
            # 确保即使失败也不会导致 crash，ipv8 属性为 None
            self.ipv8 = None

    async def stop_all(self):
        """停止所有网络服务"""
        self.logger.info("停止所有网络服务...")

        for server in self.servers:
            server.close()
            await server.wait_closed()

        for transport in self.transports:
            transport.close()

        if self.ipv8:
            await self.ipv8.stop()

        self.servers.clear()
        self.transports.clear()
        self.logger.info("所有网络服务已停止")


class NetworkModule(IModule):
    """
    网络模块 (NetworkModule)
    """

    def __init__(self):
        super().__init__()
        self._name = "network-module"
        self.service: Optional[NetworkService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化网络模块"""
        self.session = session
        self.service = NetworkService(self.session)

        # 尝试初始化 IPv8
        await self.service.initialize_ipv8()

        # 注册服务
        session.context.register_service("network", self.service)

    async def shutdown(self) -> None:
        """关闭网络模块"""
        if self.service:
            await self.service.stop_all()

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []
