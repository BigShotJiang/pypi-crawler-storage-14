"""
Resource Manager Module
资源管理模块，管理系统资源配额
"""

import logging
from typing import TYPE_CHECKING, Optional, List
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session
class ResourceService:
    """
    资源服务 (ResourceService)

    提供资源配额管理功能。

    主要功能：
    - 设置资源限制 (如最大并发数)
    - 检查资源可用性

    使用示例：

    ```python
    resource = session.get_module("resource-manager-module").service

    if resource.acquire("concurrent_downloads"):
        # do download
        resource.release("concurrent_downloads")
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.limits = {"concurrent_downloads": 5}
        self.usage = {"concurrent_downloads": 0}

    def acquire(self, resource_type: str) -> bool:
        """
        申请资源

        :param resource_type: 资源类型
        :return: 是否申请成功
        """
        limit = self.limits.get(resource_type, float('inf'))
        current = self.usage.get(resource_type, 0)

        if current < limit:
            self.usage[resource_type] = current + 1
            return True
        return False

    def release(self, resource_type: str) -> None:
        """
        释放资源

        :param resource_type: 资源类型
        """
        if self.usage.get(resource_type, 0) > 0:
            self.usage[resource_type] -= 1
class ResourceManagerModule(IModule):
    """
    资源管理模块 (ResourceManagerModule)

    基础模块之一，管理系统资源限额。
    """

    def __init__(self):
        super().__init__()
        self._name = "resource-manager-module"
        self.service: Optional[ResourceService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> list:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化资源管理模块"""
        self.session = session
        self.service = ResourceService(self.session)
        session.context.register_service("resource_manager", self.service)

    async def shutdown(self) -> None:
        """关闭模块"""
        pass

    def get_endpoints(self) -> list:
        return []
