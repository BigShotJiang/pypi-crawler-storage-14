"""
Logging Monitoring Module
日志监控模块，配置系统日志
"""

import logging
from typing import TYPE_CHECKING, List
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session
class LoggingMonitoringModule(IModule):
    """
    日志监控模块 (LoggingMonitoringModule)

    基础模块之一，负责初始化和配置 Python 的 logging 系统。

    主要功能：
    - 配置日志格式和级别
    - 提供日志记录基础设施

    使用示例：

    ```python
    # 模块初始化时会自动配置日志
    logging.info("System started")
    ```
    """

    def __init__(self):
        super().__init__()
        self._name = "logging-monitoring-module"
        self.session = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化日志模块"""
        self.session = session

        # 配置基础日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        logging.info("LoggingMonitoringModule initialized")

    async def shutdown(self) -> None:
        """关闭模块"""
        logging.info("LoggingMonitoringModule shutdown")

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []
