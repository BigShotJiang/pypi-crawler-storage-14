"""
Task Queue Module
任务队列模块
"""

import asyncio
import logging
from typing import TYPE_CHECKING, List, Optional, Callable, Any, Dict
from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from ..core.session import Session


class TaskQueueService:
    """
    任务队列服务 (TaskQueueService)

    提供异步任务的排队和执行功能，支持后台任务管理。

    主要功能：
    - 添加异步任务到队列
    - 串行处理任务
    - 任务错误处理

    使用示例：

    ```python
    task_queue = session.get_module("task-queue-module").service

    async def my_task(name):
        print(f"Executing task: {name}")
        await asyncio.sleep(1)

    # 添加任务
    await task_queue.add_task(my_task, "Task 1")
    await task_queue.add_task(my_task, "Task 2")
    ```
    """

    def __init__(self, session: 'Session'):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.queue = asyncio.Queue()
        self.is_running = False
        self.worker_task = None

    async def start(self):
        """启动任务处理 worker"""
        self.is_running = True
        self.worker_task = asyncio.create_task(self._worker())
        self.logger.info("任务队列服务已启动")

    async def stop(self):
        """停止任务队列服务"""
        self.is_running = False
        if self.worker_task:
            self.worker_task.cancel()
            try:
                await self.worker_task
            except asyncio.CancelledError:
                pass
        self.logger.info("任务队列服务已停止")

    async def add_task(self, func: Callable, *args, **kwargs):
        """
        添加任务到队列

        :param func: 异步函数
        :param args: 位置参数
        :param kwargs: 关键字参数
        """
        await self.queue.put((func, args, kwargs))
        self.logger.debug(f"任务已添加到队列，当前队列长度: {self.queue.qsize()}")

    async def _worker(self):
        """后台 worker，处理队列中的任务"""
        while self.is_running:
            try:
                func, args, kwargs = await self.queue.get()
                try:
                    self.logger.debug(f"开始执行任务: {func.__name__}")
                    if asyncio.iscoroutinefunction(func):
                        await func(*args, **kwargs)
                    else:
                        func(*args, **kwargs)
                    self.logger.debug(f"任务执行完成: {func.__name__}")
                except Exception as e:
                    self.logger.error(f"执行任务失败: {e}")
                finally:
                    self.queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Worker 错误: {e}")
                await asyncio.sleep(1) # 防止死循环


class TaskQueueModule(IModule):
    """
    任务队列模块 (TaskQueueModule)

    基础模块之一，用于管理后台异步任务。

    使用示例：

    ```python
    module = session.get_module("task-queue-module")
    await module.service.add_task(some_async_func)
    ```
    """

    def __init__(self):
        super().__init__()
        self._name = "task-queue-module"
        self.service: Optional[TaskQueueService] = None
        self.session: Optional['Session'] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, session: 'Session') -> None:
        """初始化任务队列模块"""
        self.session = session
        self.service = TaskQueueService(self.session)
        await self.service.start()

        session.context.register_service("task_queue", self.service)

    async def shutdown(self) -> None:
        """关闭任务队列模块"""
        if self.service:
            await self.service.stop()

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []
