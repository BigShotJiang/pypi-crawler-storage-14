"""
ContentDiscoveryModule

描述: 内容发现模块，负责在P2P网络中发现、索引和推荐内容，基于用户偏好和网络拓扑进行智能推荐。
"""

import asyncio
import hashlib
import logging
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session


class ContentItem:
    """内容项目类"""
    
    def __init__(self, infohash: str, name: str, size: int, category: str, 
                 num_seeders: int, num_leechers: int, source_node: str = ""):
        self.infohash = infohash
        self.name = name
        self.size = size
        self.category = category
        self.num_seeders = num_seeders
        self.num_leechers = num_leechers
        self.source_node = source_node
        self.discovery_time = datetime.now().timestamp()
        self.popularity_score = 0.0
        self.relevance_score = 0.0
        
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "infohash": self.infohash,
            "name": self.name,
            "size": self.size,
            "category": self.category,
            "num_seeders": self.num_seeders,
            "num_leechers": self.num_leechers,
            "source_node": self.source_node,
            "discovery_time": self.discovery_time,
            "popularity_score": self.popularity_score,
            "relevance_score": self.relevance_score
        }


class UserPreference:
    """用户偏好类"""
    
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.category_preferences = {}
        self.search_history = []
        self.download_history = []
        self.last_updated = datetime.now().timestamp()
        
    def update_category_preference(self, category: str, weight: float):
        """更新类别偏好"""
        self.category_preferences[category] = self.category_preferences.get(category, 0.0) + weight
        self.last_updated = datetime.now().timestamp()


class ContentDiscoveryManager:
    """
    内容发现管理器，负责发现、索引和推荐内容
    """
    
    def __init__(self, session: 'Session', config: dict = None):
        self.session = session
        self.logger = logging.getLogger(self.__class__.__name__)
        self.config = config or {
            "max_recommendations": 20,
            "enable_learning": True,
            "trending_window": 3600,  # 1小时
            "enable_personalization": True
        }
        self.content_index = {}
        self.user_preferences = {}
        self.trending_content = {}
        self.recommendation_cache = {}
        self.discovery_stats = {
            "total_discovered": 0,
            "total_recommendations": 0,
            "active_users": 0
        }
        self.is_initialized = False
        
    async def start(self):
        """启动内容发现管理器"""
        self.logger.info("启动内容发现管理器...")
        await self._init_content_index()
        asyncio.create_task(self._discovery_scheduler())
        self.is_initialized = True
        self.logger.info("内容发现管理器启动完成")
        
    async def _init_content_index(self):
        """初始化内容索引"""
        self.logger.info("初始化内容索引...")
        
    async def _discovery_scheduler(self):
        """发现调度器"""
        while self.is_initialized:
            try:
                await asyncio.sleep(60)
                await self._update_trending_content()
            except Exception as e:
                self.logger.error(f"发现调度器出错: {e}")
                
    async def _update_trending_content(self):
        """更新热门内容"""
        cutoff_time = datetime.now().timestamp() - self.config["trending_window"]
        expired_keys = [key for key, data in self.trending_content.items() 
                       if data["timestamp"] < cutoff_time]
        for key in expired_keys:
            del self.trending_content[key]
        self.logger.debug(f"更新热门内容，当前有 {len(self.trending_content)} 个热门项目")
        
    async def stop(self):
        """停止内容发现管理器"""
        self.logger.info("停止内容发现管理器...")
        self.is_initialized = False
        
    async def discover_content(self, query: str, hops: int = 1) -> List[ContentItem]:
        """发现内容"""
        if not self.is_initialized:
            return []

        discovered_items = []

        # 利用 SearchModule 发现内容
        search_module = self.session.get_module("search-module")
        if search_module:
            try:
                search_results = await search_module.search(query)
                for res in search_results:
                    # 将搜索结果转换为 ContentItem 并索引
                    infohash = res.get("infohash")
                    if not infohash:
                        continue

                    item = ContentItem(
                        infohash=infohash,
                        name=res.get("name", "Unknown"),
                        size=res.get("size", 0),
                        category=res.get("category", "Other"),
                        num_seeders=res.get("num_seeders", 0),
                        num_leechers=res.get("num_leechers", 0),
                        source_node=res.get("source", "search")
                    )

                    self.content_index[infohash] = item
                    self.discovery_stats["total_discovered"] += 1
                    self.trending_content[infohash] = {
                        "name": item.name,
                        "timestamp": datetime.now().timestamp(),
                        "popularity": item.num_seeders
                    }
                    discovered_items.append(item)
            except Exception as e:
                self.logger.error(f"SearchModule discovery failed: {e}")

        # 如果没有找到结果，仅作为演示，生成一些模拟数据 (TODO: 生产环境应移除)
        if not discovered_items and self.config.get("enable_mock_data", True):
             for i in range(5):
                infohash = hashlib.sha1(f"{query}_{i}_{datetime.now().timestamp()}".encode()).hexdigest()
                item = ContentItem(
                    infohash=infohash,
                    name=f"{query} - Mock Item {i+1}",
                    size=(i + 1) * 500 * 1024 * 1024,
                    category="Video" if "video" in query.lower() else "Other",
                    num_seeders=max(1, 50 - i * 2),
                    num_leechers=max(0, 30 - i)
                )
                self.content_index[infohash] = item
                discovered_items.append(item)

        self.logger.info(f"发现 {len(discovered_items)} 个内容项目: {query}")
        return discovered_items
        
    def get_recommendations(self, user_id: str, limit: int = None) -> List[ContentItem]:
        """获取内容推荐"""
        if not self.is_initialized:
            return []
            
        limit = limit or self.config["max_recommendations"]
        user_pref = self.user_preferences.get(user_id)
        if user_pref and self.config["enable_personalization"]:
            recommended_items = self._get_personalized_recommendations(user_pref, limit)
        else:
            recommended_items = self._get_default_recommendations(limit)
            
        self.discovery_stats["total_recommendations"] += len(recommended_items)
        self.recommendation_cache[user_id] = {
            "items": recommended_items,
            "timestamp": datetime.now().timestamp()
        }
        self.logger.info(f"为用户 {user_id} 推荐 {len(recommended_items)} 个项目")
        return recommended_items
        
    def _get_personalized_recommendations(self, user_pref: UserPreference, limit: int) -> List[ContentItem]:
        """获取个性化推荐"""
        sorted_content = sorted(
            self.content_index.values(),
            key=lambda x: (
                user_pref.category_preferences.get(x.category, 0.0) * 0.4 +
                x.num_seeders * 0.3 +
                x.popularity_score * 0.3
            ),
            reverse=True
        )
        return sorted_content[:limit]
        
    def _get_default_recommendations(self, limit: int) -> List[ContentItem]:
        """获取默认推荐（热门内容）"""
        sorted_content = sorted(
            self.content_index.values(),
            key=lambda x: x.num_seeders,
            reverse=True
        )
        return sorted_content[:limit]
        
    def record_user_interaction(self, user_id: str, infohash: str, interaction_type: str):
        """记录用户交互"""
        if not self.config["enable_learning"]:
            return
            
        if user_id not in self.user_preferences:
            self.user_preferences[user_id] = UserPreference(user_id)
            self.discovery_stats["active_users"] += 1
            
        user_pref = self.user_preferences[user_id]
        
        if infohash in self.content_index:
            content = self.content_index[infohash]
            if interaction_type == "search":
                user_pref.update_category_preference(content.category, 0.1)
                user_pref.search_history.append({
                    "infohash": infohash,
                    "timestamp": datetime.now().timestamp()
                })
            elif interaction_type == "download":
                user_pref.update_category_preference(content.category, 0.3)
                user_pref.download_history.append({
                    "infohash": infohash,
                    "timestamp": datetime.now().timestamp()
                })
        self.logger.debug(f"记录用户交互: {user_id} - {interaction_type} - {infohash}")
        
    def get_trending_content(self, limit: int = 10) -> List[ContentItem]:
        """获取热门内容"""
        trending_list = []
        for infohash, data in sorted(
            self.trending_content.items(),
            key=lambda x: x[1]["popularity"],
            reverse=True
        )[:limit]:
            if infohash in self.content_index:
                item = self.content_index[infohash]
                trending_list.append(item)
        return trending_list
        
    def get_stats(self) -> Dict[str, Any]:
        """获取内容发现统计信息"""
        return {
            "discovery_stats": self.discovery_stats,
            "indexed_content_count": len(self.content_index),
            "trending_content_count": len(self.trending_content),
            "user_preference_count": len(self.user_preferences),
            "config": self.config,
            "initialized": self.is_initialized
        }


class ContentDiscoveryModule(IModule):
    """
    内容发现模块 (ContentDiscoveryModule)

    负责在 P2P 网络中发现、索引和推荐内容。
    它位于扩展层 (Extensions)，依赖 SearchModule 和 RelevanceModule 提供基础能力。

    主要功能：
    - 主动发现热门内容
    - 基于用户偏好推荐内容
    - 维护热门内容列表

    使用示例：

    ```python
    discovery_module = session.get_module("content-discovery-module")

    # 发现内容
    items = await discovery_module.manager.discover_content("linux iso")

    # 获取推荐
    recommendations = discovery_module.manager.get_recommendations(user_id="user1")
    ```
    """
    
    def __init__(self, config: dict = None):
        """初始化模块，接收配置参数"""
        self.config = config or {}
        self.initialized = False
        self.manager = None
        self.session: Optional['Session'] = None
        
    @property
    def name(self) -> str:
        """返回模块名称"""
        return "content-discovery-module"
    
    @property
    def dependencies(self) -> List[str]:
        """返回依赖模块列表"""
        # 注意：这些依赖模块需要确保在系统中存在，或者按需加载
        # relevance-module 已被移除，不再依赖
        return ["search-module", "network-module"]
    
    async def initialize(self, session: 'Session') -> None:
        """初始化模块"""
        try:
            self.session = session
            self.manager = ContentDiscoveryManager(self.session, self.config)
            await self.manager.start()
            self.initialized = True
        except Exception as e:
            raise
    
    async def shutdown(self) -> None:
        """关闭模块"""
        try:
            if self.manager:
                await self.manager.stop()
            self.initialized = False
            self.manager = None
            self.session = None
        except Exception as e:
            self.initialized = False
    
    def get_endpoints(self) -> List[RESTEndpoint]:
        """返回API端点"""
        return []
    
    def get_health_status(self) -> dict:
        """返回模块健康状态"""
        return {
            "status": "healthy" if self.initialized else "uninitialized",
            "module": self.name,
            "dependencies_met": True,
            "info": {
                "manager_available": self.manager is not None
            }
        }
