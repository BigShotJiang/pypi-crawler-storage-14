"""
SearchModule

描述: 基础搜索模块，提供内容搜索功能的抽象和基础实现。
"""

import logging
from typing import List, Dict, Any, Optional, TYPE_CHECKING

from ..interfaces import IModule, RESTEndpoint

if TYPE_CHECKING:
    from .session import Session


class SearchModule(IModule):
    """
    SearchModule - 负责处理搜索请求并返回结果。

    作为扩展模块（Service/Extension），它利用核心层提供的能力（如数据库、网络）来执行搜索。
    目前实现主要依赖 DatabaseModule 进行本地内容检索。

    使用示例：

    ```python
    search_module = session.get_module("search-module")
    results = await search_module.search("query string", limit=10)
    for item in results:
        print(item["name"], item["infohash"])
    ```
    """

    def __init__(self):
        self._name = "search-module"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = None
        self.initialized = False

    @property
    def name(self) -> str:
        return self._name

    @property
    def dependencies(self) -> List[str]:
        return ["network-module", "database-module"]

    async def initialize(self, session: 'Session') -> None:
        """初始化搜索模块"""
        self.session = session
        self.initialized = True
        self.logger.info("SearchModule initialized")

    async def shutdown(self) -> None:
        """关闭搜索模块"""
        self.initialized = False
        self.logger.info("SearchModule shutdown")

    async def search(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        执行搜索

        :param query: 搜索关键词
        :param limit: 返回结果数量限制
        :return: 搜索结果列表
        """
        if not self.initialized:
            self.logger.warning("SearchModule not initialized")
            return []

        self.logger.info(f"Executing search for query: {query}")

        results = []

        # 1. 本地数据库搜索
        try:
            db_module = self.session.get_module("database-module")
            if db_module and db_module.store and db_module.store.connection:
                cursor = db_module.store.connection.cursor()
                # 简单的模糊搜索
                like_query = f"%{query}%"
                cursor.execute("""
                    SELECT infohash, name, size, category, num_seeders, num_leechers
                    FROM torrents
                    WHERE name LIKE ?
                    LIMIT ?
                """, (like_query, limit))

                columns = [column[0] for column in cursor.description]
                for row in cursor.fetchall():
                    item = dict(zip(columns, row))
                    item["source"] = "local_db"
                    results.append(item)

                self.logger.info(f"Found {len(results)} results in local database")
        except Exception as e:
            self.logger.error(f"Error searching local database: {e}")

        # 2. 如果本地结果不足，通过网络模块搜索 (TODO)
        # network_module = self.session.get_module("network-module")
        # if len(results) < limit and network_module:
        #     # remote_results = await network_module.search(query)
        #     # results.extend(remote_results)
        #     pass

        return results[:limit]

    def get_endpoints(self) -> List[RESTEndpoint]:
        return []