from setuptools import setup, find_packages

setup(
    name="decentralized-modules",
    version="0.3.0",
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        'ipv8>=2.8.0',
        'aiohttp>=3.8.0',
        'cryptography>=3.4.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0',
            'pytest-asyncio>=0.15.0',
            'black>=22.0.0',
            'flake8>=4.0.0',
        ]
    },
    author="Decentralized Modules Team",
    author_email="contact@decentralized-modules.org",
    description="Decentralized Modules - A modular, reusable core functionality library for decentralized network applications",
    long_description=open("README.md").read() if open("README.md", encoding='utf-8').read() else "Decentralized Modules Package",
    long_description_content_type="text/markdown",
    url="https://github.com/napoler/decentralized-modules",
    project_urls={
        "Bug Reports": "https://github.com/napoler/decentralized-modules/issues",
        "Source": "https://github.com/napoler/decentralized-modules",
        "Documentation": "https://github.com/napoler/decentralized-modules/wiki",
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Networking",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
    ],
    python_requires=">=3.8",
)
