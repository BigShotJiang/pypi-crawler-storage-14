
import unittest
import asyncio
import sqlite3
import os
from unittest.mock import MagicMock
from decentralized_modules.foundation.database_module import DatabaseModule

class TestDatabaseModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        # Use in-memory DB for testing
        self.config = {"database_path": ":memory:", "enable_wal": False}
        self.module = DatabaseModule(self.config)
        await self.module.initialize(self.session)

    async def asyncTearDown(self):
        await self.module.shutdown()

    async def test_connection_and_tables(self):
        store = self.module.store
        self.assertIsNotNone(store.connection)

        # Check if tables created
        cursor = store.connection.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='torrents'")
        result = cursor.fetchone()
        self.assertIsNotNone(result)
        self.assertEqual(result[0], 'torrents')

    async def test_crud_operations(self):
        conn = self.module.store.connection
        cursor = conn.cursor()

        # Insert
        cursor.execute("INSERT INTO torrents (infohash, name) VALUES (?, ?)", ("hash1", "test.iso"))
        conn.commit()

        # Read
        cursor.execute("SELECT name FROM torrents WHERE infohash=?", ("hash1",))
        result = cursor.fetchone()
        self.assertEqual(result[0], "test.iso")

if __name__ == '__main__':
    unittest.main()
