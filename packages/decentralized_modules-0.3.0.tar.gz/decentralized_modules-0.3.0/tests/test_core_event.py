
import unittest
import asyncio
from unittest.mock import MagicMock
from decentralized_modules.core.event_notification_module import EventNotificationModule
from decentralized_modules.core.notifier import Notification

class TestEventNotificationModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.session.context = MagicMock()
        self.module = EventNotificationModule()
        await self.module.initialize(self.session)

    async def test_pub_sub(self):
        notifier = self.session.notifier

        # Define handler
        received_args = {}
        def handler(infohash, name, hidden):
            received_args['infohash'] = infohash
            received_args['name'] = name

        # Subscribe using Enum member directly
        notifier.add(Notification.torrent_finished, handler)

        # Publish using Enum member (or string, notify handles conversion)
        notifier.notify(Notification.torrent_finished, infohash="abc", name="test", hidden=False)

        # Verify
        self.assertEqual(received_args.get('infohash'), "abc")
        self.assertEqual(received_args.get('name'), "test")

    async def test_string_topic_notify(self):
        # Test that notify converts string to Enum correctly
        notifier = self.session.notifier

        called = False
        def handler(**kwargs):
            nonlocal called
            called = True

        # Add must use Enum
        notifier.add(Notification.torrent_finished, handler)

        # Notify using string
        notifier.notify("torrent_finished", infohash="a", name="b", hidden=True)

        self.assertTrue(called)

if __name__ == '__main__':
    unittest.main()
