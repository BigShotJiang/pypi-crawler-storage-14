
import unittest
import asyncio
from unittest.mock import MagicMock, patch, AsyncMock
from decentralized_modules.core.torrent_module import TorrentModule, DefaultTorrentEngine, LibTorrentEngine, DownloadConfig, TorrentStatus

class TestTorrentModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.session.context = MagicMock()
        self.module = TorrentModule()
        # Force mock engine for general logic tests
        self.module.config = {"force_mock": True}
        await self.module.initialize(self.session)

    async def test_initialization(self):
        self.assertTrue(self.module.initialized)
        self.assertIsInstance(self.module.torrent_engine, DefaultTorrentEngine)
        self.session.context.register_service.assert_called_with("torrent_engine", self.module.torrent_engine)

    async def test_add_remove_torrent(self):
        data = b"dummy_data"
        config = DownloadConfig(save_path="/tmp/downloads")

        # Add
        success = await self.module.add_torrent(data, config)
        self.assertTrue(success)

        # Verify it exists
        torrents = await self.module.get_all_torrents()
        self.assertEqual(len(torrents), 1)
        infohash = torrents[0].infohash

        # Remove
        success = await self.module.remove_torrent(infohash)
        self.assertTrue(success)

        torrents = await self.module.get_all_torrents()
        self.assertEqual(len(torrents), 0)

    async def test_torrent_lifecycle_mock(self):
        # Test start/stop logic on Mock engine
        data = b"lifecycle_test"
        await self.module.add_torrent(data)
        torrents = await self.module.get_all_torrents()
        infohash = torrents[0].infohash

        # Default state is paused
        status = await self.module.get_torrent_status(infohash)
        self.assertEqual(status.state, "paused")

        # Start
        await self.module.start_torrent(infohash)
        status = await self.module.get_torrent_status(infohash)
        self.assertEqual(status.state, "downloading")

        # Stop
        await self.module.stop_torrent(infohash)
        status = await self.module.get_torrent_status(infohash)
        self.assertEqual(status.state, "paused")

    async def test_libtorrent_engine_logic(self):
        # This test verifies the logic of LibTorrentEngine using mocks for the libtorrent library

        # Mock libtorrent module
        with patch('decentralized_modules.core.torrent_module.HAS_LIBTORRENT', True):
            with patch('decentralized_modules.core.torrent_module.lt') as mock_lt:
                # Setup mock session
                mock_session = MagicMock()
                mock_lt.session.return_value = mock_session

                # Create engine directly
                engine = LibTorrentEngine()
                await engine.initialize()

                self.assertTrue(engine._initialized)
                mock_lt.session.assert_called()

                # Test Add Torrent
                mock_info = MagicMock()
                mock_info.info_hash.return_value = "hash123"
                mock_info.name.return_value = "test.iso"
                mock_lt.torrent_info.return_value = mock_info
                mock_lt.bdecode.return_value = {}

                mock_handle = MagicMock()
                # Set explicit integer values for comparison
                mock_handle.status.return_value.state = 3
                mock_handle.status.return_value.progress = 0.5
                mock_handle.status.return_value.download_payload_rate = 100 # int
                mock_handle.status.return_value.upload_payload_rate = 50 # int
                mock_handle.status.return_value.total_wanted = 1000 # int
                mock_handle.status.return_value.total_wanted_done = 500 # int
                mock_handle.status.return_value.num_seeds = 5 # int
                mock_handle.status.return_value.num_peers = 10 # int
                mock_handle.is_valid.return_value = True

                # Simulate states for lt enum
                mock_lt.torrent_status.states.downloading = 3

                mock_session.add_torrent.return_value = mock_handle

                config = DownloadConfig()
                success = await engine.add_torrent(b"data", config)
                self.assertTrue(success)
                self.assertIn("hash123", engine._handles)

                # Test Status Mapping
                status = await engine.get_torrent_status("hash123")
                self.assertIsNotNone(status)
                self.assertEqual(status.infohash, "hash123")
                self.assertEqual(status.state, "downloading")
                self.assertEqual(status.progress, 0.5)
                self.assertEqual(status.download_rate, 100)

if __name__ == '__main__':
    unittest.main()
