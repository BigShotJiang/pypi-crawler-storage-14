
import unittest
import asyncio
from unittest.mock import MagicMock
from decentralized_modules.core.points_core_module import PointsCoreModule, TransactionType

class TestPointsCoreModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.session.context = MagicMock()

        # Mock DatabaseModule
        self.db_module = MagicMock()
        # Mock sqlite connection/cursor
        self.conn = MagicMock()
        self.cursor = MagicMock()
        self.db_module.store.connection = self.conn
        self.conn.cursor.return_value = self.cursor

        # Mock DB results
        # First call: get balance (0)
        # Second call: insert (None)
        # Third call: get new balance (50)
        self.cursor.fetchone.side_effect = [(0,), (50,), (50,)]

        self.session.get_module.return_value = self.db_module

        self.module = PointsCoreModule()
        await self.module.initialize(self.session)

    async def test_earn_points(self):
        # Reset side effect for specific test flow
        self.cursor.fetchone.side_effect = [(50,)] # Result of "SELECT SUM..." after insert

        result = await self.module.service.earn_points("user1", 50, TransactionType.EARN_SEEDING)

        self.assertTrue(result['success'])
        self.assertEqual(result['new_balance'], 50)

        # Verify SQL execution
        self.cursor.execute.assert_called()
        insert_call = [call for call in self.cursor.execute.call_args_list if "INSERT INTO" in call[0][0]]
        self.assertTrue(len(insert_call) > 0)

    async def test_spend_points_insufficient(self):
        # Reset side effect: Current balance is 10
        self.cursor.fetchone.side_effect = [(10,)]

        result = await self.module.service.spend_points("user1", 50)

        self.assertFalse(result['success'])
        self.assertEqual(result['error'], "Insufficient points")

if __name__ == '__main__':
    unittest.main()
