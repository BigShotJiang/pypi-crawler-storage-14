
import unittest
import asyncio
from unittest.mock import MagicMock
from decentralized_modules.core.bootstrap_module import BootstrapModule, BootstrapConfig, BootstrapState

class TestBootstrapModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.session.context = MagicMock()
        # Mock TorrentModule for integration check
        self.mock_torrent = MagicMock()
        self.mock_torrent.torrent_engine = MagicMock()
        # Simulate that TorrentModule does NOT have lt_session to force Default engine in test
        # (Or we can test LibTorrentBootstrapEngine if we mock it properly)
        del self.mock_torrent.torrent_engine.lt_session

        self.session.get_module.return_value = self.mock_torrent

        self.module = BootstrapModule()
        await self.module.initialize(self.session)

    async def test_add_remove_node(self):
        host = "1.2.3.4"
        port = 1234
        pubkey = "key"

        success = await self.module.add_bootstrap_node(host, port, pubkey)
        self.assertTrue(success)

        nodes = await self.module.get_bootstrap_nodes()
        self.assertEqual(len(nodes), 1)
        self.assertEqual(nodes[0].host, host)

        node_id = nodes[0].node_id
        success = await self.module.remove_bootstrap_node(node_id)
        self.assertTrue(success)

        nodes = await self.module.get_bootstrap_nodes()
        self.assertEqual(len(nodes), 0)

    async def test_bootstrap_flow(self):
        # Add a node so bootstrap has something to connect to
        await self.module.add_bootstrap_node("127.0.0.1", 8080, "pk")

        success = await self.module.bootstrap()
        self.assertTrue(success)

        stats = await self.module.get_network_stats()
        # In mock engine, it might transition to READY or CONNECTED
        self.assertIn(stats['state'], [BootstrapState.CONNECTED.value, BootstrapState.READY.value])

if __name__ == '__main__':
    unittest.main()
