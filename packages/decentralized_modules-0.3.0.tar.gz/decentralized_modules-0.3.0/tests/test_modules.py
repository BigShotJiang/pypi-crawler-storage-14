# decentralized-modules/tests/test_modules.py
"""
Decentralized Modules 测试套件
"""

def test_import_modules():
    """测试模块导入功能"""
    try:
        from decentralized_modules.core.points_core_module import PointsCoreModule
        from decentralized_modules.foundation.configuration_module import ConfigurationModule
        from decentralized_modules.interfaces import IModule
        
        print("✓ 模块导入成功")
        
        # 测试模块实例化
        points_module = PointsCoreModule()
        config_module = ConfigurationModule()
        
        print(f"✓ 模块实例化成功: {points_module.name}, {config_module.name}")
        
        assert isinstance(points_module, IModule)
        assert isinstance(config_module, IModule)
        
        print("✓ 模块类型验证通过")
        
        return True
    except ImportError as e:
        print(f"✗ 模块导入失败: {e}")
        return False
    except Exception as e:
        print(f"✗ 测试执行失败: {e}")
        return False

if __name__ == "__main__":
    success = test_import_modules()
    if success:
        print("\n所有测试通过！")
    else:
        print("\n测试失败！")
        exit(1)