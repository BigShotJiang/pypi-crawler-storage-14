
import unittest
import asyncio
import os
import json
from unittest.mock import MagicMock
from decentralized_modules.foundation.configuration_module import ConfigurationModule

class TestConfigurationModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.test_config_path = "test_config.json"
        # Ensure clean state
        if os.path.exists(self.test_config_path):
            os.remove(self.test_config_path)

        self.module = ConfigurationModule(self.test_config_path)
        await self.module.initialize(self.session)

    async def asyncTearDown(self):
        await self.module.shutdown()
        if os.path.exists(self.test_config_path):
            os.remove(self.test_config_path)

    async def test_set_get(self):
        service = self.module.service

        service.set("app.debug", True)
        value = service.get("app.debug")
        self.assertTrue(value)

        # Test default
        value = service.get("non.existent", "default")
        self.assertEqual(value, "default")

    async def test_persistence(self):
        service = self.module.service
        service.set("network.port", 9000)
        await service.save()

        # Verify file exists
        self.assertTrue(os.path.exists(self.test_config_path))

        # Read back manually
        with open(self.test_config_path, 'r') as f:
            data = json.load(f)
            self.assertEqual(data['network']['port'], 9000)

if __name__ == '__main__':
    unittest.main()
