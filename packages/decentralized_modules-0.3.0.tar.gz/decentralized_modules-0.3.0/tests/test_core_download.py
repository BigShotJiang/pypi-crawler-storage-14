
import unittest
import asyncio
from unittest.mock import MagicMock
from decentralized_modules.core.download_module import DownloadModule, DownloadConfig, DownloadState

class TestDownloadModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.session.context = MagicMock()
        self.module = DownloadModule()
        await self.module.initialize(self.session)

    async def test_add_download(self):
        data = b"video_data"
        config = DownloadConfig(save_path="./", max_upload_rate=0, max_download_rate=0, max_connections=50, prioritize_first_last_piece=True, sequential_download=False)

        dl_id = await self.module.add_download(data, config)
        self.assertIsNotNone(dl_id)
        self.assertTrue(dl_id.startswith("download_"))

        info = await self.module.get_download_info(dl_id)
        self.assertEqual(info.download_id, dl_id)
        self.assertEqual(info.state, DownloadState.QUEUED)

    async def test_download_state_transitions(self):
        dl_id = await self.module.add_download(b"data")

        # Start
        await self.module.start_download(dl_id)
        info = await self.module.get_download_info(dl_id)
        self.assertEqual(info.state, DownloadState.DOWNLOADING)

        # Pause
        await self.module.pause_download(dl_id)
        info = await self.module.get_download_info(dl_id)
        self.assertEqual(info.state, DownloadState.PAUSED)

        # Resume
        await self.module.resume_download(dl_id)
        info = await self.module.get_download_info(dl_id)
        self.assertEqual(info.state, DownloadState.DOWNLOADING)

        # Stop
        await self.module.stop_download(dl_id)
        info = await self.module.get_download_info(dl_id)
        self.assertEqual(info.state, DownloadState.STOPPED)

    async def test_remove_download(self):
        dl_id = await self.module.add_download(b"data")

        success = await self.module.remove_download(dl_id)
        self.assertTrue(success)

        info = await self.module.get_download_info(dl_id)
        self.assertIsNone(info)

if __name__ == '__main__':
    unittest.main()
