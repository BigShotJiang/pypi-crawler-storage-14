
import unittest
import asyncio
import time
from unittest.mock import MagicMock
from decentralized_modules.foundation.cache_management_module import CacheManagementModule

class TestCacheManagementModule(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.session = MagicMock()
        self.module = CacheManagementModule()
        await self.module.initialize(self.session)

    async def test_set_get(self):
        cache = self.module.service
        cache.set("key1", "value1")
        self.assertEqual(cache.get("key1"), "value1")
        self.assertIsNone(cache.get("nonexistent"))

    async def test_expiry(self):
        cache = self.module.service
        cache.set("key_exp", "val", ttl=0.1)

        # Should exist initially
        self.assertEqual(cache.get("key_exp"), "val")

        # Wait for expiry
        await asyncio.sleep(0.2)

        # Should be gone (get returns default)
        self.assertIsNone(cache.get("key_exp"))

    async def test_clear_expired(self):
        cache = self.module.service
        cache.set("k1", "v1", ttl=0.1)
        cache.set("k2", "v2", ttl=10)

        await asyncio.sleep(0.2)

        count = cache.clear_expired()
        self.assertEqual(count, 1) # k1 cleared
        self.assertIsNone(cache.get("k1"))
        self.assertEqual(cache.get("k2"), "v2")

if __name__ == '__main__':
    unittest.main()
