"""Version information for pydantic-ai-guardrails."""

__version__ = "0.2.0"
