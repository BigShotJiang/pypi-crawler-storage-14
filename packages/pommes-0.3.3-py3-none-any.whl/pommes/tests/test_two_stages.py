"""Module to test the twos tage optimisation."""

import numpy as np
import xarray as xr

from pommes.model.build_model import build_model
from pommes.solver.two_stages import add_second_stage_constraints
from pommes.utils import assert_sol_value


def test_two_stages_two_horizons_conversion(parameters_simple_conversion):
    p = parameters_simple_conversion.copy()

    # First stage scenario
    p["load_shedding_max_capacity"] = np.nan
    p["load_shedding_cost"] = 25  # €/Mwh
    p["conversion_must_run"][0] = 0

    # First stage model
    model1 = build_model(p)
    model1.solve(solver_name="highs")
    s1 = model1.solution.squeeze()

    assert_sol_value(s1, "operation_load_shedding_power", [0, 0])
    assert_sol_value(s1, "operation_conversion_power", [10, 10])
    assert_sol_value(s1, "operation_conversion_power_capacity", [20, 20])
    assert_sol_value(s1, "planning_conversion_costs", [200.0, 200.0])
    assert model1.objective.value == 200 * 2

    # Second stage scenario
    p["load_shedding_cost"] = (
        p["load_shedding_cost"].broadcast_like(p.year_op).copy()
    )
    p["load_shedding_cost"][1] = 1  # €/Mwh
    p["conversion_variable_cost"] = (
        p["conversion_variable_cost"].broadcast_like(p.year_op).copy()
    )
    p["conversion_variable_cost"][1] = 30  # €/Mwh

    # No non-anticipativity constraint
    model2 = build_model(p)
    model2.solve(solver_name="highs")
    s2 = model2.solution.squeeze()

    assert_sol_value(s2, "operation_load_shedding_power", [10, 10])
    assert_sol_value(s2, "operation_conversion_power", [0, 0])
    assert_sol_value(s2, "operation_conversion_power_capacity", [0, 0])
    assert_sol_value(s2, "planning_conversion_costs", [0, 0])
    assert model2.objective.value == 25 * 10 + 1 * 10

    # With non-anticipativity constraint
    horizon = 2040
    model3 = build_model(p)
    add_second_stage_constraints(model3, s1, p, horizon)
    model3.solve(solver_name="highs")
    s3 = model3.solution.squeeze()

    assert_sol_value(s3, "operation_load_shedding_power", [0, 10])
    assert_sol_value(s3, "operation_conversion_power", [10, 0])
    assert_sol_value(s3, "operation_conversion_power_capacity", [20, 20])
    assert_sol_value(s3, "planning_conversion_costs", [200.0, 200.0])
    assert model3.objective.value == 200 * 2 + 10 * 1


def test_two_stages_two_horizons_early_decommissioning_conversion(
    parameters_simple_conversion,
):
    p = parameters_simple_conversion.copy()

    # First stage scenario
    p["load_shedding_max_capacity"] = np.nan
    p["load_shedding_cost"] = 50  # €/Mwh
    p["conversion_must_run"][0] = 0.0
    p["conversion_early_decommissioning"] = True
    p["conversion_annuity_perfect_foresight"] = True
    p["conversion_annuity_cost"][0] = [[18, np.nan], [10, 18], [np.nan, 10]]

    # First stage model
    model1 = build_model(p)
    model1.solve(solver_name="highs")
    s1 = model1.solution.squeeze()

    assert_sol_value(s1, "operation_load_shedding_power", [0, 0])
    assert_sol_value(s1, "operation_conversion_power", [10, 10])
    assert_sol_value(s1, "operation_conversion_power_capacity", [20, 20])
    assert_sol_value(s1, "planning_conversion_costs", [200.0, 200.0])
    assert model1.objective.value == 200 * 2

    # Second stage scenario
    p["load_shedding_cost"] = (
        p["load_shedding_cost"].broadcast_like(p.year_op).copy()
    )
    p["load_shedding_cost"][1] = 1  # €/Mwh

    # No non-anticipativity constraint
    model2 = build_model(p)
    model2.solve(solver_name="highs")
    s2 = model2.solution.squeeze()

    assert_sol_value(s2, "operation_load_shedding_power", [0, 10])
    assert_sol_value(s2, "operation_conversion_power", [10, 0])
    assert_sol_value(s2, "operation_conversion_power_capacity", [20, 0])
    assert_sol_value(s2, "planning_conversion_costs", [360, 0])
    assert model2.objective.value == 360 + 10

    # With non-anticipativity constraint
    horizon = 2040
    model3 = build_model(p)
    add_second_stage_constraints(model3, s1, p, horizon)
    model3.solve(solver_name="highs")
    s3 = model3.solution.squeeze()

    assert_sol_value(s3, "operation_load_shedding_power", [0, 0])
    assert_sol_value(s3, "operation_conversion_power", [10, 10])
    assert_sol_value(s3, "operation_conversion_power_capacity", [20, 20])
    assert_sol_value(s3, "planning_conversion_costs", [200.0, 200.0])
    assert model3.objective.value == 200 * 2


def test_two_stages_two_horizons_storage(parameters_simple_storage):
    p = parameters_simple_storage.copy()

    # First stage scenario
    p["load_shedding_max_capacity"] = np.nan
    p["load_shedding_cost"] = xr.DataArray(1).broadcast_like(p.hour).copy()
    p["load_shedding_cost"][1] = 10
    p["load_shedding_cost"] = (
        p["load_shedding_cost"].broadcast_like(p.year_op).copy()
    )
    p["demand"] = 1
    p["storage_factor_in"][0][0] = -2
    p["storage_annuity_cost_energy"][0] = [[7, np.nan], [4, 7], [np.nan, 4]]
    p["storage_annuity_cost_power"][0] = [[5, np.nan], [3, 5], [np.nan, 3]]

    # First stage model
    model1 = build_model(p)
    model1.solve(solver_name="highs")
    s1 = model1.solution.squeeze()

    assert_sol_value(s1, "operation_load_shedding_power", [[3, 3], [0, 0]])
    assert_sol_value(s1, "operation_storage_power_in", [[1, 1], [0, 0]])
    assert_sol_value(s1, "operation_storage_power_out", [[0, 0], [1, 1]])
    assert_sol_value(s1, "operation_storage_level", [[1, 1], [0, 0]])
    assert_sol_value(s1, "operation_storage_power_capacity", [1, 1])
    assert_sol_value(s1, "operation_storage_energy_capacity", [1, 1])
    assert_sol_value(s1, "planning_storage_costs", [7, 7])
    assert model1.objective.value == 7 * 2 + 1 * 3 * 2

    # Second stage scenario
    p["load_shedding_cost"][1][0] = 10

    # No non-anticipativity constraint
    model2 = build_model(p)
    model2.solve(solver_name="highs")
    s2 = model2.solution.squeeze()

    assert_sol_value(s2, "operation_load_shedding_power", [[1, 1], [1, 1]])
    assert_sol_value(s2, "operation_storage_power_in", [[0, 0], [0, 0]])
    assert_sol_value(s2, "operation_storage_power_out", [[0, 0], [0, 0]])
    assert_sol_value(s2, "operation_storage_level", [[0, 0], [0, 0]])
    assert_sol_value(s2, "operation_storage_power_capacity", [0, 0])
    assert_sol_value(s2, "operation_storage_energy_capacity", [0, 0])
    assert_sol_value(s2, "planning_storage_costs", [0, 0])
    assert model2.objective.value == 1 + 10 + 10 * 2

    # With non-anticipativity constraint
    horizon = 2040
    model3 = build_model(p)
    add_second_stage_constraints(model3, s1, p, horizon)
    model3.solve(solver_name="highs")
    s3 = model3.solution.squeeze()

    assert_sol_value(s3, "operation_load_shedding_power", [[3, 1], [0, 1]])
    assert_sol_value(s3, "operation_storage_power_in", [[1, 0], [0, 0]])
    assert_sol_value(s3, "operation_storage_power_out", [[0, 0], [1, 0]])
    assert_sol_value(s3, "operation_storage_level", [[1, 0], [0, 0]])
    assert_sol_value(s3, "operation_storage_power_capacity", [1, 1])
    assert_sol_value(s3, "operation_storage_energy_capacity", [1, 1])
    assert_sol_value(s3, "planning_storage_costs", [7, 7])
    assert model3.objective.value == 14 + 3 + 10 * 2


def test_two_stages_two_horizons_early_decommissioning_storage(
    parameters_simple_storage,
):
    p = parameters_simple_storage.copy()

    # First stage scenario
    p["load_shedding_max_capacity"] = np.nan
    p["load_shedding_cost"] = xr.DataArray(1).broadcast_like(p.hour).copy()
    p["load_shedding_cost"][1] = 10
    p["load_shedding_cost"] = (
        p["load_shedding_cost"].broadcast_like(p.year_op).copy()
    )
    p["demand"] = 1
    p["storage_factor_in"][0][0] = -1.5
    p["storage_annuity_cost_energy"][0] = [
        [4.5, np.nan],
        [4, 4.5],
        [np.nan, 4],
    ]
    p["storage_annuity_cost_power"][0] = [[3.5, np.nan], [3, 3.5], [np.nan, 3]]
    p["storage_early_decommissioning"] = True
    p["storage_annuity_perfect_foresight"] = True

    # First stage model
    model1 = build_model(p)
    model1.solve(solver_name="highs")
    s1 = model1.solution.squeeze()

    assert_sol_value(s1, "operation_load_shedding_power", [[2.5, 2.5], [0, 0]])
    assert_sol_value(s1, "operation_storage_power_in", [[1, 1], [0, 0]])
    assert_sol_value(s1, "operation_storage_power_out", [[0, 0], [1, 1]])
    assert_sol_value(s1, "operation_storage_level", [[1, 1], [0, 0]])
    assert_sol_value(s1, "operation_storage_power_capacity", [1, 1])
    assert_sol_value(s1, "operation_storage_energy_capacity", [1, 1])
    assert_sol_value(s1, "planning_storage_costs", [7, 7])
    assert model1.objective.value == 7 * 2 + 1 * 2.5 * 2

    # Second stage scenario
    p["load_shedding_cost"][1][0] = 10

    # No non-anticipativity constraint
    model2 = build_model(p)
    model2.solve(solver_name="highs")
    s2 = model2.solution.squeeze()

    assert_sol_value(s2, "operation_load_shedding_power", [[2.5, 1], [0, 1]])
    assert_sol_value(s2, "operation_storage_power_in", [[1, 0], [0, 0]])
    assert_sol_value(s2, "operation_storage_power_out", [[0, 0], [1, 0]])
    assert_sol_value(s2, "operation_storage_level", [[1, 0], [0, 0]])
    assert_sol_value(s2, "operation_storage_power_capacity", [1, 0])
    assert_sol_value(s2, "operation_storage_energy_capacity", [1, 0])
    assert_sol_value(s2, "planning_storage_costs", [8, 0])
    assert model2.objective.value == 8 + 1 * 2.5 + 10 * 2

    # With non-anticipativity constraint
    horizon = 2040
    model3 = build_model(p)
    add_second_stage_constraints(model3, s1, p, horizon)
    model3.solve(solver_name="highs")
    s3 = model3.solution.squeeze()

    assert_sol_value(s3, "operation_load_shedding_power", [[2.5, 1], [0, 1]])
    assert_sol_value(s3, "operation_storage_power_in", [[1, 0], [0, 0]])
    assert_sol_value(s3, "operation_storage_power_out", [[0, 0], [1, 0]])
    assert_sol_value(s3, "operation_storage_level", [[1, 0], [0, 0]])
    assert_sol_value(s3, "operation_storage_power_capacity", [1, 1])
    assert_sol_value(s3, "operation_storage_energy_capacity", [1, 1])
    assert_sol_value(s3, "planning_storage_costs", [7, 7])
    assert model3.objective.value == 14 + 2.5 + 10 * 2
