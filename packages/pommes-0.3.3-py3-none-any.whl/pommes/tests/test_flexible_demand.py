"""Module to test flexible demand."""

import numpy as np

from pommes.model.build_model import build_model


def test_flexible_demand_single_horizon(parameters_simple_flexible_demand):
    p = parameters_simple_flexible_demand
    p = p.sel(
        conversion_tech=["wind_onshore"],
        resource=["electricity"],
        hour=[4, 5, 6, 7, 8, 9],
    )

    model = build_model(p)
    model.solve(solver_name="highs")
    s = model.solution.squeeze()

    np.testing.assert_array_equal(
        s.planning_conversion_power_capacity.to_numpy(), np.array([90.0])
    )
    np.testing.assert_array_equal(
        s.operation_conversion_power.to_numpy(),
        np.array([18.0, 36.0, 72.0, 81.0, 54.0, 27.0]),
    )

    np.testing.assert_array_equal(
        s.operation_flexibility_demand.to_numpy(),
        np.array([8.0, 12.0, 10.0, 10.0, 10.0, 10.0]),
    )

    np.testing.assert_array_equal(
        s.operation_flexibility_displaced_demand.to_numpy(),
        np.array([2.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
    )

    assert model.objective.value == 929.2
