#!/usr/bin/env python3
"""
Example: CT Augmentation (1:1)

Augment existing CT scans with standard transformations.

⚠️ IMPORTANT: This mode does NOT provide privacy protection!
- Retains original voxel intensity patterns
- High mutual information with original data
- Should only be used for data augmentation when privacy is not a concern
- Not suitable for data sharing under HIPAA/GDPR

Use privacy-preserving synthesis mode for data sharing.
"""

from medsynth.config import Config
from medsynth.pipeline import SyntheticCTPipeline


def main():
    # Configure augmentation mode
    config = Config(
        num_subjects=5,              # Generate 5 augmented versions
        random_seed=42,
        digital_twin_mode=False,     # Standard augmentation (NO privacy protection)
        augmentation_input="./path/to/real/ct/",  # Real CT input
        output_root="./output/augmented"
    )

    # Configure output
    config.output.generate_dicom = True
    config.output.generate_nrrd = False
    config.output.generate_omop = False

    # Generate augmented dataset
    print("⚠️  WARNING: Augmentation mode does NOT provide privacy protection!")
    print("   Only use for data augmentation when privacy is not a concern.\n")

    print("Generating augmented CT scans...")
    pipeline = SyntheticCTPipeline(config)
    pipeline.generate_dataset()

    print(f"\nDone! Generated {config.num_subjects} augmented versions")
    print(f"Output directory: {config.output.output_root}")
    print("\n⚠️  PRIVACY WARNING:")
    print("   - These images retain original intensity patterns")
    print("   - High mutual information with source data")
    print("   - NOT suitable for public sharing")
    print("   - Use privacy-preserving synthesis mode for data sharing")


if __name__ == "__main__":
    main()
