#!/usr/bin/env python3
"""
Example: Privacy-Synthesis

This example shows how to create privacy-protected synthetic versions from real CT scans.
The privacy-synthesis mode uses Multi-Scale Statistical Texture Synthesis (MS-STS)
to reduce mutual information while preserving diagnostic utility.

Privacy Note:
- This provides empirical privacy protection, not cryptographic guarantees
- Aims to reduce mutual information below 1.8 bits
- Should be combined with other de-identification methods
- Validation recommended for your specific use case
"""

from pathlib import Path
from medsynth.config import Config
from medsynth.pipeline import SyntheticCTPipeline


def main():
    # Configure privacy-synthesis
    config = Config(
        # Number of synthetic versions to generate
        num_subjects=5,

        # Random seed for reproducibility
        random_seed=42,

        # Enable privacy-synthesis mode
        privacy_synth_mode=True,

        # Path to real CT scan (DICOM directory or NRRD file)
        augmentation_input="./path/to/real/ct/",

        # Output directory
        output_root="./output/privacy_synthesis"
    )

    # Configure output formats
    config.output.generate_dicom = True
    config.output.generate_nrrd = True
    config.output.generate_omop = False

    # Optional: Customize MS-STS parameters (uses optimized defaults)
    # config.volume.privacy_synth_freq_cutoff = 0.5456
    # config.volume.privacy_synth_psf_blur_sigma = 0.40
    # config.volume.privacy_synth_texture_noise_std = 5.5449
    # config.volume.privacy_synth_edge_enhancement_strength = 0.25

    # Generate synthetic dataset
    print("Generating privacy-synthesis versions...")
    print("\nMethod: Multi-Scale Statistical Texture Synthesis (MS-STS)")
    print("Expected privacy: MI < 1.8 bits (empirical)")
    print()

    pipeline = SyntheticCTPipeline(config)
    pipeline.generate_dataset()

    print(f"\nDone! Output saved to: {config.output.output_root}")
    print("\nPrivacy considerations:")
    print("  - All voxel intensities undergo statistical transformation")
    print("  - Mutual information typically < 1.8 bits (empirical)")
    print("  - Not cryptographic - should combine with other de-identification")
    print("  - Validate for your specific use case and regulatory requirements")


if __name__ == "__main__":
    main()
