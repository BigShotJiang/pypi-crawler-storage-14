#!/usr/bin/env python3
"""
Example: Pure Synthetic CT Generation

Generate CT scans completely from scratch without any real data input.
Useful for algorithm development, testing, and research.
"""

from medsynth.config import Config, VolumeConfig, AnatomicalFeaturesConfig
from medsynth.pipeline import SyntheticCTPipeline


def main():
    # Configure pure synthetic generation
    config = Config(
        num_subjects=10,
        random_seed=42,
        digital_twin_mode=False,  # Pure synthetic mode
        augmentation_input=None,  # No input data
        output_root="./output/pure_synthetic"
    )

    # Customize volume properties
    config.volume = VolumeConfig(
        volume_shape=(178, 512, 512),  # (Z, Y, X)
        spacing=(5.0, 0.976, 0.976),   # (dz, dy, dx) in mm
        hu_range=(-1024, 3071),
    )

    # Configure anatomical features
    config.volume.features = AnatomicalFeaturesConfig(
        nodules_config={
            'num_nodules': (2, 5),      # 2-5 nodules per volume
            'diameter_mm': (5, 20),     # 5-20mm diameter
            'spiculation': 0.3,         # 30% spiculated
        },
        emphysema_severity=0.2,         # 20% emphysema
        consolidation_presence=0.1,     # 10% consolidation
    )

    # Configure output formats
    config.output.generate_dicom = True
    config.output.generate_nrrd = True
    config.output.generate_omop = True

    # Generate synthetic dataset
    print("Generating pure synthetic CT scans...")
    pipeline = SyntheticCTPipeline(config)
    pipeline.generate_dataset()

    print(f"\nDone! Generated {config.num_subjects} synthetic CT volumes")
    print(f"Output directory: {config.output.output_root}")


if __name__ == "__main__":
    main()
