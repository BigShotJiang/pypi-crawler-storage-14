"""
Setup script for medsynth package.

For modern Python packaging, prefer using pyproject.toml.
This file is kept for backward compatibility.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
