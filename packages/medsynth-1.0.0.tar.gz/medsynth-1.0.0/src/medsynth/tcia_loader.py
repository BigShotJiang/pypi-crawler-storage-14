"""
TCIA CT Loader - Load and preprocess real CT data from TCIA collections.
Returns arrays in (Z, Y, X) and spacing in (dz, dy, dx).
"""
from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import math
import logging
import numpy as np
import pydicom
import SimpleITK as sitk

logger = logging.getLogger("tcia_ct_loader")
logger.setLevel(logging.INFO)

# ---- helpers -----------------------------------------------------------------

def _read_meta(path: Path) -> Optional[pydicom.dataset.FileDataset]:
    try:
        return pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    except Exception:
        return None

def _series_key(ds: pydicom.dataset.FileDataset) -> Optional[Tuple[str, Optional[str]]]:
    sid = getattr(ds, "SeriesInstanceUID", None)
    fref = getattr(ds, "FrameOfReferenceUID", None)
    return (sid, fref) if sid else None

def _is_enhanced_multiframe(ds: pydicom.dataset.FileDataset) -> bool:
    return bool(getattr(ds, "PerFrameFunctionalGroupsSequence", None))

def _compute_slice_normal(ds: pydicom.dataset.FileDataset) -> Optional[Tuple[float, float, float]]:
    iop = getattr(ds, "ImageOrientationPatient", None)
    if not iop or len(iop) != 6:
        return None
    xr, yr, zr, xc, yc, zc = map(float, iop)
    nx = yr * zc - zr * yc
    ny = zr * xc - xr * zc
    nz = xr * yc - yr * xc
    norm = math.sqrt(nx*nx + ny*ny + nz*nz) or 1.0
    return (nx / norm, ny / norm, nz / norm)

def _median_dz(metas: List[pydicom.dataset.FileDataset],
               normal: Optional[Tuple[float, float, float]]) -> Optional[float]:
    if normal is None or len(metas) < 2:
        return None
    vals: List[float] = []
    for i in range(len(metas) - 1):
        ipp0 = getattr(metas[i],   "ImagePositionPatient", None)
        ipp1 = getattr(metas[i+1], "ImagePositionPatient", None)
        if ipp0 is None or ipp1 is None:
            continue
        d = ( (ipp1[0]-ipp0[0]) * normal[0] +
              (ipp1[1]-ipp0[1]) * normal[1] +
              (ipp1[2]-ipp0[2]) * normal[2] )
        vals.append(abs(float(d)))
    if not vals:
        return None
    return float(np.median(vals))

def _pixel_spacing(ds: pydicom.dataset.FileDataset) -> Tuple[float, float]:
    ps = getattr(ds, "PixelSpacing", [1.0, 1.0])
    if len(ps) != 2:
        return (1.0, 1.0)
    return (float(ps[0]), float(ps[1]))  # (dy, dx)

# ---- core API ----------------------------------------------------------------

def find_ct_series(root: Path) -> Tuple[str, List[Path]]:
    """
    Recursively scan `root`, group DICOM files by SeriesInstanceUID(+FORUID),
    keep CT only, and return the most populous axial stack.
    """
    root = Path(root)
    if not root.exists():
        raise FileNotFoundError(f"Root not found: {root}")

    dcm_files = [p for p in root.rglob("*") if p.is_file() and (p.suffix.lower() in (".dcm", "") or p.name.isdigit())]
    if not dcm_files:
        raise RuntimeError(f"No DICOM-like files under: {root}")

    groups: Dict[Tuple[str, Optional[str]], List[Path]] = {}
    enhanced_singletons: List[Path] = []

    for f in dcm_files:
        if f.name == ".DS_Store":
            continue
        ds = _read_meta(f)
        if ds is None or getattr(ds, "Modality", None) != "CT":
            continue
        if _is_enhanced_multiframe(ds):
            enhanced_singletons.append(f)
            continue
        key = _series_key(ds)
        if key:
            groups.setdefault(key, []).append(f)

    if groups:
        (sid, _), files = max(groups.items(), key=lambda kv: len(kv[1]))
        logger.info(f"Selected CT series (single-frame): {sid} with {len(files)} files")
        return sid, files

    if enhanced_singletons:
        ds0 = _read_meta(enhanced_singletons[0])
        sid = getattr(ds0, "SeriesInstanceUID", "ENHANCED_CT")
        logger.info(f"Selected Enhanced CT (multiframe): {sid} file={enhanced_singletons[0]}")
        return sid, [enhanced_singletons[0]]

    raise RuntimeError("Found DICOMs but no CT series (perhaps only SEG/RTSTRUCT present).")

def load_ct_series(files_or_single: List[Path]) -> Tuple[sitk.Image, Tuple[float, float, float]]:
    """
    Load a CT series (single-frame list or one enhanced multiframe) with robust sorting.
    Returns (SimpleITK Image, spacing as (dz, dy, dx) in mm).
    """
    # Enhanced multiframe
    if len(files_or_single) == 1:
        img = sitk.ReadImage(str(files_or_single[0]))
        sx, sy, sz = img.GetSpacing()  # (X,Y,Z)
        return img, (float(sz), float(sy), float(sx))

    # Single-frame stack
    metas: List[Tuple[Path, pydicom.dataset.FileDataset]] = []
    for p in files_or_single:
        ds = _read_meta(p)
        if ds is not None:
            metas.append((p, ds))
    if not metas:
        raise RuntimeError("No readable DICOM headers in provided files.")

    normal = _compute_slice_normal(metas[0][1])

    # Deduplicate by SOPInstanceUID
    seen = set()
    pairs: List[Tuple[Path, pydicom.dataset.FileDataset]] = []
    for p, ds in metas:
        sop = getattr(ds, "SOPInstanceUID", None)
        if sop and sop in seen:
            continue
        seen.add(sop)
        pairs.append((p, ds))

    # Sort by projection along the normal; fallback InstanceNumber
    def sort_key(ds: pydicom.dataset.FileDataset) -> float:
        ipp = getattr(ds, "ImagePositionPatient", None)
        if ipp is not None and normal is not None:
            return float(ipp[0]*normal[0] + ipp[1]*normal[1] + ipp[2]*normal[2])
        return float(getattr(ds, "InstanceNumber", 0))

    pairs_sorted = sorted(pairs, key=lambda t: sort_key(t[1]))
    files_sorted = [str(p) for p, _ in pairs_sorted]

    reader = sitk.ImageSeriesReader()
    reader.SetFileNames(files_sorted)
    img = reader.Execute()

    # Spacing: ITK gives (sx, sy, sz); prefer geometry-derived dz (median)
    sx, sy, sz = img.GetSpacing()
    dz_est = _median_dz([ds for _, ds in pairs_sorted], normal)
    dz = float(dz_est) if dz_est is not None else float(sz)
    return img, (dz, float(sy), float(sx))

# Convenience: load as numpy with HU int16, (Z,Y,X)
def load_ct_array_and_spacing(root_or_files: Path | List[Path]) -> Tuple[np.ndarray, Tuple[float, float, float]]:
    if isinstance(root_or_files, list):
        img, spacing = load_ct_series(root_or_files)
    else:
        root_or_files = Path(root_or_files)
        if root_or_files.is_dir():
            sid, files = find_ct_series(root_or_files)
            img, spacing = load_ct_series(files)
        else:
            img = sitk.ReadImage(str(root_or_files))
            sx, sy, sz = img.GetSpacing()
            spacing = (float(sz), float(sy), float(sx))
    arr = sitk.GetArrayFromImage(img).astype(np.float32)  # HU w/ rescale applied by GDCM
    # clamp & cast to int16 typical CT range
    arr = np.clip(arr, -1024, 3071).astype(np.int16)
    return np.ascontiguousarray(arr), spacing

# ---- example CLI -------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(format="%(levelname)s: %(message)s", level=logging.INFO)
    ROOT = Path("~/Documents/Github/NSCLC_Radiomics").expanduser()
    sid, files = find_ct_series(ROOT)
    img, spacing = load_ct_series(files)
    arr = sitk.GetArrayFromImage(img)  # (Z, Y, X)
    print(f"Loaded CT: {sid}")
    print(f"Shape: {arr.shape}  Spacing (dz,dy,dx): {spacing}")
