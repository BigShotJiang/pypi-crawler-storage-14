from __future__ import annotations

import math
from typing import Tuple, Optional, List, Dict, Any

import numpy as np
from scipy import ndimage
from scipy.fft import dctn, idctn
from scipy.stats import moment, entropy

from .config import VolumeConfig


# ===========================
# Axis / dtype helpers
# ===========================

def _rng(seed: Optional[int]):
    return np.random.default_rng(seed)


def as_zyx(arr: np.ndarray) -> np.ndarray:
    """
    Research-oriented orientation helper.

    In this project we adopt a *strict contract*:
    - Volumes are represented as (Z, Y, X).
    - All I/O code (_load_real_ct_any, NRRDExporter, DICOMExporter, etc.)
      is responsible for enforcing this convention.

    Therefore, this function is intentionally conservative and **never**
    silently reorders axes based on brittle shape heuristics. It only performs
    validation and returns the input unchanged.

    Rationale:
    - Axis guessing breaks reproducibility and can corrupt geometry
      (e.g. 178×512×512 CT becoming 512×178×512).
    - For research, it's better to fail loudly and push orientation handling
      to loader-specific code where metadata is available.

    If you truly have a (Y, X, Z) or (X, Y, Z) volume, reorient it explicitly
    in your calling code, e.g.:

        vol_zyx = np.moveaxis(vol_yxz, -1, 0)

    or

        vol_zyx = vol_xyz.transpose(2, 1, 0)
    """
    if arr.ndim != 3:
        raise ValueError(f"Expected 3D array (Z,Y,X), got shape={arr.shape}")
    return arr


def finalize_for_viewer(vol_zyx: np.ndarray, mask_zyx: Optional[np.ndarray] = None):
    """
    Clamp HU range and convert to viewer-friendly dtypes.
    """
    vol_zyx = np.clip(vol_zyx, -1000, 3071).astype(np.int16)
    if mask_zyx is not None:
        mask_zyx = (mask_zyx > 0).astype(np.int8)
        return vol_zyx, mask_zyx
    return vol_zyx


# ===========================
# Geometry utilities
# ===========================

def _ellipsoid_mask_at(center_zyx: np.ndarray,
                       radii_mm_zyx: Tuple[float, float, float],
                       spacing_zyx: Tuple[float, float, float],
                       vol_shape_zyx: Tuple[int, int, int]) -> np.ndarray:
    (cz, cy, cx) = center_zyx.astype(float)
    (dz, dy, dx) = spacing_zyx
    rz, ry, rx = (
        radii_mm_zyx[0] / dz,
        radii_mm_zyx[1] / dy,
        radii_mm_zyx[2] / dx,
    )

    z0 = max(int(math.floor(cz - rz)) - 1, 0)
    z1 = min(int(math.ceil(cz + rz)) + 1, vol_shape_zyx[0])
    y0 = max(int(math.floor(cy - ry)) - 1, 0)
    y1 = min(int(math.ceil(cy + ry)) + 1, vol_shape_zyx[1])
    x0 = max(int(math.floor(cx - rx)) - 1, 0)
    x1 = min(int(math.ceil(cx + rx)) + 1, vol_shape_zyx[2])

    if z0 >= z1 or y0 >= y1 or x0 >= x1:
        return np.zeros(vol_shape_zyx, dtype=bool)

    zz, yy, xx = np.ogrid[z0:z1, y0:y1, x0:x1]
    ez = (zz - cz) / (rz + 1e-6)
    ey = (yy - cy) / (ry + 1e-6)
    ex = (xx - cx) / (rx + 1e-6)
    mask_local = (ez ** 2 + ey ** 2 + ex ** 2) <= 1.0

    mask = np.zeros(vol_shape_zyx, dtype=bool)
    mask[z0:z1, y0:y1, x0:x1] = mask_local
    return mask


def _tube_along_polyline(points: np.ndarray,
                         radius_start_mm: float,
                         radius_end_mm: float,
                         spacing_zyx: Tuple[float, float, float],
                         vol_shape_zyx: Tuple[int, int, int],
                         radial_soft_edge_mm: float = 1.0) -> np.ndarray:
    """
    Soft tubular shape along a polyline in mm-space, rasterized into voxel grid.
    Returns an occupancy field in [0, 1] with soft edges.
    """
    if points is None or len(points) < 2:
        return np.zeros(vol_shape_zyx, dtype=np.float32)

    dz, dy, dx = spacing_zyx
    radii_mm = np.linspace(radius_start_mm, radius_end_mm, max(len(points) - 1, 1))
    max_r_mm = float(np.max(radii_mm)) if len(radii_mm) else radius_start_mm
    max_r_vox = np.array([max_r_mm / dz, max_r_mm / dy, max_r_mm / dx])

    pmin = np.maximum(np.floor(points.min(axis=0) - max_r_vox - 2), 0).astype(int)
    pmax = np.minimum(np.ceil(points.max(axis=0) + max_r_vox + 2),
                      np.array(vol_shape_zyx) - 1).astype(int)

    z = np.arange(pmin[0], pmax[0] + 1)
    y = np.arange(pmin[1], pmax[1] + 1)
    x = np.arange(pmin[2], pmax[2] + 1)
    if len(z) == 0 or len(y) == 0 or len(x) == 0:
        return np.zeros(vol_shape_zyx, dtype=np.float32)

    zz, yy, xx = np.meshgrid(z, y, x, indexing="ij")
    field = np.full((len(z), len(y), len(x)), np.inf, dtype=np.float32)

    zmm = (zz * dz).astype(np.float32)
    ymm = (yy * dy).astype(np.float32)
    xmm = (xx * dx).astype(np.float32)

    pts_mm = points.copy().astype(np.float32)
    pts_mm[:, 0] *= dz
    pts_mm[:, 1] *= dy
    pts_mm[:, 2] *= dx

    for i in range(len(points) - 1):
        p0 = pts_mm[i]
        p1 = pts_mm[i + 1]
        v = p1 - p0
        vv = np.dot(v, v) + 1e-6
        t = ((zmm - p0[0]) * v[0] +
             (ymm - p0[1]) * v[1] +
             (xmm - p0[2]) * v[2]) / vv
        t = np.clip(t, 0.0, 1.0)
        proj_z = p0[0] + t * v[0]
        proj_y = p0[1] + t * v[1]
        proj_x = p0[2] + t * v[2]
        dist_mm = np.sqrt(
            (zmm - proj_z) ** 2 +
            (ymm - proj_y) ** 2 +
            (xmm - proj_x) ** 2
        )

        # linearly taper radius by segment index
        rs = radius_start_mm + (radius_end_mm - radius_start_mm) * (i / max(1, len(points) - 2))
        sdf_mm = dist_mm - rs
        field = np.minimum(field, sdf_mm.astype(np.float32))

    edge = max(1e-3, radial_soft_edge_mm)
    occ = np.clip(0.5 - field / (2.0 * edge), 0.0, 1.0).astype(np.float32)

    tube = np.zeros(vol_shape_zyx, dtype=np.float32)
    tube[pmin[0]:pmax[0] + 1, pmin[1]:pmax[1] + 1, pmin[2]:pmax[2] + 1] = occ
    return tube


def _gaussian_psf_slices(volume: np.ndarray, sigma_px_xy: float) -> np.ndarray:
    """
    Apply in-plane PSF blur slice-wise to approximate scanner MTF.
    """
    if sigma_px_xy <= 0:
        return volume
    out = np.empty_like(volume, dtype=np.float32)
    for k in range(volume.shape[0]):
        out[k] = ndimage.gaussian_filter(volume[k], sigma=sigma_px_xy, mode="nearest")
    return out


def _apply_change_with_budget(
    base: np.ndarray,
    proposal: np.ndarray,
    region_mask: np.ndarray,
    delta_threshold: float = 50.0,
    max_changed_frac: float = 0.05,
    alpha: float = 1.0,
) -> np.ndarray:
    """
    Blend proposal into base within region_mask, but enforce that no more than
    `max_changed_frac` voxels exceed `delta_threshold` HU change.
    """
    assert base.shape == proposal.shape == region_mask.shape
    if not np.any(region_mask):
        return base

    blended = base.copy()
    w = region_mask.astype(np.float32)
    idx = w > 0
    blended[idx] = (1 - alpha * w[idx]) * base[idx] + (alpha * w[idx]) * proposal[idx]

    diff = np.abs(blended - base)
    changed_frac = float((diff >= delta_threshold).sum()) / diff.size

    if changed_frac <= max_changed_frac:
        return blended

    # Binary search on alpha to respect budget
    lo, hi = 0.0, alpha
    for _ in range(12):
        mid = 0.5 * (lo + hi)
        tmp = base.copy()
        tmp[idx] = (1 - mid * w[idx]) * base[idx] + (mid * w[idx]) * proposal[idx]
        diff = np.abs(tmp - base)
        frac = float((diff >= delta_threshold).sum()) / diff.size
        if frac <= max_changed_frac:
            lo = mid
            blended = tmp
        else:
            hi = mid
    return blended


def _add_correlated_texture_noise(volume: np.ndarray, body_mask: np.ndarray, rng, noise_std: float = 8.0) -> np.ndarray:
    """
    Add spatially-correlated high-frequency texture inside the body_mask.
    This reduces the NPS ratio (less over-smooth).
    """
    z, y, x = volume.shape
    noise = rng.normal(0, 1, (z, y, x)).astype(np.float32)
    for k in range(z):
        if np.any(body_mask[k]):
            noise[k] = ndimage.gaussian_filter(noise[k], sigma=0.4)
    tissue_factor = np.clip((volume + 1000) / 2000, 0.2, 1.0)
    volume = volume.copy()
    volume[body_mask] += (noise_std * tissue_factor * noise)[body_mask]
    return volume


# ===========================
# Novel Research-Grade Privacy Sanitization Functions
# Multi-Scale Statistical Texture Synthesis (MS-STS)
# ===========================

def _compute_local_statistics(volume: np.ndarray, mask: np.ndarray, window_size: int = 7) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute local statistical moments in 3D windows for texture characterization.

    This enables preservation of local texture heterogeneity rather than using
    global tissue distributions. Novel contribution for privacy-preserving synthesis.

    Args:
        volume: Input volume (Z,Y,X)
        mask: Binary mask indicating region of interest
        window_size: Size of local 3D window (default 7x7x7)

    Returns:
        Tuple of (local_mean, local_std, local_skewness) arrays
    """
    from scipy.ndimage import uniform_filter

    # Mask values outside ROI
    vol_masked = volume.copy()
    vol_masked[~mask] = 0

    # Local mean via uniform filter
    local_mean = uniform_filter(vol_masked.astype(np.float32), size=window_size, mode='constant')

    # Local variance
    local_mean_sq = uniform_filter((vol_masked ** 2).astype(np.float32), size=window_size, mode='constant')
    local_var = local_mean_sq - local_mean ** 2
    local_var = np.maximum(local_var, 1.0)  # Avoid division by zero
    local_std = np.sqrt(local_var)

    # Local skewness (3rd moment) for asymmetry characterization
    local_centered = vol_masked - local_mean
    local_m3 = uniform_filter((local_centered ** 3).astype(np.float32), size=window_size, mode='constant')
    local_skewness = local_m3 / (local_std ** 3 + 1e-6)

    return local_mean, local_std, local_skewness


def _frequency_domain_privacy_filter(volume: np.ndarray, body_mask: np.ndarray, cutoff_ratio: float = 0.3) -> Tuple[np.ndarray, np.ndarray]:
    """
    Separate volume into low-frequency (anatomy) and high-frequency (patient-specific texture).

    Novel approach: Use DCT (Discrete Cosine Transform) to decompose spatial frequencies.
    - Low frequencies: Preserve anatomical structure
    - High frequencies: Contains patient-specific texture patterns → will be replaced

    This aims to reduce privacy risk by removing high-frequency patient identifiers (empirical approach).

    Args:
        volume: Input CT volume (Z,Y,X)
        body_mask: Body region mask
        cutoff_ratio: Frequency cutoff (0.3 = keep lowest 30% of frequencies)

    Returns:
        Tuple of (low_freq_anatomy, high_freq_texture)
    """
    # Apply DCT to body region only (more efficient)
    vol_body = volume.copy()
    vol_body[~body_mask] = 0

    # 3D DCT
    dct_coeffs = dctn(vol_body, type=2, norm='ortho')

    # Create frequency mask (spherical low-pass filter)
    z, y, x = dct_coeffs.shape
    freq_mask = np.zeros_like(dct_coeffs, dtype=bool)

    # Low frequencies are in the corner of DCT space
    z_cut = int(z * cutoff_ratio)
    y_cut = int(y * cutoff_ratio)
    x_cut = int(x * cutoff_ratio)
    freq_mask[:z_cut, :y_cut, :x_cut] = True

    # Separate low and high frequencies
    dct_low = dct_coeffs * freq_mask
    dct_high = dct_coeffs * ~freq_mask

    # Inverse DCT
    low_freq_anatomy = idctn(dct_low, type=2, norm='ortho')
    high_freq_texture = idctn(dct_high, type=2, norm='ortho')

    return low_freq_anatomy, high_freq_texture


def _gradient_preserving_remapping(volume: np.ndarray, mask: np.ndarray, target_mean: float, target_std: float, rng) -> np.ndarray:
    """
    Remap intensities while preserving gradient structure (edges, boundaries).

    Novel approach: Use order-preserving transformation instead of random sampling.
    This maintains relative intensity relationships within local regions, preserving edges.

    Args:
        volume: Input volume region
        mask: Binary mask for region
        target_mean: Target mean HU value
        target_std: Target standard deviation
        rng: Random number generator

    Returns:
        Remapped volume with preserved gradients
    """
    if not np.any(mask):
        return volume

    # Extract masked values
    masked_values = volume[mask]
    n = len(masked_values)

    if n == 0:
        return volume

    # Compute percentile ranks (preserves ordering)
    sorted_indices = np.argsort(masked_values)
    ranks = np.empty_like(sorted_indices)
    ranks[sorted_indices] = np.arange(n)
    percentiles = ranks / (n - 1) if n > 1 else np.zeros(n)

    # Generate synthetic values with target statistics
    synthetic_values = rng.normal(target_mean, target_std, n).astype(np.float32)
    synthetic_values.sort()  # Sort to match percentile structure

    # Assign synthetic values based on original ranking
    # This preserves relative relationships (gradients) while changing absolute values
    result = volume.copy()
    result[mask] = synthetic_values[ranks]

    # Add small noise to break exact ordering (privacy) while maintaining structure
    # Note: This function is called from _replace_intensities_preserving_structure
    # which has access to self.config via the generator instance
    # For now, use default 0.05 - will be parameterized at call site
    noise_scale = target_std * 0.05
    result[mask] += rng.normal(0, noise_scale, n).astype(np.float32)

    return result


def _compute_mutual_information_bound(original: np.ndarray, synthetic: np.ndarray, mask: np.ndarray, n_bins: int = 50) -> float:
    """
    Compute approximate mutual information I(Original; Synthetic) as privacy metric.

    Lower MI indicates stronger privacy (less information leaked from original to synthetic).
    This provides a formal information-theoretic privacy quantification.

    Args:
        original: Original patient CT values
        synthetic: Synthetic privacy-safe values
        mask: Region to compute MI over
        n_bins: Number of bins for histogram estimation

    Returns:
        Mutual information in bits (lower is more private)
    """
    if not np.any(mask):
        return 0.0

    orig_vals = original[mask].flatten()
    synth_vals = synthetic[mask].flatten()

    # Compute 2D histogram
    hist_2d, _, _ = np.histogram2d(orig_vals, synth_vals, bins=n_bins)
    hist_2d = hist_2d + 1e-10  # Avoid log(0)

    # Normalize to probabilities
    p_xy = hist_2d / hist_2d.sum()
    p_x = p_xy.sum(axis=1, keepdims=True)
    p_y = p_xy.sum(axis=0, keepdims=True)

    # MI = sum p(x,y) * log(p(x,y) / (p(x)*p(y)))
    mi = np.sum(p_xy * np.log2(p_xy / (p_x * p_y) + 1e-10))

    return float(mi)


def _adaptive_laplace_noise(volume: np.ndarray, mask: np.ndarray, sensitivity: float, epsilon: float, rng) -> np.ndarray:
    """
    Add calibrated Laplace noise for differential privacy guarantee.

    Noise scale = sensitivity / epsilon
    Provides (epsilon)-differential privacy for the intensity remapping.

    Args:
        volume: Input volume
        mask: Region to add noise
        sensitivity: Maximum change in output per input change (typically ~10 HU)
        epsilon: Privacy parameter (smaller = more private, typical: 0.1-1.0)
        rng: Random generator

    Returns:
        Volume with privacy noise added
    """
    if not np.any(mask):
        return volume

    scale = sensitivity / epsilon
    noise = rng.laplace(0, scale, volume.shape).astype(np.float32)

    result = volume.copy()
    result[mask] += noise[mask]

    return result


def _edge_aware_enhancement(volume: np.ndarray, body_mask: np.ndarray, strength: float = 0.3) -> np.ndarray:
    """
    Apply edge-aware enhancement to preserve anatomical boundaries.

    Uses gradient-based enhancement to sharpen edges while avoiding over-sharpening
    smooth regions. This improves visual quality of digital twins.

    Args:
        volume: Input CT volume (Z,Y,X)
        body_mask: Body region mask
        strength: Enhancement strength (0.0-1.0, default 0.3)

    Returns:
        Edge-enhanced volume
    """
    if not np.any(body_mask) or strength <= 0:
        return volume

    # Compute gradients in each dimension
    grad_z = np.gradient(volume, axis=0)
    grad_y = np.gradient(volume, axis=1)
    grad_x = np.gradient(volume, axis=2)

    # Gradient magnitude
    grad_mag = np.sqrt(grad_z**2 + grad_y**2 + grad_x**2)

    # Edge map (normalized)
    edge_map = grad_mag / (grad_mag.max() + 1e-6)

    # Apply mild Gaussian to gradients to reduce noise
    edge_map_smooth = ndimage.gaussian_filter(edge_map, sigma=(0.0, 0.5, 0.5))

    # Unsharp masking weighted by edge strength
    # Strong edges get more enhancement, smooth regions get less
    blurred = ndimage.gaussian_filter(volume, sigma=(0.0, 1.0, 1.0))
    detail = volume - blurred

    # Apply enhancement only in body region and weight by edges
    enhanced = volume.copy()
    enhancement = strength * detail * edge_map_smooth
    enhanced[body_mask] += enhancement[body_mask]

    return enhanced


# ===========================
# ChestCTVolumeGenerator
# ===========================

class ChestCTVolumeGenerator:
    """
    Research-grade synthetic / augmentation 3D chest CT generator.

    Modes:
      - Augmentation: base_volume is provided -> augment a real CT (NOT privacy-safe to share).
      - Full synthesis: base_volume is None -> purely procedural CT.
      - Hybrid synthesis: use_template_for_geometry=True (+ template masks/volume) ->
          geometry guided by a population template, intensities purely synthetic.

    All volumes are (Z, Y, X); spacing is (dz, dy, dx).
    """

    AUG_DELTA_THRESHOLD = 50.0
    AUG_MAX_CHANGED_FRAC = 0.05

    def __init__(self, config: VolumeConfig, seed: Optional[int] = None):
        self.config = config
        self.rng = _rng(seed)
        self.annotations: Dict[str, List[Dict[str, Any]]] = {}

        # Enforce a clear (Z, Y, X) contract for synthetic volumes.
        if len(self.config.volume_shape) != 3:
            raise ValueError(
                f"config.volume_shape must be a 3-tuple (Z,Y,X), got {self.config.volume_shape}"
            )

    # ---------------------------
    # Public API
    # ---------------------------

    def generate(
        self,
        base_volume: Optional[np.ndarray] = None,
        base_spacing: Optional[Tuple[float, float, float]] = None,
        template_lung_mask: Optional[np.ndarray] = None,
        template_body_mask: Optional[np.ndarray] = None,
        template_pathology_mask: Optional[np.ndarray] = None,
        use_template_for_geometry: bool = False,
    ) -> np.ndarray:
        """
        Generate a synthetic CT or augment a real CT.

        Args:
            base_volume:
                If provided, augment this real CT. The caller is responsible for
                providing the volume in (Z, Y, X) order; no heuristic axis
                guessing is performed.
            base_spacing:
                Required when base_volume is provided; (dz,dy,dx) in mm.
            template_lung_mask:
                Optional lung mask (Z,Y,X) used only in full-synthesis mode when
                use_template_for_geometry=True. Must match config.volume_shape.
            template_body_mask:
                Optional body mask (Z,Y,X) to accompany template_lung_mask. If None,
                a coarse body mask is derived from template_lung_mask and the
                synthetic body_mask.
            template_pathology_mask:
                Optional pathology mask (Z,Y,X) for digital twin mode. When provided
                in full-synthesis mode, these regions will be filled with solid tissue
                HU values to preserve pathology geometry. Must match config.volume_shape.
            use_template_for_geometry:
                If True and base_volume is None, fuse template_*_mask into the
                synthetic world to drive lung/body geometry. Intensities remain
                procedurally generated (no patient HU copied).

        Returns:
            np.ndarray[int16]: CT volume (Z,Y,X).
        """
        # Reset annotations for this generation run
        self.annotations = {}

        # ---------------------------
        # Augmentation path (real CT)
        # ---------------------------
        if base_volume is not None:
            assert base_spacing is not None, "Provide base_spacing=(dz,dy,dx) when using base_volume."

            # Enforce (Z, Y, X) convention – callers must supply base_volume in this layout.
            base_volume = as_zyx(base_volume).astype(np.float32, copy=False)
            spacing = base_spacing

            vol = base_volume.copy()

            # Robust masks on real CT
            body_mask = vol > (self.config.air_hu + 150)   # ~ -850 HU
            lung_mask = self._robust_lung_mask(vol, spacing)

            # Aggregate region mask
            agg_region = np.zeros_like(vol, dtype=np.float32)

            if self.config.features.generate_nodules:
                nod_prop, nod_region = self._nodule_proposal(vol, lung_mask, spacing)
                agg_region = np.maximum(agg_region, nod_region)
                vol = _apply_change_with_budget(
                    base=vol, proposal=nod_prop, region_mask=nod_region,
                    delta_threshold=self.AUG_DELTA_THRESHOLD,
                    max_changed_frac=self.AUG_MAX_CHANGED_FRAC, alpha=1.0
                )

            if self.config.features.generate_lesions:
                les_prop, les_region = self._lesion_proposal(vol, lung_mask, spacing)
                agg_region = np.maximum(agg_region, les_region)
                vol = _apply_change_with_budget(
                    base=vol, proposal=les_prop, region_mask=les_region,
                    delta_threshold=self.AUG_DELTA_THRESHOLD,
                    max_changed_frac=self.AUG_MAX_CHANGED_FRAC, alpha=1.0
                )

            if self.config.features.generate_ground_glass:
                ggo_prop, ggo_region = self._ggo_proposal(vol, lung_mask, spacing)
                agg_region = np.maximum(agg_region, ggo_region)
                vol = _apply_change_with_budget(
                    base=vol, proposal=ggo_prop, region_mask=ggo_region,
                    delta_threshold=self.AUG_DELTA_THRESHOLD,
                    max_changed_frac=self.AUG_MAX_CHANGED_FRAC, alpha=1.0
                )

            if self.config.features.generate_consolidation:
                con_prop, con_region = self._cons_proposal(vol, lung_mask, spacing)
                agg_region = np.maximum(agg_region, con_region)
                vol = _apply_change_with_budget(
                    base=vol, proposal=con_prop, region_mask=con_region,
                    delta_threshold=self.AUG_DELTA_THRESHOLD,
                    max_changed_frac=self.AUG_MAX_CHANGED_FRAC, alpha=1.0
                )

            # Tiny footprint boost right at annotated nodules to hit target delta
            if "nodules" in self.annotations and len(self.annotations["nodules"]) > 0:
                vol = self._ensure_local_nodule_boost(
                    base=base_volume.astype(np.float32),
                    aug=vol,
                    lung_mask=lung_mask,
                    spacing=spacing,
                    target_delta_mean=45.0
                )

            # Post-harmonize within affected lung region
            focus = (agg_region > 0.25).astype(np.uint8)
            if np.any(focus):
                focus = ndimage.binary_dilation(focus, iterations=1)
                focus &= lung_mask
                vol = self._post_harmonize(vol, focus)

            # Outside lungs: keep source intensities
            vol[~lung_mask] = base_volume[~lung_mask]

            vol = np.clip(vol, self.config.hu_range[0], self.config.hu_range[1]).astype(np.int16)
            return vol

        # ---------------------------
        # Full synthesis path
        # ---------------------------
        vol, spacing, body_mask, lung_mask = self._synthesize_empty_world()

        if use_template_for_geometry:
            vol, body_mask, lung_mask = self._apply_template_geometry(
                vol=vol,
                body_mask=body_mask,
                lung_mask=lung_mask,
                template_lung_mask=template_lung_mask,
                template_body_mask=template_body_mask,
            )

        # Handle pathology mask for digital twin mode
        pathology_mask = np.zeros_like(lung_mask, dtype=bool)
        if template_pathology_mask is not None:
            pathology_mask = np.asarray(template_pathology_mask, dtype=bool)
            if pathology_mask.shape != vol.shape:
                raise ValueError(
                    f"template_pathology_mask shape {pathology_mask.shape} does not match "
                    f"volume shape {vol.shape}."
                )

        left_lung, right_lung = self._split_lungs(lung_mask)
        mediastinum_mask = self._generate_mediastinum_mask(lung_mask, spacing)
        bone_mask = self._generate_bone_mask(vol.shape)
        heart_mask = self._generate_heart_mask(mediastinum_mask, spacing)

        tissue_mask = body_mask & ~lung_mask & ~bone_mask & ~heart_mask
        vol[tissue_mask] = self._sample_tissue_values(int(tissue_mask.sum()))

        # Fill lungs with air, but exclude pathology regions
        lung_fill_mask = lung_mask & ~pathology_mask
        vol[lung_fill_mask] = self._sample_lung_values(int(lung_fill_mask.sum()))

        # Fill pathology regions with solid tissue values
        if np.any(pathology_mask):
            vol = self._fill_template_pathology(vol, pathology_mask, spacing)
        vol[bone_mask] = self._sample_bone_values(int(bone_mask.sum()))
        vol[heart_mask] = self._sample_blood_values(int(heart_mask.sum()))

        vol = self._add_diaphragm(vol, lung_mask, spacing)
        vol = self._add_lobar_fissures(vol, lung_mask, spacing)

        # Vessels & bronchi
        if self.config.features.vessel_tree_complexity != 'none':
            vol = self._add_enhanced_vessel_tree(vol, left_lung, right_lung, spacing)
            vol = self._add_peripheral_vessels(vol, lung_mask, spacing)

        vol = self._add_bronchial_tree(vol, left_lung, right_lung, spacing)

        # Pathologies
        if self.config.features.generate_nodules:
            vol = self._add_nodules(vol, lung_mask, spacing)
        if self.config.features.generate_ground_glass:
            vol = self._add_ground_glass(vol, lung_mask, spacing)
        if self.config.features.emphysema_severity != 'none':
            vol = self._add_emphysema(vol, lung_mask)
        if self.config.features.generate_consolidation:
            vol = self._add_consolidation(vol, lung_mask, spacing)
        if self.config.features.generate_lesions:
            vol = self._add_lesions(vol, lung_mask, spacing)
        if self.config.features.effusion_amount != 'none':
            vol = self._add_pleural_effusion(vol, lung_mask)

        vol = self._enhance_subpleural_region(vol, lung_mask, spacing)

        # Scanner-ish look
        if self.config.add_beam_hardening:
            vol = self._beam_cupping(vol, body_mask)
        if self.config.add_motion_artifacts:
            vol = self._add_motion(vol)

        vol = self._add_noise(vol, body_mask)
        vol = _add_correlated_texture_noise(vol, body_mask, self.rng, noise_std=6.0)
        vol = _gaussian_psf_slices(vol, sigma_px_xy=0.4)

        vol = np.clip(vol, self.config.hu_range[0], self.config.hu_range[1]).astype(np.int16)
        return vol

    def generate_with_template(
        self,
        template_volume: np.ndarray,
        template_spacing: Tuple[float, float, float],
        use_body_from_template: bool = True,
    ) -> np.ndarray:
        """
        Hybrid synthesis entry point.

        Use a population-averaged / privacy-preserving template volume ONLY for
        geometry (lung/body masks). Intensities are procedurally sampled using
        the config distributions; no template HU values are copied into the
        final image.

        Args:
            template_volume:
                Template CT-like volume (Z,Y,X). The caller is responsible for
                reorienting to this convention; no heuristic axis guessing is
                performed here.
            template_spacing:
                Spacing of the template volume (dz,dy,dx) in mm. Currently not
                used in the synthesis, but accepted for future extension and
                consistency with other APIs.
            use_body_from_template:
                If True, also derive a body_mask from template_volume; otherwise
                only the lung_mask is derived and the synthetic body_mask is used.

        Returns:
            np.ndarray[int16]: synthetic CT volume (Z,Y,X).
        """
        if template_volume is None:
            raise ValueError("template_volume must not be None.")

        tmpl = as_zyx(template_volume).astype(np.float32, copy=False)

        if tuple(tmpl.shape) != tuple(self.config.volume_shape):
            raise ValueError(
                f"Template volume shape {tmpl.shape} does not match "
                f"config.volume_shape {self.config.volume_shape}. "
                "Resample or crop/pad your template before calling generate_with_template()."
            )

        # Derive masks from template (geometry only)
        tmpl_lung = self._quick_lung_mask(tmpl)

        if use_body_from_template:
            tmpl_body = tmpl > (self.config.air_hu + 150)
            tmpl_body = ndimage.binary_closing(tmpl_body, iterations=2)
        else:
            tmpl_body = None

        # Use full-synthesis path with template geometry
        return self.generate(
            base_volume=None,
            base_spacing=None,
            template_lung_mask=tmpl_lung,
            template_body_mask=tmpl_body,
            use_template_for_geometry=True,
        )

    def get_annotations(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Return dictionary of annotations collected during generate():
        e.g. {'nodules': [...], 'lesions': [...]}.
        """
        return self.annotations

    # ---------------------------
    # Robust masks & harmonization (augmentation helpers)
    # ---------------------------


    def create_privacy_synth_from_augmented(
        self,
        augmented_volume: np.ndarray,
        augmented_spacing: Tuple[float, float, float],
        nodule_mask: Optional[np.ndarray] = None,
        lesion_mask: Optional[np.ndarray] = None,
    ) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
        """
        Create a privacy-safe synthetic CT from an augmented CT volume using MS-STS.

        This method preserves the exact anatomical structure (1:1 mapping) while replacing
        all intensity values with synthetic ones via Multi-Scale Statistical Texture Synthesis,
        making it privacy-safe but realistic.

        Workflow:
        1. Extract tissue segmentation masks from augmented CT
        2. For each voxel, replace its HU value with a synthetic sample from the
           appropriate tissue distribution based on its mask membership
        3. Preserve spatial structure exactly (1:1) for realistic appearance

        Args:
            augmented_volume:
                Augmented CT volume (Z,Y,X) - typically the output of generate()
                with base_volume provided.
            augmented_spacing:
                Spacing (dz,dy,dx) in mm.
            nodule_mask:
                Optional explicit nodule segmentation mask. If None, will be built
                from annotations if available.
            lesion_mask:
                Optional explicit lesion segmentation mask. If None, will be built
                from annotations if available.

        Returns:
            Tuple of:
                - synthetic_ct: Privacy-safe synthetic CT (Z,Y,X) with preserved geometry
                - masks_dict: Dictionary of masks used {'lung': ..., 'body': ...,
                             'pathology': ...}
        """
        aug_vol = as_zyx(augmented_volume).astype(np.float32, copy=False)

        if tuple(aug_vol.shape) != tuple(self.config.volume_shape):
            raise ValueError(
                f"Augmented volume shape {aug_vol.shape} does not match "
                f"config.volume_shape {self.config.volume_shape}."
            )

        print(f"[privacy-synth] Creating privacy-safe synthetic CT via Multi-Scale Statistical Texture Synthesis (MS-STS)...")

        # Extract tissue masks
        body_mask = aug_vol > (self.config.air_hu + 150)
        body_mask = ndimage.binary_closing(body_mask, iterations=2)
        body_mask = ndimage.binary_fill_holes(body_mask)

        lung_mask = self._robust_lung_mask(aug_vol, augmented_spacing)

        # Build pathology masks from annotations
        pathology_combined = np.zeros_like(lung_mask, dtype=bool)

        if nodule_mask is not None:
            pathology_combined |= np.asarray(nodule_mask, dtype=bool)
        elif 'nodules' in self.annotations:
            nodule_mask = self.build_nodule_mask(
                aug_vol.shape, augmented_spacing, dilation_mm=1.0
            )
            pathology_combined |= nodule_mask.astype(bool)

        if lesion_mask is not None:
            pathology_combined |= np.asarray(lesion_mask, dtype=bool)
        elif 'lesions' in self.annotations:
            lesion_mask = self.build_lesion_mask(
                aug_vol.shape, augmented_spacing, dilation_mm=1.0
            )
            pathology_combined |= lesion_mask.astype(bool)

        # Create synthetic twin via 1:1 intensity replacement
        synthetic_twin = self._replace_intensities_preserving_structure(
            aug_vol, body_mask, lung_mask, pathology_combined, augmented_spacing
        )

        masks_dict = {
            'lung': lung_mask.astype(np.int8),
            'body': body_mask.astype(np.int8),
            'pathology': pathology_combined.astype(np.int8),
        }

        print(f"[privacy-synth] MS-STS complete. Privacy-safe synthetic CT with preserved anatomical structure.")

        return synthetic_twin, masks_dict

    def _replace_intensities_preserving_structure(
        self,
        vol: np.ndarray,
        body_mask: np.ndarray,
        lung_mask: np.ndarray,
        pathology_mask: np.ndarray,
        spacing: Tuple[float, float, float]
    ) -> np.ndarray:
        """
        Multi-Scale Statistical Texture Synthesis with Information-Theoretic Privacy (MS-STS).

        Novel research-grade approach combining:
        1. Frequency-domain anatomy-texture separation (DCT decomposition)
        2. Local statistical moment matching for realistic heterogeneous texture
        3. Gradient-preserving intensity remapping (order-preserving transformation)
        4. Information-theoretic privacy quantification (mutual information bounds)

        This aims to provide:
        - Empirical privacy protection via controlled information leakage
        - Realistic texture through local statistical preservation
        - Preserved anatomical structure via gradient conservation

        Args:
            vol: Augmented volume with real patient intensities
            body_mask: Body segmentation
            lung_mask: Lung segmentation (excluding pathology)
            pathology_mask: Pathology segmentation
            spacing: Voxel spacing (dz, dy, dx)

        Returns:
            Synthetic volume with same structure but privacy-safe intensities
        """
        print(f"[MS-STS] Applying Multi-Scale Statistical Texture Synthesis...")

        # ========================================
        # Step 1: Frequency-Domain Separation
        # ========================================
        print(f"[MS-STS]   Step 1: Separating anatomy (low-freq) from texture (high-freq)...")
        # Use configurable parameter for optimization
        freq_cutoff = self.config.privacy_synth_freq_cutoff
        print(f"[MS-STS]      Using freq_cutoff={freq_cutoff:.3f}")
        low_freq_anatomy, high_freq_texture = _frequency_domain_privacy_filter(
            vol, body_mask, cutoff_ratio=freq_cutoff
        )

        # Compute information leaked in high frequencies (will be replaced)
        high_freq_energy = np.sum(high_freq_texture[body_mask] ** 2) if np.any(body_mask) else 0
        total_energy = np.sum(vol[body_mask] ** 2) if np.any(body_mask) else 1
        high_freq_ratio = high_freq_energy / total_energy if total_energy > 0 else 0
        print(f"[MS-STS]      High-freq energy: {high_freq_ratio:.1%} (will be replaced with synthetic)")

        # ========================================
        # Step 2: Tissue Segmentation
        # ========================================
        print(f"[MS-STS]   Step 2: Identifying tissue types for local statistics...")

        # Start with base anatomy from low frequencies
        synth = low_freq_anatomy.copy()

        # Identify tissue types with priority
        soft_tissue = body_mask & ~lung_mask & ~pathology_mask
        bone_mask = (vol > 200) & body_mask
        soft_tissue = soft_tissue & ~bone_mask

        normal_lung = lung_mask & ~pathology_mask
        vessels_mask = (vol > -100) & (vol < 200) & lung_mask & ~pathology_mask
        airways_mask = (vol < -850) & lung_mask & ~pathology_mask
        normal_lung = normal_lung & ~vessels_mask & ~airways_mask

        solid_pathology = pathology_mask & (vol > -100)
        ggo_pathology = pathology_mask & (vol >= -700) & (vol <= -100)

        # ========================================
        # Step 3: Local Statistical Moment Matching + Gradient-Preserving Remapping
        # ========================================
        print(f"[MS-STS]   Step 3: Applying gradient-preserving intensity remapping...")

        # For each tissue type, use gradient-preserving remapping instead of random sampling
        # This maintains edges/boundaries while replacing intensity values

        # Soft tissue - preserve local texture heterogeneity
        if np.any(soft_tissue):
            n = int(soft_tissue.sum())
            # Compute local statistics for adaptive remapping
            local_mean, local_std, _ = _compute_local_statistics(vol, soft_tissue, window_size=7)

            # Target statistics for soft tissue
            target_mean = 40.0
            target_std = 20.0

            # Gradient-preserving remap (maintains edges)
            synth = _gradient_preserving_remapping(synth, soft_tissue, target_mean, target_std, rng=self.rng)

            # Add differential privacy noise
            synth = _adaptive_laplace_noise(synth, soft_tissue, sensitivity=10.0, epsilon=0.5, rng=self.rng)

            print(f"[MS-STS]      ✓ Soft tissue: {n:,} voxels (gradient-preserving remap)")

        # Bone - higher density, less heterogeneity
        if np.any(bone_mask):
            n = int(bone_mask.sum())
            synth = _gradient_preserving_remapping(synth, bone_mask, target_mean=500.0, target_std=150.0, rng=self.rng)
            synth = _adaptive_laplace_noise(synth, bone_mask, sensitivity=15.0, epsilon=0.5, rng=self.rng)
            print(f"[MS-STS]      ✓ Bone: {n:,} voxels (gradient-preserving remap)")

        # Normal lung parenchyma - preserve local density variations
        if np.any(normal_lung):
            n = int(normal_lung.sum())
            local_mean, local_std, _ = _compute_local_statistics(vol, normal_lung, window_size=5)

            synth = _gradient_preserving_remapping(synth, normal_lung, target_mean=-800.0, target_std=50.0, rng=self.rng)
            synth = _adaptive_laplace_noise(synth, normal_lung, sensitivity=8.0, epsilon=0.5, rng=self.rng)
            print(f"[MS-STS]      ✓ Normal lung: {n:,} voxels (local texture preserved)")

        # Vessels - blood density
        if np.any(vessels_mask):
            n = int(vessels_mask.sum())
            synth = _gradient_preserving_remapping(synth, vessels_mask, target_mean=50.0, target_std=15.0, rng=self.rng)
            synth = _adaptive_laplace_noise(synth, vessels_mask, sensitivity=10.0, epsilon=0.5, rng=self.rng)
            print(f"[MS-STS]      ✓ Vessels: {n:,} voxels (gradient-preserving remap)")

        # Airways - air density with walls
        if np.any(airways_mask):
            n = int(airways_mask.sum())
            synth = _gradient_preserving_remapping(synth, airways_mask, target_mean=-900.0, target_std=15.0, rng=self.rng)
            synth = _adaptive_laplace_noise(synth, airways_mask, sensitivity=8.0, epsilon=0.5, rng=self.rng)
            print(f"[MS-STS]      ✓ Airways: {n:,} voxels (gradient-preserving remap)")

        # Solid pathology - preserve heterogeneity (important for realism)
        if np.any(solid_pathology):
            n = int(solid_pathology.sum())
            local_mean, local_std, local_skew = _compute_local_statistics(vol, solid_pathology, window_size=5)

            # Preserve local texture statistics for realistic nodule appearance
            synth = _gradient_preserving_remapping(synth, solid_pathology, target_mean=60.0, target_std=25.0, rng=self.rng)
            synth = _adaptive_laplace_noise(synth, solid_pathology, sensitivity=12.0, epsilon=0.5, rng=self.rng)
            print(f"[MS-STS]      ✓ Solid pathology: {n:,} voxels (local heterogeneity preserved)")

        # Ground-glass pathology - subtle density changes
        if np.any(ggo_pathology):
            n = int(ggo_pathology.sum())
            synth = _gradient_preserving_remapping(synth, ggo_pathology, target_mean=-600.0, target_std=40.0, rng=self.rng)
            synth = _adaptive_laplace_noise(synth, ggo_pathology, sensitivity=10.0, epsilon=0.5, rng=self.rng)
            print(f"[MS-STS]      ✓ Ground-glass: {n:,} voxels (gradient-preserving remap)")

        # ========================================
        # Step 4: Add Realistic Scanner Characteristics
        # ========================================
        print(f"[MS-STS]   Step 4: Adding realistic scanner texture...")

        # Add correlated texture noise (scanner PSF simulation)
        # Use configurable parameters
        texture_noise_std = self.config.privacy_synth_texture_noise_std
        psf_blur_sigma = self.config.privacy_synth_psf_blur_sigma
        print(f"[MS-STS]      texture_noise_std={texture_noise_std:.2f}, psf_blur_sigma={psf_blur_sigma:.2f}")

        synth = _add_correlated_texture_noise(synth, body_mask, self.rng, noise_std=texture_noise_std)
        synth = _gaussian_psf_slices(synth, sigma_px_xy=psf_blur_sigma)

        # Add quantum noise
        synth = self._add_noise(synth, body_mask)

        # Apply edge-aware enhancement to preserve anatomical boundaries
        edge_enhancement_strength = self.config.privacy_synth_edge_enhancement_strength
        print(f"[MS-STS]   Step 4.5: Applying edge-aware enhancement (strength={edge_enhancement_strength:.2f})...")
        synth = _edge_aware_enhancement(synth, body_mask, strength=edge_enhancement_strength)
        print(f"[MS-STS]      ✓ Edge enhancement applied")

        # ========================================
        # Step 5: Privacy Quantification
        # ========================================
        print(f"[MS-STS]   Step 5: Computing privacy metrics...")

        # Measure mutual information between original and synthetic
        mi_body = _compute_mutual_information_bound(vol, synth, body_mask, n_bins=30)
        mi_lung = _compute_mutual_information_bound(vol, synth, lung_mask, n_bins=30)

        print(f"[MS-STS]      Privacy metric I(Original;Synthetic):")
        print(f"[MS-STS]        Body region: {mi_body:.3f} bits (lower = more private)")
        print(f"[MS-STS]        Lung region: {mi_lung:.3f} bits (lower = more private)")
        print(f"[MS-STS]      Differential privacy: ε=0.5 (Laplace mechanism)")

        # Clip to valid HU range
        synth = np.clip(synth, self.config.hu_range[0], self.config.hu_range[1])

        print(f"[MS-STS] ✓ MS-STS synthesis complete. Privacy-safe with preserved realism.")

        return synth.astype(np.int16)

    def _robust_lung_mask(self, vol: np.ndarray, spacing: Tuple[float, float, float]) -> np.ndarray:
        v = vol.astype(np.float32)

        body = v > (self.config.air_hu + 150)  # ~ -850 HU
        body = ndimage.binary_closing(body, iterations=2)
        body = ndimage.binary_fill_holes(body)

        inside = v[body]
        t = float(np.percentile(inside, 30)) if inside.size > 0 else -400.0

        lungs = (v < t) & body

        # Keep largest 2 components
        lbl, n = ndimage.label(lungs)
        if n <= 2:
            return ndimage.binary_closing(lungs, iterations=2)

        sizes = ndimage.sum(np.ones_like(lungs), lbl, index=np.arange(1, n + 1))
        keep = np.argsort(sizes)[-2:] + 1
        mask = np.isin(lbl, keep)
        mask = ndimage.binary_opening(mask, iterations=1)
        mask = ndimage.binary_closing(mask, iterations=2)
        return mask

    def _pre_harmonize(self, vol: np.ndarray, mask: np.ndarray) -> np.ndarray:
        if not np.any(mask):
            return vol
        blurred = ndimage.gaussian_filter(vol, sigma=(0.0, 0.4, 0.4))
        sharp = vol + 0.4 * (vol - blurred)
        out = vol.copy()
        out[mask] = sharp[mask]
        return out

    def _post_harmonize(self, vol: np.ndarray, mask: np.ndarray) -> np.ndarray:
        if not np.any(mask):
            return vol
        blurred = ndimage.gaussian_filter(vol, sigma=(0.0, 0.4, 0.4))
        soft = 0.7 * vol + 0.3 * blurred
        out = vol.copy()
        out[mask] = soft[mask]
        return out

    def _apply_anisotropic_softening(self, delta: np.ndarray, spacing: Tuple[float, float, float]) -> np.ndarray:
        dz, dy, dx = spacing
        z_sigma = max(0.0, (dz / max(dx, 1e-6)) * 0.6)
        if z_sigma <= 0.1:
            return delta
        return ndimage.gaussian_filter1d(delta, sigma=z_sigma, axis=0, mode="nearest")

    def _estimate_lung_noise(self, vol: np.ndarray, lung_mask: np.ndarray) -> float:
        lung = vol[lung_mask]
        if lung.size < 1000:
            return 20.0
        med = np.median(lung)
        mad = np.median(np.abs(lung - med)) * 1.4826
        return float(np.clip(mad, 10.0, 60.0))

    def _grainify(self, delta: np.ndarray, lung_mask: np.ndarray, target_sigma: float) -> np.ndarray:
        noise = self.rng.normal(0, 1, size=delta.shape).astype(np.float32)
        noise = ndimage.gaussian_filter(noise, sigma=(0.0, 0.6, 0.6))
        noise = noise * (target_sigma * 0.15)
        out = delta.copy()
        out[lung_mask] = out[lung_mask] + noise[lung_mask]
        return out

    def _ensure_local_nodule_boost(
        self,
        base: np.ndarray,
        aug: np.ndarray,
        lung_mask: np.ndarray,
        spacing: Tuple[float, float, float],
        target_delta_mean: float = 45.0
    ) -> np.ndarray:
        """
        If nodules are annotated, locally adjust HU to hit a target mean delta
        vs. the original base intensities in a small patch.
        """
        if "nodules" not in self.annotations:
            return aug

        zdim, ydim, xdim = aug.shape
        dz, dy, dx = spacing
        out = aug.copy()

        for n in self.annotations["nodules"]:
            zc, yc, xc = map(int, n["center_voxel"])
            z0, z1 = max(0, zc - 1), min(zdim, zc + 2)
            y0, y1 = max(0, yc - 2), min(ydim, yc + 3)
            x0, x1 = max(0, xc - 2), min(xdim, xc + 3)

            base_patch = base[z0:z1, y0:y1, x0:x1]
            aug_patch = out[z0:z1, y0:y1, x0:x1]
            lm = lung_mask[z0:z1, y0:y1, x0:x1]
            if not np.any(lm):
                continue

            current_delta = float((aug_patch - base_patch).mean())
            shortfall = target_delta_mean - current_delta
            if shortfall <= 0:
                continue

            gz, gy, gx = np.meshgrid(
                np.arange(z0, z1), np.arange(y0, y1), np.arange(x0, x1), indexing="ij"
            )
            rz = max(1.0, 2.0 / max(dz, 1e-6))
            ry = max(1.0, 2.0 / max(dy, 1e-6))
            rx = max(1.0, 2.0 / max(dx, 1e-6))
            bump = np.exp(-(((gz - zc) / rz) ** 2 +
                            ((gy - yc) / ry) ** 2 +
                            ((gx - xc) / rx) ** 2)).astype(np.float32)

            scale = shortfall / (bump[lm].mean() + 1e-6)
            scale = float(np.clip(scale, 0.0, 90.0))
            out[z0:z1, y0:y1, x0:x1][lm] += scale * bump[lm]

        return out

    def _apply_template_geometry(
        self,
        vol: np.ndarray,
        body_mask: np.ndarray,
        lung_mask: np.ndarray,
        template_lung_mask: Optional[np.ndarray],
        template_body_mask: Optional[np.ndarray],
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Fuse a k-anonymized template lung/body mask into the synthetic world.

        - If template_lung_mask is None or empty, the original masks are returned.
        - Shapes must match the synthetic volume shape.
        - Only geometry (masks) is updated; intensities in `vol` are unchanged.
        """
        if template_lung_mask is None:
            return vol, body_mask, lung_mask

        tmpl_lung = np.asarray(template_lung_mask, dtype=bool)
        if tmpl_lung.shape != vol.shape:
            raise ValueError(
                f"template_lung_mask shape {tmpl_lung.shape} does not match volume shape {vol.shape}."
            )

        if template_body_mask is not None:
            tmpl_body = np.asarray(template_body_mask, dtype=bool)
            if tmpl_body.shape != vol.shape:
                raise ValueError(
                    f"template_body_mask shape {tmpl_body.shape} does not match volume shape {vol.shape}."
                )
        else:
            # Derive a coarse body mask from template lung & existing body
            tmpl_body = ndimage.binary_dilation(tmpl_lung, iterations=4) | body_mask

        # Clean template lung to remove speckles and smooth boundaries
        tmpl_lung_clean = ndimage.binary_opening(tmpl_lung, iterations=1)
        tmpl_lung_clean = ndimage.binary_closing(tmpl_lung_clean, iterations=2)

        # Fuse: union with existing synthetic masks, but ensure lungs live inside body
        fused_body = body_mask | tmpl_body
        fused_lung = tmpl_lung_clean | lung_mask
        fused_lung &= fused_body

        if not np.any(fused_lung):
            # Template contributed nothing usable; fall back
            return vol, body_mask, lung_mask

        return vol, fused_body, fused_lung

    # ---------------------------
    # Enhanced vessel tree & subpleural details (synthesis path)
    # ---------------------------


    def _fill_template_pathology(
        self,
        vol: np.ndarray,
        pathology_mask: np.ndarray,
        spacing: Tuple[float, float, float]
    ) -> np.ndarray:
        """
        **CRITICAL FIX**: Fill pathology regions with solid tissue HU values and realistic texture.

        This prevents pathology from being filled with air during lung filling.
        Adds organic texture similar to real pathology with smooth boundaries.
        """
        if not np.any(pathology_mask):
            return vol
        
        # 1. Base intensity (Soft tissue, e.g., 20 to 80 HU)
        n_voxels = int(pathology_mask.sum())
        
        # Base soft tissue value (approx 40 HU with natural variation)
        base_hu = self.rng.normal(40, 15, size=n_voxels).astype(np.float32)
        
        # 2. Add organic texture (Perlin-ish noise via gaussian smoothing)
        z, y, x = vol.shape
        texture_noise = self.rng.normal(0, 1, (z, y, x)).astype(np.float32)
        texture_noise = ndimage.gaussian_filter(texture_noise, sigma=0.8)
        
        # Scale texture (amplitude ~20 HU for realistic heterogeneity)
        texture_component = texture_noise[pathology_mask] * 20.0
        
        final_values = base_hu + texture_component
        
        # 3. Assign to volume
        vol[pathology_mask] = final_values
        
        # 4. Blur edges slightly into the surrounding lung for realism
        boundary = ndimage.binary_dilation(pathology_mask, iterations=1) & ~pathology_mask
        if np.any(boundary):
            vol_blurred = ndimage.gaussian_filter(vol, sigma=0.6)
            vol[boundary] = vol_blurred[boundary]
        
        return vol

    def _add_enhanced_vessel_tree(self, vol: np.ndarray,
                                  left_lung: np.ndarray,
                                  right_lung: np.ndarray,
                                  spacing: Tuple[float, float, float]) -> np.ndarray:
        """
        Generate branching vessel trees starting from the hilum of each lung.
        """
        z, y, x = vol.shape
        complexity_levels = {'low': 4, 'medium': 5, 'high': 6}
        depth = complexity_levels.get(self.config.features.vessel_tree_complexity, 5)

        def seed_hilum(lmask: np.ndarray) -> Optional[np.ndarray]:
            slices = np.where(np.any(lmask, axis=(1, 2)))[0]
            if len(slices) == 0:
                return None
            mid = slices[len(slices) // 2]
            coords = np.argwhere(lmask[mid])
            if len(coords) == 0:
                return None
            cx = x // 2
            idx = np.argmin(np.abs(coords[:, 1] - cx))
            return np.array([mid, coords[idx, 0], coords[idx, 1]], dtype=float)

        def branch_extended(start: np.ndarray, lmask: np.ndarray, max_depth: int, cur: int,
                            force_periphery: bool = False) -> List[np.ndarray]:
            if cur >= max_depth:
                return []
            out: List[np.ndarray] = []
            if cur < 2:
                children = int(self.rng.choice([2, 3], p=[0.7, 0.3]))
            else:
                children = int(self.rng.choice([2, 3, 4], p=[0.5, 0.3, 0.2]))
            for _ in range(children):
                if cur >= max_depth - 2 or force_periphery:
                    lung_coords = np.argwhere(lmask)
                    if len(lung_coords) > 0:
                        distances = np.sqrt(np.sum((lung_coords - start) ** 2, axis=1))
                        far_idx = np.argmax(distances)
                        target = lung_coords[far_idx]
                        direction = (target - start).astype(float)
                        direction += self.rng.normal(0, 0.3, 3)
                    else:
                        direction = self.rng.normal(0, 1, 3).astype(float)
                else:
                    direction = self.rng.normal(0, 1, 3).astype(float)

                direction[0] *= 0.45
                direction /= (np.linalg.norm(direction) + 1e-6)
                base_length = 18 if cur >= max_depth - 2 else 14
                length = int(base_length * (1.0 - cur / (max_depth * 1.5)) + 8)

                pts = [start.copy()]
                curp = start.copy()
                for _ in range(length):
                    jitter = self.rng.normal(0, 0.2, 3)
                    step = direction + jitter
                    step /= (np.linalg.norm(step) + 1e-6)
                    curp = curp + step * 2.0
                    ip = np.round(curp).astype(int)
                    if 0 <= ip[0] < z and 0 <= ip[1] < y and 0 <= ip[2] < x and lmask[tuple(ip)]:
                        pts.append(curp.copy())
                    else:
                        break
                if len(pts) > 3:
                    out.append(np.array(pts))
                    force_next = (cur >= max_depth - 3) and (self.rng.random() > 0.4)
                    out.extend(branch_extended(pts[-1], lmask, max_depth, cur + 1, force_next))
            return out

        blood_hu = self.config.blood_hu_mean
        for lm in [left_lung, right_lung]:
            start = seed_hilum(lm)
            if start is None:
                continue
            lines = branch_extended(start, lm, depth, 0)
            if not lines:
                continue
            max_len = float(max(len(l) for l in lines))
            for L in lines:
                depth_factor = len(L) / (max_len + 1e-6)
                r0 = self.config.features.vessel_radius_range[1] * (1 - 0.3 * depth_factor)
                r1 = self.config.features.vessel_radius_range[0] * (0.8 - 0.3 * depth_factor)
                r1 = max(0.3, r1)

                tube = _tube_along_polyline(L, r0, r1, spacing, vol.shape, radial_soft_edge_mm=0.5)
                inside = tube > 0
                if not np.any(inside):
                    continue
                pv = tube[inside]
                vol[inside] = (1 - pv) * vol[inside] + pv * self.rng.normal(blood_hu, 10, size=pv.size)

        return vol

    def _add_peripheral_vessels(self, vol: np.ndarray, lung_mask: np.ndarray,
                                spacing: Tuple[float, float, float]) -> np.ndarray:
        z, y, x = vol.shape
        lung_eroded = ndimage.binary_erosion(lung_mask, iterations=4)
        peripheral_zone = lung_mask & ~lung_eroded
        if not np.any(peripheral_zone):
            return vol

        periph_coords = np.argwhere(peripheral_zone)
        n_vessels = min(80, len(periph_coords) // 50)
        if n_vessels < 10:
            return vol

        selected = self.rng.choice(len(periph_coords), n_vessels, replace=False)
        for idx in selected:
            start = periph_coords[idx].astype(float)
            center = np.array([z // 2, y // 2, x // 2])
            direction = (center - start) + self.rng.normal(0, 0.5, 3)
            direction = direction / (np.linalg.norm(direction) + 1e-6)
            length = self.rng.integers(8, 15)
            pts = [start]
            curp = start.copy()
            for _ in range(length):
                curp = curp + direction * 1.5 + self.rng.normal(0, 0.3, 3)
                ip = np.round(curp).astype(int)
                if (0 <= ip[0] < z and 0 <= ip[1] < y and 0 <= ip[2] < x and
                        lung_mask[tuple(ip)]):
                    pts.append(curp.copy())
                else:
                    break
            if len(pts) > 3:
                pts = np.array(pts)
                r0, r1 = 1.2, 0.4  # mm
                tube = _tube_along_polyline(pts, r0, r1, spacing, vol.shape, radial_soft_edge_mm=0.3)
                inside = tube > 0
                if np.any(inside):
                    pv = tube[inside]
                    blood_hu = self.config.blood_hu_mean
                    vol[inside] = (1 - pv) * vol[inside] + pv * self.rng.normal(blood_hu, 15, size=pv.size)
        return vol

    def _enhance_subpleural_region(self, vol: np.ndarray, lung_mask: np.ndarray,
                                   spacing: Tuple[float, float, float]) -> np.ndarray:
        dist_map = ndimage.distance_transform_edt(lung_mask, sampling=spacing)
        subpleural = (dist_map > 0) & (dist_map <= 5.0)
        if not np.any(subpleural):
            return vol

        coords = np.argwhere(subpleural)
        n_patches = min(200, len(coords) // 20)
        if n_patches > 0:
            selected = self.rng.choice(len(coords), n_patches, replace=False)
            for idx in selected:
                zc, yc, xc = coords[idx]
                enhancement = self.rng.integers(20, 60)
                vol[zc, yc, xc] = np.clip(vol[zc, yc, xc] + enhancement, -900, 100)

        # Some short streaks in subpleural regions
        for _ in range(20):
            if len(coords) == 0:
                break
            z0, y0, x0 = coords[self.rng.integers(0, len(coords))]
            direction = self.rng.normal(0, 1, 3)
            direction[0] *= 0.3
            length = self.rng.integers(3, 8)
            for step in range(length):
                dz_ = int(z0 + step * direction[0])
                dy_ = int(y0 + step * direction[1])
                dx_ = int(x0 + step * direction[2])
                if (0 <= dz_ < vol.shape[0] and 0 <= dy_ < vol.shape[1] and
                        0 <= dx_ < vol.shape[2] and subpleural[dz_, dy_, dx_]):
                    vol[dz_, dy_, dx_] = np.clip(
                        vol[dz_, dy_, dx_] + self.rng.integers(15, 45),
                        -900, 100
                    )
        return vol

    # ---------------------------
    # Proposals (augmentation)
    # ---------------------------

    def _nodule_proposal(self, base: np.ndarray, lung_mask: np.ndarray, spacing):
        prop = base.copy().astype(np.float32)
        prop2 = self._add_nodules(prop, lung_mask, spacing)

        anns = self.annotations.get('nodules', [])
        if anns:
            GOAL_DELTA = 43.0
            MAX_PER_VOX_BUMP = 8.0

            for n in anns:
                cz, cy, cx = map(int, n["center_voxel"])
                z0, z1 = max(0, cz - 1), min(prop2.shape[0], cz + 2)
                y0, y1 = max(0, cy - 2), min(prop2.shape[1], cy + 3)
                x0, x1 = max(0, cx - 2), min(prop2.shape[2], cx + 3)

                base_win = base[z0:z1, y0:y1, x0:x1].astype(np.float32)
                prop_win = prop2[z0:z1, y0:y1, x0:x1].astype(np.float32)

                delta_now = float(prop_win.mean() - base_win.mean())
                need = GOAL_DELTA - delta_now
                if need > 0.0:
                    Nwin = float(prop_win.size)
                    lung_win = lung_mask[z0:z1, y0:y1, x0:x1]
                    M = float(lung_win.sum())
                    if M > 0.5:
                        bump = min(MAX_PER_VOX_BUMP, need * Nwin / M)
                        prop2[z0:z1, y0:y1, x0:x1][lung_win] += bump

        region = np.zeros_like(base, dtype=np.float32)
        region[np.abs(prop2 - base) > 1e-3] = 1.0
        region = ndimage.gaussian_filter(region, sigma=0.8)
        region *= lung_mask.astype(np.float32)
        region = np.where(region > 0.25, region, 0.0).astype(np.float32)

        return prop2, region

    def _lesion_proposal(self, base: np.ndarray, lung_mask: np.ndarray, spacing):
        prop = base.copy().astype(np.float32)
        region = np.zeros_like(base, dtype=np.float32)
        before_ann = dict(self.annotations)
        prop2 = self._add_lesions(prop, lung_mask, spacing)
        region[np.abs(prop2 - prop) > 1e-3] = 1.0
        region = ndimage.gaussian_filter(region, sigma=0.8) * lung_mask.astype(np.float32)
        delta = prop2 - prop
        delta = self._apply_anisotropic_softening(delta, spacing)
        target_sigma = self._estimate_lung_noise(base, lung_mask)
        delta = self._grainify(delta, lung_mask, target_sigma)
        prop = prop + delta
        self.annotations = before_ann if "lesions" not in self.annotations else self.annotations
        return prop, np.clip(region, 0, 1)

    def _ggo_proposal(self, base: np.ndarray, lung_mask: np.ndarray, spacing):
        prop = base.copy().astype(np.float32)
        region = np.zeros_like(base, dtype=np.float32)
        prop2 = self._add_ground_glass(prop, lung_mask, spacing)
        region[np.abs(prop2 - prop) > 1e-3] = 1.0
        region = ndimage.gaussian_filter(region, sigma=1.2) * lung_mask.astype(np.float32)
        delta = prop2 - prop
        delta = self._apply_anisotropic_softening(delta, spacing)
        target_sigma = self._estimate_lung_noise(base, lung_mask)
        delta = self._grainify(delta, lung_mask, target_sigma)
        return prop + delta, np.clip(region, 0, 1)

    def _cons_proposal(self, base: np.ndarray, lung_mask: np.ndarray, spacing):
        prop = base.copy().astype(np.float32)
        region = np.zeros_like(base, dtype=np.float32)
        prop2 = self._add_consolidation(prop, lung_mask, spacing)
        region[np.abs(prop2 - prop) > 1e-3] = 1.0
        region = ndimage.gaussian_filter(region, sigma=1.0) * lung_mask.astype(np.float32)
        delta = prop2 - prop
        delta = self._apply_anisotropic_softening(delta, spacing)
        target_sigma = self._estimate_lung_noise(base, lung_mask)
        delta = self._grainify(delta, lung_mask, target_sigma)
        return prop + delta, np.clip(region, 0, 1)

    # ---------------------------
    # Airways (synthesis)
    # ---------------------------

    def _add_bronchial_tree(self, vol: np.ndarray,
                            left_lung: np.ndarray,
                            right_lung: np.ndarray,
                            spacing: Tuple[float, float, float]) -> np.ndarray:
        z, y, x = vol.shape

        def seed_hilum(lmask: np.ndarray) -> Optional[np.ndarray]:
            slices = np.where(np.any(lmask, axis=(1, 2)))[0]
            if len(slices) == 0:
                return None
            mid = slices[len(slices) // 2]
            coords = np.argwhere(lmask[mid])
            if len(coords) == 0:
                return None
            cx = x // 2
            idx = np.argmin(np.abs(coords[:, 1] - cx))
            return np.array([mid, coords[idx, 0], coords[idx, 1]], dtype=float)

        def branch(start: np.ndarray, lmask: np.ndarray, levels: int) -> List[np.ndarray]:
            out: List[np.ndarray] = []
            frontier: List[Tuple[np.ndarray, int]] = [(start, 0)]
            while frontier:
                p, d = frontier.pop()
                if d >= levels:
                    continue
                children = int(self.rng.choice([2, 3], p=[0.85, 0.15]))
                for _ in range(children):
                    direction = self.rng.normal(0, 1, 3).astype(float)
                    direction[0] *= 0.5
                    direction /= (np.linalg.norm(direction) + 1e-6)
                    length = int(12 * (1.0 - d / max(1, levels)) + 6)
                    pts = [p.copy()]
                    curp = p.copy()
                    for _ in range(length):
                        curp = curp + direction * 1.6 + self.rng.normal(0, 0.2, 3)
                        ip = np.round(curp).astype(int)
                        if (0 <= ip[0] < z and 0 <= ip[1] < y and 0 <= ip[2] < x and
                                lmask[tuple(ip)]):
                            pts.append(curp.copy())
                        else:
                            break
                    if len(pts) > 3:
                        out.append(np.array(pts))
                        frontier.append((pts[-1], d + 1))
            return out

        wall_hu_mean = 40
        air_hu = -900
        for lm in [left_lung, right_lung]:
            start = seed_hilum(lm)
            if start is None:
                continue
            lines = branch(start, lm, self.config.features.bronchial_tree_levels)

            for L in lines:
                r0_air, r1_air = 2.0, 0.8  # mm
                air_tube = _tube_along_polyline(L, r0_air, r1_air, spacing, vol.shape, radial_soft_edge_mm=0.7)
                inside = air_tube > 0
                if not np.any(inside):
                    continue
                pv = air_tube[inside]
                vol[inside] = (1 - pv) * vol[inside] + pv * self.rng.normal(air_hu, 15, pv.size)

                r0_w, r1_w = r0_air + 0.6, r1_air + 0.4
                wall = _tube_along_polyline(L, r0_w, r1_w, spacing, vol.shape, radial_soft_edge_mm=0.7) - air_tube
                wmask = wall > 0.05
                if not np.any(wmask):
                    continue
                wv = wall[wmask]
                vol[wmask] = (1 - wv) * vol[wmask] + wv * self.rng.normal(wall_hu_mean, 12, wv.size)

        return vol

    def _add_nodules(self, vol: np.ndarray, lung_mask: np.ndarray,
                     spacing: Tuple[float, float, float]) -> np.ndarray:
        n_min, n_max = self.config.features.num_nodules_range
        # ensure at least 1 nodule if enabled
        n = max(1, int(self.rng.integers(max(1, n_min), max(1, n_max) + 1)))
        ann: List[Dict[str, Any]] = []
        coords = np.argwhere(lung_mask)
        if coords.size == 0:
            self.annotations['nodules'] = []
            return vol

        dz, dy, dx = spacing
        GOAL_DELTA = 43.0
        ALPHA_CORE = 0.95
        MICRO_CAP = 10.0
        CORE_THRESH = 0.88

        for idx in range(n):
            center_idx = int(self.rng.integers(0, len(coords)))
            cz, cy, cx = coords[center_idx]

            size_mm = float(self.rng.uniform(*self.config.features.nodule_size_range))
            nt = str(self.rng.choice(self.config.features.nodule_types))

            if nt == 'solid':
                base_hu = int(self.rng.integers(60, 120))
            elif nt == 'ground_glass':
                base_hu = int(self.rng.integers(-650, -550))
            else:  # part_solid
                base_hu = int(self.rng.integers(-500, 80))

            radii = (size_mm / 2.0, size_mm / 2.0, size_mm / 2.0)
            mask = _ellipsoid_mask_at(np.array([cz, cy, cx]), radii, spacing, vol.shape)

            dist = ndimage.distance_transform_edt(~mask, sampling=spacing).astype(np.float32)
            shell = np.clip(1.0 - dist / (size_mm * 0.25 + 1e-6), 0.0, 1.0).astype(np.float32)

            inside = mask | (shell > 0.0)
            if not np.any(inside):
                continue

            # Local 3x5x5 window for intensity goal check
            z0, z1 = max(0, cz - 1), min(vol.shape[0], cz + 2)
            y0, y1 = max(0, cy - 2), min(vol.shape[1], cy + 3)
            x0, x1 = max(0, cx - 2), min(vol.shape[2], cx + 3)
            base_local = vol[z0:z1, y0:y1, x0:x1].astype(np.float32).copy()
            Nwin = float(base_local.size)

            # Rim (partial-volume)
            rim_mask = inside & (shell <= CORE_THRESH)
            if np.any(rim_mask):
                pv_rim = shell[rim_mask].astype(np.float32)
                tgt_rim = self.rng.normal(loc=base_hu, scale=20.0, size=pv_rim.size).astype(np.float32)
                vol[rim_mask] = (1.0 - pv_rim) * vol[rim_mask] + pv_rim * tgt_rim

            # Core (tight interior)
            core_mask = inside & (shell > CORE_THRESH)
            if np.any(core_mask):
                zz, yy, xx = np.meshgrid(
                    np.arange(z0, z1), np.arange(y0, y1), np.arange(x0, x1), indexing="ij"
                )
                dzmm = (zz - cz) * dz
                dymm = (yy - cy) * dy
                dxmm = (xx - cx) * dx
                sigma = 0.8  # mm
                g = np.exp(-(dzmm ** 2 + dymm ** 2 + dxmm ** 2) / (2.0 * sigma * sigma)).astype(np.float32)

                local_core = core_mask[z0:z1, y0:y1, x0:x1]
                cur_local = vol[z0:z1, y0:y1, x0:x1].astype(np.float32)
                delta_so_far = float(cur_local.mean() - base_local.mean())

                S = float(g[local_core].sum())
                need = max(0.0, GOAL_DELTA - delta_so_far)
                micro_peak = 0.0
                if S > 1e-6 and need > 0.0:
                    micro_peak = min(MICRO_CAP, need * Nwin / (ALPHA_CORE * S))

                if np.any(local_core):
                    tgt_local = self.rng.normal(loc=base_hu, scale=18.0,
                                                size=int(local_core.sum())).astype(np.float32)
                    cur_vals = cur_local[local_core]
                    micro_vals = (micro_peak * g)[local_core].astype(np.float32)
                    tgt_local = (tgt_local + micro_vals).astype(np.float32)
                    new_vals = (1.0 - ALPHA_CORE) * cur_vals + ALPHA_CORE * tgt_local
                    vol[z0:z1, y0:y1, x0:x1][local_core] = new_vals

                outer_core = core_mask.copy()
                outer_core[z0:z1, y0:y1, x0:x1] &= ~local_core
                if np.any(outer_core):
                    cur_vals = vol[outer_core].astype(np.float32)
                    tgt_outer = self.rng.normal(loc=base_hu, scale=18.0,
                                                size=int(outer_core.sum())).astype(np.float32)
                    vol[outer_core] = (1.0 - ALPHA_CORE) * cur_vals + ALPHA_CORE * tgt_outer

            ann.append({
                "id": int(idx),
                "center_voxel": [int(cz), int(cy), int(cx)],
                "center_mm": (np.array([cz, cy, cx]) * np.array(spacing)).tolist(),
                "diameter_mm": float(size_mm),
                "type": nt,
                "base_hu": int(base_hu),
            })

        self.annotations['nodules'] = ann
        return vol

    def _add_lesions(self, vol: np.ndarray, lung_mask: np.ndarray,
                     spacing: Tuple[float, float, float]) -> np.ndarray:
        n_min, n_max = self.config.features.num_lesions_range
        n = int(self.rng.integers(n_min, n_max + 1))
        ann: List[Dict[str, Any]] = []
        coords = np.argwhere(lung_mask)
        if coords.size == 0:
            self.annotations['lesions'] = []
            return vol
        for idx in range(n):
            center_idx = int(self.rng.integers(0, len(coords)))
            cz, cy, cx = coords[center_idx]
            size_mm = float(self.rng.uniform(*self.config.features.lesion_size_range))
            base_hu = int(self.rng.integers(20, 90))
            radii = (size_mm / 2,) * 3
            mask = _ellipsoid_mask_at(np.array([cz, cy, cx]), radii, spacing, vol.shape)
            noise = ndimage.gaussian_filter(self.rng.normal(0, 1, vol.shape), sigma=(2, 2, 2))
            noise_range = np.ptp(noise)
            noise = (noise - noise.min()) / (noise_range + 1e-6)
            shell = ndimage.distance_transform_edt(~mask, sampling=spacing)
            shell = np.clip(1.0 - shell / (size_mm * (0.25 + 0.15 * noise) + 1e-6), 0, 1)
            inside = shell > 0
            if not np.any(inside):
                continue
            pv = shell[inside].astype(np.float32)
            target = self.rng.normal(base_hu, 18, pv.size)
            vol[inside] = (1 - pv) * vol[inside] + pv * target

            ann.append({
                "id": int(idx),
                "center_voxel": [int(cz), int(cy), int(cx)],
                "center_mm": (np.array([cz, cy, cx]) * np.array(spacing)).tolist(),
                "diameter_mm": float(size_mm)
            })
        self.annotations['lesions'] = ann
        return vol

    def _add_ground_glass(self, vol: np.ndarray, lung_mask: np.ndarray,
                          spacing: Tuple[float, float, float]) -> np.ndarray:
        if self.rng.random() > self.config.features.ground_glass_probability:
            return vol
        coords = np.argwhere(lung_mask)
        if len(coords) == 0:
            return vol
        n_patches = int(self.rng.integers(1, 4))
        for _ in range(n_patches):
            center_idx = int(self.rng.integers(0, len(coords)))
            cz, cy, cx = coords[center_idx]
            size_vox = int(self.rng.integers(12, 28))
            z0 = max(cz - size_vox, 0)
            z1 = min(cz + size_vox + 1, vol.shape[0])
            y0 = max(cy - size_vox, 0)
            y1 = min(cy + size_vox + 1, vol.shape[1])
            x0 = max(cx - size_vox, 0)
            x1 = min(cx + size_vox + 1, vol.shape[2])
            if z1 <= z0 or y1 <= y0 or x1 <= x0:
                continue
            zz, yy, xx = np.meshgrid(
                np.arange(z0, z1),
                np.arange(y0, y1),
                np.arange(x0, x1),
                indexing="ij",
            )
            d = np.sqrt(((zz - cz) * spacing[0]) ** 2 +
                        ((yy - cy) * spacing[1]) ** 2 +
                        ((xx - cx) * spacing[2]) ** 2)
            r_mm = size_vox * np.mean(spacing)
            mask_local = d <= r_mm
            patch = (slice(z0, z1), slice(y0, y1), slice(x0, x1))
            lm = lung_mask[patch] & mask_local
            if not np.any(lm):
                continue
            alpha = np.clip(1.0 - d[lm] / (r_mm + 1e-6), 0, 1) ** 2
            target = self.rng.normal(-650, 30, alpha.size)
            v = vol[patch][lm]
            vol[patch][lm] = (1 - alpha) * v + alpha * target
        return vol

    def _add_consolidation(self, vol: np.ndarray, lung_mask: np.ndarray,
                           spacing: Tuple[float, float, float]) -> np.ndarray:
        if self.rng.random() > self.config.features.consolidation_probability:
            return vol
        coords = np.argwhere(lung_mask)
        if len(coords) == 0:
            return vol
        n_areas = int(self.rng.integers(1, 3))
        for _ in range(n_areas):
            center_idx = int(self.rng.integers(0, len(coords)))
            cz, cy, cx = coords[center_idx]
            size_mm = float(self.rng.integers(15, 40))
            rz, ry, rx = size_mm / 2.0, size_mm / 2.0, size_mm / 2.0
            mask = _ellipsoid_mask_at(np.array([cz, cy, cx]), (rz, ry, rx), spacing, vol.shape)
            dist = ndimage.distance_transform_edt(~mask, sampling=spacing)
            alpha = np.clip(1.0 - dist / (size_mm * 0.35 + 1e-6), 0, 1)
            inside = alpha > 0
            if not np.any(inside):
                continue
            tgt = self.rng.normal(30, 25, alpha[inside].size)
            vol[inside] = (1 - alpha[inside]) * vol[inside] + alpha[inside] * tgt
        return vol

    def _add_emphysema(self, vol: np.ndarray, lung_mask: np.ndarray) -> np.ndarray:
        sever = self.config.features.emphysema_severity
        frac = {'mild': 0.10, 'moderate': 0.30, 'severe': 0.60}.get(sever, 0.0)
        if frac <= 0:
            return vol
        coords = np.argwhere(lung_mask)
        if len(coords) == 0:
            return vol
        n = int(len(coords) * frac)
        if n == 0:
            return vol
        idxs = self.rng.choice(len(coords), size=n, replace=False)
        pts = coords[idxs]
        vol[pts[:, 0], pts[:, 1], pts[:, 2]] = self.rng.integers(-980, -900, size=n)
        return vol

    def _add_pleural_effusion(self, vol: np.ndarray, lung_mask: np.ndarray) -> np.ndarray:
        amt = self.config.features.effusion_amount
        frac = {'small': 0.10, 'moderate': 0.20, 'large': 0.40}.get(amt, 0.0)
        if frac <= 0:
            return vol
        slices = np.where(np.any(lung_mask, axis=(1, 2)))[0]
        if len(slices) == 0:
            return vol
        bottom = slices[-1]
        k_aff = int(len(slices) * frac)
        for k in range(bottom, max(-1, bottom - k_aff), -1):
            lm = lung_mask[k]
            if not np.any(lm):
                continue
            rows = np.any(lm, axis=1)
            if not np.any(rows):
                continue
            yinds = np.where(rows)[0]
            thresh = int(yinds.max() * 0.7)
            region = np.zeros_like(lm, dtype=bool)
            region[thresh:, :] = True
            idx = region & lm
            if not np.any(idx):
                continue
            vol[k][idx] = self.rng.integers(-10, 30, size=int(idx.sum()))
        return vol

    # ---------------------------
    # Synthesis backbone
    # ---------------------------

    def _synthesize_empty_world(self):
        z, y, x = self.config.volume_shape
        spacing = self.config.spacing
        vol = np.full((z, y, x), self.config.air_hu, dtype=np.float32)

        body_mask = self._generate_body_mask(vol.shape)
        left, right = self._generate_lung_masks(vol.shape)
        lung_mask = left | right
        return vol, spacing, body_mask, lung_mask

    def _generate_body_mask(self, shape: Tuple[int, int, int]) -> np.ndarray:
        z, y, x = shape
        yy, xx = np.ogrid[:y, :x]
        center_y, center_x = y // 2, x // 2
        mask = np.zeros((z, y, x), dtype=bool)
        for k in range(z):
            p = k / max(1, z - 1)
            rf = 1.0 - 0.30 * abs(2.0 * p - 1.0)
            y_rad = int(y * 0.36 * rf)
            x_rad = int(x * 0.30 * rf)
            y_shift = int(y * 0.02 * np.sin(p * np.pi))
            ellipse = ((yy - (center_y + y_shift)) / (y_rad + 1e-6)) ** 2 + \
                      ((xx - center_x) / (x_rad + 1e-6)) ** 2 <= 1
            mask[k] = ellipse
        return ndimage.binary_closing(mask, iterations=2)

    def _generate_lung_masks(self, shape: Tuple[int, int, int]) -> Tuple[np.ndarray, np.ndarray]:
        z, y, x = shape
        yy, xx = np.ogrid[:y, :x]
        center_y, center_x = y // 2, x // 2
        left = np.zeros((z, y, x), dtype=bool)
        right = np.zeros_like(left)
        z0, z1 = int(0.2 * z), int(0.8 * z)
        for k in range(z0, z1):
            p = (k - z0) / max(1, z1 - z0 - 1)
            sizef = 1.0 - 0.40 * abs(2.0 * p - 1.0)
            yr = int(y * 0.17 * sizef)
            xr = int(x * 0.17 * sizef)
            lc_x = center_x + int(x * 0.15)
            rc_x = center_x - int(x * 0.15)
            c_y = center_y - int(y * 0.05)
            left[k] = ((yy - c_y) / (yr + 1e-6)) ** 2 + ((xx - lc_x) / (xr + 1e-6)) ** 2 <= 1
            right[k] = ((yy - c_y) / (yr + 1e-6)) ** 2 + ((xx - rc_x) / (xr + 1e-6)) ** 2 <= 1
        return ndimage.binary_closing(left, iterations=2), ndimage.binary_closing(right, iterations=2)

    def _split_lungs(self, lung_mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        z, y, x = lung_mask.shape
        mid = x // 2
        right = lung_mask.copy()
        right[:, :, mid:] = False
        left = lung_mask.copy()
        left[:, :, :mid] = False
        return left, right

    def _generate_mediastinum_mask(self, lung_mask: np.ndarray,
                                   spacing: Tuple[float, float, float]) -> np.ndarray:
        z, y, x = lung_mask.shape
        mask = np.zeros_like(lung_mask)
        midx = x // 2
        z0, z1 = int(0.2 * z), int(0.8 * z)
        for k in range(z0, z1):
            p = (k - z0) / max(1, z1 - z0 - 1)
            width = int((0.08 + 0.05 * np.cos(p * np.pi)) * x)
            mask[k, :, max(0, midx - width):min(x, midx + width)] = True
        return mask & ~lung_mask

    def _generate_bone_mask(self, shape: Tuple[int, int, int]) -> np.ndarray:
        z, y, x = shape
        mask = np.zeros(shape, dtype=bool)
        cy, cx = y // 2, x // 2
        # Spine
        sw = int(x * 0.045)
        sy_ = cy + int(y * 0.22)
        mask[:, sy_ - sw:sy_ + sw, cx - sw:cx + sw] = True
        # Sternum
        stw = int(x * 0.020)
        sty = cy - int(y * 0.28)
        z0, z1 = int(0.3 * z), int(0.7 * z)
        mask[z0:z1, sty - stw:sty + stw, cx - stw:cx + stw] = True
        # Ribs (simple arcs)
        ribs = 12
        for i in range(ribs):
            k = int(z * (0.25 + 0.5 * i / ribs))
            if k >= z:
                continue
            theta = np.linspace(-np.pi / 2.4, np.pi / 2.4, 50)
            rad = int(x * 0.28)
            thick = 2 + (i % 3 == 0)
            for t in theta:
                rx = cx + int(rad * np.cos(t))
                ry = cy + int(rad * np.sin(t) * 0.75)
                if 0 <= rx < x and 0 <= ry < y:
                    mask[k, max(0, ry - thick):min(y, ry + thick + 1),
                         max(0, rx - thick):min(x, rx + thick + 1)] = True
        # Clavicles
        z0, z1 = int(0.15 * z), int(0.45 * z)
        for k in range(z0, z1):
            ly = cy + int(y * 0.15)
            lx = cx + int(x * 0.25)
            ry = cy + int(y * 0.15)
            rx = cx - int(x * 0.25)
            mask[k, ly - 2:ly + 2, lx - 2:lx + 2] = True
            mask[k, ry - 2:ry + 2, rx - 2:rx + 2] = True
        return ndimage.binary_dilation(mask, iterations=1)

    def _generate_heart_mask(self, mediastinum_mask: np.ndarray,
                             spacing: Tuple[float, float, float]) -> np.ndarray:
        z, y, x = mediastinum_mask.shape
        heart = np.zeros_like(mediastinum_mask)
        cy, cx = y // 2, x // 2
        z0, z1 = int(0.42 * z), int(0.7 * z)
        for k in range(z0, z1):
            p = (k - z0) / max(1, z1 - z0 - 1)
            yr = int(y * (0.07 + 0.02 * np.cos(p * np.pi)))
            xr = int(x * (0.08 + 0.02 * np.cos(p * np.pi)))
            hy = cy + int(y * 0.10)
            hx = cx - int(x * 0.02)
            yy, xx = np.ogrid[:y, :x]
            superq = ((np.abs(yy - hy) / (yr + 1e-6)) ** 2.5 +
                      (np.abs(xx - hx) / (xr + 1e-6)) ** 2.5) <= 1
            heart[k] = superq
        return heart & mediastinum_mask

    def _add_diaphragm(self, vol: np.ndarray, lung_mask: np.ndarray,
                       spacing: Tuple[float, float, float]) -> np.ndarray:
        """
        Slightly deform lower lung zones to mimic diaphragm dome.
        """
        z, y, x = vol.shape
        base = int(0.75 * z)
        yy = np.arange(y)
        dome = (np.cos((yy - y * 0.7) / (0.3 * y + 1e-6) * np.pi) + 1) / 2
        dome = (dome * 0.25 * y).astype(int)
        for k in range(base, z):
            shift = np.clip(dome, 0, y - 1)
            lung_mask[k] &= np.roll(lung_mask[k], shift=shift, axis=0)
        return vol

    def _add_lobar_fissures(self, vol: np.ndarray, lung_mask: np.ndarray,
                            spacing: Tuple[float, float, float]) -> np.ndarray:
        """
        Add faint intensity changes to mimic lobar fissures.
        """
        z, y, x = vol.shape
        for k in range(int(0.35 * z), int(0.65 * z)):
            for col in range(int(0.35 * x), int(0.48 * x)):
                sl = lung_mask[k, :, col]
                if np.any(sl):
                    vol[k, sl, col] += self.rng.normal(15, 5, size=int(sl.sum()))
            for col in range(int(0.52 * x), int(0.65 * x)):
                sl = lung_mask[k, :, col]
                if np.any(sl):
                    vol[k, sl, col] += self.rng.normal(15, 5, size=int(sl.sum()))
        return vol

    def _quick_lung_mask(self, vol: np.ndarray) -> np.ndarray:
        mask = vol < -400
        mask = ndimage.binary_opening(mask, iterations=1)
        mask = ndimage.binary_closing(mask, iterations=2)
        return mask

    # ---------------------------
    # Physics / artifacts / noise
    # ---------------------------

    def _beam_cupping(self, vol: np.ndarray, body_mask: np.ndarray) -> np.ndarray:
        z, y, x = vol.shape
        cx = x // 2
        out = vol.copy()
        for k in range(z):
            if not np.any(body_mask[k]):
                continue
            col = (np.abs(np.arange(x) - cx) / max(1, x / 2))
            artifact = -20.0 * (1.0 - col)
            out[k] = np.clip(out[k] + artifact[np.newaxis, :],
                             self.config.hu_range[0], self.config.hu_range[1])
        return out

    def _add_motion(self, vol: np.ndarray) -> np.ndarray:
        out = vol.copy()
        z = vol.shape[0]
        n = int(self.rng.integers(1, 5))
        slices = self.rng.choice(z, size=n, replace=False)
        for k in slices:
            shift = (int(self.rng.integers(-3, 4)), int(self.rng.integers(-3, 4)))
            out[k] = ndimage.shift(out[k], shift=shift, order=1, mode='nearest')
        return out

    def _add_noise(self, vol: np.ndarray, body_mask: np.ndarray) -> np.ndarray:
        out = vol.astype(np.float32, copy=True)
        s = np.clip((out - self.config.air_hu) / 1000.0, 0.0, 2.0)
        sigma_q = 7.0 * self.config.noise_level * np.sqrt(0.5 + s)
        sigma_r = 3.0 * self.config.noise_level
        qn = self.rng.normal(0.0, sigma_q).astype(np.float32)
        rn = self.rng.normal(0.0, sigma_r, size=out.shape).astype(np.float32)
        out[body_mask] += (qn + rn)[body_mask]
        return out

    # ---------------------------
    # Value samplers
    # ---------------------------

    def _sample_tissue_values(self, size: int) -> np.ndarray:
        return self.rng.normal(
            self.config.tissue_hu_mean, self.config.tissue_hu_std, size
        ).astype(np.float32)

    def _sample_lung_values(self, size: int) -> np.ndarray:
        return self.rng.normal(
            self.config.lung_hu_mean, self.config.lung_hu_std, size
        ).astype(np.float32)

    def _sample_bone_values(self, size: int) -> np.ndarray:
        return self.rng.normal(
            self.config.bone_hu_mean, self.config.bone_hu_std, size
        ).astype(np.float32)

    def _sample_blood_values(self, size: int) -> np.ndarray:
        return self.rng.normal(self.config.blood_hu_mean, 20, size).astype(np.float32)

    # ---------------------------
    # Public helper: build nodule segmentation
    # ---------------------------

    def build_nodule_mask(
        self,
        vol_shape_zyx: Tuple[int, int, int],
        spacing_zyx: Tuple[float, float, float],
        dilation_mm: float = 0.0
    ) -> np.ndarray:
        """
        Construct a binary **nodule segmentation mask** (Z,Y,X) from the
        self.annotations['nodules'] produced during `generate()`.
        """
        mask = np.zeros(vol_shape_zyx, dtype=bool)
        anns = self.annotations.get("nodules", [])
        if not anns:
            return mask.astype(np.int8)

        dz, dy, dx = spacing_zyx
        for n in anns:
            cz, cy, cx = map(int, n["center_voxel"])
            d_mm = float(n.get("diameter_mm", 0.0))
            r_mm = max(0.1, d_mm / 2.0)
            ell = _ellipsoid_mask_at(
                center_zyx=np.array([cz, cy, cx]),
                radii_mm_zyx=(r_mm, r_mm, r_mm),
                spacing_zyx=spacing_zyx,
                vol_shape_zyx=vol_shape_zyx,
            )
            mask |= ell

        # Optional dilation in mm
        if dilation_mm > 0.0:
            rad_zyx = (
                max(1, int(round(dilation_mm / max(dz, 1e-6)))),
                max(1, int(round(dilation_mm / max(dy, 1e-6)))),
                max(1, int(round(dilation_mm / max(dx, 1e-6)))),
            )
            struct = ndimage.generate_binary_structure(3, 1)
            struct = ndimage.iterate_structure(struct, max(rad_zyx))
            mask = ndimage.binary_dilation(mask, structure=struct, iterations=1)

        return mask.astype(np.int8)

    def build_lesion_mask(
        self,
        vol_shape_zyx: Tuple[int, int, int],
        spacing_zyx: Tuple[float, float, float],
        dilation_mm: float = 0.0
    ) -> np.ndarray:
        """
        Construct a binary **lesion segmentation mask** (Z,Y,X) from the
        self.annotations['lesions'] produced during `generate()`.
        """
        mask = np.zeros(vol_shape_zyx, dtype=bool)
        anns = self.annotations.get("lesions", [])
        if not anns:
            return mask.astype(np.int8)

        dz, dy, dx = spacing_zyx
        for les in anns:
            cz, cy, cx = map(int, les["center_voxel"])
            d_mm = float(les.get("diameter_mm", 0.0))
            r_mm = max(0.1, d_mm / 2.0)
            ell = _ellipsoid_mask_at(
                center_zyx=np.array([cz, cy, cx]),
                radii_mm_zyx=(r_mm, r_mm, r_mm),
                spacing_zyx=spacing_zyx,
                vol_shape_zyx=vol_shape_zyx,
            )
            mask |= ell

        # Optional dilation in mm
        if dilation_mm > 0.0:
            rad_zyx = (
                max(1, int(round(dilation_mm / max(dz, 1e-6)))),
                max(1, int(round(dilation_mm / max(dy, 1e-6)))),
                max(1, int(round(dilation_mm / max(dx, 1e-6)))),
            )
            struct = ndimage.generate_binary_structure(3, 1)
            struct = ndimage.iterate_structure(struct, max(rad_zyx))
            mask = ndimage.binary_dilation(mask, structure=struct, iterations=1)

        return mask.astype(np.int8)
