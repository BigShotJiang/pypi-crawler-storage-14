from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Tuple, Dict, Any, Optional

import numpy as np
import pydicom
from pydicom.dataset import Dataset, FileDataset
from pydicom.uid import (
    ExplicitVRLittleEndian,
    ImplicitVRLittleEndian,
)

from .config import DICOMConfig
from .uid_generator import UIDGenerator


def _clean_sh(val: Optional[str]) -> str:
    """
    Sanitize for DICOM VR=SH (Short String), which has a max length of 16.
    Keep ASCII range and trim; return '' for None.
    """
    if val is None:
        return ""
    s = str(val)
    return s[:16] if len(s) > 16 else s


class DICOMExporter:
    """Export synthetic CT volumes as a DICOM series."""

    # CT Image Storage SOP Class UID
    CT_IMAGE_STORAGE = "1.2.840.10008.5.1.4.1.1.2"

    def __init__(self, config: DICOMConfig, uid_generator: UIDGenerator):
        self.config = config
        self.uid_gen = uid_generator

    def export_volume(
        self,
        volume: np.ndarray,                      # (Z, Y, X) int16
        output_dir: Path,
        patient_info: Dict[str, Any],
        study_info: Dict[str, Any],
        series_info: Dict[str, Any],
        spacing: Tuple[float, float, float],     # (dz, dy, dx) in mm
    ) -> Dict[str, Any]:
        """
        Export a 3D volume as a DICOM series (one file per slice).

        Returns a dict with study/series UIDs and file list.
        """
        if volume.ndim != 3:
            raise ValueError(f"volume must be 3D (Z,Y,X); got {volume.shape}")
        
        # FIX: Detect and fix shape ordering if necessary
        if volume.shape[0] > 200 and volume.shape[2] < 200:
            # Input appears to be (Y, X, Z) - convert to (Z, Y, X)
            volume = np.moveaxis(volume, -1, 0)
            # Also need to adjust spacing order
            if len(spacing) == 3 and spacing[0] > 2.0 and spacing[2] < 2.0:
                # spacing likely in (dy, dx, dz) order, reorder to (dz, dy, dx)
                spacing = (spacing[2], spacing[0], spacing[1])

        output_dir.mkdir(parents=True, exist_ok=True)

        z_slices, height, width = volume.shape
        dz, dy, dx = spacing

        # Generate UIDs
        study_uid = self.uid_gen.generate_study_uid(
            patient_info.get("patient_id", "SYNTH001"),
            study_info.get("study_datetime", datetime.now()),
        )
        series_uid = self.uid_gen.generate_series_uid(study_uid, series_info.get("series_number", 1))
        frame_of_ref_uid = self.uid_gen.generate_frame_of_reference_uid(study_uid)

        meta = {
            "study_instance_uid": study_uid,
            "series_instance_uid": series_uid,
            "frame_of_reference_uid": frame_of_ref_uid,
            "dicom_files": [],
        }

        # Write one slice per file
        for k in range(z_slices):
            instance_uid = self.uid_gen.generate_instance_uid(series_uid, k + 1)

            ds = self._create_dicom_dataset(
                slice_data=volume[k],
                patient_info=patient_info,
                study_info=study_info,
                series_info=series_info,
                study_uid=study_uid,
                series_uid=series_uid,
                frame_of_ref_uid=frame_of_ref_uid,
                instance_uid=instance_uid,
                instance_number=k + 1,
                total_slices=z_slices,
                pixel_spacing=(dy, dx),
                slice_spacing=dz,
                slice_location=k * dz,
            )

            filename = f"IM{(k + 1):04d}.dcm"
            filepath = output_dir / filename
            # Modern pydicom: enforce writing valid meta via write_like_original=False
            ds.save_as(filepath, write_like_original=False)
            meta["dicom_files"].append(str(filepath))

        return meta

    def _create_dicom_dataset(
        self,
        slice_data: np.ndarray,                       # (Y, X) int16
        patient_info: Dict[str, Any],
        study_info: Dict[str, Any],
        series_info: Dict[str, Any],
        study_uid: str,
        series_uid: str,
        frame_of_ref_uid: str,
        instance_uid: str,
        instance_number: int,
        total_slices: int,
        pixel_spacing: Tuple[float, float],           # (dy, dx) in mm
        slice_spacing: float,                         # dz in mm
        slice_location: float,                        # z position in mm
    ) -> FileDataset:
        """Create a DICOM dataset for a single CT slice."""
        if slice_data.ndim != 2:
            raise ValueError(f"slice_data must be 2D (Y,X); got {slice_data.shape}")

        # ---------- File Meta ----------
        file_meta = Dataset()

        # Choose transfer syntax (default Explicit VR Little Endian)
        ts_uid = getattr(self.config, "transfer_syntax_uid", None) or str(ExplicitVRLittleEndian)
        file_meta.TransferSyntaxUID = ts_uid
        file_meta.MediaStorageSOPClassUID = self.CT_IMAGE_STORAGE
        file_meta.MediaStorageSOPInstanceUID = instance_uid
        file_meta.ImplementationClassUID = self.uid_gen.generate_uid()
        file_meta.ImplementationVersionName = _clean_sh("SYNTH_CT_1_0")
        file_meta.FileMetaInformationVersion = b"\x00\x01"

        # Create FileDataset (dummy filename ok)
        ds = FileDataset("", {}, file_meta=file_meta,
                         is_little_endian=True,
                         is_implicit_VR=(ts_uid == str(ImplicitVRLittleEndian)))

        # ---------- Patient ----------
        ds.PatientName = patient_info.get("patient_name", "SYNTH^PATIENT")  # PN
        ds.PatientID = str(patient_info.get("patient_id", "SYNTH001"))      # LO/CS
        ds.PatientBirthDate = patient_info.get("birth_date", "")            # DA (YYYYMMDD or '')
        ds.PatientSex = patient_info.get("sex", "O")                        # CS

        # ---------- Study ----------
        ds.StudyInstanceUID = study_uid
        study_dt = study_info.get("study_datetime", datetime.now())
        ds.StudyDate = study_dt.strftime("%Y%m%d")
        ds.StudyTime = study_dt.strftime("%H%M%S")
        ds.ReferringPhysicianName = study_info.get("referring_physician", "")

        ds.StudyID = _clean_sh(study_info.get("study_id", "1"))                   # SH
        ds.AccessionNumber = _clean_sh(study_info.get("accession_number", ""))    # SH
        ds.StudyDescription = getattr(self.config, "study_description", "CT STUDY")

        # ---------- Series ----------
        ds.SeriesInstanceUID = series_uid
        series_dt = series_info.get("series_datetime", study_dt)
        ds.SeriesDate = series_dt.strftime("%Y%m%d")
        ds.SeriesTime = series_dt.strftime("%H%M%S")
        ds.Modality = getattr(self.config, "modality", "CT")
        ds.SeriesDescription = getattr(self.config, "series_description", "Synthetic CT")
        ds.SeriesNumber = int(series_info.get("series_number", 1))  # IS
        ds.ImagesInAcquisition = str(total_slices)                  # CS/IS-like (string per standard)

        # ---------- Frame of Reference ----------
        ds.FrameOfReferenceUID = frame_of_ref_uid
        ds.PositionReferenceIndicator = ""  # optional

        # ---------- Equipment ----------
        ds.Manufacturer = getattr(self.config, "manufacturer", "SynthCT")
        ds.ManufacturerModelName = getattr(self.config, "manufacturer_model", "SyntheticCTGenerator")
        ds.StationName = _clean_sh(getattr(self.config, "station_name", "SYNTH_STATION"))
        ds.InstitutionName = getattr(self.config, "institution_name", "Synthetic Medical Center")

        kvp = getattr(self.config, "kvp", None)
        if kvp is not None:
            ds.KVP = float(kvp)

        exposure_time = getattr(self.config, "exposure_time", None)
        if exposure_time is not None:
            ds.ExposureTime = float(exposure_time)

        tube_current = getattr(self.config, "x_ray_tube_current", None)
        if tube_current is not None:
            ds.XRayTubeCurrent = float(tube_current)

        # ---------- Image Geometry ----------
        # Keep spacing order (dy, dx) and make IOP consistent:
        #   rows -> +Y, cols -> +X
        ds.ImageOrientationPatient = [1, 0, 0, 0, 1, 0]
        ds.ImagePositionPatient = [0.0, 0.0, float(slice_location)]
        ds.SliceLocation = float(slice_location)
        ds.SliceThickness = float(slice_spacing)
        ds.SpacingBetweenSlices = float(slice_spacing)
        ds.PixelSpacing = [float(pixel_spacing[0]), float(pixel_spacing[1])]  # (row, col) = (dy, dx)

        # ---------- Pixel Module ----------
        ds.SamplesPerPixel = 1
        ds.PhotometricInterpretation = "MONOCHROME2"
        ds.Rows = int(slice_data.shape[0])
        ds.Columns = int(slice_data.shape[1])
        ds.BitsAllocated = 16
        ds.BitsStored = 16
        ds.HighBit = 15
        ds.PixelRepresentation = 1  # signed

        # HU already in data
        ds.RescaleIntercept = 0
        ds.RescaleSlope = 1
        ds.RescaleType = "HU"

        # Optional windowing from config
        wc = getattr(self.config, "window_center", None)
        ww = getattr(self.config, "window_width", None)
        if wc is not None and ww is not None:
            ds.WindowCenter = float(wc)
            ds.WindowWidth = float(ww)

        # ---------- SOP Common ----------
        ds.SOPClassUID = self.CT_IMAGE_STORAGE
        ds.SOPInstanceUID = instance_uid
        now = datetime.now()
        ds.InstanceCreationDate = now.strftime("%Y%m%d")
        ds.InstanceCreationTime = now.strftime("%H%M%S")
        ds.InstanceNumber = int(instance_number)

        # ---------- Pixel Data ----------
        # Ensure contiguous little-endian int16 buffer for Explicit VR Little Endian
        if slice_data.dtype != np.int16 or slice_data.dtype.byteorder not in ("<", "="):
            data16 = slice_data.astype("<i2", copy=False)
        else:
            data16 = np.ascontiguousarray(slice_data)
        ds.PixelData = data16.tobytes()

        return ds