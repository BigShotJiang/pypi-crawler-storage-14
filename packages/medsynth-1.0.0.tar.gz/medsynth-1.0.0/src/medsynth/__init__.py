"""
Synthetic CT Generator
----------------------
Gold-standard synthetic 3D chest CT generator with:
- DICOM/NRRD export
- OMOP-CDM integration
- Optional augmentation of *real* CT volumes (e.g., from TCIA)
"""

__version__ = "1.0.0"
__author__ = "Ankur Lohachab"
__email__ = "ankur.lohachab@maastrichtuniversity.nl"
__institution__ = "Department of Advanced Computing Sciences, Maastricht University"

# Core configuration and top-level pipeline
from .config import (
    Config,
    VolumeConfig,
    AnatomicalFeaturesConfig,
    DICOMConfig,
    OMOPConfig,
    OutputConfig,
    get_default_config,
)
from .pipeline import SyntheticCTPipeline

# Volume synthesis / augmentation
from .volume_generator import ChestCTVolumeGenerator

# IO / export utilities
from .dicom_exporter import DICOMExporter
from .nrrd_exporter import NRRDExporter
from .omop_generator import OMOPCDMGenerator
from .uid_generator import UIDGenerator, AccessionNumberGenerator, PatientIDGenerator

# ---- TCIA loader exports -----------------------------------------------------
# Prefer the canonical module name `tcia_ct_loader`. For back-compat, try
# falling back to a legacy name if a user has it locally.
try:
    from .tcia_ct_loader import (
        find_ct_series,
        load_ct_series,
        resample_isotropic,
        load_numpy,  # convenience: (np.ndarray Z,Y,X int16, spacing (dz,dy,dx))
    )
except Exception:  # pragma: no cover
    # Optional fallback if someone kept an older file name locally.
    from .tcia_loader import (  # type: ignore
        find_ct_series,
        load_ct_series,
        resample_isotropic,
    )
    # `load_numpy` may not exist in older loader; make it optional
    try:  # pragma: no cover
        from .tcia_loader import load_numpy  # type: ignore
    except Exception:  # pragma: no cover
        load_numpy = None  # sentinel; caller can guard against None

# Public API
__all__ = [
    # Config / pipeline
    "Config",
    "VolumeConfig",
    "AnatomicalFeaturesConfig",
    "DICOMConfig",
    "OMOPConfig",
    "OutputConfig",
    "get_default_config",
    "SyntheticCTPipeline",
    # Generator
    "ChestCTVolumeGenerator",
    # Exporters
    "DICOMExporter",
    "NRRDExporter",
    "OMOPCDMGenerator",
    "UIDGenerator",
    "AccessionNumberGenerator",
    "PatientIDGenerator",
    # TCIA loader utilities
    "find_ct_series",
    "load_ct_series",
    "resample_isotropic",
    "load_numpy",
]
