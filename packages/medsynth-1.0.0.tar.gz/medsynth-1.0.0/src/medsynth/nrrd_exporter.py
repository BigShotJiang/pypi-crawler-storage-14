# src/medsynth/nrrd_exporter.py
from __future__ import annotations

import os
from pathlib import Path
from typing import Tuple, Dict, Any, Optional

import numpy as np
import nrrd


# ----------------------------
# Small utilities / validators
# ----------------------------

def _validate_spacing(spacing: Tuple[float, float, float]) -> Tuple[float, float, float]:
    """
    spacing is always interpreted as (dz, dy, dx) in mm.
    """
    if len(spacing) != 3:
        raise ValueError("spacing must be a (dz, dy, dx) tuple in mm.")
    dz, dy, dx = [float(s) for s in spacing]
    if dz <= 0 or dy <= 0 or dx <= 0:
        raise ValueError(f"Invalid spacing values: {spacing}")
    return dz, dy, dx


def _lps_space_directions_for_zyx(spacing_zyx: Tuple[float, float, float]):
    """
    OLD helper (kept for backwards compatibility in case something else imports it).

    Arrays are (Z,Y,X). NRRD header needs 3-vectors (per axis) in **LPS** space:
      axis 0 (Z) -> +Z => (0, 0, dz)
      axis 1 (Y) -> +Y => (0, dy, 0)
      axis 2 (X) -> +X => (dx, 0, 0)

    NOTE: The main exporter below now writes data in (X,Y,Z) order for
    SimpleITK / DuneAI compatibility, so this helper is no longer used
    by the internal header builder.
    """
    dz, dy, dx = spacing_zyx
    return [
        [0.0, 0.0, dz],
        [0.0, dy, 0.0],
        [dx, 0.0, 0.0],
    ]


def _lps_space_directions_for_xyz(spacing_zyx: Tuple[float, float, float]):
    """
    New helper for the ACTUAL written NRRDs.

    We store the data as (X, Y, Z) in the NRRD file so that:
      - NRRD axes:       0    1    2
      - Physical axes:   X    Y    Z  (LPS space)
      - SimpleITK image: size=(X,Y,Z), spacing=(dx,dy,dz)
      - GetArrayFromImage -> numpy (Z, Y, X)

    spacing_zyx: (dz, dy, dx)
    """
    dz, dy, dx = spacing_zyx
    return [
        [dx, 0.0, 0.0],   # axis 0 = X
        [0.0, dy, 0.0],   # axis 1 = Y
        [0.0, 0.0, dz],   # axis 2 = Z
    ]


def _coerce_order_to_zyx(arr: np.ndarray,
                         array_order: Optional[str] = None,
                         debug: bool = False) -> np.ndarray:
    """
    Ensure array is (Z,Y,X) in *Python memory*.

    If array_order is provided, reorder exactly.
    Otherwise: heuristic: if shape looks like (Y, X, Z) (e.g., 512,512,<=256) treat as YXZ.
    """
    if arr.ndim != 3:
        raise ValueError(f"Expected 3D array, got shape={arr.shape}")

    if array_order is not None:
        o = array_order.lower()
        if debug:
            print(f"[NRRDExporter] array_order explicitly set to '{o}'. Incoming shape={arr.shape}")
        if o == "zyx":
            return arr
        elif o == "yxz":
            # (Y,X,Z) -> (Z,Y,X)
            out = np.moveaxis(arr, -1, 0)
            if debug:
                print(f"[NRRDExporter] Reordered YXZ -> ZYX. New shape={out.shape}")
            return out
        elif o == "xyz":
            # (X,Y,Z) -> (Z,Y,X)
            out = np.transpose(arr, (2, 1, 0))
            if debug:
                print(f"[NRRDExporter] Reordered XYZ -> ZYX. New shape={out.shape}")
            return out
        else:
            raise ValueError(f"Unknown array_order='{array_order}'")

    # --- Heuristic auto-detect ---
    d0, d1, d2 = arr.shape
    looks_yxz = (d0 == d1 and d0 >= 256 and d2 < d0)  # e.g., 512x512x128
    if looks_yxz:
        if debug:
            print(f"[NRRDExporter] Heuristic: looks like (Y,X,Z). "
                  f"Incoming shape={arr.shape} -> moving last axis to front.")
        out = np.moveaxis(arr, -1, 0)
        if debug:
            print(f"[NRRDExporter] New shape after heuristic reorder: {out.shape}")
        return out

    if debug:
        print(f"[NRRDExporter] Assuming incoming is already (Z,Y,X). Shape={arr.shape}")
    return arr


def _summarize_array(tag: str, a: np.ndarray):
    a = np.asarray(a)
    mins, maxs = float(a.min()), float(a.max())
    print(f"[NRRDExporter] {tag}: shape={a.shape} dtype={a.dtype} "
          f"min={mins:.1f} max={maxs:.1f}")


# -------------
# Main exporter
# -------------

class NRRDExporter:
    """
    Export volumes and labelmaps as NRRD (LPS geometry).

    **Contract in Python:**
      - You pass arrays as (Z, Y, X).

    **What this exporter writes on disk:**
      - Data is stored as (X, Y, Z) in the NRRD file.
      - Header 'sizes' is (X, Y, Z).
      - 'space directions' is diag([dx, dy, dz]) in LPS.

    This way, when SimpleITK reads the NRRD and you call
      np.array(sitk.GetArrayFromImage(image)),
    you get back (Z, Y, X) — exactly what DuneAI expects.
    """

    def __init__(self, compress: bool = True, debug: bool = True):
        self.compress = bool(compress)
        # Enable verbose prints if either arg or env var is set
        self.debug = bool(debug or os.environ.get("SYNTHCT_NRRD_DEBUG"))

    # --------------------------
    # Public API
    # --------------------------

    def export_volume(
        self,
        volume: np.ndarray,
        output_path: Path,
        spacing: Tuple[float, float, float],
        metadata: Dict[str, Any] | None = None,
        array_order: Optional[str] = None,   # 'zyx' | 'yxz' | 'xyz' | None (auto)
    ) -> Dict[str, Any]:
        """
        Save a CT volume as NRRD.

        Input:
          - volume: 3D array, expected orientation in PYTHON: (Z, Y, X).
          - spacing: (dz, dy, dx) in mm.
        On disk:
          - data is stored as (X, Y, Z) so SimpleITK will read back (Z,Y,X).
        """
        if volume.ndim != 3:
            raise ValueError(f"volume must be 3D, got shape={volume.shape}")

        dz, dy, dx = _validate_spacing(spacing)
        if self.debug:
            print("\n[NRRDExporter] === export_volume ===")
            _summarize_array("incoming volume", volume)
            print(f"[NRRDExporter] requested spacing (dz,dy,dx) = {(dz,dy,dx)}")
            if array_order:
                print(f"[NRRDExporter] array_order={array_order}")

        # Ensure (Z,Y,X) in memory
        vol_zyx = _coerce_order_to_zyx(np.asarray(volume), array_order, debug=self.debug)

        # Keep HU as int16 (don’t scale).
        if vol_zyx.dtype != np.int16:
            if self.debug:
                print(f"[NRRDExporter] Casting volume to int16 from {vol_zyx.dtype}")
            vol_zyx = vol_zyx.astype(np.int16, copy=False)

        # For NRRD / SimpleITK compatibility: store as (X,Y,Z)
        # so that GetArrayFromImage returns (Z,Y,X) == vol_zyx.
        vol_xyz = np.transpose(vol_zyx, (2, 1, 0))  # (X, Y, Z)
        shape_xyz = vol_xyz.shape

        hdr = self._base_header(
            shape=shape_xyz,
            spacing=(dz, dy, dx),
            dtype="int16",
            space_origin=(0.0, 0.0, 0.0),
        )
        self._attach_metadata(hdr, metadata)

        if self.debug:
            _summarize_array("final volume array_for_nrrd", vol_xyz)
            print(f"[NRRDExporter] header.sizes                 = {hdr['sizes']}")
            print(f"[NRRDExporter] header.space                 = {hdr['space']}")
            print(f"[NRRDExporter] header.space directions      = {hdr['space directions']}")
            print(f"[NRRDExporter] header.space origin          = {hdr['space origin']}")
            print(f"[NRRDExporter] header.type/encoding/endian  = "
                  f"{hdr['type']}/{hdr['encoding']}/{hdr['endian']}")
            if metadata:
                keep = {k: metadata[k] for k in metadata if k in (
                    "modality", "patient_id", "patient_name",
                    "study_instance_uid", "series_instance_uid", "body_part",
                    "kvp", "window_center", "window_width"
                )}
                if keep:
                    print(f"[NRRDExporter] selected meta              = {keep}")

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        nrrd.write(
            str(output_path),
            vol_xyz,
            header=hdr,
            compression_level=9 if self.compress else 0,
        )

        if self.debug:
            print(f"[NRRDExporter] wrote: {output_path}\n")

        return {
            "nrrd_file": str(output_path),
            "shape_zyx": tuple(vol_zyx.shape),
            "spacing_zyx": (dz, dy, dx),
            "dtype": str(vol_zyx.dtype),
        }

    def export_labelmap(
        self,
        mask: np.ndarray,
        output_path: Path,
        spacing: Tuple[float, float, float],
        label_value: int = 1,
        metadata: Dict[str, Any] | None = None,
        array_order: Optional[str] = None,   # 'zyx' | 'yxz' | 'xyz' | None (auto)
    ) -> Dict[str, Any]:
        """
        Save a binary/label mask as NRRD aligned with the CT.

        Input:
          - mask: 3D array, expected orientation: (Z, Y, X).
        On disk:
          - stored as (X, Y, Z) to match export_volume.
        Any non-zero in `mask` becomes `label_value` (uint8).
        """
        if mask.ndim != 3:
            raise ValueError(f"mask must be 3D, got shape={mask.shape}")

        dz, dy, dx = _validate_spacing(spacing)
        if self.debug:
            print("\n[NRRDExporter] === export_labelmap ===")
            _summarize_array("incoming mask", mask)
            print(f"[NRRDExporter] requested spacing (dz,dy,dx) = {(dz,dy,dx)}")
            if array_order:
                print(f"[NRRDExporter] array_order={array_order}")

        # Ensure (Z,Y,X) in memory
        m_zyx = _coerce_order_to_zyx(np.asarray(mask), array_order, debug=self.debug)

        out_zyx = np.zeros_like(m_zyx, dtype=np.uint8)
        nz = m_zyx.astype(bool)
        out_zyx[nz] = np.uint8(label_value)

        # Store as (X,Y,Z) in NRRD
        out_xyz = np.transpose(out_zyx, (2, 1, 0))
        shape_xyz = out_xyz.shape

        hdr = self._base_header(
            shape=shape_xyz,
            spacing=(dz, dy, dx),
            dtype="uint8",
            space_origin=(0.0, 0.0, 0.0),
        )
        # Labelmap hints
        hdr["modality"] = "SEG"
        hdr["kinds"] = ["domain", "domain", "domain"]
        if metadata and "seg_label" in metadata:
            hdr["seg_label"] = str(metadata["seg_label"])
        self._attach_metadata(hdr, metadata)

        if self.debug:
            _summarize_array("final labelmap array_for_nrrd", out_xyz)
            print(f"[NRRDExporter] non-zero voxels = {int(nz.sum())}")
            print(f"[NRRDExporter] header.sizes    = {hdr['sizes']}")

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        nrrd.write(
            str(output_path),
            out_xyz,
            header=hdr,
            compression_level=9 if self.compress else 0,
        )

        if self.debug:
            print(f"[NRRDExporter] wrote: {output_path}\n")

        return {
            "nrrd_file": str(output_path),
            "shape_zyx": tuple(out_zyx.shape),
            "spacing_zyx": (dz, dy, dx),
            "dtype": str(out_zyx.dtype),
            "label_value": int(label_value),
            "nonzero_voxels": int(nz.sum()),
        }

    # --------------------------
    # Header helpers
    # --------------------------

    def _base_header(
        self,
        shape: Tuple[int, int, int],
        spacing: Tuple[float, float, float],
        dtype: str,
        space_origin: Tuple[float, float, float] = (0.0, 0.0, 0.0),
    ) -> Dict[str, Any]:
        """
        shape:   shape of the ARRAY WRITTEN TO NRRD (we now use (X,Y,Z)).
        spacing: (dz, dy, dx) in mm – we internally map to dx,dy,dz
                 for the space directions.
        """
        dz, dy, dx = spacing
        hdr: Dict[str, Any] = {
            "type": dtype,                         # 'int16' for HU, 'uint8' for labels
            "dimension": 3,
            "space": "left-posterior-superior",    # LPS
            "sizes": tuple(int(s) for s in shape), # (X, Y, Z)
            "space directions": _lps_space_directions_for_xyz((dz, dy, dx)),
            "kinds": ["domain", "domain", "domain"],
            "endian": "little",
            "encoding": "gzip" if self.compress else "raw",
            "space origin": tuple(float(v) for v in space_origin),
        }
        return hdr

    def _attach_metadata(self, header: Dict[str, Any], metadata: Dict[str, Any] | None):
        if not metadata:
            return
        for k, v in metadata.items():
            if v is None:
                continue
            if isinstance(v, (str, int, float, bool)):
                header[str(k)] = v
