from __future__ import annotations

from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import asdict, is_dataclass
import json
import random

import numpy as np
import SimpleITK as sitk  # loader for real CT (NRRD/NIfTI/DICOM)

from .config import Config
from .volume_generator import ChestCTVolumeGenerator
from .dicom_exporter import DICOMExporter
from .nrrd_exporter import NRRDExporter
from .omop_generator import OMOPCDMGenerator
from .uid_generator import UIDGenerator, AccessionNumberGenerator, PatientIDGenerator


# ----------------------------
# JSON helper
# ----------------------------

def _jsonify(obj):
    if is_dataclass(obj):
        return asdict(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# ----------------------------
# Real-CT loading helpers (compatible with TCIA loader style)
# ----------------------------

def _sitk_spacing_zyx(img: sitk.Image) -> Tuple[float, float, float]:
    # SimpleITK reports spacing in (X, Y, Z); convert to (Z, Y, X)
    dx, dy, dz = img.GetSpacing()
    return float(dz), float(dy), float(dx)


def _load_real_ct_any(path: Path) -> Tuple[np.ndarray, Tuple[float, float, float]]:
    """
    Load a CT volume from:
      - a single file (NRRD, NIfTI, MHD, etc.)
      - a directory of DICOM slices
    Returns (array_zyx int16, spacing_zyx floats).
    """
    path = Path(path)
    if path.is_file():
        print(f"[load] Loading single image file: {path}")
        img = sitk.ReadImage(str(path))
        arr_zyx = sitk.GetArrayFromImage(img).astype(np.int16)  # (Z,Y,X)
        spacing_zyx = _sitk_spacing_zyx(img)
        print(f"[load] Loaded file -> shape(Z,Y,X)={arr_zyx.shape} spacing(dz,dy,dx)={spacing_zyx}")
        return arr_zyx, spacing_zyx

    if path.is_dir():
        print(f"[load] Scanning DICOM series under: {path}")
        reader = sitk.ImageSeriesReader()
        series_uids = reader.GetGDCMSeriesIDs(str(path))
        if not series_uids:
            raise FileNotFoundError(f"No DICOM series found in directory: {path}")
        # pick the longest series
        best_uid, best_len = None, -1
        for uid in series_uids:
            files = reader.GetGDCMSeriesFileNames(str(path), uid)
            if len(files) > best_len:
                best_len = len(files)
                best_uid = uid
        files = reader.GetGDCMSeriesFileNames(str(path), best_uid)
        print(f"[load] Selected SeriesInstanceUID={best_uid} with {len(files)} slices")
        reader.SetFileNames(files)
        img = reader.Execute()
        arr_zyx = sitk.GetArrayFromImage(img).astype(np.int16)  # (Z,Y,X)
        spacing_zyx = _sitk_spacing_zyx(img)
        print(f"[load] Loaded DICOM -> shape(Z,Y,X)={arr_zyx.shape} spacing(dz,dy,dx)={spacing_zyx}")
        return arr_zyx, spacing_zyx

    raise FileNotFoundError(f"Input not found: {path}")


# ----------------------------
# Pipeline
# ----------------------------

class SyntheticCTPipeline:
    """Main pipeline for generating synthetic CT data with OMOP integration and privacy-preserving synthesis support."""

    def __init__(self, config: Config):
        self.config = config

        # RNG / IDs
        self.uid_gen = UIDGenerator(seed=config.random_seed)
        self.accession_gen = AccessionNumberGenerator(seed=config.random_seed)
        self.patient_id_gen = PatientIDGenerator(seed=config.random_seed)

        self.volume_gen = ChestCTVolumeGenerator(self._volume_config(), seed=config.random_seed)
        self.dicom_exporter = DICOMExporter(self._dicom_config(), self.uid_gen)
        self.nrrd_exporter = NRRDExporter()
        self.omop_gen = OMOPCDMGenerator(self._omop_config())

        # Reproducibility
        if config.random_seed is not None:
            random.seed(config.random_seed)
            np.random.seed(config.random_seed)

        # Accept an augmentation input path
        self.augmentation_input: Optional[Path] = None
        aug = getattr(self.config, "augmentation_input", None)
        if aug is None:
            aug = getattr(self.config.volume, "augmentation_input", None)
        if aug:
            self.augmentation_input = Path(aug)

        # Privacy-synthesis mode flag
        self.privacy_synth_mode: bool = False
        psm = getattr(self.config, "privacy_synth_mode", None)
        if psm is None:
            psm = getattr(self.config.volume, "privacy_synth_mode", None)
        if psm is not None:
            self.privacy_synth_mode = bool(psm)

    # --------- helpers to accept dataclass OR dict ---------

    def _section_get(self, section: Any, key: str, default: Any = None):
        if section is None:
            return default
        if hasattr(section, key):
            return getattr(section, key, default)
        if isinstance(section, dict):
            return section.get(key, default)
        return default

    def _output_get(self, key: str, default: Any = None):
        defaults = {
            "metadata_subdir": "metadata",
            "dicom_subdir": "dicom",
            "nrrd_subdir": "nrrd",
            "omop_subdir": "omop",
        }
        val = self._section_get(self.config.output, key, defaults.get(key, default))
        if key.endswith("_root") and val is not None:
            return Path(val)
        return val

    def _volume_get(self, key: str, default: Any = None):
        return self._section_get(self.config.volume, key, default)

    def _dicom_config(self):
        return self.config.dicom

    def _omop_config(self):
        return self.config.omop

    def _volume_config(self):
        return self.config.volume

    # ----------------------------------------------------------------

    def generate_dataset(self) -> Dict[str, Any]:
        print(f"Generating {self.config.num_subjects} CT study/studies...")
        if self.privacy_synth_mode and self.augmentation_input:
            print(f"[PRIVACY-SYNTHESIS] Will apply MS-STS to reduce mutual information")
        elif self.augmentation_input:
            print(f"[AUGMENTATION MODE] Will augment real CT (NOT privacy-safe)")
        else:
            print(f"[SYNTHESIS MODE] Pure synthetic generation")
        
        self._setup_output_structure()

        generation_metadata: Dict[str, Any] = {
            "config": self._config_to_dict(),
            "generation_datetime": datetime.now().isoformat(),
            "mode": self._get_generation_mode(),
            "subjects": []
        }

        for subject_idx in range(self.config.num_subjects):
            print(f"\nGenerating subject {subject_idx + 1}/{self.config.num_subjects}...")
            subject_data = self._generate_subject(subject_idx)
            generation_metadata["subjects"].append(subject_data)

        if self._output_get('generate_omop', False):
            print("\nExporting OMOP-CDM data...")
            omop_dir = self._output_get('output_root') / self._output_get('omop_subdir')
            omop_dir.mkdir(parents=True, exist_ok=True)
            omop_files = self.omop_gen.export_to_csv(
                tables=[
                    "PERSON",
                    "VISIT_OCCURRENCE",
                    "DEVICE_EXPOSURE",
                    "CONDITION_OCCURRENCE",
                    "OBSERVATION",
                    "REALM_FILE",
                    "RADIOLOGY_OCCURRENCE",
                    "RADIOLOGY_IMAGE",
                ],
                output_dir=omop_dir
            )
            self.omop_gen.create_metadata_json(omop_dir / 'omop_metadata.json')
            generation_metadata['omop_files'] = omop_files

        meta_path = self._output_get('output_root') / self._output_get('metadata_subdir') / 'generation_metadata.json'
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        with open(meta_path, 'w') as f:
            json.dump(generation_metadata, f, indent=2, default=_jsonify)

        print(f"\n{'='*60}")
        print(f"Dataset generation complete!")
        print(f"Output directory: {self._output_get('output_root')}")
        print(f"Mode: {self._get_generation_mode()}")
        print(f"{'='*60}")
        return generation_metadata

    def _get_generation_mode(self) -> str:
        """Return human-readable generation mode."""
        if self.privacy_synth_mode and self.augmentation_input:
            return "privacy_synthesis"
        elif self.augmentation_input:
            return "augmentation"
        else:
            return "synthesis"

    def _generate_subject(self, subject_idx: int) -> Dict[str, Any]:
        # Demographics
        patient_id = self.patient_id_gen.generate(subject_idx)
        birth_date = self._generate_birth_date()
        sex = random.choice(['M', 'F'])
        patient_info = {
            'patient_id': patient_id,
            'patient_name': f"SYNTH^PATIENT{subject_idx:04d}",
            'birth_date': birth_date.strftime('%Y%m%d'),
            'sex': sex
        }

        # Study/series
        study_datetime = self._generate_study_datetime()
        accession_number = self.accession_gen.generate(patient_id, study_datetime)
        study_info = {
            'study_datetime': study_datetime,
            'accession_number': accession_number,
            'study_id': f"{subject_idx + 1}",
            'referring_physician': 'SYNTH^PHYSICIAN'
        }
        series_info = {'series_number': 1, 'series_datetime': study_datetime}

        # ----------------------------
        # Generate CT Volume
        # ----------------------------
        volume, masks_dict, used_spacing_zyx, annotations = self._generate_volume()

        # Output dirs
        study_dir = self._get_study_directory(patient_id, study_datetime)

        # DICOM
        dicom_metadata: Optional[Dict[str, Any]] = None
        if self._output_get('generate_dicom', True):
            print("  Exporting DICOM series...")
            dicom_dir = study_dir / self._output_get('dicom_subdir') / f"SERIES{series_info['series_number']:03d}"
            dicom_metadata = self.dicom_exporter.export_volume(
                volume, dicom_dir, patient_info, study_info, series_info, used_spacing_zyx
            )
            print(f"    → DICOM series: {dicom_dir}")

        # NRRD
        nrrd_metadata: Optional[Dict[str, Any]] = None
        if self._output_get('generate_nrrd', False):
            print("  Exporting NRRD file(s)...")
            nrrd_dir = study_dir / self._output_get('nrrd_subdir')
            nrrd_dir.mkdir(parents=True, exist_ok=True)

            # CT volume
            nrrd_file = nrrd_dir / f"SERIES{series_info['series_number']:03d}.nrrd"
            nrrd_export_metadata = {
                'patient_id': patient_id,
                'study_instance_uid': dicom_metadata['study_instance_uid'] if dicom_metadata else '',
                'series_instance_uid': dicom_metadata['series_instance_uid'] if dicom_metadata else '',
                'modality': 'CT',
                'generation_mode': self._get_generation_mode(),
            }
            info_ct = self.nrrd_exporter.export_volume(
                volume, nrrd_file, used_spacing_zyx, nrrd_export_metadata, array_order="zyx"
            )

            nrrd_metadata = info_ct
            print(f"    → CT volume: {info_ct.get('nrrd_file', nrrd_file)}")

            # Export segmentation masks if requested
            if self._output_get('save_segmentation_masks', True) and masks_dict:
                self._export_segmentation_masks(
                    masks_dict, nrrd_dir, series_info, patient_id, used_spacing_zyx
                )

        # Save annotations JSON
        if self._output_get('save_annotations', True):
            ann_dir = study_dir / "annotations"
            ann_dir.mkdir(parents=True, exist_ok=True)
            ann_path = ann_dir / "annotations.json"
            with open(ann_path, "w") as f:
                json.dump(
                    {
                        "patient_id": patient_id,
                        "study_date": study_datetime.strftime("%Y%m%d"),
                        "series_number": series_info["series_number"],
                        "spacing": used_spacing_zyx,
                        "generation_mode": self._get_generation_mode(),
                        "annotations": annotations or {},
                    },
                    f,
                    indent=2,
                    default=_jsonify,
                )
            print(f"    → Annotations: {ann_path}")

        # ----------------------------
        # OMOP rows (aligned to RWD)
        # ----------------------------
        person_record = self.omop_gen.generate_person_record(patient_id, birth_date, sex)
        visit_record = self.omop_gen.generate_visit_occurrence_record(
            person_record['person_id'], study_datetime, 'outpatient'
        )

        # DEVICE_EXPOSURE for the CT study
        self.omop_gen.generate_device_exposure_record(
            person_id=person_record['person_id'],
            visit_occurrence_id=visit_record['visit_occurrence_id'],
            start_datetime=study_datetime,
            modality='CT',
            manufacturer=getattr(self._dicom_config(), "manufacturer", None),
            unique_device_id=None,
            study_instance_uid=(dicom_metadata or {}).get('study_instance_uid')
        )

        # CONDITION_OCCURRENCE (example baseline code)
        self.omop_gen.generate_condition_occurrence_record(
            person_id=person_record['person_id'],
            visit_occurrence_id=visit_record['visit_occurrence_id'],
            start_date=study_datetime,
            condition_concept_id=4115276,  # Malignant neoplasm of bronchus and lung
            condition_source_value='C34'
        )

        # OBSERVATIONs (optional examples)
        self.omop_gen.generate_observation_stage_record(
            person_id=person_record['person_id'],
            visit_occurrence_id=visit_record['visit_occurrence_id'],
            dt=study_datetime,
            stage_text=None
        )
        self.omop_gen.generate_observation_histology_record(
            person_id=person_record['person_id'],
            visit_occurrence_id=visit_record['visit_occurrence_id'],
            dt=study_datetime,
            histology_text=None
        )

        # REALM extension: file registry
        if dicom_metadata:
            self.omop_gen.add_realm_file_record(
                person_id=person_record['person_id'],
                file_type='DICOM',
                file_path=str(study_dir / self._output_get('dicom_subdir') / f"SERIES{series_info['series_number']:03d}"),
                related_study_id=dicom_metadata['study_instance_uid'],
                modality='CT',
                created_at=study_datetime,
                source_system=self.omop_gen.config.source_system
            )
        if nrrd_metadata:
            self.omop_gen.add_realm_file_record(
                person_id=person_record['person_id'],
                file_type='NRRD',
                file_path=str(
                    study_dir
                    / self._output_get('nrrd_subdir')
                    / f"SERIES{series_info['series_number']:03d}.nrrd"
                ),
                related_study_id=(dicom_metadata or {}).get('study_instance_uid'),
                modality='CT',
                created_at=study_datetime,
                source_system=self.omop_gen.config.source_system
            )

        # R-CDM rows
        ro = self.omop_gen.generate_radiology_occurrence_record(
            person_id=person_record['person_id'],
            study_datetime=study_datetime,
            modality='CT',
            manufacturer=getattr(self._dicom_config(), "manufacturer", None),
            protocol_name=getattr(self._dicom_config(), "series_description", None),
            series_count=1,
            image_count=int(volume.shape[0]) if dicom_metadata else None
        )
        if dicom_metadata:
            self.omop_gen.generate_radiology_image_record(
                radiology_occurrence_id=ro['radiology_occurrence_id'],
                series_instance_uid=dicom_metadata['series_instance_uid'],
                file_path=str(
                    study_dir
                    / self._output_get('dicom_subdir')
                    / f"SERIES{series_info['series_number']:03d}"
                ),
                body_part_source_value='CHEST',
                series_number=series_info['series_number'],
                rows=volume.shape[1],
                columns=volume.shape[2],
                slice_thickness=used_spacing_zyx[0]
            )

        return {
            'metadata': {
                'patient_info': patient_info,
                'study_info': {
                    k: (v.isoformat() if isinstance(v, datetime) else v)
                    for k, v in study_info.items()
                },
                'series_info': {
                    k: (v.isoformat() if isinstance(v, datetime) else v)
                    for k, v in series_info.items()
                },
                'annotations': annotations,
                'dicom_metadata': dicom_metadata,
                'nrrd_metadata': nrrd_metadata,
                'output_directory': str(study_dir),
                'generation_mode': self._get_generation_mode(),
                'augmentation_input': str(self.augmentation_input) if self.augmentation_input else None,
                'privacy_safe': self.privacy_synth_mode if self.augmentation_input else True,
            },
            'omop': {
                'person_id': person_record['person_id'],
                'visit_occurrence_id': visit_record['visit_occurrence_id'],
            }
        }

    def _generate_volume(self) -> Tuple[np.ndarray, Dict[str, np.ndarray], Tuple[float, float, float], Dict[str, Any]]:
        """
        Generate CT volume using appropriate mode.
        
        Returns:
            Tuple of (volume, masks_dict, spacing_zyx, annotations)
        """
        if self.augmentation_input is not None:
            if not self.augmentation_input.exists():
                raise FileNotFoundError(f"Augmentation input not found: {self.augmentation_input}")

            # Load real CT
            base_ct_zyx, base_spacing_zyx = _load_real_ct_any(self.augmentation_input)
            print(f"  Loaded base CT: shape={base_ct_zyx.shape} spacing={base_spacing_zyx}")

            # Configure generator to match real CT geometry
            self.volume_gen.config.volume_shape = tuple(base_ct_zyx.shape)
            self.volume_gen.config.spacing = tuple(base_spacing_zyx)

            if self.privacy_synth_mode:
                # PRIVACY-SYNTHESIS MODE: Apply MS-STS
                print("  [PRIVACY-SYNTH] Step 1: Augmenting real CT...")
                augmented_ct = self.volume_gen.generate(
                    base_volume=base_ct_zyx,
                    base_spacing=base_spacing_zyx
                )
                print(f"    → Augmented CT: shape={augmented_ct.shape} "
                      f"HU range=[{augmented_ct.min()}, {augmented_ct.max()}]")

                print("  [PRIVACY-SYNTH] Step 2: Applying MS-STS texture synthesis...")
                volume, masks_dict = self.volume_gen.create_privacy_synth_from_augmented(
                    augmented_volume=augmented_ct,
                    augmented_spacing=base_spacing_zyx
                )
                print(f"    → Synthesized volume: shape={volume.shape} "
                      f"HU range=[{volume.min()}, {volume.max()}]")
                print(f"    → Privacy protection: Empirical (aims for MI < 1.8 bits)")
                print(f"    → Pathology preserved: {masks_dict['pathology'].sum()} voxels")

            else:
                # AUGMENTATION MODE: NOT privacy-safe
                print("  [AUGMENTATION] Augmenting real CT (NOT privacy-safe)...")
                volume = self.volume_gen.generate(
                    base_volume=base_ct_zyx,
                    base_spacing=base_spacing_zyx
                )
                print(f"    → Augmented CT: shape={volume.shape} "
                      f"HU range=[{volume.min()}, {volume.max()}]")
                print(f"    → Privacy protection: None (contains real patient intensities)")
                
                # Build masks manually
                nodule_mask = self.volume_gen.build_nodule_mask(volume.shape, base_spacing_zyx)
                lesion_mask = self.volume_gen.build_lesion_mask(volume.shape, base_spacing_zyx)
                masks_dict = {
                    'nodule': nodule_mask,
                    'lesion': lesion_mask,
                    'pathology': (nodule_mask.astype(bool) | lesion_mask.astype(bool)).astype(np.int8),
                }

            used_spacing_zyx = base_spacing_zyx

        else:
            # PURE SYNTHESIS MODE: Privacy-safe by definition (no real patient data)
            print("  [SYNTHESIS] Generating purely synthetic CT...")
            volume = self.volume_gen.generate()

            nodule_mask = self.volume_gen.build_nodule_mask(
                volume.shape, self._volume_get('spacing')
            )
            lesion_mask = self.volume_gen.build_lesion_mask(
                volume.shape, self._volume_get('spacing')
            )
            masks_dict = {
                'nodule': nodule_mask,
                'lesion': lesion_mask,
                'pathology': (nodule_mask.astype(bool) | lesion_mask.astype(bool)).astype(np.int8),
            }
            used_spacing_zyx = self._volume_get('spacing')

            print(f"    → Synthetic CT: shape={volume.shape} "
                  f"HU range=[{volume.min()}, {volume.max()}]")
            print(f"    → Privacy protection: Not applicable (purely synthetic)")

        annotations = self.volume_gen.get_annotations()
        
        # Print summary
        n_nodules = len(annotations.get('nodules', []))
        n_lesions = len(annotations.get('lesions', []))
        print(f"    → Annotations: {n_nodules} nodules, {n_lesions} lesions")

        return volume, masks_dict, used_spacing_zyx, annotations

    def _export_segmentation_masks(
        self,
        masks_dict: Dict[str, np.ndarray],
        nrrd_dir: Path,
        series_info: Dict[str, Any],
        patient_id: str,
        spacing_zyx: Tuple[float, float, float]
    ) -> None:
        """Export segmentation masks as NRRD files."""
        series_num = series_info['series_number']
        
        # Nodule mask
        if 'nodule' in masks_dict and np.any(masks_dict['nodule']):
            nodule_file = nrrd_dir / f"SERIES{series_num:03d}_nodules.nrrd"
            info = self.nrrd_exporter.export_labelmap(
                masks_dict['nodule'], nodule_file, spacing_zyx,
                label_value=1,
                metadata={'seg_label': 'nodule_mask', 'modality': 'SEG', 'patient_id': patient_id},
                array_order="zyx"
            )
            print(f"    → Nodule mask: {nodule_file} ({info.get('nonzero_voxels', 0)} voxels)")

        # Lesion mask
        if 'lesion' in masks_dict and np.any(masks_dict['lesion']):
            lesion_file = nrrd_dir / f"SERIES{series_num:03d}_lesions.nrrd"
            info = self.nrrd_exporter.export_labelmap(
                masks_dict['lesion'], lesion_file, spacing_zyx,
                label_value=1,
                metadata={'seg_label': 'lesion_mask', 'modality': 'SEG', 'patient_id': patient_id},
                array_order="zyx"
            )
            print(f"    → Lesion mask: {lesion_file} ({info.get('nonzero_voxels', 0)} voxels)")

        # Combined pathology mask (if in privacy-synth mode)
        if 'pathology' in masks_dict and np.any(masks_dict['pathology']):
            pathology_file = nrrd_dir / f"SERIES{series_num:03d}_pathology.nrrd"
            info = self.nrrd_exporter.export_labelmap(
                masks_dict['pathology'], pathology_file, spacing_zyx,
                label_value=1,
                metadata={'seg_label': 'pathology_combined', 'modality': 'SEG', 'patient_id': patient_id},
                array_order="zyx"
            )
            print(f"    → Pathology mask: {pathology_file} ({info.get('nonzero_voxels', 0)} voxels)")

        # Lung mask (if available from privacy-synth)
        if 'lung' in masks_dict and np.any(masks_dict['lung']):
            lung_file = nrrd_dir / f"SERIES{series_num:03d}_lung.nrrd"
            info = self.nrrd_exporter.export_labelmap(
                masks_dict['lung'], lung_file, spacing_zyx,
                label_value=1,
                metadata={'seg_label': 'lung_mask', 'modality': 'SEG', 'patient_id': patient_id},
                array_order="zyx"
            )
            print(f"    → Lung mask: {lung_file} ({info.get('nonzero_voxels', 0)} voxels)")

        # Body mask (if available from privacy-synth)
        if 'body' in masks_dict and np.any(masks_dict['body']):
            body_file = nrrd_dir / f"SERIES{series_num:03d}_body.nrrd"
            info = self.nrrd_exporter.export_labelmap(
                masks_dict['body'], body_file, spacing_zyx,
                label_value=1,
                metadata={'seg_label': 'body_mask', 'modality': 'SEG', 'patient_id': patient_id},
                array_order="zyx"
            )
            print(f"    → Body mask: {body_file} ({info.get('nonzero_voxels', 0)} voxels)")

    # ----------------------------
    # Structure / utilities
    # ----------------------------

    def _setup_output_structure(self) -> None:
        base_dir = self._output_get('output_root')
        base_dir.mkdir(parents=True, exist_ok=True)
        (base_dir / self._output_get('metadata_subdir')).mkdir(parents=True, exist_ok=True)
        (base_dir / self._output_get('omop_subdir')).mkdir(parents=True, exist_ok=True)

    def _get_study_directory(self, patient_id: str, study_datetime: datetime) -> Path:
        date_str = study_datetime.strftime('%Y%m%d')
        return self._output_get('output_root') / "studies" / f"{patient_id}_{date_str}"

    def _generate_birth_date(self) -> datetime:
        age_days = random.randint(25 * 365, 75 * 365)
        return datetime.now() - timedelta(days=age_days)

    def _generate_study_datetime(self) -> datetime:
        days_ago = random.randint(0, 365)
        hours = random.randint(8, 17)
        minutes = random.randint(0, 59)
        base_date = datetime.now() - timedelta(days=days_ago)
        return base_date.replace(hour=hours, minute=minutes, second=0, microsecond=0)

    def _config_to_dict(self) -> Dict[str, Any]:
        cfg_dict = asdict(self.config) if is_dataclass(self.config) else dict(self.config.__dict__)
        out = cfg_dict.get('output', {})
        if is_dataclass(out):
            out = asdict(out)
        if isinstance(out, dict):
            for k, v in list(out.items()):
                if isinstance(v, Path):
                    out[k] = str(v)
            cfg_dict['output'] = out
        return cfg_dict