"""
TCIA CT Loader - Load and preprocess real CT data from TCIA (or any DICOM tree).

Key API:
- find_ct_series(root: Path) -> (series_uid, list[Path])
- load_ct_series(files_or_single: list[Path]) -> (sitk.Image, (dz, dy, dx))
- resample_isotropic(img: sitk.Image, iso_mm: float = 1.0, interp=sitk.sitkLinear) -> sitk.Image
- load_numpy(files_or_single, *, resample_mm: float|None=None) -> (np.ndarray[int16], (dz,dy,dx))

Additional helpers for template-based synthesis:
- load_numpy_from_root(root, *, resample_mm: float|None=None) -> (np.ndarray[int16], (dz,dy,dx))
- build_population_template(roots, *, target_shape_zyx, iso_mm, ...) -> (template_volume, (dz,dy,dx))

Notes:
- Returns spacing as (dz, dy, dx) consistent with your volume generator.
- Robust to classic single-frame series, Enhanced Multiframe CT (single DICOM),
  and single-file volumes (NRRD/NIfTI/MHA/MHD).
- Sorts DICOM slices by ImagePositionPatient projected onto the slice normal;
  falls back to InstanceNumber if needed.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Sequence, Union
import math
import logging

import pydicom
import SimpleITK as sitk
import numpy as np


__all__ = [
    "find_ct_series",
    "load_ct_series",
    "resample_isotropic",
    "load_numpy",
    "load_numpy_from_root",
    "build_population_template",
]

# -------------------------------------------------------------------------------------------------
# Logging
# -------------------------------------------------------------------------------------------------

logger = logging.getLogger("tcia_ct_loader")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    logger.addHandler(_h)
logger.setLevel(logging.INFO)


# -------------------------------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------------------------------

_SINGLE_FILE_EXTS = {".nrrd", ".nhdr", ".nii", ".nii.gz", ".mha", ".mhd"}
_DICOM_LIKE_EXTS = {".dcm", ""}  # some DICOMs have no extension


def _read_meta(path: Path) -> Optional[pydicom.dataset.FileDataset]:
    """Read only the DICOM header quickly; return None if unreadable."""
    try:
        return pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    except Exception:
        return None


def _series_key(ds: pydicom.dataset.FileDataset) -> Optional[Tuple[str, Optional[str]]]:
    """Group by SeriesInstanceUID (+ FrameOfReferenceUID to avoid mixing stacks)."""
    sid = getattr(ds, "SeriesInstanceUID", None)
    fref = getattr(ds, "FrameOfReferenceUID", None)
    return (sid, fref) if sid else None


def _is_enhanced_multiframe(ds: pydicom.dataset.FileDataset) -> bool:
    """Enhanced CT typically has PerFrameFunctionalGroupsSequence."""
    return bool(getattr(ds, "PerFrameFunctionalGroupsSequence", None))


def _compute_slice_normal(ds: pydicom.dataset.FileDataset) -> Optional[Tuple[float, float, float]]:
    """
    Compute the slice normal from ImageOrientationPatient (row, col cosines).
    Return unit vector (nx, ny, nz) or None if not available.
    """
    iop = getattr(ds, "ImageOrientationPatient", None)
    if not iop or len(iop) != 6:
        return None
    xr, yr, zr, xc, yc, zc = map(float, iop)
    # normal = row × col
    nx = yr * zc - zr * yc
    ny = zr * xc - xr * zc
    nz = xr * yc - yr * xc
    norm = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return (nx / norm, ny / norm, nz / norm)


def _slice_sort_key(d: pydicom.dataset.FileDataset, normal: Optional[Tuple[float, float, float]]) -> float:
    """
    Sort slices by projection of ImagePositionPatient on the normal.
    Fallback to InstanceNumber if geometry is missing.
    """
    ipp = getattr(d, "ImagePositionPatient", None)
    if ipp and normal:
        return float(ipp[0] * normal[0] + ipp[1] * normal[1] + ipp[2] * normal[2])
    return float(getattr(d, "InstanceNumber", 0))


def _estimate_dz(sorted_meta: List[pydicom.dataset.FileDataset],
                 normal: Optional[Tuple[float, float, float]]) -> float:
    """
    Estimate inter-slice spacing from consecutive IPP along the normal.
    Fallback to SpacingBetweenSlices or SliceThickness if needed.
    """
    if normal and len(sorted_meta) >= 2:
        ipp0 = sorted_meta[0].ImagePositionPatient
        ipp1 = sorted_meta[1].ImagePositionPatient
        d = (
            (ipp1[0] - ipp0[0]) * normal[0]
            + (ipp1[1] - ipp0[1]) * normal[1]
            + (ipp1[2] - ipp0[2]) * normal[2]
        )
        return abs(float(d))

    dz = getattr(sorted_meta[0], "SpacingBetweenSlices", None)
    if dz is None:
        dz = getattr(sorted_meta[0], "SliceThickness", 1.0)
    return float(dz)


def _center_crop_or_pad_zyx(
    vol: np.ndarray,
    target_shape_zyx: Tuple[int, int, int],
    pad_value: int = -1000,
) -> np.ndarray:
    """
    Center-crop or center-pad a (Z,Y,X) volume to target_shape_zyx.

    - If vol is larger along an axis, it is cropped centrally.
    - If vol is smaller, it is zero/constant padded centrally with pad_value.
    """
    assert vol.ndim == 3, "Volume must be 3D (Z,Y,X)."
    z, y, x = vol.shape
    tz, ty, tx = target_shape_zyx

    out = np.full((tz, ty, tx), pad_value, dtype=vol.dtype)

    # Source indices
    z0 = max(0, (z - tz) // 2)
    y0 = max(0, (y - ty) // 2)
    x0 = max(0, (x - tx) // 2)
    z1 = min(z0 + tz, z)
    y1 = min(y0 + ty, y)
    x1 = min(x0 + tx, x)

    # Dest indices
    oz0 = max(0, (tz - z) // 2)
    oy0 = max(0, (ty - y) // 2)
    ox0 = max(0, (tx - x) // 2)

    out[oz0:oz0 + (z1 - z0),
        oy0:oy0 + (y1 - y0),
        ox0:ox0 + (x1 - x0)] = vol[z0:z1, y0:y1, x0:x1]

    return out


# -------------------------------------------------------------------------------------------------
# Core API
# -------------------------------------------------------------------------------------------------

def find_ct_series(root: Path) -> Tuple[str, List[Path]]:
    """
    Resolve a CT input under `root`:
      1) If `root` is a FILE and has a supported single-volume extension (.nrrd/.nhdr/.nii/.nii.gz/.mha/.mhd),
         return ("FILE::<stem>", [root]).
      2) Else if `root` is a FILE that looks like a single DICOM, return (SeriesInstanceUID, [root]).
      3) Else if `root` is a DIRECTORY:
         - Try to find classic single-frame DICOM series (group by SeriesInstanceUID + FrameOfReferenceUID)
           and return the largest.
         - If none, look for supported single-volume files inside the directory; if multiple, pick the largest by size.
      4) Else raise.

    Returns:
        (series_id, list_of_paths)
    """
    root = Path(root)
    if not root.exists():
        raise FileNotFoundError(f"Root not found: {root}")

    # --- Case 1/2: root is a single file
    if root.is_file():
        suf = root.suffix.lower()
        if suf in _SINGLE_FILE_EXTS or str(root).lower().endswith(".nii.gz"):
            sid = f"FILE::{root.stem}"
            logger.info(f"Selected single-file volume: {root}")
            return sid, [root]
        # try DICOM single file
        ds = _read_meta(root)
        if ds is not None and getattr(ds, "Modality", None) == "CT":
            sid = getattr(ds, "SeriesInstanceUID", f"DICOM_FILE::{root.stem}")
            logger.info(f"Selected single DICOM file as series: {root}")
            return sid, [root]
        raise RuntimeError(f"Unsupported input file (not DICOM/NRRD/NIfTI/MHA/MHD): {root}")

    # --- Case 3: root is a directory
    # 3a) collect DICOM-like files
    dcm_files = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in _DICOM_LIKE_EXTS]
    groups: Dict[Tuple[str, Optional[str]], List[Path]] = {}
    enhanced_singletons: List[Path] = []

    for f in dcm_files:
        if f.name.startswith("."):
            continue
        ds = _read_meta(f)
        if ds is None:
            continue
        if getattr(ds, "Modality", None) != "CT":
            continue
        if _is_enhanced_multiframe(ds):
            enhanced_singletons.append(f)
            continue
        key = _series_key(ds)
        if key:
            groups.setdefault(key, []).append(f)

    if groups:
        (sid, _fref), files = max(groups.items(), key=lambda kv: len(kv[1]))
        logger.info(f"Selected CT series (single-frame): {sid} with {len(files)} files")
        return sid, files

    if enhanced_singletons:
        ds0 = _read_meta(enhanced_singletons[0])
        sid = getattr(ds0, "SeriesInstanceUID", "ENHANCED_CT")
        logger.info(f"Selected Enhanced CT (multiframe): {sid} file={enhanced_singletons[0]}")
        return sid, [enhanced_singletons[0]]

    # 3b) try single-file volumes inside directory
    vol_files: List[Path] = []
    for ext in _SINGLE_FILE_EXTS:
        vol_files.extend(root.rglob(f"*{ext}"))
    # handle .nii.gz (two suffixes)
    vol_files.extend([p for p in root.rglob("*") if str(p).lower().endswith(".nii.gz")])

    if vol_files:
        # choose the largest by file size (heuristic)
        best = max(vol_files, key=lambda p: p.stat().st_size if p.exists() else 0)
        sid = f"FILE::{best.stem}"
        logger.info(f"Selected single-file volume in dir: {best}")
        return sid, [best]

    raise RuntimeError(f"No DICOM-like or single-file CT volumes found under: {root}")


def load_ct_series(files_or_single: List[Path]) -> Tuple[sitk.Image, Tuple[float, float, float]]:
    """
    Load a CT series (single-frame list, one enhanced multiframe DICOM, or a single-file volume).

    Returns:
        (SimpleITK Image, spacing as (dz, dy, dx) in mm)
    """
    files_or_single = list(files_or_single)
    assert len(files_or_single) > 0, "Empty input list"

    # Single file (DICOM enhanced, NRRD/NIfTI/MHA/MHD, or plain DICOM)
    if len(files_or_single) == 1:
        img = sitk.ReadImage(str(files_or_single[0]))
        sx, sy, sz = img.GetSpacing()  # ITK order: (x, y, z)
        spacing = (sz, sy, sx)         # convert to (dz, dy, dx) to match numpy array (Z,Y,X)
        return img, spacing

    # Single-frame DICOM stack: robust sort
    metas: List[Tuple[Path, pydicom.dataset.FileDataset]] = []
    for p in files_or_single:
        ds = _read_meta(p)
        if ds is not None:
            metas.append((p, ds))
    if not metas:
        raise RuntimeError("No readable DICOM headers in provided files.")

    normal = _compute_slice_normal(metas[0][1])

    # Deduplicate by SOPInstanceUID
    seen_sop = set()
    dedup: List[Tuple[Path, pydicom.dataset.FileDataset]] = []
    for p, ds in metas:
        sop = getattr(ds, "SOPInstanceUID", None)
        if sop and sop in seen_sop:
            continue
        seen_sop.add(sop)
        dedup.append((p, ds))

    sorted_pairs = sorted(dedup, key=lambda t: _slice_sort_key(t[1], normal))
    files_sorted = [str(p) for p, _ in sorted_pairs]

    reader = sitk.ImageSeriesReader()
    reader.SetFileNames(files_sorted)
    img = reader.Execute()

    sx, sy, sz = img.GetSpacing()  # (x,y,z) in mm
    try:
        dz = _estimate_dz([ds for _, ds in sorted_pairs], normal)
        # Keep SimpleITK spacing consistent with our dz estimate so resampling is correct
        img.SetSpacing((sx, sy, dz))
        spacing = (dz, sy, sx)  # (dz,dy,dx) matching numpy (Z,Y,X)
    except Exception:
        # Fallback to whatever ITK thinks the spacing is
        spacing = (sz, sy, sx)

    return img, spacing


def resample_isotropic(img: sitk.Image,
                       iso_mm: float = 1.0,
                       interp: int = sitk.sitkLinear) -> sitk.Image:
    """
    Resample to isotropic spacing (iso_mm, iso_mm, iso_mm) in physical space.

    Note: img is SimpleITK 3D image with spacing (sx,sy,sz) in (x,y,z) order.
    """
    assert img.GetDimension() == 3
    sx, sy, sz = img.GetSpacing()
    nx, ny, nz = img.GetSize()

    new_spacing = (iso_mm, iso_mm, iso_mm)
    new_size = [
        int(round(nx * sx / iso_mm)),
        int(round(ny * sy / iso_mm)),
        int(round(nz * sz / iso_mm)),
    ]

    resampler = sitk.ResampleImageFilter()
    resampler.SetInterpolator(interp)
    resampler.SetOutputSpacing(new_spacing)
    resampler.SetSize(new_size)
    resampler.SetOutputOrigin(img.GetOrigin())
    resampler.SetOutputDirection(img.GetDirection())

    return resampler.Execute(img)


def load_numpy(files_or_single: List[Path],
               *,
               resample_mm: Optional[float] = None,
               interp: int = sitk.sitkLinear) -> Tuple[np.ndarray, Tuple[float, float, float]]:
    """
    Load a CT series and return a numpy volume and spacing.

    Args:
        files_or_single:
            List of Paths belonging to one CT series (or a single file).
        resample_mm:
            If not None, resample volume to isotropic spacing `resample_mm` using
            SimpleITK before converting to numpy.
        interp:
            Interpolation mode for resampling (SimpleITK constant).

    Returns:
        (volume_zyx[int16], spacing_zyx=(dz,dy,dx) in mm)
    """
    img, spacing = load_ct_series(files_or_single)
    if resample_mm is not None:
        img = resample_isotropic(img, iso_mm=float(resample_mm), interp=interp)
        sx, sy, sz = img.GetSpacing()
        spacing = (sz, sy, sx)  # ITK (x,y,z) -> numpy (Z,Y,X)

    arr = sitk.GetArrayFromImage(img).astype(np.int16)  # shape (Z,Y,X)
    return arr, spacing


# -------------------------------------------------------------------------------------------------
# Convenience helpers for hybrid synthesis
# -------------------------------------------------------------------------------------------------

def load_numpy_from_root(
    root: Union[Path, str],
    *,
    resample_mm: Optional[float] = None,
    interp: int = sitk.sitkLinear,
) -> Tuple[np.ndarray, Tuple[float, float, float]]:
    """
    One-shot convenience wrapper:

        root  -> find_ct_series(root) -> load_numpy(files, resample_mm)

    This is handy when building population templates or feeding real scans into
    your ChestCTVolumeGenerator.
    """
    root = Path(root).expanduser().resolve()
    sid, files = find_ct_series(root)
    vol, spacing = load_numpy(files, resample_mm=resample_mm, interp=interp)
    logger.info(f"Loaded series {sid}: shape={vol.shape}, spacing={spacing}")
    return vol, spacing


def build_population_template(
    roots: Sequence[Union[Path, str]],
    *,
    target_shape_zyx: Tuple[int, int, int],
    iso_mm: float,
    max_cases: Optional[int] = None,
    min_cases: int = 5,
    clip_hu: Tuple[int, int] = (-1000, 400),
    air_hu: int = -1000,
) -> Tuple[np.ndarray, Tuple[float, float, float]]:
    """
    Build a k-anonymous population template volume from multiple CT roots.

    This is designed for the hybrid, privacy-preserving path:
      - Each root is a TCIA-style root (directory or file).
      - We load each volume, resample to `iso_mm` spacing, clip HU, and
        center-crop/pad to `target_shape_zyx`.
      - We then compute the voxel-wise mean across all valid cases.

    The resulting template can be plugged into:

        tmpl, tmpl_spacing = build_population_template(...)
        gen = ChestCTVolumeGenerator(config, seed=...)
        vol = gen.generate_with_template(tmpl, tmpl_spacing)

    where:
      - config.volume_shape == target_shape_zyx
      - config.spacing == tmpl_spacing (or at least same dz for lung geometry).

    Args:
        roots:
            Sequence of patient/series roots (dirs or files). Each will be passed
            to find_ct_series().
        target_shape_zyx:
            Desired (Z,Y,X) shape for the template. Should match your generator's
            config.volume_shape.
        iso_mm:
            Isotropic spacing (in mm) to resample each volume to before averaging.
        max_cases:
            Optional cap on number of cases to use (e.g. for speed).
        min_cases:
            Minimum number of successfully processed cases required. If fewer
            than this succeed, a RuntimeError is raised.
        clip_hu:
            (min_HU, max_HU) range to clip each volume before averaging; this
            keeps template intensities stable and reduces outliers.
        air_hu:
            HU value used when padding volumes outside their original FOV.

    Returns:
        (template_volume_zyx[float32], spacing_zyx=(dz,dy,dx)=(iso_mm,iso_mm,iso_mm))
    """
    vols: List[np.ndarray] = []
    used_roots: List[Path] = []

    for r in roots:
        if max_cases is not None and len(vols) >= max_cases:
            break
        root = Path(r).expanduser().resolve()
        try:
            vol, spacing = load_numpy_from_root(root, resample_mm=iso_mm)
        except Exception as e:
            logger.warning(f"Skipping root {root} due to load error: {e}")
            continue

        if vol.ndim != 3 or vol.size == 0:
            logger.warning(f"Skipping root {root}: invalid volume shape {vol.shape}")
            continue

        # Clip HU to a reasonable range before averaging
        v = np.clip(vol, clip_hu[0], clip_hu[1]).astype(np.int16)

        # Ensure consistent shape for averaging
        v = _center_crop_or_pad_zyx(v, target_shape_zyx=target_shape_zyx, pad_value=air_hu)
        vols.append(v.astype(np.float32))
        used_roots.append(root)

    if len(vols) < min_cases:
        raise RuntimeError(
            f"Only {len(vols)} valid cases were found; at least min_cases={min_cases} "
            f"are required to build a population template."
        )

    logger.info(f"Building population template from {len(vols)} cases "
                f"(target_shape={target_shape_zyx}, iso_mm={iso_mm})")

    stack = np.stack(vols, axis=0)  # (N,Z,Y,X)
    template = stack.mean(axis=0).astype(np.float32)  # (Z,Y,X)
    spacing_zyx = (iso_mm, iso_mm, iso_mm)

    return template, spacing_zyx


# -------------------------------------------------------------------------------------------------
# CLI
# -------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Load a CT series or single-file volume and print shape/spacing."
    )
    parser.add_argument(
        "root",
        type=str,
        help="Folder with DICOM or a single .nrrd/.nhdr/.nii(.gz)/.mha/.mhd file.",
    )
    parser.add_argument(
        "--iso",
        type=float,
        default=None,
        help="Optional isotropic resample size in mm (e.g., 1.0).",
    )
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    sid, files = find_ct_series(root)
    img, spacing = load_ct_series(files)
    if args.iso is not None:
        img = resample_isotropic(img, iso_mm=args.iso)
        sx, sy, sz = img.GetSpacing()
        spacing = (sz, sy, sx)

    vol = sitk.GetArrayFromImage(img)
    print(f"Loaded: {sid}")
    print(f"Shape (Z,Y,X): {tuple(vol.shape)}")
    print(f"Spacing (dz,dy,dx): {spacing}")
