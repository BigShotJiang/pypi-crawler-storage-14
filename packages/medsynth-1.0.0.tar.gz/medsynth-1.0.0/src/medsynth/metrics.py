"""
Comprehensive metrics module for evaluating synthetic CT generation methods.

Implements state-of-the-art metrics for:
1. Image Quality Assessment (SSIM, PSNR, MS-SSIM)
2. Clinical Utility Metrics (SNR, CNR, Nodule Detectability)
3. Privacy Metrics (MI, Histogram Distance, Texture Analysis)

Author: Twin CT Generator Research Team
"""

from __future__ import annotations

from typing import Dict, Any, Optional, Tuple
import numpy as np
from scipy import ndimage
from scipy.stats import entropy, wasserstein_distance
from scipy.fft import dctn
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import peak_signal_noise_ratio as psnr


# ===========================
# Image Quality Metrics
# ===========================

def compute_ssim(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    data_range: float = 4095.0
) -> float:
    """
    Compute Structural Similarity Index (SSIM).

    SSIM measures perceptual similarity between two images.
    Range: [-1, 1], where 1 = perfect similarity.

    Args:
        original: Original CT volume (Z,Y,X)
        synthetic: Synthetic CT volume (Z,Y,X)
        mask: Optional binary mask to restrict computation
        data_range: Data range for SSIM computation (default: 4095 HU)

    Returns:
        SSIM value (higher is better, 1 = perfect)
    """
    if mask is not None:
        # Compute SSIM only in masked region
        if not np.any(mask):
            return 0.0

        # Extract bounding box
        z_idx, y_idx, x_idx = np.where(mask)
        z_min, z_max = z_idx.min(), z_idx.max() + 1
        y_min, y_max = y_idx.min(), y_idx.max() + 1
        x_min, x_max = x_idx.min(), x_idx.max() + 1

        orig_crop = original[z_min:z_max, y_min:y_max, x_min:x_max]
        synth_crop = synthetic[z_min:z_max, y_min:y_max, x_min:x_max]
        mask_crop = mask[z_min:z_max, y_min:y_max, x_min:x_max]

        # Apply mask
        orig_masked = np.where(mask_crop, orig_crop, 0)
        synth_masked = np.where(mask_crop, synth_crop, 0)

        return float(ssim(orig_masked, synth_masked, data_range=data_range))

    return float(ssim(original, synthetic, data_range=data_range))


def compute_psnr(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    data_range: float = 4095.0
) -> float:
    """
    Compute Peak Signal-to-Noise Ratio (PSNR).

    PSNR measures pixel-wise accuracy between two images.
    Range: [0, ∞), higher is better. Typical values: 20-50 dB.

    Args:
        original: Original CT volume (Z,Y,X)
        synthetic: Synthetic CT volume (Z,Y,X)
        mask: Optional binary mask to restrict computation
        data_range: Data range for PSNR computation (default: 4095 HU)

    Returns:
        PSNR value in dB (higher is better)
    """
    if mask is not None:
        if not np.any(mask):
            return 0.0
        orig_vals = original[mask].astype(np.float64)
        synth_vals = synthetic[mask].astype(np.float64)
        mse = np.mean((orig_vals - synth_vals) ** 2)
    else:
        mse = np.mean((original.astype(np.float64) - synthetic.astype(np.float64)) ** 2)

    if mse == 0:
        return float('inf')

    return float(20 * np.log10(data_range / np.sqrt(mse)))


def compute_ms_ssim(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    data_range: float = 4095.0,
    scales: Tuple[int, ...] = (1, 2, 4)
) -> float:
    """
    Compute Multi-Scale Structural Similarity Index (MS-SSIM).

    MS-SSIM captures image quality at multiple scales, providing a more
    comprehensive assessment than single-scale SSIM.

    Args:
        original: Original CT volume (Z,Y,X)
        synthetic: Synthetic CT volume (Z,Y,X)
        mask: Optional binary mask to restrict computation
        data_range: Data range for computation
        scales: Downsampling scales to use (default: 1, 2, 4)

    Returns:
        MS-SSIM value (higher is better, 1 = perfect)
    """
    ssim_values = []
    weights = [0.0448, 0.2856, 0.3001, 0.2363, 0.1333][:len(scales)]
    weights = np.array(weights) / np.sum(weights)  # Normalize

    for i, scale in enumerate(scales):
        if scale == 1:
            orig_scaled = original
            synth_scaled = synthetic
            mask_scaled = mask
        else:
            # Downsample by averaging
            orig_scaled = ndimage.zoom(original, 1.0/scale, order=1)
            synth_scaled = ndimage.zoom(synthetic, 1.0/scale, order=1)
            if mask is not None:
                mask_scaled = ndimage.zoom(mask.astype(float), 1.0/scale, order=0) > 0.5
            else:
                mask_scaled = None

        ssim_val = compute_ssim(orig_scaled, synth_scaled, mask_scaled, data_range)
        ssim_values.append(ssim_val)

    # Weighted geometric mean
    ms_ssim = np.prod([s ** w for s, w in zip(ssim_values, weights)])
    return float(ms_ssim)


def compute_nmse(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> float:
    """
    Compute Normalized Mean Square Error (NMSE).

    NMSE measures relative reconstruction error.
    Range: [0, ∞), lower is better. 0 = perfect reconstruction.

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        mask: Optional binary mask

    Returns:
        NMSE value (lower is better)
    """
    if mask is not None and np.any(mask):
        orig = original[mask].astype(np.float64)
        synth = synthetic[mask].astype(np.float64)
    else:
        orig = original.astype(np.float64)
        synth = synthetic.astype(np.float64)

    mse = np.mean((orig - synth) ** 2)
    orig_energy = np.mean(orig ** 2)

    if orig_energy == 0:
        return float('inf')

    return float(mse / orig_energy)


# ===========================
# Clinical Utility Metrics
# ===========================

def compute_snr(volume: np.ndarray, signal_mask: np.ndarray, noise_mask: np.ndarray) -> float:
    """
    Compute Signal-to-Noise Ratio (SNR).

    SNR measures image quality based on signal strength relative to noise.
    Higher values indicate better image quality.

    Args:
        volume: CT volume (Z,Y,X)
        signal_mask: Binary mask defining signal region (e.g., tissue)
        noise_mask: Binary mask defining noise region (e.g., air)

    Returns:
        SNR value in dB (higher is better)
    """
    if not np.any(signal_mask) or not np.any(noise_mask):
        return 0.0

    signal_mean = np.mean(volume[signal_mask])
    noise_std = np.std(volume[noise_mask])

    if noise_std == 0:
        return float('inf')

    snr_linear = signal_mean / noise_std
    snr_db = 20 * np.log10(np.abs(snr_linear))

    return float(snr_db)


def compute_cnr(
    volume: np.ndarray,
    roi1_mask: np.ndarray,
    roi2_mask: np.ndarray,
    background_mask: np.ndarray
) -> float:
    """
    Compute Contrast-to-Noise Ratio (CNR).

    CNR measures the ability to distinguish between two regions relative to noise.
    Essential for assessing lesion/nodule detectability.

    Args:
        volume: CT volume (Z,Y,X)
        roi1_mask: Binary mask for first ROI (e.g., nodule)
        roi2_mask: Binary mask for second ROI (e.g., normal lung)
        background_mask: Binary mask for background/noise region

    Returns:
        CNR value (higher is better)
    """
    if not np.any(roi1_mask) or not np.any(roi2_mask) or not np.any(background_mask):
        return 0.0

    roi1_mean = np.mean(volume[roi1_mask])
    roi2_mean = np.mean(volume[roi2_mask])
    background_std = np.std(volume[background_mask])

    if background_std == 0:
        return float('inf')

    cnr = np.abs(roi1_mean - roi2_mean) / background_std
    return float(cnr)


def compute_nodule_detectability_index(
    volume: np.ndarray,
    nodule_mask: np.ndarray,
    lung_mask: np.ndarray,
    spacing: Tuple[float, float, float]
) -> Dict[str, float]:
    """
    Compute nodule detectability metrics.

    Assesses how well nodules can be detected and characterized in synthetic CTs.
    Critical for validating clinical utility.

    Args:
        volume: CT volume (Z,Y,X)
        nodule_mask: Binary mask of nodule regions
        lung_mask: Binary mask of lung regions
        spacing: Voxel spacing (dz, dy, dx) in mm

    Returns:
        Dictionary containing:
        - contrast: Mean HU difference between nodule and lung
        - sharpness: Edge sharpness metric (gradient magnitude)
        - volume_ml: Nodule volume in mL
        - detectability_index: Combined metric (higher = more detectable)
    """
    if not np.any(nodule_mask) or not np.any(lung_mask):
        return {
            'contrast': 0.0,
            'sharpness': 0.0,
            'volume_ml': 0.0,
            'detectability_index': 0.0
        }

    # Contrast: mean difference
    nodule_mean = np.mean(volume[nodule_mask])
    lung_mean = np.mean(volume[lung_mask])
    contrast = abs(nodule_mean - lung_mean)

    # Sharpness: edge gradient magnitude
    # Dilate nodule mask slightly to get boundary
    dilated = ndimage.binary_dilation(nodule_mask, iterations=2)
    boundary = dilated & ~nodule_mask

    if np.any(boundary):
        grad_z = ndimage.sobel(volume.astype(float), axis=0)
        grad_y = ndimage.sobel(volume.astype(float), axis=1)
        grad_x = ndimage.sobel(volume.astype(float), axis=2)
        grad_mag = np.sqrt(grad_z**2 + grad_y**2 + grad_x**2)
        sharpness = np.mean(grad_mag[boundary])
    else:
        sharpness = 0.0

    # Volume in mL
    voxel_volume_mm3 = spacing[0] * spacing[1] * spacing[2]
    volume_ml = np.sum(nodule_mask) * voxel_volume_mm3 / 1000.0

    # Detectability index (Rose criterion: contrast / noise > 5 for detectability)
    lung_std = np.std(volume[lung_mask])
    if lung_std > 0:
        detectability_index = contrast / lung_std
    else:
        detectability_index = 0.0

    return {
        'contrast': float(contrast),
        'sharpness': float(sharpness),
        'volume_ml': float(volume_ml),
        'detectability_index': float(detectability_index)
    }


def compute_edge_sharpness(volume: np.ndarray, mask: np.ndarray) -> float:
    """
    Compute edge sharpness metric.

    Measures how sharp anatomical boundaries are in the volume.
    Higher values indicate better preservation of structural details.

    Args:
        volume: CT volume (Z,Y,X)
        mask: Binary mask defining region of interest

    Returns:
        Edge sharpness value (higher is better)
    """
    if not np.any(mask):
        return 0.0

    # Compute gradient magnitude
    grad_z = ndimage.sobel(volume.astype(float), axis=0)
    grad_y = ndimage.sobel(volume.astype(float), axis=1)
    grad_x = ndimage.sobel(volume.astype(float), axis=2)
    grad_mag = np.sqrt(grad_z**2 + grad_y**2 + grad_x**2)

    # Mean gradient in masked region
    edge_sharpness = np.mean(grad_mag[mask])
    return float(edge_sharpness)


# ===========================
# Privacy Metrics
# ===========================

def compute_mutual_information(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    n_bins: int = 50
) -> float:
    """
    Compute Mutual Information I(Original; Synthetic) as privacy metric.

    Lower MI indicates stronger privacy (less information leaked).
    This provides formal information-theoretic privacy quantification.

    Args:
        original: Original patient CT values
        synthetic: Synthetic privacy-safe values
        mask: Optional region to compute MI over
        n_bins: Number of bins for histogram estimation

    Returns:
        Mutual information in bits (lower is more private)
        Typical ranges:
        - < 1.0 bits: Strong privacy
        - 1.0-2.0 bits: Good privacy
        - > 3.0 bits: Weak privacy
    """
    if mask is not None:
        if not np.any(mask):
            return 0.0
        orig_vals = original[mask].flatten()
        synth_vals = synthetic[mask].flatten()
    else:
        orig_vals = original.flatten()
        synth_vals = synthetic.flatten()

    # Compute 2D histogram
    hist_2d, _, _ = np.histogram2d(orig_vals, synth_vals, bins=n_bins)
    hist_2d = hist_2d + 1e-10  # Avoid log(0)

    # Normalize to probabilities
    p_xy = hist_2d / hist_2d.sum()
    p_x = p_xy.sum(axis=1, keepdims=True)
    p_y = p_xy.sum(axis=0, keepdims=True)

    # MI = sum p(x,y) * log(p(x,y) / (p(x)*p(y)))
    mi = np.sum(p_xy * np.log2(p_xy / (p_x * p_y) + 1e-10))

    return float(mi)


def compute_histogram_distance(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    n_bins: int = 100
) -> Dict[str, float]:
    """
    Compute histogram-based distance metrics.

    Multiple distance metrics provide different perspectives on privacy:
    - Wasserstein (Earth Mover's): Geometric distance between distributions
    - KL Divergence: Information-theoretic distance
    - Jensen-Shannon: Symmetric version of KL divergence

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        mask: Optional binary mask
        n_bins: Number of histogram bins

    Returns:
        Dictionary with distance metrics (lower values = more different = better privacy)
    """
    if mask is not None and np.any(mask):
        orig_vals = original[mask].flatten()
        synth_vals = synthetic[mask].flatten()
    else:
        orig_vals = original.flatten()
        synth_vals = synthetic.flatten()

    # Compute histograms
    hist_range = (min(orig_vals.min(), synth_vals.min()),
                  max(orig_vals.max(), synth_vals.max()))

    hist_orig, bin_edges = np.histogram(orig_vals, bins=n_bins, range=hist_range, density=True)
    hist_synth, _ = np.histogram(synth_vals, bins=n_bins, range=hist_range, density=True)

    # Normalize to probabilities
    hist_orig = hist_orig / (hist_orig.sum() + 1e-10)
    hist_synth = hist_synth / (hist_synth.sum() + 1e-10)

    # Wasserstein distance (Earth Mover's Distance)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    wasserstein = wasserstein_distance(bin_centers, bin_centers, hist_orig, hist_synth)

    # KL divergence
    kl_div = entropy(hist_orig + 1e-10, hist_synth + 1e-10)

    # Jensen-Shannon divergence (symmetric)
    m = 0.5 * (hist_orig + hist_synth)
    js_div = 0.5 * entropy(hist_orig + 1e-10, m + 1e-10) + \
             0.5 * entropy(hist_synth + 1e-10, m + 1e-10)

    return {
        'wasserstein_distance': float(wasserstein),
        'kl_divergence': float(kl_div),
        'js_divergence': float(js_div)
    }


def compute_texture_similarity(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    window_size: int = 7
) -> Dict[str, float]:
    """
    Compute texture similarity metrics.

    Analyzes whether patient-specific texture patterns are preserved
    (lower similarity = better privacy).

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        mask: Optional binary mask
        window_size: Size of local window for texture analysis

    Returns:
        Dictionary with texture metrics
    """
    if mask is not None and np.any(mask):
        # Extract bounding box
        z_idx, y_idx, x_idx = np.where(mask)
        z_min, z_max = z_idx.min(), z_idx.max() + 1
        y_min, y_max = y_idx.min(), y_idx.max() + 1
        x_min, x_max = x_idx.min(), x_idx.max() + 1

        orig = original[z_min:z_max, y_min:y_max, x_min:x_max]
        synth = synthetic[z_min:z_max, y_min:y_max, x_min:x_max]
        mask_crop = mask[z_min:z_max, y_min:y_max, x_min:x_max]
    else:
        orig = original
        synth = synthetic
        mask_crop = None

    # Local variance texture
    from scipy.ndimage import uniform_filter

    orig_mean = uniform_filter(orig.astype(float), size=window_size)
    synth_mean = uniform_filter(synth.astype(float), size=window_size)

    orig_var = uniform_filter(orig.astype(float)**2, size=window_size) - orig_mean**2
    synth_var = uniform_filter(synth.astype(float)**2, size=window_size) - synth_mean**2

    if mask_crop is not None:
        orig_var = orig_var[mask_crop]
        synth_var = synth_var[mask_crop]

    # Correlation of variance patterns (lower = better privacy)
    if orig_var.size > 0:
        correlation = np.corrcoef(orig_var.flatten(), synth_var.flatten())[0, 1]
        if np.isnan(correlation):
            correlation = 0.0
    else:
        correlation = 0.0

    # Frequency domain similarity
    # Lower similarity in high frequencies = better privacy
    dct_orig = dctn(orig, type=2, norm='ortho')
    dct_synth = dctn(synth, type=2, norm='ortho')

    # High-frequency region (outer 50% of DCT coefficients)
    z, y, x = dct_orig.shape
    high_freq_mask = np.ones_like(dct_orig, dtype=bool)
    high_freq_mask[:z//2, :y//2, :x//2] = False

    if np.any(high_freq_mask):
        high_freq_corr = np.corrcoef(
            dct_orig[high_freq_mask].flatten(),
            dct_synth[high_freq_mask].flatten()
        )[0, 1]
        if np.isnan(high_freq_corr):
            high_freq_corr = 0.0
    else:
        high_freq_corr = 0.0

    return {
        'variance_correlation': float(correlation),
        'high_freq_correlation': float(high_freq_corr),
        'texture_similarity_score': float((correlation + high_freq_corr) / 2)
    }


def detect_intensity_copying(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None,
    threshold_hu: float = 1.0
) -> Dict[str, float]:
    """
    Detect potential intensity copying from original to synthetic.

    Good privacy-safe methods should have very low copying rates.

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        mask: Optional binary mask
        threshold_hu: HU difference threshold for "exact match" (default: 1.0)

    Returns:
        Dictionary with copying metrics
    """
    if mask is not None and np.any(mask):
        orig = original[mask]
        synth = synthetic[mask]
    else:
        orig = original.flatten()
        synth = synthetic.flatten()

    # Exact matches (within threshold)
    exact_matches = np.abs(orig - synth) <= threshold_hu
    exact_match_rate = np.mean(exact_matches)

    # Near matches (within 5 HU)
    near_matches = np.abs(orig - synth) <= 5.0
    near_match_rate = np.mean(near_matches)

    # Very close matches (within 10 HU)
    close_matches = np.abs(orig - synth) <= 10.0
    close_match_rate = np.mean(close_matches)

    return {
        'exact_match_rate': float(exact_match_rate),
        'near_match_rate': float(near_match_rate),
        'close_match_rate': float(close_match_rate),
        'mean_absolute_difference': float(np.mean(np.abs(orig - synth)))
    }


# ===========================
# Advanced Medical Imaging Metrics
# ===========================

def compute_hu_distribution_similarity(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> Dict[str, float]:
    """
    Analyze Hounsfield Unit distribution similarity.

    Medical imaging specific: CT values must match expected tissue distributions.
    Essential for clinical realism.

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        mask: Optional binary mask

    Returns:
        Dictionary with HU distribution metrics
    """
    if mask is not None and np.any(mask):
        orig_vals = original[mask].flatten()
        synth_vals = synthetic[mask].flatten()
    else:
        orig_vals = original.flatten()
        synth_vals = synthetic.flatten()

    # Statistical moments
    orig_mean, synth_mean = np.mean(orig_vals), np.mean(synth_vals)
    orig_std, synth_std = np.std(orig_vals), np.std(synth_vals)
    orig_skew = float(moment(orig_vals, moment=3) / (orig_std ** 3 + 1e-6))
    synth_skew = float(moment(synth_vals, moment=3) / (synth_std ** 3 + 1e-6))
    orig_kurt = float(moment(orig_vals, moment=4) / (orig_std ** 4 + 1e-6))
    synth_kurt = float(moment(synth_vals, moment=4) / (synth_std ** 4 + 1e-6))

    # Percentile comparison (clinically relevant ranges)
    percentiles = [1, 5, 25, 50, 75, 95, 99]
    orig_percentiles = np.percentile(orig_vals, percentiles)
    synth_percentiles = np.percentile(synth_vals, percentiles)
    percentile_mae = np.mean(np.abs(orig_percentiles - synth_percentiles))

    # Dynamic range
    orig_range = float(orig_vals.max() - orig_vals.min())
    synth_range = float(synth_vals.max() - synth_vals.min())

    return {
        'mean_difference': float(abs(orig_mean - synth_mean)),
        'std_difference': float(abs(orig_std - synth_std)),
        'skewness_difference': float(abs(orig_skew - synth_skew)),
        'kurtosis_difference': float(abs(orig_kurt - synth_kurt)),
        'percentile_mae': float(percentile_mae),
        'dynamic_range_ratio': float(synth_range / (orig_range + 1e-6)),
        'distribution_similarity_score': float(1.0 / (1.0 + percentile_mae / 100))
    }


def compute_noise_power_spectrum(
    volume: np.ndarray,
    mask: np.ndarray,
    roi_size: int = 64
) -> Dict[str, float]:
    """
    Compute Noise Power Spectrum (NPS) for CT image quality assessment.

    NPS characterizes noise texture - critical for radiologist perception.
    Over-smoothed images have too little high-frequency noise.

    Args:
        volume: CT volume (Z,Y,X)
        mask: Binary mask for ROI selection
        roi_size: Size of ROI for NPS computation

    Returns:
        Dictionary with NPS metrics
    """
    if not np.any(mask):
        return {'nps_peak_frequency': 0.0, 'nps_integral': 0.0, 'nps_uniformity': 0.0}

    from scipy.fft import fft2, fftshift

    # Find uniform regions in mask for NPS calculation
    z_mid = mask.shape[0] // 2
    slice_mask = mask[z_mid]

    if not np.any(slice_mask):
        return {'nps_peak_frequency': 0.0, 'nps_integral': 0.0, 'nps_uniformity': 0.0}

    # Extract ROI
    y_idx, x_idx = np.where(slice_mask)
    if len(y_idx) < roi_size or len(x_idx) < roi_size:
        return {'nps_peak_frequency': 0.0, 'nps_integral': 0.0, 'nps_uniformity': 0.0}

    y_center = int(np.mean(y_idx))
    x_center = int(np.mean(x_idx))

    y_start = max(0, y_center - roi_size // 2)
    x_start = max(0, x_center - roi_size // 2)
    y_end = min(mask.shape[1], y_start + roi_size)
    x_end = min(mask.shape[2], x_start + roi_size)

    roi = volume[z_mid, y_start:y_end, x_start:x_end].astype(float)

    if roi.shape[0] < 32 or roi.shape[1] < 32:
        return {'nps_peak_frequency': 0.0, 'nps_integral': 0.0, 'nps_uniformity': 0.0}

    # Detrend (remove low-frequency component)
    roi_detrend = roi - ndimage.gaussian_filter(roi, sigma=5)

    # Compute 2D FFT
    fft_result = fft2(roi_detrend)
    fft_shift = fftshift(fft_result)
    power_spectrum = np.abs(fft_shift) ** 2

    # Radial profile
    center = (power_spectrum.shape[0] // 2, power_spectrum.shape[1] // 2)
    y, x = np.ogrid[:power_spectrum.shape[0], :power_spectrum.shape[1]]
    r = np.sqrt((x - center[1])**2 + (y - center[0])**2).astype(int)

    radial_profile = ndimage.mean(power_spectrum, labels=r, index=np.arange(r.max() + 1))

    # NPS metrics
    peak_freq = float(np.argmax(radial_profile[1:]) + 1)  # Skip DC
    nps_integral = float(np.sum(radial_profile[1:]))
    nps_uniformity = float(np.std(radial_profile[1:20]) / (np.mean(radial_profile[1:20]) + 1e-6))

    return {
        'nps_peak_frequency': peak_freq,
        'nps_integral': nps_integral,
        'nps_uniformity': nps_uniformity
    }


def compute_anatomical_fidelity(
    original: np.ndarray,
    synthetic: np.ndarray,
    spacing: Tuple[float, float, float]
) -> Dict[str, float]:
    """
    Assess anatomical structure preservation.

    Measures whether synthetic CT maintains anatomical landmarks,
    organ shapes, and spatial relationships.

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        spacing: Voxel spacing (dz, dy, dx)

    Returns:
        Dictionary with anatomical fidelity metrics
    """
    # Body mask for both
    orig_body = (original > -850).astype(bool)
    synth_body = (synthetic > -850).astype(bool)

    # Volume similarity (Dice coefficient)
    intersection = np.sum(orig_body & synth_body)
    union = np.sum(orig_body) + np.sum(synth_body)
    dice = 2.0 * intersection / (union + 1e-6)

    # Centroid preservation
    orig_centroid = np.array(ndimage.center_of_mass(orig_body.astype(float)))
    synth_centroid = np.array(ndimage.center_of_mass(synth_body.astype(float)))
    centroid_distance = np.linalg.norm((orig_centroid - synth_centroid) * spacing)

    # Bounding box similarity
    orig_bbox = [np.where(orig_body)[i] for i in range(3)]
    synth_bbox = [np.where(synth_body)[i] for i in range(3)]

    bbox_similarity = []
    for i in range(3):
        if len(orig_bbox[i]) > 0 and len(synth_bbox[i]) > 0:
            orig_size = (orig_bbox[i].max() - orig_bbox[i].min()) * spacing[i]
            synth_size = (synth_bbox[i].max() - synth_bbox[i].min()) * spacing[i]
            bbox_similarity.append(min(orig_size, synth_size) / (max(orig_size, synth_size) + 1e-6))

    bbox_sim = float(np.mean(bbox_similarity)) if bbox_similarity else 0.0

    # Hausdorff distance (surface similarity)
    from scipy.ndimage import distance_transform_edt

    orig_surface = orig_body.astype(float) - ndimage.binary_erosion(orig_body).astype(float)
    synth_surface = synth_body.astype(float) - ndimage.binary_erosion(synth_body).astype(float)

    if np.any(orig_surface) and np.any(synth_surface):
        dist_orig_to_synth = distance_transform_edt(~synth_surface, sampling=spacing)
        dist_synth_to_orig = distance_transform_edt(~orig_surface, sampling=spacing)

        hausdorff_dist = max(
            np.max(dist_orig_to_synth[orig_surface > 0]),
            np.max(dist_synth_to_orig[synth_surface > 0])
        )
    else:
        hausdorff_dist = float('inf')

    return {
        'dice_coefficient': float(dice),
        'centroid_distance_mm': float(centroid_distance),
        'bounding_box_similarity': float(bbox_sim),
        'hausdorff_distance_mm': float(hausdorff_dist) if hausdorff_dist != float('inf') else 999.0,
        'anatomical_fidelity_score': float((dice + bbox_sim) / 2.0)
    }


def compute_frequency_domain_fidelity(
    original: np.ndarray,
    synthetic: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> Dict[str, float]:
    """
    Analyze frequency domain similarity using DCT.

    Low frequencies = anatomical structure
    High frequencies = texture and edges

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        mask: Optional binary mask

    Returns:
        Dictionary with frequency domain metrics
    """
    if mask is not None:
        orig = original * mask
        synth = synthetic * mask
    else:
        orig = original
        synth = synthetic

    # 3D DCT
    from scipy.fft import dctn

    dct_orig = dctn(orig.astype(float), type=2, norm='ortho')
    dct_synth = dctn(synth.astype(float), type=2, norm='ortho')

    # Low frequency (structure) vs high frequency (texture)
    z, y, x = dct_orig.shape
    low_freq_mask = np.zeros_like(dct_orig, dtype=bool)
    low_freq_mask[:z//4, :y//4, :x//4] = True

    high_freq_mask = ~low_freq_mask

    # Correlation in low frequencies (structure preservation)
    low_freq_orig = dct_orig[low_freq_mask].flatten()
    low_freq_synth = dct_synth[low_freq_mask].flatten()
    if len(low_freq_orig) > 0:
        low_freq_corr = np.corrcoef(low_freq_orig, low_freq_synth)[0, 1]
        if np.isnan(low_freq_corr):
            low_freq_corr = 0.0
    else:
        low_freq_corr = 0.0

    # Correlation in high frequencies (texture)
    high_freq_orig = dct_orig[high_freq_mask].flatten()
    high_freq_synth = dct_synth[high_freq_mask].flatten()
    if len(high_freq_orig) > 0:
        high_freq_corr = np.corrcoef(high_freq_orig, high_freq_synth)[0, 1]
        if np.isnan(high_freq_corr):
            high_freq_corr = 0.0
    else:
        high_freq_corr = 0.0

    # Energy preservation
    low_freq_energy_ratio = np.sum(np.abs(dct_synth[low_freq_mask])) / (np.sum(np.abs(dct_orig[low_freq_mask])) + 1e-6)
    high_freq_energy_ratio = np.sum(np.abs(dct_synth[high_freq_mask])) / (np.sum(np.abs(dct_orig[high_freq_mask])) + 1e-6)

    return {
        'low_freq_correlation': float(low_freq_corr),
        'high_freq_correlation': float(high_freq_corr),
        'low_freq_energy_ratio': float(low_freq_energy_ratio),
        'high_freq_energy_ratio': float(high_freq_energy_ratio),
        'structure_preservation_score': float(low_freq_corr),
        'texture_similarity_score': float(high_freq_corr)
    }


def compute_tissue_specific_metrics(
    original: np.ndarray,
    synthetic: np.ndarray,
    body_mask: np.ndarray,
    lung_mask: np.ndarray
) -> Dict[str, Dict[str, float]]:
    """
    Compute metrics for specific tissue types.

    Different tissues have different HU ranges and characteristics.
    Tissue-specific evaluation is critical for clinical realism.

    Args:
        original: Original CT volume
        synthetic: Synthetic CT volume
        body_mask: Body region mask
        lung_mask: Lung region mask

    Returns:
        Dictionary with tissue-specific metrics
    """
    results = {}

    # Define tissue regions
    tissues = {
        'air': original < -900,
        'lung': lung_mask & (original >= -900),
        'soft_tissue': body_mask & ~lung_mask & (original >= -100) & (original <= 200),
        'bone': body_mask & (original > 200)
    }

    for tissue_name, tissue_mask in tissues.items():
        if not np.any(tissue_mask):
            results[tissue_name] = {
                'mean_hu_diff': 0.0,
                'std_hu_diff': 0.0,
                'mae': 0.0,
                'correlation': 0.0
            }
            continue

        orig_vals = original[tissue_mask]
        synth_vals = synthetic[tissue_mask]

        mean_diff = float(abs(np.mean(orig_vals) - np.mean(synth_vals)))
        std_diff = float(abs(np.std(orig_vals) - np.std(synth_vals)))
        mae = float(np.mean(np.abs(orig_vals - synth_vals)))

        if len(orig_vals) > 1:
            corr = np.corrcoef(orig_vals, synth_vals)[0, 1]
            if np.isnan(corr):
                corr = 0.0
        else:
            corr = 0.0

        results[tissue_name] = {
            'mean_hu_diff': mean_diff,
            'std_hu_diff': std_diff,
            'mae': mae,
            'correlation': float(corr)
        }

    return results


# ===========================
# Comprehensive Evaluation
# ===========================

def evaluate_synthetic_ct(
    original: np.ndarray,
    synthetic: np.ndarray,
    body_mask: np.ndarray,
    lung_mask: np.ndarray,
    nodule_mask: Optional[np.ndarray] = None,
    spacing: Tuple[float, float, float] = (1.5, 0.7, 0.7),
    method_name: str = "Unknown"
) -> Dict[str, Any]:
    """
    Comprehensive evaluation of synthetic CT quality.

    Computes all image quality, clinical utility, and privacy metrics.

    Args:
        original: Original CT volume (Z,Y,X)
        synthetic: Synthetic CT volume (Z,Y,X)
        body_mask: Binary body mask
        lung_mask: Binary lung mask
        nodule_mask: Optional binary nodule mask
        spacing: Voxel spacing (dz, dy, dx) in mm
        method_name: Name of generation method

    Returns:
        Dictionary with comprehensive metrics
    """
    print(f"\n{'='*60}")
    print(f"Evaluating: {method_name}")
    print(f"{'='*60}")

    results = {
        'method': method_name,
        'image_quality': {},
        'clinical_utility': {},
        'privacy': {}
    }

    # ===== Image Quality Metrics =====
    print("\n[1/3] Computing image quality metrics...")

    results['image_quality']['ssim_full'] = compute_ssim(original, synthetic, mask=None)
    results['image_quality']['ssim_body'] = compute_ssim(original, synthetic, mask=body_mask)
    results['image_quality']['ssim_lung'] = compute_ssim(original, synthetic, mask=lung_mask)

    results['image_quality']['psnr_full'] = compute_psnr(original, synthetic, mask=None)
    results['image_quality']['psnr_body'] = compute_psnr(original, synthetic, mask=body_mask)

    results['image_quality']['ms_ssim'] = compute_ms_ssim(original, synthetic, mask=body_mask)
    results['image_quality']['nmse'] = compute_nmse(original, synthetic, mask=body_mask)

    print(f"  SSIM (body): {results['image_quality']['ssim_body']:.4f}")
    print(f"  PSNR (body): {results['image_quality']['psnr_body']:.2f} dB")
    print(f"  MS-SSIM: {results['image_quality']['ms_ssim']:.4f}")

    # ===== Clinical Utility Metrics =====
    print("\n[2/3] Computing clinical utility metrics...")

    # SNR (tissue vs air)
    air_mask = (original < -900) & ~body_mask
    tissue_mask = body_mask & ~lung_mask
    if np.any(tissue_mask) and np.any(air_mask):
        results['clinical_utility']['snr'] = compute_snr(synthetic, tissue_mask, air_mask)
        print(f"  SNR: {results['clinical_utility']['snr']:.2f} dB")

    # CNR (nodule vs lung)
    if nodule_mask is not None and np.any(nodule_mask):
        normal_lung = lung_mask & ~nodule_mask
        if np.any(normal_lung):
            results['clinical_utility']['cnr'] = compute_cnr(
                synthetic, nodule_mask, normal_lung, air_mask
            )
            print(f"  CNR (nodule vs lung): {results['clinical_utility']['cnr']:.2f}")

            # Nodule detectability
            nodule_metrics = compute_nodule_detectability_index(
                synthetic, nodule_mask, lung_mask, spacing
            )
            results['clinical_utility']['nodule_detectability'] = nodule_metrics
            print(f"  Nodule detectability index: {nodule_metrics['detectability_index']:.2f}")
            print(f"  Nodule contrast: {nodule_metrics['contrast']:.1f} HU")

    # Edge sharpness
    results['clinical_utility']['edge_sharpness_body'] = compute_edge_sharpness(synthetic, body_mask)
    results['clinical_utility']['edge_sharpness_lung'] = compute_edge_sharpness(synthetic, lung_mask)
    print(f"  Edge sharpness (body): {results['clinical_utility']['edge_sharpness_body']:.2f}")

    # ===== Privacy Metrics =====
    print("\n[3/5] Computing privacy metrics...")

    results['privacy']['mutual_information_body'] = compute_mutual_information(
        original, synthetic, body_mask
    )
    results['privacy']['mutual_information_lung'] = compute_mutual_information(
        original, synthetic, lung_mask
    )
    print(f"  Mutual Information (body): {results['privacy']['mutual_information_body']:.3f} bits")
    print(f"  Mutual Information (lung): {results['privacy']['mutual_information_lung']:.3f} bits")

    hist_dist = compute_histogram_distance(original, synthetic, body_mask)
    results['privacy']['histogram_distance'] = hist_dist
    print(f"  Wasserstein distance: {hist_dist['wasserstein_distance']:.2f}")

    texture_sim = compute_texture_similarity(original, synthetic, body_mask)
    results['privacy']['texture_similarity'] = texture_sim
    print(f"  Texture correlation: {texture_sim['variance_correlation']:.4f}")

    copying = detect_intensity_copying(original, synthetic, body_mask)
    results['privacy']['intensity_copying'] = copying
    print(f"  Exact match rate: {copying['exact_match_rate']*100:.2f}%")

    # ===== Advanced Medical Imaging Metrics =====
    print("\n[4/5] Computing advanced medical imaging metrics...")

    hu_dist = compute_hu_distribution_similarity(original, synthetic, body_mask)
    results['advanced'] = {'hu_distribution': hu_dist}
    print(f"  HU distribution similarity: {hu_dist['distribution_similarity_score']:.4f}")
    print(f"  Mean HU difference: {hu_dist['mean_difference']:.2f}")

    nps_orig = compute_noise_power_spectrum(original, body_mask)
    nps_synth = compute_noise_power_spectrum(synthetic, body_mask)
    results['advanced']['nps_original'] = nps_orig
    results['advanced']['nps_synthetic'] = nps_synth
    print(f"  NPS peak frequency (orig/synth): {nps_orig['nps_peak_frequency']:.1f} / {nps_synth['nps_peak_frequency']:.1f}")

    anat_fidelity = compute_anatomical_fidelity(original, synthetic, spacing)
    results['advanced']['anatomical_fidelity'] = anat_fidelity
    print(f"  Anatomical fidelity score: {anat_fidelity['anatomical_fidelity_score']:.4f}")
    print(f"  Dice coefficient: {anat_fidelity['dice_coefficient']:.4f}")

    freq_fidelity = compute_frequency_domain_fidelity(original, synthetic, body_mask)
    results['advanced']['frequency_fidelity'] = freq_fidelity
    print(f"  Structure preservation (low-freq corr): {freq_fidelity['structure_preservation_score']:.4f}")
    print(f"  Texture similarity (high-freq corr): {freq_fidelity['texture_similarity_score']:.4f}")

    # ===== Tissue-Specific Metrics =====
    print("\n[5/5] Computing tissue-specific metrics...")

    tissue_metrics = compute_tissue_specific_metrics(original, synthetic, body_mask, lung_mask)
    results['tissue_specific'] = tissue_metrics

    for tissue_name, metrics in tissue_metrics.items():
        if metrics['mae'] > 0:
            print(f"  {tissue_name.capitalize()}: MAE={metrics['mae']:.2f} HU, Corr={metrics['correlation']:.4f}")

    print(f"\n{'='*60}")
    print(f"Evaluation complete!")
    print(f"{'='*60}\n")

    return results
