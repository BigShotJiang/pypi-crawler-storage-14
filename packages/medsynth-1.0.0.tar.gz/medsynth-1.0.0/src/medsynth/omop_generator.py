# src/medsynth/omop_generator.py
from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .config import OMOPConfig


# ---------------------------------------------------------------------
# Concept maps (aligned with your NSCLC-Radiomics → OMOP mapping spec)
# ---------------------------------------------------------------------

DEVICE_CONCEPT_BY_MODALITY = {
    "CT": 4207520,
    "DX": 45772856,
    "CR": 37397241,
}
DEVICE_TYPE_CONCEPT_ID = 32817  # provenance/type

LUNG_CANCER_CONCEPT_ID = 4115276  # Malignant neoplasm of bronchus and lung

# Value concepts for overall stage (value_as_concept_id)
STAGE_VALUE_CONCEPT: Dict[str, int] = {
    # unknown/NA will be 0
    "I": 37163939,
    "II": 37151061,
    "IIIa": 37163996,
    "IIIb": 37163999,
}

# Value concepts for histology (value_as_concept_id)
HISTOLOGY_VALUE_CONCEPT: Dict[str, int] = {
    # unknown/NA will be 0
    "adenocarcinoma": 4112738,
    "squamous cell carcinoma": 4110705,
    "large cell": 4110589,
    "nos": 0,  # not otherwise specified / unknown
}


def _to_bool_int(v: Optional[bool]) -> int:
    if v is True:
        return 1
    if v is False:
        return 0
    return 0


class OMOPCDMGenerator:
    """
    Generate OMOP-CDM aligned records for synthetic / augmented NSCLC imaging datasets.

    Tables we populate by default:
      - PERSON
      - VISIT_OCCURRENCE
      - DEVICE_EXPOSURE (for imaging modality)
      - CONDITION_OCCURRENCE (lung cancer diagnosis)
      - OBSERVATION (overall stage, histology — optional)
      - REALM_FILE (REALM extension: file metadata for DICOM/NRRD)
      - RADIOLOGY_OCCURRENCE, RADIOLOGY_IMAGE (R-CDM extension)

    Design decisions (to address review comments):

      * We **do not** create MEASUREMENT rows for “CT of chest” or similar
        non-numeric procedures. MEASUREMENT is used only for truly numeric
        imaging outputs (e.g., nodule diameter in mm), with concept_id=0
        unless a proper LOINC/SNOMED is supplied by the caller.

      * OBSERVATION rows use:
            observation_concept_id = 35820498  (LUNG cancer)
        and encode stage / histology via `value_as_concept_id`.

      * We enforce referential integrity **within the generator**:
        any clinical row (OBSERVATION, MEASUREMENT, DEVICE_EXPOSURE,
        CONDITION_OCCURRENCE, REALM_FILE, RADIOLOGY_OCCURRENCE) is only created
        if the referenced `person_id` was produced by this generator via
        `generate_person_record()` (or `get_or_create_person()`).
        Otherwise the row is skipped with a warning, so the CDM load will not
        violate foreign keys or silently drop records later.
    """

    def __init__(self, config: OMOPConfig):
        self.config = config

        # Surrogate key counters
        self.person_id_counter = 1
        self.visit_occurrence_id_counter = 1
        self.device_exposure_id_counter = 1
        self.condition_occurrence_id_counter = 1
        self.observation_id_counter = 1

        # Extension counters
        self.realm_file_id_counter = 1
        self.radiology_occurrence_id_counter = 1
        self.radiology_image_id_counter = 1

        # Internal index: which person_ids exist, and map from patient source value
        self._known_person_ids: set[int] = set()
        self._person_by_source: Dict[str, int] = {}

        # In-memory stores to export
        self._buffer: Dict[str, List[Dict[str, Any]]] = {
            "PERSON": [],
            "VISIT_OCCURRENCE": [],
            "DEVICE_EXPOSURE": [],
            "CONDITION_OCCURRENCE": [],
            "OBSERVATION": [],
            # Extensions
            "REALM_FILE": [],
            "RADIOLOGY_OCCURRENCE": [],
            "RADIOLOGY_IMAGE": [],
            # Optional MEASUREMENT pool (for true numeric imaging results, if used)
            "MEASUREMENT": [],
        }

    # ------------------------------------------------------------------
    # PERSON helpers
    # ------------------------------------------------------------------

    def get_or_create_person(
        self,
        patient_id: str,
        birth_date: datetime,
        sex: str,
    ) -> Dict[str, Any]:
        """
        Convenience wrapper that ensures a single PERSON row per `patient_id`
        and returns the PERSON record.

        Use this in your ETL instead of constructing person_id externally.
        """
        if patient_id in self._person_by_source:
            pid = self._person_by_source[patient_id]
            # Find record in buffer (small; cost is negligible compared to IO)
            for rec in self._buffer["PERSON"]:
                if rec["person_id"] == pid:
                    return rec
            # Should not happen, but fall through to regenerate if needed.

        return self.generate_person_record(patient_id, birth_date, sex)

    def generate_person_record(
        self,
        patient_id: str,
        birth_date: datetime,
        sex: str,
    ) -> Dict[str, Any]:
        gender_concept_map = {"M": 8507, "F": 8532, "male": 8507, "female": 8532}
        sex_norm = (sex or "").strip()
        sex_key = sex_norm.upper()

        rec = {
            "person_id": self.person_id_counter,
            "gender_concept_id": gender_concept_map.get(sex_key, 0),
            "year_of_birth": birth_date.year,
            "month_of_birth": birth_date.month,
            "day_of_birth": birth_date.day,
            "birth_datetime": birth_date.isoformat(),
            "race_concept_id": 0,
            "ethnicity_concept_id": 0,
            "location_id": None,
            "provider_id": None,
            "care_site_id": None,
            "person_source_value": patient_id,
            "gender_source_value": sex_norm,
            "gender_source_concept_id": 0,
            "race_source_value": None,
            "race_source_concept_id": 0,
            "ethnicity_source_value": None,
            "ethnicity_source_concept_id": 0,
        }
        self._buffer["PERSON"].append(rec)

        self._known_person_ids.add(rec["person_id"])
        self._person_by_source[patient_id] = rec["person_id"]

        self.person_id_counter += 1
        return rec

    def _check_person_or_skip(self, person_id: int, table: str) -> bool:
        """
        Internal helper: enforce that clinical rows only reference valid
        PERSON records. Returns True if ok, False if row should be skipped.
        """
        if person_id in self._known_person_ids:
            return True

        print(
            f"[OMOPCDM] WARNING: skipping {table} row for unknown person_id={person_id}. "
            "Create PERSON first via get_or_create_person() or generate_person_record().",
            file=sys.stderr,
        )
        return False

    # ------------------------------------------------------------------
    # VISIT_OCCURRENCE
    # ------------------------------------------------------------------

    def generate_visit_occurrence_record(
        self,
        person_id: int,
        visit_date: datetime,
        visit_type: str = "outpatient",
    ) -> Optional[Dict[str, Any]]:
        if not self._check_person_or_skip(person_id, "VISIT_OCCURRENCE"):
            return None

        visit_concept_map = {"outpatient": 9202, "inpatient": 9201, "emergency": 9203}
        visit_end = visit_date + timedelta(hours=2)

        rec = {
            "visit_occurrence_id": self.visit_occurrence_id_counter,
            "person_id": person_id,
            "visit_concept_id": visit_concept_map.get(visit_type, 9202),
            "visit_start_date": visit_date.date().isoformat(),
            "visit_start_datetime": visit_date.isoformat(),
            "visit_end_date": visit_end.date().isoformat(),
            "visit_end_datetime": visit_end.isoformat(),
            "visit_type_concept_id": 44818518,  # EHR
            "provider_id": None,
            "care_site_id": None,
            "visit_source_value": visit_type,
            "visit_source_concept_id": 0,
            "admitted_from_concept_id": 0,
            "admitted_from_source_value": None,
            "discharged_to_concept_id": 0,
            "discharged_to_source_value": None,
            "preceding_visit_occurrence_id": None,
        }
        self._buffer["VISIT_OCCURRENCE"].append(rec)
        self.visit_occurrence_id_counter += 1
        return rec

    # ------------------------------------------------------------------
    # DEVICE_EXPOSURE (Imaging modality)
    # ------------------------------------------------------------------

    def generate_device_exposure_record(
        self,
        person_id: int,
        visit_occurrence_id: Optional[int],
        start_datetime: datetime,
        modality: str = "CT",
        manufacturer: Optional[str] = None,
        unique_device_id: Optional[str] = None,
        study_instance_uid: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        if not self._check_person_or_skip(person_id, "DEVICE_EXPOSURE"):
            return None

        device_concept = DEVICE_CONCEPT_BY_MODALITY.get((modality or "").upper(), 0)
        rec = {
            "device_exposure_id": self.device_exposure_id_counter,
            "person_id": person_id,
            "device_concept_id": device_concept,
            "device_exposure_start_date": start_datetime.date().isoformat(),
            "device_exposure_start_datetime": start_datetime.isoformat(),
            "device_exposure_end_date": start_datetime.date().isoformat(),
            "device_exposure_end_datetime": start_datetime.isoformat(),
            "device_type_concept_id": DEVICE_TYPE_CONCEPT_ID,
            "unique_device_id": unique_device_id or study_instance_uid or "",
            "quantity": None,
            "provider_id": None,
            "visit_occurrence_id": visit_occurrence_id,
            "device_source_value": (modality or "").upper(),
            "device_source_concept_id": device_concept if device_concept else 0,
        }
        self._buffer["DEVICE_EXPOSURE"].append(rec)
        self.device_exposure_id_counter += 1
        return rec

    # ------------------------------------------------------------------
    # CONDITION_OCCURRENCE (Lung cancer diagnosis)
    # ------------------------------------------------------------------

    def generate_condition_occurrence_record(
        self,
        person_id: int,
        visit_occurrence_id: Optional[int],
        start_date: datetime,
        condition_concept_id: int = LUNG_CANCER_CONCEPT_ID,
        condition_source_value: str = "C34",
    ) -> Optional[Dict[str, Any]]:
        if not self._check_person_or_skip(person_id, "CONDITION_OCCURRENCE"):
            return None

        rec = {
            "condition_occurrence_id": self.condition_occurrence_id_counter,
            "person_id": person_id,
            "condition_concept_id": int(condition_concept_id),
            "condition_start_date": start_date.date().isoformat(),
            "condition_start_datetime": start_date.isoformat(),
            "condition_type_concept_id": 32817,  # from EHR/registry
            "stop_reason": None,
            "provider_id": None,
            "visit_occurrence_id": visit_occurrence_id,
            "condition_source_value": condition_source_value,
            "condition_source_concept_id": 0,
        }
        self._buffer["CONDITION_OCCURRENCE"].append(rec)
        self.condition_occurrence_id_counter += 1
        return rec

    # ------------------------------------------------------------------
    # OBSERVATION (Overall stage / histology)
    # ------------------------------------------------------------------

    def generate_observation_stage_record(
        self,
        person_id: int,
        visit_occurrence_id: Optional[int],
        dt: datetime,
        stage_text: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        if stage_text is None:
            return None
        if not self._check_person_or_skip(person_id, "OBSERVATION"):
            return None

        stage_key = (stage_text or "").strip().upper()
        stage_cid = STAGE_VALUE_CONCEPT.get(stage_key, 0)

        rec = {
            "observation_id": self.observation_id_counter,
            "person_id": person_id,
            # high-level LUNG CANCER concept; value_as_concept_id encodes the stage
            "observation_concept_id": 35820498,
            "observation_date": dt.date().isoformat(),
            "observation_datetime": dt.isoformat(),
            "observation_type_concept_id": 32817,  # EHR
            "value_as_number": None,
            "value_as_string": None,   # no JSON blobs here
            "value_as_concept_id": stage_cid,
            "qualifier_concept_id": 0,
            "unit_concept_id": 0,
            "provider_id": None,
            "visit_occurrence_id": visit_occurrence_id,
            "visit_detail_id": None,
            "observation_source_value": "overall_stage",
            "observation_source_concept_id": 0,
            "unit_source_value": None,
            "qualifier_source_value": None,
            "value_source_value": stage_text,
            "observation_event_id": None,
            "obs_event_field_concept_id": 0,
        }
        self._buffer["OBSERVATION"].append(rec)
        self.observation_id_counter += 1
        return rec

    def generate_observation_histology_record(
        self,
        person_id: int,
        visit_occurrence_id: Optional[int],
        dt: datetime,
        histology_text: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        if histology_text is None:
            return None
        if not self._check_person_or_skip(person_id, "OBSERVATION"):
            return None

        key = (histology_text or "").strip().lower()
        cid = HISTOLOGY_VALUE_CONCEPT.get(key, 0)

        rec = {
            "observation_id": self.observation_id_counter,
            "person_id": person_id,
            # high-level LUNG CANCER concept; value_as_concept_id encodes histology
            "observation_concept_id": 35820498,
            "observation_date": dt.date().isoformat(),
            "observation_datetime": dt.isoformat(),
            "observation_type_concept_id": 32817,
            "value_as_number": None,
            "value_as_string": None,
            "value_as_concept_id": cid,
            "qualifier_concept_id": 0,
            "unit_concept_id": 0,
            "provider_id": None,
            "visit_occurrence_id": visit_occurrence_id,
            "visit_detail_id": None,
            "observation_source_value": "histology",
            "observation_source_concept_id": 0,
            "unit_source_value": None,
            "qualifier_source_value": None,
            "value_source_value": histology_text,
            "observation_event_id": None,
            "obs_event_field_concept_id": 0,
        }
        self._buffer["OBSERVATION"].append(rec)
        self.observation_id_counter += 1
        return rec

    # ------------------------------------------------------------------
    # Optional MEASUREMENT for true numeric imaging results
    # ------------------------------------------------------------------

    def generate_numeric_measurement_record(
        self,
        person_id: int,
        visit_occurrence_id: Optional[int],
        dt: datetime,
        measurement_source_value: str,
        value_as_number: float,
        unit_concept_id: int = 0,
        measurement_concept_id: int = 0,
    ) -> Optional[Dict[str, Any]]:
        """
        Use ONLY for numeric imaging results (e.g., largest_nodule_diameter_mm).

        If you do not yet have a proper LOINC/SNOMED for the numeric quantity,
        pass measurement_concept_id=0 and rely on `measurement_source_value`
        for semantics.
        """
        if not self._check_person_or_skip(person_id, "MEASUREMENT"):
            return None

        rec = {
            "measurement_id": len(self._buffer["MEASUREMENT"]) + 1,
            "person_id": person_id,
            "measurement_concept_id": int(measurement_concept_id or 0),
            "measurement_date": dt.date().isoformat(),
            "measurement_datetime": dt.isoformat(),
            "measurement_time": dt.time().isoformat(),
            "measurement_type_concept_id": 44818701,  # physical exam/result
            "operator_concept_id": 0,
            "value_as_number": float(value_as_number),
            "value_as_concept_id": 0,
            "unit_concept_id": int(unit_concept_id or 0),
            "range_low": None,
            "range_high": None,
            "provider_id": None,
            "visit_occurrence_id": visit_occurrence_id,
            "visit_detail_id": None,
            "measurement_source_value": measurement_source_value,
            "measurement_source_concept_id": 0,
            "unit_source_value": None,
            "unit_source_concept_id": 0,
            "value_source_value": None,
            "measurement_event_id": None,
            "meas_event_field_concept_id": 0,
        }
        self._buffer["MEASUREMENT"].append(rec)
        return rec

    # ------------------------------------------------------------------
    # REALM extension: file registry
    # ------------------------------------------------------------------

    def add_realm_file_record(
        self,
        person_id: int,
        file_type: str,                # "DICOM" or "NRRD"
        file_path: Optional[str],      # absolute or relative
        related_study_id: Optional[str],
        modality: Optional[str],
        created_at: Optional[datetime] = None,
        source_system: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        if not self._check_person_or_skip(person_id, "REALM_FILE"):
            return None

        created = created_at or datetime.now()
        rec = {
            "patient_supplement_id": self.realm_file_id_counter,
            "person_id": person_id,
            "file_path": file_path or "",
            "file_type": (file_type or "").upper(),
            "file_name": None if not file_path else Path(file_path).name,
            "file_description": None,
            "acquisition_date": created.date().isoformat(),
            "modality": modality,
            "source_system": source_system or self.config.source_system,
            "related_study_id": related_study_id or "",
            "care_site_id": None,
            "file_hash": None,
            "metadata": None,
            "created_at": created.isoformat(),
        }
        self._buffer["REALM_FILE"].append(rec)
        self.realm_file_id_counter += 1
        return rec

    # ------------------------------------------------------------------
    # R-CDM (Radiology Occurrence / Image)
    # ------------------------------------------------------------------

    def generate_radiology_occurrence_record(
        self,
        person_id: int,
        study_datetime: datetime,
        modality: str = "CT",
        manufacturer: Optional[str] = None,
        protocol_name: Optional[str] = None,
        series_count: Optional[int] = None,
        image_count: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        if not self._check_person_or_skip(person_id, "RADIOLOGY_OCCURRENCE"):
            return None

        rec = {
            "radiology_occurrence_id": self.radiology_occurrence_id_counter,
            "person_id": person_id,
            "radiology_occurrence_date": study_datetime.date().isoformat(),
            "radiology_occurrence_datetime": study_datetime.isoformat(),
            "modality": modality,
            "manufacturer": manufacturer,
            "protocol_concept_id": 0,
            "protocol_source_value": protocol_name,
            "count_of_series": series_count,
            "count_of_images": image_count,
            "radiology_note": None,
        }
        self._buffer["RADIOLOGY_OCCURRENCE"].append(rec)
        self.radiology_occurrence_id_counter += 1
        return rec

    def generate_radiology_image_record(
        self,
        radiology_occurrence_id: int,
        series_instance_uid: str,
        file_path: Optional[str],
        body_part_source_value: Optional[str],
        series_number: Optional[int],
        rows: Optional[int],
        columns: Optional[int],
        slice_thickness: Optional[float],
    ) -> Dict[str, Any]:
        rec = {
            "radiology_image_id": self.radiology_image_id_counter,
            "radiology_occurrence_id": radiology_occurrence_id,
            "radiology_series_id": series_instance_uid,
            "file_path": file_path,
            "body_part_source_value": body_part_source_value,
            "laterality_concept_id": 0,
            "series_type_concept_id": 0,
            "series_type_source_value": None,
            "series_total_number": None,
            "series_serial_number": series_number,
            "image_resolution_rows": rows,
            "image_resolution_columns": columns,
            "CT_slice_thickness": slice_thickness,
        }
        self._buffer["RADIOLOGY_IMAGE"].append(rec)
        self.radiology_image_id_counter += 1
        return rec

    # ------------------------------------------------------------------
    # Export helpers
    # ------------------------------------------------------------------

    def export_to_csv(
        self,
        tables: Optional[List[str]],
        output_dir: Path,
    ) -> Dict[str, str]:
        """
        Write requested tables to CSV. If `tables` is None, export all buffers.
        Returns a dict of {TABLE_NAME: filepath}.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        to_write = tables or list(self._buffer.keys())

        paths: Dict[str, str] = {}
        for table in to_write:
            rows = self._buffer.get(table, [])
            if not rows:
                continue
            df = pd.DataFrame(rows)
            p = output_dir / f"{table.lower()}.csv"
            df.to_csv(p, index=False)
            paths[table] = str(p)
        return paths

    def create_metadata_json(
        self,
        output_path: Path,
    ) -> None:
        """
        Emit a compact metadata JSON summarizing what we generated, suitable
        for documenting the CDM export in your model card / methods section.
        """
        summary = {
            "cdm_version": self.config.cdm_version,
            "vocabulary_version": self.config.vocabulary_version,
            "generation_date": datetime.now().isoformat(),
            "source_system": self.config.source_system,
            "record_counts": {k.lower(): len(v) for k, v in self._buffer.items()},
        }
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(summary, f, indent=2)
