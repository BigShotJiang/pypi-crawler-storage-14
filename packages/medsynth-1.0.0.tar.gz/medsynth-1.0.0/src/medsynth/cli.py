from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Optional, List

import numpy as np
import SimpleITK as sitk

from .config import (
    Config,
    VolumeConfig,
    AnatomicalFeaturesConfig,
    OutputConfig,
    get_default_config,
)
from .pipeline import SyntheticCTPipeline, _load_real_ct_any  # generic loader: file or DICOM dir
from .nrrd_exporter import NRRDExporter
from .volume_generator import (
    ChestCTVolumeGenerator,
    as_zyx,                           # shared orientation validator: enforces (Z,Y,X) contract
    finalize_for_viewer as _vg_finalize_for_viewer,  # HU + dtype finalizer
)
from .tcia_loader import find_ct_series, load_ct_series  # DICOM-only fallback

# ============================================================
# Helpers
# ============================================================

DEFAULT_TCIA_ROOT = Path(
    os.environ.get("TCIA_ROOT", "~/Documents/Github/NSCLC_Radiomics")
).expanduser()


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _pad_or_crop_to_512(img: np.ndarray) -> np.ndarray:
    """
    Center pad/crop a 2D or 3D image to 512×512 in-plane.

    - If img.ndim == 2: returns (512, 512)
    - If img.ndim == 3: returns (Z, 512, 512), preserving Z
    """
    def _one(x2d: np.ndarray) -> np.ndarray:
        h, w = x2d.shape
        target = 512
        # height
        if h < target:
            p0 = (target - h) // 2
            p1 = target - h - p0
            x2d = np.pad(x2d, ((p0, p1), (0, 0)), mode="edge")
        elif h > target:
            s = (h - target) // 2
            x2d = x2d[s: s + target, :]
        # width
        h2, w2 = x2d.shape
        if w2 < target:
            p0 = (target - w2) // 2
            p1 = target - w2 - p0
            x2d = np.pad(x2d, ((0, 0), (p0, p1)), mode="edge")
        elif w2 > target:
            s = (w2 - target) // 2
            x2d = x2d[:, s: s + target]
        return x2d

    if img.ndim == 2:
        return _one(img)
    if img.ndim == 3:
        return np.stack([_one(s) for s in img], axis=0)
    raise ValueError(f"Unsupported ndim for pad/crop: {img.ndim}")


def finalize_for_viewer(
    vol_zyx: np.ndarray, mask_zyx: Optional[np.ndarray] = None
) -> tuple[np.ndarray, Optional[np.ndarray]]:
    """
    Viewer-friendly finalization:

      1. Use volume_generator.finalize_for_viewer() for HU clipping & dtype
         conversion, assuming (Z,Y,X).
      2. Center pad/crop each slice to (512,512) for easier visualization.

    Returns:
        (volume_zyx_int16, mask_zyx_uint8_or_None)
    """
    if mask_zyx is not None:
        vol_zyx, mask_zyx = _vg_finalize_for_viewer(vol_zyx, mask_zyx)
    else:
        vol_zyx = _vg_finalize_for_viewer(vol_zyx)

    vol_zyx = _pad_or_crop_to_512(vol_zyx)
    out_mask = None
    if mask_zyx is not None:
        out_mask = _pad_or_crop_to_512(mask_zyx.astype(np.uint8))
    return vol_zyx, out_mask


def _list_single_file_volumes(root: Path) -> list[Path]:
    exts = {".nrrd", ".nhdr", ".nii", ".nii.gz", ".mhd", ".mha"}
    out: list[Path] = []
    for p in root.iterdir():
        if p.is_file():
            s = p.suffix.lower()
            if s in exts or str(p).lower().endswith(".nii.gz"):
                out.append(p)
    return sorted(out)


def _derive_series_seed(global_seed: Optional[int], series_id: str) -> Optional[int]:
    """
    Derive a deterministic per-series seed from a global seed and a series ID.

    This uses SHA-256 and takes the first 4 bytes as a 32-bit integer to ensure:
      - stability across Python versions and runs,
      - different seeds for different series given the same global seed.
    """
    if global_seed is None:
        return None
    h = hashlib.sha256()
    h.update(str(global_seed).encode("utf-8"))
    h.update(b":")
    h.update(series_id.encode("utf-8"))
    # Take first 4 bytes as unsigned 32-bit int
    return int.from_bytes(h.digest()[:4], "big")


# ============================================================
# Augmentation path
# ============================================================


def _augment_one_series(
    series_root: Path,
    out_root: Path,
    seed: Optional[int],
    noise_level: float = 0.35,
    ggo_prob: float = 0.30,
    privacy_synth_mode: bool = False,
) -> None:
    """
    Augment a *single* series root, which can be:
      - A DICOM folder (multi-file series)
      - A single enhanced-CT DICOM file
      - A single-file volume (.nrrd/.nhdr/.nii/.nii.gz/.mhd/.mha)

    Args:
        privacy_synth_mode: If True, apply privacy-synthesis using MS-STS
                           to reduce mutual information while preserving anatomy.
                           If False, augment real CT (NOT privacy-safe).

    Contract (research-focused):
      - All volumes passed into the generator must be (Z, Y, X).
      - Orientation handling is done in the loader, using metadata.
      - No shape-based axis guessing is performed here.
      - Each series gets its own deterministic RNG seed derived from
        the global --seed and the series ID (sid).
    """
    series_root = series_root.expanduser()

    # 1) Try generic single-file or DICOM folder loader
    try:
        # Expected to return (Z,Y,X) and spacing (dz,dy,dx)
        real_ct, spacing = _load_real_ct_any(series_root)
        sid = series_root.stem if series_root.is_file() else series_root.name
        print(f"[augment] Loaded via generic loader: {series_root}")
    except Exception:
        # 2) Fallback to DICOM-only flow
        sid, files = find_ct_series(series_root)
        img, spacing = load_ct_series(files)
        # SimpleITK returns (z,y,x) for GetArrayFromImage
        real_ct = sitk.GetArrayFromImage(img).astype(np.int16)
        print(f"[augment] Loaded DICOM series: {sid} ({len(files)} files)")

    # Enforce the (Z, Y, X) convention and validate dimensionality.
    ct_zyx = as_zyx(real_ct).astype(np.float32, copy=False)

    print(
        f"[augment] Base CT -> shape(Z,Y,X)={ct_zyx.shape} spacing(dz,dy,dx)={spacing} "
        f"dtype={ct_zyx.dtype}"
    )
    
    # Display mode and privacy warning
    if privacy_synth_mode:
        print(f"[augment] MODE: Privacy-Synthesis (MS-STS)")
        print(f"[augment]   → Will apply statistical texture synthesis to reduce MI")
    else:
        print(f"[augment] MODE: Augmentation (NOT Privacy-Safe)")
        print(f"[augment]   ⚠️  WARNING: Output will contain real patient intensities")
        print(f"[augment]   ⚠️  Use --privacy-synth for privacy-safe sharing")

    # Derive a per-series seed so that each case has distinct augmentations
    # while the whole run remains reproducible for a fixed global --seed.
    case_seed = _derive_series_seed(seed, str(sid))
    if case_seed is not None:
        print(f"[augment] Using generator seed {case_seed} for series '{sid}'")
    else:
        print(f"[augment] Using non-deterministic RNG for series '{sid}' (no global --seed provided)")

    feats = AnatomicalFeaturesConfig(
        generate_nodules=True,
        num_nodules_range=(3, 8),
        nodule_size_range=(4.0, 20.0),
        nodule_types=["solid", "ground_glass", "part_solid"],
        vessel_tree_complexity="none",
        bronchial_tree_levels=0,
        generate_ground_glass=True,
        ground_glass_probability=ggo_prob,
        generate_consolidation=False,
    )

    vcfg = VolumeConfig(
        volume_shape=ct_zyx.shape,
        spacing=spacing,
        features=feats,
        noise_level=noise_level,  # gentle — retain real CT look
        add_beam_hardening=False,
        add_motion_artifacts=False,
    )

    gen = ChestCTVolumeGenerator(vcfg, seed=case_seed)

    # STEP 1: Augment the real CT
    print(f"[augment] Step 1: Augmenting real CT...")
    aug = gen.generate(base_volume=ct_zyx, base_spacing=spacing)
    
    print(
        f"[augment]   → Augmented CT: shape={aug.shape} dtype={aug.dtype} "
        f"HU[min,max]=({aug.min()},{aug.max()})"
    )

    # STEP 2: If privacy-synthesis mode, apply MS-STS
    if privacy_synth_mode:
        print(f"[augment] Step 2: Applying privacy-synthesis (MS-STS)...")

        # Use MS-STS workflow
        synthetic_ct, masks_dict = gen.create_privacy_synth_from_augmented(
            augmented_volume=aug,
            augmented_spacing=spacing
        )

        print(
            f"[augment]   → Synthesized volume: shape={synthetic_ct.shape} "
            f"HU[min,max]=({synthetic_ct.min()},{synthetic_ct.max()})"
        )
        print(f"[augment]   → Privacy protection: Empirical (aims for MI < 1.8 bits)")
        print(f"[augment]   → Pathology preserved: {masks_dict['pathology'].sum()} voxels")

        # Use synthetic CT as final volume
        final_volume = synthetic_ct
        lung_mask = masks_dict.get('lung', np.zeros_like(synthetic_ct, dtype=np.uint8))
        body_mask = masks_dict.get('body', np.zeros_like(synthetic_ct, dtype=np.uint8))
        pathology_mask = masks_dict['pathology']
        nodule_mask = pathology_mask  # Combined pathology

    else:
        # Use augmented CT (NOT privacy-safe)
        final_volume = aug
        nodule_mask = gen.build_nodule_mask(aug.shape, spacing)
        lesion_mask = gen.build_lesion_mask(aug.shape, spacing)
        # Combine for display
        pathology_mask = (nodule_mask.astype(bool) | lesion_mask.astype(bool)).astype(np.uint8)
        lung_mask = None
        body_mask = None

    print(f"[augment] Pathology mask: unique={np.unique(pathology_mask)} nonzero={(pathology_mask > 0).sum()}")

    # Viewer convenience (keeps Z, pads/crops Y/X to 512)
    final_volume, pathology_mask = finalize_for_viewer(final_volume, pathology_mask)

    # Save artifacts
    mode_suffix = "_privacy_synth" if privacy_synth_mode else "_augmented"
    study_dir = out_root / "augment" / sid
    _ensure_dir(study_dir)

    nrrd_ct = study_dir / f"{mode_suffix}_ct.nrrd"
    nrrd_pathology = study_dir / f"{mode_suffix}_pathology_mask.nrrd"

    exp = NRRDExporter()
    exp.export_volume(
        final_volume,
        nrrd_ct,
        spacing,
        {
            "source": "privacy_synth" if privacy_synth_mode else "augmented",
            "series": sid,
            "privacy_mode": "ms_sts" if privacy_synth_mode else "none",
        },
        array_order="zyx",
    )
    exp.export_labelmap(
        pathology_mask.astype(np.uint8),
        nrrd_pathology,
        spacing,
        metadata={
            "meaning": "pathology_mask",
            "privacy_mode": "ms_sts" if privacy_synth_mode else "none",
        },
        array_order="zyx",
    )

    # Save additional masks if in privacy-synth mode
    if privacy_synth_mode and lung_mask is not None:
        lung_mask_padded, _ = finalize_for_viewer(lung_mask, None)
        nrrd_lung = study_dir / f"{mode_suffix}_lung_mask.nrrd"
        exp.export_labelmap(
            lung_mask_padded.astype(np.uint8),
            nrrd_lung,
            spacing,
            metadata={"meaning": "lung_mask", "privacy_mode": "ms_sts"},
            array_order="zyx",
        )
        print(f"[augment] Saved lung mask: {nrrd_lung}")
    
    if privacy_synth_mode and body_mask is not None:
        body_mask_padded, _ = finalize_for_viewer(body_mask, None)
        nrrd_body = study_dir / f"{mode_suffix}_body_mask.nrrd"
        exp.export_labelmap(
            body_mask_padded.astype(np.uint8),
            nrrd_body,
            spacing,
            metadata={"meaning": "body_mask", "privacy_mode": "ms_sts"},
            array_order="zyx",
        )
        print(f"[augment] Saved body mask: {nrrd_body}")

    # Store annotations + minimal augmentation metadata for reproducibility
    aug_meta = {
        "series_id": sid,
        "series_root": str(series_root),
        "spacing_zyx": list(spacing),
        "generator_seed": int(case_seed) if case_seed is not None else None,
        "noise_level": float(noise_level),
        "ground_glass_probability": float(ggo_prob),
        "privacy_synth_mode": bool(privacy_synth_mode),
        "privacy_mode": "ms_sts" if privacy_synth_mode else "none",
    }
    _save_json(study_dir / "annotations.json", {
        "annotations": gen.get_annotations(),
        "augmentation_metadata": aug_meta,
    })

    print(f"[augment] Saved CT        : {nrrd_ct}")
    print(f"[augment] Saved pathology : {nrrd_pathology}")
    print(f"[augment] Annotations     : {study_dir / 'annotations.json'}")
    print(f"[augment] Privacy mode    : {'MS-STS' if privacy_synth_mode else 'None'}\n")


def run_augment(
    paths: List[Path] | None,
    default_root: Path,
    out_root: Path,
    seed: Optional[int],
    privacy_synth_mode: bool = False,
) -> None:
    """
    Augment one or more series.

    - If `paths` provided: each item is a file or directory.
      If directory contains single-file volumes, process them; otherwise treat as DICOM.
    - Else: use `default_root` and auto-pick the largest CT series (same logic as loader).

    Args:
        privacy_synth_mode: If True, apply privacy-synthesis (MS-STS).
                           If False, augment real CTs (NOT privacy-safe).
    """
    if paths:
        for p in paths:
            p = p.expanduser()
            if not p.exists():
                print(f"[augment] Skipping missing path: {p}")
                continue
            if p.is_dir():
                candidates = _list_single_file_volumes(p)
                if candidates:
                    for f in candidates:
                        _augment_one_series(f, out_root, seed, privacy_synth_mode=privacy_synth_mode)
                else:
                    _augment_one_series(p, out_root, seed, privacy_synth_mode=privacy_synth_mode)
            else:
                _augment_one_series(p, out_root, seed, privacy_synth_mode=privacy_synth_mode)
    else:
        if not default_root.exists():
            print(f"[augment] Default TCIA root not found: {default_root}")
            print("          Set $TCIA_ROOT or pass path(s) to --augment.")
            return
        _augment_one_series(default_root, out_root, seed, privacy_synth_mode=privacy_synth_mode)

# ============================================================
# CLI
# ============================================================


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="synth-ct-generate",
        description=(
            "Generate synthetic 3D chest CT volumes and/or augment real CT series "
            "with DICOM/NRRD export and optional OMOP-CDM integration. "
            "Supports privacy-preserving synthesis using MS-STS."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=r"""
Examples:
  # Pure synthetic — 10 subjects with defaults
  synth-ct-generate -n 10

  # Pure synthetic with custom output and seed
  synth-ct-generate -n 5 -o ./my_output --seed 42

  # Create a default configuration JSON and exit
  synth-ct-generate --create-config my_config.json

  # Augment a real CT (NOT privacy-safe - contains real patient intensities)
  synth-ct-generate --augment data/case01

  # Privacy-synthesis using MS-STS (recommended for sharing)
  synth-ct-generate --augment data/case01 --privacy-synth

  # Privacy-synth: augment + apply MS-STS to reduce mutual information
  synth-ct-generate --augment data/case01/scan.nrrd --privacy-synth

  # Augment using default TCIA root (env $TCIA_ROOT or ~/Documents/Github/NSCLC_Radiomics)
  synth-ct-generate --augment --privacy-synth

  # Mixed run: generate N synthetics AND apply privacy-synth to real CTs
  synth-ct-generate -n 2 --mixed data/case01 data/case02 --privacy-synth

PRIVACY NOTES:
  - Without --privacy-synth: Augmented CTs contain real patient intensities (NOT privacy-safe)
  - With --privacy-synth: Applies MS-STS for empirical privacy protection (aims for MI < 1.8 bits)
  - Pure synthetic generation is privacy-safe by definition
        """,
    )

    # ----------------- Synthetic generation args -----------------
    parser.add_argument(
        "-n", "--num-subjects", type=int, default=10,
        help="Number of synthetic subjects to generate (default: 10)",
    )
    parser.add_argument("-c", "--config", type=Path, help="Path to configuration JSON file")
    parser.add_argument(
        "-o", "--output", type=Path, default=Path("./output"),
        help="Output directory (default: ./output)",
    )
    parser.add_argument("--seed", type=int, help="Random seed for reproducibility")

    parser.add_argument("--no-dicom", action="store_true", help="Skip DICOM generation")
    parser.add_argument("--no-nrrd", action="store_true", help="Skip NRRD generation")
    parser.add_argument("--no-omop", action="store_true", help="Skip OMOP-CDM generation")

    parser.add_argument(
        "--create-config", type=Path, metavar="FILE",
        help="Create a default configuration file and exit",
    )

    parser.add_argument(
        "--volume-shape", type=int, nargs=3, metavar=("Z", "Y", "X"),
        help="Override volume dimensions for pure synthetic generation",
    )
    parser.add_argument(
        "--spacing", type=float, nargs=3, metavar=("Z", "Y", "X"),
        help="Override voxel spacing (mm) for pure synthetic generation",
    )

    # ----------------- Augmentation / Mixed args -----------------
    parser.add_argument(
        "--augment",
        action="store_true",
        help="Augment a CT series. Use positional PATHS or default TCIA root if none given.",
    )
    parser.add_argument(
        "--privacy-synth",
        action="store_true",
        help=(
            "Enable privacy-synthesis mode using Multi-Scale Statistical "
            "Texture Synthesis (MS-STS) to reduce mutual information. "
            "WITHOUT this flag, augmented CTs contain real patient data (NOT privacy-safe)."
        ),
    )
    parser.add_argument(
        "--mixed", action="store_true",
        help="Run BOTH synthetic generation and augmentation in one invocation.",
    )
    parser.add_argument(
        "augment_paths", nargs="*", type=Path,
        help="Optional paths to case folders/files (DICOM or .nrrd/.nii/.mhd...) to augment.",
    )

    args = parser.parse_args()

    # ----------------- Privacy warning -----------------
    if (args.augment or args.mixed or len(args.augment_paths) > 0) and not args.privacy_synth:
        print("\n" + "="*70)
        print("⚠️  PRIVACY WARNING ⚠️")
        print("="*70)
        print("You are running in AUGMENTATION mode without --privacy-synth flag.")
        print("The output will contain REAL PATIENT INTENSITIES (NOT privacy-safe).")
        print("")
        print("For empirical privacy protection, use: --privacy-synth")
        print("This applies MS-STS synthesis to reduce mutual information.")
        print("="*70 + "\n")

    # ----------------- Create config file and exit -----------------
    if args.create_config:
        cfg = get_default_config()
        cfg.output.output_root = args.output
        cfg.to_json(args.create_config)
        print(f"Created default configuration file: {args.create_config}")
        return 0

    # ----------------- Build config (pure synthetic branch) -----------------
    if args.config:
        print(f"Loading configuration from: {args.config}")
        config = Config.from_json(args.config)
        if args.output:
            config.output.output_root = args.output
        if args.seed is not None:
            config.random_seed = args.seed
        if args.num_subjects is not None:
            config.num_subjects = args.num_subjects
    else:
        config = get_default_config()
        config.output.output_root = args.output
        if args.seed is not None:
            config.random_seed = args.seed
        if args.num_subjects is not None:
            config.num_subjects = args.num_subjects
        if args.volume_shape:
            config.volume.volume_shape = tuple(args.volume_shape)
        if args.spacing:
            config.volume.spacing = tuple(args.spacing)

    # honor toggles
    if args.no_dicom:
        config.output.generate_dicom = False
    if args.no_nrrd:
        config.output.generate_nrrd = False
    if args.no_omop:
        config.output.generate_omop = False

    # sanity
    if (
        not config.output.generate_dicom
        and not config.output.generate_nrrd
        and not (args.augment or args.mixed)
    ):
        print(
            "Error: At least one output format (DICOM or NRRD) must be enabled, "
            "unless you are running augmentation only."
        )
        return 1

    # ----------------- Decide which paths to augment -----------------
    do_augment = args.augment or args.mixed or (len(args.augment_paths) > 0)
    augment_paths = [p.expanduser() for p in args.augment_paths]

    # ----------------- Run selected operations -----------------
    try:
        # 1) Synthetic generation (if requested or in mixed)
        if not args.augment or args.mixed:
            print(f"Generating {config.num_subjects} synthetic CT studies...")
            pipeline = SyntheticCTPipeline(config)
            pipeline.generate_dataset()
            print(f"[synthetic] Output directory: {config.output.output_root}\n")

        # 2) Augmentation (if requested)
        if do_augment:
            out_root = config.output.output_root
            mode_str = "privacy-synthesis" if args.privacy_synth else "augmentation"
            print(f"Running {mode_str} mode...")
            run_augment(
                paths=augment_paths if len(augment_paths) > 0 else None,
                default_root=DEFAULT_TCIA_ROOT,
                out_root=out_root,
                seed=config.random_seed,
                privacy_synth_mode=args.privacy_synth,
            )

        # 3) Summary
        print("\n" + "=" * 70)
        print("Generation Summary")
        print("=" * 70)
        if not args.augment or args.mixed:
            print(f"Synthetic subjects: {config.num_subjects}")
            print(f"Output directory  : {config.output.output_root}")
            print(f"DICOM generated   : {config.output.generate_dicom}")
            print(f"NRRD generated    : {config.output.generate_nrrd}")
            print(f"OMOP-CDM generated: {config.output.generate_omop}")
        if do_augment:
            print(
                "Augmentation root : "
                f"{', '.join(map(str, augment_paths)) if augment_paths else str(DEFAULT_TCIA_ROOT)}"
            )
            print(f"Augmented output  : {config.output.output_root / 'augment'}")
            print(f"Privacy mode      : {'MS-STS' if args.privacy_synth else 'None'}")
            print(f"Privacy protection: {'Empirical (aims MI < 1.8 bits)' if args.privacy_synth else 'None'}")
        if config.random_seed is not None:
            print(f"Random seed       : {config.random_seed}")
        print("=" * 70)
        return 0

    except Exception as e:
        print(f"Error during generation: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())