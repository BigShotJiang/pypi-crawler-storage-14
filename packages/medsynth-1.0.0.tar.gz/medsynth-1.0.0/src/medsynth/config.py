# src/medsynth/config.py
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Union, Dict, Any
from pathlib import Path
import json

__all__ = [
    "AnatomicalFeaturesConfig",
    "VolumeConfig",
    "DICOMConfig",
    "OMOPConfig",
    "OutputConfig",
    "Config",
    "get_default_config",
]


# ---------------------------------------------------------------------
# Anatomical features
# ---------------------------------------------------------------------

@dataclass
class AnatomicalFeaturesConfig:
    """
    Configuration for anatomical features and pathology that the generator
    may create or augment into a volume.
    """

    # --- Nodules ---
    generate_nodules: bool = True
    # Ensure >=1 nodule for pipelines that expect a positive mask
    num_nodules_range: Tuple[int, int] = (1, 5)
    nodule_size_range: Tuple[float, float] = (3.0, 30.0)  # mm
    # Used by the generator for "solid" components; GGO handled separately
    nodule_hu_range: Tuple[int, int] = (-100, 100)
    nodule_types: List[str] = field(
        default_factory=lambda: ["solid", "ground_glass", "part_solid"]
    )

    # --- Lesions / masses ---
    generate_lesions: bool = False
    num_lesions_range: Tuple[int, int] = (0, 2)
    lesion_size_range: Tuple[float, float] = (10.0, 50.0)  # mm

    # --- Vessel tree ---
    # 'none' | 'low' | 'medium' | 'high'
    vessel_tree_complexity: str = "high"
    vessel_radius_range: Tuple[float, float] = (0.5, 3.0)  # (distal, proximal) mm

    # --- Bronchial tree ---
    bronchial_tree_levels: int = 4
    bronchial_wall_thickness: float = 1.0  # mm (some generators may ignore)

    # --- Ground-glass opacities ---
    generate_ground_glass: bool = True
    ground_glass_probability: float = 0.3

    # --- Emphysema ---
    # Preferred switch used by the generator:
    emphysema_severity: str = "none"  # 'none' | 'mild' | 'moderate' | 'severe'
    # Kept for compatibility with external configs:
    generate_emphysema: bool = False

    # --- Consolidation ---
    generate_consolidation: bool = False
    consolidation_probability: float = 0.2

    # --- Pleural effusion ---
    effusion_amount: str = "none"  # 'none' | 'small' | 'moderate' | 'large'
    # Compatibility toggle:
    generate_pleural_effusion: bool = False


# ---------------------------------------------------------------------
# Volume
# ---------------------------------------------------------------------

def _normalize_zyx_shape(shape: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """
    Heuristic normalization to (Z, Y, X).
    If first dim looks like a large in-plane dimension (~512) and the last dim
    looks like a short Z (~<200), assume it's (Y, X, Z) and swap.
    """
    if len(shape) != 3:
        raise ValueError(f"volume_shape must be length-3 (got {shape})")

    z, y, x = shape
    if z > 200 and x < 200:
        # Looks like (Y, X, Z)
        return (x, y, z)
    return (z, y, x)


@dataclass
class VolumeConfig:
    """
    Configuration for CT volume geometry and intensity model.
    All shapes and spacings are expressed in (Z, Y, X).
    """

    # Dimensions (Z, Y, X)
    volume_shape: Tuple[int, int, int] = (178, 512, 512)

    # Spacing in mm (Z, Y, X)
    spacing: Tuple[float, float, float] = (1.5, 0.7, 0.7)

    # HU clip range
    hu_range: Tuple[int, int] = (-1024, 3071)

    # Intensity priors
    lung_hu_mean: int = -800
    lung_hu_std: int = 100
    tissue_hu_mean: int = 40
    tissue_hu_std: int = 20
    bone_hu_mean: int = 700
    bone_hu_std: int = 200
    air_hu: int = -1000
    blood_hu_mean: int = 50

    # Features
    features: AnatomicalFeaturesConfig = field(default_factory=AnatomicalFeaturesConfig)

    # Realism knobs
    noise_level: float = 1.0
    add_beam_hardening: bool = True
    add_motion_artifacts: bool = False

    # NEW: Privacy-Synthesis MS-STS Parameters (OPTIMIZED for publication quality)
    # Optimized via 15-iteration parameter search on NSCLC Radiomics dataset
    # Optimization date: 2025-11-26 | Best composite score: 0.7586
    # Improvements: SSIM(body) 0.782→0.788, SSIM(lung) 0.950→0.953
    privacy_synth_freq_cutoff: float = 0.5456
    privacy_synth_gradient_noise_scale: float = 0.0646
    privacy_synth_psf_blur_sigma: float = 0.40
    privacy_synth_texture_noise_std: float = 5.5449
    privacy_synth_edge_enhancement_strength: float = 0.25

    def __post_init__(self) -> None:
        # Normalize any (Y, X, Z) input to (Z, Y, X)
        self.volume_shape = _normalize_zyx_shape(tuple(self.volume_shape))
        if len(self.spacing) != 3:
            raise ValueError(f"spacing must have 3 elements (got {self.spacing})")
        # Convert any lists -> tuples (e.g., when loaded from JSON)
        self.spacing = tuple(float(s) for s in self.spacing)  # type: ignore[assignment]
        self.hu_range = (int(self.hu_range[0]), int(self.hu_range[1]))


# ---------------------------------------------------------------------
# DICOM / OMOP / Output
# ---------------------------------------------------------------------

@dataclass
class DICOMConfig:
    """Configuration for DICOM metadata."""

    manufacturer: str = "SynthCT"
    manufacturer_model: str = "SyntheticCTGenerator v1.0"
    station_name: str = "SYNTH_STATION"
    institution_name: str = "Synthetic Medical Center"
    study_description: str = "CHEST CT"
    series_description: str = "Synthetic Chest CT"
    modality: str = "CT"
    slice_thickness: float = 1.5
    kvp: float = 120.0
    exposure_time: float = 500.0
    x_ray_tube_current: float = 200.0

    # Common chest window
    window_center: float = -600.0
    window_width: float = 1600.0

    # Transfer syntax
    transfer_syntax_uid: str = "1.2.840.10008.1.2.1"  # Explicit VR Little Endian


@dataclass
class OMOPConfig:
    """Configuration for OMOP-CDM integration."""

    cdm_version: str = "5.4"
    vocabulary_version: str = "v5.0"

    # Default concept IDs for chest CT
    imaging_concept_id: int = 4019204  # CT of chest
    visit_concept_id: int = 9202      # Outpatient visit

    # Source system
    source_system: str = "SYNTH_CT"


@dataclass
class OutputConfig:
    """Configuration for output generation."""

    output_root: Path = Path("./output")
    dicom_subdir: str = "dicom"
    nrrd_subdir: str = "nrrd"
    metadata_subdir: str = "metadata"
    omop_subdir: str = "omop"

    # File naming
    study_prefix: str = "STUDY"
    series_prefix: str = "SERIES"

    # Output formats
    generate_dicom: bool = True
    generate_nrrd: bool = True
    generate_omop: bool = True

    # Extras
    save_segmentation_masks: bool = True
    save_annotations: bool = True

    def __post_init__(self) -> None:
        if isinstance(self.output_root, str):
            self.output_root = Path(self.output_root)


# ---------------------------------------------------------------------
# Main config container
# ---------------------------------------------------------------------

@dataclass
class Config:
    """
    Top-level configuration used by the pipeline and CLI.

    Supports three generation modes:
    1. Pure synthesis (augmentation_input=None, privacy_synth_mode ignored)
    2. Augmentation (augmentation_input provided, privacy_synth_mode=False)
       → Augments real CT with synthetic pathology (NOT privacy-safe)
    3. Privacy-synthesis (augmentation_input provided, privacy_synth_mode=True)
       → Creates privacy-safe synthetic version using MS-STS
    """

    volume: VolumeConfig = field(default_factory=VolumeConfig)
    dicom: DICOMConfig = field(default_factory=DICOMConfig)
    omop: OMOPConfig = field(default_factory=OMOPConfig)
    output: OutputConfig = field(default_factory=OutputConfig)

    # Global settings
    random_seed: Optional[int] = None
    num_subjects: int = 10

    # --- Augmentation / Privacy-Synthesis Settings ---
    augmentation_input: Optional[Path] = None
    """
    Path to real CT data for augmentation or privacy-synthesis.
    - If None: Pure synthesis mode (privacy-safe)
    - If provided + privacy_synth_mode=False: Augmentation mode (NOT privacy-safe)
    - If provided + privacy_synth_mode=True: Privacy-synthesis mode (privacy-safe)

    Can be:
    - A directory of DICOM slices
    - A single NRRD/NIfTI/MHD file
    - A single enhanced DICOM file
    """

    privacy_synth_mode: bool = False
    """
    Enable privacy-safe synthesis using MS-STS (requires augmentation_input).

    When True:
    1. Augments the real CT with synthetic pathology
    2. Extracts geometry masks (lung, body, pathology)
    3. Applies Multi-Scale Statistical Texture Synthesis to reduce mutual information

    When False (default):
    - If augmentation_input is None: Pure synthesis (privacy-safe)
    - If augmentation_input provided: Augmentation only (NOT privacy-safe)

    PRIVACY:
    - privacy_synth_mode=True → Output is privacy-safe via MS-STS (can be shared)
    - privacy_synth_mode=False with augmentation_input → Output contains real patient data
    """

    def __post_init__(self) -> None:
        """Validate and normalize configuration."""
        # Convert augmentation_input to Path if provided as string
        if self.augmentation_input is not None:
            if isinstance(self.augmentation_input, str):
                self.augmentation_input = Path(self.augmentation_input)

        # Validate privacy_synth_mode usage
        if self.privacy_synth_mode and self.augmentation_input is None:
            import warnings
            warnings.warn(
                "privacy_synth_mode=True requires augmentation_input to be provided. "
                "Privacy-synthesis mode will be ignored (defaulting to pure synthesis).",
                UserWarning
            )
            self.privacy_synth_mode = False

    # ---------------- JSON IO ----------------

    @classmethod
    def from_json(cls, filepath: Union[str, Path]) -> "Config":
        """
        Load configuration from JSON file.
        Gracefully handles lists vs tuples and normalizes volume_shape to (Z,Y,X).
        """
        path = Path(filepath)
        with path.open("r") as f:
            data: Dict[str, Any] = json.load(f)

        # Volume + features
        volume_data = dict(data.get("volume", {}) or {})
        features_data = volume_data.pop("features", {}) or {}

        # Normalize shapes/spacings if they were stored as lists
        if "volume_shape" in volume_data:
            volume_data["volume_shape"] = tuple(volume_data["volume_shape"])
        if "spacing" in volume_data:
            volume_data["spacing"] = tuple(volume_data["spacing"])

        # Handle augmentation_input path
        aug_input = data.get("augmentation_input")
        if aug_input is not None:
            aug_input = Path(aug_input)

        return cls(
            volume=VolumeConfig(
                **volume_data,
                features=AnatomicalFeaturesConfig(**features_data),
            ),
            dicom=DICOMConfig(**(data.get("dicom", {}) or {})),
            omop=OMOPConfig(**(data.get("omop", {}) or {})),
            output=OutputConfig(**(data.get("output", {}) or {})),
            random_seed=data.get("random_seed"),
            num_subjects=int(data.get("num_subjects", 10)),
            augmentation_input=aug_input,
            privacy_synth_mode=bool(data.get("privacy_synth_mode", False)),
        )

    def to_json(self, filepath: Union[str, Path]) -> None:
        """Save configuration to JSON file."""
        path = Path(filepath)

        # Prepare a clean dict (convert Paths to str, tuples to lists for readability)
        def _tolist3(t: Tuple[Any, Any, Any]) -> List[Any]:
            return [t[0], t[1], t[2]]

        vol = self.volume
        vol_dict = {
            "volume_shape": list(vol.volume_shape),
            "spacing": list(vol.spacing),
            "hu_range": list(vol.hu_range),
            "lung_hu_mean": vol.lung_hu_mean,
            "lung_hu_std": vol.lung_hu_std,
            "tissue_hu_mean": vol.tissue_hu_mean,
            "tissue_hu_std": vol.tissue_hu_std,
            "bone_hu_mean": vol.bone_hu_mean,
            "bone_hu_std": vol.bone_hu_std,
            "air_hu": vol.air_hu,
            "blood_hu_mean": vol.blood_hu_mean,
            "noise_level": vol.noise_level,
            "add_beam_hardening": vol.add_beam_hardening,
            "add_motion_artifacts": vol.add_motion_artifacts,
            # features nested separately
        }

        data = {
            "volume": {
                **vol_dict,
                "features": self.volume.features.__dict__,
            },
            "dicom": self.dicom.__dict__,
            "omop": self.omop.__dict__,
            "output": {
                k: (str(v) if isinstance(v, Path) else v)
                for k, v in self.output.__dict__.items()
            },
            "random_seed": self.random_seed,
            "num_subjects": self.num_subjects,
            "augmentation_input": str(self.augmentation_input) if self.augmentation_input else None,
            "privacy_synth_mode": self.privacy_synth_mode,
        }

        with path.open("w") as f:
            json.dump(data, f, indent=2)


# ---------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------

def get_default_config() -> Config:
    """
    Get a default configuration that is safe for:
      - `synth-ct-generate -n 1`
      - quick scripts and tests
    
    Default mode: Pure synthesis (privacy-safe)
    """
    return Config()


def get_privacy_synth_config(
    augmentation_input: Union[str, Path],
    num_subjects: int = 1,
    random_seed: Optional[int] = None,
    output_root: Union[str, Path] = "./output"
) -> Config:
    """
    Get a configuration for privacy-synthesis using MS-STS.

    Args:
        augmentation_input: Path to real CT data (DICOM folder or NRRD/NIfTI file)
        num_subjects: Number of privacy-protected synthetic CTs to generate
        random_seed: Random seed for reproducibility
        output_root: Output directory

    Returns:
        Config configured for privacy-safe synthesis using MS-STS

    Example:
        >>> config = get_privacy_synth_config(
        ...     augmentation_input="path/to/patient_ct.nrrd",
        ...     num_subjects=1,
        ...     random_seed=42
        ... )
        >>> pipeline = SyntheticCTPipeline(config)
        >>> pipeline.generate_dataset()
    """
    config = Config(
        augmentation_input=Path(augmentation_input),
        privacy_synth_mode=True,
        num_subjects=num_subjects,
        random_seed=random_seed,
    )
    config.output.output_root = Path(output_root)
    return config


def get_augmentation_config(
    augmentation_input: Union[str, Path],
    num_subjects: int = 1,
    random_seed: Optional[int] = None,
    output_root: Union[str, Path] = "./output"
) -> Config:
    """
    Get a configuration for CT augmentation (NOT privacy-safe).
    
    WARNING: This creates augmented CTs that contain real patient intensities.
    For privacy-safe generation, use get_digital_twin_config() instead.
    
    Args:
        augmentation_input: Path to real CT data (DICOM folder or NRRD/NIfTI file)
        num_subjects: Number of augmented CTs to generate
        random_seed: Random seed for reproducibility
        output_root: Output directory
    
    Returns:
        Config configured for augmentation (NOT privacy-safe)
    
    Example:
        >>> # ⚠️ Output will contain real patient data
        >>> config = get_augmentation_config(
        ...     augmentation_input="path/to/patient_ct.nrrd",
        ...     num_subjects=1,
        ...     random_seed=42
        ... )
        >>> pipeline = SyntheticCTPipeline(config)
        >>> pipeline.generate_dataset()
    """
    config = Config(
        augmentation_input=Path(augmentation_input),
        digital_twin_mode=False,  # Augmentation only - NOT privacy-safe
        num_subjects=num_subjects,
        random_seed=random_seed,
    )
    config.output.output_root = Path(output_root)
    return config