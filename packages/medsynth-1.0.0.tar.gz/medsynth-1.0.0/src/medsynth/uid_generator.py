# src/medsynth/uid_generator.py
from __future__ import annotations
import uuid
from datetime import datetime
from typing import Optional

class UIDGenerator:
    """
    Generate DICOM UIDs using the UUID decimal root (2.25.*).
    - Deterministic mode: namespace+name (UUIDv5) for stable, reproducible UIDs.
    - Random mode: UUIDv4 per call.
    """
    UID_ROOT = "2.25"  # UUID-based OID root

    def __init__(self, seed: Optional[int] = None):
        self.seed = seed
        self._counter = 0  # used only to diversify deterministic names when seed is set

    @staticmethod
    def _uuid_to_uid(u: uuid.UUID) -> str:
        return f"{UIDGenerator.UID_ROOT}.{u.int}"   # always <= 2.25 + 39 digits = < 64 chars

    def generate_uid(self, namespace: Optional[str] = None, name: Optional[str] = None) -> str:
        if namespace and name:
            ns = uuid.uuid5(uuid.NAMESPACE_OID, namespace)
            u  = uuid.uuid5(ns, name)  # deterministic
        elif self.seed is not None:
            # deterministic but unique-per-call using a counter; stable across runs with same seed
            ns = uuid.uuid5(uuid.NAMESPACE_OID, f"seed:{self.seed}")
            u  = uuid.uuid5(ns, f"ctr:{self._counter}")
            self._counter += 1
        else:
            u = uuid.uuid4()  # random
        return self._uuid_to_uid(u)

    def generate_study_uid(self, patient_id: str, study_date: datetime) -> str:
        return self.generate_uid(f"{self.UID_ROOT}.study", f"{patient_id}_{study_date.strftime('%Y%m%d%H%M%S')}")

    def generate_series_uid(self, study_uid: str, series_number: int) -> str:
        return self.generate_uid(f"{study_uid}.series", str(series_number))

    def generate_instance_uid(self, series_uid: str, instance_number: int) -> str:
        return self.generate_uid(f"{series_uid}.instance", str(instance_number))

    def generate_frame_of_reference_uid(self, study_uid: str) -> str:
        return self.generate_uid(f"{study_uid}.frame", "reference")


class AccessionNumberGenerator:
    def __init__(self, prefix: str = "ACC", seed: Optional[int] = None):
        self.prefix = prefix
        self.seed = seed
        self._counter = 0

    def generate(self, patient_id: str, timestamp: datetime) -> str:
        date_str = timestamp.strftime("%Y%m%d")
        if self.seed is not None:
            seq = (self.seed + self._counter) % 100000
            self._counter += 1
        else:
            seq = int(timestamp.strftime("%H%M%S"))
        return f"{self.prefix}{date_str}{seq:05d}"


class PatientIDGenerator:
    def __init__(self, prefix: str = "PAT", seed: Optional[int] = None):
        self.prefix = prefix
        self.seed = seed

    def generate(self, index: int) -> str:
        num = (self.seed + index) % 1000000 if self.seed is not None else index
        return f"{self.prefix}{num:06d}"
