# src/medsynth/dicom_writer.py
"""
Simplified DICOM writer utility for synthetic CT volumes.
"""
from pathlib import Path
import pydicom
from pydicom.uid import CTImageStorage, ExplicitVRLittleEndian
from datetime import datetime
import numpy as np
from .uid_generator import UIDGenerator


def write_ct_series(vol_hu: np.ndarray, 
                   spacing: tuple, 
                   out_dir: Path,
                   patient_id: str = "SYNTH001",
                   patient_name: str = "SYNTH^CT",
                   study_description: str = "CHEST CT",
                   series_description: str = "Synthetic Augmented CT",
                   seed: int = 1234):
    """
    Write a 3D CT volume as a DICOM series.
    
    Args:
        vol_hu: 3D numpy array (Z, Y, X) with HU values
        spacing: (dz, dy, dx) in mm
        out_dir: Output directory
        patient_id: Patient ID
        patient_name: Patient name
        study_description: Study description
        series_description: Series description
        seed: Random seed for UID generation
    """
    dz, dy, dx = spacing
    z, y, x = vol_hu.shape
    
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate UIDs
    uid = UIDGenerator(seed=seed)
    study_uid = uid.generate_study_uid(
        patient_id=patient_id, 
        study_date=datetime.utcnow()
    )
    series_uid = uid.generate_series_uid(study_uid, series_number=1)
    frame_of_ref_uid = uid.generate_frame_of_reference_uid(study_uid)
    
    # Write each slice
    for i in range(z):
        ds = pydicom.Dataset()
        
        # File meta
        ds.file_meta = pydicom.Dataset()
        ds.file_meta.TransferSyntaxUID = ExplicitVRLittleEndian
        ds.file_meta.MediaStorageSOPClassUID = CTImageStorage
        ds.file_meta.MediaStorageSOPInstanceUID = uid.generate_instance_uid(series_uid, i+1)
        ds.file_meta.ImplementationClassUID = uid.generate_uid()
        ds.file_meta.ImplementationVersionName = "SYNTH_CT_1.0"
        
        # SOP Common
        ds.SOPClassUID = CTImageStorage
        ds.SOPInstanceUID = uid.generate_instance_uid(series_uid, i+1)
        
        # Patient
        ds.PatientName = patient_name
        ds.PatientID = patient_id
        ds.PatientBirthDate = ""
        ds.PatientSex = "O"
        
        # Study
        ds.StudyInstanceUID = study_uid
        ds.StudyDate = datetime.utcnow().strftime('%Y%m%d')
        ds.StudyTime = datetime.utcnow().strftime('%H%M%S')
        ds.StudyDescription = study_description
        ds.StudyID = "1"
        ds.AccessionNumber = f"ACC{datetime.utcnow().strftime('%Y%m%d')}"
        
        # Series
        ds.SeriesInstanceUID = series_uid
        ds.SeriesNumber = 1
        ds.SeriesDescription = series_description
        ds.Modality = "CT"
        ds.FrameOfReferenceUID = frame_of_ref_uid
        
        # Image geometry
        ds.ImagePositionPatient = [0.0, 0.0, float(i * dz)]
        ds.ImageOrientationPatient = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0]
        ds.PixelSpacing = [float(dy), float(dx)]
        ds.SliceThickness = float(dz)
        ds.SpacingBetweenSlices = float(dz)
        ds.SliceLocation = float(i * dz)
        
        # Image attributes
        ds.Rows = y
        ds.Columns = x
        ds.SamplesPerPixel = 1
        ds.PhotometricInterpretation = "MONOCHROME2"
        ds.BitsAllocated = 16
        ds.BitsStored = 16
        ds.HighBit = 15
        ds.PixelRepresentation = 1  # Signed
        
        # CT-specific
        ds.RescaleIntercept = 0
        ds.RescaleSlope = 1
        ds.RescaleType = "HU"
        ds.KVP = 120
        ds.ImageType = ["DERIVED", "SECONDARY"]
        
        # Instance info
        ds.InstanceNumber = i + 1
        ds.InstanceCreationDate = datetime.utcnow().strftime('%Y%m%d')
        ds.InstanceCreationTime = datetime.utcnow().strftime('%H%M%S')
        
        # Pixel data
        ds.PixelData = vol_hu[i].astype(np.int16).tobytes()
        
        # Write file
        output_path = out_dir / f"IM{i+1:04d}.dcm"
        pydicom.dcmwrite(output_path, ds, write_like_original=False)
    
    print(f"✓ Wrote {z} DICOM files to {out_dir}")
    return {
        'study_uid': study_uid,
        'series_uid': series_uid,
        'frame_of_ref_uid': frame_of_ref_uid,
        'num_files': z
    }