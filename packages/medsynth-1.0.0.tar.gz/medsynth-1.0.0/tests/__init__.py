# tests/__init__.py
"""
Test suite for synth-ct-generator package.
"""

__all__ = []
