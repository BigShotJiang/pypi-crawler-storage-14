# tests/test_quality_invariants.py
import numpy as np
import pytest
from pathlib import Path
from datetime import datetime

from medsynth import VolumeConfig, ChestCTVolumeGenerator
from medsynth.volume_generator import _gaussian_psf_slices

# --- optional DICOM roundtrip test (skipped if pydicom missing) ---
try:
    import pydicom  # type: ignore
    from types import SimpleNamespace
    from medsynth.dicom_exporter import DICOMExporter
    from medsynth.uid_generator import UIDGenerator
    HAVE_PYDICOM = True
except Exception:
    HAVE_PYDICOM = False


def _radial_power_2d_centered(img: np.ndarray, nbins: int = 128) -> np.ndarray:
    """Centered radial power spectrum via fft2 + fftshift."""
    img = img.astype(np.float32)
    f = np.fft.fft2(img - img.mean())
    p = np.abs(np.fft.fftshift(f)) ** 2

    h, w = p.shape
    cy, cx = (h - 1) / 2.0, (w - 1) / 2.0
    yy, xx = np.indices(p.shape)
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    rmax = r.max() + 1e-6
    rb = np.floor(np.clip(r / rmax * (nbins - 1), 0, nbins - 1)).astype(int)

    num = np.bincount(rb.ravel(), weights=p.ravel(), minlength=nbins).astype(np.float64)
    den = np.bincount(rb.ravel(), minlength=nbins).astype(np.float64) + 1e-9
    return num / den


# ----------------------------------------------------------------------
# 1) Physics & acquisition invariants
# ----------------------------------------------------------------------

def test_psf_applies_in_plane_only():
    vol = np.zeros((9, 33, 33), dtype=np.float32)
    vol[4, 16, 16] = 1000.0
    blurred = _gaussian_psf_slices(vol, sigma_px_xy=1.2)
    assert blurred[4].max() > blurred[3].max()
    assert blurred[4].max() > blurred[5].max()


def test_noise_not_white_low_freq_dominate():
    cfg = VolumeConfig(volume_shape=(24, 128, 128), noise_level=1.0)
    gen = ChestCTVolumeGenerator(cfg, seed=2)
    vol = gen.generate()
    sl = vol[vol.shape[0] // 2].astype(np.float32)

    nps = _radial_power_2d_centered(sl, nbins=128)
    k = max(1, len(nps) // 10)
    low = float(np.median(nps[:k]))
    high = float(np.median(nps[-k:]))
    assert low > high, f"Low-freq median {low} should exceed high-freq {high}"


def test_prior_hu_bands_present():
    cfg = VolumeConfig(volume_shape=(24, 128, 128))
    v = ChestCTVolumeGenerator(cfg, seed=5).generate()
    assert (v < -900).sum() > 50
    assert ((v > -900) & (v < -600)).sum() > 200
    assert ((v > -100) & (v < 150)).sum() > 300
    assert (v > 400).sum() > 20


# ----------------------------------------------------------------------
# 2) Geometry & anatomy invariants
# ----------------------------------------------------------------------

def test_anisotropy_respected_for_nodules():
    """
    With 2.5mm slices and ~8mm diameter, the nodule should be visible
    across multiple Z slices at the annotated center in a small XY patch.
    We use a relative criterion against the local lung baseline and also
    a fallback against the best Z slice to resist low-contrast cores.
    """
    cfg = VolumeConfig(volume_shape=(48, 128, 128), spacing=(2.5, 0.7, 0.7))
    feats = cfg.features
    feats.generate_nodules = True
    feats.num_nodules_range = (1, 1)
    feats.nodule_size_range = (8.0, 8.0)
    feats.vessel_tree_complexity = 'none'
    feats.bronchial_tree_levels = 0

    g = ChestCTVolumeGenerator(cfg, seed=123)
    vol = g.generate()
    ann = g.get_annotations()
    assert 'nodules' in ann and len(ann['nodules']) == 1

    n = ann['nodules'][0]
    cz, cy, cx = map(int, n['center_voxel'])
    diam_mm = float(n['diameter_mm'])
    z_spacing = float(cfg.spacing[0])
    expected_min = max(2, int(np.ceil(diam_mm / z_spacing)))

    # local XY patch and lung baseline on center slice
    z = int(cz)
    sl = vol[z].astype(np.float32)
    y0, y1 = max(0, cy - 5), min(sl.shape[0], cy + 6)
    x0, x1 = max(0, cx - 5), min(sl.shape[1], cx + 6)
    patch = sl[y0:y1, x0:x1]
    yy, xx = np.indices(patch.shape)
    r = np.sqrt((yy - (cy - y0)) ** 2 + (xx - (cx - x0)) ** 2)
    ring = (r > 3) & (r < 5)
    lung_baseline = float(np.median(patch[ring])) if ring.any() else -800.0

    def local_mean(zidx: int) -> float:
        sli = vol[zidx].astype(np.float32)
        y0, y1 = max(0, cy - 1), min(sli.shape[0], cy + 2)
        x0, x1 = max(0, cx - 1), min(sli.shape[1], cx + 2)
        return float(sli[y0:y1, x0:x1].mean())

    zwin = range(max(0, z - 6), min(vol.shape[0], z + 7))
    means = np.array([local_mean(k) for k in zwin], dtype=float)

    # Primary criterion: > lung_baseline + 80 HU
    present = means > (lung_baseline + 80.0)
    span = int(present.sum())

    if span == 0:
        # Fallback: relative to best slice at center (handles softer cores)
        peak = float(means.max())
        present = means > (peak - 60.0)
        span = int(present.sum())

    assert span >= 2, f"Measured axial span {span} too small for ~{diam_mm:.1f}mm @ {z_spacing:.1f}mm"


# ----------------------------------------------------------------------
# 3) Augmentation invariants (metamorphic)
# ----------------------------------------------------------------------

def test_augmentation_budget_obeyed():
    """
    Keep strong changes (>=50 HU) under ~6.5% to allow for partial-volume
    blending and quantization side-effects. Outside-lung preservation is
    verified in a separate test.
    """
    base_cfg = VolumeConfig(volume_shape=(24, 64, 64))
    base_cfg.features.generate_nodules = False
    base = ChestCTVolumeGenerator(base_cfg, seed=1).generate()

    aug_cfg = VolumeConfig(volume_shape=base.shape, spacing=base_cfg.spacing)
    feats = aug_cfg.features
    feats.generate_nodules = True
    feats.num_nodules_range = (3, 3)
    feats.vessel_tree_complexity = 'none'
    feats.bronchial_tree_levels = 0

    aug = ChestCTVolumeGenerator(aug_cfg, seed=2).generate(
        base_volume=base, base_spacing=base_cfg.spacing
    )

    diff = np.abs(aug.astype(np.int32) - base.astype(np.int32))
    strong_changed = (diff >= 50).mean()
    any_changed = (diff != 0).mean()

    assert strong_changed <= 0.065 + 1e-3, f"strong-changed={strong_changed:.4f}"
    assert any_changed <= 0.09 + 1e-3, f"any-changed={any_changed:.4f}"


def test_outside_lung_exact_preservation():
    """Outside the lung mask, >99.5% voxels should be exactly unchanged after augmentation."""
    cfg = VolumeConfig(volume_shape=(24, 64, 64))
    g = ChestCTVolumeGenerator(cfg, seed=10)
    base = g.generate()
    lung = g._quick_lung_mask(base.astype(np.float32))
    aug = ChestCTVolumeGenerator(cfg, seed=11).generate(base_volume=base, base_spacing=cfg.spacing)

    outside = ~lung
    diff = (aug.astype(np.int32) - base.astype(np.int32))
    unchanged_frac = (diff[outside] == 0).mean() if outside.any() else 1.0
    assert unchanged_frac > 0.995


# ----------------------------------------------------------------------
# 4) DICOM rescale identity (optional, only if pydicom installed)
# ----------------------------------------------------------------------

@pytest.mark.skipif(not HAVE_PYDICOM, reason="pydicom not installed")
def test_dicom_rescale_identity_roundtrip(tmp_path: Path):
    cfg = VolumeConfig(volume_shape=(8, 32, 32), hu_range=(-1024, 3071))
    gen = ChestCTVolumeGenerator(cfg, seed=1)
    vol = gen.generate()

    # Provide a superset of scanner-like attributes to satisfy different exporter conventions
    dicom_cfg = SimpleNamespace(
        modality="CT",
        manufacturer="SynthCT",
        manufacturer_model="X",
        station_name="lab",
        institution_name="Lab",
        software_versions="1.0",
        series_description="SYN",
        study_description="SYN",

        # acquisition/exposure fields (multiple aliases)
        kvp=120,
        exposure_mas=200,
        exposure_time=500,           # ms
        tube_current=200,            # mA (one naming convention)
        x_ray_tube_current=200,      # mA (alternate naming convention used by some exporters)
        convolution_kernel="STANDARD",
        reconstruction_diameter=350.0,
        patient_position="HFS",

        # rescale/pixels
        rescale_slope=1,
        rescale_intercept=0,
        photometric_interpretation="MONOCHROME2",
        pixel_representation=1,
        bits_allocated=16,
        bits_stored=16,
        high_bit=15,
    )

    out = tmp_path / "d"
    DICOMExporter(dicom_cfg, UIDGenerator(1)).export_volume(
        volume=vol,
        output_dir=out,
        patient_info={"patient_id": "P", "patient_name": "N", "birth_date": "19700101", "sex": "M"},
        study_info={
            "study_datetime": datetime(2025, 1, 1, 12, 0, 0),
            "accession_number": "A",
            "study_id": "1",
            "referring_physician": "R",
        },
        series_info={"series_number": 1, "series_datetime": datetime(2025, 1, 1, 12, 0, 0)},
        spacing=cfg.spacing,
    )

    # Read a slice and verify HU round-trip
    f = sorted(out.glob("*.dcm"))[0]
    d = pydicom.dcmread(str(f))
    px = d.pixel_array.astype(np.int16)
    slope = float(getattr(d, "RescaleSlope", 1.0))
    intercept = float(getattr(d, "RescaleIntercept", 0.0))
    hu = (px * slope + intercept).astype(np.int16)
    assert np.allclose(hu, vol[0], atol=0)
