"""
test_privacy_ct_generator.py

Quick sanity checks that your ChestCTVolumeGenerator respects the intended
privacy contracts:

- Augmentation mode (base_volume != None):
    * NOT privacy-safe.
    * Outside the lungs, the augmented volume should be identical
      to the original base_volume.

- Full synthesis mode (base_volume is None):
    * Privacy-preserving.
    * Output should be statistically unrelated to any given base_volume.

- Template-guided synthesis (generate_with_template):
    * Privacy-preserving (assuming k-anonymized template).
    * Output intensities must NOT simply copy the template intensities.
"""

from __future__ import annotations

from types import SimpleNamespace

import numpy as np

# ---------------------------------------------------------------------
# NumPy 2.0 compatibility shim
# Some older code calls `noise.ptp()` on ndarrays, but NumPy 2.0 removed
# ndarray.ptp in favor of `np.ptp(arr, ...)`. We reintroduce ndarray.ptp
# here so any such calls keep working without modifying the library.
# ---------------------------------------------------------------------
if not hasattr(np.ndarray, "ptp"):
    def _ndarray_ptp(self, *args, **kwargs):
        return np.ptp(self, *args, **kwargs)
    np.ndarray.ptp = _ndarray_ptp  # type: ignore[attr-defined]

# ✅ This is the only project-specific line you need:
from medsynth import ChestCTVolumeGenerator


# ---------------------------------------------------------------------
# 1. Build a test config (duck-typed, no need for real VolumeConfig)
# ---------------------------------------------------------------------

def create_test_config(shape=(32, 64, 64)):
    """
    Create a minimal config object with all attributes that
    ChestCTVolumeGenerator expects. We use SimpleNamespace so we don't
    depend on your actual VolumeConfig class.
    """
    features = SimpleNamespace(
        # Which features are turned on
        generate_nodules=True,
        generate_lesions=True,
        generate_ground_glass=True,
        generate_consolidation=True,

        # Morphology / complexity
        vessel_tree_complexity="medium",   # 'none' | 'low' | 'medium' | 'high'
        bronchial_tree_levels=3,

        emphysema_severity="moderate",     # 'none' | 'mild' | 'moderate' | 'severe'
        effusion_amount="small",           # 'none' | 'small' | 'moderate' | 'large'

        # Probabilities
        ground_glass_probability=0.8,
        consolidation_probability=0.6,

        # Vessel sizing (mm)
        vessel_radius_range=(0.6, 2.0),

        # Nodules
        num_nodules_range=(1, 3),
        nodule_size_range=(4.0, 10.0),
        nodule_types=["solid", "ground_glass", "part_solid"],

        # Lesions
        num_lesions_range=(1, 3),
        lesion_size_range=(8.0, 25.0),
    )

    config = SimpleNamespace(
        volume_shape=shape,           # (Z, Y, X)
        spacing=(1.0, 1.0, 1.0),      # (dz, dy, dx)

        air_hu=-1000.0,
        hu_range=(-1000.0, 3071.0),

        tissue_hu_mean=50.0,
        tissue_hu_std=20.0,

        lung_hu_mean=-800.0,
        lung_hu_std=80.0,

        bone_hu_mean=800.0,
        bone_hu_std=200.0,

        blood_hu_mean=40.0,

        noise_level=1.0,
        add_beam_hardening=True,
        add_motion_artifacts=True,

        features=features,
    )
    return config


# ---------------------------------------------------------------------
# 2. Construct a base volume with a unique “fingerprint”
# ---------------------------------------------------------------------

def make_base_volume(shape):
    """
    Build a deterministic "patient" volume with a strong, easily
    recognisable pattern so we can detect copying.

    Each voxel gets a unique integer pattern, but all values stay in a
    realistic HU range so they are not affected by the generator's final
    clipping step.

    Pattern construction:
        - Compute a unique linear index for each voxel
        - Wrap it modulo 2000 to keep dynamic range bounded
        - Shift into CT-like HU: roughly [-800, 1200]
    """
    z, y, x = shape
    zz, yy, xx = np.meshgrid(
        np.arange(z), np.arange(y), np.arange(x), indexing="ij"
    )

    # Unique linear index per voxel
    linear = zz * (y * x) + yy * x + xx

    # Wrap into [0, 1999]
    pattern = (linear % 2000).astype(np.int32)

    # Shift to HU range [-800, 1199]
    base = -800 + pattern
    return base


# ---------------------------------------------------------------------
# 3. Utility: compare a volume to the base
# ---------------------------------------------------------------------

def compare_to_base(base, vol, name: str):
    """
    Compute simple similarity metrics between base and vol:
    - fraction of voxels exactly equal
    - Pearson correlation

    This is not a formal privacy proof, but a sanity check:
    for privacy-preserving modes, these numbers should be tiny.
    """
    assert base.shape == vol.shape, f"Shape mismatch in {name}"

    base_f = base.astype(np.float32).ravel()
    vol_f = vol.astype(np.float32).ravel()

    frac_equal = float(np.mean(base_f == vol_f))

    # Handle potential degenerate case where variance is ~0
    if np.std(base_f) < 1e-6 or np.std(vol_f) < 1e-6:
        corr = 0.0
    else:
        corr = float(np.corrcoef(base_f, vol_f)[0, 1])

    print(f"[{name}]")
    print(f"  fraction equal to base: {frac_equal:.6f}")
    print(f"  Pearson correlation   : {corr:.4f}")
    print()
    return frac_equal, corr


# ---------------------------------------------------------------------
# 4. Helper functions for the three privacy modes
#    (NOT collected as separate pytest tests)
# ---------------------------------------------------------------------

def run_augmentation_mode(gen, base_volume, spacing):
    """
    Augmentation mode: base_volume is a real CT.

    Check:
    - outside lungs, augmented volume == base_volume (non-anonymizing)
    - so this mode is confirmed NOT privacy-safe.
    """
    print("=== Testing AUGMENTATION MODE (NOT privacy-safe) ===")

    aug = gen.generate(base_volume=base_volume, base_spacing=spacing)

    # Compute lung mask exactly as generator does.
    lung_mask = gen._robust_lung_mask(base_volume.astype(np.float32), spacing)

    # 1) Outside lungs should remain identical.
    outside_equal = float(
        np.mean(aug[~lung_mask] == base_volume[~lung_mask])
    )
    print(f"  Outside-lung equality fraction: {outside_equal:.6f}")

    # 2) Over the whole volume, a large fraction should still match.
    frac_equal, corr = compare_to_base(base_volume, aug, "Augmentation (whole volume)")

    # Simple sanity expectations:
    assert outside_equal > 0.99, (
        "Outside-lung region is not preserved; augmentation no longer "
        "matches the 'minimal change outside lungs' contract."
    )
    assert frac_equal > 0.3, (
        "Augmented volume is too different from base; either configuration "
        "is unusual, or augmentation is not behaving as expected."
    )

    print("  ✅ Augmentation behaves as a NON-privacy-safe mode (as intended).")
    print()


def run_full_synthesis_mode(gen, base_volume):
    """
    Full synthesis: base_volume is NOT used at all.

    Check:
    - synthetic volume is essentially independent of base_volume.
    """
    print("=== Testing FULL SYNTHESIS MODE (privacy-preserving) ===")

    syn = gen.generate(base_volume=None)

    frac_equal, corr = compare_to_base(base_volume, syn, "Full synthesis")

    # Expect almost no exact matches and low correlation.
    assert frac_equal < 0.01, (
        "Full synthetic volume is too close to base_volume; "
        "this should not depend on base_volume at all."
    )
    assert abs(corr) < 0.2, (
        "Unexpected high correlation between full synthetic volume and base_volume."
    )

    print("  ✅ Full synthesis appears privacy-preserving (no obvious copying).")
    print()


def run_template_guided_mode(gen, base_volume, spacing):
    """
    Template-guided synthesis: we (deliberately) misuse base_volume as the
    'template', to ensure that generate_with_template does NOT copy template
    intensities, only geometry.

    In a real pipeline, the template should be a k-anonymized average.
    """
    print("=== Testing TEMPLATE-GUIDED SYNTHESIS (privacy-preserving) ===")

    templ_syn = gen.generate_with_template(
        template_volume=base_volume,
        template_spacing=spacing,
        use_body_from_template=True,
    )

    frac_equal, corr = compare_to_base(base_volume, templ_syn, "Template-guided synthesis")

    # Again, we expect almost no equality, and low correlation.
    assert frac_equal < 0.01, (
        "Template-guided synthetic volume is too close to template intensities; "
        "it should resample intensities, not copy them."
    )
    # Allow moderate correlation due to shared geometry; we only want to
    # rule out very strong intensity copying.
    assert abs(corr) < 0.4, (
        "Unexpectedly strong correlation between template-guided synthesis "
        "and template volume; check that intensities are not being copied."
    )

    print("  ✅ Template-guided synthesis appears to use ONLY geometry from the template.")
    print()


# ---------------------------------------------------------------------
# 5. Pytest entry point wrapper (single test)
# ---------------------------------------------------------------------

def test_privacy_sanity_checks():
    """
    Single pytest entry point that runs all three privacy sanity checks.
    """
    config = create_test_config(shape=(32, 64, 64))
    gen = ChestCTVolumeGenerator(config, seed=42)

    base_volume = make_base_volume(config.volume_shape)
    spacing = config.spacing

    run_augmentation_mode(gen, base_volume, spacing)
    run_full_synthesis_mode(gen, base_volume)
    run_template_guided_mode(gen, base_volume, spacing)

    print("=======================================================")
    print("All privacy sanity checks PASSED.")
    print("Remember: augmentation mode is STILL not privacy-safe;")
    print("these tests only confirm that your synthesis modes do")
    print("not directly copy raw intensities from base/template.")
    print("=======================================================")


if __name__ == "__main__":
    # Optional: allow running as a standalone script
    config = create_test_config(shape=(32, 64, 64))
    gen = ChestCTVolumeGenerator(config, seed=42)

    base_volume = make_base_volume(config.volume_shape)
    spacing = config.spacing

    run_augmentation_mode(gen, base_volume, spacing)
    run_full_synthesis_mode(gen, base_volume)
    run_template_guided_mode(gen, base_volume, spacing)

    print("=======================================================")
    print("All privacy sanity checks PASSED.")
    print("Remember: augmentation mode is STILL not privacy-safe;")
    print("these tests only confirm that your synthesis modes do")
    print("not directly copy raw intensities from base/template.")
    print("=======================================================")
