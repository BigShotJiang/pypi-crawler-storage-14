# tests/test_omop_generator.py
import pytest
from pathlib import Path
import tempfile
import shutil
from datetime import datetime

from medsynth import OMOPCDMGenerator, OMOPConfig


class TestOMOPGenerator:
    """Test OMOP-CDM generation."""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory."""
        temp = tempfile.mkdtemp()
        yield Path(temp)
        shutil.rmtree(temp)
    
    def test_person_record(self):
        """Test person record generation."""
        config = OMOPConfig()
        generator = OMOPCDMGenerator(config)
        
        record = generator.generate_person_record(
            'PAT001',
            datetime(1980, 1, 1),
            'M'
        )
        
        # Person IDs are assigned starting from 1
        assert record['person_id'] == 1
        assert record['gender_concept_id'] == 8507
        assert record['year_of_birth'] == 1980
    
    def test_visit_record_requires_existing_person(self):
        """
        Visit occurrence should only be generated for a known person_id.
        This test both:
        - ensures privacy-aware behavior for unknown IDs (returns None)
        - checks normal behavior when the person exists.
        """
        config = OMOPConfig()
        generator = OMOPCDMGenerator(config)

        # 1) Unknown person_id -> should return None (privacy / referential integrity)
        unknown_visit = generator.generate_visit_occurrence_record(
            9999,
            datetime.now(),
            'outpatient'
        )
        assert unknown_visit is None

        # 2) Create a person first
        person = generator.generate_person_record(
            'PAT001',
            datetime(1980, 1, 1),
            'M'
        )
        person_id = person['person_id']

        # Now visit should be created correctly
        visit = generator.generate_visit_occurrence_record(
            person_id,
            datetime.now(),
            'outpatient'
        )

        assert visit is not None
        assert visit['person_id'] == person_id
        # 9202 = OMOP concept_id for "Outpatient Visit"
        assert visit['visit_concept_id'] == 9202
    
    def test_export_csv(self, temp_dir):
        """Test CSV export."""
        config = OMOPConfig()
        generator = OMOPCDMGenerator(config)
        
        person = generator.generate_person_record('PAT001', datetime(1980, 1, 1), 'M')
        
        files = generator.export_to_csv(
            {'PERSON': [person]},
            temp_dir
        )
        
        assert 'PERSON' in files
        assert Path(files['PERSON']).exists()
