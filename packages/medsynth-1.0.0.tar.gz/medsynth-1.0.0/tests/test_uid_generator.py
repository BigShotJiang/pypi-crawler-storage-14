# tests/test_uid_generator.py
import pytest
from datetime import datetime
from medsynth import UIDGenerator, AccessionNumberGenerator, PatientIDGenerator


class TestUIDGenerator:
    """Test UID generation."""
    
    def test_basic_uid(self):
        """Test basic UID generation."""
        gen = UIDGenerator()
        uid = gen.generate_uid()
        
        assert uid.startswith('2.25.')
        assert len(uid) <= 64
    
    def test_study_uid(self):
        """Test study UID generation."""
        gen = UIDGenerator(seed=42)
        uid = gen.generate_study_uid('PAT001', datetime.now())
        
        assert uid.startswith('2.25.')
    
    def test_reproducibility(self):
        """Test reproducible generation."""
        gen1 = UIDGenerator(seed=42)
        gen2 = UIDGenerator(seed=42)
        
        uid1 = gen1.generate_study_uid('PAT001', datetime(2025, 1, 1))
        uid2 = gen2.generate_study_uid('PAT001', datetime(2025, 1, 1))
        
        assert uid1 == uid2


class TestAccessionNumberGenerator:
    """Test accession number generation."""
    
    def test_generate(self):
        """Test generation."""
        gen = AccessionNumberGenerator(seed=42)
        acc = gen.generate('PAT001', datetime.now())
        
        assert acc.startswith('ACC')
        assert len(acc) > 10


class TestPatientIDGenerator:
    """Test patient ID generation."""
    
    def test_generate(self):
        """Test generation."""
        gen = PatientIDGenerator(seed=42)
        pid = gen.generate(0)
        
        assert pid.startswith('PAT')
        assert len(pid) > 5