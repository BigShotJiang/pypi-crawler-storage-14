# tests/test_nrrd_exporter.py
import pytest
from pathlib import Path
import tempfile
import shutil

pytest.importorskip("nrrd")

import nrrd
import numpy as np
from medsynth import NRRDExporter


class TestNRRDExporter:
    """Test NRRD export functionality."""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory."""
        temp = tempfile.mkdtemp()
        yield Path(temp)
        shutil.rmtree(temp)
    
    def test_nrrd_export(self, temp_dir):
        """Test basic NRRD export."""
        exporter = NRRDExporter()
        
        # Create test volume
        volume = np.random.randint(-1000, 1000, size=(8, 32, 32), dtype=np.int16)
        
        output_path = temp_dir / "test.nrrd"
        
        metadata = exporter.export_volume(
            volume,
            output_path,
            (1.5, 0.7, 0.7),
            {'patient_id': 'TEST001'}
        )
        
        assert output_path.exists()
        assert 'nrrd_file' in metadata
        
        # Read back
        data, header = nrrd.read(str(output_path))
        assert data.shape == volume.shape