import numpy as np
from medsynth import VolumeConfig, ChestCTVolumeGenerator

def test_nodules_schema_and_values():
    cfg = VolumeConfig(volume_shape=(32, 64, 64), spacing=(2.0, 0.8, 0.6))
    gen = ChestCTVolumeGenerator(cfg, seed=42)
    vol = gen.generate()
    ann = gen.get_annotations()

    assert isinstance(ann, dict)
    assert 'nodules' in ann
    assert isinstance(ann['nodules'], list)

    # At least 1 nodule typically with defaults; allow zero if lung mask empty
    if len(ann["nodules"]) > 0:
        n = ann["nodules"][0]
        for key in ["id", "center_voxel", "center_mm", "diameter_mm", "type", "base_hu"]:
            assert key in n

        cv = np.array(n["center_voxel"], dtype=float)   # [z, y, x] in voxels
        cm = np.array(n["center_mm"], dtype=float)      # [z, y, x] in mm
        spacing = np.array(cfg.spacing, dtype=float)    # (dz, dy, dx)

        # anisotropy-consistent mapping: center_mm ≈ center_voxel * spacing
        np.testing.assert_allclose(cm, cv * spacing, rtol=0, atol=1e-5)

        assert n["type"] in {"solid", "ground_glass", "part_solid"}
        assert isinstance(n["base_hu"], int)
        assert float(n["diameter_mm"]) > 0.0
