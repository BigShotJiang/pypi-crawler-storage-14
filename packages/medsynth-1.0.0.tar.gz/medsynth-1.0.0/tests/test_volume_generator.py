# tests/test_volume_generator.py
import pytest
import numpy as np
from medsynth import ChestCTVolumeGenerator, VolumeConfig
from medsynth.config import VolumeConfig, AnatomicalFeaturesConfig


class TestChestCTVolumeGenerator:
    """Test chest CT volume generation."""
    
    def test_generate_default_volume(self):
        """Test generating volume with default config."""
        config = VolumeConfig(volume_shape=(32, 64, 64))
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        assert volume.shape == (32, 64, 64)
        assert volume.dtype == np.int16
    
    def test_volume_hu_range(self):
        """Test that HU values are within specified range."""
        config = VolumeConfig(
            volume_shape=(16, 32, 32),
            hu_range=(-1024, 3071)
        )
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        assert np.min(volume) >= -1024
        assert np.max(volume) <= 3071
    
    def test_custom_volume_shape(self):
        """Test custom volume dimensions."""
        shapes = [
            (64, 128, 128),
            (128, 256, 256),
            (16, 64, 64),
            (178, 512, 512)  # Added the limit case you specified
        ]
        
        for shape in shapes:
            config = VolumeConfig(volume_shape=shape)
            generator = ChestCTVolumeGenerator(config, seed=42)
            volume = generator.generate()
            
            assert volume.shape == shape
    
    def test_reproducibility_with_seed(self):
        """Test that same seed produces identical volumes."""
        config = VolumeConfig(volume_shape=(16, 32, 32))
        
        gen1 = ChestCTVolumeGenerator(config, seed=123)
        vol1 = gen1.generate()
        
        gen2 = ChestCTVolumeGenerator(config, seed=123)
        vol2 = gen2.generate()
        
        assert np.array_equal(vol1, vol2)
    
    def test_different_seeds_different_volumes(self):
        """Test that different seeds produce different volumes."""
        config = VolumeConfig(volume_shape=(16, 32, 32))
        
        gen1 = ChestCTVolumeGenerator(config, seed=111)
        vol1 = gen1.generate()
        
        gen2 = ChestCTVolumeGenerator(config, seed=222)
        vol2 = gen2.generate()
        
        # Volumes should be different
        assert not np.array_equal(vol1, vol2)
    
    def test_volume_contains_realistic_hu_values(self):
        """Test that volume contains anatomically realistic HU values."""
        config = VolumeConfig(volume_shape=(32, 64, 64))
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        # Should contain air-like values (around -1000)
        assert np.any(volume < -900)
        
        # Should contain lung-like values (around -800)
        assert np.any((volume > -900) & (volume < -700))
        
        # Should contain tissue-like values (around 0-100)
        assert np.any((volume > -100) & (volume < 200))
        
        # Should contain bone-like values (> 400)
        assert np.any(volume > 400)
    
    def test_custom_anatomical_parameters(self):
        """Test custom HU parameters for anatomical structures."""
        config = VolumeConfig(
            volume_shape=(16, 32, 32),
            lung_hu_mean=-850,
            lung_hu_std=100,
            tissue_hu_mean=50,
            bone_hu_mean=800
        )
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        # Volume should be generated successfully
        assert volume is not None
        assert volume.shape == (16, 32, 32)
    
    def test_volume_data_type(self):
        """Test that volume has correct data type."""
        config = VolumeConfig(volume_shape=(16, 32, 32))
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        assert volume.dtype == np.int16
    
    def test_no_nan_or_inf_values(self):
        """Test that volume contains no NaN or Inf values."""
        config = VolumeConfig(volume_shape=(16, 32, 32))
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        assert not np.any(np.isnan(volume))
        assert not np.any(np.isinf(volume))
    
    def test_multiple_generations(self):
        """Test generating multiple volumes."""
        config = VolumeConfig(volume_shape=(8, 16, 16))
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volumes = [generator.generate() for _ in range(5)]
        
        # All should be generated successfully
        assert len(volumes) == 5
        
        # All should have correct shape
        for vol in volumes:
            assert vol.shape == (8, 16, 16)
    
    def test_full_size_volume(self):
        """Test generating full-size volume with correct shape."""
        config = VolumeConfig(volume_shape=(178, 512, 512))
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        
        # Should have correct shape (Z, Y, X)
        assert volume.shape == (178, 512, 512)
        assert volume.dtype == np.int16
        
        # Should contain realistic HU values
        assert np.min(volume) >= -1024
        assert np.max(volume) <= 3071
    
    def test_nodule_generation(self):
        """Test that nodules are generated when enabled."""
        config = VolumeConfig(
            volume_shape=(32, 64, 64),
            features=AnatomicalFeaturesConfig(
                generate_nodules=True,
                num_nodules_range=(1, 5)  # At least 1 nodule
            )
        )
        generator = ChestCTVolumeGenerator(config, seed=42)
        
        volume = generator.generate()
        annotations = generator.get_annotations()
        
        # Should have nodules in annotations
        assert 'nodules' in annotations
        assert len(annotations['nodules']) >= 1
        
        # Build nodule mask
        nodule_mask = generator.build_nodule_mask(
            vol_shape_zyx=volume.shape,
            spacing_zyx=config.spacing
        )
        
        # Nodule mask should have non-zero values
        assert np.any(nodule_mask > 0)


class TestVolumeConfig:
    """Test VolumeConfig class."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = VolumeConfig()
        
        assert config.volume_shape == (178, 512, 512)
        assert config.spacing == (1.5, 0.7, 0.7)
        assert config.hu_range == (-1024, 3071)
        assert config.lung_hu_mean == -800
        assert config.tissue_hu_mean == 40
        assert config.bone_hu_mean == 700
    
    def test_custom_config(self):
        """Test custom configuration."""
        config = VolumeConfig(
            volume_shape=(178, 512, 512),
            spacing=(2.0, 1.0, 1.0),
            lung_hu_mean=-850
        )
        
        assert config.volume_shape == (178, 512, 512)
        assert config.spacing == (2.0, 1.0, 1.0)
        assert config.lung_hu_mean == -850
    
    def test_anatomical_features_config(self):
        """Test anatomical features configuration."""
        config = VolumeConfig()
        
        # Check default features
        assert config.features.generate_nodules == True
        assert config.features.num_nodules_range == (1, 5)
        assert config.features.vessel_tree_complexity == 'high'


if __name__ == '__main__':
    # Need to import AnatomicalFeaturesConfig for the test
    from medsynth import AnatomicalFeaturesConfig
    pytest.main([__file__, '-v'])