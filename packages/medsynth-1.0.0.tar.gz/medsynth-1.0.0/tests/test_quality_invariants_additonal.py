import numpy as np
import pytest

from medsynth import VolumeConfig, ChestCTVolumeGenerator


# ---------------------------
# Helpers
# ---------------------------

def _lung_sigma(vol: np.ndarray) -> float:
    lung = vol[vol < -400]
    return float(lung.std()) if lung.size else 0.0


def _first_nodule(gen: ChestCTVolumeGenerator):
    ann = gen.get_annotations()
    nods = ann.get("nodules", [])
    assert len(nods) >= 1, "Expected at least one nodule for this test"
    return nods[0]


# ======================================================================
# 1) Config monotonicity (aggregate across seeds to reduce variance)
# ======================================================================

def test_monotonic_noise_level_controls_lung_sigma():
    """
    Increasing noise_level should increase the typical lung-region σ.
    We average over several seeds to be robust to anatomical randomness.
    """
    seeds = list(range(10, 15))  # 5 seeds
    cfg_lo = VolumeConfig(volume_shape=(24, 96, 96), noise_level=0.6)
    cfg_hi = VolumeConfig(volume_shape=(24, 96, 96), noise_level=1.4)

    sigmas_lo = []
    sigmas_hi = []
    for s in seeds:
        v_lo = ChestCTVolumeGenerator(cfg_lo, seed=s).generate()
        v_hi = ChestCTVolumeGenerator(cfg_hi, seed=s).generate()
        sigmas_lo.append(_lung_sigma(v_lo))
        sigmas_hi.append(_lung_sigma(v_hi))

    med_lo = float(np.median(sigmas_lo))
    med_hi = float(np.median(sigmas_hi))

    # Expect a positive trend (monotonic non-decreasing). Also require a tiny lift to
    # guard against pure equality but keep tolerance realistic for current noise model.
    slope = float(np.polyfit([0.6, 1.4], [med_lo, med_hi], 1)[0])
    assert slope > 0.0, f"Expected positive slope of σ vs noise_level, got {slope:.3f}"
    assert med_hi >= med_lo + 0.02, (
        f"noise_level should raise lung σ (got median {med_lo:.1f} → {med_hi:.1f})"
    )


def test_monotonic_nodule_size_range_increases_annotated_diameter():
    """
    Use the annotated diameter (which is exactly what the generator controls)
    rather than a noisy segmentation proxy.
    """
    cfg_small = VolumeConfig(volume_shape=(48, 128, 128), spacing=(1.5, 0.7, 0.7))
    f = cfg_small.features
    f.generate_nodules = True
    f.num_nodules_range = (1, 1)
    f.nodule_size_range = (6.0, 6.0)   # diameter will be ~12 mm

    cfg_large = VolumeConfig(volume_shape=(48, 128, 128), spacing=(1.5, 0.7, 0.7))
    g = cfg_large.features
    g.generate_nodules = True
    g.num_nodules_range = (1, 1)
    g.nodule_size_range = (14.0, 14.0) # diameter will be ~28 mm

    # Same seed so lung placement randomness cancels.
    gen_s = ChestCTVolumeGenerator(cfg_small, seed=7);  _ = gen_s.generate()
    nod_s = _first_nodule(gen_s)

    gen_l = ChestCTVolumeGenerator(cfg_large, seed=7);  _ = gen_l.generate()
    nod_l = _first_nodule(gen_l)

    d_small = float(nod_s["diameter_mm"])
    d_large = float(nod_l["diameter_mm"])

    # Keep a practical gap but not overly strict.
    assert d_large > d_small + 4.0, f"larger nodule size should yield larger diameter (got {d_small:.1f} → {d_large:.1f} mm)"


def test_vessel_tree_complexity_increases_vessel_mass():
    """
    Higher vessel complexity should increase the number of voxels
    in the soft-tissue vessel HU band ON AVERAGE across seeds.
    """
    def vessel_mass(v: np.ndarray) -> int:
        return int(((v > 30) & (v < 120)).sum())

    seeds = list(range(5, 10))  # 5 seeds

    masses_none, masses_low, masses_high = [], [], []

    for s in seeds:
        # none
        cfg_n = VolumeConfig(volume_shape=(24, 96, 96))
        cfg_n.features.vessel_tree_complexity = "none"
        cfg_n.features.bronchial_tree_levels = 0
        cfg_n.features.generate_nodules = False
        v_n = ChestCTVolumeGenerator(cfg_n, seed=s).generate()
        masses_none.append(vessel_mass(v_n))

        # low
        cfg_l = VolumeConfig(volume_shape=(24, 96, 96))
        cfg_l.features.vessel_tree_complexity = "low"
        cfg_l.features.bronchial_tree_levels = 0
        cfg_l.features.generate_nodules = False
        v_l = ChestCTVolumeGenerator(cfg_l, seed=s).generate()
        masses_low.append(vessel_mass(v_l))

        # high
        cfg_h = VolumeConfig(volume_shape=(24, 96, 96))
        cfg_h.features.vessel_tree_complexity = "high"
        cfg_h.features.bronchial_tree_levels = 0
        cfg_h.features.generate_nodules = False
        v_h = ChestCTVolumeGenerator(cfg_h, seed=s).generate()
        masses_high.append(vessel_mass(v_h))

    med_none = float(np.median(masses_none))
    med_low  = float(np.median(masses_low))
    med_high = float(np.median(masses_high))

    # Non-decreasing with complexity (allow equality if growth is subtle).
    assert med_low  >= med_none, f"low should be ≥ none (med {med_none:.0f} → {med_low:.0f})"
    assert med_high >= med_low,  f"high should be ≥ low (med {med_low:.0f} → {med_high:.0f})"

    # Require a modest margin vs 'none', tuned to current vessel synthesis.
    assert med_high >= med_none + 100, (
        f"high should exceed none by a margin (med {med_none:.0f} → {med_high:.0f})"
    )


# ======================================================================
# 2) Shape fidelity in mm-space (allow realistic tolerance)
# ======================================================================

def test_nodule_spherical_in_mm_space_with_anisotropy():
    """
    Nodules should be roughly spherical in mm space even with anisotropy.
    We allow some elongation due to partial volume and soft edges.
    """
    cfg = VolumeConfig(volume_shape=(48, 128, 128), spacing=(2.5, 0.7, 0.7))
    f = cfg.features
    f.generate_nodules = True
    f.num_nodules_range = (1, 1)
    f.nodule_size_range = (10.0, 10.0)
    f.vessel_tree_complexity = "none"
    f.bronchial_tree_levels = 0

    gen = ChestCTVolumeGenerator(cfg, seed=13)
    vol = gen.generate()
    nod = _first_nodule(gen)

    cz, cy, cx = map(int, nod["center_voxel"])
    base_hu = int(nod["base_hu"])
    dz, dy, dx = cfg.spacing

    # local 3D patch around the nodule
    z0, z1 = max(0, cz - 6), min(vol.shape[0], cz + 7)
    y0, y1 = max(0, cy - 14), min(vol.shape[1], cy + 15)
    x0, x1 = max(0, cx - 14), min(vol.shape[2], cx + 15)
    patch = vol[z0:z1, y0:y1, x0:x1]

    # threshold relative to base HU to isolate the nodule (partial-volume tolerant)
    m = patch > (base_hu - 160)

    rz = (m.any(axis=(1, 2)).sum() / 2.0) * dz
    ry = (m.any(axis=(0, 2)).sum() / 2.0) * dy
    rx = (m.any(axis=(0, 1)).sum() / 2.0) * dx

    # Spherical-ish in mm-space ⇒ ratios not too extreme.
    ratios = np.array([rz, ry, rx]) / max(1e-6, min(rz, ry, rx))
    assert ratios.max() < 2.1, f"anisotropy not respected in mm-space (radii mm = {rz:.1f},{ry:.1f},{rx:.1f})"


# ======================================================================
# 3) Augmentation metamorphic sanity
# ======================================================================

def test_augmentation_increases_local_intensity_at_nodule_centers():
    """
    When augmenting with nodules, mean HU in a small neighborhood
    around annotated centers should rise relative to the base.
    """
    base_cfg = VolumeConfig(volume_shape=(24, 96, 96))
    base_cfg.features.generate_nodules = False
    base_cfg.features.vessel_tree_complexity = "none"
    base_cfg.features.bronchial_tree_levels = 0

    base = ChestCTVolumeGenerator(base_cfg, seed=21).generate()

    aug_cfg = VolumeConfig(volume_shape=base.shape, spacing=base_cfg.spacing)
    fa = aug_cfg.features
    fa.generate_nodules = True
    fa.num_nodules_range = (2, 2)
    fa.vessel_tree_complexity = "none"
    fa.bronchial_tree_levels = 0

    aug_gen = ChestCTVolumeGenerator(aug_cfg, seed=22)
    augmented = aug_gen.generate(base_volume=base, base_spacing=base_cfg.spacing)
    anns = aug_gen.get_annotations()
    assert "nodules" in anns and len(anns["nodules"]) == 2

    def local_mean(vol, c):
        z, y, x = map(int, c)
        z0, z1 = max(0, z - 1), min(vol.shape[0], z + 2)
        y0, y1 = max(0, y - 2), min(vol.shape[1], y + 3)
        x0, x1 = max(0, x - 2), min(vol.shape[2], x + 3)
        return float(vol[z0:z1, y0:y1, x0:x1].mean())

    deltas = []
    for n in anns["nodules"]:
        c = n["center_voxel"]
        deltas.append(local_mean(augmented, c) - local_mean(base, c))

    assert np.mean(deltas) > 40.0, f"augmentation should raise local HU near nodules (Δ={np.mean(deltas):.1f})"
