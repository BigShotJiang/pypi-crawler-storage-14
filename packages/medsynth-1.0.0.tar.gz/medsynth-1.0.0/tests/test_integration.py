"""
Integration tests for the complete synthetic CT generation pipeline.
"""
import pytest
import numpy as np
from pathlib import Path
import tempfile
import shutil
import json

from medsynth import (
    Config,
    VolumeConfig,
    AnatomicalFeaturesConfig,
    SyntheticCTPipeline,
    ChestCTVolumeGenerator,
)


class TestGoldStandardFeatures:
    """Test gold-standard quality features."""

    def test_reproducibility(self):
        """Test that same seed produces identical results."""
        config = VolumeConfig(
            volume_shape=(32, 64, 64),
            features=AnatomicalFeaturesConfig(
                generate_nodules=True,
                num_nodules_range=(2, 2)
            )
        )

        gen1 = ChestCTVolumeGenerator(config, seed=42)
        vol1 = gen1.generate()
        ann1 = gen1.get_annotations()

        gen2 = ChestCTVolumeGenerator(config, seed=42)
        vol2 = gen2.generate()
        ann2 = gen2.get_annotations()

        assert np.array_equal(vol1, vol2), "Volumes should be identical"
        assert ann1 == ann2, "Annotations should be identical"

    def test_nodule_annotations(self):
        """Test that nodule annotations are accurate."""
        config = VolumeConfig(
            volume_shape=(64, 128, 128),
            spacing=(1.0, 1.0, 1.0),
            features=AnatomicalFeaturesConfig(
                generate_nodules=True,
                num_nodules_range=(3, 3),
                nodule_size_range=(10.0, 10.0)  # Fixed size
            )
        )

        generator = ChestCTVolumeGenerator(config, seed=999)
        _ = generator.generate()
        annotations = generator.get_annotations()

        assert 'nodules' in annotations
        assert len(annotations['nodules']) == 3

        # Check each nodule
        for nodule in annotations['nodules']:
            assert 'center_voxel' in nodule
            assert 'center_mm' in nodule
            assert 'diameter_mm' in nodule
            assert 'type' in nodule

            # Verify mm coordinates match voxel coordinates
            center_vox = np.array(nodule['center_voxel'])
            center_mm_calc = center_vox * np.array(config.spacing)
            center_mm_ann = np.array(nodule['center_mm'])

            assert np.allclose(center_mm_calc, center_mm_ann, atol=0.1)

    def test_anisotropic_spacing(self):
        """Test that anisotropic spacing is handled correctly."""
        config = VolumeConfig(
            volume_shape=(64, 256, 256),
            spacing=(2.5, 0.7, 0.7),  # Thick slices
            features=AnatomicalFeaturesConfig(
                generate_nodules=True,
                num_nodules_range=(1, 1),
                nodule_size_range=(8.0, 8.0)
            )
        )

        generator = ChestCTVolumeGenerator(config, seed=123)
        volume = generator.generate()
        annotations = generator.get_annotations()

        # Nodule should be spherical in mm space, not voxel space
        nodule = annotations['nodules'][0]
        assert volume.shape[0] == 64
        assert config.spacing[0] == 2.5

    def test_hu_value_ranges(self):
        """Test that HU values are realistic."""
        config = VolumeConfig(
            volume_shape=(32, 64, 64),
            features=AnatomicalFeaturesConfig(
                generate_nodules=False,
                vessel_tree_complexity='none',
                bronchial_tree_levels=0
            )
        )

        generator = ChestCTVolumeGenerator(config, seed=42)
        volume = generator.generate()

        # Check HU ranges
        assert volume.min() >= -1024, "HU below valid range"
        assert volume.max() <= 3071, "HU above valid range"

        # Should contain lung (< -400), tissue (~40), bone (> 200)
        assert np.any(volume < -400), "Should have lung-density voxels"
        assert np.any((volume > -100) & (volume < 200)), "Should have tissue-density voxels"
        assert np.any(volume > 200), "Should have bone-density voxels"

    def test_vessel_tree_complexity(self):
        """Test vessel tree generation at different complexity levels."""
        for complexity in ['low', 'medium', 'high']:
            config = VolumeConfig(
                volume_shape=(32, 64, 64),
                features=AnatomicalFeaturesConfig(
                    generate_nodules=False,
                    vessel_tree_complexity=complexity,
                    bronchial_tree_levels=0
                )
            )

            generator = ChestCTVolumeGenerator(config, seed=42)
            volume = generator.generate()

            # Vessels should be blood density (~50 HU)
            vessel_voxels = ((volume > 30) & (volume < 100)).sum()
            assert vessel_voxels > 0, f"Should have vessels at {complexity} complexity"


class TestRealCTAugmentation:
    """Test real CT augmentation capabilities."""

    def test_augment_synthetic_base(self):
        """Test augmenting a synthetic CT (as proxy for real)."""
        # Create a "base" CT
        base_config = VolumeConfig(
            volume_shape=(32, 64, 64),
            spacing=(1.5, 0.7, 0.7),
            features=AnatomicalFeaturesConfig(
                generate_nodules=False,
                vessel_tree_complexity='high',
                bronchial_tree_levels=3
            )
        )

        base_gen = ChestCTVolumeGenerator(base_config, seed=100)
        base_volume = base_gen.generate()

        # Now augment it with nodules
        aug_config = VolumeConfig(
            volume_shape=base_volume.shape,
            spacing=(1.5, 0.7, 0.7),
            features=AnatomicalFeaturesConfig(
                generate_nodules=True,
                num_nodules_range=(3, 3),
                vessel_tree_complexity='none',  # Don't regenerate
                bronchial_tree_levels=0  # Don't regenerate
            )
        )

        aug_gen = ChestCTVolumeGenerator(aug_config, seed=200)
        augmented = aug_gen.generate(
            base_volume=base_volume,
            base_spacing=(1.5, 0.7, 0.7)
        )
        annotations = aug_gen.get_annotations()

        # Check that nodules were added
        assert len(annotations['nodules']) == 3

        # Volumes should be different (nodules added)
        assert not np.array_equal(base_volume, augmented)

        # But should be similar in most places
        diff = np.abs(augmented.astype(np.float32) - base_volume.astype(np.float32))
        similar_fraction = (diff < 50).sum() / diff.size
        assert similar_fraction > 0.95, "Most of volume should be preserved"


class TestPipelineIntegration:
    """Test complete pipeline."""

    @pytest.fixture
    def temp_output(self):
        temp_dir = tempfile.mkdtemp()
        yield Path(temp_dir)
        shutil.rmtree(temp_dir)

    def test_full_pipeline_with_annotations(self, temp_output):
        """Test complete pipeline with annotation export."""
        config = Config()
        config.num_subjects = 2
        config.random_seed = 999
        config.output.output_root = temp_output

        # Use VolumeConfig object to match generator expectations
        config.volume = VolumeConfig(volume_shape=(32, 64, 64))
        config.volume.features.generate_nodules = True
        config.volume.features.num_nodules_range = (2, 2)

        config.output.save_annotations = True

        pipeline = SyntheticCTPipeline(config)
        results = pipeline.generate_dataset()

        # Check outputs exist
        assert len(results['subjects']) == 2

        # Check annotations were saved
        for subject in results['subjects']:
            study_dir = Path(subject['metadata']['output_directory'])
            ann_file = study_dir / "annotations" / "annotations.json"

            assert ann_file.exists(), f"Annotations not found: {ann_file}"

            with open(ann_file) as f:
                anns = json.load(f)

            # JSON file schema has 'annotations' wrapper
            assert 'annotations' in anns
            assert 'nodules' in anns['annotations']
            assert len(anns['annotations']['nodules']) == 2


class TestQualityMetrics:
    """Test quality and realism metrics."""

    def test_noise_characteristics(self):
        """Test that noise has proper characteristics."""
        config = VolumeConfig(
            volume_shape=(32, 64, 64),
            noise_level=1.0,
            features=AnatomicalFeaturesConfig(
                generate_nodules=False,
                vessel_tree_complexity='none'
            )
        )

        # Generate two volumes with same config but different seeds
        gen1 = ChestCTVolumeGenerator(config, seed=1)
        vol1 = gen1.generate()

        gen2 = ChestCTVolumeGenerator(config, seed=2)
        vol2 = gen2.generate()

        # Extract lung regions (approximately)
        lung1 = vol1[vol1 < -400]
        lung2 = vol2[vol2 < -400]

        # Noise should have similar std between runs
        std1 = lung1.std()
        std2 = lung2.std()

        assert 40 < std1 < 150, f"Noise std seems unrealistic: {std1}"
        assert abs(std1 - std2) < 20, "Noise characteristics should be consistent"

    def test_partial_volume_effects(self):
        """Test that boundaries are smooth (partial volume)."""
        config = VolumeConfig(
            volume_shape=(64, 128, 128),
            spacing=(1.0, 1.0, 1.0),
            features=AnatomicalFeaturesConfig(
                generate_nodules=True,
                num_nodules_range=(1, 1),
                nodule_size_range=(15.0, 15.0),
                vessel_tree_complexity='none'
            )
        )

        generator = ChestCTVolumeGenerator(config, seed=888)
        volume = generator.generate()

        # Compute gradient magnitude
        grad_z = np.abs(np.diff(volume, axis=0))
        grad_y = np.abs(np.diff(volume, axis=1))
        grad_x = np.abs(np.diff(volume, axis=2))

        smooth_fraction = (grad_z < 50).sum() / grad_z.size
        assert smooth_fraction > 0.90, "Volume should have smooth boundaries"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
