# tests/test_dicom_exporter.py
import pytest
from pathlib import Path
import tempfile
import shutil

# Only run if pydicom is available
pytest.importorskip("pydicom")

import pydicom
from medsynth import DICOMExporter, DICOMConfig, UIDGenerator, VolumeConfig, ChestCTVolumeGenerator
from datetime import datetime


class TestDICOMExporter:
    """Test DICOM export functionality."""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory."""
        temp = tempfile.mkdtemp()
        yield Path(temp)
        shutil.rmtree(temp)
    
    def test_dicom_export(self, temp_dir):
        """Test basic DICOM export."""
        # Generate small test volume
        vol_config = VolumeConfig(volume_shape=(8, 32, 32))
        generator = ChestCTVolumeGenerator(vol_config, seed=42)
        volume = generator.generate()
        
        # Setup exporter
        uid_gen = UIDGenerator(seed=42)
        dicom_config = DICOMConfig()
        exporter = DICOMExporter(dicom_config, uid_gen)
        
        # Patient info
        patient_info = {
            'patient_id': 'TEST001',
            'patient_name': 'TEST^PATIENT',
            'birth_date': '19800101',
            'sex': 'M'
        }
        
        # Study info
        study_info = {
            'study_datetime': datetime.now(),
            'accession_number': 'ACC001',
            'study_id': '1'
        }
        
        # Series info
        series_info = {
            'series_number': 1
        }
        
        # Export
        metadata = exporter.export_volume(
            volume,
            temp_dir,
            patient_info,
            study_info,
            series_info,
            (1.5, 0.7, 0.7)
        )
        
        # Verify
        assert 'study_instance_uid' in metadata
        assert 'series_instance_uid' in metadata
        assert len(metadata['dicom_files']) == 8
        
        # Read first DICOM file
        ds = pydicom.dcmread(metadata['dicom_files'][0])
        assert ds.PatientID == 'TEST001'
        assert ds.Modality == 'CT'