import numpy as np
from medsynth import VolumeConfig, ChestCTVolumeGenerator

def test_augmentation_locality_outside_lung():
    cfg = VolumeConfig(volume_shape=(24,64,64))
    base_gen = ChestCTVolumeGenerator(cfg, seed=10)
    base = base_gen.generate()
    lung_mask = base_gen._quick_lung_mask(base.astype(np.float32))

    aug = ChestCTVolumeGenerator(cfg, seed=10).generate(base_volume=base, base_spacing=cfg.spacing)

    outside = ~lung_mask
    diff = (aug.astype(np.int32) - base.astype(np.int32))
    # allow tiny numerical “nudge” tolerance outside lungs
    # 99.5% of outside-lung voxels unchanged
    unchanged_frac = float((diff[outside] == 0).sum()) / (outside.sum() or 1)
    assert unchanged_frac > 0.995
