import numpy as np
from medsynth import VolumeConfig, ChestCTVolumeGenerator

def test_noise_variation_inside_body():
    cfg = VolumeConfig(volume_shape=(32,64,64))
    g = ChestCTVolumeGenerator(cfg, seed=33)
    v = g.generate().astype(np.float32)

    body = v > (cfg.air_hu + 50)
    # Take two random slices; inside-body std should be > zero and plausible
    s1 = v[body].std()
    assert s1 > 3.0  # non-zero, avoids degenerate flat fields

def test_partial_volume_edges_present():
    cfg = VolumeConfig(volume_shape=(24,64,64))
    g = ChestCTVolumeGenerator(cfg, seed=101)
    v = g.generate().astype(np.float32)

    # Look for intermediate HU histogram between air and tissue (edge voxels)
    hist, bins = np.histogram(v, bins=128, range=(cfg.hu_range[0], cfg.hu_range[1]))
    # Expect some counts near -600..-200 (edges/partial-volume)
    pv_band = (bins[:-1] > -700) & (bins[:-1] < -150)
    assert hist[pv_band].sum() > 50
