from datetime import datetime
from pathlib import Path
import pytest

try:
    import pydicom
except Exception:
    pydicom = None

from medsynth import VolumeConfig, ChestCTVolumeGenerator
from medsynth.dicom_exporter import DICOMExporter
from medsynth.uid_generator import UIDGenerator

pytestmark = pytest.mark.skipif(pydicom is None, reason="pydicom not installed")


class DicomCfg:
    """
    Minimal, robust DICOM exporter config with realistic defaults.
    Provides __getattr__ fallback so unknown attributes won't crash.
    """
    _defaults = {
        # Core identification
        "modality": "CT",
        "manufacturer": "SynthCT",
        "manufacturer_model": "Synth-Phantom X",
        "station_name": "lab",
        "institution_name": "Synthetic Imaging Lab",
        "software_versions": "1.0.0",

        # Descriptions
        "series_description": "SYNTH-CT",
        "study_description": "SYNTH-CT STUDY",

        # Acquisition / reconstruction defaults (typical values)
        "kvp": 120,                      # Peak kV
        "exposure_mas": 200,             # mAs
        "convolution_kernel": "STANDARD",
        "reconstruction_diameter": 350.0,  # mm
        "patient_position": "HFS",       # Head First Supine

        # Rescale / photometric defaults
        "rescale_intercept": 0,
        "rescale_slope": 1,
        "photometric_interpretation": "MONOCHROME2",
        "pixel_representation": 1,       # signed
        "bits_allocated": 16,
        "bits_stored": 16,
        "high_bit": 15,

        # Optional flags
        "body_part_examined": "CHEST",
        "image_type": ["ORIGINAL", "PRIMARY", "AXIAL"],
        "manufacturer_model_name": "Synth-Phantom X",
    }

    def __init__(self, **overrides):
        self._vals = dict(self._defaults)
        self._vals.update(overrides)

    def __getattr__(self, name):
        # Return None for truly unknowns to avoid AttributeError explosions
        return self._vals.get(name, None)


def test_dicom_series_uids_consistent(tmp_path: Path):
    cfg = VolumeConfig(volume_shape=(8, 32, 32))
    gen = ChestCTVolumeGenerator(cfg, seed=101)
    vol = gen.generate()

    uid = UIDGenerator(seed=101)
    dicom_cfg = DicomCfg()  # use robust config wrapper
    exporter = DICOMExporter(dicom_cfg, uid)

    outdir = tmp_path / "dicom"
    study_dt = datetime(2025, 2, 4, 12, 0, 0)

    _ = exporter.export_volume(
        volume=vol,
        output_dir=outdir,
        patient_info={
            "patient_id": "PAT001",
            "patient_name": "SYNTH^PATIENT",
            "birth_date": "19700101",
            "sex": "M",
        },
        study_info={
            "study_datetime": study_dt,  # datetime, not string
            "accession_number": "ACC1",
            "study_id": "1",
            "referring_physician": "DOC^ONE",
        },
        series_info={
            "series_number": 1,
            "series_datetime": study_dt,  # datetime, not string
        },
        spacing=cfg.spacing,
    )

    files = sorted(str(p) for p in outdir.glob("*.dcm"))
    assert len(files) == vol.shape[0]  # one file per slice

    study_uids, series_uids, sop_uids, patient_ids = set(), set(), set(), set()
    for f in files:
        d = pydicom.dcmread(f)
        patient_ids.add(d.PatientID)
        study_uids.add(d.StudyInstanceUID)
        series_uids.add(d.SeriesInstanceUID)
        sop_uids.add(d.SOPInstanceUID)

        # basic tag presence / non-null
        assert d.SeriesDescription
        assert d.Manufacturer
        assert d.StudyDate and d.StudyTime

        # Spacing retained
        assert float(d.PixelSpacing[0]) == pytest.approx(cfg.spacing[1])
        assert float(d.PixelSpacing[1]) == pytest.approx(cfg.spacing[2])
        assert float(d.SliceThickness) == pytest.approx(cfg.spacing[0])

    # consistency
    assert len(patient_ids) == 1
    assert len(study_uids) == 1
    assert len(series_uids) == 1
    assert len(sop_uids) == vol.shape[0]  # each slice unique
