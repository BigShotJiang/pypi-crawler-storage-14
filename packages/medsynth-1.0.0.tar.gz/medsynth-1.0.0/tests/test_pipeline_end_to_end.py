from datetime import datetime, timedelta
from pathlib import Path
import json
import numpy as np

from medsynth import Config, VolumeConfig
from medsynth.pipeline import SyntheticCTPipeline


def test_pipeline_generates_metadata_and_annotations(tmp_path: Path):
    out_root = tmp_path / "out"

    # Pass VolumeConfig for volume to align with current generator expectations
    cfg = Config(
        num_subjects=1,
        random_seed=1234,
        volume=VolumeConfig(volume_shape=(16, 32, 32), spacing=(1.5, 0.7, 0.7)),
        output=dict(
            output_root=out_root,
            generate_dicom=False,
            generate_nrrd=False,
            generate_omop=False,
            save_annotations=True,
        ),
    )

    pipe = SyntheticCTPipeline(cfg)
    meta = pipe.generate_dataset()

    # top-level metadata.json exists
    metadata_subdir = getattr(cfg.output, "metadata_subdir", None)
    if metadata_subdir is None:
        # If output is a dict-like configuration
        try:
            metadata_subdir = cfg.output.get("metadata_subdir", "metadata")
        except AttributeError:
            metadata_subdir = "metadata"

    meta_file = out_root / metadata_subdir / "generation_metadata.json"
    assert meta_file.exists()
    top = json.loads(meta_file.read_text())
    assert "subjects" in top and len(top["subjects"]) == 1

    # per-subject annotations file exists and contains nodules key
    subj_dir = Path(top["subjects"][0]["metadata"]["output_directory"])
    ann_file = subj_dir / "annotations" / "annotations.json"
    assert ann_file.exists()
    ann = json.loads(ann_file.read_text())
    assert "annotations" in ann
    assert "nodules" in ann["annotations"]

    # study_date in last 0..365 days (date shifted realistically)
    sd = datetime.strptime(ann["study_date"], "%Y%m%d").date()
    delta = datetime.now().date() - sd
    assert timedelta(days=0) <= delta <= timedelta(days=365)
