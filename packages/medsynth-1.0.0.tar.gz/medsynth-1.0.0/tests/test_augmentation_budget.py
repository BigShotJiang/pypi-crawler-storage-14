import numpy as np
import pytest

from medsynth import VolumeConfig, ChestCTVolumeGenerator


def frac_changed(a: np.ndarray, b: np.ndarray, thresh: int = 0) -> float:
    diff = (a.astype(np.int32) - b.astype(np.int32))
    if thresh <= 0:
        return float((diff != 0).sum()) / diff.size
    return float((np.abs(diff) >= thresh).sum()) / diff.size


def _compat_thresholds():
    """
    Back-compat helper: some versions expose class attributes,
    others may use a mapping or a different name.
    """
    strong = getattr(ChestCTVolumeGenerator, "STRONG_DELTA_THRESHOLD", None)
    if strong is None:
        # Try a mapping if present; otherwise fall back to a sane default
        strong = getattr(ChestCTVolumeGenerator, "DELTA_THRESHOLDS", {}).get("strong", 80)

    max_any = getattr(ChestCTVolumeGenerator, "MAX_ANY_CHANGED_FRAC", 0.12)
    max_strong = getattr(ChestCTVolumeGenerator, "MAX_STRONG_CHANGED_FRAC", 0.02)
    return int(strong), float(max_any), float(max_strong)


@pytest.mark.parametrize("shape,spacing", [((32, 64, 64), (1.5, 0.7, 0.7))])
def test_augment_preserves_most_of_base(shape, spacing):
    cfg = VolumeConfig(volume_shape=shape, spacing=spacing)
    gen = ChestCTVolumeGenerator(cfg, seed=123)
    base = gen.generate()  # synthetic base

    # Augment the base (simulate “real” CT augmentation)
    gen_aug = ChestCTVolumeGenerator(cfg, seed=123)  # same seed -> deterministic proposals
    aug = gen_aug.generate(base_volume=base, base_spacing=spacing)

    strong_thr, max_any_frac, max_strong_frac = _compat_thresholds()

    any_frac = frac_changed(aug, base, thresh=0)
    strong_frac = frac_changed(aug, base, thresh=strong_thr)

    # Dual budget guarantees (tune only if you change class constants)
    assert any_frac <= max_any_frac + 1e-6
    assert strong_frac <= max_strong_frac + 1e-6


def test_augment_is_non_noop_but_small():
    cfg = VolumeConfig(volume_shape=(16, 32, 32))
    gen = ChestCTVolumeGenerator(cfg, seed=777)
    base = gen.generate()
    aug = ChestCTVolumeGenerator(cfg, seed=777).generate(base_volume=base, base_spacing=cfg.spacing)

    # deterministic “nudge” safeguard: augmentation must not be a perfect no-op
    assert not np.array_equal(base, aug)
