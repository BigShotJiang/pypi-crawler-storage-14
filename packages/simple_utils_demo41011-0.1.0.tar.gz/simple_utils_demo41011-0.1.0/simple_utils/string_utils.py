"""字符串工具类 (StringUtils)"""

class StringUtils:
    """提供常用的字符串处理工具方法"""
    
    @staticmethod
    def is_empty(text: str) -> bool:
        """检查字符串是否为空（None、空字符串或只包含空白字符）"""
        return text is None or not text.strip()
    
    @staticmethod
    def to_camel_case(text: str) -> str:
        """将下划线分隔的字符串转换为驼峰命名法"""
        if StringUtils.is_empty(text):
            return text
        
        parts = text.split('_')
        return parts[0].lower() + ''.join(part.capitalize() for part in parts[1:])
    
    @staticmethod
    def to_snake_case(text: str) -> str:
        """将驼峰命名的字符串转换为下划线分隔的格式"""
        if StringUtils.is_empty(text):
            return text
        
        result = []
        for i, char in enumerate(text):
            if i > 0 and char.isupper():
                result.append('_')
            result.append(char.lower())
        return ''.join(result)
    
    @staticmethod
    def truncate(text: str, max_length: int, suffix: str = '...') -> str:
        """截断字符串到指定长度，如果超长则添加后缀"""
        if StringUtils.is_empty(text) or len(text) <= max_length:
            return text
        
        return text[:max_length - len(suffix)] + suffix
    
    @staticmethod
    def repeat(text: str, times: int) -> str:
        """重复字符串指定次数"""
        if text is None:
            return ''
        return text * times
    
    @staticmethod
    def count_occurrences(text: str, substring: str) -> int:
        """计算子字符串在文本中出现的次数"""
        if StringUtils.is_empty(text) or StringUtils.is_empty(substring):
            return 0
        return text.count(substring)