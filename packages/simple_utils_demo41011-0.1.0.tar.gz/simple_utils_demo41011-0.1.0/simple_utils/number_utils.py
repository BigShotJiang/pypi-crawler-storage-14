"""数字工具类 (NumberUtils)"""

class NumberUtils:
    """提供常用的数字处理工具方法"""
    
    @staticmethod
    def is_even(number: int) -> bool:
        """检查一个数是否为偶数"""
        return number % 2 == 0
    
    @staticmethod
    def is_odd(number: int) -> bool:
        """检查一个数是否为奇数"""
        return number % 2 != 0
    
    @staticmethod
    def is_prime(number: int) -> bool:
        """检查一个数是否为质数"""
        if number <= 1:
            return False
        if number <= 3:
            return True
        if number % 2 == 0 or number % 3 == 0:
            return False
        i = 5
        while i * i <= number:
            if number % i == 0 or number % (i + 2) == 0:
                return False
            i += 6
        return True
    
    @staticmethod
    def to_rounded(number: float, decimals: int = 0) -> float:
        """将数字四舍五入到指定小数位"""
        return round(number, decimals)
    
    @staticmethod
    def clamp(value: float, min_value: float, max_value: float) -> float:
        """将值限制在指定的范围内"""
        return max(min_value, min(max_value, value))
    
    @staticmethod
    def average(numbers: list) -> float:
        """计算列表中数字的平均值"""
        if not numbers:
            raise ValueError("Cannot calculate average of an empty list")
        return sum(numbers) / len(numbers)
    
    @staticmethod
    def sum_digits(number: int) -> int:
        """计算一个整数各位数字之和"""
        return sum(int(digit) for digit in str(abs(number)))
    
    @staticmethod
    def format_number(number: float, decimal_places: int = 2) -> str:
        """格式化数字为字符串，保留指定的小数位"""
        format_string = f"%.{decimal_places}f"
        return format_string % number