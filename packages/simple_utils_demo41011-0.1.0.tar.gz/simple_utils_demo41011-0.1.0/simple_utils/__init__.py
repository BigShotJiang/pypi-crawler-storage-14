"""简单实用工具库 (simple_utils)"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .string_utils import StringUtils
from .number_utils import NumberUtils

__all__ = ['StringUtils', 'NumberUtils']