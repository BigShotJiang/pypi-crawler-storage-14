# simple_utils_demo41011

一个简单实用的Python工具库，提供常用的字符串和数字处理功能。

## 功能特性

### StringUtils
- 字符串空值检查
- 驼峰命名法转换
- 下划线命名法转换
- 字符串截断
- 字符串重复
- 子字符串计数

### NumberUtils
- 奇偶性检查
- 质数判断
- 数值四舍五入
- 数值范围限制
- 计算平均值
- 数字各位求和
- 数字格式化

## 安装

使用pip安装：

```bash
pip install simple_utils_demo41011
```

## 使用示例

### StringUtils

```python
from simple_utils import StringUtils

# 检查字符串是否为空
print(StringUtils.is_empty(""))  # True
print(StringUtils.is_empty("  "))  # True
print(StringUtils.is_empty("hello"))  # False

# 驼峰命名转换
print(StringUtils.to_camel_case("hello_world"))  # helloWorld

# 下划线命名转换
print(StringUtils.to_snake_case("HelloWorld"))  # hello_world

# 字符串截断
print(StringUtils.truncate("This is a long text", 10))  # This is ...
```

### NumberUtils

```python
from simple_utils import NumberUtils

# 检查奇偶性
print(NumberUtils.is_even(4))  # True
print(NumberUtils.is_odd(5))  # True

# 检查质数
print(NumberUtils.is_prime(7))  # True

# 数值四舍五入
print(NumberUtils.to_rounded(3.14159, 2))  # 3.14

# 数值范围限制
print(NumberUtils.clamp(15, 0, 10))  # 10

# 计算平均值
print(NumberUtils.average([1, 2, 3, 4, 5]))  # 3.0
```

## 许可证

MIT License