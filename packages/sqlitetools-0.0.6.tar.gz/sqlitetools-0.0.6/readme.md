# Python sqlite3 tools.

## Installation

You can install via [pypi](https://pypi.org/project/sqlitetools/)

```console
pip install -U sqlitetools
```

## Usage

```python
import sqlitetools
```
