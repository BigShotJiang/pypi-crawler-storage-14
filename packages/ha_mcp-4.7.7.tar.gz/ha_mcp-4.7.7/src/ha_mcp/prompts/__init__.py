"""Home Assistant MCP prompts."""
