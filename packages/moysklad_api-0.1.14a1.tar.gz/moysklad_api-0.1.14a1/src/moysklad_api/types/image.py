from datetime import datetime

from pydantic import BaseModel

from .meta import Meta


class Image(BaseModel):
    filename: str
    meta: Meta
    miniature: Meta
    size: int
    tiny: Meta
    title: str
    updated: datetime
