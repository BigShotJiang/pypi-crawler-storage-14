# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

AZUREML_NOTEBOOK_OUTPUT_PATHS_JSON = "notebook_output_paths.json"
