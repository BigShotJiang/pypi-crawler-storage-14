"""CSV readers and writers."""

from pysdmx.__extras_check import __check_data_extra

__check_data_extra()
