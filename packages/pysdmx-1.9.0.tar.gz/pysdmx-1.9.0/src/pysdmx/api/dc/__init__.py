"""pysdmx simple data discovery and retrieval API."""

from pysdmx.api.dc._api import Connector

__all__ = ["Connector"]
