"""Roles API routes."""

from apex.api.v1.roles.router import router

__all__ = ["router"]

