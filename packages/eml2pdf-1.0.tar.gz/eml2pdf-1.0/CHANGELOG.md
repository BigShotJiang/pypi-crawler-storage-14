# Eml2pdf changelog

## v1.0 - 2025-11-25

- Fix issue #1 - support cpu count on Windows.
- Split off libeml2pdf from eml2pdf module to prepare for GUI support.
- README.md: AUR package renamed.

## v0.1.1 - 2025-02-09

- Fix broken 'pip install' when downloading source archive from github.
