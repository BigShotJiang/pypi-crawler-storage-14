from __future__ import annotations

from .__main__ import *

__version__ = "0.5.2"
__name__ = "MinecraftDockerCLI"
