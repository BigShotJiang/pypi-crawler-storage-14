"""
Author: HECE - University of Liege, Pierre Archambeau
Date: 2025

Copyright (c) 2025 University of Liege. All rights reserved.

This script and its content are protected by copyright law. Unauthorized
copying or distribution of this file, via any medium, is strictly prohibited.
"""

from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
import logging
import warnings
from enum import Enum
import pint

class ParameterType(Enum):
    INT = "int"
    FLOAT = "float"
    STR = "str"
    BOOL = "bool"
    LIST = "list"
    DICT = "dict"
    QUANTITY = "Quantity"

ureg: pint.UnitRegistry
ureg = pint.UnitRegistry()

@dataclass_json
@dataclass(order=True)
class Parameter:
    """
    Instances of this class represent parameters.
    """
    identifier: str
    group: str
    expected_type : str
    value : int | float | str | bool | list | dict | pint.Quantity | Enum
    value_by_default: int | float | str | bool | pint.Quantity | list | dict | Enum
    units : pint.Unit | str = field(default="")
    bounds: tuple = field(default=None)
    label: str = field(default="")
    comment: str = field(default="")
    mandatory: bool = field(default=True)

    @property
    def type(self):
        """
        Get the type of the parameter value.
        :return: The type of the parameter value.
        """
        return type(self.value)

    def __post_init__(self):
        self.expected_type = str(self.expected_type.__name__) if not isinstance(self.expected_type, str) else self.expected_type
        self.value = self._verify_expected_type(self.value)

    @property
    def lower_bound(self):
        """
        Get the lower bound of the parameter.
        :return: The lower bound of the parameter.
        """
        if self.bounds is None:
            return None

        if self.expected_type == "Quantity":
            return self.bounds[0] * self.units if self.bounds[0] is not None else None

        return self.bounds[0]

    @property
    def upper_bound(self):
        """
        Get the upper bound of the parameter.
        :return: The upper bound of the parameter.
        """
        if self.bounds is None:
            return None

        if self.expected_type == "Quantity":
            return self.bounds[1] * self.units if self.bounds[1] is not None else None

        return self.bounds[1]

    @property
    def is_in_bounds(self) -> bool:
        """
        Check if the parameter value is within the defined bounds.
        :return: True if the value is within bounds, False otherwise.
        """
        if self.bounds is None:
            return True

        lower_bound, upper_bound = self.bounds

        if self.expected_type == "Quantity":
            if self.lower_bound is not None:
                return self.value >= self.lower_bound
            if self.upper_bound is not None:
                return self.value <= self.upper_bound
        else:
            if lower_bound is not None and self.value < lower_bound:
                return False
            if upper_bound is not None and self.value > upper_bound:
                return False

        return True

    @property
    def is_in_bounds_exclusive(self) -> bool:
        """
        Check if the parameter value is within the defined bounds (exclusive).
        :return: True if the value is within bounds, False otherwise.
        """
        if self.bounds is None:
            return True

        lower_bound, upper_bound = self.bounds

        if self.expected_type == "Quantity":
            if self.lower_bound is not None:
                return self.value > self.lower_bound
            if self.upper_bound is not None:
                return self.value < self.upper_bound
        else:
            if lower_bound is not None and self.value <= lower_bound:
                return False
            if upper_bound is not None and self.value >= upper_bound:
                return False

        return True

    @property
    def is_default(self) -> bool:
        """
        Check if the parameter value is equal to its default value.
        :return: True if the value is equal to its default value, False otherwise.
        """
        return self.value == self.value_by_default

    def _verify_expected_type(self, value):

        if type(value).__name__ != self.expected_type:
            try:
                if self.expected_type == "int":
                    return int(value)
                elif self.expected_type == "float":
                    return float(value)
                elif self.expected_type == "str":
                    return str(value)
                elif self.expected_type == "bool":
                    return bool(value)
                elif self.expected_type == "list":
                    return list(value)
                elif self.expected_type == "dict":
                    return dict(value)
                elif self.expected_type == "Quantity":
                    if isinstance(value, pint.Quantity):
                        return value.to(self.units)
                    else:
                        if isinstance(self.units, str):
                            return value * ureg.parse_units(self.units)
                        else:
                            return value * self.units
                elif self.expected_type == "Enum":
                    return value
                else:
                    raise TypeError(f"Expected type {self.expected_type} is not supported")
            except Exception as e:
                raise TypeError(f"Cannot convert value {value} to type {self.expected_type}: {e}")
        return value

    def __and__(self, other):
        if isinstance(other, Parameter):
            return self.value & self._verify_expected_type(other.value)
        else:
            return self.value & self._verify_expected_type(other)

    def __rand__(self, other):
        return self.__and__(other)

    def __or__(self, other):
        if isinstance(other, Parameter):
            return self.value | self._verify_expected_type(other.value)
        else:
            return self.value | self._verify_expected_type(other)

    def __ror__(self, other):
        return self.__or__(other)

    def __add__(self, other):
        if isinstance(other, Parameter):
            if self.expected_type == dict.__name__:
                # merge dictionaries
                result = self.value.copy()
                result.update(other.value)
                return result

            return self.value + self._verify_expected_type(other.value)
        else:
            if self.expected_type == dict.__name__:
                # merge dictionaries
                result = self.value.copy()
                result.update(other.value)
                return result

            return self.value + self._verify_expected_type(other)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        if self.expected_type == dict.__name__:
            raise TypeError("Subtraction is not supported for dictionary type parameters")

        if isinstance(other, Parameter):
            return self.value - self._verify_expected_type(other.value)
        else:
            return self.value - self._verify_expected_type(other)

    def __rsub__(self, other):
        if self.expected_type == dict.__name__:
            raise TypeError("Subtraction is not supported for dictionary type parameters")

        if isinstance(other, Parameter):
            return other._verify_expected_type(other.value) - self.value
        else:
            return self._verify_expected_type(other) - self.value

    def __mul__(self, other):
        if self.expected_type == dict.__name__:
            raise TypeError("Multiplication is not supported for dictionary type parameters")

        if isinstance(other, Parameter):
            return self.value * self._verify_expected_type(other.value)
        else:
            return self.value * self._verify_expected_type(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        if self.expected_type == dict.__name__:
            raise TypeError("Division is not supported for dictionary type parameters")

        if isinstance(other, Parameter):
            return self.value / self._verify_expected_type(other.value)
        else:
            return self.value / self._verify_expected_type(other)

    def __rtruediv__(self, other):
        if isinstance(other, Parameter):
            return self._verify_expected_type(other.value) / self.value
        else:
            return self._verify_expected_type(other) / self.value


@dataclass_json
@dataclass
class GroupParameters:
    """
    Instances of this class represent a group of parameters.
    """
    group_name: str
    parameters: dict[str, Parameter] = field(default_factory=dict)

    def __call__(self, identifier: str) -> Parameter:
        """
        Get a parameter by its identifier.
        :param identifier: The identifier of the parameter.
        :return: The parameter with the given identifier.
        """
        warnings.warn("Using GroupParameters as a callable is not recommended. Use get_parameter or __getitem__ instead.", SyntaxWarning)
        return self.parameters.get(identifier, None).value

    def __getitem__(self, identifier: str) -> Parameter:
        """
        Get a parameter by its identifier.
        :param identifier: The identifier of the parameter.
        :return: The parameter with the given identifier.
        """
        return self.parameters.get(identifier, None).value

    def get_parameter(self, identifier: str) -> Parameter:
        """
        Get a parameter by its identifier.
        :param identifier: The identifier of the parameter.
        :return: The parameter with the given identifier.
        """
        return self.parameters.get(identifier, None)

    def to_list(self) -> list[Parameter]:
        """
        Get all parameters in the group.
        :return: A dictionary of all parameters in the group.
        """
        return list(self.parameters.values())

    def add_parameter(self, parameter: Parameter):
        """
        Add a parameter to the group.
        :param parameter: The parameter to add.
        """
        if parameter.identifier in self.parameters:
            raise ValueError(f"Parameter with identifier {parameter.identifier} already exists in group {self.group_name}")

        self.parameters[parameter.identifier] = parameter
        parameter.group = self.group_name

@dataclass_json
@dataclass
class GroupofGroupsParameters:
    """
    Instances of this class represent a group of groups of parameters.
    """
    groupofgroups_name: str
    groups_parameters: dict[str, GroupParameters] = field(default_factory=dict)

    def __getitem__(self, *args, **kwargs):
        """
        Get a group of parameters by its name or a parameter by a tuple of group name and parameter identifier.

        :param args: The name of the group or a tuple of group name and parameter identifier
        :param kwargs: can contains 'group' and 'identifier' keys
        :return: The group of parameters or the parameter with the given name.
        """
        if len(args) == 1:
            if len(args[0]) == 2:
                group_name = args[0][0]
                identifier = args[0][1]
                group = self.groups_parameters.get(group_name, None)
                if group is not None:
                    return group[identifier]
                else:
                    return None
            else:
                return self.groups_parameters.get(args[0], None)
        elif len(args) == 2:
            group_name = args[0]
            identifier = args[1]
            group = self.groups_parameters.get(group_name, None)
            if group is not None:
                return group[identifier]
            else:
                return None
        elif 'group' in kwargs:
            group_name = kwargs['group']
            group = self.groups_parameters.get(group_name, None)

            if 'identifier' in kwargs:
                identifier = kwargs['identifier']
                return group[identifier]
            else:
                return group
        else:
            raise ValueError("Invalid arguments. Provide either a group name or a tuple of group name and parameter identifier.")

    def get_group(self, group_name: str) -> GroupParameters:
        """
        Get a group of parameters by its name.
        :param group_name: The name of the group.
        :return: The group of parameters with the given name.
        """
        return self.groups_parameters.get(group_name, None)

    def to_list(self) -> list[GroupParameters]:
        """
        Get all groups of parameters.
        :return: A list of all groups of parameters.
        """
        return list(self.groups_parameters.values())

    def add_group(self, group_parameters: GroupParameters):
        """
        Add a group of parameters to the group of groups.
        :param group_parameters: The group of parameters to add.
        """
        self.groups_parameters[group_parameters.group_name] = group_parameters


if __name__ == "__main__":

    class test():

        def __init__(self):
            self.p1 = Parameter(
                            identifier="param1",
                            group="group1",
                            value=0,
                            value_by_default=10,
                            expected_type=pint.Quantity,
                            bounds=(0, 100),
                            units=ureg.meter,
                            label="Parameter 1",
                            comment="This is parameter 1",
                            mandatory=True
                        )
            self.p2 = Parameter(
                            identifier="param2",
                            group="group1",
                            value=20.5,
                            value_by_default=20.5,
                            expected_type='Quantity',
                            bounds=(0.0, 100.0),
                            units=ureg.kilometer,
                            label="Parameter 2",
                            comment="This is parameter 2",
                            mandatory=False
                        )

            self.p3 = Parameter(
                            identifier="param3",
                            group="group1",
                            value=20.5,
                            value_by_default=20.5,
                            expected_type='Quantity',
                            bounds=(0.0, 100.0),
                            units='km',
                            label="Parameter 3",
                            comment="This is parameter 3",
                            mandatory=False
                        )

            self.p4  = Parameter(
                            identifier="param4",
                            group="group1",
                            value=[1,2,3],
                            value_by_default=[],
                            expected_type='list',
                            label="Parameter 4",
                            comment="This is parameter 4",
                            mandatory=True
                        )

            self.p5  = Parameter(
                            identifier="param5",
                            group="group1",
                            value=[4,5,6],
                            value_by_default=[],
                            expected_type='list',
                            label="Parameter 5",
                            comment="This is parameter 5",
                            mandatory=True
                        )

            self.p6  = Parameter(
                            identifier="param4",
                            group="group1",
                            value={'a':1,'b':2,'c':3},
                            value_by_default={},
                            expected_type='dict',
                            label="Parameter 6",
                            comment="This is parameter 6",
                            mandatory=True
                        )

            self.p7  = Parameter(
                            identifier="param7",
                            group="group1",
                            value={'d':4,'e':5,'f':6},
                            value_by_default={'d':4,'e':5,'f':6},
                            expected_type=dict,
                            label="Parameter 7",
                            comment="This is parameter 7",
                            mandatory=True
                        )

            self.p8 = Parameter(
                            identifier="param8",
                            group="group1",
                            value=ParameterType.BOOL,
                            value_by_default=ParameterType.BOOL,
                            expected_type=Enum,
                            label="Parameter 8",
                            comment="This is parameter 8",
                            mandatory=True
                        )

            self.p9 = Parameter(
                            identifier="param9",
                            group="group1",
                            value=True,
                            value_by_default=False,
                            expected_type=bool,
                            label="Parameter 8",
                            comment="This is parameter 8",
                            mandatory=True
                        )

            self.p10 = Parameter(
                            identifier="param10",
                            group="group1",
                            value=False,
                            value_by_default=False,
                            expected_type=bool,
                            label="Parameter 10",
                            comment="This is parameter 10",
                            mandatory=True
                        )

            self.p11 = Parameter(
                            identifier="param11",
                            group="group1",
                            value=10,
                            value_by_default=False,
                            expected_type=int,
                            label="Parameter 11",
                            comment="This is parameter 11",
                            mandatory=True
                        )

            self.p12 = Parameter(
                            identifier="param12",
                            group="group1",
                            value=10.,
                            value_by_default=False,
                            expected_type=float,
                            label="Parameter 12",
                            comment="This is parameter 12",
                            mandatory=True
                        )

            self.parameters = GroupParameters(group_name="group1")
            self.parameters.add_parameter(self.p1)
            self.parameters.add_parameter(self.p2)
            self.parameters.add_parameter(self.p3)
            self.parameters.add_parameter(self.p4)
            self.parameters.add_parameter(self.p5)
            try:
                self.parameters.add_parameter(self.p6)
                raise Exception("Should have raised an exception")
            except ValueError:
                self.p6.identifier = "param6"
                self.parameters.add_parameter(self.p6)

            self.parameters.add_parameter(self.p7)

            self.allparameters = GroupofGroupsParameters(groupofgroups_name="groupofgroups1")
            self.allparameters.add_group(self.parameters)

            print(self.parameters("param1"))
            print(self.parameters("param2"))

            print(self.parameters["param1"])
            print(self.parameters["param2"])

            print(self.allparameters["group1","param1"])
            print(type(self.allparameters["group1","param1"]))

            print(self.p1.type)

            p3 = self.p1 + self.p2
            print(f"p3 = p1 + p2 = {p3}")
            assert p3.magnitude == 20500.0 and str(p3.units) == 'meter'

            p3 = 10. + self.p2
            print(f"p3 = p1 + p2 = {p3}")
            assert p3.magnitude == 30.5 and str(p3.units) == 'kilometer'
            p3 = self.p2 + 10.
            print(f"p3 = p1 + p2 = {p3}")
            assert p3.magnitude == 30.5 and str(p3.units) == 'kilometer'

            p3 = self.p2 / 10.
            print(f"p3 = p1 + p2 = {p3}")
            assert p3.magnitude == 2.05 and str(p3.units) == 'dimensionless'

            p3 = self.p11 + self.p12
            print(f"p3 = p11 + p12 = {p3}")
            assert p3 == 10 + 10
            assert isinstance(p3, int)

            p3 = self.p12 + self.p11
            print(f"p3 = p12 + p11 = {p3}")
            assert p3 == 10. + 10.
            assert isinstance(p3, float)


            p8 = self.p4 + self.p5
            print(f"p8 = p4 + p5 = {p8}")

            p9 = self.p6 + self.p7
            print(f"p9 = p6 + p7 = {p9}")

            p11 = self.p9 + self.p10
            print(f"p11 = p9 + p10 = {p11}")

            p11 = self.p9 & self.p10
            print(f"p11 = p9 and p10 = {p11}")
            p11 = self.p9 | self.p10
            print(f"p11 = p9 or p10 = {p11}")

            print(self.p1.is_in_bounds)
            print(self.p1.is_in_bounds_exclusive)

            print(self.p7.is_default)
    t = test()
    pass

