from umlshapes._version import __version__
