"""
ribodetector

Accurate and rapid RiboRNA sequences Detector based on deep learning.
"""

__version__ = "0.3.2"
__author__ = 'ZL Deng'
