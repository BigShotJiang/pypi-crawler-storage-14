"""The amavis frontend of Modoboa."""

default_app_config = "modoboa.amavis.apps.AmavisConfig"
