###########
Translation
###########

Modoboa needs you to translate the project ! Feel free to join the translation team.

The project is using Transifex. To start with translation, you will need to create an account and join `modoboa's team <https://www.transifex.com/tonio/modoboa/dashboard/>`_

.. _translation:

Frontend
========

When editing the frontend, you may need to update localization files for transifex to pick up your changes.

To do so, after finishing editing, go to the frontend directory and run the following command::

  $ make makemessages
