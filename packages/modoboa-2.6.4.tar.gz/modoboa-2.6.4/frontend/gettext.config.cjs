module.exports = {
  output: {
    path: './src/locale',
    locales: [
      'en',
      'br',
      'cs',
      'de',
      'el',
      'es',
      'fi',
      'fr',
      'it',
      'ja',
      'nl',
      'pl',
      'pt_BR',
      'ru',
      'sv',
      'tr',
      'zh',
    ],
  },
}
