# API Reference: Settings

::: udspy.settings
