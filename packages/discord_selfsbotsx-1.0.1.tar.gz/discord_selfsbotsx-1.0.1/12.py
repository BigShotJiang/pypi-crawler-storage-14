from discord_selfsbotsx import initializationSelf

initializationSelf()  # Запускает клиент в фоне [file:67][file:66]