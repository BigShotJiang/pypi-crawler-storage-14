#!/usr/bin/env python
# -*- coding: utf-8 -*-
import importlib.metadata as metadata
from typing import Final

version: Final[str] = metadata.version("sensirion_driver_support_types")
