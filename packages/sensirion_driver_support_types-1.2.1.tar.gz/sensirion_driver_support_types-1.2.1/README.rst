sensirion-driver-support-types
==============================

Install
-------
.. sourcecode:: bash

    pip install sensirion-driver-support-types

Recommended usage is within a virtualenv.

Usage
-----
.. sourcecode:: python

    import sensirion_driver_support_types

