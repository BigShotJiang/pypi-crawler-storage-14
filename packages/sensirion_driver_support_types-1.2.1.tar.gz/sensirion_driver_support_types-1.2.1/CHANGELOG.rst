CHANGELOG
---------

1.2.1
:::::
- Update project structure

1.2.0
:::::
- support bitfield initialization

1.1.1
:::::
- support c-structs for python 3.8

1.0.1
:::::
- support mixin access even if driver class is derived

1.0.0
:::::
- tag 1.0.0
- Provide c-struct template

0.3.0
:::::
- Update dependencies and CI


0.2.0
:::::
- Provide string representation and int conversion for Bitfields

0.1.0
:::::
- Initial release
