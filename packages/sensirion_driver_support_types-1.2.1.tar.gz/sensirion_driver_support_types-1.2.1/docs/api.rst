API Documentation
=================

The package sensirion-driver-support-types provides classes that are widely used
in drivers. For now this are base type for signals
and integer wrappers that provide bit level access similar to bitfields in C/C++

 .. automodule:: sensirion_driver_support_types


