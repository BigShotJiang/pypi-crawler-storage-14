"""Rill - AI Agent Framework"""

__version__ = "0.1.0"