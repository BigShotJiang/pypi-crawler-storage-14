"""Setup file for rill-ai package."""
from setuptools import setup

# setup.py is kept minimal as pyproject.toml is the primary configuration
setup()
