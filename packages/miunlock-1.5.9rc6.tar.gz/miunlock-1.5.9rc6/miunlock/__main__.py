from miunlock import main

if __name__ == "__main__":
    main()
    input('\nPress Enter to exit')
