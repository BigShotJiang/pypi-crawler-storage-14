organization_fragment = """
fragment OrganizationFragment on Organization {
    id
    pk
    slug
    name
    createdAt
    updatedAt
}
"""
