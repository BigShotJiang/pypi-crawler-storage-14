# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""services package."""

from .aml_request import rawhttp as rawhttp
