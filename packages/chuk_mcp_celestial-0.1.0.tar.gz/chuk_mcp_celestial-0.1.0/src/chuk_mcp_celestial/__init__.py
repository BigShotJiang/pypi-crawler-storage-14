"""US Navy Celestial MCP Server.

Provides astronomical and celestial data from the US Navy's Astronomical Applications API.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
