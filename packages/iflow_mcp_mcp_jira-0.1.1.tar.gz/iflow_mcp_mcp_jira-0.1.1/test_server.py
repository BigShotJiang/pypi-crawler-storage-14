#!/usr/bin/env python3
"""
Test script for mcp-jira server
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from mcp_jira.simple_mcp_server import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())