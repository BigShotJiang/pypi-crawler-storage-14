"""Model Context Protocol server for Jira with Scrum Master capabilities"""

__version__ = "0.1.1"
