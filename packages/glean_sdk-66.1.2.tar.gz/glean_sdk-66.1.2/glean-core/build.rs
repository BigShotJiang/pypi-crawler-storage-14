fn main() {
    uniffi::generate_scaffolding("./src/glean.udl").unwrap();
}
