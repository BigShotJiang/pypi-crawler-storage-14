
from ..resources.lemmatizer import AmharicLemmatizer  


lemmatizer = AmharicLemmatizer()

# Make available at package level
__all__ = [ 'lemmatizer']