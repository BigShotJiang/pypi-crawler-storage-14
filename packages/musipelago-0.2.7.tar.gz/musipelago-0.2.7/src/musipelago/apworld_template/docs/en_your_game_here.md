# This is where your game name would be!

## Where is the options page?

Here is where you put the instructions on how to get to the options page. What is currently there should work and direct the player
your game/player-options which is the normal page for options. Really only change this to spice it up or if something weir is happening

The [player options page for this game](../player-options) contains all the options you need to configure and export a
config file.

## What does randomization do to this game?

Here you put all the items you are randomizing! You could include future goals or you could only put whats actually possible.
The world is your oyster.
And by world I mean these 3 lines of text.

## Which items can be in another player's world?

This section is useful for if your game has items that will always be local. I can't think of any games as an example but I know they exist

## When the player receives an item, what happens?

Here you can tell the player what it will look like when you receive an item in game. This is really nice cause it helps people figure out if
they actually are receiving items the first time they set up the game. Also nice for explaining that really funny/cool/quirky system you
put into your game that only a few people will see but youre really proud of.
