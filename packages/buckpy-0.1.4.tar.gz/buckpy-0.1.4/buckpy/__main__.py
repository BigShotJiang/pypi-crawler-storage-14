'''
This is the main entry point for the BuckPy package for running the package from the command line.
'''

from . import run

if __name__ == "__main__":
    run()
