'''
This is the main entry point for the BuckPy package for imports and package setup.
'''

from .buckpy import main

def run():

    '''
    Run BuckPy main workflow.
    '''

    main()
