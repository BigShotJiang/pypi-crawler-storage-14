# BUCKPY
Probabilistic Lateral Buckling Algorithm.

## Project Philosophy
**BuckPy** is an open-source algorithm developed to facilitate the implementation of the probabilistic lateral buckling methodology presented in [Lateral Buckling Design using the Friction Distributions at the Expected Buckles (PDF)](docs/_static/SPT%202023%20-%20Lateral%20Buckling%20Design%20using%20the%20Friction%20Distributions%20at%20the%20Expected%20Buckles.pdf), published by Ismael R., Carlos S., and Emilien B. at the 2023 Subsea Pipeline Technology Congress in London (SPT 2023).

The code is available on [GitHub](https://github.com/Xodus-Group/BuckPy), allowing the pipeline community to review, expand, and use it under the [GNU General Public License v3.0](https://github.com/Xodus-Group/BuckPy/blob/main/LICENSE).

## Documentation
See the [BuckPy Documentation Website](https://buckpy-org.github.io/) for full usage guides, technical references, benchmarking, API references, and updates.
