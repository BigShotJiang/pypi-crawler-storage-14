"""Prompt Groomer - A lightweight library for optimizing LLM inputs."""

__version__ = "0.1.0"

from .analyzer import CountTokens

# Import all operations for convenience
from .cleaner import FixUnicode, NormalizeWhitespace, StripHTML
from .compressor import Deduplicate, TruncateTokens
from .groomer import Groomer
from .scrubber import RedactPII

__all__ = [
    "Groomer",
    # Cleaner operations
    "StripHTML",
    "NormalizeWhitespace",
    "FixUnicode",
    # Compressor operations
    "TruncateTokens",
    "Deduplicate",
    # Scrubber operations
    "RedactPII",
    # Analyzer operations
    "CountTokens",
]
