"""
Custom exceptions for the AEY Vision SDK.
"""


class AeyVisionError(Exception):
    """Base exception for all AEY Vision SDK errors."""
    pass


class AuthenticationError(AeyVisionError):
    """Raised when API key is invalid or missing."""
    pass


class RateLimitError(AeyVisionError):
    """Raised when API rate limit is exceeded."""
    
    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None):
        super().__init__(message)
        self.retry_after = retry_after


class ValidationError(AeyVisionError):
    """Raised when request validation fails."""
    pass


class APIError(AeyVisionError):
    """Raised when the API returns an error response."""
    
    def __init__(self, message: str, status_code: int = None, response_body: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class NetworkError(AeyVisionError):
    """Raised when a network error occurs."""
    pass


class TimeoutError(AeyVisionError):
    """Raised when a request times out."""
    pass
