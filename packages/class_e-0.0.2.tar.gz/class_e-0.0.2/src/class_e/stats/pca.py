from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import joblib
import numpy as np
from sklearn.decomposition import PCA


@dataclass
class PCAModel:
    names: List[str]
    mean_: np.ndarray
    pca: PCA


class ParamPCA:
    def __init__(self, n_components: int | float = 0.95) -> None:
        self.n_components = n_components
        self.model: PCAModel | None = None

    def fit(self, theta: np.ndarray, names: Sequence[str]) -> None:
        theta = np.asarray(theta)
        pca = PCA(n_components=self.n_components, svd_solver="auto")
        pca.fit(theta)
        self.model = PCAModel(names=list(names), mean_=pca.mean_.copy(), pca=pca)

    def transform(self, theta: np.ndarray) -> np.ndarray:
        if self.model is None:
            raise RuntimeError("ParamPCA not fitted")
        return self.model.pca.transform(theta)

    def inverse_transform(self, z: np.ndarray) -> np.ndarray:
        if self.model is None:
            raise RuntimeError("ParamPCA not fitted")
        return self.model.pca.inverse_transform(z)

    def save(self, path: str) -> None:
        if self.model is None:
            raise RuntimeError("ParamPCA not fitted")
        joblib.dump({"names": self.model.names, "pca": self.model.pca}, path)

    @staticmethod
    def load(path: str) -> "ParamPCA":
        data = joblib.load(path)
        obj = ParamPCA()
        obj.model = PCAModel(
            names=data["names"], mean_=data["pca"].mean_, pca=data["pca"]
        )
        return obj
