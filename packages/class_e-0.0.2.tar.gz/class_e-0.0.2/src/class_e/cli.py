import typer
from pathlib import Path
from typing_extensions import Annotated
from typing import List, Optional
from rich.console import Console

from class_e.core.io import DESCRIPTION
from class_e.utils import mo

console = Console()
app = typer.Typer(help=DESCRIPTION)


@app.command()
def train(
    dataset: Annotated[
        Optional[str],
        typer.Option(
            "--dataset",
            help="Path to dataset .npz file to use for training",
            show_default=False,
        ),
    ] = None,
    N_PCA: Annotated[
        Optional[int],
        typer.Option("--N-PCA", help="Number of PCA components", show_default=False),
    ] = None,
    test_fraction: Annotated[
        Optional[float],
        typer.Option(
            "--test-fraction",
            help="Test fraction for train/test split",
            show_default=False,
        ),
    ] = None,
    log_space: Annotated[
        Optional[bool],
        typer.Option(
            "--log-space", help="Train emulators in log space", show_default=False
        ),
    ] = None,
    standardize_X: Annotated[
        Optional[bool],
        typer.Option("--standardize", help="Standardize X inputs", show_default=False),
    ] = None,
    interactive: Annotated[
        bool,
        typer.Option(
            "--interactive",
            "-i",
            help="Launch interactive Marimo notebook interface for data generation",
        ),
    ] = False,
    edit: Annotated[
        Optional[bool],
        typer.Option(
            "--edit",
            "-e",
            help="Enter the interactive notebook in edit mode",
            show_default=False,
        ),
    ] = False,
):
    if interactive or edit:
        console.print(
            "[bold cyan]Launching interactive emulator training interface...[/bold cyan]"
        )

        # Get the path to train.py
        train_script = Path(__file__).parent / "train.py"
        mo.run_marimo(train_script, console, edit=edit)

    from class_e.train import Options, run

    # Delegate to command implementation
    opts = Options(
        dataset=dataset,
        N_PCA=N_PCA if N_PCA is not None else 12,
        test_fraction=test_fraction if test_fraction is not None else 0.2,
        log_space=bool(log_space) if log_space is not None else True,
        standardize_X=bool(standardize_X) if standardize_X is not None else True,
    )

    result = run(opts, console=console)
    if result is None:
        # Training failed or was aborted
        raise typer.Exit(0)


@app.command()
def generate(
    info: Annotated[
        str,
        typer.Argument(
            help="Specify the path to a .yaml file containing the prior bounds for the free parameters"
        ),
    ] = None,
    out: Annotated[
        Optional[str],
        typer.Option(
            "--out",
            help="Output path where to store the training data (file or directory)",
            show_default=False,
        ),
    ] = None,
    N: Annotated[
        Optional[int],
        typer.Option(
            "--N",
            "-N",
            help="Number of cosmologies to sample (overrides YAML)",
            show_default=False,
        ),
    ] = None,
    method: Annotated[
        Optional[str],
        typer.Option(
            "--method",
            "-m",
            help=(
                "Sampling method. Choose from: LatinHyperCube (LHC), "
                "LatinHyperSphere (LHS), or CovarianceAwareLatinHyperCube (COV). "
                "Defaults to the YAML value samples.method."
            ),
            show_default=False,
        ),
    ] = None,
    observables: Annotated[
        Optional[List[str]],
        typer.Option(
            "--observable",
            "-o",
            help="Observable(s) to compute. Repeat flag for multiple (e.g., -o TT -o TE -o EE -o mPk)",
            show_default=True,
        ),
    ] = None,
    lmin: Annotated[
        Optional[int],
        typer.Option(
            "--lmin",
            help="Minimum multipole (ℓ) for C_ℓ spectra",
            show_default=True,
        ),
    ] = None,
    lmax: Annotated[
        Optional[int],
        typer.Option(
            "--lmax",
            help="Maximum multipole (ℓ) for C_ℓ spectra",
            show_default=True,
        ),
    ] = None,
    kmin: Annotated[
        Optional[float],
        typer.Option(
            "--kmin",
            help="Minimum wavenumber k [h/Mpc] for matter power spectrum grid",
            show_default=True,
        ),
    ] = None,
    kmax: Annotated[
        Optional[float],
        typer.Option(
            "--kmax",
            help="Maximum wavenumber k [h/Mpc] for matter power spectrum grid",
            show_default=True,
        ),
    ] = None,
    cov: Annotated[
        Optional[str],
        typer.Option(
            "--cov",
            help=(
                "Path to covariance matrix for COV method (.npz/.npy/.txt/.csv). "
                "If provided, the sampling method will be set to COV."
            ),
            show_default=False,
        ),
    ] = None,
    interactive: Annotated[
        bool,
        typer.Option(
            "--interactive",
            "-i",
            help="Launch interactive Marimo notebook interface for data generation",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            "-d",
            help="Print configuration and exit without generating data",
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Force overwrite of existing dataset without prompt.",
        ),
    ] = False,
    edit: Annotated[
        Optional[bool],
        typer.Option(
            "--edit",
            "-e",
            help="Enter the interactive notebook in edit mode",
            show_default=False,
        ),
    ] = False,
):
    if interactive:
        console.print(
            "[bold cyan]Launching interactive data generation interface...[/bold cyan]"
        )

        # Get the path to generate.py
        generate_script = Path(__file__).parent / "generate.py"

        if not generate_script.exists():
            console.print(
                f"[bold red]Error: Could not find generate.py at {generate_script}[/bold red]"
            )
            raise typer.Exit(1)

        mo.run_marimo(generate_script, console, edit=edit)

    from class_e.generate import Options, run

    # Delegate to command implementation
    opts = Options(
        info=Path(info),
        out=Path(out) if out else None,
        N=N,
        method=method,
        observables=observables,
        lmin=lmin,
        lmax=lmax,
        kmin=kmin,
        kmax=kmax,
        cov=Path(cov) if cov else None,
        interactive=interactive,
        dry_run=dry_run,
        force=force,
    )
    result_path = run(opts, console)
    if result_path is None and not dry_run:
        # User chose to skip or validation failed
        raise typer.Exit(0)


@app.command()
def sample():
    console.print(
        "[bold cyan]Sampling the posterior distribution with Class-E[/bold cyan]..."
    )
    pass


@app.command()
def info():
    console.print(
        "[bold cyan]Requesting detailed information about an emulator...[/bold cyan]"
    )
    pass


@app.command()
def inspect(
    edit: Annotated[
        Optional[bool],
        typer.Option(
            "--edit",
            "-e",
            help="Enter the interactive notebook in edit mode",
            show_default=False,
        ),
    ] = False,
):
    console.print("[bold cyan]Inspecting the training set...[/bold cyan]")
    # Get the path to inspect.py
    inspect_script = Path(__file__).parent / "inspect.py"
    mo.run_marimo(inspect_script, console, edit=edit)


def main():
    return app()


if __name__ == "__main__":
    main()
