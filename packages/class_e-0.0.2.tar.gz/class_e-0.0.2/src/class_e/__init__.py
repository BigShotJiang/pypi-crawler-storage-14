__author__ = """Rodrigo Calderon"""
__email__ = "calderon.cosmology@gmail.com"
__version__ = "0.0.1"


def main() -> None:
    from class_e.cli import app

    app()
