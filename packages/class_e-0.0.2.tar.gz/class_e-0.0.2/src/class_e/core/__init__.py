from .emulator import BaseEmulator, FitResult

# Import from boltzmann module (CLASS interface)
from .boltzmann import (
    load_cosmology_model,
    compute_cosmology,
    get_observables,
    require_classy,
    HAS_CLASSY,
)

__all__ = [
    "BaseEmulator",
    "FitResult",
    "load_cosmology_model",
    "compute_cosmology",
    "get_observables",
    "require_classy",
    "HAS_CLASSY",
]
