from __future__ import annotations

from typing import Any, Dict, Optional, Type
import re
from pathlib import Path
import numpy as np
from pydantic import BaseModel
from class_e.core.observables import ObservablesRequest, ObservablesResult
from class_e.core.parameters import build_outputs_flag, merge_class_args
from class_e.core.backend import ClassyBackend


# Try to import CLASS from system installation first
try:
    from classy import Class  # type: ignore
except Exception as e:
    Class = None
    _import_error = e
else:
    _import_error = None

HAS_CLASSY = Class is not None

# Default YAML backing for the model (caller may override by passing a path)
DEFAULT_CONFIG_PATH = Path("defaults.yaml")


def load_class_from_config(config_path: str | Path, verbose: bool = True) -> type:
    """Load CLASS from the path specified in a configuration file.

    This function reads the CLASS installation path from the YAML config
    and dynamically loads the CLASS Python wrapper.

    Parameters
    ----------
    config_path : str or Path
        Path to YAML configuration file containing theory.classy.path
    verbose : bool, default True
        If True, print confirmation message with the loaded CLASS path.

    Returns
    -------
    type
        The Class class from the classy module.

    Examples
    --------
    >>> Class = load_class_from_config("example.yaml")
    ✓ Loaded CLASS Python wrapper from: /Users/user/github/AxiCLASS/build/lib...
    """
    from class_e.utils import load_class_from_yaml

    return load_class_from_yaml(config_path, verbose=verbose)


def require_classy(raise_if_missing: bool = False) -> bool:
    """Check for classy; optionally raise.

    Returns True if classy is available. If not and raise_if_missing is True, raises ImportError.
    """
    if Class is None:
        if raise_if_missing:
            msg = (
                "classy (CLASS Python wrapper) not available. Build CLASS and install its Python "
                "wrapper. See README for instructions. Original import error: "
                + str(_import_error)
            )
            raise ImportError(msg)
        return False
    return True


def load_cosmology_model(config_path: str | Path) -> Type[BaseModel]:
    """Load a cosmology model from a YAML configuration file.

    This is a convenience function that uses the dynamic model factory
    to create a Pydantic model class from a YAML configuration.

    Parameters
    ----------
    config_path : str or Path
        Path to YAML configuration file defining parameters and derived parameters

    Returns
    -------
    Type[BaseModel]
        Pydantic model class with validation and derived parameters

    Examples
    --------
    >>> LCDMModel = load_cosmology_model("configs/lcdm.yaml")
    >>> params = LCDMModel(h=0.67, omega_b=0.022, omega_cdm=0.12)
    >>> class_dict = params.to_class()

    >>> # Model with Early Dark Energy
    >>> EDEModel = load_cosmology_model("configs/ede.yaml")
    >>> params = EDEModel(h=0.70, omega_b=0.024, f_ede=0.08, log10_z_c=3.5)

    Notes
    -----
    The returned model class includes:
    - Automatic validation of parameter bounds
    - Support for derived parameters (computed on-the-fly)
    - `to_class()` method for CLASS integration
    - `get_bounds()` classmethod for sampling
    - `get_latex_names()` classmethod for plotting
    - `get_derived_parameters()` classmethod for metadata
    """
    from class_e.core.cosmo_factory import load_cosmology_from_yaml

    return load_cosmology_from_yaml(config_path)


def get_default_model(config_path: Optional[str | Path] = None) -> Type[BaseModel]:
    """Load the default cosmology model from a YAML file.

    If ``config_path`` is provided, it will be used; otherwise the module-level
    DEFAULT_CONFIG_PATH will be used. The path is interpreted relative to the
    current working directory if not absolute.

    Raises
    ------
    FileNotFoundError
        If the YAML file cannot be found.
    """
    path = Path(config_path) if config_path is not None else DEFAULT_CONFIG_PATH
    if not path.exists():
        raise FileNotFoundError(
            f"Cosmology YAML not found at '{path}'. Provide a valid path or create the file."
        )
    from class_e.core.cosmo_factory import load_cosmology_from_yaml

    return load_cosmology_from_yaml(path)


def compute_cosmology(
    params: BaseModel,
    extra_args: Optional[Dict[str, Any]] = None,
    outputs: Optional[str] = None,
) -> Any:
    """Initialize and compute CLASS with given parameters.

    Parameters
    ----------
    params : BaseModel
        Cosmology parameters (any model with to_class() method)
    extra_args : dict, optional
        Additional CLASS parameters (e.g., output types, precision settings)
    outputs : str, optional
        Comma-separated list of outputs (e.g., "tCl,pCl,lCl,mPk")
        Overrides extra_args['output'] if provided

    Returns
    -------
    Class
        Initialized CLASS instance (remember to call struct_cleanup() and empty())

    Examples
    --------
    >>> from class_e.core.boltzmann import get_default_model, compute_cosmology
    >>> LCDM = get_default_model()  # uses configs/lcdm.yaml by default
    >>> params = LCDM()
    >>> cosmo = compute_cosmology(params, outputs="tCl,pCl,lCl")
    >>> try:
    ...     cls_tt = cosmo.lensed_cl(2500)['tt']
    ... finally:
    ...     cosmo.struct_cleanup()
    ...     cosmo.empty()

    >>> # With custom model
    >>> EDEModel = load_cosmology_model("configs/ede.yaml")
    >>> params = EDEModel(h=0.70, f_ede=0.08, log10_z_c=3.5)
    >>> cosmo = compute_cosmology(params, outputs="mPk")
    """
    require_classy(raise_if_missing=True)

    cosmo = Class()

    # Get CLASS parameters from model
    class_params = params.to_class()

    # Merge with extra args
    if extra_args:
        class_params.update(extra_args)
        # Remove any alias that might come from extras
        if "omega_c" in class_params:
            if "omega_cdm" not in class_params:
                class_params["omega_cdm"] = class_params["omega_c"]
            class_params.pop("omega_c", None)

    # Set output if specified
    if outputs:
        class_params["output"] = outputs

    # Normalize aliases AFTER merging extras/outputs so we don't reintroduce them
    if "omega_c" in class_params:
        if "omega_cdm" not in class_params:
            class_params["omega_cdm"] = class_params["omega_c"]
        class_params.pop("omega_c", None)

    # Proactively filter irrelevant CLASS settings based on requested outputs
    # to avoid "did not read input parameter(s)" errors from CLASS when only a
    # subset of observables is requested (e.g., mPk only should not pass
    # l_max_scalars or lensing options).
    out_flag = str(class_params.get("output", "")).strip()
    out_set = {s.strip() for s in out_flag.split(",") if s.strip()}

    wants_cls = any(x in out_set for x in ("tCl", "pCl", "lCl"))
    wants_mpk = "mPk" in out_set

    # Create a working copy we can prune safely prior to set()/compute()
    class_params = dict(class_params)

    if not wants_cls:
        # Remove CMB-spectrum-related keys when no Cls requested
        for k in [
            "l_max_scalars",
            "lensing",
            "A_L",
            "modes",
            "temperature_rescale",
            "polarization_rescale",
        ]:
            class_params.pop(k, None)

    if not wants_mpk:
        # Remove matter power spectrum related keys when mPk not requested
        for k in [
            "P_k_max_1/Mpc",
            "P_k_max_h/Mpc",
            "z_pk",
        ]:
            class_params.pop(k, None)

    # Set parameters and compute (retry by removing unknown keys if CLASS complains)
    def _try_compute(cp: Dict[str, Any]) -> None:
        cosmo.set(cp)
        cosmo.compute()

    try:
        _try_compute(class_params)
    except Exception as e:
        msg = str(e)
        # CLASS error often includes: "Class did not read input parameter(s): x, y"
        m = re.search(r"did not read input parameter\(s\):\s*([^\n]+)", msg, re.I)
        if m:
            unknown = [s.strip() for s in m.group(1).split(",")]
            pruned = {k: v for k, v in class_params.items() if k not in unknown}
            # Only retry if we actually removed something
            if len(pruned) < len(class_params):
                _try_compute(pruned)
                class_params = pruned  # keep for potential downstream use
            else:
                raise
        else:
            raise

    return cosmo


def get_observables(
    params: BaseModel,
    extra_args: Optional[Dict[str, Any]] = None,
    *,
    observables: Optional[list[str]] = None,
    lmax: Optional[int] = None,
    lensed: bool = True,
    k_values: Optional[np.ndarray] = None,
    z_values: Optional[list[float] | np.ndarray] = None,
) -> Dict[str, Any]:
    """Compute requested observables (Cls and/or mPk) in a single CLASS run.

    This function replaces the old deprecated get_observables() and serves as a
    single-pass engine: it configures CLASS once to produce all requested
    quantities and then extracts them without re-initializing CLASS.

    Parameters
    ----------
    params : BaseModel
        Cosmology parameters model (must provide to_class()).
    extra_args : dict, optional
        Additional CLASS arguments (precision, etc.). Will be merged with the
        required options for the requested outputs. The 'output' field will be
        overridden based on the requested observables.
    observables : list[str], optional (keyword-only)
        Any of ["TT", "TE", "EE", "PP", "mPk"]. Defaults to ["TT","TE","EE","mPk"].
    lmax : int, optional (keyword-only)
        Maximum multipole for Cls. Defaults to 2500 if any Cl requested and not provided.
    lensed : bool, default True (keyword-only)
        Return lensed Cls (tt, te, ee). PP is independent of this flag.
    k_values : np.ndarray, optional (keyword-only)
        k grid in h/Mpc for P(k). If None and mPk requested, a default log-space grid is used.
    z_values : list[float] | np.ndarray, optional (keyword-only)
        Redshift values for P(k). If None and mPk requested, defaults to [0.0].

    Returns
    -------
    dict
        A dictionary possibly containing the following keys depending on the request:
        - 'ell': (L,) ell grid (2..lmax)
        - 'tt', 'te', 'ee': (L,) Cl arrays if requested
        - 'pp': (L,) lensing potential spectrum if requested ("PP")
        - 'k': (K,) k grid in h/Mpc if mPk requested
        - 'z': (Z,) redshift grid if mPk requested
        - 'pk': (Z, K) matter power spectrum if mPk requested

    Notes
    -----
    - This function performs exactly one CLASS compute() call per parameter set.
    - For mPk, the CLASS parameter 'P_k_max_1/Mpc' is set based on the provided
      k-grid and an estimate of h from the parameters to avoid range errors.
    - If classy is not installed, ImportError is raised with guidance.
    """
    require_classy(raise_if_missing=True)

    # Normalize and encapsulate request
    if observables is None:
        observables = ["TT", "TE", "EE", "mPk"]
    request = ObservablesRequest(
        observables=observables,
        lmax=lmax,
        lensed=lensed,
        k_values=k_values,
        z_values=z_values,
    )
    obs_set = request.normalized()

    want_cls = any(o in obs_set for o in ("TT", "TE", "EE", "PP"))
    want_pp = "PP" in obs_set
    want_mpk = "MPK" in obs_set  # normalized to upper

    # Prepare CLASS arguments without mutating caller's dict
    args = dict(extra_args) if isinstance(extra_args, dict) else {}

    output_parts: list[str] = []
    if want_cls:
        args.setdefault("modes", "s")
        # tCl for temperature; pCl for polarization (TE/EE). We include both to
        # keep code simple when any Cl requested.
        output_parts.extend(["tCl", "pCl"])
        # CLASS requires lCl to be computed when lensing is enabled for lensed Cls.
        # Include lCl whenever we request lensed Cls, regardless of whether PP is requested.
        if request.lensed or want_pp:
            output_parts.append("lCl")
        # Set basics for Cls
        if request.lmax is None:
            lmax_use = 2500
        else:
            lmax_use = int(request.lmax)
        args.setdefault("l_max_scalars", lmax_use)
        args.setdefault("lensing", "yes" if request.lensed else "no")
    else:
        lmax_use = None  # type: ignore

    if want_mpk:
        output_parts.append("mPk")
        # z grid
        if request.z_values is None:
            request.z_values = [0.0]
        # Ensure a list/np.ndarray for iteration
        if isinstance(request.z_values, (float, int)):
            request.z_values = [float(request.z_values)]
        # CLASS prefers z_pk as comma-separated
        z_str = ",".join(str(float(z)) for z in list(request.z_values))
        args.setdefault("z_pk", z_str)

        # k grid
        if request.k_values is None:
            # Reasonable default grid in h/Mpc
            request.k_values = np.logspace(-4, 1, 200)

        # Estimate h to set P_k_max_1/Mpc prior to compute
        # Try to read from params; otherwise use a conservative 0.7
        try:
            h_guess = params.h if hasattr(params, "h") else (params.H0 / 100.0)
        except Exception:
            h_guess = 0.7
        k_max_mpc = float(np.max(request.k_values)) * float(h_guess) * 1.2
        # Use the new CLASS key name (1/Mpc). If the environment requires a
        # different key (e.g., P_k_max_h/Mpc), users can override in extra_args.
        # Check both args and params.to_class() to avoid conflicts
        params_dict = params.to_class() if hasattr(params, "to_class") else {}
        if (
            "P_k_max_1/Mpc" not in args
            and "P_k_max_h/Mpc" not in args
            and "P_k_max_1/Mpc" not in params_dict
            and "P_k_max_h/Mpc" not in params_dict
        ):
            args["P_k_max_1/Mpc"] = k_max_mpc

    # Build the output flag string
    if not output_parts:
        # Nothing requested; return empty dict early
        return {}
    outputs_flag = build_outputs_flag(request.lensed, want_cls, want_pp, want_mpk)

    # Merge precedence: model -> request-args -> user extra_args
    model_args = params.to_class() if hasattr(params, "to_class") else {}
    request_args: Dict[str, Any] = {k: v for k, v in args.items()}
    # outputs handled separately via outputs_flag (not in request_args)
    merged_args = merge_class_args(
        model_args=model_args, yaml_extra_args=extra_args, request=request_args
    )

    # Compute once
    cosmo = compute_cosmology(params, extra_args=merged_args, outputs=outputs_flag)
    backend = ClassyBackend(cosmo)

    try:
        # Collect into ObservablesResult first, then map to dict for backward compatibility
        result_struct = ObservablesResult(ell=None, k=None, z=None, spectra={})

        if want_cls and lmax_use is not None:
            cls_dict = (
                backend.lensed_cl(lmax_use) if lensed else backend.raw_cl(lmax_use)
            )
            ell = np.arange(2, lmax_use + 1)
            result_struct.ell = ell

            # Only include spectra requested
            if "TT" in obs_set and "tt" in cls_dict:
                result_struct.spectra["tt"] = cls_dict["tt"][2 : lmax_use + 1]
            if "TE" in obs_set and "te" in cls_dict:
                result_struct.spectra["te"] = cls_dict["te"][2 : lmax_use + 1]
            if "EE" in obs_set and "ee" in cls_dict:
                result_struct.spectra["ee"] = cls_dict["ee"][2 : lmax_use + 1]
            if want_pp and "pp" in cls_dict:
                result_struct.spectra["pp"] = cls_dict["pp"][2 : lmax_use + 1]

        if want_mpk:
            # Ensure arrays
            assert request.k_values is not None and request.z_values is not None
            k_arr = np.asarray(request.k_values, dtype=float)
            z_arr = np.asarray(request.z_values, dtype=float)

            # CLASS uses k in 1/Mpc; convert from h/Mpc using h from cosmo
            h_val = backend.h()
            pk = np.empty((z_arr.size, k_arr.size), dtype=float)
            for iz, z in enumerate(z_arr):
                # Evaluate P(k,z) for each k
                pk[iz, :] = [
                    backend.pk(float(k * h_val), float(z)) * h_val**3 for k in k_arr
                ]

            result_struct.k = k_arr
            result_struct.z = z_arr
            result_struct.spectra["pk"] = pk

        # Back-compat dict assembly
        out: Dict[str, Any] = {}
        if result_struct.ell is not None:
            out["ell"] = result_struct.ell
        if result_struct.k is not None:
            out["k"] = result_struct.k
        if result_struct.z is not None:
            out["z"] = result_struct.z
        # Flatten spectra
        out.update({k: v for k, v in result_struct.spectra.items()})

        return out

    finally:
        backend.cleanup()
