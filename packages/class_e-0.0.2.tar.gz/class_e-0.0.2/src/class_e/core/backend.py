from __future__ import annotations

from typing import Any, Dict, Protocol


class Backend(Protocol):
    def lensed_cl(self, lmax: int) -> Dict[str, Any]: ...

    def raw_cl(self, lmax: int) -> Dict[str, Any]: ...

    def pk(self, k_in_mpc: float, z: float) -> float: ...

    def h(self) -> float: ...

    def cleanup(self) -> None: ...


class ClassyBackend:
    def __init__(self, cosmo: Any) -> None:
        self._cosmo = cosmo

    def lensed_cl(self, lmax: int) -> Dict[str, Any]:
        return self._cosmo.lensed_cl(lmax)

    def raw_cl(self, lmax: int) -> Dict[str, Any]:
        return self._cosmo.raw_cl(lmax)

    def pk(self, k_in_mpc: float, z: float) -> float:
        return float(self._cosmo.pk(k_in_mpc, z))

    def h(self) -> float:
        return float(self._cosmo.h())

    def cleanup(self) -> None:
        try:
            self._cosmo.struct_cleanup()
        finally:
            self._cosmo.empty()
