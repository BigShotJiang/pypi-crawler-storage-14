"""Dynamic Pydantic model factory for cosmological parameters.

This module creates Pydantic models dynamically from YAML configuration files,
allowing for flexible cosmological model definitions with automatic validation.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple, Type, Callable
from pathlib import Path
from pydantic import BaseModel, Field, create_model


def _parse_parameter_spec_ex(name: str, spec: Any) -> Tuple[Type, Any, bool]:
    """Parse a parameter specification into (type, Field, drop_flag).

    Parameters
    ----------
    name : str
        Parameter name
    spec : Any
        Parameter specification from YAML, can be:
        - list [min, max]: Simple bounds
        - dict with 'min', 'max', and optionally 'latex', 'alias', 'default', 'drop'

    Returns
    -------
    tuple
        (field_type, Field object with validation, drop_from_class)

    Examples
    --------
    >>> parse_parameter_spec("H0", [60.0, 80.0])
    (float, Field(gt=60.0, lt=80.0, ...), False)

    >>> parse_parameter_spec("omega_b", {"min": 0.02, "max": 0.025, "latex": r"\\omega_b"})
    (float, Field(gt=0.02, lt=0.025, description=r"\\omega_b", ...), False)

    >>> parse_parameter_spec("theta_i", {"min": 0.1, "max": 3.14, "drop": True})
    (float, Field(gt=0.1, lt=3.14, ...), True)
    """
    # Default values
    min_val, max_val = None, None
    default_val = None
    latex = ""
    alias = None
    description = ""
    drop_from_class = False

    # Parse specification
    if isinstance(spec, list) and len(spec) == 2:
        # Simple format: [min, max]
        min_val, max_val = float(spec[0]), float(spec[1])
        default_val = (min_val + max_val) / 2  # Default to midpoint
    elif isinstance(spec, dict):
        # Full format with additional metadata
        min_val = float(spec["min"]) if "min" in spec else None
        max_val = float(spec["max"]) if "max" in spec else None

        if "default" in spec:
            default_val = float(spec["default"])
        elif min_val is not None and max_val is not None:
            default_val = (min_val + max_val) / 2
        else:
            default_val = None

        latex = spec.get("latex", "")
        alias = spec.get("alias")
        drop_from_class = spec.get("drop", False)
        description = latex if latex else f"Cosmological parameter {name}"
    else:
        raise ValueError(f"Invalid parameter specification for {name}: {spec}")

    # Build Field kwargs
    field_kwargs = {
        "description": description,
    }

    if default_val is not None:
        field_kwargs["default"] = default_val
    else:
        # If no default, make it required
        field_kwargs["default"] = ...

    # Add bounds validation (use ge/le to allow boundary values)
    if min_val is not None:
        field_kwargs["ge"] = min_val
    if max_val is not None:
        field_kwargs["le"] = max_val

    # Add alias if specified
    if alias:
        field_kwargs["alias"] = alias

    # Create Field
    field = Field(**field_kwargs)

    return (float, field, drop_from_class)


def parse_parameter_spec(name: str, spec: Any) -> Tuple[Type, Any]:
    """Backward-compatible API: return (type, Field) only.

    Tests and external code expect parse_parameter_spec to return exactly two
    values. The drop flag is handled internally by create_cosmology.
    """
    t, f, _drop = _parse_parameter_spec_ex(name, spec)
    return t, f


def parse_derived_parameter(
    name: str, spec: Dict[str, Any], all_params: Dict[str, Any]
) -> Callable:
    """Parse a derived parameter specification and create a computed property.

    Parameters
    ----------
    name : str
        Derived parameter name
    spec : dict
        Specification with 'expression' or 'function' key
    all_params : dict
        All parameter names for validation

    Returns
    -------
    callable
        Function that computes the derived parameter

    Examples
    --------
    >>> spec = {"expression": "omega_b + omega_cdm", "latex": r"\\Omega_m"}
    >>> func = parse_derived_parameter("Omega_m", spec, {"omega_b": ..., "omega_cdm": ...})
    """
    if "expression" in spec:
        # Simple expression-based derivation
        expression = spec["expression"]
        latex = spec.get("latex", name)

        # Validate that all referenced parameters exist
        # Simple check: look for parameter names in expression
        for param in all_params:
            if param in expression:
                # Basic validation passed
                pass

        # Create a function that evaluates the expression with caching
        cache_attr = f"_cached_{name}"

        def derived_func(self) -> float:
            """Computed derived parameter with caching to avoid recursion."""
            # Check cache first
            if hasattr(self, cache_attr):
                return getattr(self, cache_attr)

            # Build local namespace with parameter values
            local_vars = {
                param: getattr(self, param) for param in all_params if param != name
            }

            # Try to include other derived parameters (for chaining)
            # Use property access which will compute them if needed
            if hasattr(self.__class__, "_derived_params"):
                for other_derived in self.__class__._derived_params:
                    if other_derived != name:
                        # Check if it's a property
                        prop = getattr(self.__class__, other_derived, None)
                        if isinstance(prop, property):
                            try:
                                # This will recursively compute if needed
                                local_vars[other_derived] = getattr(self, other_derived)
                            except (RecursionError, ValueError):
                                # Skip if circular dependency
                                pass

            # Add common functions
            local_vars.update(
                {
                    "sqrt": lambda x: x**0.5,
                    "log": __import__("math").log,
                    "log10": __import__("math").log10,
                    "exp": __import__("math").exp,
                    "abs": abs,
                    "min": min,
                    "max": max,
                }
            )
            try:
                result = eval(expression, {"__builtins__": {}}, local_vars)
                value = float(result)
                # Cache the result
                setattr(self, cache_attr, value)
                return value
            except Exception as e:
                raise ValueError(
                    f"Error evaluating derived parameter '{name}' "
                    f"with expression '{expression}': {e}"
                )

        derived_func.__name__ = name
        derived_func.__doc__ = f"Derived parameter: {expression}"
        if latex:
            derived_func.__annotations__["latex"] = latex

        return derived_func

    elif "function" in spec:
        # Function-based derivation (for complex calculations)
        func_code = spec["function"]
        latex = spec.get("latex", name)

        # Execute the function definition in a safe namespace
        namespace = {}
        try:
            exec(func_code, {"__builtins__": {}}, namespace)
            if name not in namespace:
                raise ValueError(
                    f"Function code for derived parameter '{name}' "
                    f"must define a function named '{name}'"
                )
            func = namespace[name]
        except Exception as e:
            raise ValueError(
                f"Error compiling function for derived parameter '{name}': {e}"
            )

        # Wrap the function to work as a method
        def derived_func(self) -> float:
            """Computed derived parameter."""
            return float(func(self))

        derived_func.__name__ = name
        if latex:
            derived_func.__annotations__["latex"] = latex

        return derived_func

    else:
        raise ValueError(
            f"Derived parameter '{name}' must have either 'expression' or 'function' key"
        )


def create_cosmology(
    yaml_data: Dict[str, Any],
    base_class: Optional[Type[BaseModel]] = None,
    model_name: str = "DynamicCosmologyParams",
    extra_class_params: Optional[Dict[str, Any]] = None,
) -> Type[BaseModel]:
    """Create a Pydantic model dynamically from YAML parameter specifications.

    Parameters
    ----------
    yaml_data : dict
        Loaded YAML configuration with 'parameters' section
    base_class : Type[BaseModel], optional
        Base class to inherit from (e.g., for shared methods)
    model_name : str
        Name for the generated model class
    extra_class_params : dict, optional
        Additional CLASS-specific parameters to add to to_class() output

    Returns
    -------
    Type[BaseModel]
        Dynamically created Pydantic model class with validation

    Examples
    --------
    >>> yaml_data = {
    ...     "parameters": {
    ...         "H0": [60.0, 80.0],
    ...         "omega_b": {"min": 0.02, "max": 0.025, "latex": r"\\omega_b"},
    ...         "f_ede": {"min": 0.0, "max": 0.15, "default": 0.0}
    ...     }
    ... }
    >>> Model = create_cosmology(yaml_data)
    >>> params = Model(H0=67.4, omega_b=0.022, f_ede=0.05)
    >>> params.H0
    67.4
    """
    if "parameters" not in yaml_data:
        raise ValueError("YAML data must contain 'parameters' section")

    parameters = yaml_data["parameters"]
    derived_params = yaml_data.get("derived", {})

    # Parse all parameters into Field definitions
    field_definitions = {}
    drop_params = set()  # Track parameters to exclude from to_class()
    for param_name, param_spec in parameters.items():
        field_type, field_def, should_drop = _parse_parameter_spec_ex(
            param_name, param_spec
        )
        field_definitions[param_name] = (field_type, field_def)
        if should_drop:
            drop_params.add(param_name)

    # Create the model with all fields
    model = create_model(
        model_name,
        __base__=base_class if base_class else BaseModel,
        **field_definitions,
    )

    # Add derived parameters as computed properties
    if derived_params:
        for derived_name, derived_spec in derived_params.items():
            derived_func = parse_derived_parameter(
                derived_name, derived_spec, parameters
            )

            # Create a property using Pydantic's computed_field decorator
            # We need to add it to the model dynamically
            prop = property(derived_func)
            setattr(model, derived_name, prop)

            # Store metadata for derived parameters
            if not hasattr(model, "_derived_params"):
                model._derived_params = {}
            model._derived_params[derived_name] = {
                "latex": derived_spec.get("latex", derived_name),
                "expression": derived_spec.get("expression"),
                "function": derived_spec.get("function"),
            }

    # Add custom methods
    def to_class(self) -> Dict[str, Any]:
        """Convert to CLASS parameter dictionary using alias names.

        Tests and legacy code expect aliases to be used for serialization. Any
        canonical name mapping will be handled at the point of CLASS invocation.

        Parameters marked with 'drop: True' in the YAML will be excluded from
        the output, allowing them to be used in derived parameters without being
        passed to CLASS.
        """
        class_params: Dict[str, Any] = self.model_dump(by_alias=True)

        # Remove parameters marked with drop=True
        for param_name in drop_params:
            # Remove both canonical name and alias if present
            class_params.pop(param_name, None)
            # Also check if there's an alias to remove
            field_info = self.model_fields.get(param_name)
            if field_info and field_info.alias:
                class_params.pop(field_info.alias, None)

        # Handle H0 -> h conversion if H0 exists
        if "H0" in class_params:
            class_params["h"] = class_params.pop("H0") / 100.0

        # Evaluate derived parameters and add to class_params
        if hasattr(self.__class__, "_derived_params"):
            for derived_name, derived_info in self.__class__._derived_params.items():
                expr = derived_info.get("expression")
                if expr:
                    try:
                        # Get instance values for evaluation
                        instance_dict = self.model_dump()
                        # Evaluate expression (lambda or string)
                        if isinstance(expr, str) and expr.startswith("lambda"):
                            # Parse and evaluate lambda with instance values
                            import re

                            # Extract lambda parameters (simple parsing for "lambda x, y: ...")
                            match = re.match(r"lambda\s+([^:]+):", expr)
                            if match:
                                param_names = [
                                    p.strip() for p in match.group(1).split(",")
                                ]
                                # Evaluate the lambda
                                func = eval(expr)
                                # Call with values from instance
                                args = [
                                    instance_dict[p]
                                    for p in param_names
                                    if p in instance_dict
                                ]
                                derived_value = func(*args)
                                class_params[derived_name] = derived_value
                    except Exception:
                        # Skip if evaluation fails
                        pass

        # Add extra CLASS parameters if specified
        if extra_class_params:
            class_params.update(extra_class_params)

        return class_params

    @classmethod
    def get_bounds(cls) -> Dict[str, Tuple[float, float]]:
        """Get parameter bounds as a dictionary."""
        bounds = {}
        for field_name, field_info in cls.model_fields.items():
            # Extract bounds from Field constraints
            ge_val = None
            le_val = None

            # Check metadata for constraints
            if field_info.metadata:
                for constraint in field_info.metadata:
                    if hasattr(constraint, "ge"):
                        ge_val = constraint.ge
                    if hasattr(constraint, "le"):
                        le_val = constraint.le

            if ge_val is not None and le_val is not None:
                bounds[field_name] = (ge_val, le_val)

        return bounds

    @classmethod
    def get_latex_names(cls) -> Dict[str, str]:
        """Get LaTeX representation of parameter names."""
        latex_names = {}
        # Regular parameters
        for field_name, field_info in cls.model_fields.items():
            description = field_info.description
            if description and description != f"Cosmological parameter {field_name}":
                latex_names[field_name] = description
            else:
                latex_names[field_name] = field_name

        # Derived parameters
        if hasattr(cls, "_derived_params"):
            for derived_name, derived_info in cls._derived_params.items():
                latex_names[derived_name] = derived_info["latex"]

        return latex_names

    @classmethod
    def get_derived_parameters(cls) -> Dict[str, Dict[str, Any]]:
        """Get information about derived parameters."""
        if hasattr(cls, "_derived_params"):
            return cls._derived_params.copy()
        return {}

    # Attach methods to the model
    model.to_class = to_class
    model.get_bounds = get_bounds
    model.get_latex_names = get_latex_names
    model.get_derived = get_derived_parameters

    # Add class docstring
    param_list = ", ".join(parameters.keys())
    derived_list = ", ".join(derived_params.keys()) if derived_params else "none"
    model.__doc__ = (
        f"Dynamically created cosmology model with parameters: {param_list}\n"
        f"Derived parameters: {derived_list}\n\n"
        f"This model was generated from a YAML configuration file and includes\n"
        f"automatic validation of all parameter bounds."
    )

    return model


def load_cosmology_from_yaml(
    yaml_path: str | Path,
    model_name: Optional[str] = None,
    extra_class_params: Optional[Dict[str, Any]] = None,
) -> Type[BaseModel]:
    """Load YAML and create a cosmology model in one step.

    Parameters
    ----------
    yaml_path : str or Path
        Path to YAML configuration file
    model_name : str, optional
        Name for the model (defaults to output.model_name from YAML or filename)
    extra_class_params : dict, optional
        Additional CLASS-specific parameters

    Returns
    -------
    Type[BaseModel]
        Pydantic model class with validation

    Examples
    --------
    >>> LCDMModel = load_cosmology_from_yaml("configs/lcdm.yaml")
    >>> params = LCDMModel(H0=67.4, omega_b=0.022, omega_cdm=0.12)

    >>> EDEModel = load_cosmology_from_yaml("configs/ede.yaml", model_name="EDEParams")
    >>> params = EDEModel(H0=70.0, omega_b=0.024, f_ede=0.08, log10_z_c=3.5)
    """
    from class_e.utils.yml import load_yaml

    yaml_path = Path(yaml_path)
    yaml_data = load_yaml(yaml_path)

    # Determine model name
    if model_name is None:
        # Try to get from YAML output section
        model_name = yaml_data.get("output", {}).get("model_name")
        if model_name:
            model_name = f"{model_name.upper()}Params"
        else:
            # Use filename
            model_name = f"{yaml_path.stem.title()}Params"

    # Get extra CLASS parameters from YAML if not provided
    if extra_class_params is None and "theory" in yaml_data:
        extra_class_params = (
            yaml_data.get("theory", {}).get("classy", {}).get("extra_args", {})
        )

    return create_cosmology(
        yaml_data, model_name=model_name, extra_class_params=extra_class_params
    )


# Example usage and testing
if __name__ == "__main__":
    from pathlib import Path

    # Try to load example.yaml
    example_path = Path(__file__).resolve().parents[3] / "example.yaml"

    if example_path.exists():
        print("=" * 80)
        print("DYNAMIC COSMOLOGY MODEL CREATION DEMO")
        print("=" * 80)

        # Create model from YAML
        print(f"\n📄 Loading configuration from: {example_path}")
        CosmologyModel = load_cosmology_from_yaml(example_path)

        print(f"\n✅ Created model: {CosmologyModel.__name__}")
        print(f"📋 Parameters: {list(CosmologyModel.model_fields.keys())}")

        # Show parameter details
        print("\n📊 Parameter Specifications:")
        for nm, field_info in CosmologyModel.model_fields.items():
            default = (
                field_info.default if field_info.default is not ... else "Required"
            )
            print(f"  • {nm:15s} = {default}")

        # Create an instance with default values
        print("\n🔧 Creating instance with defaults:")
        try:
            params = CosmologyModel()
            print("  ✅ Success! Sample values:")
            for nm in list(CosmologyModel.model_fields.keys())[:5]:
                print(f"     {nm}: {getattr(params, nm)}")

            # Test to_class conversion
            print("\n🔄 Converting to CLASS parameters:")
            class_params = params.to_class()
            print(f"  Keys: {list(class_params.keys())[:8]}...")

            # Test validation
            print("\n🛡️  Testing validation (trying invalid value):")
            try:
                _ = CosmologyModel(H0=200.0)  # Should fail
            except Exception as err:
                print(f"  ✅ Validation caught error: {type(err).__name__}")
                print(f"     Message: {str(err)[:80]}...")

        except Exception:
            print("  ⚠️  Some parameters are required")
            print("     Try: CosmologyModel(H0=67.4, omega_b=0.022, ...)")

        print("\n" + "=" * 80)
    else:
        print(f"❌ Example file not found: {example_path}")
        print("   Usage: python cosmo_factory.py")
