<p align="center">
  <img src="docs/assets/logo-gh.png" alt="class-e Logo" width="400"/>  
</p>

<center> 
  <i>
    A fast & user-friendly emulation framework for the Boltzmann solver <a href="http://class-code.net/"><code>CLASS</code></a> and its extensions.
  </i>
</center>

[![image](https://img.shields.io/pypi/v/class-e.svg)](https://pypi.python.org/pypi/class-e)
[![image](https://img.shields.io/badge/arXiv-260X.0XXXX%20-red.svg)](https://arxiv.org/abs/260X.0XXXX)
[![image](http://img.shields.io/badge/license-MIT-blue.svg?style=flat)](https://github.com/rcalderonb6/class-e/blob/main/LICENSE) 
[![Docs](https://badgen.net/badge/icon/Documentation?icon=https://cdn.jsdelivr.net/npm/simple-icons@v13/icons/gitbook.svg&label)](https://rcalderonb6.github.io/class-e/)
[![Source Code](https://badgen.net/badge/icon/Source%20Code?icon=github&label)](https://github.com/rcalderonb6/class-e/tree/main)
