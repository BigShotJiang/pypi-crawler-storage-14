# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CopyBaselinePolicyGroupRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'description': 'str',
        'group_name': 'str',
        'group_id': 'str'
    }

    attribute_map = {
        'description': 'description',
        'group_name': 'group_name',
        'group_id': 'group_id'
    }

    def __init__(self, description=None, group_name=None, group_id=None):
        r"""CopyBaselinePolicyGroupRequestBody

        The model defined in huaweicloud sdk

        :param description: 新策略组描述信息
        :type description: str
        :param group_name: 新策略组名称
        :type group_name: str
        :param group_id: 被复制策略组id
        :type group_id: str
        """
        
        

        self._description = None
        self._group_name = None
        self._group_id = None
        self.discriminator = None

        if description is not None:
            self.description = description
        self.group_name = group_name
        self.group_id = group_id

    @property
    def description(self):
        r"""Gets the description of this CopyBaselinePolicyGroupRequestBody.

        新策略组描述信息

        :return: The description of this CopyBaselinePolicyGroupRequestBody.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this CopyBaselinePolicyGroupRequestBody.

        新策略组描述信息

        :param description: The description of this CopyBaselinePolicyGroupRequestBody.
        :type description: str
        """
        self._description = description

    @property
    def group_name(self):
        r"""Gets the group_name of this CopyBaselinePolicyGroupRequestBody.

        新策略组名称

        :return: The group_name of this CopyBaselinePolicyGroupRequestBody.
        :rtype: str
        """
        return self._group_name

    @group_name.setter
    def group_name(self, group_name):
        r"""Sets the group_name of this CopyBaselinePolicyGroupRequestBody.

        新策略组名称

        :param group_name: The group_name of this CopyBaselinePolicyGroupRequestBody.
        :type group_name: str
        """
        self._group_name = group_name

    @property
    def group_id(self):
        r"""Gets the group_id of this CopyBaselinePolicyGroupRequestBody.

        被复制策略组id

        :return: The group_id of this CopyBaselinePolicyGroupRequestBody.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this CopyBaselinePolicyGroupRequestBody.

        被复制策略组id

        :param group_id: The group_id of this CopyBaselinePolicyGroupRequestBody.
        :type group_id: str
        """
        self._group_id = group_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CopyBaselinePolicyGroupRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
