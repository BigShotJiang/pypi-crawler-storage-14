# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CveInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'cve_id': 'str',
        'cvss_score': 'float',
        'publish_time': 'int',
        'description': 'str'
    }

    attribute_map = {
        'cve_id': 'cve_id',
        'cvss_score': 'cvss_score',
        'publish_time': 'publish_time',
        'description': 'description'
    }

    def __init__(self, cve_id=None, cvss_score=None, publish_time=None, description=None):
        r"""CveInfo

        The model defined in huaweicloud sdk

        :param cve_id: **参数解释** CVE id **取值范围** 字符长度0-128位 
        :type cve_id: str
        :param cvss_score: **参数解释** CVSS分数 **取值范围** 取值0-100 
        :type cvss_score: float
        :param publish_time: **参数解释** CVE公布时间，时间单位：毫秒（ms） **取值范围** 取值0-3857960855552
        :type publish_time: int
        :param description: **参数解释** CVE描述 **取值范围** 字符长度0-256位
        :type description: str
        """
        
        

        self._cve_id = None
        self._cvss_score = None
        self._publish_time = None
        self._description = None
        self.discriminator = None

        if cve_id is not None:
            self.cve_id = cve_id
        if cvss_score is not None:
            self.cvss_score = cvss_score
        if publish_time is not None:
            self.publish_time = publish_time
        if description is not None:
            self.description = description

    @property
    def cve_id(self):
        r"""Gets the cve_id of this CveInfo.

        **参数解释** CVE id **取值范围** 字符长度0-128位 

        :return: The cve_id of this CveInfo.
        :rtype: str
        """
        return self._cve_id

    @cve_id.setter
    def cve_id(self, cve_id):
        r"""Sets the cve_id of this CveInfo.

        **参数解释** CVE id **取值范围** 字符长度0-128位 

        :param cve_id: The cve_id of this CveInfo.
        :type cve_id: str
        """
        self._cve_id = cve_id

    @property
    def cvss_score(self):
        r"""Gets the cvss_score of this CveInfo.

        **参数解释** CVSS分数 **取值范围** 取值0-100 

        :return: The cvss_score of this CveInfo.
        :rtype: float
        """
        return self._cvss_score

    @cvss_score.setter
    def cvss_score(self, cvss_score):
        r"""Sets the cvss_score of this CveInfo.

        **参数解释** CVSS分数 **取值范围** 取值0-100 

        :param cvss_score: The cvss_score of this CveInfo.
        :type cvss_score: float
        """
        self._cvss_score = cvss_score

    @property
    def publish_time(self):
        r"""Gets the publish_time of this CveInfo.

        **参数解释** CVE公布时间，时间单位：毫秒（ms） **取值范围** 取值0-3857960855552

        :return: The publish_time of this CveInfo.
        :rtype: int
        """
        return self._publish_time

    @publish_time.setter
    def publish_time(self, publish_time):
        r"""Sets the publish_time of this CveInfo.

        **参数解释** CVE公布时间，时间单位：毫秒（ms） **取值范围** 取值0-3857960855552

        :param publish_time: The publish_time of this CveInfo.
        :type publish_time: int
        """
        self._publish_time = publish_time

    @property
    def description(self):
        r"""Gets the description of this CveInfo.

        **参数解释** CVE描述 **取值范围** 字符长度0-256位

        :return: The description of this CveInfo.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this CveInfo.

        **参数解释** CVE描述 **取值范围** 字符长度0-256位

        :param description: The description of this CveInfo.
        :type description: str
        """
        self._description = description

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CveInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
