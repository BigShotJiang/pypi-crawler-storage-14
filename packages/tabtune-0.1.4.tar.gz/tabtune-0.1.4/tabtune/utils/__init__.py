"""Utility helpers for environment detection and other shared helpers."""

from .env import is_colab

__all__ = ["is_colab"]

