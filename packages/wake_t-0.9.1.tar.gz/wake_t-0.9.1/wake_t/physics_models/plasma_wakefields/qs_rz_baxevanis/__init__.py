from .wakefield import Quasistatic2DWakefield

__all__ = ["Quasistatic2DWakefield"]
