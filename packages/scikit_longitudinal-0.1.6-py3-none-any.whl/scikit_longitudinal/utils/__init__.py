"""Utility helpers for Scikit-longitudinal"""
