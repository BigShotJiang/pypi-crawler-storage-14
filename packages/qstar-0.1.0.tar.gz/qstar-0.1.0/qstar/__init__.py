"""qstar package."""

__version__ = "0.1.0"

import positional_embeddings