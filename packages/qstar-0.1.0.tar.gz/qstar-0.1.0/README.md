# qstar 

blocks.

```bash
uv add qstar 
```

