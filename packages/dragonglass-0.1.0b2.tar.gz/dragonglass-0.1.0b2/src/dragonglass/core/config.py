from pathlib import Path
from typing import Literal, Type, Tuple

from pydantic import Field, BaseModel, AliasChoices
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
    PydanticBaseSettingsSource,
    TomlConfigSettingsSource,
)
from platformdirs import user_config_dir, user_data_dir, user_cache_dir

APP_NAME = "dg"
CONFIG_FILE_NAME = "config.toml"
DB_FILE_NAME = "dg.db"


class GeminiSettings(BaseModel):
    """Settings for the Gemini API."""

    api_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("google_api_key", "GOOGLE_API_KEY", "api_key")
    )
    default_model: str = "gemini-1.5-flash"
    temperature: float = Field(0.7, ge=0.0, le=1.0)
    max_tokens: int | None = Field(None, ge=1)
    top_p: float = Field(1.0, ge=0.0, le=1.0)

    # Safety settings - simplified for initial implementation
    # In a real app, this would be more granular
    safety_settings: Literal["BLOCK_NONE", "HARM_ONLY"] = "BLOCK_NONE"

    # Grounding for Google Search
    grounding_enabled: bool = False


class AppSettings(BaseSettings):
    """Main application settings."""
    # XDG Base Directory Specification paths
    config_dir: Path = Field(default_factory=lambda: Path(user_config_dir(APP_NAME)))
    data_dir: Path = Field(default_factory=lambda: Path(user_data_dir(APP_NAME)))
    cache_dir: Path = Field(default_factory=lambda: Path(user_cache_dir(APP_NAME)))

    # Nested settings for Gemini
    gemini: GeminiSettings

    model_config = SettingsConfigDict(
        toml_file=Path(__file__).parents[3] / CONFIG_FILE_NAME,
        extra="ignore",
        env_prefix="DG_",
        env_nested_delimiter="__",
    )

    @classmethod
    def settings_customise_sources(
            cls,
            settings_cls: Type[BaseSettings],
            init_settings: PydanticBaseSettingsSource,
            env_settings: PydanticBaseSettingsSource,
            dotenv_settings: PydanticBaseSettingsSource,
            file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            env_settings,
            TomlConfigSettingsSource(settings_cls),
            dotenv_settings,
            file_secret_settings,
        )

    def ensure_dirs(self):
        """Ensures that XDG directories exist."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)


# Global settings instance
settings = AppSettings()
settings.ensure_dirs()

