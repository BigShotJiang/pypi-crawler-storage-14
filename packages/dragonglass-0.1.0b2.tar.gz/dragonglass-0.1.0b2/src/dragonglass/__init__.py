from pydantic_core._pydantic_core import ValidationError

try:
    from dragonglass.core.config import settings
except ValidationError as e:
    print("""
        Gemini API key not found. Set the GOOGLE_API_KEY environment
        variable or configure it in ~/.config/dg/config.toml

        # config.toml
        [gemini]
        google_api_key=""
        default_model=""
        temperature=0.7
        top_p=1.0
        safe_settings="BLOCK_NONE"
        grounding_enabled=true
    """)
    exit(1)
