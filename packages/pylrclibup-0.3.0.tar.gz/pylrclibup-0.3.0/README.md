# pylrclibup

一个用于将本地 MP3/LRC 歌曲批量上传到 **LRCLIB.net** 的全自动增强工具。
比官方工具更强、更稳定、更智能——覆盖元数据解析、模糊匹配、本地/外部歌词整合、脚本自动化、网络重试、空目录清理与纯音乐识别等整套流程。

---

# ✨ 功能亮点

## 🎵 1. 自动从 MP3 读取真实 metadata

- 支持 ID3v2.3 / 2.4
- 自动读取：
  - `title`（曲名）
  - `artist`（艺人，多艺人自动拆分）
  - `album`（专辑名）
  - `duration`（时长）
- 完全不依赖文件名，提高准确性

## 🔍 2. 智能匹配本地 LRC（递归扫描 + 宽松模糊规则）

- 提取 LRC 文件名的结构：`Artist - Title.lrc`
- 多艺人匹配仅需 **一个艺人命中** 即可
- 曲名 normalize 后严格一致（避免误匹配）
- 自动处理以下分隔符：`,` `/` `;` `、` `&` `x` `×` `feat.` `featuring`
- 若匹配到多个 LRC → 自动进入交互选择模式
- 支持手动指定歌词文件路径

## 🧹 3. 高级 LRC 标准化处理

### 自动清理：
- **删除歌词头部**：第一个时间戳之前的所有内容
- **删除中文翻译行**：连续相同时间戳的中文行
- **Credit 字段移除**：作词/作曲/编曲/录音/混音/母带/制作/监制/和声/配唱等
- 支持 credit 的各种格式变体（全角/半角冒号等）

### 多语言支持：
- Unicode 规范化（NFKC）
- 西里尔字母统一（俄语/乌克兰语等）
- 全角标点转换
- 零宽字符清理

## 🎼 4. 自动识别纯音乐

- 检测文本："纯音乐，请欣赏" 等常见表达
- 或 LRC 内容为空
- 或用户手动选择
- 自动上传为空歌词（instrumental）

## 🌐 5. 双查询机制（内部 + 外部）

- **`/api/get-cached`** → 仅查询 LRCLIB 内部数据库（0 外部请求）
- **`/api/get`** → 触发外部源抓取（Genius/Musixmatch 等）
- 智能判断：
  - 歌词是否已存在
  - 外部版本是否优于本地版本
  - 支持用户选择使用哪个版本

## 🚀 6. 完整的上传流程（自实现 PoW）

- **自定义 PoW 求解器**（完全无外部依赖）
- 自动获取 challenge → 计算 nonce → 生成 publish token
- SHA-256 哈希验证
- 最大化降低网络失败影响

## 🔁 7. 智能重试机制

对网络不稳定环境特别优化：
- 所有 API 调用自动重试（最大 5 次）
- 5xx 错误自动重试，4xx 错误立即停止
- 404 特殊处理（视为无结果）
- 可通过环境变量自定义重试次数

## 🖱 9. CLI 友好交互

- 单首文件上传
- 所有操作可交互式确认
- `--yes` 模式全自动
- `--dry-run` 不上传，不移动，全面预览
- `-p/--parse` LRC 标准化模式

---

# 📥 安装

## PyPI 版本

```bash
pip install pylrclibup
```

## 本地开发模式

```bash
git clone https://github.com/yourusername/pylrclibup.git
cd pylrclibup
pip install -e .
```

---

# 🧭 使用示例

## 1. 快速开始（原地模式）

```bash
cd /path/to/music
pylrclibup
```

- 递归扫描当前目录下所有 MP3
- 查找匹配的 LRC 文件
- 上传成功后文件保持原地
- 适用于只上传不整理的场景

---

## 2. -d / --default 默认模式（LRC 跟随 MP3）

```bash
pylrclibup -d "/path/to/tracks" "/path/to/lyrics"
```

**行为**：
- 按交互模式进行匹配与上传
- MP3 文件保持原地不动
- LRC 文件移动到 MP3 所在目录并重命名匹配
- 不清理空目录

**使用场景**：
- 从下载目录整理歌词到音乐库
- 保持 MP3 文件结构不变

---

## 3. -m / --match 匹配模式（歌词跟随歌曲）

### 3.1 无参数 + -m（歌词跟随，歌曲不动）

```bash
cd /music
pylrclibup -m
```

**行为**：
- MP3 保持原地
- LRC 移动到 MP3 目录并重命名匹配

### 3.2 指定输出 + -m（统一输出）

```bash
pylrclibup --tracks "/path/to/track/input" --lrc "/path/to/lrc/input" --done-tracks "/output" -m
```

**行为**：
- MP3 和 LRC 都移动到 `/output`
- LRC 重命名为与 MP3 相同的文件名

---

## 4. 普通模式（分别输出）

```bash
pylrclibup \
  --tracks "/music/input" \
  --lrc "/lyrics/input" \
  --done-tracks "/music/output" \
  --done-lrc "/lyrics/output"
```

**行为**：
- MP3 → `/music/output`
- LRC → `/lyrics/output`
- 自动清理空目录

---

## 5. 单首处理（即将遗弃）

```bash
pylrclibup --single "Lost & Found.mp3"
```

---

## 6. 预览模式（不上传不移动）

```bash
pylrclibup --dry-run
```

---

## 7. 全自动模式（即将遗弃）

```bash
pylrclibup --yes
```

---

## 8. LRC 标准化工具

```bash
# 单个文件
pylrclibup -p "song.lrc"

# 批量处理
pylrclibup -p "/path/to/lyrics/"
```

---

# ⚙️ 环境变量支持

所有 CLI 参数都可通过环境变量控制：

```bash
export PYLRCLIBUP_TRACKS_DIR="/data/mp3"
export PYLRCLIBUP_LRC_DIR="/data/lrc"
export PYLRCLIBUP_DONE_TRACKS_DIR="/data/handled_mp3"
export PYLRCLIBUP_DONE_LRC_DIR="/data/handled_lrc"
export PYLRCLIBUP_PREVIEW_LINES=8
export PYLRCLIBUP_MAX_HTTP_RETRIES=5
export PYLRCLIBUP_USER_AGENT="MyApp/1.0"

pylrclibup
```

**优先级**：CLI 参数 > 环境变量 > 默认值

---

# 📋 完整 CLI 参数

```
pylrclibup [OPTIONS]

选项：
  --tracks PATH           歌曲文件输入目录（默认：当前目录）
  --lrc PATH              LRC 文件输入目录（默认：当前目录）
  --done-tracks PATH      处理后歌曲移动目录（默认：与 --tracks 相同）
  --done-lrc PATH         处理后 LRC 移动目录（默认：与 --lrc 相同）

  -d, --default TRACKS LRC
                          默认模式：MP3 不动，LRC 跟随 MP3

  -m, --match             匹配模式：LRC 跟随歌曲（重命名为相同文件名）

  -p, --parse PATH        LRC 标准化模式（单个文件或目录）

  --single FILE           只处理指定文件
  --yes                   全自动模式，不询问确认
  --dry-run               预览模式，不上传不移动

  --preview-lines N       预览歌词显示行数（默认：10）
```

---

# 🔧 高级用法

## 处理递归子目录

```bash
# 目录结构：
# /music/
#   artist1/
#     album1/
#       01.mp3
#   artist2/
#     02.mp3

cd /music
pylrclibup
```

**原地模式**：所有 MP3 保持在各自目录
**-m 模式**：LRC 移动到各 MP3 所在目录

---

## 手动指定歌词文件

当自动匹配失败时：

```
未找到本地 LRC，选择 [s] 跳过该歌曲 / [m] 手动指定歌词文件 / [i] 上传空歌词标记为纯音乐 / [q] 退出程序:
```

选择 `m` 后，可输入绝对/相对路径：
- 支持引号（单引号/双引号）
- 支持 `~` 展开
- 支持相对路径（基于当前工作目录）

---

# 🎯 使用场景对照

| 场景 | 命令 | MP3 行为 | LRC 行为 |
|------|------|----------|----------|
| 只上传不整理 | `pylrclibup` | 原地 | 原地 |
| 整理歌词到音乐库 | `pylrclibup -d /music /downloads` | 原地 | 移动并重命名 |
| 歌词跟随歌曲（原地） | `pylrclibup -m` | 原地 | 移动并重命名 |
| 统一输出目录 | `pylrclibup --done-tracks /out -m` | 移动 | 移动并重命名 |
| 分别整理 | `pylrclibup --done-tracks /a --done-lrc /b` | 移动到 /a | 移动到 /b |
| 标准化 LRC | `pylrclibup -p /lyrics` | N/A | 原地清理 |

---

# 📄 License

MIT License

---

# 🤝 贡献

欢迎提交 Issue 和 Pull Request！