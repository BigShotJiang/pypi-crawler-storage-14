"""
REROUTE CLI Module

Command-line interface for REROUTE framework.
"""

from reroute.cli.main import cli

__all__ = ["cli"]
