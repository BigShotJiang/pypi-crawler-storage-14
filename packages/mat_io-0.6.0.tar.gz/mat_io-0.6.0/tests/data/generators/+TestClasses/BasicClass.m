classdef BasicClass
    properties
        a;
        b;
        c;
    end
end
