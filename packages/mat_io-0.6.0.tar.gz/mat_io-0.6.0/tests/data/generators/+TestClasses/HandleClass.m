classdef HandleClass < handle
    properties
        a = 10
    end
end
