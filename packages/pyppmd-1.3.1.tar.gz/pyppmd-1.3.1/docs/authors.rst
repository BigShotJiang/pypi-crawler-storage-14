:tocdepth: 2

.. _authors:

Authors
=======

``pyppmd`` is written and maintained by Hiroshi Miura <miurahr@linux.com>
Some part of ``pyppmd`` code are borrowed from ``pyzstd`` written by Ma Lin.

Contributors, listed alphabetically, are:

- Sarthak Pati
    macOS compilation
- T Yamada
    bug on race conditions on PPMd Variant I