Security Policy
===============

Supported Versions
------------------

Only recent version of pyppmd are currently being supported with security updates.

+---------+--------------------+
| Version | Status             |
+=========+====================+
| 1.0.x   | Development        |
+---------+--------------------+
| < 1.0   | not supported      |
+---------+--------------------+

Reporting a Vulnerability
-------------------------

Please disclose security vulnerabilities privately at miurahr@linux.com
