API documentation
=================

.. autosummary::
   :toctree: _generated
   :recursive:

   pyg90alarm
