"""
Contains various definitions for G90 devices (sensors etc.)
"""
