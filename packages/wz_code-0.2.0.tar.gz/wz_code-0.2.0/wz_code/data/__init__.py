"""Data module for WZ classifications."""
