"""Utility functions for the wz-code package."""

# Stub for now - will implement after data generation
