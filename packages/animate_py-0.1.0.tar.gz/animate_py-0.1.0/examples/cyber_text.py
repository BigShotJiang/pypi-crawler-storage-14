#!/usr/bin/env python3
"""CyberText animation example."""

from animate import play
from animate.animations import CyberText


def main() -> None:
    """Run CyberText animation examples."""
    print("Example 1: CyberText with 'CYBER' - Play once")
    play(CyberText("CYBERPUNK"), loop=True)

    # print("\nExample 2: CyberText with 'HACK' - Loop for 5 seconds")
    # play(CyberText("HACK"), loop=True, timeout=5)

    # print("\nExample 3: CyberText with 'NEO' - Repeat 3 times")
    # play(CyberText("NEO"), repeat_count=3)

    # print("\nExample 4: CyberText with 'CODE' - Custom FPS (2 FPS - slower)")
    # play(CyberText("CODE"), repeat_count=2, fps=2)


if __name__ == "__main__":
    main()
