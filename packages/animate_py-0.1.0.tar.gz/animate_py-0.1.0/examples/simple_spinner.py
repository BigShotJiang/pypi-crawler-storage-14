#!/usr/bin/env python3
"""Animation examples."""

from animate import play
from animate.animations import PlanetEarth, Spinner


def main() -> None:
    """Run animation examples."""
    print("Example 1: Spinner - Play once")
    play(Spinner())

    print("\nExample 2: Spinner - Loop for 5 seconds")
    play(Spinner(), loop=True, timeout=5)

    print("\nExample 3: Spinner - Repeat 3 times")
    play(Spinner(), repeat_count=3)

    print("\nExample 4: Spinner - Custom FPS (5 FPS)")
    play(Spinner(), repeat_count=2, fps=5)

    print("\nExample 5: Planet Earth - Rotating")
    play(PlanetEarth(), repeat_count=2)

    print("\nExample 6: Planet Earth - Loop for 3 seconds")
    play(PlanetEarth(), loop=True, timeout=3)


if __name__ == "__main__":
    main()
