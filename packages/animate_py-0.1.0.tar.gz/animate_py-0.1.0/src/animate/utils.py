"""Utility functions for terminal animation."""

import os


def clear_screen() -> None:
    """Clear the terminal screen."""
    # Use os.system for cross-platform reliability
    os.system("clear" if os.name != "nt" else "cls")


def get_terminal_size() -> tuple[int, int]:
    """Get terminal width and height.

    Returns:
        Tuple of (width, height) in characters.
    """
    try:
        size = os.get_terminal_size()
    except OSError:
        size = os.terminal_size((80, 24))
    return (size.columns, size.lines)
