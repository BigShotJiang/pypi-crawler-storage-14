"""Rotating planet Earth animation."""

from animate.animations.base import BaseAnimation


class PlanetEarth(BaseAnimation):
    """Rotating planet Earth animation with detailed circular ASCII globe."""

    def __init__(self) -> None:
        """Initialize the planet Earth animation."""
        # ASCII art frames showing Earth rotating with proper circular globe
        # Detailed representation with continent outlines
        self._frames = [
            # Frame 1 - Americas visible
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | ~~~  @@ |                 \n"
            "                | ~~~~  @@@@ |                \n"
            "               | ~~~~~   @@@@@|               \n"
            "               | ~~~~    @@@@@ |              \n"
            "               | ~~~    @@@@@@ |              \n"
            "                | ~~     @@@@@@ |             \n"
            "                | ~      @@@@@@|              \n"
            "                 | ~~~    @@@@|               \n"
            "                  \\  ~~~~  @ /                \n"
            "                    '===='                    ",
            # Frame 2 - Americas rotating
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | ~~~~ @@@ |                 \n"
            "                | ~~~~~~ @@@@ |                \n"
            "               | ~~~~~~~  @@@@|               \n"
            "               | ~~~     @@@@@  |             \n"
            "               | ~~     @@@@@@  |             \n"
            "                | ~      @@@@@@|              \n"
            "                | ~~~~~   @@@@~ |             \n"
            "                 | ~~~~~ @@@ ~|               \n"
            "                  \\  ~~ @@  ~ /               \n"
            "                    '===='                    ",
            # Frame 3 - Africa/Europe visible
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | ~  @@@@@@ |                \n"
            "                | ~~ @@@@@@@ |                \n"
            "               | ~ @@@@@@@@@ |               \n"
            "               | ~@@@@@@@@@@ |                \n"
            "               | @@@@@@@@@~~ |                \n"
            "                | @@@@@@@~~ ~|                \n"
            "                | @@@@~~ ~~~ |                \n"
            "                 | ~@~~ ~~~~ |               \n"
            "                  \\ ~~~  ~~~ /                \n"
            "                    '===='                    ",
            # Frame 4 - Europe/Asia visible
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | @@@@@@@@ ~|                \n"
            "                | @@@@@@@@@~~ |               \n"
            "               | @@@@@@@@@@~~ |              \n"
            "               |@@@@@@@@@~~~  |               \n"
            "               |@@@@@@@~~~~~  |               \n"
            "                |@@@@~~~~~~~  |               \n"
            "                | @@~~~~~~~   |               \n"
            "                 | ~~~~~~~  ~|                \n"
            "                  \\ ~~~~~  ~ /                \n"
            "                    '===='                    ",
            # Frame 5 - Asia/Pacific visible
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 |@@@@@~~~~~ |                \n"
            "                |@@@@@~~~~~~ |                \n"
            "               |@@@@@~~~~~~~  |              \n"
            "               |@@@~~~~~~~~~ |                \n"
            "               |@@~~~~~~~~~  |                \n"
            "                |~~~~~~~~~    |                \n"
            "                |~~~~~~~~     |               \n"
            "                 |~~~~~~~   ~~|               \n"
            "                  \\ ~~~~ ~@@ /                \n"
            "                    '===='                    ",
            # Frame 6 - Pacific visible
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | ~~~~~~~~@ |                \n"
            "                | ~~~~~ @@@@ |                \n"
            "               | ~~~~  @@@@@@ |              \n"
            "               | ~~~  @@@@@@~ |               \n"
            "               | ~~  @@@@@~~  |               \n"
            "                | ~  @@@~~~   |               \n"
            "                | ~  @@~~~~   |               \n"
            "                 | ~ @~~~~    |               \n"
            "                  \\ ~ ~~~   ~ /               \n"
            "                    '===='                    ",
            # Frame 7 - Americas returning
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | @@@  ~~~~ |                \n"
            "                | @@@@@  ~~~ |                \n"
            "               | @@@@@@~ ~~~ |              \n"
            "               | @@@@@~~ ~~~ |               \n"
            "               | @@@~~~ ~~~~ |               \n"
            "                | ~~~~~~  ~@@|               \n"
            "                | ~~~~~~~ @@|                \n"
            "                 | ~~~~~~ @@ |               \n"
            "                  \\ ~~~  @@~ /                \n"
            "                    '===='                    ",
            # Frame 8 - Back to Americas
            "                    .===.                    \n"
            "                  /       \\                  \n"
            "                 | ~~~  @@ |                 \n"
            "                | ~~~~  @@@@ |                \n"
            "               | ~~~~~   @@@@@|               \n"
            "               | ~~~~    @@@@@ |              \n"
            "               | ~~~    @@@@@@ |              \n"
            "                | ~~     @@@@@@ |             \n"
            "                | ~      @@@@@@|              \n"
            "                 | ~~~    @@@@|               \n"
            "                  \\  ~~~~  @ /                \n"
            "                    '===='                    ",
        ]

    def get_frames(self) -> list[str]:
        """Get planet Earth animation frames.

        Returns:
            List of ASCII art frames showing rotating Earth with detailed map.
        """
        return self._frames

    def get_fps(self) -> float:
        """Get frames per second.

        Returns:
            1.5 FPS for smooth, slow rotation effect.
        """
        return 1.5
