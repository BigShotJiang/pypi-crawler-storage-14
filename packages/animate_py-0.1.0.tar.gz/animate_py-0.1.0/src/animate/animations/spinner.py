"""Spinner animation."""

from animate.animations.base import BaseAnimation


class Spinner(BaseAnimation):
    """A simple rotating spinner animation."""

    def __init__(self) -> None:
        """Initialize the spinner."""
        self._frames = ["|", "/", "-", "\\"]

    def get_frames(self) -> list[str]:
        """Get spinner frames.

        Returns:
            List of spinner frame characters.
        """
        return self._frames

    def get_fps(self) -> float:
        """Get frames per second.

        Returns:
            10 FPS for smooth rotation.
        """
        return 10.0
