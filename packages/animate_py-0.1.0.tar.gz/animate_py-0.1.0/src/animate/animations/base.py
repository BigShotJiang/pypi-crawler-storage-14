"""Base class for animations."""

from abc import ABC, abstractmethod


class BaseAnimation(ABC):
    """Abstract base class for all animations.

    Subclasses must implement `get_frames()` and `get_fps()` methods.
    """

    @abstractmethod
    def get_frames(self) -> list[str]:
        """Get animation frames.

        Returns:
            List of frame strings, where each frame is ASCII art to display.
        """
        pass

    @abstractmethod
    def get_fps(self) -> float:
        """Get frames per second for the animation.

        Returns:
            FPS as a positive number.
        """
        pass
