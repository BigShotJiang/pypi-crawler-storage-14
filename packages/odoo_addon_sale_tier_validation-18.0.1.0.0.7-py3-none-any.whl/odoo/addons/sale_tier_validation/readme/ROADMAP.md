- The sales order, when moved to the state sent, will still send the
  email even if the validation is not approved by the corresponding
  tier. Code to consider this particular case is not developed.
