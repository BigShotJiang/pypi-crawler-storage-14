To configure this module, you need to:

1.  Go to *Settings \> Technical \> Tier Validations \> Tier
    Definition*.
2.  Create as many tiers as you want for Sale Order model.

If necessary, update the "Block Printing of Unvalidated Quotations" under *Sales \>
Configuration \> Settings* to block the printing of quotation when the order has yet
to be validated (disabled by default).
