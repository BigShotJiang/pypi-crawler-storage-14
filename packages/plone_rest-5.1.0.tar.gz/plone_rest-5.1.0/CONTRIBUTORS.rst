Note:  place names and roles of the people who contribute to this package
       in this file, one to a line, like so:

- Ramon Navarro Bosch, Original Author
- Timo Stollenwerk, Original Author
