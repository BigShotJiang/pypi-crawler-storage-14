from ._utils import (
    log,
    __CONSECUTIVE_SPACES_REGEX__,
    flatten,
    _is_iterable,
    _StorageTools,
    clean_spaces,
    html_forbidden,
)
