from .image import Image
from .utils import ensure_capacity
from .pyimagecuda_internal import gaussian_blur_separable_f32, sharpen_f32  #type: ignore


class Filter:

    @staticmethod
    def gaussian_blur(
        src: Image,
        radius: int = 3,
        sigma: float | None = None,
        dst_buffer: Image | None = None,
        temp_buffer: Image | None = None
    ) -> Image | None:
        """
        Applies a Gaussian blur to the image (returns new image or writes to buffer).

        Docs & Examples: https://offerrall.github.io/pyimagecuda/filter/#gaussian-blur
        """

        if sigma is None:
            sigma = radius / 3.0
        
        if dst_buffer is None:
            dst_buffer = Image(src.width, src.height)
            return_dst = True
        else:
            ensure_capacity(dst_buffer, src.width, src.height)
            return_dst = False

        if temp_buffer is None:
            temp_buffer = Image(src.width, src.height)
            owns_temp = True
        else:
            ensure_capacity(temp_buffer, src.width, src.height)
            owns_temp = False

        gaussian_blur_separable_f32(
            src._buffer._handle,
            temp_buffer._buffer._handle,
            dst_buffer._buffer._handle,
            src.width,
            src.height,
            radius,
            float(sigma)
        )

        if owns_temp:
            temp_buffer.free()
        
        return dst_buffer if return_dst else None

    @staticmethod
    def sharpen(
        src: Image,
        strength: float = 1.0,
        dst_buffer: Image | None = None
    ) -> Image | None:
        """
        Sharpens the image (returns new image or writes to buffer).

        Docs & Examples: https://offerrall.github.io/pyimagecuda/filter/#sharpen
        """

        if dst_buffer is None:
            dst_buffer = Image(src.width, src.height)
            return_buffer = True
        else:
            ensure_capacity(dst_buffer, src.width, src.height)
            return_buffer = False
        
        sharpen_f32(
            src._buffer._handle,
            dst_buffer._buffer._handle,
            src.width,
            src.height,
            float(strength)
        )
        
        return dst_buffer if return_buffer else None