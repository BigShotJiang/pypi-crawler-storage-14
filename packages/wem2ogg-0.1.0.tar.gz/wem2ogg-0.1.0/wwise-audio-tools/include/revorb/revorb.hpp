#ifndef REVORB_REVORB_H
#define REVORB_REVORB_H

#include <iostream>
#include <istream>
#include <sstream>
#include <string>

namespace revorb {
bool revorb(std::istream &indata, std::stringstream &outdata);
} // namespace revorb

#endif // REVORB_REVORB_H
