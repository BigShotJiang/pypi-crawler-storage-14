# Bibtheque

## Configuration

At `~/.config/bibtheque.env`:

```
# server
IP=192.168.12.24
PORT=5000
SECURE=0

# couchdb
DATABASE=bibtheque
COUCHDB_USER=user
COUCHDB_PASSWORD=password

# local
CACHE=~/.cache/bibtheque/
```


## For Development

Need to create the database in couchdb.

To install locally for testing:

```
source pyenv/bin/activate
pip install -e .
```

Check `scripts/`
