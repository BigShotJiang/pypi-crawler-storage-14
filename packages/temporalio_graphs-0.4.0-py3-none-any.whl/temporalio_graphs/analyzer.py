"""AST-based workflow analyzer for extracting Temporal workflow structure.

This module provides the WorkflowAnalyzer class which uses Python's Abstract Syntax
Tree (AST) to parse Temporal workflow source files and extract workflow metadata
including class definitions, run methods, and structural information.

The analyzer implements the Visitor Pattern via ast.NodeVisitor to traverse workflow
source code without executing it, enabling fast (<1ms) static analysis of workflow
structure.

Example:
    >>> from pathlib import Path
    >>> from temporalio_graphs.analyzer import WorkflowAnalyzer
    >>> analyzer = WorkflowAnalyzer()
    >>> metadata = analyzer.analyze("workflows/money_transfer.py")
    >>> print(f"Workflow: {metadata.workflow_class}")
    Workflow: MoneyTransferWorkflow
    >>> print(f"Run method: {metadata.workflow_run_method}")
    Run method: run
"""

import ast
import logging
import warnings
from pathlib import Path
from typing import TYPE_CHECKING

from temporalio_graphs._internal.graph_models import Activity, WorkflowMetadata
from temporalio_graphs.detector import (
    ChildWorkflowDetector,
    DecisionDetector,
    ExternalSignalDetector,
    SignalDetector,
    SignalHandlerDetector,
)
from temporalio_graphs.exceptions import WorkflowParseError

if TYPE_CHECKING:
    from temporalio_graphs.context import GraphBuildingContext

logger = logging.getLogger(__name__)


class WorkflowAnalyzer(ast.NodeVisitor):
    """AST-based analyzer for extracting Temporal workflow structure.

    This class extends ast.NodeVisitor to traverse Python workflow source files
    and extract workflow metadata including the workflow class decorated with
    @workflow.defn and the run method decorated with @workflow.run.

    The analyzer uses static code analysis without executing the workflow code,
    achieving sub-millisecond performance for typical workflow files.

    Attributes:
        _workflow_class: Name of the detected workflow class (None if not found).
        _workflow_run_method: Name of the detected run method (None if not found).
        _source_file: Path to the workflow source file being analyzed.
        _line_numbers: Dictionary mapping element names to source line numbers.
        _activities: List of tuples (activity_name, line_number) for detected activities.
        _activity_name_cache: Cache mapping AST node IDs to extracted activity names.

    Example:
        >>> analyzer = WorkflowAnalyzer()
        >>> metadata = analyzer.analyze("workflows/money_transfer.py")
        >>> assert metadata.workflow_class == "MoneyTransferWorkflow"
        >>> assert metadata.workflow_run_method == "run"
        >>> assert metadata.total_paths == 1  # Linear workflow in Epic 2
    """

    def __init__(self) -> None:
        """Initialize the workflow analyzer with empty state."""
        self._workflow_class: str | None = None
        self._workflow_run_method: str | None = None
        self._source_file: Path | None = None
        self._line_numbers: dict[str, int] = {}
        self._inside_workflow_class: bool = False
        self._activities: list[Activity] = []
        self._activity_name_cache: dict[int, str] = {}

    def analyze(
        self, workflow_file: Path | str, context: "GraphBuildingContext | None" = None
    ) -> WorkflowMetadata:
        """Analyze a workflow source file and extract workflow metadata.

        This method parses the workflow source file using Python's AST parser,
        traverses the syntax tree to find @workflow.defn classes and @workflow.run
        methods, and returns a WorkflowMetadata object with the extracted structure.

        Validation warnings may be emitted during analysis if context.suppress_validation
        is False (default). Warnings include empty workflows or potential rendering issues.

        Args:
            workflow_file: Path to workflow source file (relative or absolute).
                Can be a Path object or string path.
            context: Optional GraphBuildingContext with configuration options including
                suppress_validation flag to control warning emission. If None, uses default
                configuration (suppress_validation=False).

        Returns:
            WorkflowMetadata object containing:
                - workflow_class: Name of the workflow class
                - workflow_run_method: Name of the run method
                - activities: List of activity names (populated in Story 2.3)
                - decision_points: Empty list (populated in Epic 3)
                - signal_points: Empty list (populated in Epic 4)
                - source_file: Absolute path to analyzed file
                - total_paths: 1 for linear workflows

        Raises:
            FileNotFoundError: If workflow_file does not exist.
            PermissionError: If workflow_file cannot be read.
            WorkflowParseError: If no @workflow.defn class found, syntax errors,
                or workflow structure is invalid.

        Example:
            >>> from temporalio_graphs.context import GraphBuildingContext
            >>> analyzer = WorkflowAnalyzer()
            >>> context = GraphBuildingContext()
            >>> metadata = analyzer.analyze("workflows/my_workflow.py", context)
            >>> print(metadata.workflow_class)
            MyWorkflow
        """
        # Use default context if none provided
        if context is None:
            from temporalio_graphs.context import GraphBuildingContext

            context = GraphBuildingContext()

        # Reset state for new analysis
        self._workflow_class = None
        self._workflow_run_method = None
        self._line_numbers = {}
        self._inside_workflow_class = False
        self._activities = []
        self._activity_name_cache = {}

        # Convert to absolute path
        path = Path(workflow_file).resolve()
        self._source_file = path

        # Validate file exists
        if not path.exists():
            raise WorkflowParseError(
                file_path=path,
                line=0,
                message="Workflow file not found",
                suggestion="Verify file path is correct and file exists",
            ) from FileNotFoundError(f"File not found: {path}")

        # Validate file is readable
        try:
            source = path.read_text(encoding="utf-8")
        except PermissionError as e:
            raise WorkflowParseError(
                file_path=path,
                line=0,
                message="Cannot read file (permission denied)",
                suggestion="Check file permissions and ensure file is readable",
            ) from e

        # Warn if file extension is not .py
        if path.suffix != ".py":
            logger.warning(
                f"File does not have .py extension: {path}\n"
                f"Analysis may fail if file is not valid Python code."
            )

        # Parse AST
        try:
            tree = ast.parse(source, filename=str(path))
        except SyntaxError as e:
            raise WorkflowParseError(
                file_path=path,
                line=e.lineno or 0,
                message=f"Invalid Python syntax: {e.msg}",
                suggestion="Check workflow file for syntax errors",
            ) from e

        # Traverse AST to find workflow elements
        self.visit(tree)

        # Check if workflow class was found
        if self._workflow_class is None:
            raise WorkflowParseError(
                file_path=path,
                line=0,
                message="Missing @workflow.defn decorator",
                suggestion="Add @workflow.defn decorator to workflow class",
            )

        # Check if run method was found
        if self._workflow_run_method is None:
            raise WorkflowParseError(
                file_path=path,
                line=self._line_numbers.get("workflow_class", 0),
                message="Missing @workflow.run method",
                suggestion="Add @workflow.run method to workflow class",
            )

        # Build and return WorkflowMetadata
        # Activities are already Activity objects with line numbers
        activities = self._activities

        # Detect decision points using DecisionDetector
        decision_detector = DecisionDetector()
        decision_detector.visit(tree)
        decision_points = decision_detector.decisions

        # Detect signal points using SignalDetector
        signal_detector = SignalDetector()
        signal_detector.visit(tree)
        signal_points = signal_detector.signals

        # Detect child workflow calls using ChildWorkflowDetector
        child_workflow_detector = ChildWorkflowDetector()
        child_workflow_detector.set_parent_workflow(self._workflow_class)
        child_workflow_detector.visit(tree)
        child_workflow_calls = child_workflow_detector.child_calls

        # Detect external signal calls using ExternalSignalDetector
        external_signal_detector = ExternalSignalDetector()
        external_signal_detector.set_source_workflow(self._workflow_class)
        external_signal_detector.set_file_path(path)
        external_signal_detector.visit(tree)
        external_signals = external_signal_detector.external_signals

        # Detect signal handlers using SignalHandlerDetector
        signal_handler_detector = SignalHandlerDetector()
        signal_handler_detector.set_workflow_class(self._workflow_class)
        signal_handler_detector.visit(tree)
        signal_handlers = tuple(signal_handler_detector.handlers)

        # Emit validation warnings if not suppressed
        if not context.suppress_validation:
            # Warn about empty workflows (no activity calls)
            if len(activities) == 0:
                warnings.warn(
                    f"No activity calls detected in workflow '{self._workflow_class}'. "
                    f"The generated graph will only contain Start and End nodes. "
                    f"Consider adding execute_activity() calls or suppress this warning "
                    f"with context.suppress_validation=True.",
                    UserWarning,
                    stacklevel=2,
                )

            # Warn about very long activity names that may render poorly
            for activity in activities:
                activity_name = activity.name
                if len(activity_name) > 100:
                    warnings.warn(
                        f"Activity name '{activity_name[:50]}...' is very long "
                        f"({len(activity_name)} chars). "
                        f"Long names may render poorly in Mermaid diagrams. "
                        f"Consider using shorter, descriptive names or suppress this warning "
                        f"with context.suppress_validation=True.",
                        UserWarning,
                        stacklevel=2,
                    )

        # Calculate total paths from decisions + signals
        total_paths = WorkflowMetadata.calculate_total_paths(
            len(decision_points), len(signal_points)
        )

        return WorkflowMetadata(
            workflow_class=self._workflow_class,
            workflow_run_method=self._workflow_run_method,
            activities=activities,  # Populated in Story 2.3
            decision_points=decision_points,  # Populated in Epic 3 (Story 3.1)
            signal_points=signal_points,  # Populated in Epic 4 (Story 4.1)
            child_workflow_calls=child_workflow_calls,  # Populated in Epic 6 (Story 6.1)
            external_signals=tuple(external_signals),  # Populated in Epic 7 (Story 7.3)
            signal_handlers=signal_handlers,  # Populated in Epic 8 (Story 8.2)
            source_file=path,
            total_paths=total_paths,
        )

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """Visit class definition nodes to find @workflow.defn decorated classes.

        This visitor method is called for each class definition in the AST.
        It checks if the class has a @workflow.defn decorator and stores the
        class name and line number if found.

        Args:
            node: AST node representing a class definition.
        """
        # Check if class has @workflow.defn decorator
        for decorator in node.decorator_list:
            if self._is_workflow_decorator(decorator, "defn"):
                self._workflow_class = node.name
                self._line_numbers["workflow_class"] = node.lineno
                self._inside_workflow_class = True
                logger.debug(f"Found workflow class: {node.name} at line {node.lineno}")
                break

        # Continue traversal to find run method inside class
        self.generic_visit(node)

        # Reset flag after visiting class
        self._inside_workflow_class = False

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Visit function definition nodes to find @workflow.run decorated methods.

        This visitor method is called for each function/method definition in the AST.
        It checks if the method has a @workflow.run decorator (only within detected
        workflow classes) and stores the method name and line number if found.

        Args:
            node: AST node representing a function/method definition.
        """
        # Only process if inside a workflow class
        if self._inside_workflow_class:
            # Check if method has @workflow.run decorator
            for decorator in node.decorator_list:
                if self._is_workflow_decorator(decorator, "run"):
                    self._workflow_run_method = node.name
                    self._line_numbers["workflow_run_method"] = node.lineno
                    logger.debug(f"Found run method: {node.name} at line {node.lineno}")
                    break

        # Continue traversal to find nested calls (activities)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Visit async function definition nodes to find @workflow.run methods.

        This visitor method handles async methods, which are common in Temporal
        workflows. It delegates to the same logic as visit_FunctionDef.

        Args:
            node: AST node representing an async function/method definition.
        """
        # Only process if inside a workflow class
        if self._inside_workflow_class:
            # Check if method has @workflow.run decorator
            for decorator in node.decorator_list:
                if self._is_workflow_decorator(decorator, "run"):
                    self._workflow_run_method = node.name
                    self._line_numbers["workflow_run_method"] = node.lineno
                    logger.debug(f"Found async run method: {node.name} at line {node.lineno}")
                    break

        # Continue traversal to find nested calls (activities)
        self.generic_visit(node)

    def _is_workflow_decorator(self, decorator: ast.expr, target: str) -> bool:
        """Check if a decorator is a workflow decorator (@workflow.defn or @workflow.run).

        This helper method identifies Temporal workflow decorators by matching
        AST patterns for both attribute access (@workflow.defn) and direct
        imports (if user imports defn/run directly).

        Args:
            decorator: AST expression node representing the decorator.
            target: Target decorator name ("defn" or "run").

        Returns:
            True if decorator matches @workflow.{target}, False otherwise.

        Example:
            Matches these patterns:
            - @workflow.defn (ast.Attribute with value.id="workflow", attr="defn")
            - @workflow.run (ast.Attribute with value.id="workflow", attr="run")
            - @defn (ast.Name with id="defn", if imported directly)
        """
        # Handle attribute access: @workflow.defn or @workflow.run
        if isinstance(decorator, ast.Attribute):
            if decorator.attr == target:
                if isinstance(decorator.value, ast.Name) and decorator.value.id == "workflow":
                    return True

        # Handle direct import: @defn or @run (from temporalio.workflow import defn)
        if isinstance(decorator, ast.Name):
            if decorator.id == target:
                return True

        return False

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function call nodes to detect execute_activity() calls.

        This visitor method is called for each function call node in the AST.
        It identifies calls to workflow.execute_activity() and extracts the
        activity name from the first argument, storing it for later processing.

        Args:
            node: AST node representing a function call.

        Example:
            Detects these patterns:
            - workflow.execute_activity(my_activity, ...)
            - await workflow.execute_activity(my_activity, ...)
            - workflow.execute_activity("activity_name", ...)
        """
        if self._is_execute_activity_call(node):
            # Extract activity name from first argument
            if node.args:  # Ensure there is at least one argument
                activity_name = self._extract_activity_name(node.args[0])
                activity = Activity(name=activity_name, line_num=node.lineno)
                self._activities.append(activity)
                logger.debug(
                    f"Found activity call: {activity_name} at line {node.lineno}"
                )
        else:
            # Log debug information for non-activity calls to aid debugging
            logger.debug(
                f"Skipping non-activity call at line {node.lineno}: "
                f"{ast.unparse(node) if hasattr(ast, 'unparse') else '<call>'}"
            )

        # Continue traversal to find nested calls
        self.generic_visit(node)

    def _is_execute_activity_call(self, node: ast.Call) -> bool:
        """Check if a call node is an execute_activity() call.

        This helper method identifies execute_activity() calls by pattern matching
        on the AST node structure. It checks for the attribute access pattern
        (workflow.execute_activity) and verifies the context.

        Args:
            node: AST node representing a function call.

        Returns:
            True if the call is a workflow.execute_activity() call, False otherwise.

        Example:
            Returns True for:
            - workflow.execute_activity(...)
            - await workflow.execute_activity(...)
            Returns False for:
            - workflow.execute_signal(...)
            - other_module.execute_activity(...)
        """
        # Check if func is an attribute access (e.g., workflow.execute_activity)
        if not isinstance(node.func, ast.Attribute):
            return False

        # Check if the attribute name is "execute_activity" or "execute_activity_method"
        if node.func.attr not in ("execute_activity", "execute_activity_method"):
            return False

        # Check if the value is a workflow reference
        if not self._is_workflow_reference(node.func.value):
            return False

        return True

    def _is_workflow_reference(self, node: ast.expr) -> bool:
        """Check if a node is a reference to the workflow module/object.

        This helper method identifies references to the workflow object that
        is used to call execute_activity(). It handles the common pattern where
        workflow is imported from temporalio.

        Args:
            node: AST expression node to check.

        Returns:
            True if the node represents a workflow reference, False otherwise.
        """
        # Check for simple name reference: workflow
        if isinstance(node, ast.Name):
            return node.id == "workflow"

        return False

    def _extract_activity_name(self, arg: ast.expr) -> str:
        """Extract activity name from a function call argument.

        This helper method extracts the activity name from the first argument
        of an execute_activity() call. It handles both function references
        (ast.Name nodes) and string literals (ast.Constant nodes).

        Results are cached by argument object ID to optimize performance when
        the same activity reference is encountered multiple times.

        Args:
            arg: AST expression node representing the activity argument.

        Returns:
            The activity name as a string. Returns a placeholder string if the
            activity name cannot be extracted.

        Example:
            - my_activity (function reference) -> "my_activity"
            - "my_activity" (string literal) -> "my_activity"
        """
        # Check cache first to avoid redundant extraction
        arg_id = id(arg)
        if arg_id in self._activity_name_cache:
            return self._activity_name_cache[arg_id]

        # Handle function reference: execute_activity(my_activity, ...)
        if isinstance(arg, ast.Name):
            result = arg.id
            self._activity_name_cache[arg_id] = result
            return result

        # Handle string literal: execute_activity("my_activity", ...)
        if isinstance(arg, ast.Constant):
            if isinstance(arg.value, str):
                result = arg.value
                self._activity_name_cache[arg_id] = result
                return result

        # Handle method reference: execute_activity_method(ClassName.method_name, ...)
        if isinstance(arg, ast.Attribute):
            # Extract the method name from the attribute access
            result = arg.attr
            self._activity_name_cache[arg_id] = result
            return result

        # If we can't extract the activity name, log a warning and return placeholder
        placeholder = f"<unknown_activity_{arg_id}>"
        logger.warning(
            f"Could not extract activity name from argument at "
            f"line {getattr(arg, 'lineno', '?')}. Using placeholder: {placeholder}"
        )
        self._activity_name_cache[arg_id] = placeholder
        return placeholder
