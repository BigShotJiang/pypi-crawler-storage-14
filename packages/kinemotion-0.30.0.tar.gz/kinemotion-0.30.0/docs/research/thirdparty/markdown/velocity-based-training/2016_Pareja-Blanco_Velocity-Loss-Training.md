Scand J Med Sci Sports 2016: ��: ��–��
doi: 10.1111/sms.12678

ª 2016 John Wiley & Sons A/S.

Published by John Wiley & Sons Ltd

# Effects of velocity loss during resistance training on athletic performance, strength gains and muscle adaptations

F. Pareja-Blanco \[1\], D. Rodr�ıguez-Rosell \[1\], L. S�anchez-Medina \[2\], J. Sanchis-Moysi \[3,4\], C. Dorado \[3,4\], R. Mora-Custodio \[1\],
J. M. Y�a~nez-Garc�ıa \[1\], D. Morales-Alamo \[3,4\], I. P�erez-Su�arez \[3,4\], J. A. L. Calbet \[3,4\], J. J. Gonz�alez-Badillo \[1\]

1Physical Performance & Sports Research Center, Pablo de Olavide University, Seville, Spain, 2Studies, Research & Sports
Medicine Center, Government of Navarre, Pamplona, Spain, \[3\] Department of Physical Education, Las Palmas de Gran Canaria
University, Las Palmas de Gran Canaria, Spain, \[4\] Research Institute of Biomedical and Health Sciences (IUIBS), Las Palmas de
Gran Canaria University, Las Palmas de Gran Canaria, Spain
Corresponding author: Fernando Pareja-Blanco, Centro de Investigacion en Rendimiento F� �ısico y Deportivo, Universidad Pablo de
Olavide, Ctra. de Utrera km 1, 41013 Seville, Spain. Tel.: +34 653121522; Fax: +34 954 348 659; E-mail: <fparbla@gmail.com>

Accepted for publication 23 February 2016

We compared the effects of two resistance training (RT)
programs only differing in the repetition velocity loss
allowed in each set: 20% (VL20) vs 40% (VL40) on
muscle structural and functional adaptations. Twenty-two
young males were randomly assigned to a VL20 (n = 12)
or VL40 (n = 10) group. Subjects followed an 8-week
velocity-based RT program using the squat exercise while
monitoring repetition velocity. Pre- and post-training
assessments included: magnetic resonance imaging, vastus
lateralis biopsies for muscle cross-sectional area (CSA)
and fiber type analyses, one-repetition maximum strength
and full load-velocity squat profile, countermovement jump
(CMJ), and 20-m sprint running. VL20 resulted in similar

The adaptive response to resistance training (RT)
depends on several variables that configure the resistance exercise stimulus such as loading magnitude,
number of sets and repetitions, exercise type and
order, rests duration, and movement velocity (Spiering et al., 2008; S�anchez-Medina & Gonz�alezBadillo, 2011). It has been shown that velocity loss
and metabolic stress considerably differ depending
on the actual number of repetitions performed in an
exercise set in relation to the maximum number that
can be completed (S�anchez-Medina & Gonz�alezBadillo, 2011). Although some studies (Rooney
et al., 1994; Ahtiainen et al., 2003; Drinkwater et al.,
2005\) suggest that performing repetitions to failure
may be necessary to maximize muscle mass and
strength, others seem to indicate that similar, if not
greater, strength gains and improvements in athletic
performance can be obtained without reaching muscle failure (Folland et al., 2002; Izquierdo et al.,
2006; Izquierdo-Gabarren et al., 2010). It has been
hypothesized that RT eliciting high levels of fatigue,
as it occurs in typical body-building routines, may

squat strength gains than VL40 and greater improvements
in CMJ (9.5% vs 3.5%, P \< 0.05), despite VL20
performing 40% fewer repetitions. Although both groups
increased mean fiber CSA and whole quadriceps muscle
volume, VL40 training elicited a greater hypertrophy of
vastus lateralis and intermedius than VL20. Training
resulted in a reduction of myosin heavy chain IIX
percentage in VL40, whereas it was preserved in VL20. In
conclusion, the progressive accumulation of muscle fatigue
as indicated by a more pronounced repetition velocity loss
appears as an important variable in the configuration of
the resistance exercise stimulus as it influences functional
and structural neuromuscular adaptations.

induce greater strength adaptations due to an
enhanced activation of motor units and secretion of
growth-promoting hormones (Schott et al., 1995;
Schoenfeld, 2010). However, definitive evidence is
lacking and the controversial results found in the literature clearly emphasize the need to conduct further
research on this topic.
Experiments with isolated human muscle fibers
(Mogensen et al., 2006), as well as in vivo human
studies (Aagaard & Andersen, 1998; Sanchis-Moysi
et al., 2010) have shown that a high proportion of
type II muscle fibers or myosin heavy chain (MHC)
II isoforms is associated with high levels of force production during fast muscle contractions. Interestingly, most studies have shown that the percentage
of type IIX fibers is reduced following a RT program
based on repetitions to failure (Staron et al., 1991;
Andersen & Aagaard, 2000; Campos et al., 2002;
Andersen et al., 2005). Nevertheless, a study by
Harridge et al. (1998) showed that maximal isometric strength (voluntary and electrically evoked) can
be significantly increased without a reduction in the

1

Pareja-Blanco et al.

MHC-IIX fiber pool following a 6-week training
program based on 4 sessions/week of high-intensity,
short-duration, cycling exercise (three 3-s sprints
with 30-s recoveries), aimed to avoid a decline in performance during the training session.
During RT muscle fatigue increases with the accumulation of repetitions, and if the exercise is not
stopped, task failure eventually occurs. However,
prior to task failure, other signs of muscle fatigue are
detectable, such as reduced maximal force application, slower shortening velocity and decreased power
output (Allen et al., 1995; S�anchez-Medina &
Gonz�alez-Badillo, 2011; Gorostiaga et al., 2012).
The complexity of fatigue assessment has led to the
utilization of procedures that lack specificity. It has
been shown that neuromuscular fatigue induced by
RT protocols can be monitored by assessing the repetition velocity loss within a set (S�anchez-Medina &
Gonz�alez-Badillo, 2011). A novel, velocity-based
approach to RT has been proposed in which, rather
than prescribing a fixed number of repetitions to perform with a given load, training is configured using
two variables: (a) first repetition’s mean velocity,
which is intrinsically related to relative loading magnitude (Gonz�alez-Badillo & S�anchez-Medina, 2010);
and (b) the velocity loss to be allowed, expressed as a
percent loss in mean velocity from the fastest (usually first) repetition of each exercise set (S�anchezMedina & Gonz�alez-Badillo, 2011). Thus, when the
prescribed percent velocity loss limit is exceeded, the
set is terminated.
In an attempt to gain further insight into the adaptations brought about by training close to muscle
failure vs not to failure, we aimed to compare the
effects of two RT programs that only differed in the
magnitude of repetition velocity loss allowed in each
set (20% vs 40%) on structural and functional adaptations. We hypothesized that, despite a remarkably
lower training volume, improvements in strength
and performance will be greater with the RT program allowing only a 20% reduction in repetition
velocity, whereas a 40% velocity loss will result in
greater muscle hypertrophy.

Materials and methods
Subjects

Twenty-four young and healthy men (age 22.7 � 1.9 years,
height 1.76 � 0.06 m, body mass 75.8 � 7.0 kg) volunteered
to participate in this study. Their initial 1RM strength for the
full (deep) squat (SQ) exercise was 106.2 � 13.0 kg
(1.41 � 0.19 normalized per kg of body mass). All subjects
were physically active sports science students with a RT expe
–
rience ranging from 1.5 to 4 years (1 3 sessions/week) and
were accustomed to performing the SQ with correct technique.
Subjects were randomly assigned to one of two groups only
differing in the magnitude of repetition velocity loss allowed
during training: 20% (VL20; n = 12) or 40% (VL40; n = 12).

2

During the course of the study, two subjects from the VL40
dropped out because of injury (not related to the training
intervention) or illness; thus, the complete dataset for the
VL40 group was obtained from the remaining 10 subjects. All
subjects were informed about the experimental procedures
and potential risks before they provided their written
informed consent. The study was approved by the institutional review committee of Pablo de Olavide University, and
was performed in accordance with the Declaration of Helsinki. No physical limitations, health problems, or musculoskeletal injuries that could affect training were found after a
medical examination. None of the subjects were taking drugs,
medications, or dietary supplements.

Study design

–
Subjects trained twice a week (48 72 h apart) during 8-week
for a total of 16 sessions. A progressive RT program which
comprised only the SQ exercise was used (Table 1). The two
groups trained at the same relative loading magnitude (percentage of one-repetition maximum, %1RM) in each session
but differed in the maximum percent velocity loss reached in
each exercise set (20% vs 40%). As soon as the corresponding
target velocity loss limit was exceeded, the set was terminated.
Sessions were performed in a research laboratory under the
direct supervision of the investigators, at the same time of day
(�1 h) for each subject and under controlled environmental
conditions (20 °C and 60% humidity). Subjects were required
not to engage in any other type of strenuous physical activity,
exercise training, or sports competition for the duration of the
present investigation. Both VL20 and VL40 groups were
assessed on two occasions: 48 h before (Pre) and 72 h after
(Post) the 8-week training intervention. Training compliance
was 100% of all sessions for the subjects that completed the
intervention.

Testing Procedures
Isoinertial strength assessment

A progressive loading test up to the 1RM load was performed
in the SQ exercise. The SQ was performed with subjects starting from the upright position with the knees and hips fully
extended, parallel feet stance approximately shoulder-width
apart, and the barbell resting across the back at the level of
the acromion. Each subject descended in a continuous motion
until the top of the thighs was below the horizontal plane, the
posterior thighs and shanks making contact with each other
(~35–40° knee flexion), then immediately reversed motion and
raised back to the upright position. Unlike the eccentric phase
that was performed at a controlled mean velocity (~0.50–
0.65 m/s), subjects were required to always execute the concentric phase at maximal intended velocity. Initial load was
set at 30 kg and was progressively increased in 10-kg increments until the attained mean propulsive velocity (MPV) was
\<0.6 m/s. Thereafter, load was individually adjusted with
smaller increments (5 down to 2.5 kg) so that 1RM could be
precisely determined. Three repetitions were executed for light
(≤50% 1RM), two for medium (50–80% 1RM), and only one
for the heaviest loads (>80% 1RM). Strong verbal encouragement was provided to motivate participants to give a maximal
effort. Inter-set recoveries ranged from 3 min (light) to 5 min
(heavy loads). Only the best repetition at each load, according
to the criteria of fastest MPV was considered for subsequent
analysis. All velocity measures reported in this study corresponded to the mean velocity of the propulsive phase of each
repetition. The propulsive phase was defined as that fraction

Velocity loss as a strength training variable

3

Pareja-Blanco et al.

of the concentric phase during which barbell acceleration is
greater than the acceleration due to gravity (S�anchez-Medina
et al., 2010).
Warm-up consisted of 5 min of treadmill running at
10 km/h, 5 min of lower body joint mobilization exercises,
and two sets of eight and six SQ repetitions (3-min rests) with
loads of 20 and 30 kg, respectively. The exact same warm-up
and progression of absolute loads for each subject was used at
Pre and Post. In addition to 1RM strength, three other variables derived from this progressive loading test were used in
an attempt to analyze the extent to which the two training
interventions (VL20 vs VL40) affected the different parts of
the load-velocity relationship: (a) average MPV attained
against all absolute loads common to Pre and Post (AV); (b)
average MPV attained against absolute loads common to Pre
and Post that were moved faster than 1 m/s (AV>1, ‘light’
loads); and (c) average MPV attained against absolute loads
common to Pre and Post tests that were moved slower than
1 m/s (AV\<1, ‘heavy’ loads). A Smith machine (Multipower
Fitness Line, Peroga, Murcia, Spain) with no counterweight
mechanism was used for testing and training. A dynamic measurement system (T-Force System, Ergotech, Murcia, Spain)
automatically calculated the relevant kinematic parameters of
every repetition, provided auditory and visual velocity feedback in real-time and stored data on disk for analysis. This
system consists of a linear velocity transducer interfaced to a
computer by means of a 14-bit analog-to-digital data acquisition board and custom software. Instantaneous velocity was
sampled at 1000 Hz and smoothed using a 4th order low-pass
Butterworth filter with no phase shift and 10 Hz cut-off frequency. Reliability of this system has been reported elsewhere
(S�anchez-Medina & Gonz�alez-Badillo, 2011).

Sprint and vertical jump tests

Vertical jump and sprint ability were assessed as indicators of
explosive force production and lower limb whole muscle performance. Two maximal 20-m sprints, separated by a 3-min
rest, were performed in an indoor running track. Photocell
timing gates were placed at 0 and 20 m so that the times to
cover 0–20 m (T20) could be determined. A standing start
with the lead-off foot placed 1 m behind the first timing gate
was used. Subjects were required to give an all-out maximal
effort in each sprint and the best of both trials was kept for
analysis. The same warm-up protocol which incorporated several sets of progressively faster 30-m running accelerations
was followed at Pre and Post. Sprint times were measured
using photocells (Polifemo Radio Light, Microgate, Bolzano,
Italy). Five maximal countermovement vertical jumps
(CMJs), separated by 20-s rests, were performed next. The
highest and lowest CMJ height values were discarded, and the
resulting average kept for analysis. Jump height was determined using an infrared timing system (Optojump, Microgate,

–
Bolzano, Italy). Test retest reliability measured by the coefficient of variation (CV) were 0.9% and 1.5% for T20 and
CMJ, respectively. The intraclass correlation coefficients

–
(ICCs) were 0.957 (95% confidence interval, CI: 0.903 0.981)

–
for T20, and 0.995 (95% CI: 0.990 0.998) for CMJ.

Muscle biopsy sampling

Subjects reported to the laboratory at 7:00 a.m. after a 12-h
overnight fast. The dinner previous to the biopsy day was standardized for Pre and Post tests. After a 10-min rest in the supine
position, the middle portion of the vastus lateralis (VL) muscle
was anaesthetized with 2% lidocaine (2 mL). Thereafter,

4

–
muscle biopsy samples (80 160 mg) were extracted from the

–
superficial region (2 3 cm depth) of the VL muscle using the
Bergstrom technique with suction (Perez-Gomez et al., 2008).
In order to minimize sampling error, all biopsies were performed by the same medical doctor and great care was taken to
standardize the site and depth of the sample. Upon collection,

–
muscle samples, weighing 75 100 mg, were divided into two.
The first half was mounted on cork blocks with the use of Tissue-Tek \[�\] O.C.T.TM embedding medium an orientated so that
myofibers could be transversely cut. Specimens were systemati
–
cally frozen by immersion (10 15 s) in isopentane, kept at
freezing point in liquid nitrogen. The second half was immediately frozen in liquid nitrogen. Both biopsy pieces were stored
at �80 °C until analyzed. Biopsy samples were obtained and
frozen in less than 30 s at Pre and Post (48 h after the last testing session). Because of possible variations in fiber type distribution from superficial to deep and proximal to distal
(Blomstrand & Ekblom, 1982), we attempted to extract Pre
and Post tissue samples from within a small area of the muscle.
We used the pre-biopsy scar to identify the location from where
the post-biopsy should be obtained, which was located 3 cm
away from the pre-biopsy site.

Fiber type and muscle cross-sectional area determinations

Serial sections (10 lm) of the muscle biopsy samples were cut
successively in a cryostat (�20 °C) and carefully placed on
microscope slides. To determine the muscle fiber type composition, adenosine triphosphatase (ATPase) histochemistry was
performed using pre-incubation pH values of 4.37, 4.60, and
10.30 (Brooke & Kaiser, 1970). According to Staron et al.
(1991), five different fiber types were defined (types I, IIC,
IIA, IIAX, and IIX, Fig. 1a). Cross-sections from Pre and
Post biopsies from the same individual were placed on the
same slide so that they could be processed simultaneously for
ATPase histochemistry. Only truly horizontally cut fibers were
used in the determination of fiber size. An average of
180 � 27 fibers was examined in each of the biopsies. The
number of IIC fibers was too low in some individuals as to
allow a reliable statistical analysis. The serial sections were
visualized and analyzed using an Olympus BX40 microscope
(Olympus Optical Co., Tokyo, Japan), an Olympus camera
(DP 26, Olympus Optical Co.), combined with image analysis
software (Olympus CellSens Standard, Tokyo, Japan). Using
the 4.60 ATPase staining, a fiber mask was drawn manually
following the boundaries of the fibers. This mask was overimposed on the images obtained with the additional ATPase
stainings. Fiber types were then identified according to staining properties at different pHs and the cross-sectional area
(CSA) was determined. The relative fiber type area was calculated as the product of average fiber type size by percentage
distributions.

Protein extraction for MHC

For total protein extraction from human skeletal muscle, a

–
piece of frozen tissue (10 20 mg) was pulverized with grinding
balls at 3000 rpm for 1 min in a Mikro-Dismembrator S (Sartorius, Goettingen, Germany). Proteins were extracted in urea
lysis buffer \[6 M urea, 1% (wt/vol) SDS, 1X of Complete protease inhibitor, and PhosSTOP phosphatase inhibitor (Roche
Diagnostics, Mannheim, Germany)\] by the use of sonication
(75 W, 3 pulses of 10 s). After centrifugation at 20,000 g to
remove tissue debris, total protein extracts were transferred to
clean tubes, and protein quantification was performed by
bicinchoninic acid assay (Smith et al., 1985).

Velocity loss as a strength training variable

Fig. 1. Example of serial cross-sections of muscle biopsy samples taken from the vastus lateralis muscle showing fiber types
using myofibrillar ATPase histochemistry after pre-incubation at different pH values (a). Coomassie-stained representative for
myosin heavy chain (MHC) isoform composition analysis of a vastus lateralis muscle sample, as separated by SDS-PAGE (b).
Representative sample of cross-sectional magnetic resonance images at the level of the mid-thigh of both legs, showing the
four muscles of the quadriceps femoris outlined; VL: vastus lateralis, VI: vastus intermedius, VM: vastus medialis, RF: rectus
femoris (c).

MHC analysis

MHC analysis was performed on the muscle biopsies using
sodium dodecyl sulfate polyacrylamide gel electrophoresis
(SDS-PAGE) as reported by Larsson et al. (2002). Different
amounts of protein extracts (range: 2–4 lL) were loaded on a
SDS-PAGE gel. Gels were run in a Protean II unit (Bio-Rad
Laboratories Inc., Hercules, California, USA), at 70 V for
40 h followed by 7 h at 120 V, both at 4 °C. Subsequently,
the gels were Coomassie stained. This method resolved MHCs
in three bands: I, IIA, and IIX (Fig. 1b) from the fastest to
the slowest migration band (Biral et al., 1988). Gels were then
scanned with a video-scanning densitometric system and
quantified with the image analysis software Quantity One
(Bio-Rad Laboratories Inc.). The quantification of each MHC
isoform was obtained in relative terms for each muscle biopsy
sample.

Anatomical muscle CSA and volume

A 1.5-T scanner (General Electric, Milwaukee, Wisconsin,
USA) was used to acquire 4-mm axial contiguous slices from
the more distal edge of the femur condyles to the iliac spine
with the subjects lying supine with extended knees. Axial gradient-echo T1-weighted images of the thigh were collected
from both legs simultaneously using a repetition time of
132 ms and an echo time of 4.2 ms, a flip angle of 80� with a
42 cm \[2\] field of view, and a matrix of 256 9 256 pixels
(in-plane spatial resolution = 1.64 mm 9 1.64 mm).

The boundaries of the VL, vastus intermedius (VI), vastus
medialis (VM), and rectus femoris (RF) muscles were manually
outlined slice-by-slice using a specially designed image analysis software (SliceOmatic 4.3, Tomovision Inc., Montreal,
Quebec, Canada), as described elsewhere (Lee et al., 2000). A
representative example is depicted in Fig. 1c. Two investigators with expert anatomic knowledge and experience in muscle
segmentation analysis manually traced all images (SanchisMoysi et al., 2010, 2011, 2012). One observer outlined the VL,
the VI, and the VM, and the other one outlined the RF.
Examiners were blinded to the allocation of the subjects to the
VL20 or VL40 groups.
The total volume of VL, VI, VM and RF was calculated
from the most distal slice where the VM could be first identified to the most proximal slice where the RF starts to be seen.
Because substantial fusion may be found between VL and VI
on some slices (Barnouin et al., 2014), these two muscles were
outlined together (VL+VI). Muscle length was calculated as
the number of slices from the proximal to the distal reference
times the slice thickness. The degree of hypertrophy was calculated by subtracting the muscle volume at Pre from the muscle
volume at Post, expressed as a percentage of the Pre value.
The intra-observer coefficient of variation for muscle segmentation in our laboratory is below 2% (Sanchis-Moysi et al.,
2010, 2011, 2012).

Resistance training program

Descriptive characteristics of the RT program are presented in
Table 1. Both VL20 and VL40 groups trained using only the

5

Pareja-Blanco et al.

SQ exercise as previously described. Relative magnitude of
training loads (%1RM), number of sets (three), and inter-set
recoveries (4 min) were kept identical for both groups in each
training session. Relative loads were determined from the
load–velocity relationship for the SQ as it has recently been
shown that there exists a very close relationship between %
1RM and MPV (Gonz�alez-Badillo & S�anchez-Medina, 2010;
S�anchez-Medina et al., 2014). Thus, a target MPV to be
attained in the first (usually the fastest) repetition of the 1st
exercise set in each session was used as an estimation of %
1RM, as follows: 0.82 m/s (~70% 1RM), 0.75 m/s (~75%

~ ~
1RM), 0.68 m/s ( 80% 1RM), and 0.60 m/s ( 85% 1RM);
i.e., a velocity-based training was actually performed, instead
of a traditional loading-based RT program (Gonz�alez-Badillo
et al., 2014; Pareja-Blanco et al., 2014). The absolute load
(kg) was individually adjusted to match the velocity associated
(� 0.03 m/s) with the %1RM that was intended for that session. Thus, both groups trained using the same loading magnitude in each session (progressively increasing from 70% to
85% 1RM over the time course of the study, Table 1) but differed in the degree of neuromuscular fatigue experienced during the exercise sets, which was objectively quantified by the
magnitude of velocity loss attained in each set (S�anchez-Medina & Gonz�alez-Badillo, 2011). A 40% velocity loss limit for
the SQ exercise (VL40 group) implies performing repetitions
to, or very close to, muscle failure in most exercise sets
(S�anchez-Medina & Gonz�alez-Badillo, 2011). In contrast, a
20% velocity loss corresponds to performing approximately
half the maximum possible number of repetitions per set in
the SQ exercise, as previously reported (S�anchez-Medina &
Gonz�alez-Badillo, 2011). During training, subjects received
immediate velocity feedback while being encouraged to perform each repetition at maximal intended velocity. Total work
was calculated from the data provided by the linear velocity
transducer as the sum of the force (weight lifted) 9 concentric
distance completed during each repetition of each exercise set.
The warm-up preceding each training session was standardized for both intervention groups, as follows: 3 min of lower
body joint mobilization exercises, followed by two sets of
eight and six SQ repetitions with loads of 50% 1RM and 60%

–
1RM, respectively, for sessions 1 6 (in which the training load
was 70% 1RM); an additional set of four SQ repetitions with
70% 1RM was added for sessions 7–13 (in which the training
load was 75–80% 1RM); and a final set of two repetitions
with 80% 1RM was added for sessions 14 to 16 (in which the
training load was 85% 1RM). A 2-min rest between the SQ
warm-up sets was always used. For VL20 group, the velocity
loss was 20% in all training sessions. However, for VL40

group, the velocity loss followed a progression from 20% to
50%, being the average velocity loss during the training program of 41.9%. This progression was used to avoid an excessive overload and minimize the injury risk at the beginning of
the training program in the VL40 group. The real-time velocity data provided by the T-Force System were used to decide
on when the exercise had to be stopped.

Statistical analyses

Values are reported as mean � standard deviation (SD).
Test–retest absolute reliability was assessed using the CV,
whereas relative reliability was calculated by the ICC with
95% confidence interval (CI), using the one-way random
effects model. The normality of distribution of the variables at
Pre was examined with the Shapiro–Wilk test and the homogeneity of variance across groups (VL20 vs VL40) was verified
using the Levene’s test. Data were analyzed using a 2 9 2 factorial ANOVA with Bonferroni’s post-hoc comparisons using
one between factor (VL20 vs VL40) and one within factor
(Pre vs Post). Statistical significance was established at the
P ≤ 0.05 level. All statistical analyses were performed using
SPSS software version 18.0 (SPSS Inc., Chicago, Illinois,
USA).

Results

No significant differences between the VL20 and
VL40 groups were found at Pre for any of the variables analyzed. Descriptive characteristics of the
training actually performed by both groups are
reported in Table 1. The total number of repetitions
and the repetitions performed in different velocity
ranges by each group are shown in Fig. 2. Subjects
from the VL20 group trained at a significantly faster
mean velocity than those from VL40 (0.69 � 0.02 vs
0.58 � 0.03 m/s, respectively; P \< 0.001), whereas
VL40 performed more repetitions (P \< 0.001) than
VL20 (310.5 � 42.0 vs 185.9 � 22.2). The mean
fastest repetition during each session (that which
indicates the relative magnitude of the load being
lifted) did not differ between groups (0.75 � 0.03 vs
0.76 � 0.01 m/s, for VL40 and VL20, respectively)

Fig. 2. Number of repetitions in the squat exercise performed in each velocity range, and total number of repetitions completed by both training groups. Data are mean � SD. Statistically significant differences between groups: \*\*P \< 0.01,
\*\*\*P \< 0.001. VL20: group that trained with a mean velocity loss of 20% in each set (n = 12); VL40: group that trained with
a mean velocity loss of 40% in each set (n = 10). Warm-up repetitions are excluded.

6

and initial repetition velocities matched the expected
target velocities for every training session. Subjects
from the VL40 group reached muscle failure during
27.0 � 4.2 sets (56.3% of total training sets). The
mean magnitude of velocity loss matched
that intended for each group (41.9 � 1.7% vs
20.4 � 1.5% for VL40 and VL20, respectively).
Total work was significantly greater for VL40 compared to VL20 (200.6 � 47.1 vs 127.5 � 15.2 kJ,
P \< 0.001).

Isoinertial strength assessments

No significant ‘group’ 9 ‘time’ interactions were
observed for any of the isoinertial strength variables
analyzed. Following the training intervention, statistically significant increases were observed in 1RM
strength (18.0% and 13.4%), AV (12.5% and 6.0%),
and AV\<1 (21.7% and 13.7%) for VL20 and VL40
groups, respectively (Table 2). AV>1 improved in
VL20 (6.2%, P \< 0.01) but remained unchanged
(+1.0%, P = 0.62) in VL40 (group 9 time interaction P = 0.09).

Vertical jump and sprint ability

CMJ height was increased by 9.5% in the VL20
group (P \< 0.001), while it remained unchanged
(+3.5% P = 0.07) in the VL40 (group 9 time interaction P \< 0.05) (Table 2). No statistically significant changes in sprint running performance were
observed in any group (Table 2).

Fiber type distribution and MHC content

The mean CSA of muscle fibers increased similarly
in both groups (+10.5%, time effect P \< 0.01). The
increase in mean CSA was explained by an increase

Velocity loss as a strength training variable

of type I CSA (+9.9% time effect P \< 0.01) and la T
con minuscula: type II (� +11.1% time effect P \< 0.05)
(Table 3). No significant changes were observed in
muscle fiber type (ATPase analysis method,
Table 3). However, the percentage of MHC-IIX
decreased in VL40 (P \< 0.001) while it remained
unchanged in VL20 (group 9 time interaction
P \< 0.05, Table 3).

Anatomical muscle CSA and volume

Total quadriceps femoris volume (Fig. 3a) was
increased by 6.0% (time effect P \< 0.05). This was
explained by a significant increase of VM volume
(Fig. 3c) in both groups, whereas the VL+VI volume
(Fig. 3d) only increased in the VL40 group
(group 9 time interaction, P = 0.05). RF muscle
volume remained unaltered in both groups (Fig. 3b).
The total length of RF (Pre 31.6 � 2.0 vs Post
31.1 � 2.2 cm for VL40, and Pre 32.0 � 2.2 vs Post
31.7 � 1.9 cm for VL20), VM (Pre 33.2 � 1.9 vs
Post 33.8 � 2.6 cm for VL40, and Pre 33.7 � 2.1 vs
Post 33.6 � 1.4 cm for VL20), and VL+VI (Pre
33.3 � 3.0 vs Post 34.0 � 2.3 cm for VL40, and Pre
33.4 � 1.9 vs Post 33.0 � 2.0 cm for VL20) muscles
did not change for any group before and after the
RT intervention.

Discussion

To the best of our knowledge, this is the first study
that has analyzed the effect of two isoinertial RT
programs differing in the magnitude of velocity loss
experienced during each exercise set on muscle structure and performance. Although both intervention
groups trained using the same relative loading magnitude (%1RM) in each session and performed
repetitions at maximal intended velocity, a low mag

Table 2. Changes in selected neuromuscular performance variables from pre- to post-training for each group

VL40 VL20 P-value P-value group 9
time time

Pre Post P-value Pre Post P-value effect interaction

1RM (kg) 104.5 � 15.1 118.6 � 20.4 \<0.001 106.5 � 12.2 125.2 � 12.3 \<0.001 \<0.001 0.26
AV (m/s) 0.95 � 0.06 1.01 � 0.09 0.03 0.95 � 0.06 1.06 � 0.06 \<0.001 \<0.001 0.09
AV>1 (m/s) 1.22 � 0.03 1.23 � 0.08 0.62 1.21 � 0.05 1.29 � 0.07 0.005 0.02 0.09
AV\<1 (m/s) 0.72 � 0.04 0.81 � 0.07 0.001 0.72 � 0.04 0.87 � 0.07 \<0.001 \<0.001 0.12
CMJ (cm) 41.0 � 4.3 42.5 � 5.8 0.06 40.5 � 6.0 44.2 � 6.0 \<0.001 \<0.001 0.04
T20 (s) 2.99 � 0.09 3.02 � 0.08 0.25 3.00 � 0.11 2.99 � 0.10 0.45 0.73 0.18

Data are mean � SD; P-values calculated using Bonferroni adjustment.
VL20: group that trained with a mean velocity loss of 20% in each set (n = 12); VL40: group that trained with a mean velocity loss of 40% in each
set (n = 10).
1RM: one-repetition maximum squat strength, AV: average MPV attained against absolute loads common to pre- and post-test in the squat progressive loading test; AV>1: average MPV attained against absolute loads common to pre- and post-test that were moved faster than 1 m/s; AV\<1: average MPV attained against absolute loads common to pre- and post-test that were moved slower than 1 m/s; CMJ: countermovement jump height,
T20: 20-m sprint time.

7

Pareja-Blanco et al.

Table 3. Changes in muscle cross-sectional areas and muscle fiber types percentages, from pre- to post-training for each group, using myofibrillar
adenosine triphosphatase histochemestry

VL40 VL20 P-value P-value group 9
time time

Pre Post P-value Pre Post P-value effect interaction

CSA muscle fibers (ATPase)
CSA (lm \[2\] ) 4935 � 690 5438 � 788 0.02 4800 � 691 5217 � 701 0.05 0.005 0.77
CSA-I (lm \[2\] ) 4314 � 676 4798 � 804 0.01 4070 � 834 4346 � 873 0.13 0.007 0.41
CSA-IIA (lm \[2\] ) 5584 � 1259 6233 � 998 0.05 5708 � 893 6169 � 716 0.16 0.03 0.68
CSA-IIAX (lm \[2\] ) 4619 � 1022 5260 � 962 0.04 4936 � 740 5146 � 744 0.49 0.06 0.31
CSA-IIX (lm \[2\] ) 4406 � 1037 4927 � 1502 0.30 4130 � 930 4853 � 1016 0.16 0.09 0.77
Percentage fiber type (ATPase)
Type I (%) 44.3 � 10.4 47.5 � 9.8 0.25 45.9 � 15.7 43.7 � 13.4 0.39 0.78 0.15
Type IIC (%) 0.1 � 0.2 0.3 � 0.6 0.87 0.5 � 1.1 1.6 � 4.9 0.22 0.34 0.48
Type IIA (%) 36.5 � 9.7 36.4 � 7.6 0.98 33.6 � 10.2 38.5 � 11.0 0.13 0.31 0.29
Type IIAX (%) 11.2 � 6.1 12.0 � 6.3 0.71 13.7 � 11.2 10.1 � 7.6 0.07 0.32 0.13
Type IIX (%) 7.8 � 7.0 3.8 � 5.0 0.04 6.3 � 8.9 6.1 � 8.2 0.91 0.10 0.14
Percentage fiber area (ATPase)
Type I (%) 38.8 � 10.0 42.5 � 10.7 0.14 38.9 � 16.3 37.9 � 16.2 0.68 0.43 0.18
Type IIC (%) 0.1 � 0.2 0.3 � 0.6 0.23 0.6 � 1.2 1.8 � 5.3 0.39 0.34 0.47
Type IIA (%) 42.4 � 11.7 41.8 � 9.1 0.59 39.4 � 12.7 43.8 � 12.8 0.69 0.48 0.36
Type IIAX (%) 11.2 � 6.8 11.9 � 6.8 0.77 15.1 � 11.9 10.5 � 6.8 0.06 0.24 0.12
Type IIX (%) 7.5 � 6.9 3.6 � 4.8 0.05 6.0 � 8.2 6.1 � 8.2 0.96 0.15 0.13
MHC percentage
MHC-I (%) 42.8 � 7.9 45.5 � 7.6 0.30 40.0 � 8.6 39.3 � 9.3 0.77 0.56 0.33
MHC-IIA (%) 42.6 � 3.8 47.3 � 5.9 0.05 42.9 � 5.4 45.8 � 8.6 0.18 0.02 0.56
MHC-IIX (%) 14.6 � 8.9 7.2 � 7.6 \<0.001 17.0 � 7.4 14.8 � 8.2 0.18 0.001 0.04

Data are mean � SD; P-values calculated using Bonferroni adjustment. VL20: group that trained with a mean velocity loss of 20% in each set
(n = 12); VL40: group that trained with a mean velocity loss of 40% in each set (n = 10).
CSA, cross-sectional area; MHC, myosin heavy chain.

nitude of velocity loss within each set (20%) was
associated with similar squat strength gains, but
greater enhancement in vertical jump height than
training with a high velocity loss (40%), although
VL40 performed 40% more repetitions and 36%
more work than VL20 during the 8-week training
intervention. In contrast, training with a higher magnitude of velocity loss (VL40) resulted in a greater
degree of muscle hypertrophy (VL+VI), but with a
significant reduction in the expression of the fastest
myosin isoform (MHC-IIX).
Since the pioneering study by Delorme (1945),
training to muscle failure has been assumed by many
as a governing principle of RT (Campos et al., 2002;
Drinkwater et al., 2005) and it has become frequent
practice in gyms and fitness facilities all across the
world, being advocated on the assumption that it
maximizes gains in strength and muscle mass. The
possibility of ending a resistance exercise set several
repetitions short of failure seems at odds with the
common perception of the superiority of training to
failure. This may likely explain why the magnitude of
velocity loss experienced in a set (the independent
variable in the present study) or, what is equivalent,
the possibility of manipulating the actual number of
repetitions performed in relation to the maximum
number that can be completed (S�anchez-Medina &
Gonz�alez-Badillo, 2011), has received little research
attention to date. Some studies (Rooney et al., 1994;

8

Drinkwater et al., 2005) reported that RT to failure
induced greater strength gains compared with training
not leading to failure. However, in these two studies
repetition velocity during training was not monitored,
nor it was intended to be maximal. Training at maximal voluntary velocity has recently been shown to be
of paramount importance for maximizing strength
gains and athletic performance (jumping ability)
(Gonz�alez-Badillo et al., 2014; Pareja-Blanco et al.,
2014). In agreement with the present findings, it has
been reported that muscle failure might not be necessary to attain greater strength gains (Folland et al.,
2002; Izquierdo et al., 2006; Izquierdo-Gabarren
et al., 2010; Sampson & Groeller, 2015). In the present study, similar gains in 1RM were observed for
VL20 vs VL40 (18.0% vs 13.4%). In the same line,
Izquierdo et al. (2006) reported that 16 weeks of RT
to failure vs not to failure resulted in similar 1RM

~
gains ( 22%) in the bench press and parallel squat.
However, to the best of our knowledge, in previous
studies on this topic, the impact of RT on dynamic
muscle performance was limited to the evaluation of
maximum strength disregarding potential effects at

–
different regions of the load velocity relationship.
In the present investigation, we assessed changes
in average velocity attained against all absolute loads
common to Pre and Post SQ tests, from light to
heavy, as well as changes in CMJ height. The VL20
group obtained similar squat strength gains and even

Velocity loss as a strength training variable

Fig. 3. Changes in muscle volume following 8 weeks of velocity-based resistance training for: (a) Whole quadriceps femoris;
(b) rectus femoris (RF); (c) vastus medialis (VM); and (d) vastus lateralis plus vastus intermedius (VL+VI). Data are
mean � SD. VL20: group that trained with a mean velocity loss of 20% in each set (n = 12); VL40: group that trained with a
mean velocity loss of 40% in each set (n = 10). Intra-group significant differences from Pre to Post: \*\*P \< 0.01, \*\*\*P \< 0.001.
Significant group 9 time interaction: \[#\] P \< 0.05.

greater improvements in CMJ height than VL40
(Table 2). Interestingly, VL40 did not improve in the
fastest actions, such as velocity developed against
lighter loads and CMJ height. A plausible explanation for these findings might be the significantly
greater number of slow repetitions (MPV \<0.6 m/s)
performed by VL40 (Fig. 2), which could be responsible for the significant reduction of IIX fiber type
observed only in this group. It is known that force,
velocity, and power output gradually decrease as the
number of repetitions increase during a set performed to failure, concomitant with an increased
purine nucleotide degradation (S�anchez-Medina &
Gonz�alez-Badillo, 2011; Gorostiaga et al., 2012),
which is likely to impair the capacity for maximal
force production or maximal rate of force development (RFD) (Allen et al., 1995), and may increase
the time needed for recovery after training. Conversely, if only low or moderate repetition velocity

~
losses ( 20%) are experienced, higher forces and faster velocities will be achieved during training, while
minimizing fatigue. It is for these reasons that setting

a certain repetition velocity loss limit during RT has
been proposed as a strategy to avoid performing
unnecessarily slow and fatiguing repetitions that
might result in a higher degree of muscle hypertrophy, but could be counterproductive for obtaining
the rapid force production adaptations required by
many sports and athletic disciplines.
Despite the common assumption that training to
muscle failure is needed to maximize the hypertrophic response (Willardson, 2007), only one recent
study (Sampson & Groeller, 2015) has analyzed the
effect of RT leading or not leading to failure on muscle CSA. Sampson and Groeller (2015) observed similar increases in elbow flexors CSA after a 12-week
RT program leading or not to failure, concluding
that reaching repetition failure is not critical to elicit
significant neural and structural muscle changes. In
the present study, we analyzed changes in whole
quadriceps femoris muscle volume using MRI
(79.1 � 1.1 slices per leg), whereas Sampson and
Groeller (2015) only calculated the CSA as the mean
across three slices central to the muscle belly. It has

9

Pareja-Blanco et al.

been suggested that the multiple-slice MRI scanning
allows a more accurate quantification of changes in
whole muscle volume (Folland & Williams, 2007).
Limiting the analysis to a few slices precludes any
definitive conclusion regarding muscle volume
changes (Aagaard et al., 2001) or potential differences
in regional adaptations (Folland & Williams, 2007;
Sanchis-Moysi et al., 2010, 2011, 2012). In the present
study, VL40 resulted in greater hypertrophy (VL+VI:
9.0% vs 3.4%, P \< 0.05) than VL20. However, VL20
also increased quadriceps volume (4.6%) and fiber
size (9.8%), despite performing ~58% of the training
volume done by VL40. The greater mechanical and
metabolic stress (S�anchez-Medina & Gonz�alezBadillo, 2011), hormonal response, and muscle
damage associated to typical RT to failure protocols
(Willardson, 2007; Schoenfeld, 2010) might explain
the greater hypertrophic response observed for VL40,
as it has been reported that mechanical tension,
metabolic stress, and muscle damage may mediate
hypertrophic adaptations (Schoenfeld, 2010).
Resistance training to failure is known to elicit IIX
to IIA fiber transformation (Staron et al., 1991; Kraemer et al., 1995; Andersen & Aagaard, 2000; Campos
et al., 2002; Andersen et al., 2005, 2010). The present
study shows that the magnitude of velocity loss experienced during a training set may be a critical factor in
inducing a fast-to-slow phenotypic remodeling in
muscle fiber type, as VL40 showed greater reduction
of IIX fiber type than VL20 (detected MHC analysis,
Table 3). When resistance exercise sets are performed
to or very close to muscle failure, actual training velocities end up being slow resulting in high levels of metabolic and mechanical fatigue (S�anchez-Medina &
Gonz�alez-Badillo, 2011; Gorostiaga et al., 2012). As
the neuromuscular system specifically adapts to the
stimuli it is faced with (Spiering et al., 2008), it is likely
that the stress associated to RT to failure induces
greater adaptations in the slower and more resistant
to fatigue muscle fiber types. As the MHC-IIX isoform is the fastest and most powerful one (Harridge,
2007), a reduction in the percentage of IIX fibers and
in the percent area of type IIX muscle fibers (as
observed for VL40 in this study) might be detrimental
for sports where very rapid movements and explosive
force production are decisive for performance. A previous study (Andersen et al., 2010) observed a
decrease in the early phase of the relative RFD following 14 weeks of RT to failure. This decrease in the
early relative RFD was positively correlated
(r = 0.61, P \< 0.05) with the decrease in the area percentage of type IIX muscle fibers (Andersen et al.
2010). These findings might explain the lower gains in
vertical jump (CMJ) performance observed for VL40
compared to VL20 in the present study (Table 2).
In summary, this study shows that the magnitude
of velocity loss experienced during RT is a variable

10

that should be taken into account when configuring
the resistance exercise stimulus. Our findings suggest
that a higher loss of repetition velocity during training (VL40) seems suitable to maximize the hypertrophic response, but tends to induce a fast-to-slow
shift in muscle phenotype. Despite the greater hypertrophic adaptations observed in VL40, VL20 training resulted in similar strength squat gains and
superior improvements in vertical jump performance. These results were obtained despite the fact
that VL20 only performed 60% of the total training
volume carried out by VL40.

Limitations

Due to the small number of subjects studied, we cannot rule out a type II error when comparing the two
types of training. In fact, several variables show interaction P-values above 0.05 but close to 0.10, indicating that training with a lower loss of repetition
velocity, i.e. with less fatigue at the end of each set,
may result in more favorable adaptations to enhance
performance in dynamic exercises than here reported.
Another limitation is that the study did not include a
control group and as a consequence the influence of
environmental variables cannot be ruled out.

Perspectives

The magnitude of velocity loss experienced during
RT appears to influence functional and structural
muscle adaptations. Once a moderate velocity loss is
achieved during a training set, performing more repetitions does not seem to elicit further strength gains
and may even be detrimental for improving explosive
strength. This is particularly relevant for many athletes for whom resistance training is not only focused
on maximizing muscle hypertrophy but rather it is
mainly aimed at improving dynamic performance in
the most efficient way.

Key words: Muscle strength, training to failure,
muscle hypertrophy, fiber type, magnetic resonance
imaging.

Conflicts of interest

The authors declare no conflicts of interest.

Source of funding

This study was funded by the Spanish Ministry of
Science and Innovation (National R&D&I Plan
2008–2011; grant reference DEP2011-29501). The
funders had no role in study design, data collection
and analysis, decision to publish or preparation of
the manuscript.

Velocity loss as a strength training variable

References

Aagaard P, Andersen JL. Correlation
between contractile strength and
myosin heavy chain isoform
composition in human skeletal
muscle. Med Sci Sports Exerc 1998:
30: 1217–1222.
Aagaard P, Andersen JL, DyhrePoulsen P, Leffers AM, Wagner A,
Magnusson SP, Halkjaer-Kristensen
J, Simonsen EB. A mechanism for
increased contractile strength of
human pennate muscle in response
to strength training: changes in
muscle architecture. J Physiol 2001:
534: 613–623.

Ahtiainen JP, Pakarinen A, Kraemer
WJ, Hakkinen K. Acute hormonal
and neuromuscular responses and
recovery to forced vs maximum
repetitions multiple resistance
exercises. Int J Sports Med 2003: 24:
410–418.
Allen DG, Lannergren J, Westerblad
H. Muscle cell function during
prolonged activity: cellular
mechanisms of fatigue. Exp Physiol
1995: 80: 497–527.
Andersen JL, Aagaard P. Myosin
heavy chain IIX overshoot in human
skeletal muscle. Muscle Nerve 2000:

23: 1095–1104.

Andersen LL, Andersen JL,
Magnusson SP, Suetta C, Madsen
JL, Christensen LR, Aagaard P.
Changes in the human muscle forcevelocity relationship in response to
resistance training and subsequent
detraining. J Appl Physiol 2005: 99:
87–94.

Andersen LL, Andersen JL, Zebis MK,
Aagaard P. Early and late rate of
force development: differential
adaptive responses to resistance
training? Scand J Med Sci Sports
2010: 20: e162–e169.

Barnouin Y, Butler-Browne G, Voit T,
Reversat D, Azzabou N, Leroux G,
Behin A, McPhee JS, Carlier PG,
Hogrel JY. Manual segmentation of
individual muscles of the quadriceps
femoris using MRI: a reappraisal. J

–
Magn Reson Imaging 2014: 40: 239
247\.

Biral D, Betto R, Danieli-Betto D,
Salviati G. Myosin heavy chain
composition of single fibres from
normal human muscle. Biochem J

1988: 250: 307–308.

Blomstrand E, Ekblom B. The needle
biopsy technique for fibre type
determination in human skeletal
muscle-a methodological study. Acta
Physiol Scand 1982: 116: 437–442.
Brooke MH, Kaiser KK. Muscle fiber
types: how many and what kind?
Arch Neurol 1970: 23: 369–379.

Campos GE, Luecke TJ, Wendeln HK,
Toma K, Hagerman FC, Murray
TF, Ragg KE, Ratamess NA,
Kraemer WJ, Staron RS. Muscular
adaptations in response to three
different resistance-training regimens:
specificity of repetition maximum
training zones. Eur J Appl Physiol
2002: 88: 50–60.

Delorme T. Restoration of muscle
power by heavy-resistance exercises.

–
J Bone Joint Surg Am 1945: 27: 645
667\.

Drinkwater EJ, Lawton TW, Lindsell
RP, Pyne DB, Hunt PH, McKenna
MJ. Training leading to repetition
failure enhances bench press strength
gains in elite junior athletes. J

–
Strength Cond Res 2005: 19: 382
388\.

Folland JP, Irish CS, Roberts JC, Tarr
JE, Jones DA. Fatigue is not a
necessary stimulus for strength gains
during resistance training. Br J
Sports Med 2002: 36: 370–374.
Folland JP, Williams AG. The
adaptations to strength training:
morphological and neurological
contributions to increased strength.
Sports Med 2007: 37: 145–168.
Gonz�alez-Badillo JJ, Rodr�ıguez-Rosell
D, S�anchez-Medina L, Gorostiaga
EM, Pareja-Blanco F. Maximal
intended velocity training induces
greater gains in bench press
performance than deliberately slower
half-velocity training. Eur J Sport Sci
2014: 14: 772–781.
Gonz�alez-Badillo JJ, S�anchez-Medina
L. Movement velocity as a measure
of loading intensity in resistance
training. Int J Sports Med 2010: 31:
347–352.
Gorostiaga EM, Navarro-Am�ezqueta I,
Calbet JA, Hellsten Y, Cusso R,
Guerrero M, Granados C, GonzalezIzal M, Ib�anez J, Izquierdo M.~
Energy metabolism during repeated
sets of leg press exercise leading to
failure or not. PLoS ONE 2012: 7:

e40621.
Harridge SD. Plasticity of human
skeletal muscle: gene expression to
in vivo function. Exp Physiol 2007:
92: 783–797.
Harridge SD, Bottinelli R, Canepari
M, Pellegrino M, Reggiani C,
Esbjornsson M, Balsom PD, Saltin
B. Sprint training, in vitro and
in vivo muscle function, and myosin
heavy chain expression. J Appl
Physiol 1998: 84: 442–449.
Izquierdo M, Ib�anez J, Gonz~ �alezBadillo JJ, Hakkinen K, Ratamess
NA, Kraemer WJ, French DN,
Eslava J, Altadill A, Asi�ain X,

Gorostiaga EM. Differential effects
of strength training leading to failure
versus not to failure on hormonal
responses, strength, and muscle
power gains. J Appl Physiol 2006:
100: 1647–1656.
Izquierdo-Gabarren M, Gonz�alez de
Txabarri Exposito R, Garc�ıa-Pallar�es
J, S�anchez-Medina L, de Villarreal
ES, Izquierdo M. Concurrent
endurance and strength training not
to failure optimizes performance
gains. Med Sci Sports Exerc 2010:
42: 1191–1199.

Kraemer WJ, Patton JF, Gordon SE,
Harman EA, Deschenes MR,
Reynolds K, Newton RU, Triplett
NT, Dziados JE. Compatibility of
high-intensity strength and
endurance training on hormonal and
skeletal muscle adaptations. J Appl
Physiol 1995: 78: 976–989.
Larsson B, Andersen JL, Kadi F, Bjork
J, Gerdle B. Myosin heavy chain
isoforms influence surface EMG
parameters: a study of the trapezius
muscle in cleaners with and without
myalgia and in healthy teachers. Eur
J Appl Physiol 2002: 87: 481–488.
Lee RC, Wang Z, Heo M, Ross R,
Janssen I, Heymsfield SB. Totalbody skeletal muscle mass:
development and cross-validation of
anthropometric prediction models.
Am J Clin Nutr 2000: 72:

796–803.
Mogensen M, Bagger M, Pedersen PK,
Fernstrom M, Sahlin K. Cycling
efficiency in humans is related to low
UCP3 content and to type I fibres
but not to mitochondrial efficiency.
J Physiol 2006: 571: 669–681.
Pareja-Blanco F, Rodr�ıguez-Rosell D,
S�anchez-Medina L, Gorostiaga EM,
Gonz�alez-Badillo JJ. Effect of
movement velocity during resistance
training on neuromuscular
performance. Int J Sports Med 2014:
35: 916–924.

Perez-Gomez J, Olmedillas H,
Delgado-Guerra S, Ara I, VicenteRodr�ıguez G, Ortiz RA, Chavarren
J, Calbet JA. Effects of weight lifting
training combined with plyometric
exercises on physical fitness, body
composition, and knee extension
velocity during kicking in football.
Appl Physiol Nutr Metab 2008: 33:
501–510.
Rooney KJ, Herbert RD, Balnave RJ.
Fatigue contributes to the strength
training stimulus. Med Sci Sports
Exerc 1994: 26: 1160–1164.
Sampson JA, Groeller H. Is repetition
failure critical for the development of
muscle hypertrophy and strength?

11

Pareja-Blanco et al.

Scand J Med Sci Sports 2015:
doi:10.1111/sms.12445
S�anchez-Medina L, Gonz�alez-Badillo
JJ. Velocity loss as an indicator of
neuromuscular fatigue during
resistance training. Med Sci Sports
Exerc 2011: 43: 1725–1734.
S�anchez-Medina L, Gonz�alez-Badillo
JJ, P�erez CE, Pallar�es JG. Velocityand power-load relationships of the
bench pull vs. bench press exercises.
Int J Sports Med 2014: 35: 209–216.
S�anchez-Medina L, P�erez CE,
Gonz�alez-Badillo JJ. Importance of
the propulsive phase in strength
assessment. Int J Sports Med 2010:
31: 123–129.
Sanchis-Moysi J, Idoate F, Izquierdo
M, Calbet JA, Dorado C. Iliopsoas
and gluteal muscles are asymmetric
in tennis players but not in soccer
players. PLoS ONE 2011: 6: e22858.
Sanchis-Moysi J, Idoate F, Olmedillas
H, Guadalupe-Grau A, Alayon S,

12

Carreras A, Dorado C, Calbet JA.
The upper extremity of the
professional tennis player: muscle
volumes, fiber-type distribution and
muscle strength. Scand J Med Sci
Sports 2010: 20: 524–534.
Sanchis-Moysi J, Idoate F, SerranoSanchez JA, Dorado C, Calbet JA.
Muscle hypertrophy in prepubescent
tennis players: a segmentation MRI
study. PLoS ONE 2012: 7: e33622.
Schoenfeld BJ. The mechanisms of
muscle hypertrophy and their
application to resistance training. J

–
Strength Cond Res 2010: 24: 2857
2872\.
Schott J, McCully K, Rutherford OM.
The role of metabolites in strength
training. II. Short versus long
isometric contractions. Eur J Appl
Physiol 1995: 71: 337–341.
Smith PK, Krohn RI, Hermanson GT,
Mallia AK, Gartner FH, Provenzano
MD, Fujimoto EK, Goeke NM,

Olson BJ, Klenk DC. Measurement
of protein using bicinchoninic acid.
Anal Biochem 1985: 150: 76–85.
Spiering BA, Kraemer WJ, Anderson
JM, Armstrong LE, Nindl BC,
Volek JS, Maresh CM. Resistance
exercise biology: manipulation of
resistance exercise programme
variables determines the responses of
cellular and molecular signalling

–
pathways. Sports Med 2008: 38: 527
540\.
Staron RS, Leonardi MJ, Karapondo
DL, Malicky ES, Falkel JE,
Hagerman FC, Hikida RS. Strength
and skeletal muscle adaptations in
heavy-resistance-trained women after
detraining and retraining. J Appl
Physiol 1991: 70: 631–640.
Willardson JM. The application of
training to failure in periodized
multiple-set resistance exercise
programs. J Strength Cond Res
2007: 21: 628–631.
