"""Sink implementations for secrets-sync."""

from .base import build_sink

__all__ = ["build_sink"]
