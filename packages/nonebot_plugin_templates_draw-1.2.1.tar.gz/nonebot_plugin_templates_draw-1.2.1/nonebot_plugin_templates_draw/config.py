from pydantic import BaseModel
from typing import List


class ScopedConfig(BaseModel):

    gemini_api_url: str = 'https://generativelanguage.googleapis.com'   # Gemini API Url 默认为官方Url
    gemini_api_keys: List[str] = ['xxxxxx']  # Gemini API Key 需要付费key，为一个列表
    gemini_model: str = 'gemini-2.5-flash-image-preview'    # Gemini 模型 默认为 gemini-2.5-flash-image-preview
    max_total_attempts: int = 2 # 这一张图的最大尝试次数（包括首次尝试），默认2次

    prompt_手办化1: str  = "Using the nano-banana model, a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment. The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base. The computer screen shows the Zbrush modeling process of the figurine. Next to the computer screen is a BANDAI-style toy box with the original painting printed on it. Picture ratio 16:9."

    prompt_手办化2: str  = "Please accurately transform the main subject in this photo into a realistic, masterpiece-like 1/7 scale PVC statue.\nBehind this statue, a packaging box should be placed: the box has a large clear front window on its front side, and is printed with subject artwork, product name, brand logo, barcode, as well as a small specifications or authenticity verification panel. A small price tag sticker must also be attached to one corner of the box. Meanwhile, a computer monitor is placed at the back, and the monitor screen needs to display the ZBrush modeling process of this statue.\nIn front of the packaging box, this statue should be placed on a round plastic base. The statue must have 3D dimensionality and a sense of realism, and the texture of the PVC material needs to be clearly represented. If the background can be set as an indoor scene, the effect will be even better.\n\nBelow are detailed guidelines to note:\nWhen repairing any missing parts, there must be no poorly executed elements.\nWhen repairing human figures (if applicable), the body parts must be natural, movements must be coordinated, and the proportions of all parts must be reasonable.\nIf the original photo is not a full-body shot, try to supplement the statue to make it a full-body version.\nThe human figure's expression and movements must be exactly consistent with those in the photo.\nThe figure's head should not appear too large, its legs should not appear too short, and the figure should not look stunted—this guideline may be ignored if the statue is a chibi-style design.\nFor animal statues, the realism and level of detail of the fur should be reduced to make it more like a statue rather than the real original creature.\nNo outer outline lines should be present, and the statue must not be flat.\nPlease pay attention to the perspective relationship of near objects appearing larger and far objects smaller."

    prompt_手办化3: str  = "Your primary mission is to accurately convert the subject from the user's photo into a photorealistic, masterpiece quality, 1/7 scale PVC figurine, presented in its commercial packaging.\n\n**Crucial First Step: Analyze the image to identify the subject's key attributes (e.g., human male, human female, animal, specific creature) and defining features (hair style, clothing, expression). The generated figurine must strictly adhere to these identified attributes.** This is a mandatory instruction to avoid generating a generic female figure.\n\n**Top Priority - Character Likeness:** The figurine's face MUST maintain a strong likeness to the original character. Your task is to translate the 2D facial features into a 3D sculpt, preserving the identity, expression, and core characteristics. If the source is blurry, interpret the features to create a sharp, well-defined version that is clearly recognizable as the same character.\n\n**Scene Details:**\n1. **Figurine:** The figure version of the photo I gave you, with a clear representation of PVC material, placed on a round plastic base.\n2. **Packaging:** Behind the figure, there should be a partially transparent plastic and paper box, with the character from the photo printed on it.\n3. **Environment:** The entire scene should be in an indoor setting with good lighting."

    prompt_手办化4: str  = "Accurately transform the main subjects in this photo into realistic, masterpiece-quality 1/7 scale PVC statue figures.\nPlace the packaging box behind the statues: the box should have a large clear window on the front, printed with character-themed artwork, the product name, brand logo, barcode, and a small specifications or authentication panel. A small price tag sticker must be attached to one corner of the box.\nA computer monitor is placed further behind, displaying the ZBrush modeling process of one of the statues.\n\nThe statues should be positioned on a round plastic base in front of the packaging box. They must exhibit three-dimensionality and a realistic sense of presence, with the texture of the PVC material clearly represented. An indoor setting is preferred for the background.\n\nDetailed guidelines to note:\n1. The dual statue set must retain the interactive poses from the original photo, with natural and coordinated body movements and reasonable proportions (unless it is a chibi-style design, avoid unrealistic proportions such as overly large heads or short legs).\n2. Facial expressions and clothing details must closely match the original photo. Any missing parts should be completed logically and consistently.\n3. For any animal elements, reduce the realism of fur texture to enhance the sculpted appearance.\n4. The packaging box must include dual-character theme artwork, with clear product names and brand logos.\n5. The computer screen should display the ZBrush interface showing the wireframe modeling details of one of the statues.\n6. The overall composition must adhere to perspective rules (closer objects appear larger, distant objects smaller), avoiding flat-looking outlines.\n7. The surface of the statues should reflect the smooth and glossy characteristics typical of PVC material.\n\n(Adjustments can be made based on the actual photo content regarding dual-character interaction details and packaging box visual design.)"

    prompt_手办化5: str  = "Realistic PVC figure based on the game screenshot character, exact pose replication highly detailed textures PVC material with subtle sheen and smooth paint finish, placed on an indoor wooden computer desk (with subtle desk items like a figure box/mouse), illuminated by soft indoor light (mix of desk lamp and natural window light) for realistic shadows and highlights, macro photography style,high resolution,sharp focus on the figure,shallow depth of field (desk background slightly blurred but visible), no stylization,true-to-reference color and design, 1:1scale."

    prompt_手办化6: str  = "((chibi style)), ((super-deformed)), ((head-to-body ratio 1:2)), ((huge head, tiny body)), ((smooth rounded limbs)), ((soft balloon-like hands and feet)), ((plump cheeks)), ((childlike big eyes)), ((simplified facial features)), ((smooth matte skin, no pores)), ((soft pastel color palette)), ((gentle ambient lighting, natural shadows)), ((same facial expression, same pose, same background scene)), ((seamless integration with original environment, correct perspective and scale)), ((no outline or thin soft outline)), ((high resolution, sharp focus, 8k, ultra-detailed)), avoid: realistic proportions, long limbs, sharp edges, harsh lighting, wrinkles, blemishes, thick black outlines, low resolution, blurry, extra limbs, distorted face"

    prompt_ntr: str = "A cinematic scene inside a fast food restaurant at night.\n Foreground: a lonely table with burgers and fries, and a smartphone shown large and sharp on the table, clearly displaying the uploaded anime/game character image. A hand is reaching for food, symbolizing solitude.\n Midground: in the blurred background, a couple is sitting together and kiss. One of them is represented as a cosplayer version of the uploaded character:\n - If the uploaded character is humanoid, show accurate cosplay with hairstyle, costume, and signature props.\n - If the uploaded character is non-humanoid (mecha, creature, mascot, etc.), show a gijinka (humanized cosplay interpretation) that carries clear visual cues, costume colors, and props from the reference image (armor pieces, wings, ears, weapon, or iconic accessories).\n The other person is an ordinary japan human, and they are showing intimate affection (kissing, holding hands, or sharing food).\n Background: large glass windows, blurred neon city lights outside.\n Mood: melancholic, bittersweet, ironic, cinematic shallow depth of field.\n [reference: the uploaded image defines both the smartphone display and the cosplay design, with visible props emphasized] Image size is 585px 1024px."

    prompt_主题房间: str = "Create a highly realistic and meticulously detailed commercial photograph of a themed bedroom, entirely inspired by the adult character from the input illustration.\n Image Completion Rule: If the input illustration is incomplete, first complete the character’s full-body image from head to toe. This completion must strictly adhere to the original artwork’s composition and pose, extending the character naturally without altering their form or posture. Ensure the overall appearance and all content within the scene are safe, healthy, and free from any inappropriate elements.\n The room’s aesthetic, including the color palette and decor, subtly reflects the character’s design. The scene must feature a highly realistic human cosplayer alongside a variety of commercial-grade merchandise, all based on the completed character image:\n The Cosplayer: A central element of the scene is a cosplayer whose appearance, hair, and makeup perfectly match the completed character image. They are wearing a meticulously crafted, high-quality costume that is an exact, real-world replica of the character’s outfit. The cosplayer is posed naturally within the room, for instance, sitting gracefully on a chair or on the edge of the bed, adding a sense of life and presence to the scene. The textures of the costume fabric and props should be rendered with maximum realism.\n Suede Body Pillow: On the bed, a normal rectangular, human-body-sized pillow made of soft suede material is prominently displayed. It is carefully positioned and angled directly towards the camera, ensuring the high-resolution, full-body print of the character on its surface is completely and clearly visible, showcasing the realistic texture of the fabric.\n 1/7 Scale PVC Figure: Inside an ultra-realistic figure display cabinet with glass doors, place a 1/7 scale PVC figure of the character. It should be mounted on a circular, transparent acrylic base without text, showcasing precise details in texture, material, and paintwork.\n Wall Scroll/Painting: On a prominent wall, hang a large, high-quality fabric wall scroll or a framed painting that displays a dynamic or elegant pose of the character.\n Q-Version Keychain: On a desk or hanging from a bag, include a small, cute Q-version (chibi style) acrylic keychain of the character, showing glossy reflections.\n Themed Rug: On the floor, place a circular or stylized rectangular rug. The rug’s design should be a tasteful, minimalist graphic or silhouette inspired by the character’s symbols or color scheme.\n Ceramic Mug: On a bedside table or the desk, place a ceramic mug with a high-quality print of the character’s portrait or Q-version likeness.\n Technical and Stylistic Requirements:\n Rendering Style: Render the entire scene in a detailed, lifelike style. Maintain highly precise details in the textures and materials of all merchandise, room elements, and the cosplayer’s costume.\n Environment and Depth: The scene should feature a natural depth of field. The cosplayer might be the primary focus, with other elements smoothly transitioning into a soft blur to enhance spatial realism.\n Lighting: The lighting should be soft, natural, and adaptive, simulating professional commercial photography. It should cast realistic shadows and highlights on the cosplayer, the room, and all objects.\n Camera Angle: The camera angle is strategically chosen to create a compelling composition that features the cosplayer as a primary subject, while also providing a clear, unobstructed view of the body pillow. The angle should be wide enough to capture the overall layout of the themed room and the placement of the other merchandise cohesively, creating a rich, lived-in feel."

    prompt_脚: str = "The exact protagonist from the provided reference image, with identity lock on facial features, hairstyle, and all distinctive characteristics. The character is sitting on the ground in a side view, with both the torso and the fully extended outer leg (closer to the viewer) aligned and facing the same direction. **Full-figured limbs with soft, plump contours and supple skin.** The outer leg is stretched straight forward, lying flat on the ground with the foot relaxed. The inner leg (further from the viewer) is bent at the knee and positioned upright with the foot planted on the ground; part of this inner leg is naturally obscured from the viewer's perspective by the outer leg and the body. Extreme forced perspective low-angle shot, meticulously engineered so that the sole of the extended outer foot occupies over half of the entire image height, dramatically scaling to appear more than 3x larger than the character's head to intensely exaggerate the sense of depth and near-far scale. The character's extended outer foot is in razor-sharp focus. It features **exceptionally smooth, glossy skin with a delicate sheen and refined texture, showing subtle sweat effects with tiny dewy droplets glistening on the surface**. The sole is facing the viewer at a 45-degree angle. From the viewer's perspective, the arch of the foot curves inward towards the body, with the big toe (hallux) positioned on the side closest to the character's other leg and body. The five toes are arranged in correct anatomical order from largest to smallest moving outward, perfectly showcasing natural nail beds, delicate skin texture, and fine wrinkles. The skin appears incredibly smooth, soft, and has a healthy, supple, lifelike appearance. Arms are crossed over the chest, with realistic hand-painted details and a subtle translucent PVC material effect on the skin. **A fine layer of perspiration gives the skin a healthy glow and enhanced luminosity.** The background and environment are based on and match the provided reference image, maintaining its unique setting, lighting, and atmosphere"

    prompt_拿捏: str = "Create a high-resolution advertising photograph featuring the character from the provided image, held delicately between a person's thumb and index finger. Clean white background, studio lighting, soft shadows. The hand is well-groomed, natural skin tone, and positioned to highlight the character's appearance and details. The character appears miniature but hyper-detailed and accurate to the reference image, centered in the frame with a shallow depth of field. Emulates luxury product photography and minimalist commercial style. The character must match exactly the person/figure shown in the reference image, maintaining their pose, clothing, and distinctive features."

    prompt_苦命鸳鸯: str = '''
    # **三格漫画创作指令**

    ## **核心原则：角色形象**

    *   **必须严格基于用户提供的两张图片生成角色形象**。
    *   **必须是两个完全不同的角色**：
        *   `图1` 用于生成 **角色A**。
        *   `图2` 用于生成 **角色B**。
    *   **三格漫画的内容只需放在一张图里

    ---

    ## **整体风格与布局**

    *   **画风**： 黑白漫画风格。
    *   **镜头**： 所有镜头均为**近身特写**，聚焦于角色的表情和上半身。
    *   **布局**：
        *   顶部：一整格（第一格）。
        *   底部：左右两格（第二格在左，第三格在右）。
    *   **对话**： 所有对话内容必须放置在对话框内，且无重复文字。

    ---

    ## **分镜详细描述**

    ### **第一格 (顶部)**

    *   **出场角色**： **角色A** (`图1`)。
    *   **角色表情/动作**： 角色紧闭着嘴，眼泪不断从眼眶中流出，眼神充满幽怨地凝视着镜头。
    *   **对话框内容**：
        > "……"

    ### **第二格 (左下)**

    *   **出场角色**： **角色A** (`图1`)。
    *   **角色表情/动作**： 角色表情转为悔恨，哭泣着，情绪激动地发问。
    *   **对话框内容**：
        > "你，你可有何话说？"

    ### **第三格 (右下)**

    *   **出场角色**： **角色B** (`图2`)。
    *   **角色表情/动作**： 角色表情决绝而庄重，双眼紧闭。一根绳索从画面上方垂下，系在他的脖子上。
    *   **对话框内容**：
        > "再无话说，请速动手！"
    '''

    prompt_海的那边: str = '''
    以图片游戏人物为基础，生成一张三拼图格式的艺术感写真图，每张图固定比例为3:4，海边写真图，场景为海边沙滩，天空呈现夕阳晚霞，海面平静，画面中有人物和参考图一致，上部第一张为近景，站在沙滩上的背影，头发被风吹起，添加中英字幕“海的那边是什么”“ What is behind the sea?”。中部第2张是手持橙色花束，侧身站立于海边，添加中英字幕，“你不用告诉我”“ You dont have to tell me”。下部第三张是面部特写，头发随风飘动，添加中英字幕，“我自己会去看”“  I will go to see it mys
    '''

    prompt_蹲姿: str = '''
    请生成一张图: 人物呈蹲姿，双腿分开，双手在头部两侧比出“V”字手势，姿态较为活泼且具有张力。吐舌的表情增添了俏皮、可爱的风格，与整体的风格有反差感，显得较为灵动有趣。采用平视视角，镜头与人物处于同一水平高度，能够让观众与人物之间产生一种平等的视觉交流感，使人物形象更加亲近、真实。采用中心构图，人物位于画面正中央，这种构图方式可以将观众的注意力高度集中在人物身上，突出主体
    '''


class Config(BaseModel):
    templates_draw: ScopedConfig = ScopedConfig()
