# API endpoints
API_BASE_URL = "https://intelliclima.fantinicosmi.it"
API_MONO = "/server_v1_mono/api/"
