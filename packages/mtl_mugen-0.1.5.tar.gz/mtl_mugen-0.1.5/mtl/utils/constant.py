MTL_VERSION = "20250729.01"
DEBUGGER_VERSION = 1

LEGAL_COMPILER_FLAGS = [
    "no_implicit_conversion", "no_numeric", "no_implicit_bool", "no_implicit_enum",
    "no_changestate_expression", "no_compiler_internal", "allow_changestate_target"
]