import bellows.cli

# Just being able to import is a small test..
