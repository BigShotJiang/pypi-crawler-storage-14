"""Ingestion module for Contextinator."""
from .async_service import AsyncIngestionService

__all__ = ["AsyncIngestionService"]
