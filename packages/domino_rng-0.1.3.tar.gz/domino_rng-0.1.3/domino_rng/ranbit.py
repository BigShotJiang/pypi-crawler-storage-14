import time

class ranbit:
    def __init__(self):
        # Use current time in milliseconds as seed
        self.x = int(time.time() * 1000) & 0xFFFFFFFF

    def rfind(self):
        x = self.x
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= (x >> 17) & 0xFFFFFFFF
        x ^= (x << 5) & 0xFFFFFFFF
        self.x = x & 0xFFFFFFFF
        return x