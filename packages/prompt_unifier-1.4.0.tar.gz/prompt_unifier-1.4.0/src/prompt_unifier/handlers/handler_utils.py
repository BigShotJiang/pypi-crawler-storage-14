"""Shared utilities for tool handlers to reduce code duplication."""

from rich.console import Console

# Shared console instance
console = Console()
