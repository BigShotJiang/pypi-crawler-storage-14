"""Unofficial client to retrieve location data from Invoxia™ GPS trackers."""

from gps_tracker import client
from gps_tracker.client import AsyncClient, Client, Config, Device, Tracker, TrackerData

try:
    from importlib.metadata import PackageNotFoundError, version  # pragma: no cover

    __version__ = version(__name__)
except PackageNotFoundError:  # pragma: no cover
    __version__ = "unknown"
finally:
    del version, PackageNotFoundError

__all__ = [
    "__version__",
    "client",
    "AsyncClient",
    "Client",
    "Config",
    "Device",
    "Tracker",
    "TrackerData",
]
