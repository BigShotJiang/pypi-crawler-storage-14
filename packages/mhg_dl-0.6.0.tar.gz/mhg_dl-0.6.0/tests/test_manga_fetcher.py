import requests
from bs4 import BeautifulSoup

from mhg_dl.manga_fetcher import (
    manga_fetch,
    MangaInfo,
    fetch_base_info,
    fetch_chapter_list,
    analyze_chapter,
    make_img_list,
)


class FakeResponse:
    def __init__(self, text: str, status_code: int = 200):
        self.text = text
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"status {self.status_code}")


def test_fetch_base_info_and_chapter_list():
    # Build a minimal HTML page matching selectors used in fetcher
    html = '''
    <html>
      <body>
        <div class="book-title"><h1>测试漫</h1></div>
        <div class="book-cover"><p><img src="//cover.example/img.jpg"/></p></div>
        <div class="book-detail">
            <ul class="detail-list cf">
            <li></li>
            <li><span></span><span><a href="/author/1">作者名</a></span></li>
            </ul>
        </div>
        <h4><span>单话</span></h4>
        <div class="chapter-list">
          <ul>
            <li><span>第一话</span><a href="/comic/123/1001.html">link</a></li>
            <li><span>第二话</span><a href="/comic/123/1002.html">link</a></li>
          </ul>
        </div>
      </body>
    </html>
    '''

    soup = BeautifulSoup(html, "html.parser")
    # Updated: fetch_base_info now takes cid and returns MangaInfo
    manga = fetch_base_info("123", soup)
    assert isinstance(manga, MangaInfo)
    assert manga.title == "测试漫"
    assert manga.cover == "https://cover.example/img.jpg"
    assert manga.author == "作者名"

    chapter_groups = fetch_chapter_list(soup)
    assert isinstance(chapter_groups, dict)
    assert "单话" in chapter_groups
    chapters = chapter_groups["单话"]
    # reversed order in implementation, so expect keys
    assert list(chapters.keys()) == ["第二话", "第一话"]


def test_manga_fetch_handles_http_error(monkeypatch):
    # Simulate network error
    def fake_get(*args, **kwargs):
        raise requests.RequestException("network")

    monkeypatch.setattr("requests.get", fake_get)
    info = manga_fetch("no-such-cid")
    assert isinstance(info, MangaInfo)
    assert info.title == ""


def test_analyze_chapter_uses_unpack(monkeypatch):
    # page with a script containing the special eval pattern
    script_html = '<script>some();["\\x65\\x76\\x61\\x6c"]</script>'
    page_html = f"<html><body>{script_html}</body></html>"

    def fake_get(url, headers=None):
        return FakeResponse(page_html)

    monkeypatch.setattr("requests.get", fake_get)

    # patch unpack to return a dict we control
    # Updated: sl keys changed to e and m
    monkeypatch.setattr("mhg_dl.manga_fetcher.unpack", lambda s: {"files": ["a.jpg"], "sl": {"e": 1, "m": 2}, "path": "/p/"})

    result = analyze_chapter("http://example/chapter.html")
    assert isinstance(result, dict)
    assert result["files"] == ["a.jpg"]


def test_make_img_list_builds_urls():
    # Updated: sl keys changed to e and m
    chapter_data = {
        "files": ["1.jpg", "2.jpg"],
        "path": "/path/to/",
        "sl": {"e": 111, "m": 222},
    }
    result = make_img_list(chapter_data)
    assert len(result) == 2
    for file_name, url in zip(chapter_data["files"], result):
        assert file_name in url
        assert str(chapter_data["sl"]["e"]) in url
        assert str(chapter_data["sl"]["m"]) in url