"""Test package for mysqltuner_mcp."""
