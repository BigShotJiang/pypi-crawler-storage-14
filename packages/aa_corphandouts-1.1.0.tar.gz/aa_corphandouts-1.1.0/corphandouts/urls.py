"""Routes."""

from django.urls import path

from . import views

app_name = "corphandouts"

urlpatterns = [
    path("", views.handout_index, name="index"),
    path(
        "doctrine/<int:doctrine_id>",
        views.doctrine_fitting_reports,
        name="doctrine_report",
    ),
    path(
        "doctrine/<int:doctrine_id>/fits",
        views.show_all_bad_fits_for_doctrine,
        name="doctrine_fit_report_all",
    ),
    path(
        "doctrine/<int:doctrine_id>/fits/<int:fitting_report_id>",
        views.fitting_report_view,
        name="doctrine_fit_report",
    ),
    path("fitting/<int:fitting_id>", views.fitting, name="fitting"),
    path("modal_loader_body", views.modal_loader_body, name="modal_loader_body"),
    path("citadels", views.citadel_index, name="citadel-index"),
]
