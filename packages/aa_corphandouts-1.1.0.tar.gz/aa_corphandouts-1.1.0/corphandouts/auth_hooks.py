from django.utils.translation import gettext_lazy as _

from allianceauth import hooks
from allianceauth.services.hooks import MenuItemHook, UrlHook

from . import urls
from .utils import user_has_citadel_fitting_access


class CorporationHandoutMenuItem(MenuItemHook):
    """Class showing the corphandouts part of the application to authorized users"""

    def __init__(self):
        # setup menu entry for sidebar
        MenuItemHook.__init__(
            self,
            _("Corporation handouts"),
            "fas fa-boxes-packing fa-fw",
            "corphandouts:index",
            navactive=["corphandouts:"],
        )

    def render(self, request):
        if request.user.has_perm("corphandouts.basic_access"):
            return MenuItemHook.render(self, request)
        return ""


class CitadelsMenuItem(MenuItemHook):
    """Class showing the citadel fittings part of the application to authorized users"""

    def __init__(self):
        # setup menu entry for sidebar
        MenuItemHook.__init__(
            self,
            _("Citadel corrections"),
            "fa-brands fa-fort-awesome fa-fw",
            "corphandouts:citadel-index",
            navactive=["corphandouts:"],
        )

    def render(self, request):
        if user_has_citadel_fitting_access(request.user):
            return MenuItemHook.render(self, request)
        return ""


@hooks.register("menu_item_hook")
def register_menu():
    return CorporationHandoutMenuItem()


@hooks.register("menu_item_hook")
def register_citadels_menu():
    return CitadelsMenuItem()


@hooks.register("url_hook")
def register_urls():
    return UrlHook(urls, "corphandouts", r"^corphandouts/")
