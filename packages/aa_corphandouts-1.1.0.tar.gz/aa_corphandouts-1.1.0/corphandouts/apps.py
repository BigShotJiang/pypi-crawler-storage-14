from django.apps import AppConfig


class CorpHandoutsCongif(AppConfig):
    name = "corphandouts"
    label = "corphandouts"
    verbose_name = "corphandouts"
