"""Plugin to check the fitting of corporation handouts"""

# pylint: disable = invalid-name
default_app_config = "corphandouts.apps.CorpHandoutsConfig"

__version__ = "1.1.0"
