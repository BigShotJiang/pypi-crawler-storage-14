"""unimpeded: Universal model comparison & parameter estimation."""

from unimpeded._version import __version__  # noqa: F401
