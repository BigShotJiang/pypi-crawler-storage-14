from .. import register_command as register_command
from ...exceptions import CommandError as CommandError
from ...utils.logging import log_info as log_info
from ...utils.project_root import find_project_root as find_project_root
from ...utils.workspace_detector import WorkspaceDetector as WorkspaceDetector
from ..base import BaseCommand as BaseCommand
from typing import Any

class TestCommand(BaseCommand):
    __test__: bool
    @property
    def name(self) -> str: ...
    @property
    def help(self) -> str: ...
    def add_arguments(self, parser) -> None: ...
    def execute(self, *args: Any, **kwargs: Any) -> None: ...
