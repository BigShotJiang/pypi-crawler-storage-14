"""Format path handler module."""

import os
from pathlib import Path

from ...utils.logging import log_info
from .python_formatter import (
    _run_format_command,
    format_examples,
    format_tools_scripts,
    format_with_python_tools,
)
from .rust_formatter import format_rust_code


class FormatPathHandler:
    """Handler for formatting paths."""

    def format_specified_paths(self, paths, env, quiet, unsafe=False):
        """Format specified paths."""
        from pathlib import Path as PathClass

        for path in paths:
            # If path is already a Path-like object, use it directly
            # Otherwise, create a Path object from the string
            if (
                hasattr(path, "exists")
                and hasattr(path, "is_file")
                and hasattr(path, "is_dir")
                and hasattr(path, "name")
            ):
                path_obj = path
            else:
                path_obj = PathClass(path)

            if path_obj.exists():
                if path_obj.is_file() and path_obj.suffix == ".py":
                    # Format individual Python file with ruff only
                    try:
                        ruff_check_cmd = ["uv", "run", "ruff", "check", "--fix"]
                        if unsafe:
                            ruff_check_cmd.append("--unsafe-fixes")
                        ruff_check_cmd.append(str(path_obj))

                        _run_format_command(
                            ruff_check_cmd, env, quiet, passthrough=not quiet
                        )

                        # Also run ruff format for code formatting
                        _run_format_command(
                            [
                                "uv",
                                "run",
                                "ruff",
                                "format",
                                str(path_obj),
                            ],
                            env,
                            quiet,
                            passthrough=not quiet,
                        )
                    except Exception as e:
                        if not quiet:
                            print(f"Warning: Failed to format {path}: {e}")
                elif path_obj.is_dir():
                    # Format directory with ruff only
                    # Special handling for rust directory - format both Python and Rust code
                    format_with_python_tools(str(path_obj), env, quiet, unsafe=unsafe)
                    if path_obj.name == "rust":
                        format_rust_code(str(path_obj), env, quiet)
            else:
                if not quiet:
                    print(f"Warning: Path {path} does not exist")

    def format_defaults(
        self, current_path: Path, env: dict, quiet: bool, unsafe: bool, for_lint: bool
    ) -> None:
        src_path = current_path / "src"
        tools_path = current_path / "tools"
        examples_path = current_path / "examples"
        rust_path = current_path / "rust"
        if src_path.exists():
            log_info("Formatting src directory...")
            format_with_python_tools(str(src_path), env, quiet, unsafe=unsafe)
        if tools_path.exists():
            log_info("Formatting tools directory...")
            format_with_python_tools(str(tools_path), env, quiet, unsafe=unsafe)
        if examples_path.exists():
            log_info("Formatting examples directory...")
            format_with_python_tools(str(examples_path), env, quiet, unsafe=unsafe)
        # Type stubs generation removed from format; handled in build dist
        if rust_path.exists() and not for_lint:
            log_info("Formatting Rust code...")
            format_rust_code(str(rust_path), env, quiet)
