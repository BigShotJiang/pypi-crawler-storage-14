from .. import Command as Command, register_command as register_command
from ...exceptions import CommandError as CommandError
from ...utils.logging import log_error as log_error, log_info as log_info
from .utils.exceptions import InitEnvError as InitEnvError
from .utils.git_initializer import GitInitializer as GitInitializer
from .utils.initializer import Initializer as Initializer
from .utils.platform_adapter import PlatformAdapter as PlatformAdapter
from typing import Any

class InitCommand(Command):
    def __init__(self) -> None: ...
    @property
    def name(self) -> str: ...
    @property
    def help(self) -> str: ...
    def add_arguments(self, parser) -> None: ...
    def execute(self, *args: Any, **kwargs: Any) -> None: ...
