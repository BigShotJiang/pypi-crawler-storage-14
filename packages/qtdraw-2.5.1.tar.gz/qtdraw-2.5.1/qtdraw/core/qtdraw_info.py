__version__ = "2.5.1"
__date__ = "2021 -"
__author__ = "Hiroaki Kusunose"

import importlib.resources as res
import qtdraw

__top_dir__ = res.files(qtdraw).parent
