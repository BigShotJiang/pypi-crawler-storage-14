"""Custom Element Scanner for MoAI-ADK

This module provides functionality to scan for user-created custom elements
(agents, commands, skills, hooks) that are not part of the official MoAI-ADK template
installation. Unlike the existing detection functions that use template-based filtering,
this scanner compares against fresh installation file lists to identify truly custom elements.

The scanner is used during updates to provide users with a list of their custom
elements that can be selectively restored from backup.
"""

import logging
from pathlib import Path
from typing import Dict, List, Set


# Forward declaration for type hints
class TemplateSkill:
    pass

from moai_adk.core.migration.template_utils import (
    _get_template_agent_names,
    _get_template_command_names,
    _get_template_hook_names,
    _get_template_skill_names,
)

logger = logging.getLogger(__name__)


class CustomElementScanner:
    """Scanner for detecting user-created custom elements in MoAI-ADK projects.

    This scanner identifies elements that are not part of the official MoAI-ADK
    template by comparing against fresh installation file lists, providing a more
    accurate detection of user-created content.
    """

    def __init__(self, project_path: Path):
        """Initialize the scanner.

        Args:
            project_path: Path to the MoAI-ADK project directory
        """
        self.project_path = project_path
        self.template_elements = self._get_template_elements()

    def _get_template_elements(self) -> Dict[str, Set[str]]:
        """Get template element names from fresh installation.

        Returns:
            Dictionary with element types as keys and sets of element names as values
        """
        return {
            "skills": _get_template_skill_names(),
            "commands": _get_template_command_names(),
            "agents": _get_template_agent_names(),
            "hooks": _get_template_hook_names(),
        }

    def scan_custom_elements(self) -> Dict[str, List[Path]]:
        """Scan for user-created custom elements.

        Scans the project directory for agents, commands, skills, and hooks that are
        not part of the official MoAI-ADK template installation.

        Returns:
            Dictionary with element types as keys and lists of custom element paths as values

        Example:
            {
                "agents": [Path("/project/.claude/agents/my-agent.md")],
                "commands": [Path("/project/.claude/commands/my-command.md")],
                "skills": [Path("/project/.claude/skills/my-skill/")],
                "hooks": [Path("/project/.claude/hooks/moai/my-hook.py")]
            }
        """
        custom_elements = {}

        # Scan agents (all files in .claude/agents/, excluding template files)
        custom_elements["agents"] = self._scan_custom_agents()

        # Scan commands (all files in .claude/commands/moai/, excluding template files)
        custom_elements["commands"] = self._scan_custom_commands()

        # Scan skills (all directories in .claude/skills/, excluding moai-* patterns)
        custom_elements["skills"] = self._scan_custom_skills()

        # Scan hooks (all files in .claude/hooks/moai/, excluding template files)
        custom_elements["hooks"] = self._scan_custom_hooks()

        return custom_elements

    def _scan_custom_agents(self) -> List[Path]:
        """Scan for custom agents.

        Returns:
            List of paths to custom agent files
        """
        agents_dir = self.project_path / ".claude" / "agents"

        if not agents_dir.exists():
            return []

        custom_agents = []
        template_agents = self.template_elements["agents"]

        for file_path in agents_dir.rglob("*.md"):
            # Check if this is a template file
            if file_path.name not in template_agents:
                relative_path = file_path.relative_to(self.project_path)
                custom_agents.append(relative_path)

        return custom_agents

    def _scan_custom_commands(self) -> List[Path]:
        """Scan for custom commands.

        Returns:
            List of paths to custom command files
        """
        commands_dir = self.project_path / ".claude" / "commands"

        if not commands_dir.exists():
            return []

        custom_commands = []
        template_commands = self.template_elements["commands"]

        # Scan moai subdirectory specifically
        moai_commands_dir = commands_dir / "moai"
        if moai_commands_dir.exists():
            for file_path in moai_commands_dir.glob("*.md"):
                # Check if this is a template file
                if file_path.name not in template_commands:
                    relative_path = file_path.relative_to(self.project_path)
                    custom_commands.append(relative_path)

        # Also scan other subdirectories under commands
        for subdir in commands_dir.iterdir():
            if subdir.is_dir() and subdir.name != "moai":
                for file_path in subdir.rglob("*.md"):
                    relative_path = file_path.relative_to(self.project_path)
                    custom_commands.append(relative_path)

        return custom_commands

    def _scan_custom_skills(self) -> List[TemplateSkill]:
        """Scan for custom skills.

        Returns:
            List of TemplateSkill objects representing custom skill directories
        """
        skills_dir = self.project_path / ".claude" / "skills"

        if not skills_dir.exists():
            return []

        custom_skills = []
        template_skills = self.template_elements["skills"]

        for skill_dir in skills_dir.iterdir():
            if skill_dir.is_dir():
                # Skip if this is a template skill (moai-* pattern)
                if skill_dir.name.startswith("moai-"):
                    continue

                # Check if this is in template skills
                if skill_dir.name not in template_skills:
                    relative_path = skill_dir.relative_to(self.project_path)
                    custom_skills.append(
                        TemplateSkill(
                            name=skill_dir.name,
                            path=relative_path,
                            has_skill_md=(skill_dir / "SKILL.md").exists()
                        )
                    )

        return custom_skills

    def _scan_custom_hooks(self) -> List[Path]:
        """Scan for custom hooks.

        Returns:
            List of paths to custom hook files
        """
        hooks_dir = self.project_path / ".claude" / "hooks"

        if not hooks_dir.exists():
            return []

        custom_hooks = []
        template_hooks = self.template_elements["hooks"]

        # Scan moai subdirectory specifically
        moai_hooks_dir = hooks_dir / "moai"
        if moai_hooks_dir.exists():
            for file_path in moai_hooks_dir.rglob("*.py"):
                # Check if this is a template file
                if file_path.name not in template_hooks:
                    relative_path = file_path.relative_to(self.project_path)
                    custom_hooks.append(relative_path)

        # Also scan other subdirectories under hooks
        for subdir in hooks_dir.iterdir():
            if subdir.is_dir() and subdir.name != "moai":
                for file_path in subdir.rglob("*.py"):
                    relative_path = file_path.relative_to(self.project_path)
                    custom_hooks.append(relative_path)

        return custom_hooks

    def get_custom_elements_display_list(self) -> List[Dict[str, str]]:
        """Get formatted list of custom elements for display.

        Returns:
            List of dictionaries containing element info for CLI display
        """
        custom_elements = self.scan_custom_elements()
        display_list = []
        index = 1

        # Add agents
        for agent_path in custom_elements["agents"]:
            display_list.append({
                "index": index,
                "type": "agent",
                "name": agent_path.stem,
                "path": str(agent_path),
                "display_name": f"{agent_path.stem} (agent)"
            })
            index += 1

        # Add commands
        for command_path in custom_elements["commands"]:
            display_list.append({
                "index": index,
                "type": "command",
                "name": command_path.stem,
                "path": str(command_path),
                "display_name": f"{command_path.stem} (command)"
            })
            index += 1

        # Add skills
        for skill in custom_elements["skills"]:
            display_list.append({
                "index": index,
                "type": "skill",
                "name": skill.name,
                "path": str(skill.path),
                "display_name": f"{skill.name} (skill)"
            })
            index += 1

        # Add hooks
        for hook_path in custom_elements["hooks"]:
            display_list.append({
                "index": index,
                "type": "hook",
                "name": hook_path.stem,
                "path": str(hook_path),
                "display_name": f"{hook_path.stem} (hook)"
            })
            index += 1

        return display_list

    def get_element_count(self) -> int:
        """Get total count of custom elements.

        Returns:
            Total number of custom elements found
        """
        custom_elements = self.scan_custom_elements()
        return (
            len(custom_elements["agents"]) +
            len(custom_elements["commands"]) +
            len(custom_elements["skills"]) +
            len(custom_elements["hooks"])
        )


class TemplateSkill:
    """Represents a template skill directory."""

    def __init__(self, name: str, path: Path, has_skill_md: bool):
        """Initialize a TemplateSkill.

        Args:
            name: Name of the skill directory
            path: Path to the skill directory
            has_skill_md: Whether the skill has a SKILL.md file
        """
        self.name = name
        self.path = path
        self.has_skill_md = has_skill_md


def create_custom_element_scanner(project_path: str | Path) -> CustomElementScanner:
    """Factory function to create a CustomElementScanner.

    Args:
        project_path: Path to the MoAI-ADK project directory

    Returns:
        Configured CustomElementScanner instance

    Example:
        >>> scanner = create_custom_element_scanner("/path/to/project")
        >>> elements = scanner.scan_custom_elements()
        >>> print(f"Found {len(elements['agents']) custom agents")
    """
    return CustomElementScanner(Path(project_path).resolve())
