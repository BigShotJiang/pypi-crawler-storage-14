"""Legendgroup names and there titles for plotly plots"""

# Groups
# actual
ACTUAL_AVERAGE: str = "actual_average"
ACTUAL_SUM: str = "actual_sum"
ACTUAL_INDIVIDUAL: str = "actual_individual"
# required
REQUIRED_AVERAGE: str = "required_average"
REQUIRED_SUM: str = "required_sum"
REQUIRED_INDIVIDUAL: str = "required_individual"

# Titles
ACTUAL_AVERAGE_TITLE: str = "Actual average"
ACTUAL_SUM_TITLE: str = "Actual sum"
ACTUAL_INDIVIDUAL_TITLE: str = "Actual individual"
# required
REQUIRED_AVERAGE_TITLE: str = "Required average"
REQUIRED_SUM_TITLE: str = "Required sum"
REQUIRED_INDIVIDUAL_TITLE: str = "Required individual"
