SUM: str = "sum"
AVERAGE: str = "average"
INDIVIDUAL: str = "individual"
ALL_MODES: list[str] = [SUM, AVERAGE, INDIVIDUAL]
