*****************************************
API documentation: station-control-client
*****************************************

:Version: |version|
:Date: |today|

This is the documentation of the IQM station-control client library.

Contents
========

.. toctree::
   :maxdepth: 2

   API
   Changelog <changelog>
   License <license>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
