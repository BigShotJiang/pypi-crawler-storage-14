.. _changelog:

=========
CHANGELOG
=========

.. include:: ../CHANGELOG.rst
   :literal:
