import os
import time
import tempfile
import multiprocessing as mp
from functools import partial
from pdf2image import convert_from_path
import pytesseract
from PyPDF2 import PdfReader

pytesseract.pytesseract.tesseract_cmd = r"D:\Program Files\Tesseract-OCR\tesseract.exe"


def converter_pdf_para_imagens(pdf_path, pasta_temp, dpi, fmt="jpeg"):
    imgs = convert_from_path(
        pdf_path,
        dpi=dpi,
        fmt=fmt,
        output_folder=pasta_temp,
        output_file="page",
        paths_only=True
    )
    return imgs


def ocr_tesseract_pagina(img_path, lang="por"):
    try:
        return pytesseract.image_to_string(img_path, lang=lang)
    except Exception as e:
        return f"[ERRO TESSERACT {img_path}] {str(e)}"


def ocr_pdf_parcial(
    pdf_path: str,
    n_processos=None,
    dpi: int = 200,
    max_ocr_pages: int = 100
):
    """
    Executa OCR com Tesseract nas primeiras páginas e
    leitura nativa (PdfReader) nas demais.
    """
    if n_processos is None:
        n_processos = mp.cpu_count()

    pasta_temp = tempfile.mkdtemp(prefix="ocr_tess_")
    imagens = converter_pdf_para_imagens(pdf_path, pasta_temp, dpi=dpi)
    total_paginas = len(imagens)

    paginas_para_ocr = imagens[:max_ocr_pages]
    paginas_para_pdfreader = range(max_ocr_pages, total_paginas)

    t0 = time.time()
    with mp.Pool(processes=n_processos) as pool:
        resultados_ocr = pool.map(
            partial(ocr_tesseract_pagina, lang="por"),
            paginas_para_ocr
        )

    resultados_reader = []
    if paginas_para_pdfreader:
        try:
            reader = PdfReader(pdf_path)
            for i in paginas_para_pdfreader:
                try:
                    texto_pagina = reader.pages[i].extract_text()
                    if not texto_pagina:
                        texto_pagina = f"[Página {i+1}] (sem texto detectado)"
                except:
                    texto_pagina = f"[Erro ao ler página {i+1}]"
                resultados_reader.append(texto_pagina)
        except Exception as e:
            resultados_reader.append(f"[ERRO PDF READER] {str(e)}")

    tempo = time.time() - t0

    for f in imagens:
        os.remove(f)
    os.rmdir(pasta_temp)

    texto_final = "\n\n".join(resultados_ocr + resultados_reader)
    return texto_final, tempo
