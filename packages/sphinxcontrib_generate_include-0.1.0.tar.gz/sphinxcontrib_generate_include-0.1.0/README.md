# sphinxcontrib-generate-include

Sphinx extension to allow calling Python functions and including their output as Markdown,
ReStructuredText or literal in the Sphinx document.

---

**[Read the documentation on ReadTheDocs!](https://sphinxcontrib-generate-include.readthedocs.io/)**

---
