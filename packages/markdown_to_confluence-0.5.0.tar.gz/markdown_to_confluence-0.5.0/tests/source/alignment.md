---
alignment: left
---

<!-- confluence-page-id: 00000000000 -->

## Alignment

![Image with caption](figure/raster.png)
