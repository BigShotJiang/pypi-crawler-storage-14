<!-- confluence-page-id: 00000000000 -->

## Tasklist

### Examples

- [x] **Finished** action
- [ ] **Unfinished** action

### Counter-examples

- first item is not a task
- [x] **finished** action
- [ ] **unfinished** action

<!-- separates consecutive lists -->
- [x] **finished** action
- [ ] **unfinished** action
- last item is not a task
