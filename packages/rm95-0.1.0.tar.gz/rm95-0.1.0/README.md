A library for manipulating RPG Maker 95 (RPG ツクール 95) files.


## Usage

```python
from rm95 import parse_rpg, save_game

rpg = parse_rpg('/path/to/game.RPG')

# Modify initial gold
rpg.party.gold = 9999

save_game('/path/to/output.RPG', rpg)
```

## File Format

This library handles the binary file format used by RPG Maker 95, including:

- Main project file (`.RPG`)
- Event files (`eve*.dat`)
- Enemy data (`ENEMY.DAT`)
- Troop data (`TROOP.DAT`)
- Item data (`ITEM.DAT`)
- Magic data (`MAGIC.DAT`)
- String data (`STRINGS.DAT`)
- Switch names (`SWNAME.DAT`)
- Monster pictures (`MONSTPIC.DAT`)
- Tileset images (`.BMP`) and attributes (`.ATR`)

## Requirements

- Python 3.x
- PIL/Pillow (for image handling)

