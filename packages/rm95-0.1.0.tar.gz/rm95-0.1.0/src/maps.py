from dataclasses import dataclass
import os
from typing import Optional
from PIL import Image

from .reader import Reader
from .events import Event, load_event


@dataclass
class Tileset:
  name: str
  image: Image.Image
  attrs: list[int]

@dataclass
class Map:
  map_id: int
  name: str
  looping: bool
  width: int
  height: int
  parent: Optional[int]
  tileset_a: Tileset
  tileset_b: Tileset
  tileset_c: Tileset
  tileset_d: Tileset
  tiles: list[int]
  events: list[Event]
  encounters: list[tuple[int, int]]

@dataclass
class Area:
  area_id: int
  name: str
  x: int
  y: int
  width: int
  height: int
  parent: int
  exit_x: int
  exit_y: int
  encounters: list[tuple[int, int]]

def read_maps(path: str, r: Reader) -> list[Map]:
  
    map_id = r.read_short()
    r.verify(b'\x00\x00')
    read_maps = True
    maps = []
    while read_maps:
      name = r.read_str(21)

      depth = r.read_int()
      looping = r.read_int()
      if looping == 2:
        x = r.read_int()
        y = r.read_int()
        width = r.read_short()
        height = r.read_short()
        parent = r.read_int()
        for _ in range(8):
          r.verify(b'\x00')
        exit_x = r.read_int()
        exit_y = r.read_int()
        encounters = [(r.read_byte(), r.read_byte() // 2) for _ in range(10)]
        maps.append(Area(map_id, name, x, y, width, height, parent, exit_x, exit_y, encounters))
        map_id = r.read_int()
        if map_id == None:
          read_maps = False
      else:
        for _ in range(8):
          r.verify(b'\xff')
        width = r.read_short()
        height = r.read_short()
        parent = r.read_int()
        if parent == 0xFFFFFFFF:
          parent = None
        garbage = [r.read_byte() for _ in range(16)]

        encounters = [(r.read_byte(), r.read_byte() // 2) for _ in range(10)]

        tileset_a = load_tileset(path, r.read_str())
        tileset_b = load_tileset(path, r.read_str())
        tileset_c = load_tileset(path, r.read_str())
        tileset_d = load_tileset(path, 
        r.read_str())

        tiles = [r.read_short() for _ in range(width * height)]
        read_events = True
        events = []
        shift = 0
        while read_events:
          b = r.read_short()
          if b == None:
            read_events = False
            read_maps = False
          elif b > 0x7fff:
            if b == 0xffff:
              shift += 0x8000
              b = r.read_short()
              if b > 0x7fff:
                shift += b - 0x7fff
                b = r.read_short()
            else:
              shift += b - 0x7fff
              b = r.read_short()
          events.append(Event(shift % width, shift // width, b, None, None, None))
          if events[-1].event_id == 0 or events[-1].event_id == None:
            read_events = False
          shift += 1

        maps.append(Map(map_id, name, looping, width, height, parent, tileset_a, tileset_b, tileset_c, tileset_d, tiles, events, encounters))
        last = events.pop()
        if last.event_id == 0:
            map_id = events.pop().event_id
        else:
            read_maps = False

        for e in events:
          load_event(os.path.dirname(r.name), e)

    return maps
      
def load_tileset(path: str, name: str):
  image = Image.open(os.path.join(path, name + '.BMP'))
  attrs = [i for i in open(os.path.join(path, name + '.ATR'), 'rb').read()]
  return Tileset(name, image, attrs)