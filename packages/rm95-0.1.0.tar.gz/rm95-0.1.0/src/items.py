from dataclasses import dataclass
import os

from .reader import Reader

FILENAME = 'ITEM.DAT'

@dataclass
class Item:
  name: str
  cost: int
  kind: int
  power: int
  equip: int

def load_items(path: str) -> list[Item]:
  r = Reader(os.path.join(path, FILENAME))
  items = []
  for _ in range(100):
    cost = r.read_short()
    equip = r.read_short()
    power = r.read_short()
    kind = r.read_short()
    name = r.read_str(18)
    r.read_short()
    items.append(Item(name, cost, kind, power, equip))
  return items
  