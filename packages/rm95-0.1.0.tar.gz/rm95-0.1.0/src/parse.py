import os
from .enemies import load_enemies
from .items import load_items
from .magic import load_magic
from .maps import read_maps
from .party import read_party
from .reader import Reader
from .game import BGM, RPGGame, ScreenSwitch
from .troops import load_troops


def parse_rpg(path):
  r = Reader(path)

  HEADERS = [
    'RPG Maker 95'.encode('latin-1') + bytes([0] * 18),
    'RPG Maker 95 '.encode('latin-1') + bytes([0] * 17),
    b'\x52\x50\x47\xC2\xB8\xB0\xD9\x39\x35' + bytes([0] * 17),
  ]
  header = r.handle.read(30)
  is_fine = False
  for h in HEADERS:
    if h == header:
      is_fine = True

  version = r.read_str(sep=0)

  bgm: dict[str, BGM] = {}
  for n in ['walking', 'wagon', 'sled', 'boat', 'ship', 'balloon', 'airship', 'combat_start', 'combat', 'victory', 'level_up', 'rest']:
    balance = r.read_short()
    volume = r.read_short()
    mode = r.read_short()
    frequency = r.read_short()
    filename = r.read_str()
    bgm[n] = BGM(balance, volume, mode, frequency, filename)

  screen_switch = ScreenSwitch(r.read_int(), r.read_int(), r.read_int())

  currency = r.read_str(19)
  r.verify(b'\x00\x00')
  message_speed = r.read_short()
  r.verify(b'\x00\x00')
  max_item_amount = r.read_short()
  flags = r.read_short()
  transparent_window = flags & 1 == 1
  save_without_event = flags & 2 == 1

  party = read_party(r)

  dir = os.path.dirname(path)
  maps = read_maps(dir, r)
  enemies = load_enemies(dir)
  troops = load_troops(dir)
  items = load_items(dir)
  magic = load_magic(dir)
  texts = open(os.path.join(dir, 'STRINGS.DAT'), encoding='latin-1').read().split('\n')
  switch_names = open(os.path.join(dir, 'SWNAME.DAT'), encoding='latin-1').read().split('\n')

  return RPGGame(header, version, bgm, screen_switch, currency, message_speed, max_item_amount, transparent_window, save_without_event, party, maps, enemies, troops, items, magic, texts, switch_names)