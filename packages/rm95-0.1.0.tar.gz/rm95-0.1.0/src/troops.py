from dataclasses import dataclass
import os

from .reader import Reader

FILENAME = 'EPARTY.DAT'

@dataclass
class Troop:
  background: int
  land: int
  enemies: list

def load_troops(path: str) -> list[Troop]:
  r = Reader(os.path.join(path, FILENAME))
  troops = []
  for _ in range(100):
    background = r.read_short()
    land = r.read_short()
    enemies = []
    count = r.read_int()
    for i in range(count):
        enemies.append((r.read_int(), r.read_int(), r.read_int()))
    troops.append(Troop(background, land, enemies))
    for _ in range(10 - count):
        r.read_int()
        r.read_int()
        r.read_int()
  return troops  
  