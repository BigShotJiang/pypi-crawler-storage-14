"""RPG Maker 95 file format parser and writer."""

# Core game data structures
from .game import RPGGame, BGM, ScreenSwitch

# Party and character classes
from .party import Party, Character, read_party

# Map and tileset classes
from .maps import Map, Area, Tileset, read_maps, load_tileset

# Enemy and troop classes
from .enemies import Enemy, load_enemies
from .troops import Troop, load_troops

# Item and magic classes
from .items import Item, load_items
from .magic import Spell, load_magic

# Event system
from .events import Event, Page, load_event

# Command classes
from .commands import (
    Command,
    ShowMessageCommand,
    ChangeSwitchCommand,
    ShowChoiceCommand,
    StartBranchCommand,
    ChangeItemsCommand,
    ChangeGoldCommand,
    TeleportCommand,
    LearnMagicCommand,
    ChangePartyCommand,
    OpenShopCommand,
    MoveHeroCommand,
    ChangeHeroSpriteCommand,
    OpenInnCommand,
    RideVehicleCommand,
    RestoreHeroSpriteCommand,
    BringVehicleCommand,
    RestoreVehicleCommand,
    ChangeHeroSpeedCommand,
    ChangeHeroTypeCommand,
    ShowPictureCommand,
    MoveEventCommand,
    RemovePictureCommand,
    ChangeEventSpriteCommand,
    StartEffectCommand,
    ChangeEventSpeedCommand,
    StartBGMCommand,
    ChangeEventMotionCommand,
    RestoreBGMCommand,
    StopHeroCommand,
    StartSoundCommand,
    StopAllMovementCommand,
    StartMovieCommand,
    RestoreMovementCommand,
    ChangeScreenSwitchCommand,
    StartBattleCommand,
    ChangeBGMCommand,
    ChangeTeleportCommand,
    ChangeHPCommand,
    SwitchTeleportsCommand,
    ChangeMPCommand,
    ChangeEscapeCommand,
    RecoverCommand,
    WaitCommand,
    ChangeStateCommand,
    SaveGameCommand,
    ChangeEXPCommand,
    EndGameCommand,
    ChangeLevelCommand,
    command_handlers,
)

# Reader and writer
from .reader import Reader
from .writer import (
    save_game,
    save_event,
    save_enemies,
    save_troops,
    save_items,
    save_magic,
    save_texts,
    save_switch_names,
)

# Parser
from .parse import parse_rpg

# Monster picture utilities
from .monstpic import load_monster_pictures, save_monster_pics
