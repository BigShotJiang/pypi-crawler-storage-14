from dataclasses import dataclass

from .reader import Reader


@dataclass
class Character:
  sprite: int
  in_party: bool
  name: str
  level: int
  hp: int
  mp: int
  strength: int
  power: int
  intelligence: int
  speed: int
  luck: int
  attack_power: int
  defense_power: int
  power_curve: list[int]
  strength_curve: list[int]
  intelligence_curve: list[int]
  speed_curve: list[int]
  luck_curve: list[int]
  params: list[int]
  weapon: int
  armor: int
  shield: int
  helmet: int
  accessory: int
  spells: list[int]
  resistances: list[int]

@dataclass
class Party:
  characters: list[Character]
  starting_items: list[int]
  gold: int
  start_map: int
  start_x: int
  start_y: int

def read_party(r: Reader) -> Party:

  characters = []
  for i in range(8):
    sprite = r.read_int()
    in_party = r.read_int() == 1
    name = r.read_str(18)
    d = r.read_short()
    level = r.read_int()
    hp = r.read_int()
    mp = r.read_int()
    strength = r.read_int()
    power = r.read_int()
    intelligence = r.read_int()
    speed = r.read_int()
    luck = r.read_int()
    attack_power = r.read_int()
    defense_power = r.read_int()
    power_curve = [r.read_byte() for _ in range(100)]
    strength_curve = [r.read_byte() for _ in range(100)]
    intelligence_curve = [r.read_byte() for _ in range(100)]
    speed_curve = [r.read_byte() for _ in range(100)]
    luck_curve = [r.read_byte() for _ in range(100)]
    params = [r.read_int() for _ in range(40)]
    weapon = r.read_byte()
    armor = r.read_byte()
    shield = r.read_byte()
    helmet = r.read_byte()
    accessory = r.read_byte()
    spells = [r.read_byte() for _ in range(100)]
    resistances = [r.read_byte() for _ in range(100)]

    character = Character(sprite, in_party, name, level, hp, mp, strength, power, intelligence, speed, luck, attack_power, defense_power, power_curve,
                            strength_curve, intelligence_curve, speed_curve, luck_curve, params, weapon, armor, shield, helmet, accessory, spells, resistances)
    characters.append(character)

  starting_items = [r.read_short() for _ in range(100)]
  gold = r.read_int()
  start_map = r.read_int()
  start_x = r.read_int()
  start_y = r.read_int()

  return Party(characters, starting_items, gold, start_map, start_x, start_y)