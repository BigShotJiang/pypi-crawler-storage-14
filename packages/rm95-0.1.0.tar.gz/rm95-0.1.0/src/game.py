from dataclasses import dataclass

from .enemies import Enemy
from .magic import Spell
from .maps import Map
from .party import Party
from .troops import Troop
from .items import Item


@dataclass
class BGM:
  balance: int
  volume: int
  mode: int
  frequency: int
  filename: str

@dataclass
class ScreenSwitch:
  map_move: int
  battle1: int
  battle2: int

@dataclass
class RPGGame:
   header: bytes
   version: str
   bgm: dict[str, BGM]
   screen_switch: ScreenSwitch
   currency: str 
   message_speed:int
   max_item_amount:int
   transparent_window: bool
   save_without_event: bool
   party: Party
   maps: list[Map]
   enemies: list[Enemy]
   troops: list[Troop]
   items: list[Item]
   magic: list[Spell]
   texts: list[str]
   switch_names: list[str]