import os
from PIL import Image

from .reader import Reader

FILENAME = 'MONSTPIC.DAT'

def load_monster_pictures(path: str) -> list[Image.Image]:
  
  r = Reader(os.path.join(path, FILENAME))
  images = []
  while True:
    width = r.read_short()
    if width == None:
      break
    height = r.read_short()

    pixels = r.handle.read(width * height)

    palette = []

    for i in range(256):
      blue = r.read_byte()
      green = r.read_byte()
      red = r.read_byte()
      palette.append(red)
      palette.append(green)
      palette.append(blue)
      r.read_byte()
    img = Image.new('P', (width, height))
    img.putpalette(palette)

    # Build image data array efficiently
    img_data = list(range(width * height))
    for i in range(len(pixels)):
      c = pixels[-(i + 1)]
      img_data[i] = c

    # Rearrange pixels to account for horizontal mirroring
    rearranged_data = []
    for y in range(height):
      row_start = y * width
      row = img_data[row_start:row_start + width]
      rearranged_data.extend(reversed(row))

    img.putdata(rearranged_data)

    images.append(img)

  return images

def save_monster_pics(path: str, images: list[Image.Image]):
  with open(os.path.join(path, FILENAME), 'wb') as f:
    for img in images:
      width, height = img.size

      # Write width and height
      f.write(width.to_bytes(2, 'little'))
      f.write(height.to_bytes(2, 'little'))

      # Create pixel array (reversed scanline order like in the load function)
      pixels = []
      for y in range(height):
        for x in range(width):
          pixel = img.getpixel((width - 1 - x, y))
          pixels.append(pixel)

      # Reverse the pixel array to match the file format
      pixels.reverse()
      f.write(bytes(pixels))

      data = img.palette.palette
      for i in range(len(data) // 3):
        f.write(data[i * 3 + 2].to_bytes())
        f.write(data[i * 3 + 1].to_bytes())
        f.write(data[i * 3].to_bytes())
        f.write((0).to_bytes())