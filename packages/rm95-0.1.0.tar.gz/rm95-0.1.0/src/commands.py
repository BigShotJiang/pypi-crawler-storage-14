class Command:
  cmd_id: int

class ShowMessageCommand(Command):
  cmd_id = 1
  message: str
  def __init__(self, message_id: int, wait_for_action: bool, display_at_bottom: bool):
    super().__init__()
    self.message_id = message_id
    self.wait_for_action = wait_for_action
    self.display_at_bottom = display_at_bottom

  def get_data(self):
    flags = int(self.wait_for_action) + int(self.display_at_bottom) * 2
    return (self.message_id, flags)

  @classmethod
  def process(cls, data: list[int]):
    message_id = data[1]
    flags = data[2]
    return cls(message_id, flags & 1 == 1, flags & 2 == 2)

class ChangeSwitchCommand(Command):
  cmd_id = 15
  def __init__(self, switch_id: int, value: bool):
    super().__init__()
    self.switch_id = switch_id
    self.value = value

  def get_data(self):
    return (self.switch_id, int(self.value))

  @classmethod
  def process(cls, data: list[int]):
    switch_id = data[1]
    switch_value = data[2] == 1
    return cls(switch_id, switch_value)

class ShowChoiceCommand(Command):
  cmd_id = 2
  def __init__(self, message_id: int, count: int):
    super().__init__()
    self.message_id = message_id
    self.count = count

  def get_data(self):
    return (self.message_id, self.count)

  @classmethod
  def process(cls, data: list[int]):
    message_id = data[1]
    count = data[2]
    return cls(message_id, count)

class StartBranchCommand(Command):
  cmd_id = 12
  def __init__(self, n: int, branch_id: int):
    super().__init__()
    self.n = n
    self.branch_id = branch_id

  def get_data(self):
    return (self.n, self.branch_id)

  @classmethod
  def process(cls, data: list[int]):
    n = data[1]
    branch_id = data[2]
    return cls(n, branch_id)

class ChangeItemsCommand(Command):
  cmd_id = 20
  def __init__(self, a: int, b: int, item_id: int, relative: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.item_id = item_id
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.item_id * 2 + int(self.relative))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    params = data[3]
    return cls(a, b, params // 2, params % 2 == 1)

class ChangeGoldCommand(Command):
  cmd_id = 10
  def __init__(self, a: int, b: int, relative: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, int(self.relative))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    relative = data[3] == 1
    return cls(a, b, relative)

class TeleportCommand(Command):
  cmd_id = 5
  def __init__(self, map_id: int, x: int, y: int):
    super().__init__()
    self.x = x
    self.y = y
    self.map_id = map_id

  def get_data(self):
    return (self.map_id, self.x, self.y)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2], data[3])

class LearnMagicCommand(Command):
  cmd_id = 18
  def __init__(self, character_id: int, magic_id: int):
    super().__init__()
    self.character_id = character_id
    self.magic_id = magic_id

  def get_data(self):
    return (self.character_id, self.magic_id)

  @classmethod
  def process(cls, data: list[int]):
    character_id = data[1]
    magic_id = data[2]
    return cls(character_id, magic_id)
  
class ChangePartyCommand(Command):
  cmd_id = 23
  def __init__(self, characters: list[int], op: int):
    super().__init__()
    self.characters = characters
    self.op = op

  def get_data(self):
    bitmask = sum(2 ** char_id for char_id in self.characters)
    return (bitmask, self.op)

  @classmethod
  def process(cls, data: list[int]):
    characters = [i for i in range(8) if data[1] & 2 ** i != 0]
    return cls(characters, data[2])
  
class OpenShopCommand(Command):
  cmd_id = 28
  def __init__(self, itemlist_id: int, message_id: int, can_sell: bool):
    super().__init__()
    self.itemlist_id = itemlist_id
    self.message_id = message_id
    self.can_sell = can_sell

  def get_data(self):
    return (self.itemlist_id, self.message_id, 0 if self.can_sell else 1)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2], data[3] == 0)

class MoveHeroCommand(Command):
  cmd_id = 33
  def __init__(self, route_id: int):
    super().__init__()
    self.route_id = route_id

  def get_data(self):
    return (self.route_id,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class ChangeHeroSpriteCommand(Command):
  cmd_id = 40
  def __init__(self, sprite_id: int):
    super().__init__()
    self.sprite_id = sprite_id

  def get_data(self):
    return (0, self.sprite_id)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[2])

class OpenInnCommand(Command):
  cmd_id = 27
  def __init__(self, message_id: int, cost: int, heal_hp: bool, heal_mp: bool, cure_poison: bool, cure_paralysis: bool):
    super().__init__()
    self.message_id = message_id
    self.cost = cost
    self.heal_hp = heal_hp
    self.heal_mp = heal_mp
    self.cure_poison = cure_poison
    self.cure_paralysis = cure_paralysis

  def get_data(self):
    flags = (int(self.heal_hp) * 0x4000 + int(self.heal_mp) * 0x2000 +
             int(self.cure_poison) + int(self.cure_paralysis) * 2)
    return (self.message_id, self.cost, flags)

  @classmethod
  def process(cls, data: list[int]):
    message_id = data[1]
    cost = data[2]
    flags = data[3]
    heal_hp = flags & 0x4000 != 0
    heal_mp = flags & 0x2000 != 0
    cure_poison = flags & 1 != 0
    cure_paralysis = flags & 2 != 0
    return cls(message_id, cost, heal_hp, heal_mp, cure_poison, cure_paralysis)

class RideVehicleCommand(Command):
  cmd_id = 47

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class RestoreHeroSpriteCommand(Command):
  cmd_id = 51

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class BringVehicleCommand(Command):
  cmd_id = 48

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class RestoreVehicleCommand(Command):
  cmd_id = 54

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()

class ChangeHeroSpeedCommand(Command):
  cmd_id = 41
  def __init__(self, a: int, b: int, relative: int):
    super().__init__()
    self.a = a
    self.b = b
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.relative)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2], data[3])
  
class ChangeHeroTypeCommand(Command):
  cmd_id = 53
  def __init__(self, type: int):
    super().__init__()
    self.type = type

  def get_data(self):
    return (self.type,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class ShowPictureCommand(Command):
  cmd_id = 26
  def __init__(self, image_id: int, expand_to_fullscreen: bool, fade_to_black, transparent_border, wait_for_action, effect: int, origin: int):
    super().__init__()
    self.image_id = image_id
    self.expand_to_fullscreen = expand_to_fullscreen
    self.fade_to_black = fade_to_black
    self.transparent_border = transparent_border
    self.wait_for_action = wait_for_action
    self.effect = effect
    self.origin = origin

  def get_data(self):
    flags = (self.origin * 16 + int(self.expand_to_fullscreen) +
             int(self.fade_to_black) * 4 + int(self.transparent_border) * 2 +
             int(self.wait_for_action) * 8 + self.effect * 0x10000)
    return (self.image_id, flags)

  @classmethod
  def process(cls, data: list[int]):
    image_id = data[1]
    flags = data[2]
    expand_to_fullscreen = flags & 1 != 0
    fade_to_black = flags & 4 != 0
    transparent_border = flags & 2 != 0
    wait_for_action = flags & 8 != 0
    effect = flags // 0x10000
    origin = (flags // 16) % 16
    return cls(image_id, expand_to_fullscreen, fade_to_black, transparent_border, wait_for_action, effect, origin)

class MoveEventCommand(Command):
  cmd_id = 35
  def __init__(self, route_id: int):
    super().__init__()
    self.route_id = route_id

  def get_data(self):
    return (self.route_id,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class RemovePictureCommand(Command):
  cmd_id = 31
  def __init__(self, effect: int):
    super().__init__()
    self.effect = effect

  def get_data(self):
    return (self.effect,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class ChangeEventSpriteCommand(Command):
  cmd_id = 42
  def __init__(self, sprite_id: int):
    super().__init__()
    self.sprite_id = sprite_id

  def get_data(self):
    return (self.sprite_id, self.sprite_id)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])

class StartEffectCommand(Command):
  cmd_id = 29
  def __init__(self, effect: int, tone: int):
    super().__init__()
    self.effect = effect
    self.tone = tone

  def get_data(self):
    return (self.effect, self.tone)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2])

class ChangeEventSpeedCommand(Command):
  cmd_id = 43
  def __init__(self, a: int, b: int, relative: int):
    super().__init__()
    self.a = a
    self.b = b
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.relative)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2], data[3])
  
class StartBGMCommand(Command):
  cmd_id = 6
  def __init__(self, bgm_id: int, balance, volume, mode, frequency):
    super().__init__()
    self.bgm_id = bgm_id
    self.balance = balance
    self.volume = volume
    self.mode = mode
    self.frequency = frequency

  def get_data(self):
    return (self.bgm_id, self.balance + self.volume * 0x10000, self.mode + self.frequency * 0x10000)

  @classmethod
  def process(cls, data: list[int]):
    balance = data[2] % 0x10000
    volume = data[2] // 0x10000
    mode = data[3] % 0x10000
    frequency = data[3] // 0x10000
    return cls(data[1], balance, volume, mode, frequency)
  
class ChangeEventMotionCommand(Command):
  cmd_id = 44
  def __init__(self, motion: int):
    super().__init__()
    self.motion = motion

  def get_data(self):
    return (self.motion,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class RestoreBGMCommand(Command):
  cmd_id = 32

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class StopHeroCommand(Command):
  cmd_id = 36

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class StartSoundCommand(Command):
  cmd_id = 21
  def __init__(self, sound_id: int, balance: int, volume: int, mode: int, frequency: int, stop_sound: bool):
    super().__init__()
    self.sound_id = sound_id
    self.balance = balance
    self.volume = volume
    self.mode = mode
    self.frequency = frequency
    self.stop_sound = stop_sound

  def get_data(self):
    return (self.sound_id, self.balance + self.volume * 0x10000, self.mode + self.frequency * 0x10000 + int(self.stop_sound) * 4)

  @classmethod
  def process(cls, data: list[int]):
    balance = data[2] % 0x10000
    volume = data[2] // 0x10000
    mode = data[3] % 0x10000
    frequency = data[3] // 0x10000
    return cls(data[1], balance, volume, mode % 4, frequency, mode // 4 == 1)
  
class StopAllMovementCommand(Command):
  cmd_id = 38

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class StartMovieCommand(Command):
  cmd_id = 14
  def __init__(self, image_id: int, expand_to_fullscreen: bool, fade_to_black, transparent_border, wait_for_action, effect: int, origin: int):
    super().__init__()
    self.image_id = image_id
    self.expand_to_fullscreen = expand_to_fullscreen
    self.fade_to_black = fade_to_black
    self.transparent_border = transparent_border
    self.wait_for_action = wait_for_action
    self.effect = effect
    self.origin = origin

  def get_data(self):
    flags = (self.origin * 16 + int(self.expand_to_fullscreen) +
             int(self.fade_to_black) * 4 + int(self.transparent_border) * 2 +
             int(self.wait_for_action) * 8 + self.effect * 0x10000)
    return (self.image_id, flags)

  @classmethod
  def process(cls, data: list[int]):
    image_id = data[1]
    flags = data[2]
    expand_to_fullscreen = flags & 1 != 0
    fade_to_black = flags & 4 != 0
    transparent_border = flags & 2 != 0
    wait_for_action = flags & 8 != 0
    effect = flags // 0x10000
    origin = (flags // 16) % 16
    return cls(image_id, expand_to_fullscreen, fade_to_black, transparent_border, wait_for_action, effect, origin)

class RestoreMovementCommand(Command):
  cmd_id = 39

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()
  
class ChangeScreenSwitchCommand(Command):
  cmd_id = 50

  def __init__(self, screen: int, effect: int):
    super().__init__()
    self.screen = screen
    self.effect = effect

  def get_data(self):
    return (self.screen, self.effect)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2])
  
class StartBattleCommand(Command):
  cmd_id = 4
  def __init__(self, a: int, b: int, disable_escape: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.disable_escape = disable_escape

  def get_data(self):
    return (self.a, self.b, int(self.disable_escape))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    params = data[3]
    return cls(a, b, params)
  
class ChangeBGMCommand(Command):
  cmd_id = 49
  def __init__(self, bgm_id: int, kind: int, balance: int, volume, mode, frequency):
    super().__init__()
    self.bgm_id = bgm_id
    self.kind = kind
    self.balance = balance
    self.volume = volume
    self.mode = mode
    self.frequency = frequency

  def get_data(self):
    return (self.bgm_id, self.balance + self.volume * 0x10000, self.mode + self.frequency * 0x10000 + self.kind * 256)

  @classmethod
  def process(cls, data: list[int]):
    balance = data[2] % 0x10000
    volume = data[2] // 0x10000
    mode = data[3] % 256
    kind = (data[3] & 0xFF00) // 256
    frequency = data[3] // 0x10000
    return cls(data[1], kind, balance, volume, mode, frequency)

class ChangeTeleportCommand(Command):
  cmd_id = 45
  def __init__(self, area_id: int, add: bool):
    super().__init__()
    self.area_id = area_id
    self.add = add

  def get_data(self):
    return (self.area_id, int(self.add))

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2])
  
class ChangeHPCommand(Command):
  cmd_id = 16
  def __init__(self, a: int, b: int, character: int, relative: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.character = character
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.character * 2 + int(self.relative))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    params = data[3]
    return cls(a, b, params // 2, params % 2 == 1)

class SwitchTeleportsCommand(Command):
  cmd_id = 46
  def __init__(self, enable: bool):
    super().__init__()
    self.enable = enable

  def get_data(self):
    return (self.enable,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class ChangeMPCommand(Command):
  cmd_id = 17
  def __init__(self, a: int, b: int, character: int, relative: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.character = character
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.character * 2 + int(self.relative))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    params = data[3]
    return cls(a, b, params // 2, params % 2 == 1)
  
class ChangeEscapeCommand(Command):
  cmd_id = 34
  def __init__(self, area_id: int, enable: bool):
    super().__init__()
    self.area_id = area_id
    self.enable = enable

  def get_data(self):
    return (self.area_id, int(self.enable))

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2])
  
class RecoverCommand(Command):
  cmd_id = 24
  def __init__(self, character: int, amount: int):
    super().__init__()
    self.character = character
    self.amount = amount

  def get_data(self):
    return (self.character, self.amount)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2])
  
class WaitCommand(Command):
  cmd_id = 13
  def __init__(self, a: int, b: int):
    super().__init__()
    self.a = a
    self.b = b

  def get_data(self):
    return (self.a, self.b)

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    return cls(a, b)
  
class ChangeStateCommand(Command):
  cmd_id = 22
  def __init__(self, character: int, state: int):
    super().__init__()
    self.character = character
    self.state = state

  def get_data(self):
    return (self.character, self.state)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1], data[2])
  
class SaveGameCommand(Command):
  cmd_id = 52
  def __init__(self, kind: bool):
    super().__init__()
    self.kind = kind

  def get_data(self):
    return (self.kind,)

  @classmethod
  def process(cls, data: list[int]):
    return cls(data[1])
  
class ChangeEXPCommand(Command):
  cmd_id = 11
  def __init__(self, a: int, b: int, character: int, relative: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.character = character
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.character * 2 + int(self.relative))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    params = data[3]
    return cls(a, b, params // 2, params % 2 == 1)

class EndGameCommand(Command):
  cmd_id = 30

  def get_data(self):
    return ()

  @classmethod
  def process(cls, data: list[int]):
    return cls()

class ChangeLevelCommand(Command):
  cmd_id = 19
  def __init__(self, a: int, b: int, character: int, relative: bool):
    super().__init__()
    self.a = a
    self.b = b
    self.character = character
    self.relative = relative

  def get_data(self):
    return (self.a, self.b, self.character * 2 + int(self.relative))

  @classmethod
  def process(cls, data: list[int]):
    a = data[1]
    b = data[2]
    params = data[3]
    return cls(a, b, params // 2, params % 2 == 1)

command_handlers = {}

for name in locals().copy():
  if name.find('Command') > 0:
    cls = locals()[name]
    command_handlers[cls.cmd_id] = cls