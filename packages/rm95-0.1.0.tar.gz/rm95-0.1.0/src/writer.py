import os
from .enemies import Enemy
from .events import Event
from .game import RPGGame
from .maps import Map
from .monstpic import save_monster_pics


def save_game(path: str, game: RPGGame):
  dir = os.path.dirname(path)
  os.makedirs(dir, exist_ok=True)
  f = open(path, 'wb')
  f.write('RPG Maker 95 '.encode('latin-1') + bytes([0] * 17))
  f.write(game.version.encode('latin-1'))
  f.write(b'\x00')
  for n in ['walking', 'wagon', 'sled', 'boat', 'ship', 'balloon', 'airship', 'combat_start', 'combat', 'victory', 'level_up', 'rest']:
    bgm = game.bgm[n]
    f.write(bgm.balance.to_bytes(2, 'little'))
    f.write(bgm.volume.to_bytes(2, 'little'))
    f.write(bgm.mode.to_bytes(2, 'little'))
    f.write(bgm.frequency.to_bytes(2, 'little'))
    f.write(bgm.filename.encode('latin-1'))
    f.write(bytes([10]))
  f.write(game.screen_switch.map_move.to_bytes(4, 'little'))
  f.write(game.screen_switch.battle1.to_bytes(4, 'little'))
  f.write(game.screen_switch.battle2.to_bytes(4, 'little'))
  f.write(game.currency.encode('latin-1').ljust(19, b'\x00'))
  f.write(b'\x00\x00')
  f.write(game.message_speed.to_bytes(2, 'little'))
  f.write(b'\x00\x00')
  f.write(game.max_item_amount.to_bytes(2, 'little'))
  flags = int(game.transparent_window) + int(game.save_without_event) * 2
  f.write(flags.to_bytes(2, 'little'))
  for character in game.party.characters:
    f.write(character.sprite.to_bytes(4, 'little'))
    f.write(character.in_party.to_bytes(4, 'little'))
    f.write(character.name.encode('latin-1').ljust(18, b'\x00'))
    f.write(b'\x00\x00')
    f.write(character.level.to_bytes(4, 'little'))
    f.write(character.hp.to_bytes(4, 'little'))
    f.write(character.mp.to_bytes(4, 'little'))
    f.write(character.strength.to_bytes(4, 'little'))
    f.write(character.power.to_bytes(4, 'little'))
    f.write(character.intelligence.to_bytes(4, 'little'))
    f.write(character.speed.to_bytes(4, 'little'))
    f.write(character.luck.to_bytes(4, 'little'))
    f.write(character.attack_power.to_bytes(4, 'little'))
    f.write(character.defense_power.to_bytes(4, 'little'))
    for i in character.power_curve:
      f.write(i.to_bytes())
    for i in character.strength_curve:
      f.write(i.to_bytes())
    for i in character.intelligence_curve:
      f.write(i.to_bytes())
    for i in character.speed_curve:
      f.write(i.to_bytes())
    for i in character.luck_curve:
      f.write(i.to_bytes())
    for i in character.params:
      f.write(i.to_bytes(4, 'little'))
    f.write(character.weapon.to_bytes())
    f.write(character.armor.to_bytes())
    f.write(character.shield.to_bytes())
    f.write(character.helmet.to_bytes())
    f.write(character.accessory.to_bytes())
    for i in character.spells:
      f.write(i.to_bytes())
    for i in character.resistances:
      f.write(i.to_bytes())
  for i in game.party.starting_items:
    f.write(i.to_bytes(2, 'little'))
  f.write(game.party.gold.to_bytes(4, 'little'))
  f.write(game.party.start_map.to_bytes(4, 'little'))
  f.write(game.party.start_x.to_bytes(4, 'little'))
  f.write(game.party.start_y.to_bytes(4, 'little'))
  for map in game.maps:
    if type(map) == Map:
      f.write(map.map_id.to_bytes(2, 'little'))
    else:
      f.write(map.area_id.to_bytes(2, 'little'))
    f.write(b'\x00\x00')
    f.write(map.name.encode('latin-1').ljust(21, b'\x00'))
    parent = map.parent
    depth = 0
    while parent != None:
      m = [m for m in game.maps if type(m) == Map and m.map_id == parent][0]
      parent = m.parent
      depth += 1
    f.write(depth.to_bytes(4, 'little'))
    if type(map) == Map:
      f.write(map.looping.to_bytes(4, 'little'))
      f.write(b'\xff\xff\xff\xff\xff\xff\xff\xff')
      f.write(map.width.to_bytes(2, 'little'))
      f.write(map.height.to_bytes(2, 'little'))
      f.write((map.parent if map.parent != None else 0xFFFFFFFF).to_bytes(4, 'little', signed=False))
      next = [m for m in game.maps[game.maps.index(map) + 1:] if m.parent == map.parent]
      if len(next) > 0:
        f.write(next[0].map_id.to_bytes(2, 'little'))
      else:
        f.write(bytes([0] * 2))
      first_child = [m for m in game.maps if m.parent == map.map_id]
      if len(first_child) > 0:
        if type(first_child[0]) == Map:
          f.write(first_child[0].map_id.to_bytes(2, 'little'))
        else:
          f.write(first_child[0].area_id.to_bytes(2, 'little'))
        f.write((1).to_bytes(2, 'little'))
      else:
        f.write(bytes([0] * 4))
      f.write(bytes([0] * 10))
      for e in map.encounters:
        f.write(e[0].to_bytes())
        f.write((e[1] * 2).to_bytes())
      for t in [map.tileset_a, map.tileset_b, map.tileset_c, map.tileset_d]:
        f.write(t.name.encode('latin-1'))
        f.write(b'\n')
        t.image.save(os.path.join(dir, t.name + '.BMP'))
        open(os.path.join(dir, t.name + '.ATR'), 'wb').write(bytes(t.attrs))
      
      for t in map.tiles:
        f.write(t.to_bytes(2, 'little'))
      events = sorted(map.events, key=lambda e: e.y * map.width + e.x)
      last = -1
      for e in events:
        shift = e.y * map.width + e.x
        rshift = shift - last
        if rshift > 1:
          if rshift > 0x7fff:
            f.write(b'\xff\xff')
            f.write((rshift - 2).to_bytes(2, 'little'))
          else:
            f.write((rshift + 0x7ffe).to_bytes(2, 'little'))
        f.write(e.event_id.to_bytes(2, 'little'))
        last = shift
        save_event(dir, e)
      rshift = (map.height * map.width) - last - 1
      if rshift > 0:
        if rshift > 0x7fff:
          f.write(b'\xff\xff')
          f.write(rshift.to_bytes(2, 'little'))
        else:
          f.write((rshift + 0x7fff).to_bytes(2, 'little'))
    else:
      f.write((2).to_bytes(4, 'little'))
      f.write((map.x).to_bytes(4, 'little'))
      f.write((map.y).to_bytes(4, 'little'))
      f.write((map.width).to_bytes(2, 'little'))
      f.write((map.height).to_bytes(2, 'little'))
      f.write((map.parent).to_bytes(4, 'little'))
      for _ in range(8):
        f.write(b'\x00')
      f.write((map.exit_x).to_bytes(4, 'little'))
      f.write((map.exit_y).to_bytes(4, 'little'))
      for e in map.encounters:
        f.write(e[0].to_bytes())
        f.write((e[1] * 2).to_bytes())
  f.close()
  save_enemies(dir, game.enemies)
  save_troops(dir, game.troops)
  save_items(dir, game.items)
  save_magic(dir, game.magic)
  save_texts(dir, game.texts)
  save_switch_names(dir, game.switch_names)
  save_monster_pics(dir, [e.image for e in game.enemies])

def save_event(path: str, event: Event):
  filename = f'eve{event.event_id:05}.dat'
  f = open(os.path.join(path, filename), 'wb')
  f.write(b'\x88\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
  for p in event.pages:
    f.write(p.trigger.to_bytes())
  for p in event.pages:
    f.write(p.conditions.to_bytes(4, 'little'))
  for p in event.pages:
    f.write((p.display + 24).to_bytes())
  for p in event.pages:
    f.write(p.priority.to_bytes())
  for p in event.pages:
    f.write(p.movement.to_bytes())
  for p in event.pages:
    f.write(p.animation.to_bytes())
  for p in event.pages:
    f.write(p.speed.to_bytes())
  for p in event.pages:
    f.write(p.type.to_bytes())
  for p in event.pages:
    f.write(p.item.to_bytes(2, 'little'))
  for p in event.pages:
    f.write(p.member.to_bytes())
  for p in event.pages:
    f.write(p.gold.to_bytes(4, 'little'))
  for p in event.pages:
    f.write(p.switch.to_bytes(2, 'little'))
  for p in event.pages:
    f.write(p.sprite.to_bytes(2, 'little'))
  for p in event.pages:
    f.write(b'\x00\x00\x00\x00')
  for p in event.pages:
    f.write(p.command_count.to_bytes(4, 'little'))
  str_len = sum([len(t) + 1 for t in event.texts if t is not None]) + 1
  f.write(str_len.to_bytes(4, 'little'))
  for p in event.pages:
    f.write(len(p.route).to_bytes())
    for b in p.route:
      f.write(b.to_bytes())
  for p in event.pages:
    for c in p.commands:
      data = c.get_data()
      f.write(c.cmd_id.to_bytes(4, 'little'))
      for d in data:
        f.write(d.to_bytes(4, 'little'))
      for i in range(4 - len(data)):
        f.write(0x77.to_bytes(4, 'little'))
    f.write(b'\x00' * 20)

  for i, t in enumerate(event.texts):
    f.write(i.to_bytes())
    f.write(t.encode('latin-1'))
  f.write(b'\x1A')

  for r in event.routes:
    f.write(len(r).to_bytes())
    for d in r:
      f.write(d.to_bytes())

def save_enemies(path: str, enemies: list[Enemy]):
  from .enemies import FILENAME
  f = open(os.path.join(path, FILENAME), 'wb')
  for enemy in enemies:
    f.write((0).to_bytes(4, 'little'))  # Unknown int
    f.write((0).to_bytes(2, 'little'))  # Unknown short
    f.write(enemy.hp.to_bytes(2, 'little'))
    f.write((0).to_bytes(4, 'little'))  # Unknown int
    f.write(enemy.mp.to_bytes(2, 'little'))
    f.write((0).to_bytes(4, 'little'))  # Unknown int
    f.write(enemy.speed.to_bytes(2, 'little'))
    f.write((0).to_bytes(4, 'little'))  # Unknown int
    f.write(enemy.defense.to_bytes(2, 'little'))
    f.write(enemy.attack.to_bytes(2, 'little'))
    f.write((0).to_bytes(2, 'little'))  # Unknown short
    f.write(enemy.exp.to_bytes(4, 'little'))
    f.write(enemy.gold.to_bytes(4, 'little'))
    f.write(enemy.item.to_bytes(1, 'little'))
    f.write(enemy.probability.to_bytes(1, 'little'))
    f.write((0).to_bytes(4, 'little'))  # Unknown int
    f.write(enemy.name.encode('latin-1').ljust(20, b'\x00'))
    f.write((0).to_bytes(1, 'little'))  # Unknown byte
    for resistance in enemy.resistances:
      f.write(resistance.to_bytes(1, 'little'))
    for pattern in enemy.patterns:
      f.write(pattern.to_bytes(1, 'little'))
    for _ in range(9):
      f.write((0).to_bytes(1, 'little'))  # 9 unknown bytes
  f.close()

def save_troops(path: str, troops):
  from .troops import FILENAME
  f = open(os.path.join(path, FILENAME), 'wb')
  for troop in troops:
    f.write(troop.background.to_bytes(2, 'little'))
    f.write(troop.land.to_bytes(2, 'little'))
    f.write(len(troop.enemies).to_bytes(4, 'little'))
    for enemy in troop.enemies:
      f.write(enemy[0].to_bytes(4, 'little'))
      f.write(enemy[1].to_bytes(4, 'little'))
      f.write(enemy[2].to_bytes(4, 'little'))
    # Pad remaining enemy slots with zeros
    for _ in range(10 - len(troop.enemies)):
      f.write((0).to_bytes(4, 'little'))
      f.write((0).to_bytes(4, 'little'))
      f.write((0).to_bytes(4, 'little'))
  f.close()

def save_items(path: str, items):
  from .items import FILENAME
  f = open(os.path.join(path, FILENAME), 'wb')
  for item in items:
    f.write(item.cost.to_bytes(2, 'little'))
    f.write(item.equip.to_bytes(2, 'little'))
    f.write(item.power.to_bytes(2, 'little'))
    f.write(item.kind.to_bytes(2, 'little'))
    f.write(item.name.encode('latin-1').ljust(18, b'\x00'))
    f.write((0).to_bytes(2, 'little'))
  f.close()

def save_magic(path: str, magic):
  from .magic import FILENAME
  f = open(os.path.join(path, FILENAME), 'wb')
  for spell in magic:
    f.write(spell.effect.to_bytes(2, 'little'))
    f.write((0).to_bytes(2, 'little'))
    f.write(spell.cost.to_bytes(2, 'little'))
    f.write(spell.power.to_bytes(2, 'little'))
    f.write(spell.name.encode('latin-1').ljust(18, b'\x00'))
    f.write((0).to_bytes(2, 'little'))
  f.close()

def save_texts(path: str, texts: list[str]):
  f = open(os.path.join(path, 'STRINGS.DAT'), 'w', encoding='latin-1')
  f.write('\n'.join(texts))
  f.close()

def save_switch_names(path: str, switch_names: list[str]):
  f = open(os.path.join(path, 'SWNAME.DAT'), 'w', encoding='latin-1')
  f.write('\n'.join(switch_names))
  f.close()