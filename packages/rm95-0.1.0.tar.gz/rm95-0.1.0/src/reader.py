class Reader:
  def __init__(self, filename):
    self.handle = open(filename, 'rb')
    self.name = filename

  def verify(self, b: bytes):
    chunk = self.handle.read(len(b))
    if (chunk != b):
      raise Exception('bad ' + str(chunk))

  def read_str(self, l=-1, sep=10, trimmed=True) -> str:
    s = b''
    b = self.handle.read(1)
    s += b
    i = 1
    while (l == -1 and b[0] != sep) or (l > 0 and i < l):
      b = self.handle.read(1)
      s += b
      i += 1
    for i in range(len(s)):
      if s[i] == 0:
        if trimmed:
          s = s[:i].strip()
        return s.decode('latin-1')
    if trimmed:
      s = s.strip()
    return s.decode('latin-1')

  def read_int(self) -> int:
    b = self.handle.read(4)
    if (len(b) == 0):
      return None
    return int.from_bytes(b, 'little')

  def read_short(self) -> int:
    b = self.handle.read(2)
    if (len(b) == 0):
      return None
    return int.from_bytes(b, 'little')

  def read_byte(self) -> int:
    return self.handle.read(1)[0]