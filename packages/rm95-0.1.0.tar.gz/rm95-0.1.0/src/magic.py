from dataclasses import dataclass
import os

from .reader import Reader

FILENAME = 'MAGIC.DAT'

@dataclass
class Spell:
  name: str
  cost: int
  effect: int
  power: int

def load_magic(path: str) -> list[Spell]:
  r = Reader(os.path.join(path, FILENAME))
  items = []
  for _ in range(100):
    effect = r.read_short()
    r.read_short()
    cost = r.read_short()
    power = r.read_short()
    name = r.read_str(18)
    r.read_short()
    items.append(Spell(name, cost, effect, power))
  return items
  