from dataclasses import dataclass
import os
from PIL import Image

from .monstpic import load_monster_pictures
from .reader import Reader

FILENAME = 'CHARA.DAT'

@dataclass
class Enemy:
  name: str
  image: Image.Image
  hp: int
  mp: int
  attack: int
  defense: int
  speed: int
  exp: int
  gold: int
  item: int
  probability: int
  resistances: list[int]
  patterns: list[int]

def load_enemies(path: str) -> list[Enemy]:
  r = Reader(os.path.join(path, FILENAME))
  enemies = []
  #images = [None] * 100
  images = load_monster_pictures(path)
  for i in range(100):
    r.read_int()
    r.read_short()
    hp = r.read_short()
    r.read_int()
    mp = r.read_short()
    r.read_int()
    speed = r.read_short()
    r.read_int()
    defense = r.read_short()
    attack = r.read_short()
    r.read_short()
    exp = r.read_int()
    gold = r.read_int()
    item = r.read_byte()
    probability = r.read_byte()
    r.read_int()
    name = r.read_str(20)
    r.read_byte()
    resistances = [r.read_byte() for _ in range(100)]
    patterns = [r.read_byte() for _ in range(10)]
    for _ in range(9):
      r.read_byte()
    enemy = Enemy(name, images[i], hp, mp, attack, defense, speed, exp, gold, item, probability, resistances, patterns)
    enemies.append(enemy)
  return enemies
