import os
from dataclasses import dataclass

from .commands import Command, command_handlers
from .reader import Reader


@dataclass
class Page:
  sprite: int
  type: int
  priority: int
  movement: int
  trigger: int
  display: int
  animation: int
  speed: int
  conditions: int
  item: int
  member: int
  gold: int
  switch: int
  command_count: int
  commands: list[Command]
  route: list[int]

  def __init__(self):
    pass

@dataclass
class Event:
  x: int
  y: int
  event_id: int
  pages: list[Page]
  texts: list[str]
  routes: list[list[int]]

def normalize_path(path: str):
  dir = os.path.dirname(path)
  basename = os.path.basename(path)
  for name in os.listdir(dir):
    if basename.lower() == name.lower():
      return os.path.join(dir, name)

def load_event(path: str, event: Event):
  filename = f'eve{event.event_id:05}.dat'
  r = Reader(normalize_path(os.path.join(path, filename)))
  if r.read_int() != 0x88:
    raise Exception('bad header')

  r.read_int()
  r.read_int()

  pages = [Page(), Page(), Page(), Page()]
  event.pages = pages

  for p in pages:
    p.trigger = r.read_byte()

  for p in pages:
    p.conditions = r.read_int()

  for p in pages:
    b = r.read_byte()
    p.display = b - 24

  for p in pages:
    p.priority = r.read_byte()

  for p in pages:
    p.movement = r.read_byte()

  for p in pages:
    p.animation = r.read_byte()

  for p in pages:
    p.speed = r.read_byte()

  for p in pages:
    p.type = r.read_byte()

  for p in pages:
    p.item = r.read_short()

  for p in pages:
    p.member = r.read_byte()

  for p in pages:
    p.gold = r.read_int()

  for p in pages:
    p.switch = r.read_short()

  for p in pages:
    p.sprite = r.read_short()

  for p in pages:
    r.read_int()

  for p in pages:
    p.command_count = r.read_int()

  str_len = r.read_int()
  for p in pages:
    l = r.read_byte()
    p.route = []
    for i in range(l):
      p.route.append(r.read_byte())

  for p in pages:
    commands = []

    for i in range(p.command_count):
      data = [r.read_int(), r.read_int(), r.read_int(), r.read_int(), r.read_int()]
      cmd_id = data[0]
      if cmd_id == 0:
        pass
      elif cmd_id in command_handlers:
        commands.append(command_handlers[cmd_id].process(data))
      else:
        print('unknown command', cmd_id)

    p.commands = commands


  texts = [None] * 1000
  x = 0
  while x < str_len - 1:
    i = r.read_byte()
    x += 1
    texts[i] = r.read_str(sep=0, trimmed=False)
    x += len(texts[i]) + 1

  i = len(texts) - 1
  while i >= 0 and texts[i] == None:
    i -= 1
  event.texts = texts[:i + 1]

  r.verify(b'\x1A')

  size = r.handle.read(1)
  routes = []
  while len(size) > 0:
    size = size[0]
    route = []
    for i in range(size):
      route.append(r.read_byte())
    size = r.handle.read(1)
    routes.append(route)
  event.routes = routes
