Changelog
=============


v0.1.0 (October 20, 2025)
---------------------------

- Initial release of the ``aboutcode.federated`` library based on
  original work in the ``aboutcode.hashid`` library.