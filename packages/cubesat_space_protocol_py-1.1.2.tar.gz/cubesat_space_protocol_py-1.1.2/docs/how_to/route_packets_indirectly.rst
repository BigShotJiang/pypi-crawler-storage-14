Route packets to network through interface
==========================================

TODO