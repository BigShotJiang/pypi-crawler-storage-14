Set default flags for outgoing flags
====================================

TODO