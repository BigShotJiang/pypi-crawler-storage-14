from .core import CrayonLite
__version__ = "1.0.0"
