import os
import json
import pickle
import time
import unicodedata
from typing import List, Dict, Tuple
from collections import defaultdict
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

def _normalize_nfc(text: str) -> str:
    return unicodedata.normalize("NFC", text)

class TrieNode:
    __slots__ = ["children", "token_id", "is_end"]
    def __init__(self):
        self.children: Dict[str, TrieNode] = {}
        self.token_id: int = -1
        self.is_end: bool = False

class CrayonVocab:
    def __init__(self, tokens: List[str]):
        self.root = TrieNode()
        self.id_to_token = {}
        self.token_to_id = {}
        self.build(tokens)

    def build(self, tokens: List[str]):
        tokens = sorted(set(tokens), key=lambda x: (-len(x), x))
        for idx, token in enumerate(tokens):
            self.token_to_id[token] = idx
            self.id_to_token[idx] = token
            node = self.root
            for ch in token:
                if ch not in node.children:
                    node.children[ch] = TrieNode()
                node = node.children[ch]
            node.is_end = True
            node.token_id = idx

    def longest_match(self, text: str, pos: int) -> Tuple[int, int]:
        node = self.root
        best_len = 0
        best_id = -1
        cur_len = 0
        i = pos
        n = len(text)
        while i < n:
            ch = text[i]
            if ch not in node.children:
                break
            node = node.children[ch]
            cur_len += 1
            if node.is_end:
                best_len = cur_len
                best_id = node.token_id
            i += 1
        return best_len, best_id

class CrayonTokenizer:
    def __init__(self, vocab: CrayonVocab):
        self.vocab = vocab
        self.unk_id = vocab.token_to_id.get("<unk>", 0)

    def encode(self, text: str) -> List[int]:
        text = _normalize_nfc(text)
        result = []
        i = 0
        n = len(text)
        while i < n:
            mlen, tid = self.vocab.longest_match(text, i)
            if mlen > 0:
                result.append(tid)
                i += mlen
            else:
                ch = text[i]
                tid = self.vocab.token_to_id.get(ch, self.unk_id)
                result.append(tid)
                i += 1
        return result

    def decode(self, ids: List[int]) -> str:
        return "".join(self.vocab.id_to_token.get(i, "<unk>") for i in ids)

def extract_substrings(text: str, max_len: int = 16) -> Dict[str, int]:
    counts = defaultdict(int)
    n = len(text)
    for i in range(n):
        for j in range(1, min(max_len+1, n-i)):
            counts[text[i:i+j]] += 1
    return counts

def train_crayon_lite(corpus: str, vocab_size: int = 520000) -> CrayonVocab:
    print(f"Training CrayonLite on {len(corpus):,} characters...")
    counts = extract_substrings(corpus)
    items = sorted(counts.items(), key=lambda x: (-x[1], -len(x[0])))
    vocab_tokens = ["<unk>"]
    seen = {"<unk>"}
    for token, freq in items:
        if len(vocab_tokens) >= vocab_size:
            break
        if token not in seen:
            vocab_tokens.append(token)
            seen.add(token)
    print(f"Vocabulary built: {len(vocab_tokens):,} tokens")
    return CrayonVocab(vocab_tokens)

class CrayonLite:
    def __init__(self, tokenizer: CrayonTokenizer):
        self.tokenizer = tokenizer

    def encode(self, text: str) -> List[int]:
        return self.tokenizer.encode(text)

    def decode(self, ids: List[int]) -> str:
        return self.tokenizer.decode(ids)

    def save(self, path: str):
        os.makedirs(path, exist_ok=True)
        vocab_data = {
            "tokens": [self.tokenizer.vocab.id_to_token.get(i, "<unk>") for i in range(len(self.tokenizer.vocab.id_to_token))],
            "version": "crayonlite-1.0.0",
            "date": datetime.utcnow().isoformat()
        }
        with open(f"{path}/vocab.json", "w", encoding="utf-8") as f:
            json.dump(vocab_data, f, ensure_ascii=False)
        with open(f"{path}/tokenizer.pkl", "wb") as f:
            pickle.dump(self.tokenizer, f)
        print(f"Model saved to {path}/")

    @staticmethod
    def load(path: str) -> "CrayonLite":
        with open(f"{path}/tokenizer.pkl", "rb") as f:
            tokenizer = pickle.load(f)
        return CrayonLite(tokenizer)

def benchmark(tokenizer: CrayonTokenizer, texts: List[str], name: str, trials: int = 7):
    total_tokens = 0
    times = []
    for _ in range(trials):
        start = time.perf_counter()
        for text in texts:
            ids = tokenizer.encode(text)
            total_tokens += len(ids)
        end = time.perf_counter()
        times.append(end - start)
    avg_time = sum(times) / trials
    throughput = total_tokens / avg_time / 1e6
    print(f"{name} → {throughput:.3f} M tokens/sec")
    return {"name": name, "throughput": throughput, "time": avg_time}
