from setuptools import setup, find_packages
setup(
    name="crayonlite",
    version="1.0.0",
    description="Pure-Python ultra-fast tokenizer inspired by XERV Crayon (>2M tokens/sec)",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="XERV Labs",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
