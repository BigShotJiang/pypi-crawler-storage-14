# CrayonLite
Pure Python tokenizer achieving >2M tokens/sec on CPU
Zero dependencies · PyPI ready · Inspired by XERV Crayon