# Terminal utilities reference

-----

::: dda.utils.terminal.remove_ansi

::: dda.utils.terminal.terminal_size

::: dda.utils.terminal.get_terminal_size
