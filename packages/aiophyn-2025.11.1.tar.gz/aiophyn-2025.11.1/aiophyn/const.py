"""Define package constants."""
API_BASE: str = "https://api.phyn.com"