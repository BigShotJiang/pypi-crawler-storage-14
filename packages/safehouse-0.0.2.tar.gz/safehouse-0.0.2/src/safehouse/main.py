import sys

from python_on_whales import DockerClient


compose_files=[
    "/Users/tflecht/Code/calligfx/Code/trunk/services/docker-compose.yml",
]


docker = DockerClient(compose_files=compose_files)


def main():
    if not docker.compose.is_installed():
        print("Please install docker (https://docs.docker.com/get-started/get-docker/).")
        sys.exit(-1)
    print("welcome to safehouse!")

'''
This console command is part of the `Safehouse` python package, which also installs the Safehouse
SDK.
1. Load docker compose, see if it is running
'''
