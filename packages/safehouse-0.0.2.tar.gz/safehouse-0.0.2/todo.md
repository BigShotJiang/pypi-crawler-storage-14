1. switch to using volumes for mounts filesystems (pgdata, psql, metadata_?)
2. figure out how to interact with docker compose instead of docker? (if not, stop using docker compose?)
