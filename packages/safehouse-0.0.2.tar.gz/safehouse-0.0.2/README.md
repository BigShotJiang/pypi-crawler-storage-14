Safehouse console.
