# Changelog

## 1.2.2 - 2025-11-27

* Fixes event loop affecting Python 3.14

## 1.2.1 - 2025-11-26

* Uses `aspectRatio` so embed images looks better on Bluesky

## 1.2.0 - 2025-09-14

* Adds `--alt-texts` to pass images alt texts from the CLI
* Adds possibility to post image(s) without text

## 1.1.4 - 2025-09-14

* Adds support for Python 3.14
* Drops support for Python 3.9 (end of life in 17 days)
