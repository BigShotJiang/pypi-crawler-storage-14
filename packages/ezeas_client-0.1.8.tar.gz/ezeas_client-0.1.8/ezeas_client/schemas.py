from typing import List, Optional, TypedDict


DateString = str  # ISO date string "YYYY-MM-DD"


class ContactInput(TypedDict, total=False):
    external_id: str  # required logically
    employee_number: Optional[str]
    first_name: Optional[str]
    last_name: str  # required on first create
    mobile: Optional[str]
    email: str  # required on first create
    tenure_date: Optional[DateString]


class TimesheetEntry(TypedDict):
    date: DateString
    hours_ordinary: float
    hours_time_and_half: float
    hours_double_time: float


class TimesheetInput(TypedDict):
    job_code: str
    timesheet_entries: List[TimesheetEntry]
