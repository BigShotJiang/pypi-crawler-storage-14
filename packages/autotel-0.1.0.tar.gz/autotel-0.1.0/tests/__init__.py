"""Tests for autotel."""
