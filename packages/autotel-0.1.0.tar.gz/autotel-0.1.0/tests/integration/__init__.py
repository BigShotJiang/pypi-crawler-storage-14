"""Integration tests for autotel."""
