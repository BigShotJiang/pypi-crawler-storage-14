"""Unit tests for autotel."""
