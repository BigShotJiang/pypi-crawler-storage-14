"""Version information for autotel."""

__version__ = "0.1.0"
