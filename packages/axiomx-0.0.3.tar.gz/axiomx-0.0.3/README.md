# AxiomX Math Library

AxiomX is happy to announce the second release of AxiomX - AxiomX 0.0.3.
This math library is used for more accurate calculations.

## Features

### 📚 Constants

-   pi               = 3.141592653589793
-   e                = 2.718281828459045
-   tau              = 2 * pi
-   lemniscate       = 2.622057554292119
-   gelfond          = e**pi
-   sqrt_2           = sqrt(2)
-   sqrt_3           = sqrt(3)
-   sqrt_5           = sqrt(5)
-   golden_ratio     = (1 + sqrt_5) / 2
-   silver_ratio     = 1 + sqrt_2
-   apery            = zeta(3)
-   ramanujan        = gelfond**sqrt(163)
-   gauss            = lemniscate / pi
-   euler_mascheroni = 0.577215664901533

### 🔢 Number Operations

-   `absolute(x)` -- Absolute value
-   `gamma(x)` -- Lanczos-based Gamma function
-   `factorial(x)` -- Based on Gamma function
-   `sqrt(n)` -- Newton--Raphson square root
-   `zeta(n)` -- Riemann zeta approximation

### ➗ Continued Fractions

-   `continued_fraction(constant, terms=5)`
-   `evaluate_continued_fraction(list)`

### 📈 Logarithmic & Exponential

-   `exp(n)`
-   `ln(x)`
-   `log10(x)`
-   `log(a, b)`

### 🔺 Trigonometric Functions

-   `sin(x)`
-   `cos(x)`
-   `tan(x)`
-   Inverse trig functions like `arcsin`, `arccos`, etc.
-   Hyperbolic functions and their inverses

## Version

`0.0.1`

## Usage

``` python
import AxiomX as ax

print(ax.sin(ax.pi/2))
```

## What's new

New things are not introduced above. These are the things added:

### 🔢 Number Operations

-   cbrt(x) - This function returns the exact cube root of x using Newton-Raphson method.
-   beta(n) - Dirichlet beta function.

### 📚 Constants

-   catalan           = beta(2)
-   gelfond_schneider = 2**sqrt_2

### 📈 Logarithmic & Exponential

- log2(x) - returns the binary logarithm of x.

## 🔧 Bugs fixed

1. In the previous version of AxiomX, the factorial of natural numbers was returning close integers and not regular integers. So in this version, the factorial of natural numbers is always an integer and not a close integer.
2. In the previous version, ln(x) returned 3.0 when x = e^3. But when e^35, the value was not 35 but it was about 6.2. So that has been refined.
3. Trigonometric functions, hyperbolic and normal are now very much accurate.

## 📖 Notes

Now you also have a new option to use symbols instead of their defined names, for example, AxiomX.pi can be re-written as AxiomX.π. But in the case of G, which can allude to both Gauss constant and Catalan's constant, there is a confusion. So, G is chosen as Gauss constant and g is chosen as Catalan's constant.\
This software is licensed under MIT and no one is allowed to copy code from AxiomX. Hope you enjoy AxiomX. 