"""Tests initialization."""
