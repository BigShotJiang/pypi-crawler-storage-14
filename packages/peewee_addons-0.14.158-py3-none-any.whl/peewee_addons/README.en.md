# Peewee miscellaneous addons

[![Code size](https://img.shields.io/github/languages/code-size/ablaternae/py-peewee-addons)](https://github.com/ablaternae/py-peewee-addons/)
[![Downloads](https://img.shields.io/pypi/dm/peewee-addons)](https://pypi.org/project/peewee-addons)
[![Downloads](https://img.shields.io/pypi/dd/peewee-addons?label=&color=green)](https://pypi.org/project/peewee-addons)
[![Statistic](https://static.pepy.tech/personalized-badge/peewee-addons?period=total&units=NONE&left_color=GRAY&right_color=GREEN&left_text=total)](https://pepy.tech/projects/peewee-addons)
[![Hits](https://hits.sh/pypi.org/project/peewee-addons.svg?view=today-total&label=hits)](https://hits.sh/pypi.org/project/peewee-addons/)
[![License](https://img.shields.io/github/license/ablaternae/py-peewee-addons)](https://github.com/ablaternae/py-peewee-addons/blob/trunk/LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000.svg)](https://github.com/psf/black)

****

description will be provided later

## API
`import peewee_addons`
@see also `__init__.py`

### databases
Development Status :: 3 - Alpha :: still under construction

`from peewee_addons import databases`
```
from peewee_addons.databases import (
    connect,
    Database,
    DEFAULT_DATABASE,
    DEFAULT_URL,
)
DEFAULT_DATABASE = connect(DEFAULT_URL)
```

### fields
`from peewee_addons import fields`

<details><summary>fields list</summary>
<pre>
__all__ = (
    "ARCUITField",
    "ARZipCodeField",
    "ATZipCodeField",
    "AUZipCodeField",
    "BEZipCodeField",
    "BRZipCodeField",
    "CHZipCodeField",
    "CLRutField",
    "CNZipCodeField",
    "CONITField",
    "CSVField",
    "CUZipCodeField",
    "CZZipCodeField",
    "CharFieldCustom",
    "ColorHexadecimalField",
    "CountryISOCodeField",
    "CurrencyISOCodeField",
    "DEZipCodeField",
    "DateTimeTZRangeField",
    "EEZipCodeField",
    "ESZipCodeField",
    "EmailField",
    "FIELD_TYPES",
    "GRZipCodeField",
    "HROIBField",  # 'EnumField',
    "HexadecimalField",
    "IANCodeField",
    "IBANISOCodeField",
    "ILZipCodeField",
    "INZipCodeField",
    "IPAddressField",
    "IPNetworkField",
    "ISIdNumberField",
    "JPZipCodeField",
    "LanguageISOCodeField",
    "MKIdentityCardNumberField",
    "MTZipCodeField",
    "MXZipCodeField",
    "MoneyField",
    "PLNIPField",
    "PLNationalIDCardNumberField",
    "PLZipCodeField",
    "PTZipCodeField",
    "PasswordField",
    "PastDateField",
    "PastDateTimeField",
    "PositiveBigIntegerField",
    "PositiveDecimalField",
    "PositiveFloatField",
    "PositiveIntegerField",
    "PositiveSmallIntegerField",
    "ROCIFField",
    "ROCNPField",
    "ROZipCodeField",
    "RUPassportNumberField",
    "SEZipCodeField",
    "SKZipCodeField",
    "SWIFTISOCodeField",
    "SemVerField",
    "SimplePasswordField",
    "SmallHexadecimalField",
    "UAZipCodeField",
    "USSocialSecurityNumberField",
    "USZipCodeField",
    "UYCIField",
    "XMLField",
    "JSONField",
    "FileField",
    "TextField",
)
</pre>
</details>


#### FIELDS
`from peewee_addons import FIELDS` all fields list
`from peewee_addons.fields import FIELDS` the same

##### datetime
`from peewee_addons.fields.datetime import TimeDeltaField, TimedeltaField`
##### email
`from peewee_addons.fields.email import EMailField, EmailField`
##### enum
`from peewee_addons.fields.enum import EnumField`	EnumField(CharField)
##### enum2
`from peewee_addons.fields.enum2 import EnumField`	EnumField(CharField)
##### extra
`from peewee_addons.fields.extra import *`	== extra_fields
##### html
`from peewee_addons.fields.html import HTMLCharField, HTMLTextField`	# Field with HTML escaped text
##### integer
```
__all__ = (
    "UnsignedSmallIntegerFieldd",
    "SmallUnsignedIntegerField",
    "UnsignedIntegerField",
    "UnsignedBigIntegerField",
    "BigUnsignedIntegerField",
)
```
##### ip
`from peewee_addons.fields.html import IPAddressField`	IPAddressField(CharField)
`from peewee_addons.fields.html import IPv4AddressField`	IPv4AddressField(UnsignedIntegerField)
`from peewee_addons.fields.html import IPv6AddressField`	IPv6AddressField(Field)
##### password
`PasswordField(FixedCharField)` Not implemented yet
##### path
`from peewee_addons.fields.path import PathField`	Field class for storing file paths
##### path
`from peewee_addons.fields.phonenumber import PhoneNumberField, PhonenumberField`
##### restricted_char
`from peewee_addons.fields.restricted_char import RestrictedCharField`
##### username
`from peewee_addons.fields.username import UserNameField, UsernameField`


#### extra_fields
Development Status :: 2 - Pre-Alpha
  
* `from peewee_addons.fields.extra_fields import regex_fields` Zip Codes, Countries Postal Codes
* `from peewee_addons.fields.extra_fields import legacy_fields` PasswordField, PasswordHash. **require** bcrypt

****

### mixins
`from peewee_addons import mixins`

from .field_created import Created_Datetime_Mixin, Created_Timestamp_Mixin
from .field_updated import Updated_Datetime_Mixin, Updated_Timestamp_Mixin
from .model_autosave import Autosave_Mixin

from .model_iterator import Iterator_Mixin
from .model_upsert import Upsert_Mixin


### models
`from peewee_addons import models`

from .base_model import BaseModel, Database, Model
from .ext_model import ExtendModel

### logger & utils
