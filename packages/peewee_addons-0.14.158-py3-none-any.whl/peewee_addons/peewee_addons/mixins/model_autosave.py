####
##
#
#

from peewee import Model

from ..logger import logger


class Autosave_Mixin(Model):
    """Model destructor"""

    def __del__(self):
        logger.debug("%s destructor in %s" % (self.__class__.__name__, __class__.__name__))
        if self.is_dirty():
            logger.info("%s.save()" % self.__class__.__name__)
            try:
                self.save()
            except Exception as exc:
                logger.warning("NOT saved! Exception: %s" % exc)
                pass

        try:
            super().__del__()
        except Exception as exc:
            # print("нет деструктора модели, но лень обрабатывать", exc)
            pass
