####
##
#
#

from collections.abc import Mapping

from peewee import Model


class Iterator_Mixin(Model):
    """Model iterator"""

    def __iter__(self):
        # хорошо бы потестить, что быстрее и требует меньше памяти: создание итератора или генератора
        # return iter(self.__data__.items())
        return ((k, v) for k, v in self.__data__.items())

    def __next__(self):
        return next(self.__data__)

    def __len__(self):
        return len(self.__data__)

    def __getitem__(self, key):
        return self.__data__.get(key, None)
