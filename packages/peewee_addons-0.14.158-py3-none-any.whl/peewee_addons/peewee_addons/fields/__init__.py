"""Additional field definitions."""

import sys

from peewee import (
    AutoField,
    BigAutoField,
    BigBitField,
    BigIntegerField,
    BinaryUUIDField,
    BitField,
    BlobField,
    BooleanField,
    CharField,
    DateField,
    DateTimeField,
    DecimalField,
    DoubleField,
    FixedCharField,
    FloatField,
    IntegerField,
    IPField,
    SmallIntegerField,
    TextField,
    TimeField,
    TimestampField,
    UUIDField,
)

from playhouse.fields import PickleField
from playhouse.postgres_ext import JSONField as pgJSONField
from playhouse.sqlite_ext import JSONField as sqliteJSONField

from .datetime import TimedeltaField, TimeDeltaField
from .email import EmailField, EMailField
from .enum2 import EnumField
from .integer import (
    BigUnsignedIntegerField,
    SmallUnsignedIntegerField,
    UnsignedBigIntegerField,
    UnsignedIntegerField,
    UnsignedSmallIntegerField,
)
from .ip import IPAddressField, IPv4AddressField, IPv6AddressField
from .password import PasswordField
from .path import PathField
from .phonenumber import PhoneNumberField, PhonenumberField
from .restricted_char import RestrictedCharField
from .username import UsernameField, UserNameField

# BareField, ForeignKeyField,
# from .jsontext import JSONTextField  # """FOR WHAT ???"""
# from .html import HTMLCharField, HTMLTextField


try:
    import peewee_extra_fields
except ImportError:
    pass

if "peewee_extra_fields" in sys.modules:
    from peewee_extra_fields import PasswordField  # bcrypt require
    from peewee_extra_fields import (
        ColorHexadecimalField,
        CurrencyISOCodeField,
        IANCodeField,
        IBANISOCodeField,
        IPNetworkField,
        LanguageISOCodeField,
        MoneyField,
        SemVerField,
        SimplePasswordField,
        SWIFTISOCodeField,
        XMLField,
    )

    # SimplePasswordField using secrets and hashlib from standard library, without dependencies
    # from stdlib import IPAddressField


RealField = FloatField
DatetimeField = DateTimeField

# from peewee import *

__all__ = FIELDS = (
    "FIELDS",
    *sorted(x for x, y in dict(vars()).items() if type(y) is type and x.endswith("Field")),
)
# потому что сложно перечислить их все
# type(y) is type хак для is_class && y.__class__.__name__ == x
