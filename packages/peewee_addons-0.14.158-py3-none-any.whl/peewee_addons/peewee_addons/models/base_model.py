# =============================================================================
#
# https://docs.peewee-orm.com/en/latest/peewee/querying.html
#
# =============================================================================


from peewee import AutoField, Model

from ..databases import Database


class BaseModel(Model):

    # Peewee automatically adds auto-increment field `id`, if possible in the current database, but...
    id: int = AutoField()

    class Meta:
        # https://docs.red-dove.com/peewee/peewee/models.html#model-options-and-table-metadata

        database = Database(None)
        only_save_dirty = True
        legacy_table_names = False

        """
        depends_on = [model's list]
        
            if model._meta.depends_on:
                for dependency in model._meta.depends_on:
                    dfs(dependency)
            ordering.append(model)
        """

        # Meta

    """ CRUD operations commonly performed on a relational database:
            Model.create(), for executing INSERT queries.
            Model.save() and Model.update(), for executing UPDATE queries.
            Model.delete_instance() and Model.delete(), for executing DELETE queries.
            Model.select(), for executing SELECT queries.
    """

    def __str__(self):
        """
        result: <CLASS(table.pk): [data row]>
        """

        _pk = str(self._pk) if (bool(self._meta.primary_key) and self._pk is not None) else "N/A"
        _class = self.__class__.__name__
        _db_class = self._meta.database.__class__.__name__
        _db = self._meta.database.database
        _table = self._meta.table_name
        _data = (
            ", ".join(["%s='%s'" % (_k, _v) for _k, _v in self.__data__.items()])
            if self._pk is not None
            else ""
        )

        return "<{_class}({_table}:{_pk}) [{_data}]>".format(**locals())
        # с базой вывод красивее
        return "<{_class}({_db_class}{{{_db}}}.{_table}:{_pk}) [{_data}]>".format(**locals())
