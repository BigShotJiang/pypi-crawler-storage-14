####
##
#
#

# from db import DB, KVModel

from playhouse.kv import KeyValue

from .base_model import (
    SQLITE_PRAGMAS,
    BigIntegerField,
    CharField,
    Database,
    Field,
    IntegerField,
    JSONField,
    Model,
    PickleField,
    TextField,
)

KV_PRAGMAS = SQLITE_PRAGMAS.copy()
KV_PRAGMAS.update(
    dict(
        auto_vacuum="INCREMENTAL",  # 0 | NONE | 1 | FULL | 2 | INCREMENTAL
        cache_size=-(16),  # aprx 128kb = 128*1024  # 64MB = (64*1024)*1024
        foreign_keys=0,  # Enforce foreign-key constraints
        encoding="UTF8",  #
        journal_mode="PERSIST",  # Use WAL-mode (you should always use this)
        ignore_check_constraints=1,
        temp_store="MEMORY",
    )
)


class BaseKeyValue(KeyValue):
    class Meta:
        """не тот же самый класс, как в модели -- поведение не наследуется"""

        pragmas = KV_PRAGMAS  # ненужно
        database = Database(None, pragmas=KV_PRAGMAS)
        table_name = None
        ordered = False

        key_field = IntegerField(column_name="key", primary_key=True)
        value_field = CharField(column_name="value", index=False, null=True)
        # 4080=255*16
        # number is allowed for compatibility with standard SQL. but is ignored.

    def __init__(self, *args, **kwargs):
        """
        class KeyValue([key_field=None[, value_field=None[, ordered=False[, database=None[, table_name='keyvalue']]]]])

        Parameters
            key_field (Field) – field to use for key. Defaults to CharField. Must have primary_key=True.
            value_field (Field) – field to use for value. Defaults to PickleField.
            ordered (bool) – data should be returned in key-sorted order.
            database (Database) – database where key/value data is stored. If not specified, an in-memory SQLite database will be used.
            table_name (str) – table name for data storage.
        """

        super().__init__(
            key_field=(self.Meta.key_field if hasattr(self.Meta, "key_field") else None),
            value_field=(self.Meta.value_field if hasattr(self.Meta, "value_field") else None),
            ordered=(self.Meta.ordered if hasattr(self.Meta, "ordered") else None),
            database=(self.Meta.database if hasattr(self.Meta, "database") else None),
            table_name=(self.Meta.table_name if hasattr(self.Meta, "table_name") else None),
        )
        if kwargs:
            self.update(**kwargs)

        pass  # def __init__

    def __call__(self, *args, **kwargs):
        [self.update(**a) for a in args if isinstance(a, dict)]
        self.update(**kwargs)
        return self

    # def __getattr__(self, name):
    # return self.setdefault(name)
    #
    # def __setattr__(self, name, value):
    # return self.setdefault(name, value)

    #    def incr(self, key: str, quantity=1):
    # key = str(key)
    #        self.__setitem__(key, self.get(key, 0) + quantity)
    #        return self
    #
    #    def decr(self, key: str, quantity=1):
    #        return self.incr(key, -quantity)
    #
    #    def rename(self, key: str, new_key: str):
    #        self.__setitem__(str(new_key), self.setdefault(key, None))
    #        self.__delitem__(key)
    #        return self

    def clear(self):
        raise ValueError("PLEASE NO")

    pass  # BaseKeyValue
