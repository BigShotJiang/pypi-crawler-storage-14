# =============================================================================
#
# https://docs.peewee-orm.com/en/latest/peewee/querying.html
#
# =============================================================================


from peewee import Model

from playhouse.shortcuts import dict_to_model, model_to_dict, update_model_from_dict

from ..databases import Database, connect, register_database

# from typing import Any, Dict, List, Union
# from playhouse.hybrid import hybrid_method, hybrid_property


database = Database(None)


class BaseModel(Model):
    # id = AutoField()

    class Meta:
        # https://docs.red-dove.com/peewee/peewee/models.html#model-options-and-table-metadata

        database = database
        only_save_dirty = True
        legacy_table_names = False

        """
        depends_on = [model's list]
        
            if model._meta.depends_on:
                for dependency in model._meta.depends_on:
                    dfs(dependency)
            ordering.append(model)
        """

        # Meta

    """ CRUD operations commonly performed on a relational database:
            Model.create(), for executing INSERT queries.
            Model.save() and Model.update(), for executing UPDATE queries.
            Model.delete_instance() and Model.delete(), for executing DELETE queries.
            Model.select(), for executing SELECT queries.
    """

    @classmethod
    def fields_filter(cls, *args, **kwargs) -> dict:
        return dict(
            filter(
                lambda e: e if e[0] in cls._meta.fields.keys() else False,
                args[0].__dict__.items(),
            )
        )

        # можно было через update_model_from_dict(instance, data[, ignore_unknown=False])
        # https://docs.peewee-orm.com/en/latest/peewee/playhouse.html#update_model_from_dict

        keys = cls._meta.fields.keys()
        arg = args[0]
        arg = arg.to_dict() if isinstance(arg, bot_types.Dictionaryable) else arg.__dict__
        ret = {k: v for k, v in arg.items() if k in keys}
        return ret

    ffilter = fields_filter

    def to_dict(self, *args, **kwargs) -> dict:
        return model_to_dict(self, *args, **kwargs)

    @classmethod
    def from_dict(cls, data: dict, ignore_unknown: bool = True) -> "__class__":
        return dict_to_model(cls, data, ignore_unknown)

    def update_from_dict(self, data: dict, ignore_unknown: bool = True) -> "self":
        return update_model_from_dict(self, data, ignore_unknown)

    def save_dict(self, data: dict, ignore_unknown: bool = True) -> "self":
        update_model_from_dict(self, data, ignore_unknown)
        self.save()
        return self

    pass
