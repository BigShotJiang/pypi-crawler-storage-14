import json
from fpdf import FPDF
# NOTE: pdfkit and jinja2 are no longer needed, removing the dependency on wkhtmltopdf

# --- FPDF Class Helper for Custom Layout ---
class PolicyPDF(FPDF):
    """Custom FPDF class to define standard header/footer methods if needed."""
    def header(self):
        # Optional: Add a Mobishield logo or title on every page
        self.set_font('Arial', 'B', 15)
        self.cell(0, 10, 'Mobishield Policy Document', 0, 1, 'C')
        self.ln(5)

    def footer(self):
        # Optional: Page number at the bottom
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}/{{nb}}', 0, 0, 'C')

# --- PDF Generation Function (Accepts Dictionary) ---
def generate_policy_pdf_from_dict(policy_data: dict, output_filename: str = 'policy_document.pdf'):
    """
    Parses policy data (as a dictionary) and generates a PDF using FPDF2.

    Args:
        policy_data (dict): A dictionary containing policy details.
        output_filename (str): The name of the output PDF file.
    """
    try:
        pdf = PolicyPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        pdf.set_font('Arial', '', 12)
        
        # Define styling helpers
        def add_data_row(label, value):
            """Helper to print label/value pair"""
            # Label (Bold, Left)
            pdf.set_font('Arial', 'B', 12)
            pdf.cell(50, 8, label, 0, 0, 'L')
            
            # Value (Regular, Right, fills the rest of the page width)
            pdf.set_font('Arial', '', 12)
            pdf.cell(0, 8, value, 0, 1, 'R') # 0 width means 'until margin', 1 means new line

        # ----------------------------------------------------
        # 1. TITLE
        # ----------------------------------------------------
        pdf.set_font('Arial', 'B', 18)
        pdf.set_fill_color(220, 220, 255)
        pdf.cell(0, 12, 'Policy Confirmation', 0, 1, 'C', fill=True)
        pdf.ln(5)

        # ----------------------------------------------------
        # 2. CUSTOMER INFORMATION SECTION
        # ----------------------------------------------------
        pdf.set_font('Arial', 'B', 14)
        pdf.cell(0, 10, 'Customer Information', 'B', 1, 'L')
        pdf.ln(2)
        
        add_data_row('Policy Holder:', policy_data.get('customer_name', 'N/A'))
        add_data_row('Email:', policy_data.get('email', 'N/A'))
        add_data_row('Policy ID:', policy_data.get('policy_id', 'N/A'))
        pdf.ln(5)

        # ----------------------------------------------------
        # 3. DEVICE & COVERAGE SECTION
        # ----------------------------------------------------
        pdf.set_font('Arial', 'B', 14)
        pdf.cell(0, 10, 'Device & Coverage Details', 'B', 1, 'L')
        pdf.ln(2)

        device = f"{policy_data.get('device_make', '')} {policy_data.get('device_model', '')}"
        add_data_row('Device:', device.strip())
        add_data_row('IMEI:', policy_data.get('imei', 'N/A'))
        add_data_row('Coverage Type:', policy_data.get('coverage_type', 'N/A'))
        add_data_row('Premium:', f"${policy_data.get('premium_amount', '0.00')}")

        # ----------------------------------------------------
        # 4. OUTPUT
        # ----------------------------------------------------
        pdf.output(output_filename)
        
        print(f"✅ Success: Policy PDF generated at '{output_filename}' using FPDF2.")
        
    except Exception as e:
        print(f"❌ An error occurred during PDF generation: {e}")

