cvasl.carve module
==================

.. automodule:: cvasl.carve
   :members:
   :undoc-members:
   :show-inheritance:
