.. _spkg_auditwheel_or_delocate:

auditwheel_or_delocate: Repair wheels on Linux or macOS
=======================================================

Description
-----------

This package represents ``auditwheel`` on Linux and ``delocate`` on macOS.

(Actually, we install ``delocate`` also on Linux because our script
``make -j list-broken-packages`` uses a small subroutine of ``delocate``
even on Linux.)

License
-------

MIT

BSD 2-clause

Upstream Contact
----------------

https://pypi.org/project/auditwheel/

https://pypi.org/project/delocate/


Type
----

optional


Dependencies
------------

- $(PYTHON)
- $(PYTHON_TOOLCHAIN)

Version Information
-------------------

requirements.txt::

    delocate
    auditwheel; sys_platform != 'darwin'

Installation commands
---------------------

.. tab:: PyPI:

   .. CODE-BLOCK:: bash

       $ pip install delocate auditwheel\;sys_platform\!=\'darwin\'

.. tab:: Sage distribution:

   .. CODE-BLOCK:: bash

       $ sage -i auditwheel_or_delocate


If the system package is installed and if the (experimental) option
``--enable-system-site-packages`` is passed to ``./configure``, then 
``./configure`` will check if the system package can be used.
