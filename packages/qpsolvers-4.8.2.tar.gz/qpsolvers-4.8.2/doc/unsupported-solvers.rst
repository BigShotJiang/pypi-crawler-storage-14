*******************
Unsupported solvers
*******************

Unsupported solvers will be made available if they are detected on your system, but their performance is not guaranteed as they are not part of `continuous integration <https://github.com/qpsolvers/qpsolvers/actions>`__ (typically because they are not open source).

NPPro
=====

.. automodule:: qpsolvers.unsupported.nppro_
    :members:
