# handles authentication passing
from . import crypto_utils
import json

def verify_admin(input_username, input_pwrd) -> bool: 
        with open(f"{input_username}.json") as DB:
            credentials = json.load(DB)
        valid = crypto_utils.verify_admin(credentials["ciphertext"], input_pwrd)
        return valid


