# handles the packaging + passing of inputs to core functions
from . import auth_manager
from . import crypto_utils
from . import storage

# admin specific functions
def add_admin(admin_username, admin_pwrd):
    admin = storage.init_admin_DB(admin_username, admin_pwrd)
    user = storage.init_user_DB(admin_username, admin_pwrd)
    return admin, user

# database functions
def add_creds(admin_username, admin_password, new_username, new_website, new_password):
    if auth_manager.verify_admin(admin_username, admin_password):
        #encrypting the password and packaging all the new credentials into dict
        print("Adding new entry ...")
        salt = crypto_utils.generate_salt()
        key = crypto_utils.derive_key(admin_password, salt)
        token = crypto_utils.encrypt(key, new_password)
        
        new_creds = {"username": new_username,
       "website": new_website,
       "salt": salt.decode(),
       "password": token.decode()}

        return storage.add_creds(admin_username, admin_password, new_creds)

def delete_creds(admin_username, admin_password, entry_ID):
    if auth_manager.verify_admin(admin_username, admin_password): 
        print(f"Deleting entry {entry_ID}...") 
        return storage.delete_creds(admin_username, admin_password, int(entry_ID))

def update_creds(admin_username, admin_password, entry_ID, field, new_info ):
    if auth_manager.verify_admin(admin_username, admin_password): 
        print(f"Updating entry {entry_ID}...")  
        return storage.edit_creds(admin_username, admin_password, field, new_info, int(entry_ID))

def list_all(admin_username, admin_password):
    if auth_manager.verify_admin(admin_username, admin_password): 
        return storage.list_creds(admin_username, admin_password) 
    
def list_by_site(admin_username, admin_password, site):
    if auth_manager.verify_admin(admin_username, admin_password): 
        return storage.list_by_site(admin_username, admin_password, site)
    
def see_pwrd(admin_username, admin_password, entry_ID):
    if auth_manager.verify_admin(admin_username, admin_password): 
        return storage.view_pwrd(admin_username, admin_password, int(entry_ID))
  
def reset_DB(admin_username, admin_password):
    if auth_manager.verify_admin(admin_username, admin_password): 
        print(f"Resetting {admin_username}'s vault...") 
        return storage.reset_DB(admin_username, admin_password)

def delete_admin(admin_username, admin_password):
    if auth_manager.verify_admin(admin_username, admin_password): 
        # second confirmation conditional
        confirm2 = input("Please understand that you are NOT reseting the vault.\nYou are DELETING your vault and admin account.\Do you wish to proceed? Y/N? ")
        if confirm2 == "Y" or confirm2 == "y":
            print(f"Deleting admin account{admin_username}...") 
            return storage.delete_admin(admin_username)
        else: 
            print("Delete admin request cancelled.")


