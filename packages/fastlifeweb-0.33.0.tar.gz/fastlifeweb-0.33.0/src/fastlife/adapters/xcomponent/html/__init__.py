"""
This module load the html components for the xcomponent template engine.

Those components are loaded, injected in the catalog using a
{meth}`config.include <fastlife.config.configurator.Configurator.include>`
done before the app is created.
"""
