"""Testing fastlife client."""

from .testclient import WebTestClient

__all__ = ["WebTestClient"]
