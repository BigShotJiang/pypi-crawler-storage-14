import sys
import os

try:
    import glucobench
    print(f"glucobench imported from: {glucobench.__file__}")
    
    import glucobench.lib
    print(f"glucobench.lib imported from: {glucobench.lib.__file__}")
    
    from glucobench.lib.gluformer.model import Gluformer
    print("Successfully imported Gluformer")
    
    from glucobench.utils.darts_dataset import *
    print("Successfully imported utils")

except ImportError as e:
    print(f"Import failed: {e}")
except Exception as e:
    print(f"Error: {e}")

