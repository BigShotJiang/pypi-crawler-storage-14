# Project Euler Helper

A Python library containing utility functions for solving Project Euler problems.

## Installation

```bash
git clone https://github.com/LeoSenthan/project-euler-helper.git
cd project-euler-helper
pip install -e .