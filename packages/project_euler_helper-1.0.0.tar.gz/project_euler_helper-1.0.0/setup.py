from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="project-euler-helper",
    version="1.0.0",
    author="Leomaran Senthan",
    author_email="leosenthan@gmail.com",
    description="A collection of helper functions for solving Project Euler problems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/LeoSenthan/ProjectEulerHelper",
    packages=["ProjectEulerHelper"],
    package_dir={"": "."},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Education",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires=">=3.7",
    install_requires=[
        "numpy>=1.20.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov",
            "black",
            "flake8",
            "mypy",
        ],
    },
    keywords="project-euler mathematics combinatorics sequences primes digits utilities",
    project_urls={
        "Source": "https://github.com/LeoSenthan/ProjectEulerHelper",
    },
)