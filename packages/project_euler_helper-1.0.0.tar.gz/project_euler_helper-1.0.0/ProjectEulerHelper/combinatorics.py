import math
from itertools import permutations, combinations, combinations_with_replacement, product
from collections import Counter


def factorial(n: int) -> int:
    """
    Calculates the factorial of a number.

    Parameters:
        n (int): Number to calculate factorial.

    Returns:
        int: n! (factorial of n).
    """
    if n < 0:
        raise ValueError("Factorial not defined for negative numbers")
    return math.prod(range(1, n + 1), 1)


def nPr(n: int, r: int) -> int:
    """
    Calculates number of permutations of n items taken r at a time.

    Parameters:
        n (int): Total number of items.
        r (int): Number of items to arrange.

    Returns:
        int: Number of permutations = n!/(n-r)!
    """
    if r < 0 or r > n:
        return 0
    return factorial(n) // factorial(n - r)


def nCr(n: int, r: int) -> int:
    """
    Calculates number of combinations of n items taken r at a time.

    Parameters:
        n (int): Total number of items.
        r (int): Number of items to choose.

    Returns:
        int: Number of combinations = n!/(r!(n-r)!)
    """
    if r < 0 or r > n:
        return 0
    if r > n // 2:
        r = n - r
    return math.prod(range(n - r + 1, n + 1)) // factorial(r)


def nCr_multiset(n: int, r: int) -> int:
    """
    Calculates number of combinations with repetition.

    Parameters:
        n (int): Number of types of items.
        r (int): Number of items to choose.

    Returns:
        int: Number of combinations with repetition = (n + r - 1)!/(r!(n-1)!)
    """
    return nCr(n + r - 1, r)


def generate_permutations(iterable, r=None):
    """
    Generates all permutations of length r from iterable.

    Parameters:
        iterable: Input sequence.
        r (int): Length of permutations (default: len(iterable)).

    Returns:
        iterator: All permutations.
    """
    return permutations(iterable, r)


def generate_combinations(iterable, r: int):
    """
    Generates all combinations of length r from iterable.

    Parameters:
        iterable: Input sequence.
        r (int): Length of combinations.

    Returns:
        iterator: All combinations.
    """
    return combinations(iterable, r)


def generate_combinations_with_replacement(iterable, r: int):
    """
    Generates combinations with repeated elements.

    Parameters:
        iterable: Input sequence.
        r (int): Length of combinations.

    Returns:
        iterator: All combinations with replacement.
    """
    return combinations_with_replacement(iterable, r)


def generate_cartesian_product(*iterables, repeat=1):
    """
    Generates Cartesian product of input iterables.

    Parameters:
        *iterables: Input sequences.
        repeat (int): Number of times to repeat the product.

    Returns:
        iterator: Cartesian product.
    """
    return product(*iterables, repeat=repeat)


def integer_partitions(n: int, max_part=None) -> list:
    """
    Generates all integer partitions of n.

    Parameters:
        n (int): Number to partition.
        max_part (int): Maximum part size (default: n).

    Returns:
        list: List of all integer partitions.
    """
    if n == 0:
        return [[]]
    
    if max_part is None or max_part > n:
        max_part = n
    
    partitions = []
    for first in range(max_part, 0, -1):
        for partition in integer_partitions(n - first, first):
            partitions.append([first] + partition)
    return partitions


def count_integer_partitions(n: int) -> int:
    """
    Counts number of integer partitions using dynamic programming.

    Parameters:
        n (int): Number to partition.

    Returns:
        int: Number of integer partitions.
    """
    dp = [0] * (n + 1)
    dp[0] = 1
    for i in range(1, n + 1):
        for j in range(i, n + 1):
            dp[j] += dp[j - i]
    return dp[n]


def catalan_number(n: int) -> int:
    """
    Calculates the nth Catalan number.

    Parameters:
        n (int): Index of Catalan number.

    Returns:
        int: nth Catalan number = (2n)!/((n+1)!n!)
    """
    return factorial(2 * n) // (factorial(n + 1) * factorial(n))


def multiset_permutations_count(multiset) -> int:
    """
    Counts permutations of a multiset.

    Parameters:
        multiset: List of items or Counter object.

    Returns:
        int: Number of distinct permutations = n!/(n1! * n2! * ... * nk!)
    """
    if isinstance(multiset, Counter):
        counts = multiset
        total = sum(counts.values())
    else:
        counts = Counter(multiset)
        total = len(multiset)
    
    result = factorial(total)
    for count in counts.values():
        result //= factorial(count)
    return result


def generate_multiset_permutations(multiset):
    """
    Generates all distinct permutations of a multiset.

    Parameters:
        multiset: List of items or Counter object.

    Returns:
        list: All distinct permutations.
    """
    def _generate(counts, current):
        if sum(counts.values()) == 0:
            return [tuple(current)]
        
        results = []
        for item in list(counts.keys()):
            if counts[item] > 0:
                counts[item] -= 1
                current.append(item)
                results.extend(_generate(counts, current))
                current.pop()
                counts[item] += 1
        return results
    
    if isinstance(multiset, Counter):
        counts = multiset.copy()
    else:
        counts = Counter(multiset)
    
    return _generate(counts, [])


def derangements_count(n: int) -> int:
    """
    Counts derangements - permutations with no fixed points.

    Parameters:
        n (int): Number of items.

    Returns:
        int: Number of derangements !n.
    """
    if n == 0:
        return 1
    if n == 1:
        return 0
    
    d0, d1 = 1, 0
    for i in range(2, n + 1):
        d0, d1 = d1, (i - 1) * (d1 + d0)
    return d1


def stirling_first(n: int, k: int) -> int:
    """
    Calculates Stirling numbers of the first kind (unsigned).

    Parameters:
        n (int): Total number of items.
        k (int): Number of cycles.

    Returns:
        int: Stirling number of first kind s(n,k).
    """
    if n == k == 0:
        return 1
    if n == 0 or k == 0:
        return 0
    if k > n:
        return 0
    
    dp = [[0] * (k + 1) for _ in range(n + 1)]
    dp[0][0] = 1
    
    for i in range(1, n + 1):
        for j in range(1, min(i, k) + 1):
            dp[i][j] = dp[i-1][j-1] + (i-1) * dp[i-1][j]
    
    return dp[n][k]


def stirling_second(n: int, k: int) -> int:
    """
    Calculates Stirling numbers of the second kind.

    Parameters:
        n (int): Total number of items.
        k (int): Number of non-empty subsets.

    Returns:
        int: Stirling number of second kind S(n,k).
    """
    if n == k == 0:
        return 1
    if n == 0 or k == 0:
        return 0
    if k > n:
        return 0
    
    dp = [[0] * (k + 1) for _ in range(n + 1)]
    dp[0][0] = 1
    
    for i in range(1, n + 1):
        for j in range(1, min(i, k) + 1):
            dp[i][j] = dp[i-1][j-1] + j * dp[i-1][j]
    
    return dp[n][k]


def binomial_coefficients_row(n: int) -> list[int]:
    """
    Generates the nth row of Pascal's triangle.

    Parameters:
        n (int): Row index (0-indexed).

    Returns:
        list[int]: Binomial coefficients for (a+b)^n.
    """
    row = [1]
    for k in range(1, n + 1):
        row.append(row[-1] * (n - k + 1) // k)
    return row


def next_permutation(sequence):
    """
    Generates the next lexicographical permutation of a sequence.

    Parameters:
        sequence: Input sequence (list, tuple, or string).

    Returns:
        object: Next permutation or None if last permutation.
    """
    seq = list(sequence)
    n = len(seq)
    
    # Find the largest index i such that seq[i] < seq[i+1]
    i = n - 2
    while i >= 0 and seq[i] >= seq[i + 1]:
        i -= 1
    
    if i < 0:
        return None  # Last permutation
    
    # Find the largest index j such that seq[j] > seq[i]
    j = n - 1
    while seq[j] <= seq[i]:
        j -= 1
    
    # Swap and reverse
    seq[i], seq[j] = seq[j], seq[i]
    seq[i + 1:] = reversed(seq[i + 1:])
    
    if isinstance(sequence, tuple):
        return tuple(seq)
    elif isinstance(sequence, str):
        return ''.join(seq)
    else:
        return seq