
def digits(n: int) -> list[int]:
    """
    Returns the digits of n as a list.

    Parameters:
        n (int): The number to find the digits of.
    
    Returns:
        list[int]: Returns the list of digits in integer format.
    """
    return [int(digit) for digit in str(n)]

def num_digits(n:int) -> int:
    """
    Returns the number of digits in base 10.

    Parameters:
        n (int): The number to check.
    
    Returns:
        int: Returns the number of digits.
    """
    return len(str(n))

def reverse_digits(n:int) -> int:
    """
    Returns the number with reversed digits if the reversed number has 0s at the beginning these are removed.

    Parameters:
        n (int): The number to be reversed.

    Returns:
        int: The number after being reversed
    """
    return int(str(n)[::-1])

def sum_digits(n:int) -> int:
    """
    Returns the sum of digits of an integer

    Parameters:
        n (int): The number that needs to be checked.
    
    Returns:
        int: The sum of the digits of n
    """
    return sum(int(digit) for digit in str(n))

def product_digits(n:int) -> int:
    """
    Returns the product of the digits of an integer

    Parameters:
        n (int): The number that needs to be checked.
    
    Returns:
        int: The product of the digits of n
    """
    digits = [int(digit) for digit in str(n)]
    start = 1
    for digit in digits:
        start *= digit
    return start

def is_palindrome(n:int) -> bool:
    """
    Checks if an integer is a palindrome.

    Parameters:
        n (int): The number to be checked.
    
    Returns:
        bool: True if palindrome else false
    """
    n = str(n)
    return n == n[::-1]

def is_pandigital(n:int) -> bool:
    """
    Checks if a number contains digits 1..length of n.

    Parameters:
        n (int): The number to be checked.
    
    Returns:
        bool: True if pandigital else False
    """
    if n > 10**9:
        return False
    n = sorted(str(n))
    check = [str(digit) for digit in range(1,len(n)+1)]
    return n == check

def rotations(n:int) -> list[int]:
    """
    Finds all rotations of an integer e.g.  123 returns [123,312,231]
    If a 0 is the first digit this is removed.
    Parameters:
        n (int): The integer to be checked.
    
    Returns:
        list[int]: A list of all the rotations sorted in ascending order.
    """
    digits = str(n)
    ans = [int(digits[i:] + digits[:i]) for i in range(len(digits))]
    return sorted(ans)

def is_permutation(a:int, b:int) -> bool:
    """
    Checks if one digit is a permutation of another.

    Parameters:
        a (int): One of the numbers to be checked.
        b (int): One of the numbers to be checked.
    
    Returns:
        bool: True if they are permutations else False
    """
    return sorted(str(a)) == sorted(str(b))

def to_base(n:int, base:int) -> str:
    """
    Convert number to any base (2–36).
    Parameters:
        n (int): The number to be converted can be negative.
        base (int): The base the number shall be converted to between 2 and 36 inclusive.
    Returns:
        The string form of the number including the base in the format base number:converted number
        e.g. b12:A901
    """
    if base < 2 or base > 36:
        raise ValueError("Base must be between 2 and 36")

    values = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if n == 0:
        return f"b{base}:0"
    neg = n < 0
    n = abs(n)
    digits = []
    while n > 0:
        digits.append(values[n % base])
        n //= base
    if neg:
        digits.append('-')
    return f"b{base}:{''.join(reversed(digits))}"

def from_base(n:str) -> int:
    """
    Converts base representation to integer.
    Parameters:
        n (str): Must be in the format base:digits e.g. b12:23B5A
    Returns:
        int: The number in base 10
    """
    values = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    n = n[1:]
    colon = n.find(":")
    base = int(n[:colon])
    n = n[colon+1:][::-1]
    current = 1
    ans = 0
    for digit in n:
        ans += values.find(digit) * current
        current *= base
    return ans

def digital_root(n:int) -> int:
    """
    Repeated digit sum until one digit (used in some Euler problems).

    Parameters:
        n (int): The number for this to be applied to.
    Returns:
        int: Always between 1 and 9
    """
    while n > 9:
        n = sum(int(digit) for digit in str(n))
    return n

def multiplicative_persistence(n:int) -> int:
    """
    Repeated digit product until one digit (used in some Euler problems).

    Parameters:
        n (int): The number for this to be applied to
    Returns:
        int: Always between 0 and 9
    """
    while n > 9:
        current = 1
        for digit in str(n):
            current *= int(digit)
        n = current
    return n
