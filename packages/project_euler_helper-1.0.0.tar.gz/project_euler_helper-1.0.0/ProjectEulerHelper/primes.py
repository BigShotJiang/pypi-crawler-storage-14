import numpy as np
import math

def sieve(n: int) -> list[int]:
    """
    Returns all prime numbers <= n usingSieve of Eratosthenes.

    Parameters:
        n (int): Upper limit of primes to generate.

    Returns:
        List[int]: List of prime numbers up to n.
    """
    sieve = np.ones(n+1, dtype=bool)
    sieve[:2] = False
    for i in range(2, int(math.sqrt(n))+1):
        if sieve[i]:
            sieve[i*i:n+1:i] = False
    return np.nonzero(sieve)[0].tolist()

def sieve_in_range(a: int,b: int) -> list[int]:
    """
    Returns all prime numbers in range [a,b] inclusive using Sieve of Eratosthenes.
    
    Parameters:
        a (int): Lower limit of primes to generate.
        b (int): Upper limit of primes to generate.
    
    Returns:
        List[int]: List of prime numbers between a and b (inclusive)
    """
    check_primes = sieve(int(math.sqrt(b)))
    sieve_arr = np.ones(b + 1 - a, dtype=bool)
    for prime in check_primes:
        start = max(prime * prime, ((a + prime - 1) // prime) * prime)
        sieve_arr[start - a : b + 1 - a : prime] = False
    if a == 1:
        sieve_arr[0] = False
    return (np.nonzero(sieve_arr)[0] + a).tolist()

def prime_generator():
    """
    Generate prime numbers indefinitely using trial division up to sqrt(n).
    """
    primes = []
    current = 2
    while True:
        is_prime = True
        sqrt_current = math.isqrt(current)
        for p in primes:
            if p > sqrt_current:
                break
            if current % p == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(current)
            yield current
        current += 1

def nth_prime(n: int) -> int:
    """
    Finds the nth prime number using trial division up to sqrt(n)

    Parameters:
        n (int): The nth prime number to find

    Returns:
        int: The nth prime number
    """
    primes = [2]
    count = 1
    current = 3
    while count != n:
        is_prime = True
        sqrt_current = math.isqrt(current)
        for p in primes:
            if p > sqrt_current:
                break
            if current % p == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(current)
            count += 1
        current += 1
    return primes[-1]

def is_prime(n: int) -> bool:
    """
    Checks whether a number n is a prime number (USE FOR SMALL n)

    Paramters:
        n (int): Number to check if prime
    
    Returns:
        Bool: True if Prime else False
    
        
    """
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False    
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def prime_factors(n: int) -> list[int]:
    """
    Finds the prime factors of a number.

    Parameters:
        n (int): The number to find prime factors.
    
    Returns:
        List[int]: Returns primes in ascending order.
    """
    if n <= 1:
        return []

    factors = []
    while n % 2 == 0:
        factors.append(2)
        n //= 2
    f = 3
    while f * f <= n:
        while n % f == 0:
            factors.append(f)
            n //= f
        f += 2
    if n > 1:
        factors.append(n)
    return factors

def is_coprime(a:int, b:int) -> bool:
    """
    Checks if two numbers are coprime (Where they share no common divisor apart from 1)
    Parameters:
        a (int): One of the numbers to be checked.
        b (int): One of the numbers to be checked.
    Returns:
        bool: True if they are coprime else False.
    """
    def gcd(a,b):
        if b == 0:
            return a
        return gcd(b, a % b)
    return gcd(a,b) == 1

def totient(n:int) -> int:
    """
    Finds the number of numbers in range 1 to <= n where they are coprime with n.
    Parameters:
        n (int): The number this function will be applied on.
    Returns:
        int: The number of numbers where they are coprime with n.
    """
    count = 0
    for i in range(1,n+1):
        if is_coprime(i,n):
            count += 1
    return count

def mobius(n:int) -> int:
    """
    Applies the Mobius function from number theory to n.
    Parameters:
        n(int): The number to be checked.
    Returns:
        0 if the number has duplicate prime factors
        1 if n = 1
        (-1)**k where k is the number of distinct prime factors
    """
    if n == 1:
        return 1
    primes = prime_factors(n)
    if len(list(set(primes))) != len(primes):
        return 0
    return (-1) ** len(primes)

def divisors(n:int) -> list[int]:
    """
    Finds all the divisors of a number.
    Parameters:
        n (int): The number which all divisors will be found for.
    Returns:
        list[int]: A list of all divisors which is ordered.
    """
    ans = []
    if n % int(math.sqrt(n)) == 0:
        ans.append(int(math.sqrt(n)))
    for divisor in range(1,int(math.sqrt(n))+1):
        if n % divisor == 0:
            if divisor not in ans:
                ans += [divisor] + [n // divisor]
            else:
                break
    return sorted(ans)
