"""
Project Euler Helper Library
A collection of utility functions for solving Project Euler problems.
"""

__version__ = "1.0.0"
__author__ = "Leomaran Senthan"
__email__ = "leosenthan@gmail.com"

# Import modules to make them available at package level
from . import sequences
from . import combinatorics
from . import digits
from . import primes

# Import commonly used functions for easy access
from .sequences import (
    fibonacci,
    fibonacci_sequence,
    is_fibonacci,
    collatz_sequence,
    collatz_length,
    triangular,
    is_triangular,
    pentagonal,
    is_pentagonal,
    hexagonal,
    is_hexagonal,
    arithmetic_sequence,
    geometric_sequence,
    nth_arithmetic,
    nth_geometric,
    factorial_sequence,
    double_factorial,
    superfactorial,
    hyperfactorial
)

from .combinatorics import (
    factorial,
    nPr,
    nCr,
    nCr_multiset,
    generate_permutations,
    generate_combinations,
    generate_combinations_with_replacement,
    generate_cartesian_product,
    integer_partitions,
    count_integer_partitions,
    catalan_number,
    multiset_permutations_count,
    generate_multiset_permutations,
    derangements_count,
    stirling_first,
    stirling_second,
    digits_permutations,
    is_permutation,
    binomial_coefficients_row,
    next_permutation
)

from .digits import (
    digits,
    num_digits,
    reverse_digits,
    sum_digits,
    product_digits,
    is_palindrome,
    is_pandigital,
    rotations,
    to_base,
    from_base,
    digital_root,
    multiplicative_persistence
)

from .primes import (
    sieve,
    sieve_in_range,
    prime_generator,
    nth_prime,
    is_prime,
    prime_factors,
    is_coprime,
    totient,
    mobius,
    divisors
)

# Define what gets imported with "from ProjectEulerHelper import *"
__all__ = [
    # Sequences module
    'fibonacci',
    'fibonacci_sequence', 
    'is_fibonacci',
    'collatz_sequence',
    'collatz_length',
    'triangular',
    'is_triangular',
    'pentagonal',
    'is_pentagonal',
    'hexagonal',
    'is_hexagonal',
    'arithmetic_sequence',
    'geometric_sequence',
    'nth_arithmetic',
    'nth_geometric',
    'factorial_sequence',
    'double_factorial',
    'superfactorial',
    'hyperfactorial',
    
    # Combinatorics module
    'factorial',
    'nPr',
    'nCr',
    'nCr_multiset',
    'generate_permutations',
    'generate_combinations',
    'generate_combinations_with_replacement',
    'generate_cartesian_product',
    'integer_partitions',
    'count_integer_partitions',
    'catalan_number',
    'multiset_permutations_count',
    'generate_multiset_permutations',
    'derangements_count',
    'stirling_first',
    'stirling_second',
    'digits_permutations',
    'is_permutation',
    'binomial_coefficients_row',
    'next_permutation',
    
    # Digits module
    'digits',
    'num_digits',
    'reverse_digits',
    'sum_digits',
    'product_digits',
    'is_palindrome',
    'is_pandigital',
    'rotations',
    'to_base',
    'from_base',
    'digital_root',
    'multiplicative_persistence',
    
    # Primes module
    'sieve',
    'sieve_in_range',
    'prime_generator',
    'nth_prime',
    'is_prime',
    'prime_factors',
    'is_coprime',
    'totient',
    'mobius',
    'divisors'
]