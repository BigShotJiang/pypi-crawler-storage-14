import math


def fibonacci(n: int) -> int:
    """
    Finds the nth Fibonacci number.

    Parameters:
        n (int): Index in the sequence (0-indexed).

    Returns:
        int: The nth Fibonacci number.
    """
    if n == 0:
        return 0
    if n == 1:
        return 1

    prev, current = 0, 1
    count = 1

    while count < n:
        prev, current = current, prev + current
        count += 1

    return current


def fibonacci_sequence(n: int) -> list[int]:
    """
    Generates the Fibonacci sequence up to the nth number (inclusive).

    Parameters:
        n (int): Number of terms to generate.

    Returns:
        list[int]: List of Fibonacci numbers from 0 to nth term.
    """
    if n == 0:
        return [0]
    if n == 1:
        return [0, 1]
    ans = [0, 1]
    while len(ans) != n + 1:
        ans.append(ans[-1] + ans[-2])
    return ans


def is_fibonacci(n: int) -> bool:
    """
    Checks if a number is a Fibonacci number.

    Parameters:
        n (int): Number to check.

    Returns:
        bool: True if n is a Fibonacci number, else False.
    """
    a = 5 * n ** 2 + 4
    b = 5 * n ** 2 - 4
    return int(math.isqrt(a))**2 == a or int(math.isqrt(b))**2 == b



def collatz_sequence(n: int) -> list[int]:
    """
    Generates the Collatz sequence for a given number.

    Parameters:
        n (int): Starting number.

    Returns:
        list[int]: The Collatz sequence ending with 1.
    """
    ans = []
    while n != 1:
        ans.append(n)
        n = n // 2 if n % 2 == 0 else 3 * n + 1
    return ans + [1]


def collatz_length(n: int) -> int:
    """
    Finds the length of the Collatz sequence.

    Parameters:
        n (int): Starting number.

    Returns:
        int: Number of terms in the Collatz sequence.
    """
    count = 0
    while n != 1:
        count += 1
        n = n // 2 if n % 2 == 0 else 3 * n + 1
    return count + 1



def triangular(n: int) -> int:
    """
    Calculates the nth triangular number.

    Parameters:
        n (int): Index of the triangular number (0-indexed).

    Returns:
        int: The nth triangular number.
    """
    return n * (n + 1) // 2


def is_triangular(n: int) -> bool:
    """
    Checks if a number is triangular.

    Parameters:
        n (int): Number to check.

    Returns:
        bool: True if n is triangular, else False.
    """
    val = int(math.sqrt(2 * n))
    return val * (val + 1) // 2 == n


def pentagonal(n: int) -> int:
    """
    Calculates the nth pentagonal number.

    Parameters:
        n (int): Index of the pentagonal number (0-indexed).

    Returns:
        int: The nth pentagonal number.
    """
    return n * (3 * n - 1) // 2


def is_pentagonal(n: int) -> bool:
    """
    Checks if a number is pentagonal.

    Parameters:
        n (int): Number to check.

    Returns:
        bool: True if n is pentagonal, else False.
    """
    discriminant = 1 + 24 * n
    sqrt_disc = math.isqrt(discriminant)
    if sqrt_disc * sqrt_disc != discriminant:
        return False
    x = (1 + sqrt_disc) / 6
    return x.is_integer() and x > 0


def hexagonal(n: int) -> int:
    """
    Calculates the nth hexagonal number.

    Parameters:
        n (int): Index of the hexagonal number (0-indexed).

    Returns:
        int: The nth hexagonal number.
    """
    return n * (2 * n - 1)


def is_hexagonal(n: int) -> bool:
    """
    Checks if a number is hexagonal.

    Parameters:
        n (int): Number to check.

    Returns:
        bool: True if n is hexagonal, else False.
    """
    val = 8 * n + 1
    x = (1 + math.isqrt(val)) / 4
    return x.is_integer()



def arithmetic_sequence(start: int, diff: int, n: int) -> list[int]:
    """
    Generates an arithmetic sequence.

    Parameters:
        start (int): First term.
        diff (int): Common difference.
        n (int): Number of terms.

    Returns:
        list[int]: Arithmetic sequence of length n.
    """
    return [start + i * diff for i in range(n)]


def geometric_sequence(start: int, ratio: int, n: int) -> list[int]:
    """
    Generates a geometric sequence.

    Parameters:
        start (int): First term.
        ratio (int): Common ratio.
        n (int): Number of terms.

    Returns:
        list[int]: Geometric sequence of length n.
    """
    return [start * ratio**i for i in range(n)]


def nth_arithmetic(start: int, diff: int, n: int) -> int:
    """
    Returns the nth term of an arithmetic sequence.

    Parameters:
        start (int): First term.
        diff (int): Common difference.
        n (int): Index of term (0-indexed).

    Returns:
        int: nth term.
    """
    return start + diff * n


def nth_geometric(start: int, ratio: int, n: int) -> int:
    """
    Returns the nth term of a geometric sequence.

    Parameters:
        start (int): First term.
        ratio (int): Common ratio.
        n (int): Index of term (0-indexed).

    Returns:
        int: nth term.
    """
    return start * ratio**n

def factorial_sequence(n: int) -> list[int]:
    """
    Generates the factorial sequence up to n!.

    Parameters:
        n (int): Highest factorial to calculate.

    Returns:
        list[int]: List of factorials from 0! to n!.
    """
    return [math.factorial(i) for i in range(n + 1)]


def double_factorial(n: int) -> int:
    """
    Computes the double factorial n!! = n*(n-2)*(n-4)... until 1 or 2.

    Parameters:
        n (int): Number to compute double factorial.

    Returns:
        int: Double factorial of n.
    """
    if n <= 0:
        return 1
    result = 1
    while n > 1:
        result *= n
        n -= 2
    return result


def superfactorial(n: int) -> int:
    """
    Computes the superfactorial: 1! * 2! * ... * n!

    Parameters:
        n (int): Highest factorial to include.

    Returns:
        int: Superfactorial of n.
    """
    result = 1
    for i in range(1, n + 1):
        result *= math.factorial(i)
    return result


def hyperfactorial(n: int) -> int:
    """
    Computes the hyperfactorial: 1^1 * 2^2 * ... * n^n

    Parameters:
        n (int): Highest number to include.

    Returns:
        int: Hyperfactorial of n.
    """
    result = 1
    for i in range(1, n + 1):
        result *= i**i
    return result
