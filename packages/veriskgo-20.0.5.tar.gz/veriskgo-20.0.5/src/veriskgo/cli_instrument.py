# veriskgo/cli_instrument.py

import os
import ast
import astor

INSTRUMENT_IMPORT = "from veriskgo.trace_manager import track_function"


class Instrumentor(ast.NodeTransformer):
    def __init__(self, skip_private=True, exclude=None):
        self.skip_private = skip_private
        self.exclude = exclude or []

    def visit_FunctionDef(self, node):
        """Add @track_function() to eligible function defs."""

        # Skip excluded function names
        if node.name in self.exclude:
            return node

        # Skip private if configured
        if self.skip_private and node.name.startswith("_"):
            return node

        # Check if already decorated
        already = any(
            isinstance(dec, ast.Call) and getattr(dec.func, "id", "") == "track_function"
            or (isinstance(dec, ast.Name) and dec.id == "track_function")
            for dec in node.decorator_list
        )

        if not already:
            decorator = ast.Call(
                func=ast.Name(id="track_function", ctx=ast.Load()),
                args=[],
                keywords=[]
            )
            node.decorator_list.insert(0, decorator)

        return node


def ensure_import_exists(code: str) -> str:
    """Insert track_function import at the top if missing."""
    if INSTRUMENT_IMPORT in code:
        return code

    lines = code.split("\n")
    insert_pos = 0

    # place import after any shebang or encoding lines
    while insert_pos < len(lines) and (
        lines[insert_pos].startswith("#!") or
        "coding" in lines[insert_pos]
    ):
        insert_pos += 1

    # Insert import line
    lines.insert(insert_pos, INSTRUMENT_IMPORT)
    return "\n".join(lines)


def instrument_file(path: str, skip_private=True, exclude=None, dry_run=False):
    with open(path, "r", encoding="utf-8") as f:
        original = f.read()

    try:
        tree = ast.parse(original)
    except SyntaxError:
        print(f"❌ Skipping {path} (syntax error)")
        return

    transformer = Instrumentor(skip_private=skip_private, exclude=exclude)
    modified_tree = transformer.visit(tree)
    ast.fix_missing_locations(modified_tree)

    modified_code = astor.to_source(modified_tree)
    modified_code = ensure_import_exists(modified_code)

    if modified_code == original:
        print(f"✓ {path} (no changes)")
        return

    if dry_run:
        print(f"DRY RUN → Would modify: {path}")
        return

    with open(path, "w", encoding="utf-8") as f:
        f.write(modified_code)

    print(f"✔ Instrumented: {path}")


def instrument_project(root=".", skip_private=True, exclude=None, dry_run=False):
    """Walk project and instrument all .py files except .venv, site-packages, etc."""

    exclude = exclude or []

    for base, dirs, files in os.walk(root):
        # Skip unwanted dirs
        dirs[:] = [
            d for d in dirs
            if d not in (".venv", "venv", "__pycache__", "site-packages")
        ]

        for file in files:
            if file.endswith(".py"):
                path = os.path.join(base, file)
                instrument_file(
                    path,
                    skip_private=skip_private,
                    exclude=exclude,
                    dry_run=dry_run,
                )
