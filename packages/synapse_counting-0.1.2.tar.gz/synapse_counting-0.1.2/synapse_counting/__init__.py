import os
os.environ["MPLCONFIGDIR"] = "/tmp/matplotlib"