### A custom python package used in the synapse-counting pipeline

All custom functions inside this package are wrapper functions based on scikitimage functions,
but tailored towards a custom implementation of counting synapses.