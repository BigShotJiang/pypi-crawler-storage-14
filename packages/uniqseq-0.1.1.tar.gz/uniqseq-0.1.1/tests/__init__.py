"""Tests for uniqseq."""
