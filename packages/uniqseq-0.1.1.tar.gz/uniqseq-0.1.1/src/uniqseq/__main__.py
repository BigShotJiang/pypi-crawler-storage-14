"""Entry point for running uniqseq as a module."""

from .cli import app

if __name__ == "__main__":
    app()
