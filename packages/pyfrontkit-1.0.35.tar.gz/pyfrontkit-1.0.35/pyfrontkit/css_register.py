# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# pyfrontkit/css_register.py 

from pathlib import Path
from typing import Any # Nueva importación para tipado más claro

class CSSRegistry:
    """
    Simplified CSS selector registry for PyFrontKit.
    Manages unique registration of tags, IDs, classes, and parent > child cascade selectors.
    The registration occurs **only in memory** for efficiency (Memoria Pura).
    """

    _tags = set()
    _ids = set()
    _classes = set()
    _cascades = set() 

    @classmethod
    def _get_child_tag(cls, child: Any) -> str | None:
        """Helper to get the tag, whether it's a Block or a ContentItem."""
        # Si es un Block o un ContentItem
        if hasattr(child, "tag"):
            return getattr(child, "tag")
        # Si es un simple string o int (texto plano), se ignora aquí.
        return None

    @classmethod
    def _register_cascades_by_tag(cls, block):
        """
        Genera y registra las cascadas basadas en tags de 1 y 2 niveles.
        - tag > tag/content_tag (1er nivel)
        - tag > tag > tag/content_tag (2do nivel)
        """
        parent_tag = block.tag
        
        # ---------------------------------------------
        # 1. Analizar Hijos (1er Nivel)
        # ---------------------------------------------
        
        # Hijos de tipo Block
        for child in block.children:
            child_tag = cls._get_child_tag(child)
            if not child_tag:
                continue
            
            # 1.1 Cascada de 1 Nivel: tag > tag
            selector_1 = f"{parent_tag} > {child_tag}"
            cls._cascades.add(selector_1)
            
            # ---------------------------------------------
            # 2. Analizar Nietos (2do Nivel)
            # ---------------------------------------------
            # La clase Block debe estar disponible. Se asume que el hijo es una instancia de la misma clase Block.
            # Alternativamente, podría ser: if isinstance(child, __import__('block').Block):
            if hasattr(child, "tag") and hasattr(child, "children"): 
                # Nietos de tipo Block
                for grandchild in child.children:
                    grandchild_tag = cls._get_child_tag(grandchild)
                    if grandchild_tag:
                        # Cascada de 2 Niveles: tag > tag > tag (Bloque > Bloque > Bloque)
                        selector_2 = f"{parent_tag} > {child_tag} > {grandchild_tag}"
                        cls._cascades.add(selector_2)
                
                # Nietos de tipo ContentItem (texto/imagen en el bloque hijo)
                for ctn_item in getattr(child, "content_items", []):
                    grandchild_tag = cls._get_child_tag(ctn_item)
                    if grandchild_tag:
                        # Cascada de 2 Niveles: tag > tag > content_tag (Bloque > Bloque > Contenido)
                        selector_2 = f"{parent_tag} > {child_tag} > {grandchild_tag}"
                        cls._cascades.add(selector_2)


        # ---------------------------------------------
        # 3. Analizar Contenido del Bloque (1er Nivel)
        # ---------------------------------------------
        # Hijos de tipo ContentItem (Texto/Imagen)
        for ctn_item in getattr(block, "content_items", []):
            ctn_tag = cls._get_child_tag(ctn_item)
            if ctn_tag:
                # 3.1 Cascada de 1 Nivel: tag > content_tag
                selector_1 = f"{parent_tag} > {ctn_tag}"
                cls._cascades.add(selector_1)


    @classmethod
    def register_block(cls, block):
        """
        Registra selectores del bloque y sus hijos SOLAMENTE EN MEMORIA.
        Lee la estructura de Block y llena los sets.
        """
        
        block_id = getattr(block, "attrs", {}).get("id")
        children = list(getattr(block, "children", []))

        # --- LÍNEA DE DEPURACIÓN AÑADIDA ---
        print(f"\n--- DEBUG: Registering block <{block.tag}> (ID: {block_id}) ---") 
        # -----------------------------------
        
        # --- TAG REGISTRATION
        if block.tag and block.tag not in cls._tags:
            cls._tags.add(block.tag)

        # --- ID REGISTRATION
        if block_id and block_id not in cls._ids:
            cls._ids.add(block_id)
        
        # --- CLASS REGISTRATION
        classes = block.attrs.get("class")
        if classes:
            for cls_name in str(classes).split():
                if cls_name not in cls._classes:
                    cls._classes.add(cls_name)

        # ----------------------------------------------------
        # --- CASCADA EXISTENTE: ID > TAG (Hijo Directo)
        # ----------------------------------------------------
        if block_id:
            for child in children:
                child_tag = getattr(child, "tag", None)
                if child_tag:
                    selector = f"#{block_id} > {child_tag}"

                    if selector not in cls._cascades:
                        cls._cascades.add(selector)
                        
        # ----------------------------------------------------
        # --- NUEVAS CASCADAS: TAG > TAG Y TAG > TAG > TAG
        # ----------------------------------------------------
        cls._register_cascades_by_tag(block)


        # --- RECURSION THROUGH CHILD BLOCKS
        for child in children:
            if hasattr(child, "tag") and getattr(child, "tag"):
                cls.register_block(child)

        # --- CONTENT-ITEM TAG REGISTRATION (Se mantiene para registrar el TAG simple)
        for ctn_item in getattr(block, "content_items", []):
            content_tag = cls._get_child_tag(ctn_item)
            if content_tag and content_tag not in cls._tags:
                cls._tags.add(content_tag)

        # --- LÍNEA DE DEPURACIÓN AÑADIDA ---
        print(f"DEBUG: Total Cascades after <{block.tag}>: {len(cls._cascades)}")
        # -----------------------------------


    @classmethod
    def generate_css(cls):
        """
        Devuelve todos los selectores generados en memoria como una cadena de texto CSS.
        """
        lines = ["/* Selectors generated by PyFrontKit */\n"]

        # TAGS
        for tag in sorted(cls._tags):
            lines.append(f"{tag} {{\n \t/* styles here */\n}}\n")

        # IDS
        for id_name in sorted(cls._ids):
            lines.append(f"#{id_name} {{\n \t/* styles here */\n}}\n")

        # CLASSES
        for cls_name in sorted(cls._classes):
            lines.append(f".{cls_name} {{\n \t/* styles here */\n}}\n")

        # CASCADAS padre > hijo y abuelo > padre > hijo
        for selector in sorted(cls._cascades):
            lines.append(f"{selector} {{\n \t/* styles here */\n}}\n")

        return "\n".join(lines)