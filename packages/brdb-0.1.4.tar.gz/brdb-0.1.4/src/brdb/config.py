config = {"setting1": True, 
          "setting2": "value2"}