# OpenStack Information Dump 

## Set up

Create virtual environment 

```
python3 -m venv venv 
```

Install packages

```
pip install . 
```

## Execute 

```
Usage: osi-dump [OPTIONS] FILE_PATH [OUTPUT_PATH]
```

