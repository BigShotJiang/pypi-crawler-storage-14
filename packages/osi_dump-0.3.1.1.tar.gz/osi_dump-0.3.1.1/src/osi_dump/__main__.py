if __name__ == "__main__":
    from osi_dump.cli import app

    app()
