from pydantic import BaseModel
from ..core import LLMProvider
from ..cache import CacheManager, CacheConfig, CacheKey


class CachedLLMProvider(LLMProvider):
    """
    Wrapper for LLMProvider that adds caching functionality.
    """

    def __init__(self, provider: LLMProvider, cache_config: CacheConfig, model_id: str):
        self.provider = provider
        self.model_id = model_id
        self.cache_manager = CacheManager(cache_config)

    async def generate(self, prompt: str, **kwargs) -> str:
        # Create cache key
        cache_key = CacheKey(
            model_id=self.model_id,
            prompt=prompt,
            temperature=kwargs.get("temperature", 0.0),
            max_tokens=kwargs.get("max_tokens", 1000),
            seed=kwargs.get("seed", 42),
        )

        # Try to get from cache
        cached_response = await self.cache_manager.get(cache_key)
        if cached_response is not None:
            return cached_response

        # Cache miss - call provider
        response = await self.provider.generate(prompt, **kwargs)

        # Store in cache
        await self.cache_manager.set(cache_key, response)

        return response

    async def generate_structured(
        self, prompt: str, response_model: type[BaseModel], **kwargs
    ) -> BaseModel:
        # Currently not caching structured outputs to align with legacy behavior
        # which only cached the main model response (string).
        return await self.provider.generate_structured(prompt, response_model, **kwargs)

    async def shutdown(self) -> None:
        await self.cache_manager.shutdown()
