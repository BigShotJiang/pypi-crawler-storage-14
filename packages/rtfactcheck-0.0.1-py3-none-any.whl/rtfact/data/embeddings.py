"""
Embedding infrastructure for the rtfact SDK.

This module provides a small, library-friendly abstraction for computing
embeddings. It is intentionally lightweight and does not depend on LlamaIndex.

Typical usage:

    from rtfact.data.embeddings import OpenAIEmbeddingProvider
    from rtfact.data import PgVectorRetriever

    embedder = OpenAIEmbeddingProvider(...)
    retriever = PgVectorRetriever(db_url=..., seed=42, embedder=embedder)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional, Sequence

import openai


class EmbeddingProvider(ABC):
    """
    Abstract interface for an embedding backend.

    Implementations must expose a fixed output dimension `dim` and support
    asynchronous batch embedding.
    """

    dim: int

    @abstractmethod
    async def embed_batch(self, texts: Sequence[str]) -> List[List[float]]:
        """Compute embeddings for a batch of input texts."""
        raise NotImplementedError


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """
    OpenAI-based implementation of EmbeddingProvider.

    This uses the `embeddings.create` endpoint of the OpenAI-compatible API.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: Optional[str] = None,
        model: str = "text-embedding-3-small",
        dim: Optional[int] = None,
    ) -> None:
        self.client = openai.AsyncOpenAI(api_key=api_key, base_url=base_url)
        self.model = model
        # Caller can override when using custom embedding dimensions.
        self.dim = dim if dim is not None else 1536

    async def embed_batch(self, texts: Sequence[str]) -> List[List[float]]:
        if not texts:
            return []
        resp = await self.client.embeddings.create(
            model=self.model,
            input=list(texts),
        )
        return [item.embedding for item in resp.data]  # type: ignore[return-value]


__all__ = [
    "EmbeddingProvider",
    "OpenAIEmbeddingProvider",
]
