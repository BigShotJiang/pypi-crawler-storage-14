"""
Core data abstractions shared across ingestion and retrieval backends.

This module defines:

- ``QAPair``: canonical QA schema used throughout the SDK;
- ``BaseRetriever``: abstract interface for context-building backends;
- ``BaseIngester``: abstract interface for persisting documents and QA pairs,
  plus backend-agnostic helpers for common ingestion flows.

Backend-specific implementations (e.g. PgVector) live under
``rtfact.data.ingesters`` and implement these base interfaces.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterable, List, Optional, TYPE_CHECKING

from pydantic import BaseModel

if TYPE_CHECKING:
    from .unstructured import RawDocument


class QAPair(BaseModel):
    """
    Canonical QA schema used by the SCID-F pipeline.

    This is intentionally backend-agnostic so it can be reused across different
    ingestion / retrieval implementations.
    """

    id: int
    question: str
    ground_truth_answer: str
    source_document_id: Optional[str] = None


class BaseRetriever(ABC):
    """
    Abstract base class for retrieval backends used by context providers.

    Implementations take a query and a set of SCID-F parameters (k, qa_id,
    rho, answer, etc.) and return a fully formatted context string that will
    be passed directly to the LLM.
    """

    @abstractmethod
    async def get_context(self, query: str, k: int, **kwargs) -> str:
        """
        Build a context string for a given query and SCID-F configuration.
        """
        raise NotImplementedError


def _chunk_text(text: str, max_chars: int) -> List[str]:
    """
    Simple character-based chunker for long documents.

    This is intentionally lightweight and only used for noise corpus ingestion,
    where exact sentence boundaries are less critical.
    """
    if len(text) <= max_chars:
        return [text]
    chunks: List[str] = []
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        chunks.append(text[start:end])
        start = end
    return chunks


class BaseIngester(ABC):
    """
    Abstract base class for ingestion backends.

    Concrete implementations are responsible for persisting raw documents and
    QA pairs into some storage (SQL, vector DB, filesystem, etc.) and
    aligning QA identifiers so that ContextProvider implementations can
    later fetch the correct "golden" context for a given ``qa_id``.
    """

    def __init__(self, *, db_url: Optional[str] = None) -> None:
        self.db_url = db_url

    @abstractmethod
    async def ingest_raw_documents(
        self,
        documents: Iterable["RawDocument"],
        *,
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
    ) -> int:
        """Persist a batch of RawDocument objects and return the count."""
        raise NotImplementedError

    @abstractmethod
    async def persist_documents_and_qa(
        self,
        documents: Iterable["RawDocument"],
        qa_pairs: Iterable[QAPair],
        *,
        document_source: str = "documents",
    ) -> List[QAPair]:
        """
        Persist documents and QA pairs, returning QA pairs whose ``id`` and
        ``source_document_id`` fields are aligned with the backing store.
        """
        raise NotImplementedError

    async def ingest_noise_from_directory(
        self,
        directory: str | Path,
        *,
        pattern: str = "*.txt",
        encoding: str = "utf-8",
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
    ) -> int:
        """
        Load text files from a directory and ingest them as noise documents.

        This default implementation is backend-agnostic: it converts files
        into RawDocument objects and delegates to ``ingest_raw_documents``.
        """
        from .unstructured import DocumentLoader  # local import to avoid cycles

        loader = DocumentLoader(pattern=pattern, encoding=encoding)
        docs = loader.load(directory)
        return await self.ingest_raw_documents(
            docs,
            source=source,
            batch_size=batch_size,
            embed=embed,
        )

    async def ingest_noise_from_hf_dataset(
        self,
        dataset_name: str = "wikimedia/wikipedia",
        *,
        dataset_config: Optional[str] = "20231101.en",
        split: str = "train",
        text_field: str = "text",
        limit: Optional[int] = None,
        max_chars: int = 2000,
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
        streaming: bool = False,
    ) -> int:
        """
        Load documents from a Hugging Face datasets corpus (e.g. Wikipedia)
        and ingest them as noise documents.

        By default this uses the Arrow-based ``\"wikimedia/wikipedia\"`` dataset
        with a concrete snapshot config (e.g. ``\"20231101.en\"``), which is
        compatible with recent ``datasets`` versions that no longer support
        script-based datasets like the legacy ``\"wikipedia\"`` builder.

        This default implementation is backend-agnostic and delegates the
        final persistence step to ``ingest_raw_documents``.
        """
        try:
            from datasets import load_dataset
        except Exception as exc:  # pragma: no cover - import-time failure path
            raise RuntimeError(
                "The 'datasets' library is required for ingest_noise_from_hf_dataset."
            ) from exc

        if dataset_config:
            ds = load_dataset(
                dataset_name,
                dataset_config,
                split=split,
                streaming=streaming,
            )
        else:
            ds = load_dataset(
                dataset_name,
                split=split,
                streaming=streaming,
            )
        from .unstructured import RawDocument  # local import to avoid cycles
        docs: List[RawDocument] = []

        for idx, row in enumerate(ds):
            if limit is not None and idx >= limit:
                break
            text = None
            if isinstance(row, dict):
                text = row.get(text_field)
            else:
                try:
                    text = row[text_field]  # e.g. IterableDataset LazyRow
                except Exception:
                    text = None
            if not text:
                continue

            for chunk in _chunk_text(str(text), max_chars=max_chars):
                docs.append(
                    RawDocument(
                        id=None,
                        text=chunk,
                        metadata={
                            "dataset": dataset_name,
                            "split": split,
                        },
                    )
                )

        return await self.ingest_raw_documents(
            docs,
            source=source,
            batch_size=batch_size,
            embed=embed,
        )


__all__ = [
    "QAPair",
    "BaseRetriever",
    "BaseIngester",
]
