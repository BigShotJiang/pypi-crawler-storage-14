"""
Utilities for turning unstructured text (e.g., contracts, legal
policies, regulations) into QA pairs using an LLM.

This module is meant as the SDK entrypoint for users who have raw
text data rather than pre-defined QA pairs. It mirrors the pipeline
used in the paper:

    raw document text  →  chunking  →  LLM-based QA extraction
                       →  QAPair list  →  SCID-F / RT4Hallucination

Typical usage:

    from rtfact.llm import OpenAIProvider
    from rtfact.data import (
        RawDocument,
        generate_qa_for_documents,
    )

    llm = OpenAIProvider(api_key=..., model="gpt-4o")
    docs = [RawDocument(id="contract_1", text=contract_text)]
    qa_pairs = await generate_qa_for_documents(docs, llm=llm)
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from pydantic import BaseModel, Field
from tqdm import tqdm

from ..core import LLMProvider
from .base import QAPair

_logger = logging.getLogger(__name__)

SYS_INSTRUCTION = (
    "You extract question-answer pairs from a given text chunk.\n"
    "Strictly follow rules:\n"
    "- Only use information present in the chunk.\n"
    "- Prefer short, factual answers (names, dates, numbers, short spans).\n"
    "- Avoid multi-sentence or speculative answers.\n"
    '- Output ONLY a JSON array of objects: '
    '[{\"question\": str, \"answer\": str}, ...].\n'
)


class RawDocument(BaseModel):
    """
    Canonical representation of an unstructured input document.

    Users can construct this from any source (contracts, regulations,
    policy manuals, etc.) as long as they provide plain text.
    """

    id: Optional[str] = Field(
        default=None,
        description="Optional document identifier (e.g., filename or UUID).",
    )
    text: str = Field(..., description="Full raw text of the document.")
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Optional metadata (e.g., type, jurisdiction, version).",
    )


def _chunk_text(text: str, max_chars: int) -> List[str]:
    """
    Split a long document into smaller chunks for QA generation.

    The chunking is heuristic: it tries not to break inside the last word
    of a chunk by backing up to the last whitespace boundary.
    """
    if len(text) <= max_chars:
        cleaned = text.strip()
        return [cleaned] if cleaned else []

    blocks: List[str] = []
    start = 0
    length = len(text)

    while start < length:
        end = min(start + max_chars, length)
        if end < length:
            match = re.search(r"\s\S*$", text[start:end])
            if match:
                end = start + match.start()
        block = text[start:end].strip()
        if block:
            blocks.append(block)
        start = end

    # deduplicate trivial duplicates
    seen: set[str] = set()
    result: List[str] = []
    for block in blocks:
        key = block.strip()
        if key not in seen:
            seen.add(key)
            result.append(block)
    return result


def _safe_json_parse(text: str) -> Optional[List[Dict[str, str]]]:
    """
    Robust JSON array parser for LLM outputs.

    The LLM is instructed to return a JSON array of objects with
    'question' and 'answer' fields, but this helper is defensive
    against minor formatting errors.
    """
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            cleaned: List[Dict[str, str]] = []
            for item in obj:
                if (
                    isinstance(item, dict)
                    and "question" in item
                    and "answer" in item
                ):
                    question = str(item["question"]).strip()
                    answer = str(item["answer"]).strip()
                    if question and answer:
                        cleaned.append({"question": question, "answer": answer})
            return cleaned
    except Exception:
        pass

    # heuristic: try to locate first '[' and last ']' and parse that slice
    try:
        left = text.find("[")
        right = text.rfind("]")
        if left != -1 and right != -1 and right > left:
            obj = json.loads(text[left : right + 1])
            if isinstance(obj, list):
                cleaned = []
                for item in obj:
                    if (
                        isinstance(item, dict)
                        and "question" in item
                        and "answer" in item
                    ):
                        question = str(item["question"]).strip()
                        answer = str(item["answer"]).strip()
                        if question and answer:
                            cleaned.append({"question": question, "answer": answer})
                return cleaned
    except Exception:
        return None

    return None


async def generate_qa_for_chunk(
    text: str,
    *,
    llm: LLMProvider,
    max_items: int = 3,
    temperature: float = 0.0,
) -> List[Dict[str, str]]:
    """
    Generate QA pairs from a single text chunk using an LLMProvider.

    Returns at most `max_items` items, each with keys: question, answer.
    """
    if not text or not text.strip():
        return []

    user_prompt = (
        "Extract concise QA pairs from the following text chunk.\n"
        f"Return at most {max_items} items.\n\n"
        f"TEXT:\n{text}"
    )
    prompt = f"{SYS_INSTRUCTION}\n\n{user_prompt}"

    try:
        content = await llm.generate(
            prompt,
            temperature=temperature,
            max_tokens=300,
        )
    except Exception as e:
        _logger.warning(f"Error generating QA pairs for chunk: {str(e)}")
        return []

    if not content:
        _logger.warning("No content generated for chunk")
        return []

    parsed = _safe_json_parse(content)
    return parsed or []


async def generate_qa_for_documents(
    documents: Iterable[RawDocument],
    *,
    llm: LLMProvider,
    chunk_size: int = 1200,
    qa_per_chunk: int = 3,
    temperature: float = 0.0,
    concurrency: int = 8,
) -> List[QAPair]:
    """
    End-to-end pipeline: RawDocument list → QAPair list via LLM.

    For each document:
      1) Split into chunks of up to `chunk_size` characters.
      2) For each chunk, call the LLM to generate up to `qa_per_chunk` QA pairs.
      3) Convert each generated item into a QAPair, assigning a sequential id.

    The returned QAPair list can be fed directly into ScidfOrchestrator.run_experiment.
    """
    semaphore = asyncio.Semaphore(concurrency)
    qa_pairs: List[QAPair] = []
    next_id = 1

    async def _process_chunk(
        document: RawDocument,
        chunk_text: str,
    ) -> None:
        nonlocal next_id
        async with semaphore:
            items = await generate_qa_for_chunk(
                chunk_text,
                llm=llm,
                max_items=qa_per_chunk,
                temperature=temperature,
            )
        for item in items:
            qa_pairs.append(
                QAPair(
                    id=next_id,
                    question=item["question"],
                    ground_truth_answer=item["answer"],
                    source_document_id=document.id,
                )
            )
            next_id += 1

    if not documents:
        _logger.warning("No documents to process")
        return qa_pairs

    tasks: List[asyncio.Task[None]] = []
    total_chunks = 0

    for document in documents:
        for chunk in _chunk_text(document.text, chunk_size):
            total_chunks += 1
            tasks.append(asyncio.create_task(_process_chunk(document, chunk)))

    if not tasks or total_chunks == 0:
        _logger.warning("No tasks to process")
        return qa_pairs

    async def _run_with_progress(task: asyncio.Task[None], bar: tqdm) -> None:
        try:
            await task
        finally:
            bar.update(1)

    with tqdm(total=total_chunks, desc="Generating QA from chunks") as bar:
        await asyncio.gather(*[_run_with_progress(t, bar) for t in tasks])

    return qa_pairs


class DocumentLoader:
    """
    Simple loader for turning on-disk text files into RawDocument objects.

    Typical usage:
        loader = DocumentLoader(pattern=\"*.txt\", encoding=\"utf-8\")
        docs = loader.load(\"data/documents\")
    """

    def __init__(self, pattern: str = "*.txt", encoding: str = "utf-8") -> None:
        self.pattern = pattern
        self.encoding = encoding

    def load(self, directory: str | Path) -> List[RawDocument]:
        """
        Load plain-text files from a directory into RawDocument objects.

        Args:
            directory: Root directory to scan.
        """
        base = Path(directory)
        documents: List[RawDocument] = []

        if not base.exists():
            return documents

        valid = 0

        for file_path in sorted(base.rglob(self.pattern)):
            try:
                text = file_path.read_text(
                    encoding=self.encoding,
                    errors="ignore",
                )
            except Exception as e:
                _logger.warning(f"Error loading file {file_path}: {str(e)}")
                continue
            if not text:
                _logger.warning(f"File {file_path} is empty")
                continue
            valid += 1
            documents.append(
                RawDocument(
                    id=str(file_path),
                    text=text,
                    metadata={"path": str(file_path)},
                )
            )

        _logger.info(f"Loaded {valid} valid files from {directory}")
        return documents


def load_raw_documents_from_directory(
    directory: str | Path,
    *,
    pattern: str = "*.txt",
    encoding: str = "utf-8",
) -> List[RawDocument]:
    """
    Convenience helper: load plain-text files from a directory into RawDocument objects.

    This is suitable for typical usage where users place documents as `.txt` files
    in a folder. For more control, use DocumentLoader directly.
    """
    loader = DocumentLoader(pattern=pattern, encoding=encoding)
    return loader.load(directory)
