"""
Data input utilities for the rtfact SDK.

This module defines a canonical schema for user-provided QA data and helpers
to load / validate batches of questions from common file formats.

Typical usage:

    from rtfact.data import load_qa_pairs_from_csv

    qa_pairs = load_qa_pairs_from_csv("qa_dataset.csv")
    results = await orchestrator.run_experiment(qa_pairs)

By default we expect the following columns / keys per row:
    - id (int, optional)                 – Stable QA identifier
    - question (str, required)           – Question text
    - ground_truth_answer (str, required)– Reference answer text
    - source_document_id (str, optional) – ID of the underlying document

You can override column names via the loader parameters if needed.
"""

from __future__ import annotations

from dataclasses import dataclass
import csv
import json
from pathlib import Path
from typing import Iterable, Mapping, Any, List, Optional

from pydantic import BaseModel, Field, ValidationError

from .base import QAPair


class QAInputRow(BaseModel):
    """
    Canonical schema for a single user-provided QA record.

    This captures the minimal information needed by the SCID-F pipeline.
    """

    id: Optional[int] = Field(
        default=None,
        description="Optional stable identifier for the QA pair. "
        "If omitted, a sequential ID will be assigned when converting to QAPair.",
    )
    question: str = Field(..., description="Question text.")
    ground_truth_answer: str = Field(..., description="Reference answer text.")
    source_document_id: Optional[str] = Field(
        default=None,
        description="Optional ID of the underlying source document "
        "(e.g., UUID from a documents table).",
    )


@dataclass
class FieldMapping:
    """
    Mapping from canonical QAInputRow fields to keys/columns in the user data.

    This lets callers adapt existing datasets without renaming columns.
    """

    id: str = "id"
    question: str = "question"
    ground_truth_answer: str = "ground_truth_answer"
    source_document_id: str = "source_document_id"


def _normalize_row(
    raw: Mapping[str, Any],
    mapping: FieldMapping,
) -> QAInputRow:
    """Convert an arbitrary mapping into a validated QAInputRow."""
    data: dict[str, Any] = {}

    # id is optional
    if mapping.id in raw and raw[mapping.id] not in (None, ""):
        try:
            data["id"] = int(raw[mapping.id])
        except (TypeError, ValueError):
            raise ValueError(f"Invalid id value: {raw[mapping.id]!r}")

    # required fields
    try:
        data["question"] = raw[mapping.question]
    except KeyError as exc:
        raise KeyError(f"Missing required field '{mapping.question}'") from exc

    try:
        data["ground_truth_answer"] = raw[mapping.ground_truth_answer]
    except KeyError as exc:
        raise KeyError(
            f"Missing required field '{mapping.ground_truth_answer}'"
        ) from exc

    # optional source_document_id
    if mapping.source_document_id in raw and raw[mapping.source_document_id] not in (
        None,
        "",
    ):
        data["source_document_id"] = str(raw[mapping.source_document_id])

    try:
        return QAInputRow(**data)
    except ValidationError as exc:
        raise ValueError(f"Invalid QA row: {exc}") from exc


def _rows_to_qa_pairs(rows: Iterable[Mapping[str, Any]], mapping: FieldMapping) -> List[QAPair]:
    """
    Parse an iterable of raw mappings into a list of QAPair instances.

    If a row is missing an id, a monotonically increasing integer ID is assigned.
    """
    qa_pairs: List[QAPair] = []
    next_auto_id = 1

    for raw in rows:
        input_row = _normalize_row(raw, mapping)

        qa_id = input_row.id
        if qa_id is None:
            qa_id = next_auto_id
            next_auto_id += 1

        qa_pairs.append(
            QAPair(
                id=qa_id,
                question=input_row.question,
                ground_truth_answer=input_row.ground_truth_answer,
                source_document_id=input_row.source_document_id,
            )
        )

    return qa_pairs


def load_qa_pairs_from_csv(
    path: str | Path,
    *,
    field_mapping: FieldMapping | None = None,
    encoding: str = "utf-8",
    delimiter: str = ",",
) -> List[QAPair]:
    """
    Load QA pairs from a CSV file into a list of QAPair objects.

    Expected default columns:
        id, question, ground_truth_answer, source_document_id

    Args:
        path: Path to the CSV file.
        field_mapping: Optional FieldMapping to adapt custom column names.
        encoding: File encoding (default: utf-8).
        delimiter: CSV delimiter (default: ',').
    """
    mapping = field_mapping or FieldMapping()
    file_path = Path(path)

    with file_path.open("r", encoding=encoding, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        rows: List[Mapping[str, Any]] = list(reader)

    return _rows_to_qa_pairs(rows, mapping)


def load_qa_pairs_from_jsonl(
    path: str | Path,
    *,
    field_mapping: FieldMapping | None = None,
    encoding: str = "utf-8",
) -> List[QAPair]:
    """
    Load QA pairs from a JSONL (one JSON object per line) file.

    Each line must be a JSON object with at least:
        question, ground_truth_answer
    and optionally:
        id, source_document_id
    """
    mapping = field_mapping or FieldMapping()
    file_path = Path(path)

    rows: List[Mapping[str, Any]] = []
    with file_path.open("r", encoding=encoding) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if not isinstance(obj, Mapping):
                raise ValueError(f"Expected JSON object per line, got: {type(obj)}")
            rows.append(obj)

    return _rows_to_qa_pairs(rows, mapping)
