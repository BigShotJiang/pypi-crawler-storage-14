"""
Backend-specific ingestion / retrieval implementations.

Currently this package provides PgVector support via
``rtfact.data.ingesters.pgvector``. Additional backends (e.g. other SQL
databases or filesystem-based contexts) can be added alongside it by
implementing the abstractions in ``rtfact.data.base``.
"""

from .pgvector import PgVectorIngester, PgVectorRetriever, PgVectorContext

__all__ = [
    "PgVectorIngester",
    "PgVectorRetriever",
    "PgVectorContext",
]

