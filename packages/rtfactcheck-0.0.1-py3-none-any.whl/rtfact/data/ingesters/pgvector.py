"""
PgVector-backed ingestion and retrieval implementations.

This module provides:

- ``PgVectorIngester``: writes documents and QA pairs into PgVector;
- ``PgVectorRetriever``: builds SCID-F contexts (signal + noise / pure noise);
- ``PgVectorContext``: a facade that bundles ingestion and retrieval behind
  the ``ContextProvider`` interface.
"""

from __future__ import annotations

import hashlib
import math
import random
import re
import uuid
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

from sqlalchemy import create_engine, text, bindparam
from sqlalchemy.ext.asyncio import create_async_engine
from tqdm import tqdm

from ...core import ContextProvider
from ...utils import to_sync_db_url
from ..base import BaseIngester, BaseRetriever, QAPair
from ..embeddings import EmbeddingProvider
from ..unstructured import RawDocument


class PgVectorIngester(BaseIngester):
    """
    Helper for inserting documents into the shared PgVector store.

    Responsibilities:
      - Ensure the ``documents`` table and ``vector`` extension exist;
      - Insert ``RawDocument`` rows with a given ``source``;
      - Optionally compute embeddings and store them in a ``vector(dim)`` column.
    """

    def __init__(
        self,
        db_url: str,
        embedder: EmbeddingProvider,
    ) -> None:
        super().__init__(db_url=db_url)
        self.embedder = embedder
        self._engine = create_engine(to_sync_db_url(db_url))

    def _ensure_schema(self) -> None:
        """Ensure the core tables and optional embedding column exist."""
        with self._engine.begin() as conn:
            conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector;"))
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS documents (
                        id UUID PRIMARY KEY,
                        content TEXT NOT NULL,
                        source VARCHAR(50)
                    );
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS qa_pairs (
                        id SERIAL PRIMARY KEY,
                        question TEXT NOT NULL,
                        ground_truth_answer TEXT NOT NULL,
                        source_document_id UUID REFERENCES documents(id)
                    );
                    """
                )
            )
            conn.execute(
                text(
                    f"ALTER TABLE documents "
                    f"ADD COLUMN IF NOT EXISTS embedding vector({self.embedder.dim});"
                )
            )
            conn.execute(
                text(
                    """
                    ALTER TABLE documents
                    ADD COLUMN IF NOT EXISTS document_hash TEXT;
                    """
                )
            )
            conn.execute(
                text(
                    """
                    CREATE INDEX IF NOT EXISTS ix_documents_document_hash
                    ON documents(document_hash);
                    """
                )
            )

    async def ingest_raw_documents(
        self,
        documents: Iterable[RawDocument],
        *,
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
    ) -> int:
        """
        Insert ``RawDocument`` rows into the ``documents`` table.

        Args:
            documents: Iterable of RawDocument instances.
            source: Value to store in the ``source`` column (e.g. ``\"wikipedia_noise\"``).
            batch_size: Batch size for embedding computations.
            embed: Whether to compute and persist embeddings when an
                ``EmbeddingProvider`` is configured.
        Returns:
            Number of inserted documents.
        """
        docs_list = list(documents)
        if not docs_list:
            return 0

        self._ensure_schema()

        inserted_ids: List[uuid.UUID] = []
        inserted_texts: List[str] = []

        with self._engine.begin() as conn:
            for doc in docs_list:
                # Compute a stable hash for the document content to avoid
                # re‑ingesting identical rows.
                doc_hash = hashlib.sha256(doc.text.encode("utf-8")).hexdigest()

                existing = conn.execute(
                    text(
                        """
                        SELECT id, embedding
                        FROM documents
                        WHERE document_hash = :h
                        LIMIT 1
                        """
                    ),
                    {"h": doc_hash},
                ).fetchone()

                if existing is not None:
                    existing_id, existing_embedding = existing
                    # If an identical document already exists and already has
                    # an embedding, skip both insertion and re‑embedding.
                    if embed and existing_embedding is None:
                        inserted_ids.append(existing_id)
                        inserted_texts.append(doc.text)
                    continue

                doc_id = uuid.uuid4()
                conn.execute(
                    text(
                        """
                        INSERT INTO documents (id, content, source, document_hash)
                        VALUES (:id, :content, :source, :h)
                        """
                    ),
                    {
                        "id": doc_id,
                        "content": doc.text,
                        "source": source,
                        "h": doc_hash,
                    },
                )
                inserted_ids.append(doc_id)
                inserted_texts.append(doc.text)

        # Optionally compute embeddings for the inserted documents.
        if embed and inserted_ids:
            total = len(inserted_ids)
            with tqdm(
                total=total,
                desc="Embedding documents",
                unit="doc",
            ) as bar:
                idx = 0
                while idx < len(inserted_ids):
                    batch_ids = inserted_ids[idx : idx + batch_size]
                    batch_texts = inserted_texts[idx : idx + batch_size]
                    idx += batch_size

                    embeddings = await self.embedder.embed_batch(batch_texts)
                    if len(embeddings) != len(batch_ids):
                        raise RuntimeError(
                            "EmbeddingProvider returned a batch with mismatched length."
                        )

                    with self._engine.begin() as conn:
                        update_stmt = text(
                            "UPDATE documents "
                            "SET embedding = :embedding "
                            "WHERE id = :id"
                        )
                        for doc_id, emb in zip(batch_ids, embeddings):
                            conn.execute(
                                update_stmt,
                                {"id": doc_id, "embedding": emb},
                            )
                    bar.update(len(batch_ids))

        return len(inserted_ids)

    async def persist_documents_and_qa(
        self,
        documents: Iterable[RawDocument],
        qa_pairs: Iterable[QAPair],
        *,
        document_source: str = "documents",
    ) -> List[QAPair]:
        """
        Persist documents and QA pairs into Postgres, aligning QA ids.

        This mirrors the behavior previously implemented inside
        ``DocumentScidfExperiment``:

          - Insert each RawDocument into ``documents`` with a fresh UUID;
          - Insert each QAPair into ``qa_pairs``, setting ``source_document_id``
            to the corresponding document UUID (when available);
          - Update each QAPair's ``id`` to match the ``qa_pairs.id`` in the DB.
        """
        docs_list = list(documents)
        qa_list = list(qa_pairs)

        if not docs_list or not qa_list:
            return qa_list

        self._ensure_schema()
        doc_id_to_uuid: Dict[str, uuid.UUID] = {}
        updated_qa_pairs: List[QAPair] = []

        with self._engine.begin() as conn:
            # Insert documents once per RawDocument.id
            for document in docs_list:
                raw_id = str(getattr(document, "id", "") or "")
                if not raw_id or raw_id in doc_id_to_uuid:
                    continue

                document_uuid = uuid.uuid4()
                conn.execute(
                    text(
                        "INSERT INTO documents (id, content, source) "
                        "VALUES (:id, :content, :source)"
                    ),
                    {
                        "id": document_uuid,
                        "content": document.text,
                        "source": document_source,
                    },
                )
                doc_id_to_uuid[raw_id] = document_uuid

            # Insert QA pairs and capture their DB-assigned ids.
            for qa in qa_list:
                raw_source_id = getattr(qa, "source_document_id", None)
                document_uuid = None
                if raw_source_id is not None:
                    document_uuid = doc_id_to_uuid.get(str(raw_source_id))

                result = conn.execute(
                    text(
                        "INSERT INTO qa_pairs "
                        "(question, ground_truth_answer, source_document_id) "
                        "VALUES (:q, :a, :sid) "
                        "RETURNING id"
                    ),
                    {
                        "q": qa.question,
                        "a": qa.ground_truth_answer,
                        "sid": document_uuid,
                    },
                )
                db_id = result.scalar_one()

                qa.id = db_id
                if document_uuid is not None:
                    qa.source_document_id = str(document_uuid)

                updated_qa_pairs.append(qa)

        return updated_qa_pairs


class PgVectorRetriever(BaseRetriever):
    """PostgreSQL/pgvector implementation of BaseRetriever."""

    def __init__(
        self,
        db_url: str,
        embedder: EmbeddingProvider,
        seed: int = 42,
        max_noise_similarity: float = 0.3,
    ):
        """
        Args:
            db_url: Async SQLAlchemy URL for Postgres.
            seed: Global seed used to derive deterministic per-QA noise order.
            embedder: Embedding backend used to approximate the
                "topical unrelatedness" constraint by
                filtering out noise passages that are too similar to the
                question in embedding space.
            max_noise_similarity: Maximum allowed cosine similarity between
                a question and a noise document. Noise passages with higher
                similarity are skipped.
        """
        self.db_url = db_url
        self.engine = create_async_engine(db_url)
        self.seed = seed
        self.embedder = embedder
        self.max_noise_similarity = max_noise_similarity

        self._noise_doc_ids: Optional[List[str]] = None
        self._qa_to_noise_order: Dict[int, List[str]] = {}
        self._noise_content_cache: Dict[str, str] = {}
        self._noise_embedding_cache: Dict[str, List[float]] = {}
        self._qa_embedding_cache: Dict[int, List[float]] = {}

    async def _ensure_noise_doc_ids(self) -> List[str]:
        if self._noise_doc_ids is not None:
            return self._noise_doc_ids
        query = text("SELECT id::text FROM documents WHERE source = 'wikipedia_noise'")
        async with self.engine.connect() as conn:
            result = await conn.execute(query)
            self._noise_doc_ids = [row[0] for row in result.fetchall()]
            return self._noise_doc_ids

    async def _get_documents_map_by_ids(self, ids: List[str]) -> Dict[str, str]:
        if not ids:
            return {}
        query = text(
            "SELECT id::text, content FROM documents WHERE id::text IN :ids"
        ).bindparams(bindparam("ids", expanding=True))
        async with self.engine.connect() as conn:
            result = await conn.execute(query, {"ids": ids})
            rows = result.fetchall()
            return {row[0]: row[1] for row in rows}

    async def _get_documents_by_ids(self, ids: List[str]) -> List[str]:
        id_to_content = await self._get_documents_map_by_ids(ids)
        return [id_to_content[i] for i in ids if i in id_to_content]

    @staticmethod
    def _canonicalize(text: str) -> str:
        """
        Lightweight normalization used for answer-string filtering.

        This is intentionally simple: lowercase, strip, collapse non-word
        characters to spaces. It does not aim to be locale-aware.
        """
        lowered = text.lower()
        cleaned = re.sub(r"[\W_]+", " ", lowered)
        return cleaned.strip()

    async def _get_query_embedding(
        self,
        qa_id: int,
        question: str,
    ) -> Optional[List[float]]:
        """
        Embed the question once per QA for semantic noise filtering.

        Returns None if the backend fails.
        """
        if qa_id in self._qa_embedding_cache:
            return self._qa_embedding_cache[qa_id]

        embeddings = await self.embedder.embed_batch([question])
        if not embeddings:
            return None
        vec = embeddings[0]
        self._qa_embedding_cache[qa_id] = vec
        return vec

    async def _get_noise_embedding(
        self,
        doc_id: str,
        content: str,
    ) -> Optional[List[float]]:
        """Embed a noise document once and cache the result."""
        if doc_id in self._noise_embedding_cache:
            return self._noise_embedding_cache[doc_id]

        embeddings = await self.embedder.embed_batch([content])
        if not embeddings:
            return None
        vec = embeddings[0]
        self._noise_embedding_cache[doc_id] = vec
        return vec

    @staticmethod
    def _cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
        """Compute cosine similarity between two vectors."""
        if not a or not b or len(a) != len(b):
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        if na == 0.0 or nb == 0.0:
            return 0.0
        return dot / (na * nb)

    async def _select_noise_documents(
        self,
        qa_id: int,
        k: int,
        *,
        answer: Optional[str] = None,
        golden_doc: Optional[str] = None,
    ) -> List[str]:
        """
        Select up to k noise documents for a given QA in a deterministic way.

        This preserves the prefix property: the first k documents for a given
        qa_id are always a prefix of the sequence used for larger k for the
        same qa_id, after applying the same filtering rules.

        The filtering approximates the paper's "no answer string" constraint
        by skipping noise passages that contain the canonicalized answer
        string. If golden_doc is provided, noise passages that are identical
        to the golden document under the same normalization are also skipped.
        """
        if k <= 0:
            return []

        noise_ids = await self._ensure_noise_doc_ids()
        if not noise_ids:
            return []

        if qa_id not in self._qa_to_noise_order:
            rnd = random.Random(f"{self.seed}-{qa_id}")
            indices = list(range(len(noise_ids)))
            rnd.shuffle(indices)
            self._qa_to_noise_order[qa_id] = [noise_ids[i] for i in indices]

        ordered_ids = self._qa_to_noise_order[qa_id]
        canonical_answer = self._canonicalize(answer) if answer else None
        canonical_golden = self._canonicalize(golden_doc) if golden_doc else None

        # Semantic filter using embeddings to approximate "topical unrelatedness".
        # If we do not have a cached question embedding, this will be a pure
        # deterministic shuffle.
        q_emb: Optional[List[float]] = self._qa_embedding_cache.get(qa_id)

        selected: List[str] = []
        # Walk over the deterministic id sequence and lazily fetch contents.
        for doc_id in ordered_ids:
            if len(selected) >= k:
                break

            if doc_id not in self._noise_content_cache:
                content_map = await self._get_documents_map_by_ids([doc_id])
                self._noise_content_cache[doc_id] = content_map.get(doc_id, "")

            content = self._noise_content_cache.get(doc_id, "")
            if not content:
                continue

            canonical_content = self._canonicalize(content)

            if canonical_golden and canonical_content == canonical_golden:
                continue

            if canonical_answer and canonical_answer in canonical_content:
                continue

            # If semantic filtering is enabled and available, skip noise
            # documents that are too similar to the question embedding.
            if q_emb is not None:
                doc_emb = await self._get_noise_embedding(doc_id, content)
                if doc_emb is not None:
                    sim = self._cosine_similarity(q_emb, doc_emb)
                    if sim >= self.max_noise_similarity:
                        continue

            selected.append(content)

        return selected

    async def get_context(
        self,
        query: str,
        k: int,
        *,
        qa_id: int,
        rho: float = 1.0,
        **kwargs,
    ) -> str:
        # Note: This implementation preserves the specific logic from context_sampler.py
        # regarding deterministic noise and golden document insertion.
        if k == 0:
            return ""

        documents: List[str] = []
        answer: Optional[str] = kwargs.get("answer")

        # Best-effort embedding of the question for semantic noise filtering.
        if qa_id not in self._qa_embedding_cache:
            await self._get_query_embedding(qa_id, query)

        if rho == 0:  # Pure noise
            documents = await self._select_noise_documents(
                qa_id=qa_id,
                k=k,
                answer=answer,
            )
        elif rho == 1:  # Signal + Noise
            # Fetch golden doc
            golden_query = text(
                "SELECT d.content FROM documents d JOIN qa_pairs q ON d.id = q.source_document_id WHERE q.id = :qa_id"
            )
            async with self.engine.connect() as conn:
                res = await conn.execute(golden_query, {"qa_id": qa_id})
                row = res.fetchone()
                golden_doc = row[0] if row else ""

            num_noise = k - 1 if golden_doc else k
            if num_noise > 0:
                noise_docs = await self._select_noise_documents(
                    qa_id=qa_id,
                    k=num_noise,
                    answer=answer,
                    golden_doc=golden_doc,
                )
                documents.extend(noise_docs)

            if golden_doc:
                documents.insert(len(documents) // 2, golden_doc)

        return "\n\n---\n\n".join(
            [f"Document {i + 1}:\n{doc}" for i, doc in enumerate(documents)]
        )


class PgVectorContext(ContextProvider):
    """
    Composite "context layer" that bundles ingestion and retrieval.

    - ``ingester``: manages writing documents (noise or user) into PgVector;
    - ``retriever``: implements the SCID-F ``ContextProvider`` interface, building
       contexts from signal + noise documents.

    This is a convenience wrapper; you can always use ``PgVectorIngester`` and
    ``PgVectorRetriever`` separately if preferred.
    """

    def __init__(
        self,
        db_url: str,
        embedder: EmbeddingProvider,
        *,
        seed: int = 42,
        max_noise_similarity: float = 0.3,
    ) -> None:
        self.db_url = db_url
        self.ingester: BaseIngester = PgVectorIngester(db_url=db_url, embedder=embedder)
        self.retriever = PgVectorRetriever(
            db_url=db_url,
            seed=seed,
            embedder=embedder,
            max_noise_similarity=max_noise_similarity,
        )

    async def get_context(self, query: str, k: int, **kwargs) -> str:
        """
        Delegate context construction to the underlying PgVectorRetriever.
        """
        return await self.retriever.get_context(query, k, **kwargs)

    # -------- Ingestion helpers (thin wrappers over PgVectorIngester) --------

    async def ingest_raw_documents(
        self,
        documents: Iterable[RawDocument],
        *,
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
    ) -> int:
        """Proxy to PgVectorIngester.ingest_raw_documents."""
        return await self.ingester.ingest_raw_documents(
            documents,
            source=source,
            batch_size=batch_size,
            embed=embed,
        )

    async def ingest_noise_from_directory(
        self,
        directory: str | Path,
        *,
        pattern: str = "*.txt",
        encoding: str = "utf-8",
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
    ) -> int:
        """Proxy to PgVectorIngester.ingest_noise_from_directory."""
        return await self.ingester.ingest_noise_from_directory(
            directory,
            pattern=pattern,
            encoding=encoding,
            source=source,
            batch_size=batch_size,
            embed=embed,
        )

    async def ingest_noise_from_hf_dataset(
        self,
        dataset_name: str = "wikimedia/wikipedia",
        *,
        dataset_config: Optional[str] = "20231101.en",
        split: str = "train",
        text_field: str = "text",
        limit: Optional[int] = None,
        max_chars: int = 2000,
        source: str = "wikipedia_noise",
        batch_size: int = 64,
        embed: bool = True,
        streaming: bool = False,
    ) -> int:
        """Proxy to PgVectorIngester.ingest_noise_from_hf_dataset."""
        return await self.ingester.ingest_noise_from_hf_dataset(
            dataset_name=dataset_name,
            dataset_config=dataset_config,
            split=split,
            text_field=text_field,
            limit=limit,
            max_chars=max_chars,
            source=source,
            batch_size=batch_size,
            embed=embed,
            streaming=streaming,
        )

    async def persist_documents_and_qa(
        self,
        documents: Iterable[RawDocument],
        qa_pairs: Iterable[QAPair],
        *,
        document_source: str = "documents",
    ) -> List[QAPair]:
        """Proxy to PgVectorIngester.persist_documents_and_qa."""
        return await self.ingester.persist_documents_and_qa(
            documents,
            qa_pairs,
            document_source=document_source,
        )


__all__ = [
    "PgVectorIngester",
    "PgVectorRetriever",
    "PgVectorContext",
]
