from __future__ import annotations

from typing import Callable, Dict, List, Iterable, TYPE_CHECKING

from pydantic import BaseModel

if TYPE_CHECKING:
    # Imported only for type-checking; at runtime we treat results as
    # duck-typed objects with the relevant attributes.
    from ..engine.scidf_orchestrator import QAResultSummary  # noqa: F401


WeightFn = Callable[[float], float]


class ModelHallucinationMetrics(BaseModel):
    """
    Aggregated hallucination metrics for a single model.

    This is the implementation of the model-level quantities described in
    the RT4Hallucination / SCID-F paper:
      - mean knowledge depth D
      - mean base hallucination H_contextual
      - weighted intrinsic hallucination index H_intrinsic^weighted
      - effective sample size (ESS) of the depth-based weights
    """

    model_id: str
    k_max: int
    num_samples: int

    mean_knowledge_depth: float
    mean_base_hallucination: float

    # H_intrinsic^{weighted}(M) – lower is better.
    weighted_intrinsic_hallucination: float

    # Effective sample size of the weights; larger means weight
    # distribution is more balanced across questions.
    ess: float

    def pprint(self, width: int = 80) -> None:
        """
        Pretty-print a compact summary of the model-level metrics.

        Args:
            width: Separator width for visual grouping.
        """
        sep = "-" * width
        lines = [
            sep,
            f"Model ID:                           {self.model_id}",
            f"k_max:                              {self.k_max}",
            f"Num samples:                        {self.num_samples}",
            f"Mean knowledge depth:               {self.mean_knowledge_depth:.3f}",
            f"Mean base hallucination:            {self.mean_base_hallucination:.3f}",
            f"Weighted intrinsic hallucination H: {self.weighted_intrinsic_hallucination:.4f}",
            f"Effective sample size (ESS):        {self.ess:.1f}",
        ]
        print("\n".join(lines))

class ModelHallucinationMetricsList(BaseModel):
    """
    List of ModelHallucinationMetrics.
    """
    metrics: Dict[str, ModelHallucinationMetrics]

    def add_metric(self, model_id: str, metric: ModelHallucinationMetrics) -> None:
        self.metrics[model_id] = metric

    def pprint(self, width: int = 80) -> None:
        """
        Pretty-print a compact summary of the model-level metrics.
        """
        for m in self.metrics.values():
            m.pprint(width)


def _default_weight_fn(d_tilde: float) -> float:
    """Default linear weight: W(d̃) = 1 - d̃."""
    if d_tilde <= 0.0:
        return 1.0
    if d_tilde >= 1.0:
        return 0.0
    return 1.0 - d_tilde


def make_weight_fn(name: str, alpha: float = 2.0) -> WeightFn:
    """
    Build a monotone decreasing weight function W(d̃) on [0,1].

    Args:
        name: One of {"linear", "exp", "step"} (case-insensitive).
        alpha: Shape parameter for "exp" (larger = steeper decay).
    """
    key = name.lower().strip()

    if key == "linear":
        return _default_weight_fn

    if key == "exp":
        def _exp(d_tilde: float) -> float:
            if d_tilde <= 0.0:
                return 1.0
            if d_tilde >= 1.0:
                return float(pow(2.718281828459045, -alpha))
            return float(pow(2.718281828459045, -alpha * d_tilde))

        return _exp

    if key == "step":
        # Simple 3-level step: shallow depth gets weight 1,
        # medium 0.5, deep 0.1.
        def _step(d_tilde: float) -> float:
            if d_tilde <= 1.0 / 3.0:
                return 1.0
            if d_tilde <= 2.0 / 3.0:
                return 0.5
            return 0.1

        return _step

    # Fallback to linear if name is unrecognized.
    return _default_weight_fn


def _group_by_model(results: Iterable["QAResultSummary"]) -> Dict[str, List["QAResultSummary"]]:
    grouped: Dict[str, List["QAResultSummary"]] = {}
    for r in results:
        grouped.setdefault(r.model_id, []).append(r)
    return grouped


def compute_model_metrics(
    results: List["QAResultSummary"],
    *,
    k_max: int,
    weight_fn: WeightFn | None = None,
) -> ModelHallucinationMetricsList:
    """
    Aggregate QA-level SCID-F results into model-level hallucination metrics.

    Args:
        results: List of QAResultSummary from ScidfOrchestrator.run_experiment.
        k_max: Maximum context length used in the experiment (for depth normalization).
        weight_fn: Optional weight function W(d̃); if None, uses linear 1 - d̃.

    Returns:
        A dict mapping model_id -> ModelHallucinationMetrics.
    """
    if not results:
        return ModelHallucinationMetricsList(metrics={})

    if k_max <= 0:
        raise ValueError("k_max must be positive for metrics computation.")

    wf = weight_fn or _default_weight_fn
    grouped = _group_by_model(results)
    model_metrics: ModelHallucinationMetricsList = ModelHallucinationMetricsList(metrics={})

    for model_id, group in grouped.items():
        n = len(group)
        if n == 0:
            continue

        depths: List[float] = []
        hallucinations: List[float] = []
        weights: List[float] = []

        for r in group:
            # Clamp depth and base_hallucination to reasonable ranges.
            d = max(0.0, float(r.knowledge_depth))
            h = float(r.base_hallucination)
            if h < 0.0:
                h = 0.0
            elif h > 1.0:
                h = 1.0

            depths.append(d)
            hallucinations.append(h)

            d_tilde = d / float(k_max)
            if d_tilde < 0.0:
                d_tilde = 0.0
            elif d_tilde > 1.0:
                d_tilde = 1.0

            w = wf(d_tilde)
            if w < 0.0:
                w = 0.0
            weights.append(w)

        mean_depth = sum(depths) / n
        mean_h = sum(hallucinations) / n

        sum_w = sum(weights)
        if sum_w <= 0.0:
            # If all weights are zero (pathological), fall back to uniform weights.
            weights = [1.0] * n
            sum_w = float(n)

        weighted_h = sum(h * w for h, w in zip(hallucinations, weights)) / sum_w

        sum_w2 = sum(w * w for w in weights)
        ess = (sum_w * sum_w / sum_w2) if sum_w2 > 0.0 else 0.0

        model_metrics.add_metric(model_id, ModelHallucinationMetrics(
            model_id=model_id,
            k_max=k_max,
            num_samples=n,
            mean_knowledge_depth=mean_depth,
            mean_base_hallucination=mean_h,
            weighted_intrinsic_hallucination=weighted_h,
            ess=ess,
        ))

    return model_metrics


__all__ = [
    "WeightFn",
    "ModelHallucinationMetrics",
    "make_weight_fn",
    "compute_model_metrics",
]
