from __future__ import annotations

import random
from typing import Dict, List, Optional, Tuple

from pydantic import BaseModel

from ..cache import CacheConfig
from ..core import LLMProvider, ContextProvider
from ..data import QAPair
from ..engine.scidf_orchestrator import ScidfOrchestrator, QAResultSummary
from .metrics import (
    ModelHallucinationMetrics,
    WeightFn,
    compute_model_metrics,
    make_weight_fn,
)


class ScidfEvaluationConfig(BaseModel):
    """
    Configuration for running a SCID-F evaluation on a given QA dataset.

    This config is intentionally generic: it does not assume how the QA pairs
    were generated (pre-existing dataset vs. document-based generation).
    """

    k_max: int = 10
    k_min: int = 2
    batch_size: int = 4

    # Optional: subsample a fixed number of QA pairs for cost control.
    sample_size: Optional[int] = None

    # Weighting scheme for aggregating H_contextual with depth-based weights.
    weight_fn_name: str = "linear"
    weight_alpha: float = 2.0

    # Seed for deterministic operations (noise ordering, subsampling, etc.).
    seed: int = 42

    # Optional: which entry in the `models` mapping should be used as
    # the LLM-as-judge. When None, the first key in `models` is used.
    judge_model_id: Optional[str] = None


class HallucinationEvaluator:
    """
    High-level runner that wires a ContextProvider + ScidfOrchestrator and
    aggregates model-level hallucination metrics.

    Typical usage:

        config = ScidfEvaluationConfig(k_max=10, k_min=2)
        context = PgVectorContext(db_url=..., embedder=...)
        evaluator = HallucinationEvaluator(context=context, config=config)
        results, metrics = await evaluator.run_on_qa_pairs(qa_pairs, models)
    """

    def __init__(
        self,
        *,
        context: ContextProvider,
        config: ScidfEvaluationConfig,
        cache_config: Optional[CacheConfig] = None,
    ):
        self.context = context
        self.config = config
        self.cache_config = cache_config or CacheConfig(enabled=True)

    def _maybe_sample(self, qa_pairs: List[QAPair]) -> List[QAPair]:
        if not qa_pairs:
            return qa_pairs

        n = len(qa_pairs)
        sample_size = self.config.sample_size
        if sample_size is None or sample_size <= 0 or sample_size >= n:
            return qa_pairs

        rnd = random.Random(self.config.seed)
        # Preserve relative order within the sampled subset by sorting
        # according to original index.
        indices = list(range(n))
        rnd.shuffle(indices)
        chosen = sorted(indices[:sample_size])
        return [qa_pairs[i] for i in chosen]

    async def run_on_qa_pairs(
        self,
        qa_pairs: List[QAPair],
        models: Dict[str, LLMProvider],
        *,
        weight_fn: WeightFn | None = None,
    ) -> Tuple[List[QAResultSummary], Dict[str, ModelHallucinationMetrics]]:
        """
        Run SCID-F on a list of QA pairs and compute model-level metrics.

        Args:
            qa_pairs: Input QA pairs; their ids must align with the `qa_pairs`
                table in the configured Postgres database so that
                PgVectorRetriever can fetch the correct golden documents.
            models: Mapping from model_id to LLMProvider.
            weight_fn: Optional custom weight function; if None, it is built
                from `weight_fn_name` and `weight_alpha` in the config.

        Returns:
            (results, metrics) where:
              - results is a list of QAResultSummary (one per QA × model),
              - metrics is a dict model_id -> ModelHallucinationMetrics.
        """
        if not qa_pairs:
            return [], {}

        qa_subset = self._maybe_sample(qa_pairs)

        if not models:
            raise ValueError("models must be a non-empty dict of LLMProvider.")

        judge_model_id = self.config.judge_model_id or next(iter(models.keys()))
        if judge_model_id not in models:
            raise ValueError(
                f"judge_model_id {judge_model_id!r} is not present in models; "
                "make sure it matches a key in the `models` dict."
            )
        judge_provider = models[judge_model_id]

        orchestrator = ScidfOrchestrator(
            models=models,
            context=self.context,
            judge_provider=judge_provider,
            k_max=self.config.k_max,
            k_min=self.config.k_min,
            batch_size=self.config.batch_size,
            cache_config=self.cache_config,
        )

        results = await orchestrator.run_experiment(qa_subset)

        wf = weight_fn or make_weight_fn(
            self.config.weight_fn_name,
            alpha=self.config.weight_alpha,
        )
        metrics = compute_model_metrics(
            results,
            k_max=self.config.k_max,
            weight_fn=wf,
        )
        return results, metrics


__all__ = [
    "ScidfEvaluationConfig",
    "HallucinationEvaluator",
]
