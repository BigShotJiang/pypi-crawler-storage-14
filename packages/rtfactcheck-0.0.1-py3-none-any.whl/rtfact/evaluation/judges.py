from ..core import Judge, EvaluationResult, LLMProvider
from tenacity import retry, wait_random_exponential, stop_after_attempt
from typing import cast


class CorrectnessJudge(Judge):
    """Judge for evaluating correctness using an LLM."""

    def __init__(self, llm_provider: LLMProvider):
        self.llm = llm_provider

    def _build_prompt(self, question: str, ground_truth: str, response: str) -> str:
        return f"""You are an expert evaluator tasked with assessing the quality of an AI model's response to a question. Please evaluate the response on two key dimensions, STRICTLY following the definitions below:

1. **CORRECTNESS**: Does the response factually and accurately answer the question? Compare it against the ground truth.
   - Score 1.0 if completely correct, 0.0 if completely wrong, or intermediate values for partially correct answers.

---

**QUESTION**: {question}

**GROUND TRUTH ANSWER**: {ground_truth}

**MODEL'S RESPONSE**: {response}

---

Please provide your evaluation following these guidelines:

**CORRECTNESS**: 
- Score 1.0 if the response correctly and completely answers the question
- Score 0.0 if the response is factually incorrect, irrelevant, or fails to answer the question
- Score intermediate values (0.1-0.9) for partially correct answers
- Consider partial credit for answers that are correct but incomplete or contain minor errors

**REASONING**: Provide a clear explanation for your decisions on both dimensions."""

    @retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(3))
    async def evaluate(
        self, question: str, ground_truth: str, response: str, context: str = ""
    ) -> EvaluationResult:
        prompt = self._build_prompt(question, ground_truth, response)

        try:
            # We assume the LLM provider supports structured output for EvaluationResult
            result = await self.llm.generate_structured(prompt, EvaluationResult)

            # Cast to EvaluationResult for type checking
            result = cast(EvaluationResult, result)

            if result.correctness_score is None:
                result.correctness_score = 1.0 if result.is_correct else 0.0

            return result
        except Exception as e:
            return EvaluationResult(
                is_correct=False,
                correctness_score=0.0,
                reasoning=f"Evaluation failed: {str(e)}",
            )


class RefusalJudge:
    """Judge for classifying refusals."""

    def __init__(self, llm_provider: LLMProvider):
        self.llm = llm_provider

    async def is_refusal(self, question: str, response: str) -> bool:
        prompt = (
            "You are a strict classifier. Decide whether the following MODEL OUTPUT is a refusal to answer when the provided context is insufficient or irrelevant.\n\n"
            "If it clearly indicates inability to answer (e.g., says it cannot determine from context, lacks information, doesn't know), classify as REFUSE.\n"
            "If it provides or attempts a substantive factual answer, classify as NON-REFUSE.\n\n"
            f"Original Question: {question}\n\n"
            f"MODEL OUTPUT:\n{response}\n\n"
            "Return EXACTLY one token: REFUSE or NON-REFUSE."
        )

        try:
            content = await self.llm.generate(prompt, temperature=0.0, max_tokens=5)
            if not content:
                return True

            cls = content.strip().upper()
            if "REFUSE" in cls and "NON" not in cls:
                return True
            if cls == "REFUSE":
                return True
            return False
        except Exception:
            return False
