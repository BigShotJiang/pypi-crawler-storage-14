import json
import asyncio
from collections import OrderedDict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict
from .models import CacheKey, CacheEntry, CacheConfig, CacheStats

class CacheManager:
    """
    Cache manager handling memory and persistent caching.
    """
    
    def __init__(self, config: CacheConfig):
        self.config = config
        self.stats = CacheStats()
        self._memory_cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._persistent_cache: Dict[str, CacheEntry] = {}
        self._lock = asyncio.Lock()
        self._unsaved_changes = 0
        
        # Load persistent cache on init
        asyncio.create_task(self._load_persistent_cache())
    
    async def _load_persistent_cache(self) -> None:
        if not self.config.enabled:
            return
            
        cache_path = Path(self.config.persistent_cache_path)
        try:
            if cache_path.exists():
                with open(cache_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                current_time = datetime.now()
                ttl_delta = timedelta(hours=self.config.cache_ttl_hours)
                
                for key_hash, entry_data in data.items():
                    entry = CacheEntry(**entry_data)
                    if current_time - entry.created_at < ttl_delta:
                        self._persistent_cache[key_hash] = entry
                
                self.stats.persistent_entries = len(self._persistent_cache)
        except Exception as e:
            print(f"Failed to load persistent cache: {e}")
    
    async def _save_persistent_cache(self) -> None:
        if not self.config.enabled or not self._persistent_cache:
            return
            
        cache_path = Path(self.config.persistent_cache_path)
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            
            serializable_data = {
                k: v.dict() for k, v in self._persistent_cache.items()
            }
            
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(serializable_data, f, indent=2, ensure_ascii=False, default=str)
            
            self._unsaved_changes = 0
        except Exception as e:
            print(f"Failed to save persistent cache: {e}")
    
    async def get(self, cache_key: CacheKey) -> Optional[str]:
        if not self.config.enabled:
            self.stats.record_miss()
            return None
        
        key_hash = cache_key.generate_hash()
        
        async with self._lock:
            # Check memory cache
            if key_hash in self._memory_cache:
                entry = self._memory_cache[key_hash]
                entry.update_access()
                self._memory_cache.move_to_end(key_hash)
                self.stats.record_hit()
                return entry.response
            
            # Check persistent cache
            if key_hash in self._persistent_cache:
                entry = self._persistent_cache[key_hash]
                ttl_delta = timedelta(hours=self.config.cache_ttl_hours)
                
                if datetime.now() - entry.created_at < ttl_delta:
                    entry.update_access()
                    await self._add_to_memory_cache(key_hash, entry)
                    self.stats.record_hit()
                    return entry.response
                else:
                    del self._persistent_cache[key_hash]
                    self.stats.persistent_entries = len(self._persistent_cache)
            
            self.stats.record_miss()
            return None
    
    async def set(self, cache_key: CacheKey, response: str) -> None:
        if not self.config.enabled:
            return
        
        key_hash = cache_key.generate_hash()
        entry = CacheEntry(
            key_hash=key_hash,
            response=response,
            model_id=cache_key.model_id
        )
        
        async with self._lock:
            await self._add_to_memory_cache(key_hash, entry)
            self._persistent_cache[key_hash] = entry
            self.stats.persistent_entries = len(self._persistent_cache)
            
            self._unsaved_changes += 1
            if self._unsaved_changes >= self.config.auto_save_interval:
                asyncio.create_task(self._save_persistent_cache())
    
    async def _add_to_memory_cache(self, key_hash: str, entry: CacheEntry) -> None:
        if key_hash in self._memory_cache:
            self._memory_cache[key_hash] = entry
            self._memory_cache.move_to_end(key_hash)
        else:
            if len(self._memory_cache) >= self.config.memory_cache_size:
                self._memory_cache.popitem(last=False)
            self._memory_cache[key_hash] = entry
        self.stats.memory_entries = len(self._memory_cache)

    async def shutdown(self) -> None:
        if self._unsaved_changes > 0:
            await self._save_persistent_cache()
