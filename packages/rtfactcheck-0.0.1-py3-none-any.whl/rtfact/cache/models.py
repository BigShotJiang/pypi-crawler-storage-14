import hashlib
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field

class CacheKey(BaseModel):
    """Data model for cache keys."""
    model_id: str = Field(..., description="Model identifier")
    prompt: str = Field(..., description="Input prompt")
    temperature: float = Field(default=0.0, description="Temperature parameter")
    max_tokens: int = Field(default=1000, description="Max tokens")
    seed: Optional[int] = Field(default=42, description="Random seed")
    
    def generate_hash(self) -> str:
        """Generate SHA256 hash of the cache key."""
        content = f"{self.model_id}:{self.prompt}:{self.temperature}:{self.max_tokens}:{self.seed}"
        return hashlib.sha256(content.encode('utf-8')).hexdigest()

class CacheEntry(BaseModel):
    """Data model for cache entries."""
    key_hash: str
    response: str
    model_id: str
    created_at: datetime = Field(default_factory=datetime.now)
    access_count: int = Field(default=1)
    last_accessed: datetime = Field(default_factory=datetime.now)
    
    def update_access(self) -> None:
        self.access_count += 1
        self.last_accessed = datetime.now()

class CacheConfig(BaseModel):
    """Configuration for the cache system."""
    enabled: bool = Field(default=True)
    memory_cache_size: int = Field(default=1000)
    persistent_cache_path: str = Field(default="cache/rtfact_cache.json")
    cache_ttl_hours: int = Field(default=24)
    auto_save_interval: int = Field(default=10)
    
    class Config:
        frozen = True

class CacheStats(BaseModel):
    """Statistics for the cache system."""
    total_requests: int = Field(default=0)
    cache_hits: int = Field(default=0)
    cache_misses: int = Field(default=0)
    memory_entries: int = Field(default=0)
    persistent_entries: int = Field(default=0)
    
    @property
    def hit_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return (self.cache_hits / self.total_requests) * 100
    
    def record_hit(self) -> None:
        self.cache_hits += 1
        self.total_requests += 1
    
    def record_miss(self) -> None:
        self.cache_misses += 1
        self.total_requests += 1
