from __future__ import annotations

import hashlib
import re
from typing import Optional


def make_qid(question: Optional[str], qa_id: int, *, max_prefix: int = 25) -> str:
    """
    Build a filesystem-friendly QID from the question text.

    Rules:
      - lower-case
      - use only the first line
      - replace whitespace with '-'
      - remove characters invalid or awkward in file/dir names
      - limit the human-readable prefix to at most `max_prefix` characters
      - append an 8-char hash of the original question to ensure uniqueness
    """
    raw = question or f"qa_{qa_id}"
    h = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:8]

    base = raw.lower()
    base = base.replace("\r\n", "\n").replace("\r", "\n").split("\n", 1)[0]
    base = re.sub(r"\s+", "-", base)
    base = re.sub(r"[^a-z0-9\\-]+", "", base)
    base = base.strip("-")
    if len(base) > max_prefix:
        base = base[:max_prefix].rstrip("-")
    if not base:
        base = f"qa-{qa_id}"
    return f"{base}-{h}"


def to_sync_db_url(url: str) -> str:
    """
    Convert an asyncpg-style SQLAlchemy URL to a synchronous one.

    Example:
        postgresql+asyncpg://... -> postgresql+psycopg2://...
    """
    if not url:
        return url
    if url.startswith("postgresql+asyncpg"):
        return url.replace("postgresql+asyncpg", "postgresql+psycopg2", 1)
    return url


__all__ = ["make_qid", "to_sync_db_url"]

