from __future__ import annotations

import csv
from pathlib import Path
from typing import List

from ..utils import make_qid
from .scidf_orchestrator import QAResultSummary


class ResultExporter:
    """
    Export SCID-F experiment results to disk.

    Current implementation writes:
      - A CSV file with one row per QAResultSummary.
      - A directory per sample (qid) with one text file per field.
    """

    def __init__(
        self,
        output_root: Path | str = "result",
        run_name: str = "documents",
        csv_name: str = "scidf_ab_documents.csv",
    ) -> None:
        self.output_root = Path(output_root)
        self.run_name = run_name
        self.csv_name = csv_name

    def export(self, results: List[QAResultSummary]) -> Path:
        """
        Export results to CSV and per-sample folders.

        Returns:
            Path to the run directory.
        """
        out_dir = self.output_root / f"run_{self.run_name}"
        out_dir.mkdir(parents=True, exist_ok=True)
        csv_path = out_dir / self.csv_name

        sorted_results = sorted(
            results,
            key=lambda x: x.base_hallucination,
            reverse=True,
        )

        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                [
                    "qa_id",
                    "model_id",
                    "knowledge_depth",
                    "base_hallucination",
                    "qid",
                    "reason",
                    "error",
                ]
            )
            for r in sorted_results:
                qid = make_qid(r.question, r.qa_id)
                writer.writerow(
                    [
                        r.qa_id,
                        r.model_id,
                        r.knowledge_depth,
                        r.base_hallucination,
                        qid,
                        r.reason or "",
                        r.error or "",
                    ]
                )

                sample_dir = out_dir / qid
                sample_dir.mkdir(parents=True, exist_ok=True)
                (sample_dir / "qa_id.txt").write_text(
                    str(r.qa_id), encoding="utf-8"
                )
                (sample_dir / "model_id.txt").write_text(
                    str(r.model_id), encoding="utf-8"
                )
                (sample_dir / "question.txt").write_text(
                    r.question or "", encoding="utf-8"
                )
                (sample_dir / "answer.txt").write_text(
                    r.ground_truth_answer or "", encoding="utf-8"
                )
                (sample_dir / "knowledge_depth.txt").write_text(
                    str(r.knowledge_depth), encoding="utf-8"
                )
                (sample_dir / "base_hallucination.txt").write_text(
                    str(r.base_hallucination), encoding="utf-8"
                )
                (sample_dir / "reason.txt").write_text(
                    r.reason or "", encoding="utf-8"
                )
                (sample_dir / "context_signal.txt").write_text(
                    r.context_signal or "", encoding="utf-8"
                )
                (sample_dir / "response_signal.txt").write_text(
                    r.response_signal or "", encoding="utf-8"
                )
                (sample_dir / "context_noise.txt").write_text(
                    r.context_noise or "", encoding="utf-8"
                )
                (sample_dir / "response_noise.txt").write_text(
                    r.response_noise or "", encoding="utf-8"
                )
                (sample_dir / "error.txt").write_text(
                    r.error or "", encoding="utf-8"
                )

        return out_dir

