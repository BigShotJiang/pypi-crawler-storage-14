from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from pydantic import BaseModel


class EvaluationResult(BaseModel):
    """Standardized evaluation result."""

    is_correct: bool
    correctness_score: float
    faithfulness_score: Optional[float] = None
    reasoning: str
    metadata: Dict[str, Any] = {}


class LLMProvider(ABC):
    """Abstract interface for LLM providers."""

    @abstractmethod
    async def generate(self, prompt: str, **kwargs) -> str:
        """Generate text from a prompt."""
        pass

    @abstractmethod
    async def generate_structured(
        self, prompt: str, response_model: type[BaseModel], **kwargs
    ) -> BaseModel:
        """Generate structured output."""
        pass


class ContextProvider(ABC):
    """Abstract interface for building retrieval-based contexts for SCID-F."""

    @abstractmethod
    async def get_context(self, query: str, k: int, **kwargs) -> str:
        """Retrieve context for a query."""
        pass


class Judge(ABC):
    """Abstract interface for evaluation judges."""

    @abstractmethod
    async def evaluate(
        self, question: str, ground_truth: str, response: str, context: str
    ) -> EvaluationResult:
        """Evaluate a response."""
        pass
