
```bash
# Context Architect (ZMB)

**Stop Fighting the Context Window.**

The intelligent CLI that curates your codebase for AI coding assistants. Focus on what matters, ignore the noise.

[**View Public Roadmap**](https://github.com/ADevBelgie/ZMB-Prototype/blob/master/docs/ROADMAP.md) | [**Read the Docs**](https://github.com/ADevBelgie/ZMB-Prototype)

```bash
pip install .
```

### Usage

```bash
context-architect scan
context-architect generate --output context.md
context-architect generate --focus auth
```
