# SPDX-FileCopyrightText: 2025 German Aerospace Center <amiris@dlr.de>
#
# SPDX-License-Identifier: Apache-2.0
from priceforecast.workflow import priceforecast_cli

priceforecast_cli()
