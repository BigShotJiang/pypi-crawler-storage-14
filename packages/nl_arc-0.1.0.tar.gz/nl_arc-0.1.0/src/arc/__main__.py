"""Main entry point for Arc CLI when run as a module."""

from arc import main

if __name__ == "__main__":
    main()
