__all__ = (
    "__version__",
)

__version__ = "1.1.1"

import warnings

warnings.warn("The Brightway25 package doesn't provide anything; import the constituent libraries separately")
