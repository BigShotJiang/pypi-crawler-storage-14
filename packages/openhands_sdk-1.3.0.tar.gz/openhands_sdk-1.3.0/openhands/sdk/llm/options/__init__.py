# options package for LLM parameter selection helpers
