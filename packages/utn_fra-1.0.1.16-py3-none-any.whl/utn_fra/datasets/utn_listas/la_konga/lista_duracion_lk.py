# Copyright (C) 2025 <UTN FRA>
#
# Author: Facundo Falcone <f.falcone@sistemas-utnfra.com.ar>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

duraciones_lk = [
    150,
    169,
    176,
    164,
    183,
    139,
    217,
    174,
    332,
    213,
    219,
    175,
    225,
    180,
    192,
    161,
    221,
    194,
    176,
    177,
    6981,
    171,
    161,
    169,
    2722,
    199,
    178,
    345,
    177,
    189,
    184,
    187,
    189,
    164,
    203,
    31,
    218,
    186,
    237,
    230,
    31,
    199,
    246,
    265,
    189,
    252,
    218,
    181,
    235,
    213
]