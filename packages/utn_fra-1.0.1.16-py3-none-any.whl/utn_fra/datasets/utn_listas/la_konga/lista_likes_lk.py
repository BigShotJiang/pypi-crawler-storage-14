# Copyright (C) 2025 <UTN FRA>
#
# Author: Facundo Falcone <f.falcone@sistemas-utnfra.com.ar>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

likes_lk = [
    3576,
    3336,
    1736,
    2030,
    4343,
    4117,
    3119,
    7159,
    2983,
    4830,
    9053,
    1946,
    5732,
    882,
    4469,
    4103,
    14520,
    2596,
    4741,
    3930,
    5361,
    7127,
    19896,
    23646,
    3119,
    13765,
    18145,
    8299,
    50751,
    16038,
    10966,
    33986,
    18223,
    8655,
    25802,
    1,
    155083,
    28629,
    78913,
    20135,
    8,
    70809,
    62175,
    13969,
    28507,
    80445,
    18274,
    144107,
    8617,
    945275
]