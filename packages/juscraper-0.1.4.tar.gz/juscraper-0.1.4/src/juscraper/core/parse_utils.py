# helpers de BeautifulSoup, regex, limpeza de texto
