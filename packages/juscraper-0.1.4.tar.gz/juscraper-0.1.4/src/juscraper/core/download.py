# funções auxiliares (download único, retries, etc.)
