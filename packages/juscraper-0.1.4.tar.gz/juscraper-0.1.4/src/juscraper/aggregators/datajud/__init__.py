"""
Exports DatajudScraper for easier access
"""
from .client import DatajudScraper

__all__ = ["DatajudScraper"]
