
"""
Exports JusbrScraper for easier access
"""
from .client import JusbrScraper

__all__ = ["JusbrScraper"]
