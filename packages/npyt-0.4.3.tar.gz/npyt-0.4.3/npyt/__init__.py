from npyt._version import __version__
from npyt.core import NPYT
from npyt.endless import NPY8
