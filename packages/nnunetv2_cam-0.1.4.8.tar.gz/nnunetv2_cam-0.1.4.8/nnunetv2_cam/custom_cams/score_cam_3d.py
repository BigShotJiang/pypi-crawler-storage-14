"""
ScoreCAM implementation with 3D support.

This is a custom implementation that extends the original ScoreCAM to handle
both 2D and 3D spatial dimensions, making it compatible with 3D medical imaging
models like nnU-Net.
"""

import numpy as np
import torch
import torch.nn.functional as F
import tqdm
from pytorch_grad_cam.base_cam import BaseCAM


class ScoreCAM3D(BaseCAM):
    """
    ScoreCAM with adaptive 2D/3D upsampling support.
    
    Unlike the original ScoreCAM which hardcodes UpsamplingBilinear2d,
    this implementation automatically detects spatial dimensions and uses
    appropriate interpolation (bilinear for 2D, trilinear for 3D).
    """
    
    def __init__(
        self,
        model,
        target_layers,
        reshape_transform=None
    ):
        super(ScoreCAM3D, self).__init__(
            model,
            target_layers,
            reshape_transform=reshape_transform,
            uses_gradients=False
        )

    def get_cam_weights(
        self,
        input_tensor,
        target_layer,
        targets,
        activations,
        grads
    ):
        """
        Compute importance weights for each activation channel using forward passes.
        
        Args:
            input_tensor: Input image tensor (N, C, H, W) or (N, C, D, H, W)
            target_layer: Target layer (unused in ScoreCAM)
            targets: List of target objects
            activations: Activation maps from target layer
            grads: Gradients (unused in ScoreCAM)
            
        Returns:
            weights: Importance weights for each channel (N, C)
        """
        with torch.no_grad():
            # Convert activations to tensor if needed
            if isinstance(activations, np.ndarray):
                activation_tensor = torch.from_numpy(activations)
            else:
                activation_tensor = activations
            
            activation_tensor = activation_tensor.to(self.device)
            
            # Detect spatial dimensions
            spatial_dims = len(input_tensor.shape) - 2  # 2 for batch + channel
            
            # Adaptive upsampling based on spatial dimensions
            if spatial_dims == 2:
                # 2D: (N, C, H, W)
                target_size = input_tensor.shape[-2:]
                upsampled = F.interpolate(
                    activation_tensor,
                    size=target_size,
                    mode='bilinear',
                    align_corners=False
                )
            elif spatial_dims == 3:
                # 3D: (N, C, D, H, W)
                target_size = input_tensor.shape[-3:]
                upsampled = F.interpolate(
                    activation_tensor,
                    size=target_size,
                    mode='trilinear',
                    align_corners=False
                )
            else:
                raise ValueError(
                    f"Invalid spatial dimensions: {spatial_dims}. "
                    f"Expected 2 (for 2D images) or 3 (for 3D volumes)."
                )

            # Normalize each activation map to [0, 1]
            # Flatten spatial dimensions for min/max computation
            batch_size, num_channels = upsampled.size(0), upsampled.size(1)
            upsampled_flat = upsampled.view(batch_size, num_channels, -1)
            
            maxs = upsampled_flat.max(dim=-1)[0]
            mins = upsampled_flat.min(dim=-1)[0]
            
            # Reshape for broadcasting
            if spatial_dims == 2:
                maxs = maxs[:, :, None, None]
                mins = mins[:, :, None, None]
            elif spatial_dims == 3:
                maxs = maxs[:, :, None, None, None]
                mins = mins[:, :, None, None, None]
            
            # Normalize
            upsampled = (upsampled - mins) / (maxs - mins + 1e-8)

            # Create masked inputs: each channel masks the input
            # Broadcasting: (N, 1, spatial...) * (N, C, 1, spatial...)
            if spatial_dims == 2:
                # (N, 1, H, W) * (N, C, 1, H, W) -> (N, C, 1, H, W)
                input_tensors = input_tensor[:, None, :, :, :] * upsampled[:, :, None, :, :]
            elif spatial_dims == 3:
                # (N, 1, D, H, W) * (N, C, 1, D, H, W) -> (N, C, 1, D, H, W)
                input_tensors = input_tensor[:, None, :, :, :, :] * upsampled[:, :, None, :, :, :]

            # Batch size for forward passes
            if hasattr(self, "batch_size"):
                BATCH_SIZE = self.batch_size
            else:
                BATCH_SIZE = 16

            # Score each masked input
            scores = []
            for target, tensor in zip(targets, input_tensors):
                for i in tqdm.tqdm(range(0, tensor.size(0), BATCH_SIZE), desc="ScoreCAM"):
                    batch = tensor[i: i + BATCH_SIZE, :]
                    outputs = [
                        target(o).cpu().item()
                        for o in self.model(batch)
                    ]
                    scores.extend(outputs)
            
            scores = torch.Tensor(scores)
            scores = scores.view(activations.shape[0], activations.shape[1])
            
            # Apply softmax to get weights
            weights = torch.nn.Softmax(dim=-1)(scores).numpy()
            
            return weights
