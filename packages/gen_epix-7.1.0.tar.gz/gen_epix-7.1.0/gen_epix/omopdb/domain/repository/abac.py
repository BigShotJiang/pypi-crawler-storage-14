from gen_epix.commondb.domain.repository import (
    BaseAbacRepository as CommonBaseAbacRepository,
)


class BaseAbacRepository(CommonBaseAbacRepository):
    pass
