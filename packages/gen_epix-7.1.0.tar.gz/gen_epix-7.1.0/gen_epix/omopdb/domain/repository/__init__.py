# pylint: disable=useless-import-alias
from gen_epix.commondb.domain.repository import (
    BaseOrganizationRepository as BaseOrganizationRepository,
)
from gen_epix.commondb.domain.repository import (
    BaseSystemRepository as BaseSystemRepository,
)
from gen_epix.omopdb.domain.repository.abac import (
    BaseAbacRepository as BaseAbacRepository,
)
from gen_epix.omopdb.domain.repository.omop import (
    BaseOmopRepository as BaseOmopRepository,
)
