# pylint: disable=useless-import-alias
from gen_epix.commondb.api import (
    UpdateUserOwnOrganizationRequestBody as UpdateUserOwnOrganizationRequestBody,
)
