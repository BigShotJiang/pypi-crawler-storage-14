# pylint: disable=useless-import-alias
from gen_epix.casedb.services.seqdb.remote_app import SeqdbRemoteApp as SeqdbRemoteApp
from gen_epix.casedb.services.seqdb.service import SeqdbService as SeqdbService
