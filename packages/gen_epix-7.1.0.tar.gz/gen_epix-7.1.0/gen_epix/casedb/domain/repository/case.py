from gen_epix.fastapp import BaseRepository


class BaseCaseRepository(BaseRepository):
    pass
