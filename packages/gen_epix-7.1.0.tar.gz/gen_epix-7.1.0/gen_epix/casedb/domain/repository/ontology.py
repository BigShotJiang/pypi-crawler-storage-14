from gen_epix.fastapp import BaseRepository


class BaseOntologyRepository(BaseRepository):
    pass
