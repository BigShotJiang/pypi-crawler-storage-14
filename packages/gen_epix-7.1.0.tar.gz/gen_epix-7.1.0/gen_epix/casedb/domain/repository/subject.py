from gen_epix.fastapp import BaseRepository


class BaseSubjectRepository(BaseRepository):
    pass
