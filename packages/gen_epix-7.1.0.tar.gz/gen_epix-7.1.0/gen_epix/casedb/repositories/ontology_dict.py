from gen_epix.casedb.domain.repository import BaseOntologyRepository
from gen_epix.fastapp.repositories import DictRepository


class OntologyDictRepository(DictRepository, BaseOntologyRepository):
    pass
