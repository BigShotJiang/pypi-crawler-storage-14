# pylint: disable=useless-import-alias
from gen_epix.fastapp.api.crud_endpoint_generator import (
    CrudEndpointGenerator as CrudEndpointGenerator,
)
from gen_epix.fastapp.api.crud_endpoint_set import CrudEndpointSet as CrudEndpointSet
