# pylint: disable=useless-import-alias
from gen_epix.fastapp.services.remote.service import (
    BaseRemoteService as BaseRemoteService,
)
