from gen_epix.fastapp.repository import BaseRepository


class BaseFileRepository(BaseRepository):

    pass
