from gen_epix.fastapp.repositories import DictRepository
from gen_epix.seqdb.domain.repository import BaseAbacRepository


class AbacDictRepository(DictRepository, BaseAbacRepository):
    pass
