# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## 项目概述

**DF Test Framework** - 现代化 Python 测试自动化框架
- **Python**: 3.12+
- **核心**: 基于 pytest + httpx + Pydantic v2 + SQLAlchemy + Pluggy
- **架构**: 五层架构（能力层驱动设计）

---

## 核心开发命令

### 环境设置与依赖管理

```bash
# 同步开发依赖（推荐 - 默认包含dev依赖组）
uv sync

# 同步所有可选依赖（包括UI、消息队列等）
uv sync --all-extras

# 传统方式安装开发依赖
uv pip install -e ".[dev]"
```

### 测试执行

```bash
# 运行所有测试（推荐）
uv run pytest -v

# 排除需要外部服务的测试（Kafka/RabbitMQ/RocketMQ）
uv run pytest -v --ignore=tests/test_messengers/

# 运行特定测试文件
uv run pytest tests/clients/http/test_client.py -v

# 运行特定测试类/方法
uv run pytest tests/clients/http/test_client.py::TestHTTPClient -v
uv run pytest tests/clients/http/test_client.py::TestHTTPClient::test_get_request -v

# 使用标记运行测试
uv run pytest -m smoke -v         # 冒烟测试
uv run pytest -m "not slow" -v    # 排除慢速测试
uv run pytest -m asyncio -v       # 异步测试
```

### 代码质量检查

```bash
# Ruff 代码检查
uv run ruff check src/ tests/

# 自动修复
uv run ruff check --fix src/ tests/

# 格式化代码
uv run ruff format src/ tests/

# 类型检查
uv run mypy src/
```

### 测试覆盖率

```bash
# 生成覆盖率报告（显示未覆盖行）
uv run pytest --cov=src/df_test_framework --cov-report=term-missing

# 生成 HTML 报告
uv run pytest --cov=src/df_test_framework --cov-report=html

# 查看报告（Windows）
start reports/coverage/index.html

# 覆盖率要求: ≥80% (配置在 pyproject.toml)
```

### CLI 工具

```bash
# 初始化项目脚手架
df-test init my-test-project              # API 测试项目
df-test init my-test-project --type ui    # UI 测试项目
df-test init my-test-project --type full  # API + UI 混合

# 代码生成
df-test gen test user_login               # 生成测试文件
df-test gen builder user                  # 生成 Builder 类
df-test gen repository user               # 生成 Repository 类
df-test gen api-client --spec api.yaml    # 从 OpenAPI 生成客户端
```

---

## 架构设计

### 五层架构

```
Layer 4 ─── extensions/         # Pluggy 扩展系统 + 内置监控
Layer 3 ─── testing/            # Fixtures、调试工具、数据构建、插件
Layer 2 ─── infrastructure/     # Bootstrap、配置、日志、Provider、Runtime
Layer 1 ─── clients/drivers/databases/messengers/storages/engines/  # 能力层
Layer 0 ─── common/             # 异常与基础类型
```

**依赖规则**: Layer N 只能依赖更低层，能力层不依赖测试层。

### 能力层（Layer 1）- 按交互模式组织

| 目录 | 职责 | 实现状态 |
|------|------|---------|
| `clients/` | 请求-响应模式（HTTP/REST、GraphQL、gRPC） | ✅ HttpClient + AsyncHttpClient |
| `drivers/` | 会话式交互（Playwright、Selenium） | ✅ Playwright |
| `databases/` | 数据存储（MySQL、Redis） | ✅ Database + RedisClient + Repository + UnitOfWork |
| `messengers/` | 消息队列（Kafka、RabbitMQ、RocketMQ） | ✅ 三种MQ客户端 (v3.9.0) |
| `storages/` | 对象存储（S3、MinIO） | ❌ 预留目录 |
| `engines/` | 计算引擎（Spark、Flink） | ❌ 预留目录 |

### 基础设施层（Layer 2）

#### Bootstrap 启动流程

```python
from df_test_framework import Bootstrap, FrameworkSettings

runtime = (
    Bootstrap()
    .with_settings(MySettings, namespace="test")
    .with_plugin("my_project.plugins")
    .build()
    .run()
)

# 获取资源
http = runtime.http_client()
db = runtime.database()
redis = runtime.redis_client()
```

**执行流程**:
1. 清理/加载 Settings（多配置源合并、命名空间缓存）
2. 初始化 Loguru 日志（结构化输出、敏感字段脱敏）
3. 装配 ProviderRegistry（默认 + Hook 扩展）
4. 注册 Pluggy 扩展并触发 `df_post_bootstrap`
5. 构造不可变 `RuntimeContext`

#### 配置系统

- **FrameworkSettings**: Pydantic BaseSettings，模块化配置
- **配置源**: EnvVarSource、DotenvSource、DictSource、ArgSource
- **嵌套键支持**: `APP_HTTP__BASE_URL`
- **命名空间**: 多环境配置隔离

#### Provider 体系

- **SingletonProvider**: 线程安全的惰性单例（双重检查锁）
- **ProviderRegistry**: 统一注册、扩展、关闭资源
- **自定义扩展**: 通过 `df_providers` Hook 注册

### 测试支持层（Layer 3）

#### Fixtures (`testing/fixtures/`)

```python
# 核心 fixtures (自动注入)
def test_api(runtime, http_client, database, redis_client):
    # runtime: RuntimeContext 实例
    # http_client: HttpClient 实例
    # database: Database 实例
    # redis_client: RedisClient 实例
    pass

# UI fixtures
def test_ui(browser_manager, page):
    # browser_manager: BrowserManager 实例
    # page: Playwright Page 对象
    pass

# 数据清理
def test_with_cleanup(test_data_cleaner):
    test_data_cleaner.register("users", user_id=123)
    # 测试结束后自动清理
```

#### 数据构建 (`testing/data/`)

- **预置工厂**: UserFactory, OrderFactory, ProductFactory 等 (8个)
- **数据加载器**: JSONLoader, CSVLoader, YAMLLoader
- **断言辅助**: ResponseAssertions（链式调用 + JSON Schema）

#### 调试工具 (`testing/debug/`)

```python
from df_test_framework.testing.debug import enable_http_debug, enable_db_debug

# 开启 HTTP 调试
enable_http_debug()

# 开启数据库调试
enable_db_debug()

# 录制请求/SQL、慢调用提示、终端摘要
```

### 扩展系统（Layer 4）

#### Pluggy Hooks

```python
@hookimpl
def df_config_sources(settings_cls):
    """提供额外配置源"""
    return [MyCustomSource()]

@hookimpl
def df_providers(settings, logger):
    """注入自定义 Provider"""
    return {"my_service": MyServiceProvider(settings)}

@hookimpl
def df_post_bootstrap(runtime):
    """Bootstrap 完成后的回调"""
    # 初始化逻辑
```

#### 内置扩展

- **APIPerformanceTracker**: 调用次数、耗时分位数、慢请求提醒
- **SlowQueryMonitor**: SQLAlchemy 事件监控慢 SQL

---

## 关键技术实现

### HttpClient 特性

```python
# 同步客户端
http = runtime.http_client()
response = http.get("/users/1")

# 拦截器: 签名、Token、Bearer、日志、重试
# 自动集成 HTTPDebugger
# 敏感信息脱敏
```

### AsyncHttpClient 特性（v3.8.0+）

```python
# 异步客户端 - 性能提升 10-50 倍
async with AsyncHttpClient("https://api.example.com") as client:
    # 并发 100 个请求（仅需 0.5 秒）
    tasks = [client.get(f"/users/{i}") for i in range(100)]
    responses = await asyncio.gather(*tasks)

# HTTP/2 支持、连接池管理、资源占用降低 75%
```

### Database 特性

```python
# 事务支持
with database.transaction():
    database.execute("INSERT ...")

# 保存点
with database.savepoint():
    database.execute("UPDATE ...")

# Repository 模式
class UserRepository(BaseRepository):
    def find_by_email(self, email: str):
        return self.query(QuerySpec(filters={"email": email}))

# UnitOfWork 模式 (v3.7.0+)
with UnitOfWork(runtime) as uow:
    uow.users.add(user)
    uow.orders.add(order)
    uow.commit()  # 原子提交
```

### 消息队列客户端（v3.9.0）

```python
# Kafka
kafka = KafkaClient(brokers=["localhost:9092"])
kafka.produce("topic", {"key": "value"})
messages = kafka.consume("topic", group_id="test")

# RabbitMQ
rabbitmq = RabbitMQClient(host="localhost")
rabbitmq.publish_direct("exchange", "routing_key", {"data": 123})
messages = rabbitmq.consume("queue")

# RocketMQ
rocketmq = RocketMQClient(name_server="localhost:9876")
rocketmq.send_message("topic", {"content": "test"}, tags="tag1")
```

---

## 日志记录模式

### 双层日志系统

框架提供两套互补的日志系统：

| 日志系统 | 用途 | 输出方式 | 使用场景 |
|---------|------|---------|---------|
| **ObservabilityLogger** | 实时日志 | 终端输出 | 本地调试、即时故障定位 |
| **Allure** | 审计报告 | HTML报告 | 测试报告、可视化分析 |

### Loguru 结构化日志

#### 基础配置

```python
from df_test_framework.infrastructure.config import LoggingConfig

# 在 FrameworkSettings 中配置
class MySettings(FrameworkSettings):
    logging: LoggingConfig = Field(
        default_factory=lambda: LoggingConfig(
            level="INFO",                    # 日志级别: DEBUG/INFO/WARNING/ERROR/CRITICAL
            file="logs/test.log",            # 日志文件路径
            rotation="100 MB",               # 轮转大小
            retention="7 days",              # 保留时间
            enable_console=True,             # 启用控制台输出
            sanitize=True,                   # 启用敏感信息脱敏
        )
    )
```

#### 日志输出格式

**控制台输出**（带颜色）:
```
2025-11-26 12:34:56 | INFO     | module:function | 消息内容
```

**文件输出**:
```
2025-11-26 12:34:56 | INFO     | module:function:line | 消息内容
```

**错误日志**（独立文件 `error.log`）:
```
2025-11-26 12:34:56 | ERROR    | module:function:line | 消息内容
[完整堆栈跟踪]
[变量诊断信息]
```

#### 敏感信息脱敏

自动脱敏以下字段（支持正则匹配）：
- `password` → `password: ******`
- `token` → `token: ******`
- `secret` → `secret: ******`
- `api_key` / `api-key` → `api_key: ******`
- `authorization` → `authorization: ******`

```python
# 脱敏前
logger.info("Login with password: mysecret123")

# 脱敏后（实际输出）
# Login with password: ******
```

#### 日志轮转与压缩

- **轮转**: 当日志文件达到 100MB 时自动轮转
- **压缩**: 旧日志自动压缩为 `.zip` 文件
- **保留**: 保留最近 7 天的日志
- **异步写入**: `enqueue=True` 避免阻塞主线程

### 可观测性日志（ObservabilityLogger）

#### 全局开关

```python
from df_test_framework.infrastructure.logging.observability import (
    set_observability_enabled,
    is_observability_enabled
)

# 禁用实时日志（不影响 Allure）
set_observability_enabled(False)

# 检查状态
print(is_observability_enabled())  # False
```

**优先级**:
1. 显式调用 `set_observability_enabled()` 设置的值
2. `FrameworkSettings.enable_observability` 配置
3. 默认值: `True`

#### HTTP 请求日志

```python
from df_test_framework.infrastructure.logging.observability import get_logger

logger = get_logger("HTTP")

# 请求开始
logger.request_start("GET", "/api/users", request_id="req-001")
# 输出: [12:34:56] [HTTP] [req-001] → GET /api/users

# 请求头（仅关键headers）
logger.request_headers(
    {"Authorization": "Bearer token123", "Content-Type": "application/json"},
    request_id="req-001",
    sanitize=True
)
# 输出: [12:34:56] [HTTP] [req-001] Headers: {'Authorization': 'Bearer ******'}

# 拦截器执行
logger.interceptor_execute(
    "SignatureInterceptor",
    {"headers": {"X-Sign": "abc123"}},
    request_id="req-001"
)
# 输出: [12:34:56] [HTTP] [req-001] Interceptor: SignatureInterceptor → Headers: X-Sign

# 请求结束
logger.request_end("req-001", 200, 145.5)
# 输出: [12:34:56] [HTTP] [req-001] ← 200 OK (145.5ms)

# 请求错误
logger.request_error(ConnectionError("Timeout"), request_id="req-001")
# 输出: [12:34:56] [HTTP] [req-001] ✗ Error: Timeout
```

**日志级别规则**:
- `2xx` 状态码 → `INFO`
- `4xx` 状态码 → `WARNING`
- `5xx` 状态码 → `ERROR`

#### 数据库查询日志

```python
logger = get_logger("DB")

# 查询开始
logger.query_start("SELECT", "users", query_id="q-001")
# 输出: [12:34:56] [DB] [q-001] → SELECT users

# 查询结束
logger.query_end("q-001", row_count=10, duration_ms=23.5)
# 输出: [12:34:56] [DB] [q-001] ← 10 rows (23.5ms)

# 查询错误
logger.query_error(DatabaseError("Connection lost"), query_id="q-001")
# 输出: [12:34:56] [DB] [q-001] ✗ Error: Connection lost
```

#### 事务日志

```python
logger = get_logger("DB")

# 事务开始
logger.transaction_start(tx_id="tx-001")
# 输出: [12:34:56] [DB] [tx-001] → BEGIN TRANSACTION

# 保存点
logger.savepoint_create("sp1", tx_id="tx-001")
# 输出: [12:34:56] [DB] [tx-001] → SAVEPOINT sp1

# 回滚到保存点
logger.savepoint_rollback("sp1", tx_id="tx-001")
# 输出: [12:34:56] [DB] [tx-001] ← ROLLBACK TO sp1

# 事务提交
logger.transaction_commit(tx_id="tx-001")
# 输出: [12:34:56] [DB] [tx-001] ← COMMIT
```

#### 自定义组件日志

```python
from df_test_framework.infrastructure.logging.observability import ObservabilityLogger

# 创建自定义组件日志
logger = ObservabilityLogger("MyService")

# 通用日志方法
logger.info("Service started")
logger.debug("Processing request", extra={"user_id": 123})
logger.warning("Cache miss")
logger.error("Service unavailable")

# 输出格式: [12:34:56] [MyService] 消息内容
```

### 调试工具集成

#### HTTPDebugger

```python
from df_test_framework.testing.debug import enable_http_debug

# 开启 HTTP 调试（自动集成 ObservabilityLogger）
enable_http_debug()

# 自动记录:
# - 所有 HTTP 请求/响应
# - 拦截器执行过程
# - 请求耗时统计
# - 慢请求提醒（可配置阈值）
```

#### DBDebugger

```python
from df_test_framework.testing.debug import enable_db_debug

# 开启数据库调试
enable_db_debug()

# 自动记录:
# - 所有 SQL 查询
# - 查询参数
# - 影响行数
# - 执行时间
# - 慢查询提醒
```

### 日志最佳实践

#### 1. 日志级别选择

```python
# DEBUG - 详细的调试信息（开发阶段）
logger.debug(f"Variable value: {value}")

# INFO - 正常流程信息（默认）
logger.info("User login successful")

# WARNING - 警告信息（可能的问题）
logger.warning("Cache miss, fetching from database")

# ERROR - 错误信息（需要处理）
logger.error("Database connection failed")

# CRITICAL - 严重错误（系统级别）
logger.critical("Service crashed")
```

#### 2. 结构化日志

```python
# ✅ 推荐：使用 extra 参数
logger.info("User action", extra={
    "user_id": 123,
    "action": "login",
    "ip": "192.168.1.1"
})

# ❌ 不推荐：字符串拼接
logger.info(f"User {user_id} performed {action} from {ip}")
```

#### 3. 异常日志

```python
# ✅ 推荐：记录完整堆栈
try:
    risky_operation()
except Exception as e:
    logger.exception("Operation failed")  # 自动包含堆栈跟踪

# ❌ 不推荐：只记录异常消息
try:
    risky_operation()
except Exception as e:
    logger.error(f"Error: {e}")  # 丢失堆栈信息
```

#### 4. 性能敏感场景

```python
# ✅ 推荐：使用日志级别检查
if logger.level("DEBUG").no >= logger.level("INFO").no:
    logger.debug(f"Expensive computation: {expensive_call()}")

# ❌ 不推荐：总是计算
logger.debug(f"Expensive computation: {expensive_call()}")  # 即使DEBUG禁用也会执行
```

#### 5. 测试环境日志控制

```python
# conftest.py
import pytest

@pytest.fixture(autouse=True)
def configure_test_logging():
    """测试环境日志配置"""
    # 测试期间降低日志级别（减少噪音）
    from loguru import logger
    logger.remove()
    logger.add(sys.stderr, level="WARNING")  # 只显示警告和错误

    yield

    # 恢复默认配置
    logger.remove()
    logger.add(sys.stderr, level="INFO")
```

---

## 目录结构约定

```
src/df_test_framework/
├── common/              # 异常、类型（Layer 0）
├── clients/             # HTTP/REST 客户端
│   └── http/rest/httpx/ # HttpClient + AsyncHttpClient
├── drivers/             # Playwright/Selenium
├── databases/           # Database + Redis + Repository + UnitOfWork
├── messengers/          # Kafka + RabbitMQ + RocketMQ
├── storages/            # 预留（S3/MinIO）
├── engines/             # 预留（Spark/Flink）
├── infrastructure/      # Bootstrap、配置、日志、Provider、Runtime
│   ├── bootstrap/       # Bootstrap 管线
│   ├── config/          # Settings + ConfigSource
│   ├── logging/         # Loguru 策略
│   ├── providers/       # Provider 基类
│   ├── runtime/         # RuntimeContext
│   ├── tracing/         # OpenTelemetry 分布式追踪
│   └── metrics/         # Prometheus 指标监控
├── testing/             # Fixtures、数据工具、调试器、插件
│   ├── fixtures/        # pytest fixtures
│   ├── data/            # Factories + Loaders + Assertions
│   ├── debug/           # HTTPDebugger + DBDebugger
│   └── plugins/         # Allure + 环境标记
├── extensions/          # Pluggy 扩展系统
│   └── builtin/         # 内置扩展（性能追踪、慢查询监控）
└── cli/                 # CLI 工具 + 脚手架模板

tests/                   # 镜像 src/ 结构
├── clients/
├── databases/
├── test_messengers/     # 需要外部服务（可排除）
├── unit/                # 单元测试
└── conftest.py
```

---

## 测试编写规范

### AAA 模式

```python
def test_example(http_client):
    """测试示例"""
    # Arrange - 准备测试数据
    user_data = {"name": "Alice", "email": "alice@example.com"}

    # Act - 执行操作
    response = http_client.post("/users", json=user_data)

    # Assert - 验证结果
    assert response.status_code == 201
    assert response.json()["name"] == "Alice"
```

### 测试命名

```python
# ✅ 清晰描述场景
def test_login_with_valid_credentials_returns_token(self):
    """测试使用有效凭证登录返回token"""
    pass

# ❌ 不清晰
def test_login(self):
    pass
```

### Fixtures 使用

```python
@pytest.fixture
def user_factory():
    """用户工厂 fixture"""
    return UserFactory()

def test_create_user(user_factory):
    user = user_factory.build(role="admin")
    assert user["role"] == "admin"
```

### 参数化测试

```python
@pytest.mark.parametrize("input,expected", [
    ("my-test-project", "my_test_project"),
    ("UserLogin", "user_login"),
    ("HTTPClient", "http_client"),
])
def test_to_snake_case(input, expected):
    assert to_snake_case(input) == expected
```

### Mock 外部依赖

```python
@patch('df_test_framework.clients.http.httpx.Client')
def test_http_request_with_mock(mock_client):
    mock_response = Mock()
    mock_response.status_code = 200
    mock_client.return_value.get.return_value = mock_response

    client = HTTPClient()
    response = client.get("/users")

    assert response.status_code == 200
    mock_client.return_value.get.assert_called_once()
```

---

## 代码质量要求

### 覆盖率

- **目标**: ≥80% (配置在 `pyproject.toml`)
- **排除**: `__init__.py`, `conftest.py`, 测试文件本身
- **验证**: PR 提交前确保覆盖率不低于当前水平

### Ruff 配置

```toml
[tool.ruff]
line-length = 100
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W", "UP"]
ignore = ["E501", "N818"]
```

### 类型注解

- 使用现代 Python 类型注解（PEP 585 + PEP 604）
- `list[T]` 而非 `typing.List[T]`
- `T | None` 而非 `typing.Optional[T]`
- `type[T]` 而非 `typing.Type[T]`

---

## 框架需求开发完整流程

### 从需求到发布的7个阶段

本章节描述框架开发的完整工作流程，确保代码质量、文档完整、测试覆盖。

---

### 📋 阶段 1: 需求分析与规划

#### 1.1 需求理解

```bash
# 1. 确定需求类型
- feat: 新功能（如 AsyncHttpClient、OpenTelemetry）
- fix: Bug修复
- perf: 性能优化
- refactor: 代码重构

# 2. 明确优先级（基于 Phase 规划）
- P1: 核心功能增强
- P2: 可观测性增强
- P3: 开发体验提升
```

#### 1.2 技术方案设计（复杂需求推荐）

创建技术方案文档，明确架构、API、实现计划。

#### 1.3 创建 Todo 列表

使用 TodoWrite 工具规划任务，跟踪进度。

---

### 💻 阶段 2: 代码实现

#### 2.1 创建分支

```bash
# 分支命名规范
git checkout -b feature/P2.1-opentelemetry-tracing  # 新功能
git checkout -b fix/http-client-timeout             # Bug修复
```

#### 2.2 目录结构规划

遵循**五层架构**：

```bash
# 示例：新增追踪功能 (Layer 2 - 基础设施层)
src/df_test_framework/infrastructure/tracing/
├── __init__.py
├── manager.py      # TracingManager
├── config.py       # TracingConfig
├── decorators.py   # 装饰器
└── context.py      # 上下文传播

tests/unit/infrastructure/tracing/
├── test_manager.py
└── test_decorators.py
```

#### 2.3 代码实现要点

**类型注解**（现代 Python）:
```python
# ✅ 推荐
def create_span(name: str, attrs: dict[str, str] | None = None) -> Span:
    pass

# ❌ 避免旧式
from typing import Dict, Optional
def create_span(name: str, attrs: Optional[Dict[str, str]] = None) -> Span:
    pass
```

**配置管理**（Pydantic v2）:
```python
from pydantic import BaseModel, Field

class TracingConfig(BaseModel):
    enabled: bool = Field(default=True, description="是否启用追踪")
    service_name: str = Field(..., description="服务名称")
```

**错误处理**（统一异常）:
```python
from df_test_framework.common.exceptions import ConfigurationError

if not config.service_name:
    raise ConfigurationError("service_name is required")
```

#### 2.4 增量测试

```bash
# 边写边测试（推荐）
uv run pytest tests/unit/infrastructure/tracing/ -v
```

---

### ✅ 阶段 3: 测试验证

#### 3.1 单元测试（覆盖率 ≥80%）

```bash
# 运行测试并生成覆盖率报告
uv run pytest tests/unit/infrastructure/tracing/ \
    --cov=src/df_test_framework/infrastructure/tracing \
    --cov-report=term-missing \
    -v
```

**测试编写规范**:
```python
"""测试 TracingManager - 追踪管理器

测试覆盖:
- 初始化与配置
- Span 创建与管理
- 异常处理
"""

class TestTracingManager:
    @pytest.fixture
    def manager(self):
        config = TracingConfig(service_name="test")
        return TracingManager(config)

    def test_create_span_success(self, manager):
        """测试成功创建 Span"""
        # Arrange
        span_name = "test-operation"

        # Act
        span = manager.create_span(span_name)

        # Assert
        assert span.name == span_name
        assert span.is_recording()
```

#### 3.2 代码质量检查

```bash
# 1. Ruff 代码检查 + 自动修复
uv run ruff check --fix src/ tests/

# 2. 格式化
uv run ruff format src/ tests/

# 3. 类型检查（可选）
uv run mypy src/df_test_framework/infrastructure/tracing/

# 4. 安全扫描（推荐）
bash scripts/security-scan.sh  # Linux/Mac
```

---

### 📖 阶段 4: 文档编写

#### 4.1 文档类型

| 文档类型 | 路径 | 必需性 | 字数 |
|---------|------|--------|------|
| **使用指南** | `docs/guides/<feature>.md` | ✅ 必需 | 500-1000行 |
| **版本发布说明** | `docs/releases/v<version>.md` | ✅ 必需 | 详细完整 |
| **CHANGELOG** | `CHANGELOG.md` | ✅ 必需 | 简洁摘要 |
| **API 参考** | `docs/api-reference/<module>.md` | 可选 | - |

#### 4.2 CHANGELOG.md 更新规范

**格式**：简洁版本摘要 + 完整文档链接

```markdown
## [3.10.0] - 2025-11-26

### OpenTelemetry 分布式追踪

**核心特性**: 基于 OpenTelemetry 标准的分布式追踪能力。

**主要功能**:
- TracingManager 追踪管理器
- @trace_span/@trace_async_span 装饰器
- HTTP/数据库追踪集成
- 多导出器支持 (Console/OTLP/Jaeger/Zipkin)

**详细内容**: 查看完整发布说明 [v3.10.0](docs/releases/v3.10.0.md)

### 文档
- 新增 `docs/guides/distributed_tracing.md` - 分布式追踪使用指南
- 新增 `docs/releases/v3.10.0.md` - 完整版本发布说明

### 测试覆盖
- 70个新增测试用例，全部通过
- 覆盖率 95%+
```

#### 4.3 版本发布文档规范

**路径**: `docs/releases/v<version>.md`

**结构**:
```markdown
# DF Test Framework v3.10.0 Release Notes

发布日期: 2025-11-26

---

## 🎉 重大更新

### 📊 OpenTelemetry 分布式追踪（核心特性）

[详细功能说明 + 代码示例]

---

## 🚀 核心功能

### 1. TracingManager

[详细说明 + 代码示例]

---

## 📊 技术细节

[架构设计、性能测试]

---

## 🔄 迁移指南

[升级步骤]

---

## 📖 完整示例

[综合示例]
```

---

### 📝 阶段 5: Commit 与 PR

#### 5.1 Commit Message 规范

**格式**: `<type>(<scope>): <subject>`

**Type**:
- `feat`: 新功能
- `fix`: Bug 修复
- `docs`: 文档更新
- `test`: 测试相关
- `refactor`: 代码重构
- `perf`: 性能优化
- `chore`: 构建/工具链
- `ci`: CI/CD 配置
- `style`: 代码风格

**Scope**（推荐使用 Phase 编号）:
- `P2.1`: Phase 2.1 任务
- `http`: HTTP 客户端相关
- `v3.9.0`: 版本相关

**Subject**:
- 中文描述（项目约定）
- 简洁明了（50字以内）

**Body**（详细说明）:
```
新增功能:
1. 功能点 1
   - 详细说明
2. 功能点 2

新增文件:
- src/...
- tests/...
- docs/...

测试:
- XX个单元测试，全部通过
- 覆盖率 XX%

文档更新:
- CHANGELOG.md: 简洁版本摘要
- docs/releases/vX.X.X.md: 详细版本说明

代码统计:
- 代码: +XXX行
- 测试: +XXX行
- 文档: +XXX行

技术亮点:
- 亮点 1
- 亮点 2

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

**完整示例**:
```bash
feat(P2.1): OpenTelemetry 分布式追踪 - 完整实现

新增功能:
1. TracingManager 核心追踪管理器
   - TracingConfig 配置类
   - TracerProvider 生命周期管理

2. 追踪装饰器
   - @trace_span() - 同步函数追踪
   - @trace_async_span() - 异步函数追踪

测试覆盖:
- 70个单元测试，全部通过
- 覆盖率 95%+

文档:
- docs/guides/distributed_tracing.md (~500行)
- docs/releases/v3.10.0.md

代码统计:
- 代码: +700行
- 测试: +300行
- 文档: +500行

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

#### 5.2 提交前检查清单

```bash
# ✅ 所有测试通过
uv run pytest -v

# ✅ 代码覆盖率 ≥80%
uv run pytest --cov=src/df_test_framework --cov-report=term

# ✅ 代码风格检查通过
uv run ruff check src/ tests/

# ✅ 代码已格式化
uv run ruff format src/ tests/

# ✅ 文档已更新
- [ ] CHANGELOG.md
- [ ] docs/releases/vX.X.X.md
- [ ] docs/guides/<feature>.md

# ✅ Commit message 规范
- [ ] 格式正确
- [ ] 包含 Co-Authored-By
```

#### 5.3 创建 Pull Request

**PR 标题**:
```
feat(P2.1): OpenTelemetry 分布式追踪 - 完整实现
```

**PR 描述模板**:
```markdown
## 📝 变更说明

### 功能概述
[简要描述]

### 关键变更
- 新增 TracingManager
- 实现追踪装饰器

### 测试覆盖
- ✅ 70个单元测试，全部通过
- ✅ 覆盖率 95%+

### 文档更新
- ✅ docs/guides/distributed_tracing.md
- ✅ CHANGELOG.md

---

## 📊 检查清单

- [x] 所有测试通过
- [x] 覆盖率 ≥80%
- [x] 文档已更新
```

---

### 🔍 阶段 6: 代码审查与合并

#### 6.1 代码审查要点

**审查者检查**:
1. ✅ 代码质量
   - 是否遵循框架架构？
   - 错误处理是否完善？

2. ✅ 测试覆盖
   - 是否覆盖核心功能？
   - 是否覆盖边界条件？

3. ✅ 文档完整性
   - 使用指南是否详细？
   - 示例代码是否可运行？

4. ✅ 向后兼容
   - 是否破坏现有 API？

#### 6.2 合并策略

```bash
# 1. 确保分支最新
git fetch origin
git rebase origin/main

# 2. 解决冲突（如有）
git add .
git rebase --continue

# 3. 合并到主分支（维护者操作）
```

---

### 🚀 阶段 7: 发布管理

#### 7.1 版本号规则（语义化版本）

- `MAJOR.MINOR.PATCH`（如 `3.10.0`）
- `MAJOR`: 不兼容的 API 变更
- `MINOR`: 向后兼容的新功能
- `PATCH`: 向后兼容的 Bug 修复

#### 7.2 创建版本标签

```bash
# 1. 确保所有变更已合并
git checkout main
git pull

# 2. 创建标签
git tag -a v3.10.0 -m "Release v3.10.0: OpenTelemetry 分布式追踪"

# 3. 推送标签（触发 CI/CD 自动发布）
git push origin v3.10.0
```

#### 7.3 发布检查清单

```bash
# ✅ 版本号更新
- [ ] pyproject.toml - version = "3.10.0"
- [ ] __init__.py - __version__ = "3.10.0"

# ✅ 文档完整
- [ ] CHANGELOG.md 已更新
- [ ] docs/releases/v3.10.0.md 已创建
- [ ] README.md 版本号已更新

# ✅ 测试通过
- [ ] 所有单元测试通过
- [ ] CI/CD 通过
```

---

## Git 工作流

```bash
# 创建特性分支
git checkout -b feature/awesome-feature

# 开发 + 测试
uv run pytest -v
uv run ruff check src/ tests/
uv run mypy src/

# 提交代码
git add .
git commit -m "feat: 添加新功能"
git push origin feature/awesome-feature

# 创建 PR
# - 清晰的标题和描述
# - 说明变更内容和影响范围
# - 确保 CI 检查通过
```

---

## 常见任务

### 添加新的客户端

1. 在 `clients/` 或 `drivers/` 或 `messengers/` 创建目录
2. 实现客户端类（继承适当的基类）
3. 在 `infrastructure/providers/` 注册 Provider
4. 在 `testing/fixtures/` 添加 fixture
5. 编写单元测试（覆盖率 ≥80%）
6. 更新文档（API 参考 + 使用指南）

### 添加新的扩展

1. 在 `extensions/builtin/` 创建扩展类
2. 实现 Hook（`@hookimpl`）
3. 在 `extensions/__init__.py` 注册
4. 编写测试（验证 Hook 执行）
5. 更新文档（扩展系统指南）

### 添加新的 CLI 命令

1. 在 `cli/commands/` 添加命令函数
2. 在 `cli/main.py` 注册 subparser
3. 更新模板（如需要，在 `cli/templates/`）
4. 编写集成测试（`tests/cli/`）
5. 更新文档（CLI 指南）

---

## 性能优化策略

1. **延迟初始化**: Provider 按需创建实例
2. **连接池**: 数据库和 Redis 使用连接池
3. **配置缓存**: Settings 和资源实例缓存
4. **异步支持**: AsyncHttpClient 并发请求（10-50倍提升）
5. **HTTP/2**: AsyncHttpClient 支持 HTTP/2 协议

---

## 线程安全

- **ProviderRegistry**: 线程安全的单例管理（双重检查锁）
- **Database 连接池**: SQLAlchemy 管理
- **Redis 连接池**: redis-py 管理
- **HttpClient**: httpx 原生支持

---

## 重要提示

### 预留目录（未实现）

以下模块仅有目录占位符，**暂未实现**:
- `storages/` - 对象存储（S3、MinIO）
- `engines/` - 计算引擎（Spark、Flink）

### 外部服务测试

`tests/test_messengers/` 需要外部服务（Kafka/RabbitMQ/RocketMQ）:
```bash
# 排除这些测试
uv run pytest -v --ignore=tests/test_messengers/
```

### Windows 平台

- CLI 已修复 UTF-8 编码问题（`sys.stdout.reconfigure(encoding="utf-8")`）
- 使用 `start` 而非 `open` 打开 HTML 报告

---

## 参考文档

### 核心文档
- **架构总览**: `docs/architecture/overview.md`
- **快速开始**: `docs/user-guide/QUICK_START_V3.5.md`
- **用户手册**: `docs/user-guide/USER_MANUAL.md`
- **贡献指南**: `CONTRIBUTING.md`

### 功能指南
- **AsyncHttpClient**: `docs/guides/async_http_client.md`
- **消息队列**: `docs/guides/message_queue.md`
- **测试数据**: `docs/guides/test_data.md`
- **代码生成**: `docs/user-guide/code-generation.md`

### 版本历史
- **发布说明**: `docs/releases/`
- **更新日志**: `CHANGELOG.md`
- **迁移指南**: `docs/migration/`

---

## 设计原则

1. **语义驱动**: 按交互模式（HTTP、数据库、UI）组织代码，而非按技术栈
2. **解耦与可扩展**: Bootstrap + ProviderRegistry + Pluggy Hook
3. **类型安全**: Pydantic v2 配置 + 完整类型注解
4. **可观测性**: 结构化日志、HTTP/DB 调试器、性能监控
5. **零配置**: 预置工厂、Fixtures 自动注入、声明式配置

---

## 常见问题排查

### 测试失败

```bash
# 查看详细日志
uv run pytest -v --tb=long

# 单独运行失败的测试
uv run pytest tests/path/to/test.py::test_function -v

# 开启调试
uv run pytest --pdb
```

### 覆盖率不足

```bash
# 查看未覆盖的行
uv run pytest --cov=src/df_test_framework --cov-report=term-missing

# 生成 HTML 详细报告
uv run pytest --cov=src/df_test_framework --cov-report=html
```

### 类型检查错误

```bash
# 检查特定模块
uv run mypy src/df_test_framework/clients/

# 忽略第三方库错误
# 在 pyproject.toml 添加: [[tool.mypy.overrides]]
```

---

**返回**: [README.md](README.md) | [文档首页](docs/README.md)
