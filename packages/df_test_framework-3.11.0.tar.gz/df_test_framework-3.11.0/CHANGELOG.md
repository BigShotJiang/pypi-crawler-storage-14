# Changelog

本文档记录df-test-framework的所有重要变更。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/),
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [3.11.0] - 2025-11-26

### Phase 2 完整交付 (P2.5-P2.8)

**核心特性**: 协议扩展 + Mock 工具增强 + 测试覆盖率提升

**主要功能**:
- ✨ GraphQL 客户端 (P2.5) - 支持 Query/Mutation/Subscription、QueryBuilder、批量操作、文件上传
- ✨ gRPC 客户端 (P2.6) - 支持所有 RPC 模式、拦截器、健康检查
- ✨ DatabaseMocker (P2.7) - 数据库操作 Mock，SQL 标准化、调用历史
- ✨ RedisMocker (P2.7) - Redis 操作 Mock，支持 fakeredis 或简单内存实现
- ✅ 新增 104+ 个单元测试 (P2.8)
- ✅ 测试总数达到 1078 个，通过率 98.9%

**详细内容**: 查看完整发布说明 [v3.11.0](docs/releases/v3.11.0.md)

### 新增

#### GraphQL 客户端
- 新增 `GraphQLClient` - 基于 httpx 的 GraphQL 客户端
- 新增 `QueryBuilder` - 流畅的 GraphQL 查询构建器
- 新增 `GraphQLRequest/Response/Error` 数据模型
- 支持批量查询、文件上传

#### gRPC 客户端
- 新增 `GrpcClient` - 通用 gRPC 客户端
- 新增 `LoggingInterceptor/MetadataInterceptor/RetryInterceptor/TimingInterceptor` 拦截器
- 新增 `GrpcResponse[T]/GrpcError/GrpcStatusCode` 数据模型
- 新增 `ChannelOptions` 通道配置
- 支持所有 RPC 调用模式（Unary/Server Streaming/Client Streaming/Bidirectional）

#### Mock 工具增强
- 新增 `DatabaseMocker` - 数据库操作 Mock 工具
- 新增 `RedisMocker` - Redis 操作 Mock 工具
- RedisMocker 支持 fakeredis 或降级到简单内存实现
- DatabaseMocker 支持 SQL 标准化、调用历史、断言辅助

### 测试
- 新增 GraphQL 客户端测试：37 个（全部通过）
- 新增 gRPC 客户端测试：39 个通过，1 个跳过
- 新增 Mock 工具测试：28 个通过，1 个跳过
- 总测试数：1078 个
- 测试通过率：98.9% (1036/1047)
- 测试覆盖率：57.02%

### 文档
- 新增 `docs/releases/v3.11.0.md` - 完整版本发布说明
- 更新 `CHANGELOG.md` - Phase 2 完整摘要

---

## [3.10.0] - 2025-11-26

### 存储客户端 - LocalFile + S3 + 阿里云OSS

**核心特性**: 统一的文件存储抽象，支持本地文件、AWS S3、阿里云OSS三种存储方式。

**主要功能**:
- LocalFileClient - 本地文件系统存储，支持元数据、路径安全验证
- S3Client - 基于 boto3 的 AWS S3 对象存储，支持 MinIO
- OSSClient - 基于 oss2 的阿里云 OSS 对象存储，支持 STS、CRC64、内网访问
- 统一的 CRUD API（upload/download/delete/list/copy）
- 分片上传支持（大文件自动分片）
- 预签名 URL 生成
- 完整的 pytest fixtures（local_file_client、s3_client、oss_client）

**详细内容**: 查看完整使用指南 [storage.md](docs/guides/storage.md)

### 测试覆盖
- 75个单元测试，全部通过
- LocalFileClient 测试覆盖率 95%+
- S3Client 测试覆盖率 95%+
- OSSClient 测试覆盖率 95%+

### OpenTelemetry 分布式追踪

**核心特性**: 基于 OpenTelemetry 标准的分布式追踪能力，支持 Console/OTLP/Jaeger/Zipkin 导出器。

**主要功能**:
- TracingManager 追踪管理器，支持多导出器配置
- @trace_span/@trace_async_span/@TraceClass 装饰器，零侵入式追踪
- TracingContext 和 Baggage 上下文传播机制
- HTTP 请求追踪拦截器，自动记录请求链路
- 数据库查询追踪集成，记录 SQL 执行详情
- 70个单元测试，覆盖率 95%+

**详细内容**: 查看完整发布说明 [v3.10.0](docs/releases/v3.10.0.md)

### 测试数据工具增强

**核心特性**: 数据加载器和响应断言辅助，提升测试数据处理效率。

**主要功能**:
- JSONLoader/CSVLoader/YAMLLoader 三种数据加载器
- 支持 JSONPath 查询、类型转换、环境变量替换
- ResponseAssertions 响应断言辅助（链式调用 + 静态方法）
- 支持状态码、JSON、响应头、响应时间断言
- pytest 参数化支持

**预置工厂说明**:
- UserFactory/OrderFactory 等 8 个预置工厂已标记为 **示例代码**
- 这些工厂是业务领域特定的，不同项目字段差异大
- **建议**: 项目根据自身需求继承 Factory 基类自定义工厂
- Factory 基类提供 Sequence、LazyAttribute、FakerAttribute 等通用能力

**详细内容**: 查看完整发布说明 [v3.10.0](docs/releases/v3.10.0.md)

### Prometheus 指标监控

**核心特性**: 基于 Prometheus 的应用性能监控（APM），零配置模式。

**主要功能**:
- MetricsManager 指标管理器，支持 Prometheus exporter 和 Pushgateway
- Counter/Gauge/Histogram/Summary 四种指标类型，线程安全
- @count_calls/@time_calls/@track_in_progress 等 6 个装饰器
- HttpMetrics 自动收集 HTTP 请求指标
- DatabaseMetrics 自动收集数据库查询指标
- 零配置模式（无需安装 prometheus_client 即可使用）
- 44个单元测试，全部通过

**详细内容**: 查看完整发布说明 [v3.10.0](docs/releases/v3.10.0.md)

### 文档
- 新增 `docs/guides/storage.md` - 存储客户端完整使用指南
- 新增 `docs/guides/distributed_tracing.md` - 分布式追踪完整使用指南
- 新增 `docs/guides/test_data.md` - 测试数据工具完整使用指南
- 新增 `docs/guides/prometheus_metrics.md` - Prometheus 监控完整使用指南
- 新增 `docs/releases/v3.10.0.md` - 完整版本发布说明
- 新增 `examples/01-basic/storage_usage.py` - 存储客户端使用示例

### 测试覆盖
- 257个新增测试用例，全部通过
- 存储模块: 75个测试，覆盖率 95%+
- 追踪模块: 70个测试，覆盖率 95%+
- 测试数据: 68个测试，覆盖率 90%+
- 指标模块: 44个测试，覆盖率 92%+

---

## [3.9.0] - 2025-01-25

### 消息队列客户端 - Kafka + RabbitMQ + RocketMQ

**核心特性**: 提供三大主流消息队列的统一封装,支持企业级测试场景。

**主要功能**:
- Kafka客户端 (confluent-kafka 1.9.2)，生产性能提升3倍
- RabbitMQ客户端 (pika, AMQP 0-9-1)，支持延迟队列和死信队列
- RocketMQ客户端，支持顺序消息和事务消息
- SSL/TLS 支持，完整的证书认证和 SASL 认证
- 统一的 API 设计，便于切换不同消息队列

**详细内容**: 查看完整发布说明 [v3.9.0](docs/releases/v3.9.0.md)

### 测试覆盖
- 68个单元测试和集成测试
- Kafka测试覆盖率 96.32%
- RabbitMQ测试覆盖率 94.85%
- RocketMQ测试覆盖率 91.47%

---

## [3.8.0] - 2025-11-25

### AsyncHttpClient - 异步HTTP客户端

**核心特性**: 基于 httpx.AsyncClient 实现的异步HTTP客户端，性能提升 10-50 倍。

**主要功能**:
- 并发性能提升 40 倍 (100个请求从 20秒 降至 0.5秒)
- 内存占用降低 90%，CPU占用降低 75%
- 默认启用 HTTP/2 支持，连接复用
- 完全兼容现有拦截器，无需修改
- 适用场景: 批量操作、压力测试、微服务调用、数据迁移

**详细内容**: 查看完整发布说明 [v3.8.0](docs/releases/v3.8.0.md)

### 修复
- 更新 CLI 生成模板的版本引用 (v3.7 → v3.8)
- 重构 Repository 测试从 MockDatabase 到 MockSession

### 依赖变更
- 新增 pytest-asyncio>=1.3.0 (异步测试支持)

---

## [3.7.0] - 2025-11-24

### Unit of Work 模式 - 现代化数据访问架构

**核心特性**: 统一管理事务边界和 Repository 生命周期，解决 v3.6.2 事务隔离失效问题。

**主要功能**:
- 新增 BaseUnitOfWork 类，支持 Repository 懒加载和缓存
- 新增 uow fixture，替代 db_transaction，确保所有操作在同一事务中
- 所有 Repository 共享同一个 Session，事务隔离正确
- 新增熔断器 (Circuit Breaker) 模块，防止级联失败
- 新增安全最佳实践指南 (8000+字)
- 集成 CI/CD 依赖漏洞扫描 (Safety/Bandit/pip-audit)

**详细内容**: 查看完整发布说明 [v3.7.0](docs/releases/v3.7.0.md)

### 测试覆盖
- 19个 UnitOfWork 单元测试，覆盖率 94.52%
- 26个熔断器单元测试，覆盖率 98.40%

---

## [3.6.2] - 2025-11-24

### 测试数据清理控制机制

**核心特性**: 增强 db_transaction fixture 的数据清理控制，提供灵活的清理策略。

**主要功能**:
- 默认强制回滚，确保测试数据不残留
- 支持三种控制方式：命令行参数、测试标记、环境变量
- 移除 TransactionalDatabase 包装器，直接返回 SQLAlchemy Session
- 新增框架架构说明文档

**详细内容**: 查看完整发布说明 [v3.6.2](docs/releases/v3.6.2.md)

### 测试
- 17个集成测试，覆盖所有数据清理场景

---

## [3.6.1] - 2025-11-23

### 日志系统修复 + Loguru/Pytest 深度集成

**核心特性**: 修复日志传播导致的重复输出问题，增强 Loguru 和 pytest 集成。

**主要功能**:
- 修复日志传播链导致的重复输出问题
- 新增 LoguruHandler 集成 Loguru 到 Python logging
- 新增 LoguruPytestHandler 集成到 pytest 日志系统
- 新增 pytest_configure_logging hook 自动配置

**详细内容**: 查看完整发布说明 [v3.6.1](docs/releases/v3.6.1.md)

### 测试
- 26个日志系统单元测试

---

## [3.6.0] - 2025-11-22

### Decimal 零配置序列化 + HttpClient Pydantic 支持

**核心特性**: Decimal 类型的 JSON 序列化零配置支持，HttpClient 增强 Pydantic 集成。

**主要功能**:
- 全局 Decimal JSON 编码器，自动转换为字符串
- HttpClient 原生支持 Pydantic 模型序列化/反序列化
- 新增 DecimalJSONEncoder 和 DecimalJSONProvider (Flask扩展)
- 修复 LogConfig 死循环问题

**详细内容**: 查看完整发布说明 [v3.6.0](docs/releases/v3.6.0.md)

### 测试
- 22个单元测试，全部通过

---

## [3.5.0] - 2025-11-21

### 核心特性
- Repository基类：基础的CRUD能力
- 查询构建器：支持链式调用和复杂查询
- 数据库工厂：自动管理Session生命周期
- 事务支持：上下文管理器模式
- SQLAlchemy 2.0 原生支持

### 依赖变更
- SQLAlchemy >= 2.0.0

---

## [3.4.0] - 2025-11-20

### 核心特性
- HttpClient：统一的HTTP客户端接口
- 拦截器链：支持请求/响应拦截
- 重试机制：指数退避 + 抖动
- Mock支持：MockHttpClient 测试辅助

### 依赖变更
- httpx >= 0.27.0
- tenacity >= 8.5.0

---

## [3.3.0] - 2025-11-19

### 核心特性
- Factory模式：测试数据生成
- Faker集成：真实感测试数据
- 序列和懒加载：灵活的数据生成

### 依赖变更
- Faker >= 30.8.2

---

## [3.2.0] - 2025-11-18

### 核心特性
- 日志系统：LogConfig配置化管理
- Loguru集成：更优雅的日志输出
- 多输出支持：控制台、文件、JSON、Syslog

### 依赖变更
- loguru >= 0.7.3

---

## [3.1.0] - 2025-11-17

### 核心特性
- BaseModel：统一的数据模型基类
- 配置系统：环境变量管理
- 验证器：Pydantic集成

### 依赖变更
- pydantic >= 2.10.3
- pydantic-settings >= 2.7.0

---

## [3.0.0] - 2025-11-16

### 重大变更
- 项目重构：模块化架构
- Python 3.12+：现代化类型注解
- pytest 8.0+：最新测试框架

### 核心特性
- clients/：HTTP、数据库客户端
- infrastructure/：基础设施层
- testing/：测试工具集

---

## [2.x.x] - Legacy 版本

早期版本的变更记录已归档。详见: [CHANGELOG_V2.md](CHANGELOG_V2.md)
