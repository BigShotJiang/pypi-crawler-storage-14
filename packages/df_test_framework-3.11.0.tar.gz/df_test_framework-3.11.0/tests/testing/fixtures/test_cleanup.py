"""测试 cleanup.py - 测试数据清理fixtures

测试覆盖:
- BaseTestDataCleaner基类
- GenericTestDataCleaner通用清理器
- 资源注册和清理机制
"""

from unittest.mock import Mock

import pytest

from df_test_framework.testing.fixtures.cleanup import (
    BaseTestDataCleaner,
    GenericTestDataCleaner,
)


class ConcreteTestDataCleaner(BaseTestDataCleaner):
    """BaseTestDataCleaner的具体实现，用于测试"""

    def __init__(self, db):
        super().__init__(db)
        self.cleanup_called = False
        self.cleanup_count = 0

    def cleanup(self):
        """记录cleanup被调用"""
        self.cleanup_called = True
        self.cleanup_count += 1


class TestBaseTestDataCleaner:
    """测试BaseTestDataCleaner基类"""

    @pytest.fixture
    def mock_db(self):
        """Mock数据库对象"""
        return Mock()

    @pytest.fixture
    def cleaner(self, mock_db):
        """测试用cleaner实例"""
        return ConcreteTestDataCleaner(mock_db)

    def test_init(self, mock_db):
        """测试初始化"""
        cleaner = ConcreteTestDataCleaner(mock_db)
        assert cleaner.db == mock_db
        assert cleaner.resources == {}

    def test_register_single_resource(self, cleaner):
        """测试注册单个资源"""
        cleaner.register("card_nos", "CARD001")
        assert "card_nos" in cleaner.resources
        assert cleaner.resources["card_nos"] == ["CARD001"]

    def test_register_multiple_resources_same_type(self, cleaner):
        """测试注册多个同类型资源"""
        cleaner.register("card_nos", "CARD001")
        cleaner.register("card_nos", "CARD002")
        cleaner.register("card_nos", "CARD003")
        assert len(cleaner.resources["card_nos"]) == 3
        assert "CARD001" in cleaner.resources["card_nos"]
        assert "CARD002" in cleaner.resources["card_nos"]
        assert "CARD003" in cleaner.resources["card_nos"]

    def test_register_different_resource_types(self, cleaner):
        """测试注册不同类型的资源"""
        cleaner.register("card_nos", "CARD001")
        cleaner.register("order_ids", "ORD001")
        cleaner.register("user_ids", "USER001")
        assert len(cleaner.resources) == 3
        assert cleaner.resources["card_nos"] == ["CARD001"]
        assert cleaner.resources["order_ids"] == ["ORD001"]
        assert cleaner.resources["user_ids"] == ["USER001"]

    def test_register_many(self, cleaner):
        """测试批量注册资源"""
        resource_ids = ["CARD001", "CARD002", "CARD003"]
        cleaner.register_many("card_nos", resource_ids)
        assert len(cleaner.resources["card_nos"]) == 3
        assert cleaner.resources["card_nos"] == resource_ids

    def test_register_many_empty_list(self, cleaner):
        """测试批量注册空列表"""
        cleaner.register_many("card_nos", [])
        assert cleaner.resources["card_nos"] == []

    def test_register_many_multiple_times(self, cleaner):
        """测试多次批量注册"""
        cleaner.register_many("card_nos", ["CARD001", "CARD002"])
        cleaner.register_many("card_nos", ["CARD003", "CARD004"])
        assert len(cleaner.resources["card_nos"]) == 4

    def test_get_resources_existing_type(self, cleaner):
        """测试获取已注册的资源"""
        cleaner.register("card_nos", "CARD001")
        cleaner.register("card_nos", "CARD002")
        result = cleaner.get_resources("card_nos")
        assert result == ["CARD001", "CARD002"]

    def test_get_resources_nonexistent_type(self, cleaner):
        """测试获取不存在的资源类型"""
        result = cleaner.get_resources("nonexistent")
        assert result == []

    def test_clear_resources_existing_type(self, cleaner):
        """测试清空已注册的资源"""
        cleaner.register("card_nos", "CARD001")
        cleaner.register("card_nos", "CARD002")
        cleaner.clear_resources("card_nos")
        assert cleaner.resources["card_nos"] == []

    def test_clear_resources_nonexistent_type(self, cleaner):
        """测试清空不存在的资源类型"""
        # 不应抛出异常
        cleaner.clear_resources("nonexistent")
        assert "nonexistent" not in cleaner.resources

    def test_cleanup_abstract_method_is_callable(self, cleaner):
        """测试cleanup方法可以被调用"""
        assert not cleaner.cleanup_called
        cleaner.cleanup()
        assert cleaner.cleanup_called


class TestGenericTestDataCleaner:
    """测试GenericTestDataCleaner通用清理器"""

    @pytest.fixture
    def mock_db(self):
        """Mock数据库对象"""
        return Mock()

    @pytest.fixture
    def cleaner(self, mock_db):
        """测试用cleaner实例"""
        return GenericTestDataCleaner(mock_db)

    def test_init(self, mock_db):
        """测试初始化"""
        cleaner = GenericTestDataCleaner(mock_db)
        assert cleaner.db == mock_db
        assert cleaner.resources == {}
        assert cleaner.cleanup_callbacks == {}

    def test_add_cleanup_callback(self, cleaner):
        """测试添加清理回调"""

        def mock_cleanup(ids):
            pass

        cleaner.add_cleanup_callback("cards", mock_cleanup)
        assert "cards" in cleaner.cleanup_callbacks
        assert cleaner.cleanup_callbacks["cards"] == mock_cleanup

    def test_cleanup_with_registered_callback(self, cleaner):
        """测试执行已注册回调的清理"""
        # 创建Mock回调
        mock_callback = Mock()
        cleaner.add_cleanup_callback("cards", mock_callback)

        # 注册资源
        cleaner.register("cards", "CARD001")
        cleaner.register("cards", "CARD002")

        # 执行清理
        cleaner.cleanup()

        # 验证回调被调用
        mock_callback.assert_called_once_with(["CARD001", "CARD002"])

    def test_cleanup_without_callback(self, cleaner):
        """测试没有注册回调时的清理"""
        # 注册资源但不注册回调
        cleaner.register("cards", "CARD001")

        # 执行清理（不应抛出异常）
        cleaner.cleanup()

    def test_cleanup_with_empty_resources(self, cleaner):
        """测试清理空资源列表"""
        mock_callback = Mock()
        cleaner.add_cleanup_callback("cards", mock_callback)

        # 注册空资源
        cleaner.register_many("cards", [])

        # 执行清理
        cleaner.cleanup()

        # 回调不应该被调用
        mock_callback.assert_not_called()

    def test_cleanup_with_callback_exception(self, cleaner):
        """测试回调抛出异常时的清理"""

        # 创建会抛出异常的回调
        def failing_callback(ids):
            raise ValueError("清理失败")

        cleaner.add_cleanup_callback("cards", failing_callback)
        cleaner.register("cards", "CARD001")

        # 执行清理不应抛出异常
        cleaner.cleanup()

    def test_cleanup_multiple_resource_types(self, cleaner):
        """测试清理多种类型的资源"""
        # 创建多个Mock回调
        cards_callback = Mock()
        orders_callback = Mock()
        users_callback = Mock()

        # 注册回调
        cleaner.add_cleanup_callback("cards", cards_callback)
        cleaner.add_cleanup_callback("orders", orders_callback)
        cleaner.add_cleanup_callback("users", users_callback)

        # 注册资源
        cleaner.register_many("cards", ["CARD001", "CARD002"])
        cleaner.register_many("orders", ["ORD001"])
        cleaner.register_many("users", ["USER001", "USER002", "USER003"])

        # 执行清理
        cleaner.cleanup()

        # 验证所有回调都被调用
        cards_callback.assert_called_once_with(["CARD001", "CARD002"])
        orders_callback.assert_called_once_with(["ORD001"])
        users_callback.assert_called_once_with(["USER001", "USER002", "USER003"])

    def test_cleanup_partial_failure(self, cleaner):
        """测试部分清理失败的情况"""
        # 第一个回调成功，第二个失败，第三个成功
        success_callback1 = Mock()
        failing_callback = Mock(side_effect=ValueError("清理失败"))
        success_callback2 = Mock()

        cleaner.add_cleanup_callback("type1", success_callback1)
        cleaner.add_cleanup_callback("type2", failing_callback)
        cleaner.add_cleanup_callback("type3", success_callback2)

        cleaner.register("type1", "ID1")
        cleaner.register("type2", "ID2")
        cleaner.register("type3", "ID3")

        # 执行清理
        cleaner.cleanup()

        # 验证成功的回调被调用
        success_callback1.assert_called_once()
        success_callback2.assert_called_once()
        # 失败的回调也被调用了但抛出异常
        failing_callback.assert_called_once()

    def test_cleanup_with_lambda_callback(self, cleaner):
        """测试使用lambda作为回调"""
        result = []

        cleaner.add_cleanup_callback("cards", lambda ids: result.extend(ids))
        cleaner.register_many("cards", ["CARD001", "CARD002"])

        cleaner.cleanup()

        assert result == ["CARD001", "CARD002"]


__all__ = [
    "TestBaseTestDataCleaner",
    "TestGenericTestDataCleaner",
]
