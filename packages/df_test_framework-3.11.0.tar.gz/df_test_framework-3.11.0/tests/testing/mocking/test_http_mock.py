"""HTTP Mock测试

测试HTTP Mock功能的完整性和正确性
"""

import pytest

from df_test_framework.clients.http.core import Request
from df_test_framework.testing.mocking import (
    HttpMocker,
    MockInterceptor,
    MockResponse,
)


class TestMockInterceptor:
    """测试MockInterceptor基础功能"""

    def test_simple_mock_rule(self):
        """测试简单的Mock规则"""
        interceptor = MockInterceptor()
        interceptor.add_rule(
            url="/api/users", method="GET", json_data={"users": [{"id": 1, "name": "Alice"}]}
        )

        request = Request(method="GET", url="/api/users")

        with pytest.raises(MockResponse) as exc_info:
            interceptor.before_request(request)

        mock_response = exc_info.value
        assert mock_response.response.status_code == 200
        assert mock_response.response.json_data == {"users": [{"id": 1, "name": "Alice"}]}

    def test_url_pattern_matching(self):
        """测试URL模式匹配"""
        import re

        interceptor = MockInterceptor()
        interceptor.add_rule(
            url=re.compile(r"/api/users/\d+"), method="GET", json_data={"id": 123, "name": "Bob"}
        )

        # 匹配成功
        request = Request(method="GET", url="/api/users/123")
        with pytest.raises(MockResponse):
            interceptor.before_request(request)

        # 匹配失败
        request = Request(method="GET", url="/api/users/abc")
        result = interceptor.before_request(request)
        assert result is None  # 不匹配，返回None

    def test_method_matching(self):
        """测试HTTP方法匹配"""
        interceptor = MockInterceptor()
        interceptor.add_rule(
            url="/api/users",
            method="POST",  # 只匹配POST
            status_code=201,
        )

        # POST匹配成功
        request = Request(method="POST", url="/api/users", json={"name": "Alice"})
        with pytest.raises(MockResponse) as exc_info:
            interceptor.before_request(request)
        assert exc_info.value.response.status_code == 201

        # GET不匹配
        request = Request(method="GET", url="/api/users")
        result = interceptor.before_request(request)
        assert result is None

    def test_times_limit(self):
        """测试times限制"""
        interceptor = MockInterceptor()
        interceptor.add_rule(
            url="/api/users",
            method="GET",
            json_data={"users": []},
            times=2,  # 只能匹配2次
        )

        request = Request(method="GET", url="/api/users")

        # 第1次：成功
        with pytest.raises(MockResponse):
            interceptor.before_request(request)

        # 第2次：成功
        with pytest.raises(MockResponse):
            interceptor.before_request(request)

        # 第3次：规则已被移除，不匹配
        result = interceptor.before_request(request)
        assert result is None

    def test_assert_called(self):
        """测试请求调用验证"""
        interceptor = MockInterceptor()
        interceptor.add_rule(url="/api/users", method="GET", json_data={})

        request = Request(method="GET", url="/api/users")

        # 调用2次
        with pytest.raises(MockResponse):
            interceptor.before_request(request)
        with pytest.raises(MockResponse):
            interceptor.before_request(request)

        # 验证调用次数
        interceptor.assert_called("/api/users", "GET", times=2)

        # 验证失败应抛出AssertionError
        with pytest.raises(AssertionError):
            interceptor.assert_called("/api/users", "GET", times=3)


class TestHttpMocker:
    """测试HttpMocker工具类"""

    def test_get_shortcut(self):
        """测试GET快捷方法"""
        from df_test_framework.clients.http.rest.httpx import HttpClient

        client = HttpClient(base_url="http://test.local")
        mocker = HttpMocker(client)

        mocker.get("/api/users", json={"users": []})

        response = client.get("/api/users")
        assert response.status_code == 200
        assert response.json() == {"users": []}

        mocker.assert_called("/api/users", "GET", times=1)
        mocker.reset()

    def test_post_shortcut(self):
        """测试POST快捷方法"""
        from df_test_framework.clients.http.rest.httpx import HttpClient

        client = HttpClient(base_url="http://test.local")
        mocker = HttpMocker(client)

        mocker.post("/api/users", status_code=201, json={"id": 1, "name": "Alice"})

        response = client.post("/api/users", json={"name": "Alice"})
        assert response.status_code == 201
        assert response.json() == {"id": 1, "name": "Alice"}

        mocker.reset()

    def test_method_chaining(self):
        """测试链式调用"""
        from df_test_framework.clients.http.rest.httpx import HttpClient

        client = HttpClient(base_url="http://test.local")
        mocker = HttpMocker(client)

        mocker.get("/api/users", json={"users": []}).post(
            "/api/users", status_code=201, json={"id": 1}
        ).delete("/api/users/1", status_code=204)

        assert client.get("/api/users").status_code == 200
        assert client.post("/api/users", json={"name": "Alice"}).status_code == 201
        assert client.delete("/api/users/1").status_code == 204

        mocker.reset()


def test_http_mock_fixture(http_mock, http_client):
    """测试http_mock fixture（集成测试）

    注意：此测试需要框架完整启动，如果运行失败请确保pytest配置正确
    """
    # Mock GET请求
    http_mock.get("/api/users", json={"users": [{"id": 1, "name": "Test User"}]})

    # 发送请求
    response = http_client.get("/api/users")

    # 验证Mock响应
    assert response.status_code == 200
    assert response.json() == {"users": [{"id": 1, "name": "Test User"}]}

    # 验证请求被调用
    http_mock.assert_called("/api/users", "GET", times=1)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
