"""测试 Redis Mock"""

import pytest

from df_test_framework.testing.mocking import FAKEREDIS_AVAILABLE, RedisMocker


class TestRedisMocker:
    """测试 RedisMocker"""

    def test_context_manager(self) -> None:
        """测试上下文管理器"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            assert redis_mock.mock_client is not None

    def test_simple_mock_get_set(self) -> None:
        """测试简单 Mock 的 GET/SET"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            redis_mock.mock_client.set("key", "value")
            result = redis_mock.mock_client.get("key")
            assert result == "value"

    def test_simple_mock_delete(self) -> None:
        """测试简单 Mock 的 DELETE"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            redis_mock.mock_client.set("key1", "value1")
            redis_mock.mock_client.set("key2", "value2")

            count = redis_mock.mock_client.delete("key1")
            assert count == 1
            assert redis_mock.mock_client.get("key1") is None
            assert redis_mock.mock_client.get("key2") == "value2"

    def test_simple_mock_exists(self) -> None:
        """测试简单 Mock 的 EXISTS"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            redis_mock.mock_client.set("key", "value")

            assert redis_mock.mock_client.exists("key") == 1
            assert redis_mock.mock_client.exists("nonexistent") == 0

    def test_simple_mock_keys(self) -> None:
        """测试简单 Mock 的 KEYS"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            redis_mock.mock_client.set("key1", "value1")
            redis_mock.mock_client.set("key2", "value2")

            keys = redis_mock.mock_client.keys()
            assert set(keys) == {"key1", "key2"}

    def test_simple_mock_hash_operations(self) -> None:
        """测试简单 Mock 的 Hash 操作"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            # HSET
            redis_mock.mock_client.hset("user:1", "name", "Alice")
            redis_mock.mock_client.hset("user:1", "age", "30")

            # HGET
            assert redis_mock.mock_client.hget("user:1", "name") == "Alice"

            # HGETALL
            user_data = redis_mock.mock_client.hgetall("user:1")
            assert user_data == {"name": "Alice", "age": "30"}

            # HDEL
            count = redis_mock.mock_client.hdel("user:1", "age")
            assert count == 1
            assert redis_mock.mock_client.hget("user:1", "age") is None

    def test_simple_mock_list_operations(self) -> None:
        """测试简单 Mock 的 List 操作"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            # RPUSH
            redis_mock.mock_client.rpush("queue", "item1", "item2")
            assert redis_mock.mock_client.llen("queue") == 2

            # LPUSH
            redis_mock.mock_client.lpush("queue", "item0")
            assert redis_mock.mock_client.llen("queue") == 3

            # LRANGE
            items = redis_mock.mock_client.lrange("queue", 0, -1)
            assert items == ["item0", "item1", "item2"]

            # LPOP
            item = redis_mock.mock_client.lpop("queue")
            assert item == "item0"

            # RPOP
            item = redis_mock.mock_client.rpop("queue")
            assert item == "item2"

    def test_simple_mock_set_operations(self) -> None:
        """测试简单 Mock 的 Set 操作"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            # SADD
            count = redis_mock.mock_client.sadd("tags", "python", "testing")
            assert count == 2

            # SMEMBERS
            members = redis_mock.mock_client.smembers("tags")
            assert members == {"python", "testing"}

            # SREM
            count = redis_mock.mock_client.srem("tags", "python")
            assert count == 1

            members = redis_mock.mock_client.smembers("tags")
            assert members == {"testing"}

    def test_reset(self) -> None:
        """测试重置"""
        with RedisMocker(use_fakeredis=False) as redis_mock:
            redis_mock.mock_client.set("key", "value")

            redis_mock.reset()

            assert redis_mock.mock_client.get("key") is None

    @pytest.mark.skipif(not FAKEREDIS_AVAILABLE, reason="fakeredis not installed")
    def test_fakeredis_integration(self) -> None:
        """测试 fakeredis 集成（如果可用）"""
        with RedisMocker(use_fakeredis=True) as redis_mock:
            redis_mock.mock_client.set("counter", 0)
            redis_mock.mock_client.incr("counter")
            redis_mock.mock_client.incr("counter")

            assert int(redis_mock.mock_client.get("counter")) == 2
