"""测试签名策略

验证签名生成和验证逻辑的正确性
"""

from df_test_framework.clients.http.interceptors.signature import (
    MD5SortedValuesStrategy,
    SHA256SortedValuesStrategy,
)


class TestMD5SortedValuesStrategy:
    """测试MD5签名策略"""

    def test_generate_signature_simple(self):
        """测试生成签名 - 简单参数"""
        strategy = MD5SortedValuesStrategy()
        params = {"userId": 1001, "orderId": "ORDER_001"}

        # 待签名字符串: "ORDER_001" + "1001" + "secret"
        signature = strategy.generate_signature(params, "secret")

        # 验证签名格式
        assert len(signature) == 32  # MD5固定32位
        assert signature.islower()  # 小写
        assert signature.isalnum()  # 只包含字母和数字

    def test_generate_signature_with_sorting(self):
        """测试生成签名 - 验证排序逻辑"""
        strategy = MD5SortedValuesStrategy()

        # 参数1: 乱序
        params1 = {"z": "3", "a": "1", "m": "2"}
        sig1 = strategy.generate_signature(params1, "secret")

        # 参数2: 已排序（应该生成相同签名）
        params2 = {"a": "1", "m": "2", "z": "3"}
        sig2 = strategy.generate_signature(params2, "secret")

        # 应该相同（因为都会排序）
        assert sig1 == sig2

    def test_generate_signature_skip_empty(self):
        """测试生成签名 - 跳过空值"""
        strategy = MD5SortedValuesStrategy()

        # 参数包含空值
        params = {
            "a": "1",
            "b": None,  # 应该跳过
            "c": "",  # 应该跳过
            "d": "2",
        }

        signature = strategy.generate_signature(params, "secret")

        # 应该只包含 "1" + "2" + "secret"
        # 验证：与不包含空值的参数生成的签名应该相同
        params_no_empty = {"a": "1", "d": "2"}
        sig_no_empty = strategy.generate_signature(params_no_empty, "secret")

        assert signature == sig_no_empty

    def test_generate_signature_with_real_data(self):
        """测试生成签名 - 使用真实数据"""
        strategy = MD5SortedValuesStrategy()

        # 真实的Gift Card API参数
        params = {"customerOrderNo": "ORDER_001", "userId": 1001, "templateId": 1, "quantity": 1}

        signature = strategy.generate_signature(params, "gift_card_secret_2025")

        # 验证签名格式
        assert len(signature) == 32
        assert signature.islower()

        # 签名应该可以验证通过
        assert strategy.verify_signature(params, "gift_card_secret_2025", signature)

    def test_verify_signature_success(self):
        """测试验证签名 - 成功"""
        strategy = MD5SortedValuesStrategy()
        params = {"userId": 1001, "orderId": "ORDER_001"}
        secret = "secret"

        # 生成签名
        signature = strategy.generate_signature(params, secret)

        # 验证应该通过
        assert strategy.verify_signature(params, secret, signature) is True

    def test_verify_signature_failure_wrong_signature(self):
        """测试验证签名 - 错误的签名"""
        strategy = MD5SortedValuesStrategy()
        params = {"userId": 1001}

        # 使用错误的签名
        assert strategy.verify_signature(params, "secret", "wrong_signature") is False

    def test_verify_signature_failure_wrong_secret(self):
        """测试验证签名 - 错误的密钥"""
        strategy = MD5SortedValuesStrategy()
        params = {"userId": 1001}

        # 使用正确密钥生成签名
        signature = strategy.generate_signature(params, "secret1")

        # 使用错误密钥验证
        assert strategy.verify_signature(params, "secret2", signature) is False

    def test_verify_signature_failure_modified_params(self):
        """测试验证签名 - 参数被篡改"""
        strategy = MD5SortedValuesStrategy()
        original_params = {"userId": 1001, "amount": 100}
        secret = "secret"

        # 生成签名
        signature = strategy.generate_signature(original_params, secret)

        # 篡改参数
        tampered_params = {"userId": 1001, "amount": 999}

        # 验证应该失败
        assert strategy.verify_signature(tampered_params, secret, signature) is False

    def test_case_insensitive(self):
        """测试签名大小写不敏感"""
        strategy = MD5SortedValuesStrategy()
        params = {"userId": 1001}
        secret = "secret"

        signature = strategy.generate_signature(params, secret)

        # 大写签名应该也能验证通过
        assert strategy.verify_signature(params, secret, signature.upper()) is True
        # 小写签名也能验证通过
        assert strategy.verify_signature(params, secret, signature.lower()) is True


class TestSHA256SortedValuesStrategy:
    """测试SHA256签名策略"""

    def test_generate_signature_length(self):
        """测试生成签名 - 长度验证"""
        strategy = SHA256SortedValuesStrategy()
        params = {"userId": 1001}

        signature = strategy.generate_signature(params, "secret")

        # SHA256固定64位
        assert len(signature) == 64
        assert signature.islower()
        assert signature.isalnum()

    def test_generate_signature_different_from_md5(self):
        """测试SHA256签名与MD5不同"""
        params = {"userId": 1001}
        secret = "secret"

        md5_strategy = MD5SortedValuesStrategy()
        sha256_strategy = SHA256SortedValuesStrategy()

        md5_sig = md5_strategy.generate_signature(params, secret)
        sha256_sig = sha256_strategy.generate_signature(params, secret)

        # 两种算法生成的签名应该不同
        assert md5_sig != sha256_sig
        assert len(md5_sig) == 32
        assert len(sha256_sig) == 64

    def test_verify_signature_success(self):
        """测试验证签名 - 成功"""
        strategy = SHA256SortedValuesStrategy()
        params = {"userId": 1001}
        secret = "secret"

        signature = strategy.generate_signature(params, secret)

        assert strategy.verify_signature(params, secret, signature) is True

    def test_verify_signature_failure(self):
        """测试验证签名 - 失败"""
        strategy = SHA256SortedValuesStrategy()
        params = {"userId": 1001}

        assert strategy.verify_signature(params, "secret", "wrong") is False


class TestSignatureCompatibility:
    """测试签名兼容性 - 与Java后端对比"""

    def test_md5_signature_matches_java(self):
        """测试MD5签名与Java后端一致

        Java代码:
        Map<String, String> params = new HashMap<>();
        params.put("customerOrderNo", "ORDER_001");
        params.put("userId", "1001");
        params.put("templateId", "1");
        params.put("quantity", "1");
        String signature = SignatureUtil.generateSignature(params, "test_secret");

        待签名字符串（按key排序）:
        "ORDER_001" + "1" + "1" + "1001" + "test_secret"
        = "ORDER_00111001test_secret"
        """
        strategy = MD5SortedValuesStrategy()

        params = {"customerOrderNo": "ORDER_001", "userId": 1001, "templateId": 1, "quantity": 1}

        signature = strategy.generate_signature(params, "test_secret")

        # 待签名字符串: ORDER_00111001test_secret
        # MD5: 可以用在线工具验证
        assert len(signature) == 32
        assert signature.islower()

        # 验证可以通过
        assert strategy.verify_signature(params, "test_secret", signature)

    def test_empty_params_signature(self):
        """测试空参数签名"""
        strategy = MD5SortedValuesStrategy()

        # 空参数，只有密钥
        params = {}
        signature = strategy.generate_signature(params, "secret")

        # 待签名字符串只有: "secret"
        import hashlib

        expected = hashlib.md5(b"secret").hexdigest()
        assert signature == expected
