"""测试 GraphQL 客户端"""

from unittest.mock import MagicMock, Mock, patch

import httpx
import pytest

from df_test_framework.clients.graphql import GraphQLClient


class TestGraphQLClient:
    """测试 GraphQLClient"""

    @pytest.fixture
    def mock_httpx_client(self):
        """Mock httpx.Client"""
        with patch("df_test_framework.clients.graphql.client.httpx.Client") as mock:
            yield mock

    def test_init_client(self, mock_httpx_client):
        """测试初始化客户端"""
        client = GraphQLClient("https://api.example.com/graphql")

        assert client.url == "https://api.example.com/graphql"
        assert client.timeout == 30
        assert client.verify_ssl is True
        assert client.headers["Content-Type"] == "application/json"

    def test_init_with_custom_headers(self, mock_httpx_client):
        """测试使用自定义请求头初始化"""
        headers = {"Authorization": "Bearer token123"}
        client = GraphQLClient(
            "https://api.example.com/graphql",
            headers=headers,
        )

        assert "Authorization" in client.headers
        assert client.headers["Authorization"] == "Bearer token123"

    def test_set_header(self, mock_httpx_client):
        """测试设置请求头"""
        client = GraphQLClient("https://api.example.com/graphql")
        client.set_header("X-Custom-Header", "value")

        assert client.headers["X-Custom-Header"] == "value"

    def test_remove_header(self, mock_httpx_client):
        """测试移除请求头"""
        client = GraphQLClient("https://api.example.com/graphql")
        client.set_header("X-Custom-Header", "value")
        client.remove_header("X-Custom-Header")

        assert "X-Custom-Header" not in client.headers

    def test_execute_success(self, mock_httpx_client):
        """测试成功执行查询"""
        # Mock HTTP 响应
        mock_response = Mock()
        mock_response.json.return_value = {"data": {"user": {"id": "123", "name": "Alice"}}}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = mock_httpx_client.return_value
        mock_client_instance.post.return_value = mock_response

        client = GraphQLClient("https://api.example.com/graphql")
        query = "{ user { id name } }"
        response = client.execute(query)

        assert response.is_success is True
        assert response.data == {"user": {"id": "123", "name": "Alice"}}
        mock_client_instance.post.assert_called_once()

    def test_execute_with_variables(self, mock_httpx_client):
        """测试执行带变量的查询"""
        mock_response = Mock()
        mock_response.json.return_value = {"data": {"user": {"id": "123", "name": "Alice"}}}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = mock_httpx_client.return_value
        mock_client_instance.post.return_value = mock_response

        client = GraphQLClient("https://api.example.com/graphql")
        query = "query GetUser($id: ID!) { user(id: $id) { name } }"
        variables = {"id": "123"}

        response = client.execute(query, variables)

        assert response.is_success is True
        # 验证请求参数
        call_args = mock_client_instance.post.call_args
        assert call_args[1]["json"]["variables"] == {"id": "123"}

    def test_execute_with_errors(self, mock_httpx_client):
        """测试执行返回错误"""
        mock_response = Mock()
        mock_response.json.return_value = {"errors": [{"message": "Field not found"}]}
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = mock_httpx_client.return_value
        mock_client_instance.post.return_value = mock_response

        client = GraphQLClient("https://api.example.com/graphql")
        query = "{ user { invalidField } }"
        response = client.execute(query)

        assert response.is_success is False
        assert len(response.errors) == 1  # type: ignore
        assert response.errors[0].message == "Field not found"  # type: ignore

    def test_execute_http_error(self, mock_httpx_client):
        """测试 HTTP 请求错误"""
        mock_client_instance = mock_httpx_client.return_value
        mock_client_instance.post.side_effect = httpx.HTTPError("Connection error")

        client = GraphQLClient("https://api.example.com/graphql")
        query = "{ user { id } }"

        with pytest.raises(httpx.HTTPError):
            client.execute(query)

    def test_execute_batch(self, mock_httpx_client):
        """测试批量执行查询"""
        mock_response = Mock()
        mock_response.json.return_value = [
            {"data": {"user": {"id": "1", "name": "Alice"}}},
            {"data": {"user": {"id": "2", "name": "Bob"}}},
        ]
        mock_response.raise_for_status = MagicMock()

        mock_client_instance = mock_httpx_client.return_value
        mock_client_instance.post.return_value = mock_response

        client = GraphQLClient("https://api.example.com/graphql")
        operations = [
            ("{ user(id: 1) { id name } }", None),
            ("{ user(id: 2) { id name } }", None),
        ]

        responses = client.execute_batch(operations)

        assert len(responses) == 2
        assert responses[0].data == {"user": {"id": "1", "name": "Alice"}}
        assert responses[1].data == {"user": {"id": "2", "name": "Bob"}}

    def test_context_manager(self, mock_httpx_client):
        """测试上下文管理器"""
        mock_client_instance = mock_httpx_client.return_value

        with GraphQLClient("https://api.example.com/graphql") as client:
            assert client is not None

        mock_client_instance.close.assert_called_once()

    def test_close(self, mock_httpx_client):
        """测试关闭客户端"""
        mock_client_instance = mock_httpx_client.return_value

        client = GraphQLClient("https://api.example.com/graphql")
        client.close()

        mock_client_instance.close.assert_called_once()
