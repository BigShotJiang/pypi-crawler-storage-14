"""GraphQL 客户端测试模块"""
