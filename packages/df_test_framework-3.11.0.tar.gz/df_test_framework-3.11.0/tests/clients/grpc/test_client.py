"""测试 gRPC 客户端

注意：由于 gRPC 需要安装额外的依赖（grpcio），这里主要测试客户端的基本功能和接口
"""

import pytest

from df_test_framework.clients.grpc import GrpcClient
from df_test_framework.clients.grpc.interceptors import MetadataInterceptor
from df_test_framework.clients.grpc.models import ChannelOptions


class TestGrpcClient:
    """测试 GrpcClient"""

    def test_init_client(self) -> None:
        """测试初始化客户端"""
        client = GrpcClient("localhost:50051")

        assert client.target == "localhost:50051"
        assert client.secure is False
        assert isinstance(client.options, ChannelOptions)
        assert len(client.interceptors) == 0

    def test_init_with_custom_options(self) -> None:
        """测试使用自定义选项初始化"""
        options = ChannelOptions(
            max_send_message_length=1024 * 1024,
            keepalive_time_ms=30000,
        )

        client = GrpcClient(
            "localhost:50051",
            options=options,
        )

        assert client.options.max_send_message_length == 1024 * 1024
        assert client.options.keepalive_time_ms == 30000

    def test_init_with_interceptors(self) -> None:
        """测试使用拦截器初始化"""
        interceptor = MetadataInterceptor({"Authorization": "Bearer token"})
        client = GrpcClient(
            "localhost:50051",
            interceptors=[interceptor],
        )

        assert len(client.interceptors) == 1
        assert isinstance(client.interceptors[0], MetadataInterceptor)

    def test_init_secure_client(self) -> None:
        """测试初始化安全客户端"""
        client = GrpcClient(
            "localhost:50051",
            secure=True,
        )

        assert client.secure is True

    def test_add_metadata(self) -> None:
        """测试添加元数据"""
        client = GrpcClient("localhost:50051")
        client.add_metadata("Authorization", "Bearer token123")
        client.add_metadata("X-Request-ID", "abc")

        assert len(client._metadata) == 2
        assert ("Authorization", "Bearer token123") in client._metadata
        assert ("X-Request-ID", "abc") in client._metadata

    def test_clear_metadata(self) -> None:
        """测试清除元数据"""
        client = GrpcClient("localhost:50051")
        client.add_metadata("key", "value")
        client.clear_metadata()

        assert len(client._metadata) == 0

    def test_add_interceptor(self) -> None:
        """测试添加拦截器"""
        client = GrpcClient("localhost:50051")
        interceptor = MetadataInterceptor()

        client.add_interceptor(interceptor)

        assert len(client.interceptors) == 1
        assert client.interceptors[0] == interceptor

    def test_ensure_grpc_not_installed(self) -> None:
        """测试 grpcio 未安装时的错误"""
        client = GrpcClient("localhost:50051")

        # 如果 grpcio 未安装，应该抛出 ImportError
        # 如果已安装，这个测试会被跳过
        try:
            import grpc  # noqa: F401

            pytest.skip("grpcio is installed, skipping this test")
        except ImportError:
            with pytest.raises(ImportError, match="grpcio is not installed"):
                client.connect()

    def test_unary_call_without_connection(self) -> None:
        """测试未连接时调用"""
        client = GrpcClient("localhost:50051")

        with pytest.raises(RuntimeError, match="Not connected"):
            client.unary_call("TestMethod", {})

    def test_server_streaming_call_without_connection(self) -> None:
        """测试未连接时流式调用"""
        client = GrpcClient("localhost:50051")

        with pytest.raises(RuntimeError, match="Not connected"):
            list(client.server_streaming_call("TestMethod", {}))

    def test_apply_interceptors_request(self) -> None:
        """测试应用请求拦截器"""
        interceptor = MetadataInterceptor({"X-Custom": "value"})
        client = GrpcClient("localhost:50051", interceptors=[interceptor])

        request = {}
        metadata = [("Content-Type", "application/grpc")]

        result_request, result_metadata = client._apply_interceptors_request(
            "TestMethod", request, metadata
        )

        # 验证拦截器被应用
        assert ("X-Custom", "value") in result_metadata

    def test_apply_interceptors_response(self) -> None:
        """测试应用响应拦截器"""
        client = GrpcClient("localhost:50051")

        response = {"result": "ok"}
        metadata = {}

        result_response = client._apply_interceptors_response("TestMethod", response, metadata)

        assert result_response == response
