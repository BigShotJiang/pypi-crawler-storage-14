"""测试Allure集成功能

验证AllureObserver与HttpClient、InterceptorChain的集成

运行测试并生成Allure报告:
    pytest tests/test_allure_integration.py --alluredir=./allure-results -v
    allure serve ./allure-results
"""

from unittest.mock import Mock, patch

import httpx
import pytest

from df_test_framework.clients.http.core import Request, Response
from df_test_framework.clients.http.rest.httpx import HttpClient
from df_test_framework.infrastructure.config.schema import (
    HTTPConfig,
    SignatureInterceptorConfig,
    TokenInterceptorConfig,
)
from df_test_framework.testing.observers.allure_observer import (
    ALLURE_AVAILABLE,
    AllureObserver,
    get_current_observer,
    set_current_observer,
)


class TestAllureObserver:
    """测试AllureObserver核心功能"""

    def test_observer_creation(self):
        """测试创建AllureObserver"""
        observer = AllureObserver(test_name="test_example")

        assert observer.test_name == "test_example"
        assert observer.request_counter == 0

    def test_get_set_current_observer(self):
        """测试获取和设置当前observer"""
        observer = AllureObserver(test_name="test_example")

        # 设置
        set_current_observer(observer)

        # 获取
        current = get_current_observer()
        assert current == observer

        # 清理
        set_current_observer(None)
        assert get_current_observer() is None

    @pytest.mark.skipif(not ALLURE_AVAILABLE, reason="Allure not installed")
    def test_on_http_request_start(self):
        """测试记录HTTP请求开始"""
        observer = AllureObserver(test_name="test_example")

        request = Request(method="POST", url="/api/users", json={"name": "Alice"})

        request_id = observer.on_http_request_start(request)

        # 验证request_id格式
        assert request_id.startswith("req-")
        assert observer.request_counter == 1

    @pytest.mark.skipif(not ALLURE_AVAILABLE, reason="Allure not installed")
    def test_on_interceptor_execute(self):
        """测试记录拦截器执行"""
        observer = AllureObserver(test_name="test_example")

        # 开始请求
        request = Request(method="POST", url="/api/users", json={"name": "Alice"})
        request_id = observer.on_http_request_start(request)

        # 记录拦截器执行
        changes = {"headers": {"added": {"X-Sign": "md5_abc123"}}}
        observer.on_interceptor_execute(request_id, "SignatureInterceptor", changes)

        # 如果能执行到这里说明没有抛出异常
        assert True

    @pytest.mark.skipif(not ALLURE_AVAILABLE, reason="Allure not installed")
    def test_on_http_request_end(self):
        """测试记录HTTP请求结束"""
        observer = AllureObserver(test_name="test_example")

        # 开始请求
        request = Request(method="POST", url="/api/users", json={"name": "Alice"})
        request_id = observer.on_http_request_start(request)

        # 结束请求
        response = Response(
            status_code=201,
            headers={"content-type": "application/json"},
            body='{"id": 1, "name": "Alice"}',
            json_data={"id": 1, "name": "Alice"},
        )
        observer.on_http_request_end(request_id, response, duration_ms=145.23)

        # 验证step已关闭
        assert observer._current_step_context is None

    @pytest.mark.skipif(not ALLURE_AVAILABLE, reason="Allure not installed")
    def test_on_error(self):
        """测试记录错误"""
        observer = AllureObserver(test_name="test_example")

        error = ValueError("Invalid input")
        context = {"stage": "before_request", "request_id": "req-001"}

        observer.on_error(error, context)

        # 如果能执行到这里说明没有抛出异常
        assert True


class TestHttpClientAllureIntegration:
    """测试HttpClient与Allure的集成"""

    def test_http_client_calls_observer(self):
        """测试HttpClient自动调用observer"""
        # 创建observer并设置为当前
        observer = AllureObserver(test_name="test_http_request")
        set_current_observer(observer)

        # 创建HttpClient
        http_config = HTTPConfig(
            base_url="http://test.example.com",
            interceptors=[
                SignatureInterceptorConfig(
                    type="signature",
                    algorithm="md5",
                    secret="test_secret",
                    header_name="X-Sign",
                )
            ],
        )
        client = HttpClient(base_url="http://test.example.com", config=http_config)

        # Mock httpx response
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.text = '{"result": "ok"}'
        mock_response.headers = {"content-type": "application/json"}

        with patch.object(client.client, "request", return_value=mock_response):
            # 发送请求
            client.get("/test")

            # 验证observer被调用
            assert observer.request_counter == 1

        # 清理
        set_current_observer(None)
        client.close()

    def test_http_client_without_observer(self):
        """测试HttpClient在没有observer时仍正常工作"""
        # 确保没有observer
        set_current_observer(None)

        client = HttpClient(base_url="http://test.example.com")

        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.text = '{"result": "ok"}'
        mock_response.headers = {"content-type": "application/json"}

        with patch.object(client.client, "request", return_value=mock_response):
            # 应该正常工作，不抛出异常
            response = client.get("/test")
            assert response.status_code == 200

        client.close()


class TestInterceptorChainAllureIntegration:
    """测试InterceptorChain与Allure的集成"""

    def test_chain_diff_request(self):
        """测试_diff_request()方法"""
        from df_test_framework.clients.http.core import InterceptorChain

        chain = InterceptorChain()

        # 创建两个Request
        before = Request(
            method="POST",
            url="/api/users",
            headers={"Content-Type": "application/json"},
            json={"name": "Alice"},
        )

        after = Request(
            method="POST",
            url="/api/users",
            headers={
                "Content-Type": "application/json",
                "X-Sign": "md5_abc123",
                "Authorization": "Bearer token123",
            },
            json={"name": "Alice"},
        )

        # 对比
        changes = chain._diff_request(before, after)

        # 验证变化
        assert "headers" in changes
        assert "added" in changes["headers"]
        assert "X-Sign" in changes["headers"]["added"]
        assert "Authorization" in changes["headers"]["added"]

    def test_chain_records_interceptor_changes(self):
        """测试InterceptorChain记录拦截器修改到observer"""
        from df_test_framework.clients.http.core import InterceptorChain
        from df_test_framework.clients.http.interceptors import SignatureInterceptor

        # 创建observer
        observer = AllureObserver(test_name="test_chain")
        set_current_observer(observer)

        # 创建拦截器链
        chain = InterceptorChain()

        # 创建签名拦截器
        signature_interceptor = SignatureInterceptor(
            algorithm="md5", secret="test_secret", header_name="X-Sign", priority=10
        )

        # 添加到链
        chain.add(signature_interceptor)

        # 创建请求
        request = Request(method="POST", url="/api/users", json={"name": "Alice"})

        # 开始HTTP请求（创建request_id）
        request_id = observer.on_http_request_start(request)

        # 执行拦截器链（传递observer和request_id）
        modified_request = chain.execute_before_request(
            request, request_id=request_id, observer=observer
        )

        # 验证拦截器执行成功
        assert "X-Sign" in modified_request.headers

        # 清理
        set_current_observer(None)


class TestAutouseFixture:
    """测试autouse fixture的自动注入"""

    def test_auto_allure_observer_fixture(self):
        """测试_auto_allure_observer自动注入

        这个测试本身就会触发autouse fixture
        验证observer已自动设置
        """
        # 获取当前observer
        observer = get_current_observer()

        # 如果Allure可用，observer应该存在
        if ALLURE_AVAILABLE:
            assert observer is not None
            assert isinstance(observer, AllureObserver)
        else:
            # Allure不可用时，observer应该为None
            assert observer is None


@pytest.mark.skipif(not ALLURE_AVAILABLE, reason="Allure not installed")
class TestEndToEndIntegration:
    """端到端集成测试"""

    def test_complete_http_request_with_interceptors(self):
        """测试完整的HTTP请求流程（带拦截器和Allure记录）

        这个测试会自动记录到Allure报告:
        - HTTP请求详情
        - 拦截器执行过程
        - HTTP响应详情
        """
        # autouse fixture会自动注入observer
        observer = get_current_observer()

        # 创建HttpClient（带拦截器）
        http_config = HTTPConfig(
            base_url="http://test.example.com",
            interceptors=[
                SignatureInterceptorConfig(
                    type="signature",
                    algorithm="md5",
                    secret="test_secret",
                    header_name="X-Sign",
                    priority=10,
                ),
                TokenInterceptorConfig(
                    type="token",
                    token="test_token_123",
                    token_type="Bearer",
                    header_name="Authorization",
                    priority=20,
                ),
            ],
        )

        client = HttpClient(base_url="http://test.example.com", config=http_config)

        # Mock httpx response
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 201
        mock_response.text = '{"id": 1, "name": "Alice"}'
        mock_response.headers = {"content-type": "application/json"}

        with patch.object(client.client, "request", return_value=mock_response):
            # 发送请求
            response = client.post("/api/users", json={"name": "Alice"})

            # 验证响应
            assert response.status_code == 201

            # 验证observer记录了请求
            if observer:
                assert observer.request_counter == 1

        client.close()

        # Allure报告应该包含:
        # 🌐 POST /api/users
        #   ├─ 📤 Request Details
        #   ├─ ⚙️ SignatureInterceptor
        #   ├─ ⚙️ TokenInterceptor
        #   └─ ✅ Response (201) - XXXms


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--alluredir=./allure-results"])
