"""测试 AsyncHttpClient 与拦截器的集成

验证同步拦截器在异步客户端中正常工作
"""

import asyncio
from unittest.mock import AsyncMock, Mock, patch

import httpx
import pytest

from df_test_framework.clients.http.interceptors import (
    BearerTokenInterceptor,
    LoggingInterceptor,
    SignatureInterceptor,
)
from df_test_framework.clients.http.rest.httpx import AsyncHttpClient


class TestAsyncHttpClientWithInterceptors:
    """测试异步HTTP客户端与拦截器集成"""

    @pytest.fixture
    def mock_response(self):
        """模拟HTTP响应"""
        response = Mock(spec=httpx.Response)
        response.status_code = 200
        response.headers = {"Content-Type": "application/json"}
        response.text = '{"message": "success"}'
        response.json.return_value = {"message": "success"}
        return response

    @pytest.mark.asyncio
    async def test_bearer_token_interceptor(self, mock_response):
        """测试BearerToken拦截器在异步客户端中工作"""
        async with AsyncHttpClient("https://api.test.com") as client:
            # 添加拦截器（使用静态token）
            interceptor = BearerTokenInterceptor(
                token_source="static", static_token="test_token_123"
            )
            client.interceptor_chain.add(interceptor)

            with patch.object(client.client, "request", new_callable=AsyncMock) as mock_request:
                mock_request.return_value = mock_response

                response = await client.get("/users")

                # 验证拦截器添加了Authorization header
                call_kwargs = mock_request.call_args.kwargs
                assert "headers" in call_kwargs
                assert call_kwargs["headers"]["Authorization"] == "Bearer test_token_123"
                assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_logging_interceptor(self, mock_response):
        """测试Logging拦截器在异步客户端中工作"""
        async with AsyncHttpClient("https://api.test.com") as client:
            # 添加拦截器
            interceptor = LoggingInterceptor(level="DEBUG")
            client.interceptor_chain.add(interceptor)

            with patch.object(client.client, "request", new_callable=AsyncMock) as mock_request:
                mock_request.return_value = mock_response

                # 应该正常工作，不抛异常
                response = await client.get("/users")

                assert response.status_code == 200
                mock_request.assert_called_once()

    @pytest.mark.asyncio
    async def test_signature_interceptor(self, mock_response):
        """测试Signature拦截器在异步客户端中工作"""
        async with AsyncHttpClient("https://api.test.com") as client:
            # 添加拦截器
            interceptor = SignatureInterceptor(
                algorithm="md5", secret="my_secret", header_name="X-Sign"
            )
            client.interceptor_chain.add(interceptor)

            with patch.object(client.client, "request", new_callable=AsyncMock) as mock_request:
                mock_request.return_value = mock_response

                response = await client.post("/users", json={"name": "Alice"})

                # 验证拦截器添加了签名header
                call_kwargs = mock_request.call_args.kwargs
                assert "headers" in call_kwargs
                assert "X-Sign" in call_kwargs["headers"]
                assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_multiple_interceptors(self, mock_response):
        """测试多个拦截器按优先级执行"""
        async with AsyncHttpClient("https://api.test.com") as client:
            # 添加多个拦截器（按优先级执行）
            signature = SignatureInterceptor(algorithm="md5", secret="secret", priority=10)
            bearer = BearerTokenInterceptor(
                token_source="static", static_token="my_token", priority=20
            )
            logging = LoggingInterceptor(priority=100)

            client.interceptor_chain.add(signature)
            client.interceptor_chain.add(bearer)
            client.interceptor_chain.add(logging)

            with patch.object(client.client, "request", new_callable=AsyncMock) as mock_request:
                mock_request.return_value = mock_response

                response = await client.post("/api/users", json={"name": "Bob"})

                # 验证所有拦截器都生效
                call_kwargs = mock_request.call_args.kwargs
                assert "headers" in call_kwargs
                assert "X-Sign" in call_kwargs["headers"]  # 签名拦截器
                assert call_kwargs["headers"]["Authorization"] == "Bearer my_token"  # Token拦截器
                assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_concurrent_requests_with_interceptors(self, mock_response):
        """测试并发请求时拦截器正常工作"""
        async with AsyncHttpClient("https://api.test.com") as client:
            # 添加拦截器
            interceptor = BearerTokenInterceptor(
                token_source="static", static_token="concurrent_token"
            )
            client.interceptor_chain.add(interceptor)

            with patch.object(client.client, "request", new_callable=AsyncMock) as mock_request:
                mock_request.return_value = mock_response

                # 并发10个请求
                tasks = [client.get(f"/users/{i}") for i in range(10)]
                responses = await asyncio.gather(*tasks)

                # 所有请求都成功
                assert len(responses) == 10
                for response in responses:
                    assert response.status_code == 200

                # 验证拦截器对每个请求都生效
                assert mock_request.call_count == 10


__all__ = ["TestAsyncHttpClientWithInterceptors"]
