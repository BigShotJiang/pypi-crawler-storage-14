# 测试框架调试系统设计 (v3.5)

> **目标**: 提供现代化、统一、零配置的调试能力

---

## 1. 核心设计原则

### 1.1 用户体验优先

- ✅ **零配置** - 默认启用，pytest运行时自动记录
- ✅ **智能输出** - 测试失败时自动展开详情，成功时仅显示摘要
- ✅ **清晰可读** - 统一格式，emoji图标，分组输出

### 1.2 统一输出格式

**所有组件使用相同的日志格式**：

```
[时间] [组件] [级别] 消息内容
```

**示例**：
```
[10:53:08] [HTTP] [→] GET /api/users
[10:53:08] [HTTP] [i] Headers: Authorization=Bearer tok...
[10:53:08] [HTTP] [←] 200 OK (145ms)
[10:53:08] [HTTP] [✓] Body: {"users": [...]}
```

### 1.3 自动上下文追踪

每个HTTP请求自动分配 `request_id`，关联所有相关操作：

```
[10:53:08] [HTTP] [req-001] GET /api/users
[10:53:08] [HTTP] [req-001] Interceptor: SignatureInterceptor → Added X-Sign
[10:53:08] [HTTP] [req-001] Interceptor: TokenInterceptor → Added Authorization
[10:53:08] [HTTP] [req-001] 200 OK (145ms)
```

---

## 2. 架构设计

### 2.1 核心组件

```
┌─────────────────────────────────────┐
│   TestDebugger (统一调试器)         │
│   - 自动记录所有操作                │
│   - 测试结束时输出摘要              │
│   - 测试失败时展开详情              │
└─────────────────────────────────────┘
         ↓          ↓          ↓
┌────────────┐ ┌──────────┐ ┌──────────┐
│ HTTPTracer │ │ DBTracer │ │ 其他Tracer│
│ (HTTP记录) │ │ (DB记录) │ │          │
└────────────┘ └──────────┘ └──────────┘
```

### 2.2 类图

```python
class TestDebugger:
    """统一调试器 - 测试级别的调试入口"""

    def __init__(self):
        self.http_tracer = HTTPTracer(self)
        self.db_tracer = DBTracer(self)
        self.events: List[Event] = []  # 所有事件按时间序列

    def start_test(self, test_name: str):
        """测试开始"""

    def end_test(self, result: TestResult):
        """测试结束 - 输出摘要或详情"""
        if result.failed:
            self.print_full_details()  # 失败时展开所有详情
        else:
            self.print_summary()  # 成功时仅显示摘要

class HTTPTracer:
    """HTTP追踪器"""

    def start_request(self, request: Request) -> str:
        """开始HTTP请求 - 返回request_id"""
        request_id = self._generate_id()
        self._log(f"[{request_id}] {request.method} {request.url}")
        return request_id

    def log_interceptor(self, request_id: str, interceptor_name: str, changes: Dict):
        """记录拦截器操作"""

    def end_request(self, request_id: str, response: Response):
        """结束HTTP请求"""

class Event:
    """调试事件"""
    timestamp: datetime
    component: str  # "HTTP", "DB", etc.
    level: str      # "INFO", "DEBUG", "ERROR"
    request_id: Optional[str]
    message: str
    details: Dict[str, Any]
```

---

## 3. 输出格式设计

### 3.1 测试运行时输出（pytest -s）

**成功的测试**：
```
tests/test_api.py::test_create_user
[HTTP] 3 requests, all succeeded ✓
  POST /api/users → 201 (145ms)
  GET /api/users/123 → 200 (89ms)
  DELETE /api/users/123 → 204 (67ms)
PASSED
```

**失败的测试**：
```
tests/test_api.py::test_create_user
[HTTP] 2 requests, 1 failed ✗

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Request #1: POST /api/users [req-001]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[10:53:08.123] → POST http://api.example.com/api/users

Headers:
  Content-Type: application/json

Body:
  {"name": "John", "email": "john@example.com"}

Interceptors:
  ✓ SignatureInterceptor → Added X-Sign: md5_abc123...
  ✓ TokenInterceptor → Added Authorization: Bearer tok...

[10:53:08.268] ← 400 Bad Request (145ms) ✗

Response Headers:
  Content-Type: application/json

Response Body:
  {"error": "Email already exists"}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FAILED
```

### 3.2 详细模式（pytest -s -vv）

显示所有请求的完整详情（即使测试通过）。

### 3.3 pytest --tb=short 输出

集成到pytest的错误报告中：

```python
    def test_create_user(client):
        response = client.post("/api/users", json={"name": "John"})
>       assert response.status_code == 201
E       AssertionError: assert 400 == 201
E
E       [HTTP Debug] Last request details:
E       POST /api/users → 400 Bad Request
E       Response: {"error": "Email already exists"}
```

---

## 4. 实现细节

### 4.1 自动启用机制

**通过pytest plugin自动注入**：

```python
# src/df_test_framework/testing/fixtures/debug.py

@pytest.fixture(scope="function", autouse=True)
def _auto_debug(request):
    """自动启用调试（对所有测试生效）"""
    debugger = TestDebugger()
    debugger.start_test(request.node.name)

    # 注入到全局context
    _set_current_debugger(debugger)

    yield

    # 测试结束，输出摘要/详情
    result = _get_test_result(request)
    debugger.end_test(result)

    # 清理
    _clear_current_debugger()
```

### 4.2 HttpClient集成

```python
# src/df_test_framework/clients/http/rest/httpx/client.py

class HttpClient:
    def request(self, method: str, url: str, **kwargs) -> httpx.Response:
        # 1. 获取当前测试的debugger
        debugger = _get_current_debugger()
        request_id = None

        if debugger:
            # 2. 记录请求开始
            request_id = debugger.http_tracer.start_request(
                Request(method, url, **kwargs)
            )

        # 3. 执行拦截器（拦截器内部会自动记录到debugger）
        try:
            modified_request = self.interceptor_chain.execute_before_request(
                request_obj,
                request_id=request_id  # 传递request_id
            )
        except Exception as e:
            if debugger:
                debugger.http_tracer.log_error(request_id, e)
            raise

        # 4. 发送请求
        httpx_response = self.client.request(method, url, **kwargs)

        # 5. 记录响应
        if debugger:
            debugger.http_tracer.end_request(
                request_id,
                Response.from_httpx(httpx_response)
            )

        return httpx_response
```

### 4.3 拦截器自动记录

```python
# src/df_test_framework/clients/http/core/chain.py

class InterceptorChain:
    def execute_before_request(
        self,
        request: Request,
        request_id: Optional[str] = None
    ) -> Request:
        debugger = _get_current_debugger()

        for interceptor in self.interceptors:
            # 记录拦截器开始
            if debugger and request_id:
                debugger.http_tracer.log_interceptor_start(
                    request_id, interceptor.name
                )

            # 执行拦截器
            modified = interceptor.before_request(request)

            # 记录拦截器结果
            if debugger and request_id and modified:
                changes = self._diff_request(request, modified)
                debugger.http_tracer.log_interceptor_changes(
                    request_id, interceptor.name, changes
                )
                request = modified

        return request
```

---

## 5. 配置选项

### 5.1 pytest.ini 配置

```ini
[pytest]
# 调试输出级别
# - summary: 仅显示摘要（默认）
# - detailed: 显示所有请求详情
# - minimal: 最小输出（仅失败时）
df_debug_level = summary

# 是否自动启用调试
df_auto_debug = true

# 是否在测试失败时自动展开详情
df_debug_on_failure = true

# Body截断长度
df_debug_max_body_length = 1000
```

### 5.2 代码配置

```python
# conftest.py

@pytest.fixture(scope="session")
def configure_debug():
    from df_test_framework.testing.debug import configure_debug

    configure_debug(
        level="detailed",  # 显示所有详情
        max_body_length=2000,
        show_interceptors=True,
    )
```

---

## 6. 使用示例

### 6.1 基本使用（零配置）

```python
def test_create_user(http_client):
    """完全零配置，自动记录所有HTTP请求"""
    response = http_client.post("/api/users", json={"name": "John"})
    assert response.status_code == 201
```

**输出**（成功）：
```
tests/test_api.py::test_create_user
[HTTP] 1 request ✓
PASSED
```

**输出**（失败）：
```
tests/test_api.py::test_create_user
[HTTP] 1 request ✗

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Request #1: POST /api/users
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→ POST /api/users
Body: {"name": "John"}

Interceptors:
  ✓ SignatureInterceptor → Added X-Sign
  ✓ TokenInterceptor → Added Authorization

← 400 Bad Request (145ms)
Body: {"error": "Email already exists"}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FAILED
```

### 6.2 手动控制（高级用法）

```python
from df_test_framework.testing.debug import get_current_debugger

def test_complex_flow(http_client):
    debugger = get_current_debugger()

    # 标记关键操作
    debugger.mark("Step 1: Login")
    login_resp = http_client.post("/admin/login", ...)

    debugger.mark("Step 2: Create Order")
    order_resp = http_client.post("/api/orders", ...)

    # 手动打印当前状态
    debugger.print_current_state()
```

---

## 7. 对比现有方案

### 7.1 Before (HTTPDebugger)

**优点**：
- ✅ 简单直接
- ✅ `print_summary()` 有用

**缺点**：
- ❌ 需要手动调用 `start()`/`stop()`
- ❌ 输出格式不统一（`[HTTP DEBUG]` vs Loguru）
- ❌ 无法追踪拦截器操作
- ❌ 多个debugger（HTTP、DB）独立，无关联

### 7.2 After (TestDebugger)

**优点**：
- ✅ **零配置** - 自动启用，无需手动调用
- ✅ **统一格式** - 所有组件使用相同的输出格式
- ✅ **上下文追踪** - 请求ID关联所有操作
- ✅ **智能输出** - 失败时自动展开详情
- ✅ **拦截器可见** - 自动记录拦截器操作

**缺点**：
- ⚠️ 需要重写现有debugger（工作量1-2天）

---

## 8. 实施计划

### Phase 2: 调试系统重构 (2-3天)

**Day 1: 核心实现**
- Task 2.1: 实现TestDebugger核心类
- Task 2.2: 实现HTTPTracer
- Task 2.3: 实现Event模型

**Day 2: 集成**
- Task 2.4: HttpClient集成（自动记录）
- Task 2.5: InterceptorChain集成（拦截器记录）
- Task 2.6: pytest plugin（自动启用）

**Day 3: 完善**
- Task 2.7: 输出格式美化
- Task 2.8: 配置选项
- Task 2.9: 文档和示例

### 验收标准

- ✅ 零配置即可使用
- ✅ 测试失败时自动展开HTTP详情
- ✅ 拦截器操作可见
- ✅ 输出格式统一、清晰
- ✅ 所有现有测试通过

---

## 9. 未来扩展

### 9.1 其他Tracer

- `DBTracer` - 数据库查询追踪
- `RedisTracer` - Redis操作追踪
- `MessageQueueTracer` - 消息队列追踪

### 9.2 高级功能

- 请求间关联分析（如token传递）
- 性能分析（拦截器开销、网络开销）
- 导出调试日志（JSON/HTML格式）
- 集成到CI报告

---

**总结**：新的调试系统提供**零配置、统一格式、智能输出**的现代化体验，完美适配v3.5架构。
