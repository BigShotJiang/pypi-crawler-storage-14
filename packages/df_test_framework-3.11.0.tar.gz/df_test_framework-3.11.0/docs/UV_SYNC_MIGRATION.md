# 迁移到 uv sync 现代化依赖管理

> **更新时间**: 2025-11-12
> **适用版本**: v3.5.0+

本文档说明如何从传统的 `uv pip install` 方式迁移到现代化的 `uv sync` 方式进行依赖管理。

---

## 📋 目录

- [为什么使用 uv sync](#为什么使用-uv-sync)
- [迁移步骤](#迁移步骤)
- [新的工作流程](#新的工作流程)
- [常见问题](#常见问题)

---

## 🎯 为什么使用 uv sync

### 优势对比

| 特性 | `uv pip install` | `uv sync` |
|------|------------------|-----------|
| **依赖锁定** | ❌ 无锁定文件 | ✅ `uv.lock` 确保一致性 |
| **虚拟环境管理** | 手动管理 | ✅ 自动创建和管理 `.venv` |
| **依赖解析速度** | 较快 | ✅ 更快（使用缓存） |
| **可重现性** | ⚠️  依赖最新版本 | ✅ 完全可重现 |
| **团队协作** | ⚠️  版本可能不一致 | ✅ 所有人使用相同版本 |
| **CI/CD 一致性** | ⚠️  可能不一致 | ✅ 开发和 CI 环境完全一致 |

### 核心特性

1. **依赖锁定**: `uv.lock` 文件记录所有依赖的精确版本
2. **自动虚拟环境**: 自动创建 `.venv` 目录，无需手动管理
3. **快速同步**: 增量更新，只安装变化的包
4. **完全可重现**: 任何人在任何机器上都能得到相同的环境

---

## 🚀 迁移步骤

### 1. 确认 uv 版本

```bash
uv --version
# 应该是 0.8.0 或更高版本
```

如果版本过低，更新 uv：
```bash
pip install --upgrade uv
```

### 2. 清理旧环境（可选）

如果你之前使用 `uv pip install` 安装在全局环境：

```bash
# 卸载旧的安装
uv pip uninstall df-test-framework

# 清理 Python 缓存
rm -rf __pycache__ .pytest_cache
```

### 3. 同步依赖

项目已经包含 `uv.lock` 文件，直接同步即可：

```bash
# 同步所有依赖（包括 dev 和 ui）
uv sync --all-extras

# 或者只同步特定的 extra
uv sync --extra dev       # 只安装开发依赖
uv sync --extra ui        # 只安装 UI 测试依赖
```

### 4. 验证安装

```bash
# 验证 pytest 可用
uv run pytest --version

# 验证 df-test CLI 可用
uv run df-test --help

# 验证其他工具
uv run ruff --version
uv run mypy --version
```

### 5. 更新 .gitignore

确保 `.gitignore` 包含：

```gitignore
.venv/
uv.lock  # 不要忽略！这个文件应该提交到 Git
```

---

## 💻 新的工作流程

### 日常开发命令

**旧方式 (uv pip install)**:
```bash
# 安装依赖
uv pip install -e ".[dev]"

# 运行命令
pytest -v
df-test --help
ruff check src/
```

**新方式 (uv sync)** ✅:
```bash
# 同步依赖
uv sync --all-extras

# 运行命令（使用 uv run）
uv run pytest -v
uv run df-test --help
uv run ruff check src/
```

### 运行测试

```bash
# 运行所有测试
uv run pytest -v

# 运行特定测试文件
uv run pytest tests/utils/test_common.py -v

# 运行测试并生成覆盖率
uv run pytest --cov=src/df_test_framework --cov-report=html

# 使用标记运行测试
uv run pytest -m smoke -v
```

### 代码质量检查

```bash
# Ruff 检查
uv run ruff check src/ tests/
uv run ruff format src/ tests/

# MyPy 类型检查
uv run mypy src/

# 运行所有检查
uv run ruff check src/ tests/ && \
uv run ruff format src/ tests/ --check && \
uv run mypy src/
```

### 添加新依赖

**方式1: 手动编辑 `pyproject.toml`** （推荐）

1. 编辑 `pyproject.toml`，添加依赖到 `dependencies` 或 `optional-dependencies`
2. 运行 `uv sync` 更新环境

```bash
# 更新 pyproject.toml 后
uv sync --all-extras
```

**方式2: 使用 uv add** （如果 uv 支持）

```bash
# 添加到主依赖
uv add requests

# 添加到 dev 依赖
uv add --dev pytest-asyncio
```

### 更新依赖

```bash
# 更新所有依赖到最新版本
uv lock --upgrade

# 同步更新后的依赖
uv sync --all-extras
```

---

## 🔧 CI/CD 配置

### GitHub Actions

项目的 CI 配置已更新为使用 `uv sync`：

```yaml
# .github/workflows/test.yml
- name: 安装uv
  uses: astral-sh/setup-uv@v3

- name: 同步依赖
  run: |
    uv sync --all-extras

- name: 运行测试
  run: |
    uv run pytest tests/ --verbose
```

### 其他 CI 系统

**GitLab CI**:
```yaml
test:
  script:
    - pip install uv
    - uv sync --all-extras
    - uv run pytest -v
```

**Jenkins**:
```groovy
stage('Test') {
    steps {
        sh 'pip install uv'
        sh 'uv sync --all-extras'
        sh 'uv run pytest -v'
    }
}
```

---

## ❓ 常见问题

### Q1: `uv.lock` 文件需要提交到 Git 吗？

**A**: ✅ **需要！** `uv.lock` 必须提交到版本控制，这样团队成员和 CI 环境才能使用完全相同的依赖版本。

### Q2: 如何在不同 Python 版本间切换？

**A**: 项目使用 `.python-version` 文件指定 Python 版本：

```bash
# 查看当前指定的 Python 版本
cat .python-version

# uv 会自动使用 .python-version 指定的版本
uv sync --all-extras
```

### Q3: 虚拟环境创建在哪里？

**A**: `uv sync` 会在项目根目录创建 `.venv/` 目录：

```bash
# 激活虚拟环境（可选）
.venv\Scripts\activate  # Windows
source .venv/bin/activate  # Linux/Mac

# 或直接使用 uv run（推荐）
uv run pytest -v
```

### Q4: 旧的 `uv pip install` 方式还能用吗？

**A**: ✅ 可以，但不推荐。新项目应该使用 `uv sync` 方式。

### Q5: 如何清理和重建环境？

**A**: 删除 `.venv` 目录，重新同步：

```bash
# Windows
rmdir /s /q .venv
uv sync --all-extras

# Linux/Mac
rm -rf .venv
uv sync --all-extras
```

### Q6: 为什么运行 pytest 报错？

**A**: 如果你看到类似 `FrameworkSettings is not fully defined` 的错误，这是框架代码本身的问题，不是 `uv sync` 的问题。`uv sync` 和 `uv run` 的工作流程是正确的。

### Q7: 如何在 IDE 中配置 Python 解释器？

**A**:

**VS Code**:
1. `Ctrl+Shift+P` → "Python: Select Interpreter"
2. 选择 `.venv\Scripts\python.exe`

**PyCharm**:
1. Settings → Project → Python Interpreter
2. Add Interpreter → Existing Environment
3. 选择 `.venv\Scripts\python.exe`

### Q8: `uv sync` 和 `uv pip install` 有什么本质区别？

**A**:

| `uv pip install` | `uv sync` |
|------------------|-----------|
| 类似 `pip install` | 类似 `poetry install` 或 `npm install` |
| 安装到当前环境 | 创建独立虚拟环境 |
| 没有锁定文件 | 使用 `uv.lock` 锁定版本 |
| 每次可能安装不同版本 | 每次都是相同版本 |

---

## 📚 参考资源

- [uv 官方文档](https://docs.astral.sh/uv/)
- [README.md](../README.md) - 项目文档
- [CONTRIBUTING.md](../CONTRIBUTING.md) - 贡献指南

---

## ✅ 迁移检查清单

- [ ] 更新 uv 到最新版本 (`pip install --upgrade uv`)
- [ ] 运行 `uv sync --all-extras`
- [ ] 验证命令可用 (`uv run pytest --version`)
- [ ] 更新 IDE 的 Python 解释器设置
- [ ] 将 `.venv/` 添加到 `.gitignore`
- [ ] **保留** `uv.lock` 在版本控制中
- [ ] 更新团队文档和说明
- [ ] 通知团队成员更新工作流程

---

**最后更新**: 2025-11-12
