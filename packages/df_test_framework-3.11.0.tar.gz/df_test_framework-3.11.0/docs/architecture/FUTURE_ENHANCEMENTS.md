# DF Test Framework v3 - 未来增强功能规划

> 基于v3架构的后续功能增强建议
>
> 📅 创建日期: 2025-11-03
> 🎯 优先级: P2-P3（非核心功能，逐步实现）

---

## 📋 背景说明

在早期v3架构讨论中（REFACTORING_PLAN_V3.md），我们识别出了6个遗漏点。经过v3架构实施和审计后，我们需要基于**最新的v3架构原则**重新评估这些遗漏点。

**v3架构核心原则**:
1. **按交互模式分类能力层** - clients/drivers/databases/messengers/storages/engines
2. **testing/按功能职责组织** - 不按测试类型（api/ui），而按工具职责（assertions/fixtures/plugins）
3. **能力层与测试支持层解耦** - 任何测试都可使用任何能力

---

## ✅ 已解决的遗漏点

### 1. 数据测试能力 ✅
**原始需求**: 缺少数据测试能力

**v3解决方案**:
- `databases/` - 数据访问模式（已扁平化）
  - `databases/redis/` ✅
  - `databases/repositories/` ✅
  - `databases/database.py` ✅
  - `databases/factory.py` ✅
- 预留能力层:
  - `messengers/queue/{kafka,rabbitmq}/` ⏳
  - `storages/object/s3/`, `storages/file/local/` ⏳
  - `engines/batch/spark/`, `engines/stream/flink/` ⏳

**状态**: ✅ 已完全解决

---

### 2. 测试类型维度混淆 ✅
**原始需求**: 性能测试、安全测试应该放在testing/下

**原始方案** (已废弃):
```
testing/
├── functional/       # 功能测试
├── performance/      # 性能测试
├── security/         # 安全测试
└── ...
```

**v3最终方案** (已实施):
```
testing/
├── assertions/       # 断言工具（所有测试都可用）
├── data/builders/    # 数据构建（所有测试都可用）
├── fixtures/         # Pytest fixtures（所有测试都可用）
├── plugins/          # Pytest插件（所有测试都可用）
└── debug/            # 调试工具（所有测试都可用）
```

**设计决策**:
- ✅ **不按测试类型组织**（api/ui/performance/security）
- ✅ **按功能职责组织**（assertions/fixtures/plugins）
- ✅ **原因**: 避免工具重复，任何测试类型都可以使用这些工具

**状态**: ✅ 已按更好的方式解决（审计已确认）

---

## 🔄 需要重新评估的遗漏点

以下遗漏点需要基于v3架构原则重新评估，看是否仍然适用。

---

### 3. 测试数据管理增强

#### 当前状态
```
testing/data/
└── builders/         # ✅ Builder模式（已实现）
```

#### 原始建议
```
testing/data/
├── builders/         # ✅ 已实现
├── factories/        # ❌ 未实现 - 基于Faker的随机数据生成
├── loaders/          # ❌ 未实现 - 从JSON/CSV/Excel加载
├── cleaners/         # ❌ 未实现 - 测试后清理
└── snapshots/        # ❌ 未实现 - 数据库快照
```

#### v3架构评估

**✅ 保留建议**:

1. **testing/data/factories/** - 随机数据生成
   - **理由**: 符合"测试数据构建"职责，与builders/并列
   - **用途**: 使用Faker库生成随机测试数据
   - **优先级**: P2
   - **示例**:
   ```python
   # testing/data/factories/user_factory.py
   from faker import Faker

   class UserFactory:
       def __init__(self):
           self.faker = Faker('zh_CN')

       def create_user(self, **overrides):
           return {
               'name': self.faker.name(),
               'email': self.faker.email(),
               'phone': self.faker.phone_number(),
               **overrides
           }
   ```

2. **testing/data/loaders/** - 数据加载器
   - **理由**: 符合"测试数据管理"职责
   - **用途**: 从外部文件加载测试数据（JSON/CSV/Excel/YAML）
   - **优先级**: P2
   - **示例**:
   ```python
   # testing/data/loaders/json_loader.py
   class JsonDataLoader:
       def load(self, file_path: str) -> dict:
           """从JSON文件加载测试数据"""
           pass
   ```

**⚠️ 需要调整**:

3. **testing/data/cleaners/** → **testing/fixtures/cleanup.py**
   - **原因**: 数据清理已在`testing/fixtures/cleanup.py`中实现
   - **决策**: ✅ **不需要新目录**，现有实现已满足需求
   - **状态**: ✅ 已解决（以不同形式实现）

4. **testing/data/snapshots/** - 数据库快照
   - **问题**: 这是否属于"测试数据"职责？
   - **重新评估**: 数据库快照更像是"数据库工具"而非"测试数据"
   - **建议**:
     - 选项A: 放在`databases/snapshots/`（属于能力层）
     - 选项B: 放在`testing/fixtures/`（作为fixture提供）
     - 选项C: 暂不实现（使用数据库自带工具）
   - **优先级**: P3（可选）

**结论**:
- ✅ `factories/` - 建议实现（P2）
- ✅ `loaders/` - 建议实现（P2）
- ✅ `cleaners/` - 已解决（在fixtures/cleanup.py中）
- ⚠️ `snapshots/` - 需要重新考虑归属（P3）

---

### 4. API验证机制

#### 原始建议
```
testing/validation/
└── response/
    ├── validator.py      # 响应验证器（Fluent API）
    ├── json_schema.py    # JSON Schema验证
    └── matchers.py       # 断言匹配器
```

#### v3架构评估

**问题分析**:
1. **与assertions/重复？** - testing/assertions/已存在，是否需要单独的validation/？
2. **职责边界模糊** - validator vs assertions的区别是什么？

**重新评估**:

**选项A: 合并到assertions/** (推荐)
```
testing/assertions/
├── __init__.py
├── base.py              # 基础断言（assertpy封装）
├── response.py          # ✅ 新增 - HTTP响应断言
├── json_schema.py       # ✅ 新增 - JSON Schema验证
└── matchers.py          # ✅ 新增 - 自定义匹配器
```

**选项B: 保留独立的validation/** (不推荐)
```
testing/validation/
└── response/            # 独立的验证器
```

**建议**: ✅ **选项A - 合并到assertions/**
- **理由1**: 避免概念混淆（assertions vs validation都是验证）
- **理由2**: 符合v3原则（按功能职责组织，不过度细分）
- **理由3**: 用户更容易找到（所有断言都在assertions/）

**优先级**: P2

**结论**:
- ❌ 不创建`testing/validation/`目录
- ✅ 在`testing/assertions/`中增强功能（response.py, json_schema.py）

---

### 5. Mock支持

#### 原始建议
```
testing/mocks/
├── http/             # HTTP Mock
├── database/         # 数据库Mock
└── time/             # 时间Mock
```

#### v3架构评估

**问题分析**:
1. **是否符合testing/职责？** - Mock是测试工具，符合
2. **是否有更好的位置？** - testing/mocks/似乎合理

**重新评估**:

**✅ 保留建议** - 创建`testing/mocks/`目录

**理由**:
- Mock是通用测试工具（所有测试都可能需要）
- 符合testing/按功能职责组织的原则
- 与fixtures/、plugins/并列，职责清晰

**建议实现**:
```
testing/mocks/
├── __init__.py
├── http/             # HTTP Mock（responses库封装）
│   └── mock_server.py
├── database/         # 数据库Mock（内存数据库）
│   └── sqlite_mock.py
└── time/             # 时间Mock（freezegun封装）
    └── time_mock.py
```

**示例**:
```python
# testing/mocks/http/mock_server.py
import responses

class HttpMock:
    """HTTP请求Mock"""
    def __init__(self):
        self.mock = responses.RequestsMock()

    def add_response(self, method: str, url: str, json: dict, status: int = 200):
        self.mock.add(method, url, json=json, status=status)
```

**优先级**: P2

**结论**: ✅ 建议实现`testing/mocks/`（P2）

---

### 6. 报告系统增强

#### 原始建议
```
testing/reporting/
├── allure/           # Allure报告
├── html/             # HTML报告
├── screenshots/      # 截图管理
└── videos/           # 视频录制
```

#### 当前状态
```
testing/plugins/
└── allure.py         # ✅ Allure集成已实现
```

#### v3架构评估

**问题分析**:
1. **Allure已在plugins/中实现** - 无需重复
2. **screenshots/videos/** - 这是"报告内容"还是"测试工具"？
3. **html/报告** - pytest已有HTML报告插件（pytest-html）

**重新评估**:

**选项A: 不创建reporting/目录** (推荐)
- Allure集成 → `testing/plugins/allure.py` ✅ 已实现
- HTML报告 → 使用`pytest-html`插件（外部依赖）
- 截图 → 在`testing/fixtures/ui_fixtures.py`中实现（失败自动截图）
- 视频 → Playwright自带录制功能

**选项B: 创建reporting/目录** (不推荐)
```
testing/reporting/
├── screenshots/      # 截图管理
│   └── manager.py
└── videos/           # 视频管理
    └── recorder.py
```

**建议**: ✅ **选项A - 不创建独立reporting/目录**
- **理由1**: 功能分散在更合适的位置（plugins/、fixtures/）
- **理由2**: 避免过度细分目录
- **理由3**: 符合v3原则（按功能职责组织）

**具体实现位置**:
- Allure集成 → `testing/plugins/allure.py` ✅
- 失败截图 → `testing/fixtures/ui_fixtures.py`（新增功能）
- 视频录制 → Playwright自带，通过配置启用

**优先级**: P3（可选，大部分已有解决方案）

**结论**:
- ❌ 不创建`testing/reporting/`目录
- ✅ 在现有位置增强功能（fixtures/ui_fixtures.py添加失败截图）

---

## 📊 汇总建议

### 建议实现（P2优先级）

| 功能 | 位置 | 理由 | 工作量 |
|------|------|------|--------|
| **随机数据生成** | `testing/data/factories/` | 补充测试数据构建能力 | 中 |
| **数据加载器** | `testing/data/loaders/` | 从外部文件加载测试数据 | 中 |
| **响应断言增强** | `testing/assertions/response.py` | HTTP响应专用断言 | 小 |
| **JSON Schema验证** | `testing/assertions/json_schema.py` | Schema验证能力 | 小 |
| **Mock支持** | `testing/mocks/` | HTTP/数据库/时间Mock | 中 |

### 已有解决方案（无需新增）

| 功能 | 现有实现 | 说明 |
|------|----------|------|
| **数据清理** | `testing/fixtures/cleanup.py` | ✅ 已实现 |
| **Allure报告** | `testing/plugins/allure.py` | ✅ 已实现 |
| **HTML报告** | 使用`pytest-html`插件 | 外部依赖 |
| **视频录制** | Playwright自带功能 | 通过配置启用 |

### 需要重新考虑（P3或暂不实现）

| 功能 | 问题 | 建议 |
|------|------|------|
| **数据库快照** | 归属不明确（能力层？工具层？） | 使用数据库自带工具，暂不实现 |
| **独立validation/目录** | 与assertions/重复 | 合并到assertions/ |
| **独立reporting/目录** | 功能分散更合适 | 不创建，使用现有方案 |

---

## 🎯 实施优先级

### Phase 2A: 测试数据增强（P2 - 建议近期实现）
**预计时间**: 2-3天

1. ✅ **实现testing/data/factories/**
   - 集成Faker库
   - 提供常用数据工厂（User、Order、Product等）
   - 编写单元测试

2. ✅ **实现testing/data/loaders/**
   - JSON加载器
   - CSV加载器
   - YAML加载器
   - 编写单元测试

### Phase 2B: 断言增强（P2 - 建议近期实现）
**预计时间**: 1-2天

3. ✅ **增强testing/assertions/**
   - 实现`response.py` - HTTP响应断言
   - 实现`json_schema.py` - JSON Schema验证
   - 实现`matchers.py` - 自定义匹配器
   - 编写单元测试

### Phase 2C: Mock支持（P2 - 建议中期实现）
**预计时间**: 2-3天

4. ✅ **实现testing/mocks/**
   - `mocks/http/` - HTTP Mock（基于responses库）
   - `mocks/database/` - 数据库Mock（SQLite内存）
   - `mocks/time/` - 时间Mock（基于freezegun）
   - 编写单元测试

### Phase 2D: UI测试增强（P3 - 可选）
**预计时间**: 1天

5. ✅ **增强testing/fixtures/ui_fixtures.py**
   - 实现失败自动截图
   - 集成Playwright视频录制
   - 编写单元测试

---

## 📝 实施检查清单

### Phase 2A: 测试数据增强
- [ ] 实现`testing/data/factories/`
  - [ ] 集成Faker库
  - [ ] 实现`UserFactory`
  - [ ] 实现`BaseFactory`抽象类
  - [ ] 编写单元测试
  - [ ] 更新文档
- [ ] 实现`testing/data/loaders/`
  - [ ] 实现`JsonLoader`
  - [ ] 实现`CsvLoader`
  - [ ] 实现`YamlLoader`
  - [ ] 编写单元测试
  - [ ] 更新文档

### Phase 2B: 断言增强
- [ ] 增强`testing/assertions/`
  - [ ] 实现`response.py`
  - [ ] 实现`json_schema.py`
  - [ ] 实现`matchers.py`
  - [ ] 编写单元测试
  - [ ] 更新文档

### Phase 2C: Mock支持
- [ ] 实现`testing/mocks/`
  - [ ] 实现`mocks/http/mock_server.py`
  - [ ] 实现`mocks/database/sqlite_mock.py`
  - [ ] 实现`mocks/time/time_mock.py`
  - [ ] 编写单元测试
  - [ ] 更新文档

### Phase 2D: UI测试增强
- [ ] 增强`testing/fixtures/ui_fixtures.py`
  - [ ] 实现失败自动截图
  - [ ] 集成视频录制
  - [ ] 编写单元测试
  - [ ] 更新文档

---

## 🔍 设计原则验证

所有建议的增强功能都符合v3架构原则：

| 原则 | 验证 |
|------|------|
| **按交互模式分类能力层** | ✅ 所有增强都在testing/层（测试支持层），不影响能力层 |
| **testing/按功能职责组织** | ✅ factories/loaders/assertions/mocks/都是功能职责分类 |
| **能力层与测试支持层解耦** | ✅ 所有工具适用于任何测试类型 |
| **避免概念混淆** | ✅ 废弃validation/和reporting/，避免与assertions/和plugins/混淆 |
| **避免过度细分** | ✅ 将功能合并到现有目录，不创建过多顶级目录 |

---

## 📚 相关文档

- **V3_ARCHITECTURE.md** - v3架构设计方案（核心原则）
- **V3_IMPLEMENTATION.md** - v3实施指南
- **ARCHITECTURE_AUDIT.md** - 架构审计报告
- **archive/REFACTORING_PLAN_V3.md** - 早期讨论（包含6个遗漏点）

---

## ✅ 结论

**核心架构已完成**: v3架构重构已100%完成，所有核心目标达成

**后续增强规划**:
- ✅ **建议实现** (P2): factories/, loaders/, assertions/增强, mocks/
- ❌ **不建议实现**: validation/, reporting/, snapshots/
- ✅ **已有解决方案**: cleaners/, Allure, HTML报告, 视频录制

**实施策略**:
- 作为独立的Phase 2任务逐步实现
- 不影响v3核心架构
- 所有功能符合v3设计原则

---

**文档创建日期**: 2025-11-03
**审核状态**: 待审核
**优先级**: P2-P3（非紧急，逐步实现）
