# DF Test Framework v3 - 架构重构方案

> 基于"能力层与测试类型层解耦"的可无限扩展架构
>
> 📅 日期: 2025-11-03
> 📌 版本: v3.0.0（最终整合版）
> 🚀 状态: 架构设计完成，准备实施
>
> **重要说明**: 项目仍在搭建阶段，未大规模使用，本次重构**不需要保留向后兼容性**，可以大胆调整使用方式。

---

## 📖 目录

- [第一部分：设计决策过程](#第一部分设计决策过程)
  - [1.1 初始问题识别](#11-初始问题识别)
  - [1.2 遗漏点补充](#12-遗漏点补充)
  - [1.3 架构演进历程](#13-架构演进历程)
- [第二部分：最终架构方案](#第二部分最终架构方案)
  - [2.1 架构核心突破](#21-架构核心突破)
  - [2.2 完整分层架构](#22-完整分层架构)
  - [2.3 核心设计原则](#23-核心设计原则)
  - [2.4 扩展性验证](#24-扩展性验证)
- [第三部分：实施指南](#第三部分实施指南)
  - [3.1 实施计划](#31-实施计划)
  - [3.2 目录结构对照](#32-目录结构对照)
  - [3.3 重要提醒](#33-重要提醒)

---

## 第一部分：设计决策过程

### 1.1 初始问题识别

#### 问题1: exceptions.py 放置不当

**现状**:
```
src/df_test_framework/
├── exceptions.py          # ⚠️ 单文件在顶级目录
├── infrastructure/
├── core/
├── patterns/
├── testing/
├── extensions/
├── models/
├── utils/
├── ui/
└── cli/
```

**问题分析**:
- 顶级目录已经有10个子目录，再加上单文件显得不够清晰
- exceptions 是基础设施部分，应该属于更底层的位置
- 可能引发循环依赖（如果放在 infrastructure/）

**解决方案**:
```
创建 common/ 作为 Layer 0（最底层）：
common/
├── exceptions.py     # 异常定义
├── types.py          # 类型定义
└── protocols.py      # 通用Protocol
```

**理由**:
- ✅ 符合分层架构原则（最基础的层）
- ✅ 避免循环依赖（所有层都可以依赖它）
- ✅ 保持顶级目录简洁

---

#### 问题2: patterns/ 目录概念混淆

**现状**:
```
patterns/
├── repositories/     # Repository模式
│   ├── base.py
│   └── query_spec.py
└── builders/         # Builder模式
    ├── base.py
    └── dict_builder.py
```

**问题分析**:
1. **Repository** 与数据库操作强相关，应该归属到数据处理能力层
2. **Builder** 是测试数据构建工具，应该归属到测试支持层
3. 两者职责完全不同，放在一起不合理

**解决方案**:
```
# Repository → engines/sql/repositories/
engines/
└── sql/
    ├── database.py           # 原 core/database/
    └── repositories/         # 原 patterns/repositories/
        ├── base.py
        └── query_spec.py

# Builder → testing/data/builders/
testing/
└── data/
    └── builders/             # 原 patterns/builders/
        ├── base.py
        └── dict_builder.py
```

**理由**:
- ✅ Repository 是数据访问层，属于 engines/sql/
- ✅ Builder 是测试数据构建工具，属于 testing/data/
- ✅ 职责清晰，归属明确

---

#### 问题3: UI/API 架构不对称

**现状**:
```
core/
└── http/              # API客户端
    ├── client.py
    └── base_api.py

ui/                    # UI模块
├── page.py
├── browser.py
└── locator.py
```

**问题分析**:
- API 在 `core/http/`，UI 在 `ui/`，层级不对称
- `core/http/` 暗示 HTTP 是核心业务，但实际上它是一种"能力"
- 难以扩展其他协议（GraphQL、gRPC）或其他驱动（Selenium、Appium）

**解决方案 - 对称架构**:
```
clients/              # API通信能力（与 drivers/ 对称）
├── rest/
│   ├── httpx/       # 默认实现
│   └── requests/    # 备选实现
├── graphql/         # 扩展
└── grpc/            # 扩展

drivers/              # UI交互能力（与 clients/ 对称）
├── web/
│   ├── playwright/  # 默认实现
│   └── selenium/    # 备选实现
└── mobile/          # 扩展
    └── appium/
```

**理由**:
- ✅ 对称设计，概念清晰
- ✅ 易于扩展新协议和新驱动
- ✅ Protocol+Adapter+Factory 模式统一

---

### 1.2 遗漏点补充

在初始讨论后，我们发现架构还缺少以下关键内容：

#### 遗漏点1: 数据测试能力

**问题**: 只有 API 和 UI 能力，缺少数据测试能力

**解决方案**: 新增 `engines/` 层
```
engines/              # 数据处理能力
├── sql/
│   ├── mysql/
│   ├── postgresql/
│   └── sqlite/
├── nosql/
│   ├── redis/
│   └── mongodb/
├── bigdata/
│   ├── spark/
│   ├── hive/
│   └── kafka/
├── etl/
└── stream/
```

**影响**: 数据测试成为一等公民，与 API、UI 同级

---

#### 遗漏点2: 测试类型维度混淆

**问题**: 性能测试、安全测试应该放在哪里？

**分析**:
```
❌ 错误理解：
testing/
├── performance/      # 性能测试放在 testing/？
└── security/         # 安全测试放在 testing/？

问题：功能测试去哪了？
```

**解决方案**: 测试类型作为独立维度
```
✅ 正确架构：
testing/
├── functional/       # 功能测试
├── performance/      # 性能测试
├── security/         # 安全测试
├── compatibility/    # 兼容性测试
├── integration/      # 集成测试
├── e2e/              # 端到端测试
├── data/             # 测试数据管理（通用工具）
├── validation/       # 验证器（通用工具）
├── mocks/            # Mock（通用工具）
└── reporting/        # 报告（通用工具）
```

**关键**: 任何测试类型都可以使用任何能力（矩阵组合）

---

#### 遗漏点3: 测试数据管理不完善

**问题**: 只有 Builder，缺少其他数据管理工具

**解决方案**:
```
testing/data/
├── builders/         # 数据构建器（已有）
├── factories/        # 数据工厂（新增 - 基于Faker生成随机数据）
├── loaders/          # 数据加载器（新增 - 从JSON/CSV/Excel加载）
├── cleaners/         # 数据清理器（新增 - 测试后清理）
└── snapshots/        # 数据快照（新增 - 数据库快照和恢复）
```

---

#### 遗漏点4: API 验证机制缺失

**问题**: 没有专门的 API 响应验证工具

**解决方案**:
```
testing/validation/
├── response/
│   ├── validator.py         # 响应验证器（Fluent API）
│   ├── json_schema.py       # JSON Schema验证
│   └── matchers.py          # 断言匹配器
└── fixtures.py
```

---

#### 遗漏点5: Mock 支持缺失

**问题**: 没有 Mock 外部依赖的工具

**解决方案**:
```
testing/mocks/
├── http/             # HTTP Mock（Mock外部API）
├── database/         # 数据库Mock（内存数据库）
├── time/             # 时间Mock（freezegun）
└── fixtures.py
```

---

#### 遗漏点6: 报告系统单一

**问题**: 只支持 Allure

**解决方案**:
```
testing/reporting/
├── allure/           # Allure报告
├── html/             # HTML报告
├── screenshots/      # 截图管理（失败自动截图）
└── videos/           # 视频录制（失败录制视频）
```

---

### 1.3 架构演进历程

我们的架构讨论经历了以下演进过程：

#### 阶段1: 发现问题
- exceptions.py 放置不当
- patterns/ 概念混淆
- UI/API 不对称

#### 阶段2: 初步方案
- 创建 `common/` 层
- 创建对称的 `clients/` 和 `drivers/`
- 拆分 `patterns/`

#### 阶段3: 补充遗漏
- 新增 `engines/` 层（数据处理能力）
- 完善 `testing/` 层（测试类型维度）
- 补充数据管理、验证、Mock、报告等

#### 阶段4: 最终共识
- **能力层与测试类型层完全解耦**
- **能力层开放扩展**（不限于clients/drivers/engines）
- **测试类型层开放扩展**（不限于functional/performance/security）
- **任何测试类型 × 任何能力 = 无限可能**

---

## 第二部分：最终架构方案

### 2.1 架构核心突破

经过深度讨论，我们发现了测试框架架构的本质问题，并给出了终极解决方案：

#### 问题：能力与测试类型混淆

```
❌ 错误的架构（v2及之前）：

clients/         # API能力
drivers/         # UI能力
core/
├── database/    # ❓ 数据库是能力？还是工具？
└── redis/       # ❓ Redis是能力？还是工具？
testing/
├── performance/ # ❓ 性能测试为什么在testing？
└── security/    # ❓ 安全测试为什么在testing？

问题：
1. 能力层不完整（缺少数据测试能力）
2. 概念混淆（数据库既是能力又是工具）
3. 测试类型不完整（功能测试去哪了？）
```

#### 解决方案：两个维度完全分离

```
✅ 正确的架构（v3）：

维度1: 能力层（Layer 1）- 定义"测试什么"
────────────────────────────────────────
clients/      - API通信能力
drivers/      - UI交互能力
engines/      - 数据处理能力
messengers/   - 消息队列能力（可扩展）
chains/       - 区块链能力（可扩展）
devices/      - IoT设备能力（可扩展）
storages/     - 文件存储能力（可扩展）
...           - 任意新能力（可扩展）

维度2: 测试类型层（Layer 3）- 定义"怎么测"
────────────────────────────────────────
testing/
├── functional/     - 功能测试
├── performance/    - 性能测试
├── security/       - 安全测试
├── compatibility/  - 兼容性测试
├── integration/    - 集成测试
├── e2e/            - 端到端测试
├── accessibility/  - 可访问性测试（可扩展）
├── chaos/          - 混沌测试（可扩展）
└── ...             - 任意新测试类型（可扩展）

关键：两个维度完全解耦，任意组合
──────────────────────────────────
任何测试类型 × 任何能力 = 无限可能

示例：
- 性能测试 × API能力 = API性能测试
- 性能测试 × UI能力 = UI性能测试
- 性能测试 × 数据能力 = 数据库性能测试
- 安全测试 × API能力 = API安全测试
- 安全测试 × 数据能力 = 数据安全测试
- 混沌测试 × 消息队列能力 = 消息队列混沌测试
- ...
```

---

### 2.2 完整分层架构

```
┌─────────────────────────────────────────────────────────┐
│ Layer 4: 扩展和工具层                                    │
│  extensions/  utils/  cli/                              │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 3: 测试类型层（定义"怎么测"）                      │
│  testing/                                               │
│   ├── functional/      - 功能测试                       │
│   ├── performance/     - 性能测试                       │
│   ├── security/        - 安全测试                       │
│   ├── compatibility/   - 兼容性测试                     │
│   ├── integration/     - 集成测试                       │
│   ├── e2e/             - 端到端测试                     │
│   ├── data/            - 测试数据管理（通用）            │
│   ├── validation/      - 验证器（通用）                 │
│   ├── mocks/           - Mock（通用）                   │
│   ├── reporting/       - 报告（通用）                   │
│   ├── fixtures/        - Pytest Fixtures（通用）        │
│   └── plugins/         - Pytest插件（通用）             │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 2: 基础设施层                                      │
│  infrastructure/                                        │
│   ├── bootstrap/  - 启动管理                           │
│   ├── config/     - 配置管理                           │
│   ├── logging/    - 日志系统                           │
│   ├── providers/  - 依赖注入                           │
│   └── runtime/    - 运行时上下文                       │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 1: 能力层（定义"测试什么"）- 开放式，可无限扩展    │
│                                                         │
│  clients/          - API通信能力                        │
│   ├── rest/          - REST API                        │
│   ├── graphql/       - GraphQL                         │
│   ├── grpc/          - gRPC                            │
│   └── websocket/     - WebSocket                       │
│                                                         │
│  drivers/          - UI交互能力                         │
│   ├── web/           - Web UI（Playwright/Selenium）  │
│   └── mobile/        - Mobile UI（Appium）            │
│                                                         │
│  engines/          - 数据处理能力                       │
│   ├── sql/           - SQL数据库（MySQL/PostgreSQL等） │
│   ├── nosql/         - NoSQL数据库（MongoDB/Redis等）  │
│   ├── bigdata/       - 大数据（Spark/Hive/Kafka等）   │
│   ├── etl/           - ETL                            │
│   └── stream/        - 流处理                         │
│                                                         │
│  messengers/      - 消息队列能力（未来扩展）            │
│   ├── rabbitmq/      - RabbitMQ                       │
│   ├── kafka/         - Kafka                          │
│   └── rocketmq/      - RocketMQ                       │
│                                                         │
│  chains/          - 区块链能力（未来扩展）              │
│   ├── ethereum/      - Ethereum                       │
│   └── bitcoin/       - Bitcoin                        │
│                                                         │
│  devices/         - IoT设备能力（未来扩展）             │
│   ├── mqtt/          - MQTT                           │
│   └── coap/          - CoAP                           │
│                                                         │
│  storages/        - 存储系统能力（未来扩展）            │
│   ├── s3/            - AWS S3                         │
│   ├── oss/           - 阿里云OSS                      │
│   └── ftp/           - FTP                            │
│                                                         │
│  ...              - 任意新能力（可扩展）                │
│                                                         │
└─────────────────────────────────────────────────────────┘
                         ↑ 依赖
┌─────────────────────────────────────────────────────────┐
│ Layer 0: 共享基础层                                      │
│  common/                                                │
│   ├── exceptions.py   - 异常定义                       │
│   ├── types.py        - 类型定义                       │
│   └── protocols.py    - 通用Protocol                   │
└─────────────────────────────────────────────────────────┘
```

**依赖规则**: Layer N 只能依赖 Layer N-1 及以下，不能依赖同层或上层

---

### 2.3 核心设计原则

#### 原则1: 能力层开放性

**能力层不是固定的"三层"，而是开放的、可按需扩展的**

```python
# ✅ 正确理解
能力层 = {
    "clients": "API通信能力",
    "drivers": "UI交互能力",
    "engines": "数据处理能力",
    # 未来可以添加：
    "messengers": "消息队列能力",
    "chains": "区块链能力",
    "devices": "IoT设备能力",
    "storages": "存储系统能力",
    # ... 无限扩展
}

# ❌ 错误理解
能力层 = ["clients", "drivers", "engines"]  # 固定三层
```

---

#### 原则2: 测试类型层开放性

**测试类型层也是开放的、可按需扩展的**

```python
# ✅ 正确理解
测试类型 = {
    "functional": "功能测试",
    "performance": "性能测试",
    "security": "安全测试",
    "compatibility": "兼容性测试",
    "integration": "集成测试",
    "e2e": "端到端测试",
    # 未来可以添加：
    "accessibility": "可访问性测试",
    "chaos": "混沌测试",
    "regression": "回归测试",
    "smoke": "冒烟测试",
    # ... 无限扩展
}
```

---

#### 原则3: 两个维度完全解耦

**任何测试类型都可以使用任何能力**

```
测试矩阵（示例）：

                  clients/  drivers/  engines/  messengers/  chains/
                  (API)     (UI)      (数据)    (消息队列)   (区块链)
functional/         ✓         ✓         ✓          ✓           ✓
performance/        ✓         ✓         ✓          ✓           ✓
security/           ✓         ✓         ✓          ✓           ✓
compatibility/      ✓         ✓         ✓          ✓           ✓
chaos/              ✓         ✓         ✓          ✓           ✓

说明：任意组合都是有效的测试场景
```

---

#### 原则4: Protocol+Adapter+Factory 模式

**所有能力层统一使用此模式，支持多种实现**

```python
# Step 1: 定义 Protocol（接口规范）
from typing import Protocol

class RestClientProtocol(Protocol):
    def get(self, url: str, **kwargs) -> Response: ...
    def post(self, url: str, **kwargs) -> Response: ...

# Step 2: 实现 Adapter（具体实现）
class HttpxRestClient:
    """httpx 实现"""
    def get(self, url: str, **kwargs):
        return self.client.get(url, **kwargs)

class RequestsRestClient:
    """requests 实现"""
    def get(self, url: str, **kwargs):
        return self.session.get(url, **kwargs)

# Step 3: 使用 Factory（运行时选择）
class RestClientFactory:
    _adapters = {
        "httpx": HttpxRestClient,
        "requests": RequestsRestClient,
    }

    @classmethod
    def create(cls, client_type: str = "httpx", **options):
        adapter_class = cls._adapters[client_type]
        return adapter_class(**options)

# Step 4: 配置化切换
# config.yaml
http_client:
  type: httpx  # 或 requests
```

---

### 2.4 扩展性验证

#### 场景1: 扩展新的能力 - 消息队列

**需求**：需要测试RabbitMQ消息队列

**实施步骤**：

```bash
# Step 1: 在Layer 1创建新能力层
mkdir -p src/df_test_framework/messengers/rabbitmq
```

```python
# Step 2: 实现能力（遵循Protocol+Adapter+Factory模式）

# messengers/rabbitmq/protocols.py
class MessageQueueProtocol(Protocol):
    def send(self, queue: str, message: str) -> None: ...
    def receive(self, queue: str, timeout: int = None) -> str: ...

# messengers/rabbitmq/client.py
class RabbitMQClient:
    """实现MessageQueueProtocol"""
    def send(self, queue: str, message: str):
        # 发送消息
        pass

# messengers/rabbitmq/factory.py
class RabbitMQFactory:
    @classmethod
    def create(cls, host: str, port: int) -> RabbitMQClient:
        return RabbitMQClient(host, port)
```

```python
# Step 3: 添加Fixture
# testing/fixtures/messenger_fixtures.py
@pytest.fixture
def rabbitmq_client():
    client = RabbitMQFactory.create(host="localhost", port=5672)
    yield client
    client.close()
```

```python
# Step 4: 使用（任何测试类型都可以使用）

# 功能测试
def test_message_functional(rabbitmq_client):
    """消息队列功能测试"""
    rabbitmq_client.send("test_queue", "hello")
    message = rabbitmq_client.receive("test_queue")
    assert message == "hello"

# 性能测试
def test_message_performance(rabbitmq_client):
    """消息队列性能测试"""
    from df_test_framework.testing.performance import PerformanceTimer

    with PerformanceTimer() as timer:
        for i in range(1000):
            rabbitmq_client.send("test_queue", f"message_{i}")

    assert timer.elapsed < 5.0  # 1000条消息<5秒

# 安全测试
def test_message_security(rabbitmq_client):
    """消息队列安全测试"""
    # 测试未授权访问
    # ...
```

**关键**：新增能力不影响任何现有代码！

---

#### 场景2: 扩展新的测试类型 - 混沌测试

**需求**：需要进行混沌测试（Chaos Testing）

**实施步骤**：

```bash
# Step 1: 在Layer 3创建新测试类型
mkdir -p src/df_test_framework/testing/chaos
```

```python
# testing/chaos/api/fault_injection.py
class APIFaultInjection:
    """API故障注入"""
    def inject_latency(self, endpoint: str, latency_ms: int):
        """注入延迟"""
        pass

    def inject_error(self, endpoint: str, error_code: int):
        """注入错误"""
        pass

# testing/chaos/data/db_chaos.py
class DatabaseChaos:
    """数据库混沌测试"""
    def kill_connection(self):
        """杀死连接"""
        pass

# testing/chaos/message/queue_chaos.py
class MessageQueueChaos:
    """消息队列混沌测试"""
    def inject_message_loss(self, queue: str, loss_rate: float):
        """注入消息丢失"""
        pass
```

```python
# Step 2: 使用（可以使用任何能力）

# 混沌测试 × API能力
def test_api_chaos(rest_client):
    """API混沌测试（使用clients/能力）"""
    fault = APIFaultInjection()
    fault.inject_latency("/api/users", latency_ms=5000)

    response = rest_client.get("/api/users")
    assert response.status_code == 504  # 超时

# 混沌测试 × 数据能力
def test_db_chaos(mysql_engine):
    """数据库混沌测试（使用engines/能力）"""
    chaos = DatabaseChaos()
    chaos.kill_connection()

    # 测试重连机制
    mysql_engine.reconnect()
    assert mysql_engine.is_connected()

# 混沌测试 × 消息队列能力
def test_mq_chaos(rabbitmq_client):
    """消息队列混沌测试（使用messengers/能力）"""
    chaos = MessageQueueChaos()
    chaos.inject_message_loss("test_queue", loss_rate=0.1)

    # 测试消息可靠性机制
    # ...
```

**关键**：新增测试类型可以使用所有能力！

---

#### 场景3: 扩展新的能力 - 区块链

**需求**：需要测试以太坊智能合约

**实施步骤**：

```bash
# Step 1: 创建区块链能力层
mkdir -p src/df_test_framework/chains/ethereum
```

```python
# chains/ethereum/protocols.py
class BlockchainProtocol(Protocol):
    def deploy_contract(self, contract_code: str) -> str: ...
    def call_function(self, contract_address: str, function: str, args: list) -> Any: ...

# chains/ethereum/client.py
from web3 import Web3

class EthereumClient:
    """以太坊客户端"""
    def __init__(self, node_url: str):
        self.w3 = Web3(Web3.HTTPProvider(node_url))

    def deploy_contract(self, contract_code: str) -> str:
        # 部署合约
        pass

    def call_function(self, contract_address: str, function: str, args: list):
        # 调用合约函数
        pass
```

```python
# Step 2: 使用（所有测试类型都可以使用）

# 功能测试
def test_contract_functional(ethereum_client):
    """智能合约功能测试（使用chains/能力）"""
    contract_address = ethereum_client.deploy_contract(contract_code)
    result = ethereum_client.call_function(contract_address, "transfer", [100])
    assert result == True

# 安全测试
def test_contract_security(ethereum_client):
    """智能合约安全测试"""
    from df_test_framework.testing.security.blockchain import ReentrancyScanner

    scanner = ReentrancyScanner()
    vulnerabilities = scanner.scan(contract_code)
    assert len(vulnerabilities) == 0
```

**关键**：架构完全支持，无需修改！

---

## 📊 架构优势总结

### 1. 无限扩展性

| 维度 | 扩展方式 | 影响范围 |
|------|---------|---------|
| **新增能力** | 在Layer 1添加新目录 | 无影响，所有测试类型自动可用 |
| **新增测试类型** | 在Layer 3添加新目录 | 无影响，可以使用所有能力 |
| **新增实现** | 在能力层添加Adapter | 无影响，通过配置切换 |

### 2. 组合爆炸的威力

```
假设：
- 5种能力（clients/drivers/engines/messengers/chains）
- 6种测试类型（functional/performance/security/chaos/integration/e2e）

组合数 = 5 × 6 = 30种测试场景

未来：
- 10种能力
- 10种测试类型

组合数 = 10 × 10 = 100种测试场景

所有场景都自动支持！
```

### 3. 清晰的概念模型

```
问题：我要测试XXX

Step 1: 确定能力（测试什么）
  - 是API吗？       → clients/
  - 是UI吗？        → drivers/
  - 是数据吗？      → engines/
  - 是消息队列吗？  → messengers/
  - 是区块链吗？    → chains/

Step 2: 确定测试类型（怎么测）
  - 功能测试？      → testing/functional/
  - 性能测试？      → testing/performance/
  - 安全测试？      → testing/security/
  - 混沌测试？      → testing/chaos/

Step 3: 组合使用
  例如：API性能测试 = testing/performance/api/ + clients/rest/
```

---

## 第三部分：实施指南

### 3.1 实施计划

#### Phase 1: 核心架构重构（P0 - 必须实现）

**目标**: 完成基础架构迁移，保证现有功能正常工作

**任务清单**:

1. ✅ **创建新目录结构**
   ```bash
   mkdir -p src/df_test_framework/common
   mkdir -p src/df_test_framework/clients/rest/httpx
   mkdir -p src/df_test_framework/drivers/web/playwright
   mkdir -p src/df_test_framework/engines/sql
   mkdir -p src/df_test_framework/engines/nosql/redis
   ```

2. ✅ **移动现有文件**
   ```bash
   # exceptions.py → common/exceptions.py
   # models/types.py → common/types.py
   # core/http/ → clients/rest/httpx/
   # ui/ → drivers/web/playwright/
   # core/database/ → engines/sql/
   # core/redis/ → engines/nosql/redis/
   # patterns/repositories/ → engines/sql/repositories/
   # patterns/builders/ → testing/data/builders/
   ```

3. ✅ **更新所有导入语句**
   - 使用 IDE 的重构功能批量更新
   - 运行测试确保无遗漏

4. ✅ **更新顶层 `__init__.py`**
   - 重新导出所有公共 API
   - 确保用户使用方式简洁

5. ✅ **运行测试验证**
   ```bash
   pytest -v
   ```

**预计时间**: 1-2天

---

#### Phase 2: 完善测试支持（P1 - 重要）

**目标**: 补充遗漏的测试支持功能

**任务清单**:

1. ✅ **实现测试数据管理**
   ```bash
   mkdir -p src/df_test_framework/testing/data/factories
   mkdir -p src/df_test_framework/testing/data/loaders
   mkdir -p src/df_test_framework/testing/data/cleaners
   mkdir -p src/df_test_framework/testing/data/snapshots
   ```

2. ✅ **实现 API 验证系统**
   ```bash
   mkdir -p src/df_test_framework/testing/validation/response
   ```

3. ✅ **实现 Mock 支持**
   ```bash
   mkdir -p src/df_test_framework/testing/mocks/http
   mkdir -p src/df_test_framework/testing/mocks/database
   mkdir -p src/df_test_framework/testing/mocks/time
   ```

4. ✅ **完善报告系统**
   ```bash
   mkdir -p src/df_test_framework/testing/reporting/screenshots
   mkdir -p src/df_test_framework/testing/reporting/videos
   ```

**预计时间**: 2-3天

---

#### Phase 3: 备选实现（P2 - 可选）

**目标**: 实现备选的适配器，验证可插拔性

**任务清单**:

1. ✅ **实现 requests 适配器**
   ```bash
   mkdir -p src/df_test_framework/clients/rest/requests
   ```

2. ✅ **实现 Selenium 适配器**
   ```bash
   mkdir -p src/df_test_framework/drivers/web/selenium
   ```

3. ✅ **验证配置切换**
   ```yaml
   # config.yaml
   http_client:
     type: requests  # 从 httpx 切换到 requests

   web_driver:
     type: selenium  # 从 playwright 切换到 selenium
   ```

**预计时间**: 1-2天

---

#### Phase 4: 扩展功能（P3 - 未来规划）

**目标**: 按需实现扩展能力和测试类型

**可选任务**:

- `clients/graphql/` - GraphQL 客户端
- `engines/bigdata/spark/` - Spark 引擎
- `messengers/rabbitmq/` - RabbitMQ 客户端
- `testing/performance/` - 性能测试完整实现
- `testing/security/` - 安全测试完整实现
- `testing/chaos/` - 混沌测试

**按需实施，不设时间限制**

---

### 3.2 目录结构对照

#### v2 → v3 文件迁移对照表

| v2 路径 | v3 路径 | 说明 |
|---------|---------|------|
| `exceptions.py` | `common/exceptions.py` | 移到共享基础层 |
| `models/types.py` | `common/types.py` | 移到共享基础层 |
| `core/http/client.py` | `clients/rest/httpx/client.py` | REST客户端 |
| `core/http/base_api.py` | `clients/rest/httpx/base_api.py` | 基础API类 |
| `ui/page.py` | `drivers/web/playwright/page.py` | 页面对象 |
| `ui/browser.py` | `drivers/web/playwright/browser.py` | 浏览器管理 |
| `ui/locator.py` | `drivers/web/playwright/locator.py` | 定位器 |
| `core/database/` | `engines/sql/` | SQL引擎 |
| `core/redis/` | `engines/nosql/redis/` | Redis引擎 |
| `patterns/repositories/` | `engines/sql/repositories/` | Repository模式 |
| `patterns/builders/` | `testing/data/builders/` | Builder模式 |
| `infrastructure/*` | `infrastructure/*` | 保持不变 |
| `extensions/*` | `extensions/*` | 保持不变 |
| `utils/*` | `utils/*` | 保持不变 |
| `cli/*` | `cli/*` | 保持不变 |

---

### 3.3 重要提醒

#### ⚠️ 不需要向后兼容

**用户确认**: 项目仍在搭建阶段，未大规模使用，可以大胆重构

**影响**:
- ✅ 不需要保留旧的导入路径
- ✅ 不需要实现兼容性层
- ✅ 可以直接修改使用方式
- ✅ 可以删除不合理的设计

**行动**:
- 直接按照 v3 架构实施
- 更新所有示例代码和文档
- 通知用户迁移到新的使用方式

---

#### 📋 实施检查清单

- [ ] Phase 1: 核心架构重构完成
  - [ ] 创建新目录结构
  - [ ] 移动现有文件
  - [ ] 更新导入语句
  - [ ] 更新 `__init__.py`
  - [ ] 所有测试通过
- [ ] Phase 2: 完善测试支持
  - [ ] 数据管理系统
  - [ ] API验证系统
  - [ ] Mock支持
  - [ ] 报告系统
- [ ] Phase 3: 备选实现（可选）
  - [ ] requests 适配器
  - [ ] Selenium 适配器
  - [ ] 配置切换验证
- [ ] 文档更新
  - [ ] README.md
  - [ ] API文档
  - [ ] 示例代码
  - [ ] 迁移指南
- [ ] 最终验证
  - [ ] 覆盖率测试
  - [ ] 集成测试
  - [ ] 用户验收

---

## ✅ 架构设计完成标志

我们的架构讨论已经达成共识，关键点：

1. ✅ **不是"三层对称"**，而是"能力层可无限扩展"
2. ✅ **不是固定结构**，而是"开放式架构"
3. ✅ **核心是解耦**：能力层 ⊥ 测试类型层
4. ✅ **扩展验证通过**：消息队列、区块链、IoT等都可以无缝扩展
5. ✅ **测试类型验证通过**：混沌测试、可访问性测试等都可以无缝扩展
6. ✅ **不需要向后兼容**：项目搭建阶段，可以大胆重构

---

**🎉 架构设计完成！准备开始实施！**

---

## 附录

### 附录A: 完整目录结构

```
src/df_test_framework/
├── common/                          # Layer 0: 共享基础
│   ├── exceptions.py
│   ├── types.py
│   └── protocols.py
│
├── clients/                         # Layer 1: API通信能力
│   ├── rest/
│   │   ├── protocols.py
│   │   ├── httpx/                   # 默认实现
│   │   │   ├── client.py
│   │   │   └── base_api.py
│   │   └── requests/                # 备选实现
│   ├── graphql/                     # 预留
│   ├── grpc/                        # 预留
│   └── websocket/                   # 预留
│
├── drivers/                         # Layer 1: UI交互能力
│   ├── web/
│   │   ├── protocols.py
│   │   ├── playwright/              # 默认实现
│   │   │   ├── browser.py
│   │   │   ├── page.py
│   │   │   └── locator.py
│   │   └── selenium/                # 备选实现
│   └── mobile/                      # 预留
│       └── appium/
│
├── engines/                         # Layer 1: 数据处理能力
│   ├── sql/
│   │   ├── database.py
│   │   └── repositories/
│   │       ├── base.py
│   │       └── query_spec.py
│   ├── nosql/
│   │   ├── redis/
│   │   └── mongodb/                 # 预留
│   ├── bigdata/                     # 预留
│   │   ├── spark/
│   │   ├── hive/
│   │   └── kafka/
│   ├── etl/                         # 预留
│   └── stream/                      # 预留
│
├── infrastructure/                  # Layer 2: 基础设施
│   ├── bootstrap/
│   ├── config/
│   ├── logging/
│   ├── providers/
│   └── runtime/
│
├── testing/                         # Layer 3: 测试类型层
│   ├── functional/                  # 功能测试
│   ├── performance/                 # 性能测试
│   ├── security/                    # 安全测试
│   ├── compatibility/               # 兼容性测试（预留）
│   ├── integration/                 # 集成测试（预留）
│   ├── e2e/                         # 端到端测试（预留）
│   │
│   ├── data/                        # 测试数据管理（通用）
│   │   ├── builders/
│   │   ├── factories/
│   │   ├── loaders/
│   │   ├── cleaners/
│   │   └── snapshots/
│   │
│   ├── validation/                  # 验证器（通用）
│   │   └── response/
│   │
│   ├── mocks/                       # Mock（通用）
│   │   ├── http/
│   │   ├── database/
│   │   └── time/
│   │
│   ├── reporting/                   # 报告（通用）
│   │   ├── allure/
│   │   ├── html/
│   │   ├── screenshots/
│   │   └── videos/
│   │
│   ├── fixtures/                    # Pytest Fixtures
│   │   ├── core_fixtures.py
│   │   ├── client_fixtures.py
│   │   ├── driver_fixtures.py
│   │   └── engine_fixtures.py
│   │
│   ├── plugins/                     # Pytest插件
│   │   ├── allure.py
│   │   ├── markers.py
│   │   └── debug.py
│   │
│   └── debug/                       # 调试工具
│       ├── http_debugger.py
│       └── db_debugger.py
│
├── extensions/                      # Layer 4: 扩展系统
│   ├── core/
│   └── builtin/
│
├── utils/                           # Layer 4: 工具函数
│   ├── assertion.py
│   ├── decorator.py
│   ├── performance.py
│   └── data_generator.py
│
├── cli/                             # Layer 4: 命令行工具
│   ├── commands/
│   ├── templates/
│   └── main.py
│
└── __init__.py
```

### 附录B: 参考文档

本文档整合了以下讨论过程：
- `1.md` - 初始问题识别（exceptions.py、patterns/）
- `2.md` - 遗漏点补充（性能测试、数据管理、Mock等）
- `REFACTORING_PLAN_V3_COMPLETE.md` - 第一版完整架构方案
- `REFACTORING_PLAN_V3_FINAL.md` - 强调开放扩展性的最终版

以上讨论文档已归档至 `docs/architecture/archive/`
