# DF Test Framework - 快速参考

> **版本**: v3.0.0 | **更新**: 2025-11-04

---

## 🚀 快速开始

```bash
# 创建项目
df-test init my-project

# 配置环境
cp .env.example .env && vim .env

# 运行测试
pytest -v
```

---

## 📦 核心导入

```python
# 基础设施
from df_test_framework import (
    Bootstrap,              # 启动器
    RuntimeContext,         # 运行时上下文
    FrameworkSettings,      # 配置基类
)

# HTTP客户端
from df_test_framework import (
    HttpClient,             # HTTP客户端
    BaseAPI,                # API基类
    BusinessError,          # 业务异常
)

# 认证
from df_test_framework import (
    BearerTokenInterceptor,      # Bearer Token
    BasicAuthInterceptor,        # Basic认证
    APIKeyInterceptor,           # API Key
    SignatureInterceptor,        # 签名认证
)

# 数据库
from df_test_framework import (
    Database,               # 数据库客户端
    BaseRepository,         # Repository基类
    RedisClient,            # Redis客户端
)

# 设计模式
from df_test_framework import (
    BaseBuilder,            # Builder基类
    DictBuilder,            # 字典Builder
)

# 测试支持
from df_test_framework.testing.plugins import (
    step,                   # Allure步骤
    attach_json,            # 附加JSON
    attach_log,             # 附加日志
)
```

---

## ⚙️ 配置示例

**config/settings.py**:

```python
from pydantic import Field
from pydantic_settings import SettingsConfigDict
from df_test_framework import FrameworkSettings
from df_test_framework.infrastructure.config import HTTPSettings

class MySettings(FrameworkSettings):
    # v3.5+ 使用HTTPSettings
    http_settings: HTTPSettings = Field(
        default_factory=lambda: HTTPSettings(
            base_url="http://localhost:8000/api",
            timeout=30,
        ),
        description="HTTP配置"
    )

    # 自定义配置
    test_user: str = Field(default="test_user", env="TEST_USER")

    model_config = SettingsConfigDict(
        env_prefix="MY_",
        env_file=".env",
    )
```

**pytest.ini**:

```ini
[pytest]
df_settings_class = config.settings.MySettings
```

**.env**:

```bash
MY_HTTP_BASE_URL=http://api.example.com
TEST_USER=admin
```

---

## 🌐 HTTP客户端

### 基础用法

```python
def test_http(http_client):
    # GET
    response = http_client.get("/users/1")

    # POST
    response = http_client.post("/users", json={"name": "张三"})

    # PUT
    response = http_client.put("/users/1", json={"name": "李四"})

    # DELETE
    response = http_client.delete("/users/1")

    # 带参数和请求头
    response = http_client.get(
        "/users",
        params={"page": 1, "size": 10},
        headers={"Authorization": "Bearer token"}
    )
```

### 封装API客户端

```python
from df_test_framework import BaseAPI

class UserAPI(BaseAPI):
    def __init__(self, http_client):
        super().__init__(http_client)
        self.base_path = "/users"

    def get_user(self, user_id: str):
        response = self.http_client.get(f"{self.base_path}/{user_id}")
        data = response.json()
        self._check_business_error(data)
        return data["data"]

    def _check_business_error(self, data: dict):
        if data.get("code") != 200:
            from df_test_framework import BusinessError
            raise BusinessError(data.get("message"))
```

### 添加认证

```python
# Bearer Token
from df_test_framework import BearerTokenInterceptor

@pytest.fixture
def auth_client(http_client):
    interceptor = BearerTokenInterceptor("your_token")
    http_client.add_request_interceptor(interceptor)
    return http_client

# 签名认证（高级用法）
# ⚠️ v3.5+ 推荐在settings.py中使用SignatureInterceptorSettings配置
from df_test_framework import (
    SignatureInterceptor,
    MD5SortedValuesStrategy,
    SignatureConfig,
)

@pytest.fixture
def signed_client(http_client):
    """手动添加签名拦截器（高级用法）

    v3.5+ 推荐：在settings.py中声明式配置
    详见：docs/user-guide/configuration.md
    """
    config = SignatureConfig(
        app_id="app_id",
        app_secret="app_secret",
    )
    strategy = MD5SortedValuesStrategy(config)
    interceptor = SignatureInterceptor(strategy, config)
    http_client.add_request_interceptor(interceptor)
    return http_client
```

---

## 💾 数据库操作

### 直接使用Database

```python
def test_db(database):
    # 查询单条
    user = database.query_one(
        "SELECT * FROM users WHERE id = :id",
        {"id": 1}
    )

    # 查询多条
    users = database.query_all(
        "SELECT * FROM users WHERE status = :status",
        {"status": "ACTIVE"}
    )

    # 插入
    user_id = database.insert("users", {
        "username": "test_user",
        "email": "test@example.com"
    })

    # 更新
    database.update(user_id, {"status": "INACTIVE"})

    # 删除
    database.delete("users", {"id": user_id})
```

### 使用Repository

```python
from df_test_framework import BaseRepository

class UserRepo(BaseRepository):
    def __init__(self, db):
        super().__init__(db, table_name="users")

    def find_by_username(self, username: str):
        return self.find_one({"username": username})

    def find_active_users(self):
        return self.find_all(
            conditions={"status": "ACTIVE"},
            order_by="created_at DESC"
        )

# 使用
@pytest.fixture
def user_repo(database):
    return UserRepo(database)

def test_repo(user_repo):
    user = user_repo.find_by_username("test_user")
```

### Unit of Work 模式（v3.7推荐）

```python
# uow.py - 项目中实现
from df_test_framework.infrastructure.database import BaseUnitOfWork

class ProjectUoW(BaseUnitOfWork):
    def __init__(self, engine):
        super().__init__(engine)

    @property
    def users(self):
        return UserRepository(self._session)

# conftest.py
@pytest.fixture
def uow(database):
    with ProjectUoW(database.engine) as uow:
        yield uow
        # 默认自动回滚，调用 uow.commit() 持久化

# 测试
def test_with_uow(user_api, uow):
    # 创建数据
    result = user_api.create_user({"username": "test"})

    # 验证数据库 - 使用UoW的Repository
    user = uow.users.find_by_id(result["user_id"])
    assert user is not None

    # ✅ 测试结束后自动回滚
```

---

## 🎲 Redis操作

```python
def test_redis(redis_client):
    # 字符串
    redis_client.set("key", "value", ex=60)
    value = redis_client.get("key")

    # 哈希
    redis_client.hset("user:1", "name", "张三")
    name = redis_client.hget("user:1", "name")
    user = redis_client.hgetall("user:1")

    # 列表
    redis_client.lpush("queue", "item1")
    items = redis_client.lrange("queue", 0, -1)

    # 集合
    redis_client.sadd("tags", "python", "testing")
    tags = redis_client.smembers("tags")
```

---

## 🏗️ Builder模式

```python
from df_test_framework import DictBuilder

class UserBuilder:
    def __init__(self):
        self._builder = DictBuilder({
            "username": "default",
            "email": "default@example.com"
        })

    def with_username(self, username: str):
        self._builder.set("username", username)
        return self

    def with_email(self, email: str):
        self._builder.set("email", email)
        return self

    def build(self):
        return self._builder.build()

# 使用
user_data = (
    UserBuilder()
    .with_username("test_user")
    .with_email("test@example.com")
    .build()
)
```

---

## 🧪 Pytest Fixtures

### 框架提供

| Fixture | 说明 | 作用域 |
|---------|------|--------|
| `runtime` | 运行时上下文 | session |
| `http_client` | HTTP客户端 | session |
| `database` | 数据库客户端 | session |
| `redis_client` | Redis客户端 | session |

### 自定义Fixtures

```python
# conftest.py

# Session级别
@pytest.fixture(scope="session")
def test_config():
    return {"test_user": "admin"}

# Function级别
@pytest.fixture
def test_user_data():
    return {"username": "test", "email": "test@example.com"}

# Unit of Work（带清理）
@pytest.fixture
def uow(database):
    from your_project.uow import ProjectUoW
    with ProjectUoW(database.engine) as uow:
        yield uow
        # 默认自动回滚

# API客户端
@pytest.fixture
def user_api(http_client):
    from apis import UserAPI
    return UserAPI(http_client)

# Repository
@pytest.fixture
def user_repo(database):
    from repositories import UserRepo
    return UserRepo(database)
```

---

## 📊 Allure报告

```python
import allure
from df_test_framework.testing.plugins import step, attach_json

@allure.feature("用户管理")
@allure.story("用户创建")
class TestUserCreation:

    @allure.title("测试创建用户成功")
    @allure.severity(allure.severity_level.CRITICAL)
    @pytest.mark.smoke
    def test_create_user(self, user_api):
        """测试创建用户"""

        with step("准备测试数据"):
            user_data = {"username": "test"}
            attach_json(user_data, name="请求数据")

        with step("调用API"):
            result = user_api.create_user(user_data)
            attach_json(result, name="响应数据")

        with step("验证结果"):
            assert result["username"] == "test"
```

---

## 🏷️ Pytest标记

```python
# 定义标记（conftest.py）
def pytest_configure(config):
    config.addinivalue_line("markers", "smoke: 冒烟测试")
    config.addinivalue_line("markers", "p0: P0优先级")

# 使用标记
@pytest.mark.smoke
@pytest.mark.p0
def test_critical():
    pass

# 运行特定标记
# pytest -m smoke
# pytest -m "p0 or p1"
# pytest -m "smoke and not slow"
```

---

## 🔍 调试

```python
# HTTP调试
from df_test_framework.testing.debug import enable_http_debug

def test_debug(http_client):
    enable_http_debug()
    response = http_client.get("/users/1")

# 数据库调试
from df_test_framework.testing.debug import enable_db_debug

def test_db_debug(database):
    enable_db_debug()
    user = database.query_one("SELECT * FROM users WHERE id = 1")

# 日志
from loguru import logger

logger.info("信息日志")
logger.debug("调试日志")
logger.error("错误日志")
```

---

## ⚡ 常用命令

```bash
# 运行所有测试
pytest

# 运行指定文件
pytest tests/api/test_user.py

# 运行指定测试
pytest tests/api/test_user.py::TestUser::test_create_user

# 运行标记
pytest -m smoke

# 并行运行
pytest -n auto

# 详细输出
pytest -v

# 显示打印
pytest -s

# 失败时停止
pytest -x

# 重新运行失败的测试
pytest --lf

# 生成Allure报告
pytest --alluredir=allure-results
allure serve allure-results

# 生成HTML报告
pytest --html=report.html --self-contained-html

# 覆盖率
pytest --cov=src --cov-report=html
```

---

## 📂 项目结构

```
my-project/
├── config/
│   └── settings.py          # 配置
├── apis/
│   ├── base.py              # API基类
│   └── user_api.py          # 用户API
├── repositories/
│   └── user_repo.py         # 用户Repository
├── builders/
│   └── user_builder.py      # 用户Builder
├── fixtures/
│   └── data_cleaners.py     # 数据清理
├── tests/
│   ├── conftest.py          # Pytest配置
│   └── api/
│       └── test_user.py     # 测试用例
├── .env                      # 环境变量
├── pytest.ini               # Pytest配置
└── pyproject.toml           # 项目配置
```

---

## 🔗 相关链接

- [使用手册](USER_MANUAL.md) - 完整使用手册
- [最佳实践](BEST_PRACTICES.md) - 最佳实践指南
- [API参考](../api-reference/README.md) - API文档
- [示例代码](../../examples/) - 示例代码

---

**快速查询完毕！开始编写测试吧 🚀**
