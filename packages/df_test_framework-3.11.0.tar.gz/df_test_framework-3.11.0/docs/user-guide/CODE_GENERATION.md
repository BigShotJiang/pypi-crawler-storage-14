# 代码生成工具 - 使用指南

> **版本**: v3.2.0
> **更新**: 2025-11-05
> **功能**: 自动生成Pydantic模型、Builder、Repository等代码，减少80%的重复劳动

---

## 📖 概述

DF Test Framework 提供了强大的代码生成工具，可以帮助您快速生成测试所需的各种代码文件。

**核心优势**:
- ✅ 从JSON响应自动生成Pydantic模型
- ✅ 自动类型推断和字段转换
- ✅ 支持嵌套对象和数组
- ✅ 自动驼峰↔蛇形命名转换
- ✅ 减少80%的模型定义工作量

---

## 🚀 快速开始

### 1. 从JSON响应生成模型

最常见的场景：从API响应JSON自动生成Pydantic模型。

#### 步骤1: 保存API响应

```bash
# 方式1: 直接保存响应
curl http://api.example.com/users/123 > user_response.json

# 方式2: 手动创建JSON文件
cat > order_response.json << 'EOF'
{
  "code": 200,
  "message": "success",
  "data": {
    "orderNo": "ORDER123456",
    "userId": "user_001",
    "items": [
      {"itemId": "item_001", "price": 99.99}
    ]
  }
}
EOF
```

#### 步骤2: 生成Pydantic模型

```bash
# 在项目根目录执行
df-test gen models order_response.json
```

**输出**:
```
✅ 模型文件生成成功！
📁 文件路径: src/my_project/models/responses/order_response.py

💡 使用示例:
  from my_project.models.responses import OrderResponse, OrderResponseData
  response: OrderResponse = ...
  print(response.data)
```

#### 步骤3: 查看生成的代码

```python
# src/my_project/models/responses/order_response.py
"""自动生成的Pydantic模型

使用 df-test gen models 命令生成
"""

from __future__ import annotations

from typing import List, Optional, Any
from pydantic import BaseModel, Field
from df_test_framework.models.responses import BaseResponse


class Item(BaseModel):
    """自动生成的数据模型"""
    item_id: str = Field(..., alias="itemId", description="itemId字段")
    price: float = Field(..., description="price字段")


class OrderResponseData(BaseModel):
    """自动生成的数据模型"""
    order_no: str = Field(..., alias="orderNo", description="orderNo字段")
    user_id: str = Field(..., alias="userId", description="userId字段")
    items: List[Item] = Field(..., description="items字段")


class OrderResponse(BaseResponse[OrderResponseData]):
    """响应模型"""
    pass
```

---

## 🎯 使用场景

### 场景1: 快速对接新API

当后端提供了新接口时，您可以快速生成对应的模型：

```bash
# 1. 调用API并保存响应
curl -X POST http://api/cards/create \
  -H "Content-Type: application/json" \
  -d '{"userId":"user_001","quantity":2}' \
  > card_create_response.json

# 2. 生成模型（自定义模型名）
df-test gen models card_create_response.json --name CardCreateResponse

# 3. 立即使用
```

**效果**:
- ⏱️ 时间: 30分钟 → 2分钟 (减少93%)
- ✅ 零错误: 自动生成，避免手工输入错误
- 📝 完整文档: 自动生成Field描述

### 场景2: 批量生成模型

当需要对接多个API时，可以批量生成：

```bash
# 保存多个API响应
curl http://api/users/list > responses/user_list.json
curl http://api/users/1 > responses/user_detail.json
curl http://api/orders/1 > responses/order_detail.json

# 批量生成
for file in responses/*.json; do
  df-test gen models "$file"
done
```

### 场景3: 复杂嵌套结构

生成器自动处理复杂的嵌套对象：

**输入JSON**:
```json
{
  "code": 200,
  "data": {
    "orderNo": "ORDER123",
    "items": [
      {
        "itemId": "item_001",
        "product": {
          "productId": "prod_001",
          "name": "产品A",
          "specs": {
            "color": "红色",
            "size": "L"
          }
        }
      }
    ]
  }
}
```

**生成**:
```bash
df-test gen models order_detail.json --name OrderDetailResponse
```

**输出**: 自动生成5个类（OrderDetailResponseData, Item, Product, Specs, OrderDetailResponse）

---

## 📋 命令参考

### `df-test gen models`

从JSON响应生成Pydantic模型。

#### 语法

```bash
df-test gen models <json_file> [选项]
```

#### 参数

| 参数 | 必需 | 说明 | 示例 |
|------|:----:|------|------|
| `json_file` | ✅ | JSON文件路径 | `response.json` |
| `--name` | ❌ | 模型名称（默认根据文件名生成） | `--name UserResponse` |
| `--output-dir` | ❌ | 输出目录 | `--output-dir src/models` |
| `--force` | ❌ | 强制覆盖已存在的文件 | `--force` |

#### 示例

```bash
# 基础用法（自动推断模型名）
df-test gen models user_detail.json
# 生成: UserDetailResponse

# 自定义模型名
df-test gen models response.json --name CustomUserResponse

# 指定输出目录
df-test gen models data.json --output-dir src/custom/models

# 强制覆盖
df-test gen models data.json --force
```

---

## ⚙️ 功能特性

### 1. 自动类型推断

生成器智能推断Python类型：

| JSON类型 | Python类型 | 示例 |
|----------|------------|------|
| `"text"` | `str` | `name: str` |
| `123` | `int` | `age: int` |
| `123.45` | `float` | `price: float` |
| `true` | `bool` | `is_active: bool` |
| `null` | `Optional[Any]` | `data: Optional[Any]` |
| `["a","b"]` | `List[str]` | `tags: List[str]` |
| `[{...}]` | `List[Model]` | `items: List[Item]` |
| `{...}` | `Model` | `profile: Profile` |

### 2. 字段命名转换

自动处理驼峰↔蛇形命名：

```python
# JSON中的驼峰命名
{
  "userId": "123",
  "orderNo": "ORDER001",
  "createdAt": "2025-01-05"
}

# 自动生成为蛇形命名 + alias
class DataModel(BaseModel):
    user_id: str = Field(..., alias="userId", description="userId字段")
    order_no: str = Field(..., alias="orderNo", description="orderNo字段")
    created_at: str = Field(..., alias="createdAt", description="createdAt字段")
```

### 3. 嵌套对象处理

自动识别并生成嵌套类：

```python
# 输入
{
  "user": {
    "profile": {
      "name": "张三"
    }
  }
}

# 输出（按依赖顺序）
class Profile(BaseModel):
    name: str = Field(..., description="name字段")

class User(BaseModel):
    profile: Profile = Field(..., description="profile字段")

class DataModel(BaseModel):
    user: User = Field(..., description="user字段")
```

### 4. 数组类型处理

智能处理基础类型数组和对象数组：

```python
# 基础类型数组
"tags": ["vip", "active"]  →  tags: List[str]

# 对象数组
"items": [{"id": "001"}]  →  items: List[Item]
```

### 5. BaseResponse包装

自动生成符合框架规范的响应模型：

```python
# 标准响应格式
{
  "code": 200,
  "message": "success",
  "data": {...}
}

# 自动生成
class UserResponseData(BaseModel):  # data内容
    ...

class UserResponse(BaseResponse[UserResponseData]):  # 响应包装
    pass
```

---

## 💡 最佳实践

### 1. 文件组织

建议的目录结构：

```
src/my_project/
├── models/
│   ├── requests/        # 请求模型（手动编写）
│   │   ├── __init__.py
│   │   └── user_create_request.py
│   └── responses/       # 响应模型（自动生成）
│       ├── __init__.py
│       ├── user_list_response.py
│       ├── user_detail_response.py
│       └── order_create_response.py
└── apis/
    └── user_api.py
```

### 2. 命名约定

```bash
# JSON文件命名: <entity>_<action>_response.json
user_list_response.json
user_create_response.json
order_detail_response.json

# 生成的模型类名: <Entity><Action>Response
UserListResponse
UserCreateResponse
OrderDetailResponse
```

### 3. 工作流程

```bash
# 1. 开发阶段: 快速生成模型
df-test gen models user_detail.json

# 2. 调整阶段: 根据需要手动微调生成的模型
# 3. 后端变更: 重新生成并使用--force覆盖
df-test gen models user_detail.json --force
```

### 4. 版本控制

```bash
# 将生成的模型加入版本控制
git add src/my_project/models/responses/
git commit -m "feat: 添加用户相关响应模型"

# JSON响应文件可选是否提交（建议提交作为文档）
git add responses/*.json
git commit -m "docs: 添加API响应示例"
```

---

## 🔧 高级用法

### 自定义输出目录

如果项目结构不同，可以指定输出目录：

```bash
df-test gen models response.json \
  --output-dir custom/path/to/models \
  --name CustomModel
```

### 批处理脚本

创建脚本批量生成：

```bash
#!/bin/bash
# scripts/generate_all_models.sh

RESPONSES_DIR="responses"
OUTPUT_DIR="src/my_project/models/responses"

for json_file in $RESPONSES_DIR/*.json; do
  echo "生成模型: $json_file"
  df-test gen models "$json_file" --output-dir "$OUTPUT_DIR" --force
done

echo "✅ 所有模型生成完成！"
```

---

## ❓ 常见问题

### Q1: 生成的模型字段类型不正确？

**A**: 类型推断基于JSON值的实际类型。如果需要调整：

1. 修改JSON示例中的值类型
2. 重新生成模型
3. 或者生成后手动调整字段类型

### Q2: 如何处理可选字段？

**A**: 如果JSON中某字段值为`null`，会自动生成为`Optional[Any]`。如果需要更精确的类型：

```python
# 生成后手动调整
age: Optional[Any] = None  # 自动生成

# 调整为
age: Optional[int] = Field(None, description="年龄（可选）")
```

### Q3: 嵌套层级过深怎么办？

**A**: 生成器支持任意深度嵌套。如果觉得类太多，可以：

1. 简化JSON响应结构
2. 生成后合并某些嵌套类

### Q4: 如何生成请求模型？

**A**: 当前版本主要支持响应模型生成。请求模型建议：

1. 使用生成的响应模型作为参考
2. 手动编写请求模型（通常比响应简单）
3. 未来版本将支持请求模型生成

---

## 📈 效率提升

| 任务 | 手工方式 | 使用生成器 | 提升 |
|------|---------|-----------|------|
| 简单模型（5字段） | 10分钟 | 1分钟 | **90%** ⬆️ |
| 复杂模型（15字段+嵌套） | 30分钟 | 2分钟 | **93%** ⬆️ |
| 批量生成（10个模型） | 5小时 | 10分钟 | **96%** ⬆️ |

**实际项目案例（gift-card-test）**:
- 40+个响应模型
- 手工估计: ~20小时
- 使用生成器: ~1小时
- **节省时间: 95%** 🎉

---

## 🔄 与其他工具集成

### 与Postman集成

```bash
# 1. 在Postman中导出响应
# Tests标签页添加:
pm.collectionVariables.set("response", pm.response.text());

# 2. 将响应保存到文件
# 3. 生成模型
df-test gen models postman_response.json
```

### 与Swagger集成

未来版本将支持从OpenAPI/Swagger直接生成：

```bash
# 即将支持
df-test gen models --from-openapi swagger.json --prefix User
```

---

## 📚 相关文档

- [最佳实践](BEST_PRACTICES.md) - 项目结构和测试组织
- [快速参考](QUICK_REFERENCE.md) - 常用命令速查
- [API参考](../api-reference/README.md) - 完整API文档

---

**贡献建议**: 如果您有改进建议或发现bug，请提交Issue！

**上次更新**: 2025-11-05 · **版本**: v3.2.0
