"""
Bootstrap orchestrates configuration loading, logging setup, and runtime
initialisation. Projects can customise each stage fluently.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any, TypeVar

from ...extensions import create_extension_manager
from ..config import (
    ConfigSource,
    FrameworkSettings,
    SettingsAlreadyConfiguredError,
    SettingsNamespace,
    clear_settings,
    configure_settings,
    get_settings,
)
from ..logging import LoggerStrategy, LoguruStructuredStrategy
from ..providers import ProviderRegistry, default_providers
from ..runtime import RuntimeBuilder, RuntimeContext

TSettings = TypeVar("TSettings", bound=FrameworkSettings)


ProviderFactory = Callable[[], ProviderRegistry]


@dataclass
class Bootstrap:
    settings_cls: type[FrameworkSettings] = FrameworkSettings
    namespace: SettingsNamespace = "default"
    profile: str | None = None  # ✅ v3.5 Phase 3: 支持profile
    sources: Iterable[ConfigSource] | None = None
    cache_enabled: bool = True
    logger_strategy: LoggerStrategy = field(default_factory=LoguruStructuredStrategy)
    provider_factory: ProviderFactory | None = None
    plugins: list[str | object] = field(default_factory=list)

    def with_settings(
        self,
        settings_cls: type[TSettings],
        *,
        namespace: SettingsNamespace = "default",
        profile: str | None = None,  # ✅ v3.5 Phase 3: 支持profile参数
        sources: Iterable[ConfigSource] | None = None,
        cache_enabled: bool = True,
    ) -> Bootstrap:
        """配置Settings

        Args:
            settings_cls: Settings类
            namespace: 命名空间
            profile: 环境配置（dev/test/staging/prod），优先级高于ENV环境变量
            sources: 配置源
            cache_enabled: 是否缓存

        Example:
            >>> Bootstrap().with_settings(
            ...     CustomSettings,
            ...     profile="dev",  # 明确指定使用dev环境配置
            ... )
        """
        self.settings_cls = settings_cls
        self.namespace = namespace
        self.profile = profile  # ✅ 保存profile
        self.sources = sources
        self.cache_enabled = cache_enabled
        return self

    def with_logging(self, strategy: LoggerStrategy) -> Bootstrap:
        self.logger_strategy = strategy
        return self

    def with_provider_factory(self, factory: ProviderFactory) -> Bootstrap:
        self.provider_factory = factory
        return self

    def with_plugin(self, plugin: str | object) -> Bootstrap:
        self.plugins.append(plugin)
        return self

    def build(self) -> BootstrapApp:
        return BootstrapApp(
            settings_cls=self.settings_cls,
            namespace=self.namespace,
            profile=self.profile,  # ✅ v3.5 Phase 3: 传递profile
            sources=self.sources,
            cache_enabled=self.cache_enabled,
            logger_strategy=self.logger_strategy,
            provider_factory=self.provider_factory,
            plugins=list(self.plugins),
        )


@dataclass
class BootstrapApp:
    settings_cls: type[FrameworkSettings]
    namespace: SettingsNamespace
    profile: str | None  # ✅ v3.5 Phase 3: 支持profile
    sources: Iterable[ConfigSource] | None
    cache_enabled: bool
    logger_strategy: LoggerStrategy
    provider_factory: ProviderFactory | None
    plugins: list[str | object]

    def run(self, *, force_reload: bool = False) -> RuntimeContext:
        """
        Execute the bootstrap pipeline and return a RuntimeContext.

        v3.5 Phase 3: 支持profile参数，优先级高于ENV环境变量
        """
        if force_reload:
            clear_settings(self.namespace)

        extensions = create_extension_manager()
        extensions.register_many(self.plugins)
        pm = extensions.manager

        extra_sources: list[Any] = []
        for contributed in pm.hook.df_config_sources(settings_cls=self.settings_cls):
            extra_sources.extend(contributed or [])

        combined_sources: list[Any] = []
        if self.sources:
            combined_sources.extend(self.sources)
        combined_sources.extend(extra_sources)

        try:
            configure_settings(
                self.settings_cls,
                namespace=self.namespace,
                profile=self.profile,  # ✅ v3.5 Phase 3: 传递profile
                sources=combined_sources or None,
                cache_enabled=self.cache_enabled,
            )
        except SettingsAlreadyConfiguredError:
            if force_reload:
                clear_settings(self.namespace)
                configure_settings(
                    self.settings_cls,
                    namespace=self.namespace,
                    profile=self.profile,  # ✅ v3.5 Phase 3: 传递profile
                    sources=combined_sources or None,
                    cache_enabled=self.cache_enabled,
                )

        settings = get_settings(self.namespace, force_reload=force_reload)
        logger = self.logger_strategy.configure(settings.logging)

        builder = RuntimeBuilder().with_settings(settings).with_logger(logger)
        providers_factory = self.provider_factory or default_providers
        providers = providers_factory()

        for contributed in pm.hook.df_providers(settings=settings, logger=logger):
            if contributed:
                providers.extend(contributed)

        builder.with_providers(lambda: providers)
        builder.with_extensions(extensions)
        runtime = builder.build()

        pm.hook.df_post_bootstrap(runtime=runtime)
        return runtime
