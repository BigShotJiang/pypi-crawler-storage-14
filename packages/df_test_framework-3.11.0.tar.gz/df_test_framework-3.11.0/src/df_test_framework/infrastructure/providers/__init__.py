"""Providers - 资源提供者系统"""

from .registry import (
    Provider,
    ProviderRegistry,
    SingletonProvider,
    default_providers,
)

__all__ = [
    "Provider",
    "SingletonProvider",
    "ProviderRegistry",
    "default_providers",
]
