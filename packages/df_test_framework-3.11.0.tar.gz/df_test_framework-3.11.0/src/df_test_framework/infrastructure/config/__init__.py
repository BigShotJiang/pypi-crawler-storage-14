"""
Configuration subsystem for df-test-framework.

Projects should subclass `FrameworkSettings` to extend business-specific fields,
then register the subclass via `configure_settings`.
"""

from .http_settings import HTTPSettings
from .interceptor_settings import (
    BearerTokenInterceptorSettings,
    SignatureInterceptorSettings,
)
from .manager import (
    SettingsAlreadyConfiguredError,
    SettingsNamespace,
    SettingsNotConfiguredError,
    clear_settings,
    configure_settings,
    create_settings,
    get_settings,
)
from .pipeline import ConfigPipeline
from .schema import (
    BearerTokenInterceptorConfig,
    CustomInterceptorConfig,
    DatabaseConfig,
    FrameworkSettings,
    HTTPConfig,
    # Interceptor配置
    InterceptorConfig,
    LoggingConfig,
    RedisConfig,
    SignatureConfig,
    SignatureInterceptorConfig,
    StorageConfig,
    TestExecutionConfig,
    TokenInterceptorConfig,
)
from .sources import (
    ConfigSource,
    DictSource,
    DotenvSource,
    EnvVarSource,
)

__all__ = [
    # schema
    "FrameworkSettings",
    "HTTPConfig",
    "DatabaseConfig",
    "RedisConfig",
    "StorageConfig",
    "TestExecutionConfig",
    "LoggingConfig",
    "SignatureConfig",
    # Interceptor配置
    "InterceptorConfig",
    "SignatureInterceptorConfig",
    "BearerTokenInterceptorConfig",
    "TokenInterceptorConfig",
    "CustomInterceptorConfig",
    # Settings类（v3.5+ 现代化配置）
    "HTTPSettings",
    "SignatureInterceptorSettings",
    "BearerTokenInterceptorSettings",
    # manager
    "configure_settings",
    "get_settings",
    "create_settings",
    "clear_settings",
    "SettingsNamespace",
    "SettingsAlreadyConfiguredError",
    "SettingsNotConfiguredError",
    # sources
    "ConfigSource",
    "DictSource",
    "EnvVarSource",
    "DotenvSource",
    # pipeline
    "ConfigPipeline",
]

# 修复 Pydantic 前向引用问题
# 在所有模块加载完成后调用 model_rebuild()
# 参考: https://docs.pydantic.dev/latest/concepts/postponed_annotations/
FrameworkSettings.model_rebuild()
