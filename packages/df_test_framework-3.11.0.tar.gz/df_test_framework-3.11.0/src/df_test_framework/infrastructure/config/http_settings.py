"""HTTP配置Settings类 - 完全声明式嵌套配置

v3.5+ 现代化配置设计：
- ✅ 完全声明式（Pydantic BaseSettings）
- ✅ 嵌套配置（HTTP → Interceptors）
- ✅ 不依赖os.getenv()
- ✅ 自动构建HTTPConfig对象
- ✅ 类型安全和自动验证

使用方式：
    >>> http_settings = HTTPSettings()
    >>> http_config = http_settings.to_http_config()
    >>> print(http_config.base_url)
    >>> print(len(http_config.interceptors))
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from .interceptor_settings import (
    BearerTokenInterceptorSettings,
    SignatureInterceptorSettings,
)


class HTTPSettings(BaseSettings):
    """HTTP配置Settings - 嵌套拦截器配置

    完全声明式配置，包含HTTP基础配置和拦截器配置。

    环境变量：
        # HTTP基础配置
        APP_HTTP_BASE_URL - API基础URL
        APP_HTTP_TIMEOUT - 请求超时时间（秒）
        APP_HTTP_MAX_RETRIES - 最大重试次数
        APP_HTTP_VERIFY_SSL - 是否验证SSL证书

        # 签名拦截器配置（通过APP_SIGNATURE_前缀）
        APP_SIGNATURE_ENABLED - 是否启用
        APP_SIGNATURE_ALGORITHM - 签名算法
        APP_SIGNATURE_SECRET - 签名密钥
        ... （其他签名配置，见SignatureInterceptorSettings）

        # Token拦截器配置（通过APP_TOKEN_前缀）
        APP_TOKEN_ENABLED - 是否启用
        APP_TOKEN_TOKEN_SOURCE - Token来源
        APP_TOKEN_USERNAME - 登录用户名
        ... （其他Token配置，见BearerTokenInterceptorSettings）

    示例：
        >>> # 不需要load_dotenv()，Pydantic自动从.env加载
        >>> settings = HTTPSettings()
        >>> settings.base_url  # 从APP_HTTP_BASE_URL读取
        'https://api.example.com'
        >>> settings.signature.enabled  # 从APP_SIGNATURE_ENABLED读取
        True
        >>> config = settings.to_http_config()  # 自动构建HTTPConfig
        >>> len(config.interceptors)
        2
    """

    # ========== HTTP基础配置 ==========
    base_url: str = Field(default="http://localhost:8000", description="API基础URL")
    timeout: int = Field(default=30, description="请求超时时间（秒）")
    max_retries: int = Field(default=3, description="最大重试次数")
    verify_ssl: bool = Field(default=True, description="是否验证SSL证书")
    max_connections: int = Field(default=50, description="最大连接数")
    max_keepalive_connections: int = Field(default=20, description="Keep-Alive连接数")

    # ========== 嵌套拦截器配置 ==========
    signature: SignatureInterceptorSettings = Field(
        default_factory=SignatureInterceptorSettings, description="签名拦截器配置"
    )
    token: BearerTokenInterceptorSettings = Field(
        default_factory=BearerTokenInterceptorSettings, description="Bearer Token拦截器配置"
    )

    # Pydantic配置
    model_config = SettingsConfigDict(
        env_prefix="APP_HTTP_",
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def http_config(self):
        """自动构建HTTPConfig对象

        根据Settings配置自动构建HTTPConfig，包括：
        1. HTTP基础配置（base_url, timeout等）
        2. 启用的拦截器配置

        Returns:
            HTTPConfig对象，包含所有配置和启用的拦截器

        Example:
            >>> settings = HTTPSettings()
            >>> config = settings.http_config
            >>> config.base_url
            'http://localhost:8000'
            >>> len(config.interceptors)
            2  # 如果签名和Token都启用
        """
        from .schema import HTTPConfig

        # 收集所有启用的拦截器
        interceptors = []

        # 签名拦截器
        if sig_config := self.signature.to_config():
            interceptors.append(sig_config)

        # Token拦截器
        if token_config := self.token.to_config():
            interceptors.append(token_config)

        # 按优先级排序
        interceptors.sort(key=lambda x: x.priority)

        return HTTPConfig(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
            verify_ssl=self.verify_ssl,
            max_connections=self.max_connections,
            max_keepalive_connections=self.max_keepalive_connections,
            interceptors=interceptors,
        )

    def to_http_config(self):
        """转换为HTTPConfig对象（便捷方法）

        这是http_config属性的别名，提供更明确的方法名。

        Returns:
            HTTPConfig对象
        """
        return self.http_config


__all__ = ["HTTPSettings"]
