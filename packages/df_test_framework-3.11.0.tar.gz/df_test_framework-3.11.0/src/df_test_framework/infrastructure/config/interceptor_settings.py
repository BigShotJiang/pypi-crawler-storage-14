"""拦截器配置Settings类 - 完全声明式配置

v3.5+ 现代化配置设计：
- ✅ 完全声明式（Pydantic BaseSettings）
- ✅ 类型安全和自动验证
- ✅ 不依赖os.getenv()和load_dotenv()
- ✅ 清晰的配置分层
- ✅ 易于扩展

使用方式：
    >>> settings = SignatureInterceptorSettings()
    >>> config = settings.to_config()
    >>> if config:
    ...     print(f"签名拦截器已启用: {config.algorithm}")
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from .schema import BearerTokenInterceptorConfig, SignatureInterceptorConfig


class SignatureInterceptorSettings(BaseSettings):
    """签名拦截器配置Settings

    完全声明式配置，自动从环境变量加载。

    环境变量：
        APP_SIGNATURE_ENABLED - 是否启用签名拦截器
        APP_SIGNATURE_ALGORITHM - 签名算法（md5/sha256/hmac-sha256）
        APP_SIGNATURE_SECRET - 签名密钥
        APP_SIGNATURE_HEADER_NAME - 签名Header名称
        APP_SIGNATURE_INCLUDE_PATHS - 包含路径（JSON数组）
        APP_SIGNATURE_EXCLUDE_PATHS - 排除路径（JSON数组）

    示例：
        >>> settings = SignatureInterceptorSettings()
        >>> settings.enabled  # 从 APP_SIGNATURE_ENABLED 读取
        True
        >>> settings.algorithm  # 从 APP_SIGNATURE_ALGORITHM 读取
        'md5'
    """

    # 基础配置
    enabled: bool = Field(default=False, description="是否启用签名拦截器")
    priority: int = Field(default=10, description="拦截器优先级（数字越小越先执行）")

    # 签名算法配置
    algorithm: str = Field(default="md5", description="签名算法：md5 | sha256 | hmac-sha256")
    secret: str = Field(default="change_me_in_production", description="签名密钥")

    # Header配置
    header_name: str = Field(default="X-Sign", description="签名Header名称")

    # 路径匹配规则
    include_paths: list[str] = Field(
        default_factory=lambda: ["/**"], description="包含路径模式列表（支持通配符）"
    )
    exclude_paths: list[str] = Field(
        default_factory=list, description="排除路径模式列表（支持通配符）"
    )

    # 签名计算范围
    include_query_params: bool = Field(default=True, description="是否包含查询参数")
    include_json_body: bool = Field(default=True, description="是否包含JSON请求体")
    include_timestamp: bool = Field(default=True, description="是否包含时间戳")

    # Pydantic配置
    model_config = SettingsConfigDict(
        env_prefix="APP_SIGNATURE_",
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    def to_config(self) -> SignatureInterceptorConfig | None:
        """转换为SignatureInterceptorConfig

        如果未启用，返回None。

        Returns:
            SignatureInterceptorConfig对象，如果未启用则返回None

        Example:
            >>> settings = SignatureInterceptorSettings(enabled=True, algorithm="md5")
            >>> config = settings.to_config()
            >>> config.type
            'signature'
            >>> config.algorithm
            'md5'
        """
        if not self.enabled:
            return None

        return SignatureInterceptorConfig(
            type="signature",
            enabled=True,
            priority=self.priority,
            algorithm=self.algorithm,
            secret=self.secret,
            header_name=self.header_name,
            include_paths=self.include_paths,
            exclude_paths=self.exclude_paths,
            include_query_params=self.include_query_params,
            include_json_body=self.include_json_body,
            include_timestamp=self.include_timestamp,
        )


class BearerTokenInterceptorSettings(BaseSettings):
    """Bearer Token拦截器配置Settings

    完全声明式配置，自动从环境变量加载。

    环境变量：
        APP_TOKEN_ENABLED - 是否启用Token拦截器
        APP_TOKEN_TOKEN_SOURCE - Token来源（static/login/env/custom）
        APP_TOKEN_LOGIN_URL - 登录URL（token_source=login时使用）
        APP_TOKEN_USERNAME - 登录用户名
        APP_TOKEN_PASSWORD - 登录密码
        APP_TOKEN_STATIC_TOKEN - 静态Token（token_source=static时使用）
        APP_TOKEN_FIELD_PATH - Token字段路径（如：data.token）
        APP_TOKEN_HEADER_NAME - Token Header名称
        APP_TOKEN_TOKEN_PREFIX - Token前缀（如：Bearer）
        APP_TOKEN_INCLUDE_PATHS - 包含路径（JSON数组）
        APP_TOKEN_EXCLUDE_PATHS - 排除路径（JSON数组）

    示例：
        >>> settings = BearerTokenInterceptorSettings()
        >>> settings.enabled  # 从 APP_TOKEN_ENABLED 读取
        True
        >>> settings.token_source  # 从 APP_TOKEN_TOKEN_SOURCE 读取
        'login'
    """

    # 基础配置
    enabled: bool = Field(default=False, description="是否启用Token拦截器")
    priority: int = Field(default=20, description="拦截器优先级（数字越小越先执行）")

    # Token来源配置
    token_source: str = Field(
        default="login", description="Token来源：static | login | env | custom"
    )

    # 登录配置（token_source=login时使用）
    login_url: str = Field(default="/auth/login", description="登录URL")
    username: str = Field(default="admin", description="登录用户名")
    password: str = Field(default="password", description="登录密码")

    # 静态Token配置（token_source=static时使用）
    static_token: str = Field(default="", description="静态Token值")

    # Token字段配置
    token_field_path: str = Field(
        default="data.token", description="Token在响应中的字段路径（支持嵌套）"
    )

    # Header配置
    header_name: str = Field(default="Authorization", description="Token Header名称")
    token_prefix: str = Field(default="Bearer", description="Token前缀")

    # 路径匹配规则
    include_paths: list[str] = Field(
        default_factory=lambda: ["/**"], description="包含路径模式列表（支持通配符）"
    )
    exclude_paths: list[str] = Field(
        default_factory=list, description="排除路径模式列表（支持通配符）"
    )

    # 缓存配置
    cache_enabled: bool = Field(default=True, description="是否启用Token缓存")

    # Pydantic配置
    model_config = SettingsConfigDict(
        env_prefix="APP_TOKEN_",
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    def to_config(self) -> BearerTokenInterceptorConfig | None:
        """转换为BearerTokenInterceptorConfig

        如果未启用，返回None。

        Returns:
            BearerTokenInterceptorConfig对象，如果未启用则返回None

        Example:
            >>> settings = BearerTokenInterceptorSettings(
            ...     enabled=True,
            ...     token_source="login",
            ...     username="admin"
            ... )
            >>> config = settings.to_config()
            >>> config.type
            'bearer_token'
            >>> config.token_source
            'login'
        """
        if not self.enabled:
            return None

        # 构建登录凭据
        login_credentials = None
        if self.token_source == "login":
            login_credentials = {
                "username": self.username,
                "password": self.password,
            }

        return BearerTokenInterceptorConfig(
            type="bearer_token",
            enabled=True,
            priority=self.priority,
            token_source=self.token_source,
            static_token=self.static_token if self.token_source == "static" else None,
            login_url=self.login_url,
            login_credentials=login_credentials,
            token_field_path=self.token_field_path,
            header_name=self.header_name,
            token_prefix=self.token_prefix,
            include_paths=self.include_paths,
            exclude_paths=self.exclude_paths,
            cache_enabled=self.cache_enabled,
        )


__all__ = [
    "SignatureInterceptorSettings",
    "BearerTokenInterceptorSettings",
]
