"""测试文件生成模板"""

GEN_TEST_TEMPLATE = """\"\"\"测试文件: {test_name}

使用df-test-framework v3.8进行API测试。

v3.8特性:
- ✅ 异步HTTP客户端（AsyncHttpClient）- 性能提升40倍
- ✅ Unit of Work模式（uow）
- ✅ HTTP Mock支持（http_mock）
- ✅ 时间Mock支持（time_mock）
- ✅ 配置化拦截器（签名、Token自动处理）
\"\"\"

import pytest
import allure
from df_test_framework.testing.plugins import attach_json, step


@allure.feature("{feature_name}")
@allure.story("{story_name}")
class Test{TestName}:
    \"\"\"{TestName}测试类\"\"\"

    @allure.title("测试{test_description}")
    @allure.severity(allure.severity_level.NORMAL)
    @pytest.mark.smoke
    def test_{method_name}(self, http_client, uow):
        \"\"\"测试{test_description}

        v3.8: 使用uow自动回滚，数据不会保留
        \"\"\"
        with step("准备测试数据"):
            # TODO: 准备测试数据
            # 提示：使用Builder模式快速构建数据
            # from {{project_name}}.builders import UserBuilder
            # user_data = UserBuilder().with_name("test_user").build()
            pass

        with step("调用API"):
            # TODO: 调用API
            # 提示：配置化拦截器会自动添加签名/Token
            # response = http_client.get("/api/path")
            # assert response.status_code == 200
            pass

        with step("验证响应"):
            # TODO: 验证响应数据
            # data = response.json()
            # attach_json(data, name="响应数据")
            # assert data["code"] == 200
            pass

        with step("验证数据库"):
            # TODO: 验证数据库状态
            # 提示：使用UoW的Repository访问数据库
            # user = uow.users.find_by_id(user_id)
            # assert user is not None
            pass

        # ✅ 测试结束后自动回滚数据库，无需手动清理

    @allure.title("测试{test_description} - Mock模式")
    @allure.severity(allure.severity_level.NORMAL)
    @pytest.mark.smoke
    def test_{method_name}_with_mock(self, http_mock, http_client):
        \"\"\"测试{test_description}（使用HTTP Mock）

        v3.5新增: 使用http_mock隔离外部依赖
        \"\"\"
        with step("配置Mock响应"):
            # TODO: 配置Mock
            # http_mock.get("/api/external", json={{
            #     "code": 200,
            #     "data": {{"mock": "data"}},
            # }})
            pass

        with step("调用API（返回Mock数据）"):
            # TODO: 调用API
            # response = http_client.get("/api/external")
            # data = response.json()
            # assert data["code"] == 200
            pass

        with step("验证Mock调用"):
            # TODO: 验证Mock被正确调用
            # http_mock.assert_called("/api/external", "GET", times=1)
            pass


__all__ = ["Test{TestName}"]
"""

__all__ = ["GEN_TEST_TEMPLATE"]
