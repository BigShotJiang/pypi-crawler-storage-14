"""pytest.ini 配置文件模板"""

PYTEST_INI_TEMPLATE = """[pytest]
# Python路径
pythonpath = src

# 测试路径
testpaths = tests

# 框架配置（v2.0.0）
# 配置类：使用项目的{ProjectName}Settings
df_settings_class = {project_name}.config.settings.{ProjectName}Settings

# 命令行选项
addopts =
    -v
    --tb=short
    --strict-markers
    --alluredir=reports/allure-results

# 标记定义
markers =
    smoke: 冒烟测试
    regression: 回归测试
    integration: 集成测试
    slow: 慢速测试
"""

__all__ = ["PYTEST_INI_TEMPLATE"]
