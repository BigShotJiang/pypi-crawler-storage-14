"""README模板"""

README_TEMPLATE = """# {ProjectName}

> 基于 df-test-framework v3.7 的自动化测试项目

## 📋 项目简介

{ProjectName} 是基于 DF Test Framework v3.7 构建的自动化测试项目。

### 技术栈

- Python 3.12+
- df-test-framework v3.7.0
- pytest 8.0+
- Pydantic v2
- Allure报告

### v3.7核心特性

- ✅ **Unit of Work模式**: 统一管理事务和Repository，自动回滚
- ✅ **配置化拦截器**: 零代码配置签名、Token认证等拦截器
- ✅ **Profile环境配置**: 支持dev/test/staging/prod多环境
- ✅ **运行时配置覆盖**: 灵活的with_overrides()动态配置
- ✅ **Debug工具集成**: http_debug、db_debug、debug_mode一键调试
- ✅ **完整可观测性**: 自动HTTP/DB日志记录，Allure集成

---

## 🚀 快速开始

### 1. 安装依赖

```bash
# 安装框架
pip install df-test-framework

# 或者在开发模式下
pip install -e .
```

### 2. 配置环境

```bash
# 复制环境配置模板
cp .env.example .env

# 编辑配置文件，填入实际的API地址等信息
vim .env
```

### 3. 运行测试

```bash
# 运行所有测试
pytest

# 运行指定目录的测试
pytest tests/api/ -v

# 运行冒烟测试
pytest -m smoke -v
```

### 4. 查看报告

```bash
# 生成并查看Allure报告
allure serve reports/allure-results
```

---

## 📁 项目结构

```
{project_name}/
├── src/{project_name}/          # 源代码
│   ├── apis/                     # API封装层
│   ├── models/                   # 数据模型
│   ├── repositories/             # Repository层
│   ├── builders/                 # Builder层
│   ├── fixtures/                 # Pytest Fixtures
│   └── config/                   # 配置层
├── tests/                        # 测试目录
│   ├── api/                      # API测试
│   └── conftest.py               # Pytest配置
├── .env.example                 # 配置模板
├── pytest.ini                   # Pytest配置
└── README.md                    # 本文档
```

---

## 📚 使用指南

### 编写API测试

```python
def test_example_api(http_client, uow):
    # 调用API
    response = http_client.get("/api/users/1")

    # 验证响应
    assert response.status_code == 200

    # 使用UoW验证数据库（自动回滚）
    user = uow.users.find_by_id(response.json()["id"])
    assert user is not None
    # 测试结束后数据自动清理，无需手动删除
```

### 使用Unit of Work模式

```python
def test_user_repository(uow):
    # UoW管理所有Repository和事务
    user = uow.users.find_by_id(1)
    assert user is not None

    # 执行SQL查询
    from sqlalchemy import text
    result = uow.session.execute(text("SELECT * FROM users"))

    # 默认自动回滚，如需持久化：
    # uow.commit()
```

### 使用Builder模式

```python
from {project_name}.builders import UserBuilder

user_data = (
    UserBuilder()
    .with_name("张三")
    .with_age(30)
    .with_email("zhangsan@example.com")
    .build()
)
```

---

## 🔗 相关资源

- [DF Test Framework 文档](https://github.com/your-org/df-test-framework)
- [Pytest 文档](https://docs.pytest.org/)
- [Allure 报告](https://docs.qameta.io/allure/)

---

**版本**: v1.0.0
**创建时间**: 2025-11-01
"""

__all__ = ["README_TEMPLATE"]
