"""数据清理Fixtures模板"""

DATA_CLEANERS_TEMPLATE = """\"\"\"数据清理Fixtures

提供项目自定义的数据清理功能。

v3.7说明:
- ✅ 推荐使用 Unit of Work 模式（uow fixture 管理事务和 Repository）
- ✅ 框架已内置 http_mock（HTTP请求Mock）
- ✅ 框架已内置 time_mock（时间Mock）

本文件用于定义项目特定的清理fixtures，例如:
- 文件清理（临时文件、上传文件）
- 外部资源清理（S3、OSS等）
- 缓存清理（Redis特定key清理）
\"\"\"

import pytest
from pathlib import Path
from typing import List, Callable


@pytest.fixture
def cleanup_files() -> Callable[[Path], Path]:
    \"\"\"文件自动清理fixture

    测试中创建的文件会在测试结束后自动删除。

    使用示例:
        ```python
        def test_file_upload(cleanup_files, http_client):
            # 创建临时文件
            test_file = Path("test_upload.txt")
            test_file.write_text("test content")
            cleanup_files(test_file)  # 注册清理

            # 上传文件
            response = http_client.post(
                "/upload",
                files={{"file": test_file.open("rb")}}
            )
            assert response.status_code == 200

            # ✅ 测试结束后自动删除 test_upload.txt
        ```

    Yields:
        Callable: 文件注册函数
    \"\"\"
    created_files: List[Path] = []

    def register_file(filepath: Path) -> Path:
        \"\"\"注册需要清理的文件

        Args:
            filepath: 文件路径

        Returns:
            Path: 原始路径（支持链式调用）
        \"\"\"
        created_files.append(filepath)
        return filepath

    yield register_file

    # 测试结束后清理所有注册的文件
    for filepath in created_files:
        if filepath.exists():
            try:
                if filepath.is_file():
                    filepath.unlink()
                elif filepath.is_dir():
                    import shutil
                    shutil.rmtree(filepath)
            except Exception as e:
                print(f"清理文件失败: {{filepath}} - {{e}}")


@pytest.fixture
def cleanup_redis_keys(redis_client) -> Callable[[str], None]:
    \"\"\"Redis Key自动清理fixture

    测试中创建的Redis key会在测试结束后自动删除。

    使用示例:
        ```python
        def test_cache(cleanup_redis_keys, redis_client):
            # 设置缓存
            test_key = "test:user:123"
            redis_client.set(test_key, "test_value")
            cleanup_redis_keys(test_key)  # 注册清理

            # 验证缓存
            value = redis_client.get(test_key)
            assert value == "test_value"

            # ✅ 测试结束后自动删除 test:user:123
        ```

    Yields:
        Callable: Key注册函数
    \"\"\"
    keys_to_delete: List[str] = []

    def register_key(key: str) -> None:
        \"\"\"注册需要清理的Redis key

        Args:
            key: Redis key
        \"\"\"
        keys_to_delete.append(key)

    yield register_key

    # 测试结束后清理所有注册的keys
    if keys_to_delete:
        try:
            redis_client.delete(*keys_to_delete)
        except Exception as e:
            print(f"清理Redis keys失败: {{e}}")


__all__ = ["cleanup_files", "cleanup_redis_keys"]
"""

__all__ = ["DATA_CLEANERS_TEMPLATE"]
