"""Fixtures模块导出模板"""

FIXTURES_INIT_TEMPLATE = """\"\"\"Pytest Fixtures

导出框架提供的fixtures和项目自定义fixtures。

v3.8更新:
- ✅ 框架已内置 runtime, http_client, database, redis_client
- ✅ 新增 AsyncHttpClient - 异步HTTP客户端，性能提升40倍
- ✅ 推荐使用 Unit of Work 模式（需项目实现 uow fixture）
- ✅ 框架已内置 http_mock（HTTP请求Mock）
- ✅ 框架已内置 time_mock（时间Mock）
\"\"\"

# ========== 框架提供的核心Fixtures ==========
from df_test_framework.testing.fixtures.core import (
    runtime,
    http_client,
    database,
    redis_client,
    http_mock,       # ✅ HTTP Mock
    time_mock,       # ✅ 时间Mock
)

# ========== Unit of Work 模式（v3.7推荐） ==========
# 需要在项目中实现 uow fixture，参考：
# from your_project.uow import YourProjectUoW
#
# @pytest.fixture
# def uow(database):
#     with YourProjectUoW(database.engine) as uow:
#         yield uow
#         # 默认回滚，调用 uow.commit() 持久化数据

# ========== 项目自定义Fixtures（可选） ==========
# 如果需要自定义数据清理fixtures，可以在这里导入
# from .data_cleaners import cleanup_files


__all__ = [
    # Runtime fixtures（框架提供）
    "runtime",
    "http_client",
    "database",
    "redis_client",

    # Mock fixtures（框架提供）
    "http_mock",
    "time_mock",

    # Unit of Work（项目实现）
    # "uow",

    # 项目自定义fixtures（按需添加）
    # "cleanup_files",
]
"""

__all__ = ["FIXTURES_INIT_TEMPLATE"]
