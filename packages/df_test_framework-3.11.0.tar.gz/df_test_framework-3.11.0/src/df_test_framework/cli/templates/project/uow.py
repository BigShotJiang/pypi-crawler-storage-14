"""UnitOfWork 模板

用于项目初始化时生成 UoW 类。
"""

UOW_TEMPLATE = '''"""Unit of Work 定义

v3.7.0+ 特性：
- ✅ 统一管理项目所有 Repository
- ✅ 提供类型安全的访问接口
- ✅ 支持自动事务管理和回滚

使用示例：
    >>> with {ProjectName}UoW(session_factory) as uow:
    ...     # 通过属性访问 Repository
    ...     user = uow.users.find_by_id(1)
    ...     order = uow.orders.create({{"user_id": 1, "amount": 100}})
    ...     uow.commit()
"""

from df_test_framework.databases import BaseUnitOfWork

# 导入项目的 Repository
# from .repositories import UserRepository, OrderRepository


class {ProjectName}UoW(BaseUnitOfWork):
    """{project_name} 项目专用 Unit of Work

    提供类型安全的 Repository 访问接口。

    特性：
    - ✅ IDE 自动补全
    - ✅ 类型检查支持
    - ✅ 事务自动管理
    - ✅ 测试自动回滚

    属性：
        users: 用户 Repository（示例）
        orders: 订单 Repository（示例）

    使用示例：
        >>> # 在测试中使用
        >>> def test_example(uow: {ProjectName}UoW):
        ...     user = uow.users.create({{"name": "Alice"}})
        ...     order = uow.orders.create({{"user_id": user.id}})
        ...     # ✅ 测试结束自动回滚

        >>> # 在业务代码中使用
        >>> with {ProjectName}UoW(session_factory) as uow:
        ...     user = uow.users.find_by_id(1)
        ...     if user:
        ...         uow.orders.create({{"user_id": user["id"]}})
        ...         uow.commit()
    """

    # TODO: 添加项目的 Repository 属性
    # 示例：
    #
    # @property
    # def users(self) -> UserRepository:
    #     \"\"\"用户 Repository\"\"\"
    #     return self.repository(UserRepository)
    #
    # @property
    # def orders(self) -> OrderRepository:
    #     \"\"\"订单 Repository\"\"\"
    #     return self.repository(OrderRepository)

    pass


__all__ = ["{ProjectName}UoW"]
'''

__all__ = ["UOW_TEMPLATE"]
