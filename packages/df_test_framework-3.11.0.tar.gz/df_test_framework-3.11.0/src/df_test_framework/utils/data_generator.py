"""测试数据生成器"""

import random
import string
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any

from faker import Faker


class DataGenerator:
    """
    测试数据生成器

    提供各种类型的测试数据生成功能
    """

    def __init__(self, locale: str = "zh_CN"):
        """
        初始化数据生成器

        Args:
            locale: 本地化设置 (zh_CN, en_US等)
        """
        self.faker = Faker(locale)

    # ========== 基础数据 ==========

    def random_string(
        self,
        length: int = 10,
        chars: str = string.ascii_letters + string.digits,
    ) -> str:
        """生成随机字符串"""
        return "".join(random.choice(chars) for _ in range(length))

    def random_int(self, min_value: int = 0, max_value: int = 100) -> int:
        """生成随机整数"""
        return random.randint(min_value, max_value)

    def random_float(
        self,
        min_value: float = 0.0,
        max_value: float = 100.0,
        decimals: int = 2,
    ) -> float:
        """生成随机浮点数"""
        value = random.uniform(min_value, max_value)
        return round(value, decimals)

    def random_decimal(
        self,
        min_value: float = 0.0,
        max_value: float = 100.0,
        decimals: int = 2,
    ) -> Decimal:
        """生成随机Decimal"""
        value = self.random_float(min_value, max_value, decimals)
        return Decimal(str(value))

    def random_bool(self) -> bool:
        """生成随机布尔值"""
        return random.choice([True, False])

    def random_choice(self, choices: list[Any]) -> Any:
        """从列表中随机选择"""
        return random.choice(choices)

    # ========== 个人信息 ==========

    def name(self) -> str:
        """生成随机姓名"""
        return self.faker.name()

    def email(self) -> str:
        """生成随机邮箱"""
        return self.faker.email()

    def phone(self) -> str:
        """生成随机手机号"""
        return self.faker.phone_number()

    def address(self) -> str:
        """生成随机地址"""
        return self.faker.address()

    def company(self) -> str:
        """生成随机公司名"""
        return self.faker.company()

    # ========== 日期时间 ==========

    def date(
        self,
        start_date: str = "-30d",
        end_date: str = "now",
    ) -> datetime:
        """
        生成随机日期

        Args:
            start_date: 开始日期 (支持相对日期如"-30d")
            end_date: 结束日期 (支持相对日期如"now")

        Returns:
            随机日期时间
        """
        return self.faker.date_time_between(start_date=start_date, end_date=end_date)

    def future_date(self, days: int = 30) -> datetime:
        """生成未来日期"""
        return datetime.now() + timedelta(days=random.randint(1, days))

    def past_date(self, days: int = 30) -> datetime:
        """生成过去日期"""
        return datetime.now() - timedelta(days=random.randint(1, days))

    # ========== 业务数据 ==========

    def card_number(self, length: int = 16) -> str:
        """生成卡号"""
        return "".join(random.choice(string.digits) for _ in range(length))

    def order_id(self, prefix: str = "ORD") -> str:
        """生成订单号"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        random_suffix = self.random_string(6, string.digits)
        return f"{prefix}{timestamp}{random_suffix}"

    def uuid(self) -> str:
        """生成UUID"""
        return self.faker.uuid4()

    # ========== 金融数据 ==========

    def amount(
        self,
        min_value: float = 1.0,
        max_value: float = 1000.0,
    ) -> Decimal:
        """生成金额"""
        return self.random_decimal(min_value, max_value, 2)

    def currency_code(self) -> str:
        """生成货币代码"""
        return self.faker.currency_code()

    # ========== 网络数据 ==========

    def url(self) -> str:
        """生成URL"""
        return self.faker.url()

    def ipv4(self) -> str:
        """生成IPv4地址"""
        return self.faker.ipv4()

    def user_agent(self) -> str:
        """生成User-Agent"""
        return self.faker.user_agent()


__all__ = ["DataGenerator"]
