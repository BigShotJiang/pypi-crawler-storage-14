"""请求-响应模式客户端层 - Layer 1

按协议族组织：
- http/: HTTP协议族（REST、GraphQL、SOAP等）
- rpc/: RPC协议族（gRPC、Thrift等）
- websocket/: WebSocket协议
"""

from .http import BaseAPI, BusinessError, HttpClient

__all__ = [
    "HttpClient",
    "BaseAPI",
    "BusinessError",
]
