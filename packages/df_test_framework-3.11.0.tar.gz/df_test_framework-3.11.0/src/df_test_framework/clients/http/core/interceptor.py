"""拦截器接口

简单的生命周期钩子:
- before_request: 请求前处理
- after_response: 响应后处理
- on_error: 错误处理
"""

from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING

from .request import Request
from .response import Response

if TYPE_CHECKING:
    from ...infrastructure.config.schema import InterceptorConfig


class Interceptor(ABC):
    """拦截器基类

    简单的生命周期钩子设计
    子类只需要覆盖需要的钩子

    Example:
        >>> class MyInterceptor(Interceptor):
        >>>     def before_request(self, request: Request) -> Request:
        >>>         return request.with_header("X-Custom", "value")
    """

    name: str = ""
    priority: int = 100  # 数字越小越先执行

    def before_request(self, request: Request) -> Request | None:
        """请求前处理

        Args:
            request: 原始请求对象

        Returns:
            - None: 不修改请求
            - Request: 修改后的新请求对象

        Raises:
            InterceptorAbort: 主动终止请求
        """
        return None

    def after_response(self, response: Response) -> Response | None:
        """响应后处理

        Args:
            response: 原始响应对象

        Returns:
            - None: 不修改响应
            - Response: 修改后的新响应对象
        """
        return None

    def on_error(self, error: Exception, request: Request) -> None:
        """错误处理（可选）

        Args:
            error: 异常对象
            request: 请求对象
        """
        pass


class BaseInterceptor(Interceptor):
    """拦截器便捷基类

    提供默认的name和priority
    子类只需要覆盖需要的钩子

    Example:
        >>> class MyInterceptor(BaseInterceptor):
        >>>     def __init__(self):
        >>>         super().__init__(name="MyInterceptor", priority=50)
        >>>
        >>>     def before_request(self, request: Request) -> Request:
        >>>         return request.with_header("X-Custom", "value")
    """

    def __init__(self, name: str | None = None, priority: int = 100):
        """初始化拦截器

        Args:
            name: 拦截器名称（默认使用类名）
            priority: 优先级（数字越小越先执行，默认100）
        """
        self.name = name or self.__class__.__name__
        self.priority = priority


class InterceptorAbortError(Exception):
    """拦截器主动终止请求的异常

    拦截器可以抛出此异常来终止请求

    Example:
        >>> class SecurityInterceptor(BaseInterceptor):
        >>>     def before_request(self, request: Request) -> Request:
        >>>         if not self._is_safe(request):
        >>>             raise InterceptorAbortError("不安全的请求")
        >>>         return request
    """

    pass


class PathFilteredInterceptor(BaseInterceptor):
    """路径过滤拦截器包装器（v3.5新增）

    包装任意拦截器，添加路径匹配逻辑
    只有当请求路径匹配include_paths且不匹配exclude_paths时才执行内部拦截器

    这是v3.5架构中用于实现配置化路径匹配的关键组件

    Example:
        >>> from df_test_framework.infrastructure.config.schema import SignatureInterceptorConfig
        >>> from df_test_framework.clients.http.interceptors import SignatureInterceptor
        >>>
        >>> # 创建内部拦截器
        >>> inner = SignatureInterceptor(algorithm="md5", secret="secret")
        >>>
        >>> # 创建配置（包含路径规则）
        >>> config = SignatureInterceptorConfig(
        ...     algorithm="md5",
        ...     secret="secret",
        ...     include_paths=["/api/**"],
        ...     exclude_paths=["/api/health"]
        ... )
        >>>
        >>> # 包装为路径过滤拦截器
        >>> wrapped = PathFilteredInterceptor(inner, config)
        >>>
        >>> # 添加到链
        >>> chain.add(wrapped)
    """

    def __init__(
        self,
        inner: Interceptor,
        config: InterceptorConfig,  # 延迟导入避免循环依赖
    ):
        """初始化路径过滤包装器

        Args:
            inner: 被包装的拦截器实例
            config: 拦截器配置（包含路径规则: include_paths, exclude_paths）
        """
        # 使用内部拦截器的名称和优先级
        super().__init__(
            name=f"PathFiltered({inner.name})",
            priority=inner.priority,
        )
        self.inner = inner
        self.config = config

    def before_request(self, request: Request) -> Request | None:
        """before钩子 - 带路径过滤

        只有路径匹配时才调用内部拦截器
        """
        # 检查路径是否匹配
        if not self.config.should_apply(request.path):
            # 路径不匹配，跳过（返回None表示不修改）
            return None

        # 路径匹配，调用内部拦截器
        return self.inner.before_request(request)

    def after_response(self, response: Response) -> Response | None:
        """after钩子 - 直接代理

        注意: after钩子不检查路径（因为before已检查过）
        如果before被跳过，after也不会被调用（由InterceptorChain保证）
        """
        return self.inner.after_response(response)

    def on_error(self, error: Exception, request: Request) -> None:
        """错误钩子 - 直接代理"""
        self.inner.on_error(error, request)
