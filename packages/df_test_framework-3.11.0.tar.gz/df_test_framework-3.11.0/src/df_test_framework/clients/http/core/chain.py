"""拦截器执行链

责任链模式:
- 自动按priority排序
- 支持短路（InterceptorAbort）
- 洋葱模型（响应拦截器逆序执行）

v3.5新增:
- 支持AllureObserver集成，自动记录拦截器修改
- _diff_request()方法对比Request变化
"""

from typing import TYPE_CHECKING, Any, Optional

from loguru import logger

from .interceptor import Interceptor, InterceptorAbortError
from .request import Request
from .response import Response

if TYPE_CHECKING:
    from ...testing.observers.allure_observer import AllureObserver


class InterceptorChain:
    """拦截器执行链

    责任链模式：
    - 按priority排序（数字越小越先执行）
    - before_request正序执行
    - after_response逆序执行（洋葱模型）

    Example:
        >>> chain = InterceptorChain()
        >>> chain.add(SignatureInterceptor(priority=10))
        >>> chain.add(LoggingInterceptor(priority=100))
        >>>
        >>> # 执行顺序:
        >>> # 1. SignatureInterceptor.before_request (priority=10)
        >>> # 2. LoggingInterceptor.before_request (priority=100)
        >>> # 3. HTTP请求
        >>> # 4. LoggingInterceptor.after_response (逆序)
        >>> # 5. SignatureInterceptor.after_response (逆序)
    """

    def __init__(self, interceptors: list[Interceptor] = None):
        """初始化拦截器链

        Args:
            interceptors: 拦截器列表（可选）
        """
        self.interceptors = interceptors or []
        self._sort()

    def add(self, interceptor: Interceptor) -> None:
        """添加拦截器

        Args:
            interceptor: 拦截器实例
        """
        self.interceptors.append(interceptor)
        self._sort()
        logger.debug(
            f"[InterceptorChain] 添加拦截器: {interceptor.name} (priority={interceptor.priority})"
        )

    def _sort(self) -> None:
        """按priority排序（数字越小越先执行）"""
        self.interceptors.sort(key=lambda i: i.priority)

    def execute_before_request(
        self,
        request: Request,
        request_id: str | None = None,  # ✅ v3.5: 新增参数
        observer: Optional["AllureObserver"] = None,  # ✅ v3.5: 新增参数
    ) -> Request:
        """执行所有before_request钩子（v3.5 Allure集成）

        v3.5新增:
        - 支持传入request_id和observer
        - 自动记录拦截器修改到Allure报告

        Args:
            request: 原始请求对象
            request_id: 请求ID（可选，用于Allure关联）
            observer: Allure观察者（可选）

        Returns:
            处理后的请求对象

        Raises:
            InterceptorAbort: 拦截器主动终止请求
        """
        current_request = request

        for interceptor in self.interceptors:
            try:
                # 记录拦截器开始执行（仅当observer存在时）
                request_before = current_request

                # 执行拦截器
                modified_request = interceptor.before_request(current_request)
                if modified_request is not None:
                    current_request = modified_request

                # ✅ v3.5: 记录拦截器修改（如果有变化）
                if observer and request_id and modified_request:
                    changes = self._diff_request(request_before, modified_request)
                    if changes:
                        # Allure: 记录拦截器修改
                        observer.on_interceptor_execute(request_id, interceptor.name, changes)

                        # ObservabilityLogger: 实时输出拦截器执行
                        from ....infrastructure.logging.observability import http_logger

                        obs = http_logger()
                        obs.interceptor_execute(interceptor.name, changes, request_id)

            except InterceptorAbortError as e:
                logger.warning(f"[拦截器] {interceptor.name} 主动终止请求: {e}")
                raise

            except Exception as e:
                # ✅ v3.5: 记录拦截器错误到Allure
                if observer:
                    observer.on_error(
                        e, {"interceptor": interceptor.name, "request_id": request_id}
                    )
                logger.error(f"[拦截器] {interceptor.name} 执行失败: {e}", exc_info=True)
                # 默认容错：继续执行下一个拦截器
                # 如果需要严格模式，可以在这里raise

        return current_request

    def execute_after_response(self, response: Response) -> Response:
        """执行所有after_response钩子（逆序）

        Args:
            response: 原始响应对象

        Returns:
            处理后的响应对象
        """
        current_response = response

        # 响应拦截器逆序执行（洋葱模型）
        for interceptor in reversed(self.interceptors):
            try:
                modified_response = interceptor.after_response(current_response)
                if modified_response is not None:
                    current_response = modified_response

                logger.debug(f"[拦截器] {interceptor.name} 响应处理成功")

            except Exception as e:
                logger.error(f"[拦截器] {interceptor.name} 响应处理失败: {e}", exc_info=True)
                # 响应拦截器失败不中断

        return current_response

    def execute_on_error(self, error: Exception, request: Request) -> None:
        """执行所有on_error钩子

        Args:
            error: 异常对象
            request: 请求对象
        """
        for interceptor in self.interceptors:
            try:
                interceptor.on_error(error, request)
            except Exception as e:
                logger.error(f"[拦截器] {interceptor.name} 错误处理失败: {e}", exc_info=True)

    def _diff_request(self, before: Request, after: Request) -> dict[str, Any]:
        """对比两个Request，返回变化的字段

        用于Allure报告展示拦截器做了什么修改

        Args:
            before: 修改前的Request
            after: 修改后的Request

        Returns:
            变化的字段字典

        Example:
            >>> before = Request(method="POST", url="/api/users", headers={})
            >>> after = Request(method="POST", url="/api/users", headers={"X-Sign": "abc123"})
            >>> changes = chain._diff_request(before, after)
            >>> print(changes)
            {"headers": {"added": {"X-Sign": "abc123"}}}
        """
        changes: dict[str, Any] = {}

        # 对比headers
        if before.headers != after.headers:
            added = {k: v for k, v in after.headers.items() if k not in before.headers}
            modified = {
                k: v
                for k, v in after.headers.items()
                if k in before.headers and before.headers[k] != v
            }

            if added or modified:
                changes["headers"] = {}
                if added:
                    changes["headers"]["added"] = added
                if modified:
                    changes["headers"]["modified"] = modified

        # 对比params
        if before.params != after.params:
            changes["params"] = {"before": before.params, "after": after.params}

        # 对比json/data
        if before.json != after.json:
            changes["json"] = {"before": before.json, "after": after.json}

        if before.data != after.data:
            changes["data"] = {"before": before.data, "after": after.data}

        return changes
