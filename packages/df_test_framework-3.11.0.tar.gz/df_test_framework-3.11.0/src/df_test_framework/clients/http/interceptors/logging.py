"""日志拦截器

记录HTTP请求和响应
"""

from loguru import logger

from df_test_framework.clients.http.core.interceptor import BaseInterceptor
from df_test_framework.clients.http.core.request import Request
from df_test_framework.clients.http.core.response import Response


class LoggingInterceptor(BaseInterceptor):
    """日志拦截器

    记录HTTP请求和响应

    Example:
        >>> interceptor = LoggingInterceptor(
        >>>     level="DEBUG",
        >>>     log_request_body=True,
        >>>     log_response_body=True,
        >>>     priority=100,
        >>> )
        >>> client.use(interceptor)
    """

    def __init__(
        self,
        level: str = "INFO",
        log_request_body: bool = True,
        log_response_body: bool = True,
        max_body_length: int = 500,
        priority: int = 100,
        name: str = None,
    ):
        """初始化日志拦截器

        Args:
            level: 日志级别（DEBUG/INFO/WARNING/ERROR）
            log_request_body: 是否记录请求体
            log_response_body: 是否记录响应体
            max_body_length: 最大记录长度
            priority: 优先级（默认100，较低优先级）
            name: 拦截器名称（默认LoggingInterceptor）
        """
        super().__init__(name=name or "LoggingInterceptor", priority=priority)
        self.level = level
        self.log_request_body = log_request_body
        self.log_response_body = log_response_body
        self.max_body_length = max_body_length

    def before_request(self, request: Request) -> None:
        """记录请求

        Args:
            request: 请求对象

        Returns:
            None（不修改请求）
        """
        # 构建日志消息
        message = f"→ {request.method} {request.url}"

        # 构建extra信息
        extra = {
            "headers": request.headers,
            "params": request.params,
        }

        # 添加请求体
        if self.log_request_body and request.json:
            body_str = str(request.json)
            extra["body"] = body_str[: self.max_body_length]

        # 记录日志
        logger.log(self.level, message, extra=extra)

        return None  # 不修改请求

    def after_response(self, response: Response) -> None:
        """记录响应

        Args:
            response: 响应对象

        Returns:
            None（不修改响应）
        """
        # 构建日志消息
        message = f"← {response.status_code}"

        # 构建extra信息
        extra = {
            "headers": response.headers,
        }

        # 添加响应体
        if self.log_response_body:
            extra["body"] = response.body[: self.max_body_length]

        # 记录日志
        logger.log(self.level, message, extra=extra)

        return None  # 不修改响应


__all__ = ["LoggingInterceptor"]
