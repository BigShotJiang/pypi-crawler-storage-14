"""拦截器工厂

v3.5重构: 直接返回Interceptor实例，而非Callable
路径匹配逻辑由PathFilteredInterceptor包装器处理
"""

import importlib

from loguru import logger

from df_test_framework.clients.http.core.interceptor import Interceptor

# 从子模块直接导入，避免循环导入
from df_test_framework.clients.http.interceptors.signature import SignatureInterceptor
from df_test_framework.infrastructure.config.schema import (
    BearerTokenInterceptorConfig,
    CustomInterceptorConfig,
    InterceptorConfig,
    SignatureInterceptorConfig,
    TokenInterceptorConfig,
)


class InterceptorFactory:
    """拦截器工厂（v3.5重构版）

    根据配置自动创建拦截器实例,支持:
    - 多种拦截器类型(Signature/Token/BearerToken/Custom)
    - 优先级控制
    - 直接返回Interceptor实例（而非Callable）

    路径匹配由PathFilteredInterceptor包装器处理（见core/interceptor.py）

    Example:
        >>> from df_test_framework.infrastructure.config.schema import (
        ...     SignatureInterceptorConfig
        ... )
        >>> config = SignatureInterceptorConfig(
        ...     type="signature",
        ...     algorithm="md5",
        ...     secret="my_secret",
        ...     include_paths=["/api/**"],
        ...     exclude_paths=["/api/health"]
        ... )
        >>> # ✅ 返回Interceptor实例
        >>> interceptor = InterceptorFactory.create(config)
        >>> assert isinstance(interceptor, Interceptor)
    """

    @staticmethod
    def create(config: InterceptorConfig) -> Interceptor | None:
        """根据配置创建拦截器实例

        v3.5变化: 返回类型从Callable改为Interceptor

        Args:
            config: 拦截器配置

        Returns:
            Interceptor实例,如果disabled则返回None

        Raises:
            ValueError: 不支持的拦截器类型
        """
        if not config.enabled:
            logger.debug(f"[拦截器工厂] 拦截器已禁用: type={config.type}")
            return None

        # ✅ 直接创建并返回Interceptor实例
        if isinstance(config, SignatureInterceptorConfig):
            return InterceptorFactory._create_signature_interceptor(config)
        elif isinstance(config, TokenInterceptorConfig):
            return InterceptorFactory._create_token_interceptor(config)
        elif isinstance(config, BearerTokenInterceptorConfig):
            return InterceptorFactory._create_bearer_token_interceptor(config)
        elif isinstance(config, CustomInterceptorConfig):
            return InterceptorFactory._create_custom_interceptor(config)
        else:
            raise ValueError(f"不支持的拦截器类型: {config.type}")

    @staticmethod
    def _create_signature_interceptor(config: SignatureInterceptorConfig) -> Interceptor:
        """创建签名拦截器

        v3.5变化: 直接返回SignatureInterceptor实例

        Args:
            config: 签名拦截器配置

        Returns:
            SignatureInterceptor实例
        """
        logger.debug(
            f"[拦截器工厂] 创建签名拦截器: "
            f"algorithm={config.algorithm}, header={config.header_name}"
        )

        # ✅ 直接返回拦截器实例
        return SignatureInterceptor(
            algorithm=config.algorithm,
            secret=config.secret,
            header_name=config.header_name,
            include_query=config.include_query_params,
            include_body=config.include_json_body,
            include_form=config.include_form_data,
            priority=config.priority,
        )

    @staticmethod
    def _create_token_interceptor(config: TokenInterceptorConfig) -> Interceptor:
        """创建Token拦截器

        v3.5变化: 直接返回TokenInterceptor实例

        Args:
            config: Token拦截器配置

        Returns:
            TokenInterceptor实例
        """
        from df_test_framework.clients.http.interceptors.auth.token import TokenInterceptor

        logger.debug(
            f"[拦截器工厂] 创建Token拦截器: type={config.token_type}, header={config.header_name}"
        )

        # ✅ 直接返回拦截器实例
        return TokenInterceptor(
            token=config.token,
            token_type=config.token_type,
            header_name=config.header_name,
            priority=config.priority,
        )

    @staticmethod
    def _create_bearer_token_interceptor(config: BearerTokenInterceptorConfig) -> Interceptor:
        """创建Bearer Token认证拦截器

        v3.5变化: 直接返回BearerTokenInterceptor实例

        Args:
            config: Bearer Token拦截器配置

        Returns:
            BearerTokenInterceptor实例
        """
        from df_test_framework.clients.http.interceptors.auth.bearer_token import (
            BearerTokenInterceptor,
        )

        logger.debug(
            f"[拦截器工厂] 创建Bearer Token拦截器: "
            f"source={config.token_source}, header={config.header_name}"
        )

        # ✅ 直接返回拦截器实例
        # 注意：BearerTokenInterceptor不支持env_var_name参数
        return BearerTokenInterceptor(
            token_source=config.token_source,
            static_token=config.static_token,
            login_url=config.login_url,
            login_credentials=config.login_credentials,
            token_field_path=config.token_field_path,
            header_name=config.header_name,
            token_prefix=config.token_prefix,
            priority=config.priority,
        )

    @staticmethod
    def _create_custom_interceptor(config: CustomInterceptorConfig) -> Interceptor:
        """创建自定义拦截器

        v3.5变化: 确保返回Interceptor实例

        通过动态导入加载用户自定义的拦截器类

        Args:
            config: 自定义拦截器配置

        Returns:
            自定义拦截器实例（必须继承自Interceptor）

        Raises:
            ImportError: 无法导入拦截器类
            TypeError: 拦截器类未继承Interceptor
        """
        logger.debug(f"[拦截器工厂] 创建自定义拦截器: class_path={config.class_path}")

        try:
            # 动态导入: "my_project.interceptors.CustomInterceptor"
            # → module="my_project.interceptors", class_name="CustomInterceptor"
            module_path, class_name = config.class_path.rsplit(".", 1)
            module = importlib.import_module(module_path)
            interceptor_class = getattr(module, class_name)

            # 使用params实例化
            interceptor = interceptor_class(**config.params)

            # ✅ 验证是否为Interceptor实例
            if not isinstance(interceptor, Interceptor):
                raise TypeError(
                    f"自定义拦截器 {class_name} 必须继承自 Interceptor 基类。"
                    f"当前类型: {type(interceptor)}"
                )

            logger.debug(f"[拦截器工厂] 自定义拦截器创建成功: {class_name}")
            return interceptor

        except (ImportError, AttributeError) as e:
            raise ImportError(
                f"无法导入拦截器类: {config.class_path}。请检查类路径是否正确。错误: {e}"
            )


__all__ = ["InterceptorFactory"]
