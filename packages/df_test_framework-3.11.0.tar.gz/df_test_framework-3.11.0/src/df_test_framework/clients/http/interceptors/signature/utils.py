"""签名工具函数

提供签名生成常用的工具函数
"""

from collections import OrderedDict
from typing import Any
from urllib.parse import urlencode


def sort_params_by_key(params: dict[str, Any]) -> dict[str, Any]:
    """按key排序参数

    很多签名算法都需要对参数按key排序

    Args:
        params: 参数字典

    Returns:
        按key排序后的OrderedDict

    Example:
        >>> params = {"z": 1, "a": 2, "m": 3}
        >>> sorted_params = sort_params_by_key(params)
        >>> list(sorted_params.keys())
        ['a', 'm', 'z']
    """
    return OrderedDict(sorted(params.items()))


def filter_empty_values(params: dict[str, Any]) -> dict[str, Any]:
    """过滤空值参数

    过滤掉None和空字符串

    Args:
        params: 参数字典

    Returns:
        过滤后的字典

    Example:
        >>> params = {"a": 1, "b": None, "c": "", "d": "value"}
        >>> filtered = filter_empty_values(params)
        >>> filtered
        {'a': 1, 'd': 'value'}
    """
    return {k: v for k, v in params.items() if v is not None and str(v)}


def concat_values(params: dict[str, Any]) -> str:
    """拼接参数值

    将字典的所有值拼接成字符串

    Args:
        params: 参数字典

    Returns:
        拼接后的字符串

    Example:
        >>> params = {"a": 1, "b": 2, "c": 3}
        >>> concat_values(params)
        '123'
    """
    return "".join(str(v) for v in params.values())


def build_query_string(params: dict[str, Any], encoding: str = "utf-8") -> str:
    """构建查询字符串

    用于URL签名等场景

    Args:
        params: 参数字典
        encoding: 编码格式

    Returns:
        URL查询字符串

    Example:
        >>> params = {"userId": 1001, "name": "test"}
        >>> build_query_string(params)
        'userId=1001&name=test'
    """
    return urlencode(params, encoding=encoding)


def concat_key_value_pairs(
    params: dict[str, Any], separator: str = "&", key_value_separator: str = "="
) -> str:
    """拼接键值对

    用于某些签名算法需要 key1=value1&key2=value2 格式

    Args:
        params: 参数字典
        separator: 键值对之间的分隔符
        key_value_separator: 键和值之间的分隔符

    Returns:
        拼接后的字符串

    Example:
        >>> params = {"a": 1, "b": 2}
        >>> concat_key_value_pairs(params)
        'a=1&b=2'
    """
    pairs = [f"{k}{key_value_separator}{v}" for k, v in params.items()]
    return separator.join(pairs)


__all__ = [
    "sort_params_by_key",
    "filter_empty_values",
    "concat_values",
    "build_query_string",
    "concat_key_value_pairs",
]
