"""Token认证拦截器

v3.5新增: 实现完整的Interceptor协议
"""

from loguru import logger

from df_test_framework.clients.http.core.interceptor import BaseInterceptor
from df_test_framework.clients.http.core.request import Request


class TokenInterceptor(BaseInterceptor):
    """Token认证拦截器

    自动为请求添加认证Token

    Example:
        >>> interceptor = TokenInterceptor(
        ...     token="your_token",
        ...     token_type="Bearer",
        ...     header_name="Authorization",
        ... )
        >>> chain.add(interceptor)
    """

    def __init__(
        self,
        token: str,
        token_type: str = "Bearer",
        header_name: str = "Authorization",
        priority: int = 50,
        name: str = None,
    ):
        """初始化Token拦截器

        Args:
            token: 认证Token
            token_type: Token类型（如Bearer, Basic）
            header_name: 认证Header名称
            priority: 优先级（默认50）
            name: 拦截器名称（默认TokenInterceptor）
        """
        super().__init__(name=name or "TokenInterceptor", priority=priority)
        self.token = token
        self.token_type = token_type
        self.header_name = header_name

    def before_request(self, request: Request) -> Request | None:
        """添加Token到请求头"""
        token_value = f"{self.token_type} {self.token}" if self.token_type else self.token

        # ✅ 修复: 使用with_header()保持不可变性,而非直接修改request.headers
        logger.debug(
            f"[TokenInterceptor] 已添加认证Header: {self.header_name}={self.token_type} ****"
        )

        return request.with_header(self.header_name, token_value)


__all__ = ["TokenInterceptor"]
