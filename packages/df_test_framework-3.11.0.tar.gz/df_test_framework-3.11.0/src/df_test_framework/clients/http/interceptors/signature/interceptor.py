"""签名拦截器

自动为HTTP请求添加签名Header
"""

from typing import Any

from loguru import logger

from df_test_framework.clients.http.core.interceptor import BaseInterceptor
from df_test_framework.clients.http.core.request import Request

from .strategies import (
    HMACSignatureStrategy,
    MD5SortedValuesStrategy,
    SHA256SortedValuesStrategy,
)


class SignatureInterceptor(BaseInterceptor):
    """签名拦截器

    自动为请求添加签名Header

    支持的签名算法:
    - md5: MD5签名
    - sha256: SHA256签名
    - hmac-sha256: HMAC-SHA256签名
    - hmac-sha512: HMAC-SHA512签名

    Example:
        >>> interceptor = SignatureInterceptor(
        >>>     algorithm="md5",
        >>>     secret="my_secret",
        >>>     header_name="X-Sign",
        >>>     priority=10,
        >>> )
        >>> client.use(interceptor)
    """

    def __init__(
        self,
        algorithm: str = "md5",
        secret: str = "",
        header_name: str = "X-Sign",
        include_query: bool = True,
        include_body: bool = True,
        include_form: bool = False,
        priority: int = 10,
        name: str = None,
    ):
        """初始化签名拦截器

        Args:
            algorithm: 签名算法（md5/sha256/hmac-sha256/hmac-sha512）
            secret: 签名密钥
            header_name: 签名Header名称
            include_query: 是否包含URL参数
            include_body: 是否包含JSON请求体
            include_form: 是否包含表单数据
            priority: 优先级（默认10）
            name: 拦截器名称（默认SignatureInterceptor）
        """
        super().__init__(name=name or "SignatureInterceptor", priority=priority)
        self.algorithm = algorithm
        self.secret = secret
        self.header_name = header_name
        self.include_query = include_query
        self.include_body = include_body
        self.include_form = include_form

        # 策略模式：根据算法创建签名策略
        self.strategy = self._create_strategy(algorithm)

        logger.info(
            f"[签名拦截器] 已初始化: algorithm={algorithm}, header={header_name}, enabled=True"
        )

    def _create_strategy(self, algorithm: str):
        """根据算法创建签名策略

        Args:
            algorithm: 签名算法

        Returns:
            签名策略实例

        Raises:
            ValueError: 不支持的签名算法
        """
        strategies = {
            "md5": MD5SortedValuesStrategy(),
            "sha256": SHA256SortedValuesStrategy(),
            "hmac-sha256": HMACSignatureStrategy(algorithm="sha256"),
            "hmac-sha512": HMACSignatureStrategy(algorithm="sha512"),
        }

        if algorithm not in strategies:
            raise ValueError(
                f"不支持的签名算法: {algorithm}。支持的算法: {', '.join(strategies.keys())}"
            )

        return strategies[algorithm]

    def before_request(self, request: Request) -> Request:
        """添加签名

        Args:
            request: 原始请求对象

        Returns:
            添加了签名header的新请求对象
        """
        # 1. 提取参数
        params = self._extract_params(request)

        logger.debug(f"[签名拦截器] 待签名参数: {params}")

        # 2. 生成签名
        signature = self.strategy.generate_signature(params, self.secret)

        logger.info(f"[签名拦截器] 已生成签名: {signature[:16]}...")

        # 3. 添加到header
        return request.with_header(self.header_name, signature)

    def _extract_params(self, request: Request) -> dict[str, Any]:
        """提取请求参数

        Args:
            request: 请求对象

        Returns:
            提取的参数字典
        """
        params = {}

        # 添加URL参数
        if self.include_query and request.params:
            params.update(request.params)

        # 添加JSON body参数
        if self.include_body and request.json:
            params.update(request.json)

        # 添加表单数据
        if self.include_form and request.data:
            if isinstance(request.data, dict):
                params.update(request.data)

        return params


__all__ = ["SignatureInterceptor"]
