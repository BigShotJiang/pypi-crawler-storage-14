"""签名策略实现

提供多种签名算法的具体实现
"""

import hashlib
from collections import OrderedDict
from typing import Any

from loguru import logger


class MD5SortedValuesStrategy:
    """MD5排序值签名策略

    签名算法（通用实现）:
    1. 参数按key排序（字母顺序）
    2. 拼接所有非空value值（跳过None和空字符串）
    3. 追加密钥
    4. MD5加密

    Example:
        >>> strategy = MD5SortedValuesStrategy()
        >>> params = {
        ...     "customerOrderNo": "ORDER_001",
        ...     "userId": 1001,
        ...     "templateId": 1,
        ...     "quantity": 1
        ... }
        >>> signature = strategy.generate_signature(params, "secret_key")
        >>> # 步骤1: 按key排序 -> customerOrderNo, quantity, templateId, userId
        >>> # 步骤2: 拼接value -> "ORDER_001" + "1" + "1" + "1001"
        >>> # 步骤3: 追加密钥 -> "ORDER_00111001" + "secret_key"
        >>> # 步骤4: MD5加密 -> "a1b2c3d4..."
    """

    def generate_signature(self, params: dict[str, Any], secret: str) -> str:
        """生成签名

        Args:
            params: 请求参数（会被转换为字符串）
            secret: 应用密钥

        Returns:
            32位小写MD5签名

        Example:
            >>> strategy = MD5SortedValuesStrategy()
            >>> params = {"userId": 1001, "orderId": "ORDER_001"}
            >>> signature = strategy.generate_signature(params, "secret")
            >>> len(signature)
            32
        """
        # 1. 参数按key排序（字母顺序）
        sorted_params = OrderedDict(sorted(params.items()))

        # 2. 只拼接value值（跳过None和空字符串）
        values = []
        for key, value in sorted_params.items():
            # 转换为字符串
            str_value = str(value) if value is not None else ""
            if str_value:  # 跳过空字符串
                values.append(str_value)

        # 3. 拼接所有值
        sign_str = "".join(values)

        # 4. 追加密钥
        sign_str += secret

        logger.debug(f"[签名生成] 待签名字符串: {sign_str}")

        # 5. MD5加密
        signature = self._md5(sign_str)
        logger.debug(f"[签名生成] MD5签名: {signature}")

        return signature

    def verify_signature(self, params: dict[str, Any], secret: str, signature: str) -> bool:
        """验证签名

        Args:
            params: 请求参数（不包含sign）
            secret: 应用密钥
            signature: 待验证的签名

        Returns:
            验证是否通过

        Example:
            >>> strategy = MD5SortedValuesStrategy()
            >>> params = {"userId": 1001}
            >>> sig = strategy.generate_signature(params, "secret")
            >>> strategy.verify_signature(params, "secret", sig)
            True
        """
        expected_signature = self.generate_signature(params, secret)
        result = expected_signature.lower() == signature.lower()

        if not result:
            logger.warning(f"[签名验证失败] 期望: {expected_signature}, 实际: {signature}")
        else:
            logger.debug("[签名验证通过]")

        return result

    @staticmethod
    def _md5(text: str) -> str:
        """MD5加密

        Args:
            text: 待加密文本

        Returns:
            32位小写MD5值
        """
        return hashlib.md5(text.encode("utf-8")).hexdigest()


class SHA256SortedValuesStrategy:
    """SHA256排序值签名策略

    算法与MD5版本相同，只是使用SHA256加密（更安全）

    SHA256适用场景:
    - 需要更高安全性的场景
    - 合规要求禁止使用MD5
    - 未来升级替换MD5

    Example:
        >>> strategy = SHA256SortedValuesStrategy()
        >>> params = {"userId": 1001}
        >>> signature = strategy.generate_signature(params, "secret")
        >>> len(signature)
        64
    """

    def generate_signature(self, params: dict[str, Any], secret: str) -> str:
        """生成签名

        Args:
            params: 请求参数
            secret: 应用密钥

        Returns:
            64位小写SHA256签名
        """
        # 实现与MD5版本相同，只是最后用SHA256
        sorted_params = OrderedDict(sorted(params.items()))

        values = []
        for key, value in sorted_params.items():
            str_value = str(value) if value is not None else ""
            if str_value:
                values.append(str_value)

        sign_str = "".join(values) + secret

        logger.debug(f"[签名生成] 待签名字符串: {sign_str}")

        signature = self._sha256(sign_str)
        logger.debug(f"[签名生成] SHA256签名: {signature}")

        return signature

    def verify_signature(self, params: dict[str, Any], secret: str, signature: str) -> bool:
        """验证签名

        Args:
            params: 请求参数（不包含sign）
            secret: 应用密钥
            signature: 待验证的签名

        Returns:
            验证是否通过
        """
        expected = self.generate_signature(params, secret)
        result = expected.lower() == signature.lower()

        if not result:
            logger.warning(f"[签名验证失败] 期望: {expected}, 实际: {signature}")
        else:
            logger.debug("[签名验证通过]")

        return result

    @staticmethod
    def _sha256(text: str) -> str:
        """SHA256加密

        Args:
            text: 待加密文本

        Returns:
            64位小写SHA256值
        """
        return hashlib.sha256(text.encode("utf-8")).hexdigest()


class HMACSignatureStrategy:
    """HMAC签名策略

    使用HMAC算法生成签名，支持多种哈希算法

    HMAC适用场景:
    - 需要密钥安全的签名
    - API认证（如AWS Signature V4）
    - Webhook签名验证

    Example:
        >>> strategy = HMACSignatureStrategy(algorithm="sha256")
        >>> params = {"userId": 1001}
        >>> signature = strategy.generate_signature(params, "secret")
    """

    def __init__(self, algorithm: str = "sha256"):
        """初始化HMAC签名策略

        Args:
            algorithm: 哈希算法（sha256, sha512等）
        """
        self.algorithm = algorithm

    def generate_signature(self, params: dict[str, Any], secret: str) -> str:
        """生成HMAC签名

        Args:
            params: 请求参数
            secret: 应用密钥

        Returns:
            HMAC签名（hex格式）
        """
        import hmac

        # 1. 参数按key排序
        sorted_params = OrderedDict(sorted(params.items()))

        # 2. 拼接所有非空值
        values = []
        for key, value in sorted_params.items():
            str_value = str(value) if value is not None else ""
            if str_value:
                values.append(str_value)

        sign_str = "".join(values)

        logger.debug(f"[HMAC签名生成] 待签名字符串: {sign_str}")

        # 3. HMAC签名
        if self.algorithm == "sha256":
            signature = hmac.new(
                secret.encode("utf-8"), sign_str.encode("utf-8"), hashlib.sha256
            ).hexdigest()
        elif self.algorithm == "sha512":
            signature = hmac.new(
                secret.encode("utf-8"), sign_str.encode("utf-8"), hashlib.sha512
            ).hexdigest()
        else:
            raise ValueError(f"不支持的HMAC算法: {self.algorithm}")

        logger.debug(f"[HMAC签名生成] {self.algorithm.upper()}签名: {signature}")

        return signature

    def verify_signature(self, params: dict[str, Any], secret: str, signature: str) -> bool:
        """验证HMAC签名

        Args:
            params: 请求参数
            secret: 应用密钥
            signature: 待验证的签名

        Returns:
            验证是否通过
        """
        import hmac

        expected = self.generate_signature(params, secret)
        # 使用constant_time_compare防止时序攻击
        result = hmac.compare_digest(expected, signature)

        if not result:
            logger.warning(f"[HMAC签名验证失败] 期望: {expected}, 实际: {signature}")
        else:
            logger.debug("[HMAC签名验证通过]")

        return result


__all__ = [
    "MD5SortedValuesStrategy",
    "SHA256SortedValuesStrategy",
    "HMACSignatureStrategy",
]
