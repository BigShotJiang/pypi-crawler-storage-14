"""Bearer Token认证拦截器

支持多种Token获取方式:
- login: 通过登录接口获取
- static: 使用静态Token
- custom: 自定义获取方式

高级特性:
- Token TTL（过期时间）管理
- JWT自动解析过期时间
- 401自动清除缓存
- Token刷新回调
"""

import base64
import json
import threading
import time
from collections.abc import Callable

import httpx
from loguru import logger

from df_test_framework.clients.http.core.interceptor import BaseInterceptor
from df_test_framework.clients.http.core.request import Request
from df_test_framework.clients.http.core.response import Response


class BearerTokenInterceptor(BaseInterceptor):
    """Bearer Token认证拦截器

    自动获取Token并添加到请求头
    支持多种Token获取方式

    Example 1 - 登录获取Token:
        >>> interceptor = BearerTokenInterceptor(
        >>>     token_source="login",
        >>>     login_url="/admin/auth/login",
        >>>     login_credentials={
        >>>         "username": "admin",
        >>>         "password": "admin123",
        >>>     },
        >>>     token_field_path="data.token",
        >>> )

    Example 2 - 静态Token:
        >>> interceptor = BearerTokenInterceptor(
        >>>     token_source="static",
        >>>     static_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        >>> )

    Example 3 - 自定义获取方式:
        >>> def get_token_from_cache():
        >>>     return redis_client.get("api_token")
        >>>
        >>> interceptor = BearerTokenInterceptor(
        >>>     token_source="custom",
        >>>     custom_token_getter=get_token_from_cache,
        >>> )
    """

    def __init__(
        self,
        # Token获取方式
        token_source: str = "login",  # login/static/custom
        # 登录方式配置
        login_url: str | None = None,
        login_credentials: dict[str, str] | None = None,
        # 静态Token配置
        static_token: str | None = None,
        # 自定义Token获取函数
        custom_token_getter: Callable[[], str] | None = None,
        # Token提取配置
        token_field_path: str = "data.token",
        # Header配置
        header_name: str = "Authorization",
        token_prefix: str = "Bearer",
        # 缓存配置
        cache_enabled: bool = True,
        cache_ttl: int | None = None,
        # 高级特性
        auto_refresh_on_401: bool = True,
        auto_parse_jwt_expiry: bool = False,
        on_token_refresh: Callable[[str], None] | None = None,
        # 通用配置
        priority: int = 20,
        name: str | None = None,
    ):
        """初始化Bearer Token拦截器

        Args:
            token_source: Token获取方式（login/static/custom）
            login_url: 登录接口路径
            login_credentials: 登录凭证（username/password）
            static_token: 静态Token值
            custom_token_getter: 自定义Token获取函数
            token_field_path: Token在响应中的字段路径（支持嵌套，如"data.token"）
            header_name: Token Header名称（默认Authorization）
            token_prefix: Token前缀（默认Bearer）
            cache_enabled: 是否启用Token缓存（默认True）
            cache_ttl: Token缓存有效期（秒），None表示永久缓存（默认None）
            auto_refresh_on_401: 检测到401时自动清除缓存（默认True）
            auto_parse_jwt_expiry: 自动从JWT解析过期时间（默认False）
            on_token_refresh: Token刷新时的回调函数，接收新token作为参数
            priority: 优先级（默认20）
            name: 拦截器名称（默认BearerTokenInterceptor）
        """
        super().__init__(name=name or "BearerTokenInterceptor", priority=priority)
        self.token_source = token_source
        self.login_url = login_url
        self.login_credentials = login_credentials or {}
        self.static_token = static_token
        self.custom_token_getter = custom_token_getter
        self.token_field_path = token_field_path
        self.header_name = header_name
        self.token_prefix = token_prefix

        # Token缓存配置
        self._cache_enabled = cache_enabled
        self._cache_ttl = cache_ttl
        self._token_cache: str | None = None
        self._token_expire_time: float | None = None

        # 高级特性配置
        self._auto_refresh_on_401 = auto_refresh_on_401
        self._auto_parse_jwt_expiry = auto_parse_jwt_expiry
        self._on_token_refresh = on_token_refresh

        # 线程安全保护
        self._lock = threading.Lock()

        # 验证配置
        self._validate_config()

        logger.info(
            f"[Bearer Token拦截器] 已初始化: token_source={token_source}, header={header_name}"
        )

    def _validate_config(self) -> None:
        """验证配置"""
        if self.token_source == "login":
            if not self.login_url:
                raise ValueError("token_source=login时，必须提供login_url")
            if not self.login_credentials:
                raise ValueError("token_source=login时，必须提供login_credentials")

        elif self.token_source == "static":
            if not self.static_token:
                raise ValueError("token_source=static时，必须提供static_token")

        elif self.token_source == "custom":
            if not self.custom_token_getter:
                raise ValueError("token_source=custom时，必须提供custom_token_getter")

        else:
            raise ValueError(
                f"不支持的token_source: {self.token_source}。支持的值: login, static, custom"
            )

    def before_request(self, request: Request) -> Request:
        """添加Token

        Args:
            request: 原始请求对象

        Returns:
            添加了Token header的新请求对象
        """
        # 1. 获取Token
        token = self._get_token(request)

        # 2. 添加到header
        token_value = f"{self.token_prefix} {token}" if self.token_prefix else token

        logger.debug(f"[Bearer Token] 已添加{self.header_name} Header")

        return request.with_header(self.header_name, token_value)

    def _parse_jwt_expiry(self, token: str) -> int | None:
        """从JWT token中解析过期时间

        JWT格式: header.payload.signature
        payload是Base64编码的JSON，包含exp字段（Unix时间戳）

        Args:
            token: JWT token字符串

        Returns:
            过期时间戳（秒），如果解析失败则返回None

        Example:
            >>> token = "eyJhbGci...eyJleHA...signature"
            >>> expiry = self._parse_jwt_expiry(token)
            >>> ttl = expiry - time.time()  # 剩余有效期
        """
        try:
            # JWT格式: header.payload.signature
            parts = token.split(".")
            if len(parts) != 3:
                logger.debug(f"[Bearer Token] Token不是JWT格式（部分数量: {len(parts)}）")
                return None

            # 解码payload（第二部分）
            payload = parts[1]

            # 添加padding（Base64要求长度是4的倍数）
            padding = len(payload) % 4
            if padding:
                payload += "=" * (4 - padding)

            # Base64解码
            decoded_bytes = base64.urlsafe_b64decode(payload)
            decoded_str = decoded_bytes.decode("utf-8")

            # JSON解析
            payload_data = json.loads(decoded_str)

            # 提取exp字段
            exp = payload_data.get("exp")
            if exp is None:
                logger.debug("[Bearer Token] JWT payload中没有exp字段")
                return None

            logger.debug(f"[Bearer Token] JWT过期时间: {exp} ({time.ctime(exp)})")
            return int(exp)

        except Exception as e:
            logger.debug(f"[Bearer Token] JWT解析失败: {e}")
            return None

    def _is_token_expired(self) -> bool:
        """检查Token是否过期

        Returns:
            True: Token已过期或未设置
            False: Token仍然有效
        """
        # 如果没有过期时间记录，视为未过期（永久缓存）
        if self._token_expire_time is None:
            return False

        # 检查是否超过过期时间
        return time.time() >= self._token_expire_time

    def _get_token(self, request: Request) -> str:
        """获取Token（带缓存、TTL、线程安全）

        使用双检锁模式确保：
        1. 快速路径：已缓存且未过期时直接返回，无锁开销
        2. 线程安全：多线程并发时只有一个线程会真正获取Token
        3. 防止重复登录：避免同时发起多个登录请求
        4. 自动过期：支持TTL，过期后自动重新获取

        Args:
            request: 请求对象

        Returns:
            Token值
        """
        # 第一次检查（快速路径，无锁）
        if self._token_cache is not None and self._cache_enabled and not self._is_token_expired():
            logger.debug("[Bearer Token] 使用缓存的Token（快速路径）")
            return self._token_cache

        # 获取锁，进入临界区
        with self._lock:
            # 第二次检查（有锁，防止竞态条件）
            if (
                self._token_cache is not None
                and self._cache_enabled
                and not self._is_token_expired()
            ):
                logger.debug("[Bearer Token] 使用缓存的Token（临界区）")
                return self._token_cache

            # 只有第一个获得锁的线程会执行到这里
            if self._is_token_expired():
                logger.info("[Bearer Token] Token已过期，重新获取")
            else:
                logger.info("[Bearer Token] 缓存未命中，开始获取Token")

            # 根据token_source获取Token
            if self.token_source == "login":
                token = self._get_token_by_login(request)
            elif self.token_source == "static":
                token = self.static_token
            elif self.token_source == "custom":
                token = self.custom_token_getter()
            else:
                raise ValueError(f"不支持的token_source: {self.token_source}")

            # 缓存Token（线程安全）
            if self._cache_enabled:
                self._token_cache = token

                # 设置过期时间
                if self._auto_parse_jwt_expiry:
                    # 尝试从JWT解析过期时间
                    jwt_exp = self._parse_jwt_expiry(token)
                    if jwt_exp:
                        self._token_expire_time = jwt_exp
                        ttl = jwt_exp - time.time()
                        logger.info(f"[Bearer Token] Token已缓存，从JWT解析TTL={int(ttl)}秒")
                    elif self._cache_ttl is not None:
                        # JWT解析失败，使用配置的TTL
                        self._token_expire_time = time.time() + self._cache_ttl
                        logger.info(f"[Bearer Token] Token已缓存，使用配置TTL={self._cache_ttl}秒")
                    else:
                        logger.info("[Bearer Token] Token已缓存（永久有效）")
                elif self._cache_ttl is not None:
                    self._token_expire_time = time.time() + self._cache_ttl
                    logger.info(f"[Bearer Token] Token已缓存，TTL={self._cache_ttl}秒")
                else:
                    logger.info("[Bearer Token] Token已缓存（永久有效）")

                # 触发刷新回调
                if self._on_token_refresh:
                    try:
                        self._on_token_refresh(token)
                        logger.debug("[Bearer Token] Token刷新回调已执行")
                    except Exception as e:
                        logger.error(f"[Bearer Token] Token刷新回调执行失败: {e}")

            return token

    def _get_token_by_login(self, request: Request) -> str:
        """通过登录接口获取Token

        Args:
            request: 请求对象

        Returns:
            Token值

        Raises:
            ValueError: 登录失败或Token提取失败
        """
        # 获取base_url
        base_url = request.get_context("base_url", "")
        full_login_url = f"{base_url}{self.login_url}"

        logger.info(
            f"[Bearer Token] 调用登录接口: {full_login_url}, "
            f"username={self.login_credentials.get('username')}"
        )

        # 调用登录接口（使用httpx直接调用）
        try:
            login_response = httpx.post(
                full_login_url,
                json=self.login_credentials,
                timeout=30,
            )
            login_response.raise_for_status()
        except httpx.HTTPStatusError as e:
            # HTTP状态码错误（4xx, 5xx）
            response_text = e.response.text[:500]  # 限制长度
            logger.error(
                f"[Bearer Token] 登录失败 - HTTP错误: "
                f"status={e.response.status_code}, "
                f"url={e.request.url}, "
                f"response={response_text}"
            )
            raise ValueError(f"登录失败 (HTTP {e.response.status_code}): {response_text}") from e
        except httpx.TimeoutException as e:
            # 超时错误
            logger.error(f"[Bearer Token] 登录超时: url={full_login_url}, timeout=30s")
            raise ValueError(f"登录超时: {full_login_url}") from e
        except httpx.NetworkError as e:
            # 网络错误（连接失败、DNS解析失败等）
            logger.error(f"[Bearer Token] 网络错误: {e}, url={full_login_url}")
            raise ValueError(f"网络连接失败: {e}") from e
        except Exception as e:
            # 其他未知错误
            logger.error(f"[Bearer Token] 登录失败 - 未知错误: {e}")
            raise ValueError(f"登录失败: {e}") from e

        # 提取Token（支持嵌套字段: "data.token"）
        try:
            data = login_response.json()
        except Exception as e:
            response_preview = login_response.text[:200]
            logger.error(f"[Bearer Token] 登录响应JSON解析失败: {e}, 响应内容: {response_preview}")
            raise ValueError(f"登录响应不是有效的JSON: {response_preview}") from e

        token = data
        for field in self.token_field_path.split("."):
            if not isinstance(token, dict) or field not in token:
                # 限制响应内容长度，避免日志过大
                data_preview = str(data)[:500] if len(str(data)) > 500 else str(data)
                logger.error(
                    f"[Bearer Token] Token字段提取失败: "
                    f"字段路径={self.token_field_path}, "
                    f"当前字段={field}, "
                    f"响应预览={data_preview}"
                )
                raise ValueError(
                    f"登录响应中未找到Token字段 '{self.token_field_path}' (当前字段: {field})"
                ) from None
            token = token[field]

        logger.info("[Bearer Token] 登录成功，Token已获取")
        return token

    def invalidate_cache(self) -> None:
        """手动清除Token缓存

        使用场景：
        1. Token已知失效，需要强制重新获取
        2. 测试场景需要重置状态
        3. 用户登出后清除缓存

        Example:
            >>> interceptor.invalidate_cache()
            >>> # 下次请求会重新获取Token
        """
        with self._lock:
            self._token_cache = None
            self._token_expire_time = None
            logger.info("[Bearer Token] 缓存已清除")

    def after_response(self, response: Response) -> Response | None:
        """响应后处理：检测401自动清除缓存

        当检测到401 Unauthorized响应时，自动清除Token缓存
        这样下次请求会自动获取新的Token

        Args:
            response: HTTP响应对象

        Returns:
            不修改响应，返回None

        Note:
            这个方法不会自动重试请求，只是清除缓存
            用户需要在业务代码中处理401并重试，或使用HTTP客户端的重试机制
        """
        if not self._auto_refresh_on_401:
            return None

        # 检测401 Unauthorized
        if response.status_code == 401:
            logger.warning("[Bearer Token] 检测到401 Unauthorized响应，自动清除Token缓存")
            self.invalidate_cache()

            # 在响应context中标记已清除缓存
            return response.with_context("bearer_token_cache_cleared", True)

        return None


__all__ = ["BearerTokenInterceptor"]
