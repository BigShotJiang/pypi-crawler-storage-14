"""签名拦截器

提供HTTP请求签名功能
"""

from .interceptor import SignatureInterceptor
from .protocols import SignatureConfig, SignatureStrategy
from .strategies import (
    HMACSignatureStrategy,
    MD5SortedValuesStrategy,
    SHA256SortedValuesStrategy,
)
from .utils import (
    build_query_string,
    concat_key_value_pairs,
    concat_values,
    filter_empty_values,
    sort_params_by_key,
)

__all__ = [
    # 拦截器
    "SignatureInterceptor",
    # 协议
    "SignatureStrategy",
    "SignatureConfig",
    # 策略实现
    "MD5SortedValuesStrategy",
    "SHA256SortedValuesStrategy",
    "HMACSignatureStrategy",
    # 工具函数
    "sort_params_by_key",
    "filter_empty_values",
    "concat_values",
    "build_query_string",
    "concat_key_value_pairs",
]
