"""签名协议定义

定义签名策略的标准接口，支持多种签名算法实现
"""

from typing import Any, Protocol


class SignatureStrategy(Protocol):
    """签名策略协议

    定义签名生成和验证的标准接口，所有签名策略必须实现这些方法。

    Example:
        >>> class MySignatureStrategy:
        ...     def generate_signature(self, params, secret):
        ...         return "signature"
        ...     def verify_signature(self, params, secret, signature):
        ...         return True
    """

    def generate_signature(self, params: dict[str, Any], secret: str) -> str:
        """生成签名

        Args:
            params: 请求参数字典
            secret: 应用密钥

        Returns:
            签名字符串
        """
        ...

    def verify_signature(self, params: dict[str, Any], secret: str, signature: str) -> bool:
        """验证签名

        Args:
            params: 请求参数字典（不包含sign）
            secret: 应用密钥
            signature: 待验证的签名

        Returns:
            验证是否通过
        """
        ...


class SignatureConfig:
    """签名配置（占位符，待实现具体配置类）"""

    pass


__all__ = ["SignatureStrategy", "SignatureConfig"]
