"""HTTP协议族客户端 - Layer 1

支持多种HTTP风格的API客户端：
- REST: RESTful API客户端
- GraphQL: GraphQL客户端（预留）
- SOAP: SOAP客户端（预留）
"""

# 当前实现
# 核心对象
from .core import Request, Response

# HTTP拦截器
from .interceptors import (
    BearerTokenInterceptor,
    LoggingInterceptor,
    SignatureInterceptor,
)
from .rest.httpx import BaseAPI, BusinessError, HttpClient

__all__ = [
    # 客户端和API
    "HttpClient",
    "BaseAPI",
    "BusinessError",
    # 拦截器
    "SignatureInterceptor",
    "BearerTokenInterceptor",
    "LoggingInterceptor",
    # 核心对象
    "Request",
    "Response",
]
