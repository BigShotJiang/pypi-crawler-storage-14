"""HTTP客户端封装

v3.0.0 新增:
- 集成HTTPDebugger调试支持

v3.5.0 重构:
- 使用InterceptorChain替代List[Callable]
- 支持完整的before/after/on_error拦截器生命周期
"""

from __future__ import annotations

import re
import time
from typing import TYPE_CHECKING, Any

import httpx
from loguru import logger
from pydantic import BaseModel

from df_test_framework.clients.http.core import (
    InterceptorChain,
    PathFilteredInterceptor,
    Request,
    Response,
)

if TYPE_CHECKING:
    from df_test_framework.infrastructure.config.schema import (
        HTTPConfig,
        InterceptorConfig,
    )


def sanitize_url(url: str) -> str:
    """
    脱敏URL中的敏感参数

    将以下敏感参数值替换为****:
    - token, access_token, refresh_token
    - key, api_key, secret, secret_key
    - password
    - authorization

    Args:
        url: 原始URL

    Returns:
        脱敏后的URL

    Examples:
        >>> sanitize_url("/api/users?token=abc123&id=1")
        '/api/users?token=****&id=1'

        >>> sanitize_url("/api/pay?amount=100&key=xyz789")
        '/api/pay?amount=100&key=****'
    """
    # 敏感参数列表
    sensitive_params = [
        "token",
        "access_token",
        "refresh_token",
        "key",
        "api_key",
        "secret",
        "secret_key",
        "password",
        "passwd",
        "authorization",
        "auth",
    ]

    for param in sensitive_params:
        # 匹配 ?param=value 或 &param=value，替换为 ?param=**** 或 &param=****
        # 使用(?<![a-zA-Z_]) 和 (?![a-zA-Z_]) 确保参数名准确匹配
        pattern = rf"([?&]{param}=)[^&]*"
        url = re.sub(pattern, r"\1****", url, flags=re.IGNORECASE)

    return url


class HttpClient:
    """
    统一的HTTP客户端封装

    功能:
    - 统一的请求/响应拦截
    - 自动添加认证token
    - 请求/响应日志记录
    - 自动重试机制
    - 上下文管理器支持
    """

    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        headers: dict[str, str] | None = None,
        verify_ssl: bool = True,
        max_retries: int = 3,
        max_connections: int = 50,
        max_keepalive_connections: int = 20,
        config: HTTPConfig | None = None,  # 🆕 支持从HTTPConfig加载配置
    ):
        """
        初始化HTTP客户端

        Args:
            base_url: API基础URL
            timeout: 请求超时时间(秒) (默认30)
            headers: 默认请求头
            verify_ssl: 是否验证SSL证书 (默认True)
            max_retries: 最大重试次数 (默认3)
            max_connections: 最大连接数 (默认50)
            max_keepalive_connections: Keep-Alive连接数 (默认20)
            config: HTTPConfig配置对象 (可选,用于自动加载拦截器)
        """
        self.base_url = base_url
        self.timeout = timeout
        self.default_headers = headers or {}
        self.verify_ssl = verify_ssl
        self.max_retries = max_retries

        # v3.5: 使用InterceptorChain替代List[Callable]
        self.interceptor_chain = InterceptorChain()

        # 配置传输层 (注意: httpx.HTTPTransport没有retries参数)
        transport = httpx.HTTPTransport(
            verify=verify_ssl,
        )

        # 配置连接限制
        limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
        )

        # 创建httpx客户端
        self.client = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers=self.default_headers,
            transport=transport,
            limits=limits,  # ✅ 添加连接限制
            follow_redirects=True,
        )

        logger.debug(
            f"HTTP客户端已初始化: base_url={base_url}, "
            f"timeout={timeout}s, max_retries={max_retries}"
        )

        # v3.5: 从配置自动加载拦截器（使用PathFilteredInterceptor包装）
        if config and config.interceptors:
            self._load_interceptors_from_config(config.interceptors)

    def set_auth_token(self, token: str, token_type: str = "Bearer") -> None:
        """
        设置认证token

        Args:
            token: 认证令牌
            token_type: 令牌类型 (Bearer, Basic等)
        """
        self.client.headers["Authorization"] = f"{token_type} {token}"
        logger.debug(f"已设置认证token: {token_type} {token[:10]}...")

    # ==================== ✅ 重构: 辅助方法（降低request()复杂度） ====================

    def _prepare_request_object(
        self,
        method: str,
        url: str,
        **kwargs,
    ) -> Request:
        """准备Request对象

        ✅ v3.6新增: 支持 Pydantic 模型自动序列化

        Args:
            method: 请求方法
            url: 请求URL
            **kwargs: 请求参数
                - json: 可以是 Pydantic 模型或字典
                  如果是 Pydantic 模型，会自动使用 model_dump_json() 序列化
                  自动处理 Decimal/datetime/UUID 等类型

        Returns:
            Request对象
        """
        # ✅ v3.6: 自动处理 Pydantic 模型序列化
        json_param = kwargs.get("json")
        if json_param is not None:
            # 检查是否为 Pydantic 模型
            from pydantic import BaseModel

            if isinstance(json_param, BaseModel):
                # 使用 Pydantic 的 model_dump_json() 序列化
                # 优点：
                # 1. 自动处理 Decimal → 字符串
                # 2. 自动处理 datetime → ISO 8601
                # 3. 自动处理 UUID → 字符串
                # 4. 性能优化（Rust 核心）
                json_str = json_param.model_dump_json()

                # 将序列化后的 JSON 字符串设置为 data
                # 同时设置 Content-Type 头
                kwargs["data"] = json_str
                headers = kwargs.get("headers", {})
                if "Content-Type" not in headers and "content-type" not in headers:
                    headers["Content-Type"] = "application/json"
                    kwargs["headers"] = headers

                # 清空 json 参数，避免 httpx 重复处理
                kwargs["json"] = None

        return Request(
            method=method,
            url=url,
            headers=kwargs.get("headers", {}),
            params=kwargs.get("params"),
            json=kwargs.get("json"),
            data=kwargs.get("data"),
            context={"base_url": self.base_url},
        )

    def _execute_before_interceptors(
        self,
        request_obj: Request,
        request_id: str | None,
        observer,
    ) -> Request:
        """执行before_request拦截器链

        Args:
            request_obj: 请求对象
            request_id: 请求ID（用于可观测性）
            observer: Allure观察者

        Returns:
            修改后的Request对象

        Raises:
            MockResponse: Mock响应（需要特殊处理）
            Exception: 拦截器执行失败
        """
        try:
            modified_request = self.interceptor_chain.execute_before_request(
                request_obj,
                request_id=request_id,
                observer=observer,
            )
            return modified_request if modified_request else request_obj
        except Exception as e:
            # ✅ v3.5: 检查是否为Mock响应（直接向上传播）
            from .....testing.mocking import MockResponse

            if isinstance(e, MockResponse):
                raise  # Mock响应需要在request()中特殊处理

            # 其他异常正常处理
            if observer:
                observer.on_error(e, {"stage": "before_request", "request_id": request_id})
            self.interceptor_chain.execute_on_error(e, request_obj)
            raise

    def _convert_request_to_kwargs(self, request_obj: Request, kwargs: dict) -> dict:
        """将Request对象转换回kwargs（用于httpx调用）

        Args:
            request_obj: Request对象
            kwargs: 原始kwargs

        Returns:
            更新后的kwargs
        """
        kwargs["headers"] = dict(request_obj.headers) if request_obj.headers else {}
        if request_obj.params:
            kwargs["params"] = dict(request_obj.params)
        if request_obj.json:
            kwargs["json"] = request_obj.json
        if request_obj.data:
            kwargs["data"] = request_obj.data
        return kwargs

    def _execute_after_interceptors(self, response_obj: Response, request_obj: Request) -> Response:
        """执行after_response拦截器链

        Args:
            response_obj: 响应对象
            request_obj: 请求对象（用于错误处理）

        Returns:
            修改后的Response对象
        """
        try:
            modified_response = self.interceptor_chain.execute_after_response(response_obj)
            return modified_response if modified_response else response_obj
        except Exception as e:
            self.interceptor_chain.execute_on_error(e, request_obj)
            logger.warning(f"[HttpClient] after_response拦截器失败: {e}")
            return response_obj

    def _create_response_object(self, httpx_response: httpx.Response) -> Response:
        """创建Response对象

        Args:
            httpx_response: httpx响应

        Returns:
            Response对象
        """
        json_data = None
        try:
            if httpx_response.headers.get("content-type", "").startswith("application/json"):
                json_data = httpx_response.json()
        except Exception:
            pass

        return Response(
            status_code=httpx_response.status_code,
            headers=dict(httpx_response.headers),
            body=httpx_response.text,
            json_data=json_data,
        )

    # ==================== 主请求方法 ====================

    def request(
        self,
        method: str,
        url: str,
        **kwargs,
    ) -> httpx.Response:
        """
        发送HTTP请求 (支持自动重试)

        ✅ v3.5重构: 拆分为多个辅助方法,降低复杂度
        ✅ v3.5新增: 支持HTTP Mock（通过MockInterceptor）

        重试策略:
        - 自动重试: 超时异常(TimeoutException)和5xx服务器错误
        - 不重试: 4xx客户端错误
        - 重试次数: max_retries (初始化时指定)
        - 退避策略: 指数退避 (1s, 2s, 4s, 8s...)

        Args:
            method: 请求方法 (GET, POST, PUT, DELETE等)
            url: 请求路径
            **kwargs: 其他请求参数 (params, json, data, headers等)

        Returns:
            httpx.Response对象（可能是Mock响应）

        Raises:
            httpx.TimeoutException: 请求超时 (重试max_retries次后仍失败)
            httpx.HTTPStatusError: HTTP状态错误
            httpx.RequestError: 请求错误
        """
        # 初始化可观测性组件
        from .....infrastructure.logging.observability import http_logger
        from .....testing.mocking import MockResponse
        from .....testing.observers.allure_observer import get_current_observer

        obs_logger = http_logger()
        observer = get_current_observer()

        # 1. 准备Request对象
        request_obj = self._prepare_request_object(method, url, **kwargs)

        # 2. 可观测性: 记录请求开始
        start_time = time.time()
        request_id = observer.on_http_request_start(request_obj) if observer else None
        obs_logger.request_start(method, url, request_id)

        try:
            # 3. 执行before_request拦截器链（可能抛出MockResponse）
            request_obj = self._execute_before_interceptors(request_obj, request_id, observer)

            # 4. 转换Request对象为httpx kwargs
            kwargs = self._convert_request_to_kwargs(request_obj, kwargs)
            if request_obj.headers:
                obs_logger.request_headers(request_obj.headers, request_id, sanitize=True)

            # 5. 带重试的请求发送
            return self._send_with_retry(
                method=method,
                url=url,
                kwargs=kwargs,
                request_obj=request_obj,
                request_id=request_id,
                observer=observer,
                obs_logger=obs_logger,
                start_time=start_time,
            )

        except MockResponse as mock_response:
            # ✅ v3.5: 处理Mock响应
            duration_ms = (time.time() - start_time) * 1000

            # 记录Mock响应（可观测性）
            if observer and request_id:
                observer.on_http_request_end(request_id, mock_response.response, duration_ms)
            obs_logger.request_end(request_id, mock_response.response.status_code, duration_ms)

            # 将框架Response转换为httpx.Response
            return self._convert_to_httpx_response(mock_response.response, request_obj)

    def _convert_to_httpx_response(self, response: Response, request: Request) -> httpx.Response:
        """将框架Response对象转换为httpx.Response对象

        用于Mock响应的转换

        Args:
            response: 框架的Response对象
            request: 原始请求对象

        Returns:
            httpx.Response对象
        """
        # 构造httpx.Request对象
        httpx_request = httpx.Request(
            method=request.method,
            url=f"{self.base_url}{request.url}",
            headers=request.headers,
        )

        # 构造httpx.Response对象
        return httpx.Response(
            status_code=response.status_code,
            headers=response.headers,
            content=response.body.encode("utf-8") if response.body else b"",
            request=httpx_request,
        )

    def _send_with_retry(
        self,
        method: str,
        url: str,
        kwargs: dict,
        request_obj: Request,
        request_id: str | None,
        observer,
        obs_logger,
        start_time: float,
    ) -> httpx.Response:
        """带重试逻辑的请求发送

        Args:
            method: 请求方法
            url: 请求URL
            kwargs: 请求参数
            request_obj: Request对象
            request_id: 请求ID
            observer: Allure观察者
            obs_logger: 可观测性日志器
            start_time: 请求开始时间

        Returns:
            httpx.Response对象
        """
        last_exception = None

        for attempt in range(self.max_retries + 1):
            try:
                # 发送HTTP请求
                httpx_response = self.client.request(method, url, **kwargs)

                logger.info(f"Response Status: {httpx_response.status_code}")
                logger.debug(f"Response Body: {httpx_response.text[:500]}")

                # 检查是否需要重试 (5xx错误)
                if httpx_response.status_code >= 500 and attempt < self.max_retries:
                    logger.warning(
                        f"服务器错误 {httpx_response.status_code}, 重试 {attempt + 1}/{self.max_retries}"
                    )
                    time.sleep(2**attempt)  # 指数退避
                    continue

                # 创建Response对象并执行after_response拦截器
                response_obj = self._create_response_object(httpx_response)
                response_obj = self._execute_after_interceptors(response_obj, request_obj)

                # 记录响应完成
                duration_ms = (time.time() - start_time) * 1000
                if observer and request_id:
                    observer.on_http_request_end(request_id, response_obj, duration_ms)
                obs_logger.request_end(request_id, httpx_response.status_code, duration_ms)

                return httpx_response

            except httpx.TimeoutException as e:
                last_exception = e
                self.interceptor_chain.execute_on_error(e, request_obj)

                if attempt < self.max_retries:
                    time.sleep(2**attempt)
                    continue
                else:
                    if observer:
                        observer.on_error(
                            e,
                            {"stage": "request", "request_id": request_id, "attempt": attempt + 1},
                        )
                    obs_logger.request_error(e, request_id)
                    raise

            except httpx.HTTPStatusError as e:
                # 4xx错误不重试
                self.interceptor_chain.execute_on_error(e, request_obj)
                obs_logger.request_end(
                    request_id, e.response.status_code, (time.time() - start_time) * 1000
                )
                raise

            except httpx.RequestError as e:
                last_exception = e
                self.interceptor_chain.execute_on_error(e, request_obj)

                if attempt < self.max_retries:
                    time.sleep(2**attempt)
                    continue
                else:
                    obs_logger.request_error(e, request_id)
                    raise

            except Exception as e:
                self.interceptor_chain.execute_on_error(e, request_obj)
                obs_logger.request_error(e, request_id)
                raise

        # 所有重试失败
        if last_exception:
            raise last_exception

    def get(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """GET请求"""
        return self.request("GET", url, params=params, **kwargs)

    def post(
        self,
        url: str,
        json: dict[str, Any] | BaseModel | None = None,
        data: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """POST请求

        ✅ v3.6新增: 支持直接传入 Pydantic 模型

        Args:
            url: 请求路径
            json: 请求体，支持：
                - Python 字典
                - Pydantic 模型（推荐）- 自动序列化，支持 Decimal/datetime/UUID 等
            data: 表单数据
            **kwargs: 其他请求参数

        Returns:
            httpx.Response对象

        Example:
            >>> # 方式 1: 使用字典（传统方式）
            >>> response = client.post("/api/users", json={"name": "Alice"})
            >>>
            >>> # 方式 2: 使用 Pydantic 模型（推荐）
            >>> from pydantic import BaseModel
            >>> from decimal import Decimal
            >>>
            >>> class PaymentRequest(BaseModel):
            ...     amount: Decimal  # 自动序列化为字符串
            ...
            >>> request = PaymentRequest(amount=Decimal("123.45"))
            >>> response = client.post("/api/payment", json=request)
            >>> # 发送: {"amount":"123.45"}
        """
        return self.request("POST", url, json=json, data=data, **kwargs)

    def put(
        self,
        url: str,
        json: dict[str, Any] | BaseModel | None = None,
        **kwargs,
    ) -> httpx.Response:
        """PUT请求

        ✅ v3.6新增: 支持直接传入 Pydantic 模型

        Args:
            url: 请求路径
            json: 请求体，支持字典或 Pydantic 模型
            **kwargs: 其他请求参数

        Returns:
            httpx.Response对象
        """
        return self.request("PUT", url, json=json, **kwargs)

    def patch(
        self,
        url: str,
        json: dict[str, Any] | BaseModel | None = None,
        **kwargs,
    ) -> httpx.Response:
        """PATCH请求

        ✅ v3.6新增: 支持直接传入 Pydantic 模型

        Args:
            url: 请求路径
            json: 请求体，支持字典或 Pydantic 模型
            **kwargs: 其他请求参数

        Returns:
            httpx.Response对象
        """
        return self.request("PATCH", url, json=json, **kwargs)

    def delete(
        self,
        url: str,
        **kwargs,
    ) -> httpx.Response:
        """DELETE请求"""
        return self.request("DELETE", url, **kwargs)

    def _load_interceptors_from_config(self, interceptor_configs: list[InterceptorConfig]) -> None:
        """从配置自动加载拦截器（v3.5重构版）

        创建Interceptor实例并使用PathFilteredInterceptor包装（如果有路径规则）

        Args:
            interceptor_configs: 拦截器配置列表
        """
        from df_test_framework.clients.http.interceptors import InterceptorFactory

        logger.debug(f"[HttpClient] 开始加载拦截器: count={len(interceptor_configs)}")

        # 按优先级排序
        sorted_configs = sorted(interceptor_configs, key=lambda c: c.priority)

        for config in sorted_configs:
            try:
                # v3.5: Factory直接返回Interceptor实例
                interceptor = InterceptorFactory.create(config)
                if not interceptor:
                    continue

                # v3.5: 如果配置有路径规则，用PathFilteredInterceptor包装
                has_path_rules = (hasattr(config, "include_paths") and config.include_paths) or (
                    hasattr(config, "exclude_paths") and config.exclude_paths
                )

                if has_path_rules:
                    # 包装为路径过滤拦截器
                    interceptor = PathFilteredInterceptor(interceptor, config)
                    logger.debug(
                        f"[HttpClient] 拦截器已包装路径过滤: "
                        f"include={getattr(config, 'include_paths', [])}, "
                        f"exclude={getattr(config, 'exclude_paths', [])}"
                    )

                # v3.5: 添加到InterceptorChain
                self.interceptor_chain.add(interceptor)
                logger.debug(
                    f"[HttpClient] 已加载拦截器: "
                    f"type={config.type}, priority={config.priority}, name={interceptor.name}"
                )

            except Exception as e:
                logger.error(f"[HttpClient] 加载拦截器失败: type={config.type}, error={e}")
                raise

        logger.debug(
            f"[HttpClient] 拦截器加载完成: total={len(self.interceptor_chain.interceptors)}"
        )

    def close(self) -> None:
        """关闭客户端连接"""
        self.client.close()
        logger.debug("HTTP客户端已关闭")

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()


__all__ = ["HttpClient"]
