"""Unit of Work 模式实现

v3.7.0 新增 - 现代化数据访问架构

Unit of Work 模式提供:
- 统一的事务边界管理
- 多个 Repository 共享同一 Session
- 显式的提交/回滚控制
- 测试友好的数据隔离

使用示例:
    >>> with UnitOfWork(session_factory) as uow:
    ...     card = uow.cards.find_by_no("CARD001")
    ...     uow.orders.create({...})
    ...     uow.commit()  # 显式提交，否则自动回滚
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from loguru import logger
from sqlalchemy.orm import Session

if TYPE_CHECKING:
    from collections.abc import Callable


class UnitOfWork:
    """工作单元 - 管理事务边界和 Repository 生命周期

    核心职责:
    1. 管理数据库 Session 生命周期
    2. 提供统一的事务边界（commit/rollback）
    3. 延迟创建 Repository 实例（共享同一 Session）

    设计原则:
    - Repository 只负责数据访问，不管理事务
    - UnitOfWork 负责事务边界，不负责具体查询
    - 所有 Repository 在同一 UoW 中共享 Session

    使用模式:
        # 作为上下文管理器（推荐）
        with UnitOfWork(session_factory) as uow:
            card = uow.cards.find_by_no("CARD001")
            uow.commit()

        # 在 pytest fixture 中
        @pytest.fixture
        def uow(database):
            with UnitOfWork(database.SessionLocal) as uow:
                yield uow
                # 自动回滚（除非已 commit）
    """

    def __init__(self, session_factory: Callable[[], Session]):
        """初始化 UnitOfWork

        Args:
            session_factory: Session 工厂函数，通常是 database.SessionLocal
        """
        self._session_factory = session_factory
        self._session: Session | None = None
        self._repositories: dict[str, Any] = {}
        self._committed = False
        self._registered_repo_attrs: dict[str, tuple[type, str | None]] = {}

    def __enter__(self) -> UnitOfWork:
        """进入上下文，创建 Session"""
        self._session = self._session_factory()
        self._committed = False
        self._repositories.clear()  # 重置Repository缓存
        # 注意: _registered_repo_attrs 不重置，允许在进入上下文前注册
        logger.debug("UnitOfWork: Session 已创建")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """退出上下文，处理事务"""
        if exc_type is not None:
            # 发生异常，回滚
            self.rollback()
            logger.error(f"UnitOfWork: 发生异常，数据已回滚: {exc_val}")
        elif not self._committed:
            # 未提交，回滚（默认行为）
            self.rollback()
            logger.info("✅ UnitOfWork: 数据已回滚（自动清理）")

        self._close()

    @property
    def session(self) -> Session:
        """获取当前 Session

        Returns:
            SQLAlchemy Session 实例

        Raises:
            RuntimeError: 如果 UoW 未在上下文中使用
        """
        if self._session is None:
            raise RuntimeError("UnitOfWork 必须在 with 语句中使用")
        return self._session

    def commit(self) -> None:
        """提交事务

        显式调用 commit() 才会持久化数据，否则自动回滚。
        这是测试友好的设计：默认不保留测试数据。
        """
        self.session.commit()
        self._committed = True
        logger.info("⚠️ UnitOfWork: 数据已提交并保留到数据库")

    def rollback(self) -> None:
        """回滚事务"""
        if self._session:
            self._session.rollback()

    def _close(self) -> None:
        """关闭 Session"""
        if self._session:
            self._session.close()
            self._session = None
            self._repositories.clear()
            logger.debug("UnitOfWork: Session 已关闭")

    def repository(self, repo_class: type, table_name: str | None = None) -> Any:
        """获取或创建 Repository 实例

        Repository 实例会被缓存，同一 UoW 中多次获取返回相同实例。

        Args:
            repo_class: Repository 类
            table_name: 表名（可选，某些 Repository 需要）

        Returns:
            Repository 实例

        Example:
            >>> card_repo = uow.repository(CardRepository)
            >>> order_repo = uow.repository(OrderRepository)
        """
        key = repo_class.__name__
        if key not in self._repositories:
            if table_name:
                self._repositories[key] = repo_class(self.session, table_name)
            else:
                self._repositories[key] = repo_class(self.session)
        return self._repositories[key]

    def register_repository(
        self, name: str, repo_class: type, table_name: str | None = None
    ) -> None:
        """注册 Repository，使其可通过属性访问

        Args:
            name: 属性名
            repo_class: Repository 类
            table_name: 表名（可选）

        Example:
            >>> uow.register_repository("cards", CardRepository)
            >>> card = uow.cards.find_by_no("CARD001")
        """
        self._registered_repo_attrs[name] = (repo_class, table_name)

    def execute(self, sql, params=None):
        """执行原生 SQL

        Args:
            sql: SQL 语句（使用 text() 包装）
            params: 参数字典

        Returns:
            执行结果
        """
        from sqlalchemy import text

        if isinstance(sql, str):
            sql = text(sql)

        return self.session.execute(sql, params or {})

    def __getattr__(self, item: str) -> Any:
        """实例级 Repository 访问"""
        if item in self._registered_repo_attrs:
            repo_class, table_name = self._registered_repo_attrs[item]
            return self.repository(repo_class, table_name)
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{item}'")


class BaseUnitOfWork(UnitOfWork):
    """可扩展的 UnitOfWork 基类

    项目可以继承此类，预注册业务 Repository：

    Example:
        class GiftCardUoW(BaseUnitOfWork):
            @property
            def cards(self) -> CardRepository:
                return self.repository(CardRepository)

            @property
            def orders(self) -> OrderRepository:
                return self.repository(OrderRepository)

        # 使用
        with GiftCardUoW(session_factory) as uow:
            card = uow.cards.find_by_no("CARD001")
    """

    pass
