"""Redis客户端封装"""

from typing import Any

import redis
from loguru import logger


class RedisClient:
    """
    Redis客户端封装

    功能:
    - 提供Redis连接管理
    - 封装常用的Redis操作
    - 支持连接池
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: str | None = None,
        max_connections: int = 50,
        decode_responses: bool = True,
    ):
        """
        初始化Redis客户端

        Args:
            host: Redis主机地址
            port: Redis端口
            db: 数据库编号
            password: 密码
            max_connections: 连接池最大连接数
            decode_responses: 是否自动解码响应为字符串
        """
        self.host = host
        self.port = port
        self.db = db

        # 创建连接池
        self.pool = redis.ConnectionPool(
            host=host,
            port=port,
            db=db,
            password=password,
            max_connections=max_connections,
            decode_responses=decode_responses,
        )

        # 创建Redis客户端
        self.client = redis.Redis(connection_pool=self.pool)

        # v3.5: ObservabilityLogger
        from ...infrastructure.logging.observability import redis_logger

        self.obs_logger = redis_logger()

        logger.info(f"Redis连接已建立: {host}:{port}/{db}")

    def ping(self) -> bool:
        """
        测试连接

        Returns:
            连接是否正常
        """
        try:
            return self.client.ping()
        except Exception as e:
            logger.error(f"Redis连接测试失败: {str(e)}")
            return False

    # ========== 字符串操作 ==========

    def set(
        self,
        key: str,
        value: Any,
        ex: int | None = None,
        nx: bool = False,
    ) -> bool:
        """
        设置键值

        Args:
            key: 键
            value: 值
            ex: 过期时间(秒)
            nx: 如果键不存在才设置

        Returns:
            是否成功
        """
        result = self.client.set(key, value, ex=ex, nx=nx)

        # v3.5: ObservabilityLogger记录缓存操作
        self.obs_logger.cache_operation("SET", key)

        # v3.5: AllureObserver记录缓存操作
        from ...testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()
        if observer:
            observer.on_cache_operation("SET", key, value=value)

        return result

    def get(self, key: str) -> str | None:
        """
        获取值

        Args:
            key: 键

        Returns:
            值,如果不存在返回None
        """
        result = self.client.get(key)

        # v3.5: ObservabilityLogger记录缓存操作
        self.obs_logger.cache_operation("GET", key, hit=(result is not None))

        # v3.5: AllureObserver记录缓存操作
        from ...testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()
        if observer:
            observer.on_cache_operation("GET", key, hit=(result is not None))

        return result

    def delete(self, *keys: str) -> int:
        """
        删除键

        Args:
            *keys: 要删除的键

        Returns:
            删除的键数量
        """
        result = self.client.delete(*keys)

        # v3.5: ObservabilityLogger记录缓存操作
        for key in keys:
            self.obs_logger.cache_operation("DELETE", key)

        # v3.5: AllureObserver记录缓存操作
        from ...testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()
        if observer:
            for key in keys:
                observer.on_cache_operation("DELETE", key)

        return result

    def exists(self, *keys: str) -> int:
        """
        检查键是否存在

        Args:
            *keys: 要检查的键

        Returns:
            存在的键数量
        """
        return self.client.exists(*keys)

    def expire(self, key: str, seconds: int) -> bool:
        """
        设置键的过期时间

        Args:
            key: 键
            seconds: 过期时间(秒)

        Returns:
            是否成功
        """
        return self.client.expire(key, seconds)

    def ttl(self, key: str) -> int:
        """
        获取键的剩余过期时间

        Args:
            key: 键

        Returns:
            剩余秒数,-1表示永久,-2表示不存在
        """
        return self.client.ttl(key)

    # ========== 哈希操作 ==========

    def hset(self, name: str, key: str, value: Any) -> int:
        """设置哈希字段"""
        return self.client.hset(name, key, value)

    def hget(self, name: str, key: str) -> str | None:
        """获取哈希字段"""
        return self.client.hget(name, key)

    def hgetall(self, name: str) -> dict:
        """获取哈希所有字段"""
        return self.client.hgetall(name)

    def hdel(self, name: str, *keys: str) -> int:
        """删除哈希字段"""
        return self.client.hdel(name, *keys)

    # ========== 列表操作 ==========

    def lpush(self, name: str, *values: Any) -> int:
        """从左边推入列表"""
        return self.client.lpush(name, *values)

    def rpush(self, name: str, *values: Any) -> int:
        """从右边推入列表"""
        return self.client.rpush(name, *values)

    def lpop(self, name: str) -> str | None:
        """从左边弹出"""
        return self.client.lpop(name)

    def rpop(self, name: str) -> str | None:
        """从右边弹出"""
        return self.client.rpop(name)

    def lrange(self, name: str, start: int, end: int) -> list:
        """获取列表范围"""
        return self.client.lrange(name, start, end)

    # ========== 集合操作 ==========

    def sadd(self, name: str, *values: Any) -> int:
        """添加到集合"""
        return self.client.sadd(name, *values)

    def smembers(self, name: str) -> set:
        """获取集合所有成员"""
        return self.client.smembers(name)

    def srem(self, name: str, *values: Any) -> int:
        """从集合移除"""
        return self.client.srem(name, *values)

    # ========== 有序集合操作 ==========

    def zadd(self, name: str, mapping: dict) -> int:
        """添加到有序集合"""
        return self.client.zadd(name, mapping)

    def zrange(self, name: str, start: int, end: int, withscores: bool = False) -> list:
        """获取有序集合范围"""
        return self.client.zrange(name, start, end, withscores=withscores)

    # ========== 通用操作 ==========

    def keys(self, pattern: str = "*") -> list:
        """
        获取匹配的键列表

        Args:
            pattern: 匹配模式

        Returns:
            键列表
        """
        return self.client.keys(pattern)

    def flushdb(self) -> bool:
        """清空当前数据库"""
        logger.warning(f"清空Redis数据库: DB{self.db}")
        return self.client.flushdb()

    def close(self) -> None:
        """关闭连接"""
        self.client.close()
        logger.info("Redis连接已关闭")


__all__ = ["RedisClient"]
