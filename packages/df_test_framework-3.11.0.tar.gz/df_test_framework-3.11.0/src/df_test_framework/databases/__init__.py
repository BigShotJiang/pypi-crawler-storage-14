"""数据访问能力层 - Layer 1

提供SQL、NoSQL等数据库访问能力
按数据库类型扁平化组织：mysql/、postgresql/、redis/、mongodb/等

v3.7.0 新增:
- UnitOfWork 模式：统一事务边界管理
- BaseUnitOfWork：可扩展的 UoW 基类
"""

# 工厂类
# 通用Database类（支持MySQL/PostgreSQL/SQLite等）
from .database import Database
from .factory import DatabaseFactory

# Redis客户端
from .redis.redis_client import RedisClient

# Repository模式
from .repositories.base import BaseRepository
from .repositories.query_spec import QuerySpec

# Unit of Work 模式
from .uow import BaseUnitOfWork, UnitOfWork

__all__ = [
    # 工厂
    "DatabaseFactory",
    # 通用Database
    "Database",
    # Unit of Work
    "UnitOfWork",
    "BaseUnitOfWork",
    # Repository模式
    "BaseRepository",
    "QuerySpec",
    # Redis
    "RedisClient",
]
