"""数据库操作封装

v1.2.0 新增:
- 批量操作支持
- 表名白名单验证
- 增强的错误处理

v3.0.0 新增:
- 集成DBDebugger调试支持（可选）

v3.5.0 新增:
- 集成ObservabilityLogger实时日志（默认）
- 集成AllureObserver自动附件（默认）

v3.6.1 修复:
- Database.execute() 迁移到 ObservabilityLogger（统一日志输出）
"""

from contextlib import contextmanager
from typing import Any

from loguru import logger
from sqlalchemy import Engine, create_engine, text
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import QueuePool
from sqlalchemy.sql import Executable

# ========== 表名白名单 (安全措施) ==========
# 生产环境应该明确定义允许操作的表
# 防止SQL注入和误操作

# 默认不限制表名 (开发/测试环境)
# None表示允许所有表,空集表示禁止所有表,有值则只允许白名单内的表
DEFAULT_ALLOWED_TABLES: set[str] | None = None


class Database:
    """
    数据库操作封装

    功能:
    - 提供数据库连接管理
    - 支持会话上下文管理
    - 提供常用的查询和执行方法
    """

    def __init__(
        self,
        connection_string: str,
        pool_size: int = 10,
        max_overflow: int = 20,
        pool_timeout: int = 30,
        pool_recycle: int = 3600,
        pool_pre_ping: bool = True,
        echo: bool = False,
        allowed_tables: set[str] | None = None,
    ):
        """
        初始化数据库连接

        Args:
            connection_string: 数据库连接字符串
                示例: mysql+pymysql://user:password@host:port/database?charset=utf8mb4
            pool_size: 连接池大小 (默认10)
            max_overflow: 连接池最大溢出数 (默认20)
            pool_timeout: 连接池超时时间(秒) (默认30)
            pool_recycle: 连接回收时间(秒) (默认3600,防止连接过期)
            pool_pre_ping: 是否检测连接有效性 (默认True)
            echo: 是否打印SQL语句 (默认False)
            allowed_tables: 允许操作的表名白名单 (None表示允许所有表)

        Example:
            # 开发/测试环境: 不限制表名 (默认)
            db = Database(connection_string)
            # 等同于: allowed_tables=None

            # 生产环境: 限制表名白名单
            db = Database(
                connection_string,
                allowed_tables={"users", "orders", "products"}
            )

            # 特殊场景: 禁止所有表操作
            db = Database(
                connection_string,
                allowed_tables=set()  # 空集禁止所有表
            )
        """
        self.connection_string = connection_string
        # 注意: 使用 is not None 判断,因为空集set()也是合法值(表示禁止所有表)
        self.allowed_tables = (
            allowed_tables if allowed_tables is not None else DEFAULT_ALLOWED_TABLES
        )

        # 创建数据库引擎
        self.engine: Engine = create_engine(
            connection_string,
            poolclass=QueuePool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,  # ✅ 添加连接回收
            pool_pre_ping=pool_pre_ping,  # 检测连接是否有效
            echo=echo,
        )

        # 创建会话工厂
        self.SessionLocal = sessionmaker(
            bind=self.engine,
            autocommit=False,
            autoflush=False,
            expire_on_commit=False,
        )

        # v3.5: ObservabilityLogger
        from ..infrastructure.logging.observability import db_logger

        self.obs_logger = db_logger()
        self._query_counter = 0  # 查询计数器（用于生成query_id）

        # 初始化日志（兼容旧logger）
        logger.info(f"数据库连接已建立: {self._mask_connection_string()}")
        if self.allowed_tables is not None:
            if self.allowed_tables:
                logger.debug(f"表名白名单已启用, 允许的表: {self.allowed_tables}")
            else:
                logger.warning("表名白名单为空集, 禁止所有表操作")

    def _mask_connection_string(self) -> str:
        """隐藏连接字符串中的密码"""
        if "@" in self.connection_string:
            parts = self.connection_string.split("@")
            if ":" in parts[0]:
                user_pass = parts[0].split(":")
                return f"{user_pass[0]}:****@{parts[1]}"
        return self.connection_string

    def _generate_query_id(self) -> str:
        """生成查询ID（用于日志关联）"""
        self._query_counter += 1
        return f"query-{self._query_counter:03d}"

    def _validate_table_name(self, table: str) -> None:
        """
        验证表名是否在白名单中

        逻辑规则:
        - allowed_tables=None: 允许所有表 (不检查)
        - allowed_tables=set(): 禁止所有表 (抛出异常)
        - allowed_tables={"a","b"}: 只允许白名单中的表

        Args:
            table: 表名

        Raises:
            ValueError: 表名不在白名单中或白名单为空
        """
        # None表示不限制
        if self.allowed_tables is None:
            return

        # 空集表示禁止所有表
        if not self.allowed_tables:
            raise ValueError(
                f"表操作已禁用: 白名单为空集, 不允许操作任何表. 尝试操作的表: '{table}'"
            )

        # 检查表名是否在白名单中
        if table not in self.allowed_tables:
            raise ValueError(f"表名 '{table}' 不在白名单中. 允许的表: {self.allowed_tables}")

    @staticmethod
    def _prepare_statement(sql: str | Executable) -> Executable:
        """
        将字符串SQL或可执行语句统一转换为 Executable 对象

        Args:
            sql: SQL字符串或已经构建好的Executable
        """
        if isinstance(sql, str):
            return text(sql)
        return sql

    @contextmanager
    def session(self) -> Session:
        """
        获取数据库会话上下文管理器

        使用方式:
            with db.session() as session:
                result = session.execute(text("SELECT * FROM table"))

        Yields:
            Session: SQLAlchemy会话对象
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"数据库操作失败,已回滚: {str(e)}")
            raise
        finally:
            session.close()

    @contextmanager
    def transaction(self):
        """
        事务上下文管理器 - 支持原子操作

        使用方式:
            with db.transaction():
                db.insert("users", {"name": "张三"})
                db.insert("orders", {"user_id": 1})
                # 要么都成功，要么都回滚

        Yields:
            Session: SQLAlchemy会话对象
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
            logger.info("事务已成功提交")
        except Exception as e:
            session.rollback()
            logger.error(f"事务已回滚: {str(e)}")
            raise
        finally:
            session.close()

    @contextmanager
    def savepoint(self, name: str = "sp1"):
        """
        保存点 - 支持部分回滚

        使用方式:
            with db.transaction():
                db.insert("users", {"name": "张三"})
                try:
                    with db.savepoint("sp1"):
                        db.insert("orders", {"user_id": 1})
                        raise ValueError("订单验证失败")
                except ValueError:
                    # 只回滚到保存点，user已插入
                    pass
                # 继续操作
                db.insert("logs", {"message": "处理完成"})

        Args:
            name: 保存点名称

        Yields:
            Savepoint对象
        """
        session = self.SessionLocal()
        savepoint = session.begin_nested()
        try:
            yield savepoint
            savepoint.commit()
            logger.debug(f"保存点 {name} 已提交")
        except Exception as e:
            savepoint.rollback()
            logger.debug(f"保存点 {name} 已回滚: {str(e)}")
            raise
        finally:
            session.close()

    def execute(
        self,
        sql: str | Executable,
        params: dict[str, Any] | None = None,
    ) -> int:
        """
        执行SQL语句(INSERT/UPDATE/DELETE)

        Args:
            sql: SQL语句
            params: 参数字典

        Returns:
            影响的行数

        Note:
            此方法仅用于非查询语句,查询请使用 query_one() 或 query_all()
        """
        # v3.5: ObservabilityLogger
        import time

        query_id = self._generate_query_id()

        # 从SQL中提取操作类型和表名
        sql_str = str(sql).strip().upper()
        operation = "EXECUTE"
        table_name = "unknown"

        # 尝试解析操作类型
        for op in ["INSERT", "UPDATE", "DELETE"]:
            if sql_str.startswith(op):
                operation = op
                break

        # 尝试解析表名
        if "INTO" in sql_str:  # INSERT INTO table
            parts = sql_str.split("INTO")[1].split()
            if parts:
                table_name = parts[0].strip()
        elif operation in ["UPDATE", "DELETE"]:
            # UPDATE table SET / DELETE FROM table
            keyword = "FROM" if operation == "DELETE" else operation
            if keyword in sql_str:
                parts = sql_str.split(keyword)[1].split()
                if parts:
                    table_name = parts[0].strip()

        # v3.5: AllureObserver集成
        from ..testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()

        session: Session
        with self.session() as session:
            # ObservabilityLogger: 记录查询开始
            start_time = time.time()
            self.obs_logger.query_start(operation, table_name, query_id)

            # AllureObserver: 记录查询开始
            if observer:
                observer.on_query_start(
                    query_id=query_id,
                    operation=operation,
                    table=table_name,
                    sql=str(sql),
                    params=params,
                )

            try:
                statement = self._prepare_statement(sql)
                result = session.execute(statement, params or {})
                rowcount = result.rowcount

                # ObservabilityLogger: 记录查询结束
                duration_ms = (time.time() - start_time) * 1000
                self.obs_logger.query_end(query_id, rowcount, duration_ms)

                # AllureObserver: 记录查询结束
                if observer:
                    observer.on_query_end(query_id, rowcount, duration_ms)

                return rowcount
            except Exception as e:
                # ObservabilityLogger: 记录查询错误
                self.obs_logger.query_error(e, query_id)

                # AllureObserver: 记录查询错误
                if observer:
                    observer.on_query_error(query_id, e)

                raise

    def query_one(
        self,
        sql: str | Executable,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """
        查询单条记录

        Args:
            sql: SQL查询语句
            params: 参数字典

        Returns:
            单条记录的字典,如果没有结果则返回None
        """
        # v3.5: ObservabilityLogger
        import time

        query_id = self._generate_query_id()

        # 从SQL中提取表名（简单解析）
        sql_str = str(sql).strip().upper()
        table_name = "unknown"
        if "FROM" in sql_str:
            parts = sql_str.split("FROM")[1].split()
            if parts:
                table_name = parts[0].strip()

        # v3.5: AllureObserver集成
        from ..testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()

        session: Session
        with self.session() as session:
            # ObservabilityLogger: 记录查询开始
            start_time = time.time()
            self.obs_logger.query_start("SELECT", table_name, query_id)

            # AllureObserver: 记录查询开始
            if observer:
                observer.on_query_start(
                    query_id=query_id,
                    operation="SELECT",
                    table=table_name,
                    sql=str(sql),
                    params=params,
                )

            try:
                statement = self._prepare_statement(sql)
                result = session.execute(statement, params or {})
                row = result.fetchone()

                # ObservabilityLogger: 记录查询结束
                duration_ms = (time.time() - start_time) * 1000
                row_count = 1 if row else 0
                self.obs_logger.query_end(query_id, row_count, duration_ms)

                # AllureObserver: 记录查询结束
                if observer:
                    observer.on_query_end(query_id, row_count, duration_ms)

                if row:
                    return dict(row._mapping)
                return None
            except Exception as e:
                # ObservabilityLogger: 记录查询错误
                self.obs_logger.query_error(e, query_id)

                # AllureObserver: 记录查询错误
                if observer:
                    observer.on_query_error(query_id, e)

                raise

    def query_all(
        self,
        sql: str | Executable,
        params: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """
        查询多条记录

        Args:
            sql: SQL查询语句
            params: 参数字典

        Returns:
            记录列表
        """
        # v3.5: ObservabilityLogger
        import time

        query_id = self._generate_query_id()

        # 从SQL中提取表名
        sql_str = str(sql).strip().upper()
        table_name = "unknown"
        if "FROM" in sql_str:
            parts = sql_str.split("FROM")[1].split()
            if parts:
                table_name = parts[0].strip()

        # v3.5: AllureObserver集成
        from ..testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()

        session: Session
        with self.session() as session:
            # ObservabilityLogger: 记录查询开始
            start_time = time.time()
            self.obs_logger.query_start("SELECT", table_name, query_id)

            # AllureObserver: 记录查询开始
            if observer:
                observer.on_query_start(
                    query_id=query_id,
                    operation="SELECT",
                    table=table_name,
                    sql=str(sql),
                    params=params,
                )

            try:
                statement = self._prepare_statement(sql)
                result = session.execute(statement, params or {})
                rows = result.fetchall()
                result_list = [dict(row._mapping) for row in rows]

                # ObservabilityLogger: 记录查询结束
                duration_ms = (time.time() - start_time) * 1000
                self.obs_logger.query_end(query_id, len(result_list), duration_ms)

                # AllureObserver: 记录查询结束
                if observer:
                    observer.on_query_end(query_id, len(result_list), duration_ms)

                return result_list
            except Exception as e:
                # ObservabilityLogger: 记录查询错误
                self.obs_logger.query_error(e, query_id)

                # AllureObserver: 记录查询错误
                if observer:
                    observer.on_query_error(query_id, e)

                raise

    def insert(
        self,
        table: str,
        data: dict[str, Any],
    ) -> int:
        """
        插入记录

        Args:
            table: 表名
            data: 数据字典

        Returns:
            插入的记录ID

        Raises:
            ValueError: 表名不在白名单中
            IntegrityError: 违反唯一性约束等完整性错误
            OperationalError: 数据库操作错误
        """
        self._validate_table_name(table)

        # v3.5: ObservabilityLogger
        import time

        query_id = self._generate_query_id()

        columns = ", ".join(data.keys())
        placeholders = ", ".join([f":{key}" for key in data.keys()])
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"

        # v3.5: AllureObserver集成
        from ..testing.observers.allure_observer import get_current_observer

        observer = get_current_observer()

        try:
            # ObservabilityLogger: 记录INSERT开始
            start_time = time.time()
            self.obs_logger.query_start("INSERT", table, query_id)

            # AllureObserver: 记录INSERT开始
            if observer:
                observer.on_query_start(
                    query_id=query_id, operation="INSERT", table=table, sql=sql, params=data
                )

            session: Session
            with self.session() as session:
                result = session.execute(text(sql), data)
                inserted_id = result.lastrowid

                # ObservabilityLogger: 记录INSERT结束
                duration_ms = (time.time() - start_time) * 1000
                self.obs_logger.query_end(query_id, 1, duration_ms)

                # AllureObserver: 记录INSERT结束
                if observer:
                    observer.on_query_end(query_id, 1, duration_ms)

                return inserted_id
        except (IntegrityError, OperationalError) as e:
            # ObservabilityLogger: 记录错误
            self.obs_logger.query_error(e, query_id)

            # AllureObserver: 记录错误
            if observer:
                observer.on_query_error(query_id, e)

            raise

    def batch_insert(
        self,
        table: str,
        data_list: list[dict[str, Any]],
        chunk_size: int = 1000,
    ) -> int:
        """
        批量插入记录

        Args:
            table: 表名
            data_list: 数据字典列表
            chunk_size: 每批次插入数量 (默认1000)

        Returns:
            插入的总记录数

        Raises:
            ValueError: 表名不在白名单中或数据列表为空
            IntegrityError: 违反唯一性约束
            OperationalError: 数据库操作错误

        Example:
            data_list = [
                {"name": "张三", "age": 20},
                {"name": "李四", "age": 25},
                # ... 更多数据
            ]
            count = db.batch_insert("users", data_list)
        """
        self._validate_table_name(table)

        if not data_list:
            raise ValueError("数据列表不能为空")

        # 获取列名 (从第一条数据)
        columns = list(data_list[0].keys())
        columns_str = ", ".join(columns)
        placeholders = ", ".join([f":{col}" for col in columns])

        sql = f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders})"

        total_inserted = 0
        try:
            session: Session
            with self.session() as session:
                # 分批插入
                for i in range(0, len(data_list), chunk_size):
                    chunk = data_list[i : i + chunk_size]
                    session.execute(text(sql), chunk)
                    total_inserted += len(chunk)
                    logger.debug(
                        f"批量插入: {table}, 当前批次 {len(chunk)} 条, 累计 {total_inserted} 条"
                    )

                logger.info(f"批量插入成功: {table}, 总计 {total_inserted} 条记录")
                return total_inserted
        except IntegrityError as e:
            logger.error(f"批量插入数据完整性错误: {table}, 错误: {e.orig}")
            raise
        except OperationalError as e:
            logger.error(f"批量插入操作错误: {table}, 错误: {str(e)}")
            raise

    def update(
        self,
        table: str,
        data: dict[str, Any],
        where: str,
        where_params: dict[str, Any] | None = None,
    ) -> int:
        """
        更新记录

        Args:
            table: 表名
            data: 要更新的数据字典
            where: WHERE条件
            where_params: WHERE条件参数

        Returns:
            影响的行数

        Raises:
            ValueError: 表名不在白名单中
            OperationalError: 数据库操作错误
        """
        self._validate_table_name(table)

        set_clause = ", ".join([f"{key} = :{key}" for key in data.keys()])
        sql = f"UPDATE {table} SET {set_clause} WHERE {where}"

        params = {**data, **(where_params or {})}

        try:
            session: Session
            with self.session() as session:
                result = session.execute(text(sql), params)
                affected_rows = result.rowcount
                logger.info(f"更新记录成功: {table}, 影响行数: {affected_rows}")
                return affected_rows
        except OperationalError as e:
            logger.error(f"更新操作错误: {table}, 错误: {str(e)}")
            raise

    def delete(
        self,
        table: str,
        where: str,
        where_params: dict[str, Any] | None = None,
    ) -> int:
        """
        删除记录

        Args:
            table: 表名
            where: WHERE条件
            where_params: WHERE条件参数

        Returns:
            删除的行数

        Raises:
            ValueError: 表名不在白名单中
            OperationalError: 数据库操作错误
        """
        self._validate_table_name(table)

        sql = f"DELETE FROM {table} WHERE {where}"

        try:
            session: Session
            with self.session() as session:
                result = session.execute(text(sql), where_params or {})
                deleted_rows = result.rowcount
                logger.info(f"删除记录成功: {table}, 删除行数: {deleted_rows}")
                return deleted_rows
        except OperationalError as e:
            logger.error(f"删除操作错误: {table}, 错误: {str(e)}")
            raise

    def close(self) -> None:
        """关闭数据库连接"""
        self.engine.dispose()
        logger.info("数据库连接已关闭")


__all__ = ["Database"]
