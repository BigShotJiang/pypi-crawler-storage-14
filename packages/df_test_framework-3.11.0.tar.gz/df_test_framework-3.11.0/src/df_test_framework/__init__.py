"""
DF 测试自动化框架 v3.11

基于交互模式的现代化测试自动化框架，支持API、UI、数据库、消息队列等多种测试场景。

核心特性:
- 🌐 协议扩展 - GraphQL/gRPC 客户端（v3.11）
- 🎭 Mock 增强 - DatabaseMocker/RedisMocker（v3.11）
- 📊 可观测性增强 - OpenTelemetry/Prometheus（v3.10）
- 💾 存储客户端 - LocalFile/S3/OSS（v3.10）
- 🎯 配置化拦截器系统（v3.5 Phase 1）
- 🔍 完整的可观测性集成（v3.5 Phase 2）
- ⚙️ Profile环境配置 + 运行时覆盖（v3.5 Phase 3）
- 🚀 异步HTTP客户端 - 性能提升40倍（v3.8）
- 🔄 Unit of Work 模式支持（v3.7）
- ⚡ Circuit Breaker 熔断器（v3.7）
- 🏗️ 基于交互模式的分层架构
- 🔌 插件化扩展系统
- 📦 Repository + Builder 设计模式
"""

__version__ = "3.11.0"
__author__ = "DF QA Team"

# ============= 异常体系 =============
# HTTP核心对象
# GraphQL客户端
from .clients.graphql import (
    GraphQLClient,
    GraphQLError,
    GraphQLRequest,
    GraphQLResponse,
    QueryBuilder,
)

# gRPC客户端
from .clients.grpc import (
    GrpcClient,
    GrpcError,
    GrpcResponse,
)
from .clients.http.core import Request, Response

# HTTP拦截器
from .clients.http.interceptors import (
    BearerTokenInterceptor,
    LoggingInterceptor,
    SignatureInterceptor,
)

# HTTP签名策略
from .clients.http.interceptors.signature import (
    HMACSignatureStrategy,
    MD5SortedValuesStrategy,
    SHA256SortedValuesStrategy,
    SignatureStrategy,
)

# ============= 核心功能层 =============
# HTTP客户端
from .clients.http.rest.httpx import (
    AsyncHttpClient,
    BaseAPI,
    BusinessError,
    HttpClient,
)
from .common.exceptions import (
    ConfigurationError,
    DatabaseError,
    ExtensionError,
    FrameworkError,
    HttpError,
    ProviderError,
    RedisError,
    ResourceError,
    TestError,
    ValidationError,
)

# 数据库
from .databases.database import Database
from .databases.redis.redis_client import RedisClient

# Repository模式
from .databases.repositories.base import BaseRepository
from .databases.repositories.query_spec import QuerySpec

# Unit of Work 模式
from .databases.uow import BaseUnitOfWork, UnitOfWork

# ============= UI模块 =============
from .drivers.web import (
    BasePage,
    BrowserManager,
    BrowserType,
    ElementLocator,
    LocatorType,
    WaitHelper,
)

# ============= 扩展系统 =============
from .extensions import (
    ExtensionManager,
    create_extension_manager,
    hookimpl,
)
from .extensions.builtin import (
    APIPerformanceTracker,
    SlowQueryMonitor,
)

# ============= 基础设施层 =============
from .infrastructure import (
    # Bootstrap
    Bootstrap,
    BootstrapApp,
    DatabaseConfig,
    # Config
    FrameworkSettings,
    HTTPConfig,
    # Logging
    LoggerStrategy,
    LoggingConfig,
    LoguruStructuredStrategy,
    NoOpStrategy,
    Provider,
    # Providers
    ProviderRegistry,
    RedisConfig,
    RuntimeBuilder,
    # Runtime
    RuntimeContext,
    SignatureConfig,  # 签名配置属于基础设施层
    SingletonProvider,
    TestExecutionConfig,
    clear_settings,
    configure_settings,
    create_settings,
    default_providers,
    get_settings,
)

# ============= 数据模型 =============
from .models import (
    BaseRequest,
    BaseResponse,
    DatabaseOperation,
    Environment,
    HttpMethod,
    HttpStatus,
    HttpStatusGroup,
    LogLevel,
    PageResponse,
    TestPriority,
    TestType,
)

# ============= 设计模式层 =============
# Builder模式
from .testing.data.builders.base import BaseBuilder, DictBuilder
from .testing.debug import (
    DBDebugger,
    HTTPDebugger,
    disable_db_debug,
    disable_http_debug,
    enable_db_debug,
    enable_http_debug,
)

# ============= 测试支持层 =============
from .testing.fixtures import (
    BaseTestDataCleaner,
    GenericTestDataCleaner,
    database,
    http_client,
    redis_client,
    runtime,
)
from .testing.plugins import (
    AllureHelper,
    EnvironmentMarker,
    attach_json,
    attach_log,
    attach_screenshot,
    dev_only,
    get_env,
    is_env,
    prod_only,
    skip_if_dev,
    skip_if_prod,
    step,
)
from .utils.assertion import assert_that
from .utils.data_generator import DataGenerator

# ============= 工具函数 =============
from .utils.decorator import (
    cache_result,
    deprecated,
    log_execution,
    retry_on_failure,
)
from .utils.performance import (
    PerformanceCollector,
    PerformanceTimer,
    track_performance,
)

# ============= 类型工具 (v3.6新增) =============
from .utils.types import Decimal, DecimalAsCurrency, DecimalAsFloat

# ============= 全部导出 =============
__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    # ===== 异常体系 =====
    "FrameworkError",
    "ConfigurationError",
    "ResourceError",
    "DatabaseError",
    "RedisError",
    "HttpError",
    "ValidationError",
    "ExtensionError",
    "ProviderError",
    "TestError",
    # ===== 基础设施层 =====
    # Bootstrap
    "Bootstrap",
    "BootstrapApp",
    # Runtime
    "RuntimeContext",
    "RuntimeBuilder",
    # Config
    "FrameworkSettings",
    "HTTPConfig",
    "DatabaseConfig",
    "RedisConfig",
    "LoggingConfig",
    "TestExecutionConfig",
    "SignatureConfig",
    "configure_settings",
    "get_settings",
    "clear_settings",
    "create_settings",
    # Logging
    "LoggerStrategy",
    "LoguruStructuredStrategy",
    "NoOpStrategy",
    # Providers
    "ProviderRegistry",
    "Provider",
    "SingletonProvider",
    "default_providers",
    # ===== 核心功能层 =====
    # HTTP客户端
    "HttpClient",
    "AsyncHttpClient",
    "BaseAPI",
    "BusinessError",
    # HTTP核心对象
    "Request",
    "Response",
    # HTTP拦截器
    "SignatureInterceptor",
    "BearerTokenInterceptor",
    "LoggingInterceptor",
    # HTTP签名策略
    "SignatureStrategy",
    "MD5SortedValuesStrategy",
    "SHA256SortedValuesStrategy",
    "HMACSignatureStrategy",
    # GraphQL客户端 (v3.11)
    "GraphQLClient",
    "GraphQLRequest",
    "GraphQLResponse",
    "GraphQLError",
    "QueryBuilder",
    # gRPC客户端 (v3.11)
    "GrpcClient",
    "GrpcResponse",
    "GrpcError",
    # 数据库
    "Database",
    "RedisClient",
    # ===== 设计模式层 =====
    "BaseBuilder",
    "DictBuilder",
    "BaseRepository",
    "QuerySpec",
    # Unit of Work
    "UnitOfWork",
    "BaseUnitOfWork",
    # ===== 测试支持层 =====
    # Fixtures
    "runtime",
    "http_client",
    "database",
    "redis_client",
    "BaseTestDataCleaner",
    "GenericTestDataCleaner",
    # Plugins
    "AllureHelper",
    "EnvironmentMarker",
    "attach_json",
    "attach_log",
    "attach_screenshot",
    "step",
    "get_env",
    "is_env",
    "skip_if_prod",
    "skip_if_dev",
    "dev_only",
    "prod_only",
    # Debug工具
    "HTTPDebugger",
    "DBDebugger",
    "enable_http_debug",
    "disable_http_debug",
    "enable_db_debug",
    "disable_db_debug",
    # ===== 扩展系统 =====
    "create_extension_manager",
    "ExtensionManager",
    "hookimpl",
    "APIPerformanceTracker",
    "SlowQueryMonitor",
    # ===== 数据模型 =====
    "BaseRequest",
    "BaseResponse",
    "PageResponse",
    "HttpMethod",
    "Environment",
    "LogLevel",
    "HttpStatus",
    "HttpStatusGroup",
    "DatabaseOperation",
    "TestPriority",
    "TestType",
    # ===== 工具函数 =====
    "cache_result",
    "deprecated",
    "log_execution",
    "retry_on_failure",
    "track_performance",
    "PerformanceTimer",
    "PerformanceCollector",
    "DataGenerator",
    "assert_that",
    # ===== 类型工具 (v3.6) =====
    "Decimal",
    "DecimalAsFloat",
    "DecimalAsCurrency",
    # ===== UI模块 =====
    "BasePage",
    "BrowserManager",
    "BrowserType",
    "ElementLocator",
    "LocatorType",
    "WaitHelper",
]
