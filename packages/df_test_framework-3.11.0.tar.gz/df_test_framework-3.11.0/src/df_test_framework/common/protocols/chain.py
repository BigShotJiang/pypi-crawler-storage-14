"""通用拦截器执行链

责任链模式:
- 自动按priority排序
- 支持短路（InterceptorAbort）
- 洋葱模型（后置处理逆序执行）
"""

from typing import TypeVar

from loguru import logger

from .interceptor import Interceptor, InterceptorAbortError

T = TypeVar("T")


class InterceptorChain[T]:
    """通用拦截器执行链

    使用泛型T表示上下文类型
    - InterceptorChain[Request] - HTTP请求拦截器链
    - InterceptorChain[DBQuery] - 数据库查询拦截器链

    责任链模式：
    - 按priority排序（数字越小越先执行）
    - before正序执行
    - after逆序执行（洋葱模型）

    Example:
        >>> chain = InterceptorChain[Request]()
        >>> chain.add(SignatureInterceptor(priority=10))
        >>> chain.add(LoggingInterceptor(priority=100))
        >>>
        >>> # 执行顺序:
        >>> # 1. SignatureInterceptor.before (priority=10)
        >>> # 2. LoggingInterceptor.before (priority=100)
        >>> # 3. 实际操作（HTTP请求/DB查询）
        >>> # 4. LoggingInterceptor.after (逆序)
        >>> # 5. SignatureInterceptor.after (逆序)
    """

    def __init__(self, interceptors: list[Interceptor[T]] = None):
        """初始化拦截器链

        Args:
            interceptors: 拦截器列表（可选）
        """
        self.interceptors: list[Interceptor[T]] = interceptors or []
        self._sort()

    def add(self, interceptor: Interceptor[T]) -> None:
        """添加拦截器

        Args:
            interceptor: 拦截器实例
        """
        self.interceptors.append(interceptor)
        self._sort()
        logger.debug(
            f"[InterceptorChain] 添加拦截器: {interceptor.name} (priority={interceptor.priority})"
        )

    def _sort(self) -> None:
        """按priority排序（数字越小越先执行）"""
        self.interceptors.sort(key=lambda i: i.priority)

    def execute_before(self, context: T) -> T:
        """执行所有before钩子

        Args:
            context: 上下文对象

        Returns:
            处理后的上下文对象

        Raises:
            InterceptorAbortError: 拦截器主动终止操作
        """
        current_context = context

        for interceptor in self.interceptors:
            try:
                modified_context = interceptor.before(current_context)
                if modified_context is not None:
                    current_context = modified_context

                logger.debug(
                    f"[拦截器] {interceptor.name} (priority={interceptor.priority}) 执行成功"
                )

            except InterceptorAbortError as e:
                logger.warning(f"[拦截器] {interceptor.name} 主动终止操作: {e}")
                raise

            except Exception as e:
                logger.error(f"[拦截器] {interceptor.name} 执行失败: {e}", exc_info=True)
                # 默认容错：继续执行下一个拦截器

        return current_context

    def execute_after(self, context: T) -> T:
        """执行所有after钩子（逆序）

        Args:
            context: 上下文对象

        Returns:
            处理后的上下文对象
        """
        current_context = context

        # 后置处理逆序执行（洋葱模型）
        for interceptor in reversed(self.interceptors):
            try:
                modified_context = interceptor.after(current_context)
                if modified_context is not None:
                    current_context = modified_context

                logger.debug(f"[拦截器] {interceptor.name} 后置处理成功")

            except Exception as e:
                logger.error(f"[拦截器] {interceptor.name} 后置处理失败: {e}", exc_info=True)
                # 后置处理失败不中断

        return current_context

    def execute_on_error(self, error: Exception, context: T) -> None:
        """执行所有on_error钩子

        Args:
            error: 异常对象
            context: 上下文对象
        """
        for interceptor in self.interceptors:
            try:
                interceptor.on_error(error, context)
            except Exception as e:
                logger.error(f"[拦截器] {interceptor.name} 错误处理失败: {e}", exc_info=True)
