"""通用协议

提供框架级别的通用协议和抽象
"""

from .chain import InterceptorChain
from .interceptor import Interceptor, InterceptorAbortError

__all__ = [
    "Interceptor",
    "InterceptorAbortError",
    "InterceptorChain",
]
