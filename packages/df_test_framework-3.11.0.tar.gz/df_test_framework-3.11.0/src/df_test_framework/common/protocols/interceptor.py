"""通用拦截器协议

设计理念:
- 通用的拦截器协议，不绑定到HTTP
- 可用于HTTP、数据库、Redis、消息队列等任何需要拦截的场景
- 使用泛型保证类型安全
"""

from abc import ABC
from typing import TypeVar

# 上下文类型（Request/DBQuery/RedisCommand等）
T = TypeVar("T")


class Interceptor[T](ABC):
    """通用拦截器协议

    使用泛型T表示上下文类型：
    - Interceptor[Request] - HTTP拦截器
    - Interceptor[DBQuery] - 数据库拦截器
    - Interceptor[RedisCommand] - Redis拦截器

    Example:
        >>> class MyInterceptor(Interceptor[Request]):
        >>>     def before(self, context: Request) -> Request:
        >>>         return context.with_header("X-Custom", "value")
    """

    name: str = ""
    priority: int = 100  # 数字越小越先执行

    def before(self, context: T) -> T | None:
        """前置处理

        Args:
            context: 上下文对象（Request/DBQuery/等）

        Returns:
            - None: 不修改上下文
            - T: 修改后的新上下文

        Raises:
            InterceptorAbortError: 主动终止操作
        """
        return None

    def after(self, context: T) -> T | None:
        """后置处理

        Args:
            context: 上下文对象（Response/DBResult/等）

        Returns:
            - None: 不修改上下文
            - T: 修改后的新上下文
        """
        return None

    def on_error(self, error: Exception, context: T) -> None:
        """错误处理（可选）

        Args:
            error: 异常对象
            context: 上下文对象
        """
        pass


class InterceptorAbortError(Exception):
    """拦截器主动终止操作的异常

    拦截器可以抛出此异常来终止操作

    Example:
        >>> class SecurityInterceptor(Interceptor[Request]):
        >>>     def before(self, context: Request) -> Request:
        >>>         if not self._is_safe(context):
        >>>             raise InterceptorAbortError("不安全的请求")
        >>>         return context
    """

    pass
