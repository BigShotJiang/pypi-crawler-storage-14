"""共享基础层 - Layer 0

包含异常定义、类型定义和通用协议
"""

from .exceptions import (
    ConfigurationError,
    DatabaseError,
    ExtensionError,
    FrameworkError,
    HttpError,
    ProviderError,
    RedisError,
    ResourceError,
    TestError,
    ValidationError,
)
from .protocols import (
    Interceptor,
    InterceptorAbortError,
    InterceptorChain,
)
from .types import (
    DatabaseOperation,
    Environment,
    HttpMethod,
    HttpStatus,
    HttpStatusGroup,
    LogLevel,
    TestPriority,
    TestType,
)

__all__ = [
    # Exceptions
    "FrameworkError",
    "ConfigurationError",
    "ResourceError",
    "DatabaseError",
    "RedisError",
    "HttpError",
    "ValidationError",
    "ExtensionError",
    "ProviderError",
    "TestError",
    # Types
    "HttpMethod",
    "Environment",
    "LogLevel",
    "HttpStatus",
    "HttpStatusGroup",
    "DatabaseOperation",
    "TestPriority",
    "TestType",
    # Protocols
    "Interceptor",
    "InterceptorAbortError",
    "InterceptorChain",
]
