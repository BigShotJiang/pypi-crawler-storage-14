"""
DF Test Framework统一异常体系

定义了框架所有异常的层次结构，便于统一处理和错误分类。
"""

from __future__ import annotations

from typing import Any


class FrameworkError(Exception):
    """框架基础异常

    所有框架异常的基类，用于统一捕获框架相关错误。

    Attributes:
        message: 错误消息
        details: 错误详细信息（可选）
    """

    def __init__(self, message: str, details: Any | None = None):
        self.message = message
        self.details = details
        super().__init__(message)

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} (详情: {self.details})"
        return self.message


class ConfigurationError(FrameworkError):
    """配置错误

    配置加载、验证或使用过程中的错误。

    Examples:
        >>> raise ConfigurationError("API base URL未配置")
        >>> raise ConfigurationError("数据库连接串格式错误", details={"url": "..."})
    """

    pass


class ResourceError(FrameworkError):
    """资源错误

    资源（数据库、Redis、HTTP等）访问或操作错误的基类。
    """

    pass


class DatabaseError(ResourceError):
    """数据库错误

    数据库连接、查询、事务等操作错误。

    Examples:
        >>> raise DatabaseError("数据库连接失败")
        >>> raise DatabaseError("查询超时", details={"sql": "SELECT ..."})
    """

    pass


class RedisError(ResourceError):
    """Redis错误

    Redis连接或操作错误。

    Examples:
        >>> raise RedisError("Redis连接失败")
        >>> raise RedisError("Key不存在", details={"key": "user:123"})
    """

    pass


class HttpError(ResourceError):
    """HTTP错误

    HTTP请求或响应错误。

    Attributes:
        status_code: HTTP状态码（可选）
        response_data: 响应数据（可选）

    Examples:
        >>> raise HttpError("请求失败", details={"url": "/api/users", "status": 500})
        >>> raise HttpError("API返回错误", details={"code": "USER_NOT_FOUND"})
    """

    def __init__(
        self,
        message: str,
        details: Any | None = None,
        status_code: int | None = None,
        response_data: Any | None = None,
    ):
        super().__init__(message, details)
        self.status_code = status_code
        self.response_data = response_data


class ValidationError(FrameworkError):
    """验证错误

    数据验证、参数检查等错误。

    Examples:
        >>> raise ValidationError("用户名不能为空")
        >>> raise ValidationError("邮箱格式错误", details={"email": "invalid"})
    """

    pass


class ExtensionError(FrameworkError):
    """扩展错误

    扩展加载、执行或Hook调用错误。

    Examples:
        >>> raise ExtensionError("扩展加载失败")
        >>> raise ExtensionError("Hook执行错误", details={"hook": "df_providers"})
    """

    pass


class ProviderError(FrameworkError):
    """Provider错误

    Provider注册、查找或实例化错误。

    Examples:
        >>> raise ProviderError("Provider未注册", details={"name": "custom_service"})
        >>> raise ProviderError("Provider实例化失败")
    """

    pass


class TestError(FrameworkError):
    """测试错误

    测试执行过程中的框架级错误（不是测试断言失败）。

    Examples:
        >>> raise TestError("Fixture初始化失败")
        >>> raise TestError("测试数据清理失败")
    """

    pass


__all__ = [
    "FrameworkError",
    "ConfigurationError",
    "ResourceError",
    "DatabaseError",
    "RedisError",
    "HttpError",
    "ValidationError",
    "ExtensionError",
    "ProviderError",
    "TestError",
]
