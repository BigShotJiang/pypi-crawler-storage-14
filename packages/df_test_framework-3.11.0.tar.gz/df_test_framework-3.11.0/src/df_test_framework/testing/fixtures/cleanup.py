"""测试数据清理fixtures - 通用基础设施

v1.2.0 新增:
- 提供通用的测试数据清理基础设施
- 不包含业务相关逻辑(如卡片、订单等)
- 测试项目需要继承并实现具体的清理逻辑

重要说明:
- 本模块只提供通用的清理器基类
- 具体业务相关的清理逻辑应在测试项目中实现
- 参考 examples.py 查看如何在测试项目中使用
"""

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

from loguru import logger

from ...databases.database import Database


class BaseTestDataCleaner(ABC):
    """测试数据清理器基类

    提供通用的资源注册和清理机制
    测试项目应继承此类并实现具体的清理逻辑

    示例:
        # 在测试项目中创建具体的清理器
        class MyTestDataCleaner(BaseTestDataCleaner):
            def cleanup(self):
                # 清理具体业务数据
                if self.resources.get("card_nos"):
                    self.db.execute(
                        "DELETE FROM cards WHERE card_no IN :ids",
                        {"ids": tuple(self.resources["card_nos"])}
                    )

        # 在conftest.py中使用
        @pytest.fixture
        def data_cleaner(db):
            cleaner = MyTestDataCleaner(db)
            yield cleaner
            cleaner.cleanup()

    v1.2.0 新增 - 通用基础设施
    """

    def __init__(self, db: Database):
        """初始化清理器

        Args:
            db: 数据库实例
        """
        self.db = db
        self.resources: dict[str, list[Any]] = {}  # 资源字典,由子类定义结构

    def register(self, resource_type: str, resource_id: Any) -> None:
        """注册资源,测试结束后自动清理

        Args:
            resource_type: 资源类型(如 "card_nos", "order_ids" 等)
            resource_id: 资源ID

        示例:
            cleaner.register("card_nos", "CARD001")
            cleaner.register("user_ids", "user_001")
        """
        if resource_type not in self.resources:
            self.resources[resource_type] = []
        self.resources[resource_type].append(resource_id)
        logger.debug(f"注册待清理资源: {resource_type} = {resource_id}")

    def register_many(self, resource_type: str, resource_ids: list[Any]) -> None:
        """批量注册资源

        Args:
            resource_type: 资源类型
            resource_ids: 资源ID列表

        示例:
            cleaner.register_many("card_nos", ["CARD001", "CARD002", "CARD003"])
        """
        if resource_type not in self.resources:
            self.resources[resource_type] = []
        self.resources[resource_type].extend(resource_ids)
        logger.debug(f"批量注册待清理资源: {resource_type} 数量={len(resource_ids)}")

    def get_resources(self, resource_type: str) -> list[Any]:
        """获取已注册的资源列表

        Args:
            resource_type: 资源类型

        Returns:
            资源ID列表
        """
        return self.resources.get(resource_type, [])

    def clear_resources(self, resource_type: str) -> None:
        """清空指定类型的资源注册

        Args:
            resource_type: 资源类型
        """
        if resource_type in self.resources:
            self.resources[resource_type].clear()
            logger.debug(f"已清空资源注册: {resource_type}")

    @abstractmethod
    def cleanup(self) -> None:
        """清理所有注册的测试数据

        子类必须实现此方法,定义具体的清理逻辑

        示例:
            def cleanup(self):
                # 清理卡片
                if self.resources.get("card_nos"):
                    self.db.execute(
                        "DELETE FROM cards WHERE card_no IN :ids",
                        {"ids": tuple(self.resources["card_nos"])}
                    )

                # 清理订单
                if self.resources.get("order_ids"):
                    self.db.execute(
                        "DELETE FROM orders WHERE id IN :ids",
                        {"ids": tuple(self.resources["order_ids"])}
                    )
        """
        pass


class GenericTestDataCleaner(BaseTestDataCleaner):
    """通用测试数据清理器

    提供基于回调函数的清理机制,无需继承即可使用

    适用场景:
    - 简单的清理逻辑
    - 不想创建子类的情况
    - 临时的清理需求

    示例:
        cleaner = GenericTestDataCleaner(db)

        # 注册清理回调
        cleaner.add_cleanup_callback(
            "cards",
            lambda ids: db.execute(
                "DELETE FROM cards WHERE card_no IN :ids",
                {"ids": tuple(ids)}
            )
        )

        # 注册资源
        cleaner.register("cards", "CARD001")

        # 清理
        cleaner.cleanup()

    v1.2.0 新增 - 通用基础设施
    """

    def __init__(self, db: Database):
        super().__init__(db)
        self.cleanup_callbacks: dict[str, Callable[[list[Any]], None]] = {}

    def add_cleanup_callback(
        self, resource_type: str, callback: Callable[[list[Any]], None]
    ) -> None:
        """添加清理回调函数

        Args:
            resource_type: 资源类型
            callback: 清理回调函数,接收资源ID列表作为参数

        示例:
            def cleanup_cards(card_nos):
                db.execute(
                    "DELETE FROM cards WHERE card_no IN :ids",
                    {"ids": tuple(card_nos)}
                )

            cleaner.add_cleanup_callback("cards", cleanup_cards)
        """
        self.cleanup_callbacks[resource_type] = callback
        logger.debug(f"注册清理回调: {resource_type}")

    def cleanup(self) -> None:
        """执行所有清理回调"""
        logger.info("开始清理测试数据...")

        for resource_type, resource_ids in self.resources.items():
            if not resource_ids:
                continue

            callback = self.cleanup_callbacks.get(resource_type)
            if callback:
                try:
                    callback(resource_ids)
                    logger.info(f"清理完成: {resource_type} 数量={len(resource_ids)}")
                except Exception as e:
                    logger.error(f"清理失败 {resource_type}: {str(e)}")
            else:
                logger.warning(f"未找到清理回调: {resource_type}, 跳过清理")

        logger.info("测试数据清理完成")


# ==================== Pytest Fixtures示例 ====================
#
# 注意: 框架不提供 generic_data_cleaner fixture
# 原因: 它需要db连接,而db连接配置是项目特定的
#
# 在测试项目中,你应该这样创建:
#
# @pytest.fixture(scope="function")
# def data_cleaner(db):  # 使用你项目的db fixture
#     from df_test_framework.fixtures.cleanup import GenericTestDataCleaner
#
#     cleaner = GenericTestDataCleaner(db)
#
#     # 注册清理回调
#     cleaner.add_cleanup_callback(
#         "cards",
#         lambda ids: db.execute(
#             "DELETE FROM cards WHERE card_no IN :ids",
#             {"ids": tuple(ids)}
#         )
#     )
#
#     yield cleaner
#     cleaner.cleanup()
#
# v1.2.0 新增, v1.3.1 移除fixture,改为示例
#
# =============================================================


__all__ = [
    "BaseTestDataCleaner",
    "GenericTestDataCleaner",
]
