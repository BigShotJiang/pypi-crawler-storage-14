"""Allure集成 - 自动记录测试操作到Allure报告

通过 autouse fixture 实现零配置自动记录:
- HTTP请求/响应详情
- 拦截器执行过程
- 数据库查询（可选）
- 错误和异常

特性:
- 零配置: autouse=True，无需在测试代码中手动启用
- 终端静默: 测试通过时无额外输出
- 详细报告: Allure HTML报告包含完整详情
- 拦截器可见: 每个拦截器都是独立的sub-step

生成报告:
    pytest --alluredir=./allure-results
    allure serve ./allure-results

架构设计参考:
    docs/ALLURE_INTEGRATION_DESIGN.md
    docs/V3.5_ALLURE_INTEGRATION_PLAN.md
"""

from collections.abc import Generator

import pytest

from ..observers.allure_observer import (
    ALLURE_AVAILABLE,
    AllureObserver,
    set_current_observer,
)

try:
    import allure
except ImportError:
    allure = None


@pytest.fixture(scope="function", autouse=True)
def _auto_allure_observer(request) -> Generator[AllureObserver | None, None, None]:
    """自动启用Allure观察者（零配置）

    autouse=True: 对所有测试自动生效，无需手动添加到测试参数
    scope=function: 每个测试函数独立的observer实例

    特性:
    - 零配置：无需在测试代码中手动启用
    - 自动记录：HTTP请求、拦截器、数据库查询
    - 静默终端：测试通过时无额外输出
    - 详细报告：Allure HTML报告包含完整详情

    工作原理:
    1. pytest运行每个测试前，自动创建AllureObserver
    2. 通过ContextVar将observer注入到全局上下文
    3. HttpClient/InterceptorChain自动调用observer记录操作
    4. 测试结束后，自动清理observer

    使用场景:
        # 测试代码无需任何修改，自动记录
        def test_create_user(http_client):
            response = http_client.post("/api/users", json={"name": "Alice"})
            assert response.status_code == 201

        # 生成报告: pytest --alluredir=./allure-results
        # 查看报告: allure serve ./allure-results

    Allure报告内容:
        🌐 POST /api/users
          ├─ 📤 Request Details (JSON附件)
          │   {"method": "POST", "url": "/api/users", "json": {"name": "Alice"}}
          ├─ ⚙️ SignatureInterceptor (sub-step)
          │   └─ Changes: {"headers": {"added": {"X-Sign": "md5_..."}}}
          ├─ ⚙️ TokenInterceptor (sub-step)
          │   └─ Changes: {"headers": {"added": {"Authorization": "Bearer ..."}}}
          └─ ✅ Response (201) - 145ms (JSON附件)
              {"status_code": 201, "body": "{\"id\": 1, \"name\": \"Alice\"}"}

    注意:
    - 如果未安装allure-pytest，此fixture自动跳过
    - 不会影响测试执行，只是不生成Allure报告
    """
    # 如果Allure不可用，直接跳过
    if not ALLURE_AVAILABLE or allure is None:
        yield None
        return

    # 创建当前测试的observer
    test_name = request.node.name
    observer = AllureObserver(test_name=test_name)

    # 设置为当前上下文的observer（通过ContextVar，线程安全）
    set_current_observer(observer)

    # yield让测试执行
    # 注意: 不需要用 with allure.step()，因为HTTP请求会创建自己的step
    yield observer

    # 测试结束，清理observer
    set_current_observer(None)


__all__ = ["_auto_allure_observer"]
