"""
df-test-framework fixture entry points.

The primary pytest plugin lives in `df_test_framework.fixtures.core`.
"""

from .allure import _auto_allure_observer  # noqa: F401
from .cleanup import BaseTestDataCleaner, GenericTestDataCleaner  # noqa: F401
from .core import database, http_client, redis_client, runtime  # noqa: F401
from .ui_fixtures import (  # noqa: F401
    browser,
    browser_manager,
    context,
    goto,
    page,
    screenshot,
    ui_manager,
)

__all__ = [
    # API测试fixtures
    "runtime",
    "http_client",
    "database",
    "redis_client",
    # 数据清理
    "BaseTestDataCleaner",
    "GenericTestDataCleaner",
    # UI测试fixtures
    "browser_manager",
    "browser",
    "context",
    "page",
    "ui_manager",
    "goto",
    "screenshot",
]
