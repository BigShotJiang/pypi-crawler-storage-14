"""调试相关的Fixtures

提供HTTP和数据库调试工具的fixtures。
"""

import pytest

from ..debug import (
    DBDebugger,
    HTTPDebugger,
    enable_db_debug,
    enable_http_debug,
)


@pytest.fixture(scope="function")
def http_debugger():
    """HTTP调试器fixture

    在测试中使用HTTP调试器记录请求和响应。

    Example:
        def test_api(http_client, http_debugger):
            http_debugger.start()
            response = http_client.get("/users")
            http_debugger.print_summary()
    """
    debugger = HTTPDebugger()
    debugger.start()
    yield debugger
    debugger.stop()


@pytest.fixture(scope="function")
def db_debugger():
    """数据库调试器fixture

    在测试中使用数据库调试器记录查询。

    Example:
        def test_query(database, db_debugger):
            db_debugger.start()
            results = database.execute_query("SELECT * FROM users")
            db_debugger.print_summary()
    """
    debugger = DBDebugger()
    debugger.start()
    yield debugger
    debugger.stop()


@pytest.fixture(scope="session")
def global_http_debugger():
    """全局HTTP调试器fixture（session级别）

    整个测试会话共享的HTTP调试器。

    Example:
        def test_api(http_client, global_http_debugger):
            # 所有测试的HTTP请求都会被记录
            response = http_client.get("/users")
    """
    debugger = enable_http_debug()
    yield debugger
    debugger.print_summary()


@pytest.fixture(scope="session")
def global_db_debugger():
    """全局数据库调试器fixture（session级别）

    整个测试会话共享的数据库调试器。

    Example:
        def test_query(database, global_db_debugger):
            # 所有测试的数据库查询都会被记录
            results = database.execute_query("SELECT * FROM users")
    """
    debugger = enable_db_debug()
    yield debugger
    debugger.print_summary()


@pytest.fixture(scope="function", autouse=False)
def auto_debug_on_failure(request, http_debugger, db_debugger):
    """测试失败时自动打印调试信息

    在测试失败时自动打印HTTP和数据库调试摘要。

    Usage:
        在conftest.py中启用：
        pytest_plugins = ["df_test_framework.testing.fixtures.debug"]

        或在测试中使用：
        def test_example(auto_debug_on_failure):
            # 测试代码
            pass
    """
    yield

    # 检查测试是否失败
    if request.node.rep_call.failed if hasattr(request.node, "rep_call") else False:
        print("\n" + "=" * 80)
        print("🐛 测试失败，自动打印调试信息")
        print("=" * 80)

        # 打印HTTP调试信息
        if http_debugger.get_requests():
            http_debugger.print_summary()

        # 打印数据库调试信息
        if db_debugger.get_queries():
            db_debugger.print_summary()


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """记录测试结果供auto_debug_on_failure使用"""
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f"rep_{rep.when}", rep)


__all__ = [
    "http_debugger",
    "db_debugger",
    "global_http_debugger",
    "global_db_debugger",
    "auto_debug_on_failure",
]
