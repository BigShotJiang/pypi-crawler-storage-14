"""Pytest插件模块"""

from .allure import (
    AllureHelper,
    attach_json,
    attach_log,
    attach_screenshot,
    step,
)
from .markers import (
    EnvironmentMarker,
    dev_only,
    get_env,
    is_env,
    prod_only,
    skip_if_dev,
    skip_if_prod,
)

__all__ = [
    # Allure辅助工具
    "AllureHelper",
    "attach_log",
    "attach_json",
    "attach_screenshot",
    "step",
    # 环境标记
    "EnvironmentMarker",
    "get_env",
    "is_env",
    "skip_if_prod",
    "skip_if_dev",
    "dev_only",
    "prod_only",
]
