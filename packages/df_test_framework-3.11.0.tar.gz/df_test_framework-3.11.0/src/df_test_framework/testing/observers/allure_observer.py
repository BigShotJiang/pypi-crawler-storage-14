"""Allure测试观察者

零配置自动记录HTTP请求、拦截器、数据库查询等操作到Allure报告

设计原则:
- 零配置: 通过pytest autouse fixture自动注入
- 零侵入: 测试代码无需修改
- 可视化: 生成Allure HTML报告而非终端日志
- 行业标准: 使用Allure Report（与Playwright/Selenium对齐）

架构:
- AllureObserver: 核心观察者类，记录测试操作到Allure
- ContextVar: 线程安全的全局observer访问
- pytest fixture: 自动注入到每个测试
"""

import json
import time
from contextvars import ContextVar
from typing import TYPE_CHECKING, Any, Optional

try:
    import allure

    ALLURE_AVAILABLE = True
except ImportError:
    ALLURE_AVAILABLE = False
    allure = None

if TYPE_CHECKING:
    from df_test_framework.clients.http.core import Request, Response


# 线程安全的当前Observer
_current_observer: ContextVar[Optional["AllureObserver"]] = ContextVar(
    "allure_observer", default=None
)


def is_allure_enabled() -> bool:
    """检查Allure集成是否启用

    优先级:
    1. Allure库是否可用 (ALLURE_AVAILABLE)
    2. FrameworkSettings.enable_allure配置
    3. 默认值: True (如果Allure可用)

    Returns:
        是否启用

    Example:
        >>> is_allure_enabled()  # 检查当前状态
        True
    """
    # 1. 检查Allure库是否可用
    if not ALLURE_AVAILABLE or allure is None:
        return False

    # 2. 检查FrameworkSettings配置
    try:
        from ...infrastructure.config import get_settings

        settings = get_settings()
        return settings.enable_allure
    except Exception:
        # 如果获取settings失败（如未配置），使用默认值
        pass

    # 3. 默认启用（如果Allure可用）
    return True


class AllureObserver:
    """Allure测试观察者

    自动记录测试操作到Allure报告:
    - HTTP请求/响应详情
    - 拦截器执行过程
    - 数据库查询 (可选)
    - 错误和异常

    特性:
    - 零配置: 通过autouse fixture自动启用
    - 终端静默: 测试通过时无额外输出
    - 详细报告: Allure HTML报告包含完整详情
    - 拦截器可见: 每个拦截器都是独立的sub-step

    使用方式:
        # 完全自动，通过 autouse fixture 注入
        def test_api(http_client):
            response = http_client.post("/api/users", json={"name": "Alice"})
            assert response.status_code == 201

        # Allure报告自动包含:
        # - 🌐 POST /api/users (主step)
        #   ├─ 📤 Request Details (附件)
        #   ├─ ⚙️ SignatureInterceptor (sub-step)
        #   ├─ ⚙️ TokenInterceptor (sub-step)
        #   └─ ✅ Response (201) - 145ms (附件)

    生成报告:
        pytest --alluredir=./allure-results
        allure serve ./allure-results
    """

    def __init__(self, test_name: str):
        """初始化Observer

        Args:
            test_name: 当前测试名称
        """
        self.test_name = test_name
        self.request_counter = 0
        self._current_step_context = None
        self._current_request_id = None
        self._request_start_time = None

        # v3.5: Database & Redis 观察
        self._current_query_context = None  # 当前数据库查询step
        self._current_query_id = None
        self._query_start_time = None

    def on_http_request_start(self, request: "Request") -> str:
        """HTTP请求开始

        创建Allure step并附加请求详情

        Args:
            request: Request对象

        Returns:
            request_id - 用于关联后续事件（如拦截器、响应）

        Example:
            >>> observer = AllureObserver("test_create_user")
            >>> request = Request(method="POST", url="/api/users", json={"name": "Alice"})
            >>> request_id = observer.on_http_request_start(request)
            >>> print(request_id)  # "req-001"

            # Allure报告中创建:
            # 🌐 POST /api/users
            #   └─ 📤 Request Details (JSON附件)
        """
        if not is_allure_enabled():
            return None

        self.request_counter += 1
        request_id = f"req-{self.request_counter:03d}"
        self._request_start_time = time.time()

        # 创建Allure step (带emoji图标)
        step_title = f"🌐 {request.method} {request.url}"
        self._current_step_context = allure.step(step_title)
        self._current_step_context.__enter__()
        self._current_request_id = request_id

        # 附加请求详情
        request_details = {
            "request_id": request_id,
            "method": request.method,
            "url": request.url,
            "headers": dict(request.headers) if request.headers else {},
            "params": request.params,
            "json": request.json,
            "data": request.data,
        }

        allure.attach(
            json.dumps(request_details, indent=2, ensure_ascii=False),
            name="📤 Request Details",
            attachment_type=allure.attachment_type.JSON,
        )

        return request_id

    def on_interceptor_execute(
        self, request_id: str, interceptor_name: str, changes: dict[str, Any]
    ) -> None:
        """拦截器执行记录

        在当前HTTP请求step下创建子step，展示拦截器做了什么修改

        Args:
            request_id: 请求ID（用于关联）
            interceptor_name: 拦截器名称
            changes: 拦截器做的修改（如添加的headers）

        Example:
            >>> observer.on_interceptor_execute(
            ...     "req-001",
            ...     "SignatureInterceptor",
            ...     {"headers": {"added": {"X-Sign": "md5_abc123..."}}}
            ... )

            # Allure报告中创建sub-step:
            #   ⚙️ SignatureInterceptor
            #     └─ Changes (JSON附件)
            #         {"headers": {"added": {"X-Sign": "md5_abc123..."}}}
        """
        if not is_allure_enabled():
            return

        # 跳过空变化
        if not changes:
            return

        # 在当前HTTP请求step下创建sub-step
        with allure.step(f"  ⚙️ {interceptor_name}"):
            allure.attach(
                json.dumps(changes, indent=2, ensure_ascii=False),
                name="Changes",
                attachment_type=allure.attachment_type.JSON,
            )

    def on_http_request_end(
        self, request_id: str, response: "Response", duration_ms: float | None = None
    ) -> None:
        """HTTP请求结束

        附加响应详情并关闭当前step

        Args:
            request_id: 请求ID
            response: Response对象
            duration_ms: 请求耗时（毫秒），如果未提供则自动计算

        Example:
            >>> response = Response(status_code=201, body='{"id": 1}', ...)
            >>> observer.on_http_request_end("req-001", response, 145.23)

            # Allure报告中附加:
            # ✅ Response (201) - 145.23ms (JSON附件)
            #   {
            #     "status_code": 201,
            #     "body": "{\"id\": 1}",
            #     "duration_ms": 145.23
            #   }
        """
        if not is_allure_enabled():
            return

        # 计算耗时
        if duration_ms is None and self._request_start_time:
            duration_ms = (time.time() - self._request_start_time) * 1000

        # 响应详情
        response_details = {
            "request_id": request_id,
            "status_code": response.status_code,
            "headers": dict(response.headers) if response.headers else {},
            "body": response.body[:1000] if response.body else None,  # 截断防止过长
            "duration_ms": round(duration_ms, 2) if duration_ms else None,
        }

        # 根据状态码选择emoji
        status_emoji = "✅" if 200 <= response.status_code < 300 else "❌"
        attachment_name = f"{status_emoji} Response ({response.status_code})"
        if duration_ms:
            attachment_name += f" - {round(duration_ms, 2)}ms"

        allure.attach(
            json.dumps(response_details, indent=2, ensure_ascii=False),
            name=attachment_name,
            attachment_type=allure.attachment_type.JSON,
        )

        # 关闭当前step
        if self._current_step_context:
            self._current_step_context.__exit__(None, None, None)
            self._current_step_context = None
            self._current_request_id = None
            self._request_start_time = None

    def on_error(self, error: Exception, context: dict[str, Any]) -> None:
        """错误记录

        记录错误信息到Allure报告

        Args:
            error: 异常对象
            context: 错误上下文信息（如stage, request_id等）

        Example:
            >>> try:
            ...     raise ValueError("Invalid input")
            ... except Exception as e:
            ...     observer.on_error(e, {"stage": "before_request", "request_id": "req-001"})

            # Allure报告中附加:
            # ❌ Error (JSON附件)
            #   {
            #     "error_type": "ValueError",
            #     "error_message": "Invalid input",
            #     "context": {"stage": "before_request", "request_id": "req-001"}
            #   }
        """
        if not is_allure_enabled():
            return

        error_details = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "context": context,
        }

        allure.attach(
            json.dumps(error_details, indent=2, ensure_ascii=False),
            name="❌ Error",
            attachment_type=allure.attachment_type.JSON,
        )

    # ========== v3.5: Database 观察方法 ==========

    def on_query_start(
        self,
        query_id: str,
        operation: str,
        table: str,
        sql: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> None:
        """数据库查询开始

        创建Allure step并附加查询详情

        Args:
            query_id: 查询ID（如 "query-001"）
            operation: 操作类型（SELECT/INSERT/UPDATE/DELETE）
            table: 表名
            sql: SQL语句（可选）
            params: SQL参数（可选）

        Example:
            >>> observer.on_query_start(
            ...     "query-001",
            ...     "SELECT",
            ...     "users",
            ...     "SELECT * FROM users WHERE id = :id",
            ...     {"id": 123}
            ... )

            # Allure报告中创建:
            # 🗄️ SELECT users (query-001)
            #   └─ 📜 Query Details (JSON附件)
        """
        if not is_allure_enabled():
            return

        self._query_start_time = time.time()
        self._current_query_id = query_id

        # 创建Allure step (带emoji图标)
        step_title = f"🗄️ {operation} {table}"
        self._current_query_context = allure.step(step_title)
        self._current_query_context.__enter__()

        # 附加查询详情
        query_details = {
            "query_id": query_id,
            "operation": operation,
            "table": table,
        }
        if sql:
            query_details["sql"] = sql
        if params:
            query_details["params"] = params

        allure.attach(
            json.dumps(query_details, indent=2, ensure_ascii=False),
            name="📜 Query Details",
            attachment_type=allure.attachment_type.JSON,
        )

    def on_query_end(self, query_id: str, row_count: int, duration_ms: float | None = None) -> None:
        """数据库查询结束

        附加查询结果并关闭当前step

        Args:
            query_id: 查询ID
            row_count: 影响/返回的行数
            duration_ms: 查询耗时（毫秒），如果未提供则自动计算

        Example:
            >>> observer.on_query_end("query-001", row_count=1, duration_ms=2.3)

            # Allure报告中附加:
            # ✅ Result: 1 rows (2.3ms) (JSON附件)
        """
        if not is_allure_enabled():
            return

        # 计算耗时
        if duration_ms is None and self._query_start_time:
            duration_ms = (time.time() - self._query_start_time) * 1000

        # 查询结果
        result_details = {
            "query_id": query_id,
            "row_count": row_count,
            "duration_ms": round(duration_ms, 2) if duration_ms else None,
        }

        attachment_name = f"✅ Result: {row_count} rows"
        if duration_ms:
            attachment_name += f" ({round(duration_ms, 2)}ms)"

        allure.attach(
            json.dumps(result_details, indent=2, ensure_ascii=False),
            name=attachment_name,
            attachment_type=allure.attachment_type.JSON,
        )

        # 关闭当前step
        if self._current_query_context:
            self._current_query_context.__exit__(None, None, None)
            self._current_query_context = None
            self._current_query_id = None
            self._query_start_time = None

    def on_query_error(self, query_id: str, error: Exception) -> None:
        """数据库查询错误

        Args:
            query_id: 查询ID
            error: 异常对象

        Example:
            >>> observer.on_query_error("query-001", IntegrityError("Duplicate key"))

            # Allure报告中附加:
            # ❌ Query Error (JSON附件)
        """
        if not is_allure_enabled():
            return

        error_details = {
            "query_id": query_id,
            "error_type": type(error).__name__,
            "error_message": str(error),
        }

        allure.attach(
            json.dumps(error_details, indent=2, ensure_ascii=False),
            name="❌ Query Error",
            attachment_type=allure.attachment_type.JSON,
        )

        # 关闭当前step（即使出错也要关闭）
        if self._current_query_context:
            self._current_query_context.__exit__(None, None, None)
            self._current_query_context = None
            self._current_query_id = None
            self._query_start_time = None

    # ========== v3.5: Redis 观察方法 ==========

    def on_cache_operation(
        self, operation: str, key: str, hit: bool | None = None, value: Any | None = None
    ) -> None:
        """Redis缓存操作

        创建Allure step记录缓存操作

        Args:
            operation: 操作类型（GET/SET/DELETE等）
            key: 缓存键
            hit: 是否命中（仅GET操作）
            value: 缓存值（仅SET操作，可选）

        Example:
            >>> observer.on_cache_operation("GET", "user:cache:1", hit=True)

            # Allure报告中创建:
            # 💾 Redis: GET user:cache:1 → HIT ✓

            >>> observer.on_cache_operation("SET", "user:cache:1", value="Alice")

            # Allure报告中创建:
            # 💾 Redis: SET user:cache:1
        """
        if not is_allure_enabled():
            return

        # 构建step标题
        step_title = f"💾 Redis: {operation} {key}"
        if operation == "GET" and hit is not None:
            result_text = "HIT ✓" if hit else "MISS ✗"
            step_title += f" → {result_text}"

        # 创建step (快速操作，不保留context)
        with allure.step(step_title):
            # 附加缓存操作详情
            cache_details = {
                "operation": operation,
                "key": key,
            }
            if hit is not None:
                cache_details["hit"] = hit
            if value is not None:
                # 截断防止过长
                value_str = str(value)
                cache_details["value"] = value_str[:500] if len(value_str) > 500 else value_str

            allure.attach(
                json.dumps(cache_details, indent=2, ensure_ascii=False),
                name="Cache Details",
                attachment_type=allure.attachment_type.JSON,
            )


def get_current_observer() -> AllureObserver | None:
    """获取当前测试的Observer

    通过ContextVar获取，线程安全

    Returns:
        当前测试的AllureObserver实例，如果没有则返回None

    Example:
        >>> # 在HttpClient中
        >>> observer = get_current_observer()
        >>> if observer:
        ...     request_id = observer.on_http_request_start(request)
    """
    return _current_observer.get()


def set_current_observer(observer: AllureObserver | None) -> None:
    """设置当前测试的Observer

    通过ContextVar设置，线程安全

    Args:
        observer: AllureObserver实例或None

    Example:
        >>> # 在pytest fixture中
        >>> observer = AllureObserver(test_name="test_create_user")
        >>> set_current_observer(observer)
        >>> yield observer
        >>> set_current_observer(None)  # 清理
    """
    _current_observer.set(observer)


__all__ = [
    "AllureObserver",
    "get_current_observer",
    "set_current_observer",
    "ALLURE_AVAILABLE",
]
