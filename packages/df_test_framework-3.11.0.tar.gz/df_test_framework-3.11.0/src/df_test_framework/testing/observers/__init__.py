"""测试观察者模块

提供自动化测试过程中的可观测性支持:
- AllureObserver: 自动记录测试操作到Allure报告
"""

from .allure_observer import (
    ALLURE_AVAILABLE,
    AllureObserver,
    get_current_observer,
    set_current_observer,
)

__all__ = [
    "AllureObserver",
    "get_current_observer",
    "set_current_observer",
    "ALLURE_AVAILABLE",
]
