"""扩展系统 - 插件机制和内置扩展"""

from .core import ExtensionManager, create_extension_manager, hookimpl

__all__ = [
    "create_extension_manager",
    "ExtensionManager",
    "hookimpl",
]
