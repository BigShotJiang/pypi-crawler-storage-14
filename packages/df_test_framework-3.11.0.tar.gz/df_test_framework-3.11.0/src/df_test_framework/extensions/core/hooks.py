"""
Hook specifications for df-test-framework plugin system.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...infrastructure.runtime import RuntimeContext

import pluggy

from ...infrastructure.config.schema import FrameworkSettings
from ...infrastructure.config.sources import ConfigSource
from ...infrastructure.providers import Provider

hookspec = pluggy.HookspecMarker("df_test_framework")
hookimpl = pluggy.HookimplMarker("df_test_framework")


class HookSpecs:
    @hookspec
    def df_config_sources(self, settings_cls: type[FrameworkSettings]) -> Iterable[ConfigSource]:
        """
        Return additional ConfigSource objects to be appended to the pipeline.
        """

    @hookspec
    def df_providers(self, settings: FrameworkSettings, logger) -> dict[str, Provider]:
        """
        Return a mapping of provider name -> Provider to be merged into the registry.
        """

    @hookspec
    def df_post_bootstrap(self, runtime: RuntimeContext) -> None:
        """
        Execute arbitrary logic after RuntimeContext is created.
        """
