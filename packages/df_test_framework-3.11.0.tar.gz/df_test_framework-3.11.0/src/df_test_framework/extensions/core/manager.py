"""Plugin manager utilities for df-test-framework."""

from __future__ import annotations

import importlib
from collections.abc import Iterable

import pluggy

from .hooks import HookSpecs


class ExtensionManager:
    def __init__(self):
        self._pm = pluggy.PluginManager("df_test_framework")
        self._pm.add_hookspecs(HookSpecs)

    @property
    def manager(self) -> pluggy.PluginManager:
        return self._pm

    def register(self, plugin: str | object) -> None:
        if isinstance(plugin, str):
            module = importlib.import_module(plugin)
            try:
                self._pm.register(module, name=plugin)
            except ValueError:
                pass
        else:
            try:
                self._pm.register(plugin)
            except ValueError:
                pass

    def register_many(self, plugins: Iterable[str | object]) -> None:
        for plugin in plugins:
            self.register(plugin)


def create_extension_manager() -> ExtensionManager:
    return ExtensionManager()
