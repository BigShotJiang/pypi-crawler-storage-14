"""数据库慢查询监控

v1.3.0 新增
监控数据库慢查询,记录查询耗时超过阈值的SQL
"""

import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from loguru import logger
from sqlalchemy import event
from sqlalchemy.engine import Engine


@dataclass
class SlowQuery:
    """慢查询记录"""

    sql: str  # SQL语句
    params: Any  # 参数
    duration_ms: float  # 耗时(毫秒)
    timestamp: datetime  # 时间戳


class SlowQueryMonitor:
    """慢查询监控器

    记录和统计数据库慢查询

    示例:
        monitor = SlowQueryMonitor(threshold_ms=100)

        # 在SQLAlchemy中启用
        setup_slow_query_logging(db.engine, monitor=monitor)

        # 获取慢查询记录
        slow_queries = monitor.get_slow_queries()
        print(f"总慢查询数: {monitor.total_slow_queries}")

    v1.3.0 新增
    """

    def __init__(self, threshold_ms: float = 100.0, max_records: int = 1000, keep_sql: bool = True):
        """初始化慢查询监控器

        Args:
            threshold_ms: 慢查询阈值(毫秒),默认100ms
            max_records: 最多保留多少条慢查询记录,默认1000
            keep_sql: 是否保留完整SQL,False则只统计数量,默认True
        """
        self.threshold_ms = threshold_ms
        self.max_records = max_records
        self.keep_sql = keep_sql
        self.slow_queries: list[SlowQuery] = []
        self.total_slow_queries = 0
        self.total_queries = 0

    def record(self, sql: str, params: Any, duration_ms: float) -> None:
        """记录查询

        Args:
            sql: SQL语句
            params: 参数
            duration_ms: 耗时(毫秒)
        """
        self.total_queries += 1

        if duration_ms >= self.threshold_ms:
            self.total_slow_queries += 1

            # 记录慢查询
            if self.keep_sql and len(self.slow_queries) < self.max_records:
                self.slow_queries.append(
                    SlowQuery(
                        sql=sql[:500],  # 截断过长SQL
                        params=params,
                        duration_ms=duration_ms,
                        timestamp=datetime.now(),
                    )
                )

            # 日志输出
            logger.warning(f"慢查询 ({duration_ms:.2f}ms): {sql[:200]}... | 参数: {params}")

    def get_slow_queries(
        self, limit: int | None = None, sort_by_duration: bool = True
    ) -> list[dict[str, Any]]:
        """获取慢查询列表

        Args:
            limit: 限制返回数量,None表示返回所有
            sort_by_duration: 是否按耗时排序,默认True

        Returns:
            慢查询列表

        示例:
            # 获取耗时最长的10条慢查询
            top10 = monitor.get_slow_queries(limit=10)
        """
        queries = self.slow_queries.copy()

        if sort_by_duration:
            queries.sort(key=lambda x: x.duration_ms, reverse=True)

        if limit:
            queries = queries[:limit]

        return [
            {
                "SQL": q.sql,
                "参数": str(q.params),
                "耗时(ms)": round(q.duration_ms, 2),
                "时间": q.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for q in queries
        ]

    def get_statistics(self) -> dict[str, Any]:
        """获取统计信息

        Returns:
            统计信息字典

        示例:
            stats = monitor.get_statistics()
        """
        return {
            "总查询次数": self.total_queries,
            "慢查询次数": self.total_slow_queries,
            "慢查询比例(%)": (
                round((self.total_slow_queries / self.total_queries) * 100, 2)
                if self.total_queries > 0
                else 0
            ),
            "慢查询阈值(ms)": self.threshold_ms,
            "记录的慢查询数": len(self.slow_queries),
        }

    def reset(self) -> None:
        """重置监控数据"""
        self.slow_queries.clear()
        self.total_slow_queries = 0
        self.total_queries = 0
        logger.info("慢查询监控已重置")


def setup_slow_query_logging(
    engine: Engine,
    threshold_ms: float = 100.0,
    monitor: SlowQueryMonitor | None = None,
) -> SlowQueryMonitor:
    """为SQLAlchemy Engine设置慢查询监控

    使用SQLAlchemy的事件系统监听查询执行,记录慢查询

    Args:
        engine: SQLAlchemy Engine实例
        threshold_ms: 慢查询阈值(毫秒),默认100ms
        monitor: 可选的SlowQueryMonitor实例,如果不提供则创建新的

    Returns:
        SlowQueryMonitor实例

    示例:
        # 方式1: 自动创建monitor
        from df_test_framework.monitoring import setup_slow_query_logging

        db = Database(connection_string)
        monitor = setup_slow_query_logging(db.engine, threshold_ms=100)

        # ... 执行测试 ...

        # 获取慢查询统计
        stats = monitor.get_statistics()
        slow_queries = monitor.get_slow_queries(limit=10)

        # 方式2: 使用自定义monitor
        monitor = SlowQueryMonitor(threshold_ms=50, max_records=500)
        setup_slow_query_logging(db.engine, monitor=monitor)

    注意:
        - 监控会在整个engine生命周期内有效
        - 会增加一定的性能开销(通常<1%)
        - 建议在测试环境使用,生产环境谨慎开启

    v1.3.0 新增
    """
    if monitor is None:
        monitor = SlowQueryMonitor(threshold_ms=threshold_ms)

    @event.listens_for(engine, "before_cursor_execute")
    def receive_before_cursor_execute(conn, cursor, statement, params, context, executemany):
        """查询执行前记录开始时间"""
        context._query_start_time = time.time()

    @event.listens_for(engine, "after_cursor_execute")
    def receive_after_cursor_execute(conn, cursor, statement, params, context, executemany):
        """查询执行后计算耗时并记录"""
        duration_ms = (time.time() - context._query_start_time) * 1000
        monitor.record(statement, params, duration_ms)

    logger.info(
        f"慢查询监控已启用 - 阈值: {monitor.threshold_ms}ms, 最大记录数: {monitor.max_records}"
    )

    return monitor


# ==================== Pytest Fixture 示例 ====================

"""
在测试项目中使用慢查询监控的示例:

# conftest.py

import pytest
from df_test_framework.monitoring import SlowQueryMonitor, setup_slow_query_logging
from df_test_framework.core.database import Database

@pytest.fixture(scope="session")
def db_with_monitoring() -> Database:
    '''创建带慢查询监控的数据库实例'''
    db = Database(settings.db_connection_string)

    # 启用慢查询监控
    monitor = setup_slow_query_logging(
        db.engine,
        threshold_ms=100,  # 100ms阈值
    )

    yield db

    # 测试结束后输出慢查询统计
    stats = monitor.get_statistics()
    print(f"\\n慢查询统计: {stats}")

    slow_queries = monitor.get_slow_queries(limit=10)
    if slow_queries:
        print("\\n慢查询Top 10:")
        import json
        print(json.dumps(slow_queries, indent=2, ensure_ascii=False))

    db.close()


@pytest.fixture(scope="session")
def slow_query_monitor() -> SlowQueryMonitor:
    '''获取慢查询监控器'''
    return SlowQueryMonitor(threshold_ms=100)


# test_performance.py

def test_query_performance(db_with_monitoring, slow_query_monitor):
    '''测试查询性能'''
    # 执行查询
    result = db_with_monitoring.query_all("SELECT * FROM large_table")

    # 检查慢查询
    stats = slow_query_monitor.get_statistics()
    assert stats["慢查询比例(%)"] < 10, "慢查询比例过高"


# 在Allure报告中附加慢查询信息

import allure

@pytest.fixture(scope="function", autouse=True)
def attach_slow_queries(request, slow_query_monitor):
    '''自动附加慢查询到Allure报告'''
    yield

    # 测试结束后
    slow_queries = slow_query_monitor.get_slow_queries(limit=5)
    if slow_queries:
        allure.attach(
            json.dumps(slow_queries, indent=2, ensure_ascii=False),
            name="慢查询记录",
            attachment_type=allure.attachment_type.JSON
        )
"""
