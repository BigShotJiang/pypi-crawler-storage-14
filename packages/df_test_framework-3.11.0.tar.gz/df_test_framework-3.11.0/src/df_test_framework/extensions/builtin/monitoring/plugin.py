"""Optional monitoring extension registering performance tracker providers."""

from __future__ import annotations

from ....extensions.core.hooks import hookimpl
from ....infrastructure.providers import Provider, SingletonProvider
from .api_tracker import APIPerformanceTracker


@hookimpl
def df_providers(settings, logger) -> dict[str, Provider]:
    extras = getattr(settings, "extras", {}) or {}
    slow_threshold = extras.get("performance_slow_threshold", 200)

    return {
        "api_performance_tracker": SingletonProvider(
            lambda ctx: APIPerformanceTracker(slow_threshold_ms=slow_threshold)
        ),
    }
