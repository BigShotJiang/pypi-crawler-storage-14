"""API性能追踪器

v1.3.0 新增
追踪API调用的响应时间、成功率等性能指标
"""

import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from loguru import logger


@dataclass
class APIStats:
    """API统计数据"""

    count: int = 0  # 调用次数
    total_time: float = 0.0  # 总耗时(毫秒)
    min_time: float = float("inf")  # 最小耗时
    max_time: float = 0.0  # 最大耗时
    errors: int = 0  # 错误次数
    slow_calls: int = 0  # 慢调用次数
    durations: list[float] = field(default_factory=list)  # 所有耗时记录

    @property
    def avg_time(self) -> float:
        """平均响应时间"""
        return self.total_time / self.count if self.count > 0 else 0.0

    @property
    def success_rate(self) -> float:
        """成功率"""
        if self.count == 0:
            return 100.0
        return ((self.count - self.errors) / self.count) * 100

    @property
    def error_rate(self) -> float:
        """错误率"""
        return 100.0 - self.success_rate

    @property
    def p50(self) -> float:
        """P50分位数"""
        return self._percentile(50)

    @property
    def p90(self) -> float:
        """P90分位数"""
        return self._percentile(90)

    @property
    def p95(self) -> float:
        """P95分位数"""
        return self._percentile(95)

    @property
    def p99(self) -> float:
        """P99分位数"""
        return self._percentile(99)

    def _percentile(self, p: int) -> float:
        """计算分位数"""
        if not self.durations:
            return 0.0
        sorted_durations = sorted(self.durations)
        index = int(len(sorted_durations) * p / 100)
        return sorted_durations[min(index, len(sorted_durations) - 1)]


class APIPerformanceTracker:
    """API性能追踪器

    用于追踪和统计API调用的性能指标

    示例:
        # 创建追踪器
        tracker = APIPerformanceTracker(slow_threshold_ms=200)

        # 记录API调用
        tracker.record("create_card", duration_ms=125.5, success=True)
        tracker.record("query_card", duration_ms=50.2, success=True)
        tracker.record("create_card", duration_ms=350.0, success=False)

        # 获取统计摘要
        summary = tracker.get_summary()
        print(json.dumps(summary, indent=2, ensure_ascii=False))

        # 获取慢调用列表
        slow_calls = tracker.get_slow_calls()

        # 重置统计
        tracker.reset()

    v1.3.0 新增
    """

    def __init__(
        self,
        slow_threshold_ms: float = 200.0,
        keep_durations: bool = True,
        max_durations: int = 10000,
    ):
        """初始化性能追踪器

        Args:
            slow_threshold_ms: 慢调用阈值(毫秒),默认200ms
            keep_durations: 是否保留所有耗时记录用于计算分位数,默认True
            max_durations: 最多保留多少条耗时记录,防止内存溢出,默认10000
        """
        self.slow_threshold_ms = slow_threshold_ms
        self.keep_durations = keep_durations
        self.max_durations = max_durations
        self.stats: dict[str, APIStats] = defaultdict(APIStats)
        self.start_time = datetime.now()

    def record(self, api_name: str, duration_ms: float, success: bool = True) -> None:
        """记录API调用

        Args:
            api_name: API名称
            duration_ms: 耗时(毫秒)
            success: 是否成功

        示例:
            tracker.record("create_card", duration_ms=125.5, success=True)
        """
        stat = self.stats[api_name]

        # 更新基础统计
        stat.count += 1
        stat.total_time += duration_ms
        stat.min_time = min(stat.min_time, duration_ms)
        stat.max_time = max(stat.max_time, duration_ms)

        # 记录错误
        if not success:
            stat.errors += 1

        # 记录慢调用
        if duration_ms > self.slow_threshold_ms:
            stat.slow_calls += 1
            logger.warning(
                f"慢API调用: {api_name} 耗时 {duration_ms:.2f}ms (阈值: {self.slow_threshold_ms}ms)"
            )

        # 保留耗时记录用于分位数计算
        if self.keep_durations:
            if len(stat.durations) < self.max_durations:
                stat.durations.append(duration_ms)
            else:
                # 达到上限后,随机替换(简单的采样策略)
                import random

                if random.random() < 0.1:  # 10%概率替换
                    stat.durations[random.randint(0, self.max_durations - 1)] = duration_ms

    def get_summary(self, sort_by: str = "count") -> dict[str, Any]:
        """获取统计摘要

        Args:
            sort_by: 排序字段,可选: count, avg_time, max_time, errors

        Returns:
            统计摘要字典

        示例:
            summary = tracker.get_summary(sort_by="avg_time")
        """
        summary = {}

        for api_name, stat in self.stats.items():
            api_summary = {
                "调用次数": stat.count,
                "平均响应时间(ms)": round(stat.avg_time, 2),
                "最小响应时间(ms)": round(stat.min_time, 2),
                "最大响应时间(ms)": round(stat.max_time, 2),
                "总耗时(ms)": round(stat.total_time, 2),
                "成功率(%)": round(stat.success_rate, 2),
                "错误次数": stat.errors,
                "慢调用次数": stat.slow_calls,
                "慢调用比例(%)": (
                    round((stat.slow_calls / stat.count) * 100, 2) if stat.count > 0 else 0
                ),
            }

            # 添加分位数(如果有耗时记录)
            if self.keep_durations and stat.durations:
                api_summary.update(
                    {
                        "P50(ms)": round(stat.p50, 2),
                        "P90(ms)": round(stat.p90, 2),
                        "P95(ms)": round(stat.p95, 2),
                        "P99(ms)": round(stat.p99, 2),
                    }
                )

            summary[api_name] = api_summary

        # 排序
        if sort_by == "count":
            summary = dict(sorted(summary.items(), key=lambda x: x[1]["调用次数"], reverse=True))
        elif sort_by == "avg_time":
            summary = dict(
                sorted(summary.items(), key=lambda x: x[1]["平均响应时间(ms)"], reverse=True)
            )
        elif sort_by == "max_time":
            summary = dict(
                sorted(summary.items(), key=lambda x: x[1]["最大响应时间(ms)"], reverse=True)
            )
        elif sort_by == "errors":
            summary = dict(sorted(summary.items(), key=lambda x: x[1]["错误次数"], reverse=True))

        return summary

    def get_slow_calls(self) -> list[dict[str, Any]]:
        """获取慢调用列表

        Returns:
            慢调用列表

        示例:
            slow_calls = tracker.get_slow_calls()
        """
        slow_calls = []

        for api_name, stat in self.stats.items():
            if stat.slow_calls > 0:
                slow_calls.append(
                    {
                        "API名称": api_name,
                        "慢调用次数": stat.slow_calls,
                        "慢调用比例(%)": round((stat.slow_calls / stat.count) * 100, 2),
                        "最大响应时间(ms)": round(stat.max_time, 2),
                    }
                )

        # 按慢调用次数排序
        slow_calls.sort(key=lambda x: x["慢调用次数"], reverse=True)
        return slow_calls

    def get_failed_apis(self) -> list[dict[str, Any]]:
        """获取失败的API列表

        Returns:
            失败的API列表

        示例:
            failed = tracker.get_failed_apis()
        """
        failed_apis = []

        for api_name, stat in self.stats.items():
            if stat.errors > 0:
                failed_apis.append(
                    {
                        "API名称": api_name,
                        "错误次数": stat.errors,
                        "错误率(%)": round(stat.error_rate, 2),
                        "总调用次数": stat.count,
                    }
                )

        # 按错误次数排序
        failed_apis.sort(key=lambda x: x["错误次数"], reverse=True)
        return failed_apis

    def get_report(self) -> str:
        """生成性能报告

        Returns:
            格式化的性能报告字符串

        示例:
            print(tracker.get_report())
        """
        elapsed_time = (datetime.now() - self.start_time).total_seconds()

        report = [
            "=" * 80,
            "API性能统计报告",
            "=" * 80,
            f"统计时间: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"运行时长: {elapsed_time:.2f}秒",
            f"慢调用阈值: {self.slow_threshold_ms}ms",
            "",
            "整体统计:",
            "-" * 80,
        ]

        # 整体统计
        total_calls = sum(stat.count for stat in self.stats.values())
        total_errors = sum(stat.errors for stat in self.stats.values())
        total_slow = sum(stat.slow_calls for stat in self.stats.values())

        report.extend(
            [
                f"总调用次数: {total_calls}",
                f"总错误次数: {total_errors}",
                f"总慢调用次数: {total_slow}",
                f"整体成功率: {((total_calls - total_errors) / total_calls * 100) if total_calls > 0 else 100:.2f}%",
                "",
                "API详细统计:",
                "-" * 80,
            ]
        )

        # 详细统计
        summary = self.get_summary(sort_by="count")
        report.append(json.dumps(summary, indent=2, ensure_ascii=False))

        # 慢调用
        slow_calls = self.get_slow_calls()
        if slow_calls:
            report.extend(["", "慢调用Top 10:", "-" * 80])
            report.append(json.dumps(slow_calls[:10], indent=2, ensure_ascii=False))

        # 失败API
        failed = self.get_failed_apis()
        if failed:
            report.extend(["", "失败API Top 10:", "-" * 80])
            report.append(json.dumps(failed[:10], indent=2, ensure_ascii=False))

        report.append("=" * 80)
        return "\n".join(report)

    def reset(self) -> None:
        """重置所有统计数据

        示例:
            tracker.reset()
        """
        self.stats.clear()
        self.start_time = datetime.now()
        logger.info("性能统计已重置")

    def export_to_json(self, file_path: str) -> None:
        """导出统计数据到JSON文件

        Args:
            file_path: 文件路径

        示例:
            tracker.export_to_json("performance_report.json")
        """
        summary = self.get_summary()
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "统计时间": self.start_time.isoformat(),
                    "慢调用阈值(ms)": self.slow_threshold_ms,
                    "API统计": summary,
                    "慢调用": self.get_slow_calls(),
                    "失败API": self.get_failed_apis(),
                },
                f,
                indent=2,
                ensure_ascii=False,
            )
        logger.info(f"性能报告已导出: {file_path}")
