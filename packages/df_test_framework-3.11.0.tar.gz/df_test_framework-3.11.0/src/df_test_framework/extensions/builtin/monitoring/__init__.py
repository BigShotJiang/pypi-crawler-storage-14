"""性能监控模块

v1.3.0 新增:
- API响应时间统计
- 数据库慢查询监控
- 性能数据收集和分析

使用示例:
    # API性能追踪
    from df_test_framework.monitoring import APIPerformanceTracker

    tracker = APIPerformanceTracker()
    tracker.record("create_card", duration_ms=125.5, success=True)
    summary = tracker.get_summary()

    # 数据库慢查询监控
    from df_test_framework.monitoring import setup_slow_query_logging

    db = Database(connection_string)
    setup_slow_query_logging(db.engine, threshold_ms=100)
"""

from .api_tracker import APIPerformanceTracker
from .db_monitor import SlowQueryMonitor, setup_slow_query_logging

__all__ = [
    "APIPerformanceTracker",
    "setup_slow_query_logging",
    "SlowQueryMonitor",
]
