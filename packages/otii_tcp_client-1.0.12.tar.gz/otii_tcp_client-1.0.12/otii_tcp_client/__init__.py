"""Otii TCP Client

Install the Otii TCP Client for Python:

    .. code-block:: python

        python3 -m pip install otii-tcp-client

"""
