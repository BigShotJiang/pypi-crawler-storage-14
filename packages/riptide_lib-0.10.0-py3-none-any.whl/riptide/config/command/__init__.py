"""
Additional functions for commands.
"""
