class RiptideDeprecationWarning(DeprecationWarning):
    pass
