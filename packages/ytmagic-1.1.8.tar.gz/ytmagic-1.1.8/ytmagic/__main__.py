#!/usr/bin/env python3

import argparse
import os
import sys
from pathlib import Path
from yt_dlp import YoutubeDL
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.console import Console

console = Console()

quality_map = {
    "360": "best[height<=360]/best",
    "480": "best[height<=480]/best",
    "720": "best[height<=720]/best",
    "1080": "best[height<=1080]/best",
    "best": "best"
}

# -------- FALLBACK CLIENT PROFILES (FOR SABR / SIGNATURE ISSUES) --------
CLIENT_PROFILES = [
    {},  # default
    {"extractor_args": {"youtube": {"player_client": ["android"]}}},
    {"extractor_args": {"youtube": {"player_client": ["web"]}}},
    {"extractor_args": {"youtube": {"player_client": ["ios"]}}},
]

def download_video(url, quality, download_path, audio_only=False):
    output_template = os.path.join(download_path, "%(title)s.%(ext)s")

    primary_format = "bestaudio/best" if audio_only else quality_map.get(quality, "best")
    fallback_format = "best"

    base_opts = {
        "outtmpl": output_template,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "merge_output_format": "mp4",

        # METADATA + THUMBNAILS
        "addmetadata": True,
        "embedmetadata": True,
        "embedthumbnail": True,
        "writethumbnail": True,
        "prefer_ffmpeg": True,

        "progress_hooks": [],
    }

    # AUDIO MODE: MP3 + ID3 METADATA + COVER ART
    if audio_only:
        base_opts["postprocessors"] = [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            },
            {
                "key": "FFmpegMetadata",
            },
            {
                "key": "EmbedThumbnail",
            },
        ]
        base_opts["keepvideo"] = False

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TimeElapsedColumn(),
        transient=True,
    ) as progress:

        task = progress.add_task("Downloading...", start=False)

        def hook(d):
            if d["status"] == "downloading" and not progress.tasks[task].started:
                progress.start_task(task)
            if d["status"] == "finished":
                progress.update(task, description="Processing...")
                console.print(f"\n✅ [bold green]Download complete:[/bold green] {d['filename']}")

        base_opts["progress_hooks"] = [hook]

        # -------- SMART FALLBACK LOOP --------
        for attempt, profile in enumerate(CLIENT_PROFILES, start=1):
            ydl_opts = {**base_opts, **profile, "format": primary_format}

            try:
                with YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
                return  # ✅ SUCCESS

            except Exception:
                if attempt == 1:
                    console.print("⚠️  Normal client failed. Trying fallback clients...")
                elif attempt == len(CLIENT_PROFILES):
                    console.print("⚠️  All clients failed. Using safest fallback format...")
                else:
                    continue

        # -------- FINAL HARD FALLBACK --------
        base_opts["format"] = fallback_format
        try:
            with YoutubeDL(base_opts) as ydl:
                ydl.download([url])
            console.print("⚠️  Downloaded with limited format due to YouTube restrictions.")
        except Exception as e:
            console.print(f"❌ [bold red]Fatal Download Error:[/bold red] {e}")
            sys.exit(1)
def main():
    parser = argparse.ArgumentParser(
        description="🎥 Download videos or extract audio from YouTube, Instagram, Facebook, TikTok, X (Twitter), and more — easily and fast.",
        epilog="""
Examples:
  ytmagic -v or ytmagic --version                  # Show Current version
  ytmagic https://youtu.be/example1                # Best video+audio(saved into Downloads folder)
  ytmagic https://youtu.be/example1 -q 360         # Download 360p
  ytmagic https://youtu.be/example2 -q 720         # Download 720p
  ytmagic https://youtu.be/example3 -a             # Download and convert to MP3
  ytmagic -a https://youtu.be/exapmple4 -p ~/Music # Audio to custom folder
  
  Owner: Owais shafi
  Username: @Meowahaha
  To upgrade ytmagic, run: pipx upgrade ytmagic
  For more details, visit: https://pypi.org/project/ytmagic/
              """,
        formatter_class=argparse.RawTextHelpFormatter
    )

    parser.add_argument("url", help="Video URL to download")
    parser.add_argument("-q", "--quality", default="best", choices=quality_map.keys(),
                        help="Video quality: 360, 480, 720, 1080, best")
    parser.add_argument("-p", "--path", default=str(Path.home() / "Downloads"),
                        help="Download location (default: ~/Downloads)")
    parser.add_argument("-a", "--audio", action="store_true",
                        help="Download audio only and convert to MP3")
    parser.add_argument("-v", "--version", action="version", version="ytmagic 1.1.8",
                        help="Show the version of ytmagic")

    args = parser.parse_args()
    download_video(args.url, args.quality, args.path, audio_only=args.audio)

if __name__ == "__main__":
    main()
