import json
import urllib.request
import pandas as pd
class APIError(Exception):
    pass
from datetime import datetime
import datetime as dt
from typing import Optional


SERVER_URL = "http://117.72.218.26:888/proxy"
# SERVER_URL = "http://127.0.0.1:888/proxy"

class QtFactor:
    def __init__(self, license_code: str):
        self.license = license_code
        if not self._verify(self.license):
            raise APIError("授权码无效或已过期")

    def _verify(self, text: str) -> bool:
        try:
            s = str(eval(text))
            start_date = str(datetime.now())[:10]
            year = s[100:104]
            moth = s[163:165]
            daily = s[184:186]
            end_date = f"{year}-{moth}-{daily}"
            y, m, d = map(int, end_date.split('-'))
            d1 = dt.datetime(*map(int, start_date.split('-'))) # type: ignore
            d2 = dt.datetime(y, m, d)
            days = (d2 - d1).days
            return s[8]=='8' and s[16]=='8' and s[24]=='8' and s[32]=='8' and days>0
        except Exception:
            return False

    def _request(self, api_name: str, fields: Optional[str] = None, **kwargs):
        """
        私有的通用请求方法，用于统一处理API调用、响应解析和错误处理。
        """
        try:
            params = {k: v for k, v in kwargs.items() if v is not None}
            payload = {"api_name": api_name, "params": params, "license": self.license}
            if fields:
                payload["fields"] = fields
            
            req = urllib.request.Request(
                SERVER_URL,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"},
            )

            with urllib.request.urlopen(req, timeout=30) as resp:
                obj = json.loads(resp.read().decode("utf-8"))
                
                if obj.get("code", 0) != 0:
                    msg = obj.get("msg", "未知错误")
                    separator = "权限的具体详情访问"
                    if separator in msg:
                        msg = msg.split(separator)[0].strip().rstrip('，').rstrip(',')
                    raise APIError(msg)
                
                data = obj.get("data", {})
                
                if api_name == "get_full_tick":
                    return data

                if api_name == "get_market_data_ex":
                    reconstructed_data = {}
                    if isinstance(data, dict):
                        for key, value in data.items():
                            if isinstance(value, dict) and 'data' in value and 'columns' in value:
                                # Reconstruct the DataFrame from the serialized dict
                                reconstructed_data[key] = pd.DataFrame(value['data'], index=value.get('index'), columns=value['columns'])
                            else:
                                # Keep non-DataFrame values as is
                                reconstructed_data[key] = value
                    else:
                        # Should not happen based on server logic, but safe to have
                        reconstructed_data = data 
                    return reconstructed_data
                
                fields_list = data.get("fields", [])
                items = data.get("items", [])
                return pd.DataFrame(items, columns=fields_list)

        except Exception as e:
            if isinstance(e, APIError):
                raise e
            raise APIError(str(e))

    # --- 接口函数定义区 (共39个) ---

    def stock_basic(self, fields: Optional[str] = None, **kwargs):
        return self._request("stock_basic", fields=fields, **kwargs)

    def stock_moneyflow(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow", fields=fields, **kwargs)

    def moneyflow_ths(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow_ths", fields=fields, **kwargs)

    def moneyflow_dc(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow_dc", fields=fields, **kwargs)

    def moneyflow_cnt_ths(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow_cnt_ths", fields=fields, **kwargs)

    def moneyflow_ind_ths(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow_ind_ths", fields=fields, **kwargs)

    def moneyflow_ind_dc(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow_ind_dc", fields=fields, **kwargs)

    def moneyflow_mkt_dc(self, fields: Optional[str] = None, **kwargs):
        return self._request("moneyflow_mkt_dc", fields=fields, **kwargs)

    def report_rc(self, fields: Optional[str] = None, **kwargs):
        return self._request("report_rc", fields=fields, **kwargs)

    def cyq_perf(self, fields: Optional[str] = None, **kwargs):
        return self._request("cyq_perf", fields=fields, **kwargs)

    def cyq_chips(self, fields: Optional[str] = None, **kwargs):
        return self._request("cyq_chips", fields=fields, **kwargs)

    def stk_factor_pro(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_factor_pro", fields=fields, **kwargs)

    def stk_auction_o(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_auction_o", fields=fields, **kwargs)

    def stk_auction_c(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_auction_c", fields=fields, **kwargs)

    def stk_nineturn(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_nineturn", fields=fields, **kwargs)

    def stk_ah_comparison(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_ah_comparison", fields=fields, **kwargs)

    def broker_recommend(self, fields: Optional[str] = None, **kwargs):
        return self._request("broker_recommend", fields=fields, **kwargs)

    def top_list(self, fields: Optional[str] = None, **kwargs):
        return self._request("top_list", fields=fields, **kwargs)

    def top_inst(self, fields: Optional[str] = None, **kwargs):
        return self._request("top_inst", fields=fields, **kwargs)

    def ths_index(self, fields: Optional[str] = None, **kwargs):
        return self._request("ths_index", fields=fields, **kwargs)

    def ths_daily(self, fields: Optional[str] = None, **kwargs):
        return self._request("ths_daily", fields=fields, **kwargs)

    def ths_member(self, fields: Optional[str] = None, **kwargs):
        return self._request("ths_member", fields=fields, **kwargs)

    def dc_index(self, fields: Optional[str] = None, **kwargs):
        return self._request("dc_index", fields=fields, **kwargs)

    def dc_member(self, fields: Optional[str] = None, **kwargs):
        return self._request("dc_member", fields=fields, **kwargs)

    def dc_daily(self, fields: Optional[str] = None, **kwargs):
        return self._request("dc_daily", fields=fields, **kwargs)

    def stk_auction(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_auction", fields=fields, **kwargs)

    def tdx_index(self, fields: Optional[str] = None, **kwargs):
        return self._request("tdx_index", fields=fields, **kwargs)

    def tdx_member(self, fields: Optional[str] = None, **kwargs):
        return self._request("tdx_member", fields=fields, **kwargs)

    def tdx_daily(self, fields: Optional[str] = None, **kwargs):
        return self._request("tdx_daily", fields=fields, **kwargs)

    def kpl_list(self, fields: Optional[str] = None, **kwargs):
        return self._request("kpl_list", fields=fields, **kwargs)

    def kpl_concept(self, fields: Optional[str] = None, **kwargs):
        return self._request("kpl_concept", fields=fields, **kwargs)

    def kpl_concept_cons(self, fields: Optional[str] = None, **kwargs):
        return self._request("kpl_concept_cons", fields=fields, **kwargs)

    def trade_cal(self, fields: Optional[str] = None, **kwargs):
        return self._request("trade_cal", fields=fields, **kwargs)

    def stock_st(self, fields: Optional[str] = None, **kwargs):
        return self._request("stock_st", fields=fields, **kwargs)

    def stock_hsgt(self, fields: Optional[str] = None, **kwargs):
        return self._request("stock_hsgt", fields=fields, **kwargs)

    def new_share(self, fields: Optional[str] = None, **kwargs):
        return self._request("new_share", fields=fields, **kwargs)

    def daily_basic(self, fields: Optional[str] = None, **kwargs):
        return self._request("daily_basic", fields=fields, **kwargs)

    def pro_bar(self, fields: Optional[str] = None, **kwargs):
        return self._request("pro_bar", fields=fields, **kwargs)

    def stk_limit(self, fields: Optional[str] = None, **kwargs):
        return self._request("stk_limit", fields=fields, **kwargs)

    def get_market_data_ex(self, stock_code: str = '', field_list: list = [], period: str = '1d', start_time: str = '', end_time: str = '', count: int = -1, dividend_type: str = 'none', fill_data: bool = True):
        params = locals()
        del params['self']
        return self._request("get_market_data_ex", **params)

    def get_full_tick(self, stock_list: list):
        return self._request("get_full_tick", stock_list=stock_list)
