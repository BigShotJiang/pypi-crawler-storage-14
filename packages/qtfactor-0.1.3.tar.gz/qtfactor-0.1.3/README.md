# QtFactor

QtFactor 是面向量化研究的数据访问库，统一封装了 Tushare 与 QMT 的接口，支持以同一种调用方式获取多源数据，覆盖基础资料、行情、资金、财务与高频逐笔等核心数据场景。

## 能获取哪些数据

- Tushare 系列（完整兼容原始 39 个接口）
  - 基础资料：股票列表、行业/地域、上市/退市、交易日历等
  - 行情与指标：日线/周线/月线、复权、技术指标、资金面等
  - 财务相关：利润表、资产负债表、现金流量、财务指标等
  - 指数/期货/基金等常用板块数据
- QMT 系列（实时/高频）
  - `get_market_data_ex`：按周期获取 K 线、复权因子等，原始字典返回，其中包含 `DataFrame`
  - `get_full_tick`：获取全量逐笔 tick 原始数据（字典格式，不做转换）
- 特殊处理
  - `pro_bar`：遵循官方约定，走 `ts.pro_bar` 特殊通道，保持与 Tushare 标准一致

## 返回格式说明

- Tushare 接口：统一返回 `pandas.DataFrame`
- QMT `get_market_data_ex`：返回字典，字典中某些键对应 `DataFrame`
- QMT `get_full_tick`：返回原始字典，不做任何格式转换

## 安装

```bash
pip install QtFactor
```

## 导入与快速上手

```python
from QtFactor import QtFactor

# 使用授权码初始化（无授权码联系管理员：微信 QUANT0808）
q = QtFactor("YOUR_LICENSE_CODE")

# 示例1：获取股票基础信息（Tushare）
df_basic = q.stock_basic(fields='ts_code,name,area,industry')
print(df_basic.head())

# 示例2：获取 K 线行情（QMT）
data_kline = q.get_market_data_ex(stock_code='600519.SH', period='1d', count=5)
print(type(data_kline), list(data_kline.keys()))

# 示例3：获取全量逐笔（QMT）
tick = q.get_full_tick(stock_list=['000001.SZ'])
print(type(tick))
```

## 使用前提

- 该包为客户端组件，需要有可访问的服务端实例；服务端地址通过包内 `SERVER_URL` 配置
- QMT 数据获取需本机启动 MiniQMT，并按要求先订阅后拉取（`get_market_data_ex` 已在服务端内置顺序）