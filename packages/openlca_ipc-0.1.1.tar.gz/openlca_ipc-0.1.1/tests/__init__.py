"""
Test suite for openlca_ipc library
"""
