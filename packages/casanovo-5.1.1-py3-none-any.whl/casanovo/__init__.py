from .version import _get_version


__version__ = _get_version()
