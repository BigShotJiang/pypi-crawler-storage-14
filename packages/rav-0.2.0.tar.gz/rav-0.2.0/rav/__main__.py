import fire

from rav.cli import RavCLI


def main():
    fire.Fire(RavCLI)


if __name__ == "__main__":
    main()
