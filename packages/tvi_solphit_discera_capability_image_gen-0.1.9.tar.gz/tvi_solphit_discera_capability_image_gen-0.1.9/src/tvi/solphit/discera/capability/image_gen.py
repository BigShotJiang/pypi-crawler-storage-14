# src/discera_service/capabilities/image_gen.py
from __future__ import annotations

import os
import html
import base64
from io import BytesIO
from typing import Any, Dict, List, Optional

import torch
from diffusers import StableDiffusionXLPipeline

class ImageGenCapability:
    """
    Discera capability: image_gen
    - Text-to-image via SDXL
    - Returns HTML snippet + base64 PNG for UI display
    """
    name = "image_gen"
    _pipe: Optional[StableDiffusionXLPipeline] = None

    # ---------- Descriptor & assets ----------
    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": ImageGenCapability.name,
            "description": (
                "Generates images from text prompts using local Stable Diffusion XL. "
                "Returns a base64-encoded PNG and minimal CSS/JS for rendering."
            ),
            "intents": ["image_generation", "visualization", "art", "diagram"],
            "examples": [
                "Generate a futuristic city skyline at sunset.",
                "Create a diagram of the water cycle.",
                "Draw a cartoon cat riding a bicycle.",
            ],
            "tags": ["image", "generation", "art", "visual", "diagram", "picture"],
            "excludes": [],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        css = r"""
.image-gen-result {
  margin: 12px 0;
  text-align: center;
}
.image-gen-result img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.12);
  background: #222;
}
.image-gen-caption {
  margin-top: 8px;
  color: #9ca3af;
  font-size: 0.92rem;
}
"""
        # (We keep JS empty; rendering is handled by the HTML snippet we return.)
        return {"css": [css], "js": []}

    # ---------- Model loading ----------
    def _get_pipe(self) -> StableDiffusionXLPipeline:
        """
        Lazy-load the SDXL pipeline, preferring local weights.

        Environment variables:
          - SDXL_MODEL_DIR (optional): local folder with the SDXL base model
          - HF_HOME / TRANSFORMERS_CACHE / DIFFUSERS_CACHE: cache dirs (default /models/hf)
        """
        if self._pipe is not None:
            return self._pipe

        # Prefer local cache/weights under /models by default
        hf_home = os.getenv("HF_HOME", "/models/hf")
        os.environ.setdefault("HF_HOME", hf_home)
        os.environ.setdefault("TRANSFORMERS_CACHE", hf_home)
        os.environ.setdefault("DIFFUSERS_CACHE", hf_home)

        local_dir = os.getenv("SDXL_MODEL_DIR")  # e.g., /models/sdxl-base-1.0
        model_id = os.getenv("SDXL_MODEL_ID", "stabilityai/stable-diffusion-xl-base-1.0")

        # Use float16 on CUDA if available; else float32 on CPU
        use_cuda = torch.cuda.is_available()
        dtype = torch.float16 if use_cuda else torch.float32

        if local_dir and os.path.isdir(local_dir):
            # Local-only: do not attempt network
            pipe = StableDiffusionXLPipeline.from_pretrained(
                local_dir,
                local_files_only=True,
                torch_dtype=dtype,
            )
        else:
            # Remote id with cache; will read from HF_HOME if already present
            pipe = StableDiffusionXLPipeline.from_pretrained(
                model_id,
                torch_dtype=dtype,
                cache_dir=hf_home,
            )

        # a) VAE slicing/tiling — big impact on peak VRAM at decode step
        try:
            if hasattr(pipe, "enable_vae_slicing"):
                pipe.enable_vae_slicing()
            if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_tiling"):
                pipe.vae.enable_tiling()
        except Exception:
            pass

        # b) Offload modules to CPU between uses (slower, but saves a lot of VRAM)
        try:
            pipe.enable_sequential_cpu_offload()
        except Exception:
            try:
                pipe.enable_model_cpu_offload()
            except Exception:
                pass

        # c) Memory‑efficient attention — use xFormers (if installed) or SDPA fallback
        try:
            pipe.enable_xformers_memory_efficient_attention()
        except Exception:
            # Torch 2 SDPA is decent if xFormers isn't available
            try:
                torch.set_float32_matmul_precision("medium")
            except Exception:
                pass

        # Disable NSFW checker if you’ve pre-filtered prompts elsewhere; leave enabled otherwise.
        # try: pipe.safety_checker = None
        # except Exception: pass

        self._pipe = pipe
        return pipe

    # ---------- Helper ----------
    @staticmethod
    def _html_for_image(b64: str, prompt: str, caption: str = "") -> str:
        safe_prompt = html.escape(prompt or "")
        cap = html.escape(caption or "")
        return (
            f'<div class="image-gen-result">'
            f'<img src="data:image/png;base64,{b64}" alt="{safe_prompt}" loading="lazy">{cap}</div>'
            f"</div>"
        )

    def _extract(self, args: Any, hints: Dict[str, Any]) -> Dict[str, Any]:
        # Helper: first non-empty value among candidates
        def pick(*vals, default=None):
            for v in vals:
                if v is None:
                    continue
                s = str(v).strip() if isinstance(v, str) else v
                if s in ("", "none", "null"):
                    continue
                return v
            return default

        # Helper: int/float coercers with default and optional clamping
        def to_int(val, default, *, lo=None, hi=None):
            if val is None or (isinstance(val, str) and val.strip() in ("", "none", "null")):
                v = default
            else:
                try:
                    v = int(val) if isinstance(val, (int,)) else int(float(str(val)))
                except Exception:
                    v = default
            if lo is not None: v = max(lo, v)
            if hi is not None: v = min(hi, v)
            return v

        def to_float(val, default, *, lo=None, hi=None):
            if val is None or (isinstance(val, str) and val.strip() in ("", "none", "null")):
                v = default
            else:
                try:
                    v = float(val)
                except Exception:
                    v = default
            if lo is not None: v = max(lo, v)
            if hi is not None: v = min(hi, v)
            return v

        # Pull prompt and options from hints/args (dict or object)
        prompt = (getattr(args, "question", None) or (
            args.get("question") if isinstance(args, dict) else "") or "").strip()
        negative = (pick(hints.get("negative"), (args.get("negative") if isinstance(args, dict) else None),
                         getattr(args, "negative", None), default="") or "").strip()

        width = to_int(pick(hints.get("width"), (args.get("width") if isinstance(args, dict) else None),
                            getattr(args, "width", None)), 128, lo=64, hi=1024)
        height = to_int(pick(hints.get("height"), (args.get("height") if isinstance(args, dict) else None),
                             getattr(args, "height", None)), 128, lo=64, hi=1024)
        steps = to_int(pick(hints.get("steps"), (args.get("steps") if isinstance(args, dict) else None),
                            getattr(args, "steps", None)), 10, lo=10, hi=80)
        guidance = to_float(pick(hints.get("guidance"), (args.get("guidance") if isinstance(args, dict) else None),
                                 getattr(args, "guidance", None)), 7.0, lo=1.0, hi=20.0)

        width = max(128, min(int(width), 832))  # <= 832 recommended for 8 GB
        height = max(128, min(int(height), 832))
        steps = max(10, min(int(steps), 28))  # 20–28 is usually fine on SDXL
        guidance = max(1.0, min(float(guidance), 9.0))

        seed_val = pick(hints.get("seed"), (args.get("seed") if isinstance(args, dict) else None),
                        getattr(args, "seed", None), default=None)
        try:
            seed = int(seed_val) if seed_val is not None and str(seed_val).strip() not in ("", "none", "null") else None
        except Exception:
            seed = None

        concise = bool(pick(hints.get("concise"), (args.get("concise") if isinstance(args, dict) else None),
                            getattr(args, "concise", None), default=False))

        return {
            "prompt": prompt,
            "negative": negative,
            "width": width,
            "height": height,
            "steps": steps,
            "guidance": guidance,
            "seed": seed,
            "concise": concise,
        }

    # ---------- Execution ----------
    def run_once(self, args: Any, **kwargs) -> Dict[str, Any]:
        hints: Dict[str, Any] = kwargs.get("hints") or {}
        p = self._extract(args, hints)
        prompt = p["prompt"]
        if not prompt:
            return {
                "answer": "Please provide a prompt for image generation.",
                "image_base64": "",
                "meta": {"capability": self.name, "error": "missing_prompt"},
            }

        try:
            pipe = self._get_pipe()
            generator = torch.Generator(device="cuda" if torch.cuda.is_available() else "cpu")
            if p["seed"] is not None:
                generator = generator.manual_seed(int(p["seed"]))

            with torch.inference_mode():
                image = pipe(
                    prompt=prompt,
                    negative_prompt=p["negative"] or None,
                    width=p["width"],
                    height=p["height"],
                    num_inference_steps=p["steps"],
                    guidance_scale=p["guidance"],
                    generator=generator,
                ).images[0]

            buf = BytesIO()
            image.save(buf, format="PNG")
            image_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

            # Build HTML (concise: no long caption)
            caption = "Rendered via local SDXL" if not p["concise"] else ""
            html_block = self._html_for_image(image_b64, prompt, caption)

            return {
                "answer": html_block,       # front-end renders this directly
                "image_base64": image_b64,  # also available to the UI if needed
                "meta": {
                    "capability": self.name,
                    "prompt": prompt,
                    "negative": p["negative"],
                    "width": p["width"],
                    "height": p["height"],
                    "steps": p["steps"],
                    "guidance": p["guidance"],
                    "seed": p["seed"],
                    "device": "cuda" if torch.cuda.is_available() else "cpu",
                },
            }

        except Exception as ex:
            md = (
                "### Image Generation Error\n"
                f"**Prompt:** {html.escape(prompt)}\n\n"
                f"Sorry, image generation failed: `{ex}`"
            )
            return {
                "answer": md,
                "image_base64": "",
                "meta": {"capability": self.name, "prompt": prompt, "error": str(ex)},
            }

    async def run_stream(self, args: Any, **kwargs):
        # No token-by-token progress from diffusers; stream a few events for consistency
        yield {"event": "generation_started", "data": {"capability": self.name}}
        result = self.run_once(args, **kwargs)
        # Ask FE to inject capability assets (CSS) once per session
        try:
            yield {"event": "assets", "data": {"css": self.assets().get("css", []), "js": self.assets().get("js", [])}}
        except Exception:
            pass
        yield {"event": "token", "data": result["answer"]}
        yield {"event": "generation_done", "data": {}}
        yield {"event": "done", "data": {}}

def register(registry):
    registry.register(ImageGenCapability())
