A trial-version Linux terminal simulator for learning Linux commands on Windows.
