"""Application layer for BitAds Miner Scoring."""


