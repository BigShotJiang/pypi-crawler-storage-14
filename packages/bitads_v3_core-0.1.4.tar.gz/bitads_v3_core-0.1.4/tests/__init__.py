"""Unit tests for BitAds Miner Scoring."""


