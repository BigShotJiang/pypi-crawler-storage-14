"""ytp-dl: YouTube video downloader with Mullvad VPN integration"""

__version__ = "0.2.85"
__author__  = "dumgum82"
__email__   = "dumgum42@gmail.com"
