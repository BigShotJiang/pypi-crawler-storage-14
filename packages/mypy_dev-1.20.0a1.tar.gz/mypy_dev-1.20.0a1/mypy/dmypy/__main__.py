from __future__ import annotations

from mypy.dmypy.client import console_entry

if __name__ == "__main__":
    console_entry()
