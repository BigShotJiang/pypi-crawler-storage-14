::: github_custom_actions.ActionBase.render
    options:
      show_root_heading: true
      heading_level: 2
      show_submodules: false

::: github_custom_actions.ActionBase.render_template
    options:
      show_root_heading: true
      heading_level: 2
      show_submodules: false
