# main()

`main()` is called from `run()`:

---

::: github_custom_actions.ActionBase.run
    options:
      heading_level: 1
      show_submodules: false
