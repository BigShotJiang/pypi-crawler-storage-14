::: github_custom_actions.ActionInputs
    options:
      show_root_heading: false
      heading_level: 1
      show_submodules: false
