from github_custom_actions import __version__


def test_version():
    assert __version__
