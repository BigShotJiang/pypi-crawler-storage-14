from pathlib import Path
from typing import Optional


class NotDjangXAppRootError(Exception):
    """Raised when the current directory is not a DjangX app root."""

    pass


class DjangXAppRoot:
    """Directory path configuration and validation of DjangX app project structure."""

    _cached_base_dir: Optional[Path] = None
    _cached_is_valid: Optional[bool] = None

    @classmethod
    def _detect_base_dir(cls) -> tuple[Path, bool]:
        """Detect if we're in a valid DjangX project and cache the results."""
        cwd = Path.cwd()
        apps_py = cwd / "app" / "apps.py"

        if apps_py.exists():
            try:
                with open(apps_py, "r", encoding="utf-8") as f:
                    content = f.read()
                if "DjangXAppConfig" in content:
                    return apps_py.resolve().parent.parent, True
            except (OSError, UnicodeDecodeError):
                pass

        return cwd, False

    @classmethod
    def get_base_dir(cls) -> Path:
        """
        Get the DjangX app base directory or raise NotDjangXAppRootError.

        Returns:
            Path: The base directory of the DjangX app.

        Raises:
            NotDjangXAppRootError: If not in a valid DjangX app root.
        """
        if cls._cached_base_dir is None:
            cls._cached_base_dir, cls._cached_is_valid = cls._detect_base_dir()

        if not cls._cached_is_valid:
            raise NotDjangXAppRootError(
                "Not a DjangX app root. Navigate to your app's root or initialize a new DjangX app."
            )

        return cls._cached_base_dir

    @classmethod
    def get_cached_base_dir(cls) -> Optional[Path]:
        """
        Get the base directory if it has already been validated, otherwise return None.

        This is useful for contexts where validation has already happened (like CLI startup)
        and we want to reuse the cached result without re-checking.

        Returns:
            Optional[Path]: The cached base directory if already validated, None otherwise.
        """
        if cls._cached_base_dir is not None and cls._cached_is_valid:
            return cls._cached_base_dir
        return None


def get_base_dir_or_exit() -> Path:
    """Get the DjangX app base directory or exit with an error."""
    try:
        return DjangXAppRoot.get_base_dir()
    except NotDjangXAppRootError as e:
        import sys

        from django.core.management.color import color_style

        print(color_style().ERROR(e))
        sys.exit(1)
