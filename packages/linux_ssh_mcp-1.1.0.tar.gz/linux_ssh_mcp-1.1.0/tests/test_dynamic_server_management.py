#!/usr/bin/env python3
"""
Test suite for Dynamic Server Management functionality

This module tests the new runtime server management features including:
- Runtime server addition and removal
- Server configuration updates
- Batch import/export operations
- Performance metrics collection
"""

import pytest
import asyncio
import tempfile
import json
import os
from pathlib import Path
import sys

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from linux_ssh_mcp.ssh_manager import SSHManager, ServerConfig, ServerStatus


class TestDynamicServerManagement:
    """Test suite for dynamic server management features"""

    @pytest.fixture
    async def ssh_manager(self):
        """Create a test SSH manager instance"""
        manager = SSHManager(use_pooling=False, config_file="test_servers.json")
        yield manager
        # Cleanup
        await manager.cleanup_connections()
        # Remove test config file
        if os.path.exists("test_servers.json"):
            os.unlink("test_servers.json")

    @pytest.fixture
    def test_server_configs(self):
        """Sample server configurations for testing"""
        return {
            "web-01": {
                "id": "web-01",
                "host": "192.168.1.10",
                "port": 22,
                "username": "admin",
                "password": "test123",
                "timeout": 30
            },
            "db-01": {
                "id": "db-01",
                "host": "192.168.1.20",
                "port": 22,
                "username": "root",
                "password": "dbpass456",
                "timeout": 45
            },
            "cache-01": {
                "id": "cache-01",
                "host": "192.168.1.30",
                "port": 22,
                "username": "redis",
                "password": "cache789",
                "timeout": 20
            }
        }

    async def test_add_server_runtime_success(self, ssh_manager):
        """Test successful runtime server addition"""
        success = ssh_manager.add_server_runtime(
            server_id="test-server",
            host="10.0.1.100",
            username="admin",
            password="test123",
            persistent=False  # Don't persist for test
        )

        assert success is True
        assert "test-server" in ssh_manager.servers

        config = ssh_manager.get_server_config("test-server")
        assert config.host == "10.0.1.100"
        assert config.username == "admin"
        assert config.password == "test123"

    async def test_add_server_runtime_persistent(self, ssh_manager):
        """Test runtime server addition with persistence"""
        success = ssh_manager.add_server_runtime(
            server_id="persistent-server",
            host="10.0.1.101",
            username="admin",
            password="test123",
            persistent=True
        )

        assert success is True

        # Check if config file was created
        assert os.path.exists("test_servers.json")

        # Verify content in config file
        with open("test_servers.json", 'r') as f:
            data = json.load(f)
            assert "persistent-server" in data

    async def test_add_server_runtime_duplicate(self, ssh_manager):
        """Test adding duplicate server"""
        # Add first server
        ssh_manager.add_server_runtime(
            server_id="duplicate-test",
            host="10.0.1.102",
            username="admin"
        )

        # Try to add same server again
        success = ssh_manager.add_server_runtime(
            server_id="duplicate-test",
            host="10.0.1.103",  # Different host
            username="admin"
        )

        # Should still succeed (just overwrites)
        assert success is True

        config = ssh_manager.get_server_config("duplicate-test")
        assert config.host == "10.0.1.103"  # Updated host

    async def test_remove_server_runtime_success(self, ssh_manager):
        """Test successful server removal"""
        # First add a server
        ssh_manager.add_server_runtime(
            server_id="remove-test",
            host="10.0.1.200",
            username="admin"
        )

        assert "remove-test" in ssh_manager.servers

        # Remove the server
        success = ssh_manager.remove_server_runtime("remove-test")

        assert success is True
        assert "remove-test" not in ssh_manager.servers

    async def test_remove_server_runtime_not_found(self, ssh_manager):
        """Test removing non-existent server"""
        success = ssh_manager.remove_server_runtime("non-existent-server")
        assert success is False

    async def test_update_server_config_success(self, ssh_manager):
        """Test successful server configuration update"""
        # Add a server first
        ssh_manager.add_server_runtime(
            server_id="update-test",
            host="10.0.1.300",
            username="admin",
            password="oldpass",
            timeout=30
        )

        # Update configuration
        success = ssh_manager.update_server_config(
            "update-test",
            password="newpass",
            timeout=60,
            port=2222
        )

        assert success is True

        config = ssh_manager.get_server_config("update-test")
        assert config.password == "newpass"
        assert config.timeout == 60
        assert config.port == 2222
        assert config.host == "10.0.1.300"  # Unchanged

    async def test_update_server_config_not_found(self, ssh_manager):
        """Test updating non-existent server"""
        success = ssh_manager.update_server_config(
            "non-existent-server",
            password="newpass"
        )
        assert success is False

    async def test_import_servers_from_dict(self, ssh_manager, test_server_configs):
        """Test importing servers from dictionary"""
        count = ssh_manager.import_servers_from_dict(test_server_configs, overwrite=False)

        assert count == 3  # All 3 servers should be imported

        # Verify all servers were added
        for server_id in test_server_configs.keys():
            assert server_id in ssh_manager.servers

        config = ssh_manager.get_server_config("web-01")
        assert config.host == "192.168.1.10"

    async def test_import_servers_from_dict_overwrite(self, ssh_manager, test_server_configs):
        """Test importing servers with overwrite enabled"""
        # Add one server first
        ssh_manager.add_server_runtime(
            server_id="web-01",
            host="10.0.1.999",
            username="olduser"
        )

        # Import with overwrite
        count = ssh_manager.import_servers_from_dict(test_server_configs, overwrite=True)

        assert count == 3
        config = ssh_manager.get_server_config("web-01")
        assert config.host == "192.168.1.10"  # Should be overwritten
        assert config.username == "admin"  # Should be overwritten

    async def test_export_servers_to_dict(self, ssh_manager, test_server_configs):
        """Test exporting servers to dictionary"""
        # Import servers first
        ssh_manager.import_servers_from_dict(test_server_configs)

        # Export servers
        exported_data = ssh_manager.export_servers_to_dict()

        assert len(exported_data) == 3

        # Verify structure and password masking
        for server_id, config_data in exported_data.items():
            assert "host" in config_data
            assert "username" in config_data
            # Password should be masked
            if config_data.get("password"):
                assert config_data["password"] == "***"

    async def test_load_servers_from_file(self, ssh_manager, test_server_configs):
        """Test loading servers from file"""
        # Create temporary file with server configs
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(test_server_configs, f, indent=2)
            temp_file = f.name

        try:
            # Load from file
            count = ssh_manager.load_servers_from_file(temp_file, overwrite=False)

            assert count == 3

            # Verify servers were loaded
            for server_id in test_server_configs.keys():
                assert server_id in ssh_manager.servers

        finally:
            os.unlink(temp_file)

    async def test_save_servers_to_file(self, ssh_manager, test_server_configs):
        """Test saving servers to file"""
        # Import servers first
        ssh_manager.import_servers_from_dict(test_server_configs)

        # Save to temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_file = f.name

        try:
            success = ssh_manager.save_servers_to_file(temp_file, include_passwords=True)
            assert success is True
            assert os.path.exists(temp_file)

            # Verify content
            with open(temp_file, 'r') as f:
                data = json.load(f)
                assert len(data) == 3
                assert "web-01" in data

        finally:
            if os.path.exists(temp_file):
                os.unlink(temp_file)

    async def test_get_performance_metrics(self, ssh_manager):
        """Test performance metrics collection"""
        # Add some servers
        ssh_manager.add_server_runtime("metrics-test-1", "10.0.1.400", "admin")
        ssh_manager.add_server_runtime("metrics-test-2", "10.0.1.401", "admin")

        metrics = ssh_manager.get_performance_metrics()

        # Verify structure
        assert "ssh_connections" in metrics
        assert "ssh_commands" in metrics
        assert "servers" in metrics

        # Verify server metrics
        assert metrics["servers"]["total"] == 2
        assert metrics["servers"]["configured"] == 2

        # Verify connection metrics structure
        conn_metrics = metrics["ssh_connections"]
        assert "total" in conn_metrics
        assert "successful" in conn_metrics
        assert "failed" in conn_metrics
        assert "success_rate" in conn_metrics

    async def test_server_configuration_validation(self):
        """Test server configuration validation"""
        manager = SSHManager()

        # Test invalid configurations
        with pytest.raises(ValueError):
            ServerConfig(id="", host="192.168.1.1", username="admin")

        with pytest.raises(ValueError):
            ServerConfig(id="test", host="", username="admin")

    async def test_server_status_check(self, ssh_manager):
        """Test server status checking"""
        # Add a server
        ssh_manager.add_server_runtime("status-test", "10.0.1.500", "admin")

        # Get status (will return DISCONNECTED since it's a test server)
        status = await ssh_manager.get_server_status("status-test")
        assert isinstance(status, ServerStatus)

        # Test non-existent server
        status = await ssh_manager.get_server_status("non-existent")
        assert status == ServerStatus.ERROR

    @pytest.mark.asyncio
    async def test_concurrent_server_operations(self, ssh_manager):
        """Test concurrent server operations"""
        # Create multiple concurrent tasks
        tasks = []

        for i in range(5):
            task = ssh_manager.add_server_runtime(
                server_id=f"concurrent-{i}",
                host=f"10.0.1.{600+i}",
                username="admin",
                persistent=False
            )
            tasks.append(task)

        # Wait for all operations to complete
        results = await asyncio.gather(*tasks)

        # Verify all operations succeeded
        assert all(results) is True
        assert len(ssh_manager.servers) == 5

        # Verify servers were added correctly
        for i in range(5):
            server_id = f"concurrent-{i}"
            assert server_id in ssh_manager.servers
            config = ssh_manager.get_server_config(server_id)
            assert config.host == f"10.0.1.{600+i}"


# Integration test for MCP tools
class TestMCPToolsIntegration:
    """Test integration of dynamic server management with MCP tools"""

    @pytest.mark.asyncio
    async def test_mcp_server_initialization(self):
        """Test that MCP server initializes correctly with new tools"""
        # Import should not raise exceptions
        from linux_ssh_mcp.mcp_server import LinuxSSHMCP

        # Create MCP server instance
        mcp_server = LinuxSSHMCP()

        # Verify it was created successfully
        assert mcp_server is not None
        assert mcp_server.server is not None

        # The tools will be listed when the MCP server actually runs
        # For now, we just verify the server initializes without errors

    @pytest.mark.asyncio
    async def test_mcp_tools_availability(self):
        """Test that all new MCP tools are properly defined"""
        from linux_ssh_mcp.mcp_server import LinuxSSHMCP

        mcp_server = LinuxSSHMCP()

        # Get the tool definitions
        tools = mcp_server.setup_handlers()

        # We can't easily test the actual tool list without running the server
        # But we can verify the server doesn't crash during setup
        assert mcp_server is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])