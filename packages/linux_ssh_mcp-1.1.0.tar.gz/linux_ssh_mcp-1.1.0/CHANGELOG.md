# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2025-01-30

### Added 🆕
- **Dynamic Server Management**: Complete runtime server management without service restart
- **Runtime Server Addition**: `add_server_runtime()` method for adding servers at runtime
- **Server Configuration Updates**: `update_server_config()` method for updating server settings
- **Batch Server Operations**: `import_servers_from_dict()` and `export_servers_to_dict()` for bulk management
- **File-based Configuration**: `load_servers_from_file()` and `save_servers_to_file()` for persistence
- **Enhanced MCP Tools**: 7 new MCP tools for dynamic server management
  - `add_server_runtime` - Runtime server addition with persistence options
  - `update_server` - Update existing server configurations
  - `import_servers` - Batch import from files or dictionaries
  - `export_servers` - Export configurations with security options
  - `batch_execute` - Execute commands across multiple servers
  - `get_performance_metrics` - Real-time performance monitoring
- **Security Enhancements**: Password masking in exports, secure credential management
- **Performance Monitoring**: Enhanced metrics collection and reporting
- **Documentation**: Comprehensive Dynamic Server Management guide
- **Examples**: Complete usage examples and integration tests

### Changed 🔧
- Enhanced SSH Manager with 8 new server management methods
- Updated MCP Server with expanded tool set (from 4 to 11 tools)
- Improved error handling and connection management
- Better configuration persistence and validation
- Updated project structure and documentation

### Fixed 🐛
- Resolved issues with static server configuration limitations
- Fixed server addition requiring service restart
- Improved memory usage and connection cleanup
- Enhanced error reporting for server operations

### Security 🔒
- Added password masking in configuration exports
- Enhanced credential validation and handling
- Improved security for runtime server management

## [1.0.4] - 2024-11-29

### Added
- Initial MCP integration support
- Basic SSH connection management
- Authentication system with role-based access control
- Performance monitoring and metrics collection
- Docker and Kubernetes deployment support
- Web interface for server management

### Fixed
- Connection pooling issues
- Memory leaks in long-running operations
- Authentication token expiration handling

## [1.0.0] - 2024-11-01

### Added
- Initial release of Linux SSH MCP
- Core SSH connection management
- Basic server configuration
- Command execution framework
- Monitoring and logging systems

---

## Version History

- **1.1.0** - Dynamic Server Management Release (Current)
- **1.0.x** - Initial releases with basic functionality

## Upgrade Guide

### From 1.0.x to 1.1.0

All existing configurations are compatible. New features are additive and do not break existing functionality.

**New Features Available:**
- Use `add_server_runtime()` for dynamic server addition
- Use `update_server_config()` for runtime configuration changes
- Use new MCP tools for enhanced management capabilities

**No Migration Required:**
- Existing server configurations remain unchanged
- All existing API calls continue to work
- Configuration files are backward compatible