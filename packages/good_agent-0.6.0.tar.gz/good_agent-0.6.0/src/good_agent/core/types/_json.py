type JSONData = None | bool | int | float | str | list[JSONData] | dict[str, JSONData]
