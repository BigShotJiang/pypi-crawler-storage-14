# Documentação da pyontl

## Visão Geral

A `pyontl` é uma biblioteca Python para acesso facilitado aos dados da
Observatório Nacional de Transporte e Logística (ONTL).

## Instalação

```bash
# Instalação via pip
pip install pyontl

# Instalação para desenvolvimento
git clone https://github.com/DevSciHub/pyontl.git
cd pyontl
pip install -e .