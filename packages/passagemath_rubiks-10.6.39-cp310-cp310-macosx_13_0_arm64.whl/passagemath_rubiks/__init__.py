# sage_setup: distribution = sagemath-rubiks

from sage.all__sagemath_rubiks import *
