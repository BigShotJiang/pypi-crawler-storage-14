"""Convert PDF to structured text using MistralOCR"""
__version__ = "0.5.70"
