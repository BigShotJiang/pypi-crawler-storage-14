__version__ = "v2.2.0"
default_app_config = "azbankgateways.apps.AZIranianBankGatewaysConfig"
