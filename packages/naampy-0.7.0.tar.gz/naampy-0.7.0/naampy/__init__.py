from .in_rolls_fn import InRollsFnData, in_rolls_fn_gender, predict_fn_gender

__all__ = ["in_rolls_fn_gender", "predict_fn_gender", "InRollsFnData"]
