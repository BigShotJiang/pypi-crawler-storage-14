#!/user/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2024 Galaxy Technologies
Licensed under the Apache License, Version 2.0
"""
from .timeutils import *
from .calendars import *

__all__ = ['global_evaluation_date', 'set_evaluation_date', 'get_last_business_date', 'CN_CALENDAR', 'Schedule',
           'BusinessConvention', 'MonthAdjustment', 'EndOfMonthModify', 'AnnualDays']


def get_last_business_date(trade_calendar=CN_CALENDAR):
    """获取默认估值日期: 最近一个交易日"""
    today = datetime.datetime.now().date()
    if trade_calendar.isholiday(today):
        evaluationDate = trade_calendar.advance(today, datetime.timedelta(days=-1))
    else:
        evaluationDate = today
    return evaluationDate


# 估值日期全局变量
__EvaluationDate = get_last_business_date()


def set_evaluation_date(date: datetime.date):
    """设置估值日期"""
    if isinstance(date, datetime.datetime):
        date = date.date()
    elif not isinstance(date, datetime.date):
        raise ValueError(f"set_evaluation_date输入值不是date或datetime!")
    global __EvaluationDate
    __EvaluationDate = date


def global_evaluation_date():
    """获取估值日期"""
    return __EvaluationDate
