#!/user/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2024 Galaxy Technologies
Licensed under the Apache License, Version 2.0
"""
import numpy as np
from pricelib.common.utilities.enums import StatusType, ExerciseType
from pricelib.common.date_handler import CN_CALENDAR, AnnualDays
from .autocallable_base import PhoenixBase_OLD
from pricelib.pricing_engines.fdm_engines.fdm_autocallable_engine import FdmPhoenixEngine_OLD
from pricelib.pricing_engines.integral_engines import QuadFCNEngine
from pricelib.pricing_engines.mc_engines import MCPhoenixEngine_OLD
from .phoenix_base import PhoenixBase


class DCN_OLD(PhoenixBase_OLD):
    """DCN(Dynamic Coupon Note 动态票息票据)产品类
    有派息价格，每个观察日如果价格高于派息价格，派固定利息；到期日观察是否敲入"""
    in_obs_type = ExerciseType.European

    def __init__(self, s0, barrier_out, barrier_in, coupon, barrier_yield=None, obs_dates=None, pay_dates=None,
                 strike_upper=None, lock_term=1, parti_in=1, margin_lvl=1, status=StatusType.NoTouch, div_history=None,
                 engine=None, maturity=None, start_date=None, end_date=None,
                 trade_calendar=CN_CALENDAR, annual_days=AnnualDays.N365, t_step_per_year=243,
                 stoch_process=None, s=None, r=None, q=None, vol=None, engine_method=None):
        """构造函数
        Args:
            s0: float，标的初始价格
            barrier_out: float，敲出障碍价，绝对值/百分比
            barrier_in: float，敲入障碍价，绝对值/百分比，到期日观察是否敲入
            coupon: float，派息票息，百分比，非年化
            barrier_yield: float，派息边界价格，绝对值/百分比
            strike_upper: float，敲入发生(熊市价差)的高行权价，即DCN敲入发生后的折价减仓价，一般为敲入价
            lock_term: int，锁定期，单位为月，锁定期内不触发敲出
            parti_in: float，敲入后参与率，限损
            margin_lvl: float，保证金比例，默认为1，即无杠杆
            status: 敲出状态，StatusType枚举类，默认为NoTouch未敲出，UpTouch为已敲出。由于DCN到期观察敲入，不可能已敲入
            div_history: List[datetime.date]，历史派息列表，记录已经发生派息的观察日obs_date
        时间参数: 要么输入年化期限，要么输入起始日和到期日；敲出观察日和票息支付日可缺省
            maturity: float，年化期限
            start_date: datetime.date，起始日
            end_date: datetime.date，到期日
            obs_dates: List[datetime.date]，敲出观察日，可缺省，缺省时会自动生成每月观察的敲出日期序列(已根据节假日调整)
            pay_dates: List[datetime.date]，票息支付日，可缺省，缺省时会自动生成每月观察的派息日期序列(已根据节假日调整)
            trade_calendar: 交易日历，Calendar类，默认为中国内地交易日历
            annual_days: int，每年的自然日数量
            t_step_per_year: int，每年的交易日数量
        可选参数:
            engine: 定价引擎，PricingEngine类
                        蒙特卡洛: MCPhoenixEngine
                        PDE: FdmPhoenixEngine
                        积分法: QuadFCNEngine
            engine_method: str, 定价引擎种类。若未输入engine，可以用engine_method快捷生成指定定价引擎。可选MC/MonteCarlo、PDE/FDM、QUAD。
            若未提供引擎engine、也未指定引擎种类engine_method的情况下，如果提供了标的价格、无风险利率、分红/融券率、波动率，
            则默认使用 PDE 定价引擎 FdmPhoenixEngine
            s: float，标的价格
            r: float，无风险利率
            q: float，分红/融券率
            vol: float，波动率
        """
        super().__init__(s0=s0, maturity=maturity, start_date=start_date, end_date=end_date, lock_term=lock_term,
                         trade_calendar=trade_calendar, obs_dates=obs_dates, pay_dates=pay_dates, status=status,
                         annual_days=annual_days, parti_in=parti_in, margin_lvl=margin_lvl,
                         t_step_per_year=t_step_per_year, div_history=div_history)
        len_pay_dates = len(self.pay_dates.date_schedule)
        # todo: 区分敲出观察日和付息观察日，以及敲出支付日和付息日
        # obs_dates无锁定期，因为迭代过程中paydates和barrier in的改变都发生在敲出日obs_dates，锁定期靠敲出价+inf实现

        self.lock_term = lock_term  # 锁定期
        # 锁定期敲出价格 为+inf
        self.barrier_out = np.ones(len_pay_dates) * barrier_out
        self.barrier_out[:(lock_term - 1)] = np.inf
        # DCN只有期末观察敲入
        self.barrier_in = np.zeros(len_pay_dates)
        self.barrier_in[-1] = barrier_in
        # DCN，默认派息价等于敲入价
        self.barrier_yield = np.ones(len_pay_dates) * barrier_yield if barrier_yield is not None else self.barrier_in
        self.coupon = np.ones(len_pay_dates) * coupon
        self.strike_upper = barrier_in if strike_upper is None else strike_upper
        self.strike_lower = 0
        if engine is not None:
            self.set_pricing_engine(engine)
        else:
            if engine_method is None:
                default_engine = QuadFCNEngine  # 默认定价引擎
            elif engine_method in ["PDE", "FDM"]:
                default_engine = FdmPhoenixEngine_OLD
            elif engine_method in ["MC", "MonteCarlo"]:
                default_engine = MCPhoenixEngine_OLD
            elif engine_method == "QUAD":
                default_engine = QuadFCNEngine
            else:
                raise NotImplementedError(
                    f"不支持的engine_method{engine_method}, 凤凰仅支持MC/PDE; FCN、DCN仅支持MC/PDE/QUAD")
            if stoch_process is not None:
                self.set_pricing_engine(default_engine(stoch_process))
            elif s is not None and r is not None and q is not None and vol is not None:
                self.set_pricing_engine(default_engine(s=s, r=r, q=q, vol=vol))

    def __repr__(self):
        """返回期权的描述"""
        return "DCN(Dynamic Coupon Note 动态票息票据)"


class DCN(PhoenixBase):
    """DCN(Dynamic Coupon Note, 动态票息票据)产品类
    有派息价格，每个观察日如果价格高于派息价格，派固定利息；到期日观察是否敲入"""

    def __init__(self, s0, barrier_out, barrier_in, coupon, barrier_yield=None, obs_dates=None,
                 pay_dates=None, div_obs_dates=None, strike_upper=None, strike_lower=0, lock_term=None, parti_in=1,
                 margin_lvl=1, status=StatusType.NoTouch, engine=None, maturity=None, start_date=None, end_date=None,
                 trade_calendar=CN_CALENDAR, annual_days=AnnualDays.N365, t_step_per_year=243,
                 stoch_process=None, s=None, r=None, q=None, vol=None, engine_method=None):
        """构造函数
        Args:
            s0: float，标的初始价格
            barrier_out: float，敲出障碍价，绝对值/百分比，长度需要与敲出观察日数一致
            barrier_yield: float，派息边界价格，绝对值/百分比，长度需要与派息观察日数一致
            barrier_in: float，敲入障碍价，绝对值/百分比
            coupon: float，派息票息，百分比，非年化
            lock_term: int，锁定期，单位为月，锁定期内不触发敲出
            parti_in: float，敲入后参与率，限损
            margin_lvl: float，保证金比例，默认为1，即无杠杆
            strike_upper: float，敲入发生后(熊市价差)的高行权价，即OTM行权价(<s0)，普通凤凰敲入发生后的高行权价为期初价格s0
            strike_lower: float，敲入发生后(熊市价差)的低行权价，即保底边界，越高提供的保护越多，值为0时不保底
            status: 敲入敲出状态，StatusType枚举类，默认为NoTouch未敲入未敲出，UpTouch为已敲出
        时间参数: 要么输入年化期限，要么输入起始日和到期日；敲出观察日和票息支付日可缺省
            maturity: float，年化期限
            start_date: datetime.date，起始日
            end_date: datetime.date，到期日
            obs_dates: List[datetime.date]，敲出观察日，可缺省，缺省时会自动生成每月观察的敲出日期序列(已根据节假日调整)
            pay_dates: List[datetime.date]，票息支付日，可缺省，长度需要与敲出观察日数一致，如不指定则默认为敲出观察日
            div_obs_dates: List[datetime.date]，派息观察日，可缺省，缺省时会自动生成每月观察的敲出观察日期序列（已根据节假日调整）
            trade_calendar: 交易日历，Calendar类，默认为中国内地交易日历
            annual_days: int，每年的自然日数量
            t_step_per_year: int，每年的交易日数量
        可选参数:
            engine: 定价引擎，PricingEngine类
                    蒙特卡洛: MCPhoenixEngine
                    PDE: FdmPhoenixEngine
                    积分法: QuadPhoenixEngine
            engine_method: str, 定价引擎种类。若未输入engine，可以用engine_method快捷生成指定定价引擎。可选MC/MonteCarlo、PDE/FDM
            若未提供引擎engine、也未指定引擎种类engine_method的情况下，如果提供了 随机过程 或 标的价格、无风险利率、分红/融券率、波动率，
            则默认使用Quad定价引擎 QuadPhoenixEngine
            stoch_process: 随机过程StochProcessBase对象
            s: float，标的价格
            r: float，无风险利率
            q: float，分红/融券率
            vol: float，波动率
        """
        super().__init__(in_obs_type=ExerciseType.European,  # 到期观察敲入(欧式)
                         s0=s0, barrier_out=barrier_out, barrier_in=barrier_in, barrier_yield=barrier_yield,
                         coupon=coupon, strike_upper=strike_upper, strike_lower=strike_lower,
                         maturity=maturity, start_date=start_date, end_date=end_date, lock_term=lock_term,
                         trade_calendar=trade_calendar, obs_dates=obs_dates, pay_dates=pay_dates, status=status,
                         div_obs_dates=div_obs_dates, annual_days=annual_days, parti_in=parti_in, margin_lvl=margin_lvl,
                         t_step_per_year=t_step_per_year, engine=engine, stoch_process=stoch_process,
                         s=s, r=r, q=q, vol=vol, engine_method=engine_method)

    def __repr__(self):
        """返回期权的描述"""
        return "DCN(Dynamic Coupon Note 动态票息票据)"


