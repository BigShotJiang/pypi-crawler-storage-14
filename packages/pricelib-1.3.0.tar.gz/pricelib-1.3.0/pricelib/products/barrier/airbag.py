#!/user/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2024 Galaxy Technologies
Licensed under the Apache License, Version 2.0
"""
import datetime
from contextlib import suppress
from pricelib.common.utilities.enums import CallPut, InOut, UpDown, ExerciseType, EngineType, PaymentType, StatusType
from pricelib.common.date_handler import CN_CALENDAR, AnnualDays, global_evaluation_date
from pricelib.common.utilities.patterns import Observer, global_auto_update_status
from pricelib.common.utilities.utility import time_this, logging
from pricelib.common.product_base.option_base import OptionBase
from pricelib.pricing_engines.analytic_engines.analytic_airbag_engine import AnalyticAirbagEngine
from pricelib.pricing_engines.fdm_engines import FdmAirbagEngine
from pricelib.pricing_engines.mc_engines import MCAirbagEngine


class Airbag(OptionBase, Observer):
    """安全气囊
    安全气囊是美式观察向下敲入看涨期权，到期支付
        敲入前是call，执行价等于合约设立时的标的期初价格
        敲入后payoff与持有标的资产相同(在上涨和下跌参与率为1的情况下)"""
    updown = UpDown.Down
    inout = InOut.In
    callput = CallPut.Call
    payment_type = PaymentType.Expire
    obs_type = ExerciseType.American

    def __init__(self, strike, barrier, *, knockin_parti=1, call_parti=0.8, reset_call_parti=1, engine=None,
                 status=StatusType.NoTouch, maturity=None, start_date=None, end_date=None,
                 init_strike_cap=None, in_strike_cap=None, in_strike_floor=None, discrete_obs_interval=None,
                 floor_yield=0., trade_calendar=CN_CALENDAR, annual_days=AnnualDays.N365, t_step_per_year=243,
                 stoch_process=None, s0=None, s=None, r=None, q=None, vol=None, engine_method=None):
        """构造函数  todo: 保底收益率，敲入前封顶收益率，敲入后封顶收益率
        产品参数:
            s0:  float, 标的期初价格
            strike:  float, 执行价
            barrier:  float, 敲入障碍价格
            init_strike_cap:  float, 敲入前封顶价格
            in_strike_cap:  float, 敲入后封顶价格
            in_strike_floor:  float, 敲入后封底价格（保底）
            knockin_parti: float, 敲入的下跌参与率
            call_parti: float, 未敲入的看涨参与率
            reset_call_parti: float, 敲入的重置后看涨参与率
            floor_yield: float, 额外的保底收益率，年化收益，百分比小数
            status: 敲入状态，StatusType枚举类，默认为NoTouch未敲入，DownTouch为已敲入
        时间参数: 要么输入年化期限，要么输入起始日和到期日
            maturity: float，年化期限
            start_date: datetime.date，起始日
            end_date: datetime.date，到期日
            trade_calendar: 交易日历，Calendar类，默认为中国内地交易日历
            annual_days: int，每年的自然日数量
            t_step_per_year: int，每年的交易日数量
            discrete_obs_interval: 观察时间间隔. 若为连续观察，None；若为均匀离散观察，为年化的观察时间间隔
        可选参数:
            engine: 定价引擎，PricingEngine类
                    解析解: AnalyticAirbagEngine 由障碍与二元解析解(资产或无)组合而成，所以敲入的下跌参与率与重置后看涨参与率必须相等。
                                                支持连续观察/离散观察(默认为每日观察)
                    PDE: FdmAirbagEngine 支持连续观察/离散观察(默认为每日观察)
                    蒙特卡洛: MCAirbagEngine 只支持离散观察(默认为每日观察)
            engine_method: str, 定价引擎种类。若未输入engine，可以用engine_method快捷生成指定定价引擎。可选Analytic、MC/MonteCarlo、PDE/FDM。
            若未提供引擎engine、也未指定引擎种类engine_method的情况下，如果提供了 随机过程 或 标的价格、无风险利率、分红/融券率、波动率，
            若敲入前后的上涨参与率相等，则使用解析解定价引擎AnalyticAirbagEngine，其他情况则默认使用 PDE 定价引擎 FdmAirbagEngine
            stoch_process: 随机过程StochProcessBase对象
            s: float，标的价格
            r: float，无风险利率
            q: float，分红/融券率
            vol: float，波动率
        """
        super().__init__()
        self.trade_calendar = trade_calendar
        self.annual_days = annual_days
        self.t_step_per_year = t_step_per_year
        assert maturity is not None or (start_date is not None and end_date is not None), "Error: 到期时间或起止时间必须输入一个"
        self.start_date = start_date if start_date is not None else global_evaluation_date()  # 起始时间
        self.end_date = end_date if end_date is not None else (
                self.start_date + datetime.timedelta(days=round(maturity * annual_days.value)))  # 结束时间
        if self.trade_calendar.isholiday(self.end_date):  # 如果到期日不是交易日，向后顺延一个交易日
            self.end_date = self.trade_calendar.advance(self.end_date, datetime.timedelta(days=1))
        self.maturity = maturity if maturity is not None else (self.end_date - self.start_date).days / annual_days.value
        self.strike = strike
        self.barrier = barrier
        self.knockin_parti = knockin_parti
        self.call_parti = call_parti
        self.reset_call_parti = reset_call_parti
        self.init_strike_cap = init_strike_cap
        self.in_strike_cap = in_strike_cap
        self.in_strike_floor = in_strike_floor
        self.floor_yield = floor_yield
        self.s0 = s0
        self.discrete_obs_interval = discrete_obs_interval  # 连续观察=None；均匀离散观察=观察时间间隔
        self.status = status
        if engine is not None:
            self.set_pricing_engine(engine)
        else:
            if engine_method is None:
                if knockin_parti == reset_call_parti:
                    default_engine = AnalyticAirbagEngine
                else:
                    default_engine = FdmAirbagEngine
            elif engine_method == "Analytic":
                default_engine = AnalyticAirbagEngine
            elif engine_method in ["PDE", "FDM"]:
                default_engine = FdmAirbagEngine
            elif engine_method in ["MC", "MonteCarlo"]:
                default_engine = MCAirbagEngine
            else:
                raise NotImplementedError(
                    f"不支持的engine_method{engine_method}, {self.__repr__()}仅支持Analytic/MC/PDE")
            if stoch_process is not None:
                self.set_pricing_engine(default_engine(stoch_process))
            elif s is not None and r is not None and q is not None and vol is not None:
                self.set_pricing_engine(default_engine(s=s, r=r, q=q, vol=vol))

    def set_pricing_engine(self, engine):
        """设置定价引擎，同时将自己注册为观察者。若已有定价引擎，先将自己从原定价引擎的观察者列表中移除"""
        with suppress(AttributeError, ValueError):
            self.engine.process.spot.remove_observer(self)
        self.engine = engine
        self.engine.process.spot.add_observer(self)
        logging.info(f"{self}当前定价方法为{engine.engine_type.value}")

    def remove_self(self):
        """删除对象自己，del自己之前，先将自己从被观察者的列表中移除"""
        self.engine.process.spot.remove_observer(self)
        del self

    def update(self, observable, *args, **kwargs):
        """收到标的价格变化的通知时，自动更新是否已经触碰障碍，默认每日观察"""
        if global_evaluation_date() > self.end_date:  # 如果估值日已经过了到期日，维持原来的状态
            return
        if global_auto_update_status() and observable == self.engine.process.spot:
            if observable.data <= self.barrier:
                self.status = StatusType.DownTouch

    def __repr__(self):
        """返回期权的描述"""
        return "安全气囊"

    @time_this
    def price(self, t=None, spot=None):
        self.validate_parameters(t=t)
        if self.engine.engine_type == EngineType.PdeEngine:  # 接口特殊是因为PDE引擎兼容了单双边障碍
            price = self.engine.calc_present_value(prod=self, t=t, spot=spot, bound=(self.barrier, None),
                                                   rebate=(0, 0))
        else:
            price = self.engine.calc_present_value(prod=self, t=t, spot=spot)
        return price
