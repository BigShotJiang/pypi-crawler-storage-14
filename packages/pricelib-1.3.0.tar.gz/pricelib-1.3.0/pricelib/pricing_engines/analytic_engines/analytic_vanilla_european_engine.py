#!/user/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2024 Galaxy Technologies
Licensed under the Apache License, Version 2.0
"""
import math
import numpy as np
from scipy.stats import norm
from pricelib.common.processes import StochProcessBase
from pricelib.common.utilities.enums import ExerciseType
from pricelib.common.date_handler import global_evaluation_date
from pricelib.common.pricing_engine_base.analytic_engine_base import AnalyticEngine, bs_d1, bs_formula


class AnalyticVanillaEuEngine(AnalyticEngine):
    """欧式期权BSM解析解定价引擎"""

    def __init__(self, stoch_process: StochProcessBase = None, *, s=None, r=None, q=None, vol=None):
        """构造函数
        Args:
            stoch_process: 随机过程StochProcessBase对象
        在未设置stoch_process时，(stoch_process=None)，会默认创建BSMprocess，需要输入以下变量进行初始化
            s: float，标的价格
            r: float，无风险利率
            q: float，分红/融券率
            vol: float，波动率
        """
        super().__init__(stoch_process=stoch_process, s=s, r=r, q=q, vol=vol)
        # 以下属性指向需要定价的产品，由calc_present_value方法设置
        self.prod = None

    def d1(self, tau, spot):
        """BSM公式d1"""
        d1_value = bs_d1(s=spot, k=self.prod.strike, t=tau, r=self.process.interest(tau), q=self.process.div(tau),
                         sigma=self.process.diffusion(tau, spot))
        return d1_value

    def d2(self, tau, spot):
        """BSM公式d2, d2 = d1 - sigma * sqrt(t)"""
        d2_value = self.d1(tau, spot) - self.process.diffusion(tau, spot) * np.sqrt(tau)
        return d2_value

    def calc_present_value(self, prod, t=None, spot=None):
        """计算现值
        Args:
            prod: Product产品对象
            t: datetime.date，估值日; 如果是None，则使用全局估值日globalEvaluationDate
            spot: float，估值日标的价格，如果是None，则使用随机过程的当前价格
        Returns: float，现值
        """
        assert prod.exercise_type == ExerciseType.European, "Error: 欧式期权解析解只支持European行权类型."
        self.prod = prod
        calculate_date = global_evaluation_date() if t is None else t
        tau = (prod.end_date - calculate_date).days / prod.annual_days.value
        if spot is None:
            spot = self.process.spot()

        price = bs_formula(s=spot, k=prod.strike, t=tau, sign=prod.callput.value, r=self.process.interest(tau),
                           q=self.process.div(tau), sigma=self.process.diffusion(tau, spot))
        return price * prod.parti

    def delta(self, prod, spot=None):
        """∂V/∂S"""
        self.prod = prod
        tau = (prod.end_date - global_evaluation_date()).days / prod.annual_days.value
        if spot is None:
            spot = self.process.spot()
        q = self.process.div(tau)
        delta = self.prod.callput.value * math.exp(-q * tau) * norm.cdf(self.prod.callput.value * self.d1(tau, spot))
        return delta * prod.parti

    def gamma(self, prod, spot=None):
        """∂2V/∂S2"""
        self.prod = prod
        tau = (prod.end_date - global_evaluation_date()).days / prod.annual_days.value
        if spot is None:
            spot = self.process.spot()
        q = self.process.div(tau)
        vol = self.process.vol(tau, spot)
        gamma = math.exp(-q * tau) * norm.pdf(self.d1(tau, spot)) / (spot * vol * np.sqrt(tau))
        return gamma * prod.parti

    def vega(self, prod, spot=None):
        """∂V/∂σ"""
        self.prod = prod
        tau = (prod.end_date - global_evaluation_date()).days / prod.annual_days.value
        if spot is None:
            spot = self.process.spot()
        q = self.process.div(tau)
        vega = math.exp(-q * tau) * spot * norm.pdf(self.d1(tau, spot)) * np.sqrt(tau)
        # 业内习惯把Vega理解为波动率变动1个百分点对应期权价值的变化量，所以根据BS公式计算出的vega还需再除以100
        return vega * 0.01 * prod.parti

    def rho(self, prod, spot=None):
        """∂V/∂r"""
        self.prod = prod
        tau = (prod.end_date - global_evaluation_date()).days / prod.annual_days.value
        if spot is None:
            spot = self.process.spot()
        r = self.process.interest(tau)
        rho = self.prod.callput.value * self.prod.strike * tau * np.exp(-r * tau) * norm.cdf(
            self.prod.callput.value * self.d2(tau, spot))
        # 业内习惯把Rho理解为波动率变动1个百分点对应期权价值的变化量，所以根据BS公式计算出的rho还需再除以100
        return rho * 0.01 * prod.parti

    def theta(self, prod, spot=None):
        """∂V/∂t
        注意，这里B-S公式的theta计算结果在周五或节假日的前一天计算时，与差分法有所不同。因为差分法是交易日+1天，这里是自然日+1天。"""
        self.prod = prod
        tau = (prod.end_date - global_evaluation_date()).days / prod.annual_days.value
        if spot is None:
            spot = self.process.spot()
        r = self.process.interest(tau)
        q = self.process.div(tau)
        vol = self.process.vol(tau, spot)
        sign = self.prod.callput.value
        theta = (-1 * spot * math.exp(-q * tau) * norm.pdf(self.d1(tau, spot)) * vol / (2 * np.sqrt(tau))
                 - sign * r * self.prod.strike * np.exp(-r * tau) * norm.cdf(sign * self.d2(tau, spot))
                 + sign * q * spot * np.exp(-q * tau) * norm.cdf(sign * self.d1(tau, spot)))
        # 业内习惯Theta用来衡量每日的time decay，而BS Model中的时间单位是年，所以按此公式算出来的Theta需要再除以365
        return (theta / prod.annual_days.value) * prod.parti

    def pv_and_greeks(self, prod, spot=None):
        """当一次性计算pv和5个greeks时，可以调用此函数
        Args:
            prod: Product，产品对象
            spot: float，价格的绝对值
        Returns:
            Dict[str:float]: {'pv': pv, 'delta': delta, 'gamma': gamma, 'theta': theta, 'vega': vega, 'rho': rho}
        """

        return {'pv': self.calc_present_value(prod, spot=spot),
                'delta': self.delta(prod, spot=spot),
                'gamma': self.gamma(prod, spot=spot),
                'vega': self.vega(prod, spot=spot),
                'theta': self.theta(prod, spot=spot),
                'rho': self.rho(prod, spot=spot)}
