#!/user/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2024 Galaxy Technologies
Licensed under the Apache License, Version 2.0
"""
import numpy as np
from pricelib.common.utilities.enums import InOut, PaymentType, ExerciseType
from .fdm_barrier_engine import FdmBarrierEngine


class FdmDoubleSharkEngine(FdmBarrierEngine):
    """双鲨结构PDE有限差分法定价引擎"""
    inout = InOut.Out  # 双鲨结构属于敲出期权

    def _init_boundary_condition(self, smax, maturity, elapsed_time):
        """初始化边界条件
        双鲨结构，上方边界条件是call，下方边界条件是put
        Args:
            smax: float, 有限差分网格上边界的价格最大值
            maturity: float, 到期时间
            elapsed_time: float, 已过时间（从起始日到估值日）
        Returns:
            self.fn_callput: List[Callable], 0~smax网格的边界条件
            self.fn_bound: List[Callable], 障碍价格网格的边界条件
        """
        prod = self.prod
        # floor_yield: float, 保底收益率，默认为0。保底收益绝对数值 = 保底收益率 * s0 * 存续期
        # 生成无障碍价格的边界条件：在s=0处，call近似为0; 在smax处，put近似为0。根据看涨看跌平价 call-put = S*exp(-qT) - K*exp(-rT),
        # 可得对应的put(0) = K * exp(-rT), call(smax) = smax * exp(-qT) - K * exp(-rT)
        if prod.floor_yield == 0:
            self.fn_callput = [
                lambda u: (self.prod.strike[0] * self.process.interest.disc_factor(maturity, u)) * self.prod.parti[0],
                lambda u: (smax * self.process.div.disc_factor(maturity, u) -
                           self.prod.strike[1] * self.process.interest.disc_factor(maturity, u)) * self.prod.parti[1]]
        else:
            self.fn_callput = [  # u是估值日开始的年化时间，不是起始日开始的
                lambda u: (self.prod.strike[0] * self.prod.parti[0] + prod.floor_yield * prod.s0 * (elapsed_time + u)
                           ) * self.process.interest.disc_factor(maturity, u),
                lambda u: (smax * self.process.div.disc_factor(maturity, u) * self.prod.parti[1] +
                           (prod.floor_yield * prod.s0 * (elapsed_time + u) - self.prod.strike[1] * self.prod.parti[1]
                            ) * self.process.interest.disc_factor(maturity, u))]
        # 生成障碍价格的Dirichlet边界条件： 第u天触碰障碍产生的补偿，折现到第u天的价值。
        # 返回一个包含两个lambda函数的列表，列表索引分别为[0, 1]，每个lambda函数的形参r=self.rebate中的r补偿值
        # 需要注意的是，敲出期权rebate[0]是下边界补偿，敲出期权rebate[1]是上边界补偿；敲入期权rebate[0]是敲入补偿，敲入期权rebate[1]没有用处。
        self.fn_bound = []
        for r in self.rebate:
            if self.prod.payment_type == PaymentType.Hit:  # 触碰障碍立即支付
                if prod.rebate_annual:  # 年化现金返还
                    self.fn_bound.append(lambda u: r * prod.s0 * (elapsed_time + u))  # u是估值日开始的年化时间，不是起始日开始的
                else:  # 绝对数值现金返还
                    self.fn_bound.append(lambda u: r)
            elif prod.payment_type == PaymentType.Expire:  # 触碰障碍后，到期时支付现金补偿
                if prod.rebate_annual:  # 年化现金返还
                    self.fn_bound.append(lambda u: r * prod.s0 * (elapsed_time + maturity)
                                                   * self.process.interest.disc_factor(maturity, u))
                else:  # 绝对数值现金返还
                    self.fn_bound.append(lambda u: r * self.process.interest.disc_factor(maturity, u))
            else:
                raise ValueError("payment type must be Hit or Expire, not {}".format(prod.payment_type))

    def _init_terminal_condition(self, s_vec, maturity, elapsed_time, _floor_yield=0.):
        """初始化终止条件
        双鲨结构，上方是call，下方是put"""
        prod = self.prod
        call_put_payoff = (np.maximum(s_vec - self.prod.strike[1], 0) * self.prod.parti[1] +
              np.maximum(self.prod.strike[0] - s_vec, 0) * self.prod.parti[0] + _floor_yield)
        if prod.obs_type == ExerciseType.American and prod.discrete_obs_interval is None:  # 连续观察
            return call_put_payoff  # 已敲入/未敲出 都是香草
        else:  # 离散观察/到期观察  # 未敲出香草，已敲出rebate
            if prod.rebate_annual:  # 年化现金返还
                yv = np.where(s_vec >= self.bound[1], self.rebate[1] * prod.s0 * (elapsed_time + maturity),
                              np.where(s_vec <= self.bound[0], self.rebate[0] * prod.s0 * (elapsed_time + maturity)
                                       , call_put_payoff))
            else:  # 绝对数值现金返还
                yv = np.where(s_vec >= self.bound[1], self.rebate[1],
                              np.where(s_vec <= self.bound[0], self.rebate[0], call_put_payoff))
            return yv
