"""Answer decoding module for BrowseComp."""

from .browsecomp_answer_decoder import BrowseCompAnswerDecoder

__all__ = ["BrowseCompAnswerDecoder"]
