"""API Tests for Local Deep Research."""
