import pyqtgraph as pg


class Plot(pg.PlotWidget):
    pass
