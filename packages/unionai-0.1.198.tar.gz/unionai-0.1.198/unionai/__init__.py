"""Previous unionai SDK."""

import warnings as _warnings

_warnings.warn(
    "unionai is deprecated, use union instead: `pip install union`",
    FutureWarning,
    stacklevel=2,
)
