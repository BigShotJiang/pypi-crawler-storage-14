"""Tests for CLI bootstrap module."""
