"""Main entry point for the Amazon Ads MCP server."""

from .mcp_server import main

if __name__ == "__main__":
    main()
