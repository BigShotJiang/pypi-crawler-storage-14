"""Amazon Ads API MCP server module.

This module contains the Model Context Protocol (MCP) server implementation
for the Amazon Ads API, including server creation, tool registration,
and request handling.
"""
