"""Utility functions for Amazon Ads API MCP server.

This module provides utility functions and classes for the Amazon Ads
MCP server, including OpenAPI specification handling and other
helper functionality.
"""
