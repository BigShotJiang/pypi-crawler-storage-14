from . import units as _u

pi = _u.twopi / 2.0
twopi = _u.twopi
G = 1 * (_u.au**3 / _u.solMass / _u.yr2pi**2)
