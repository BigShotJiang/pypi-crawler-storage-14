"""Tests for Asynchronous Python client for the Fressnapf Tracker GPS API."""
