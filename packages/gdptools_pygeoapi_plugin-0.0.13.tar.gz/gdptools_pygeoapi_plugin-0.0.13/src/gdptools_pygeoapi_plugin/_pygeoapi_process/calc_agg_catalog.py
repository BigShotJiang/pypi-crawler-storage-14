"""Calc_weights_catalog_proceess."""

import json
import logging
from typing import Any
from typing import Dict
from typing import Tuple

import geopandas as gpd
import pandas as pd
from gdptools import AggGen
from gdptools import ClimRCatData
from pygeoapi.process.base import BaseProcessor

from ._validators import ensure_feature_collection
from ._validators import parse_iso_date
from ._validators import parse_json_object
from ._validators import ProcessorException
from ._validators import require_field

# import tempfile
# from pathlib import Path

LOGGER = logging.getLogger(__name__)

PROCESS_METADATA = {
    "version": "0.1.0",
    "id": "calc_agg_catalog",
    "title": "Run area-weighted aggregation",
    "description": (
        "Apply gdptools aggregation to user polygons using a remote OpenDAP "
        "catalog definition and pre-computed weights."
    ),
    "jobControlOptions": ["sync-execute", "async-execute"],
    "keywords": ["area-weighted intersections", "gdptools", "aggregation"],
    "links": [
        {
            "type": "text/html",
            "rel": "about",
            "title": "Project documentation",
            "href": "https://gdptools-pygeoapi-plugin.readthedocs.io/en/latest/usage.html#calc-agg-catalog-process",
            "hreflang": "en",
        }
    ],
    "inputs": {
        "cat_dict": {
            "title": "Catalog definition",
            "description": "Same JSON fragment used to build ClimRCatData (see example).",
            "schema": {
                "type": "string",
                "contentMediaType": "application/json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "weights": {
            "title": "Weight table",
            "description": "JSON-exported DataFrame produced by calc_weights_catalog.",
            "schema": {
                "type": "string",
                "contentMediaType": "application/json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_file": {
            "title": "Feature collection",
            "description": "GeoJSON FeatureCollection for the polygon(s) being aggregated.",
            "schema": {
                "type": "string",
                "contentMediaType": "application/geo+json",
            },
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_crs": {
            "title": "Feature CRS",
            "description": "EPSG code or proj string describing the feature CRS.",
            "schema": {"type": "string"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "shape_poly_idx": {
            "title": "Feature identifier field",
            "description": "Name of the column containing the polygon identifier.",
            "schema": {"type": "string"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "start_date": {
            "title": "Start date",
            "description": "Beginning of the aggregation window (YYYY-MM-DD).",
            "schema": {"type": "string", "format": "date"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
        "end_date": {
            "title": "End date",
            "description": "End of the aggregation window (YYYY-MM-DD).",
            "schema": {"type": "string", "format": "date"},
            "minOccurs": 1,
            "maxOccurs": 1,
        },
    },
    "outputs": {
        "aggregated_json": {
            "title": "Aggregated result",
            "description": "JSON records (time, varname, units, polygon columns).",
            "schema": {"type": "object", "contentMediaType": "application/json"},
        }
    },
    "example": {
        "inputs": {
            "cat_dict": (
                '{"aet": {"id": "terraclim", "asset": '
                '"agg_terraclimate_aet_1958_CurrentYear_GLOBE", "URL": '
                '"http://thredds.northwestknowledge.net:8080/thredds/dodsC/agg_terraclimate_aet_1958_CurrentYear_GLOBE.nc", '  # noqa: B950
                '"type": "opendap", "varname": "aet", "variable": "aet", "description": '
                '"water_evaporation_amount", "units": "mm", "model": null, "ensemble": null, '
                '"scenario": "total", "T_name": "time", "duration": "1958-01-01/2021-12-01", '
                '"interval": "1 months", "nT": 768.0, "X_name": "lon", "Y_name": "lat", "X1": '
                '-179.97916666666666, "Xn": 179.97916666666666, "Y1": 89.97916666666667, '
                '"Yn": -89.97916666666664, "resX": 0.041666666666666664, "resY": '
                '0.041666666666666664, "ncols": 8640.0, "nrows": 4320.0, "crs": '
                '"+proj=longlat +a=6378137 +f=0.00335281066474748 +pm=0 +no_defs", '
                '"toptobottom": false, "tiled": ""}, "pet": {"id": "terraclim", "asset": '
                '"agg_terraclimate_pet_1958_CurrentYear_GLOBE", "URL": '
                '"http://thredds.northwestknowledge.net:8080/thredds/dodsC/agg_terraclimate_pet_1958_CurrentYear_GLOBE.nc", '  # noqa: B950
                '"type": "opendap", "varname": "pet", "variable": "pet", "description": '
                '"water_potential_evaporation_amount", "units": "mm", "model": null, '
                '"ensemble": null, "scenario": "total", "T_name": "time", "duration": '
                '"1958-01-01/2021-12-01", "interval": "1 months", "nT": 768.0, "X_name": '
                '"lon", "Y_name": "lat", "X1": -179.97916666666666, "Xn": 179.97916666666666, '
                '"Y1": 89.97916666666667, "Yn": -89.97916666666664, "resX": '
                '0.041666666666666664, "resY": 0.041666666666666664, "ncols": 8640.0, '
                '"nrows": 4320.0, "crs": "+proj=longlat +a=6378137 +f=0.00335281066474748 '
                '+pm=0 +no_defs", "toptobottom": false, "tiled": ""}}'
            ),
            "weights": (
                '{"i":{"0":2,"1":1,"2":2,"3":1},'
                '"index":{"0":0,"1":1,"2":2,"3":3},'
                '"j":{"0":3,"1":3,"2":2,"3":2},'
                '"poly_idx":{"0":"1","1":"1","2":"1","3":"1"},'
                '"wght":{'
                '"0":0.138616567,"1":0.001795472,"2":0.7689606915,"3":0.0906272694}}'
            ),
            "shape_file": (
                '{"type": "FeatureCollection", "features": ['
                '{"id": "0", "type": "Feature", "properties": {'
                '"id": 1, "poly_idx": "1"}, "geometry": {'
                '"type": "Polygon", "coordinates": [['
                "[-70.60141212297273, 41.9262774500321], "
                "[-70.57199544021768, 41.91303994279233], "
                "[-70.5867037815952, 41.87626908934851], "
                "[-70.61906213262577, 41.889506596588284], "
                "[-70.60141212297273, 41.9262774500321]"
                "]]}}]}"
            ),
            "shape_crs": "4326",
            "shape_poly_idx": "poly_idx",
            "start_date": "1980-01-01",
            "end_date": "1980-12-31",
        }
    },
}


class GDPCalcAggCatalogProcessor(BaseProcessor):  # type: ignore
    """Run area-weighted grid-to-poly aggregation."""

    def __init__(self, processor_def: dict[str, Any]):
        """Initialize Processor.

        Args:
            processor_def (_type_): _description_
        """
        super().__init__(processor_def, PROCESS_METADATA)

    def execute(self, data: Dict[str, Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
        """Execute run_weights_catalog web service."""
        cat_dict = parse_json_object(require_field(data, "cat_dict"), "cat_dict")
        weights_payload = parse_json_object(require_field(data, "weights"), "weights")
        shp_geojson = ensure_feature_collection(
            parse_json_object(require_field(data, "shape_file"), "shape_file"),
            "shape_file",
        )
        shp_crs = str(require_field(data, "shape_crs")).strip()
        shp_poly_idx = str(require_field(data, "shape_poly_idx")).strip()
        start_date = parse_iso_date(require_field(data, "start_date"), "start_date")
        end_date = parse_iso_date(require_field(data, "end_date"), "end_date")
        period = [start_date, end_date]

        if not shp_crs:
            raise ProcessorException("Input 'shape_crs' must be a non-empty string")
        if not shp_poly_idx:
            raise ProcessorException(
                "Input 'shape_poly_idx' must be a non-empty string"
            )

        weights = pd.DataFrame.from_dict(weights_payload)
        if weights.empty:
            raise ProcessorException("Input 'weights' produced an empty table")

        shp_file = gpd.GeoDataFrame.from_features(shp_geojson)
        shp_file.set_crs(shp_crs, inplace=True)
        if shp_poly_idx not in shp_file.columns:
            raise ProcessorException(
                f"Column '{shp_poly_idx}' not found in uploaded feature collection"
            )

        LOGGER.info(f"cat_dict: {cat_dict}  type: {type(cat_dict)}\n")
        LOGGER.info(f"weights: {weights.head()} type: {type(weights)}\n")
        LOGGER.info(f"shp_file: {shp_file.head()} type: {type(shp_file)}\n")
        LOGGER.info(f"shp_poly_idx: {shp_poly_idx} type: {type(shp_poly_idx)}\n")
        LOGGER.info(f"start_date: {start_date} type: {type(start_date)}\n")
        LOGGER.info(f"end_date: {end_date} type: {type(end_date)}\n")

        user_data = ClimRCatData(
            cat_dict=cat_dict,
            f_feature=shp_file,
            id_feature=shp_poly_idx,
            period=period,
        )
        # tempdir = tempfile.TemporaryDirectory()
        agg_gen = AggGen(
            user_data=user_data,
            stat_method="masked_mean",
            agg_engine="serial",
            agg_writer="none",
            weights=weights,
        )
        ngdf, nvals = agg_gen.calculate_agg()
        for idx, (_key, value) in enumerate(agg_gen.agg_data.items()):
            gdf = ngdf
            param_values = value.cat_cr
            t_coord = param_values.T_name
            units = param_values.units
            varname = param_values.varname
            time = value.da.coords[t_coord].values

            df_key = pd.DataFrame(data=nvals[_key].values, columns=gdf.index.T.values)

            df_key.insert(0, "units", [units] * df_key.shape[0])
            df_key.insert(0, "varname", [varname] * df_key.shape[0])
            df_key.insert(0, "time", time)

            if idx == 0:
                df = df_key
            else:
                df = pd.concat([df, df_key])
        df.reset_index(inplace=True)
        return "application/json", json.loads(
            df.to_json(date_format="iso", orient="index")
        )

    def __repr__(self):  # type: ignore
        """Return representation."""
        return f"<GDPCalcWeightsCatalogProcessor> {self.name}"
