# 角色类型
ROLE_VILLAGER = "villager"  # 村民
ROLE_WOLF = "wolf"  # 狼人
ROLE_SEER = "seer"  # 预言家
ROLE_WITCH = "witch"  # 女巫
ROLE_HUNTER = "hunter"  # 猎人
ROLE_GUARD = "guard"  # 守卫
ROLE_WOLF_KING = "wolf_king" # 狼王