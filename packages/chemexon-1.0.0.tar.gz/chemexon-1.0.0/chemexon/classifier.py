def classify_reaction(equation: str) -> str:
    """
    Classify the reaction type based on the equation.
    """
    if '->' not in equation:
        raise ValueError("Invalid equation")
    parts = equation.split('->')
    reactants_str = parts[0].strip()
    products_str = parts[1].strip()

    reactants = [comp.strip() for comp in reactants_str.split('+')]
    products = [comp.strip() for comp in products_str.split('+')]

    num_reactants = len(reactants)
    num_products = len(products)

    # Combustion: hydrocarbon + O2 -> CO2 + H2O
    if num_reactants == 2 and num_products >= 2:
        has_o2 = any('O2' in r for r in reactants)
        has_co2 = any('CO2' in p for p in products)
        has_h2o = any('H2O' in p for p in products)
        if has_o2 and has_co2 and has_h2o:
            return "combustion"

    # Synthesis: A + B -> AB
    if num_reactants == 2 and num_products == 1:
        return "synthesis"

    # Decomposition: AB -> A + B
    if num_reactants == 1 and num_products == 2:
        return "decomposition"

    # Single replacement: A + BC -> AC + B
    if num_reactants == 2 and num_products == 2:
        # Check if one reactant is element, one is compound, and products are element and compound
        from .parser import parse_chemical_formula
        reactant_elements = []
        reactant_compounds = []
        for r in reactants:
            atoms = parse_chemical_formula(r)
            if len(atoms) == 1:
                reactant_elements.append(r)
            else:
                reactant_compounds.append(r)
        product_elements = []
        product_compounds = []
        for p in products:
            atoms = parse_chemical_formula(p)
            if len(atoms) == 1:
                product_elements.append(p)
            else:
                product_compounds.append(p)
        if len(reactant_elements) == 1 and len(reactant_compounds) == 1 and len(product_elements) == 1 and len(product_compounds) == 1:
            return "single replacement"

    # Double replacement: AB + CD -> AD + CB
    if num_reactants == 2 and num_products == 2:
        # All are compounds
        from .parser import parse_chemical_formula
        all_compounds = all(len(parse_chemical_formula(comp)) > 1 for comp in reactants + products)
        if all_compounds:
            return "double replacement"

    # Acid-base: acid + base -> salt + water
    # Simplified: if has H2O in products and specific patterns
    if 'H2O' in products_str and num_reactants == 2 and num_products == 2:
        return "acid-base neutralization"

    return "unknown"