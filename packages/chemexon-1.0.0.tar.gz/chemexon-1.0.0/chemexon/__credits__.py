__project__ = "Chemexon Chemistry Toolkit"
__organization__ = "Codexon - Org"
__developers__ = ["ramkrishna-dev razzak (Co-Developer)"]
__license__ = "MIT License"
__year__ = "2025"