from typing import Dict
from .parser import parse_chemical_formula
from .elements import get_element

def calculate_molar_mass(formula: str) -> float:
    """
    Calculate molar mass from formula.
    """
    atoms = parse_chemical_formula(formula)
    mass = 0.0
    for element, count in atoms.items():
        el_data = get_element(element)
        if el_data:
            mass += el_data['atomic_mass'] * count
        else:
            raise ValueError(f"Unknown element: {element}")
    return round(mass, 3)