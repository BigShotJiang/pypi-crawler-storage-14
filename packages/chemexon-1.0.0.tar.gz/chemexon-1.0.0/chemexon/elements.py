import json
import os
from typing import Dict, List, Optional

_elements: Optional[Dict[str, Dict]] = None

def _load_periodic_table() -> Dict[str, Dict]:
    global _elements
    if _elements is None:
        path = os.path.join(os.path.dirname(__file__), 'data', 'periodic_table.json')
        with open(path, 'r') as f:
            data = json.load(f)
        _elements = {el['symbol']: el for el in data['elements']}
    return _elements

def list_elements() -> List[Dict]:
    """Return list of all elements."""
    elements = _load_periodic_table()
    return list(elements.values())

def get_element(symbol: str) -> Optional[Dict]:
    """Get element by symbol."""
    elements = _load_periodic_table()
    return elements.get(symbol.upper())