# Chemexon Chemistry Toolkit

A comprehensive Python package for chemistry calculations, built by **Codexon - Org**.

## Features

- Chemical equation balancing using matrix algebra
- Formula parsing with support for parentheses and hydrates
- Periodic table data access
- Reaction classification (synthesis, decomposition, combustion, etc.)
- Molar mass calculations
- Vercel serverless API ready

## Installation

```bash
pip install chemexon
```

## Usage

```python
from chemexon import balance_equation, parse_chemical_formula, calculate_molar_mass

# Balance equation
eq, coeffs = balance_equation("Al + O2 -> Al2O3")
print(eq)  # "4 Al + 3 O2 -> 2 Al2O3"

# Parse formula
atoms = parse_chemical_formula("H2O")
print(atoms)  # {'H': 2, 'O': 1}

# Calculate molar mass
mass = calculate_molar_mass("H2O")
print(mass)  # 18.015
```

## Vercel Deployment

1. Clone this repository
2. Install Vercel CLI: `npm install -g vercel`
3. Deploy: `vercel`

## API Endpoints

- `POST /api/balance` - Balance chemical equations
- `POST /api/parse` - Parse chemical formulas
- `POST /api/molar_mass` - Calculate molar mass
- `GET /api/elements` - List all elements
- `GET /api/elements?symbol=H` - Get element by symbol
- `POST /api/classify` - Classify reaction type

## Credits

Developed by **Codexon - Org**  
Co-Developer: **ramkrishna-dev razzak**  
All rights reserved © 2025 Codexon.