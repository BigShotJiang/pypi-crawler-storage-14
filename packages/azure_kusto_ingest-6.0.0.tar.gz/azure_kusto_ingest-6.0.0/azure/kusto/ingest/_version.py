# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License
import importlib.metadata

VERSION = importlib.metadata.version("azure-kusto-ingest")
