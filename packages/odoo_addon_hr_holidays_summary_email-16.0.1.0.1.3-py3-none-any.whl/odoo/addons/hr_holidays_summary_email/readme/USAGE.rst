For each employee, three options can be selected for the Leave Summary Email
configuration:

- No: No email with the leaves summary is sent to the employee.
- Daily: A daily email with the leaves summary is sent to the employee.
- Weekly: A weekly email with the leaves summary is sent to the employee.

For the weekly email, the setting `Leave Weekly Summary Day of Week` allows
setting the day of the week in which the email is sent.
