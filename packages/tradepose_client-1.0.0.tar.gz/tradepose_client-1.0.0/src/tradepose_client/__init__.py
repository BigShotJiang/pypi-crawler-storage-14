"""Tradepose Python Client SDK.

This package provides a type-safe, async-first Python client for interacting
with the Tradepose Gateway API.

Example:
    >>> from tradepose_client import TradeposeClient
    >>> async with TradeposeClient(api_key="tp_live_xxx") as client:
    ...     subscription = await client.billing.get_subscription()
    ...     print(subscription)
"""

from .client import TradeposeClient
from .config import TradeposeConfig
from .exceptions import (
    AuthenticationError,
    AuthorizationError,
    NetworkError,
    RateLimitError,
    ResourceNotFoundError,
    SerializationError,
    ServerError,
    StrategyError,
    SubscriptionError,
    TaskCancelledError,
    TaskError,
    TaskFailedError,
    TaskTimeoutError,
    TradeposeAPIError,
    TradeposeConfigError,
    TradeposeError,
    ValidationError,
)
from .builder import (
    BlueprintBuilder,
    IndicatorSpecWrapper,
    StrategyBuilder,
    TradingContext,
)

# Batch testing API
from .batch import (
    BacktestRequest,
    BatchResults,
    BatchTester,
    Period,
    PeriodResult,
)

# Import enums from tradepose_models for convenient access
from tradepose_models.enums import (
    Freq,
    IndicatorType,
    OrderStrategy,
    TradeDirection,
    TrendType,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "TradeposeClient",
    "TradeposeConfig",
    # Base exceptions
    "TradeposeError",
    "TradeposeConfigError",
    "TradeposeAPIError",
    # API exceptions
    "AuthenticationError",
    "AuthorizationError",
    "ResourceNotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
    # Task exceptions
    "TaskError",
    "TaskTimeoutError",
    "TaskFailedError",
    "TaskCancelledError",
    # Data exceptions
    "SerializationError",
    # Business logic exceptions
    "SubscriptionError",
    "StrategyError",
    # Builder classes
    "StrategyBuilder",
    "BlueprintBuilder",
    "IndicatorSpecWrapper",
    "TradingContext",
    # Batch testing API
    "BatchTester",
    "BatchResults",
    "PeriodResult",
    "Period",
    "BacktestRequest",
    # Enums (for convenient strategy building)
    "Freq",
    "IndicatorType",
    "OrderStrategy",
    "TradeDirection",
    "TrendType",
]
