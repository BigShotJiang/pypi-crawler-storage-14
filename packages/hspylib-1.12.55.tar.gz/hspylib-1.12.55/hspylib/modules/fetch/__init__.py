# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.modules.fetch
"""Package initialization."""

__all__ = [
    'fetch', 
    'http_response', 
    'uri_builder', 
    'uri_scheme'
]
__version__ = '1.12.55'
