# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.modules.security
"""Package initialization."""

__all__ = [
    'security'
]
__version__ = '1.12.55'
