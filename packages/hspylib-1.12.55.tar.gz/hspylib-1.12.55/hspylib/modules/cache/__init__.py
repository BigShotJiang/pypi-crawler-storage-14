# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.modules.cache
"""Package initialization."""

__all__ = [
    'ttl_cache', 
    'ttl_keyring_be'
]
__version__ = '1.12.55'
