# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.modules.cli.vt100
"""Package initialization."""

__all__ = [
    'vt_100', 
    'vt_code', 
    'vt_color'
]
__version__ = '1.12.55'
