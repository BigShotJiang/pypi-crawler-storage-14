# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.modules.cli
"""Package initialization."""

__all__ = [
    'keyboard', 
    'vt100'
]
__version__ = '1.12.55'
