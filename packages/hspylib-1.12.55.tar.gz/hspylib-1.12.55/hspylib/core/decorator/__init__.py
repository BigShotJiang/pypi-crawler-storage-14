# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.core.decorator
"""Package initialization."""

__all__ = [
    'decorators'
]
__version__ = '1.12.55'
