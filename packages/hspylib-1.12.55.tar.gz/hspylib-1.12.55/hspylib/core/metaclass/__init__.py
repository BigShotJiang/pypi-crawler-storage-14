# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.core.metaclass
"""Package initialization."""

__all__ = [
    'classpath', 
    'singleton'
]
__version__ = '1.12.55'
