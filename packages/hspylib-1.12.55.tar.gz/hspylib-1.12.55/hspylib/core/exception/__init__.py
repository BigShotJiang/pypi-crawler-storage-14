# _*_ coding: utf-8 _*_
#
# hspylib v1.12.55
#
# Package: main.hspylib.core.exception
"""Package initialization."""

__all__ = [
    'exceptions'
]
__version__ = '1.12.55'
