#! /usr/bin/python3

with open('README.md', 'a+') as f:
    f.write('\nHello\n')
