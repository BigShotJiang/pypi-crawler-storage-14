from __future__ import annotations

import warnings
from pathlib import Path
from typing import Any, Callable

import ch5mpy as ch
import numpy as np
import zarr
from zarr.errors import UnstableSpecificationWarning


def _update_array_v0_to_v1(arr: ch.H5Array[Any], output_file: Path | None) -> None:
    if output_file is not None:
        raise NotImplementedError

    if arr.dtype == object or np.issubdtype(arr.dtype, bytes):
        arr.attributes["dtype"] = "str"


def _update_array_v2_to_v3(arr: ch.H5Array[Any], output_file: Path | None) -> None:
    assert output_file is not None

    with warnings.catch_warnings(action="ignore", category=UnstableSpecificationWarning):
        zarr.create_array(output_file, name=arr.dset.name, data=np.array(arr))


update_array: list[Callable[[ch.H5Array[Any], Path | None], None]] = [
    _update_array_v0_to_v1,
    lambda arr, out: None,
    _update_array_v2_to_v3,
]
