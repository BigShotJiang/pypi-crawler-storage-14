from typing import Literal
from uuid import UUID

from spectuel_engine_utils.enums import Side
from spectuel_engine_utils.events.base import EngineEventBase
from .enums import OrderEventType


class OrderEventBase(EngineEventBase):
    version: int = 1
    order_id: UUID


class OrderPlacedEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_PLACED] = OrderEventType.ORDER_PLACED
    instrument_id: UUID
    executed_quantity: int
    quantity: int
    price: float
    user_id: UUID
    side: Side


class OrderFilledEventBase(OrderEventBase):
    instrument_id: UUID
    executed_quantity: int
    quantity: int
    price: float


class OrderPartiallyFilledEvent(OrderFilledEventBase):
    type: Literal[OrderEventType.ORDER_PARTIALLY_FILLED] = (
        OrderEventType.ORDER_PARTIALLY_FILLED
    )


class OrderFilledEvent(OrderFilledEventBase):
    type: Literal[OrderEventType.ORDER_FILLED] = OrderEventType.ORDER_FILLED


class OrderModifiedEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_MODIFIED] = OrderEventType.ORDER_MODIFIED
    limit_price: float | None = None
    stop_price: float | None = None

    def model_post_init(self, context):
        if self.limit_price is None and self.stop_price is None:
            raise ValueError("Either limit price or stop price must be provided.")
        return self


class OrderModifyRejectedEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_MODIFY_REJECTED] = (
        OrderEventType.ORDER_MODIFY_REJECTED
    )
    instrument_id: UUID
    reason: str


class OrderCancelledEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_CANCELLED] = OrderEventType.ORDER_CANCELLED
    instrument_id: UUID
