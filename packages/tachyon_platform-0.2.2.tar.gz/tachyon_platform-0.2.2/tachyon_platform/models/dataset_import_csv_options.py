# coding: utf-8



from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictInt, StrictStr, field_validator
from typing import Any, ClassVar, Dict, List, Optional
from typing import Optional, Set
from typing_extensions import Self

class DatasetImportCsvOptions(BaseModel):
    """
    Additional options for CSV files.
    """ # noqa: E501
    allow_quoted_newlines: Optional[StrictBool] = Field(default=None, alias="allowQuotedNewlines")
    encoding: Optional[StrictStr] = None
    skip_leading_rows: Optional[StrictInt] = Field(default=None, alias="skipLeadingRows")
    __properties: ClassVar[List[str]] = ["allowQuotedNewlines", "encoding", "skipLeadingRows"]

    @field_validator('encoding')
    def encoding_validate_enum(cls, value):
        """Validates the enum"""
        if value is None:
            return value

        if value not in set(['UTF-8', 'ISO-8859-1', 'SHIFT-JIS']):
            raise ValueError("must be one of enum values ('UTF-8', 'ISO-8859-1', 'SHIFT-JIS')")
        return value

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of DatasetImportCsvOptions from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of DatasetImportCsvOptions from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "allowQuotedNewlines": obj.get("allowQuotedNewlines"),
            "encoding": obj.get("encoding"),
            "skipLeadingRows": obj.get("skipLeadingRows")
        })
        return _obj


