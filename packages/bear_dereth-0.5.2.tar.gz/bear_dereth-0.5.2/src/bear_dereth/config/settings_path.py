"""Settings path derivation utilities."""

from pathlib import Path


class SettingsHelper:
    """Helper class for settings file operations."""

    def __init__(
        self,
        name: str,
        file: str | None,
        path: Path | str | None = None,
        ext: str | None = None,
        *,
        default_exemptions: frozenset[str] | None = None,
        allowed_extensions: set[str] | None = None,
        strict: bool = False,
        default_ext: str = "json",
    ) -> None:
        """Initialize SettingsHelper.

        Args:
            name: App name (used as default file name and for default directory)
            file: Optional specific file name (overrides name for filename)
            path: Optional path - can be:
                - Full path to .json file (returns as-is)
                - Directory path (file will be created inside)
                - None (uses default settings directory)
            ext: File extension (default: "json")
            default_exemptions: Optional set of extensions that should use default_ext instead
            default_ext: Default extension to use if ext is in default_exemptions
            mkdir: Whether to create missing directories
        """
        self.name: str = name
        self._file_name: str | None = file
        self._path: Path | str | None = path

        self._ext: str = ext or default_ext
        self.default_exemptions: frozenset[str] = default_exemptions or frozenset()
        if allowed_extensions is not None and self._ext not in allowed_extensions and strict:
            raise ValueError(f"Extension '{self._ext}' is not in allowed extensions: {allowed_extensions}")
        self.default_ext: str = default_ext

    @property
    def extension(self) -> str:
        """Get the effective file extension."""
        if self._file_name is not None and self._file_name:
            return Path(self._file_name).suffix.lstrip(".")
        if self._path is not None:
            path_value = Path(self._path)
            if path_value.suffix:
                return path_value.suffix.lstrip(".")
        return self._ext

    @property
    def file_name(self) -> str:
        """Get the effective file name."""
        if self._file_name is not None:
            return Path(self._file_name).stem
        return self.name

    @property
    def path(self) -> Path:
        """Get the full path to the settings file."""
        from funcy_bear.tools.dir_manager import get_settings_path  # noqa: PLC0415

        if self._path is not None:
            path_value: Path = Path(self._path)
            if path_value.is_file() or path_value.suffix:
                return path_value.parent
            return path_value
        return get_settings_path(self.name, mkdir=True)

    @property
    def ext(self) -> str:
        """Get the effective file extension."""
        if self.extension in self.default_exemptions:
            return self.default_ext
        return self.extension

    @property
    def full_path(self) -> Path:
        """Get the full path to the settings file."""
        return self.path / f"{self.file_name}.{self.ext}"

    def get_path(self) -> Path:
        """Get the full path to the settings file."""
        return self.full_path


def derive_settings_path(name: str, file: str | None = None, path: Path | str | None = None) -> SettingsHelper:
    """Get the path to the settings file based on app name, file, and optional path.

    Args:
        name: Application name (used as default file name and for default directory)
        file: Optional specific file name (overrides name for filename)
        path: Optional path - can be:
            - Full path to .json file (returns as-is)
            - Directory path (file will be created inside)
            - None (uses default settings directory)

    Returns:
        Path: Full path to the settings file
    """
    return SettingsHelper(name, file, path)
