"""Bear Dereth package.

A set of common tools for various bear projects.
"""

from bear_dereth._internal._info import METADATA
from bear_dereth._internal.cli import main

__version__: str = METADATA.version

__all__: list[str] = ["METADATA", "__version__", "main"]
