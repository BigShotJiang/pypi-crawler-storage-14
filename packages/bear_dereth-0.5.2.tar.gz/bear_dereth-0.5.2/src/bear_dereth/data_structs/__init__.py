"""Set of data structures and collections used throughout Bear Dereth."""

from .queuestuffs import PriorityQueue, SimpooQueue
from .stacks import SimpleStack, SimpleStackCursor

__all__ = [
    "PriorityQueue",
    "SimpleStack",
    "SimpleStackCursor",
    "SimpooQueue",
]
