"""Basic tests for the package."""
