"""Test suite for calibre package."""
