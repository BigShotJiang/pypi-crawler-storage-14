#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
移动端测试用例: test_测试
生成时间: 2025-11-26 14:57:47

✨ 特性：智能定位 + 自动降级
   - 优先使用MCP验证过的定位方式（快速）
   - 定位失败时自动降级到智能定位（自愈）
   - 页面改版后大部分用例能自动适应

运行方式:
    pytest test_测试.py -v
    pytest test_测试.py --alluredir=./allure-results  # 生成allure报告
"""
import asyncio
import pytest
import sys
from pathlib import Path

# 添加backend目录到路径
# tests目录结构: backend/mobile_mcp/tests/test_xxx.py
# 需要导入: backend/mobile_mcp/core/mobile_client.py
sys.path.insert(0, str(Path(__file__).parent.parent))

from mobile_mcp.core.mobile_client import MobileClient
from mobile_mcp.core.locator.mobile_smart_locator import MobileSmartLocator


PACKAGE_NAME = "com.duitang.main"


@pytest.fixture(scope='function')
async def mobile_client():
    """
    pytest fixture: 创建并返回MobileClient实例
    scope='function': 每个测试函数都会创建一个新的client
    """
    client = MobileClient(device_id=None)
    
    # 🎯 附加智能定位器（用于降级场景）
    client.smart_locator = MobileSmartLocator(client)
    
    # 启动App
    print(f"\n📱 启动App: {{PACKAGE_NAME}}", file=sys.stderr)
    result = await client.launch_app(PACKAGE_NAME, wait_time=5)
    if not result.get('success'):
        raise Exception(f"启动App失败: {{result.get('reason')}}")
    
    await asyncio.sleep(2)  # 等待页面加载
    
    yield client
    
    # 清理
    client.device_manager.disconnect()


@pytest.mark.asyncio
async def test_test_测试(mobile_client):
    """
    测试用例: test_测试
    
    Args:
        mobile_client: pytest fixture，已启动App的MobileClient实例
    """
    client = mobile_client
    
    print("=" * 60, file=sys.stderr)
    print(f"🚀 test_测试", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    
    try:
        # 步骤1: 点击 我
        print(f"\n步骤1: 点击 我", file=sys.stderr)
        try:
            # 优先使用MCP验证过的resource-id
            await client.click("我", ref="com.duitang.main:id/ex_tab_title", verify=False)
            print(f"✅ 点击成功（resource-id: com.duitang.main:id/ex_tab_title）", file=sys.stderr)
        except Exception as e:
            # 🎯 原定位失效，启用智能定位（自愈）
            print(f"⚠️  原定位失效: {e}", file=sys.stderr)
            print(f"🔍 启用智能定位重新查找'我'...", file=sys.stderr)
            
            locate_result = await client.smart_locator.locate("我")
            if locate_result:
                await client.click("我", ref=locate_result['ref'], verify=False)
                print(f"✅ 智能定位成功: {locate_result['ref']}", file=sys.stderr)
            else:
                raise Exception(f"❌ 智能定位也失败了，元素'我'可能已被删除或页面结构大幅改变")
        
        await asyncio.sleep(1.5)  # 等待页面响应
        # 步骤2: 点击 [864,2221][1080,2356]
        print(f"\n步骤2: 点击 [864,2221][1080,2356]", file=sys.stderr)
        try:
            # 优先使用MCP验证过的bounds
            await client.click("[864,2221][1080,2356]", ref="[864,2221][1080,2356]", verify=False)
            print(f"✅ 点击成功（bounds: [864,2221][1080,2356]）", file=sys.stderr)
        except Exception as e:
            # 🎯 原定位失效，启用智能定位（自愈）
            print(f"⚠️  原定位失效: {e}", file=sys.stderr)
            print(f"🔍 启用智能定位重新查找'[864,2221][1080,2356]'...", file=sys.stderr)
            
            locate_result = await client.smart_locator.locate("[864,2221][1080,2356]")
            if locate_result:
                await client.click("[864,2221][1080,2356]", ref=locate_result['ref'], verify=False)
                print(f"✅ 智能定位成功: {locate_result['ref']}", file=sys.stderr)
            else:
                raise Exception(f"❌ 智能定位也失败了，元素'[864,2221][1080,2356]'可能已被删除或页面结构大幅改变")
        
        await asyncio.sleep(1.5)  # 等待页面响应
        # 步骤3: 点击 不同意
        print(f"\n步骤3: 点击 不同意", file=sys.stderr)
        # 🎯 可选操作：弹窗/权限请求（不一定出现）
        try:
            # 优先使用MCP验证过的resource-id
            await client.click("不同意", ref="com.duitang.main:id/welcome_policies_disagree", verify=False)
            print(f"✅ 点击成功（resource-id: com.duitang.main:id/welcome_policies_disagree）", file=sys.stderr)
        except Exception as e:
            # 弹窗未出现，跳过
            print(f"ℹ️  '不同意'未出现，跳过（可能已授权或无需操作）", file=sys.stderr)
        
        await asyncio.sleep(0.5)  # 🎯 等待下拉选项加载
        # 步骤4: 点击 首页
        print(f"\n步骤4: 点击 首页", file=sys.stderr)
        try:
            # 优先使用MCP验证过的resource-id
            await client.click("首页", ref="com.duitang.main:id/ex_tab_title", verify=False)
            print(f"✅ 点击成功（resource-id: com.duitang.main:id/ex_tab_title）", file=sys.stderr)
        except Exception as e:
            # 🎯 原定位失效，启用智能定位（自愈）
            print(f"⚠️  原定位失效: {e}", file=sys.stderr)
            print(f"🔍 启用智能定位重新查找'首页'...", file=sys.stderr)
            
            locate_result = await client.smart_locator.locate("首页")
            if locate_result:
                await client.click("首页", ref=locate_result['ref'], verify=False)
                print(f"✅ 智能定位成功: {locate_result['ref']}", file=sys.stderr)
            else:
                raise Exception(f"❌ 智能定位也失败了，元素'首页'可能已被删除或页面结构大幅改变")
        
        await asyncio.sleep(0.5)  # 🎯 等待下拉选项加载
        # 步骤5: 点击 大家都在搜
        print(f"\n步骤5: 点击 大家都在搜", file=sys.stderr)
        try:
            # 优先使用MCP验证过的bounds
            await client.click("大家都在搜", ref="[515,313][565,363]", verify=False)
            print(f"✅ 点击成功（bounds: [515,313][565,363]）", file=sys.stderr)
        except Exception as e:
            # 🎯 原定位失效，启用智能定位（自愈）
            print(f"⚠️  原定位失效: {e}", file=sys.stderr)
            print(f"🔍 启用智能定位重新查找'大家都在搜'...", file=sys.stderr)
            
            locate_result = await client.smart_locator.locate("大家都在搜")
            if locate_result:
                await client.click("大家都在搜", ref=locate_result['ref'], verify=False)
                print(f"✅ 智能定位成功: {locate_result['ref']}", file=sys.stderr)
            else:
                raise Exception(f"❌ 智能定位也失败了，元素'大家都在搜'可能已被删除或页面结构大幅改变")
        
        await asyncio.sleep(0.5)  # 🎯 等待下拉选项加载
        # 步骤6: 在搜索输入框输入 测试
        print(f"\n步骤6: 在搜索输入框输入 测试", file=sys.stderr)
        try:
            # 🎯 先点击输入框聚焦
            await client.click("搜索输入框", ref="com.duitang.main:id/etSearch", verify=False)
            await asyncio.sleep(0.3)
            
            # 🎯 清空输入框（避免内容累加）
            if client.platform == 'android':
                client.u2.clear_text()
            elif client.platform == 'ios':
                # iOS清空逻辑
                pass
            await asyncio.sleep(0.2)
            
            # 优先使用MCP验证过的resource-id
            await client.type_text("搜索输入框", "测试", ref="com.duitang.main:id/etSearch")
            print(f"✅ 输入成功（resource-id: com.duitang.main:id/etSearch）", file=sys.stderr)
        except Exception as e:
            # 🎯 原定位失效，启用智能定位（自愈）
            print(f"⚠️  原定位失效: {e}", file=sys.stderr)
            print(f"🔍 启用智能定位重新查找'搜索输入框'...", file=sys.stderr)
            
            locate_result = await client.smart_locator.locate("搜索输入框")
            if locate_result:
                # 重新点击聚焦
                await client.click("搜索输入框", ref=locate_result['ref'], verify=False)
                await asyncio.sleep(0.3)
                # 清空
                if client.platform == 'android':
                    client.u2.clear_text()
                await asyncio.sleep(0.2)
                # 输入
                await client.type_text("搜索输入框", "测试", ref=locate_result['ref'])
                print(f"✅ 智能定位成功: {locate_result['ref']}", file=sys.stderr)
            else:
                raise Exception(f"❌ 智能定位也失败了，元素'搜索输入框'可能已被删除或页面结构大幅改变")
        
        await asyncio.sleep(1)  # 等待输入完成
        # 步骤7: 点击 搜索
        print(f"\n步骤7: 点击 搜索", file=sys.stderr)
        try:
            # 优先使用MCP验证过的resource-id
            await client.click("搜索", ref="com.duitang.main:id/search_bar_search_btn", verify=False)
            print(f"✅ 点击成功（resource-id: com.duitang.main:id/search_bar_search_btn）", file=sys.stderr)
        except Exception as e:
            # 🎯 原定位失效，启用智能定位（自愈）
            print(f"⚠️  原定位失效: {e}", file=sys.stderr)
            print(f"🔍 启用智能定位重新查找'搜索'...", file=sys.stderr)
            
            locate_result = await client.smart_locator.locate("搜索")
            if locate_result:
                await client.click("搜索", ref=locate_result['ref'], verify=False)
                print(f"✅ 智能定位成功: {locate_result['ref']}", file=sys.stderr)
            else:
                raise Exception(f"❌ 智能定位也失败了，元素'搜索'可能已被删除或页面结构大幅改变")
        
        await asyncio.sleep(1.5)  # 等待页面响应
        
        print("\n✅ 测试完成！", file=sys.stderr)
        
    except AssertionError as e:
        print(f"\n❌ 断言失败: {e}", file=sys.stderr)
        # 打印当前页面快照以便调试
        snapshot = await client.snapshot()
        print(f"\n当前页面快照:\n{snapshot[:500]}...", file=sys.stderr)
        raise
    except Exception as e:
        print(f"\n❌ 测试失败: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        raise