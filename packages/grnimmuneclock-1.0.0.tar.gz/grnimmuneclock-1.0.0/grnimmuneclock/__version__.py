"""Version information for GRNimmuneClock."""

__version__ = "1.0.0"
__author__ = "Jalil Nourisa"
__license__ = "MIT"
