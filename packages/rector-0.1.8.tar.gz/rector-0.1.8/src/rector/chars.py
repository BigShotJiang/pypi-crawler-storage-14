"""Character helpers for building regex character classes."""

from __future__ import annotations

from typing import Iterable


def escape_literal(char: str) -> str:
    if char in ".^$*+?{}[]\\|()":
        return "\\" + char
    return char


def escape_for_class(char: str) -> str:
    if char in {"-", "]", "^", "\\"}:
        return "\\" + char
    return char


def is_atom(expr: str) -> bool:
    if not expr:
        return False
    if len(expr) == 1:
        return True
    if expr.startswith("\\") and len(expr) == 2:
        return True
    if expr.startswith("[") and expr.endswith("]"):
        return True
    if expr.startswith("(?:") and expr.endswith(")") and "|" not in expr:
        return True
    return False


def optional(expr: str) -> str:
    if not expr:
        return ""
    return f"{expr}?" if is_atom(expr) else f"(?:{expr})?"


def char_class(chars: Iterable[str]) -> str:
    """
    Build a character class, collapsing contiguous ranges where possible.
    """

    char_set = set(chars)
    if len(char_set) == 1:
        return escape_literal(next(iter(char_set)))

    codes = sorted(ord(ch) for ch in char_set)
    if not codes:
        return ""

    ranges: list[tuple[int, int]] = []
    start = prev = codes[0]
    for code in codes[1:]:
        if code == prev + 1:
            prev = code
            continue
        ranges.append((start, prev))
        start = prev = code
    ranges.append((start, prev))

    parts: list[str] = []
    for first, last in ranges:
        if first == last:
            parts.append(escape_for_class(chr(first)))
        elif last == first + 1:
            parts.append(escape_for_class(chr(first)))
            parts.append(escape_for_class(chr(last)))
        else:
            parts.append(
                f"{escape_for_class(chr(first))}-{escape_for_class(chr(last))}"
            )

    if len(parts) == 1:
        part = parts[0]
        if "-" in part and len(part) > 1:
            return "[" + part + "]"
        return escape_literal(part)
    return "[" + "".join(parts) + "]"


def contiguous_class(chars: set[str]) -> str:
    if len(chars) == 1:
        return escape_literal(next(iter(chars)))

    codes = sorted(ord(c) for c in chars)
    if not codes:
        return ""
    if codes[-1] - codes[0] + 1 == len(codes):
        # Full contiguous block.
        first = escape_for_class(chr(codes[0]))
        last = escape_for_class(chr(codes[-1]))
        if first == last:
            return escape_literal(chr(codes[0]))
        return f"[{first}-{last}]"
    return char_class(chars)
