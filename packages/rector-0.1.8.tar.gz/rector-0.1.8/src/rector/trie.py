"""Minimal trie helpers used for regex generation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable


@dataclass(eq=False)
class TrieNode:
    """A node in the prefix tree."""

    children: Dict[str, "TrieNode"] = field(default_factory=dict)
    terminal: bool = False

    def insert(self, word: str) -> None:
        node = self
        for char in word:
            node = node.children.setdefault(char, TrieNode())
        node.terminal = True


@dataclass
class Trie:
    root: TrieNode = field(default_factory=TrieNode)

    @classmethod
    def from_words(cls, words: Iterable[str]) -> "Trie":
        trie = cls()
        for word in words:
            trie.root.insert(word)
        return trie


def build_trie(words: Iterable[str]) -> Trie:
    return Trie.from_words(words)


__all__ = ["Trie", "TrieNode", "build_trie"]
