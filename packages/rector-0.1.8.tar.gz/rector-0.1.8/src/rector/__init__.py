"""Rector regex generation framework."""

from pathlib import Path

from .trie_regex import TrieRegexGenerator

_VERSION_FILE = Path(__file__).with_name("VERSION")
__version__ = _VERSION_FILE.read_text().strip()

__all__ = [
    "TrieRegexGenerator",
]
