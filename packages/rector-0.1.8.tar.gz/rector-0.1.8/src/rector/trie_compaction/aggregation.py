"""Aggregation-based trie compaction helpers."""

from __future__ import annotations

from fractions import Fraction

from ..trie import TrieNode
from .dense_ranges import dense_range_or_class


def aggregate_layers(root: TrieNode) -> tuple[list[set[str]], set[int]] | None:
    """
    Collect union of child labels per depth across all nodes plus allowed lengths.
    Returns (classes_per_depth, lengths) if each depth has at least one label; else None.
    """

    classes: list[set[str]] = []
    lengths: set[int] = set()

    current = [root]
    depth = 0
    while current:
        if any(node.terminal for node in current):
            lengths.add(depth)

        symbols: set[str] = set()
        next_level: list[TrieNode] = []
        for node in current:
            symbols.update(node.children.keys())
            next_level.extend(node.children.values())

        if not symbols:
            break

        classes.append(symbols)
        current = next_level
        depth += 1

    if not classes:
        return None
    return classes, lengths


def _length_window(lengths: set[int], depth_count: int) -> tuple[int, int] | None:
    """
    Validate that lengths form a contiguous interval within the collected depth count.
    """

    if not lengths:
        return None

    min_len, max_len = min(lengths), max(lengths)
    if len(lengths) != max_len - min_len + 1:
        return None
    if max_len > depth_count:
        return None

    return min_len, max_len


def _atoms_for_levels(
    classes: list[set[str]],
    *,
    max_len: int,
    dense_threshold: Fraction,
    allow_canonicals: bool,
) -> list[str] | None:
    """
    Build regex atoms for the first max_len levels using dense range compaction.
    """

    atoms = [
        dense_range_or_class(
            symbols,
            dense_threshold=dense_threshold,
            allow_canonical=allow_canonicals,
        )
        for symbols in classes[:max_len]
    ]
    if any(not atom for atom in atoms):
        return None
    return atoms


def _format_atom_run(atom: str, lower: int, upper: int) -> str:
    """
    Format a single atom with its lower/upper bound.
    """

    if lower == upper:
        if lower == 1:
            return atom
        return f"{atom}{{{lower}}}"

    if lower == 0 and upper == 1:
        return f"{atom}?"
    if lower == 0:
        return f"{atom}{{0,{upper}}}"
    return f"{atom}{{{lower},{upper}}}"


def _compress_atoms(atoms: list[str], *, min_len: int) -> str:
    """
    Collapse consecutive identical atoms while applying the required/optional split
    around min_len.
    """

    body_parts: list[str] = []
    index = 0
    max_len = len(atoms)

    while index < max_len:
        atom = atoms[index]
        run_end = index + 1
        while run_end < max_len and atoms[run_end] == atom:
            run_end += 1
        run_len = run_end - index

        required = 0 if index >= min_len else min(min_len - index, run_len)
        optional = run_len - required

        lower = required
        upper = required + optional
        body_parts.append(_format_atom_run(atom, lower, upper))

        index = run_end

    return "".join(body_parts)


def compact_aggregated(
    root: TrieNode,
    *,
    dense_threshold: Fraction,
    allow_canonicals_in_aggregation: bool,
) -> str | None:
    """
    If all depths are populated and lengths form a contiguous interval, build a compact
    pattern from the aggregated per-depth symbol unions.
    """

    aggregated = aggregate_layers(root)
    if aggregated is None:
        return None

    classes, lengths = aggregated
    length_window = _length_window(lengths, len(classes))
    if length_window is None:
        return None
    min_len, max_len = length_window

    atoms = _atoms_for_levels(
        classes,
        max_len=max_len,
        dense_threshold=dense_threshold,
        allow_canonicals=allow_canonicals_in_aggregation,
    )
    if atoms is None:
        return None

    body = _compress_atoms(atoms, min_len=min_len)

    if root.terminal and min_len > 0:
        # Allow empty only if root itself is terminal.
        body = f"(?:{body})?"

    return body
