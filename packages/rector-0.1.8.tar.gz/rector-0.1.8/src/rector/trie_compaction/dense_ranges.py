"""Helpers for collapsing character sets into dense regex ranges."""

from __future__ import annotations

from fractions import Fraction
import string

from ..chars import char_class, escape_for_class, escape_literal

_DIGITS = set(string.digits)
_WORD_CHARS = set(string.ascii_letters + string.digits + "_")


def dense_range_or_class(
    chars: set[str], *, dense_threshold: Fraction, allow_canonical: bool = True
) -> str:
    """
    Collapse a character set to a dense range if coverage over its span meets the threshold.
    """

    if not chars:
        return ""

    if len(chars) == 1:
        return escape_literal(next(iter(chars)))

    if allow_canonical:
        if all(ch.isspace() for ch in chars):
            return r"\s"

        if all(ch.isdigit() for ch in chars) and "0" in chars:
            digit_coverage = Fraction(len(chars), len(_DIGITS))
            if digit_coverage >= dense_threshold:
                return r"\d"

        if chars <= _WORD_CHARS:
            word_coverage = Fraction(len(chars), len(_WORD_CHARS))
            if word_coverage >= dense_threshold:
                return r"\w"

        if chars == _WORD_CHARS:
            return r"\w"

    codes = sorted(ord(c) for c in chars)
    start, end = codes[0], codes[-1]
    span = end - start + 1
    coverage = Fraction(len(chars), span) if span else Fraction(1, 1)

    if coverage >= dense_threshold and len(chars) >= 3:
        first = escape_for_class(chr(start))
        last = escape_for_class(chr(end))
        if first == last:
            return escape_literal(chr(start))
        return f"[{first}-{last}]"

    return char_class(chars)
