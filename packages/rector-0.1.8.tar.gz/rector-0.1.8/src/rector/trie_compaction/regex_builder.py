"""Entry point for compacting tries into regex fragments."""

from __future__ import annotations

from fractions import Fraction

from ..chars import optional
from ..trie import TrieNode
from .aggregation import compact_aggregated
from .dense_ranges import dense_range_or_class
from .uniform import compact_uniform


def trie_to_regex(
    node: TrieNode,
    *,
    dense_threshold: Fraction,
    allow_canonicals_in_aggregation: bool = False,
) -> str:
    """
    Produce a compact regex that matches exactly the strings in the trie.
    """

    for strategy in (
        lambda n: compact_uniform(n, dense_threshold=dense_threshold),
        lambda n: compact_aggregated(
            n,
            dense_threshold=dense_threshold,
            allow_canonicals_in_aggregation=allow_canonicals_in_aggregation,
        ),
    ):
        compact = strategy(node)
        if compact is not None:
            return compact

    grouped: dict[str, list[str]] = {}
    for char, child in sorted(node.children.items()):
        suffix = trie_to_regex(child, dense_threshold=dense_threshold)
        grouped.setdefault(suffix, []).append(char)

    options: list[str] = []
    for suffix, chars in sorted(grouped.items()):
        prefix = dense_range_or_class(set(chars), dense_threshold=dense_threshold)
        options.append(prefix + suffix)

    has_empty = node.terminal
    if not options and not has_empty:
        return ""

    if len(options) == 1:
        base = options[0]
    elif options:
        base = "(?:" + "|".join(options) + ")"
    else:
        base = ""

    if has_empty:
        return optional(base)
    return base
