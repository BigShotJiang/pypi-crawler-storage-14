"""Uniform-depth trie compaction helpers."""

from __future__ import annotations

from fractions import Fraction

from ..trie import TrieNode
from .dense_ranges import dense_range_or_class


def uniform_signature(
    root: TrieNode, *, dense_threshold: Fraction
) -> tuple[set[int], list[str]] | None:
    """
    If every depth shares identical terminal flags and child sets, return
    (allowed_lengths, classes_per_depth). Otherwise None.
    """

    allowed_lengths: set[int] = set()
    classes: list[str] = []

    level = [root]
    depth = 0
    while True:
        terminal_flags = {n.terminal for n in level}
        if len(terminal_flags) > 1:
            return None
        if True in terminal_flags:
            allowed_lengths.add(depth)

        child_sets = [tuple(sorted(n.children.keys())) for n in level]
        first = child_sets[0] if child_sets else ()
        if any(cs != first for cs in child_sets):
            return None
        if not first:
            break

        classes.append(
            dense_range_or_class(set(first), dense_threshold=dense_threshold)
        )
        level = [child for node in level for child in node.children.values()]
        depth += 1

    return allowed_lengths, classes


def compact_uniform(root: TrieNode, *, dense_threshold: Fraction) -> str | None:
    """
    If the trie is uniform per depth, emit a compact pattern with optional tails
    or aggregated quantifiers.
    """

    signature = uniform_signature(root, dense_threshold=dense_threshold)
    if signature is None:
        return None

    allowed_lengths, classes = signature
    if not allowed_lengths:
        return None

    max_len = len(classes)
    min_len, max_allowed = min(allowed_lengths), max(allowed_lengths)

    if max_allowed > 1:
        classes = ["[0-9]" if cls == r"\d" else cls for cls in classes]
    if max_allowed != max_len:
        return None
    if len(allowed_lengths) != max_allowed - min_len + 1:
        return None

    if len(set(classes)) == 1:
        cls = classes[0]
        if min_len == max_allowed:
            if max_allowed == 1:
                return cls
            return f"{cls}{{{max_allowed}}}"
        return f"{cls}{{{min_len},{max_allowed}}}"

    required_classes = classes[:min_len]
    optional_classes = classes[min_len:max_allowed]
    required = "".join(required_classes)

    if not optional_classes:
        return required

    if len(set(optional_classes)) == 1:
        tail_cls = optional_classes[0]
        if required_classes and required_classes[-1] == tail_cls:
            head = "".join(required_classes[:-1])
            lower = 1
            upper = 1 + len(optional_classes)
            return f"{head}{tail_cls}{{{lower},{upper}}}"
        return f"{required}{tail_cls}{{0,{len(optional_classes)}}}"

    from ..chars import optional

    tail = optional_classes[-1]
    for cls in reversed(optional_classes[:-1]):
        tail = f"{cls}{optional(tail)}"

    return required + optional(tail)
