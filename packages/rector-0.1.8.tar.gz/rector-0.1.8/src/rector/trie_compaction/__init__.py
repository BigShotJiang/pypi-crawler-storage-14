"""Public interface for trie compaction utilities."""

from .regex_builder import trie_to_regex

__all__ = ["trie_to_regex"]
