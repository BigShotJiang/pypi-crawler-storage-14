"""Trie-based regex generation."""

from __future__ import annotations

import re
from fractions import Fraction
from typing import Iterable

from .examples import normalize_examples
from .trie import build_trie
from .trie_compaction import trie_to_regex

RegexPattern = re.Pattern[str]


class TrieRegexGenerator:
    """
    Generate a regular expression from examples using a trie without heuristics.
    """

    def __init__(
        self,
        *,
        anchor_start: bool = True,
        anchor_end: bool = True,
        flags: re.RegexFlag = re.RegexFlag(0),
        dense_threshold: Fraction = Fraction(8, 10),
        aggregate_canonicals: bool = False,
    ) -> None:
        self._examples: list[str] = []
        self.anchor_start = anchor_start
        self.anchor_end = anchor_end
        self.flags = flags
        self.dense_threshold = dense_threshold
        self.aggregate_canonicals = aggregate_canonicals

    def add_example(self, example: str) -> "TrieRegexGenerator":
        """Add a single example string."""

        if not isinstance(example, str):
            raise TypeError("All examples must be strings.")
        self._examples.append(example)
        return self

    def add_examples(self, examples: Iterable[str]) -> "TrieRegexGenerator":
        """Add normalized examples to the generator."""

        self._examples.extend(normalize_examples(examples))
        return self

    def generate(self) -> RegexPattern:
        """Build a regex from accumulated examples."""
        if not self._examples:
            raise ValueError("No examples provided for trie regex generation.")

        trie = build_trie(list(self._examples))
        body = trie_to_regex(
            trie.root,
            dense_threshold=self.dense_threshold,
            allow_canonicals_in_aggregation=self.aggregate_canonicals,
        )
        prefix = "^" if self.anchor_start else ""
        suffix = "$" if self.anchor_end else ""
        return re.compile(f"{prefix}{body}{suffix}", self.flags)
