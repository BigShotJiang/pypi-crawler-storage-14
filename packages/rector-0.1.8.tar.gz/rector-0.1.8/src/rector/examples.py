"""Example normalization helpers for trie-based regex generation."""

from __future__ import annotations

from typing import Iterable, List


def normalize_examples(examples: Iterable[str]) -> List[str]:
    """Validate and copy examples as a list of strings."""
    normalized: List[str] = []
    for example in examples:
        if not isinstance(example, str):
            raise TypeError("All examples must be strings.")
        normalized.append(example)
    return normalized
