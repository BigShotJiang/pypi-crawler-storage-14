# rector (***Re***gex ***Gen***era***tor***)

## `[x]` Setup the project

I would like to prepare the project from the structure in such a way that it stands as a framework and corresponds to the usual Python conventions and is so designed that I can then publish it without problems on PyPI.

It should be prepared for BDD testing with PyTest BDD. So this can be taken into the developer deficiencies.

Status: Project scaffolded with `pyproject.toml`, MIT license, `src/rector` generator module, and pytest-bdd sample feature plus steps.

## `[x]` Complete the Makefile template

* Ensure that all dependencies required during the make process are in the dev-dependencies in pyproject.toml
* If an external script is required for any task, implement the script (but prefer using existing tools)

Status: Makefile filled with working targets (help, install, fmt, lint, test, build, publish, versioning) using the project venv; dev extras now include required tools (ruff, black, build, twine, hatch, tomli).

## `[x]` Formal regex construction 

Wherever appropriate make use of well maintained libraries (e.g. https://pypi.org/project/FAdo/)

Status: Implemented trie-driven regex pipeline (trie → NFA → DFA determinization → Hopcroft minimization → regex elimination) plus a simple CLI for printing the derived regex.

### `[x]` Build Trie from the input strings
  - automata/nfa.py
### `[x]` NFA (non-deterministic machines) construct
  - automata/dfa.py
### `[x]` NFA → Determine DFA
  - automata/minimize.py
### `[x]` minimize DFA (Hopcroft)
  - regex/elimination.py
### `[x]` Transform minimal DFA back into Regex
  - main.py (CLI optional)
