import io
import itertools
import re
import string
from fractions import Fraction

import pytest
from rector.main import generate_pattern_from_stream, main
from rector.trie_regex import TrieRegexGenerator


def test_generate_pattern_from_stream_matches_examples():
    stream = io.StringIO("cat\ncar\ncap\n")
    pattern = generate_pattern_from_stream(stream)
    compiled = re.compile(pattern)
    for word in ["cat", "car", "cap"]:
        assert compiled.fullmatch(word)
    assert compiled.fullmatch("cabb") is None


def test_generate_pattern_from_stream_requires_input():
    with pytest.raises(ValueError):
        generate_pattern_from_stream(io.StringIO(""))


def test_main_prints_pattern_and_returns_zero(capsys):
    stream = io.StringIO("foo\nbar\n")
    exit_code = main([], stream=stream)
    captured = capsys.readouterr()
    assert exit_code == 0
    lines = [line for line in captured.out.splitlines() if line.strip()]
    expected = TrieRegexGenerator().add_examples(["foo", "bar"]).generate().pattern
    assert lines == [expected]


def test_main_preserves_empty_lines(capsys):
    stream = io.StringIO("\nfoo\n")
    exit_code = main([], stream=stream)
    captured = capsys.readouterr()

    assert exit_code == 0
    pattern = captured.out.strip()
    compiled = re.compile(pattern)
    assert compiled.fullmatch("")
    assert compiled.fullmatch("foo")


def test_main_accepts_fraction_dense_threshold(capsys):
    examples = ["a0", "a1", "a2", "a3", "a4", "a9"]
    stream = io.StringIO("\n".join(examples) + "\n")

    exit_code = main(["--dense-threshold", "1/2"], stream=stream)

    captured = capsys.readouterr()
    assert exit_code == 0
    pattern = captured.out.strip()
    expected = (
        TrieRegexGenerator(dense_threshold=Fraction(1, 2))
        .add_examples(examples)
        .generate()
        .pattern
    )
    assert pattern == expected


def test_main_rejects_invalid_dense_threshold(capsys):
    stream = io.StringIO("foo\n")

    exit_code = main(["--dense-threshold", "nonsense"], stream=stream)

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "invalid dense threshold" in captured.err


@pytest.fixture
def dense_lowercase_examples_stream():
    two_letter = (
        "".join(chars) for chars in itertools.product(string.ascii_lowercase, repeat=2)
    )
    three_letter = (
        "".join(chars) for chars in itertools.product(string.ascii_lowercase, repeat=3)
    )
    return io.StringIO("\n".join([*two_letter, *three_letter]) + "\n")


def test_cli_preserves_trie_compaction_for_dense_alphabet(
    capsys, dense_lowercase_examples_stream
):
    """
    Regression fixture: with all 2- and 3-letter lowercase permutations the CLI
    should compact to a simple range-based pattern instead of enumerating every word.
    """

    exit_code = main([], stream=dense_lowercase_examples_stream)
    captured = capsys.readouterr()

    assert exit_code == 0
    assert captured.out.strip() == r"^[a-z]{2,3}$"


def test_cli_with_dense_threshold_still_uses_trie_on_mixed_lengths(
    capsys, dense_lowercase_examples_stream
):
    """
    Even when --dense-threshold is supplied, mixed-length inputs should avoid
    heuristic alternation and stick to trie compaction.
    """

    exit_code = main(
        ["--dense-threshold", "3/4"], stream=dense_lowercase_examples_stream
    )
    captured = capsys.readouterr()

    assert exit_code == 0
    assert captured.out.strip() == r"^[a-z]{2,3}$"


def test_cli_accepts_input_files_and_outputs_one_pattern_per_file(tmp_path, capsys):
    file_one = tmp_path / "one.txt"
    file_one.write_text("cat\ncar\n")
    file_two = tmp_path / "two.txt"
    file_two.write_text("foo\nbar\n")

    exit_code = main([str(file_one), str(file_two)])
    captured = capsys.readouterr()

    assert exit_code == 0
    lines = captured.out.splitlines()
    expected_one = TrieRegexGenerator().add_examples(["cat", "car"]).generate().pattern
    expected_two = TrieRegexGenerator().add_examples(["foo", "bar"]).generate().pattern
    assert lines == [expected_one, expected_two]


def test_cli_can_join_inputs_into_single_pattern(tmp_path, capsys):
    file_one = tmp_path / "one.txt"
    file_one.write_text("cat\ncar\n")
    file_two = tmp_path / "two.txt"
    file_two.write_text("cap\n")

    exit_code = main(["-j", str(file_one), str(file_two)])
    captured = capsys.readouterr()

    assert exit_code == 0
    lines = captured.out.splitlines()
    expected = (
        TrieRegexGenerator().add_examples(["cat", "car", "cap"]).generate().pattern
    )
    assert lines == [expected]
