from pathlib import Path
from fractions import Fraction

from pytest_bdd import given, parsers, scenario, then, when

from rector import TrieRegexGenerator


@scenario("regex_builder.feature", "Generate ISO date regex from examples")
def test_generate_iso_date():
    pass


@scenario("file_examples.feature", "Generate regex patterns from example files")
def test_generate_patterns_from_files():
    pass


@given(parsers.re(r"the example strings (?P<items>.+)"), target_fixture="examples")
def example_strings(items: str):
    values = [part.strip().strip('"').strip("'") for part in items.split(",")]
    return [value for value in values if value]


@given(parsers.parse('the example file "{filename}"'), target_fixture="examples")
def example_file(filename: str):
    base_dir = Path(__file__).resolve().parent.parent.parent
    path = Path(filename)
    if not path.is_absolute():
        path = base_dir / path
    if not path.exists():
        raise FileNotFoundError(f"Example file not found: {path}")
    return path.read_text().splitlines()


@when("I generate an optimized regex", target_fixture="compiled_pattern")
def generate_pattern(examples):
    generator = TrieRegexGenerator()
    return generator.add_examples(examples).generate()


@when(
    parsers.parse(
        'I generate an optimized regex with dense threshold "{dense_threshold}" and aggregate canonicals "{aggregate_canonicals}"'
    ),
    target_fixture="compiled_pattern",
)
def generate_pattern_with_options(
    examples, dense_threshold: str, aggregate_canonicals: str
):
    def to_bool(value: str) -> bool:
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "y"}:
            return True
        if normalized in {"false", "0", "no", "n"}:
            return False
        raise ValueError(f"Invalid boolean value: {value}")

    generator = TrieRegexGenerator(
        dense_threshold=Fraction(dense_threshold),
        aggregate_canonicals=to_bool(aggregate_canonicals),
    )
    return generator.add_examples(examples).generate()


@then(parsers.parse('the pattern matches "{text}"'))
def pattern_matches(compiled_pattern, text: str):
    assert compiled_pattern.fullmatch(text)


@then(parsers.parse('the pattern does not match "{text}"'))
def pattern_does_not_match(compiled_pattern, text: str):
    assert compiled_pattern.fullmatch(text) is None


@then(parsers.parse('the pattern equals "{expected_pattern}"'))
def pattern_equals(compiled_pattern, expected_pattern: str):
    normalized_expected = expected_pattern.encode("utf-8").decode("unicode_escape")
    assert compiled_pattern.pattern == normalized_expected
