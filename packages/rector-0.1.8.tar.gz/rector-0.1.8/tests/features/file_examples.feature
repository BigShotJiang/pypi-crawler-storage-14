Feature: Generate regex patterns from files
  Rector builds regex patterns based on example files containing one string per line.

  Scenario Outline: Generate regex patterns from example files
    Given the example file "<input_file>"
    When I generate an optimized regex with dense threshold "<dense_threshold>" and aggregate canonicals "<aggregate_canonicals>"
    Then the pattern equals "<expected_pattern>"

    Examples:
      | input_file                                | dense_threshold | aggregate_canonicals | expected_pattern                    |
      | tests/fixtures/numbers_0-8.txt            | 8/10            | False                | ^\d$                                |
      | tests/fixtures/space_variants.txt         | 3/4             | False                | ^[a-z] [a-z]{2}[ a-z]{2}[a-z]{2,3}$ |
      | tests/fixtures/increasing_line_length.txt | 1               | False                | ^a(?:bc?)?$                         |
      | tests/fixtures/prefixes.txt               | 1               | False                | ^pre(?:fix(?:es)?)?$                |
      | tests/fixtures/digit_pairs.txt            | 1               | False                | ^[0-9]{2}$                          |
      | tests/fixtures/whitespace_prefix.txt      | 1               | True                 | ^\scat$                             |
      | tests/fixtures/zip_branch.txt             | 1               | False                | ^1234[5A]$                          |
