Feature: Generate regular expressions from examples
  Rector derives an optimized regex pattern from provided example strings.

  Scenario: Generate ISO date regex from examples
    Given the example strings "2025-11-28", "2024-01-01", "1999-12-31"
    When I generate an optimized regex
    Then the pattern matches "2025-11-28"
    And the pattern does not match "28/11/2025"
    And the pattern does not match "2025-1-1"
