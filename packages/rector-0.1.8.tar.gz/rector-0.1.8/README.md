# rector — Regex Generator

Rector turns example strings into optimized regular expressions you can reuse in search, validation, or routing rules. It ships with a trie-based engine that produces compact, deterministic patterns (also used by the CLI).

## Installation
```bash
pip install rector
```

## Library usage
```python
from rector import TrieRegexGenerator

# Build a minimal trie-based pattern for larger sets or ranges
numbers = (
    TrieRegexGenerator()
    .add_examples([str(n) for n in range(10, 1000)])
    .generate()
)
assert numbers.pattern == "^[1-9][0-9]{1,2}$"

# Generate from small fixed-length samples
words = TrieRegexGenerator().add_examples(["cat", "car", "cap"]).generate()
assert words.pattern == r"^ca[prt]$"
```

## CLI
Pipe examples to `rector` and it prints the generated pattern to stdout:
```bash
printf "cat\ncar\ncap\n" | rector
# -> ^ca[prt]$
```
The CLI anchors patterns by default and exits with status 1 if no stdin input is provided.
Use `--dense-threshold` to adjust when near-contiguous character sets are collapsed into ranges
(accepts `fractions.Fraction` strings like `3/4` or `0.6`; default when flag is present without a value:
`8/10`).

## Behavior notes
- Patterns anchor to start/end unless you pass `anchor_start=False` or `anchor_end=False`.
- Examples must be strings; `TrieRegexGenerator` raises `TypeError` otherwise.
- `TrieRegexGenerator` builds a trie, minimizes it, and compacts ranges/quantifiers (using the density threshold for near-contiguous classes); it also accepts empty lines as valid examples.
