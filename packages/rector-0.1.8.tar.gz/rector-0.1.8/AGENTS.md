# Collaboration Guidelines

- Communicate with the user in the language they use; keep all project files, code, and documentation in English.
- Use detailed, descriptive commit messages (summaries plus context/rationale) following the Conventional Commits format.
- Always review current repository state before working: check for staged or unstaged changes since the last commit, because the user may have made their own edits.
- When crafting multi-line commit messages via here-docs, use `git commit -F - <<'EOF' ... EOF` and never try to make manual writes inside `.git`.
- Always run `pytest` after making changes to verify the suite.
- Always invoke `git add` and `git commit` with escalated permissions; never try to delete `index.lock` or force git state.
- When committing, prefer `make commit m="$(cat <<'EOF'\n...message...\nEOF\n)"` so lint/format/tests run first and the message supports multiple lines.
