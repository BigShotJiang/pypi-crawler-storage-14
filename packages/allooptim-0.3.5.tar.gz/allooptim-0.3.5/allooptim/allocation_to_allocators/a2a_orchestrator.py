"""A2A Orchestrator Base Classes.

Abstract base classes for Allocation-to-Allocators orchestration.
Provides clean separation between different orchestration strategies.
"""

import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional

import pandas as pd

from allooptim.allocation_to_allocators.a2a_result import A2AResult
from allooptim.allocation_to_allocators.simulator_interface import (
    AbstractObservationSimulator,
)
from allooptim.config.a2a_config import A2AConfig
from allooptim.config.cash_config import AllowCashOption
from allooptim.config.failure_diagnostics import (
    CircuitBreaker,
    FailureClassifier,
)
from allooptim.config.failure_handling_config import FailureHandlingOption
from allooptim.config.stock_dataclasses import StockUniverse
from allooptim.covariance_transformer.transformer_interface import (
    AbstractCovarianceTransformer,
)
from allooptim.optimizer.optimizer_interface import AbstractOptimizer


class AbstractA2AOrchestrator(ABC):
    """Abstract base class for Allocation-to-Allocators orchestration.

    Design Philosophy:
    - INTERFACE ONLY: No implementation in ABC
    - Receives data provider (not pre-computed allocations)
    - Controls when/how optimizers are called
    - Time-agnostic (operates on single time step)
    - Configuration-driven (Pydantic, not dicts)

    Note: Concrete implementations should inherit from BaseOrchestrator, not this class directly.
    """

    @abstractmethod
    def allocate(
        self,
        data_provider: AbstractObservationSimulator,
        time_today: Optional[datetime] = None,
        all_stocks: Optional[List["StockUniverse"]] = None,
    ) -> A2AResult:
        """Orchestrate allocation process for current time step.

        Args:
            data_provider: Provides ground truth and sampling capability for current time step
            time_today: Current time step (optional, can be derived from data_provider)
            all_stocks: List of all available stocks (optional, used by some orchestrators)

        Returns:
            A2AResult with final allocation and all statistics
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Orchestrator name for logging/reporting."""
        pass


class BaseOrchestrator(AbstractA2AOrchestrator):
    """Base implementation providing shared functionality for all orchestrators.

    Design Philosophy:
    - CONCRETE IMPLEMENTATION: Provides utility methods
    - NO ABSTRACT METHODS: Except allocate() from parent
    - SHARED LOGIC: Covariance transformation, result creation
    - EXTENSIBLE: Subclasses override allocate() only
    """

    def __init__(
        self,
        optimizers: List[AbstractOptimizer],
        covariance_transformers: List[AbstractCovarianceTransformer],
        config: A2AConfig,
    ):
        """Initialize orchestrator.

        Args:
            optimizers: List of optimizer instances
            covariance_transformers: List of covariance transformers to apply
            config: A2A configuration object
        """
        self.optimizers = optimizers
        self.covariance_transformers = covariance_transformers
        self.config = config

        # Initialize circuit breaker if enabled
        self.circuit_breaker = None
        if config.failure_handling.circuit_breaker_threshold is not None:
            self.circuit_breaker = CircuitBreaker(threshold=config.failure_handling.circuit_breaker_threshold)

        # Set allow_cash on optimizers based on cash configuration
        self._configure_optimizer_cash_settings()

    def _configure_optimizer_cash_settings(self) -> None:
        """Configure allow_cash and max_leverage settings on all optimizers based on cash configuration.

        Uses the AllowCashOption enum from cash_config to determine cash policy:
        - GLOBAL_ALLOW_CASH: Force all optimizers to allow cash
        - GLOBAL_FORBID_CASH: Force all optimizers to forbid cash
        - OPTIMIZER_DECIDES: Use each optimizer's default setting

        Also sets max_leverage from cash_config on all optimizers.
        """
        cash_option = self.config.cash_config.allow_cash_option

        if cash_option == AllowCashOption.GLOBAL_ALLOW_CASH:
            for optimizer in self.optimizers:
                optimizer.set_allow_cash(True)
        elif cash_option == AllowCashOption.GLOBAL_FORBID_CASH:
            for optimizer in self.optimizers:
                optimizer.set_allow_cash(False)
        # OPTIMIZER_DECIDES: Leave optimizers with their default settings

        # Set max_leverage on all optimizers
        max_leverage = self.config.cash_config.max_leverage
        for optimizer in self.optimizers:
            optimizer.set_max_leverage(max_leverage)

    def _should_allow_cash(self) -> bool:
        """Determine if cash positions should be allowed based on cash configuration.

        Returns:
            True if cash positions are allowed, False otherwise
        """
        return self.config.cash_config.allow_cash_option == AllowCashOption.GLOBAL_ALLOW_CASH

    def _apply_covariance_transformers(self, cov: pd.DataFrame, n_observations: int) -> pd.DataFrame:
        """Apply covariance transformation pipeline.

        Args:
            cov: Raw covariance matrix from data provider
            n_observations: Number of observations used to compute covariance

        Returns:
            Transformed covariance matrix
        """
        cov_transformed = cov
        for transformer in self.covariance_transformers:
            cov_transformed = transformer.transform(cov_transformed, n_observations)
        return cov_transformed

    def _handle_optimizer_failure(
        self,
        optimizer: AbstractOptimizer,
        exception: Exception,
        n_assets: int,
        asset_names: Optional[List[str]] = None,
    ) -> Optional[pd.Series]:
        """Handle optimizer failure according to configured failure handling strategy.

        Enhanced version with error classification, context-aware fallbacks,
        retry logic, circuit breaker, and diagnostics.

        Args:
            optimizer: The optimizer that failed
            exception: The exception that was raised
            n_assets: Number of assets in the portfolio
            asset_names: Optional list of asset names for index

        Returns:
            Fallback weights as pd.Series, or None to skip optimizer entirely
        """
        failure_config = self.config.failure_handling

        # Check circuit breaker first
        if self.circuit_breaker and self.circuit_breaker.is_open(optimizer.name):
            if failure_config.log_failures:
                logging.warning(f"Optimizer {optimizer.name} is circuit-breaker disabled, skipping")
            return None

        # Classify the failure
        failure_classifier = FailureClassifier()
        failure_type = failure_classifier.classify_failure(exception)

        # Determine handling strategy (context-aware or default)
        handling_option = failure_config.context_aware_fallbacks.get(failure_type, failure_config.option)

        # Log failure if enabled
        if failure_config.log_failures:
            logging.warning(f"Optimizer {optimizer.name} failed with {failure_type.value}: {exception}")

        # Record failure for circuit breaker
        if self.circuit_breaker:
            self.circuit_breaker.record_failure(optimizer.name)

        # Apply the determined handling strategy
        match handling_option:
            case FailureHandlingOption.ZERO_WEIGHTS:
                # Return all-zero weights (no investment)
                weights = pd.Series(0.0, index=asset_names or range(n_assets), name=optimizer.name)
                return weights
            case FailureHandlingOption.EQUAL_WEIGHTS:
                # Return 1/N naive diversification
                equal_weight = 1.0 / n_assets
                weights = pd.Series(equal_weight, index=asset_names or range(n_assets), name=optimizer.name)
                return weights

            case FailureHandlingOption.IGNORE_OPTIMIZER:
                # Skip optimizer entirely in ensemble combination
                return None

        raise NotImplementedError(f"Unknown FailureHandlingOption: {handling_option}")

    @abstractmethod
    def allocate(
        self,
        data_provider: AbstractObservationSimulator,
        time_today: Optional[datetime] = None,
        all_stocks: Optional[List[StockUniverse]] = None,
    ) -> A2AResult:
        """Orchestrate allocation process for current time step.

        Args:
            data_provider: Provides ground truth and sampling capability for current time step
            time_today: Current time step (optional, can be derived from data_provider)
            all_stocks: List of all available stocks (optional, used by some orchestrators)

        Returns:
            A2AResult with final allocation and all statistics

        Implementation Guide:
        1. Call data_provider.get_sample() as needed (Monte Carlo, Bootstrap, etc.)
        2. Unpack sample: mu, cov, prices, time, l_moments = data_provider.get_sample()
        3. Apply covariance transformers: cov_transformed = self._apply_covariance_transformers(cov, n_obs)
        4. Call optimizers: allocation = optimizer.allocate(mu, cov_transformed, prices, time, l_moments)
        5. Aggregate optimizer results (equal weight, PSO, meta-learning, etc.)
        6. Return A2AResult
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Orchestrator name for logging/reporting."""
        pass
