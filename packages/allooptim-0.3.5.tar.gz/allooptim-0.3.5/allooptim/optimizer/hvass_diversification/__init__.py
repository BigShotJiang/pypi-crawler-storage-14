"""Hvass diversification optimization algorithms."""

import logging

logger = logging.getLogger(__name__)
