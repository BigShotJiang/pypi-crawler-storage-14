#include <Python.h>
#include "nell_scb_c.h"

static PyObject* scb_api_create_qr(PyObject* self, PyObject* args) {
    const char* config_id;
    float amount;
    const char* reference;
    const char* channel = "ecomm";
    
    if (!PyArg_ParseTuple(args, "sfs|s", &config_id, &amount, &reference, &channel)) {
        return NULL;
    }
    
    // Call C implementation
    char* json_result = scb_create_qr_impl(config_id, amount, reference, channel);
    if (json_result == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "Failed to create QR code");
        return NULL;
    }
    
    PyObject* result = PyUnicode_FromString(json_result);
    scb_free(json_result);
    
    return result;
}

static PyObject* scb_api_check_payment(PyObject* self, PyObject* args) {
    const char* reference;
    
    if (!PyArg_ParseTuple(args, "s", &reference)) {
        return NULL;
    }
    
    // Call C implementation
    char* json_result = scb_check_payment_impl(reference);
    if (json_result == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "Failed to check payment status");
        return NULL;
    }
    
    PyObject* result = PyUnicode_FromString(json_result);
    scb_free(json_result);
    
    return result;
}

static PyObject* scb_api_refresh_token(PyObject* self, PyObject* args) {
    const char* api_key;
    const char* api_secret;
    const char* token_url;
    
    if (!PyArg_ParseTuple(args, "sss", &api_key, &api_secret, &token_url)) {
        return NULL;
    }
    
    // Call C implementation
    char* json_result = scb_refresh_token(api_key, api_secret, token_url);
    if (json_result == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "Failed to refresh token");
        return NULL;
    }
    
    PyObject* result = PyUnicode_FromString(json_result);
    scb_free(json_result);
    
    return result;
}

static PyObject* scb_api_create_qr_full(PyObject* self, PyObject* args) {
    const char* api_key;
    const char* access_token;
    const char* qr_create_url;
    const char* biller_id;
    float amount;
    const char* ref1;
    const char* ref2;
    const char* ref3;
    
    if (!PyArg_ParseTuple(args, "ssssfss|s", 
            &api_key, &access_token, &qr_create_url, &biller_id,
            &amount, &ref1, &ref2, &ref3)) {
        return NULL;
    }
    
    // Call C implementation
    char* json_result = scb_create_qr_full(
        api_key, access_token, qr_create_url, biller_id,
        amount, ref1, ref2, ref3
    );
    if (json_result == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "Failed to create QR code");
        return NULL;
    }
    
    PyObject* result = PyUnicode_FromString(json_result);
    scb_free(json_result);
    
    return result;
}

static PyObject* scb_api_create_qr_by_bank(PyObject* self, PyObject* args) {
    const char* bank_account_id;
    float amount;
    const char* ref1;
    const char* ref2;
    const char* ref3 = "SCB";
    
    if (!PyArg_ParseTuple(args, "sfss|s", 
            &bank_account_id, &amount, &ref1, &ref2, &ref3)) {
        return NULL;
    }
    
    // Call C implementation
    char* json_result = scb_create_qr_by_bank_account(
        bank_account_id, amount, ref1, ref2, ref3
    );
    if (json_result == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "Failed to create QR code via bank account");
        return NULL;
    }
    
    PyObject* result = PyUnicode_FromString(json_result);
    scb_free(json_result);
    
    return result;
}

static PyObject* internal_telemetry_init(PyObject* self, PyObject* args) {
    // Call C implementation (no arguments - fetches everything from database)
    int result = scb_telemetry_init();
    
    if (result) {
        Py_RETURN_TRUE;
    } else {
        Py_RETURN_FALSE;
    }
}

static PyMethodDef ScbMethods[] = {
    {"scb_api_create_qr", scb_api_create_qr, METH_VARARGS,
     "Create SCB QR code"},
    {"scb_api_create_qr_full", scb_api_create_qr_full, METH_VARARGS,
     "Create SCB QR code with full parameters"},
    {"scb_api_create_qr_by_bank", scb_api_create_qr_by_bank, METH_VARARGS,
     "Create SCB QR code using bank account ID (fetches config from database)"},
    {"scb_api_check_payment", scb_api_check_payment, METH_VARARGS,
     "Check SCB payment status"},
    {"scb_api_refresh_token", scb_api_refresh_token, METH_VARARGS,
     "Refresh SCB access token"},
    {"_internal_telemetry_init", internal_telemetry_init, METH_NOARGS,
     "Internal: Initialize telemetry (auto-called on module import)"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef scbmodule = {
    PyModuleDef_HEAD_INIT,
    "_binding",
    "Nellika SCB C Extension",
    -1,
    ScbMethods
};

PyMODINIT_FUNC PyInit__binding(void) {
    return PyModule_Create(&scbmodule);
}
