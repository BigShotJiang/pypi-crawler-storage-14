import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import CurrentStock, MetaArray, Stock


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetStock:
    """
    Example with options: --assortment-id=1234-5678-919dj-5252363
    """

    async def test_method(
        self, real_client: MoyskladAPI, default_params: dict, current: bool = False
    ):
        report = await real_client.get_stock(current, **default_params)
        if current:
            assert isinstance(report, list)
            assert all(isinstance(item, CurrentStock) for item in report)
        else:
            assert isinstance(report, MetaArray)
            assert all(isinstance(s, Stock) for s in report.rows)
