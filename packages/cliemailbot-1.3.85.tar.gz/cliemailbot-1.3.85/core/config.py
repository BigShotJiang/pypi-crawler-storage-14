# -*- coding: utf-8 -*-
import re
from threading import RLock
from typing import List, Dict, Iterator, Tuple

__all__ = ["add_gmail", "del_gmail", "get_all_gmail", "iter_gmail", "ACCOUNTS", "ADMINS"]

ACCOUNTS: List[Dict[str, str]] = []
_LOCK = RLock()

OWNER_ID: list[int] = []

def set_owner_ids(ids: list[int]):
    """
    تنظیم آی‌دی مالک (Owner IDs)
    در فایل main.py مقداردهی می‌شود تا برای هر کاربر جداگانه شخصی‌سازی شود.
    """
    global OWNER_ID
    OWNER_ID = ids

_EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def _validate_email(addr: str) -> bool:
    return bool(_EMAIL_REGEX.match(addr or ""))

def add_gmail(email: str, password: str) -> None: 
    email = (email or "").strip()
    password = (password or "").strip()

    if not _validate_email(email):
        raise ValueError("Invalid email format.")
    if not password:
        raise ValueError("Password (app password) cannot be empty.")

    with _LOCK:
        if any(item["email"].lower() == email.lower() for item in ACCOUNTS):
            return 
        ACCOUNTS.append({"email": email, "app_password": password})

def del_gmail(email: str) -> bool: 
    email = (email or "").strip()
    if not _validate_email(email):
        return False

    with _LOCK:
        before = len(ACCOUNTS) 
        remaining = [item for item in ACCOUNTS if item["email"].lower() != email.lower()]
        removed = len(remaining) < before
        if removed:
            ACCOUNTS.clear()
            ACCOUNTS.extend(remaining)
        return removed

def get_all_gmail() -> List[Dict[str, str]]: 
    with _LOCK:
        return list(ACCOUNTS)

def iter_gmail() -> Iterator[Tuple[str, str]]: 
    with _LOCK:
        snapshot = list(ACCOUNTS)
    for item in snapshot:
        yield item["email"], item["app_password"]

def load_admins() -> None: 
    global ADMINS 
    ADMINS = list(set(ADMINS))  

def update_admins(new_admins: List[int]) -> None: 
    global ADMINS
    ADMINS = list(set(new_admins))  
    load_admins() 

