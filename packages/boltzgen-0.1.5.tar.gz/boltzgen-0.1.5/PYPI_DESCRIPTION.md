<div align="center">
  <div>&nbsp;</div>
  <img src="https://raw.githubusercontent.com/HannesStark/boltzgen/main/assets/boltzgen.png" alt="BoltzGen logo" width="60%">

[Paper](https://hannes-stark.com/assets/boltzgen.pdf) | 
[Slack](https://boltz.bio/join-slack) <br> <br>
 ![alt text](https://raw.githubusercontent.com/HannesStark/boltzgen/main/assets/cover.png)
</div>

# Installation
In an environment with python >=3.11:
```bash
pip install boltzgen
```

For more details see the [GitHub](https://github.com/HannesStark/boltzgen/tree/main).