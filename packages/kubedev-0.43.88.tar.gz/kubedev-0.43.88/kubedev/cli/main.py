import sys

from kubedev import main

sys.exit(main())
