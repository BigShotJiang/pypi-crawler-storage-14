
Acknowledgements
-------------------------------------

* Dominik Marszk for general support and MAL header baseline implementation.
