
Installation
-------------------------------------

Install using pip:

.. code-block:: bash

   $ pip install minsp

Install package from the git repository:

.. code-block:: bash

    $ pip install git+https://github.com/nunorc/minsp@master
