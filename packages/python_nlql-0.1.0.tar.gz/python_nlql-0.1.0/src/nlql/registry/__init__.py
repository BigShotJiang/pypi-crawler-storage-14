"""Registry system for extensibility."""

from nlql.registry.embedding import get_embedding_provider, register_embedding_provider
from nlql.registry.functions import get_function, register_function
from nlql.registry.operators import get_operator, register_operator
from nlql.registry.splitters import get_splitter, register_splitter

__all__ = [
    "register_operator",
    "get_operator",
    "register_function",
    "get_function",
    "register_splitter",
    "get_splitter",
    "register_embedding_provider",
    "get_embedding_provider",
]

