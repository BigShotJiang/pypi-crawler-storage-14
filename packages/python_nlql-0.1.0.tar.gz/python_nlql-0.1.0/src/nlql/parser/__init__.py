"""NLQL parser module."""

from nlql.parser.parser import NLQLParser

__all__ = ["NLQLParser"]

