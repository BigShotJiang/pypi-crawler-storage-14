# Types API Reference

::: nlql.types.core.BaseType
    options:
      show_source: true
      heading_level: 2

::: nlql.types.core.NumberType
    options:
      show_source: true
      heading_level: 2

::: nlql.types.core.TextType
    options:
      show_source: true
      heading_level: 2

::: nlql.types.core.DateType
    options:
      show_source: true
      heading_level: 2

::: nlql.types.meta.MetaFieldRegistry
    options:
      show_source: true
      heading_level: 2

