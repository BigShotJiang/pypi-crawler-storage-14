# NLQL API Reference

::: nlql.api.NLQL
    options:
      show_source: true
      heading_level: 2

::: nlql.config.NLQLConfig
    options:
      show_source: true
      heading_level: 2

::: nlql.result.Result
    options:
      show_source: true
      heading_level: 2

