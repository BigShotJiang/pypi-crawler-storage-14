r"""The ElSabio web app."""

# Local
from elsabio.app.main import APP_PATH

# The Public API
__all__ = ['APP_PATH']
