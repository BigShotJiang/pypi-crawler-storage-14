COPYRIGHT = '''Copyright (C)2024-25, by maxpat78.'''
__version__ = '1.15'
__all__ = ["Vault", "init_vault", "backupDirIds"]
from .cryptomator import *
