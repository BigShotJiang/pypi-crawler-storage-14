#!/usr/bin/env python3
"""
STDIO MCP Server Implementation for OpenAI Code Assistant

This module provides stdio transport support for the Model Context Protocol.
"""

import json
import sys
import asyncio
import logging
from typing import Any, Dict, List, Optional
import os
from mcp_server import MCPServer

# Configure logging to stderr to avoid interfering with stdio communication
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr
)
logger = logging.getLogger("stdio_mcp_server")

class StdioMCPServer:
    """MCP Server with stdio transport"""
    
    def __init__(self):
        self.mcp_server = MCPServer()
        self.running = True
        
    async def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming MCP request"""
        try:
            method = request.get("method")
            params = request.get("params", {})
            
            if method == "initialize":
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id"),
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {
                            "tools": {},
                            "prompts": {},
                            "resources": {}
                        },
                        "serverInfo": {
                            "name": "openai-mcp",
                            "version": "1.0.0"
                        }
                    }
                }
            
            elif method == "tools/list":
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id"),
                    "result": {
                        "tools": [
                            {
                                "name": "generate_context",
                                "description": "Generate context using OpenAI models",
                                "inputSchema": {
                                    "type": "object",
                                    "properties": {
                                        "prompt": {
                                            "type": "string",
                                            "description": "The prompt to process"
                                        },
                                        "model": {
                                            "type": "string",
                                            "description": "Model to use (default: gpt-4o)",
                                            "default": "gpt-4o"
                                        }
                                    },
                                    "required": ["prompt"]
                                }
                            },
                            {
                                "name": "list_models",
                                "description": "List available OpenAI models",
                                "inputSchema": {
                                    "type": "object",
                                    "properties": {}
                                }
                            }
                        ]
                    }
                }
            
            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                
                if tool_name == "generate_context":
                    # Use the existing MCP server logic
                    prompt = arguments.get("prompt", "")
                    model = arguments.get("model", "gpt-4o")
                    
                    # Simple context generation
                    context = f"Generated context for prompt: {prompt[:100]}..."
                    
                    return {
                        "jsonrpc": "2.0",
                        "id": request.get("id"),
                        "result": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": context
                                }
                            ]
                        }
                    }
                
                elif tool_name == "list_models":
                    return {
                        "jsonrpc": "2.0",
                        "id": request.get("id"),
                        "result": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": "Available models: gpt-4o, gpt-4-turbo, gpt-3.5-turbo"
                                }
                            ]
                        }
                    }
                
                else:
                    return {
                        "jsonrpc": "2.0",
                        "id": request.get("id"),
                        "error": {
                            "code": -32601,
                            "message": f"Unknown tool: {tool_name}"
                        }
                    }
            
            elif method == "prompts/list":
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id"),
                    "result": {
                        "prompts": [
                            {
                                "name": "code_assistant",
                                "description": "OpenAI code assistant prompt",
                                "arguments": [
                                    {
                                        "name": "task",
                                        "description": "The coding task to perform",
                                        "required": True
                                    }
                                ]
                            }
                        ]
                    }
                }
            
            elif method == "prompts/get":
                prompt_name = params.get("name")
                if prompt_name == "code_assistant":
                    return {
                        "jsonrpc": "2.0",
                        "id": request.get("id"),
                        "result": {
                            "description": "OpenAI code assistant prompt",
                            "messages": [
                                {
                                    "role": "user",
                                    "content": {
                                        "type": "text",
                                        "text": "Please help me with this coding task: {{task}}"
                                    }
                                }
                            ]
                        }
                    }
                else:
                    return {
                        "jsonrpc": "2.0",
                        "id": request.get("id"),
                        "error": {
                            "code": -32601,
                            "message": f"Unknown prompt: {prompt_name}"
                        }
                    }
            
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id"),
                    "error": {
                        "code": -32601,
                        "message": f"Unknown method: {method}"
                    }
                }
                
        except Exception as e:
            logger.error(f"Error handling request: {str(e)}", exc_info=True)
            return {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "error": {
                    "code": -32603,
                    "message": f"Internal error: {str(e)}"
                }
            }
    
    async def run(self):
        """Run the stdio MCP server"""
        logger.info("Starting OpenAI MCP Server with stdio transport")
        
        try:
            while self.running:
                # Read line from stdin
                line = await asyncio.get_event_loop().run_in_executor(
                    None, sys.stdin.readline
                )
                
                if not line:
                    break
                
                line = line.strip()
                if not line:
                    continue
                
                try:
                    # Parse JSON-RPC request
                    request = json.loads(line)
                    
                    # Handle the request
                    response = await self.handle_request(request)
                    
                    # Send response to stdout
                    print(json.dumps(response), flush=True)
                    
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON received: {e}")
                    error_response = {
                        "jsonrpc": "2.0",
                        "id": None,
                        "error": {
                            "code": -32700,
                            "message": "Parse error"
                        }
                    }
                    print(json.dumps(error_response), flush=True)
                
        except KeyboardInterrupt:
            logger.info("Server interrupted")
        except Exception as e:
            logger.error(f"Server error: {str(e)}", exc_info=True)
        finally:
            logger.info("Server stopped")

def main():
    """Main entry point for stdio MCP server"""
    server = StdioMCPServer()
    asyncio.run(server.run())

if __name__ == "__main__":
    main()