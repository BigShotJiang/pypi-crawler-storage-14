from django.apps import AppConfig

class CoreAuthConfig(AppConfig):
    name = 'django_core_micha.auth'
    label = 'core_auth'

    def ready(self):
        import django_core_micha.auth.signals