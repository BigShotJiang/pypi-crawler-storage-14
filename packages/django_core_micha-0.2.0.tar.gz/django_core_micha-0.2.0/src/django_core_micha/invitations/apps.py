from django.apps import AppConfig


class InvitationsCoreConfig(AppConfig):
    name = "django_core_micha.invitations"
    label = "django_core_micha_invitations"
    verbose_name = "Core Invitations"
