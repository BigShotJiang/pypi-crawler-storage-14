from setuptools import setup, find_packages

setup(
    name="raep",  # 记得改个唯一的名字
    version="0.0.1",
    author="DHY",
    author_email="dhy.scut@outlook.com",
    description="RAEP model package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True, 
    package_data={
        '': ['*.pth', '*.pkl', '*.json', '*.csv'], 
    },
    python_requires='>=3.6',
    install_requires=[
        "numpy",
        "pandas",
        "scikit-learn",
        "joblib",
        "xgboost",
        "torch>=1.7.0",
    ],
)
