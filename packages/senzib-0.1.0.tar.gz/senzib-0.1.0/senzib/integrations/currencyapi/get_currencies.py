"""
senzib.integrations.currencyapi.get_currencies

Утилиты поверх CurrencyAPIClient для быстрой работы
с метаданными валют.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import CurrencyAPIClient

JsonDict = Dict[str, Any]


def fetch_currencies(
    api_key: str,
    codes: Optional[List[str]] = None,
) -> JsonDict:
    """
    Простой хелпер: создать клиент и получить currencies.

    :param api_key: API-ключ CurrencyAPI.
    :param codes: список кодов валют (["USD", "EUR"]) или None для всех доступных.
    :return: сырой dict, как возвращает client.get_currencies().
    """
    client = CurrencyAPIClient(api_key=api_key)
    return client.get_currencies(codes=codes)


def fetch_currencies_map(
    api_key: str,
    codes: Optional[List[str]] = None,
) -> Dict[str, JsonDict]:
    """
    Возвращает удобный маппинг {code: currency_info}.

    На основе ответа CurrencyAPI /v3/currencies, который выглядит примерно так:

        {
            "data": {
                "USD": {...},
                "EUR": {...},
                ...
            }
        }

    Эта функция просто достаёт поле "data" или возвращает {}.
    """
    raw = fetch_currencies(api_key=api_key, codes=codes)
    data = raw.get("data") or {}
    # На случай, если API вернуло не совсем стандартный формат:
    if not isinstance(data, dict):
        return {}
    return data


"""
ПРИМЕР ИСПОЛЬЗОВАНИЯ

from senzib.integrations.currencyapi.get_currencies import fetch_currencies_map

API_KEY = settings.CURRENCYAPI_KEY  # откуда-то из конфига

def get_currencies_for_front():
    currencies = fetch_currencies_map(API_KEY, codes=["USD", "EUR", "UZS"])
    # можешь сохранить в БД/файл/кэш, а потом уже отдавать через свой Flask-эндпоинт
    return currencies
"""