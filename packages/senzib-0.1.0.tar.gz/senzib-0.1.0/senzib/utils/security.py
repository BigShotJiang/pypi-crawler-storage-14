"""
senzib.utils.security

Небольшие помощники по безопасности:

- HMAC-подпись (например, для вебхуков).
- Проверка подписи с защитой от timing-attack.
- Генератор случайных токенов.
"""

from __future__ import annotations

import hmac
import hashlib
import secrets
from typing import Union


BytesLike = Union[str, bytes]


def _to_bytes(value: BytesLike) -> bytes:
    if isinstance(value, bytes):
        return value
    return str(value).encode("utf-8")


def generate_hmac_signature(
    secret: BytesLike,
    message: BytesLike,
    *,
    algo: str = "sha256",
) -> str:
    """
    Генерирует HMAC-подпись.

    :param secret: секретный ключ (строка или bytes).
    :param message: сообщение (строка или bytes).
    :param algo: алгоритм хеша (sha256, sha1, ...).
    :return: hex-строка подписи.

    Пример:
        sig = generate_hmac_signature(SECRET, body, algo="sha256")
    """
    digestmod = getattr(hashlib, algo)
    return hmac.new(_to_bytes(secret), _to_bytes(message), digestmod).hexdigest()


def verify_hmac_signature(
    secret: BytesLike,
    message: BytesLike,
    signature: BytesLike,
    *,
    algo: str = "sha256",
) -> bool:
    """
    Проверяет HMAC-подпись, используя сравнение, устойчивое к timing-attack.

    :param secret: секретный ключ.
    :param message: сообщение.
    :param signature: ожидаемая подпись (строка или bytes).
    :param algo: алгоритм хеша.
    :return: True, если подпись совпадает, иначе False.
    """
    expected = generate_hmac_signature(secret, message, algo=algo)
    return hmac.compare_digest(expected, _to_bytes(signature).decode("utf-8"))


def generate_random_token(length: int = 32) -> str:
    """
    Генерация криптографически стойкого случайного токена.

    :param length: длина токена в байтах (до hex-представления).
    :return: hex-строка токена длиной 2*length.

    Пример:
        token = generate_random_token(16)  # 32 hex-символа
    """
    return secrets.token_hex(length)


__all__ = [
    "generate_hmac_signature",
    "verify_hmac_signature",
    "generate_random_token",
]
