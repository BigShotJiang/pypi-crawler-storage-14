"""
senzib.utils.log

Логирование для библиотеки senzib.

По умолчанию:
- создаём логгер "senzib" с NullHandler, чтобы не ломать
  конфигурацию приложения.
- при желании можно вызвать setup_basic_logging(), чтобы
  быстро получить вывод в stdout.
"""

from __future__ import annotations

import logging
from typing import Optional


LOGGER_NAME = "senzib"


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Возвращает логгер библиотеки.

    :param name:
        Если None — вернёт корневой логгер "senzib".
        Если указать имя — вернёт "senzib.<name>".

    Пример:
        logger = get_logger()
        logger.info("Hello")

        api_logger = get_logger("api")
        api_logger.debug("Request ...")
    """
    full_name = LOGGER_NAME if name is None else f"{LOGGER_NAME}.{name}"
    logger = logging.getLogger(full_name)
    return logger


# Инициализируем базовый "senzib" с NullHandler,
# чтобы отсутствие конфигурации у приложения не вызывало предупреждений.
_root_logger = get_logger()
if not _root_logger.handlers:
    _root_logger.addHandler(logging.NullHandler())


def setup_basic_logging(level: int = logging.INFO) -> None:
    """
    Простая настройка логгера для скриптов/тестов.

    В реальных приложениях лучше настраивать logging самостоятельно.

    Пример:

        from senzib.utils.log import setup_basic_logging, get_logger

        setup_basic_logging()
        logger = get_logger()
        logger.info("Senzib lib ready")
    """
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "[%(levelname)s] %(asctime)s - %(name)s: %(message)s"
    )
    handler.setFormatter(formatter)

    root = logging.getLogger(LOGGER_NAME)
    root.setLevel(level)

    # Убираем NullHandler (если есть) и ставим StreamHandler
    root.handlers.clear()
    root.addHandler(handler)


__all__ = [
    "LOGGER_NAME",
    "get_logger",
    "setup_basic_logging",
]
