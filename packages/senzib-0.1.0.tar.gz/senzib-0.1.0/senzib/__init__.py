"""
senzib

Core package for Senzib integrations library.

Использование (рекомендуемый стиль):

    from senzib.integrations.amocrm.client import AmoCRMClient
    from senzib.integrations.profitbase.client import ProfitbaseClient
    from senzib.utils.log import get_logger
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    # Имя проекта из pyproject.toml (см. ниже)
    __version__ = version("senzib")
except PackageNotFoundError:
    # На dev-этапе, когда пакет ещё не установлен,
    # версия может быть недоступна.
    __version__ = "0.0.0"

# Ничего не реэкспортируем — пусть разработчики явно
# ходят в senzib.integrations.* и senzib.utils.*
__all__ = ["__version__"]
