"""gRPC support for Forthic multi-runtime communication."""

from forthic.grpc.runtime_manager import RuntimeManager

__all__ = ["RuntimeManager"]
