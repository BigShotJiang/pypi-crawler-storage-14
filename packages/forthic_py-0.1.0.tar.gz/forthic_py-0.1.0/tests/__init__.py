"""Tests for Forthic Python runtime."""
