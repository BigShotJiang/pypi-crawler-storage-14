"""Unit tests for gRPC functionality"""
