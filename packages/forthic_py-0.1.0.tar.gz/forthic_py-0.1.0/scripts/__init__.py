"""Utility scripts for Forthic Python implementation."""
