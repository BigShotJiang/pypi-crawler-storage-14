"""Examples for Forthic Python runtime"""
