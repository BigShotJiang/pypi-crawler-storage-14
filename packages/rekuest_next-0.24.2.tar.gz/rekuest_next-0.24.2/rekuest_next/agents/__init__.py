"""Base class for all agents."""
