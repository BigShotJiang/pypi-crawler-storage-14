"""Stuff for defining Rekuest Next API endpoints."""
