"""General serialzion logic for Rekuest Next"""
