import pydantic

class Event(pydantic.BaseModel):    
    pass