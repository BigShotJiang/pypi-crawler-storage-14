"""
wlk - Alias package for whisperlivekit

This package is an alias for whisperlivekit. All imports are redirected to whisperlivekit.
"""

# Import everything from whisperlivekit
from whisperlivekit import *
from whisperlivekit import __all__

__version__ = "0.2.16.dev0"

# Re-export __all__ from whisperlivekit
__all__ = __all__

