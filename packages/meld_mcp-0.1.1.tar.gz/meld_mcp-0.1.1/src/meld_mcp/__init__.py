"""Meld MCP Server - Connects Claude Code to Meld cloud."""

__version__ = "0.1.0"

