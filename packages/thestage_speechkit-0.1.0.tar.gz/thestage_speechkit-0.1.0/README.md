# thestage_speechkit

A placeholder package for Whisper-related functionality.

## Version

0.1.0

## Installation

```bash
pip install -e .
```

## Usage

```python
import thestage_speechkit

print(thestage_speechkit.__version__)
```

## License

MIT

