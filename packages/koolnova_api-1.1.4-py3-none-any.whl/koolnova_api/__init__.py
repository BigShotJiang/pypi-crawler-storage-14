"""Flipr API REST Client."""

from .client import KoolnovaAPIRestClient

__all__ = ["KoolnovaAPIRestClient"]
