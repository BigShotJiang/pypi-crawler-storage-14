# -*- coding: utf-8 -*-
"""Consts for Koolnova python client API."""

KOOLNOVA_API_URL = "https://api.koolnova.com"
KOOLNOVA_AUTH_URL = KOOLNOVA_API_URL + "/auth/v2/login/"
