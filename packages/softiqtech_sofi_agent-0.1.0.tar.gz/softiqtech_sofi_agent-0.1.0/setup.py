from setuptools import setup, find_packages

setup(
    name="SoftiqTech_Sofi_Agent",  # Your package name on PyPI
    version="0.1.0",  # Update version as needed
    author="SoftiqTech",
    author_email="infosoftiqtech@gmail.com",
    description="An AI Agent of SoftiqTech Website named as Sofi use to assist the user with the content softiqtech having in its website",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="",  # optional
    packages=find_packages(),  # automatically finds all Python packages
    include_package_data=True,  # include files like frontend_build if specified in MANIFEST.in
    install_requires=[
       "fastapi>=0.95.0",
        "uvicorn[standard]>=0.20.0",
        "requests>=2.28.0",
        "python-dotenv>=1.0.0",
        "openai-agents"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',  # or your Python version
)
