created a venv:
py -m venv venv

activate venv

install packages:
1) FastApi
2) uvicorn
3) openai-agents