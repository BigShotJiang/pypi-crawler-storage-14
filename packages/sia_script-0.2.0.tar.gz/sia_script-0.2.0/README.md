SIA — Simplified Integrated Architecture

SIA (Simplified Integrated Architecture) by SIA SOFTWARE INNOVATIONS is a unified framework designed for learning, experimentation, enterprise logic execution, chemical computation, and object modeling. The project integrates multiple modules into one consistent architecture.



The first module is SIA-ELS, the Enterprise Logic Studio, which is a full ABAP-style interpreter written entirely in Python. It supports strict ABAP grammar including DATA, WRITE, IF, ELSEIF, LOOP, CASE, DO, WHILE, internal tables with APPEND and LOOP AT, SQL-style SELECT INTO TABLE emulation, structure creation using VALUE #( ), and requires the sia ... sia wrapper around code. It also includes an interactive REPL. Example usage: running ABAP-like code from Python using els\_run, where ABAP statements are placed inside the sia and sia markers.



The second module is SiaNTT, a lightweight entity/object meta-modeling system. It allows simple entity definitions and object creation using intuitive patterns, useful for rapid modeling of structured data or OOP concepts.



The third module is SiaCHI, a chemical analysis utility for molecular calculations. It provides calculation of molar mass and related analytical functionality through a simple API.



Installation is done through: pip install sia-script.



Usage is straightforward. For the ABAP interpreter, import els\_run. For the REPL mode, import and call els\_repl. For chemical utilities, import chi. For entity modeling, import ntt.



The ABAP interpreter also supports SQL emulation and internal table processing. For example, you can SELECT records from a built-in table such as “employees”, place them into an internal table, count rows using LINES( ), and iterate using LOOP AT.



Author: Naga Sai Durga Nagesh, Founder of SIA SOFTWARE INNOVATIONS. Contact: sbvnagesh00@gmail.com

.



Vision: To unify logical, analytical, and modeling frameworks into a single Simplified Integrated Architecture — SIA.

