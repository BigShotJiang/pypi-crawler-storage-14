"""
SIA ENTERPRISE LOGIC STUDIO
-----------------------------------------
Full ABAP Interpreter - Strict Grammar
Single-file version (els.py)
Author: Nagesh
Version: 1.0
-----------------------------------------

This module implements:

- Strict ABAP lexer
- Strict ABAP grammar parser
- Expression evaluator
- Runtime engine
- SQL emulator
- Object-oriented engine
- Internal table engine
- WRITE engine
- Full program execution

Outer wrapper required:
*sia
   ABAP code...
sia*
"""

# =====================================================
# ===============   LEXICAL ANALYSIS   ================
# =====================================================

import re
import sys

class Token:
    def __init__(self, kind, value, line, col):
        self.kind = kind      # e.g. ID, NUMBER, STRING, SYMBOL, KEYWORD
        self.value = value
        self.line = line
        self.col = col

    def __repr__(self):
        return f"Token({self.kind}, {self.value})"


# ABAP keywords (strict)
ABAP_KEYWORDS = {
    "DATA", "TYPES", "TYPE", "LIKE",
    "WRITE", "CLEAR", "MOVE",
    "APPEND", "INSERT", "MODIFY", "DELETE",
    "LOOP", "AT", "INTO", "ENDLOOP",
    "READ", "TABLE", "WITH", "KEY",
    "IF", "ELSEIF", "ELSE", "ENDIF",
    "WHILE", "ENDWHILE",
    "DO", "TIMES", "ENDDO",
    "CASE", "WHEN", "ENDCASE",
    "BEGIN", "OF", "END",
    "SELECT", "FROM", "WHERE", "INTO",
    "CREATE", "OBJECT",
    "CALL", "METHOD",
    "EXPORTING", "IMPORTING", "CHANGING",
    "RETURNING", "VALUE",
    "CLASS", "DEFINITION", "PUBLIC", "SECTION",
    "PRIVATE", "PROTECTED",
    "IMPLEMENTATION", "ENDCLASS",
}


TOKEN_PATTERNS = [
    ("STRING",   r"'([^']*)'"),
    ("NUMBER",   r"\b\d+\b"),
    ("ID",       r"[A-Za-z_][A-Za-z0-9_]*"),
    ("SYMBOL",   r"->|==|!=|<=|>=|:=|[-+*/=().,:]"),
    ("NEWLINE",  r"[\n]"),
    ("SKIP",     r"[ \t\r]+"),
    ("COMMENT",  r"\*.*?$|\".*?$"),
]

TOKEN_REGEX = re.compile(
    "|".join(f"(?P<{name}>{regex})" for name, regex in TOKEN_PATTERNS),
    re.MULTILINE
)


def tokenize_abap(src):
    """
    Convert ABAP source into tokens.
    Strict ABAP mode.
    """
    tokens = []
    line = 1
    col = 1

    for m in TOKEN_REGEX.finditer(src):
        kind = m.lastgroup
        value = m.group()

        if kind == "NEWLINE":
            line += 1
            col = 1
            continue

        if kind == "SKIP":
            col += len(value)
            continue

        if kind == "COMMENT":
            col += len(value)
            continue

        # Identify keywords
        if kind == "ID":
            upper = value.upper()
            if upper in ABAP_KEYWORDS:
                kind = "KEYWORD"
                value = upper
            else:
                value = value.lower()  # ABAP identifiers may be case-insensitive

        tok = Token(kind, value, line, col)
        tokens.append(tok)
        col += len(value)

    return tokens
# =====================================================
# ===============     AST DEFINITIONS    ==============
# =====================================================

class Node: 
    pass

class Program(Node):
    def __init__(self, statements):
        self.statements = statements

# ----- Statements -----

class Write(Node):
    def __init__(self, items):
        self.items = items  # list of expressions or newline markers

class DataDecl(Node):
    def __init__(self, name, type_spec=None, value=None):
        self.name = name
        self.type_spec = type_spec
        self.value = value

class Assign(Node):
    def __init__(self, target, expr):
        self.target = target     # variable name or field access
        self.expr = expr

class Append(Node):
    def __init__(self, source_row, target_table):
        self.source_row = source_row  # dict of field → expr
        self.target_table = target_table

class AppendSimple(Node):
    def __init__(self, source_var, target_table):
        self.source_var = source_var
        self.target_table = target_table

class LoopAt(Node):
    def __init__(self, table, into, body):
        self.table = table
        self.into = into
        self.body = body

class If(Node):
    def __init__(self, cond, then_body, elif_list, else_body):
        self.cond = cond
        self.then_body = then_body
        self.elif_list = elif_list  # list of (cond, body)
        self.else_body = else_body

class While(Node):
    def __init__(self, cond, body):
        self.cond = cond
        self.body = body

class Do(Node):
    def __init__(self, times_expr, body):
        self.times_expr = times_expr
        self.body = body

class SelectInto(Node):
    def __init__(self, table_name, into_table, where_clause=None):
        self.table_name = table_name
        self.into_table = into_table
        self.where = where_clause  # (field, expr)

# ----- Expressions -----

class Var(Node):
    def __init__(self, name):
        self.name = name

class Number(Node):
    def __init__(self, val):
        self.val = int(val)

class String(Node):
    def __init__(self, val):
        self.val = val

class Field(Node):
    def __init__(self, struct, field):
        self.struct = struct
        self.field = field

class BinOp(Node):
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

class FuncCall(Node):
    def __init__(self, name, args):
        self.name = name.upper()
        self.args = args

# ============================================
#            EXPRESSION PARSER
# ============================================

class ParserError(Exception):
    pass

class Parser:
    def __init__(self, tokens):
        self.t = tokens
        self.i = 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def next(self):
        tok = self.peek()
        if tok: self.i += 1
        return tok

    def accept(self, kind_or_value):
        tok = self.peek()
        if tok and (tok.kind == kind_or_value or tok.value == kind_or_value):
            self.i += 1
            return tok
        return None

    def expect(self, kind_or_value):
        tok = self.peek()
        if not tok or (tok.kind != kind_or_value and tok.value != kind_or_value):
            raise ParserError(f"Expected {kind_or_value}, got {tok}")
        self.i += 1
        return tok

    # --------------------------------------------
    #  Primary: numbers, strings, variables, func()
    # --------------------------------------------
    def parse_primary(self):
        tok = self.peek()
        if not tok:
            raise ParserError("Unexpected end in expression")

        # number
        if tok.kind == "NUMBER":
            self.next()
            return Number(tok.value)

        # string
        if tok.kind == "STRING":
            self.next()
            return String(tok.value.strip("'"))

        # identifier or field or function-call
        if tok.kind in ("ID", "KEYWORD"):
            self.next()
            name = tok.value

            # function call: NAME(...)
            if self.accept("("):
                args = []
                if not self.accept(")"):
                    while True:
                        args.append(self.parse_expr())
                        if self.accept(")"):
                            break
                        self.expect(",")
                return FuncCall(name, args)

            # field access: wa-field
            if self.accept("-"):
                field = self.expect("ID").value
                return Field(name, field)

            return Var(name)

        # parenthesis
        if self.accept("("):
            e = self.parse_expr()
            self.expect(")")
            return e

        raise ParserError(f"Unexpected token {tok}")

    # ---------------------------------------
    #  Unary operators (not used much in ABAP)
    # ---------------------------------------
    def parse_unary(self):
        return self.parse_primary()

    # ---------------------------------------
    #  Multiplicative: *, /
    # ---------------------------------------
    def parse_mul(self):
        node = self.parse_unary()
        while True:
            tok = self.peek()
            if tok and tok.value in ("*", "/"):
                op = self.next().value
                rhs = self.parse_unary()
                node = BinOp(node, op, rhs)
            else:
                break
        return node

    # ---------------------------------------
    #  Additive: +, -
    # ---------------------------------------
    def parse_add(self):
        node = self.parse_mul()
        while True:
            tok = self.peek()
            if tok and tok.value in ("+", "-"):
                op = self.next().value
                rhs = self.parse_mul()
                node = BinOp(node, op, rhs)
            else:
                break
        return node

    # ---------------------------------------
    #  Comparisons
    # ---------------------------------------
    def parse_compare(self):
        node = self.parse_add()
        tok = self.peek()
        if tok and tok.value in ("=", "<>", ">", "<", ">=", "<="):
            op = self.next().value
            rhs = self.parse_add()
            return BinOp(node, op, rhs)
        return node

    # ---------------------------------------
    #  Top-level expression
    # ---------------------------------------
    def parse_expr(self):
        return self.parse_compare()
# =====================================================
# ===============    STATEMENT PARSER    ==============
# =====================================================

class FullParser(Parser):

    # -----------------------------------------------
    #  Program entry point
    # -----------------------------------------------
    def parse_program(self):
        statements = []
        while self.peek():
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        return Program(statements)

    # -----------------------------------------------
    #  Parse one ABAP statement (ends with ".")
    # -----------------------------------------------
    def parse_statement(self):
        tok = self.peek()
        if not tok:
            return None

        # WRITE
        if tok.value == "WRITE":
            return self.parse_write_stmt()

        # DATA
        if tok.value == "DATA":
            return self.parse_data_stmt()

        # ASSIGNMENT e.g. lv_a = lv_b + 1.
        if tok.kind == "ID" and self.lookahead("="):
            return self.parse_assignment()

        # APPEND
        if tok.value == "APPEND":
            return self.parse_append_stmt()

        # LOOP AT …
        if tok.value == "LOOP":
            return self.parse_loop()

        # IF / ELSEIF / ELSE / ENDIF
        if tok.value == "IF":
            return self.parse_if_block()

        # WHILE
        if tok.value == "WHILE":
            return self.parse_while()

        # DO / TIMES
        if tok.value == "DO":
            return self.parse_do()

        # CASE
        if tok.value == "CASE":
            return self.parse_case()

        # SELECT
        if tok.value == "SELECT":
            return self.parse_select()

        # CREATE OBJECT
        if tok.value == "CREATE":
            return self.parse_create_object()

        # CALL METHOD
        if tok.value == "CALL":
            return self.parse_call_method()

        # CLASS DEFINITION / IMPLEMENTATION
        if tok.value == "CLASS":
            return self.parse_class_block()

        # Unknown → skip token
        unknown = self.next()
        # Skip until period for safety
        if self.accept("."):
            pass
        return Node()  # unknown

    # Utility: look ahead 1 token
    def lookahead(self, value):
        tok = self.peek()
        if not tok: return False
        nxt = self.t[self.i+1] if (self.i+1)<len(self.t) else None
        return nxt and nxt.value == value

    # -----------------------------------------------
    #  WRITE: expr [, expr ...].
    #  WRITE: / 'Text'.
    # -----------------------------------------------
    def parse_write_stmt(self):
        self.expect("KEYWORD")  # WRITE

        items = []
        if self.accept(":"):
            pass

        while self.peek() and not self.accept("."):
            # newline: "/"
            if self.accept("/"):
                items.append(String("\n"))
                continue

            # comma separator
            if self.accept(","):
                continue

            # expression
            items.append(self.parse_expr())

        return Write(items)

    # -----------------------------------------------
    #  DATA: lv_a TYPE i VALUE 10.
    # -----------------------------------------------
    def parse_data_stmt(self):
        self.expect("KEYWORD")  # DATA
        self.accept(":")  # optional

        name = self.expect("ID").value

        type_spec = None
        value_expr = None

        if self.accept("TYPE"):
            type_spec = self.expect("ID").value

        if self.accept("VALUE"):
            value_expr = self.parse_expr()

        self.expect(".")
        return DataDecl(name, type_spec, value_expr)

    # -----------------------------------------------
    #  ASSIGNMENT: lv = expr.
    # -----------------------------------------------
    def parse_assignment(self):
        # left side can be:
        #  ID
        #  ID - ID    (field access)
        left = self.expect("ID").value

        field = None
        if self.accept("-"):
            field = self.expect("ID").value

        self.expect("=")
        expr = self.parse_expr()
        self.expect(".")

        if field:
            return Assign(Field(left, field), expr)
        return Assign(Var(left), expr)

    # -----------------------------------------------
    #  APPEND VALUE #( field = expr ... ) TO itab.
    #  APPEND wa TO itab.
    # -----------------------------------------------
    def parse_append_stmt(self):
        self.expect("APPEND")

        # APPEND VALUE #( ... ) TO itab
        if self.accept("VALUE"):
            self.expect("#")
            self.expect("(")
            row = {}

            while not self.accept(")"):
                key = self.expect("ID").value
                self.expect("=")
                val = self.parse_expr()
                row[key] = val
                self.accept(",")  # optional comma

            self.expect("TO")
            target = self.expect("ID").value
            self.expect(".")
            return Append(row, target)

        # APPEND wa TO itab
        source = self.expect("ID").value
        self.expect("TO")
        target = self.expect("ID").value
        self.expect(".")
        return AppendSimple(source, target)

    # -----------------------------------------------
    #  LOOP AT itab INTO wa. ... ENDLOOP.
    # -----------------------------------------------
    def parse_loop(self):
        self.expect("LOOP")
        self.expect("AT")
        table = self.expect("ID").value
        self.expect("INTO")
        into = self.expect("ID").value
        self.expect(".")

        body = []
        while True:
            if self.peek() and self.peek().value == "ENDLOOP":
                break
            body.append(self.parse_statement())

        self.expect("ENDLOOP")
        self.expect(".")
        return LoopAt(table, into, body)

    # -----------------------------------------------
    #  IF cond. ... ELSEIF cond. ... ELSE. ... ENDIF.
    # -----------------------------------------------
    def parse_if_block(self):
        self.expect("IF")
        cond = self.parse_expr()
        self.expect(".")

        then_body = []
        while True:
            tok = self.peek()
            if not tok:
                raise ParserError("Missing ENDIF")
            if tok.value in ("ELSEIF", "ELSE", "ENDIF"):
                break
            then_body.append(self.parse_statement())

        # ELSEIF list
        elif_list = []
        while self.accept("ELSEIF"):
            c = self.parse_expr()
            self.expect(".")
            block = []
            while True:
                tok = self.peek()
                if tok.value in ("ELSEIF", "ELSE", "ENDIF"):
                    break
                block.append(self.parse_statement())
            elif_list.append((c, block))

        # ELSE
        else_body = []
        if self.accept("ELSE"):
            self.expect(".")
            while True:
                tok = self.peek()
                if tok.value == "ENDIF":
                    break
                else_body.append(self.parse_statement())

        self.expect("ENDIF")
        self.expect(".")

        return If(cond, then_body, elif_list, else_body)

    # -----------------------------------------------
    #  WHILE cond. ... ENDWHILE.
    # -----------------------------------------------
    def parse_while(self):
        self.expect("WHILE")
        cond = self.parse_expr()
        self.expect(".")

        body = []
        while True:
            if self.peek().value == "ENDWHILE":
                break
            body.append(self.parse_statement())

        self.expect("ENDWHILE")
        self.expect(".")
        return While(cond, body)

    # -----------------------------------------------
    #  DO n TIMES. ... ENDDO.
    # -----------------------------------------------
    def parse_do(self):
        self.expect("DO")
        times_expr = None

        if self.peek() and self.peek().kind != "SYMBOL":
            times_expr = self.parse_expr()

        if self.accept("TIMES"):
            pass

        self.expect(".")

        body = []
        while True:
            if self.peek().value == "ENDDO":
                break
            body.append(self.parse_statement())

        self.expect("ENDDO")
        self.expect(".")

        return Do(times_expr, body)

    # -----------------------------------------------
    #  CASE expr. WHEN x. ... ENDCASE.
    # -----------------------------------------------
    def parse_case(self):
        self.expect("CASE")
        expr = self.parse_expr()
        self.expect(".")

        cases = []  # list: (value_expr, body_list)
        else_body = []

        while True:
            tok = self.peek()
            if not tok:
                raise ParserError("Missing ENDCASE")

            if tok.value == "WHEN":
                self.next()
                val = self.parse_expr()
                self.expect(".")
                block = []
                while True:
                    tok2 = self.peek()
                    if tok2.value in ("WHEN", "ENDCASE"):
                        break
                    block.append(self.parse_statement())
                cases.append((val, block))
                continue

            if tok.value == "ENDCASE":
                break

        self.expect("ENDCASE")
        self.expect(".")

        # Return a tuple block
        return ("CASE", expr, cases)

    # -----------------------------------------------
    #  SELECT * FROM table INTO TABLE itab.
    #  SELECT * FROM table INTO TABLE itab WHERE field = expr.
    # -----------------------------------------------
    def parse_select(self):
        self.expect("SELECT")
        self.expect("*")
        self.expect("FROM")

        table = self.expect("ID").value

        where = None
        if self.accept("WHERE"):
            field = self.expect("ID").value
            self.expect("=")
            expr = self.parse_expr()
            where = (field, expr)

        self.expect("INTO")
        self.expect("TABLE")
        target = self.expect("ID").value
        self.expect(".")

        return SelectInto(table, target, where)

    # -----------------------------------------------
    #  CREATE OBJECT obj TYPE classname.
    # -----------------------------------------------
    def parse_create_object(self):
        self.expect("CREATE")
        self.expect("OBJECT")
        obj = self.expect("ID").value
        self.expect("TYPE")
        cls = self.expect("ID").value
        self.expect(".")
        return ("CREATE_OBJ", obj, cls)

    # -----------------------------------------------
    #  CALL METHOD obj->method.
    # -----------------------------------------------
    def parse_call_method(self):
        self.expect("CALL")
        self.expect("METHOD")
        obj = self.expect("ID").value
        self.expect("->")
        meth = self.expect("ID").value
        self.expect(".")
        return ("CALL_METH", obj, meth)

    # -----------------------------------------------
    #  CLASS ... DEFINITION / IMPLEMENTATION / ENDCLASS
    #  (We parse and store structure, full engine in Part 4/5)
    # -----------------------------------------------
    def parse_class_block(self):
        self.expect("CLASS")
        name = self.expect("ID").value
        mode = None

        if self.accept("DEFINITION"):
            mode = "DEF"
        elif self.accept("IMPLEMENTATION"):
            mode = "IMP"

        # Skip until ENDCLASS.
        while True:
            tok = self.next()
            if not tok:
                raise ParserError("Missing ENDCLASS")
            if tok.value == "ENDCLASS":
                break

        self.expect(".")
        return ("CLASS", name, mode)
# =====================================================
# ===============     RUNTIME ENGINE     ===============
# =====================================================

class RuntimeError(Exception):
    pass


class RuntimeEnv:
    """
    Holds variables, internal tables, objects, classes,
    SQL tables, and runtime output buffer.
    """
    def __init__(self):
        self.vars = {}          # simple variables
        self.structs = {}       # structure definitions
        self.tables = {}        # internal tables
        self.output = []        # WRITE output
        self.classes = {}       # class → method bodies
        self.objects = {}       # object → {class, attributes}
        self.db = {}            # fake SQL database tables


# ============================================
#    Expression Evaluation
# ============================================

def eval_expr(env: RuntimeEnv, expr):
    """
    Evaluate expression nodes.
    """
    if isinstance(expr, Number):
        return expr.val

    if isinstance(expr, String):
        return expr.val

    if isinstance(expr, Var):
        return env.vars.get(expr.name, None)

    if isinstance(expr, Field):
        s = env.vars.get(expr.struct, None)
        if not isinstance(s, dict):
            return None
        return s.get(expr.field, None)

    if isinstance(expr, FuncCall):
        fn = expr.name

        # ---- Built-ins ----
        if fn == "LINES":
            table_name = expr.args[0].name
            return len(env.tables.get(table_name, []))

        if fn == "STRLEN":
            val = eval_expr(env, expr.args[0])
            return len(str(val))

        # More built-in functions can be added later
        return None

    if isinstance(expr, BinOp):
        a = eval_expr(env, expr.left)
        b = eval_expr(env, expr.right)
        op = expr.op

        # Arithmetic
        if op == "+": return (a or 0) + (b or 0)
        if op == "-": return (a or 0) - (b or 0)
        if op == "*": return (a or 0) * (b or 0)
        if op == "/": return (a or 0) / (b or 0)

        # Comparisons
        if op == "=":  return a == b
        if op == "<>": return a != b
        if op == ">":  return a > b
        if op == "<":  return a < b
        if op == ">=": return a >= b
        if op == "<=": return a <= b

        raise RuntimeError(f"Unknown operator {op}")

    raise RuntimeError(f"Cannot evaluate expression: {expr}")


# ============================================
#      Statement Execution
# ============================================

def exec_statement(env: RuntimeEnv, stmt):
    """
    Execute individual statements using strict ABAP semantics.
    """

    # -------------------------
    # WRITE
    # -------------------------
    if isinstance(stmt, Write):
        for item in stmt.items:
            if isinstance(item, String) and item.val == "\n":
                env.output.append("\n")
            else:
                env.output.append(str(eval_expr(env, item)))
        env.output.append("\n")
        return

    # -------------------------
    # DATA declaration
    # -------------------------
    if isinstance(stmt, DataDecl):
        # Simple variable
        if stmt.value:
            env.vars[stmt.name] = eval_expr(env, stmt.value)
        else:
            env.vars[stmt.name] = None
        return

    # -------------------------
    # Assignment
    # -------------------------
    if isinstance(stmt, Assign):
        val = eval_expr(env, stmt.expr)
        if isinstance(stmt.target, Var):
            env.vars[stmt.target.name] = val
            return

        if isinstance(stmt.target, Field):
            sname = stmt.target.struct
            fld   = stmt.target.field
            if sname not in env.vars or not isinstance(env.vars[sname], dict):
                env.vars[sname] = {}
            env.vars[sname][fld] = val
            return

    # -------------------------
    # APPEND structured
    # -------------------------
    if isinstance(stmt, Append):
        target = stmt.target_table
        if target not in env.tables:
            env.tables[target] = []
        row = {}
        for k, v in stmt.source_row.items():
            row[k] = eval_expr(env, v)
        env.tables[target].append(row)
        return

    # -------------------------
    # APPEND simple
    # -------------------------
    if isinstance(stmt, AppendSimple):
        src = stmt.source_var
        tgt = stmt.target_table

        if tgt not in env.tables:
            env.tables[tgt] = []

        v = env.vars.get(src)
        if isinstance(v, dict):
            env.tables[tgt].append(v.copy())
        else:
            env.tables[tgt].append(v)
        return

    # -------------------------
    # LOOP AT itab INTO wa
    # -------------------------
    if isinstance(stmt, LoopAt):
        itab = env.tables.get(stmt.table, [])
        for row in itab:
            env.vars[stmt.into] = row.copy() if isinstance(row, dict) else row
            for inner in stmt.body:
                exec_statement(env, inner)
        return

    # -------------------------
    # IF block
    # -------------------------
    if isinstance(stmt, If):
        if eval_expr(env, stmt.cond):
            for s in stmt.then_body: exec_statement(env, s)
            return

        for cond, block in stmt.elif_list:
            if eval_expr(env, cond):
                for s in block: exec_statement(env, s)
                return

        for s in stmt.else_body: exec_statement(env, s)
        return

    # -------------------------
    # WHILE
    # -------------------------
    if isinstance(stmt, While):
        while eval_expr(env, stmt.cond):
            for s in stmt.body:
                exec_statement(env, s)
        return

    # -------------------------
    # DO n TIMES
    # -------------------------
    if isinstance(stmt, Do):
        times = eval_expr(env, stmt.times_expr) if stmt.times_expr else 0
        for _ in range(times):
            for s in stmt.body:
                exec_statement(env, s)
        return

    # -------------------------
    # CASE block
    # -------------------------
    if isinstance(stmt, tuple) and stmt[0] == "CASE":
        _, expr, cases = stmt
        val = eval_expr(env, expr)
        for c, block in cases:
            if eval_expr(env, c) == val:
                for s in block:
                    exec_statement(env, s)
                return
        return

    # -------------------------
    # SELECT FROM (simple SQL emulator)
    # -------------------------
    if isinstance(stmt, SelectInto):
        table_name = stmt.table_name
        itab_name = stmt.into_table

        src = env.db.get(table_name, [])
        dest = []

        if stmt.where:
            field, expr = stmt.where
            cond_val = eval_expr(env, expr)
            for row in src:
                if str(row.get(field)) == str(cond_val):
                    dest.append(row.copy())
        else:
            for row in src:
                dest.append(row.copy())

        env.tables[itab_name] = dest
        return

    # -------------------------
    # CREATE OBJECT
    # -------------------------
    if isinstance(stmt, tuple) and stmt[0] == "CREATE_OBJ":
        _, obj, cls = stmt
        env.objects[obj] = {"class": cls, "attrs": {}}
        return

    # -------------------------
    # CALL METHOD
    # -------------------------
    if isinstance(stmt, tuple) and stmt[0] == "CALL_METH":
        _, obj, meth = stmt
        # For now, classes aren't fully implemented
        env.output.append(f"[CALL] {obj}->{meth}\n")
        return

    # -------------------------
    # CLASS parsing (no runtime yet)
    # -------------------------
    if isinstance(stmt, tuple) and stmt[0] == "CLASS":
        # handled at parse-time; skip for now
        return

    # Unknown — silently ignore for now
    return


# =====================================================
#            RUN PROGRAM (MAIN EXECUTOR)
# =====================================================

def execute_program(program: Program):
    env = RuntimeEnv()
    for stmt in program.statements:
        exec_statement(env, stmt)
    return "".join(env.output)
# =====================================================
#            PUBLIC API (SIA WRAPPER + RUNNER)
# =====================================================

def extract_sia_block(code: str):
    """
    Extract content inside *sia ... sia*
    """
    start = code.find("*sia")
    end   = code.rfind("sia*")

    if start == -1 or end == -1:
        raise RuntimeError(
            "Missing SIA wrapper. Expected code inside:\n"
            "*sia\n"
            "   ... ABAP code ...\n"
            "sia*"
        )

    inner = code[start + 4 : end].strip()
    return inner


def run(code: str):
    """
    Execute ABAP code inside *sia ... sia*.
    """
    try:
        src = extract_sia_block(code)
        tokens = tokenize_abap(src)
        parser = FullParser(tokens)
        program = parser.parse_program()

        output = execute_program(program)
        print(output)
        return output

    except ParserError as pe:
        print(f"[PARSER ERROR] {pe}")
        raise

    except RuntimeError as re:
        print(f"[RUNTIME ERROR] {re}")
        raise

    except Exception as e:
        print(f"[UNKNOWN ERROR] {e}")
        raise



def run_file(path: str):
    """
    Run ABAP code from a file.
    """
    with open(path, "r", encoding="utf-8") as f:
        return run(f.read())



def repl():
    """
    Interactive REPL shell for SIA-ELS.
    User types *sia at start and sia* at end.
    """
    print("SIA Enterprise Logic Studio - REPL")
    print("Enter ABAP code inside *sia ... sia* blocks.")
    print("Type ':quit' to exit.\n")

    buffer = []
    recording = False

    while True:
        line = input("ELS> ").rstrip("\n")

        if line == ":quit":
            break

        # Start capturing when *sia appears
        if "*sia" in line:
            recording = True
            buffer = [line]

            # Immediate end
            if "sia*" in line:
                code = "\n".join(buffer)
                run(code)
                recording = False

            continue

        if recording:
            buffer.append(line)

            if "sia*" in line:
                code = "\n".join(buffer)
                run(code)
                recording = False

            continue

        # Not inside *sia
        print("Use *sia ... sia* to execute code.")

# =====================================================
#            OPTIONAL HELPERS & ENHANCEMENTS
# =====================================================

# --------------------------------------------
# Debugging utilities
# --------------------------------------------
DEBUG = False

def debug(msg):
    if DEBUG:
        print("[DEBUG]", msg)


# --------------------------------------------
# SQL Table Loader (user can populate env.db)
# --------------------------------------------
def load_sql_table(env: RuntimeEnv, name: str, rows: list):
    """
    Loads a Python list of dicts into SQL namespace.
    Example:
        load_sql_table(env, "employees", [
            {"id": 1, "name": "Alice"},
            {"id": 2, "name": "Bob"}
        ])
    """
    if not isinstance(rows, list):
        raise RuntimeError("SQL table must be a list of dictionaries")
    env.db[name] = [r.copy() for r in rows]


# --------------------------------------------
# Class Registry (Stub implementation)
# --------------------------------------------
def register_class(env: RuntimeEnv, cls_name: str, methods: dict):
    """
    Register a class with method bodies.
    Only a basic structure is implemented.
    """
    env.classes[cls_name] = {
        "methods": methods,
        "attributes": {}
    }


def get_method(env: RuntimeEnv, class_name: str, method_name: str):
    cls = env.classes.get(class_name)
    if not cls:
        return None
    return cls["methods"].get(method_name)


# --------------------------------------------
# Object Attribute Helpers
# --------------------------------------------
def set_object_attr(env: RuntimeEnv, obj_name, key, value):
    if obj_name not in env.objects:
        raise RuntimeError(f"Object '{obj_name}' not created.")
    env.objects[obj_name]["attrs"][key] = value


def get_object_attr(env: RuntimeEnv, obj_name, key):
    if obj_name not in env.objects:
        raise RuntimeError(f"Object '{obj_name}' not created.")
    return env.objects[obj_name]["attrs"].get(key)


# =====================================================
#            DEFAULT BOOTSTRAP / UTILITIES
# =====================================================

def bootstrap_environment(env: RuntimeEnv):
    """
    Optional: Pre-load some example SQL data.
    Teachers can enable this to give students built-in DB tables.
    """
    # Example built-in SQL table
    env.db["employees"] = [
        {"id": "1", "name": "Alice", "dept": "HR"},
        {"id": "2", "name": "Bob", "dept": "IT"},
        {"id": "3", "name": "Carol", "dept": "HR"},
    ]


# =====================================================
#               SAFE EXECUTION WRAPPER
# =====================================================

def safe_run(code: str):
    """
    Same as run(), but traps errors cleanly.
    """
    try:
        return run(code)
    except Exception as e:
        print("[SIA-ELS ERROR]", e)
        return None


# =====================================================
#               FINAL MODULE EXPORTS
# =====================================================

__all__ = [
    # Main API
    "run",
    "run_file",
    "repl",
    "safe_run",

    # Core tools
    "tokenize_abap",
    "FullParser",
    "execute_program",

    # Runtime & helpers
    "RuntimeEnv",
    "load_sql_table",
    "register_class",
    "set_object_attr",
    "get_object_attr",

    # Debug
    "DEBUG",
    "debug",
]
