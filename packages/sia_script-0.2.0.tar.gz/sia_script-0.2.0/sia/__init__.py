"""
SIA Package Initializer
-----------------------
Loads the following modules:

1. SiaNTT  — Entity / Object modeling
2. SiaCHI  — Chemical analysis toolkit
3. SIA-ELS — ABAP Interpreter (Enterprise Logic Studio)
"""

# =====================================================
# Existing NTT Module
# =====================================================

from .ntt import ntt


# =====================================================
# Existing CHI Module (Chemical Analysis)
# =====================================================

from .chi import chi as ChiClass
chi = ChiClass(verbose=False)


# =====================================================
# SIA Enterprise Logic Studio (ABAP Interpreter)
# =====================================================

try:
    from .els import (
        run as els_run,
        run_file as els_run_file,
        repl as els_repl,
        safe_run as els_safe_run,
        DEBUG as els_debug,
        debug as els_debug_print
    )

except Exception as e:
    print(f"[SIA] ELS interpreter not loaded: {e}")

    def els_run(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")

    def els_run_file(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")

    def els_repl(*args, **kwargs):
        raise ImportError("ELS interpreter missing. Add els.py to the sia folder.")

    def els_safe_run(*args, **kwargs):
        print("[ELS] Interpreter missing.")
        return None

    els_debug = False

    def els_debug_print(*args, **kwargs):
        pass


# =====================================================
# Public API
# =====================================================

__all__ = [
    # Existing modules
    "ntt",
    "chi",

    # Interpreter API
    "els_run",
    "els_run_file",
    "els_repl",
    "els_safe_run",
    "els_debug",
    "els_debug_print",
]