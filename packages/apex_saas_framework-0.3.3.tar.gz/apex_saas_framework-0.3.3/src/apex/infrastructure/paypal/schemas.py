"""PayPal Pydantic schemas."""

from typing import Any

from pydantic import BaseModel, Field


class SubscriberName(BaseModel):
    """Subscriber name schema."""

    given_name: str
    surname: str


class SubscriberEmail(BaseModel):
    """Subscriber email schema."""

    email_address: str


class SubscriberInfo(BaseModel):
    """Subscriber information schema."""

    name: SubscriberName | None = None
    email_address: str


class CreateSubscriptionRequest(BaseModel):
    """Schema for creating a subscription."""

    plan_id: str
    subscriber_email: str
    subscriber_first_name: str
    subscriber_last_name: str
    return_url: str
    cancel_url: str


class BillingCycle(BaseModel):
    """Billing cycle schema."""

    frequency: dict[str, Any]
    tenure_type: str
    sequence: int
    total_cycles: int
    pricing_scheme: dict[str, Any]


class CreatePlanRequest(BaseModel):
    """Schema for creating a billing plan."""

    product_id: str
    name: str
    description: str
    billing_cycles: list[BillingCycle]


class CreateProductRequest(BaseModel):
    """Schema for creating a product."""

    name: str
    description: str
    type: str = Field(default="SERVICE")


class CancelSubscriptionRequest(BaseModel):
    """Schema for cancelling a subscription."""

    subscription_id: str
    reason: str | None = None


class SuspendSubscriptionRequest(BaseModel):
    """Schema for suspending a subscription."""

    subscription_id: str
    reason: str | None = None


class ActivateSubscriptionRequest(BaseModel):
    """Schema for activating a subscription."""

    subscription_id: str
    reason: str | None = None


class SubscriptionResponse(BaseModel):
    """Schema for subscription response."""

    id: str
    status: str
    plan_id: str
    start_time: str | None = None
    subscriber: dict[str, Any] | None = None
    billing_info: dict[str, Any] | None = None
    links: list[dict[str, Any]] | None = None


class WebhookEventRequest(BaseModel):
    """Schema for webhook event."""

    id: str
    event_type: str
    resource: dict[str, Any]
    summary: str | None = None
    create_time: str

