"""
Apex - A production-ready FastAPI boilerplate framework for SaaS applications.

Build SaaS apps in minutes with minimal code!

Quick Start:
    >>> from apex import Apex
    >>> app = Apex().app

With Models:
    >>> from apex import Apex
    >>> from apex.models import User, Organization
    >>> app = Apex(models=[User, Organization]).app
"""

__version__ = "0.3.3"

# Simple API - LangChain-style ease of use
from apex.core.app import Apex, ApexConfig, create_app, init_database
from apex.core.decorators import (
    auth_required,
    permission_required,
    role_required,
    route,
    on,
    validate,
    cache,
    rate_limit,
)

# Configuration
from apex.core.config import Settings, get_settings

# Models - Import base (abstract) models for users to extend
from apex.domain.models.user import BaseUser
from apex.domain.models.organization import BaseOrganization, BaseOrganizationLocation
from apex.domain.models.role import BaseRole
from apex.domain.models.permission import BasePermission

# Convenience aliases (users extend these to create concrete models)
User = BaseUser
Organization = BaseOrganization
OrganizationLocation = BaseOrganizationLocation
Role = BaseRole
Permission = BasePermission

__all__ = [
    # Core Framework
    "Apex",
    "ApexConfig",
    "create_app",
    "init_database",
    
    # Decorators
    "auth_required",
    "permission_required",
    "role_required",
    "route",
    "on",
    "validate",
    "cache",
    "rate_limit",
    
    # Configuration
    "Settings",
    "get_settings",
    
    # Models (Simple names)
    "User",
    "Organization",
    "OrganizationLocation",
    "Role",
    "Permission",
    
    # Models (Base names)
    "BaseUser",
    "BaseOrganization",
    "BaseOrganizationLocation",
    "BaseRole",
    "BasePermission",
    
    # Version
    "__version__",
]

