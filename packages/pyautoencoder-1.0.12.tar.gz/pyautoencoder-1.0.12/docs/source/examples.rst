Examples
========

.. toctree::
   :maxdepth: 1

   examples/ae_mnist
   examples/vae_mnist
