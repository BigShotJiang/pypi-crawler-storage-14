"""Unit tests for MCP Ticketer core components."""
