# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Module for interacting with the weather API service."""
