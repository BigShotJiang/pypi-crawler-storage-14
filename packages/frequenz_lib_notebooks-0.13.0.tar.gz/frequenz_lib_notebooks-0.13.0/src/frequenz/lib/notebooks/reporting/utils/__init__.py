# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Utilities for energy reporting."""
