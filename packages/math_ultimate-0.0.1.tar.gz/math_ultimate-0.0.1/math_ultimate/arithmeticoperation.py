def arithmeticoperation(num1, num2, choice):

    def convert_to_number(value):
        try:
            value_str = str(value).strip()
            return float(value_str) if "." in value_str else int(value_str)
        except (ValueError, TypeError):
            raise ValueError(f"Invalid numeric input: '{value}'")

    num1 = convert_to_number(num1)
    num2 = convert_to_number(num2)

    if not isinstance(choice, str):
        raise ValueError("Choice must be a string.")

    choice = choice.lower().strip()

    operation_map = {
        "+": "add", "add": "add", "addition": "add",
        "-": "sub", "sub": "sub", "subtract": "sub", "subtraction": "sub",
        "*": "mul", "mul": "mul", "prod": "mul", "multiply": "mul", "multiplication": "mul",
        "/": "div", "div": "div", "divide": "div", "division": "div",
        "%": "mod", "mod": "mod", "modulo": "mod",
    }

    if choice not in operation_map:
        raise ValueError(f"Invalid operation choice: '{choice}'")

    operation = operation_map[choice]

    match operation:
        case "add":
            return num1 + num2
        case "sub":
            return num1 - num2
        case "mul":
            return num1 * num2
        case "div":
            if num2 == 0:
                raise ZeroDivisionError("Division by zero is not allowed.")
            return num1 / num2
        case "mod":
            if num2 == 0:
                raise ZeroDivisionError("Modulo by zero is not allowed.")
            return num1 % num2
        case _:
            raise ValueError("Unexpected operation encountered.")
