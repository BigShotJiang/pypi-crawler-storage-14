"""enecoQ power data fetcher.

Fetch power usage, cost, and CO2 emission data from enecoQ web service.
"""

__version__ = "2.1.0"
