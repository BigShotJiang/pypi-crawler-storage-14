"""Tests for enecoq_data_fetcher."""
