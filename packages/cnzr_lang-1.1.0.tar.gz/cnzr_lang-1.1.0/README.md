# CNZR Language

CNZR Language adalah bahasa pemrograman scripting sederhana dengan sintaks yang mudah dibaca, menggunakan kata kunci dalam Bahasa Indonesia.

Versi saat ini: **v1.0** (High-Level & Beginner Friendly)

## Fitur Utama

*   **Sintaks Bahasa Indonesia**: Menggunakan kata kunci seperti `jika`, `selama`, `tulis`, `fungsi`.
*   **Ramah Pemula**: Pesan error yang jelas dan edukatif, serta mode pemula di REPL.
*   **High-Level**: Mendukung input (`tanya`), loop sederhana (`ulang`), dan modul standar (`teks`, `daftar`, `angka`, `waktu`, `berkas`).
*   **Indentation-based**: Blok kode ditandai dengan indentasi (mirip Python).
*   **CLI Resmi**: Jalankan kode dengan perintah `cnzr`.
*   **Debugging**: Mode debug untuk melacak eksekusi program.
*   **Scaffolding**: Buat proyek baru dengan cepat menggunakan `cnzr init`.

## Instalasi

Pastikan Anda memiliki Python 3 terinstal.

1.  Clone repository ini.
2.  Install package CNZR:
    ```bash
    pip install .
    ```
    *(Gunakan `pip3` jika perlu)*

## Penggunaan

Setelah terinstal, Anda bisa menggunakan perintah `cnzr` langsung dari terminal.

### 1. Memulai Proyek Baru
Gunakan perintah `init` untuk membuat struktur proyek dasar.
```bash
cnzr init nama_proyek
cd nama_proyek
cnzr run main.cnzr
```

### 2. Mode Interaktif (REPL)
Ketik `cnzr` untuk masuk ke mode interaktif standar.
```bash
cnzr
```

### 3. Mode Pemula
Ketik `cnzr pemula` untuk masuk ke mode interaktif dengan panduan dan bantuan.
```bash
cnzr pemula
```

### 4. Menjalankan File Script
Jalankan file `.cnzr` dengan perintah `run`.
```bash
cnzr run nama_file.cnzr
```
Contoh:
```bash
cnzr run cnzr_lang/examples/v1_test.cnzr
```

### 5. Debugging
Gunakan flag `--debug` untuk melihat jejak eksekusi program.
```bash
cnzr run --debug nama_file.cnzr
```
Ini akan menampilkan log eksekusi setiap baris dan stack trace lengkap jika terjadi error.

### 7. Auto-Formatter
Merapikan kode Anda secara otomatis.
```bash
cnzr fmt nama_file.cnzr
```

### 8. Unit Testing
Menjalankan file test (`*_test.cnzr`).
### 9. Dokumentasi & Bantuan
Lihat dokumentasi langsung di terminal.
```bash
cnzr help
cnzr doc tulis
cnzr doc nama_file.cnzr:nama_fungsi
```

### 10. Template Proyek
Buat proyek dengan template siap pakai.
```bash
cnzr init nama_proyek --tipe cli
cnzr init nama_proyek --tipe catatan
cnzr init nama_proyek --tipe game-teks
```

## Contoh Kode (v1.0)

### Halo Pengguna
```cnzr
setel nama = tanya "Siapa nama Anda? "
tulis "Halo " + nama + ", selamat datang di CNZR!"
```

### Pemrograman Berorientasi Objek (OOP)
```cnzr
kelas Orang:
    fungsi __init__(self, nama):
        setel self.nama = nama

    fungsi sapa(self):
        tulis "Halo, saya " + self.nama

setel o = Orang("Budi")
o.sapa()
```

### Modul dan Import
```cnzr
dari matematika ambil PI, luas_lingkaran

tulis "Luas lingkaran: " + luas_lingkaran(10)
```

### Perulangan Sederhana
```cnzr
ulang 3 kali:
    tulis "Hore!"
```

### Menggunakan Modul Standar
```cnzr
pakai angka
pakai teks

setel acak = angka.acak(1, 100)
tulis "Angka keberuntungan Anda: " + acak

setel pesan = "belajar koding itu seru"
tulis teks.besar(pesan)
```

### Percabangan
```cnzr
setel nilai = 80
jika nilai >= 75:
    tulis "Lulus"
jika tidak apa-apa:
    tulis "Belum Lulus"
```

## Dokumentasi

*   [Panduan Pemula](docs/panduan_pemula.md) - Tutorial dasar.
*   [Fitur Lanjutan](docs/fitur_lanjutan.md) - OOP, Modul, Testing, dan Formatter.

## Lisensi

MIT License
