from setuptools import setup, find_packages

setup(
    name='cnzr_lang',
    version='1.1.0',
    description='Bahasa Pemrograman High-Level Berbahasa Indonesia',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='CNZR Team',
    url='https://github.com/cenzer0/cnzr',
    packages=find_packages(),
    install_requires=[
        'pygls>=2.0.0',
    ],
    entry_points={
        'console_scripts': [
            'cnzr=cnzr_lang.cnzr.cli:main',
        ],
    },
    python_requires='>=3.8',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: Interpreters',
    ],
)
