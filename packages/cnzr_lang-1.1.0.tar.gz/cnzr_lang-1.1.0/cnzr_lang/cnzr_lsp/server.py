from pygls.lsp.server import LanguageServer
from lsprotocol.types import (
    TEXT_DOCUMENT_DID_CHANGE,
    TEXT_DOCUMENT_DID_OPEN,
    TEXT_DOCUMENT_HOVER,
    TEXT_DOCUMENT_DEFINITION,
    TEXT_DOCUMENT_COMPLETION,
    Diagnostic,
    DiagnosticSeverity,
    Position,
    Range,
    Hover,
    MarkupContent,
    MarkupKind,
    Location,
    CompletionItem,
    CompletionItemKind,
    CompletionList,
    CompletionParams,
    HoverParams,
    DefinitionParams,
    DidOpenTextDocumentParams,
    DidChangeTextDocumentParams
)
import sys
import os

# Ensure we can import cnzr modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cnzr.lexer import Lexer
from cnzr.parser import Parser
from cnzr.tokens import *
from cnzr.ast_nodes import *

server = LanguageServer("cnzr-lsp", "v0.1")

def _validate(ls, params):
    text_doc = ls.workspace.get_text_document(params.text_document.uri)
    source = text_doc.source
    
    diagnostics = []
    
    lexer = Lexer("lsp", source)
    tokens, error = lexer.make_tokens()
    
    if error:
        # Lexer error
        start_line = error.pos_start.ln
        start_col = error.pos_start.col
        end_line = error.pos_end.ln
        end_col = error.pos_end.col
        
        d = Diagnostic(
            range=Range(
                start=Position(line=start_line, character=start_col),
                end=Position(line=end_line, character=end_col)
            ),
            message=error.details,
            severity=DiagnosticSeverity.Error,
            source="cnzr"
        )
        diagnostics.append(d)
    else:
        parser = Parser(tokens)
        ast = parser.parse()
        
        if ast.error:
            # Parser error
            start_line = ast.error.pos_start.ln
            start_col = ast.error.pos_start.col
            end_line = ast.error.pos_end.ln
            end_col = ast.error.pos_end.col
            
            d = Diagnostic(
                range=Range(
                    start=Position(line=start_line, character=start_col),
                    end=Position(line=end_line, character=end_col)
                ),
                message=ast.error.details,
                severity=DiagnosticSeverity.Error,
                source="cnzr"
            )
            diagnostics.append(d)

    ls.publish_diagnostics(params.text_document.uri, diagnostics)

@server.feature(TEXT_DOCUMENT_DID_OPEN)
def did_open(ls, params: DidOpenTextDocumentParams):
    _validate(ls, params)

@server.feature(TEXT_DOCUMENT_DID_CHANGE)
def did_change(ls, params: DidChangeTextDocumentParams):
    _validate(ls, params)

def find_node_at_pos(node, line, col):
    if not node: return None
    
    # Check if position is within node's range
    if not (node.pos_start.ln <= line <= node.pos_end.ln):
        return None
        
    # If single line, check columns
    if node.pos_start.ln == node.pos_end.ln:
        if not (node.pos_start.col <= col <= node.pos_end.col):
            return None
    else:
        # Multi-line: check start and end lines specifically
        if line == node.pos_start.ln and col < node.pos_start.col: return None
        if line == node.pos_end.ln and col > node.pos_end.col: return None

    # Check children
    # This requires knowing the structure of every node. 
    # For simplicity, we'll check common attributes or iterate if it's a list
    
    found_child = None
    
    if isinstance(node, list): # List of statements
        for stmt in node:
            res = find_node_at_pos(stmt, line, col)
            if res: return res
        return None

    # Generic child traversal using __dict__ to find Nodes or lists of Nodes
    for key, value in node.__dict__.items():
        if isinstance(value, Node):
            res = find_node_at_pos(value, line, col)
            if res: found_child = res
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, Node):
                    res = find_node_at_pos(item, line, col)
                    if res: found_child = res
    
    return found_child if found_child else node

def get_keywords():
    return [
        'setel', 'tulis', 'jika', 'selama', 'untuk', 'ulang', 'fungsi', 'kelas',
        'kembalikan', 'pakai', 'dari', 'ambil', 'tanya', 'dan', 'atau', 'tidak',
        'benar', 'salah', 'kosong'
    ]

@server.feature(TEXT_DOCUMENT_HOVER)
def hover(ls, params: HoverParams):
    text_doc = ls.workspace.get_text_document(params.text_document.uri)
    source = text_doc.source
    lexer = Lexer("lsp", source)
    tokens, _ = lexer.make_tokens()
    parser = Parser(tokens)
    ast = parser.parse()
    
    if ast.node:
        # AST node is a list of statements
        node = find_node_at_pos(ast.node, params.position.line, params.position.character)
        if node:
            # Simple hover info
            info = f"Node: {type(node).__name__}"
            if isinstance(node, VarAccessNode):
                info = f"Variabel: {node.var_name_tok.value}"
            elif isinstance(node, FuncDefNode):
                name = node.var_name_tok.value if node.var_name_tok else "<anon>"
                args = ", ".join([t.value for t in node.arg_name_toks])
                info = f"Fungsi: {name}({args})"
            elif isinstance(node, ClassDefNode):
                info = f"Kelas: {node.var_name_tok.value}"
            
            return Hover(contents=MarkupContent(kind=MarkupKind.Markdown, value=info))
            
    return None

@server.feature(TEXT_DOCUMENT_COMPLETION)
def completion(ls, params: CompletionParams):
    items = []
    
    # Add keywords
    for kw in get_keywords():
        items.append(CompletionItem(label=kw, kind=CompletionItemKind.Keyword))
        
    # TODO: Add identifiers from scope (requires traversing AST and collecting names)
    
    return CompletionList(is_incomplete=False, items=items)

@server.feature(TEXT_DOCUMENT_DEFINITION)
def definition(ls, params: DefinitionParams):
    # Basic implementation: just return current location for now as placeholder
    # In real implementation, we need symbol table to look up definition location
    return None

if __name__ == "__main__":
    server.start_io()
