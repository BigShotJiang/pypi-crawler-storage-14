from enum import IntEnum, auto
import struct

class OpCode(IntEnum):
    # Stack Manipulation
    POP_TOP = 0x01
    DUP_TOP = 0x02

    # Load & Store
    LOAD_CONST = 0x10
    LOAD_NAME = 0x11
    STORE_NAME = 0x12
    LOAD_ATTR = 0x13
    STORE_ATTR = 0x14

    # Arithmetic & Logic
    ADD = 0x20
    SUB = 0x21
    MUL = 0x22
    DIV = 0x23
    MOD = 0x24
    POW = 0x25
    EQ = 0x26
    NEQ = 0x27
    LT = 0x28
    GT = 0x29
    LTE = 0x2A
    GTE = 0x2B
    AND = 0x2C
    OR = 0x2D
    NOT = 0x2E
    NEG = 0x2F

    # Control Flow
    JUMP_FORWARD = 0x30
    JUMP_ABSOLUTE = 0x31
    POP_JUMP_IF_FALSE = 0x32
    POP_JUMP_IF_TRUE = 0x33

    # Functions & Calls
    MAKE_FUNCTION = 0x40
    CALL_FUNCTION = 0x41
    RETURN_VALUE = 0x42

    # Built-ins
    PRINT_EXPR = 0x50
    INPUT_EXPR = 0x51

class Instruction:
    def __init__(self, opcode, arg=None):
        self.opcode = opcode
        self.arg = arg

    def __repr__(self):
        return f"{self.opcode.name} {self.arg if self.arg is not None else ''}"

class BytecodeProgram:
    def __init__(self):
        self.constants = []
        self.names = []
        self.code = []
        self.version = 1

    def add_const(self, value):
        if value in self.constants:
            return self.constants.index(value)
        self.constants.append(value)
        return len(self.constants) - 1

    def add_name(self, name):
        if name in self.names:
            return self.names.index(name)
        self.names.append(name)
        return len(self.names) - 1

    def emit(self, opcode, arg=None):
        self.code.append(Instruction(opcode, arg))

    def __repr__(self):
        return f"BytecodeProgram(v{self.version}, {len(self.code)} instrs)"
