class Node:
    def __init__(self, pos_start, pos_end):
        self.pos_start = pos_start
        self.pos_end = pos_end

class NumberNode(Node):
    def __init__(self, tok):
        super().__init__(tok.pos_start, tok.pos_end)
        self.tok = tok
    def __repr__(self): return f'{self.tok}'

class StringNode(Node):
    def __init__(self, tok):
        super().__init__(tok.pos_start, tok.pos_end)
        self.tok = tok
    def __repr__(self): return f'{self.tok}'

class ListNode(Node):
    def __init__(self, element_nodes, pos_start, pos_end):
        super().__init__(pos_start, pos_end)
        self.element_nodes = element_nodes

class DictNode(Node):
    def __init__(self, key_value_pairs, pos_start, pos_end):
        super().__init__(pos_start, pos_end)
        self.key_value_pairs = key_value_pairs

class BinOpNode(Node):
    def __init__(self, left_node, op_tok, right_node):
        super().__init__(left_node.pos_start, right_node.pos_end)
        self.left_node = left_node
        self.op_tok = op_tok
        self.right_node = right_node
    def __repr__(self): return f'({self.left_node}, {self.op_tok}, {self.right_node})'

class TaskNode(Node):
    def __init__(self, node_to_run, pos_start=None, pos_end=None):
        super().__init__(pos_start if pos_start else node_to_run.pos_start, pos_end if pos_end else node_to_run.pos_end)
        self.node_to_run = node_to_run

    def __repr__(self):
        return f'TaskNode({self.node_to_run})'

class AwaitNode(Node):
    def __init__(self, node_to_await, pos_start=None, pos_end=None):
        super().__init__(pos_start if pos_start else node_to_await.pos_start, pos_end if pos_end else node_to_await.pos_end)
        self.node_to_await = node_to_await

    def __repr__(self):
        return f'AwaitNode({self.node_to_await})'

class UnaryOpNode(Node):
    def __init__(self, op_tok, node):
        super().__init__(op_tok.pos_start, node.pos_end)
        self.op_tok = op_tok
        self.node = node
    def __repr__(self): return f'({self.op_tok}, {self.node})'

class VarAccessNode(Node):
    def __init__(self, var_name_tok):
        super().__init__(var_name_tok.pos_start, var_name_tok.pos_end)
        self.var_name_tok = var_name_tok

class VarAssignNode(Node):
    def __init__(self, target_node, value_node):
        super().__init__(target_node.pos_start, value_node.pos_end)
        self.target_node = target_node
        self.value_node = value_node

class IfNode(Node):
    def __init__(self, cases, else_case):
        pos_end = cases[-1][0].pos_end
        if else_case:
            if len(else_case) > 0:
                pos_end = else_case[-1].pos_end
        elif cases[-1][1]:
            pos_end = cases[-1][1][-1].pos_end
            
        super().__init__(cases[0][0].pos_start, pos_end)
        self.cases = cases
        self.else_case = else_case

class WhileNode(Node):
    def __init__(self, condition_node, body_nodes):
        super().__init__(condition_node.pos_start, body_nodes[-1].pos_end if body_nodes else condition_node.pos_end)
        self.condition_node = condition_node
        self.body_nodes = body_nodes

class ForEachNode(Node):
    def __init__(self, var_name_tok, iter_node, body_nodes):
        super().__init__(var_name_tok.pos_start, body_nodes[-1].pos_end if body_nodes else iter_node.pos_end)
        self.var_name_tok = var_name_tok
        self.iter_node = iter_node
        self.body_nodes = body_nodes

class RepeatNode(Node):
    def __init__(self, count_node, body_nodes):
        super().__init__(count_node.pos_start, body_nodes[-1].pos_end if body_nodes else count_node.pos_end)
        self.count_node = count_node
        self.body_nodes = body_nodes

class ImportNode(Node):
    def __init__(self, module_name_tok):
        super().__init__(module_name_tok.pos_start, module_name_tok.pos_end)
        self.module_name_tok = module_name_tok

class MemberAccessNode(Node):
    def __init__(self, left_node, member_name_tok):
        super().__init__(left_node.pos_start, member_name_tok.pos_end)
        self.left_node = left_node
        self.member_name_tok = member_name_tok

class InputNode(Node):
    def __init__(self, prompt_node, pos_start, pos_end):
        super().__init__(pos_start, pos_end)
        self.prompt_node = prompt_node

class FuncDefNode(Node):
    def __init__(self, var_name_tok, arg_name_toks, body_nodes, docstring=None):
        pos_start = var_name_tok.pos_start if var_name_tok else (arg_name_toks[0].pos_start if arg_name_toks else body_nodes[0].pos_start)
        super().__init__(pos_start, body_nodes[-1].pos_end)
        self.var_name_tok = var_name_tok
        self.arg_name_toks = arg_name_toks
        self.body_nodes = body_nodes
        self.docstring = docstring

class CallNode(Node):
    def __init__(self, node_to_call, arg_nodes):
        pos_end = arg_nodes[-1].pos_end if arg_nodes else node_to_call.pos_end
        super().__init__(node_to_call.pos_start, pos_end)
        self.node_to_call = node_to_call
        self.arg_nodes = arg_nodes

class ReturnNode(Node):
    def __init__(self, node_to_return, pos_start, pos_end):
        super().__init__(pos_start, pos_end)
        self.node_to_return = node_to_return

class PrintNode(Node):
    def __init__(self, node_to_print, pos_start, pos_end):
        super().__init__(pos_start, pos_end)
        self.node_to_print = node_to_print

class ClassDefNode(Node):
    def __init__(self, var_name_tok, body_nodes, docstring=None):
        super().__init__(var_name_tok.pos_start, body_nodes[-1].pos_end if body_nodes else var_name_tok.pos_end)
        self.var_name_tok = var_name_tok
        self.body_nodes = body_nodes
        self.docstring = docstring

class ImportFromNode(Node):
    def __init__(self, module_name_tok, import_name_toks):
        super().__init__(module_name_tok.pos_start, import_name_toks[-1].pos_end)
        self.module_name_tok = module_name_tok
        self.import_name_toks = import_name_toks
