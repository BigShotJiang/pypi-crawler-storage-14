from .bytecode import OpCode, BytecodeProgram
import sys

class VM:
    def __init__(self, program: BytecodeProgram):
        self.program = program
        self.stack = []
        self.globals = {}
        self.ip = 0 # Instruction Pointer

    def run(self):
        code = self.program.code
        constants = self.program.constants
        names = self.program.names
        
        while self.ip < len(code):
            instr = code[self.ip]
            op = instr.opcode
            arg = instr.arg
            
            self.ip += 1
            
            if op == OpCode.LOAD_CONST:
                self.stack.append(constants[arg])
                
            elif op == OpCode.LOAD_NAME:
                name = names[arg]
                if name in self.globals:
                    self.stack.append(self.globals[name])
                else:
                    # Check builtins (simplified)
                    if name == "tulis":
                        self.stack.append("tulis") # Placeholder for builtin
                    else:
                        raise NameError(f"Name '{name}' is not defined")
                        
            elif op == OpCode.STORE_NAME:
                name = names[arg]
                val = self.stack.pop()
                self.globals[name] = val
                
            elif op == OpCode.ADD:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a + b)
                
            elif op == OpCode.SUB:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a - b)
                
            elif op == OpCode.MUL:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a * b)
                
            elif op == OpCode.DIV:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a / b)
                
            elif op == OpCode.PRINT_EXPR:
                val = self.stack.pop()
                print(val)
                
            elif op == OpCode.POP_JUMP_IF_FALSE:
                val = self.stack.pop()
                if not val:
                    self.ip = arg
                    
            elif op == OpCode.JUMP_FORWARD:
                self.ip = arg # In our compiler, we used absolute positions for jumps
                
            elif op == OpCode.JUMP_ABSOLUTE:
                self.ip = arg

            elif op == OpCode.EQ:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a == b)
                
            elif op == OpCode.LT:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a < b)
                
            elif op == OpCode.GT:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a > b)

            elif op == OpCode.INPUT_EXPR:
                prompt = self.stack.pop()
                res = input(prompt)
                self.stack.append(res)

            else:
                raise RuntimeError(f"Unknown opcode: {op}")
