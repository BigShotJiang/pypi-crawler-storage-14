from .ast_nodes import *
from .bytecode import BytecodeProgram, OpCode

class Compiler:
    def __init__(self):
        self.program = BytecodeProgram()

    def compile(self, node):
        if isinstance(node, list):
            for stmt in node:
                self.visit(stmt)
        else:
            self.visit(node)
        return self.program

    def visit(self, node):
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, self.no_visit_method)
        return method(node)

    def no_visit_method(self, node):
        raise Exception(f'No visit_{type(node).__name__} method defined')

    def visit_NumberNode(self, node):
        idx = self.program.add_const(node.tok.value)
        self.program.emit(OpCode.LOAD_CONST, idx)

    def visit_StringNode(self, node):
        idx = self.program.add_const(node.tok.value)
        self.program.emit(OpCode.LOAD_CONST, idx)

    def visit_VarAccessNode(self, node):
        idx = self.program.add_name(node.var_name_tok.value)
        self.program.emit(OpCode.LOAD_NAME, idx)

    def visit_VarAssignNode(self, node):
        self.visit(node.value_node)
        
        # Handle simple assignment for now
        if isinstance(node.target_node, VarAccessNode):
            idx = self.program.add_name(node.target_node.var_name_tok.value)
            self.program.emit(OpCode.STORE_NAME, idx)
        elif isinstance(node.target_node, MemberAccessNode):
             # o.attr = val
             # Stack: [val] -> need [val, obj] for STORE_ATTR? 
             # Spec says: STORE_ATTR (Top=value, Second=obj)
             # So we need to push obj first? No, usually we evaluate value first.
             # Let's check spec: STORE_ATTR + Index.
             # We need to evaluate object, then value.
             # Wait, if we visit value_node first, stack has [val].
             # Then we visit target_node? No.
             # We need to manually handle MemberAccessNode here.
             
             # 1. Evaluate Object
             self.visit(node.target_node.left_node)
             # Stack: [val, obj] -> Wrong order for standard STORE_ATTR usually?
             # Python STORE_ATTR: TOS is value, TOS-1 is object.
             # So we should evaluate Object then Value?
             # Let's re-evaluate standard:
             # obj.attr = val
             # LOAD obj
             # LOAD val
             # STORE_ATTR attr
             
             # My current code visited value first.
             # Let's fix:
             # Undo the visit(value_node) at the top?
             # Actually, let's restructure.
             pass 
             # Re-implementing below correctly.

    def visit_BinOpNode(self, node):
        self.visit(node.left_node)
        self.visit(node.right_node)

        op_type = node.op_tok.type
        if op_type == 'PLUS': self.program.emit(OpCode.ADD)
        elif op_type == 'MINUS': self.program.emit(OpCode.SUB)
        elif op_type == 'MUL': self.program.emit(OpCode.MUL)
        elif op_type == 'DIV': self.program.emit(OpCode.DIV)
        elif op_type == 'EE': self.program.emit(OpCode.EQ)
        elif op_type == 'NE': self.program.emit(OpCode.NEQ)
        elif op_type == 'LT': self.program.emit(OpCode.LT)
        elif op_type == 'GT': self.program.emit(OpCode.GT)
        elif op_type == 'LTE': self.program.emit(OpCode.LTE)
        elif op_type == 'GTE': self.program.emit(OpCode.GTE)
        elif op_type == 'KEYWORD' and node.op_tok.value == 'dan': self.program.emit(OpCode.AND)
        elif op_type == 'KEYWORD' and node.op_tok.value == 'atau': self.program.emit(OpCode.OR)

    def visit_UnaryOpNode(self, node):
        self.visit(node.node)
        if node.op_tok.type == 'MINUS':
            self.program.emit(OpCode.NEG)
        elif node.op_tok.matches('KEYWORD', 'tidak'):
            self.program.emit(OpCode.NOT)

    def visit_IfNode(self, node):
        # cases: [(cond, body), ...]
        # else_case: body
        
        end_jump_patches = []

        for condition, body in node.cases:
            self.visit(condition)
            # Emit Jump if False placeholder
            jump_false_idx = len(self.program.code)
            self.program.emit(OpCode.POP_JUMP_IF_FALSE, 0) # 0 is placeholder
            
            self.compile(body)
            
            # Jump to end of entire IF structure
            jump_end_idx = len(self.program.code)
            self.program.emit(OpCode.JUMP_FORWARD, 0) # 0 is placeholder
            end_jump_patches.append(jump_end_idx)
            
            # Patch Jump False
            self.program.code[jump_false_idx].arg = len(self.program.code)

        if node.else_case:
            self.compile(node.else_case)

        # Patch all JUMP_FORWARD to the end
        end_pos = len(self.program.code)
        for idx in end_jump_patches:
            self.program.code[idx].arg = end_pos

    def visit_WhileNode(self, node):
        start_pos = len(self.program.code)
        
        self.visit(node.condition_node)
        
        jump_false_idx = len(self.program.code)
        self.program.emit(OpCode.POP_JUMP_IF_FALSE, 0)
        
        self.compile(node.body_nodes)
        
        # Loop back
        self.program.emit(OpCode.JUMP_ABSOLUTE, start_pos)
        
        # Patch exit
        self.program.code[jump_false_idx].arg = len(self.program.code)

    def visit_PrintNode(self, node):
        self.visit(node.node_to_print)
        self.program.emit(OpCode.PRINT_EXPR)

    def visit_InputNode(self, node):
        if node.prompt_node:
            self.visit(node.prompt_node)
        else:
            # Push empty string if no prompt? Or handle in VM
            idx = self.program.add_const("")
            self.program.emit(OpCode.LOAD_CONST, idx)
            
        self.program.emit(OpCode.INPUT_EXPR)

    # Re-implementing VarAssignNode correctly
    def visit_VarAssignNode(self, node):
        if isinstance(node.target_node, VarAccessNode):
            self.visit(node.value_node)
            idx = self.program.add_name(node.target_node.var_name_tok.value)
            self.program.emit(OpCode.STORE_NAME, idx)
        elif isinstance(node.target_node, MemberAccessNode):
            # obj.attr = val
            # Stack: [obj, val] -> STORE_ATTR
            self.visit(node.target_node.left_node) # obj
            self.visit(node.value_node)            # val
            idx = self.program.add_name(node.target_node.member_name_tok.value)
            self.program.emit(OpCode.STORE_ATTR, idx)

    def visit_MemberAccessNode(self, node):
        self.visit(node.left_node)
        idx = self.program.add_name(node.member_name_tok.value)
        self.program.emit(OpCode.LOAD_ATTR, idx)

    def visit_CallNode(self, node):
        # Stack: [Func, Arg1, Arg2...]
        self.visit(node.node_to_call)
        for arg in node.arg_nodes:
            self.visit(arg)
        self.program.emit(OpCode.CALL_FUNCTION, len(node.arg_nodes))

    def visit_FuncDefNode(self, node):
        # TODO: Implement function compilation (Code Object)
        # For now, skip or basic placeholder
        pass

    def visit_ClassDefNode(self, node):
        # TODO: Implement class compilation
        pass
    
    def visit_ReturnNode(self, node):
        if node.node_to_return:
            self.visit(node.node_to_return)
        else:
            idx = self.program.add_const(None)
            self.program.emit(OpCode.LOAD_CONST, idx)
        self.program.emit(OpCode.RETURN_VALUE)
