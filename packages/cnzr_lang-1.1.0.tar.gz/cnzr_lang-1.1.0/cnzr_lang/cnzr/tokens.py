# Token Types
TT_INT = 'INT'
TT_FLOAT = 'FLOAT'
TT_STRING = 'STRING'
TT_IDENTIFIER = 'IDENTIFIER'
TT_KEYWORD = 'KEYWORD'
TT_PLUS = 'PLUS'
TT_MINUS = 'MINUS'
TT_MUL = 'MUL'
TT_DIV = 'DIV'
TT_MOD = 'MOD'
TT_LPAREN = 'LPAREN'
TT_RPAREN = 'RPAREN'
TT_LBRACKET = 'LBRACKET'  # [
TT_RBRACKET = 'RBRACKET'  # ]
TT_LBRACE = 'LBRACE'      # {
TT_RBRACE = 'RBRACE'      # }
TT_DOT = 'DOT'
TT_EQ = 'EQ'              # =
TT_EE = 'EE'              # ==
TT_NE = 'NE'              # !=
TT_LT = 'LT'              # <
TT_GT = 'GT'              # >
TT_LTE = 'LTE'            # <=
TT_GTE = 'GTE'            # >=
TT_COMMA = 'COMMA'
TT_COLON = 'COLON'        # :
TT_NEWLINE = 'NEWLINE'
TT_INDENT = 'INDENT'
TT_DEDENT = 'DEDENT'
TT_EOF = 'EOF'

KEYWORDS = [
    'setel', 'tulis', 
    'jika', 'jika tidak', 'jika tidak jika', # Multi-word keywords handled in lexer logic
    'selama', 'untuk', 'setiap', 'di', 'ulang', 'kali',
    'fungsi', 'kembalikan', 'pakai', 'kelas', 'dari', 'ambil',
    'tugas', 'tunggu', 'jalan_bersama',
    'benar', 'salah', 'kosong', 
    'dan', 'atau', 'tidak', 'tanya', 'apa-apa'
]

class Token:
    def __init__(self, type_, value=None, pos_start=None, pos_end=None):
        self.type = type_
        self.value = value
        if pos_start:
            self.pos_start = pos_start.copy()
            self.pos_end = pos_start.copy()
            self.pos_end.advance()
        if pos_end:
            self.pos_end = pos_end

    def matches(self, type_, value):
        return self.type == type_ and self.value == value

    def __repr__(self):
        if self.value: return f'{self.type}:{self.value}'
        return f'{self.type}'
